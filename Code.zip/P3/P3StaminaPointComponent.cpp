// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3StaminaPointComponent.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3Log.h"
#include "P3World.h"
#include "DrawDebugHelpers.h"
#include "Net/UnrealNetwork.h"

static TAutoConsoleVariable<int32> CVarP3StaminaDebug(
    TEXT("p3.staminaDebug"),
    0,
    TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3StaminaConsumeModifier(
	TEXT("p3.staminaConsumeModifier"),
	1.f,
	TEXT("modifier to adjust stamina consumption"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3StaminaSync(
	TEXT("p3.staminaSync"),
	1,
	TEXT("1: enable sync. 0: disable sync"), ECVF_Cheat);

TAutoConsoleVariable<float> CVarP3StaminaSyncMargin(
	TEXT("p3.staminaSyncMargin"),
	3.0f,
	TEXT("allowable error range of synchronizations"), ECVF_Cheat);


UP3StaminaPointComponent::UP3StaminaPointComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3StaminaPointComponent::BeginPlay()
{
	Super::BeginPlay();

	StaminaPoint = MaxStaminaPoint;
	LastGenerateTimeSeconds = GetWorld()->GetTimeSeconds();
}

void UP3StaminaPointComponent::OnRegister()
{
	Super::OnRegister();

}

void UP3StaminaPointComponent::OnUnregister()
{
	Super::OnUnregister();

}

void UP3StaminaPointComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	const float PrevStaminaPoint = StaminaPoint;
	bool bHasActiveConsumer = false;
	ConsumePerTick = 0.0f;
	float Regen = 0.0f;

	if (!bExhausted)
	{
		for (int32 Layer = 0; Layer < ARRAY_COUNT(Consumers); ++Layer)
		{
			if (Consumers[Layer] > 0.0f)
			{
				ConsumePerTick = Consumers[Layer] * CVarP3StaminaConsumeModifier.GetValueOnGameThread();

				SetStaminaPoint(StaminaPoint - (DeltaTime * ConsumePerTick));

				bHasActiveConsumer = true;
			}
		}
	}

	if (StaminaPoint < MaxStaminaPoint)
	{
		if (!bHasActiveConsumer)
		{
			if (bRegenAllowed)
			{
				const float Now = GetWorld()->GetTimeSeconds();
				if (LastGenerateTimeSeconds <= 0.0f)
				{
					LastGenerateTimeSeconds = Now - DeltaTime;
				}
				const float StartRegen = (Now - LastGenerateTimeSeconds - DeltaTime) * BaseStaminaRegenerateSlope + BaseStaminaRegeneratePerSeconds;
				const float EndRegen = (Now - LastGenerateTimeSeconds) * BaseStaminaRegenerateSlope + BaseStaminaRegeneratePerSeconds;
				Regen = (StartRegen + EndRegen) * DeltaTime * 0.5f;

				if (bExhausted)
				{
					Regen *= StaminaRegenerateMultiplierInExhausted;
					Regen = FMath::Max(Regen, 0.0f);
				}
				SetStaminaPoint(StaminaPoint + Regen);
			}
			else
			{
				LastGenerateTimeSeconds = 0.0f;
			}
		}
		else
		{
			LastGenerateTimeSeconds = 0.0f;
		}
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3StaminaDebug.GetValueOnGameThread() != 0)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character)
		{
			FString DebugString = FString::Printf(TEXT("Stamina (%.0f/%.0f)"), StaminaPoint, MaxStaminaPoint);

			if (bExhausted)
			{
				DebugString += TEXT(" Exhausted");
			}

			if (CVarP3StaminaDebug.GetValueOnGameThread() > 1)
			{
				if (Regen > 0.0f)
				{
					DebugString += FString::Printf(TEXT(" Regen %f"), Regen);
				}

				if (ConsumePerTick != 0.0f)
				{
					DebugString += FString::Printf(TEXT(" Consume %f"), ConsumePerTick);
				}

				DebugString += FString::Printf(TEXT(" RegenAllowed %d"), bRegenAllowed);
			}

			Character->AddDebugString(DebugString);

			for (int32 Layer = 0; Layer < ARRAY_COUNT(Consumers); ++Layer)
			{
				if (Consumers[Layer] != 0.0f)
				{
					Character->AddDebugString(FString::Printf(TEXT("  Consumer %s : %.3f/s"), *EnumToStringShort(EStaminaConsumerLayer, EStaminaConsumerLayer(Layer)), Consumers[Layer]));
				}
			}
		}
	}
#endif
}

float UP3StaminaPointComponent::GetStaminaPoint() const
{
	return bExhausted ? 0.0f : StaminaPoint;
}

float UP3StaminaPointComponent::GetStaminaPointInExhausted() const
{
	ensure(bExhausted);

	return StaminaPoint;
}

float UP3StaminaPointComponent::GetConsumePerTick() const
{
	return bExhausted ? 0.0f : ConsumePerTick;
}

float UP3StaminaPointComponent::GetConsumePerAction() const
{
	return bExhausted ? 0.0f : ConsumePerAction;
}

void UP3StaminaPointComponent::SetMaxStaminaPoint(const float InMaxStaminaPoint)
{
	MaxStaminaPoint = InMaxStaminaPoint;

	StaminaPoint = FMath::Clamp(StaminaPoint, 0.0f, MaxStaminaPoint);

	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_SetDirty(*this);
	}
}

void UP3StaminaPointComponent::FillUpStaminaPoint()
{
	SetStaminaPoint(MaxStaminaPoint);
	LastGenerateTimeSeconds = GetWorld()->GetTimeSeconds();
}

void UP3StaminaPointComponent::RestoreStaminaPoint(float InRestoreAmount)
{
	const float NewStaminaPoint = FMath::Min(MaxStaminaPoint, GetStaminaPoint() + InRestoreAmount);

	SetStaminaPoint(NewStaminaPoint);
}

void UP3StaminaPointComponent::SetStaminaPoint(float InStaminaPoint)
{
	StaminaPoint = FMath::Clamp(InStaminaPoint, 0.0f, MaxStaminaPoint);

	if (FMath::IsNearlyZero(StaminaPoint))
	{
		bExhausted = true;
	}

	if (bExhausted && StaminaPoint >= RecoverFromExhaustionStamina)
	{
		bExhausted = false;
	}

	if (CVarP3StaminaSync.GetValueOnGameThread() != 0)
	{
		if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
		{
			Server_SetDirty(*this);
		}
	}
}

void UP3StaminaPointComponent::SetConsumer(EStaminaConsumerLayer Layer, float ConsumeStaminaPerSecond)
{
	Consumers[static_cast<int>(Layer)] = ConsumeStaminaPerSecond;
}

float UP3StaminaPointComponent::GetConsumer(EStaminaConsumerLayer Layer) const
{
	return Consumers[static_cast<int>(Layer)];
}

void UP3StaminaPointComponent::ConsumeStamina(float ConsumeStaminaPoint)
{
	ConsumePerAction = ConsumeStaminaPoint * CVarP3StaminaConsumeModifier.GetValueOnGameThread();
	SetStaminaPoint(GetStaminaPoint() - (ConsumePerAction));

	LastGenerateTimeSeconds = GetWorld()->GetTimeSeconds();
}

void UP3StaminaPointComponent::NetSerialize(FArchive& Archive)
{
	if (!Archive.IsLoading())
	{
		Archive << MaxStaminaPoint;
		Archive << StaminaPoint;
		Archive << bExhausted;
	}
	else
	{
		float NewMaxStaminaPoint, NewStaminaPoint;

		Archive << NewMaxStaminaPoint;
		Archive << NewStaminaPoint;
		Archive << bExhausted;

		if (FMath::Abs(NewStaminaPoint - StaminaPoint) > CVarP3StaminaSyncMargin.GetValueOnGameThread())
		{
			SetStaminaPoint(NewStaminaPoint);
		}

		if (FMath::Abs(NewMaxStaminaPoint - MaxStaminaPoint) > 0.0f)
		{
			SetMaxStaminaPoint(NewMaxStaminaPoint);
		}
	}
}
