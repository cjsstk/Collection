// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ThermalVolumeActor.h"
#include "P3Character.h"
#include "P3CharacterMovementComponent.h"

const static FName NAME_ThermalActivateChanged = TEXT("ThermalActivateChanged");

AP3ThermalVolumeActor::AP3ThermalVolumeActor()
{
	PrimaryActorTick.bCanEverTick = false;
}

void AP3ThermalVolumeActor::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetThermalActive(bDefaultThermalActive);
	}
}

void AP3ThermalVolumeActor::Client_OnEvent(FName EventName, int32 Param)
{
	Super::Client_OnEvent(EventName, Param);

	if (EventName == NAME_ThermalActivateChanged)
	{
		Net_bThermalActive = (Param == 1);

		ThermalActiveChanged();
	}
}

void AP3ThermalVolumeActor::NotifyActorBeginOverlap(AActor* OtherActor)
{
	Super::NotifyActorBeginOverlap(OtherActor);

	if (!Net_bThermalActive)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(OtherActor);
	if (Character && Character->GetP3CharacterMovementBP())
	{
		const FVector WorldTargetVelocity = GetActorRotation().RotateVector(TargetVelocity);

		Character->GetP3CharacterMovementBP()->AddWindForce(WorldTargetVelocity, Strength, *this);
	}
}

void AP3ThermalVolumeActor::NotifyActorEndOverlap(AActor* OtherActor)
{
	Super::NotifyActorEndOverlap(OtherActor);

	if (!Net_bThermalActive)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(OtherActor);
	if (Character && Character->GetP3CharacterMovementBP())
	{
		const FVector WorldTargetVelocity = GetActorRotation().RotateVector(TargetVelocity);

		Character->GetP3CharacterMovementBP()->RemoveWindForce(*this);
	}
}

void AP3ThermalVolumeActor::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	const bool bOldActive = Net_bThermalActive;

	Archive << Net_bThermalActive;

	if (Archive.IsLoading())
	{
		if (bOldActive != Net_bThermalActive)
		{
			ThermalActiveChanged();
		}
	}
}

void AP3ThermalVolumeActor::Server_SetThermalActive(bool bInActive)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_bThermalActive == bInActive)
	{
		return;
	}

	Net_bThermalActive = bInActive;

	Server_MulticastEvent(NAME_ThermalActivateChanged, bInActive ? 1 : 0);
}

void AP3ThermalVolumeActor::ThermalActiveChanged()
{
	if (Net_bThermalActive)
	{
		TArray<AActor*> OverlappedActors;
		GetOverlappingActors(OverlappedActors, AP3Character::StaticClass());

		const FVector WorldTargetVelocity = GetActorRotation().RotateVector(TargetVelocity);

		for (AActor* Actor : OverlappedActors)
		{
			AP3Character* Character = Cast<AP3Character>(Actor);

			if (Character && Character->GetP3CharacterMovementBP())
			{
				Character->GetP3CharacterMovementBP()->AddWindForce(WorldTargetVelocity, Strength, *this);
			}
		}
	}
	else
	{
		TArray<AActor*> OverlappedActors;
		GetOverlappingActors(OverlappedActors, AP3Character::StaticClass());

		for (AActor* Actor : OverlappedActors)
		{
			AP3Character* Character = Cast<AP3Character>(Actor);

			if (Character && Character->GetP3CharacterMovementBP())
			{
				Character->GetP3CharacterMovementBP()->RemoveWindForce(*this);
			}
		}
	}

	ReceiveThermalActivateChanged(Net_bThermalActive);
}
