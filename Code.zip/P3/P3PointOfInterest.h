// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "P3PointOfInterest.generated.h"

UCLASS()
class P3_API AP3PointOfInterest : public AActor
{
	GENERATED_BODY()

public:
	AP3PointOfInterest();

	void SetOriginLocation(const FVector& Location);

	UFUNCTION(BlueprintPure)
	const FVector& GetOriginLocation() const;

	float GetSpawnTimeSeconds() const { return SpawnTimeSeconds; }

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	FVector OriginLocation = FVector::ZeroVector;

	UPROPERTY(Transient)
	class UBillboardComponent* EditorSprite;

	float SpawnTimeSeconds = 0;
};
