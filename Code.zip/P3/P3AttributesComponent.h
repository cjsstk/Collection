// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3AttributesComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3AttributeCompOnUpdateAttributes);

UENUM(BlueprintType)
enum class EP3Attribute : uint8
{
	Invalid = 0 UMETA(Hidden),

	MaxHealth,
	PhysicalAttack,
	ArmorClass,

	End UMETA(Hidden)
};
static const int32 P3AttributeStart = 1;
static const int32 P3AttributeEnd = StaticCast<int32>(EP3Attribute::End);

UENUM(BlueprintType)
enum class EP3AttributeOperator : uint8
{
	Add,
	Multiply,
};

USTRUCT(BlueprintType)
struct FP3AttributeModifier
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	EP3Attribute Attribute;

	UPROPERTY(EditAnywhere)
	EP3AttributeOperator Operator;

	/** If the operator is 'Multiply', then the unit of value is permil (1/1000) */
	UPROPERTY(EditAnywhere)
	int32 Value;
};

UCLASS(Blueprintable, meta = (BlueprintSpawnableComponent))
class P3_API UP3AttributesComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3AttributesComponent();

	UFUNCTION(BlueprintCallable, meta = (CompactNodeTitle = "Level"))
	int32 GetLevel() const;

	UFUNCTION(BlueprintCallable, meta = (CompactNodeTitle = "Attribute"))
	int32 GetAttribute(EP3Attribute Attribute) const;

	UFUNCTION(BlueprintCallable)
	void UpdateAttributes();

	UFUNCTION(BlueprintCallable)
	void Test_SetLevelBP(int32 NewLevel);

	void SetLevel(int32 NewLevel);

	FP3AttributeCompOnUpdateAttributes OnUpdateAttributes;

protected:
	virtual void BeginPlay() override;

	UFUNCTION(BlueprintImplementableEvent)
	int32 CalcBase(EP3Attribute Attribute);

	void ApplyModifier(const FP3AttributeModifier& Modifier);

private:
	int32 Level;

	UPROPERTY(EditAnywhere)
	TArray<FP3AttributeModifier> Modifiers;

	UPROPERTY(Transient)
	TArray<int32> Attributes;
};
