// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#define P3_BUILD_WITH_TEST WITH_EDITOR && !PLATFORM_LINUX

// To test in command line. Use following parameters.
// "C:\work\p3\game\P3.uproject" Empty -Game -ExecCmds="Automation RunTests P3" -debug -log -resx=640 -resy=480 -windowed -unattended -nopause -testexit="Automation Test Queue Empty" -nosplash
// After testing, open game log file and search "AutomationTestingLog"

#if P3_BUILD_WITH_TEST

#include "NUTUtil.h"
#define P3_ARG_WITH_COMMAS(...) __VA_ARGS__

#define P3_ASSERT_TRUE(Actual) \
	if (!ensure(Actual)) \
	{ \
		AddError(FString::Printf(TEXT("Expected '%s' to be true, but it was not."), TEXT(#Actual)), 0); \
		return false; \
	}

#define P3_ASSERT_FALSE(Actual) \
	if (!ensure(!Actual)) \
	{ \
		AddError(FString::Printf(TEXT("Expected '%s' to be false, but it was not."), TEXT(#Actual)), 0); \
		return false; \
	}

#define P3_ASSERT_EQUAL(Actual, Expected) \
	if (!ensure((Actual) == (Expected))) \
	{ \
		AddError(FString::Printf(TEXT("Expected '%s' to be %d, but it was %d."), TEXT(#Actual), Expected, Actual), 0); \
		return false; \
	}

#define P3_ASSERT_EQUAL_STR(Actual, Expected) \
	if (!ensure((Actual) == (Expected))) \
	{ \
		AddError(FString::Printf(TEXT("Expected '%s' to be '%s', but it was '%s'."), TEXT(#Actual), *Expected, *Actual), 0); \
		return false; \
	}

#define P3_ASSERT_EQUAL_TARRAY(Actual, Expected) \
	if (!ensure((Actual) == (Expected))) \
	{ \
		AddError(FString::Printf(TEXT("Unexpected value for '%s'"), TEXT(#Actual)), 0); \
		return false; \
	}

#define P3_ASSERT_EQUAL_MEMORY(Actual, Expected, Size) \
	if (!ensure(FMemory::Memcmp((Actual), (Expected), (Size)) == 0)) \
	{ \
		AddError(FString::Printf(TEXT("Unexpected value for '%s'"), TEXT(#Actual)), 0); \
		return false; \
	}

#endif // P3_BUILD_WITH_TEST
