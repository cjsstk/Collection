// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3OverlapComponent.h"
#include "P3PortalComponent.generated.h"

/**
 * Teleport character to target location
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3PortalComponent : public UP3OverlapComponent
{
	GENERATED_BODY()
	
protected:
	virtual void Server_OverlappedActorAdded(AActor& Actor) override;

private:
	UPROPERTY(EditAnywhere, Category = Portal)
	AActor* TargetActor;
};
