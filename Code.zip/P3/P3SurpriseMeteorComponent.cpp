// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3SurpriseMeteorComponent.h"

#include "Engine/World.h"

#include "P3Character.h"

static TAutoConsoleVariable<int32> CVarP3SurpriseMeteorDebug(
	TEXT("p3.surpriseMeteorDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

UP3SurpriseMeteorComponent::UP3SurpriseMeteorComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3SurpriseMeteorComponent::BeginPlay()
{
	Super::BeginPlay();

	Server_LeftCoolDownTimeSeconds = GetNewCoolDown();
}

void UP3SurpriseMeteorComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_TickSpawnMeteor(DeltaTime);

		if (CVarP3SurpriseMeteorDebug.GetValueOnGameThread() > 0)
		{
			AP3Character* Character = Cast<AP3Character>(GetOwner());
			if (Character)
			{
				Character->AddDebugString(FString::Printf(TEXT("LeftCoolDown: %f"), Server_LeftCoolDownTimeSeconds));
			}
		}
	}
}

void UP3SurpriseMeteorComponent::Server_TickSpawnMeteor(float DeltaTime)
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	if (Character->IsDead() || Character->GetStance() != EP3CharacterStance::Combat)
	{
		return;
	}

	Server_LeftCoolDownTimeSeconds -= DeltaTime;

	if (Server_LeftCoolDownTimeSeconds <= 0.0f)
	{
		Server_LeftCoolDownTimeSeconds = GetNewCoolDown();

		if (CanSpawnMeteor())
		{
			FActorSpawnParameters SpawnParams;
			SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
			SpawnParams.Instigator = Cast<APawn>(GetOwner());
			GetWorld()->SpawnActor<AActor>(MeteorSpawnerClass.Get(), GetOwner()->GetActorLocation(), FRotator::ZeroRotator, SpawnParams);
		}
	}
}

bool UP3SurpriseMeteorComponent::CanSpawnMeteor() const
{
	// See if gameplaytag is required
	if (RequiredGameplayTagsAny.Num() > 0 || DisableGameplaytagsAny.Num() > 0)
	{
		IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(GetOwner());
		if (GameplayTagAsset)
		{
			const bool bHasRequiredTags = (RequiredGameplayTagsAny.Num() == 0)
				|| GameplayTagAsset->HasAnyMatchingGameplayTags(RequiredGameplayTagsAny);

			if (!bHasRequiredTags)
			{
				return false;
			}

			const bool bHasDisableTags = (DisableGameplaytagsAny.Num() != 0)
				&& GameplayTagAsset->HasAnyMatchingGameplayTags(DisableGameplaytagsAny);

			if (bHasDisableTags)
			{
				return false;
			}
		}
	}

	if (SpawnMeteorPercent >= FMath::RandRange(0.0f, 100.0f))
	{
		return true;
	}

	return false;
}

float UP3SurpriseMeteorComponent::GetNewCoolDown() const
{
	return FMath::Max(0.001f, FMath::RandRange(MinMeteorCoolDown, MaxMeteorCoolDown));
}

