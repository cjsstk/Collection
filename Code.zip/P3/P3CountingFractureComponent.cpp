// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CountingFractureComponent.h"

#include "P3Destructible.h"
#include "P3HealthPointComponent.h"

extern TAutoConsoleVariable<int32> CVarP3OverlapDebug;


UP3CountingFractureComponent::UP3CountingFractureComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
	PrimaryComponentTick.bStartWithTickEnabled = false;

	bAutoActivate = true;
}

void UP3CountingFractureComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this) && CVarP3OverlapDebug.GetValueOnGameThread() > 0)
	{
		AP3Destructible* OwnerActor = Cast<AP3Destructible>(GetOwner());
		if (!ensure(OwnerActor))
		{
			return;
		}

		OwnerActor->AddDebugString(FString::Printf(TEXT("OverlapCount: %d"), Server_OverlapCount));
	}
}

void UP3CountingFractureComponent::Server_OverlappedActorAdded(AActor& Actor)
{
	Super::Server_OverlappedActorAdded(Actor);

	Server_OverlapCount++;

	if (Server_OverlapCount == OverlapCountToDestroy)
	{
		Server_Fracture();
	}
}

void UP3CountingFractureComponent::Server_Fracture()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Destructible* OwnerActor = Cast<AP3Destructible>(GetOwner());
	if (!ensure(OwnerActor))
	{
		return;
	}

	OwnerActor->Server_Fracture();
}
