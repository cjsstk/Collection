// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PortalComponent.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3Log.h"

void UP3PortalComponent::Server_OverlappedActorAdded(AActor& Actor)
{
	Super::Server_OverlappedActorAdded(Actor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!TargetActor)
	{
		P3JsonLog(Error, "Portal failed. No Target actor", TEXT("PortalName"), GetOwner() ? GetOwner()->GetName() : TEXT("NULL"));
		return;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (Character && ensure(Character->GetCommandComponent()))
	{
		FP3CommandRequestParams Params;
		Params.Teleport_Location = TargetActor->GetActorLocation();
		Params.Teleport_Rotation = TargetActor->GetActorRotation();

		Character->GetCommandComponent()->RequestCommand(UP3TeleportCommand::StaticClass(), Params);
	}
}
