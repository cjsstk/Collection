// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3OverlapComponent.h"
#include "P3Faction.h"
#include "P3BuffTriggerComponent.generated.h"

UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3BuffTriggerComponent : public UP3OverlapComponent
{
	GENERATED_BODY()

public:
	UP3BuffTriggerComponent(){}

protected:
	virtual void Server_OverlappedActorAdded(AActor& Actor) override;

private:
	/** If true, Only Instigator is overlapped */
	UPROPERTY(EditDefaultsOnly, Category = Effect)
	bool bOnlyInstigator = true;

	UPROPERTY(EditDefaultsOnly, Category = Effect)
	int32 CmsBuffKey = 0;

	/** If set, any character that has this faction will trigger switch */
	UPROPERTY(EditAnywhere, Category = Effect)
	TSet<EP3Faction> TriggerFactions;
};
