// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3RagdollComponent.generated.h"


UCLASS()
class P3_API UP3RagdollComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3RagdollComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void Ragdollize();
	void Unragdollize();

	bool IsRagdollized() const { return bRagollized; }

private:
	void TickMoveCapsuleDuringRagdoll();
	void TickUnragdollizing(float DeltaSeconds);

	class ACharacter* GetOwnerCharacter() const;

	bool bRagollized = false;

	/** Remember mesh relative transform to capsule so that we can restore */
	FTransform RagdollMeshTransform = FTransform::Identity;

	/** Restoring from ragdoll */
	bool bUnragollizing = false;
	float UnragdollizeAge = 0;
	FTransform UnragdollizeStartTransform = FTransform::Identity;
};
