// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Core.h"

#include "Animation/AnimMontage.h"
#include "Animation/AnimSequence.h"
#include "Animation/WidgetAnimation.h"
#include "Blueprint/UserWidget.h"
#include "Blueprint/WidgetBlueprintGeneratedClass.h"
#include "Components/PrimitiveComponent.h"
#include "Engine/LocalPlayer.h"
#include "Engine/ObjectLibrary.h"
#include "GameFramework/Actor.h"

#include "Network/P3DediNet.h"
#include "Network/P3UDPENetClient.h"
#include "Network/P3UnrealUDPNet.h"
#include "P3GameInstance.h"
#include "P3GameMode.h"
#include "P3GameState.h"
#include "P3PlayerController.h"
#include "P3World.h"
#include "World/P3WorldSystem.h"

extern TAutoConsoleVariable<int32> CVarP3CharacterMovementServerDriven;

bool IsLocalControlledActor(AActor* Actor)
{
	//return Actor && (Actor->Role == ROLE_AutonomousProxy || (Actor->Role == ROLE_Authority && Actor->GetRemoteRole() != ROLE_AutonomousProxy));

	if (!Actor)
	{
		return false;
	}

	if (IsAutonomousProxy(Actor))
	{
		return true;
	}

	if (CVarP3CharacterMovementServerDriven.GetValueOnAnyThread() == 0)
	{
		if (P3Core::GetLocalPawn(Actor->GetWorld()) == Actor)
		{
			return true;
		}
	}

	if (IsAuthority(Actor))
	{
		if (P3Core::GetLocalPawn(Actor->GetWorld()) == Actor)
		{
			return true;
		}

		if (!P3Core::IsP3NetModeServerInstance(*Actor))
		{
			return true;
		}

		if (Actor->GetRemoteRole() == ROLE_AutonomousProxy)
		{
			return false;
		}

		return true;
	}

	return false;
}

bool IsAutonomousProxy(class AActor* Actor)
{
	if (!Actor)
	{
		return false;
	}

	if (CVarP3CharacterMovementServerDriven.GetValueOnAnyThread() != 0)
	{
		return (Actor->Role == ROLE_AutonomousProxy);
	}

	if (P3Core::IsP3NetModeServerInstance(*Actor))
	{
		return false;
	}

	if (P3Core::GetLocalPawn(Actor->GetWorld()) == Actor)
	{
		return true;
	}

	return false;
}

bool IsAuthority(class AActor* Actor)
{
	if (!Actor)
	{
		return false;
	}

	if (CVarP3CharacterMovementServerDriven.GetValueOnAnyThread() != 0)
	{
		return Actor->Role == ROLE_Authority;
	}

	if (P3Core::IsP3NetModeServerInstance(*Actor))
	{
		return true;
	}

	return false;
}

FP3Silhouetter::~FP3Silhouetter()
{
	if (SilhouettedActor.IsValid())
	{
		TArray<UActorComponent*> PrimComps = SilhouettedActor->GetComponentsByClass(UPrimitiveComponent::StaticClass());
		for (UActorComponent* ActorComp : PrimComps)
		{
			CastChecked<UPrimitiveComponent>(ActorComp)->SetRenderCustomDepth(false);
		}
	}
}

void FP3Silhouetter::SetActor(AActor* Actor)
{
	if (SilhouettedActor.Get() == Actor)
	{
		return;
	}

	TInlineComponentArray<UPrimitiveComponent*> Components;

	if (bEnable)
	{
		if (SilhouettedActor.IsValid())
		{
			SilhouettedActor->GetComponents(Components);

			for (UPrimitiveComponent* Comp : Components)
			{
				Comp->SetRenderCustomDepth(false);

				// TODO: Engine Bug(4.19): You need to recreate render proxy to reset 'EOcclusionFlags::CanBeOccluded'
				Comp->MarkRenderStateDirty();
			}
		}
	}

	SilhouettedActor = Actor;

	if (bEnable)
	{
		if (SilhouettedActor.IsValid())
		{
			SilhouettedActor->GetComponents(Components);

			for (UPrimitiveComponent* Comp : Components)
			{
				Comp->SetRenderCustomDepth(true);

				// TODO: Engine Bug(4.19): You need to recreate render proxy to remove 'EOcclusionFlags::CanBeOccluded'
				Comp->MarkRenderStateDirty();
			}
		}
	}
}

AActor* FP3Silhouetter::GetActor() const
{
	return SilhouettedActor.Get();
}

namespace P3Core
{

bool IsConnectedToDedi(const UObject* Object)
{
	if (!ensure(Object))
	{
		return false;
	}

	UWorld* World = Object->GetWorld();

	if (!ensure(World))
	{
		return false;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		ensure(IsRunningCommandlet());
		return false;
	}

	if (GameInstance->GetDediNet() && GameInstance->GetDediNet()->GetConnStatus() == EP3NetConnStatus::Connected)
	{
		return true;
	}

	if (GameInstance->GetUDPNetwork() && GameInstance->GetUDPNetwork()->Client_IsConnected())
	{
		return true;
	}

	return false;
}

EP3NetMode GetP3NetMode(const class AActor& Actor)
{
	UWorld* World = Actor.GetWorld();
	
	UP3GameInstance* GameInstance = World ? Cast<UP3GameInstance>(World->GetGameInstance()) : nullptr;

	if (GameInstance)
	{
		return GameInstance->GetGameNetMode();
	}

	ensure(IsRunningCommandlet());

	return EP3NetMode::Standalone;
}

EP3NetMode GetP3NetMode(const class UWorld& World)
{
	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World.GetGameInstance());

	if (GameInstance)
	{
		return GameInstance->GetGameNetMode();
	}

	ensure(IsRunningCommandlet() || !World.IsGameWorld());

	return EP3NetMode::Standalone;
}

EP3NetMode GetP3NetMode(const class UWorld* World)
{
	if (!World)
	{
		ensure(0);
		return EP3NetMode::MAX;
	}

	return GetP3NetMode(*World);
}

bool IsP3NetModeStandalone(const class AActor& Actor)
{
	return (GetP3NetMode(Actor) == EP3NetMode::Standalone);
}

bool IsP3NetModeListenServer(const class AActor& Actor)
{
	return (GetP3NetMode(Actor) == EP3NetMode::ListenServer);
}

bool IsP3NetModeDedicatedServer(const class AActor& Actor)
{
	return (GetP3NetMode(Actor) == EP3NetMode::DedicatedServer);
}

bool IsP3NetModeClient(const class AActor& Actor)
{
	return (GetP3NetMode(Actor) == EP3NetMode::Client);
}

bool IsP3NetModeClientInstance(const class UObject& Object)
{
	const EP3NetMode NetMode = GetP3NetMode(Object.GetWorld());

	return ((NetMode == EP3NetMode::Standalone) || (NetMode == EP3NetMode::ListenServer) || (NetMode == EP3NetMode::Client));
}

bool IsP3NetModeServerInstance(const class UObject& Object)
{
	const EP3NetMode NetMode = GetP3NetMode(Object.GetWorld());

	return ((NetMode == EP3NetMode::Standalone) || (NetMode == EP3NetMode::ListenServer) || (NetMode == EP3NetMode::DedicatedServer));
}

const TCHAR* GetNetModeStr(ENetMode Value)
{
	switch (Value)
	{
	case NM_Standalone: return TEXT("Standalone");
	case NM_DedicatedServer: return TEXT("DedicatedServer");
	case NM_ListenServer: return TEXT("ListenServer");
	case NM_Client: return TEXT("Client");
	case NM_MAX: return TEXT("MAX");
	}

	return TEXT("Unknown");
};

const TCHAR* GetNetModeStr(EP3NetMode Value)
{
	switch (Value)
	{
	case EP3NetMode::Standalone: return TEXT("Standalone");
	case EP3NetMode::DedicatedServer: return TEXT("DedicatedServer");
	case EP3NetMode::ListenServer: return TEXT("ListenServer");
	case EP3NetMode::Client: return TEXT("Client");
	case EP3NetMode::MAX: return TEXT("MAX");
	}

	return TEXT("Unknown");
}

EP3NetMode GetNetModeFromStr(const TCHAR* Str)
{
	if (FCString::Stricmp(Str, TEXT("Standalone")) == 0)
	{
		return EP3NetMode::Standalone;
	}
	if (FCString::Stricmp(Str, TEXT("DedicatedServer")) == 0)
	{
		return EP3NetMode::DedicatedServer;
	}
	if (FCString::Stricmp(Str, TEXT("ListenServer")) == 0)
	{
		return EP3NetMode::ListenServer;
	}
	if (FCString::Stricmp(Str, TEXT("Client")) == 0)
	{
		return EP3NetMode::Client;
	}

	return EP3NetMode::MAX;
}

bool GetAllBlueprintNamesInPath(FName Path, TArray<FName>& Result, UClass* BaseClass)
{
	UObjectLibrary* Library = UObjectLibrary::CreateLibrary(BaseClass, true, GIsEditor);

	if (!ensure(Library))
	{
		return false;
	}

	Library->LoadBlueprintAssetDataFromPath(Path.ToString());

	TArray<FAssetData> Assets;
	Library->GetAssetDataList(Assets);

	for (const FAssetData& Asset : Assets)
	{
		Result.Add(Asset.AssetName);
	}

	return true;
}

UClass* GetBlueprintClassInPath(FName Path, FName AssetName, UClass* BaseClass)
{
	UObjectLibrary* Library = UObjectLibrary::CreateLibrary(BaseClass, true, GIsEditor);

	if (!ensure(Library))
	{
		return nullptr;
	}

	Library->LoadBlueprintAssetDataFromPath(Path.ToString());

	TArray<FAssetData> Assets;
	Library->GetAssetDataList(Assets);

	FAssetData* Asset = Assets.FindByPredicate([AssetName](const FAssetData& Asset) { return Asset.AssetName == AssetName; });

	if (!Asset)
	{
		return nullptr;
	}

	UBlueprint* Blueprint = Cast<UBlueprint>(Asset->GetAsset());

	if (Blueprint)
	{
		return Blueprint->GeneratedClass;
	}

	FString GeneratedClassName = (Asset->AssetName.ToString() + "_C");
	UClass* Class = FindObject<UClass>(Asset->GetPackage(), *GeneratedClassName);

	if (Class)
	{
		return Class;
	}

	UObjectRedirector* RenamedClassRedirector = FindObject<UObjectRedirector>(Asset->GetPackage(), *GeneratedClassName);

	if (RenamedClassRedirector)
	{
		return Cast<UClass>(RenamedClassRedirector->DestinationObject);
	}

	return nullptr;
}

UWidgetAnimation* GetWidgetAnimation(const UUserWidget& Widget, FName AnimName)
{
	UWidgetBlueprintGeneratedClass* BGClass = Cast<UWidgetBlueprintGeneratedClass>(Widget.GetClass());

	if (!ensure(BGClass))
	{
		return nullptr;
	}

	for (UWidgetAnimation* Anim : BGClass->Animations)
	{
		if (Anim->GetMovieScene() && Anim->GetMovieScene()->GetFName() == AnimName)
		{
			return Anim;
		}
	}

	return nullptr;
}

class UP3GameInstance* GetP3GameInstance(const UObject& Object)
{
	if (!ensure(Object.GetWorld()))
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Object.GetWorld()->GetGameInstance<UP3GameInstance>();

	return GameInstance;
}

UP3GameInstance* GetP3GameInstanceChecked(const UObject& Object)
{
	UP3GameInstance* GameInstance = GetP3GameInstance(Object);
	check(GameInstance);

	return GameInstance;
}

AP3GameMode* GetP3GameMode(const UObject& Object)
{
	if (!ensure(Object.GetWorld()))
	{
		return nullptr;
	}

	return Cast<AP3GameMode>(Object.GetWorld()->GetAuthGameMode());
}

AP3GameState* GetP3GameState(const UObject& Object)
{
	if (!ensure(Object.GetWorld()))
	{
		return nullptr;
	}

	AGameModeBase* GameMode = Object.GetWorld()->GetAuthGameMode();

	return GameMode ? GameMode->GetGameState<AP3GameState>() : nullptr;
}

AP3ContributionSystem* GetContributionSystem(const UObject& Object)
{
	AP3WorldSystem* WorldSystem = GetP3WorldSystem(Object);

	if (!WorldSystem)
	{
		return nullptr;
	}

	return WorldSystem->GetContributionSystem();
}

const UP3GameRule& GetGameRule(const UObject& Object)
{
	AP3GameState* GameState = GetP3GameState(Object);

	if (!GameState)
	{
		return *Cast<UP3GameRule>(UP3GameRule::StaticClass()->ClassDefaultObject);
	}

	return GameState->GetGameRule();
}

class APawn* GetLocalPawn(class UWorld* World)
{
	if (!ensure(World))
	{
		return nullptr;
	}

	ULocalPlayer* LocalPlayer = World->GetFirstLocalPlayerFromController();

	if (!LocalPlayer)
	{
		return nullptr;
	}

	APlayerController* PlayerController = LocalPlayer->GetPlayerController(World);

	if (!PlayerController)
	{
		return nullptr;
	}

	return PlayerController->GetPawn();
}

const UP3GameResource& GetGameResource(UObject* Object)
{
	if (!Object || !Object->GetWorld())
	{
		ensure(0);
		return *Cast<UP3GameResource>(UP3GameResource::StaticClass()->ClassDefaultObject);
	}

	AP3GameState* GameState = Cast<AP3GameState>(Object->GetWorld()->GetGameState());

	if (GameState && GameState->GetGameResource())
	{
		return *GameState->GetGameResource();
	}

	ensure(0);
	return *Cast<UP3GameResource>(UP3GameResource::StaticClass()->ClassDefaultObject);
}

UP3ItemManager* GetItemManager(const UObject& Object)
{
	if (!ensure(Object.GetWorld()))
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Object.GetWorld()->GetGameInstance<UP3GameInstance>();

	if (ensure(GameInstance))
	{
		return GameInstance->GetItemManager();
	}

	return nullptr;
}

UP3World* GetP3World(const UObject& Object)
{
	if (!ensure(Object.GetWorld()))
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Object.GetWorld()->GetGameInstance<UP3GameInstance>();

	if (ensure(GameInstance))
	{
		return GameInstance->GetP3World();
	}

	return nullptr;
}

UP3ServerWorld* GetP3ServerWorld(const UObject& Object)
{
	UP3World* P3World = GetP3World(Object);
	UP3ServerWorld* P3ServerWorld = P3World ? P3World->GetServerWorld() : nullptr;

	return P3ServerWorld;
}

UP3ClientWorld* GetP3ClientWorld(const UObject& Object)
{
	if (!IsP3NetModeClientInstance(Object))
	{
		return nullptr;
	}

	UP3World* P3World = GetP3World(Object);
	UP3ClientWorld* P3ClientWorld = P3World ? P3World->GetClientWorld() : nullptr;
	return P3ClientWorld;
}

AP3WorldSystem* GetP3WorldSystem(const UObject& Object)
{
	UP3World* P3World = GetP3World(Object);

	if (!P3World)
	{
		return nullptr;
	}

	return P3World->GetWorldSystem();
}

class AP3PlayerController* GetP3PlayerController(const UObject& Object)
{
	UWorld* World = Object.GetWorld();

	if (World)
	{
		AP3PlayerController* PlayerController = Cast<AP3PlayerController>(World->GetFirstPlayerController());

		return PlayerController;
	}

	return nullptr;
}

class AActor* GetP3WorldParticleActor(UObject* Object)
{
	if (!ensure(Object) || !ensure(Object->GetWorld()))
	{
		return nullptr;
	}

	AP3GameState* GameState = Cast<AP3GameState>(Object->GetWorld()->GetGameState());
	if (!GameState)
	{
		return nullptr;
	}

	return GameState->GetWorldParticleActor();
}

AActor* FindActorByName(UWorld* World, const FString& LevelName, const FString& ActorName)
{
	if (!ensure(World))
	{
		return nullptr;
	}

	ULevel* FoundLevel = nullptr;

	for (ULevel* Level : World->GetLevels())
	{
		if (Level->GetOuter()->GetName() == LevelName)
		{
			FoundLevel = Level;
			break;
		}
	}

	if (!ensure(FoundLevel))
	{
		return nullptr;
	}

	AActor** FoundActorPtr = FoundLevel->Actors.FindByPredicate([&ActorName](const AActor* LevelActor) {
		return (LevelActor && LevelActor->GetName() == ActorName);
	});

	if (FoundActorPtr)
	{
		return *FoundActorPtr;
	}

	return nullptr;
}

void GetChildComponentOverlappingActors(const class USceneComponent* SceneComponent, TSet<AActor*>& OutOverlappingActors)
{
	if (!SceneComponent)
	{
		return;
	}

	TArray<USceneComponent*> ChildComponents;
	SceneComponent->GetChildrenComponents(true, ChildComponents);

	for (USceneComponent* ChildComp : ChildComponents)
	{
		UPrimitiveComponent* ChildPrimComp = Cast<UPrimitiveComponent>(ChildComp);
		if (!ChildPrimComp)
		{
			continue;
		}

		TSet<AActor*> OverlappingActors;
		ChildPrimComp->GetOverlappingActors(OverlappingActors);

		OutOverlappingActors.Append(OverlappingActors);
	}
}

void GetChildComponentOverlappingComponents(const class USceneComponent* SceneComponent, TSet<UPrimitiveComponent*>& OutOverlappingComponents)
{
	if (!SceneComponent)
	{
		return;
	}

	TArray<USceneComponent*> ChildComponents;
	SceneComponent->GetChildrenComponents(true, ChildComponents);

	for (USceneComponent* ChildComp : ChildComponents)
	{
		UPrimitiveComponent* ChildPrimComp = Cast<UPrimitiveComponent>(ChildComp);
		if (!ChildPrimComp)
		{
			continue;
		}

		TSet<UPrimitiveComponent*> OverlappingComponents;
		ChildPrimComp->GetOverlappingComponents(OverlappingComponents);

		OutOverlappingComponents.Append(OverlappingComponents);
	}
}

void GetComponentOverlappingComponents(const class USceneComponent* SceneComponent, TSet<UPrimitiveComponent*>& OutOverlappingComponents, bool bSearchChild)
{
	const UPrimitiveComponent* PrimComponent = Cast<UPrimitiveComponent>(SceneComponent);

	if (PrimComponent)
	{
		PrimComponent->GetOverlappingComponents(OutOverlappingComponents);
	}

	if (bSearchChild)
	{
		TSet<UPrimitiveComponent*> ChildOverlappingComponents;
		GetChildComponentOverlappingComponents(SceneComponent, ChildOverlappingComponents);

		OutOverlappingComponents.Append(ChildOverlappingComponents);
	}
}

AActor* GetAttachRootActor(AActor* Actor, bool bIncludeSelf)
{
	if (!Actor)
	{
		return nullptr;
	}

	USceneComponent* ParentSceneComp = Actor->GetRootComponent() ? Actor->GetRootComponent()->GetAttachParent() : nullptr;

	if (!ParentSceneComp)
	{
		if (bIncludeSelf)
		{
			return Actor;
		}
		else
		{
			return nullptr;
		}
	}

	int32 NumLoop = 0;

	while (1)
	{
		if (ParentSceneComp->GetAttachParent())
		{
			ParentSceneComp = ParentSceneComp->GetAttachParent();
		}
		else
		{
			return ParentSceneComp->GetOwner();
		}

		if (++NumLoop > 1024)
		{
			ensure(0);
			break;
		}
	}

	checkNoEntry();

	return nullptr;
}

void MergeBoundingSpheres(const FVector& Center1, float Radius1, const FVector& Center2, float Radius2, FVector& OutCenter, float& OutRadius)
{
	const FVector Center1To2 = Center2 - Center1;

	if (Center1To2.IsNearlyZero())
	{
		// They are at same location, just return larger one
		OutCenter = Center1;
		OutRadius = FMath::Max(Radius1, Radius2);
		return;
	}

	const FVector Center1To2Dir = Center1To2.GetSafeNormal();

	const FVector Edge1 = Center1 - (Center1To2Dir * Radius1);
	const FVector Edge2 = Center2 - (Center1To2Dir * Radius2);

	OutCenter = (Edge1 + Edge2) * 0.5f;
	OutRadius = (Edge1 - OutCenter).Size();
}

void GetActorSphereBounds(const AActor& Actor, FVector& OutCenter, float& OutRadius, bool bNonColliding)
{
	bool bFirst = true;

	for (const UActorComponent* ActorComponent : Actor.GetComponents())
	{
		const UPrimitiveComponent* PrimComp = Cast<const UPrimitiveComponent>(ActorComponent);
		if (PrimComp)
		{
			if (PrimComp->IsRegistered() && (bNonColliding || PrimComp->IsCollisionEnabled()))
			{
				if (bFirst)
				{
					OutCenter = PrimComp->Bounds.GetSphere().Center;
					OutRadius = PrimComp->Bounds.GetSphere().W;

					bFirst = false;
				}
				else
				{
					const FVector OldCenter = OutCenter;
					const float OldRadius = OutRadius;
					MergeBoundingSpheres(OldCenter, OldRadius, PrimComp->Bounds.GetSphere().Center, PrimComp->Bounds.GetSphere().W, OutCenter, OutRadius);
				}
			}
		}
	}
}

float GetYawBetweenVectors(const FVector& VectorA, const FVector& VectorB)
{
	FVector2D A(VectorA.X, VectorA.Y);
	FVector2D B(VectorB.X, VectorB.Y);

	const float Yaw = FMath::Atan2((A ^ B), (A | B));

	return Yaw;
}

FTransform ExtractMontageBoneTransformFromPosition(USkeletalMeshComponent& MeshComponent, const UAnimMontage& Montage, float Position, const FName& BoneName)
{
	// Reference: https://forums.unrealengine.com/development-discussion/c-gameplay-programming/27146-how-to-get-a-bone-location-for-the-first-frame-of-an-animmontage

	if (!ensure(MeshComponent.SkeletalMesh))
	{
		return FTransform::Identity;
	}

	const int32 SectionIndex = Montage.GetSectionIndexFromPosition(Position);

	if (!ensure(Montage.IsValidSectionIndex(SectionIndex)))
	{
		return FTransform::Identity;
	}
	
	float SectionStartTime, SectionEndTime;
	Montage.GetSectionStartAndEndTime(SectionIndex, SectionStartTime, SectionEndTime);

	// TODO: GetAnimCompositeSection 와 GetLinkedSequence 가 const 가 아니라서 const_cast 를 임시로 사용
	FCompositeSection& Section = const_cast<UAnimMontage&>(Montage).GetAnimCompositeSection(SectionIndex);
	const UAnimSequence* Sequence = Cast<UAnimSequence>(Section.GetLinkedSequence());

	if (!ensure(Sequence) || !ensure(Sequence->GetSkeleton()))
	{
		return FTransform::Identity;
	}

	USkeleton* Skeleton = Sequence->GetSkeleton();
	int32 BoneIndex = MeshComponent.GetBoneIndex(BoneName);

	FTransform OutTransform = FTransform::Identity;

	while (BoneIndex != INDEX_NONE)
	{
		const int32 ParentBoneIndex = MeshComponent.SkeletalMesh->RefSkeleton.GetParentIndex(BoneIndex);
		const int32 BoneTreeIndex = Skeleton->GetSkeletonBoneIndexFromMeshBoneIndex(MeshComponent.SkeletalMesh, BoneIndex);
		const int32 TrackIndex = Skeleton->GetRawAnimationTrackIndex(BoneTreeIndex, Sequence);

		float SectionPosition = Position - SectionStartTime;
		if (ParentBoneIndex == INDEX_NONE)
		{
			// Root Bone 의 경우, Root Motion 을 무시하기 위해 0초 지점을 가져와야 함
			SectionPosition = 0;
		}

		FTransform BoneTransform = FTransform::Identity;
		Sequence->GetBoneTransform(BoneTransform, TrackIndex, SectionPosition, true);

		OutTransform *= BoneTransform;

		if (ParentBoneIndex == INDEX_NONE)
		{
			// root reached
			break;
		}

		BoneIndex = ParentBoneIndex;
	}

	return OutTransform;
}

void Client_ToastMessageBP(const UWorld* World, const FText& Message)
{
	if (!World)
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(World->GetFirstPlayerController());
	if (!ensure(PlayerController))
	{
		return;
	}

	PlayerController->ToastMessageBP(Message);	
}

} // P3Core

FP3ActorPointerAndId& FP3ActorPointerAndId::operator=(AActor* InActor)
{
	if (InActor)
	{
		Actor = InActor;
		UpdateIdFromPointer(*Actor);
	}
	else
	{
		Actor = nullptr;
		ActorId = INVALID_ACTORID;
	}

	return *this;
}

void FP3ActorPointerAndId::UpdateIdFromPointer(const UObject& WorldContextObject)
{
	UP3World* World = P3Core::GetP3World(WorldContextObject);

	if (World)
	{
		ActorId = World->GetActorIdFromActor(Actor);
	}
	else
	{
		ActorId = INVALID_ACTORID;
	}
}

void FP3ActorPointerAndId::UpdatePointerFromId(const UObject& WorldContextObject)
{
	UP3World* P3World = P3Core::GetP3World(WorldContextObject);

	if (P3World)
	{
		Actor = P3World->GetActorFromActorId(ActorId);
	}
	else
	{
		Actor = nullptr;
	}
}

bool FP3ActorPointerAndId::IsValidIdOrReplicated() const
{
	return (ActorId != INVALID_ACTORID || (Actor && Actor->GetIsReplicated()));
}

bool FP3ActorPointerAndId::IsValidId() const
{
	return ActorId != INVALID_ACTORID;
}

