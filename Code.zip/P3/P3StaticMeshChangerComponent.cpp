// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3StaticMeshChangerComponent.h"

#include "P3OverlapComponent.h"
#include "P3World.h"

UP3StaticMeshChangerComponent::UP3StaticMeshChangerComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UP3StaticMeshChangerComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AActor* OwnerActor = GetOwner();
		if (!OwnerActor)
		{
			return;
		}

		UP3OverlapComponent* OverlapComp = OwnerActor->FindComponentByClass<UP3OverlapComponent>();
		if (OverlapComp)
		{
			OverlapComp->Server_OnOverlappedActorAdded.AddUniqueDynamic(this, &UP3StaticMeshChangerComponent::Server_OnActorOverlapped);
		}
	}
	
}

void UP3StaticMeshChangerComponent::ChangeStaticMesh()
{
	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	UStaticMeshComponent* StaticMeshComp = OwnerActor->FindComponentByClass<UStaticMeshComponent>();
	if (!ensure(StaticMeshComp))
	{
		return;
	}

	if (ChangeParticle)
	{
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), ChangeParticle, GetComponentTransform());
	}

	StaticMeshComp->SetStaticMesh(NewStaticMesh);
}

void UP3StaticMeshChangerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

}

void UP3StaticMeshChangerComponent::Server_OnActorOverlapped(AActor* Actor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_bChanged)
	{
		return;
	}

	if (!NewStaticMesh)
	{
		return;
	}

	Net_bChanged = true;

	ChangeStaticMesh();

	Server_SetDirty(*this);
}

void UP3StaticMeshChangerComponent::NetSerialize(FArchive& Archive)
{
	if (!Archive.IsLoading())
	{
		Archive << Net_bChanged;
	}
	else
	{
		bool NewbChanged;

		Archive << NewbChanged;

		if (NewbChanged != Net_bChanged)
		{
			ChangeStaticMesh();
		}
	}
}

