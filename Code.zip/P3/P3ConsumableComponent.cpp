// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ConsumableComponent.h"

UP3ConsumableComponent::UP3ConsumableComponent()
{
}

void UP3ConsumableComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3ConsumableComponent::Server_SetInteractionLock(class UP3PickupConsumablePawnAction* InLockerAction, bool bInInteractionLocked)
{
	/** Try to Lock this Component */
	if (bInInteractionLocked)
	{
		if (Server_IsInteractionLocked() || LockerAction)
		{
			ensure(0);
			return;
		}
		LockerAction = InLockerAction;
	}
	/** Try to Unlock this Component */
	else
	{
		if (!Server_IsInteractionLocked() || !LockerAction || LockerAction != InLockerAction)
		{
			ensure(0);
			return;
		}
		LockerAction = nullptr;
	}

	Server_bIsInteractionLocked = bInInteractionLocked;
}