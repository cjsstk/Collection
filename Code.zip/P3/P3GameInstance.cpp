// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3GameInstance.h"

#include "Engine/LevelStreaming.h"
#include "Framework/Application/SlateApplication.h"
#include "Misc/Paths.h"
#include "Tickable.h"

#include "Item/P3ItemManager.h"
#include "P3.h"
#include "P3Cms.h"
#include "P3ConfigLoader.h"
#include "P3Input.h"
#include "P3Log.h"
#include "P3PlatformMisc.h"
#include "P3World.h"
#include "Network/Lib/P3Net.h"
#include "Network/P3AuthNet.h"
#include "Network/P3ChatNet.h"
#include "Network/P3GoChatNet.h"
#include "Network/P3DediNet.h"
#include "Network/P3DedimanHelper.h"
#include "Network/P3GameWorldNet.h"
#include "Network/P3PlayerNet.h"
#include "Network/P3UDPNetwork.h"
#include "Network/P3UnrealUDPNet.h"
#include "Network/P3WorldNet.h"
#include "Network/P3UDPENetServer.h"
#include "Network/P3UDPENetClient.h"

#if WITH_EDITOR
#include "Editor/EditorEngine.h"
#include "Settings/LevelEditorPlaySettings.h"
extern UNREALED_API UEditorEngine* GEditor;
#endif

static TAutoConsoleVariable<int32> CVarP3EnableWorldNet(
	TEXT("p3.enableWorldNet"),
	0,
	TEXT("Enable world server connection"), ECVF_Default);

static TAutoConsoleVariable<FString> CVarP3FakeAuthToken(
	TEXT("p3.fakeAuthToken"),
	TEXT("1"),
	TEXT("Test token for test"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3FakeCharId(
	TEXT("p3.fakeCharId"),
	0,
	TEXT("Test character id for test"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3NetTCP(
	TEXT("p3.netTCP"),
	1,
	TEXT("Enable TCP Network Protocol"), ECVF_Default);

static TAutoConsoleVariable<FString> CVarP3NetUDP(
	TEXT("p3.netUDP"),
	"",
	TEXT("Enable UDP Network Protocol"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3UseGoChat(
	TEXT("p3.useGoChat"),
	0,
	TEXT("Enable Golang Chat network"), ECVF_Default);


//////////////////////////////////////////////////////////////////////////
// FP3NetTick
//////////////////////////////////////////////////////////////////////////

class FP3NetTick : FTickableGameObject
{
public:
	explicit FP3NetTick(UP3Net* InNet, UP3DediNet* InDediNet, UP3PlayerNet* InPlayerNet, UP3WorldNetBase* InWorldNet, UP3WebServer* InWebServer, UP3UDPNetwork* InUDPNetwork)
		: FTickableGameObject()
		, Net(InNet)
		, DediNet(InDediNet)
		, PlayerNet(InPlayerNet)
		, WorldNet(InWorldNet)
		, WebServer(InWebServer)
		, UDPNetwork(InUDPNetwork)
	{}

	virtual void Tick(float DeltaTime) override
	{
		Net->Tick(DeltaTime);

		if (DediNet)
		{
			DediNet->Tick(DeltaTime);
		}

		if (PlayerNet)
		{
			PlayerNet->Tick(DeltaTime);
		}

		if (WorldNet)
		{
			WorldNet->Tick(DeltaTime);
		}

		if (UDPNetwork)
		{
			UDPNetwork->Tick(DeltaTime);
		}

		if (WebServer)
		{
			WebServer->Tick(DeltaTime);
		}
	}

	virtual bool IsTickable() const override
	{
		return true;
	}

	virtual bool IsTickableWhenPaused() const override
	{
		return true;
	}

	virtual bool IsTickableInEditor() const override
	{
		return false;
	}

	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FP3NetTick, STATGROUP_Tickables);
	}

private:
	UP3Net* Net = nullptr;
	UP3DediNet* DediNet = nullptr;
	UP3PlayerNet* PlayerNet = nullptr;
	UP3WorldNetBase* WorldNet = nullptr;
	UP3WebServer* WebServer = nullptr;
	UP3UDPNetwork* UDPNetwork = nullptr;
};

UP3GameInstance::UP3GameInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

#if WITH_EDITOR

FGameInstancePIEResult UP3GameInstance::InitializeForPlayInEditor(int32 PIEInstanceIndex, const FGameInstancePIEParameters& Params)
{
	EPlayNetMode PlayNetMode(PIE_Standalone);
	GetDefault<ULevelEditorPlaySettings>()->GetPlayNetMode(PlayNetMode);

	int32 PlayNumberOfClients;
	GetDefault<ULevelEditorPlaySettings>()->GetPlayNumberOfClients(PlayNumberOfClients);

	bool PlayNetDedicated;
	GetDefault<ULevelEditorPlaySettings>()->GetPlayNetDedicated(PlayNetDedicated);

	P3JsonLog(Display, "InitializeForPlayInEditor",
		TEXT("PlayNetMode"), *EnumToString(EPlayNetMode, PlayNetMode),
		TEXT("PlayNumberOfClients"), PlayNumberOfClients);

	switch (PlayNetMode)
	{
	case PIE_Standalone:
		if (PlayNumberOfClients == 1)
		{
			GameNetMode = (PlayNetDedicated) ? EP3NetMode::Client : EP3NetMode::Standalone;
		}
		else
		{
			GameNetMode = (PIEInstanceIndex == 1) ? EP3NetMode::ListenServer : EP3NetMode::Client;
		}
		break;
	case PIE_ListenServer:
		GameNetMode = EP3NetMode::ListenServer;
		break;
	case PIE_Client:
		GameNetMode = EP3NetMode::Client;
		break;
	default:
		ensureMsgf(false, TEXT("Invalid PlayNetMode %d"), StaticCast<int32>(PlayNetMode));
	}

	EditorSteramingLevelPackageNames.Empty();
	if (GEditor && GEditor->EditorWorld)
	{
		for (const ULevelStreaming* LevelStreaming : GEditor->EditorWorld->GetStreamingLevels())
		{
			EditorSteramingLevelPackageNames.Add(LevelStreaming->PackageNameToLoad);
		}
	}

	return Super::InitializeForPlayInEditor(PIEInstanceIndex, Params);
}

#endif

void UP3GameInstance::Init()
{
	Super::Init();

	P3Cms::Initialize();

	AccountName = FPlatformProcess::ComputerName();
	AuthToken = CVarP3FakeAuthToken.GetValueOnGameThread();
	CharacterId = (charid)CVarP3FakeCharId.GetValueOnGameThread();
	CharacterName = FPlatformProcess::ComputerName();

	if (!PIEMapName.IsEmpty())
	{
		const FString PIENo = PIEMapName.Mid(PIEMapName.Find(TEXT("UEDPIE_")) + 7, 1);
		AccountName += PIENo;
		CharacterName += PIENo;
		CharacterId = FCString::Atoi(*PIENo);
	}

	// MAX means non-PIE Game
	if (GameNetMode == EP3NetMode::MAX)
	{
		if (IsDedicatedServerInstance())
		{
			GameNetMode = EP3NetMode::DedicatedServer;
		}
		else
		{
			GameNetMode = EP3NetMode::Client;
		}
	}

	if (IsDedicatedServerInstance())
	{
		FString WindowTitle;
		if (FParse::Value(FCommandLine::Get(), TEXT("-P3WindowTitle="), WindowTitle))
		{
			FP3PlatformMisc::SetConsoleWindowTitle(*WindowTitle);
		}
	}

	// Override from commandline option
	FString NetModeStr;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3NetMode="), NetModeStr))
	{
		GameNetMode = P3Core::GetNetModeFromStr(*NetModeStr);
	}

	bool bForcedTCPClient = false;

	int32 NetTCP = CVarP3NetTCP.GetValueOnGameThread();

	if (FParse::Value(FCommandLine::Get(), TEXT("-P3NetTCP="), NetTCP))
	{
		bForcedTCPClient = (NetTCP == 1);
	}

	FString UDPProtocolStr = CVarP3NetUDP.GetValueOnGameThread();
	FParse::Value(FCommandLine::Get(), TEXT("-P3NetUDP="), UDPProtocolStr);

	EP3NetProtocol UDPProtocol = EP3NetProtocol::None;

	FString ConfigDirectory;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3ConfigDirectory="), ConfigDirectory))
	{
		ConfigPath = ConfigDirectory;
	}

	check(GameNetMode != EP3NetMode::MAX);

	if (ensure(FP3GameModule::Get()))
	{
		Version = FP3GameModule::Get()->GetVersion();
	}

	P3JsonLog(Display, "Initialize P3GameInstance",
		TEXT("NetMode"), P3Core::GetNetModeStr(GetWorld()->GetNetMode()),
		TEXT("GameNetMode"), P3Core::GetNetModeStr(GameNetMode));

	if (GameNetMode == EP3NetMode::Standalone)
	{
		// In standalone mode, player character is spawned before ServerWorld is ready
		ItemIdGenerator.InitGenerator(1);
	}

	ensure(!Net);
	Net = NewObject<UP3Net>();
	Net->Initialize();

	if (GameNetMode != EP3NetMode::Client)
	{
		bool bEnableWorldNet = (CVarP3EnableWorldNet.GetValueOnGameThread() > 0);
		if (FParse::Param(FCommandLine::Get(), TEXT("P3EnableWorldNet")))
		{
			bEnableWorldNet = true;
		}

		ensure(!WorldNet);
		WorldNet = bEnableWorldNet ? (UP3WorldNetBase*)NewObject<UP3WorldNet>() : (UP3WorldNetBase*)NewObject<UP3WorldNetLocal>();
		WorldNet->Initialize(this, Net);

		if (FCString::Stricmp(*UDPProtocolStr, TEXT("UE4")) == 0)
		{
			UDPProtocol = EP3NetProtocol::UnrealUDP;
		}
		else if (FCString::Stricmp(*UDPProtocolStr, TEXT("ENet")) == 0)
		{
			UDPProtocol = EP3NetProtocol::ENetUDP;
		}

		if (NetTCP == 1)
		{
			ensure(!PlayerNet);
			PlayerNet = NewObject<UP3PlayerNet>();
			PlayerNet->Initialize(this, Net);
		}

		if (UDPProtocol == EP3NetProtocol::UnrealUDP || UDPProtocol == EP3NetProtocol::ENetUDP)
		{
			ensure(!UDPNetwork);
			UDPNetwork = UP3UDPNetwork::CreateUDPNet(this, UDPProtocol, true);
		}

		check(PlayerNet || UDPNetwork);

		ensure(!WebServer);
		WebServer = NewObject<UP3WebServer>();
		WebServer->Initialize(this);
	}

	if (GameNetMode != EP3NetMode::DedicatedServer)
	{
		ensure(!GameWorldNet);
		GameWorldNet = NewObject<UP3GameWorldNet>();
		GameWorldNet->Initialize(this, Net);

		ensure(!AuthNet);
		AuthNet = NewObject<UP3AuthNet>();
		AuthNet->Initialize(this, Net);

		ensure(!ChatNet);
		ChatNet = NewObject<UP3ChatNet>();
		ChatNet->Initialize(this, Net);

		if (CVarP3UseGoChat.GetValueOnGameThread() != 0)
		{
			ensure(!GoChatNet);
			GoChatNet = NewObject<UP3GoChatNet>();
			GoChatNet->Initialize(this, Net);
		}

		if (!bForcedTCPClient)
		{
			if (FCString::Stricmp(*UDPProtocolStr, TEXT("UE4")) == 0)
			{
				UDPProtocol = EP3NetProtocol::UnrealUDP;
				NetTCP = 0;
			}
			else if (FCString::Stricmp(*UDPProtocolStr, TEXT("ENet")) == 0)
			{
				UDPProtocol = EP3NetProtocol::ENetUDP;
				NetTCP = 0;
			}
		}

		if (NetTCP == 1 || GameNetMode == EP3NetMode::Standalone)
		{
			ensure(!DediNet);
			DediNet = NewObject<UP3DediNet>();
			DediNet->Initialize(this, Net);
		}
		else
		{
			if (UDPProtocol == EP3NetProtocol::UnrealUDP || UDPProtocol == EP3NetProtocol::ENetUDP)
			{
				ensure(!UDPNetwork);
				UDPNetwork = UP3UDPNetwork::CreateUDPNet(this, UDPProtocol, false);
			}
		}

		check(!(DediNet && UDPNetwork));
		check(DediNet || UDPNetwork);
	}

	ensure(!DedimanHelper);
	DedimanHelper = NewObject<UP3DedimanHelper>();
	DedimanHelper->Initialize(this);

	ensure(!ItemManager);
	ItemManager = NewObject<UP3ItemManager>();
	ItemManager->InitializeItemManager(this);

	ensure(!World);
	World = NewObject<UP3World>();
	World->Initialize(this);

	ensure(!NetTick);
	NetTick = new FP3NetTick(Net, DediNet, PlayerNet, WorldNet, WebServer, UDPNetwork);

	PartyManager.InitializePartyManager(this);

	FP3ConfigLoader::LoadConfigFile(ConfigPath);

	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().SetInputManager(MakeShared<FP3SlateInputMapping>());
	}
}

void UP3GameInstance::Shutdown()
{
	Super::Shutdown();

	P3JsonLog(Display, "Shutdown P3GameInstance");

	if (AuthNet)
	{
		AuthNet->Shutdown();
		AuthNet = nullptr;
	}

	if (ChatNet)
	{
		ChatNet->Shutdown();
		ChatNet = nullptr;
	}

	if (GoChatNet)
	{
		GoChatNet->Shutdown();
		GoChatNet = nullptr;
	}

	if (DediNet)
	{
		DediNet->Shutdown();
		DediNet = nullptr;
	}

	if (PlayerNet)
	{
		PlayerNet->Shutdown();
		PlayerNet = nullptr;
	}

	if (WorldNet)
	{
		WorldNet->Shutdown();
		WorldNet = nullptr;
	}

	if (GameWorldNet)
	{
		GameWorldNet->Shutdown();
		GameWorldNet = nullptr;
	}

	if (UDPNetwork)
	{
		UDPNetwork->Shutdown();
		UDPNetwork = nullptr;
	}

	if (ensure(Net))
	{
		Net->Shutdown();
		Net = nullptr;
	}

	if (WebServer)
	{
		WebServer->Shutdown();
		WebServer = nullptr;
	}

	if (ItemManager)
	{
		ItemManager = nullptr;
	}

	if (ensure(World))
	{
		World->Shutdown();
		World = nullptr;
	}

	if (DedimanHelper)
	{
		DedimanHelper->Shutdown();
		DedimanHelper = nullptr;
	}

	if (ensure(NetTick))
	{
		delete NetTick;
		NetTick = nullptr;
	}

	P3Cms::Shutdown();
}

UP3Net* UP3GameInstance::GetNet() const
{
	return Net;
}

UP3AuthNet* UP3GameInstance::GetAuthNet() const
{
	return AuthNet;
}

UP3ChatNet* UP3GameInstance::GetChatNet() const
{
	return ChatNet;
}

UP3DediNet* UP3GameInstance::GetDediNet() const
{
	return DediNet;
}

UP3PlayerNet* UP3GameInstance::GetPlayerNet() const
{
	return PlayerNet;
}

UP3WorldNetBase* UP3GameInstance::GetWorldNet() const
{
	return WorldNet;
}

UP3GameWorldNet* UP3GameInstance::GetGameWorldNet() const
{
	return GameWorldNet;
}

UP3DedimanHelper* UP3GameInstance::GetDedimanHelper() const
{
	return DedimanHelper;
}

UP3WebServer* UP3GameInstance::GetWebServer() const
{
	return WebServer;
}

UP3UDPNetwork* UP3GameInstance::GetUDPNetwork() const
{
	return UDPNetwork;
}

UP3ItemManager* UP3GameInstance::GetItemManager() const
{
	return ItemManager;
}

UWorld* UP3GameInstance::GetCurrentWorld() const
{
	return GetP3World() ? GetP3World()->GetWorld() : nullptr;
}

void UP3GameInstance::SetCharacterName(const FString& InCharacterName)
{
	CharacterName = InCharacterName;
}

void UP3GameInstance::ForceTickNet(float DeltaSeconds)
{
	if (!NetTick)
	{
		return;
	}

	NetTick->Tick(DeltaSeconds);
}

UP3AuthNet* P3GetAuthNet(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetAuthNet();
}

UP3ChatNet* P3GetChatNet(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetChatNet();
}

UP3GoChatNet* P3GetGoChatNet(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetGoChatNet();
}

UP3DediNet* P3GetDediNet(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetDediNet();
}

UP3PlayerNet* P3GetPlayerNet(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetPlayerNet();
}

UP3WorldNetBase* P3GetWorldNet(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetWorldNet();
}

UP3GameWorldNet* P3GetGameWorldNet(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetGameWorldNet();
}

UP3DedimanHelper* P3GetDedimanHelper(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetDedimanHelper();
}

UP3WebServer* P3GetWebServer(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();
	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());
	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetWebServer();
}

UP3UDPNetwork* P3GetUDPNetwork(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();

	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());

	if (!GameInstance)
	{
		return nullptr;
	}

	return GameInstance->GetUDPNetwork();
}

FP3IdGenerator* P3GetItemIdGenerator(const UObject* Object)
{
	if (!Object)
	{
		return nullptr;
	}

	UWorld* World = Object->GetWorld();
	if (!World)
	{
		return nullptr;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());
	if (!GameInstance)
	{
		return nullptr;
	}

	return &GameInstance->GetItemIdGenerator();
}

FP3Version P3GetVersion(const UObject* Object)
{
	if (!Object)
	{
		return FP3Version();
	}

	UWorld* World = Object->GetWorld();
	if (!World)
	{
		return FP3Version();
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());
	if (!GameInstance)
	{
		return FP3Version();
	}

	return GameInstance->GetVersion();
}
