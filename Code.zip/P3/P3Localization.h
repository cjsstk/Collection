#pragma once

#include "CoreMinimal.h"
#include "Internationalization/StringTableRegistry.h"

#define P3LOC_CHARACTER(Key) LOCTABLE("Character", Key)
#define P3LOC_ITEM(Key) LOCTABLE("Item", Key)
#define P3LOC_LOGIN(Key) LOCTABLE("Login", Key)
#define P3LOC_BOSS(Key) LOCTABLE("Boss", Key)
#define P3LOC_NETWORK(Key) LOCTABLE("Network", Key)
