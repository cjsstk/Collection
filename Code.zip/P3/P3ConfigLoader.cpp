// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ConfigLoader.h"

#include "FileHelper.h"
#include "Function.h"
#include "JsonObjectConverter.h"
#include "Paths.h"

#include "P3Log.h"

const char* FP3ConfigLoader::P3JsonFileNames[] = { "P3DefaultConfig", "P3LocalConfig" };

FString FP3ConfigLoader::GetJsonFilePath(const FString& FilePath, const FString& FileName)
{
	const FString JsonFileName = FString::Printf(TEXT("%s.json"), *FileName);

	const FString JasonFilePath = FilePath.IsEmpty() ? FPaths::ProjectConfigDir() : (FPaths::ProjectDir() + FilePath);

	return JasonFilePath / JsonFileName;
}

bool FP3ConfigLoader::LoadConfigFile(const FString& FilePath/* = ""*/)
{
	int32 Size = sizeof(P3JsonFileNames) / sizeof(P3JsonFileNames[0]);

	for (int32 i = 0; i < Size; ++i)
	{
		FString JsonString;

		const FString JasonFilePath = GetJsonFilePath(FilePath, ANSI_TO_TCHAR(P3JsonFileNames[i]));

		if (!FFileHelper::LoadFileToString(JsonString, *JasonFilePath))
		{
			UE_LOG(P3Log, Display, TEXT("Cannot find file - %s"), *JasonFilePath);
			continue;
		}

		TSharedRef<TJsonReader<TCHAR>> JsonReader = TJsonReaderFactory<TCHAR>::Create(JsonString);
		TSharedPtr<FJsonObject> JsonObject = MakeShareable(new FJsonObject());

		bool bResult = FJsonSerializer::Deserialize(JsonReader, JsonObject);

		if (!ensure(bResult))
		{
			return false;
		}

		if (!ensure(JsonObject.IsValid()))
		{
			return false;
		}

		const TMap<FString, TSharedPtr<FJsonValue>>& Values = JsonObject->Values;

		for (const auto& Iter : Values)
		{
			const TSharedPtr<FJsonValue>& JsonValue = Iter.Value;

			if (!JsonValue.IsValid())
			{
				continue;
			}

			ParseJsonValues(Iter.Key, JsonValue);
		}
	}

	return true;
}

bool FP3ConfigLoader::ReloadConfigFile(const FString& FilePath/* = ""*/)
{
	// If you need to prepare something before reloading...

	bool bRet = LoadConfigFile(FilePath);
	return bRet;
}

void FP3ConfigLoader::ParseJsonValues(const FString& Key, const TSharedPtr<FJsonValue>& JsonValue)
{
	if (!JsonValue.IsValid())
	{
		UE_LOG(P3Log, Display, TEXT("Invalid json value - %s"), *Key);
		return;
	}

	if (JsonValue->Type == EJson::Array)
	{
		const TArray<TSharedPtr<FJsonValue>>& JsonArray = JsonValue->AsArray();
		for (const TSharedPtr<FJsonValue>& Val : JsonArray)
		{
			const TSharedPtr<FJsonObject>& Object = Val->AsObject();
			for (const auto& Iter : Object->Values)
			{
				ParseJsonValues(Iter.Key, Iter.Value);
			}
		}
	}
	else if (JsonValue->Type == EJson::Object)
	{
		const TSharedPtr<FJsonObject>& Object = JsonValue->AsObject();
		for (const auto& Iter : Object->Values)
		{
			ParseJsonValues(Iter.Key, Iter.Value);
		}
	}
	else
	{
		IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(*Key);
		if (ensure(CVar))
		{
			if (JsonValue->Type == EJson::String)
			{
				CVar->Set(*JsonValue->AsString());
				UE_LOG(P3Log, Display, TEXT("Set P3 config - %s : %s"), *Key, *JsonValue->AsString());
			}
			else if (JsonValue->Type == EJson::Number)
			{
				if (CVar->IsVariableInt())
				{
					int32 Val = StaticCast<int32>(JsonValue->AsNumber());
					CVar->Set(Val);
					UE_LOG(P3Log, Display, TEXT("Set P3 config - %s : %d"), *Key, Val);
				}
				else
				{
					float Val = StaticCast<float>(JsonValue->AsNumber());
					CVar->Set(Val);
					UE_LOG(P3Log, Display, TEXT("Set P3 config - %s : %f"), *Key, Val);
				}
			}
			else if (JsonValue->Type == EJson::Boolean)
			{
				if (ensure(CVar->IsVariableInt()))
				{
					int32 Val = StaticCast<int32>(JsonValue->AsNumber());
					CVar->Set(Val);
					UE_LOG(P3Log, Display, TEXT("Set P3 config - %s : %d"), *Key, Val);
				}
				else
				{
					UE_LOG(P3Log, Display, TEXT("Invalid boolean value - %s"), *Key);
				}
			}
			else
			{
				ensure(0);
				UE_LOG(P3Log, Display, TEXT("Invalid json value type - %s"), *Key);
			}
		}
		else
		{
			UE_LOG(P3Log, Display, TEXT("Cannot find P3 config - %s"), *Key);
		}
	}
}
