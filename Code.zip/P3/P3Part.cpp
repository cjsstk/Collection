// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Part.h"
#include "P3Core.h"
#include "P3Character.h"
#include "P3StaminaPointComponent.h"

#include "Components/SceneComponent.h"
#include "Components/StaticMeshComponent.h"

AP3Part::AP3Part()
{	
	PrimaryActorTick.bCanEverTick = true;	
	StaticMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StaticMeshComponent"));
}

void AP3Part::BeginPlay()
{
	Super::BeginPlay();
	
	DisableComponentsSimulatePhysics();

	TInlineComponentArray<UPrimitiveComponent*> Components;
	GetComponents(Components);

	for (UPrimitiveComponent* Component : Components)
	{
		Component->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}	

	SetActorHiddenInGame(true);	
	
	PartFlags.AddZeroed((int32)EP3PartType::Count);
	PartFlags[(int32)EP3PartType::Mobile] = MobilePartFlags;
}

void AP3Part::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	
}

void AP3Part::AttachPart(const AP3Character* Character)
{	
	if (ensure(Character))
	{			
		AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::KeepWorldTransform, HoldSocketName);
		SetActorRelativeLocation(HoldLocation);
		SetActorRelativeRotation(HoldRotation);
		SetActorRelativeScale3D(FVector(1, 1, 1));						
	}
}

void AP3Part::DetachPart()
{	
	DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);		
}

void AP3Part::AddStartPart(const AP3Character* Character)
{
	if (PartInputType == EP3PartInputType::Passive)
	{
		StartPart(Character);
	}
	else
	{
		if (PartViewType == EP3PartViewType::Always ||
			PartViewType == EP3PartViewType::AlwaysHolder)
		{
			SetActorHiddenInGame(false);
		}

		AttachPart(Character);
	}

	bHolder = true;
}

void AP3Part::RemoveStopPart(const AP3Character* Character)
{
	bHolder = false;
	DeactivateInternal(Character);	
}

void AP3Part::StartPart(const AP3Character* Character)
{
	if (PartInputType == EP3PartInputType::Passive ||
		PartInputType == EP3PartInputType::Charging )
	{				
		ActivateInternal(Character);
	}
	else
	if (PartInputType == EP3PartInputType::Toggle)
	{
		if (!bPlaying)
		{
			ActivateInternal(Character);
		}			
		else
		{
			DeactivateInternal(Character);		
		}
	}
}

void AP3Part::StopPart(const AP3Character* Character)
{
	if (bPlaying)
	{
		if (PartInputType == EP3PartInputType::Passive ||
			PartInputType == EP3PartInputType::Charging )
		{
			DeactivateInternal(Character);
		}
	}
}

void AP3Part::StopPartInterrupt(const AP3Character* Character)
{
	if (PartInputType == EP3PartInputType::Toggle)
	{
		if (bPlaying)
		{
			DeactivateInternal(Character);
		}
	}
	else
	{
		StopPart(Character);
	}
}

bool AP3Part::CanPartFlags(EP3PartType Type, int32 Flag) const
{
	return bPlaying && (PartFlags[(int32)Type] & (1 << Flag));
}

bool AP3Part::Server_BeginInterruptCondition(const AP3Character* Character) const
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));
	
	if (ensure(Character))
	{
		const UP3StaminaPointComponent* StaminaComponent = Character->GetStaminaComponent();
		if (ensure(StaminaComponent))
		{
			if (PartInputType == EP3PartInputType::Charging)
			{
				return StaminaComponent->GetStaminaPoint() <= 0.f;
			}
			else
			if (PartInputType == EP3PartInputType::Toggle)
			{
				return !bPlaying ? (StaminaComponent->GetStaminaPoint() <= 0.f) : false;
			}
		}			
	}	

	return false;
}

bool AP3Part::Server_TickInterruptCondition(const AP3Character* Character) const
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));
			
	if (ensure(Character))
	{
		if (PartInputType == EP3PartInputType::Passive ||
			PartInputType == EP3PartInputType::Charging || 
			PartInputType == EP3PartInputType::Toggle )
		{
			const UP3StaminaPointComponent* StaminaComponent = Character->GetStaminaComponent();
			if (ensure(StaminaComponent))
			{
				return bPlaying && StaminaComponent->GetStaminaPoint() <= 0.f;
			}
		}
	}
	
	return false;
}

void AP3Part::ActivateInternal(const AP3Character* Character)
{
	if (ensure(Character))
	{
		UP3StaminaPointComponent* StaminaComponent = Character->GetStaminaComponent();
		if (ensure(StaminaComponent))
		{
			StaminaComponent->SetConsumer(EStaminaConsumerLayer::ConsumePart, Cost);			
		}

		bPlaying = true;

		AttachPart(Character);
		SetActorHiddenInGame(false);				
	}
}

void AP3Part::DeactivateInternal(const AP3Character* Character)
{
	if (ensure(Character))
	{
		UP3StaminaPointComponent* StaminaComponent = Character->GetStaminaComponent();
		if (ensure(StaminaComponent))
		{
			StaminaComponent->SetConsumer(EStaminaConsumerLayer::ConsumePart, 0.f);
		}

		bPlaying = false;

		DetachPart();
		SetActorHiddenInGame(true);		
	}
}