// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "Components/ArrowComponent.h"
#include "GameplayTagContainer.h"
#include "GameFramework/Actor.h"
#include "P3LootDropComponent.h"
#include "P3SpawnerComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3SpawnerComponentOnSpawn, class UP3SpawnerComponent*, SpawnerComponent, class AActor*, SpawnedActor);


UCLASS( ClassGroup=(P3), meta=(BlueprintSpawnableComponent) )
class P3_API UP3SpawnerComponent : public USceneComponent
{
	GENERATED_BODY()

public:	
	UP3SpawnerComponent();

	virtual void Activate(bool bReset=false) override;
	virtual void SetComponentTickEnabled(bool bEnabled) override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** Reset to initial state - used when restarting level without reloading. */
	void ResetSpawnerComponent();

	float GetRandom2DRadius() const { return Random2DRadius; }
	TArray<AActor*> GetSpawnedActors() const { return SpawnedActors; }
	TSubclassOf<AActor> GetSpawnActorClass() const { return ActorClass; }

	FP3SpawnerComponentOnSpawn OnSpawn;

protected:
	virtual void BeginPlay() override;
	virtual AActor* SpawnInternal();

private:
	void DoInitialSpawn();

	void StartCooldown();
	void Spawn();
	bool FindSpawnTransform(FTransform& OutTransform);

	/** See if given location is overlap with pre-spawned actors */
	bool IsOverlapWithSpawnedActors(const FVector& Location) const;

	/** See if we have valid navigation path from given location to spawner component location */
	bool HasValidNavPath(const FVector& Location) const;

	/** See if any player can see this location */
	bool IsInPlayerSight(const FVector& Location) const;

	UPROPERTY(EditAnywhere, Category = Spawner)
	ESpawnActorCollisionHandlingMethod CollisionHandling = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	UPROPERTY(EditAnywhere, Category = Spawner)
	TSubclassOf<AActor> ActorClass;

	UPROPERTY(EditAnywhere, Category = Spawner)
	TArray<TSubclassOf<UActorComponent>> ComponentClasses;

	UPROPERTY(EditAnywhere, Category = Spawner)
	FGameplayTagContainer GameplayTagContainer;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Spawner, meta = (AllowPrivateAccess = "true"))
	int32 NumInitialSpawn = 0;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Spawner, meta = (AllowPrivateAccess = "true"))
	int32 NumMaxSpawn = 1;

	/** Limit accumulated total spawn count. -1 means no limit */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Spawner, meta = (AllowPrivateAccess = "true"))
	int32 NumMaxTotalSpawn = -1;

	UPROPERTY(EditAnywhere, Category = Spawner)
	float MinCooldownSeconds = 0;

	UPROPERTY(EditAnywhere, Category = Spawner)
	float MaxCooldownSeconds = 10;

	UPROPERTY(EditAnywhere, Category = Spawner)
	float Random2DRadius = 0;

	/** If set, radius within this will not be used for spawning */
	UPROPERTY(EditAnywhere, Category = Spawner)
	float Min2DRadius = 0;

	UPROPERTY(EditAnywhere, Category = Spawner)
	FRotator RandomRotation = FRotator(0, 360, 0);

	/** If set true, spawned actor will be aligned vertically to ground. Random Rotation only works for yaw if this is checked */
	UPROPERTY(EditAnywhere, Category = Spawner)
	bool bAlignToGround = false;

	/** If set true, actors will be spawned only on landscape */
	UPROPERTY(EditAnywhere, Category = Spawner)
	bool bSpawnOnLandscapeOnly = false;

	/** If set true and Random2DRadius is not 0, spawning location will have valid path to spawner component location */
	UPROPERTY(EditAnywhere, Category = Spawner)
	bool bCheckPathFinding = false;

	/** If set true, spawn only if non of players are watching */
	UPROPERTY(EditAnywhere, Category = Spawner)
	bool bAvoidPlayerSight = false;

	/** If set true, new actor will not be spawn near previously spawned actor */
	UPROPERTY(EditAnywhere, Category = Spawner)
	bool bAvoidOverlap = false;

	/** Requires AvoidOverlap to be true */
	UPROPERTY(EditAnywhere, Category = Spawner)
	float AvoidOverlapDistance = 100.0f;

	/** If set > 0, spawned actor will be move to downward with sweeping. Use this to perfectly settle object to floor */
	UPROPERTY(EditAnywhere, Category = Spawner)
	float SweepZDistance = 0;

	/** If set > 0, spawned actor will teleport upward before Sweep Z. This is required if object's bound is lower than it's pivot */
	UPROPERTY(EditAnywhere, Category = Spawner)
	float SweepZStartOffset = 0;

	/** Set max retry count if spawn fails(due to overlap or landscape check) */
	UPROPERTY(EditAnywhere, Category = Spawner)
	int32 NumRetrySpawn = 10;

	/** Optional loot items to be added to spawned actor(if actor has loot drop component) */
	UPROPERTY(EditAnywhere, Category = Spawner)
	FP3LootItemContainer LootItemContainer;
	
	UPROPERTY(Transient, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"), Category = Spawner)
	TArray<AActor*> SpawnedActors;

	float CooldownSecondsLeft = 0;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"), Category = Spawner)
	int32 NumTotalSpawned = 0;

	/** Store default spawner component activation for reset */
	bool bReset_DefaultbActivation = true;
};


UCLASS(Blueprintable, meta=(BlueprintSpawnableComponent))
class P3_API UP3DeadPawnDestroyerComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3DeadPawnDestroyerComponent();

	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	float GetDestroyTimeLeftSecondsBP() const { return DestoryTimeLeftSeconds; }
	float GetDestroyTimeLeftSeconds() const { return DestoryTimeLeftSeconds; }

private:

	UPROPERTY(EditAnywhere, Category = Spawner)
	float MinDestoryDelaySeconds = 10;

	UPROPERTY(EditAnywhere, Category = Spawner)
	float MaxDestoryDelaySeconds = 20;

	UPROPERTY(Transient)
	class UP3HealthPointComponent* CachedHealthPointComponent;

	float DestoryTimeLeftSeconds = 0;
};

UCLASS(Blueprintable, meta=(BlueprintSpawnableComponent))
class P3_API UP3DeadCharacterRagollizerComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3DeadCharacterRagollizerComponent();

	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void OnCharacterDead();
};

UCLASS(ClassGroup=(P3),  meta=(BlueprintSpawnableComponent))
class P3_API UP3DestroyActorComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3DestroyActorComponent();

	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void OnBeginOverlap(AActor* OverlappedActor, AActor* OtherActor);

	/** If set, any P3Actor/P3Character that has any of this tags will trigger switch */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer TriggerGameplayTagsAny;

	/** If set, any P3Actor/P3Character that has all of this tags will trigger switch */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer TriggerGameplayTagsAll;
};

/** 
 * Set Owner Actor's life span as random range
 */
UCLASS(ClassGroup=(P3),  meta=(BlueprintSpawnableComponent))
class P3_API UP3RandomLifeSpanComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	virtual void BeginPlay() override;

private:
	UPROPERTY(EditAnywhere, Category = P3)
	float MinLifeSpan = 5;

	UPROPERTY(EditAnywhere, Category = P3)
	float MaxLifeSpan = 10;

	/** If true, lifespan will be only changed on server */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bServerOnly = true;
};
