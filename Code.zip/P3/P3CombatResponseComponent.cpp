// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CombatResponseComponent.h"

#include "Curves/CurveVector.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "P3AnimInstance.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3CharacterMovementComponent.h"
#include "P3Core.h"
#include "P3HolderComponent.h"
#include "P3PlayerController.h"
#include "P3StaminaPointComponent.h"
#include "P3World.h"
#include "P3Weapon.h"

UP3CombatResponseComponent::UP3CombatResponseComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	bWantsInitializeComponent = true;
}

void UP3CombatResponseComponent::InitializeComponent()
{
	Super::InitializeComponent();
	Deactivate();
}

void UP3CombatResponseComponent::UninitializeComponent()
{
	Super::UninitializeComponent();	
}

void UP3CombatResponseComponent::BeginPlay()
{
	Super::BeginPlay();	
}

void UP3CombatResponseComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void UP3CombatResponseComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!IsActive())
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{		
		return;
	}

	const FP3CombatReactionRow* ReactionRow = GetReactionRow();
	if (!ensure(ReactionRow))
	{	
		return;
	}

	TickReactionAnimation(*Character, *ReactionRow, DeltaTime);
	TickReactionMesh(*Character, *ReactionRow, DeltaTime);

	const bool bIsFinshedCCD = ReactionRow->CCDDurationSeconds <= CCDInProgressTimeSeconds;
	const bool bIsFinshedPoseAsset = ReactionRow->PoseAssetDurationSeconds <= PoseAssetInProgressTimeSeconds;
	const bool bIsFinshedMorpth = ReactionRow->MorpthDurationSeconds <= MorpthInProgressTimeSeconds;
	const bool bIsFinshedPhysicsBlendBone = ReactionRow->PhysicsBlendBoneDurationSeconds <= PhysicsBlendBoneInProgressTimeSeconds;
	const bool bIsFinshedFrameHold = ReactionRow->FrameHoldDurationSeconds <= FrameHoldInProgressTimeSeconds || !RequestReactionParams.bIsFrameHold;
	const bool bIsFinshedMeshShake = ReactionRow->FrameHoldDurationSeconds <= FrameHoldInProgressTimeSeconds || !ReactionRow->bMeshShake;
	
	if (bIsFinshedCCD && bIsFinshedPoseAsset && bIsFinshedMorpth && bIsFinshedPhysicsBlendBone && bIsFinshedFrameHold && bIsFinshedMeshShake)
	{
		FinishReaction();
	}
}

void UP3CombatResponseComponent::StartReaction(const FP3RequestResponseParams& InRequestReactionParams)
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	if (IsActive())
	{
		FinishReaction();
	}

	RequestReactionParams = InRequestReactionParams;
	
	if (!RequestReactionParams.AttackerActor)
	{
		RequestReactionParams.AttackerActor = P3Core::GetP3World(*this)->GetActorFromActorId(RequestReactionParams.AttackerActorID);
	}

	const FP3CombatReactionRow* ReactionRow = GetReactionRow();
	if (!ensure(ReactionRow))
	{
		return;
	}

	if (!ReactionRow->Montage && ReactionRow->bForceStopAction)
	{
		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		if (ActionComp && !ActionComp->IsActionInProgress(EPawnActionType::CombatReactionHit))
		{
			ActionComp->StopAction(ActionComp->GetActiveActionId(), FP3PawnActionStopRequestParams());
		}
	}

	StartReactionAnimation(*Character, *ReactionRow);
	StartReactionMovement(*Character, *ReactionRow);
	StartReactionMesh(*Character, *ReactionRow);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		Server_StartReactionStatus(*Character, *ReactionRow);
	}

	if (P3Core::IsP3NetModeClientInstance(*Character))
	{
		Client_StartReactioCamera(*Character, *ReactionRow);
		Client_StartReactioUI(*Character, *ReactionRow);
	}

	Activate();
}

void UP3CombatResponseComponent::FinishReaction()
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	const FP3CombatReactionRow* ReactionRow = GetReactionRow();
	if (!ensure(ReactionRow))
	{
		return;
	}

	FinishReactionAnimation(*Character, *ReactionRow);
	FinishReactionMesh(*Character, *ReactionRow);	

	CCDInProgressTimeSeconds = 0.f;
	PoseAssetInProgressTimeSeconds = 0.f;
	MorpthInProgressTimeSeconds = 0.f;
	PhysicsBlendBoneInProgressTimeSeconds = 0.f;
	FrameHoldInProgressTimeSeconds = 0.f;

	bRestsoreMeshShake = false;

	RequestReactionParams.Reset();

	Deactivate();
}

const UDataTable* UP3CombatResponseComponent::GetCombatReactionTable(EP3ReactionLayer ReactionLayer) const
{
	return ReactionTable.FindRef(ReactionLayer);
}

const UDataTable* UP3CombatResponseComponent::GetCombatReactionOverlapRuleTable(EP3ReactionLayer ReactionLayer) const
{
	return ReactionOverlapRuleTable.FindRef(ReactionLayer);
}

const FVector UP3CombatResponseComponent::GetReactiontDirection(AP3Character& Character, EP3ReactiontDirection DesirDirection)
{
	FVector Direction = FVector::ForwardVector;
	FTransform TargetTransform = RequestReactionParams.TargetTransform;

	switch (DesirDirection)
	{
	case EP3ReactiontDirection::OffenceForward:
	{
		Direction = TargetTransform.GetRotation().GetForwardVector();
		break;
	}
	case EP3ReactiontDirection::OffenceBack:
	{
		Direction = -TargetTransform.GetRotation().GetForwardVector();
		break;
	}
	case EP3ReactiontDirection::OffenceRight:
	{
		Direction = TargetTransform.GetRotation().GetRightVector();
		break;
	}
	case EP3ReactiontDirection::OffenceLeft:
	{
		Direction = -TargetTransform.GetRotation().GetRightVector();
		break;
	}
	case EP3ReactiontDirection::DefenceForward:
	{
		Direction = Character.GetActorForwardVector();
		break;
	}
	case EP3ReactiontDirection::DefenceBack:
	{
		Direction = -Character.GetActorForwardVector();
		break;
	}
	case EP3ReactiontDirection::DefenceRight:
	{
		Direction = Character.GetActorRightVector();
		break;
	}
	case EP3ReactiontDirection::DefenceLeft:
	{
		Direction = -Character.GetActorRightVector();
		break;
	}
	case EP3ReactiontDirection::HitForward:
	{
		Direction = -(Character.GetActorLocation() - TargetTransform.GetLocation()).GetSafeNormal();
		break;
	}
	case EP3ReactiontDirection::HitBack:
	{
		Direction = (Character.GetActorLocation() - TargetTransform.GetLocation()).GetSafeNormal();
		break;
	}
	case EP3ReactiontDirection::HitRight:
	{
		Direction = (Character.GetActorLocation() - TargetTransform.GetLocation()).GetSafeNormal().RightVector;
		break;
	}
	case EP3ReactiontDirection::HitLeft:
	{
		Direction = -(Character.GetActorLocation() - TargetTransform.GetLocation()).GetSafeNormal().RightVector;
		break;
	}
	default:
	{
		ensure(0);
		break;
	}
	}

	return Direction;
}

void UP3CombatResponseComponent::IncreaseOverlapCount()
{
	ReactionOverlapCount++;
}

void UP3CombatResponseComponent::ResetOverlapCount()
{
	ReactionOverlapCount = 0;
}

int32 UP3CombatResponseComponent::GetOverlapCount() const
{
	return ReactionOverlapCount;
}

void UP3CombatResponseComponent::SetReactionInProgress(FName ReactionName, EP3ReactionLayer Layer, EAnimNotifyAttackDirectionFlags AttackDirection, EAnimNotifyAttackStrengthFlags AttackStrength)
{
	InProgressReactionName = ReactionName;
	InProgressLayer = Layer;
	InProgressAttackDirection = AttackDirection;
	InProgressAttackStrength = AttackStrength;
}

const FName& UP3CombatResponseComponent::GetInProgressName() const
{
	return InProgressReactionName;
}

EP3ReactionLayer UP3CombatResponseComponent::GetInProgressLayer() const
{
	return InProgressLayer;
}

EAnimNotifyAttackDirectionFlags UP3CombatResponseComponent::GetInProgressAttackDirection() const
{
	return  InProgressAttackDirection;
}

EAnimNotifyAttackStrengthFlags UP3CombatResponseComponent::GetInProgressAttackStrength() const
{
	return InProgressAttackStrength;
}

void UP3CombatResponseComponent::SetInProgressAnimationType(EP3ReactionLayerAnimationType InReactionLayerAnimationType)
{
	InProgressReactionLayerAnimationType = InReactionLayerAnimationType;
}

EP3ReactionLayerAnimationType UP3CombatResponseComponent::GetInProgressAnimationType() const
{
	return InProgressReactionLayerAnimationType;
}

void UP3CombatResponseComponent::SetNotifyStateSignal(const FName& SignalName, bool bIsEnabled)
{
	NotifyStateSignal.FindOrAdd(SignalName) = bIsEnabled;
}

bool UP3CombatResponseComponent::IsNotifyStateSignalEnabled(const FName& SignalName) const
{
	return NotifyStateSignal.FindRef(SignalName) == true;
}

void UP3CombatResponseComponent::SetLastUpdateAttackerActor(AActor* InLastUpdateAttackerActor)
{
	LastUpdateAttackerActor = InLastUpdateAttackerActor;
}

AActor* UP3CombatResponseComponent::GetLastUpdateAttackerActor() const
{
	return LastUpdateAttackerActor;
}

void UP3CombatResponseComponent::SetLastUpdateCmsCombatHitKey(FName InLastUpdateCmsCombatHitKey)
{
	LastUpdateCmsCombatHitKey = InLastUpdateCmsCombatHitKey;
}

FName UP3CombatResponseComponent::GetLastUpdateCmsCombatHitKey() const
{
	return LastUpdateCmsCombatHitKey;
}

void UP3CombatResponseComponent::StartReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	UP3AnimInstance* AnimInstance = Character.GetMesh() ? Cast<UP3AnimInstance>(Character.GetMesh()->GetAnimInstance()) : nullptr;
	if (!ensure(AnimInstance))
	{
		return;
	}

	if (ReactionRow.CCDAlpha.Num() && ReactionRow.CCDDurationSeconds > 0.f)
	{
		for (const TPair<FName, FCCDReaction>& CCD : ReactionRow.CCDAlpha)
		{
			AnimInstance->SetCCDAlpha(CCD.Key, CCD.Value.Alpha);
		}
	}

	if (ReactionRow.PoseAsset.Num() && ReactionRow.PoseAssetDurationSeconds > 0.f)
	{
		for (const TPair<FName, float>& PoseAsset : ReactionRow.PoseAsset)
		{
			AnimInstance->SetPoseAsset(PoseAsset.Key, PoseAsset.Value);
		}
	}

	if (bRestsoreMeshShake)
	{
		USkeletalMeshComponent* MeshComp = Character.GetMesh();
		if (MeshComp)
		{
			MeshComp->SetRelativeLocation(RestoreMeshLocation);
		}

		bRestsoreMeshShake = false;
	}

	if (ReactionRow.FrameHoldDurationSeconds > 0.f)
	{
		StartMeshShake(Character, ReactionRow);
	}
}

void UP3CombatResponseComponent::StartMeshShake(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	if (RequestReactionParams.bIsFrameHold)
	{		
		UAnimInstance* AnimInstance = Character.GetMesh() ? Character.GetMesh()->GetAnimInstance() : nullptr;

		if (AnimInstance && !ReactionRow.bAttackerFrameHoldOnly)
		{			
			AnimInstance->Montage_Pause(AnimInstance->GetCurrentActiveMontage());
		}

		AP3Character* AttackerCharacter = RequestReactionParams.AttackerActor ? Cast<AP3Character>(RequestReactionParams.AttackerActor) : nullptr;
		USkeletalMeshComponent* AttackerMeshComp = AttackerCharacter ? AttackerCharacter->GetMesh() : nullptr;
		UAnimInstance* AttackerAnimInstance = AttackerMeshComp ? AttackerMeshComp->GetAnimInstance() : nullptr;
			
		if (AttackerAnimInstance)
		{
			if (AttackerCharacter && AttackerCharacter->IsControlled())
			{
				AttackerAnimInstance->Montage_SetPlayRate(AttackerAnimInstance->GetCurrentActiveMontage(), 0.001f);
			}
			else
			{
				AttackerAnimInstance->Montage_Pause(AttackerAnimInstance->GetCurrentActiveMontage());
			}
		}

		if (ReactionRow.bMeshShake && !ReactionRow.bAttackerFrameHoldOnly)
		{
			USkeletalMeshComponent* MeshComp = Character.GetMesh();
			if (MeshComp)
			{
				RestoreMeshLocation = MeshComp->GetRelativeTransform().GetLocation();
				bRestsoreMeshShake = true;
			}
		}
	}	
}

void UP3CombatResponseComponent::StartReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	UP3CharacterMovementComponent* MovementComp = Character.GetP3CharacterMovementBP();

	if (!ensure(MovementComp))
	{
		return;
	}

	if (ReactionRow.bHitRotator)
	{
		FVector SourceToTargetDirection = (Character.GetActorLocation() - RequestReactionParams.TargetTransform.GetLocation()).GetSafeNormal();
		FVector SourceForward = Character.GetActorForwardVector();

		const bool bIsFront = (SourceToTargetDirection.GetSafeNormal2D() | SourceForward.GetSafeNormal2D()) < 0.f;
		SourceToTargetDirection *= bIsFront ? 1.f : -1.f;

		FRotator HitRotator = (-SourceToTargetDirection).Rotation();

		if (MovementComp->ShouldRemainVertical())
		{
			HitRotator.Pitch = 0.f;
			HitRotator.Yaw = FRotator::NormalizeAxis(HitRotator.Yaw);
			HitRotator.Roll = 0.f;
		}

		Character.SetActorRotation(HitRotator);
	}

	 if (ReactionRow.ImpulseStrength2D > 0.f || ReactionRow.ImpulseStrength > 0.f)
	{
		FVector Impulse = GetReactiontDirection(Character, ReactionRow.ReactiontDirection);
		Impulse = Impulse.GetSafeNormal2D() * ReactionRow.ImpulseStrength2D;
		Impulse.Z = ReactionRow.ImpulseStrength;

		MovementComp->AddImpulse(Impulse, true);
	}
}

void UP3CombatResponseComponent::StartReactionMesh(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	if (ReactionRow.PhysicsBlendBoneDurationSeconds > 0.f)
	{
		USkeletalMeshComponent* MeshComp = Character.GetMesh();
		if (MeshComp)
		{
			const FPhysicsBlendBone* FindPhysicsBlendBone = ReactionRow.PhysicsBlendBone.Find(RequestReactionParams.HitBoneName);
			if (FindPhysicsBlendBone)
			{
				MeshComp->SetCollisionEnabled(ECollisionEnabled::PhysicsOnly);

				FVector Impulse = GetReactiontDirection(Character, ReactionRow.MeshImpulsetDirection);
				Impulse = Impulse.GetSafeNormal2D() * ReactionRow.MeshImpulseStrength2D + FVector(0.f, 0.f, ReactionRow.MeshImpulseStrength);

				for (const TPair<FName, float>& BlendBoneWeight : FindPhysicsBlendBone->PhysicsBlendBoneWeight)
				{
					MeshComp->SetAllBodiesBelowSimulatePhysics(BlendBoneWeight.Key, true);
					MeshComp->SetAllBodiesBelowPhysicsBlendWeight(BlendBoneWeight.Key, BlendBoneWeight.Value);
					MeshComp->AddImpulse(Impulse, BlendBoneWeight.Key, true);
				}
			}
		}
	}
}

void UP3CombatResponseComponent::Server_StartReactionStatus(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	if (ReactionRow.bDropPickable || ReactionRow.bDropLeftHandHoldable || ReactionRow.bDropRightHandHoldable)
	{
		UP3CombatComponent* CombatComp = Character.GetP3CombatComponentBP();
		if (ensure(CombatComp))
		{
			const float DropImpulseSize = ReactionRow.DropImpulseSize;
			FVector DropDirection = (RequestReactionParams.HitLocation - RequestReactionParams.AttackerActor->GetActorLocation()).GetSafeNormal();

			if (ReactionRow.bDropPickable)
			{
				Character.GetCommandComponent()->RequestCommand(UP3DropPickableCommand::StaticClass(), FP3CommandRequestParams());
			}

			if (ReactionRow.bDropLeftHandHoldable)
			{
				const bool bLeftHandHolder = (Character.GetLeftHandHolderComponent() != nullptr);
				AP3Weapon* LeftHandWeapon = bLeftHandHolder ? (Cast<AP3Weapon>(Character.GetLeftHandHolderComponent()->GetHoldingActor())) : nullptr;
				if (LeftHandWeapon)
				{
					if (!(LeftHandWeapon->IsPlayerUsable()))
					{
						LeftHandWeapon->SetLifeSpan(ReactionRow.DropHoldableItemLifeSpan);
					}

					FP3CommandRequestParams DropHoldableParams;
					DropHoldableParams.DropHoldable_HoldType = EP3HoldType::LeftHand;
					DropHoldableParams.DropHoldable_DropImpulseSize = DropImpulseSize;
					DropHoldableParams.DropHoldable_DropDirection = DropDirection;
					Character.GetCommandComponent()->RequestCommand(UP3DropHoldableCommand::StaticClass(), DropHoldableParams);
				}
			}

			if (ReactionRow.bDropRightHandHoldable)
			{
				const bool bRightHandHoler = (Character.GetRightHandHolderComponent() != nullptr);
				AP3Weapon* RightHandWeapon = bRightHandHoler ? (Cast<AP3Weapon>(Character.GetRightHandWeaponActor())) : nullptr;
				if (RightHandWeapon)
				{
					if (!(RightHandWeapon->IsPlayerUsable()))
					{
						RightHandWeapon->SetLifeSpan(ReactionRow.DropHoldableItemLifeSpan);
					}

					FP3CommandRequestParams DropHoldableParams;
					DropHoldableParams.DropHoldable_HoldType = EP3HoldType::RightHand;
					DropHoldableParams.DropHoldable_DropImpulseSize = DropImpulseSize;
					DropHoldableParams.DropHoldable_DropDirection = DropDirection;
					Character.GetCommandComponent()->RequestCommand(UP3DropHoldableCommand::StaticClass(), DropHoldableParams);
				}
			}
		}
	}

	if (ReactionRow.bBreakGuard)
	{
		if (Character.GetCharacterStoreBP().bIsBlocking)
		{
			FP3CommandRequestParams BlockingCommandParams;
			BlockingCommandParams.SetBlocking_bNewBlocking = false;
			Character.GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), BlockingCommandParams);
		}
	}

	if (ReactionRow.bBreakCrounchGuard)
	{
		if (Character.GetCharacterStoreBP().bIsCrouchBlocking)
		{
			FP3CommandRequestParams CrouchBlockingCommandParams;
			CrouchBlockingCommandParams.SetCrouchBlocking_bNewBlocking = false;
			Character.GetCommandComponent()->RequestCommand(UP3SetCrouchBlockingCommand::StaticClass(), CrouchBlockingCommandParams);
		}
	}

	if (ReactionRow.StaminaAmount > 0.f)
	{
		if (Character.GetStaminaComponent())
		{
			Character.GetStaminaComponent()->ConsumeStamina(ReactionRow.StaminaAmount);
		}
	}
}

void UP3CombatResponseComponent::Client_StartReactioUI(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	AP3PlayerController* Controller = Cast<AP3PlayerController>(Character.GetController());
	if (!Controller || !Controller->IsLocalController())
	{
		return;
	}

	switch (RequestReactionParams.Layer)
	{
	case::EP3ReactionLayer::Guard:
	{
		Controller->CreateBlockCombatText(&Character);
		break;
	};

	case::EP3ReactionLayer::Parrying:
	{
		Controller->CreateCounterAttackCombatText(&Character);
		break;
	};
	}
}

void UP3CombatResponseComponent::Client_StartReactioCamera(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	FName CameraShakeName = ReactionRow.CmsReactionCameraShakeKey;
	const FP3CmsCameraShakeRow* CmsCameraShakeRow = P3Cms::GetCameraShake(CameraShakeName);

	if (!CmsCameraShakeRow)
	{		
		return;		
	}

	const float Distance = (Character.GetActorLocation() - RequestReactionParams.AttackerActor->GetActorLocation()).Size();

	if (CmsCameraShakeRow->bStandaloneLocalPlay)
	{
		if (IsLocalControlledActor(&Character))
		{
			Character.Client_PlayCameraShake(CameraShakeName, Distance);
		}
	}
	else
	{
		Character.Client_PlayCameraShake(CameraShakeName, Distance);
	}
}

void UP3CombatResponseComponent::TickReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds)
{
	UP3AnimInstance* AnimInstance = Character.GetMesh() ? Cast<UP3AnimInstance>(Character.GetMesh()->GetAnimInstance()) : nullptr;
	if (!ensure(AnimInstance))
	{		
		return;
	}

	if (ReactionRow.CCDAlpha.Num() && ReactionRow.CCDDurationSeconds > 0.f && ReactionRow.CCDDurationSeconds > CCDInProgressTimeSeconds)
	{
		for (const TPair<FName, FCCDReaction>& CCD : ReactionRow.CCDAlpha)
		{
			if (!CCD.Value.CurveVector)
			{
				continue;
			}

			FVector EffectLocation = ReactionRow.CCDResponseDist * CCD.Value.CurveVector->GetVectorValue(CCDInProgressTimeSeconds);
			AnimInstance->SetCCDEffectLocation(CCD.Key, EffectLocation);
		}

		CCDInProgressTimeSeconds += DeltaSeconds;
	}

	if (ReactionRow.PoseAsset.Num() && ReactionRow.PoseAssetDurationSeconds > 0.f && ReactionRow.PoseAssetDurationSeconds > PoseAssetInProgressTimeSeconds)
	{
		float Alpha = ReactionRow.PoseAssetCurve ? ReactionRow.PoseAssetCurve->GetFloatValue(PoseAssetInProgressTimeSeconds) : 0.f;
		AnimInstance->SetPoseAssetAlpha(Alpha);

		PoseAssetInProgressTimeSeconds += DeltaSeconds;		
	}

	if (ReactionRow.Morpth.Num() && ReactionRow.MorpthDurationSeconds > 0.f && ReactionRow.MorpthDurationSeconds > MorpthInProgressTimeSeconds)
	{
		const FMorpthReaction* FindMorpth = ReactionRow.Morpth.Find(RequestReactionParams.HitBoneName);
		if (FindMorpth)
		{
			for (const FName& MorpthName : FindMorpth->MorpthName)
			{
				if (!FindMorpth->MorpthCurve)
				{
					continue;
				}

				float MorphValue = FindMorpth->MorpthCurve->GetFloatValue(MorpthInProgressTimeSeconds);
				AnimInstance->SetMorphTarget(MorpthName, MorphValue);
			}
		}

		MorpthInProgressTimeSeconds += DeltaSeconds;
	}	
}

void UP3CombatResponseComponent::TickReactionMesh(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds)
{
	if (ReactionRow.PhysicsBlendBoneDurationSeconds > 0.f && ReactionRow.PhysicsBlendBoneDurationSeconds > PhysicsBlendBoneInProgressTimeSeconds)
	{
		USkeletalMeshComponent* MeshComp = Character.GetMesh();
		if (MeshComp)
		{
			const FPhysicsBlendBone* FindPhysicsBlendBone = ReactionRow.PhysicsBlendBone.Find(RequestReactionParams.HitBoneName);
			if (FindPhysicsBlendBone)
			{
				for (const TPair<FName, float>& BlendBoneWeight : FindPhysicsBlendBone->PhysicsBlendBoneWeight)
				{
					float BlendWeight = BlendBoneWeight.Value;

					if (PhysicsBlendBoneInProgressTimeSeconds > ReactionRow.PhysicsBlendBoneDurationSeconds * 0.5f)
					{
						float Alpha = PhysicsBlendBoneInProgressTimeSeconds / ReactionRow.PhysicsBlendBoneDurationSeconds;
						BlendWeight = FMath::Lerp<float>(BlendWeight, 0.f, Alpha);
					}

					MeshComp->SetAllBodiesBelowPhysicsBlendWeight(BlendBoneWeight.Key, BlendWeight);
				}
			}
		}

		PhysicsBlendBoneInProgressTimeSeconds += DeltaSeconds;
	}

	if (ReactionRow.FrameHoldDurationSeconds > 0.f && ReactionRow.FrameHoldDurationSeconds > FrameHoldInProgressTimeSeconds)
	{
		if (ReactionRow.bMeshShake && bRestsoreMeshShake)
		{
			USkeletalMeshComponent* MeshComp = Character.GetMesh();
			if (MeshComp)
			{
				FVector RelativeLocation = FVector::ZeroVector;
				const float Range = ReactionRow.MeshShakeStrength * DeltaSeconds;

				RelativeLocation.X = RestoreMeshLocation.X + FMath::RandRange(-Range, Range);
				RelativeLocation.Y = RestoreMeshLocation.Y + FMath::RandRange(-Range, Range);
				RelativeLocation.Z = RestoreMeshLocation.Z;

				MeshComp->SetRelativeLocation(RelativeLocation);
			}			
		}

		if (RequestReactionParams.bIsFrameHold && !ReactionRow.bAttackerFrameHoldOnly)
		{
			UAnimInstance* AnimInstance = Character.GetMesh() ? Character.GetMesh()->GetAnimInstance() : nullptr;
			if (AnimInstance && AnimInstance->GetActiveMontageInstance())
			{				
				if (AnimInstance->GetActiveMontageInstance()->IsPlaying())
				{
					AnimInstance->Montage_Pause(AnimInstance->GetCurrentActiveMontage());
				}
			}
		}

		FrameHoldInProgressTimeSeconds += DeltaSeconds;
	}
	else
	{
		FinishMeshShake(Character, ReactionRow);
	}		
}

void UP3CombatResponseComponent::FinishReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	UP3AnimInstance* AnimInstance = Character.GetMesh() ? Cast<UP3AnimInstance>(Character.GetMesh()->GetAnimInstance()) : nullptr;
	if (AnimInstance)
	{
		AnimInstance->SetPoseAssetAlpha(0.f);
		AnimInstance->ClearMorphTargets();
		AnimInstance->ClearCCDEffectLocation();
	}

	FinishMeshShake(Character, ReactionRow);
}

void UP3CombatResponseComponent::FinishMeshShake(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	if (ReactionRow.FrameHoldDurationSeconds > 0.f)
	{
		if (RequestReactionParams.bIsFrameHold)
		{
			UAnimInstance* AnimInstance = Character.GetMesh() ? Character.GetMesh()->GetAnimInstance() : nullptr;

			if (AnimInstance && !ReactionRow.bAttackerFrameHoldOnly)
			{
				AnimInstance->Montage_Resume(AnimInstance->GetCurrentActiveMontage());
			}

			AP3Character* AttackerCharacter = RequestReactionParams.AttackerActor ? Cast<AP3Character>(RequestReactionParams.AttackerActor) : nullptr;
			USkeletalMeshComponent* AttackerMeshComp = AttackerCharacter ? AttackerCharacter->GetMesh() : nullptr;
			UAnimInstance* AttackerAnimInstance = AttackerMeshComp ? AttackerMeshComp->GetAnimInstance() : nullptr;

			if (AttackerAnimInstance)
			{
				if (AttackerCharacter && AttackerCharacter->IsControlled())
				{
					AttackerAnimInstance->Montage_SetPlayRate(AttackerAnimInstance->GetCurrentActiveMontage(), 1.f);
				}
				else
				{
					AttackerAnimInstance->Montage_Resume(AttackerAnimInstance->GetCurrentActiveMontage());
				}
			}
		}

		if (bRestsoreMeshShake)
		{
			USkeletalMeshComponent* MeshComp = Character.GetMesh();
			if (MeshComp)
			{
				MeshComp->SetRelativeLocation(RestoreMeshLocation);
				bRestsoreMeshShake = false;
			}
		}
	}
}

void UP3CombatResponseComponent::FinishReactionMesh(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	if (ReactionRow.PhysicsBlendBoneDurationSeconds > 0.f)
	{
		USkeletalMeshComponent* MeshComp = Character.GetMesh();
		if (MeshComp)
		{
			MeshComp->SetAllBodiesPhysicsBlendWeight(0.f, false);
			MeshComp->SetAllBodiesSimulatePhysics(false);
		}
	}
}

const FP3CombatReactionRow* UP3CombatResponseComponent::GetReactionRow() const
{
	const UDataTable* FindReactionTable = ReactionTable.FindRef(RequestReactionParams.Layer);
	if (!ensure(FindReactionTable))
	{
		return nullptr;
	}

	const FP3CombatReactionRow* FindReactionRow = FindReactionTable->FindRow<FP3CombatReactionRow>(RequestReactionParams.ReactionName, "UP3CombatReactionHitPawnAction");
	if (!ensure(FindReactionRow))
	{
		return nullptr;
	}

	return FindReactionRow;
}
