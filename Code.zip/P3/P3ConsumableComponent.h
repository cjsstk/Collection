// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "P3ConsumableComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3ConsumableComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3ConsumableComponent();

	/**
	 * Interaction Lock
	 */
	bool Server_IsInteractionLocked() const { return Server_bIsInteractionLocked; }
	void Server_SetInteractionLock(class UP3PickupConsumablePawnAction* InLockerAction, bool bInInteractionLocked);

protected:
	virtual void BeginPlay() override;

private:
	/** If this is true, Can't interact  */
	bool Server_bIsInteractionLocked = false;

	/** This component locked by this action */
	UPROPERTY(Transient)
	UP3PickupConsumablePawnAction* LockerAction = nullptr;
};
