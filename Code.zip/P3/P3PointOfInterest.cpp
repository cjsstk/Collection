// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PointOfInterest.h"

#include "Engine/World.h"
#include "Components/ArrowComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/SphereComponent.h"
#include "DrawDebugHelpers.h"

#if WITH_EDITORONLY_DATA
#include "UObject/ConstructorHelpers.h"
#endif

#include "P3Core.h"
#include "P3World.h"

TAutoConsoleVariable<int32> CVarP3POIDebug(
	TEXT("p3.poiDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

TAutoConsoleVariable<float> CVarP3POIDuration(
	TEXT("p3.poiDuration"),
	10.0f,
	TEXT("Life time of POI actor"), ECVF_Default);

AP3PointOfInterest::AP3PointOfInterest()
{
	bNetLoadOnClient = false;

	USphereComponent* SphereComponent = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComponent"));
	RootComponent = SphereComponent;
	SphereComponent->InitSphereRadius(10.0f);
	SphereComponent->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	SphereComponent->GetBodyInstance()->SetObjectType(ECC_WorldStatic);
	SphereComponent->GetBodyInstance()->SetResponseToAllChannels(ECollisionResponse::ECR_Ignore);

	InitialLifeSpan = CVarP3POIDuration.GetValueOnGameThread();
	PrimaryActorTick.bCanEverTick = false;
	SetReplicates(false);

	EditorSprite = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorSprite"));

	OriginLocation = FVector::ZeroVector;

#if WITH_EDITORONLY_DATA
	if (!IsRunningCommandlet())
	{
		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> SpriteTextureObject;
			FConstructorStatics()
				: SpriteTextureObject(TEXT("/Engine/EditorResources/Waypoint"))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (EditorSprite)
		{
			EditorSprite->Sprite = ConstructorStatics.SpriteTextureObject.Get();
			EditorSprite->RelativeScale3D = FVector(1.0f);
			EditorSprite->bHiddenInGame = true;
			EditorSprite->SetupAttachment(RootComponent);
			EditorSprite->bAbsoluteScale = true;
			EditorSprite->bIsScreenSizeScaled = true;
		}
	}
#endif // WITH_EDITORONLY_DATA
}

void AP3PointOfInterest::SetOriginLocation(const FVector& Location)
{
	OriginLocation = Location;
}

const FVector& AP3PointOfInterest::GetOriginLocation() const
{
	return OriginLocation;
}

void AP3PointOfInterest::BeginPlay()
{
	Super::BeginPlay();

	if (OriginLocation.IsZero())
	{
		SetOriginLocation(GetActorLocation());
	}

	SpawnTimeSeconds = GetWorld()->GetTimeSeconds();

	if (CVarP3POIDebug.GetValueOnGameThread())
	{
		DrawDebugCrosshairs(GetWorld(), OriginLocation, GetActorRotation(), 100.0f, FColor::Blue, false, CVarP3POIDuration.GetValueOnGameThread(), 0);
		DrawDebugCrosshairs(GetWorld(), GetActorLocation(), GetActorRotation(), 100.0f, FColor::Red, false, CVarP3POIDuration.GetValueOnGameThread(), 0);

		DrawDebugDirectionalArrow(GetWorld(), OriginLocation, GetActorLocation(), 100.0f, FColor::Red, false, CVarP3POIDuration.GetValueOnGameThread(), 0, 2.0f);
	}

	UP3World* World = P3Core::GetP3World(*this);

	if (World)
	{
		World->AddToActorCache(GetClass(), this);
	}
}

void AP3PointOfInterest::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	UP3World* World = P3Core::GetP3World(*this);

	if (World)
	{
		World->RemoveFromActorCache(GetClass(), this);
	}
}
