// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3EffectTriggerComponent.h"

#include "Components/PrimitiveComponent.h"
#include "GameFramework/Actor.h"

#include "P3CharacterEffectComponent.h"
#include "P3Core.h"


UP3EffectTriggerComponent::UP3EffectTriggerComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3EffectTriggerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaTime);
	}
}

void UP3EffectTriggerComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3EffectTriggerComponent::Server_OverlappedActorAdded(AActor& Actor)
{
	Super::Server_OverlappedActorAdded(Actor);

	if (bIgnoreInstigator && GetOwner() && &Actor == GetOwner()->Instigator)
	{
		return;
	}

	UP3CharacterEffectComponent* EffectComp = Actor.FindComponentByClass<UP3CharacterEffectComponent>();
	if (EffectComp)
	{
		if (MaxDelayRandomTime == 0.0f)
		{
			EffectComp->Server_AddEffect(EffectType, *this);
			Server_AffectedActors.Add(&Actor);
		}
		else
		{
			const float RandomSecondsZeroToMax = FMath::RandRange(0.0f, MaxDelayRandomTime);
			Server_PendingActors.Add(FP3PendingActor({ &Actor, RandomSecondsZeroToMax }));
		}
	}
}

void UP3EffectTriggerComponent::Server_OverlappedActorRemoved(AActor& Actor)
{
	Super::Server_OverlappedActorRemoved(Actor);

	Server_PendingActors.RemoveAll([&Actor](const FP3PendingActor& PendingActor) -> bool
	{
		return PendingActor.Actor == &Actor;
	});

	if (!Server_AffectedActors.Contains(&Actor))
	{
		return;
	}

	UP3CharacterEffectComponent* EffectComp = Actor.FindComponentByClass<UP3CharacterEffectComponent>();
	if (EffectComp)
	{
		EffectComp->Server_RemoveEffect(EffectType, *this);

		Server_AffectedActors.Remove(&Actor);
	}
}

void UP3EffectTriggerComponent::Server_Tick(float DeltaTime)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_PendingActors.Num() > 0)
	{
		for (FP3PendingActor& PendingActor : Server_PendingActors)
		{
			if (!PendingActor.Actor)
			{
				continue;
			}
			PendingActor.EffectDelayTime -= DeltaTime;
			if (PendingActor.EffectDelayTime <= 0.0f)
			{
				UP3CharacterEffectComponent* EffectComp = (PendingActor.Actor)->FindComponentByClass<UP3CharacterEffectComponent>();
				if (EffectComp)
				{
					EffectComp->Server_AddEffect(EffectType, *this);
					Server_AffectedActors.Add(PendingActor.Actor);
				}
			}
		}

		// Remove actors that have get effect
		Server_PendingActors.RemoveAll([](const FP3PendingActor& PendingActor) {
			if (PendingActor.EffectDelayTime <= 0.0f)
			{
				return true;
			}

			return false;
		});
	}


}
