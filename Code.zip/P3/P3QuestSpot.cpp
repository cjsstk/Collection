// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3QuestSpot.h"

#include "Engine/World.h"
#include "Components/ArrowComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/SphereComponent.h"
#include "DrawDebugHelpers.h"

#include "P3World.h"

#if WITH_EDITORONLY_DATA
#include "UObject/ConstructorHelpers.h"
#endif

AP3QuestSpot::AP3QuestSpot()
{
	//bNetLoadOnClient = false; // levelSequence in client
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* SphereComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	RootComponent = SphereComponent;

#if WITH_EDITORONLY_DATA
	EditorSprite = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorSprite"));

	if (!IsRunningCommandlet())
	{
		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> SpriteTextureObject;
			FConstructorStatics()
				: SpriteTextureObject(TEXT("/Engine/EditorResources/S_Pickup"))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (EditorSprite)
		{
			EditorSprite->Sprite = ConstructorStatics.SpriteTextureObject.Get();
			EditorSprite->RelativeScale3D = FVector(1.0f);
			EditorSprite->bHiddenInGame = true;
			EditorSprite->SetupAttachment(RootComponent);
			EditorSprite->bAbsoluteScale = true;
			EditorSprite->bIsScreenSizeScaled = true;
		}
	}
#endif // WITH_EDITORONLY_DATA
}

void AP3QuestSpot::BeginPlay()
{
	Super::BeginPlay();

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->RegisterQuestActor(this);
	}
}

void AP3QuestSpot::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->UnregisterQuestActor(this);
	}

	Super::EndPlay(EndPlayReason);
}
