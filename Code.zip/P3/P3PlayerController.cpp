// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PlayerController.h"

#include "Blueprint/UserWidget.h"
#include "Components/Image.h"
#include "DrawDebugHelpers.h"
#include "Engine/NetConnection.h"
#include "Engine/World.h"
#include "Engine/WorldComposition.h"
#include "EngineUtils.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Application/NavigationConfig.h"
#include "GameFramework/PlayerStart.h"
#include "GameFramework/PlayerState.h"
#include "GameFramework/SpectatorPawn.h"
#include "TimerManager.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "Network/P3DediNet.h"
#include "Network/P3UDPMessage.h"
#include "Network/P3UnrealUDPNet.h"
#include "P3Character.h"
#include "P3ClientWorld.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3GameMode.h"
#include "P3GameUserSettings.h"
#include "P3HUD.h"
#include "P3Log.h"
#include "P3PickupableComponent.h"
#include "P3ServerWorld.h"
#include "P3Store.h"
#include "P3Weapon.h"
#include "P3World.h"
#include "Widget/P3BackpackInventoryWidget.h"
#include "Widget/P3BossTimerWidget.h"
#include "Widget/P3DamageMetersWidget.h"
#include "Widget/P3InGameActionWidget.h"
#include "Widget/P3SubtitleWidget.h"
#include "Widget/P3WalkieTalkieWidget.h"
#include "Widget/P3QuestListWidget.h"

extern TAutoConsoleVariable<int32> CVarP3ShowDamageMeter;

TAutoConsoleVariable<float> CVarP3PingUpdatePeriodSecondsDebug(
    TEXT("p3.pingUpdatePeriodSeconds"),
    3.0f,
    TEXT("Ping update period in seconds"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3LookForwardSeconds(
	TEXT("p3.lookForwardSeconds"),
	0.1f,
	TEXT("Look forward duration in seconds"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3LookForwardPitch(
	TEXT("p3.lookForwardPitch"),
	-30.0f,
	TEXT("Pitch when look forward in degree"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3ZoneDebug(
	TEXT("p3.zoneDebug"),
	0,
	TEXT("1: Debug player's zone location"), ECVF_Cheat);

void AP3PlayerController::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	TickLookForward();

	if (P3Core::IsP3NetModeClient(*this))
	{
		Client_TickSeamlessZoneConnection(DeltaSeconds);
		Client_TickSeamlessZoneConnection2(DeltaSeconds);
		Client_TickAttachAudioListenerToCharacter();
	}

	UP3DamageMetersWidget* DamageMeterWidget = GetDamageMetersWidget();
	
	if (DamageMeterWidget)
	{
		if (DamageMeterWidget->GetVisibility() != ESlateVisibility::Hidden
			&& CVarP3ShowDamageMeter.GetValueOnGameThread() == 0)
		{
			DamageMeterWidget->SetVisibility(ESlateVisibility::Hidden);
		}
		else if (DamageMeterWidget->GetVisibility() == ESlateVisibility::Hidden
			&& CVarP3ShowDamageMeter.GetValueOnGameThread() != 0)
		{
			DamageMeterWidget->SetVisibility(ESlateVisibility::HitTestInvisible);
		}
	}
}

bool AP3PlayerController::InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad)
{
	if (bIgnoreGamepad && bGamepad)
	{
		return false;
	}

	return Super::InputKey(Key, EventType, AmountDepressed, bGamepad);
}

bool AP3PlayerController::InputAxis(FKey Key, float Delta, float DeltaTime, int32 NumSamples, bool bGamepad)
{
	if (bIgnoreGamepad && bGamepad)
	{
		return false;
	}

	return Super::InputAxis(Key, Delta, DeltaTime, NumSamples, bGamepad);
}

void AP3PlayerController::AddPitchInput(float Val)
{
	if (bInvertCameraVertical)
	{
		Val *= -1.0f;
	}

	Super::AddPitchInput(Val);
}

void AP3PlayerController::DisplayDebug(class UCanvas* Canvas, const FDebugDisplayInfo& DebugDisplay, float& YL, float& YPos)
{

}

void AP3PlayerController::SetPawn(APawn* InPawn)
{
	Super::SetPawn(InPawn);
}

void AP3PlayerController::SetCinematicMode(bool bInCinematicMode, bool bHidePlayer, bool bAffectsHUD, bool bAffectsMovement, bool bAffectsTurning)
{
	Super::SetCinematicMode(bInCinematicMode, bHidePlayer, bAffectsHUD, bAffectsMovement, bAffectsTurning);

	ClientSetCinematicMode_Implementation(bCinematicMode, bAffectsMovement, bAffectsTurning, bAffectsHUD);

	ReceiveCinematicModeChanged(bInCinematicMode);
}

void AP3PlayerController::BeginPlay()
{
	Super::BeginPlay();

	{
		IConsoleCommand* Command = IConsoleManager::Get().RegisterConsoleCommand(
			TEXT("p3s"),
			TEXT("Run console command in server"),
			FConsoleCommandWithArgsDelegate::CreateUObject(this, &AP3PlayerController::OnServerConsoleCommand),
			ECVF_Cheat
		);

		ConsoleCommands.Add(Command);
	}

	{
		IConsoleCommand* Command = IConsoleManager::Get().RegisterConsoleCommand(
			TEXT("p3.gm"),
			TEXT("Send gm command"),
			FConsoleCommandWithArgsDelegate::CreateUObject(this, &AP3PlayerController::OnGMConsoleCommand),
			ECVF_Cheat
		);

		ConsoleCommands.Add(Command);
	}

	{
		IConsoleCommand* Command = IConsoleManager::Get().RegisterConsoleCommand(
			TEXT("p3.goto"),
			TEXT("<actor id>"),
			FConsoleCommandWithArgsDelegate::CreateUObject(this, &AP3PlayerController::OnGotoConsoleCommand),
			ECVF_Cheat
		);

		ConsoleCommands.Add(Command);
	}

	{
		IConsoleCommand* Command = IConsoleManager::Get().RegisterConsoleCommand(
			TEXT("p3.showContributionBoard"),
			TEXT(""),
			FConsoleCommandWithArgsDelegate::CreateUObject(this, &AP3PlayerController::OnShowContributionBoardCommand),
			ECVF_Cheat
		);

		ConsoleCommands.Add(Command);
	}

	TSharedRef<FNavigationConfig> Config = FSlateApplication::Get().GetNavigationConfig();
	Config.Get().bTabNavigation = false;

	FSlateApplication::Get().SetNavigationConfig(Config);
}

void AP3PlayerController::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	for (IConsoleCommand* Command : ConsoleCommands)
	{
		IConsoleManager::Get().UnregisterConsoleObject(Command);
	}

	ConsoleCommands.Empty();

	TSharedRef<FNavigationConfig> Config = FSlateApplication::Get().GetNavigationConfig();
	Config.Get().bTabNavigation = true;

	FSlateApplication::Get().SetNavigationConfig(Config);
}

float AP3PlayerController::GetPlayerStateExactPingBP() const
{
	if (PlayerState)
	{
		return PlayerState->ExactPing;
	}

	return -1.0f;
}

void AP3PlayerController::SetBlockInputBP(bool bInBlockInput)
{
	bBlockInput = bInBlockInput;

	if (InputComponent)
	{
		InputComponent->bBlockInput = bBlockInput;
	}
}

void AP3PlayerController::SetCursorMode(bool bEnableCursor)
{
	if (bEnableCursor)
	{
		FInputModeGameAndUI InputMode;
		InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::LockOnCapture);
		InputMode.SetHideCursorDuringCapture(true);

		bShowMouseCursor = true;
		SetInputMode(InputMode);
	}
	else
	{
		FInputModeGameOnly InputMode;
		InputMode.SetConsumeCaptureMouseDown(true);

		bShowMouseCursor = false;
		SetInputMode(InputMode);
	}
}

UP3DamageMetersWidget* AP3PlayerController::GetDamageMetersWidget() const
{
	UUserWidget* InGameActionWidget = GetInGameActionWidget();

	if (!InGameActionWidget)
	{
		return nullptr;
	}

	return Cast<UP3DamageMetersWidget>(InGameActionWidget->GetWidgetFromName(DamageMetersWidgetName));
}

class UP3QuestListWidget* AP3PlayerController::GetQuestListWidget() const
{
	UUserWidget* InGameActionWidget = GetInGameActionWidget();

	if (!InGameActionWidget)
	{
		return nullptr;
	}

	return Cast<UP3QuestListWidget>(InGameActionWidget->GetWidgetFromName(QuestListWidgetName));
}

class UP3WalkieTalkieWidget* AP3PlayerController::GetWalkieTalkieWidget() const
{
	UUserWidget* InGameActionWidget = GetInGameActionWidget();

	if (!InGameActionWidget)
	{
		return nullptr;
	}

	return Cast<UP3WalkieTalkieWidget>(InGameActionWidget->GetWidgetFromName(WalkieTalkieWidgetName));
}

UP3BossTimerWidget * AP3PlayerController::GetBossTimerWidget() const
{
	UUserWidget* InGameActionWidget = GetInGameActionWidget();

	if (!InGameActionWidget)
	{
		P3JsonLog(Error, "InGameActionWidget is not ready");
		return nullptr;
	}

	UP3BossTimerWidget* BossTimerWidget = Cast<UP3BossTimerWidget>(InGameActionWidget->GetWidgetFromName(BossTimerWidgetName));

	if (!BossTimerWidget)
	{
		P3JsonLog(Error, "BossTimerWidget is not ready");
	}

	return BossTimerWidget;
}

UImage * AP3PlayerController::GetMinimapImage() const
{
	UUserWidget* InGameActionWidget = GetInGameActionWidget();

	if (!InGameActionWidget)
	{
		return nullptr;
	}

	return Cast<UImage>(InGameActionWidget->GetWidgetFromName(MinimapWidgetName));
}

class UP3BackpackInventoryWidget* AP3PlayerController::GetBackpackInventoryWidget() const
{
	UUserWidget* InGameActionWidget = GetInGameActionWidget();

	if (!InGameActionWidget)
	{
		return nullptr;
	}

	return Cast<UP3BackpackInventoryWidget>(InGameActionWidget->GetWidgetFromName(BackpackInventoryWidgetName));
}

void AP3PlayerController::SetInputModeUIOnly(const UUserWidget& Requester, TSharedPtr<SWidget> WidgetToFocus)
{
	if (!ensure(!InputModeUIOnlyRequester))
	{
		P3JsonLog(Error, "Multiple SetInputModeUIOnly",
			TEXT("Old"), *InputModeUIOnlyRequester->GetFName().ToString(),
			TEXT("New"), *Requester.GetFName().ToString());
		return;
	}

	InputModeUIOnlyRequester = &Requester;

	FInputModeUIOnly InputMode;
	InputMode.SetWidgetToFocus(WidgetToFocus);
	SetInputMode(InputMode);
}

void AP3PlayerController::CancelInputModeUIOnly(const UUserWidget& Requester)
{
	if (!ensure(InputModeUIOnlyRequester))
	{
		P3JsonLog(Error, "No previous requester for CancelInputModeUIOnly",
			TEXT("New"), *Requester.GetFName().ToString());
		return;
	}

	if (!ensure(InputModeUIOnlyRequester == &Requester))
	{
		P3JsonLog(Error, "Different request for CancelInputModeUIOnly",
			TEXT("Old"), *InputModeUIOnlyRequester->GetFName().ToString(),
			TEXT("New"), *Requester.GetFName().ToString());
		return;
	}

	InputModeUIOnlyRequester = nullptr;

	// HACK: To focus on GameViewportClient. FSlateApplication::SetUserFocus does not work.
	SetInputMode(FInputModeGameOnly());

	// Return to previous input mode (GameOnly or GameAndUI)
	SetCursorMode(IsCursorMode());
}

void AP3PlayerController::SetSpectatorMode(bool bEnableSpectator)
{
	if (bEnableSpectator)
	{
		if (GetPawn())
		{
			Autonomouse_SpectatorMyPawn = GetPawn();
		}

		ASpectatorPawn* OldSpectatorPawn = GetSpectatorPawn();

		PlayerCameraManager->bClientSimulatingViewTarget = true;
		bAutoManageActiveCameraTarget = false;

		const FTransform PawnTransform = GetPawn() ? GetPawn()->GetActorTransform() : FTransform::Identity;

		ChangeState(NAME_Spectating);

		if (GetSpectatorPawn())
		{
			GetSpectatorPawn()->SetActorTransform(PawnTransform);

			AP3Character* AttachTarget = nullptr;
			AP3Character* AttachTargetFallback = nullptr;

			if (OldSpectatorPawn)
			{
				for (TActorIterator<AP3Character> Iter(GetWorld()); Iter; ++Iter)
				{
					AP3Character* TargetCharacter = *Iter;

					if (TargetCharacter == Autonomouse_SpectatorMyPawn)
					{
						continue;
					}

					if (!TargetCharacter->IsPlayerControlled())
					{
						continue;
					}

					if (AttachTargetFallback == nullptr)
					{
						AttachTargetFallback = TargetCharacter;
					}

					if (!SpectatorHistories.Contains(TargetCharacter))
					{
						AttachTarget = TargetCharacter;
						break;
					}
				}
			}

			GetSpectatorPawn()->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
			GetSpectatorPawn()->GetRootComponent()->bAbsoluteLocation = false;
			GetSpectatorPawn()->GetRootComponent()->bAbsoluteRotation = true;
			GetSpectatorPawn()->GetRootComponent()->bAbsoluteScale = true;

			AP3Character* FinalAttachTarget = AttachTarget ? AttachTarget : AttachTargetFallback;

			if (FinalAttachTarget)
			{
				if (!AttachTarget)
				{
					SpectatorHistories.Empty();
				}

				SpectatorHistories.Add(FinalAttachTarget);

				FAttachmentTransformRules AttachmentRule(EAttachmentRule::KeepWorld, EAttachmentRule::KeepWorld, EAttachmentRule::KeepWorld, false);

				//GetSpectatorPawn()->SetActorLocation(AttachTarget->GetActorLocation() + GetControlRotation().RotateVector(FVector(-1000, 0, 0)));
				GetSpectatorPawn()->SetActorLocation(FinalAttachTarget->GetActorLocation());
				GetSpectatorPawn()->SetActorRotation(GetControlRotation());
				GetSpectatorPawn()->AttachToActor(FinalAttachTarget, AttachmentRule);

				SetViewTarget(GetSpectatorPawn());
			}
		}
	}
	else
	{
		//SetViewTarget(Autonomouse_SpectatorMyPawn);

		PlayerCameraManager->bClientSimulatingViewTarget = false;
		bAutoManageActiveCameraTarget = true;
		
		OnPossess(Autonomouse_SpectatorMyPawn);

		Autonomouse_SpectatorMyPawn = nullptr;

		//ChangeState(NAME_Playing);

		//AutoManageActiveCameraTarget(this);
	}

	ServerSetSpectatorMode(bEnableSpectator);
}

bool AP3PlayerController::IsCursorMode() const
{
	return bShowMouseCursor;
}

void AP3PlayerController::LookForward(const FRotator& Rotation)
{
	bInLookingForward = true;
	LookForwardStartTimeSeconds = GetWorld()->GetTimeSeconds();
	LookForwardBeginRotation = GetControlRotation();
	LookForwardEndRotation = Rotation;
	LookForwardEndRotation.Pitch = CVarP3LookForwardPitch.GetValueOnGameThread();
}

void AP3PlayerController::TickLookForward()
{
	if (!bInLookingForward)
	{
		return;
	}

	float ElapsedSeconds = GetWorld()->GetTimeSeconds() - LookForwardStartTimeSeconds;
	float LookForwardSeconds = CVarP3LookForwardSeconds.GetValueOnGameThread();
	if (ElapsedSeconds >= LookForwardSeconds)
	{
		SetControlRotation(LookForwardEndRotation);
		bInLookingForward = false;
	}
	else
	{
		float Alpha = ElapsedSeconds / LookForwardSeconds;
		FRotator Rotation = FMath::Lerp(LookForwardBeginRotation, LookForwardEndRotation, Alpha);
		SetControlRotation(Rotation);
	}
}

UP3InGameActionWidget* AP3PlayerController::GetInGameActionWidget() const
{
	AP3HUD* P3HUD = Cast<AP3HUD>(GetHUD());
	if (P3HUD)
	{
		return P3HUD->GetInGameActionWidget();
	}

	return nullptr;
}

class UP3SubtitleWidget* AP3PlayerController::GetSubtitleWidget() const
{
	AP3HUD* P3HUD = Cast<AP3HUD>(GetHUD());
	if (P3HUD)
	{
		return P3HUD->GetSubtitleWidget();
	}

	return nullptr;
}

void AP3PlayerController::AddForbiddenVolume(class AP3ForbiddenVolume* Volume)
{
	ForbiddenVolumes.AddUnique(Volume);
}

void AP3PlayerController::RemoveForbiddenVolume(class AP3ForbiddenVolume* Volume)
{
	ForbiddenVolumes.Remove(Volume);
}

bool AP3PlayerController::IsInForbiddenVolume() const
{
	return (ForbiddenVolumes.Num() > 0);
}

int32 AP3PlayerController::GetPingTimeMsecBP() const
{
	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(GetGameInstance());
	if (!GameInstance)
	{
		return 0;
	}

	UP3DediNet* DediNet = GameInstance->GetDediNet();

	if (DediNet)
	{
		return DediNet->GetPingTimeMsec();
	}
	else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
	{
		return UDPNetwork->GetPingTimeMsec();
	}
	else
	{
		ensureMsgf(false, TEXT("No available network"));
	}

	return 0;
}

FDateTime AP3PlayerController::GetPingUpdatedTimeBP() const
{
	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(GetGameInstance());
	if (!GameInstance)
	{
		return FDateTime(0);
	}

	UP3DediNet* DediNet = GameInstance->GetDediNet();

	if (DediNet)
	{
		return DediNet->GetPingUpdatedTime();
	}
	else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
	{
		return UDPNetwork->GetPingUpdatedTime();
	}
	else
	{
		ensureMsgf(false, TEXT("No available network"));
	}

	return FDateTime(0);
}

float AP3PlayerController::GetServerFrameTimeMsec() const
{
	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(GetGameInstance());
	if (!GameInstance)
	{
		return 0.0f;
	}

	UP3DediNet* DediNet = GameInstance->GetDediNet();

	if (DediNet)
	{
		return DediNet->GetServerFrameTimeMsec();
	}
	else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
	{
		return UDPNetwork->GetServerFrameTimeMsec();
	}
	else
	{
		ensureMsgf(false, TEXT("No available network"));
	}

	return 0.0f;
}

void AP3PlayerController::Client_TickAttachAudioListenerToCharacter()
{
	if (!ensure(P3Core::IsP3NetModeClient(*this)))
	{
		return;
	}

	UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());
	if (UserSettings)
	{
		if (bAttachAudioListenerToCharacter == UserSettings->GetAudioListenerAttachToCharacter())
		{
			return;
		}

		bAttachAudioListenerToCharacter = UserSettings->GetAudioListenerAttachToCharacter();

		if (bAttachAudioListenerToCharacter)
		{
			AP3Character* PlayerCharacter = Cast<AP3Character>(GetPawn());
			if (PlayerCharacter)
			{
				SetAudioListenerOverride(PlayerCharacter->GetAudioListenerPositionComponent(), FVector::ZeroVector, FRotator::ZeroRotator);
			}
		}
		else
		{
			ClearAudioListenerOverride();
		}
	}
}

void AP3PlayerController::ReturnHome()
{
	FVector ReturnLocation;
	FRotator ReturnRotation;
	bool bReturnLocationFound = false;

	for (TActorIterator<APlayerStart> It(GetWorld()); It; ++It)
	{
		APlayerStart* Start = *It;
		
		if (Start)
		{
			bReturnLocationFound = true;
			ReturnLocation = Start->GetActorLocation();
			ReturnRotation = Start->GetActorRotation();
			break;
		}
	}

	if (bReturnLocationFound)
	{
		AP3Character* MyCharacter = Cast<AP3Character>(GetPawn());

		if (MyCharacter)
		{
			if (P3Core::IsConnectedToDedi(this))
			{
				UP3CommandComponent* CommandComp = MyCharacter->GetCommandComponent();
				if (ensure(CommandComp))
				{
					FP3CommandRequestParams Params;
					Params.Teleport_Location = ReturnLocation;
					Params.Teleport_Rotation = ReturnRotation;
					CommandComp->RequestCommand(UP3TeleportCommand::StaticClass(), Params);
				}
			}
			else
			{
				MyCharacter->SetActorLocationAndRotation(ReturnLocation, ReturnRotation);

				GEngine->BlockTillLevelStreamingCompleted(GetWorld());
			}
		}
	}
}

void AP3PlayerController::OnChangeWeapon(class UP3HolderComponent* HolderComponent, AActor* HoldingActor)
{
	AP3Weapon* Weapon = Cast<AP3Weapon>(HoldingActor);

	if (Weapon)
	{
		const FP3CmsItem& ItemDesc = P3Cms::GetItem(P3Cms::GetItemKeyFromActorClass(Weapon->GetClass()));
		ToastMessageBP(ItemDesc.DisplayName);
	}
}

void AP3PlayerController::OnPickup(AActor* PickupedActor)
{
	if (PickupedActor)
	{
		const UP3PickupableComponent* PickupableComp = PickupedActor->FindComponentByClass<UP3PickupableComponent>();

		if (PickupableComp)
		{
			ToastMessageBP(PickupableComp->GetPickupableDisplayName());
		}
	}
}

void AP3PlayerController::ToastMessageBP(const FText& Message)
{
	UP3InGameActionWidget* InGameActionWidget = GetInGameActionWidget();

	if (InGameActionWidget)
	{
		InGameActionWidget->ToastMessage(Message);
	}
}

void AP3PlayerController::ShowContributionBoard(bool bShow)
{
	UP3InGameActionWidget* InGameActionWidget = GetInGameActionWidget();

	if (InGameActionWidget)
	{
		InGameActionWidget->ShowContributionBoard(bShow);
	}
}

void AP3PlayerController::AddMenuWidget(class UP3MenuWidget* MenuWidget)
{
	MenuWidgets.AddUnique(MenuWidget);
}

void AP3PlayerController::RemoveMenuWidget(class UP3MenuWidget* MenuWidget)
{
	MenuWidgets.Remove(MenuWidget);
}

bool AP3PlayerController::ServerSetSpectatorMode_Validate(bool bEnableSpectator)
{
	return true;
}

void AP3PlayerController::ServerSetSpectatorMode_Implementation(bool bEnableSpectator)
{
	if (bEnableSpectator)
	{
		if (GetPawn())
		{
			Server_SpectatorMyPawn = GetPawn();
		}

		ChangeState(NAME_Spectating);

		if (Role == ROLE_Authority && PlayerState != NULL)
		{
			PlayerState->bIsSpectator = true;
		}
	}
	else
	{
		ChangeState(NAME_Playing);

		if (Role == ROLE_Authority && PlayerState != NULL)
		{
			PlayerState->bIsSpectator = false;
		}

		Possess(Server_SpectatorMyPawn);

		Server_SpectatorMyPawn = nullptr;
	}
}

void AP3PlayerController::CheatSpawnWeapon(const FName& AssetName)
{
	P3JsonLog(Display, "[Cheat] SpawnWeapon", TEXT("AssetName"), *AssetName.ToString());

	TArray<FString> Args;
	Args.Add("spawnWeapon");
	Args.Add(AssetName.ToString());
	OnGMConsoleCommand(Args);
}

void AP3PlayerController::CheatGetItemPackage(const FName& AssetName)
{
	P3JsonLog(Display, "[Cheat] GetItemPackage", TEXT("AssetName"), *AssetName.ToString());

	TArray<FString> Args;
	Args.Add("getItemPackage");
	Args.Add(AssetName.ToString());
	OnGMConsoleCommand(Args);
}

void AP3PlayerController::OnServerConsoleCommand(const TArray<FString>& Args)
{
	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(GetGameInstance());

	if (!ensure(GameInstance))
	{
		return;
	}

	FString Command = FString::Join(Args, TEXT(" "));

	UP3DediNet* DediNet = GameInstance->GetDediNet();

	if (DediNet)
	{
		DediNet->SendConsoleCommand(Command);
	}
	else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
	{
		UDPNetwork->SendConsoleCommand(Command);
	}
}

void AP3PlayerController::OnGMConsoleCommand(const TArray<FString>& Args)
{
	FP3NetGMCommand Packet;
	Packet.Args = Args;

	UP3World* P3World = P3Core::GetP3World(*this);

	if (P3World)
	{
		P3World->Client_SendPacketReliable((UP3ServerWorld*)(nullptr), INVALID_ACTORID, nullptr, Packet, EP3NetComponentType::ServerWorld, &UP3ServerWorld::HandleGMCommand);
	}
}

void AP3PlayerController::OnGotoConsoleCommand(const TArray<FString>& Args)
{
	if (Args.Num() != 1)
	{
		UE_LOG(P3Log, Warning, TEXT("usage: <actor id / character name>"));
		return;
	}

	const int64 ActorId = FCString::Atoi64(*Args[0]);

	UP3World* P3World = P3Core::GetP3World(*this);
	if (!ensure(P3World))
	{
		P3JsonLog(Warning, "No world");
		return;
	}

	AActor* Actor = P3World->GetActorFromActorId(ActorId);
	if (!Actor)
	{
		UP3ClientWorld* ClientWorld = P3World->GetClientWorld();
		Actor = ClientWorld ? ClientWorld->FindPlayerCharacterByName(FText::AsCultureInvariant(Args[0])) : nullptr;

		if (!Actor)
		{
			P3JsonLog(Warning, "No actor");
			return;
		}
	}

	const FVector Location = Actor->GetActorLocation();

	AP3Character* P3Character = Cast<AP3Character>(GetPawn());
	if (!P3Character)
	{
		P3JsonLog(Warning, "No controlled Character");
		return;
	}

	if (!P3Character->GetCommandComponent())
	{
		P3JsonLog(Warning, "No command component");
		return;
	}

	P3JsonLog(Display, "Executing Goto command",
		TEXT("Target Actor Id"), ActorId,
		TEXT("Target Actor"), Actor->GetName(),
		TEXT("Target Location"), Location.ToString());

	FP3CommandRequestParams Params;
	Params.Teleport_Location = Location;

	P3Character->GetCommandComponent()->RequestCommand(UP3TeleportCommand::StaticClass(), Params);
}

void AP3PlayerController::OnShowContributionBoardCommand(const TArray<FString>& Args)
{
	ShowContributionBoard(true);
}

void AP3PlayerController::Client_TickSeamlessZoneConnection(float DeltaSeconds)
{
	ensure(P3Core::IsP3NetModeClient(*this));

	if (!GetWorld() || !GetWorld()->WorldComposition)
	{
		return;
	}

	if (!NetConnection)
	{
		return;
	}

	const APawn* MyPawn = GetPawn();
	if (!MyPawn)
	{
		return;
	}

	// Note: reference @ UWorldComposition::GetDistanceVisibleLevels

	const UWorld* World = GetWorld();
	const FVector& PawnLocation = MyPawn->GetActorLocation();
	const FIntPoint WorldOriginLocationXY(World->OriginLocation.X, World->OriginLocation.Y);

	TArray<TPair<FString, int32>> PackageToPorts;
	PackageToPorts.Add(TPair<FString, int32>(TEXT("marianople"), 7777));
	PackageToPorts.Add(TPair<FString, int32>(TEXT("twocrowns"), 7778));

	int32 TargetPort = -1;

	for (int32 TileIdx = 0; TileIdx < GetWorld()->WorldComposition->GetTilesList().Num(); ++TileIdx)
	{
		const FWorldCompositionTile& Tile = GetWorld()->WorldComposition->GetTilesList()[TileIdx];

		FIntPoint LevelPositionXY = FIntPoint(Tile.Info.AbsolutePosition.X, Tile.Info.AbsolutePosition.Y);
		FIntPoint LevelOffsetXY = LevelPositionXY - WorldOriginLocationXY;
		FBox LevelBounds = Tile.Info.Bounds.ShiftBy(FVector(LevelOffsetXY));

		// We don't care about third dimension yet
		LevelBounds.Min.Z = -WORLD_MAX;
		LevelBounds.Max.Z = +WORLD_MAX;
		
		const bool bIntersected = FMath::PointBoxIntersection(PawnLocation, LevelBounds);

		FColor DrawColor = bIntersected ? FColor::Green : FColor::Red;
		DrawColor.A = 100;
		LevelBounds.Min.Z = PawnLocation.Z - 10000;
		LevelBounds.Max.Z = PawnLocation.Z + 10000;

		DrawDebugSolidBox(World, LevelBounds, DrawColor);

		if (bIntersected)
		{
			//ULevelStreaming* StreamingLevel = GetWorld()->WorldComposition->TilesStreaming[TileIdx];

			for (auto&& Iter : PackageToPorts)
			{
				if (Tile.PackageName.ToString().Contains(Iter.Get<0>()))
				{
					TargetPort = Iter.Get<1>();
				}
			}
		}
	}

	if (TargetPort != -1 && NetConnection->URL.Port != TargetPort)
	{
		const FIntVector WorldLocation = FIntVector(PawnLocation) + FIntVector(WorldOriginLocationXY.X, WorldOriginLocationXY.Y, 0);
		const FRotator PawnRotation = MyPawn->GetActorRotation();

		ClientTravel(FString::Printf(TEXT("127.0.0.1:%d?PosX=%d?PosY=%d?PosZ=%d?RotX=%d?RotY=%d?RotZ=%d?CRotX=%d?CRotY=%d?CRotZ=%d"),
			TargetPort, WorldLocation.X, WorldLocation.Y, WorldLocation.Z,
			FMath::RoundToInt(PawnRotation.Roll), FMath::RoundToInt(PawnRotation.Pitch), FMath::RoundToInt(PawnRotation.Yaw),
			FMath::RoundToInt(ControlRotation.Roll), FMath::RoundToInt(ControlRotation.Pitch), FMath::RoundToInt(ControlRotation.Yaw)),
			TRAVEL_Absolute);
	}
}

void AP3PlayerController::Client_TickSeamlessZoneConnection2(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeClient(*this)))
	{
		return;
	}

	if (!GetWorld() || !GetWorld()->WorldComposition)
	{
		return;
	}

	APawn* MyPawn = GetPawn();
	if (!MyPawn)
	{
		return;
	}

	if (CVarP3ZoneDebug.GetValueOnGameThread() != 0)
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(MyPawn);
		if (P3ActorInterface)
		{
			UP3World* P3World = P3Core::GetP3World(*this);

			if (ensure(P3World))
			{
				UP3GameInstance* GameInstance = P3World->GetGameInstance();

				if (ensure(GameInstance))
				{
					const FName ZoneName = P3World->GetZoneFromLocation(MyPawn->GetActorLocation());
					P3ActorInterface->AddDebugString(FString::Printf(TEXT("Zone by Location: %s"), *ZoneName.ToString()));

					UP3DediNet* DediNet = P3GetDediNet(this);

					if (DediNet)
					{
						P3ActorInterface->AddDebugString(FString::Printf(TEXT("Connected Zone: %s"), *DediNet->GetZone().ToString()));
					}
					else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
					{
						P3ActorInterface->AddDebugString(FString::Printf(TEXT("Connected Zone: %s"), *UDPNetwork->GetZone().ToString()));
					}
					else
					{
						checkf(0, TEXT("No available network"));
					}
				}
			}
		}
	}
}
