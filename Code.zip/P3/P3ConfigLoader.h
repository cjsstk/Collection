// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3ConfigLoader.generated.h"

USTRUCT()
struct FP3ConfigJson
{
	GENERATED_BODY()

	UPROPERTY()
	FString NetStatUpdatePeriod;
};

class FP3ConfigLoader : FNoncopyable
{
public:
	static bool LoadConfigFile(const FString& Path = "");
	static bool ReloadConfigFile(const FString& Path = "");

private:
	static FString GetJsonFilePath(const FString& FilePath, const FString& FileName);

	static void ParseJsonValues(const FString& Key, const TSharedPtr<class FJsonValue>& JsonValue);

	FP3ConfigLoader() = delete;

	static const char* P3JsonFileNames[];
};
