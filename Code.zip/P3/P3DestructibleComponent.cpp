// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3DestructibleComponent.h"

#include "DestructibleActor.h"
#include "DestructibleComponent.h"
#include "DrawDebugHelpers.h"
#include "Kismet/GameplayStatics.h"
#include "MessageLog.h"
#include "Particles/ParticleSystemComponent.h"
#include "PhysXPublic.h"
#include "TimerManager.h"

#include "Character/P3SurfaceEffectComponent.h"
#include "Chemical/P3Chemical.h"
#include "P3BlueprintFunctionLibrary.h"
#include "P3Combat.h"
#include "P3Core.h"
#include "P3HealthPointComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3Physics.h"
#include "P3Projectile.h"
#include "P3World.h"
#include "P3WorldNetCore.h"

extern TAutoConsoleVariable<int32> CVarP3DestructibleFallingDurationSeconds;

const static FName DestructibleCollisionProfileName(TEXT("BlockAllDynamic"));

UP3DestructibleComponent::UP3DestructibleComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;

	bWantsInitializeComponent = true;

	SetCollisionProfileName(DestructibleCollisionProfileName);
	SetCollisionObjectType(ECC_Destructible);
	SetGenerateOverlapEvents(true);
	Mobility = EComponentMobility::Movable;
	bUseDefaultCollision = false;
	SetSimulatePhysics(true);
	GetBodyInstance()->bNotifyRigidBodyCollision = true;
	SetUseCCD(true);
}

void UP3DestructibleComponent::InitializeComponent()
{
	Super::InitializeComponent();

	if (bStatic)
	{
		SetSimulatePhysics(false);
	}
	else
	{
		SetSimulatePhysics(true);
	}
}

void UP3DestructibleComponent::BeginPlay()
{
	Super::BeginPlay();

	DefaultStaticMesh = GetStaticMesh();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (HealthPoint > 0)
		{
			Server_CreateHealthPointComponent();
		}

		//Server_SetSleep(true);

		AActor* OwnerActor = GetOwner();

		if (OwnerActor)
		{
			OwnerActor->OnActorHit.AddUniqueDynamic(this, &UP3DestructibleComponent::Server_OnActorHit);
		}
	}

	if (RemainStaticMesh && OwnerActorLifespanAfterFracture != 0.0f)
	{
		FMessageLog("PIE").Warning(FText::Format(FText::AsCultureInvariant(TEXT("Remain Static 메시가 설정되었지만 OwnerActorLifespanAfterFracture 값이 0이 아닙니다. 파일: '{0}'")), FText::AsCultureInvariant(GetPathName())));
	}
}

void UP3DestructibleComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (DestructibleActor)
	{
		FractureAgeSeconds += DeltaTime;

		if (FractureAgeSeconds > DebrisLifespan)
		{
			// Start fade out debris
			//DestructibleActor->GetDestructibleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			//DestructibleActor->AddActorWorldOffset(FVector(0, 0, DeltaTime * -100.0f));

			// Let debris fall through
			if (DestructibleActor->GetDestructibleComponent()
				&& DestructibleActor->GetDestructibleComponent()->GetBodyInstance())
			{
				FCollisionResponseContainer CollisionResponse;
				CollisionResponse.SetAllChannels(ECR_Ignore);

				//DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannels(CollisionResponse);

				DestructibleActor->GetDestructibleComponent()->SetCollisionResponseToAllChannels(ECR_Ignore);

#if WITH_APEX
				if (DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor)
				{
					FPhysScene* PhysScene = GetWorld()->GetPhysicsScene();
					PxScene* PScene = PhysScene->GetPxScene();

					SCOPED_SCENE_WRITE_LOCK(PScene);

					PxRigidDynamic** PActorBuffer = NULL;
					PxU32 PActorCount = 0;
					if (DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor->acquirePhysXActorBuffer(PActorBuffer, PActorCount))
					{
						for (uint32 ActorIdx = 0; ActorIdx < PActorCount; ++ActorIdx)
						{
							PxRigidDynamic* PActor = PActorBuffer[ActorIdx];
							if (FApexDestructionCustomPayload* ChunkInfo = (FApexDestructionCustomPayload*)FPhysxUserData::Get<FCustomPhysXPayload>(PActor->userData))	 // -V1027
							{
								DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor->setChunkPhysXActorAwakeState(ChunkInfo->ChunkIndex, true);
							}
						}
						DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor->releasePhysXActorBuffer();
					}


				}
#endif
			}
		}

		if (GIsClient && DestructibleActor)
		{
			for (auto&& Iter : Client_DebrisParticles)
			{
				UParticleSystemComponent* ParticleComp = Iter.Key;
				const FName SocketName = Iter.Value;

				const FVector CenterOfMass = DestructibleActor->GetDestructibleComponent()->GetCenterOfMass(SocketName);

				ParticleComp->SetWorldLocation(CenterOfMass);
			}
		}
	}
}

void UP3DestructibleComponent::NetSerialize(FArchive& Archive)
{
	// TODO ..
}

void UP3DestructibleComponent::SetupDestructible(bool bInStatic, int32 InHealthPoint, float InOwnerActorLifespanAfterFracture)
{
	if (ensureMsgf(!bRegistered, TEXT("SetupDestructible should only be used to initialize Destructible before register")))
	{
		bStatic = bInStatic;
		HealthPoint = InHealthPoint;
		OwnerActorLifespanAfterFracture = InOwnerActorLifespanAfterFracture;

		if (bStatic)
		{
			SetSimulatePhysics(false);
		}
	}
}

void UP3DestructibleComponent::OverrideDebrisCollisionResponse(const FCollisionResponseContainer& Response)
{
	bOverrideDebrisCollisionResponse = true;
	DebrisCollisionResponses = Response;
}

#if WITH_EDITOR

void UP3DestructibleComponent::CheckForErrors()
{
	Super::CheckForErrors();

	if (RemainStaticMesh && OwnerActorLifespanAfterFracture != 0.0f)
	{
		FMessageLog("MapCheck").Warning(FText::Format(FText::AsCultureInvariant(TEXT("Remain Static 메시가 설정되었지만 OwnerActorLifespanAfterFracture 값이 0이 아닙니다. 파일: '{0}'")), FText::AsCultureInvariant(GetPathName())));
	}
}

#endif

void UP3DestructibleComponent::Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_bFractured || !bEnableDestruction)
	{
		return;
	}

	if (MinImpulseSizeToFracture < 0)
	{
		return;
	}

	if (Server_HitIgnoreActors.Contains(OtherActor))
	{
		return;
	}

	AP3Projectile* OtherProjectile = Cast<AP3Projectile>(OtherActor);

	if (OtherProjectile)
	{
		UPrimitiveComponent* ProjectilePrimComp = Cast<UPrimitiveComponent>(OtherProjectile->GetRootComponent());

		if (ProjectilePrimComp)
		{
			ProjectilePrimComp->GetBodyInstance()->UpdateMassProperties();

			const FVector Velocity = OtherProjectile->GetVelocity();
			const float Mass = ProjectilePrimComp->CalculateMass();
			NormalImpulse = Hit.Normal * (Velocity.Size() * Mass);
		}
	}

	const float NormalImpulseSizeSquared = NormalImpulse.SizeSquared();

	if (NormalImpulseSizeSquared >= FMath::Square(MinImpulseSizeToFracture))
	{
		const float ImpulseSize = FMath::Sqrt(NormalImpulseSizeSquared);

		Server_Fracture(Hit.Location, Hit.Normal, ImpulseSize);
	}
}

int32 UP3DestructibleComponent::CalcDamagedMeshIndex(int32 HealthPoint, int32 MaxHealthPoint, int32 NumDamagedMeshes)
{
	if (HealthPoint == MaxHealthPoint)
	{
		return -1;
	}

	if (HealthPoint == 0)
	{
		return NumDamagedMeshes;
	}

	const float HealthRatio = (float)HealthPoint / MaxHealthPoint;
	const float HealthStep = HealthRatio * (NumDamagedMeshes + 1);
	int32 NewDamagedMeshIndex = FMath::Clamp(FMath::FloorToInt(HealthStep) - 1, 0, NumDamagedMeshes);

	// We invert this since it's more intuitive to editor UI
	NewDamagedMeshIndex = NumDamagedMeshes - 1 - NewDamagedMeshIndex;

	return NewDamagedMeshIndex;
}

void UP3DestructibleComponent::Server_CreateHealthPointComponent()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();
	ensure(OwnerActor);

	HealthPointComponent = NewObject<UP3HealthPointComponent>(OwnerActor, UP3HealthPointComponent::StaticClass(), TEXT("DSHealthPointComponent"));
	if (ensure(HealthPointComponent))
	{
		HealthPointComponent->RegisterComponent();
		HealthPointComponent->Server_SetServerOnly(true);
		HealthPointComponent->SetMaxHealthPoint(HealthPoint);
		HealthPointComponent->SetHealthPoint(HealthPoint);
		HealthPointComponent->OnChange.AddUniqueDynamic(this, &UP3DestructibleComponent::Server_OnHealthChanged);
	}
}

void UP3DestructibleComponent::Server_OnHealthChanged(class UP3HealthPointComponent* InHealthPointComponent, int32 OldHealthPoint, int32 NewHealthPoint)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	ensure(InHealthPointComponent == HealthPointComponent);

	if (!Server_bFractured)
	{
		if (NewHealthPoint == 0)
		{
			ensure(bEnableDestruction);

			Server_Fracture(GetComponentLocation(), FVector(0, 0, 1), 100000);
		}
		else
		{
			if (DamagedStaticMeshes.Num() > 0 && InHealthPointComponent && InHealthPointComponent->GetMaxHealthPoint() > 0)
			{
				const int32 NewDamagedMeshIndex = CalcDamagedMeshIndex(NewHealthPoint, InHealthPointComponent->GetMaxHealthPoint(), DamagedStaticMeshes.Num());

				if (Net_DamagedMeshIndex != NewDamagedMeshIndex)
				{
					Net_DamagedMeshIndex = NewDamagedMeshIndex;

					DamagedMeshIndexChanged();

					Server_SetDirty(*this);
				}
			}
		}
	}
}

void UP3DestructibleComponent::DamagedMeshIndexChanged()
{
	if (Net_DamagedMeshIndex == -1)
	{
		SetStaticMesh(DefaultStaticMesh);
	}
	else if (ensure(DamagedStaticMeshes.IsValidIndex(Net_DamagedMeshIndex)))
	{
		SetStaticMesh(DamagedStaticMeshes[Net_DamagedMeshIndex]);
	}
}

void UP3DestructibleComponent::Server_Fracture(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		ensure(0);
		return;
	}

	if (!bEnableDestruction)
	{
		ensure(0);
		return;
	}

	if (Server_bFractured)
	{
		ensure(0);
		return;
	}

	// Too much impulse makes look ugly, like fractured parts shooting into air in a blink of eyes
	ImpulseStrength = FMath::Min(ImpulseStrength, 1000.0f);

	Server_bFractured = true;

	AActor* OwnerActor = GetOwner();

	if (Damage != 0 && OwnerActor)
	{
		P3Combat::Server_Explode(*OwnerActor, GetComponentLocation(), DamageRadius, Damage, DamageToAllyPermil, HitActionImpulseSpeed, bKnockDown, KnockDownDurationSeconds, Server_ExplosionIgnoreActors);
	}

	if (bBurn)
	{
		UP3BlueprintFunctionLibrary::Server_BurnAround(this, GetComponentLocation(), DamageRadius, BurnPower, TArray<AActor*>(), this);
	}

	if (bWaterSplash)
	{
		P3Chemical::Server_SplashWater(*this, GetComponentLocation(), DamageRadius);

		if (WaterPuddleActorClass.Get())
		{
			FActorSpawnParameters ActorSpawnParams;
			ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			GetWorld()->SpawnActor<AActor>(WaterPuddleActorClass.Get(), GetComponentLocation(), GetComponentRotation(), ActorSpawnParams);
		}
	}

	if (OwnerActorLifespanAfterFracture > 0 && GetOwner())
	{
		GetOwner()->SetLifeSpan(OwnerActorLifespanAfterFracture);
	}

	UP3World* P3World = P3Core::GetP3World(*this);
	check(P3World);

	const actorid ActorId = GetOwnerActorId(*this);

	ensure(ActorId != INVALID_ACTORID);

	FNetFracture NetFracture;
	NetFracture.HitLocation = HitLocation;
	NetFracture.ImpulseDir = ImpulseDir;
	NetFracture.ImpulseStrength = ImpulseStrength;

	P3World->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetFracture, EP3NetComponentType::Destructible, &UP3DestructibleComponent::Client_Fractured);

	Multicast_Fracture(HitLocation, ImpulseDir, ImpulseStrength);

	//P3World->Server_FireScareFlockEvent(GetActorLocation(), DamageRadius * 3, 3.0f);
}

void UP3DestructibleComponent::Multicast_Fracture(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("Destructible_Explode"), STAT_Destructible_Explode, STATGROUP_P3);

	if (Multicast_bFractured)
	{
		ensure(0);
		return;
	}

	Multicast_bFractured = true;

	const FVector Velocity = GetPhysicsLinearVelocity();

	if (RemainStaticMesh)
	{
		SetStaticMesh(RemainStaticMesh);
	}
	else
	{
		SetVisibility(false, true);
	}

	SetSimulatePhysics(false);
	SetCollisionEnabled(ECollisionEnabled::NoCollision);

	if (FractureSound)
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), FractureSound, GetComponentLocation());
	}

	if (FractureParticle)
	{
		FTransform ExplosionTransform = GetComponentTransform();
		ExplosionTransform.MultiplyScale3D(FVector(FractureParticleScale));

		if (DoesSocketExist(FractureParticle_SocketName))
		{
			const FVector SocketWorldLocation = GetSocketTransform(FractureParticle_SocketName, ERelativeTransformSpace::RTS_World).GetTranslation();
			ExplosionTransform.SetTranslation(SocketWorldLocation);
		}
		else
		{
			P3JsonLog(Warning, "There is no name of socket in the static mesh.", TEXT("Socket Name"), FractureParticle_SocketName.ToString(), TEXT("Component Owner"), GetOwner()->GetName());
		}

		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), FractureParticle, ExplosionTransform);
	}

	DestructibleActor = GetWorld()->SpawnActorDeferred<ADestructibleActor>(ADestructibleActor::StaticClass(), GetComponentTransform(), nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AlwaysSpawn);

	if (ensure(DestructibleActor))
	{
		if (bOverrideDebrisCollisionResponse)
		{
			DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannels(DebrisCollisionResponses);
		}

		if (bUseSurfaceHitEffectOnDebris)
		{
			DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->bNotifyRigidBodyCollision = true;
		}
		DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_Pawn, ECR_Ignore);
		DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_CLIMB, ECR_Ignore);
		DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_Camera, ECR_Ignore);
		DestructibleActor->GetDestructibleComponent()->SetPhysicsLinearVelocity(Velocity);
		DestructibleActor->GetDestructibleComponent()->SetDestructibleMesh(DestructableMesh);
		DestructibleActor->GetDestructibleComponent()->SetSimulatePhysics(!bStatic);
		DestructibleActor->FinishSpawning(GetComponentTransform());

		// Health Point based destruction use Actor location as Hit Location and that location could be empty space when mesh is concave.
		// So, we need to use max radius to make sure fracture actually happens
		const float BoundingSphereRadius = DestructibleActor->GetDestructibleComponent()->Bounds.SphereRadius
			+ (DestructibleActor->GetDestructibleComponent()->Bounds.Origin - DestructibleActor->GetDestructibleComponent()->GetComponentLocation()).Size();

		DestructibleActor->GetDestructibleComponent()->ApplyRadiusDamage(FractureDamage, HitLocation, BoundingSphereRadius, ImpulseStrength * DestructibleImpulseMultiplier, true);

		DestructibleActor->SetLifeSpan(DebrisLifespan + CVarP3DestructibleFallingDurationSeconds.GetValueOnGameThread());

		SetComponentTickEnabled(true);

		if (GIsClient && DebrisParticle)
		{
			const TArray<FName> SocketNames = DestructibleActor->GetDestructibleComponent()->GetAllSocketNames();

			for (const FName& SocketName : SocketNames)
			{
				const FVector CenterOfMass = DestructibleActor->GetDestructibleComponent()->GetCenterOfMass(SocketName);
				const FTransform SocketTransform = DestructibleActor->GetDestructibleComponent()->GetSocketTransform(SocketName);
				const FVector LocalCenterOfMass = SocketTransform.InverseTransformPosition(CenterOfMass);

				//UGameplayStatics::SpawnEmitterAttached(DebrisParticle, DestructibleActor->GetDestructibleComponent(), SocketName, LocalCenterOfMass, FRotator::ZeroRotator, FVector(DebrisParticleScale), EAttachLocation::KeepRelativeOffset);

				UParticleSystemComponent* ParticleComp = UGameplayStatics::SpawnEmitterAttached(DebrisParticle, DestructibleActor->GetDestructibleComponent(), SocketName, CenterOfMass, FRotator::ZeroRotator, FVector(DebrisParticleScale), EAttachLocation::KeepWorldPosition);

				if (ParticleComp)
				{
					Client_DebrisParticles.Add(ParticleComp, SocketName);
				}
			}
		}
	}

	if (GIsClient && bUseSurfaceHitEffectOnDebris)
	{
		UP3SurfaceHitEffectComponent* HitEffectComp = NewObject<UP3SurfaceHitEffectComponent>(DestructibleActor, TEXT("HitEffectComponent"));

		if (HitEffectComp)
		{
			HitEffectComp->RegisterComponent();
			HitEffectComp->SetParticleScale(SurfaceHitEffectSizeScale);
		}
	}

	DestructibleFractured.Broadcast(this);

	if (!DestructibleActor && OwnerActorLifespanAfterFracture > 0 && GetOwner())
	{
		GetOwner()->Destroy();
	}
}

void UP3DestructibleComponent::Client_Fractured(const FP3DediToClientHandlerParams& Params)
{
	FNetFracture NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		Multicast_Fracture(NetParams.HitLocation, NetParams.ImpulseDir, NetParams.ImpulseStrength);
	}
}
