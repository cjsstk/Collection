// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3FruitComponent.h"
#include "P3Core.h"
#include "P3Tree.h"
#include "P3World.h"
#include "Components/StaticMeshComponent.h"

void UP3FruitComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (SpawnChancePer10000 < 10000)
		{
			const int32 Dice = FMath::Rand() % 10000;

			if (Dice >= SpawnChancePer10000)
			{
				Server_bDespawn = true;

				GetWorld()->GetTimerManager().SetTimerForNextTick(FTimerDelegate::CreateUObject(this, &UP3FruitComponent::Server_Despawn));
			}
		}

		if (!Server_bDespawn)
		{
			AActor* OwnerActor = GetOwner();
	
			if (OwnerActor)
			{
				OwnerActor->OnTakeAnyDamage.AddUniqueDynamic(this, &UP3FruitComponent::Server_OnTreeTakeAnyDamage);
			}

			AActor* MyChildActor = GetChildActor();

			if (MyChildActor)
			{
				MyChildActor->OnTakeAnyDamage.AddUniqueDynamic(this, &UP3FruitComponent::Server_OnFruitTakeAnyDamage);
			}
		}
	}
}

void UP3FruitComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AActor* OwnerActor = GetOwner();

		if (OwnerActor)
		{
			OwnerActor->OnTakeAnyDamage.RemoveDynamic(this, &UP3FruitComponent::Server_OnTreeTakeAnyDamage);
		}
	}
}

void UP3FruitComponent::Server_Despawn()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	ensure(Server_bDespawn);

	AActor* MyChildActor = GetChildActor();
	if (MyChildActor)
	{
		MyChildActor->Destroy();
	}

	DestroyComponent();
}

void UP3FruitComponent::Server_OnTreeTakeAnyDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, AActor* DamageCauser)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}
	
	Server_TakeDamage();

	AActor* OwnerActor = GetOwner();

	if (OwnerActor)
	{
		OwnerActor->OnTakeAnyDamage.RemoveDynamic(this, &UP3FruitComponent::Server_OnTreeTakeAnyDamage);
	}
}

void UP3FruitComponent::Server_OnFruitTakeAnyDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, AActor* DamageCauser)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_TakeDamage();

	AActor* MyChildActor = GetChildActor();

	if (MyChildActor)
	{
		MyChildActor->OnTakeAnyDamage.RemoveDynamic(this, &UP3FruitComponent::Server_OnFruitTakeAnyDamage);
	}
}

void UP3FruitComponent::Server_TakeDamage()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}


	if (Server_bDropped || Server_bDespawn)
	{
		return;
	}

	AActor* MyChildActor = GetChildActor();
	if (!ensure(MyChildActor))
	{
		return;
	}
	
	USceneComponent* RootComponent = MyChildActor->GetRootComponent();
	UPrimitiveComponent* PrimitiveRootComponent = Cast<UPrimitiveComponent>(RootComponent);
	if (RootComponent && PrimitiveRootComponent)
	{
		RootComponent->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);

		PrimitiveRootComponent->SetSimulatePhysics(true);

		ensure(PrimitiveRootComponent->IsSimulatingPhysics());

		if (FruitActorLifeSpanSeconds > 0.0f)
		{
			MyChildActor->SetLifeSpan(FruitActorLifeSpanSeconds);
		}
	}

	Server_bDropped = true;
}