// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ThreatListComponent.h"

#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "Net/UnrealNetwork.h"
#include "Perception/AISense_Sight.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Perception/AISense_Hearing.h"

#include "P3Core.h"
#include "P3AggroComponent.h"
#include "P3AIPerceptionComponent.h"
#include "P3Character.h"


static TAutoConsoleVariable<int32> CVarP3ThreatListDebug(
    TEXT("p3.threatListDebug"),
    0,
    TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ThreatPointIncreaseMultiplier(
    TEXT("p3.threatPointIncreaseMultiplier"),
    25.0f,
    TEXT("Control Increased amount of threat point"), ECVF_Cheat);


UP3ThreatListComponent::UP3ThreatListComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	bReplicates = true;
}


void UP3ThreatListComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3ThreatListComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaTime);
	}
}

void UP3ThreatListComponent::Server_Tick(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	UP3AIPerceptionComponent* AIPerceptionComponent = Character ? Character->GetAIPerceptionComponent() : nullptr;

	if (!AIPerceptionComponent)
	{
		return;
	}

	// Get AI Sense Config_Sight
	FAISenseID Id = UAISense::GetSenseID(UAISense_Sight::StaticClass());
	if (!Id.IsValid())
	{
		// Wrong Sense ID
		return;
	}
	UAISenseConfig* Config = AIPerceptionComponent->GetSenseConfig(Id);
	UAISenseConfig_Sight* ConfigSight = Config ? Cast<UAISenseConfig_Sight>(Config) : nullptr;


	// Get perceived actor list
	TArray<AActor*> PerceivedActors_Sight;
	Character->GetAIPerceptionComponent()->GetKnownPerceivedActors(UAISense_Sight::StaticClass(), PerceivedActors_Sight);

	// Make threat list
	for (AActor* PerceivedActor : PerceivedActors_Sight)
	{
		const bool IsPerceivedActorInThreatList = ThreatList.ContainsByPredicate([PerceivedActor](const FP3ThreatActor& ThreatActor) -> bool {
			return (ThreatActor.Actor == PerceivedActor);
		});

		if (!IsPerceivedActorInThreatList)
		{
			FVector CharacterLocation = Character->GetActorLocation();
			FVector PerceivedActorLocation = PerceivedActor->GetActorLocation();
			const float DistanceMeToPerceivedActor = (PerceivedActorLocation - CharacterLocation).Size();

			// Add perceived actor to threat list If the actor is in sight range.
			// TODO: We need to make threat range.
			if (ConfigSight && (DistanceMeToPerceivedActor < (ConfigSight->SightRadius)))
			{
				ThreatList.Add(FP3ThreatActor({ PerceivedActor, 1.0f }));
			}
		}
	}

	// Calculate Threat Point 
	for (FP3ThreatActor& ThreatActor : ThreatList)
	{
		if (!(ThreatActor.Actor))
		{
			continue;
		}
		FVector CharacterLocation = Character->GetActorLocation();
		FVector ThreatActorLocation = ThreatActor.Actor->GetActorLocation();
		const float DistanceMeToThreatActor = (ThreatActorLocation - CharacterLocation).Size();

		if (ConfigSight && (DistanceMeToThreatActor < ConfigSight->LoseSightRadius))
		{
			if (ThreatActor.ThreatPoint < MaxThreatPoint)
			{
				// If the threat actor is too close to me, set threat point of the actor max.
				ThreatActor.ThreatPoint +=  (DistanceMeToThreatActor > SMALL_NUMBER) ? (IncreaseThreatPointPerSecond + ((ConfigSight->LoseSightRadius * DeltaSeconds) / DistanceMeToThreatActor)) * CVarP3ThreatPointIncreaseMultiplier.GetValueOnGameThread() : MaxThreatPoint;
				ThreatActor.ThreatPoint = FMath::Clamp((ThreatActor.ThreatPoint), 0.0f, MaxThreatPoint);
			}
		}
		else
		{
			ThreatActor.ThreatPoint -= DecreaseThreatPointPerSecond * DeltaSeconds;
		}


		if (ThreatActor.ThreatPoint >= MaxThreatPoint)
		{
			UP3AggroComponent* AggroComponent = Character->GetAggroComponentBP();
			if (AggroComponent)
			{
				AggroComponent->OnSight(ThreatActor.Actor);
			}
		}
	}

	// Remove actors that have zero threat point
	ThreatList.RemoveAll([](const FP3ThreatActor& ThreatActor) {
		if (ThreatActor.ThreatPoint <= 0.0f)
		{
			return true;
		}

		AP3Character* ThreatCharacter = Cast<AP3Character>(ThreatActor.Actor);
		if (ThreatCharacter && ThreatCharacter->IsDead())
		{
			return true;
		}

		return false;
	});


	// Debug Threat List
	if (CVarP3ThreatListDebug.GetValueOnGameThread() != 0)
	{
		if (Character)
		{
			TArray<FP3ThreatActor> ThreatListForDebug = ThreatList;
			ThreatListForDebug.StableSort([](const FP3ThreatActor& ThreatActor1, const FP3ThreatActor& ThreatActor2) -> bool {
				return (ThreatActor1.ThreatPoint > ThreatActor2.ThreatPoint);
			});

			for (const FP3ThreatActor& ThreatActor : ThreatListForDebug)
			{
				Character->AddDebugString(FString::Printf(TEXT("ThreatActor : %s  |  Threat Point: %.2f"), *(ThreatActor.Actor)->GetName(), ThreatActor.ThreatPoint));
			}
		}
	}
}
