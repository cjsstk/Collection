// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3SpawnerComponent.h"

#include "AI/NavigationSystemBase.h"
#include "Classes/Landscape.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Actor.h"
#include "GameplayTagAssetInterface.h"
#include "LandscapeHeightfieldCollisionComponent.h"
#include "NavigationSystem.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "P3Actor.h"
#include "P3Character.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3ServerWorld.h"

static TAutoConsoleVariable<int32> CVarP3SpawnerDebug(
	TEXT("p3.spawnerDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

UP3SpawnerComponent::UP3SpawnerComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;

	bAutoActivate = true;
}

void UP3SpawnerComponent::Activate(bool bReset/*=false*/)
{
	Super::Activate(bReset);

	if (bReset)
	{
		CooldownSecondsLeft = 0;
		NumTotalSpawned = 0;
	}

	if (GetWorld() && GetWorld()->HasBegunPlay() && P3Core::IsP3NetModeServerInstance(*this))
	{
		DoInitialSpawn();
	}
}

void UP3SpawnerComponent::SetComponentTickEnabled(bool bEnabled)
{
	Super::SetComponentTickEnabled(bEnabled);
}

void UP3SpawnerComponent::BeginPlay()
{
	Super::BeginPlay();

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		Deactivate();
		return;
	}

	bReset_DefaultbActivation = IsActive();

	if (IsActive())
	{
		DoInitialSpawn();
	}
}

void UP3SpawnerComponent::DoInitialSpawn()
{
	if (NumInitialSpawn > 0)
	{
		for (int32 i = 0; i < NumInitialSpawn; ++i)
		{
			if (SpawnedActors.Num() >= NumMaxSpawn)
			{
				break;
			}

			Spawn();
		}
	}

	if (SpawnedActors.Num() < NumMaxSpawn)
	{
		StartCooldown();
	}
}

AActor* UP3SpawnerComponent::SpawnInternal()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return nullptr;
	}

	AActor* OwnerActor = GetOwner();

	if (!ensure(OwnerActor))
	{
		return nullptr;
	}

	FTransform Transform;
	const bool bValidTransformFound = FindSpawnTransform(Transform);

	if (!bValidTransformFound)
	{
		return nullptr;
	}
	
	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = CollisionHandling;
	Params.Instigator = OwnerActor->Instigator;

	AActor* Actor = GetWorld()->SpawnActor(ActorClass.Get(), &Transform, Params);

	if (!Actor)
	{
		P3JsonLog(Error, "Failed to spawn", TEXT("Error"), TEXT("Spawn actor failed"), TEXT("SpawnerName"), GetOwner()->GetName());
		return nullptr;
	}

	if (SweepZDistance > 0)
	{
		if (SweepZStartOffset > 0)
		{
			Actor->AddActorWorldOffset(FVector(0, 0, SweepZStartOffset));
		}

		Actor->AddActorWorldOffset(FVector(0, 0, -SweepZDistance), true);
	}

	for (const TSubclassOf<UActorComponent>& CompClass : ComponentClasses)
	{
		if (CompClass.Get())
		{
			UActorComponent* ActorComp = NewObject<UActorComponent>(Actor, CompClass.Get());
			ActorComp->RegisterComponent();
		}
	}

	AP3Character* Character = Cast<AP3Character>(Actor);
	if (Character)
	{
		Character->AddGameplayTagsBP(GameplayTagContainer);
	}
	else
	{
		AP3Actor* P3Actor = Cast<AP3Actor>(Actor);
		if (P3Actor)
		{
			P3Actor->AddGameplayTags(GameplayTagContainer);
		}
	}

	UP3LootDropComponent* LootDropComp = Actor->FindComponentByClass<UP3LootDropComponent>();
	if (LootDropComp)
	{
		LootDropComp->Server_AddLootItems(LootItemContainer);
	}

	OnSpawn.Broadcast(this, Actor);

	return Actor;
}

void UP3SpawnerComponent::StartCooldown()
{
	// 0 cool down means no cool down, so we have to clamp min
	CooldownSecondsLeft = FMath::Max(0.001f, FMath::RandRange(MinCooldownSeconds, MaxCooldownSeconds));
}

void UP3SpawnerComponent::Spawn()
{
	AActor* Actor = SpawnInternal();
	if (Actor)
	{
		SpawnedActors.Add(Actor);

		++NumTotalSpawned;
	}
}

bool UP3SpawnerComponent::FindSpawnTransform(FTransform& OutTransform)
{
	OutTransform = GetComponentTransform();

	if (Random2DRadius != 0.0f)
	{
		const FVector MyLocation = GetComponentLocation();
		int32 NumTry = 0;
		bool bValidLocationFound = false;

		while (NumTry++ < NumRetrySpawn)
		{
			FVector2D Rand2D = FMath::RandPointInCircle(Random2DRadius - Min2DRadius);
			if (Min2DRadius > 0)
			{
				Rand2D += Rand2D.GetSafeNormal() * Min2DRadius;
			}
			OutTransform.SetTranslation(MyLocation + FVector(Rand2D.X, Rand2D.Y, 0));

			const FVector LineStart = OutTransform.GetLocation() + FVector(0, 0, Random2DRadius);
			const FVector LineEnd = OutTransform.GetLocation() - FVector(0, 0, Random2DRadius);
			//FCollisionObjectQueryParams QueryParams(FCollisionObjectQueryParams::AllStaticObjects);
			FCollisionQueryParams QueryParams;
			FCollisionResponseParams ResponseParams;
			ResponseParams.CollisionResponse.SetResponse(ECC_Pawn, ECR_Ignore);
			FHitResult HitResult;

			bool bHitFound = GetWorld()->LineTraceSingleByChannel(HitResult, LineStart, LineEnd, ECC_Pawn, QueryParams, ResponseParams);

			if (bHitFound)
			{
				OutTransform.SetLocation(HitResult.Location);

				if (bAvoidOverlap)
				{
					// See if this random location is pre-occupied
					const bool bOverlapFound = IsOverlapWithSpawnedActors(OutTransform.GetLocation());

					if (bOverlapFound)
					{
						continue;
					}
				}

				if (bCheckPathFinding)
				{
					const bool bHasValidPath = HasValidNavPath(OutTransform.GetLocation());

					if (!bHasValidPath)
					{
						continue;
					}
				}

				if (bAvoidPlayerSight)
				{
					const bool bInPlayerSight = IsInPlayerSight(OutTransform.GetLocation());

					if (bInPlayerSight)
					{
						continue;
					}

					if (ActorClass.Get() && ActorClass->ClassDefaultObject)
					{
						// To be sure, check character's head location again
						ACharacter* DefaultCharacter = Cast<ACharacter>(ActorClass->ClassDefaultObject);
						if (DefaultCharacter && DefaultCharacter->GetCapsuleComponent())
						{
							const bool bHeadInPlayerSight = IsInPlayerSight(OutTransform.GetLocation() + (DefaultCharacter->GetCapsuleComponent()->GetScaledCapsuleHalfHeight() * 2.0f));

							if (bHeadInPlayerSight)
							{
								continue;
							}
						}
					}
				}

				UPrimitiveComponent* HitComponent = HitResult.GetComponent();
				if (bSpawnOnLandscapeOnly && !Cast<ULandscapeHeightfieldCollisionComponent>(HitComponent))
				{
					if (CVarP3SpawnerDebug.GetValueOnGameThread() != 0)
					{
						DrawDebugLine(GetWorld(), LineStart, LineEnd, FColor::Purple, true, 3.0f);
						DrawDebugSphere(GetWorld(), HitResult.Location, 30.0f, 12, FColor::Purple, true, 3.0f);
					}
					continue;
				}

				if (bAlignToGround)
				{
					OutTransform.SetRotation(OutTransform.GetRotation() * FQuat::FindBetweenNormals(OutTransform.GetRotation().GetUpVector(), HitResult.Normal));
				}

				if (ActorClass.Get() && ActorClass->ClassDefaultObject)
				{
					ACharacter* DefaultCharacter = Cast<ACharacter>(ActorClass->ClassDefaultObject);
					if (DefaultCharacter && DefaultCharacter->GetCapsuleComponent())
					{
						OutTransform.AddToTranslation(FVector(0, 0, DefaultCharacter->GetCapsuleComponent()->GetScaledCapsuleHalfHeight()));
					}
				}

				bValidLocationFound = true;

				if (CVarP3SpawnerDebug.GetValueOnGameThread() != 0)
				{
					DrawDebugLine(GetWorld(), LineStart, LineEnd, FColor::Green, true, 5.0f);
					DrawDebugSphere(GetWorld(), HitResult.Location, 100.0f, 12, FColor::Green, true, 5.0f);

					if (bAlignToGround)
					{
						DrawDebugLine(GetWorld(), HitResult.Location, HitResult.Location + HitResult.Normal * 100, FColor::Red, true, 5.0f);
						DrawDebugLine(GetWorld(),
							HitResult.Location + HitResult.Normal * 100,
							HitResult.Location + HitResult.Normal * 100 + OutTransform.GetRotation().GetForwardVector() * 100, FColor::Red, true, 5.0f);
					}
				}

				break;
			}
			else
			{
				if (CVarP3SpawnerDebug.GetValueOnGameThread() != 0)
				{
					DrawDebugLine(GetWorld(), LineStart, LineEnd, FColor::Red, true, 3.0f);
					DrawDebugSphere(GetWorld(), HitResult.Location, 30.0f, 12, FColor::Red, true, 3.0f);
				}
			}
		}

		if (!bValidLocationFound)
		{
			return false;
		}
	}

	if (bAlignToGround)
	{
		OutTransform.SetRotation(OutTransform.GetRotation() * FRotator(
			0,
			FMath::RandRange(-RandomRotation.Yaw * 0.5f, RandomRotation.Yaw * 0.5f),
			0).Quaternion());
	}
	else
	{
		OutTransform.SetRotation(GetComponentQuat() * FRotator(
			FMath::RandRange(-RandomRotation.Pitch * 0.5f, RandomRotation.Pitch * 0.5f),
			FMath::RandRange(-RandomRotation.Yaw * 0.5f, RandomRotation.Yaw * 0.5f),
			FMath::RandRange(-RandomRotation.Roll * 0.5f, RandomRotation.Roll * 0.5f)).Quaternion());
	}

	return true;
}

bool UP3SpawnerComponent::IsOverlapWithSpawnedActors(const FVector& Location) const
{
	bool bOverlapFound = false;

	for (const AActor* Actor : SpawnedActors)
	{
		if (!Actor || Actor->IsActorBeingDestroyed())
		{
			continue;
		}

		const float DistanceSquared = (Actor->GetActorLocation() - Location).SizeSquared2D();
		if (DistanceSquared < FMath::Square(AvoidOverlapDistance))
		{
			bOverlapFound = true;
			break;
		}
	}

	return bOverlapFound;
}

bool UP3SpawnerComponent::HasValidNavPath(const FVector& Location) const
{
	const UWorld* World = GetWorld();

	if (!World || !World->GetNavigationSystem())
	{
		return false;
	}

	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	if (!ensure(NavSys))
	{
		return false;
	}

	const FNavAgentProperties& AgentProps = FNavAgentProperties::DefaultProperties;

	FNavLocation ProjectedLocation;

	// See if selected location is valid on nav mesh
	if (NavSys->ProjectPointToNavigation(Location, ProjectedLocation, INVALID_NAVEXTENT, &AgentProps))
	{
		const ANavigationData* NavData = NavSys->GetNavDataForProps(AgentProps);

		// See if have valid path from selected location to spawner component location
		if (ensure(NavData))
		{
			FSharedConstNavQueryFilter QueryFilter = UNavigationQueryFilter::GetQueryFilter(*NavData, nullptr, nullptr);

			FPathFindingQuery Query(this, *NavData, Location, GetComponentLocation(), QueryFilter);
			Query.bAllowPartialPaths = false;

			const bool bHasPath = NavSys->TestPathSync(Query, EPathFindingMode::Hierarchical);

			if (!bHasPath)
			{
				return false;
			}
		}

		if (CVarP3SpawnerDebug.GetValueOnGameThread() != 0)
		{
			DrawDebugLine(GetWorld(), Location, ProjectedLocation.Location, FColor::Blue, false, 3.0f);
			DrawDebugSphere(GetWorld(), ProjectedLocation.Location, 30.0f, 12, FColor::Blue, false, 5.0f);
		}

		return true;
	}

	return false;
}

bool UP3SpawnerComponent::IsInPlayerSight(const FVector& Location) const
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(*this);

	if (!ensure(ServerWorld))
	{
		return false;
	}

	const FVector SpawnerLocation = GetComponentLocation();

	FCollisionObjectQueryParams ObjectQueryParams(FCollisionObjectQueryParams::AllStaticObjects);
	FCollisionQueryParams QueryParams;
	QueryParams.bIgnoreTouches = true;
	QueryParams.MobilityType = EQueryMobilityType::Static;
	FCollisionResponseParams ResponseParams;
	ResponseParams.CollisionResponse.SetResponse(ECC_Pawn, ECR_Ignore);
	ResponseParams.CollisionResponse.SetResponse(ECC_PhysicsBody, ECR_Ignore);

	FHitResult HitResult;

	// Since location may already placed on something, we need to back off a little bit
	const float BackoffDistance = 10.0f;

	const TArray<class AP3Character*>& Characters = ServerWorld->GetCharacters();

	for (AP3Character* Character : Characters)
	{
		if (!Character)
		{
			continue;
		}

		if (!Character->IsPlayerControlled())
		{
			continue;
		}

		const FVector CharacterLocation = Character->GetActorLocation() + Character->GetControlRotation().RotateVector(FVector(-200, 0, 0));
		const FVector LineDir = (Location - CharacterLocation).GetSafeNormal();

		const bool bHit = GetWorld()->LineTraceSingleByChannel(HitResult, CharacterLocation, Location - (LineDir * BackoffDistance), ECC_Visibility,  QueryParams, ResponseParams);

		if (bHit)
		{
			// there is something between character and this location

			if (CVarP3SpawnerDebug.GetValueOnGameThread() != 0)
			{
				DrawDebugSphere(GetWorld(), HitResult.Location, 30.0f, 12, FColor::Red, false, 5.0f);
			}

			return false;
		}
	}

	return true;
}

void UP3SpawnerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		//ensure(0);
		return;
	}


	// Do Spawn
	if (NumMaxTotalSpawn == -1 || NumTotalSpawned < NumMaxTotalSpawn)
	{
		if (CooldownSecondsLeft > 0)
		{
			CooldownSecondsLeft -= DeltaTime;

			if (CooldownSecondsLeft <= 0)
			{
				CooldownSecondsLeft = 0;

				Spawn();
			}
		}
		else
		{
			if (SpawnedActors.Num() < NumMaxSpawn)
			{
				StartCooldown();
			}
		}
	}

	// Remove dead actors from spawn history
	SpawnedActors.RemoveAll([](const AActor* Actor) -> bool {
		if (!Actor)
		{
			return true;
		}

		if (Actor->IsActorBeingDestroyed())
		{
			return true;
		}

		return false;
	});

#if ENABLE_DRAW_DEBUG
	if (CVarP3SpawnerDebug.GetValueOnGameThread() != 0)
	{
		FString DebugString = FString::Printf(TEXT("[Spawner] %d/%d, Cooldown: %.1f"), SpawnedActors.Num(), NumMaxSpawn, CooldownSecondsLeft);

		if (NumMaxTotalSpawn > 0)
		{
			DebugString += FString::Printf(TEXT(", Total: %d/%d"), NumTotalSpawned, NumMaxTotalSpawn);
		}

		DrawDebugString(GetWorld(), FVector(0, 0, 100), DebugString, GetOwner(), FColor::White, 0, true);
	}
#endif
}


void UP3SpawnerComponent::ResetSpawnerComponent()
{
	for (AActor* Actor : SpawnedActors)
	{
		if (Actor && !Actor->IsActorBeingDestroyed())
		{
			Actor->Destroy();
		}
	}

	SpawnedActors.Empty();

	CooldownSecondsLeft = 0;
	NumTotalSpawned = 0;

	if (bReset_DefaultbActivation)
	{
		Activate();
	}
	else
	{
		Deactivate();
	}
}


UP3DeadPawnDestroyerComponent::UP3DeadPawnDestroyerComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3DeadPawnDestroyerComponent::BeginPlay()
{
	Super::BeginPlay();

	CachedHealthPointComponent = GetOwner() ? GetOwner()->FindComponentByClass<UP3HealthPointComponent>() : nullptr;
}

void UP3DeadPawnDestroyerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	if (!CachedHealthPointComponent || !GetOwner() || GetOwner()->IsActorBeingDestroyed())
	{
		return;
	}

	if (CachedHealthPointComponent->GetHealthPoint() == 0)
	{
		if (DestoryTimeLeftSeconds == 0)
		{
			DestoryTimeLeftSeconds = FMath::RandRange(MinDestoryDelaySeconds, MaxDestoryDelaySeconds);
		}
		else
		{
			DestoryTimeLeftSeconds -= DeltaTime;

			if (DestoryTimeLeftSeconds <= 0)
			{
				GetOwner()->Destroy();
			}
		}
	}
}

UP3DeadCharacterRagollizerComponent::UP3DeadCharacterRagollizerComponent()
{
}

void UP3DeadCharacterRagollizerComponent::BeginPlay()
{
	Super::BeginPlay();

	ensure(P3Core::IsP3NetModeServerInstance(*this));

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (Character)
	{
		Character->OnCharacterDead.AddUniqueDynamic(this, &UP3DeadCharacterRagollizerComponent::OnCharacterDead);
	}
}

void UP3DeadCharacterRagollizerComponent::OnCharacterDead()
{
	if (ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character)
		{
			Character->GetActionComponent()->StartAction(EPawnActionType::Ragdollize, _FUNCTION_TEXT);
		}
	}
}

UP3DestroyActorComponent::UP3DestroyActorComponent()
{

}

void UP3DestroyActorComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		GetOwner()->OnActorBeginOverlap.AddUniqueDynamic(this, &UP3DestroyActorComponent::OnBeginOverlap);
	}
}

void UP3DestroyActorComponent::OnBeginOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(OtherActor);
	if (GameplayTagAsset)
	{
		const bool bHasAll = GameplayTagAsset->HasAllMatchingGameplayTags(TriggerGameplayTagsAll);
		const bool bHasAny = GameplayTagAsset->HasAnyMatchingGameplayTags(TriggerGameplayTagsAny);

		if (bHasAll && bHasAny)
		{
			OtherActor->Destroy(true);
		}
	}
}

void UP3RandomLifeSpanComponent::BeginPlay()
{
	Super::BeginPlay();

	if (GetOwner())
	{
		if (!bServerOnly || P3Core::IsP3NetModeServerInstance(*this))
		{
			const float RandomLifeSpan = FMath::RandRange(MinLifeSpan, MaxLifeSpan);
			GetOwner()->SetLifeSpan(RandomLifeSpan);
		}
	}
}
