// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3ComboTable.h"
#include "P3ComboNameWidget.generated.h"

/**
 * Combo Name Widget
 */
UCLASS()
class P3_API UP3ComboNameWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveComboStart(const FName& ComboName);

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveComboInput(const FName& ComboName);

private:
	UFUNCTION()
	void OnComboStarted(const FP3ComboRow& ComboRow);

	bool bDelegateBound = false;
};
