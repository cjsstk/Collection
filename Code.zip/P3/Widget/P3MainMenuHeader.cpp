// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3MainMenuHeader.h"

#include "Components/Image.h"
#include "Components/TextBlock.h"


FReply UP3MainMenuHeader::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (InMouseEvent.GetPressedButtons().Contains(EKeys::LeftMouseButton))
	{
		MainMenuHeaderOnClicked.Broadcast(MenuIndex);
	}

	return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
}

void UP3MainMenuHeader::InitHeader(const FText& InText, int32 InMenuIndex)
{
	SetText(InText);
	MenuIndex = InMenuIndex;
}

void UP3MainMenuHeader::SetText(const FText& InText)
{
	if (MenuTextBlock)
	{
		MenuTextBlock->SetText(InText);
	}
}

void UP3MainMenuHeader::Refresh(bool bSelected)
{
	if (SelectedImage)
	{
		SelectedImage->SetVisibility(bSelected ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}
