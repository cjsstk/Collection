// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3InGameActionWidget.generated.h"

/**
 * In game action widget
 * - Toast Message
 */
UCLASS()
class P3_API UP3InGameActionWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	UFUNCTION(BlueprintImplementableEvent)
	void ToastMessage(const FText& Message);

	void ShowContributionBoard(bool bShow);

protected:
	UFUNCTION(BlueprintCallable)
	bool IsInputGuideRescueVisible() const;

	UFUNCTION(BlueprintCallable)
	bool IsInputGuidePickupVisible() const;

	UFUNCTION(BlueprintCallable)
	bool IsInputGuidePutawayToInteractVisible() const;

	UFUNCTION(BlueprintCallable)
	bool IsInputGuideThrowVisible() const;

private:
	UPROPERTY(meta = (BindWidget))
	class UUserWidget* AIControlWidget = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3ContributionBoardWidget* ContributionBoard = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3PartyMemberListWidget* PartyMemberListWidget = nullptr;
};
