// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3BackpackInventoryWidget.h"

#include "Components/UniformGridPanel.h"
#include "Components/UniformGridSlot.h"

#include "P3Character.h"
#include "P3InventoryComponent.h"
#include "Widget/P3InventorySlotWidget.h"

void UP3BackpackInventoryWidget::InitInventory()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	if (!InventoryItemSlotPanel)
	{
		return;
	}

	if (!SlotClass.Get())
	{
		ensure(0);
		return;
	}

	InventoryItemSlotPanel->ClearChildren();
	InventorySlots.Empty();

	const TArray<FP3Item>& BackpackItems = InventoryComp->GetItemsBySlot(EP3CharacterItemSlot::Backpack);

	for (int32 Row = 0; Row < RowCount; ++Row)
	{
		for (int32 Coloumn = 0; Coloumn < ColumnCount; ++Coloumn)
		{
			UP3InventorySlotWidget* SlotWidget = CreateWidget<UP3InventorySlotWidget>(GetOwningPlayer(), SlotClass);
			if (!SlotWidget)
			{
				continue;
			}

			UUniformGridSlot* UniformGridSlot = InventoryItemSlotPanel->AddChildToUniformGrid(SlotWidget);
			if (ensure(UniformGridSlot))
			{
				UniformGridSlot->SetRow(Row);
				UniformGridSlot->SetColumn(Coloumn);
			}

			const int32 SlotIndex = Row * ColumnCount + Coloumn;
			FP3Item InventoryItem = FP3Item::InvalidItem;

			if (BackpackItems.IsValidIndex(SlotIndex))
			{
				InventoryItem = BackpackItems[SlotIndex];
			}

			SlotWidget->InitSlot(InventoryItem);
			SlotWidget->SetSlotIndex(SlotIndex);
			InventorySlots.Add(SlotWidget);
		}
	}

}

void UP3BackpackInventoryWidget::OnOpen()
{
	SetVisibility(ESlateVisibility::Visible);

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (Character && IsLocalControlledActor(Character))
	{
		Character->LocalControl_SetBackpackUIOpened(true);
	}
}

void UP3BackpackInventoryWidget::OnClose()
{
	SetVisibility(ESlateVisibility::Collapsed);

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (Character && IsLocalControlledActor(Character))
	{
		Character->LocalControl_SetBackpackUIOpened(false);
	}
}

void UP3BackpackInventoryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	InitInventory();

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (Character)
	{
		Character->OnInputOpenBackpackInventory.AddUniqueDynamic(this, &UP3BackpackInventoryWidget::OnOpen);
		Character->OnInputCloseBackpackInventory.AddUniqueDynamic(this, &UP3BackpackInventoryWidget::OnClose);
	}
}

void UP3BackpackInventoryWidget::NativeDestruct()
{
	Super::NativeDestruct();

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (Character)
	{
		Character->OnInputOpenBackpackInventory.RemoveDynamic(this, &UP3BackpackInventoryWidget::OnOpen);
		Character->OnInputCloseBackpackInventory.RemoveDynamic(this, &UP3BackpackInventoryWidget::OnClose);
	}
}
