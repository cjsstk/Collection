// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"

#include "P3Cms.h"

#include "P3CreateCharacterDialog.generated.h"

DECLARE_MULTICAST_DELEGATE(FP3CreateCharacterDialogOnClose);
DECLARE_MULTICAST_DELEGATE_TwoParams(FP3CreateCharacterDialogOnCreate, const FString&, EP3CharClass);

UCLASS(Blueprintable)
class P3_API UP3CreateCharacterDialog : public UUserWidget
{
	GENERATED_BODY()

public:
	void Reset();

	FP3CreateCharacterDialogOnClose OnClose;
	FP3CreateCharacterDialogOnCreate OnCreate;

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

private:
	UFUNCTION()
	void OnCreateClicked();

	UFUNCTION()
	void OnCancelClicked();

	UPROPERTY(meta = (BindWidget))
	class UEditableTextBox* NameEdit = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UComboBoxString* ClassCombo = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* CreateButton = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* CancelButton = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* MessageText = nullptr;

	FDelegateHandle OnConnectedToAuthDelegate;
	FDelegateHandle OnCreateCharacterDelegate;
};
