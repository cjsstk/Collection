// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3InGameActionWidget.h"

#include "Action/P3PawnActionComponent.h"
#include "P3Character.h"
#include "P3ContributionBoardWidget.h"
#include "P3PickupableComponent.h"
#include "P3PickupComponent.h"
#include "P3Weapon.h"

TAutoConsoleVariable<int32> CVarP3ShowAIControl(
	TEXT("p3.showAIControl"),
	0,
	TEXT("1: show. 0: hide"), ECVF_Cheat);

extern TAutoConsoleVariable<int32> CVarP3DisableInteractionInCombatStance;


void UP3InGameActionWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (AIControlWidget)
	{
		if (CVarP3ShowAIControl.GetValueOnGameThread() == 0)
		{
			AIControlWidget->SetVisibility(ESlateVisibility::Collapsed);
		}
		else
		{
			AIControlWidget->SetVisibility(ESlateVisibility::Visible);
		}
	}
}

void UP3InGameActionWidget::ShowContributionBoard(bool bShow)
{
	if (ContributionBoard)
	{
		if (bShow)
		{
			ContributionBoard->ReceiveUpdateBoard();
		}
		ContributionBoard->SetVisibility(bShow ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}
}

bool UP3InGameActionWidget::IsInputGuideRescueVisible() const
{
	const AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (!Character)
	{
		return false;
	}

	if (!Character->CanInteract())
	{
		return false;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();

	if (!PickupComp)
	{
		return false;
	}

	AP3Character* PickupCandidateCharacter = Cast<AP3Character>(PickupComp->GetPickupCandidateActor());

	if (PickupCandidateCharacter && PickupCandidateCharacter->IsDowned())
	{
		return true;
	}

	return false;
}

bool UP3InGameActionWidget::IsInputGuidePickupVisible() const
{
	const AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (!Character)
	{
		return false;
	}

	if (!Character->CanInteract())
	{
		return false;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();

	if (!PickupComp)
	{
		return false;
	}

	AActor* PickupCandidateActor = PickupComp->GetPickupCandidateActor();

	if (PickupCandidateActor && PickupCandidateActor->FindComponentByClass<UP3PickupableComponent>())
	{
		return true;
	}

	if (PickupCandidateActor && PickupCandidateActor->IsA(AP3Weapon::StaticClass()))
	{
		return true;
	}

	return false;
}

bool UP3InGameActionWidget::IsInputGuidePutawayToInteractVisible() const
{
	if (CVarP3DisableInteractionInCombatStance.GetValueOnGameThread() != 1)
	{
		return false;
	}

	const AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (!Character)
	{
		return false;
	}

	if (Character->GetStance() != EP3CharacterStance::Combat)
	{
		return false;
	}

	if (Character->GetActionComponent() && Character->GetActionComponent()->GetActiveActionType() == EPawnActionType::PutAwayWeapon)
	{
		return false;
	}

	const bool bHasInteractable = Character->HasSomethingToInteract();

	return bHasInteractable;
}

bool UP3InGameActionWidget::IsInputGuideThrowVisible() const
{
	const AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (!Character)
	{
		return false;
	}

	if (Character->GetStance() != EP3CharacterStance::Pickup)
	{
		return false;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();

	if (!PickupComp)
	{
		return false;
	}

	if (!PickupComp->CanThrow())
	{
		return false;
	}

	return true;
}
