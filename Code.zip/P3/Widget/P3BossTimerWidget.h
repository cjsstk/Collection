// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3BossTimerWidget.generated.h"

/**
 *
 */
UCLASS()
class P3_API UP3BossTimerWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

public:
	void StartTimer(float InTimeLimitSeconds, float InLeftTimeSeconds);
	void ResetTimer();

	/*
	 * Widget Blueprint requirement
	 */
	UFUNCTION(BlueprintCallable)
	FText GetLeftTimeMinutes() const;

	UFUNCTION(BlueprintCallable)
	float GetLeftTimeRatio() const;

private:
	float TimeLimitSeconds = -1.0f;
	float LeftTimeSeconds = -1.0f;
};
