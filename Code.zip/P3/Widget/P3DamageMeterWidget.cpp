// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3DamageMeterWidget.h"

#include "Components/TextBlock.h"
#include "Components/ProgressBar.h"

#include "P3DamageMetersComponent.h"

void UP3DamageMeterWidget::SetData(const FP3DamageMeter& Data, int32 MaxAmount)
{
	if (ensure(NameText))
	{
		NameText->SetText(FText::AsCultureInvariant(Data.SourceName));
	}

	if (ensure(AmountText))
	{
		AmountText->SetText(FText::AsCultureInvariant(FString::Printf(TEXT("%d (%d)"), Data.DamageAmount, Data.NumKills)));

		if (Data.NumKills >= 3)
		{
			AmountText->SetColorAndOpacity(FLinearColor::Red);
		}
		else
		{
			AmountText->SetColorAndOpacity(FLinearColor::White);
		}
	}

	if (ensure(DamageProgressBar))
	{
		const float Percent = StaticCast<float>(Data.DamageAmount) / MaxAmount;
		DamageProgressBar->SetPercent(Percent);
	}
}
