// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3LoginHUDWidget.h"

#include "Components/Border.h"
#include "Components/Button.h"
#include "Components/TextBlock.h"
#include "Kismet/GameplayStatics.h"

#include "Network/P3AuthNet.h"
#include "Network/P3DedimanHelper.h"
#include "Network/P3GameWorldNet.h"
#include "Network/P3UnrealUDPNet.h"
#include "P3CreateCharacterDialog.h"
#include "P3GameInstance.h"
#include "P3Localization.h"
#include "P3LoginDialog.h"
#include "P3LoginHUDWidget.h"
#include "P3SelectCharacterDialog.h"
#include "P3SelectWorldDialog.h"
#include "P3ServerAddressDialog.h"
#include "P3SignUpDialog.h"

void UP3LoginHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (ensure(LoginDialog))
	{
		LoginDialog->OnSignUp.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnLoginDialogSignUp);
		LoginDialog->OnServerAddress.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnLoginDialogServerAddress);
		LoginDialog->OnLoginSuccess.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnLoginSuccess);
	}

	if (ensure(SignUpDialog))
	{
		SignUpDialog->OnClose.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnSignUpDialogClose);
	}

	if (ensure(ServerAddressDialog))
	{
		ServerAddressDialog->OnOK.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnServerAddressDialogOK);
		ServerAddressDialog->OnCancel.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnServerAddressDialogCancel);
	}

	if (ensure(SelectWorldDialog))
	{
		SelectWorldDialog->OnSelect.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnSelectWorldDialogSelectItem);
	}

	if (ensure(SelectCharacterDialog))
	{
		OnSelectCharacterDialogCreateDelegate = SelectCharacterDialog->OnCreate.AddUObject(this, &UP3LoginHUDWidget::OnSelectCharacterDialogCreate);
		OnSelectCharacterDialogDeleteDelegate = SelectCharacterDialog->OnDelete.AddUObject(this, &UP3LoginHUDWidget::OnSelectCharacterDialogDelete);
		OnSelectCharacterDialogEnterDelegate = SelectCharacterDialog->OnEnter.AddUObject(this, &UP3LoginHUDWidget::OnSelectCharacterDialogEnter);
		OnSelectCharacterDialogCloseDelegate = SelectCharacterDialog->OnClose.AddUObject(this, &UP3LoginHUDWidget::OnSelectCharacterDialogClose);
	}

	if (ensure(CreateCharacterDialog))
	{
		OnCreateCharacterDialogCreateDelegate = CreateCharacterDialog->OnCreate.AddUObject(this, &UP3LoginHUDWidget::OnCreateCharacterDialogCreate);
	}

	if (ensure(MessageOKButton))
	{
		MessageOKButton->OnClicked.AddUniqueDynamic(this, &UP3LoginHUDWidget::OnMessageDialogOK);
	}

	if (ensure(LoginDialog))
	{
		LoginDialog->Reset();
		LoginDialog->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void UP3LoginHUDWidget::NativeDestruct()
{
	Super::NativeDestruct();

	if (LoginDialog)
	{
		LoginDialog->OnSignUp.RemoveDynamic(this, &UP3LoginHUDWidget::OnLoginDialogSignUp);
		LoginDialog->OnServerAddress.RemoveDynamic(this, &UP3LoginHUDWidget::OnLoginDialogServerAddress);
		LoginDialog->OnLoginSuccess.RemoveDynamic(this, &UP3LoginHUDWidget::OnLoginSuccess);
	}

	if (SignUpDialog)
	{
		SignUpDialog->OnClose.RemoveDynamic(this, &UP3LoginHUDWidget::OnSignUpDialogClose);
	}

	if (ServerAddressDialog)
	{
		ServerAddressDialog->OnOK.RemoveDynamic(this, &UP3LoginHUDWidget::OnServerAddressDialogOK);
		ServerAddressDialog->OnCancel.RemoveDynamic(this, &UP3LoginHUDWidget::OnServerAddressDialogCancel);
	}

	if (SelectWorldDialog)
	{
		SelectWorldDialog->OnSelect.RemoveDynamic(this, &UP3LoginHUDWidget::OnSelectWorldDialogSelectItem);
	}

	if (SelectCharacterDialog)
	{
		SelectCharacterDialog->OnCreate.Remove(OnSelectCharacterDialogCreateDelegate);
		SelectCharacterDialog->OnDelete.Remove(OnSelectCharacterDialogDeleteDelegate);
		SelectCharacterDialog->OnEnter.Remove(OnSelectCharacterDialogEnterDelegate);
		SelectCharacterDialog->OnClose.Remove(OnSelectCharacterDialogCloseDelegate);
	}

	if (CreateCharacterDialog)
	{
		CreateCharacterDialog->OnCreate.Remove(OnCreateCharacterDialogCreateDelegate);
	}

	if (MessageOKButton)
	{
		MessageOKButton->OnClicked.RemoveDynamic(this, &UP3LoginHUDWidget::OnMessageDialogOK);
	}
}

void UP3LoginHUDWidget::OnLoginDialogSignUp()
{
	LoginDialog->SetVisibility(ESlateVisibility::Collapsed);

	SignUpDialog->Reset();
	SignUpDialog->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UP3LoginHUDWidget::OnLoginDialogServerAddress()
{
	LoginDialog->SetVisibility(ESlateVisibility::Collapsed);

	ServerAddressDialog->Reset();
	ServerAddressDialog->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UP3LoginHUDWidget::OnLoginSuccess(const FString& Account, const TArray<FP3WorldServerInfo>& WorldServerInfos)
{
	LoginDialog->SetVisibility(ESlateVisibility::Collapsed);

	SelectWorldDialog->Reset(WorldServerInfos);
	SelectWorldDialog->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	APlayerController* PlayerController = GetOwningPlayer();

	if (PlayerController)
	{
		// Workaround to focus dialog (SetUserFocus does not work)
		FInputModeUIOnly InputMode;
		InputMode.SetWidgetToFocus(SelectWorldDialog->TakeWidget());
		PlayerController->SetInputMode(InputMode);
	}
}

void UP3LoginHUDWidget::OnServerAddressDialogOK()
{
	ServerAddressDialog->SetVisibility(ESlateVisibility::Collapsed);

	LoginDialog->Reset();
	LoginDialog->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UP3LoginHUDWidget::OnServerAddressDialogCancel()
{
	ServerAddressDialog->SetVisibility(ESlateVisibility::Collapsed);

	LoginDialog->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UP3LoginHUDWidget::OnSignUpDialogClose()
{
	SignUpDialog->SetVisibility(ESlateVisibility::Collapsed);

	LoginDialog->Reset();
	LoginDialog->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UP3LoginHUDWidget::OnMessageDialogOK()
{
	check(MessageDialog);

	MessageDialog->SetVisibility(ESlateVisibility::Collapsed);

	if (ensure(CreateCharacterDialog))
	{
		CreateCharacterDialog->Reset();
	}
}

void UP3LoginHUDWidget::OnSelectWorldDialogSelectItem(const FP3WorldServerInfo& WorldServerInfo)
{
	check(SelectWorldDialog);

	SelectWorldDialog->SetVisibility(ESlateVisibility::Collapsed);

	UP3GameWorldNet* GameWorldNet = P3GetGameWorldNet(this);
	if (!ensure(GameWorldNet))
	{
		return;
	}

	GameWorldNet->SetHost(WorldServerInfo.Address);
	GameWorldNet->SetPort(WorldServerInfo.Port);
	GameWorldNet->Connect(this);
}

void UP3LoginHUDWidget::OnSelectCharacterDialogCreate()
{
	check(CreateCharacterDialog);

	CreateCharacterDialog->SetVisibility(ESlateVisibility::Visible);
	CreateCharacterDialog->Reset();
}

void UP3LoginHUDWidget::OnSelectCharacterDialogDelete(charid CharacterId)
{
	UP3GameWorldNet* GameWorldNet = P3GetGameWorldNet(this);
	if (!ensure(GameWorldNet))
	{
		return;
	}

	GameWorldNet->SendDeleteCharacter(CharacterId);
}

void UP3LoginHUDWidget::OnSelectCharacterDialogEnter(charid CharacterId)
{
	check(SelectCharacterDialog && LoadingDialog);

	if (!ensure(CharacterId != INVALID_CHARID))
	{
		return;
	}

	SelectCharacterDialog->SetVisibility(ESlateVisibility::Collapsed);
	LoadingDialog->SetVisibility(ESlateVisibility::Visible);

	UP3GameWorldNet* GameWorldNet = P3GetGameWorldNet(this);
	if (!ensure(GameWorldNet))
	{
		return;
	}

	GameWorldNet->SendSelectCharacter(CharacterId);
}

void UP3LoginHUDWidget::OnSelectCharacterDialogClose()
{
	check(SelectWorldDialog && SelectCharacterDialog);

	SelectCharacterDialog->SetVisibility(ESlateVisibility::Collapsed);
	SelectWorldDialog->SetVisibility(ESlateVisibility::Visible);

	UP3GameWorldNet* GameWorldNet = P3GetGameWorldNet(this);
	if (!ensure(GameWorldNet))
	{
		return;
	}

	GameWorldNet->Close();
}

void UP3LoginHUDWidget::OnCreateCharacterDialogCreate(const FString& Name, EP3CharClass CharClass)
{
	UP3GameWorldNet* GameWorldNet = P3GetGameWorldNet(this);
	if (!ensure(GameWorldNet))
	{
		return;
	}

	FName HairName;
	FName ArmorName;

	const UDataTable* HairTable = P3Cms::GetCharacterHairTable();

	if (HairTable)
	{
		const TArray<FName> HairNames = HairTable->GetRowNames();
		if (HairNames.Num() > 0)
		{
			HairName = HairNames[FMath::Rand() % HairNames.Num()];
		}
	}

	const UDataTable* ArmorTable = P3Cms::GetCharacterArmorTable();

	if (ArmorTable)
	{
		const TArray<FName> ArmorNames = ArmorTable->GetRowNames();
		if (ArmorNames.Num() > 0)
		{
			ArmorName = ArmorNames[FMath::Rand() % ArmorNames.Num()];
		}
	}

	GameWorldNet->SendCreateCharacter(Name, CharClass, HairName.ToString(), ArmorName.ToString());
}

void UP3LoginHUDWidget::OnConnectedToGameWorld(UP3GameWorldNet& GameWorldNet, bool bSuccess)
{
	check(MessageText && MessageDialog);

	UP3GameInstance* GameInstance = GetWorld()->GetGameInstance<UP3GameInstance>();
	if (!ensure(GameInstance))
	{
		return;
	}

	if (bSuccess)
	{
		GameWorldNet.SendLogin(GameInstance->GetAuthToken());
	}
	else
	{
		MessageText->SetText(P3LOC_LOGIN("FailedToConnect"));
		MessageDialog->SetVisibility(ESlateVisibility::Visible);

		LoginDialog->SetVisibility(ESlateVisibility::Visible);
		LoginDialog->Reset();
	}
}

void UP3LoginHUDWidget::OnLoginReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLLoginRes& Message)
{
	check(MessageText && MessageDialog);

	if (Message.err() != pb::WU2CLError_SUCCESS)
	{
		MessageText->SetText(P3LOC_LOGIN("FailedToWorldLogin"));
		MessageDialog->SetVisibility(ESlateVisibility::Visible);

		LoginDialog->SetVisibility(ESlateVisibility::Visible);
		LoginDialog->Reset();
		return;
	}	

	GameWorldNet.SendListCharacters();
}

void UP3LoginHUDWidget::OnListCharactersReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLListCharactersRes& Message)
{
	check(LoadingDialog && SelectCharacterDialog);

	if (Message.err() != pb::WU2CLError_SUCCESS)
	{
		MessageText->SetText(P3LOC_LOGIN("FailedToGetCharacterList"));
		MessageDialog->SetVisibility(ESlateVisibility::Visible);
		return;
	}

	LoadingDialog->SetVisibility(ESlateVisibility::Collapsed);

	SelectCharacterDialog->SetVisibility(ESlateVisibility::Visible);
	SelectCharacterDialog->Reset(Message);
}

void UP3LoginHUDWidget::OnCreateCharacterReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLCreateCharacterRes& Message)
{
	check(CreateCharacterDialog);

	if (Message.err() != pb::WU2CLError_SUCCESS)
	{
		if (Message.err() == pb::WU2CLError_DUPLICATED_CHAR_NAME)
		{
			MessageText->SetText(P3LOC_LOGIN("DuplicatedCharacterName"));
		}
		else
		{
			MessageText->SetText(P3LOC_LOGIN("FailedToCreateCharacter"));
		}
		MessageDialog->SetVisibility(ESlateVisibility::Visible);
		return;
	}

	if (!ensure(Message.char_id() > 0))
	{
		return;
	}

	CreateCharacterDialog->SetVisibility(ESlateVisibility::Collapsed);

	GameWorldNet.SendListCharacters();
}

void UP3LoginHUDWidget::OnDeleteCharacterReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLDeleteCharacterRes& Message)
{
	check(MessageText && MessageDialog);

	if (Message.err() != pb::WU2CLError_SUCCESS)
	{
		MessageText->SetText(P3LOC_LOGIN("FailedToDeleteCharacter"));
		MessageDialog->SetVisibility(ESlateVisibility::Visible);
		return;
	}

	GameWorldNet.SendListCharacters();
}

void UP3LoginHUDWidget::OnSelectCharacterReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLSelectCharacterRes& Message)
{
	check(MessageText && MessageDialog);

	if (Message.err() != pb::WU2CLError_SUCCESS)
	{
		if (Message.err() == pb::WU2CLError_NO_AVAILABLE_DEDI)
		{
			MessageText->SetText(P3LOC_LOGIN("NoAvailableDediServer"));
		}
		else
		{
			MessageText->SetText(P3LOC_LOGIN("FailedToSelectCharacter"));
		}
		MessageDialog->SetVisibility(ESlateVisibility::Visible);

		SelectCharacterDialog->SetVisibility(ESlateVisibility::Visible);
		LoadingDialog->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}


	GameWorldNet.Close();

	UP3GameInstance* GameInstance = GetWorld()->GetGameInstance<UP3GameInstance>();
	if (!ensure(GameInstance))
	{
		return;
	}

	GameInstance->SetCharacterId(Message.char_id());
	GameInstance->SetCharacterName(UTF8_TO_TCHAR(Message.char_name().c_str()));

	UP3DedimanHelper* DedimanHelper = GameInstance->GetDedimanHelper();
	if (ensure(DedimanHelper))
	{
		DedimanHelper->SetDedimanURL(UTF8_TO_TCHAR(Message.dediman_url().c_str()));
	}

	FString Options = FString::Printf(TEXT("DediConnect=1?DediAddress=%s?DediPort=%d?Port=%d?DediZone=%s"),
		UTF8_TO_TCHAR(Message.dedi_host().c_str()), Message.dedi_port(), Message.dedi_udpport(), UTF8_TO_TCHAR(Message.zone().c_str()));
	if (!Message.reset_pos())
	{
		Options += FString::Printf(TEXT("?PosX=%f?PosY=%f?PosZ=%f?RotX=%f?RotY=%f?RotZ=%f"),
			Message.pos().x(), Message.pos().y(), Message.pos().z(),
			Message.rot().x(), Message.rot().y(), Message.rot().z());
	}

	UGameplayStatics::OpenLevel(GetWorld(), FName(Message.map().c_str()), true, Options);
}
