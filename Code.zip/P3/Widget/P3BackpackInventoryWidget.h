// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3BackpackInventoryWidget.generated.h"

/**
 * 배낭 인벤토리 위젯
 */
UCLASS()
class P3_API UP3BackpackInventoryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void InitInventory();

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

private:
	UFUNCTION()
	void OnOpen();

	UFUNCTION()
	void OnClose();

	UPROPERTY(meta = (BindWidget))
	class UUniformGridPanel* InventoryItemSlotPanel = nullptr;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UP3InventorySlotWidget> SlotClass;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 RowCount = 5;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 ColumnCount = 8;

	UPROPERTY(Transient)
	TArray<class UP3InventorySlotWidget*> InventorySlots;

};
