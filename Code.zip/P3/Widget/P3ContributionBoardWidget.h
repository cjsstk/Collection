// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3ContributionBoardWidget.generated.h"

/**
 * 
 */
UCLASS()
class P3_API UP3ContributionBoardWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	UFUNCTION(BlueprintCallable)
	void CloseContributionBoard();

public:
	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveUpdateBoard();
};
