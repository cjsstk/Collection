// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3InventorySlotWidget.h"

#include "Components/Button.h"
#include "Components/Image.h"
#include "Components/TextBlock.h"

#include "Item/P3Item.h"
#include "P3InventoryComponent.h"

void UP3InventorySlotWidget::InitSlot(const FP3Item& InItem /*= FP3Item::InvalidItem*/)
{
	if (IconImage)
	{
		IconImage->SetVisibility(ESlateVisibility::Hidden);
	}

	if (SelectedImage)
	{
		SelectedImage->SetVisibility(ESlateVisibility::Hidden);
	}

	if (ItemNameText)
	{
		ItemNameText->SetVisibility(ESlateVisibility::Hidden);
	}

	if (StackText)
	{
		StackText->SetVisibility(ESlateVisibility::Hidden);
	}

	if (InItem.IsValid())
	{
		const FP3CmsItem& CmsItem = P3Cms::GetItem(InItem.Key);
		if (!CmsItem.Icon.IsNull() && ensure(IconImage))
		{
			IconImage->SetBrushFromTexture(CmsItem.Icon.LoadSynchronous());
			IconImage->SetVisibility(ESlateVisibility::HitTestInvisible);
		}

		if (ensure(ItemNameText))
		{
			ItemNameText->SetText(CmsItem.DisplayName);
			ItemNameText->SetVisibility(ESlateVisibility::HitTestInvisible);
		}

		if (ensure(StackText))
		{
			StackText->SetText(FText::AsNumber(InItem.Stack));
			StackText->SetVisibility(ESlateVisibility::HitTestInvisible);
		}

		SlotItem = InItem;
	}
}

void UP3InventorySlotWidget::SetSlotIndex(int32 InIndex)
{
	SlotIndex = InIndex;
}

void UP3InventorySlotWidget::Refresh(const FP3Item& InItem, bool bSelected)
{
	InitSlot(InItem);

	if (SelectedImage)
	{
		SelectedImage->SetVisibility(bSelected ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Hidden);
	}
}

void UP3InventorySlotWidget::NativeConstruct()
{
	Super::NativeConstruct();

}

void UP3InventorySlotWidget::NativeDestruct()
{
	Super::NativeDestruct();
	
}

FReply UP3InventorySlotWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (InMouseEvent.GetPressedButtons().Contains(EKeys::LeftMouseButton))
	{
		OnSlotLeftClicked.Broadcast(SlotIndex);
	}
	else if (InMouseEvent.GetPressedButtons().Contains(EKeys::RightMouseButton))
	{
		OnSlotRightClicked.Broadcast(SlotIndex);
	}

	return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
}

void UP3InventoryItemDetailWidget::Refresh(const FP3Item& InItem)
{
	if (IconImage)
	{
		IconImage->SetVisibility(ESlateVisibility::Hidden);
	}

	if (ItemNameText)
	{
		ItemNameText->SetVisibility(ESlateVisibility::Hidden);
	}

	if (ItemDescription)
	{
		ItemDescription->SetVisibility(ESlateVisibility::Hidden);
	}

	if (InItem.IsValid())
	{
		const FP3CmsItem& CmsItem = P3Cms::GetItem(InItem.Key);
		if (!CmsItem.Icon.IsNull() && ensure(IconImage))
		{
			IconImage->SetBrushFromTexture(CmsItem.Icon.LoadSynchronous());
			IconImage->SetVisibility(ESlateVisibility::HitTestInvisible);
		}

		if (ensure(ItemNameText))
		{
			ItemNameText->SetText(CmsItem.DisplayName);
			ItemNameText->SetVisibility(ESlateVisibility::HitTestInvisible);
		}

		if (ensure(ItemDescription))
		{
			ItemDescription->SetText(CmsItem.Description);
			ItemDescription->SetVisibility(ESlateVisibility::HitTestInvisible);
		}
	}
}

void UP3InventoryQuickSlotItemWidget::SetSlotIndex(int32 InIndex)
{
	SlotIndex = InIndex;
}

void UP3InventoryQuickSlotItemWidget::Refresh(bool bSelected, itemkey ItemKey)
{
	if (IconImage)
	{
		if (ItemKey == INVALID_ITEMKEY)
		{
			IconImage->SetBrushFromTexture(nullptr);
		}
		else
		{
			const FP3CmsItem& CmsItem = P3Cms::GetItem(ItemKey);
			IconImage->SetBrushFromTexture(CmsItem.Icon.LoadSynchronous());
		}
	}

	if (SelectedImage)
	{
		SelectedImage->SetVisibility(bSelected ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Hidden);
	}
}

FReply UP3InventoryQuickSlotItemWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (InMouseEvent.GetPressedButtons().Contains(EKeys::LeftMouseButton))
	{
		OnSlotLeftClicked.Broadcast(SlotIndex);
	}

	return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
}
