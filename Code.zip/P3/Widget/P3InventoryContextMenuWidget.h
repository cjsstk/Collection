// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widget/P3MainMenuWidget.h"
#include "Components/Image.h"
#include "Item/P3Item.h"
#include "P3InventoryContextMenuWidget.generated.h"


UENUM(Blueprintable)
enum class EP3InventoryContextType : uint8
{
	UseItem				UMETA(DisplayName = "Use Item"),
	RegisterThrowable	UMETA(DisplayName = "Register Throwable"),
	RegisterConsumable	UMETA(DisplayName = "Register Consumable"),
	Cancel				UMETA(DisplayName = "Cancel"),
	Count				UMETA(Hidden),
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnSlotClicked, EP3InventoryContextType, InContextType);

UCLASS()
class P3_API UP3ContextMenuSlot : public UUserWidget
{
	GENERATED_BODY()

public:
	void Refresh(bool bSelected, bool bActive);
	void SetContextName(const FText& InName);

	FP3OnSlotClicked OnSlotClicked;

protected:
	virtual void NativeConstruct() override;
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

private:
	UPROPERTY(meta = (BindWidget))
	class UImage* ContextImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UImage* SelectedImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UImage* DeactiveImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* ContextName = nullptr;

	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true"))
	FText ContextNameText;

	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true"))
	EP3InventoryContextType ContextType = EP3InventoryContextType::Cancel;

	bool bSlotActive = false;
};

UCLASS()
class P3_API UP3InventoryContextMenuWidget : public UP3MenuWidget
{
	GENERATED_BODY()

public:
	void Init();
	void Refresh();
	void SetCurrentSelectedItem(const FP3Item& InItem);
	void HideOnBlur(bool bNewHideOnBlur);

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	virtual void OnFocus() override;
	virtual void OnBlur() override;

private:
	virtual void OnUp() override;
	virtual void OnDown() override;
	virtual void OnSelectItem() override;

	bool IsCurrentItemThrowable() const;
	bool IsCurrentItemConsumable() const;

	UFUNCTION()
	void OnClicked(EP3InventoryContextType InContextType);

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UP3ContextMenuSlot> MenuClass;

	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* MenuBox;

	UPROPERTY(Transient)
	TArray<class UP3ContextMenuSlot*> ContextMenuSlots;

	int32 CurrentContextMenuIndex = 0;
	FP3Item CurrentSelectedItem;

	bool bHideOnBlur = true;
};
