// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ChatWidget.h"

#include "Components/Border.h"
#include "Components/Button.h"
#include "Components/EditableText.h"
#include "Components/ScrollBox.h"
#include "Components/TextBlock.h"
#include "Kismet/GameplayStatics.h"

#include "Network/P3ChatNet.h"
#include "P3Character.h"
#include "P3ClientWorld.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3PlayerController.h"

static TAutoConsoleVariable<float> CVarP3ChatFadeOutSeconds(
	TEXT("p3.chatFadeOutSeconds"),
	10.0f,
	TEXT("Waiting time to fade out chat window in seconds"), ECVF_Default);

void UP3ChatWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UP3GameInstance* GameInstance = GetGameInstance<UP3GameInstance>();

	if (!ensure(GameInstance))
	{
		return;
	}

	ChatNet = GameInstance->GetChatNet();

	if (ensure(ChatNet))
	{
		OnChatDelegate = ChatNet->OnChat.AddUObject(this, &UP3ChatWidget::OnRecvChat);
	}

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (Character)
	{
		Character->OnInputOpenChat.AddUniqueDynamic(this, &UP3ChatWidget::OnOpenChat);
	}

	if (ensure(InputEdit))
	{
		InputEdit->OnTextChanged.AddUniqueDynamic(this, &UP3ChatWidget::OnInputTextChanged);
		InputEdit->OnTextCommitted.AddUniqueDynamic(this, &UP3ChatWidget::OnInputTextCommitted);
	}

	if (ensure(PinButton))
	{
		PinButton->OnClicked.AddUniqueDynamic(this, &UP3ChatWidget::OnPinClicked);
	}

	if (ensure(UnpinButton))
	{
		UnpinButton->OnClicked.AddUniqueDynamic(this, &UP3ChatWidget::OnUnpinClicked);
	}

	// Blueprint must call SetFadeOutAnim
	ensure(FadeOutAnim);

	Reset();
}

void UP3ChatWidget::NativeDestruct()
{
	Super::NativeDestruct();

	if (ChatNet)
	{
		ChatNet->OnChat.Remove(OnChatDelegate);
	}

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (Character)
	{
		Character->OnInputOpenChat.RemoveDynamic(this, &UP3ChatWidget::OnOpenChat);
	}

	if (InputEdit)
	{
		InputEdit->OnTextChanged.RemoveDynamic(this, &UP3ChatWidget::OnInputTextChanged);
		InputEdit->OnTextCommitted.RemoveDynamic(this, &UP3ChatWidget::OnInputTextCommitted);
	}

	if (ensure(PinButton))
	{
		PinButton->OnClicked.RemoveDynamic(this, &UP3ChatWidget::OnPinClicked);
	}

	if (ensure(UnpinButton))
	{
		UnpinButton->OnClicked.RemoveDynamic(this, &UP3ChatWidget::OnUnpinClicked);
	}
}

void UP3ChatWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (!ensure(FadeOutAnim))
	{
		return;
	}

	const float FadeOutTimeSeconds = CVarP3ChatFadeOutSeconds.GetValueOnGameThread();

	if (bPinned)
	{
		IdleAgeSeconds = 0.0f;
	}
	else
	{
		IdleAgeSeconds += InDeltaTime;
	}

	if (bIsActive && IdleAgeSeconds >= FadeOutTimeSeconds)
	{
		PlayAnimation(FadeOutAnim);
		bIsActive = false;
	}

	if (!bIsActive && IdleAgeSeconds < FadeOutTimeSeconds)
	{
		StopAnimation(FadeOutAnim);
		SetRenderOpacity(1.0f);
		bIsActive = true;
	}

	if (ensure(ContentScrollBox))
	{
		FVector2D ContentSize = ContentScrollBox->GetDesiredSize();
		FVector2D PanelSize = ContentScrollBox->GetCachedGeometry().GetLocalSize();

		// If scrollbar is not int the end
		if (ContentScrollBox->GetScrollOffset() < ContentSize.Y - PanelSize.Y)
		{
			IdleAgeSeconds = 0.0f;
		}
	}
}

void UP3ChatWidget::Reset()
{
	if (ensure(ContentText))
	{
		ContentText->SetText(FText::GetEmpty());
	}

	StopAnimation(FadeOutAnim);
	SetRenderOpacity(1.0f);
	bIsActive = true;
	bPinned = true;

	if (ensure(PinButton))
	{
		PinButton->SetVisibility(ESlateVisibility::Collapsed);
	}

	if (ensure(UnpinButton))
	{
		UnpinButton->SetVisibility(ESlateVisibility::Visible);
	}
}

void UP3ChatWidget::OnOpenChat()
{
	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetOwningPlayer());

	if (!ensure(PlayerController))
	{
		return;
	}

	if (PlayerController->bCinematicMode)
	{
		return;
	}

	if (!ensure(InputEdit))
	{
		return;
	}

	PlayerController->SetInputModeUIOnly(*this, InputEdit->TakeWidget());
	bIsInputModeUIOnly = true;
	IdleAgeSeconds = 0.0f;
}

void UP3ChatWidget::OnRecvChat(const FString& UserName, uint32 ZoneChannelId, const FString& Msg)
{
	if (!ensure(ContentText))
	{
		return;
	}

	FString Line = FString::Printf(TEXT("%s> %s"), *UserName, *Msg);
	if (ZoneChannelId > 0)
	{
		Line = FString::Printf(TEXT("#%d %s"), ZoneChannelId, *Line);
	}

	Lines.Add(Line);

	if (Lines.Num() > 100)
	{
		Lines.RemoveAt(0);
	}

	if (ensure(ContentText))
	{
		ContentText->SetText(FText::AsCultureInvariant(FString::Join(Lines, TEXT("\n"))));
	}

	if (ensure(ContentScrollBox))
	{
		ContentScrollBox->ScrollToEnd();
	}

	IdleAgeSeconds = 0.0f;
}

void UP3ChatWidget::OnInputTextChanged(const FText& Text)
{
	IdleAgeSeconds = 0.0f;
}

void UP3ChatWidget::OnInputTextCommitted(const FText& Text, ETextCommit::Type CommitMethod)
{
	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetOwningPlayer());

	if (!ensure(PlayerController))
	{
		return;
	}

	if (!ensure(ChatNet))
	{
		return;
	}

	if (!ensure(InputEdit))
	{
		return;
	}

	if (CommitMethod == ETextCommit::OnEnter)
	{
		FString Msg = Text.ToString().TrimEnd();

		if (!Msg.IsEmpty())
		{
			// Get zone channel id
			uint32 ZoneChannelId = 0;
			UP3GameInstance* GameInstance = GetGameInstance<UP3GameInstance>();
			if (GameInstance && GameInstance->GetP3World() && GameInstance->GetP3World()->GetClientWorld())
			{
				ZoneChannelId = GameInstance->GetP3World()->GetClientWorld()->GetZoneChannelId();
			}

			TSharedRef<FP3ChatProtocol::FCSChat, ESPMode::ThreadSafe> Req(new FP3ChatProtocol::FCSChat());
			Req->Msg = Msg;
			Req->ZoneChannelId = ZoneChannelId;
			ChatNet->Send(Req);

			InputEdit->SetText(FText::GetEmpty());
		}
	}

	if (bIsInputModeUIOnly)
	{
		PlayerController->CancelInputModeUIOnly(*this);
		bIsInputModeUIOnly = false;
	}

	IdleAgeSeconds = 0.0f;
}

void UP3ChatWidget::OnPinClicked()
{
	bPinned = true;
	IdleAgeSeconds = 0.0f;

	if (ensure(PinButton))
	{
		PinButton->SetVisibility(ESlateVisibility::Collapsed);
	}

	if (ensure(UnpinButton))
	{
		UnpinButton->SetVisibility(ESlateVisibility::Visible);
	}
}

void UP3ChatWidget::OnUnpinClicked()
{
	bPinned = false;
	IdleAgeSeconds = CVarP3ChatFadeOutSeconds.GetValueOnGameThread(); // Fade out now

	if (ensure(PinButton))
	{
		PinButton->SetVisibility(ESlateVisibility::Visible);
	}

	if (ensure(UnpinButton))
	{
		UnpinButton->SetVisibility(ESlateVisibility::Collapsed);
	}
}
