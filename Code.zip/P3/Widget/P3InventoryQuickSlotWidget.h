// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Widget/P3MainMenuWidget.h"
#include "Item/P3Item.h"
#include "P3InventoryQuickSlotWidget.generated.h"

UENUM(Blueprintable)
enum class EP3InventoryQuickSlotType : uint8
{
	Throwable	UMETA(DisplayName = "Throwable"),
	Consumable	UMETA(DisplayName = "Consumable"),
};

UCLASS()
class P3_API UP3InventoryQuickSlotWidget : public UP3MenuWidget
{
	GENERATED_BODY()

public:
	void InitQuickSlot();
	void SetCurrentSelectedItem(const FP3Item& InItem);
	void Refresh();

	const TArray<itemkey>& GetInventoryQuickSlotItems() const;
	void SetInventoryQuickSlotItem(int32 QuickSlotIndex, itemkey NewItemKey);

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	virtual void OnFocus() override;
	virtual void OnBlur() override;

private:
	virtual void OnRight() override;
	virtual void OnLeft() override;
	virtual void OnSelectItem() override;

	UFUNCTION()
	void OnLeftClicked(int32 InSlotIndex);

	UPROPERTY(meta = (BindWidget))
	class UUniformGridPanel* QuickSlotItemPanel = nullptr;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UP3InventoryQuickSlotItemWidget> QuickSlotClass;

	UPROPERTY(EditAnywhere, meta = (AllowPrivateAccess = "true"))
	EP3InventoryQuickSlotType QuickSlotType = EP3InventoryQuickSlotType::Throwable;

	UPROPERTY()
	TArray<class UP3InventoryQuickSlotItemWidget*> QuickSlots;

	int32 CurrentQuickSlotIndex = -1;

	FP3Item CurrentSelectedItem;

};
