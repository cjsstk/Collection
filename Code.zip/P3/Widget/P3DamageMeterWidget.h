// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3DamageMeterWidget.generated.h"

UCLASS(Blueprintable)
class P3_API UP3DamageMeterWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void SetData(const struct FP3DamageMeter& Data, int32 MaxAmount);

private:
	UPROPERTY(meta = (BindWidget))
	class UTextBlock* NameText = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* AmountText = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UProgressBar* DamageProgressBar = nullptr;
};
