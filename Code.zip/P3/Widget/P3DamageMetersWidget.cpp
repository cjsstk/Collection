// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3DamageMetersWidget.h"

#include "Components/VerticalBox.h"

#include "Action/P3PawnActionComponent.h"
#include "P3Character.h"
#include "P3DamageMetersComponent.h"
#include "P3DamageMeterWidget.h"
#include "P3InventoryComponent.h"

TAutoConsoleVariable<int32> CVarP3ShowDamageMeter(
	TEXT("p3.showDamageMeter"),
	0,
	TEXT("0: hide, 1: show"), ECVF_Cheat);

void UP3DamageMetersWidget::NativeConstruct()
{
	Super::NativeConstruct();

	Reset();
}

void UP3DamageMetersWidget::NativeDestruct()
{
	Super::NativeDestruct();
}

void UP3DamageMetersWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	// Clean up if target disappears

	if (!DamageMetersComponent.IsValid())
	{
		if (Version > 0)
		{
			MetersBox->ClearChildren();
			Version = 0;
		}
		return;
	}

	// Compare store version with mine

	const FP3DamageMetersStore& Store = DamageMetersComponent->GetMetersStore();

	if (Store.Version <= Version)
	{
		return;
	}

	Version = Store.Version;

	// Find max amount for percent display

	int32 MaxAmount = 0;
	for (auto& Meter : Store.Meters)
	{
		if (Meter.Value.DamageAmount > MaxAmount)
		{
			MaxAmount = Meter.Value.DamageAmount;
		}
	}

	// Remove children if children count is more than actual meter count

	while (Store.Meters.Num() < MetersBox->GetChildrenCount())
	{
		MetersBox->RemoveChildAt(MetersBox->GetChildrenCount() - 1);
	}

	// Add children if actual meter count is more than children count

	while (Store.Meters.Num() > MetersBox->GetChildrenCount())
	{
		UP3DamageMeterWidget* MeterWidget = CreateWidget<UP3DamageMeterWidget>(GetOwningPlayer(), MeterClass);

		if (!ensure(MeterWidget))
		{
			break;
		}

		MetersBox->AddChild(MeterWidget);
	}

	// Set data

	int32 ChildIndex = 0;

	for (auto& Meter : Store.Meters)
	{
		UP3DamageMeterWidget* MeterWidget = Cast<UP3DamageMeterWidget>(MetersBox->GetChildAt(ChildIndex));

		if (!ensure(MeterWidget))
		{
			break;
		}

		MeterWidget->SetData(Meter.Value, MaxAmount);

		++ChildIndex;
	}
}

void UP3DamageMetersWidget::Reset()
{
	if (ensure(MetersBox))
	{
		MetersBox->ClearChildren();
	}
}

void UP3DamageMetersWidget::SetDamageMetersComponent(class UP3DamageMetersComponent* InDamageMetersComponent)
{
	if (DamageMetersComponent != InDamageMetersComponent)
	{
		DamageMetersComponent = InDamageMetersComponent;
		Version = 0;
	}
}
