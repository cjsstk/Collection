// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"

#include "P3ConsumableItem.generated.h"

UCLASS(Blueprintable)
class P3_API UP3ConsumableItem : public UUserWidget
{
	GENERATED_BODY()

public:
	void Reset();
	void SetItem(const struct FP3Item& Consumable, bool bSelected);

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

private:
	UPROPERTY(meta = (BindWidget))
	class UImage* IconImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UImage* SelectedImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* NameTextBlock = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* StackText = nullptr;
};
