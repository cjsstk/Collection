// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"

#include "P3Cms.h"
#include "P3Core.h"
#include "P3WorldServerInfo.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/userlistener.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/userlistener.pb.h"
#endif

#include "P3LoginHUDWidget.generated.h"

class UP3GameWorldNet;

UCLASS(Blueprintable)
class P3_API UP3LoginHUDWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	// GameWorldNet Events
	void OnConnectedToGameWorld(UP3GameWorldNet& GameWorldNet, bool bSuccess);

	void OnLoginReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLLoginRes& Message);
	void OnListCharactersReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLListCharactersRes& Message);
	void OnCreateCharacterReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLCreateCharacterRes& Message);
	void OnDeleteCharacterReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLDeleteCharacterRes& Message);
	void OnSelectCharacterReply(UP3GameWorldNet& GameWorldNet, const pb::WU2CLSelectCharacterRes& Message);

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

private:
	UFUNCTION()
	void OnLoginDialogSignUp();

	UFUNCTION()
	void OnLoginDialogServerAddress();

	UFUNCTION()
	void OnLoginSuccess(const FString& Account, const TArray<FP3WorldServerInfo>& WorldServerInfos);

	UFUNCTION()
	void OnServerAddressDialogOK();

	UFUNCTION()
	void OnServerAddressDialogCancel();

	UFUNCTION()
	void OnSignUpDialogClose();

	UFUNCTION()
	void OnSelectWorldDialogSelectItem(const FP3WorldServerInfo& WorldServerInfo);

	UFUNCTION()
	void OnMessageDialogOK();

	void OnSelectCharacterDialogCreate();
	void OnSelectCharacterDialogDelete(charid CharacterId);
	void OnSelectCharacterDialogEnter(charid CharacterId);
	void OnSelectCharacterDialogClose();
	void OnCreateCharacterDialogCreate(const FString& Name, EP3CharClass CharClass);

	UPROPERTY(meta = (BindWidget))
	class UP3LoginDialog* LoginDialog = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3SignUpDialog* SignUpDialog = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3ServerAddressDialog* ServerAddressDialog = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3SelectWorldDialog* SelectWorldDialog = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3SelectCharacterDialog* SelectCharacterDialog = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3CreateCharacterDialog* CreateCharacterDialog = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UWidget* MessageDialog = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* MessageText = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* MessageOKButton = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UBorder* LoadingDialog = nullptr;

	FDelegateHandle OnSelectCharacterDialogCreateDelegate;
	FDelegateHandle OnSelectCharacterDialogDeleteDelegate;
	FDelegateHandle OnSelectCharacterDialogEnterDelegate;
	FDelegateHandle OnSelectCharacterDialogCloseDelegate;
	FDelegateHandle OnCreateCharacterDialogCreateDelegate;
};
