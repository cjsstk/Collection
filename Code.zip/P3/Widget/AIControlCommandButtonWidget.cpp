// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "AIControlCommandButtonWidget.h"

#include "P3World.h"
#include "P3ServerWorld.h"

void UAIControlCommandButtonWidget::ExecuteCommand()
{
	FP3NetAICommand Packet;
	Packet.GameplayTag = GameplayTag;

	P3Core::GetP3World(*this)->Client_SendPacketReliable((UP3ServerWorld*)(nullptr), INVALID_ACTORID, nullptr, Packet, EP3NetComponentType::ServerWorld, &UP3ServerWorld::HandleAIControlCommand);
}
