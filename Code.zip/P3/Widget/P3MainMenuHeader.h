// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3MainMenuHeader.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3MainMenuHeaderOnClicked, int32, MenuIndex);

UCLASS()
class P3_API UP3MainMenuHeader : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

	void InitHeader(const FText& InText, int32 InMenuIndex);
	void Refresh(bool bSelected);

	FP3MainMenuHeaderOnClicked MainMenuHeaderOnClicked;

private:
	void SetText(const FText& InText);

	UPROPERTY(meta = (BindWidget))
	class UImage* IconImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UImage* SelectedImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* MenuTextBlock = nullptr;

	int32 MenuIndex = 0;

};
