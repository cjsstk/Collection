// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ComboNameWidget.h"

#include "P3Character.h"
#include "P3ComboTableComponent.h"

static TAutoConsoleVariable<int32> CVarP3ShowComboNameWidget(
	TEXT("p3.showComboNameWidget"),
	0,
	TEXT("1: show. 0: hide"), ECVF_Cheat);

void UP3ComboNameWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	AP3Character* Character = GetOwningPlayerPawn<AP3Character>();

	if (!Character || !Character->GetComboComponent())
	{
		return;
	}

	if (!bDelegateBound)
	{
		// Since combo table component is created at BeginPlay(), we need to bind from tick
		Character->GetComboComponent()->OnComboStarted.AddUniqueDynamic(this, &UP3ComboNameWidget::OnComboStarted);

		bDelegateBound = true;		
	}

	if (CVarP3ShowComboNameWidget.GetValueOnGameThread() != 0)
	{
		FString NextComboInputString = Character->GetComboComponent()->GetNextComboInputString();
		if (!NextComboInputString.IsEmpty())
		{
			ReceiveComboInput(*NextComboInputString);
		}
	}
}

void UP3ComboNameWidget::OnComboStarted(const FP3ComboRow& ComboRow)
{
	if (CVarP3ShowComboNameWidget.GetValueOnGameThread() == 0)
	{
		return;
	}

	ReceiveComboStart(ComboRow.ComboName);
}
