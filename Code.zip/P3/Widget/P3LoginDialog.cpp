// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3LoginDialog.h"

#include "Components/Button.h"
#include "Components/EditableTextBox.h"
#include "Components/TextBlock.h"

#include "P3GameInstance.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "Network/P3AuthNet.h"

TAutoConsoleVariable<FString> CVarP3DefaultAccount(
	TEXT("p3.defaultAccount"),
	"",
	TEXT("Enable world server connection"), ECVF_Default);

TAutoConsoleVariable<FString> CVarP3DefaultPassword(
	TEXT("p3.defaultPassword"),
	"",
	TEXT("Enable world server connection"), ECVF_Default);


void UP3LoginDialog::NativeConstruct()
{
	Super::NativeConstruct();

	PasswordEdit->OnTextCommitted.AddUniqueDynamic(this, &UP3LoginDialog::OnPasswordTextCommitted);
	ServerAddressButton->OnClicked.AddUniqueDynamic(this, &UP3LoginDialog::OnServerAddressClicked);
	LoginButton->OnClicked.AddUniqueDynamic(this, &UP3LoginDialog::OnLoginClicked);
	SignUpButton->OnClicked.AddUniqueDynamic(this, &UP3LoginDialog::OnSignUpClicked);

	AuthNet = GetWorld()->GetGameInstanceChecked<UP3GameInstance>()->GetAuthNet();
	check(AuthNet);

	OnConnectedToAuthDelegate = AuthNet->OnConnected.AddUObject(this, &UP3LoginDialog::OnConnectedToAuth);
	OnLoginDelegate = AuthNet->OnLogin.AddUObject(this, &UP3LoginDialog::OnLogin);
}

void UP3LoginDialog::NativeDestruct()
{
	Super::NativeDestruct();

	PasswordEdit->OnTextCommitted.RemoveDynamic(this, &UP3LoginDialog::OnPasswordTextCommitted);
	ServerAddressButton->OnClicked.RemoveDynamic(this, &UP3LoginDialog::OnServerAddressClicked);
	LoginButton->OnClicked.RemoveDynamic(this, &UP3LoginDialog::OnLoginClicked);
	SignUpButton->OnClicked.RemoveDynamic(this, &UP3LoginDialog::OnSignUpClicked);

	AuthNet->OnConnected.Remove(OnConnectedToAuthDelegate);
	AuthNet->OnLogin.Remove(OnLoginDelegate);
}

void UP3LoginDialog::Reset()
{
	FString Address = FString::Printf(TEXT("%s:%d"), *AuthNet->GetHost(), AuthNet->GetPort());
	AddressText->SetText(FText::AsCultureInvariant(Address));
	MessageText->SetText(FText::GetEmpty());
	AccountEdit->SetText(FText::AsCultureInvariant(*CVarP3DefaultAccount.GetValueOnGameThread()));
	PasswordEdit->SetText(FText::AsCultureInvariant(*CVarP3DefaultPassword.GetValueOnGameThread()));

	AccountEdit->SetUserFocus(GetOwningPlayer());

	LoginButton->SetIsEnabled(true);
}

void UP3LoginDialog::OnServerAddressClicked()
{
	OnServerAddress.Broadcast();
}

void UP3LoginDialog::OnLoginClicked()
{
	if (AccountEdit)
	{
		if (AccountEdit->GetText().IsEmpty())
		{
			MessageText->SetText(P3LOC_LOGIN("AccountIsEmpty"));
			return;
		}
	}

	MessageText->SetText(FText::GetEmpty());
	LoginButton->SetIsEnabled(false);
	AuthNet->Connect();
}

void UP3LoginDialog::OnSignUpClicked()
{
	OnSignUp.Broadcast();
}

void UP3LoginDialog::OnPasswordTextCommitted(const FText& Text, ETextCommit::Type CommitMethod)
{
	if (CommitMethod == ETextCommit::OnEnter)
	{
		OnLoginClicked();
	}
}

void UP3LoginDialog::OnConnectedToAuth(bool bSuccess)
{
	if (!IsVisible())
	{
		return;
	}

	if (bSuccess)
	{
		MessageText->SetText(P3LOC_LOGIN("Connected"));

		FString Account = FText::TrimPrecedingAndTrailing(AccountEdit->GetText()).ToString();
		FString Password = PasswordEdit->GetText().ToString();

		AuthNet->Login(Account, Password);
	}
	else
	{
		MessageText->SetText(P3LOC_LOGIN("FailedToConnect"));
		LoginButton->SetIsEnabled(true);
	}
}

void UP3LoginDialog::OnLogin(bool bSuccess, const FString& Account, const TArray<FP3WorldServerInfo>& WorldServerInfos)
{
	if (bSuccess)
	{
		MessageText->SetText(P3LOC_LOGIN("SuccessToLogin"));
		OnLoginSuccess.Broadcast(Account, WorldServerInfos);
	}
	else
	{
		MessageText->SetText(P3LOC_LOGIN("FailedToLogin"));
		LoginButton->SetIsEnabled(true);
	}
}
