// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3InventoryQuickSlotWidget.h"

#include "Components/TextBlock.h"
#include "Components/UniformGridPanel.h"
#include "Components/UniformGridSlot.h"

#include "P3Character.h"
#include "P3Input.h"
#include "P3InventoryComponent.h"
#include "P3InventorySlotWidget.h"

void UP3InventoryQuickSlotWidget::InitQuickSlot()
{
	if (!QuickSlotItemPanel)
	{
		return;
	}

	QuickSlotItemPanel->ClearChildren();
	QuickSlots.Empty();

	const TArray<itemkey>& QuickSlotItems = GetInventoryQuickSlotItems();

	for (int32 Index = 0; Index < QuickSlotItems.Num(); ++Index)
	{
		UP3InventoryQuickSlotItemWidget* QuickSlotItem = CreateWidget<UP3InventoryQuickSlotItemWidget>(GetOwningPlayer(), QuickSlotClass);
		if (!QuickSlotItem)
		{
			continue;
		}

		QuickSlotItem->SetSlotIndex(Index);
		QuickSlotItem->OnSlotLeftClicked.AddUniqueDynamic(this, &UP3InventoryQuickSlotWidget::OnLeftClicked);
		QuickSlotItem->Refresh(CurrentQuickSlotIndex == Index, QuickSlotItems[Index]);

		UUniformGridSlot* UniformGridSlot = QuickSlotItemPanel->AddChildToUniformGrid(QuickSlotItem);
		if (ensure(UniformGridSlot))
		{
			UniformGridSlot->SetRow(0);
			UniformGridSlot->SetColumn(Index);
		}

		QuickSlots.Add(QuickSlotItem);
	}

}

void UP3InventoryQuickSlotWidget::SetCurrentSelectedItem(const FP3Item& InItem)
{
	if (!InItem.IsValid())
	{
		ensure(0);
		return;
	}

	CurrentSelectedItem = InItem;
}

void UP3InventoryQuickSlotWidget::Refresh()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!Character)
	{
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		return;
	}

	const TArray<itemkey>& QuickSlotItems = GetInventoryQuickSlotItems();

	for (int32 Index = 0; Index < QuickSlotItems.Num(); ++Index)
	{
		const FP3Item& Item = InvenComp->GetItemByKey(QuickSlotItems[Index]);
		if (!Item.IsValid())
		{
			SetInventoryQuickSlotItem(Index, INVALID_ITEMKEY);
		}

		UP3InventoryQuickSlotItemWidget* QuickSlot = QuickSlots[Index];
		if (QuickSlot)
		{
			QuickSlot->Refresh(CurrentQuickSlotIndex == Index, QuickSlotItems[Index]);
		}
	}
}

const TArray<itemkey>& UP3InventoryQuickSlotWidget::GetInventoryQuickSlotItems() const
{
	static TArray<itemkey> DummyQuickSlotItems;

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!Character)
	{
		return DummyQuickSlotItems;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (InvenComp)
	{
		return InvenComp->GetQuickSlotItems(QuickSlotType);
	}

	return DummyQuickSlotItems;
}

void UP3InventoryQuickSlotWidget::SetInventoryQuickSlotItem(int32 QuickSlotIndex, itemkey NewItemKey)
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!Character)
	{
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!InvenComp)
	{
		return;
	}

	InvenComp->SetQuickSlotItem(QuickSlotType, QuickSlotIndex, NewItemKey);
}

void UP3InventoryQuickSlotWidget::NativeConstruct()
{
	Super::NativeConstruct();

	InitQuickSlot();
}

void UP3InventoryQuickSlotWidget::NativeDestruct()
{
	Super::NativeDestruct();
}

void UP3InventoryQuickSlotWidget::OnFocus()
{
	Super::OnFocus();

	CurrentQuickSlotIndex = 0;

	Refresh();
}

void UP3InventoryQuickSlotWidget::OnBlur()
{
	Super::OnBlur();

	CurrentQuickSlotIndex = -1;

	Refresh();
}

void UP3InventoryQuickSlotWidget::OnRight()
{
	CurrentQuickSlotIndex = (CurrentQuickSlotIndex + 1) % GetInventoryQuickSlotItems().Num();

	Refresh();
}

void UP3InventoryQuickSlotWidget::OnLeft()
{
	int32 QuickSlotNum = GetInventoryQuickSlotItems().Num();
	CurrentQuickSlotIndex = (CurrentQuickSlotIndex - 1 + QuickSlotNum) % QuickSlotNum;

	Refresh();
}

void UP3InventoryQuickSlotWidget::OnSelectItem()
{
	SetInventoryQuickSlotItem(CurrentQuickSlotIndex, CurrentSelectedItem.Key);

	Refresh();

	if (PrevFocusWidget)
	{
		PrevFocusWidget->Open();
	}
}

void UP3InventoryQuickSlotWidget::OnLeftClicked(int32 InSlotIndex)
{
	if (GetInventoryQuickSlotItems().IsValidIndex(InSlotIndex))
	{
		CurrentQuickSlotIndex = InSlotIndex;
	}

	Refresh();

	OnSelectItem();
}
