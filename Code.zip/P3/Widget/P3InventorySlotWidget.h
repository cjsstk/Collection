// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"

#include "Item/P3Item.h"
#include "P3InventorySlotWidget.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnSlotPressed, int32, InSlotIndex);

UCLASS(Blueprintable)
class P3_API UP3InventorySlotWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	void InitSlot(const FP3Item& InItem = FP3Item::InvalidItem);
	void SetSlotIndex(int32 InIndex);
	void Refresh(const FP3Item& InItem, bool bSelected);
	const FP3Item& GetSlotItem() const { return SlotItem; }

	FP3OnSlotPressed OnSlotLeftClicked;
	FP3OnSlotPressed OnSlotRightClicked;

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

private:	
	UPROPERTY(meta = (BindWidget))
	class UImage* IconImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UImage* SelectedImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* ItemNameText = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* StackText = nullptr;

	int32 SlotIndex = 0;
	FP3Item SlotItem;
};


UCLASS(Blueprintable)
class P3_API UP3InventoryItemDetailWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void Refresh(const FP3Item& InItem);

private:
	UPROPERTY(meta = (BindWidget))
	class UImage* IconImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* ItemNameText = nullptr;

	UPROPERTY(BlueprintReadWrite, meta = (BindWidget, AllowPrivateAccess = "true"))
	class UTextBlock* ItemDescription = nullptr;
};

UCLASS(Blueprintable)
class P3_API UP3InventoryQuickSlotItemWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void SetSlotIndex(int32 InIndex);
	void Refresh(bool bSelected, itemkey ItemKey);

	FP3OnSlotPressed OnSlotLeftClicked;

protected:
	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

private:
	UPROPERTY(meta = (BindWidget))
	class UImage* IconImage = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UImage* SelectedImage = nullptr;

	int32 SlotIndex = 0;
};
