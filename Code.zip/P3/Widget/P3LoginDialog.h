// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3WorldServerInfo.h"
#include "P3LoginDialog.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3LoginDialogOnServerAddress);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3LoginDialogOnSignUp);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3LoginDialogOnLoginSuccess, const FString&, Account, const TArray<FP3WorldServerInfo>&, WorldServerInfos);

UCLASS(Blueprintable)
class P3_API UP3LoginDialog : public UUserWidget
{
	GENERATED_BODY()

public:
	void Reset();

	FP3LoginDialogOnServerAddress OnServerAddress;
	FP3LoginDialogOnSignUp OnSignUp;
	FP3LoginDialogOnLoginSuccess OnLoginSuccess;

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

private:
	UFUNCTION()
	void OnPasswordTextCommitted(const FText& Text, ETextCommit::Type CommitMethod);

	UFUNCTION()
	void OnServerAddressClicked();

	UFUNCTION()
	void OnLoginClicked();

	UFUNCTION()
	void OnSignUpClicked();

	UFUNCTION()
	void OnConnectedToAuth(bool bSuccess);

	UFUNCTION()
	void OnLogin(bool bSuccess, const FString& Account, const TArray<FP3WorldServerInfo>& WorldServerInfos);

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* AddressText = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UEditableTextBox* AccountEdit = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UEditableTextBox* PasswordEdit = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* ServerAddressButton = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* LoginButton = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* SignUpButton = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* MessageText = nullptr;

	UPROPERTY()
	class UP3AuthNet* AuthNet = nullptr;

	FDelegateHandle OnConnectedToAuthDelegate;
	FDelegateHandle OnLoginDelegate;
};
