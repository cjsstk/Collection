// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ConsumableItem.h"

#include "Components/Image.h"
#include "Components/TextBlock.h"

#include "Item/P3Item.h"
#include "P3ConsumableComponent.h"
#include "P3PickupableComponent.h"

void UP3ConsumableItem::NativeConstruct()
{
	Super::NativeConstruct();

	Reset();
}

void UP3ConsumableItem::NativeDestruct()
{
	Super::NativeDestruct();
}

void UP3ConsumableItem::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);
}

void UP3ConsumableItem::Reset()
{
	if (ensure(IconImage))
	{
		IconImage->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UP3ConsumableItem::SetItem(const FP3Item& Consumable, bool bSelected)
{
	const FP3CmsItem& CmsItem = P3Cms::GetItem(Consumable.Key);
	if (!CmsItem.Icon.IsNull())
	{
		if (ensure(IconImage))
		{
			IconImage->SetBrushFromTexture(CmsItem.Icon.LoadSynchronous());
			IconImage->SetVisibility(ESlateVisibility::HitTestInvisible);
			IconImage->SetBrushTintColor(FSlateColor(bSelected ? FLinearColor(1.0f, 1.0f, 1.0f, 0.9f) : FLinearColor(0.3f, 0.3f, 0.3f, 0.8f)));
		}

		if (ensure(NameTextBlock))
		{
			NameTextBlock->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
	else
	{
		if (ensure(NameTextBlock))
		{
			NameTextBlock->SetText(CmsItem.DisplayName);
			NameTextBlock->SetVisibility(ESlateVisibility::HitTestInvisible);
		}
	}

	if (ensure(StackText))
	{
		StackText->SetText(FText::AsNumber(Consumable.Stack));
		StackText->SetColorAndOpacity(FSlateColor(bSelected ? FLinearColor(1.0f, 1.0f, 1.0f, 0.9f) : FLinearColor(0.4f, 0.4f, 0.4f, 0.8f)));
	}

	if (ensure(SelectedImage))
	{
		SelectedImage->SetVisibility(bSelected ? ESlateVisibility::HitTestInvisible : ESlateVisibility::Collapsed);
	}
}
