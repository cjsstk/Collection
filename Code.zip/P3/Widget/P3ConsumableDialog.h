// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3ConsumableDialog.generated.h"

UCLASS(Blueprintable)
class P3_API UP3ConsumableDialog : public UUserWidget
{
	GENERATED_BODY()

public:
	void Reset();

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

private:
	UFUNCTION()
	void OnOpen();

	UFUNCTION()
	void OnClose();

	UFUNCTION()
	void OnNext();

	UFUNCTION()
	void OnPrev();

	UFUNCTION()
	void OnUse();

	UFUNCTION()
	void OnThrow();

	UFUNCTION()
	void OnHold();

	UFUNCTION()
	void ConsumableRefresh();

	UFUNCTION()
	void ThrowableRefresh();

	void OnAimPressed();
	void OnAimReleased();

	void OnThrowPressed();
	void OnThrowReleased();

	void OnInteractPressed();
	void OnInteractReleased();

	void OnUseItemPressed();
	void OnUseItemReleased();

	void OnPrevPressed();
	void OnPrevReleased();

	void OnNextPressed();
	void OnNextReleased();

	void OnThrowableChange();

	UPROPERTY(meta = (BindWidget))
	class UScrollBox* ThrowableItemScrollBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* ThrowableItemBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UScrollBox* ConsumableItemScrollBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* ConsumableItemBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UHorizontalBox* InfoGuideBar = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UHorizontalBox* ItemNameBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* ItemNameText = nullptr;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UP3ConsumableItem> ItemClass;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UUserWidget> NonItemClass;

	UPROPERTY(meta = (BindWidgetAnim))
	UWidgetAnimation* InfoGuideAnim = nullptr;

	UPROPERTY(meta = (BindWidgetAnim))
	UWidgetAnimation* ConsumableScrollAnim = nullptr;

	UPROPERTY(meta = (BindWidgetAnim))
	UWidgetAnimation* ThrowableScrollAnim = nullptr;

	int32 SelectedThrowableIndex = 0;
	int32 SelectedConsumableIndex = 0;

	float ChangingThrowableMaintainTimeSeconds = 2.0f;
	float ChangingThrowableMaintainTimeAgeSeconds = 0.0f;

	/** 
	 * User Inputs 
	 */
	bool bInAimMode = false;
};
