// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3ContributionBoardWidget.h"

#include "P3Core.h"
#include "P3PlayerController.h"

void UP3ContributionBoardWidget::CloseContributionBoard()
{
	AP3PlayerController* PlayerController = P3Core::GetP3PlayerController(*this);

	if (PlayerController)
	{
		PlayerController->ShowContributionBoard(false);
	}
}
