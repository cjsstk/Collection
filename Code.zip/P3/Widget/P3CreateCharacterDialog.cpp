// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CreateCharacterDialog.h"

#include "Components/Button.h"
#include "Components/ComboBoxString.h"
#include "Components/EditableTextBox.h"
#include "Components/TextBlock.h"
#include "Kismet/GameplayStatics.h"

#include "P3GameInstance.h"
#include "P3Localization.h"

void UP3CreateCharacterDialog::NativeConstruct()
{
	Super::NativeConstruct();

	if (ensure(CreateButton))
	{
		CreateButton->OnClicked.AddUniqueDynamic(this, &UP3CreateCharacterDialog::OnCreateClicked);
	}

	if (ensure(CancelButton))
	{
		CancelButton->OnClicked.AddUniqueDynamic(this, &UP3CreateCharacterDialog::OnCancelClicked);
	}
}

void UP3CreateCharacterDialog::NativeDestruct()
{
	Super::NativeDestruct();

	if (CreateButton)
	{
		CreateButton->OnClicked.RemoveDynamic(this, &UP3CreateCharacterDialog::OnCreateClicked);
	}

	if (CancelButton)
	{
		CancelButton->OnClicked.RemoveDynamic(this, &UP3CreateCharacterDialog::OnCancelClicked);
	}
}

void UP3CreateCharacterDialog::Reset()
{
	MessageText->SetText(FText::GetEmpty());
	NameEdit->SetText(FText::GetEmpty());

	CreateButton->SetIsEnabled(true);

	ClassCombo->ClearSelection();
	ClassCombo->ClearOptions();

	UEnum* Enum = FindObject<UEnum>(ANY_PACKAGE, TEXT("EP3CharClass"), true);
	if (ensure(Enum))
	{
		const int32 StartIndex = (int32)EP3CharClass::Invalid + 1;
		const int32 EndIndex = Enum->NumEnums() - 2; // Exclude MAX
		for (int32 Index = StartIndex; Index <= EndIndex; ++Index)
		{
			ClassCombo->AddOption(Enum->GetNameStringByIndex(Index));
		}

		if (ensure(EndIndex - StartIndex >= 0))
		{
			ClassCombo->SetSelectedOption(Enum->GetNameStringByIndex(StartIndex));
		}
	}

	NameEdit->SetUserFocus(GetOwningPlayer());
}

void UP3CreateCharacterDialog::OnCreateClicked()
{
	const FString Name = FText::TrimPrecedingAndTrailing(NameEdit->GetText()).ToString();

	if (Name.IsEmpty())
	{
		MessageText->SetText(P3LOC_LOGIN("CharacterNameIsEmpty"));
		return;
	}

	UEnum* Enum = FindObject<UEnum>(ANY_PACKAGE, TEXT("EP3CharClass"), true);
	if (!ensure(Enum))
	{
		return;
	}

	EP3CharClass CharClass = (EP3CharClass)Enum->GetValueByNameString(ClassCombo->GetSelectedOption());

	CreateButton->SetIsEnabled(false);
	OnCreate.Broadcast(Name, CharClass);
}

void UP3CreateCharacterDialog::OnCancelClicked()
{
	SetVisibility(ESlateVisibility::Collapsed);
	OnClose.Broadcast();
}
