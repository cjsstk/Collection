// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ConsumableDialog.h"

#include "Components/HorizontalBox.h"
#include "Components/InputComponent.h"
#include "Components/ScrollBox.h"
#include "Components/TextBlock.h"
#include "Components/VerticalBox.h"

#include "Action/P3PawnActionComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3CharacterMovementComponent.h"
#include "P3ConsumableComponent.h"
#include "P3ConsumableItem.h"
#include "P3ComboTableComponent.h"
#include "P3GameUserSettings.h"
#include "P3IngredientComponent.h"
#include "P3InventoryComponent.h"
#include "P3Log.h"

void UP3ConsumableDialog::NativeConstruct()
{
	Super::NativeConstruct();

	Reset();

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (Character)
	{
		Character->OnInputOpenConsumableUI.AddUniqueDynamic(this, &UP3ConsumableDialog::OnOpen);
		Character->OnInputCloseConsumableUI.AddUniqueDynamic(this, &UP3ConsumableDialog::OnClose);
		Character->OnInputNextConsumable.AddUniqueDynamic(this, &UP3ConsumableDialog::OnNext);
		Character->OnInputPrevConsumable.AddUniqueDynamic(this, &UP3ConsumableDialog::OnPrev);
		Character->OnInputUseConsumable.AddUniqueDynamic(this, &UP3ConsumableDialog::OnUse);
		Character->OnInputThrowConsumable.AddUniqueDynamic(this, &UP3ConsumableDialog::OnThrow);
		Character->OnInputHoldItemFromInventory.AddUniqueDynamic(this, &UP3ConsumableDialog::OnHold);

		UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();

		if (ensure(InventoryComp))
		{
			InventoryComp->OnChangeConsumable.AddUniqueDynamic(this, &UP3ConsumableDialog::ConsumableRefresh);
			InventoryComp->OnChangeConsumable.AddUniqueDynamic(this, &UP3ConsumableDialog::ThrowableRefresh);
			InventoryComp->OnChangeQuickSlot.AddUniqueDynamic(this, &UP3ConsumableDialog::ConsumableRefresh);
			InventoryComp->OnChangeQuickSlot.AddUniqueDynamic(this, &UP3ConsumableDialog::ThrowableRefresh);
		}

		OnOpen();
	}
}

void UP3ConsumableDialog::NativeDestruct()
{
	Super::NativeDestruct();

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (Character)
	{
		Character->OnInputOpenConsumableUI.RemoveDynamic(this, &UP3ConsumableDialog::OnOpen);
		Character->OnInputCloseConsumableUI.RemoveDynamic(this, &UP3ConsumableDialog::OnClose);
		Character->OnInputNextConsumable.RemoveDynamic(this, &UP3ConsumableDialog::OnNext);
		Character->OnInputPrevConsumable.RemoveDynamic(this, &UP3ConsumableDialog::OnPrev);
		Character->OnInputUseConsumable.RemoveDynamic(this, &UP3ConsumableDialog::OnUse);
		Character->OnInputThrowConsumable.RemoveDynamic(this, &UP3ConsumableDialog::OnThrow);

		UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();

		if (ensure(InventoryComp))
		{
			InventoryComp->OnChangeConsumable.RemoveDynamic(this, &UP3ConsumableDialog::ConsumableRefresh);
			InventoryComp->OnChangeConsumable.RemoveDynamic(this, &UP3ConsumableDialog::ThrowableRefresh);
			InventoryComp->OnChangeQuickSlot.RemoveDynamic(this, &UP3ConsumableDialog::ConsumableRefresh);
			InventoryComp->OnChangeQuickSlot.RemoveDynamic(this, &UP3ConsumableDialog::ThrowableRefresh);
		}
	}
}

void UP3ConsumableDialog::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	const FP3CharacterStore& CharacterStore = Character->GetCharacterStoreBP();
	if (CharacterStore.bIsChangingThrowable)
	{
		ChangingThrowableMaintainTimeAgeSeconds += InDeltaTime;

		if (ChangingThrowableMaintainTimeAgeSeconds >= ChangingThrowableMaintainTimeSeconds)
		{
			UP3CommandComponent* CommandComp = Character->GetCommandComponent();
			if (!CommandComp)
			{
				return;
			}

			FP3CommandRequestParams Params;
			Params.SetChangingThrowable_bNewChangingThrowable = false;
			CommandComp->RequestCommand(UP3SetChangingThrowableCommand::StaticClass(), Params);

			ChangingThrowableMaintainTimeAgeSeconds = 0.0f;
		}
	}
}

void UP3ConsumableDialog::Reset()
{
	if (ensure(ConsumableItemBox))
	{
		ConsumableItemBox->ClearChildren();
	}
}

void UP3ConsumableDialog::OnOpen()
{
	SetVisibility(ESlateVisibility::HitTestInvisible);

	ConsumableRefresh();
	ThrowableRefresh();

	if (!InputComponent)
	{
		InitializeInputComponent();
	}

	if (!ensure(InputComponent))
	{
		return;
	}

	RegisterInputComponent();

	SetInputActionBlocking(false);
	SetInputActionPriority(1);

	InputComponent->BindAction("Inventory_UseItem", IE_Pressed, this, &UP3ConsumableDialog::OnUseItemPressed);
	InputComponent->BindAction("Inventory_UseItem", IE_Released, this, &UP3ConsumableDialog::OnUseItemReleased);

	InputComponent->BindAction("Inventory_Prev", IE_Pressed, this, &UP3ConsumableDialog::OnPrevPressed);
	InputComponent->BindAction("Inventory_Prev", IE_Released, this, &UP3ConsumableDialog::OnPrevReleased);

	InputComponent->BindAction("Inventory_Next", IE_Pressed, this, &UP3ConsumableDialog::OnNextPressed);
	InputComponent->BindAction("Inventory_Next", IE_Released, this, &UP3ConsumableDialog::OnNextReleased);

	InputComponent->BindAction("Weapon_Private_Action", IE_Pressed, this, &UP3ConsumableDialog::OnAimPressed).bConsumeInput = false;
	InputComponent->BindAction("Weapon_Private_Action", IE_Released, this, &UP3ConsumableDialog::OnAimReleased).bConsumeInput = false;

	InputComponent->BindAction("Weapon_Normal_Attack", IE_Pressed, this, &UP3ConsumableDialog::OnThrowPressed).bConsumeInput = false;
	InputComponent->BindAction("Weapon_Normal_Attack", IE_Released, this, &UP3ConsumableDialog::OnThrowReleased).bConsumeInput = false;

	//InputComponent->BindAction("Weapon_Special_Attack", IE_Pressed, this, &UP3ConsumableDialog::OnInteractPressed);
	//InputComponent->BindAction("Weapon_Special_Attack", IE_Released, this, &UP3ConsumableDialog::OnInteractReleased);
}

void UP3ConsumableDialog::OnClose()
{
	if (bInAimMode)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
		UP3CommandComponent* CommandComp = Character ? Character->GetCommandComponent() : nullptr;
		if (CommandComp)
		{
			FP3CommandRequestParams Params;
			Params.SetRangedAiming_bNewAiming = false;
			CommandComp->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), Params);
		}

		bInAimMode = false;
	}

	SetVisibility(ESlateVisibility::Collapsed);

	UnregisterInputComponent();
}

void UP3ConsumableDialog::OnNext()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();

	if (!ensure(InventoryComp))
	{
		return;
	}

	const TArray<FP3Item>& Throwables = InventoryComp->GetThrowableItems(false);

	if (Throwables.Num() == 0)
	{
		SelectedThrowableIndex = 0;
		return;
	}

	++SelectedThrowableIndex;

	if (SelectedThrowableIndex < 0)
	{
		ensure(0);
		SelectedThrowableIndex = 0;
		return;
	}

	if (SelectedThrowableIndex >= Throwables.Num())
	{
		SelectedThrowableIndex = 0;
	}

	if (ensure(ThrowableScrollAnim))
	{
		PlayAnimation(ThrowableScrollAnim);
	}

	ThrowableRefresh();

	OnThrowableChange();
}

void UP3ConsumableDialog::OnPrev()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());

	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();

	if (!ensure(InventoryComp))
	{
		return;
	}

	const TArray<FP3Item>& Consumables = InventoryComp->GetConsumableItems(false);

	if (Consumables.Num() == 0)
	{
		return;
	}

	--SelectedConsumableIndex;

	if (SelectedConsumableIndex < 0)
	{
		SelectedConsumableIndex = Consumables.Num() - 1;
	}

	if (SelectedConsumableIndex >= Consumables.Num())
	{
		ensure(0);
		SelectedConsumableIndex = 0;
		return;
	}

	if (ensure(ConsumableScrollAnim))
	{
		PlayAnimation(ConsumableScrollAnim);
	}

	ConsumableRefresh();
}

void UP3ConsumableDialog::OnUse()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return;
	}

	const TArray<FP3Item>& Items = InventoryComp->GetConsumableItems(false);
	if (!Items.IsValidIndex(SelectedConsumableIndex))
	{
		return;
	}

	const FP3CmsItem& CmsItem = P3Cms::GetItem(Items[SelectedConsumableIndex].Key);

	if (CmsItem.bIsIngredient)
	{
		OnHold();
		return;
	}

	const FP3CmsConsumable* CmsConsumable = P3Cms::GetItemConsumable(Items[SelectedConsumableIndex].Key);

	FP3PawnActionStartRequestParams Params;
	Params.UseConsumable_ItemId = Items[SelectedConsumableIndex].Id;
	Params.UseConsumable_bHoldItemOnConsume = CmsConsumable ? CmsConsumable->bHoldItemOnConsume : false;
	Params.UseConsumable_bDestoryHoldingItemOnUseNotify = CmsConsumable ? CmsConsumable->bDestroyHoldingItemOnUseNotify : false;

	ActionComp->StartAction(EPawnActionType::UseConsumable, _FUNCTION_TEXT, Params);
}

void UP3ConsumableDialog::OnThrow()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ActionComp)
	{
		return;
	}

	if (ActionComp->GetActiveActionId() != 0)
	{
		if (Character->GetActionComponent()->GetActiveActionType() != EPawnActionType::StartItemThrowAim)
		{
			return;
		}
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const TArray<FP3Item>& Throwables = InventoryComp->GetThrowableItems(false);
	if (!Throwables.IsValidIndex(SelectedThrowableIndex))
	{
		return;
	}

	UP3CommandComponent* CommandComp = Character->GetCommandComponent();
	if (!ensure(CommandComp))
	{
		return;
	}

	FP3CommandRequestParams CommandParams;
	CommandParams.ThrowItemFromInventory_ItemId = Throwables[SelectedThrowableIndex].Id;
	CommandComp->RequestCommand(UP3ThrowItemFromInventoryCommand::StaticClass(), CommandParams);

	FP3CommandRequestParams StopAimParams;
	StopAimParams.SetRangedAiming_bNewAiming = false;
	CommandComp->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), StopAimParams);
}

void UP3ConsumableDialog::OnHold()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return;
	}

	const TArray<FP3Item>& Consumables = InventoryComp->GetConsumableItems(false);
	if (!Consumables.IsValidIndex(SelectedConsumableIndex))
	{
		return;
	}

	FP3PawnActionStartRequestParams Params;
	Params.HoldItemFromInventory_ItemId = Consumables[SelectedConsumableIndex].Id;
	ActionComp->StartAction(EPawnActionType::HoldItemFromInventory, _FUNCTION_TEXT, Params);
}

void UP3ConsumableDialog::ConsumableRefresh()
{
	ConsumableItemBox->ClearChildren();

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const TArray<FP3Item>& Consumables = InventoryComp->GetConsumableItems(false);
	if (Consumables.Num() == 0)
	{
		SelectedConsumableIndex = 0;
		InfoGuideBar->SetVisibility(ESlateVisibility::Hidden);
		ItemNameBox->SetVisibility(ESlateVisibility::Hidden);
		return;
	}
	else
	{
		UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());

		if (UserSettings && UserSettings->GetShowKeyGuide())
		{
			InfoGuideBar->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
		ItemNameBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	if (!Consumables.IsValidIndex(SelectedConsumableIndex))
	{
		SelectedConsumableIndex = 0;
	}

	UP3ConsumableItem* SelectedItem = nullptr;

	int32 TopSideNum = 2;
	int32 StartIndex = (SelectedConsumableIndex + Consumables.Num() - TopSideNum) % Consumables.Num();
	int32 EndIndex = (StartIndex + 5) % Consumables.Num();

	int32 CurrentIndex = StartIndex;

	const static int32 CreateSlotNum = 6;
	int32 SlotCount = 0;
	while (SlotCount < CreateSlotNum && EndIndex >= 0 && StartIndex >= 0)
	{
		const FP3Item Consumable = Consumables[CurrentIndex];
		if (!ensure(Consumable.IsValid()))
		{
			continue;
		}

		UP3ConsumableItem* ItemWidget = CreateWidget<UP3ConsumableItem>(GetOwningPlayer(), ItemClass);
		if (!ensure(ItemWidget))
		{
			return;
		}

		ConsumableItemBox->AddChild(ItemWidget);

		bool bSelected = (CurrentIndex == SelectedConsumableIndex);
		ItemWidget->SetItem(Consumable, bSelected);

		if (bSelected)
		{
			SelectedItem = ItemWidget;

			const FP3CmsItem& CmsItem = P3Cms::GetItem(Consumable.Key);
			ItemNameText->SetText(CmsItem.DisplayName);
		}

		CurrentIndex = (CurrentIndex + Consumables.Num() + 1) % Consumables.Num();
		SlotCount++;
	}

	if (ensure(ConsumableItemScrollBox) && SelectedItem)
	{
		ConsumableItemScrollBox->SetScrollOffset(70);
	}

	if (ensure(InfoGuideAnim))
	{
		PlayAnimation(InfoGuideAnim);
	}
}

void UP3ConsumableDialog::ThrowableRefresh()
{
	ThrowableItemBox->ClearChildren();

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const TArray<FP3Item>& Throwables = InventoryComp->GetThrowableItems(false);
	if (Throwables.Num() == 0)
	{
		SelectedThrowableIndex = 0;
		InfoGuideBar->SetVisibility(ESlateVisibility::Hidden);
		ItemNameBox->SetVisibility(ESlateVisibility::Hidden);
		return;
	}
	else
	{
		UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());
		if (UserSettings && UserSettings->GetShowKeyGuide())
		{
			InfoGuideBar->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
		ItemNameBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	if (!Throwables.IsValidIndex(SelectedThrowableIndex))
	{
		SelectedThrowableIndex = 0;
	}

	UP3ConsumableItem* SelectedItem = nullptr;

	int32 BottomSideNum = 2;
	int32 StartIndex = (SelectedThrowableIndex + Throwables.Num() - BottomSideNum) % Throwables.Num();
	int32 EndIndex = (StartIndex + 5) % Throwables.Num();

	int32 CurrentIndex = StartIndex;

	const static int32 CreateSlotNum = 6;
	int32 SlotCount = 0;
	while (SlotCount < CreateSlotNum && EndIndex >= 0 && StartIndex >= 0)
	{
		const FP3Item Throwable = Throwables[CurrentIndex];
		if (!ensure(Throwable.IsValid()))
		{
			continue;
		}

		UP3ConsumableItem* ItemWidget = CreateWidget<UP3ConsumableItem>(GetOwningPlayer(), ItemClass);
		if (!ensure(ItemWidget))
		{
			return;
		}

		ThrowableItemBox->AddChild(ItemWidget);

		bool bSelected = (CurrentIndex == SelectedThrowableIndex);
		ItemWidget->SetItem(Throwable, bSelected);

		if (bSelected)
		{
			SelectedItem = ItemWidget;

			const FP3CmsItem& CmsItem = P3Cms::GetItem(Throwable.Key);
			ItemNameText->SetText(CmsItem.DisplayName);
		}

		CurrentIndex = (CurrentIndex + Throwables.Num() + 1) % Throwables.Num();
		SlotCount++;
	}

	if (ensure(ThrowableItemScrollBox) && SelectedItem)
	{
		ThrowableItemScrollBox->SetScrollOffset(70);
	}

	if (ensure(InfoGuideAnim))
	{
		PlayAnimation(InfoGuideAnim);
	}
}

void UP3ConsumableDialog::OnAimPressed()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	if (Character->IsLocallyControlled() && Character->LocalControl_IsMainMenuUIOpened())
	{
		return;
	}

	if (!Character->CanAiming())
	{
		return;
	}

	if (Character->GetStance() == EP3CharacterStance::Combat)
	{
		return;
	}

	if (Character->GetComboComponent() && !Character->GetComboComponent()->IsInProgressRootCombo())
	{
		return;
	}

	if (Character->GetActionComponent() && Character->GetActionComponent()->GetActiveActionId() != 0)
	{
		if (Character->GetActionComponent()->GetActiveActionType() != EPawnActionType::EndItemThrowAim)
		{
			return;
		}
	}

	UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
	if (!MovementComp || !MovementComp->IsWalking())
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	if (InventoryComp->GetBackpackWeight() == EP3BackpackWeight::Heavy)
	{
		return;
	}

	const TArray<FP3Item>& Throwables = InventoryComp->GetThrowableItems(false);
	if (!Throwables.IsValidIndex(SelectedThrowableIndex))
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ActionComp)
	{
		return;
	}

	FP3PawnActionStartRequestParams Params;
	Params.StartThrowItemAim_ThrowAimingItemId = Throwables[SelectedThrowableIndex].Id;

	ActionComp->StartAction(EPawnActionType::StartItemThrowAim, _FUNCTION_TEXT, Params);

	bInAimMode = true;

	if (InputComponent)
	{
		for (int32 BindingIndex = 0; BindingIndex < InputComponent->GetNumActionBindings(); ++BindingIndex)
		{
			FInputActionBinding& ActionBinding = InputComponent->GetActionBinding(BindingIndex);

			if (ActionBinding.GetActionName() == FName(TEXT("Weapon_Normal_Attack")))
			{
				ActionBinding.bConsumeInput = true;
			}
		}
	}
}

void UP3ConsumableDialog::OnAimReleased()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	if (Character->IsLocallyControlled() && Character->LocalControl_IsMainMenuUIOpened())
	{
		return;
	}

	if (Character->GetComboComponent() && !Character->GetComboComponent()->IsInProgressRootCombo())
	{
		return;
	}

	if (Character->GetCharacterStoreBP().bIsAiming)
	{
		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		if (!ActionComp)
		{
			return;
		}

		ActionComp->StartAction(EPawnActionType::EndItemThrowAim, _FUNCTION_TEXT, FP3PawnActionStartRequestParams());

		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		if (!CommandComp)
		{
			return;
		}

		FP3CommandRequestParams CommandParams;
		CommandParams.SetRangedAiming_bNewAiming = false;

		CommandComp->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), CommandParams);
	}

	bInAimMode = false;

	if (InputComponent)
	{
		for (int32 BindingIndex = 0; BindingIndex < InputComponent->GetNumActionBindings(); ++BindingIndex)
		{
			FInputActionBinding& ActionBinding = InputComponent->GetActionBinding(BindingIndex);

			if (ActionBinding.GetActionName() == FName(TEXT("Weapon_Normal_Attack")))
			{
				ActionBinding.bConsumeInput = false;
			}
		}
	}
}

void UP3ConsumableDialog::OnThrowPressed()
{

}

void UP3ConsumableDialog::OnThrowReleased()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	if (!bInAimMode)
	{
		return;
	}

	if (Character->GetCharacterStoreBP().bIsAiming)
	{
		OnThrow();
	}
}

void UP3ConsumableDialog::OnInteractPressed()
{

}

void UP3ConsumableDialog::OnInteractReleased()
{
	OnHold();
}

void UP3ConsumableDialog::OnUseItemPressed()
{

}

void UP3ConsumableDialog::OnUseItemReleased()
{
	OnUse();
}

void UP3ConsumableDialog::OnPrevPressed()
{

}

void UP3ConsumableDialog::OnPrevReleased()
{
	OnPrev();
}

void UP3ConsumableDialog::OnNextPressed()
{

}

void UP3ConsumableDialog::OnNextReleased()
{
	OnNext();
}

void UP3ConsumableDialog::OnThrowableChange()
{
	if (!bInAimMode)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3CommandComponent* CommandComp = Character->GetCommandComponent();
	if (!CommandComp)
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const TArray<FP3Item>& Throwables = InventoryComp->GetThrowableItems();
	if (!Throwables.IsValidIndex(SelectedThrowableIndex))
	{
		return;
	}

	if (Throwables[SelectedThrowableIndex].Id != INVALID_ITEMID)
	{
		FP3CommandRequestParams Params;
		Params.SetChangingThrowable_bNewChangingThrowable = true;
		CommandComp->RequestCommand(UP3SetChangingThrowableCommand::StaticClass(), Params);

		FP3CharacterStore CharacterStore = Character->GetCharacterStoreBP();
		CharacterStore.ThrowAimingItemId = Throwables[SelectedThrowableIndex].Id;

		Character->SetCharacterStore(CharacterStore);

		ChangingThrowableMaintainTimeAgeSeconds = 0.0f;
	}
}
