// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3DamageMetersWidget.generated.h"

UCLASS(Blueprintable)
class P3_API UP3DamageMetersWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void Reset();
	void SetDamageMetersComponent(class UP3DamageMetersComponent* InDamageMetersComponent);

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

private:
	UPROPERTY(meta = (BindWidget))
	class UVerticalBox* MetersBox = nullptr;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UP3DamageMeterWidget> MeterClass;

	TWeakObjectPtr<class UP3DamageMetersComponent> DamageMetersComponent;
	int32 Version = 0;
};
