// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3ChatWidget.generated.h"

UCLASS(Blueprintable)
class P3_API UP3ChatWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void Reset();

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	UFUNCTION(BlueprintCallable)
	void SetFadeOutAnim(UWidgetAnimation* InFadeOutAnim) { FadeOutAnim = InFadeOutAnim; }

private:
	UFUNCTION()
	void OnOpenChat();

	UFUNCTION()
	void OnRecvChat(const FString& UserName, uint32 ZoneChannelId, const FString& Msg);

	UFUNCTION()
	void OnInputTextChanged(const FText& Text);

	UFUNCTION()
	void OnInputTextCommitted(const FText& Text, ETextCommit::Type CommitMethod);

	UFUNCTION()
	void OnPinClicked();

	UFUNCTION()
	void OnUnpinClicked();

	UPROPERTY(meta = (BindWidget))
	class UEditableText* InputEdit = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UTextBlock* ContentText = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UScrollBox* ContentScrollBox = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* PinButton = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UButton* UnpinButton = nullptr;

	UPROPERTY()
	UWidgetAnimation* FadeOutAnim = nullptr;

	UPROPERTY()
	class UP3ChatNet* ChatNet = nullptr;

	TArray<FString> Lines;
	bool bIsInputModeUIOnly = true;
	bool bIsActive = true;
	bool bPinned = true;
	float IdleAgeSeconds = 0.0f;

	FDelegateHandle OnChatDelegate;
};
