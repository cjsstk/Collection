// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "P3MainMenuWidget.h"
#include "P3InventoryWidget.generated.h"

UCLASS(Blueprintable)
class P3_API UP3InventoryWidget : public UP3MenuWidget
{
	GENERATED_BODY()

public:
	void InitInventory();
	void Refresh();

	class UP3InventoryQuickSlotWidget* GetThrowableQuickSlot() const { return ThrowableQuickSlot; }
	class UP3InventoryQuickSlotWidget* GetConsumableQuickSlot() const { return ConsumableQuickSlot; }

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	virtual void OnFocus() override;
	virtual void OnBlur() override;

private:
	virtual void OnUp() override;
	virtual void OnDown() override;
	virtual void OnLeft() override;
	virtual void OnRight() override;
	virtual void OnSelectItem() override;

	UFUNCTION()
	void OnLeftClicked(int32 InSlotIndex);

	UFUNCTION()
	void OnRightClicked(int32 InSlotIndex);

	UPROPERTY(meta = (BindWidget))
	class UUniformGridPanel* InventoryItemSlotPanel = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3InventoryItemDetailWidget* InventoryItemDetailWidget = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3InventoryQuickSlotWidget* ThrowableQuickSlot = nullptr;

	UPROPERTY(meta = (BindWidget))
	class UP3InventoryQuickSlotWidget* ConsumableQuickSlot = nullptr;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UP3InventoryContextMenuWidget> ContextMenuClass;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	TSubclassOf<class UP3InventorySlotWidget> SlotClass;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 RowCount = 10;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 ColumnCount = 5;

	UPROPERTY(Transient)
	TArray<class UP3InventorySlotWidget*> InventorySlots;

	UPROPERTY(Transient)
	UP3InventoryContextMenuWidget* ContextMenu;

	int32 CurrentInventorySlotIndex = -1;
};
