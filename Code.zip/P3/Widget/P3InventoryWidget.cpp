// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3InventoryWidget.h"

#include "Components/TextBlock.h"
#include "Components/UniformGridPanel.h"
#include "Components/UniformGridSlot.h"
#include "Components/CanvasPanelSlot.h"

#include "P3Character.h"
#include "P3Input.h"
#include "P3InventoryContextMenuWidget.h"
#include "P3InventoryComponent.h"
#include "P3InventoryQuickSlotWidget.h"
#include "P3InventorySlotWidget.h"
#include "P3PlayerController.h"

void UP3InventoryWidget::InitInventory()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	if (!InventoryItemSlotPanel)
	{
		return;
	}

	InventoryItemSlotPanel->ClearChildren();
	InventorySlots.Empty();

	const TArray<FP3Item>& InventoryItems = InventoryComp->GetItemsBySlot(EP3CharacterItemSlot::Inventory);

	for (int32 Row = 0; Row < RowCount; ++Row)
	{
		for (int32 Coloumn = 0; Coloumn < ColumnCount; ++Coloumn)
		{
			UP3InventorySlotWidget* SlotWidget = CreateWidget<UP3InventorySlotWidget>(GetOwningPlayer(), SlotClass);
			if (!SlotWidget)
			{
				continue;
			}

			UUniformGridSlot* UniformGridSlot = InventoryItemSlotPanel->AddChildToUniformGrid(SlotWidget);
			if (ensure(UniformGridSlot))
			{
				UniformGridSlot->SetRow(Row);
				UniformGridSlot->SetColumn(Coloumn);
			}

			const int32 SlotIndex = Row * ColumnCount + Coloumn;
			FP3Item InventoryItem = FP3Item::InvalidItem;

			if (InventoryItems.IsValidIndex(SlotIndex))
			{
				InventoryItem = InventoryItems[SlotIndex];
			}

			SlotWidget->InitSlot(InventoryItem);
			SlotWidget->SetSlotIndex(SlotIndex);
			SlotWidget->OnSlotLeftClicked.AddUniqueDynamic(this, &UP3InventoryWidget::OnLeftClicked);
			SlotWidget->OnSlotRightClicked.AddUniqueDynamic(this, &UP3InventoryWidget::OnRightClicked);
			InventorySlots.Add(SlotWidget);
		}
	}

	ContextMenu = CreateWidget<UP3InventoryContextMenuWidget>(GetOwningPlayer(), ContextMenuClass);
	if (ContextMenu)
	{
		ContextMenu->AddToViewport(2);
		ContextMenu->SetVisibility(ESlateVisibility::Collapsed);
		ContextMenu->SetPrevFocusWidget(this);
	}

	if (ThrowableQuickSlot)
	{
		ThrowableQuickSlot->SetPrevFocusWidget(this);
	}
	if (ConsumableQuickSlot)
	{
		ConsumableQuickSlot->SetPrevFocusWidget(this);
	}

	Refresh();
}

void UP3InventoryWidget::Refresh()
{
	AP3Character* Character = Cast<AP3Character>(GetOwningPlayerPawn());
	if (!Character)
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const TArray<FP3Item>& InventoryItems = InventoryComp->GetItemsBySlot(EP3CharacterItemSlot::Inventory);

	for (int32 Index = 0; Index < InventorySlots.Num(); ++Index)
	{
		UP3InventorySlotWidget* InventorySlot = InventorySlots[Index];
		if (!ensure(InventorySlot))
		{
			continue;
		}

		FP3Item InventoryItem = FP3Item::InvalidItem;

		if (InventoryItems.IsValidIndex(Index))
		{
			InventoryItem = InventoryItems[Index];
		}

		InventorySlot->Refresh(InventoryItem, (CurrentInventorySlotIndex == Index));
	}

	if (InventoryItemDetailWidget)
	{
		FP3Item InventoryItem = FP3Item::InvalidItem;

		if (InventoryItems.IsValidIndex(CurrentInventorySlotIndex))
		{
			InventoryItem = InventoryItems[CurrentInventorySlotIndex];
		}

		InventoryItemDetailWidget->Refresh(InventoryItem);
	}
}

void UP3InventoryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	InitInventory();
	ThrowableQuickSlot->Refresh();
	ConsumableQuickSlot->Refresh();
}

void UP3InventoryWidget::NativeDestruct()
{
	Super::NativeDestruct();

	Close();

	if (ContextMenu)
	{
		ContextMenu->RemoveFromParent();
	}
}

void UP3InventoryWidget::OnFocus()
{
	Super::OnFocus();

	if (ContextMenu && !ContextMenu->IsVisible())
	{
		CurrentInventorySlotIndex = 0;
	}

	LocalControl_MoveUpMenuRemainSeconds = LocalControl_MoveMenuCoolDown;
	Refresh();
}

void UP3InventoryWidget::OnBlur()
{
	if (ContextMenu && !ContextMenu->IsVisible())
	{
		CurrentInventorySlotIndex = -1;
	}

	Refresh();
}

void UP3InventoryWidget::OnUp()
{
	if (CurrentInventorySlotIndex >= ColumnCount)
	{
		CurrentInventorySlotIndex -= ColumnCount;
		Refresh();
	}
	else
	{
		if (ensure(PrevFocusWidget))
		{
			PrevFocusWidget->Open();
		}
	}
}

void UP3InventoryWidget::OnDown()
{
	if (CurrentInventorySlotIndex + ColumnCount < InventorySlots.Num())
	{
		CurrentInventorySlotIndex += ColumnCount;
		Refresh();
	}
}

void UP3InventoryWidget::OnLeft()
{
	CurrentInventorySlotIndex = (CurrentInventorySlotIndex - 1 + InventorySlots.Num()) % InventorySlots.Num();

	Refresh();
}

void UP3InventoryWidget::OnRight()
{
	CurrentInventorySlotIndex = (CurrentInventorySlotIndex + 1) % InventorySlots.Num();

	Refresh();
}

void UP3InventoryWidget::OnLeftClicked(int32 InSlotIndex)
{
	Open();

	if (InventorySlots.IsValidIndex(InSlotIndex))
	{
		CurrentInventorySlotIndex = InSlotIndex;
	}

	Refresh();
}

void UP3InventoryWidget::OnRightClicked(int32 InSlotIndex)
{
	OnLeftClicked(InSlotIndex);
	OnSelectItem();
}

void UP3InventoryWidget::OnSelectItem()
{
	// Disable Context Menu
	return;

	if (!InventorySlots.IsValidIndex(CurrentInventorySlotIndex))
	{
		ensure(0);
		return;
	}

	UP3InventorySlotWidget* SlotWidget = InventorySlots[CurrentInventorySlotIndex];
	if (!SlotWidget)
	{
		return;
	}

	if (!ContextMenu)
	{
		return;
	}

	const FP3Item& SlotItem = SlotWidget->GetSlotItem();

	FVector2D MenuWidgetPos = SlotWidget->GetCachedGeometry().LocalToAbsolute(FVector2D(0, 0));

	int32 ViewportX = 0;
	int32 ViewportY = 0;
	GetOwningPlayer()->GetViewportSize(ViewportX, ViewportY);

	MenuWidgetPos.X = MenuWidgetPos.X * ((float)ViewportX / 1920);
	MenuWidgetPos.Y = MenuWidgetPos.Y * ((float)ViewportY / 1080);

	ContextMenu->SetCurrentSelectedItem(SlotItem);
	ContextMenu->SetPositionInViewport(MenuWidgetPos);
	ContextMenu->Open();
}
