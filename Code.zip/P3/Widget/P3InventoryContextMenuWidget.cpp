// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3InventoryContextMenuWidget.h"

#include "Components/TextBlock.h"
#include "Components/VerticalBox.h"

#include "P3Character.h"
#include "P3Input.h"
#include "P3InventoryQuickSlotWidget.h"
#include "P3InventoryWidget.h"
#include "P3Log.h"

void UP3InventoryContextMenuWidget::Init()
{
	if (!MenuBox)
	{
		return;
	}

	for (UWidget* ChildWidget : MenuBox->GetAllChildren())
	{
		UP3ContextMenuSlot* MenuSlot = Cast<UP3ContextMenuSlot>(ChildWidget);
		if (MenuSlot)
		{
			MenuSlot->OnSlotClicked.AddUniqueDynamic(this, &UP3InventoryContextMenuWidget::OnClicked);
			ContextMenuSlots.Add(MenuSlot);
		}
	}

	Refresh();
}

void UP3InventoryContextMenuWidget::Refresh()
{
	for (int32 Index = 0; Index < ContextMenuSlots.Num(); ++Index)
	{
		bool bActive = true;

		switch ((EP3InventoryContextType)Index)
		{
		case EP3InventoryContextType::RegisterThrowable:
			bActive = IsCurrentItemThrowable();
			break;
		case EP3InventoryContextType::RegisterConsumable:
			bActive = IsCurrentItemConsumable();
			break;
		default:
			break;
		}

		UP3ContextMenuSlot* ContextMenu = ContextMenuSlots[Index];
		if (ensure(ContextMenu))
		{
			ContextMenu->Refresh(Index == CurrentContextMenuIndex, bActive);
		}
	}
}

void UP3InventoryContextMenuWidget::SetCurrentSelectedItem(const FP3Item& InItem)
{
	if (!InItem.IsValid())
	{
		ensure(0);
		return;
	}

	CurrentSelectedItem = InItem;
}

void UP3InventoryContextMenuWidget::HideOnBlur(bool bNewHideOnBlur)
{
	bHideOnBlur = bNewHideOnBlur;
}

void UP3InventoryContextMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();

	Init();
}

void UP3InventoryContextMenuWidget::NativeDestruct()
{
	Super::NativeDestruct();

	Close();
}

void UP3InventoryContextMenuWidget::OnFocus()
{
	Super::OnFocus();

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	CurrentContextMenuIndex = 0;

	Refresh();
}

void UP3InventoryContextMenuWidget::OnBlur()
{
	Super::OnBlur();

	if (bHideOnBlur)
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UP3InventoryContextMenuWidget::OnUp()
{
	--CurrentContextMenuIndex;

	if (CurrentContextMenuIndex < 0)
	{
		CurrentContextMenuIndex = ContextMenuSlots.Num() - 1;
	}

	Refresh();
}

void UP3InventoryContextMenuWidget::OnDown()
{
	++CurrentContextMenuIndex;
	if (CurrentContextMenuIndex >= ContextMenuSlots.Num())
	{
		CurrentContextMenuIndex = 0;
	}

	Refresh();
}

bool UP3InventoryContextMenuWidget::IsCurrentItemThrowable() const
{
	const FP3CmsThrowable* Throwable = P3Cms::GetItemThrowable(CurrentSelectedItem.Key);
	if (Throwable)
	{
		return true;
	}

	return false;
}

bool UP3InventoryContextMenuWidget::IsCurrentItemConsumable() const
{
	const FP3CmsConsumable* Consumable = P3Cms::GetItemConsumable(CurrentSelectedItem.Key);
	if (Consumable)
	{
		return true;
	}

	return false;
}

void UP3InventoryContextMenuWidget::OnSelectItem()
{
	EP3InventoryContextType CurrentContextType = (EP3InventoryContextType)CurrentContextMenuIndex;

	switch (CurrentContextType)
	{
	case EP3InventoryContextType::UseItem:
		break;
	case EP3InventoryContextType::RegisterThrowable:
	{
		if (!IsCurrentItemThrowable())
		{
			break;
		}

		UP3InventoryWidget* InvenWidget = Cast<UP3InventoryWidget>(PrevFocusWidget);
		if (!InvenWidget)
		{
			break;
		}

		UP3InventoryQuickSlotWidget* ThrowableQuickSlot = InvenWidget->GetThrowableQuickSlot();
		if (!ensure(ThrowableQuickSlot))
		{
			break;
		}

		HideOnBlur(false);
		ThrowableQuickSlot->SetCurrentSelectedItem(CurrentSelectedItem);
		ThrowableQuickSlot->Open();
		HideOnBlur(true);

		break;
	}
	case EP3InventoryContextType::RegisterConsumable:
	{
		if (!IsCurrentItemConsumable())
		{
			break;
		}

		UP3InventoryWidget* InvenWidget = Cast<UP3InventoryWidget>(PrevFocusWidget);
		if (!InvenWidget)
		{
			break;
		}

		UP3InventoryQuickSlotWidget* ConsumableQuickSlot = InvenWidget->GetConsumableQuickSlot();
		if (!ensure(ConsumableQuickSlot))
		{
			break;
		}

		HideOnBlur(false);
		ConsumableQuickSlot->SetCurrentSelectedItem(CurrentSelectedItem);
		ConsumableQuickSlot->Open();
		HideOnBlur(true);

		break;
	}
	case EP3InventoryContextType::Cancel:
		PrevFocusWidget->Open();
		break;
	default:
		break;
	}
}

void UP3InventoryContextMenuWidget::OnClicked(EP3InventoryContextType InContextType)
{
	if (InContextType == EP3InventoryContextType::Count)
	{
		ensure(0);
		return;
	}

	CurrentContextMenuIndex = (int32)InContextType;

	Refresh();

	OnSelectItem();
}

void UP3ContextMenuSlot::Refresh(bool bSelected, bool bActive)
{
	bSlotActive = bActive;

	if (DeactiveImage)
	{
		DeactiveImage->SetVisibility(!bActive ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}

	if (SelectedImage)
	{
		SelectedImage->SetVisibility(bSelected ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void UP3ContextMenuSlot::SetContextName(const FText& InName)
{
	if (ContextName)
	{
		ContextName->SetText(InName);
	}
}

void UP3ContextMenuSlot::NativeConstruct()
{
	Super::NativeConstruct();

	if (!ContextNameText.IsEmpty())
	{
		SetContextName(ContextNameText);
	}
	else
	{
		SetContextName(FText::FromString(EnumToString(EP3InventoryContextType, ContextType)));
	}
}

FReply UP3ContextMenuSlot::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	if (bSlotActive && InMouseEvent.GetPressedButtons().Contains(EKeys::LeftMouseButton))
	{
		OnSlotClicked.Broadcast(ContextType);
	}

	return Super::NativeOnMouseButtonDown(InGeometry, InMouseEvent);
}
