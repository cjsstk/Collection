// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3BossTimerWidget.h"

#include "EngineUtils.h"

#include "Combat/P3BossChallenge.h"


void UP3BossTimerWidget::NativeConstruct()
{
	Super::NativeConstruct();

	for (TActorIterator<AP3BossChallengeActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AP3BossChallengeActor* Actor = *Iter;
		if (Actor)
		{
			Actor->Client_ResetUI();
			return;
		}
	}
}

void UP3BossTimerWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (LeftTimeSeconds < 0.0f)
	{
		return;
	}

	LeftTimeSeconds -= InDeltaTime;
}

void UP3BossTimerWidget::StartTimer(float InTimeLimitSeconds, float InLeftTimeSeconds)
{
	if (!ensure(InTimeLimitSeconds > 0.0f))
	{
		return;
	}

	TimeLimitSeconds = InTimeLimitSeconds;
	LeftTimeSeconds = InLeftTimeSeconds;
}

void UP3BossTimerWidget::ResetTimer()
{
	LeftTimeSeconds = -1.0f;
}

FText UP3BossTimerWidget::GetLeftTimeMinutes() const
{
	return FText::AsNumber(StaticCast<int32>(LeftTimeSeconds / 60.0f));
}

float UP3BossTimerWidget::GetLeftTimeRatio() const
{
	return LeftTimeSeconds / TimeLimitSeconds;
}
