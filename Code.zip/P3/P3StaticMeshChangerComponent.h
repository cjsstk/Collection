// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "EngineMinimal.h"
#include "P3StoreInterface.h"
#include "Components/SceneComponent.h"
#include "P3StaticMeshChangerComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3StaticMeshChangerComponent : public USceneComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3StaticMeshChangerComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION()
	void Server_OnActorOverlapped(AActor* Actor);

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

protected:
	virtual void BeginPlay() override;

private:
	void ChangeStaticMesh();

	UPROPERTY(EditDefaultsOnly)
	UStaticMesh* NewStaticMesh;

	/** Change particle (Start on Change) */
	UPROPERTY(EditDefaultsOnly)
	class UParticleSystem* ChangeParticle;

	bool Net_bChanged = false;
		
};
