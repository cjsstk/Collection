// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3Command.h"
#include "Network/Lib/P3NetCore.h"
#include "P3CommandComponent.generated.h"

USTRUCT()
struct FP3NetCommandParams
{
	GENERATED_BODY()

	UPROPERTY()
	FString CommandClassName;

	UPROPERTY()
	FP3CommandRequestParams RequestParams;
};

UCLASS()
class P3_API UP3CommandComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3CommandComponent();
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void RequestCommand(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params);

private:
	UFUNCTION()
	void Server_HandleRequestCommand(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Client_HandleExecuteCommand(const FP3DediToClientHandlerParams& Params);

	void Server_HandleRequestCommandInternal(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params);
	bool Server_ExecuteCommand(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params);
	void MulticastExecuteCommand(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params);
};
