// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineTypes.h"
#include "UObject/NoExportTypes.h"

#include "Item/P3Item.h"
#include "P3Core.h"
#include "P3CharacterStance.h"
#include "P3HealthChangeReason.h"
#include "P3HoldType.h"
#include "P3Command.generated.h"

/**
 * Command Type
 */
UENUM()
enum class EP3CommandType
{
	ApplyDamage
};

/**
 * Command Params
 */
USTRUCT()
struct FP3CommandRequestParams
{
	GENERATED_BODY()

	/**
	 * Apply Damage
	 */
	UPROPERTY()
	FP3ActorPointerAndId ApplyDamage_SourceActor;

	UPROPERTY()
	EAnimNotifyAttackStrengthFlags ApplyDamage_AttackStrength = EAnimNotifyAttackStrengthFlags::Ignore;

	UPROPERTY()
	int32 ApplyDamage_DamageAmount = 0;

	UPROPERTY()
	bool ApplyDamage_bIsCriticalPart = false;

	UPROPERTY()
	bool ApplyDamage_bIsArmorPart = false;

	UPROPERTY()
	FVector ApplyDamage_WorldImpactDirection = FVector::ZeroVector;

	UPROPERTY()
	FVector ApplyDamage_HitLocation = FVector::ZeroVector;

	UPROPERTY()
	bool ApplyDamage_bHoldFrame = false;

	UPROPERTY()
	int32 ApplyDamage_PartIndex = -1;

	UPROPERTY()
	FName ApplyDamage_PartName = NAME_None;

	UPROPERTY()
	bool ApplyDamage_bRagdollizeIfDead = false;

	/**
	 * Debug information
	 */
	UPROPERTY()
	EP3WeaponType ApplyDamage_WeaponType = EP3WeaponType::None;

	/**
	 * Debug information
	 */
	UPROPERTY()
	EP3HealthChangeReason ApplyDamage_Reason = EP3HealthChangeReason::Unknown;

	/**
	 * Heal
	 */
	UPROPERTY()
	int32 Heal_Amount = 0;

	// If set true, heal to max health point ( ignore Heal_Amount )
	UPROPERTY()
	bool Heal_bToMaxPoint = 0;

	/**
	 * Change Stance
	 */
	UPROPERTY()
	EP3CharacterStance ChangeStance_NewStance = EP3CharacterStance::Idle;

	/**
	 * Set Blocking
	 */
	UPROPERTY()
	bool SetBlocking_bNewBlocking = false;

	/**
	 * Set CrouchBlocking
	 */
	UPROPERTY()
	bool SetCrouchBlocking_bNewBlocking = false;

	/**
	 * Set BouncingMode
	 */
	UPROPERTY()
	bool SetBouncing_bNewBouncingMode = false;

	/**
	 * Set Pushing
	 */
	UPROPERTY()
	bool SetPushing_bNewPushing = false;

	UPROPERTY()
	FP3ActorPointerAndId SetPushing_PushingTargetActor;


	/**
	 * Set KnockDowned
	 */
	UPROPERTY()
	bool SetKnockDowned_bNewKnowDowned = false;

	UPROPERTY()
	float SetKnockDowned_DurationSeconds = 0.0f;

	/**
	 * Set God Mode
	 */
	UPROPERTY()
	bool SetGodMode_bNewGodMode = false;

	UPROPERTY()
	bool SetGodMode_bNewNoTargetMode = false;

	/**
	 * Set Melee Aiming
	 */
	UPROPERTY()
	bool SetMeleeAiming_bNewAiming = false;

	/**
	 * Set Ranged Aiming
	 */
	UPROPERTY()
	bool SetRangedAiming_bNewAiming = false;

	/** SetRangedAiming_bNewAiming must be true */
	UPROPERTY()
	bool SetRangedAiming_bChangeToCombatStance = true;	
	
	/** [Optional] Used for throwing item from inventory. SetRangedAiming_bNewAiming must be true */
	UPROPERTY()
	FP3ItemId SetRangedAiming_ThrowAimingItemId = INVALID_ITEMID;

	/**
	 * Revive
	 */
	UPROPERTY()
	int32 Revive_NewHealthPoint = 1;

	/**
	 * Teleport
	 */
	UPROPERTY()
	FVector Teleport_Location = FVector::ZeroVector;

	UPROPERTY()
	FRotator Teleport_Rotation = FRotator::ZeroRotator;

	/**
	 * Aim item from inventory
	 */
	UPROPERTY()
	FP3ItemId AimItemFromInventory_ItemId = INVALID_ITEMID;

	/**
	 * Throw item from inventory
	 */
	UPROPERTY()
	FP3ItemId ThrowItemFromInventory_ItemId = INVALID_ITEMID;

	UPROPERTY()
	FName PickUpItemFromInventory_AttachSocketName;

	/**
	 * Throw item from inventory (Step 2)
	 */
	UPROPERTY()
	FP3ItemId ThrowItemFromInventoryStep2_ItemId = INVALID_ITEMID;

	UPROPERTY()
	AActor* ThrowItemFromInventoryStep2_ItemActor = nullptr;

	/**
	 * Hold item
	 */
	UPROPERTY()
	AActor* HoldItem_ItemActor = nullptr;

	/**
	 * Ragdollize
	 */
	UPROPERTY()
	bool Ragdollize_bRagdoll = false;

	/**
	 * AttachPart
	 */
	UPROPERTY()
	int32 PartType = 0;

	UPROPERTY()
	int32 SlotIndex = 0;

	UPROPERTY()
	bool SetPart_bStart = false;

	UPROPERTY()
	bool SetPart_bInterrupt = false;

	UPROPERTY()
	bool SetPart_bAdd = false;

	/**
	 * Stumble
	 */
	UPROPERTY()
	bool SetStumbling_bIsStumbling = false;

	/**
	 * Mount
	 */
	UPROPERTY()
	bool Mount_Detach = false;

	UPROPERTY()
	bool Mount_DeatchWithEjection = false;

	UPROPERTY()
	class AP3Character* Mount_TargetCharacter = nullptr;

	UPROPERTY()
	int32 Mount_TargetMountPointIndex = -1;

	UPROPERTY()
	bool Mount_bRescuing = false;

	/**
	 * Bucking
	 */
	UPROPERTY()
	bool Bucking_bInBucking = false;

	/**
	 * Bucking Endure
	 */
	UPROPERTY()
	bool BuckingEndure_bNewEndure = false;

	/**
	 * LaunchProjectile
	 */
	UPROPERTY()
	FVector LaunchProjectile_Location = FVector::ZeroVector;

	UPROPERTY()
	FRotator LaunchProjectile_Rotation = FRotator::ZeroRotator;
	
	UPROPERTY()
	float LaunchProjectile_ConsumeStamina = 0.f;

	UPROPERTY()
	TSubclassOf<class AP3Projectile> LaunchProjectile_Class = nullptr;

	/**
	 * Drop Holdable
	 */
	UPROPERTY()
	EP3HoldType DropHoldable_HoldType = EP3HoldType::LeftHand;

	UPROPERTY()
	float DropHoldable_DropImpulseSize = 0.0f;

	UPROPERTY()
	FVector DropHoldable_DropDirection = FVector::ZeroVector;

	/**
	 * Change Holdable
	 */
	UPROPERTY()
	EP3HoldType ChangeHoldable_RightHoldType = EP3HoldType::Count;

	UPROPERTY()
	EP3HoldType ChangeHoldable_LeftHoldType = EP3HoldType::Count;

	UPROPERTY()
	FP3ItemId ChangeHoldable_InvenToRightHolderItemId;

	UPROPERTY()
	FP3ActorPointerAndId ChangeHoldable_InvenToRightHolderItemActor;

	UPROPERTY()
	FP3ItemId ChangeHoldable_InvenToLeftHolderItemId;

	UPROPERTY()
	FP3ActorPointerAndId ChangeHoldable_InvenToLeftHolderItemActor;

	UPROPERTY()
	FP3Item ChangeHoldable_HolderToRightInvenItem = FP3Item::InvalidItem;

	UPROPERTY()
	FP3Item ChangeHoldable_HolderToLeftInvenItem = FP3Item::InvalidItem;

	UPROPERTY()
	bool ChangeHoldable_bRemovePrevItemAfterChange = false;

	/**
	 * Revert after using temporary weapon
	 */
	UPROPERTY()
	FP3ItemId RecoveryAfterTempWeapon_HoldingItemId = INVALID_ITEMID;

	UPROPERTY()
	AActor* RecoveryAfterTempWeapon_HoldingItemActor = nullptr;

	UPROPERTY()
	FP3ItemId RecoveryAfterTempWeapon_RightItemId = INVALID_ITEMID;

	UPROPERTY()
	AActor* RecoveryAfterTempWeapon_RightItemActor = nullptr;

	UPROPERTY()
	FP3ItemId RecoveryAfterTempWeapon_LeftItemId = INVALID_ITEMID;

	UPROPERTY()
	AActor* RecoveryAfterTempWeapon_LeftItemActor = nullptr;

	/**
	 * Change the material value
	 */
	UPROPERTY()
	FName ParameterName = NAME_None;

	UPROPERTY()
	float ParameterFloat = 0.f;

	/**
	 * Look at target location
	 */
	UPROPERTY()
	FVector LookAtTargetLocation = FVector::ZeroVector;

	/**
	 * Talk
	 */
	UPROPERTY()
	AActor* TalkTargetActor = nullptr;

	/**
	 * CableAttachEnd
	 */
	UPROPERTY()
	AActor* CableWeaponActor = nullptr;

	/**
	 * Set Crippled
	 */
	UPROPERTY()
	bool SetCrippled_bCrippled = false;

	/**
	 * Camera Shake
	 */
	UPROPERTY()
	FName CmsCameraShakeKey = NAME_Name;

	UPROPERTY()
	FVector CameraShakeLocation = FVector::ZeroVector;

	UPROPERTY()
	AActor* CameraShakeActor = nullptr;

	/**
	 * Play Reaction VFX
	 */
	UPROPERTY()
	FName ReactionName = NAME_Name;

	UPROPERTY()
	FVector ReactionHitLocation = FVector::ZeroVector;

	UPROPERTY()
	FVector ReactionImpactDirection = FVector::ZeroVector;

	UPROPERTY()
	EP3ReactionLayer ReactionLayer = EP3ReactionLayer::Default;

	UPROPERTY()
	EP3AnimNotifyAttackAttribute AttackAttribute = EP3AnimNotifyAttackAttribute::Slash;

	/**
	 * Set Changing Throwable
	 */
	UPROPERTY()
	bool SetChangingThrowable_bNewChangingThrowable = false;

	/**
	 * Set Stroll
	 */
	UPROPERTY()
	bool SetStroll_bStroll = false;

	/**
	 * Set Emote By Name
	 */
	UPROPERTY()
	FName SetEmoteByName_EmoteAnimName = NAME_None;

	/**
	 * Set In Emote
	 */
	UPROPERTY()
	bool SetInEmote_bInEmote = false;

	/**
	 * Pickup Backpack
	 */
	UPROPERTY()
	AActor* PickupBackpack_BackpackActor = nullptr;

	UPROPERTY()
	FName PickupBackpack_AttachSocketName = NAME_Name;

	/**
	 * Putdown Backpack
	 */
	UPROPERTY()
	AActor* PutdownBackpack_BackpackActor = nullptr;

	/**
	 * Play CombatResponseHit
	 */
	UPROPERTY()
	AActor* PlayCombatResponseHit_AttackerActor = nullptr;

	UPROPERTY()
	int64 PlayCombatResponseHit_AttackerActorID = -1;

	UPROPERTY()
	FName PlayCombatResponseHit_ReactionName = NAME_None;

	UPROPERTY()
	EP3ReactionLayer PlayCombatResponseHit_Layer = EP3ReactionLayer::None;

	UPROPERTY()
	FTransform PlayCombatResponseHit_TargetTransform = FTransform::Identity;

	UPROPERTY()
	FVector PlayCombatResponseHit_HitLocation = FVector::ZeroVector;

	UPROPERTY()
	FName PlayCombatResponseHit_HitBoneName = NAME_None;

	UPROPERTY()
	bool PlayCombatResponseHit_bIsFrameHold = false;
};

/**
 * Command base class
 */
UCLASS()
class P3_API UP3Command : public UObject
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const { return true; }
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) {}

protected:
	class AActor* GetOwnerActor() const;

private:
	// Command is used as Default object, hence no world. Use Actor parameter instead
	virtual class UWorld* GetWorld() const override { check(0); return nullptr; }
};


/**
 * Apply Damage
 */
UCLASS()
class P3_API UP3ApplyDamageCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Heal
 */
UCLASS()
class P3_API UP3HealCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Change Stance
 */
UCLASS()
class P3_API UP3ChangeStanceCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Set Blocking
 */
UCLASS()
class P3_API UP3SetBlockingCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Set CrouchBlocking
 */
UCLASS()
class P3_API UP3SetCrouchBlockingCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
* BouncingMode
*/
UCLASS()
class P3_API UP3SetBouncingModeCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Set Pushing
 */
UCLASS()
class P3_API UP3SetPushingCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Set Knock down
 */
UCLASS()
class P3_API UP3SetKnockDownedCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Set Gode Mode
 */
UCLASS()
class P3_API UP3SetGodModeCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Set Melee Aiming
 */
UCLASS()
class P3_API UP3SetMeleeAimingCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Set Ranged Aiming
 */
UCLASS()
class P3_API UP3SetRangedAimingCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Revive
 */
UCLASS()
class P3_API UP3ReviveCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Teleport
 */
UCLASS()
class P3_API UP3TeleportCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Ragdollize
 */
UCLASS()
class P3_API UP3RagdollizeCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Part
 */
UCLASS()
class P3_API UP3StartPartCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
* Drop Pickable
*/
UCLASS()
class P3_API UP3DropPickableCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
* Drop Holdable
*/
UCLASS()
class P3_API UP3DropHoldableCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Change Holdable
 */
UCLASS()
class P3_API UP3ChangeHoldableCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;

private:
	bool SetHoldingActor(AP3Character& Character, EP3HoldType HoldType, FP3ItemId HolderItemId, AActor* HolderItemActor, const FP3Item& InvenItem);

	bool bRemovePrevItemAfterChange = false;
};


/**
* Stumble
*/
UCLASS()
class P3_API UP3SetStumblingCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
* Mount
*/
UCLASS()
class P3_API UP3MountCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
* LaunchProjectile
*/
UCLASS()
class P3_API UP3LaunchProjectileCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;

private:
	void Multicast_OnFire(class AP3Character& Character, class AP3Weapon& WeaponActor, const FP3CommandRequestParams& Params);
	void Server_OnFire(class AP3Character& Character, class AP3Weapon& WeaponActor, const FP3CommandRequestParams& Params);
};

/**
* Throw Forced
*/
const static FName NAME_ThrowForcedActor(TEXT("ThrowForcedActor"));

UCLASS()
class P3_API UP3ThrowForcedCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

UCLASS()
class P3_API UP3BuckingEndureCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

///**
// * Pose aim with item from inventory
// */
//UCLASS()
//class P3_API UP3AimItemFromInventoryCommand : public UP3Command
//{
//	GENERATED_BODY()
//
//public:
//	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
//	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
//};

/**
 * Throw item from inventory
 */
UCLASS()
class P3_API UP3ThrowItemFromInventoryCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Second step of throwing item from inventory command
 */
UCLASS()
class P3_API UP3ThrowItemFromInventoryStep2Command : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Hold item
 */
UCLASS()
class P3_API UP3HoldItemCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Clear pickupped actor
 */
UCLASS()
class P3_API UP3ClearPickuppedActorCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Bucking
 */
UCLASS()
class P3_API UP3SetBuckingCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Revert after using temporary weapon
 */
UCLASS()
class P3_API UP3RecoveryAfterTempWeaponCommand : public UP3Command
{
	GENERATED_BODY()

public:
	static bool Server_BuildParams(UWorld* World, const AP3Character& Character, FP3CommandRequestParams& Params);
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Change the material value 
 */
UCLASS()
class P3_API UP3SetParameterValueOnMaterialCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Look at target location
 */
UCLASS()
class P3_API UP3LookAtCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Talk
 */
UCLASS()
class P3_API UP3TalkCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * CableAttachEnd
 */
UCLASS()
class P3_API UP3CableAttachEndCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Set Crippled Walking
 */
UCLASS()
class P3_API UP3SetCrippledCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * CameraShake
 */
UCLASS()
class P3_API UP3CameraShakeCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * PlayReactionVFX
 */
UCLASS()
class P3_API UP3PlayReactionVFXCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Change throwable
 */
UCLASS()
class P3_API UP3SetChangingThrowableCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Set Stroll (Walk Slowly)
 */
UCLASS()
class P3_API UP3SetStrollCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Set Character Emote By Name
 */
UCLASS()
class P3_API UP3SetEmoteByNameCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Pickup Backpack
 */
UCLASS()
class P3_API UP3PickupBackpackCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Putdown Backpack
 */
UCLASS()
class P3_API UP3PutdownBackpackCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual bool CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const override;
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};


/**
 * Play Combat Response Hit
 */
UCLASS()
class P3_API UP3PlayCombatResponseHitCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};

/**
 * Set In Emote
 */
UCLASS()
class P3_API UP3SetInEmoteCommand : public UP3Command
{
	GENERATED_BODY()

public:
	virtual void Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params) override;
};
