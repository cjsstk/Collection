// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Command.h"

#include "AIController.h"
#include "BrainComponent.h"
#include "Classes/CableComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Engine/WorldComposition.h"
#include "GameFramework/Actor.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"

#include "Action/P3PawnActionComponent.h"
#include "Network/P3WorldNet.h"
#include "P3Backpack.h"
#include "P3CharacterMovementComponent.h"
#include "P3Combat.h"
#include "P3CombatComponent.h"
#include "P3CombatResponseComponent.h"
#include "P3CommandComponent.h"
#include "P3ConsumableComponent.h"
#include "P3Character.h"
#include "P3DamageMetersComponent.h"
#include "P3Destructible.h"
#include "P3EquipmentComponent.h"
#include "P3ExperiencePointComponent.h"
#include "P3GameInstance.h"
#include "P3HealthPointComponent.h"
#include "P3HolderComponent.h"
#include "P3InteractableComponent.h"
#include "P3InventoryComponent.h"
#include "P3Log.h"
#include "P3PartComponent.h"
#include "P3PartInventoryComponent.h"
#include "P3PickupComponent.h"
#include "P3PickupableComponent.h"
#include "P3PlayerController.h"
#include "P3Projectile.h"
#include "P3RagdollComponent.h"
#include "P3StaminaPointComponent.h"
#include "P3Store.h"
#include "P3Weapon.h"
#include "P3World.h"
#include "Widget/P3DamageMetersWidget.h"

static TAutoConsoleVariable<float> CVarP3CombatNoAnimHitTimeDilation(
	TEXT("p3.combatNoAnimHitTimeDilation"),
	0.01f,
	TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3CombatNoAnimHitTimeDilationDurationSeconds(
	TEXT("p3.combatNoAnimHitTimeDilationDurationSeconds"),
	0.1f,
	TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3CombatNoSourceHostileDamageCombatTextMaxDistance(
	TEXT("p3.combatNoSourceHostileDamageCombatTextMaxDistance"),
	3000.0f,
	TEXT("Set max distance of damage combat text for hostile actor when source is null"), ECVF_Cheat);

extern TAutoConsoleVariable<float> CVarP3CombatBlockStartStaminaAmount;
extern TAutoConsoleVariable<float> CVarP3CombatCrouchBlockStartStaminaAmount;
extern TAutoConsoleVariable<int32> CVarP3RotateCameraOnMountingResuced;

#undef CommandJsonLog
#define CommandJsonLog(Verbosity, Subject, ...) \
	P3JsonLog(Verbosity, Subject,	\
		TEXT("Actor"), Actor.GetName(),	\
		TEXT("Role"), EnumToStringShort(ENetRole, Actor.Role),	\
		TEXT("Command"), GetClass()->GetName(),	\
		##__VA_ARGS__)


void UP3ApplyDamageCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	P3Combat::Multicast_ApplyDamageByCommand(
		Actor, Params.ApplyDamage_SourceActor.Actor, Params.ApplyDamage_DamageAmount, Params.ApplyDamage_PartIndex, Params.ApplyDamage_WeaponType, Params.ApplyDamage_Reason, *this);

	AP3Character* SourceCharacter = Cast<AP3Character>(Params.ApplyDamage_SourceActor.Actor);
	AP3Character* TargetCharacter = Cast<AP3Character>(&Actor);

	if (TargetCharacter && Params.ApplyDamage_bHoldFrame)
	{
		TargetCharacter->SetTimeDelation(
			CVarP3CombatNoAnimHitTimeDilation.GetValueOnGameThread(),
			CVarP3CombatNoAnimHitTimeDilationDurationSeconds.GetValueOnGameThread());
	}

	AP3PlayerController* LocalPlayerController = Actor.GetWorld() ? Cast<AP3PlayerController>(Actor.GetWorld()->GetFirstPlayerController()) : nullptr;
	AP3Character* LocalCharacter = LocalPlayerController ? Cast<AP3Character>(LocalPlayerController->GetPawn()) : nullptr;
	FVector PlayerViewLocation;
	FRotator PlayerViewRotation;
	if (LocalPlayerController)
	{
		LocalPlayerController->GetPlayerViewPoint(PlayerViewLocation, PlayerViewRotation);
	}

	const bool bLocalPlayerIsSource = (LocalPlayerController && (SourceCharacter == LocalPlayerController->GetPawn()));
	const bool bTargetIsEnemy = (LocalCharacter && TargetCharacter && LocalCharacter->GetFaction() != TargetCharacter->GetFaction());
	const float DistanceSquared = (Actor.GetActorLocation() - PlayerViewLocation).SizeSquared();
	const bool bNearbyNoSourceEnemy = !SourceCharacter && bTargetIsEnemy && DistanceSquared < FMath::Square(CVarP3CombatNoSourceHostileDamageCombatTextMaxDistance.GetValueOnGameThread());

	// Show combat text if local player is the source or no source and target is hostile
	if (LocalPlayerController && (bLocalPlayerIsSource || bNearbyNoSourceEnemy))
	{
		LocalPlayerController->CreateCombatText(
			TargetCharacter,
			Params.ApplyDamage_HitLocation,
			Params.ApplyDamage_DamageAmount,
			Params.ApplyDamage_WorldImpactDirection,
			Params.ApplyDamage_bIsCriticalPart,
			Params.ApplyDamage_bIsArmorPart);

		UP3DamageMetersComponent* DamageMetersComp = Actor.FindComponentByClass<UP3DamageMetersComponent>();

		if (DamageMetersComp)
		{
			UP3DamageMetersWidget* DamageMetersWidget = LocalPlayerController->GetDamageMetersWidget();

			if (DamageMetersWidget)
			{
				DamageMetersWidget->SetDamageMetersComponent(DamageMetersComp);
			}
		}
	}

	if (TargetCharacter)
	{
		if (TargetCharacter->IsGliding())
		{
			TargetCharacter->BreakGlidingByCommand(*this);
		}
		else if (TargetCharacter->IsClimbing())
		{
			TargetCharacter->BreakClimbingByCommand(*this);
		}

		UP3PartComponent* PartComponent = nullptr;
		if (!Params.ApplyDamage_PartName.IsNone())
		{
			PartComponent = P3Core::GetActorComponentByName<UP3PartComponent>(*TargetCharacter, Params.ApplyDamage_PartName.ToString());

			if (PartComponent)
			{
				PartComponent->OnPartDamaged(Params.ApplyDamage_HitLocation, Params.ApplyDamage_WorldImpactDirection);
			}
		}

		TargetCharacter->ReceiveCombatDamage(Params.ApplyDamage_HitLocation, PartComponent);

		const bool bIsDead = TargetCharacter->GetP3HealthComponentBP() && TargetCharacter->GetP3HealthComponentBP()->GetHealthPoint() == 0;
		if (bIsDead)
		{
			if (Params.ApplyDamage_bRagdollizeIfDead)
			{
				TargetCharacter->RagdollizeByCommand(*this, true);
			}

			if (SourceCharacter && P3Core::IsP3NetModeServerInstance(*SourceCharacter))
			{
				UP3ExperiencePointComponent* ExperiencePointComponent = SourceCharacter->GetExperienceComponent();

				if (ExperiencePointComponent)
				{
					/** TODO: Get ExperiencePoint from CMS */
					ExperiencePointComponent->Server_AddExperiencePoint(10);
				}
			}
		}
	}

	if (SourceCharacter)
	{
		const UP3CharacterSounds* CharacterSounds = SourceCharacter->GetCharacterSounds();
		if (CharacterSounds)
		{
			UGameplayStatics::PlaySoundAtLocation(Actor.GetWorld(), CharacterSounds->GetHit(), Actor.GetActorLocation());
		}
	}

	if (TargetCharacter)
	{
		FP3CharacterDamage CharacterDamage;
		CharacterDamage.AttackStrength = Params.ApplyDamage_AttackStrength;
		CharacterDamage.DamageAmount = Params.ApplyDamage_DamageAmount;
		
		TargetCharacter->OnCharacterDamage(CharacterDamage);
	}
}

void UP3HealCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	UP3HealthPointComponent* HealthPointComp = Character->GetP3HealthComponentBP();
	if (!ensure(HealthPointComp))
	{
		return;
	}

	int32 Amount = Params.Heal_Amount;
	if (Params.Heal_bToMaxPoint)
	{
		Amount = HealthPointComp->GetMaxHealthPoint() - HealthPointComp->GetHealthPoint();
	}

	P3Combat::ChangeActorHealth(Character, *HealthPointComp, Amount, EP3HealthChangeReason::Heal);
}

void UP3ChangeStanceCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	Character->SetStanceByCommand(*this, Params.ChangeStance_NewStance, true);
}

void UP3SetBlockingCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	if (Params.SetBlocking_bNewBlocking)
	{
		if (Character->CanBlock())
		{
			Character->SetBlockingByCommand(*this, true);
			Character->GetStaminaComponent()->ConsumeStamina(CVarP3CombatBlockStartStaminaAmount.GetValueOnGameThread());
		}
	}
	else
	{
		Character->SetBlockingByCommand(*this, false);
	}
}

void UP3SetCrouchBlockingCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	if (Params.SetCrouchBlocking_bNewBlocking)
	{
		if (Character->CanBlock())
		{
			Character->SetCrouchBlockingByCommand(*this, true);
			Character->GetStaminaComponent()->ConsumeStamina(CVarP3CombatCrouchBlockStartStaminaAmount.GetValueOnGameThread());
		}
	}
	else
	{
		Character->SetCrouchBlockingByCommand(*this, false);
	}
}

void UP3SetBouncingModeCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return;
	}

	Character->SetBouncingModeByCommand(*this, Params.SetBouncing_bNewBouncingMode);
}


void UP3SetKnockDownedCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	Character->SetKnockDownedByCommand(*this, Params.SetKnockDowned_bNewKnowDowned, Params.SetKnockDowned_DurationSeconds);
}

bool UP3SetPushingCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	if (!ensure(!Params.SetPushing_bNewPushing || Params.SetPushing_PushingTargetActor.IsValidIdOrReplicated()))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return false;
	}

	if (Character->GetCharacterStoreBP().Stance == EP3CharacterStance::Pickup)
	{
		return false;
	}

	return true;
}

void UP3SetPushingCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	Character->SetPushingByCommand(*this, Params.SetPushing_bNewPushing, Params.SetPushing_PushingTargetActor.Actor);
}

void UP3SetGodModeCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	FP3CharacterStore NewStore = Character->GetCharacterStoreBP();
	NewStore.bGodMode = Params.SetGodMode_bNewGodMode;
	NewStore.bNoTargetMode = Params.SetGodMode_bNewNoTargetMode;

	Character->SetCharacterStoreByCommand(*this, NewStore);
}

void UP3SetMeleeAimingCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	FP3CharacterStore CharacterStore = Character->GetCharacterStoreBP();

	CharacterStore.bIsMeleeAiming = Params.SetMeleeAiming_bNewAiming;

	Character->SetCharacterStoreByCommand(*this, CharacterStore);
}

bool UP3SetRangedAimingCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return false;
	}

	EP3CharacterStance CurrentStance = Character->GetStance();

	if (CurrentStance != EP3CharacterStance::Idle && CurrentStance != EP3CharacterStance::Combat)
	{
		return false;
	}

	if ((CurrentStance == EP3CharacterStance::Idle) && Params.SetRangedAiming_bNewAiming)
	{
		UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
		if (InvenComp)
		{
			const FP3Item Item = InvenComp->GetItem(Params.SetRangedAiming_ThrowAimingItemId);
			if (!ensure(Item.IsValid()))
			{
				return false;
			}

			const FP3CmsThrowable* ItemThrowable = P3Cms::GetItemThrowable(Item.Key);
			if (!ensure(ItemThrowable))
			{
				return false;
			}

			UClass* ActorClass = ItemThrowable->ItemActorClass.LoadSynchronous();
			if (!ensure(ActorClass))
			{
				return false;
			}
		}
	}

	return true;
}

void UP3SetRangedAimingCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	FP3CharacterStore CharacterStore = Character->GetCharacterStoreBP();

	//if (CharacterStore.bIsAiming == Params.SetRangedAiming_bNewAiming)
	//{
	//	return;
	//}

	CharacterStore.bIsAiming = Params.SetRangedAiming_bNewAiming;
	CharacterStore.ThrowAimingItemId = Params.SetRangedAiming_ThrowAimingItemId;

	Character->SetCharacterStoreByCommand(*this, CharacterStore);

	if (Params.SetRangedAiming_bNewAiming)
	{
		if (Params.SetRangedAiming_bChangeToCombatStance)
		{
			Character->SetStanceByCommand(*this, EP3CharacterStance::Combat, true);
		}

		if (Character->IsGliding())
		{
			Character->BreakGlidingByCommand(*this);
		}

	}
}

bool UP3ReviveCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	UP3HealthPointComponent* HealthComponent = Actor.FindComponentByClass<UP3HealthPointComponent>();
	if (HealthComponent && !HealthComponent->IsDead())
	{
		CommandJsonLog(Error, "Revive command failed. Not dead yet");
		return false;
	}

	return true;
}

void UP3ReviveCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(Actor))
	{
		UP3HealthPointComponent* HealthComp = Character->GetP3HealthComponentBP();
		if (ensure(HealthComp))
		{
			HealthComp->Server_Revive(Params.Revive_NewHealthPoint);
		}
	}
}

void UP3TeleportCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	Actor.SetActorLocationAndRotation(Params.Teleport_Location, Params.Teleport_Rotation, false, nullptr, ETeleportType::TeleportPhysics);

	if (IsLocalControlledActor(&Actor))
	{
		APawn* Pawn = Cast<APawn>(&Actor);
		if (Pawn)
		{
			APlayerController* PC = Cast<APlayerController>(Pawn->GetController());
			if (PC)
			{
				PC->SetControlRotation(Pawn->GetActorRotation());
				if (PC->PlayerCameraManager)
				{
					PC->PlayerCameraManager->UpdateCamera(0);
				}
			}
		}

		// FIXME: this is not enough. got to fix APlayerController::GetPlayerViewPoint
		FVector Location = Params.Teleport_Location;
		if (Actor.GetWorld()->WorldComposition)
		{
			Actor.GetWorld()->WorldComposition->UpdateStreamingState(&Location, 1);
		}
		GEngine->BlockTillLevelStreamingCompleted(Actor.GetWorld());

		// History of failure... maybe needed for client?(NOT TESTED YET)
		//Actor.GetWorld()->ProcessLevelStreamingVolumes(&Location);
		//Actor.GetWorld()->FlushLevelStreaming(EFlushLevelStreamingType::Full);
		//Actor.GetWorld()->bRequestedBlockOnAsyncLoading = true;
	}
}

bool UP3RagdollizeCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	ACharacter* Character = Cast<ACharacter>(&Actor);

	if (!ensure(Character))
	{
		return false;
	}

	return true;
}

void UP3RagdollizeCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (Character)
	{
		Character->RagdollizeByCommand(*this, Params.Ragdollize_bRagdoll);
	}
	else
	{
		UP3RagdollComponent* RagdollComp = Actor.FindComponentByClass<UP3RagdollComponent>();
		if (ensure(RagdollComp))
		{
			if (Params.Ragdollize_bRagdoll)
			{
				RagdollComp->Ragdollize();
			}
			else
			{
				RagdollComp->Unragdollize();
			}
		}
	}
}

bool UP3StartPartCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	const UP3EquipmentComponent* PartComp = Actor.FindComponentByClass<UP3EquipmentComponent>();
	if (ensure(PartComp))
	{
		if (Params.SetPart_bStart)
		{
			if (P3Core::IsP3NetModeServerInstance(Actor))
			{
				return PartComp->Server_CanPartStart(Params.PartType);
			}
		}

		return true;
	}

	return false;
}

void UP3StartPartCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	if (Params.SetPart_bAdd)
	{
		UP3PartInventoryComponent* PartInventoryComp = Actor.FindComponentByClass<UP3PartInventoryComponent>();
		if (!ensure(PartInventoryComp)) return;

		PartInventoryComp->HolderPart(Params.SlotIndex);
	}
	else
	{
		UP3EquipmentComponent* PartComp = Actor.FindComponentByClass<UP3EquipmentComponent>();
		if (!ensure(PartComp)) return;

		if (Params.SetPart_bStart)
		{
			PartComp->StartPart(Params.PartType);
		}
		else
		{
			if (!Params.SetPart_bInterrupt)
			{
				PartComp->StopPart(Params.PartType);
			}
			else
			{
				PartComp->StopPartInterrupt(Params.PartType);
			}
		}
	}
}

bool UP3DropPickableCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	Super::CanExecute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return false;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();

	return (PickupComp && PickupComp->GetPickuppedActor() != nullptr);
}

void UP3DropPickableCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();

	if (PickupComp && PickupComp->GetPickuppedActor())
	{
		// TODO: We have need to see if target actor is same as requested one
		AActor* TargetActor = PickupComp->GetPickuppedActor();
		if (!TargetActor->IsActorBeingDestroyed())
		{
			TargetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

			UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());

			if (PrimComp)
			{
				UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
				if (PickupableComp)
				{
					PickupableComp->RestorePhysicsAfterPutdown();
				}
				else
				{
					PrimComp->SetSimulatePhysics(true);
				}

				if (IsAuthority(Character))
				{
					AP3Destructible* Destructible = Cast<AP3Destructible>(TargetActor);
					if (Destructible)
					{
						Destructible->Server_SetPOIOriginLocation(Character->GetActorLocation());
					}
				}
			}

			PickupComp->OnThrowActionFinished();
		}
	}

	Character->SetStanceByCommand(*this, EP3CharacterStance::Idle, true);
}

bool UP3SetStumblingCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return false;
	}

	if (Params.SetStumbling_bIsStumbling && Character->IsDeadOrDowned())
	{
		return false;
	}

	return true;
}

void UP3SetStumblingCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return;
	}

	Character->SetStumblingByCommand(*this, Params.SetStumbling_bIsStumbling);
}

bool UP3MountCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return false;
	}

	if (Params.Mount_Detach)
	{
		// Unmount
		if (!Character->GetCharacterStoreBP().MountTargetCharacter)
		{
			// Not mounted
			return false;
		}
	}
	else
	{
		// Mount

		if (Character->GetCharacterStoreBP().MountTargetCharacter != nullptr)
		{
			// You can't mount twice
			return false;
		}

		if (!ensure(Params.Mount_TargetCharacter))
		{
			return false;
		}

		if (!ensure(Params.Mount_TargetCharacter->GetMountPoints().IsValidIndex(Params.Mount_TargetMountPointIndex)))
		{
			return false;
		}

		if (!Params.Mount_TargetCharacter->IsMountPointAvailable(Params.Mount_TargetMountPointIndex))
		{
			return false;
		}

		if (Params.Mount_TargetCharacter->IsDead())
		{
			return false;
		}
	}

	return true;
}

void UP3MountCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return;
	}

	if (Params.Mount_Detach)
	{
		if (ensure(Character->GetCharacterStoreBP().MountTargetCharacter))
		{
			Character->GetCharacterStoreBP().MountTargetCharacter->SetRiderByCommand(*this, nullptr, Character->GetCharacterStoreBP().MountPointIndex);
		}

		// Find good eject direction : side way from mount target
		const FVector MountOffset = Character->GetActorLocation() - Character->GetCharacterStoreBP().MountTargetCharacter->GetActorLocation();
		const FVector MountTargetRightVector = Character->GetCharacterStoreBP().MountTargetCharacter->GetActorRightVector();
		const FVector EjectDirection = (MountOffset | MountTargetRightVector) > 0.0f ? MountTargetRightVector : -MountTargetRightVector;

		Character->DismountByCommand(*this);
		Character->SetBuckingEndureByCommand(*this, false);

		if (Params.Mount_DeatchWithEjection && Character->GetP3CharacterMovementBP())
		{
			Character->GetP3CharacterMovementBP()->AddImpulse(EjectDirection * 800, true);
		}
	}
	else
	{
		if (ensure(Params.Mount_TargetCharacter))
		{
			Params.Mount_TargetCharacter->SetRiderByCommand(*this, Character, Params.Mount_TargetMountPointIndex);
		}

		Character->MountByCommand(*this, Params.Mount_TargetCharacter, Params.Mount_TargetMountPointIndex, Params.Mount_bRescuing);

		if (IsLocalControlledActor(Character))
		{
			if ((CVarP3RotateCameraOnMountingResuced.GetValueOnGameThread() > 0 && Params.Mount_bRescuing) || !Params.Mount_bRescuing)
			{
				AController* CharacterController = Character->GetController();
				if (ensure(CharacterController))
				{
					CharacterController->SetControlRotation(UKismetMathLibrary::MakeRotFromX(-Character->GetActorUpVector()));
				}
			}
		}
	}
}

bool UP3LaunchProjectileCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return false;
	}

	if (!ensure(Params.LaunchProjectile_Class))
	{
		return false;
	}

	return true;
}

void UP3LaunchProjectileCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return;
	}

	AP3Weapon* WeaponActor = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());

	if (!ensure(WeaponActor))
	{
		return;
	}

	Multicast_OnFire(*Character, *WeaponActor, Params);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		Server_OnFire(*Character, *WeaponActor, Params);
	}
}

void UP3LaunchProjectileCommand::Multicast_OnFire(AP3Character& Character, AP3Weapon& WeaponActor, const FP3CommandRequestParams& Params)
{
	if (WeaponActor.GetProjectileFireSound())
	{
		UGameplayStatics::PlaySoundAtLocation(Character.GetWorld(), WeaponActor.GetProjectileFireSound(), Params.LaunchProjectile_Location);

		WeaponActor.Multicast_OnFireBP();
	}

	if (Params.LaunchProjectile_ConsumeStamina > 0.f)
	{
		UP3StaminaPointComponent* StaminaComp = Character.GetStaminaComponent();
		if (StaminaComp)
		{
			StaminaComp->ConsumeStamina(Params.LaunchProjectile_ConsumeStamina);
		}
	}
}

void UP3LaunchProjectileCommand::Server_OnFire(AP3Character& Character, AP3Weapon& WeaponActor, const FP3CommandRequestParams& Params)
{
	AP3Projectile* Projectile = nullptr;

	if (ensure(Params.LaunchProjectile_Class))
	{
		FActorSpawnParameters ActorSpawnParams;
		ActorSpawnParams.Instigator = &Character;
		ActorSpawnParams.Owner = &WeaponActor;
		ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

		const AP3Projectile* DefaultObject = Params.LaunchProjectile_Class->GetDefaultObject<AP3Projectile>();

		TSubclassOf<class AP3Projectile> ProjectileClass = Params.LaunchProjectile_Class;

		if (DefaultObject)
		{
			// Apply Buff to Projectile table
			// We use this to swap to burning-arrow

			const TMap<int32, TSubclassOf<AP3Projectile>>& BuffProjectileClasses = DefaultObject->GetBuffProjectileClasses();

			UP3CharacterEffectComponent* EffectComp = Character.GetEffectComponent();
			
			if (EffectComp)
			{
				for (auto&& Iter : BuffProjectileClasses)
				{
					if (EffectComp->HasBuffByBuffKey(Iter.Key))
					{
						ProjectileClass = Iter.Value;
						break;
					}
				}
			}
		}

		Projectile = Character.GetWorld()->SpawnActor<AP3Projectile>(ProjectileClass, Params.LaunchProjectile_Location, Params.LaunchProjectile_Rotation, ActorSpawnParams);
	}

	if (ensure(Projectile))
	{
		Projectile->Instigator = &Character;
		Projectile->Server_SetSourceCharacter(&Character);
		Projectile->Server_SetWeaponActor(&WeaponActor);

		WeaponActor.Server_SetLastFiredProjectile(Projectile);
		P3Core::GetP3World(Character)->Server_FireScareFlockEvent(Params.LaunchProjectile_Location, 3000, 10.0f);
	}
}

bool UP3ThrowForcedCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	AP3Character* SourceCharacter = Cast<AP3Character>(&Actor);

	if (!ensure(SourceCharacter) || !ensure(SourceCharacter->GetRightHandWeaponActor())
		|| !ensure(Params.ApplyDamage_SourceActor.Actor))
	{
		return false;
	}

	return true;
}

void UP3ThrowForcedCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* ThrowCharacter = Cast<AP3Character>(Params.ApplyDamage_SourceActor.Actor);
	if (ThrowCharacter)
	{
		if (ThrowCharacter->GetCapsuleComponent())
		{
			ThrowCharacter->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		}

		UCharacterMovementComponent* MovementComp = ThrowCharacter->GetCharacterMovement();
		if (MovementComp)
		{
			MovementComp->SetActive(false);
			MovementComp->StopMovementImmediately();
		}

		const AAIController* AIController = Cast<AAIController>(ThrowCharacter->GetController());
		if (AIController && AIController->BrainComponent)
		{
			static const FString Reason("ThrowForcedCommand");
			AIController->BrainComponent->StopLogic(Reason);
		}
	}
	else
	{
		UPrimitiveComponent* PrimitiveComp = Params.ApplyDamage_SourceActor.Actor->FindComponentByClass<UPrimitiveComponent>();
		if (PrimitiveComp)
		{
			PrimitiveComp->SetSimulatePhysics(false);
			PrimitiveComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		}
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (Character && Character->GetRightHandWeaponActor()
		&& Params.ApplyDamage_SourceActor.Actor)
	{
		static const FName AttachSockeName("ThrowForced");
		FAttachmentTransformRules AttachRule = FAttachmentTransformRules::SnapToTargetNotIncludingScale;

		USkeletalMeshComponent* AttachComponent = Cast<USkeletalMeshComponent>(Character->GetRightHandWeaponActor()->GetComponentByClass(USkeletalMeshComponent::StaticClass()));
		if (AttachComponent)
		{
			Params.ApplyDamage_SourceActor.Actor->AttachToComponent(AttachComponent, AttachRule, AttachSockeName);
		}
		else
		{
			Params.ApplyDamage_SourceActor.Actor->AttachToActor(Character->GetRightHandWeaponActor(), AttachRule, AttachSockeName);
		}

		Params.ApplyDamage_SourceActor.Actor->Tags.Add(NAME_ThrowForcedActor);
	}
}

bool UP3BuckingEndureCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!Character)
	{
		return false;
	}

	if (Character->IsDeadOrDowned())
	{
		return false;
	}

	if (!Character->IsMounted())
	{
		return false;
	}

	if (Params.BuckingEndure_bNewEndure)
	{
		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		if (!ActionComp || ActionComp->GetActiveActionType() != EPawnActionType::BuckingHangOn)
		{
			return false;
		}
	}

	return true;
}

void UP3BuckingEndureCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (Character)
	{
		const bool bIsBuckingEndure = Params.BuckingEndure_bNewEndure;
		Character->SetBuckingEndureByCommand(*this, bIsBuckingEndure);
	}
}

bool UP3DropHoldableCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return false;
	}

	UP3HolderComponent* HolderComp = Character->GetHolderComponentByHoldType(Params.DropHoldable_HoldType);
	if (!HolderComp)
	{
		return false;
	}

	if (!HolderComp->GetHoldingActor())
	{
		return false;
	}


	return true;
}

void UP3DropHoldableCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	UP3HolderComponent* HolderComp = Character->GetHolderComponentByHoldType(Params.DropHoldable_HoldType);
	if (!HolderComp)
	{
		return;
	}

	AActor* DroppedActor = HolderComp->RemoveHoldingActor();
	if (DroppedActor)
	{
		UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(DroppedActor->GetRootComponent());
		if (PrimComp && PrimComp->IsSimulatingPhysics())
		{
			// Don't care about the mass?
			//const float MyMass = PrimComp->GetMass();
			const FVector DropDirection = Params.DropHoldable_DropDirection;
			const float DropImpulseSize = Params.DropHoldable_DropImpulseSize;

			PrimComp->AddImpulse(DropDirection * DropImpulseSize);
		}
	}

	// Do not write to DB
	ensure(!Character->IsPlayerControlled());
}

void UP3ChangeHoldableCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	bRemovePrevItemAfterChange = Params.ChangeHoldable_bRemovePrevItemAfterChange;

	if (SetHoldingActor(*Character,
		Params.ChangeHoldable_RightHoldType,
		Params.ChangeHoldable_InvenToRightHolderItemId,
		Params.ChangeHoldable_InvenToRightHolderItemActor.Actor,
		Params.ChangeHoldable_HolderToRightInvenItem))
	{
		if (Character->GetCharacterStoreBP().bIsAiming
			&& Params.ChangeHoldable_HolderToRightInvenItem.IsValid())
		{
			const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(Params.ChangeHoldable_HolderToRightInvenItem.Key);
			if (ensure(CmsHoldable))
			{
				if (!IsRangedWeapon(CmsHoldable->WeaponType))
				{
					Character->SetAimingByCommand(*this, false);
				}
			}
		}

		SetHoldingActor(*Character,
			Params.ChangeHoldable_LeftHoldType,
			Params.ChangeHoldable_InvenToLeftHolderItemId,
			Params.ChangeHoldable_InvenToLeftHolderItemActor.Actor,
			Params.ChangeHoldable_HolderToLeftInvenItem);

		return;
	}

}

bool UP3ChangeHoldableCommand::SetHoldingActor(AP3Character& Character, EP3HoldType HoldType, FP3ItemId HolderItemId, AActor* HolderItemActor, const FP3Item& InvenItem)
{
	if (!ensure(HoldType != EP3HoldType::Count))
	{
		return false;
	}

	EP3CharacterItemSlot CharacterItemSlot = FP3ItemUtil::GetCharacterItemSlotFromHoldType(HoldType);
	if (!ensure(CharacterItemSlot != EP3CharacterItemSlot::Invalid))
	{
		return false;
	}

	UP3HolderComponent* HolderComp = Character.GetHolderComponentByHoldType(HoldType);
	if (!ensure(HolderComp))
	{
		return false;
	}

	UP3InventoryComponent* InventoryComp = Character.GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return false;
	}

	const FP3Item HoldingItem = InventoryComp->GetItemBySlot(CharacterItemSlot);
	if (!ensure(HoldingItem.Id == InvenItem.Id))
	{
		return false;
	}

	UP3WorldNetBase* WorldNet = nullptr;
	if (P3Core::IsP3NetModeServerInstance(Character))
	{
		WorldNet = P3GetWorldNet(&Character);
		if (!ensure(WorldNet))
		{
			return false;
		}
	}

	AActor* HoldingItemActor = Character.RemoveHoldingActorByCommand(*this, HolderComp);

	if (InvenItem.IsValid())
	{
		if (P3Core::IsP3NetModeServerInstance(Character))
		{
			// Remove from holder
			if (ensure(HoldingItemActor))
			{
				HoldingItemActor->Destroy();
			}

			// Update slot in inventory
			InventoryComp->Server_ChangeItemSlot(InvenItem.Id, EP3CharacterItemSlot::Inventory);

			// Write to DB
			WorldNet->SendUpdateCharacterItemSlot(Character.GetCharacterStoreBP().CharacterId, InvenItem.Id, EP3CharacterItemSlot::Inventory); //-V522

			if (bRemovePrevItemAfterChange)
			{
				InventoryComp->Server_RemoveItemByIdAndCount(InvenItem.Id, 1);
			}
		}
	}

	if (HolderItemId != INVALID_ITEMID)
	{
		// Prepare item
		const FP3Item HolderItem = InventoryComp->GetItem(HolderItemId);

		if (P3Core::IsP3NetModeServerInstance(Character))
		{
			// Update slot in inventory
			InventoryComp->Server_ChangeItemSlot(HolderItemId, CharacterItemSlot);

			// Write to DB
			WorldNet->SendUpdateCharacterItemSlot(Character.GetCharacterStoreBP().CharacterId, HolderItemId, CharacterItemSlot);
		}

		// Hold an item
		const bool bHold = Character.GetStance() == EP3CharacterStance::Combat;
		Character.SetHoldingActorByCommand(*this, HolderComp, HolderItemActor, bHold);
	}

	return true;
}
//
//bool UP3AimItemFromInventoryCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
//{
//	if (!Super::CanExecute(Actor, Params))
//	{
//		return false;
//	}
//
//	if (!ensure(Params.AimItemFromInventory_ItemId != INVALID_ITEMID))
//	{
//		return false;
//	}
//
//	AP3Character* Character = Cast<AP3Character>(&Actor);
//	if (!Character)
//	{
//		return false;
//	}
//
//	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
//	if (!ActionComp)
//	{
//		return false;
//	}
//
//	if (!ActionComp->CanStartAction(EPawnActionType::Throw))
//	{
//		return false;
//	}
//
//	return true;
//}
//
//void UP3AimItemFromInventoryCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
//{
//	Super::Multicast_Execute(Actor, Params);
//
//	if (P3Core::IsP3NetModeServerInstance(Actor))
//	{
//		AP3Character* Character = Cast<AP3Character>(&Actor);
//		if (!ensure(Character))
//		{
//			return;
//		}
//
//		UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);
//		if (!ensure(WorldNet))
//		{
//			return;
//		}
//
//		UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
//		if (!ensure(InventoryComp))
//		{
//			return;
//		}
//
//		UP3PickupComponent* PickupComp = Character->GetPickupComponent();
//		if (!ensure(PickupComp) || PickupComp->GetPickuppedActor())
//		{
//			return;
//		}
//
//		AActor* ItemActor = InventoryComp->SpawnItemActor(Params.AimItemFromInventory_ItemId);
//
//		PickupComp->Hold(ItemActor);
//
//		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
//		if (!ensure(CommandComp))
//		{
//			return;
//		}
//
//		USkeletalMeshComponent* CharacterMesh = Character->GetMesh();
//		if (!ensure(CharacterMesh))
//		{
//			return;
//		}
//
//		const FP3Item ThrowItem = InventoryComp->GetItem(Params.ThrowItemFromInventory_ItemId);
//		UClass* ActorClass = P3Cms::GetActorClassFromItemKey(ThrowItem.Key);
//		if (!ensure(ActorClass))
//		{
//			return;
//		}
//
//		static const FName AttachSocketName = FName(TEXT("item_hand_r"));
//		FTransform SocketTransform = CharacterMesh->GetSocketTransform(AttachSocketName);
//
//		FActorSpawnParameters SpawnParams;
//		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
//		AActor* ThrowItemActor = Actor.GetWorld()->SpawnActor<AActor>(ActorClass, SocketTransform, SpawnParams);
//		if (!ensure(ThrowItemActor))
//		{
//			return;
//		}
//
//		P3Item::Server_DecreaseItemStackOrRemove(*WorldNet, *InventoryComp, Character->GetCharacterStoreBP().CharacterId, ThrowItem.Id, 1); //-V522
//
//		/** Attach to hand */
//		ThrowItemActor->DisableComponentsSimulatePhysics();
//		ThrowItemActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::KeepWorldTransform, AttachSocketName);
//
//		FP3CommandRequestParams CommandParams;
//		CommandParams.ThrowItemFromInventoryStep2_ItemId = ThrowItem.Id;
//		CommandParams.ThrowItemFromInventoryStep2_ItemActor = ThrowItemActor;
//		CommandComp->RequestCommand(UP3ThrowItemFromInventoryStep2Command::StaticClass(), CommandParams);
//	}
//}

bool UP3ThrowItemFromInventoryCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	if (!ensure(Params.ThrowItemFromInventory_ItemId != INVALID_ITEMID))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ActionComp)
	{
		return false;
	}

	if (!ActionComp->CanStartAction(EPawnActionType::Throw))
	{
		return false;
	}

	return true;
}

void UP3ThrowItemFromInventoryCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	if (P3Core::IsP3NetModeServerInstance(Actor))
	{
		AP3Character* Character = Cast<AP3Character>(&Actor);
		if (!ensure(Character))
		{
			return;
		}

		UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			return;
		}

		UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
		if (!ensure(InventoryComp))
		{
			return;
		}

		UP3PickupComponent* PickupComp = Character->GetPickupComponent();
		if (!ensure(PickupComp) || PickupComp->GetPickuppedActor())
		{
			return;
		}

		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		if (!ensure(CommandComp))
		{
			return;
		}

		USkeletalMeshComponent* CharacterMesh = Character->GetMesh();
		if (!ensure(CharacterMesh))
		{
			return;
		}

		const FP3Item ThrowItem = InventoryComp->GetItem(Params.ThrowItemFromInventory_ItemId);
		const FP3CmsThrowable* ItemThrowable = P3Cms::GetItemThrowable(ThrowItem.Key);
		if (!ensure(ItemThrowable))
		{
			return;
		}

		UClass* ActorClass = ItemThrowable->ItemActorClass.LoadSynchronous();
		if (!ensure(ActorClass))
		{
			return;
		}

		static const FName AttachSocketName = FName(TEXT("item_hand_r"));
		FTransform SocketTransform = CharacterMesh->GetSocketTransform(AttachSocketName);

		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		AActor* ThrowItemActor = Actor.GetWorld()->SpawnActor<AActor>(ActorClass, SocketTransform, SpawnParams);
		if (!ensure(ThrowItemActor))
		{
			return;
		}

		InventoryComp->Server_RemoveItemByIdAndCount(ThrowItem.Id, 1);

		/** Attach to hand */
		ThrowItemActor->DisableComponentsSimulatePhysics();
		ThrowItemActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::KeepWorldTransform, AttachSocketName);

		FP3CommandRequestParams CommandParams;
		CommandParams.ThrowItemFromInventoryStep2_ItemId = ThrowItem.Id;
		CommandParams.ThrowItemFromInventoryStep2_ItemActor = ThrowItemActor;
		CommandComp->RequestCommand(UP3ThrowItemFromInventoryStep2Command::StaticClass(), CommandParams);
	}
}

bool UP3ThrowItemFromInventoryStep2Command::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!ensure(Params.ThrowItemFromInventoryStep2_ItemId != INVALID_ITEMID))
	{
		return false;
	}

	return true;
}

void UP3ThrowItemFromInventoryStep2Command::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	CommandJsonLog(Error, "Step2 Start");

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();
	if (!ensure(PickupComp && !PickupComp->GetPickuppedActor()))
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return;
	}

	FP3ItemId ThrowItemId = Params.ThrowItemFromInventoryStep2_ItemId;
	AActor* ThrowItemActor = Params.ThrowItemFromInventoryStep2_ItemActor;
	if (!ensure(ThrowItemActor))
	{
		return;
	}

	UP3PickupableComponent* PickupableComp = ThrowItemActor->FindComponentByClass<UP3PickupableComponent>();
	if (PickupableComp)
	{
		PickupableComp->DisablePhysicsForPickup();
	}

	/** Set PickUped Actor */
	PickupComp->SetPickuppedActor(ThrowItemActor);

	/** Set Instigator */
	ThrowItemActor->Instigator = Character;

	/** Throw Item */
	if (Character->IsLocallyControlled())
	{
		if (ActionComp->CanStartAction(EPawnActionType::Throw))
		{
			CommandJsonLog(Error, "Can Start Throw");
			PickupComp->AimThrow();
			PickupComp->Throw();
		}
		else
		{
			ThrowItemActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

			UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(ThrowItemActor->GetRootComponent());

			if (PrimComp)
			{
				if (PickupableComp)
				{
					PickupableComp->RestorePhysicsAfterPutdown();
				}
				else
				{
					PrimComp->SetSimulatePhysics(true);
				}
			}
		}
	}
}

bool UP3HoldItemCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	if (!ensure(Params.HoldItem_ItemActor))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ActionComp)
	{
		return false;
	}

	return true;
}

void UP3HoldItemCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	if (!ensure(Params.HoldItem_ItemActor))
	{
		return;
	}

	UP3PickupComponent* PickUpComp = Character->GetPickupComponent();
	if (!ensure(PickUpComp))
	{
		return;
	}

	Params.HoldItem_ItemActor->Instigator = Character;

	if (ensure(!PickUpComp->GetPickuppedActor()))
	{
		PickUpComp->HoldActor(Params.HoldItem_ItemActor, true);
	}
}

void UP3ClearPickuppedActorCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	UP3PickupComponent* PickUpComp = Character->GetPickupComponent();
	if (!ensure(PickUpComp))
	{
		return;
	}

	PickUpComp->SetPickuppedActor(nullptr);

	Character->SetStanceByCommand(*this, EP3CharacterStance::Idle, false);
}

bool UP3SetBuckingCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	return true;
}

void UP3SetBuckingCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	const bool bBucking = Params.Bucking_bInBucking;
	Character->SetBuckingByCommand(bBucking);
}

bool UP3RecoveryAfterTempWeaponCommand::Server_BuildParams(UWorld* World, const AP3Character& Character, FP3CommandRequestParams& Params)
{
	UP3HolderComponent* RightHolderComp = Character.GetHolderComponentByHoldType(EP3HoldType::RightHand);
	UP3HolderComponent* LeftHolderComp = Character.GetHolderComponentByHoldType(EP3HoldType::LeftHand);
	if (!ensure(RightHolderComp) || !ensure(LeftHolderComp))
	{
		return false;
	}

	UP3InventoryComponent* InventoryComp = Character.GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return false;
	}

	// Check recovery items are valid
	FP3Item RightRecoveryItem = InventoryComp->GetItem(RightHolderComp->Server_GetRecoveryAfterTempWeaponItem().Id);
	FP3Item LeftRecoveryItem = InventoryComp->GetItem(LeftHolderComp->Server_GetRecoveryAfterTempWeaponItem().Id);

	if (!RightRecoveryItem.IsValid())
	{
		// Right recovery item is invalid, let's forget left recovery item too
		RightRecoveryItem = InventoryComp->FindHoldableItem(EP3HoldType::RightHand);
		LeftRecoveryItem = FP3Item::InvalidItem;
	}

	AActor* RightRecoveryItemActor = nullptr;
	AActor* LeftRecoveryItemActor = nullptr;

	if (RightRecoveryItem.IsValid())
	{
		RightRecoveryItemActor = FP3ItemUtil::SpawnItemActor(World, RightRecoveryItem.Key);
		if (ensure(RightRecoveryItemActor))
		{
			if (!LeftRecoveryItem.IsValid())
			{
				const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(RightRecoveryItem.Key);
				if (CmsHoldable)
				{
					LeftRecoveryItem = InventoryComp->FindHoldableItem(EP3HoldType::LeftHand, CmsHoldable->WeaponType);
				}
			}

			if (LeftRecoveryItem.IsValid())
			{
				LeftRecoveryItemActor = FP3ItemUtil::SpawnItemActor(World, LeftRecoveryItem.Key);
				if (!ensure(LeftRecoveryItemActor))
				{
					LeftRecoveryItem = FP3Item::InvalidItem;
				}
			}
		}
		else
		{
			RightRecoveryItem = FP3Item::InvalidItem;
			LeftRecoveryItem = FP3Item::InvalidItem;
		}
	}

	Params.RecoveryAfterTempWeapon_HoldingItemActor = RightHolderComp->GetHoldingActor();
	Params.RecoveryAfterTempWeapon_HoldingItemId = InventoryComp->GetItemBySlot(EP3CharacterItemSlot::RightHand).Id;
	Params.RecoveryAfterTempWeapon_RightItemId = RightRecoveryItem.Id;
	Params.RecoveryAfterTempWeapon_RightItemActor = RightRecoveryItemActor;
	Params.RecoveryAfterTempWeapon_LeftItemId = LeftRecoveryItem.Id;
	Params.RecoveryAfterTempWeapon_LeftItemActor = LeftRecoveryItemActor;

	return true;
}

bool UP3RecoveryAfterTempWeaponCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	if (!ensure(Params.RecoveryAfterTempWeapon_RightItemActor))
	{
		return false;
	}

	UP3HolderComponent* RightHolderComp = Character->GetHolderComponentByHoldType(EP3HoldType::RightHand);
	if (!ensure(RightHolderComp))
	{
		return false;
	}

	UP3HolderComponent* LeftHolderComp = Character->GetHolderComponentByHoldType(EP3HoldType::LeftHand);
	if (!ensure(LeftHolderComp))
	{
		return false;
	}

	return true;
}

void UP3RecoveryAfterTempWeaponCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	EP3CharacterItemSlot CharacterRightItemSlot = FP3ItemUtil::GetCharacterItemSlotFromHoldType(EP3HoldType::RightHand);
	EP3CharacterItemSlot CharacterLeftItemSlot = FP3ItemUtil::GetCharacterItemSlotFromHoldType(EP3HoldType::LeftHand);
	if (!ensure(CharacterRightItemSlot != EP3CharacterItemSlot::Invalid) || !ensure(CharacterLeftItemSlot != EP3CharacterItemSlot::Invalid))
	{
		return;
	}

	UP3HolderComponent* RightHolderComp = Character->GetHolderComponentByHoldType(EP3HoldType::RightHand);
	UP3HolderComponent* LeftHolderComp = Character->GetHolderComponentByHoldType(EP3HoldType::LeftHand);
	if (!ensure(RightHolderComp) || !ensure(LeftHolderComp))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const bool bIsServer = P3Core::IsP3NetModeServerInstance(*Character);
	UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);
	if (bIsServer && !ensure(WorldNet))
	{
		return;
	}

	if (RightHolderComp->GetHoldingActor() == Params.RecoveryAfterTempWeapon_HoldingItemActor)
	{
		Character->RemoveHoldingActorByCommand(*this, RightHolderComp);
	}

	if (bIsServer)
	{
		if (InventoryComp->HasItem(Params.RecoveryAfterTempWeapon_HoldingItemId))
		{
			InventoryComp->Server_RemoveItem(Params.RecoveryAfterTempWeapon_HoldingItemId);
		}

		if (InventoryComp->HasItem(Params.RecoveryAfterTempWeapon_RightItemId))
		{
			InventoryComp->Server_ChangeItemSlot(Params.RecoveryAfterTempWeapon_RightItemId, CharacterRightItemSlot);
			WorldNet->SendUpdateCharacterItemSlot(Character->GetCharacterStoreBP().CharacterId, Params.RecoveryAfterTempWeapon_RightItemId, CharacterRightItemSlot); //-V522
		}

		if (InventoryComp->HasItem(Params.RecoveryAfterTempWeapon_LeftItemId))
		{
			InventoryComp->Server_ChangeItemSlot(Params.RecoveryAfterTempWeapon_LeftItemId, CharacterLeftItemSlot);
			WorldNet->SendUpdateCharacterItemSlot(Character->GetCharacterStoreBP().CharacterId, Params.RecoveryAfterTempWeapon_LeftItemId, CharacterLeftItemSlot); //-V522
		}
	}

	const bool bHold = Character->GetStance() == EP3CharacterStance::Combat;

	if (Params.RecoveryAfterTempWeapon_RightItemActor)
	{
		Character->SetHoldingActorByCommand(*this, RightHolderComp, Params.RecoveryAfterTempWeapon_RightItemActor, bHold);
	}

	if (Params.RecoveryAfterTempWeapon_LeftItemActor)
	{
		Character->SetHoldingActorByCommand(*this, LeftHolderComp, Params.RecoveryAfterTempWeapon_LeftItemActor, bHold);
	}
}

bool UP3SetParameterValueOnMaterialCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	if (!Character->GetMesh())
	{
		return false;
	}

	return true;
}

void UP3SetParameterValueOnMaterialCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	if (!ensure(Character->GetMesh()))
	{
		return;
	}

	Character->GetMesh()->SetScalarParameterValueOnMaterials(Params.ParameterName, Params.ParameterFloat);
}

bool UP3LookAtCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot look at. No character");
		return false;
	}

	return true;
}

void UP3LookAtCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot look at. No character");
		return;
	}

	if (P3Core::IsP3NetModeClientInstance(Actor))
	{
		AP3PlayerController* PlayerController = Cast<AP3PlayerController>(Character->GetController());
		if (PlayerController)
		{
			FRotator Rot = UKismetMathLibrary::FindLookAtRotation(Character->GetActorLocation(), Params.LookAtTargetLocation);
			//PlayerController->LookForward(Rot);
			PlayerController->SetControlRotation(Rot);
		}
	}
}

bool UP3TalkCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot talk. No character");
		return false;
	}

	if (!Params.TalkTargetActor)
	{
		P3JsonLog(Warning, "Cannot talk. No target actor");
		return false;
	}

	return true;
}

void UP3TalkCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot talk. No character");
		return;
	}

	if (!Params.TalkTargetActor)
	{
		P3JsonLog(Warning, "Cannot talk. No target actor");
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(Actor))
	{
		UP3InteractableComponent* InteractableComp = Params.TalkTargetActor->FindComponentByClass<UP3InteractableComponent>();

		if (InteractableComp && InteractableComp->IsInteractionAllowed())
		{
			InteractableComp->Server_OnInteract(Character);
		}
	}
}

bool UP3CableAttachEndCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	if (!Params.CableWeaponActor)
	{
		P3JsonLog(Warning, "No target actor");
		return false;
	}

	return true;
}

void UP3CableAttachEndCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	if (!Params.CableWeaponActor)
	{
		P3JsonLog(Warning, "No target actor");
		return;
	}

	UCableComponent* CableComp = Params.CableWeaponActor->FindComponentByClass<UCableComponent>();
	if (CableComp)
	{
		CableComp->SetAttachEndTo(nullptr, NAME_None);
		CableComp->SetVisibility(false);
	}
}

bool UP3SetCrippledCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot be crippled. No character");
		return false;
	}

	return true;
}

void UP3SetCrippledCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot be crippled. No character");
		return;
	}

	UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
	if (MovementComp)
	{
		MovementComp->SetCrippled(Params.SetCrippled_bCrippled);
	}
}

bool UP3CameraShakeCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	return true;
}

void UP3CameraShakeCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	if (!GIsClient)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot Camera Shake. No character");
		return;
	}

	const FP3CmsCameraShakeRow* CmsCameraShakeRow = P3Cms::GetCameraShake(Params.CmsCameraShakeKey);
	if (!CmsCameraShakeRow)
	{
		return;
	}

	if (CmsCameraShakeRow->bStandaloneLocalPlay)
	{
		if (Params.CameraShakeActor != P3Core::GetLocalPawn(Character->GetWorld()))
		{
			return;
		}
	}

	const float Distance = (Character->GetActorLocation() - Params.CameraShakeLocation).Size();
	Character->Client_PlayCameraShake(Params.CmsCameraShakeKey, Distance);	
}

bool UP3PlayReactionVFXCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	return true;
}

void UP3PlayReactionVFXCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	if (!P3Core::IsP3NetModeClientInstance(Actor))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot Play ReactionVFX. No character");
		return;
	}

	UP3CombatResponseComponent* CombatResponseComp = Character->GetP3CombatResponseoComponent();	
	if (!ensure(CombatResponseComp))
	{
		return;
	}

	const UDataTable* ReactionTable = CombatResponseComp->GetCombatReactionTable(Params.ReactionLayer);
	if (!ensure(ReactionTable))
	{
		return;
	}

	const FP3CombatReactionRow* ReactionRow = ReactionTable->FindRow<FP3CombatReactionRow>(Params.ReactionName, "UP3PlayReactionVFXCommand");
	if (!ensure(ReactionRow))
	{
		return;
	}

	const FFXReaction* FindVFX = ReactionRow->VFX.Find(Params.AttackAttribute);
	if (FindVFX)
	{
		if (FindVFX->HitParticle)
		{
			FRotator Rotator = FindVFX->bImpactRotation ? Params.ReactionImpactDirection.Rotation() : FRotator::ZeroRotator;												
			Rotator += FindVFX->SpawnRotation;

			UGameplayStatics::SpawnEmitterAtLocation(Character->GetWorld(), FindVFX->HitParticle, Params.ReactionHitLocation + FindVFX->SpawnLocationOffset, Rotator, FindVFX->SpawnScale);
		}

		if (FindVFX->HitSound)
		{
			UGameplayStatics::PlaySoundAtLocation(Character->GetWorld(), FindVFX->HitSound, Params.ReactionHitLocation, FindVFX->VolumeMultiplier, FindVFX->PitchMultiplier, FindVFX->StartTimeSeconds);
		}
	}
}

bool UP3SetChangingThrowableCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	const FP3CharacterStore& CharacterStore = Character->GetCharacterStoreBP();
	if (!CharacterStore.bIsAiming)
	{
		return false;
	}

	return true;
}

void UP3SetChangingThrowableCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return;
	}

	FP3CharacterStore CharacterStore = Character->GetCharacterStoreBP();

	CharacterStore.bIsChangingThrowable = Params.SetChangingThrowable_bNewChangingThrowable;

	Character->SetCharacterStoreByCommand(*this, CharacterStore);
}

bool UP3SetStrollCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot Stroll. No character");
		return false;
	}

	return true;
}

void UP3SetStrollCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		P3JsonLog(Warning, "Cannot stroll. No character");
		return;
	}

	UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
	if (MovementComp)
	{
		MovementComp->SetStroll(Params.SetStroll_bStroll);
	}
}

void UP3SetEmoteByNameCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	const FP3CharacterEmoteAnimation* EmoteAnimationResult = Character->FindEmoteByName(Params.SetEmoteByName_EmoteAnimName);
	FP3CharacterStore CharacterStore = Character->GetCharacterStoreBP();

	if (!EmoteAnimationResult)
	{
		// 고의적 None으로 Emote을 초기화하는 코드가 있어 로그는 남기지 않았습니다
		/*P3JsonLog(Error, "Cannot find the RoutineAnimation")*/
		CharacterStore.Emote = FP3CharacterEmoteAnimation{ nullptr, nullptr, nullptr };
		return;
	}

	CharacterStore.Emote = *EmoteAnimationResult;

	Character->SetCharacterStoreByCommand(*this, CharacterStore);
}

void UP3SetInEmoteCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);

	if (!ensure(Character))
	{
		return;
	}

	FP3CharacterStore CharacterStore = Character->GetCharacterStoreBP();
	CharacterStore.bInEmote = Params.SetInEmote_bInEmote;
	Character->SetCharacterStoreByCommand(*this, CharacterStore);
}

bool UP3PickupBackpackCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	AActor* BackpackActor = Params.PickupBackpack_BackpackActor;
	if (!BackpackActor)
	{
		return false;
	}

	return true;
}

void UP3PickupBackpackCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!InventoryComp)
	{
		return;
	}

	AP3Backpack* BackpackActor = Cast<AP3Backpack>(Params.PickupBackpack_BackpackActor);
	if (!BackpackActor)
	{
		P3JsonLog(Error, "BackpackActor doesn't exist");
		return;
	}

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(BackpackActor->GetRootComponent());
	if (PrimComp)
	{
		PrimComp->SetSimulatePhysics(false);
		PrimComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}

	BackpackActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetIncludingScale, Params.PickupBackpack_AttachSocketName);

	InventoryComp->SetBackpackActor(BackpackActor);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		BackpackActor->Server_SetBackpackOwnerID(Character->GetCharacterStoreBP().CharacterId);
	}
}

bool UP3PutdownBackpackCommand::CanExecute(AActor& Actor, const FP3CommandRequestParams& Params) const
{
	if (!Super::CanExecute(Actor, Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return false;
	}

	AActor* BackpackActor = Params.PutdownBackpack_BackpackActor;
	if (!BackpackActor)
	{
		return false;
	}

	return true;
}

void UP3PutdownBackpackCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!Character)
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!InventoryComp)
	{
		return;
	}

	AActor* BackpackActor = Params.PutdownBackpack_BackpackActor;
	if (!BackpackActor)
	{
		P3JsonLog(Error, "Carrying BackpackActor doesn't exist");
		return;
	}

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(BackpackActor->GetRootComponent());
	if (PrimComp)
	{
		PrimComp->SetSimulatePhysics(true);
		PrimComp->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	}

	BackpackActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

	InventoryComp->SetBackpackActor(nullptr);
}

void UP3PlayCombatResponseHitCommand::Multicast_Execute(AActor& Actor, const FP3CommandRequestParams& Params)
{
	Super::Multicast_Execute(Actor, Params);

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (!ensure(Character))
	{
		return;
	}

	UP3CombatResponseComponent* CombatResponseComp = Character->GetP3CombatResponseoComponent();
	if (!ensure(CombatResponseComp))
	{
		return;
	}

	FP3RequestResponseParams RequestResponseParams;

	RequestResponseParams.AttackerActor = Params.PlayCombatResponseHit_AttackerActor;
	RequestResponseParams.AttackerActorID = Params.PlayCombatResponseHit_AttackerActorID;
	RequestResponseParams.ReactionName = Params.PlayCombatResponseHit_ReactionName;
	RequestResponseParams.Layer = Params.PlayCombatResponseHit_Layer;
	RequestResponseParams.TargetTransform = Params.PlayCombatResponseHit_TargetTransform;
	RequestResponseParams.HitLocation = Params.PlayCombatResponseHit_HitLocation;
	RequestResponseParams.HitBoneName = Params.PlayCombatResponseHit_HitBoneName;
	RequestResponseParams.bIsFrameHold = Params.PlayCombatResponseHit_bIsFrameHold;

	CombatResponseComp->StartReaction(RequestResponseParams);
}
