// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CommandComponent.h"
#include "P3Core.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3World.h"
#include "P3WorldNetCore.h"

#undef CommandJsonLog
#define CommandJsonLog(Verbosity, Subject, ...) \
	P3JsonLog(Verbosity, Subject,	\
		TEXT("Pawn"), (GetOwner() ? GetOwner()->GetName() : TEXT("NULL")),	\
		TEXT("Role"), EnumToStringShort(ENetRole, GetOwnerRole()),	\
		##__VA_ARGS__)


static void _UpdatePointerFromId(FP3CommandRequestParams& Params, const UObject& WorldContextObject)
{
	UStruct* ParamStruct = FP3CommandRequestParams::StaticStruct();
	UField* Field = ParamStruct->Children;
	while (Field)
	{
		UStructProperty* StructProperty = Cast<UStructProperty>(Field);
		if (StructProperty && StructProperty->Struct == FP3ActorPointerAndId::StaticStruct())
		{
			FP3ActorPointerAndId* P3ActorPointerAndId = StructProperty->ContainerPtrToValuePtr<FP3ActorPointerAndId>(&Params);
			if (ensure(P3ActorPointerAndId) && P3ActorPointerAndId->ActorId != INVALID_ACTORID)
			{
				P3ActorPointerAndId->UpdatePointerFromId(WorldContextObject);
			}
		}

		Field = Field->Next;
	}
}


UP3CommandComponent::UP3CommandComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3CommandComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UP3CommandComponent::RequestCommand(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params)
{
	if (!ensure(CommandClass.Get()))
	{
		CommandJsonLog(Error, "Request command failed. No command class");
		return;
	}

	AActor* OwnerActor = GetOwner();
	if (!ensure(OwnerActor))
	{
		CommandJsonLog(Error, "Request command failed. No owner actor");
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_ExecuteCommand(CommandClass, Params);
	}
	else if (IsAutonomousProxy(OwnerActor))
	{
		if (P3Core::IsConnectedToDedi(this))
		{
			const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(OwnerActor);
			ensure(ActorId != INVALID_ACTORID);

			FP3NetCommandParams NetParams;
			NetParams.CommandClassName = CommandClass->GetPathName();
			NetParams.RequestParams = Params;

			P3Core::GetP3World(*this)->Client_SendPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Command, &UP3CommandComponent::Server_HandleRequestCommand);
		}
	}
	else
	{
		ensure(0);
		CommandJsonLog(Error, "Request command failed. Neither authority nor autonomous");
		return;
	}

}

void UP3CommandComponent::Server_HandleRequestCommand(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetCommandParams NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		TSubclassOf<class UP3Command> CommandClass = StaticLoadClass(UP3Command::StaticClass(), NULL, *NetParams.CommandClassName);

		Server_HandleRequestCommandInternal(CommandClass, NetParams.RequestParams);
	}
}

void UP3CommandComponent::Client_HandleExecuteCommand(const FP3DediToClientHandlerParams& Params)
{
	FP3NetCommandParams NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		TSubclassOf<class UP3Command> CommandClass = StaticLoadClass(UP3Command::StaticClass(), NULL, *NetParams.CommandClassName);

		MulticastExecuteCommand(CommandClass, NetParams.RequestParams);
	}
}

void UP3CommandComponent::Server_HandleRequestCommandInternal(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params)
{
	FP3CommandRequestParams CopiedParams = Params;
	_UpdatePointerFromId(CopiedParams, *this);

	const bool bSucceeded = Server_ExecuteCommand(CommandClass, CopiedParams);
}

struct FActorGatherer : public FArchive
{
public:
	virtual FArchive& operator<<(UObject*& Value)
	{
		AActor* Actor = Cast<AActor>(Value);
		if (Actor)
		{
			Actors.Add(Actor);
		}

		return *this;
	}

	TArray<TWeakObjectPtr<AActor>> Actors;
};

static bool _HasVaildActorPointer(FP3CommandRequestParams& Params, const UObject& WorldContextObject)
{
	UStruct* ParamStruct = FP3CommandRequestParams::StaticStruct();
	UField* Field = ParamStruct->Children;
	while (Field)
	{
		UStructProperty* StructProperty = Cast<UStructProperty>(Field);
		if (StructProperty && StructProperty->Struct == FP3ActorPointerAndId::StaticStruct())
		{
			FP3ActorPointerAndId* P3ActorPointerAndId = StructProperty->ContainerPtrToValuePtr<FP3ActorPointerAndId>(&Params);
			if (P3ActorPointerAndId->IsValidId())
			{
				return true;
			}
		}

		Field = Field->Next;
	}

	return false;
}

bool UP3CommandComponent::Server_ExecuteCommand(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (!ensure(CommandClass))
	{
		CommandJsonLog(Error, "Request command failed. No command class");
		return false;
	}

	AActor* OwnerActor = GetOwner();

	if (!ensure(OwnerActor))
	{
		CommandJsonLog(Error, "Request command failed. No owner actor");
		return false;
	}

	UP3Command* Command = Cast<UP3Command>(CommandClass->ClassDefaultObject);

	if (!ensure(Command))
	{
		CommandJsonLog(Error, "Request command failed. No command");
		return false;
	}

	if (!Command->CanExecute(*OwnerActor, Params))
	{
		CommandJsonLog(Warning, "Request command failed. Can't execute");
		return false;
	}


	UP3World* World = P3Core::GetP3World(*this);
	if (World)
	{
		const actorid ActorId = World->GetActorIdFromActor(OwnerActor);
		ensure(ActorId != INVALID_ACTORID);

		// .. Maybe this is bad choice, 
		// Since Params may contain actor which client might not replicated yet
		// We need to flush actor replications
		FActorGatherer ActorGatherer;
		FP3CommandRequestParams TempCopiedParams = Params;
		FP3CommandRequestParams::StaticStruct()->SerializeBin(ActorGatherer, &TempCopiedParams);

		if (ActorGatherer.Actors.Num() > 0 || _HasVaildActorPointer(TempCopiedParams, *this))
		{
			UP3ServerWorld* ServerWorld = World->GetServerWorld();
			ServerWorld->SyncActors();
		}

		FP3NetCommandParams NetParams;
		NetParams.CommandClassName = CommandClass->GetPathName();
		NetParams.RequestParams = Params;

		World->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Command, &UP3CommandComponent::Client_HandleExecuteCommand);

		MulticastExecuteCommand(CommandClass, Params);
	}

	return true;
}

void UP3CommandComponent::MulticastExecuteCommand(TSubclassOf<class UP3Command> CommandClass, const FP3CommandRequestParams& Params)
{
	if (!ensure(CommandClass))
	{
		CommandJsonLog(Error, "Execute command failed. No command class");
		return;
	}

	AActor* OwnerActor = GetOwner();

	if (!ensure(OwnerActor))
	{
		CommandJsonLog(Error, "Execute command failed. No owner actor");
		return;
	}

	UP3Command* Command = Cast<UP3Command>(CommandClass->ClassDefaultObject);

	if (!ensure(Command))
	{
		CommandJsonLog(Error, "Execute command failed. No command");
		return;
	}

	FP3CommandRequestParams CopiedParams = Params;
	_UpdatePointerFromId(CopiedParams, *this);

	Command->Multicast_Execute(*OwnerActor, CopiedParams);
}

