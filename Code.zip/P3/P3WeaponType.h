// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3WeaponType.generated.h"

UENUM(Blueprintable)
enum class EP3WeaponType : uint8
{
	None,
	WeaponMasterStart UMETA(Hidden),
	SwordAndShield,
	Bow,
	GreatSword,
	Gun,
	Lance,
	WeaponMasterEnd UMETA(Hidden),
	ElementalistStart UMETA(Hidden),
	Staff,
	ElementalistEnd UMETA(Hidden),
	TempStart UMETA(Hidden),
	Temp_Staff,
	Temp_Spear,
	Temp_Javlin,
	Temp_JavlinCable,
	Temp_Torch,
	Temp_DevTest1,
	Temp_DevTest2,
	Temp_DevTest3,
	TempEnd UMETA(Hidden),
	Count UMETA(Hidden),
};

static bool IsRangedWeapon(EP3WeaponType WeaponType)
{ 
	return WeaponType == EP3WeaponType::Gun
		|| WeaponType == EP3WeaponType::Bow
		|| WeaponType == EP3WeaponType::Staff
		|| WeaponType == EP3WeaponType::Temp_Staff
		|| WeaponType == EP3WeaponType::Temp_Spear
		|| WeaponType == EP3WeaponType::Temp_Javlin
		|| WeaponType == EP3WeaponType::Temp_JavlinCable
		|| WeaponType == EP3WeaponType::Temp_Torch
		|| WeaponType == EP3WeaponType::Temp_DevTest1
		|| WeaponType == EP3WeaponType::Temp_DevTest2
		|| WeaponType == EP3WeaponType::Temp_DevTest3;
}

static bool IsShieldWeapon(EP3WeaponType WeaponType)
{ 
	return WeaponType == EP3WeaponType::SwordAndShield
		|| WeaponType == EP3WeaponType::GreatSword
		|| WeaponType == EP3WeaponType::Temp_Javlin;
}

static bool IsCounterAttackWeapon(EP3WeaponType WeaponType)
{ 
	return WeaponType == EP3WeaponType::SwordAndShield
		|| WeaponType == EP3WeaponType::GreatSword; 
}

static bool IsLargeTargetCounterAttackWeapon(EP3WeaponType WeaponType) 
{
	return WeaponType == EP3WeaponType::GreatSword; 
}

static bool IsWeaponMasterWeapon(EP3WeaponType WeaponType)
{
	return (int32)WeaponType > (int32)EP3WeaponType::WeaponMasterStart
		&& (int32)WeaponType < (int32)EP3WeaponType::WeaponMasterEnd;
}

static bool IsElementalistWeapon(EP3WeaponType WeaponType)
{
	return (int32)WeaponType > (int32)EP3WeaponType::ElementalistStart
		&& (int32)WeaponType < (int32)EP3WeaponType::ElementalistEnd;
}

static bool IsTempWeapon(EP3WeaponType WeaponType) 
{ 
	return (int32)WeaponType > (int32)EP3WeaponType::TempStart 
		&& (int32)WeaponType < (int32)EP3WeaponType::TempEnd; 
}
