// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Serialization/BitWriter.h"
#include "Serialization/BitReader.h"

struct FP3StoreBitWriter : public FBitWriter
{
	FP3StoreBitWriter(class UP3World* InWorld, int64 InMaxBits, bool AllowResize = false);

	virtual FArchive& operator<<(FName& Value) override;
	virtual FArchive& operator<<(UObject*& Value) override;
	virtual FArchive& operator<<(struct FWeakObjectPtr& Value) override;

private:
	class UP3World* World = nullptr;
};

struct FP3StoreBitReader : public FBitReader
{
	FP3StoreBitReader(class UP3World* InWorld, uint8* Src = nullptr, int64 CountBits = 0);

	virtual FArchive& operator<<(FName& Value) override;
	virtual FArchive& operator<<(UObject*& Value) override;
	virtual FArchive& operator<<(struct FWeakObjectPtr& Value) override;

private:
	class UP3World* World = nullptr;
};

/** 
 * FP3ActorIdWriter
 * useful when you need referenced actor id list
 */
class FP3ActorIdWriter : public FArchive
{
public:
	virtual FArchive& operator<<(UObject*& Value) override;

private:
	TArray<int64> ActorIds;
};
