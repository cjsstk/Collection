// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3ContributionSystem.h"

#include "P3Character.h"
#include "P3Core.h"
#include "P3ServerWorld.h"
#include "P3World.h"

void AP3ContributionSystem::Server_Reset()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Net_Players.Empty();
}

void AP3ContributionSystem::Server_AddPoint(const AP3Character* Character, EP3ContributionType ContributionType, int32 Point)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(Character))
	{
		return;
	}

	FP3PlayerContribution& Player = FindOrAddPlayer(*Character);

	int32& CurrentPoints = Player.Points.FindOrAdd(ContributionType);

	CurrentPoints += Point;

	Server_bIsDirty = true;
}

void AP3ContributionSystem::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (P3Core::IsP3NetModeServerInstance(*this) && Server_bIsDirty)
	{
		Server_SetDirty(*this);
	}
}

void AP3ContributionSystem::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	Archive << Net_Players;
}

FP3PlayerContribution& AP3ContributionSystem::FindOrAddPlayer(const AP3Character& Character)
{
	UP3World* P3World = P3Core::GetP3World(*this);

	const charid CharacterId = Character.GetCharacterStoreBP().CharacterId;

	for (FP3PlayerContribution& Player : Net_Players)
	{
		if (Player.CharacterId == CharacterId)
		{
			return Player;
		}
	}

	FP3PlayerContribution& NewPlayer = Net_Players.AddDefaulted_GetRef();
	NewPlayer.CharacterId = CharacterId;
	NewPlayer.PlayerName = Character.GetCharacterStoreBP().DisplayName;

	return NewPlayer;
}

void P3Contribution::Server_AddPoint(const AP3Character* Character, EP3ContributionType ContributionType, int32 Point)
{
	if (!Character)
	{
		return;
	}

	AP3ContributionSystem* System = P3Core::GetContributionSystem(*Character);

	if (!ensure(System))
	{
		return;
	}

	System->Server_AddPoint(Character, ContributionType, Point);
}
