// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3ContributionSystem.generated.h"

UENUM(Blueprintable)
enum class EP3ContributionType : uint8
{
	DamageEnemy,
	DamageAlly,
	DamageToBoss,
	HealAlly,
	HealByConsumption,
	Rescue,
	Down,
	Dead
};

USTRUCT(Blueprintable)
struct FP3PlayerContribution
{
	GENERATED_BODY()

	charid CharacterId = INVALID_CHARID;

	UPROPERTY(BlueprintReadOnly)
	FText PlayerName;

	UPROPERTY(BlueprintReadOnly)
	TMap<EP3ContributionType, int32> Points;

	friend FArchive& operator<<(FArchive& Ar, FP3PlayerContribution& A)
	{
		FP3PlayerContribution::StaticStruct()->SerializeBin(Ar, &A);

		return Ar;
	}
};

/**
 * Contribution system
 * Point each action of players
 */
UCLASS(Blueprintable)
class P3_API AP3ContributionSystem : public AP3Actor
{
	GENERATED_BODY()

public:
	void Server_Reset();
	void Server_AddPoint(const class AP3Character* Character, EP3ContributionType ContributionType, int32 Point);

	UFUNCTION(BlueprintCallable)
	const TArray<FP3PlayerContribution>& GetPlayers() const { return Net_Players; }

protected:
	virtual void Tick(float DeltaTime) override;
	virtual void NetSerialize(FArchive& Archive) override;

private:
	FP3PlayerContribution& FindOrAddPlayer(const class AP3Character& Character);

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	TArray<FP3PlayerContribution> Net_Players;

	bool Server_bIsDirty = false;
};

namespace P3Contribution
{
	void Server_AddPoint(const class AP3Character* Character, EP3ContributionType ContributionType, int32 Point);
}
