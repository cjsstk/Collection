// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3World.h"

#include "Components/BrushComponent.h"
#include "DrawDebugHelpers.h"
#include "Engine/Canvas.h"
#include "Engine/Engine.h"
#include "Engine/LevelStreaming.h"
#include "Engine/LocalPlayer.h"
#include "Engine/NetConnection.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/GameStateBase.h"
#include "GameFramework/HUD.h"
#include "Kismet/GameplayStatics.h"
#include "LevelSequence.h"
#include "LevelSequenceActor.h"
#include "Tickable.h"

#include "KiteDemo/FlockManager.h"
#include "Network/P3AuthNet.h"
#include "Network/P3DediNet.h"
#include "Network/P3PlayerNet.h"
#include "Network/P3UnrealUDPNet.h"
#include "P3Actor.h"
#include "P3ActorInterface.h"
#include "P3AnimalCharacter.h"
#include "P3Character.h"
#include "P3ClientWorld.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3GameState.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3StoreInterface.h"
#include "P3TimeOfDaySettings.h"
#include "P3QuestVolume.h"
#include "World/P3ZoneVolume.h"
#include "World/P3WorldSystem.h"


extern TAutoConsoleVariable<int32> CVarP3CharacterMovementServerDriven;
extern TAutoConsoleVariable<int32> CVarP3WorldDebugTransform;
extern TAutoConsoleVariable<int32> CVarP3ZoneDebug;
extern TAutoConsoleVariable<int32> CVarP3CombatShowSwingHitParticle;

TAutoConsoleVariable<int32> CVarP3WorldDebug(
	TEXT("p3.worldDebug"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3WorldDebugPacket(
	TEXT("p3.worldDebugPacket"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3WorldPacketProfile(
	TEXT("p3.worldPacketProfile"),
	0,
	TEXT("Display P3 World packet profile. 0: off. 1: on"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3UnrealNetModeDebug(
	TEXT("p3.unrealNetModeDebug"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3LevelStreamingDebug(
	TEXT("p3.levelStreamingDebug"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Default);

/** 
 * Which actor classes are we interested in?
 */
bool _IsP3ActorClass(const AActor& Actor)
{
	UClass* P3ActorClasses[] = {
		AP3Actor::StaticClass(),
		AP3Character::StaticClass(),
		AP3AnimalCharacter::StaticClass()
	};

	for (int32 Index = 0; Index < ARRAY_COUNT(P3ActorClasses); ++Index)
	{
		if (Actor.IsA(P3ActorClasses[Index]))
		{
			return true;
		}
	}

	return false;
}

static bool _IsLocalCharacter(const AActor& Actor)
{
	if (!ensure(Actor.GetWorld()))
	{
		return false;
	}

 	ULocalPlayer* LocalPlayer = Actor.GetWorld()->GetFirstLocalPlayerFromController();

	if (!LocalPlayer)
	{
		return false;
	}

	APlayerController* PlayerController = LocalPlayer->GetPlayerController(Actor.GetWorld());

	if (!PlayerController)
	{
		return false;
	}

	return PlayerController->GetPawn() == &Actor;
}



//////////////////////////////////////////////////////////////////////////
// FP3WorldTick
//////////////////////////////////////////////////////////////////////////

class FP3WorldTick : FTickableGameObject
{
public:
	explicit FP3WorldTick(UP3World* InWorld) :
		FTickableGameObject(),
		World(InWorld)
	{}

	virtual void Tick(float DeltaTime) override
	{
		World->Tick(DeltaTime);
	}

	virtual bool IsTickable() const override { return true; }
	virtual bool IsTickableWhenPaused() const override { return true; }
	virtual bool IsTickableInEditor() const override { return false; }

	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FP3WorldTick, STATGROUP_Tickables);
	}

private:
	UP3World* World;
};


UP3World::UP3World()
{
	
}

UP3World::~UP3World()
{
	ensure(!WorldTick);
}

void UP3World::Initialize(class UP3GameInstance* InGameInstance)
{
	ensure(!GameInstance);
	GameInstance = InGameInstance;

	WorldTick = new FP3WorldTick(this);

	GEngine->OnWorldDestroyed().AddUObject(this, &UP3World::OnWorldDestroyed);

	FCoreUObjectDelegates::PreLoadMap.AddUObject(this, &UP3World::OnPreLoadMap);
	FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UP3World::OnPostLoadMapWithWorld);
	AHUD::OnHUDPostRender.AddUObject(this, &UP3World::OnHUDPostRender);

	ConsoleCommandDump = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("p3.worldDump"),
		TEXT("Dump actors"),
		FConsoleCommandWithArgsDelegate::CreateUObject(this, &UP3World::OnDumpConsoleCommand),
		ECVF_Cheat
	);
}

void UP3World::Shutdown()
{
	if (Client_World)
	{
		Client_World->Shutdown();
	}

	if (Server_World)
	{
		Server_World->Shutdown();
	}

	if (Net_WorldSystem)
	{
		Net_WorldSystem->Destroy();
	}

	delete WorldTick;
	WorldTick = nullptr;

	FWorldDelegates::LevelAddedToWorld.RemoveAll(this);
	FWorldDelegates::LevelRemovedFromWorld.RemoveAll(this);

	GEngine->OnWorldDestroyed().RemoveAll(this);

	FCoreUObjectDelegates::PreLoadMap.RemoveAll(this);
	FCoreUObjectDelegates::PostLoadMapWithWorld.RemoveAll(this);
	AHUD::OnHUDPostRender.RemoveAll(this);

	IConsoleManager::Get().UnregisterConsoleObject(ConsoleCommandDump);
}

void UP3World::BeginPlay(UWorld* InWorld)
{
	if (!ensure(InWorld))
	{
		return;
	}

	P3JsonWorldLog(Display, "Begin Play", TEXT("World"), InWorld->GetName());

	ensure(Actors.Num() == 0);
	ensure(InWorld->GetAuthGameMode());

	World = InWorld;

	Debug_NetMode = P3Core::GetP3NetMode(*World);

	const bool bIsServerInstance = P3Core::IsP3NetModeServerInstance(*World);
	const bool bIsClientInstance = P3Core::IsP3NetModeClientInstance(*World);

	Server_World = nullptr;
	Client_World = nullptr;

	if (bIsServerInstance)
	{
		Server_World = NewObject<UP3ServerWorld>(this);
		Server_World->BeginPlay(this);
	}

	if (bIsClientInstance)
	{
		Client_World = NewObject<UP3ClientWorld>(this);
		Client_World->BeginPlay(this);
	}

	if (bIsClientInstance)
	{
		if (!Client_LevelAddedToWorldDelegateHandle.IsValid())
		{
			Client_LevelAddedToWorldDelegateHandle =  FWorldDelegates::LevelAddedToWorld.AddUObject(this, &UP3World::Client_OnLevelAddedToWorld);
		}
	}

	if (bIsServerInstance)
	{
		FWorldDelegates::LevelAddedToWorld.AddUObject(this, &UP3World::Server_OnLevelAddedToWorld);
		FWorldDelegates::LevelRemovedFromWorld.AddUObject(this, &UP3World::Server_OnLevelRemovedFromWorld);

		for (auto&& Iter(World->GetLevelIterator()); Iter; ++Iter)
		{
			ULevel* Level = *Iter;

			// Since Server_AddActor might spawn actors, we need copy of actor list
			TArray<TWeakObjectPtr<AActor>> LevelActors;

			for (AActor* Actor : Level->Actors)
			{
				LevelActors.Add(Actor);
			}

			for (TWeakObjectPtr<AActor> ActorPtr : LevelActors)
			{
				Server_AddActor(ActorPtr.Get());
			}
		}

		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		Net_WorldSystem = GetWorld()->SpawnActor<AP3WorldSystem>(SpawnParams);
	}

	for (TActorIterator<AP3TimeOfDaySettings> Iter(GetWorld()); Iter; ++Iter)
	{
		AP3TimeOfDaySettings* Settings = *Iter;
		TimeOfDay.TimeOfDayInSeconds = Settings->DefaultHour * 3600;
		TimeOfDay.GameTimeToTimeOfDayRatio = Settings->Speed;
	}
}

void UP3World::RegisterActor(AActor& Actor)
{
	ensure(_IsP3ActorClass(Actor));

	if (Server_World)
	{
		Server_AddActor(&Actor);
	}
}

void UP3World::Tick(float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3World_Tick"), STAT_P3World_Tick, STATGROUP_P3);

	if (Server_World)
	{
		Server_World->Tick(DeltaSeconds);
	}

	if (Client_World)
	{
		Client_World->Tick(DeltaSeconds);
	}

	if (World)
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			Server_Tick(DeltaSeconds);
		}
	}

	TickUnrealNetModeDebug(DeltaSeconds);

	TimeOfDay.TimeOfDayInSeconds += DeltaSeconds * TimeOfDay.GameTimeToTimeOfDayRatio;
}

void UP3World::Server_Tick(float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3World_Server_Tick"), STAT_P3World_Server_Tick, STATGROUP_P3);

	ensure(P3Core::IsP3NetModeServerInstance(*this));

	// Tick begin play
	{
		TArray<AActor*> BeginPlayQueue;
		BeginPlayQueue = MoveTemp(Server_BeginPlayQueue);
		ensure(Server_BeginPlayQueue.Num() == 0);

		for (AActor* Actor : BeginPlayQueue)
		{
			if (!Actor)
			{
				continue;
			}

			for (UActorComponent* Comp : Actor->GetComponents())
			{
				IP3ComponentInterface* StoreInterface = Cast<IP3ComponentInterface>(Comp);
				if (StoreInterface)
				{
					StoreInterface->Server_BeginPlayP3World();
				}
			}
		}
	}
}

void UP3World::TickUnrealNetModeDebug(float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3World_TickUnrealNetModeDebug"), STAT_P3World_TickUnrealNetModeDebug, STATGROUP_P3);

	if (CVarP3UnrealNetModeDebug.GetValueOnGameThread() == 0)
	{
		return;
	}

	NetModeDebugPrintTimeSeconds -= DeltaSeconds;

	if (NetModeDebugPrintTimeSeconds > 0.0f)
	{
		return;
	}

	check(GameInstance);

	FString GameInstanceName = GameInstance->GetName();
	FString UnrealNetModeStr = GetWorld() ? P3Core::GetNetModeStr(GetWorld()->GetNetMode()) : TEXT("No World");
	int32 UnrealPlayerNum = (GetWorld() && GetWorld()->GetGameState()) ? GetWorld()->GetGameState()->PlayerArray.Num() : 0;
	FString P3NetModeStr = P3Core::GetNetModeStr(GetP3NetMode());
	int32 P3PlayerNum = GameInstance->GetPlayerNet() ? GameInstance->GetPlayerNet()->GetPlayerCount() : 0;
	FString Message = FString::Printf(TEXT("%s %s(%d) %s(%d)"), *GameInstanceName, *UnrealNetModeStr, UnrealPlayerNum, *P3NetModeStr, P3PlayerNum);

	GEngine->AddOnScreenDebugMessage(INDEX_NONE, 2.9f, FColor::White, Message);

	NetModeDebugPrintTimeSeconds = 3.0f;
}

void UP3World::Server_SendToastMessage(const AActor& Actor, const FText& Message)
{
	if (ensure(Server_World))
	{
		Server_World->SendToastMessage(Actor, Message);
	}
}

void UP3World::Server_SendToastMessageToAll(const FText& Message)
{
	if (ensure(Server_World))
	{
		Server_World->SendToastMessageToAll(Message);
	}
}

AActor* UP3World::GetActorFromActorId(actorid ActorId) const
{
	AActor*const* Actor = Actors.Find(ActorId);

	if (Actor)
	{
		return *Actor;
	}

	return nullptr;
}

actorid UP3World::GetActorIdFromActor(const AActor* Actor) const
{
	if (!Actor)
	{
		return INVALID_ACTORID;
	}

	const IP3ActorInterface* P3ActorInterface = Cast<const IP3ActorInterface>(Actor);
	if (P3ActorInterface)
	{
		return P3ActorInterface->GetActorId();
	}

	for (auto&& Iter : Actors)
	{
		if (Iter.Value == Actor)
		{
			return Iter.Key;
		}
	}

	return INVALID_ACTORID;
}

class UP3ClientWorld* UP3World::GetClientWorld() const
{
	return Client_World;
}

class UP3ServerWorld* UP3World::GetServerWorld() const
{
	return Server_World;
}

void UP3World::Client_HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	if (ensure(Client_World))
	{
		Client_World->HandlePacketBuffer(NetConnInfo, ActorId, Actor, Buffer, Header);
	}
}

void UP3World::Server_HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (ensure(Server_World))
	{
		Server_World->HandlePacketBuffer(NetConnInfo, ActorId, Actor, Buffer, Header);
	}
}

void UP3World::OnDumpConsoleCommand(const TArray<FString>& Args)
{
	UE_LOG(P3Log, Display, TEXT("-------------------------------------------------------------------"));
	UE_LOG(P3Log, Display, TEXT(" Dump P3 World Actors"));
	UE_LOG(P3Log, Display, TEXT("  Num Actors: %d"), Actors.Num());
	UE_LOG(P3Log, Display, TEXT("-------------------------------------------------------------------"));

	for (auto&& Iter : Actors)
	{
		const int64 ActorId = Iter.Key;
		AActor* Actor = Iter.Value;

		UE_LOG(P3Log, Display, TEXT("Id: %ld,\t Name: %s,\t Class: %s,\t Location: (%.2f, %.2f, %.2f)"),
			ActorId,
			Actor ? *Actor->GetName() : TEXT("NULL"),
			Actor ? *Actor->GetClass()->GetName() : TEXT("NULL"),
			Actor ? Actor->GetActorLocation().X : 0.0f,
			Actor ? Actor->GetActorLocation().Y : 0.0f,
			Actor ? Actor->GetActorLocation().Z : 0.0f
		);
	}
}

void UP3World::Server_FireScareFlockEvent(const FVector& Location, float Radius, float DurationSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (AFlockManager* FlockManager : Server_FlockManagers)
	{
		if (FlockManager)
		{
			FlockManager->AddScareFlockEvent(Location, Radius, DurationSeconds);
		}
	}
}

void UP3World::Server_DamageFoliage(AActor& FoliageActor, UPrimitiveComponent& Component, int32 ItemIndex)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	FP3NetDamageFoliage NetDamageFoliage;
	NetDamageFoliage.LevelName = FoliageActor.GetLevel()->GetOuter()->GetName();
	NetDamageFoliage.ActorName = FoliageActor.GetName();
	NetDamageFoliage.ComponentName = Component.GetName();
	NetDamageFoliage.ItemIndex = ItemIndex;

	Server_MulticastPacketReliable((UP3ClientWorld*)(nullptr), INVALID_ACTORID, &FoliageActor, NetDamageFoliage, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleDamageFoliage);

	FPointDamageEvent PointDamageEvent;
	PointDamageEvent.Damage = 1;
	PointDamageEvent.HitInfo.Component = &Component;
	PointDamageEvent.HitInfo.Item = ItemIndex;
	FoliageActor.TakeDamage(1, PointDamageEvent, nullptr, nullptr);
}

void UP3World::Server_DamageNonCommandActor(AActor& TargetActor, AActor& SourceActor, int32 DamageAmount, UPrimitiveComponent* TargetComponent, int32 HitItemIndex, const FVector* HitLocation)
{
	if (CVarP3CombatShowSwingHitParticle.GetValueOnGameThread() != 2)
	{
		return;
	}

	FP3NetDamageNonCommandActor NetDamage;
	NetDamage.TargetActor = &TargetActor;
	NetDamage.SourceActor = &SourceActor;
	NetDamage.DamageAmount = DamageAmount;
	NetDamage.TargetComponent = TargetComponent;
	NetDamage.HitItemIndex = HitItemIndex;
	
	if (HitLocation)
	{
		NetDamage.bHasHitLocation = true;
		NetDamage.HitLocation = *HitLocation;
	}

	const actorid TargetActorId = GetActorIdFromActor(&TargetActor);

	if (TargetActorId != INVALID_ACTORID)
	{
		Server_MulticastPacketReliable((UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetDamage, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleDamageNonCommandActor);
	}

	Multicast_DamageNonCommandActor(NetDamage);
}

void UP3World::RegisterZoneVolume(const class AP3ZoneVolume* ZoneVolume)
{
	ZoneVolumes.AddUnique(ZoneVolume);
}

void UP3World::UnregisterZoneVolume(const class AP3ZoneVolume* ZoneVolume)
{
	ZoneVolumes.Remove(ZoneVolume);
}

FName UP3World::GetZoneFromLocation(const FVector& Location) const
{
	FName ZoneName = NAME_None;

	for (const AP3ZoneVolume* ZoneVolume : ZoneVolumes)
	{
		if (!ZoneVolume)
		{
			continue;
		}

#if WITH_PHYSX
		FVector ClosestPoint;
		float DistanceSqr;

		if (ZoneVolume->GetBrushComponent()->GetSquaredDistanceToCollision(Location, DistanceSqr, ClosestPoint))
		{
			if (DistanceSqr == 0.0f)
			{
				if (CVarP3ZoneDebug.GetValueOnGameThread() > 0)
				{
					ZoneName = ZoneVolume->GetZoneName();
				}
				else
				{
					return ZoneVolume->GetZoneName();
				}
			}
			else
			{
				if (CVarP3ZoneDebug.GetValueOnGameThread() > 0)
				{
					DrawDebugSphere(GetWorld(), ClosestPoint, 200.0f, 32, FColor::Green);
					DrawDebugLine(GetWorld(), Location, ClosestPoint, FColor::Green);
					DrawDebugString(GetWorld(), ClosestPoint,
						FString::Printf(TEXT("%s: %.0f"), *ZoneVolume->GetZoneName().ToString(), FMath::Sqrt(DistanceSqr)), nullptr, FColor::White, 0.0f);
				}
			}
		}
#else
		const bool bEncompass = ZoneVolume->EncompassesPoint(Location);
		if (bEncompass)
		{
			return ZoneVolume->GetZoneName();
		}
#endif
	}

	return ZoneName;
}

void UP3World::RegisterQuestVolume(const class AP3QuestVolume* QuestVolume)
{
	QuestVolumes.AddUnique(QuestVolume);
}

void UP3World::UnregisterQuestVolume(const class AP3QuestVolume* QuestVolume)
{
	QuestVolumes.Remove(QuestVolume);
}

const class AP3QuestVolume* UP3World::GetQuestVolume(const struct FGameplayTagContainer& GameplayTagsAll) const
{
	for (const AP3QuestVolume* QuestVolume : QuestVolumes)
	{
		if (!QuestVolume)
		{
			continue;
		}

		if (QuestVolume->HasAllMatchingGameplayTags(GameplayTagsAll))
		{
			return QuestVolume;
		}
	}

	return nullptr;
}

void UP3World::RegisterQuestActor(class AP3Actor* Actor)
{
	QuestActors.AddUnique(Actor);
}

void UP3World::UnregisterQuestActor(class AP3Actor* Actor)
{
	QuestActors.Remove(Actor);
}

class AP3Actor* UP3World::GetQuestActor(const struct FGameplayTagContainer& GameplayTagsAll) const
{
	for (AP3Actor* Actor : QuestActors)
	{
		if (!Actor)
		{
			continue;
		}

		if (Actor->HasAllMatchingGameplayTags(GameplayTagsAll))
		{
			return Actor;
		}
	}

	return nullptr;
}

void UP3World::AddSequencePlayer(class ULevelSequencePlayer* Player)
{
	SequencePlayers.AddUnique(Player);
}

void UP3World::RemoveSequencePlayer(class ULevelSequencePlayer* Player)
{
	SequencePlayers.Remove(Player);
}

static bool _IsSequencePossessedObject(ULevelSequencePlayer* Player, const UObject& Object)
{
	if (!Player)
	{
		return false;
	}

	ULevelSequence* LevelSequence = Cast<ULevelSequence>(Player->GetSequence());
	if (!LevelSequence)
	{
		return false;
	}

	UMovieScene* MovieScene = LevelSequence->GetMovieScene();
	if (!MovieScene)
	{
		return false;
	}

	const int32 NumPossessable = MovieScene->GetPossessableCount();
	for (int32 PossessableIndex = 0; PossessableIndex < NumPossessable; ++PossessableIndex)
	{
		const FMovieScenePossessable& Possessable = MovieScene->GetPossessable(PossessableIndex);

		TArray<UObject*, TInlineAllocator<1>> Objects;
		LevelSequence->LocateBoundObjects(Possessable.GetGuid(), Player, Objects);

		if (Objects.Contains(&Object))
		{
			return true;
		}
	}

	return false;
}

bool UP3World::IsSequencePossessedObject(const UObject& Object) const
{
	for (ULevelSequencePlayer* Player : SequencePlayers)
	{
		if (_IsSequencePossessedObject(Player, Object))
		{
			return true;
		}
	}

	return false;
}

bool UP3World::Client_SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const
{
	ensure(GetP3NetMode() != EP3NetMode::DedicatedServer);

	if (ensure(Client_World))
	{
		return Client_World->SendPacketBuffer(ActorId, Actor, Buffer, Header, bReliable);
	}

	return false;
}

bool UP3World::Server_MulticastPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const
{
	if (ensure(Server_World))
	{
		return Server_World->MulticastPacketBuffer(ActorId, Actor, Buffer, Header, bReliable);
	}

	return false;
}

bool UP3World::Server_SendPacketBufferToPlayer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bCheckPlayerStatus, bool bReliable) const
{
	if (ensure(Server_World))
	{
		return Server_World->SendPacketBufferToPlayer(NetConnInfo, ActorId, Actor, Buffer, Header, bCheckPlayerStatus, bReliable);
	}

	return false;
}

void UP3World::Server_AddActor(AActor* Actor)
{
	ensure(GetP3NetMode() != EP3NetMode::Client);

	if (!Actor)
	{
		return;
	}

	if (_IsP3ActorClass(*Actor))
	{
		const actorid ActorId = GetActorIdFromActor(Actor);
		if (ensure(ActorId == INVALID_ACTORID))
		{
			ensure(Actor->Tags.Find(NAME_ClientActor) == INDEX_NONE);

			const actorid NewActorId = Server_NextId++;
			Actors.Add(NewActorId, Actor);

			IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
			if (ensure(ActorInterface))
			{
				ActorInterface->SetActorId(NewActorId);
			}

			Actor->Tags.Add(NAME_ServerActor);
			Actor->OnDestroyed.AddUniqueDynamic(this, &UP3World::Server_OnActorDestroyed);

			Server_BeginPlayQueue.Add(Actor);
			Server_ActorAdded.Broadcast(NewActorId, Actor);

			if (CVarP3WorldDebug.GetValueOnGameThread() != 0)
			{
				P3JsonWorldLog(Display, "Server_AddActor",
					TEXT("ActorId"), NewActorId,
					TEXT("Class"), Actor->GetClass()->GetPathName(),
					TEXT("NetMode"), P3Core::GetNetModeStr(GetP3NetMode()));
			}
		}
	}

	AFlockManager* FlockManager = Cast<AFlockManager>(Actor);

	if (FlockManager)
	{
		P3JsonWorldLog(Display, "Flock Manager added", TEXT("Name"), FlockManager->GetName());

		Server_FlockManagers.Add(FlockManager);
	}
}

void UP3World::Multicast_DamageNonCommandActor(const FP3NetDamageNonCommandActor& NetDamage)
{
	if (NetDamage.TargetActor)
	{
		FPointDamageEvent PointDamageEvent;
		PointDamageEvent.Damage = NetDamage.DamageAmount;
		PointDamageEvent.HitInfo.Component = NetDamage.TargetComponent;
		PointDamageEvent.HitInfo.Item = NetDamage.HitItemIndex;
		NetDamage.TargetActor->TakeDamage(NetDamage.DamageAmount, PointDamageEvent, nullptr, NetDamage.SourceActor);
	}

	if (GIsClient && NetDamage.bHasHitLocation)
	{
		UParticleSystem* HitParticle = P3Core::GetGameResource(this).HitObjectParticle;

		if (HitParticle)
		{
			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), HitParticle, NetDamage.HitLocation, FRotator::ZeroRotator);
		}
	}
}

void UP3World::Server_OnActorDestroyed(AActor* Actor)
{
	ensure(GetP3NetMode() != EP3NetMode::Client);

	const actorid ActorId = GetActorIdFromActor(Actor);

	if (ensure(ActorId != INVALID_ACTORID))
	{
		if (CVarP3WorldDebug.GetValueOnGameThread() != 0)
		{
			P3JsonWorldLog(Display, "Server_OnActorDestroyed",
				TEXT("ActorId"), ActorId,
				TEXT("Class"), Actor->GetClass()->GetPathName(),
				TEXT("NetMode"), P3Core::GetNetModeStr(GetP3NetMode()));
		}

		IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
		if (ensure(ActorInterface))
		{
			ActorInterface->SetActorId(INVALID_ACTORID);
		}

		Actors.Remove(ActorId);
		Server_ActorRemoved.Broadcast(ActorId, Actor);
	}
}

void UP3World::Client_OnLevelAddedToWorld(ULevel* InLevel, UWorld* InWorld)
{
	if (InWorld == World && !P3Core::IsP3NetModeServerInstance(*this))
	{
		APawn* LocalPawn = P3Core::GetLocalPawn(GetWorld());

		for (FActorIterator ActorIter(InWorld); ActorIter; ++ActorIter)
		{
			AActor* Actor = *ActorIter;

			if (Actor == LocalPawn)
			{
				continue;
			}

			// FixMe: This is workaround to avoid destroy game mode which is bNetLoadOnClient true
			if (!_IsP3ActorClass(*Actor))
			{
				continue;
			}

			IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
			if (ActorInterface && ActorInterface->IsLevelPersistence())
			{
				continue;
			}

			if (Actor && !Actor->bNetLoadOnClient && !Actor->ActorHasTag(NAME_ClientActor))
			{
				Actor->Destroy(true);
			}
		}
	}
}

void UP3World::Server_OnLevelAddedToWorld(ULevel* InLevel, UWorld* InWorld)
{
	ensure(GetP3NetMode() != EP3NetMode::Client);

	if (!ensure(InLevel))
	{
		return;
	}

	if (InWorld != World)
	{
		return;
	}

	for (AActor* Actor : InLevel->Actors)
	{
		Server_AddActor(Actor);
	}
}

void UP3World::Server_OnLevelRemovedFromWorld(ULevel* InLevel, UWorld* InWorld)
{
	ensure(GetP3NetMode() != EP3NetMode::Client);

	// I guess... nothing to do?
}

void UP3World::OnPreLoadMap(const FString& MapName)
{

}

void UP3World::OnPostLoadMapWithWorld(UWorld* LoadedWorld)
{
	if (!LoadedWorld)
	{
		return;
	}

	// In case of client, BeginPlay can't be called since it's from GameMode which client doesn't have
	// So, we BeginPlay from here. This seems some how most early stage in client
	if (World == nullptr && GameInstance && LoadedWorld == GameInstance->GetWorld())
	{
		ensure(LoadedWorld->GetNetMode() == NM_Client);
		ensure(LoadedWorld == GameInstance->GetWorld());

		BeginPlay(LoadedWorld);
	}
}

void UP3World::OnWorldDestroyed(UWorld* DestroyedWorld)
{
	// Got to loose world pointer so that it can be garbage collected
	if (DestroyedWorld == World)
	{
		World = nullptr;
		Actors.Empty();
	}
}

void UP3World::OnHUDPostRender(class AHUD* HUD, class UCanvas* Canvas)
{
	if (HUD->GetWorld() != GetWorld())
	{
		return;
	}

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0)
	{
		float X = 50;
		float Y = 150;

		const int32 MaxNumLinesPerProfile = 5;

		for (int32 ProfileIndex = 0; ProfileIndex < EP3WorldPacketProfileType::WPP_Count; ++ProfileIndex)
		{
			HUD->DrawText(FString::Printf(TEXT("[%s]"), *EnumToStringShort(EP3WorldPacketProfileType, (EP3WorldPacketProfileType)ProfileIndex)), FLinearColor::White, X, Y);	Y += 20;

			int32 NumLines = 0;

			Client_World->ForeachProfileResult(ProfileIndex, [HUD, X, &Y, &NumLines, MaxNumLinesPerProfile](const FString& FunctionName, int32 PacketCount, float DurationSeconds) -> bool
			{
				HUD->DrawText(FString::Printf(TEXT("%5.2f PKS. %s"), PacketCount / DurationSeconds, *FunctionName), FLinearColor::White, X, Y); Y += 20;
				return (++NumLines > MaxNumLinesPerProfile) ? true : false;
			});
		}
	}

	if (CVarP3WorldDebug.GetValueOnGameThread() != 0)
	{
		float X = 50;
		float Y = 150;

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			X += 400;
		}
		
		int32 NumReplicateMovement = 0;
		int32 NumCharacter = 0;

		struct FClassStat
		{
			int32 NumActors = 0;
			int32 NumAttachedActors = 0;
		};

		TMap<UClass*, FClassStat> NumActorsPerClass;

		for (auto&& Iter : GetActors())
		{
			const AActor* Actor = Iter.Value;
			if (!Actor)
			{
				continue;
			}

			UClass* Class = Actor->GetClass();
			AActor* ClassDefaultActor = Cast<AActor>(Class->ClassDefaultObject);
			const bool bReplicateMovement = ClassDefaultActor && ClassDefaultActor->bReplicateMovement;
			if (bReplicateMovement)
			{
				++NumReplicateMovement;
			}
			if (Cast<ACharacter>(ClassDefaultActor))
			{
				++NumCharacter;
			}

			FClassStat& ClassStat = NumActorsPerClass.FindOrAdd(Class);
			
			++ClassStat.NumActors;

			if (Actor->GetAttachParentActor())
			{
				++ClassStat.NumAttachedActors;
			}
		}

		HUD->DrawText(FString::Printf(TEXT("[P3World] NetMode(%s), GIsClient(%s), GIsServer(%s)"),
			P3Core::GetNetModeStr(GetP3NetMode()),
			GIsClient ? TEXT("True") : TEXT("False"),
			GIsServer ? TEXT("True") : TEXT("False")),
			FLinearColor::White, X, Y);	Y += 20;
		HUD->DrawText(FString::Printf(TEXT("Num Actors(%d), Num Characters(%d), Num Movement Replicated Actors(%d)"),
			Actors.Num(), NumCharacter, NumReplicateMovement), FLinearColor::White, X, Y);	Y += 20;

		NumActorsPerClass.ValueSort([](const FClassStat& A, const FClassStat& B) {
			return A.NumActors > B.NumActors;
		});

		for (auto&& Iter : NumActorsPerClass)
		{
			UClass* Class= Iter.Key;
			const FClassStat& ClassStat = Iter.Value;
			AActor* ClassDefaultActor = Class ? Cast<AActor>(Class->ClassDefaultObject) : nullptr;
			const bool bReplicateMovement = ClassDefaultActor && ClassDefaultActor->bReplicateMovement;
			const FString NumAttachedActorsString = (ClassStat.NumAttachedActors > 0) ? FString::Printf(TEXT("Attached(%d)"), ClassStat.NumAttachedActors) : FString();

			HUD->DrawText(FString::Printf(TEXT("(%d) %s %s %s"),
				ClassStat.NumActors,
				Class ? *Class->GetName() : TEXT("NULL"),
				bReplicateMovement ? TEXT("(Movement Replicated)") : TEXT(""),
				*NumAttachedActorsString),
				FLinearColor::White, X, Y);
			Y += 20;
		}

		// List all actors
		int32 Index = 0;
		int32 NumShows = 30;
		for (auto&& Iter : GetActors())
		{
			if (++Index > NumShows)
			{
				// Screen size is limited
				break;
			}

			const int64 Id = Iter.Key;
			const AActor* Actor = Iter.Value;

			HUD->DrawText(
				FString::Printf(TEXT("Id(%ld), Actor(%s), %s %s"),
					Id, Actor ? *Actor->GetName() : TEXT("<NULL>"),
					Actor && Actor->ActorHasTag(NAME_ClientActor) ? TEXT("Client") : TEXT(""),
					Actor && Actor->ActorHasTag(NAME_ServerActor) ? TEXT("Server") : TEXT("")), FLinearColor::White, X, Y);	Y += 20;
		}
	}

	if (CVarP3LevelStreamingDebug.GetValueOnGameThread() != 0 && World)
	{
		float X = 50;
		float Y = 150;

		HUD->DrawText(FString::Printf(TEXT("[Level streaming]")), FLinearColor::White, X, Y);	Y += 20;

		for (ULevelStreaming* LevelStreaming : World->GetStreamingLevels())
		{
			int32 CurrentState = StaticCast<int32>(LevelStreaming->GetCurrentState());
			if (CurrentState == 1) // Unloaded
			{
				continue;
			}

			HUD->DrawText(FString::Printf(TEXT("%s: State %d, %s"),
				*LevelStreaming->PackageNameToLoad.ToString(),
				CurrentState,
				LevelStreaming->IsLevelLoaded() ? TEXT("Loaded") : TEXT("Not Loaded")),
				FLinearColor::White, X, Y);	Y += 20;
		}
	}
}

EP3NetMode UP3World::GetP3NetMode() const
{
	if (!ensure(World))
	{
		Debug_NetMode = EP3NetMode::MAX;
	}
	else
	{
		Debug_NetMode = P3Core::GetP3NetMode(*World);
	}

	return Debug_NetMode;
}

void UP3World::AddToActorCache(UClass* ActorClass, AActor* Actor)
{
	ensure(Actor && Actor->IsA(ActorClass));

	CachedActors.AddUnique(ActorClass, Actor);
}

void UP3World::RemoveFromActorCache(UClass* ActorClass, AActor* Actor)
{
	ensure(Actor && Actor->IsA(ActorClass));

	const int32 NumRemoved = CachedActors.Remove(ActorClass, Actor);

	ensure(NumRemoved > 0);
}
