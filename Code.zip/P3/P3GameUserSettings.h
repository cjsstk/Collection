// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameUserSettings.h"
#include "P3GameUserSettings.generated.h"

/**
 * Game User Setting
 */
UCLASS(BlueprintType)
class P3_API UP3GameUserSettings : public UGameUserSettings
{
	GENERATED_BODY()
	
public:
	UFUNCTION(BlueprintCallable, Category = Sound)
	void SetBGMVolume(float InVolume);

	UFUNCTION(BlueprintCallable, Category = Sound)
	float GetBGMVolume() const { return BGMVolume; }

	UFUNCTION(BlueprintCallable, Category = Sound)
	void SetUseJumpToParkour(bool bInUseJumpToParkour) { bUseJumpToParkour = bInUseJumpToParkour; }

	UFUNCTION(BlueprintCallable, Category = Sound)
	bool GetUseJumpToParkour() const { return bUseJumpToParkour; }

	UFUNCTION(BlueprintCallable, Category = UI)
	void SetShowKeyGuide(bool bInShowKeyGuide) { bShowKeyGuide = bInShowKeyGuide; }

	UFUNCTION(BlueprintCallable, Category = UI)
	bool GetShowKeyGuide() const { return bShowKeyGuide; }

	UFUNCTION(BlueprintCallable, Category = UI)
	void SetShowOtherPlayersHealthBar(bool bInShowOtherPlayersHealthBar) { bShowOtherPlayersHealthBar = bInShowOtherPlayersHealthBar; }

	UFUNCTION(BlueprintCallable, Category = UI)
	bool GetShowOtherPlayersHealthBar() const { return bShowOtherPlayersHealthBar; }

	UFUNCTION(BlueprintCallable, Category = UI)
	void SetShowOtherPlayersName(bool bInShowOtherPlayersName) { bShowOtherPlayersName = bInShowOtherPlayersName; }

	UFUNCTION(BlueprintCallable, Category = UI)
	bool GetShowOtherPlayersName() const { return bShowOtherPlayersName; }

	UFUNCTION(BlueprintCallable, Category = Camera)
	void SetPadCameraSensitivity(float InSensitivity);

	UFUNCTION(BlueprintCallable, Category = Camera)
	float GetPadCameraSensitivity() const { return PadCameraSensitivity; }

	UFUNCTION(BlueprintCallable, Category = Camera)
	void SetPadAimCameraSensitivity(float InSensitivity);

	UFUNCTION(BlueprintCallable, Category = Camera)
	float GetPadAimCameraSensitivity() const { return PadAimCameraSensitivity; }

	UFUNCTION(BlueprintCallable, Category = Camera)
	void SetFieldOfView(float InFieldOfView);

	UFUNCTION(BlueprintCallable, Category = Camera)
	float GetFieldOfView() const { return FieldOfView; }

	UFUNCTION(BlueprintCallable)
	void SetAudioListenerAttachToCharacter(bool bInAttachToCharacter) { bAttachAudioListenerToCharacter = bInAttachToCharacter; }

	UFUNCTION(BlueprintCallable)
	bool GetAudioListenerAttachToCharacter() const { return bAttachAudioListenerToCharacter; }

private:
	UPROPERTY(config)
	float BGMVolume = 1.0f;

	/** If set true, player need to input jump to start parkour */
	UPROPERTY(config)
	bool bUseJumpToParkour = true;

	/** If set true, Show key guides on UI */
	UPROPERTY(config)
	bool bShowKeyGuide = true;

	/** If set true, Show other player's Health bar on UI */
	UPROPERTY(config)
	bool bShowOtherPlayersHealthBar = false;

	/** If set true, Show other player's Name on UI */
	UPROPERTY(config)
	bool bShowOtherPlayersName = true;

	/** Pad camera control sensitivity */
	UPROPERTY(config)
	float PadCameraSensitivity = 1.f;

	/** Pad aim camera control sensitivity */
	UPROPERTY(config)
	float PadAimCameraSensitivity = 1.f;

	/** Camera FOV(Horizontal) */
	UPROPERTY(config)
	float FieldOfView = 80.0f;

	/** If set true, Audio listener is attached to character */
	UPROPERTY(config)
	bool bAttachAudioListenerToCharacter = false;
};
