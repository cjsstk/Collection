// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Combat.h"

#include "Components/CapsuleComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Actor.h"
#include "InstancedFoliageActor.h"
#include "Kismet/GameplayStatics.h"

#include "AI/P3AIController.h"
#include "Action/P3PawnActionComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "GameMode/P3ContributionSystem.h"
#include "P3AggroComponent.h"
#include "P3AttributesComponent.h"
#include "P3Character.h"
#include "P3CharacterHealthPointComponent.h"
#include "P3CharacterMovementComponent.h"
#include "P3CombatComponent.h"
#include "P3CombatResponseComponent.h"
#include "P3ComboTableComponent.h"
#include "P3Core.h"
#include "P3DamageMetersComponent.h"
#include "P3Destructible.h"
#include "P3DrawDebugHelpers.h"
#include "P3GameState.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3Log.h"
#include "P3Physics.h"
#include "P3PickupableComponent.h"
#include "P3PlayerController.h"
#include "P3Projectile.h"
#include "P3StaminaPointComponent.h"
#include "P3SwitchActor.h"
#include "P3Tree.h"
#include "P3Weapon.h"

extern TAutoConsoleVariable<float> CVarP3CombatBlockStaminaAmount;
extern TAutoConsoleVariable<float> CVarP3CombatCrouchBlockStaminaAmount;

static TAutoConsoleVariable<float> CVarP3CombatAttackInterruptTimeSeconds(
	TEXT("p3.combatAttackInterruptTimeSeconds"),
	0.0f,
	TEXT("Set time duration which attack action can be interrupted by hit"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CombatPKMode(
	TEXT("p3.combatPKMode"),
	0,
	TEXT("1: PK Allowed, 0: PK Disallowed"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3CombatPKDamage(
	TEXT("p3.combatPKDamage"),
	0.1f,
	TEXT("PK Damage Multiplier"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3CombatCounterAttackDurationTimeSeconds(
	TEXT("p3.combatCounterAttackDurationTimeSeconds"),
	0.3f,
	TEXT("Set time duration which block action can be interrupted by counterattack"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AIRangeDebug(
	TEXT("p3.aiRangeDebug"),
	0,
	TEXT("1: Enable debug. 0: Disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AIRangeDebugActor(
	TEXT("p3.aiRangeDebugActor"),
	0,
	TEXT("AI Range debug only for specific actor id (0: all npc)"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AutoDrawWeaponOnApplyDamage(
	TEXT("p3.autoDrawWeaponOnApplyDamage"),
	0,
	TEXT("1: Allow Auto Draw, 0: Disallow Auto Draw"), ECVF_Cheat);

namespace P3Combat
{

static float _RollDice_CalcDamage(const AActor& Source, const AActor& Target, bool bIgnoreArmor = false)
{
	//static const float MaxDamageReduction = 0.75f;
	static const float MinDamage = 1.0f;
	//static const float LargeToTreeDamage = 100.0f;

	//UP3AttributesComponent* SourceAttributes = Source.FindComponentByClass<UP3AttributesComponent>();
	//UP3AttributesComponent* TargetAttributes = Target.FindComponentByClass<UP3AttributesComponent>();
	const AP3Character* SourceCharacter = Cast<const AP3Character>(&Source);

	//if (!SourceAttributes || !TargetAttributes)
	//{
	//	// TODO: Sorry
	//	if (Target.IsA(AP3Tree::StaticClass()) && SourceCharacter && SourceCharacter->IsLarge())
	//	{
	//		return LargeToTreeDamage;
	//	}

	//	return MinDamage;
	//}

	//float SourceLevel = SourceAttributes->GetLevel();
	//float Damage = SourceAttributes->GetAttribute(EP3Attribute::PhysicalAttack) * FMath::FRandRange(0.8f, 1.2f);
	//float ArmorClass = bIgnoreArmor ? 0.0f : FMath::Max(0, TargetAttributes->GetAttribute(EP3Attribute::ArmorClass));
	//float DamageReduction = FMath::Min(MaxDamageReduction, ArmorClass / (ArmorClass + 400 + 85 * SourceLevel));
	//Damage = FMath::Max(MinDamage, Damage - Damage * DamageReduction);

	UWorld* World = Source.GetWorld();
	if (!ensure(World))
	{
		return MinDamage;
	}
	
	AP3GameState* GameState = Cast<AP3GameState>(World->GetGameState());
	if (!ensure(GameState))
	{
		return MinDamage;
	}

	float Damage = GameState->RollDice_CalcDamage(&Source, &Target, bIgnoreArmor);

	const AP3Character* TargetCharacter = Cast<const AP3Character>(&Target);

	if (SourceCharacter && TargetCharacter && SourceCharacter->GetFaction() == TargetCharacter->GetFaction())
	{
		Damage *= CVarP3CombatPKDamage.GetValueOnGameThread();
	}

	return Damage;
}

EP3ReactionLayer Server_GetCharacterTargetReactionLayer(const FDamageActorParams& Params, AP3Character* TargetCharacter)
{
	EP3ReactionLayer ReactionLayer = EP3ReactionLayer::Default;

	if (!ensure(TargetCharacter))
	{
		return EP3ReactionLayer::None;
	}

	if (TargetCharacter->IsDead())
	{
		ReactionLayer = EP3ReactionLayer::Dead;
	}
	else if (TargetCharacter->IsMounted())
	{
		ReactionLayer = EP3ReactionLayer::Mounting;
	}
	else if (TargetCharacter->IsDowned())
	{
		ReactionLayer = EP3ReactionLayer::Downed;
	}
	else if (TargetCharacter->IsClimbing())
	{
		ReactionLayer = EP3ReactionLayer::Climbing;
	}
	else if (TargetCharacter->IsGliding())
	{
		ReactionLayer = EP3ReactionLayer::Gliding;
	}
	else if (TargetCharacter->IsSliding())
	{
		ReactionLayer = EP3ReactionLayer::Sliding;
	}
	else if (TargetCharacter->GetP3CharacterMovementBP()->IsFalling())
	{
		ReactionLayer = EP3ReactionLayer::Air;
	}	
	else
	{				
		const bool bIsGuardMode = TargetCharacter->GetCharacterStoreBP().bIsBlocking || TargetCharacter->GetCharacterStoreBP().bIsCrouchBlocking;
		const bool bCanGuard = TargetCharacter->CanBlock() && bIsGuardMode;

		const float TimeSinceBlockStartedSeconds = TargetCharacter->GetWorld()->GetTimeSeconds() - TargetCharacter->GetStartBlcokTimeSeconds();
		const bool bCanParrying = TimeSinceBlockStartedSeconds > 0 && TimeSinceBlockStartedSeconds < CVarP3CombatCounterAttackDurationTimeSeconds.GetValueOnGameThread();

		const FVector& SourceToTargetDirection = (Params.TargetActor.GetActorLocation() - Params.SourceActor.GetActorLocation()).GetSafeNormal();
		const bool bIsFront = (Params.TargetActor.GetActorQuat().GetForwardVector() | SourceToTargetDirection) < 0;						
		
		const bool bBlocked = bCanGuard && bIsFront;

		if (bBlocked)
		{
			ReactionLayer = bCanParrying ? EP3ReactionLayer::Parrying : EP3ReactionLayer::Guard;
		}
	}

	if (ReactionLayer == EP3ReactionLayer::Default)
	{
		UP3CombatResponseComponent* CombatResponseComp = TargetCharacter->GetP3CombatResponseoComponent();
		if (ensure(CombatResponseComp))
		{
			EP3ReactionLayerAnimationType InProgressAnimationType = CombatResponseComp->GetInProgressAnimationType();
			if (InProgressAnimationType == EP3ReactionLayerAnimationType::FrontDown)
			{
				ReactionLayer = EP3ReactionLayer::FrontDown;
			}
			else if (InProgressAnimationType == EP3ReactionLayerAnimationType::BackDown)
			{
				ReactionLayer = EP3ReactionLayer::BackDown;
			}
		}
	}

	return ReactionLayer;
}

const FP3CombatReactionRow* Server_GetCharacterTargetReactionCms(EP3ReactionLayer ReactionLayer, const FDamageActorParams& Params, AP3Character* TargetCharacter, EAnimNotifyAttackDirectionFlags AttackDirection, EAnimNotifyAttackStrengthFlags AttackStrength, EAnimNotifyAttackPartFlags AttackPart)
{
	if (!ensure(TargetCharacter) || ReactionLayer == EP3ReactionLayer::None)
	{
		return nullptr;
	}

	UP3CombatResponseComponent* CombatResponseComp = TargetCharacter->GetP3CombatResponseoComponent();
	if (!ensure(CombatResponseComp))
	{
		return nullptr;
	}

	const UDataTable* ReactionTable = CombatResponseComp->GetCombatReactionTable(ReactionLayer);
	if (!ReactionTable)
	{
		return nullptr;
	}

	const FP3CombatReactionRow* ReactionRow = nullptr;
	TArray<FP3CombatReactionRow*> CmsReactions;	

	ReactionTable->GetAllRows<FP3CombatReactionRow>("Server_GetCharacterTargetReactionCms", CmsReactions);

	for (const FP3CombatReactionRow* CmsReaction : CmsReactions)
	{
		if (!CmsReaction)
		{
			continue;
		}		

		const bool bSameDirection = (CmsReaction->AttackDirectionFlags & (1 << (int32)AttackDirection)) > 0;
		const bool bSameStrength = (CmsReaction->AttackStrengthFlags & (1 << (int32)AttackStrength)) > 0;
		const bool bSamePart = (CmsReaction->AttackPartFlags & (1 << (int32)AttackPart)) > 0;
		const bool bCheckAttackDirection = Server_CheckAttackDirection(CmsReaction->CheckAttackDirection, Params.SourceActor.GetActorLocation(), TargetCharacter);
		const bool bCheckSingalName = CmsReaction->CheckSingalName == NAME_None ? true : CombatResponseComp->IsNotifyStateSignalEnabled(CmsReaction->CheckSingalName);
		const bool bCheckTagName = CmsReaction->CheckTagName == Params.TagName;

		if (bSameDirection && bSameStrength && bSamePart && bCheckAttackDirection && bCheckSingalName && bCheckTagName)
		{
			ReactionRow = CmsReaction;
			break;
		}
	}

	return ReactionRow;
}

const FP3CombatReactionRow* Server_GetCharacterTargetReactionCms(EP3ReactionLayer ReactionLayer, AP3Character* TargetCharacter)
{
	if (!ensure(TargetCharacter) || ReactionLayer == EP3ReactionLayer::None)
	{
		return nullptr;
	}

	UP3CombatResponseComponent* CombatResponseComp = TargetCharacter->GetP3CombatResponseoComponent();
	if (!ensure(CombatResponseComp))
	{
		return nullptr;
	}

	const UDataTable* ReactionTable = CombatResponseComp->GetCombatReactionTable(ReactionLayer);
	if (!ReactionTable)
	{
		return nullptr;
	}

	TArray<FP3CombatReactionRow*> CmsReactions;
	ReactionTable->GetAllRows<FP3CombatReactionRow>("Server_GetCharacterTargetReactionCms", CmsReactions);

	for (const FP3CombatReactionRow* CmsReaction : CmsReactions)
	{
		if (!CmsReaction)
		{
			continue;
		}

		return CmsReaction;
	}

	return nullptr;
}

const FP3CombatReactionRow* Server_GetCharacterTargetOverlapReactionCms(EP3ReactionLayer ReactionLayer, AP3Character* TargetCharacter, const FName& ReactionName)
{
	if (!ensure(TargetCharacter) || ReactionLayer == EP3ReactionLayer::None)
	{
		return nullptr;
	}

	UP3CombatResponseComponent* CombatResponseComp = TargetCharacter->GetP3CombatResponseoComponent();
	if (!ensure(CombatResponseComp))
	{
		return nullptr;
	}

	const UDataTable* ReactionTable = CombatResponseComp->GetCombatReactionTable(ReactionLayer);
	if (!ReactionTable)
	{
		return nullptr;
	}

	TArray<FP3CombatReactionRow*> CmsReactions;
	ReactionTable->GetAllRows<FP3CombatReactionRow>("Server_GetCharacterTargetReactionCms", CmsReactions);

	for (const FP3CombatReactionRow* CmsReaction : CmsReactions)
	{
		if (!CmsReaction)
		{
			continue;
		}

		if (CmsReaction->ReactionName == ReactionName)
		{
			return CmsReaction;
		}
	}

	return nullptr;
}

bool Server_GetCharacterTargetReactionOverrideBuffer(AP3Character* TargetCharacter, FP3CharacterBuff& CharacterBuff)
{
	UP3CharacterEffectComponent* EffectComp = TargetCharacter ? TargetCharacter->FindComponentByClass<UP3CharacterEffectComponent>() : nullptr;
	if (!EffectComp)
	{
		return false;
	}

	const TArray<FP3CharacterBuff> Buffs = EffectComp->GetBuffs();
	for (const auto& Buff : Buffs)
	{
		if (Buff.CmsCharacterBuff.BuffImplType != EP3CharacterBuffImplType::Reaction)
		{
			continue;
		}
			
		const FP3CmsReactionBuffImplRow* RectionBuff = P3Cms::GetReactionBuffImpl(Buff.CmsCharacterBuff.BuffImpleKey);
		if (!RectionBuff)
		{
			continue;
		}
						
		CharacterBuff.bCanReaction = RectionBuff->bCanReaction;
		CharacterBuff.bCanDamage = RectionBuff->bCanDamage;
		CharacterBuff.OverrideReactionLayer = RectionBuff->OverrideReactionLayer;
		CharacterBuff.OverrideAttackDirection = RectionBuff->OverrideAttackDirection;
		CharacterBuff.OverrideAttackStrength = RectionBuff->OverrideAttackStrength;

		return true;
	}

	return false;
}

bool Server_CheckAttackDirection(EP3ReactionCheckAttackDirection CheckAttackDirection, const FVector& SourceActorLocation, AP3Character* TargetCharacter)
{
	if (!ensure(TargetCharacter))
	{
		return false;
	}

	if (CheckAttackDirection != EP3ReactionCheckAttackDirection::Any)
	{
		FVector SourceToTargetDirection = (TargetCharacter->GetActorLocation() - SourceActorLocation).GetSafeNormal();
		FVector TargetForward = TargetCharacter->GetActorForwardVector();

		const bool bIsFront = (SourceToTargetDirection.GetSafeNormal2D() | TargetForward.GetSafeNormal2D()) < 0.f;

		return (bIsFront && CheckAttackDirection == EP3ReactionCheckAttackDirection::Front)
			|| (!bIsFront && CheckAttackDirection == EP3ReactionCheckAttackDirection::Back);
	}

	return true;
}

bool Server_CharacterTargetReaction(EP3ReactionLayer ReactionLayer, const FP3CombatReactionRow* ReactionRow, const FDamageActorParams& Params, AP3Character* TargetCharacter, EAnimNotifyAttackPartFlags AttackPart)
{	
	if (!ensure(TargetCharacter) || ReactionLayer == EP3ReactionLayer::None)
	{
		return false;
	}

	if (!ReactionRow)
	{
		return false;
	}

	UP3PawnActionComponent* ActionComp = TargetCharacter->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return false;
	}

	UP3CombatResponseComponent* CombatResponseComp = TargetCharacter->GetP3CombatResponseoComponent();
	if (!ensure(CombatResponseComp))
	{
		return false;
	}

	FP3PawnActionStartRequestParams RequestParams;
	
	const FP3CombatReactionRow* OverlapReactionRow = Server_GetCharacterTargetReactionOverlapRule(ReactionLayer, ReactionRow, RequestParams, Params.SourceActor.GetActorLocation(), Params.AttackStrength, Params.AttackDirection, AttackPart, TargetCharacter);

	const bool bCanStartedAction = Server_CanStartAction(OverlapReactionRow);
	if (bCanStartedAction)
	{
		if (!ActionComp->IsActionInProgress(EPawnActionType::CombatReactionHit)
			|| CombatResponseComp->GetInProgressLayer() != ReactionLayer)
		{
			CombatResponseComp->ResetOverlapCount();
		}
		else
		{
			CombatResponseComp->IncreaseOverlapCount();
		}

		switch (ReactionLayer)
		{
		case EP3ReactionLayer::Default:
		case EP3ReactionLayer::FrontDown:
		case EP3ReactionLayer::BackDown:
		case EP3ReactionLayer::Air:
		case EP3ReactionLayer::Dead:
		case EP3ReactionLayer::Downed:
		case EP3ReactionLayer::Guard:
		case EP3ReactionLayer::Climbing:
		case EP3ReactionLayer::Gliding:
		case EP3ReactionLayer::Sliding:
		case EP3ReactionLayer::Parrying:
		case EP3ReactionLayer::Mounting:
		{
			RequestParams.ReactionHit_AttackerActor = &Params.SourceActor;

			UP3World* World = P3Core::GetP3World(*TargetCharacter);
			if (World)
			{
				RequestParams.ReactionHit_AttackerActorID = World->GetActorIdFromActor(&Params.SourceActor);
			}

			RequestParams.ReactionHit_Name = OverlapReactionRow->ReactionName;
			RequestParams.ReactionHit_Layer = ReactionLayer;
			RequestParams.ReactionHit_AttackDirection = Params.AttackDirection;
			RequestParams.ReactionHit_AttackStrength = Params.AttackStrength;
			RequestParams.ReactionHit_AttackAttribute = Params.AttackAttribute;
			RequestParams.ReactionHit_TargetTransform = Params.SourceActor.GetActorTransform();
			RequestParams.ReactionHit_HitLocation = Params.HitLocation ? *Params.HitLocation : Params.SourceActor.GetActorLocation();
			RequestParams.ReactionHit_HitBoneName = Params.BoneName;
			RequestParams.ReactionHit_AttackerBoneName = Params.AttackBoneName;
			RequestParams.ReactionHit_ThrowAwayVelocity = Params.ThrowAwayVelocity;
			RequestParams.ReactionHit_bIsFrameHold = Params.bIsFrameHold;

			ActionComp->StartAction(EPawnActionType::CombatReactionHit, _FUNCTION_TEXT, RequestParams);
			break;
		}
		default:
		{
			ensure(0);
			break;
		}
		}
	}
	else
	{
		CombatResponseComp->ResetOverlapCount();
	}

	const bool bCanStartedCommand = Server_CanStartCommand(OverlapReactionRow, ReactionLayer);
	if(bCanStartedCommand)
	{		
		if (TargetCharacter->GetCommandComponent())
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.PlayCombatResponseHit_AttackerActor = &Params.SourceActor;

			UP3World* World = P3Core::GetP3World(*TargetCharacter);
			if (World)
			{
				CommandParams.PlayCombatResponseHit_AttackerActorID = World->GetActorIdFromActor(&Params.SourceActor);
			}

			CommandParams.PlayCombatResponseHit_ReactionName = OverlapReactionRow->ReactionName;
			CommandParams.PlayCombatResponseHit_Layer = ReactionLayer;
			CommandParams.PlayCombatResponseHit_TargetTransform = Params.SourceActor.GetActorTransform();
			CommandParams.PlayCombatResponseHit_HitLocation = Params.HitLocation ? *Params.HitLocation : Params.SourceActor.GetActorLocation();
			CommandParams.PlayCombatResponseHit_HitBoneName = Params.BoneName;
			CommandParams.PlayCombatResponseHit_bIsFrameHold = Params.bIsFrameHold;

			TargetCharacter->GetCommandComponent()->RequestCommand(UP3PlayCombatResponseHitCommand::StaticClass(), CommandParams);
		}
	}
	
	return bCanStartedAction;
}

bool Server_CharacterTargetVFX(EP3ReactionLayer ReactionLayer, const FP3CombatReactionRow* ReactionRow, const FVector* HitLocation, const FVector& ImpactDirection, EP3AnimNotifyAttackAttribute AttackAttribute, AP3Character* TargetCharacter)
{
	if (!ensure(TargetCharacter) || ReactionLayer == EP3ReactionLayer::None)
	{
		return false;
	}

	if (!ReactionRow || !ReactionRow->VFX.Contains(AttackAttribute))
	{
		return false;
	}

	UP3CommandComponent* CommandComp = TargetCharacter->GetCommandComponent();
	if (!ensure(CommandComp))
	{
		return false;
	}

	FP3CommandRequestParams CommandParams;
	CommandParams.ReactionName = ReactionRow->ReactionName;
	CommandParams.ReactionHitLocation = HitLocation ? *HitLocation : TargetCharacter->GetActorLocation();
	CommandParams.ReactionImpactDirection = ImpactDirection;
	CommandParams.ReactionLayer = ReactionLayer;
	CommandParams.AttackAttribute = AttackAttribute;

	CommandComp->RequestCommand(UP3PlayReactionVFXCommand::StaticClass(), CommandParams);

	return true;
}

const FP3CombatReactionRow* Server_CharacterSourceReaction(EP3ReactionLayer& ReactionLayer, const FDamageActorParams& Params, AP3Character* SourceCharacter)
{
	if (!SourceCharacter || ReactionLayer == EP3ReactionLayer::None)
	{
		return nullptr;
	}

	if (Params.Projectile)
	{
		return nullptr;
	}

	UP3PawnActionComponent* ActionComp = SourceCharacter->GetActionComponent();
	if (!ActionComp)
	{
		return nullptr;
	}

	UP3CombatResponseComponent* CombatResponseComp = SourceCharacter->GetP3CombatResponseoComponent();
	if (!CombatResponseComp)
	{
		return nullptr;
	}

	FP3PawnActionStartRequestParams RequestParams;
	const UDataTable* ReactionTable = nullptr;

	switch (ReactionLayer)
	{
		case EP3ReactionLayer::Guard:
		{
			ReactionLayer = EP3ReactionLayer::CounterGuard;
			ReactionTable = CombatResponseComp->GetCombatReactionTable(ReactionLayer);
			break;
		}
		case EP3ReactionLayer::Parrying:
		{
			ReactionLayer = EP3ReactionLayer::CounterParrying;
			ReactionTable = CombatResponseComp->GetCombatReactionTable(ReactionLayer);
			break;
		}
	}

	if (ReactionTable)
	{
		const FP3CombatReactionRow* ReactionRow = nullptr;
		TArray<FP3CombatReactionRow*> CmsReactions;
		ReactionTable->GetAllRows<FP3CombatReactionRow>("Server_CharacterSourceReaction", CmsReactions);	

		for (const FP3CombatReactionRow* CmsReaction : CmsReactions)
		{
			if (!CmsReaction)
			{
				continue;
			}

			const bool bSameDirection = (CmsReaction->AttackDirectionFlags & (1 << (int32)Params.AttackDirection)) > 0;
			const bool bSameStrength = (CmsReaction->AttackStrengthFlags & (1 << (int32)Params.AttackStrength)) > 0;
			
			if (bSameDirection && bSameStrength)
			{
				ReactionRow = CmsReaction;
				break;
			}
		}

		if (ReactionRow)
		{
			const bool bCanStartedAction = Server_CanStartAction(ReactionRow);
			if (bCanStartedAction)
			{
				RequestParams.ReactionHit_AttackerActor = &Params.TargetActor;

				UP3World* World = P3Core::GetP3World(*SourceCharacter);
				if (World)
				{
					RequestParams.ReactionHit_AttackerActorID = World->GetActorIdFromActor(&Params.TargetActor);
				}

				RequestParams.ReactionHit_Name = ReactionRow->ReactionName;
				RequestParams.ReactionHit_Layer = ReactionLayer;
				RequestParams.ReactionHit_AttackAttribute = Params.AttackAttribute;
				RequestParams.ReactionHit_TargetTransform = Params.TargetActor.GetActorTransform();
				RequestParams.ReactionHit_HitLocation = Params.HitLocation ? *Params.HitLocation : Params.TargetActor.GetActorLocation();
				RequestParams.ReactionHit_HitBoneName = Params.BoneName;
				RequestParams.ReactionHit_AttackerBoneName = Params.AttackBoneName;
				RequestParams.ReactionHit_bIsFrameHold = Params.bIsFrameHold;

				ActionComp->StartAction(EPawnActionType::CombatReactionHit, _FUNCTION_TEXT, RequestParams);
			}

			const bool bCanStartedCommand = Server_CanStartCommand(ReactionRow, ReactionLayer);
			if(bCanStartedCommand)
			{
				if (SourceCharacter->GetCommandComponent())
				{
					FP3CommandRequestParams CommandParams;
					CommandParams.PlayCombatResponseHit_AttackerActor = &Params.SourceActor;

					UP3World* World = P3Core::GetP3World(*SourceCharacter);
					if (World)
					{
						CommandParams.PlayCombatResponseHit_AttackerActorID = World->GetActorIdFromActor(&Params.SourceActor);
					}

					CommandParams.PlayCombatResponseHit_ReactionName = ReactionRow->ReactionName;
					CommandParams.PlayCombatResponseHit_Layer = ReactionLayer;
					CommandParams.PlayCombatResponseHit_TargetTransform = Params.SourceActor.GetActorTransform();
					CommandParams.PlayCombatResponseHit_HitLocation = Params.HitLocation ? *Params.HitLocation : Params.SourceActor.GetActorLocation();
					CommandParams.PlayCombatResponseHit_HitBoneName = Params.BoneName;
					CommandParams.PlayCombatResponseHit_bIsFrameHold = Params.bIsFrameHold;

					SourceCharacter->GetCommandComponent()->RequestCommand(UP3PlayCombatResponseHitCommand::StaticClass(), CommandParams);
				}
			}

			return ReactionRow;
		}
	}
		
	return nullptr;
}

const FP3CombatReactionRow* Server_GetCharacterTargetReactionOverlapRule(EP3ReactionLayer ReactionLayer, const FP3CombatReactionRow* ReactionRow, FP3PawnActionStartRequestParams& RequestParams, const FVector& SourceActorLocation
	, EAnimNotifyAttackStrengthFlags AttackStrength, EAnimNotifyAttackDirectionFlags AttackDirection, EAnimNotifyAttackPartFlags AttackPart, AP3Character* TargetCharacter)
{
	if (!ensure(TargetCharacter) || ReactionLayer == EP3ReactionLayer::None || !ReactionRow)
	{
		return ReactionRow;
	}

	UP3PawnActionComponent* ActionComp = TargetCharacter->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return ReactionRow;
	}

	UP3CombatResponseComponent* CombatResponseComp = TargetCharacter->GetP3CombatResponseoComponent();
	if (!ensure(CombatResponseComp))
	{
		return ReactionRow;
	}
	
	int32 ReactionOverlapCount = CombatResponseComp->GetOverlapCount();	
	const FName& InProgressReactionName = CombatResponseComp->GetInProgressName();
	EP3ReactionLayer InProgressLayer = CombatResponseComp->GetInProgressLayer();
	EAnimNotifyAttackStrengthFlags InProgressAttackStrength = CombatResponseComp->GetInProgressAttackStrength();
	EAnimNotifyAttackDirectionFlags InProgressAttackDirection = CombatResponseComp->GetInProgressAttackDirection();
	EP3ReactionLayerAnimationType InProgressAnimationType = CombatResponseComp->GetInProgressAnimationType();

	if (InProgressLayer == EP3ReactionLayer::None)
	{
		return ReactionRow;
	}

	const FP3CombatReactionOverlapRuleRow* ReactionOverlapRow = nullptr;
	const UDataTable* ReactionOverlapRuleTable = CombatResponseComp->GetCombatReactionOverlapRuleTable(ReactionLayer);
	
	if (!ReactionOverlapRuleTable)
	{
		return ReactionRow;
	}

	TArray<FP3CombatReactionOverlapRuleRow*> CmsOverlapRuleReactions;
	ReactionOverlapRuleTable->GetAllRows<FP3CombatReactionOverlapRuleRow>("Server_GetCharacterTargetReactionOverlapRule", CmsOverlapRuleReactions);

	for (const FP3CombatReactionOverlapRuleRow* CmsOverlapRuleReaction : CmsOverlapRuleReactions)
	{
		if (!CmsOverlapRuleReaction)
		{
			continue;
		}

		if (!CmsOverlapRuleReaction->OverlapRange.IsZero())
		{
			if (CmsOverlapRuleReaction->OverlapRange.X > ReactionOverlapCount || CmsOverlapRuleReaction->OverlapRange.Y < ReactionOverlapCount)
			{
				continue;
			}
		}

		if (CmsOverlapRuleReaction->InProgressLayer != EP3ReactionLayer::None)
		{
			if (CmsOverlapRuleReaction->InProgressLayer != InProgressLayer)
			{
				continue;
			}
		}

		const bool bCheckAttackDirection = Server_CheckAttackDirection(CmsOverlapRuleReaction->CheckAttackDirection, SourceActorLocation, TargetCharacter);
		if (!bCheckAttackDirection)
		{
			continue;
		}

		if (CmsOverlapRuleReaction->StartAttackStrengthFlags != 0)
		{
			const bool bSameStrength = (CmsOverlapRuleReaction->StartAttackStrengthFlags & (1 << (int32)AttackStrength)) > 0;
			if (!bSameStrength)
			{
				continue;
			}
		}

		if (CmsOverlapRuleReaction->InProgressAttackStrengthFlags != 0 && InProgressAttackStrength != EAnimNotifyAttackStrengthFlags::Ignore)
		{
			const bool bSameStrength = (CmsOverlapRuleReaction->InProgressAttackStrengthFlags & (1 << (int32)InProgressAttackStrength)) > 0;
			if (!bSameStrength)
			{
				continue;
			}
		}

		if (CmsOverlapRuleReaction->StartAttackDirectionFlags != 0)
		{			
			const bool bSameDirection = (CmsOverlapRuleReaction->StartAttackDirectionFlags & (1 << (int32)AttackDirection)) > 0;
			if (!bSameDirection)
			{
				continue;
			}
		}

		if (CmsOverlapRuleReaction->InProgressAttackDirectionFlags != 0 && InProgressAttackDirection != EAnimNotifyAttackDirectionFlags::None)
		{
			const bool bSameDirection = (CmsOverlapRuleReaction->InProgressAttackDirectionFlags & (1 << (int32)InProgressAttackDirection)) > 0;
			if (!bSameDirection)
			{
				continue;
			}
		}

		if (CmsOverlapRuleReaction->StartAttackPartFlags != 0)
		{
			const bool bSamePart = (CmsOverlapRuleReaction->StartAttackPartFlags & (1 << (int32)AttackPart)) > 0;
			if (!bSamePart)
			{
				continue;
			}
		}

		if (CmsOverlapRuleReaction->StartReactionName != NAME_None)
		{
			if (CmsOverlapRuleReaction->StartReactionName != ReactionRow->ReactionName)
			{
				continue;
			}
		}

		if (CmsOverlapRuleReaction->InProgressReactionName != NAME_None)
		{
			if (CmsOverlapRuleReaction->InProgressReactionName != InProgressReactionName)
			{
				continue;
			}
		}

		ReactionOverlapRow = CmsOverlapRuleReaction;
		break;
	}

	if (ReactionOverlapRow)
	{
		if (ReactionOverlapRow->bSkipReaction)
		{		
			return InProgressAnimationType == EP3ReactionLayerAnimationType::OverlapSkipFrame ? nullptr : ReactionRow;
		}
								
		const float StartMontagePosition = ReactionOverlapRow->IncrememtStartMontagePosition * ReactionOverlapCount;
		RequestParams.ReactionHit_StartMontagePosition = StartMontagePosition > 0.f ? StartMontagePosition : 0.f;
		RequestParams.ReactionHit_StartMontagePlayRate = ReactionOverlapRow->IncrememtStartMontagePlayRate * ReactionOverlapCount + 1.f;
		RequestParams.ReactionHit_SkipMontageFrame = ReactionOverlapRow->bSkipMontageFrame;						

		if (ReactionOverlapRow->OverrideReactionName != NAME_None)
		{
			const FP3CombatReactionRow* FindOverlapReactionRow = Server_GetCharacterTargetOverlapReactionCms(ReactionLayer, TargetCharacter, ReactionOverlapRow->OverrideReactionName);

			if (Server_CanStartAction(FindOverlapReactionRow))
			{				
				return FindOverlapReactionRow;
			}

			return nullptr;
		}
	}		
	
	return ReactionRow;
}

void Server_GetTargetPartDamageParam(FPartDamageParams& DamageParams, const FDamageActorParams& Params, AP3Character* TargetCharacter)
{
	if (Params.BoneName.IsValid() && TargetCharacter && TargetCharacter->GetParts().Num() > 0)
	{
		for (int32 PartIterIndex = 0; PartIterIndex < TargetCharacter->GetParts().Num(); ++PartIterIndex)
		{
			const FP3CharacterPart& Part = TargetCharacter->GetParts()[PartIterIndex];

			if (Part.Bones.Contains(Params.BoneName))
			{
				DamageParams.bIsCriticalPart = Part.bIsCritical;
				DamageParams.bIsArmorPart = Part.bIsArmor;
				DamageParams.PartDamageMultiplier = Part.DamageMultiplier;
				DamageParams.PartIndex = PartIterIndex;
				break;
			}
		}
	}

	TInlineComponentArray<UP3PartComponent*, 8> PartComponents;
	Params.TargetActor.GetComponents(PartComponents);

	if (Params.BoneName.IsValid() && PartComponents.Num() > 0)
	{
		for (UP3PartComponent* PartComp : PartComponents)
		{
			if (PartComp)
			{
				if (!PartComp->IsPartActivated())
				{
					continue;
				}

				if (PartComp->GetPartDesc().HitAreaBones.Contains(Params.BoneName))
				{
					DamageParams.bIsCriticalPart = PartComp->GetPartDesc().bIsCriticalHit;
					DamageParams.bIsArmorPart = PartComp->GetPartDesc().bIsArmor;
					DamageParams.bIgnoreArmor = PartComp->GetPartDesc().bTakeDamageIgnoringArmor;
					DamageParams.PartDamageMultiplier = PartComp->GetPartDesc().DamageMultiplier;
					DamageParams.PartComponent = PartComp;
					break;
				}
			}
		}
	}
}

 bool Server_CanStartAction(const FP3CombatReactionRow* ReactionRow)
{
	if (!ReactionRow)
	{
		return false;
	}

	return ReactionRow->Montage != nullptr;
}

 bool Server_CanStartCommand(const FP3CombatReactionRow* ReactionRow, EP3ReactionLayer ReactionLayer)
 {
	 if (!ReactionRow)
	 {
		 return false;
	 }

	 return ReactionRow->CCDDurationSeconds > 0.f || ReactionRow->PoseAssetDurationSeconds > 0.f || ReactionRow->MorpthDurationSeconds
		 || ReactionRow->ImpulseStrength > 0.f || ReactionRow->ImpulseStrength2D > 0.f || ReactionRow->PhysicsBlendBoneDurationSeconds > 0.f
		 || ReactionRow->MeshImpulseStrength > 0.f || ReactionRow->MeshImpulseStrength2D > 0.f || ReactionRow->FrameHoldDurationSeconds > 0.f
		 || ReactionRow->bHitRotator || ReactionRow->bDropPickable || ReactionRow->bDropLeftHandHoldable || ReactionRow->bDropRightHandHoldable
		 || ReactionRow->bBreakGuard || ReactionRow->bBreakCrounchGuard || ReactionRow->StaminaAmount > 0.f
		 || ReactionRow->CmsReactionCameraShakeKey != NAME_None
		 || ReactionLayer == EP3ReactionLayer::Guard || ReactionLayer == EP3ReactionLayer::Parrying;
 }

static bool _Server_DamageCharacterWithReaction(
	const EAnimNotifyAttackStrengthFlags AttackStrength,
	const FP3CombatReactionRow* ReactionRow,
	const FDamageActorParams& Params,
	const FPartDamageParams& PartDamageParams,
	AP3Character* TargetCharacter)
{
	if (!ensure(TargetCharacter))
	{
		return false;
	}
	
	float DamageRatio = 1.f;
	if (ReactionRow)
	{
		if (ReactionRow->DamageRatio <= 0.f)
		{
			return false;
		}

		DamageRatio = ReactionRow->DamageRatio;
	}

	// Apply damage
	UP3CommandComponent* CommandComp = TargetCharacter->GetCommandComponent();
	if (!ensure(CommandComp))
	{
		return false;
	}

	AP3Character* SourceCharacter = Cast<AP3Character>(&Params.SourceActor);
	
	if (!SourceCharacter)
	{
		SourceCharacter = Cast<AP3Character>(Params.SourceActor.GetInstigator());
	}

	float DamageFactionMultiplier = 1.0f;

	if (SourceCharacter && TargetCharacter->GetFaction() == SourceCharacter->GetFaction())
	{
		DamageFactionMultiplier = Params.AllyDamagePermil * 0.001f;
	}
	
	const float ProjectileDamageMultiplier = Params.Projectile ? Params.Projectile->GetDamageMultiplier() : 1.0f;
	const float DamageMultiplier = Params.DamagePermil * 0.001f;

	const float Damage = ((_RollDice_CalcDamage(Params.SourceActor, Params.TargetActor, PartDamageParams.bIgnoreArmor) 
		* DamageMultiplier * PartDamageParams.PartDamageMultiplier * ProjectileDamageMultiplier * DamageRatio) + Params.TrueDamage) * DamageFactionMultiplier;

	FP3CommandRequestParams CommandParams;
	CommandParams.ApplyDamage_AttackStrength = AttackStrength;
	CommandParams.ApplyDamage_DamageAmount = Damage;
	CommandParams.ApplyDamage_bIsCriticalPart = PartDamageParams.bIsCriticalPart;
	CommandParams.ApplyDamage_bIsArmorPart = PartDamageParams.bIsArmorPart;
	CommandParams.ApplyDamage_SourceActor = &Params.SourceActor;
	CommandParams.ApplyDamage_WorldImpactDirection = Params.ImpactDirection;
	CommandParams.ApplyDamage_HitLocation = Params.TargetActor.GetActorLocation();	
	CommandParams.ApplyDamage_PartIndex = PartDamageParams.PartIndex;
	CommandParams.ApplyDamage_PartName = PartDamageParams.PartComponent ? PartDamageParams.PartComponent->GetFName() : NAME_None;
	CommandParams.ApplyDamage_WeaponType = Params.WeaponType;
	CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Damage;

	if (Params.HitLocation)
	{
		CommandParams.ApplyDamage_HitLocation = *Params.HitLocation;
	}
	else if (Params.BoneName.IsValid() && TargetCharacter->GetMesh())
	{
		CommandParams.ApplyDamage_HitLocation = TargetCharacter->GetMesh()->GetSocketLocation(Params.BoneName);
	}

	CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);

	// Apply part damage
	if (PartDamageParams.PartComponent)
	{
		if (!PartDamageParams.PartComponent->IsDamagedAnyTypesOnly()
			|| PartDamageParams.PartComponent->CanBeDamagedByTemporaryWeaponType(Params.TemporaryWeaponType))
		{
			PartDamageParams.PartComponent->Server_SetHealthPoint(PartDamageParams.PartComponent->Server_GetHealthPoint() - Damage);
		}
	}

	FPointDamageEvent PointDamageEvent;
	PointDamageEvent.Damage = Damage;
	PointDamageEvent.HitInfo.Component = Params.TargetComponent;
	PointDamageEvent.HitInfo.Item = Params.TargetHitItemIndex;
	Params.TargetActor.TakeDamage(Damage, PointDamageEvent, nullptr, &Params.SourceActor);
	
	return true;
}

static bool _Server_DamageNonCharacterWithReaction(const FDamageActorParams& Params, const FPartDamageParams& PartDamageParams)
{
	AP3Destructible* TargetDestructible = Cast<AP3Destructible>(&Params.TargetActor);

	const float ProjectileDamageMultiplier = Params.Projectile ? Params.Projectile->GetDamageMultiplier() : 1.0f;
	const float DamageMultiplier = TargetDestructible ? Params.DamageDestructiblePermil * 0.001f : Params.DamagePermil * 0.001f;
	const float Damage = (_RollDice_CalcDamage(Params.SourceActor, Params.TargetActor, PartDamageParams.bIgnoreArmor) 
		* DamageMultiplier * PartDamageParams.PartDamageMultiplier * ProjectileDamageMultiplier) + Params.TrueDamage;

	UP3CommandComponent* CommandComp = Params.TargetActor.FindComponentByClass<UP3CommandComponent>();
	if (CommandComp)
	{
		FP3CommandRequestParams CommandParams;
		CommandParams.ApplyDamage_AttackStrength = Params.AttackStrength;
		CommandParams.ApplyDamage_DamageAmount = Damage;
		CommandParams.ApplyDamage_bIsCriticalPart = PartDamageParams.bIsCriticalPart;
		CommandParams.ApplyDamage_bIsArmorPart = PartDamageParams.bIsArmorPart;
		CommandParams.ApplyDamage_SourceActor = &Params.SourceActor;
		CommandParams.ApplyDamage_WorldImpactDirection = Params.ImpactDirection;
		CommandParams.ApplyDamage_HitLocation = Params.TargetActor.GetActorLocation();
		CommandParams.ApplyDamage_WeaponType = Params.WeaponType;
		CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Damage;

		if (Params.HitLocation)
		{
			CommandParams.ApplyDamage_HitLocation = *Params.HitLocation;
		}

		CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
	}
	else // No Command component on target actor
	{
		if (Params.TargetActor.IsA(AInstancedFoliageActor::StaticClass()) && ensure(Params.TargetComponent))
		{
			P3Core::GetP3World(Params.TargetActor)->Server_DamageFoliage(Params.TargetActor, *Params.TargetComponent, Params.TargetHitItemIndex);
		}
		else
		{
			UP3World* P3World = P3Core::GetP3World(Params.TargetActor);

			if (P3World)
			{
				P3World->Server_DamageNonCommandActor(Params.TargetActor, Params.SourceActor, Damage, Params.TargetComponent, Params.TargetHitItemIndex, Params.HitLocation);
			}

			ChangeActorHealth(&Params.SourceActor, Params.TargetActor, -Damage, EP3HealthChangeReason::Damage);
		}
	}

	return true;
}

EP3GiveDamageResult Server_DamageActor(AP3Character* TargetCharacter, EP3ReactionLayer ReactionLayer)
{
	if (!TargetCharacter)
	{
		return EP3GiveDamageResult::NoEffect;
	}

	if (!ensure(P3Core::IsP3NetModeServerInstance(*TargetCharacter)))
	{
		return EP3GiveDamageResult::NoEffect;
	}

	AActor* SourceActor = TargetCharacter;

	UP3CombatResponseComponent* CombatResponseComp = TargetCharacter->GetP3CombatResponseoComponent();
	if (ensure(CombatResponseComp) && CombatResponseComp->GetLastUpdateAttackerActor())
	{
		SourceActor = CombatResponseComp->GetLastUpdateAttackerActor();
	}

	FDamageActorParams Params(*SourceActor, *TargetCharacter);
	EAnimNotifyAttackDirectionFlags AttackDirection = EAnimNotifyAttackDirectionFlags::Left;
	EAnimNotifyAttackStrengthFlags AttackStrength = EAnimNotifyAttackStrengthFlags::Small;
	EAnimNotifyAttackPartFlags AttackPart = EAnimNotifyAttackPartFlags::Body;
	const int32 ReactionOverlapCount = CombatResponseComp ? CombatResponseComp->GetOverlapCount() : 0;
	const int32 IncrememAttackStrengthOverlapCount = 3;

	const FP3CmsCombatHit* CmsCombatHit = CombatResponseComp ? P3Cms::GetCombatHit(CombatResponseComp->GetLastUpdateCmsCombatHitKey()) : nullptr;
	if (CmsCombatHit)
	{
		AttackDirection = CmsCombatHit->AttackDirection;
		AttackStrength = CmsCombatHit->AttackStrength;

		if (ReactionOverlapCount > IncrememAttackStrengthOverlapCount)
		{
			switch (AttackStrength)
			{
			case EAnimNotifyAttackStrengthFlags::Small:
			{
				AttackStrength = EAnimNotifyAttackStrengthFlags::Medium;
				break;
			}
			case EAnimNotifyAttackStrengthFlags::Medium:
			{
				AttackStrength = EAnimNotifyAttackStrengthFlags::Large;
				break;
			}
			case EAnimNotifyAttackStrengthFlags::Large:
			{
				AttackStrength = EAnimNotifyAttackStrengthFlags::ExtraLarge;
				break;
			}
			}
		}
	}
	
	const FP3CombatReactionRow* ReactionRow = Server_GetCharacterTargetReactionCms(ReactionLayer, Params, TargetCharacter, AttackDirection, AttackStrength, AttackPart);
	if (!ReactionRow)
	{
		ReactionRow = Server_GetCharacterTargetReactionCms(ReactionLayer, TargetCharacter);
	}

	if (ensure(ReactionRow))
	{
		const bool bCanStartReaction = Server_CharacterTargetReaction(ReactionLayer, ReactionRow, Params, TargetCharacter, AttackPart);
		Server_CharacterTargetVFX(ReactionLayer, ReactionRow, Params.HitLocation, Params.ImpactDirection, Params.AttackAttribute, TargetCharacter);

		if (bCanStartReaction)
		{
			return EP3GiveDamageResult::HitAction;
		}
	}
	
	return EP3GiveDamageResult::NoEffect;
}

EP3GiveDamageResult Server_DamageActor(const FDamageActorParams& Params)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(Params.SourceActor)))
	{
		return EP3GiveDamageResult::NoEffect;
	}

	EP3GiveDamageResult DamageResult = EP3GiveDamageResult::NoEffect;
	bool bHitOnEquipment = false;

	AP3Character* SourceCharacter = Cast<AP3Character>(&Params.SourceActor);
	AP3Character* TargetCharacter = Cast<AP3Character>(&Params.TargetActor);
	AP3Weapon* TargetEquipmentActor = nullptr;

	if (!TargetCharacter)
	{
		TargetEquipmentActor = Cast<AP3Weapon>(&Params.TargetActor);
		if (TargetEquipmentActor)
		{
			TargetCharacter = Cast<AP3Character>(Params.TargetActor.GetAttachParentActor());
			if (TargetCharacter)
			{
				bHitOnEquipment = true;
			}
		}
	}

	AP3Tree* TargetTree = Cast<AP3Tree>(&Params.TargetActor);
	AP3SwitchActor* TargetSwitch = Cast<AP3SwitchActor>(&Params.TargetActor);
	bool bTargetIsEnemy = true;
	bool bIsPKMode = false;

	AP3AIController* AIController = TargetCharacter ? Cast<AP3AIController>(TargetCharacter->GetController()) : nullptr;
	if (AIController && AIController->IsReturningFromCombat())
	{
		return EP3GiveDamageResult::NoEffect;
	}

	UP3CombatComponent* TargetCombatComp = TargetCharacter ? TargetCharacter->FindComponentByClass<UP3CombatComponent>() : nullptr;
	if (TargetCombatComp)
	{
		if (Params.Projectile)
		{
			TargetCombatComp->Server_UpdateUnreachableActorList(SourceCharacter);

			if (TargetCombatComp->IsIgnoreUnreachableActorAttack(SourceCharacter))
			{
				return EP3GiveDamageResult::NoEffect;
			}
		}		
	}

	UP3CombatResponseComponent* TargetCombatResponseComp = TargetCharacter ? TargetCharacter->GetP3CombatResponseoComponent() : nullptr;
	if (TargetCombatResponseComp)
	{
		TargetCombatResponseComp->SetLastUpdateAttackerActor(&Params.SourceActor);
		TargetCombatResponseComp->SetLastUpdateCmsCombatHitKey(Params.CmsCombatHitKey);		
	}
	
	if (TargetTree)
	{
		TargetTree->Server_SleepTree(false);
	}

	if (TargetSwitch)
	{
		const bool bOn = TargetSwitch->IsSwitchOn();
		TargetSwitch->Server_ToggleSwitch(!bOn);
	}

	if (TargetCharacter && SourceCharacter)
	{
		bTargetIsEnemy = TargetCharacter->GetFaction() != SourceCharacter->GetFaction();
		bIsPKMode = CVarP3CombatPKMode.GetValueOnGameThread() == 1 && SourceCharacter->IsControlled() && TargetCharacter->IsControlled();
	}
	
	if (!Params.bCanDamageAlly && !bTargetIsEnemy)
	{
		if (!bIsPKMode)
		{
			return EP3GiveDamageResult::NoEffect;
		}
	}

	FPartDamageParams PartDamageParams;
	Server_GetTargetPartDamageParam(PartDamageParams, Params, TargetCharacter);

	if (TargetCharacter)
	{
		FP3CharacterBuff CharacterBuff;
		Server_GetCharacterTargetReactionOverrideBuffer(TargetCharacter, CharacterBuff);

		if (!CharacterBuff.bCanReaction && !CharacterBuff.bCanDamage)
		{
			return EP3GiveDamageResult::NoEffect;
		}

		EP3ReactionLayer TargetReactionLayer = EP3ReactionLayer::None;
		EAnimNotifyAttackDirectionFlags AttackDirection = Params.AttackDirection;
		EAnimNotifyAttackStrengthFlags AttackStrength = Params.AttackStrength;
		EAnimNotifyAttackPartFlags AttackPart = EAnimNotifyAttackPartFlags::Body;

		if (bHitOnEquipment && TargetEquipmentActor)
		{
			UP3HoldableComponent* HoldableComp = TargetEquipmentActor->GetHoldableComponent();
			UP3HolderComponent* HolderComp = HoldableComp ? HoldableComp->GetHolderComponent() : nullptr;

			if (HolderComp)
			{
				AttackPart = (HolderComp->GetHoldType() == EP3HoldType::LeftHand) ? EAnimNotifyAttackPartFlags::LeftHolder : EAnimNotifyAttackPartFlags::RightHolder;;
			}
		}

		if (CharacterBuff.OverrideReactionLayer == EP3ReactionLayer::None)
		{
			TargetReactionLayer = Server_GetCharacterTargetReactionLayer(Params, TargetCharacter);
		}
		else
		{
			TargetReactionLayer = CharacterBuff.OverrideReactionLayer;
		}

		if (CharacterBuff.OverrideAttackDirection != EAnimNotifyAttackDirectionFlags::None)
		{
			AttackDirection = CharacterBuff.OverrideAttackDirection;
		}

		if (CharacterBuff.OverrideAttackStrength != EAnimNotifyAttackStrengthFlags::Ignore)
		{
			AttackStrength = CharacterBuff.OverrideAttackStrength;
		}

		if (!CharacterBuff.bCanReaction)
		{
			if (TargetReactionLayer == EP3ReactionLayer::Dead || TargetReactionLayer == EP3ReactionLayer::Downed)
			{
				CharacterBuff.bCanReaction = true;
			}
		}
		
		const FP3CombatReactionRow* ReactionRow = Server_GetCharacterTargetReactionCms(TargetReactionLayer, Params, TargetCharacter, AttackDirection, AttackStrength, AttackPart);
		
		if (ReactionRow)
		{				
			if (Params.bCanDamageAlly && bTargetIsEnemy)
			{
				if (!ReactionRow->bCanDamageAlly)
				{
					return EP3GiveDamageResult::NoEffect;
				}
			}

			if (CharacterBuff.bCanReaction)
			{
				const bool bTakeReaction = Server_CharacterTargetReaction(TargetReactionLayer, ReactionRow, Params, TargetCharacter, AttackPart);
				if (bTakeReaction)
				{
					DamageResult = EP3GiveDamageResult::HitAction;
				}
			}

			if (CharacterBuff.bCanDamage)
			{
				if (TargetReactionLayer == EP3ReactionLayer::Guard)
				{
					DamageResult = EP3GiveDamageResult::Blocked;
				}
				else
				{
					if (TargetReactionLayer == EP3ReactionLayer::Dead)
					{
						DamageResult = EP3GiveDamageResult::HitAction;
					}
					else
					{
						const bool bTakeDamage = _Server_DamageCharacterWithReaction(AttackStrength, ReactionRow, Params, PartDamageParams, TargetCharacter);
						if (bTakeDamage)
						{
							if (DamageResult == EP3GiveDamageResult::NoEffect)
							{
								if (!ReactionRow->CmsDamageCameraShakeKey.IsNone() && TargetCharacter->GetCommandComponent())
								{
									FP3CommandRequestParams CommandParams;
									CommandParams.CmsCameraShakeKey = ReactionRow->CmsDamageCameraShakeKey;
									CommandParams.CameraShakeLocation = TargetCharacter->GetActorLocation();
									CommandParams.CameraShakeActor = TargetCharacter;
									TargetCharacter->GetCommandComponent()->RequestCommand(UP3CameraShakeCommand::StaticClass(), CommandParams);								
								}
							}

							DamageResult = EP3GiveDamageResult::HitAction;
						}
					}
				}				
			}

			if (DamageResult != EP3GiveDamageResult::NoEffect)
			{
				Server_CharacterTargetVFX(TargetReactionLayer, ReactionRow, Params.HitLocation, Params.ImpactDirection, Params.AttackAttribute, TargetCharacter);
			}
		}
		else
		{
			if (CharacterBuff.bCanDamage)
			{
				if (TargetReactionLayer == EP3ReactionLayer::Guard)
				{
					DamageResult = EP3GiveDamageResult::Blocked;
				}
				else
				{
					if (TargetReactionLayer == EP3ReactionLayer::Dead)
					{
						DamageResult = EP3GiveDamageResult::HitAction;
					}
					else
					{
						const bool bTakeDamage = _Server_DamageCharacterWithReaction(AttackStrength, ReactionRow, Params, PartDamageParams, TargetCharacter);
						if (bTakeDamage)
						{
							DamageResult = EP3GiveDamageResult::HitAction;
						}
					}
				}				
			}
		}

		EP3ReactionLayer SourceReactionLayer = TargetReactionLayer;
		const FP3CombatReactionRow* SourceReactionRow = Server_CharacterSourceReaction(SourceReactionLayer, Params, SourceCharacter);
		if (SourceReactionRow)
		{
			Server_CharacterTargetVFX(SourceReactionLayer, SourceReactionRow, Params.HitLocation, Params.ImpactDirection, Params.AttackAttribute, SourceCharacter);
		}
	}
	else
	{
		_Server_DamageNonCharacterWithReaction(Params, PartDamageParams);			
	}	

	if (DamageResult != EP3GiveDamageResult::NoEffect && !Params.CmsCameraShakeKey.IsNone())
	{
		if (SourceCharacter && SourceCharacter->GetCommandComponent())
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.CmsCameraShakeKey = Params.CmsCameraShakeKey;
			CommandParams.CameraShakeLocation = SourceCharacter->GetActorLocation();
			CommandParams.CameraShakeActor = SourceCharacter;
			SourceCharacter->GetCommandComponent()->RequestCommand(UP3CameraShakeCommand::StaticClass(), CommandParams);
		}
	}

	return DamageResult;
}

void Multicast_ApplyDamageByCommand(AActor& TargetActor, AActor* SourceActor, int32 Damage, int32 PartIndex,
	EP3WeaponType WeaponType, EP3HealthChangeReason Reason, const UP3Command& Command)
{
	AP3Character* TargetCharacter = Cast<AP3Character>(&TargetActor);

	const bool bWasDead = (TargetCharacter != nullptr) && TargetCharacter->IsDead();
	const bool bIsDowned = (TargetCharacter != nullptr) && TargetCharacter->IsDowned();

	if (P3Core::IsP3NetModeServerInstance(TargetActor))
	{
		if (TargetCharacter)
		{
			UP3AggroComponent* AggroComp = TargetCharacter->GetAggroComponentBP();
			if (AggroComp)
			{
				AggroComp->OnHit(SourceActor, Damage);
			}

			AP3AIController* AIController = Cast<AP3AIController>(TargetCharacter->GetController());
			if (AIController)
			{
				AIController->OnHit(SourceActor, Damage);
			}
		}

		AP3Character* SourceCharacter = Cast<AP3Character>(SourceActor);

		if (SourceCharacter && SourceCharacter->IsPlayerControlled())
		{
			if (Damage > 0)
			{
				if (TargetCharacter && TargetCharacter->GetFaction() != SourceCharacter->GetFaction())
				{
					P3Contribution::Server_AddPoint(SourceCharacter, EP3ContributionType::DamageEnemy, Damage);
				}

				if (TargetCharacter && TargetCharacter->GetFaction() == SourceCharacter->GetFaction())
				{
					P3Contribution::Server_AddPoint(SourceCharacter, EP3ContributionType::DamageAlly, Damage);
				}

				if (TargetCharacter && TargetCharacter->IsLarge())
				{
					P3Contribution::Server_AddPoint(SourceCharacter, EP3ContributionType::DamageToBoss, Damage);
				}
			}

			if (Damage < 0)
			{
				if (TargetCharacter && TargetCharacter->GetFaction() == SourceCharacter->GetFaction())
				{
					P3Contribution::Server_AddPoint(SourceCharacter, EP3ContributionType::HealAlly, Damage);
				}
			}
		}
	}

	UP3HealthPointComponent* HealthComp = TargetCharacter ? TargetCharacter->GetP3HealthComponentBP() : TargetActor.FindComponentByClass<UP3HealthPointComponent>();
	if (HealthComp)
	{
		if (bIsDowned)
		{
			UP3CharacterHealthPointComponent* CharacterHealthComp = Cast<UP3CharacterHealthPointComponent>(HealthComp);
			if (P3Core::IsP3NetModeServerInstance(TargetActor) && ensure(CharacterHealthComp))
			{
				CharacterHealthComp->Server_ReduceDownedHealthPoint(Damage);
			}
		}
		else
		{
			HealthComp->SetHealthPoint(HealthComp->GetHealthPoint() - Damage);
		}
	}

	{
		const FString SourceName = SourceActor ? SourceActor->GetName() : FString("Unknown");
		P3JsonLogWithCategory(P3CombatLog, Verbose, "HP changed",
			TEXT("Source"), *SourceName,
			TEXT("Target"), TargetActor.GetName(),
			TEXT("Amount"), -Damage,
			TEXT("Part"), PartIndex,
			TEXT("WeaponType"), *EnumToStringShort(EP3WeaponType, WeaponType),
			TEXT("Reason"), *EnumToStringShort(EP3HealthChangeReason, Reason));
	}

	if (CVarP3AutoDrawWeaponOnApplyDamage.GetValueOnGameThread() > 0)
	{
		if (TargetCharacter && TargetCharacter->GetStance() != EP3CharacterStance::Combat && !bIsDowned)
		{
			TargetCharacter->SetStanceByCommand(Command, EP3CharacterStance::Combat, true);
		}
	}

	if (TargetCharacter && PartIndex != -1)
	{
		TargetCharacter->SetPartHealthPoint(PartIndex, TargetCharacter->GetPartHealthPoint(PartIndex) - Damage);
	}

	AP3Character* SourceCharacter = Cast<AP3Character>(SourceActor);

	UP3ComboTableComponent* ComboComp = SourceCharacter ? SourceCharacter->GetComboComponent() : nullptr;
	if (ComboComp)
	{
		ComboComp->OnReceiveDamage(TargetCharacter);
	}

	ComboComp = TargetCharacter ? TargetCharacter->GetComboComponent() : nullptr;
	if (ComboComp)
	{
		ComboComp->OnGiveDamage(SourceCharacter);
	}

	// Damage meters
	if (P3Core::IsP3NetModeServerInstance(TargetActor))
	{
		UP3DamageMetersComponent* TargetDamageMetersComp = TargetActor.FindComponentByClass<UP3DamageMetersComponent>();
		if (TargetDamageMetersComp)
		{
			TargetDamageMetersComp->Server_AddDamage(SourceActor, Damage);
		}

		if (SourceActor)
		{
			UP3DamageMetersComponent* SourceDamageMetersComp = SourceActor->FindComponentByClass<UP3DamageMetersComponent>();
			if (SourceDamageMetersComp)
			{
				if (SourceCharacter && SourceCharacter->IsLarge())
				{
					UP3CombatComponent* TargetCharacterComp = TargetActor.FindComponentByClass<UP3CombatComponent>();
					if (TargetCharacterComp)
					{
						TargetCharacterComp->Server_SetLastDamageSource(SourceCharacter);
					}
				}
			}
		}
	}
}

bool ChangeActorHealth(AActor* SourceActor, AActor& TargetActor, int32 Amount, EP3HealthChangeReason Reason)
{
	UP3HealthPointComponent* HealthComp = TargetActor.FindComponentByClass<UP3HealthPointComponent>();
	if (!HealthComp)
	{
		return false;
	}

	if (!ChangeActorHealth(SourceActor, *HealthComp, Amount, Reason))
	{
		return false;
	}

	return true;
}

bool ChangeActorHealth(AActor* SourceActor, AP3Character& TargetCharacter, int32 Amount, EP3HealthChangeReason Reason)
{
	UP3HealthPointComponent* HealthComp = TargetCharacter.GetP3CharacterHealthComponentBP();
	if (!HealthComp)
	{
		return false;
	}

	if (!ChangeActorHealth(SourceActor, *HealthComp, Amount, Reason))
	{
		return false;
	}

	return true;
}

bool ChangeActorHealth(AActor* SourceActor, UP3HealthPointComponent& HealthComp, int32 Amount, EP3HealthChangeReason Reason)
{
	HealthComp.SetHealthPoint(HealthComp.GetHealthPoint() + Amount);

	const FString SourceName = SourceActor ? SourceActor->GetName() : FString("Unknown");
	const FString TargetName = HealthComp.GetOwner() ? HealthComp.GetOwner()->GetName() : FString("Unknown");
	P3JsonLogWithCategory(P3CombatLog, Verbose, "HP changed without command",
		TEXT("Source"), *SourceName,
		TEXT("Target"), *TargetName,
		TEXT("Amount"), Amount,
		TEXT("Reason"), *EnumToStringShort(EP3HealthChangeReason, Reason));

	return true;
}

static bool _IsInFrontOf(const AActor& Source, const AActor& Target)
{
	FVector SourceLocation = Source.GetActorLocation();
	const FVector SourceFoward = Source.GetActorForwardVector();
	const ACharacter* TargetCharacter = Cast<ACharacter>(&Target);

	if (TargetCharacter && TargetCharacter->GetCapsuleComponent())
	{
		// Step back source location
		SourceLocation = SourceLocation - SourceFoward * TargetCharacter->GetCapsuleComponent()->GetScaledCapsuleRadius();
	}

	return FVector::DotProduct(SourceFoward, Target.GetActorLocation() - SourceLocation) >= 0.0f;
}

static TArray<AActor*> _OverlapMultiByCylindricalSector(const AP3Character& MyCharacter, float Radius, float HalfHeight, bool bFrontOnly, bool bDebug)
{
	TArray<AActor*> OverlappedResults;

	if (!MyCharacter.GetWorld())
	{
		return OverlappedResults;
	}

	static const FName TraceTag("P3OverlapMultiByCylinder");

	FCollisionQueryParams CollisionQueryParams;

	if (bDebug)
	{
		CollisionQueryParams.TraceTag = TraceTag;
	}

	TArray<FOverlapResult> CapsuleOverlapResults;
	{
		FCollisionObjectQueryParams QueryParams;
		QueryParams.AddObjectTypesToQuery(ECC_Pawn);

		FCollisionShape CollisionShape;
		CollisionShape.SetCapsule(Radius, HalfHeight + Radius);

		MyCharacter.GetWorld()->OverlapMultiByObjectType(CapsuleOverlapResults, MyCharacter.GetActorLocation(), FQuat::Identity, QueryParams, CollisionShape, CollisionQueryParams);
	}

	TArray<FOverlapResult> BoxOverlapResults;
	{
		FCollisionObjectQueryParams QueryParams;
		QueryParams.AddObjectTypesToQuery(ECC_Pawn);

		FCollisionShape CollisionShape;
		CollisionShape.SetBox(FVector(Radius, Radius, HalfHeight));

		MyCharacter.GetWorld()->OverlapMultiByObjectType(BoxOverlapResults, MyCharacter.GetActorLocation(), FQuat::Identity, QueryParams, CollisionShape, CollisionQueryParams);
	}

	// Find actors overlapped two shapes
	for (FOverlapResult& Result : CapsuleOverlapResults)
	{
		AActor* Actor = Result.GetActor();

		if (!Actor)
		{
			continue;
		}

		const bool bOverlapWithBox = BoxOverlapResults.ContainsByPredicate([Actor](const FOverlapResult& R) { return R.GetActor() == Actor; });

		if (!bOverlapWithBox)
		{
			continue;
		}

		if (bFrontOnly && !_IsInFrontOf(MyCharacter, *Actor))
		{
			continue;
		}

		OverlappedResults.AddUnique(Actor);
	}

	if (bDebug)
	{
		const bool bDrawLine = true;
		const FColor DebugDrawColor(255, 0, 0, 30);
		const FColor LineColor(DebugDrawColor.R, DebugDrawColor.G, DebugDrawColor.B, 255);
		const float LineThickness = 0.0f;
		if (bFrontOnly)
		{
			P3DrawDebugSolidCylindricalSector(*MyCharacter.GetWorld(), MyCharacter.GetActorLocation(), MyCharacter.GetActorForwardVector(), MyCharacter.GetActorRightVector(),
				Radius, PI, HalfHeight * 2.0f, 16, DebugDrawColor, bDrawLine, LineColor, LineThickness, false, 0.5f, 0);
		}
		else
		{
			P3DrawDebugSolidCylinder(*MyCharacter.GetWorld(), MyCharacter.GetActorLocation(), MyCharacter.GetActorForwardVector(), MyCharacter.GetActorRightVector(),
				Radius, HalfHeight * 2.0f, 16, DebugDrawColor, bDrawLine, LineColor, LineThickness, false, 0.5f, 0);
		}
	}

	return OverlappedResults;
}

static TArray<AActor*> _OverlapMultiByHemiSphere(const AP3Character& MyCharacter, float Radius, bool bFrontOnly, bool bDebug)
{
	TArray<AActor*> OverlappedResults;

	if (!MyCharacter.GetWorld())
	{
		return OverlappedResults;
	}

	static const FName TraceTag("P3OverlapMultiByHemiSphere");

	FCollisionQueryParams CollisionQueryParams;

	if (bDebug)
	{
		CollisionQueryParams.TraceTag = TraceTag;
	}

	FCollisionObjectQueryParams QueryParams;
	QueryParams.AddObjectTypesToQuery(ECC_Pawn);

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(Radius);

	TArray<FOverlapResult> OverlapResults;
	MyCharacter.GetWorld()->OverlapMultiByObjectType(OverlapResults, MyCharacter.GetActorLocation(), FQuat::Identity, QueryParams, CollisionShape, CollisionQueryParams);

	for (FOverlapResult& Result : OverlapResults)
	{
		AActor* Actor = Result.GetActor();

		if (!Actor)
		{
			continue;
		}

		if (bFrontOnly && !_IsInFrontOf(MyCharacter, *Actor))
		{
			continue;
		}

		OverlappedResults.AddUnique(Actor);
	}

	if (bDebug)
	{
		const bool bDrawLine = true;
		const FColor DebugDrawColor(255, 0, 0, 30);
		const FColor LineColor(DebugDrawColor.R, DebugDrawColor.G, DebugDrawColor.B, 255);
		const float LineThickness = 0.0f;
		if (bFrontOnly)
		{
			P3DrawDebugSolidSphericalWedge(*MyCharacter.GetWorld(), MyCharacter.GetActorLocation(), MyCharacter.GetActorForwardVector(), MyCharacter.GetActorRightVector(), Radius, PI,
				16, DebugDrawColor, false, 0.5f, 0, LineThickness);
		}
		else
		{
			P3DrawDebugSolidSphere(*MyCharacter.GetWorld(), MyCharacter.GetActorLocation(),
				Radius, 16, DebugDrawColor, false, 0.5f, 0);
		}
	}

	return OverlappedResults;
}

static bool _CanSeeTargetActor(const AActor& Source, const AActor& Target, bool bDebug)
	{
	UWorld* World = Source.GetWorld();

	if (!World)
	{
		return false;
	}

	FCollisionQueryParams CollisionQueryParams;
	CollisionQueryParams.AddIgnoredActor(&Source);
	CollisionQueryParams.AddIgnoredActor(&Target);

	FVector SourceLocation;
	FRotator SourceRotation;
	Source.GetActorEyesViewPoint(SourceLocation, SourceRotation);

	// Try target location first

	FVector TargetLocation = Target.GetTargetLocation();

	FHitResult HitResult;
	bool bOccluded = Source.GetWorld()->LineTraceSingleByChannel(HitResult, SourceLocation, TargetLocation, ECC_Visibility, CollisionQueryParams);

	if (bDebug)
	{
		FVector DebugTargetLocation = bOccluded ? HitResult.Location : TargetLocation;
		FColor DebugColor = bOccluded ? FColor::Red : FColor::Green;
		DrawDebugDirectionalArrow(World, SourceLocation, DebugTargetLocation, 100.0f, DebugColor, false, 0.5f);
	}

	if (!bOccluded)
	{
		return true;
	}

	// If target has capsule, give another chance

	const ACharacter* TargetCharacter = Cast<ACharacter>(&Target);

	if (!TargetCharacter || !TargetCharacter->GetCapsuleComponent())
	{
		return false;
	}

	// Try top of capsule

	TargetLocation.Z = TargetCharacter->GetActorLocation().Z + TargetCharacter->GetCapsuleComponent()->GetScaledCapsuleHalfHeight();

	bOccluded = Source.GetWorld()->LineTraceSingleByChannel(HitResult, SourceLocation, TargetLocation, ECC_Visibility, CollisionQueryParams);

	if (bDebug)
	{
		FVector DebugTargetLocation = bOccluded ? HitResult.Location : TargetLocation;
		FColor DebugColor = bOccluded ? FColor::Red : FColor::Green;
		DrawDebugDirectionalArrow(World, SourceLocation, DebugTargetLocation, 100.0f, DebugColor, false, 0.5f);
	}

	if (!bOccluded)
	{
		return true;
	}

	// Try bottom of capsule

	TargetLocation.Z = TargetCharacter->GetActorLocation().Z - TargetCharacter->GetCapsuleComponent()->GetScaledCapsuleHalfHeight();

	bOccluded = Source.GetWorld()->LineTraceSingleByChannel(HitResult, SourceLocation, TargetLocation, ECC_Visibility, CollisionQueryParams);

	if (bDebug)
	{
		FVector DebugTargetLocation = bOccluded ? HitResult.Location : TargetLocation;
		FColor DebugColor = bOccluded ? FColor::Red : FColor::Green;
		DrawDebugDirectionalArrow(World, SourceLocation, DebugTargetLocation, 100.0f, DebugColor, false, 0.5f);
	}

	if (!bOccluded)
	{
		return true;
	}

	return false;
}

AActor* FindTargetInRange(const AP3Character& MyCharacter, float Radius, bool bFrontOnly)
{
	if (!MyCharacter.GetWorld())
	{
		return nullptr;
	}

	bool bDebug = false;
	if (CVarP3AIRangeDebug.GetValueOnGameThread())
	{
		const int32 DebugActorId = CVarP3AIRangeDebugActor.GetValueOnGameThread();
		bDebug = (DebugActorId == 0 || MyCharacter.GetActorId() == DebugActorId);
	}

	TArray<AActor*> OverlappedResults = _OverlapMultiByHemiSphere(MyCharacter, Radius, bFrontOnly, bDebug);

	float MaxDistanceSquared = 10E10;
	AActor* NewTargetActor = nullptr;

	for (AActor* OverlappedActor : OverlappedResults)
	{
		if (!ensure(OverlappedActor))
		{
			continue;
		}

		AP3Character* OverlappedCharacter = Cast<AP3Character>(OverlappedActor);

		if (OverlappedCharacter)
		{
			if (OverlappedCharacter->IsDeadOrDowned())
			{
				continue;
			}

			if (OverlappedCharacter->GetFaction() == MyCharacter.GetFaction())
			{
				continue;
			}
		}

		if (!_CanSeeTargetActor(MyCharacter, *OverlappedActor, bDebug))
		{
			continue;
		}

		const float DistanceSquared = (OverlappedActor->GetActorLocation() - MyCharacter.GetActorLocation()).SizeSquared();

		if (MaxDistanceSquared > DistanceSquared)
		{
			MaxDistanceSquared = DistanceSquared;
			NewTargetActor = OverlappedActor;
		}
	}

	return NewTargetActor;
}

AActor* FindTargetForAI(const AP3Character& MyCharacter, float SearchRange, bool bSearchFrontOnly, float AggroRangeLimit)
{
	AP3AIController* AICon = Cast<AP3AIController>(MyCharacter.GetController());

	if (AICon && AICon->GetForceTarget())
	{
		return AICon->GetForceTarget();
	}

	UP3AggroComponent* AggroComp = MyCharacter.FindComponentByClass<UP3AggroComponent>();

	// Try to find new target
	AActor* NewTargetActor = FindTargetInRange(MyCharacter, SearchRange, bSearchFrontOnly);

	if (NewTargetActor && AggroComp)
	{
		AggroComp->OnSight(NewTargetActor);
	}

	if (AggroComp)
	{
		// See if we have anything on aggro table

		NewTargetActor = nullptr;

		const float AggroRangeLimitSquared = AggroRangeLimit * AggroRangeLimit;
		const TArray<FP3AggroItem>& AggroItems = AggroComp->GetSortedAggroItems();

		for (const FP3AggroItem& AggroItem : AggroItems)
		{
			AActor* Actor = AggroItem.Actor.Get();
			if (!Actor)
			{
				continue;
			}

			float DistanceSquared = FVector::DistSquared(MyCharacter.GetActorLocation(), Actor->GetActorLocation());
			if (DistanceSquared > AggroRangeLimitSquared)
			{
				continue;
			}

			AP3Character* Character = Cast<AP3Character>(Actor);
			if (Character && Character->GetCharacterStoreBP().MountTargetCharacter == &MyCharacter)
			{
				// You cannot attack your rider
				continue;
			}

			if (Character && Character->IsInForbiddenVolume())
			{
				// You cannot attack character in forbidden volume.
				continue;
			}

			if (Character && Character->IsDead())
			{
				continue;
			}

			if (Character && Character->GetCharacterStoreBP().bNoTargetMode)
			{
				continue;
			}

			if (Character && Character->GetCharacterStoreBP().bOnQuestCutscene)
			{
				continue;
			}

			NewTargetActor = Actor;
			break;
		}
	}

	return NewTargetActor;
}

const static void _GetPartBoneNames(const AActor& Actor, TSet<FName>& OutBoneNames)
{
	TInlineComponentArray<UP3PartComponent*, 8> PartComponents;
	Actor.GetComponents(PartComponents);

	for (UP3PartComponent* PartComp : PartComponents)
	{
		for (const FName& BoneName : PartComp->GetPartDesc().HitAreaBones)
		{
			OutBoneNames.Add(BoneName);
		}
	}
}

void Server_Explode(AActor& SourceActor, const FVector& Location, float Radius, float Damage, int32 AllyDamagePermil, float ImpulseVelocity, bool bKnockDown, float KnockDownDurationSeconds, const TArray<AActor*>& IgnoreActors)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(SourceActor)))
	{
		return;
	}

	if (!SourceActor.GetWorld())
	{
		return;
	}

	TArray<AActor*> OverlapActors;

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(Radius);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActors(IgnoreActors);

	TArray<FHitResult> HitResults;
	SourceActor.GetWorld()->SweepMultiByChannel(HitResults, Location, Location + FVector(0, 0, 1), FQuat::Identity, ECC_COMBAT, CollisionShape, QueryParams);

	HitResults.Sort([&Location](const FHitResult& A, const FHitResult& B) -> bool
	{
		AActor* ActorA = A.GetActor();
		AActor* ActorB = B.GetActor();

		if (ActorA && ActorA == ActorB)
		{
			TSet<FName> PartBoneNames;
			_GetPartBoneNames(*ActorA, PartBoneNames);

			const bool bIsAPart = PartBoneNames.Contains(A.BoneName);
			const bool bIsBPart = PartBoneNames.Contains(B.BoneName);

			if (bIsAPart && !bIsBPart)
			{
				return true;
			}

			if (bIsBPart && !bIsAPart)
			{
				return false;
			}
			
			const AP3Character* CharacterA = Cast<AP3Character>(ActorA);
			const AP3Character* CharacterB = Cast<AP3Character>(ActorB);
			const FVector LocationA = (A.BoneName.IsValid() && CharacterA && CharacterA->GetMesh()) 
				? CharacterA->GetMesh()->GetSocketLocation(A.BoneName) : ActorA->GetActorLocation();
			const FVector LocationB = (B.BoneName.IsValid() && CharacterB && CharacterB->GetMesh())
				? CharacterB->GetMesh()->GetSocketLocation(B.BoneName) : ActorB->GetActorLocation();

			const float DistanceA = (LocationA - Location).SizeSquared();
			const float DistanceB = (LocationB - Location).SizeSquared();

			return (DistanceA < DistanceB);
		}

		return ActorA < ActorB;
	});

	TArray<AActor*> HitActors;

	for (const FHitResult& HitResult : HitResults)
	{
		// TODO: prefer part, like combat component

		AActor* Actor = HitResult.GetActor();
		if (!Actor)
		{
			continue;
		}

		if (HitActors.Contains(Actor))
		{
			continue;
		}

		HitActors.Add(Actor);

		P3Combat::FDamageActorParams DamageParams(SourceActor, *Actor);
		DamageParams.AttackStrength = EAnimNotifyAttackStrengthFlags::ExtraLarge;
		DamageParams.AttackDirection = EAnimNotifyAttackDirectionFlags::Push;
		DamageParams.AttackAttribute = EP3AnimNotifyAttackAttribute::Bash;
		DamageParams.TargetComponent = HitResult.GetComponent();
		DamageParams.TargetHitItemIndex = HitResult.FaceIndex;
		DamageParams.BoneName = HitResult.BoneName;
		DamageParams.WeaponType = EP3WeaponType::None;
		DamageParams.TrueDamage = Damage;
		DamageParams.AllyDamagePermil = AllyDamagePermil;
		DamageParams.DamagePermil = 0;
		DamageParams.ImpactDirection = (Actor->GetActorLocation() - Location).GetSafeNormal();

		P3Combat::Server_DamageActor(DamageParams);
	}
}

} // P3Combat
