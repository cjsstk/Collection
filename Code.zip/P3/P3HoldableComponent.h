// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3HoldType.h"
#include "P3WeaponType.h"
#include "P3HoldableComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3HoldableComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3HoldableComponent();
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void SetHolderComponent(class UP3HolderComponent* InHolderComponent);
	class UP3HolderComponent* GetHolderComponent() const { return HolderComponent; }

	/**
	 * Interact Lock
	 */
	bool Server_IsInteractionLocked() const { return Server_bIsInteractionLocked; }
	void Server_SetInteractionLock(class UP3PickupHoldablePawnAction* InLockerAction, bool bInInteractionLocked);

protected:
	virtual void BeginPlay() override;

private:
	UPROPERTY()
	class UP3HolderComponent* HolderComponent = nullptr;

	/** If this is true, Can't interact  */
	bool Server_bIsInteractionLocked = false;

	/** This component locked by this action */
	UPROPERTY(Transient)
	UP3PickupHoldablePawnAction* LockerAction = nullptr;
};

bool P3GetMuzzleLocation(const AActor& WeaponActor, FVector& OutLocation);
