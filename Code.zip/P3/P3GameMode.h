// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameModeBase.h"
#include "P3GameMode.generated.h"

/**
 * P3 Game Mode
 */
UCLASS(minimalapi)
class AP3GameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	AP3GameMode();

	float GetAverageFrameTimeMsec() const { return AverageFrameTimeMsec; }

	UFUNCTION(BlueprintCallable)
	static class USkeleton* GetSkeletonFromAnimation(const class UAnimationAsset* AnimationAsset);

	class UP3BGMPlayer* GetBGMPlayer() const { return BGMPlayer; }

	class UP3PlayerReviver* GetPlayerReviver() const { return Server_PlayerReviver; }

protected:
	virtual void PreInitializeComponents() override;
	virtual void InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage) override;
	virtual FString InitNewPlayer(APlayerController* NewPlayerController, const FUniqueNetIdRepl& UniqueId, const FString& Options, const FString& Portal = TEXT("")) override;
	virtual void StartPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual APawn* SpawnDefaultPawnFor_Implementation(AController* NewPlayer, AActor* StartSpot) override;

private:
	void Server_SetPlayerReviver(class UP3PlayerReviver* NewPlayerReviver);

	float AverageFrameTimeMsec = 0.0f;

	UPROPERTY(Transient)
	class UP3PlayerReviver* Server_PlayerReviver = nullptr;

	UPROPERTY(Transient)
	class UP3BGMPlayer* BGMPlayer = nullptr;

	bool bStopZoneAutoChange = false;
};
