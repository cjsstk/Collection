// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "GameplayTagAssetInterface.h"

#include "P3ActorInterface.h"
#include "P3AnimalCharacter.generated.h"

UCLASS()
class P3_API AP3AnimalCharacter : public ACharacter, public IGameplayTagAssetInterface, public IP3ActorInterface
{
	GENERATED_BODY()

public:
	AP3AnimalCharacter(const FObjectInitializer& ObjectInitializer);

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	virtual void SpawnDefaultController() override;

	/**
	 * Network
	 */
	virtual void NetSerializeMovement(FArchive& Archive);


	/** IGameplayTagAssetInterface */
	virtual void GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const override;

	/**
	 * IP3ActorInterface
	 */
	virtual actorid GetActorId() const { return ActorId; }
	virtual void SetActorId(actorid Id) { ActorId = Id; }
	virtual void AddGameplayTags(const struct FGameplayTagContainer& TagContainer) override;
	virtual void RemoveGameplayTags(const struct FGameplayTagContainer& TagContainer) override;
	virtual void AddDebugString(const FString& InDebugString, bool bAddNewLine = true) override;
	virtual void NetSerialize(FArchive& Archive) override;
	virtual class UP3StoreComponent* GetStoreComponent() const;
	virtual bool IsLevelPersistence() const override { return bLevelPersistence; }

	UFUNCTION(BlueprintCallable)
	class UP3HealthPointComponent* GetP3HealthComponentBP() const { return HealthComponent; }

protected:
	virtual void PostActorCreated() override;

	/** If true, Client will load this actor from level and sync from server by name (instead of spawn new actor) */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bLevelPersistence = false;

private:
	void Server_Tick(float DeltaSeconds);
	void TickIgnoreMoveInput();

	UFUNCTION()
	void OnDead();

	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer GameplayTagContainer;

	/** Store Component */
	UPROPERTY(Transient)
	class UP3StoreComponent* StoreComponent;

	/** Attribute Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3AttributesComponent* AttributeComponent;

	/** Health Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3HealthPointComponent* HealthComponent;

	/** Ragdoll Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3RagdollComponent* RagdollComponent;

	/** Command Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3CommandComponent* CommandComponent;

	actorid ActorId = INVALID_ACTORID;

	/** AController::IgnoreMoveInput is stack based, so we have to track our own value here to avoid conflict */
	bool bIgnoredMoveInput = false;

	/** Debug string */
	FString DebugString;
};
