// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CharacterSpeedModifierComponent.h"
#include "P3CharacterEffectComponent.h"
#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "GameFramework/Actor.h"
#include "GameFramework/Character.h"

UP3CharacterSpeedModifierComponent::UP3CharacterSpeedModifierComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
}

void UP3CharacterSpeedModifierComponent::BeginPlay()
{
	Super::BeginPlay();
	
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		SetComponentTickEnabled(true);

		GetOwner()->OnActorBeginOverlap.AddUniqueDynamic(this, &UP3CharacterSpeedModifierComponent::OnBeginOverlap);
		GetOwner()->OnActorEndOverlap.AddUniqueDynamic(this, &UP3CharacterSpeedModifierComponent::OnEndOverlap);
	}
}

void UP3CharacterSpeedModifierComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	ensure(P3Core::IsP3NetModeServerInstance(*this));

	if (!ensure(GetOwner()))
	{
		return;
	}

	for (ACharacter* Character : OverlappedCharacters)
	{
		if (Character)
		{
			UP3CharacterEffectComponent* EffectComp = Character->FindComponentByClass<UP3CharacterEffectComponent>();
			if (EffectComp)
			{
				const float NewSpeedMultiplier = GetSpeedMultiplierForActor(Character);

				EffectComp->SetMoveSpeedEffect(EffectLayer, NewSpeedMultiplier, this);
			}
		}
	}
}

void UP3CharacterSpeedModifierComponent::OnBeginOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	ACharacter* Character = Cast<ACharacter>(OtherActor);
	if (Character)
	{
		OverlappedCharacters.AddUnique(Character);
	}
}

void UP3CharacterSpeedModifierComponent::OnEndOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	ACharacter* Character = Cast<ACharacter>(OtherActor);
	if (Character)
	{
		const int32 Index = OverlappedCharacters.Remove(Character);
		ensure(Index != INDEX_NONE);

		UP3CharacterEffectComponent* EffectComp = Character->FindComponentByClass<UP3CharacterEffectComponent>();
		if (EffectComp)
		{
			EffectComp->SetMoveSpeedEffect(EffectLayer, 1.0f, nullptr);
		}
	}
}
