// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PhysicsVolume.h"
#include "P3SwampVolume.generated.h"

/**
 * 
 */
UCLASS(Blueprintable)
class P3_API AP3SwampVolume : public APhysicsVolume
{
	GENERATED_BODY()
	
	AP3SwampVolume();

protected:
	// Called when actor enters a volume
	virtual void ActorEnteredVolume(class AActor* Other) override;
	
	// Called when actor leaves a volume, Other can be NULL
	virtual void ActorLeavingVolume(class AActor* Other) override;		
};
