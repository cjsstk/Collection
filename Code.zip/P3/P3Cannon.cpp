// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Cannon.h"

#include "Engine/World.h"

#include "Chemical/P3FlammableComponent.h"
#include "P3Core.h"
#include "P3ServerWorld.h"
#include "P3World.h"

static TAutoConsoleVariable<int32> CVarP3CannonDebug(
	TEXT("p3.cannonDebug"),
	0,
	TEXT("1: Enable Debug, 0: Disable Debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CannonBallInsertCount(
	TEXT("p3.cannonBallInsertCount"),
	1,
	TEXT("How many cannonball will be inserted on each drop?"), ECVF_Cheat);


AP3Cannon::AP3Cannon()
{
	PrimaryActorTick.bCanEverTick = true;

}

void AP3Cannon::BeginPlay()
{
	Super::BeginPlay();
	
	UP3FlammableComponent* FlammableComp = FindComponentByClass<UP3FlammableComponent>();
	if (P3Core::IsP3NetModeServerInstance(*this) && FlammableComp)
	{
		FlammableComp->OnFire.AddUniqueDynamic(this, &AP3Cannon::Fire);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetCurrentCannonBall(DefaultNumLoadedCannonBalls);
	}

}

void AP3Cannon::Fire(bool bOnFire)
{
	if (!bOnFire)
	{
		if ((Server_bCanFire && !Net_bIsOverloaded) || Server_bIsInfiniteCannonBall)
		{
			static const FName SpawnLocationTag = FName(TEXT("ProjectileSpawnLocation"));
			TArray<UActorComponent*> SpawnLocationComps = GetComponentsByTag(USceneComponent::StaticClass(), SpawnLocationTag);

			USceneComponent* SpawnLocationComp = Cast<USceneComponent>(SpawnLocationComps[0]);

			if (!ensure(SpawnLocationComp))
			{
				return;
			}

			const FTransform SpawnTransform = SpawnLocationComp->GetComponentTransform();

			AP3Actor* Actor = GetWorld()->SpawnActor<AP3Actor>(SpawnProjectileClass.Get(), SpawnTransform);

			if (!Server_bIsInfiniteCannonBall)
			{
				Server_SetCurrentCannonBall(Net_NumLoadedCannonBalls - 1);

				if (++Server_NumFired >= MaxFireCount)
				{
					SetOverloaded(true);
				}
			}
		}
	}
}

void AP3Cannon::Server_SetCurrentCannonBall(int32 NewCurrentCannonBall)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const int32 OldBalls = Net_NumLoadedCannonBalls;

	Net_NumLoadedCannonBalls = NewCurrentCannonBall;

	if (Net_NumLoadedCannonBalls == 0)
	{
		Server_EnableFire(false);
	}
	else if (Net_NumLoadedCannonBalls < 0)
	{
		Server_bIsInfiniteCannonBall = true;
	}
	else
	{
		Server_EnableFire(true);
	}

	if (Net_NumLoadedCannonBalls != OldBalls)
	{
		ReceiveCannonBallChanged(OldBalls, Net_NumLoadedCannonBalls);
	}

	Server_SetDirty(*this);
}

void AP3Cannon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (CVarP3CannonDebug.GetValueOnGameThread() > 0)
	{
		AddDebugString(FString::Printf(TEXT("Balls: %d"), Net_NumLoadedCannonBalls));
		AddDebugString(FString::Printf(TEXT("IsOverload: %s"), Net_bIsOverloaded ? TEXT("true") : TEXT("false")));
	}
}

void AP3Cannon::Reset()
{
	Super::Reset();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetCurrentCannonBall(DefaultNumLoadedCannonBalls);
		SetOverloaded(false);
		Server_NumFired = 0;
	}
}

void AP3Cannon::SetOverloaded(bool bInOverloaded)
{
	Net_bIsOverloaded = bInOverloaded;

	OnChangeOverloadedBP(bInOverloaded);
	
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetDirty(*this);
	}
}

void AP3Cannon::Server_AddCannonBalls(int32 InNum)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_SetCurrentCannonBall(Net_NumLoadedCannonBalls + InNum);
}

void AP3Cannon::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	if (Archive.IsLoading())
	{
		const int32 OldCannonballs = Net_NumLoadedCannonBalls;
		const bool OldOverload = Net_bIsOverloaded;

		Archive << Net_NumLoadedCannonBalls;
		Archive << Net_bIsOverloaded;

		if (Net_NumLoadedCannonBalls != OldCannonballs)
		{
			ReceiveCannonBallChanged(OldCannonballs, Net_NumLoadedCannonBalls);
		}

		if (Net_bIsOverloaded != OldOverload)
		{
			SetOverloaded(Net_bIsOverloaded);
		}
	}
	else
	{
		Archive << Net_NumLoadedCannonBalls;
		Archive << Net_bIsOverloaded;
	}
}

void AP3CannonBallInserter::Server_OnSignal(bool bOn)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (CannonActor && bOn)
	{
		CannonActor->Server_AddCannonBalls(CVarP3CannonBallInsertCount.GetValueOnGameThread());
	}
}
