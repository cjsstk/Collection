// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "Network/Lib/P3NetCore.h"
#include "P3StoreInterface.h"
#include "P3DamageMetersComponent.generated.h"

USTRUCT()
struct FP3DamageMeter
{
	GENERATED_BODY()

	UPROPERTY()
	FString SourceName;

	UPROPERTY()
	int32 DamageAmount = 0;

	/** How many times owner kills source actor? */
	UPROPERTY()
	int32 NumKills = 0;
};

USTRUCT()
struct FP3DamageMetersStore
{
	GENERATED_BODY()

	/** Key: Source Actor Id */
	UPROPERTY()
	TMap<int32, FP3DamageMeter> Meters;

	UPROPERTY()
	int32 Version = 0;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3DamageMetersComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	virtual void OnRegister() override;
	virtual void OnUnregister() override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	const FP3DamageMetersStore& GetMetersStore() const { return Net_MetersStore; }
	void Server_AddDamage(AActor* SourceActor, int32 Damage);
	void Server_AddKill(AActor* SourceActor);

protected:
	virtual void BeginPlay() override;

private:
	FP3DamageMeter* FindOrAddMeter(AActor* SourceActor);

	UPROPERTY(Transient)
	FP3DamageMetersStore Net_MetersStore;
};
