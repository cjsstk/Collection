// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AchievementComponent.h"


UP3AchievementComponent::UP3AchievementComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}

void UP3AchievementComponent::BeginPlay()
{
	Super::BeginPlay();

	// ...
	
}

void UP3AchievementComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// ...
}

void UP3AchievementComponent::AddAchievement(EAchievementCategory Category, FP3AchievementContent Content, FP3AchievementReward Reward)
{
	UP3Achievement* NewAchievement = nullptr;
	switch (Category)
	{
	case EAchievementCategory::Invalid:
		return;
	case EAchievementCategory::Amount:
		NewAchievement = NewObject<UP3AmountAchievement>();
		break;
	case EAchievementCategory::Visit:
		break;
	case EAchievementCategory::Find:
		break;
	default:
		ensure(0);
		return;
	}

	if (NewAchievement)
	{
		NewAchievement->OnRegister(Content, Reward);
		Achievements.Add(NewAchievement);
	}
}

void UP3AchievementComponent::UpdateAchievementContent(FP3AchievementUpdateParams Params)
{
	UP3Achievement* Achievement = GetAchievement(Params.AchievementCategory, Params.AchievementExplanation);

	if (Achievement)
	{
		if (Achievement->IsCompleted())
		{
			/** This Achievement Completed already */
			return;
		}

		switch (Achievement->GetAchievementCategory())
		{
		case EAchievementCategory::Invalid:
			return;
		case EAchievementCategory::Amount:
			Achievement->SetAchievementCurrentCount(Achievement->GetAchievementCurrentCount() + Params.Amount_AddedNumberToAmount);
			break;
		case EAchievementCategory::Visit:
			break;
		case EAchievementCategory::Find:
			break;
		default:
			ensure(0);
			return;
		}

		Achievement->OnChangeValue();
	}
}

UP3Achievement* UP3AchievementComponent::GetAchievement(EAchievementCategory Category, FString Explanation) const
{
	if (Category == EAchievementCategory::Invalid)
	{
		return nullptr;
	}

	for (auto Achieve : Achievements)
	{
		if (Achieve->GetAchievementCategory() == Category && Achieve->GetAchievementExplanation() == Explanation)
		{
			return Achieve;
		}
	}

	/** have no this Achievement */
	ensure(0);
	return nullptr;
}

void UP3Achievement::OnRegister(FP3AchievementContent Content, FP3AchievementReward Reward)
{
	AchievementContent = Content;
	AchievementReward = Reward;
}

void UP3Achievement::OnComplete()
{
	/** Receive Reward? */
}

void UP3Achievement::SetAchievementCurrentCount(const int32 InCount)
{
	AchievementContent.Amount_CurrentNumberToAmount = InCount;
}

void UP3AmountAchievement::OnChangeValue()
{
	Super::OnChangeValue();

	if (AchievementContent.Amount_CurrentNumberToAmount >= AchievementContent.Amount_GoalNumberToAmount)
	{
		bCompleted = true;
		OnComplete();
	}
}
