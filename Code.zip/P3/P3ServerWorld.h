// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "Network/Lib/P3NetCore.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/dedilistener.pb.h"
#include "Network/pb/game.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/dedilistener.pb.h"
#include "Network/pb/game.pb.h"
#endif

#include "P3Core.h"
#include "P3Cms.h"
#include "P3Version.h"
#include "P3WorldNetCore.h"

#include "P3ServerWorld.generated.h"

using ProtobufMessage = ::google::protobuf::Message;

/**
 * Cached actor transform
 * used to optimize transform sync bandwidth
 */
struct FP3CachedActorTransform
{
	float LastSentTime = 0;
	FP3NetActorTransform ActorTransform;
	TArray<uint8> CharacterMovement;
	TMap<TWeakObjectPtr<UObject>, FP3NetActorComponentTransform> ActorComponentTransform;
};

/**
 * Server side status of each player
 */
struct FP3PlayerStatus
{
	bool bHasValidPawn = false;
	TArray<int64> OwnActorIds;
};


/** 
 * Visibility of each player in server side
 */
struct FP3PlayerSight
{
	/** Actors which sent to client */
	TSet<int64> ActorIds;

	/** Actor transform which sent to client. Share index with ClientActorIds */
	TMap<int64, FP3CachedActorTransform> ActorTransforms;

	/** 
	 * Actors which client failed to spawn. Server will wait little bit and send again 
	 * actorid -> wait delay in seconds
	 */
	TMap<int64, float> SpawnFailedActorIds;

	/** 
	 * When actor is added or removed from server, this queue gets updates for every players
	 * This queue will be cleared once player gets informed
	 */
	TArray<int64> Pending_AddedActors;
	TArray<int64> Pending_RemovedActors;

	/** To avoid sync error, we flush sync for every actor once a while */
	float LastMovementFlushTimeSeconds = 0;
};

UCLASS()
class UP3ServerPlayer : public UObject
{
	GENERATED_BODY()

public:
	FP3NetConnInfo NetConnInfo;
	charid CharacterId;
	FName Name;
	EP3CharClass CharClass;
	int32 CharLevel;
	FP3Version Version;
	partyid PartyId = NON_PARTY_ID;

	UPROPERTY(Transient)
	class AP3ServerPlayerController* PlayerController;

	FP3PlayerStatus Status;
	FP3PlayerSight Sight;

	float LastTODSyncedTimeSeconds = 0;
	bool bReadyToPlay = true;
};

/**
 * Server side actor data
 * some data are derived from actor as a cache to optimize sync process
 */
struct FP3ServerActor
{
	struct FMovement
	{
		/** If true, actor's movement replication is enabled */
		bool bReplicateMovement = false;

		/**
		 * Following values are only valid when bReplicateMovement == true
		 */

		bool bPossessedBySequence = false;

		/** If true, actor is attached to some other actor */
		bool bAttached = false;

		/** If true, actor is physics-simulation enabled */
		bool bPhysicsSimulating = false;

		/** If true, actor's simulation is in sleep. Only valid if bPhysicsSimulating == true */
		bool bPhysicsSleeping = false;

		/** Frame number of last replicated movement cache update */
		uint32 ReplicatedMovementCachedFrame = 0;

		/**
		 * Following values are only valid when ReplicatedMovementCachedFrame == SyncFrame
		 */

		FP3NetMovement CachedNetMovement;

		/** set true if CachedNetMovement is changed */
		bool bCacheIsDirty = false;

		/** Too make things faster, we serialize movement here for every player */
		TArray<uint8> CachedNetMovementData;

		/**
		 * Character movement packet
		 */
		TArray<uint8> CachedCharacterMovementData;
		bool bCachedCharacterMovementDataDirty = false;

		/**
		 * Animal movement packet
		 */
		TArray<uint8> CachedAnimalMovementData;
		bool bCachedAnimalMovementDataDirty = false;

		/**
		 * Attached transform packet
		 * Only valid when bAttached is true
		 */
		TArray<uint8> CachedAttachedTransformData;
		bool bCachedAttachedTransformDataDirty = false;

		/**
		 * Component movement packets
		 */
		struct FComponent
		{
			TWeakObjectPtr<USceneComponent> Component;
			TArray<uint8> CachedTransformData;
			bool bCachedTransformDataDirty = false;
		};
		TArray<FComponent> Components;
	};

	struct FMovementSync
	{
		float LastSyncTime = 0.0f;
	};

	actorid ActorId = INVALID_ACTORID;
	TWeakObjectPtr<AActor> ActorPtr;
	FMovement Movement;
	FMovementSync MovementSync;

	void UpdateReplicatedMovement(UP3World* P3World, uint32 Frame);
};

UCLASS()
class UP3ServerWorld : public UObject
{
	GENERATED_BODY()

public:
	void BeginPlay(class UP3World* InP3World);
	void Shutdown();

	void RegisterToDediman(const FString& DedimanDirect);

	void Tick(float DeltaSeconds);
	
	void NetOnPlayerDisconnected(const FP3NetConnInfo& NetConnInfo);

	void SyncActors();
	void SyncTimeOfDay();

	/** Players */
	void SyncPlayerList();
	void OnCharacterLevelChanged(const class AP3Character& Character);
	const UP3ServerPlayer* FindPlayerByName(const FName& Name) const;
	const UP3ServerPlayer* FindPlayerByConnInfo(const FP3NetConnInfo& NetConnInfo, bool bFromArray = false) const;
	const TArray<UP3ServerPlayer*>& GetPlayers() const { return Players; };

	/** Characters */
	const TArray<class AP3Character*>& GetCharacters() const { return CharacterActors; }

	/** Dirty actors */
	void AddDirtyActor(actorid ActorId);
	void AddDirtyComponent(actorid ActorId, const FName& ComponentName);

	bool IsPlayerControlledActor(actorid ActorId) const;
	FP3NetConnInfo GetPlayerConnInfoFromActor(const AActor& Actor) const;
	FP3NetConnInfo GetPlayerConnInfoFromActorId(actorid ActorId) const;
	FP3NetConnInfo GetPlayerConnInfoFromCharId(charid CharId) const;
	TArray<FP3NetConnInfo> GetPlayerConnInfos() const;
	TArray<int64> GetPlayerOwnActorIds(const FP3NetConnInfo& NetConnInfo) const;
	
	bool SendPacketBufferToPlayer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bCheckPlayerStatus, bool bReliable) const;
	bool MulticastPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const;
	void HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header);

	void SendWorldMessageToWorldServer(const FP3NetConnInfo& NetConn, const pb::C2DWorldMessage& WorldMessage);
	void SendWorldMessageToClient(const FP3NetConnInfo& NetConn, enum pb::D2CWorldRelayMessageType RelayMessageType, const ProtobufMessage& RelayMessage);

	/** Message */
	void SendToastMessage(const AActor& Actor, const FText& Message);
	void SendToastMessageToAll(const FText& Message);

	/** Time of day */
	void SetTimeOfDayInSeconds(float Seconds);
	void SetGameTimeToTimeOfDayRatio(float Ratio);

	/** Networked Debug draw */
	void SendDebugDrawSphere(const FVector& Location, float Radius, const FColor& Color, float LifeTime = -1.0f);

	UFUNCTION()
	void HandleEnter(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void HandleClientSpawnActorFailed(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void HandleGMCommand(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void HandleAIControlCommand(const FP3ClientToDediHandlerParams& Params);

	/** Handle World Server packets */
	void HandleRegisterRes(const pb::WD2DDRegisterRes& Message);
	void HandleLoadCharacterRes(const pb::WD2DDLoadCharacterRes& Message);

	/**
	 * Packet handlers
	 */
	UFUNCTION()
	void HandleSyncActorTransform(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void HandleSyncActorMovement(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void HandleCharacterMovement(const FP3ClientToDediHandlerParams& Params);

	/** Dediman callback */
	UFUNCTION()
	void OnRegisterDediman(uint32 ZoneChannelId, bool bWasSuccessful);

	/** Admin */
	bool IsReady() const;
	FString GetPlayersAsJson() const;

	class UP3World* GetP3World() const { return P3World; }

	void DisconnectClient(const FP3NetConnInfo& NetConnInfo);

private:
	struct FDirtyActor
	{
		bool bActorDirty = false;
		bool bActorAndAllComponentsDirty = false;

		TSet<FName> ComponentNames;
	};

	void SyncActorsToPlayer(UP3ServerPlayer* Player);
	void SyncMovementToPlayer(UP3ServerPlayer& Player, FP3ServerActor& ServerActor);
	void SyncActorTransformToPlayer(UP3ServerPlayer* Player);
	void SendSyncDataToPlayer(UP3ServerPlayer* Player);

	void TickActors(float DeltaSeconds);

	void HandleEnterInternal(const FP3NetConnInfo& NetConnInfo, const pb::WD2DDLoadCharacterRes& Message, const struct FP3NetPlayerEnterWorld& NetEnter);

	UP3ServerPlayer* AddPlayer(const FP3NetConnInfo& NetConnInfo, charid CharacterId, const FString& Name, EP3CharClass CharClass, int32 CharLevel, const FP3Version& Version);
	void RemovePlayer(const FP3NetConnInfo& NetConnInfo);

	UP3ServerPlayer* FindPlayerByConnInfo(const FP3NetConnInfo& NetConnInfo, bool bFromArray = false);

	FP3ServerActor& AddServerActor(int32 ActorId, AActor& Actor);
	void UpdateServerActor(FP3ServerActor& ServerActor);
	void AddToSyncData(FP3ServerActor& ServerActor);

	void SyncActorStoreToPlayer(const UP3ServerPlayer* Player, actorid ActorId, const UP3ServerWorld::FDirtyActor* DirtyActor);
	void SyncMovementToPlayer(AActor* Actor, actorid ActorId, const FP3ServerActor& ServerActor, FP3CachedActorTransform &SentActorTransform, const bool bItHasBeenLongSinceLastSent, const float Now, const FP3NetConnInfo& NetConnInfo);
	
	bool IsSequencePossessedObject(const UObject& Object) const;

	UFUNCTION()
	void OnActorAdded(int64 ActorId, AActor* Actor);

	UFUNCTION()
	void OnActorRemoved(int64 ActorId, AActor* Actor);

	UPROPERTY(Transient)
	class UP3World* P3World;

	FString ZoneName;
	uint32 ZoneChannelId = 0;
	bool bWaitForDedimanResponse = false;
	bool bRegisteredToDedimanDirectly = false;
	bool bReady = false;

	/** Players who are waiting for character info from database. (Key: AccountId) */
	TMap<int64, FP3ClientToDediHandlerParams> EnteringPlayers;

	/** Players */
	UPROPERTY(Transient)
	TArray<UP3ServerPlayer*> Players;

	TMap<P3NetConnId, UP3ServerPlayer*> TCPPlayers;
	TMap<P3NetConnId, UP3ServerPlayer*> UDPPlayers;

	/** 
	 * Actors 
	 * contains server-side info of P3World::Actors
	 * updated on tick
	 */
	TMap<int32, FP3ServerActor> Actors;
	TArray<int64> Pending_AddedActors;
	TArray<int64> Pending_RemovedActors;

	/** Characters */
	UPROPERTY(Transient)
	TArray<class AP3Character*> CharacterActors;

	/** Sync */
	uint32 SyncFrame = 0;

	enum class ESyncDataType
	{
		ActorMovement,
		CharacterMovement,
		AnimalMovement,
		AttachedTransform,
		ComponentTansform
	};

	struct FSyncData
	{
		ESyncDataType SyncDataType = ESyncDataType::ActorMovement;
		actorid ActorId = INVALID_ACTORID;
		TWeakObjectPtr<AActor> Actor;
		TArray<uint8> PacketData;

	};

	TArray<FSyncData> SyncDataArray;

	/** Dirty Actor Map, actor id -> component names */
	TMap<int64, FDirtyActor> DirtyStoreActors;

	/** 
	 * Packet profiles
	 */
	mutable FP3WorldPacketProfile PacketProfileHistory;
	FP3WorldPacketProfile PacketProfileResult;
	float PacketProfileWritingSeconds = 0;
};
