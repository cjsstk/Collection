// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3PushableComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3PushableComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3PushableComponent();

	bool IsLockPushDirection() const { return bLockPushDirection; }

	void Server_AddPusher(class AActor& Pusher);
	void Server_RemovePusher(class AActor& Pusher);

private:
	/* If set true, pushing direction will be locked at start. Set this false if you want to rotate this object by pushing */
	UPROPERTY(EditDefaultsOnly, Category = "Pushable")
	bool bLockPushDirection = true;

	UPROPERTY(Transient)
	TArray<class AActor*> Server_Pushers;
};
