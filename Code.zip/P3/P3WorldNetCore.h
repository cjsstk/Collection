// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameplayTagContainer.h"

#include "P3Core.h"
#include "P3StoreArchive.h"
#include "P3WorldNetCore.generated.h"

const static FName NAME_ClientActor(TEXT("ClientActor"));
const static FName NAME_ServerActor(TEXT("ServerActor"));

UENUM()
enum class EP3NetComponentType : uint16
{
	None,
	/** Components */
	Command,
	Action,
	Health,
	CharacterMovement,
	Destructible,
	Quest,

	/** World Sub modules */
	ClientWorld,
	ServerWorld,

	/** UDP */
	ActorChannel,
};


USTRUCT()
struct FP3NetActorIdAndByteArray
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId;

	UPROPERTY()
	TArray<uint8> ByteArray;
};

USTRUCT()
struct FP3NetHeader
{
	GENERATED_BODY()

	UPROPERTY()
	EP3NetComponentType ComponentType = EP3NetComponentType::None;

	UPROPERTY()
	FName HandlerFunctionName;
};

USTRUCT()
struct FP3NetDummy
{
	GENERATED_BODY()
};

USTRUCT()
struct FP3NetActorId
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId;
};

USTRUCT()
struct FP3NetStoreData
{
	GENERATED_BODY()

	UPROPERTY()
	FString Name;

	UPROPERTY()
	FString ClassName;

	/** true if ActorComponent::CreationMethod is Instance. In this case, client must spawn component */
	UPROPERTY()
	bool bIsInstanceComponent = false;

	UPROPERTY()
	TArray<uint8> Buffer;
};


/**
 * Movement packet
 * @reference: FRepMovement
 */
USTRUCT()
struct FP3NetMovement
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId = INVALID_ACTORID;

	UPROPERTY()
	FVector LinearVelocity = FVector::ZeroVector;

	UPROPERTY()
	FVector AngularVelocity = FVector::ZeroVector;
	
	UPROPERTY()
	FVector Location = FVector::ZeroVector;

	UPROPERTY()
	FRotator Rotation = FRotator::ZeroRotator;

	/** If set, RootComponent should be sleeping. */
	UPROPERTY()
	uint8 bSimulatedPhysicSleep : 1;

	/** If set, additional physic data (angular velocity) will be replicated. */
	UPROPERTY()
	uint8 bRepPhysics : 1;

	bool Equals(const FP3NetMovement& Other) const
	{
		if (!LinearVelocity.Equals(Other.LinearVelocity))
		{
			return false;
		}

		if (!AngularVelocity.Equals(Other.AngularVelocity))
		{
			return false;
		}

		if (!Location.Equals(Other.Location))
		{
			return false;
		}

		if (!Rotation.Equals(Other.Rotation))
		{
			return false;
		}

		if (bSimulatedPhysicSleep != Other.bSimulatedPhysicSleep)
		{
			return false;
		}

		if (bRepPhysics != Other.bRepPhysics)
		{
			return false;
		}

		return true;
	}
};


/**
 * Since FTransform is vectorized and cannot be serialized easily, we need net type
 * TODO: consider packing
 */
USTRUCT()
struct FP3NetTransform
{
	GENERATED_BODY()

	FORCEINLINE FP3NetTransform()
		: Rotation(0.f, 0.f, 0.f, 1.f)
		, Translation(0.f)
		, Scale3D(FVector::OneVector)
		, Velocity(FVector::ZeroVector)
	{
	}

	FORCEINLINE explicit FP3NetTransform(const FTransform& Transform)
		: Rotation(Transform.GetRotation())
		, Translation(Transform.GetTranslation())
		, Scale3D(Transform.GetScale3D())
	{
	}

	FORCEINLINE FP3NetTransform& operator = (const FTransform& Transform)
	{
		Rotation = Transform.GetRotation();
		Translation = Transform.GetTranslation();
		Scale3D = Transform.GetScale3D();

		return *this;
	}

	FORCEINLINE FTransform ToTransform() const
	{
		return FTransform(Rotation, Translation, Scale3D);
	}

	friend FArchive& operator<<(FArchive& Ar, FP3NetTransform& V)
	{
		Ar << V.Rotation;
		Ar << V.Translation;
		Ar << V.Scale3D;
		Ar << V.Velocity;

		return Ar;
	}

	bool Serialize(FArchive& Ar)
	{
		Ar << Rotation;
		Ar << Translation;
		Ar << Scale3D;
		Ar << Velocity;

		return true;
	}

	UPROPERTY()
	FQuat Rotation;

	UPROPERTY()
	FVector	Translation;

	UPROPERTY()
	FVector	Scale3D;

	UPROPERTY()
	FVector Velocity;
};

/** 
 * Net packet for actor transform sync
 */
USTRUCT()
struct FP3NetActorTransform
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId = INVALID_ACTORID;
		
	/** If AttachedActorId is not invalid, this is local transform */
	UPROPERTY()
	FP3NetTransform Transform = FP3NetTransform(FTransform::Identity);

	UPROPERTY()
	bool bAttached = false;

	UPROPERTY()
	USceneComponent* AttachedComponent = nullptr;

	UPROPERTY()
	FName AttachedSocketName = NAME_None;

	bool Equals(const FP3NetActorTransform& Other) const
	{
		if (!Transform.ToTransform().Equals(Other.Transform.ToTransform()))
		{
			return false;
		}

		if (AttachedComponent != Other.AttachedComponent)
		{
			return false;
		}

		if (AttachedSocketName != Other.AttachedSocketName)
		{
			return false;
		}

		return true;
	}


	friend FArchive& operator<<(FArchive& Ar, FP3NetActorTransform& N)
	{
		Ar << N.ActorId;
		Ar << N.Transform;
		Ar << N.bAttached;
		Ar << N.AttachedComponent;
		Ar << N.AttachedSocketName;

		return Ar;
	}
};

/** 
 * Net packet for actor component transform sync
 */
USTRUCT()
struct FP3NetActorComponentTransform
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId = INVALID_ACTORID;

	UPROPERTY()
	FString ComponentName;

	/** Note that this string could be invalid */
	UPROPERTY()
	FString AttachParentComponentName;
		
	/** If AttachedActorId is not invalid, this is local transform */
	UPROPERTY()
	FP3NetTransform Transform = FP3NetTransform(FTransform::Identity);

	/** TODO: Sorry */
	UPROPERTY()
	bool bHiddenInGame = false;

	bool Equals(const FP3NetActorComponentTransform& Other) const
	{
		if (AttachParentComponentName != Other.AttachParentComponentName)
		{
			return false;
		}

		if (!Transform.ToTransform().Equals(Other.Transform.ToTransform()))
		{
			return false;
		}

		if (bHiddenInGame != Other.bHiddenInGame)
		{
			return false;
		}

		return true;
	}

	friend FArchive& operator<<(FArchive& Ar, FP3NetActorComponentTransform& N)
	{
		Ar << N.ActorId;
		Ar << N.ComponentName;
		Ar << N.AttachParentComponentName;
		Ar << N.Transform;
		Ar << N.bHiddenInGame;

		return Ar;
	}
};

USTRUCT()
struct FP3NetSpawnActorParams
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId = INVALID_ACTORID;

	UPROPERTY()
	bool bLevelPersistence = false;

	// Only valid if bLevelPersistence == true
	UPROPERTY()
	FString LevelName;

	// Only valid if bLevelPersistence == true
	UPROPERTY()
	FString ActorName;

	/** TODO: change to cms id */
	UPROPERTY()
	FString ClassName;

	UPROPERTY()
	FVector Location;

	UPROPERTY()
	FRotator Rotation;

	UPROPERTY()
	FVector Scale3D;

	UPROPERTY()
	ESpawnActorCollisionHandlingMethod CollisionHandlingMethod;

	UPROPERTY()
	int64 StandaloneActorPointer = 0;

	UPROPERTY()
	TArray<FP3NetStoreData> StoreData;
	
	/** Time spent after spawn in server side. We need this on client side to decide whether play spawn effect or not */
	UPROPERTY()
	float GameTimeSinceCreation = 0;
};

/**
 * Time of Day
 */
USTRUCT()
struct FP3NetTimeOfDay
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeOfDayInSeconds = 0;

	/** Time of day = Game time * ratio */
	UPROPERTY()	
	float GameTimeToTimeOfDayRatio = 1.0f;
};

UENUM()
enum class EP3NetDebugDrawType
{
	Sphere
};

/**
 * Debug Draw
 */
USTRUCT()
struct FP3NetDebugDraw
{
	GENERATED_BODY()

	UPROPERTY()
	EP3NetDebugDrawType DebugDrawType = EP3NetDebugDrawType::Sphere;

	UPROPERTY()
	float SphereRadius = 0;

	/**
	 * Common data
	 */
	UPROPERTY()
	FVector Location = FVector::ZeroVector;

	UPROPERTY()
	FColor Color = FColor::White;

	UPROPERTY()
	float LifeTime = -1.0f;
};

/** 
 * "/p3gm" console command from Player Controller
 */
USTRUCT()
struct FP3NetGMCommand
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FString> Args;
};

/** 
 * AI Control command
 */
USTRUCT()
struct FP3NetAICommand
{
	GENERATED_BODY()

	UPROPERTY()
	bool bSetForceTargetPlayerName = false;

	UPROPERTY()
	FName ForceTargetPlayerName;

	UPROPERTY()
	FGameplayTag GameplayTag;
};

UENUM()
enum EP3WorldPacketProfileType
{
	// Note this is also a display order (for now)
	WPP_HandlerNameReceived = 0,
	WPP_ActorClassNameReceived,
	WPP_ActorNameReceived,
	WPP_HandlerNameSent,
	WPP_ActorNameSent,
	WPP_ActorClassNameSent,
	WPP_Count
};

struct FP3WorldPacketProfile
{
	/** Key: Type, Value: Num Packets */
	TMap<FName, int32> NumPackets[EP3WorldPacketProfileType::WPP_Count];
	float DurationSeconds = 0;
};

namespace P3WorldNet
{
	template<typename PacketType>
	bool BufferToPacket(UP3World* World, const TArray<uint8>& Buffer, PacketType& OutPacket)
	{
		// TODO: BitReader expect non const buffer strangely.... got to fix that...
		TArray<uint8> TmpBuffer = Buffer;
		FP3StoreBitReader BitReader(World, TmpBuffer.GetData(), TmpBuffer.Num() * sizeof(uint8) * 8);
		PacketType::StaticStruct()->SerializeBin(BitReader, &OutPacket);

		if (BitReader.IsError())
		{
			ensure(0);
			return false;
		}

		return true;
	}

	template<typename PacketType>
	bool BufferToPacketNonStruct(UP3World* World, const TArray<uint8>& Buffer, PacketType& OutPacket)
	{
		// TODO: BitReader expect non const buffer strangely.... got to fix that...
		TArray<uint8> TmpBuffer = Buffer;
		FP3StoreBitReader BitReader(World, TmpBuffer.GetData(), TmpBuffer.Num() * sizeof(uint8) * 8);
		
		BitReader << OutPacket;

		if (BitReader.IsError())
		{
			ensure(0);
			return false;
		}

		return true;
	}

} // P3WorldNet
