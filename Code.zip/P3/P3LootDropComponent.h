// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "GameplayTagContainer.h"
#include "P3LootDropComponent.generated.h"


namespace P3Loot
{
	const TArray<FP3LootDropResultItem> RollDice(const FP3LootItemContainer& Container);
	const FP3LootDropResultItem RollDiceAndPickOne(const FP3LootItemContainer& Container);
}

USTRUCT(Blueprintable)
struct FP3LootItem
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Category = P3)
	int32 ChancePer10000;

	UPROPERTY(EditAnywhere, Category = P3)
	TSubclassOf<AActor> SpawnActor;

	/** Optional socket name that actor should spawn from */
	UPROPERTY(EditAnywhere, Category = P3)
	FName SpawnSocketName;

	UPROPERTY(EditAnywhere, Category = P3)
	float LifeSpanAfterDrop = 180.0f;
};

USTRUCT(Blueprintable)
struct FP3LootItemContainer
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Category = P3)
	TArray<FP3LootItem> Items;
};

USTRUCT(Blueprintable)
struct FP3LootDropResultItem
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, Category = P3)
	TSubclassOf<AActor> SpawnActor;

	UPROPERTY(EditAnywhere, Category = P3)
	FName SpawnSocketName;

	UPROPERTY(EditAnywhere, Category = P3)
	float LifeSpanAfterDrop = 180.0f;
};

UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3LootDropComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	UP3LootDropComponent();

	void Server_RollDiceAndDrop();

	// TODO: maybe this bad choice, but this makes things so much easier to control drop timing in blueprint
	UFUNCTION(BlueprintCallable)
	void Server_RollDiceAndDropBP();

	void Server_AddLootItems(const FP3LootItemContainer& Container);

	bool HasItems() const { return ItemContainer.Items.Num() > 0; }

protected:
	virtual void BeginPlay() override;

private:
	void Server_Drop(const FP3LootDropResultItem& Item);

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FP3LootItemContainer ItemContainer;

	/** If this actor has this tag, do not drop */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FGameplayTagContainer NoDropGameplayTag;
};

/** 
 * This component will drop loot when HealthComponent broadcast Dead event
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3LootDropOnDeadComponent : public UP3LootDropComponent
{
	GENERATED_BODY()

protected:
	virtual void OnComponentCreated() override;
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void Server_BindToDeadEvent();

	UFUNCTION()
	void Server_OnDead();
};

/** 
 * This component will drop loot when Destructible Fracture
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3LootDropOnFractureComponent : public UP3LootDropComponent
{
	GENERATED_BODY()

protected:
	virtual void OnComponentCreated() override;
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void Server_BindToFractureEvent();

	UFUNCTION()
	void Server_OnFracture(class AP3Destructible* Destructible);

	UFUNCTION()
	void Server_OnComponentFracture(class UP3DestructibleComponent* DestructibleComponent);
};

/** 
 * This component will drop loot when Pickupable Component is being pickupped
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3LootDropOnPickupComponent : public UP3LootDropComponent
{
	GENERATED_BODY()

protected:
	virtual void OnComponentCreated() override;
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void Server_BindEvent();

	UFUNCTION()
	void Server_PickupStarted(class UP3PickupableComponent* PickupableComponent, class AActor* PickupperActor);

	/** If set > 0, once loot drop happens, loot drop will not happen for this time */
	UPROPERTY(EditDefaultsOnly, Category = "Loot Drop on Pickup")
	float CooldownSeconds = 0;

	float Server_NextCooldownFinishedTimeSeconds = 0;
};
