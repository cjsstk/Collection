// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3WalkType.generated.h"

UENUM(Blueprintable)
enum class EP3RouteWalkType : uint8
{
	Stroll,
	Walk,
	Sprint,
	Crippled
};
