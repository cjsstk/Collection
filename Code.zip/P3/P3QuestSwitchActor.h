// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3SwitchActor.h"
#include "P3QuestSwitchActor.generated.h"

UCLASS(Blueprintable)
class P3_API AP3QuestSwitchActor : public AP3SwitchActor
{
	GENERATED_BODY()

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
};

UCLASS(Blueprintable)
class P3_API AP3QuestBoxTriggeredSwitchActor : public AP3BoxTriggeredSwitchActor
{
	GENERATED_BODY()

public:
	int32 GetFilteredActorCount(TSubclassOf<class AP3Character> TargetActorClass) const;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
};
