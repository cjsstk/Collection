// Copyright 1998-2018 Epic Games, Inc. All Rights Reserved.
#pragma once
#include "GameFramework/Character.h"
#include "FlockManager.h"
#include "P3AnimalCharacter.h"
#include "CrowdTestChar.generated.h"

USTRUCT()
struct FCrowdTestStore
{
	GENERATED_BODY()

	UPROPERTY()
	bool bMale = false;

	UPROPERTY()
	float RandomScale = 1.0f;
};

USTRUCT()
struct FCrowdTestMovement
{
	GENERATED_BODY()

	UPROPERTY()
	float RequestedSpeed = 0;

	UPROPERTY()
	float RequestedSpeedSmoothed = 0;

	UPROPERTY()
	float TurnRateSmoothed = 0;

	UPROPERTY()
	float TurnDelta = 0;

	UPROPERTY()
	float TurnDeltaSmoothed = 0;

	UPROPERTY()
	float TurnAmount = 0;

	float UpDownAim = 0;
	float LeftRightAim = 0;
	float bPlayerNearby = 0;
};

/** One agent in a crowd */
UCLASS(Blueprintable)
class ACrowdTestChar : public AP3AnimalCharacter
{
	GENERATED_UCLASS_BODY()

	/** Weak pointer to the flock manager we are registered with */
	TWeakObjectPtr<class AFlockManager>	WeakFlockManager;

	virtual void PostInitializeComponents() override;
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;

	/**
	 * Network
	 */
	virtual void NetSerialize(FArchive& Archive) override;
	virtual void NetSerializeMovement(FArchive& Archive) override;

	const FCrowdTestMovement& GetCrowdMovement() const { return CrowdMovement; }

private:
	void ApplyStore();

protected:

	/** Auto register with the specified flock manager, or to a specific flock manager if specified */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Flock")
	bool bAutoRegisterWithFlockManager;

	/** Flock Manager to register to (only if bAutoRegisterWithFlockManager = true) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Flock")
	class AFlockManager* FlockManager;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Scale Variation")
	float HartBaseScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Scale Variation")
	float HartScaleVariance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Scale Variation")
	float HindBaseScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="Scale Variation")
	float HindScaleVariance;

	UPROPERTY(Transient)
	FRandomStream RandomStream;
	
	UPROPERTY(EditDefaultsOnly, Category = "Meshes")
	class USkeletalMesh* SkeletalMeshes[2];

	UPROPERTY(EditDefaultsOnly, Category = "Meshes")
	class UStaticMesh* AntlerMeshes[4];

	UPROPERTY()
	class UStaticMeshComponent* Antlers;

	FCrowdTestStore CrowdStore;
	FCrowdTestMovement CrowdMovement;
};
