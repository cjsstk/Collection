// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

UENUM()
enum class EP3ActionAnimationType : int32
{	
	None UMETA(Hidden),

	DrawWeapon,
	PutawayWeapon,

	NormalBlock,
	HardBlock,
	BreakBlock,
	BreakCrouchBlock,
	CounterAttack,	

	BreakfallForward,
	BreakfallRight,
	BreakfallLeft,
	BreakfallBackward,

	BreakfallAir,
	
	HitLeft,
	HitRight,	
	HitKnockDown,
	HitShortKnockBackForward,
	HitShortKnockBackBackward,
	HitShortKnockBackLeft,
	HitShortKnockBackRight,
	HitKnockBackForward,
	HitKnockBackBackward,
	HitKnockBackLeft,
	HitKnockBackRight,
	HitPushBackForward,
	HitPushBackBackward,
	HitPushBackLeft,
	HitPushBackRight,	
	Death,
	Stun,
	AttackBlocked,

	RollForward,
	RollForwardRight,
	RollRight,
	RollBackwardRight,
	RollBackward,
	RollBackwardLeft,
	RollLeft,
	RollForwardLeft,

	Count UMETA(Hidden),
};
