// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3GameState.h"

#include "Net/UnrealNetwork.h"
#include "Kismet/GameplayStatics.h"
#include "ParticleEmitterInstances.h"
#include "Particles/ParticleSystemComponent.h"
#include "Engine/World.h"

#include "P3Core.h"
#include "P3Log.h"
#include "P3World.h"

AP3GameState::AP3GameState()
{
}

void AP3GameState::HandleBeginPlay()
{
	GameResource = NewObject<UP3GameResource>(GetTransientPackage(), GameResourceClass);

	WorldParticleActor = GetWorld()->SpawnActor<AP3WorldParticleActor>();

	UP3World* World = P3Core::GetP3World(*this);

	if (World)
	{
		World->BeginPlay(GetWorld());
	}

	Super::HandleBeginPlay();
}

void AP3GameState::OnRep_ReplicatedHasBegunPlay()
{
	GameResource = NewObject<UP3GameResource>(GetTransientPackage(), GameResourceClass);

	Super::OnRep_ReplicatedHasBegunPlay();
}


const UP3GameRule& AP3GameState::GetGameRule() const
{
	if (GameRule)
	{
		return *GameRule;
	}
	else
	{
		return *Cast<UP3GameRule>(UP3GameRule::StaticClass()->ClassDefaultObject);
	}
}

AP3WorldParticleActor::AP3WorldParticleActor()
{
	RootSceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootSceneComponent"));

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = true;
	PrimaryActorTick.TickInterval = 0.1f;
}

void AP3WorldParticleActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	DeactivatedParticles.Remove(nullptr);

	const float Now = GetWorld()->GetTimeSeconds();

	TSet<UActorComponent*> Components = GetComponents();

	for (UActorComponent* Component : Components)
	{
		UParticleSystemComponent* ParticleComp = Cast<UParticleSystemComponent>(Component);

		if (!ParticleComp)
		{
			continue;
		}

		if (ParticleComp->bWasDeactivated)
		{
			const float* DeactivatedTime = DeactivatedParticles.Find(ParticleComp);

			if (!DeactivatedTime)
			{
				DeactivatedParticles.Add(ParticleComp, Now);
			}
			else if (*DeactivatedTime < Now - 10.0f)
			{
				// Zombie found
				P3JsonLog(Warning, "Zombie world particle found", TEXT("Particle"), ParticleComp->Template ? ParticleComp->Template->GetName() : TEXT("NULL"));

				ParticleComp->DestroyComponent();
				DeactivatedParticles.Remove(ParticleComp);
			}
		}
	}
}
