// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CombatComponent.h"

#include "AIController.h"
#include "Animation/AnimInstance.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "EngineUtils.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "GameFramework/PawnMovementComponent.h"
#include "GameplayTagAssetInterface.h"
#include "InstancedFoliageActor.h"
#include "Kismet/GameplayStatics.h"
#include "NavigationSystem.h"
#include "NavMesh/RecastNavMesh.h"
#include "SlateBlueprintLibrary.h"
#include "TimerManager.h"
#include "UserWidget.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "Chemical/P3FlammableComponent.h"
#include "Command/P3CommandComponent.h"
#include "P3.h"
#include "P3AnimNotify.h"
#include "P3AttributesComponent.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3Combat.h"
#include "P3ComboTableComponent.h"
#include "P3Cms.h"
#include "P3DrawDebugHelpers.h"
#include "P3Projectile.h"
#include "P3HealthPointComponent.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3GameState.h"
#include "P3Log.h"
#include "P3PartComponent.h"
#include "P3PlayerController.h"
#include "P3Physics.h"
#include "P3StaminaPointComponent.h"
#include "P3Weapon.h"

extern TAutoConsoleVariable<int32> CVarP3CombatShapCollision;

TAutoConsoleVariable<int32> CVarP3CombatDebug(
    TEXT("p3.combatDebug"),
    0,
    TEXT("1: enable debug. 0: disable dibug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CombatSkillDebug(
    TEXT("p3.combatSkillDebug"),
    0,
    TEXT("1: enable debug. 0: disable dibug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3AutoPutAwayDelay(
	TEXT("p3.combatAutoPutAwayWeaponDelaySeconds"),
	20.0f,
	TEXT("Delay seconds that put away weapon automatically after any combat related action is finished"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AutoPutAway(
	TEXT("p3.combatAutoPutAway"),
	0,
	TEXT("1: enable AutoPutAway, 0: disable AutoPutAway"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3AutoDrawDelay(
	TEXT("p3.combatAutoDrawWeaponDelaySeconds"),
	20.0f,
	TEXT("Delay after last put away weapon to draw automatically"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AutoDraw(
	TEXT("p3.combatAutoDraw"),
	0,
	TEXT("1: enable AutoDraw, 0: disable AutoDraw"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3AutoDrawWeaponLargeHostileSearchRange(
	TEXT("p3.combatAutoDrawWeaponLargeHostileSearchRange"),
	2000.0f,
	TEXT("The Range to find large hostile nearby"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3AutoDrawWeaponHostileSearchRange(
	TEXT("p3.combatAutoDrawWeaponHostileSearchRange"),
	1000.0f,
	TEXT("The Range to find normal hostile nearby"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AttackMove(
	TEXT("p3.attackMove"),
	2,
	TEXT("0: not move, 1: always move, 2: move by anim event"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3AttackMoveSpeed(
	TEXT("p3.attackMoveSpeed"),
	1.0f,
	TEXT("Speed multiplier for attack move"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3CombatRotateToTarget(
    TEXT("p3.combatRotateToTarget"),
    1,
    TEXT("0: nothing, 1: rotate at start, 2: keep rotate while attacking"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3CombatDebugServerMainTarget(
    TEXT("p3.combatDebugServerMainTarget"),
    0,
    TEXT("0: nothing, 1: debug"), ECVF_Cheat);

TAutoConsoleVariable<float> CVarP3CombatBlockStaminaAmount(
	TEXT("p3.combatBlockStaminaAmount"),
	10.0f,
	TEXT("consumed stamina amount by successful blocking"), ECVF_Default);

TAutoConsoleVariable<float> CVarP3CombatCrouchBlockStaminaAmount(
	TEXT("p3.combatCrouchBlockStaminaAmount"),
	5.0f,
	TEXT("consumed stamina amount by successful crouchblocking"), ECVF_Default);

TAutoConsoleVariable<float> CVarP3CombatBlockStartStaminaAmount(
	TEXT("p3.combatBlockStartStaminaAmount"),
	0.0f,
	TEXT("consumed stamina amount by start blocking"), ECVF_Default);

TAutoConsoleVariable<float> CVarP3CombatCrouchBlockStartStaminaAmount(
	TEXT("p3.combatCrouchBlockStartStaminaAmount"),
	0.0f,
	TEXT("consumed stamina amount by start crouchblocking"), ECVF_Default);

TAutoConsoleVariable<float> CVarP3CombatAttackHeightModifier(
	TEXT("p3.combatAttackHeightModifier"),
	0.8f,
	TEXT("Attack height is this value multiplied by capsule half height"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3CombatSearchRangeDebug(
	TEXT("p3.combatSearchRangeDebug"),
	0,
	TEXT("Show search range for main target"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3CombatAttackRangeDebug(
	TEXT("p3.combatAttackRangeDebug"),
	0,
	TEXT("Show attack range on hit timing"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CrossHairDebug(
	TEXT("p3.crossHairDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CrossHairOutline(
	TEXT("p3.crossHairOutline"),
	0,
	TEXT("1: enable outline. 0: disable outline"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AimAssistSpeed(
    TEXT("p3.aimAssistSpeed"),
    1.0f,
    TEXT("Speed multiplier for aim assist"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CombatRealSweepNumSteps(
	TEXT("p3f.combatRealSweepNumSteps"),
	10,
	TEXT("Step Number to devide Real Sweep"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3LockOnDebug(
	TEXT("p3.lockOnDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3LookAssistCameraRotationSpeed(
	TEXT("p3.lookAssistCameraRotationSpeed"),
	2.5f,
	TEXT("Camera rotation speed during look assist"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3UnreachableActorDebug(
	TEXT("p3.unreachableActorDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3IgnoreUnreachableActorAttackCountThreshold(
	TEXT("p3.ignoreUnreachableActorAttackCountThreshold"),
	0,
	TEXT("If the damage source actor attack in unreachable place, ignore the actor's attack damage after this times (0 means disable this feature)"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ThrownAwayMaxSpeed(
	TEXT("p3.thrownAwayMaxSpeed"),
	2000.0f,
	TEXT("Set max speed of thrown away"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3CombatShowSwingHitParticle(
	TEXT("p3.combatShowSwingHitParticle"),
	0,
	TEXT("0: hide, 1: show oldway, 2: show new way(networked)"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3CombatAnimMultipleHitIgnoreDurationSeconds(
	TEXT("p3.combatAnimMultipleHitIgnoreDurationSeconds"),
	1.5f,
	TEXT("Multiple hit for same actor within this time will be ignored, in same animation"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3BracingLevelOverride(
	TEXT("p3.bracingLevelOverride"),
	0,
	TEXT("set > 0 to override required bracing level to knowdown behemoth"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3BracingDetectDistance(
	TEXT("p3.bracingDetectDistance"),
	2000,
	TEXT("Behemoth will counter attack if bracing is further than this"), ECVF_Cheat);


static void DrawDebugSweptBox(const UWorld* InWorld, FVector const& Start, FVector const& End, FRotator const & Orientation, FVector const & HalfSize, FColor const& Color, bool bPersistentLines = false, float LifeTime = -1.f, uint8 DepthPriority = 0)
{
	FVector const TraceVec = End - Start;
	float const Dist = TraceVec.Size();

	FVector const Center = Start + TraceVec * 0.5f;

	FQuat const CapsuleRot = Orientation.Quaternion();
	::DrawDebugBox(InWorld, Start, HalfSize, CapsuleRot, Color, bPersistentLines, LifeTime, DepthPriority);

	//now draw lines from vertices
	FVector Vertices[8];
	Vertices[0] = Start + CapsuleRot.RotateVector(FVector(-HalfSize.X, -HalfSize.Y, -HalfSize.Z));	//flt
	Vertices[1] = Start + CapsuleRot.RotateVector(FVector(-HalfSize.X, HalfSize.Y, -HalfSize.Z));	//frt
	Vertices[2] = Start + CapsuleRot.RotateVector(FVector(-HalfSize.X, -HalfSize.Y, HalfSize.Z));	//flb
	Vertices[3] = Start + CapsuleRot.RotateVector(FVector(-HalfSize.X, HalfSize.Y, HalfSize.Z));	//frb
	Vertices[4] = Start + CapsuleRot.RotateVector(FVector(HalfSize.X, -HalfSize.Y, -HalfSize.Z));	//blt
	Vertices[5] = Start + CapsuleRot.RotateVector(FVector(HalfSize.X, HalfSize.Y, -HalfSize.Z));	//brt
	Vertices[6] = Start + CapsuleRot.RotateVector(FVector(HalfSize.X, -HalfSize.Y, HalfSize.Z));	//blb
	Vertices[7] = Start + CapsuleRot.RotateVector(FVector(HalfSize.X, HalfSize.Y, HalfSize.Z));		//brb
	for (int32 VertexIdx = 0; VertexIdx < 8; ++VertexIdx)
	{
		::DrawDebugLine(InWorld, Vertices[VertexIdx], Vertices[VertexIdx] + TraceVec, Color, bPersistentLines, LifeTime, DepthPriority);
	}

	::DrawDebugBox(InWorld, End, HalfSize, CapsuleRot, Color, bPersistentLines, LifeTime, DepthPriority);
}

static bool _IsCharacterPlayingMontage(const AActor* Actor)
{
	const AP3Character* Character = Cast<AP3Character>(Actor);
	if (Character && Character->GetMesh() && Character->GetMesh()->GetAnimInstance())
	{
		if (Character->GetMesh()->GetAnimInstance()->Montage_IsPlaying(nullptr))
		{
			return true;
		}
	}
	return false;
}

#if ENABLE_DRAW_DEBUG
static TArray<FP3Silhouetter> SilhouettersForOverlappedActor;
#endif

static TArray<AActor*> _FindOverlapActors(const UWorld& World, const AActor& Source, float Range, float AngleInDegree, bool bDebugDraw, FColor DebugDrawColor)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("CombatComponent_FindOverlapActors"), STAT_CombatComponent_FindOverlapActors, STATGROUP_P3);

	TArray<AActor*> OverlapActors;

	if (Range <= 0.0f || AngleInDegree <= 0.0f)
	{
		return OverlapActors;
	}

	const FVector SourceLocation = Source.GetActorLocation();
	float HalfRange = Range * 0.5f;
	float HalfAngleRadian = FMath::DegreesToRadians(AngleInDegree / 2.0f);
	float HalfHeight = Source.GetSimpleCollisionHalfHeight() * CVarP3CombatAttackHeightModifier.GetValueOnGameThread();

	static const FName TraceTag("FindOverlapActors");

	FCollisionQueryParams QueryParams;
	if (bDebugDraw)
	{
		QueryParams.TraceTag = TraceTag;
	}
	QueryParams.AddIgnoredActor(&Source);

	FCollisionResponseParams ResponseParams;

	// Capsule Test (There is no cylinder)
	TArray<FOverlapResult> CapsuleOverlapResults;
	{
		FCollisionShape CollisionShape;
		CollisionShape.SetCapsule(Range, HalfHeight + Range);

		World.OverlapMultiByChannel(CapsuleOverlapResults, SourceLocation, Source.GetActorQuat(), ECC_COMBAT, CollisionShape, QueryParams);
	}

	// Right Aligned Box Test
	TArray<FOverlapResult> LeftBoxOverlapResults;
	{
		FCollisionShape CollisionBox;
		CollisionBox.SetBox(FVector(Range, HalfRange, HalfHeight));

		FQuat YawRot(Source.GetActorUpVector(), -HalfAngleRadian);
		FVector OverlapPos = SourceLocation + YawRot.RotateVector(Source.GetActorRightVector()) * HalfRange;
		FQuat OverlapRot = Source.GetActorQuat() * YawRot;

		World.OverlapMultiByChannel(LeftBoxOverlapResults, OverlapPos, OverlapRot, ECC_COMBAT, CollisionBox, QueryParams);
	}

	// Right Aligned Box Test
	TArray<FOverlapResult> RightBoxOverlapResults;
	{
		FCollisionShape CollisionBox;
		CollisionBox.SetBox(FVector(Range, HalfRange, HalfHeight));

		FQuat YawRot(Source.GetActorUpVector(), HalfAngleRadian);
		FVector OverlapPos = SourceLocation - YawRot.RotateVector(Source.GetActorRightVector()) * HalfRange;
		FQuat OverlapRot = Source.GetActorQuat() * YawRot;

		World.OverlapMultiByChannel(RightBoxOverlapResults, OverlapPos, OverlapRot, ECC_COMBAT, CollisionBox, QueryParams);
	}

	// Find actors overlapped all three shapes
	for (const FOverlapResult& Result : CapsuleOverlapResults)
	{
		AActor* Actor = Result.GetActor();
		if (!Actor)
		{
			continue;
		}

		bool bOverlapLeft = LeftBoxOverlapResults.ContainsByPredicate([Actor](const FOverlapResult& R) { return R.GetActor() == Actor; });
		if (!bOverlapLeft)
		{
			continue;
		}

		bool bOverlapRight = RightBoxOverlapResults.ContainsByPredicate([Actor](const FOverlapResult& R) { return R.GetActor() == Actor; });
		if (!bOverlapRight)
		{
			continue;
		}

		OverlapActors.AddUnique(Actor);
	}

#if ENABLE_DRAW_DEBUG
	if (bDebugDraw)
	{
		float AngleRadian = HalfAngleRadian * 2.0f;
		const bool bDrawLine = true;
		const FColor LineColor(DebugDrawColor.R, DebugDrawColor.G, DebugDrawColor.B, 255);
		const float LineThickness = 0.0f;
		P3DrawDebugSolidCylindricalSector(World, SourceLocation, Source.GetActorForwardVector(), Source.GetActorRightVector(),
			Range, AngleRadian, HalfHeight * 2.0f, 16, DebugDrawColor, bDrawLine, LineColor, LineThickness, false, 1.0f, 0);

		SilhouettersForOverlappedActor.SetNum(OverlapActors.Num());
		for (int32 Index = 0; Index < OverlapActors.Num(); ++Index)
		{
			SilhouettersForOverlappedActor[Index].SetActor(OverlapActors[Index]);
		}

		FTimerDelegate TimerCallback;
		TimerCallback.BindLambda([]
		{
			SilhouettersForOverlappedActor.Empty();
		});

		FTimerHandle Handle;
		World.GetTimerManager().SetTimer(Handle, TimerCallback, 1.0f, false);
	}
#endif

	return OverlapActors;
}


struct FMeleeAttackSweepResult
{
	AActor& Actor;
	FHitResult HitResult;
	FName BoneName;
	FVector Location;

	bool operator == (const FMeleeAttackSweepResult& Other) const
	{
		return &Other.Actor == &Actor && Other.BoneName == BoneName && Other.HitResult.Item == HitResult.Item;
	}
};

static TArray<FMeleeAttackSweepResult> _SweepMeleeAttackHits(
	const UWorld& World,
	const AActor& Source,
	float Range,
	float AngleInDegree,
	const FVector& Location,
	const FQuat& Quaternion,
	bool bDebugDraw,
	FColor DebugDrawColor)
{
	TArray<FMeleeAttackSweepResult> OutResults;

	if (Range <= 0.0f || AngleInDegree <= 0.0f)
	{
		return OutResults;
	}

	const FVector SourceLocation = Location;
	float HalfRange = Range * 0.5f;
	float HalfAngleRadian = FMath::DegreesToRadians(AngleInDegree / 2.0f);
	float HalfHeight = Source.GetSimpleCollisionHalfHeight() * CVarP3CombatAttackHeightModifier.GetValueOnGameThread();

	static const FName TraceTag("FindOverlapActors");

	FCollisionQueryParams QueryParams;
	if (bDebugDraw)
	{
		QueryParams.TraceTag = TraceTag;
	}

	QueryParams.AddIgnoredActor(&Source);
	{
		TArray<AActor*> SourceAttachedActors;
		Source.GetAttachedActors(SourceAttachedActors);
		QueryParams.AddIgnoredActors(SourceAttachedActors);
	}

	FCollisionResponseParams ResponseParams;

	TArray<FHitResult> TotalSweepResults;

	const int32 NumSteps = CVarP3CombatRealSweepNumSteps.GetValueOnGameThread();

	const FQuat WorldConeQuat = Quaternion;
	const float StepAngleRadian = (NumSteps != 0) ? HalfAngleRadian / NumSteps * 2 : 0;

	for (int32 CurrStep = 0; CurrStep < NumSteps; ++CurrStep)
	{
		TArray<FHitResult> SweepResults;

		FCollisionShape CollisionPlane;
		CollisionPlane.SetBox(FVector(HalfRange, 1.0f, HalfHeight));

		/** Left to Right (Current) */
		const FQuat SweepQuat = WorldConeQuat * FQuat(FVector(0, 0, 1), -HalfAngleRadian + (StepAngleRadian * CurrStep));

		const FVector StartPos = SourceLocation + SweepQuat.RotateVector(FVector(1, 0, 0)) * HalfRange;
		const FVector EndPos = SourceLocation
			+ (SweepQuat.RotateVector(FVector(0, 1, 0)) * Range * FMath::Tan(StepAngleRadian))
			+ SweepQuat.RotateVector(FVector(1, 0, 0)) * HalfRange;

		World.SweepMultiByChannel(SweepResults, StartPos, EndPos, SweepQuat, ECC_COMBAT, CollisionPlane, QueryParams, ResponseParams);

		if (bDebugDraw)
		{
			DrawDebugSweptBox(&World, StartPos, EndPos, SweepQuat.Rotator(), FVector(HalfRange, 1.0f, HalfHeight), FColor::Red, false, 2.0f);

			for (const FHitResult& HitResult : SweepResults)
			{
				AActor* Actor = HitResult.GetActor();
				DrawDebugPoint(&World, HitResult.ImpactPoint, 10.0f, FColor::Green, false, 2.0f);
			}
		}

		TotalSweepResults.Append(SweepResults);
	}

	for (const FHitResult& Result : TotalSweepResults)
	{
		AActor* Actor = Result.GetActor();
		if (!Actor)
		{
			continue;
		}

		const FName BoneName = Result.BoneName;

		OutResults.AddUnique(FMeleeAttackSweepResult({ *Actor, Result, BoneName, Result.ImpactPoint }));
	}

#if ENABLE_DRAW_DEBUG
	if (bDebugDraw)
	{
		SilhouettersForOverlappedActor.SetNum(OutResults.Num());
		for (int32 Index = 0; Index < OutResults.Num(); ++Index)
		{
			SilhouettersForOverlappedActor[Index].SetActor(&OutResults[Index].Actor);
		}

		FTimerDelegate TimerCallback;
		TimerCallback.BindLambda([]
		{
			SilhouettersForOverlappedActor.Empty();
		});

		FTimerHandle Handle;
		World.GetTimerManager().SetTimer(Handle, TimerCallback, 1.0f, false);
	}
#endif

	return OutResults;
}


UP3CombatComponent::UP3CombatComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	AttackRange = 200;
	AttackAngleDegree = 120;
	MainTargetSearchRange = 500;
	MainTargetSearchAngleDegree = 120;
}

void UP3CombatComponent::BeginPlay()
{
	Super::BeginPlay();
	
	GetWorld()->GetTimerManager().SetTimer(SlowTickTimerHandle, this, &UP3CombatComponent::SlowTick, 1.0f, true, FMath::RandRange(0.9f, 1.1f));

	for (FP3CombatSkill& Skill : Skills)
	{
		if (ensure(Skill.CmsCombatSkill))
		{
			Skill.Server_NextCooldownFinishTimeSeconds = GetWorld()->GetTimeSeconds() + Skill.CmsCombatSkill->CooldownTimeSeconds;
		}
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (Character && Character->IsLarge())
	{
		bUseHitLog = true;
	}
}

void UP3CombatComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	GetWorld()->GetTimerManager().ClearTimer(SlowTickTimerHandle);
}

void UP3CombatComponent::OnRegister()
{
	Super::OnRegister();

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (ensure(Character))
	{
		Character->OnInputStartAttack.AddUniqueDynamic(this, &UP3CombatComponent::OnStartAttackInput);
		Character->OnInputStopAttack.AddUniqueDynamic(this, &UP3CombatComponent::OnStopAttackInput);
		Character->OnCharacterStoreChanged.AddUniqueDynamic(this, &UP3CombatComponent::OnCharacterStoreChanged);
		Character->OnInputPressLockOnButton.AddUniqueDynamic(this, &UP3CombatComponent::OnLockOnPressed);
		Character->OnInputReleaseLockOnButton.AddUniqueDynamic(this, &UP3CombatComponent::OnLockOnReleased);
		Character->OnInputNextLockOn.AddUniqueDynamic(this, &UP3CombatComponent::OnNextLockOn);
		Character->OnInputPrevLockOn.AddUniqueDynamic(this, &UP3CombatComponent::OnPrevLockOn);
		Character->OnInputLookAssist.AddUniqueDynamic(this, &UP3CombatComponent::OnLookAssist);
		Character->OnInputMoveLook.AddUniqueDynamic(this, &UP3CombatComponent::OnInputMoveLook);

		TArray<UP3PartComponent*> PartComponents;
		Character->GetComponents<UP3PartComponent>(PartComponents);
		for (auto&& PartComponent : PartComponents)
		{
			PartComponent->OnPartBroken.AddUniqueDynamic(this, &UP3CombatComponent::OnPartBroken);
		}

		TArray<const FP3CmsCombatSkill*> CmsCombatSkills = P3Cms::GetCharacterCombatSkills(Character->GetCmsCharacterKey());
		for (const FP3CmsCombatSkill* CmsSkill : CmsCombatSkills)
		{
			FP3CombatSkill Skill;
			Skill.CmsCombatSkill = CmsSkill;
			Skills.Add(Skill);
		}
	}
}

void UP3CombatComponent::OnUnregister()
{
	Super::OnUnregister();

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (Character)
	{
		Character->OnInputStartAttack.RemoveDynamic(this, &UP3CombatComponent::OnStartAttackInput);
		Character->OnInputStopAttack.RemoveDynamic(this, &UP3CombatComponent::OnStopAttackInput);
		Character->OnCharacterStoreChanged.RemoveDynamic(this, &UP3CombatComponent::OnCharacterStoreChanged);
		Character->OnInputPressLockOnButton.RemoveDynamic(this, &UP3CombatComponent::OnLockOnPressed);
		Character->OnInputReleaseLockOnButton.RemoveDynamic(this, &UP3CombatComponent::OnLockOnReleased);
		Character->OnInputNextLockOn.RemoveDynamic(this, &UP3CombatComponent::OnNextLockOn);
		Character->OnInputPrevLockOn.RemoveDynamic(this, &UP3CombatComponent::OnPrevLockOn);
		Character->OnInputLookAssist.RemoveDynamic(this, &UP3CombatComponent::OnLookAssist);
		Character->OnInputMoveLook.RemoveDynamic(this, &UP3CombatComponent::OnInputMoveLook);

		TArray<UP3PartComponent*> PartComponents;
		Character->GetComponents<UP3PartComponent>(PartComponents);
		for (auto&& PartComponent : PartComponents)
		{
			PartComponent->OnPartBroken.RemoveDynamic(this, &UP3CombatComponent::OnPartBroken);
		}
	}
}

void UP3CombatComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("CombatComponent_Tick"), STAT_CombatComponent_Tick, STATGROUP_P3);

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (Character && Character->IsDeadOrDowned())
	{
		LocalControl_bIsAttacking = false;
	}

	if (IsLocalControlledActor(GetOwner()))
	{
		if (Character && Character->IsPlayerControlled())
		{
			if (LocalControl_bAssistAim)
			{
				LocalControl_TickAssistAim(DeltaTime);
			}

			LocalControl_TickFindTargetUnderCrossHair();
			LocalControl_TickCameraRotationLockOnTarget(DeltaTime);
			LocalControl_TickReleaseLockOnTarget();
			LocalControl_Player_TickSwing(Character, DeltaTime);
		}

		if (LocalControl_bIsAttacking)
		{
			if (!IsCrossHairMode())
			{
				LocalControl_TickConsiderFindTarget();
				LocalControl_TickMoveTowardsTarget();
			}
			LocalControl_TickAutoAttack();
		}

		if (CVarP3AutoPutAway.GetValueOnGameThread() != 0)
		{
			LocalControl_TickAutoPutAwayWeapon();
		}
	}

	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_Tick(DeltaTime, Character);

		if (Character && Character->IsPlayerControlled())
		{
			Server_MainTarget.OnTick(*Character, DeltaTime);
		}
	}

	if (Character && CVarP3CombatSkillDebug.GetValueOnGameThread() != 0)
	{
		const TArray<FP3CombatSkill>& LocalSkills = GetSkills();

		Character->AddDebugString(FString::Printf(TEXT("[Skills] Num: %d"), LocalSkills.Num()));

		for (const FP3CombatSkill& Skill : LocalSkills)
		{
			if (ensure(Skill.CmsCombatSkill))
			{
				Character->AddDebugString(FString::Printf(TEXT("  Anim(%s), Cooddown Time(%.1f), Cooldown Left(%.1f)"),
					Skill.CmsCombatSkill->AnimMontage ? *Skill.CmsCombatSkill->AnimMontage->GetName() : TEXT("NULL"),
					Skill.CmsCombatSkill->CooldownTimeSeconds,
					Skill.Server_NextCooldownFinishTimeSeconds - GetWorld()->GetTimeSeconds()));
			}
		}
	}

	if (Character && CVarP3UnreachableActorDebug.GetValueOnGameThread() != 0)
	{
		for (const FP3UnreachableActor& UnreachableActor : UnreachableActorList)
		{
			Character->AddDebugString(FString::Printf(TEXT("Unreachable Actor : %s  |  Unfair Attack Count: %d"), *(UnreachableActor.Actor)->GetName(), UnreachableActor.AttackCount));
		}
	}
}

void UP3CombatComponent::SlowTick()
{
	if (CVarP3AutoDraw.GetValueOnGameThread() > 0 && IsLocalControlledActor(GetOwner()))
	{
		LocalControl_TickAutoDrawWeapon();
	}
}

void UP3CombatComponent::Server_Tick(float DeltaSeconds, AP3Character* Character)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_TickBoneAttack(DeltaSeconds, Character);
}

bool UP3CombatComponent::Server_IsAlreadyThrownByBoneAttack(const AP3Character& Character, const UAnimSequenceBase* AnimSequence) const
{
	if (!ensure(AnimSequence))
	{
		return false;
	}

	for (const FBoneAttackAnimNotify& BoneAttackNotify : BoneAttackAnimNotifies)
	{
		if (BoneAttackNotify.Animation.Get() == AnimSequence)
		{
			if (BoneAttackNotify.ThrownCharacters.Contains(&Character))
			{
				return true;
			}
		}
	}

	return false;
}

void UP3CombatComponent::Server_TickBoneAttack(float DeltaSeconds, AP3Character* Character)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Character)
	{
		return;
	}

	if (BoneAttackAnimNotifies.Num() == 0)
	{
		return;
	}

	USkeletalMeshComponent* SkeletalMeshComp = Character->GetMesh();

	if (!SkeletalMeshComp)
	{
		return;
	}

	UPhysicsAsset* PhysicsAsset = SkeletalMeshComp->GetPhysicsAsset();

	if (!ensure(PhysicsAsset))
	{
		return;
	}

	const FReferenceSkeleton* RefSkeleton = SkeletalMeshComp->SkeletalMesh ? &SkeletalMeshComp->SkeletalMesh->RefSkeleton : nullptr;

	if (!ensure(RefSkeleton))
	{
		return;
	}

	if (BoneAttackAnimNotifies.Num() == 0)
	{
		return;
	}

	Server_TimeoutHitLogs();

	const float Now = GetWorld()->GetTimeSeconds();
	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	const int32 ActionId = ActionComp ? ActionComp->GetActiveActionId() : 0;

	const EP3WeaponType WeaponType = Character->GetRightHandWeaponType();
	const FTransform& SkeletalMeshTransform = SkeletalMeshComp->GetComponentTransform();
	const bool bHasMasterPoseComponent = SkeletalMeshComp->MasterPoseComponent.IsValid();
	const TArray<FTransform>& BoneTransforms = SkeletalMeshComp->GetComponentSpaceTransforms();

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(Character);
	{
		TArray<AActor*>AttachedActors;
		Character->GetAttachedActors(AttachedActors);
		QueryParams.AddIgnoredActors(AttachedActors);
	}

	for (FBoneAttackAnimNotify& AnimNotify : BoneAttackAnimNotifies)
	{
		const UAnimNotifyState_BoneAttack* BoneAttackNotify = AnimNotify.Notify.Get();

		if (!ensure(BoneAttackNotify))
		{
			continue;
		}

		const FName& CmsCombatHitKey = BoneAttackNotify->GetCmsCombatHitKey();
		const FP3CmsCombatHit* CmsCombatHit = nullptr;

		if (CmsCombatHitKey != NAME_None)
		{
			CmsCombatHit = P3Cms::GetCombatHit(CmsCombatHitKey);

			if (!CmsCombatHit)
			{
				P3JsonLog(Warning, "Invalid CmsCombatHitKey",
					TEXT("Key"), CmsCombatHitKey.ToString(),
					TEXT("Character"), *Character->GetFullName(),
					TEXT("Animation"), AnimNotify.Animation.Get() ? *AnimNotify.Animation.Get()->GetFullName() : TEXT("NULL"));
			}
		}

		for (auto&& Iter : AnimNotify.Bones)
		{
			const FName& BoneName = Iter.Key;
			FAttackBone& AttackBone = Iter.Value;

			if (Server_DisabledBoneNameOnBoneAttack.ContainsByPredicate([BoneName](FP3DisabledBoneData& BoneData) { return BoneData.DisabledBoneName == BoneName;}))
			{
				continue;
			}

			// Reference code: USkeletalMeshComponent::GetClosestPointOnPhysicsAsset()
			for (const UBodySetup* BodySetup : PhysicsAsset->SkeletalBodySetups)
			{
				if (BoneName == BodySetup->BoneName)
				{
					const int32 BoneIndex = RefSkeleton->FindBoneIndex(BoneName);

					if (ensure(BoneIndex != INDEX_NONE) && ensure(BoneTransforms.IsValidIndex(BoneIndex)))
					{
						const FTransform BoneTM = bHasMasterPoseComponent ? SkeletalMeshComp->GetBoneTransform(BoneIndex) : BoneTransforms[BoneIndex];

						const FTransform BoneWorldTM = BoneTM * SkeletalMeshTransform;

						if (!AttackBone.bTransformInitialized)
						{
							AttackBone.bTransformInitialized = true;
							AttackBone.Transform = BoneWorldTM;

							continue;
						}

						for (const FKSphylElem& Sphyl : BodySetup->AggGeom.SphylElems)
						{
							FCollisionShape Shape;
							Shape.SetCapsule(Sphyl.Radius, Sphyl.Length * 0.5f);

							if (BoneAttackNotify->IsThrow())
							{
								Shape.SetCapsule(Sphyl.Radius * 2.0f, Sphyl.Length * 0.5f);
							}

							const FTransform OldGeomTransform = Sphyl.GetTransform() * AttackBone.Transform;
							const FTransform GeomTransform = Sphyl.GetTransform() * BoneWorldTM;
							const FVector Moved = GeomTransform.GetLocation() - OldGeomTransform.GetLocation();
							const float MovedDistance = Moved.Size();
							const float MovedSpeed = DeltaSeconds > KINDA_SMALL_NUMBER ? MovedDistance / DeltaSeconds : 0.0f;
							const FVector MoveDirection = MovedDistance > KINDA_SMALL_NUMBER ? Moved / MovedDistance : FVector(1, 0, 0);

							TArray<FHitResult> HitResults;
							GetWorld()->SweepMultiByChannel(HitResults, OldGeomTransform.GetLocation(), GeomTransform.GetLocation(), GeomTransform.GetRotation(), ECC_COMBAT, Shape, QueryParams);

							bool bValidHitFound = false;

							for (const FHitResult& HitResult : HitResults)
							{
								AActor* HitActor = HitResult.GetActor();

								if (!HitActor)
								{
									continue;
								}

								if (Server_HitLogActionId != ActionId)
								{
									Server_HitLogActionId = ActionId;
									Server_HitLogActors.Empty();
								}

								AP3Character* HitCharacter = Cast<AP3Character>(HitActor);

								// Ignore mounted one
								if (HitCharacter && HitCharacter->GetCharacterStoreBP().MountTargetCharacter == Character)
								{
									continue;
								}

								if (BoneAttackNotify->IsThrow()
									&& HitCharacter
									&& Server_IsAlreadyThrownByBoneAttack(*HitCharacter, AnimNotify.Animation.Get()))
								{
									// This actor is already got hit by this animation, skip it

									// TODO: find part and sort by priority
									continue;
								}

								// See if target actor is hit by this animation already
								bool bDuplicatedHit = false;

								if (bUseHitLog && Server_HitLogActors.Contains(HitActor))
								{
									bDuplicatedHit = true;
								}

								if (bDuplicatedHit && !BoneAttackNotify->IsThrow())
								{
									continue;
								}

								Server_HitLogActors.Add(HitActor, Now);

								if (CVarP3CombatAttackRangeDebug.GetValueOnGameThread() != 0)
								{
									DrawDebugPoint(GetWorld(), HitResult.ImpactPoint, 10.0f, FColor::Red, false, 5.0f);
									DrawDebugDirectionalArrow(GetWorld(), HitResult.ImpactPoint, HitResult.ImpactPoint + (MoveDirection * 100.0f), 20.0f, FColor::Red, false, 5.0f);
								}

								if (CmsCombatHit)
								{
									P3Combat::FDamageActorParams DamageParams(*Character, *HitActor);
									DamageParams.AttackStrength = CmsCombatHit->AttackStrength;
									DamageParams.AttackDirection = CmsCombatHit->AttackDirection;
									DamageParams.AttackAttribute = CmsCombatHit->AttackAttribute;
									DamageParams.TagName = CmsCombatHit->TagName;
									DamageParams.TargetComponent = HitResult.GetComponent();
									DamageParams.TargetHitItemIndex = HitResult.Item;
									DamageParams.WeaponType = WeaponType;
									DamageParams.ImpactDirection = MoveDirection;
									DamageParams.BoneName = HitResult.BoneName;
									DamageParams.AttackBoneName = BoneName;
									DamageParams.DamagePermil = bDuplicatedHit ? 0 : CmsCombatHit->DamagePermil;
									DamageParams.DamageDestructiblePermil = bDuplicatedHit ? 0 : CmsCombatHit->DamageDestructiblePermil;
									DamageParams.bCanDamageAlly = CmsCombatHit->bCanDamageAlly;
									DamageParams.HitLocation = &HitResult.ImpactPoint;
									DamageParams.bIsFrameHold = CmsCombatHit->bIsFrameHold;
									DamageParams.CmsCombatHitKey = CmsCombatHitKey;
									DamageParams.CmsCameraShakeKey = CmsCombatHit->CmsCameraShakeName;

									if (HitCharacter && BoneAttackNotify->IsThrow())
									{
										AnimNotify.ThrownCharacters.Add(HitCharacter);

										DamageParams.AttackStrength = EAnimNotifyAttackStrengthFlags::ThrowAttack;
										DamageParams.ThrowAwayVelocity = MoveDirection * FMath::Min(MovedSpeed, CVarP3ThrownAwayMaxSpeed.GetValueOnGameThread());
									}

									const EP3GiveDamageResult Result = P3Combat::Server_DamageActor(DamageParams);
								}
								
								bValidHitFound = true;
							}

							if (CVarP3CombatAttackRangeDebug.GetValueOnGameThread() != 0)
							{
								DrawDebugCapsule(GetWorld(), GeomTransform.GetLocation(), Shape.GetCapsuleHalfHeight(), Shape.GetCapsuleRadius(), GeomTransform.GetRotation(), bValidHitFound ? FColor::Green : FColor::White, false, 5.0f);
							}
						}

						AttackBone.Transform = BoneWorldTM;
					}

					break;
				}
			}
		}
	}
}

void UP3CombatComponent::LocalControl_TickAutoDrawWeapon()
{
	ensure(IsLocalControlledActor(GetOwner()));

	AP3Character* MyCharacter = Cast<AP3Character>(GetOwner());
	if (!ensure(MyCharacter))
	{
		return;
	}

	if (!MyCharacter->IsPlayerControlled())
	{
		// AI Behavior Tree will take care of draw
		return;
	}

	/** If an action is in progress, Do not draw */
	UP3PawnActionComponent* ActionComp = MyCharacter->GetActionComponent();
	if (ActionComp && ActionComp->GetActiveActionType() != EPawnActionType::Invalid)
	{
		return;
	}

	if (MyCharacter->IsGliding()
		|| MyCharacter->IsClimbing()
		|| MyCharacter->IsRescuing())
	{
		return;
	}

	const float SecondsSinceLastPutawayWeapon = GetWorld()->GetTimeSeconds() - LocalControl_LastPutawayWeaponTimeSeconds;

	if (LocalControl_LastPutawayWeaponTimeSeconds != 0
		&& SecondsSinceLastPutawayWeapon < CVarP3AutoDrawDelay.GetValueOnGameThread())
	{
		return;
	}

	bool bEnemyInSight = false;

	// See if we have any any hostile character near by
	TArray<AActor*> OverlapActors = _FindOverlapActors(*GetWorld(), *MyCharacter, CVarP3AutoDrawWeaponLargeHostileSearchRange.GetValueOnGameThread(), AutoDrawWeaponHostileSearchAngleDegree, false, FColor::Yellow);

	const float SquaredHostileSearchRange = FMath::Square(CVarP3AutoDrawWeaponHostileSearchRange.GetValueOnGameThread());

	for (AActor* Actor : OverlapActors)
	{
		// Should be P3Character and alive
		AP3Character* OverlappedCharacter = Cast<AP3Character>(Actor);
		if (!OverlappedCharacter || OverlappedCharacter->IsDeadOrDowned())
		{
			continue;
		}

		if (OverlappedCharacter->GetFaction() != MyCharacter->GetFaction())
		{
			const float SquaredDistanceFromOverlappedCharacter = FVector::DistSquared(OverlappedCharacter->GetActorLocation(), MyCharacter->GetActorLocation());
			const bool OverlappedCharacterIsLarge = OverlappedCharacter->IsLarge();
			const bool OverlappedCharacterIsInSearchRange = SquaredDistanceFromOverlappedCharacter <= SquaredHostileSearchRange;
			if (OverlappedCharacterIsLarge || OverlappedCharacterIsInSearchRange)
			{
				// Enemy in sight, combat station
				bEnemyInSight = true;
				break;
			}
		}
	}

	if (bEnemyInSight)
	{
		LocalControl_AutoPutAwayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();

		if (MyCharacter->GetStance() != EP3CharacterStance::Combat)
		{
			LocalControl_DrawWeapon();
		}
	}

}

void UP3CombatComponent::LocalControl_TickAutoAttack()
{
	ensure(IsLocalControlledActor(GetOwner()));
	ensure(LocalControl_bIsAttacking);

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		LocalControl_bIsAttacking = false;
		return;
	}

	switch (Character->GetRightHandWeaponType())
	{
	case EP3WeaponType::SwordAndShield:
	case EP3WeaponType::Lance:
		LocalControl_TickAutoAttackSword();
		break;
	case EP3WeaponType::Gun:
	case EP3WeaponType::Bow:
		LocalControl_TickAutoAttackGun();
		break;
	}
}

void UP3CombatComponent::LocalControl_TickAutoAttackSword()
{
	/*
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;

	if (ActionComp && ActionComp->CanStartAction(EPawnActionType::CombatAttack))
	{
		// Never stop

		FP3PawnActionStartRequestParams Params;
		Params.CombatAttack_MontageIndex = FMath::Rand() % Character->GetAnimMontages().Attacks.Num();
		Params.CombatAttack_MoveInputLocalVector = Character->GetActorRotation().UnrotateVector(Character->GetMovementComponent()->GetLastInputVector());

		if (LocalControl_IsMeleeCrossHairMode())
		{
			Params.CombatAttack_Target = nullptr;
			Params.CombatAttack_ChracterRotator = Character->GetActorRotation();
			//AP3PlayerController* Controller = Cast<AP3PlayerController>(Character->GetController());
			//if (ensure(Controller) && !Character->HasControlInput())
			//{
			//	Params.CombatAttack_ChracterRotator.Yaw = Controller->GetControlRotation().Yaw;
			//}
		}
		else
		{
			Params.CombatAttack_Target = LocalControl_MainTarget.Get();

			if (CVarP3CombatRotateToTarget.GetValueOnGameThread() == 1)
			{
				if (LocalControl_MainTarget.IsValid())
				{
					const FVector Offset = LocalControl_MainTarget->GetActorLocation() - GetOwner()->GetActorLocation();
					Params.CombatAttack_ChracterRotator = Offset.GetSafeNormal2D().Rotation();
				}
			}
		}

		ActionComp->StartAction(EPawnActionType::CombatAttack, Params);

		LocalControl_AutoPutAwayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();
	}
	*/
}

void UP3CombatComponent::LocalControl_TickAutoAttackGun()
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

	if (!ensure(ActionComp))
	{
		return;
	}

	if (!ActionComp->CanStartAction(EPawnActionType::CombatRangedAttack))
	{
		return;
	}

	LocalControl_AutoPutAwayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();

	if (!IsCrossHairMode())
	{
		FP3PawnActionStartRequestParams Params;
		Params.CombatRangedAttack_CharacterRotator = Character->GetActorRotation();

		ActionComp->StartAction(EPawnActionType::CombatRangedAttack, _FUNCTION_TEXT, Params);
		return;
	}

	bool bHit = false;
	FHitResult HitResult;
	FVector AimTarget;

	bool bSuccess = LocalControl_LineTraceCrossHair(bHit, HitResult, nullptr, &AimTarget);

	if (!ensure(bSuccess))
	{
		FP3PawnActionStartRequestParams Params;
		Params.CombatRangedAttack_CharacterRotator = Character->GetActorRotation();

		ActionComp->StartAction(EPawnActionType::CombatRangedAttack, _FUNCTION_TEXT, Params);
		return;
	}

	if (bHit)
	{
		AimTarget = HitResult.Location;
	}

	FVector MuzzleLocation = Character->GetActorLocation();
	AActor* WeaponActor = Character->GetRightHandWeaponActor();

	ensure(WeaponActor && P3GetMuzzleLocation(*WeaponActor, MuzzleLocation));

	if (CVarP3CrossHairDebug.GetValueOnGameThread() > 0)
	{
		DrawDebugCrosshairs(GetWorld(), AimTarget, Character->GetActorRotation(), 100.0f, FColor::Red, false, 3.0f, 0);
		DrawDebugCrosshairs(GetWorld(), MuzzleLocation, Character->GetActorRotation(), 100.0f, FColor::Red, false, 3.0f, 0);
	}

	FRotator AimRotation = FRotationMatrix::MakeFromX(AimTarget - MuzzleLocation).Rotator();

	FP3PawnActionStartRequestParams Params;
	Params.CombatRangedAttack_CharacterRotator = AimRotation;

	ActionComp->StartAction(EPawnActionType::CombatRangedAttack, _FUNCTION_TEXT, Params);
}

void UP3CombatComponent::LocalControl_TickAutoPutAwayWeapon()
{
	ensure(IsLocalControlledActor(GetOwner()));

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (Character && !Character->IsDeadOrDowned() && Character->GetStance() == EP3CharacterStance::Combat)
	{
		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

		bool bPostponePutaway = false;

		if (Character->GetCharacterStoreBP().bIsBlocking)
		{
			bPostponePutaway = true;
		}

		if (!bPostponePutaway && Character->GetCharacterStoreBP().bIsAiming)
		{
			bPostponePutaway = true;
		}

		if (!bPostponePutaway && Character->GetCharacterStoreBP().MountTargetCharacter != nullptr)
		{
			bPostponePutaway = true;
		}

		if (!bPostponePutaway && ActionComp && ActionComp->GetActiveActionType() != EPawnActionType::Invalid)
		{
			bPostponePutaway = true;
		}
		
		AActor* RightHandWeaponActor = Character->GetRightHandWeaponActor();
		if (RightHandWeaponActor && RightHandWeaponActor->FindComponentByClass<UP3FlammableComponent>())
		{
			// You don't want to put out fire by accident
			bPostponePutaway = true;
		}

		if (bPostponePutaway || LocalControl_AutoPutAwayWeaponTimeSeconds == 0)
		{
			LocalControl_AutoPutAwayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();
		}
		else
		{
			const float TimeSinceLastAutoPutaway = GetWorld()->GetTimeSeconds() - LocalControl_AutoPutAwayWeaponTimeSeconds;
			if (TimeSinceLastAutoPutaway > CVarP3AutoPutAwayDelay.GetValueOnGameThread())
			{
				LocalControl_AutoPutAwayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();

				PutAwayWeapon();
			}
		}

		if (CVarP3CombatDebug.GetValueOnGameThread() != 0)
		{
			if (BoneAttackAnimNotifies.Num() > 0)
			{
				for (const FBoneAttackAnimNotify& BoneAttack : BoneAttackAnimNotifies)
				{
					Character->AddDebugString(FString::Printf(
						TEXT("[BoneAttack] %s")
						, BoneAttack.Animation.Get() ? *BoneAttack.Animation.Get()->GetName() : TEXT("NULL")));
				}
			}

			//if (IsLocalControlledActor(GetOwner()))
			//{
			//	Character->AddDebugString(FString::Printf(TEXT("AutoPutAway: %.2f/%.0f"),
			//		GetWorld()->GetTimeSeconds() - LocalControl_AutoPutAwayWeaponTimeSeconds, CVarP3AutoPutAwayDelay.GetValueOnGameThread()));
			//}
		}
	}
}

bool UP3CombatComponent::LocalControl_LineTraceCrossHair(bool& bOutHit, FHitResult& OutHitResult, FVector* OutTraceStart, FVector* OutTraceEnd) const
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return false;
	}

	AP3PlayerController* Controller = Cast<AP3PlayerController>(Character->GetController());

	if (!ensure(Controller && Controller->IsLocalController()))
	{
		return false;
	}
	
	const UP3ComboTableComponent* ComboComp = Character->GetComboComponent();
	if (!ensure(ComboComp))
	{
		return false;		
	}

	FVector2D LocalControl_CrossHairPosition = ComboComp->GetCrossHairPosition();

	FVector TraceStart;
	FVector TraceDirection;

	if (!Controller->DeprojectScreenPositionToWorld(LocalControl_CrossHairPosition.X, LocalControl_CrossHairPosition.Y, TraceStart, TraceDirection))
	{
		return false;
	}

	static const float HitResultTraceDistance = 10000.0f;
	FCollisionQueryParams CollisionQueryParams;
	CollisionQueryParams.AddIgnoredActor(Character);

	FVector TraceEnd = TraceStart + TraceDirection * HitResultTraceDistance;
	bOutHit = GetWorld()->LineTraceSingleByChannel(OutHitResult, TraceStart, TraceEnd, ECC_PhysicsBody, CollisionQueryParams);

	if (OutTraceStart)
	{
		*OutTraceStart = TraceStart;
	}

	if (OutTraceEnd)
	{
		*OutTraceEnd = TraceEnd;
	}

	return true;
}

bool UP3CombatComponent::LocalControl_UpdateCrossHairTargetAndAimRotation()
{
	LocalControl_CrossHairTarget.Reset();
	LocalControl_AimRotation = FRotator::ZeroRotator;

	if (!IsCrossHairMode())
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return false;
	}

	LocalControl_AimRotation = Character->GetActorRotation();

	bool bHit = false;
	FHitResult HitResult;
	FVector AimTarget;

	bool bSuccess = LocalControl_LineTraceCrossHair(bHit, HitResult, nullptr, &AimTarget);

	if (!ensure(bSuccess))
	{
		return false;
	}

	if (bHit)
	{
		AimTarget = HitResult.Location;
	}

	FVector AimSource = Character->GetActorLocation();
	AimSource.Z += 60.0f; // To make close to arm position

	LocalControl_CrossHairTarget = Cast<AP3Character>(HitResult.GetActor());
	LocalControl_AimRotation = FRotationMatrix::MakeFromX(AimTarget - AimSource).Rotator();

	if (CVarP3CrossHairDebug.GetValueOnGameThread() > 0)
	{
		DrawDebugLine(GetWorld(), AimSource, AimTarget, FColor::Yellow);
	}

	return true;
}

void UP3CombatComponent::LocalControl_TickFindTargetUnderCrossHair()
{
	AP3Character* PreviousCrossHairTarget = LocalControl_CrossHairTarget.Get();

	LocalControl_UpdateCrossHairTargetAndAimRotation();

	if (PreviousCrossHairTarget == LocalControl_CrossHairTarget)
	{
		return;
	}

	AP3Character* CurrentCrossHairTarget = LocalControl_CrossHairTarget.Get();

	if (CurrentCrossHairTarget)
	{
		LocalControl_MainTarget = LocalControl_CrossHairTarget;
	}

	if (CVarP3CrossHairOutline.GetValueOnGameThread() > 0)
	{
		LocalControl_CrossHairTargetSilhouetter.SetActor(CurrentCrossHairTarget);
	}
}

void UP3CombatComponent::LocalControl_TickConsiderFindTarget()
{
	bool bFindTarget = false;

	if (!LocalControl_MainTarget.IsValid())
	{
		// No target
		bFindTarget = true;
	}
	else
	{
		if (LocalControl_MainTarget->IsDeadOrDowned())
		{
			// Target dead
			bFindTarget = true;
		}
		else if ((GetOwner()->GetActorLocation() - LocalControl_MainTarget->GetActorLocation()).SizeSquared() > MainTargetSearchRange)
		{
			// Target too far
			bFindTarget = true;
		}
	}

	if (bFindTarget)
	{
		LocalControl_SearchMainTarget();
	}
}

void UP3CombatComponent::LocalControl_TickMoveTowardsTarget()
{
	ensure(IsLocalControlledActor(GetOwner()));

	if (!LocalControl_MainTarget.IsValid())
	{
		return;
	}

	const FVector Offset = LocalControl_MainTarget->GetActorLocation() - GetOwner()->GetActorLocation();
	const FVector Offset2D(Offset.X, Offset.Y, 0);
	const FVector Direction2D = Offset2D.GetSafeNormal2D();
	const float Distance = Offset.Size();

	if (Distance < AttackRange * 0.8f)
	{
		return;
	}

	if (LocalControl_bAnimNotifyAttackMove && CVarP3AttackMove.GetValueOnGameThread() != 0)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character)
		{
			Character->AddMovementInput(Direction2D, CVarP3AttackMoveSpeed.GetValueOnGameThread(), true);
		}
	}
}

bool UP3CombatComponent::IsCrossHairMode() const
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!Character)
	{
		return false;
	}

	if (Character->GetCharacterStoreBP().bIsMeleeAiming)
	{
		return true;
	}

	return Character->GetCharacterStoreBP().bIsAiming;
}

bool UP3CombatComponent::LocalControl_IsMeleeCrossHairMode() const
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!Character)
	{
		return false;
	}

	if (Character->GetCharacterStoreBP().bIsMeleeAiming)
	{
		return true;
	}

	return false;
}

void UP3CombatComponent::LocalControl_SetAssistAim(bool bAssist)
{
	LocalControl_bAssistAim = bAssist;
}

void UP3CombatComponent::LocalControl_TickAssistAim(float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("CombatComponent_LocalControl_TickAssistAim"), STAT_CombatComponent_LocalControl_TickAssistAim, STATGROUP_P3);

	ensure(IsLocalControlledActor(GetOwner()));

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return;
	}

	AP3PlayerController* Controller = Cast<AP3PlayerController>(Character->GetController());

	if (!ensure(Controller && Controller->IsLocalController()))
	{
		return;
	}	

	const UP3ComboTableComponent* ComboComp = Character->GetComboComponent();
	if (!ensure(ComboComp))
	{
		return;
	}

	FVector2D LocalControl_CrossHairPosition = ComboComp->GetCrossHairPosition();

	FVector TraceStart;
	FVector TraceDirection;

	if (!Controller->DeprojectScreenPositionToWorld(LocalControl_CrossHairPosition.X, LocalControl_CrossHairPosition.Y, TraceStart, TraceDirection))
	{
		return;
	}

	float MinDistanceSquared = 10E10;
	AP3Character* MinDistCharacter = nullptr;
	FVector2D MinDistCharacterScreenLocation;

	// Search characters
	for (TActorIterator<AP3Character> Iter(GetWorld()); Iter; ++Iter)
	{
		AP3Character* Candidate = *Iter;
		if (Candidate == GetOwner())
		{
			continue;
		}

		const FVector CharacterLocation = Candidate->GetActorLocation();
		
		FVector2D CharacterScreenLocation;
		const bool bProjected = Controller->ProjectWorldLocationToScreen(CharacterLocation, CharacterScreenLocation);

		if (bProjected)
		{
			const float DistanceSquared = (CharacterScreenLocation - LocalControl_CrossHairPosition).SizeSquared();

			if (MinDistanceSquared > DistanceSquared)
			{
				MinDistanceSquared = DistanceSquared;
				MinDistCharacter = Candidate;
				MinDistCharacterScreenLocation = CharacterScreenLocation;
			}
		}
	}

	if (MinDistCharacter)
	{
		//DrawDebugSphere(GetWorld(), MinDistCharacter->GetActorLocation(), 100.0f, 12, FColor::Red, false, -1.0f);
		
		const FVector2D ScreenSpaceOffset = MinDistCharacterScreenLocation - LocalControl_CrossHairPosition;

		FRotator AimModification(0);

		const float MaxScreenSpaceSpeed = 100.0f;
		const float SpeedMultiplier = CVarP3AimAssistSpeed.GetValueOnGameThread();
		const float AspectRatio = Controller->PlayerCameraManager->ViewTarget.POV.AspectRatio;

		AimModification.Pitch = FMath::Clamp(ScreenSpaceOffset.Y, -MaxScreenSpaceSpeed, MaxScreenSpaceSpeed) * -DeltaSeconds * SpeedMultiplier;
		AimModification.Yaw = FMath::Clamp(ScreenSpaceOffset.X, -MaxScreenSpaceSpeed, MaxScreenSpaceSpeed) * DeltaSeconds * SpeedMultiplier * AspectRatio;

		Controller->SetControlRotation(Controller->GetControlRotation() + AimModification);
	}
}

bool UP3CombatComponent::IsAttacking() const
{
	ensure(IsLocalControlledActor(GetOwner()));

	return LocalControl_bIsAttacking;
}

bool UP3CombatComponent::CanCombat() const
{
	if (!GetOwner())
	{
		return false;
	}

	TInlineComponentArray<UP3HolderComponent*> HolderComponents;
	GetOwner()->GetComponents(HolderComponents);

	for (const UP3HolderComponent* HolderComp : HolderComponents)
	{
		if ((HolderComp->GetHoldType() == EP3HoldType::RightHand) && HolderComp->GetHoldingActor())
		{
			return true;
		}
	}

	return false;
}

void UP3CombatComponent::LocalControl_SearchMainTarget()
{
	ensure(IsLocalControlledActor(GetOwner()));

	// See if we have anything new in front of us
	AActor* Owner = GetOwner();
	check(Owner);

	AP3Character* MyCharacter = Cast<AP3Character>(Owner);

	bool bDebugDraw = CVarP3CombatSearchRangeDebug.GetValueOnGameThread() != 0;
	TArray<AActor*> OverlapActors = _FindOverlapActors(*GetWorld(), *Owner, MainTargetSearchRange, MainTargetSearchAngleDegree, bDebugDraw, FColor(128, 255, 128, 5));

	const FVector ForwardVec = Owner->GetActorQuat().GetForwardVector();
	AP3Character* NewCandidate = nullptr;
	float BestCandidatePoint = 0;

	for (AActor* Actor : OverlapActors)
	{
		// Should be P3Character and alive
		AP3Character* Character = Cast<AP3Character>(Actor);
		if (!Character || Character->IsDeadOrDowned())
		{
			continue;
		}

		// Skip ally
		if (MyCharacter && Character->GetFaction() == MyCharacter->GetFaction())
		{
			continue;
		}

		// Calculate Directional and Distance point to pick best candidate
		const float ForwardDot = ((Actor->GetActorLocation() - Owner->GetActorLocation()).GetSafeNormal() | ForwardVec);
		const float DistanceSquared = (Actor->GetActorLocation() - Owner->GetActorLocation()).SizeSquared();
		const float Point = (ForwardDot * (MainTargetSearchRange * MainTargetSearchRange)) + ((MainTargetSearchRange * MainTargetSearchRange) - DistanceSquared);

		if (Point > BestCandidatePoint)
		{
			NewCandidate = Character;
			BestCandidatePoint = Point;
		}
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3CombatDebug.GetValueOnGameThread() != 0 && NewCandidate)
	{
		DrawDebugSphere(GetWorld(), NewCandidate->GetActorLocation(), 50, 16, FColor(128, 255, 128), false, 0.5f);
	}
#endif

	LocalControl_MainTarget = NewCandidate;
}

void UP3CombatComponent::LocalControl_DrawWeapon()
{
	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}

	LocalControl_AutoPutAwayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;

	if (Character && Character->GetStance() != EP3CharacterStance::Combat && ActionComp)
	{
		if (!ActionComp->IsActionInProgress(EPawnActionType::DrawWeapon))
		{
			ActionComp->StartAction(EPawnActionType::DrawWeapon, _FUNCTION_TEXT);
		}
	}
}

void UP3CombatComponent::LocalControl_SearchLockOnTarget()
{
	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}
	
	UCameraComponent* CameraComp = Cast<UCameraComponent>(Character->GetComponentByClass(UCameraComponent::StaticClass()));
	if (!ensure(CameraComp))
	{
		return;
	}

	FMinimalViewInfo CameraView;
	CameraComp->GetCameraView(0.f, CameraView);

	const FQuat CameraQuat = CameraView.Rotation.Quaternion();
	const FVector CameraLocation = CameraView.Location;
	const FVector CameraForward = CameraQuat.GetForwardVector();
	const FVector CameraRight = CameraQuat.GetRightVector();
	const FVector CameraUp = CameraQuat.GetUpVector();
	
	const float FOV = FMath::DegreesToRadians(CameraView.FOV);
	const float ScreenHeight = 2.f * SearchLockOnTargetDistance * FMath::Atan(FOV * 0.5f);
	const float ScreenWidth = ScreenHeight * CameraView.AspectRatio;

	const float HalfScreenWidth = ScreenWidth * 0.5f;
	const float HalfScreenHeight = ScreenHeight * 0.5f;

	FVector V1 = CameraLocation + (CameraRight * -HalfScreenWidth) + (CameraUp * HalfScreenHeight);
	FVector V2 = CameraLocation + (CameraRight * HalfScreenWidth) + (CameraUp * HalfScreenHeight);
	FVector V3 = CameraLocation + (CameraRight * -HalfScreenWidth) + (CameraUp * -HalfScreenHeight);
	
	FVector HalfExtent;
	HalfExtent.X = SearchLockOnTargetDistance * 0.5f;
	HalfExtent.Y = V1.Dist(V1, V2) * 0.5f;
	HalfExtent.Z = V1.Dist(V1, V3) * 0.5f;

	const FVector BoxLocation = CameraLocation + (CameraForward * HalfExtent.X);
	
	static const FName TraceTag("LocalControl_SearchLockOnTarget");
	FCollisionQueryParams QueryParams;
	
	QueryParams.TraceTag = TraceTag;
	QueryParams.AddIgnoredActor(GetOwner());
		
	TArray<FOverlapResult> BoxOverlapResults;
	FCollisionShape CollisionShape;
	CollisionShape.SetBox(HalfExtent);

	GetWorld()->OverlapMultiByChannel(BoxOverlapResults, BoxLocation, CameraQuat, ECC_Pawn, CollisionShape, QueryParams);
			
	LocalControl_LockOnTargets.Reset();

	for (const FOverlapResult& Result : BoxOverlapResults)
	{
		AP3Character* OverlappedCharacter = Cast<AP3Character>(Result.GetActor());
		if (!OverlappedCharacter || OverlappedCharacter->IsDeadOrDowned())
		{
			continue;
		}

		if (OverlappedCharacter->GetFaction() == Character->GetFaction())
		{
			continue;
		}

		LocalControl_LockOnTargets.Add(OverlappedCharacter);
	}

	const FVector SourceLocation = Character->GetActorLocation();
	const float SourceDistanceZ = SearchLockOnTargetDistance;

	LocalControl_LockOnTargets.Sort([SourceLocation, CameraForward, SourceDistanceZ](const TWeakObjectPtr<AP3Character>& A, const TWeakObjectPtr<AP3Character>& B)
	{
		float ForwardDot = ((A.Get()->GetActorLocation() - SourceLocation).GetSafeNormal() | CameraForward);
		float DistanceSquared = (A.Get()->GetActorLocation() - SourceLocation).SizeSquared();
		const float PointA = (ForwardDot * (SourceDistanceZ * SourceDistanceZ)) + ((SourceDistanceZ * SourceDistanceZ) - DistanceSquared);

		ForwardDot = ((B.Get()->GetActorLocation() - SourceLocation).GetSafeNormal() | CameraForward);
		DistanceSquared = (B.Get()->GetActorLocation() - SourceLocation).SizeSquared();
		const float PointB = (ForwardDot * (SourceDistanceZ * SourceDistanceZ)) + ((SourceDistanceZ * SourceDistanceZ) - DistanceSquared);
		
		return PointA < PointB;
	});	

	if (CVarP3LockOnDebug.GetValueOnGameThread() > 0)
	{
		DrawDebugLine(GetWorld(), BoxLocation, BoxLocation + CameraForward * HalfExtent.X, FColor::Red, false, 3.f);
		DrawDebugLine(GetWorld(), BoxLocation, BoxLocation + CameraRight * HalfExtent.Y, FColor::Red, false, 3.f);
		DrawDebugLine(GetWorld(), BoxLocation, BoxLocation + CameraUp * HalfExtent.Z, FColor::Red, false, 3.f);
		DrawDebugPoint(GetWorld(), BoxLocation, 10.f, FColor::Red, false, 3.f);

		DrawDebugBox(GetWorld(), BoxLocation, HalfExtent, CameraQuat, FColor::Red, false, 3.f);
	}
}

void UP3CombatComponent::LocalControl_TickCameraRotationLockOnTarget(float DeltaSeconds)
{
	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}
	
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}	

	if (LockOnTargetDestRotation.IsZero())
	{
		return;
	}

	APlayerController* Controller = Cast<APlayerController>(Character->GetController());
	if (!ensure(Controller))
	{
		return;
	}

	if ((Controller->GetControlRotation() - LockOnTargetDestRotation).IsZero())
	{
		return;
	}

	const float LerpSpeed = FMath::Clamp(DeltaSeconds * CVarP3LookAssistCameraRotationSpeed.GetValueOnGameThread(), 0.0f, 1.0f);
	const FRotator Rotation = FMath::Lerp(Controller->GetControlRotation(), LockOnTargetDestRotation, LerpSpeed);
	Controller->SetControlRotation(Rotation);
}

void UP3CombatComponent::LocalControl_TickReleaseLockOnTarget()
{
	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}

	if (LocalControl_SelectedLookOnTargetIndex < 0)
	{
		return;
	}		

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	if (LocalControl_LockOnTargets.IsValidIndex(LocalControl_SelectedLookOnTargetIndex)
		&& LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex].IsValid())
	{
		const float Dist = FVector::Dist(Character->GetActorLocation(), LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex]->GetActorLocation());
		if (Dist > SearchLockOnTargetDistance)
		{
			LocalControl_SelectedLookOnTargetIndex = -1;
			LockOnTargetDestRotation = FRotator::ZeroRotator;
			LocalControl_LockOnTargetSilhouetter.SetActor(nullptr);
		}
	}
}

void UP3CombatComponent::LocalControl_Player_TickSwing(AP3Character* Character, float DeltaSeconds)
{
	if (CVarP3CombatShowSwingHitParticle.GetValueOnGameThread() == 0)
	{
		return;
	}

	if (!Character)
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

	if (!ActionComp)
	{
		return;
	}

	bool bNewSwing = false;

	if (ActionComp->GetActiveActionType() == EPawnActionType::CombatAttack
		|| ActionComp->GetActiveActionType() == EPawnActionType::CombatCombo)
	{
		bNewSwing = true;
	}

	if (!bNewSwing)
	{
		bSwing = false;
	}
	else
	{
		AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
		UPrimitiveComponent* WeaponPrimComp = Weapon ? Cast<UPrimitiveComponent>(Weapon->GetRootComponent()) : nullptr;

		// TODO: move to cms
		const bool bSwingTypeWeapon = Weapon
			&& (Weapon->GetCmsHoldable().WeaponType == EP3WeaponType::SwordAndShield
				|| Weapon->GetCmsHoldable().WeaponType == EP3WeaponType::GreatSword
				|| Weapon->GetCmsHoldable().WeaponType == EP3WeaponType::Lance);

		if (bSwingTypeWeapon && WeaponPrimComp)
		{
			if (!bSwing)
			{
				// We just started swing
				LastWeaponTransform = Weapon->GetTransform();

				bSwing = true;
			}
			else
			{
				// We are in middle of swing. lets do some sweeping
				const FTransform CurrentWeaponTransform = Weapon->GetTransform();
				
				TArray<AActor*> ChildActors;
				Character->GetAttachedActors(ChildActors);

				FComponentQueryParams QueryParams;
				QueryParams.AddIgnoredActor(Character);
				QueryParams.AddIgnoredActors(ChildActors);
				QueryParams.bIgnoreTouches = true;

				TArray<FHitResult> HitResults;

				GetWorld()->ComponentSweepMulti(HitResults, WeaponPrimComp, LastWeaponTransform.GetLocation(), CurrentWeaponTransform.GetLocation(), CurrentWeaponTransform.GetRotation(), QueryParams); 

				UParticleSystem* HitParticle = P3Core::GetGameResource(this).HitObjectParticle;

				for (const FHitResult& HitResult : HitResults)
				{
					//AActor* HitActor = HitResult.GetActor();
					//DrawDebugSphere(GetWorld(), HitResult.ImpactPoint, 10.0f, 24, FColor::Red, false, 3.0f);

					UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), HitParticle, HitResult.ImpactPoint, FRotator::ZeroRotator);
				}

				LastWeaponTransform = Weapon->GetTransform();
			}
		}
	}
}

void UP3CombatComponent::OnStartAttackInput()
{
	AActor* Owner = GetOwner();

	if (!Owner)
	{
		return;
	}

	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}

	if (!CanCombat())
	{
		P3JsonLog(Error, "Failed to start attack. can't combat");
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	// See if we are deprecated due to combo
	UP3ComboTableComponent* ComboComp = Character ? Character->GetComboComponent() : nullptr;
	if (ComboComp)
	{
		if (ComboComp->IsComboEnabled())
		{
			return;
		}
	}

	if (Character && Character->GetCharacterStoreBP().bIsAiming && Character->CanThrowWeaponBP())
	{
		AActor* WeaponActor = Character->GetRightHandWeaponActor();
		if (!ensure(WeaponActor))
		{
			return;
		}

		FP3PawnActionStartRequestParams ActionParams;

		bool bHit = false;
		FHitResult HitResult;
		FVector AimTarget;

		const bool bFoundTargetLocation = LocalControl_LineTraceCrossHair(bHit, HitResult, nullptr, &AimTarget);

		if (!ensure(bFoundTargetLocation))
		{
			P3JsonLog(Warning, "Throw weapon failed. Cross hair line trace failed");
			return;
		}

		DrawDebugCrosshairs(GetWorld(), HitResult.Location, Character->GetActorRotation(), 100.0f, FColor::Red, false, 3.0f, 0);

		if (bHit)
		{
			ActionParams.ThrowWeapon_Direction = (HitResult.Location - WeaponActor->GetActorLocation()).GetSafeNormal();
		}
		else
		{
			APlayerController* Controller = Cast<APlayerController>(Character->GetController());

			if (!Controller)
			{
				P3JsonLog(Warning, "Throw weapon failed. No player controller");
				return;
			}
			ActionParams.ThrowWeapon_Direction = Controller->GetControlRotation().Vector();
		}

		Character->GetActionComponent()->StartAction(EPawnActionType::ThrowWeapon, _FUNCTION_TEXT, ActionParams);
		return;
	}

	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;

	if (Character && Character->GetStance() != EP3CharacterStance::Combat)
	{
		LocalControl_DrawWeapon();
		return;
	}

	LocalControl_bIsAttacking = true;
	LocalControl_AutoPutAwayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();

	if (!IsCrossHairMode())
	{
		LocalControl_SearchMainTarget();
	}

	if (Character->GetCharacterStoreBP().bIsBlocking && Character->GetAnimMontages().ShieldAttacks.Num() > 0)
	{
		if (ActionComp && ActionComp->CanStartAction(EPawnActionType::CombatAttack))
		{
			FP3PawnActionStartRequestParams Params;
			Params.CombatAttack_Target = LocalControl_MainTarget.Get();
			Params.CombatAttack_MontageIndex = FMath::Rand() % Character->GetAnimMontages().ShieldAttacks.Num();
			Params.CombatAttack_bIsShieldAttack = true;

			if (CVarP3CombatRotateToTarget.GetValueOnGameThread() == 1)
			{
				if (LocalControl_MainTarget.IsValid())
				{
					const FVector Offset = LocalControl_MainTarget->GetActorLocation() - GetOwner()->GetActorLocation();
					Params.CombatAttack_ChracterRotator = Offset.GetSafeNormal2D().Rotation();
				}
			}

			ActionComp->StartAction(EPawnActionType::CombatAttack, _FUNCTION_TEXT, Params);
		}
	}
}

void UP3CombatComponent::OnStopAttackInput()
{
	AActor* Owner = GetOwner();

	if (!Owner)
	{
		return;
	}

	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}

	if (!LocalControl_bIsAttacking)
	{
		return;
	}

	LocalControl_MainTarget.Reset();
	LocalControl_bIsAttacking = false;

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!Character)
	{
		return;
	}

	UP3ComboTableComponent* ComboComp = Character->GetComboComponent();

	if (ComboComp && ComboComp->IsComboEnabled())
	{
		return;		
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

	if (!ActionComp)
	{
		return;
	}

	if (!ActionComp->IsActionInProgress(EPawnActionType::CombatAttack) && !ActionComp->IsActionInProgress(EPawnActionType::CombatRangedAttack))
	{
		return;
	}

	P3JsonLog(Verbose, "Request stop action",
		TEXT("Character"), *Character->GetName(),
		TEXT("ActionId"), ActionComp->GetActiveActionId());

	ActionComp->StopAction(ActionComp->GetActiveActionId(), FP3PawnActionStopRequestParams());
}

void UP3CombatComponent::OnCharacterStoreChanged(const FP3CharacterStore& OldStore, const FP3CharacterStore& NewStore)
{
}

void UP3CombatComponent::OnLockOnPressed()
{
	if (LocalControl_SelectedLookOnTargetIndex < 0)
	{
		LocalControl_SearchLockOnTarget();

		if (LocalControl_LockOnTargets.Num() > 0 && LocalControl_LockOnTargets.Top().IsValid())
		{
			LocalControl_SelectedLookOnTargetIndex = 0;
			LocalControl_LockOnTargetSilhouetter.SetActor(LocalControl_LockOnTargets.Top().Get());
		}
	}
	else
	{
		LocalControl_SelectedLookOnTargetIndex = -1;
		LocalControl_LockOnTargets.Reset();
	}

	bLockOnButtonPressed = true;
}

void UP3CombatComponent::OnLockOnReleased()
{
	if (LocalControl_SelectedLookOnTargetIndex < 0)
	{
		if (LocalControl_LockOnTargets.Num() <= 0 )
		{
			LocalControl_LockOnTargetSilhouetter.SetActor(nullptr);
			LocalControl_SelectedLookOnTargetIndex = -1;
		}
	}		

	bLockOnButtonPressed = false;
}

void UP3CombatComponent::OnNextLockOn()
{
	if (bLockOnButtonPressed && LocalControl_LockOnTargets.Num() > 1)
	{
		if (!LocalControl_LockOnTargets.IsValidIndex(LocalControl_SelectedLookOnTargetIndex + 1))
		{
			LocalControl_SelectedLookOnTargetIndex = 0;
		}
		else
		{
			LocalControl_SelectedLookOnTargetIndex++;
		}

		if (LocalControl_LockOnTargets.IsValidIndex(LocalControl_SelectedLookOnTargetIndex)
			&& LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex].IsValid())
		{			
			LocalControl_LockOnTargetSilhouetter.SetActor(LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex].Get());
		}				
	}
}

void UP3CombatComponent::OnPrevLockOn()
{
	if (bLockOnButtonPressed && LocalControl_LockOnTargets.Num() > 1)
	{
		if (!LocalControl_LockOnTargets.IsValidIndex(LocalControl_SelectedLookOnTargetIndex - 1))
		{
			LocalControl_SelectedLookOnTargetIndex = LocalControl_LockOnTargets.Num() - 1;
		}
		else
		{
			LocalControl_SelectedLookOnTargetIndex--;
		}

		if (LocalControl_LockOnTargets.IsValidIndex(LocalControl_SelectedLookOnTargetIndex)
			&& LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex].IsValid())
		{			
			LocalControl_LockOnTargetSilhouetter.SetActor(LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex].Get());
		}		
	}
}

void UP3CombatComponent::OnLookAssist()
{
	if (LocalControl_SelectedLookOnTargetIndex >= 0)
	{
		if (LocalControl_LockOnTargets.IsValidIndex(LocalControl_SelectedLookOnTargetIndex)
			&& LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex].IsValid())
		{
			LockOnTargetDestRotation = (LocalControl_LockOnTargets[LocalControl_SelectedLookOnTargetIndex].Get()->GetActorLocation() - GetOwner()->GetActorLocation()).Rotation();
		}
	}
	else
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character)
		{
			AP3PlayerController* MyController = Cast<AP3PlayerController>(Character->GetController());

			if (MyController && MyController->IsLocalController())
			{
				MyController->LookForward(Character->GetActorRotation());
			}
		}		
	}
}

void UP3CombatComponent::OnInputMoveLook(float Rate)
{
	LockOnTargetDestRotation = FRotator::ZeroRotator;
}

void UP3CombatComponent::OnPartBroken(class UP3PartComponent* PartComp)
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		const FP3CharacterPartDesc& PartDesc = PartComp->GetPartDesc();

		for (const FName& BoneName : PartDesc.DisableBoneNamesOnPartBroken)
		{
			FP3DisabledBoneData DisabledBoneData;
			DisabledBoneData.RequestPartComponent = PartComp;
			DisabledBoneData.DisabledBoneName = BoneName;

			Server_DisabledBoneNameOnBoneAttack.Add(DisabledBoneData);
		}
	}
}

void UP3CombatComponent::Server_TimeoutHitLogs()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const float TimeoutDurationSeconds = CVarP3CombatAnimMultipleHitIgnoreDurationSeconds.GetValueOnGameThread();
	const float TimeoutSeconds = GetWorld()->GetTimeSeconds() - TimeoutDurationSeconds;

	for (auto Iter = Server_HitLogActors.CreateIterator(); Iter; ++Iter)
	{
		if (Iter.Value() <= TimeoutSeconds)
		{
			Iter.RemoveCurrent();
		}
	}
}

void UP3CombatComponent::PutAwayWeapon()
{
	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;

	if (ActionComp)
	{
		ActionComp->StartAction(EPawnActionType::PutAwayWeapon, _FUNCTION_TEXT);
	}

	LocalControl_LastPutawayWeaponTimeSeconds = GetWorld()->GetTimeSeconds();
}

void UP3CombatComponent::OnAttackMoveAnimNotifyBegin()
{
	LocalControl_bAnimNotifyAttackMove = true;
}

void UP3CombatComponent::OnAttackMoveAnimNotifyEnd()
{
	LocalControl_bAnimNotifyAttackMove = false;
}

void UP3CombatComponent::OnAttackWithSkeletalMeshPhysicsBegin(const TArray<FName>& BoneNames, UAnimNotifyState_BoneAttack* Notify, UAnimSequenceBase* Animation)
{
	FBoneAttackAnimNotify& NewNotify = BoneAttackAnimNotifies.AddDefaulted_GetRef();

	NewNotify.Notify = MakeWeakObjectPtr(Notify);
	NewNotify.Animation = MakeWeakObjectPtr(Animation);

	for (const FName& BoneName : BoneNames)
	{
		NewNotify.Bones.Add(BoneName);
	}
}

void UP3CombatComponent::OnAttackWithSkeletalMeshPhysicsEnd(const TArray<FName>& BoneNames, UAnimNotifyState_BoneAttack* Notify, UAnimSequenceBase* Animation)
{
	bool bRemoved = false;

	for (int32 Index = 0; Index < BoneAttackAnimNotifies.Num(); ++Index)
	{
		const FBoneAttackAnimNotify& AttackBoneAnimNotify = BoneAttackAnimNotifies[Index];

		if (AttackBoneAnimNotify.Notify.Get() == Notify
			&& AttackBoneAnimNotify.Animation.Get() == Animation)
		{
			BoneAttackAnimNotifies.RemoveAt(Index);
			bRemoved = true;
			break;
		}
	}

	ensure(bRemoved);
}

void UP3CombatComponent::Client_ShowProjectile(const TSubclassOf<AP3Projectile>& ProjectileClass, const FName& AttachBoneName, bool bIsEnabled)
{	
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!Character || !Character->GetMesh())
	{
		return;
	}

	UStaticMesh* StaticMesh = ShowProjectiles.FindRef(ProjectileClass);
	if (StaticMesh)
	{		
		if (!ShowProjectileComponent)
		{
			ShowProjectileComponent = NewObject<UStaticMeshComponent>(GetOwner());
			if (!ShowProjectileComponent)
			{
				return;
			}

			ShowProjectileComponent->SetupAttachment(Character->GetMesh(), AttachBoneName);
			ShowProjectileComponent->SetStaticMesh(StaticMesh);
			ShowProjectileComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			ShowProjectileComponent->RegisterComponent();
		}
		else
		{
			ShowProjectileComponent->SetStaticMesh(StaticMesh);
		}

		if (bIsEnabled)
		{			
			if (ShowProjectileComponent->GetAttachSocketName() != AttachBoneName)
			{
				ShowProjectileComponent->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
				ShowProjectileComponent->AttachToComponent(Character->GetMesh(),FAttachmentTransformRules::KeepWorldTransform, AttachBoneName);
			}

			ShowProjectileComponent->SetHiddenInGame(false);
		}
		else
		{			
			ShowProjectileComponent->SetHiddenInGame(true);
		}
	}	
}

int32 UP3CombatComponent::GetCancelChargingBraceLevel() const
{
	// This is temporal 'Help to Quick Balancing' feature
	const int32 OverrideValue = CVarP3BracingLevelOverride.GetValueOnGameThread();

	return OverrideValue > 0 ? OverrideValue : CancelChargingBraceLevel;
}

bool UP3CombatComponent::IsActorInAttackRange(const AActor* TargetActor, int32 SkillIndex, float RangeAddition) const
{
	if (!GetOwner())
	{
		return false;
	}

	float CurrentAttackRange = AttackRange;
	float CurrentAttackDistanceZ = AttackDistanceZ;

	const FP3CmsCombatSkill* CmsCombatSkill = GetCmsCombatSkill(SkillIndex);
	if (SkillIndex != -1 && ensure(CmsCombatSkill))
	{
		CurrentAttackRange = CmsCombatSkill->AttackRange;
		CurrentAttackDistanceZ = CmsCombatSkill->AttackDistanceZ;
	}

	CurrentAttackRange += RangeAddition;
	CurrentAttackRange = FMath::Max(CurrentAttackRange, 0.0f);
	CurrentAttackRange *= GetOwner()->GetActorScale().X;

	float TargetCollisionRadius = 0.0f;
	float TargetCollisionHalfHeight = 0.0f;
	TargetActor->GetSimpleCollisionCylinder(TargetCollisionRadius, TargetCollisionHalfHeight);

	float MyCollisionRadius = 0.0f;
	float MyCollisionHalfHeight = 0.0f;
	GetOwner()->GetSimpleCollisionCylinder(MyCollisionRadius, MyCollisionHalfHeight);

	// Current combat logic doesn't care about my capsule size
	MyCollisionRadius = 0.0f;

	const float DistanceSquared2D = (TargetActor->GetActorLocation() - GetOwner()->GetActorLocation()).SizeSquared2D();
	const float AttackDistance = CurrentAttackRange + MyCollisionRadius + TargetCollisionRadius;

	if (DistanceSquared2D > FMath::Square(AttackDistance))
	{
		return false;
	}

	const float DistanceZ = TargetActor->GetActorLocation().Z - GetOwner()->GetActorLocation().Z;
	if (FMath::Abs(DistanceZ) > (MyCollisionHalfHeight + TargetCollisionHalfHeight + CurrentAttackDistanceZ))
	{
		return false;
	}

	return true;
}

bool UP3CombatComponent::IsIgnoreUnreachableActorAttack(AActor* DamageSourceActor) const
{
	if (CVarP3IgnoreUnreachableActorAttackCountThreshold.GetValueOnGameThread() == 0)
	{
		return false;
	}

	// Ignore damage if the unreachable actor attack over max endure attack
	const bool IsDamageSourceAtUnreachablePlace = UnreachableActorList.ContainsByPredicate([DamageSourceActor](const FP3UnreachableActor& UnreachableActor) -> bool {
		if (UnreachableActor.Actor == DamageSourceActor)
		{
			return (UnreachableActor.AttackCount > CVarP3IgnoreUnreachableActorAttackCountThreshold.GetValueOnGameThread());
		}
		return false;
	});

	return IsDamageSourceAtUnreachablePlace;
}

void UP3CombatComponent::Server_UpdateUnreachableActorList(AActor* DamageSourceActor)
{
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return;
	}

	if (!DamageSourceActor)
	{
		return;
	}

	AP3Character* MyCharacter = Cast<AP3Character>(GetOwner());
	if (MyCharacter && MyCharacter->IsPlayerControlled())
	{
		return;
	}

	bool DoesPathExistToDamageSourceActor = Server_DoesPathExistToDamageSourceActor(DamageSourceActor);
	FP3UnreachableActor* ActorInUnreachableActorList = UnreachableActorList.FindByPredicate([DamageSourceActor](const FP3UnreachableActor& UnreachableActor) -> bool {
		return (UnreachableActor.Actor == DamageSourceActor);
	});

	// Add the damage source actor in list if the actor is in unreachable place
	if (!DoesPathExistToDamageSourceActor)
	{
		if (!ActorInUnreachableActorList)
		{
			UnreachableActorList.Add(FP3UnreachableActor({ DamageSourceActor, 1 }));
		}
		else
		{
			ActorInUnreachableActorList->AttackCount += 1;
		}
	}
	else
	{
		// Remove the damage source actor from list If reachable damage source is in unreachable actor list
		if (ActorInUnreachableActorList)
		{
			UnreachableActorList.RemoveAll([DamageSourceActor](const FP3UnreachableActor& UnreachableActor) {
				return (UnreachableActor.Actor == DamageSourceActor);
			});
		}
	}
}

bool UP3CombatComponent::Server_DoesPathExistToDamageSourceActor(AActor* DamageSourceActor) const
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3CombatComponent_Server_DoesPathExistToDamageSourceActor"), STAT_P3CombatComponent_Server_DoesPathExistToDamageSourceActor, STATGROUP_P3);

	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return false;
	}

	AP3Character* MyCharacter = Cast<AP3Character>(GetOwner());
	if (MyCharacter->IsPlayerControlled())
	{
		return false;
	}

	if (!DamageSourceActor)
	{
		return false;
	}

	FVector SourceActorLocation = DamageSourceActor->GetActorLocation();
	FVector TargetActorLocation = MyCharacter->GetActorLocation();
	bool bHasPath = false;

	const UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	if (NavSys)
	{
		const AAIController* AIOwner = Cast<AAIController>(MyCharacter->GetController());
		const ANavigationData* NavData = AIOwner ? NavSys->GetNavDataForProps(AIOwner->GetNavAgentPropertiesRef()) : NULL;
		if (NavData)
		{
			FSharedConstNavQueryFilter QueryFilter = UNavigationQueryFilter::GetQueryFilter(*NavData, AIOwner, NaviQueryFilterClassToDamageSource);

			if (PathQueryTypeToDamageSource == EP3PathExistanceQueryType::NavmeshRaycast2D)
			{
#if WITH_RECAST
				const ARecastNavMesh* RecastNavMesh = Cast<const ARecastNavMesh>(NavData);
				bHasPath = RecastNavMesh && RecastNavMesh->IsSegmentOnNavmesh(SourceActorLocation, TargetActorLocation, QueryFilter);
#endif
			}
			else
			{
				EPathFindingMode::Type TestMode = (PathQueryTypeToDamageSource == EP3PathExistanceQueryType::HierarchicalQuery) ? EPathFindingMode::Hierarchical : EPathFindingMode::Regular;
				bHasPath = NavSys->TestPathSync(FPathFindingQuery(AIOwner, *NavData, SourceActorLocation, TargetActorLocation, QueryFilter), TestMode);
			}
		}
	}

	return bHasPath;
}

const TArray<FP3CombatSkill>& UP3CombatComponent::GetSkills() const
{
	return Skills;
}

const FP3CombatSkill* UP3CombatComponent::GetSkill(int32 Index) const
{
	return Skills.IsValidIndex(Index) ? &Skills[Index] : nullptr;
}

FP3CombatSkill* UP3CombatComponent::GetSkill(int32 Index)
{
	return Skills.IsValidIndex(Index) ? &Skills[Index] : nullptr;
}

const FP3CmsCombatSkill* UP3CombatComponent::GetCmsCombatSkill(int32 Index) const
{
	return Skills.IsValidIndex(Index) ? Skills[Index].CmsCombatSkill : nullptr;
}

bool UP3CombatComponent::Server_CanUseSkill(int32 SkillIndex) const
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return false;
	}

	const FP3CombatSkill* Skill = GetSkill(SkillIndex);
	if (!Skill)
	{
		return false;
	}

	const FP3CmsCombatSkill* CmsCombatSkill = Skill->CmsCombatSkill;
	if (!ensure(CmsCombatSkill))
	{
		return false;
	}

	const float Now = GetWorld()->GetTimeSeconds();

	// See if we are still in cool down
	if (Skill->Server_NextCooldownFinishTimeSeconds > Now)
	{
		return false;
	}

	// See if gameplaytag is required
	if (CmsCombatSkill->RequiredGameplayTagsAny.Num() > 0 || CmsCombatSkill->DisableGameplaytagsAny.Num())
	{
		IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(GetOwner());
		if (GameplayTagAsset)
		{
			const bool bHasRequiredTags = (CmsCombatSkill->RequiredGameplayTagsAny.Num() == 0)
				|| GameplayTagAsset->HasAnyMatchingGameplayTags(CmsCombatSkill->RequiredGameplayTagsAny);

			if (!bHasRequiredTags)
			{
				return false;
			}

			const bool bHasDisableTags = (CmsCombatSkill->DisableGameplaytagsAny.Num() != 0)
				&& GameplayTagAsset->HasAnyMatchingGameplayTags(CmsCombatSkill->DisableGameplaytagsAny);

			if (bHasDisableTags)
			{
				return false;
			}
		}
	}


	return true;
}

void UP3CombatComponent::Server_SetLastDamageSource(AP3Character* SourceCharacter)
{
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return;
	}

	Server_LastDamageSource = SourceCharacter;
}

class AP3Character* UP3CombatComponent::Server_GetLastDamageSource() const
{
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return nullptr;
	}

	return Server_LastDamageSource;
}

void UP3CombatComponent::Server_OnSkillStarted(int32 SkillIndex)
{
	FP3CombatSkill* Skill = GetSkill(SkillIndex);
	if (!ensure(Skill && Skill->CmsCombatSkill))
	{
		return;
	}

	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return;
	}

	Skill->Server_NextCooldownFinishTimeSeconds = GetWorld()->GetTimeSeconds() + Skill->CmsCombatSkill->CooldownTimeSeconds;

}

const static void _GetPartBoneNames(const AActor& Actor, TSet<FName>& OutBoneNames)
{
	TInlineComponentArray<UP3PartComponent*, 8> PartComponents;
	Actor.GetComponents(PartComponents);

	for (UP3PartComponent* PartComp : PartComponents)
	{
		for (const FName& BoneName : PartComp->GetPartDesc().HitAreaBones)
		{
			OutBoneNames.Add(BoneName);
		}
	}
}

void UP3CombatComponent::Server_OnHitNotify(const FP3CmsCombatHit& CombatHitDesc, const FVector& LocalImpactDirection, int32 SkillIndex, const AActor* TargetActor, const FName& CmsCombatHitKey, int32 ActionId, const UAnimSequenceBase* AnimSequence, const FName& SocketName)
{
	// Only server is allowed to process hit
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		return;
	}

	AActor* Owner = GetOwner();
	if (!Owner)
	{
		return;
	}

	AP3Character* MyCharacter = Cast<AP3Character>(Owner);
	if (MyCharacter && MyCharacter->IsDeadOrDowned())
	{
		return;
	}

	if (Server_HitLogActionId != ActionId)
	{
		Server_HitLogActionId = ActionId;
		Server_HitLogActors.Empty();
	}

	Server_TimeoutHitLogs();

	const float Now = GetWorld()->GetTimeSeconds();
	const EP3WeaponType WeaponType = MyCharacter ? MyCharacter->GetRightHandWeaponType() : EP3WeaponType::None;

	float CurrentAttackRange = CombatHitDesc.AttackRange;
	float CurrentAttackAngleDegree = CombatHitDesc.ConeHalfAngleDegree * 2.0f;
	FRotator CurrentConeRotation = CombatHitDesc.ConeRotation;

	if (CombatHitDesc.SpawnActorClass.LoadSynchronous())
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		SpawnParams.Instigator = MyCharacter;

		FTransform SpawnTransform = Owner->GetActorTransform();

		if (TargetActor && CombatHitDesc.bSpawnActorAtTarget)
		{
			SpawnTransform = TargetActor->GetActorTransform();
		}

		SpawnTransform.SetScale3D(FVector(1, 1, 1));

		GetWorld()->SpawnActor<AActor>(CombatHitDesc.SpawnActorClass.LoadSynchronous(), SpawnTransform, SpawnParams);
	}

	if (SkillIndex >= 0)
	{
		const FP3CombatSkill* Skill = GetSkill(SkillIndex);
		if (ensure(Skill && Skill->CmsCombatSkill))
		{
			if (Skill->CmsCombatSkill->SpawnActorClass.LoadSynchronous())
			{
				FActorSpawnParameters SpawnParams;
				SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
				SpawnParams.Instigator = MyCharacter;

				FTransform SpawnTransform = Owner->GetActorTransform();
				SpawnTransform.SetScale3D(FVector(1, 1, 1));

				GetWorld()->SpawnActor<AActor>(Skill->CmsCombatSkill->SpawnActorClass.LoadSynchronous(), SpawnTransform, SpawnParams);
			}
		}
	}

	CurrentAttackRange *= GetOwner()->GetActorScale().X;

	const bool bDebugDraw = CVarP3CombatAttackRangeDebug.GetValueOnGameThread() != 0;

	const FTransform SweepTransform = MyCharacter->GetMesh() && !SocketName.IsNone() ? 
		MyCharacter->GetMesh()->GetSocketTransform(SocketName) : Owner->GetActorTransform();
	const FQuat SweepQuat = SweepTransform.GetRotation() * CurrentConeRotation.Quaternion();

	TArray<FMeleeAttackSweepResult> SweepResults = _SweepMeleeAttackHits(*GetWorld(), *Owner, CurrentAttackRange, CurrentAttackAngleDegree, SweepTransform.GetLocation(), SweepQuat, bDebugDraw, FColor(255, 0, 0, 5));

	const FVector MyLocation = MyCharacter->GetActorLocation();

	SweepResults.Sort([&MyLocation](const FMeleeAttackSweepResult& A, const FMeleeAttackSweepResult& B) -> bool
	{
		if (&A.Actor == &B.Actor)
		{
			TSet<FName> PartBoneNames;
			_GetPartBoneNames(A.Actor, PartBoneNames);

			if (PartBoneNames.Contains(A.BoneName))
			{
				return true;
			}
			if (PartBoneNames.Contains(B.BoneName))
			{
				return false;
			}
			
			const AP3Character* CharacterA = Cast<AP3Character>(&A.Actor);
			const AP3Character* CharacterB = Cast<AP3Character>(&B.Actor);
			const FVector LocationA = (A.BoneName.IsValid() && CharacterA && CharacterA->GetMesh()) 
				? CharacterA->GetMesh()->GetSocketLocation(A.BoneName) : A.Actor.GetActorLocation();
			const FVector LocationB = (B.BoneName.IsValid() && CharacterB && CharacterB->GetMesh())
				? CharacterB->GetMesh()->GetSocketLocation(B.BoneName) : B.Actor.GetActorLocation();

			const float DistanceA = (LocationA - MyLocation).SizeSquared();
			const float DistanceB = (LocationB - MyLocation).SizeSquared();

			return (DistanceA < DistanceB);
		}

		return A.Actor < B.Actor;
	});

	TArray<AActor*> ProcessedActors;

	for (const FMeleeAttackSweepResult& SweepResult : SweepResults)
	{
		AP3Character* TargetCharacter = Cast<AP3Character>(&SweepResult.Actor);

		// Ignore mounted one
		if (TargetCharacter
			&& TargetCharacter->GetCharacterStoreBP().MountTargetCharacter
			&& TargetCharacter->GetCharacterStoreBP().MountTargetCharacter == MyCharacter)
		{
			continue;
		}

		bool bAllowMultipleHit = false;

		if (SweepResult.Actor.IsA(AInstancedFoliageActor::StaticClass()))
		{
			bAllowMultipleHit = true;
		}

		if (!bAllowMultipleHit)
		{
			if (bUseHitLog && Server_HitLogActors.Contains(&SweepResult.Actor))
			{
				continue;
			}

			Server_HitLogActors.Add(&SweepResult.Actor, Now);

			if (ProcessedActors.Contains(&SweepResult.Actor))
			{
				continue;
			}

			ProcessedActors.Add(&SweepResult.Actor);
		}

		const FVector WorldImpactDirection = Owner->GetActorRotation().RotateVector(LocalImpactDirection);
		const FVector* HitLocation = SweepResult.BoneName.IsValid() ? &SweepResult.Location : nullptr;

		P3Combat::FDamageActorParams DamageParams(*Owner, SweepResult.Actor);
		DamageParams.AttackStrength = CombatHitDesc.AttackStrength;
		DamageParams.AttackDirection = CombatHitDesc.AttackDirection;
		DamageParams.AttackAttribute = CombatHitDesc.AttackAttribute;
		DamageParams.TagName = CombatHitDesc.TagName;
		DamageParams.TargetComponent = SweepResult.HitResult.GetComponent();
		DamageParams.TargetHitItemIndex = SweepResult.HitResult.Item;
		DamageParams.WeaponType = WeaponType;
		DamageParams.ImpactDirection = WorldImpactDirection;
		DamageParams.BoneName = SweepResult.BoneName;
		DamageParams.DamagePermil = CombatHitDesc.DamagePermil;
		DamageParams.DamageDestructiblePermil = CombatHitDesc.DamageDestructiblePermil;
		DamageParams.bCanDamageAlly = CombatHitDesc.bCanDamageAlly;
		DamageParams.HitLocation = HitLocation;
		DamageParams.bIsFrameHold = CombatHitDesc.bIsFrameHold;
		DamageParams.CmsCombatHitKey = CmsCombatHitKey;
		DamageParams.CmsCameraShakeKey = CombatHitDesc.CmsCameraShakeName;

		const EP3GiveDamageResult Result = P3Combat::Server_DamageActor(DamageParams);

		if (Result == EP3GiveDamageResult::HitAction)
		{
			if (ensure(TargetCharacter) && MyCharacter->IsPlayerControlled())
			{
				Server_MainTarget.OnAttack(TargetCharacter);
			}
		}

		//DrawDebugPoint(GetWorld(), HitResult.Location, 30.0f, FColor::Yellow, false, 2.0f);
		//if (HitResult.BoneName.IsValid())
		//{
		//	AP3Character* Character = Cast<AP3Character>(&HitResult.Actor);
		//	if (Character)
		//	{
		//		DrawDebugPoint(GetWorld(), Character->GetMesh()->GetSocketLocation(HitResult.BoneName), 30.0f, FColor::Green, false, 2.0f);
		//	}
		//}
	}
}

/**
 * FServerMainTarget
 */

void FServerMainTarget::OnTick(AP3Character& MyCharacter, float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("FServerMainTarget_OnTick"), STAT_FServerMainTarget_OnTick, STATGROUP_P3);

	RemoveInvalidCandidates();
	
	bool bTickWatch = true;

	if (Candidates.Num() == 0)
	{
		// Slow down tick rate if nothing intrested, since watch has heavy query calls inside
		bTickWatch = ((FMath::Rand() % 10) == 0);
	}

	if (bTickWatch)
	{
		TickWatch(MyCharacter, DeltaSeconds);
	}

	TickChangeMainTarget();

	if (CVarP3CombatDebugServerMainTarget.GetValueOnGameThread() != 0)
	{
		if (MyCharacter.IsPlayerControlled())
		{
			APlayerController* PlayerController = MyCharacter.GetWorld()->GetFirstPlayerController();
			if (PlayerController)
			{
				const FRotator ControlRotation = PlayerController->GetControlRotation();
				const FVector CameraRightVector = ControlRotation.RotateVector(FVector(0, 1, 0));

				for (FCandidate& Candidate : Candidates)
				{
					//Candidate.Character->AddDebugString(FString::Printf(TEXT("MT(%.2f/%.2f, %.2f)"), Candidate.WatchPoint, Candidate.LastWatchPoint, Candidate.AttackPoint));

					const FBoxSphereBounds& Bounds = Candidate.Character->GetCapsuleComponent()->Bounds;
					const FVector BoundTop = Bounds.Origin + FVector(0, 0, Bounds.SphereRadius);

					if (Candidate.Character == MainTarget)
					{
						DrawDebugPoint(MyCharacter.GetWorld(), BoundTop + FVector(0, 0, -10), 20.0f, FColor::Cyan);
					}

					DrawDebugLine(MyCharacter.GetWorld(), MyCharacter.GetActorLocation(), Candidate.Character->GetActorLocation(), FColor::Red);
					DrawDebugLine(MyCharacter.GetWorld(), BoundTop, BoundTop + FVector(0, 0, Candidate.LastWatchPoint), FColor::Green, false, -1.0f, 0, 5.0f);
					DrawDebugLine(MyCharacter.GetWorld(), BoundTop + (CameraRightVector * 10), BoundTop + (CameraRightVector * 10) + FVector(0, 0, Candidate.WatchPoint), FColor::Red, false, -1.0f, 0, 5.0f);
				}

				MyCharacter.AddDebugString(FString::Printf(TEXT("MainTarget: %s")
					, MainTarget.IsValid() ? *MainTarget.Get()->GetName() : TEXT("NULL")));
			}
		}
	}
}

void FServerMainTarget::RemoveInvalidCandidates()
{
	Candidates.RemoveAll([](const FCandidate& Candidate) -> bool {
		if (Candidate.WatchPoint < 0/* && Candidate.AttackPoint <= 0*/)
		{
			return true;
		}

		if (!Candidate.Character.IsValid())
		{
			return true;
		}

		if (Candidate.Character->IsDeadOrDowned())
		{
			return true;
		}

		return false;
	});
}

void FServerMainTarget::TickWatch(AP3Character& MyCharacter, float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("FServerMainTarget_TickWatch"), STAT_FServerMainTarget_TickWatch, STATGROUP_P3);

	TArray<FOverlapResult> OverlapResults;
	{
		FCollisionShape CollisionShape;
		CollisionShape.SetSphere(500);

		FCollisionQueryParams QueryParams;
		QueryParams.AddIgnoredActor(&MyCharacter);

		FCollisionResponseParams ResponsParams(ECR_Ignore);
		ResponsParams.CollisionResponse.SetResponse(ECC_Pawn, ECR_Overlap);

		MyCharacter.GetWorld()->OverlapMultiByChannel(OverlapResults, MyCharacter.GetActorLocation(), MyCharacter.GetActorQuat(), ECC_Pawn, CollisionShape, QueryParams);
	}

	TArray<AP3Character*> NearCharacters;

	for (const FOverlapResult& OverlapResult : OverlapResults)
	{
		AP3Character* Character = Cast<AP3Character>(OverlapResult.GetActor());
		if (Character && Character->GetFaction() != MyCharacter.GetFaction())
		{
			NearCharacters.AddUnique(Character);
		}
	}

	const float MaxWatchPoint = 100.0f;

	// List to remove from candidate
	TArray<AP3Character*> OutOfInterestCharacters;

	// List to clear watch point (still in range but not watching)
	TArray<AP3Character*> OutOfSightCharacters;

	// Initialize OutOfInterestCharacters from all candidate
	for (const FCandidate& Candidate : Candidates)
	{
		ensure(!OutOfInterestCharacters.Contains(Candidate.Character.Get()));

		OutOfInterestCharacters.Add(Candidate.Character.Get());
	}

	for (AP3Character* Character : NearCharacters)
	{
		const FVector Offset = Character->GetActorLocation() - MyCharacter.GetActorLocation();
		const FVector Direction2D = Offset.GetSafeNormal2D();
		const float ForwardDotOffset = MyCharacter.GetActorQuat().GetForwardVector() | Direction2D;

		if (ForwardDotOffset > 0)
		{
			const float Distance = Offset.Size();

			// Square ForwardDotOffset to linearize cosine graph
			float WatchPoint = MaxWatchPoint * (ForwardDotOffset * ForwardDotOffset);

			WatchPoint *= FMath::Max(0.0f, 1.0f - (Distance / 500.0f));

			if (WatchPoint > 0)
			{
				TickWatchPoint(Character, WatchPoint, DeltaSeconds);

				// We are interested in this character
				OutOfInterestCharacters.Remove(Character);
			}
		}
		else
		{
			OutOfInterestCharacters.Remove(Character);
			OutOfSightCharacters.Add(Character);

		}
	}

	for (AP3Character* Character : OutOfInterestCharacters)
	{
		TickWatchPoint(Character, -10.0f, DeltaSeconds);
	}

	for (AP3Character* Character : OutOfSightCharacters)
	{
		TickWatchPoint(Character, 0.0f, DeltaSeconds);
	}
}

void FServerMainTarget::TickWatchPoint(AP3Character* WatchingCharacter, float Point, float DeltaSeconds)
{
	FCandidate* OldCandidate = Candidates.FindByPredicate([WatchingCharacter](const FCandidate& Candidate) -> bool {
		return Candidate.Character.Get() == WatchingCharacter;
	});

	const float Alpha = DeltaSeconds;
	
	if (OldCandidate)
	{
		OldCandidate->WatchPoint = FMath::Lerp(OldCandidate->WatchPoint, Point, Alpha);
		OldCandidate->LastWatchPoint = Point;
	}
	else
	{
		FCandidate NewCandidate;
		NewCandidate.Character = WatchingCharacter;
		NewCandidate.WatchPoint = FMath::Lerp(0.0f, Point, Alpha);
		NewCandidate.LastWatchPoint = Point;
		Candidates.Add(NewCandidate);
	}
}

void FServerMainTarget::TickChangeMainTarget()
{
	float MaxPoint = -1;
	AP3Character* MaxPointCharacter = nullptr;

	for (FCandidate& Candidate : Candidates)
	{
		const float SumPoint = Candidate.WatchPoint; //+ Candidate.AttackPoint
		if (MaxPoint < SumPoint)
		{
			MaxPoint = SumPoint;
			MaxPointCharacter = Candidate.Character.Get();
		}
	}

	MainTarget = MaxPointCharacter;
}

void FServerMainTarget::OnAttack(AP3Character* AttackTarget)
{
	FCandidate* OldCandidate = Candidates.FindByPredicate([AttackTarget](const FCandidate& Candidate) -> bool {
		return Candidate.Character.Get() == AttackTarget;
	});

	const float AttackPoint = 5;

	if (OldCandidate)
	{
		OldCandidate->AttackPoint += AttackPoint;
	}
	else
	{
		FCandidate NewCandidate;
		NewCandidate.Character = AttackTarget;
		NewCandidate.AttackPoint = AttackPoint;
		Candidates.Add(NewCandidate);
	}
}
