// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Input.h"

#include "Engine/World.h"
#include "P3World.h"

namespace P3Input
{
	EP3InputDirection _AxisInputToDirection(bool bIsVertical, float Value)
	{
		if (!FMath::IsNearlyZero(Value))
		{
			if (bIsVertical)
			{
				return (Value > 0) ? EP3InputDirection::Up : EP3InputDirection::Down;
			}
			else
			{
				return (Value > 0) ? EP3InputDirection::Right : EP3InputDirection::Left;
			}
		}

		return EP3InputDirection::None;
	}
}
