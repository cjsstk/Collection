// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "P3Core.h"
#include "P3Store.h"
#include "P3CharacterStore.h"
#include "P3World.h"
#include "Network/Lib/P3NetCore.h"
#include "P3PlayerController.generated.h"

class UUserWidget;

/**
 * P3 Player Controller
 */
UCLASS()
class P3_API AP3PlayerController : public APlayerController
{
	GENERATED_BODY()
	
public:
	virtual void Tick(float DeltaSeconds);
	virtual bool InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad) override;
	virtual bool InputAxis(FKey Key, float Delta, float DeltaTime, int32 NumSamples, bool bGamepad) override;
	virtual void AddPitchInput(float Val) override;
	virtual void DisplayDebug(class UCanvas* Canvas, const FDebugDisplayInfo& DebugDisplay, float& YL, float& YPos) override;
	virtual void SetPawn(APawn* InPawn) override;
	virtual void SetCinematicMode(bool bInCinematicMode, bool bHidePlayer, bool bAffectsHUD, bool bAffectsMovement, bool bAffectsTurning) override;

	UFUNCTION(BlueprintCallable)
	int32 GetPingTimeMsecBP() const;

	UFUNCTION(BlueprintCallable)
	FDateTime GetPingUpdatedTimeBP() const;

	UFUNCTION(BlueprintCallable)
	float GetServerFrameTimeMsec() const;

	UFUNCTION(BlueprintCallable)
	float GetPlayerStateExactPingBP() const;

	UFUNCTION(BlueprintCallable)
	void SetBlockInputBP(bool bInBlockInput);

	UFUNCTION(BlueprintCallable)
	void SetCursorModeBP(bool bEnableCursor) { SetCursorMode(bEnableCursor); }
	void SetCursorMode(bool bEnableCursor);

	void SetInputModeUIOnly(const UUserWidget& Requester, TSharedPtr<SWidget> WidgetToFocus);
	void CancelInputModeUIOnly(const UUserWidget& Requester);

	UFUNCTION(BlueprintCallable)
	void SetSpectatorModeBP(bool bEnableSpectator) { SetSpectatorMode(bEnableSpectator); }
	void SetSpectatorMode(bool bEnableSpectator);

	UFUNCTION(BlueprintCallable)
	void CheatSpawnWeapon(const FName& AssetName);

	UFUNCTION(BlueprintCallable)
	void CheatGetItemPackage(const FName& AssetName);

	UFUNCTION(BlueprintCallable)
	bool IsCursorModeBP() const { return IsCursorMode(); }
	bool IsCursorMode() const;

	void LookForward(const FRotator& Rotation);
	bool IsInLookingForward() const { return bInLookingForward; }

	UFUNCTION(BlueprintImplementableEvent)
	void CreateCombatText(const AP3Character* HitTarget, const FVector& Location, int32 Damage, const FVector& ImpactDirection, bool bIsCriticalPart, bool bIsArmorPart);

	UFUNCTION(BlueprintImplementableEvent)
	void CreateBlockCombatText(const AP3Character* BlockTarget);

	UFUNCTION(BlueprintImplementableEvent)
	void CreateCounterAttackCombatText(const AP3Character* CounterAttackTarget);

	class UP3DamageMetersWidget* GetDamageMetersWidget() const;

	UFUNCTION(BlueprintCallable)
	class UP3QuestListWidget* GetQuestListWidget() const;

	UFUNCTION(BlueprintCallable)
	class UP3WalkieTalkieWidget* GetWalkieTalkieWidget() const;

	UFUNCTION(BlueprintCallable)
	class UP3BossTimerWidget* GetBossTimerWidget() const;

	UFUNCTION(BlueprintCallable)
	class UImage* GetMinimapImage() const;

	UFUNCTION(BlueprintCallable)
	class UP3BackpackInventoryWidget* GetBackpackInventoryWidget() const;

	UFUNCTION(BlueprintCallable) // for test
	void SetIgnoreGamepadBP(bool bInIgnoreGamepad) { bIgnoreGamepad = bInIgnoreGamepad; }

	UFUNCTION(BlueprintCallable)
	bool IsIgnoreGamepadBP() const { return bIgnoreGamepad; }

	UFUNCTION(BlueprintCallable)
	void SetInvertCameraVerticalBP(bool bInvert) { bInvertCameraVertical = bInvert; }

	UFUNCTION(BlueprintCallable)
	bool IsInvertCameraVerticalBP() const { return bInvertCameraVertical; }

	UFUNCTION(BlueprintCallable)
	void SetInvertCameraZoomDirection(bool InInvert) { bInvertCameraZoomDirection = InInvert; };

	UFUNCTION(BlueprintCallable)
	bool IsInvertCameraZoomDirection() const { return bInvertCameraZoomDirection; };

	UFUNCTION(BlueprintCallable)
	void ReturnHome();

	UFUNCTION(BlueprintCallable)
	class UP3SubtitleWidget* GetSubtitleWidget() const;

	void Server_SetOptions(const FString& Options) { Server_Options = Options; }
	const FString& Server_GetOptions() const { return Server_Options; }

	void AddForbiddenVolume(class AP3ForbiddenVolume* Volume);
	void RemoveForbiddenVolume(class AP3ForbiddenVolume* Volume);
	bool IsInForbiddenVolume() const;

	/** Events from sub systems */
	void OnChangeWeapon(class UP3HolderComponent* HolderComponent, AActor* HoldingActor);
	void OnPickup(AActor* PickupedActor);

	/**
	 * UI
	 */
	void ToastMessageBP(const FText& Message);
	void ShowContributionBoard(bool bShow);

	void AddMenuWidget(class UP3MenuWidget* MenuWidget);
	void RemoveMenuWidget(class UP3MenuWidget* MenuWidget);
	TArray<class UP3MenuWidget*> GetMenuWidgets() const { return MenuWidgets; };

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason);

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveCinematicModeChanged(bool bInCinematicMode);
	
private:
	void TickLookForward();

	class UP3InGameActionWidget* GetInGameActionWidget() const;

	UFUNCTION(Server, Reliable, WithValidation)
	void ServerSetSpectatorMode(bool bEnableSpectator);
	bool ServerSetSpectatorMode_Validate(bool bEnableSpectator);
	void ServerSetSpectatorMode_Implementation(bool bEnableSpectator);

	void OnServerConsoleCommand(const TArray<FString>& Args);
	void OnGMConsoleCommand(const TArray<FString>& Args);
	void OnGotoConsoleCommand(const TArray<FString>& Args);
	void OnProfileTrueSkyCommand(const TArray<FString>& Args);
	void OnShowContributionBoardCommand(const TArray<FString>& Args);

	/** See if we have to connect to other dedicated server */
	void Client_TickSeamlessZoneConnection(float DeltaSeconds);
	void Client_TickSeamlessZoneConnection2(float DeltaSeconds);

	void Client_TickAttachAudioListenerToCharacter();

	/** Look forward states */
	bool bInLookingForward = false;
	float LookForwardStartTimeSeconds = 0.0f;
	FRotator LookForwardBeginRotation = FRotator::ZeroRotator;
	FRotator LookForwardEndRotation = FRotator::ZeroRotator;

	UPROPERTY(Transient)
	TArray<AActor*> SpectatorHistories;

	UPROPERTY(Transient)
	APawn* Autonomouse_SpectatorMyPawn = nullptr;

	UPROPERTY(Transient)
	APawn* Server_SpectatorMyPawn = nullptr;

	bool bIgnoreGamepad = false;
	bool bInvertCameraVertical = false;
	bool bInvertCameraZoomDirection = false;

	/** Set the requester widget who want to change input mode to 'UI Only' */
	UPROPERTY()
	const UUserWidget* InputModeUIOnlyRequester = nullptr;

	TArray<class UP3MenuWidget*> MenuWidgets;

	FString Server_Options;

	/** Console commands */
	TArray<IConsoleCommand*> ConsoleCommands;

	UPROPERTY(Transient)
	TArray<class AP3ForbiddenVolume*> ForbiddenVolumes;

	bool bAttachAudioListenerToCharacter = false;

	/** 찾는 위젯 이름 */
	UPROPERTY(EditDefaultsOnly, Category = "Widget", meta = (AllowPrivateAccess = "true"))
	FName DamageMetersWidgetName = FName("DamageMeters");

	UPROPERTY(EditDefaultsOnly, Category = "Widget", meta = (AllowPrivateAccess = "true"))
	FName QuestListWidgetName = FName("QuestList");

	UPROPERTY(EditDefaultsOnly, Category = "Widget", meta = (AllowPrivateAccess = "true"))
	FName WalkieTalkieWidgetName = FName("WalkieTalkie");

	UPROPERTY(EditDefaultsOnly, Category = "Widget", meta = (AllowPrivateAccess = "true"))
	FName BossTimerWidgetName = FName("BossTimer");

	UPROPERTY(EditDefaultsOnly, Category = "Widget", meta = (AllowPrivateAccess = "true"))
	FName MinimapWidgetName = FName("Minimap");

	UPROPERTY(EditDefaultsOnly, Category = "Widget", meta = (AllowPrivateAccess = "true"))
	FName BackpackInventoryWidgetName = FName("BackpackInventory");
};
