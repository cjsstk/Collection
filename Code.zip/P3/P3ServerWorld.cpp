// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ServerWorld.h"

#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Classes/AIController.h"
#include "GameFramework/GameModeBase.h"
#include "Kismet/GameplayStatics.h"

#include "Action/P3PawnActionComponent.h"
#include "AI/P3AIController.h"
#include "Command/P3CommandComponent.h"
#include "Network/P3UDPENetServer.h"
#include "Network/P3PlayerNet.h"
#include "Network/P3UnrealUDPNet.h"
#include "Network/P3WorldNet.h"
#include "P3Actor.h"
#include "P3AnimalCharacter.h"
#include "P3Character.h"
#include "P3CharacterMovementComponent.h"
#include "P3ClientWorld.h"
#include "P3ConsumableComponent.h"
#include "P3GameInstance.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3PlayerController.h"
#include "P3ServerPlayerController.h"
#include "P3StoreArchive.h"
#include "P3Weapon.h"
#include "P3World.h"
#include "P3WorldNetCore.h"
#include "P3QuestComponent.h"

DECLARE_DWORD_COUNTER_STAT(TEXT("P3ServerWorld Num Players"), STAT_P3ServerWorld_NumPlayers, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ServerWorld Num Actors"), STAT_P3ServerWorld_NumActors, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ServerWorld Num Movement Replicated Actors"), STAT_P3ServerWorld_NumMovementReplicatedActors, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ServerWorld Num Movement Replicated Attached Actors"), STAT_P3ServerWorld_NumMovementReplicatedAttachedActors, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ServerWorld Num Movement Dirty Actors"), STAT_P3ServerWorld_NumMovementDirtyActors, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ServerWorld Num Movement Dirty Characters"), STAT_P3ServerWorld_NumMovementDirtyCharacters, STATGROUP_P3);

extern TAutoConsoleVariable<int32> CVarP3WorldPacketProfile;
extern TAutoConsoleVariable<int32> CVarP3WorldDebugPacket;
extern TAutoConsoleVariable<int32> CVarP3CharacterMovementServerDriven;

TAutoConsoleVariable<int32> CVarP3UseP3ServerPlayerController(
	TEXT("p3.useP3ServerPlayerController"),
	1,
	TEXT("1: spawn player controller on server side. 0: null controller on server"), ECVF_Cheat);

TAutoConsoleVariable<float> CVarP3WorldClientSpawnFailedWaitSeconds(
	TEXT("p3.worldClientSpawnFailedWaitSeconds"),
	0.1f,
	TEXT("If client failed to spawn actor. Server will wait this seconds time before send spawn packet again"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3WorldTimeOfDaySyncPeriodTimeSeconds(
	TEXT("p3.worldTimeOfDaySyncPeriodTimeSeconds"),
	5.0f,
	TEXT("Sync period of time of day in seconds"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3WorldSyncMovementMaxPeriodSeconds(
	TEXT("p3.worldSyncMovementMaxPeriodSeconds"),
	1.0f,
	TEXT("Movement sync can be throttle down until this time"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3WorldRegisterActorEarly(
	TEXT("p3.worldRegisterActorEarly"),
	1,
	TEXT("Testing register actors early instead of next tick to avoid sync error"), ECVF_Default);

extern bool _IsP3ActorClass(const AActor& Actor);

static bool _IsLocalConnection(UP3GameInstance* GameInstance, FP3NetConnInfo NetConnInfo)
{
	if (!GameInstance)
	{
		return false;
	}

	if (FP3NetUtil::IsTCPConnection(NetConnInfo))
	{
		if (!GameInstance->GetPlayerNet())
		{
			return false;
		}

		return GameInstance->GetPlayerNet()->IsLocalConnection(NetConnInfo.TCPConnId);
	}

	if (FP3NetUtil::IsUDPConnection(NetConnInfo))
	{
		if (!GameInstance->GetUDPNetwork())
		{
			return false;
		}
	}

	return false;
}

static bool _MakeSpawnActorParamsFromActor(bool bIsLocalPlayer, AActor& Actor,  FP3NetSpawnActorParams& OutParams)
{
	IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(&Actor);

	OutParams.ClassName = Actor.GetClass()->GetPathName();
	OutParams.Location = Actor.GetActorLocation();
	OutParams.Rotation = Actor.GetActorRotation();
	OutParams.Scale3D = Actor.GetActorScale3D();
	OutParams.CollisionHandlingMethod = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	OutParams.GameTimeSinceCreation = Actor.GetGameTimeSinceCreation();

	OutParams.bLevelPersistence = false;
	if (ActorInterface && ActorInterface->IsLevelPersistence())
	{
		ULevel* Level = Cast<ULevel>(Actor.GetOuter());
		if (ensure(Level))
		{
			OutParams.bLevelPersistence = true;
			OutParams.LevelName = Level->GetOuter()->GetName();
			OutParams.ActorName = Actor.GetName();
		}
	}

	if (bIsLocalPlayer)
	{
		OutParams.StandaloneActorPointer = reinterpret_cast<int64>(&Actor);
	}

	return true;
}

static void _FillNetAttachedLevelActors(TArray<FP3NetAttachedLevelActor>& OutNetActors, AActor& Actor, actorid ActorId)
{
	if (ActorId == INVALID_ACTORID)
	{
		ensure(0);
		return;
	}

	ensure(P3Core::GetP3World(Actor)->GetActorFromActorId(ActorId) == &Actor);

	TArray<AActor*> ChildActors;
	Actor.GetAttachedActors(ChildActors);

	for (AActor* ChildActor : ChildActors)
	{
		if (!ChildActor || ChildActor->IsActorBeingDestroyed() || !ChildActor->GetRootComponent())
		{
			continue;
		}
		
		ULevel* Level = Cast<ULevel>(ChildActor->GetOuter());

		if (!ensure(Level))
		{
			continue;
		}

		// TODO: This is quite slow way to filter out dynamic actor, got to find better way
		if (Level->ActorsForGC.Contains(ChildActor))
		{
			// This is dynamic actor, we don't have care about these...
			continue;
		}

		if (_IsP3ActorClass(*ChildActor))
		{
			// P3 actor will be handled by it's own store sync
			continue;
		}

		FP3NetAttachedLevelActor NetAttach;
		NetAttach.ParentActorId = ActorId;
		NetAttach.ChildActorLevelName = Level->GetOuter()->GetName();
		NetAttach.ChildActorName = ChildActor->GetName();
		NetAttach.ChildRelativeTransform = ChildActor->GetRootComponent()->GetRelativeTransform();
		NetAttach.AttachedComponentName = ChildActor->GetRootComponent()->GetAttachParent()->GetName();
		NetAttach.AttachedSocketName = ChildActor->GetAttachParentSocketName();

		OutNetActors.Add(NetAttach);

	}
}

void UP3ServerWorld::BeginPlay(class UP3World* InP3World)
{
	check(InP3World);

	P3World = InP3World;

	ensure(P3World->Actors.Num() == 0);
	P3World->Server_ActorAdded.AddUniqueDynamic(this, &UP3ServerWorld::OnActorAdded);
	P3World->Server_ActorRemoved.AddUniqueDynamic(this, &UP3ServerWorld::OnActorRemoved);

	AGameModeBase* GameMode = GetWorld()->GetAuthGameMode();
	if (!ensure(GameMode))
	{
		return;
	}

	ZoneName = UGameplayStatics::ParseOption(GameMode->OptionsString, TEXT("Zone"));
	ZoneChannelId = 0;

	FString DedimanDirect;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3DedimanDirect="), DedimanDirect))
	{
		P3JsonLog(Display, "Register to dediman");
		RegisterToDediman(DedimanDirect);
	}
	else
	{
		ZoneChannelId = (uint32)UGameplayStatics::GetIntOption(GameMode->OptionsString, TEXT("Channel"), 0);
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);
	if (ensure(WorldNet))
	{
		WorldNet->Connect();
	}
}

void UP3ServerWorld::Shutdown()
{
	UP3DedimanHelper* DedimanHelper = P3GetDedimanHelper(this);
	if (ensure(DedimanHelper))
	{
		DedimanHelper->OnRegisterDediman.RemoveDynamic(this, &UP3ServerWorld::OnRegisterDediman);

		if (bRegisteredToDedimanDirectly)
		{
			DedimanHelper->UnregisterFromDediman(ZoneChannelId);
		}
	}
}

void UP3ServerWorld::RegisterToDediman(const FString& DedimanDirect)
{
	FString DedimanUrl;
	FString ExternalIP;
	if (!ensure(DedimanDirect.Split("|", &DedimanUrl, &ExternalIP)))
	{
		P3JsonLog(Error, "Invalid format for -P3DedimanDirect", TEXT("Param"), *DedimanDirect);
		return;
	}

	UP3DedimanHelper* DedimanHelper = P3GetDedimanHelper(this);
	if (!ensure(DedimanHelper))
	{
		P3JsonLog(Error, "No dediman helper");
		return;
	}

	int32 GamePort = 0;
	UP3PlayerNet* PlayerNet = P3GetPlayerNet(this);
	if (PlayerNet)
	{
		GamePort = PlayerNet->GetPort();
	}

	int32 GameUDPPort = 0;
	UP3UDPNetwork* UDPNetwork = P3GetUDPNetwork(this);
	if (UDPNetwork)
	{
		GameUDPPort = UDPNetwork->GetPort();
	}

	int32 AdminPort = 0;
	UP3WebServer* WebServer = P3GetWebServer(this);
	if (WebServer)
	{
		AdminPort = WebServer->GetPort();
	}

	DedimanHelper->OnRegisterDediman.AddUniqueDynamic(this, &UP3ServerWorld::OnRegisterDediman);
	DedimanHelper->SetDedimanURL(DedimanUrl);
	DedimanHelper->RegisterToDediman(*ZoneName, *ExternalIP, GamePort, GameUDPPort, AdminPort);
	bWaitForDedimanResponse = true;
}

void UP3ServerWorld::Tick(float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_Tick"), STAT_P3ServerWorld_Tick, STATGROUP_P3);

	if (P3World)
	{
		SET_DWORD_STAT(STAT_P3ServerWorld_NumActors, P3World->Actors.Num());
	}

	if (!bReady)
	{
		const FP3IdGenerator* ItemIdGenerator = P3GetItemIdGenerator(P3World);
		if (!ensure(ItemIdGenerator) || !ItemIdGenerator->IsInitialized())
		{
			return;
		}

		if (bWaitForDedimanResponse)
		{
			return;
		}

		bReady = true;
	}

	TickActors(DeltaSeconds);
	SyncActors();
	SyncTimeOfDay();

	// Tick Client spawn failed timer
	{
		TArray<int64> TimeoutActors;

		for (UP3ServerPlayer* Player : Players)
		{
			FP3PlayerSight& Sight = Player->Sight;

			for (auto&& FailedIter : Sight.SpawnFailedActorIds)
			{
				FailedIter.Value -= DeltaSeconds;

				if (FailedIter.Value < 0)
				{
					TimeoutActors.Add(FailedIter.Key);
				}
			}

			for (int64 ActorId : TimeoutActors)
			{
				Sight.SpawnFailedActorIds.Remove(ActorId);
			}
		}
	}

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0)
	{
		PacketProfileWritingSeconds += DeltaSeconds;

		if (PacketProfileWritingSeconds > 5.0f)
		{
			for (int32 Index = 0; Index < ARRAY_COUNT(PacketProfileHistory.NumPackets); ++Index)
			{
				PacketProfileHistory.NumPackets[Index].ValueSort(TGreater<int32>());
			}
			PacketProfileResult = MoveTemp(PacketProfileHistory);
			PacketProfileResult.DurationSeconds = PacketProfileWritingSeconds;

			PacketProfileWritingSeconds = 0.0f;
		}
	}
}

void UP3ServerWorld::TickActors(float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_TickActors"), STAT_P3ServerWorld_TickActors, STATGROUP_P3);

	++SyncFrame;

	if (SyncFrame == 0)
	{
		++SyncFrame;
	}

	check(P3World);

	//Actors.Empty(P3World->GetActors().Num());

	// Add new actors
	for (int32 ActorId : Pending_AddedActors)
	{
		AActor* Actor = P3World->GetActorFromActorId(ActorId);
		
		if (!ensure(Actor))
		{
			continue;
		}

		AddServerActor(ActorId, *Actor);
	}
	Pending_AddedActors.Empty();

	// Remove old actors
	for (int32 ActorId : Pending_RemovedActors)
	{
		Actors.Remove(ActorId);
		DirtyStoreActors.Remove(ActorId);
	}
	Pending_RemovedActors.Empty();

	ensure(Actors.Num() == P3World->GetActors().Num());

	int32 NumMovementReplicatedActors = 0;
	int32 NumMovementReplicatedAttachedActors = 0;
	int32 NumMovementDirtyActors = 0;
	int32 NumMovementDirtyCharacters = 0;

	SyncDataArray.Empty(SyncDataArray.Num());

	// Update actor movements cache
	for (auto&& Iter : Actors)
	{
		const int32 ActorId = Iter.Key;
		FP3ServerActor& ServerActor = Iter.Value;

		UpdateServerActor(ServerActor);
		AddToSyncData(ServerActor);

		if (ServerActor.Movement.bReplicateMovement)
		{
			++NumMovementReplicatedActors;

			if (ServerActor.Movement.bAttached)
			{
				++NumMovementReplicatedAttachedActors;
			}

			if (ServerActor.Movement.bCacheIsDirty)
			{
				++NumMovementDirtyActors;
			}

			if (ServerActor.Movement.bCachedCharacterMovementDataDirty)
			{
				++NumMovementDirtyCharacters;
			}
		}
	}

	SET_DWORD_STAT(STAT_P3ServerWorld_NumMovementReplicatedActors, NumMovementReplicatedActors);
	SET_DWORD_STAT(STAT_P3ServerWorld_NumMovementReplicatedAttachedActors, NumMovementReplicatedAttachedActors);
	SET_DWORD_STAT(STAT_P3ServerWorld_NumMovementDirtyActors, NumMovementDirtyActors);
	SET_DWORD_STAT(STAT_P3ServerWorld_NumMovementDirtyCharacters, NumMovementDirtyCharacters);
}

FP3NetConnInfo UP3ServerWorld::GetPlayerConnInfoFromActorId(actorid ActorId) const
{
	for (UP3ServerPlayer* Player : Players)
	{
		const FP3PlayerStatus& Status = Player->Status;

		if (Status.OwnActorIds.Contains(ActorId))
		{
			return Player->NetConnInfo;
		}
	}

	return FP3NetConnInfo();
}

FP3NetConnInfo UP3ServerWorld::GetPlayerConnInfoFromCharId(charid CharId) const
{
	for (const UP3ServerPlayer* Player : Players)
	{
		if (Player && Player->CharacterId == CharId)
		{
			return Player->NetConnInfo;
		}
	}

	return FP3NetConnInfo();
}

UP3ServerPlayer* UP3ServerWorld::AddPlayer(const FP3NetConnInfo& NetConnInfo, charid CharacterId, const FString& Name, EP3CharClass CharClass, int32 CharLevel, const FP3Version& Version)
{
	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return nullptr;
	}

	const UP3ServerPlayer* DuplicatedPlayer = FindPlayerByConnInfo(NetConnInfo);

	if (DuplicatedPlayer)
	{
		ensure(0);

		P3JsonWorldLog(Error, "Duplicated server player add requested. Ignoring..",
			TEXT("Old TCPConnId"), DuplicatedPlayer->NetConnInfo.TCPConnId.X,
			TEXT("Old UDPConnId"), DuplicatedPlayer->NetConnInfo.UDPConnId.X,
			TEXT("Old CharacterId"), *FString::Printf(TEXT("%lld"), DuplicatedPlayer->CharacterId),
			TEXT("Old Name"), DuplicatedPlayer->Name,
			TEXT("Old CharClass"), *EnumToStringShort(EP3CharClass, DuplicatedPlayer->CharClass),
			TEXT("Old Level"), DuplicatedPlayer->CharLevel,
			TEXT("Old BuildNumber"), DuplicatedPlayer->Version.BuildNumber,
			TEXT("Old Git"), DuplicatedPlayer->Version.Git,
			TEXT("Old Branch"), DuplicatedPlayer->Version.Branch,
			TEXT("New TCPConnId"), NetConnInfo.TCPConnId.X,
			TEXT("New UDPConnId"), NetConnInfo.UDPConnId.X,
			TEXT("New CharacterId"), *FString::Printf(TEXT("%lld"), CharacterId),
			TEXT("New Name"), Name,
			TEXT("New CharClass"), *EnumToStringShort(EP3CharClass, CharClass),
			TEXT("New CharLevel"), CharLevel,
			TEXT("New BuildNumber"), Version.BuildNumber,
			TEXT("New Branch"), Version.Branch,
			TEXT("New Git"), Version.Git);
		return nullptr;
	}

	if (!P3World)
	{
		return nullptr;
	}

	UP3ServerPlayer* NewPlayer = NewObject<UP3ServerPlayer>(this);
	NewPlayer->NetConnInfo = NetConnInfo;
	NewPlayer->CharacterId = CharacterId;
	NewPlayer->Name = FName(*Name);
	NewPlayer->CharClass = CharClass;
	NewPlayer->CharLevel = CharLevel;
	NewPlayer->Version = Version;

	P3World->Actors.GetKeys(NewPlayer->Sight.Pending_AddedActors);

	Players.Add(NewPlayer);

	if (FP3NetUtil::IsTCPConnection(NewPlayer->NetConnInfo))
	{
		TCPPlayers.Add(NewPlayer->NetConnInfo.TCPConnId, NewPlayer);
	}

	if (FP3NetUtil::IsUDPConnection(NewPlayer->NetConnInfo))
	{
		UDPPlayers.Add(NewPlayer->NetConnInfo.UDPConnId, NewPlayer);
	}

	SET_DWORD_STAT(STAT_P3ServerWorld_NumPlayers, Players.Num());

	P3JsonLog(Display, "Server player added",
		TEXT("TCPConnId"), NetConnInfo.TCPConnId.X,
		TEXT("UDPConnId"), NetConnInfo.UDPConnId.X,
		TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), CharacterId),
		TEXT("Name"), Name,
		TEXT("CharClass"), *EnumToStringShort(EP3CharClass, CharClass),
		TEXT("CharLevel"), CharLevel,
		TEXT("Version"), Version.BuildNumber,
		TEXT("Git"), Version.Git,
		TEXT("Branch"), Version.Branch);

	// Broadcast player list to all players (TODO: change to add packet)
	SyncPlayerList();

	return NewPlayer;
}

void UP3ServerWorld::RemovePlayer(const FP3NetConnInfo& NetConnInfo)
{
	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return;
	}

	int NumRemoved = Players.RemoveAll([&NetConnInfo](const UP3ServerPlayer* Player) -> bool {
		return (NetConnInfo.UDPConnId != INVALID_NETCONNID && NetConnInfo.UDPConnId == Player->NetConnInfo.UDPConnId) ||
			(NetConnInfo.TCPConnId != INVALID_NETCONNID && NetConnInfo.TCPConnId == Player->NetConnInfo.TCPConnId);
	});

	ensure(NumRemoved == 1);

	if (FP3NetUtil::IsTCPConnection(NetConnInfo))
	{
		NumRemoved = TCPPlayers.Remove(NetConnInfo.TCPConnId);
		ensure(NumRemoved == 1);
	}

	if (FP3NetUtil::IsUDPConnection(NetConnInfo))
	{
		NumRemoved = UDPPlayers.Remove(NetConnInfo.UDPConnId);
		ensure(NumRemoved == 1);
	}

	SET_DWORD_STAT(STAT_P3ServerWorld_NumPlayers, Players.Num());

	// Broadcast player list to all players (TODO: change to remove packet)
	SyncPlayerList();
}

void UP3ServerWorld::NetOnPlayerDisconnected(const FP3NetConnInfo& NetConnInfo)
{
	P3JsonWorldLog(Display, "Player Disconnected", TEXT("TCPConnId"), NetConnInfo.TCPConnId.X, TEXT("UDPConnId"), NetConnInfo.UDPConnId.X);

	UP3ServerPlayer* Player = FindPlayerByConnInfo(NetConnInfo);
	if (!Player)
	{
		P3JsonLog(Warning, "Player is disconnected before added to player list",
			TEXT("TCPConnId"), NetConnInfo.TCPConnId.X, TEXT("UDPConnId"), NetConnInfo.UDPConnId.X);
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);

	const FP3PlayerStatus& PlayerStatus = Player->Status;

	if (!_IsLocalConnection(P3World->GetGameInstance(), NetConnInfo))
	{
		// Destroy player own actors

		const TArray<int64> OwnActorIds = PlayerStatus.OwnActorIds;

		for (actorid ActorId : OwnActorIds)
		{
			AActor* Actor = P3World->GetActorFromActorId(ActorId);

			if (Actor)
			{
				TArray<AActor*> ChildActors;

				Actor->GetAttachedActors(ChildActors);

				// Since weapons and consumables are created with player character, we got to destroy those, too
				for (AActor* ChildActor : ChildActors)
				{
					if (Cast<AP3Weapon>(ChildActor) || ChildActor->FindComponentByClass<UP3ConsumableComponent>())
					{
						ChildActor->Destroy(true);
					}
				}

				AP3Character* Character = Cast<AP3Character>(Actor);
				if (Character && ensure(WorldNet))
				{
					const FP3CharacterStore& CharacterStore = Character->GetCharacterStoreBP();

					if (CharacterStore.CharacterId == Player->CharacterId)
					{
						const FRotator Rot = Character->GetActorRotation();
						const FString Map = GetWorld() ? GetWorld()->GetMapName() : TEXT("InvalidMap");

						WorldNet->SendSaveCharacter(Player->CharacterId, Map, ZoneName,
							Character->GetActorLocation(), FVector(Rot.Roll, Rot.Pitch, Rot.Yaw), Character->GetCharLevel(), Character->GetExperiencePoint());
					}
				}

				Actor->Destroy(true);
			}
		}
	}

	RemovePlayer(NetConnInfo);
}

void UP3ServerWorld::SyncActors()
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncActors"), STAT_P3ServerWorld_SyncActors, STATGROUP_P3);

	for (UP3ServerPlayer* Player : Players)
	{
		if (!Player)
		{
			continue;
		}

		if (!Player->bReadyToPlay)
		{
			continue;
		}

		SyncActorsToPlayer(Player);
		//SyncActorTransformToPlayer(Player);
		SendSyncDataToPlayer(Player);

		// TODO: some of stores are already sent from SyncActorsToPlayer above, got to remove those duplications
		for (auto&& Iter : DirtyStoreActors)
		{
			const actorid ActorId = Iter.Key;
			const FDirtyActor& DirtyActor = Iter.Value;

			SyncActorStoreToPlayer(Player, ActorId, &DirtyActor);
		}
	}

	DirtyStoreActors.Empty();
}


void UP3ServerWorld::SyncActorTransformToPlayer(UP3ServerPlayer* Player)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncActorTransformToPlayer"), STAT_P3ServerWorld_SyncActorTransformToPlayer, STATGROUP_P3);

	if (!ensure(Player))
	{
		return;
	}

	const FP3NetConnInfo& NetConnInfo = Player->NetConnInfo;

	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return;
	}

	if (_IsLocalConnection(P3World->GetGameInstance(), NetConnInfo))
	{
		return;
	}
	
	const FP3PlayerStatus& PlayerStatus = Player->Status;
	if (!PlayerStatus.bHasValidPawn)
	{
		// Player is not ready yet
		return;
	}

	const float Now = GetWorld()->GetTimeSeconds();
	const float MaxPeriod = CVarP3WorldSyncMovementMaxPeriodSeconds.GetValueOnGameThread();

	FP3PlayerSight& PlayerSight = Player->Sight;

	const float JitteredMaxPeriod = FMath::RandRange(1.0f, 1.3f) * MaxPeriod * 5.0f;
	const bool bItHasBeenLongSinceLastFlush = (Now - PlayerSight.LastMovementFlushTimeSeconds) > JitteredMaxPeriod;

	if (bItHasBeenLongSinceLastFlush)
	{
		PlayerSight.LastMovementFlushTimeSeconds = Now;
	}

	for (auto&& ActorIter : Actors)
	{
		actorid ActorId = ActorIter.Key;
		FP3ServerActor& ServerActor = ActorIter.Value;
		AActor* Actor = ServerActor.ActorPtr.Get();

		ensure(!Actor || ServerActor.Movement.bReplicateMovement == Actor->bReplicateMovement);

		if (!ServerActor.Movement.bReplicateMovement)
		{
			continue;
		}

		if (ServerActor.Movement.bPossessedBySequence)
		{
			continue;
		}

		if (Actor && Actor->GetRootComponent())
		{
			if (Actor->IsActorBeingDestroyed())
			{
				continue;
			}

			FP3CachedActorTransform& SentActorTransform = PlayerSight.ActorTransforms.FindOrAdd(ActorId);
			const bool bItHasBeenLongSinceLastSent = (Now - SentActorTransform.LastSentTime) > JitteredMaxPeriod;

			if (bItHasBeenLongSinceLastSent)
			{
				SentActorTransform.LastSentTime = Now;
			}

			const AActor* AttachedParentActor = ServerActor.Movement.bAttached ? Actor->GetAttachParentActor() : nullptr;

			if (!AttachedParentActor)
			{
				if (ServerActor.Movement.bPhysicsSimulating
					&& ServerActor.Movement.bPhysicsSleeping)
				{
					// It's on sleep state. No need to hurry
				}
				else
				{
					SyncMovementToPlayer(Actor, ActorId, ServerActor, SentActorTransform, bItHasBeenLongSinceLastFlush, Now, NetConnInfo);
				}
			}
			else
			{
				DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncActorTransformToPlayer_AttachedTransform"), STAT_P3ServerWorld_SyncActorTransformToPlayer_Transform, STATGROUP_P3);

				FP3NetActorTransform NetActorTransform;
				NetActorTransform.ActorId = ActorId;
				NetActorTransform.bAttached = true;
				NetActorTransform.Transform = Actor->GetRootComponent()->GetRelativeTransform();
				NetActorTransform.AttachedComponent = Actor->GetRootComponent()->GetAttachParent();
				NetActorTransform.AttachedSocketName = Actor->GetAttachParentSocketName();

				FP3NetActorTransform& SentNetActorTransform = SentActorTransform.ActorTransform;

				if (bItHasBeenLongSinceLastSent || !SentNetActorTransform.Equals(NetActorTransform))
				{
					SentNetActorTransform = NetActorTransform;

					P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, NetActorTransform, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleSyncActorTransform);
				}
			}

			// Replicate component transform
			if (ServerActor.Movement.Components.Num() > 0)
			{
				DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncActorTransformToPlayer_Components"), STAT_P3ServerWorld_SyncActorTransformToPlayer_Components, STATGROUP_P3);

				for (const FP3ServerActor::FMovement::FComponent& ComponentMovement : ServerActor.Movement.Components)
				{
					USceneComponent* Component = ComponentMovement.Component.Get();
					
					if (!ensure(Component))
					{
						continue;
					}

					ensure(Component->GetIsReplicated());

					FP3NetActorComponentTransform NetTransform;
					NetTransform.ActorId = ActorId;
					NetTransform.ComponentName = Component->GetName();
					NetTransform.AttachParentComponentName = Component->GetAttachParent() ? Component->GetAttachParent()->GetName() : TEXT("");
					NetTransform.Transform = Component->GetRelativeTransform();
					NetTransform.bHiddenInGame = Component->bHiddenInGame;

					FP3NetActorComponentTransform& OldNetTransform = SentActorTransform.ActorComponentTransform.FindOrAdd(ComponentMovement.Component);

					if (bItHasBeenLongSinceLastSent || !OldNetTransform.Equals(NetTransform))
					{
						P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, NetTransform, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleSyncActorComponentTransform);

						OldNetTransform = NetTransform;
					}
				}
			}
		}
	}
}

void UP3ServerWorld::SendSyncDataToPlayer(UP3ServerPlayer* Player)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SendSyncDataToPlayer"), STAT_P3ServerWorld_SendSyncDataToPlayer, STATGROUP_P3);

	const FP3NetConnInfo& NetConnInfo = Player->NetConnInfo;

	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return;
	}

	if (_IsLocalConnection(P3World->GetGameInstance(), NetConnInfo))
	{
		return;
	}

	const FP3PlayerStatus& PlayerStatus = Player->Status;
	if (!PlayerStatus.bHasValidPawn)
	{
		// Player is not ready yet
		return;
	}

	for (const FSyncData& SyncData : SyncDataArray)
	{
		switch (SyncData.SyncDataType)
		{
		case ESyncDataType::ActorMovement:
			P3World->Server_SendRawDataToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, SyncData.Actor.Get(), SyncData.PacketData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleSyncActorMovement);
			break;

		case ESyncDataType::CharacterMovement:
		{
			FP3NetActorIdAndByteArray NetData;
			NetData.ActorId = SyncData.ActorId;
			NetData.ByteArray = SyncData.PacketData;

			P3World->Server_SendPacketToPlayer(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, SyncData.Actor.Get(), NetData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleCharacterMovement);
		}
			break;

		case ESyncDataType::AnimalMovement:
		{
			FP3NetActorIdAndByteArray NetData;
			NetData.ActorId = SyncData.ActorId;
			NetData.ByteArray = SyncData.PacketData;

			P3World->Server_SendPacketToPlayer(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, SyncData.Actor.Get(), NetData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleAnimalMovement);
		}
			break;

		case ESyncDataType::AttachedTransform:
			P3World->Server_SendRawDataToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, SyncData.Actor.Get(), SyncData.PacketData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleSyncActorTransform);
			break;

		case ESyncDataType::ComponentTansform:
			P3World->Server_SendRawDataToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, SyncData.Actor.Get(), SyncData.PacketData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleSyncActorComponentTransform);
			break;

		default:
			ensureMsgf(0, TEXT("Unhandled sync data type: %d"), (int32)SyncData.SyncDataType);
		}
	}
}

void UP3ServerWorld::SyncTimeOfDay()
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncTOD"), STAT_P3ServerWorld_SyncTOD, STATGROUP_P3);

	const float SyncPeriod = CVarP3WorldTimeOfDaySyncPeriodTimeSeconds.GetValueOnGameThread();
	const float Now = GetWorld()->GetTimeSeconds();

	FP3NetTimeOfDay NetTimeOfDay;
	NetTimeOfDay.TimeOfDayInSeconds = P3World->GetTimeOfDay().TimeOfDayInSeconds;
	NetTimeOfDay.GameTimeToTimeOfDayRatio = P3World->GetTimeOfDay().GameTimeToTimeOfDayRatio;

	for (UP3ServerPlayer* Player : Players)
	{
		if (!Player)
		{
			continue;
		}

		if (Player->LastTODSyncedTimeSeconds + SyncPeriod < Now)
		{
			const float Jitter = FMath::RandRange(0.0f, SyncPeriod * 0.1f);

			Player->LastTODSyncedTimeSeconds = Now + Jitter;

			P3World->Server_SendPacketToPlayer(Player->NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetTimeOfDay, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleSyncTimeOfDay);
		}
	}
}

void UP3ServerWorld::SyncPlayerList()
{
	if (!P3World)
	{
		return;
	}

	FP3NetClientPlayers NetClientPlayers;

	for (const UP3ServerPlayer* Player : Players)
	{
		NetClientPlayers.Players.Add(FP3ClientPlayer({ Player->Name, Player->CharClass, Player->CharLevel, Player->Version }));
	}

	P3World->Server_MulticastPacketReliable((UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetClientPlayers, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandlePlayerList);
}

void UP3ServerWorld::OnCharacterLevelChanged(const class AP3Character& Character)
{
	const FP3NetConnInfo NetConnInfo = GetPlayerConnInfoFromActor(Character);
	UP3ServerPlayer* Player = FindPlayerByConnInfo(NetConnInfo);
	if (ensure(Player))
	{
		Player->CharLevel = Character.GetCharLevel();

		// Let every players know about this..
		// TODO: do this better way
		SyncPlayerList();
	}
}

const UP3ServerPlayer* UP3ServerWorld::FindPlayerByName(const FName& Name) const
{
	for (const UP3ServerPlayer* Player : Players)
	{
		if (Player && Player->Name == Name)
		{
			return Player;
		}
	}

	return nullptr;
}

void UP3ServerWorld::SyncMovementToPlayer(AActor* Actor, actorid ActorId, const FP3ServerActor& ServerActor, FP3CachedActorTransform &SentActorTransform, const bool bItHasBeenLongSinceLastSent, const float Now, const FP3NetConnInfo& NetConnInfo)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncMovementToPlayer"), STAT_P3ServerWorld_SyncMovementToPlayer, STATGROUP_P3);

	ensure(ServerActor.Movement.ReplicatedMovementCachedFrame == SyncFrame);
	ensure(ServerActor.Movement.CachedNetMovement.ActorId == ActorId);

	if ((bItHasBeenLongSinceLastSent || ServerActor.Movement.bCacheIsDirty)
		&& ensure(ServerActor.Movement.CachedNetMovementData.Num() > 0))
	{
		DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncMovementToPlayer_Send"), STAT_P3ServerWorld_SyncMovementToPlayer_Send, STATGROUP_P3);

		P3World->Server_SendRawDataToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, ServerActor.Movement.CachedNetMovementData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleSyncActorMovement);
	}

	AP3Character* Character = Cast<AP3Character>(Actor);
	if (Character)
	{
		DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncMovementToPlayer_Character"), STAT_P3ServerWorld_SyncMovementToPlayer_Character, STATGROUP_P3);

		//FP3StoreBitWriter BitWriter(P3World, 256, true);
		//Character->NetSerializeMovement(BitWriter);
		//ensure(!BitWriter.IsError());

		//TArray<uint8>& SentCharacterMovement = SentActorTransform.CharacterMovement;

		if ((bItHasBeenLongSinceLastSent || ServerActor.Movement.bCachedCharacterMovementDataDirty)
			&& ensure(ServerActor.Movement.CachedCharacterMovementData.Num() > 0))
		{
			DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncMovementToPlayer_Character_Send"), STAT_P3ServerWorld_SyncMovementToPlayer_Character_Send, STATGROUP_P3);

			FP3NetActorIdAndByteArray NetData;
			NetData.ActorId = ActorId;
			NetData.ByteArray = ServerActor.Movement.CachedCharacterMovementData;

			P3World->Server_SendPacketToPlayer(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, NetData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleCharacterMovement);
		}
	}

	AP3AnimalCharacter* Animal = Cast<AP3AnimalCharacter>(Actor);
	if (Animal)
	{
		DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncMovementToPlayer_Animal"), STAT_P3ServerWorld_SyncMovementToPlayer_Animal, STATGROUP_P3);

		FP3StoreBitWriter BitWriter(P3World, 256, true);
		Animal->NetSerializeMovement(BitWriter);
		ensure(!BitWriter.IsError());

		FP3NetActorIdAndByteArray NetData;
		NetData.ActorId = ActorId;
		NetData.ByteArray = *BitWriter.GetBuffer();

		P3World->Server_SendPacketToPlayer(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, NetData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleAnimalMovement);
	}
}

bool UP3ServerWorld::IsSequencePossessedObject(const UObject& Object) const
{
	if (P3World)
	{
		return P3World->IsSequencePossessedObject(Object);
	}

	return false;
}

void UP3ServerWorld::OnActorAdded(int64 ActorId, AActor* Actor)
{
	for (UP3ServerPlayer* Player : Players)
	{
		ensure(!Player->Sight.Pending_AddedActors.Contains(ActorId));
		ensure(!Player->Sight.Pending_RemovedActors.Contains(ActorId));

		Player->Sight.Pending_AddedActors.Add(ActorId);
	}

	ensure(!Pending_AddedActors.Contains(ActorId));
	ensure(!Pending_RemovedActors.Contains(ActorId));

	Pending_AddedActors.Add(ActorId);

	AP3Character* Character = Cast<AP3Character>(Actor);
	if (Character)
	{
		CharacterActors.AddUnique(Character);
	}

	if (CVarP3WorldRegisterActorEarly.GetValueOnGameThread() != 0)
	{
		// Register to server actor
		FP3ServerActor& ServerActor = AddServerActor(ActorId, *Actor);

		UpdateServerActor(ServerActor);

		Pending_AddedActors.Remove(ActorId);

		for (UP3ServerPlayer* Player : Players)
		{
			if (!Player)
			{
				continue;
			}

			SyncActorsToPlayer(Player);

			//if (bSyncTransform)
			//{
			//	SyncActorTransformToPlayer(Player->NetConnInfo);
			//}

			//// TODO: some of stores are already sent from Server_SyncActorsToPlayer above, got to remove those duplications
			//for (auto&& Iter : DirtyStoreActors)
			//{
			//	const actorid ActorId = Iter.Key;
			//	const TSet<FName>& ComponentNames = Iter.Value;
			//	SyncActorStoreToPlayer(NetConnInfo, ActorId, &ComponentNames);
			//}
		}

		// Since this is too early, some parameters are not set yet
		// Adding to dirty list make sure it will be synced as soon as possible
		FDirtyActor& DirtyActor = DirtyStoreActors.FindOrAdd(ActorId);
		DirtyActor.bActorAndAllComponentsDirty = true;
	}
}

void UP3ServerWorld::OnActorRemoved(int64 ActorId, AActor* Actor)
{
	for (UP3ServerPlayer* Player : Players)
	{
		ensure(!Player->Sight.Pending_RemovedActors.Contains(ActorId));

		Player->Sight.Pending_AddedActors.RemoveSingle(ActorId);
		Player->Sight.Pending_RemovedActors.Add(ActorId);
	}

	ensure(!Pending_RemovedActors.Contains(ActorId));

	Pending_AddedActors.RemoveSingle(ActorId);
	Pending_RemovedActors.Add(ActorId);

	AP3Character* Character = Cast<AP3Character>(Actor);
	if (Character)
	{
		CharacterActors.Remove(Character);
	}
}

void UP3ServerWorld::AddDirtyActor(actorid ActorId)
{
	if (ActorId == INVALID_ACTORID)
	{
		ensure(0);
		return;
	}

	FDirtyActor& DirtyActor = DirtyStoreActors.FindOrAdd(ActorId);

	DirtyActor.bActorDirty = true;
}

void UP3ServerWorld::AddDirtyComponent(actorid ActorId, const FName& ComponentName)
{
	if (ensure(ActorId != INVALID_ACTORID))
	{
		FDirtyActor& DirtyActor = DirtyStoreActors.FindOrAdd(ActorId);
		DirtyActor.ComponentNames.Add(ComponentName);
	}
}

bool UP3ServerWorld::IsPlayerControlledActor(actorid ActorId) const
{
	for (UP3ServerPlayer* Player : Players)
	{
		const FP3PlayerStatus& PlayerStatus = Player->Status;

		if (PlayerStatus.OwnActorIds.Contains(ActorId))
		{
			return true;
		}
	}

	return false;
}

FP3NetConnInfo UP3ServerWorld::GetPlayerConnInfoFromActor(const AActor& Actor) const
{
	const actorid ActorId = P3World->GetActorIdFromActor(&Actor);

	if (ActorId == INVALID_ACTORID)
	{
		return FP3NetConnInfo();
	}

	for (UP3ServerPlayer* Player : Players)
	{
		const FP3PlayerStatus& Status = Player->Status;
		if (Status.OwnActorIds.Contains(ActorId))
		{
			return Player->NetConnInfo;
		}
	}

	return FP3NetConnInfo();
}

TArray<FP3NetConnInfo> UP3ServerWorld::GetPlayerConnInfos() const
{
	TArray<FP3NetConnInfo> ConnInfos;

	for (const UP3ServerPlayer* Player : Players)
	{
		if (Player)
		{
			ConnInfos.Add(Player->NetConnInfo);
		}
	}

	return ConnInfos;
}

TArray<int64> UP3ServerWorld::GetPlayerOwnActorIds(const FP3NetConnInfo& NetConnInfo) const
{
	const UP3ServerPlayer* Player = FindPlayerByConnInfo(NetConnInfo);

	if (!Player)
	{
		return TArray<int64>();
	}

	return Player->Status.OwnActorIds;
}

void UP3ServerWorld::SendToastMessage(const AActor& Actor, const FText& Message)
{
	if (P3World)
	{
		actorid ActorId = P3World->GetActorIdFromActor(&Actor);

		const FP3NetConnInfo NetConnInfo = GetPlayerConnInfoFromActorId(ActorId);

		FP3NetToastMessage NetToastMessage;
		NetToastMessage.Message = Message;

		P3World->Server_SendPacketToPlayer(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetToastMessage, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleToastMessage);
	}
}

void UP3ServerWorld::SendToastMessageToAll(const FText& Message)
{
	for (const UP3ServerPlayer* Player : Players)
	{
		if (!Player)
		{
			continue;
		}

		FP3NetToastMessage NetToastMessage;
		NetToastMessage.Message = Message;

		P3World->Server_SendPacketToPlayer(Player->NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetToastMessage, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleToastMessage);
	}
}

void UP3ServerWorld::SetTimeOfDayInSeconds(float Seconds)
{
	if (P3World)
	{
		P3World->TimeOfDay.TimeOfDayInSeconds = Seconds;
	}
}

void UP3ServerWorld::SetGameTimeToTimeOfDayRatio(float Ratio)
{
	if (P3World)
	{
		P3World->TimeOfDay.GameTimeToTimeOfDayRatio = Ratio;
	}
}

void UP3ServerWorld::SendDebugDrawSphere(const FVector& Location, float Radius, const FColor& Color, float LifeTime /*= -1.0f*/)
{
	if (!P3World)
	{
		return;
	}

	FP3NetDebugDraw NetDebugDraw;
	NetDebugDraw.DebugDrawType = EP3NetDebugDrawType::Sphere;
	NetDebugDraw.Location = Location;
	NetDebugDraw.Color = Color;
	NetDebugDraw.LifeTime = LifeTime;
	NetDebugDraw.SphereRadius = Radius;

	for (UP3ServerPlayer* Player : Players)
	{
		if (!Player)
		{
			continue;
		}

		P3World->Server_SendPacketToPlayer(Player->NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetDebugDraw, EP3NetComponentType::ClientWorld, &UP3ClientWorld::Client_HandleDebugDraw);
	}
}

void UP3ServerWorld::DisconnectClient(const FP3NetConnInfo& NetConnInfo)
{
	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return;
	}

	if (FP3NetUtil::IsTCPConnection(NetConnInfo))
	{
		UP3PlayerNet* PlayerNet = P3GetPlayerNet(this);
		if (PlayerNet)
		{
			PlayerNet->Close(NetConnInfo.TCPConnId);
		}
	}

	if (FP3NetUtil::IsUDPConnection(NetConnInfo))
	{
		if (P3World && P3World->GetGameInstance())
		{
			UP3UDPNetwork* UDPNetwork = P3World->GetGameInstance()->GetUDPNetwork();

			if (UDPNetwork)
			{
				UDPNetwork->Close(NetConnInfo.UDPConnId);
			}
		}
	}
}

static void _CloseConnWithEnterWorldFailResponse(UP3ServerWorld& P3ServerWorld, const FP3NetConnInfo& NetConnInfo, const TCHAR* Message)
{
	P3JsonWorldLog(Display, "Handle Enter Fail",
		TEXT("TCPConnId"), NetConnInfo.TCPConnId.X,
		TEXT("UDPConnId"), NetConnInfo.UDPConnId.X,
		TEXT("Message"), Message);

	UP3World* P3World = P3ServerWorld.GetP3World();
	if (ensure(P3World))
	{
		FP3NetPlayerEnterWorldFailResponse NetResponse;
		NetResponse.ServerVersion = P3World->GetGameInstance() ? P3World->GetGameInstance()->GetVersion() : FP3Version();
		NetResponse.DebugMessage = Message;
		P3World->Server_SendPacketToPlayerForceReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetResponse, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleEnterFailResponse);
	}

	P3ServerWorld.DisconnectClient(NetConnInfo);
}

void UP3ServerWorld::HandleEnter(const FP3ClientToDediHandlerParams& Params)
{
	P3JsonWorldLog(Display, "Handle Enter", TEXT("TCPConnId"), Params.NetConnInfo.TCPConnId.X, TEXT("UDPConnId"), Params.NetConnInfo.UDPConnId.X);

	if (!bReady)
	{
		_CloseConnWithEnterWorldFailResponse(*this, Params.NetConnInfo, TEXT("Server is not ready"));
		return;
	}

	FP3NetPlayerEnterWorld NetEnter;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetEnter);

	if (!ensure(bSerializeSucceeded))
	{
		_CloseConnWithEnterWorldFailResponse(*this, Params.NetConnInfo, TEXT("Failed to deserialize enter packet"));
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);

	if (!ensure(WorldNet))
	{
		_CloseConnWithEnterWorldFailResponse(*this, Params.NetConnInfo, TEXT("No world net"));
		return;
	}

	if (WorldNet->GetConnStatus() != EP3NetConnStatus::Connected)
	{
		_CloseConnWithEnterWorldFailResponse(*this, Params.NetConnInfo, TEXT("World not connected"));
		return;
	}

	// TODO: Use JWT or something...
	int64 AccountId = FCString::Atoi64(*NetEnter.Token);
	if (AccountId == 0)
	{
		_CloseConnWithEnterWorldFailResponse(*this, Params.NetConnInfo, TEXT("Invalid account id"));
		return;
	}

	// Save player context (TODO: Save NetEnter instead)
	EnteringPlayers.Add(AccountId, Params);

	WorldNet->SendLoadCharacter(AccountId, NetEnter.CharacterId, ZoneName, ZoneChannelId);
}

void UP3ServerWorld::HandleEnterInternal(const FP3NetConnInfo& NetConnInfo, const pb::WD2DDLoadCharacterRes& Message, const FP3NetPlayerEnterWorld& NetEnter)
{
	P3JsonWorldLog(Display, "Handle Enter Internal", TEXT("TCPConnId"), NetConnInfo.TCPConnId.X, TEXT("UDPConnId"), NetConnInfo.UDPConnId.X);

	const charid CharacterId = Message.char_id();
	const FString& Name = UTF8_TO_TCHAR(Message.char_name().c_str());
	const EP3CharClass CharClass = (EP3CharClass)Message.char_class();
	const int32 CharLevel = Message.char_level();
	const int32 ExperiencePoint = Message.experience_point();

	UP3ServerPlayer* Player = AddPlayer(NetConnInfo, CharacterId, Name, CharClass, CharLevel, NetEnter.Version);
	if (!ensure(Player))
	{
		DisconnectClient(NetConnInfo);
		return;
	}

	const bool bIsLocalConnection = _IsLocalConnection(P3World->GetGameInstance(), NetConnInfo);

	FP3NetPlayerEnterWorldResponse NetResponse;
	NetResponse.ServerVersion = P3World->GetGameInstance() ? P3World->GetGameInstance()->GetVersion() : FP3Version();
	NetResponse.ZoneChannelId = ZoneChannelId;
	NetResponse.TimeOfDayInSeconds = P3World->GetTimeOfDay().TimeOfDayInSeconds;
	NetResponse.GameTimeToTimeOfDayRatio = P3World->GetTimeOfDay().GameTimeToTimeOfDayRatio;

	AP3ServerPlayerController* PlayerController = nullptr;

	if (CVarP3UseP3ServerPlayerController.GetValueOnGameThread() != 0)
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		PlayerController = GetWorld()->SpawnActor<AP3ServerPlayerController>(SpawnParams);
		Player->PlayerController = PlayerController;
	}

	for (const FP3NetPlayerOwnActor& OwnActor : NetEnter.OwnActors)
	{
		if (bIsLocalConnection)
		{
			ensure(P3Core::IsP3NetModeClientInstance(*this));

			// Ok, this is just me. lets make things smooth..
			NetResponse.RemapOwnActors.Add(OwnActor.ActorId, OwnActor.ActorId);
		}
		else
		{
			UClass* ActorClass = StaticLoadClass(AActor::StaticClass(), NULL, *OwnActor.ClassName);

			if (!ensure(ActorClass))
			{
				P3JsonWorldLog(Error, "Failed to spawn player own actor. Can't find class",
					TEXT("ActorId"), OwnActor.ActorId, TEXT("Class"), OwnActor.ClassName);
				continue;
			}

			const FTransform Transform = OwnActor.Transform.ToTransform();

			AActor* Actor = GetWorld()->SpawnActorDeferred<AActor>(ActorClass, Transform, nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AlwaysSpawn);

			if (!ensure(Actor))
			{
				P3JsonWorldLog(Error, "Failed to spawn player own actor",
					TEXT("ActorId"), OwnActor.ActorId, TEXT("Class"), OwnActor.ClassName);
				continue;
			}

			AP3Character* Character = Cast<AP3Character>(Actor);
			if (Character)
			{
				FName HairName = Message.hair().c_str();
				FName ArmorName = Message.armor().c_str();

				if (HairName == "None")
				{
					// Select random hair for now
					const UDataTable* HairTable = P3Cms::GetCharacterHairTable();

					if (HairTable)
					{
						const TArray<FName> HairNames = HairTable->GetRowNames();
						if (HairNames.Num() > 0)
						{
							HairName = HairNames[FMath::Rand() % HairNames.Num()];
						}
					}
				}

				if (ArmorName == "None")
				{
					// Select random armor for now
					const UDataTable* ArmorTable = P3Cms::GetCharacterArmorTable();

					if (ArmorTable)
					{
						const TArray<FName> ArmorNames = ArmorTable->GetRowNames();
						if (ArmorNames.Num() > 0)
						{
							ArmorName = ArmorNames[FMath::Rand() % ArmorNames.Num()];
						}
					}
				}

				const FText DisplayName = FText::AsCultureInvariant(Name);
				FP3CharacterInitParams Params = {
					CharacterId,
					DisplayName,
					CharClass,
					HairName,
					ArmorName,
					CharLevel,
					ExperiencePoint
				};

				for (const pb::CharacterItem& Item : Message.items())
				{
					FP3CharacterItem CharacterItem;
					CharacterItem.Item.Id = FP3ItemId::FromUInt64(Item.id());
					CharacterItem.Item.Key = Item.cms_key();
					CharacterItem.Item.Stack = Item.stack();
					CharacterItem.Slot = (EP3CharacterItemSlot)Item.slot();

					Params.Items.Add(CharacterItem);
				}

				for (const pb::Quest& Quest : Message.quests())
				{
					FP3QuestData& QuestData = Params.Quests.Add(Quest.key());
					QuestData.State = (EP3QuestState)Quest.state();
					QuestData.PhaseIndex = Quest.phase_index();
					QuestData.ActionIndex = Quest.action_index();
				}

				Character->Server_InitBaseInfo(Params);
				Character->Server_InitDefaultItems();

				// Without this, AI Controller will be created and poses this character
				// Which makes things ugly
				Character->AutoPossessAI = EAutoPossessAI::Disabled;

				// Set Remote Role as AutonomousProxy
				Character->SetReplicates(true);
				Character->SetAutonomousProxy(true, false);

				if (CVarP3UseP3ServerPlayerController.GetValueOnGameThread() == 0)
				{
					Character->GetCharacterMovement()->bRunPhysicsWithNoController = true;
				}

				if (CVarP3CharacterMovementServerDriven.GetValueOnGameThread() != 0)
				{
					if (Character->GetMesh())
					{
						// Refer ACharacter::PossessedBy
						// Since we don't have player controller on server side, we need this.
						Character->GetMesh()->bOnlyAllowAutonomousTickPose = true;
					}
				}
			}

			Actor->FinishSpawning(Transform);

			const actorid ActorId = P3World->GetActorIdFromActor(Actor);

			if (ensure(ActorId != INVALID_ACTORID))
			{
				NetResponse.RemapOwnActors.Add(OwnActor.ActorId, ActorId);
			}

			if (Character)
			{
				// Mimic AController::Possess to trigger SetDefaultMovementMode()
				// Comment-out: bRunPhysicsWithNoController can handle this
				//Character->Restart();

				if (PlayerController && ensure(!PlayerController->GetPawn()))
				{
					PlayerController->Possess(Character);
				}
			}

			if (FP3NetUtil::IsUDPConnection(NetConnInfo))
			{
				if (P3World->GetGameInstance())
				{
					UP3UDPNetwork* UDPNetwork = P3World->GetGameInstance()->GetUDPNetwork();

					if (UDPNetwork)
					{
						UDPNetwork->Server_CreateActorChannel(NetConnInfo.UDPConnId, Actor, nullptr);
					}
				}
			}
		}
	}

	FP3PlayerSight& PlayerSight = Player->Sight;
	for (auto&& Iter : NetResponse.RemapOwnActors)
	{
		AActor* Actor = P3World->GetActorFromActorId(Iter.Value);
		AP3Character* Character = Cast<AP3Character>(Actor);
		if (Character)
		{
			Character->Server_SetPlayerControlled(true);

			if (!bIsLocalConnection)
			{
				if (CVarP3CharacterMovementServerDriven.GetValueOnGameThread() == 0)
				{
					Character->Role = ROLE_SimulatedProxy;
				}
			}
		}
	}

	FP3PlayerStatus& PlayerStatus = Player->Status;
	PlayerStatus.bHasValidPawn = true;
	for (auto&& Iter : NetResponse.RemapOwnActors)
	{
		PlayerStatus.OwnActorIds.Add(Iter.Value);
	}

	P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetResponse, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleEnterResponse);

	SyncActorsToPlayer(Player);

	FP3NetDummy NetDummy;

	P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetDummy, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleActorSyncEnd);
}

void UP3ServerWorld::HandleClientSpawnActorFailed(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetActorId NetActorId;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetActorId);

	if (ensure(bSerializeSucceeded))
	{
		UP3ServerPlayer* Player = UP3ServerWorld::FindPlayerByConnInfo(Params.NetConnInfo);

		if (ensure(Player))
		{
			Player->Sight.ActorIds.Remove(NetActorId.ActorId);
			float& DelaySeconds = Player->Sight.SpawnFailedActorIds.FindOrAdd(NetActorId.ActorId);
			DelaySeconds = CVarP3WorldClientSpawnFailedWaitSeconds.GetValueOnGameThread();
		}
	}
}

void UP3ServerWorld::HandleGMCommand(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetGMCommand Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		UP3ServerPlayer* Player = UP3ServerWorld::FindPlayerByConnInfo(Params.NetConnInfo);

		if (ensure(Player) && ensure(Player->PlayerController))
		{
			Player->PlayerController->HandleGMCommand(Packet.Args);
		}
	}
}

void UP3ServerWorld::HandleAIControlCommand(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetAICommand Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		if (Packet.bSetForceTargetPlayerName)
		{
			const UP3ServerPlayer* Player = Packet.ForceTargetPlayerName.IsNone() ? nullptr : FindPlayerByName(Packet.ForceTargetPlayerName);
			AActor* ForceTargetObject = Player && Player->PlayerController ? Player->PlayerController->GetPawn() : nullptr;

			for (AP3Character* Character : CharacterActors)
			{
				if (Character && Character->IsLarge())
				{
					AP3AIController* AIController = Cast<AP3AIController>(Character->GetController());
					if (AIController)
					{
						AIController->SetForceTarget(ForceTargetObject);
					}
					//if (AIController && AIController->GetBlackboardComponent())
					//{
					//	UBlackboardComponent* Blackboard = AIController->GetBlackboardComponent();
					//	Blackboard->SetValue<UBlackboardKeyType_Object>(FName(TEXT("Command_ForceTarget")), ForceTargetObject);
					//}
				}
			}
		}
		else
		{
			FGameplayTagContainer Container;
			Container.AddTag(Packet.GameplayTag);

			for (AP3Character* Character : CharacterActors)
			{
				if (Character && Character->IsLarge())
				{
					if (Character->HasAnyMatchingGameplayTags(Container))
					{
						Character->RemoveGameplayTags(Container);
					}
					else
					{
						Character->AddGameplayTags(Container);
					}
				}
			}
		}
	}
}

void UP3ServerWorld::HandleRegisterRes(const pb::WD2DDRegisterRes& Message)
{
	check(P3World);

	const uint64 MachineId = Message.machine_id_for_item_id();
	P3JsonLog(Display, "Registered to world server", TEXT("machineIdForItemId"), UINT64_TO_STR(MachineId));

	FP3IdGenerator* ItemIdGenerator = P3GetItemIdGenerator(P3World);
	if (!ensure(ItemIdGenerator))
	{
		P3JsonLog(Error, "Failed to get item id generator");
		return;
	}

	ItemIdGenerator->InitGenerator(MachineId);
}

void UP3ServerWorld::HandleLoadCharacterRes(const pb::WD2DDLoadCharacterRes& Message)
{
	P3JsonWorldLog(Display, "Handle LoadCharacterReply",
		TEXT("AccountId"), UINT64_TO_STR(Message.account_id()),
		TEXT("CharacterId"), UINT64_TO_STR(Message.char_id()),
		TEXT("Name"), FString(UTF8_TO_TCHAR(Message.char_name().c_str())),
		TEXT("CharClass"), (int32)Message.char_class());

	FP3ClientToDediHandlerParams Params;
	const bool bFound = EnteringPlayers.RemoveAndCopyValue(Message.account_id(), Params);
	if (!ensure(bFound))
	{
		P3JsonLog(Error, "Cannot find player context", TEXT("AccountId"), UINT64_TO_STR(Message.account_id()));
		return;
	}

	if (P3World && P3World->GetGameInstance())
	{
		bool bFoundNet = false;

		if (FP3NetUtil::IsTCPConnection(Params.NetConnInfo))
		{
			UP3PlayerNet* PlayerNet = P3World->GetGameInstance()->GetPlayerNet();

			if (PlayerNet && PlayerNet->IsConnected(Params.NetConnInfo.TCPConnId))
			{
				bFoundNet = true;
			}
		}

		if (FP3NetUtil::IsUDPConnection(Params.NetConnInfo))
		{
			UP3UDPNetwork* UDPNetwork = P3World->GetGameInstance()->GetUDPNetwork();

			if (UDPNetwork && UDPNetwork->Server_IsConnected(Params.NetConnInfo.UDPConnId))
			{
				bFoundNet = true;
			}
		}

		if (!bFoundNet)
		{
			if (FP3NetUtil::IsTCPConnection(Params.NetConnInfo))
			{
				P3JsonLog(Error, "No matching player connection",
					TEXT("AccountId"), UINT64_TO_STR(Message.account_id()),
					TEXT("NetConnId"), Params.NetConnInfo.TCPConnId.X);
			}

			if (FP3NetUtil::IsUDPConnection(Params.NetConnInfo))
			{
				P3JsonLog(Error, "No matching udp connection",
					TEXT("AccountId"), UINT64_TO_STR(Message.account_id()),
					TEXT("UDPConnId"), Params.NetConnInfo.UDPConnId.X);
			}

			return;
		}
	}

	if (Message.err() != pb::WD2DDErrorNone)
	{
		DisconnectClient(Params.NetConnInfo);
		return;
	}

	FP3NetPlayerEnterWorld NetEnter;
	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetEnter);
	if (!ensure(bSerializeSucceeded))
	{
		P3JsonLog(Warning, "Failed to decode packet",
			TEXT("AccountId"), UINT64_TO_STR(Message.account_id()),
			TEXT("CharacterId"), UINT64_TO_STR(Message.char_id()));

		DisconnectClient(Params.NetConnInfo);
		return;
	}

	// TODO: Make another packet for loading failure
	if (Message.char_class() == 0)
	{
		P3JsonLog(Warning, "Failed to load character",
			TEXT("AccountId"), UINT64_TO_STR(Message.account_id()),
			TEXT("CharacterId"), UINT64_TO_STR(Message.char_id()));

		DisconnectClient(Params.NetConnInfo);
		return;
	}

	HandleEnterInternal(Params.NetConnInfo, Message, NetEnter);
}

void UP3ServerWorld::HandleSyncActorTransform(const FP3ClientToDediHandlerParams& Params)
{
	if (_IsLocalConnection(P3World->GetGameInstance(), Params.NetConnInfo))
	{
		// If this is listen server and coming from local player, don't bother for now..
		return;
	}

	FP3NetActorTransform NetTransform;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetTransform);

	if (ensure(bSerializeSucceeded))
	{
		AActor** ActorPtr = P3World->Actors.Find(NetTransform.ActorId);

		if (!ActorPtr || !*ActorPtr)
		{
			ensure(0);
			return;
		}

		AActor* Actor = *ActorPtr;

		if (Actor->GetAttachParentActor())
		{
			// Somehow server's actor is not attached but local actor is attached
			// Maybe this is just some simple miss understanding for a short moment, like we just picked up that actor
			// So, lets just move on... like nothing happen...
		}
		else
		{
			Actor->SetActorRelativeTransform(NetTransform.Transform.ToTransform());
		}
	}
}

static void _ApplyNetMovement(const FP3NetMovement& NetMovement, AActor* Actor)
{
	if (!ensure(Actor))
	{
		return;
	}

	if (Actor->GetAttachParentActor())
	{
		// TODO: not supported yet!
	}
	else
	{
		// Note OnRep_ReplicatedMovement crash at UCharacterMovementComponent::SmoothCorrection in debug build server instance
		//if (ensure(Actor->Role == ROLE_SimulatedProxy) && !P3Core::IsP3NetModeServerInstance(*Actor))
		// FIXME: turned off. ROLE_Standalone also crashed in debug build. got to fix them..
		if (1)
		{
			Actor->ReplicatedMovement.LinearVelocity = NetMovement.LinearVelocity;
			Actor->ReplicatedMovement.AngularVelocity = NetMovement.AngularVelocity;
			Actor->ReplicatedMovement.Location = NetMovement.Location;
			Actor->ReplicatedMovement.Rotation = NetMovement.Rotation;
			Actor->ReplicatedMovement.bSimulatedPhysicSleep = NetMovement.bSimulatedPhysicSleep;
			Actor->ReplicatedMovement.bRepPhysics = NetMovement.bRepPhysics;

			Actor->OnRep_ReplicatedMovement();
		}
		else
		{
			Actor->ReplicatedMovement.LinearVelocity = NetMovement.LinearVelocity;
			Actor->ReplicatedMovement.AngularVelocity = NetMovement.AngularVelocity;
			Actor->ReplicatedMovement.Location = NetMovement.Location;
			Actor->ReplicatedMovement.Rotation = NetMovement.Rotation;

			Actor->SetActorLocationAndRotation(NetMovement.Location, NetMovement.Rotation, false);
			Actor->PostNetReceiveVelocity(NetMovement.LinearVelocity);
		}
	}
}

void UP3ServerWorld::HandleSyncActorMovement(const FP3ClientToDediHandlerParams& Params)
{
	if (_IsLocalConnection(P3World->GameInstance, Params.NetConnInfo))
	{
		// If this is listen server and coming from local player, don't bother for now..
		return;
	}

	FP3NetMovement NetMovement;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetMovement);

	if (ensure(bSerializeSucceeded))
	{
		AActor** ActorPtr = P3World->Actors.Find(NetMovement.ActorId);

		if (!ActorPtr || !*ActorPtr)
		{
			ensure(0);
			return;
		}

		_ApplyNetMovement(NetMovement, *ActorPtr);
	}
}

void UP3ServerWorld::HandleCharacterMovement(const FP3ClientToDediHandlerParams& Params)
{
	if (_IsLocalConnection(P3World->GameInstance, Params.NetConnInfo))
	{
		// If this is listen server and coming from local player, don't bother for now..
		return;
	}

	FP3NetActorIdAndByteArray NetData;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetData);

	if (ensure(bSerializeSucceeded))
	{
		AActor** ActorPtr = P3World->Actors.Find(NetData.ActorId);

		if (!ActorPtr || !*ActorPtr)
		{
			ensure(0);
			return;
		}

		AP3Character* Character = Cast<AP3Character>(*ActorPtr);
		if (!ensure(Character))
		{
			return;
		}

		// TODO: BitReader expect non const buffer strangely.... got to fix that...
		TArray<uint8> TmpBuffer = NetData.ByteArray;

		FP3StoreBitReader BitReader(P3World, TmpBuffer.GetData(), TmpBuffer.Num() * sizeof(uint8) * 8);
		Character->NetSerializeMovement(BitReader);
		ensure(!BitReader.IsError());
	}
}

void UP3ServerWorld::OnRegisterDediman(uint32 InZoneChannelId, bool bWasSuccessful)
{
	if (ensure(bWasSuccessful && InZoneChannelId > 0))
	{
		ZoneChannelId = InZoneChannelId;
		bRegisteredToDedimanDirectly = true;
		bWaitForDedimanResponse = false;

		P3JsonLog(Display, "Registered to dediman successfully", TEXT("ChannelId"), (int32)ZoneChannelId);
	}
	else
	{
		P3JsonLog(Error, "Failed to register to dediman", TEXT("ChannelId"), (int32)ZoneChannelId);
	}
}

UP3ServerPlayer* UP3ServerWorld::FindPlayerByConnInfo(const FP3NetConnInfo& NetConnInfo, bool bFromArray/* = false*/)
{
	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return nullptr;
	}

	UP3ServerPlayer* const* Player = nullptr;

	if (bFromArray)
	{
		Player = Players.FindByPredicate([&NetConnInfo](const UP3ServerPlayer* Player) -> bool {
			return (NetConnInfo.UDPConnId != INVALID_NETCONNID && NetConnInfo.UDPConnId == Player->NetConnInfo.UDPConnId) ||
				(NetConnInfo.TCPConnId != INVALID_NETCONNID && NetConnInfo.TCPConnId == Player->NetConnInfo.TCPConnId);
		});
	}
	else
	{
		if (FP3NetUtil::IsTCPConnection(NetConnInfo))
		{
			Player = TCPPlayers.Find(NetConnInfo.TCPConnId);
		}

		if (FP3NetUtil::IsUDPConnection(NetConnInfo))
		{
			Player = UDPPlayers.Find(NetConnInfo.UDPConnId);
		}
	}

	return Player ? *Player : nullptr;
}

const UP3ServerPlayer* UP3ServerWorld::FindPlayerByConnInfo(const FP3NetConnInfo& NetConnInfo, bool bFromArray/* = false*/) const
{
	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return nullptr;
	}

	const UP3ServerPlayer* const* Player = nullptr;

	if (bFromArray)
	{
		Player = Players.FindByPredicate([&NetConnInfo](const UP3ServerPlayer* Player) -> bool {
			return (NetConnInfo.UDPConnId != INVALID_NETCONNID && NetConnInfo.UDPConnId == Player->NetConnInfo.UDPConnId) ||
				(NetConnInfo.TCPConnId != INVALID_NETCONNID && NetConnInfo.TCPConnId == Player->NetConnInfo.TCPConnId);
		});
	}
	else
	{
		if (FP3NetUtil::IsTCPConnection(NetConnInfo))
		{
			Player = TCPPlayers.Find(NetConnInfo.TCPConnId);
		}

		if (FP3NetUtil::IsUDPConnection(NetConnInfo))
		{
			Player = UDPPlayers.Find(NetConnInfo.UDPConnId);
		}
	}

	return Player ? *Player : nullptr;
}

FP3ServerActor& UP3ServerWorld::AddServerActor(int32 ActorId, AActor& Actor)
{
	check(P3World);

	FP3ServerActor& ServerActor = Actors.Add(ActorId);

	ServerActor.ActorId = ActorId;
	ServerActor.ActorPtr = &Actor;

	return ServerActor;
}

void UP3ServerWorld::UpdateServerActor(FP3ServerActor& ServerActor)
{
	AActor* Actor = ServerActor.ActorPtr.Get();

	if (!Actor || Actor->IsActorBeingDestroyed())
	{
		return;
	}

	// Cache movement
	ServerActor.Movement.bReplicateMovement = Actor->bReplicateMovement;

	if (ServerActor.Movement.bReplicateMovement)
	{
		const AActor* AttachedParentActor = Actor->GetAttachParentActor();
		if (AttachedParentActor)
		{
			ServerActor.Movement.bAttached = true;
		}
		else
		{
			ServerActor.Movement.bAttached = false;
		}

		UPrimitiveComponent* RootPrimComp = Cast<UPrimitiveComponent>(Actor->GetRootComponent());
		if (RootPrimComp && RootPrimComp->IsSimulatingPhysics())
		{
			ServerActor.Movement.bPhysicsSimulating = true;
			ServerActor.Movement.bPhysicsSleeping = !RootPrimComp->GetBodyInstance()->IsInstanceAwake();
		}
		else
		{
			ServerActor.Movement.bPhysicsSimulating = false;
		}
			
		ServerActor.Movement.bPossessedBySequence = IsSequencePossessedObject(*Actor);


		// Cache replicated components
		TArray<USceneComponent*> ReplicatedComponets;

		const TSet<UActorComponent*>& Components = Actor->GetComponents();
		for (auto&& Iter : Components)
		{
			if (Iter == Actor->GetRootComponent())
			{
				continue;
			}

			USceneComponent* Component = Cast<USceneComponent>(Iter);

			if (Component && Component->GetIsReplicated())
			{
				// Note child actor component doesn't need to be replicated in P3
				if (Cast<UChildActorComponent>(Component) == nullptr)
				{
					ReplicatedComponets.Add(Component);
				}
			}
		}

		// Remove no long replicated components
		for (int32 Index = 0; Index < ServerActor.Movement.Components.Num(); ++Index)
		{
			USceneComponent* Component = ServerActor.Movement.Components[Index].Component.Get();

			if (!Component || !ReplicatedComponets.Contains(Component))
			{
				ServerActor.Movement.Components.RemoveAtSwap(Index);
				--Index;
			}
			else
			{
				ReplicatedComponets.RemoveSingleSwap(Component);
			}
		}

		// Add new replicated components
		for (USceneComponent* Component : ReplicatedComponets)
		{
			FP3ServerActor::FMovement::FComponent& ComponentMovement = ServerActor.Movement.Components.AddDefaulted_GetRef();
			ComponentMovement.Component = Component;
		}


		ServerActor.UpdateReplicatedMovement(P3World, SyncFrame);
	}
}

void UP3ServerWorld::AddToSyncData(FP3ServerActor& ServerActor)
{
	const actorid ActorId = ServerActor.ActorId;
	AActor* Actor = ServerActor.ActorPtr.Get();

	ensure(!Actor || ServerActor.Movement.bReplicateMovement == Actor->bReplicateMovement);

	if (!ServerActor.Movement.bReplicateMovement)
	{
		return;
	}

	if (ServerActor.Movement.bPossessedBySequence)
	{
		return;
	}

	const float Now = GetWorld()->GetTimeSeconds();
	const float MaxPeriod = CVarP3WorldSyncMovementMaxPeriodSeconds.GetValueOnGameThread();
	const float JitteredMaxPeriod = FMath::RandRange(1.0f, 1.3f) * MaxPeriod * 5.0f;

	FP3ServerActor::FMovementSync& MovementSync = ServerActor.MovementSync;
	const bool bItHasBeenLongSinceLastSync = (Now - MovementSync.LastSyncTime) > JitteredMaxPeriod;

	if (bItHasBeenLongSinceLastSync)
	{
		MovementSync.LastSyncTime = Now;
	}

	if (Actor && Actor->GetRootComponent())
	{
		if (Actor->IsActorBeingDestroyed())
		{
			return;
		}

		const AActor* AttachedParentActor = ServerActor.Movement.bAttached ? Actor->GetAttachParentActor() : nullptr;

		if (!AttachedParentActor)
		{
			if (ServerActor.Movement.bPhysicsSimulating
				&& ServerActor.Movement.bPhysicsSleeping)
			{
				// It's on sleep state. No need to hurry
			}
			else
			{
				ensure(ServerActor.Movement.ReplicatedMovementCachedFrame == SyncFrame);
				ensure(ServerActor.Movement.CachedNetMovement.ActorId == ActorId);

				if ((bItHasBeenLongSinceLastSync || ServerActor.Movement.bCacheIsDirty)
					&& ensure(ServerActor.Movement.CachedNetMovementData.Num() > 0))
				{
					FSyncData& NewSyncData = SyncDataArray.AddDefaulted_GetRef();

					NewSyncData.SyncDataType = ESyncDataType::ActorMovement;
					NewSyncData.ActorId = ActorId;
					NewSyncData.Actor = Actor;
					NewSyncData.PacketData = ServerActor.Movement.CachedNetMovementData;
				}

				if (ServerActor.Movement.CachedCharacterMovementData.Num() > 0
					&& (bItHasBeenLongSinceLastSync || ServerActor.Movement.bCachedCharacterMovementDataDirty))
				{
					FSyncData& NewSyncData = SyncDataArray.AddDefaulted_GetRef();

					NewSyncData.SyncDataType = ESyncDataType::CharacterMovement;
					NewSyncData.ActorId = ActorId;
					NewSyncData.Actor = Actor;
					NewSyncData.PacketData = ServerActor.Movement.CachedCharacterMovementData;
				}

				if (ServerActor.Movement.CachedAnimalMovementData.Num() > 0
					&& (bItHasBeenLongSinceLastSync || ServerActor.Movement.bCachedAnimalMovementDataDirty))
				{
					FSyncData& NewSyncData = SyncDataArray.AddDefaulted_GetRef();

					NewSyncData.SyncDataType = ESyncDataType::AnimalMovement;
					NewSyncData.ActorId = ActorId;
					NewSyncData.Actor = Actor;
					NewSyncData.PacketData = ServerActor.Movement.CachedAnimalMovementData;
				}

				if (ServerActor.Movement.CachedAnimalMovementData.Num() > 0
					&& (bItHasBeenLongSinceLastSync || ServerActor.Movement.bCachedAnimalMovementDataDirty))
				{
					FSyncData& NewSyncData = SyncDataArray.AddDefaulted_GetRef();

					NewSyncData.SyncDataType = ESyncDataType::AnimalMovement;
					NewSyncData.ActorId = ActorId;
					NewSyncData.Actor = Actor;
					NewSyncData.PacketData = ServerActor.Movement.CachedAnimalMovementData;
				}
			}
		}
		else // AttachedParentActor
		{
			if (ensure(ServerActor.Movement.CachedAttachedTransformData.Num() > 0)
				&& (bItHasBeenLongSinceLastSync || ServerActor.Movement.bCachedAttachedTransformDataDirty))
			{
				FSyncData& NewSyncData = SyncDataArray.AddDefaulted_GetRef();

				NewSyncData.SyncDataType = ESyncDataType::AttachedTransform;
				NewSyncData.ActorId = ActorId;
				NewSyncData.Actor = Actor;
				NewSyncData.PacketData = ServerActor.Movement.CachedAttachedTransformData;
			}
		}
	}

	for (const FP3ServerActor::FMovement::FComponent& ComponentMovement : ServerActor.Movement.Components)
	{
		if (ensure(ComponentMovement.CachedTransformData.Num() > 0)
			&& (bItHasBeenLongSinceLastSync || ComponentMovement.bCachedTransformDataDirty))
		{
			FSyncData& NewSyncData = SyncDataArray.AddDefaulted_GetRef();

			NewSyncData.SyncDataType = ESyncDataType::ComponentTansform;
			NewSyncData.ActorId = ActorId;
			NewSyncData.Actor = Actor;
			NewSyncData.PacketData = ComponentMovement.CachedTransformData;
		}
	}
}

void UP3ServerWorld::SyncActorsToPlayer(UP3ServerPlayer* Player)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncActorsToPlayer"), STAT_P3ServerWorld_SyncActorsToPlayer, STATGROUP_P3);

	if (!ensure(Player))
	{
		return;
	}

	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return;
	}

	const FP3NetConnInfo& NetConnInfo = Player->NetConnInfo;

	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return;
	}

	const FP3PlayerStatus* PlayerStatus = &Player->Status;
	if (!PlayerStatus->bHasValidPawn)
	{
		// Player is not ready yet
		return;
	}

	bool bIsLocalPlayer = true;

	if (FP3NetUtil::IsTCPConnection(NetConnInfo))
	{
		if (P3World && P3World->GetGameInstance())
		{
			if (P3World->GetGameInstance()->GetPlayerNet())
			{
				bIsLocalPlayer = P3World->GetGameInstance()->GetPlayerNet()->IsLocalConnection(NetConnInfo.TCPConnId);
			}
		}
	}

	if (FP3NetUtil::IsUDPConnection(NetConnInfo))
	{
		if (P3World && P3World->GetGameInstance())
		{
			if (P3World->GetGameInstance()->GetUDPNetwork())
			{
				bIsLocalPlayer = P3World->GetGameInstance()->GetUDPNetwork()->IsLocalConnection(NetConnInfo.UDPConnId);
			}
		}
	}

	FP3PlayerSight& PlayerSight = Player->Sight;
	TArray<int64> AddFailedIds, SentIds;

	for (actorid ActorId : PlayerSight.Pending_AddedActors)
	{
		if (Player->Status.OwnActorIds.Contains(ActorId))
		{
			SentIds.Add(ActorId);
			continue;
		}

		// Skip if player failed to spawn this actor recently
		if (PlayerSight.SpawnFailedActorIds.Find(ActorId) != nullptr)
		{
			AddFailedIds.Add(ActorId);
			continue;
		}

		AActor* Actor = P3World->GetActorFromActorId(ActorId);

		if (ensure(Actor))
		{
			FP3NetSpawnActorParams NetSpawnParams;
			const bool bHasValidSpawnParam = _MakeSpawnActorParamsFromActor(bIsLocalPlayer, *Actor, NetSpawnParams);

			if (ensure(bHasValidSpawnParam))
			{
				NetSpawnParams.ActorId = ActorId;

				if (FP3NetUtil::IsUDPConnection(NetConnInfo))
				{
					UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork();

					if (UDPNetwork)
					{
						if (UDPNetwork->GetProtocol() == EP3NetProtocol::UnrealUDP)
						{
							UDPNetwork->Server_CreateActorChannel(NetConnInfo.UDPConnId, Actor, &NetSpawnParams);
						}
						else
						{
							P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, NetSpawnParams, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleSpawnActor);
						}
					}
				}

				if (FP3NetUtil::IsTCPConnection(NetConnInfo))
				{
					P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, NetSpawnParams, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleSpawnActor);
				}

				SentIds.Add(ActorId);
			}
			else
			{
				AddFailedIds.Add(ActorId);
			}
		}
	}

	UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork();
	
	for (actorid ActorId : PlayerSight.Pending_RemovedActors)
	{
		FP3NetActorId NetActorId;
		NetActorId.ActorId = ActorId;

		if (FP3NetUtil::IsUDPConnection(NetConnInfo))
		{
			if (UDPNetwork)
			{
				if (UDPNetwork->GetProtocol() == EP3NetProtocol::UnrealUDP)
				{
					UDPNetwork->Server_DestroyActorChannel(NetConnInfo.UDPConnId, ActorId);
				}
				else
				{
					P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetActorId, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleDestroyActor);
				}
			}
		}

		if (FP3NetUtil::IsTCPConnection(NetConnInfo))
		{
			P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, nullptr, NetActorId, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleDestroyActor);
		}
	}
	
	for (const int64 Id : PlayerSight.Pending_RemovedActors)
	{
		PlayerSight.ActorIds.Remove(Id);
	}

	PlayerSight.ActorIds.Append(SentIds);

	PlayerSight.Pending_AddedActors = AddFailedIds;
	PlayerSight.Pending_RemovedActors.Empty();

	ensure(PlayerSight.ActorIds.Num() + PlayerSight.Pending_AddedActors.Num() == P3World->Actors.Num());

	// Send store later on after all the actors are gone, so that store can restore actor from id
	for (actorid ActorId : SentIds)
	{
		SyncActorStoreToPlayer(Player, ActorId, nullptr);
	}
}

void UP3ServerWorld::SyncActorStoreToPlayer(const UP3ServerPlayer* Player, actorid ActorId, const FDirtyActor* DirtyActor)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SyncActorStoreToPlayer"), STAT_P3ServerWorld_SyncActorStoreToPlayer, STATGROUP_P3);

	if (!ensure(Player))
	{
		return;
	}

	const FP3NetConnInfo& NetConnInfo = Player->NetConnInfo;

	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return;
	}
	
	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		if (_IsLocalConnection(P3World->GetGameInstance(), NetConnInfo))
		{
			// Skip local player in case of standalone/listen server
			// Otherwise, server side data can be corrupted
			return;
		}
	}
	
	const FP3PlayerStatus* PlayerStatus = &Player->Status;
	if (!PlayerStatus->bHasValidPawn)
	{
		// Player is not ready yet
		return;
	}

	AActor* Actor = P3World->GetActorFromActorId(ActorId);

	if (!ensure(Actor))
	{
		return;
	}

	// Since following check can be slow on large map(because ActorIds can be huge) I will just skip the test in non-debug build
#if UE_BUILD_DEBUG
	ensure(Player->Sight.ActorIds.Contains(ActorId));
#endif

	FP3NetActorStoreData NetActorStoreData;
	NetActorStoreData.ActorId = ActorId;

	IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);

	if (ensure(ActorInterface))
	{
		if (!DirtyActor
			|| ((DirtyActor->bActorAndAllComponentsDirty || DirtyActor->bActorDirty)))
		{
			FP3StoreBitWriter BitWriter(P3World, 8192, true);
			ActorInterface->NetSerialize(BitWriter);
			ensure(BitWriter.GetMaxBits() == 8192);

			if (ensure(!BitWriter.IsError()))
			{
				NetActorStoreData.ActorStoreData = *BitWriter.GetBuffer();
			}
		}

		if (!DirtyActor
			|| ((DirtyActor->bActorAndAllComponentsDirty || DirtyActor->ComponentNames.Num() > 0)))
		{
			UP3StoreComponent* StoreComponent = ActorInterface->GetStoreComponent();
			if (StoreComponent)
			{
				const TSet<FName>* ComponentNames = (DirtyActor && !DirtyActor->bActorAndAllComponentsDirty) ? 
					&DirtyActor->ComponentNames : nullptr;
				StoreComponent->WriteNetBuffer(NetActorStoreData.ComponentStoreData, ComponentNames);
			}
		}
	}

	ensure(NetActorStoreData.ActorStoreData.Num() > 0 || NetActorStoreData.ComponentStoreData.Num() > 0);

	_FillNetAttachedLevelActors(NetActorStoreData.AttachedLevelActors, *Actor, ActorId);

	// TODO: maybe skip empty store?
	P3World->Server_SendPacketToPlayerReliable(NetConnInfo, (UP3ClientWorld*)(nullptr), INVALID_ACTORID, Actor, NetActorStoreData, EP3NetComponentType::ClientWorld, &UP3ClientWorld::HandleSyncActorStore);
}

bool UP3ServerWorld::SendPacketBufferToPlayer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bCheckPlayerStatus, bool bReliable) const
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_SendPacketToPlayer"), STAT_P3ServerWorld_SendPacketToPlayer, STATGROUP_P3);

	bool bListenServer = false;

	if (P3World && P3World->GetGameInstance())
	{
		EP3NetMode NetMode = P3World->GetGameInstance()->GetGameNetMode();

		bListenServer = (NetMode == EP3NetMode::ListenServer);
	}

	if (!bListenServer && P3Core::IsP3NetModeClientInstance(*this))
	{
		UP3ClientWorld* ClientWorld = P3World->GetClientWorld();

		if (ensure(ClientWorld))
		{
			ClientWorld->HandlePacketBuffer(NetConnInfo, ActorId, Actor, Buffer, Header);
		}

		return true;
	}

	if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
	{
		return false;
	}

	if (!ensure(GetWorld()))
	{
		return false;
	}

	if (bCheckPlayerStatus)
	{
		const UP3ServerPlayer* Player = FindPlayerByConnInfo(NetConnInfo);
		if (!ensure(Player))
		{
			return false;
		}

		const FP3PlayerStatus& PlayerStatus = Player->Status;
		if (!PlayerStatus.bHasValidPawn)
		{
			return false;
		}

		// Since following check can be slow on large map(because ActorIds can be huge) I will just skip the test in non-debug build
#if UE_BUILD_DEBUG
		ensure(ActorId == INVALID_ACTORID || Player->Sight.ActorIds.Contains(ActorId));
#endif
	}

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0)
	{
		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_HandlerNameSent].FindOrAdd(Header.HandlerFunctionName);
	}

	if (CVarP3WorldDebugPacket.GetValueOnGameThread() != 0)
	{
		P3JsonWorldLog(Display, "Server_SendPacketBufferToPlayer", TEXT("ActorId"), ActorId, TEXT("Function"), *Header.HandlerFunctionName.ToString());
	}

	if (P3World && P3World->GetGameInstance())
	{
		if (FP3NetUtil::IsTCPConnection(NetConnInfo))
		{
			UP3PlayerNet* PlayerNet = P3World->GetGameInstance()->GetPlayerNet();
			if (PlayerNet && PlayerNet->GetPlayerCount() > 0)
			{
				TSharedRef<pb::D2CUnrealRaw, ESPMode::ThreadSafe> Message(new pb::D2CUnrealRaw());
				Message->set_actor_id(ActorId);
				Message->set_buffer(Buffer.GetData(), StaticCast<size_t>(Buffer.Num()));
				Message->set_component_type(StaticCast<uint32>(Header.ComponentType));
				Message->set_handler_function_name(TCHAR_TO_UTF8(*Header.HandlerFunctionName.ToString()));

				PlayerNet->Send(NetConnInfo.TCPConnId, pb::D2CType::D2C_UNREAL_RAW, Message);
				return true;
			}
		}

		if (FP3NetUtil::IsUDPConnection(NetConnInfo))
		{
			UP3UDPNetwork* UDPNetwork = P3World->GetGameInstance()->GetUDPNetwork();

			if (UDPNetwork)
			{
				return UDPNetwork->Server_SendPacketBuffer(NetConnInfo.UDPConnId, ActorId, Actor, Buffer, Header, bReliable);
			}
		}
	}

	return false;
}

bool UP3ServerWorld::MulticastPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_MulticastPacket"), STAT_P3ServerWorld_MulticastPacket, STATGROUP_P3);

	if (!ensure(GetWorld()))
	{
		return false;
	}

	if (CVarP3WorldDebugPacket.GetValueOnGameThread() != 0)
	{
		P3JsonWorldLog(Display, "Server_MulticastPacketBuffer", TEXT("ActorId"), ActorId, TEXT("Function"), Header.HandlerFunctionName.ToString());
	}

	//if (GameInstance)
	//{
	//	UP3PlayerNet* PlayerNet = GameInstance->GetPlayerNet();
	//	if (PlayerNet && PlayerNet->GetPlayerCount() > 0)
	//	{
	//		// TODO: check Server_PlayerStatus for each player before send packet
	//		TSharedRef<pb::D2CUnrealRaw> Message(new pb::D2CUnrealRaw());
	//		Message->set_actor_id(ActorId);
	//		Message->set_buffer(Buffer.GetData(), Buffer.Num());
	//		Message->set_component_type(StaticCast<uint32>(Header.ComponentType));
	//		Message->set_handler_function_name(TCHAR_TO_UTF8(*Header.HandlerFunctionName));

	//		// Skip local player in case of standalone/listen server
	//		PlayerNet->SendToAll(pb::D2CType::D2C_UNREAL_RAW, Message);
	//		return;
	//	}
	//}

	if (ensure(P3World && P3World->GetGameInstance()))
	{
		UP3PlayerNet* PlayerNet = P3World->GetGameInstance()->GetPlayerNet();

		UP3UDPNetwork* UDPNetwork = P3World->GetGameInstance()->GetUDPNetwork();

		ensure(PlayerNet || UDPNetwork);

		for (const UP3ServerPlayer* Player : Players)
		{
			if (!Player)
			{
				continue;
			}

			const FP3NetConnInfo& NetConnInfo = Player->NetConnInfo;
			const FP3PlayerSight& Sight = Player->Sight;

			// Since following check can be slow on large map(because ActorIds can be huge) I will just skip the test in non-debug build
#if UE_BUILD_DEBUG
			ensure(ActorId == INVALID_ACTORID || Sight.ActorIds.Contains(ActorId));
#endif
			//if (ActorId == INVALID_ACTORID || Sight.ActorIds.Contains(ActorId))
			{
				if (!ensure(FP3NetUtil::IsNetConnValid(NetConnInfo)))
				{
					continue;
				}

				if (FP3NetUtil::IsTCPConnection(NetConnInfo))
				{
					if (PlayerNet)
					{
						if (P3Core::IsP3NetModeClientInstance(*this))
						{
							if (PlayerNet->IsLocalConnection(NetConnInfo.TCPConnId))
							{
								// Skip local player in case of standalone/listen server
								continue;
							}
						}

						TSharedRef<pb::D2CUnrealRaw, ESPMode::ThreadSafe> Message(new pb::D2CUnrealRaw());
						Message->set_actor_id(ActorId);
						Message->set_buffer(Buffer.GetData(), StaticCast<size_t>(Buffer.Num()));
						Message->set_component_type(StaticCast<uint32>(Header.ComponentType));
						Message->set_handler_function_name(TCHAR_TO_UTF8(*Header.HandlerFunctionName.ToString()));

						PlayerNet->Send(NetConnInfo.TCPConnId, pb::D2CType::D2C_UNREAL_RAW, Message);
					}
					continue;
				}

				if (FP3NetUtil::IsUDPConnection(NetConnInfo))
				{
					if (UDPNetwork)
					{
						if (P3Core::IsP3NetModeClientInstance(*this))
						{
							if (UDPNetwork->IsLocalConnection(NetConnInfo.UDPConnId))
							{
								// Skip local player in case of standalone/listen server
								continue;
							}
						}

						UDPNetwork->Server_SendPacketBuffer(NetConnInfo.UDPConnId, ActorId, Actor, Buffer, Header, bReliable);
					}
					continue;
				}
			}
		}
	}

	return true;
}

void UP3ServerWorld::HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_HandlePacket"), STAT_P3ServerWorld_HandlePacket, STATGROUP_P3);

	if (CVarP3WorldDebugPacket.GetValueOnGameThread() != 0)
	{
		P3JsonWorldLog(Display, "Server_HandlePacketBuffer", TEXT("ActorId"), ActorId, TEXT("Function"), Header.HandlerFunctionName.ToString());
	}

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0)
	{
		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_HandlerNameReceived].FindOrAdd(Header.HandlerFunctionName);
	}

	// TODO: We got to check if this Player has valid authority to do something on ActorId

	UObject* HandlerObject = nullptr;
	
	if (ActorId == INVALID_ACTORID)
	{
		if (Header.ComponentType == EP3NetComponentType::None)
		{
			HandlerObject = P3World;
		}
		else if (Header.ComponentType == EP3NetComponentType::ServerWorld)
		{
			HandlerObject = this;
		}
		else
		{
			ensureMsgf(0, TEXT("Invalid component type: %d"), (int32)Header.ComponentType);
		}
	}
	else
	{
		if (Actor == nullptr)
		{
			Actor = P3World ? P3World->GetActorFromActorId(ActorId) : nullptr;
		}

		if (ensure(Actor))
		{
			if (Header.ComponentType == EP3NetComponentType::None)
			{
				HandlerObject = Actor;
			}
			else if (Header.ComponentType == EP3NetComponentType::Command)
			{
				HandlerObject = Actor->FindComponentByClass<UP3CommandComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::Action)
			{
				HandlerObject = Actor->FindComponentByClass<UP3PawnActionComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::Health)
			{
				HandlerObject = Actor->FindComponentByClass<UP3HealthPointComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::CharacterMovement)
			{
				HandlerObject = Actor->FindComponentByClass<UP3CharacterMovementComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::Quest)
			{
				HandlerObject = Actor->FindComponentByClass<UP3QuestComponent>();
			}
			else
			{
				ensureMsgf(0, TEXT("Invalid component type: %d"), (int32)Header.ComponentType);
			}
		}
	}

	if (!ensure(HandlerObject))
	{
		P3JsonWorldLog(Warning, "Server handle packet buffer failed. No Actor found", TEXT("ActorId"), ActorId);
		return;
	}

	UFunction* HandlerFunction = HandlerObject->FindFunction(Header.HandlerFunctionName);

	if (!ensure(HandlerFunction))
	{
		P3JsonWorldLog(Warning, "Server handle packet buffer failed. No handler function found", 
			TEXT("HandlerFunctionName"), Header.HandlerFunctionName.ToString());
		return;
	}

	TArray<uint8> TempBuffer = Buffer;

	FP3ClientToDediHandlerParams Params;
	Params.NetConnInfo = NetConnInfo;
	Params.Buffer = Buffer;
	
	HandlerObject->ProcessEvent(HandlerFunction, &Params);
}

void FP3ServerActor::UpdateReplicatedMovement(UP3World* P3World, uint32 Frame)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ServerWorld_UpdateReplicatedMovement"), STAT_P3ServerWorld_UpdateReplicatedMovement, STATGROUP_P3);

	AActor* Actor = ActorPtr.Get();

	if (!ensure(Actor))
	{
		return;
	}

	Movement.ReplicatedMovementCachedFrame = Frame;

	Actor->GatherCurrentMovement();

	const FP3NetMovement OldMovement = Movement.CachedNetMovement;

	// NOTE: Reference AActor::GatherCurrentMovement()
	Movement.CachedNetMovement.ActorId = ActorId;
	Movement.CachedNetMovement.LinearVelocity = Actor->ReplicatedMovement.LinearVelocity;
	Movement.CachedNetMovement.AngularVelocity = Actor->ReplicatedMovement.AngularVelocity;
	Movement.CachedNetMovement.Location = Actor->ReplicatedMovement.Location;
	Movement.CachedNetMovement.Rotation = Actor->ReplicatedMovement.Rotation;
	Movement.CachedNetMovement.bSimulatedPhysicSleep = Actor->ReplicatedMovement.bSimulatedPhysicSleep;
	Movement.CachedNetMovement.bRepPhysics = Actor->ReplicatedMovement.bRepPhysics;

	Movement.bCacheIsDirty = !OldMovement.Equals(Movement.CachedNetMovement);

	if (Movement.bCacheIsDirty || Movement.CachedNetMovementData.Num() == 0)
	{
		FP3StoreBitWriter BitWriter(P3World, 512, true);
		FP3NetMovement::StaticStruct()->SerializeBin(BitWriter, &Movement.CachedNetMovement);
		ensure(BitWriter.GetMaxBits() == 512);

		if (ensure(!BitWriter.IsError()))
		{
			Movement.CachedNetMovementData = *BitWriter.GetBuffer();
		}
		else
		{
			Movement.CachedNetMovementData.Empty();
			Movement.bCacheIsDirty = false;
		}
	}

	AP3Character* Character = Cast<AP3Character>(Actor);

	if (Character)
	{
		FP3StoreBitWriter BitWriter(P3World, 256, true);
		Character->NetSerializeMovement(BitWriter);
		ensure(BitWriter.GetMaxBits() == 256);

		if (ensure(!BitWriter.IsError()))
		{
			const TArray<uint8> OldData = Movement.CachedCharacterMovementData;

			Movement.CachedCharacterMovementData = *BitWriter.GetBuffer();
			Movement.bCachedCharacterMovementDataDirty = (OldData != Movement.CachedCharacterMovementData);
		}
		else
		{
			Movement.CachedCharacterMovementData.Empty();
			Movement.bCachedCharacterMovementDataDirty = false;
		}
	}
	else if (AP3AnimalCharacter* Animal = Cast<AP3AnimalCharacter>(Actor))
	{
		FP3StoreBitWriter BitWriter(P3World, 256, true);
		Animal->NetSerializeMovement(BitWriter);
		ensure(BitWriter.GetMaxBits() == 256);

		if (ensure(!BitWriter.IsError()))
		{
			const TArray<uint8> OldData = Movement.CachedAnimalMovementData;

			Movement.CachedAnimalMovementData = *BitWriter.GetBuffer();
			Movement.bCachedAnimalMovementDataDirty = (OldData != Movement.CachedAnimalMovementData);
		}
		else
		{
			Movement.CachedAnimalMovementData.Empty();
			Movement.bCachedAnimalMovementDataDirty = false;
		}
	}

	const AActor* AttachedParentActor = Movement.bAttached ? Actor->GetAttachParentActor() : nullptr;

	if (AttachedParentActor)
	{
		FP3NetActorTransform NetActorTransform;
		NetActorTransform.ActorId = ActorId;
		NetActorTransform.bAttached = true;
		NetActorTransform.Transform = Actor->GetRootComponent()->GetRelativeTransform();
		NetActorTransform.AttachedComponent = Actor->GetRootComponent()->GetAttachParent();
		NetActorTransform.AttachedSocketName = Actor->GetAttachParentSocketName();

		FP3StoreBitWriter BitWriter(P3World, 2048, true);
		BitWriter << NetActorTransform;
		ensure(BitWriter.GetMaxBits() == 2048);

		if (ensure(!BitWriter.IsError()))
		{
			const TArray<uint8> OldData = Movement.CachedAttachedTransformData;

			Movement.CachedAttachedTransformData = *BitWriter.GetBuffer();
			Movement.bCachedAttachedTransformDataDirty = (OldData != Movement.CachedAttachedTransformData);
		}
		else
		{
			Movement.CachedAttachedTransformData.Empty();
			Movement.bCachedAttachedTransformDataDirty = false;
		}
	}


	for (FP3ServerActor::FMovement::FComponent& ComponentMovement : Movement.Components)
	{
		USceneComponent* Component = ComponentMovement.Component.Get();

		if (!ensure(Component))
		{
			continue;
		}

		ensure(Component->GetIsReplicated());

		FP3NetActorComponentTransform NetTransform;
		NetTransform.ActorId = ActorId;
		NetTransform.ComponentName = Component->GetName();
		NetTransform.AttachParentComponentName = Component->GetAttachParent() ? Component->GetAttachParent()->GetName() : TEXT("");
		NetTransform.Transform = Component->GetRelativeTransform();
		NetTransform.bHiddenInGame = Component->bHiddenInGame;

		FP3StoreBitWriter BitWriter(P3World, 1024, true);
		BitWriter << NetTransform;
		ensure(BitWriter.GetMaxBits() == 1024);

		if (ensure(!BitWriter.IsError()))
		{
			const TArray<uint8> OldData = ComponentMovement.CachedTransformData;

			ComponentMovement.CachedTransformData = *BitWriter.GetBuffer();
			ComponentMovement.bCachedTransformDataDirty = (OldData != ComponentMovement.CachedTransformData);
		}
		else
		{
			ComponentMovement.CachedTransformData.Empty();
			ComponentMovement.bCachedTransformDataDirty = false;
		}
	}
}

bool UP3ServerWorld::IsReady() const
{
	return P3World && (P3GetPlayerNet(this) || P3GetUDPNetwork(this));
}

FString UP3ServerWorld::GetPlayersAsJson() const
{
	FString PlayersJson;
	TSharedRef<TJsonWriter<TCHAR>> JsonWriter = TJsonWriterFactory<TCHAR>::Create(&PlayersJson);
	JsonWriter->WriteObjectStart();
	{
		JsonWriter->WriteArrayStart(TEXT("players"));
		for (const UP3ServerPlayer* Player : Players)
		{
			JsonWriter->WriteObjectStart();
			JsonWriter->WriteValue("character_id", Player->CharacterId);
			JsonWriter->WriteValue("name", Player->Name.ToString());
			JsonWriter->WriteObjectEnd();
		}
		JsonWriter->WriteArrayEnd();
	}
	JsonWriter->WriteObjectEnd();
	JsonWriter->Close();

	return PlayersJson;
}

void UP3ServerWorld::SendWorldMessageToWorldServer(const FP3NetConnInfo& NetConn, const pb::C2DWorldMessage& WorldMessage)
{
	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);
	if (!ensure(WorldNet))
	{
		return;
	}

	const UP3ServerPlayer* Player = FindPlayerByConnInfo(NetConn);

	if (!ensure(Player != nullptr))
	{
		return;
	}

	if (!ensure(Player->CharacterId != INVALID_CHARID))
	{
		return;
	}

	const pb::C2DWorldRelayMessage& RelayMessage = WorldMessage.message();

	if (RelayMessage.has_player_list_req())
	{
		WorldNet->SendRequestPlayerList(Player->CharacterId);
	}
	else if (RelayMessage.has_party_invite())
	{
		const pb::C2DWorldRelayMessage_PartyInvite& PartyInvite = RelayMessage.party_invite();

		const FString& InviteeName = UTF8_TO_TCHAR(PartyInvite.invitee_name().c_str());

		WorldNet->SendInviteParty(Player->CharacterId, Player->Name.ToString(), InviteeName);
	}
	else if (RelayMessage.has_party_invitation_res())
	{
		const pb::C2DWorldRelayMessage_PartyInvitationRes& PartyInvitationRes = RelayMessage.party_invitation_res();

		pb::PartyDefine Response = PartyInvitationRes.response();

		WorldNet->SendInvitePartyResponse(Player->CharacterId, Response);
	}
	else if (RelayMessage.has_party_leave())
	{
		WorldNet->SendLeaveParty(Player->CharacterId);
	}
	else
	{
		ensure(0);
	}
}

void UP3ServerWorld::SendWorldMessageToClient(const FP3NetConnInfo& NetConn, pb::D2CWorldRelayMessageType RelayMessageType, const ProtobufMessage& RelayMessage)
{
	if (!ensure(P3World))
	{
		return;
	}

	if (!ensure(P3World->GetGameInstance()))
	{
		return;
	}

	TSharedRef<pb::D2CWorldMessage, ESPMode::ThreadSafe> WorldMessage(new pb::D2CWorldMessage());

	pb::D2CWorldRelayMessage* WorldRelayMessage = WorldMessage->mutable_message();

	if (!ensure(WorldRelayMessage))
	{
		return;
	}

	WorldRelayMessage->set_message_type(RelayMessageType);

	ProtobufMessage* DstMessage = nullptr;

	switch (RelayMessageType)
	{
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPlayerList:
	{
		DstMessage = WorldRelayMessage->mutable_player_list();
		break;
	}
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyInvitation:
	{
		DstMessage = WorldRelayMessage->mutable_party_invitation();
		break;
	}
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyMembersJoin:
	{
		DstMessage = WorldRelayMessage->mutable_party_members_join();
		break;
	}
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyMembersLeave:
	{
		DstMessage = WorldRelayMessage->mutable_party_members_leave();
		break;
	}
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyLeaveRes:
	{
		DstMessage = WorldRelayMessage->mutable_party_leave_res();
		break;
	}
	default:
		break;
	}

	if (ensure(DstMessage))
	{
		auto CopyProtobuf = [](const ProtobufMessage& Src, ProtobufMessage& Dst) -> bool {
			if (Src.GetDescriptor() == Dst.GetDescriptor())
			{
				if (Src.ByteSizeLong() > 0)
				{
					Dst.CopyFrom(Src);
				}
				return true;
			}
			return false;
		};

		const bool bValidMessage = CopyProtobuf(RelayMessage, *DstMessage);

		if (!ensure(bValidMessage))
		{
			return;
		}

		if (FP3NetUtil::IsTCPConnection(NetConn))
		{
			UP3PlayerNet* PlayerNet = P3World->GetGameInstance()->GetPlayerNet();

			if (ensure(PlayerNet))
			{
				PlayerNet->Send(NetConn.TCPConnId, pb::D2CType::D2C_WORLD_MESSAGE, WorldMessage);
			}
		}
		else if (FP3NetUtil::IsUDPConnection(NetConn))
		{
			UP3UDPNetwork* UDPNetwork = P3World->GetGameInstance()->GetUDPNetwork();

			if (ensure(UDPNetwork))
			{
				UDPNetwork->Server_SendWorldMessage(NetConn.UDPConnId, WorldMessage.Get());
			}
		}
		else
		{
			ensure(0);
		}
	}
}
