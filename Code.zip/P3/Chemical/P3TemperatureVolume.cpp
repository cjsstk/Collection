// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3TemperatureVolume.h"

#include "ActorEditorUtils.h"
#include "Components/BrushComponent.h"
#include "GameFramework/Volume.h"
#include "UObject/UObjectIterator.h"

#include "Character/P3CharacterTemperatureComponent.h"

#include "P3Character.h"
#include "P3Core.h"
#include "P3ServerWorld.h"
#include "P3World.h"

extern TAutoConsoleVariable<int32> CVarTemperatureDebug;

void AP3TemperatureVolume::UpdateTemperatureVolumeDebug(bool bForceUpdate)
{
	static int32 TemperatureDebug = 0;

	if (bForceUpdate || TemperatureDebug != CVarTemperatureDebug.GetValueOnGameThread())
	{
		TemperatureDebug = CVarTemperatureDebug.GetValueOnGameThread();

		// Note: Following codes are copied from UGameViewportClient::ToggleShowVolumes()

		// Iterate over all brushes
		for (TObjectIterator<UBrushComponent> It; It; ++It)
		{
			UBrushComponent* BrushComponent = *It;
			AVolume* Owner = Cast<AVolume>(BrushComponent->GetOwner());

			// Only bother with volume brushes that belong to the world's scene
			if (Owner && Owner->GetWorld() && Owner->GetWorld()->IsGameWorld()
				&& BrushComponent->GetScene() == Owner->GetWorld()->Scene && !FActorEditorUtils::IsABuilderBrush(Owner))
			{
				// Toggle visibility of this volume
				if (TemperatureDebug)
				{
					BrushComponent->SetVisibility(true);
					BrushComponent->SetHiddenInGame(false);
				}
				else
				{
					BrushComponent->SetVisibility(false);
					BrushComponent->SetHiddenInGame(true);
				}
			}
		}
	}
}

bool AP3TemperatureVolume::bUpdateTemperatureVolumeDebugBound = false;

AP3TemperatureVolume::AP3TemperatureVolume()
{
	GetBrushComponent()->SetCollisionResponseToAllChannels(ECR_Ignore);
	GetBrushComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
}

void AP3TemperatureVolume::BeginPlay()
{
	Super::BeginPlay();

	if (!bUpdateTemperatureVolumeDebugBound)
	{
		bUpdateTemperatureVolumeDebugBound = true;

		IConsoleManager::Get().RegisterConsoleVariableSink_Handle(FConsoleCommandDelegate::CreateStatic(AP3TemperatureVolume::UpdateTemperatureVolumeDebug, false));
	}
	else
	{
#if !UE_BUILD_SHIPPING
		// To make debug easier..
		AP3TemperatureVolume::UpdateTemperatureVolumeDebug(true);
#endif
	}
}

void AP3TemperatureVolume::NotifyActorBeginOverlap(AActor* OtherActor)
{
	Super::NotifyActorBeginOverlap(OtherActor);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(OtherActor);

		if (Character && Character->GetTemperatureComponent())
		{
			Character->GetTemperatureComponent()->Server_AddTemperatureVolume(Temperature, TemperaturePriority, *this);
		}
	}
}

void AP3TemperatureVolume::NotifyActorEndOverlap(AActor* OtherActor)
{
	Super::NotifyActorEndOverlap(OtherActor);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(OtherActor);

		if (Character && Character->GetTemperatureComponent())
		{
			Character->GetTemperatureComponent()->Server_RemoveTemperatureVolume(*this);
		}
	}
}
