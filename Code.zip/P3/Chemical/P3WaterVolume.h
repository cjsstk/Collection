// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Volume.h"
#include "P3WaterVolume.generated.h"

/**
 * Water Volume
 */
UCLASS()
class P3_API AP3WaterVolume : public AVolume
{
	GENERATED_BODY()
	
	AP3WaterVolume();

private:
	UPROPERTY(VisibleAnywhere, Category = "Water")
	class UP3WaterComponent* WaterComponent;
};
