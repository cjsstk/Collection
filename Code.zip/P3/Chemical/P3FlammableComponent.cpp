// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3FlammableComponent.h"

#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystemComponent.h"
#include "TimerManager.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "Character/P3CharacterTemperatureComponent.h"
#include "Chemical/P3WetComponent.h"
#include "Command/P3CommandComponent.h"
#include "P3Actor.h"
#include "P3ActorInterface.h"
#include "P3BlueprintFunctionLibrary.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3Combat.h"
#include "P3DamageType.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3Physics.h"
#include "P3PickupComponent.h"
#include "P3Weapon.h"
#include "P3World.h"

TAutoConsoleVariable<int32> CVarP3FlameDebug(
	TEXT("p3.flameDebug"),
	0,
	TEXT("1: debug on, 0: debug off"), ECVF_Cheat);

TAutoConsoleVariable<float> CVarP3FlameUnregisterParticleDelaySeconds(
	TEXT("p3.flameUnregisterParticleDelaySeconds"),
	5,
	TEXT("Particle system will be unregisted after this time"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3FlameTickHitActionEnable(
	TEXT("p3.flameTickHitActionEnable"),
	0,
	TEXT("1: Do hit action in fire, 0: No hit action in fire"), ECVF_Cheat);


UP3FlammableComponent::UP3FlammableComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;

	ShapeColor = FColor::Red;
	bCanEverAffectNavigation = false;

	SetCollisionProfileName(FName("Flame"));
}

void UP3FlammableComponent::OnRegister()
{
	Super::OnRegister();

	if (!IsRunningCommandlet())
	{
		ensureMsgf(!GetOwner() || (Cast<IP3ActorInterface>(GetOwner()) != nullptr), TEXT("Flammable is only valid with P3Actor. Used actor: %s"), GetOwner() ? *GetOwner()->GetName() : TEXT("NULL"));
	}

	if (GetOwner() && !Cast<IP3ActorInterface>(GetOwner()))
	{
		P3JsonLog(Warning, "Flammable is only valid with P3Actor", TEXT("Actor"), GetOwner()->GetName());
	}

#if WITH_EDITOR
	if (bStartInFire)
	{
		SetVisibility(true, true);
	}
	else
	{
		SetVisibility(false, true);

		TArray<USceneComponent*> ChildrenComponents;
		GetChildrenComponents(true, ChildrenComponents);

		for (USceneComponent* ChildComp : ChildrenComponents)
		{
			UParticleSystemComponent* ParticleComp = Cast<UParticleSystemComponent>(ChildComp);

			if (ParticleComp)
			{
				// Since particle system component will be ticked even while invisible
				// And GPU particle increase take several DP during it's tick,
				// we need to avoid register at all during Editor view to make aritst not to be confused
				ParticleComp->bAutoRegister = false;
			}
		}
	}
#endif
}

void UP3FlammableComponent::OnUnregister()
{
	Super::OnUnregister();

	if (Server_DamageAroundTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(Server_DamageAroundTimerHandle);
	}
}

void UP3FlammableComponent::BeginPlay()
{
	Super::BeginPlay();
	
	ensure(GetOwner()->GetIsReplicated());

	if (GetOwner() && !Cast<IP3ActorInterface>(GetOwner()))
	{
		P3JsonLog(Warning, "Flammable is only valid with P3Actor", TEXT("Actor"), GetOwner()->GetName());
	}

	Server_LeftFireDurationSeconds = FireDurationSeconds;
	Server_TimeToStartFireLeftSeconds = TimeToStartFireSeconds;
	Server_TimeToDestroyActorLeftSeconds = TimeToDestoryActorSeconds;
	Server_FireCoolDownLeftSeconds = bCoolDownStartAtBeginning ? FireCoolDownSeconds : 0.0f;

	SetFireInternal(bStartInFire);
}

void UP3FlammableComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (GIsClient)
	{
		// To fade out particles, we need to re-attach them to world particle actor
		TArray<USceneComponent*> ChildrenComponents;
		GetChildrenComponents(true, ChildrenComponents);

		for (USceneComponent* ChildComp : ChildrenComponents)
		{
			UParticleSystemComponent* ParticleComp = Cast<UParticleSystemComponent>(ChildComp);

			if (ParticleComp && ParticleComp->IsActive())
			{
				ParticleComp->Rename(nullptr, P3Core::GetP3WorldParticleActor(this));

				// Let particle fade out by it self
				ParticleComp->bAutoDestroy = true;
				ParticleComp->Deactivate();
			}
		}
	}
}

void UP3FlammableComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	DECLARE_CYCLE_STAT(TEXT("P3Flammable_Tick"), STAT_P3Flammable_Tick, STATGROUP_P3);

	if (UnregisterParticleSystemTimeSeconds != 0.0f)
	{
		if (UnregisterParticleSystemTimeSeconds < GetWorld()->GetTimeSeconds())
		{
			ensure(!bInFire);

			UnregisterParticleSystemTimeSeconds = 0.0f;

			TArray<USceneComponent*> ChildrenComponents;
			GetChildrenComponents(true, ChildrenComponents);

			for (USceneComponent* ChildComp : ChildrenComponents)
			{
				UParticleSystemComponent* ParticleComp = Cast<UParticleSystemComponent>(ChildComp);

				if (ParticleComp)
				{
					ParticleComp->UnregisterComponent();
				}
			}
		}
	}

	FString DebugString;

	if (CVarP3FlameDebug.GetValueOnGameThread() != 0)
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(GetOwner());
		if (P3ActorInterface)
		{
			DebugString = FString::Printf(TEXT("Fire(%s)"), bInFire ? TEXT("On") : TEXT("Off"));
		}
	}

	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		if (IsInFire())
		{
			Server_TickFiringAge(DeltaTime);
			Server_TickFireDestroyActor(DeltaTime);
			Server_TickSpreading(DeltaTime);
			Server_TickDamage(DeltaTime);
		}
		else
		{
			Server_FireCoolDownLeftSeconds = FMath::Max(0.0f, Server_FireCoolDownLeftSeconds - DeltaTime);

			// If we were burning by other flame
			if (Server_TimeToStartFireLeftSeconds < TimeToStartFireSeconds)
			{
				const float TimeSinceLastBurn = GetWorld()->GetTimeSeconds() - Server_LastBurnTimeSeconds;
				if (TimeSinceLastBurn > 1.0f)
				{
					// And it has been long since last burn, lets restore the timer
					Server_TimeToStartFireLeftSeconds = FMath::Min(Server_TimeToStartFireLeftSeconds + DeltaTime, TimeToStartFireSeconds);
				}
			}
		}

		if (CVarP3FlameDebug.GetValueOnGameThread() != 0)
		{
			if (FireDurationSeconds > 0)
			{
				DebugString += FString::Printf(TEXT(", Duration(%.2f/%.2f)"), Server_LeftFireDurationSeconds, FireDurationSeconds);
			}

			if (FireDurationSeconds > 0)
			{
				DebugString += FString::Printf(TEXT(", Start(%.2f/%.2f)"), Server_TimeToStartFireLeftSeconds, TimeToStartFireSeconds);
			}

			if (TimeToDestoryActorSeconds > 0)
			{
				DebugString += FString::Printf(TEXT(", Destroy(%.2f/%.2f)"), Server_TimeToDestroyActorLeftSeconds, TimeToDestoryActorSeconds);
			}

			if (FireCoolDownSeconds > 0)
			{
				DebugString += FString::Printf(TEXT(", Cooldown(%.2f/%.2f)"), Server_FireCoolDownLeftSeconds, FireCoolDownSeconds);
			}

			if (MaxBurnAgainCount >= 0)
			{
				DebugString += FString::Printf(TEXT(", Repeat(%.2f/%.2f)"), Server_NumBurned, MaxBurnAgainCount);
			}
		}
	}
	else
	{
		Client_TickSmokeAge(DeltaTime);

		if (CVarP3FlameDebug.GetValueOnGameThread() != 0)
		{
			if (Client_SmokeParticleTimeAgeSeconds >= 0)
			{
				DebugString += FString::Printf(TEXT(", Smoke(%.2f/%.2f)"), Client_SmokeParticleTimeAgeSeconds, SmokeParticleTimeSeconds);
			}
		}
	}

	if (CVarP3FlameDebug.GetValueOnGameThread() != 0)
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(GetOwner());
		if (P3ActorInterface)
		{
			P3ActorInterface->AddDebugString(DebugString);
		}

		if (GetOwner() && GetWorld() && GetOwner()->GetLastRenderTime() > GetWorld()->GetTimeSeconds() - 5.0f)
		{
			DrawDebugSphere(GetWorld(), GetComponentLocation(), GetScaledSphereRadius(), 12, IsInFire() ? FColor::Red : FColor::Yellow);
		}
	}
}

void UP3FlammableComponent::Server_TickFiringAge(float DeltaSeconds)
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	if (!IsInFire())
	{
		return;
	}

	if (FireDurationSeconds <= 0)
	{
		return;
	}

	Server_LeftFireDurationSeconds -= DeltaSeconds;

	if (Server_LeftFireDurationSeconds <= 0)
	{
		Server_LeftFireDurationSeconds = 0;

		SetFireInternal(false);
	}
}

void UP3FlammableComponent::Server_TickFireDestroyActor(float DeltaSeconds)
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	if (!IsInFire())
	{
		return;
	}

	if (TimeToDestoryActorSeconds <= 0)
	{
		return;
	}

	Server_TimeToDestroyActorLeftSeconds -= DeltaSeconds;

	if (Server_TimeToDestroyActorLeftSeconds <= 0)
	{
		Server_TimeToDestroyActorLeftSeconds = 0;

		if (GetOwner())
		{
			GetOwner()->Destroy();
		}
	}
}

void UP3FlammableComponent::Server_TickSpreading(float DeltaSeconds)
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	if (!IsInFire())
	{
		return;
	}

	AActor* OwnerActor = GetOwner();

	if (!OwnerActor)
	{
		return;
	}

	AActor* AttachParentActor = OwnerActor->GetAttachParentActor();

	const bool bIsWeapon = OwnerActor->IsA(AP3Weapon::StaticClass());

	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("FlammableComponent_TickSpreading"), STAT_FlammableComponent_TickSpreading, STATGROUP_P3);

	// TODO: Slow down tick rate

	TArray<UP3FlammableComponent*> TargetFlammableComps;

	for (const FOverlapInfo& OverlapComponentInfo : OverlappingComponents)
	{
		UPrimitiveComponent* OverlappingComp = OverlapComponentInfo.OverlapInfo.GetComponent();

		if (!OverlappingComp)
		{
			continue;
		}

		UP3FlammableComponent* FlammableComp = Cast<UP3FlammableComponent>(OverlappingComp);

		if (!FlammableComp)
		{
			if (OverlappingComp->IsA(UP3CharacterTemperatureComponent::StaticClass()))
			{
				// Temperature component is ECC_Flame overlap type but it doesn't mean it will get burn
				// It's just using it to detect near by flammable, so got to ignore it.
				// Otherwise character will get burn too early without actual contact
				continue;
			}

			// First, look for first flammable and see if it's not bChildComponentOverlapOnly
			FlammableComp = OverlappingComp->GetOwner() ? OverlappingComp->GetOwner()->FindComponentByClass<UP3FlammableComponent>() : nullptr;

			if (!FlammableComp || FlammableComp->bChildComponentOverlapOnly)
			{
				// Second, see if we have bChildComponentOverlapOnly along the ancestor
				FlammableComp = P3Core::GetParentComponentByComponentType<UP3FlammableComponent>(OverlappingComp);

				if (!FlammableComp || !FlammableComp->bChildComponentOverlapOnly)
				{
					continue;
				}
			}
		}

		if (FlammableComp == this)
		{
			continue;
		}

		if (TargetFlammableComps.Contains(FlammableComp))
		{
			continue;
		}

		AActor* OverlappingActor = FlammableComp->GetOwner();
		AP3Character* OverlappingCharacter = Cast<AP3Character>(OverlappingActor);

		// Character is kind of picky about getting burned by
		if (OverlappingCharacter)
		{
			// It doesn't want to get burned by it's own weapon
			if (bIsWeapon && OverlappingCharacter == AttachParentActor)
			{
				continue;
			}

			// It doesn't want to get burned by something it pickupped
			if (OverlappingCharacter->GetPickupComponent() && OwnerActor == OverlappingCharacter->GetPickupComponent()->GetPickuppedActor())
			{
				continue;
			}
		}

		TargetFlammableComps.Add(FlammableComp);
	}

	for (UP3FlammableComponent* TargetFlammableComp : TargetFlammableComps)
	{
		TargetFlammableComp->Server_Burn(DeltaSeconds * FirePower, this);
	}
}

void UP3FlammableComponent::Server_TickDamage(float DeltaSeconds)
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	if (FlameDamageAmount > 0 && FlameDamageTickSeconds > 0)
	{
		Server_FlameDamageTickAgeSeconds += DeltaSeconds;

		if (Server_FlameDamageTickAgeSeconds > FlameDamageTickSeconds)
		{
			Server_FlameDamageTickAgeSeconds = 0;

			Server_DamageAround();
		}
	}

	if (SelfDamageAmount > 0 && SelfDamageTickSeconds > 0)
	{
		Server_SelfDamageTickAgeSeconds += DeltaSeconds;

		if (Server_SelfDamageTickAgeSeconds > SelfDamageTickSeconds)
		{
			Server_SelfDamageTickAgeSeconds = 0;

			Server_DamageOneself();
		}
	}
}

void UP3FlammableComponent::Server_DamageAround()
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	if (!IsInFire())
	{
		return;
	}

	if (FlameDamageAmount <= 0)
	{
		return;
	}

	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("FlammableComponent_DamageAround"), STAT_FlammableComponent_DamageAround, STATGROUP_P3);

	TArray<USceneComponent*> ChildComponents;
	GetChildrenComponents(true, ChildComponents);

	TSet<AActor*> UniqueOverlappingActors;

	for (USceneComponent* ChildComp : ChildComponents)
	{
		UPrimitiveComponent* ChildPrimComp = Cast<UPrimitiveComponent>(ChildComp);
		if (!ChildPrimComp)
		{
			continue;
		}

		TSet<AActor*> OverlappingActors;
		ChildPrimComp->GetOverlappingActors(OverlappingActors);

		UniqueOverlappingActors.Append(OverlappingActors);
	}

	AActor* MyAttachRootActor = GetOwner()->GetRootComponent()->GetAttachmentRootActor();

	for (AActor* Actor : UniqueOverlappingActors)
	{
		if (Actor == GetOwner())
		{
			continue;
		}

		AActor* AttachRootActor = Actor->GetRootComponent() ? Actor->GetRootComponent()->GetAttachmentRootActor() : Actor;

		if (MyAttachRootActor == AttachRootActor || MyAttachRootActor == Actor || AttachRootActor == GetOwner())
		{
			continue;
		}

		UP3FlammableComponent* FlammableComp = Actor->FindComponentByClass<UP3FlammableComponent>();
		if (FlammableComp && !FlammableComp->IsDamageOneself())
		{
			continue;
		}

		UP3PawnActionComponent* ActionComp = Actor->FindComponentByClass<UP3PawnActionComponent>();
		if (ActionComp)
		{
			AP3Character* OverlapCharacter = Cast<AP3Character>(Actor);
			if (OverlapCharacter && !OverlapCharacter->IsLarge() && CVarP3FlameTickHitActionEnable.GetValueOnGameThread() > 0)
			{
				FP3PawnActionStartRequestParams HitParams;
				HitParams.CombatHit_Damage = FlameDamageAmount;
				HitParams.CombatHit_SourceActor = GetOwner();

				ActionComp->StartAction(EPawnActionType::CombatHit, _FUNCTION_TEXT, HitParams);
			}

			UP3CommandComponent* CommandComp = Actor->FindComponentByClass<UP3CommandComponent>();
			if (CommandComp)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.ApplyDamage_DamageAmount = FlameDamageAmount;
				CommandParams.ApplyDamage_SourceActor = GetOwner();
				CommandParams.ApplyDamage_HitLocation = Actor->GetActorLocation();
				CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Flame;

				CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
			}
		}
		else
		{
			const int32 Damage = FlameDamageAmount;

			FPointDamageEvent PointDamageEvent;
			PointDamageEvent.Damage = Damage;
			Actor->TakeDamage(Damage, PointDamageEvent, nullptr, GetOwner());

			// TODO: need to find a way to broadcast to client
			P3Combat::ChangeActorHealth(GetOwner(), *Actor, -Damage, EP3HealthChangeReason::Flame);
		}
	}

}

void UP3FlammableComponent::Server_DamageOneself()
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	if (!IsInFire())
	{
		return;
	}

	if (SelfDamageAmount <= 0.0f)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (Character)
	{
		if (!Character->IsDead())
		{
			UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

			if (ActionComp && CVarP3FlameTickHitActionEnable.GetValueOnGameThread() > 0)
			{
				if (!Character->IsLarge())
				{
					FP3PawnActionStartRequestParams HitParams;
					HitParams.CombatHit_Damage = SelfDamageAmount;
					HitParams.CombatHit_DamageType = EP3DamageType::Flame;

					ActionComp->StartAction(EPawnActionType::CombatHitFlame, _FUNCTION_TEXT, HitParams);
				}
			}

			UP3CommandComponent* CommandComp = Character->GetCommandComponent();

			if (CommandComp)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.ApplyDamage_DamageAmount = SelfDamageAmount;
				CommandParams.ApplyDamage_SourceActor = nullptr; // Hotfix: Not to attack oneself by aggro system
				CommandParams.ApplyDamage_HitLocation = GetOwner()->GetActorLocation();
				CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Flame;

				CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
			}
		}
	}
	else
	{
		FPointDamageEvent PointDamageEvent;
		PointDamageEvent.Damage = SelfDamageAmount;
		GetOwner()->TakeDamage(SelfDamageAmount, PointDamageEvent, nullptr, GetOwner());

		// TODO: need to find a way to broadcast to client
		if (GetOwner())
		{
			P3Combat::ChangeActorHealth(nullptr, *GetOwner(), -SelfDamageAmount, EP3HealthChangeReason::Flame);
		}
	}
}

void UP3FlammableComponent::SetFireInternal(bool bNewFire)
{
	const bool bOldInFire = bInFire;

	bInFire = bNewFire;

	AActor* OwnerActor = GetOwner();

	if (bInFire)
	{
		SetComponentTickEnabled(true);

		SetCollisionEnabled(ECollisionEnabled::QueryOnly);

		SetVisibility(true, true);

		TArray<USceneComponent*> ChildrenComponents;
		GetChildrenComponents(true, ChildrenComponents);

		for (USceneComponent* ChildComp : ChildrenComponents)
		{
			UParticleSystemComponent* ParticleComp = Cast<UParticleSystemComponent>(ChildComp);

			if (ParticleComp)
			{
				if (!ParticleComp->IsRegistered())
				{
					ParticleComp->RegisterComponent();
				}

				ParticleComp->Activate(true);
			}
		}

		if (ExplosionParticle)
		{
			UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), ExplosionParticle, GetComponentTransform());
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			++Server_NumBurned;

			Server_DamageAround();
			Server_Explode();

			AP3Character* Character = Cast<AP3Character>(GetOwner());
			if (Character)
			{
				UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
				if (ActionComp)
				{
					if (!Character->IsLarge())
					{
						FP3PawnActionStartRequestParams HitParams;
						HitParams.CombatHit_Damage = SelfDamageAmount;
						HitParams.CombatHit_DamageType = EP3DamageType::Flame;

						ActionComp->StartAction(EPawnActionType::CombatHitFlame, _FUNCTION_TEXT, HitParams);
					}
				}

				UP3CommandComponent* CommandComp = Character->GetCommandComponent();
				if (CommandComp)
				{
					FP3CommandRequestParams CommandParams;
					CommandParams.ApplyDamage_DamageAmount = SelfDamageAmount;
					CommandParams.ApplyDamage_SourceActor = nullptr; // Hotfix: Not to attack oneself by aggro system
					CommandParams.ApplyDamage_HitLocation = GetOwner()->GetActorLocation();
					CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Flame;

					CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
				}
			}
		}

		OnFire.Broadcast(true);

		UnregisterParticleSystemTimeSeconds = 0.0f;
	}
	else
	{
		SetCollisionEnabled(ECollisionEnabled::NoCollision);

		TArray<USceneComponent*> ChildrenComponents;
		GetChildrenComponents(true, ChildrenComponents);

		for (USceneComponent* ChildComp : ChildrenComponents)
		{
			UParticleSystemComponent* ParticleComp = Cast<UParticleSystemComponent>(ChildComp);

			if (ParticleComp)
			{
				if (bOldInFire)
				{
					// Fade out
					ParticleComp->Deactivate();
				}
				else
				{
					// Let it go away, otherwise it will consume precious Draw call
					ParticleComp->UnregisterComponent();
				}
			}
			else if (ChildComp)
			{
				ChildComp->SetVisibility(false);
			}
		}

		if (P3Core::IsP3NetModeClientInstance(*this) && SmokeParticle && bOldInFire)
		{
			if (!Client_SmokeParticleComp)
			{
				Client_SmokeParticleComp = UGameplayStatics::SpawnEmitterAttached(SmokeParticle, this);
			}
			else
			{
				Client_SmokeParticleComp->Activate();
				Client_SmokeParticleTimeAgeSeconds = 0.0f;
			}
		}

		SetVisibility(false);

		OnFire.Broadcast(false);

		UnregisterParticleSystemTimeSeconds = GetWorld()->GetTimeSeconds() + SmokeParticleTimeSeconds + CVarP3FlameUnregisterParticleDelaySeconds.GetValueOnGameThread();
	}

	if (OwnerActor && P3Core::IsP3NetModeServerInstance(*OwnerActor))
	{
		Server_SetDirty(*this);
	}
}

void UP3FlammableComponent::Client_TickSmokeAge(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*GetOwner())))
	{
		return;
	}

	if (!Client_SmokeParticleComp)
	{
		return;
	}

	if (!Client_SmokeParticleComp->IsActive())
	{
		return;
	}

	if (bInFire)
	{
		Client_SmokeParticleComp->Deactivate();
		return;
	}

	Client_SmokeParticleTimeAgeSeconds += DeltaSeconds;
	if (Client_SmokeParticleTimeAgeSeconds >= SmokeParticleTimeSeconds)
	{
		Client_SmokeParticleComp->Deactivate();
	}

}

void UP3FlammableComponent::Server_Burn(float TimeSeconds, UObject* SourceObject)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*GetOwner())))
	{
		return;
	}

	if (IsInFire())
	{
		// Already in fire

		if (FireDurationSeconds != 0.0f)
		{
			UP3FlammableComponent* SourceFlammable = Cast<UP3FlammableComponent>(SourceObject);
			const bool bSourceIsSameActor = (SourceFlammable && SourceFlammable->GetOwner() == GetOwner());
			const bool bSourceOwnerIsCharacter = (SourceFlammable && SourceFlammable->GetOwner() && SourceFlammable->GetOwner()->IsA(AP3Character::StaticClass()));

			if (!bSourceIsSameActor && !bSourceOwnerIsCharacter)
			{
				// Let this fire stay longer
				Server_LeftFireDurationSeconds = FMath::Min(Server_LeftFireDurationSeconds + TimeSeconds, FireDurationSeconds);
			}
		}

		return;
	}

	// Can't be burnt during wet
	UP3WetComponent* WetComp = GetOwner()->FindComponentByClass<UP3WetComponent>();
	if (WetComp && WetComp->IsWet())
	{
		// But still, we can dry it faster
		WetComp->Server_Burn(TimeSeconds);

		return;
	}

	if (Server_FireCoolDownLeftSeconds > 0)
	{
		// Still in cooldown
		return;
	}

	if (MaxBurnAgainCount >= 0 && Server_NumBurned >= MaxBurnAgainCount)
	{
		// Max repeat number reached
		return;
	}

	SetComponentTickEnabled(true);
	
	if (bResetDurationOnNewFire)
	{
		Server_LeftFireDurationSeconds = FireDurationSeconds;
	}

	Server_LastBurnTimeSeconds = GetWorld()->GetTimeSeconds();
	Server_TimeToStartFireLeftSeconds -= TimeSeconds;

	Server_OnBurn.Broadcast();

	if (Server_TimeToStartFireLeftSeconds <= 0)
	{
		Server_TimeToStartFireLeftSeconds = TimeToStartFireSeconds;
		Server_FireCoolDownLeftSeconds = FireCoolDownSeconds;

		SetFireInternal(true);
	}
}

void UP3FlammableComponent::Server_StartFire()
{
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return;
	}

	SetFireInternal(true);
}

void UP3FlammableComponent::Server_StopFire()
{
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return;
	}

	SetFireInternal(false);
}

void UP3FlammableComponent::Server_SetLeftFireDurationSeconds(float InLeftFireDurationSeconds)
{
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return;
	}

	const float NewLeftFireDurationSeconds = FMath::Max(0.0f, InLeftFireDurationSeconds);
	Server_LeftFireDurationSeconds = NewLeftFireDurationSeconds;
}

void UP3FlammableComponent::Server_Explode()
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		ensure(0);
		return;
	}

	if (!IsInFire() || ExplodeRadius <= 0.f)
	{
		return;
	}

	AActor* OwnerActor = GetOwner();

	TArray<AActor*> OverlapActors;

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(ExplodeRadius);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(OwnerActor);

	TArray<FOverlapResult> OverlapResults;
	GetWorld()->OverlapMultiByChannel(OverlapResults, GetComponentLocation(), FQuat::Identity, ECC_FLAME, CollisionShape, QueryParams);

	TSet<AActor*> ProcessedActors;

	for (const FOverlapResult& OverlapResult : OverlapResults)
	{
		AActor* Actor = OverlapResult.Actor.Get();

		if (ProcessedActors.Contains(Actor))
		{
			continue;
		}

		UP3FlammableComponent* FlammableComp = Actor ? Actor->FindComponentByClass<UP3FlammableComponent>() : nullptr;
		if (FlammableComp)
		{
			FlammableComp->Server_Burn(ExplodePower, this);

			ProcessedActors.Add(Actor);
		}
	}

	if (ExplosionDamage != 0 && OwnerActor)
	{
		P3Combat::Server_Explode(*OwnerActor, GetComponentLocation(), ExplodeRadius, ExplosionDamage, ExplosionDamage, HitActionImpulseSpeed, bKnockDown, KnockDownDurationSeconds, Server_ExplosionIgnoreActors);
		
		//UP3BlueprintFunctionLibrary::ExplodeBP(this, GetComponentLocation(), ExplodeRadius, ExplosionDamage, HitActionImpulseSpeed, bKnockDown, KnockDownDurationSeconds, Server_ExplosionIgnoreActors);
	}
}

void UP3FlammableComponent::NetSerialize(FArchive& Archive)
{
	if (!Archive.IsLoading())
	{
		Archive << bInFire;
	}
	else
	{
		bool bNewInFire = bInFire;

		Archive << bNewInFire;

		if (bNewInFire != bInFire)
		{
			SetFireInternal(bNewInFire);
		}
	}
}
