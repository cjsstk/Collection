// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3StoreInterface.h"
#include "P3WetComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnWetChanged, bool, bIsWet);


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3WetComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:
	UP3WetComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	bool IsWet() const { return Net_bIsWet; }

	void Server_Wet();
	void Server_Dry();
	void Server_Burn(float TimeSeconds);

	UPROPERTY(BlueprintAssignable)
	FP3OnWetChanged OnWetChanged;

private:
	void Server_SetWet(bool bInWet);

	void Server_Tick(float DeltaSeconds);
	void Client_OnWetChanged();

	/**
	 * Settings
	 */

	/** Set duration for wet fades out. 0 means no fade */
	UPROPERTY(EditDefaultsOnly, Category = "Wet")
	float WetDurationSeconds = 10.0f;


	/**
	 * Status
	 */
	bool Net_bIsWet = false;

	/** Will automatically dry at this time. Only valid if WetDurationSeconds is not 0 */
	float Server_DryAtTimeSeconds = 0;
};
