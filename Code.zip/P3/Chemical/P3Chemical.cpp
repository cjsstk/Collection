// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Chemical.h"

#include "DrawDebugHelpers.h"
#include "Engine/World.h"

#include "P3FlammableComponent.h"

extern TAutoConsoleVariable<int32> CVarP3WaterDebug;

TAutoConsoleVariable<int32> CVarTemperatureDebug(
	TEXT("p3.temperatureDebug"),
	0,
	TEXT("1: debug on, 0: debug off"), ECVF_Cheat);


void P3Chemical::Server_SplashWater(const UObject& WorldContext, const FVector& Location, float Radius)
{
	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(Radius);

	FCollisionQueryParams QueryParams;

	TArray<FOverlapResult> OverlapResults;
	WorldContext.GetWorld()->OverlapMultiByChannel(OverlapResults, Location, FQuat::Identity, ECC_Pawn, CollisionShape, QueryParams);

	for (const FOverlapResult& OverlapResult : OverlapResults)
	{
		AActor* Actor = OverlapResult.Actor.Get();
		UP3FlammableComponent* FlammableComp = Actor ? Actor->FindComponentByClass<UP3FlammableComponent>() : nullptr;
		if (FlammableComp && FlammableComp->IsInFire() && FlammableComp->IsExtinguishByWater())
		{
			FlammableComp->Server_StopFire();

#if ENABLE_DRAW_DEBUG
			if (CVarP3WaterDebug.GetValueOnGameThread() > 0)
			{
				DrawDebugSphere(WorldContext.GetWorld(), FlammableComp->GetComponentLocation(), 100.0f, 16, FColor(0, 0, 255), false, 3.0f);
				DrawDebugLine(WorldContext.GetWorld(), Location, FlammableComp->GetComponentLocation(), FColor(20, 20, 255), false, 3.0f);
			}
#endif
		}
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3WaterDebug.GetValueOnGameThread() > 0)
	{
		DrawDebugSphere(WorldContext.GetWorld(), Location, Radius, 32, FColor(20, 20, 255), false, 3.0f, 0, 2.0f);
	}
#endif
}
