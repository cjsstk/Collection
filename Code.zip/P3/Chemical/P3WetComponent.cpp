// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3WetComponent.h"

#include "Components/PrimitiveComponent.h"
#include "Engine/World.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Particles/ParticleSystemComponent.h"

#include "P3ActorInterface.h"
#include "P3Core.h"
#include "P3World.h"

extern TAutoConsoleVariable<int32> CVarP3WaterDebug;


UP3WetComponent::UP3WetComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3WetComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaTime);
	}
}

void UP3WetComponent::Server_Wet()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_SetWet(true);
}

void UP3WetComponent::Server_Dry()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_SetWet(false);
}

void UP3WetComponent::Server_Burn(float TimeSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!IsWet())
	{
		return;
	}

	if (WetDurationSeconds == 0.0f)
	{
		// This is immortal
		return;
	}

	ensure(Server_DryAtTimeSeconds != 0.0f);

	Server_DryAtTimeSeconds -= TimeSeconds;
}

void UP3WetComponent::Server_SetWet(bool bInWet)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const bool bOldIsWet = Net_bIsWet;

	Net_bIsWet = bInWet;

	Server_DryAtTimeSeconds = Net_bIsWet && (WetDurationSeconds != 0.0f) ? GetWorld()->GetTimeSeconds() + WetDurationSeconds : 0;

	if (bOldIsWet != Net_bIsWet && GetOwner() && P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetDirty(*this);

		if (P3Core::IsP3NetModeClientInstance(*this))
		{
			// Just something that makes PIE easier
			Client_OnWetChanged();
		}
		else
		{
			OnWetChanged.Broadcast(Net_bIsWet);
		}
	}
}

void UP3WetComponent::Server_Tick(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_bIsWet)
	{
		// Tick fade out
		if (WetDurationSeconds > 0.0f)
		{
			if (GetWorld()->GetTimeSeconds() > Server_DryAtTimeSeconds)
			{
				Server_Dry();
			}
		}
	}

	if (CVarP3WaterDebug.GetValueOnGameThread() != 0)
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(GetOwner());
		if (P3ActorInterface)
		{
			FString DebugString = FString::Printf(TEXT("Wet(%s)"), Net_bIsWet ? TEXT("Yes") : TEXT("No"));
			if (Net_bIsWet && WetDurationSeconds > 0.0f)
			{
				DebugString += FString::Printf(TEXT("LifeTime(%.2f/%.2f)"),
					Server_DryAtTimeSeconds - GetWorld()->GetTimeSeconds(), WetDurationSeconds);
			}
			P3ActorInterface->AddDebugString(DebugString);
		}
	}
}

void UP3WetComponent::Client_OnWetChanged()
{
	AActor* OwnerActor = GetOwner();

	// Apply dynamic material

	const static FName Name_Wet(TEXT("Wet"));

	TInlineComponentArray<UPrimitiveComponent*> Components;
	OwnerActor->GetComponents(Components, true);

	for (UPrimitiveComponent* Comp : Components)
	{
		if (!Comp)
		{
			continue;
		}

		if (Comp->IsA(UParticleSystemComponent::StaticClass()))
		{
			continue;
		}

		const int32 NumMaterials = Comp->GetNumMaterials();

		for (int32 MaterialIndex = 0; MaterialIndex < NumMaterials; ++MaterialIndex)
		{
			UMaterialInstanceDynamic* DynamicMaterial = Comp->CreateDynamicMaterialInstance(MaterialIndex);
			if (DynamicMaterial)
			{
				DynamicMaterial->SetScalarParameterValue(Name_Wet, Net_bIsWet ? 1.0f : 0.0f);
			}
		}
	}

	OnWetChanged.Broadcast(Net_bIsWet);
}

void UP3WetComponent::NetSerialize(FArchive& Archive)
{
	const bool bOldIsWet = Net_bIsWet;

	Archive << Net_bIsWet;

	if (Archive.IsLoading() && P3Core::IsP3NetModeClientInstance(*this) && bOldIsWet != Net_bIsWet)
	{
		Client_OnWetChanged();
	}
}
