// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SphereComponent.h"

#include "P3StoreInterface.h"
#include "P3FlammableComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3FlammableOnBurn);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3FlammableOnFire, bool, bOnFire);


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3FlammableComponent : public USphereComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:
	UP3FlammableComponent();

	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	bool IsInFire() const { return bInFire; }

	bool IsDamageOneself() const { return SelfDamageAmount > 0.f; }
	bool IsChildComponentOverlapOnly() const { return bChildComponentOverlapOnly; }
	bool IsExtinguishByWater() const { return bExtinguishByWater; }

	/** Burn this object for given time so that it can start fire */
	void Server_Burn(float TimeSeconds, UObject* SourceObject);

	/** Set fire immediately */
	UFUNCTION(BlueprintCallable)
	void Server_StartFire();

	/** Put out fire immediately */
	UFUNCTION(BlueprintCallable)
	void Server_StopFire();

	float Server_GetLeftFireDurationSeconds() const { return Server_LeftFireDurationSeconds; }

	void Server_SetLeftFireDurationSeconds(float InLeftFireDurationSeconds);

	void Server_Explode();

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	UPROPERTY(BlueprintAssignable)
	FP3FlammableOnBurn Server_OnBurn;

	UPROPERTY(BlueprintAssignable)
	FP3FlammableOnFire OnFire;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	/** See if we are out of fuel */
	void Server_TickFiringAge(float DeltaSeconds);

	/** See if we are ready to destroy  owner actor */
	void Server_TickFireDestroyActor(float DeltaSeconds);

	/** Make more fire around, by calling Burn() */
	void Server_TickSpreading(float DeltaSeconds);

	/** Call Damage Methods every DamageTickSeconds */
	void Server_TickDamage(float DeltaSeconds);

	/** Cause HP damage around */
	void Server_DamageAround();

	/** Cause HP damage oneself */
	void Server_DamageOneself();

	void SetFireInternal(bool bNewFire);

	void Client_TickSmokeAge(float DeltaSeconds);

	/** 
	 * Settings
	 */

	/** Automatically fire at BeginPlay? */
	UPROPERTY(EditAnywhere, Category = "Fire")
	bool bStartInFire = false;

	/** If set true, child components will be used for flammable area instead of owner actor's all components */
	UPROPERTY(EditAnywhere, Category = "Fire")
	bool bChildComponentOverlapOnly = false;

	/** How long does it takes to this object start fire if it keeps touched by other fire */
	UPROPERTY(EditAnywhere, Category = "Fire|Duration")
	float TimeToStartFireSeconds = 0;

	/** How long can this object burn. 0 means forever */
	UPROPERTY(EditAnywhere, Category = "Fire|Duration")
	float FireDurationSeconds = 0;

	/** If set true, duration left will be refill on each new fire */
	UPROPERTY(EditAnywhere, Category = "Fire|Duration")
	bool bResetDurationOnNewFire = true;

	/** Set how strong this fire can spread */
	UPROPERTY(EditAnywhere, Category = "Fire|Power")
	float FirePower = 1.0f;

	/** The fire won't start during this time */
	UPROPERTY(EditAnywhere, Category = "Fire|Cooldown")
	float FireCoolDownSeconds = 0;

	/** If false, apply cooldown after burning */
	UPROPERTY(EditAnywhere, Category = "Fire|Cooldown")
	bool bCoolDownStartAtBeginning = false;

	/** How long does it takes to destroy actor by fire. 0 means do not destroy actor at all */
	UPROPERTY(EditAnywhere, Category = "Fire|Destory")
	float TimeToDestoryActorSeconds = 0;

	/** Max Count to burn again. -1 means no limit */
	UPROPERTY(EditAnywhere, Category = "Fire|Repeat")
	int32 MaxBurnAgainCount = -1;

	/** Tick delay seconds for each oneself damage */
	UPROPERTY(EditAnywhere, Category = "Fire|Self Damage", meta = (EditCondition = "bDamagedOneself"))
	float SelfDamageTickSeconds = 0.5f;

	/** Damage amount by flame for oneself */
	UPROPERTY(EditAnywhere, Category = "Fire|Self Damage", meta = (EditCondition = "bDamagedOneself"))
	int32 SelfDamageAmount = 5;

	/** Tick period seconds for nearby actors */
	UPROPERTY(EditAnywhere, Category = "Fire|Damage")
	float FlameDamageTickSeconds = 0.5f;

	/** Damage amount for nearby actors */
	UPROPERTY(EditAnywhere, Category = "Fire|Damage")
	int32 FlameDamageAmount = 0;

	/** Explosion particle (Start on Fire) */
	UPROPERTY(EditDefaultsOnly, Category = "Fire|Explosion")
	class UParticleSystem* ExplosionParticle;

	/** Explosion Radius */
	UPROPERTY(EditAnywhere, Category = "Fire|Explosion")
	float ExplodeRadius = 0.f;

	/** Spreading flame time in explosion radius */
	UPROPERTY(EditAnywhere, Category = "Fire|Explosion")
	float ExplodePower = 1.f;

	/** Explosion damage amount in explosion radius */
	UPROPERTY(EditAnywhere, Category = "Fire|Explosion")
	int32 ExplosionDamage = 0;

	UPROPERTY(EditAnywhere, Category = "Fire|Explosion")
	float HitActionImpulseSpeed = 0.0f;

	UPROPERTY(EditAnywhere, Category = "Fire|Explosion")
	bool bKnockDown = false;

	UPROPERTY(EditAnywhere, Category = "Fire|Explosion")
	float KnockDownDurationSeconds = 0.0f;

	/** Actor list that will not affected by explosion */
	UPROPERTY(Transient)
	TArray<AActor*> Server_ExplosionIgnoreActors;

	/** If set true, fire can be put out by water */
	UPROPERTY(EditAnywhere, Category = "Fire|Wet")
	bool bExtinguishByWater = true;

	/** Smoke particle (Start on Fire end) */
	UPROPERTY(EditDefaultsOnly, Category = "Fire|Smoke")
	class UParticleSystem* SmokeParticle;

	/** Smoke particle time */
	UPROPERTY(EditDefaultsOnly, Category = "Fire|Smoke")
	float SmokeParticleTimeSeconds = 5.0f;

	UPROPERTY(Transient)
	class UParticleSystemComponent* Client_SmokeParticleComp = nullptr;

	/** 
	 * Current State
	 */

	/** Is in fire? */
	bool bInFire = false;

	/** How long can this object burn more? */
	float Server_LeftFireDurationSeconds = 0;

	/** The fire won't start during this time */
	float Server_FireCoolDownLeftSeconds = 0;

	/** How long does it takes to this object start fire if it keeps touched by other fire */
	float Server_TimeToStartFireLeftSeconds = 0;

	/** When I got burn from other fire? */
	float Server_LastBurnTimeSeconds = 0;

	/** How long does it takes to destroy actor by fire */
	float Server_TimeToDestroyActorLeftSeconds = 0;

	float Server_FlameDamageTickAgeSeconds = 0;

	float Server_SelfDamageTickAgeSeconds = 0;
	
	int32 Server_NumBurned = 0;

	float Client_SmokeParticleTimeAgeSeconds = 0.0f;

	/** Timer handler for damage around tick */
	FTimerHandle Server_DamageAroundTimerHandle;

	/** 
	 * Since deactivating is not enough to remove DP, we got to unregister particle system
	 * Some time later after fire turned off
	 */
	float UnregisterParticleSystemTimeSeconds = 0;
};
