// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "P3OverlapComponent.h"
#include "P3StoreInterface.h"
#include "P3WaterComponent.generated.h"


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3WaterComponent : public UP3OverlapComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:
	UP3WaterComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	UFUNCTION(BlueprintCallable)
	int32 GetWaterLevel() const { return WaterLevel; }

protected:
	virtual void BeginPlay() override;

	virtual void Server_OverlappedActorAdded(AActor& Actor) override;
	virtual void Server_OverlappedActorRemoved(AActor& Actor) override;

private:
	void Server_TickApplyWaterEffects();
	void Server_TickWaterLifetime(float DeltaSeconds);
	void Server_OnWaterLifetimeFinished();

	void Server_ApplyWaterEffectToActor(AActor& Actor);

	/** 
	 * Settings
	 */

	/** Water level */
	UPROPERTY(EditAnywhere, Category = "Water")
	int32 WaterLevel = 1;

	/** Water will disappear after this time. 0 means forever */
	UPROPERTY(EditAnywhere, Category = "Water")
	float WaterLifetimeSeconds = 0.0f;

	/** If set true, owner actor will be destroyed after life time */
	UPROPERTY(EditAnywhere, Category = "Water")
	bool bAutoDestroyActor = false;

	/** 
	 * Current State
	 */

	/** Countdown of life time  */
	float Server_WaterLifetimeLeftSeconds = 0.0f;
};
