// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

namespace P3Chemical
{

const static float MIN_Temperature = -20.0f;
const static float MAX_Temperature = 100.0f;

void Server_SplashWater(const UObject& WorldContext, const FVector& Location, float Radius);

} // P3Chemical