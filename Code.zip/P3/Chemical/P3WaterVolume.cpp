// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3WaterVolume.h"
#include "P3WaterComponent.h"

AP3WaterVolume::AP3WaterVolume()
{
	WaterComponent = CreateDefaultSubobject<UP3WaterComponent>(TEXT("WaterComponent"));
	WaterComponent->SetMobility(EComponentMobility::Static);
}
