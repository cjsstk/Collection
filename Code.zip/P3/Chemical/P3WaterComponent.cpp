// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3WaterComponent.h"

#include "GameFramework/Actor.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "TimerManager.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "Chemical/P3FlammableComponent.h"
#include "Chemical/P3WetComponent.h"
#include "Command/P3CommandComponent.h"
#include "P3Actor.h"
#include "P3ActorInterface.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3HealthPointComponent.h"
#include "P3World.h"

TAutoConsoleVariable<int32> CVarP3WaterDebug(
	TEXT("p3.waterDebug"),
	0,
	TEXT("1: debug on, 0: debug off"), ECVF_Cheat);


UP3WaterComponent::UP3WaterComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3WaterComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (WaterLifetimeSeconds > 0.0f)
		{
			Server_WaterLifetimeLeftSeconds = WaterLifetimeSeconds;
		}
	}
}

void UP3WaterComponent::Server_OverlappedActorAdded(AActor& Actor)
{
	Super::Server_OverlappedActorAdded(Actor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_ApplyWaterEffectToActor(Actor);
}

void UP3WaterComponent::Server_OverlappedActorRemoved(AActor& Actor)
{
	Super::Server_OverlappedActorRemoved(Actor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}
}

void UP3WaterComponent::Server_TickApplyWaterEffects()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const TSet<AActor*>& OverlappedActors = Server_GetOverlappedActors();

	for (AActor* Actor : OverlappedActors)
	{
		if (Actor)
		{
			Server_ApplyWaterEffectToActor(*Actor);
		}
	}
}

void UP3WaterComponent::Server_TickWaterLifetime(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_WaterLifetimeLeftSeconds > 0)
	{
		Server_WaterLifetimeLeftSeconds -= DeltaSeconds;

		if (Server_WaterLifetimeLeftSeconds < 0)
		{
			Server_WaterLifetimeLeftSeconds = 0;

			Server_OnWaterLifetimeFinished();
		}
	}
}

void UP3WaterComponent::Server_OnWaterLifetimeFinished()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (bAutoDestroyActor)
	{
		if (GetOwner())
		{
			GetOwner()->Destroy();
		}
	}
}

void UP3WaterComponent::Server_ApplyWaterEffectToActor(AActor& Actor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	UP3FlammableComponent* FlameComp = Actor.FindComponentByClass<UP3FlammableComponent>();
	if (FlameComp && FlameComp->IsInFire() && FlameComp->IsExtinguishByWater())
	{
		FlameComp->Server_StopFire();
	}

	UP3WetComponent* WetComp = Actor.FindComponentByClass<UP3WetComponent>();
	if (WetComp)
	{
		WetComp->Server_Wet();
	}
}

void UP3WaterComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_TickWaterLifetime(DeltaTime);
		Server_TickApplyWaterEffects();
	}

	if (CVarP3WaterDebug.GetValueOnGameThread() != 0)
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(GetOwner());
		if (P3ActorInterface)
		{
			FString DebugString = FString::Printf(TEXT("WaterLevel(%d)"), WaterLevel);
			if (WaterLifetimeSeconds > 0)
			{
				DebugString += FString::Printf(TEXT("LifeTime(%.2f/%.2f)"),
					Server_WaterLifetimeLeftSeconds, WaterLifetimeSeconds);
			}
			P3ActorInterface->AddDebugString(DebugString);
		}
	}
}

void UP3WaterComponent::NetSerialize(FArchive& Archive)
{

}

