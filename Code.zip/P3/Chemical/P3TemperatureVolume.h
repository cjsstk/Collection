// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Volume.h"
#include "P3TemperatureVolume.generated.h"

/**
 * Temperature Volume
 */
UCLASS()
class P3_API AP3TemperatureVolume : public AVolume
{
	GENERATED_BODY()

	AP3TemperatureVolume();

protected:
	virtual void BeginPlay() override;
	virtual void NotifyActorBeginOverlap(AActor* OtherActor) override;
	virtual void NotifyActorEndOverlap(AActor* OtherActor) override;

private:
	static void UpdateTemperatureVolumeDebug(bool bForceUpdate);

	static bool bUpdateTemperatureVolumeDebugBound;

	/** Temperature in Celsius */
	UPROPERTY(EditAnywhere, Category = Temperature, meta=(ClampMin="-20.0", UIMin="-20.0", ClampMax="100", UIMax="100"))
	float Temperature = 20;

	/** Higher number, higher priority */
	UPROPERTY(EditAnywhere)
	int32 TemperaturePriority = 0;
};
