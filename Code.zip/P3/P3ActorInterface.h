// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "P3Core.h"
#include "P3ActorInterface.generated.h"

UINTERFACE(meta=( CannotImplementInterfaceInBlueprint ))
class UP3ActorInterface : public UInterface
{
	GENERATED_UINTERFACE_BODY()
};

class IP3ActorInterface
{
	GENERATED_IINTERFACE_BODY()

public:
	virtual actorid GetActorId() const = 0;
	virtual void SetActorId(actorid Id) = 0;

	virtual void AddGameplayTags(const struct FGameplayTagContainer& TagContainer) = 0;
	virtual void RemoveGameplayTags(const struct FGameplayTagContainer& TagContainer) = 0;
	virtual void AddDebugString(const FString& InDebugString, bool bAddNewLine = true) = 0;

	virtual void NetSerialize(FArchive& Archive) = 0;
	virtual class UP3StoreComponent* GetStoreComponent() const = 0;

	virtual bool IsLevelPersistence() const = 0;

protected:
	void RegisterToP3World(AActor& Self);

	/** Add to Server World's dirty list */
	void Server_SetDirty(AActor& Self);
};
