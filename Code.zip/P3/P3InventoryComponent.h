// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "Item/P3Item.h"
#include "P3CharacterItemSlots.h"
#include "P3HoldType.h"
#include "P3Store.h"
#include "P3StoreInterface.h"
#include "P3WeaponType.h"
#include "Widget/P3InventoryQuickSlotWidget.h"
#include "P3InventoryComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3InventoryComponentOnChangeConsumable);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3InventoryComponentOnChangeQuickSlot);

UENUM()
enum class EP3BackpackWeight : int32
{
	None,
	Light,
	Middle,
	Heavy,
};

/**
 * 캐릭터가 소유한 인벤토리 컴포넌트
 */
UCLASS()
class P3_API UP3InventoryComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3InventoryComponent();

	void Server_InitItems(const TArray<FP3CharacterItem>& Items);

	bool Server_AddItemByKeyAndCount(itemkey ItemKey, int32 Stack);
	bool Server_RemoveItemByIdAndCount(FP3ItemId ItemId, int32 Stack);

	bool Server_AddItem(const FP3Item& Item, EP3CharacterItemSlot Slot = EP3CharacterItemSlot::Inventory);
	bool Server_RemoveItem(FP3ItemId ItemId);

	/** Increase item stack count */
	bool Server_IncreaseItemStack(FP3ItemId ItemId, int32 Stack);

	/**
	 * Decrease item stack count
	 * Will be failed if existing stack is less than or EQUAL to required stack
	 * Must be checked in advance
	*/
	bool Server_DecreaseItemStack(FP3ItemId ItemId, int32 Stack);

	/** TODO: move to equipment component */
	bool Server_ChangeItemSlot(FP3ItemId ItemId, EP3CharacterItemSlot Slot);


	AActor* SpawnItemActor(FP3ItemId ItemId) const;

	FP3Item GetItem(FP3ItemId ItemId) const;
	FP3Item GetItemByKey(itemkey CmsKey) const;
	FP3Item GetItemBySlot(EP3CharacterItemSlot Slot) const;
	TArray<FP3Item> GetItemsBySlot(EP3CharacterItemSlot Slot, bool bExcludeWeapons = true) const;
	const TArray<FP3CharacterItem>& GetCharacterItems() const { return Net_CharacterItems; }
	bool HasItem(FP3ItemId ItemId) const;
	bool HasTempWeapon() const;
	int32 GetNumItemsByKey(itemkey ItemKey) const;
	bool CanAddItem(itemkey ItemKey, int32 Amount) const;

	TArray<FP3Item> GetThrowableItems(bool bOnlyQuickSlot = false) const;
	TArray<FP3Item> GetConsumableItems(bool bOnlyQuickSlot = false) const;
	bool HasConsumable(FP3ItemId ItemId) const;

	UFUNCTION(BlueprintCallable)
	bool HasHoldeable(EP3HoldType HoldType) const { return FindHoldableItem(HoldType).IsValid(); }

	FP3Item FindHoldableItem(EP3HoldType HoldType, EP3WeaponType WeaponType = EP3WeaponType::None) const;

	/**
	 * QuickSlot
	 */
	int32 GetQuickSlotNum() const { return QuickSlotNum; }
	const TArray<itemkey>& GetQuickSlotItems(EP3InventoryQuickSlotType QuickSlotType) const;
	void SetQuickSlotItem(EP3InventoryQuickSlotType QuickSlotType, int32 QuickSlotIndex, itemkey NewItemKey);

	/**
	 * Backpack
	 */
	void SetBackpackActor(class AP3Backpack* InBackpackActor);
	class AP3Backpack* GetBackpackActor() const { return MyBackpackActor; }
	EP3BackpackWeight GetBackpackWeight() const;

	bool IsCarryingBackpack() const { return MyBackpackActor ? true : false; }

	/** IP3ComponentInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	UPROPERTY()
	FP3InventoryComponentOnChangeConsumable OnChangeConsumable;

	UPROPERTY()
	FP3InventoryComponentOnChangeQuickSlot OnChangeQuickSlot;

	void SortInvenItems();

protected:
	virtual void BeginPlay() override;

private:
	uint64 GetCharacterId() const;

	/** Items (including holdable, consumable, ...) */
	TArray<FP3CharacterItem> Net_CharacterItems;

	TArray<itemkey> ThrowableQuickSlotItems;
	TArray<itemkey> ConsumableQuickSlotItems;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 QuickSlotNum = 5;

	/**
	 * Backpack
	 */
	UPROPERTY(Transient)
	class AP3Backpack* MyBackpackActor = nullptr;

	//UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	//class TSubclassOf<class AP3Backpack> BackpackActorClass;

	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 BackpackSizeNum = 40;

	// 배낭 아이템 개수의 비율이 이 수치 이상이면 '무거움' 상태가 됩니다.
	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 ItemNumPercentageForHeavy = 100;

	// 배낭 아이템 개수의 비율이 이 수치 이상이면 '중간' 상태가 됩니다. 미만은 '가벼움'입니다.
	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	int32 ItemNumPercentageForMiddle = 70;

	bool bBackpackInventoryUIOpened = false;
};
