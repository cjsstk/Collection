// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/EngineBaseTypes.h"
#include "Math/Vector2D.h"
#include "P3Core.generated.h"

/** 
 * To make things easier, we are making client to have authority on movement 
 * Which must be removed and implement input exchange with client side error correction as Unreal did
 * This define is foot print of every temporal codes with client authority
 */
#define FIXME_CHARACTER_MOVEMENT_CLIENT_AUTHORITY 0

DECLARE_STATS_GROUP(TEXT("P3"), STATGROUP_P3, STATCAT_Advanced);

using actorid = int64;
const static actorid INVALID_ACTORID = -1;

using charid = int64;
const static charid INVALID_CHARID = -1;

using partyid = uint32;
const static partyid NON_PARTY_ID = 0;

class UP3GameInstance;
class AP3GameMode;
class AP3GameState;
class UP3GameRule;
class UP3GameResource;
class AP3ContributionSystem;
class UP3World;
class UP3ServerWorld;
class UP3ClientWorld;
class UWidgetAnimation;
class UUserWidget;
class AP3PlayerController;
class AP3WorldSystem;
class UP3ItemManager;

enum class EP3NetMode
{
	Standalone,
	ListenServer,
	Client,
	DedicatedServer,
	MAX
};

template <typename T>
struct P3IdType
{
	int32 X;

	P3IdType() {}
	explicit P3IdType(int32 InX) : X(InX) {}

	bool operator == (const P3IdType& Other) const { return X == Other.X; }
	bool operator != (const P3IdType& Other) const { return X != Other.X; }
};

#define P3DefineId(IdName)							\
	struct ___##IdName { };							\
	typedef P3IdType<___##IdName> IdName;			\
	FORCEINLINE uint32 GetTypeHash(IdName Id) { return GetTypeHash(Id.X); }


/** 
 * Local control means, either I'm client and actor is my player character, or I'm server and actor is not controlled by remote player
 * (AKA, Autonomous Proxy or (Authority and remote role is not Autonomous Proxy)
 */
bool IsLocalControlledActor(class AActor* Actor);
bool IsAutonomousProxy(class AActor* Actor);
bool IsAuthority(class AActor* Actor);


/**
* Wrapper for the actor who want to be rendered with silhouette
* We need this to safely turn on/off 'render custom depth' effect for outline effect
*/
struct FP3Silhouetter
{
	FP3Silhouetter() {}
	~FP3Silhouetter();

	void Enable(bool bInEnable) { bEnable = bInEnable; }

	void SetActor(class AActor* Actor);
	class AActor* GetActor() const;

private:
	TWeakObjectPtr<class AActor> SilhouettedActor;
	bool bEnable = true;
};

namespace P3Core
{
	bool IsConnectedToDedi(const UObject* Object);

	EP3NetMode GetP3NetMode(const class AActor& Actor);
	EP3NetMode GetP3NetMode(const class UWorld& World);
	EP3NetMode GetP3NetMode(const class UWorld* World);
	bool IsP3NetModeStandalone(const class AActor& Actor);
	bool IsP3NetModeListenServer(const class AActor& Actor);
	bool IsP3NetModeDedicatedServer(const class AActor& Actor);
	bool IsP3NetModeClient(const class AActor& Actor);
	bool IsP3NetModeClientInstance(const class UObject& Object);
	bool IsP3NetModeServerInstance(const class UObject& Object);

	const TCHAR* GetNetModeStr(ENetMode Value);
	const TCHAR* GetNetModeStr(EP3NetMode Value);
	EP3NetMode GetNetModeFromStr(const TCHAR* Str);

	bool GetAllBlueprintNamesInPath(FName Path, TArray<FName>& Result, UClass* BaseClass);
	UClass* GetBlueprintClassInPath(FName Path, FName AssetName, UClass* BaseClass);

	/** UMG */
	UWidgetAnimation* GetWidgetAnimation(const UUserWidget& Widget, FName AnimName);

	/** UI */
	void Client_ToastMessageBP(const UWorld* World, const FText& Message);

	UP3GameInstance* GetP3GameInstance(const UObject& Object);
	UP3GameInstance* GetP3GameInstanceChecked(const UObject& Object);
	AP3GameMode* GetP3GameMode(const UObject& Object);
	AP3GameState* GetP3GameState(const UObject& Object);
	AP3ContributionSystem* GetContributionSystem(const UObject& Object);
	const UP3GameRule& GetGameRule(const UObject& Object);
	const UP3GameResource& GetGameResource(UObject* Object);
	UP3ItemManager* GetItemManager(const UObject& Object);
	UP3World* GetP3World(const UObject& Object);
	UP3ServerWorld* GetP3ServerWorld(const UObject& Object);
	UP3ClientWorld* GetP3ClientWorld(const UObject& Object);
	AP3WorldSystem* GetP3WorldSystem(const UObject& Object);
	AP3PlayerController* GetP3PlayerController(const UObject& Object);

	class APawn* GetLocalPawn(class UWorld* World);
	class AActor* GetP3WorldParticleActor(UObject* Object);

	/** Find Actor by name */
	AActor* FindActorByName(UWorld* World, const FString& LevelName, const FString& ActorName);

	/** Find Actor component by name */
	template<typename T>
	T* GetActorComponentByName(const AActor& Actor, const FString& ComponentName)
	{
		TInlineComponentArray<T*> Components;
		Actor.GetComponents<T>(Components);

		for (T* Component : Components)
		{
			if (Component && Component->GetName().Equals(ComponentName))
			{
				return Component;
			}
		}

		return nullptr;
	}

	/** Return overlapping actors from child components */
	void GetChildComponentOverlappingActors(const class USceneComponent* SceneComponent, TSet<AActor*>& OutOverlappingActors);

	/** Return overlapping components from child components */
	void GetChildComponentOverlappingComponents(const class USceneComponent* SceneComponent, TSet<UPrimitiveComponent*>& OutOverlappingComponents);

	/** 
	 * Return overlapping components 
	 * @param	bSearchChild	If true, overlapping components of child components are also searched
	 */
	void GetComponentOverlappingComponents(const class USceneComponent* SceneComponent, TSet<UPrimitiveComponent*>& OutOverlappingComponents, bool bSearchChild);

	/** Find first parent component by type */
	template<class ComponentType>
	ComponentType* GetParentComponentByComponentType(const class USceneComponent* SceneComponent)
	{
		if (!SceneComponent)
		{
			return nullptr;
		}

		USceneComponent* ParentComp = SceneComponent->GetAttachParent();
		while (ParentComp)
		{
			ComponentType* CastedParentComp = Cast<ComponentType>(ParentComp);
			if (CastedParentComp)
			{
				return CastedParentComp;
			}

			ParentComp = ParentComp->GetAttachParent();
		}

		return nullptr;
	}

	/** Return all the parent actors */
	template<class AllocatorType>
	void GetAttachAncestorActors(const AActor& Actor, TArray<AActor, AllocatorType>& OutActors)
	{
		USceneComponent* SceneComp = Actor.GetRootComponent();
		while ((SceneComp = SceneComp->GetAttachParent()) != nullptr)
		{
			OutActors.Add(SceneComp->GetOwner());
		}
	}

	/** Get root ancestor */
	AActor* GetAttachRootActor(AActor* Actor, bool bIncludeSelf);

	void MergeBoundingSpheres(const FVector& Center1, float Radius1, const FVector& Center2, float Radius2, FVector& OutCenter, float& OutRadius);

	/** 
	 * Returns the world space bounding sphere of all components in this Actor.
	 * @param bNonColliding Indicates that you want to include non-colliding components in the bounding sphere
	 */
	void GetActorSphereBounds(const AActor& Actor, FVector& OutCenter, float& OutRadius, bool bNonColliding = false);

	/** 두 벡터 사이의 Yaw 각도를 구함. Radian */
	float GetYawBetweenVectors(const FVector& VectorA, const FVector& VectorB);

	/** 몽타지에서 특정 시각의 본 위치를 가져옴. 메시 좌표계. Root Motion 제외. */
	FTransform ExtractMontageBoneTransformFromPosition(USkeletalMeshComponent& MeshComponent, const UAnimMontage& Montage, float Position, const FName& BoneName);

} // P3Core


template<typename T>
static void _DiffArray(const TArray<T>& Old, const TArray<T>& New, TArray<T>* Added, TArray<T>* Removed)
{
	if (Added)
	{
		*Added = New;
	}

	if (Removed)
	{
		*Removed = Old;
	}

	if (Added)
	{
		Added->RemoveAll([&Old](const T& Item)
		{
			return (Old.Find(Item) != INDEX_NONE);
		});
	}

	if (Removed)
	{
		Removed->RemoveAll([&New](const T& Item)
		{
			return (New.Find(Item) != INDEX_NONE);
		});
	}
}

template<typename T>
static void _DiffSet(const TSet<T>& Old, const TSet<T>& New, TSet<T>* Added, TSet<T>* Removed)
{
	if (Added)
	{
		*Added = New;
	}

	if (Removed)
	{
		*Removed = Old;
	}

	if (Added)
	{
		for (const T& OldItem : Old)
		{
			Added->Remove(OldItem);
		}
	}

	if (Removed)
	{
		for (const T& NewItem : New)
		{
			Removed->Remove(NewItem);
		}
	}
}

/**
 * Temporal Wrapper for P3World transition
 * If P3World is turned on, Actor id will be used for replication and UpdateIdFromPointer and UpdatePointerFromId should be called to make valid Actor pointer
 * If not, Actor pointer will be used for replication
 */
USTRUCT()
struct FP3ActorPointerAndId
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId = INVALID_ACTORID;

	//UPROPERTY()
	AActor* Actor = nullptr;

	FP3ActorPointerAndId& operator = (AActor* InActor);

	explicit operator bool() const { return (ActorId != INVALID_ACTORID || Actor != nullptr); }
	
	void UpdateIdFromPointer(const UObject& WorldContextObject);
	void UpdatePointerFromId(const UObject& WorldContextObject);

	bool IsValidIdOrReplicated() const;
	bool IsValidId() const;
};

inline bool operator == (const AActor* Actor, const FP3ActorPointerAndId& ActorPointerAndId)
{ 
	return (Actor == ActorPointerAndId.Actor); 
}
