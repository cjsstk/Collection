// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "P3FallingStepFloorActor.generated.h"

UCLASS()
class P3_API AP3FallingStepFloorActor : public AActor
{
	GENERATED_BODY()
	
public:	
	AP3FallingStepFloorActor();
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void Tick(float DeltaTime) override;
	virtual void NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;

protected:
	virtual void BeginPlay() override;

private:
	void CreateStepStaticMeshComponents();
	void CreateTrapList();

	/** Return (X, Y) of step component. Return (-1, -1) if not found */
	FIntPoint GetStepCoordFromComponent(const class UPrimitiveComponent* Comp) const;

	UPROPERTY(EditAnywhere)
	int32 NumX = 4;

	UPROPERTY(EditAnywhere)
	int32 NumY = 4;

	UPROPERTY(EditAnywhere)
	float StepMeshPadding = 5.0f;

	UPROPERTY(EditAnywhere)
	class UStaticMesh* StepStaticMesh;

	UPROPERTY()
	TMap<FIntPoint, UStaticMeshComponent*> StepStaticMeshComponents;

	UPROPERTY()
	TArray<FIntPoint> Traps;
};
