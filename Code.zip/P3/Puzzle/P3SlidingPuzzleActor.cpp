// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3SlidingPuzzleActor.h"

#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"
#include "JsonObjectConverter.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Misc/FileHelper.h"
#include "UObject/ConstructorHelpers.h"

#include "P3Core.h"
#include "P3Log.h"
#include "P3Physics.h"
#include "P3ServerWorld.h"
#include "P3World.h"

static TAutoConsoleVariable<int32> CVarP3SlidingPuzzleCoinInsertCount(
	TEXT("p3.slidingPuzzleCoinInsertCount"),
	3,
	TEXT("How many coins will be inserted on each drop?"), ECVF_Cheat);

AP3SlidingPuzzleActor::AP3SlidingPuzzleActor()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;

	USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootScene"));
	RootComponent = SceneComponent;

	static ConstructorHelpers::FObjectFinder<UStaticMesh> DefaultPieceMesh(TEXT("StaticMesh'/Engine/BasicShapes/Cube.Cube'"));
	PieceStaticMesh = DefaultPieceMesh.Object;

	SetReplicateMovement(true);
}

void AP3SlidingPuzzleActor::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	ConstructPieceStaticMeshComponents();
}

void AP3SlidingPuzzleActor::ConstructPieceStaticMeshComponents()
{
	for (auto&& Iter : PieceStaticMeshComponents)
	{
		UStaticMeshComponent* Comp = Iter.Value;

		if (Comp && !Comp->IsBeingDestroyed())
		{
			Comp->DestroyComponent();
		}
	}
	PieceStaticMeshComponents.Empty();

	if (!PieceStaticMesh)
	{
		return;
	}

	int32 PieceIndex = 0;

	for (int32 X = 0; X < NumX; ++X)
	{
		for (int32 Y = 0; Y < NumY; ++Y)
		{
			const FString StepCompName = FString::Printf(TEXT("MeshComp_%d_%d"), X, Y);
			UStaticMeshComponent* MeshComp = NewObject<UStaticMeshComponent>(this, *StepCompName);
			if (ensure(MeshComp))
			{
				const FVector Location = GetPieceLocation(FIntPoint(X, Y));

				MeshComp->RegisterComponent();
				MeshComp->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
				MeshComp->SetRelativeLocation(Location);
				MeshComp->SetStaticMesh(PieceStaticMesh);
				MeshComp->SetIsReplicated(true);
				MeshComp->SetCollisionResponseToChannel(ECC_CLIMB, ECR_Ignore);
				PieceStaticMeshComponents.Add(FIntPoint(X, Y), MeshComp);

				if (PieceMaterials.IsValidIndex(PieceIndex))
				{
					MeshComp->SetMaterial(0, PieceMaterials[PieceIndex]);
				}
				else if (TileMaterial)
				{
					MeshComp->SetMaterial(0, TileMaterial);
					UMaterialInstanceDynamic* DynamicMaterial = MeshComp->CreateAndSetMaterialInstanceDynamic(0);
					if (DynamicMaterial)
					{
						DynamicMaterial->SetScalarParameterValue(FName(TEXT("NumX")), NumX);
						DynamicMaterial->SetScalarParameterValue(FName(TEXT("NumY")), NumY);
						DynamicMaterial->SetScalarParameterValue(FName(TEXT("X")), X);
						DynamicMaterial->SetScalarParameterValue(FName(TEXT("Y")), Y);
					}
				}
			}

			++PieceIndex;
		}
	}

	PieceStaticMeshComponentsBeforeShuffle = PieceStaticMeshComponents;
}

void AP3SlidingPuzzleActor::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (!Server_LoadStatus())
		{
			PickRandomEmptyLocation();
			ShufflePieces();
			Server_SaveStatus();
		}

		for (auto&& Iter : PieceStaticMeshComponents)
		{
			UStaticMeshComponent* Comp = Iter.Value;
			if (ensure(Comp))
			{
				Comp->SetNotifyRigidBodyCollision(true);
			}
		}
	}
}

bool AP3SlidingPuzzleActor::Server_IsSlidingTriggerHit_Implementation(FIntPoint HitPieceCoord, class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) const
{
	return true;
}

void AP3SlidingPuzzleActor::PickRandomEmptyLocation()
{
	// Pick new empty location
	FIntPoint NewEmptyPiceCoord;
	NewEmptyPiceCoord.X = FMath::Rand() % NumX;
	NewEmptyPiceCoord.Y = FMath::Rand() % NumY;

	SetEmptyPieceCoord(NewEmptyPiceCoord);
}

void AP3SlidingPuzzleActor::SetEmptyPieceCoord(const FIntPoint& Coord)
{
	Net_EmptyPieceCoord = Coord;

	// Restore all
	for (auto&& Iter : PieceStaticMeshComponents)
	{
		UStaticMeshComponent* Comp = Iter.Value;
		if (ensure(Comp))
		{
			Comp->SetHiddenInGame(false);
			Comp->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		}
	}

	UStaticMeshComponent** CompPtr = PieceStaticMeshComponents.Find(Net_EmptyPieceCoord);
	if (ensure(CompPtr) && ensure(*CompPtr))
	{
		(*CompPtr)->SetHiddenInGame(true);
		(*CompPtr)->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetDirty(*this);
	}
}

void AP3SlidingPuzzleActor::ShufflePieces()
{
	if (NumX < 2 || NumY < 2)
	{
		return;
	}

	const int32 NumShuffle = (FMath::CeilToInt(NumX * NumY * ShuffleMultiplier) * 2) + 1;

	const FIntPoint SlideDirections[] = {
		FIntPoint(-1, 0),
		FIntPoint(1, 0),
		FIntPoint(0, -1),
		FIntPoint(0, 1),
	};

	int32 RetryCounter = 0;

	int32 LastDirectionIndex = -1;
	int32 ShuffleCount = 0;

	for (int32 ShuffleIndex = 0; ShuffleIndex < NumShuffle; )
	{
		int32 DirectionIndex = FMath::Rand() % ARRAY_COUNT(SlideDirections);

		// Do not revert last move
		if (LastDirectionIndex != -1 && ((LastDirectionIndex / 2) == (DirectionIndex / 2)))
		{
			continue;
		}
		LastDirectionIndex = DirectionIndex;

		const FIntPoint SlideDirection = SlideDirections[DirectionIndex];
		const FIntPoint SlideCoord = Net_EmptyPieceCoord + SlideDirection;		

		// Do not go over edge
		if (SlideCoord.X < 0 || SlideCoord.X >= NumX || SlideCoord.Y < 0 || SlideCoord.Y >= NumY)
		{
			continue;
		}
		
		const FIntPoint SourceCoord = Net_EmptyPieceCoord;
		const FIntPoint TargetCoord = SlideCoord;

		ensure(SourceCoord != TargetCoord);

		UStaticMeshComponent** SourceCompPtr = PieceStaticMeshComponents.Find(SourceCoord);
		UStaticMeshComponent** TargetCompPtr = PieceStaticMeshComponents.Find(TargetCoord);
		if (ensure(SourceCompPtr) && ensure(TargetCompPtr))
		{
			Swap(*SourceCompPtr, *TargetCompPtr);

			(*SourceCompPtr)->SetRelativeLocation(GetPieceLocation(SourceCoord));
			(*TargetCompPtr)->SetRelativeLocation(GetPieceLocation(TargetCoord));

			Net_EmptyPieceCoord = TargetCoord;
			++ShuffleCount;
		}

		if (ShuffleIndex == NumShuffle - 1)
		{
			if (RetryCounter < 10 && IsPiecesAreOnRightPlace())
			{
				// This is soomin's theory
				ensure(ShuffleCount % 2 == 0);

				// Damn... God of random just fooled us
				++RetryCounter;
				ShuffleIndex = 0;
			}
		}

		++ShuffleIndex;
	}
}

FVector AP3SlidingPuzzleActor::GetPieceLocation(const FIntPoint& Coord) const
{
	if (!ensure(PieceStaticMesh))
	{
		return FVector::ZeroVector;
	}

	const FBox MeshBoundingBox = PieceStaticMesh->GetBoundingBox();
	const float MeshSizeX = MeshBoundingBox.GetExtent().X * 2.0f;
	const float MeshSizeY = MeshBoundingBox.GetExtent().Y * 2.0f;

	FVector Out;
	Out.X = (MeshSizeX + PieceMeshPadding) * Coord.X;
	Out.Y = (MeshSizeY + PieceMeshPadding) * Coord.Y;
	Out.Z = 0;

	return Out;
}

void AP3SlidingPuzzleActor::Server_StartSliding(const FIntPoint& SlidingPieceCoord)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Server_bEnableSliding)
	{
		return;
	}

	if (Server_CurrentSlidingAction.bActive)
	{
		ensure(0);
		return;
	}

	const FIntPoint DistanceToEmpty = Net_EmptyPieceCoord - SlidingPieceCoord;
	if (!ensure(DistanceToEmpty.SizeSquared() == 1))
	{
		// Empty spot must be neighbored
		return;
	}

	Server_SetDirty(*this);

	Server_CurrentSlidingAction.bActive = true;
	Server_CurrentSlidingAction.SlidingProgress = 0;
	Server_CurrentSlidingAction.StartCoord = SlidingPieceCoord;
	Server_CurrentSlidingAction.EndCoord = Net_EmptyPieceCoord;

	SetActorTickEnabled(true);
	
	UStaticMeshComponent** Comp = PieceStaticMeshComponents.Find(SlidingPieceCoord);
	OnStartSliding.Broadcast(Comp ? *Comp : nullptr);
}

void AP3SlidingPuzzleActor::FinishSliding()
{
	UStaticMeshComponent* StartComp = nullptr;
	UStaticMeshComponent* EndComp = nullptr;

	{
		UStaticMeshComponent** StartCompPtr = PieceStaticMeshComponents.Find(Server_CurrentSlidingAction.StartCoord);
		UStaticMeshComponent** EndCompPtr = PieceStaticMeshComponents.Find(Server_CurrentSlidingAction.EndCoord);
		if (!ensure(StartCompPtr) || !ensure(EndCompPtr))
		{
			return;
		}

		StartComp = *StartCompPtr;
		EndComp = *EndCompPtr;
	}

	const FVector StartLocation = GetPieceLocation(Server_CurrentSlidingAction.StartCoord);
	const FVector EndLocation = GetPieceLocation(Server_CurrentSlidingAction.EndCoord);

	if (ensure(StartComp))
	{
		StartComp->SetRelativeLocation(EndLocation);
		PieceStaticMeshComponents[Server_CurrentSlidingAction.EndCoord] = StartComp;
	}

	if (ensure(EndComp))
	{
		EndComp->SetRelativeLocation(StartLocation);
		PieceStaticMeshComponents[Server_CurrentSlidingAction.StartCoord] = EndComp;
	}

	ensure(Net_EmptyPieceCoord == Server_CurrentSlidingAction.EndCoord);
	Net_EmptyPieceCoord = Server_CurrentSlidingAction.StartCoord;

	Server_CurrentSlidingAction.bActive = false;
	Server_CurrentSlidingAction.SlidingProgress = 0;
	Server_CurrentSlidingAction.StartCoord = FIntPoint(0, 0);
	Server_CurrentSlidingAction.EndCoord = FIntPoint(0, 0);

	SetActorTickEnabled(false);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SaveStatus();
	}

	const bool bFinished = IsPiecesAreOnRightPlace();

	if (bFinished)
	{
		Finished();
	}
}

bool AP3SlidingPuzzleActor::IsPiecesAreOnRightPlace() const
{
	if (PieceStaticMeshComponents.OrderIndependentCompareEqual(PieceStaticMeshComponentsBeforeShuffle))
	{
		return true;
	}

	return false;
}

void AP3SlidingPuzzleActor::Finished()
{
	UStaticMeshComponent** LastPiecePtr = PieceStaticMeshComponents.Find(Net_EmptyPieceCoord);
	UStaticMeshComponent* LastPieceComp = nullptr;
	if (ensure(LastPiecePtr) && ensure(*LastPiecePtr))
	{
		LastPieceComp = *LastPiecePtr;
		LastPieceComp->SetHiddenInGame(false);
		LastPieceComp->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	}

	Server_bFinishedFuzzle = true;

	OnFinished.Broadcast(LastPieceComp);
}

FString AP3SlidingPuzzleActor::GetSaveFilePath() const
{
	return FPaths::ProjectSavedDir()
		/ FString("P3SlidingPuzzle")
		/ UGameplayStatics::GetCurrentLevelName(this)
		/ FString::Printf(TEXT("%s.json"), *GetName());
}

bool AP3SlidingPuzzleActor::Server_LoadStatus()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	FString FilePath = GetSaveFilePath();

	FString JsonString;
	if (!FFileHelper::LoadFileToString(JsonString, *FilePath))
	{
		return false;
	}

	P3JsonLog(Display, "Load P3SlidingPuzzle", TEXT("FilePath"), *FilePath);

	FP3SlidingPuzzleSaveData SaveData;
	if (!ensure(FJsonObjectConverter::JsonObjectStringToUStruct(JsonString, &SaveData, 0, 0)))
	{
		P3JsonLog(Display, "Failed to convert json to object", TEXT("FilePath"), *FilePath);
		return false;
	}

	if (SaveData.Movements.Num() != PieceStaticMeshComponents.Num())
	{
		P3JsonLog(Display, "Number of components are not match", TEXT("FilePath"), *FilePath);
		return false;
	}

	TMap<FIntPoint, UStaticMeshComponent*> NewPieceStaticMeshComponents;

	for (const FP3SlidingPuzzleSaveDataMovement& Movement : SaveData.Movements)
	{
		UStaticMeshComponent** OriginalCompPtr = PieceStaticMeshComponents.Find(Movement.OriginalLocation);
		if (ensure(OriginalCompPtr && *OriginalCompPtr))
		{
			(*OriginalCompPtr)->SetRelativeLocation(GetPieceLocation(Movement.CurrentLocation));
			NewPieceStaticMeshComponents.Add(Movement.CurrentLocation, *OriginalCompPtr);
		}
	}

	PieceStaticMeshComponents = MoveTemp(NewPieceStaticMeshComponents);

	SetEmptyPieceCoord(SaveData.EmptyPieceCoord);

	return true;
}

void AP3SlidingPuzzleActor::Server_SaveStatus() const
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	FP3SlidingPuzzleSaveData SaveData;
	SaveData.EmptyPieceCoord = Net_EmptyPieceCoord;

	for (auto&& Iter : PieceStaticMeshComponentsBeforeShuffle)
	{
		FP3SlidingPuzzleSaveDataMovement Movement;
		Movement.OriginalLocation = Iter.Key;
		Movement.CurrentLocation = GetPieceCoordFromComponent(Iter.Value);

		if (!ensure(Movement.CurrentLocation != FIntPoint(-1, -1)))
		{
			return;
		}

		SaveData.Movements.Add(Movement);
	}

	FString JsonString;
	if (!ensure(FJsonObjectConverter::UStructToJsonObjectString(SaveData, JsonString)))
	{
		return;
	}

	ensure(FFileHelper::SaveStringToFile(JsonString, *GetSaveFilePath(), FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM));
}

FIntPoint AP3SlidingPuzzleActor::GetPieceCoordFromComponent(const class UPrimitiveComponent* Comp) const
{
	for (auto&& Iter : PieceStaticMeshComponents)
	{
		if (Iter.Value == Comp)
		{
			return Iter.Key;
		}
	}

	return FIntPoint(-1, -1);
}

void AP3SlidingPuzzleActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	ensure(P3Core::IsP3NetModeServerInstance(*this));
	if (ensure(Server_CurrentSlidingAction.bActive))
	{
		if (SlidingTimeSeconds < SMALL_NUMBER)
		{
			FinishSliding();
		}
		else
		{
			Server_CurrentSlidingAction.SlidingProgress += DeltaTime / SlidingTimeSeconds;
			if (Server_CurrentSlidingAction.SlidingProgress > 1.0f)
			{
				FinishSliding();
			}
			else
			{
				UStaticMeshComponent** CompPtr = PieceStaticMeshComponents.Find(Server_CurrentSlidingAction.StartCoord);
				if (ensure(CompPtr) && ensure(*CompPtr))
				{
					const FVector StartLocation = GetPieceLocation(Server_CurrentSlidingAction.StartCoord);
					const FVector EndLocation = GetPieceLocation(Server_CurrentSlidingAction.EndCoord);
					const FVector CurrentLocation = FMath::Lerp(StartLocation, EndLocation, Server_CurrentSlidingAction.SlidingProgress);

					(*CompPtr)->SetRelativeLocation(CurrentLocation);
				}
			}
		}
	}
}

void AP3SlidingPuzzleActor::NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (Server_CurrentSlidingAction.bActive)
	{
		return;
	}

	if (Server_bFinishedFuzzle)
	{
		return;
	}

	const FIntPoint HitPieceCoord = GetPieceCoordFromComponent(MyComp);

	const bool bValidTriggerHit = Server_IsSlidingTriggerHit(HitPieceCoord, MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);

	if (!bValidTriggerHit)
	{
		return;
	}

	const FIntPoint DistanceToEmpty = Net_EmptyPieceCoord - HitPieceCoord;
	if (DistanceToEmpty.SizeSquared() == 1)
	{
		Server_StartSliding(HitPieceCoord);
	}
}

void AP3SlidingPuzzleActor::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);
	
	if (Archive.IsLoading())
	{
		Archive << Net_EmptyPieceCoord;
		
		SetEmptyPieceCoord(Net_EmptyPieceCoord);
	}
	else
	{
		// Since client doesn't shuffle, we need to convert to original coord
		FIntPoint EmptyPieceOriginalCoord = Net_EmptyPieceCoord;

		UStaticMeshComponent** EmptyPieceComp = PieceStaticMeshComponents.Find(Net_EmptyPieceCoord);

		if (ensure(EmptyPieceComp))
		{
			const FIntPoint* Coord = PieceStaticMeshComponentsBeforeShuffle.FindKey(*EmptyPieceComp);
			if (ensure(Coord))
			{
				EmptyPieceOriginalCoord = *Coord;
			}
		}

		Archive << EmptyPieceOriginalCoord;
	}
}

void AP3SlidingPuzzleActor::Server_RestartPuzzle()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_bFinishedFuzzle = false;
	Server_CurrentSlidingAction.bActive = false;

	PickRandomEmptyLocation();
	ShufflePieces();

	for (auto&& Iter : PieceStaticMeshComponents)
	{
		UStaticMeshComponent* Comp = Iter.Value;
		if (ensure(Comp))
		{
			Comp->SetNotifyRigidBodyCollision(true);
		}
	}
}

void AP3SlidingPuzzleCoinBox::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this) && SlidingPuzzleActor)
	{
		SlidingPuzzleActor->OnStartSliding.AddUniqueDynamic(this, &AP3SlidingPuzzleCoinBox::Server_OnStartSliding);

		Server_SetCurrentCoin(NumDefaultCoin);
	}
}

void AP3SlidingPuzzleCoinBox::Server_OnStartSliding(UStaticMeshComponent* PieceComponent)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_SetCurrentCoin(Net_NumCurrentCoins - 1);
}

void AP3SlidingPuzzleCoinBox::Server_SetCurrentCoin(int32 NewCoins)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const int32 OldCoins = Net_NumCurrentCoins;
	
	Net_NumCurrentCoins = FMath::Clamp(NewCoins, 0, NumMaxCoin);

	if (SlidingPuzzleActor)
	{
		if (Net_NumCurrentCoins == 0)
		{
			SlidingPuzzleActor->Server_EnableSliding(false);
		}
		else
		{
			SlidingPuzzleActor->Server_EnableSliding(true);
		}
	}

	if (Net_NumCurrentCoins != OldCoins)
	{
		RecvCoinChanged(OldCoins, Net_NumCurrentCoins);
	}

	Server_SetDirty(*this);
}

void AP3SlidingPuzzleCoinBox::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	if (Archive.IsLoading())
	{
		const int32 OldCoins = Net_NumCurrentCoins;

		Archive << Net_NumCurrentCoins;

		if (Net_NumCurrentCoins != OldCoins)
		{
			RecvCoinChanged(OldCoins, Net_NumCurrentCoins);
		}
	}
	else
	{
		Archive << Net_NumCurrentCoins;
	}

}

void AP3SlidingPuzzleCoinBox::Server_AddCoins(int32 NumCoins)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_SetCurrentCoin(Net_NumCurrentCoins + NumCoins);
}

void AP3SlidingPuzzleCoinInserter::Server_OnSignal(bool bOn)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (CoinBoxActor)
	{
		CoinBoxActor->Server_AddCoins(CVarP3SlidingPuzzleCoinInsertCount.GetValueOnGameThread());
	}
}
