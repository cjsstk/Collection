// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3FallingStepFloorActor.h"

#include "Components/StaticMeshComponent.h"
#include "Engine/StaticMesh.h"

AP3FallingStepFloorActor::AP3FallingStepFloorActor()
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootScene"));
	RootComponent = SceneComponent;
}

void AP3FallingStepFloorActor::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);

	CreateStepStaticMeshComponents();
	CreateTrapList();
}

void AP3FallingStepFloorActor::BeginPlay()
{
	Super::BeginPlay();
	
}

void AP3FallingStepFloorActor::CreateStepStaticMeshComponents()
{
	for (auto&& Iter : StepStaticMeshComponents)
	{
		UStaticMeshComponent* Comp = Iter.Value;

		if (Comp && !Comp->IsBeingDestroyed())
		{
			Comp->DestroyComponent();
		}
	}
	StepStaticMeshComponents.Empty();

	if (!StepStaticMesh)
	{
		return;
	}

	const FBox StepMeshBoundingBox = StepStaticMesh->GetBoundingBox();
	const float StepMeshSizeX = StepMeshBoundingBox.GetExtent().X * 2.0f;
	const float StepMeshSizeY = StepMeshBoundingBox.GetExtent().Y * 2.0f;

	for (int32 X = 0; X < NumX; ++X)
	{
		for (int32 Y = 0; Y < NumY; ++Y)
		{
			const FString StepCompName = FString::Printf(TEXT("StepMeshComp_%d_%d"), X, Y);
			UStaticMeshComponent* MeshComp = NewObject<UStaticMeshComponent>(this, *StepCompName);
			if (ensure(MeshComp))
			{
				FVector Location((StepMeshSizeX + StepMeshPadding) * X, (StepMeshSizeY + StepMeshPadding) * Y, 0);

				MeshComp->RegisterComponent();
				MeshComp->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
				MeshComp->SetRelativeLocation(Location);
				MeshComp->SetStaticMesh(StepStaticMesh);
				MeshComp->SetNotifyRigidBodyCollision(true);
				StepStaticMeshComponents.Add(FIntPoint(X, Y), MeshComp);
			}
		}
	}
}

void AP3FallingStepFloorActor::CreateTrapList()
{
	Traps.Empty();

	for (int32 X = 0; X < NumX; ++X)
	{
		const int32 NumTargetTraps = NumY / 2;
		int32 NumTraps = 0;

		while (NumTraps < NumTargetTraps)
		{
			const int32 RandY = FMath::Rand() % NumY;
			if (!Traps.Contains(FIntPoint(X, RandY)))
			{
				Traps.Add(FIntPoint(X, RandY));
				++NumTraps;
			}
		}
	}

	//for (const FIntPoint& Coord : Traps)
	//{
	//	UStaticMeshComponent** Comp = StepStaticMeshComponents.Find(Coord);

	//	if (Comp && *Comp)
	//	{
	//		(*Comp)->SetSimulatePhysics(true);
	//		(*Comp)->PutAllRigidBodiesToSleep();
	//	}
	//}
}

FIntPoint AP3FallingStepFloorActor::GetStepCoordFromComponent(const class UPrimitiveComponent* Comp) const
{
	for (auto&& Iter : StepStaticMeshComponents)
	{
		if (Iter.Value == Comp)
		{
			return Iter.Key;
		}
	}

	return FIntPoint(-1, -1);
}

void AP3FallingStepFloorActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AP3FallingStepFloorActor::NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);

	const FIntPoint StepCoord = GetStepCoordFromComponent(MyComp);

	if (StepCoord != FIntPoint(-1, -1))
	{
		if (Traps.Contains(StepCoord))
		{
			// It's a trap!
			MyComp->SetSimulatePhysics(true);
		}
	}
}
