// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3SignalReceiver.h"
#include "P3SlidingPuzzleActor.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3SlidingPuzzleFinished, UStaticMeshComponent*, LastPieceComponent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3SlidingPuzzleStartSliding, UStaticMeshComponent*, PieceComponent);

struct FP3SlidingPuzzleSlidingAction
{
	bool bActive = false;

	/** 0 ~ 1 */
	float SlidingProgress = 0;

	FIntPoint StartCoord = FIntPoint(0, 0);
	FIntPoint EndCoord = FIntPoint(0, 0);
};

UCLASS()
class P3_API AP3SlidingPuzzleActor : public AP3Actor
{
	GENERATED_BODY()
	
public:	
	AP3SlidingPuzzleActor();

	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void Tick(float DeltaTime) override;
	virtual void NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;

	virtual void NetSerialize(FArchive& Archive) override;

	UFUNCTION(BlueprintCallable)
	void Server_RestartPuzzle();

	UFUNCTION(BlueprintCallable)
	void Server_EnableSliding(bool bEnable) { Server_bEnableSliding = bEnable; }

	UFUNCTION(BlueprintCallable)
	bool Server_IsSlidingEnabled() { return Server_bEnableSliding; }

	UFUNCTION(BlueprintCallable)
	bool Server_IsFinished() const { return Server_bFinishedFuzzle; }

	UPROPERTY(BlueprintAssignable)
	FP3SlidingPuzzleFinished OnFinished;

	FP3SlidingPuzzleStartSliding OnStartSliding;

protected:
	virtual void BeginPlay() override;

	UFUNCTION(BlueprintNativeEvent)
	bool Server_IsSlidingTriggerHit(FIntPoint HitPieceCoord, class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) const;
	virtual bool Server_IsSlidingTriggerHit_Implementation(FIntPoint HitPieceCoord, class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) const;


private:
	void ConstructPieceStaticMeshComponents();
	void ShufflePieces();
	void PickRandomEmptyLocation();
	void SetEmptyPieceCoord(const FIntPoint& Coord);

	/** Return (X, Y) of piece component. Return (-1, -1) if not found */
	FIntPoint GetPieceCoordFromComponent(const class UPrimitiveComponent* Comp) const;
	FVector GetPieceLocation(const FIntPoint& Coord) const;

	void Server_StartSliding(const FIntPoint& SlidingPieceCoord);
	void FinishSliding();

	FString GetSaveFilePath() const;
	bool Server_LoadStatus();
	void Server_SaveStatus() const;

	bool IsPiecesAreOnRightPlace() const;
	void Finished();

	void TickDissolveIn(float DeltaSeconds);

	UPROPERTY(EditAnywhere)
	int32 NumX = 3;

	UPROPERTY(EditAnywhere)
	int32 NumY = 3;

	/** We shuffle NumX * NumY * Multipier * 2 + 1 times. Odd number is lucky charm to avoid not-shuffled-result */
	UPROPERTY(EditAnywhere)
	float ShuffleMultiplier = 2.0f;

	UPROPERTY(EditAnywhere)
	float PieceMeshPadding = 5.0f;

	/** Each sliding will takes this time */
	UPROPERTY(EditAnywhere)
	float SlidingTimeSeconds = 5.0f;

	/** How many sliding is available? -1 means infinite */
	UPROPERTY(EditAnywhere)
	int32 NumSlidingAvailable = -1;

	/** How many sliding is available? -1 means infinite */
	UPROPERTY(EditAnywhere)
	int32 NumMaxSlidingAvailable = -1;

	UPROPERTY(EditAnywhere)
	class UStaticMesh* PieceStaticMesh;

	UPROPERTY(EditAnywhere)
	class UMaterialInterface* TileMaterial;

	UPROPERTY(EditAnywhere)
	TArray<UMaterialInterface*> PieceMaterials;

	UPROPERTY()
	TMap<FIntPoint, UStaticMeshComponent*> PieceStaticMeshComponents;

	/** This is the right answer */
	UPROPERTY()
	TMap<FIntPoint, UStaticMeshComponent*> PieceStaticMeshComponentsBeforeShuffle;

	UPROPERTY()
	FIntPoint Net_EmptyPieceCoord = FIntPoint(0, 0);

	FP3SlidingPuzzleSlidingAction Server_CurrentSlidingAction;

	bool Server_bEnableSliding = true;
	bool Server_bFinishedFuzzle = false;
};


UCLASS()
class P3_API AP3SlidingPuzzleCoinBox : public AP3Actor
{
public:
	GENERATED_BODY()

	virtual void NetSerialize(FArchive& Archive) override;

	UFUNCTION(BlueprintCallable)
	void Server_AddCoins(int32 NumCoins);

protected:
	virtual void BeginPlay() override;

	UFUNCTION(BlueprintImplementableEvent)
	void RecvCoinChanged(int32 OldCoins, int32 NewCoins);

private:
	UFUNCTION()
	void Server_OnStartSliding(UStaticMeshComponent* PieceComponent);

	void Server_SetCurrentCoin(int32 NewCoins);


	UPROPERTY(EditInstanceOnly)
	AP3SlidingPuzzleActor* SlidingPuzzleActor;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	int32 NumMaxCoin = 5;

	UPROPERTY(EditAnywhere)
	int32 NumDefaultCoin = 5;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	int32 Net_NumCurrentCoins = -1;
};


UCLASS()
class P3_API AP3SlidingPuzzleCoinInserter : public AP3SignalReceiver
{
public:
	GENERATED_BODY()

protected:
	virtual void Server_OnSignal(bool bOn) override;

private:
	UPROPERTY(EditInstanceOnly)
	AP3SlidingPuzzleCoinBox* CoinBoxActor;
};


USTRUCT()
struct FP3SlidingPuzzleSaveDataMovement
{
	GENERATED_BODY()

	UPROPERTY()
	FIntPoint OriginalLocation;

	UPROPERTY()
	FIntPoint CurrentLocation;
};

USTRUCT()
struct FP3SlidingPuzzleSaveData
{
	GENERATED_BODY()

	UPROPERTY()
	FIntPoint EmptyPieceCoord;

	UPROPERTY()
	TArray<FP3SlidingPuzzleSaveDataMovement> Movements;
};
