// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTDecorator.h"
#include "P3CharacterStance.h"
#include "Action/P3PawnAction.h"
#include "P3BTDeco.generated.h"


UENUM()
namespace EP3ArithmeticKeyOperation
{
	enum Type
	{
		Equal			UMETA(DisplayName = "Is Equal To"),
		NotEqual		UMETA(DisplayName = "Is Not Equal To"),
		Less			UMETA(DisplayName = "Is Less Than"),
		LessOrEqual		UMETA(DisplayName = "Is Less Than Or Equal To"),
		Greater			UMETA(DisplayName = "Is Greater Than"),
		GreaterOrEqual	UMETA(DisplayName = "Is Greater Than Or Equal To"),
	};
}


/**
 * Is Dead
 */
UCLASS()
class P3_API UP3BTDeco_IsDead : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsDead();
	
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};

/**
 * Is Downed
 */
UCLASS()
class P3_API UP3BTDeco_IsDowned : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsDowned();
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** Target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;
};


/**
 * Is Knock downed
 */
UCLASS()
class P3_API UP3BTDeco_IsKnockDowned : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsKnockDowned();
	
    virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

    /** Target character */
    UPROPERTY(EditAnywhere, Category = Blackboard)
    struct FBlackboardKeySelector BBKey_TargetCharacter;
};


/**
* Is Exhausted
*/
UCLASS()
class P3_API UP3BTDeco_IsExhausted : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsExhausted();
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** Target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;
};


/**
 * Is Flamed
 */
UCLASS()
class P3_API UP3BTDeco_IsFlamed : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsFlamed();

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};


/**
 * Is Wet
 */
UCLASS()
class P3_API UP3BTDeco_IsWet : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsWet();

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};


/**
 * Is Stance
 */
UCLASS()
class P3_API UP3BTDeco_IsStance : public UBTDecorator
{
	GENERATED_BODY()

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	/** Stance */
	UPROPERTY(Category = Node, EditAnywhere)
	EP3CharacterStance Stance = EP3CharacterStance::Idle;
};


/**
 * Is Alert
 */
UCLASS()
class P3_API UP3BTDeco_IsInAlert : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsInAlert();

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};


/**
 * Is other AI attacking target
 */
UCLASS()
class P3_API UP3BTDeco_IsOtherAIAttackingTarget : public UBTDecorator
{
	GENERATED_BODY()
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	/** Target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/** Search range */
	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 500;
};

/**
 * Is target in attack range
 */
UCLASS()
class P3_API UP3BTDeco_IsTargetInAttackRange : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsTargetInAttackRange();
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** Target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/** Skill index */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_SkillIndex;

	/** Add to attack range during compare  */
	UPROPERTY(Category = Node, EditAnywhere)
	float RangeAddition = 0;
};

/**
 * Is target in attack range
 */
UCLASS()
class P3_API UP3BTDeco_IsMainTarget : public UBTDecorator
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:

	/** Source Character */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_SourceCharacter;

	/** Target Character */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetCharacter;
};

/**
 * Is action in progress
 */
UCLASS()
class P3_API UP3BTDeco_IsActionInProgress : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsActionInProgress();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** Target Character */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetCharacter;

	/** Action type. Set invalid to check any action */
	UPROPERTY(EditAnywhere)
	EPawnActionType ActionType = EPawnActionType::Invalid;
};

/**
 * Can Use Skill
 */
UCLASS()
class P3_API UP3BTDeco_CanUseSkill : public UBTDecorator
{
	GENERATED_BODY()

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

private:
	UPROPERTY(EditAnywhere)
	int32 SkillIndex = 0;
};

/**
 * Has Rider
 */
UCLASS()
class P3_API UP3BTDeco_HasRider : public UBTDecorator
{
	GENERATED_BODY()

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;
	virtual FString GetStaticDescription() const override;

private:
	/** these mount point will be checked */
	UPROPERTY(EditAnywhere)
	TArray<int32> MountPointsIndex;

	/** If riders in MountPointsIndex is more than this value, return true */
	UPROPERTY(EditAnywhere)
	int32 ShouldHaveRidersNum = 0;
};

/**
 * Has Hostile in Cone
 * check aggro table and see if we have any target on given direction and distance
 */
UCLASS()
class P3_API UP3BTDeco_HasHostileInCone : public UBTDecorator
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

private:
	UPROPERTY(EditAnywhere)
	FVector LocalConeDirection = FVector(1, 0, 0);

	UPROPERTY(EditAnywhere)
	float ConeHalfAngle = 10.0f;

	UPROPERTY(EditAnywhere)
	float MinDistance = 0;

	UPROPERTY(EditAnywhere)
	float MaxDistance = 200.0f;

	float ConeHalfAngleDot = 1.0f;
};

/**
 * Distance within Range
 * see if distance to given actor is within range
 */
UCLASS()
class P3_API UP3BTDeco_DistanceWithinRange : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_DistanceWithinRange();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

private:
	/** Source pawn or vector
	*   Default: Owner pawn location
	*/
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_Source;

	/** Target actor or vector */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_Target;

	/** If set -1, min will not be checked */
	UPROPERTY(EditAnywhere)
	float MinRange = -1;

	/** If set -1, max will not be checked */
	UPROPERTY(EditAnywhere)
	float MaxRange = -1;

	/** If set true, Min/Max Range will be multiplied by owner actor's scale */
	UPROPERTY(EditAnywhere)
	bool MultiplyMyScale = false;
};

/**
 * Percentage of healthPoint
 */
UCLASS()
class P3_API UP3BTDeco_PercentageOfHealthPoint : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_PercentageOfHealthPoint();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = P3)
	TEnumAsByte<EP3ArithmeticKeyOperation::Type> Query;

	/** Target Character */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetCharacter;

	/** Health Point Percentage*/
	UPROPERTY(EditAnywhere, Category = P3)
	int HealthPointPercentage = 0;
};

/**
 * Percentage of Stamina Point
 */
UCLASS()
class P3_API UP3BTDeco_PercentageOfStaminaPoint : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_PercentageOfStaminaPoint();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = P3)
	TEnumAsByte<EP3ArithmeticKeyOperation::Type> Query;

	/** Target Character */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetCharacter;

	/** Stamina Point Percentage*/
	UPROPERTY(EditAnywhere, Category = P3)
	int StaminaPointPercentage = 0;
};

/**
 * Cone Check
 */
UCLASS()
class P3_API UP3BTDeco_ConeCheck2DEx : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_ConeCheck2DEx();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;

protected:
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;
	bool CalculateDirection(const UBlackboardComponent* BlackboardComp, const FBlackboardKeySelector& Origin, const FBlackboardKeySelector& End, FVector& Direction) const;
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

private:
	/** Angle between cone direction and code cone edge, or a half of the total cone angle */
	UPROPERTY(EditAnywhere, Category=Decorator)
	float ConeHalfAngle = 45.0f;
	
	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	FBlackboardKeySelector ConeOrigin;

	/** "None" means "use ConeOrigin's direction" */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	FBlackboardKeySelector ConeDirection;

	/** Cone Direction Offset */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	int32 ConeDirectionOffset = 0;

	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	FBlackboardKeySelector Observed;

	float ConeHalfAngleDot = 0.0f;
};

/**
 * Has Attach Parent
 */
UCLASS()
class P3_API UP3BTDeco_HasAttachParent : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_HasAttachParent();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** Nearest Weapon Actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_NearestWeapon;
};

/**
 * Has Weapon
 */
UCLASS()
class P3_API UP3BTDeco_HasWeapon : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_HasWeapon();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** Hold Type */
	UPROPERTY(EditAnywhere, Category = P3)
	EP3HoldType HoldType = EP3HoldType::RightHand;

	UPROPERTY(EditAnywhere, Category = P3, meta = (InlineEditConditionToggle))
	bool bChooseWeaponType = false;

	/** 체크할 무기 종류를 고릅니다. */
	UPROPERTY(EditAnywhere, Category = P3, meta=(EditCondition="bChooseWeaponType"))
	EP3WeaponType WeaponType = EP3WeaponType::None;

	UPROPERTY(EditAnywhere, Category = P3, meta = (InlineEditConditionToggle))
	bool bChooseItemKey = false;

	/** Item key를 입력하여 정확히 어떤 아이템을 찾을 것인지 설정합니다. */
	UPROPERTY(EditAnywhere, Category = P3, meta = (EditCondition = "bChooseItemKey"))
	int32 ItemKey = INVALID_ITEMKEY;

	/** Target Character */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetCharacter;
};


/**
 * Random percentage from custom numerator of denominator
 */
UCLASS()
class P3_API UP3BTDeco_RandomPercentage : public UBTDecorator
{
	GENERATED_BODY()

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	/** The Percentage */
	UPROPERTY(Category = Percentage, EditAnywhere, meta=(UIMin = 0, ClampMin = 0, DisplayName="Numerator"))
	int32 Percentage_Numerator  = 0;

	UPROPERTY(Category = Percentage, EditAnywhere, meta=(UIMin = 1, ClampMin = 1, DisplayName="Denominator"))
	int32 Percentage_Denominator = 100;
};

/**
 * Random percentage from custom numerator of denominator
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTDeco_IsValidRouteSpotIndex : public UBTDecorator
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteActor;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_SpotIndex;
};

/**
 * Provoke Level
 */
UCLASS()
class P3_API UP3BTDeco_ProvokeLevel : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_ProvokeLevel();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = P3)
	TEnumAsByte<EP3ArithmeticKeyOperation::Type> Query;

	/** Provoke Level */
	UPROPERTY(EditAnywhere, Category = P3)
	int ProvokeLevel = 0;
};

/**
 * Temptation Level
 */
UCLASS()
class P3_API UP3BTDeco_IsInForbiddenVolume: public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsInForbiddenVolume();

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};

/**
 * Is the number of hits over threshold?
 */
UCLASS()
class P3_API UP3BTDeco_IsOverHit : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsOverHit();

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};

/**
 * the number of Player Character who is doing the action type.
 */
UCLASS()
class P3_API UP3BTDeco_ActionCount: public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_ActionCount();

	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** Search range */
	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 500;

	/** Action type. Set invalid to check any action */
	UPROPERTY(EditAnywhere, Category=P3)
	EPawnActionType ActionType = EPawnActionType::Invalid;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = P3)
	TEnumAsByte<EP3ArithmeticKeyOperation::Type> ActionCount_Query;

	/** Number of Downed PC */
	UPROPERTY(EditAnywhere, Category = P3, meta=(UIMin = 0, ClampMin = 0))
	int32 ActionCount = 0;
};

/**
 * The number of actors around target (calculate except target)
 */
UCLASS()
class P3_API UP3BTDeco_CharacterCount : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_CharacterCount();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

private:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetCharacter;

	/** If set -1, min will not be checked */
	UPROPERTY(EditAnywhere)
	float SearchRange = -1;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = P3)
	TEnumAsByte<EP3ArithmeticKeyOperation::Type> ActorCount_Query;

	UPROPERTY(EditAnywhere, Category = P3, meta=(UIMin = 0, ClampMin = 0))
	int32 SearchedCharacterCount = 0;

	/** If true, search actors include allies of behavior tree owner */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bSearchIncludeMyAllies = false;

	/** If true, search actors include behavior tree owner */
	UPROPERTY(EditAnywhere, Category = P3, meta=(EditCondition="bSearchIncludeMyAllies"))
	bool bSearchIncludeMe = false;
};

/**
 * Raycasting test
 * Return true if something hits
 */
UCLASS()
class P3_API UP3BTDeco_RayTest : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_RayTest();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

private:
	/** blackboard for source actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_SourceActor;

	/** Ray casting distance */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	float Distance = 1000;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	TEnumAsByte<ECollisionChannel> TraceChannel = ECC_Visibility;
};

/**
 * Route Spot에 지정된 Montage가 EP3RouteSpotAction::None으로 설정돼있거나, Montage를 찾을 수 없으면 false를 return 합니다.
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTDeco_IsValidRouteSpotMontageAction : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsValidRouteSpotMontageAction();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteSpotActor;
};

/**
 * Route Spot에 지정된 Emote를 Character Emote Data Set에서 찾을 수 없으면 false를 return 합니다.
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTDeco_IsValidRouteSpotEmote : public UBTDecorator
{
	GENERATED_BODY()

	UP3BTDeco_IsValidRouteSpotEmote();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteSpotActor;
};
