// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "P3BTTask_FindSpot.generated.h"

/**
 * Find P3 Spot
 */
UCLASS()
class P3_API UP3BTTask_FindSpot : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_Spot;

	/** 0 means infinity */
	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 0.0f;

	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer RequiredGameplayTagsAny;

	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer IgnoredGameplayTagsAny;
};
