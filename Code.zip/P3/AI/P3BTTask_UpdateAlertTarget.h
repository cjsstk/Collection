// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"

#include "P3BTTask_UpdateAlertTarget.generated.h"

/**
 * Update Alert Target
 */
UCLASS()
class P3_API UP3BTTask_UpdateAlertTarget : public UBTTaskNode
{
	GENERATED_BODY()
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
protected:
	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 1200.0f;

	UPROPERTY(Category = Node, EditAnywhere)
	float SearchHalfHeight = 1200.0f;

	UPROPERTY(Category = Node, EditAnywhere)
	bool bSearchFrontOnly = false;

	UPROPERTY(Category = Node, EditAnywhere)
	float WaitTimeSecondsBeforeAttack = 5.0f;

	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_AlertTargetActor;

	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_AlertStartTimeSeconds;
};
