// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_SetVectorVariable.h"

#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Vector.h"
#include "DrawDebugHelpers.h"

extern TAutoConsoleVariable<int32> CVarP3AIDebug;

void UP3BTTask_SetVectorVariable::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_SourceActorOrLocation.ResolveSelectedKey(*BBAsset);
		BBKey_TargetLocation.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_SetVectorVariable::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	FVector SourceLocation = FVector::ZeroVector;

	if (BBKey_SourceActorOrLocation.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		const AActor* SourceActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_SourceActorOrLocation.GetSelectedKeyID()));

		if (!SourceActor)
		{
			return EBTNodeResult::Failed;
		}

		SourceLocation = SourceActor->GetActorLocation();
	}
	else if (BBKey_SourceActorOrLocation.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass())
	{
		SourceLocation = MyBlackboard->GetValue<UBlackboardKeyType_Vector>(BBKey_SourceActorOrLocation.GetSelectedKeyID());
	}
	else
	{
		ensure(false);
		return EBTNodeResult::Failed;
	}

	if (!ensure(BBKey_TargetLocation.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass()))
	{
		return EBTNodeResult::Failed;
	}

	if (CVarP3AIDebug.GetValueOnGameThread() > 0)
	{
		DrawDebugSphere(GetWorld(), SourceLocation, 100.0f, 16, FColor::Green, true, 0.5f);
	}

	//GEngine->AddOnScreenDebugMessage(-1, 15.0f, FColor::Red, FString::Printf(TEXT("UP3BTTask_SetVectorVariable")));

	MyBlackboard->SetValue<UBlackboardKeyType_Vector>(BBKey_TargetLocation.GetSelectedKeyID(), SourceLocation);

	return EBTNodeResult::Succeeded;
}
