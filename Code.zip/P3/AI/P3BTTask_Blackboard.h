// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "P3BTTask_Blackboard.generated.h"

/**
 * Clear Blackboard variable
 */
UCLASS()
class P3_API UP3BTTask_ClearVariable : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_TargetLocation;
};

/**
 * Increase Blackboard variable
 */
UCLASS()
class P3_API UP3BTTask_AddToVariable : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere)
	float Add = 1.0f;

	UPROPERTY(EditAnywhere)
	struct FBlackboardKeySelector BBKey_Value;
};
