// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Spot.h"

#include "Engine/World.h"
#include "Components/ArrowComponent.h"
#include "Components/BillboardComponent.h"
#include "Components/SphereComponent.h"
#include "DrawDebugHelpers.h"

#if WITH_EDITORONLY_DATA
#include "UObject/ConstructorHelpers.h"
#endif

#include "P3Log.h"

static TAutoConsoleVariable<int32> CVarP3SpotBehaviorDebug(
    TEXT("p3.spotBehaviorDebug"),
    0,
    TEXT("1: enable debug. 0: disable debug. Show Character Montage and Emote in each spot."), ECVF_Cheat);

AP3Spot::AP3Spot()
{
	bNetLoadOnClient = false;
	PrimaryActorTick.bCanEverTick = false;
#if ENABLE_DRAW_DEBUG
	PrimaryActorTick.bCanEverTick = true;
#endif

	USceneComponent* SphereComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	RootComponent = SphereComponent;

#if WITH_EDITORONLY_DATA
	EditorSprite = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorSprite"));

	if (!IsRunningCommandlet())
	{
		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> SpriteTextureObject;
			FConstructorStatics()
				: SpriteTextureObject(TEXT("/Engine/EditorResources/S_Pickup"))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (EditorSprite)
		{
			EditorSprite->Sprite = ConstructorStatics.SpriteTextureObject.Get();
			EditorSprite->RelativeScale3D = FVector(1.0f);
			EditorSprite->bHiddenInGame = true;
			EditorSprite->SetupAttachment(RootComponent);
			EditorSprite->bAbsoluteScale = true;
			EditorSprite->bIsScreenSizeScaled = true;
		}
	}
#endif // WITH_EDITORONLY_DATA
}

void AP3Spot::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

#if ENABLE_DRAW_DEBUG
	if (CVarP3SpotBehaviorDebug.GetValueOnGameThread() != 0)
	{
		// Spot 위치를 짚어줍니다
		DrawDebugLine(GetWorld(), GetActorLocation(), GetActorLocation() + FVector(0, 0, 100), FColor::Red, false, -1.0f, (uint8)'\000', 20.0f);

		AddDebugString(FString::Printf(TEXT("Use Action?: %s"), DoUseMontageAction() ? TEXT("True (Use Action)") : TEXT("False (Use Emote)")));
		AddDebugString(FString::Printf(TEXT("Action Name Setting: %s"), *(GetMontageActionName().ToString())));
		AddDebugString(FString::Printf(TEXT("Emote Name Setting: %s"), *(GetEmoteName().ToString())));
	}
#endif
}
