// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask.h"

#include "AIController.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Int.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Float.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Engine/World.h"
#include "VisualLogger.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "AI/P3AIController.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3AggroComponent.h"
#include "P3Character.h"
#include "P3CharacterMovementComponent.h"
#include "P3CharacterStore.h"
#include "P3CombatComponent.h"
#include "P3HealthPointComponent.h"
#include "P3HolderComponent.h"
#include "P3Log.h"
#include "P3PickupComponent.h"
#include "P3ServerWorld.h"
#include "P3Weapon.h"


EBTNodeResult::Type UP3BTTask_Action::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	if (ActionType == EPawnActionType::Invalid)
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return EBTNodeResult::Failed;
	}

	if (ActionComp->IsActionInProgress(ActionType))
	{
		return EBTNodeResult::Succeeded;
	}

	const int32 RequestId = ActionComp->StartAction(ActionType, _FUNCTION_TEXT);
	const bool bSuccess = (RequestId != 0);

	return EBTNodeResult::Succeeded;
}

UP3BTTask_WaitForNoAction::UP3BTTask_WaitForNoAction()
{
	bNotifyTick = true;
}

EBTNodeResult::Type UP3BTTask_WaitForNoAction::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Succeeded;
	}

	if (!ensure(Character->GetActionComponent()))
	{
		return EBTNodeResult::Succeeded;
	}

	if (Character->GetActionComponent()->GetActiveActionType() == EPawnActionType::Invalid)
	{
		return EBTNodeResult::Succeeded;
	}

	return EBTNodeResult::InProgress;
}

void UP3BTTask_WaitForNoAction::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;

	if (!ensure(ActionComp))
	{
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
		return;
	}

	if (ActionComp->GetActiveActionType() == EPawnActionType::Invalid)
	{
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
		return;
	}
}

void UP3BTTask_GetAggroTopActor::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_GetAggroTopActor::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AAIController* AIController = OwnerComp.GetAIOwner();
		APawn* Pawn = AIController->GetPawn();
		UP3AggroComponent* AggroComp = Pawn ? Pawn->FindComponentByClass<UP3AggroComponent>() : nullptr;

		if (!ensure(AggroComp))
		{
			P3JsonLog(Warning, "Get aggro top actor BTTask is used but no Aggro Component found", TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));

			return EBTNodeResult::Failed;
		}

		AActor* AggroTopActor = AggroComp->GetTopActor();

		MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID(), AggroTopActor);
	}

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_ConsiderSkill::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_OutSkillIndex.ResolveSelectedKey(*BBAsset);
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_ConsiderSkill::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard
		|| BBKey_OutSkillIndex.SelectedKeyType != UBlackboardKeyType_Int::StaticClass()
		|| BBKey_TargetActor.SelectedKeyType != UBlackboardKeyType_Object::StaticClass())
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();

	if (!ensure(CombatComp))
	{
		P3JsonLog(Warning, "Consider Skill Failed. No combat component", TEXT("Character"), Character->GetName());
		return EBTNodeResult::Failed;
	}

	TArray<int32, TInlineAllocator<16>> AvailableSkills;

	const TArray<FP3CombatSkill>& Skills = CombatComp->GetSkills();
	for (int32 Index = 0; Index < Skills.Num(); ++Index)
	{
		if (CombatComp->Server_CanUseSkill(Index))
		{
			AvailableSkills.Add(Index);
		}
	}

	int32 ReadySkillIndex = -1;

	if (AvailableSkills.Num() > 0)
	{
		ReadySkillIndex = AvailableSkills[FMath::Rand() % AvailableSkills.Num()];
	}

	if (ReadySkillIndex >= 0)
	{
		const FP3CmsCombatSkill* CmsCombatSkill = Skills[ReadySkillIndex].CmsCombatSkill;
		if (!ensure(CmsCombatSkill))
		{
			return EBTNodeResult::Failed;
		}

		switch (CmsCombatSkill->Target)
		{
		case EP3CombatSkillTarget::Current:
			// Do not change current target
			break;

		case EP3CombatSkillTarget::FarthestInAggroList:
			ChangeTargetFarthestInAggroList(*MyBlackboard, *Character);
			break;

		default:
			ensureMsgf(false, TEXT("Invalid comat skill type %d"), (int32)CmsCombatSkill->Target);
		}
	}

	MyBlackboard->SetValue<UBlackboardKeyType_Int>(BBKey_OutSkillIndex.GetSelectedKeyID(), ReadySkillIndex);

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_ConsiderSkill::ChangeTargetFarthestInAggroList(UBlackboardComponent& MyBlackboard, const AP3Character& Character)
{
	const UP3AggroComponent* AggroComp = Character.GetAggroComponentBP();

	if (!AggroComp)
	{
		return;
	}

	TArray<AActor*> Actors = AggroComp->GetAllActors();
	FVector CharacterLocation = Character.GetActorLocation();

	float MinDistanceSquared = 0.0f;
	AActor* NewTargetActor = nullptr;

	for (AActor* Actor : Actors)
	{
		const float DistanceSquared = (Actor->GetActorLocation() - CharacterLocation).SizeSquared();

		if (DistanceSquared >= MinDistanceSquared)
		{
			MinDistanceSquared = DistanceSquared;
			NewTargetActor = Actor;
		}
	}

	if (NewTargetActor)
	{
		MyBlackboard.SetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID(), NewTargetActor);
	}
}

void UP3BTTask_SelectRandomBuckSkill::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_OutSkillIndex.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_SelectRandomBuckSkill::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard || BBKey_OutSkillIndex.SelectedKeyType != UBlackboardKeyType_Int::StaticClass())
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3CombatComponent* CombatComponent = Character ? Character->GetP3CombatComponentBP() : nullptr;

	if (!CombatComponent)
	{
		return EBTNodeResult::Failed;
	}

	TArray<int32> BuckSkills;

	// Get all buck skills from mount point which has rider on it
	const int32 NumMountPoints = Character->GetMountPoints().Num();
	for (int32 MountPointIndex = 0; MountPointIndex < NumMountPoints; ++MountPointIndex)
	{
		if (Character->HasRiderOnMountPoint(MountPointIndex))
		{
			for (int32 SkillIndex : Character->GetMountPoints()[MountPointIndex].BuckingSkills)
			{
				BuckSkills.AddUnique(SkillIndex);
			}
		}
	}

	// Remove invalid skills
	for (auto&& Iter = BuckSkills.CreateIterator(); Iter; ++Iter)
	{
		if (!CombatComponent->Server_CanUseSkill(*Iter))
		{
			Iter.RemoveCurrent();
		}
	}

	if (BuckSkills.Num() == 0)
	{
		return EBTNodeResult::Failed;
	}

	// Select random skill
	const int32 BuckSkillIndex = BuckSkills[FMath::Rand() % BuckSkills.Num()];

	MyBlackboard->SetValue<UBlackboardKeyType_Int>(BBKey_OutSkillIndex.GetSelectedKeyID(), BuckSkillIndex);

	return EBTNodeResult::Succeeded;
}

EBTNodeResult::Type UP3BTTask_ChangeStance::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	if (!Character || !Character->GetCommandComponent())
	{
		P3JsonLog(Error, "Failed change stance task. No character or command component");
		return EBTNodeResult::Failed;
	}
	
	FP3CommandRequestParams Params;
	Params.ChangeStance_NewStance = Stance;

	Character->GetCommandComponent()->RequestCommand(UP3ChangeStanceCommand::StaticClass(), Params);

	return EBTNodeResult::Succeeded;
}

EBTNodeResult::Type UP3BTTask_ToggleSprint::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	if (!Character || !Character->GetP3CharacterMovementBP())
	{
		P3JsonLog(Error, "Failed toggle sprint task. No character or movement component");
		return EBTNodeResult::Failed;
	}

	Character->GetP3CharacterMovementBP()->SetSprint(bSprint);

	return EBTNodeResult::Succeeded;
}

EBTNodeResult::Type UP3BTTask_MontageAction::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	if (MontageActionName.IsNone())
	{
		return EBTNodeResult::Failed;
	}

	FP3PawnActionStartRequestParams Params;
	Params.CharacterMontage_Name = MontageActionName;

	EBTNodeResult::Type Result = StartAction(OwnerComp, NodeMemory, EPawnActionType::CharacterMontage, Params);

	return Result;
}

UP3BTTask_ActionBase::UP3BTTask_ActionBase()
{
	bNotifyTick = true;
}

EBTNodeResult::Type UP3BTTask_ActionBase::StartAction(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EPawnActionType ActionType, const struct FP3PawnActionStartRequestParams& Params)
{
	FBTActionBaseMemory* MyMemory = (FBTActionBaseMemory*)NodeMemory;
	if (!ensure(MyMemory))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return EBTNodeResult::Failed;
	}

	MyMemory->RequestedActionId = ActionComp->StartAction(ActionType, _FUNCTION_TEXT, Params);

	if (MyMemory->RequestedActionId == 0)
	{
		return EBTNodeResult::Failed;
	}

	WaitForMessage(OwnerComp, UP3PawnActionComponent::AIMessage_ActionStartFailed, MyMemory->RequestedActionId);
	WaitForMessage(OwnerComp, UP3PawnActionComponent::AIMessage_ActionFinished, MyMemory->RequestedActionId);
	WaitForMessage(OwnerComp, UP3PawnActionComponent::AIMessage_ChainedActionRequested, MyMemory->RequestedActionId);

	return EBTNodeResult::InProgress;
}

void UP3BTTask_ActionBase::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);
}

EBTNodeResult::Type UP3BTTask_ActionBase::AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::AbortTask(OwnerComp, NodeMemory);

	FBTActionBaseMemory* MyMemory = (FBTActionBaseMemory*)NodeMemory;

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;

	if (MyMemory->RequestedActionId != 0 && ActionComp)
	{
		Character->GetActionComponent()->Server_StopActionByRequestId(MyMemory->RequestedActionId);
	}

	return EBTNodeResult::Aborted;
}

uint16 UP3BTTask_ActionBase::GetInstanceMemorySize() const
{
	return sizeof(FBTActionBaseMemory);
}

void UP3BTTask_ActionBase::OnMessage(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, FName Message, int32 RequestID, bool bSuccess)
{
	FBTActionBaseMemory* MyMemory = (FBTActionBaseMemory*)NodeMemory;

	if (Message == UP3PawnActionComponent::AIMessage_ActionStartFailed)
	{
		MyMemory->RequestedActionId = 0;
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
	}
	else if (Message == UP3PawnActionComponent::AIMessage_ActionFinished)
	{
		MyMemory->RequestedActionId = 0;
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
	}
	else if (Message == UP3PawnActionComponent::AIMessage_ChainedActionRequested)
	{
		AAIController* AIController = OwnerComp.GetAIOwner();
		AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
		if (!ensure(Character))
		{
			FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
			return;
		}

		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		if (!ensure(ActionComp))
		{
			FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
			return;
		}

		const TArray<int32>& ChainedActionRequestIds = ActionComp->GetChainedActionRequestIds();

		if (ChainedActionRequestIds.Contains(MyMemory->RequestedActionId))
		{
			StopWaitingForMessages(OwnerComp);

			MyMemory->RequestedActionId = ChainedActionRequestIds.Last();

			WaitForMessage(OwnerComp, UP3PawnActionComponent::AIMessage_ActionStartFailed, MyMemory->RequestedActionId);
			WaitForMessage(OwnerComp, UP3PawnActionComponent::AIMessage_ActionFinished, MyMemory->RequestedActionId);
			WaitForMessage(OwnerComp, UP3PawnActionComponent::AIMessage_ChainedActionRequested, MyMemory->RequestedActionId);

			// Super::OnMessage will finish this task, so don't call it
			return;
		}
	}

	Super::OnMessage(OwnerComp, NodeMemory, Message, RequestID, bSuccess);
}

EBTNodeResult::Type UP3BTTask_DropHoldable::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!Character || !Character->GetCommandComponent())
	{
		P3JsonLog(Error, "Failed change stance task. No character or command component");
		return EBTNodeResult::Failed;
	}

	FP3CommandRequestParams Params;
	Params.DropHoldable_HoldType = HoldType;

	Character->GetCommandComponent()->RequestCommand(UP3DropHoldableCommand::StaticClass(), Params);

	return EBTNodeResult::Succeeded;
}

EBTNodeResult::Type UP3BTTask_SetAlert::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	AP3AIController* P3AIController = Character ? Cast<AP3AIController>(Character->GetController()): nullptr;
	if (P3AIController)
	{
		P3AIController->SetInAlert(bInAlert);
	}

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_SetAlertAround::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_AlertActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_SetAlertAround::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = AIController->GetPawn();
	if (!MyPawn)
	{
		return EBTNodeResult::Failed;
	}

	FCollisionShape Sphere;
	Sphere.SetSphere(AlertRange);

	FCollisionQueryParams QueryParams;
	FCollisionObjectQueryParams ObjectQueryParams(ECC_Pawn);

	TArray<FOverlapResult> OverlapResults;
	GetWorld()->OverlapMultiByObjectType(OverlapResults, MyPawn->GetActorLocation(), FQuat::Identity, ObjectQueryParams, Sphere, QueryParams);

	for (const FOverlapResult& Result : OverlapResults)
	{
		APawn* Pawn = Cast<APawn>(Result.GetActor());
		if (!Pawn)
		{
			continue;
		}

		// See if gameplaytag is required
		if (IncludedGameplayTagsAny.Num() > 0 || ExcludedGameplaytagsAny.Num() > 0)
		{
			IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(Pawn);
			if (GameplayTagAsset)
			{
				const bool bHasRequiredTags = (IncludedGameplayTagsAny.Num() == 0)
					|| GameplayTagAsset->HasAnyMatchingGameplayTags(IncludedGameplayTagsAny);

				if (!bHasRequiredTags)
				{
					continue;
				}

				const bool bHasDisableTags = (ExcludedGameplaytagsAny.Num() != 0)
					&& GameplayTagAsset->HasAnyMatchingGameplayTags(ExcludedGameplaytagsAny);

				if (bHasDisableTags)
				{
					continue;
				}
			}
		}

		AP3AIController* P3AIController = Cast<AP3AIController>(Pawn->GetController());
		UBlackboardComponent* BlackboardComp = P3AIController ? P3AIController->GetBrainComponent()->GetBlackboardComponent() : nullptr;
		AActor* CurrentAlertActor = BlackboardComp ? (Cast<AActor>(BlackboardComp->GetValue<UBlackboardKeyType_Object>(BBKey_AlertActor.GetSelectedKeyID()))) : nullptr;

		// Set the initiator to the Alert Actor
		if (BlackboardComp && !(Pawn == MyPawn) 
							&& !(P3AIController->IsInAlert()) 
							&& !(CurrentAlertActor))
		{
			BlackboardComp->SetValue<UBlackboardKeyType_Object>(BBKey_AlertActor.GetSelectedKeyID(), MyPawn);
			P3AIController->SetInAlert(true);
		}
	}

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_AddGameplayTag::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_AddGameplayTag::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

		if (!TargetActor)
		{
			return EBTNodeResult::Failed;
		}

		AP3Character* TargetCharacter = Cast<AP3Character>(TargetActor);
		if (TargetCharacter)
		{
			if (TargetCharacter->IsDead())
			{
				// Target dead
				return EBTNodeResult::Failed;
			}
		}

		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(TargetActor);

		if (!P3ActorInterface)
		{
			return EBTNodeResult::Failed;
		}

		P3ActorInterface->AddGameplayTags(GameplayTags);

		return EBTNodeResult::Succeeded;

	}
	else
	{
		return EBTNodeResult::Failed;
	}

	return EBTNodeResult::Failed;
	
}

EBTNodeResult::Type UP3BTTask_Suicide::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!Character)
	{
		return EBTNodeResult::Failed;
	}

	UP3CommandComponent* CommandComp = Character->GetCommandComponent();
	if (!CommandComp)
	{
		return EBTNodeResult::Failed;
	}

	UP3HealthPointComponent* HealthComp = Character->GetP3HealthComponentBP();
	if (HealthComp)
	{
		FP3CommandRequestParams DamageParams;
		DamageParams.ApplyDamage_SourceActor = Character->GetOwner();
		DamageParams.ApplyDamage_DamageAmount = HealthComp->GetMaxHealthPoint();
		DamageParams.ApplyDamage_Reason = EP3HealthChangeReason::Suicide;
		CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), DamageParams);
	}

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_RemoveGameplayTag::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_RemoveGameplayTag::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

		if (!TargetActor)
		{
			return EBTNodeResult::Failed;
		}

		AP3Character* TargetCharacter = Cast<AP3Character>(TargetActor);
		if (TargetCharacter)
		{
			if (TargetCharacter->IsDead())
			{
				// Target dead
				return EBTNodeResult::Failed;
			}
		}

		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(TargetActor);

		if (!P3ActorInterface)
		{
			return EBTNodeResult::Failed;
		}

		P3ActorInterface->RemoveGameplayTags(GameplayTags);

		return EBTNodeResult::Succeeded;

	}
	else
	{
		return EBTNodeResult::Failed;
	}

	return EBTNodeResult::Failed;
}

EBTNodeResult::Type UP3BTTask_SetCrippled::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	if (!Character || !Character->GetP3CharacterMovementBP())
	{
		P3JsonLog(Error, "Failed toggle sprint task. No character or movement component");
		return EBTNodeResult::Failed;
	}

	Character->GetP3CharacterMovementBP()->SetCrippled(bCrippled);

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_FindHoldable::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_NearestWeaponActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_FindHoldable::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{	
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = AIController ? Cast<AP3Character>(AIController->GetCharacter()) : nullptr;
	if (!MyCharacter)
	{
		return EBTNodeResult::Failed;
	}

	// If the character already has any weapon on the holder, Do not this BTTask.
	UP3HolderComponent* HolderComponent = MyCharacter->GetHolderComponentByHoldType(HoldType);
	if (HolderComponent->GetHoldingActor())
	{
		P3JsonLog(Warning, "The Character already has weapon on the holder", TEXT("Character"), MyCharacter->GetName(), TEXT("Holder Type"), EnumToString(EP3HoldType, HoldType));

		return EBTNodeResult::Failed;
	}

	AActor* NearestWeapon = nullptr;
	float MinimumDistanceWeaponToMe = SearchRange;

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(SearchRange);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(MyCharacter);

	TArray<FOverlapResult> OverlapResults;
	GetWorld()->OverlapMultiByChannel(OverlapResults, MyCharacter->GetActorLocation(), MyCharacter->GetActorQuat(), ECC_WorldDynamic, CollisionShape, QueryParams);

	for (const FOverlapResult& Result : OverlapResults)
	{
		AP3Weapon* Weapon = (Result.GetActor()) ? Cast<AP3Weapon>(Result.GetActor()) : nullptr;
		if (!Weapon)
		{
			continue;
		}

		if (Weapon->IsActorBeingDestroyed())
		{
			continue;
		}

		// Skip Result if the weapon doesn't contain the hold type.
		if (!Weapon->IsContainingHoldType(HoldType))
		{
			continue;
		}

		// Skip Result if the weapon type is not what the character want.
		if (Weapon->GetWeaponType() != WeaponType)
		{
			continue;
		}

		// Skip Result if someone has the weapon.
		if (Weapon->GetAttachParentActor())
		{
			continue;
		}

		// See if gameplaytag is required
		if (IncludedGameplayTagsAny.Num() > 0 || ExcludedGameplaytagsAny.Num() > 0)
		{
			IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(Weapon);
			if (GameplayTagAsset)
			{
				const bool bHasRequiredTags = (IncludedGameplayTagsAny.Num() == 0)
					|| GameplayTagAsset->HasAnyMatchingGameplayTags(IncludedGameplayTagsAny);

				if (!bHasRequiredTags)
				{
					continue;
				}

				const bool bHasDisableTags = (ExcludedGameplaytagsAny.Num() != 0)
					&& GameplayTagAsset->HasAnyMatchingGameplayTags(ExcludedGameplaytagsAny);

				if (bHasDisableTags)
				{
					continue;
				}
			}
		}

		const float NewDistanceWeaponToMe = (Weapon->GetActorLocation() - MyCharacter->GetActorLocation()).Size();

		// Find nearest weapon
		if (NewDistanceWeaponToMe < MinimumDistanceWeaponToMe)
		{
			NearestWeapon = Weapon;
			MinimumDistanceWeaponToMe = NewDistanceWeaponToMe;
		}
	}

	AP3AIController* P3AIController = Cast<AP3AIController>(MyCharacter->GetController());
	UBlackboardComponent* BlackboardComp = P3AIController ? P3AIController->GetBrainComponent()->GetBlackboardComponent() : nullptr;

	// Set the nearest weapon in blackboard key
	if (NearestWeapon && BlackboardComp)
	{
		BlackboardComp->SetValue<UBlackboardKeyType_Object>(BBKey_NearestWeaponActor.GetSelectedKeyID(), NearestWeapon);
		return EBTNodeResult::Succeeded;
	}

	return EBTNodeResult::Failed;
}

UP3BTTask_PickUpHoldable::UP3BTTask_PickUpHoldable()
{
	bNotifyTick = true;
}

void UP3BTTask_PickUpHoldable::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_NearestWeaponActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_PickUpHoldable::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = Cast<AP3Character>(AIController->GetCharacter());
	AP3AIController* P3AIController = Cast<AP3AIController>(MyCharacter->GetController());
	UBlackboardComponent* BlackboardComp = P3AIController ? P3AIController->GetBrainComponent()->GetBlackboardComponent() : nullptr;
	AActor* WeaponActor = BlackboardComp ? (Cast<AActor>(BlackboardComp->GetValue<UBlackboardKeyType_Object>(BBKey_NearestWeaponActor.GetSelectedKeyID()))) : nullptr;
	if (!WeaponActor)
	{
		return EBTNodeResult::Failed;
	}

	FP3PawnActionStartRequestParams Params;
	Params.PickupHoldable_ObjectActor = WeaponActor;
	Params.PickupHoldable_HolderType = HoldType;

	EBTNodeResult::Type Result = StartAction(OwnerComp, NodeMemory, EPawnActionType::PickupHoldable, Params);

	return Result;
}

EBTNodeResult::Type UP3BTTask_ChangeMaterialValue::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!Character || !Character->GetCommandComponent())
	{
		P3JsonLog(Error, "Failed change material task.");
		return EBTNodeResult::Failed;
	}

	FP3CommandRequestParams Params;
	Params.ParameterName = ParameterName;
	Params.ParameterFloat = ParameterFloat;

	Character->GetCommandComponent()->RequestCommand(UP3SetParameterValueOnMaterialCommand::StaticClass(), Params);

	return EBTNodeResult::Succeeded;
}

EBTNodeResult::Type UP3BTTask_PrintDebugMessage::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	APawn* Pawn = AIController ? AIController->GetPawn() : nullptr;
	FString Name = Pawn ? Pawn->GetName() : "Unknown";
	FString FullMessage = FString::Printf(TEXT("%s: %s"), *Name, *Message);
	GEngine->AddOnScreenDebugMessage(Key, TimeToDisplayInSeconds, DisplayColor, FullMessage);
	P3JsonLog(Display, "BTTask_PrintDebugMessage", TEXT("Message"), *FullMessage);

	return EBTNodeResult::Succeeded;
}

EBTNodeResult::Type UP3BTTask_MoveToEx::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	if (SetSprint != EP3WalkPostureType::WalkPosture_Default)
	{
		AAIController* MyController = OwnerComp.GetAIOwner();
		AP3Character* Character = MyController ? Cast<AP3Character>(MyController->GetPawn()) : nullptr;

		if (Character && Character->GetP3CharacterMovementBP())
		{
			WasSprintBeforeTask = Character->GetP3CharacterMovementBP()->GetSprintingPressed();
			Character->GetP3CharacterMovementBP()->SetSprint(EnumToBoolForSettingWalkPosture(SetSprint));
		}
		else
		{
			P3JsonLog(Error, "Failed toggle sprint. No character or movement component");
		}
	}

	if (SetCrippled != EP3WalkPostureType::WalkPosture_Default)
	{
		AAIController* MyController = OwnerComp.GetAIOwner();
		AP3Character* Character = MyController ? Cast<AP3Character>(MyController->GetPawn()) : nullptr;

		if (Character && Character->GetP3CharacterMovementBP() && Character->GetCommandComponent())
		{
			WasCrippledBeforeTask = Character->GetP3CharacterMovementBP()->IsCrippled();

			FP3CommandRequestParams Params;
			Params.SetCrippled_bCrippled = EnumToBoolForSettingWalkPosture(SetCrippled);

			Character->GetCommandComponent()->RequestCommand(UP3SetCrippledCommand::StaticClass(), Params);
		}
		else
		{
			P3JsonLog(Error, "Failed toggle cirppled run. No character or cor command component");
		}
	}

	if (SetMeleeAiming != EP3WalkPostureType::WalkPosture_Default)
	{
		AAIController* MyController = OwnerComp.GetAIOwner();
		AP3Character* Character = MyController ? Cast<AP3Character>(MyController->GetPawn()) : nullptr;

		if (Character && Character->GetCommandComponent())
		{
			WasMeleeAimingBeforeTask = (Character->GetCharacterStoreBP()).bIsMeleeAiming;

			FP3CommandRequestParams Params;
			Params.SetMeleeAiming_bNewAiming = EnumToBoolForSettingWalkPosture(SetMeleeAiming);

			Character->GetCommandComponent()->RequestCommand(UP3SetMeleeAimingCommand::StaticClass(), Params);
		}
		else
		{
			P3JsonLog(Error, "Failed toggle melee aiming. No character or command component");
		}
	}

	return Super::ExecuteTask(OwnerComp, NodeMemory);
}

void UP3BTTask_MoveToEx::OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult)
{
	if (SetSprint != EP3WalkPostureType::WalkPosture_Default)
	{
		AAIController* MyController = OwnerComp.GetAIOwner();
		AP3Character* Character = MyController ? Cast<AP3Character>(MyController->GetPawn()) : nullptr;
		if (Character && Character->GetP3CharacterMovementBP())
		{
			Character->GetP3CharacterMovementBP()->SetSprint(WasSprintBeforeTask);
		}
	}

	if (SetCrippled != EP3WalkPostureType::WalkPosture_Default)
	{
		AAIController* MyController = OwnerComp.GetAIOwner();
		AP3Character* Character = MyController ? Cast<AP3Character>(MyController->GetPawn()) : nullptr;
		if (Character && Character->GetCommandComponent())
		{
			FP3CommandRequestParams Params;
			Params.SetCrippled_bCrippled = WasCrippledBeforeTask;

			Character->GetCommandComponent()->RequestCommand(UP3SetCrippledCommand::StaticClass(), Params);
		}
	}

	if (SetMeleeAiming != EP3WalkPostureType::WalkPosture_Default)
	{
		AAIController* MyController = OwnerComp.GetAIOwner();
		AP3Character* Character = MyController ? Cast<AP3Character>(MyController->GetPawn()) : nullptr;
		if (Character && Character->GetCommandComponent())
		{
			FP3CommandRequestParams Params;
			Params.SetMeleeAiming_bNewAiming = WasMeleeAimingBeforeTask;

			Character->GetCommandComponent()->RequestCommand(UP3SetMeleeAimingCommand::StaticClass(), Params);
		}
	}

	Super::OnTaskFinished(OwnerComp, NodeMemory, TaskResult);
}

bool UP3BTTask_MoveToEx::EnumToBoolForSettingWalkPosture(EP3WalkPostureType WalkPosture)
{
	switch (WalkPosture)
	{
	case EP3WalkPostureType::WalkPosture_On:				return true;
	case EP3WalkPostureType::WalkPosture_Off:				return false;
	default:
		P3JsonLog(Error, "It's invalid walk posture");
		break;
	}

	return false;
}

void UP3BTTask_CharacterCount::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
		BBKey_OutNumActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_CharacterCount::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
	AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return EBTNodeResult::Failed;
	}

	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		P3JsonLog(Warning, "Can not find BlackboardComponent", TEXT("Character"), MyCharacter->GetName());
		return EBTNodeResult::Failed;
	}

	const AP3Character* ChoosenActorFromBBkey = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));

	// If the target from Blackboard key is none, my character is set target character.
	const AP3Character* TargetCharacter = ChoosenActorFromBBkey ? ChoosenActorFromBBkey : MyCharacter;

	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(*this);

	if (!ServerWorld)
	{
		return EBTNodeResult::Failed;
	}

	const TArray<class AP3Character*>& Characters = ServerWorld->GetCharacters();

	int32 SearchedActorCount = 0;

	for (AP3Character* Character : Characters)
	{
		if (!Character)
		{
			continue;
		}

		// Except target actor as center of search
		if (Character == TargetCharacter)
		{
			continue;
		}

		// If my character doesn't have to search allies, then skip same faction.
		if (!bSearchIncludeMyAllies && (Character->GetFaction() == MyCharacter->GetFaction()))
		{
			continue;
		}

		// If bSearchIncludeMyAllies is true but bSearchIncludeMe is false, except owner
		if (bSearchIncludeMyAllies && !bSearchIncludeMe && Character == MyCharacter)
		{
			continue;
		}

		const FVector CharacterToTargetCharacter = Character->GetActorLocation() - TargetCharacter->GetActorLocation();

		// If the PC is out of my smaller search range, do not consider the PC.
		if ((SearchRange >= 0) && (CharacterToTargetCharacter.SizeSquared() > (SearchRange * SearchRange)))
		{
			continue;
		}
		else
		{
			SearchedActorCount += 1;
		}
	}

	if (BBKey_OutNumActor.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
	{
		MyBlackboard->SetValue<UBlackboardKeyType_Int>(BBKey_OutNumActor.GetSelectedKeyID(), SearchedActorCount);
	}

	return EBTNodeResult::Succeeded;
}

UP3BTTask_ArithmeticOfTwoBBEntries::UP3BTTask_ArithmeticOfTwoBBEntries()
{
	// Accept only integer and float
	BBKey_FirstNumber.AddIntFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_ArithmeticOfTwoBBEntries, BBKey_FirstNumber));
	BBKey_FirstNumber.AddFloatFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_ArithmeticOfTwoBBEntries, BBKey_FirstNumber));
	BBKey_SecondNumber.AddIntFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_ArithmeticOfTwoBBEntries, BBKey_SecondNumber));
	BBKey_SecondNumber.AddFloatFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_ArithmeticOfTwoBBEntries, BBKey_SecondNumber));
	BBKey_OutResultNumber.AddFloatFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_ArithmeticOfTwoBBEntries, BBKey_OutResultNumber));
}

void UP3BTTask_ArithmeticOfTwoBBEntries::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_FirstNumber.ResolveSelectedKey(*BBAsset);
		BBKey_SecondNumber.ResolveSelectedKey(*BBAsset);
		BBKey_OutResultNumber.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_ArithmeticOfTwoBBEntries::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	APawn* Pawn = AIController ? AIController->GetPawn() : nullptr;

	if (!Pawn)
	{
		return EBTNodeResult::Failed;
	}

	float FirstNumber = 0.0f;
	float SecondNumber = 0.0f;

	FirstNumber = GetFloatNumberFromBBkey(*MyBlackboard, *Pawn, BBKey_FirstNumber);
	SecondNumber = GetFloatNumberFromBBkey(*MyBlackboard, *Pawn, BBKey_SecondNumber);

	// Prevent division by zero
	SecondNumber = (SecondNumber == 0) ? FMath::Clamp(SecondNumber, 1.0f, BIG_NUMBER) : SecondNumber;

	float ArithmeticResult = 0.0f;
	switch (Calculation_Query)
	{
	case EP3ArithmeticCalculation::Addition:				ArithmeticResult = FirstNumber + SecondNumber;	break;
	case EP3ArithmeticCalculation::Subtraction:				ArithmeticResult = FirstNumber - SecondNumber;	break;
	case EP3ArithmeticCalculation::Multiplication:			ArithmeticResult = FirstNumber * SecondNumber;	break;
	case EP3ArithmeticCalculation::Division:				ArithmeticResult = FirstNumber / SecondNumber;	break;
	default: break;
	}

	if (BBKey_OutResultNumber.SelectedKeyType == UBlackboardKeyType_Float::StaticClass())
	{
		MyBlackboard->SetValue<UBlackboardKeyType_Float>(BBKey_OutResultNumber.GetSelectedKeyID(), ArithmeticResult);
	}
	else
	{
		P3JsonLog(Warning, "BTTask Get arimetic result failed. the blackboard key is not float number",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"),
			TEXT("Blackboard Key"), (BBKey_OutResultNumber.SelectedKeyName).ToString());

		return EBTNodeResult::Failed;
	}

	return EBTNodeResult::Succeeded;
}

float UP3BTTask_ArithmeticOfTwoBBEntries::GetFloatNumberFromBBkey(UBlackboardComponent& Blackboard, APawn& Pawn, struct FBlackboardKeySelector BBkey_Number) const
{
	float FloatNumber = 0.0f;

	if (BBkey_Number.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
	{
		FloatNumber = (float)(Blackboard.GetValue<UBlackboardKeyType_Int>(BBkey_Number.GetSelectedKeyID()));
	}
	else if (BBkey_Number.SelectedKeyType == UBlackboardKeyType_Float::StaticClass())
	{
		FloatNumber = Blackboard.GetValue<UBlackboardKeyType_Float>(BBkey_Number.GetSelectedKeyID());
	}
	else
	{
		P3JsonLog(Warning, "BTDeco Get number for arimetic failed. the number is not number",
			TEXT("Pawn"), (&Pawn) ? Pawn.GetName() : TEXT("NULL"),
			TEXT("Blackboard Key"), (BBkey_Number.SelectedKeyName).ToString());
		return EBTNodeResult::Failed;
	}

	return FloatNumber;
}

EBTNodeResult::Type UP3BTTask_AddAIPoint::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AP3AIController* AICon = Cast<AP3AIController>(OwnerComp.GetAIOwner());

	if (!ensure(AICon))
	{
		return EBTNodeResult::Failed;
	}

	AICon->AddPoint(PointType, Point);

	return EBTNodeResult::Succeeded;
}

EBTNodeResult::Type UP3BTTask_SetAIPoint::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AP3AIController* AICon = Cast<AP3AIController>(OwnerComp.GetAIOwner());

	if (!ensure(AICon))
	{
		return EBTNodeResult::Failed;
	}

	AICon->SetPoint(PointType, Point);

	return EBTNodeResult::Succeeded;
}

UP3BTTask_MovementInputForward::UP3BTTask_MovementInputForward()
{
	bNotifyTick = true;
}

EBTNodeResult::Type UP3BTTask_MovementInputForward::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	return EBTNodeResult::InProgress;
}

void UP3BTTask_MovementInputForward::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	AAIController* MyController = OwnerComp.GetAIOwner();
	AP3Character* Character = MyController ? Cast<AP3Character>(MyController->GetPawn()) : nullptr;
	if (!Character)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return;
	}

	Character->AddMovementInput(Character->GetActorForwardVector());
}

UP3BTTask_SetCharacterEmote::UP3BTTask_SetCharacterEmote()
{
	bNotifyTick = true;
}

EBTNodeResult::Type UP3BTTask_SetCharacterEmote::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AP3AIController* P3AIController = Cast<AP3AIController>(OwnerComp.GetAIOwner());
	if (!P3AIController)
	{
		P3JsonLog(Error, "Failed setting ai controller emote task. No P3AIController.");
		return EBTNodeResult::Failed;
	}

	AP3Character* MyCharacter = P3AIController ? Cast<AP3Character>(P3AIController->GetPawn()) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Error, "Failed setting ai controller emote task. No Character.");
		return EBTNodeResult::Failed;
	}

	FBTCharacterEmoteTaskMemory* MyMemory = (FBTCharacterEmoteTaskMemory*)NodeMemory;
	MyMemory->TaskAgeSeconds = 0.0f;
	MyMemory->EmoteDurationSeconds = EmoteTimeLimit;

	if (bSetEmoteFromAIController)
	{
		SetCharacterEmote(OwnerComp, P3AIController->GetEmoteAnimName());
	}
	else
	{
		SetCharacterEmote(OwnerComp, EmoteAnimNameForce);
	}

	UAnimSequenceBase* EmoteStartAnimation = MyCharacter->GetEmote().EmoteAnimationStart;
	UAnimSequenceBase* EmoteEndAnimation = MyCharacter->GetEmote().EmoteAnimationEnd;

	MyMemory->EmoteStartAnimTotalSeconds = EmoteStartAnimation ? (EmoteStartAnimation->SequenceLength) : 0.0f;
	MyMemory->EmoteEndAnimTotalSeconds = EmoteEndAnimation ? (EmoteEndAnimation->SequenceLength) : 0.0f;

	// Emote Start Anim, Emote End Anim 보다 Spot 설정의 총 Emote 지속 시간이 짧게 설정된 경우, 에러를 띄우고 return Failed.
	if (EmoteTimeLimit > 0.0f &&
		(((MyMemory->EmoteDurationSeconds) < (MyMemory->EmoteStartAnimTotalSeconds)) || ((MyMemory->EmoteDurationSeconds) < (MyMemory->EmoteEndAnimTotalSeconds))))
	{
		P3JsonLog(Warning, "Emote Duration Seconds Setting is shorter than EmoteStartAnim or EmoteEndAnim.");
		return EBTNodeResult::Failed;
	}

	SetInEmote(OwnerComp, true);

	return EBTNodeResult::InProgress;
}

void UP3BTTask_SetCharacterEmote::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

	FBTCharacterEmoteTaskMemory* MyMemory = (FBTCharacterEmoteTaskMemory*)NodeMemory;
	MyMemory->TaskAgeSeconds += DeltaSeconds;

	if ((MyMemory->EmoteEndAnimTotalSeconds) == 0.0f)
	{
		// End Animation이 없는 Non-Loop Emote 입니다.
		if ((MyMemory->TaskAgeSeconds) >= (MyMemory->EmoteStartAnimTotalSeconds))
		{
			SetInEmote(OwnerComp, false);
			SetCharacterEmote(OwnerComp, NAME_None);
			FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
			OnTaskFinished(OwnerComp, NodeMemory, EBTNodeResult::Succeeded);
		}
	}
	else
	{
		if (EmoteTimeLimit < 0.0f)
		{
			// 시간제한 없음
		}
		else
		{
			// End Animation이 있는 Loop Emote 입니다. End Animation Sequence 길이 만큼만 시간 여분을 남겨두어 마지막에 Loop-End Anim을 출력하도록 합니다.
			if ((MyMemory->TaskAgeSeconds) >= ((MyMemory->EmoteDurationSeconds)-(MyMemory->EmoteEndAnimTotalSeconds)))
			{
				if (!(MyMemory->HasInitializedEmote))
				{
					SetInEmote(OwnerComp, false);
					MyMemory->HasInitializedEmote = true;
				}

				if ((MyMemory->TaskAgeSeconds) >= (MyMemory->EmoteDurationSeconds))
				{
					// continue execution from this node
					SetCharacterEmote(OwnerComp, NAME_None);
					FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
					OnTaskFinished(OwnerComp, NodeMemory, EBTNodeResult::Succeeded);
				}
			}
		}

	}
}

void UP3BTTask_SetCharacterEmote::OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult)
{
	Super::OnTaskFinished(OwnerComp, NodeMemory, TaskResult);

	SetInEmote(OwnerComp, false);
	SetCharacterEmote(OwnerComp, NAME_None);
}

/** BTDecorator에 의한 Task 종료 시에는 OnTaskFinished가 아닌 AbortTask 함수로 들어옴 */
EBTNodeResult::Type UP3BTTask_SetCharacterEmote::AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	SetInEmote(OwnerComp, false);
	SetCharacterEmote(OwnerComp, NAME_None);

	return Super::AbortTask(OwnerComp, NodeMemory);
}

uint16 UP3BTTask_SetCharacterEmote::GetInstanceMemorySize() const
{
	return sizeof(FBTCharacterEmoteTaskMemory);
}

void UP3BTTask_SetCharacterEmote::SetInEmote(UBehaviorTreeComponent& OwnerComp, bool NewInEmote)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!Character)
	{
		return;
	}

	if (!Character->GetCommandComponent())
	{
		P3JsonLog(Error, "Failed setting ai controller emote task. No command component");
		return;
	}

	FP3CommandRequestParams Params;
	Params.SetInEmote_bInEmote = NewInEmote;

	Character->GetCommandComponent()->RequestCommand(UP3SetInEmoteCommand::StaticClass(), Params);
}

void UP3BTTask_SetCharacterEmote::SetCharacterEmote(UBehaviorTreeComponent& OwnerComp, FName InEmoteAnimName)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!Character)
	{
		P3JsonLog(Error, "Failed setting ai controller emote task. No character");
		return;
	}

	if (!(Character->GetCommandComponent()))
	{
		P3JsonLog(Error, "Failed setting ai controller emote task. No command component");
		return;
	}

	FP3CommandRequestParams Params;
	Params.SetEmoteByName_EmoteAnimName = InEmoteAnimName;

	Character->GetCommandComponent()->RequestCommand(UP3SetEmoteByNameCommand::StaticClass(), Params);
}
