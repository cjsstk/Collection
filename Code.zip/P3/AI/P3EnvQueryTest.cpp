// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3EnvQueryTest.h"

#include "AIController.h"
#include "EnvironmentQuery/Items/EnvQueryItemType_Actor.h"
#include "NavigationSystem.h"
#include "NavMesh/RecastNavMesh.h"

#include "Action/P3PawnActionComponent.h"
#include "P3AggroComponent.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3HealthPointComponent.h"
#include "P3HolderComponent.h"
#include "P3ServerWorld.h"
#include "P3Weapon.h"

UP3EnvQueryTest_ScareLevel::UP3EnvQueryTest_ScareLevel()
{
	Cost = EEnvTestCost::Low;
	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_ScareLevel::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	FloatValueMin.BindData(QueryOwner, QueryInstance.QueryID);
	const float MinThresholdValue = FloatValueMin.GetValue();

	FloatValueMax.BindData(QueryOwner, QueryInstance.QueryID);
	const float MaxThresholdValue = FloatValueMax.GetValue();

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AP3Character* Character = Cast<AP3Character>(GetItemActor(QueryInstance, It.GetIndex()));
		if (!Character)
		{
			continue;
		}

		if (Character == QueryOwner)
		{
			// Exclude self
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		int32 ScareLevel = 0;

		UP3CharacterEffectComponent* EffectComp = Character->GetEffectComponent();

		if (EffectComp)
		{
			ScareLevel = EffectComp->GetOverlappableBuffEffectiveLevel(EP3OverappableBuffType::Scare);
		}

		if (ScareLevel <= 0)
		{
			// Exclude 0 scare level
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		It.SetScore(TestPurpose, FilterType, ScareLevel, MinThresholdValue, MaxThresholdValue);
	}
}

FText UP3EnvQueryTest_ScareLevel::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("Scare 레벨");
}

FText UP3EnvQueryTest_ScareLevel::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_PawnActionType::UP3EnvQueryTest_PawnActionType()
{
	Cost = EEnvTestCost::Low;
	SetWorkOnFloatValues(false);

	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_PawnActionType::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	BoolValue.BindData(QueryOwner, QueryInstance.QueryID);
	bool bWantsValid = BoolValue.GetValue();

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AP3Character* Character = Cast<AP3Character>(GetItemActor(QueryInstance, It.GetIndex()));
		if (!Character)
		{
			continue;
		}

		if (!Character->IsPlayerControlled())
		{
			continue;
		}

		if (Character == QueryOwner)
		{
			// Exclude self
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		if (!Character->GetActionComponent())
		{
			continue;
		}

		if (ActionType == EPawnActionType::Invalid)
		{
			if (Character->GetActionComponent()->GetActiveActionType() != EPawnActionType::Invalid)
			{
				It.SetScore(TestPurpose, FilterType, true, bWantsValid);
			}
		}
		else
		{
			if (Character->GetActionComponent()->IsActionInProgress(ActionType))
			{
				It.SetScore(TestPurpose, FilterType, true, bWantsValid);
			}
		}
	}
}

FText UP3EnvQueryTest_PawnActionType::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("폰 액션 종류");
}

FText UP3EnvQueryTest_PawnActionType::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_WeaponType::UP3EnvQueryTest_WeaponType()
{
	Cost = EEnvTestCost::Low;
	SetWorkOnFloatValues(false);

	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_WeaponType::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	BoolValue.BindData(QueryOwner, QueryInstance.QueryID);
	bool bWantsValid = BoolValue.GetValue();

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AP3Character* Character = Cast<AP3Character>(GetItemActor(QueryInstance, It.GetIndex()));
		if (!Character)
		{
			continue;
		}

		if (!Character->IsPlayerControlled())
		{
			continue;
		}

		if (Character == QueryOwner)
		{
			// Exclude self
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		UP3HolderComponent* RightHandHolder = Character->GetRightHandHolderComponent();
		UP3HolderComponent* LeftHandHolder = Character->GetLeftHandHolderComponent();
		if (RightHandHolder || LeftHandHolder)
		{
			AP3Weapon* RightHandWeapon = RightHandHolder ? Cast<AP3Weapon>(RightHandHolder->GetHoldingActor()) : nullptr;
			AP3Weapon* LeftHandWeapon = LeftHandHolder ? Cast<AP3Weapon>(LeftHandHolder->GetHoldingActor()) : nullptr;

			if (WeaponType == EP3WeaponType::None)
			{
				It.SetScore(TestPurpose, FilterType, true, bWantsValid);
			}
			else
			{
				if (RightHandWeapon && RightHandWeapon->GetWeaponType() == WeaponType)
				{
					It.SetScore(TestPurpose, FilterType, true, bWantsValid);
				}
				else if (LeftHandWeapon && LeftHandWeapon->GetWeaponType() == WeaponType)
				{
					It.SetScore(TestPurpose, FilterType, true, bWantsValid);
				}
			}
		}
	}
}

FText UP3EnvQueryTest_WeaponType::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("무기 종류");
}

FText UP3EnvQueryTest_WeaponType::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_HealthPercentage::UP3EnvQueryTest_HealthPercentage()
{
	Cost = EEnvTestCost::Low;
	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_HealthPercentage::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	FloatValueMin.BindData(QueryOwner, QueryInstance.QueryID);
	const float MinThresholdValue = FloatValueMin.GetValue();

	FloatValueMax.BindData(QueryOwner, QueryInstance.QueryID);
	const float MaxThresholdValue = FloatValueMax.GetValue();

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AP3Character* Character = Cast<AP3Character>(GetItemActor(QueryInstance, It.GetIndex()));
		if (!Character)
		{
			continue;
		}

		if (!Character->IsPlayerControlled())
		{
			continue;
		}

		if (Character == QueryOwner)
		{
			// Exclude self
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		int32 HealthPercentage = 0;

		UP3HealthPointComponent* HealthPointComp = Character->GetP3HealthComponentBP();
		if (HealthPointComp)
		{
			const int32 MaxHealthPoint = HealthPointComp->GetMaxHealthPoint();
			const int32 CurrentHealthPoint = HealthPointComp->GetHealthPoint();
			HealthPercentage = (MaxHealthPoint != 0) ? FMath::RoundToInt((((float)CurrentHealthPoint / (float)MaxHealthPoint)) * 100) : 0;
		}

		if (HealthPercentage <= 0)
		{
			// Exclude 0 Health Percentage
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		It.SetScore(TestPurpose, FilterType, HealthPercentage, MinThresholdValue, MaxThresholdValue);
	}
}

FText UP3EnvQueryTest_HealthPercentage::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("체력 비율");
}

FText UP3EnvQueryTest_HealthPercentage::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_ProvokeLevel::UP3EnvQueryTest_ProvokeLevel()
{
	Cost = EEnvTestCost::Low;
	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_ProvokeLevel::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	FloatValueMin.BindData(QueryOwner, QueryInstance.QueryID);
	const float MinThresholdValue = FloatValueMin.GetValue();

	FloatValueMax.BindData(QueryOwner, QueryInstance.QueryID);
	const float MaxThresholdValue = FloatValueMax.GetValue();

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AP3Character* Character = Cast<AP3Character>(GetItemActor(QueryInstance, It.GetIndex()));
		if (!Character)
		{
			continue;
		}

		if (Character == QueryOwner)
		{
			// Exclude self
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		int32 ProvokeLevel = 0;

		UP3CharacterEffectComponent* EffectComp = Character->GetEffectComponent();

		if (EffectComp)
		{
			ProvokeLevel = EffectComp->GetBuffProvokeLevel();
		}

		if (ProvokeLevel <= 0)
		{
			// Exclude 0 scare level
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		It.SetScore(TestPurpose, FilterType, ProvokeLevel, MinThresholdValue, MaxThresholdValue);
	}
}

FText UP3EnvQueryTest_ProvokeLevel::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("Provoke 레벨");
}

FText UP3EnvQueryTest_ProvokeLevel::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_NearbyCharacterCount::UP3EnvQueryTest_NearbyCharacterCount()
{
	Cost = EEnvTestCost::Low;
	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_NearbyCharacterCount::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	FloatValueMin.BindData(QueryOwner, QueryInstance.QueryID);
	const float MinThresholdValue = FloatValueMin.GetValue();

	FloatValueMax.BindData(QueryOwner, QueryInstance.QueryID);
	const float MaxThresholdValue = FloatValueMax.GetValue();

	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(*this);
	if (!ServerWorld)
	{
		return;
	}

	const TArray<class AP3Character*>& Characters = ServerWorld->GetCharacters();
	const AP3Character* OwnerCharacter = Cast<AP3Character>(QueryOwner);

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AP3Character* ItemCharacter = Cast<AP3Character>(GetItemActor(QueryInstance, It.GetIndex()));
		if (!ItemCharacter)
		{
			continue;
		}

		// If the item character doesn't have to search allies, then skip same faction.
		if (!bSearchIncludeAllies && (ItemCharacter->GetFaction() == OwnerCharacter->GetFaction()))
		{
			continue;
		}

		if (ItemCharacter == QueryOwner)
		{
			// Exclude self
			It.ForceItemState(EEnvItemStatus::Failed);
			continue;
		}

		int32 CurrentNearbyCharacterCount = 0;

		for (AP3Character* Character : Characters)
		{
			if (!Character)
			{
				continue;
			}

			// If the character is same faction with Querier, Skip it.
			if (OwnerCharacter)
			{
				if (Character->GetFaction() == OwnerCharacter->GetFaction())
				{
					continue;
				}
			}

			const FVector CharacterToTester = Character->GetActorLocation() - ItemCharacter->GetActorLocation();

			// If the character is out of my search range, do not consider the character.
			if (CharacterToTester.SizeSquared() > (SearchRangeAroundEachItem * SearchRangeAroundEachItem))
			{
				continue;
			}
			else
			{
				CurrentNearbyCharacterCount += 1;
			}
		}

		It.SetScore(TestPurpose, FilterType, CurrentNearbyCharacterCount, MinThresholdValue, MaxThresholdValue);
	}
}

FText UP3EnvQueryTest_NearbyCharacterCount::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("주변 캐릭터 수");
}

FText UP3EnvQueryTest_NearbyCharacterCount::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_AggroTableIndex::UP3EnvQueryTest_AggroTableIndex()
{
	Cost = EEnvTestCost::Low;
	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_AggroTableIndex::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	FloatValueMin.BindData(QueryOwner, QueryInstance.QueryID);
	const float MinThresholdValue = FloatValueMin.GetValue();

	FloatValueMax.BindData(QueryOwner, QueryInstance.QueryID);
	const float MaxThresholdValue = FloatValueMax.GetValue();

	const AP3Character* OwnerCharacter = Cast<AP3Character>(QueryOwner);

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AActor* ItemActor = GetItemActor(QueryInstance, It.GetIndex());
		if (!ItemActor)
		{
			continue;
		}

		const TArray<FP3AggroItem> AggroList = OwnerCharacter->GetAggroComponentBP()->GetSortedAggroItems();
		int32 index = 0;
		for (index = 0; index < AggroList.Num(); index++)
		{
			if (AggroList[index].Actor == ItemActor)
			{
				break;
			}
		}

		It.SetScore(TestPurpose, FilterType, (float)index, MinThresholdValue, MaxThresholdValue);
	}
}

FText UP3EnvQueryTest_AggroTableIndex::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("어그로 테이블 인덱스");
}

FText UP3EnvQueryTest_AggroTableIndex::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_AggroTablePoint::UP3EnvQueryTest_AggroTablePoint()
{
	Cost = EEnvTestCost::Low;
	ValidItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryTest_AggroTablePoint::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	FloatValueMin.BindData(QueryOwner, QueryInstance.QueryID);
	const float MinThresholdValue = FloatValueMin.GetValue();

	FloatValueMax.BindData(QueryOwner, QueryInstance.QueryID);
	const float MaxThresholdValue = FloatValueMax.GetValue();

	const AP3Character* OwnerCharacter = Cast<AP3Character>(QueryOwner);

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		const AActor* ItemActor = GetItemActor(QueryInstance, It.GetIndex());
		if (!ItemActor)
		{
			continue;
		}

		const TArray<FP3AggroItem> AggroList = OwnerCharacter->GetAggroComponentBP()->GetSortedAggroItems();

		const FP3AggroItem* AggroActor = AggroList.FindByPredicate([ItemActor](const FP3AggroItem& AggroActor) -> bool {
			return (AggroActor.Actor == ItemActor);
		});

		if (!AggroActor)
		{
			continue;
		}

		It.SetScore(TestPurpose, FilterType, (float)(AggroActor->Point), MinThresholdValue, MaxThresholdValue);
	}
}

FText UP3EnvQueryTest_AggroTablePoint::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("어그로 테이블 포인트");
}

FText UP3EnvQueryTest_AggroTablePoint::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}

UP3EnvQueryTest_ItemsOnNavmesh::UP3EnvQueryTest_ItemsOnNavmesh()
{
	Cost = EEnvTestCost::Low;
	SetWorkOnFloatValues(false);

	ValidItemType = UEnvQueryItemType_VectorBase::StaticClass();
}

void UP3EnvQueryTest_ItemsOnNavmesh::RunTest(FEnvQueryInstance& QueryInstance) const
{
	UObject* QueryOwner = QueryInstance.Owner.Get();

	if (QueryOwner == nullptr)
	{
		return;
	}

	BoolValue.BindData(QueryOwner, QueryInstance.QueryID);
	bool bWantsValid = BoolValue.GetValue();

	AP3Character* MyCharacter = Cast<AP3Character>(QueryOwner);
	if (!MyCharacter)
	{
		return;
	}

	if (MyCharacter->IsPlayerControlled())
	{
		return;
	}

	for (FEnvQueryInstance::ItemIterator It(this, QueryInstance); It; ++It)
	{
		bool bHasPath = false;

		const UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
		if (NavSys)
		{
			const AAIController* AIOwner = Cast<AAIController>(MyCharacter->GetController());
			const ANavigationData* NavData = AIOwner ? NavSys->GetNavDataForProps(AIOwner->GetNavAgentPropertiesRef()) : NULL;
			if (NavData)
			{
				FSharedConstNavQueryFilter QueryFilter = UNavigationQueryFilter::GetQueryFilter(*NavData, AIOwner, FilterClass);

				const ARecastNavMesh* RecastNavMesh = Cast<const ARecastNavMesh>(NavData);
				FVector ItemLocation = GetItemLocation(QueryInstance, It.GetIndex());

				bHasPath = (RecastNavMesh && RecastNavMesh->IsSegmentOnNavmesh(ItemLocation, ItemLocation, QueryFilter));
			}
		}

		It.SetScore(TestPurpose, FilterType, bHasPath, bWantsValid);
	}
}

FText UP3EnvQueryTest_ItemsOnNavmesh::GetDescriptionTitle() const
{
	return FText::AsCultureInvariant("Navmesh의 아이템");
}

FText UP3EnvQueryTest_ItemsOnNavmesh::GetDescriptionDetails() const
{
	return DescribeFloatTestParams();
}
