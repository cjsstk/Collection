// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_UpdateAlertTarget.h"

#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Float.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"

#include "P3AggroComponent.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3Combat.h"

extern TAutoConsoleVariable<float> CVarP3FarSightRangeScale;

void UP3BTTask_UpdateAlertTarget::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_AlertTargetActor.ResolveSelectedKey(*BBAsset);
		BBKey_AlertStartTimeSeconds.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_UpdateAlertTarget::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	if (!ensure(BBKey_AlertTargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass()))
	{
		return EBTNodeResult::Failed;
	}

	if (!ensure(BBKey_AlertStartTimeSeconds.SelectedKeyType == UBlackboardKeyType_Float::StaticClass()))
	{
		return EBTNodeResult::Failed;
	}

	UWorld* World = OwnerComp.GetWorld();

	if (!ensure(World))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = MyAIController ? Cast<AP3Character>(MyAIController->GetPawn()) : nullptr;

	if (!ensure(MyCharacter))
	{
		return EBTNodeResult::Failed;
	}

	UP3CharacterEffectComponent* EffectComp = MyCharacter->GetEffectComponent();

	float Range = SearchRange;
	float HalfHeight = SearchHalfHeight;

	if (EffectComp && EffectComp->HasEffect(EP3CharacterEffectTypes::FarSight))
	{
		float Scale = CVarP3FarSightRangeScale.GetValueOnGameThread();
		Range *= Scale;
		HalfHeight *= Scale;
	}

	AActor* NewAlertTargetActor = P3Combat::FindTargetInRange(*MyCharacter, Range, bSearchFrontOnly);

	if (!NewAlertTargetActor)
	{
		MyBlackboard->ClearValue(BBKey_AlertTargetActor.GetSelectedKeyID());
		MyBlackboard->ClearValue(BBKey_AlertStartTimeSeconds.GetSelectedKeyID());

		return EBTNodeResult::Failed;
	}

	float AlertStartTimeSeconds = MyBlackboard->GetValue<UBlackboardKeyType_Float>(BBKey_AlertStartTimeSeconds.GetSelectedKeyID());

	if (World->GetTimeSeconds() - AlertStartTimeSeconds > WaitTimeSecondsBeforeAttack)
	{
		UP3AggroComponent* AggroComp = MyCharacter->FindComponentByClass<UP3AggroComponent>();

		if (AggroComp)
		{
			AggroComp->OnSight(NewAlertTargetActor);
			MyBlackboard->ClearValue(BBKey_AlertTargetActor.GetSelectedKeyID());
			MyBlackboard->ClearValue(BBKey_AlertStartTimeSeconds.GetSelectedKeyID());

			return EBTNodeResult::Succeeded;
		}
	}

	MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_AlertTargetActor.GetSelectedKeyID(), NewAlertTargetActor);

	return EBTNodeResult::Succeeded;
}
