// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "AI/P3Route.h"
#include "AIController.h"
#include "P3TripType.h"
#include "P3AIController.generated.h"

UENUM(BlueprintType)
enum class EP3AIPointType : uint8
{
	Rage,
	Count	UMETA(Hidden)
};

/**
 * AI Controller
 */
UCLASS()
class P3_API AP3AIController : public AAIController
{
	GENERATED_BODY()
	
public:
	AP3AIController();

	virtual void Tick(float DeltaSeconds) override;

	virtual void UpdateControlRotation(float DeltaTime, bool bUpdatePawn = true) override;

	void OnHit(AActor* SourceActor, int32 Damage);

	UFUNCTION(BlueprintImplementableEvent)
	void OnHitBP(AActor* SourceActor, int32 Damage);

	void ResetAfterReturn();

	void SetPointOfInterest(class AP3PointOfInterest* POI);
	class AP3PointOfInterest* GetPointOfInterest() const { return PointOfInterest; }

	void SetRouteList(const TArray<FP3Route>& InRouteList);
	const TArray<FP3Route>& GetRouteList() const { return RouteList; }

	void SetEmoteAnimName(const FName& InEmoteAnimName);
	const FName& GetEmoteAnimName() const { return EmoteAnimName; }

	void AddForbiddenVolume(class AP3ForbiddenVolume* Volume);
	void RemoveForbiddenVolume(class AP3ForbiddenVolume* Volume);
	bool IsInForbiddenVolume() const;

	bool IsInAlert() const { return bInAlert; }
	void SetInAlert(bool bNewInAlert);

	bool IsReturningFromCombat() const { return bReturningFromCombat; }
	float GetReturningFromCombatAgeSeconds() const { return ReturningFromCombatAgeSeconds; }
	void SetReturningFromCombat(bool bInReturningFromCombat);

	bool IsOverHit() const;

	void SetForceTarget(AActor* Target);
	AActor* GetForceTarget() const { return CommandForceTarget; }

	UFUNCTION(BlueprintCallable)
	int32 GetMaxPoint(EP3AIPointType PointType) const;

	UFUNCTION(BlueprintCallable)
	int32 GetPoint(EP3AIPointType PointType) const;

	/**
	 * Add Point
	 * Returns final points
	 */
	UFUNCTION(BlueprintCallable)
	int32 AddPoint(EP3AIPointType PointType, int32 Point);

	UFUNCTION(BlueprintCallable)
	void SetPoint(EP3AIPointType PointType, int32 Point);

	FString GetDebugString() const;

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void OnResetAfterReturnBP();

private:
	void Server_Tick(float DeltaSeconds);

	/** 
	 * UP3BTTask_FindPointOfInterest will use this as lowest-priority point
	 * you can use this as 'default go to point' or 'default return to point'
	 * @see also AP3PawnSpawnerActor::RandomPointOfInterests
	 */
	UPROPERTY(Transient)
	class AP3PointOfInterest* PointOfInterest;

	UPROPERTY(Transient)
	TArray<FP3Route> RouteList;

	UPROPERTY(Transient)
	TArray<class AP3ForbiddenVolume*> ForbiddenVolumes;

	UPROPERTY(EditAnywhere, Category = P3)
	int32 OverNumHitThreshold = 3;

	UPROPERTY(EditAnywhere, Category = P3)
	float NumHitClearTimeSeconds = 2.0f;

	UPROPERTY(EditAnywhere, Category = P3)
	TMap<EP3AIPointType, int32> MaxPoints;

	UPROPERTY(Transient)
	AActor* CommandForceTarget = nullptr;

	bool bInAlert = false;
	bool bReturningFromCombat = false;
	float ReturningFromCombatAgeSeconds = 0.0f;
	int32 NumHit = 0;
	float TimeSinceOverHit = 0.0f;
	FName EmoteAnimName = NAME_None;

	TMap<EP3AIPointType, int32> Points;
};
