// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "Components/ActorComponent.h"
#include "P3Actor.h"
#include "P3TripType.h"
#include "P3WalkType.h"
#include "P3Route.generated.h"

USTRUCT()
struct FP3Route
{
	GENERATED_BODY()

	/** Spawned pawn's AI Controller will have this route, which can be used by Behavior Tree */
	UPROPERTY(EditAnywhere)
	AP3RouteActor* RouteActor;

	/**
	* 경로 이동 방법
	* OneWay : 편도
	* RoundTrip : 왕복
	* CircleTrip : 순회
	*/
	UPROPERTY(EditAnywhere)
	EP3RouteTripType RouteTripType = EP3RouteTripType::CircleTrip;

	UPROPERTY(EditAnywhere)
	EP3RouteWalkType RouteWalkType = EP3RouteWalkType::Walk;
};

/**
 * Route
 * list of Spots
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3RouteComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3RouteComponent();

	const TArray<class AP3Spot*>& GetSpots() const { return Spots; }

private:
	UPROPERTY(EditInstanceOnly, Category = "Route")
	TArray<class AP3Spot*> Spots;
};

UCLASS(ClassGroup = (P3), ComponentWrapperClass)
class P3_API AP3RouteActor : public AP3Actor
{
	GENERATED_BODY()

public:
	AP3RouteActor();

	UP3RouteComponent* GetRouteComponent() const { return RouteComponent; }

private:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Route", meta = (AllowPrivateAccess = "true"))
	UP3RouteComponent* RouteComponent;

	UPROPERTY(Transient)
	class UBillboardComponent* EditorSprite;
};
