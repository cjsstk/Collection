// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "P3BTTask_FindPointOfInterest.generated.h"

/**
 * Find point of interest
 */
UCLASS()
class P3_API UP3BTTask_FindPointOfInterest : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_PointOfInterest;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_PointOfInterestOrigin;

	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 800.0f;

	UPROPERTY(Category = Node, EditAnywhere)
	float MaxDistanceToOrigin = 1500.0f;

private:
	class AP3PointOfInterest* FindNewPointOfInterest(class AAIController& MyAIController, class AP3Character& MyCharacter);
};

/**
 * Find P3Actor with game play tag
 */
UCLASS()
class P3_API UP3BTTask_FindNearestActorWithTag : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/**
	 * 근처에 여기 지정한 Gameplay Tag가 포함된 P3Actor를 찾습니다.
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer IncludedGameplayTagsAny;

	/**
	 * 찾은 P3Actor를 이 Blackboard key에 저장합니다.
	 */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/**
	 * 찾은 P3Actor의 위치를 이 Blackboard key에 저장합니다.
	 */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActorLocation;

	/**
	 * 탐색 반경
	 */
	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 1000.0f;

private:
	class AActor* FindP3ActorWithTag(class AP3Character& MyCharacter);
};
