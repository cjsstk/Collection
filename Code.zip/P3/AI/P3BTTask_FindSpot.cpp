// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_FindSpot.h"

#include "AIController.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Vector.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "EngineUtils.h"

#include "P3Log.h"
#include "P3Spot.h"

void UP3BTTask_FindSpot::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_Spot.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_FindSpot::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard && BBKey_Spot.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass()))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	if (!ensure(AIController))
	{
		return EBTNodeResult::Failed;
	}

	APawn* Pawn = AIController->GetPawn();
	if (!ensure(Pawn))
	{
		return EBTNodeResult::Failed;
	}

	const FVector PawnLocation = Pawn->GetActorLocation();

	const float SearchRangeSquared = SearchRange * SearchRange;

	P3JsonLog(Display, "FindP3Spot...", TEXT("Owner"), *Pawn->GetName());

	TArray<FVector, TInlineAllocator<16>> CandidateLocations;
	for (TActorIterator<AP3Spot> It(GetWorld()); It; ++It)
	{
		AP3Spot* Candidate = *It;
		const FVector CandidateLocation = Candidate->GetActorLocation();

		P3JsonLog(Display, "P3Spot", TEXT("Location"), *CandidateLocation.ToString());

		if (SearchRange > 0.0f && FVector::DistSquared(CandidateLocation, PawnLocation) > SearchRangeSquared)
		{
			continue;
		}

		IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(Candidate);

		if (!ensure(GameplayTagAsset))
		{
			continue;
		}

		if (RequiredGameplayTagsAny.Num() > 0 && !GameplayTagAsset->HasAnyMatchingGameplayTags(RequiredGameplayTagsAny))
		{
			continue;
		}

		if (IgnoredGameplayTagsAny.Num() > 0 && GameplayTagAsset->HasAnyMatchingGameplayTags(IgnoredGameplayTagsAny))
		{
			continue;
		}

		CandidateLocations.Add(CandidateLocation);
	}

	P3JsonLog(Display, "P3Spot Candidates", TEXT("Num"), CandidateLocations.Num());

	if (CandidateLocations.Num() == 0)
	{
		MyBlackboard->ClearValue(BBKey_Spot.GetSelectedKeyID());

		return EBTNodeResult::Failed;
	}

	const int32 Selected = FMath::RandHelper(CandidateLocations.Num());
	MyBlackboard->SetValue<UBlackboardKeyType_Vector>(BBKey_Spot.GetSelectedKeyID(), CandidateLocations[Selected]);

	P3JsonLog(Display, "P3Spot Final", TEXT("Location"), *CandidateLocations[Selected].ToString());

	return EBTNodeResult::Succeeded;
}
