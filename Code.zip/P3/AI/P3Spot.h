// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "P3Actor.h"
#include "P3Spot.generated.h"

/**
 * Any location
 * Mostly used by AI
 */
UCLASS()
class P3_API AP3Spot : public AP3Actor
{
	GENERATED_BODY()

public:
	AP3Spot();

	virtual void Tick(float DeltaTime) override;

	const bool DoUseMontageAction() const { return bUseMontageAction; };
	const FName& GetMontageActionName() const { return MontageActionName; };
	const FName& GetEmoteName() const { return EmoteName; };
	const float GetEmoteDuration() const { return EmoteDuration; };

private:
	UPROPERTY(Transient)
	class UBillboardComponent* EditorSprite;

	UPROPERTY(EditAnywhere)
	bool bUseMontageAction = false;

	UPROPERTY(EditAnywhere, meta = (EditCondition="bUseMontageAction"))
	FName MontageActionName = NAME_None;

	UPROPERTY(EditAnywhere, meta = (EditCondition="!bUseMontageAction"))
	FName EmoteName = NAME_None;

	UPROPERTY(EditAnywhere, meta = (EditCondition="!bUseMontageAction"))
	float EmoteDuration = 10.0f;
};
