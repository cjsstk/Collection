// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3EnvQueryGenerators.h"

#include "EnvironmentQuery/Items/EnvQueryItemType_Actor.h"

#include "P3AggroComponent.h"

UP3EnvQueryGenerator_AggroTableActors::UP3EnvQueryGenerator_AggroTableActors(const FObjectInitializer& ObjectInitializer) :
	Super(ObjectInitializer)
{
	ItemType = UEnvQueryItemType_Actor::StaticClass();
}

void UP3EnvQueryGenerator_AggroTableActors::GenerateItems(FEnvQueryInstance& QueryInstance) const
{
	AActor* QueryOwnerActor = Cast<AActor>(QueryInstance.Owner.Get());
	if (!QueryOwnerActor)
	{
		return;
	}

	UP3AggroComponent* AggroComp = QueryOwnerActor->FindComponentByClass<UP3AggroComponent>();
	if (!AggroComp)
	{
		return;
	}

	TArray<AActor*> AggroActors = AggroComp->GetAllActors();

	QueryInstance.AddItemData<UEnvQueryItemType_Actor>(AggroActors);
}
