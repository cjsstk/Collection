// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "Templates/SubclassOf.h"
#include "EnvironmentQuery/EnvQueryContext.h"
#include "EnvironmentQuery/EnvQueryTest.h"

#include "Action/P3PawnAction.h"

#include "P3EnvQueryTest.generated.h"

/** 
 * EQS Test - Scare level
 */
UCLASS()
class UP3EnvQueryTest_ScareLevel : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_ScareLevel();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;
};


/**
 * EQS Test - Pawn Action Type
 */
UCLASS()
class UP3EnvQueryTest_PawnActionType : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_PawnActionType();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;

private:
	/** Action type. Set invalid to check any action */
	UPROPERTY(EditAnywhere, Category=P3)
	EPawnActionType ActionType = EPawnActionType::Invalid;
};


/**
 * EQS Test - Weapon Type
 */
UCLASS()
class UP3EnvQueryTest_WeaponType : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_WeaponType();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;

private:
	/** Weapon type. Set none to check any weapon type*/
	UPROPERTY(EditAnywhere, Category=P3)
	EP3WeaponType WeaponType = EP3WeaponType::None;
};


/**
 * EQS Test - Health Percentage
 */
UCLASS()
class UP3EnvQueryTest_HealthPercentage : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_HealthPercentage();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;
};

/**
 * EQS Test - Provoke level
 */
UCLASS()
class UP3EnvQueryTest_ProvokeLevel : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_ProvokeLevel();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;
};

/**
 * EQS Test - Nearby Actor Count (calculate include self)
 */
UCLASS()
class UP3EnvQueryTest_NearbyCharacterCount : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_NearbyCharacterCount();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;

private:
	/** Search range for finding other allies of target*/
	UPROPERTY(EditAnywhere, Category = P3)
	float SearchRangeAroundEachItem = 500.0f;

	/** If true, search actors include allies of searcher */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bSearchIncludeAllies = false;
};

/**
 * EQS Test - AggroTable_index
 */
UCLASS()
class UP3EnvQueryTest_AggroTableIndex : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_AggroTableIndex();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;
};

/**
 * EQS Test - AggroTable_point
 */
UCLASS()
class UP3EnvQueryTest_AggroTablePoint : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_AggroTablePoint();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;
};

/**
 * EQS Test - Items on navmesh
 */
UCLASS()
class UP3EnvQueryTest_ItemsOnNavmesh : public UEnvQueryTest
{
	GENERATED_BODY()

	UP3EnvQueryTest_ItemsOnNavmesh();

	virtual void RunTest(FEnvQueryInstance& QueryInstance) const override;

	virtual FText GetDescriptionTitle() const override;
	virtual FText GetDescriptionDetails() const override;

private:
	/** navigation filter to use in pathfinding */
	UPROPERTY(EditDefaultsOnly, Category = Pathfinding)
	TSubclassOf<UNavigationQueryFilter> FilterClass;
};
