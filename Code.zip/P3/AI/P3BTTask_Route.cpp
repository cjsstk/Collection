// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_Route.h"

#include "AIController.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Enum.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Int.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Vector.h"
#include "BehaviorTree/BlackboardComponent.h"

#include "Command/P3CommandComponent.h"
#include "P3AIController.h"
#include "P3Character.h"
#include "P3Log.h"
#include "P3Route.h"
#include "P3Spot.h"
#include "P3TripType.h"
#include "P3WalkType.h"

void UP3BTTask_GetRouteActorFromController::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_RouteActorIndex.ResolveSelectedKey(*BBAsset);
		BBKey_OutRouteActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_GetRouteActorFromController::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AP3AIController* AIController = Cast<AP3AIController>(OwnerComp.GetAIOwner());
	if (!AIController)
	{
		return EBTNodeResult::Failed;
	}

	if (AIController->GetRouteList().Num() == 0)
	{
		return EBTNodeResult::Failed;
	}

	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	APawn* Pawn = AIController->GetPawn();

	int32 SelectedRouteActorIndex = -1;

	if (BBKey_RouteActorIndex.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
	{
		SelectedRouteActorIndex = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_RouteActorIndex.GetSelectedKeyID());
	}

	if (SelectedRouteActorIndex == -1 && RouteActorIndex != -1)
	{
		SelectedRouteActorIndex = RouteActorIndex;
	}

	if (SelectedRouteActorIndex == -1)
	{
		SelectedRouteActorIndex = FMath::Rand() % AIController->GetRouteList().Num();
	}


	if (!AIController->GetRouteList().IsValidIndex(SelectedRouteActorIndex))
	{
		return EBTNodeResult::Failed;
	}

	AP3RouteActor* RouteActor = AIController->GetRouteList()[SelectedRouteActorIndex].RouteActor;

	if (BBKey_OutRouteActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_OutRouteActor.GetSelectedKeyID(), RouteActor);

		return EBTNodeResult::Succeeded;
	}

	return EBTNodeResult::Failed;
}

void UP3BTTask_GetRouteSpot::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_RouteActor.ResolveSelectedKey(*BBAsset);
		BBKey_SpotIndex.ResolveSelectedKey(*BBAsset);
		BBKey_OutLocation.ResolveSelectedKey(*BBAsset);
		BBKey_OutActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_GetRouteSpot::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	APawn* Pawn = AIController ? AIController->GetPawn() : nullptr;

	AP3RouteActor* RouteActor = nullptr;

	if (BBKey_RouteActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteActor = Cast<AP3RouteActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteActor.GetSelectedKeyID()));
	}

	if (!RouteActor)
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. Route actor is not set",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	if (!RouteActor->GetRouteComponent())
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. No route component found",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	int32 SpotIndex = -1;

	if (BBKey_SpotIndex.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
	{
		SpotIndex = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_SpotIndex.GetSelectedKeyID());
	}

	if (SpotIndex == -1)
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. Spot index is not set",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	if (!RouteActor->GetRouteComponent()->GetSpots().IsValidIndex(SpotIndex))
	{
		return EBTNodeResult::Failed;
	}

	AP3Spot* Spot = RouteActor->GetRouteComponent()->GetSpots()[SpotIndex];

	if (!ensure(Spot))
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. Spot is NULL",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	if (BBKey_OutLocation.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass())
	{
		MyBlackboard->SetValue<UBlackboardKeyType_Vector>(BBKey_OutLocation.GetSelectedKeyID(), Spot->GetActorLocation());
	}

	if (BBKey_OutActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_OutActor.GetSelectedKeyID(), Spot);
	}

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_GetRouteNumSpots::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_RouteActor.ResolveSelectedKey(*BBAsset);
		BBKey_OutNumSpots.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_GetRouteNumSpots::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	APawn* Pawn = AIController ? AIController->GetPawn() : nullptr;

	AP3RouteActor* RouteActor = nullptr;

	if (BBKey_RouteActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteActor = Cast<AP3RouteActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteActor.GetSelectedKeyID()));
	}

	if (!RouteActor)
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. Route actor is not set",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	if (!RouteActor->GetRouteComponent())
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. No route component found",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	if (BBKey_OutNumSpots.SelectedKeyType != UBlackboardKeyType_Int::StaticClass())
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. OutNumSpot is not integer type",
			TEXT("Pawn"), Pawn ? Pawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	MyBlackboard->SetValue<UBlackboardKeyType_Int>(BBKey_OutNumSpots.GetSelectedKeyID(), RouteActor->GetRouteComponent()->GetSpots().Num());

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_FindNearbySpotIndexOfMyRoute::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_RouteActor.ResolveSelectedKey(*BBAsset);
		BBKey_OutSpotIndex.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_FindNearbySpotIndexOfMyRoute::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	AP3RouteActor* RouteActor = nullptr;

	if (BBKey_RouteActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteActor = Cast<AP3RouteActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteActor.GetSelectedKeyID()));
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = AIController ? AIController->GetPawn() : nullptr;

	if (!MyPawn)
	{
		return EBTNodeResult::Failed;
	}

	if (!RouteActor)
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. Route actor is not set",
			TEXT("Pawn"), MyPawn ? MyPawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	if (!RouteActor->GetRouteComponent())
	{
		P3JsonLog(Warning, "BTTask Get route spot location failed. No route component found",
			TEXT("Pawn"), MyPawn ? MyPawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	const TArray<AP3Spot*> Spots = RouteActor->GetRouteComponent()->GetSpots();
	const int32 NumSpots = RouteActor->GetRouteComponent()->GetSpots().Num();

	// If the route actor has no spot, return failed.
	if (NumSpots <= 0)
	{
		return EBTNodeResult::Failed;
	}

	int32 NearestMyRouteSpotIndex = 0;
	float MinimumDistanceSpotToMe = 0.0f;

	// Find nearby spot index of my route
	for (int32 i = 0; i < NumSpots; i++ )
	{
		if (i == 0)
		{
			MinimumDistanceSpotToMe = (((Spots[0])->GetActorLocation()) - MyPawn->GetActorLocation()).Size();
		}

		const float NewDistanceSpotToMe = (((Spots[i])->GetActorLocation()) - MyPawn->GetActorLocation()).Size();

		if (NewDistanceSpotToMe < MinimumDistanceSpotToMe)
		{
			NearestMyRouteSpotIndex = i;
			MinimumDistanceSpotToMe = NewDistanceSpotToMe;
		}

		// If it doesn't need to find the nearest spot, just get the spot that is in minimum range and break loop.
		if (!bFindNearestSpot)
		{
			if (MinimumDistanceSpotToMe <= MininumRange)
			{
				NearestMyRouteSpotIndex = i;
				break;
			}
		}
	}

	if (!(RouteActor->GetRouteComponent()->GetSpots().IsValidIndex(NearestMyRouteSpotIndex)))
	{
		return EBTNodeResult::Failed;
	}

	if (BBKey_OutSpotIndex.SelectedKeyType != UBlackboardKeyType_Int::StaticClass())
	{
		P3JsonLog(Warning, "BTTask Get route spot index failed. The index is not integer type",
			TEXT("Pawn"), MyPawn ? MyPawn->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	MyBlackboard->SetValue<UBlackboardKeyType_Int>(BBKey_OutSpotIndex.GetSelectedKeyID(), NearestMyRouteSpotIndex);

	return EBTNodeResult::Succeeded;
}

UP3BTTask_GetRouteFromController::UP3BTTask_GetRouteFromController()
{
	BBKey_RouteIndex.AllowNoneAsValue(true);

	BBKey_RouteIndex.AddIntFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_GetRouteFromController, BBKey_RouteIndex));
	BBKey_OutRouteActor.AddObjectFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_GetRouteFromController, BBKey_OutRouteActor), AActor::StaticClass());
	BBKey_OutRouteTripType.AddEnumFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_GetRouteFromController, BBKey_OutRouteTripType), StaticEnum<EP3RouteTripType>());
	BBKey_OutRouteWalkType.AddEnumFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_GetRouteFromController, BBKey_OutRouteWalkType), StaticEnum<EP3RouteWalkType>());
}

void UP3BTTask_GetRouteFromController::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_RouteIndex.ResolveSelectedKey(*BBAsset);
		BBKey_OutRouteActor.ResolveSelectedKey(*BBAsset);
		BBKey_OutRouteTripType.ResolveSelectedKey(*BBAsset);
		BBKey_OutRouteWalkType.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_GetRouteFromController::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AP3AIController* AIController = Cast<AP3AIController>(OwnerComp.GetAIOwner());
	if (!AIController)
	{
		return EBTNodeResult::Failed;
	}

	if (AIController->GetRouteList().Num() == 0)
	{
		return EBTNodeResult::Failed;
	}

	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	APawn* Pawn = AIController->GetPawn();

	int32 SelectedRouteIndex = -1;

	if (BBKey_RouteIndex.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
	{
		SelectedRouteIndex = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_RouteIndex.GetSelectedKeyID());
	}

	if (SelectedRouteIndex == -1 && RouteIndex != -1)
	{
		SelectedRouteIndex = RouteIndex;
	}

	if (SelectedRouteIndex == -1)
	{
		SelectedRouteIndex = FMath::Rand() % AIController->GetRouteList().Num();
	}


	if (!AIController->GetRouteList().IsValidIndex(SelectedRouteIndex))
	{
		return EBTNodeResult::Failed;
	}

	AP3RouteActor* RouteActor = AIController->GetRouteList()[SelectedRouteIndex].RouteActor;
	EP3RouteTripType RouteTripType = AIController->GetRouteList()[SelectedRouteIndex].RouteTripType;
	EP3RouteWalkType RouteWalkType = AIController->GetRouteList()[SelectedRouteIndex].RouteWalkType;

	if (BBKey_OutRouteActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass()
		&& BBKey_OutRouteTripType.SelectedKeyType == UBlackboardKeyType_Enum::StaticClass()
		&& BBKey_OutRouteWalkType.SelectedKeyType == UBlackboardKeyType_Enum::StaticClass())
	{
		MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_OutRouteActor.GetSelectedKeyID(), RouteActor);
		MyBlackboard->SetValue<UBlackboardKeyType_Enum>(BBKey_OutRouteTripType.GetSelectedKeyID(), (uint8)RouteTripType);
		MyBlackboard->SetValue<UBlackboardKeyType_Enum>(BBKey_OutRouteWalkType.GetSelectedKeyID(), (uint8)RouteWalkType);

		return EBTNodeResult::Succeeded;
	}

	return EBTNodeResult::Failed;
}

UP3BTTask_RouteSpotMontageAction::UP3BTTask_RouteSpotMontageAction()
{
	BBKey_RouteSpotActor.AddObjectFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_RouteSpotMontageAction, BBKey_RouteSpotActor), AActor::StaticClass());
}

void UP3BTTask_RouteSpotMontageAction::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_RouteSpotActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_RouteSpotMontageAction::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return EBTNodeResult::Failed;
	}

	AP3Spot* RouteSpotActor = nullptr;

	if (BBKey_RouteSpotActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteSpotActor = Cast<AP3Spot>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteSpotActor.GetSelectedKeyID()));
	}

	if (!RouteSpotActor)
	{
		P3JsonLog(Warning, "BTTask Get route spot actor failed.",
			TEXT("Character"), MyCharacter ? MyCharacter->GetName() : TEXT("NULL"));
		return EBTNodeResult::Failed;
	}

	if (!(RouteSpotActor->DoUseMontageAction()))
	{
		// bSpotMontageAction is false. you have to use spot emote or toggle on bUseMontageAction
		return EBTNodeResult::Failed;
	}

	FName MontageActionName = RouteSpotActor->GetMontageActionName();

	// None이면 몽타지 검색하지 않고 바로 return false
	if (MontageActionName.IsNone())
	{
		return EBTNodeResult::Failed;
	}

	FP3PawnActionStartRequestParams Params;
	Params.CharacterMontage_Name = MontageActionName;

	EBTNodeResult::Type Result = StartAction(OwnerComp, NodeMemory, EPawnActionType::CharacterMontage, Params);

	return Result;
}

UP3BTTask_RouteSpotEmote::UP3BTTask_RouteSpotEmote()
{
	bNotifyTick = true;
	BBKey_RouteSpotActor.AddObjectFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTTask_RouteSpotEmote, BBKey_RouteSpotActor), AActor::StaticClass());
}

void UP3BTTask_RouteSpotEmote::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_RouteSpotActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_RouteSpotEmote::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return EBTNodeResult::Failed;
	}

	AP3Spot* RouteSpotActor = nullptr;

	if (BBKey_RouteSpotActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteSpotActor = Cast<AP3Spot>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteSpotActor.GetSelectedKeyID()));
	}

	if (!RouteSpotActor)
	{
		P3JsonLog(Warning, "BTTask Get route spot actor failed.",
			TEXT("Character"), MyCharacter->GetName());
		return EBTNodeResult::Failed;
	}

	if (RouteSpotActor->DoUseMontageAction())
	{
		// bSpotMontageAction is true. you have to use spot montage action or toggle off bUseMontageAction.
		return EBTNodeResult::Failed;
	}

	const FName RouteSpotEmoteName = RouteSpotActor->GetEmoteName();

	FBTRouteSpotEmoteTaskMemory* MyMemory = (FBTRouteSpotEmoteTaskMemory*)NodeMemory;
	MyMemory->TaskAgeSeconds = 0.0f;
	MyMemory->EmoteDurationSeconds = RouteSpotActor->GetEmoteDuration();

	SetCharacterEmote(OwnerComp, RouteSpotEmoteName);
	SetInEmote(OwnerComp, true);

	UAnimSequenceBase* EmoteStartAnimation = MyCharacter->GetEmote().EmoteAnimationStart;
	UAnimSequenceBase* EmoteEndAnimation = MyCharacter->GetEmote().EmoteAnimationEnd;

	MyMemory->EmoteStartAnimTotalSeconds = EmoteStartAnimation ? (EmoteStartAnimation->SequenceLength) : 0.0f;
	MyMemory->EmoteEndAnimTotalSeconds = EmoteEndAnimation ? (EmoteEndAnimation->SequenceLength) : 0.0f;

	// Emote Start Anim, Emote End Anim 보다 Spot 설정의 총 Emote 지속 시간이 짧게 설정된 경우, 에러를 띄우고 return Failed.
	if (((MyMemory->EmoteDurationSeconds) < (MyMemory->EmoteStartAnimTotalSeconds)) ||
		((MyMemory->EmoteDurationSeconds) < (MyMemory->EmoteEndAnimTotalSeconds)))
	{
		P3JsonLog(Error, "Emote Duration Seconds Setting is shorter than EmoteStartAnim or EmoteEndAnim.");
		return EBTNodeResult::Failed;
	}


	return EBTNodeResult::InProgress;
}

void UP3BTTask_RouteSpotEmote::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickTask(OwnerComp, NodeMemory, DeltaSeconds);

	FBTRouteSpotEmoteTaskMemory* MyMemory = (FBTRouteSpotEmoteTaskMemory*)NodeMemory;
	MyMemory->TaskAgeSeconds += DeltaSeconds;

	if ((MyMemory->EmoteEndAnimTotalSeconds) == 0.0f)
	{
		// End Animation이 없는 Non-Loop Emote 입니다.
		if ((MyMemory->TaskAgeSeconds) >= (MyMemory->EmoteStartAnimTotalSeconds))
		{
			SetInEmote(OwnerComp, false);
			SetCharacterEmote(OwnerComp, NAME_None);
			FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
			OnTaskFinished(OwnerComp, NodeMemory, EBTNodeResult::Succeeded);
		}
	}
	else
	{
		// End Animation이 있는 Loop Emote 입니다. End Animation Sequence 길이 만큼만 시간 여분을 남겨두어 마지막에 Loop-End Anim을 출력하도록 합니다.
		if ((MyMemory->TaskAgeSeconds) >= ((MyMemory->EmoteDurationSeconds)-(MyMemory->EmoteEndAnimTotalSeconds)))
		{
			if (!(MyMemory->HasInitializedEmote))
			{
				SetInEmote(OwnerComp, false);
				MyMemory->HasInitializedEmote = true;
			}

			if ((MyMemory->TaskAgeSeconds) >= (MyMemory->EmoteDurationSeconds))
			{
				// continue execution from this node
				SetCharacterEmote(OwnerComp, NAME_None);
				FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
				OnTaskFinished(OwnerComp, NodeMemory, EBTNodeResult::Succeeded);
			}
		}
	}
}

void UP3BTTask_RouteSpotEmote::OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult)
{
	Super::OnTaskFinished(OwnerComp, NodeMemory, TaskResult);

	FBTRouteSpotEmoteTaskMemory* MyMemory = (FBTRouteSpotEmoteTaskMemory*)NodeMemory;
	MyMemory->HasInitializedEmote = false;
}

EBTNodeResult::Type UP3BTTask_RouteSpotEmote::AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	FBTRouteSpotEmoteTaskMemory* MyMemory = (FBTRouteSpotEmoteTaskMemory*)NodeMemory;
	MyMemory->HasInitializedEmote = false;

	SetCharacterEmote(OwnerComp, NAME_None);

	return Super::AbortTask(OwnerComp, NodeMemory);
}

uint16 UP3BTTask_RouteSpotEmote::GetInstanceMemorySize() const
{
	return sizeof(FBTRouteSpotEmoteTaskMemory);
}

void UP3BTTask_RouteSpotEmote::SetInEmote(UBehaviorTreeComponent& OwnerComp, bool NewInEmote)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!Character)
	{
		return;
	}

	if (!Character->GetCommandComponent())
	{
		P3JsonLog(Error, "Failed setting ai controller emote task. No command component");
		return;
	}

	FP3CommandRequestParams Params;
	Params.SetInEmote_bInEmote = NewInEmote;

	Character->GetCommandComponent()->RequestCommand(UP3SetInEmoteCommand::StaticClass(), Params);
}

void UP3BTTask_RouteSpotEmote::SetCharacterEmote(UBehaviorTreeComponent& OwnerComp, FName InEmoteAnimName)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!Character)
	{
		P3JsonLog(Error, "Failed setting ai controller route spot emote task. No character");
		return;
	}

	if (!(Character->GetCommandComponent()))
	{
		P3JsonLog(Error, "Failed setting ai controller route spot emote task. No command component");
		return;
	}

	FP3CommandRequestParams Params;
	Params.SetEmoteByName_EmoteAnimName = InEmoteAnimName;

	Character->GetCommandComponent()->RequestCommand(UP3SetEmoteByNameCommand::StaticClass(), Params);
}
