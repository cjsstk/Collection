// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "P3BTTask_Aggro.generated.h"

/**
 * Reset Aggro for everyone
 */
UCLASS()
class P3_API UP3BTTask_ResetAggro : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/** If > 0, give initial aggro point from 0 to RandomRange - 1 */
	UPROPERTY(Category = Node, EditAnywhere)
	int32 RandomRange = 0;
};

/**
 * Reset Aggro for given actor
 */
UCLASS()
class P3_API UP3BTTask_ResetAggroOf : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/** blackboard for target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/** Remove from aggro list or just reset to 0 */
	UPROPERTY(Category = Node, EditAnywhere)
	uint32 bRemoveFromList : 1;

	/** If > 0, give initial aggro point from 0 to RandomRange - 1 */
	UPROPERTY(Category = Node, EditAnywhere)
	int32 RandomRange = 0;
};

/**
 * Make given actor to be top on aggro table
 */
UCLASS()
class P3_API UP3BTTask_MakeTopAggro : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/** blackboard for target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;
};
