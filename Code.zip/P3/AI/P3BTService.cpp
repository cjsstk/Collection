// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTService.h"

#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Enum.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Float.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Bool.h"

#include "Action/P3PawnActionComponent.h"
#include "AI/P3AIController.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3AggroComponent.h"
#include "P3Character.h"
#include "P3CharacterMovementComponent.h"
#include "P3Combat.h"
#include "P3CombatComponent.h"
#include "P3Log.h"
#include "P3WalkType.h"


void UP3BTService_UpdateWaitTimeBeforeAttack::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
		BBKey_WaitTimeBeforeAttack.ResolveSelectedKey(*BBAsset);
	}
}

void UP3BTService_UpdateWaitTimeBeforeAttack::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = MyAIController ? Cast<AP3Character>(MyAIController->GetPawn()) : nullptr;
	
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyCharacter && MyBlackboard)
	{
		AActor* TargetActor = nullptr;

		if (BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
		{
			TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));
		}

		float WaitTime = 0;

		if (TargetActor)
		{
			TArray<struct FOverlapResult> OverlappedResults;
			FCollisionObjectQueryParams QueryParams;
			FCollisionQueryParams CollisionQueryParams;
			FCollisionShape CollisionShape;

			QueryParams.AddObjectTypesToQuery(ECC_Pawn);
			CollisionShape.SetSphere(500);
			CollisionQueryParams.AddIgnoredActor(MyCharacter);
			CollisionQueryParams.AddIgnoredActor(TargetActor);

			GetWorld()->OverlapMultiByObjectType(OverlappedResults, MyCharacter->GetActorLocation(), FQuat::Identity, QueryParams, CollisionShape, CollisionQueryParams);

			TArray<AP3Character*> SameFactionCharacters;

			for (const FOverlapResult& OverlappedResult : OverlappedResults)
			{
				AActor* OverlappedActor = OverlappedResult.GetActor();

				if (!OverlappedActor)
				{
					continue;
				}

				AP3Character* OverlappedCharacter = Cast<AP3Character>(OverlappedActor);
				if (!OverlappedCharacter)
				{
					continue;
				}

				if (OverlappedCharacter->GetFaction() == MyCharacter->GetFaction())
				{
					SameFactionCharacters.AddUnique(OverlappedCharacter);
				}
			}

			const float GangBoost = (float)SameFactionCharacters.Num() / FMath::Max(1, MinSameFactionCharacterNum);

			const FVector Direction = (MyCharacter->GetActorLocation() - TargetActor->GetActorLocation()).GetSafeNormal2D();
			const FVector TargetForward = TargetActor->GetActorQuat().GetForwardVector();
			const float ForwardDotDirection = Direction | TargetForward;

			WaitTime = MaxWaitTime * FMath::Clamp(1.0f - ForwardDotDirection, 0.0f, 1.0f) * GangBoost;
			WaitTime = FMath::Clamp(WaitTime, 0.0f, MaxWaitTime);
		}

		MyBlackboard->SetValue<UBlackboardKeyType_Float>(BBKey_WaitTimeBeforeAttack.GetSelectedKeyID(), WaitTime);
	}
}

void UP3BTService_ResetAggro::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (FMath::RandHelper(100) >= ResetChance)
	{
		return;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return;
	}

	UP3AggroComponent* AggroComp = Character->GetAggroComponentBP();

	if (!AggroComp)
	{
		// Don't care if there is no aggro component
		return;
	}

	AggroComp->ResetAggro(RandomRange);
}

void UP3BTService_UpdateTarget::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

void UP3BTService_UpdateTarget::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return;
	}

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = MyAIController ? Cast<AP3Character>(MyAIController->GetPawn()) : nullptr;

	if (!ensure(MyCharacter))
	{
		return;
	}

	//GEngine->AddOnScreenDebugMessage(-1, 1.5, FColor::White, MyCharacter ? *MyCharacter->GetName() : TEXT("null"));

	AActor* NewTargetActor = P3Combat::FindTargetForAI(*MyCharacter, SearchRange, bSearchFrontOnly, AggroRangeLimit);

	MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID(), NewTargetActor);
}

void UP3BTService_CheckGameplayTag::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_HasTheGameplayTag.ResolveSelectedKey(*BBAsset);
	}
}

void UP3BTService_CheckGameplayTag::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = MyAIController ? Cast<AP3Character>(MyAIController->GetPawn()) : nullptr;

	if (!ensure(MyCharacter))
	{
		return;
	}

	// See if gameplaytag is exist
	if (CheckGameplayTags.Num() > 0)
	{
		IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(MyCharacter);
		if (GameplayTagAsset)
		{
			const bool bHasDropGameplayTag = GameplayTagAsset->HasAnyMatchingGameplayTags(CheckGameplayTags);

			UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
			if (MyBlackboard)
			{
				if (bHasDropGameplayTag)
				{
					MyBlackboard->SetValue<UBlackboardKeyType_Bool>(BBKey_HasTheGameplayTag.GetSelectedKeyID(), true);
				}
				else
				{
					MyBlackboard->SetValue<UBlackboardKeyType_Bool>(BBKey_HasTheGameplayTag.GetSelectedKeyID(), false);
				}
			}
		}
	}
}

UP3BTService_KeepReturningFromCombatStatus::UP3BTService_KeepReturningFromCombatStatus(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bNotifyBecomeRelevant = true;
	bNotifyCeaseRelevant = true;
}

void UP3BTService_KeepReturningFromCombatStatus::OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnBecomeRelevant(OwnerComp, NodeMemory);

	SetReturningFromCombatStatus(OwnerComp, true);
}

void UP3BTService_KeepReturningFromCombatStatus::OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnCeaseRelevant(OwnerComp, NodeMemory);

	SetReturningFromCombatStatus(OwnerComp, false);
}

void UP3BTService_KeepReturningFromCombatStatus::SetReturningFromCombatStatus(UBehaviorTreeComponent& OwnerComp, bool bReturningFromCombat)
{
	if (!OwnerComp.GetAIOwner())
	{
		P3JsonLog(Error, "Failed to set ReturningFromCombat. No ai owner");
		return;
	}

	AP3Character* Character = Cast<AP3Character>(OwnerComp.GetAIOwner()->GetPawn());
	if (!Character)
	{
		P3JsonLog(Error, "Failed to set ReturningFromCombat. No character");
		return;
	}

	UP3CommandComponent* CommandComp = Character->GetCommandComponent();
	if (!CommandComp)
	{
		P3JsonLog(Error, "Failed to set ReturningFromCombat. No command component");
		return;
	}

	AP3AIController* AIController = Cast<AP3AIController>(Character->GetController());
	if (!AIController)
	{
		P3JsonLog(Error, "Failed to set ReturningFromCombat. No ai controller");
		return;
	}

	if (bReturningFromCombat)
	{
		FP3CommandRequestParams Params;
		Params.Heal_bToMaxPoint = true;
		Character->GetCommandComponent()->RequestCommand(UP3HealCommand::StaticClass(), Params);
	}

	AIController->SetReturningFromCombat(bReturningFromCombat);
}

void UP3BTService_UpdateMainTargetOfTarget::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_OutMainTargetOfTargetActor.ResolveSelectedKey(*BBAsset);
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

void UP3BTService_UpdateMainTargetOfTarget::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();

	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		P3JsonLog(Error, "Failed to update target charactor's main target. No Blackboard");
		return;
	}

	AP3Character* TargetCharacter = nullptr;

	if (BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		TargetCharacter = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));
	}

	if (!TargetCharacter)
	{
		P3JsonLog(Error, "Failed to update target charactor's main target. No Target actor");
		return;
	}

	UP3CombatComponent* CombatComp = TargetCharacter->GetP3CombatComponentBP();
	if (!CombatComp)
	{
		P3JsonLog(Error, "Failed to update target charactor's main target. No Target actor's combat component");
		return;
	}

	AP3Character* MainTargetOfTargetCharacter = CombatComp->Server_GetMainTarget();

	// If the Target Character has no main target, just clear BBKey_MainTargetOfTargetActor
	if (!MainTargetOfTargetCharacter)
	{
		MyBlackboard->ClearValue(BBKey_OutMainTargetOfTargetActor.GetSelectedKeyID());
	}

	MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_OutMainTargetOfTargetActor.GetSelectedKeyID(), MainTargetOfTargetCharacter);
}

UP3BTService_KeepBlockingStatus::UP3BTService_KeepBlockingStatus(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bNotifyBecomeRelevant = true;
	bNotifyCeaseRelevant = true;
}

void UP3BTService_KeepBlockingStatus::OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnBecomeRelevant(OwnerComp, NodeMemory);

	SetBlockingStatus(OwnerComp, true);
}

void UP3BTService_KeepBlockingStatus::OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnCeaseRelevant(OwnerComp, NodeMemory);

	SetBlockingStatus(OwnerComp, false);
}

void UP3BTService_KeepBlockingStatus::SetBlockingStatus(UBehaviorTreeComponent& OwnerComp, bool bBlocking)
{
	if (!OwnerComp.GetAIOwner())
	{
		P3JsonLog(Error, "Failed to set Block Action. No ai owner");
		return;
	}

	AP3Character* Character = Cast<AP3Character>(OwnerComp.GetAIOwner()->GetPawn());
	if (!Character)
	{
		P3JsonLog(Error, "Failed to set blocking action. No character");
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ActionComp)
	{
		P3JsonLog(Error, "Failed to set blocking action. No action component", TEXT("Character"), Character->GetName());
		return;
	}

	UP3CommandComponent* CommandComp = Character->GetCommandComponent();
	if (!CommandComp)
	{
		P3JsonLog(Error, "Failed to set blocking action. No command component", TEXT("Character"), Character->GetName());
		return;
	}

	if (bBlocking)
	{
		ActionComp->StartAction(EPawnActionType::StartBlock, _FUNCTION_TEXT);
	}
	else
	{
		if (ActionComp->CanStartAction(EPawnActionType::StopBlock))
		{
			ActionComp->StartAction(EPawnActionType::StopBlock, _FUNCTION_TEXT);
		}
		else
		{
			// Use UP3SetBlockingCommand if the character cannot forcibly finish other actions (Combat Reaction Hit Action, CombatCombo, etc..)
			FP3CommandRequestParams Params;
			Params.SetBlocking_bNewBlocking = false;
			Character->GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), Params);
		}
	}

}

UP3BTService_KeepWalkingStatus::UP3BTService_KeepWalkingStatus()
{
	bNotifyBecomeRelevant = true;
	bNotifyCeaseRelevant = true;

	BBKey_RouteWalkType.AddEnumFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTService_KeepWalkingStatus, BBKey_RouteWalkType), StaticEnum<EP3RouteWalkType>());
}

void UP3BTService_KeepWalkingStatus::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_RouteWalkType.ResolveSelectedKey(*BBAsset);
	}
}

void UP3BTService_KeepWalkingStatus::OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnBecomeRelevant(OwnerComp, NodeMemory);

	SetWalkingStatus(OwnerComp, true);
}

void UP3BTService_KeepWalkingStatus::OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	Super::OnCeaseRelevant(OwnerComp, NodeMemory);

	SetWalkingStatus(OwnerComp, false);
}

void UP3BTService_KeepWalkingStatus::SetWalkingStatus(UBehaviorTreeComponent& OwnerComp, bool bDefinedWalking)
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = Cast<AP3Character>(MyAIController->GetPawn());

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find Character");
		return;
	}

	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		P3JsonLog(Warning, "Can not find BlackboardComponent", TEXT("Character"), MyCharacter->GetName());
		return;
	}

	if (BBKey_RouteWalkType.SelectedKeyType == UBlackboardKeyType_Enum::StaticClass())
	{
		RouteWalkType = (EP3RouteWalkType)(MyBlackboard->GetValue<UBlackboardKeyType_Enum>(BBKey_RouteWalkType.GetSelectedKeyID()));
	}

	if (RouteWalkType == EP3RouteWalkType::Walk)
	{
		return;
	}
	else if (RouteWalkType == EP3RouteWalkType::Stroll)
	{
		if (MyCharacter->GetP3CharacterMovementBP() && MyCharacter->GetCommandComponent())
		{
			FP3CommandRequestParams Params;
			Params.SetStroll_bStroll = bDefinedWalking;

			MyCharacter->GetCommandComponent()->RequestCommand(UP3SetStrollCommand::StaticClass(), Params);
		}
		else
		{
			P3JsonLog(Error, "Failed toggle stroll. No character or command component");
		}
	}
	else if (RouteWalkType == EP3RouteWalkType::Sprint)
	{
		if (MyCharacter->GetP3CharacterMovementBP())
		{
			MyCharacter->GetP3CharacterMovementBP()->SetSprint(bDefinedWalking);
		}
		else
		{
			P3JsonLog(Error, "Failed toggle on sprint. No character or movement component");
		}
	}
	else if (RouteWalkType == EP3RouteWalkType::Crippled)
	{
		if (MyCharacter->GetP3CharacterMovementBP() && MyCharacter->GetCommandComponent())
		{
			FP3CommandRequestParams Params;
			Params.SetCrippled_bCrippled = bDefinedWalking;

			MyCharacter->GetCommandComponent()->RequestCommand(UP3SetCrippledCommand::StaticClass(), Params);
		}
		else
		{
			P3JsonLog(Error, "Failed toggle cirppled run. No character or cor command component");
		}
	}

}
