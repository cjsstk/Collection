// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AIController.h"

#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/BlackboardComponent.h"

#include "P3AggroComponent.h"
#include "P3Character.h"
#include "P3Log.h"

static TAutoConsoleVariable<float> CVarP3ReturningFromCombatMaxDuration(
	TEXT("p3.returningFromCombatMaxDuration"),
	3.0f,
	TEXT("How long will 'returning from combat' status last in seconds? (0 means forever until idle)"), ECVF_Default);

AP3AIController::AP3AIController()
{
	for (int32 PointType = 0; PointType < (int32)EP3AIPointType::Count; ++PointType)	// -V1008
	{
		MaxPoints.Add((EP3AIPointType)PointType, 100);
	}
}

void AP3AIController::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaSeconds);
	}

	if (bReturningFromCombat)
	{
		ReturningFromCombatAgeSeconds += DeltaSeconds;

		const float MaxDuration = CVarP3ReturningFromCombatMaxDuration.GetValueOnGameThread();
		if (MaxDuration != 0.0f && ReturningFromCombatAgeSeconds > MaxDuration)
		{
			bReturningFromCombat = false;
			ReturningFromCombatAgeSeconds = 0;
		}
	}
}

/**
*   Super를 Override 함
*/
void AP3AIController::UpdateControlRotation(float DeltaTime, bool bUpdatePawn /*= true*/)
{
	APawn* const MyPawn = GetPawn();
	if (MyPawn)
	{
		FRotator NewControlRotation = GetControlRotation();

		// Look toward focus
		const FVector FocalPoint = GetFocalPoint();
		if (FAISystem::IsValidLocation(FocalPoint))
		{
			NewControlRotation = (FocalPoint - MyPawn->GetPawnViewLocation()).Rotation();
		}
		else if (bSetControlRotationFromPawnOrientation)
		{
			NewControlRotation = MyPawn->GetActorRotation();
		}

		AP3Character* MyCharacter = Cast<AP3Character>(GetPawn());
		const bool IsMeleeAiming = (MyCharacter->GetCharacterStoreBP()).bIsMeleeAiming;

		if (IsMeleeAiming)
		{
			// Look toward focus
			const FVector FocalGameplayPoint = GetFocalPointForPriority(EAIFocusPriority::Gameplay);
			if (FAISystem::IsValidLocation(FocalGameplayPoint))
			{
				NewControlRotation = (FocalGameplayPoint - MyPawn->GetPawnViewLocation()).Rotation();
			}
			else
			{
				NewControlRotation = GetControlRotation();
			}
		}

		// Don't pitch view unless looking at another pawn
		if (NewControlRotation.Pitch != 0 && Cast<APawn>(GetFocusActor()) == nullptr)
		{
			NewControlRotation.Pitch = 0.f;
		}

		SetControlRotation(NewControlRotation);

		if (bUpdatePawn)
		{
			const FRotator CurrentPawnRotation = MyPawn->GetActorRotation();

			if (CurrentPawnRotation.Equals(NewControlRotation, 1e-3f) == false)
			{
				MyPawn->FaceRotation(NewControlRotation, DeltaTime);
			}
		}
	}

}

void AP3AIController::OnHit(AActor* SourceActor, int32 Damage)
{
	if (GetPawn())
	{
		AP3Character* MyCharacter = Cast<AP3Character>(GetPawn());
		if (MyCharacter)
		{
			NumHit += 1;
		}
	}

	OnHitBP(SourceActor, Damage);
}

void AP3AIController::ResetAfterReturn()
{
	OnResetAfterReturnBP();

	if (GetPawn())
	{
		UP3AggroComponent* AggroComp = GetPawn()->FindComponentByClass<UP3AggroComponent>();

		if (AggroComp)
		{
			AggroComp->ClearAggro();
		}
	}
}

void AP3AIController::SetPointOfInterest(class AP3PointOfInterest* POI)
{
	PointOfInterest = POI;
}

void AP3AIController::SetRouteList(const TArray<FP3Route>& InRouteList)
{
	RouteList = InRouteList;
}

void AP3AIController::SetEmoteAnimName(const FName& InEmoteAnimName)
{
	EmoteAnimName = InEmoteAnimName;
}

void AP3AIController::AddForbiddenVolume(class AP3ForbiddenVolume* Volume)
{
	ForbiddenVolumes.AddUnique(Volume);
}

void AP3AIController::RemoveForbiddenVolume(class AP3ForbiddenVolume* Volume)
{
	ForbiddenVolumes.Remove(Volume);
}

bool AP3AIController::IsInForbiddenVolume() const
{
	return (ForbiddenVolumes.Num() > 0);
}

void AP3AIController::SetInAlert(bool bNewInAlert)
{
	if (IsInAlert() == bNewInAlert)
	{
		return;
	}

	bInAlert = bNewInAlert;
}

void AP3AIController::SetReturningFromCombat(bool bInReturningFromCombat)
{
	bReturningFromCombat = bInReturningFromCombat;
	ReturningFromCombatAgeSeconds = 0;
}

int32 AP3AIController::GetMaxPoint(EP3AIPointType PointType) const
{
	const int32* Point = MaxPoints.Find(PointType);

	if (Point)
	{
		return *Point;
	}

	return 0;
}

int32 AP3AIController::GetPoint(EP3AIPointType PointType) const
{
	const int32* Point = Points.Find(PointType);

	if (Point)
	{
		return *Point;
	}

	return 0;
}

int32 AP3AIController::AddPoint(EP3AIPointType PointType, int32 Point)
{
	int32& TotalPoint = Points.FindOrAdd(PointType);

	TotalPoint += Point;
	TotalPoint = FMath::Min(TotalPoint, GetMaxPoint(PointType));

	return TotalPoint;
}

void AP3AIController::SetPoint(EP3AIPointType PointType, int32 Point)
{
	int32& TotalPoint = Points.FindOrAdd(PointType);

	TotalPoint = Point;
	TotalPoint = FMath::Min(TotalPoint, GetMaxPoint(PointType));
}

FString AP3AIController::GetDebugString() const
{
	FString OutString;

	if (Blackboard)
	{
		static const FName TargetActorKey("TargetActor");

		AActor* TargetActor = Cast<AActor>(Blackboard->GetValue<UBlackboardKeyType_Object>(TargetActorKey));
		if (TargetActor)
		{
			AP3Character* TargetCharacter = Cast<AP3Character>(TargetActor);
			if (TargetCharacter)
			{
				OutString += TargetCharacter->GetCharacterStoreBP().DisplayName.ToString();
			}
			else
			{
				OutString += TargetActor->GetName();
			}
			
			APawn* MyPawn = GetPawn();

			if (MyPawn)
			{
				const float Distance = FVector::Distance(TargetActor->GetActorLocation(), MyPawn->GetActorLocation());
				OutString += FString::Printf(TEXT(" (%.1fm)"), *TargetActor->GetName(), Distance / 100.0f);
			}

			OutString += TEXT("\n");
		}
		else
		{
			OutString += "No target\n";
		}
	}




	for (auto&& Iter : Points)
	{
		OutString += FString::Printf(TEXT("[%s] %d\n"), *EnumToStringShort(EP3AIPointType, Iter.Key), Iter.Value);
	}

	return OutString;
}

bool AP3AIController::IsOverHit() const
{
	if (NumHit > OverNumHitThreshold)
	{
		return true;
	}

	return false;
}

void AP3AIController::SetForceTarget(AActor* Target)
{
	CommandForceTarget = Target;
}

void AP3AIController::Server_Tick(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (NumHit > OverNumHitThreshold)
	{
		TimeSinceOverHit += DeltaSeconds;

		if (TimeSinceOverHit > NumHitClearTimeSeconds)
		{
			NumHit = 0;
			TimeSinceOverHit = 0.0f;
		}
	}
}
