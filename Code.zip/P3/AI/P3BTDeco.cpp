// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTDeco.h"

#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Int.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Float.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Vector.h"

#include "Action/P3PawnActionComponent.h"
#include "AI/P3AIController.h"
#include "Chemical/P3FlammableComponent.h"
#include "Chemical/P3WetComponent.h"
#include "P3AggroComponent.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3CombatComponent.h"
#include "P3HealthPointComponent.h"
#include "P3HolderComponent.h"
#include "P3Log.h"
#include "P3Route.h"
#include "P3ServerWorld.h"
#include "P3Spot.h"
#include "P3StaminaPointComponent.h"
#include "P3Weapon.h"

UP3BTDeco_IsDead::UP3BTDeco_IsDead()
{
	bNotifyTick = true;
}

bool UP3BTDeco_IsDead::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (Character)
	{
		return Character->IsDead();
	}

	return false;
}


void UP3BTDeco_IsDead::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

void UP3BTDeco_IsOtherAIAttackingTarget::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsOtherAIAttackingTarget::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController->GetPawn();

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));
		
		if (!TargetActor)
		{
			return false;
		}

		TArray<struct FOverlapResult> OverlappedResults;
		FCollisionObjectQueryParams QueryParams;
		FCollisionShape CollisionShape;

		QueryParams.AddObjectTypesToQuery(ECC_Pawn);
		CollisionShape.SetSphere(SearchRange);

		GetWorld()->OverlapMultiByObjectType(OverlappedResults, MyPawn->GetActorLocation(), FQuat::Identity, QueryParams, CollisionShape);

		for (const FOverlapResult& OverlappedResult : OverlappedResults)
		{
			AActor* OverlappedActor = OverlappedResult.GetActor();

			if (!OverlappedActor)
			{
				continue;
			}

			APawn* OverlappedPawn = Cast<APawn>(OverlappedActor);
			if (!OverlappedPawn || !Cast<AAIController>(OverlappedPawn->Controller))
			{
				// Not an AI
				continue;
			}

			UP3PawnActionComponent* ActionComp = OverlappedActor->FindComponentByClass<UP3PawnActionComponent>();
			if (ActionComp && ActionComp->IsActionInProgress(EPawnActionType::CombatAttack))
			{
				// TODO: check if target is atually same
				return true;
			}
		}
	}

	return false;
}

UP3BTDeco_IsTargetInAttackRange::UP3BTDeco_IsTargetInAttackRange()
{
	bNotifyTick = true;
}

void UP3BTDeco_IsTargetInAttackRange::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
		BBKey_SkillIndex.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsTargetInAttackRange::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
	AP3Character* MyCharacter = Cast<AP3Character>(MyPawn);

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return false;
	}

	UP3CombatComponent* CombatComp = MyCharacter->GetP3CombatComponentBP();
	if (!CombatComp)
	{
		return false;
	}

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

		if (!TargetActor)
		{
			return false;
		}

		int32 SkillIndex = -1;

		if (BBKey_SkillIndex.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
		{
			SkillIndex = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_SkillIndex.GetSelectedKeyID());
		}

		if (CombatComp->IsActorInAttackRange(TargetActor, SkillIndex, RangeAddition))
		{
			return true;
		}

		return false;
	}

	return false;
}

void UP3BTDeco_IsTargetInAttackRange::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

void UP3BTDeco_IsMainTarget::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_SourceCharacter.ResolveSelectedKey(*BBAsset);
		BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsMainTarget::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard)
	{
		AP3Character* SourceCharacter = nullptr;
		AP3Character* TargetCharacter = nullptr;

		if (BBKey_SourceCharacter.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
		{
			SourceCharacter = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_SourceCharacter.GetSelectedKeyID()));
		}

		if (!SourceCharacter)
		{
			return false;
		}

		if (BBKey_TargetCharacter.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
		{
			TargetCharacter = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));
		}

		if (!TargetCharacter)
		{
			return false;
		}

		UP3CombatComponent* CombatComp = SourceCharacter->GetP3CombatComponentBP();
		if (!CombatComp)
		{
			return false;
		}

		if (CombatComp->Server_GetMainTarget() == TargetCharacter)
		{
			return true;
		}
	}

	return false;
}

bool UP3BTDeco_IsStance::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
	AP3Character* MyCharacter = Cast<AP3Character>(MyPawn);

	if (MyCharacter && MyCharacter->GetStance() == Stance)
	{
		return true;
	}

	return false;
}

UP3BTDeco_IsActionInProgress::UP3BTDeco_IsActionInProgress()
{
	bNotifyTick = true;
}

void UP3BTDeco_IsActionInProgress::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsActionInProgress::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		return false;
	}

	const AP3Character* ChoosenActorFromBBkey = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
	AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

	// If the target from Blackboard key is none, my character is set target character.
	const AP3Character* TargetCharacter = ChoosenActorFromBBkey ? ChoosenActorFromBBkey : MyCharacter;

	if (!TargetCharacter)
	{
		return false;
	}

	if (!TargetCharacter->GetActionComponent())
	{
		return false;
	}

	if (ActionType == EPawnActionType::Invalid)
	{
		if (TargetCharacter->GetActionComponent()->GetActiveActionType() != EPawnActionType::Invalid)
		{
			return true;
		}
	}
	else
	{
		if (TargetCharacter->GetActionComponent()->IsActionInProgress(ActionType))
		{
			return true;
		}
	}

	return false;

}

void UP3BTDeco_IsActionInProgress::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_IsKnockDowned::UP3BTDeco_IsKnockDowned()
{
	bNotifyTick = true;
}

void UP3BTDeco_IsKnockDowned::InitializeFromAsset(UBehaviorTree& Asset)
{
    Super::InitializeFromAsset(Asset);

    UBlackboardData* BBAsset = GetBlackboardAsset();
    if (ensure(BBAsset))
    {
        BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
    }
}

bool UP3BTDeco_IsKnockDowned::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
    const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
    if (MyBlackboard)
    {
		const AP3Character* ChoosenActorFromBBkey = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));

		AAIController* MyAIController = OwnerComp.GetAIOwner();
		APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
		AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

		// If the target from Blackboard key is none, my character is set target character.
		const AP3Character* TargetCharacter = ChoosenActorFromBBkey ? ChoosenActorFromBBkey : MyCharacter;

        if (TargetCharacter)
        {
            const bool bKnockDowned = TargetCharacter->IsKnockDowned();
            const bool bIsInKnockBack = TargetCharacter->GetActionComponent() ? TargetCharacter->GetActionComponent()->IsInKnockBack() : false;

            return bKnockDowned || bIsInKnockBack;
        }
    }

    return false;
}

void UP3BTDeco_IsKnockDowned::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

bool UP3BTDeco_CanUseSkill::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3CombatComponent* CombatComponent = Character ? Character->GetP3CombatComponentBP() : nullptr;

	if (CombatComponent)
	{
		return CombatComponent->Server_CanUseSkill(SkillIndex);
	}

	return false;
}

bool UP3BTDeco_HasRider::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (Character)
	{
		if (MountPointsIndex.Num() > 0)
		{
			int32 NumRiders = 0;
			for (int32 Index : MountPointsIndex)
			{
				if (Character->HasRiderOnMountPoint(Index))
				{
					NumRiders++;
				}
			}

			return (NumRiders >= ShouldHaveRidersNum) ? true : false;
		}
		else
		{
			const int32 NumMountPoints = Character->GetMountPoints().Num();
			for (int32 Index = 0; Index < NumMountPoints; ++Index)
			{
				if (Character->HasRiderOnMountPoint(Index))
				{
					return true;
				}
			}
		}
	}

	return false;
}

FString UP3BTDeco_HasRider::GetStaticDescription() const
{
	FString MountPointIndexs = *Super::GetStaticDescription() + FString("(");
	for (int32 Index : MountPointsIndex)
	{
		MountPointIndexs += FString::FromInt(Index) + FString(" ");
	}
	MountPointIndexs += FString(")");

	return MountPointIndexs;
}

void UP3BTDeco_HasHostileInCone::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	ConeHalfAngleDot = FMath::Cos(FMath::DegreesToRadians(ConeHalfAngle));
}

bool UP3BTDeco_HasHostileInCone::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3AggroComponent* AggroComp = Character ? Character->FindComponentByClass<UP3AggroComponent>() : nullptr;

	if (!AggroComp)
	{
		return false;
	}

	const FVector MyLocation = Character->GetActorLocation();
	const FVector ConeDirection = Character->GetActorRotation().RotateVector(LocalConeDirection);
	const float MinDistanceSquared = FMath::Square(MinDistance);
	const float MaxDistanceSquared = FMath::Square(MaxDistance);

	const TArray<AActor*> AggroActors = AggroComp->GetAllActors();
	for (const AActor* AggroActor : AggroActors)
	{
		if (!AggroActor)
		{
			continue;
		}

		const FVector TargetLocation = AggroActor->GetActorLocation();
		const FVector TargetDirection = TargetLocation - MyLocation;
		const float TargetDistanceSquared = TargetDirection.SizeSquared();

		if (TargetDistanceSquared < MinDistanceSquared)
		{
			continue;
		}

		if (TargetDistanceSquared > MaxDistanceSquared)
		{
			continue;
		}

		const float Dot = ConeDirection | (TargetDirection.GetSafeNormal());
		if (Dot < ConeHalfAngleDot)
		{
			continue;
		}

		return true;
	}

	return false;
}

UP3BTDeco_DistanceWithinRange::UP3BTDeco_DistanceWithinRange()
{
	BBKey_Source.AddObjectFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTDeco_DistanceWithinRange, BBKey_Source), AActor::StaticClass());
	BBKey_Source.AddVectorFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTDeco_DistanceWithinRange, BBKey_Source));
	BBKey_Target.AddObjectFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTDeco_DistanceWithinRange, BBKey_Target), AActor::StaticClass());
	BBKey_Target.AddVectorFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTDeco_DistanceWithinRange, BBKey_Target));
}

void UP3BTDeco_DistanceWithinRange::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_Source.ResolveSelectedKey(*BBAsset);
		BBKey_Target.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_DistanceWithinRange::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		return false;
	}

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController->GetPawn();
	if (!MyPawn)
	{
		return false;
	}

	FVector SourceLocation = MyPawn->GetActorLocation();
	AActor* SourceActor = MyPawn;

	if (BBKey_Source.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		SourceActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_Source.GetSelectedKeyID()));
		if (!SourceActor)
		{
			P3JsonLog(Warning, "Distance Within Range Decorator failed. Origin actor is NULL", TEXT("Pawn"), MyPawn->GetName());
			return false;
		}

		SourceLocation = SourceActor->GetActorLocation();
	}
	else if (BBKey_Source.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass())
	{
		SourceLocation = MyBlackboard->GetValue<UBlackboardKeyType_Vector>(BBKey_Source.GetSelectedKeyID());
	}
	else
	{
		P3JsonLog(Warning, "Distance Within Range Decorator failed. Key type is not actor or vector", TEXT("Pawn"), MyPawn->GetName());
		return false;
	}


	FVector TargetLocation = FVector::ZeroVector;

	if (BBKey_Target.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_Target.GetSelectedKeyID()));
		if (!TargetActor)
		{
			P3JsonLog(Warning, "Distance Within Range Decorator failed. Target actor is NULL", TEXT("Pawn"), MyPawn->GetName());
			return false;
		}

		TargetLocation = TargetActor->GetActorLocation();
	}
	else if (BBKey_Target.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass())
	{
		TargetLocation = MyBlackboard->GetValue<UBlackboardKeyType_Vector>(BBKey_Target.GetSelectedKeyID());
	}
	else
	{
		P3JsonLog(Warning, "Distance Within Range Decorator failed. Key type is not actor or vector", TEXT("Pawn"), MyPawn->GetName());
		return false;
	}

	const float MyScale = SourceActor->GetActorScale().X;
	const float DistanceSquared = (SourceLocation - TargetLocation).SizeSquared();

	if (MinRange >= 0)
	{
		const float ScaledMinRange = MultiplyMyScale ? MinRange * MyScale : MinRange;
		if (DistanceSquared < FMath::Square(ScaledMinRange))
		{
			return false;
		}
	}

	if (MaxRange >= 0)
	{
		const float ScaledMaxRange = MultiplyMyScale ? MaxRange * MyScale : MaxRange;
		if (DistanceSquared > FMath::Square(ScaledMaxRange))
		{
			return false;
		}
	}

	return true;
}

UP3BTDeco_IsDowned::UP3BTDeco_IsDowned()
{
	bNotifyTick = true;
}

void UP3BTDeco_IsDowned::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsDowned::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (Character)
	{
		return Character->IsDowned();
	}

	return false;
}

void UP3BTDeco_IsDowned::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_IsExhausted::UP3BTDeco_IsExhausted()
{
	bNotifyTick = true;
}

void UP3BTDeco_IsExhausted::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsExhausted::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3StaminaPointComponent* StaminaComponent = Character ? Character->GetStaminaComponent() : nullptr;

	if (StaminaComponent && StaminaComponent->IsExhausted())
	{
		return true;
	}

	return false;
}

void UP3BTDeco_IsExhausted::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_IsFlamed::UP3BTDeco_IsFlamed()
{
	bNotifyTick = true;
}

bool UP3BTDeco_IsFlamed::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3FlammableComponent* FlammableComponent = Character ? Character->GetFlammableComponent() : nullptr;

	if (FlammableComponent && FlammableComponent->IsInFire())
	{
		return true;
	}

	return false;
}

void UP3BTDeco_IsFlamed::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_IsInAlert::UP3BTDeco_IsInAlert()
{
	bNotifyTick = true;
}

bool UP3BTDeco_IsInAlert::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = AIController ? AIController->GetPawn() : nullptr;

	AP3AIController* P3AIController = MyPawn ? Cast<AP3AIController>(MyPawn->GetController()) : nullptr;
	if (P3AIController)
	{
		return P3AIController->IsInAlert();
	}

	return false;
}

void UP3BTDeco_IsInAlert::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_IsWet::UP3BTDeco_IsWet()
{
	bNotifyTick = true;
}

bool UP3BTDeco_IsWet::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3WetComponent* WetComponent = Character ? Character->GetWetComponent() : nullptr;

	if (WetComponent && WetComponent->IsWet())
	{
		return true;
	}

	return false;
}

void UP3BTDeco_IsWet::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_PercentageOfHealthPoint::UP3BTDeco_PercentageOfHealthPoint()
{
	bNotifyTick = true;
}

void UP3BTDeco_PercentageOfHealthPoint::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_PercentageOfHealthPoint::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
    if (MyBlackboard)
    {
		const AP3Character* ChoosenActorFromBBkey = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));

		AAIController* MyAIController = OwnerComp.GetAIOwner();
		APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
		AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

		// If the target from Blackboard key is none, my character is set target character.
		const AP3Character* TargetCharacter = ChoosenActorFromBBkey ? ChoosenActorFromBBkey : MyCharacter;

        if (TargetCharacter)
        {
			UP3HealthPointComponent* HealthPointComponent = TargetCharacter->GetP3HealthComponentBP();
			if (HealthPointComponent)
			{
				const int32 TargetMaxHealthPoint = HealthPointComponent->GetMaxHealthPoint();
				const int32 TargetCurrentHealthPoint = HealthPointComponent->GetHealthPoint();
				const int32 CurrentHealthPointPercentage = (TargetMaxHealthPoint != 0) ? FMath::RoundToInt((((float)TargetCurrentHealthPoint / (float)TargetMaxHealthPoint)) * 100) : 0;
				switch (Query)
				{
				case EP3ArithmeticKeyOperation::Equal:				return (CurrentHealthPointPercentage == HealthPointPercentage);
				case EP3ArithmeticKeyOperation::NotEqual:			return (CurrentHealthPointPercentage != HealthPointPercentage);
				case EP3ArithmeticKeyOperation::Less:				return (CurrentHealthPointPercentage < HealthPointPercentage);
				case EP3ArithmeticKeyOperation::LessOrEqual:		return (CurrentHealthPointPercentage <= HealthPointPercentage);
				case EP3ArithmeticKeyOperation::Greater:			return (CurrentHealthPointPercentage > HealthPointPercentage);
				case EP3ArithmeticKeyOperation::GreaterOrEqual:		return (CurrentHealthPointPercentage >= HealthPointPercentage);
				default: break;
				}
			}
			else
			{
				P3JsonLog(Error, "There is the Character, but can not find Health Point Component.", TEXT("Character"), TargetCharacter->GetName());
			}
        }
		else
		{
			P3JsonLog(Error, "Can not find Character.");
		}
    }
	else
	{
		P3JsonLog(Error, "Can not find Blackboard Component.");
	}

    return false;
}

void UP3BTDeco_PercentageOfHealthPoint::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_ConeCheck2DEx::UP3BTDeco_ConeCheck2DEx()
{
	ConeDirection.AllowNoneAsValue(true);

	bNotifyTick = true;
}

void UP3BTDeco_ConeCheck2DEx::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	ConeHalfAngleDot = FMath::Cos(FMath::DegreesToRadians(ConeHalfAngle));

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		ConeOrigin.ResolveSelectedKey(*BBAsset);
		ConeDirection.ResolveSelectedKey(*BBAsset);
		Observed.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_ConeCheck2DEx::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* BBComponent = OwnerComp.GetBlackboardComponent();

	FVector ConeDir;
	FVector DirectionToObserve;

	FRotator Offset = FRotator(0, ConeDirectionOffset, 0);

	return CalculateDirection(BBComponent, ConeOrigin, Observed, DirectionToObserve)
		&& CalculateDirection(BBComponent, ConeOrigin, ConeDirection, ConeDir)
		&& ConeDir.CosineAngle2D(Offset.RotateVector(DirectionToObserve)) > ConeHalfAngleDot;
}

bool UP3BTDeco_ConeCheck2DEx::CalculateDirection(const UBlackboardComponent* BlackboardComp, const FBlackboardKeySelector& Origin, const FBlackboardKeySelector& End, FVector& Direction) const
{
	FVector PointA = FVector::ZeroVector;
	FVector PointB = FVector::ZeroVector;
	FRotator Rotation = FRotator::ZeroRotator;

	if (BlackboardComp)
	{
		if (End.IsNone())
		{
			if (BlackboardComp->GetRotationFromEntry(Origin.GetSelectedKeyID(), Rotation))
			{
				Direction = Rotation.Vector();
				return true;
			}
		}
		else if (BlackboardComp->GetLocationFromEntry(Origin.GetSelectedKeyID(), PointA) && BlackboardComp->GetLocationFromEntry(End.GetSelectedKeyID(), PointB))
		{
			Direction = (PointB - PointA).GetSafeNormal();
			return true;
		}
	}

	return false;
}

void UP3BTDeco_ConeCheck2DEx::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_HasAttachParent::UP3BTDeco_HasAttachParent()
{
	bNotifyTick = true;
}

void UP3BTDeco_HasAttachParent::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_NearestWeapon.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_HasAttachParent::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard)
	{
		const AP3Weapon* NearestWeapon = Cast<AP3Weapon>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_NearestWeapon.GetSelectedKeyID()));
		if (NearestWeapon && NearestWeapon->GetAttachParentActor())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	return false;
}

void UP3BTDeco_HasAttachParent::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_HasWeapon::UP3BTDeco_HasWeapon()
{
	bNotifyTick = true;
}

void UP3BTDeco_HasWeapon::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_HasWeapon::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
	AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		P3JsonLog(Warning, "Can not find BlackboardComponent", TEXT("Character"), (MyCharacter ? MyCharacter->GetName() : TEXT("NULL")));
		return false;
	}
	const AP3Character* ChoosenActorFromBBkey = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));

	// If the target from Blackboard key is none, my character is set target character.
	const AP3Character* TargetCharacter = ChoosenActorFromBBkey ? ChoosenActorFromBBkey : MyCharacter;

	UP3HolderComponent* HolderComponent = TargetCharacter ? TargetCharacter->GetHolderComponentByHoldType(HoldType) : nullptr;
	if (!HolderComponent)
	{
		P3JsonLog(Warning, "Can not find HolderComponent of the character.", TEXT("Character"), (TargetCharacter ? TargetCharacter->GetName() : TEXT("NULL")), TEXT("Holder Type"), EnumToString(EP3HoldType, HoldType));
		return false;
	}

	bool bHasWeapon = false;
	AP3Weapon* HoldingWeapon = Cast<AP3Weapon>(HolderComponent->GetHoldingActor());

	if (HoldingWeapon)
	{
		bHasWeapon = true;

		if (bChooseWeaponType && (HoldingWeapon->GetWeaponType() != WeaponType))
		{
			bHasWeapon = false;
		}

		if (bChooseItemKey && (HoldingWeapon->GetItemKey() != (itemkey)ItemKey))
		{
			P3JsonLog(Warning, "Can not find Item that has the item key.", TEXT("Character"), (TargetCharacter ? TargetCharacter->GetName() : TEXT("NULL")), TEXT("Holder Type"), EnumToString(EP3HoldType, HoldType), TEXT("Input Item Key:"), ItemKey);

			bHasWeapon = false;
		}
	}

	return bHasWeapon;
}

void UP3BTDeco_HasWeapon::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

bool UP3BTDeco_RandomPercentage::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const int32 Min = 1;
	const int32 RandomIntegerMinToDenominator = FMath::RandRange(Min, Percentage_Denominator);

	if (RandomIntegerMinToDenominator <= Percentage_Numerator)
	{
		return true;
	}
	else
	{
		return false;
	}

}

void UP3BTDeco_IsValidRouteSpotIndex::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_RouteActor.ResolveSelectedKey(*BBAsset);
		BBKey_SpotIndex.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsValidRouteSpotIndex::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!MyBlackboard)
	{
		return false;
	}

	AP3RouteActor* RouteActor = nullptr;

	if (BBKey_RouteActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteActor = Cast<AP3RouteActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteActor.GetSelectedKeyID()));
	}

	if (!RouteActor || !RouteActor->GetRouteComponent())
	{
		return false;
	}

	int32 SpotIndex = -1;

	if (BBKey_SpotIndex.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
	{
		SpotIndex = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_SpotIndex.GetSelectedKeyID());
	}

	const bool bIsValidIndex = RouteActor->GetRouteComponent()->GetSpots().IsValidIndex(SpotIndex);

	return bIsValidIndex;
}

UP3BTDeco_PercentageOfStaminaPoint::UP3BTDeco_PercentageOfStaminaPoint()
{
	bNotifyTick = true;
}

void UP3BTDeco_PercentageOfStaminaPoint::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_PercentageOfStaminaPoint::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
    if (MyBlackboard)
    {
		const AP3Character* ChoosenActorFromBBkey = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));

		AAIController* MyAIController = OwnerComp.GetAIOwner();
		APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
		AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

		// If the target from Blackboard key is none, my character is set target character.
		const AP3Character* TargetCharacter = ChoosenActorFromBBkey ? ChoosenActorFromBBkey : MyCharacter;

        if (TargetCharacter)
        {
			UP3StaminaPointComponent* StaminaPointComponent = TargetCharacter->GetStaminaComponent();
			if (StaminaPointComponent)
			{
				const int32 TargetMaxStaminaPoint = StaminaPointComponent->GetMaxStaminaPoint();
				const int32 TargetCurrentStaminaPoint = StaminaPointComponent->GetStaminaPoint();
				const int32 CurrentStaminaPointPercentage = (TargetMaxStaminaPoint != 0) ? FMath::RoundToInt((((float)TargetCurrentStaminaPoint / (float)TargetMaxStaminaPoint)) * 100) : 0;
				switch (Query)
				{
				case EP3ArithmeticKeyOperation::Equal:				return (CurrentStaminaPointPercentage == StaminaPointPercentage);
				case EP3ArithmeticKeyOperation::NotEqual:			return (CurrentStaminaPointPercentage != StaminaPointPercentage);
				case EP3ArithmeticKeyOperation::Less:				return (CurrentStaminaPointPercentage < StaminaPointPercentage);
				case EP3ArithmeticKeyOperation::LessOrEqual:		return (CurrentStaminaPointPercentage <= StaminaPointPercentage);
				case EP3ArithmeticKeyOperation::Greater:			return (CurrentStaminaPointPercentage > StaminaPointPercentage);
				case EP3ArithmeticKeyOperation::GreaterOrEqual:		return (CurrentStaminaPointPercentage >= StaminaPointPercentage);
				default: break;
				}
			}
			else
			{
				P3JsonLog(Error, "There is the Character, but can not find Stamina Component.", TEXT("Character"), TargetCharacter->GetName());
			}
        }
		else
		{
			P3JsonLog(Error, "Can not find Character.");
		}
    }
	else
	{
		P3JsonLog(Error, "Can not find Blackboard Component.");
	}

    return false;
}

void UP3BTDeco_PercentageOfStaminaPoint::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_ProvokeLevel::UP3BTDeco_ProvokeLevel()
{
	bNotifyTick = true;
}

void UP3BTDeco_ProvokeLevel::InitializeFromAsset(UBehaviorTree& Asset)
{

}

bool UP3BTDeco_ProvokeLevel::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3CharacterEffectComponent* EffectComp = Character ? Character->GetEffectComponent() : nullptr;
	if (!EffectComp)
	{
		return false;
	}

	int32 CurrentProvokeLevel = EffectComp->GetBuffProvokeLevel();

	switch (Query)
	{
	case EP3ArithmeticKeyOperation::Equal:				return (CurrentProvokeLevel == ProvokeLevel);
	case EP3ArithmeticKeyOperation::NotEqual:			return (CurrentProvokeLevel != ProvokeLevel);
	case EP3ArithmeticKeyOperation::Less:				return (CurrentProvokeLevel < ProvokeLevel);
	case EP3ArithmeticKeyOperation::LessOrEqual:		return (CurrentProvokeLevel <= ProvokeLevel);
	case EP3ArithmeticKeyOperation::Greater:			return (CurrentProvokeLevel > ProvokeLevel);
	case EP3ArithmeticKeyOperation::GreaterOrEqual:		return (CurrentProvokeLevel >= ProvokeLevel);
	default: break;
	}

	return false;
}

void UP3BTDeco_ProvokeLevel::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_IsInForbiddenVolume::UP3BTDeco_IsInForbiddenVolume()
{
	bNotifyTick = true;
}

bool UP3BTDeco_IsInForbiddenVolume::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AP3AIController* AIController = Cast<AP3AIController>(OwnerComp.GetAIOwner());
	if (!AIController)
	{
		return false;
	}

	return AIController->IsInForbiddenVolume();
}

void UP3BTDeco_IsInForbiddenVolume::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_IsOverHit::UP3BTDeco_IsOverHit()
{
	bNotifyTick = true;
}

bool UP3BTDeco_IsOverHit::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const AP3AIController* MyAIController = Cast<AP3AIController>(OwnerComp.GetAIOwner());

	if (!MyAIController)
	{
		return false;
	}

	return MyAIController->IsOverHit();
}

void UP3BTDeco_IsOverHit::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_ActionCount::UP3BTDeco_ActionCount()
{
	bNotifyTick = true;
}

bool UP3BTDeco_ActionCount::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return false;
	}

	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(*this);

	if (!ServerWorld)
	{
		return false;
	}

	const TArray<class AP3Character*>& Characters = ServerWorld->GetCharacters();

	int32 CurrentActionCount = 0;

	for (AP3Character* Character : Characters)
	{
		if (!Character)
		{
			continue;
		}

		if (!Character->IsPlayerControlled())
		{
			continue;
		}

		const FVector CharacterToMyCharacter = Character->GetActorLocation() - MyCharacter->GetActorLocation();

		// If the PC is out of my search range, do not consider the PC.
		if (CharacterToMyCharacter.SizeSquared() > (SearchRange * SearchRange))
		{
			continue;
		}

		if (!Character->GetActionComponent())
		{
			continue;
		}

		if (ActionType == EPawnActionType::Invalid)
		{
			if (Character->GetActionComponent()->GetActiveActionType() != EPawnActionType::Invalid)
			{
				CurrentActionCount += 1;
			}
		}
		else
		{
			if (Character->GetActionComponent()->IsActionInProgress(ActionType))
			{
				CurrentActionCount += 1;
			}
		}
	}

	switch (ActionCount_Query)
	{
	case EP3ArithmeticKeyOperation::Equal:				return (CurrentActionCount == ActionCount);
	case EP3ArithmeticKeyOperation::NotEqual:			return (CurrentActionCount != ActionCount);
	case EP3ArithmeticKeyOperation::Less:				return (CurrentActionCount < ActionCount);
	case EP3ArithmeticKeyOperation::LessOrEqual:		return (CurrentActionCount <= ActionCount);
	case EP3ArithmeticKeyOperation::Greater:			return (CurrentActionCount > ActionCount);
	case EP3ArithmeticKeyOperation::GreaterOrEqual:		return (CurrentActionCount >= ActionCount);
	default: break;
	}

	return false;
}

void UP3BTDeco_ActionCount::TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	Super::TickNode(OwnerComp, NodeMemory, DeltaSeconds);

	if (CalculateRawConditionValue(OwnerComp, NodeMemory) == IsInversed())
	{
		OwnerComp.RequestExecution(this);
	}
}

UP3BTDeco_CharacterCount::UP3BTDeco_CharacterCount()
{
	bNotifyTick = true;
}

void UP3BTDeco_CharacterCount::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetCharacter.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_CharacterCount::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
	AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return false;
	}

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		P3JsonLog(Warning, "Can not find BlackboardComponent", TEXT("Character"), MyCharacter->GetName());
		return false;
	}

	const AP3Character* ChoosenActorFromBBkey = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetCharacter.GetSelectedKeyID()));

	// If the target from Blackboard key is none, my character is set target character.
	const AP3Character* TargetCharacter = ChoosenActorFromBBkey ? ChoosenActorFromBBkey : MyCharacter;

	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(*this);

	if (!ServerWorld)
	{
		return false;
	}

	const TArray<class AP3Character*>& Characters = ServerWorld->GetCharacters();

	int32 CurrentSearchedActorCount = 0;

	for (AP3Character* Character : Characters)
	{
		if (!Character)
		{
			continue;
		}

		// Except target actor as center of search
		if (Character == TargetCharacter)
		{
			continue;
		}

		// If my character doesn't have to search allies, then skip same faction.
		if (!bSearchIncludeMyAllies && (Character->GetFaction() == MyCharacter->GetFaction()))
		{
			continue;
		}

		// If bSearchIncludeMyAllies is true but bSearchIncludeMe is false, except owner
		if (bSearchIncludeMyAllies && !bSearchIncludeMe && Character == MyCharacter)
		{
			continue;
		}

		const FVector CharacterToTargetCharacter = Character->GetActorLocation() - TargetCharacter->GetActorLocation();

		// If the PC is out of my smaller search range, do not consider the PC.
		if ((SearchRange >= 0) && (CharacterToTargetCharacter.SizeSquared() > (SearchRange * SearchRange)))
		{
			continue;
		}
		else
		{
			CurrentSearchedActorCount += 1;
		}
	}

	switch (ActorCount_Query)
	{
	case EP3ArithmeticKeyOperation::Equal:				return (CurrentSearchedActorCount == SearchedCharacterCount);
	case EP3ArithmeticKeyOperation::NotEqual:			return (CurrentSearchedActorCount != SearchedCharacterCount);
	case EP3ArithmeticKeyOperation::Less:				return (CurrentSearchedActorCount < SearchedCharacterCount);
	case EP3ArithmeticKeyOperation::LessOrEqual:		return (CurrentSearchedActorCount <= SearchedCharacterCount);
	case EP3ArithmeticKeyOperation::Greater:			return (CurrentSearchedActorCount > SearchedCharacterCount);
	case EP3ArithmeticKeyOperation::GreaterOrEqual:		return (CurrentSearchedActorCount >= SearchedCharacterCount);
	default: break;
	}

	return false;
}

UP3BTDeco_RayTest::UP3BTDeco_RayTest()
{
	bNotifyTick = false;

	// can't abort, it's not observing anything
	bAllowAbortLowerPri = false;
	bAllowAbortNone = false;
	bAllowAbortChildNodes = false;
	FlowAbortMode = EBTFlowAbortMode::None;
}

void UP3BTDeco_RayTest::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_SourceActor.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_RayTest::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	AAIController* MyAIController = OwnerComp.GetAIOwner();
	APawn* MyPawn = MyAIController ? MyAIController->GetPawn() : nullptr;
	AP3Character* MyCharacter = MyPawn ? Cast<AP3Character>(MyPawn) : nullptr;

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (!MyBlackboard)
	{
		P3JsonLog(Warning, "Can not find BlackboardComponent", TEXT("Character"), (MyCharacter ? MyCharacter->GetName() : TEXT("NULL")));
		return false;
	}
	const AActor* SourceActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_SourceActor.GetSelectedKeyID()));

	if (!SourceActor)
	{
		return false;
	}

	UWorld* World = SourceActor->GetWorld();

	if (!World)
	{
		return false;
	}

	const FVector RayStart = SourceActor->GetActorLocation();
	const FVector RayEnd = SourceActor->GetActorLocation() + (SourceActor->GetActorForwardVector() * Distance);

	FCollisionQueryParams QueryParams;
	TArray<AActor*> ChildActors;
	SourceActor->GetAllChildActors(ChildActors);
	QueryParams.AddIgnoredActor(SourceActor);
	QueryParams.AddIgnoredActors(ChildActors);

	FHitResult HitResult;
	const bool bHit = World->LineTraceSingleByChannel(HitResult, RayStart, RayEnd, TraceChannel, QueryParams);

	return bHit;
}

UP3BTDeco_IsValidRouteSpotMontageAction::UP3BTDeco_IsValidRouteSpotMontageAction()
{
	BBKey_RouteSpotActor.AddObjectFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTDeco_IsValidRouteSpotMontageAction, BBKey_RouteSpotActor), AActor::StaticClass());
}

void UP3BTDeco_IsValidRouteSpotMontageAction::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_RouteSpotActor.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsValidRouteSpotMontageAction::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!MyBlackboard)
	{
		return false;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return false;
	}

	AP3Spot* RouteSpotActor = nullptr;

	if (BBKey_RouteSpotActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteSpotActor = Cast<AP3Spot>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteSpotActor.GetSelectedKeyID()));
	}

	if (!RouteSpotActor)
	{
		P3JsonLog(Warning, "BTDeco Get route spot actor failed.",
			TEXT("Character"), MyCharacter ? MyCharacter->GetName() : TEXT("NULL"));
		return false;
	}

	FName MontageActionName = RouteSpotActor->GetMontageActionName();

	// None이면 몽타지 검색하지 않고 바로 return false
	if (MontageActionName.IsNone())
	{
		return false;
	}

	FP3PawnActionStartRequestParams Params;
	Params.CharacterMontage_Name = MontageActionName;

	const FP3CharacterMontageActionDesc* Desc = MyCharacter->GetMontageActionDescs().Find(MontageActionName);

	if (!Desc)
	{
		P3JsonLog(Warning, "Can't find action desc",
			TEXT("Name"), MontageActionName.ToString());
		return false;
	}

	if (Desc->AnimMontage)
	{
		return true;
	}

	return false;
}

UP3BTDeco_IsValidRouteSpotEmote::UP3BTDeco_IsValidRouteSpotEmote()
{
	BBKey_RouteSpotActor.AddObjectFilter(this, GET_MEMBER_NAME_CHECKED(UP3BTDeco_IsValidRouteSpotEmote, BBKey_RouteSpotActor), AActor::StaticClass());
}

void UP3BTDeco_IsValidRouteSpotEmote::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_RouteSpotActor.ResolveSelectedKey(*BBAsset);
	}
}

bool UP3BTDeco_IsValidRouteSpotEmote::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!MyBlackboard)
	{
		return false;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!MyCharacter)
	{
		P3JsonLog(Warning, "Can not find AIOwnerCharacter");
		return false;
	}

	AP3Spot* RouteSpotActor = nullptr;

	if (BBKey_RouteSpotActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		RouteSpotActor = Cast<AP3Spot>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_RouteSpotActor.GetSelectedKeyID()));
	}

	if (!RouteSpotActor)
	{
		P3JsonLog(Warning, "BTDeco Get route spot actor failed.",
			TEXT("Character"), MyCharacter ? MyCharacter->GetName() : TEXT("NULL"));
		return false;
	}

	const FName RouteSpotAction = RouteSpotActor->GetEmoteName();

	if (MyCharacter->FindEmoteByName(RouteSpotAction))
	{
		return true;
	}

	return false;
}
