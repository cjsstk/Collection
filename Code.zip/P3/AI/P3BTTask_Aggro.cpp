// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_Aggro.h"

#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"

#include "P3AggroComponent.h"
#include "P3Character.h"

EBTNodeResult::Type UP3BTTask_ResetAggro::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	UP3AggroComponent* AggroComp = Character->GetAggroComponentBP();

	if (!AggroComp)
	{
		// Don't care if there is no aggro component
		return EBTNodeResult::Succeeded;
	}

	AggroComp->ResetAggro(RandomRange);

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_ResetAggroOf::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_ResetAggroOf::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!MyBlackboard
		|| BBKey_TargetActor.SelectedKeyType != UBlackboardKeyType_Object::StaticClass())
	{
		return EBTNodeResult::Failed;
	}

	AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

	if (!TargetActor)
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	UP3AggroComponent* AggroComp = Character->GetAggroComponentBP();

	if (!AggroComp)
	{
		// Don't care if there is no aggro component
		return EBTNodeResult::Succeeded;
	}

	if (bRemoveFromList)
	{
		AggroComp->RemoveAggroOf(*TargetActor);
	}
	else
	{
		AggroComp->ResetAggroOf(*TargetActor, RandomRange);
	}

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_MakeTopAggro::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_MakeTopAggro::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!MyBlackboard
		|| BBKey_TargetActor.SelectedKeyType != UBlackboardKeyType_Object::StaticClass())
	{
		return EBTNodeResult::Failed;
	}

	AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

	if (!TargetActor)
	{
		return EBTNodeResult::Failed;
	}

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;
	UP3AggroComponent* AggroComp = Character ? Character->GetAggroComponentBP() : nullptr;

	if (!AggroComp)
	{
		// Don't care if there is no aggro component
		return EBTNodeResult::Succeeded;
	}

	AggroComp->MakeAsTop(*TargetActor);

	return EBTNodeResult::Succeeded;
}
