// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "BehaviorTree/Tasks/BTTask_MoveTo.h"
#include "Action/P3PawnAction.h"
#include "AI/P3AIController.h"
#include "P3BTTask.generated.h"


struct FBTActionBaseMemory
{
	int32 RequestedActionId = 0;
};

struct FBTCharacterEmoteTaskMemory
{
	/** time left */
	float TaskAgeSeconds;

	float EmoteDurationSeconds = 0.0f;
	float EmoteStartAnimTotalSeconds = 0.0f;
	float EmoteEndAnimTotalSeconds = 0.0f;
	bool HasInitializedEmote = false;
};

UENUM()
enum class EP3WalkPostureType : uint8
{
	/** Don't affect the walk posture. Walk posture will be maintained current posture. */
	WalkPosture_Default 		UMETA(DisplayName="Unchanged"),

	/** Toggle on walk posture. Current walk posture will be come back after the MoveToEx task */
	WalkPosture_On 				UMETA(DisplayName="On"),

	/** Toggle off walk posture. Current walk posture will be returned after the MoveToEx task */
	WalkPosture_Off 			UMETA(DisplayName="Off"),
};

UENUM()
namespace EP3ArithmeticCalculation
{
	enum Type
	{
		Addition		UMETA(DisplayName = "+"),
		Subtraction		UMETA(DisplayName = "-"),
		Multiplication	UMETA(DisplayName = "*"),
		Division		UMETA(DisplayName = "/"),
	};
}

/**
 * Action
 */
UCLASS()
class P3_API UP3BTTask_Action : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
protected:
	UPROPERTY(Category = Node, EditAnywhere)
	EPawnActionType ActionType = EPawnActionType::Invalid;
};


/**
 * Move To Ex
 * This BTTask can change walk posture.
 */
UCLASS()
class P3_API UP3BTTask_MoveToEx : public UBTTask_MoveTo
{
	GENERATED_BODY()

public:
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult) override;
	bool EnumToBoolForSettingWalkPosture(EP3WalkPostureType WalkPosture);

protected:
	UPROPERTY(EditAnywhere, Category = P3)
	EP3WalkPostureType SetSprint = EP3WalkPostureType::WalkPosture_Default;

	UPROPERTY(EditAnywhere, Category = P3)
	EP3WalkPostureType SetCrippled = EP3WalkPostureType::WalkPosture_Default;

	UPROPERTY(EditAnywhere, Category = P3)
	EP3WalkPostureType SetMeleeAiming = EP3WalkPostureType::WalkPosture_Default;

private:
	bool WasSprintBeforeTask = false;
	bool WasCrippledBeforeTask = false;
	bool WasMeleeAimingBeforeTask = false;
};



/**
 * Wait for actions to be finished
 */
UCLASS()
class P3_API UP3BTTask_WaitForNoAction : public UBTTaskNode
{
	GENERATED_BODY()

	UP3BTTask_WaitForNoAction();

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};

UCLASS()
class P3_API UP3BTTask_GetAggroTopActor : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:

	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;
};

/**
 * Consider Skill
 */
UCLASS()
class P3_API UP3BTTask_ConsiderSkill : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
protected:
	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_OutSkillIndex;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

private:
	void ChangeTargetFarthestInAggroList(UBlackboardComponent& MyBlackboard, const AP3Character& Character);
};

/**
 * Select Random Buck Skill
 */
UCLASS()
class P3_API UP3BTTask_SelectRandomBuckSkill : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
protected:
	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_OutSkillIndex;
};

/**
 * Change Stance
 */
UCLASS()
class P3_API UP3BTTask_ChangeStance : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
private:
	UPROPERTY(Category = Node, EditAnywhere)
	EP3CharacterStance Stance = EP3CharacterStance::Idle;
};

/**
 * Toggle Sprint
 */
UCLASS()
class P3_API UP3BTTask_ToggleSprint : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
private:
	UPROPERTY(Category = Node, EditAnywhere)
	bool bSprint = true;
};

/**
 * Set Crippled Run
 */
UCLASS()
class P3_API UP3BTTask_SetCrippled : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
private:
	UPROPERTY(Category = Node, EditAnywhere)
	bool bCrippled = true;
};

/**
 * Action Base
 * helper class to support task keep ticking until Action finishes or fails
 */
UCLASS()
class P3_API UP3BTTask_ActionBase : public UBTTaskNode
{
	GENERATED_BODY()

public:
	UP3BTTask_ActionBase();

protected:
	EBTNodeResult::Type StartAction(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EPawnActionType ActionType, const struct FP3PawnActionStartRequestParams& Params);

	virtual void TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
	virtual EBTNodeResult::Type AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual uint16 GetInstanceMemorySize() const override;

private:
	virtual void OnMessage(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, FName Message, int32 RequestID, bool bSuccess) override;
};

/**
 * Montage Action
 */

UCLASS()
class P3_API UP3BTTask_MontageAction : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	
private:
	UPROPERTY(EditAnywhere)
	FName MontageActionName;
};

/**
 * Drop Holdable
 */
UCLASS()
class P3_API UP3BTTask_DropHoldable : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(Category = Node, EditAnywhere)
	EP3HoldType HoldType = EP3HoldType::LeftHand;
};


/**
 * Toggle Alert
 */
UCLASS()
class P3_API UP3BTTask_SetAlert : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(Category = Node, EditAnywhere)
	bool bInAlert = true;
};


/**
 * Set Alert Around
 */
UCLASS()
class P3_API UP3BTTask_SetAlertAround : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(Category = Node, EditAnywhere)
	float AlertRange = 100.0f;

	/**
	 * If the pawn that is around the owner(Instigator) has any of these gameplaytags, the pawn is set alert
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer IncludedGameplayTagsAny;

	/**
	 * the character that is around the owner(Instigator) has any of these gameplaytags, they cannot be set in alert.
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer ExcludedGameplaytagsAny;

	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_AlertActor;
};


/**
 * Add Gameplay Tag
 */
UCLASS()
class P3_API UP3BTTask_AddGameplayTag : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/** blackboard for target actor */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

private:
	UPROPERTY(Category = GameplayTag, EditAnywhere)
	FGameplayTagContainer GameplayTags;
};


/**
 * Remove Gameplay Tag
 */
UCLASS()
class P3_API UP3BTTask_RemoveGameplayTag : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/** blackboard for target actor */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

private:
	UPROPERTY(Category = GameplayTag, EditAnywhere)
	FGameplayTagContainer GameplayTags;
};


/**
 * Suicide
 */
UCLASS()
class P3_API UP3BTTask_Suicide : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
};


/**
 * Find a Holdable
 */
UCLASS()
class P3_API UP3BTTask_FindHoldable : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 100.0f;

	UPROPERTY(Category = P3, EditAnywhere)
	EP3HoldType HoldType = EP3HoldType::RightHand;

	UPROPERTY(Category = P3, EditAnywhere)
	EP3WeaponType WeaponType = EP3WeaponType::None;

	/**
	 * If the weapon that is around the owner acter has any of these gameplaytags, the weapon can be picked up.
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer IncludedGameplayTagsAny;

	/**
	 * the weapon that is around the owner acter has any of these gameplaytags, the weapon cannot be picked up.
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer ExcludedGameplaytagsAny;

	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_NearestWeaponActor;
};


/**
 * Pick up Holdable
 */
UCLASS()
class P3_API UP3BTTask_PickUpHoldable : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	UP3BTTask_PickUpHoldable();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_NearestWeaponActor;

	UPROPERTY(Category = P3, EditAnywhere)
	EP3HoldType HoldType = EP3HoldType::RightHand;
};

/**
 * Change MaterialValue
 */
UCLASS()
class P3_API UP3BTTask_ChangeMaterialValue : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(Category = Node, EditAnywhere)
	FName ParameterName = NAME_None;
	
	UPROPERTY(Category = Node, EditAnywhere)
	float ParameterFloat = 0.f;
};

/**
 * Print debug message on screen
 */
UCLASS()
class P3_API UP3BTTask_PrintDebugMessage : public UBTTaskNode
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(Category = Node, EditAnywhere)
	FString Message;

	UPROPERTY(Category = Node, EditAnywhere)
	int32 Key = -1;

	UPROPERTY(Category = Node, EditAnywhere)
	float TimeToDisplayInSeconds = 1.0f;

	UPROPERTY(Category = Node, EditAnywhere)
	FColor DisplayColor = FColor::White;
};

/**
 * Get the number of actors around target (calculate except target)
 */
UCLASS()
class P3_API UP3BTTask_CharacterCount : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	/** blackboard key selector: Center of Search*/
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetCharacter;

	/** blackboard key selector: Output */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_OutNumActor;

	/** If set -1, min will not be checked */
	UPROPERTY(EditAnywhere, Category = P3)
	float SearchRange = -1;

	/** If true, search actors include allies of behavior tree owner */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bSearchIncludeMyAllies = false;

	/** If true, search actors include behavior tree owner */
	UPROPERTY(EditAnywhere, Category = P3, meta=(EditCondition="bSearchIncludeMyAllies"))
	bool bSearchIncludeMe = false;
};

/**
 * The arithmetic operation of two blackboard keys
 * In this case, arithmetic is used as a noun. The mathematics of two black board entries under the operations of addition, subtraction, multiplication, and division.
 */
UCLASS()
class P3_API UP3BTTask_ArithmeticOfTwoBBEntries : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	UP3BTTask_ArithmeticOfTwoBBEntries();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	float GetFloatNumberFromBBkey(UBlackboardComponent& Blackboard, APawn& Pawn, struct FBlackboardKeySelector BBkey_Number) const;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_FirstNumber;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	TEnumAsByte<EP3ArithmeticCalculation::Type> Calculation_Query;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_SecondNumber;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = P3)
	struct FBlackboardKeySelector BBKey_OutResultNumber;
};

UCLASS()
class P3_API UP3BTTask_AddAIPoint : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	EP3AIPointType PointType = EP3AIPointType::Rage;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	int32 Point = 0;
};

UCLASS()
class P3_API UP3BTTask_SetAIPoint : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	EP3AIPointType PointType = EP3AIPointType::Rage;

	/** ArithmeticKeyOperation Query */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	int32 Point = 0;
};

/**
*  캐릭터 정면 방향으로 Input 이동을 시켜주는 BTTask
*/
UCLASS()
class P3_API UP3BTTask_MovementInputForward : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	UP3BTTask_MovementInputForward();

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
};

/**
*  캐릭터 Emote를 설정합합니다.
*/
UCLASS()
class P3_API UP3BTTask_SetCharacterEmote : public UBTTaskNode
{
	GENERATED_BODY()

	UP3BTTask_SetCharacterEmote();

	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
	virtual void OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult) override;

	/** BTDecorator에 의한 Task 종료 시에는 OnTaskFinished가 아닌 AbortTask 함수로 들어옴 */
	virtual EBTNodeResult::Type AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual uint16 GetInstanceMemorySize() const override;

private:
	void SetInEmote(UBehaviorTreeComponent& OwnerComp, bool NewInEmote);
	void SetCharacterEmote(UBehaviorTreeComponent& OwnerComp, FName InEmoteAnimName);

	UPROPERTY(EditAnywhere, Category = P3)
	bool bSetEmoteFromAIController = true;

	UPROPERTY(EditAnywhere, Category = P3, meta = (EditCondition="!bSetEmoteFromAIController"))
	FName EmoteAnimNameForce = NAME_None;

	/**
	*  Emote 유지시간. -1은 시간 제한 없음을 뜻합니다.
	*/
	UPROPERTY(EditAnywhere, Category = P3)
	float EmoteTimeLimit = -1.0f;
};
