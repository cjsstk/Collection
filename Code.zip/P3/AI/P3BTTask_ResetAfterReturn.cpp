// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_ResetAfterReturn.h"

#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"

#include "P3AIController.h"
#include "P3Character.h"

void UP3BTTask_ResetAfterReturn::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_ResetAfterReturn::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!MyBlackboard
		|| BBKey_TargetActor.SelectedKeyType != UBlackboardKeyType_Object::StaticClass())
	{
		return EBTNodeResult::Failed;
	}

	AP3Character* TargetCharacter = Cast<AP3Character>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

	if (!TargetCharacter)
	{
		return EBTNodeResult::Failed;
	}

	AP3AIController* TargetCharacterController = Cast<AP3AIController>(TargetCharacter->GetController());

	if (!TargetCharacterController)
	{
		return EBTNodeResult::Failed;
	}

	TargetCharacterController->ResetAfterReturn();

	return EBTNodeResult::Succeeded;
}
