// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "P3BTTask_SetVectorVariable.generated.h"

UCLASS()
class P3_API UP3BTTask_SetVectorVariable : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_SourceActorOrLocation;

	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_TargetLocation;
};
