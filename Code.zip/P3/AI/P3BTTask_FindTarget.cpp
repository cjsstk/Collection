// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_FindTarget.h"

#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"

#include "P3AggroComponent.h"
#include "P3Character.h"
#include "P3Combat.h"

void UP3BTTask_FindTarget::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_FindTarget::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = MyAIController ? Cast<AP3Character>(MyAIController->GetPawn()) : nullptr;

	if (!ensure(MyCharacter))
	{
		return EBTNodeResult::Failed;
	}

	AActor* NewTargetActor = P3Combat::FindTargetForAI(*MyCharacter, SearchRange, bSearchFrontOnly, AggroRangeLimit);

	MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID(), NewTargetActor);

	return (NewTargetActor ? EBTNodeResult::Succeeded : EBTNodeResult::Failed);
}
