// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_Blackboard.h"

#include "BehaviorTree/Blackboard/BlackboardKeyType_Float.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Int.h"
#include "BehaviorTree/BlackboardComponent.h"

void UP3BTTask_ClearVariable::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_TargetLocation.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_ClearVariable::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	MyBlackboard->ClearValue(BBKey_TargetLocation.GetSelectedKeyID());

	return EBTNodeResult::Succeeded;
}

void UP3BTTask_AddToVariable::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_Value.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_AddToVariable::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard))
	{
		return EBTNodeResult::Failed;
	}

	if (BBKey_Value.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
	{
		const int32 Value = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_Value.GetSelectedKeyID());

		MyBlackboard->SetValue<UBlackboardKeyType_Int>(BBKey_Value.GetSelectedKeyID(), Value + Add);
	}
	else if (BBKey_Value.SelectedKeyType == UBlackboardKeyType_Float::StaticClass())
	{
		const float Value = MyBlackboard->GetValue<UBlackboardKeyType_Float>(BBKey_Value.GetSelectedKeyID());

		MyBlackboard->SetValue<UBlackboardKeyType_Float>(BBKey_Value.GetSelectedKeyID(), Value + Add);
	}

	return EBTNodeResult::Succeeded;
}
