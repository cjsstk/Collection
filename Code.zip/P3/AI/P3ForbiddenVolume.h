// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Volume.h"
#include "GameplayTagContainer.h"
#include "P3ForbiddenVolume.generated.h"

/**
 * Forbidden volume
 * AI will not enter this volume
 */
UCLASS()
class P3_API AP3ForbiddenVolume : public AVolume
{
	GENERATED_BODY()

public:
	AP3ForbiddenVolume();

	virtual bool IsLevelBoundsRelevant() const override;
	
protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds);
};
