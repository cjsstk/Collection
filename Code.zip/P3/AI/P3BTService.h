// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTService.h"

#include "P3WalkType.h"
#include "P3BTService.generated.h"

/**
 * Update wait time before attack
 */
UCLASS()
class P3_API UP3BTService_UpdateWaitTimeBeforeAttack : public UBTService
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

protected:
	/** Minimum same character count to apply wait time */
	UPROPERTY(Category = Node, EditAnywhere)
	int32 MinSameFactionCharacterNum = 1;

	/** Max wait time */
	UPROPERTY(Category = Node, EditAnywhere)
	float MaxWaitTime = 5.0f;

	/** Target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/** WaitTimeBeforeAttack */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_WaitTimeBeforeAttack;
};


/**
 * Reset aggro as given value
 */
UCLASS()
class P3_API UP3BTService_ResetAggro : public UBTService
{
	GENERATED_BODY()

	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

protected:
	/** If > 0, give initial aggro point from 0 to RandomRange - 1 */
	UPROPERTY(Category = Aggro, EditAnywhere)
	int32 RandomRange = 0;

	/** Chance to reset aggro (percent) */
	UPROPERTY(Category = Aggro, EditAnywhere)
	int32 ResetChance = 100;
};


/**
 * Update target periodically
 */
UCLASS()
class P3_API UP3BTService_UpdateTarget : public UBTService
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

protected:
	UPROPERTY(Category = Node, EditAnywhere)
	float SearchRange = 500.0f;

	UPROPERTY(Category = Node, EditAnywhere)
	float SearchHalfHeight = 500.0f;

	UPROPERTY(Category = Node, EditAnywhere)
	bool bSearchFrontOnly = false;

	UPROPERTY(Category = Node, EditAnywhere)
	float AggroRangeLimit = 2500.0f;

	/** Target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;
};


/**
 * Check Gameplay Tag periodically
 */
UCLASS()
class P3_API UP3BTService_CheckGameplayTag : public UBTService
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

protected:
	/** Choose the gameplay tag for checking.*/
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer CheckGameplayTags;

	/** Save the result about whether the character has the gameplay tag. */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_HasTheGameplayTag;
};


/**
 * Keep ReturningFromCombat Status
 */
UCLASS()
class P3_API UP3BTService_KeepReturningFromCombatStatus : public UBTService
{
	GENERATED_UCLASS_BODY()

protected:
	virtual void OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	void SetReturningFromCombatStatus(UBehaviorTreeComponent& OwnerComp, bool bReturningFromCombat);
};

/**
 * Update target's main target periodically
 */
UCLASS()
class P3_API UP3BTService_UpdateMainTargetOfTarget : public UBTService
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual void TickNode(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

protected:
	/** Target Character */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/** Target's main target */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutMainTargetOfTargetActor;

};

/**
 * Keep Blocking Status
 */
UCLASS()
class P3_API UP3BTService_KeepBlockingStatus : public UBTService
{
	GENERATED_UCLASS_BODY()

protected:
	virtual void OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	void SetBlockingStatus(UBehaviorTreeComponent& OwnerComp, bool bBlocking);
};


/**
 * Keep Walking Status
 */
UCLASS()
class P3_API UP3BTService_KeepWalkingStatus : public UBTService
{
	GENERATED_BODY()

	UP3BTService_KeepWalkingStatus();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;

protected:
	virtual void OnBecomeRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void OnCeaseRelevant(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:
	void SetWalkingStatus(UBehaviorTreeComponent& OwnerComp, bool bDefinedWalking);

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteWalkType;

	EP3RouteWalkType RouteWalkType = EP3RouteWalkType::Walk;
};
