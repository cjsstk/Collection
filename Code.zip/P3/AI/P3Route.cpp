// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Route.h"

#include "Engine/World.h"
#include "DrawDebugHelpers.h"

#if WITH_EDITORONLY_DATA
#include "Components/BillboardComponent.h"
#include "UObject/ConstructorHelpers.h"
#endif

#include "P3Spot.h"

UP3RouteComponent::UP3RouteComponent()
{

}

AP3RouteActor::AP3RouteActor()
{
	bNetLoadOnClient = false;
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* SphereComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	RootComponent = SphereComponent;

	RouteComponent = CreateDefaultSubobject<UP3RouteComponent>(TEXT("RouteComponent"));

#if WITH_EDITORONLY_DATA
	EditorSprite = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorSprite"));

	if (!IsRunningCommandlet())
	{
		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> SpriteTextureObject;
			FConstructorStatics()
				: SpriteTextureObject(TEXT("/Game/DevTools/Editor/EditorResources/S_Route"))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (EditorSprite)
		{
			EditorSprite->Sprite = ConstructorStatics.SpriteTextureObject.Get();
			EditorSprite->RelativeScale3D = FVector(0.2f);
			EditorSprite->bHiddenInGame = true;
			EditorSprite->SetupAttachment(RootComponent);
			EditorSprite->bAbsoluteScale = true;
			EditorSprite->bIsScreenSizeScaled = true;
		}
	}
#endif // WITH_EDITORONLY_DATA
}
