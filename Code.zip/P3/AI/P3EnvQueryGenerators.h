// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "EnvironmentQuery/EnvQueryGenerator.h"
#include "P3EnvQueryGenerators.generated.h"

/**
 * EQS Generator - Aggro Table Actors
 */
UCLASS(meta = (DisplayName = "Aggro Table Actors"))
class P3_API UP3EnvQueryGenerator_AggroTableActors : public UEnvQueryGenerator
{
	GENERATED_UCLASS_BODY()

	virtual void GenerateItems(FEnvQueryInstance& QueryInstance) const override;
};
