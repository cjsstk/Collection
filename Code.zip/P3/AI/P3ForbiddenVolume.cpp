// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ForbiddenVolume.h"

#include "Components/BrushComponent.h"

#include "P3AIController.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3ServerWorld.h"
#include "P3World.h"

AP3ForbiddenVolume::AP3ForbiddenVolume()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;

	if (GetBrushComponent())
	{
		GetBrushComponent()->SetCollisionResponseToAllChannels(ECR_Ignore);
	}
}

bool AP3ForbiddenVolume::IsLevelBoundsRelevant() const
{
	return true;
}

void AP3ForbiddenVolume::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		SetActorTickEnabled(true);
	}
}

void AP3ForbiddenVolume::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void AP3ForbiddenVolume::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(*this);

		if (ensure(ServerWorld))
		{
			const TArray<class AP3Character*>& Characters = ServerWorld->GetCharacters();

			for (AP3Character* Character : Characters)
			{
				if (!Character)
				{
					continue;
				}

				const bool bEncompass = EncompassesPoint(Character->GetActorLocation());
				if (bEncompass)
				{
					Character->AddForbiddenVolume(this);
				}
				else
				{
					Character->RemoveForbiddenVolume(this);
				}
			}
		}
	}
}
