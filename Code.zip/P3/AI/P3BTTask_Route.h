// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "P3BTTask.h"
#include "P3BTTask_Route.generated.h"

struct FBTRouteSpotEmoteTaskMemory
{
	/** time left */
	float TaskAgeSeconds;

	float EmoteDurationSeconds = 0.0f;
	float EmoteStartAnimTotalSeconds = 0.0f;
	float EmoteEndAnimTotalSeconds = 0.0f;
	bool HasInitializedEmote = false;
};

/** 
 * Get route actor from conroller, which set from spawner
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTTask_GetRouteActorFromController : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/** Set null to select random */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteActorIndex;

	/** Only valid if >= 0 and BBKey_RouteActorIndex is null */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	int32 RouteActorIndex = -1;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutRouteActor;
};

UCLASS(ClassGroup=(P3))
class P3_API UP3BTTask_GetRouteSpot : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteActor;

	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_SpotIndex;

	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_OutLocation;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutActor;
};

/** 
 * Get number of spots of route
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTTask_GetRouteNumSpots : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteActor;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutNumSpots;
};


/**
 * Find Nearest Spot of My Route
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTTask_FindNearbySpotIndexOfMyRoute : public UBTTaskNode
{
	GENERATED_BODY()

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category = P3)
	bool bFindNearestSpot = false;

	UPROPERTY(EditAnywhere, Category = P3, meta=(EditCondition="!bFindNearestSpot"))
	float MininumRange = 100.0f;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteActor;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutSpotIndex;
};

/**
 * Route Actor와 Trip Type을 가져옵니다.
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTTask_GetRouteFromController : public UBTTaskNode
{
	GENERATED_BODY()

	UP3BTTask_GetRouteFromController();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	/** Set null to select random */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteIndex;

	/** Only valid if >= 0 and BBKey_RouteActorIndex is null */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	int32 RouteIndex = -1;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutRouteActor;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutRouteTripType;

	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_OutRouteWalkType;
};

/**
 * 도달한 Spot Actor에 설정된 Action을 합니다.
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTTask_RouteSpotMontageAction : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	UP3BTTask_RouteSpotMontageAction();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteSpotActor;
};

/**
 * 도달한 Spot Actor에 설정된 Emote을 출력합니다
 */
UCLASS(ClassGroup=(P3))
class P3_API UP3BTTask_RouteSpotEmote : public UBTTaskNode
{
	GENERATED_BODY()

	UP3BTTask_RouteSpotEmote();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
	virtual void OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult) override;
	virtual EBTNodeResult::Type AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual uint16 GetInstanceMemorySize() const override;

protected:
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_RouteSpotActor;

private:
	void SetInEmote(UBehaviorTreeComponent& OwnerComp, bool NewInEmote);
	void SetCharacterEmote(UBehaviorTreeComponent& OwnerComp, FName InEmoteAnimName);
};
