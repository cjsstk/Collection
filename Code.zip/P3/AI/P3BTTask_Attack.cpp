// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_Attack.h"
#include "P3Character.h"
#include "P3CombatComponent.h"
#include "P3Log.h"
#include "P3Projectile.h"
#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "AIController.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Int.h"
#include "BehaviorTree/BlackboardComponent.h"

UP3BTTask_Attack::UP3BTTask_Attack()
{
	bNotifyTick = true;
}

void UP3BTTask_Attack::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_Attack::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	if (Character->IsDead())
	{
		return EBTNodeResult::Failed;
	}

	Character->StartAttackByAI();

	return EBTNodeResult::InProgress;
}

EBTNodeResult::Type UP3BTTask_Attack::AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Aborted;
	}

	Character->StopAttackByAI();

	return EBTNodeResult::Aborted;
}

void UP3BTTask_Attack::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	if (Character->IsDead())
	{
		Character->StopAttackByAI();
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
	if (!ensure(CombatComp))
	{
		Character->StopAttackByAI();
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	if (!CombatComp->IsAttacking())
	{
		FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
		return;
	}

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

		if (!TargetActor)
		{
			Character->StopAttackByAI();
			FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
			return;
		}

		if (!CombatComp->IsActorInAttackRange(TargetActor, -1, 0.0f))
		{
			// Target too far
			Character->StopAttackByAI();
			FinishLatentTask(OwnerComp, EBTNodeResult::Failed);
			return;
		}

		AP3Character* TargetCharacter = Cast<AP3Character>(TargetActor);
		if (TargetCharacter)
		{
			if (TargetCharacter->IsDead())
			{
				// Target dead
				Character->StopAttackByAI();
				FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
				return;
			}
		}
	}
	else
	{
		Character->StopAttackByAI();
		FinishLatentAbort(OwnerComp);
		return;
	}
}

void UP3BTTask_Attack::OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult)
{
	Super::OnTaskFinished(OwnerComp, NodeMemory, TaskResult);

	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (ensure(Character))
	{
		Character->StopAttackByAI();
	}
}

/**
 * Attack Once
 */

UP3BTTask_AttackOnce::UP3BTTask_AttackOnce()
{
	bNotifyTick = true;
}

void UP3BTTask_AttackOnce::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
		BBKey_SkillIndex.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_AttackOnce::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	if (Character->IsDead())
	{
		return EBTNodeResult::Failed;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
	if (!ensure(CombatComp))
	{
		return EBTNodeResult::Failed;
	}

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

		if (!TargetActor)
		{
			return EBTNodeResult::Failed;
		}

		int32 SkillIndex = -1;

		if (BBKey_SkillIndex.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
		{
			SkillIndex = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_SkillIndex.GetSelectedKeyID());
		}

		if (!CombatComp->IsActorInAttackRange(TargetActor, SkillIndex, 0.0f))
		{
			// Target too far
			return EBTNodeResult::Failed;
		}

		AP3Character* TargetCharacter = Cast<AP3Character>(TargetActor);
		if (TargetCharacter)
		{
			if (TargetCharacter->IsDead())
			{
				// Target dead
				return EBTNodeResult::Failed;
			}
		}

		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

		if (ActionComp && ActionComp->CanStartAction(EPawnActionType::CombatAttack))
		{
			if (SkillIndex != -1)
			{
				if (!ensure(CombatComp->GetSkills().IsValidIndex(SkillIndex)))
				{
					return EBTNodeResult::Failed;
				}
			}

			const FP3CmsCombatSkill* CmsCombatSkill = CombatComp->GetCmsCombatSkill(SkillIndex);
			if (SkillIndex != -1 && ensure(CmsCombatSkill) && CmsCombatSkill->ProjectileClass.LoadSynchronous())
			{
				FP3PawnActionStartRequestParams Params;
				Params.CombatProjectileSkillAttack_SkillIndex = SkillIndex;
				Params.CombatProjectileSkillAttack_TargetHalfHeight = TargetActor->GetSimpleCollisionHalfHeight();
				Params.CombatProjectileSkillAttack_TargetLocation = TargetActor->GetActorLocation();

				ActionComp->StartAction(EPawnActionType::CombatProjectileSkillAttack, _FUNCTION_TEXT, Params);
				CurrentCombatActionType = EPawnActionType::CombatProjectileSkillAttack;

				return EBTNodeResult::InProgress;
			}

			if (Character->GetAnimMontages().Attacks.Num() > 0)
			{
				FP3PawnActionStartRequestParams Params;
				Params.CombatAttack_Target = TargetActor;
				Params.CombatAttack_bIsTurningAttack = bIsTurningAttack;
				Params.CombatAttack_TurningAttackIndex = TurningAttackIndex;
				Params.CombatAttack_bFinishOnMontageBlendingOut = bFinishOnMontageBlendingOut;
				Params.CombatAttack_MontageIndex = FMath::Rand() % Character->GetAnimMontages().Attacks.Num();

				ActionComp->StartAction(EPawnActionType::CombatAttack, _FUNCTION_TEXT, Params);
				CurrentCombatActionType = EPawnActionType::CombatAttack;

				return EBTNodeResult::InProgress;
			}
		}

		P3JsonLog(Warning, "Called AttackOnce, but can not do anything", TEXT("Character"), Character->GetName());
	}
	else
	{
		return EBTNodeResult::Failed;
	}

	return EBTNodeResult::Failed;
}

void UP3BTTask_AttackOnce::TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		FinishLatentAbort(OwnerComp);
		return;
	}

	if (Character->IsDead())
	{
		FinishLatentAbort(OwnerComp);
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

	if (!ensure(ActionComp))
	{
		FinishLatentAbort(OwnerComp);
		return;
	}

	if (!ActionComp->IsActionInProgress(CurrentCombatActionType)
		&& !ActionComp->Server_IsActionInQueue(CurrentCombatActionType))
	{
		FinishLatentTask(OwnerComp, EBTNodeResult::Succeeded);
		return;
	}
}

UP3BTTask_Charging::UP3BTTask_Charging()
{
	bNotifyTick = true;
}

void UP3BTTask_Charging::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_Charging::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	if (Character->IsDead())
	{
		return EBTNodeResult::Failed;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
	if (!ensure(CombatComp))
	{
		return EBTNodeResult::Failed;
	}

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

		if (!TargetActor)
		{
			return EBTNodeResult::Failed;
		}

		AP3Character* TargetCharacter = Cast<AP3Character>(TargetActor);
		if (TargetCharacter)
		{
			if (TargetCharacter->IsDead())
			{
				// Target dead
				return EBTNodeResult::Failed;
			}
		}
		
		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		if (!ActionComp)
		{
			return EBTNodeResult::Failed;
		}

		if (!CombatComp->GetChargings().IsValidIndex(ChargingIndex))
		{
			return EBTNodeResult::Failed;
		}

		if (ActionComp->CanStartAction(EPawnActionType::CombatCharging))
		{
			FP3PawnActionStartRequestParams Params;
			Params.CombatCharging_TargetActor = TargetActor;
			Params.CombatCharging_Index = ChargingIndex;

			const EBTNodeResult::Type Result = StartAction(OwnerComp, NodeMemory, EPawnActionType::CombatCharging, Params);

			return Result;
		}
	}

	return EBTNodeResult::Failed;
}

UP3BTTask_UseSkill::UP3BTTask_UseSkill()
{
	BBKey_SkillIndex.AllowNoneAsValue(true);
}

void UP3BTTask_UseSkill::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();
	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
		BBKey_SkillIndex.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_UseSkill::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	AAIController* AIController = OwnerComp.GetAIOwner();
	AP3Character* Character = AIController ? Cast<AP3Character>(AIController->GetPawn()) : nullptr;

	if (!ensure(Character))
	{
		return EBTNodeResult::Failed;
	}

	if (Character->IsDead())
	{
		return EBTNodeResult::Failed;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
	if (!ensure(CombatComp))
	{
		return EBTNodeResult::Failed;
	}

	EBTNodeResult::Type Result = EBTNodeResult::Failed;

	const UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();
	if (MyBlackboard && BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass())
	{
		AActor* TargetActor = Cast<AActor>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID()));

		if (!TargetActor)
		{
			return EBTNodeResult::Failed;
		}

		AP3Character* TargetCharacter = Cast<AP3Character>(TargetActor);
		if (TargetCharacter)
		{
			if (TargetCharacter->IsDead())
			{
				// Target is dead
				return EBTNodeResult::Failed;
			}
		}
		
		int32 SkillIndexToUse = SkillIndex;

		if (BBKey_SkillIndex.SelectedKeyType == UBlackboardKeyType_Int::StaticClass())
		{
			SkillIndexToUse = MyBlackboard->GetValue<UBlackboardKeyType_Int>(BBKey_SkillIndex.GetSelectedKeyID());
		}

		if (!CombatComp->GetSkills().IsValidIndex(SkillIndexToUse))
		{
			return EBTNodeResult::Failed;
		}

		const FP3CmsCombatSkill* CmsCombatSkill = CombatComp->GetCmsCombatSkill(SkillIndexToUse);
		if (!ensure(CmsCombatSkill))
		{
			return EBTNodeResult::Failed;
		}

		if (!CombatComp->Server_CanUseSkill(SkillIndexToUse))
		{
			return EBTNodeResult::Failed;
		}

		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		if (!ActionComp)
		{
			return EBTNodeResult::Failed;
		}

		const bool bIsProjectileSkill = (CmsCombatSkill->ProjectileClass.LoadSynchronous() != nullptr);

		if (bIsProjectileSkill)
		{
			FP3PawnActionStartRequestParams Params;
			Params.CombatProjectileSkillAttack_TargetLocation = TargetActor->GetActorLocation();
			Params.CombatProjectileSkillAttack_TargetHalfHeight = TargetActor->GetSimpleCollisionHalfHeight();
			Params.CombatProjectileSkillAttack_SkillIndex = SkillIndexToUse;
			Params.CombatAttack_bFinishOnMontageBlendingOut = bFinishOnMontageBlendingOut;

			Result = StartAction(OwnerComp, NodeMemory, EPawnActionType::CombatProjectileSkillAttack, Params);
		}
		else 
		{
			EPawnActionType ActionType = EPawnActionType::CombatAttack;

			if (CmsCombatSkill->bAdapted)
			{
				ActionType = EPawnActionType::CombatAdaptedAttack;
			}

			FP3PawnActionStartRequestParams Params;
			Params.CombatAttack_Target = TargetActor;
			Params.CombatAttack_SkillIndex = SkillIndexToUse;
			Params.CombatAttack_bFinishOnMontageBlendingOut = bFinishOnMontageBlendingOut;

			Result = StartAction(OwnerComp, NodeMemory, ActionType, Params);
		}
	}

	return Result;
}
