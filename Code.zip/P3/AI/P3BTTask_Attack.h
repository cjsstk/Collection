// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/BTTaskNode.h"
#include "Action/P3PawnActionType.h"
#include "P3BTTask.h"
#include "P3BTTask_Attack.generated.h"

/**
 * Attack
 */
UCLASS()
class P3_API UP3BTTask_Attack : public UBTTaskNode
{
	GENERATED_BODY()

	UP3BTTask_Attack();
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	virtual EBTNodeResult::Type AbortTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;
	virtual void OnTaskFinished(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, EBTNodeResult::Type TaskResult) override;

protected:
	/** blackboard key selector */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;
};

UCLASS()
class P3_API UP3BTTask_AttackOnce : public UBTTaskNode
{
	GENERATED_BODY()

	UP3BTTask_AttackOnce();
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:
	virtual void TickTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory, float DeltaSeconds) override;

	/** blackboard for target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/** blackboard for skill index */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_SkillIndex;

	/** If true, face to target and turning attack montage will be used */
	UPROPERTY(EditAnywhere, Category = TurningAttack)
	bool bIsTurningAttack = false;

	UPROPERTY(EditAnywhere, Category = TurningAttack, meta=(ClampMin="0.0", UIMin = "0.0", EditCondition="bIsTurningAttack"))
	int32 TurningAttackIndex = 0;

	/** If true, the attack montage will be finished on blending out*/
	UPROPERTY(EditAnywhere, Category = P3)
	bool bFinishOnMontageBlendingOut = false;

private:
	EPawnActionType CurrentCombatActionType = EPawnActionType::Invalid;
};

UCLASS()
class P3_API UP3BTTask_Charging : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	UP3BTTask_Charging();

	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

private:

	/** blackboard for target actor */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	UPROPERTY(Category = Node, EditAnywhere)
	int32 ChargingIndex = 0;
};

UCLASS()
class P3_API UP3BTTask_UseSkill : public UP3BTTask_ActionBase
{
	GENERATED_BODY()

	UP3BTTask_UseSkill();
	
	virtual void InitializeFromAsset(UBehaviorTree& Asset) override;
	virtual EBTNodeResult::Type ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) override;

protected:

	/** blackboard for target actor */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	struct FBlackboardKeySelector BBKey_TargetActor;

	/** blackboard for skill index */
	UPROPERTY(EditAnywhere, Category = Blackboard)
	struct FBlackboardKeySelector BBKey_SkillIndex;

	/** If BBKey_SkillIndex is set, this is ignored */
	UPROPERTY(EditAnywhere, Category=Blackboard)
	int32 SkillIndex = 0;

	/** If true, the attack montage will be finished on blending out*/
	UPROPERTY(EditAnywhere, Category = P3)
	bool bFinishOnMontageBlendingOut = false;
};
