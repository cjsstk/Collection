// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BTTask_FindPointOfInterest.h"

#include "AIController.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Vector.h"
#include "BehaviorTree/Blackboard/BlackboardKeyType_Object.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "DrawDebugHelpers.h"

#include "P3AIController.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3PointOfInterest.h"
#include "P3World.h"

extern TAutoConsoleVariable<int32> CVarP3POIDebug;

void UP3BTTask_FindPointOfInterest::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_PointOfInterest.ResolveSelectedKey(*BBAsset);
		BBKey_PointOfInterestOrigin.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_FindPointOfInterest::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
	UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard
		&& BBKey_PointOfInterest.SelectedKeyType == UBlackboardKeyType_Object::StaticClass()
		&& BBKey_PointOfInterestOrigin.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass()))
	{
		return EBTNodeResult::Failed;
	}

	//AP3PointOfInterest* PointOfInterest = Cast<AP3PointOfInterest>(MyBlackboard->GetValue<UBlackboardKeyType_Object>(BBKey_PointOfInterest.GetSelectedKeyID()));

	// Comment-out: P3-575. We need to find newer PoI
	//// Keep moving to already found POI
	//if (PointOfInterest)
	//{
	//	return EBTNodeResult::Succeeded;
	//}

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = MyAIController ? Cast<AP3Character>(MyAIController->GetPawn()) : nullptr;

	if (!ensure(MyCharacter))
	{
		return EBTNodeResult::Failed;
	}

	AP3PointOfInterest* NewPointOfInterest = FindNewPointOfInterest(*MyAIController, *MyCharacter);

	if (!NewPointOfInterest)
	{
		MyBlackboard->ClearValue(BBKey_PointOfInterest.GetSelectedKeyID());
		MyBlackboard->ClearValue(BBKey_PointOfInterestOrigin.GetSelectedKeyID());

		return EBTNodeResult::Failed;
	}

	MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_PointOfInterest.GetSelectedKeyID(), NewPointOfInterest);
	MyBlackboard->SetValue<UBlackboardKeyType_Vector>(BBKey_PointOfInterestOrigin.GetSelectedKeyID(), NewPointOfInterest->GetOriginLocation());

	return EBTNodeResult::Succeeded;
}

AP3PointOfInterest* UP3BTTask_FindPointOfInterest::FindNewPointOfInterest(AAIController& MyAIController, AP3Character& MyCharacter)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("FindNewPointOfInterest"), STAT_FindNewPointOfInterest, STATGROUP_P3);

	UP3World* P3World = P3Core::GetP3World(MyCharacter);

	if (!ensure(P3World))
	{
		return nullptr;
	}

	TArray<AP3PointOfInterest*> PointOfInterestActors;

	P3World->FindActorsFromCache(PointOfInterestActors);

	if (CVarP3POIDebug.GetValueOnGameThread() > 0)
	{
		DrawDebugSphere(GetWorld(), MyCharacter.GetActorLocation(), SearchRange, 32, FColor::Yellow, true, 0.5f);
		DrawDebugSphere(GetWorld(), MyCharacter.GetActorLocation(), MaxDistanceToOrigin, 32, FColor::Red, true, 0.5f);
	}

	float LatestPoISpawnTimeSeconds = 0.0f;
	float MaxDistanceToOriginSquared = MaxDistanceToOrigin * MaxDistanceToOrigin;
	AP3PointOfInterest* NewPointOfInterest = nullptr;

	for (AP3PointOfInterest* PointOfInterest : PointOfInterestActors)
	{
		if (!PointOfInterest)
		{
			continue;
		}

		// Is it too far?

		const float DistanceToOriginSquared = (PointOfInterest->GetOriginLocation() - MyCharacter.GetActorLocation()).SizeSquared();

		if (CVarP3POIDebug.GetValueOnGameThread() > 0)
		{
			if (DistanceToOriginSquared > MaxDistanceToOriginSquared)
			{
				DrawDebugLine(GetWorld(), MyCharacter.GetActorLocation(), PointOfInterest->GetOriginLocation(), FColor::Red, false, 0.5f);
			}
			else
			{
				DrawDebugLine(GetWorld(), MyCharacter.GetActorLocation(), PointOfInterest->GetOriginLocation(), FColor::Green, false, 1.0f);
			}
		}

		if (DistanceToOriginSquared > MaxDistanceToOriginSquared)
		{
			continue;
		}

		// Can I actually see it?

		FCollisionQueryParams CollisionQueryParams;
		CollisionQueryParams.AddIgnoredActor(&MyCharacter);
		CollisionQueryParams.AddIgnoredActor(PointOfInterest);
		
		// Ignore destructible, since it must be just debris
		FCollisionResponseParams CollisionResponseParams;
		CollisionResponseParams.CollisionResponse.SetResponse(ECollisionChannel::ECC_Destructible, ECR_Ignore);

		FHitResult HitResult;
		bool bOccluded = GetWorld()->LineTraceSingleByChannel(HitResult, MyCharacter.GetActorLocation(), PointOfInterest->GetTargetLocation(), ECC_Visibility, CollisionQueryParams);

		if (CVarP3POIDebug.GetValueOnGameThread() > 0)
		{
			if (bOccluded)
			{
				DrawDebugLine(GetWorld(), MyCharacter.GetActorLocation(), HitResult.Location, FColor::Red, false, 0.5f);
			}
			else
			{
				DrawDebugLine(GetWorld(), MyCharacter.GetActorLocation(), PointOfInterest->GetTargetLocation(), FColor::Green, false, 1.0f);
			}
		}

		if (bOccluded)
		{
			continue;
		}

		const float SpawnTimeSeconds = PointOfInterest->GetSpawnTimeSeconds();

		if (LatestPoISpawnTimeSeconds < SpawnTimeSeconds)
		{
			LatestPoISpawnTimeSeconds = SpawnTimeSeconds;
			NewPointOfInterest = PointOfInterest;
		}
	}

	if (!NewPointOfInterest)
	{
		AP3AIController* MyP3AIController = Cast<AP3AIController>(&MyAIController);
		if (MyP3AIController && MyP3AIController->GetPointOfInterest())
		{
			return MyP3AIController->GetPointOfInterest();
		}
	}



	return NewPointOfInterest;
}

void UP3BTTask_FindNearestActorWithTag::InitializeFromAsset(UBehaviorTree& Asset)
{
	Super::InitializeFromAsset(Asset);

	UBlackboardData* BBAsset = GetBlackboardAsset();

	if (ensure(BBAsset))
	{
		BBKey_TargetActor.ResolveSelectedKey(*BBAsset);
		BBKey_TargetActorLocation.ResolveSelectedKey(*BBAsset);
	}
}

EBTNodeResult::Type UP3BTTask_FindNearestActorWithTag::ExecuteTask(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory)
{
		UBlackboardComponent* MyBlackboard = OwnerComp.GetBlackboardComponent();

	if (!ensure(MyBlackboard
		&& BBKey_TargetActor.SelectedKeyType == UBlackboardKeyType_Object::StaticClass()
		&& BBKey_TargetActorLocation.SelectedKeyType == UBlackboardKeyType_Vector::StaticClass()))
	{
		return EBTNodeResult::Failed;
	}

	AAIController* MyAIController = OwnerComp.GetAIOwner();
	AP3Character* MyCharacter = MyAIController ? Cast<AP3Character>(MyAIController->GetPawn()) : nullptr;

	if (!ensure(MyCharacter))
	{
		return EBTNodeResult::Failed;
	}

	AActor* ActorWithTag = FindP3ActorWithTag(*MyCharacter);

	if (!ActorWithTag)
	{
		MyBlackboard->ClearValue(BBKey_TargetActor.GetSelectedKeyID());
		MyBlackboard->ClearValue(BBKey_TargetActorLocation.GetSelectedKeyID());

		return EBTNodeResult::Failed;
	}

	MyBlackboard->SetValue<UBlackboardKeyType_Object>(BBKey_TargetActor.GetSelectedKeyID(), ActorWithTag);
	MyBlackboard->SetValue<UBlackboardKeyType_Vector>(BBKey_TargetActorLocation.GetSelectedKeyID(), ActorWithTag->GetActorLocation());

	return EBTNodeResult::Succeeded;

}

class AActor* UP3BTTask_FindNearestActorWithTag::FindP3ActorWithTag(class AP3Character& MyCharacter)
{
	AActor* NearestP3ActorWithRequiredTag = nullptr;
	const float SearchRangeToTargetSquared = SearchRange * SearchRange;
	float MinimumDistanceTargetToMeSquared = SearchRangeToTargetSquared;

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(SearchRange);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(&MyCharacter);

	TArray<FOverlapResult> OverlapResults;
	GetWorld()->OverlapMultiByChannel(OverlapResults, MyCharacter.GetActorLocation(), MyCharacter.GetActorQuat(), ECC_WorldDynamic, CollisionShape, QueryParams);

	for (const FOverlapResult& Result : OverlapResults)
	{
		AActor* Actor = (Result.GetActor()) ? Cast<AP3Actor>(Result.GetActor()) : nullptr;
		if (!Actor)
		{
			continue;
		}

		// 요구되는 Tag를 포함하고 있는지 체크
		if (IncludedGameplayTagsAny.Num() > 0)
		{
			IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(Actor);
			if (GameplayTagAsset)
			{
				const bool bHasRequiredTags = GameplayTagAsset->HasAnyMatchingGameplayTags(IncludedGameplayTagsAny);

				if (!bHasRequiredTags)
				{
					continue;
				}
			}
		}

		const float NewDistanceWeaponToMeSquared = (Actor->GetActorLocation() - MyCharacter.GetActorLocation()).SizeSquared();

		// 조건 충족한 P3Actor 중 가장 가까운 거리에 있는 걸 고른다.
		if (NewDistanceWeaponToMeSquared < MinimumDistanceTargetToMeSquared)
		{
			NearestP3ActorWithRequiredTag = Actor;
			MinimumDistanceTargetToMeSquared = NewDistanceWeaponToMeSquared;
		}
	}

	return NearestP3ActorWithRequiredTag;
}
