// Copyriht 2018 XLGames, Inc. All Rights Reserved.

#include "P3ServerPlayerController.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3Combat.h"
#include "P3ConfigLoader.h"
#include "P3GameInstance.h"
#include "P3GameState.h"
#include "P3HealthPointComponent.h"
#include "P3InventoryComponent.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3Weapon.h"
#include "P3World.h"

bool AP3ServerPlayerController::IsLocalController() const
{
	return false;
}

bool AP3ServerPlayerController::NotifyServerReceivedClientData(APawn* InPawn, float TimeStamp)
{
	return true;
}

void AP3ServerPlayerController::HandleGMCommand(const TArray<FString>& Args) const
{
	if (Args.Num() == 0)
	{
		return;
	}

	if (Args[0].Equals(TEXT("die"), ESearchCase::IgnoreCase))
	{
		AP3Character* MyCharacter = Cast<AP3Character>(GetPawn());
		if (MyCharacter && MyCharacter->GetCommandComponent() && MyCharacter->GetP3HealthComponentBP())
		{
			FP3CommandRequestParams Params;
			Params.ApplyDamage_DamageAmount = MyCharacter->GetP3HealthComponentBP()->GetHealthPoint();
			Params.ApplyDamage_Reason = EP3HealthChangeReason::GM;
			MyCharacter->GetCommandComponent()->RequestCommand(UP3ApplyDamageCommand::StaticClass(), Params);
		}
	}
	else if (Args[0].Equals(TEXT("spawnWeapon"), ESearchCase::IgnoreCase))
	{
		HandleGMCommandSpawnWeapon(Args);
	}
	else if (Args[0].Equals(TEXT("tod"), ESearchCase::IgnoreCase))
	{
		HandleGMCommandTOD(Args);
	}
	else if (Args[0].Equals(TEXT("setHealth"), ESearchCase::IgnoreCase))
	{
		HandleGMCommandSetHealth(Args);
	}
	else if (Args[0].Equals(TEXT("getItemPackage"), ESearchCase::IgnoreCase))
	{
		HandleGMCommandGetItemPackage(Args);
	}
	else if (Args[0].Equals(TEXT("killNPC"), ESearchCase::IgnoreCase))
	{
		HandleGMCommandKillNPC(Args);
	}
	else if (Args[0].Equals(TEXT("noTarget"), ESearchCase::IgnoreCase))
	{
		AP3Character* MyCharacter = Cast<AP3Character>(GetPawn());

		if (MyCharacter)
		{
			FP3CommandRequestParams Params;
			Params.SetGodMode_bNewGodMode = MyCharacter->GetCharacterStoreBP().bGodMode;
			Params.SetGodMode_bNewNoTargetMode = !MyCharacter->GetCharacterStoreBP().bNoTargetMode;

			MyCharacter->GetCommandComponent()->RequestCommand(UP3SetGodModeCommand::StaticClass(), Params);
		}
	}
	else if (Args[0].Equals(TEXT("reloadConfig"), ESearchCase::IgnoreCase))
	{
		UP3GameInstance* GameInstance = P3Core::GetP3GameInstance(*this);
		if (GameInstance)
		{
			FP3ConfigLoader::ReloadConfigFile(GameInstance->GetConfigPath());
		}
	}
}

void AP3ServerPlayerController::HandleGMCommandSpawnWeapon(const TArray<FString>& Args) const
{
	if (Args.Num() != 2)
	{
		return;
	}

	const FString AssetName = Args[1];
	const static FName AssetPath("/Game/Objects/Weapon");

	P3JsonLog(Display, "[GM] spawnWeapon", TEXT("AssetName"), *AssetName);

	UClass* Class = P3Core::GetBlueprintClassInPath(AssetPath, FName(*AssetName), AP3Weapon::StaticClass());

	if (!Class)
	{
		P3JsonLog(Display, "[GM] spawnWeapon: No class");
		return;
	}

	if (!GetPawn())
	{
		P3JsonLog(Display, "[GM] spawnWeapon: No pawn");
		return;
	}

	FTransform SpawnTransform = GetPawn()->GetActorTransform();
	SpawnTransform.AddToTranslation(GetPawn()->GetActorForwardVector() * 100.0f);

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	GetWorld()->SpawnActor(Class, &SpawnTransform, Params);
}

void AP3ServerPlayerController::HandleGMCommandTOD(const TArray<FString>& Args) const
{
	if (Args.Num() < 2)
	{
		return;
	}

	const FString NewTimeOfDayHour = Args[1];

	P3JsonLog(Display, "[GM] TOD", TEXT("NewTimeOfDayHour"), *NewTimeOfDayHour);

	P3Core::GetP3World(*this)->GetServerWorld()->SetTimeOfDayInSeconds(FCString::Atoi(*NewTimeOfDayHour) * 3600);

	if (Args.Num() > 2)
	{
		const FString NewTimeOfDayRatio = Args[2];

		P3JsonLog(Display, "[GM] TOD", TEXT("NewTimeOfDayRatio"), *NewTimeOfDayRatio);
		
		UP3World* P3World = P3Core::GetP3World(*this);

		if (P3World)
		{
			P3World->GetServerWorld()->SetGameTimeToTimeOfDayRatio(FCString::Atoi(*NewTimeOfDayRatio));
		}
	}
}

/**
 * <P3ActorId> <Health>
 */
void AP3ServerPlayerController::HandleGMCommandSetHealth(const TArray<FString>& Args) const
{
	if (Args.Num() < 3)
	{
		return;
	}

	const FString P3ActorIdString = Args[1];
	const FString HealthString = Args[2];

	P3JsonLog(Display, "[GM] SetHealth", TEXT("Health"), HealthString, TEXT("ActorId"), P3ActorIdString);

	const int32 Health = FCString::Atoi(*HealthString);
	const actorid P3ActorId = FCString::Atoi64(*P3ActorIdString);

	UP3World* P3World = P3Core::GetP3World(*this);
	if (!P3World)
	{
		return;
	}

	AActor* Actor = P3World->GetActorFromActorId(P3ActorId);
	if (!Actor)
	{
		return;
	}

	UP3HealthPointComponent* HealthComp = Actor->FindComponentByClass<UP3HealthPointComponent>();
	if (!HealthComp)
	{
		return;
	}

	const int32 Amount = Health - HealthComp->GetHealthPoint();
	P3Combat::ChangeActorHealth(GetPawn(), *HealthComp, Amount, EP3HealthChangeReason::GM);
}

void AP3ServerPlayerController::HandleGMCommandGetItemPackage(const TArray<FString>& Args) const
{
	if (Args.Num() != 2)
	{
		return;
	}

	const FString AssetName = Args[1];
	const FString AssetPath("/Game/GameMode/");

	P3JsonLog(Display, "[GM] getItemPackage", TEXT("AssetName"), *AssetName);

	FStringAssetReference ItemPackageAssetPath(AssetPath + AssetName);
	UObject* PackageAsset = ItemPackageAssetPath.TryLoad();
	if (!PackageAsset)
	{
		P3JsonLog(Display, "[GM] getItemPackage: No asset");
		return;
	}

	UP3ItemPackage* ItemPackage = Cast<UP3ItemPackage>(PackageAsset);
	if (!ItemPackage)
	{
		P3JsonLog(Display, "[GM] getItemPackage: No itemPackage");
		return;
	}

	AP3Character* OwnerCharacter = Cast<AP3Character>(GetPawn());
	if (!OwnerCharacter)
	{
		P3JsonLog(Display, "[GM] getItemPackage: No Character");
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(OwnerCharacter);
	if (!ensure(WorldNet))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = OwnerCharacter->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const TMap<int32, int32> PackagedItems = ItemPackage->PackagedItems;
	for (auto Item : PackagedItems)
	{
		itemkey ItemKey = Item.Key;
		if (!ensure(ItemKey != INVALID_ITEMKEY))
		{
			P3JsonLog(Warning, "[GM] getItemPackage: Invalid item key");
			continue;
		}

		int32 NumItems = Item.Value;
		if (NumItems < 0)
		{
			P3JsonLog(Warning, "[GM] getItemPackage: ItemNum is negative quantity");
			continue;
		}

		const FP3CmsItem& ItemDesc = P3Cms::GetItem(ItemKey);
		if (ItemDesc.MaxCountInInventory > 0 && NumItems > ItemDesc.MaxCountInInventory)
		{
			NumItems = ItemDesc.MaxCountInInventory;
		}

		const int32 NumExistingItems = InventoryComp->GetNumItemsByKey(ItemKey);
		NumItems -= NumExistingItems;
		if (NumItems > 0)
		{
			InventoryComp->Server_AddItemByKeyAndCount(ItemKey, NumItems);
		}
	}
}

void AP3ServerPlayerController::HandleGMCommandKillNPC(const TArray<FString>& Args) const
{
	UP3ServerWorld* ServerWorld = P3Core::GetP3World(*this)->GetServerWorld();

	if (!ServerWorld)
	{
		return;
	}

	for (AP3Character* ServerCharacter : ServerWorld->GetCharacters())
	{
		if (!ServerCharacter->IsPlayerControlled()
			&& ServerCharacter->GetCommandComponent()
			&& ServerCharacter->GetP3HealthComponentBP())
		{
			FP3CommandRequestParams Params;
			Params.ApplyDamage_DamageAmount = ServerCharacter->GetP3HealthComponentBP()->GetHealthPoint();
			Params.ApplyDamage_Reason = EP3HealthChangeReason::GM;
			ServerCharacter->GetCommandComponent()->RequestCommand(UP3ApplyDamageCommand::StaticClass(), Params);
		}
	}
}
