// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

namespace P3Tags
{
	/** This object doesn't damage character when hit */
	const static FName NoHitDamage(TEXT("NoHitDamage"));

	/** This actor is spawned by consumable component */
	const static FName SpawendByConsumable(TEXT("SpawendByConsumable"));

	/** This actor collide with charging Behemoth */
	const static FName StuckWhenColliding(TEXT("StuckWhenColliding"));
}
