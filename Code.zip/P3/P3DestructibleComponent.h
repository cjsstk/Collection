// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/StaticMeshComponent.h"
#include "Network/Lib/P3NetCore.h"
#include "P3StoreInterface.h"
#include "P3DestructibleComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3DestructibleComponentFratured, class UP3DestructibleComponent*, DestructibleComponent);

USTRUCT()
struct FNetFracture
{
	GENERATED_BODY()

	UPROPERTY()
	FVector HitLocation;
	
	UPROPERTY()
	FVector ImpulseDir;
	
	UPROPERTY()
	float ImpulseStrength;
};

UCLASS(ClassGroup = (P3), meta=(BlueprintSpawnableComponent) )
class P3_API UP3DestructibleComponent : public UStaticMeshComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3DestructibleComponent();

	virtual void InitializeComponent() override;
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	void SetupDestructible(bool bInStatic, int32 InHealthPoint, float InOwnerActorLifespanAfterFracture);
	void OverrideDebrisCollisionResponse(const FCollisionResponseContainer& Response);

	UFUNCTION(BlueprintCallable)
	class ADestructibleActor* GetSpawnedDestructibleActor() const { return DestructibleActor; }

	UFUNCTION(BlueprintCallable)
	void Server_Fracture(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength);

#if WITH_EDITOR
	virtual void CheckForErrors() override;
#endif

	UPROPERTY(BlueprintAssignable)
	FP3DestructibleComponentFratured DestructibleFractured;

private:
	UFUNCTION()
	void Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit);

	static int32 CalcDamagedMeshIndex(int32 HealthPoint, int32 MaxHealthPoint, int32 NumDamagedMeshes);

	void Server_CreateHealthPointComponent();

	UFUNCTION()
	void Server_OnHealthChanged(class UP3HealthPointComponent* InHealthPointComponent, int32 OldHealthPoint, int32 NewHealthPoint);

	void DamagedMeshIndexChanged();

	void Multicast_Fracture(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength);

	UFUNCTION()
	void Client_Fractured(const FP3DediToClientHandlerParams& Params);

	UPROPERTY(Transient)
	class UP3HealthPointComponent* HealthPointComponent;

	/** Toggle Static mesh physics simulation */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	bool bStatic = false;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	bool bEnableDestruction = true;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	class UDestructibleMesh* DestructableMesh;

	/** Optional. If set 4 meshes, each mesh will be used when HP amount become 20%, 40%, 60%, 80%. (Default static mesh will be used on 81~100%) */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	TArray<class UStaticMesh*> DamagedStaticMeshes;

	/** Set it > 0 to make it combat-compatible */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	int32 HealthPoint = 0.0f;

	/** < 0 means no fracture by physical impulse */
	UPROPERTY(EditAnywhere, Category = "Destructible - Fracture")
	float MinImpulseSizeToFracture = 100000;

	/** Set how strong fracture effect will be */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Fracture", meta = (DisplayAfter = "HealthPoint"))
	float FractureDamage = 5.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Fracture")
	class UParticleSystem* FractureParticle;

	/** Set socket name which socket start particle effect */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Fracture")
	FName FractureParticle_SocketName = NAME_None;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Fracture")
	float FractureParticleScale = 1.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Fracture")
	class USoundBase* FractureSound;

	/** Optional. If set, this mesh will be visible after fracture */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Debris", meta = (DisplayAfter = "FractureDamage"))
	class UStaticMesh* RemainStaticMesh;

	/** Set this 0 to let actor stay permanent after fracture */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Debris", meta = (DisplayAfter = "FractureDamage"))
	float OwnerActorLifespanAfterFracture = 5.0f;

	/** Set how long debris will remain */
	UPROPERTY(EditAnywhere, Category = "Destructible - Debris", meta = (DisplayAfter = "FractureDamage"))
	float DebrisLifespan = 5.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Debris", meta = (DisplayAfter = "FractureDamage"))
	float DestructibleImpulseMultiplier = 1.0f; 

	/** Set this true to use DebrisCollisionResponses */
	UPROPERTY(EditAnywhere, Category = "Destructible - Debris", meta = (DisplayAfter = "FractureDamage"))
	bool bOverrideDebrisCollisionResponse = false;

	/** Set this to override debris(destructible)'s collision response */
	UPROPERTY(EditAnywhere, Category = "Destructible - Debris", meta = (DisplayAfter = "FractureDamage", EditCondition = "bOverrideDebrisCollisionResponse"))
	struct FCollisionResponseContainer DebrisCollisionResponses;

	/** [Optional] If set, particle will spawn for each debris */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Debris")
	class UParticleSystem* DebrisParticle;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Debris")
	float DebrisParticleScale = 1.0f;

	/** If set true, hit event from debris will create surface particle effect */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Debris")
	bool bUseSurfaceHitEffectOnDebris = false;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Debris", meta = (EditCondition = "bUseSurfaceHitEffectOnDebris"))
	float SurfaceHitEffectSizeScale = 1.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	float Damage = 0.0f;

	/** Damage will be multiplied by this to ally character */
	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	int32 DamageToAllyPermil = 1000;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	float DamageRadius = 0.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	float HitActionImpulseSpeed = 0.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	bool bKnockDown = false;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	float KnockDownDurationSeconds = 0;

	/** If set, burn around up to Damage Radius */
	UPROPERTY(EditAnywhere, Category = "Destructible - Fire")
	bool bBurn = false;

	/** Near by Flammable components will take burn for this amount of time */
	UPROPERTY(EditAnywhere, Category = "Destructible - Fire", meta = (EditCondition = "bBurn"))
	float BurnPower = 1.0f;

	/** If set true, splash water on Damage Radius */
	UPROPERTY(EditAnywhere, Category = "Destructible - Water")
	bool bWaterSplash = false;

	/** Set actor class for water splash */
	UPROPERTY(EditAnywhere, Category = "Destructible - Water", meta = (EditCondition = "bWaterSplash"))
	TSubclassOf<AActor> WaterPuddleActorClass;

	UPROPERTY(Transient)
	UStaticMesh* DefaultStaticMesh;

	UPROPERTY(Transient)
	class ADestructibleActor* DestructibleActor;

	/** Actor list that hit event will not trigger destruction */
	UPROPERTY(Transient)
	TArray<AActor*> Server_HitIgnoreActors;

	/** Actor list that will not affected by explosion */
	UPROPERTY(Transient)
	TArray<AActor*> Server_ExplosionIgnoreActors;

	UPROPERTY(Transient)
	TMap<UParticleSystemComponent*, FName> Client_DebrisParticles;

	/** 
	 * Runtime status
	 */

	/** -1 means Default mesh */
	int32 Net_DamagedMeshIndex = -1;

	/** Fractured? */
	bool Server_bFractured = false;
	bool Multicast_bFractured = false;

	/** Time since fracture */
	float FractureAgeSeconds = 0;
};
