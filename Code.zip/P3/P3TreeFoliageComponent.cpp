// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3TreeFoliageComponent.h"
#include "P3Core.h"

#include "DrawDebugHelpers.h"
#include "TimerManager.h"

static TAutoConsoleVariable<int32> CVarP3UseTreeFoliage(
	TEXT("p3.useTreeFoliage"),
	1,
	TEXT("1: use 0: no use (origianl foliage)"), ECVF_Cheat);

void UP3TreeFoliageComponent::BeginPlay()
{
	Super::BeginPlay();

	GetWorld()->GetTimerManager().SetTimerForNextTick(
		FTimerDelegate::CreateUObject(this, &UP3TreeFoliageComponent::ReplaceToP3Tree));
}

void UP3TreeFoliageComponent::ReplaceToP3Tree()
{
	if (CVarP3UseTreeFoliage.GetValueOnGameThread() != 0)
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			const FTransform ComponentTransform = GetComponentTransform();

			for (const FInstancedStaticMeshInstanceData& InstanceData : PerInstanceSMData)
			{
				//DrawDebugSphere(GetWorld(), InstanceData.Transform.GetOrigin(), 300, 16, FColor::Red, false, 10.0f);

				FActorSpawnParameters SpawnParameters;
				SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

				AActor* ReplaceActor = GetWorld()->SpawnActor<AActor>(ReplaceActorClass.Get(), FTransform(InstanceData.Transform) * ComponentTransform, SpawnParameters);
			}
		}

		DestroyComponent();
	}
}
