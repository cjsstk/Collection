// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

class FP3IdGenerator
{
public:
	void InitGenerator(uint64 InMachineId);
	bool IsInitialized() const;
	uint64 Generate(bool bCheckMarchineId = false);

private:
	uint64 GetCurrentTimestamp() const;

	uint64 MachineId = 0;
	uint64 LastTimestamp = 0;
	uint64 LastSeq = 0;
};
