// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PushableComponent.h"


UP3PushableComponent::UP3PushableComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UP3PushableComponent::Server_AddPusher(class AActor& Pusher)
{
	Server_Pushers.Remove(nullptr);
	Server_Pushers.AddUnique(&Pusher);
}

void UP3PushableComponent::Server_RemovePusher(class AActor& Pusher)
{
	Server_Pushers.Remove(nullptr);
	Server_Pushers.Remove(&Pusher);
}
