// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Framework/Application/SlateApplication.h"


enum class EP3InputDirection
{
	None,
	Up,
	Down,
	Right,
	Left,
};

namespace P3Input
{
	EP3InputDirection _AxisInputToDirection(bool bIsVertical, float Value);
}

class FP3SlateInputMapping : public ISlateInputManager
{
public:
	virtual int32 GetUserIndexForKeyboard() const override { return 0; }

	/** 모든 컨트롤러를 0번 유저로 돌림. 간혹 연결된 패드가 Controller 0번이 아닐 경우, 게임에서 쓰지 못하는 문제를 해결하기 위함 */
	virtual int32 GetUserIndexForController(int32 ControllerId) const override { return 0; }
};
