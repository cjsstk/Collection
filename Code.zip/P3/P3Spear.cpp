// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Spear.h"

#include "Classes/CableComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Character.h"

#include "Action/P3PawnActionComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3Combat.h"
#include "P3Core.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3PartComponent.h"
#include "P3Physics.h"
#include "P3PickupableComponent.h"
#include "P3Weapon.h"
#include "P3World.h"

static TAutoConsoleVariable<float> CVarP3TargetVelocityForUnpenetrable(
	TEXT("p3.targetVelocityForUnpenetrable"),
	1000.0f,
	TEXT("Spear can't attach to target moving above this velocity"), ECVF_Cheat);

const static FName EventName_Hit(TEXT("SpearHit"));
const static FName EventName_TargetDead(TEXT("SpearTargetDead"));
const static FName EventName_Detach(TEXT("SpearDetach"));

AP3Spear::AP3Spear()
{
	PrimaryActorTick.bCanEverTick = true;

	bReplicateMovement = true;

	PickupableComponent = CreateDefaultSubobject<UP3PickupableComponent>(TEXT("PickupableComponent"));
	PickupableComponent->SetPickupableType(EP3PickupableType::Spear);
}

void AP3Spear::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaSeconds);
	}

	if (PitchingMomentDuringFlying != 0)
	{
		UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
		if (MyPrimComp->IsSimulatingPhysics())
		{
			const FVector Velocity = MyPrimComp->GetPhysicsLinearVelocity();
			const float Speed = Velocity.Size();
			if (Speed > SMALL_NUMBER)
			{
				const FVector MovingDirection = Velocity / Speed;
				const FVector ForwardVector = GetActorForwardVector();
				const float Drag = 1.0f - FMath::Abs(ForwardVector | MovingDirection);
				if (Drag > SMALL_NUMBER)
				{
					const FVector TorqueAxis = (ForwardVector ^ MovingDirection).GetSafeNormal();
					const FVector AngularImpulse = TorqueAxis * Drag * FMath::Square(Speed) * PitchingMomentDuringFlying * DeltaSeconds;

					MyPrimComp->AddAngularImpulseInDegrees(AngularImpulse);
				}
			}
		}
	}
}

void AP3Spear::Client_OnEvent(FName EventName, int32 Param)
{
	Super::Client_OnEvent(EventName, Param);

	if (EventName == EventName_Hit)
	{
		UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
		if (MyPrimComp)
		{
			MyPrimComp->SetSimulatePhysics(false);
		}
	}
	else if (EventName == EventName_TargetDead)
	{
		UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
		if (MyPrimComp)
		{
			MyPrimComp->SetSimulatePhysics(true);
		}
	}
	else if (EventName == EventName_Detach)
	{
		UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
		if (MyPrimComp)
		{
			MyPrimComp->SetSimulatePhysics(true);
		}
	}
}

void AP3Spear::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		bool bAttached = (GetAttachParentActor() != nullptr);

		Archive << bAttached;
	}
	else
	{
		bool bAttached = false;

		Archive << bAttached;

		if (bAttached)
		{
			// TODO: simulation physics better be synced by world automatically
			UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
			if (MyPrimComp)
			{
				MyPrimComp->SetSimulatePhysics(false);
			}
		}
	}
}

void AP3Spear::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		TInlineComponentArray<UPrimitiveComponent*, 8> Components;
		GetComponents(Components);

		for (UPrimitiveComponent* Component : Components)
		{
			if (Component->GetCollisionObjectType() != ECC_FLAME)
			{
				Component->OnComponentBeginOverlap.AddUniqueDynamic(this, &AP3Spear::Server_OnComponentBeginOverlap);
			}
		}
	}
}

void AP3Spear::Server_Tick(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_LastVelocity = GetVelocity();

	UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
	if (!ensure(MyPrimComp))
	{
		return;
	}

	UP3PickupableComponent* PickupableComp = FindComponentByClass<UP3PickupableComponent>();
	if (!ensure(PickupableComp))
	{
		return;
	}

	AActor* ParentActor = GetAttachParentActor();

	/** When pickup spear SimulatePhysics become false too. So need to check Lock */
	if (!MyPrimComp->IsSimulatingPhysics() && !PickupableComp->Server_IsInteractionLocked())
	{
		/** Spear is in the air Or Monster destroyed */
		if (!ParentActor || ParentActor->IsActorBeingDestroyed())
		{
			if (ParentActor)
			{
				DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
			}
			Server_MulticastEvent(EventName_TargetDead, 0);
		}
	}

	/** If spear is not used, it will be gone in DestroyTimeSeconds */
	if (ParentActor)
	{
		Server_TimeSinceLastAttachSeconds = 0.0f;
		Server_bUsed = true;
	}
	else if (Server_bUsed && !PickupableComp->Server_IsInteractionLocked())
	{
		Server_TimeSinceLastAttachSeconds += DeltaSeconds;
		if (Server_TimeSinceLastAttachSeconds > DestroyTimeSeconds)
		{
			Destroy();
		}
	}

	ACharacter* CurrentParentCharacter = Cast<ACharacter>(ParentActor);

	if (Server_TargetCharacter)
	{
		if (!CurrentParentCharacter || CurrentParentCharacter != Server_TargetCharacter)
		{
			Server_TargetCharacter->OnCharacterRevive.RemoveDynamic(this, &AP3Spear::Server_OnCharacterRevive);
			Server_TargetCharacter = nullptr;
		}
	}
}

void AP3Spear::Server_Hit(UPrimitiveComponent& OtherComp, FName SocketName)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (GetInstigator() && GetInstigator() == OtherComp.GetOwner())
	{
		// Do not hit thrower
		// This can happen since throwing time is based on animation event
		// TODO: better make this not happening at at. Even if we ignore hit, spear will probably stop flying..
		return;
	}

	Server_MulticastEvent(EventName_Hit, 0);

	UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
	if (!MyPrimComp)
	{
		return;
	}

	// Let spear to through little bit more
	AddActorWorldOffset(Server_LastVelocity.GetSafeNormal() * PenetrationDepthOnHit);

	// And attach to it
	AttachToComponent(&OtherComp, FAttachmentTransformRules::KeepWorldTransform, SocketName);

	Server_TargetCharacter = Cast<AP3Character>(OtherComp.GetOwner());
	if (Server_TargetCharacter)
	{
		Server_TargetCharacter->OnCharacterRevive.AddUniqueDynamic(this, &AP3Spear::Server_OnCharacterRevive);
		if (!Server_TargetCharacter->IsPlayerControlled())
		{
			AActor* CombatSourceActor = this;
			if (Instigator)
			{
				CombatSourceActor = Instigator;
			}

			P3Combat::FDamageActorParams DamageParams(*CombatSourceActor, *Server_TargetCharacter);
			DamageParams.AttackStrength = EAnimNotifyAttackStrengthFlags::Large;
			DamageParams.AttackDirection = EAnimNotifyAttackDirectionFlags::Push;
			DamageParams.AttackAttribute = EP3AnimNotifyAttackAttribute::Pierce;
			DamageParams.TargetComponent = &OtherComp;
			DamageParams.ImpactDirection = Server_LastVelocity.GetSafeNormal();
			DamageParams.BoneName = SocketName;
			DamageParams.DamagePermil = DamagePermil;
			DamageParams.TemporaryWeaponType = TemporaryWeaponType;

			P3Combat::Server_DamageActor(DamageParams);
		}
		else // If player controlled character
		{
			//Server_TargetCharacter->HitByLargeObjectBP(this);

			UP3CommandComponent* CommandComp = Server_TargetCharacter->GetCommandComponent();
			if (CommandComp)
			{
				FP3CommandRequestParams RagdollizeParams;
				RagdollizeParams.Ragdollize_bRagdoll = true;
				CommandComp->RequestCommand(UP3RagdollizeCommand::StaticClass(), RagdollizeParams);

				UP3HealthPointComponent* HealthComp = Server_TargetCharacter->GetP3HealthComponentBP();
				if (HealthComp)
				{
					FP3CommandRequestParams DamageParams;
					DamageParams.ApplyDamage_SourceActor = this;
					DamageParams.ApplyDamage_DamageAmount = HealthComp->GetMaxHealthPoint();
					DamageParams.ApplyDamage_Reason = EP3HealthChangeReason::Spear;
					CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), DamageParams);
				}

				UP3World* World = P3Core::GetP3World(*this);
				check(World);

				ensure(GetActorId()!= INVALID_ACTORID);

				FNetSpearAttachToCharacter NetSpearAttachToCharacter;
				NetSpearAttachToCharacter.TargetComponent = &OtherComp;
				NetSpearAttachToCharacter.SocketName = SocketName;
				NetSpearAttachToCharacter.Impulse = Server_LastVelocity * 10;

				World->Server_MulticastPacketReliable(this, GetActorId(), GetOwner(), NetSpearAttachToCharacter, EP3NetComponentType::None, &AP3Spear::Client_AttachToCharacter);

				Multicast_AttachToCharacter(&OtherComp, SocketName, NetSpearAttachToCharacter.Impulse);
			}
		}
	}
}

void AP3Spear::Server_OnCharacterRevive()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	ACharacter* CurrentParentCharacter = Cast<ACharacter>(GetAttachParentActor());

	if (!CurrentParentCharacter || !Server_TargetCharacter)
	{
		return;
	}

	if (CurrentParentCharacter != Server_TargetCharacter)
	{
		return;
	}

	Server_DetachFromActor();

	Server_TargetCharacter->OnCharacterRevive.RemoveDynamic(this, &AP3Spear::Server_OnCharacterRevive);
	Server_TargetCharacter = nullptr;
}

void AP3Spear::Server_DetachFromActor()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	Server_MulticastEvent(EventName_Detach, 0);
}

void AP3Spear::Server_OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_LastVelocity.SizeSquared() < 500)
	{
		return;
	}

	if (GetAttachParentActor())
	{
		return;
	}

	ACharacter* Character = Cast<ACharacter>(OtherActor);
	if (Character && OtherComp && OtherComp->IsA(USkeletalMeshComponent::StaticClass()))
	{
		const FBox BoundingBox = CalculateComponentsBoundingBoxInLocalSpace();
		const float SpearTipDistance = BoundingBox.GetCenter().X + BoundingBox.GetExtent().X;
		const FVector TipLocation = GetTransform().TransformPosition(FVector(SpearTipDistance, 0, 0));

		FHitResult HitResult;
		const bool bHitFound = OtherComp->LineTraceComponent(HitResult, GetActorLocation(), TipLocation, FCollisionQueryParams());
		if (bHitFound)
		{
			Server_Hit(*OtherComp, HitResult.BoneName);
		}
	}
}

void AP3Spear::Client_AttachToCharacter(const FP3DediToClientHandlerParams& Params)
{
	FNetSpearAttachToCharacter NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		Multicast_AttachToCharacter(NetParams.TargetComponent, NetParams.SocketName, NetParams.Impulse);
	}
}

void AP3Spear::Multicast_AttachToCharacter(UPrimitiveComponent* TargetComponent, FName SocketName, const FVector& Impulse)
{
	if (!ensure(TargetComponent))
	{
		return;
	}

	UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
	if (!ensure(MyPrimComp))
	{
		return;
	}

	TargetComponent->AddImpulseAtLocation(Impulse, GetActorLocation(), SocketName);

	MyPrimComp->AttachToComponent(TargetComponent, FAttachmentTransformRules::KeepWorldTransform, SocketName);
	const bool bWelded = MyPrimComp->WeldToImplementation(TargetComponent, SocketName);

	ensure(bWelded);
}

void AP3Spear::NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (GetAttachParentActor())
		{
			return;
		}

		if (Other && OtherComp)
		{
			// Ignore Character Capsule
			ACharacter* OtherCharacter = Cast<ACharacter>(Other);
			if (OtherCharacter && OtherComp == OtherCharacter->GetCapsuleComponent())
			{
				return;
			}

			UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
			if (ensure(MyPrimComp))
			{
				const float MyMass = MyPrimComp->GetMass();
				const FVector MyForwardVec = GetActorForwardVector();
				const bool bIsFrontalImpact = (Hit.ImpactNormal | MyForwardVec) < -0.1f;
				const bool bEnoughImpact = (NormalImpulse.SizeSquared() > FMath::Square(MyMass * 100));

				if (bIsFrontalImpact && bEnoughImpact)
				{
					Server_Hit(*OtherComp, Hit.BoneName);
				}
			}
		}
	}
}

UP3JavelinComponent::UP3JavelinComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3JavelinComponent::Throw(const FVector& Direction, APawn* Instigator)
{
	// TODO-FIXME: This must be done only from server, otherwise if one side fails, final status will be different

	AP3Weapon* WeaponActor = Cast<AP3Weapon>(GetOwner());

	if (!ensure(WeaponActor))
	{
		return;
	}

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(WeaponActor->GetRootComponent());

	if (!ensure(PrimComp))
	{
		return;
	}

	TInlineComponentArray<UPrimitiveComponent*, 8> Components;
	WeaponActor->GetComponents(Components);

	WeaponActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	WeaponActor->Instigator = Instigator;

	// Make fly!	
	PrimComp->SetSimulatePhysics(true);
	PrimComp->SetPhysicsLinearVelocity(Direction * ThrowSpeed);
	PrimComp->SetPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
	PrimComp->SetWorldRotation(Direction.Rotation());	

	for (UPrimitiveComponent* Component : Components)
	{
		Component->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	}

	bFlying = true;

	UCableComponent* CableComp = WeaponActor->FindComponentByClass<UCableComponent>();
	if (CableComp && WeaponActor->Instigator)
	{		
		CableComp->SetVisibility(true);
		CableComp->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		
		CableComp->bAttachEnd = true;
		CableComp->NumSegments = 10;
		CableComp->CableGravityScale = 0.05f;
		CableComp->CableWidth = 2.5f;
		CableComp->CableLength = 1000.f;
		CableComp->bEnableCollision = false;
		
		CableComp->SetAttachEndTo(Instigator, NAME_None);

		Server_CableVisibleStartedTimeSeconds = 0.f;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		WeaponActor->OnActorHit.AddUniqueDynamic(this, &UP3JavelinComponent::Server_OnActorHit);

		for (UPrimitiveComponent* Component : Components)
		{
			if (Component->GetCollisionObjectType() != ECC_FLAME)
			{
				Component->OnComponentBeginOverlap.AddUniqueDynamic(this, &UP3JavelinComponent::Server_OnComponentBeginOverlap);
			}
		}
	}
}

void UP3JavelinComponent::NetSerialize(FArchive& Archive)
{
	Archive << Net_ImpaledCharacter;
}

void UP3JavelinComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (PitchingMomentDuringFlying != 0)
	{
		AActor* OwnerActor = GetOwner();

		UPrimitiveComponent* MyPrimComp = OwnerActor ? Cast<UPrimitiveComponent>(OwnerActor->GetRootComponent()) : nullptr;

		if (MyPrimComp && MyPrimComp->IsSimulatingPhysics())
		{
			const FVector Velocity = MyPrimComp->GetPhysicsLinearVelocity();
			const float Speed = Velocity.Size();
			if (Speed > 10.0f)
			{
				const FVector MovingDirection = Velocity / Speed;
				const FVector ForwardVector = OwnerActor->GetActorForwardVector();
				const float Drag = 1.0f - FMath::Abs(ForwardVector | MovingDirection);
				if (Drag > SMALL_NUMBER)
				{
					const FVector TorqueAxis = (ForwardVector ^ MovingDirection).GetSafeNormal();
					const FVector AngularImpulse = TorqueAxis * Drag * FMath::Square(Speed) * PitchingMomentDuringFlying * DeltaTime;

					MyPrimComp->AddAngularImpulseInDegrees(AngularImpulse);
				}
			}
		}
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaTime);
	}
}

void UP3JavelinComponent::Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}
	
	AActor* OwnerActor = GetOwner();
	bool bHit = false;

	if (!ensure(OwnerActor))
	{
		return;
	}

	if (OwnerActor->GetAttachParentActor())
	{
		return;
	}
	
	if (OtherActor)
	{
		UPrimitiveComponent* OtherComp = Hit.GetComponent();

		// Ignore Character Capsule
		ACharacter* OtherCharacter = Cast<ACharacter>(OtherActor);

		if (OtherCharacter && OtherComp == OtherCharacter->GetCapsuleComponent())
		{
			return;
		}

		UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(OwnerActor->GetRootComponent());

		if (ensure(MyPrimComp))
		{
			const float MyMass = MyPrimComp->GetMass();
			const FVector MyForwardVec = OwnerActor->GetActorForwardVector();
			const bool bIsFrontalImpact = (Hit.ImpactNormal | MyForwardVec) < -0.1f;
			const bool bEnoughImpact = (NormalImpulse.SizeSquared() > FMath::Square(MyMass * 100));

			if (bIsFrontalImpact && bEnoughImpact)
			{
				bHit = Server_Hit(*OtherComp, Hit.BoneName);
			}
		}
	}

	Server_CableHit(Hit.GetComponent(), bHit, true);
}

void UP3JavelinComponent::Server_OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();
	bool bHit = false;		

	if (!ensure(OwnerActor))
	{
		return;
	}

	if (Server_LastVelocity.SizeSquared() < 500)
	{
		return;
	}

	if (OwnerActor->GetAttachParentActor())
	{
		return;
	}
	
	if (OwnerActor->Instigator == OtherActor)
	{
		return;
	}

	ACharacter* Character = Cast<ACharacter>(OtherActor);
	if (Character && OtherComp && OtherComp->IsA(USkeletalMeshComponent::StaticClass()))
	{
		const FBox BoundingBox = OwnerActor->CalculateComponentsBoundingBoxInLocalSpace();
		const float SpearTipDistance = BoundingBox.GetCenter().X + BoundingBox.GetExtent().X;
		const FVector TipLocation = OwnerActor->GetTransform().TransformPosition(FVector(SpearTipDistance, 0, 0));
				
		FHitResult HitResult;
		const bool bHitFound = OtherComp->LineTraceComponent(HitResult, OwnerActor->GetActorLocation(), TipLocation, FCollisionQueryParams());

		if (bHitFound)
		{
			bHit = Server_Hit(*OtherComp, HitResult.BoneName);			
		}
	}

	Server_CableHit(OtherComp, bHit, false);
}

void UP3JavelinComponent::Server_Tick(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();

	if (!ensure(OwnerActor))
	{
		return;
	}

	/** Restart physics if attached parent is missing (maybe died, destroyed) */
	UP3PickupableComponent* PickupableComp = OwnerActor->FindComponentByClass<UP3PickupableComponent>();
	UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(OwnerActor->GetRootComponent());
	AActor* ParentActor = OwnerActor->GetAttachParentActor();

	if (MyPrimComp && !MyPrimComp->IsSimulatingPhysics() && (!PickupableComp || !PickupableComp->Server_IsInteractionLocked()))
	{
		if (!ParentActor || ParentActor->IsActorBeingDestroyed())
		{
			if (ParentActor)
			{
				ParentActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
			}

			MyPrimComp->SetSimulatePhysics(true);
		}
	}

	Server_LastVelocity = OwnerActor->GetVelocity();

	if (Net_ImpaledCharacter)
	{
		if (OwnerActor->GetAttachParentActor() != Net_ImpaledCharacter)
		{
			Server_SetImapledCharacter(nullptr);
		}
	}

	UCableComponent* CableComp = OwnerActor->FindComponentByClass<UCableComponent>();
	if (CableComp && CableComp->IsVisible())
	{
		Server_CableVisibleStartedTimeSeconds += DeltaSeconds;

		if (Server_CableVisibleStartedTimeSeconds > CableAttachEndTimeSeconds)
		{
			AP3Character* Character = Cast<AP3Character>(OwnerActor->Instigator);

			UP3CommandComponent* CommandComp = Character ? Character->GetCommandComponent() : nullptr;
			if (CommandComp)
			{
				FP3CommandRequestParams CableAttachEndParams;
				CableAttachEndParams.CableWeaponActor = OwnerActor;

				CommandComp->RequestCommand(UP3CableAttachEndCommand::StaticClass(), CableAttachEndParams);
			}

			Server_CableVisibleStartedTimeSeconds = 0.f;
		}		
	}
}

bool UP3JavelinComponent::Server_Hit(UPrimitiveComponent& OtherComp, FName BoneName)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	AP3Weapon* WeaponActor = Cast<AP3Weapon>(GetOwner());

	if (!ensure(WeaponActor))
	{
		return false;
	}

	if (WeaponActor->GetInstigator() && WeaponActor->GetInstigator() == OtherComp.GetOwner())
	{
		// Do not hit thrower
		// This can happen since throwing time is based on animation event
		// TODO: better make this not happening at at. Even if we ignore hit, spear will probably stop flying..
		return false;
	}

	AP3Character* TargetCharacter = Cast<AP3Character>(OtherComp.GetOwner());

	// Ignore player character
	if (TargetCharacter && TargetCharacter->IsPlayerControlled())
	{
		return false;
	}

	bUnpenetrablePart = false;

	if (TargetCharacter && TargetCharacter->IsLarge()
		&& TargetCharacter->GetVelocity().SizeSquared() > FMath::Pow(CVarP3TargetVelocityForUnpenetrable.GetValueOnGameThread(), 2))
	{
		bUnpenetrablePart = true;
	}

	TArray<UP3PartComponent*> HitPartComponents;

	if (TargetCharacter && !bUnpenetrablePart)
	{
		if (BoneName.IsValid())
		{
			// See if it's a non-penetrable part
			TInlineComponentArray<UP3PartComponent*, 24> PartComponents;
			TargetCharacter->GetComponents(PartComponents);

			for (UP3PartComponent* PartComp : PartComponents)
			{
				if (!ensure(PartComp))
				{
					continue;
				}

				if (!PartComp->IsPartActivated())
				{
					continue;
				}

				if (PartComp->GetPartDesc().HitAreaBones.Contains(BoneName))
				{
					if (!PartComp->GetPartDesc().bPenetrable)
					{
						bUnpenetrablePart = true;
						break;
					}

					HitPartComponents.Add(PartComp);
				}
			}
		}
	}

	if (bUnpenetrablePart)
	{
		// Bounce off

		UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(WeaponActor->GetRootComponent());
		if (MyPrimComp)
		{
			FVector Velocity = MyPrimComp->GetPhysicsLinearVelocity();
			Velocity *= -0.5f;

			const float Speed = Velocity.Size();

			const FVector AngularVelocity(FMath::RandRange(-Speed, Speed), FMath::RandRange(-Speed, Speed), FMath::RandRange(-Speed, Speed));

			MyPrimComp->SetPhysicsLinearVelocity(Velocity);
			MyPrimComp->AddAngularImpulseInDegrees(AngularVelocity, NAME_None, true);
		}

		JavelinBounced.Broadcast(&OtherComp);
	}
	else
	{
		// Penetrated

		// Attach to target (Impale)
		UPrimitiveComponent* MyPrimComp = Cast<UPrimitiveComponent>(WeaponActor->GetRootComponent());
		if (!MyPrimComp)
		{
			return false;
		}

		const FVector Velocity = MyPrimComp->GetPhysicsLinearVelocity();

		// Need to turn off physics to attach
		MyPrimComp->SetSimulatePhysics(false);

		// Let spear to through little bit more
		WeaponActor->AddActorWorldOffset(Server_LastVelocity.GetSafeNormal() * PenetrationDepthOnHit);

		// And attach to it
		WeaponActor->AttachToComponent(&OtherComp, FAttachmentTransformRules::KeepWorldTransform, BoneName);

		Server_SetImapledCharacter(TargetCharacter);

		if (TargetCharacter)
		{
			TargetCharacter->Server_ReceiveImpaled(GetOwner(), Velocity.GetSafeNormal(), HitPartComponents);
		}

		JavelinImpaled.Broadcast(&OtherComp);
	}
	
	if (TargetCharacter)
	{
		// Damage Target

		AActor* CombatSourceActor = WeaponActor;
		if (WeaponActor->GetInstigator())
		{
			CombatSourceActor = WeaponActor->GetInstigator();
		}

		P3Combat::FDamageActorParams DamageParams(*CombatSourceActor, *TargetCharacter);
		DamageParams.AttackStrength = EAnimNotifyAttackStrengthFlags::Large;
		DamageParams.AttackDirection = EAnimNotifyAttackDirectionFlags::Push;
		DamageParams.AttackAttribute = EP3AnimNotifyAttackAttribute::Pierce;
		DamageParams.TargetComponent = &OtherComp;
		DamageParams.ImpactDirection = Server_LastVelocity.GetSafeNormal();
		DamageParams.BoneName = BoneName;
		DamageParams.DamagePermil = DamagePermil;
		DamageParams.TemporaryWeaponType = EP3TemporaryWeaponType::Javelin;

		P3Combat::Server_DamageActor(DamageParams);		
	}

	return true;
}

void UP3JavelinComponent::Server_CableHit(UPrimitiveComponent* OtherComp, bool bHit, bool bCableAttachEnd)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Weapon* WeaponActor = Cast<AP3Weapon>(GetOwner());
	if (!WeaponActor || !OtherComp)
	{
		return;
	}
	
	UCableComponent* CableComp = WeaponActor->FindComponentByClass<UCableComponent>();
	if (CableComp)
	{
		AP3Character* Character = Cast<AP3Character>(WeaponActor->Instigator);
		AP3Character* TargetCharacter = Cast<AP3Character>(OtherComp->GetOwner());

		if (bHit && CanCableMove(Character, TargetCharacter))
		{
			UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
			if (ActionComp)
			{
				FP3PawnActionStartRequestParams Params;
				Params.CableMove_WeaponActorID = WeaponActor->GetActorId();
				Params.CableMove_HitActorActorID = TargetCharacter->GetActorId();
				Params.CableMove_WeaponActor = WeaponActor;				
				Params.CableMove_CableMoveImpulse = CableMoveImpulse;

				ActionComp->StartAction(EPawnActionType::CableMove, _FUNCTION_TEXT, Params);
			}			
		}
		else
		{
			if (CableComp->GetAttachedActor() && bCableAttachEnd)
			{
				UP3CommandComponent* CommandComp = Character ? Character->GetCommandComponent() : nullptr;
				if (CommandComp)
				{
					FP3CommandRequestParams CableAttachEndParams;
					CableAttachEndParams.CableWeaponActor = WeaponActor;

					CommandComp->RequestCommand(UP3CableAttachEndCommand::StaticClass(), CableAttachEndParams);
				}
			}
		}
	}
}

void UP3JavelinComponent::Server_SetImapledCharacter(class AP3Character* Character)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_ImpaledCharacter == Character)
	{
		return;
	}

	Net_ImpaledCharacter = Character;

	Server_SetDirty(*this);
}

bool UP3JavelinComponent::CanCableMove(const AP3Character* Character, const AP3Character* TargetCharacter) const
{
	if (!Character || !TargetCharacter)
	{
		return false;
	}

	if (bUnpenetrablePart && !IgnoreUnpenetrablePart)
	{
		return false;
	}

	FVector TargetLocation = TargetCharacter->GetActorLocation();
	float Size2D = (Character->GetActorLocation() - TargetLocation).Size2D();
	const bool bCanCableMove = Size2D > CableMoveMinDist && Size2D < CableMoveMaxDist && Character->GetFaction() != TargetCharacter->GetFaction();

	return bCanCableMove;
}
