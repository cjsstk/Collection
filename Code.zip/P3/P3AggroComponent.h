// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameFramework/Actor.h"
#include "P3AggroComponent.generated.h"

USTRUCT()
struct FP3AggroItem
{
	GENERATED_BODY()

	UPROPERTY()
	TWeakObjectPtr<AActor> Actor;

	UPROPERTY()
	int32 Point = 0;

	/** We need this to remove revived character */
	UPROPERTY()
	float LastDeadTime = 0.0f;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3AggroComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3AggroComponent();

	virtual void OnRegister() override;
	virtual void OnUnregister() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	void OnHit(AActor* SourceActor, int32 Damage);
	void OnSight(AActor* SourceActor);

	void ClearAggro();
	void ResetAggro(int32 RandomRange);
	void ResetAggroOf(const AActor& SourceActor, int32 RandomRange);
	void RemoveAggroOf(const AActor& SourceActor);

	/** Set aggro of given actor to be top on the table */
	void MakeAsTop(AActor& Actor);

	AActor* GetTopActor();
	TArray<AActor*> GetAllActors() const;
	const TArray<FP3AggroItem>& GetSortedAggroItems() const;

protected:
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void OnCharacterDead();

	void SortItems();
	void RemoveInvalidItems();

	FP3AggroItem* FindItemByActor(AActor& Actor);
	FP3AggroItem& FindOrCreateItemByActor(AActor& Actor);

	// Replicate for debugging at client
	UPROPERTY(Replicated)
	TArray<FP3AggroItem> Items;

	mutable TArray<FP3AggroItem> SortedItems;
};
