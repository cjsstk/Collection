// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "P3TimeOfDaySettings.generated.h"

/** 
 * Optional setting actor for Time of Day
 */
UCLASS()
class P3_API AP3TimeOfDaySettings : public AActor
{
	GENERATED_BODY()

public:
	/** Game will start with this time */
	UPROPERTY(EditAnywhere)
	float DefaultHour = 9.0f;

	/** Time of day = Real time * speed */
	UPROPERTY(EditAnywhere)
	float Speed = 24.0f;
};
