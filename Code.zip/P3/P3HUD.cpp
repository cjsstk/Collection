// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3HUD.h"

#include "UserWidget.h"

#include "Widget/P3InGameActionWidget.h"
#include "Widget/P3SubtitleWidget.h"

static TAutoConsoleVariable<int32> CVarP3ShowUI(
	TEXT("p3.showUI"),
	1,
	TEXT("1: show UI , 0: not show UI "), ECVF_Cheat);

void AP3HUD::BeginPlay()
{
	Super::BeginPlay();

	if (HealthBarsWidgetClass.Get())
	{
		HealthBarsWidget = CreateWidget(GetOwningPlayerController(), HealthBarsWidgetClass.Get(), FName(TEXT("HealthBars")));
		HealthBarsWidget->AddToViewport();
	}

	if (InGameActionWidgetClass.Get())
	{
		InGameActionWidget = CreateWidget<UP3InGameActionWidget>(GetOwningPlayerController(), InGameActionWidgetClass.Get(), FName(TEXT("InGameAction")));
		InGameActionWidget->AddToViewport();
	}

	if (SubtitleWidgetClass.Get())
	{
		SubtitleWidget = CreateWidget<UP3SubtitleWidget>(GetOwningPlayerController(), SubtitleWidgetClass.Get(), FName(TEXT("Subtitle")));
		SubtitleWidget->AddToViewport();
	}
}

void AP3HUD::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!bShowHUD || CVarP3ShowUI.GetValueOnGameThread() == 0)
	{
		if (HealthBarsWidget)
		{
			HealthBarsWidget->SetVisibility(ESlateVisibility::Collapsed);
		}

		if (InGameActionWidget)
		{
			InGameActionWidget->SetVisibility(ESlateVisibility::Collapsed);
		}

		/** TODO : Need a subtitle visible policy */
		/*if (SubtitleWidget)
		{
			SubtitleWidget->SetVisibility(ESlateVisibility::Collapsed);
		}*/
	}
	else
	{
		if (HealthBarsWidget)
		{
			HealthBarsWidget->SetVisibility(ESlateVisibility::HitTestInvisible);
		}

		if (InGameActionWidget)
		{
			InGameActionWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}

		/*if (SubtitleWidget)
		{
			SubtitleWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}*/
	}
}
