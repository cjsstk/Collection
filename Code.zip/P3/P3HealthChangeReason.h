// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3HealthChangeReason.generated.h"

UENUM()
enum class EP3HealthChangeReason : uint8
{
	Unknown,
	Damage,
	DamageOverTime,
	PainCausing,
	ActorHit,
	HitByLargeObject,
	Explode,
	Fall,
	Swamp,
	Flame,
	Spear,
	Suicide,
	QuickDeath,
	Consumable,
	Thrown,
	Heal,
	GM,
};
