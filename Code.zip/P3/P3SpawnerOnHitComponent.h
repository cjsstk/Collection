// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "P3SpawnerOnHitComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3SpawnerOnHitComponent : public USceneComponent
{
	GENERATED_BODY()

public:	
	UP3SpawnerOnHitComponent();
	
protected:
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit);

	UFUNCTION()
	void Server_OnActorBeginOverlap(AActor* OverlappedActor, AActor* OtherActor);

	void Server_SpawnActor();

	UPROPERTY(EditDefaultsOnly, Category = "Spawn on hit")
	TSubclassOf<class AActor> SpawnActorClass = nullptr;
	
	/** Need impulse size on hit for Spawn actor */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn on hit")
	float HitImpulseSizeForSpawn = 40000.0f;

	/** If true, owner actor will destroy after spawn actor */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn on hit")
	bool bDestroyOwnerAfterSpawn = true;

	/** Don't spawn during this cooldown time seconds */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn on hit")
	float SpawnCoolDownSeconds = 5.0f;

	/** If set true, overlap with large character will consider as hit */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn on hit")
	bool bOverlapWithLargeCharacter = true;

	/** If this is not 0 and current time is below this, it means you are in cooldown */
	float Server_CooldownFinishTimeSeconds = 0.0f;
};
