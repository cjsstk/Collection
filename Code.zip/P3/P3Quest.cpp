// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3Quest.h"

#include "Network/P3WorldNet.h"
#include "P3Character.h"
#include "P3Log.h"
#include "P3QuestComponent.h"
#include "P3QuestSwitchActor.h"
#include "P3QuestVolume.h"

/*
 * Quest
 */

void UP3Quest::InitQuest(UP3QuestComponent* InQuestComponent, questkey InQuestKey)
{
	if (!ensure(InQuestKey != INVALID_QUESTKEY))
	{
		return;
	}

	if (!ensure(P3Cms::GetQuestDescFromQuestKey(InQuestKey)))
	{
		return;
	}

	QuestComponent = InQuestComponent;
	QuestKey = InQuestKey;
	QuestDesc = P3Cms::GetQuestDescFromQuestKey(InQuestKey);
	State = EP3QuestState::PrepareNextPhase;
}

void UP3Quest::InitQuestData(const FP3QuestData& InQuestData)
{
	UpdateQuestData(InQuestData);

	if (PhaseIndex < 0)
	{
		return;
	}

	for (int32 Index = 0; Index < PhaseIndex; ++Index)
	{
		if (!QuestDesc->QuestPhases.IsValidIndex(Index))
		{
			return;
		}

		const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[Index];

		if (!ensure(PhaseDesc))
		{
			continue;
		}

		PlayFastForwardPhase(Index);
	}

	PlayFastForwardPhase(PhaseIndex, ActionIndex, State);
}

void UP3Quest::UpdateQuestData(const FP3QuestData& InQuestData)
{
	PhaseIndex = InQuestData.PhaseIndex;
	ActionIndex = InQuestData.ActionIndex;
	State = InQuestData.State;
	ElapsedTimeSeconds = InQuestData.ElapsedTimeSeconds;

	OnQuestUpdated.Broadcast(QuestKey);
}

void UP3Quest::GetQuestData(FP3QuestData& QuestData) const
{
	QuestData.PhaseIndex = PhaseIndex;
	QuestData.ActionIndex = ActionIndex;
	QuestData.State = State;
	QuestData.ElapsedTimeSeconds = ElapsedTimeSeconds;
}

void UP3Quest::OnActionFinishCallback()
{
	if (!ensure(IsWaitingActionFinished()))
	{
		return;
	}

	State = EP3QuestState::PrepareNextAction;

	OnQuestUpdated.Broadcast(QuestKey);
}

void UP3Quest::Tick(float DeltaTimeSeconds)
{
	if (!ensure(IsValid()))
	{
		return;
	}

	EP3QuestState PrevState = State;

	if (State >= EP3QuestState::PhaseStart && State < EP3QuestState::Done)
	{
		ElapsedTimeSeconds += DeltaTimeSeconds;
	}

	if (State == EP3QuestState::PrepareNextPhase)
	{
		if (CanNextPhase())
		{
			State = EP3QuestState::PhaseStart;
			PhaseIndex++;
		}
		else
		{
			State = EP3QuestState::Done;
		}
	}
	else if (State == EP3QuestState::PhaseStart)
	{
		State = EP3QuestState::CheckCondition;
		ElapsedTimeSeconds = 0.0f;
	}
	else if (State == EP3QuestState::CheckCondition)
	{
		if (CheckConditions())
		{
			State = EP3QuestState::PrepareNextAction;
			ActionIndex = -1;
		}
	}
	else if (State == EP3QuestState::PrepareNextAction)
	{
		if (CanNextAction())
		{
			State = EP3QuestState::DoAction;
			ActionIndex++;
		}
		else
		{
			State = EP3QuestState::PrepareNextPhase;
			ActionIndex = -1;
		}
	}
	else if (State == EP3QuestState::DoAction)
	{
		bool bWaiting = DoAction(GetNextAction());

		if (bWaiting)
		{
			State = EP3QuestState::WaitingAction; // todo : timeout?
		}
		else
		{
			State = EP3QuestState::PrepareNextAction;
		}
	}
	else if (State == EP3QuestState::WaitingAction)
	{
		// nothing
	}
	else if (State == EP3QuestState::Done)
	{
		// nothing
	}
	else
	{
		ensureMsgf(false, TEXT("Should not be reached here : CurrentState [%s]"), *EnumToStringShort(EP3QuestState, State));
	}

	if (PrevState != State)
	{
		OnQuestUpdated.Broadcast(QuestKey);
	}
}

bool UP3Quest::ManuallyProceed()
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	if (!IsManuallyProceedable())
	{
		return false;
	}

	ensure(State == EP3QuestState::CheckCondition);

	State = EP3QuestState::PrepareNextAction;
	ActionIndex = -1;

	OnQuestUpdated.Broadcast(QuestKey);

	return true;
}

const FText& UP3Quest::GetTitle() const
{
	if (!ensure(IsValid()))
	{
		return FText::GetEmpty();
	}

	return QuestDesc->QuestName;
}

const FText& UP3Quest::GetDescription() const
{
	if (!ensure(IsValid()))
	{
		return FText::GetEmpty();
	}

	return QuestDesc->QuestDescription;
}

const FText& UP3Quest::GetPhaseDescription() const
{
	if (!ensure(IsValid()))
	{
		return FText::GetEmpty();
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(PhaseIndex))
	{
		return FText::GetEmpty();
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[PhaseIndex];
	if (!ensure(PhaseDesc))
	{
		return FText::GetEmpty();
	}

	return PhaseDesc->PhaseDescription;
}

bool UP3Quest::IsValid() const
{
	// not initialized yet
	if (!QuestComponent)
	{
		return false;
	}

	if (!QuestDesc)
	{
		return false;
	}

	// invalid QuestDesc(DataAsset)
	if (QuestDesc->QuestPhases.Num() == 0)
	{
		return false;
	}

	for (const UP3QuestPhaseDesc* PhaseDesc : QuestDesc->QuestPhases)
	{
		if (PhaseDesc->QuestConditions.Num() == 0 && PhaseDesc->QuestActions.Num() == 0)
		{
			return false;
		}
	}

	// invalid quest data
	//if (State < EP3QuestState::PrepareNextPhase || State > EP3QuestState::Done)
	if (State > EP3QuestState::Done)
	{
		return false;
	}

	if (State == EP3QuestState::Done)
	{
		return true;
	}

	if (State == EP3QuestState::PrepareNextPhase)
	{
		return true;
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(PhaseIndex))
	{
		return false;
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[PhaseIndex];
	if (!PhaseDesc)
	{
		return false;
	}

	// invalid quest data - action
	if (State == EP3QuestState::DoAction || State == EP3QuestState::WaitingAction)
	{
		if (!PhaseDesc->QuestActions.IsValidIndex(ActionIndex))
		{
			return false;
		}

		const UP3QuestActionDesc* ActionDesc = PhaseDesc->QuestActions[ActionIndex];
		if (!ActionDesc)
		{
			return false;
		}
	}

	return true;
}

bool UP3Quest::IsActive() const
{
	return IsValid() && State != EP3QuestState::Done;
}

bool UP3Quest::IsWaitingActionFinished() const
{
	return State == EP3QuestState::WaitingAction;
}

bool UP3Quest::IsManuallyProceedable() const
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	if (State != EP3QuestState::CheckCondition)
	{
		return false;
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(PhaseIndex))
	{
		return false;
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[PhaseIndex];
	if (!ensure(PhaseDesc))
	{
		return false;
	}

	return PhaseDesc->bManuallyProceedable;
}

bool UP3Quest::IsWatchingCutscene() const
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(PhaseIndex))
	{
		return false;
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[PhaseIndex];
	if (!ensure(PhaseDesc))
	{
		return false;
	}

	if (!PhaseDesc->QuestActions.IsValidIndex(ActionIndex))
	{
		return false;
	}

	const UP3QuestActionDesc* ActionDesc = PhaseDesc->QuestActions[ActionIndex];
	if (!ensure(ActionDesc))
	{
		return false;
	}

	if (State < EP3QuestState::DoAction || State > EP3QuestState::WaitingAction)
	{
		return false;
	}

	return ActionDesc->ActionType == EP3QuestActionType::PlaySequence;
}

FString UP3Quest::GetDebugString(int32 DebugLevel) const
{
	FString OutString = FString::Printf(TEXT("[%d] %s - state %s"), QuestKey, *QuestDesc->GetName(), *EnumToStringShort(EP3QuestState, State));

	if (DebugLevel > 1)
	{
		OutString += FString::Printf(TEXT(", phase %d, action %d"), PhaseIndex, ActionIndex);
	}

	return OutString;
}

bool UP3Quest::CanNextPhase() const
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	return QuestDesc->QuestPhases.IsValidIndex(PhaseIndex + 1);
}

bool UP3Quest::CanNextAction() const
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(PhaseIndex))
	{
		return false;
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[PhaseIndex];
	if (!ensure(PhaseDesc))
	{
		return false;
	}

	return PhaseDesc->QuestActions.IsValidIndex(ActionIndex + 1);
}

const UP3QuestActionDesc* UP3Quest::GetNextAction() const
{
	if (!ensure(IsValid()))
	{
		return nullptr;
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(PhaseIndex))
	{
		return nullptr;
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[PhaseIndex];
	if (!ensure(PhaseDesc))
	{
		return nullptr;
	}

	if (!PhaseDesc->QuestActions.IsValidIndex(ActionIndex))
	{
		return nullptr;
	}

	const UP3QuestActionDesc* ActionDesc = PhaseDesc->QuestActions[ActionIndex];
	if (!ensure(ActionDesc))
	{
		return nullptr;
	}

	return ActionDesc;
}

bool UP3Quest::CheckConditions()
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(PhaseIndex))
	{
		return false;
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[PhaseIndex];
	if (!ensure(PhaseDesc))
	{
		return false;
	}

	for (const UP3QuestConditionDesc* ConditionDesc : PhaseDesc->QuestConditions)
	{
		if (!CheckCondition(ConditionDesc))
		{
			return false;
		}
	}

	return true;
}

bool UP3Quest::CheckCondition(const UP3QuestConditionDesc* ConditionDesc)
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	if (ConditionDesc->ConditionType == EP3QuestConditionType::NeverHappen)
	{
		return false;
	}
	else if (ConditionDesc->ConditionType == EP3QuestConditionType::TimeElapsed)
	{
		const UP3QuestConditionDesc_TimeElapsed* TimeCond = CastChecked<UP3QuestConditionDesc_TimeElapsed>(ConditionDesc);

		return ElapsedTimeSeconds > TimeCond->ElapseSeconds;
	}
	else if (ConditionDesc->ConditionType == EP3QuestConditionType::PlayerEnterVolume)
	{
		const UP3QuestConditionDesc_PlayerEnterVolume* EnterCond = CastChecked<UP3QuestConditionDesc_PlayerEnterVolume>(ConditionDesc);

		const AP3QuestVolume* QuestVolume = QuestComponent->FindQuestVolume(EnterCond->FindVolumeGameplayTagsAll);
		if (!QuestVolume)
		{
			return false;
		}

		return QuestVolume->EncompassesPoint(QuestComponent->GetOwner()->GetActorLocation());
	}
	else if (ConditionDesc->ConditionType == EP3QuestConditionType::SwitchState)
	{
		const UP3QuestConditionDesc_SwitchState* SwitchCond = CastChecked<UP3QuestConditionDesc_SwitchState>(ConditionDesc);

		const AP3SwitchActor* SwitchActor = QuestComponent->FindSwitchActor(SwitchCond->FindSwitchGameplayTagsAll);
		if (!SwitchActor)
		{
			return false;
		}

		return SwitchActor->IsSwitchOn() == SwitchCond->bCurrentSwitchState;
	}
	else if (ConditionDesc->ConditionType == EP3QuestConditionType::CharacterCount)
	{
		const UP3QuestConditionDesc_CharacterCount* CountCond = CastChecked<UP3QuestConditionDesc_CharacterCount>(ConditionDesc);

		const AP3QuestBoxTriggeredSwitchActor* SwitchActor = QuestComponent->FindQuestBoxTriggeredSwitchActor(CountCond->FindSwitchGameplayTagsAll);
		if (!SwitchActor)
		{
			return false;
		}

		int32 Count = SwitchActor->GetFilteredActorCount(CountCond->TargetActorClass);

		if (CountCond->Operator == EP3ComparisonOperator::Equal)
		{
			return Count == CountCond->Operand;
		}
		else if (CountCond->Operator == EP3ComparisonOperator::NotEqual)
		{
			return Count != CountCond->Operand;
		}
		else if (CountCond->Operator == EP3ComparisonOperator::GreatherThan)
		{
			return Count > CountCond->Operand;
		}
		else if (CountCond->Operator == EP3ComparisonOperator::GreatherThanOrEqual)
		{
			return Count >= CountCond->Operand;
		}
		else if (CountCond->Operator == EP3ComparisonOperator::LessThan)
		{
			return Count < CountCond->Operand;
		}
		else if (CountCond->Operator == EP3ComparisonOperator::LessThanOrEqual)
		{
			return Count <= CountCond->Operand;
		}
		else
		{
			ensureMsgf(false, TEXT("Should not be reached here : Comparison Operator [%s]"), *EnumToStringShort(EP3ComparisonOperator, CountCond->Operator));
		}

		return false;
	}
	else if (ConditionDesc->ConditionType == EP3QuestConditionType::Logic)
	{
		const UP3QuestConditionDesc_Logic* LogicCond = CastChecked<UP3QuestConditionDesc_Logic>(ConditionDesc);

		if (LogicCond->Operator == EP3QuestConditionLogicOperator::And)
		{
			for (UP3QuestConditionDesc* Operand : LogicCond->Operands)
			{
				if (!CheckCondition(Operand))
				{
					return false;
				}
			}

			return true;
		}
		else if (LogicCond->Operator == EP3QuestConditionLogicOperator::Or)
		{
			for (UP3QuestConditionDesc* Operand : LogicCond->Operands)
			{
				if (CheckCondition(Operand))
				{
					return true;
				}
			}

			return false;
		}
		else if (LogicCond->Operator == EP3QuestConditionLogicOperator::Not)
		{
			for (UP3QuestConditionDesc* Operand : LogicCond->Operands)
			{
				if (CheckCondition(Operand))
				{
					return false;
				}
			}

			return true;
		}
		else
		{
			ensureMsgf(false, TEXT("Should not be reached here : Logic Operator [%s]"), *EnumToStringShort(EP3QuestConditionLogicOperator, LogicCond->Operator));
		}
	}
	else
	{
		ensureMsgf(false, TEXT("Should not be reached here : ConditionType [%s]"), *EnumToStringShort(EP3QuestConditionType, ConditionDesc->ConditionType));
	}

	return false;
}

bool UP3Quest::DoAction(const UP3QuestActionDesc* ActionDesc)
{
	if (!ensure(IsValid()))
	{
		return false;
	}

	if (!ensure(ActionDesc))
	{
		return false;
	}

	P3JsonLog(Display, "DoAction", TEXT("ActionType"), *EnumToStringShort(EP3QuestActionType, ActionDesc->ActionType));

	bool bWaitingActionFinished = false;

	if (ActionDesc->ActionType == EP3QuestActionType::PlaySequence)
	{
		const UP3QuestActionDesc_PlaySequence* PlaySequenceAction = CastChecked<UP3QuestActionDesc_PlaySequence>(ActionDesc);
		bWaitingActionFinished = QuestComponent->Server_PlaySequence(PlaySequenceAction->LevelSequence, PlaySequenceAction->bDisableMovementInput, PlaySequenceAction->bDisableLookAtInput, PlaySequenceAction->bHidePlayer, PlaySequenceAction->bHideHud, PlaySequenceAction->bDisableCameraCuts, PlaySequenceAction->bWaitingFinished);
	}
	else if (ActionDesc->ActionType == EP3QuestActionType::ToggleSwitchState)
	{
		const UP3QuestActionDesc_ToggleSwitch* ToggleSwitchAction = CastChecked<UP3QuestActionDesc_ToggleSwitch>(ActionDesc);
		bWaitingActionFinished = QuestComponent->Server_ToggleSwitch(ToggleSwitchAction->FindSwitchGameplayTagsAll, ToggleSwitchAction->bNewSwitchState);
	}
	else if (ActionDesc->ActionType == EP3QuestActionType::DeriveQuest)
	{
		const UP3QuestActionDesc_DeriveQuest* DeriveQuestAction = CastChecked<UP3QuestActionDesc_DeriveQuest>(ActionDesc);
		bWaitingActionFinished = QuestComponent->Server_DeriveQuest(DeriveQuestAction->NextQuest);
	}
	else if (ActionDesc->ActionType == EP3QuestActionType::SpawnCharacter)
	{
		const UP3QuestActionDesc_SpawnCharacter* SpawnCharacterQuestAction = CastChecked<UP3QuestActionDesc_SpawnCharacter>(ActionDesc);
		bWaitingActionFinished = QuestComponent->Server_SpawnCharacter(SpawnCharacterQuestAction->SpawnCharacterClass, SpawnCharacterQuestAction->FindSpotGameplayTagsAll);
	}
	else if (ActionDesc->ActionType == EP3QuestActionType::SendWalkieTalkieMessage)
	{
		const UP3QuestActionDesc_SendWalkieTalkieMessage* WalkieTalkieQuestAction = CastChecked<UP3QuestActionDesc_SendWalkieTalkieMessage>(ActionDesc);
		bWaitingActionFinished = QuestComponent->Server_SendWalkieTalkieMessage(WalkieTalkieQuestAction->Message);
	}
	else if (ActionDesc->ActionType == EP3QuestActionType::LookAt)
	{
		const UP3QuestActionDesc_LookAt* LookAtQuestAction = CastChecked<UP3QuestActionDesc_LookAt>(ActionDesc);
		bWaitingActionFinished = QuestComponent->Server_LookAt(LookAtQuestAction->FindSpotGameplayTagsAll);
	}
	else
	{
		ensureMsgf(false, TEXT("Should not be reached here : ActionType [%s]"), *EnumToStringShort(EP3QuestActionType, ActionDesc->ActionType));
	}

	return bWaitingActionFinished;
}

void UP3Quest::PlayFastForwardPhase(int32 InPhaseIndex, int32 ToActionIndex, EP3QuestState InState)
{
	if (!ensure(QuestDesc))
	{
		return;
	}

	if (InState <= EP3QuestState::CheckCondition)
	{
		return;
	}

	if (!QuestDesc->QuestPhases.IsValidIndex(InPhaseIndex))
	{
		return;
	}

	const UP3QuestPhaseDesc* PhaseDesc = QuestDesc->QuestPhases[InPhaseIndex];

	if (!ensure(PhaseDesc))
	{
		return;
	}

	if (ToActionIndex == -1)
	{
		ToActionIndex = PhaseDesc->QuestActions.Num();
	}

	for (int32 Index = 0; Index <= ToActionIndex; ++Index)
	{
		if (!PhaseDesc->QuestActions.IsValidIndex(Index))
		{
			continue;
		}

		if (Index == ToActionIndex)
		{
			if (InState < EP3QuestState::WaitingAction)
			{
				continue;
			}
		}

		const UP3QuestActionDesc* ActionDesc = PhaseDesc->QuestActions[Index];

		if (!ensure(ActionDesc))
		{
			continue;
		}

		if (ActionDesc->bPermanentlyDone)
		{
			P3JsonLog(Display, "DoAction while initializing", TEXT("QuestName"), QuestDesc->GetName(), TEXT("PhaseIndex"), InPhaseIndex, TEXT("ActionIndex"), Index);

			DoAction(ActionDesc);
		}
	}
}

void FP3QuestUtil::Server_CreateQuest(UP3WorldNetBase& WorldNet, UP3QuestComponent& QuestComp, charid CharacterId, questkey QuestKey)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(QuestComp)))
	{
		return;
	}

	const UP3QuestDesc* QuestDesc = P3Cms::GetQuestDescFromQuestKey(QuestKey);

	if (!ensure(QuestDesc))
	{
		return;
	}

	WorldNet.SendCreateQuest(CharacterId, QuestKey);
}

void FP3QuestUtil::Server_UpdateQuest(UP3WorldNetBase& WorldNet, UP3QuestComponent& QuestComp, charid CharacterId, questkey QuestKey, EP3QuestState State, int32 PhaseIndex, int32 ActionIndex)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(QuestComp)))
	{
		return;
	}

	WorldNet.SendUpdateQuest(CharacterId, QuestKey, State, PhaseIndex, ActionIndex);
}
