// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3QuestSwitchActor.h"
#include "Components/ShapeComponent.h"
#include "P3Character.h"
#include "P3World.h"


void AP3QuestSwitchActor::BeginPlay()
{
	Super::BeginPlay();

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->RegisterQuestActor(this);
	}
}

void AP3QuestSwitchActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->UnregisterQuestActor(this);
	}

	Super::EndPlay(EndPlayReason);
}

int32 AP3QuestBoxTriggeredSwitchActor::GetFilteredActorCount(TSubclassOf<class AP3Character> TargetActorClass) const
{
	int32 Count = 0;

	for (const AActor* TriggeredActor : GetTriggeredActors())
	{
		if (!TriggeredActor || TriggeredActor->IsActorBeingDestroyed())
		{
			continue;
		}

		if (TriggeredActor->GetClass()->IsChildOf(TargetActorClass))
		{
			Count++;
		}
	}

	return Count;
}

void AP3QuestBoxTriggeredSwitchActor::BeginPlay()
{
	Super::BeginPlay();

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	UShapeComponent* CollisionComp = GetCollisionComponent();
	if (!ensure(CollisionComp))
	{
		return;
	}

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->RegisterQuestActor(this);
	}

	TArray<AActor*> OverlappingActors;
	CollisionComp->GetOverlappingActors(OverlappingActors, TSubclassOf<AActor>());
	for (AActor* OverlappingActor : OverlappingActors)
	{
		TArray<FOverlapInfo> OverlapInfos;
		CollisionComp->GetOverlapsWithActor(OverlappingActor, OverlapInfos);

		for (FOverlapInfo& OverlapInfo : OverlapInfos)
		{
			UPrimitiveComponent* OverlappingComponent = OverlapInfo.OverlapInfo.Component.Get();
			if (OverlappingComponent)
			{
				OnBeginOverlap(CollisionComp, OverlappingComponent->GetOwner(), OverlappingComponent, OverlapInfo.GetBodyIndex(), OverlapInfo.bFromSweep, OverlapInfo.OverlapInfo);
			}
		}
	}
}

void AP3QuestBoxTriggeredSwitchActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->UnregisterQuestActor(this);
	}

	Super::EndPlay(EndPlayReason);
}
