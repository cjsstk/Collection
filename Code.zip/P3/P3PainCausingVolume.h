// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PhysicsVolume.h"
#include "P3PainCausingVolume.generated.h"

/**
 * Pain causing volume
 */
UCLASS(Blueprintable)
class P3_API AP3PainCausingVolume : public APhysicsVolume
{
	GENERATED_BODY()
	
	virtual void ActorEnteredVolume(class AActor* Other) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	/** Damage overlapping actors if pain-causing. */
	void Server_PainTimer();

	/** damage overlapping actors if pain causing. */
	void Server_CausePainTo(class AActor* Other);

	/** If pain causing, time between damage applications. */
	UPROPERTY(EditAnywhere, Category=P3)
	float PainInterval = 1.0f;

	/** Damage per each pain */
	UPROPERTY(EditAnywhere, Category=P3)
	int32 PainAmount = 10;

	/** Cause pain when something enters the volume in addition to damage each second */
	UPROPERTY(EditAnywhere, Category=P3)
	bool bEntryPain = true;

	/** Handle for efficient management of OnTimerTick timer */
	FTimerHandle Server_PainTimerHandle;
};
