// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3HolderComponent.h"

#include "Engine/World.h"
#include "Components/PrimitiveComponent.h"

#include "Chemical/P3FlammableComponent.h"
#include "P3HoldableComponent.h"


UP3HolderComponent::UP3HolderComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}


void UP3HolderComponent::DestroyComponent(bool bPromoteChildren /*= false*/)
{
	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		if (HoldingActor)
		{
			HoldingActor->Destroy();
		}
	}

	Super::DestroyComponent(bPromoteChildren);
}

void UP3HolderComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3HolderComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UP3HolderComponent::SetHoldingActor(AActor* NewHoldingActor, bool bInHold)
{
	if (HoldingActor && !HoldingActor->IsActorBeingDestroyed() && HoldingActor != NewHoldingActor)
	{
		ensure(0);
		return;
	}

	if (!ensure(NewHoldingActor))
	{
		return;
	}

	UP3HoldableComponent* HoldableComp = NewHoldingActor->FindComponentByClass<UP3HoldableComponent>();
	if (!ensure(HoldableComp))
	{
		return;
	}

	HoldableComp->SetHolderComponent(this);

	HoldingActor = NewHoldingActor;
	HoldingActor->DisableComponentsSimulatePhysics();

	TInlineComponentArray<UPrimitiveComponent*> Components;
	HoldingActor->GetComponents(Components);

	PhysicsOnlyComponents.Empty();
	QueryAndPhysicsComponents.Empty();

	for (UPrimitiveComponent* Component : Components)
	{
		ECollisionEnabled::Type CollisionEnabled = Component->GetCollisionEnabled();

		if (CollisionEnabled == ECollisionEnabled::PhysicsOnly)
		{
			Component->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			PhysicsOnlyComponents.Add(Component);
		}
		else if (CollisionEnabled == ECollisionEnabled::QueryAndPhysics)
		{
			Component->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
			QueryAndPhysicsComponents.Add(Component);
		}
	}

	// Loot item has life span set from loot drop component, lets clear it
	HoldingActor->SetLifeSpan(0.0f);
	
	if (bInHold)
	{
		Hold();
	}
	else
	{
		Stash();
	}
}

AActor* UP3HolderComponent::RemoveHoldingActor()
{
	if (!HoldingActor)
	{
		return nullptr;
	}

	UP3HoldableComponent* HoldableComp = HoldingActor->FindComponentByClass<UP3HoldableComponent>();
	if (ensure(HoldableComp))
	{
		ensure(HoldableComp->GetHolderComponent() == this);

		HoldableComp->SetHolderComponent(nullptr);
	}

	HoldingActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	HoldingActor->SetActorEnableCollision(true);

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(HoldingActor->GetRootComponent());
	if (PrimComp)
	{
		PrimComp->SetSimulatePhysics(true);
	}

	if (bHiddenInStash)
	{
		HoldingActor->SetActorHiddenInGame(false);
	}

	// Restore collision enabled
	for (UPrimitiveComponent* Component : PhysicsOnlyComponents)
	{
		Component->SetCollisionEnabled(ECollisionEnabled::PhysicsOnly);
	}
	PhysicsOnlyComponents.Empty();

	for (UPrimitiveComponent* Component : QueryAndPhysicsComponents)
	{
		Component->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	}
	QueryAndPhysicsComponents.Empty();

	AActor* OutActor = HoldingActor;

	HoldingActor = nullptr;
	bHold = false;

	OnActorRemoved.Broadcast(this, OutActor);

	return OutActor;
}

void UP3HolderComponent::Hold()
{
	if (HoldingActor && ensure(GetAttachParent()))
	{
		const FP3HoldableAttachParams& HoldParams = FindHoldParams();

		HoldingActor->AttachToComponent(GetAttachParent(), FAttachmentTransformRules::KeepWorldTransform, HoldParams.SocketName);
		HoldingActor->SetActorRelativeLocation(HoldParams.Location);
		HoldingActor->SetActorRelativeRotation(HoldParams.Rotation);
		HoldingActor->SetActorRelativeScale3D(FVector(1, 1, 1));

		if (bHiddenInStash)
		{
			HoldingActor->SetActorHiddenInGame(false);
		}

		bHold = true;

		OnHold.Broadcast(this, HoldingActor);
	}
}

const FP3HoldableAttachParams& UP3HolderComponent::FindHoldParams() const
{
	const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(HoldingActor->GetClass()));
	if (!CmsHoldable)
	{
		return DefaultHoldParams;
	}

	for (const auto& It : WeaponHoldParams)
	{
		if (It.Key == CmsHoldable->WeaponType)
		{
			return It.Value;
		}
	}

	return DefaultHoldParams;
}

const FP3HoldableAttachParams& UP3HolderComponent::FindStashParams() const
{
	const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(HoldingActor->GetClass()));
	if (!CmsHoldable)
	{
		return DefaultStashParams;
	}

	for (const auto& It : WeaponStashParams)
	{
		if (It.Key == CmsHoldable->WeaponType)
		{
			return It.Value;
		}
	}

	return DefaultStashParams;
}

void UP3HolderComponent::Stash()
{
	if (HoldingActor && ensure(GetAttachParent()))
	{
		const FP3HoldableAttachParams& StashParams = FindStashParams();

		HoldingActor->AttachToComponent(GetAttachParent(), FAttachmentTransformRules::KeepWorldTransform, StashParams.SocketName);
		HoldingActor->SetActorRelativeLocation(StashParams.Location);
		HoldingActor->SetActorRelativeRotation(StashParams.Rotation);
		HoldingActor->SetActorRelativeScale3D(FVector(1, 1, 1));

		if (bHiddenInStash)
		{
			HoldingActor->SetActorHiddenInGame(true);
		}

		if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
		{
			UP3FlammableComponent* FlammableComp = HoldingActor->FindComponentByClass<UP3FlammableComponent>();
			if (FlammableComp)
			{
				FlammableComp->Server_StopFire();
			}
		}

		bHold = false;

		OnStash.Broadcast(this, HoldingActor);
	}
}

TSubclassOf<AActor> UP3HolderComponent::GetDefaultHoldingActorClass(EP3CharClass CharClass) const
{
	const TSubclassOf<AActor>* ActorClass = DefaultHoldingActorClass.Find(CharClass);
	return ActorClass ? *ActorClass : TSubclassOf<AActor>();
}

FTransform UP3HolderComponent::GetHoldSocketTransform() const
{
	if (!GetAttachParent())
	{
		return FTransform::Identity;
	}
	
	const FP3HoldableAttachParams& HoldParams = FindHoldParams();

	const FTransform OutTransform = GetAttachParent()->GetSocketTransform(HoldParams.SocketName, RTS_World);

	return OutTransform;
}

void UP3HolderComponent::OnCharacterHiddenChanged(bool bNewHidden)
{
	if (!HoldingActor)
	{
		return;
	}

	if (bNewHidden)
	{
		HoldingActor->SetActorHiddenInGame(true);
	}
	else
	{
		if (bHold || !bHiddenInStash)
		{
			HoldingActor->SetActorHiddenInGame(false);
		}
	}
}

void UP3HolderComponent::NetSerialize(FArchive& Archive)
{
	if (!Archive.IsLoading())
	{
		Archive << HoldingActor;
		Archive << bHold;
	}
	else
	{
		AActor* NewHoldingActor(nullptr);
		bool bNewHold(false);

		Archive << NewHoldingActor;
		Archive << bHold;

		if (NewHoldingActor)
		{
			SetHoldingActor(NewHoldingActor, bHold);
		}
		else
		{
			RemoveHoldingActor();
		}
	}
}
