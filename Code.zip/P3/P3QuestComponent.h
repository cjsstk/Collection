// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Network/Lib/P3NetCore.h"
#include "P3Core.h"
#include "P3Cms.h"
#include "P3StoreInterface.h"
#include "P3QuestDesc.h"
#include "P3Quest.h"
#include "P3QuestComponent.generated.h"


USTRUCT()
struct FP3NetQuestActionParams
{
	GENERATED_BODY()

	UPROPERTY()
	int32 RequestId = -1;

	UPROPERTY()
	EP3QuestActionType ActionType = EP3QuestActionType::None;

	UPROPERTY()
	FText Message = FText::GetEmpty();

	UPROPERTY()
	class ULevelSequence* LevelSequence = nullptr;

	UPROPERTY()
	bool bDisableMovementInput = true;

	UPROPERTY()
	bool bDisableLookAtInput = true;

	UPROPERTY()
	bool bHidePlayer = false;

	UPROPERTY()
	bool bHideHud = true;

	UPROPERTY()
	bool bDisableCameraCuts = false;

	UPROPERTY()
	bool bNeedFinishCallback = false;
};

int32 GenerateRequestId();

struct FGameplayTagContainer;

UCLASS()
class P3_API UP3QuestComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:
	UP3QuestComponent();

	/** ActorComponent */
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

public:
	void Server_InitQuests(const TMap<questkey, FP3QuestData>& QuestDatas);

	/** Process quest */
	void Server_Tick(float DeltaTimeSeconds);

	void Client_Tick(float DeltaTimeSeconds);

	/**
	 * Start Quest
	 * This only works when quests is empty
	 * (at this time no way to figure out demo quest is going on)
	 */
	bool Server_StartQuest(questkey QuestKey);

	// todo : have to specify target quest
	UFUNCTION(BlueprintCallable)
	bool Server_ManuallyProceed();

	bool IsManuallyProceedable() const;

	/**
	 * Condition
	 * @return whether condition check succeed
	 */
	const class AP3QuestVolume* FindQuestVolume(const FGameplayTagContainer& GameplayTag) const;
	class AP3SwitchActor* FindSwitchActor(const FGameplayTagContainer& GameplayTag) const;
	class AP3QuestSpot* FindQuestSpot(const FGameplayTagContainer& GameplayTag) const;
	class AP3QuestBoxTriggeredSwitchActor* FindQuestBoxTriggeredSwitchActor(const FGameplayTagContainer& GameplayTag) const;

	/**
	 * Action
	 * @return whether we should wait something finished
	 */
	bool Server_ToggleSwitch(const FGameplayTagContainer& SwitchGameplayTagAll, bool bNewSwitchState);
	bool Server_PlaySequence(ULevelSequence* LevelSequence, bool bDisableMovementInput, bool bDisableLookAtInput, bool bHidePlayer, bool bHideHud, bool bDisableCameraCuts, bool bNeedFinishCallback);
	void Client_PlaySequence(ULevelSequence* LevelSequence, bool bDisableMovementInput, bool bDisableLookAtInput, bool bHidePlayer, bool bHideHud, bool bDisableCameraCuts, bool bNeedFinishCallback, int32 RequestId);
	bool Server_DeriveQuest(const UP3QuestDesc* QuestDesc);
	void Server_AddQuest(questkey QuestKey);
	bool Server_SpawnCharacter(UClass* Class, const FGameplayTagContainer& SpawnSpotGameplayTagAll);
	bool Server_SendWalkieTalkieMessage(const FText& Message);
	void Client_SendWalkieTalkieMessage(const FText& Message);
	bool Server_LookAt(const FGameplayTagContainer& LookAtTargetSpotGameplayTagAll);

private:
	void Server_InitQuest(questkey QuestKey, const FP3QuestData& QuestData);

	UP3Quest* AddQuestInternal(questkey QuestKey);

	/** Request action to client */
	void Server_RequestAction(const FP3NetQuestActionParams& ActionParams);

	/** Do action in client */
	UFUNCTION()
	void Client_HandleRequest(const FP3DediToClientHandlerParams& Params);

	/** Reply action result to server */
	void Client_ReplyActionFinished(const FP3NetQuestActionParams& ActionParams);

	/** Receive action result from client */
	UFUNCTION()
	void Server_HandleReply(const FP3ClientToDediHandlerParams& Params);

	/** Sync UI from server */
	void Client_AddQuest(questkey QuestKey);
	void Client_RemoveQuest(questkey QuestKey);

	/** Set dirty flag to sync quest data to clieint when something changed */
	void Server_OnQuestUpdated(questkey QuestKey);

	/** LevelSequence callbacks */
	UFUNCTION()
	void Client_OnSequenceStop();

	UFUNCTION()
	void Client_OnSequenceFinished();

	UPROPERTY(Transient)
	TMap<int32, UP3Quest*> Quests;

	UPROPERTY(Transient)
	class ALevelSequenceActor* LevelSequenceActor;

	/**
	 * These variables are used to help sync action
	 */
	UPROPERTY(Transient)
	int32 ProcessingQuestKey = INVALID_QUESTKEY;

	UPROPERTY(Transient)
	TMap<int32, int32> Server_WatchingRequestIds;

	UPROPERTY(Transient)
	int32 Client_WatchingRequestId = -1;
};