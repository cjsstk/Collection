// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

void P3DrawDebugArc(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 NumSides,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority, float Thickness);
void P3DrawDebugCircularSector(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 NumSides,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority, float Thickness);
void P3DrawDebugSolidCircularSector(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 NumSides,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority);
void P3DrawDebugSolidCylinder(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Height, int32 NumSides,
	const FColor& Color, bool bDrawLine, const FColor& LineColor, float LineThickness, bool bPersistent, float LifeTime, uint8 DepthPriority);
void P3DrawDebugSolidCylindricalSector(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, float Height, int32 NumSides,
	const FColor& Color, bool bDrawLine, const FColor& LineColor, float LineThickness, bool bPersistent, float LifeTime, uint8 DepthPriority);
void P3DrawDebugSolidSphere(const UWorld& World, const FVector& Center, float Radius, int32 Segments,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority);
void P3DrawDebugSolidSphericalWedge(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 Segments,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority, float Thickness);
