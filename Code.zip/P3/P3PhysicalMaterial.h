// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "P3PhysicalMaterial.generated.h"

/**
 * This is copy of WalkableSlope
 *
 * @See EWalkableSlopeBehavior
 * @See FWalkableSlopeOverride
 */
UENUM(BlueprintType)
enum ESlidableSlopeBehavior
{
	SlidableSlope_Default		UMETA(DisplayName = "Unchanged"),
	SlidableSlope_Increase		UMETA(DisplayName = "Increase Slidable Slope"),
	SlidableSlope_Decrease		UMETA(DisplayName = "Decrease Slidable Slope"),
	SlidableSlope_Unslidable	UMETA(DisplayName = "Unslidable"),
	SlidableSlope_Max			UMETA(Hidden),
};

USTRUCT(BlueprintType)
struct FSlidableSlopeOverride
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SlidableSlopeOverride)
	TEnumAsByte<ESlidableSlopeBehavior> SlidableSlopeBehavior;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = SlidableSlopeOverride, meta = (ClampMin = "0", ClampMax = "90", UIMin = "0", UIMax = "90"))
	float SlidableSlopeAngle;

private:

	// Cached angle for which we computed a cosine.
	mutable float CachedSlopeAngle;
	// Cached cosine of angle.
	mutable float CachedSlopeCos;

public:

	FSlidableSlopeOverride()
		: SlidableSlopeBehavior(SlidableSlope_Default)
		, SlidableSlopeAngle(0.f)
		, CachedSlopeAngle(0.f)
		, CachedSlopeCos(1.f)
	{ }

	FSlidableSlopeOverride(ESlidableSlopeBehavior NewSlopeBehavior, float NewSlopeAngle)
		: SlidableSlopeBehavior(NewSlopeBehavior)
		, SlidableSlopeAngle(NewSlopeAngle)
		, CachedSlopeAngle(0.f)
		, CachedSlopeCos(1.f)
	{
	}

	/** Gets the slope override behavior. */
	FORCEINLINE ESlidableSlopeBehavior GetSlidableSlopeBehavior() const
	{
		return SlidableSlopeBehavior;
	}

	/** Gets the slope angle used for the override behavior. */
	FORCEINLINE float GetSlidableSlopeAngle() const
	{
		return SlidableSlopeAngle;
	}

	/** Set the slope override behavior. */
	FORCEINLINE void SetSlidableSlopeBehavior(ESlidableSlopeBehavior NewSlopeBehavior)
	{
		SlidableSlopeBehavior = NewSlopeBehavior;
	}

	/** Set the slope angle used for the override behavior. */
	FORCEINLINE void SetSlidableSlopeAngle(float NewSlopeAngle)
	{
		SlidableSlopeAngle = FMath::Clamp(NewSlopeAngle, 0.f, 90.f);
	}

	/** Given a slidable floor normal Z value, either relax or restrict the value if we override such behavior. */
	float ModifySlidableFloorZ(float InSlidableFloorZ) const
	{
		switch (SlidableSlopeBehavior)
		{
			case SlidableSlope_Default:
			{
				return InSlidableFloorZ;
			}

			case SlidableSlope_Increase:
			{
				CheckCachedData();
				return FMath::Min(InSlidableFloorZ, CachedSlopeCos);
			}

			case SlidableSlope_Decrease:
			{
				CheckCachedData();
				return FMath::Max(InSlidableFloorZ, CachedSlopeCos);
			}

			case SlidableSlope_Unslidable:
			{
				// Z component of a normal will always be less than this, so this will be unslidable.
				return 2.0f;
			}

			default:
			{
				return InSlidableFloorZ;
			}
		}
	}

private:
	void CheckCachedData() const
	{
		if (CachedSlopeAngle != SlidableSlopeAngle)
		{
			const float AngleRads = FMath::DegreesToRadians(SlidableSlopeAngle);
			CachedSlopeCos = FMath::Clamp(FMath::Cos(AngleRads), 0.f, 1.f);
			CachedSlopeAngle = SlidableSlopeAngle;
		}
	}
};

template<> struct TIsPODType<FSlidableSlopeOverride> { enum { Value = true }; };

/**
 *
 */
UCLASS()
class P3_API UP3PhysicalMaterial : public UPhysicalMaterial
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = P3Movement_Sliding)
	const struct FSlidableSlopeOverride& GetSlidableSlopeOverride() const { return SlidableSlopeOverride; }

protected:

	UPROPERTY(EditAnywhere, AdvancedDisplay, BlueprintReadOnly, Category = P3Movement_Sliding, meta = (editcondition = "bOverrideSlidableSlopeOnInstance"))
	struct FSlidableSlopeOverride SlidableSlopeOverride;
};
