// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Engine/EngineTypes.h"
#include "P3PickupableType.h"
#include "P3PickupableComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3PickupStarted, class UP3PickupableComponent*, PickupableComponent, class AActor*, PickupperActor);

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3PickupableComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3PickupableComponent();

	void DisablePhysicsForPickup();
	void RestorePhysicsForPutdown(class AP3Character* Character);
	void RestorePhysicsAfterPutdown();
	
	bool IsTripOverLargeCharacter() const { return bTripOverLargeCharacter; }

	void SetPickupableType(EP3PickupableType InPickupableType) { PickupableType = InPickupableType; }
	EP3PickupableType GetPickupableType() const { return PickupableType; }

	void SetPickupableDisplayName(const FText& InPickupableDisplayName) { PickupableDisplayName = InPickupableDisplayName; }
	const FText& GetPickupableDisplayName() const { return PickupableDisplayName; }

	void SetPickupToInventory(bool bInPickupToInventory) { bPickupToInventory = bInPickupToInventory; }
	bool IsPickupToInventory() const { return bPickupToInventory; }

	void SetDoNotRotateDuringPickup(bool bInDoNotRotateDuringPickup) { bDoNotRotateDuringPickup = bInDoNotRotateDuringPickup; }
	bool IsDoNotRotateDuringPickup() const { return bDoNotRotateDuringPickup; }

	/** 
	 * Interact Lock
	 */
	bool Server_IsInteractionLocked() const { return Server_bIsInteractionLocked; }
	void Server_SetInteractionLock(class UP3PickupPawnAction* InLockerAction, bool bInInteractionLocked);

	FP3PickupStarted Server_PickupStarted;

protected:
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	void TickPickupableEffect();

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FText PickupableDisplayName;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	EP3PickupableType PickupableType = EP3PickupableType::OverHeadRock;

	/** If true, any large character hit this object will trip over */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bTripOverLargeCharacter = false;

	/** If true, this actor go into Inventory when pickup */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bPickupToInventory = false;

	/** If true, this object will not rotate with hand during pickup */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bDoNotRotateDuringPickup = true;

	/** Temporal 'pickupable' sign effect to help player locate pickupable items on ground */
	UPROPERTY(Transient)
	class UParticleSystemComponent* PickupableEffectParticleComponent = nullptr;

	TMap<UPrimitiveComponent*, ECollisionEnabled::Type> SavedCollisionEnabled;
	TMap<UPrimitiveComponent*, FCollisionResponseContainer> SavedCollisionResponse;

	/** If this is true, Can't interact  */
	bool Server_bIsInteractionLocked = false;

	/** This component locked by this action */
	UP3PickupPawnAction* LockerAction = nullptr;
};
