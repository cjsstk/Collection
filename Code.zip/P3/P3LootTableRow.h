#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/DataTable.h"
#include "EngineMinimal.h"
#include "P3LootTableRow.generated.h"

USTRUCT(BlueprintType)
struct FP3LootTableRow: public FTableRowBase
{
    GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	int32 ChancePer10000 = 10000;

    UPROPERTY(BlueprintReadWrite, EditAnywhere)
    TSoftClassPtr<AActor> SpawnActorClass;

	/** Optional socket name that actor should spawn from */
	UPROPERTY(BlueprintReadWrite, EditAnywhere)
	FName SpawnSocketName;
};
