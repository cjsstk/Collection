// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "Action/P3PawnActionAnimNotifyTypes.h"
#include "P3Cms.h"
#include "P3AnimNotify.generated.h"

/**
 * Using Aim Rotation Type
 */
UENUM()
enum class EP3UsingAimRotationType
{
	NoAim,
	UntilNotify,
	FixingAtStartingMontage
};

/**
 * Attack Notify (Deprecated. Use Hit Notify)
 */
UCLASS(const, hidecategories=Object, collapsecategories, meta=(DisplayName="Attack"))
class P3_API UAnimNotify_Attack : public UAnimNotify
{
	GENERATED_BODY()

public:
	UAnimNotify_Attack()
		: AttackDirection(EAnimNotifyAttackDirectionFlags::Left)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	EAnimNotifyAttackDirectionFlags AttackDirection;
};


/**
 * Hit Notify (Working with FP3AnimNotifyGenerator. No Notify function here)
 */
UCLASS(const, hidecategories=Object, collapsecategories, meta=(DisplayName="Hit"))
class P3_API UAnimNotify_Hit : public UAnimNotify
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category="CMS")
	FName CmsCombatHitKey;

	/** Optional socket name to transform hit-area(pie) */
	UPROPERTY(EditAnywhere, Category = "Socket")
	FName SocketName;

	/**
	 * true 로 할 경우, Adapted Attack 의 타격 지점으로 사용됨
	 * Adapted Attack Hit Notify 가 없어야 함
	 * Adapted Attack Hit Notify 가 없으면서 모든 Hit Notify 가 false 일 경우, 첫 Hit Notify 가 사용됨
	 */
	UPROPERTY(EditAnywhere, Category = "Adapted Attack")
	bool bUseAsAdaptedAttackHit = false;
};


/**
* AttackStoppable Notify (Working with FP3AnimNotifyGenerator. No Notify function here)
*/
UCLASS(const, hidecategories = Object, collapsecategories, meta = (DisplayName = "AttackStoppable"))
class P3_API UAnimNotify_AttackStoppable : public UAnimNotify
{
	GENERATED_BODY()
};


/**
* AttackMove NotifyState
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "AttackMove"))
class UAnimNotifyState_AttackMove : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};


/**
 * Action
 */
UCLASS(const, hidecategories=Object, collapsecategories, meta=(DisplayName="Action"))
class P3_API UAnimNotify_Action : public UAnimNotify
{
	GENERATED_BODY()
	
public:
	// Begin UAnimNotify interface
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
	virtual FString GetNotifyName_Implementation() const override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AnimNotify")
	EActionAnimNotifyType ActionNotifyType;
};


/**
 * Pickup
 */
UCLASS(const, hidecategories=Object, collapsecategories, meta=(DisplayName="Pickup"))
class P3_API UAnimNotify_Pickup : public UAnimNotify
{
	GENERATED_BODY()
	
public:
	// Begin UAnimNotify interface
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};


/**
 * Throw
 */
UCLASS(const, hidecategories=Object, collapsecategories, meta=(DisplayName="Throw"))
class P3_API UAnimNotify_Throw : public UAnimNotify
{
	GENERATED_BODY()
	
public:
	// Begin UAnimNotify interface
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};

/**
 * Buff
 */
UCLASS(const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "Add Buff"))
class UAnimNotify_AddBuff : public UAnimNotify
{
	GENERATED_BODY()

public:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	int32 CmsBuffKey = INVALID_BUFFKEY;
};

/**
* Reaction Block
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "ReactionBlock"))
class UAnimNotifyState_ReactionBlock : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;	

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	bool bIsPlayHitAnimationBlock = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	bool bIsPlayHitRotatorBlock = false;

private:
	const FName NAME_ParameterHitAnimationBlock = FName(TEXT("HitAnimationBlock"));

	UPROPERTY(Transient)
	class UMaterialInstanceDynamic* HitAnimationBlockMaterial = nullptr;
};

/**
* AutoMoveTowardsTarget
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "AutoMoveTowardsTarget"))
class UAnimNotifyState_AutoMoveTowardsTarget : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;	
};

/**
 * LaunchProjectile Notify
 */
UCLASS(const, hidecategories = Object, collapsecategories, meta = (DisplayName = "LaunchProjectile"))
class P3_API UAnimNotify_LaunchProjectile : public UAnimNotify
{
	GENERATED_BODY()

public:
	// Begin UAnimNotify interface
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	/** If not set, weapon's projectile is used */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	TSubclassOf<class AP3Projectile> ProjectileClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	TSubclassOf<class UCameraShake> CameraShakeClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	FVector LaunchDirection = FVector::ForwardVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	FVector LaunchLocationOffset = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	EP3UsingAimRotationType UsingAimRotationType = EP3UsingAimRotationType::UntilNotify;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	float ConsumeStamina = 0.f;
};

/**
 * Show projectile
 */
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "ShowProjectile"))
class UAnimNotifyState_ShowProjectile : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
	
	UPROPERTY(EditAnywhere, Category = "P3")
	TSubclassOf<class AP3Projectile> ProjectileClass;

	UPROPERTY(EditAnywhere, Category = "P3")
	FName AttachBoneName = NAME_None;
};

/**
 * Start Buff
 */
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "StartBuff"))
class UAnimNotifyState_StartBuff : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	int32 CmsBuffKey = 0;
};

/**
 * Activate Part
 */
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "ActivatePart"))
class UAnimNotifyState_ActivatePart : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	TArray<FName> ActivatePartNames;
};

/**
 * Deactivate Part
 */
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "DeactivatePart"))
class UAnimNotifyState_DeactivatePart : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	TArray<FName> DeactivatePartNames;
};

/**
 * Attack With SkeletalMesh Physics
 * Use skeletal mesh's physics mesh as a weapon
 * Anything that overlaps with assigned mesh will get hit
 */
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "Bone Attack"))
class UAnimNotifyState_BoneAttack : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	const FName& GetCmsCombatHitKey() const { return CmsCombatHitKey; }
	bool IsThrow() const { return bThrow; }

private:
	UPROPERTY(EditAnywhere, Category = "Bone Attack")
	TArray<FName> BoneNames;

	UPROPERTY(EditAnywhere, Category = "Bone Attack")
	FName CmsCombatHitKey;

	/** If set true, overlapped character will be thrown away */
	UPROPERTY(EditAnywhere, Category = "Bone Attack")
	bool bThrow = false;
};

/**
* It's detected in the combo and used as a notify signal
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "ComboSignal"))
class UAnimNotifyState_ComboSignal : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
	virtual FString GetNotifyName_Implementation() const override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	FName SignalName = NAME_None;
};

/**
* Prevent movement input during the interval
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "MoveInputIgnore"))
class UAnimNotifyState_MoveInputIgnore : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};

/**
* Prevent movement turn input during the interval
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "TurnInputIgnore"))
class UAnimNotifyState_TurnInputIgnore : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};

/**
* Prevent camera movement input during the interval
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "CameraMoveInputIgnore"))
class UAnimNotifyState_CameraMoveInputIgnore : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};

/**
* Store aforetime input button in Stack
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "InputStack"))
class UAnimNotifyState_InputStack : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};

/**
* Animation information to use in the reaction
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "ReactionLayerAnimation"))
class UAnimNotifyState_ReactionLayerAnimation : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	EP3ReactionLayerAnimationType ReactionLayerAnimationType = EP3ReactionLayerAnimationType::None;
};

/**
 * Blow Horn
 */
UCLASS(const, hidecategories=Object, collapsecategories, meta=(DisplayName="Blow Horn"))
class P3_API UAnimNotify_BlowHorn: public UAnimNotify
{
	GENERATED_BODY()

	// Begin UAnimNotify interface
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

public:
	UPROPERTY(EditAnywhere, Category="P3")
	float Radius = 10000.0f;
};

/**
* Activate weapon collision shape
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "CombatWeaponCollision"))
class UAnimNotifyState_CombatWeaponCollision : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
	
	UPROPERTY(EditAnywhere, Category = "AnimNotifyState")
	FName CmsCombatHitKey = NAME_None;

	UPROPERTY(EditAnywhere, Category = "AnimNotifyState")
	bool bActiveRightHand = true;
	
	UPROPERTY(EditAnywhere, Category = "AnimNotifyState")
	bool bActiveLeftHand = false;
	
	UPROPERTY(EditAnywhere, Category = "AnimNotifyState")
	int32 MaxOverlapCount = 1;

	UPROPERTY(EditAnywhere, Category = "AnimNotifyState")
	float OverlapBufferClearTimeSeconds = 0.5f;
};


/**
 * Foot Step
 * Play particle effect and sound
 */
UCLASS(const, collapsecategories, meta = (DisplayName = "FootStep"))
class P3_API UAnimNotify_FootStep : public UAnimNotify
{
	GENERATED_BODY()

public:
	// Begin UAnimNotify interface
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

private:
	/** Surface type below this socket will be used to select right effect */
	UPROPERTY(EditAnywhere, Category = "Foot Step")
	FName SocketName;

	UPROPERTY(EditAnywhere, Category = "Foot Step")
	float ParticleScale = 1.0f;

	UPROPERTY(EditAnywhere, Category = "Foot Step")
	bool bAttachToSocket = false;

	UPROPERTY(EditAnywhere, Category = "Foot Step", meta = (EditCondition = "bAttachToSocket"))
	FTransform AttachedTransform = FTransform::Identity;
};


/**
* Use branch information in reaction conditions
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "ReactionSignal"))
class UAnimNotifyState_ReactionSignal : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
	virtual FString GetNotifyName_Implementation() const override;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotifyState")
	FName SignalName = NAME_None;
};

/**
 * Camera Shake
 */
UCLASS(const, hidecategories = Object, collapsecategories, meta = (DisplayName = "CameraShake"))
class UAnimNotify_CameraShake : public UAnimNotify
{
	GENERATED_BODY()

	// Begin UAnimNotify interface
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

public:
	UPROPERTY(EditAnywhere, Category = "P3")
	FName CmsCameraShakeKey = NAME_None;
};

/**
* Stash Weapon
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "StashWeapon"))
class UAnimNotifyState_StashWeapon : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(EditAnywhere, Category = "P3")
	EP3HoldType HoldType = EP3HoldType::RightHand;
};

/**
* Adapt Attack Moving
* 캐릭터를 코드에서 이동/회전하는 구간을 지정
*/
UCLASS(editinlinenew, const, hidecategories = Object, collapsecategories, MinimalAPI, meta = (DisplayName = "Adapted Attack Move"))
class UAnimNotifyState_AdaptedAttackMove : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	// Begin UAnimNotifyState interface
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
};

/**
 * Hit Notify (Working with FP3AnimNotifyGenerator. No Notify function here)
 */
UCLASS(const, hidecategories = Object, collapsecategories, meta = (DisplayName = "Adapted Attack Hit"))
class UAnimNotify_AdaptedAttackHit : public UAnimNotify
{
	GENERATED_BODY()

public:
	/** 타격 지점의 기준이되는 소켓. 비어있을 경우 루트본을 사용 */
	UPROPERTY(EditAnywhere, Category = "Adpated Attack")
	FName SocketName;

	/** 타격 지점 오프셋. 소켓 좌표계 기준 */
	UPROPERTY(EditAnywhere, Category = "Adpated Attack")
	FVector Offset = FVector::ZeroVector;
};
