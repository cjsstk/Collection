// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Network/Lib/P3NetCore.h"
#include "P3StoreInterface.h"
#include "P3StaminaPointComponent.generated.h"

UENUM()
enum class EStaminaConsumerLayer
{
	/**
	 * Stance
	 */
	Sprint,
	Blocking,
	Climbing,
	Gliding,
	Pushing,
	Mounted,
	CombatCharging,
	BuckingHangOn,

	/**
	 * Part
	 */
	ConsumePart,

	/**
	 * Combo
	 */
	Combo,
	Max
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3StaminaPointComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3StaminaPointComponent();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void OnRegister() override;
	virtual void OnUnregister() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	float GetMaxStaminaPoint() const { return MaxStaminaPoint; }

	UFUNCTION(BlueprintCallable)
	float GetStaminaPoint() const;

	UFUNCTION(BlueprintCallable)
	float GetStaminaPointInExhausted() const;

	UFUNCTION(BlueprintCallable)
	float GetConsumePerTick() const;

	UFUNCTION(BlueprintCallable)
	float GetConsumePerAction() const;

	void SetConsumePerAction(const float Consume) { ConsumePerAction = Consume; }

	UFUNCTION(BlueprintCallable)
	void SetMaxStaminaPoint(const float InMaxStaminaPoint);

	void FillUpStaminaPoint();
	void RestoreStaminaPoint(float InRestoreAmount);

	UFUNCTION(BlueprintCallable)
	bool IsExhausted() const { return bExhausted; }

	void SetConsumer(EStaminaConsumerLayer Layer, float ConsumeStaminaPerSecond);
	float GetConsumer(EStaminaConsumerLayer Layer) const;
	void ConsumeStamina(float ConsumeStaminaPoint);

	void SetRegenAllowed(bool bInAllowed) { bRegenAllowed = bInAllowed; }

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

private:
	void SetStaminaPoint(float InStaminaPoint);

	UPROPERTY(EditDefaultsOnly)
	float MaxStaminaPoint = 100.0f;
	
	/** Generation rate during idle(no active consumer) */
	UPROPERTY(EditDefaultsOnly)
	float BaseStaminaRegeneratePerSeconds = 5.0f;

	UPROPERTY(EditDefaultsOnly)
	float BaseStaminaRegenerateSlope = 20.0f;

	UPROPERTY(EditDefaultsOnly)
	float StaminaRegenerateMultiplierInExhausted = 0.5f;

	UPROPERTY(EditDefaultsOnly)
	float RecoverFromExhaustionStamina = 100.0f;

	float StaminaPoint = 100.0f;
	float ConsumePerTick = 0.0f;
	float ConsumePerAction = 0.0f;	// TODO: Change name to LastStaminaCosume
	float LastGenerateTimeSeconds = 0.0f;
	bool bExhausted = false;
	bool bRegenAllowed = true;

	UPROPERTY()
	float Consumers[static_cast<int>(EStaminaConsumerLayer::Max)];

};
