// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CharacterTemperatureComponent.h"

#include "DrawDebugHelpers.h"

#include "Chemical/P3Chemical.h"
#include "Chemical/P3FlammableComponent.h"
#include "Chemical/P3TemperatureVolume.h"
#include "Chemical/P3WetComponent.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3Core.h"
#include "P3GameState.h"
#include "P3Physics.h"
#include "P3Log.h"
#include "P3World.h"

extern TAutoConsoleVariable<int32> CVarTemperatureDebug;

UP3CharacterTemperatureComponent::UP3CharacterTemperatureComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	SphereRadius = 200.0f;
	ShapeColor = FColor(255, 100, 100);

	bCanEverAffectNavigation = false;

	SetCollisionObjectType(ECC_Pawn);
	SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	SetCollisionResponseToAllChannels(ECR_Ignore);
	SetCollisionResponseToChannel(ECC_FLAME, ECR_Overlap);
}

bool UP3CharacterTemperatureComponent::IsBreathVisible() const
{
	return Net_Temperature <= BreathVisibleTemperature;
}

void UP3CharacterTemperatureComponent::NetSerialize(FArchive& Archive)
{
	Archive << Net_Temperature;
	Archive << Net_TemperatureStatus;
}

void UP3CharacterTemperatureComponent::BeginPlay()
{
	Super::BeginPlay();

	Net_Temperature = P3Core::GetGameRule(*this).DefaultTemperature;

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}
}

void UP3CharacterTemperatureComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_TickFire();
		Server_TickWet();
	}

	if (CVarTemperatureDebug.GetValueOnGameThread() > 0)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (ensure(Character))
		{
			Character->AddDebugString(FString::Printf(TEXT("Temp: %.0f"), Net_Temperature));

			for (const FP3CharacterTemperatureVolume& Effect : Server_TemperatureVolumes)
			{
				AActor* SourceActor = Cast<AActor>(Effect.VolumeActor.Get());

				if (SourceActor)
				{
					DrawDebugString(GetWorld(), FVector::ZeroVector,
						FString::Printf(TEXT("%s. Temp(%.0f), Prior(%d)")
							, *SourceActor->GetName(), Effect.Temperature, Effect.Priority)
						, SourceActor, FColor::White, 0.0f, true);

					DrawDebugLine(GetWorld(), Character->GetActorLocation(), SourceActor->GetActorLocation(), FColor::White);
				}
			}
		}
	}
}

void UP3CharacterTemperatureComponent::Server_AddTemperatureVolume(float Temperature, int32 Priority, class AP3TemperatureVolume& VolumeActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	FP3CharacterTemperatureVolume* AlreadyExistedInstance = Server_TemperatureVolumes.FindByPredicate([&VolumeActor](const FP3CharacterTemperatureVolume& Instance) -> bool {
		return (Instance.VolumeActor.Get() == &VolumeActor);
	});

	if (AlreadyExistedInstance)
	{
		ensure(0);
		P3JsonLog(Warning, "Character temperature effect is added but already exists",
			TEXT("Source"), VolumeActor.GetName());
		return;
	}

	FP3CharacterTemperatureVolume NewInstance;
	NewInstance.VolumeActor = &VolumeActor;
	NewInstance.Temperature = Temperature;
	NewInstance.Priority = Priority;

	Server_TemperatureVolumes.Add(NewInstance);

	Server_UpdateTemperature();
}

void UP3CharacterTemperatureComponent::Server_RemoveTemperatureVolume(class AP3TemperatureVolume& VolumeActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const int32 NumRemoved = Server_TemperatureVolumes.RemoveAll([&VolumeActor](const FP3CharacterTemperatureVolume& Instance) -> bool {
		return (Instance.VolumeActor.Get() == &VolumeActor);
	});

	if (ensure(NumRemoved > 0))
	{
		Server_UpdateTemperature();
	}
}

void UP3CharacterTemperatureComponent::Server_UpdateTemperature()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const UP3GameRule& GameRule = P3Core::GetGameRule(*this);

	int32 Priority = -1;
	float NewTemperature = GameRule.DefaultTemperature;

	for (const FP3CharacterTemperatureVolume& Effect : Server_TemperatureVolumes)
	{
		if (Effect.Priority > Priority)
		{
			NewTemperature = Effect.Temperature;
		}
	}

	// Apply fire temperature
	NewTemperature = NewTemperature + Server_FireTemperature;
	NewTemperature = FMath::Clamp(NewTemperature, P3Chemical::MIN_Temperature, P3Chemical::MAX_Temperature);

	// Apply wet
	if (Server_bIsWet)
	{
		if (NewTemperature > 0)
		{
			NewTemperature *= 0.5f;
		}
	}

	if (Net_Temperature != NewTemperature)
	{
		Net_Temperature = NewTemperature;
		
		// Update Status
		EP3CharacterTemperatureStatus OldStatus = Net_TemperatureStatus;

		if (Net_Temperature <= ColdTemperature)
		{
			Net_TemperatureStatus = EP3CharacterTemperatureStatus::Cold;
		}
		else if (Net_Temperature >= HotTemperature)
		{
			Net_TemperatureStatus = EP3CharacterTemperatureStatus::Hot;
		}
		else
		{
			Net_TemperatureStatus = EP3CharacterTemperatureStatus::Normal;
		}

		if (OldStatus != Net_TemperatureStatus)
		{
			// Status is changed, we need to update buffs

			AP3Character* Character = Cast<AP3Character>(GetOwner());
			UP3CharacterEffectComponent* EffectComp = Character ? Character->GetEffectComponent() : nullptr;
			
			if (ensure(EffectComp))
			{
				// Remove old buffs
				for (int32 BuffId : Server_Buffs)
				{
					EffectComp->Server_RemoveBuff(BuffId);
				}
				Server_Buffs.Empty();

				// Add new buffs
				const TArray<int32>* Buffs = nullptr;

				if (Net_TemperatureStatus == EP3CharacterTemperatureStatus::Cold)
				{
					Buffs = &GameRule.DefaultCharacterColdBuffs;
				}
				else if (Net_TemperatureStatus == EP3CharacterTemperatureStatus::Hot)
				{
					Buffs = &GameRule.DefaultCharacterHotBuffs;
				}

				if (Buffs)
				{
					for (int32 BuffKey : *Buffs)
					{
						const int32 BuffId = EffectComp->Server_AddBuff(BuffKey, this);

						Server_Buffs.Add(BuffId);
					}
				}
			}
		}

		Server_SetDirty(*this);
	}
}

void UP3CharacterTemperatureComponent::Server_TickFire()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();

	if (!OwnerActor)
	{
		return;
	}

	const float MyRadius = GetScaledSphereRadius();

	if (MyRadius < KINDA_SMALL_NUMBER)
	{
		return;
	}

	const AActor* MyRootActor = P3Core::GetAttachRootActor(OwnerActor, true);

	const FVector MyLocation = OwnerActor->GetActorLocation();

	float FireTemperature = 0;

	TArray<const UP3FlammableComponent*> ProcessedFlammableComps;

	for (const FOverlapInfo& OverlappingComp : OverlappingComponents)
	{
		const UP3FlammableComponent* FlammableComp = Cast<UP3FlammableComponent>(OverlappingComp.OverlapInfo.GetComponent());

		if (!FlammableComp)
		{
			continue;
		}

		if (FlammableComp->IsInFire())
		{
			if (ProcessedFlammableComps.Contains(FlammableComp))
			{
				continue;
			}

			ProcessedFlammableComps.Add(FlammableComp);

			const AActor* OverlappingRootActor = P3Core::GetAttachRootActor(FlammableComp->GetOwner(), true);

			if (MyRootActor == OverlappingRootActor)
			{
				FireTemperature = OwnFlammableTemperatureAddition;
			}
			else
			{
				const float Distance = (FlammableComp->GetComponentLocation() - MyLocation).Size()
					- FlammableComp->GetScaledSphereRadius();

				const float Temperature = P3Chemical::MAX_Temperature * ((MyRadius - Distance) / MyRadius);

				FireTemperature += Temperature;

#if ENABLE_DRAW_DEBUG
				if (CVarTemperatureDebug.GetValueOnGameThread() > 0)
				{
					DrawDebugString(GetWorld(), FlammableComp->GetComponentLocation(), FString::Printf(TEXT("Distance: %.2f, Temp: %.2f"), Distance, Temperature), nullptr, FColor::White, 0.0f, true);
				}
#endif
			}
		}
	}

	if (Server_FireTemperature != FireTemperature)
	{
		Server_FireTemperature = FireTemperature;

		Server_UpdateTemperature();
	}
}

void UP3CharacterTemperatureComponent::Server_TickWet()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!Character)
	{
		return;
	}

	UP3WetComponent* WetComp = Character->GetWetComponent();

	if (!WetComp)
	{
		return;
	}

	const bool bNewWet = WetComp->IsWet();

	if (Server_bIsWet != bNewWet)
	{
		Server_bIsWet = bNewWet;

		Server_UpdateTemperature();
	}
}
