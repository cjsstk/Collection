// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3SurfaceEffectComponent.h"

#include "Components/SkeletalMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystemComponent.h"
#include "PhysicalMaterials/PhysicalMaterial.h"

#include "P3Character.h"
#include "P3CharacterMovementComponent.h"
#include "P3Core.h"
#include "P3GameState.h"
#include "P3Physics.h"

static TAutoConsoleVariable<int32> CVarP3SurfaceEffectDebug(
	TEXT("p3.surfaceEffectDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SurfaceHitEffectIntervalSeconds(
	TEXT("p3.surfaceHitEffectIntervalSeconds"),
	0.05f,
	TEXT("Set hit effect interval"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SurfaceSlipperySlopeThreshold(
	TEXT("p3.surfaceSlipperySlopeThreshold"),
	0.75f,
	TEXT("미끄러운 지면 기준값(경사가 급한 정도, [0.0, 1.0])"), ECVF_Cheat);


UP3SurfaceEffectComponent::UP3SurfaceEffectComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
}

void UP3SurfaceEffectComponent::BeginPlay()
{
	Super::BeginPlay();

	if (GIsClient)
	{
		SetComponentTickEnabled(true);

		ACharacter* Character = Cast<ACharacter>(GetOwner());
		if (Character)
		{
			SetMesh(Character->GetMesh());
		}

		for (const FP3SurfaceEffectSocketParams& SocketParam : SocketParams)
		{
			FSocket Socket;
			Socket.SocketName = SocketParam.SocketName;

			Sockets.Add(Socket);
		}
	}
}

void UP3SurfaceEffectComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!Mesh)
	{
		return;
	}

	AActor* OwnerActor = GetOwner();
	AP3Character* OwnerCharacter = Cast<AP3Character>(OwnerActor);

	const float Now = GetWorld()->GetTimeSeconds();

	FCollisionShape Sphere;

	FCollisionQueryParams QueryParams;
	QueryParams.bReturnPhysicalMaterial = true;
	QueryParams.bIgnoreTouches = true;

	FCollisionResponseParams ResponseParams;
	ResponseParams.CollisionResponse.SetResponse(ECC_Pawn, ECR_Ignore);

	if (OwnerActor)
	{
		TArray<AActor*> AttachedActors;
		OwnerActor->GetAttachedActors(AttachedActors);

		QueryParams.AddIgnoredActor(OwnerActor);
		QueryParams.AddIgnoredActors(AttachedActors);
	}

	const UP3GameResource& Resource = P3Core::GetGameResource(this);

	for (int32 SocketIndex = 0; SocketIndex < Sockets.Num(); ++SocketIndex)
	{
		if (!ensure(SocketParams.IsValidIndex(SocketIndex)))
		{
			break;
		}

		const FP3SurfaceEffectSocketParams& SocketParam = SocketParams[SocketIndex];
		FSocket& Socket = Sockets[SocketIndex];

		const FVector NewLocation = Mesh->GetSocketLocation(Socket.SocketName);

		if (!Socket.Location.IsZero() && DeltaTime > KINDA_SMALL_NUMBER)
		{
			Socket.Velocity = (NewLocation - Socket.Location) / DeltaTime;
		}
		else
		{
			Socket.Velocity = FVector::ZeroVector;
		}

		Sphere.SetSphere(SocketParam.CollisionSphereRadius);

		const bool bHit = GetWorld()->SweepSingleByChannel(Socket.HitResult, Socket.Location, NewLocation, FQuat::Identity, ECC_Pawn, Sphere, QueryParams, ResponseParams);

		Socket.Location = NewLocation;
		Socket.bHit = bHit;

		if (bHit)
		{
			UPhysicalMaterial* PhysicalMaterial = Socket.HitResult.PhysMaterial.Get();

			if (PhysicalMaterial)
			{
				// TODO: Cache this
				for (const FP3SurfaceEffect& SurfaceEffect : Resource.SurfaceEffects)
				{
					if (SurfaceEffect.SurfaceType != PhysicalMaterial->SurfaceType)
					{
						continue;
					}

					if (SurfaceEffect.bOnSlip && OwnerCharacter)
					{
						const UP3CharacterMovementComponent* MoveComp = Cast<UP3CharacterMovementComponent>(OwnerCharacter->GetMovementComponent());
						if (MoveComp)
						{
							if (MoveComp->GetSlopeRatio() < CVarP3SurfaceSlipperySlopeThreshold.GetValueOnAnyThread())
							{
								continue;
							}
						}
					}

					float LastSpawnTimeSeconds = -1.0f;
					if (Socket.LastParticleSpawnTimeSeconds.Contains(&SurfaceEffect))
					{
						LastSpawnTimeSeconds = Socket.LastParticleSpawnTimeSeconds[&SurfaceEffect];
					}

					if (Socket.Velocity.Size() > SurfaceEffect.SpawnParticleMinSpeed
						&& (Now - LastSpawnTimeSeconds) > SurfaceEffect.ParticleSpawnPeriodSeconds)
					{
						SpawnParticle(Socket, SocketParam, SurfaceEffect);
					}
				}
			}
		}
	}

	for (FSocket& Socket : Sockets) {
		for (auto Iter = Socket.LastParticleSpawnTimeSeconds.CreateIterator(); Iter; ++Iter)
		{
			float LastSpawned = Iter.Value();
			if (Now - LastSpawned >= 60.0f)
			{
				Iter.RemoveCurrent();
			}
		}
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3SurfaceEffectDebug.GetValueOnGameThread() > 0)
	{
		for (int32 SocketIndex = 0; SocketIndex < Sockets.Num(); ++SocketIndex)
		{
			if (!ensure(SocketParams.IsValidIndex(SocketIndex)))
			{
				break;
			}

			const FP3SurfaceEffectSocketParams& SocketParam = SocketParams[SocketIndex];
			FSocket& Socket = Sockets[SocketIndex];

			DrawDebugSphere(GetWorld(), Socket.Location, SocketParam.CollisionSphereRadius, 24, Socket.bHit ? FColor::Green : FColor::White);

			if (Socket.bHit)
			{
				UPhysicalMaterial* PhysicalMaterial = Socket.HitResult.PhysMaterial.Get();

				if (PhysicalMaterial)
				{
					DrawDebugString(GetWorld(), Socket.Location, P3Physics::GetSurfaceName(PhysicalMaterial->SurfaceType).ToString(), nullptr, FColor::White, 0.0f, true);
				}
			}
		}
	}
#endif
}

void UP3SurfaceEffectComponent::SpawnParticle(FSocket& Socket, const FP3SurfaceEffectSocketParams& SocketParam, const struct FP3SurfaceEffect& SurfaceEffect)
{
	const float Now = GetWorld()->GetTimeSeconds();

	if (Socket.LastParticleSpawnTimeSeconds.Contains(&SurfaceEffect))
	{
		Socket.LastParticleSpawnTimeSeconds[&SurfaceEffect] = Now;
	}
	else
	{
		Socket.LastParticleSpawnTimeSeconds.Add(&SurfaceEffect, Now);
	}

	UParticleSystemComponent* ParticleComp = UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), SurfaceEffect.Particle, Socket.HitResult.ImpactPoint, FRotator::ZeroRotator,
		FVector(SurfaceEffect.ParticleScale * SocketParam.ParticleScale));

	if (ParticleComp)
	{
		const static FName NAME_Velocity(TEXT("Velocity"));
		ParticleComp->SetVectorParameter(NAME_Velocity, Socket.Velocity);
	}
}

UP3SurfaceHitEffectComponent::UP3SurfaceHitEffectComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UP3SurfaceHitEffectComponent::BeginPlay()
{
	Super::BeginPlay();

	if (GIsClient)
	{
		AActor* OwnerActor = GetOwner();

		if (OwnerActor)
		{
			OwnerActor->OnActorHit.AddUniqueDynamic(this, &UP3SurfaceHitEffectComponent::OnActorHit);
		}
	}
}

void UP3SurfaceHitEffectComponent::OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit)
{
	const float Now = GetWorld()->GetTimeSeconds();

	if (Now < LastSpawnTimeSeconds + CVarP3SurfaceHitEffectIntervalSeconds.GetValueOnGameThread())
	{
		// It's too early from last emit
		return;
	}

	if (NormalImpulse.SizeSquared() < MinImpulseSize * MinImpulseSize)
	{
		return;
	}

	const UP3GameResource& Resource = P3Core::GetGameResource(this);

	UPhysicalMaterial* PhysicalMaterial = Hit.PhysMaterial.Get();

	if (PhysicalMaterial)
	{
		// TODO: Cache this
		for (const FP3SurfaceEffect& SurfaceEffect : Resource.SurfaceEffects)
		{
			if (SurfaceEffect.SurfaceType != PhysicalMaterial->SurfaceType)
			{
				continue;
			}

			UParticleSystemComponent* ParticleComp = UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), SurfaceEffect.Particle, Hit.ImpactPoint, FRotator::ZeroRotator,
				FVector(SurfaceEffect.ParticleScale * ParticleScale));

			LastSpawnTimeSeconds = Now;
		}
	}
}
