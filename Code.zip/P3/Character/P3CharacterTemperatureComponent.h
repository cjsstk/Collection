// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SphereComponent.h"

#include "P3StoreInterface.h"

#include "P3CharacterTemperatureComponent.generated.h"

UENUM(BlueprintType)
enum class EP3CharacterTemperatureStatus : uint8
{
	Normal,
	Cold,
	Hot
};


/**
 * Character Temperature
 */
UCLASS()
class UP3CharacterTemperatureComponent : public USphereComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:
	UP3CharacterTemperatureComponent();

	void Server_AddTemperatureVolume(float Temperature, int32 Priority, class AP3TemperatureVolume& VolumeActor);
	void Server_RemoveTemperatureVolume(class AP3TemperatureVolume& VolumeActor);

	UFUNCTION(BlueprintCallable)
	float GetTemperature() const { return Net_Temperature; }

	UFUNCTION(BlueprintCallable)
	EP3CharacterTemperatureStatus GetCharacterStatus() const { return Net_TemperatureStatus; }

	UFUNCTION(BlueprintCallable)
	bool IsBreathVisible() const;

protected:
	virtual void BeginPlay();
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

private:
	void Server_UpdateTemperature();

	/** Look for nearby by fire */
	void Server_TickFire();
	void Server_TickWet();

	struct FP3CharacterTemperatureVolume
	{
		TWeakObjectPtr<class AP3TemperatureVolume> VolumeActor;
		float Temperature = 0;
		int32 Priority = 0;
	};

	/**
	 * Config
	 */

	/** If environment temperature is below or same to this, breath become visible */
	UPROPERTY(EditDefaultsOnly, Category = "Character Temperature|Breath")
	float BreathVisibleTemperature = 5.0f;

	/** If environment temperature below or same to this, character feels cold */
	UPROPERTY(EditDefaultsOnly, Category = "Character Temperature")
	float ColdTemperature = 0.0f;

	/** If environment temperature above or same to this, character feels hot */
	UPROPERTY(EditDefaultsOnly, Category = "Character Temperature")
	float HotTemperature = 30.0f;

	/** If owner actor has burning flammable, this temperature will be added */
	UPROPERTY(EditDefaultsOnly, Category = "Character Temperature")
	float OwnFlammableTemperatureAddition = 10.0f;

	/**
	 * Status
	 */

	/** Affecting volumes */
	TArray<FP3CharacterTemperatureVolume> Server_TemperatureVolumes;

	/** Added temperature by fire */
	float Server_FireTemperature = 0.0f;

	/** Am I wet? */
	bool Server_bIsWet = false;

	/** Current temperature */
	float Net_Temperature = 0.0f;

	/** Current status. Whether character feels cold or hot */
	EP3CharacterTemperatureStatus Net_TemperatureStatus = EP3CharacterTemperatureStatus::Normal;

	TArray<int32> Server_Buffs;
};
