// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3CharacterMeshDamperComponent.h"

#include "Components/SkeletalMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"

#include "P3Character.h"
#include "P3ActorInterface.h"

static TAutoConsoleVariable<int32> CVarP3CharacterMeshDamperDebug(
	TEXT("p3.characterMeshDamperDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

UP3CharacterMeshDamperComponent::UP3CharacterMeshDamperComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
}


void UP3CharacterMeshDamperComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		ACharacter* Character = Cast<ACharacter>(GetOwner());

		if (Character)
		{
			MeshComponent = Character->GetMesh();

			if (MeshComponent)
			{
				LastLocation =  MeshComponent->GetComponentLocation();
				DefaultOffset = MeshComponent->GetRelativeTransform().GetLocation();

				SetComponentTickEnabled(true);

				UCharacterMovementComponent* MovementComp = Character->GetCharacterMovement();

				if (MovementComp)
				{
					PrimaryComponentTick.AddPrerequisite(MovementComp, MovementComp->PrimaryComponentTick); // force us to tick after the parent does
				}
			}
		}
	}
}


void UP3CharacterMeshDamperComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!MeshComponent)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(MeshComponent->GetOwner());

	if (!Character)
	{
		return;
	}

	const FVector NewLocation = MeshComponent->GetComponentLocation();
	const FVector DeltaLocation = NewLocation - LastLocation;
	const float DeltaDistance = DeltaLocation.Size();

	if (DeltaDistance > 1000)
	{
		// Maybe teleported?
		LastLocation = NewLocation;
		CurrentZOffset = 0;
		MeshComponent->SetRelativeLocation(DefaultOffset);
		Character->CacheInitialMeshOffset(MeshComponent->RelativeLocation, Character->GetBaseRotationOffsetRotator());
		return;
	}

	if (Damping > 0)
	{
		const float DeltaZ = DeltaLocation.Z;
		CurrentZOffset -= DeltaZ;
		CurrentZOffset = FMath::Lerp(CurrentZOffset, 0.0f, DeltaTime / Damping);
	}
	else
	{
		CurrentZOffset = 0.0f;
	}

	const FVector NewOffset = FVector(DefaultOffset.X, DefaultOffset.Y, DefaultOffset.Z + CurrentZOffset);

	MeshComponent->SetRelativeLocation(NewOffset);
	Character->CacheInitialMeshOffset(MeshComponent->RelativeLocation, Character->GetBaseRotationOffsetRotator());

	LastLocation = MeshComponent->GetComponentLocation();

	if (CVarP3CharacterMeshDamperDebug.GetValueOnGameThread() > 0)
	{
		IP3ActorInterface* P3Actor = Cast<IP3ActorInterface>(GetOwner());

		if (P3Actor)
		{
			P3Actor->AddDebugString(FString::Printf(TEXT("[Mesh Damping] ZOffset: %.2f"), CurrentZOffset));
		}

		DrawDebugDirectionalArrow(GetWorld(), MeshComponent->GetComponentLocation()
			, MeshComponent->GetComponentLocation() + MeshComponent->GetAttachParent()->GetComponentRotation().RotateVector(NewOffset)
			, 50.0f, FColor::Green, false, -1.0f, 1);
	}
}

