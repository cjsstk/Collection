// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3CharacterMeshDamperComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3CharacterMeshDamperComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3CharacterMeshDamperComponent();

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	UPROPERTY(EditDefaultsOnly)
	float Damping = 1.0f;

	UPROPERTY()
	class USkeletalMeshComponent* MeshComponent;

	FVector LastLocation = FVector::ZeroVector;
	FVector DefaultOffset = FVector::ZeroVector;
	float CurrentZOffset = 0;

};
