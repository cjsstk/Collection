// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3SurfaceEffectComponent.generated.h"

USTRUCT(Blueprintable)
struct FP3SurfaceEffectSocketParams
{
	GENERATED_BODY()

	/** 표면 이펙트 재생 위치 */
	UPROPERTY(EditDefaultsOnly)
	FName SocketName;

	/** 표면 충돌 검사 반경 */
	UPROPERTY(EditDefaultsOnly)
	float CollisionSphereRadius = 50.0f;

	/** 이펙트 크기 배율 (GameResource 설정과 곱연산) */
	UPROPERTY(EditDefaultsOnly)
	float ParticleScale = 1.0f;
};


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3SurfaceEffectComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3SurfaceEffectComponent();
	
protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	void SetMesh(class USkeletalMeshComponent* InMesh) { Mesh = InMesh; }

	struct FSocket;
	void SpawnParticle(FSocket& Socket, const FP3SurfaceEffectSocketParams& SocketParam, const struct FP3SurfaceEffect& SurfaceEffect);

	UPROPERTY(EditDefaultsOnly, Category = "Surface Effect")
	TArray<FP3SurfaceEffectSocketParams> SocketParams;

	UPROPERTY(Transient)
	class USkeletalMeshComponent* Mesh = nullptr;

	struct FSocket
	{
		FName SocketName;
		
		FVector Location = FVector::ZeroVector;
		FVector Velocity = FVector::ZeroVector;

		bool bHit = false;
		FHitResult HitResult;

		TMap<const struct FP3SurfaceEffect*, float> LastParticleSpawnTimeSeconds;
	};

	TArray<FSocket> Sockets;
};


UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class P3_API UP3SurfaceHitEffectComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3SurfaceHitEffectComponent();

	void SetParticleScale(float InScale) { ParticleScale = InScale; }

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit);

private:
	UPROPERTY(EditDefaultsOnly)
	float MinImpulseSize = 10000.0f;

	UPROPERTY(EditDefaultsOnly)
	float ParticleScale = 1.0f;

	float LastSpawnTimeSeconds = 0;
};
