// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3TripType.generated.h"

UENUM(Blueprintable)
enum class EP3RouteTripType : uint8
{
	OneWay,
	RoundTrip,
	CircleTrip
};
