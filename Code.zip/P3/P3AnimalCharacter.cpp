// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AnimalCharacter.h"

#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Controller.h"

#include "Command/P3CommandComponent.h"
#include "P3AttributesComponent.h"
#include "P3Core.h"
#include "P3HealthPointComponent.h"
#include "P3InteractableComponent.h"
#include "P3RagdollComponent.h"
#include "P3Store.h"

AP3AnimalCharacter::AP3AnimalCharacter(const FObjectInitializer& ObjectInitializer)
{
	bNetLoadOnClient = false;

	PrimaryActorTick.bCanEverTick = true;

	StoreComponent = CreateDefaultSubobject<UP3StoreComponent>(TEXT("StoreComponent"));
	AttributeComponent = CreateDefaultSubobject<UP3AttributesComponent>(TEXT("AttributeComponent"));
	HealthComponent = CreateDefaultSubobject<UP3HealthPointComponent>(TEXT("HealthComponent"));
	RagdollComponent = CreateDefaultSubobject<UP3RagdollComponent>(TEXT("RagdollComponent"));
	CommandComponent = CreateDefaultSubobject<UP3CommandComponent>(TEXT("CommandComponent"));
}

void AP3AnimalCharacter::PostActorCreated()
{
	Super::PostActorCreated();

	RegisterToP3World(*this);
}

void AP3AnimalCharacter::BeginPlay()
{
	Super::BeginPlay();

	if (HealthComponent)
	{
		HealthComponent->OnDead.AddUniqueDynamic(this, &AP3AnimalCharacter::OnDead);
	}
}

void AP3AnimalCharacter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (HealthComponent)
	{
		HealthComponent->OnDead.RemoveDynamic(this, &AP3AnimalCharacter::OnDead);
	}
}

void AP3AnimalCharacter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaTime);
	}

	TickIgnoreMoveInput();

#if ENABLE_DRAW_DEBUG
	if (!DebugString.IsEmpty())
	{
		DrawDebugString(GetWorld(), FVector(0, 0, 100), DebugString, this, FColor::White, 0, true);
		DebugString.Empty();
	}
#endif
}

void AP3AnimalCharacter::Server_Tick(float DeltaSeconds)
{
	if (HealthComponent && HealthComponent->GetHealthPoint() == 0)
	{
		/*if (RagdollComponent && !RagdollComponent->IsRagdollized())
		{
			FP3CommandRequestParams Params;
			Params.Ragdollize_bRagdoll = true;

			CommandComponent->RequestCommand(UP3RagdollizeCommand::StaticClass(), Params);
		}*/

		GetCharacterMovement()->SetMovementMode(MOVE_None);
	}
}

void AP3AnimalCharacter::TickIgnoreMoveInput()
{
	AController* MyController = GetController();

	if (!MyController || !MyController->IsLocalPlayerController())
	{
		return;
	}

	bool bNewIgnoreMoveInput = false;

	if (HealthComponent && HealthComponent->GetHealthPoint() == 0)
	{
		bNewIgnoreMoveInput = true;
	}

	if (bIgnoredMoveInput != bNewIgnoreMoveInput)
	{
		bIgnoredMoveInput = bNewIgnoreMoveInput;

		MyController->SetIgnoreMoveInput(bIgnoredMoveInput);
	}
}

void AP3AnimalCharacter::OnDead()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		SetLifeSpan(20.0f);
	}

	TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
	GetComponents(PrimComps);

	for (UPrimitiveComponent* PrimComp : PrimComps)
	{
		PrimComp->SetCollisionResponseToAllChannels(ECR_Ignore);
		PrimComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldDynamic, ECollisionResponse::ECR_Block);
		PrimComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_WorldStatic, ECollisionResponse::ECR_Block);
	}
}

void AP3AnimalCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
}

void AP3AnimalCharacter::SpawnDefaultController()
{
	// Overriding APawn::SpawnDefaultController, since P3 client is not NM_Client and creates AI controller which we don't want to

	if (Controller != nullptr || !P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (AIControllerClass != nullptr)
	{
		FActorSpawnParameters SpawnInfo;
		SpawnInfo.Instigator = Instigator;
		SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		SpawnInfo.OverrideLevel = GetLevel();
		SpawnInfo.ObjectFlags |= RF_Transient;	// We never want to save AI controllers into a map
		AController* NewController = GetWorld()->SpawnActor<AController>(AIControllerClass, GetActorLocation(), GetActorRotation(), SpawnInfo);
		if (NewController != nullptr)
		{
			// if successful will result in setting this->Controller 
			// as part of possession mechanics
			NewController->Possess(this);
		}
	}
}

void AP3AnimalCharacter::NetSerialize(FArchive& Archive)
{

}

UP3StoreComponent* AP3AnimalCharacter::GetStoreComponent() const
{
	return StoreComponent;
}

void AP3AnimalCharacter::NetSerializeMovement(FArchive& Archive)
{

}

void AP3AnimalCharacter::GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const
{
	TagContainer = GameplayTagContainer;
}

void AP3AnimalCharacter::AddGameplayTags(const struct FGameplayTagContainer& TagContainer)
{
	GameplayTagContainer.AppendTags(TagContainer);
}

void AP3AnimalCharacter::RemoveGameplayTags(const struct FGameplayTagContainer& TagContainer)
{
	GameplayTagContainer.RemoveTags(TagContainer);
}

void AP3AnimalCharacter::AddDebugString(const FString& InDebugString, bool bAddNewLine /*= true*/)
{
	DebugString += InDebugString;

	if (bAddNewLine)
	{
		DebugString += TEXT("\n");
	}
}
