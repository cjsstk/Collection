// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "P3CreateCmsTableCommandlet.h"

#include "AssetRegistryModule.h"
#include "HAL/PlatformFilemanager.h"

#include "P3AnimNotify.h"
#include "P3CombatComponent.h"
#include "P3Commandlet.h"
#include "P3Log.h"

#if WITH_EDITOR
#include "UnrealEd.h"
#endif

// Usage: UE4Editor.exe c:\work\p3\unreal\Game\P3.uproject run=P3CreateCmsTableCommandlet

#if WITH_EDITOR
static FString Pluralize(const FString& Word)
{
	return Word + TEXT("s");
}

static bool CreateDataTableFromCSV(IAssetRegistry& AssetRegistry, UScriptStruct* RowStruct)
{
	FString ObjectName = RowStruct->GetStructCPPName();
	ObjectName.RemoveFromStart("FP3Cms");
	ObjectName = Pluralize(ObjectName);

	const FString PackageName = FString::Printf(TEXT("/Game/CMS/%s"), *ObjectName);
	const FString AssetPath = FString::Printf(TEXT("%s.%s"), *PackageName, *ObjectName);

	UDataTable* DataTable = LoadObject<UDataTable>(nullptr, *AssetPath);
	if (!DataTable)
	{
		UPackage* Package = CreatePackage(nullptr, *PackageName);
		DataTable = NewObject<UDataTable>(Package, FName(*ObjectName), RF_Public | RF_Standalone);
		if (!ensure(DataTable))
		{
			return false;
		}

		AssetRegistry.AssetCreated(DataTable);
	}

	DataTable->RowStruct = RowStruct;
	const FString FilePath = FPaths::ProjectContentDir() / TEXT("CMS") / FString::Printf(TEXT("%s.csv"), *ObjectName);

	FString CSV;
	const bool bResult = FFileHelper::LoadFileToString(CSV, *FilePath);
	if (!ensure(bResult))
	{
		return false;
	}

	const TArray<FString> Problems = DataTable->CreateTableFromCSVString(CSV);
	if (!ensure(Problems.Num() == 0))
	{
		return false;
	}

	return P3Commandlet::SaveAsset(DataTable);
}
#endif

int32 UP3CreateCmsTableCommandlet::Main(const FString& Params)
{
#if WITH_EDITOR
	// Load AssetRegistryModule
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	const FString CmsFilePath = FPaths::ProjectContentDir() / TEXT("CMS");

	TArray<UScriptStruct*> Structs = P3Cms::GetAllRowStructs();
	for (UScriptStruct* Struct : Structs)
	{
		if (!CreateDataTableFromCSV(AssetRegistry, Struct))
		{
			UE_LOG(P3Log, Error, TEXT("Failed to create data table: %s"), *Struct->GetStructCPPName());
			return 1;
		}
	}
#endif // WITH_EDITOR

	return 0;
}
