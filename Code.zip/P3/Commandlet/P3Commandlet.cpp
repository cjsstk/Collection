// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "P3Commandlet.h"

#include "GenericPlatformFile.h"
#include "Object.h"
#include "Package.h"
#include "PackageName.h"
#include "PlatformFilemanager.h"

bool P3Commandlet::SaveAsset(UObject* Asset)
{
	Asset->MarkPackageDirty();

	UPackage* Package = Asset->GetOutermost();

	FString Filename = FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension());
	FPlatformFileManager::Get().GetPlatformFile().SetReadOnly(*Filename, false);

	const bool bSaved = UPackage::SavePackage(Package, nullptr, RF_Standalone, *FPackageName::LongPackageNameToFilename(Package->GetName(), FPackageName::GetAssetPackageExtension()));

	return bSaved;
}
