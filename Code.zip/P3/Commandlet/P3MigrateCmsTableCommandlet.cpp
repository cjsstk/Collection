// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "P3MigrateCmsTableCommandlet.h"

#include "AssetRegistryModule.h"
#include "HAL/PlatformFilemanager.h"

#include "P3AnimNotify.h"
#include "P3CombatComponent.h"
#include "P3Commandlet.h"
#include "P3ConsumableComponent.h"
#include "P3HoldableComponent.h"
#include "P3IngredientComponent.h"
#include "P3PickupableComponent.h"
#include "P3Log.h"

#if WITH_EDITOR
#include "UnrealEd.h"
#endif

// Usage: UE4Editor.exe c:\work\p3\unreal\Game\P3.uproject run=P3MigrateCmsTableCommandlet

#if WITH_EDITOR
static UDataTable* CreateDataTable(const FString& ObjectName)
{
	const FString PackageName = FString::Printf(TEXT("/Game/CMS/%s"), *ObjectName);
	const FString AssetPath = FString::Printf(TEXT("%s.%s"), *PackageName, *ObjectName);

	UPackage* Package = CreatePackage(nullptr, *PackageName);
	if (!ensure(Package))
	{
		return nullptr;
	}

	return NewObject<UDataTable>(Package, FName(*ObjectName), RF_Public | RF_Standalone);
}

//void MigrateCombatSkills(IAssetRegistry& AssetRegistry)
//{
//	UDataTable* DataTable = NewObject<UDataTable>();
//	DataTable->RowStruct = FP3CmsCombatSkill::StaticStruct();
//
//	FARFilter Filter;
//	Filter.ClassNames.Add(UBlueprint::StaticClass()->GetFName());
//	Filter.ClassNames.Add(UBlueprintGeneratedClass::StaticClass()->GetFName());
//	
//	TArray<FAssetData> AssetDataList;
//	AssetRegistry.GetAssets(Filter, AssetDataList);
//
//	for (const FAssetData& AssetData : AssetDataList)
//	{
//		if (AssetData.AssetClass.ToString() == "AnimMontage")
//		{
//			UE_LOG(P3Log, Display, TEXT("AnimMontage"));
//		}
//
//		UObject* Asset = AssetData.GetAsset();
//		if (!Asset)
//		{
//			continue;
//		}
//
//		UBlueprint* Blueprint = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), nullptr, *Asset->GetPathName()));
//		if (!Blueprint || !Blueprint->GeneratedClass || !Blueprint->GeneratedClass->GetDefaultObject())
//		{
//			continue;
//		}
//
//		UP3CombatComponent* CombatComp = Cast<UP3CombatComponent>(Blueprint->GeneratedClass->GetDefaultObject());
//		if (!CombatComp)
//		{
//			continue;
//		}
//
//		UE_LOG(P3Log, Display, TEXT("Found UP3CombatComponent: %s (%d)"), *AssetData.AssetName.ToString(), CombatComp->GetSkills().Num());
//
//		FString CharacterName = Blueprint->GetName();
//		CharacterName.ReplaceInline(TEXT("_"), TEXT(""));
//		CharacterName.ReplaceInline(TEXT("CombatBP"), TEXT(""));
//
//		const TArray<FP3CombatSkill>& Skills = CombatComp->GetSkills();
//		for (int32 SkillIndex = 0; SkillIndex < Skills.Num(); ++SkillIndex)
//		{
//			FP3CombatSkill Skill = Skills[SkillIndex];
//
//			FP3CmsCombatSkill CmsSkill;
//			CmsSkill.CmsCharacterKey = FName(*CharacterName);
//			CmsSkill.AnimMontage = Skill.AnimMontage;
//			CmsSkill.AttackRange = Skill.AttackRange;
//			CmsSkill.AttackAngleDegree = Skill.AttackAngleDegree;
//			CmsSkill.AttackDistanceZ = Skill.AttackDistanceZ;
//			CmsSkill.CooldownTimeSeconds = Skill.CooldownTimeSeconds;
//			CmsSkill.StaminuaConsume = Skill.StaminuaConsume;
//			CmsSkill.Target = Skill.Target;
//			CmsSkill.RequiredGameplayTagsAny = Skill.RequiredGameplayTagsAny;
//			CmsSkill.DisableGameplaytagsAny = Skill.DisableGameplaytagsAny;
//			CmsSkill.ProjectileClass = Skill.ProjectileClass;
//			CmsSkill.ProjectileLaunchSocketName = Skill.ProjectileLaunchSocketName;
//			CmsSkill.SpawnActorClass = Skill.SpawnActorClass;
//
//			FString Key = FString::Printf(TEXT("%s_%d"), *CharacterName, SkillIndex);
//			DataTable->AddRow(FName(*Key), CmsSkill);
//		}
//	}
//
//	FString CSV = DataTable->GetTableAsCSV();
//	FString FilePath = FPaths::ProjectContentDir() / TEXT("CMS") / TEXT("CombatSkills.csv");
//	FFileHelper::SaveStringToFile(CSV, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
//}
//
//void MigrateCombatHits(IAssetRegistry& AssetRegistry)
//{
//	UDataTable* DataTable = NewObject<UDataTable>();
//	DataTable->RowStruct = FP3CmsCombatHit::StaticStruct();
//
//	FARFilter Filter;
//	Filter.ClassNames.Add(UAnimMontage::StaticClass()->GetFName());
//	
//	TArray<FAssetData> AssetDataList;
//	AssetRegistry.GetAssets(Filter, AssetDataList);
//
//	for (const FAssetData& AssetData : AssetDataList)
//	{
//		UObject* Asset = AssetData.GetAsset();
//		if (!Asset)
//		{
//			continue;
//		}
//
//		UAnimMontage* AnimMontage = Cast<UAnimMontage>(Asset);
//		if (!AnimMontage)
//		{
//			continue;
//		}
//
//		UE_LOG(P3Log, Display, TEXT("Found UAnimMontage: %s (%d)"), *AssetData.AssetName.ToString(), AnimMontage->Notifies.Num());
//
//		FString MontageName = AssetData.AssetName.ToString();
//
//		int32 HitIndex = 0;
//		for (const FAnimNotifyEvent& NotifyEvent : AnimMontage->Notifies)
//		{
//			UAnimNotify_Hit* Notify = Cast<UAnimNotify_Hit>(NotifyEvent.Notify);
//			if (!Notify)
//			{
//				continue;
//			}
//
//			FP3CmsCombatHit Desc;
//			Desc.AttackDirection = Notify->AttackDirection;
//			Desc.bIsKnockDown = Notify->bIsKnockDown;
//			Desc.KnockBackStrength = Notify->KnockBackStrength;
//			Desc.bIsPushBack = Notify->bIsPushBack;
//			Desc.bIsBreakBlock = Notify->bIsBreakBlock;
//			Desc.bIsThrowForced = Notify->bIsThrowForced;
//			Desc.StumbleDurationSeconds = Notify->StumbleDurationSeconds;
//			Desc.AttackRange = Notify->AttackRange;
//			Desc.ConeHalfAngleDegree = Notify->ConeHalfAngleDegree;
//			Desc.ConeRotation = Notify->ConeRotation;
//			Desc.DamagePermil = Notify->DamagePermil;
//			Desc.SpawnActorClass = Notify->SpawnActorClass;
//
//			FName Key = FName(*FString::Printf(TEXT("%s_%d"), *MontageName, HitIndex));
//			DataTable->AddRow(Key, Desc);
//
//			Notify->CmsCombatHitKey = Key;
//			SaveAsset(Notify);
//
//			++HitIndex;
//		}
//	}
//
//	FString CSV = DataTable->GetTableAsCSV();
//	FString FilePath = FPaths::ProjectContentDir() / TEXT("CMS") / TEXT("CombatHits.csv");
//	FFileHelper::SaveStringToFile(CSV, *FilePath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM);
//}

void MigrateItems(IAssetRegistry& AssetRegistry)
{
	const FString ObjectName = "Items";
	const FString PackageName = FString::Printf(TEXT("/Game/CMS/%s"), *ObjectName);
	const FString AssetPath = FString::Printf(TEXT("%s.%s"), *PackageName, *ObjectName);
	UDataTable*  DataTable = LoadObject<UDataTable>(nullptr, *AssetPath);
	if (!ensure(DataTable))
	{
		return;
	}

	//UDataTable* DataTable = CreateDataTable("Items");
	//if (!DataTable)
	//{
	//	return;
	//}

	AssetRegistry.AssetCreated(DataTable);
	DataTable->RowStruct = FP3CmsItem::StaticStruct();

	UDataTable* HoldableDataTable = CreateDataTable("Holdables");
	if (!HoldableDataTable)
	{
		return;
	}

	AssetRegistry.AssetCreated(HoldableDataTable);
	HoldableDataTable->RowStruct = FP3CmsHoldable::StaticStruct();

	UDataTable* ConsumableDataTable = CreateDataTable("Consumables");
	if (!ConsumableDataTable)
	{
		return;
	}

	AssetRegistry.AssetCreated(ConsumableDataTable);
	ConsumableDataTable->RowStruct = FP3CmsConsumable::StaticStruct();

	UDataTable* ThrowableDataTable = CreateDataTable("Throwables");
	if (!ThrowableDataTable)
	{
		return;
	}

	AssetRegistry.AssetCreated(ThrowableDataTable);
	ThrowableDataTable->RowStruct = FP3CmsThrowable::StaticStruct();

	FARFilter Filter;
	Filter.ClassNames.Add(UBlueprint::StaticClass()->GetFName());
	Filter.ClassNames.Add(UBlueprintGeneratedClass::StaticClass()->GetFName());

	TArray<FAssetData> AssetDataList;
	AssetRegistry.GetAssets(Filter, AssetDataList);

	int32 ItemKey = 100; // Will be changed by hand
	int32 HoldableKey = 1;
	int32 ConsumableKey = 1;

	for (const FAssetData& AssetData : AssetDataList)
	{
		UObject* Asset = AssetData.GetAsset();
		if (!Asset)
		{
			continue;
		}

		UBlueprint* Blueprint = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), nullptr, *Asset->GetPathName()));
		if (!Blueprint || !Blueprint->GeneratedClass || !Blueprint->SimpleConstructionScript)
		{
			continue;
		}

		const TArray<USCS_Node*>& Nodes = Blueprint->SimpleConstructionScript->GetAllNodes();
		for (const USCS_Node* Node : Nodes) 
		{
			const bool bIsConsumable = Node->ComponentClass == UP3ConsumableComponent::StaticClass();
			const bool bIsHoldable = Node->ComponentClass == UP3HoldableComponent::StaticClass();
			const bool bIsPickupable = Node->ComponentClass == UP3PickupableComponent::StaticClass();
			const bool bIsIngredient = Node->ComponentClass == UP3IngredientComponent::StaticClass();

			//if (!bIsConsumable && !bIsHoldable && !bIsPickupable && !bIsIngredient)
			//{
			//	continue;
			//}

			// Migrate only pickupable this time
			if (!bIsPickupable)
			{
				continue;
			}

			UE_LOG(P3Log, Display, TEXT("Found Item Actor: %s"), *AssetData.AssetName.ToString());

			FP3CmsItem CmsItem;
			CmsItem.DisplayName = FText::FromName(AssetData.AssetName);
			CmsItem.ItemActorClass = Blueprint->GeneratedClass;
			CmsItem.bIsIngredient = bIsIngredient;

			//if (bIsHoldable)
			//{
			//	UP3HoldableComponent* HoldableComp = CastChecked<UP3HoldableComponent>(Node->ComponentTemplate);

			//	FP3CmsHoldable CmsHoldable;
			//	CmsHoldable.Name = CmsItem.Name;
			//	CmsHoldable.ItemKey = ItemKey;
			//	CmsHoldable.HoldTypes = HoldableComp->GetHoldTypes();
			//	CmsHoldable.WeaponType = HoldableComp->GetWeaponType();
			//	CmsHoldable.MaxUsableCountByPlayer = HoldableComp->GetMaxUsableCountByPlayer();
			//	CmsHoldable.ProjectileClass = HoldableComp->GetProjectileClass();
			//	CmsHoldable.MuzzleSocketName = HoldableComp->GetMuzzleSocketName();

			//	HoldableDataTable->AddRow(FName(*FString::FromInt(HoldableKey)), CmsHoldable);
			//	++HoldableKey;
			//}

			//if (bIsConsumable)
			//{
			//	UP3ConsumableComponent* ConsumableComp = CastChecked<UP3ConsumableComponent>(Node->ComponentTemplate);

			//	FP3CmsConsumable CmsConsumable;
			//	CmsConsumable.Name = CmsItem.Name;
			//	CmsConsumable.ItemKey = ItemKey;
			//	CmsConsumable.Icon = ConsumableComp->GetIcon();
			//	CmsConsumable.HealAmount = ConsumableComp->GetHealAmount();
			//	CmsConsumable.HealEffectParticle = ConsumableComp->GetHealEffectParticle();
			//	CmsConsumable.MaxStaminaAmount = ConsumableComp->GetMaxStaminaAmount();
			//	CmsConsumable.SpawnActorClass = ConsumableComp->GetSpawnActorClass();
			//	CmsConsumable.SpawnActorOffset = ConsumableComp->GetSpawnActorOffset();

			//	ConsumableDataTable->AddRow(FName(*FString::FromInt(ConsumableKey)), CmsConsumable);
			//	++ConsumableKey;

			//	CmsItem.Icon = ConsumableComp->GetIcon();
			//}

			if (bIsPickupable)
			{
				UP3PickupableComponent* PickupableComp = CastChecked<UP3PickupableComponent>(Node->ComponentTemplate);

				if (!PickupableComp->IsPickupToInventory())
				{
					continue;
				}
			}

			DataTable->AddRow(FName(*FString::FromInt(ItemKey)), CmsItem);
			++ItemKey;
		}
	}

	P3Commandlet::SaveAsset(DataTable);
	//P3Commandlet::SaveAsset(HoldableDataTable);
	//P3Commandlet::SaveAsset(ConsumableDataTable);
}
#endif

int32 UP3MigrateCmsTableCommandlet::Main(const FString& Params)
{
#if WITH_EDITOR
	// Load AssetRegistryModule
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	AssetRegistryModule.Get().SearchAllAssets(true);

	//MigrateCombatSkills(AssetRegistryModule.Get());
	//MigrateCombatHits(AssetRegistryModule.Get());
	MigrateItems(AssetRegistryModule.Get());
#endif // WITH_EDITOR

	return 0;
}
