// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#pragma once

#include "Commandlets/Commandlet.h"
#include "P3MigrateCmsTableCommandlet.generated.h"

UCLASS()
class UP3MigrateCmsTableCommandlet : public UCommandlet
{
	GENERATED_BODY()

public:
	virtual int32 Main(const FString& Params) override;
};

