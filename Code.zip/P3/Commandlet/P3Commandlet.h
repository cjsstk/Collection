// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"

namespace P3Commandlet
{
	bool SaveAsset(class UObject* Asset);

} // P3Commandlet
