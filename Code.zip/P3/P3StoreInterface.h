// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "P3StoreInterface.generated.h"

UINTERFACE(meta=( CannotImplementInterfaceInBlueprint ))
class UP3ComponentInterface : public UInterface
{
	GENERATED_UINTERFACE_BODY()
};

class IP3ComponentInterface
{
	GENERATED_IINTERFACE_BODY()

public:
	virtual void NetSerialize(FArchive& Archive) = 0;
	virtual bool IsNetSerializeDisabled() const { return false; }

	// TODO: maybe move to it's own interface?
	virtual void Server_BeginPlayP3World() {}

protected:
	virtual void Server_SetDirty(const UActorComponent& Self);
	int64 GetOwnerActorId(const UActorComponent& Self) const;
};
