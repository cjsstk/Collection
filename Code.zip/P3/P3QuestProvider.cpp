// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3QuestProvider.h"
#include "Components/ShapeComponent.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3Cms.h"
#include "P3QuestComponent.h"


void AP3QuestProvider::BeginPlay()
{
	Super::BeginPlay();

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	UShapeComponent* CollisionComp = GetCollisionComponent();

	if (!ensure(CollisionComp))
	{
		return;
	}

	OnActorBeginOverlap.AddUniqueDynamic(this, &AP3QuestProvider::OnActorOverlapped);

	TArray<AActor*> OverlappingActors;

	CollisionComp->GetOverlappingActors(OverlappingActors, TSubclassOf<AActor>());

	for (AActor* OverlappingActor : OverlappingActors)
	{
		OnActorOverlapped(GetOwner(), OverlappingActor);
	}
}

void AP3QuestProvider::OnActorOverlapped(AActor* OverlappedActor, AActor* OtherActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Quest)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(OtherActor);

	if (!Character)
	{
		return;
	}

	if (!Character->IsPlayerControlled())
	{
		return;
	}

	StartQuest(Character);
}

void AP3QuestProvider::StartQuest(AP3Character* Character)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(Quest))
	{
		return;
	}

	if (!ensure(Character))
	{
		return;
	}

	if (!ensure(Character->IsPlayerControlled()))
	{
		return;
	}

	UP3QuestComponent* QuestComp = Character->GetQuestComponent();
	if (!QuestComp)
	{
		return;
	}

	questkey QuestKey = P3Cms::GetQuestKeyFromQuestDesc(Quest);
	if (QuestKey == INVALID_QUESTKEY)
	{
		return;
	}

	QuestComp->Server_StartQuest(QuestKey);
}
