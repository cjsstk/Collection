// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3SpawnerOnHitComponent.h"

#include "Engine/World.h"
#include "Kismet/KismetMathLibrary.h"

#include "P3Character.h"
#include "P3Core.h"

UP3SpawnerOnHitComponent::UP3SpawnerOnHitComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UP3SpawnerOnHitComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AActor* OwnerActor = GetOwner();

		if (OwnerActor)
		{
			OwnerActor->OnActorHit.AddUniqueDynamic(this, &UP3SpawnerOnHitComponent::Server_OnActorHit);

			if (bOverlapWithLargeCharacter)
			{
				OwnerActor->OnActorBeginOverlap.AddUniqueDynamic(this, &UP3SpawnerOnHitComponent::Server_OnActorBeginOverlap);
			}
		}
	}
}

void UP3SpawnerOnHitComponent::Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_CooldownFinishTimeSeconds > 0.0f && GetWorld()->GetTimeSeconds() < Server_CooldownFinishTimeSeconds)
	{
		// Still in cooldown
		return;
	}

	const float NormalImpulseSizeSquared = NormalImpulse.SizeSquared();

	if (NormalImpulseSizeSquared > FMath::Square(HitImpulseSizeForSpawn))
	{
		Server_SpawnActor();

		if (bDestroyOwnerAfterSpawn && SelfActor)
		{
			ensure(GetOwner() == SelfActor);

			SelfActor->Destroy();
		}
	}
}

void UP3SpawnerOnHitComponent::Server_OnActorBeginOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(bOverlapWithLargeCharacter))
	{
		return;
	}

	if (Server_CooldownFinishTimeSeconds > 0.0f && GetWorld()->GetTimeSeconds() < Server_CooldownFinishTimeSeconds)
	{
		// Still in cooldown
		return;
	}

	AP3Character* Character = Cast<AP3Character>(OtherActor);

	if (!Character || !Character->IsLarge())
	{
		return;
	}

	// FIXME: maybe we need to consider impulse threshold using velocity and mass?

	Server_SpawnActor();

	if (bDestroyOwnerAfterSpawn && OverlappedActor)
	{
		ensure(GetOwner() == OverlappedActor);

		OverlappedActor->Destroy();
	}
}

void UP3SpawnerOnHitComponent::Server_SpawnActor()
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (!SpawnActorClass)
	{
		return;
	}

	AActor* Owner = GetOwner();
	if (!Owner)
	{
		return;
	}

	FTransform SpawnTransform = GetComponentTransform();
	FRotator Direction = UKismetMathLibrary::MakeRotFromX(Owner->GetVelocity());
	Direction.Pitch = 0;

	SpawnTransform.SetRotation(Direction.Quaternion());

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AActor* SpawnedActor = GetWorld()->SpawnActor(SpawnActorClass, &SpawnTransform, Params);

	if (SpawnCoolDownSeconds > 0.0f)
	{
		Server_CooldownFinishTimeSeconds = GetWorld()->GetTimeSeconds() + SpawnCoolDownSeconds;
	}
}
