// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3HoldableComponent.h"

#include "DrawDebugHelpers.h"

#include "Action/P3PickupAction.h"
#include "P3Character.h"
#include "P3Log.h"
#include "P3PickupComponent.h"
#include "P3Projectile.h"

static TAutoConsoleVariable<int32> CVarP3HoldableLockDebug(
	TEXT("p3.holdableLockDebug"),
	0,
	TEXT("1: enable debug. 0: disable dibug"), ECVF_Cheat);

UP3HoldableComponent::UP3HoldableComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3HoldableComponent::BeginPlay()
{
	Super::BeginPlay();

	//ensure(!GetOwner() || (GetOwner()->GetIsReplicated() && GetOwner()->bAlwaysRelevant));
}

void UP3HoldableComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

#if ENABLE_DRAW_DEBUG
	if (CVarP3HoldableLockDebug.GetValueOnGameThread() != 0)
	{
		const IP3ActorInterface* LockOwner = (LockerAction && LockerAction->GetOwnerActor()) ? Cast<IP3ActorInterface>(LockerAction->GetOwnerActor()) : nullptr;
		const int32 ActorId = LockOwner ? LockOwner->GetActorId() : 0;

		DrawDebugString(GetWorld(), GetOwner()->GetActorLocation(), FString::Printf(TEXT("Locked = %s, OwnerActorId = %d"),
			Server_bIsInteractionLocked ? TEXT("True") : TEXT("False"), ActorId), nullptr, FColor::White, 0.0f, true);
	}
#endif
}

void UP3HoldableComponent::SetHolderComponent(class UP3HolderComponent* InHolderComponent)
{
	HolderComponent = InHolderComponent;
}

void UP3HoldableComponent::Server_SetInteractionLock(class UP3PickupHoldablePawnAction* InLockerAction, bool bInInteractionLocked)
{
	/** Try to Lock this Component */
	if (bInInteractionLocked)
	{
		if (Server_IsInteractionLocked() || LockerAction)
		{
			ensure(0);
			return;
		}
		LockerAction = InLockerAction;
	}
	/** Try to Unlock this Component */
	else
	{
		if (!Server_IsInteractionLocked() || !LockerAction || LockerAction != InLockerAction)
		{
			ensure(0);
			return;
		}
		LockerAction = nullptr;
	}

	Server_bIsInteractionLocked = bInInteractionLocked;
}

bool P3GetMuzzleLocation(const AActor& WeaponActor, FVector& OutLocation)
{
	const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(WeaponActor.GetClass()));
	if (!CmsHoldable)
	{
		return false;
	}

	USkeletalMeshComponent* SkeletalMeshComp = WeaponActor.FindComponentByClass<USkeletalMeshComponent>();
	if (SkeletalMeshComp)
	{
		OutLocation = SkeletalMeshComp->GetSocketTransform(CmsHoldable->MuzzleSocketName).GetLocation();
		return true;
	}

	UStaticMeshComponent* StaticMeshComp = WeaponActor.FindComponentByClass<UStaticMeshComponent>();
	if (StaticMeshComp)
	{
		OutLocation = StaticMeshComp->GetSocketTransform(CmsHoldable->MuzzleSocketName).GetLocation();
		return true;
	}

	P3JsonLog(Warning, "No skeletal mesh component", TEXT("HoldingActor"), WeaponActor.GetName());

	return false;
}
