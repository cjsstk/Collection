// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3Actor.h"
#include "P3FoliageActor.generated.h"

UCLASS(ComponentWrapperClass)
class P3_API AP3FoliageActor : public AP3Actor
{
	GENERATED_BODY()
	
public:	
	AP3FoliageActor(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

private:
	UPROPERTY(VisibleDefaultsOnly, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"), Category = "Foliage")
	class UP3DestructibleComponent* DestructibleComponent;
};
