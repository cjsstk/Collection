// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameplayTagContainer.h"
#include "P3SurpriseMeteorComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3SurpriseMeteorComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3SurpriseMeteorComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void Server_TickSpawnMeteor(float DeltaTime);

	bool CanSpawnMeteor() const;
	float GetNewCoolDown() const;

protected:
	virtual void BeginPlay() override;

private:

	float Server_LeftCoolDownTimeSeconds = 0.0f;

	UPROPERTY(EditDefaultsOnly)
	float MinMeteorCoolDown = 0.0f;

	UPROPERTY(EditDefaultsOnly)
	float MaxMeteorCoolDown = 0.0f;

	UPROPERTY(EditDefaultsOnly)
	float SpawnMeteorPercent = 100.0f;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class AActor> MeteorSpawnerClass;

	/**
	 * If set, owner character must has any of this gameplaytag to use this SurpriseMeteor
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer RequiredGameplayTagsAny;

	/**
	 * If set and owner character has any of this gameplaytag, SurpriseMeteor is not available
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer DisableGameplaytagsAny;

};
