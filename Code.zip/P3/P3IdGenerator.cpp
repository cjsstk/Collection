// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3IdGenerator.h"

#include "P3Log.h"

static const int32 TotalBits = 64;
static const int32 TimestampBits = 40;  // Almost 35 year
static const int32 MachineBits = 14;    // 16384
static const int32 SequenceBits = 10;   // 1024
static const int32 MaxSequence = 0x3FF; // 2^SequenceBits - 1 == 1023
static const int64 BaseEpochTicks = FDateTime(2019, 5, 27).GetTicks();

void FP3IdGenerator::InitGenerator(uint64 InMachineId)
{
	MachineId = InMachineId;
}

bool FP3IdGenerator::IsInitialized() const
{
	return MachineId > 0;
}

uint64 FP3IdGenerator::Generate(bool bCheckMarchineId)
{
	if (bCheckMarchineId && !ensure(MachineId > 0))
	{
		P3JsonLog(Error, "Invalid machine id", TEXT("MachineId"), UINT64_TO_STR(MachineId));
		return 0;
	}

	uint64 Timestamp = GetCurrentTimestamp();
	if (!ensure(Timestamp >= LastTimestamp))
	{
		P3JsonLog(Error, "Invalid timestamp", TEXT("MachineId"), UINT64_TO_STR(MachineId));
		return 0;
	}
	
	uint64 Seq = 0;
	if (Timestamp == LastTimestamp)
	{
		if (LastSeq < MaxSequence)
		{
			Seq = LastSeq + 1;
		}
		else
		{
			P3JsonLog(Error, "The sequence number has reached maximum number", TEXT("MachineId"), UINT64_TO_STR(MachineId));
			while (Timestamp == LastTimestamp)
			{
				Timestamp = GetCurrentTimestamp();
			}
		}
	}

	LastTimestamp = Timestamp;
	LastSeq = Seq;

	return Timestamp << (MachineBits + SequenceBits) | MachineId << SequenceBits | Seq;
}

uint64 FP3IdGenerator::GetCurrentTimestamp() const
{
	ensure(FDateTime::UtcNow().GetTicks() > BaseEpochTicks);
	const uint64 Timestamp = (uint64)((FDateTime::UtcNow().GetTicks() - BaseEpochTicks) / ETimespan::TicksPerMillisecond);
	ensure(Timestamp < ((uint64)1 << TimestampBits));
	return Timestamp;
}