// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameplayTagContainer.h"
#include "P3StoreInterface.h"
#include "P3TemporaryWeaponType.h"
#include "P3PartComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnPartBroken, class UP3PartComponent*, PartComponent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnPartCombatDamage, FVector, HitLocation);

USTRUCT(Blueprintable)
struct FP3CharacterPartDesc
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly)
	FName PartName;

	/** Which bones can be count as this part on combat hit? */
	UPROPERTY(EditDefaultsOnly)
	TArray<FName> HitAreaBones;

	/** Is this weak point? which makes hit as critical? (shows as yellow damage font) If it is, better set DamageMultiplier > 1 */
	UPROPERTY(EditDefaultsOnly)
	bool bIsCriticalHit = false;

	/** Is this strong point? which makes hit as armored? (shows as gray damage font) If it is, better set DamageMultiplier < 1 */
	UPROPERTY(EditDefaultsOnly)
	bool bIsArmor = false;

	/** If true, this part takes damage ignoring armor class(attribute) */
	UPROPERTY(EditDefaultsOnly)
	bool bTakeDamageIgnoringArmor = false;

	/** This will be multiplied to each hit damage amount */
	UPROPERTY(EditDefaultsOnly)
	float DamageMultiplier = 1.0f;

	/** [0 ~ 1000] 1000 means 100% of HP. If not 0, part has it's own HP and if that become 0, it broke */
	UPROPERTY(EditDefaultsOnly)
	int32 HealthPointPermil = 0;

	/** If set > 0, broken part will be repaired after this time */
	UPROPERTY(EditDefaultsOnly)
	float AutoRepairTimeSeconds = 0;

	/** If set > 0, part will be restored at every this time seconds */
	UPROPERTY(EditDefaultsOnly)
	float RestoreTickSeconds = 0.0f;

	/** If set > 0, part will be restored every RestoreTickSeconds this much */
	UPROPERTY(EditDefaultsOnly)
	int32 RestoreHealthPointAmount = 5;

	/** If set false, arrows or javlins are not allowed to pierce and stuck */
	UPROPERTY(EditDefaultsOnly)
	bool bPenetrable = true;

	/** If part become broken, this gameplay tag will be added to character */
	UPROPERTY(EditDefaultsOnly)
	FGameplayTagContainer GameplayTagOnBroken;

	/** If part become broken, mountPoints that has this Tag will disable */
	UPROPERTY(EditDefaultsOnly)
	FGameplayTagContainer DisableMountPointGameplayTagOnBroken;

	/** If part become broken, these bones are ignored on bone attack  */
	UPROPERTY(EditDefaultsOnly)
	TArray<FName> DisableBoneNamesOnPartBroken;
};


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3PartComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3PartComponent();

	const FP3CharacterPartDesc& GetPartDesc() const { return PartDesc; }

	int32 Server_GetHealthPoint() const { return Server_HealthPoint; }
	void Server_SetHealthPoint(int32 InHealthPoint);

	UFUNCTION(BlueprintCallable)
	const FVector& Server_GetLastHitDirection() const { return Server_LastHitDirection; }

	UFUNCTION(BlueprintCallable)
	bool IsPartBroken() const { return Net_bBroken; }

	bool IsPartActivated() const { return Net_bActivated; }

	bool IsDamagedAnyTypesOnly() const { return bOnlyDamagedByTemporaryWeapons; }
	bool CanBeDamagedByTemporaryWeaponType(EP3TemporaryWeaponType WeaponType) const;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;
	
	void OnPartDamaged(const FVector& HitLocation, const FVector& ImpactDirection);

	UFUNCTION(BlueprintCallable)
	void Server_ActivatePart();

	UFUNCTION(BlueprintCallable)
	void Server_DeactivatePart();

protected:
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private: 
	void Server_SetBroken(bool bNewBroken);
	void OnBrokenStatusChanged();
	void UpdateMesh();

	/** Update max hp from attribute */
	void Server_InitHealthPoint();

public:
	UPROPERTY(BlueprintAssignable)
	FP3OnPartBroken OnPartBroken;

	UPROPERTY(BlueprintAssignable)
	FP3OnPartCombatDamage OnPartCombatDamaged;

private:

	UPROPERTY(EditDefaultsOnly)
	FP3CharacterPartDesc PartDesc;

	UPROPERTY(EditDefaultsOnly)
	class USkeletalMesh* DefaultSkeletalMesh;

	/** If set 2, each mesh will be used for HP 33~66, 1~33 (DefaultSkeletalMesh will be used for 67~100, BrokenSkeletalMesh will be used for 0 */
	UPROPERTY(EditDefaultsOnly)
	TArray<class USkeletalMesh*> DamagedSkeltalMeshes;

	UPROPERTY(EditDefaultsOnly)
	class USkeletalMesh* BrokenSkeletalMesh;

	/** If set, skeletal mesh will use character's skeleton as master */
	UPROPERTY(EditDefaultsOnly)
	bool bUseCharacterAsMasterSkeleton = true;

	/** If true, this part damaged by CanBeDamagedTemporaryWeaponTypes only */
	UPROPERTY(EditDefaultsOnly)
	bool bOnlyDamagedByTemporaryWeapons = false;

	UPROPERTY(EditDefaultsOnly, meta = (EditCondition = "bOnlyDamagedByTemporaryWeapons"))
	TSet<EP3TemporaryWeaponType> CanBeDamagedTemporaryWeaponTypes;

	UPROPERTY(Transient)
	class USkeletalMeshComponent* SkeletalMeshComponent;

	int32 Server_MaxHealthPoint = 0;
	int32 Server_HealthPoint = 0;
	float Server_RepairTimeSeconds = 0;
	float Server_RestoreTickAgeSeconds = 0;

	bool Net_bBroken = false;

	/** -1 means Default mesh */
	int32 Net_DamagedMeshIndex = -1;

	UPROPERTY(Transient)
	FVector Server_LastHitDirection = FVector::ZeroVector;

	/** Deactivated part doesn't take damage */
	UPROPERTY(EditDefaultsOnly)
	bool bActivatePartOnBegin = true;

	/** If false, this part doesn't take damage */
	bool Net_bActivated = true;
};
