// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Volume.h"
#include "P3FarSightVolume.generated.h"

UCLASS(Blueprintable)
class P3_API AP3FarSightVolume : public AVolume
{
	GENERATED_BODY()
	
protected:
	virtual void NotifyActorBeginOverlap(AActor* OtherActor) override;
	virtual void NotifyActorEndOverlap(AActor* OtherActor) override;
};
