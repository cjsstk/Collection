// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Core.h"
#include "P3Part.h"

#include "Components/ActorComponent.h"
#include "P3EquipmentComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class P3_API UP3EquipmentComponent : public UActorComponent
{
	GENERATED_BODY()

public:		
	UP3EquipmentComponent();

	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void AddPart(const TArray<class AP3Part*>& InPartsRef);
	const class AP3Part* AddPart(class AP3Part* InPart);
	const class AP3Part* RemovePart(const class AP3Part* InPart);
	
	void StartPart(int32 TypeIndex);
	void StopPart(int32 TypeIndex);
	void StopPartInterrupt(int32 TypeIndex);

	bool Server_CanPartStart(int32 TypeIndex) const;
	bool CanPartFlags(EP3PartType Type, int32 Flag) const;

protected:	
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	void Server_TickComponent();
	bool IsValidPartType(EP3PartType PartType) const;
	
	UPROPERTY()
	TMap<EP3PartType,class AP3Part*> Parts;

	UPROPERTY()
	class AP3Character* Character = nullptr;

	UFUNCTION()
	void OnStartMobilePart();

	UFUNCTION()
	void OnStopMobilePart();
};
