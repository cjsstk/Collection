// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "P3GameState.generated.h"

/** 
 * Surface effect
 */
USTRUCT(Blueprintable)
struct FP3SurfaceEffect
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly)
	TEnumAsByte<EPhysicalSurface> SurfaceType = SurfaceType_Default;

	UPROPERTY(EditDefaultsOnly)
	class UParticleSystem* Particle;

	UPROPERTY(EditDefaultsOnly)
	float ParticleScale = 1.0f;

	/** If speed of contact point is higher than this, spawn particle effect */
	UPROPERTY(EditDefaultsOnly)
	float SpawnParticleMinSpeed = 50.0f;

	/** Particle will spawn for every this seconds */
	UPROPERTY(EditDefaultsOnly)
	float ParticleSpawnPeriodSeconds = 0.2f;

	/** 표면에서 미끄러지는 경우 */
	UPROPERTY(EditDefaultsOnly)
	bool bOnSlip = false;
};


/**
 * Game Resource
 */
UCLASS(Blueprintable)
class UP3GameResource : public UObject
{
	GENERATED_BODY()

public:

	/** Default particle effect that will show on loot-able items */
	UPROPERTY(EditDefaultsOnly, Category = Loot)
	class UParticleSystem* LootEffectParticle;

	/** Default particle effect that will show on hitting non-combat object */
	UPROPERTY(EditDefaultsOnly, Category = Loot)
	class UParticleSystem* HitObjectParticle;

	UPROPERTY(EditDefaultsOnly, Category = BGM)
	TArray<class USoundBase*> BGMList;

	UPROPERTY(EditDefaultsOnly, Category = BGM)
	TArray<class USoundBase*> BossBattleBGMList;

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	UStaticMesh* MinimapLocalPlayerIconMesh;

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	UMaterialInterface* MinimapLocalPlayerIconMaterial;

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	FVector MinimapLocalPlayerIconScale = FVector(4.0f, 8.0f, 8.0f);

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	UStaticMesh* MinimapPlayerIconMesh;

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	UMaterialInterface* MinimapPlayerIconMaterial;

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	FVector MinimapPlayerIconScale = FVector(1.5f, 3.0f, 3.0f);

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	UStaticMesh* MinimapDownedPlayerIconMesh;

	UPROPERTY(EditDefaultsOnly, Category = Minimap)
	UMaterialInterface* MinimapDownedPlayerIconMaterial;

	UPROPERTY(EditDefaultsOnly, Category = "Surface")
	TArray<FP3SurfaceEffect> SurfaceEffects;
};

/**
 * P3 Item package
 * defines package of items
 */
UCLASS(BlueprintType)
class UP3ItemPackage : public UDataAsset
{
	GENERATED_BODY()

public:
	/** [ItemKey, NumItems] When player click button, their inventory will be filled with these items (to help test play) */
	UPROPERTY(EditDefaultsOnly, Category = "Package")
	TMap<int32, int32> PackagedItems;
};

/**
 * P3 Game Rule
 * defines rules of game worlds
 */
UCLASS(BlueprintType)
class UP3GameRule : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "Temperature")
	float DefaultTemperature = 20.0f;

	/** Characters that feels hot will get these buffs */
	UPROPERTY(EditDefaultsOnly, Category = "Temperature")
	TArray<int32> DefaultCharacterHotBuffs;

	/** Characters that feels cold will get these buffs */
	UPROPERTY(EditDefaultsOnly, Category = "Temperature")
	TArray<int32> DefaultCharacterColdBuffs;

	/** [ItemKey, NumItems] When player logs in, their inventory will be filled with these items (to help test play) */
	UPROPERTY(EditDefaultsOnly, Category = "Temperature")
	TMap<int32, int32> DefaultInventoryItems;

	/** Acceptable character's falling time seconds, -1 means character can fall infinitely */
	UPROPERTY(EditDefaultsOnly, Category = "Character Movement: Falling", meta = (ClampMin = "-1", UIMin = "-1"))
	float AcceptableFallingTimeSeconds = 20.0f;
};

/**
 * Game State
 */
UCLASS()
class P3_API AP3GameState : public AGameStateBase
{
	GENERATED_BODY()

public:
	AP3GameState();

	virtual void HandleBeginPlay() override;
	virtual void OnRep_ReplicatedHasBegunPlay() override;

	const UP3GameResource* GetGameResource() const { return GameResource; }
	class AP3WorldParticleActor* GetWorldParticleActor() const { return WorldParticleActor; }
	const UP3GameRule& GetGameRule() const;

	UFUNCTION(BlueprintCallable)
	const TArray<UP3ItemPackage*> GetItemPackages() const { return ItemPackages; }

	UFUNCTION(BlueprintImplementableEvent, Category = Combat)
	float RollDice_CalcDamage(const AActor* Source, const AActor* Target, bool bIgnoreArmor);

private:
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TSubclassOf<UP3GameResource> GameResourceClass = UP3GameResource::StaticClass();

	UPROPERTY(Transient)
	UP3GameResource* GameResource;

	UPROPERTY(Transient)
	class AP3WorldParticleActor* WorldParticleActor = nullptr;

	UPROPERTY(EditDefaultsOnly)
	UP3GameRule* GameRule;

	UPROPERTY(EditDefaultsOnly)
	TArray<UP3ItemPackage*> ItemPackages;
};

UCLASS()
class P3_API AP3WorldParticleActor : public AActor
{
	GENERATED_BODY()

public:
	AP3WorldParticleActor();

	virtual void Tick(float DeltaSeconds) override;

private:
	UPROPERTY(Transient)
	USceneComponent* RootSceneComponent = nullptr;

	UPROPERTY(Transient)
	TMap<class UParticleSystemComponent*, float> DeactivatedParticles;
};
