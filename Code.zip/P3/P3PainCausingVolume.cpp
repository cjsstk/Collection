// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PainCausingVolume.h"

#include "TimerManager.h"
#include "GameFramework/Pawn.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "P3Log.h"

void AP3PainCausingVolume::ActorEnteredVolume(class AActor* Other)
{
	Super::ActorEnteredVolume(Other);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (bEntryPain)
		{
			Server_CausePainTo(Other);
		}

		// Start timer if none is active
		if (!GetWorldTimerManager().IsTimerActive(Server_PainTimerHandle))
		{
			GetWorldTimerManager().SetTimer(Server_PainTimerHandle, this, &AP3PainCausingVolume::Server_PainTimer, PainInterval, true);
		}
	}
}

void AP3PainCausingVolume::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
	
	GetWorldTimerManager().ClearTimer(Server_PainTimerHandle);
}

void AP3PainCausingVolume::Server_PainTimer()
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	TSet<AActor*> TouchingActors;
	GetOverlappingActors(TouchingActors, APawn::StaticClass());

	for (AActor* const A : TouchingActors)
	{
		if (A &&!A->IsPendingKill())
		{
			// Only Pawn supports physics volume
			APawn* PawnA = Cast<APawn>(A);
			if (PawnA && PawnA->GetPawnPhysicsVolume() == this)
			{
				Server_CausePainTo(A);
			}
		}
	}

	// Stop timer if nothing is overlapping us
	if (TouchingActors.Num() == 0)
	{
		GetWorldTimerManager().ClearTimer(Server_PainTimerHandle);
	}
}

void AP3PainCausingVolume::Server_CausePainTo(class AActor* Other)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	UP3PawnActionComponent * ActionComp = Other->FindComponentByClass<UP3PawnActionComponent>();
	if (ActionComp)
	{
		FP3PawnActionStartRequestParams HitParams;
		HitParams.CombatHit_Damage = PainAmount;
		HitParams.CombatHit_SourceActor = GetOwner();

		ActionComp->StartAction(EPawnActionType::CombatHit, _FUNCTION_TEXT, HitParams);
	}
}
