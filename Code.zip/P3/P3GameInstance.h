// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "Engine/GameInstance.h"
#include "Network/P3WebServer.h"
#include "P3Core.h"
#include "P3IdGenerator.h"
#include "P3Version.h"
#include "Party/P3PartyManager.h"
#include "P3GameInstance.generated.h"

UCLASS()
class UP3GameInstance : public UGameInstance
{
	GENERATED_BODY()

public:
	UP3GameInstance(const FObjectInitializer& ObjectInitializer);

#if WITH_EDITOR
	virtual FGameInstancePIEResult InitializeForPlayInEditor(int32 PIEInstanceIndex, const FGameInstancePIEParameters& Params) override;
#endif

	virtual void Init() override;
	virtual void Shutdown() override;

	UFUNCTION(BlueprintPure)
	const FP3Version& GetVersion() const { return Version; }

	UFUNCTION(BlueprintPure)
	const FP3Version& GetServerVersion() const { return ServerVersion; }

	void SetServerVersion(const FP3Version& InServerVersion) { ServerVersion = InServerVersion; }

	class UP3Net* GetNet() const;
	class UP3AuthNet* GetAuthNet() const;
	class UP3ChatNet* GetChatNet() const;
	class UP3GoChatNet* GetGoChatNet() const { return GoChatNet; }
	class UP3DediNet* GetDediNet() const;
	class UP3PlayerNet* GetPlayerNet() const;
	class UP3GameWorldNet* GetGameWorldNet() const;
	class UP3WorldNetBase* GetWorldNet() const;
	class UP3DedimanHelper* GetDedimanHelper() const;
	class UP3WebServer* GetWebServer() const;
	class UP3UDPNetwork* GetUDPNetwork() const;
	class UP3ItemManager* GetItemManager() const;
	class UP3World* GetP3World() const { return World; }
	class UWorld* GetCurrentWorld() const;
	FP3PartyManager& GetPartyManager() { return PartyManager; }

	EP3NetMode GetGameNetMode() const { return GameNetMode; }

	FP3IdGenerator& GetItemIdGenerator() { return ItemIdGenerator; }

	void SetAccountName(const FString& InAccountName) { AccountName = InAccountName; }
	const FString& GetAccountName() const { return AccountName; }

	void SetAuthToken(const FString& InAuthToken) { AuthToken = InAuthToken; }
	const FString& GetAuthToken() const { return AuthToken; }

	void SetCharacterId(charid InCharacterId) { CharacterId = InCharacterId; }
	charid GetCharacterId() const { return CharacterId; }

	void SetCharacterName(const FString& InCharacterName);
	const FString& GetCharacterName() const { return CharacterName; }

	const TArray<FName>& GetEditorSteramingLevelPackageNames() const { return EditorSteramingLevelPackageNames; }

	void ForceTickNet(float DeltaSeconds);

	const FString& GetConfigPath() const { return ConfigPath; }

private:
	UPROPERTY()
	class UP3Net* Net = nullptr;

	UPROPERTY()
	class UP3AuthNet* AuthNet = nullptr;

	UPROPERTY()
	class UP3ChatNet* ChatNet = nullptr;

	UPROPERTY()
	class UP3GoChatNet* GoChatNet = nullptr;

	UPROPERTY()
	class UP3DediNet* DediNet = nullptr;

	UPROPERTY()
	class UP3PlayerNet* PlayerNet = nullptr;

	UPROPERTY()
	class UP3GameWorldNet* GameWorldNet = nullptr;

	UPROPERTY()
	class UP3WorldNetBase* WorldNet = nullptr;

	UPROPERTY()
	class UP3DedimanHelper* DedimanHelper = nullptr;

	UPROPERTY()
	class UP3WebServer* WebServer = nullptr;

	UPROPERTY()
	class UP3UDPNetwork* UDPNetwork = nullptr;

	UPROPERTY()
	class UP3ItemManager* ItemManager = nullptr;

	UPROPERTY()
	class UP3World* World = nullptr;

	class FP3NetTick* NetTick = nullptr;

	FP3PartyManager PartyManager;

	/** Version */
	FP3Version Version;
	FP3Version ServerVersion;

	/** Login name or computer name in non-login mode */
	FString AccountName;

	/** Auth token from login */
	FString AuthToken;

	/** User selected character id */
	charid CharacterId;

	/** User selected character name */
	FString CharacterName;

	// Temporary net mode for transition
	EP3NetMode GameNetMode = EP3NetMode::MAX;

	/** We need to keep loaded level names so that PIE can use it */
	TArray<FName> EditorSteramingLevelPackageNames;

	/** Id Generators */
	FP3IdGenerator ItemIdGenerator;

	/** P3 config file path */
	FString ConfigPath;
};

class UP3AuthNet* P3GetAuthNet(const UObject* Object);
class UP3ChatNet* P3GetChatNet(const UObject* Object);
class UP3GoChatNet* P3GetGoChatNet(const UObject* Object);
class UP3DediNet* P3GetDediNet(const UObject* Object);
class UP3PlayerNet* P3GetPlayerNet(const UObject* Object);
class UP3WorldNetBase* P3GetWorldNet(const UObject* Object);
class UP3GameWorldNet* P3GetGameWorldNet(const UObject* Object);
class UP3DedimanHelper* P3GetDedimanHelper(const UObject* Object);
class UP3WebServer* P3GetWebServer(const UObject* Object);
class UP3UDPNetwork* P3GetUDPNetwork(const UObject* Object);
class FP3IdGenerator* P3GetItemIdGenerator(const UObject* Object);
FP3Version P3GetVersion(const UObject* Object);
