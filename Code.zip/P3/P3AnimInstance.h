// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "P3CharacterEmoteAnimation.h"
#include "P3CharacterStance.h"
#include "P3PickupableType.h"
#include "P3AnimInstance.generated.h"

extern TAutoConsoleVariable<int32> CVarP3EnableLookIK;

/**
 * P3 Anim Instance
 */
UCLASS()
class P3_API UP3AnimInstance : public UAnimInstance
{
	GENERATED_BODY()

public:
	bool IsPlayingTurnAnimation() const { return bPlayingTurnAnimation; }
	float GetTurnAnimationRotationDegreePerSecond() const { return TurnAnimationRotationDegreePerSecond; }
	
	/** Snapshot */
	void AddSnapshot(const FName& SnapshotName);
	void RemoveSnapshot(const FName& SnapshotName);
	
	UFUNCTION(BlueprintCallable)
	bool HasSnapshot(const FName SnapshotName) const;

	/** PoseAsset */
	void SetPoseAsset(const FName& PoseName, float Weight);
	void SetPoseAssetAlpha(float Alpha);

	UFUNCTION(BlueprintCallable)
	float GetPoseAssetWeight(const FName PoseName) const;

	UFUNCTION(BlueprintCallable)
	float GetPoseAssetAlpha() const;

	/** CCD */
	void SetCCDAlpha(const FName& CCDName, float Alpha);
	void SetCCDEffectLocation(const FName& CCDName, const FVector& EffectLocation);
	void ClearCCDEffectLocation();

	UFUNCTION(BlueprintCallable)
	float GetCCDAlpha(const FName CCDName) const;

	UFUNCTION(BlueprintCallable)
	FVector GetCCDEffectLocation(const FName CCDName) const;

protected:
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;
	virtual void NativeBeginPlay() override;

	UFUNCTION(BlueprintCallable)
	void OnTurnAnimationStarted();

	UFUNCTION(BlueprintCallable)
	void OnTurnAnimationFinished();
	
	 /** Aimoffset animation Index */
	UFUNCTION(BlueprintCallable)
	int32 GetAimOffsetAnimationIndex() const;

	 /** BlendSpeace combat run animation Index */
	UFUNCTION(BlueprintCallable)
	int32 GetCombatRunBlendSpeaceIndex() const;

	/** Aimoffset shake local offset vector */
	UFUNCTION(BlueprintCallable)
	const FVector2D GetAimOffset(float Scale = 1.f) const;	

private:
	void TickCharacter(class AP3Character* Character);
	void TickTurnAnimation(float DeltaSeconds, class AP3Character* Character);
	void ConsiderTurnAnimation(float DeltaSeconds);
	void TickPickupArmIK(float DeltaSeconds);

	/**
	 * Config
	 */
	UPROPERTY(EditDefaultsOnly, Category = ConfigToggleFeatures)
	bool bUseTurnAnimation = false;

	UPROPERTY(EditDefaultsOnly, Category = ConfigToggleFeatures)
	float CombatIdleDurationSeconds = 5.0f;

	/**
	 * System
	 */
	UPROPERTY(BlueprintReadOnly, Category = System, meta = (AllowPrivateAccess = "true"))
	bool bIsDedicatedServer = false;

	/**
	 * Turn animations
	 */
	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_L45;

	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_L90;

	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_L135;

	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_L180;

	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_R45;

	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_R90;

	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_R135;

	UPROPERTY(EditDefaultsOnly, Category = ConfigAnims)
	UAnimSequenceBase* AnimSequence_Turn_R180;

	/** 
	 * Runtime turn-animation states
	 */
	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bStartTurnAnimation = false;

	UPROPERTY(Transient, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	float SelectedTurnAnimPlayRate = 1;

	UPROPERTY(Transient, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	UAnimSequenceBase* SelectedTurnAnimSequence;

	bool bPlayingTurnAnimation = false;
	float TurnAnimationRotationDegreePerSecond = 0;

	/** Since current aproach is rely on Anim BP Node event, which seems not as perfect as expected, we need some kind of time out of turn anim request */
	float TurnAnimEstimatedFinishTimeSeconds = 0;

	/**
	 * Runtime states
	 */
	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	EP3CharacterStance Stance = EP3CharacterStance::Idle;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	EP3PickupableType PickupableType = EP3PickupableType::None;

	/** Since become suddenly idle by just putting weapon away is kind of awkward. We keep use combat idle for a while */
	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bUseCombatIdle = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bEntangled = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bRoarStunned = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bStunned = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bInSwamp = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bStumbling = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bIsInCombatStance = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	int32 CombatRunBlendSpeaceIndex = 0;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bIsItemThrowAiming = false;

	/**
	 * Pickup arm IK
	 */
	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	float PickupArmIKRightHandAlpha = 0.0f;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	float PickupArmIKLeftHandAlpha = 0.0f;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	FVector PickupArmIKRightHandEffectorLocation = FVector::ZeroVector;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	FVector PickupArmIKLeftHandEffectorLocation = FVector::ZeroVector;

	/** 
	 * Need to change to combat stance node?
	 * (Combat stance || Draw weapon Action) && !Put away weapon Action 
	 */
	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bPlayCombatStanceAnim = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	bool bHasValidLookAtTarget = false;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	FVector LookAtTargetLocation = FVector::ZeroVector;

	UPROPERTY(Transient)
	class UP3LookIK* LookIK;

	/** Snapshot */
	TSet<FName> PoseSnapshot;

	/** PoseAsset */	
	TMap<FName, float> PoseAsset;	
	float PoseAssetAlpha = 0.f;
	
	/** CCD */
	TMap<FName, float> CCDAlpha;
	TMap<FName, FVector> CCDEffectLocation;

	float LastCombatStanceTimeSeconds = 0;
};


UCLASS(BlueprintType)
class P3_API UP3OrcAnimSequnceData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(BlueprintReadOnly)
	class UAnimSequenceBase* EmoteStart;

	UPROPERTY(BlueprintReadOnly)
	class UAnimSequenceBase* EmoteLoop;

	UPROPERTY(BlueprintReadOnly)
	class UAnimSequenceBase* EmoteEnd;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UBlendSpaceBase* IdleRunBS;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UBlendSpaceBase* CombatRunBS;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UBlendSpaceBase* CombatWalks8WayBS;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* Dead;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* KnockDowned;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* TurnL;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* TurnR;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* Blocking;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* RagdollStart;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* RagdollEnd;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	class UAnimSequenceBase* Burning;
};

/**
 * P3 Orc Anim Instance
 */
UCLASS()
class P3_API UP3OrcAnimInstance : public UP3AnimInstance
{
	GENERATED_BODY()

public:
	virtual void NativeInitializeAnimation() override;
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

	UPROPERTY(EditDefaultsOnly)
	UP3OrcAnimSequnceData* DefaultAnimSequenceSet;

	UPROPERTY(EditDefaultsOnly)
	UP3OrcAnimSequnceData* FistAnimSequenceSet;

	UPROPERTY(Transient, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	UP3OrcAnimSequnceData* AnimSequenceSet;

	UPROPERTY(Transient, BlueprintReadOnly)
	FP3CharacterEmoteAnimation EmoteAnim;
};
