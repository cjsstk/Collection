// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

struct FP3PlatformMisc
{
private:
	FP3PlatformMisc() = delete;

public:
	static void SetConsoleWindowTitle(const TCHAR* Title);
};
