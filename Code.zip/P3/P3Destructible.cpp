// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Destructible.h"

#include "Components/StaticMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "DestructibleActor.h"
#include "DestructibleComponent.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"

#include "Chemical/P3Chemical.h"
#include "Chemical/P3FlammableComponent.h"
#include "P3BlueprintFunctionLibrary.h"
#include "P3Combat.h"
#include "P3Core.h"
#include "P3HealthPointComponent.h"
#include "P3Physics.h"
#include "P3PickupableComponent.h"
#include "P3PointOfInterest.h"
#include "P3Projectile.h"
#include "P3World.h"
#include "P3WorldNetCore.h"

#include "PhysXPublic.h"

TAutoConsoleVariable<int32> CVarP3DestructibleUseSleep(
	TEXT("p3.destructibleUseSleep"),
	0,
	TEXT("1: use sleep, 0: no sleep. Using sleep can lower CPU usage both client and server"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3DestructibleFallingDurationSeconds(
	TEXT("p3.destructibleFallingDurationSeconds"),
	10.0f,
	TEXT("Debris will fall through for this time"), ECVF_Cheat);

AP3Destructible::AP3Destructible()
{
	// We need to tick only after explosion
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;

	StaticMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StaticMeshComponent"));
	StaticMeshComponent->SetCollisionProfileName(UCollisionProfile::BlockAllDynamic_ProfileName);
	StaticMeshComponent->SetCollisionObjectType(ECC_Destructible);
	StaticMeshComponent->Mobility = EComponentMobility::Movable;
	StaticMeshComponent->SetGenerateOverlapEvents(true);
	StaticMeshComponent->bUseDefaultCollision = false;
	StaticMeshComponent->SetSimulatePhysics(true);
	StaticMeshComponent->GetBodyInstance()->bNotifyRigidBodyCollision = true;

	RootComponent = StaticMeshComponent;
}

void AP3Destructible::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	if (bStatic)
	{
		//SetReplicateMovement(false);
		StaticMeshComponent->SetSimulatePhysics(false);
	}
}

void AP3Destructible::BeginPlay()
{
	Super::BeginPlay();

	StaticMeshComponent->SetStaticMesh(StaticMesh);
	StaticMeshComponent->SetUseCCD(true);

	for (int32 Index = 0; Index < Materials.Num(); ++Index)
	{
		StaticMeshComponent->SetMaterial(Index, Materials[Index]);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (HealthPoint > 0 && bEnableDestruction)
		{
			Server_CreateHealthPointComponent();
		}

		Server_SetPOIOriginLocation(GetActorLocation());

		Server_SetSleep(true);
	}
}

void AP3Destructible::Server_SetSleep(bool bNewSleep)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (CVarP3DestructibleUseSleep.GetValueOnGameThread() == 0)
	{
		bNewSleep = false;
	}

	if (Net_bSleep == bNewSleep)
	{
		return;
	}

	Net_bSleep = bNewSleep;

	SleepChanged();

	Server_SetDirty(*this);
}

void AP3Destructible::SleepChanged()
{
	if (Net_bSleep)
	{
		TInlineComponentArray<UP3FlammableComponent*> FlammableComps;
		GetComponents(FlammableComps);

		for (UP3FlammableComponent* FlammableComp : FlammableComps)
		{
			FlammableComp->UnregisterComponent();
		}

		TInlineComponentArray<UP3HealthPointComponent*> HealthPointComps;
		GetComponents(HealthPointComps);

		for (UP3HealthPointComponent* HealthPointComp : HealthPointComps)
		{
			HealthPointComp->UnregisterComponent();
		}
	}
	else
	{
		TInlineComponentArray<UP3FlammableComponent*> FlammableComps;
		GetComponents(FlammableComps);

		for (UP3FlammableComponent* FlammableComp : FlammableComps)
		{
			FlammableComp->RegisterComponent();
		}

		TInlineComponentArray<UP3HealthPointComponent*> HealthPointComps;
		GetComponents(HealthPointComps);

		for (UP3HealthPointComponent* HealthPointComp : HealthPointComps)
		{
			HealthPointComp->RegisterComponent();
		}
	}
}

void AP3Destructible::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (DestructibleActor)
	{
		ExplodedAgeSeconds += DeltaTime;

		if (ExplodedAgeSeconds > DebrisLifespan)
		{
			DestructibleActor->GetDestructibleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			//DestructibleActor->AddActorWorldOffset(FVector(0, 0, DeltaTime * -100.0f));

			// Let debris fall through
			if (DestructibleActor->GetDestructibleComponent()
				&& DestructibleActor->GetDestructibleComponent()->GetBodyInstance())
			{
				FCollisionResponseContainer CollisionResponse;
				CollisionResponse.SetAllChannels(ECR_Ignore);

				//DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannels(CollisionResponse);

				DestructibleActor->GetDestructibleComponent()->SetCollisionResponseToAllChannels(ECR_Ignore);

#if WITH_APEX
				if (DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor)
				{
					FPhysScene* PhysScene = GetWorld()->GetPhysicsScene();
					PxScene* PScene = PhysScene->GetPxScene();

					SCOPED_SCENE_WRITE_LOCK(PScene);

					PxRigidDynamic** PActorBuffer = NULL;
					PxU32 PActorCount = 0;
					if (DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor->acquirePhysXActorBuffer(PActorBuffer, PActorCount))
					{
						for (uint32 ActorIdx = 0; ActorIdx < PActorCount; ++ActorIdx)
						{
							PxRigidDynamic* PActor = PActorBuffer[ActorIdx];
							if (FApexDestructionCustomPayload* ChunkInfo = (FApexDestructionCustomPayload*)FPhysxUserData::Get<FCustomPhysXPayload>(PActor->userData))	 // -V1027
							{
								DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor->setChunkPhysXActorAwakeState(ChunkInfo->ChunkIndex, true);
							}
						}
						DestructibleActor->GetDestructibleComponent()->ApexDestructibleActor->releasePhysXActorBuffer();
					}
				}
#endif
			}
		}
	}
	else if (Server_bExploded)
	{
		Destroy();
	}
}

void AP3Destructible::Server_SetPOIOriginLocation(const FVector& Location)
{
	Server_POIOriginLocation = Location;
	Server_bHasPOIOriginLocation = true;
}

void AP3Destructible::EnablePhysics()
{
	bStatic = false;

	StaticMeshComponent->SetSimulatePhysics(true);
	SetReplicateMovement(true);
}

void AP3Destructible::DisablePhysics()
{
	bStatic = true;

	StaticMeshComponent->SetSimulatePhysics(false);
	StaticMeshComponent->SetPhysicsLinearVelocity(FVector::ZeroVector);
	//SetReplicateMovement(false);
}

void AP3Destructible::Server_EnableDestruction(bool bEnable)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!bEnable)
	{
		if (HealthPointComponent)
		{
			HealthPointComponent->DestroyComponent();
			HealthPointComponent = nullptr;
		}
	}
	else
	{
		if (!HealthPointComponent)
		{
			Server_CreateHealthPointComponent();
		}
	}

	bEnableDestruction = bEnable;
}

void AP3Destructible::Server_SetMinImpulseSizeToExplode(float Impulse)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	MinImpulseSizeToExplode = Impulse;
}

void AP3Destructible::Server_SetHitIgnoreActors(const TArray<AActor*>& Actors)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_HitIgnoreActors = Actors;
}

void AP3Destructible::Server_AddHitIgnoreActor(AActor* Actor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_HitIgnoreActors.Add(Actor);
}

void AP3Destructible::Server_SetExplosionIgnoreActors(const TArray<AActor*>& Actors)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_ExplosionIgnoreActors = Actors;
}

void AP3Destructible::Server_AddExplosionIgnoreActor(AActor* Actor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_ExplosionIgnoreActors.Add(Actor);
}

void AP3Destructible::Client_OnExplode(const FP3DediToClientHandlerParams& Params)
{
	FNetExplode NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		MulticastExplode(NetParams.HitLocation, NetParams.ImpulseDir, NetParams.ImpulseStrength);
	}
}

void AP3Destructible::Server_HitByLargeCharacter()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_bExploded || !bEnableDestruction)
	{
		return;
	}

	Server_Explode(GetActorLocation(), FVector(0, 0, 1), MinImpulseSizeToExplode);
}

void AP3Destructible::Server_Fracture()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_bExploded || !bEnableDestruction)
	{
		return;
	}

	Server_Explode(GetActorLocation(), FVector(0, 0, 1), MinImpulseSizeToExplode);
}

void AP3Destructible::NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (Server_bExploded || !bEnableDestruction)
	{
		return;
	}

	if (MinImpulseSizeToExplode < 0)
	{
		return;
	}

	if (Server_HitIgnoreActors.Contains(Other))
	{
		return;
	}

	AP3Projectile* OtherProjectile = Cast<AP3Projectile>(Other);

	if (OtherProjectile)
	{
		UPrimitiveComponent* ProjectilePrimComp = Cast<UPrimitiveComponent>(OtherProjectile->GetRootComponent());

		if (ProjectilePrimComp)
		{
			ProjectilePrimComp->GetBodyInstance()->UpdateMassProperties();

			const FVector Velocity = OtherProjectile->GetVelocity();
			const float Mass = ProjectilePrimComp->CalculateMass();
			NormalImpulse = HitNormal * (Velocity.Size() * Mass);
		}
	}

	const float NormalImpulseSizeSquared = NormalImpulse.SizeSquared();

	if (NormalImpulseSizeSquared >= FMath::Square(MinImpulseSizeToExplode))
	{
		const float ImpulseSize = FMath::Sqrt(NormalImpulseSizeSquared);

		Server_Explode(HitLocation, HitNormal, ImpulseSize);
	}
}

void AP3Destructible::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	if (!Archive.IsLoading())
	{
		Archive << Net_DamagedMeshIndex;
	}
	else
	{
		int32 NewDamagedMeshIndex = -1;

		Archive << NewDamagedMeshIndex;

		if (Net_DamagedMeshIndex != NewDamagedMeshIndex)
		{
			Net_DamagedMeshIndex = NewDamagedMeshIndex;

			DamagedMeshIndexChanged();
		}
	}
}

void AP3Destructible::Server_Explode(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		ensure(0);
		return;
	}

	if (!bEnableDestruction)
	{
		ensure(0);
		return;
	}

	if (Server_bExploded)
	{
		ensure(0);
		return;
	}

	// Too much impulse makes look ugly, like fractured parts shooting into air in a blink of eyes
	ImpulseStrength = FMath::Min(ImpulseStrength, 1000.0f);

	Server_bExploded = true;
	
	if (Damage != 0)
	{
		//UP3BlueprintFunctionLibrary::ExplodeBP(this, GetActorLocation(), DamageRadius, Damage, HitActionImpulseSpeed, bKnockDown, KnockDownDurationSeconds, Server_ExplosionIgnoreActors);

		P3Combat::Server_Explode(*this, GetActorLocation(), DamageRadius, Damage, DamageToAllyPermil, HitActionImpulseSpeed, bKnockDown, KnockDownDurationSeconds, Server_ExplosionIgnoreActors);
	}

	if (bBurn)
	{
		UP3BlueprintFunctionLibrary::Server_BurnAround(this, GetActorLocation(), DamageRadius, BurnPower, TArray<AActor*>(), this);
	}

	if (bWaterSplash)
	{
		P3Chemical::Server_SplashWater(*this, GetActorLocation(), DamageRadius);

		if (WaterPuddleActorClass.Get())
		{
			FActorSpawnParameters ActorSpawnParams;
			ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			GetWorld()->SpawnActor<AActor>(WaterPuddleActorClass.Get(), GetActorLocation(), GetActorRotation(), ActorSpawnParams);
		}
	}

	if (Server_bHasPOIOriginLocation)
	{
		AP3PointOfInterest* PointOfInterest = GetWorld()->SpawnActorDeferred<AP3PointOfInterest>(AP3PointOfInterest::StaticClass(), GetActorTransform(), nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AlwaysSpawn);

		if (ensure(PointOfInterest))
		{
			ensure(!PointOfInterest->GetIsReplicated());
			PointOfInterest->SetOriginLocation(Server_POIOriginLocation);
			UGameplayStatics::FinishSpawningActor(PointOfInterest, GetActorTransform());
		}
	}

	SetLifeSpan(LifespanAfterHit);

	UP3World* P3World = P3Core::GetP3World(*this);
	check(P3World);

	ensure(GetActorId() != INVALID_ACTORID);

	FNetExplode NetExplode;
	NetExplode.HitLocation = HitLocation;
	NetExplode.ImpulseDir = ImpulseDir;
	NetExplode.ImpulseStrength = ImpulseStrength;

	P3World->Server_MulticastPacketReliable(this, GetActorId(), this, NetExplode, EP3NetComponentType::None, &AP3Destructible::Client_OnExplode);

	MulticastExplode(HitLocation, ImpulseDir, ImpulseStrength);

	P3World->Server_FireScareFlockEvent(GetActorLocation(), DamageRadius * 3, 3.0f);
}

void AP3Destructible::MulticastExplode(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("Destructible_Explode"), STAT_Destructible_Explode, STATGROUP_P3);

	if (Multicast_bExploded)
	{
		ensure(0);
		return;
	}

	Multicast_bExploded = true;

	const FVector Velocity = StaticMeshComponent->GetPhysicsLinearVelocity();
	StaticMeshComponent->SetVisibility(false, true);
	StaticMeshComponent->SetSimulatePhysics(false);
	StaticMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	if (ExplosionSound)
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), ExplosionSound, GetActorLocation());
	}

	if (ExplosionParticle)
	{
		FTransform ExplosionTransform = GetActorTransform();
		ExplosionTransform.MultiplyScale3D(FVector(ExplosionParticleScale));

		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), ExplosionParticle, ExplosionTransform);
	}

	DestructibleActor = GetWorld()->SpawnActorDeferred<ADestructibleActor>(ADestructibleActor::StaticClass(), GetActorTransform(), nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AlwaysSpawn);

	if (ensure(DestructibleActor))
	{
		DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_Pawn, ECR_Ignore);
		DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_CLIMB, ECR_Ignore);
		DestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_Camera, ECR_Ignore);
		DestructibleActor->GetDestructibleComponent()->SetPhysicsLinearVelocity(Velocity);
		DestructibleActor->GetDestructibleComponent()->SetDestructibleMesh(DestructableMesh);
		DestructibleActor->GetDestructibleComponent()->SetSimulatePhysics(!bStatic);

		for (int32 Index = 0; Index < Materials.Num(); ++Index)
		{
			DestructibleActor->GetDestructibleComponent()->SetMaterial(Index, Materials[Index]);
		}

		DestructibleActor->FinishSpawning(GetActorTransform());

		// Health Point based destruction use Actor location as Hit Location and that location could be empty space when mesh is concave.
		// So, we need to use max radius to make sure fracture actually happens
		const float BoundingSphereRadius = DestructibleActor->GetDestructibleComponent()->Bounds.SphereRadius + DestructibleActor->GetDestructibleComponent()->Bounds.Origin.Size();

		DestructibleActor->GetDestructibleComponent()->ApplyRadiusDamage(100000000, HitLocation, BoundingSphereRadius, ImpulseStrength * DestructibleImpulseMultiplier, true);

		DestructibleActor->SetLifeSpan(DebrisLifespan + CVarP3DestructibleFallingDurationSeconds.GetValueOnGameThread());

		SetActorTickEnabled(true);
	}

	DestructibleFractured.Broadcast(this);

	if (!DestructibleActor)
	{
		Destroy();
	}
}

void AP3Destructible::Server_CreateHealthPointComponent()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	HealthPointComponent = NewObject<UP3HealthPointComponent>(this, UP3HealthPointComponent::StaticClass(), TEXT("HealthPointComponent"));
	if (ensure(HealthPointComponent))
	{
		HealthPointComponent->RegisterComponent();
		HealthPointComponent->Server_SetServerOnly(true);
		HealthPointComponent->SetMaxHealthPoint(HealthPoint);
		HealthPointComponent->SetHealthPoint(HealthPoint);
		HealthPointComponent->OnChange.AddUniqueDynamic(this, &AP3Destructible::Server_OnHealthChanged);
	}
}

int32 AP3Destructible::CalcDamagedMeshIndex(int32 HealthPoint, int32 MaxHealthPoint, int32 NumDamagedMeshes)
{
	if (HealthPoint == MaxHealthPoint)
	{
		return -1;
	}
	
	if (HealthPoint == 0)
	{
		return NumDamagedMeshes;
	}

	const float HealthRatio = (float)HealthPoint / MaxHealthPoint;
	const float HealthStep = HealthRatio * (NumDamagedMeshes + 1);
	int32 NewDamagedMeshIndex = FMath::Clamp(FMath::FloorToInt(HealthStep) - 1, 0, NumDamagedMeshes);

	// We invert this since it's more intuitive to editor UI
	NewDamagedMeshIndex = NumDamagedMeshes - 1 - NewDamagedMeshIndex;

	return NewDamagedMeshIndex;
}

void AP3Destructible::Server_OnHealthChanged(class UP3HealthPointComponent* InHealthPointComponent, int32 OldHealthPoint, int32 NewHealthPoint)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Server_bExploded)
	{
		if (NewHealthPoint == 0)
		{
			ensure(bEnableDestruction);

			Server_Explode(GetActorLocation(), FVector(0, 0, 1), 100000);
		}
		else
		{
			if (DamagedStaticMeshes.Num() > 0 && InHealthPointComponent && InHealthPointComponent->GetMaxHealthPoint() > 0)
			{
				const int32 NewDamagedMeshIndex = CalcDamagedMeshIndex(NewHealthPoint, InHealthPointComponent->GetMaxHealthPoint(), DamagedStaticMeshes.Num());

				if (Net_DamagedMeshIndex != NewDamagedMeshIndex)
				{
					Net_DamagedMeshIndex = NewDamagedMeshIndex;

					DamagedMeshIndexChanged();

					Server_SetDirty(*this);
				}
			}
		}
	}
}

void AP3Destructible::DamagedMeshIndexChanged()
{
	if (!ensure(StaticMeshComponent))
	{
		return;
	}

	if (Net_DamagedMeshIndex == -1)
	{
		StaticMeshComponent->SetStaticMesh(StaticMesh);
	}
	else if (ensure(DamagedStaticMeshes.IsValidIndex(Net_DamagedMeshIndex)))
	{
		StaticMeshComponent->SetStaticMesh(DamagedStaticMeshes[Net_DamagedMeshIndex]);
	}
}

#if WITH_EDITOR
void AP3Destructible::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	StaticMeshComponent->SetStaticMesh(StaticMesh);
	for (int32 Index = 0; Index < Materials.Num(); ++Index)
	{
		StaticMeshComponent->SetMaterial(Index, Materials[Index]);
	}
}

#endif
