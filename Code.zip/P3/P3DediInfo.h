// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3DediInfo.generated.h"

USTRUCT()
struct FP3DediInfo
{
	GENERATED_BODY()

	UPROPERTY()
	int32 Id = 0;

	UPROPERTY()
	FString Name;

	UPROPERTY()
	FString Address;

	UPROPERTY()
	int32 TCPPort = 0;

	UPROPERTY()
	int32 UDPPort = 0;

	UPROPERTY()
	FString Map;

	UPROPERTY()
	FString Zone;
};
