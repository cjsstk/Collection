// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimMontage.h"

/**
* Generate animation notifies without playing animation
*/
class FP3AnimNotifyGenerator
{
public:
	void Start(const UAnimMontage* InAnimMontage, float Now, float InPlayRate);

	TArray<FAnimNotifyEventReference> TickAndNotifies(float DeltaSeconds);

private:
	TWeakObjectPtr<const UAnimMontage> AnimMontage;
	float StartTimeSeconds = 0.0f;
	float AgeSeconds = 0.0f;
	float LastCheckTime = 0.0f;
	float PlayRate = 1.0f;
};
