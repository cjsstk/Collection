// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3AchievementComponent.generated.h"


UENUM(Blueprintable)
enum class EAchievementCategory : uint8
{
	Invalid,
	Amount,
	Visit,
	Find,
};

USTRUCT(BlueprintType)
struct FP3AchievementContent
{
	GENERATED_BODY()

public:
	UPROPERTY()
	EAchievementCategory AchievementCategory = EAchievementCategory::Invalid;

	UPROPERTY()
	FString AchievementExplanation;

	UPROPERTY()
	FName Amount_NameToAmount;

	UPROPERTY()
	int32 Amount_CurrentNumberToAmount = 0;

	UPROPERTY()
	int32 Amount_GoalNumberToAmount = 0;

	UPROPERTY()
	FVector Visit_CurrentLocation = FVector::ZeroVector;

	UPROPERTY()
	FVector Visit_DestinationLocation = FVector::ZeroVector;

	UPROPERTY()
	bool bHasLinkedAchievement = false;
};

USTRUCT(BlueprintType)
struct FP3AchievementReward
{
	GENERATED_BODY()

};

USTRUCT(BlueprintType)
struct FP3AchievementUpdateParams
{
	GENERATED_BODY()

public:
	UPROPERTY()
	EAchievementCategory AchievementCategory = EAchievementCategory::Invalid;

	UPROPERTY()
	FString AchievementExplanation;

	UPROPERTY()
	int32 Amount_AddedNumberToAmount = 1;

	UPROPERTY()
	FVector Visit_CurrentLocation = FVector::ZeroVector;
};

/** 
 * Achievement
 */
UCLASS(BlueprintType, abstract)
class P3_API UP3Achievement : public UObject
{
	GENERATED_BODY()

public:
	UP3Achievement() {};
	virtual ~UP3Achievement() {};

	virtual void OnRegister(FP3AchievementContent Content, FP3AchievementReward Reward);
	//virtual void StartUpdateAchievement();
	virtual void OnComplete();
	virtual void OnChangeValue() {}

	//virtual void SetLinkedAchievement();

	bool IsCompleted() const { return bCompleted; }

	EAchievementCategory GetAchievementCategory() const { return AchievementContent.AchievementCategory; }
	FString GetAchievementExplanation() const { return AchievementContent.AchievementExplanation; }
	int32 GetAchievementCurrentCount() const { return AchievementContent.Amount_CurrentNumberToAmount; }

	void SetAchievementCurrentCount(const int32 InCount);

protected:
	FP3AchievementContent AchievementContent;
	FP3AchievementReward AchievementReward;

	bool bCompleted = false;
};


UCLASS(BlueprintType)
class P3_API UP3AmountAchievement : public UP3Achievement
{
	GENERATED_BODY()

public:
	UP3AmountAchievement() {};
	virtual ~UP3AmountAchievement() {};

	//virtual void OnRegister(FP3AchievementContentParams Content, FP3AchievementReward Reward) override;
	//virtual void StartUpdateAchievement() override;
	//virtual void OnComplete() override;
	virtual void OnChangeValue() override;

	//virtual void SetLinkedAchievement() override;

private:

};


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3AchievementComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3AchievementComponent();

	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void AddAchievement(EAchievementCategory Category, FP3AchievementContent Content, FP3AchievementReward Reward);
	
	void UpdateAchievementContent(FP3AchievementUpdateParams Params);

private:
	UP3Achievement* GetAchievement(EAchievementCategory Category, FString Explanation) const;

	UPROPERTY()
	TArray<UP3Achievement*> Achievements;

};
