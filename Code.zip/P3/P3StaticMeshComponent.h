// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/StaticMeshComponent.h"
#include "P3Actor.h"
#include "P3StoreInterface.h"
#include "P3StaticMeshComponent.generated.h"


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3StaticMeshComponent : public UStaticMeshComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3StaticMeshComponent();

	virtual void NetSerialize(FArchive& Archive) override;
};


UCLASS()
class P3_API AP3StaticMeshActor : public AP3Actor
{
	GENERATED_BODY()

	AP3StaticMeshActor();

private:
	UPROPERTY(Category = StaticMeshActor, VisibleAnywhere, BlueprintReadOnly, meta = (ExposeFunctionCategories = "Mesh,Rendering,Physics,Components|StaticMesh", AllowPrivateAccess = "true"))
	class UP3StaticMeshComponent* StaticMeshComponent;
};
