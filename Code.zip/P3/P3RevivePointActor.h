// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "P3Actor.h"
#include "P3RevivePointActor.generated.h"


/**
 * Revive Point Actor
 */
UCLASS()
class P3_API AP3RevivePointActor : public AP3Actor
{
	GENERATED_BODY()

public:
	AP3RevivePointActor();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	class UBoxComponent* GetBoxComponent() { return BoxComponent; }
	const FName GetZoneNameToBelong() const { return ZoneNameToBelong; }

private:
	/** Default Scene Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class USceneComponent* SceneComponent;

	/** Box Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UBoxComponent* BoxComponent;

	/** TextRender Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UTextRenderComponent* TextRenderComponent;

	/** Characters in this zone revive this actor point */
	UPROPERTY(EditAnywhere)
	FName ZoneNameToBelong;

};

/**
 * Player Reviver
 */
UCLASS()
class P3_API UP3PlayerReviver : public UObject
{
	GENERATED_BODY()

public:
	UP3PlayerReviver();

	virtual void StartReviver();
	void StopReviver();

protected:
	virtual void TickRevivePlayer() {};

private:
	FTimerHandle ReviveTimerHandle;
};


/**
 * Player Reviver at nearest location
 */
UCLASS()
class P3_API UP3ReviveAtNearestPointPlayerReviver : public UP3PlayerReviver
{
	GENERATED_BODY()

public:
	UP3ReviveAtNearestPointPlayerReviver();

	virtual void StartReviver() override;

	FTransform GetReviveTransform(const class AP3Character* Character) const;

protected:
	virtual void TickRevivePlayer() override;

private:
	void AddRevivePoint(AP3RevivePointActor* NewRevivePoint);
	AP3RevivePointActor* GetNearestRevivePoint(const class AP3Character* Character) const;

	UPROPERTY(Transient)
	TArray<AP3RevivePointActor*> RevivePoints;

	/** [ActorId, CountDown] */
	TMap<int32, int32> PlayerReviveCountdown;
};
