// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3.h"

#include "Internationalization/StringTableRegistry.h"
#include "JsonObjectConverter.h"
#include "Misc/FileHelper.h"
#include "Modules/ModuleManager.h"

#include "P3Character.h"
#include "P3Cms.h"
#include "P3Log.h"

#include "google/protobuf/stubs/common.h"

IMPLEMENT_PRIMARY_GAME_MODULE(FP3GameModule, P3, "P3");

FP3GameModule* FP3GameModule::GameModule = nullptr;

void FP3GameModule::StartupModule()
{
	FDefaultGameModuleImpl::StartupModule();

	P3JsonLog(Display, "FP3GameModule::StartupModule");

#if UE_EDITOR
	const bool bIsEditorMode = !(IsRunningGame() || IsRunningDedicatedServer() || IsRunningClientOnly());
	const bool bIsDevelopment = FApp::GetBuildConfiguration() == EBuildConfigurations::Development;
	if (bIsEditorMode && bIsDevelopment && !IsRunningCommandlet() && !FParse::Param(FCommandLine::Get(), TEXT("Zenga")))
	{
		FPlatformMisc::MessageBoxExt(EAppMsgType::Ok, TEXT("젠가를 통해 실행하세요."), TEXT("Error"));
		FPlatformMisc::RequestExit(true);
	}
#endif

	GameModule = this;

	FString VersionFilePath = FPaths::ProjectContentDir() / TEXT("BuildNonAsset") / TEXT("Version.json");

	FString VersionJsonString;
	const bool bSuccess = FFileHelper::LoadFileToString(VersionJsonString, *VersionFilePath);
	if (bSuccess)
	{
		const bool bParseSuccess = FJsonObjectConverter::JsonObjectStringToUStruct<FP3Version>(VersionJsonString, &Version, 0, 0);
		if (!bParseSuccess)
		{
			P3JsonLog(Error, "Failed to parse version", TEXT("json"), VersionJsonString);
		}
	}
	else
	{
		P3JsonLog(Error, "Failed to read version file", TEXT("file"), VersionFilePath);
	}

	P3JsonLog(Display, "Initialize P3GameModule", TEXT("Version"), VersionJsonString);

	LoadStringTables();

	ConsoleCommandCrash = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("p3.crash"),
		TEXT("Make a crash for test"),
		FConsoleCommandWithArgsDelegate::CreateRaw(this, &FP3GameModule::OnConsoleCommandCrash),
		ECVF_Cheat
	);
}

void FP3GameModule::PostLoadCallback()
{
	FDefaultGameModuleImpl::PostLoadCallback();

	P3JsonLog(Display, "FP3GameModule::PostLoadCallback");
}

void FP3GameModule::ShutdownModule()
{
	IConsoleManager::Get().UnregisterConsoleObject(ConsoleCommandCrash);

	ReleaseStringTables();

	FDefaultGameModuleImpl::ShutdownModule();

	google::protobuf::ShutdownProtobufLibrary();

	P3JsonLog(Display, "FP3GameModule::ShutdownModule");

	GameModule = nullptr;
}

void FP3GameModule::OnConsoleCommandCrash(const TArray<FString>& Args)
{
	uint32* Ptr = nullptr;
	*Ptr = 1;
}

void FP3GameModule::LoadStringTables()
{
	const FString StringTablesPath = "StringTables";
	const FString SearchPath = FPaths::ProjectContentDir() / StringTablesPath;
	TArray<FString> CsvFiles;
	IFileManager::Get().FindFiles(CsvFiles, *SearchPath, TEXT("CSV"));
	for (const FString& CsvFile : CsvFiles)
	{
		const FString StringTableId = FPaths::GetBaseFilename(CsvFile);
		FStringTableRegistry::Get().Internal_LocTableFromFile(*StringTableId, *StringTableId, CsvFile, SearchPath);
		StringTableIds.Add(StringTableId);
	}
}

void FP3GameModule::ReleaseStringTables()
{
	for (const FString& StringTableId : StringTableIds)
	{
		FStringTableRegistry::Get().UnregisterStringTable(*StringTableId);
	}
	StringTableIds.Empty();
}
