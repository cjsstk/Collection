// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Network/Lib/P3NetCore.h"

#include "P3Actor.h"
#include "P3StoreInterface.h"
#include "P3TemporaryWeaponType.h"
#include "P3Spear.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3JavelinImpaled, class UActorComponent*, TargetComponent);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3JavelinBounced, class UActorComponent*, TargetComponent);

USTRUCT()
struct FNetSpearAttachToCharacter
{
	GENERATED_BODY()

	UPROPERTY()
	UPrimitiveComponent* TargetComponent;

	UPROPERTY()
	FName SocketName;

	UPROPERTY()
	FVector Impulse = FVector::ZeroVector;
};

/**
 * Pickupable and Throwable
 */
UCLASS()
class P3_API AP3Spear : public AP3Actor
{
	GENERATED_BODY()
	
public:
	AP3Spear();

protected:
	virtual void NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void Client_OnEvent(FName EventName, int32 Param) override;
	virtual void NetSerialize(FArchive& Archive) override;

private:
	virtual void BeginPlay() override;

	void Server_Tick(float DeltaSeconds);
	void Server_Hit(UPrimitiveComponent& OtherComp, FName SocketName);

	UFUNCTION()
	void Server_OnCharacterRevive();

	void Server_DetachFromActor();

	UFUNCTION()
	void Server_OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void Client_AttachToCharacter(const FP3DediToClientHandlerParams& Params);
	void Multicast_AttachToCharacter(UPrimitiveComponent* TargetComponent, FName SocketName, const FVector& Impulse);

	/** Set how long spear will stuck into target on hit */
	UPROPERTY(EditDefaultsOnly, Category = Spear)
	float PenetrationDepthOnHit = 50.0f;

	UPROPERTY(EditDefaultsOnly, Category = Spear)
	float DamagePermil = 3000.0f;

	UPROPERTY(EditDefaultsOnly, Category = Spear)
	float DestroyTimeSeconds = 30.0f;

	/** How strong pitch moment will arise during flying. If set higher, spear's front-end will fall more quickly */
	UPROPERTY(EditDefaultsOnly, Category = Spear)
	float PitchingMomentDuringFlying = 50.0f;

	UPROPERTY(VisibleAnywhere)
	class UP3PickupableComponent* PickupableComponent;

	FVector Server_LastVelocity = FVector::ZeroVector;

	float Server_TimeSinceLastAttachSeconds = 0.0f;

	bool Server_bUsed = false;

	UPROPERTY(Transient)
	class AP3Character* Server_TargetCharacter = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = Spear)
	EP3TemporaryWeaponType TemporaryWeaponType = EP3TemporaryWeaponType::Javelin;
};

/** 
 * Javelin Component
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3JavelinComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:
	UP3JavelinComponent();

	void Throw(const FVector& Direction, APawn* Instigator);

	class AP3Character* GetImpaledCharacter() const { return Net_ImpaledCharacter; }

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	UPROPERTY(BlueprintAssignable)
	FP3JavelinImpaled JavelinImpaled;

	UPROPERTY(BlueprintAssignable)
	FP3JavelinBounced JavelinBounced;

protected:
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	UFUNCTION()
	void Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit);

	UFUNCTION()
	void Server_OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	void Server_Tick(float DeltaSeconds);
	bool Server_Hit(UPrimitiveComponent& OtherComp, FName BoneName);
	void Server_SetImapledCharacter(class AP3Character* Character);
	
	void Server_CableHit(UPrimitiveComponent* OtherComp, bool bHit, bool bCableAttachEnd);
	bool CanCableMove(const AP3Character* Character, const AP3Character *TargetCharacter) const;	

	/**
	 * Config
	 */

	/** Throwing Speed */
	UPROPERTY(EditDefaultsOnly, Category = "Javelin")
	float ThrowSpeed = 2000;

	/** How strong pitch moment will arise during flying. If set higher, spear's front-end will fall more quickly */
	UPROPERTY(EditDefaultsOnly, Category = "Javelin")
	float PitchingMomentDuringFlying = 50.0f;

	/** Set how long spear will stuck into target on hit */
	UPROPERTY(EditDefaultsOnly, Category = "Javelin")
	float PenetrationDepthOnHit = 50.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Javelin")
	float DamagePermil = 3000.0f;

	/** Minimum cable action distance */
	UPROPERTY(EditDefaultsOnly, Category = "JavelinCable")
	float CableMoveMinDist = 500.f;

	/** Maximum cable action distance */
	UPROPERTY(EditDefaultsOnly, Category = "JavelinCable")
	float CableMoveMaxDist = 5000.f;

	/** Cable movement impulse value */
	UPROPERTY(EditDefaultsOnly, Category = "JavelinCable")
	float CableMoveImpulse = 4500.f;
	
	/** Does work with 'UnpenetrablePart' */
	UPROPERTY(EditDefaultsOnly, Category = "JavelinCable")
	bool IgnoreUnpenetrablePart = false;

	/** Time to show cable after visible */
	UPROPERTY(EditDefaultsOnly, Category = "JavelinCable")
	float CableAttachEndTimeSeconds = 5.0f;

	/** Cable visible start time */
	float Server_CableVisibleStartedTimeSeconds = 0.0f;

	/**
	 * Status
	 */

	/** Been thrown and still flying in the air? */
	bool bFlying = false;
	bool bUnpenetrablePart = false;

	FVector Server_LastVelocity = FVector::ZeroVector;

	/** Set if javelin is impaled to a character */
	UPROPERTY(Transient)
	class AP3Character* Net_ImpaledCharacter = nullptr;
};
