// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "Engine/DataTable.h"

#include "Action/P3PawnActionType.h"
#include "P3CharacterStance.h"
#include "P3CharacterEffectTypes.h"
#include "Command/P3Command.h"

#include "P3ComboTable.generated.h"

/**
* Keyboard / pad input value for combo start input condition
*/
UENUM(Meta = (Bitflags))
enum class EP3ComboTableInputFlags : int32
{	
	NormalAttackDown,
	NormalAttackUp,
	PrivateActionDown,
	PrivateActionUp,
	SpecialAttackDown,
	SpecialAttackUp,
	ClassAttackDown,
	ClassAttackUp,
	SprintDown,
	SprintUp,
	MoveForward,
	MoveBack,
	MoveRight,
	MoveLeft,
	JumpDown,
	JumpUp,
	EvadeDown,
	EvadeUp,
	Count			UMETA(Hidden),		
};

/**
* When the combo action starts, the initial character direction 
*/
UENUM()
enum class EP3ComboTableStartRotationType : uint8
{
	None,
	CameraForward,
	ControlForward,
	TargetDirection,
};

/**
* 8 way conversion value of keyboard / pad input
*/
UENUM()
enum class EP3ComboTableInputDirectionType : int32
{
	Forward = 0,
	ForwardRight,
	Right,
	BackwardRight,
	Backward,
	BackwardLeft,
	Left,
	ForwardLeft,	
	None	 UMETA(Hidden),
	Count	 UMETA(Hidden)
};

/**
* Change status to combo
*/
USTRUCT(Blueprintable)
struct FP3ComboStatus
{
	GENERATED_BODY()

	/** Do you switch stance to combat? */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool bChangeStanceToCombat = false;

	/** If MeleeAimingMode is disabled, start it */
	UPROPERTY(EditDefaultsOnly, Category = Aim)
	bool bStartMeleeAiming = false;
	
	/** If RangedAimingMode is disabled, start it */
	UPROPERTY(EditDefaultsOnly, Category = Aim)
	bool bStartRangedAiming = false;
	
	/** Do you want to activate a mode that gives bouncing jumping ability to other characters? */
	UPROPERTY(EditDefaultsOnly, Category = Block)
	bool bStartBouncingMode = false;

	/** Start blocking mode of 8 way movement */
	UPROPERTY(EditDefaultsOnly, Category = Block)
	bool bStartBlockingMode = false;

	/** Same as BlockingMode but more powerful blocking mode */
	UPROPERTY(EditDefaultsOnly, Category = Block)
	bool bStartCrouchBlockingMode = false;
};

/**
* Target catching condition
*/
USTRUCT(Blueprintable)
struct FP3ComboTarget
{
	GENERATED_BODY()

	/** Check for class Type */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool CheckClass = false;

	/** Is the class type of target in the list? */
	UPROPERTY(EditDefaultsOnly, Category = P3, Meta = (EditCondition = "CheckClass"))
	TArray<UClass*> ClassAny;

	/** Check for apply damage  */
	UPROPERTY(EditDefaultsOnly, Category = Damage)
	bool CheckDamage = false;

	/** Did you apply damage? */
	UPROPERTY(EditDefaultsOnly, Category = Damage, Meta = (EditCondition = "CheckDamage"))
	bool bIsDamageReceived = false;

	/** Did you give damage? */
	UPROPERTY(EditDefaultsOnly, Category = Damage, Meta = (EditCondition = "CheckDamage"))
	bool bIsDamageGiven = false;
	
	/** Check for distance to target */
	UPROPERTY(EditDefaultsOnly, Category = Location)
	bool CheckDistance = false;

	/** X is the distance range. Y is the height distance */
	UPROPERTY(EditDefaultsOnly, Category = Location, Meta = (EditCondition = "CheckDistance"))
	FVector2D DistanceRange = FVector2D::ZeroVector;

	/** Check for angle to target */
	UPROPERTY(EditDefaultsOnly, Category = Location)
	bool CheckAngle = false;

	/** X is the 0 degrees to -180 degrees. Y is the 0 degrees to 180 degrees range */
	UPROPERTY(EditDefaultsOnly, Category = Location, Meta = (EditCondition = "CheckAngle"))
	FVector2D AngleRange = FVector2D::ZeroVector;

	/** Check for target current action type */
	UPROPERTY(EditDefaultsOnly, Category = Action)
	bool CheckActionType = false;

	/** Is target the current action type */
	UPROPERTY(EditDefaultsOnly, Category = Action, Meta = (EditCondition = "CheckActionType"))
	EPawnActionType ActionType = EPawnActionType::Invalid;

	/** Check the current target stance */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckCharacterStance = false;

	/** What is the current target stance? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckCharacterStance"))
	EP3CharacterStance CharacterStance = EP3CharacterStance::Combat;

	/** Check for target faction */
	UPROPERTY(EditDefaultsOnly, Category = Attribute)
	bool CheckFaction = true;

	/** Is the same faction as the target? */
	UPROPERTY(EditDefaultsOnly, Category = Attribute, Meta = (EditCondition = "CheckFaction"))
	bool bIsSameFaction = false;

	/** Check for target large type */
	UPROPERTY(EditDefaultsOnly, Category = Attribute)
	bool CheckLarge = false;

	/** Is the target large? */
	UPROPERTY(EditDefaultsOnly, Category = Attribute, Meta = (EditCondition = "CheckLarge"))
	bool bIsLarge = false;		
};

/**
* Command to execute combo
*/
USTRUCT(Blueprintable)
struct FP3ComboRow : public FTableRowBase
{
	GENERATED_BODY()
	
	/** Name set in Edge. For the first run combo, you must set it to "root" */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName ComboName = NAME_None;
	
	/** Do you keep the combo until you press the input button? */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bInputPressHold = false;

	/** Keyboard / pad input conditions for combo hold. All input conditions match */
	UPROPERTY(EditDefaultsOnly, Category = P3, Meta = (Bitmask, BitmaskEnum = "EP3ComboTableInputFlags", EditCondition = "bInputPressHold"))
	int32 InputPressHoldAllFlags = 0;

	/** Keyboard / pad input conditions for combo hold. Anything input condition match. */
	UPROPERTY(EditDefaultsOnly, Category = P3, Meta = (Bitmask, BitmaskEnum = "EP3ComboTableInputFlags", EditCondition = "bInputPressHold"))
	int32 InputPressHoldAnyFlags = 0;
	
	/** ActionType to execute */
	UPROPERTY(EditDefaultsOnly, Category = Action)
	EPawnActionType ActionType = EPawnActionType::CombatCombo;
	
	/** The desired motion at start of the combo */
	UPROPERTY(EditDefaultsOnly, Category = Action)
	FName AnimationName = NAME_None;	

	/** The desired motion rate at start of the combo */
	UPROPERTY(EditDefaultsOnly, Category = Action)
	float AnimationPlayRate = 1.f;
	
	/** The desired character direction at start of the combo */
	UPROPERTY(EditDefaultsOnly, Category = Action)
	EP3ComboTableStartRotationType StartRotationType = EP3ComboTableStartRotationType::None;

	/** Aimoffset selection index used by animation BP */
	UPROPERTY(EditDefaultsOnly, Category = Animation)
	int32 SelectedAimOffsetAnimationIndex = 0;

	/** BlendSpace combat run selection index used by animation BP */
	UPROPERTY(EditDefaultsOnly, Category = Animation)
	int32 SelectedCombatRunBlendSpeaceIndex = 0;	
		
	/** Clears all currently stored input value */
	UPROPERTY(EditDefaultsOnly, Category = Input)
	bool bClearInputFlags = false;
	
	/** Time to clear stack input */
	UPROPERTY(EditDefaultsOnly, Category = Input)
	float InputStackClearTimeSeconds = 0.5f;
	
	/** Stamina amount consumed at combo start */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float ConsumeStamina = 0.f;

	/** Staminer amount per second consumed during combo action */	
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float ConsumeStaminaPerSecond = 0.f;

	/** Shake the camera with a given curve */
	UPROPERTY(EditDefaultsOnly, Category = Aim)
	bool bStartAimShake = false;

	/** Shake the camera Curve value */
	UPROPERTY(EditDefaultsOnly, Category = Aim, Meta = (EditCondition = "bStartAimShake"))
	UCurveFloat* AimShakeCurve = nullptr;

	/** Weapon use counter decrease */
	UPROPERTY(EditDefaultsOnly, Category = Weapon)
	bool bIsIncreaseUseCountByPlayer = false;

	/** The desired weapon motion at start of the combo */
	UPROPERTY(EditDefaultsOnly, Category = Weapon)
	FName WeaponAnimationName = NAME_None;
	
	/* Stop the weapon motion with the action finish */
	UPROPERTY(EditDefaultsOnly, Category = Weapon)
	bool bIsWeaponAnimationStopWithActionFinish = false;

	/** Change camera offset distance by offset */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	FVector SocketOffset = FVector::ZeroVector;

	/** Change camera offset Interpolation speed by ratio */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	UCurveFloat* SocketOffsetInterpSpeedRatioCurve = nullptr;

	/** Change camera boom distance by ratio */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	float TargetArmLengthRatio = 1.f;

	/** Change camera boom Interpolation speed by ratio */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	UCurveFloat* TargetArmLengthInterpSpeedRatioCurve = nullptr;

	/** Change camera FieldOfView by ratio */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	float FieldOfViewRatio = 1.f;
	
	/** Change camera FieldOfView Interpolation speed by ratio */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	UCurveFloat* FieldOfViewInterpSpeedRatioCurve = nullptr;

	/** Interpolation speed from camera direction to aim direction */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	float CameraFollowSpeed = 0.f;

	/** Camera pitch rotation limit angle */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	float LimitPitchDegrees = 0.f;
	
	/** Camera yaw rotation limit angle */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	float LimitYawDegrees = 0.f;

	/** Camera shake CMS table row name */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	FName CmsCameraShakeKey = NAME_None;
	
	/** Change movement speed by multiplier */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float SpeedMultiplier = 1.f;

	/** Change movement yaw turn speed by multiplier */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float RotationYawMultiplier = 1.f;
		
	/** Curve asset to pass to the movement.X value forward Z value upward */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	UCurveVector* DeltaMoveCurve = nullptr;

	/** Hold time through curve movement */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float ActionForceDurationSeconds = 1.f;

	/** Falling on ground motion session name */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	FName FallingOnGroundSectionName = NAME_None;

	/** Stopping on ground motion session name */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	FName StoppingOnGroundSectonName = NAME_None;

	/** Increase the input scale by interval distance */
	UPROPERTY(EditDefaultsOnly, Category = MoveTowardsTarget)
	float IntervalDistance = 100.f;

	/** 'IntervalDistance' Value to multiply by difference */
	UPROPERTY(EditDefaultsOnly, Category = MoveTowardsTarget)
	float MultiplyInputScale = 1.0f;
		
	/** Turn off state automatically. If it is false, you must set the 'ExitComboStatus' value */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool bAutoOffStatus = true;

	/** The state to change when starting the combo */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	FP3ComboStatus EntryComboStatus;
	
	/** The state to change when exiting the combo */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "!bAutoOffStatus"))
	FP3ComboStatus ExitComboStatus;
};

/**
* Combo check condition
*/
USTRUCT(Blueprintable)
struct FP3ComboEdgeRow : public FTableRowBase
{
	GENERATED_BODY()
	
	/** The name of the currently running combo. For the first run combo, you must set it to "root" */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName ComboName = NAME_None;
	
	/** If the condition passes, the next combo name to be executed */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName NextComboName = NAME_None;
	
	/** Activate input condition check */
	UPROPERTY(EditDefaultsOnly, Category = Input)
	bool CheckInput = true;

	/** Keyboard / pad any input conditions for combo operation */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (Bitmask, BitmaskEnum = "EP3ComboTableInputFlags", EditCondition = "CheckInput"))
	int32 InputFlags = 0;

	/** Keyboard / pad all input conditions for combo operation */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (Bitmask, BitmaskEnum = "EP3ComboTableInputFlags", EditCondition = "CheckInput"))
	int32 InputAllFlags = 0;

	/** Check the time the button is pressed */
	UPROPERTY(EditDefaultsOnly, Category = Input)
	bool CheckInputPressTime = false;
	
	/** Do you want to check which button you pressed? */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (Bitmask, BitmaskEnum = "EP3ComboTableInputFlags", EditCondition = "CheckInputPressTime"))
	int32 InputPressTimeFlags = 0;
		
	/** The time the button is pressed must be between this value */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (EditCondition = "CheckInputPressTime"))
	FVector2D InputPressTimeSeconds = FVector2D::ZeroVector;
	
	/** Check the input direction in 8 directions */
	UPROPERTY(EditDefaultsOnly, Category = Input)
	bool CheckInputDirection = false;
	
	/** What input value is the current input value in 8 directions? */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (EditCondition = "CheckInputDirection"))
	EP3ComboTableInputDirectionType InputDirectionType = EP3ComboTableInputDirectionType::Forward;

	/** Check camera axis the input direction in 8 directions */
	UPROPERTY(EditDefaultsOnly, Category = Input)
	bool CheckCameraInputDirection = false;

	/** What input value is the current input value in 8 directions? */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (EditCondition = "CheckCameraInputDirection"))
	EP3ComboTableInputDirectionType CameraInputDirectionType = EP3ComboTableInputDirectionType::Forward;
	
	/** Check the stored input stack. Is the input unlocked using 'UAnimNotify_InputStackButtonUnblock'? */
	UPROPERTY(EditDefaultsOnly, Category = Input)
	bool CheckInputStack = false;

	/** Use input stack order checking */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (EditCondition = "CheckInputStack"))
	bool bIsInputStackSequence = false;
	
	/** Input value to check on the stack */
	UPROPERTY(EditDefaultsOnly, Category = Input, Meta = (EditCondition = "CheckInputStack"))
	TArray<EP3ComboTableInputFlags> InputStack;
	
	/** Check the current animation in 'UAnimNotifyState_ComboSignal' signal */
	UPROPERTY(EditDefaultsOnly, Category = Notify)
	bool CheckAnimNotifyStateSignal = false;

	/** Signal name set in 'UAnimNotifyState_ComboSignal' */
	UPROPERTY(EditDefaultsOnly, Category = Notify, Meta = (EditCondition = "CheckAnimNotifyStateSignal"))
	FName AnimNotifyStateSignalName = NAME_None;

	/** Check the current character's action type */
	UPROPERTY(EditDefaultsOnly, Category = Action)
	bool CheckActionType = false;

	/** What is the current character's action type? */
	UPROPERTY(EditDefaultsOnly, Category = Action, Meta = (EditCondition = "CheckActionType"))
	EPawnActionType ActionType = EPawnActionType::CombatCombo;

	/** Check the current character's stance */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckCharacterStance = false;
	
	/** What is the current character's stance? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckCharacterStance"))
	EP3CharacterStance CharacterStance = EP3CharacterStance::Combat;

	/** Check for BlockingMode */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckBlockingMode = false;
	
	/** Is the current blocking mode? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckBlockingMode"))
	bool bIsBlockingMode = false;

	/** Check for CheckCrouchBlockingMode */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckCrouchBlockingMode = false;

	/** Is the current crouch blocking mode? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckCrouchBlockingMode"))
	bool bIsCrouchBlockingMode = false;

	/** Check for BouncingMode */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckBouncingMode = false;

	/** Is the current bouncing mode? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckBouncingMode"))
	bool bIsBouncingMode = false;

	/** Check for MeleeAimingMode */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckMeleeAiming = false;

	/** Is the current meleeaiming mode? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckMeleeAiming"))
	bool bIsMeleeAiming = false;

	/** Check for RangedAimingMode */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckRangedAiming = false;

	/** Is the current rangedaiming mode? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckRangedAiming"))
	bool bIsRangedAiming = false;
		
	/** Check stamina status */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckExhausted = true;

	/** Is the stamina exhausted? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckExhausted"))
	bool bIsExhausted = false;
		
	/** Check if current reaction is knockdown */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckKnockDown = false;

	/** Is the reaction currently knocked down? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckKnockDown"))
	bool bIsKnockDown = false;
	
	/** Check if current reaction is knockback */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckKnockBack = false;
	
	/** Is the reaction currently knocked back? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckKnockBack"))
	bool bIsKnockBack = false;
	
	/** Check if can block mode */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckCanBlock = false;
	
	/** Can you block mode? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckCanBlock"))
	bool bCanBlock = false;

	/** Check if it is attached to another character */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckMounted = true;

	/** Is the current mounted mode? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckMounted"))
	bool bIsMounted = false;

	/** Check for Stumbling */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckStumbling = false;
	
	/** Is the character Stumbling? */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckStumbling"))
	bool bIsStumbling = false;
	
	/** Check for stamina amount */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool CheckStamina = false;
	
	/** Amount of stamina to check */
	UPROPERTY(EditDefaultsOnly, Category = Status, Meta = (EditCondition = "CheckStamina"))
	float Stamina = 0.f;

	/** Check if the movement is on the ground */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool CheckMovingOnGround = false;
	
	/** Is the movement on the ground? */
	UPROPERTY(EditDefaultsOnly, Category = Movement, Meta = (EditCondition = "CheckMovingOnGround"))
	bool bIsMovingOnGround = false;

	/** Check if the movement is falling*/
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool CheckFalling = false;

	/** Is the movement falling? */
	UPROPERTY(EditDefaultsOnly, Category = Movement, Meta = (EditCondition = "CheckFalling"))
	bool bIsFalling = false;

	/** Check if the movement is flying */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool CheckFlying = false;

	/** Is the movement flying? */
	UPROPERTY(EditDefaultsOnly, Category = Movement, Meta = (EditCondition = "CheckFlying"))
	bool bIsFlying = false;
	
	/** Check if movement's Velocity.Z > 0 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool CheckAscending = false;

	/** Is the movement ascending? */
	UPROPERTY(EditDefaultsOnly, Category = Movement, Meta = (EditCondition = "CheckAscending"))
	bool bIsAscending = false;

	/** Check if the movement is moving*/
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool CheckMoving = false;

	/** Is the movement moving? */
	UPROPERTY(EditDefaultsOnly, Category = Movement, Meta = (EditCondition = "CheckMoving"))
	bool bIsMoving = false;

	/** Check  movement speed */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool CheckSpeed = false;

	/** Is the current speed range value? */
	UPROPERTY(EditDefaultsOnly, Category = Movement, Meta = (EditCondition = "CheckSpeed"))
	FVector2D Speed = FVector2D::ZeroVector;
		
	/** If you are jumping, check the height of the ground */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool CheckJumpHeight = false;
	
	/** Is it greater than this height? */
	UPROPERTY(EditDefaultsOnly, Category = Movement, Meta = (EditCondition = "CheckJumpHeight"))
	float JumpHeight = 0.f;	
		
	/** Check for apply damage  */
	UPROPERTY(EditDefaultsOnly, Category = Damage)
	bool CheckDamageReceived = false;
	
	/** Combo name that gave damage */
	UPROPERTY(EditDefaultsOnly, Category = Damage, Meta = (EditCondition = "CheckDamageReceived"))
	FName DamageReceivedComboName = NAME_None;

	/** Did you apply damage? */
	UPROPERTY(EditDefaultsOnly, Category = Damage, Meta = (EditCondition = "CheckDamageReceived"))
	bool bIsDamageReceived = false;

	/** Check for effects */
	UPROPERTY(EditDefaultsOnly, Category = Effect)
	bool CheckHasEffect = false;
		
	/** Must have everything */
	UPROPERTY(EditDefaultsOnly, Category = Effect, Meta = (EditCondition = "CheckHasEffect"))
	TArray<EP3CharacterEffectTypes>  HasEffectsAll;
	
	/** There is only one of these */
	UPROPERTY(EditDefaultsOnly, Category = Effect, Meta = (EditCondition = "CheckHasEffect"))
	TArray<EP3CharacterEffectTypes>  HasEffectsAny;	

	/** Try to catch the target */
	UPROPERTY(EditDefaultsOnly, Category = Target)
	bool CheckTarget = false;

	/** If set true, execution combo if can not catch the target */
	UPROPERTY(EditDefaultsOnly, Category = Target, Meta = (EditCondition = "CheckTarget"))
	bool bRunWithoutTarget = true;

	/** Detailed conditions of the target */
	UPROPERTY(EditDefaultsOnly, Category = Target, Meta = (EditCondition = "CheckTarget"))
	TArray<FP3ComboTarget> TryTargetAny;
};

USTRUCT()
struct FP3ComboTableContext
{
	GENERATED_BODY()
	
	EPawnActionType ActiveActionType = EPawnActionType::Invalid;
	EPawnActionType RequestedActionType = EPawnActionType::Invalid;

	FName ActiveComboAnimationName = NAME_None;
	FName BeforeActiveComboAnimationName = NAME_None;
	FName NextComboAnimationName = NAME_None;

	FName CurrentComboName = NAME_None;
	FName NextComboName = NAME_None;

	int32 ComboInputFlags = 0;
	int32 ExecutionInputFlags = 0;
	FVector InputForwardDirection = FVector::ZeroVector;
	FVector InputRightDirection = FVector::ZeroVector;

	TStaticArray<float, (int32)EP3ComboTableInputFlags::Count> InputButtonPressTimeSeconds;	
	
	int32 RequestedActionId = 0;
	int32 ReceivedActionId = 0;
		
	float ConsumeStaminaPerSecond = 0.f;

	bool LocalControl_bIsAnimNotifyInputMoveBlock = false;
	bool LocalControl_bIsAnimNotifyInputTurnBlock = false;
	bool LocalControl_bIsAnimNotifyInputButtonStack = false;
	bool LocalControl_bIsAnimNotifyInputCameraMoveBlock = false;
	
	bool LocalControl_bIsAnimNotifyPlayActionBlock = true;
	bool LocalControl_bIsAnimNotifyAutoMoveTowardsTarget = false;

	EP3CharacterStance Stance = EP3CharacterStance::Idle;
	bool bIsBlockingMode = false;
	bool bIsCrouchBlockingMode = false;
	bool bIsBouncingMode = false;
	bool bIsMeleeAiming = false;
	bool bIsRangedAiming = false;
	bool bIsStumbling = false;
	bool bIsExhausted = false;
	bool bIsMovingOnGround = false;
	bool bIsFalling = false;
	bool bIsFlying = false;
	bool bIsAscending = false;
	bool bIsMoving = false;
	bool bCanCombat = false;	
	bool bIsKnockDown = false;
	bool bIsKnockBack = false;
	bool bCanBlock = false;
	bool bIsMounted = false;
	bool bHasStunEffect = false;
	bool bIsDamageReceived = false;
	bool bIsMontageStarted = false;
	
	/** Current combo name on OnReceiveDamage call */
	FName DamageReceivedComboName = NAME_None;
	
	float CurrentSpeed = 0.f;
	float SpeedMultiplier = 1.f;
	float RotationYawMultiplier = 1.f;
	float CurrentStaminaPoint = 0.f;
	float MaxJumpHeight = 0.f;
	float InputStackClearTimeSeconds = 0.0f;

	FVector SocketOffset = FVector::ZeroVector;	
	float TargetArmLengthRatio = 1.f;
	float FieldOfViewRatio = 1.f;
	float CameraFollowSpeed = 0.f;
	
	float RestoreViewPitchMin = 0.f;
	float RestoreViewPitchMax = 0.f;
	float RestoreViewYawMin = 0.f;
	float RestoreViewYawMax = 0.f;

	float SocketOffsetInterpSpeedRatio = 1.f;
	float TargetArmLengthInterpSpeedRatio = 1.f;
	float FieldOfViewInterpSpeedRatio = 1.f;

	float MoveTowardsTargetIntervalDistance = 0.f;
	float MoveTowardsTargetMultiplyInputScale = 0.f;
	
	FP3CommandRequestParams RequestedCommandParams;
	FP3CommandRequestParams CommandParams;
	
	TWeakObjectPtr<class AP3Character> Character = nullptr;	
	TWeakObjectPtr<class AActor> Target = nullptr;
	TWeakObjectPtr<class AP3Character> DamageReceivedTarget = nullptr;
	TWeakObjectPtr<class AP3Character> DamageGivenTarget = nullptr;
	
	static const int32 MaxInputFlagStack = 15;
	TArray<EP3ComboTableInputFlags, TFixedAllocator<MaxInputFlagStack>> InputFlagStack;

	TMap<FName, bool> NotifyStateSignal;

	FRotator AimingStartRotation = FRotator::ZeroRotator;
};
