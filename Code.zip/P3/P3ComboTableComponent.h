// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "P3ActionAnimationType.h"
#include "P3ComboTable.h"
#include "P3WeaponType.h"

#include "P3ComboTableComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3ComboStarted, const struct FP3ComboRow&, ComboRow);

USTRUCT(Blueprintable)
struct FP3ComboDataTable
{
	GENERATED_BODY()
	
	UPROPERTY(EditDefaultsOnly, Category = P3)
	UDataTable* ComboDataTable = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	UDataTable* ComboEdgeDataTable = nullptr;
};

USTRUCT(Blueprintable)
struct FP3ComboCameraTable : public FTableRowBase
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, Category = P3)
	EP3WeaponType WeaponType = EP3WeaponType::None;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	EP3CharacterStance CharacterStance = EP3CharacterStance::Idle;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FVector SocketOffset = FVector::ZeroVector;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float TargetArmLengthRatio = 1.f;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float FieldOfViewRatio = 1.f;
};

UCLASS(BlueprintType)
class P3_API UP3ComboActionMontageData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = P3)
	EP3WeaponType WeaponType = EP3WeaponType::None;

	UPROPERTY(EditAnywhere, Category = P3)
	TMap<EP3ActionAnimationType, UAnimMontage*> ActionAnimations;
};

UCLASS(BlueprintType)
class P3_API UP3ComboMontageData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = P3)
	EP3WeaponType WeaponType = EP3WeaponType::None;

	UPROPERTY(EditAnywhere, Category = P3)
	TMap<FName, UAnimMontage*> ComboAnimations;
};

UCLASS(BlueprintType)
class P3_API UP3ComboWeaponMontageData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = P3)
	EP3WeaponType WeaponType = EP3WeaponType::None;

	UPROPERTY(EditAnywhere, Category = P3)
	TMap<FName, UAnimMontage*> WeaponAnimations;
};

UCLASS(ClassGroup = (P3), Blueprintable, meta = (BlueprintSpawnableComponent))
class P3_API UP3ComboTableComponent : public UActorComponent
{
	GENERATED_BODY()

public:		
	UP3ComboTableComponent();

	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void InitializeComponent() override;
	virtual void UninitializeComponent() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	void Client_OnDisconnected();
	bool IsComboEnabled() const;
	bool IsNotifyStateSignalEnabled(const FName& SignalName);
	
	void SetInputStackBlock(bool bInInputStackBlock) { ComboContext.LocalControl_bIsAnimNotifyInputButtonStack = bInInputStackBlock; }
	void SetInputMoveBlock(bool bInInputMoveBlock) { ComboContext.LocalControl_bIsAnimNotifyInputMoveBlock = bInInputMoveBlock; }	
	void SetInputTurnBlock(bool bInInputTurnBlock) { ComboContext.LocalControl_bIsAnimNotifyInputTurnBlock = bInInputTurnBlock; }
	void SetInputCameraMoveBlock(bool bInInputCameraMoveBlock) { ComboContext.LocalControl_bIsAnimNotifyInputCameraMoveBlock = bInInputCameraMoveBlock; }
	void SetPlayActionBlock(bool bInPlayActionBlock) { ComboContext.LocalControl_bIsAnimNotifyPlayActionBlock = bInPlayActionBlock; }
	void SetAutoMoveTowardsTarget(bool bInAutoMoveTowardsTarget) { ComboContext.LocalControl_bIsAnimNotifyAutoMoveTowardsTarget = bInAutoMoveTowardsTarget; }
	void SetNotifyStateSignal(const FName& SignalName, bool bIsEnabled);

	bool CanCombo() const;
	bool CanMove() const;		
	bool CanTurn() const;
	bool CanJump() const;	
	bool CanCameraMove() const;
	bool CanStartedCondition(const FP3ComboEdgeRow& ComboEdgeRow);

	FRotator GetControlRotation() const;
	
	UFUNCTION(BlueprintCallable)
	void LocalControl_SetCrossHairPosition(UWidget* Widget);

	UFUNCTION(BlueprintCallable)
	FString GetNextComboInputString();

	FVector GetLaunchLocation() const;
	FRotator GetAimRotation(const FVector& LauncherLocation) const;
	FRotator GetAimRotation() const;
	FRotator GetAimingStartRotation() const;
	const FVector2D& GetCrossHairPosition() const { return LocalControl_CrossHairPosition; }
	FVector GetDeprojectWorldLocation() const;

	float GetConsumeStaminaPerSecond() const { return ComboContext.ConsumeStaminaPerSecond; }
	float GetMoveSpeedMultiplier() const;
	float GetRotationYawRateMultiplier() const;

	const FVector& GetSocketOffset() const { return ComboContext.SocketOffset; }
	float GetTargetArmLengthRatio() const { return ComboContext.TargetArmLengthRatio; }
	float GetFieldOfViewRatio() const { return ComboContext.FieldOfViewRatio; }
	float GetSocketOffsetInterpSpeedRatio() const { return ComboContext.SocketOffsetInterpSpeedRatio; }
	float GetTargetArmLengthInterpSpeedRatio() const { return ComboContext.TargetArmLengthInterpSpeedRatio; }
	float GetFieldOfViewInterpSpeedRatio() const { return ComboContext.FieldOfViewInterpSpeedRatio; }
	float GetCameraFollowSpeed() const { return ComboContext.CameraFollowSpeed; }
	
	void OnAnimNotify(const class UAnimNotify& AnimNotify);
	void OnReceiveDamage(AP3Character* ReceiveDamageTarget);
	void OnGiveDamage(AP3Character* GiveDamageTarget);
	void OnRevive();
	void OnDownedChanged();
	void OnDead();

	class UAnimMontage* GetAnimByAction(EP3ActionAnimationType DesireAnimationType) const;
	class UAnimMontage* GetComboAnimationByTableName(const FName& AnimationName) const;
	class UAnimMontage* GetComboWeaponAnimationByTableName(const FName& AnimationName) const;
	
	int32 GetAimOffsetAnimationIndex() const;
	int32 GetCombatRunBlendSpeaceIndex() const;
	const FVector2D GetAimOffset(float Scale = 1.f) const;
	
	const FP3ComboRow* GetComboRow(const FName& ComboName = NAME_None) const;
	const bool IsInProgressRootCombo() const;
	const bool IsStaminaRegenAllowed() const;

	FString GetDebugString() const;

	FP3ComboStarted OnComboStarted;

protected:		
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bIsComboEnabled = false;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<EP3WeaponType, FP3ComboDataTable> ComboWeaponDataTable;
	
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<EP3WeaponType, UP3ComboActionMontageData*> ComboActionMontages;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<EP3WeaponType, UP3ComboMontageData*> ComboMontages;	

	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<EP3WeaponType, UP3ComboWeaponMontageData*> ComboWeaponMontages;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	UDataTable* ComboCameraTable = nullptr;

private:		
	UFUNCTION(BlueprintCallable, Category = P3)
	void OnPressLeftButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnReleaseLeftButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnPressRightButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnReleaseRightButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnPressClassButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnReleaseClassButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnPressSprintButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnReleaseSprintButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnInputMoveForward(float InValue);

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnInputMoveRight(float InValue);

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnPressJumpButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnReleaseJumpButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnStartSpecialAttackButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnStopSpecialAttackButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnPressEvadeButton();

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnReleaseEvadeButton();	

	UFUNCTION()
	void OnActionStatusChanged(int32 RequestId, EP3RequestedActionStatus Status);

	UFUNCTION()
	void OnMontageStarted(UAnimMontage* Montage);
	
	void SetComboWeapon(const UDataTable* ComboDataTable, const UDataTable* ComboEdgeDataTable);	

	void TickChangeWeapon();
	bool TickStartedCondition(float DeltaTime, const FP3ComboEdgeRow& ComboEdge);
	bool TickInProgressCondition(float DeltaTime, const FP3ComboRow& ComboRow);
	bool TickInterruptableCondition(float DeltaTime, const FP3ComboRow& ComboRow);
	void TickInputButtonPressTimeSeconds(float DeltaTime);
	void TickInputStack(float DeltaTime);	
	void TickMoveTowardsTarget();
	void TickCommand();	
	void TickCamera();	

	void StartCombo(const FP3ComboRow& ComboRow);
	void ExitCombo(const FP3ComboRow& ComboRow);
	void ProgressCombo(const FP3ComboRow& ComboRow, float DeltaTime);	
	void ResetCombo();
	void ClearCombo(bool bInputClear = true);

	bool IsInputPressHoldCondition(const FP3ComboRow& ComboRow) const;
	FString GetInputFlagsString(const FP3ComboEdgeRow& ComboEdgeRow);
	FString GetInputFlagToString(EP3ComboTableInputFlags InputFlags);
	FString GetInputDirectionTypeToString(EP3ComboTableInputDirectionType InputDirectionType);
	
	FP3ComboTableContext ComboContext;
	
	EP3WeaponType WeaponType = EP3WeaponType::None;	
	float InputFlagStackTimeSecondsForPop = 0.f;	
	
	FVector2D AimOffset = FVector2D::ZeroVector;
	FVector2D LocalControl_CrossHairPosition = FVector2D::ZeroVector;

	const static FName Name_RootCombo;
	FName CurrentComboName = Name_RootCombo;
	float CurrentComboProgressTimeSeconds = 0.f;

	TMap<FName, FP3ComboRow> ComboTable;
	TArray<FP3ComboEdgeRow> ComboEdgeTable;		

	void AddFlags(int32& InOutFlags, EP3ComboTableInputFlags AddFlags);
	void RemoveFlags(int32& InOutFlags, EP3ComboTableInputFlags RemoveFlags);

	static bool HasFlags(int32 InFlags, int32 HasFlags);
	static bool HasFlags(int32 InFlags, EP3ComboTableInputFlags HasFlags);
	static bool HasAllFlags(int32 InFlags, int32 HasAllFlags);
	static FRotator GetComboStartRotation(const FP3ComboTableContext& ComboContext, EP3ComboTableStartRotationType ComboStartRotationType);
	static EP3ComboTableInputDirectionType GetInputDirectionType(const FP3ComboTableContext& ComboContext, const FVector& ForwardVector, const FVector& RightVector);

	static bool Condition_InputFlags(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);	
	static bool Condition_InputButtonPressTimeSeconds(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);
	static bool Condition_InputDirectionType(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);
	static bool Condition_Notify(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);
	static bool Condition_Status(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);	
	static bool Condition_Action(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);
	static bool Condition_Movement(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);	
	static bool Condition_Damage(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);
	static bool Condition_Effect(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);
	static bool Condition_Target(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow);

	TArray<bool(*)(const FP3ComboTableContext&, const FP3ComboEdgeRow&)> ConditionFunctionPointers;
	TArray<bool(*)(const FP3ComboTableContext&, const FP3ComboEdgeRow&)> ConditionStartedFunctionPointers;

	static void Execution_Action(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted);
	static void Execution_Command(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted);
	static void Execution_InputFlags(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted);
	static void Execution_Camera(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted);
	static void Execution_Stamina(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted);	
	static void Execution_MoveTowardsTarget(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted);
	static void Execution_Movement(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted);
	
	TArray<void(*)(FP3ComboTableContext&, const FP3ComboRow&, const bool)> ExecutionFunctionPointers;
};
