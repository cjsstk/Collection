// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3GrassFoliageComponent.h"


UP3GrassFoliageComponent::UP3GrassFoliageComponent()
{
	OnInstanceTakePointDamage.AddDynamic(this, &UP3GrassFoliageComponent::OnInstancePointDamage);
	OnInstanceTakeRadialDamage.AddDynamic(this, &UP3GrassFoliageComponent::OnInstanceRadialDamage);
}

void UP3GrassFoliageComponent::OnInstancePointDamage(int32 InstanceIndex, float Damage, class AController* InstigatedBy, FVector HitLocation, FVector ShotFromDirection, const class UDamageType* DamageType, AActor* DamageCauser)
{
	if (!InstanceReorderTable.IsValidIndex(InstanceIndex) || InstanceReorderTable[InstanceIndex] == INDEX_NONE)
	{
		return;
	}

	RemoveInstance(InstanceIndex);
}

void UP3GrassFoliageComponent::OnInstanceRadialDamage(const TArray<int32>& Instances, const TArray<float>& Damages, class AController* InstigatedBy, FVector Origin, float MaxRadius, const class UDamageType* DamageType, AActor* DamageCauser)
{
	for (int32 InstanceIndex : Instances)
	{
		if (!InstanceReorderTable.IsValidIndex(InstanceIndex) || InstanceReorderTable[InstanceIndex] == INDEX_NONE)
		{
			continue;
		}
		RemoveInstance(InstanceIndex);
	}
}
