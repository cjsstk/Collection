// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "GameplayTagAssetInterface.h"
#include "GenericTeamAgentInterface.h"
#include "Perception/AISightTargetInterface.h"

#include "Action/P3PawnActionAnimNotifyTypes.h"
#include "Action/P3PawnActionType.h"
#include "P3ActionAnimationType.h"
#include "P3ActorInterface.h"
#include "P3AIPerceptionComponent.h"
#include "P3CharacterEmoteAnimation.h"
#include "P3CharacterStance.h"
#include "P3CharacterStore.h"
#include "P3Cms.h"
#include "P3Faction.h"
#include "P3Quest.h"
#include "P3WeaponType.h"
#include "P3Character.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnInputAction);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnOpenConsumableUI);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnCloseConsumableUI);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnNextConsumable);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnPrevConsumable);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnUseConsumable);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnThrowConsumable);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnHoldItemFromInventory);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnOpenChat);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnConnectDedi);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnDead);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnRevive);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnPickupAnimNotify);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnPutdownAnimNotify);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3CharacterOnThrowAnimNotify);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3CharacterOnActionAnimNotify, EActionAnimNotifyType, ActionAnimNotifyType);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3CharacterOnActionAnimNotifyStateBegin, EActionAnimNotifyStateType, ActionAnimNotifyStateType, float, Duration);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3CharacterOnActionAnimNotifyStateEnd, EActionAnimNotifyStateType, ActionAnimNotifyStateType);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3CharacterOnStartBuffAnimNotify, int32, StartCmsBuffKey);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3CharacterOnStoreChanged, const FP3CharacterStore&, OldStore, const FP3CharacterStore&, NewStore);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3CharacterOnInputMove, float, Value);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3CharacterOnInputLook, float, Value);

FGenericTeamId FactionToGenericTeamId(EP3Faction Faction);

extern TAutoConsoleVariable<int32> CVarP3ActionDataDriven;

/**
 * LOD step of character at server side
 */
UENUM()
enum class EP3CharacterServerLOD : uint8
{
	Normal,
	Sleep
};

USTRUCT(Blueprintable)
struct FP3CharacterDamage
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	EAnimNotifyAttackStrengthFlags AttackStrength = EAnimNotifyAttackStrengthFlags::Ignore;

	UPROPERTY(BlueprintReadOnly)
		int32 DamageAmount = 0;
};

USTRUCT(Blueprintable)
struct FP3ParkourClimbUpMontage
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly)
	float Height;

	UPROPERTY(EditDefaultsOnly)
	UAnimMontage* Montage;
};

UCLASS(Blueprintable, BlueprintType)
class UP3ParkourData : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	TArray<FP3ParkourClimbUpMontage> ClimbUpMontages;

	/** Get index of ClimbUpMontages which has nearest height value */
	int32 GetNearestClimbUpMontageIndex(float Height) const;
};

UCLASS(BlueprintType)
class P3_API UP3CharacterAnimMontageData : public UDataAsset
{
	GENERATED_BODY()

public:
	/** Optional */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn")
	UAnimMontage* Spawn;

	UPROPERTY(EditDefaultsOnly, Category = "Climbing")
	UAnimMontage* ClimbStart;

	UPROPERTY(EditDefaultsOnly, Category = "Climbing")
	UAnimMontage* ClimbJump;

	UPROPERTY(EditDefaultsOnly, Category = "Climbing")
	UAnimMontage* ClimbDown;

	UPROPERTY(EditDefaultsOnly, Category = "Climbing")
	UAnimMontage* ClimbEnd;

	UPROPERTY(EditDefaultsOnly, Category = "Climbing")
	UAnimMontage* ParkourClimb150;

	UPROPERTY(EditDefaultsOnly, Category = "Pickup")
	UAnimMontage* Pickup;

	UPROPERTY(EditDefaultsOnly, Category = "Pickup")
	UAnimMontage* PickupHodableFromGround;

	UPROPERTY(EditDefaultsOnly, Category = "Pickup")
	UAnimMontage* Putdown;

	UPROPERTY(EditDefaultsOnly, Category = "Pickup")
	UAnimMontage* Throw;

	UPROPERTY(EditDefaultsOnly, Category = "Pickup")
	UAnimMontage* ThrowOneHand;

	UPROPERTY(EditDefaultsOnly, Category = "Pickup")
	UAnimMontage* ThrowJavelin;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UAnimMontage* UsePotion;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UAnimMontage* UsePotionDuringClimbing;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UAnimMontage* BlowShofar;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UAnimMontage* SkewerEat;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UAnimMontage* PutDownForUseItem;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UAnimMontage* SetUpBomb;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UAnimMontage* EquipElemental;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	TArray<UAnimMontage*> Attacks;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	TArray<UAnimMontage*> ShieldAttacks;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* RangedAttack;
		
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* TripOver;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* BouncingJump;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* ThrowWeapon;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* RecallThrownWeapon;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* MountedAttack;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* MountedHit;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* Downed;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* DeadOnDowned;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* DownedEnd;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* Rescue;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* RescueEnd;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* ThrownAway;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* StartItemThrowAim;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* EndItemThrowAim;

	/** 구조 업기 시작 */
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	TMap<EP3RescueDirection, UAnimMontage*> CarryingOnBackStarts;

	/** 구조 업기 반복 */
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* CarryingOnBackIdle;

	/** 구조 업기 종료 */
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* CarryingOnBackEnd;

	/** 구조 업히기 시작 */
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	TMap<EP3RescueDirection, UAnimMontage*> CarriedOnBackStarts;

	/** 구조 업히기 반복 */
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* CarriedOnBackIdle;

	/** 구조 업히기 종료 */
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UAnimMontage* CarriedOnBackEnd;

	UPROPERTY(EditDefaultsOnly, Category = "CrowdControl")
	UAnimMontage* RoarStun;

	UPROPERTY(EditDefaultsOnly, Category = "Movement")
	UAnimMontage* Exhaust;

	UPROPERTY(EditDefaultsOnly, Category = "Movement")
	UAnimMontage* BuckingHangOn;
	
	UPROPERTY(EditDefaultsOnly, Category = "Movement")
	UAnimMontage* CableMove;
	
	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Interaction;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Collect;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Extract;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Catch;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Harvest;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Mining;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Pluck;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* PickupHarvestable;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* TakeOutItemFromBag;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* TakeOutAnotherItemFromBag;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* Cook;

	UPROPERTY(EditDefaultsOnly, Category = "Interaction")
	UAnimMontage* MountByRegolasMove;
};

UCLASS(BlueprintType)
class P3_API UP3CharacterAnimActionMontageData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = P3)
	TMap<EP3ActionAnimationType, UAnimMontage*> Animations;
};

UCLASS(BlueprintType)
class P3_API UP3CharacterEmoteAnimSequenceData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = P3)
	TMap<FName, FP3CharacterEmoteAnimation> Emotes;
};

UCLASS(BlueprintType)
class P3_API UP3CharacterSounds : public UDataAsset
{
	GENERATED_BODY()

public:
	USoundBase* GetHit() const { return Hits.Num() > 0 ? Hits[FMath::Rand() % Hits.Num()] : nullptr; }
	USoundBase* GetBlock() const { return  Block; }
	USoundBase* GetBreakBlock() const { return BreakBlock; }
	USoundBase* GetMountedHit() const { return MountedHit; }
	USoundBase* GetKnockBack() const { return KnockBack; }
	USoundBase* GetKnockDown() const { return KnockDown; }
	USoundBase* GetPushBack() const { return PushBack; }

private:
	UPROPERTY(EditAnywhere, Category = P3)
	TArray<USoundBase*> Hits;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* Block = nullptr;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* BreakBlock = nullptr;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* MountedHit = nullptr;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* KnockBack = nullptr;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* KnockDown = nullptr;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* PushBack = nullptr;
};

USTRUCT(BlueprintType)
struct FP3CharacterMontageActionDesc
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly)
	UAnimMontage* AnimMontage = nullptr;

	/** If set false, character is not allowed to move by it self */
	UPROPERTY(EditDefaultsOnly)
	bool bAllowMoveAndRotate = false;

	/** If set true, character is not allowed to move by it self */
	UPROPERTY(EditDefaultsOnly)
	bool bIsKnockDown = false;

	/** If set > 0, given stamina will be used when this action starts */
	UPROPERTY(EditDefaultsOnly)
	float StaminaConsume = 0.0f;

	/** character can start these actions during montage playing */
	UPROPERTY(EditDefaultsOnly)
	TArray<EPawnActionType> CanForceStartActions;

	/** character can start these montage actions during montage playing */
	UPROPERTY(EditDefaultsOnly)
	TArray<FName> CanForceStartMontageActionNames;

	/** Hit action by flammable damage ignored even if hit action contained in CanForceStartActions */
	UPROPERTY(EditDefaultsOnly)
	bool bIgnoreFireHitAction = true;
};

UENUM(Blueprintable)
enum class EHoldingKeyInputType : uint8
{
	Invalid,
	PutdownHoldable,
	Rescue,
	PickUpBackpack,
};

USTRUCT(Blueprintable)
struct FP3HoldingKeyStatus
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	EHoldingKeyInputType InputType = EHoldingKeyInputType::Invalid;

	UPROPERTY(BlueprintReadOnly)
	bool bIsHolding = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsHoldingSucceeded = false;

	UPROPERTY(BlueprintReadOnly)
	float HoldingAgeSeconds = 0;

	void StartHolding(EHoldingKeyInputType InInputType)
	{
		InputType = InInputType;
		bIsHolding = true;
		bIsHoldingSucceeded = false;
		HoldingAgeSeconds = 0;
	}
};

USTRUCT(Blueprintable)
struct FP3CharacterPart
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly)
	TArray<FName> Bones;

	UPROPERTY(EditDefaultsOnly)
	bool bIsCritical = false;

	UPROPERTY(EditDefaultsOnly)
	float DamageMultiplier = 1.0f;

	UPROPERTY(EditDefaultsOnly)
	bool bIsArmor = false;

	/** [0 ~ 1000] 1000 means 100% of HP. If not 0, part has it's own HP and if that become 0, it broke */
	UPROPERTY(EditDefaultsOnly)
	int32 HealthPointPermil = 0;

	/** If part become broken, this gameplay tag will be added to character */
	UPROPERTY(EditDefaultsOnly)
	FGameplayTagContainer GameplayTagOnBroken;
};

USTRUCT(Blueprintable)
struct FP3CharacterMountPoint
{
	GENERATED_BODY()
	
	UPROPERTY(EditDefaultsOnly)
	FName SocketName;

	/** Player can mount when closer than this distance */
	UPROPERTY(EditDefaultsOnly)
	float MountStartRadius = 200.0f;

	/** Skill id list which do a 'bucking' movement */
	UPROPERTY(EditDefaultsOnly)
	TArray<int32> BuckingSkills;

	/** This MountPoint become disable When broken part with this tag */
	UPROPERTY(EditDefaultsOnly)
	FGameplayTagContainer GameplayTagDisableByPart;
};

struct FP3CharacterInitParams
{
	charid CharacterId;
	const FText& DisplayName;
	EP3CharClass CharClass = EP3CharClass::Melee;
	FName HairName;
	FName ArmorName;
	int32 CharLevel = 0;
	int32 ExperiencePoint = 0;
	TArray<FP3CharacterItem> Items;
	TMap<questkey, FP3QuestData> Quests;
};

struct FP3CharacterInitData
{
	int32 CharLevel = 0;
	int32 ExperiencePoint = 0;
	TArray<FP3CharacterItem> Items;

	FP3CharacterInitData& operator=(const FP3CharacterInitParams& Source);
	void Clear();
	bool IsItemListEmpty() const;
};

/**
 * P3 Character
 * BAMM!
 */
UCLASS(config=Game)
class AP3Character : public ACharacter, public IGameplayTagAssetInterface, public IP3ActorInterface, public IGenericTeamAgentInterface, public IAISightTargetInterface
{
	GENERATED_BODY()

public:
	AP3Character(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	/**
	 * UObject
	 */
	virtual void PostInitProperties() override;

	/**
	 * Actor
	 */
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void SetActorHiddenInGame(bool bNewHidden) override;
	virtual void NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;
	virtual bool IsPlayerControlled() const override;
	virtual void OnRep_ReplicatedMovement() override;
	virtual void PostNetReceiveVelocity(const FVector& NewVelocity) override;
	virtual void SpawnDefaultController() override;
	virtual FVector ConsumeMovementInputVector() override;
	virtual void SetBase(UPrimitiveComponent* NewBase, const FName BoneName = NAME_None, bool bNotifyActor = true) override;
	virtual FRotator GetBaseAimRotation() const override;

	/**
	 * Events from Controller
	 */
	virtual void OnRep_Controller() override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void UnPossessed() override;

	/**
	 * Events from Movement controller 
	 */
	virtual void MoveBlockedBy(const FHitResult& Impact) override;
	virtual void Landed(const FHitResult& Hit) override;
	virtual void OnMovementModeChanged(EMovementMode PrevMovementMode, uint8 PreviousCustomMode = 0) override;
	/** return true if handled by character, otherwise movement controller handles impact */
	bool ApplyImpactPhysicsForces(const FHitResult& Impact, const FVector& ImpactAcceleration, const FVector& ImpactVelocity, float MaxSpeed);
	void OnPreMovementTick();

	/**
	 * IP3ActorInterface
	 */
	virtual actorid GetActorId() const override { return ActorId; }
	virtual void SetActorId(actorid Id) override { ActorId = Id; }
	virtual void AddGameplayTags(const FGameplayTagContainer& TagContainer) override;
	virtual void RemoveGameplayTags(const struct FGameplayTagContainer& TagContainer) override;
	virtual void AddDebugString(const FString& InDebugString, bool bAddNewLine = true) override;
	virtual void NetSerialize(FArchive& Archive) override;
	virtual class UP3StoreComponent* GetStoreComponent() const;
	virtual bool IsLevelPersistence() const override { return bLevelPersistence; }

	/**
	 * IGenericTeamAgentInterface
	 */
	virtual FGenericTeamId GetGenericTeamId() const override { return FactionToGenericTeamId(Faction); }

	/**
	 * IAISightTargetInterface
	 */
	virtual bool CanBeSeenFrom(const FVector& ObserverLocation, FVector& OutSeenLocation, int32& NumberOfLoSChecksPerformed, float& OutSightStrength, const AActor* IgnoreActor = NULL) const;

	/**
	 * Start montage action
	 * @param MontageActionName - key of MontageActionDescs
	 * @return 0 if failed. otherwise, action request id is returned
	 */
	UFUNCTION(BlueprintCallable)
	int32 StartMontageAction(const FName& MontageActionName);

	/** 
	 * Set components
	 * TODO:this function is created because of UI bug. It will be delete when the bug is fixed.
	 */
	UFUNCTION(BlueprintCallable)
	void SetAIPerceptionComponent(UP3AIPerceptionComponent* AIPerceptionComponentBP);

	/** 
	 * Get components
	 */
	UFUNCTION(BlueprintCallable)
	class UP3CharacterMovementComponent* GetP3CharacterMovementBP() const;

	UFUNCTION(BlueprintCallable)
	class UP3CombatComponent* GetP3CombatComponentBP() const { return CombatComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3ComboTableComponent* GetP3ComboComponentBP() const { return ComboTableComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3CombatResponseComponent* GetP3CombatResponseoComponent() const { return CombatResponseComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3HealthPointComponent* GetP3HealthComponentBP() const;

	UFUNCTION(BlueprintCallable)
	class UP3CharacterHealthPointComponent* GetP3CharacterHealthComponentBP() const;

	UFUNCTION(BlueprintCallable)
	class UP3AggroComponent* GetAggroComponentBP() const { return AggroComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3ThreatListComponent* GetThreatListComponent() const { return ThreatListComponent; }
	
	UFUNCTION(BlueprintCallable)
	const FP3CharacterStore& GetCharacterStoreBP() const { return CharacterStore; }

	UFUNCTION(BlueprintCallable)
	class UP3StaminaPointComponent* GetStaminaComponent() const { return StaminaComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3ExperiencePointComponent* GetExperienceComponent() const { return ExperienceComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3CharacterEffectComponent* GetEffectComponent() const { return EffectComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3PickupComponent* GetPickupComponent() const { return PickupComponent; }

	UFUNCTION(BlueprintCallable)
	class UP3PawnActionComponent* GetActionComponent() const { return ActionComponent; }
	class UP3InventoryComponent* GetInventoryComponentBP() const { return InventoryComponent; }
	class UP3CommandComponent* GetCommandComponent() const { return CommandComponent; }
	class UP3PickupComponent* GetGrabberComponent() const { return PickupComponent; }
	class UP3PushComponent* GetPushComponent() const { return PushComponent; }
	class UP3FlammableComponent* GetFlammableComponent() const { return FlammableComponent; }
	class UP3WetComponent* GetWetComponent() const { return WetComponent; }	
	class UP3ComboTableComponent* GetComboComponent() const { return ComboTableComponent; }
	class UP3CharacterTemperatureComponent* GetTemperatureComponent() const { return TemperatureComponent; }
	class UP3AIPerceptionComponent* GetAIPerceptionComponent() const { return AIPerceptionComponent; }
	class UP3QuestComponent* GetQuestComponent() const { return QuestComponent; }
	class USceneComponent* GetAudioListenerPositionComponent() const { return AudioListenerPositionComponent; }

	/**
	 * Network
	 */
	void Client_SetServerGameTimeSinceCreation(float Time) { Client_ServerGameTimeSinceCreation = Time; }
	void Client_OnDisconnected();
	void Server_SetPlayerControlled(bool bPlayerControlled);
	void NetSerializeMovement(FArchive& Archive);

	/** 
	 * Store
	 */
	void Server_InitBaseInfo(const FP3CharacterInitParams& Params);
	void Server_InitDefaultItems();
	void Standalone_InitBaseInfo();
	void SetCharacterStore(const FP3CharacterStore& InCharacterStore);
	void SetCharacterStoreByAction(const class UP3PawnAction& Action, const FP3CharacterStore& InCharacterStore);
	void SetCharacterStoreByCommand(const class UP3Command& Command, const FP3CharacterStore& InCharacterStore);
	void SetStanceByAction(const class UP3PawnAction& Action, EP3CharacterStance InStance, bool bUpdateWeaponAttachment);
	void SetStanceByCommand(const class UP3Command& Command, EP3CharacterStance InStance, bool bUpdateWeaponAttachment);
	void SetBlockingByCommand(const class UP3Command& Command, bool bIsBlocking);
	void SetCrouchBlockingByCommand(const class UP3Command& Command, bool bIsBlocking);
	void SetBouncingModeByCommand(const class UP3Command& Command, bool bIsBouncingMode);
	void SetPushingByCommand(const class UP3Command& Command, bool bIsPushing, AActor* PushingTargetActor);
	void SetKnockDownedByCommand(const class UP3Command& Command, bool bNewKnockDowned, float DurationSeconds);
	void SetGodModeByCommand(const class UP3Command& Command, bool bNewGodMode);
	void SetAimingByAction(const class UP3PawnAction& Action, bool bIsAiming);
	void SetAimingByCommand(const class UP3Command& Command, bool bIsAiming);
	void RagdollizeByAction(const class UP3PawnAction& Action, bool bRagdollize);
	void RagdollizeByCommand(const class UP3Command& Command, bool bRagdollize);	
	void SetHoldingActorByAction(const class UP3PawnAction* Action, class UP3HolderComponent* HolderComponent, AActor* HoldingActor, bool bHold);
	void SetHoldingActorByCommand(const class UP3Command& Command, class UP3HolderComponent* HolderComponent, AActor* HoldingActor, bool bHold);
	AActor* RemoveHoldingActorByAction(const class UP3PawnAction& Action, class UP3HolderComponent* HolderComponent);
	AActor* RemoveHoldingActorByCommand(const class UP3Command& Command, class UP3HolderComponent* HolderComponent);
	void SetRecallingWeaponByAction(const class UP3PawnAction& Action, class AP3Weapon* Weapon);
	void SetThrownWeaponByAction(const class UP3PawnAction& Action, const struct FP3Item& Item, class AP3Weapon* Weapon, class UP3HolderComponent* HolderComponent);
	void SetStumblingByCommand(const class UP3Command& Command, bool bIsStumbling);
	void SetTimeDelation(float TimeDilation, float DurationSeconds);
	int32 GetPartHealthPoint(int32 PartIndex) const;
	void SetPartHealthPoint(int32 PartIndex, int32 HealthPoint);
	void SetIgnoredHitAnimation(bool bInIgnoredHitAnimation);
	void SetIgnoredHitRotator(bool bInIgnoredHitRotator);

	void Server_StartStumble(float DurationSeconds);
	void Server_SetHair(const FName& HairName);
	void Server_SetArmor(const FName& ArmorName);

	bool CanCombat() const;
	bool CanBlock() const;
	bool CanAiming() const;
	bool CanThrowConsumable() const;
	bool CanHitAnimation() const;
	bool CanHitRotator() const;

	UFUNCTION(BlueprintCallable)
	bool IsPushing() const;

	bool IsPickuped() const;
	bool IsKnockDowned() const;

	bool IsCarryingBackpack() const;

	float GetStartBlcokTimeSeconds() { return StartBlockTimeSeconds; }
	float GetLastBaseChangedTimeSeconds() const { return LastBaseChangedTimeSeconds; }

	/** Attach or Detach weapon to hand base on current status */
	void ConsiderChangeWeaponAttachment();

	/** 
	 * Action
	 */
	bool IsActionCategoryDisabled(EPawnActionCategory ActionCategory) const;
	bool IsFlameHitActionIgnored() const;

	/**
	 * Gliding
	 */
	UFUNCTION(BlueprintCallable)
	bool CanGlide() const;

	bool IsGliding() const;
	void BreakGlidingByAction(class UP3PawnAction& Action);
	void BreakGlidingByCommand(class UP3Command& Command);

	/**
	 * Sliding
	 */
	bool IsSliding() const;

	/**
	 * Climbing 
	 */
	void OnStartClimb();
	bool IsClimbing() const;
	void BreakClimbingByCommand(class UP3Command& Command);

	/**
	 * Mounting
	 */
	UFUNCTION(BlueprintCallable)
	bool IsMounted() const;

	UFUNCTION(BlueprintCallable)
	bool CanMount() const;

	bool IsBuckingEnduring() const;

	/** 
	 * Carrying
	 */

	/** 부상 당한 캐릭터를 업고 있는가? */
	UFUNCTION(BlueprintCallable)
	bool IsCarryingDownedCharacter() const;

	/** 구조자에게 업혀 있는가 */
	UFUNCTION(BlueprintCallable)
	bool IsMountingByRescuer() const;

	/** 
	 * Ground
	 */
	bool IsOnGround() const;

	/**
	 * Bucking
	 */
	bool IsBucking() const { return bIsBucking; }
	void SetBuckingByCommand(const bool bInBucking) { bIsBucking = bInBucking; }

	/**
	 * Sprint
	 */
	bool CanSprint() const;

	/**
	 * Mount
	 */

	/** Return true if someone is mounted on that point */
	UFUNCTION(BlueprintCallable)
	bool HasRiderOnMountPoint(int32 MountPointIndex) const;

	/** Return true if mount point is empty and not disabled */
	bool IsMountPointAvailable(int32 MountPointIndex) const;
	
	const TArray<FP3CharacterMountPoint>& GetMountPoints() const { return MountPoints; }
	void MountByCommand(const class UP3Command& Command, AP3Character* Target, int32 MountPointIndex, bool bRescue);
	void DismountByCommand(const class UP3Command& Command);
	void SetRiderByCommand(const class UP3Command& Command, AP3Character* Rider, int32 MountPointIndex);
	void SetBuckingEndureByCommand(const class UP3Command& Command, const bool bIsBuckingEndure);

	/**
	 * Pickup downed character
	 */

	const FName& GetStuckWhenChargingMontageName() const { return StuckWhenChargingMontageName; }
	const FName& GetStuckWhenChargingWithoutHornMontageName() const { return StuckWhenChargingWithoutHornMontageName; }

	UFUNCTION(BlueprintCallable)
	bool IsLarge() const { return bIsLarge; }

	bool HasStun() const;
	bool HasControlInput() const { return !LastControlInputVector.IsNearlyZero(); }

	/** 
	 * Holdable/Weapon
	 */
	UFUNCTION(BlueprintCallable)
	bool IsHoldingFireBP() const;

	UFUNCTION(BlueprintCallable)
	bool CanThrowWeaponBP() const;

	UFUNCTION(BlueprintCallable)
	AP3Weapon* GetRecallingThrownWeaponBP() const;

	UFUNCTION(BlueprintCallable)
	EP3CharacterStance GetStanceBP() const { return CharacterStore.Stance; }
	EP3CharacterStance GetStance() const { return CharacterStore.Stance; }

	/** Called when something sharp(Javelin) is impaled this character */
	UFUNCTION(BlueprintImplementableEvent)
	void Server_ReceiveImpaled(AActor* SharpObject, const FVector& Direction, const TArray<UP3PartComponent*>& HitPartComponents);

	/**
	 * CMS
	 */
	FName GetCmsCharacterKey() const { return CmsCharacterKey; }

	/**
	 * Health bar
	 */
	UFUNCTION(BlueprintCallable)
	void Server_ShowHealthBar(bool bShow);

	UFUNCTION(BlueprintCallable)
	bool IsShowHealthBar() const { return Net_bShowHealthBar; }

	/** 
	 * Flock
	 */
	bool DoesScareFlocks() const { return bScareFlocks; }

	/**
	 * Forbidden Volume
	 */
	void AddForbiddenVolume(class AP3ForbiddenVolume* Volume);
	void RemoveForbiddenVolume(class AP3ForbiddenVolume* Volume);
	bool IsInForbiddenVolume() const;

	/**
	 * UI
	 */
	bool LocalControl_IsMainMenuUIOpened() const { return LocalControl_bMainMenuUIOpened; }
	bool LocalControl_IsBackpackUIOpened() const { return LocalControl_bBackpackUIOpened; }
	void LocalControl_SetBackpackUIOpened(bool bInOpened) { LocalControl_bBackpackUIOpened = bInOpened; }

	/**
	 * Camera
	 */
	void Client_PlayCameraShake(const FName& CmsCameraShakeKey, float Distance = 0.f);

	/**
	 * Emote
	 */
	UFUNCTION(BlueprintCallable)
	const FP3CharacterEmoteAnimation& GetEmote() const { return CharacterStore.Emote; };

	UFUNCTION(BlueprintCallable)
	bool IsInEmote() const { return CharacterStore.bInEmote; };


	UFUNCTION(BlueprintCallable)
	EP3Faction GetFactionBP() const { return Faction; }
	EP3Faction GetFaction() const { return Faction; }

	float GetCombatRollStamina() const { return CombatRollStamina; }
	float GetClimbingJumpStamina() const { return ClimbingJumpStamina; }
	float GetBreakfallStamina() const { return BreakfallStamina; }	
		
	UFUNCTION(BlueprintCallable)
	void AddGameplayTagsBP(const FGameplayTagContainer& TagContainer);

	UFUNCTION(BlueprintCallable)
	void RemoveGameplayTagsBP(const FGameplayTagContainer& TagContainer);

	UE_DEPRECATED(4.21, "Use UP3RagdollizeCommand")
	UFUNCTION(BlueprintCallable)
	void HitByLargeObjectBP(AActor* ObjectActor);

	bool IsInLookingForward() const;

	UFUNCTION(BlueprintCallable)
	bool IsRagdollizedBP() const { return CharacterStore.bIsRagdollized; }

	UFUNCTION(BlueprintCallable)
	bool IsDead() const;

	UFUNCTION(BlueprintCallable)
	bool IsDowned() const;

	UFUNCTION(BlueprintCallable)
	bool IsDeadOrDowned() const;

	UFUNCTION(BlueprintCallable)
	bool IsRescuing() const;

	UFUNCTION(BlueprintCallable)
	bool CanBeRescued() const;

	UFUNCTION(BlueprintCallable)
	bool IsBurning() const;

	/** Interaction */
	bool HasSomethingToInteract() const;

	UFUNCTION(BlueprintCallable)
	bool CanInteract() const;

	/** Revive Player */
	UFUNCTION(BlueprintCallable)
	void Revive(const FTransform& RevivePointTransform) const;

	void Server_Rescued() const;

	float GetLastDeadTimeSeconds() const { return LastDeadTimeSeconds; }
	
	const UP3CharacterAnimMontageData& GetAnimMontages() const;
	UAnimMontage* GetAnimationByType(EP3ActionAnimationType DesireAnimationType) const;	
	const FP3CharacterEmoteAnimation* FindEmoteByName(const FName& DesireEmoteName) const;
	const TMap<FName, FP3CharacterMontageActionDesc>& GetMontageActionDescs() const { return MontageActionDescs; }	
	const TArray<FP3CharacterPart>& GetParts() const { return Parts; }
	const UP3CharacterSounds* GetCharacterSounds() const;
	const UP3ParkourData* GetParkourData() const { return ParkourData; }

	UFUNCTION(BlueprintCallable)
	EP3WeaponType GetRightHandWeaponTypeBP() const { return GetRightHandWeaponType(); }
	EP3WeaponType GetRightHandWeaponType() const;

	UP3HolderComponent* GetHolderComponentByHoldType(EP3HoldType HoldType) const;
	UP3HolderComponent* GetRightHandHolderComponent() const;
	UP3HolderComponent* GetLeftHandHolderComponent() const;
	AActor* GetRightHandWeaponActor() const;
	AActor* GetHoldingActorByHoldType(EP3HoldType HoldType) const;

	UFUNCTION(BlueprintCallable)
	FP3HoldingKeyStatus GetHoldingKeyStatus() const;

	void StartAttackByAI();
	void StopAttackByAI();

	void NativeAttachWeapon();
	void NativeAttachShield();
	void NativeAttachDagger();
	void NativeAttachSupportHoldable();
	void NativeAttachElementalCatcher();
	void NativeDetachWeapon();
	void NativeDetachShield();
	void NativeDetachDagger();
	void NativeDetachSupportHoldable();
	void NativeDetachElementalCatcher();

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveCombatDamage(const FVector& HitLocation, UP3PartComponent* PartComponent);

	UFUNCTION(BlueprintCallable)
	void AddDebugStringBP(const FString& InDebugString, bool bAddNewLine = true) { AddDebugString(InDebugString, bAddNewLine); }

	UFUNCTION(BlueprintCallable)
	void Test_RagdollizeBP() { Ragdollize(); }

	UFUNCTION(BlueprintCallable)
	void Test_UnragdollizeBP() { Unragdollize(); }

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	/** Returns Valid if this object has data validation rules set up for it and the data for this object is valid. Returns Invalid if it does not pass the rules. Returns NotValidated if no rules are set for this object. */
	virtual EDataValidationResult IsDataValid(TArray<FText>& ValidationErrors) override;
#endif

	int32 GetCharLevel() const { return CharacterStore.CharLevel; }
	int32 GetExperiencePoint() const;
	void Server_SetCharLevel(int32 InLevel);

	UFUNCTION(BlueprintImplementableEvent)
	void Server_OnHitWallDuringCharging(AActor* OtherActor);

	UFUNCTION(BlueprintImplementableEvent)
	void OnCharacterDamage(const FP3CharacterDamage& CharacterDamage);


	/** Attach, Detach flag */
	void Server_AttachFlag(UClass* ActorClass);
	void Server_DetachFlag();

	/**
	 * Some debug only features
	 */
	UFUNCTION(BlueprintCallable)
	void Debug_Server_StartStumble(float DurationSeconds);

	UFUNCTION(BlueprintCallable)
	void Debug_SetStance(EP3CharacterStance Stance);

	UFUNCTION(BlueprintCallable)
	void Debug_SetSprint(bool bSprint);

protected:
	virtual void PostActorCreated() override;

	UFUNCTION(BlueprintImplementableEvent)
	void AttachDagger();

	UFUNCTION(BlueprintImplementableEvent)
	void DetachDagger();

	UFUNCTION(BlueprintImplementableEvent)
	void AttachElementalCatcher();

	UFUNCTION(BlueprintImplementableEvent)
	void DetachElementalCatcher();

	UFUNCTION(BlueprintCallable)
	void SetBreathParticleComponent(UParticleSystemComponent* InBreathParticleComponent);

	// ACharacter interface
	virtual bool CanJumpInternal_Implementation() const override;
	// End of ACharacter interface

	// APawn interface
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	// End of APawn interface

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveDeadBP();

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveReviveBP();

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveStartBlockBP();

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveStopBlockBP();

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveAttachWeapon();

	void OnToggleCursorMode();
	void OnToggleCrossHairMode();

	/** 
	 * Input Handlers
	 */

	/** Input Modifier Inputs */
	void OnPressLeftTrigger();
	void OnReleaseLeftTrigger();
	void OnPressRightTrigger();
	void OnReleaseRightTrigger();

	/** Weapon Inputs */
	void OnWeaponNormalAttackPressed();
	void OnWeaponNormalAttackReleased();
	void OnWeaponSpecialAttackPressed();
	void OnWeaponSpecialAttackReleased();	
	void OnWeaponClassAttackPressed();
	void OnWeaponClassAttackReleased();
	void OnWeaponPrivateActionPressed();
	void OnWeaponPrivateActionReleased();
	
	/** Called for jump input */
	void OnStartJump();
	void OnStopJump();

	/** Called for evade input */
	void OnStartEvade();
	void OnStopEvade();

	/** Called for attack input */
	void OnStartAttack();
	void OnStopAttack();

	/** Called for sprint input */
	void OnStartSprint();
	void OnStopSprint();

	/** Called for interact input */
	void OnStartInteract();
	void OnStopInteract();

	/** Called for aim assist input (pad only for now) */
	void OnAimAssistPressed();
	void OnAimAssistReleased();

	/** Called for throw input */
	void OnThrowPressed();
	void OnThrowReleased();

	/** Called for block input */
	void OnStartBlock();
	void OnStopBlock();
	
	/** Called for change weapon input */
	void OnStartChangeWeapon();
	void OnStopChangeWeapon();

	/** Called for put down weapon input */
	void OnStartPutDownHoldable();
	void OnStopPutDownHoldable();

	/** Resets HMD orientation in VR. */
	void OnResetVR();

	/** Toggle God Mode */
	void OnToggleGodMode();

	/** Called for forwards/backward input */
	void MoveForward(float Value);

	/** Called for side to side input */
	void MoveRight(float Value);

	void Move2D(const FVector2D& Movement);

	/** Called for camera zoom input */
	void OnCameraZoom(float Value);
	void OnToggleCameraZoom();

	/** Called for camera look assist */
	void OnLockOnPressed();
	void OnLockOnReleased();
	void OnNextLockOn();
	void OnPrevLockOn();
	void OnLookAssist();

	/** Called for PartComponent */
	void OnStartMobilePart();
	void OnStopMobilePart();

	/** Called for PartInventoryComponent */
	void OnShowInventory();

	/** Called for main menu UI */
	void OnToggleMainMenuUI();

	/** Called for using Item UI */
	void OnToggleConsumableUI();
	void OnNextConsumable();
	void OnPrevConsumable();
	void OnUseConsumable();

	/** Called for opening chatting input window */
	void OnOpenChatPressed();

	/** Called to connect/close dedi server */
	void OnConnectDediPressed();
	
	/** 
	 * Called via input to look right a given rate.
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired look rate
	 */
	void LookRight(float Rate);
	void LookRightRate(float Rate);

	/**
	 * Called via input to turn look up/down at a given rate. 
	 * @param Rate	This is a normalized rate, i.e. 1.0 means 100% of desired turn rate
	 */
	void LookUp(float Rate);
	void LookUpAtRate(float Rate);

	/** Called for turning camera to character forward */
	void OnLookForward();

	/** Handler for when a touch input begins. */
	void TouchStarted(ETouchIndex::Type FingerIndex, FVector Location);

	/** Handler for when a touch input stops. */
	void TouchStopped(ETouchIndex::Type FingerIndex, FVector Location);

private:
	/** Initialize routines */
	void Server_InitHolderComponents();
	void Server_InitHolderComponent(UP3HolderComponent* HolderComp, const struct FP3Item& Item);

	/**
	 * Store
	 */
	void SetCharacterStoreBySync(const FP3CharacterStore& InCharacterStore);

	void TickStamina();
	void TickCustomSpeedMultiplier();
	void TickCustomRotationRate();
	void TickIgnoreMoveInput();
	void TickAllowMove();
	void TickAllowRotate();
	void TickAllowJump();
	void TickAffectNavigation(float DeltaSeconds);
	void TickMovementRotationMode();
	void TickMeshUpdateFlags();
	void TickCharacterDebug();
	void TickItemDebug();
	void TickAIDebug();
	void TickMountedDebug();
	void TickAllowClimb();
	void TickAllowParkour();
	void TickEffect();
	void TickGliding();
	void TickMoveCapsuleDuringRagdoll();
	void TickUnragdollizing(float DeltaSeconds);
	void TickURO();
	void TickCollision();
	void LocalControl_TickSprinting(float DeltaSeconds);

	void Client_TickMinimapIconMeshComponent();
	void Client_TickToggleClothSimulation();
	void Client_TickBreathEffect();
	void Client_DebugDraw();

	void Server_Tick(float TickSeconds);
	void Server_TickMounting();
	void Server_TickBlocking();
	void Server_TickAiming();
	void Server_TickDestoryObjects();	
	void Server_ConsiderDismount();
	void Server_TickLOD();
	void Server_ApplyLOD();

	void LocalControl_TickCameraBoomOffset(float DeltaSeconds);
	void LocalControl_TickCameraArmLength(float DeltaSeconds);
	void LocalControl_TickCameraFOV(float DeltaSeconds);
	void LocalControl_TickConsumableUI(float DeltaSeconds);
	void LocalControl_TickCameraRotation(float DeltaSeconds);
	void LocalControl_TickConsiderMount(float DeltaSeconds);
	void LocalControl_CloseConsumableUI();

	void UpdateHairComponent();
	void UpdateArmorComponent();

	void SetCameraBoomDistance(float Distance);

	void Ragdollize();
	void Unragdollize();

	void CreateCameraAndBoom();
	void DestroyCameraAndBoom();

	void SetStanceInternal(EP3CharacterStance InStance, bool bUpdateWeaponAttachment);

	bool CanAttack() const;

	/** Triggered by HealthPointComponent */
	UFUNCTION()
	void OnDead();

	UFUNCTION()
	void OnDownedChanged(bool bDowned);

	UFUNCTION()
	void OnRevive();

	/** Triggered by HolderComponent */
	UFUNCTION()
	void OnHold(UP3HolderComponent* HolderComponnet, AActor* HoldingActor);

	UFUNCTION()
	void OnStash(UP3HolderComponent* HolderComponnet, AActor* StashingActor);

	UFUNCTION()
	void OnHolderActorRemoved(UP3HolderComponent* HolderComponnet, AActor* StashingActor);

	/** Triggered by PartComponent */
	UFUNCTION()
	void OnPartBroken(class UP3PartComponent* InPartComponent);

	/**
	 * IGameplayTagAssetInterface
	 */
	virtual void GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const override;
	
public:
	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStartAttack;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStopAttack;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStartSprint;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStopSprint;
	
	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStartSpecialAttack;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStopSpecialAttack;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStartMobilePart;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputStopMobilePart;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputShowInventory;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputOpenBackpackInventory;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputCloseBackpackInventory;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputPressLeftButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputReleaseLeftButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputPressRightButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputReleaseRightButton;	

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputPressClassButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputReleaseClassButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputPressLockOnButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputReleaseLockOnButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputNextLockOn;
	
	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputPrevLockOn;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputLookAssist;
	
	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputMove OnInputMoveForward;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputMove OnInputMoveRight;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputLook OnInputMoveLook;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputPressJumpButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputReleaseJumpButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputPressEvadeButton;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnInputAction OnInputReleaseEvadeButton;

	UPROPERTY()
	FP3CharacterOnOpenConsumableUI OnInputOpenConsumableUI;

	UPROPERTY()
	FP3CharacterOnCloseConsumableUI OnInputCloseConsumableUI;

	UPROPERTY()
	FP3CharacterOnNextConsumable OnInputNextConsumable;

	UPROPERTY()
	FP3CharacterOnPrevConsumable OnInputPrevConsumable;

	UPROPERTY()
	FP3CharacterOnUseConsumable OnInputUseConsumable;

	UPROPERTY()
	FP3CharacterOnThrowConsumable OnInputThrowConsumable;

	UPROPERTY()
	FP3CharacterOnHoldItemFromInventory OnInputHoldItemFromInventory;

	UPROPERTY()
	FP3CharacterOnOpenChat OnInputOpenChat;

	UPROPERTY()
	FP3CharacterOnConnectDedi OnInputConnectDedi;

	UPROPERTY()
	FP3CharacterOnPickupAnimNotify OnPickupAnimNotify;

	UPROPERTY()
	FP3CharacterOnPutdownAnimNotify OnPutdownAnimNotify;

	UPROPERTY()
	FP3CharacterOnThrowAnimNotify OnThrowAnimNotify;

	UPROPERTY()
	FP3CharacterOnActionAnimNotify OnActionAnimNotify;

	UPROPERTY()
	FP3CharacterOnActionAnimNotifyStateBegin OnActionAnimNotifyStateBegin;

	UPROPERTY()
	FP3CharacterOnActionAnimNotifyStateEnd OnActionAnimNotifyStateEnd;
	
	UPROPERTY()
	FP3CharacterOnStartBuffAnimNotify OnStartBuffAnimNotify;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnDead OnCharacterDead;

	UPROPERTY(BlueprintAssignable)
	FP3CharacterOnRevive OnCharacterRevive;

	UPROPERTY()
	FP3CharacterOnStoreChanged OnCharacterStoreChanged;

protected:
	/** If true, Client will load this actor from level and sync from server by name (instead of spawn new actor) */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bLevelPersistence = false;

private:

	/**
	 * Settings
	 */

	/** Team ID */
	FGenericTeamId TeamID = FGenericTeamId::NoTeam;

	/** Faction */
	UPROPERTY(EditDefaultsOnly, Category=P3)
	EP3Faction Faction;

	/** Combat Component Class */
	UPROPERTY(EditDefaultsOnly, Category=P3)
	TSubclassOf<class UP3CombatComponent> CombatComponentClass;

	/** Combo Component Class */
	UPROPERTY(EditDefaultsOnly, Category=P3)
	TSubclassOf<class UP3ComboTableComponent> ComboComponentClass;

	/** CombatResponse Component Class */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TSubclassOf<class UP3CombatResponseComponent> CombatResponseComponentClass;
	
	/** Parkour Data */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TSubclassOf<UP3ParkourData> ParkourDataClass;

	UPROPERTY()
	UP3ParkourData* ParkourData;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	UP3CharacterAnimMontageData* AnimMontageData;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	UP3CharacterAnimActionMontageData* AnimActionMontageData;

	/** Sounds lists. Filled by Default Blueprint */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	UP3CharacterSounds* Sounds = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	UP3CharacterEmoteAnimSequenceData* EmoteAnimSequenceData;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<FName, FP3CharacterMontageActionDesc> MontageActionDescs;

	/** How many stamina combat roll use? */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float CombatRollStamina = 30.0f;

	/** How many stamina climbing jump use? */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float ClimbingJumpStamina = 20.0f;

	/** How many stamina breakfall use? */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float BreakfallStamina = 30.0f;
	
	/** Minimum speed of hard landing damage */
	UPROPERTY(EditDefaultsOnly, Category=P3)
	float HardLandingDamageMinSpeed = 1000.0f;	// height = v^2 / 20  => v = sqrt(height * 20). 10m/s => 5.0m

	/** Minimum speed of hard landing damage */
	UPROPERTY(EditDefaultsOnly, Category=P3)
	float HardLandingDamagePerSpeed = 1000.0f;	// 1000 + 1000 = 20m/s => 20m height

	/** Base turn rate, in deg/sec. Other scaling may affect final turn rate. */
	UPROPERTY(EditDefaultsOnly, Category=Camera)
	float BaseLookRightRate;

	/** Base look up/down rate, in deg/sec. Other scaling may affect final rate. */
	UPROPERTY(EditDefaultsOnly, Category=Camera)
	float BaseLookUpRate;

	/** Minimum Camera Distance */
	UPROPERTY(EditDefaultsOnly, Category=Camera)
	float CameraMinDistance;

	/** Maximum Camera Distance */
	UPROPERTY(EditDefaultsOnly, Category=Camera)
	float CameraMaxDistance;

	/** Default Camera Distance */
	UPROPERTY(EditDefaultsOnly, Category=Camera)
	float CameraDefaultDistance;

	/** Camera offset during aim mode */
	UPROPERTY(EditDefaultsOnly, Category=Camera)
	FVector AimModeCameraOffset = FVector(0, 100, 50);

	/** Camera distance during range zoom mode */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	float RangeZoomCameraDistance = 100;

	/** Camera offset during sliding movement mode */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	FVector SlidingCameraOffset = FVector(0, 0, -100);

	/** Camera distance during sliding movement mode */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	float SlidingCameraDistance = 250;

	/** Large? */
	UPROPERTY(EditDefaultsOnly, Category=P3)
	bool bIsLarge = false;

	UPROPERTY(EditDefaultsOnly, Category = P3, meta = (EditCondition = "bIsLarge"))
	FName StuckWhenChargingMontageName;

	UPROPERTY(EditDefaultsOnly, Category = P3, meta = (EditCondition = "bIsLarge"))
	FName StuckWhenChargingWithoutHornMontageName;

	/** If set > 0, Actor will be destoryed after dead. Only works with non-player control */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float LifespanAfterDead = 10;

	/** Stamina consumption during sprint */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumePerSecondDuringSprint = 30.0f;

	/** Stamina consumption during charging */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumePerSecondDuringCharging = 20.0f;

	/** Stamina consumption during climbing */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumePerSecondDuringClimbing = 10.0f;

	/** Stamina consumption during blocking */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumePerSecondDuringBlocking = 10.0f;

	/** Stamina consumption during gliding */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumePerSecondDuringGliding = 8.0f;

	/** Stamina consumption during pushing */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumePerSecondDuringPushing = 10.0f;

	/** Stamina consumption during mounting */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumePerSecondDuringMounting = 10.0f;

	/** Stamina consumption Multiplier during Enduring */
	UPROPERTY(EditDefaultsOnly, Category = Stamina)
	float StaminaConsumeEnduringMultiplier = 1.5f;


	UPROPERTY(EditDefaultsOnly, Category = Combat)
	TArray<FP3CharacterPart> Parts;

	UPROPERTY(EditDefaultsOnly, Category = Combat)
	TArray<FP3CharacterMountPoint> MountPoints;

	/** If set true, flocks will be scared by this character */
	UPROPERTY(EditDefaultsOnly, Category = Flock)
	bool bScareFlocks = true;

	/** Set socket name which flag actor will be attached */
	UPROPERTY(EditDefaultsOnly, Category = Flag)
	FName FlagAttachSocketName = NAME_None;

	/**
	 * CMS
	 */

	/** Type */
	UPROPERTY(EditDefaultsOnly, Category = "P3 CMS")
	FName CmsCharacterKey;

	/** Preview (ReadyOnly) */
	UPROPERTY(VisibleDefaultsOnly, Category = "P3 CMS")
	TArray<FP3CmsCombatSkill> CombatSkills;

	UPROPERTY(EditDefaultsOnly, Category = "P3 CMS")
	FName DefaultHairName;

	/**
	 * Components 
	 */

	 /** Camera boom positioning the camera behind the character */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class USpringArmComponent* CameraBoom;

	/** Follow camera */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Camera, meta = (AllowPrivateAccess = "true"))
	class UCameraComponent* FollowCamera;

	/** Combat Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3CombatComponent* CombatComponent;

	/** Action Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3PawnActionComponent* ActionComponent;

	/** Command Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3CommandComponent* CommandComponent;

	/** Health Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3HealthPointComponent* HealthComponent;

	/** Stamina Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3StaminaPointComponent* StaminaComponent;

	/** Pickup Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3PickupComponent* PickupComponent;

	/** Push Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3PushComponent* PushComponent;

	/** Aggro Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3AggroComponent* AggroComponent;

	/** Threat List Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3ThreatListComponent* ThreatListComponent;

	/** Temperature Component */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UP3CharacterTemperatureComponent* TemperatureComponent;

	/** Flammable Component */
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UP3FlammableComponent* FlammableComponent;

	/** Wet Component */
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UP3WetComponent* WetComponent;

	/** AI Perception Component */
	UPROPERTY(Transient, VisibleAnywhere, BlueprintReadWrite, meta = (AllowPrivateAccess = "true"))
	class UP3AIPerceptionComponent* AIPerceptionComponent;

	/** Inventory Component */
	UPROPERTY(VisibleAnywhere)
	class UP3InventoryComponent* InventoryComponent;

	/** Store Component */
	UPROPERTY(VisibleAnywhere)
	class UP3StoreComponent* StoreComponent;

	UPROPERTY(Transient, VisibleAnywhere)
	class UP3EquipmentComponent* EquipmentComponent;

	/** Part Inventory Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3PartInventoryComponent* PartInventoryComponent;

	/** Part Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3CharacterEffectComponent* EffectComponent;
	
	/** Combo Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3ComboTableComponent* ComboTableComponent;

	/** CombatResponse Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3CombatResponseComponent* CombatResponseComponent;
	
	/** Hair Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class USkeletalMeshComponent* HairComponent;

	/** Armor Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class USkeletalMeshComponent* ArmorComponent;

	/** Experience Component */
	UPROPERTY(Transient, VisibleAnywhere)
	class UP3ExperiencePointComponent* ExperienceComponent;

	/** Breath Component */
	UPROPERTY(VisibleAnywhere)
	class UParticleSystemComponent* BreathParticleComponent;

	UPROPERTY(EditDefaultsOnly)
	class UStaticMeshComponent* MinimapIconMeshComponent;

	UPROPERTY(VisibleAnywhere)
	class UP3QuestComponent* QuestComponent;

	UPROPERTY(VisibleAnywhere)
	class USceneComponent* AudioListenerPositionComponent;

	/** Gameplay tag container */
	FGameplayTagContainer Net_GameplayTagContainer;

	/**
	 * Status
	 */

	actorid ActorId = INVALID_ACTORID;

	/** Store */
	UPROPERTY(Transient)
	FP3CharacterStore CharacterStore;

	/** Temporary data during initialization */
	FP3CharacterInitData InitialCharData;

	/** AController::IgnoreMoveInput is stack based, so we have to track our own value here to avoid conflict */
	bool bIgnoredMoveInput = false;

	/** Ignore hit motion when hit determination */
	bool bIgnoredHitAnimation = false;

	/** Do not look at the attack object */
	bool bIgnoredHitRotator = false;

	/** 
	 * If character doesn't move for certain time, we need to affect navigation so that other pawn can go around
	 * This is especially useful when many AI is gathered around Player. 
	 * In that case, this makes AI to go around each other and spread around player, instead of stacking at some place
	 */
	float NotMovingAgeSecondsForAffectNavigation = 0;

	/** Input modifier button state */
	bool bLeftTriggerPressed = false;
	bool bRightTriggerPressed = false;

	float StartSpirntTimeSeconds = 0.0f;
	float StartBlockTimeSeconds = 0.0f;

	/** Remember mesh relative transform to capsule so that we can restore */
	FTransform RagdollMeshTransform = FTransform::Identity;

	/** When did we Ragdollized? */
	float RagdollStartedTimeSeconds = 0;

	/** Restoring from ragdoll */
	bool bUnragollizing = false;
	float UnragdollizeAge = 0;
	FTransform UnragdollizeStartTransform = FTransform::Identity;

	bool bDefaultUseControllerDesiredRotation = false;	

	/** Camera offset */
	FVector DefaultCameraOffset = FVector(0, 0, 0);

	/** Debug string */
	FString DebugString;
	FString Net_AIDebugString;

	/** Holding key input */
	FP3HoldingKeyStatus HoldingKeyStatus;

	/** Time dilation timer */
	float TimeDilationResetTime = 0;

	/** Knock down timer */
	float Server_KnockDownFinishTime = 0;

	/** Hit damage history, needed to avoid falsely repeated hit damage */
	TMap<AActor*, float> Server_LastHitDamageTimes;

	/** Last dead time */
	float LastDeadTimeSeconds = 0.0f;

	/** Server's game time since creation. We can add this to client's GameTimeSinceCreation() to get actual age */
	float Client_ServerGameTimeSinceCreation = 0;

	bool LocalControl_RangeZoomMode = false;
	float LocalControl_CameraBoomTargetArmLength = 0;
	float LocalControl_DefaultFOV = 0;

	/** UI Status */
	bool LocalControl_bMainMenuUIOpened = false;
	bool LocalControl_bConsumableUIOpened = false;
	bool LocalControl_bBackpackUIOpened = false;
	float LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;
	float LocalControl_UseConsumableTimeSeconds = 0.0f;
	float LocalControl_MoveMenuCoolDown = 0.5f;
	float LocalControl_MoveUpMenuRemainSeconds = 0.0f;
	float LocalControl_MoveRightMenuRemainSeconds = 0.0f;

	/** LOD */
	bool Client_EnableClothSimulation = true;

	/** Stumbling */
	float Server_StumblingEndTimeSeconds = 0;

	/** Mount */
	bool bCanMount = false;
	float LastUnmountTimeSeconds = 0;
	bool bBuckingEndurePressed = false;
	UPROPERTY(Transient)
	AP3Character* MountOverlappedCharacter = nullptr;
	int32 MountOverlappedPointIndex = -1;

	/** Bucking */
	bool bIsBucking = false;

	/** Base */
	float LastBaseChangedTimeSeconds = -1.0f;

	/** Weapon attachment */
	bool bWeaponAttached = false;
	bool bShieldAttached = false;
	bool bSupportHoldableAttached = false;

	/** 
	 * P3 Net Serialization Data
	 * These are assigned by server and broadcast to client
	 */
	bool Net_bInitialized = false;
	bool Net_bAIControlled = false;
	bool Net_bPlayerControlled = false;
	bool Net_bShowHealthBar = true;
	TArray<int32> Net_PartHealthPoints;
	FRotator NetMovement_AimRotator = FRotator::ZeroRotator;

	/**
	 * LOD
	 */
	EP3CharacterServerLOD Server_LOD = EP3CharacterServerLOD::Normal;
};
