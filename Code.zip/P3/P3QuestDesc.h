// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "P3Core.h"
#include "P3QuestDesc.generated.h"

/**
 * Quest Condition
 *
 * If this condition is met, the quest goes one step further.
 */
UENUM(BlueprintType)
enum class EP3QuestConditionType : uint8
{
	None				UMETA(Hidden),
	TimeElapsed,
	PlayerEnterVolume,
	SwitchState,
	CharacterCount,
	NeverHappen,
	Logic,
	Max					UMETA(Hidden),
};

UCLASS(BlueprintType, editinlinenew, Abstract)
class UP3QuestConditionDesc : public UObject
{
	GENERATED_BODY()

public:
	UP3QuestConditionDesc()
		: ConditionType(EP3QuestConditionType::None)
	{ }

	explicit UP3QuestConditionDesc(EP3QuestConditionType InConditionType)
		: ConditionType(InConditionType)
	{ }

	UPROPERTY(VisibleDefaultsOnly, Category = "Condition")
	EP3QuestConditionType ConditionType = EP3QuestConditionType::None;

	/** This condition only needs to be met once. */
	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	bool bRequiredOnce = false;
};

/**
 * Check time elapsed since quest started.
 */
UCLASS(BlueprintType)
class UP3QuestConditionDesc_TimeElapsed : public UP3QuestConditionDesc
{
	GENERATED_BODY()

public:
	UP3QuestConditionDesc_TimeElapsed()
		: UP3QuestConditionDesc(EP3QuestConditionType::TimeElapsed)
	{ }

	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	float ElapseSeconds = 0.0f;
};

/**
 * Check player entered to QuestVolume.
 */
UCLASS(BlueprintType)
class UP3QuestConditionDesc_PlayerEnterVolume : public UP3QuestConditionDesc
{
	GENERATED_BODY()

public:
	UP3QuestConditionDesc_PlayerEnterVolume()
		: UP3QuestConditionDesc(EP3QuestConditionType::PlayerEnterVolume)
	{ }

	/** Filter to find QuestVolume. */
	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	FGameplayTagContainer FindVolumeGameplayTagsAll;
};

/**
 * Check SwitchActor's state.
 */
UCLASS(BlueprintType)
class UP3QuestConditionDesc_SwitchState : public UP3QuestConditionDesc
{
	GENERATED_BODY()

public:
	UP3QuestConditionDesc_SwitchState()
		: UP3QuestConditionDesc(EP3QuestConditionType::SwitchState)
	{ }

	/** Filter to find SwitchActor. */
	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	FGameplayTagContainer FindSwitchGameplayTagsAll;

	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	bool bCurrentSwitchState = true;
};

/**
 * Check Character's count using BoxTriggeredSwitchActor.
 */
UENUM(BlueprintType)
enum class EP3ComparisonOperator : uint8
{
	None	UMETA(Hidden),
	Equal,
	NotEqual,
	GreatherThan,
	GreatherThanOrEqual,
	LessThan,
	LessThanOrEqual,
};
UCLASS(BlueprintType)
class UP3QuestConditionDesc_CharacterCount : public UP3QuestConditionDesc
{
	GENERATED_BODY()

public:
	UP3QuestConditionDesc_CharacterCount()
		: UP3QuestConditionDesc(EP3QuestConditionType::CharacterCount)
	{ }

	/** Target actor class */
	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	TSubclassOf<class AP3Character> TargetActorClass;

	/** Filter to find P3QuestBoxTriggeredSwitchActor. */
	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	FGameplayTagContainer FindSwitchGameplayTagsAll;

	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	EP3ComparisonOperator Operator = EP3ComparisonOperator::None;

	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	int32 Operand = -1;
};

/**
 * This condition is never happen.
 *
 * @See UP3QuestPhase::bManuallyProceedable
 */
UCLASS(BlueprintType)
class UP3QuestConditionDesc_NeverHappen : public UP3QuestConditionDesc
{
	GENERATED_BODY()

public:
	UP3QuestConditionDesc_NeverHappen()
		: UP3QuestConditionDesc(EP3QuestConditionType::NeverHappen)
	{ }
};

/**
 * Condition operation.
 *
 * : AND, OR, NOT
 */
UENUM(BlueprintType)
enum class EP3QuestConditionLogicOperator : uint8
{
	None	UMETA(Hidden),
	And,
	Or,
	Not,
	Max		UMETA(Hidden),
};

UCLASS(BlueprintType)
class UP3QuestConditionDesc_Logic : public UP3QuestConditionDesc
{
	GENERATED_BODY()

public:
	UP3QuestConditionDesc_Logic()
		: UP3QuestConditionDesc(EP3QuestConditionType::Logic)
	{ }

	UPROPERTY(EditDefaultsOnly, Category = "Condition")
	EP3QuestConditionLogicOperator Operator;

	UPROPERTY(EditDefaultsOnly, Instanced, NoClear, Category = "Condition")
	TArray<UP3QuestConditionDesc*> Operands;
};

/**
 * Quest Action
 */
UENUM(BlueprintType)
enum class EP3QuestActionType : uint8
{
	None				UMETA(Hidden),
	PlaySequence,
	ToggleSwitchState,
	DeriveQuest,
	SpawnCharacter,
	SendWalkieTalkieMessage,
	LookAt,
	Max					UMETA(Hidden),
};

UCLASS(BlueprintType, editinlinenew, Abstract)
class UP3QuestActionDesc : public UObject
{
	GENERATED_BODY()

public:
	UP3QuestActionDesc()
		: ActionType(EP3QuestActionType::None)
	{ }

	explicit UP3QuestActionDesc(EP3QuestActionType InActionType)
		: ActionType(InActionType)
	{ }

	UPROPERTY(VisibleDefaultsOnly, Category = "Action")
	EP3QuestActionType ActionType = EP3QuestActionType::None;

	/** If set, Quest should wait until this action finished */
	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bWaitingFinished = false;

	/** If set, this action should be done when quest is activated */
	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bPermanentlyDone = false;
};

UCLASS(BlueprintType)
class UP3QuestActionDesc_PlaySequence : public UP3QuestActionDesc
{
	GENERATED_BODY()

public:
	UP3QuestActionDesc_PlaySequence()
		: UP3QuestActionDesc(EP3QuestActionType::PlaySequence)
	{
		bWaitingFinished = false;
	}

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	class ULevelSequence* LevelSequence;

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bDisableMovementInput = true;

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bDisableLookAtInput = true;

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bHidePlayer = false;

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bHideHud = true;

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bDisableCameraCuts = false;

	// todo : not implemented yet
	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bDisableActionInput = true;
};

UCLASS(BlueprintType)
class UP3QuestActionDesc_ToggleSwitch : public UP3QuestActionDesc
{
	GENERATED_BODY()

public:
	UP3QuestActionDesc_ToggleSwitch()
		: UP3QuestActionDesc(EP3QuestActionType::ToggleSwitchState)
	{ }

	/** Filter to find SwitchActor. */
	UPROPERTY(EditDefaultsOnly, Category = "Action")
	FGameplayTagContainer FindSwitchGameplayTagsAll;

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bNewSwitchState = false;
};

/**
 * This action is for sequential quest.
 *
 * Do not place this action in the middle of action list.
 */
UCLASS(BlueprintType)
class UP3QuestActionDesc_DeriveQuest : public UP3QuestActionDesc
{
	GENERATED_BODY()

public:
	UP3QuestActionDesc_DeriveQuest()
		: UP3QuestActionDesc(EP3QuestActionType::DeriveQuest)
	{ }

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	UP3QuestDesc* NextQuest;
};

/**
 * Spawn AP3Character.
 */
UCLASS(BlueprintType)
class UP3QuestActionDesc_SpawnCharacter : public UP3QuestActionDesc
{
	GENERATED_BODY()

public:
	UP3QuestActionDesc_SpawnCharacter()
		: UP3QuestActionDesc(EP3QuestActionType::SpawnCharacter)
	{ }

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	TSubclassOf<class AP3Character> SpawnCharacterClass;

	/** Filter to find QuestSpot. */
	UPROPERTY(EditDefaultsOnly, Category = "Action")
	FGameplayTagContainer FindSpotGameplayTagsAll;
};

/**
 * Send WalkieTalkie message.
 */
UCLASS(BlueprintType)
class UP3QuestActionDesc_SendWalkieTalkieMessage : public UP3QuestActionDesc
{
	GENERATED_BODY()

public:
	UP3QuestActionDesc_SendWalkieTalkieMessage()
		: UP3QuestActionDesc(EP3QuestActionType::SendWalkieTalkieMessage)
	{ }

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	FText Message;

	UPROPERTY(EditDefaultsOnly, Category = "Action")
	bool bBroadcast = false;
};

/**
 * Look at (spot).
 */
UCLASS(BlueprintType)
class UP3QuestActionDesc_LookAt : public UP3QuestActionDesc
{
	GENERATED_BODY()

public:
	UP3QuestActionDesc_LookAt()
		: UP3QuestActionDesc(EP3QuestActionType::LookAt)
	{ }

	/** Filter to find QuestSpot. */
	UPROPERTY(EditDefaultsOnly, Category = "Action")
	FGameplayTagContainer FindSpotGameplayTagsAll;
};

/**
 * Quest Phase
 */
UCLASS(BlueprintType, editinlinenew)
class P3_API UP3QuestPhaseDesc : public UObject
{
	GENERATED_BODY()

public:
	/* Explanation shown in Quest UI (for player) */
	UPROPERTY(EditDefaultsOnly, Category = "Phase")
	FText PhaseDescription;

	/** If set, you can cut in to this phase. (from previous phases). */
	UPROPERTY(EditAnywhere, Category = "Phase")
	bool bInterceptable = false;

	/** If set, you can manually proceed to next step. */
	UPROPERTY(EditAnywhere, Category = "Phase")
	bool bManuallyProceedable = false;

	UPROPERTY(EditAnywhere, Instanced, NoClear, Category = "Conditions")
	TArray<UP3QuestConditionDesc*> QuestConditions;

	UPROPERTY(EditAnywhere, Instanced, NoClear, Category = "Actions")
	TArray<UP3QuestActionDesc*> QuestActions;
};

/**
 * Quest
 */
UCLASS(BlueprintType)
class P3_API UP3QuestDesc : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "P3Quest")
	FText QuestName;

	/* Explanation shown in Quest UI (for player) */
	UPROPERTY(EditDefaultsOnly, Category = "P3Quest")
	FText QuestDescription;

	/* Generally phases is proceeded in order. (Check UP3QuestPhaseDesc.bInterceptable) */
	UPROPERTY(EditAnywhere, Instanced, Category = "P3Quest|Phases")
	TArray<UP3QuestPhaseDesc*> QuestPhases;
};
