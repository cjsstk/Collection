// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3StaticMeshComponent.h"
#include "P3Core.h"
#include "P3World.h"
#include "Engine/CollisionProfile.h"

UP3StaticMeshComponent::UP3StaticMeshComponent()
{

}

void UP3StaticMeshComponent::NetSerialize(FArchive& Archive)
{
	if (Archive.IsLoading())
	{
		UStaticMesh* TempStaticMesh(nullptr);

		Archive << TempStaticMesh;

		SetStaticMesh(TempStaticMesh);
	}
	else
	{
		UStaticMesh* TempStaticMesh = GetStaticMesh();

		Archive << TempStaticMesh;
	}
}


AP3StaticMeshActor::AP3StaticMeshActor()
{
	StaticMeshComponent = CreateDefaultSubobject<UP3StaticMeshComponent>(TEXT("StaticMeshComponent0"));
	StaticMeshComponent->SetCollisionProfileName(UCollisionProfile::BlockAll_ProfileName);
	StaticMeshComponent->Mobility = EComponentMobility::Movable;
	StaticMeshComponent->SetGenerateOverlapEvents(false);
	StaticMeshComponent->bUseDefaultCollision = true;

	RootComponent = StaticMeshComponent;
}
