// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ExperiencePointComponent.h"

#include "P3Core.h"
#include "P3World.h"
#include "P3Character.h"
#include "P3PlayerController.h"

UP3ExperiencePointComponent::UP3ExperiencePointComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UP3ExperiencePointComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3ExperiencePointComponent::OnRegister()
{
	Super::OnRegister();
}

void UP3ExperiencePointComponent::OnUnregister()
{
	Super::OnUnregister();
}

void UP3ExperiencePointComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UP3ExperiencePointComponent::NetSerialize(FArchive& Archive)
{
	if (!Archive.IsLoading())
	{
		Archive << ExperiencePoint;
	}
	else
	{
		int32 NewExperiencePoint = 0;

		Archive << NewExperiencePoint;

		if (NewExperiencePoint != ExperiencePoint)
		{
			ExperiencePoint = NewExperiencePoint;
		}
	}
}

void UP3ExperiencePointComponent::Server_InitExperiencePoint(int32 InExperiencePoint, int32 InCharLevel)
{
	if (GetOwner() && ensure(P3Core::IsP3NetModeServerInstance(*GetOwner())))
	{
		ExperiencePoint = InExperiencePoint;
		SetMaxExperiencePoint(InCharLevel);
	}
}

int32 UP3ExperiencePointComponent::GetMaxExperiencePoint() const
{
	return MaxExperiencePoint;
}

void UP3ExperiencePointComponent::SetMaxExperiencePoint(int32 CharLevel)
{
	const FP3CmsCharacterExperiencePoint* CmsExperiencePoint = P3Cms::GetCharacterExperiencePoint(CharLevel);
	if (CmsExperiencePoint)
	{
		MaxExperiencePoint = CmsExperiencePoint->MaxExperiencePoint;
	}
	else
	{
		/** TODO: Temporary max value */
		MaxExperiencePoint = CharLevel * 10000;
	}
}

void UP3ExperiencePointComponent::Server_AddExperiencePoint(int32 InExperiencePoint)
{
	if (GetOwner() && ensure(P3Core::IsP3NetModeServerInstance(*GetOwner())))
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());

		if (!ensure(Character))
		{
			return;
		}

		const int32 OldCharLevel = Character->GetCharLevel();
		int32 IncreaseCharLevel = 0;

		while (InExperiencePoint > 0)
		{
			const int32 NeedExperiencePoint = GetMaxExperiencePoint() - ExperiencePoint;
			if (InExperiencePoint >= NeedExperiencePoint)
			{
				InExperiencePoint -= NeedExperiencePoint;
				ExperiencePoint = 0;
				++IncreaseCharLevel;
				SetMaxExperiencePoint(OldCharLevel + IncreaseCharLevel);
			}
			else
			{
				ExperiencePoint += InExperiencePoint;
				break;
			}
		}

		if (IncreaseCharLevel > 0)
		{
			Character->Server_SetCharLevel(OldCharLevel + IncreaseCharLevel);
		}

		Server_SetDirty(*this);
	}
}
