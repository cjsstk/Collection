// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3CmsTypes.h"
#include "P3ItemComponent.generated.h"

UCLASS(ClassGroup = (P3))
class P3_API UP3ItemComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3ItemComponent();

	virtual void OnRegister() override;
	virtual void OnUnregister() override;

	itemkey GetItemKey() const { return ItemKey; }
	const struct FP3CmsItem& GetCmsItem() const;

private:

	UPROPERTY(VisibleAnywhere, Category = "Item")
	int32 ItemKey = INVALID_ITEMKEY;
};
