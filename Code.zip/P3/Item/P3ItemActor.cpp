// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3ItemActor.h"

#include "Components/CapsuleComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"

#include "P3Character.h"
#include "P3Cms.h"
#include "P3ConsumableComponent.h"
#include "P3DestructibleComponent.h"
#include "P3IngredientComponent.h"
#include "P3ItemComponent.h"
#include "P3PickupableComponent.h"

const FName AP3ItemActor::ItemRootComponent(TEXT("ItemRootComponent"));

void AP3ItemActor::DisablePawnCollisionUntilLeaveCharacter(class AP3Character& Character)
{
	TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
	GetComponents(PrimComps);

	for (UPrimitiveComponent* PrimComp : PrimComps)
	{
		SavedCollisionResponse.Add(PrimComp, PrimComp->GetCollisionResponseToChannel(ECC_Pawn));

		PrimComp->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
	}

	DisableCollisionCharacter = &Character;
	CurrentDisableCollisionDuration = MaxDisableCollisionDuration;

	SetActorTickEnabled(true);
}

AP3ItemActor::AP3ItemActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	ItemComponent = CreateDefaultSubobject<UP3ItemComponent>(TEXT("ItemComponent"));
	RootComponent = CreateOptionalDefaultSubobject<USceneComponent>(AP3ItemActor::ItemRootComponent);

	PickupableComponent = CreateDefaultSubobject<UP3PickupableComponent>(TEXT("PickupableComponent"));
	if (PickupableComponent)
	{
		PickupableComponent->SetPickupableType(EP3PickupableType::Item);
		PickupableComponent->SetPickupToInventory(true);
		PickupableComponent->SetDoNotRotateDuringPickup(false);
	}

	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.bStartWithTickEnabled = false;
}

void AP3ItemActor::BeginPlay()
{
	Super::BeginPlay();

	const FP3CmsItem* CmsItem = nullptr;
	itemkey ItemKey = INVALID_ITEMKEY;

	if (ensure(ItemComponent))
	{
		CmsItem = &ItemComponent->GetCmsItem();
		ItemKey = ItemComponent->GetItemKey();
	}

	if (CmsItem && ensure(PickupableComponent))
	{
		PickupableComponent->SetPickupableDisplayName(CmsItem->DisplayName);
	}

	if (CmsItem && CmsItem->bIsIngredient)
	{
		IngredientComponent = NewObject<UP3IngredientComponent>(this, TEXT("IngredientComponent"));
		IngredientComponent->RegisterComponent();
	}

	const FP3CmsConsumable* CmsConsumable = P3Cms::GetItemConsumable(ItemKey);

	if (CmsConsumable)
	{
		ConsumableComponent = NewObject<UP3ConsumableComponent>(this, TEXT("ConsumableComponent"));
		ConsumableComponent->RegisterComponent();
	}
}

void AP3ItemActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (DisableCollisionCharacter)
	{
		TArray<UPrimitiveComponent*> OverlappedComponents;

		GetOverlappingComponents(OverlappedComponents);

		if (!OverlappedComponents.Contains(DisableCollisionCharacter->GetMesh())
			&& !OverlappedComponents.Contains(DisableCollisionCharacter->GetRootComponent())
			)
		{
			RestorePawnCollision();
			return;
		}

		CurrentDisableCollisionDuration -= DeltaTime;
		if (CurrentDisableCollisionDuration <= 0.0f)
		{
			RestorePawnCollision();
			return;
		}
	}
}

void AP3ItemActor::RestorePawnCollision()
{
	if (GetAttachParentActor())
	{
		ensure(0);
		return;
	}

	TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
	GetComponents(PrimComps);

	for (UPrimitiveComponent* PrimComp : PrimComps)
	{
		ECollisionResponse* CollisionResponse = SavedCollisionResponse.Find(PrimComp);
		if (CollisionResponse)
		{
			PrimComp->SetCollisionResponseToChannel(ECC_Pawn, *CollisionResponse);
		}
	}

	DisableCollisionCharacter = nullptr;

	SetActorTickEnabled(false);
}

AP3SphereItemActor::AP3SphereItemActor(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<USphereComponent>(AP3ItemActor::ItemRootComponent))
{
	SphereComponent = Cast<USphereComponent>(RootComponent);
	if (SphereComponent)
	{
		// Use a sphere as a simple collision representation
		SphereComponent->InitSphereRadius(5.0f);
		SphereComponent->SetCollisionProfileName(TEXT("Item"));
		SphereComponent->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
		SphereComponent->SetCanEverAffectNavigation(false);
		SphereComponent->CanCharacterStepUpOn = ECB_No;
		SphereComponent->SetSimulatePhysics(true);
		SphereComponent->SetGenerateOverlapEvents(true);
	}
}

AP3StaticMeshItemActor::AP3StaticMeshItemActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<UStaticMeshComponent>(AP3ItemActor::ItemRootComponent))
{
	StaticMeshComponent = Cast<UStaticMeshComponent>(RootComponent);
	if (StaticMeshComponent)
	{
		StaticMeshComponent->SetCollisionProfileName(TEXT("Item"));
		StaticMeshComponent->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
		StaticMeshComponent->SetCanEverAffectNavigation(false);
		StaticMeshComponent->CanCharacterStepUpOn = ECB_No;
		StaticMeshComponent->SetSimulatePhysics(true);
		StaticMeshComponent->SetGenerateOverlapEvents(true);
	}
}

AP3DestructibleItemActor::AP3DestructibleItemActor(const FObjectInitializer& ObjectInitializer /*= FObjectInitializer::Get()*/)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<UP3DestructibleComponent>(AP3ItemActor::ItemRootComponent))
{
	DestructibleComponent = Cast<UP3DestructibleComponent>(RootComponent);
	if (DestructibleComponent)
	{
		DestructibleComponent->SetCollisionProfileName(TEXT("Item"));
		DestructibleComponent->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
		DestructibleComponent->SetCanEverAffectNavigation(false);
		DestructibleComponent->CanCharacterStepUpOn = ECB_No;
		DestructibleComponent->SetSimulatePhysics(true);
		DestructibleComponent->SetGenerateOverlapEvents(true);
	}
}
