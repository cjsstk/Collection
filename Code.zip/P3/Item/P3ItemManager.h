// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3Item.h"
#include "P3ItemManager.generated.h"

/**
 * 아이템 매니저
 * Game Instance 당 1개가 생성됨
 * 아이템 생성과 제거, 스택 개수 변경을 관리
 */
UCLASS()
class UP3ItemManager : public UObject
{
	GENERATED_BODY()

public:
	void InitializeItemManager(class UP3GameInstance* InGameInstance);

	FP3Item CreateItem(itemkey ItemKey, int32 Stack, const FString& ContextString);

private:
	class UP3GameInstance* GameInstance = nullptr;
};
