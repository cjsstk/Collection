// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3ItemActor.generated.h"

/**
 * Item Actor
 *	do not use directly. Consider static mesh version first
 */
UCLASS(NotBlueprintable)
class P3_API AP3ItemActor : public AP3Actor
{
	GENERATED_BODY()
	
public:
	AP3ItemActor(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

	void DisablePawnCollisionUntilLeaveCharacter(class AP3Character& Character);

	class UP3ItemComponent* GetItemComponent() const { return ItemComponent; }

	const static FName ItemRootComponent;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

private:
	void RestorePawnCollision();

	UPROPERTY(Transient)
	class UP3ItemComponent* ItemComponent;

	UPROPERTY(Transient)
	class UP3PickupableComponent* PickupableComponent;

	UPROPERTY(Transient)
	class UP3IngredientComponent* IngredientComponent;

	UPROPERTY(Transient)
	class UP3ConsumableComponent* ConsumableComponent;

	UPROPERTY(Transient)
	class AP3Character* DisableCollisionCharacter;

	UPROPERTY(EditDefaultsOnly)
	float MaxDisableCollisionDuration = 3.0f;

	float CurrentDisableCollisionDuration = 0.0f;

	TMap<UPrimitiveComponent*, ECollisionResponse> SavedCollisionResponse;

};


/**
 * Sphere Item Actor
 *
 * Item with sphere collision as root
 * This is useful if item mesh needs some transform
 */
UCLASS(Blueprintable)
class P3_API AP3SphereItemActor : public AP3ItemActor
{
	GENERATED_BODY()

public:
	AP3SphereItemActor(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

private:
	UPROPERTY(VisibleDefaultsOnly, Category = Item)
	class USphereComponent* SphereComponent;
};


/**
 * Static mesh Item Actor
 */
UCLASS(Blueprintable)
class P3_API AP3StaticMeshItemActor : public AP3ItemActor
{
	GENERATED_BODY()

public:
	AP3StaticMeshItemActor(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

private:
	UPROPERTY(VisibleDefaultsOnly, Category = Item)
	class UStaticMeshComponent* StaticMeshComponent;
};


/**
 * Destructible Item Actor
 */
UCLASS(Blueprintable)
class P3_API AP3DestructibleItemActor : public AP3ItemActor
{
	GENERATED_BODY()

public:
	AP3DestructibleItemActor(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());

private:
	UPROPERTY(VisibleDefaultsOnly, Category = Item)
	class UP3DestructibleComponent* DestructibleComponent;
};
