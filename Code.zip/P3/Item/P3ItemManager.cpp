// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ItemManager.h"

#include "P3GameInstance.h"
#include "P3IdGenerator.h"
#include "P3Item.h"
#include "P3Log.h"

void UP3ItemManager::InitializeItemManager(class UP3GameInstance* InGameInstance)
{
	GameInstance = InGameInstance;
}

FP3Item UP3ItemManager::CreateItem(itemkey ItemKey, int32 Stack, const FString& ContextString)
{
	if (!ensure(GameInstance))
	{
		return FP3Item();
	}

	const FP3ItemId ItemId = FP3ItemId::FromUInt64(GameInstance->GetItemIdGenerator().Generate());

	if (!ensure(ItemId != INVALID_ITEMID))
	{
		P3JsonLog(Error, "Failed to create item. Id gen failed.",
			TEXT("Context"), ContextString,
			TEXT("ItemKey"), ItemKey,
			TEXT("Stack"), Stack);
		return FP3Item();
	}

	const FP3Item Item = FP3Item(ItemId, ItemKey, Stack);

	P3JsonLog(Log, "Item Created",
		TEXT("Context"), ContextString,
		TEXT("ItemId"), ItemId,
		TEXT("ItemKey"), ItemKey,
		TEXT("Stack"), Stack);

	return Item;
}
