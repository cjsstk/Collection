// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UnrealTemplate.h"

#include "P3Core.h"
#include "P3Cms.h"
#include "P3Item.generated.h"

USTRUCT(BlueprintType)
struct FP3ItemId
{
	GENERATED_BODY()

	/** High 32bit of Id */
	UPROPERTY(EditDefaultsOnly)
	uint32 High = 0;

	/** Low 32bit of Id */
	UPROPERTY(EditDefaultsOnly)
	uint32 Low = 0;

	static FP3ItemId FromUInt64(uint64 Id);
	uint64 ToUInt64() const { return (uint64)High << 32 | Low; }
	FString ToString() const { return FString::Printf(TEXT("%llu"), ToUInt64()); }
	bool Increase();

	bool operator==(const FP3ItemId& Other) const { return High == Other.High && Low == Other.Low; }
	bool operator!=(const FP3ItemId& Other) const { return !operator==(Other); }
	bool operator<(const FP3ItemId& Other) const { return High < Other.High || (High == Other.High && Low < Other.Low); }
	bool operator>(const FP3ItemId& Other) const { return  Other.operator<(*this); }
	bool operator<=(const FP3ItemId& Other) const { return !operator>(Other); }
	bool operator>=(const FP3ItemId& Other) const { return !operator<(Other); }
};

FArchive& operator<<(FArchive& Ar, FP3ItemId& ItemId);

const static FP3ItemId INVALID_ITEMID;

USTRUCT(BlueprintType)
struct FP3Item
{
	GENERATED_BODY()

	// USTRUCT requires default constructor :(
	FP3Item()
		: Id(INVALID_ITEMID)
		, Key(INVALID_ITEMKEY)
		, Stack(0)
	{}

	FP3Item(FP3ItemId InId, int32 InCmsKey, int32 InStack)
		: Id(InId)
		, Key(InCmsKey)
		, Stack(InStack)
	{}

	/** Unique Id among all item instances */
	UPROPERTY(EditDefaultsOnly)
	FP3ItemId Id = INVALID_ITEMID;

	/** CMS Key */
	UPROPERTY(EditDefaultsOnly)
	int32 Key = INVALID_ITEMKEY;

	/** Item Count */
	UPROPERTY(EditDefaultsOnly)
	int32 Stack = 0;

	static const FP3Item InvalidItem;

	bool IsValid() const { return Id != INVALID_ITEMID && Key != INVALID_ITEMKEY && Stack > 0; }

	bool operator==(const FP3Item& Other) const { return Id == Other.Id && Key == Other.Key && Stack == Other.Stack; }
};

FArchive& operator<<(FArchive& Ar, FP3Item& Item);

class UP3WorldNetBase;
class UP3InventoryComponent;

struct FP3CharacterItem
{
	FP3Item Item = FP3Item::InvalidItem;
	EP3CharacterItemSlot Slot = EP3CharacterItemSlot::Invalid;

	bool operator==(const FP3CharacterItem& Other) const { return Item == Other.Item && Slot == Other.Slot; }
	bool operator!=(const FP3CharacterItem& Other) const { return !operator==(Other); }
};

inline FArchive& operator<<(FArchive& Ar, FP3CharacterItem& CharacterItem)
{
	Ar << CharacterItem.Item;
	Ar << CharacterItem.Slot;
	return Ar;
}

struct FP3ItemUtil : FNoncopyable
{
	static FP3ItemId GenerateItemId(const UObject* Object);
	static FP3ItemId GenerateTempItemId(const UObject* Object);
	static EP3CharacterItemSlot GetCharacterItemSlotFromHoldType(EP3HoldType HoldType);
	static EP3HoldType GetHoldTypeFromCharacterItemSlot(EP3CharacterItemSlot Slot);

	/**
	 * Spawn Item Actors
	 */

	/** Spawn Weapon Actor */
	static AActor* Server_SpawnWeaponActorFromInventory(UP3InventoryComponent& InventoryComp, FP3ItemId ItemId);

	/** Spawn Item Actor */
	static AActor* SpawnItemActor(UWorld* World, itemkey ItemKey);

private:
	FP3ItemUtil() = delete;
};
