// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Item.h"

#include "Network/P3WorldNet.h"
#include "P3GameInstance.h"
#include "P3IdGenerator.h"
#include "P3InventoryComponent.h"
#include "P3Log.h"
#include "P3Test.h"

#if P3_BUILD_WITH_TEST

#include "AutomationTest.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3ItemIdConversionTest, "P3.ItemId.Conversion", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3ItemIdConversionTest::RunTest(const FString& Parameters)
{
	uint64 Id = 0x0102030405060708ull;
	FP3ItemId ItemId = FP3ItemId::FromUInt64(Id);

	P3_ASSERT_EQUAL(ItemId.High, 0x01020304ul);
	P3_ASSERT_EQUAL(ItemId.Low, 0x05060708ul);

	P3_ASSERT_EQUAL(ItemId.ToUInt64(), Id);
	P3_ASSERT_EQUAL_STR(ItemId.ToString(), "72623859790382856");

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3ItemIdIncreaseTest, "P3.ItemId.Increase", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3ItemIdIncreaseTest::RunTest(const FString& Parameters)
{
	FP3ItemId ItemId = FP3ItemId::FromUInt64(0x0000000000000000ull);

	P3_ASSERT_TRUE(ItemId.Increase());
	P3_ASSERT_EQUAL(ItemId.High, 0x00000000ul);
	P3_ASSERT_EQUAL(ItemId.Low, 0x00000001ul);

	P3_ASSERT_TRUE(ItemId.Increase());
	P3_ASSERT_EQUAL(ItemId.High, 0x00000000ul);
	P3_ASSERT_EQUAL(ItemId.Low, 0x00000002ul);

	ItemId.Low = 0xFFFFFFFFul;
	P3_ASSERT_TRUE(ItemId.Increase());
	P3_ASSERT_EQUAL(ItemId.High, 0x00000001ul);
	P3_ASSERT_EQUAL(ItemId.Low, 0x00000000ul);

	P3_ASSERT_TRUE(ItemId.Increase());
	P3_ASSERT_EQUAL(ItemId.High, 0x00000001ul);
	P3_ASSERT_EQUAL(ItemId.Low, 0x00000001ul);

	ItemId.Low = 0xFFFFFFFFul;
	P3_ASSERT_TRUE(ItemId.Increase());
	P3_ASSERT_EQUAL(ItemId.High, 0x00000002ul);
	P3_ASSERT_EQUAL(ItemId.Low, 0x00000000ul);

	P3_ASSERT_TRUE(ItemId.Increase());
	P3_ASSERT_EQUAL(ItemId.High, 0x00000002ul);
	P3_ASSERT_EQUAL(ItemId.Low, 0x00000001ul);

	ItemId.High = 0xFFFFFFFFul;
	ItemId.Low = 0xFFFFFFFFul;
	P3_ASSERT_FALSE(ItemId.Increase());
	P3_ASSERT_EQUAL(ItemId.High, 0xFFFFFFFFul);
	P3_ASSERT_EQUAL(ItemId.Low, 0xFFFFFFFFul);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3ItemIdComparisonTest, "P3.ItemId.Comparison", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3ItemIdComparisonTest::RunTest(const FString& Parameters)
{
	FP3ItemId ItemId11 = FP3ItemId::FromUInt64(0x1111111111111111ull);
	FP3ItemId ItemId12 = FP3ItemId::FromUInt64(0x1111111122222222ull);
	FP3ItemId ItemId21 = FP3ItemId::FromUInt64(0x2222222211111111ull);
	FP3ItemId ItemId22 = FP3ItemId::FromUInt64(0x2222222222222222ull);

	P3_ASSERT_EQUAL(ItemId11 == ItemId11, true); // -V501
	P3_ASSERT_EQUAL(ItemId11 == ItemId12, false);
	P3_ASSERT_EQUAL(ItemId11 == ItemId21, false);
	P3_ASSERT_EQUAL(ItemId11 == ItemId22, false);

	P3_ASSERT_EQUAL(ItemId12 == ItemId11, false);
	P3_ASSERT_EQUAL(ItemId12 == ItemId12, true); // -V501
	P3_ASSERT_EQUAL(ItemId12 == ItemId21, false);
	P3_ASSERT_EQUAL(ItemId12 == ItemId22, false);

	P3_ASSERT_EQUAL(ItemId21 == ItemId11, false);
	P3_ASSERT_EQUAL(ItemId21 == ItemId12, false);
	P3_ASSERT_EQUAL(ItemId21 == ItemId21, true); // -V501
	P3_ASSERT_EQUAL(ItemId21 == ItemId22, false);

	P3_ASSERT_EQUAL(ItemId22 == ItemId11, false);
	P3_ASSERT_EQUAL(ItemId22 == ItemId12, false);
	P3_ASSERT_EQUAL(ItemId22 == ItemId21, false);
	P3_ASSERT_EQUAL(ItemId22 == ItemId22, true); // -V501

	P3_ASSERT_EQUAL(ItemId11 != ItemId11, false); // -V501
	P3_ASSERT_EQUAL(ItemId11 != ItemId12, true);
	P3_ASSERT_EQUAL(ItemId11 != ItemId21, true);
	P3_ASSERT_EQUAL(ItemId11 != ItemId22, true);

	P3_ASSERT_EQUAL(ItemId11 < ItemId11, false); // -V501
	P3_ASSERT_EQUAL(ItemId11 < ItemId12, true);
	P3_ASSERT_EQUAL(ItemId11 < ItemId21, true);
	P3_ASSERT_EQUAL(ItemId11 < ItemId22, true);

	P3_ASSERT_EQUAL(ItemId12 < ItemId11, false);
	P3_ASSERT_EQUAL(ItemId12 < ItemId12, false); // -V501
	P3_ASSERT_EQUAL(ItemId12 < ItemId21, true);
	P3_ASSERT_EQUAL(ItemId12 < ItemId22, true);

	P3_ASSERT_EQUAL(ItemId21 < ItemId11, false);
	P3_ASSERT_EQUAL(ItemId21 < ItemId12, false);
	P3_ASSERT_EQUAL(ItemId21 < ItemId21, false); // -V501
	P3_ASSERT_EQUAL(ItemId21 < ItemId22, true);

	P3_ASSERT_EQUAL(ItemId22 < ItemId11, false);
	P3_ASSERT_EQUAL(ItemId22 < ItemId12, false);
	P3_ASSERT_EQUAL(ItemId22 < ItemId21, false);
	P3_ASSERT_EQUAL(ItemId22 < ItemId22, false); // -V501

	P3_ASSERT_EQUAL(ItemId11 > ItemId11, false); // -V501
	P3_ASSERT_EQUAL(ItemId11 > ItemId12, false);
	P3_ASSERT_EQUAL(ItemId11 > ItemId21, false);
	P3_ASSERT_EQUAL(ItemId11 > ItemId22, false);

	P3_ASSERT_EQUAL(ItemId11 <= ItemId11, true); // -V501
	P3_ASSERT_EQUAL(ItemId11 <= ItemId12, true);
	P3_ASSERT_EQUAL(ItemId11 <= ItemId21, true);
	P3_ASSERT_EQUAL(ItemId11 <= ItemId22, true);

	P3_ASSERT_EQUAL(ItemId11 >= ItemId11, true); // -V501
	P3_ASSERT_EQUAL(ItemId11 >= ItemId12, false);
	P3_ASSERT_EQUAL(ItemId11 >= ItemId21, false);
	P3_ASSERT_EQUAL(ItemId11 >= ItemId22, false);

	return true;
}

#endif // P3_BUILD_WITH_TEST

const FP3Item FP3Item::InvalidItem(INVALID_ITEMID, INVALID_ITEMKEY, 0);

FP3ItemId FP3ItemId::FromUInt64(uint64 Id)
{
	FP3ItemId ItemId;
	ItemId.High = (uint32)(Id >> 32);
	ItemId.Low = (uint32)(Id & 0xFFFFFFFF);
	return ItemId;
}

bool FP3ItemId::Increase()
{
	if (Low < 0xFFFFFFFFul)
	{
		++Low;
		return true;
	}

	if (High < 0xFFFFFFFFul)
	{
		++High;
		Low = 0ul;
		return true;
	}

	return false;
}

FArchive& operator<<(FArchive& Ar, FP3ItemId& ItemId)
{
	Ar << ItemId.High;
	Ar << ItemId.Low;
	return Ar;
}

FArchive& operator<<(FArchive& Ar, FP3Item& Item)
{
	Ar << Item.Id;
	Ar << Item.Key;
	Ar << Item.Stack;
	return Ar;
}

FP3ItemId FP3ItemUtil::GenerateItemId(const UObject* Object)
{
	FP3IdGenerator* Generator = P3GetItemIdGenerator(Object);
	if (!ensure(Generator))
	{
		return INVALID_ITEMID;
	}

	return FP3ItemId::FromUInt64(Generator->Generate());
}

FP3ItemId FP3ItemUtil::GenerateTempItemId(const UObject* Object)
{
	FP3IdGenerator* Generator = P3GetItemIdGenerator(Object);
	if (!ensure(Generator))
	{
		return INVALID_ITEMID;
	}

	return FP3ItemId::FromUInt64(Generator->Generate(false));
}

EP3CharacterItemSlot FP3ItemUtil::GetCharacterItemSlotFromHoldType(EP3HoldType HoldType)
{
	switch (HoldType)
	{
	case EP3HoldType::LeftHand: return EP3CharacterItemSlot::LeftHand;
	case EP3HoldType::RightHand: return EP3CharacterItemSlot::RightHand;
	}

	return EP3CharacterItemSlot::Invalid;
}

EP3HoldType FP3ItemUtil::GetHoldTypeFromCharacterItemSlot(EP3CharacterItemSlot Slot)
{
	switch (Slot)
	{
	case EP3CharacterItemSlot::LeftHand: return EP3HoldType::LeftHand;
	case EP3CharacterItemSlot::RightHand: return EP3HoldType::RightHand;
	}

	return EP3HoldType::Count;
}

AActor* FP3ItemUtil::SpawnItemActor(UWorld* World, itemkey ItemKey)
{
	if (!ensure(World))
	{
		return nullptr;
	}

	UClass* ActorClass = P3Cms::GetActorClassFromItemKey(ItemKey);

	if (!ensure(ActorClass))
	{
		return nullptr;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AActor* Actor = World->SpawnActor<AActor>(ActorClass, SpawnParams);

	return Actor;
}

AActor* FP3ItemUtil::Server_SpawnWeaponActorFromInventory(UP3InventoryComponent& InventoryComp, FP3ItemId ItemId)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(InventoryComp)))
	{
		return nullptr;
	}

	if (ItemId == INVALID_ITEMID)
	{
		return nullptr;
	}

	UWorld* World = InventoryComp.GetWorld();

	if (!World)
	{
		return nullptr;
	}

	const FP3Item Item = InventoryComp.GetItem(ItemId);

	AActor* WeaponActor = FP3ItemUtil::SpawnItemActor(World, Item.Key);

	return WeaponActor;
}
