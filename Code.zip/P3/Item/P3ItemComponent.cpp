// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ItemComponent.h"

#include "P3Cms.h"

UP3ItemComponent::UP3ItemComponent()
{

}

void UP3ItemComponent::OnRegister()
{
	Super::OnRegister();

	AActor* OwnerActor = GetOwner();

	if (OwnerActor)
	{
		ItemKey = P3Cms::GetItemKeyFromActorClass(OwnerActor->GetClass());
	}
}

void UP3ItemComponent::OnUnregister()
{
	Super::OnUnregister();
}

const FP3CmsItem& UP3ItemComponent::GetCmsItem() const
{
	return P3Cms::GetItem(ItemKey);
}
