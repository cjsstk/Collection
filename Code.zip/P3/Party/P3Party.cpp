// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Party.h"

#include "Network/P3ChatNet.h"

FP3Party::FP3Party(partyid InPartyId)
	: PartyId(InPartyId)
{
}

void FP3Party::AddPartyMember(uint32 WorldDediId, const FString& CharName, EP3CharClass CharClass, int32 CharLevel)
{
	Members.Add(CharName, FP3PartyMember(WorldDediId, CharName, CharClass, CharLevel));
}

void FP3Party::RemovePartyMember(const FString& CharName)
{
	Members.Remove(CharName);
}

uint32 FP3Party::GetMemberCount() const
{
	return Members.Num();
}
