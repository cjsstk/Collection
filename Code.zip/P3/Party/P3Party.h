// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3Cms.h"
#include "P3Core.h"

#include "P3Party.generated.h"

struct FP3PartyMember
{
	explicit FP3PartyMember(const FString& InCharName)
		: WorldDediId(0)
		, CharName(InCharName)
		, CharClass(EP3CharClass::Invalid)
		, CharLevel(0)
	{
	}

	FP3PartyMember(const FString& InCharName, EP3CharClass InCharClass, int32 InCharLevel)
		: WorldDediId(0)
		, CharName(InCharName)
		, CharClass(InCharClass)
		, CharLevel(InCharLevel)
	{
	}

	FP3PartyMember(uint32 InWorldDediId, const FString& InCharName, EP3CharClass InCharClass, int32 InCharLevel)
		: WorldDediId(InWorldDediId)
		, CharName(InCharName)
		, CharClass(InCharClass)
		, CharLevel(InCharLevel)
	{
	}

	uint32 WorldDediId = 0;
	FString CharName;
	EP3CharClass CharClass;
	int32 CharLevel;
};

USTRUCT()
struct FP3PartyMembers
{
	GENERATED_BODY()

	FP3PartyMembers() {}
	explicit FP3PartyMembers(bool bInAdd) : bAdd(bInAdd) {}

	bool bAdd = false;
	TArray<FP3PartyMember> PartyMemberList;
};

struct FP3Party
{
public:
	FP3Party() {}

	explicit FP3Party(partyid InPartyId);

	void SetPartyId(partyid InPartyId) { PartyId = InPartyId; }
	partyid GetPartyId() const { return PartyId; }

	void AddPartyMember(uint32 WorldDediId, const FString& CharName, EP3CharClass CharClass, int32 CharLevel);
	void RemovePartyMember(const FString& CharName);

	uint32 GetMemberCount() const;

private:
	partyid PartyId = NON_PARTY_ID;

	TMap<FString, FP3PartyMember> Members;
};
