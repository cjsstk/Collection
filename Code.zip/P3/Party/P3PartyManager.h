// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3Party.h"

/**
 * 파티 매니저
 * Game Instance 당 1개가 생성됨
 * 파티 생성과 제거를 관리
 */

class FP3PartyManager
{
public:
	FP3PartyManager() {}

	void InitializePartyManager(class UP3GameInstance* InGameInstance);

	FP3Party* GetParty(partyid PartyId);
	FP3Party* CreateParty(partyid PartyId);
	FP3Party& Client_GetOrAddParty(partyid PartyId);

	void RemoveParty(partyid PartyId);

	void SetWorldDediConnId(uint32 InWorldDediId) { WorldDediId = InWorldDediId; }

private:
	UP3GameInstance* GameInstance = nullptr;

	TMap<partyid, FP3Party> PartyList;

	// 파티멤버가 이 데디서버에 접속한 플레이어인지 판단하기 위한 아이디 (world-dedi-listener로 부터 받음)
	uint32 WorldDediId = 0;
};
