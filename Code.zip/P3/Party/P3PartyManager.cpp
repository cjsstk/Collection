// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PartyManager.h"

#include "P3GameInstance.h"

void FP3PartyManager::InitializePartyManager(UP3GameInstance* InGameInstance)
{
	GameInstance = InGameInstance;
}

FP3Party* FP3PartyManager::GetParty(partyid PartyId)
{
	FP3Party* Party = PartyList.Find(PartyId);
	return Party;
}

FP3Party* FP3PartyManager::CreateParty(partyid PartyId)
{
	return &PartyList.Add(PartyId, FP3Party(PartyId));
}

FP3Party& FP3PartyManager::Client_GetOrAddParty(partyid PartyId)
{
	return PartyList.FindOrAdd(PartyId);
}

void FP3PartyManager::RemoveParty(partyid PartyId)
{
	PartyList.Remove(PartyId);
}
