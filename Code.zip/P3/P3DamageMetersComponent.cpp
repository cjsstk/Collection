// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3DamageMetersComponent.h"

#include "P3ActorInterface.h"
#include "P3Character.h"
#include "P3World.h"

void UP3DamageMetersComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3DamageMetersComponent::OnRegister()
{
	Super::OnRegister();
}

void UP3DamageMetersComponent::OnUnregister()
{
	Super::OnUnregister();
}

void UP3DamageMetersComponent::NetSerialize(FArchive& Archive)
{
	FP3DamageMetersStore::StaticStruct()->SerializeBin(Archive, &Net_MetersStore); //-V2001

	if (Archive.IsLoading())
	{
		Net_MetersStore.Meters.ValueSort([](const FP3DamageMeter& A, const FP3DamageMeter& B)
		{
			return A.DamageAmount > B.DamageAmount;
		});
	}
}

FP3DamageMeter* UP3DamageMetersComponent::FindOrAddMeter(AActor* SourceActor)
{
	actorid SourceActorId = INVALID_ACTORID;

	if (SourceActor)
	{
		IP3ActorInterface* P3Actor = Cast<IP3ActorInterface>(SourceActor);
		
		if (P3Actor)
		{
			SourceActorId = P3Actor->GetActorId();
		}
	}

	FP3DamageMeter* Meter = Net_MetersStore.Meters.Find(SourceActorId);

	if (!Meter)
	{
		FString SourceName = "Unknown";
		AP3Character* Character = Cast<AP3Character>(SourceActor);

		if (Character)
		{
			SourceName = Character->GetCharacterStoreBP().DisplayName.ToString();
		}
		else if (SourceActor)
		{
			SourceName = SourceActor->GetName();
		}

		FP3DamageMeter NewMeter;
		NewMeter.SourceName = SourceName;

		Meter = &Net_MetersStore.Meters.Add(SourceActorId, NewMeter);
	}
	
	return Meter;
}

void UP3DamageMetersComponent::Server_AddDamage(AActor* SourceActor, int32 Damage)
{
	AActor* Owner = GetOwner();

	if (!ensure(Owner && P3Core::IsP3NetModeServerInstance(*Owner)))
	{
		return;
	}

	FP3DamageMeter* Meter = FindOrAddMeter(SourceActor);
	if (ensure(Meter))
	{
		Meter->DamageAmount += Damage;

		++Net_MetersStore.Version;

		Server_SetDirty(*this);
	}
}

void UP3DamageMetersComponent::Server_AddKill(AActor* SourceActor)
{
	AActor* Owner = GetOwner();

	if (!ensure(Owner && P3Core::IsP3NetModeServerInstance(*Owner)))
	{
		return;
	}

	FP3DamageMeter* Meter = FindOrAddMeter(SourceActor);
	if (ensure(Meter))
	{
		++Meter->NumKills;

		++Net_MetersStore.Version;

		Server_SetDirty(*this);

		//AP3Character* MyCharacter = Cast<AP3Character>(Owner);
		//if (MyCharacter && MyCharacter->IsLarge())
		//{
		//	int32 NumTotalKills = 0;
		//	for (auto&& Iter : Net_MetersStore.Meters)
		//	{
		//		const FP3DamageMeter& IterMeter = Iter.Value;
		//		NumTotalKills += IterMeter.NumKills;
		//	}

		//	if (NumTotalKills >= CVarP3BossFailKillCount.GetValueOnGameThread())
		//	{
		//		Owner->Destroy(true);
		//	}
		//}
	}
}
