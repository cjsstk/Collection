// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "Components/ActorComponent.h"
#include "P3Store.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3OnStoreSynced);

UCLASS(Blueprintable)
class UP3StoreBase : public UObject
{
	GENERATED_BODY()

public:
	void SetStoreComponent(class UP3StoreComponent* InStoreComp) { StoreComponent = InStoreComp; }
	class UP3StoreComponent* GetStoreComponent() const { return StoreComponent; }

	void OnStoreChanged() const;
	
	FP3OnStoreSynced OnStoreSynced;

private:
	UPROPERTY()
	class UP3StoreComponent* StoreComponent = nullptr;
};

UCLASS()
class P3_API UP3StoreComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3StoreComponent();

	virtual void BeginPlay() override;

	void WriteNetBuffer(TArray<struct FP3NetStoreData>& OutData, const TSet<FName>* ComponentNames) const;
	void SyncWithNetBuffer(class UNetConnection* Connection, const TArray<struct FP3NetStoreData>& NetData);

	void RegisterStore(UObject* Owner, UP3StoreBase* Store);
	void UnregisterStore(UObject* Owner, UP3StoreBase* Store);

	/** Callback from UP3StoreBase */
	void OnStoreChanged(const UP3StoreBase& Store);
	
	//void RequestSync();
	//void RequestDelayedSync();
	void Sync(const TArray<UObject*>& Objects, const TArray<UP3StoreBase*>& Stores);
	   
	const TMap<UObject*, UP3StoreBase*>& GetStoreMap() const { return StoreMap; }

private:
	/** Owner to Store map */
	UPROPERTY()
	TMap<UObject*, UP3StoreBase*> StoreMap;
};
