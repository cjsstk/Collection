// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3LootDropComponent.h"

#include "Engine/World.h"
#include "GameplayTagAssetInterface.h"
#include "GameFramework/Actor.h"
#include "TimerManager.h"

#include "P3Core.h"
#include "P3Destructible.h"
#include "P3DestructibleComponent.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3PickupableComponent.h"

UP3LootDropComponent::UP3LootDropComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

void UP3LootDropComponent::BeginPlay()
{
	Super::BeginPlay();

}

void UP3LootDropComponent::Server_RollDiceAndDrop()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const TArray<FP3LootDropResultItem>& DropItems = P3Loot::RollDice(ItemContainer);

	for (const FP3LootDropResultItem& Item : DropItems)
	{
		Server_Drop(Item);
	}
}

void UP3LootDropComponent::Server_RollDiceAndDropBP()
{
	Server_RollDiceAndDrop();
}

void UP3LootDropComponent::Server_AddLootItems(const FP3LootItemContainer& Container)
{
	ItemContainer.Items.Append(Container.Items);
}

void UP3LootDropComponent::Server_Drop(const FP3LootDropResultItem& Item)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(GetWorld()))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();

	if (!ensure(OwnerActor) || !ensure(OwnerActor->GetRootComponent()))
	{
		return;
	}

	if (!ensure(Item.SpawnActor.Get()))
	{
		return;
	}

	// See if gameplaytag is required
	if (NoDropGameplayTag.Num() > 0)
	{
		IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(GetOwner());
		if (GameplayTagAsset)
		{
			const bool bHasDropGameplayTag = GameplayTagAsset->HasAnyMatchingGameplayTags(NoDropGameplayTag);

			if (bHasDropGameplayTag)
			{
				return;
			}
		}
	}


	FTransform SpawnTransform = GetComponentTransform();

	if (!Item.SpawnSocketName.IsNone())
	{
		TInlineComponentArray<USceneComponent*> SceneComponents;
		OwnerActor->GetComponents(SceneComponents);

		for (const USceneComponent* SceneComp : SceneComponents)
		{
			if (SceneComp->DoesSocketExist(Item.SpawnSocketName))
			{
				SpawnTransform = SceneComp->GetSocketTransform(Item.SpawnSocketName);
				break;
			}
		}
	}

	SpawnTransform.SetScale3D(FVector(1.0f));

	FActorSpawnParameters Params;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AActor* SpawnedActor = GetWorld()->SpawnActor(Item.SpawnActor.Get(), &SpawnTransform, Params);
	if (ensure(SpawnedActor))
	{
		SpawnedActor->SetLifeSpan(Item.LifeSpanAfterDrop);
	}
}

void UP3LootDropOnDeadComponent::OnComponentCreated()
{
	Super::OnComponentCreated();

	if (!P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		DestroyComponent();
	}
}

void UP3LootDropOnDeadComponent::BeginPlay()
{
	Super::BeginPlay();

	if (!GetOwner())
	{
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		// Since health component might be created dynamically on BeginPlay(), this is too early to find it. Lets wait for one frame
		// ex) AP3Destructible::BeginPlay()
		GetWorld()->GetTimerManager().SetTimerForNextTick(FTimerDelegate::CreateUObject(this, &UP3LootDropOnDeadComponent::Server_BindToDeadEvent));
	}
}

void UP3LootDropOnDeadComponent::Server_BindToDeadEvent()
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	UP3HealthPointComponent* HealthComp = GetOwner()->FindComponentByClass<UP3HealthPointComponent>();
	if (ensure(HealthComp))
	{
		HealthComp->OnDead.AddUniqueDynamic(this, &UP3LootDropOnDeadComponent::Server_OnDead);
	}
}

void UP3LootDropOnDeadComponent::Server_OnDead()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_RollDiceAndDrop();
}

void UP3LootDropOnFractureComponent::OnComponentCreated()
{
	Super::OnComponentCreated();

	if (!P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		DestroyComponent();
	}
}

void UP3LootDropOnFractureComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		AP3Destructible* Destructible = Cast<AP3Destructible>(GetOwner());
		UP3DestructibleComponent* DestructibleComponent = Cast<UP3DestructibleComponent>(GetAttachParent());

		if (!Destructible && !DestructibleComponent)
		{
			ensure(0);
			P3JsonLog(Error, "Loot drop on fracture component is attached to actor which is not P3Destructible and not P3DestructibleComponent",
				TEXT("Actor"), GetOwner()->GetName());
		}
		else
		{
			// Since health component might be created dynamically on BeginPlay(), this is too early to find it. Lets wait for one frame
			// ex) AP3Destructible::BeginPlay()
			GetWorld()->GetTimerManager().SetTimerForNextTick(FTimerDelegate::CreateUObject(this, &UP3LootDropOnFractureComponent::Server_BindToFractureEvent));
		}
	}
}

void UP3LootDropOnFractureComponent::Server_BindToFractureEvent()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Destructible* Destructible = Cast<AP3Destructible>(GetOwner());

	if (Destructible)
	{
		Destructible->DestructibleFractured.AddUniqueDynamic(this, &UP3LootDropOnFractureComponent::Server_OnFracture);
	}
	else
	{
		UP3DestructibleComponent* DestructibleComponent = Cast<UP3DestructibleComponent>(GetAttachParent());

		if (ensure(DestructibleComponent))
		{
			DestructibleComponent->DestructibleFractured.AddUniqueDynamic(this, &UP3LootDropOnFractureComponent::Server_OnComponentFracture);
		}
	}
}

void UP3LootDropOnFractureComponent::Server_OnFracture(class AP3Destructible* Destructible)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_RollDiceAndDrop();
}

void UP3LootDropOnFractureComponent::Server_OnComponentFracture(class UP3DestructibleComponent* DestructibleComponent)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_RollDiceAndDrop();
}

void UP3LootDropOnPickupComponent::OnComponentCreated()
{
	Super::OnComponentCreated();

	if (!P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		DestroyComponent();
	}
}

void UP3LootDropOnPickupComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		// Since some component might be created dynamically on BeginPlay(), this is too early to find it. Lets wait for one frame
		GetWorld()->GetTimerManager().SetTimerForNextTick(FTimerDelegate::CreateUObject(this, &UP3LootDropOnPickupComponent::Server_BindEvent));
	}
}

void UP3LootDropOnPickupComponent::Server_BindEvent()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();
	UP3PickupableComponent* PickupableComp = OwnerActor ? OwnerActor->FindComponentByClass<UP3PickupableComponent>() : nullptr;
	if (ensure(PickupableComp))
	{
		PickupableComp->Server_PickupStarted.AddUniqueDynamic(this, &UP3LootDropOnPickupComponent::Server_PickupStarted);
	}
}

void UP3LootDropOnPickupComponent::Server_PickupStarted(class UP3PickupableComponent* PickupableComponent, class AActor* PickupperActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const float Now = GetWorld()->GetTimeSeconds();

	if (CooldownSeconds > 0 && Now < Server_NextCooldownFinishedTimeSeconds)
	{
		return;
	}

	Server_RollDiceAndDrop();

	if (CooldownSeconds > 0)
	{
		Server_NextCooldownFinishedTimeSeconds = Now + CooldownSeconds;
	}
}

const TArray<FP3LootDropResultItem> P3Loot::RollDice(const FP3LootItemContainer& Container)
{
	TArray<FP3LootDropResultItem> DropItems;

	for (const FP3LootItem& Item : Container.Items)
	{
		const int32 Dice = FMath::Rand() % 10000;

		if (Dice < Item.ChancePer10000)
		{
			FP3LootDropResultItem DropItem;
			DropItem.SpawnActor = Item.SpawnActor;
			DropItem.SpawnSocketName = Item.SpawnSocketName;
			DropItem.LifeSpanAfterDrop = Item.LifeSpanAfterDrop;
			DropItems.Add(DropItem);
		}
	}

	return DropItems;
}

const FP3LootDropResultItem P3Loot::RollDiceAndPickOne(const FP3LootItemContainer& Container)
{
	FP3LootDropResultItem DropItem;

	for (const FP3LootItem& Item : Container.Items)
	{
		const int32 Dice = FMath::Rand() % 10000;

		if (Dice < Item.ChancePer10000)
		{
			DropItem.SpawnActor = Item.SpawnActor;
			DropItem.SpawnSocketName = Item.SpawnSocketName;
			DropItem.LifeSpanAfterDrop = Item.LifeSpanAfterDrop;
		}
	}

	return DropItem;
}
