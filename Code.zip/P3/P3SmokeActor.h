// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3SmokeActor.generated.h"

/**
 *
 */
UCLASS()
class P3_API AP3SmokeActor : public AP3Actor
{
	GENERATED_BODY()


public:
	AP3SmokeActor();

	void SpawnSmoke();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaTime) override;

private:
	UPROPERTY(VisibleAnywhere)
	class USphereComponent* SphereComponent = nullptr;

	UPROPERTY(VisibleAnywhere)
	class UDecalComponent* DecalComponent = nullptr;

	UPROPERTY(EditDefaultsOnly)
	class UParticleSystem* SmokeParticle;

	UPROPERTY(EditDefaultsOnly)
	float SmokeParticleLiftTime = 5.0f;

	class UParticleSystemComponent* ParticleComp = nullptr;
	float CurrentSmokeLifeTime = 0.0f;
	bool bSmokeEnd = false;
	bool bHitFound = false;
};
