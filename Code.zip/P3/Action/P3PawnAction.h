// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"

#include "Containers/CircularBuffer.h"

#include "Item/P3Item.h"
#include "P3ActionAnimationType.h"
#include "P3AnimNotifyGenerator.h"
#include "P3CharacterStance.h"
#include "P3Cms.h"
#include "P3Core.h"
#include "P3ComboTable.h"
#include "P3DamageType.h"
#include "P3HoldType.h"
#include "P3PawnActionType.h"
#include "P3PawnActionAnimNotifyTypes.h"
#include "P3WeaponType.h"
#include "P3PawnAction.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3PawnActionFinished, UP3PawnAction*, Action);


/** 
 * Pawn Action Status
 */
UENUM(Blueprintable)
enum class EP3PawnActionStatus : uint8
{
	Idle,		// Default
	InProgress,
	Finished
};

UENUM(Blueprintable)
enum class EP3PawnActionResult : uint8
{
	Success,
	Failed,		// Failed by internal issue
	Aborted		// Stopped by outsider
};

/** 
 * Start action request params
 * Made by requester (mostly autonomous, sometimes authority)
 * This should not be trusted
 */
USTRUCT(BlueprintType)
struct FP3PawnActionStartRequestParams
{
	GENERATED_BODY()

	/**
	 * Common data. Do not modify.
	 * Filled by Action components
	 */
	UPROPERTY()
	int32 AutonomousRequestId = 0;

	UPROPERTY()
	int32 ServerRequestId = 0;

	/** 
	 * Combat Roll 
	 */
	UPROPERTY()
	FRotator Roll_Rotator = FRotator::ZeroRotator;

	UPROPERTY()
	FVector Roll_Direction = FVector::ZeroVector;

	UPROPERTY()
	FVector Roll_CharacterForwardVector = FVector::ZeroVector;

	/** 
	 * Pickup
	 */
	UPROPERTY()
	AActor* Pickup_ObjectActor = nullptr;

	UPROPERTY()
	FName Pickup_AttachSocketName;

	/** 
	 * Pickup Holdable
	 */
	UPROPERTY()
	FP3ActorPointerAndId PickupHoldable_ObjectActor;

	UPROPERTY()
	EP3HoldType PickupHoldable_HolderType = EP3HoldType::Count;

	/**
	 * Pickup Consumable
	 */
	UPROPERTY()
	FP3ActorPointerAndId PickupConsumable_ObjectActor;

	/**
	 * Pickup Backpack
	 */
	UPROPERTY()
	AActor* PickupBackpack_BackpackActor = nullptr;

	UPROPERTY()
	FName PickupBackpack_AttachSocketName;

	/**
	 * Use Consumable
	 */
	UPROPERTY()
	FP3ItemId UseConsumable_ItemId;

	UPROPERTY()
	bool UseConsumable_bHoldItemOnConsume;

	UPROPERTY()
	bool UseConsumable_bDestoryHoldingItemOnUseNotify;

	/**
	 * Hold Item from Inventory
	 */
	UPROPERTY()
	FP3ItemId HoldItemFromInventory_ItemId;

	/**
	 * Interact
	 */
	UPROPERTY()
	FP3ActorPointerAndId Interact_InteracteeActor;

	UPROPERTY()
	bool Interact_bHoldLootItemOnInteract = false;

	/**
	 * Switching
	 */
	UPROPERTY()
	FP3ActorPointerAndId Switching_SwitchActor;

	UPROPERTY()
	bool Switching_bOn = false;

	/** 
	 * Putdown
	 */
	UPROPERTY()
	FName Putdown_AttachSocketName;

	/** 
	 * Putdown Holdable
	 */
	UPROPERTY()
	FP3ActorPointerAndId PutdownHoldable_ObjectActor;

	UPROPERTY()
	FString PutdownHoldable_HolderComponentName;

	/**
	 * Throw
	 */
	UPROPERTY()
	FRotator Throw_Rotator = FRotator::ZeroRotator;

	/**
	 * Change Holdable
	 */
	UPROPERTY()
	EP3HoldType ChangeHoldable_RightHoldType = EP3HoldType::Count;

	UPROPERTY()
	EP3HoldType ChangeHoldable_LeftHoldType = EP3HoldType::Count;

	UPROPERTY()
	FP3ItemId ChangeHoldable_InvenToRightHolderItemId;

	UPROPERTY()
	FP3ItemId ChangeHoldable_InvenToLeftHolderItemId;

	UPROPERTY()
	FP3Item ChangeHoldable_HolderToRightInvenItem = FP3Item::InvalidItem;
		
	UPROPERTY()
	FP3Item ChangeHoldable_HolderToLeftInvenItem = FP3Item::InvalidItem;

	UPROPERTY()
	bool ChangeHoldable_bRemovePrevWeaponAfterChange = false;

	/** 
	 * Combat Attack
	 */
	UPROPERTY()
	FP3ActorPointerAndId CombatAttack_Target;

	UPROPERTY()
	FRotator CombatAttack_ChracterRotator = FRotator::ZeroRotator;

	UPROPERTY()
	bool CombatAttack_bIsShieldAttack = false;

	UPROPERTY()
	bool CombatAttack_bIsMountedAttack = false;

	UPROPERTY()
	int32 CombatAttack_MontageIndex = 0;

	UPROPERTY()
	int32 CombatAttack_SkillIndex = -1;

	UPROPERTY()
	FVector CombatAttack_MoveInputLocalVector = FVector::ZeroVector;

	UPROPERTY()
	bool CombatAttack_bIsTurningAttack = false;

	UPROPERTY()
	int32 CombatAttack_TurningAttackIndex = 0;

	UPROPERTY()
	bool CombatAttack_bFinishOnMontageBlendingOut = false;

	/**
	 * Combat Ranged Attack
	 */
	UPROPERTY()
	FRotator CombatRangedAttack_CharacterRotator = FRotator::ZeroRotator;

	/**
	 * Combat Projectile Skill Attack
	 */
	UPROPERTY()
	int32 CombatProjectileSkillAttack_SkillIndex = -1;

	/** Half height of target */
	UPROPERTY()
	float CombatProjectileSkillAttack_TargetHalfHeight = 0.0f;

	UPROPERTY()
	FVector CombatProjectileSkillAttack_TargetLocation = FVector::ZeroVector;

	/** 
	 * Combat Hit
	 */
	UPROPERTY()
	float CombatHit_Damage = 0;

	UPROPERTY()
	EP3DamageType CombatHit_DamageType = EP3DamageType::Combat;

	UPROPERTY()
	bool CombatHit_bIsCriticalPart = false;

	UPROPERTY()
	bool CombatHit_bIsArmorPart = false;

	UPROPERTY()
	bool CombatHit_bIsKnockDown = false;

	UPROPERTY()
	bool CombatHit_bBreakBlock = false;

	UPROPERTY()
	bool CombatHit_bIsPushBack = false;

	UPROPERTY()
	float CombatHit_KnockDownDurationSeconds = 0.0f;

	UPROPERTY()
	FP3ActorPointerAndId CombatHit_SourceActor;

	UPROPERTY()
	EP3WeaponType CombatHit_WeaponType = EP3WeaponType::None;

	/** Impact direction in world space */
	UPROPERTY()
	FVector CombatHit_ImpactDirection = FVector::ZeroVector;

	/** Impact direction in target actor space */
	UPROPERTY()
	FVector CombatHit_ImpactLocalDirection = FVector::ZeroVector;

	UPROPERTY()
	FVector CombatHit_Location = FVector::ZeroVector;

	/** Push back impulse in world space */
	UPROPERTY()
	FVector CombatHit_Impulse = FVector::ZeroVector;

	/** Rotate target actor */
	UPROPERTY()
	FRotator CombatHit_Rotator = FRotator::ZeroRotator;

	/** 
	 * Combat Block
	 */
	UPROPERTY()
	FVector CombatBlock_ImpulseVelocity = FVector::ZeroVector;

	UPROPERTY()
	FRotator CombatBlock_Rotator = FRotator::ZeroRotator;

	UPROPERTY()
	bool CombatBlock_bIsProjectile = false;

	UPROPERTY()
	float CombatBlock_ConsumeStamina = 0.f;

	/** Hit by large character? */
	UPROPERTY()
	bool CombatBlock_bHardBlock = false;

	/**
	 * Throw Weapon
	 */
	UPROPERTY()
	FVector ThrowWeapon_Direction = FVector::ZeroVector;

	/**
	 * Recall Thrown Weapon
	 */
	UPROPERTY()
	EP3HoldType RecallThrownWeapon_HoldType = EP3HoldType::Count;

	UPROPERTY()
	FP3Item RecallThrownWeapon_WeaponItem = FP3Item::InvalidItem;

	UPROPERTY()
	FP3ActorPointerAndId RecallThrownWeapon_WeaponActor;

	/**
	 * Combo
	 */
	UPROPERTY()
	FName Combo_Name = NAME_None;

	UPROPERTY()
	FRotator Combo_ChracterRotator = FRotator::ZeroRotator;
	
	UPROPERTY()
	FVector Combo_DeprojectWorldLocation = FVector::ZeroVector;

	UPROPERTY()
	bool Combo_bIsCounterAttack = false;	

	/**
	 * Charging
	 */
	UPROPERTY()
	FP3ActorPointerAndId CombatCharging_TargetActor;

	UPROPERTY()
	int32 CombatCharging_Index = -1;

	/**
	 * BouncingJump
	 */
	UPROPERTY()
	FVector BouncingJump_Impulse = FVector::ZeroVector;

	/**
	 * Rescue
	 */
	UPROPERTY()
	FP3ActorPointerAndId Rescue_TargetActor;

	/**
	 * Character montage
	 */
	UPROPERTY()
	FName CharacterMontage_Name;

	/**
	 * Parkour Climb Up
	 */
	UPROPERTY()
	int32 ParkourClimbUp_MontageIndex = 0;

	/** 
	 * Bucking Endure
	 */
	UPROPERTY()
	float BuckingEndure_RemoveStaminaOfMountedCharacterPerSeconds = 0.0f;

	/** 
	 * Cooking
	 */
	UPROPERTY()
	FName Cooking_RecipeKey = NAME_None;

	UPROPERTY()
	AActor* Cooking_CookerActor = nullptr;

	/**
	 * Response
	 */
	UPROPERTY()
	FP3ActorPointerAndId Response_Offence_Target;

	UPROPERTY()
	FName Response_OffenceResultName = NAME_None;
	
	UPROPERTY()
	FName Response_DefenceResultName = NAME_None;

	/**
	 * Mount by regolas move
	 */
	UPROPERTY(Transient)
	class AActor* MountByRegolasMove_HandleActor = nullptr;

	UPROPERTY(Transient)
	class AP3Character* MountByRegolasMove_TargetCharacter = nullptr;

	int32 MountByRegolasMove_TargetMountIndex = -1;

	/**
	 * Thrown away
	 */
	UPROPERTY(Transient)
	FVector ThrowAway_Velocity = FVector::ZeroVector;

	/**
	 * ReactionHit
	 */
	UPROPERTY(Transient)
	class AActor* ReactionHit_AttackerActor = nullptr;

	UPROPERTY()
	int64 ReactionHit_AttackerActorID = -1;

	UPROPERTY()
	FName ReactionHit_Name = NAME_None;

	UPROPERTY()
	EP3ReactionLayer ReactionHit_Layer = EP3ReactionLayer::None;

	UPROPERTY()
	EAnimNotifyAttackDirectionFlags ReactionHit_AttackDirection = EAnimNotifyAttackDirectionFlags::None;

	UPROPERTY()
	EAnimNotifyAttackStrengthFlags ReactionHit_AttackStrength = EAnimNotifyAttackStrengthFlags::Ignore;

	UPROPERTY()
	EP3AnimNotifyAttackAttribute ReactionHit_AttackAttribute = EP3AnimNotifyAttackAttribute::Slash;
	
	UPROPERTY()
	FTransform ReactionHit_TargetTransform = FTransform::Identity;
	
	UPROPERTY()
	FVector ReactionHit_HitLocation = FVector::ZeroVector;

	UPROPERTY()
	FName ReactionHit_HitBoneName = NAME_None;

	UPROPERTY()
	FName ReactionHit_AttackerBoneName = NAME_None;

	UPROPERTY()
	FVector ReactionHit_ThrowAwayVelocity = FVector::ZeroVector;

	UPROPERTY()
	float ReactionHit_StartMontagePosition = 0.f;
	
	UPROPERTY()
	float ReactionHit_StartMontagePlayRate = 1.f;

	UPROPERTY()
	bool ReactionHit_SkipMontageFrame = false;

	UPROPERTY()
	bool ReactionHit_bIsFrameHold = false;

	/**
	 * CableMove
	*/
	UPROPERTY()
	int64 CableMove_WeaponActorID = -1;

	UPROPERTY()
	int64 CableMove_HitActorActorID = -1;

	UPROPERTY(Transient)
	class AActor* CableMove_WeaponActor = nullptr;

	UPROPERTY(Transient)
	class AActor* CableMove_HitActor = nullptr;
	
	UPROPERTY()
	float CableMove_CableMoveImpulse = 0.f;

	/**
	 * Start Throw Item Aim
	 */
	UPROPERTY()
	FP3ItemId StartThrowItemAim_ThrowAimingItemId = INVALID_ITEMID;
	
	/**
	 * Start rescue carry on 
	 */
	UPROPERTY()
	AP3Character* CarryOnBack_TargetCharacter = nullptr;

	UPROPERTY()
	EP3RescueDirection CarryOnBack_RescueDirection = EP3RescueDirection::None;
};

/** 
 * Start action authority params
 * Made by authority(server)
 */
USTRUCT(BlueprintType)
struct FP3PawnActionStartAuthorityParams
{
	GENERATED_BODY()

	/**
	 * Throw
	 */
	UPROPERTY()
	FVector Throw_WorldVelocity;

	/**
	 * PickupHoldable
	 */
	UPROPERTY()
	FP3Item PickupHoldable_ObjectItem = FP3Item::InvalidItem;
};

/** 
 * Start action multicast params
 */
USTRUCT(BlueprintType)
struct FP3PawnActionStartMulticastParams
{
	GENERATED_BODY()

	FP3PawnActionStartMulticastParams() : ActionId(0) {}

	UPROPERTY()
	int32 ActionId;

	UPROPERTY()
	FP3PawnActionStartRequestParams RequestParams;

	UPROPERTY()
	FP3PawnActionStartAuthorityParams AuthorityParams;
};


/**
 * Stop action request params
 * Made by requester (mostly autonomous, sometimes authority)
 * This should not be trusted
 */
USTRUCT(BlueprintType)
struct FP3PawnActionStopRequestParams
{
	GENERATED_BODY()
};

/**
 * Stop action authority params
 * Made by authority(server)
 */
USTRUCT(BlueprintType)
struct FP3PawnActionStopAuthorityParams
{
	GENERATED_BODY()

	/**
	 * CombatAttack
	 */
	UPROPERTY()
	int32 StopComboAfter;
};

/**
 * Stop action multicast params
 */
USTRUCT(BlueprintType)
struct FP3PawnActionStopMulticastParams
{
	GENERATED_BODY()

	FP3PawnActionStopMulticastParams() : ActionId(0) {}

	UPROPERTY()
	int32 ActionId;

	UPROPERTY()
	FP3PawnActionStopRequestParams RequestParams;

	UPROPERTY()
	FP3PawnActionStopAuthorityParams AuthorityParams;
};


/**
 * Pawn Action
 * Something pawn do exclusively
 * - Montage based Jumping
 * - Attacking
 * - Picking up object
 * - Throwing object
 */
UCLASS(BlueprintType)
class P3_API UP3PawnAction : public UObject
{
	GENERATED_BODY()

public:
	UP3PawnAction();
	virtual ~UP3PawnAction() {}

	virtual class UWorld* GetWorld() const override;

	/** Action must be registered to ActionComponent before using */
	virtual void OnRegister(class UP3PawnActionComponent* InOwnerComponent, EPawnActionType InActionType, EPawnActionCategory InActionCategory);

	void SetActionKey(FName InActionKey) { ActionKey = InActionKey; }
	FName GetActionKey() const { return ActionKey; }

	/** 
	 * Action Interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const;
	virtual bool CanStartOnDead() const { return false; }
	virtual bool CanStartOnDowned() const { return false; }
	virtual bool CanStartGliding() const { return false; }
	virtual bool CanStartJump() const { return false; }
	virtual bool CanStartClimb() const { return true; }
	virtual bool CanSprint() const { return true; }
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual bool CanForceFinishedByOtherAction(EPawnActionType OtherActionType, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params);
	virtual void Autonomous_FailedToStart();
	virtual bool CanBeForceFinishedByPlayer() const { return false; }
	virtual void Server_FillAuthorityStartParams(const FP3PawnActionStartRequestParams& RequestParams, FP3PawnActionStartAuthorityParams& OutParams) const {}
	virtual void Server_FillAuthorityStopParams(FP3PawnActionStopAuthorityParams& OutParams) const {}
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params);
	virtual void Multicast_Progress(int32 StepIndex) {}
	virtual void Multicast_StopAction(const FP3PawnActionStopMulticastParams& Params) {};
	virtual void Multicast_Finish(EP3PawnActionResult Result);
	virtual void TickAction(float DeltaSeconds);
	virtual FString GetRequestParamsDebugString(const FP3PawnActionStartRequestParams& Params) const { return FString(); }
	void ForceFinish(EP3PawnActionResult Result);
	
	/** 
	 * Action optional interfaces
	 */

	/** Trigger AController::SetIgnoreMoveInput(true), during in-proress */
	virtual bool IsIgnoreMoveInput() const { return false; }
	virtual float GetMoveSpeedMultiplier() const { return 1.0f; }
	virtual bool IsMoveAllowed() const { return true; }
	virtual bool IsRotateAllowed() const { return true; }
	virtual bool IsJumpAllowed() const { return true; }
	/** Return true if actor is being knock-backed */
	virtual bool IsKnockBack() const { return false; }
	/** Return true if actor is being knock-downed */
	virtual bool IsInKnockDown() const { return false; }
	/** If return false, stamina will not be regenerated during this action */
	virtual bool CanRegenStamina() const { return true; }
	/** WorldStatic, WorldDynamic 과 충돌을 끄는가? 파크루 등 무충돌 루트모션일 경우 필요 */
	virtual bool IsDisableCollisionWithWorldObject() const { return false;  }

	/** 
	 * Action common values
	 */
	class UP3PawnActionComponent* GetOwnerComponent() const { return OwnerComponent; }
	class AActor* GetOwnerActor() const;
	EPawnActionType GetActionType() const { return ActionType; }
	EPawnActionCategory GetActionCategory() const { return ActionCategory; }

	int32 GetActionId() const { return ActionId; }
	int32 GetAutonomousRequestId() const { return AutonomousRequestId; }
	int32 GetServerRequestId() const { return ServerRequestId; }
	EP3PawnActionStatus GetActionLocalStatus() const { return ActionLocalStatus; }
	EP3PawnActionStatus GetActionServerStatus() const { return ActionServerStatus; }
	EP3PawnActionResult GetActionLocalResult() const { return ActionLocalResult; }
	EP3PawnActionResult GetActionServerResult() const { return ActionServerResult; }
	bool IsInProgress() const;
	float GetStartTimeSeconds() const { return StartTimeSeconds; }
	const FString& GetDebugString() const { return DebugStringUntilFinish; }
	
protected:
	virtual void Finish(EP3PawnActionResult Result);
	virtual void FinishToIdle();

	/** Helper function to change character stance. Note that character only can be changed by pawn action */
	void ChangeCharacterStance(EP3CharacterStance Stance, bool bUpdateWeaponAttachment = true);

	/** Helper to get owner */
	class AP3Character* GetP3Character() const;

	void SetCanForceStartActions(const TArray<EPawnActionType>& NewCanForceStartActions) { CanForceStartActions = NewCanForceStartActions; }
	void Server_RecoveryAfterTempWeapon();

#if !UE_BUILD_SHIPPING
	/** Add debug string that will be empty on finish */
	void AddDebugStringUntilFinish(const FString& DebugString, bool bAddNewLine = true) const;
#endif

private:
	class UP3PawnActionComponent* OwnerComponent = nullptr;
	EPawnActionType ActionType = EPawnActionType::Invalid;
	EPawnActionCategory ActionCategory = EPawnActionCategory::Invalid;

	int32 ActionId = 0;
	int32 AutonomousRequestId = 0;
	int32 ServerRequestId = 0;
	EP3PawnActionStatus ActionLocalStatus = EP3PawnActionStatus::Idle;
	EP3PawnActionStatus ActionServerStatus = EP3PawnActionStatus::Idle;
	EP3PawnActionResult ActionLocalResult = EP3PawnActionResult::Success;
	EP3PawnActionResult ActionServerResult = EP3PawnActionResult::Success;
	float StartTimeSeconds = 0;

	TArray<EPawnActionType> CanForceStartActions;

	/** Debug string that will be empty on finish */
	mutable FString DebugStringUntilFinish;

	/** ActionKey : Row Name in (Impl)ActionTable or CharacterMontageActionTable */
	FName ActionKey = NAME_None;
};

/** 
 * Play Montage
 */
UCLASS(BlueprintType)
class P3_API UP3PlayMontagePawnAction : public UP3PawnAction
{
	GENERATED_BODY()

public:
	enum EFlags
	{
		Flags_DisableAutoPlay					= (1 << 0),		// If set, montage will not be played at multicast start
																// PlayAnimMontage() should be called manually
		Flags_CannotStartIfAnyMontageIsPlaying	= (1 << 1),		// Do not start if any montage is already playing
		Flags_AutonomousHeadStart				= (1 << 2),		// Play montage at autonomous pre start 
																// In case of Root motion, this should be turned on
																// Otherwise movement sync system will make montage warp ahead in autonomous, 
																// since movement expect montage is played first in autonomous)
		Flags_DoNotFinishOnEndMontage = (1 << 3),
		Flags_FlyingMode = (1 << 4),							// If set, character movement mode will be change to flying during anim montage
																// This is needed if you want Root Motion on Z-Axis
	};

	UP3PlayMontagePawnAction();

	/** Helper function to create action instance */
	static UP3PlayMontagePawnAction* NewAction(class UAnimMontage* AnimMontage, uint32 Flags);

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual void Autonomous_FailedToStart() override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool IsIgnoreMoveInput() const { return true; }

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

	/** Set Montage. Note only available in idle status */
	void SetAnimMontage(class UAnimMontage* InAnimMontage);
	class UAnimMontage* GetAnimMontage() const { return AnimMontage; }

	void SetPlayRate(float InPlayRate);
	float GetPlayRate() const;
	void SetPlayMontagePosition(float InPlayMontagePosition);
	void SetStopBlendOutTime(float InStopBlendOutTime);

	/** Set Flags */
	void SetAnimMontageActionFlags(uint32 InFlags) { Flags = InFlags; }

	class UAnimInstance* GetAnimInstance(bool bFinishWithFailIfNotFound);
	class UAnimInstance* GetAnimInstance() const;
	struct FAnimMontageInstance* GetAnimMontageInstance() const;

	virtual bool PlayAnimMontage();
	void StopAnimMontage();

	bool IsPlaying() const;
	bool IsPlayedAtPreStart() const { return bPlayedAtPreStart; }

	UFUNCTION()
	void OnMontageEnded(class UAnimMontage* EndedAnimMontage, bool bInterrupted, int32 MontageInstanceID);

	UFUNCTION()
	void OnMontageBlendingOut(class UAnimMontage* BlendingOutAnimMontage, bool bInterrupted);

	UFUNCTION()
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType);

	UFUNCTION()
	virtual void OnActionAnimNotifyStateBegin(EActionAnimNotifyStateType NotifyStateType, float Duration);

	UFUNCTION()
	virtual void OnActionAnimNotifyStateEnd(EActionAnimNotifyStateType NotifyStateType);
	
private:
	uint32 Flags;

	UPROPERTY()
	class UAnimMontage* AnimMontage;

	float PlayRate = 1.0f;
	float PlayMontagePosition = 0.f;
	float StopBlendOutTime = 0.2f;

	bool bPlaying;
	bool bPlayedAtPreStart;
	int32 PlayingMontageInstanceID;
	bool bIsFinishOnMontageBlendingOut = false;

	float FailSafeMontageNotPlayingDurationSeconds = 0;
};

/** 
 * Spawn
 */
UCLASS(BlueprintType)
class P3_API UP3SpawnPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	bool bVisibleTurnedOn = false;
};

/** 
 * Climb start
 */
UCLASS(BlueprintType)
class P3_API UP3ClimbStartPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3ClimbStartPawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanRegenStamina() const override { return false; }
	virtual bool IsIgnoreMoveInput() const { return false; }
};

/**
 * Climb down

	DYLEE NOTE 아래와 같이 몽타쥬만 지정하여 사용하면 되지만 테이블화 작업에 유일하게 걸림돌이 되므로 임시로 클래스화

	ActionComp->RegisterAction(EPawnActionType::ClimbDown, EPawnActionCategory::Movement,
		UP3PlayMontagePawnAction::NewAction(Character->GetAnimMontages().ClimbDown, UP3PlayMontagePawnAction::Flags_AutonomousHeadStart));
 */
UCLASS(BlueprintType)
class P3_API UP3ClimbDownPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3ClimbDownPawnAction();

	void OnRegister(class UP3PawnActionComponent* InOwnerComponent, EPawnActionType InActionType, EPawnActionCategory InActionCategory) override;
};

/** 
 * Climb jump
 */
UCLASS(BlueprintType)
class P3_API UP3ClimbJumpPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3ClimbJumpPawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanRegenStamina() const override { return false; }

protected:	
	virtual void Finish(EP3PawnActionResult Result) override;

};

/** 
 * Climb end
 */
UCLASS(BlueprintType)
class P3_API UP3ClimbEndPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3ClimbEndPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanRegenStamina() const override { return false; }

protected:	
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;
};


/** 
 * Draw Weapon (Change to combat stance)
 */
UCLASS(BlueprintType)
class P3_API UP3DrawWeaponPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3DrawWeaponPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanSprint() const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool IsIgnoreMoveInput() const { return false; }

protected:	
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType);
};

/** 
 * Put away Weapon (Change combat stance to idle stance)
 */
UCLASS(BlueprintType)
class P3_API UP3PutawayWeaponPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3PutawayWeaponPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanSprint() const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool IsIgnoreMoveInput() const { return false; }

protected:	
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType);
};

/** 
 * Combat Roll
 */
UCLASS(BlueprintType)
class P3_API UP3CombatRollPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3CombatRollPawnAction();

public:

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool IsIgnoreMoveInput() const { return false; }	
	virtual bool CanRegenStamina() const override { return false; }

protected:	
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	void SelectAnimMontage(const FP3PawnActionStartRequestParams& Params);
};

/** 
 * Combat Attack
 */
UCLASS(BlueprintType)
class P3_API UP3CombatAttackPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3CombatAttackPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Server_FillAuthorityStopParams(FP3PawnActionStopAuthorityParams& OutParams) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void Multicast_StopAction(const FP3PawnActionStopMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool IsIgnoreMoveInput() const;
	virtual float GetMoveSpeedMultiplier() const;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

	virtual class UAnimMontage* GetAttackMontage(const FP3PawnActionStartRequestParams& Params) const;

private:
	float GetAttackMontagePlayRate() const;
	bool IsRootMotionHasInvalidLocation() const;

	UPROPERTY()
	AActor* TargetActor = nullptr;

	int32 SkillIndex = -1;

	FP3CmsCombatSkill CurrentCmsCombatSkill;

	FP3AnimNotifyGenerator AnimNotifyGenerator;
	int32 CurrentCombo = 0;
	int32 StopComboAfter = 0;

	/** Is Playing return to idle animation by stop combo? */
	bool bReturning = false;
};

/**
 * Combat Ranged Attack
 */
UCLASS(BlueprintType)
class P3_API UP3CombatRangedAttackPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool IsIgnoreMoveInput() const;
	virtual float GetMoveSpeedMultiplier() const;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	void Multicast_OnFire(AP3Character& Character, AP3Weapon& WeaponActor);
	void Server_OnFire(AP3Character& Character, AP3Weapon& WeaponActor);

private:
	FRotator CharacterRotator;
};


/**
 * Combat Projectile Skill Attack
 */
UCLASS(BlueprintType)
class P3_API UP3CombatProjectileSkillAttackPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

protected:
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	int32 SkillIndex = -1;
	FVector TargetLocation = FVector::ZeroVector;
	float TargetHalfHeight = 0.0f;
};

/**
 * Combat Hit
 */
UCLASS(BlueprintType)
class P3_API UP3CombatHitPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3CombatHitPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool CanStartOnDead() const { return false; }
	virtual bool IsIgnoreMoveInput() const;
	virtual float GetMoveSpeedMultiplier() const;
	virtual bool IsMoveAllowed() const;
	virtual bool IsRotateAllowed() const;
	virtual bool IsJumpAllowed() const;
	virtual bool IsInKnockDown() const { return bIsKnockDown; }
	virtual bool IsKnockBack() const { return bHasImpulse; }	

protected:	
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	void DropPickupable();
	EP3ActionAnimationType GetKnockBackMontageType(AP3Character* Character, const FVector& Impulse) const;
	EP3ActionAnimationType GetPushBackMontageType(AP3Character* Character, const FVector& Impulse) const;

	bool bIsKnockDown = false;
	bool bHasImpulse = false;
	bool bPlayingKnockBackMontage = false;
};

/**
 * Combat Hit by Flame
 *
 * CombatHit + DamageType Flame 의 조합이 많이 쓰여서 분리
 */
UCLASS(BlueprintType)
class P3_API UP3CombatHitFlamePawnAction : public UP3CombatHitPawnAction
{
	GENERATED_BODY()

public:
	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
};

/** 
 * Start Block
 */
UCLASS(BlueprintType)
class P3_API UP3StartBlockPawnAction : public UP3PawnAction
{
	GENERATED_BODY()

public:
	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanRegenStamina() const override { return false; }

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
};

/** 
 * Stop Block
 */
UCLASS(BlueprintType)
class P3_API UP3StopBlockPawnAction : public UP3PawnAction
{
	GENERATED_BODY()

public:
	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
};

/** 
 * Change holdable (command)
 */
UCLASS(BlueprintType)
class P3_API UP3ChangeHoldablePawnAction : public UP3PawnAction
{
	GENERATED_BODY()

public:
	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

private:
	bool SetHoldingActor(AP3Character& Character, EP3HoldType HoldType, FP3ItemId HolderItemId, AActor* HolderItemActor, const FP3Item& InvenItem);
};

/** 
 * Ragdollize (command)
 */
UCLASS(BlueprintType)
class P3_API UP3RagdollizePawnAction : public UP3PawnAction
{
	GENERATED_BODY()

public:
	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStartOnDead() const { return true; }
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const { return true; }
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
};

/** 
 * UnRagdollize (command)
 */
UCLASS(BlueprintType)
class P3_API UP3UnRagdollizePawnAction : public UP3PawnAction
{
	GENERATED_BODY()

public:
	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStartOnDead() const { return true; }
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const { return true; }
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
};

/** 
 * Throw Weapon
 */
UCLASS(BlueprintType)
class P3_API UP3ThrowWeaponPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

protected:
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	void Throw();

	FVector ThrowDirection = FVector::ZeroVector;
	bool bThrown = false;
};

/** 
 * Recall Thrown Weapon
 */
UCLASS(BlueprintType)
class P3_API UP3RecallThrownWeaponPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:

	UP3RecallThrownWeaponPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual void Multicast_Progress(int32 StepIndex) override;
	virtual void Multicast_Finish(EP3PawnActionResult Result) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	void Catch();

	enum { PROGRESS_STEP_CATCH = 1 };

	UFUNCTION()
	void OnWeaponRecallFinished(class AP3Weapon* Weapon);

	UPROPERTY()
	class AP3Weapon* Weapon = nullptr;

	UPROPERTY()
	class UP3HolderComponent* HolderComponent = nullptr;

	EP3CharacterItemSlot CharacterItemSlot = EP3CharacterItemSlot::Invalid;
	FP3Item WeaponItem = FP3Item::InvalidItem;
	float WaitingAgeSeconds = 0;
	bool bRecallFinished = false;
};

/** 
 * Pull Harpoon
 */
UCLASS(BlueprintType)
class P3_API UP3PullHarpoonPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void Multicast_Progress(int32 StepIndex) override;

private:
	enum { PROGRESS_STEP_PULL_CHARACTER = 1 };
};

/**
 * Combo Attack
 */
UCLASS(BlueprintType)
class P3_API UP3ComboAttackPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3ComboAttackPawnAction();

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanStartJump() const override { return true; }
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;	
	virtual bool CanStartClimb() const { return false; }
	virtual bool CanRegenStamina() const override { return false; }
	virtual void Server_FillAuthorityStopParams(FP3PawnActionStopAuthorityParams& OutParams) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void Multicast_StopAction(const FP3PawnActionStopMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool IsIgnoreMoveInput() const;	

protected:	
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	class UAnimMontage* GetAttackMontage(const FName& AnimationName, bool bIsCounterAttack) const;
	class UAnimMontage* GetWeaponMontage(const FName& AnimationName) const;

	void OnThrowAnimNotify();
	void OnThrowWeaponAnimNotify();	

	FP3AnimNotifyGenerator AnimNotifyGenerator;			

	FName ComboName = NAME_None;	
	FVector DeprojectWorldLocation = FVector::ZeroVector;
	FP3ComboRow ComboRow;

	float InProgressTimeSeconds = 0.f;
	float LastUpdateInProgressTimeSeconds = 0.f;	

	bool bLastUpdateFalling = false;
	bool bLastUpdateMovingOnGround = false;

	bool bRestoreMovement = false;
	float RestoreMaxWalkSpeed = 0.f;
	bool bRestoreUseSeparateBrakingFriction = false;
};

/**
 * Charging
 */
UCLASS(BlueprintType)
class P3_API UP3CombatChargingPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3CombatChargingPawnAction();

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void Multicast_Progress(int32 StepIndex) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual void Multicast_Finish(EP3PawnActionResult Result) override;
	virtual float GetMoveSpeedMultiplier() const;
	virtual bool CanRegenStamina() const override { return false; }
	virtual bool IsIgnoreMoveInput() const override { return false; }

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	void LocalControl_Tick(AP3Character* Character, float DeltaSeconds);
	/** 전방에 위험요소(낭떠러지 등)가 없는가? */
	bool Server_HasClearPathAhead(AP3Character* Character);
	void Server_Tick(AP3Character* Character, float DeltaSeconds);

	UFUNCTION()
	void Server_OnMeshBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);
	enum
	{ 
		STEP_PASSED_TARGET = 1,
		STEP_END = 2,
	};

	UFUNCTION()
	void Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit);

	/**
	 * Config
	 */
	int32 ChargingIndex = 0;
	float MaxDistance = 1.0f;
	float MoveSpeed = 0.0f;
	float MoveSpeedMultiplier = 1.0f;
	float ChargingBrakeTime = 0.0f;
	float ChargingChaseMinDistance = 0.0f;
	float ChaseTurningRatio = 0.0f;
	float NeedSpeedForStuck = 0.0f;
	float NeedSpeedForHitCharacter = 0.0f;
	float ChargingDamagePermil = 0.0f;
	bool Server_bHitTargetCharacter = false;

	/**
	 * Status
	 */
	UPROPERTY(Transient)
	AActor* ChargingTargetActor = nullptr;

	/** We don't want to hit same actor twice, since it might feel awkward */
	UPROPERTY(Transient)
	TArray<AActor*> Server_DamageAppliedActors;

	FVector Server_StartLocation = FVector::ZeroVector;
	FVector Server_TargetStartLocation = FVector::ZeroVector;
	float Server_StartTimeSeconds = 0.0f;

	TCircularBuffer<float> SquaredSpeedHistory = TCircularBuffer<float>(2);
	uint32 CurrentHistoryIndex = 0;

	/** Time when this actor passed target actor. We need this to stop at overshoot */
	float Server_TargetPassedTimeSeconds = 0.0f;

	float Server_LastStuckCheckTimeSeconds = 0.0f;
	FVector Server_LastStuckCheckLocation = FVector::ZeroVector;

	FVector Server_LastLocation = FVector::ZeroVector;

	/** Step */
	bool bPassedTarget = false;
	bool bChargingEnded = false;

	/** Am I controlling this pawn? */
	bool bLocalControl = false;

	/** Final input for move right. Only valid if bLocalControl is true */
	float LocalControl_MoveRightInput = 0.0f;

	/** End 가 되었을 때, 천천히 속도를 줄이기 위한 수치 */
	float LocalControl_EndingSlideProgress = 0.0f;
};

/**
 * Trip Over
 */
UCLASS(BlueprintType)
class P3_API UP3TripOverPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3TripOverPawnAction();

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool IsInKnockDown() const { return true; }
	virtual bool IsIgnoreMoveInput() const { return true; }

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

	float AgeSeconds = 0;
};

/**
 * BouncingJump
 */
UCLASS(BlueprintType)
class P3_API UP3BouncingJumpPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3BouncingJumpPawnAction();

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;	
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
};

/**
 * Character Montage Action
 * Customizable action, defined by FP3CharacterMontageActionDesc
 */
UCLASS(BlueprintType)
class P3_API UP3CharacterMontageAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3CharacterMontageAction();

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;	
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool CanForceFinishedByOtherAction(EPawnActionType OtherActionType, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool IsIgnoreMoveInput() const override { return bMoveAndRotateAllowed; }
	virtual bool IsMoveAllowed() const override { return bMoveAndRotateAllowed; }
	virtual bool IsRotateAllowed() const override { return bMoveAndRotateAllowed; }
	virtual bool IsInKnockDown() const override { return bIsKnockDown; }
	virtual FString GetRequestParamsDebugString(const FP3PawnActionStartRequestParams& Params) const override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	bool bMoveAndRotateAllowed = false;
	bool bIsKnockDown = false;
	bool bIsIgnoreFireHitAction = false;

	TArray<FName> CanForceStartMontageActionNames;
};

/**
 * StandUpOnDownedEnd
 */
UCLASS(BlueprintType)
class P3_API UP3DownedEndPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStartOnDowned() const override { return true; }
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override { return true; }

protected:
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType);
};

/**
 * Help
 */
UCLASS(BlueprintType)
class P3_API UP3RescuePawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3RescuePawnAction();

public:
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual void Multicast_Progress(int32 StepIndex) override;
	virtual void Multicast_Finish(EP3PawnActionResult Result) override;
	virtual bool IsIgnoreMoveInput() const override { return bIgnoreMoveInput; }

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	
private:
	UPROPERTY()
	AP3Character* TargetCharacter = nullptr;

	bool bSavedSomeone = false;
	bool bIgnoreMoveInput = false;

	enum { STEP_END = 1 };
};

/**
 * Breakfall
 */
UCLASS(BlueprintType)
class P3_API UP3BreakfallPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3BreakfallPawnAction();

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
};

/**
 * ParkourClimbUp
 */
UCLASS(BlueprintType)
class P3_API UP3ParkourClimbUp : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3ParkourClimbUp();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params) override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool IsDisableCollisionWithWorldObject() const;

private:
	void SelectClimbUpMontage(int32 MontageIndex);
};


/**
 * Exhaust
 */
UCLASS(BlueprintType)
class P3_API UP3ExhaustPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3ExhaustPawnAction() {}

public:
	/**
	* UP3PawnAction interfaces
	*/
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;

protected:
};


/**
 * Bucking Hang On
 */
UCLASS(BlueprintType)
class P3_API UP3BuckingHangOnPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3BuckingHangOnPawnAction() {}

public:
	/**
	* UP3PawnAction interfaces
	*/
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual void Multicast_Finish(EP3PawnActionResult Result) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:

	float RemoveStaminaOfMountedCharacterPerSeconds = 0.0f;

};

/**
 * Mount By Regolas Move
 */
UCLASS(BlueprintType)
class P3_API UP3MountByRegolasMoveAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3MountByRegolasMoveAction();

	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	UPROPERTY(Transient)
	class AActor* HandleActor = nullptr;

	UPROPERTY(Transient)
	class AP3Character* TargetCharacter = nullptr;

	int32 TargetMountIndex = -1;
};

/**
 * Character gets throw away
 */
UCLASS(BlueprintType)
class P3_API UP3ThrowAwayAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3ThrowAwayAction();

	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual void Multicast_Progress(int32 StepIndex) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	enum { PROGRESS_STEP_LANDED = 1 };

	float Server_AgeSeconds = 0.0f;
	bool Server_bLanded = false;
};


/**
 * Character gets roar stun
 */
UCLASS(BlueprintType)
class P3_API UP3RoarStunAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3RoarStunAction();

	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual void Multicast_Progress(int32 StepIndex) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	enum { STEP_END = 1 };

	bool Server_HasStunned = false;
};


/**
 * Combat ReactionHit
 */
UCLASS(BlueprintType)
class P3_API UP3CombatReactionHitPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3CombatReactionHitPawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;
	virtual bool CanForceFinishedByOtherAction(EPawnActionType OtherActionType, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void Multicast_StopAction(const FP3PawnActionStopMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool CanStartOnDead() const { return true; }
	virtual bool CanStartOnDowned() const { return true; }
	virtual bool CanRegenStamina() const override { return true; }
	
	virtual bool IsIgnoreMoveInput() const;	
	virtual bool IsMoveAllowed() const;
	virtual bool IsRotateAllowed() const;
	virtual bool IsJumpAllowed() const;	

	virtual float GetMoveSpeedMultiplier() const;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void SetAnimMontage(class UAnimMontage* InAnimMontage);
	virtual bool PlayAnimMontage() override;		

private:
	const FP3CombatReactionRow* GetReactionRow(AP3Character& Character) const;

	void StartReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void StartReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);		

	void TickReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds);
	void TickReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds);
	void Server_TickReactionStatus(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds);

	void FinishReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void FinishReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void Server_FinishReactionStatus(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);	

	UPROPERTY(Transient)
	class AActor* AttackerActor = nullptr;

	FName ReactionName = NAME_None;
	EP3ReactionLayer ReactionLayer = EP3ReactionLayer::None;
	EP3AnimNotifyAttackAttribute AttackAttribute = EP3AnimNotifyAttackAttribute::Slash;
	
	FTransform TargetTransform = FTransform::Identity;
	FVector HitLocation = FVector::ZeroVector;
	
	FVector ThrowAwayVelocity = FVector::ZeroVector;
	
	FName AttackerBoneName = NAME_None;
	FName HitBoneName = NAME_None;
	
	float MoveSpeedMultiplier = 1.f;

	FName SnapshotName = NAME_None;
	FVector RagdollStartedLocation = FVector::ZeroVector;
	float RagdollStartedGroundHitTimeSeconds = 0.f;
	float RagdollInProgressTimeSeconds = 0.f;
	float SnapshotInProgressTimeSeconds = 0.f;
	float DeltaMoveInProgressTimeSeconds = 0.f;
	float DownInProgressTimeSeconds = 0.f;
	float LastUpdateDeltaMoveInProgressTimeSeconds = 0.f;

	bool bLastUpdateFalling = false;
	bool bLastUpdateMovingOnGround = false;	

	bool bRestoreMovement = false;
	float RestoreMaxWalkSpeed = 0.f;
	bool bRestoreUseSeparateBrakingFriction = false;

	bool bRestsoreBlocking = false;
	bool bRestsoreCrouchBlocking = false;

	bool bSkipMontageFrame = false;
	bool bIsFrameHold = false;	
};

/**
 * CableMove
 */
UCLASS(BlueprintType)
class P3_API UP3CableMovePawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	UP3CableMovePawnAction();

	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;	
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual void Multicast_Finish(EP3PawnActionResult Result) override;

	virtual bool IsIgnoreMoveInput() const override { return true; }

protected:
	virtual void Finish(EP3PawnActionResult Result) override;	

private:
	int32 GetTargetMountPointIndex(AP3Character* CableHitCharacter, const FVector& TargetLocation);
	
	UPROPERTY(Transient)
	class AActor* CableWeaponActor = nullptr;

	UPROPERTY(Transient)
	class AActor* CableHitActor = nullptr;
		
	int32 TargetMountPointIndex = -1;
	float CableMoveImpulse = 0.f;
};

/**
 * Start Item Throw Aim
 */
UCLASS(BlueprintType)
class P3_API UP3StartItemThrowAimPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool IsIgnoreMoveInput() const override { return false; }
};

/**
 * Start Item Throw Aim
 */
UCLASS(BlueprintType)
class P3_API UP3EndItemThrowAimPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual bool IsIgnoreMoveInput() const override { return false; }
};

/**
 * Adapted Attack
 * 타겟의 위치로 정확히 공격하기 위해 위치와 방향을 조절하는 공격
 * 애니메이션의 Hit Event 를 고려하여, Pawn 의 위치와 회전을 조정함
 */
UCLASS(BlueprintType)
class P3_API UP3AdaptedAttackAction : public UP3CombatAttackPawnAction
{
	GENERATED_BODY()

public:

	/**
	 * UP3PawnAction interfaces
	 */
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotifyStateBegin(EActionAnimNotifyStateType NotifyStateType, float Duration);
	virtual void OnActionAnimNotifyStateEnd(EActionAnimNotifyStateType NotifyStateType);
	virtual class UAnimMontage* GetAttackMontage(const FP3PawnActionStartRequestParams& Params) const override;

private:
	/** 애니메이션 상 타격 위치를 반환. 월드 좌표계 */
	FVector GetHitLocation() const;

	/** 타겟의 위치. 액션 시작 시 결정됨 */
	FVector TargetLocation = FVector::ZeroVector;

	/** 타격 위치. 캐릭터 좌표계 */
	FVector RelativeHitLocation = FVector::ZeroVector;

	/** 보정 회전 각도 (Z축). 액션 시작 시 결정됨 */
	float AdaptingYawDegree = 0.0f;

	/** 보정 이동 거리. 액션 시작 시 결정됨 */
	FVector AdaptingMove = FVector::ZeroVector;

	float TickAgeSeconds = 0.0f;
	bool bRootMotionDisabled = false;

	bool bMove = false;
	float MoveDurationSeconds = 0.0f;
};

/**
 * Carry on back
 * (구조 목적의 캐릭터 업기 액션)
 */
UCLASS(BlueprintType)
class P3_API UP3CarryingOnBackStartPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotifyStateBegin(EActionAnimNotifyStateType NotifyStateType, float Duration);
	virtual void OnActionAnimNotifyStateEnd(EActionAnimNotifyStateType NotifyStateType);

private:
	UFUNCTION()
	void OnCarryOnBackStartAnimNotify();

	/** 구조자의 위치 계산 */
	EP3RescueDirection CalcRescueDirection() const;
	FString GetTargetSocketName(EP3RescueDirection RescueDirection) const;
	EP3RescueDirection GetRescueDirection(FString& TargetSocketNameStr) const;

	UAnimMontage* GetRescuerAnimMontage(EP3RescueDirection RescueDirection) const;
	bool CalcRescuerOffset();

	/** 구조 대상 */
	UPROPERTY(Transient)
	AP3Character* RescueTarget = nullptr;

	/** 업기 시작 방향 */
	EP3RescueDirection RescueDirection = EP3RescueDirection::None;
	FName RescuerSocketName = TEXT("CarryDownedCharacter_Rescuer");
	FString FindTargetSocketNameStr = TEXT("CarryDownedCharacter_Target_");
	FVector RescueStartTranslation = FVector::ZeroVector;
	FRotator RescueStartRotation = FRotator::ZeroRotator;

	bool bIsMove = false;
	float MoveDurationSeconds = 0.f;
	float TickAgeSeconds = 0.f;
};

UCLASS(BlueprintType)
class P3_API UP3CarriedOnBackStartPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	virtual bool CanStartOnDowned() const { return true; }
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	UAnimMontage* GetRescueTargetAnimMontage(EP3RescueDirection RescueDirection) const;

	/** 구조자 */
	UPROPERTY(Transient)
	AP3Character* Rescuer = nullptr;
};

UCLASS(BlueprintType)
class P3_API UP3CarryingOnBackEndPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;

private:
	UFUNCTION()
	void OnCarryOnBackEndAnimNotify();

	UPROPERTY(Transient)
	AP3Character* RescueTarget = nullptr;
};

UCLASS(BlueprintType)
class P3_API UP3CarriedOnBackEndPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

public:
	virtual bool CanStartOnDowned() const { return true; }
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
};
