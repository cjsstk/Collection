// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PawnAction.h"

#include "Classes/CableComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Curves/CurveVector.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Character.h"
#include "GameFramework/PawnMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "NavigationSystem.h"
#include "PhysicsEngine/PhysicsHandleComponent.h"

#include "AI/P3AIController.h"
#include "Chemical/P3FlammableComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "GameMode//P3ContributionSystem.h"
#include "Network/P3WorldNet.h"
#include "P3.h"
#include "P3AggroComponent.h"
#include "P3AnimInstance.h"
#include "P3AnimNotify.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3CharacterHealthPointComponent.h"
#include "P3CharacterMovementComponent.h"
#include "P3Cms.h"
#include "P3Combat.h"
#include "P3CombatComponent.h"
#include "P3CombatResponseComponent.h"
#include "P3ComboTableComponent.h"
#include "P3Core.h"
#include "P3Destructible.h"
#include "P3GameInstance.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3InventoryComponent.h"
#include "P3Log.h"
#include "P3PartComponent.h"
#include "P3PawnActionComponent.h"
#include "P3PickupComponent.h"
#include "P3PickupableComponent.h"
#include "P3PlayerController.h"
#include "P3Projectile.h"
#include "P3RagdollComponent.h"
#include "P3Spear.h"
#include "P3StaminaPointComponent.h"
#include "P3Tags.h"
#include "P3Weapon.h"


extern TAutoConsoleVariable<int32> CVarP3CombatRotateToTarget;
extern TAutoConsoleVariable<float> CVarP3CombatBlockStaminaAmount;
extern TAutoConsoleVariable<int32> CVarP3ActionDebug;
extern TAutoConsoleVariable<int32> CVarP3AllowInteractionDuringPutawayWeaponAction;
extern TAutoConsoleVariable<int32> CVarP3CombatDebug;

static TAutoConsoleVariable<int32> CVarP3CombatAttackIgnoreMoveInput(
    TEXT("p3.combatAttackIgnoreMoveInput"),
    0,
    TEXT("1: ignore move input during attack. 0: don't do that"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CombatAttackPreStart(
	TEXT("p3.combatAttackPreStart"),
	1,
	TEXT("1: start attack before server response. 0: start attack after server response"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3CombatAttackPreDecisionAmount(
	TEXT("p3.combatAttackPreDecisionAmount"),
	0,
	TEXT("make hit decision early for specific amount (msec)"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3CombatBlockInstancely(
    TEXT("p3.combatBlockInstancely"),
    1,
    TEXT("1: blocking action can interrupt any other action"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3HarpoonPullImpulse(
	TEXT("p3.harpoonPullImpulse"),
	100000,
	TEXT(""), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3HarpoonCharacterPullImpulse(
	TEXT("p3.harpoonCharacterPullImpulse"),
	150000,
	TEXT(""), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3CombatRollAllowTimeSecondsAfterHit(
	TEXT("p3.combatRollAllowTimeSecondsAfterHit"),
	1.0f,
	TEXT("If set >= 0, combat roll is allowed to interrupt hit action after this seconds"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3CanSprintOnPutAway(
	TEXT("p3.canSprintOnPutAway"),
	0,
	TEXT("1: can Sprint. 0: can't Sprint"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CanSprintOnDraw(
	TEXT("p3.canSprintOnDraw"),
	0,
	TEXT("1: can Sprint. 0: can't Sprint"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ChargingStuckTickPeriod(
	TEXT("p3.chargingStuckTickPeriod"),
	1.0f,
	TEXT("Charging check tick period in seconds"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ChargingStuckDistance(
	TEXT("p3.chargingStuckDistance"),
	100,
	TEXT("If actor doesn't move more than this, it's stuck"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ChargingStuckMinDotProduct(
	TEXT("p3.chargingStuckMinDotProduct"),
	0.0f,
	TEXT("1 only allows frontal impact, 0 allows vertical impact"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3ChargingDebug(
	TEXT("p3.chargingDebug"),
	0,
	TEXT("1: Enable Debug, 0: Disable Debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ChargingBouncingRotateSpeed(
	TEXT("p3.chargingBouncingRotateSpeed"),
	100.0f,
	TEXT("Set speed of turning towards changed moving direction due to hit"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3DropHoldableItemLifeSpan(
	TEXT("p3.dropHoldableItemLifeSpan"),
	30.0f,
	TEXT("Dropped holdable item's life span"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3CombatFrameHoldDurationSeconds(
	TEXT("p3.combatFrameHoldDurationSeconds"),
	0,
	TEXT("Set reaction frame hold retention time"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3CombatFrameHoldMeshShakelImpulse(
	TEXT("p3.combatFrameHoldMeshShakelImpulse"),
	0,
	TEXT("Set reaction frame hold random mesh shake impulse"), ECVF_Cheat);

static TAutoConsoleVariable<FString> CVarP3CombatFrameHoldCameraShake(
	TEXT("p3.combatFrameHoldCameraShake"),
	"",
	TEXT("Set reaction frame hold camera shake table name"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3CombatReactionAnimationStartPoision(
	TEXT("p3.combatReactionAnimationStartPoision"),
	0,
	TEXT("Set reaction motion start position"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CombatUseAdaptedAttack(
	TEXT("p3.combatUseAdaptedAttack"),
	1,
	TEXT("Toggle adapted attack. 0: disable, 1: enable"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ParkourDisableCollision(
	TEXT("p3.parkourDisableCollision"),
	1,
	TEXT("Set 1 to disable collision during parkour. This makes movement smoother"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ChargingLookupNavigation(
	TEXT("p3.chargingLookupNavigation"),
	1,
	TEXT("Set 1 to use navigation mesh to avoid charging into strange area"), ECVF_Cheat);

#undef ActionJsonLog
#define ActionJsonLog(Verbosity, Subject, ...) \
	P3JsonLogWithCategory(P3ActionLog, Verbosity, Subject,	\
		TEXT("Pawn"), (GetOwnerComponent() && GetOwnerComponent()->GetOwner()) ? GetOwnerComponent()->GetOwner()->GetName() : TEXT("NULL"),	\
		TEXT("Role"), GetOwnerComponent() && GetOwnerComponent()->GetOwner() ? P3Core::GetNetModeStr(P3Core::GetP3NetMode(*GetOwnerComponent()->GetOwner())) : TEXT("NONE"),	\
		TEXT("ActionType"), EnumToStringShort(EPawnActionType, GetActionType()),	\
		TEXT("ActionId"), GetActionId(),	\
		##__VA_ARGS__)


UP3PawnAction::UP3PawnAction()
{
}

UWorld* UP3PawnAction::GetWorld() const
{
	if (OwnerComponent)
	{
		return OwnerComponent->GetWorld();
	}

	return nullptr;
}

void UP3PawnAction::OnRegister(class UP3PawnActionComponent* InOwnerComponent, EPawnActionType InActionType, EPawnActionCategory InActionCategory)
{
	ensure(OwnerComponent == nullptr);
	ensure(ActionType == EPawnActionType::Invalid);
	ensure(ActionCategory == EPawnActionCategory::Invalid);

	OwnerComponent = InOwnerComponent;
	ActionType = InActionType;
	ActionCategory = InActionCategory;
}

bool UP3PawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	AP3Character* Character = GetP3Character();
	if (Character && Character->IsActionCategoryDisabled(GetActionCategory()))
	{
		return false;
	}

	return true;
}

bool UP3PawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (GetActionCategory() == EPawnActionCategory::Pickup
		&& CVarP3AllowInteractionDuringPutawayWeaponAction.GetValueOnGameThread() != 0)
	{
		if (OtherActionType == EPawnActionType::PutAwayWeapon)
		{
			return true;
		}
	}

	return false;
}

bool UP3PawnAction::CanForceFinishedByOtherAction(EPawnActionType OtherActionType, const FP3PawnActionStartRequestParams* Params) const
{
	const bool bInList = CanForceStartActions.Contains(OtherActionType);

	return bInList;
}

void UP3PawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	check(IsAutonomousProxy(GetOwnerComponent()->GetOwner()));

	ActionLocalStatus = EP3PawnActionStatus::InProgress;
	ActionServerStatus = EP3PawnActionStatus::Idle;
	ActionId = 0;

	ActionJsonLog(Display, "Autonomous action pre-started");
}

void UP3PawnAction::Autonomous_FailedToStart()
{
	ensure(ActionLocalStatus == EP3PawnActionStatus::InProgress || ActionLocalStatus == EP3PawnActionStatus::Finished);
	ensure(ActionServerStatus == EP3PawnActionStatus::Idle);

	ActionJsonLog(Display, "Autonomous failed to start");

	// Derived class might already have finished this action, in that case, we don't need to call finish here
	if (ActionLocalStatus != EP3PawnActionStatus::Finished)
	{
		Finish(EP3PawnActionResult::Failed);
	}

	ActionServerStatus = EP3PawnActionStatus::Finished;
	ActionServerResult = EP3PawnActionResult::Failed;

	if (ActionLocalStatus == EP3PawnActionStatus::Finished)
	{
		FinishToIdle();
	}
}

void UP3PawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	ensure(ActionServerStatus == EP3PawnActionStatus::Idle);
	ensure(ActionLocalStatus == EP3PawnActionStatus::Idle || ActionLocalStatus == EP3PawnActionStatus::InProgress || ActionLocalStatus == EP3PawnActionStatus::Finished);
	ensure(IsAutonomousProxy(GetOwnerComponent()->GetOwner()) || 
		   (!IsAutonomousProxy(GetOwnerComponent()->GetOwner()) && ActionLocalStatus == EP3PawnActionStatus::Idle));
	ensure(Params.ActionId != 0);

	ActionId = Params.ActionId;
	AutonomousRequestId = Params.RequestParams.AutonomousRequestId;
	ServerRequestId = Params.RequestParams.ServerRequestId;

	if (ActionLocalStatus != EP3PawnActionStatus::Finished)
	{
		ActionLocalStatus = EP3PawnActionStatus::InProgress;
	}

	ActionServerStatus = EP3PawnActionStatus::InProgress;
	StartTimeSeconds = GetWorld()->GetTimeSeconds();

	ActionJsonLog(Display, "Multicast start action");
}

void UP3PawnAction::TickAction(float DeltaSeconds)
{
}

void UP3PawnAction::ForceFinish(EP3PawnActionResult Result)
{
	ActionJsonLog(Log, "Force finish");

	Finish(Result);
}

class AActor* UP3PawnAction::GetOwnerActor() const
{
	if (!OwnerComponent)
	{
		return nullptr;
	}

	return OwnerComponent->GetOwner();
}

bool UP3PawnAction::IsInProgress() const
{
	return ActionLocalStatus == EP3PawnActionStatus::InProgress || 
		ActionServerStatus == EP3PawnActionStatus::InProgress;
}

void UP3PawnAction::Finish(EP3PawnActionResult Result)
{
	ensure(ActionLocalStatus == EP3PawnActionStatus::InProgress);
	ensure(GetOwnerComponent() && IsAutonomousProxy(GetOwnerComponent()->GetOwner()) ||  
		   ActionServerStatus == EP3PawnActionStatus::InProgress || ActionServerStatus == EP3PawnActionStatus::Finished);

	ActionJsonLog(Log, "Action Finished", TEXT("Result"), EnumToStringShort(EP3PawnActionResult, Result));

	ActionLocalStatus = EP3PawnActionStatus::Finished;
	ActionLocalResult = Result;

	if (GetOwnerComponent())
	{
		GetOwnerComponent()->OnActionFinished(*this);
	}

	if (ActionLocalStatus == EP3PawnActionStatus::Finished && ActionServerStatus == EP3PawnActionStatus::Finished)
	{
		FinishToIdle();
	}

}

void UP3PawnAction::FinishToIdle()
{
	ensure(ActionLocalStatus == EP3PawnActionStatus::Finished && ActionServerStatus == EP3PawnActionStatus::Finished);

	ActionJsonLog(Log, "Action become idle");

	if (GetOwnerComponent())
	{
		GetOwnerComponent()->OnActionFinishedToIdle(*this);
	}

	// Both local and server are finished, now we can go back into idle state
	ActionId = 0;
	ActionLocalStatus = EP3PawnActionStatus::Idle;
	ActionServerStatus = EP3PawnActionStatus::Idle;
	ActionLocalResult = EP3PawnActionResult::Success;
	ActionServerResult = EP3PawnActionResult::Success;
	StartTimeSeconds = 0;

	CanForceStartActions.Empty();
	DebugStringUntilFinish.Empty();
}

void UP3PawnAction::Multicast_Finish(EP3PawnActionResult Result)
{
	ensure(ActionLocalStatus == EP3PawnActionStatus::InProgress || ActionLocalStatus == EP3PawnActionStatus::Finished);
	ensure(ActionServerStatus == EP3PawnActionStatus::InProgress);

	ActionJsonLog(Log, "Multicast finished");

	ActionServerStatus = EP3PawnActionStatus::Finished;
	ActionServerResult = Result;

	if (ActionLocalStatus == EP3PawnActionStatus::Finished)
	{
		FinishToIdle();
	}
}

void UP3PawnAction::ChangeCharacterStance(EP3CharacterStance Stance, bool bUpdateWeaponAttachment)
{
	AP3Character* Character = GetP3Character();

	if (ensure(Character))
	{
		// This is needed to change stance quickly on client side
		// Final state will be synced with server eventually by command
		Character->SetStanceByAction(*this, Stance, bUpdateWeaponAttachment);

		if (Character->Role == ROLE_Authority || Character->Role == ROLE_AutonomousProxy)
		{
			UP3CommandComponent* CommandComponent = Character->GetCommandComponent();

			if (ensure(CommandComponent))
			{
				FP3CommandRequestParams Params;
				Params.ChangeStance_NewStance = Stance;
				CommandComponent->RequestCommand(UP3ChangeStanceCommand::StaticClass(), Params);
			}
		}
	}
}

class AP3Character* UP3PawnAction::GetP3Character() const
{
	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;

	return Character;
}

void UP3PawnAction::AddDebugStringUntilFinish(const FString& DebugString, bool bAddNewLine /*= true*/) const
{
	DebugStringUntilFinish += DebugString;

	if (bAddNewLine)
	{
		DebugStringUntilFinish += TEXT("\n");
	}
}

void UP3PawnAction::Server_RecoveryAfterTempWeapon()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	FP3CommandRequestParams CommandParams;
	if (ensure(UP3RecoveryAfterTempWeaponCommand::Server_BuildParams(GetWorld(), *Character, CommandParams)))
	{
		Character->GetCommandComponent()->RequestCommand(UP3RecoveryAfterTempWeaponCommand::StaticClass(), CommandParams);
	}
}

UP3PlayMontagePawnAction::UP3PlayMontagePawnAction() 
	: Flags(0)
	, bPlaying(false)
	, bPlayedAtPreStart(false)
	, PlayingMontageInstanceID(INDEX_NONE)
{

}

UP3PlayMontagePawnAction* UP3PlayMontagePawnAction::NewAction(class UAnimMontage* AnimMontage, uint32 Flags)
{
	UP3PlayMontagePawnAction* Action = NewObject<UP3PlayMontagePawnAction>();
	Action->SetAnimMontage(AnimMontage);
	Action->SetAnimMontageActionFlags(Flags);

	return Action;
}

void UP3PlayMontagePawnAction::SetAnimMontage(class UAnimMontage* InAnimMontage)
{
	if (bPlaying || bPlayedAtPreStart)
	{
		ensureMsgf(0, TEXT("You can only change montage before play"));
		return;
	}

	AnimMontage = InAnimMontage;

#if !UE_BUILD_SHIPPING
	if (InAnimMontage)
	{
		AddDebugStringUntilFinish(InAnimMontage->GetName());
	}
#endif
}

void UP3PlayMontagePawnAction::SetPlayRate(float InPlayRate)
{
	PlayRate = InPlayRate;
}

float UP3PlayMontagePawnAction::GetPlayRate() const
{
	return PlayRate;
}

void UP3PlayMontagePawnAction::SetPlayMontagePosition(float InPlayMontagePosition)
{
	PlayMontagePosition = InPlayMontagePosition;
}

void UP3PlayMontagePawnAction::SetStopBlendOutTime(float InStopBlendOutTime)
{
	StopBlendOutTime = InStopBlendOutTime;
}

bool UP3PlayMontagePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	UAnimInstance* AnimInstance = GetAnimInstance();
	if (!AnimInstance)
	{
		return false;
	}

	// Can't start if already some montage is playing
	if ((Flags & Flags_CannotStartIfAnyMontageIsPlaying) != 0)
	{
		if (AnimInstance->IsAnyMontagePlaying())
		{
			return false;
		}
	}

	return true;
}

void UP3PlayMontagePawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	Super::Autonomous_PreStartAction(Params);

	if ((Flags & Flags_AutonomousHeadStart) != 0)
	{
		const bool bPlayed = PlayAnimMontage();

		if (!bPlayed)
		{
			ActionJsonLog(Warning, "Failed to play action montage during autonomouse prestart");
			return;
		}

		bPlayedAtPreStart = true;
	}
}

void UP3PlayMontagePawnAction::Autonomous_FailedToStart()
{
	if (bPlaying)
	{
		StopAnimMontage();
	}

	Super::Autonomous_FailedToStart();
}

void UP3PlayMontagePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);
	
	if (GetActionLocalStatus() != EP3PawnActionStatus::Finished && !bPlayedAtPreStart && (Flags & Flags_DisableAutoPlay) == 0)
	{
		bIsFinishOnMontageBlendingOut = Params.RequestParams.CombatAttack_bFinishOnMontageBlendingOut;
		const bool bPlayed = PlayAnimMontage();

		if (!bPlayed)
		{
			ActionJsonLog(Warning, "Failed to play action montage during multicast start");
			Finish(EP3PawnActionResult::Failed);
			return;
		}		
	}	
}

void UP3PlayMontagePawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (!GetOwnerComponent())
	{
		ActionJsonLog(Warning, "Play montage pawn action tick with no owner");

		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (bPlaying)
	{
		UAnimInstance* AnimInstance = GetAnimInstance(true);

		if (!ensure(AnimInstance))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		FAnimMontageInstance* AnimMontageInstance = AnimInstance->GetActiveInstanceForMontage(AnimMontage);

		if (!AnimMontageInstance)
		{
			FailSafeMontageNotPlayingDurationSeconds += DeltaSeconds;
			if (FailSafeMontageNotPlayingDurationSeconds > 1.0f)
			{
				ensure(0);
				ActionJsonLog(Warning, "Montage action tick failed. No instance found");
				Finish(EP3PawnActionResult::Failed);
				return;
			}
		}
	}
}

void UP3PlayMontagePawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;
	if (Character)
	{
		Character->OnActionAnimNotify.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotify);
		Character->OnActionAnimNotifyStateBegin.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateBegin);
		Character->OnActionAnimNotifyStateEnd.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateEnd);
	}

	UAnimInstance* AnimInstance = GetAnimInstance(true);
	if (AnimInstance)
	{
		if (bIsFinishOnMontageBlendingOut)
		{
			AnimInstance->OnMontageBlendingOut.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnMontageBlendingOut);
		}
 		else
 		{
			AnimInstance->P3OnMontageEnded.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnMontageEnded);
		}
		
	}

	if (bPlaying)
	{
		StopAnimMontage();
	}
	
	if (Flags & Flags_FlyingMode)
	{
		UCharacterMovementComponent* MovementComp = Character ? Character->GetCharacterMovement() : nullptr;
		if (MovementComp)
		{
			MovementComp->SetMovementMode(EMovementMode::MOVE_Walking);
		}
	}

	bPlaying = false;
	bPlayedAtPreStart = false;
	PlayingMontageInstanceID = INDEX_NONE;
	FailSafeMontageNotPlayingDurationSeconds = 0;
	bIsFinishOnMontageBlendingOut = false;
}

class UAnimInstance* UP3PlayMontagePawnAction::GetAnimInstance(bool bFinishWithFailIfNotFound)
{
	UAnimInstance* AnimInstance = GetAnimInstance();

	if (!AnimInstance && bFinishWithFailIfNotFound)
	{
		Finish(EP3PawnActionResult::Failed);
	}

	return AnimInstance;
}

class UAnimInstance* UP3PlayMontagePawnAction::GetAnimInstance() const
{
	ACharacter* Character = Cast<ACharacter>(GetOwnerComponent()->GetOwner());

	if (!Character)
	{
		return nullptr;
	}

	UAnimInstance* AnimInstance = (Character->GetMesh() ? Character->GetMesh()->GetAnimInstance() : nullptr);

	return AnimInstance;
}

FAnimMontageInstance* UP3PlayMontagePawnAction::GetAnimMontageInstance() const
{
	UAnimInstance* AnimInstance = GetAnimInstance();

	if (!AnimInstance)
	{
		return nullptr;
	}

	FAnimMontageInstance* AnimMontageInstance = AnimInstance->GetMontageInstanceForID(PlayingMontageInstanceID);

	return AnimMontageInstance;
}

bool UP3PlayMontagePawnAction::PlayAnimMontage()
{
	ensure((Flags & Flags_AutonomousHeadStart) || GetActionId() != 0);
	ensure(GetActionLocalStatus() == EP3PawnActionStatus::InProgress || GetActionServerStatus() == EP3PawnActionStatus::InProgress);

	if (GetActionLocalStatus() != EP3PawnActionStatus::InProgress)
	{
		// This can happen if client already finished(or failed) and multicast start is received
		// In this case, playing montage again can make things too complex, so better bail out
		return false;
	}

	if (bPlaying)
	{
		ensure(0);
		return false;
	}

	if (!GetOwnerComponent())
	{
		ActionJsonLog(Warning, "Play action montage failed", TEXT("Error"), TEXT("No owner component"));
		return false;
	}

	if (!ensure(AnimMontage))
	{
		ActionJsonLog(Warning, "Play action montage failed", TEXT("Error"), TEXT("No anim montage"));
		return false;
	}

	UAnimInstance* AnimInstance = GetAnimInstance(false);

	if (!ensure(AnimInstance))
	{
		ActionJsonLog(Warning, "Play action montage failed", TEXT("Error"), TEXT("No anim instance"));
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (Character)
	{
		Character->OnActionAnimNotify.AddUniqueDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotify);
		Character->OnActionAnimNotifyStateBegin.AddUniqueDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateBegin);
		Character->OnActionAnimNotifyStateEnd.AddUniqueDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateEnd);
	}

	const float Duration = AnimInstance->Montage_Play(AnimMontage, PlayRate,EMontagePlayReturnType::MontageLength, PlayMontagePosition);

	if (Duration == 0)
	{
		ActionJsonLog(Warning, "Play action montage failed", TEXT("Error"), TEXT("Duration 0"));
		return false;
	}

	FAnimMontageInstance* AnimMontageInstance = AnimInstance->GetActiveInstanceForMontage(AnimMontage);

	if (!AnimMontageInstance)
	{
		ActionJsonLog(Warning, "Play action montage failed", TEXT("Error"), TEXT("No anim montage instance"));
		return false;
	}

	ActionJsonLog(Display, "Montage_Play",
		TEXT("AnimMontage"), *AnimMontage->GetName(),
		TEXT("AnimMontageInstanceID"), AnimMontageInstance->GetInstanceID());

	bPlaying = true;
	PlayingMontageInstanceID = AnimMontageInstance->GetInstanceID();

 	if (bIsFinishOnMontageBlendingOut)
 	{
		AnimInstance->OnMontageBlendingOut.AddUniqueDynamic(this, &UP3PlayMontagePawnAction::OnMontageBlendingOut);
 	}
	else
	{
		AnimInstance->P3OnMontageEnded.AddUniqueDynamic(this, &UP3PlayMontagePawnAction::OnMontageEnded);
	}
	

	// TODO: need to figure out these again later. just setting these flag on player character blueprint for now.
	//// We need this flag to work properly at dedicated server
	//ensure(AnimInstance->GetSkelMeshComponent()->MeshComponentUpdateFlag == EMeshComponentUpdateFlag::AlwaysTickPoseAndRefreshBones);

#if !UE_BUILD_SHIPPING
	if (CVarP3ActionDebug.GetValueOnGameThread() >= 2)
	{
		AddDebugStringUntilFinish(FString::Printf(
			TEXT("Montage: %s"), *AnimMontage->GetName()));
	}
#endif

	if (Flags & Flags_FlyingMode)
	{
		UCharacterMovementComponent* MovementComp = Character ? Character->GetCharacterMovement() : nullptr;
		if (MovementComp)
		{
			MovementComp->SetMovementMode(EMovementMode::MOVE_Flying);
		}
	}

	return true;
}

void UP3PlayMontagePawnAction::StopAnimMontage()
{
	UAnimInstance* AnimInstance = GetAnimInstance(true);

	if (AnimInstance && AnimMontage && bPlaying)
	{
		AnimInstance->Montage_Stop(StopBlendOutTime, AnimMontage);
		bPlaying = false;
		bPlayedAtPreStart = false;
	}
}

bool UP3PlayMontagePawnAction::IsPlaying() const
{ 
	UAnimInstance* AnimInstance = GetAnimInstance();

	if (bPlaying && AnimInstance)
	{
		return AnimInstance->Montage_IsPlaying(AnimMontage);				
	}

	return false;
}

void UP3PlayMontagePawnAction::OnMontageEnded(UAnimMontage* EndedAnimMontage, bool bInterrupted, int32 MontageInstanceID)
{
	if (EndedAnimMontage != AnimMontage || !bPlaying)
	{
		// Not my montage, don't care
		return;
	}

	ActionJsonLog(Display, "Montage_End",
		TEXT("AnimMontage"), *AnimMontage->GetName(),
		TEXT("AnimMontageInstanceID"), MontageInstanceID);

	if (MontageInstanceID != PlayingMontageInstanceID)
	{
		return;
	}

	ensure(GetActionLocalStatus() == EP3PawnActionStatus::InProgress);

	if ((Flags & Flags_DoNotFinishOnEndMontage) == 0)
	{
		Finish(bInterrupted ? EP3PawnActionResult::Aborted : EP3PawnActionResult::Success);
	}

	UAnimInstance* AnimInstance = GetAnimInstance(true);
	if (AnimInstance)
	{
		AnimInstance->P3OnMontageEnded.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnMontageEnded);
	}

	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;
	if (Character)
	{
		Character->OnActionAnimNotify.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotify);
		Character->OnActionAnimNotifyStateBegin.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateBegin);
		Character->OnActionAnimNotifyStateEnd.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateEnd);
	}

	bPlaying = false;
}

void UP3PlayMontagePawnAction::OnMontageBlendingOut(UAnimMontage* BlendingOutAnimMontage, bool bInterrupted)
{
	if (BlendingOutAnimMontage != AnimMontage || !bPlaying)
	{
		// Not my montage, don't care
		return;
	}

	ensure(GetActionLocalStatus() == EP3PawnActionStatus::InProgress);

	if ((Flags & Flags_DoNotFinishOnEndMontage) == 0)
	{
		Finish(bInterrupted ? EP3PawnActionResult::Aborted : EP3PawnActionResult::Success);
	}

	UAnimInstance* AnimInstance = GetAnimInstance(true);
	if (AnimInstance)
	{
		AnimInstance->OnMontageBlendingOut.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnMontageBlendingOut);
	}

	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;
	if (Character)
	{
		Character->OnActionAnimNotify.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotify);
		Character->OnActionAnimNotifyStateBegin.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateBegin);
		Character->OnActionAnimNotifyStateEnd.RemoveDynamic(this, &UP3PlayMontagePawnAction::OnActionAnimNotifyStateEnd);
	}

	bPlaying = false;
}

void UP3PlayMontagePawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	AP3Character* Character = GetP3Character();

	if (NotifyType == EActionAnimNotifyType::DrawSupportHoldable)
	{
		if (ensure(Character))
		{
			Character->NativeAttachSupportHoldable();
		}
	}
	else if (NotifyType == EActionAnimNotifyType::PutawaySupportHoldable)
	{
		if (ensure(Character))
		{
			Character->NativeDetachSupportHoldable();
		}
	}

	else if (NotifyType == EActionAnimNotifyType::DropAllRiders)
	{
		if (!P3Core::IsP3NetModeServerInstance(*this))
		{
			return;
		}

		if (!ensure(Character))
		{
			return;
		}

		const TMap<int32, AP3Character*>& RiderCharacters = Character->GetCharacterStoreBP().MountRiderCharacters;

		TArray<AP3Character*> Riders;

		for (auto&& RiderCharacterIter : RiderCharacters)
		{
			if (RiderCharacterIter.Value && RiderCharacterIter.Value->IsMounted())
			{
				Riders.Add(RiderCharacterIter.Value);
			}
		}

		for (auto&& Rider : Riders)
		{
			UP3CommandComponent* CommandComp = Rider->GetCommandComponent();

			if (CommandComp)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.Mount_Detach = true;
				CommandComp->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
			}
		}
	}
}

void UP3PlayMontagePawnAction::OnActionAnimNotifyStateBegin(EActionAnimNotifyStateType NotifyStateType, float Duration)
{

}

void UP3PlayMontagePawnAction::OnActionAnimNotifyStateEnd(EActionAnimNotifyStateType NotifyStateType)
{

}

UP3CombatRollPawnAction::UP3CombatRollPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart);
}

bool UP3CombatRollPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		return false;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (StaminaComp)
	{
		if (StaminaComp->IsExhausted())
		{
			return false;
		}

		if (StaminaComp->GetStaminaPoint() < Character->GetCombatRollStamina())
		{
			return false;
		}
	}

	if (Character->IsMounted())
	{
		return false;
	}

	if (!Character->CanCombat())
	{
		return false;
	}

	return true;
}

void UP3CombatRollPawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	SelectAnimMontage(Params);

	AP3Character* Character = GetP3Character();
	if (Character && IsLocalControlledActor(Character))
	{
		Character->SetActorRotation(Params.Roll_Rotator);
	}

	Super::Autonomous_PreStartAction(Params);	
}

bool UP3CombatRollPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::DrawWeapon,
		EPawnActionType::PutAwayWeapon,
		EPawnActionType::CombatAttack,
		EPawnActionType::CombatCombo,
		EPawnActionType::CombatRangedAttack,
		EPawnActionType::Interact,
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3CombatRollPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	if (!IsPlayedAtPreStart())
	{
		SelectAnimMontage(Params.RequestParams);

		UP3PawnActionComponent* ActionComp = GetOwnerComponent();
		if (ActionComp && ActionComp->GetOwner() && !IsAutonomousProxy(ActionComp->GetOwner()))
		{
			ActionComp->GetOwner()->SetActorRotation(Params.RequestParams.Roll_Rotator);
		}
	}
	
	AP3Character* Character = GetP3Character();
	if (Character)
	{
		UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

		if (StaminaComp)
		{
			StaminaComp->ConsumeStamina(Character->GetCombatRollStamina());
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			UP3FlammableComponent* FlammableComp = Character->FindComponentByClass<UP3FlammableComponent>();
			if (FlammableComp && FlammableComp->IsInFire())
			{
				const float NewLeftFireDurationSeconds = FlammableComp->Server_GetLeftFireDurationSeconds() * 0.5f;
				FlammableComp->Server_SetLeftFireDurationSeconds(NewLeftFireDurationSeconds);
			}
		}
	}

	Super::Multicast_StartAction(Params);
}

void UP3CombatRollPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

	if (StaminaComp)
	{
		StaminaComp->SetConsumePerAction(0.0f);
	}
}

void UP3CombatRollPawnAction::SelectAnimMontage(const FP3PawnActionStartRequestParams& Params)
{
	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;

	if (!Character)
	{
		return;
	}
	
	const FVector ForwardVector = Params.Roll_CharacterForwardVector;
	const FVector Direction = Params.Roll_Direction.GetSafeNormal2D();
	
	const float Sin = ForwardVector.X * Direction.Y - Direction.X * ForwardVector.Y;
	const float Cos = ForwardVector.X * Direction.X + ForwardVector.Y * Direction.Y;

	// -PI ~ PI
	const float YawRadian = FMath::Atan2(Sin, Cos);

	// 0 ~ 360
	float YawDegree = FMath::RadiansToDegrees(YawRadian);
	if (YawDegree < 0.f)
	{
		YawDegree = 360.f + YawDegree;
	}

	// 0 ~ 8
	const int32 Index = FMath::FloorToInt((YawDegree + (45.0f * 0.5f)) / 45.0f);

	check(Index >= 0 && Index <= 8);

	EP3ActionAnimationType RollMontages[] = {
		EP3ActionAnimationType::RollForward,
		EP3ActionAnimationType::RollForwardRight,
		EP3ActionAnimationType::RollRight,
		EP3ActionAnimationType::RollBackwardRight,
		EP3ActionAnimationType::RollBackward,
		EP3ActionAnimationType::RollBackwardLeft,
		EP3ActionAnimationType::RollLeft,
		EP3ActionAnimationType::RollForwardLeft,
		EP3ActionAnimationType::RollForward,
	};

	SetAnimMontage(Character->GetAnimationByType(RollMontages[Index]));
}

UP3DrawWeaponPawnAction::UP3DrawWeaponPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3DrawWeaponPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		return false;
	}

	if (Character->GetStance() != EP3CharacterStance::Idle)
	{
		return false;
	}

	if (Character->IsPushing())
	{
		return false;
	}

	if (Character->IsMounted())
	{
		return false;
	}

	if (!Character->GetAnimationByType(EP3ActionAnimationType::DrawWeapon))
	{
		ActionJsonLog(Warning, "Failed to start draw weapon action. No Draw Weapon Montage found");
		return false;
	}

	return true;
}

bool UP3DrawWeaponPawnAction::CanSprint() const
{
	if (CVarP3CanSprintOnDraw.GetValueOnGameThread() > 0)
	{
		return true;
	}

	return false;
}

bool UP3DrawWeaponPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::PutAwayWeapon,		
		EPawnActionType::UseConsumable,
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;

	return false;
}

void UP3DrawWeaponPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UAnimMontage* Montage = Character->GetAnimationByType(EP3ActionAnimationType::DrawWeapon);
	
	if (!Montage)
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			ChangeCharacterStance(EP3CharacterStance::Combat, true);
		}

		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Montage);
	PlayAnimMontage();
	
	if (Character->IsGliding())
	{
		Character->BreakGlidingByAction(*this);
	}
}

void UP3DrawWeaponPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		AP3Character* Character = GetP3Character();

		if (!ensure(Character))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		if (!Character->CanCombat())
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}
}

void UP3DrawWeaponPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (Result == EP3PawnActionResult::Success)
	{
		ChangeCharacterStance(EP3CharacterStance::Combat, true);
	}
	else
	{
		// Restore temporary changed status from OnActionAnimNotify
		AP3Character* Character = GetP3Character();

		if (ensure(Character))
		{
			Character->ConsiderChangeWeaponAttachment();
		}
	}
}

void UP3DrawWeaponPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	if (NotifyType == EActionAnimNotifyType::DrawWeapon)
	{
		AP3Character* Character = GetP3Character();

		if (ensure(Character))
		{
			Character->NativeAttachWeapon();
		}
	}
	else if (NotifyType == EActionAnimNotifyType::DrawShield)
	{
		AP3Character* Character = GetP3Character();

		if (ensure(Character))
		{
			Character->NativeAttachShield();
		}
	}
	else if (NotifyType == EActionAnimNotifyType::PutawaySupportHoldable)
	{
		AP3Character* Character = GetP3Character();

		if (ensure(Character))
		{
			Character->NativeDetachSupportHoldable();
		}
	}
}

UP3PutawayWeaponPawnAction::UP3PutawayWeaponPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3PutawayWeaponPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		return false;
	}	

	if (Character->GetStance() != EP3CharacterStance::Combat)
	{
		return false;
	}
	
	if (Character->GetCharacterStoreBP().bIsBlocking)
	{
		return false;
	}

	if (!Character->GetAnimationByType(EP3ActionAnimationType::PutawayWeapon))
	{
		return false;	
	}

	return true;
}

bool UP3PutawayWeaponPawnAction::CanSprint() const
{
	if (CVarP3CanSprintOnPutAway.GetValueOnGameThread() > 0)
	{
		return true;
	}

	return false;
}

bool UP3PutawayWeaponPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::DrawWeapon,		
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;

	return false;
}

void UP3PutawayWeaponPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!Character->GetRightHandWeaponActor())
	{
		// No weapon to put away
		Finish(EP3PawnActionResult::Success);
		return;
	}
	
	UAnimMontage* Montage = Character->GetAnimationByType(EP3ActionAnimationType::PutawayWeapon);
	if (!Montage)
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			ChangeCharacterStance(EP3CharacterStance::Idle, true);
		}

		Finish(EP3PawnActionResult::Failed);
		return;
	}

	Character->SetAimingByAction(*this, false);
	SetAnimMontage(Montage);
	PlayAnimMontage();
}

void UP3PutawayWeaponPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (Result == EP3PawnActionResult::Success)
	{
		ChangeCharacterStance(EP3CharacterStance::Idle, true);
	}
	else
	{
		// Restore temporary changed status from OnActionAnimNotify
		AP3Character* Character = GetP3Character();

		if (ensure(Character))
		{
			Character->ConsiderChangeWeaponAttachment();
		}
	}
}

void UP3PutawayWeaponPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::PutawayWeapon)
	{
		AP3Character* Character = GetP3Character();

		if (ensure(Character))
		{
			Character->NativeDetachWeapon();
		}
	}
	else if (NotifyType == EActionAnimNotifyType::PutawayShield)
	{
		AP3Character* Character = GetP3Character();

		if (ensure(Character))
		{
			Character->NativeDetachShield();
		}
	}
}

UP3CombatAttackPawnAction::UP3CombatAttackPawnAction()
{
	if (CVarP3CombatAttackPreStart.GetValueOnGameThread() == 1)
	{
		SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart);
	}
}

void UP3CombatAttackPawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	float NewPlayRate = 1.0f;

	SetAnimMontage(GetAttackMontage(Params));
	SetPlayRate(GetAttackMontagePlayRate());

	Super::Autonomous_PreStartAction(Params);

	if (IsPlayedAtPreStart())
	{
		AnimNotifyGenerator.Start(GetAnimMontage(), GetWorld()->GetTimeSeconds(), GetAttackMontagePlayRate());
		CurrentCombo = 1;
		StopComboAfter = 0;
	}
}

bool UP3CombatAttackPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		return false;
	}

	if (Character->GetStance() != EP3CharacterStance::Combat)
	{
		ActionJsonLog(Warning, "Attack action start failed. Not in combat stance");
		return false;
	}

	AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
	if (Weapon && (Weapon->GetActionStamina() > 0) && Character->GetStaminaComponent()->IsExhausted())
	{
		return false;
	}

	// Need to check weapon type?

	return true;
}

bool UP3CombatAttackPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::DrawWeapon,
		EPawnActionType::UseConsumable,
		EPawnActionType::CombatHit,		
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3CombatAttackPawnAction::Server_FillAuthorityStopParams(FP3PawnActionStopAuthorityParams& OutParams) const
{
	Super::Server_FillAuthorityStopParams(OutParams);

	if (StopComboAfter < CurrentCombo)
	{
		OutParams.StopComboAfter = CurrentCombo;
	}
	else
	{
		// Player click attack key repeatedly, let's extend one more attack
		OutParams.StopComboAfter = CurrentCombo + 1;
	}
}

void UP3CombatAttackPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
	if (!ensure(CombatComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetActor = Params.RequestParams.CombatAttack_Target.Actor;

	// Rotate to target, if needed
	if (CVarP3CombatRotateToTarget.GetValueOnGameThread() == 1)
	{
		if (!Params.RequestParams.CombatAttack_ChracterRotator.IsZero())
		{
			Character->SetActorRotation(Params.RequestParams.CombatAttack_ChracterRotator);
		}
	}
	else if (CVarP3CombatRotateToTarget.GetValueOnGameThread() == 2)
	{
		if (Params.RequestParams.CombatAttack_Target.Actor)
		{
			const FVector Offset = Params.RequestParams.CombatAttack_Target.Actor->GetActorLocation() - Character->GetActorLocation();
			Character->SetActorRotation(Offset.GetSafeNormal2D().Rotation());
		}
	}

	// Play montage, if needed
	if (!IsPlayedAtPreStart())
	{
		SetAnimMontage(GetAttackMontage(Params.RequestParams));
		SetPlayRate(GetAttackMontagePlayRate());
	}

	// Start skill, if requested
	if (Params.RequestParams.CombatAttack_SkillIndex != -1)
	{
		SkillIndex = Params.RequestParams.CombatAttack_SkillIndex;

		if (!ensure(CombatComp->GetSkills().IsValidIndex(SkillIndex)))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
		
		CurrentCmsCombatSkill = *(CombatComp->GetCmsCombatSkill(SkillIndex));

		if (P3Core::IsP3NetModeServerInstance(*Character))
		{
			CombatComp->Server_OnSkillStarted(SkillIndex);
			
			if (CurrentCmsCombatSkill.bIsBucking)
			{
				UP3CommandComponent* CommandComp = Character->GetCommandComponent();
				if (CommandComp)
				{
					FP3CommandRequestParams CommandParams;
					CommandParams.Bucking_bInBucking = true;
					CommandComp->RequestCommand(UP3SetBuckingCommand::StaticClass(), CommandParams);
				}
			}
		}
	}
	
	Super::Multicast_StartAction(Params);

	if (SkillIndex >= 0 && P3Core::IsP3NetModeServerInstance(*this))
	{
		// 스킬일 경우, 루트 모션이 네비게이션 메시를 벗어나면 액션 실패로 처리 (엉뚱한 곳으로 가지 않기 위해)
		const bool bHasInvalidLocation = IsRootMotionHasInvalidLocation();

		if (bHasInvalidLocation)
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	// Reset combo state, if needed
	if (!IsPlayedAtPreStart())
	{
		const float Now = GetWorld()->GetTimeSeconds();
		const float PreDecisionAmount = CVarP3CombatAttackPreDecisionAmount.GetValueOnGameThread() / 1000.0f;
		AnimNotifyGenerator.Start(GetAnimMontage(), Now - PreDecisionAmount, GetAttackMontagePlayRate());
		CurrentCombo = 1;
		StopComboAfter = 0;
	}

	// Stop gliding
	if (Character->IsGliding())
	{
		Character->BreakGlidingByAction(*this);
	}

	// Consume stamina
	if (Character->GetStaminaComponent())
	{
		AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
		if (Weapon && Weapon->GetActionStamina() > 0)
		{
			Character->GetStaminaComponent()->ConsumeStamina(Weapon->GetActionStamina());
		}
		if (SkillIndex != -1)
		{
			const float SkillStaminaConsume = CurrentCmsCombatSkill.StaminuaConsume;
			if (SkillStaminaConsume > 0)
			{
				Character->GetStaminaComponent()->ConsumeStamina(SkillStaminaConsume);
			}
		}
	}

#if !UE_BUILD_SHIPPING
	if (CVarP3ActionDebug.GetValueOnGameThread() >= 2)
	{
		AddDebugStringUntilFinish(FString::Printf(
			TEXT("Skill: %d"), SkillIndex));
	}
#endif
}

void UP3CombatAttackPawnAction::Multicast_StopAction(const FP3PawnActionStopMulticastParams& Params)
{
	StopComboAfter = Params.AuthorityParams.StopComboAfter;
}

static void _BroadcastHitAnimNotify(AP3Character& Character, const UAnimNotify_Hit& HitNotify, int32 SkillIndex, const AActor* TargetActor, int32 ActionId, const UAnimSequenceBase* AnimSequence)
{
	const FP3CmsCombatHit* CmsCombatHit = P3Cms::GetCombatHit(HitNotify.CmsCombatHitKey);
	if (!CmsCombatHit)
	{
		P3JsonLog(Warning, "Invalid CmsCombatHitKey",
			TEXT("Key"), *HitNotify.CmsCombatHitKey.ToString(),
			TEXT("Character"), *Character.GetFullName(),
			TEXT("Animation"), AnimSequence ? *AnimSequence->GetFullName() : TEXT("NULL"));
		return;
	}

	FVector LocalImpactDirection;

	switch (CmsCombatHit->AttackDirection)
	{
	case EAnimNotifyAttackDirectionFlags::Left:
		LocalImpactDirection = FVector(0, -1, 0);
		break;

	case EAnimNotifyAttackDirectionFlags::Right:
		LocalImpactDirection = FVector(0, 1, 0);
		break;

	case EAnimNotifyAttackDirectionFlags::Up:
		LocalImpactDirection = FVector(0, 0, 1);
		break;

	case EAnimNotifyAttackDirectionFlags::Down:
		LocalImpactDirection = FVector(0, 0, -1);
		break;

	case EAnimNotifyAttackDirectionFlags::Pull:
		LocalImpactDirection = FVector(-1, 0, 0);
		break;

	case EAnimNotifyAttackDirectionFlags::Push:
		LocalImpactDirection = FVector(1, 0, 0);
		break;

	default:
		ensureMsgf(0, TEXT("unhandled direction: %d"), static_cast<int32>(CmsCombatHit->AttackDirection));
		LocalImpactDirection = FVector(0, -1, 0);
		break;
	}

	UP3CombatComponent* CombatComp = Character.GetP3CombatComponentBP();
	if (ensure(CombatComp))
	{
		CombatComp->Server_OnHitNotify(*CmsCombatHit, LocalImpactDirection, SkillIndex, TargetActor, HitNotify.CmsCombatHitKey, ActionId, AnimSequence, HitNotify.SocketName);
	}
}

void UP3CombatAttackPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this) && SkillIndex != -1)
	{
		if (CurrentCmsCombatSkill.bIsBucking)
		{
			const TMap<int32, AP3Character*>& RiderCharacters = Character->GetCharacterStoreBP().MountRiderCharacters;

			for (auto&& RiderCharacterIter : RiderCharacters)
			{
				AP3Character* RiderCharacter = RiderCharacterIter.Value;
				if (RiderCharacter && RiderCharacter->IsMounted())
				{
					UP3PawnActionComponent* RiderActionComp = RiderCharacter->GetActionComponent();
					if (RiderActionComp && RiderActionComp->GetActiveActionType() != EPawnActionType::BuckingHangOn)
					{
						FP3PawnActionStartRequestParams Params;
						Params.BuckingEndure_RemoveStaminaOfMountedCharacterPerSeconds = CurrentCmsCombatSkill.RemoveStaminaOfMountedCharacterPerSeconds;

						RiderActionComp->StartAction(EPawnActionType::BuckingHangOn, _FUNCTION_TEXT, Params);
					}
				}
			}
		}
	}

	if (CVarP3CombatRotateToTarget.GetValueOnGameThread() == 2)
	{
		if (TargetActor)
		{
			const FVector Offset = TargetActor->GetActorLocation() - Character->GetActorLocation();
			Character->SetActorRotation(Offset.GetSafeNormal2D().Rotation());
		}
	}

	// Process anim notifications
	// TODO: this doesn't support Section, so we just skip when playing 'returning section' for now
	if (IsPlaying() && !bReturning)
	{
		TArray<FAnimNotifyEventReference> AnimNotifyEventReferences = AnimNotifyGenerator.TickAndNotifies(DeltaSeconds);

		for (const FAnimNotifyEventReference& AnimNotifyEventReference : AnimNotifyEventReferences)
		{
			const FAnimNotifyEvent* AnimNotifyEvent = AnimNotifyEventReference.GetNotify();
			if (!AnimNotifyEvent || !AnimNotifyEvent->Notify)
			{
				continue;
			}

			UAnimNotify_Hit* HitNotify = Cast<UAnimNotify_Hit>(AnimNotifyEvent->Notify);
			if (HitNotify)
			{
				_BroadcastHitAnimNotify(*Character, *HitNotify, SkillIndex, TargetActor, GetActionId(), GetAnimMontage());
			}

			UAnimNotify_AttackStoppable* StoppableNotify = Cast<UAnimNotify_AttackStoppable>(AnimNotifyEvent->Notify);
			if (StoppableNotify)
			{
				if (StopComboAfter != 0 && StopComboAfter <= CurrentCombo)
				{
					bool bReturnSectionPlayed = false;

					if (Character->GetMesh()->GetAnimInstance())
					{
						const FName ReturnSectionName = FName(*FString::Printf(TEXT("Return%d"), CurrentCombo));

						Character->GetMesh()->GetAnimInstance()->Montage_JumpToSection(ReturnSectionName, GetAnimMontage());

						bReturnSectionPlayed = (Character->GetMesh()->GetAnimInstance()->Montage_GetCurrentSection(GetAnimMontage()) == ReturnSectionName);

						bReturning = true;
					}

					if (!bReturnSectionPlayed)
					{
						Finish(EP3PawnActionResult::Success);
					}
				}
				++CurrentCombo;
				break;
			}
		}
	}
}

bool UP3CombatAttackPawnAction::IsIgnoreMoveInput() const
{
	return (CVarP3CombatAttackIgnoreMoveInput.GetValueOnGameThread() == 1);
}

float UP3CombatAttackPawnAction::GetMoveSpeedMultiplier() const
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		return 1.0f;
	}

	AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());

	if (Weapon)
	{
		return Weapon->GetMoveSpeedMultiplayerDuringAttack();
	}

	return 1.0f;
}

void UP3CombatAttackPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	TargetActor = nullptr;
	SkillIndex = -1;
	bReturning = false;

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

	if (StaminaComp)
	{
		StaminaComp->SetConsumePerAction(0.0f);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		if (CommandComp)
		{
			FP3CommandRequestParams Params;
			Params.Bucking_bInBucking = false;
			CommandComp->RequestCommand(UP3SetBuckingCommand::StaticClass(), Params);
		}
	}
}

void UP3CombatAttackPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);
}

class UAnimMontage* UP3CombatAttackPawnAction::GetAttackMontage(const FP3PawnActionStartRequestParams& Params) const
{
	UAnimMontage* Montage = nullptr;

	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;
	if (ensure(Character))
	{
		UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();

		if (Params.CombatAttack_bIsTurningAttack)
		{
			if (!ensure(Params.CombatAttack_Target.Actor))
			{
				return nullptr;
			}

			if (!ensure(CombatComp))
			{
				return nullptr;
			}

			// Clamp If TurningAttackIndex is out of range
			FMath::Clamp(Params.CombatAttack_TurningAttackIndex, 0, (CombatComp->GetTurningAttackAnimations().Num()) - 1);

			if (!ensure(((CombatComp->GetTurningAttackAnimations()[Params.CombatAttack_TurningAttackIndex])->TurningAttackAnimations).Num() > 0))
			{
				return nullptr;
			}

			const FVector TargetLocation = Params.CombatAttack_Target.Actor->GetActorLocation();
			const FVector TargetDirection = TargetLocation - Character->GetActorLocation();
			const FRotator SourceToTargetRotation = TargetDirection.GetSafeNormal2D().Rotation();

			const int32 NumAnims = ((CombatComp->GetTurningAttackAnimations()[Params.CombatAttack_TurningAttackIndex])->TurningAttackAnimations).Num();
			const float YawDelta = FMath::UnwindDegrees((SourceToTargetRotation - Character->GetActorRotation()).Yaw);
			const float YawDeltaIn0To360 = (YawDelta < 0) ? YawDelta + 360.0f : YawDelta;
			const float AnimStep = 360.0f / NumAnims;
			const int32 AnimIndex = FMath::RoundToInt(YawDeltaIn0To360 / AnimStep) % NumAnims;
			if (ensure(((CombatComp->GetTurningAttackAnimations()[Params.CombatAttack_TurningAttackIndex])->TurningAttackAnimations).IsValidIndex(AnimIndex)))
			{
				Montage = ((CombatComp->GetTurningAttackAnimations()[Params.CombatAttack_TurningAttackIndex])->TurningAttackAnimations)[AnimIndex];

#if !UE_BUILD_SHIPPING
				if (CVarP3ActionDebug.GetValueOnGameThread() >= 2)
				{
					AddDebugStringUntilFinish(FString::Printf(
						TEXT("<Turning Attack> NumAnims(%d), Yaw(%.0f'), AnimIndex(%d)\r\n  Anim(%s)"),
						NumAnims, YawDelta, AnimIndex, Montage ? *Montage->GetName() : TEXT("NULL")));
				}
#endif
			}
		}
		else if (Params.CombatAttack_bIsShieldAttack)
		{
			Montage = Character->GetAnimMontages().ShieldAttacks[Params.CombatAttack_MontageIndex];
		}
		else if (Params.CombatAttack_SkillIndex >= 0)
		{
			if (ensure(CombatComp))
			{
				const FP3CmsCombatSkill* CmsCombatSkill = CombatComp->GetCmsCombatSkill(Params.CombatAttack_SkillIndex);
				if (CmsCombatSkill)
				{
					Montage = CmsCombatSkill->AnimMontage.LoadSynchronous();
				}
				else
				{
					ActionJsonLog(Warning, "Invalid skill index", TEXT("SkillIndex"), Params.CombatAttack_SkillIndex);
				}
			}
		}
		else if (Params.CombatAttack_bIsMountedAttack)
		{
			Montage = Character->GetAnimMontages().MountedAttack;
		}
		else
		{
			Montage = Character->GetAnimMontages().Attacks[Params.CombatAttack_MontageIndex];

			if (ensure(CombatComp))
			{
				const EP3WeaponType WeaponType = Character->GetRightHandWeaponType();
				const FP3CombatWeapon* CombatWeapon = CombatComp->GetWeapons().Find(WeaponType);

				if (CombatWeapon)
				{
					if (CombatWeapon->ForwardAttackAnim && Params.CombatAttack_MoveInputLocalVector.X > 0.8f)
					{
						Montage = CombatWeapon->ForwardAttackAnim;
					}
					else
					{
						Montage = CombatWeapon->NormalAttackAnim;
					}
				}
			}
		}
	}

	ensure(Montage);

	return Montage;
}

float UP3CombatAttackPawnAction::GetAttackMontagePlayRate() const
{
	float AttackPlayRate = 1.0f;

	AP3Character* Character = GetP3Character();
	AP3Weapon* Weapon = Character ? Cast<AP3Weapon>(Character->GetRightHandWeaponActor()) : nullptr;

	if (Weapon)
	{
		AttackPlayRate = Weapon->GetFireRate();
	}

	return AttackPlayRate;
}

bool UP3CombatAttackPawnAction::IsRootMotionHasInvalidLocation() const
{
	if (!CurrentCmsCombatSkill.bSafeRootMotion)
	{
		return false;
	}

	if (CurrentCmsCombatSkill.bAdapted)
	{
		// 아직 지원 안됨
		return false;
	}

	UAnimMontage* Montage = GetAnimMontage();

	if (!Montage)
	{
		return false;
	}

	if (!Montage->HasRootMotion())
	{
		return false;
	}

	AP3Character* Character = GetP3Character();

	if (!ensure(Character && Character->GetMesh()))
	{
		return false;
	}

	AAIController* AICon = Character->GetController<AAIController>();

	if (!ensure(AICon))
	{
		return false;
	}

	UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
	if (!ensure(NavSys))
	{
		return false;
	}

	const FNavAgentProperties& AgentProps = AICon->GetNavAgentPropertiesRef();
	const FTransform CharacterMeshTransform = Character->GetMesh()->GetComponentTransform();

	// 0.1초 간격으로 루트모션을 추적해서 Navigation 을 벗어나는지 확인하기
	const float StepSeconds = 0.1f;
	const float MontageLength = Montage->GetPlayLength();
	
	for (float Time = 0.0f; Time < MontageLength; Time += StepSeconds)
	{
		const FTransform RootMotionTransform = Montage->ExtractRootMotionFromTrackRange(0, Time);

		FNavLocation ProjectedLocation;

		const FVector Location = CharacterMeshTransform.TransformPosition(RootMotionTransform.GetTranslation());

		if (!NavSys->ProjectPointToNavigation(Location, ProjectedLocation, INVALID_NAVEXTENT, &AgentProps))
		{
			// 네비게이션 메시가 없는 위치 발견!

#if ENABLE_DRAW_DEBUG
			if (CVarP3ActionDebug.GetValueOnGameThread() != 0)
			{
				DrawDebugSphere(GetWorld(), Location, 30.0f, 16, FColor::Red, true, 3.0f);
			}
#endif
			return true;
		}

#if ENABLE_DRAW_DEBUG
		if (CVarP3ActionDebug.GetValueOnGameThread() != 0)
		{
			DrawDebugSphere(GetWorld(), Location, 30.0f, 16, FColor::Green, true, 3.0f);
		}
#endif
	}

	return false;
}

bool UP3CombatRangedAttackPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		return false;
	}

	if (Character->GetStance() != EP3CharacterStance::Combat)
	{
		return false;
	}

	if (!IsRangedWeapon(Character->GetRightHandWeaponType()))
	{
		return false;
	}

	AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
	if (Weapon && (Weapon->GetActionStamina() > 0) && Character->GetStaminaComponent()->IsExhausted())
	{
		return false;
	}

	return true;
}

void UP3CombatRangedAttackPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());

	if (!ensure(Weapon))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().RangedAttack);
	SetPlayRate(Weapon->GetFireRate());

	CharacterRotator = Params.RequestParams.CombatRangedAttack_CharacterRotator;

	if (Character->IsGliding())
	{
		Character->BreakGlidingByAction(*this);
	}

	Super::Multicast_StartAction(Params);
}

bool UP3CombatRangedAttackPawnAction::IsIgnoreMoveInput() const
{
	return (CVarP3CombatAttackIgnoreMoveInput.GetValueOnGameThread() == 1);
}

float UP3CombatRangedAttackPawnAction::GetMoveSpeedMultiplier() const
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		return 1.0f;
	}

	AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());

	if (ensure(Weapon))
	{
		return Weapon->GetMoveSpeedMultiplayerDuringAttack();
	}

	return 1.0f;
}

void UP3CombatRangedAttackPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	if (NotifyType != EActionAnimNotifyType::Fire)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3Weapon* WeaponActor = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());

	if (!ensure(WeaponActor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	Multicast_OnFire(*Character, *WeaponActor);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		Server_OnFire(*Character, *WeaponActor);
	}
}

void UP3CombatRangedAttackPawnAction::Multicast_OnFire(AP3Character& Character, AP3Weapon& WeaponActor)
{
	if (WeaponActor.GetProjectileFireSound())
	{
		FVector MuzzleLocation = WeaponActor.GetActorLocation();
		ensure(P3GetMuzzleLocation(WeaponActor, MuzzleLocation));

		UGameplayStatics::PlaySoundAtLocation(GetWorld(), WeaponActor.GetProjectileFireSound(), MuzzleLocation);

		WeaponActor.Multicast_OnFireBP();
	}

	if (WeaponActor.GetActionStamina() > 0)
	{
		Character.GetStaminaComponent()->ConsumeStamina(WeaponActor.GetActionStamina());
	}
}

void UP3CombatRangedAttackPawnAction::Server_OnFire(AP3Character& Character, AP3Weapon& WeaponActor)
{
	const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(WeaponActor.GetClass()));
	if (!ensure(CmsHoldable))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UClass* ProjectileClass = CmsHoldable->ProjectileClass.LoadSynchronous();
	if (!ensure(ProjectileClass))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	FVector SpawnLocation = WeaponActor.GetActorLocation();

	ensure(P3GetMuzzleLocation(WeaponActor, SpawnLocation));

	FActorSpawnParameters ActorSpawnParams;
	ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	for (int32 Index = 0; Index < WeaponActor.GetNumProjectiles(); ++Index)
	{
		const FVector RandomDirection = FMath::VRandCone(FVector(1, 0, 0), FMath::DegreesToRadians(WeaponActor.GetProjectileRandomConeDegree() * 0.5f));
		const FRotator RandomRotator = CharacterRotator.RotateVector(RandomDirection).ToOrientationRotator();

		AP3Projectile* Projectile = GetWorld()->SpawnActor<AP3Projectile>(ProjectileClass, SpawnLocation, RandomRotator, ActorSpawnParams);

		if (ensure(Projectile))
		{
			Projectile->Server_SetSourceCharacter(&Character);
			Projectile->Server_SetWeaponActor(&WeaponActor);

			WeaponActor.Server_SetLastFiredProjectile(Projectile);

			P3Core::GetP3World(*this)->Server_FireScareFlockEvent(SpawnLocation, 3000, 10.0f);
		}
	}
}

void UP3CombatRangedAttackPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

	if (StaminaComp)
	{
		StaminaComp->SetConsumePerAction(0.0f);
	}
}

UP3CombatHitPawnAction::UP3CombatHitPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3CombatHitPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::DrawWeapon,
		EPawnActionType::PutAwayWeapon,
		EPawnActionType::CombatAttack,
		EPawnActionType::CombatCombo,
		EPawnActionType::CombatRangedAttack,
		EPawnActionType::CombatProjectileSkillAttack,
		EPawnActionType::CombatHit,		
		EPawnActionType::CombatRoll,
		EPawnActionType::UseConsumable,
		EPawnActionType::Rescue,
		EPawnActionType::Breakfall,
		EPawnActionType::Interact
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

bool UP3CombatHitPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	return true;
}

void UP3CombatHitPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	const FVector ImpactDirection = Params.RequestParams.CombatHit_ImpactDirection;
	const bool bWasKnockDowned = Character->GetCharacterStoreBP().bKnockDowned;

	// Do not disturb by playing hit animation if target is already knock downed
	if (bWasKnockDowned)
	{
		Finish(EP3PawnActionResult::Success);
		return;
	}

	bIsKnockDown = Params.RequestParams.CombatHit_bIsKnockDown;
	bHasImpulse = !Params.RequestParams.CombatHit_Impulse.IsNearlyZero();
	const bool bIsPushBack = Params.RequestParams.CombatHit_bIsPushBack;
	const bool bIsKnockBack = (bIsKnockDown && bHasImpulse);	
	const bool bIsMounted = Character->IsMounted() && Character->GetAnimMontages().MountedHit;
	const bool bIsBreakBlock = Params.RequestParams.CombatHit_bBreakBlock && (Character->GetCharacterStoreBP().bIsBlocking || Character->GetCharacterStoreBP().bIsCrouchBlocking);

	// Rotate character if needed
	// Note: this must be done before select anim montage below, since anim montage will be selected based on character rotation
	if (!Params.RequestParams.CombatHit_Rotator.IsZero() && !Character->GetAttachParentActor())
	{
		FRotator HitRotator = Params.RequestParams.CombatHit_Rotator;

		if (Character->GetP3CharacterMovementBP()->ShouldRemainVertical())
		{
			HitRotator.Pitch = 0.f;
			HitRotator.Yaw = FRotator::NormalizeAxis(HitRotator.Yaw);
			HitRotator.Roll = 0.f;
		}

		Character->SetActorRotation(HitRotator);
	}

	// Select Hit anim montage	
	EP3ActionAnimationType HitAnimMontageType = EP3ActionAnimationType::HitLeft;

	if (bIsMounted)
	{
		SetAnimMontage(Character->GetAnimMontages().MountedHit);
	}
	else if (bIsBreakBlock)
	{
		HitAnimMontageType = Character->GetCharacterStoreBP().bIsCrouchBlocking ? EP3ActionAnimationType::BreakCrouchBlock : EP3ActionAnimationType::BreakBlock;			
	}
	else if (bIsKnockBack)
	{
		bPlayingKnockBackMontage = true;
		HitAnimMontageType = GetKnockBackMontageType(Character, ImpactDirection);
	}
	else if (bIsKnockDown)
	{
		HitAnimMontageType = EP3ActionAnimationType::HitKnockDown;			
	}
	else if (bIsPushBack)
	{
		HitAnimMontageType = GetPushBackMontageType(Character, ImpactDirection);
	}
	else if (Params.RequestParams.CombatHit_ImpactLocalDirection.Y > 0)
	{
		HitAnimMontageType = EP3ActionAnimationType::HitRight;
	}

	Character->GetP3CharacterMovementBP()->AddImpulse(Params.RequestParams.CombatHit_Impulse, false);
	Character->GetMesh()->AddImpulseToAllBodiesBelow(Params.RequestParams.CombatHit_Impulse, NAME_None, false);
	
	SetAnimMontage(Character->GetAnimationByType(HitAnimMontageType));

	const bool bPlayed = PlayAnimMontage();

	if (!ensure(bPlayed))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	if (!IsRangedWeapon(Params.RequestParams.CombatHit_WeaponType))
	{
		const AP3Character* CombatHitSourceCharacter = Cast<AP3Character>(Params.RequestParams.CombatHit_SourceActor.Actor);
		if (CombatHitSourceCharacter)
		{
			const UP3CharacterSounds* CharacterSounds = CombatHitSourceCharacter->GetCharacterSounds();
			if (CharacterSounds)
			{
				USoundBase* HitSound = CharacterSounds->GetHit();
				if (bIsMounted)
				{
					HitSound = CharacterSounds->GetMountedHit();
				}
				else if (bIsBreakBlock)
				{
					HitSound = CharacterSounds->GetBreakBlock();
				}
				else if (bIsKnockBack)
				{
					HitSound = CharacterSounds->GetKnockBack();
				}
				else if (bIsKnockDown)
				{
					HitSound = CharacterSounds->GetKnockDown();
				}
				else if (bIsPushBack)
				{
					HitSound = CharacterSounds->GetPushBack();
				}

				UGameplayStatics::PlaySoundAtLocation(GetWorld(), HitSound, Character->GetActorLocation());
			}
		}		
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		Character->GetCommandComponent()->RequestCommand(UP3DropPickableCommand::StaticClass(), FP3CommandRequestParams());

		if (bIsBreakBlock)
		{
			if (Character->GetCharacterStoreBP().bIsBlocking)
			{				
				FP3CommandRequestParams BlockingCommandParams;
				BlockingCommandParams.SetBlocking_bNewBlocking = false;
				Character->GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), BlockingCommandParams);
			}

			if (Character->GetCharacterStoreBP().bIsCrouchBlocking)
			{			
				FP3CommandRequestParams CrouchBlockingCommandParams;
				CrouchBlockingCommandParams.SetCrouchBlocking_bNewBlocking = false;
				Character->GetCommandComponent()->RequestCommand(UP3SetCrouchBlockingCommand::StaticClass(), CrouchBlockingCommandParams);
			}
		}
	}
}

void UP3CombatHitPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
		if (!Character || !Character->GetMesh() || !Character->GetMesh()->GetAnimInstance())
		{
			return;
		}

		if (Character->IsDead())
		{
			if (Character->GetMesh()->GetAnimInstance()->Montage_GetPosition(nullptr) > 0.1f
				&& Character->GetCommandComponent())
			{
				FP3CommandRequestParams Params;
				Params.Ragdollize_bRagdoll = true;
				Character->GetCommandComponent()->RequestCommand(UP3RagdollizeCommand::StaticClass(), Params);
			}
		}
	}
}

EP3ActionAnimationType UP3CombatHitPawnAction::GetKnockBackMontageType(AP3Character* Character, const FVector& Impulse) const
{
	EP3ActionAnimationType OutMontageType = EP3ActionAnimationType::HitKnockBackBackward;

	const FVector LocalImpulse = Character->GetActorQuat().UnrotateVector(Impulse);

	// -180 ~ +180
	const float LocalImpulseYaw = FMath::RadiansToDegrees(FMath::Atan2(LocalImpulse.Y, LocalImpulse.X));

	// 0 ~ 360
	const float LocalImpulseYawIn360 = LocalImpulseYaw < 0 ? LocalImpulseYaw + 360 : LocalImpulseYaw;
	const int32 ImpulseIndex = FMath::RoundToInt(LocalImpulseYawIn360 / 90.0f) % 4;

	EP3ActionAnimationType KnockBackMontages4[] = {
		EP3ActionAnimationType::HitKnockBackForward,
		EP3ActionAnimationType::HitKnockBackRight,
		EP3ActionAnimationType::HitKnockBackBackward,
		EP3ActionAnimationType::HitKnockBackLeft,		
	};

	if (ensure(ImpulseIndex >= 0 && ImpulseIndex < ARRAY_COUNT(KnockBackMontages4)))
	{
		OutMontageType = KnockBackMontages4[ImpulseIndex];		
	}

	return OutMontageType;
}

EP3ActionAnimationType UP3CombatHitPawnAction::GetPushBackMontageType(AP3Character* Character, const FVector& Impulse) const
{
	EP3ActionAnimationType OutMontageType = EP3ActionAnimationType::HitPushBackBackward;

	const FVector LocalImpulse = Character->GetActorQuat().UnrotateVector(Impulse);

	// -180 ~ +180
	const float LocalImpulseYaw = FMath::RadiansToDegrees(FMath::Atan2(LocalImpulse.Y, LocalImpulse.X));

	// 0 ~ 360
	const float LocalImpulseYawIn360 = LocalImpulseYaw < 0 ? LocalImpulseYaw + 360 : LocalImpulseYaw;
	const int32 ImpulseIndex = FMath::RoundToInt(LocalImpulseYawIn360 / 90.0f) % 4;

	EP3ActionAnimationType PushBackMontages4[] = {
		EP3ActionAnimationType::HitPushBackForward,
		EP3ActionAnimationType::HitPushBackRight,
		EP3ActionAnimationType::HitPushBackBackward,
		EP3ActionAnimationType::HitPushBackLeft,		
	};

	if (ensure(ImpulseIndex >= 0 && ImpulseIndex < ARRAY_COUNT(PushBackMontages4)))
	{
		OutMontageType = PushBackMontages4[ImpulseIndex];
	}

	return OutMontageType;
}

bool UP3CombatHitPawnAction::IsIgnoreMoveInput() const 
{ 
	return bIsKnockDown;
}

float UP3CombatHitPawnAction::GetMoveSpeedMultiplier() const
{
	if (bPlayingKnockBackMontage)
	{
		return 10.0f;
	}
	else if (bHasImpulse)
	{
		return 0.0f;
	}

	return 1.0f;
}

bool UP3CombatHitPawnAction::IsMoveAllowed() const
{
	AP3Character* Character = GetP3Character();

	if (Character && !(Character->IsPlayerControlled()) && !(Character->IsLarge()))
	{
		return false;
	}

	return true;
}

bool UP3CombatHitPawnAction::IsRotateAllowed() const
{
	AP3Character* Character = GetP3Character();

	if (Character && !(Character->IsPlayerControlled()) && !(Character->IsLarge()))
	{
		return false;
	}

	return true;
}

bool UP3CombatHitPawnAction::IsJumpAllowed() const
{
	AP3Character* Character = GetP3Character();

	if (Character && !(Character->IsPlayerControlled()) && !(Character->IsLarge()))
	{
		return false;
	}

	return true;
}

void UP3CombatHitPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	bIsKnockDown = false;
	bHasImpulse = false;
	bPlayingKnockBackMontage = false;
}

void UP3CombatHitPawnAction::DropPickupable()
{
	/*AP3Character* Character = GetP3Character();

	UP3PickupComponent* PickupComp = Character ? Character->GetPickupComponent() : nullptr;

	if (PickupComp && PickupComp->GetPickuppedActor())
	{
		// TODO: We have need to see if target actor is same as requested one
		AActor* TargetActor = PickupComp->GetPickuppedActor();
		if (!TargetActor->IsActorBeingDestroyed())
		{
			TargetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

			UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());

			if (PrimComp)
			{
				UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
				if (ensure(PickupableComp))
				{
					PickupableComp->RestorePhysicsAfterPutdown();
				}

				if (IsAuthority(GetOwnerComponent()->GetOwner()))
				{
					AP3Destructible* Destructible = Cast<AP3Destructible>(TargetActor);
					if (Destructible)
					{
						Destructible->Server_SetPOIOriginLocation(GetOwnerComponent()->GetOwner()->GetActorLocation());
					}
				}
			}

			PickupComp->OnThrowActionFinished();	
		}
	}*/


}

bool UP3CombatHitFlamePawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (OtherActionType == EPawnActionType::CombatRoll)
	{
		return false;
	}

	return Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params);
}

bool UP3CombatHitFlamePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (GetP3Character() && GetP3Character()->IsFlameHitActionIgnored())
	{
		return false;
	}

	return Super::CanStart(Params);
}

bool UP3StartBlockPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (Character)
	{
		if (!Character->CanBlock())
		{
			return false;
		}

	}

	return true;
}

bool UP3StartBlockPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::CombatHit
		|| OtherActionType == EPawnActionType::CombatReactionHit)
	{
		return false;
	}

	if (CVarP3CombatBlockInstancely.GetValueOnGameThread() == 1)
	{
		return true;
	}

	return false;
}

void UP3StartBlockPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (Character->IsGliding())
	{
		Character->BreakGlidingByAction(*this);
	}

	Finish(EP3PawnActionResult::Success);
}

void UP3StartBlockPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (Result == EP3PawnActionResult::Success)
	{
		AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;

		if (Character)
		{
			if (P3Core::IsP3NetModeServerInstance(*Character))
			{
				FP3CommandRequestParams Params;
				Params.SetBlocking_bNewBlocking = true;
				Character->GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), Params);
			}
		}

		ChangeCharacterStance(EP3CharacterStance::Combat);
	}
}

bool UP3StopBlockPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::CombatHit
		|| OtherActionType == EPawnActionType::CombatReactionHit		
		|| OtherActionType == EPawnActionType::CombatCombo)
	{
		return false;
	}

	return true;
}

void UP3StopBlockPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	Finish(EP3PawnActionResult::Success);
}

void UP3StopBlockPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (Result == EP3PawnActionResult::Success)
	{
		AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;

		if (Character)
		{
			if (P3Core::IsP3NetModeServerInstance(*Character))
			{
				FP3CommandRequestParams Params;
				Params.SetBlocking_bNewBlocking = false;
				Character->GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), Params);
			}
		}
	}
}

UP3ClimbEndPawnAction::UP3ClimbEndPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart);
}

bool UP3ClimbEndPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		return false;
	}

	if (!Character->GetP3CharacterMovementBP() || !Character->GetP3CharacterMovementBP()->IsClimbing())
	{
		return false;
	}

	return true;
}

bool UP3ClimbEndPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::ClimbStart,
		EPawnActionType::ClimbJump
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3ClimbEndPawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().ClimbEnd);

	Super::Autonomous_PreStartAction(Params);
}

void UP3ClimbEndPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!IsPlayedAtPreStart())
	{
		SetAnimMontage(Character->GetAnimMontages().ClimbEnd);
	}

	Super::Multicast_StartAction(Params);
}

void UP3ClimbEndPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (Result == EP3PawnActionResult::Success)
	{
		AP3Character* Character = GetP3Character();
		if (Character)
		{
			UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
			if (MovementComp)
			{
				MovementComp->SetMovementMode(MOVE_Walking);
			}
		}
	}
}

void UP3ClimbEndPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::ClimbEndLanded)
	{
		AP3Character* Character = GetP3Character();
		if (Character)
		{
			UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
			if (MovementComp)
			{
				MovementComp->SetMovementMode(MOVE_Walking);
			}
		}
	}
}

bool UP3ChangeHoldablePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!ensure(Params.ChangeHoldable_RightHoldType != EP3HoldType::Count))
	{
		return false;
	}

	if (!ensure(Params.ChangeHoldable_InvenToRightHolderItemId != INVALID_ITEMID))
	{
		return false;
	}

	return true;
}

bool UP3ChangeHoldablePawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::UseConsumable,
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3ChangeHoldablePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
		if (!ensure(InventoryComp))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		AActor* InvenToRightHolderItemActor = nullptr;
		if (Params.RequestParams.ChangeHoldable_InvenToRightHolderItemId != INVALID_ITEMID)
		{
			InvenToRightHolderItemActor = FP3ItemUtil::Server_SpawnWeaponActorFromInventory(*InventoryComp, Params.RequestParams.ChangeHoldable_InvenToRightHolderItemId);
			if (!ensure(InvenToRightHolderItemActor))
			{
				Finish(EP3PawnActionResult::Failed);
				return;
			}
		}

		AActor* InvenToLeftHolderItemActor = nullptr;
		if (Params.RequestParams.ChangeHoldable_InvenToLeftHolderItemId != INVALID_ITEMID)
		{
			InvenToLeftHolderItemActor = FP3ItemUtil::Server_SpawnWeaponActorFromInventory(*InventoryComp, Params.RequestParams.ChangeHoldable_InvenToLeftHolderItemId);
			if (!ensure(InvenToLeftHolderItemActor))
			{
				Finish(EP3PawnActionResult::Failed);
				return;
			}
		}

		FP3CommandRequestParams CommandParams;
		CommandParams.ChangeHoldable_RightHoldType = Params.RequestParams.ChangeHoldable_RightHoldType;
		CommandParams.ChangeHoldable_LeftHoldType = Params.RequestParams.ChangeHoldable_LeftHoldType;
		CommandParams.ChangeHoldable_InvenToRightHolderItemId = Params.RequestParams.ChangeHoldable_InvenToRightHolderItemId;
		CommandParams.ChangeHoldable_InvenToRightHolderItemActor = InvenToRightHolderItemActor;
		CommandParams.ChangeHoldable_InvenToLeftHolderItemId = Params.RequestParams.ChangeHoldable_InvenToLeftHolderItemId;
		CommandParams.ChangeHoldable_InvenToLeftHolderItemActor = InvenToLeftHolderItemActor;
		CommandParams.ChangeHoldable_HolderToRightInvenItem = Params.RequestParams.ChangeHoldable_HolderToRightInvenItem;
		CommandParams.ChangeHoldable_HolderToLeftInvenItem = Params.RequestParams.ChangeHoldable_HolderToLeftInvenItem;
		CommandParams.ChangeHoldable_bRemovePrevItemAfterChange = Params.RequestParams.ChangeHoldable_bRemovePrevWeaponAfterChange;
		Character->GetCommandComponent()->RequestCommand(UP3ChangeHoldableCommand::StaticClass(), CommandParams);
	}

	Finish(EP3PawnActionResult::Success);
}

UP3ClimbStartPawnAction::UP3ClimbStartPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart);
}

bool UP3ClimbStartPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		return false;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

	if (StaminaComp && StaminaComp->IsExhausted())
	{
		return false;
	}

	return true;
}

void UP3ClimbStartPawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().ClimbStart);

	Super::Autonomous_PreStartAction(Params);
}

void UP3ClimbStartPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!IsPlayedAtPreStart())
	{
		SetAnimMontage(Character->GetAnimMontages().ClimbStart);
	}

	Super::Multicast_StartAction(Params);
}

UP3ClimbDownPawnAction::UP3ClimbDownPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart);
}

void UP3ClimbDownPawnAction::OnRegister(class UP3PawnActionComponent* InOwnerComponent, EPawnActionType InActionType, EPawnActionCategory InActionCategory)
{
	Super::OnRegister(InOwnerComponent, InActionType, InActionCategory);

	AP3Character* Character = GetP3Character();
	if (ensure(Character))
	{
		SetAnimMontage(Character->GetAnimMontages().ClimbDown);
	}
}

UP3ClimbJumpPawnAction::UP3ClimbJumpPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart);
}

bool UP3ClimbJumpPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		return false;
	}

	if (!Character->GetP3CharacterMovementBP() || !Character->GetP3CharacterMovementBP()->IsClimbing())
	{
		return false;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

	if (StaminaComp && StaminaComp->IsExhausted())
	{
		return false;
	}

	return true;
}

void UP3ClimbJumpPawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().ClimbJump);

	Super::Autonomous_PreStartAction(Params);
}

void UP3ClimbJumpPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

	if (StaminaComp)
	{
		StaminaComp->ConsumeStamina(Character->GetClimbingJumpStamina());
	}

	if (!IsPlayedAtPreStart())
	{
		SetAnimMontage(Character->GetAnimMontages().ClimbJump);
	}

	Super::Multicast_StartAction(Params);
}

void UP3ClimbJumpPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();

	if (StaminaComp)
	{
		StaminaComp->SetConsumePerAction(0.0f);
	}
}

void UP3RagdollizePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (Character)
	{
		Character->RagdollizeByAction(*this, true);
	}

	Finish(EP3PawnActionResult::Success);
}

void UP3UnRagdollizePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (Character)
	{
		Character->RagdollizeByAction(*this, false);
	}

	Finish(EP3PawnActionResult::Success);
}


void UP3ThrowWeaponPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	ThrowDirection = Params.RequestParams.ThrowWeapon_Direction;

	SetAnimMontage(Character->GetAnimMontages().ThrowWeapon);

	Super::Multicast_StartAction(Params);
}

void UP3ThrowWeaponPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::ThrowWeapon)
	{
		Throw();
	}
}

void UP3ThrowWeaponPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);
	
	ensure(Result != EP3PawnActionResult::Success || bThrown);

	Throw();

	bThrown = false;
}

void UP3ThrowWeaponPawnAction::Throw()
{
	if (bThrown)
	{
		return;
	}

	bThrown = true;

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	UP3WorldNetBase* WorldNet = nullptr;
	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			return;
		}
	}

	UP3HolderComponent* HolderComp = Character->GetRightHandHolderComponent();
	if (!ensure(HolderComp))
	{
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		return;
	}

	// Prepare item
	const FP3Item Item = InvenComp->GetItemBySlot(EP3CharacterItemSlot::RightHand);
	if (!ensure(Item.IsValid()))
	{
		return;
	}

	// Remove from holder
	AActor* Actor = Character->RemoveHoldingActorByAction(*this, HolderComp);
	if (!ensure(Actor))
	{
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		// Remove from inventory
		InvenComp->Server_RemoveItem(Item.Id);
	}

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(Actor->GetRootComponent());
	if (PrimComp)
	{
		// We need to turn off simulation to use Projectile Movement Component
		PrimComp->SetSimulatePhysics(false);
	}

	AP3Weapon* Weapon = Cast<AP3Weapon>(Actor);
	Character->SetThrownWeaponByAction(*this, Item, Weapon, HolderComp);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		if (ensure(Weapon))
		{
			Weapon->Server_Throw(ThrowDirection, Character);
		}
	}
}

UP3RecallThrownWeaponPawnAction::UP3RecallThrownWeaponPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

void UP3RecallThrownWeaponPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);
	
	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	WeaponItem = Params.RequestParams.RecallThrownWeapon_WeaponItem;
	Weapon = Cast<AP3Weapon>(Params.RequestParams.RecallThrownWeapon_WeaponActor.Actor);
	CharacterItemSlot = FP3ItemUtil::GetCharacterItemSlotFromHoldType(Params.RequestParams.RecallThrownWeapon_HoldType);
	HolderComponent = Character->GetHolderComponentByHoldType(Params.RequestParams.RecallThrownWeapon_HoldType);

	if (!ensure(Weapon) || !ensure(CharacterItemSlot != EP3CharacterItemSlot::Invalid) || !ensure(HolderComponent))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (HolderComponent->GetHoldingActor())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	Character->SetRecallingWeaponByAction(*this, Weapon);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		Weapon->OnRecallFinished.AddUniqueDynamic(this, &UP3RecallThrownWeaponPawnAction::OnWeaponRecallFinished);
		Weapon->Server_Recall(HolderComponent);
	}

	SetAnimMontage(Character->GetAnimMontages().RecallThrownWeapon);

	PlayAnimMontage();
}

void UP3RecallThrownWeaponPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress && !bRecallFinished)
	{
		WaitingAgeSeconds += DeltaSeconds;

		if (WaitingAgeSeconds > 3.0f)
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		if (HolderComponent && HolderComponent->GetHoldingActor())
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}
}

void UP3RecallThrownWeaponPawnAction::Multicast_Progress(int32 StepIndex)
{
	Super::Multicast_Progress(StepIndex);

	if (StepIndex == PROGRESS_STEP_CATCH)
	{
		Catch();
	}
}

void UP3RecallThrownWeaponPawnAction::Multicast_Finish(EP3PawnActionResult Result)
{
	Super::Multicast_Finish(Result);

	AP3Character* Character = GetP3Character();

	if (Result == EP3PawnActionResult::Success)
	{
		Catch();
	}
	else if (Result == EP3PawnActionResult::Failed)
	{
		if (Weapon)
		{
			Weapon->StopRecall();
		}
	}

	if (Weapon)
	{
		Weapon->OnRecallFinished.RemoveAll(this);
	}

	WaitingAgeSeconds = 0;
	bRecallFinished = false;
	Weapon = nullptr;
	HolderComponent = nullptr;
}

void UP3RecallThrownWeaponPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);
}

void UP3RecallThrownWeaponPawnAction::Catch()
{
	if (bRecallFinished)
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3WorldNetBase* WorldNet = nullptr;
	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	Character->GetMesh()->GetAnimInstance()->Montage_JumpToSection(FName(TEXT("End")));
	Character->SetRecallingWeaponByAction(*this, nullptr);

	if (ensure(HolderComponent))
	{
		// Hold item
		HolderComponent->SetHoldingActor(Weapon, true);

		if (P3Core::IsP3NetModeServerInstance(*Character))
		{
			// Add to inventory
			InvenComp->Server_AddItem(WeaponItem, CharacterItemSlot);
		}
	}

	bRecallFinished = true;

	if (IsAuthority(GetOwnerComponent()->GetOwner()))
	{
		GetOwnerComponent()->OnActionProgress(this, PROGRESS_STEP_CATCH);
	}
}

void UP3RecallThrownWeaponPawnAction::OnWeaponRecallFinished(class AP3Weapon* InWeapon)
{
	if (GetActionLocalStatus() != EP3PawnActionStatus::InProgress)
	{
		ensure(0);
		return;
	}

	if (!HolderComponent || InWeapon != Weapon)
	{
		ensure(0);
		return;
	}

	Catch();
}

void UP3SpawnPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().Spawn);

	Super::Multicast_StartAction(Params);
}

void UP3SpawnPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (!bVisibleTurnedOn)
	{
		AP3Character* Character = GetP3Character();

		if (!ensure(Character))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}
}

void UP3SpawnPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetP3Character();

	if (Character && Character->GetMesh() && Character->GetMesh()->GetAnimInstance())
	{
		Character->GetMesh()->GetAnimInstance()->OnMontageStarted.RemoveAll(this);
	}

	if (Result == EP3PawnActionResult::Success && !bVisibleTurnedOn)
	{
		// To avoid 1 frame pop-up at spawning, spawn component hides actor, so we have to make it visible here
		if (Character && Character->GetMesh())
		{
			Character->GetMesh()->SetVisibility(true);
		}
	}

	bVisibleTurnedOn = false;
}

void UP3CombatProjectileSkillAttackPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SkillIndex = Params.RequestParams.CombatProjectileSkillAttack_SkillIndex;
	TargetLocation = Params.RequestParams.CombatProjectileSkillAttack_TargetLocation;
	TargetHalfHeight = Params.RequestParams.CombatProjectileSkillAttack_TargetHalfHeight;

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
	if (!ensure(CombatComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const FP3CmsCombatSkill* CmsCombatSkill = CombatComp->GetCmsCombatSkill(SkillIndex);
	if (!ensure(CmsCombatSkill))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		CombatComp->Server_OnSkillStarted(SkillIndex);
	}

	UAnimMontage* Montage = CmsCombatSkill->AnimMontage.LoadSynchronous();

	SetAnimMontage(Montage);

	Super::Multicast_StartAction(Params);
}

void UP3CombatProjectileSkillAttackPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	if (NotifyType != EActionAnimNotifyType::Fire)
	{
		return;
	}

	if (GetOwnerActor() && !P3Core::IsP3NetModeServerInstance(*GetOwnerActor()))
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
	if (!CombatComp)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const FP3CmsCombatSkill* CmsCombatSkill = CombatComp->GetCmsCombatSkill(SkillIndex);
	if (!ensure(CmsCombatSkill))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UClass* ProjectileClass = CmsCombatSkill->ProjectileClass.LoadSynchronous();
	const AP3Projectile* ProjectileDefaultObject = ProjectileClass ? ProjectileClass->GetDefaultObject<AP3Projectile>() : nullptr;

	if (!ensure(ProjectileDefaultObject))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const FTransform LaunchSocketTransform = ensure(Character->GetMesh()) ? Character->GetMesh()->GetSocketTransform(CmsCombatSkill->ProjectileLaunchSocketName) : Character->GetActorTransform();
	const FVector LaunchLocation = LaunchSocketTransform.GetLocation();
	const FVector TargetDirection2D = (TargetLocation - LaunchLocation).GetSafeNormal2D();
	const float TargetDistance2D = (TargetLocation - LaunchLocation).Size2D();
	const float ProjectileGravity = -ProjectileDefaultObject->GetProjectileMovement()->ProjectileGravityScale * GetWorld()->GetGravityZ();
	const float ProjectileInitialSpeed = ProjectileDefaultObject->GetProjectileMovement()->InitialSpeed;

	if (ProjectileInitialSpeed <= SMALL_NUMBER)
	{
		ensure(0);
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	FVector WorldVelocity = FVector(1, 0, 0) * ProjectileInitialSpeed;

	const float TimeLeft = TargetDistance2D / ProjectileInitialSpeed;

	if (TimeLeft > SMALL_NUMBER)
	{
		const float HeightFromLaunchSocketToTarget = TargetLocation.Z - LaunchLocation.Z;
		const float NewProjectileVelocityZ = (HeightFromLaunchSocketToTarget / TimeLeft) + (0.5f * ProjectileGravity * TimeLeft);
		
		WorldVelocity = (TargetDirection2D * ProjectileInitialSpeed) + FVector(0, 0, NewProjectileVelocityZ);
	}
	
	if (CVarP3ActionDebug.GetValueOnGameThread() >= 1)
	{
		const FVector TopOfCapsule = Character->GetActorLocation() + FVector(0.f, 0.f, Character->GetSimpleCollisionHalfHeight());
		float HeightOffset = 0.f;
		// AimTarget Vector Debug
		{
			const FColor DebugColor = FColor::Red;
			HeightOffset += 15.f;
			const FVector DebugLocation = TopOfCapsule + FVector(0.f, 0.f, HeightOffset);
			DrawDebugDirectionalArrow(GetWorld(), TargetLocation - FVector(0.0f, 0.0f, TargetHalfHeight), LaunchLocation,
				100.f, DebugColor, false, 2.f, (uint8)'\000', 10.f);

			DrawDebugDirectionalArrow(GetWorld(), LaunchLocation, LaunchLocation + WorldVelocity.GetSafeNormal() * 200,
				100.f, DebugColor, false, 2.0f, 0, 10.f);
		}
	}

	FActorSpawnParameters ActorSpawnParams;
	ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AP3Projectile* Projectile = GetWorld()->SpawnActor<AP3Projectile>(ProjectileClass, LaunchLocation, WorldVelocity.Rotation(), ActorSpawnParams);

	if (ensure(Projectile))
	{
		ensure(Projectile->GetIsReplicated());
		Projectile->Server_SetSourceCharacter(Character);

		Projectile->GetProjectileMovement()->SetVelocityInLocalSpace(Projectile->GetActorRotation().UnrotateVector(WorldVelocity));
	}
}

void UP3CombatProjectileSkillAttackPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	SkillIndex = -1;
	TargetHalfHeight = 0.0f;
	TargetLocation = FVector::ZeroVector;
}

void UP3PullHarpoonPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (Character)
	{
		SetAnimMontage(Character->GetAnimationByType(EP3ActionAnimationType::NormalBlock));
	}

	Super::Multicast_StartAction(Params);
	
	if (Character && P3Core::IsP3NetModeServerInstance(*Character))
	{
		bool bSuccess = false;

		AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
		if (Weapon)
		{
			AP3Projectile* Projectile = Weapon->GetLastFiredProjectile();
			if (Projectile)
			{
				if (Projectile->GetAttachParentActor() && Projectile->GetAttachParentActor() != Character)
				{
					// Projectile is attached to sometime, which means hit a physical P3 object (refer AP3Projectile::OnHit)
					// In this case, we pull that object

					AActor* PullingActor = Projectile->GetAttachParentActor();

					ensure(P3Core::GetP3World(*this)->GetActorIdFromActor(PullingActor) != INVALID_ACTORID);

					UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(Projectile->GetRootComponent()->GetAttachParent());
					if (PrimComp && PrimComp->IsSimulatingPhysics())
					{
						const FVector Impulse = (Weapon->GetActorLocation() - PullingActor->GetActorLocation()).GetSafeNormal() * CVarP3HarpoonPullImpulse.GetValueOnGameThread();
						PrimComp->AddImpulseAtLocation(Impulse, Projectile->GetActorLocation());

						bSuccess = true;
					}
					else
					{
						ActionJsonLog(Error, "Pull harpoon failed. Target is not simulating",
							TEXT("TargetActor"), PullingActor->GetName());
					}
				}
				else if (Projectile->GetProjectileMovement()->HasStoppedSimulation())
				{
					// Projectile is not attached, but not simulating either, which means hit a static object (refer AP3Projectile::OnHit)
					// In this case, we pull character towards projectile

					GetOwnerComponent()->OnActionProgress(this, PROGRESS_STEP_PULL_CHARACTER);
				}

				Projectile->SetLifeSpan(1.0f);
			}
		}

		if (!bSuccess)
		{
			// Comment-out: lets just watch anim
			//Finish(EP3PawnActionResult::Failed);
		}
	}
}

void UP3PullHarpoonPawnAction::Multicast_Progress(int32 StepIndex)
{
	Super::Multicast_Progress(StepIndex);

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		return;
	}

	AP3Weapon* Weapon = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
	if (Weapon)
	{
		AP3Projectile* Projectile = Weapon->GetLastFiredProjectile();
		if (Projectile)
		{
			const FVector Impulse = (Projectile->GetActorLocation() - Character->GetActorLocation()).GetSafeNormal() * CVarP3HarpoonCharacterPullImpulse.GetValueOnGameThread();

			Character->GetP3CharacterMovementBP()->AddImpulse(Impulse, false);
		}
	}
}

UP3ComboAttackPawnAction::UP3ComboAttackPawnAction()
{
	if (CVarP3CombatAttackPreStart.GetValueOnGameThread() == 1)
	{
		SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart);
	}
}

void UP3ComboAttackPawnAction::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	UP3ComboTableComponent* ComboComp = Character->GetComboComponent();
	if (!ensure(ComboComp))
	{
		return;
	}

	const FP3ComboRow* FindComboRow = ComboComp->GetComboRow(Params.Combo_Name);
	if (!ensure(FindComboRow))
	{
		return;
	}

	if (IsPlaying() || IsPlayedAtPreStart())
	{
		StopAnimMontage();
	}

	UAnimMontage* Montage = GetAttackMontage(FindComboRow->AnimationName, Params.Combo_bIsCounterAttack);
	if (Montage)
	{		
		SetAnimMontage(Montage);
		SetPlayRate(FindComboRow->AnimationPlayRate);
	}

	UAnimMontage* WeaponMontage = GetWeaponMontage(FindComboRow->WeaponAnimationName);
	if (WeaponMontage)
	{
		AActor* WeaponActor = Character->GetRightHandWeaponActor();
		if (WeaponActor)
		{
			USkeletalMeshComponent* SkeletalMeshComp = WeaponActor->FindComponentByClass<USkeletalMeshComponent>();
			if (SkeletalMeshComp && SkeletalMeshComp->GetAnimInstance())
			{
				SkeletalMeshComp->GetAnimInstance()->Montage_Play(WeaponMontage, FindComboRow->AnimationPlayRate);
			}
		}
	}

	ComboName = Params.Combo_Name;	
	ComboRow = *FindComboRow;
	
	Super::Autonomous_PreStartAction(Params);

	if (IsPlayedAtPreStart())
	{
		AnimNotifyGenerator.Start(GetAnimMontage(), GetWorld()->GetTimeSeconds(), FindComboRow->AnimationPlayRate);
	}
}

bool UP3ComboAttackPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{	
		return false;
	}

	UP3ComboTableComponent* ComboComp = Character->GetComboComponent();
	if (!ensure(ComboComp))
	{		
		return false;
	}

	const FP3ComboRow* FindComboRow = ComboComp->GetComboRow(Params.Combo_Name);
	if (!ensure(FindComboRow))
	{	
		return false;
	}

	if (FindComboRow->bIsIncreaseUseCountByPlayer)
	{		
		AP3Weapon* WeaponActor = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
		if (WeaponActor && WeaponActor->IsRunOutOfDurability())
		{
			return false;
		}
	}
	
	return true;
}

bool UP3ComboAttackPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::CombatRoll,
		EPawnActionType::CombatCombo,
		EPawnActionType::UseConsumable,
		EPawnActionType::CombatRangedAttack,		
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3ComboAttackPawnAction::Server_FillAuthorityStopParams(FP3PawnActionStopAuthorityParams& OutParams) const
{
	Super::Server_FillAuthorityStopParams(OutParams);
	
}

void UP3ComboAttackPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3ComboTableComponent* ComboComp = Character->GetComboComponent();
	if (!ensure(ComboComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	const FP3ComboRow* FindComboRow = ComboComp->GetComboRow(Params.RequestParams.Combo_Name);
	if (!ensure(FindComboRow))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	if (!IsPlayedAtPreStart())
	{
		UAnimMontage* Montage = GetAttackMontage(FindComboRow->AnimationName, Params.RequestParams.Combo_bIsCounterAttack);
		if (Montage)
		{			
			SetAnimMontage(Montage);
			SetPlayRate(FindComboRow->AnimationPlayRate);
		}

		UAnimMontage* WeaponMontage = GetWeaponMontage(FindComboRow->WeaponAnimationName);
		if (WeaponMontage)
		{
			AActor* WeaponActor = Character->GetRightHandWeaponActor();
			if (WeaponActor)
			{
				USkeletalMeshComponent* SkeletalMeshComp = WeaponActor->FindComponentByClass<USkeletalMeshComponent>();
				if (SkeletalMeshComp && SkeletalMeshComp->GetAnimInstance())
				{
					SkeletalMeshComp->GetAnimInstance()->Montage_Play(WeaponMontage, FindComboRow->AnimationPlayRate);
				}
			}
		}
	}
	
	if (!Params.RequestParams.Combo_ChracterRotator.IsZero())
	{
		Character->SetActorRotation(Params.RequestParams.Combo_ChracterRotator);
	}
	
	if (FindComboRow->EntryComboStatus.bChangeStanceToCombat)
	{
		ChangeCharacterStance(EP3CharacterStance::Combat);
	}

	if (Params.RequestParams.Combo_bIsCounterAttack)
	{
		AP3PlayerController* Controller = Cast<AP3PlayerController>(Character->GetController());
		if (Controller && Controller->IsLocalController())
		{
			Controller->CreateCounterAttackCombatText(Character);
		}		

		if (P3Core::IsP3NetModeServerInstance(*Character))
		{
			if (Character->GetCharacterStoreBP().bIsBlocking)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetBlocking_bNewBlocking = false;
				Character->GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), CommandParams);
			}

			if (Character->GetCharacterStoreBP().bIsCrouchBlocking)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetCrouchBlocking_bNewBlocking = false;
				Character->GetCommandComponent()->RequestCommand(UP3SetCrouchBlockingCommand::StaticClass(), CommandParams);
			}

			if (Character->GetCharacterStoreBP().bIsMeleeAiming)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetMeleeAiming_bNewAiming = false;
				Character->GetCommandComponent()->RequestCommand(UP3SetMeleeAimingCommand::StaticClass(), CommandParams);
			}

		}		
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (ensure(StaminaComp))
	{
		StaminaComp->ConsumeStamina(FindComboRow->ConsumeStamina);
		StaminaComp->SetConsumer(EStaminaConsumerLayer::Combo, FindComboRow->ConsumeStaminaPerSecond);
	}

	UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
	if (MovementComp)
	{		
		if (bRestoreMovement)
		{
			MovementComp->RemoveActionForce(*this);
			MovementComp->MaxWalkSpeed = RestoreMaxWalkSpeed;
			MovementComp->bUseSeparateBrakingFriction = bRestoreUseSeparateBrakingFriction;
			bRestoreMovement = false;
		}

		if (FindComboRow->DeltaMoveCurve)
		{
			bRestoreMovement = true;
			RestoreMaxWalkSpeed = MovementComp->MaxWalkSpeed;
			bRestoreUseSeparateBrakingFriction = MovementComp->bUseSeparateBrakingFriction;

			MovementComp->bUseSeparateBrakingFriction = true;

			const float Strength = 10.f;
			MovementComp->AddActionForce(FVector::ZeroVector, Strength, *this);
		}
	}

	ComboName = Params.RequestParams.Combo_Name;	
	DeprojectWorldLocation = Params.RequestParams.Combo_DeprojectWorldLocation;
	ComboRow = *FindComboRow;

	InProgressTimeSeconds = 0.f;
	LastUpdateInProgressTimeSeconds = 0.f;	
	
	bLastUpdateFalling = false;
	bLastUpdateMovingOnGround = false;

	Super::Multicast_StartAction(Params);

	if (!IsPlayedAtPreStart())
	{
		const float Now = GetWorld()->GetTimeSeconds();
		const float PreDecisionAmount = CVarP3CombatAttackPreDecisionAmount.GetValueOnGameThread() / 1000.0f;
		AnimNotifyGenerator.Start(GetAnimMontage(), Now - PreDecisionAmount, FindComboRow->AnimationPlayRate);
	}
}

void UP3ComboAttackPawnAction::Multicast_StopAction(const FP3PawnActionStopMulticastParams& Params)
{
	ensure(GetActionLocalStatus() == EP3PawnActionStatus::InProgress || GetActionLocalStatus() == EP3PawnActionStatus::Finished);

	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		Finish(EP3PawnActionResult::Aborted);
	}
}

void UP3ComboAttackPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);	

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	// Process anim notifications	
	if (IsPlaying())
	{
		TArray<FAnimNotifyEventReference> AnimNotifyEventReferences = AnimNotifyGenerator.TickAndNotifies(DeltaSeconds);

		for (const FAnimNotifyEventReference& AnimNotifyEventReference : AnimNotifyEventReferences)
		{
			const FAnimNotifyEvent* AnimNotifyEvent = AnimNotifyEventReference.GetNotify();
			if (!AnimNotifyEvent || !AnimNotifyEvent->Notify)
			{
				continue;
			}

			UAnimNotify_Hit* HitNotify = Cast<UAnimNotify_Hit>(AnimNotifyEvent->Notify);
			if (HitNotify)
			{
				_BroadcastHitAnimNotify(*Character, *HitNotify, -1, nullptr, GetActionId(), GetAnimMontage());
			}
		}

		if (GetAnimMontage() && GetAnimMontage()->HasRootMotion())
		{
			UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
			if (MovementComp)
			{
				if (MovementComp->IsFalling())
				{
					Finish(EP3PawnActionResult::Success);
				}
				else if (MovementComp->AnimRootMotionVelocity.Z > 0.01f)
				{
					MovementComp->SetMovementMode(EMovementMode::MOVE_Flying);
				}
			}
		}
	}

	UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();
	if (MovementComp && ComboRow.DeltaMoveCurve)
	{
		FP3CharacterMovementForce* ActionForce = MovementComp->GetActionForce(*this);
		if (ActionForce)
		{								
			const bool bFallingOnGround = bLastUpdateFalling && MovementComp->IsMovingOnGround() && ComboRow.FallingOnGroundSectionName != NAME_None;
			const bool bFalling = bLastUpdateMovingOnGround && MovementComp->IsFalling() && ComboRow.FallingOnGroundSectionName == NAME_None;

			if (bFallingOnGround)
			{
				MovementComp->RemoveActionForce(*this);
				
				UAnimInstance* AnimInstance = GetAnimInstance();
				if (ensure(AnimInstance))
				{
					AnimInstance->Montage_JumpToSection(ComboRow.FallingOnGroundSectionName, AnimInstance->GetCurrentActiveMontage());
				}
			}
			else if (bFalling)
			{
				MovementComp->RemoveActionForce(*this);
				MovementComp->SetMovementMode(EMovementMode::MOVE_Falling);

				Finish(EP3PawnActionResult::Success);
			}
			else if (ComboRow.ActionForceDurationSeconds <= InProgressTimeSeconds)
			{
				MovementComp->RemoveActionForce(*this);
				
				if (ComboRow.StoppingOnGroundSectonName != NAME_None && !Character->GetP3CharacterMovementBP()->IsFalling())
				{
					UAnimInstance* AnimInstance = GetAnimInstance();
					if (ensure(AnimInstance))
					{
						AnimInstance->Montage_JumpToSection(ComboRow.StoppingOnGroundSectonName, AnimInstance->GetCurrentActiveMontage());
					}
				}
				else
				{
					MovementComp->SetMovementMode(EMovementMode::MOVE_Falling);
					Finish(EP3PawnActionResult::Success);
				}
			}
			else
			{								
				const FVector UpdateDeltaMoveCurveValue = ComboRow.DeltaMoveCurve->GetVectorValue(InProgressTimeSeconds);
				const FVector LastUpdateDeltaMoveCurveValue = ComboRow.DeltaMoveCurve->GetVectorValue(LastUpdateInProgressTimeSeconds);
								
				ActionForce->ActionTargetVelocity = (UpdateDeltaMoveCurveValue - LastUpdateDeltaMoveCurveValue) / DeltaSeconds;

				MovementComp->MaxWalkSpeed = ActionForce->ActionTargetVelocity.X;

				if (MovementComp->IsFalling() && MovementComp->Velocity.Z < 0.f)
				{
					if (FMath::Abs<float>(MovementComp->Velocity.Z) > FMath::Abs<float>(ActionForce->ActionTargetVelocity.Z))
					{
						ActionForce->ActionTargetVelocity.Z = MovementComp->Velocity.Z;
					}
				}

				ActionForce->ActionTargetVelocity = Character->GetActorForwardVector() * ActionForce->ActionTargetVelocity.X + FVector(0.f, 0.f, ActionForce->ActionTargetVelocity.Z);				
			}								

			bLastUpdateFalling = MovementComp->IsFalling();
			bLastUpdateMovingOnGround = MovementComp->IsMovingOnGround();
		}		
	}

	if(Character->IsMounted())
	{
		Finish(EP3PawnActionResult::Aborted);
	}
	
	LastUpdateInProgressTimeSeconds = InProgressTimeSeconds;
	InProgressTimeSeconds += DeltaSeconds;
}

bool UP3ComboAttackPawnAction::IsIgnoreMoveInput() const
{
	return (CVarP3CombatAttackIgnoreMoveInput.GetValueOnGameThread() == 1);
}

void UP3ComboAttackPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);	

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	if (ComboRow.bIsIncreaseUseCountByPlayer)
	{
		AP3Weapon* WeaponActor = Cast<AP3Weapon>(Character->GetRightHandWeaponActor());
		if (WeaponActor)
		{
			WeaponActor->IncreaseUseCountByPlayer();

			const bool bIsServerRecoveryAfterTempWeapon = WeaponActor->IsRunOutOfDurability() && P3Core::IsP3NetModeServerInstance(*this);
			if (bIsServerRecoveryAfterTempWeapon)
			{
				Server_RecoveryAfterTempWeapon();
			}
		}		
	}	
	
	if (ComboRow.bIsWeaponAnimationStopWithActionFinish)
	{
		AActor* WeaponActor = Character->GetRightHandWeaponActor();
		if (WeaponActor)
		{
			USkeletalMeshComponent* SkeletalMeshComp = WeaponActor->FindComponentByClass<USkeletalMeshComponent>();
			if (SkeletalMeshComp && SkeletalMeshComp->GetAnimInstance() && SkeletalMeshComp->GetAnimInstance()->GetCurrentActiveMontage())
			{
				SkeletalMeshComp->GetAnimInstance()->Montage_Stop(0.f, SkeletalMeshComp->GetAnimInstance()->GetCurrentActiveMontage());
			}
		}
	}
		
	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (ensure(StaminaComp))
	{
		StaminaComp->SetConsumer(EStaminaConsumerLayer::Combo, 0.f);	
	}
	
	UP3CharacterMovementComponent* MovementComp = Character->GetP3CharacterMovementBP();

	if (MovementComp)
	{		
		if (bRestoreMovement && ComboRow.DeltaMoveCurve)
		{
			MovementComp->RemoveActionForce(*this);
			MovementComp->MaxWalkSpeed = RestoreMaxWalkSpeed;
			MovementComp->bUseSeparateBrakingFriction = bRestoreUseSeparateBrakingFriction;
		}

		if (GetAnimMontage() && GetAnimMontage()->HasRootMotion())
		{
			MovementComp->SetMovementMode(EMovementMode::MOVE_Walking);
		}		
	}

	ComboName = NAME_None;	
	InProgressTimeSeconds = 0.f;
	bRestoreMovement = false;
}

UAnimMontage* UP3ComboAttackPawnAction::GetAttackMontage(const FName& AnimationName, bool bIsCounterAttack) const
{
	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;
	if (!ensure(Character))
	{
		return nullptr;
	}

	UAnimMontage* Montage = nullptr;
		
	if (bIsCounterAttack)
	{
		Montage = Character->GetAnimationByType(EP3ActionAnimationType::CounterAttack);
	}
	else
	{
		const UP3ComboTableComponent* ComboComp = Character->GetComboComponent();
		if (ComboComp)
		{
			Montage = ComboComp->GetComboAnimationByTableName(AnimationName);
		}
	}
					
	ensure(Montage);

	return Montage;
}

UAnimMontage* UP3ComboAttackPawnAction::GetWeaponMontage(const FName& AnimationName) const
{
	if (AnimationName == NAME_None)
	{
		return nullptr;
	}

	AP3Character* Character = GetOwnerComponent() ? Cast<AP3Character>(GetOwnerComponent()->GetOwner()) : nullptr;
	if (!ensure(Character))
	{
		return nullptr;
	}

	UAnimMontage* Montage = nullptr;

	const UP3ComboTableComponent* ComboComp = Character->GetComboComponent();
	if (ComboComp)
	{
		Montage = ComboComp->GetComboWeaponAnimationByTableName(AnimationName);
	}

	ensure(Montage);

	return Montage;
}

void UP3ComboAttackPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::Throw)
	{
		OnThrowAnimNotify();
	}
	else if (NotifyType == EActionAnimNotifyType::ThrowWeapon)
	{
		OnThrowWeaponAnimNotify();
	}
}

void UP3ComboAttackPawnAction::OnThrowAnimNotify()
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	const AActor* Weapon = Character->GetRightHandWeaponActor();
	if (!ensure(Weapon))
	{
		return;
	}

	TArray<AActor*> AttachActors;
	Weapon->GetAttachedActors(AttachActors);

	const bool bIsServer = P3Core::IsP3NetModeServerInstance(*this);

	for (const auto& Iter : AttachActors)
	{
		if (!Iter)
		{
			continue;
		}

		if (!Iter->ActorHasTag(NAME_ThrowForcedActor))
		{
			continue;
		}

		Iter->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		Iter->Tags.Remove(NAME_ThrowForcedActor);

		AP3Character* TargetCharacter = Cast<AP3Character>(Iter);
		if (TargetCharacter)
		{
			if (bIsServer)
			{
				UP3HealthPointComponent* HealthPointComp = TargetCharacter->GetP3HealthComponentBP();
				if (ensure(HealthPointComp))
				{
					P3Combat::ChangeActorHealth(Character, *HealthPointComp, -HealthPointComp->GetHealthPoint(), EP3HealthChangeReason::Thrown);
				}
			}

			TargetCharacter->RagdollizeByAction(*this, true);
		}
		else
		{
			UPrimitiveComponent* PrimitiveComp = Iter->FindComponentByClass<UPrimitiveComponent>();
			if (PrimitiveComp)
			{
				FVector Impulse = Character->GetActorForwardVector() * 2000.f;

				PrimitiveComp->SetSimulatePhysics(true);
				PrimitiveComp->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);

				PrimitiveComp->IgnoreActorWhenMoving(Character, true);

				PrimitiveComp->SetPhysicsLinearVelocity(Impulse);
				PrimitiveComp->SetPhysicsAngularVelocityInDegrees(FVector::ZeroVector);
				PrimitiveComp->SetWorldRotation(Impulse.Rotation());
			}
		}
	}
}

void UP3ComboAttackPawnAction::OnThrowWeaponAnimNotify()
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}
	
	AActor* Actor = Character->GetRightHandWeaponActor();	
	if (!ensure(Actor))
	{
		return;
	}

	FVector LauncherLocation = Actor->GetActorLocation();
	FVector ThrowDirection = Actor->GetActorForwardVector();

	if (!DeprojectWorldLocation.IsZero())
	{
		ThrowDirection = (DeprojectWorldLocation - LauncherLocation).GetSafeNormal();
	}	
	
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_RecoveryAfterTempWeapon();
	}
	
	UP3JavelinComponent* JavlinComp = Actor->FindComponentByClass<UP3JavelinComponent>();
	if (JavlinComp)
	{
		JavlinComp->Throw(ThrowDirection, Character);
	}
	else
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			AP3Weapon* Weapon = Cast<AP3Weapon>(Actor);
			if (ensure(Weapon))
			{
				Weapon->Server_ThrowPhysically(ThrowDirection, Character);
			}
		}
	}	
}

UP3CombatChargingPawnAction::UP3CombatChargingPawnAction()
{

}

bool UP3CombatChargingPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		return false;
	}

	if (!Character->GetP3CombatComponentBP())
	{
		return false;
	}

	if (!Character->GetP3CombatComponentBP()->GetChargings().IsValidIndex(Params.CombatCharging_Index))
	{
		ActionJsonLog(Warning, "Invalid charging index for charging action",
			TEXT("ChargingIndex"), Params.CombatCharging_Index);
		return false;
	}

	return true;
}

void UP3CombatChargingPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();
	if (!Character || !Character->GetP3CombatComponentBP())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	if (!Character->GetP3CombatComponentBP()->GetChargings().IsValidIndex(Params.RequestParams.CombatCharging_Index))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const FP3CombatCharging& CombatCharging = Character->GetP3CombatComponentBP()->GetChargings()[Params.RequestParams.CombatCharging_Index];

	SetAnimMontage(Character->GetP3CombatComponentBP()->GetChargings()[Params.RequestParams.CombatCharging_Index].AnimMontage);

	Super::Multicast_StartAction(Params);

	ChargingIndex = Params.RequestParams.CombatCharging_Index;
	ChargingTargetActor = Params.RequestParams.CombatCharging_TargetActor.Actor;
	MaxDistance = CombatCharging.MaxDistance;
	MoveSpeed = CombatCharging.MoveSpeed;
	MoveSpeedMultiplier = (Character->GetCharacterMovement()->MaxWalkSpeed > 0) ? CombatCharging.MoveSpeed / Character->GetCharacterMovement()->MaxWalkSpeed : 0.0f;
	ChargingBrakeTime = CombatCharging.ChargingBrakeTime;
	ChargingChaseMinDistance = CombatCharging.ChargingChaseMinDistance;
	ChaseTurningRatio = CombatCharging.ChaseTurningRatio;
	NeedSpeedForStuck = CombatCharging.NeedSpeedForStuck;
	NeedSpeedForHitCharacter = CombatCharging.NeedSpeedForHitCharacter;
	ChargingDamagePermil = CombatCharging.ChargingDamagePermil;

	const bool bServerPawn = (Character->Role == ROLE_Authority && Character->GetRemoteRole() == ROLE_SimulatedProxy);
	const bool bAutonomousProxy = (Character->Role == ROLE_AutonomousProxy);

	bLocalControl = bServerPawn || bAutonomousProxy;
	   
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_StartLocation = Character->GetActorLocation();
		Server_StartTimeSeconds = GetWorld()->GetTimeSeconds();
		Server_TargetStartLocation = ChargingTargetActor ? ChargingTargetActor->GetActorLocation() : FVector::ZeroVector;
		Server_TargetPassedTimeSeconds = 0.0f;
		Server_LastLocation = Character->GetActorLocation();

		if (Character->GetMesh())
		{
			Character->GetMesh()->OnComponentBeginOverlap.AddUniqueDynamic(this, &UP3CombatChargingPawnAction::Server_OnMeshBeginOverlap);
		}
		//Character->OnActorBeginOverlap.AddUniqueDynamic(this, &UP3CombatChargingPawnAction::Server_OnActorBeginOverlap);
		Character->OnActorHit.AddUniqueDynamic(this, &UP3CombatChargingPawnAction::Server_OnActorHit);
	}
}

void UP3CombatChargingPawnAction::Multicast_Progress(int32 StepIndex)
{
	Super::Multicast_Progress(StepIndex);

	if (StepIndex == STEP_PASSED_TARGET)
	{
		bPassedTarget = true;
	}
	else if (StepIndex == STEP_END)
	{
		bChargingEnded = true;
		LocalControl_EndingSlideProgress = 0.0f;
		
		AP3Character * Character = GetP3Character();

		if (Character)
		{
			StopAnimMontage();
			PlayAnimMontage();

			const static FName SectionName = FName(TEXT("End"));

			UAnimInstance* AnimInstance = (Character->GetMesh()) ? Character->GetMesh()->GetAnimInstance() : nullptr;
			if (ensure(AnimInstance))
			{
				AnimInstance->Montage_JumpToSection(SectionName);
			}
		}
	}
}

void UP3CombatChargingPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	AP3Character* Character = GetP3Character();
	if (!Character || !Character->GetP3CombatComponentBP())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	CurrentHistoryIndex = SquaredSpeedHistory.GetNextIndex(CurrentHistoryIndex);
	SquaredSpeedHistory[CurrentHistoryIndex] = Character->GetVelocity().SizeSquared();

	if (bLocalControl)
	{
		LocalControl_Tick(Character, DeltaSeconds);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(Character, DeltaSeconds);
	}
}

void UP3CombatChargingPawnAction::LocalControl_Tick(AP3Character* Character, float DeltaSeconds)
{
	if (!ensure(bLocalControl))
	{
		return;
	}

	if (bChargingEnded && LocalControl_EndingSlideProgress >= 1.0f)
	{
		return;
	}

	float Accel = 1.0f;

	if (bChargingEnded)
	{
		// 1초간 천천히 감속 (미끄러지는 모습을 보여주기 위해)
		LocalControl_EndingSlideProgress += DeltaSeconds;
		LocalControl_EndingSlideProgress = FMath::Min(LocalControl_EndingSlideProgress, 1.0f);

		Accel = (1.0f - LocalControl_EndingSlideProgress);
	}

	// Move forward
	Character->AddMovementInput(Character->GetActorForwardVector() * Accel);

	if (!bPassedTarget)
	{
		const FVector MyLocation = Character->GetActorLocation();
		const FVector TargetLocation = ChargingTargetActor->GetActorLocation();
		const FVector TargetDirection = TargetLocation - MyLocation;

		const FVector MyCurrentToTargetCurrent2D = FVector(TargetDirection.X, TargetDirection.Y, 0);
		const float TargetDistance = MyCurrentToTargetCurrent2D.Size2D();

		if (TargetDistance > ChargingChaseMinDistance && Character->GetVelocity().SizeSquared() > FMath::Square(100))
		{
			// Rotate towards target
			const float LateralInputStrength = Character->GetActorRightVector() | MyCurrentToTargetCurrent2D.GetSafeNormal();
			const float LateralMovementInput = ChaseTurningRatio * LateralInputStrength;

			LocalControl_MoveRightInput = FMath::FInterpTo(LocalControl_MoveRightInput, LateralMovementInput, DeltaSeconds, 10.0f);

			Character->AddMovementInput(Character->GetActorRightVector() * LocalControl_MoveRightInput);

			if (CVarP3ChargingDebug.GetValueOnGameThread() > 0)
			{
				Character->AddDebugString(FString::Printf(TEXT("Chasing On (%.2f/%.2f)"), TargetDistance, ChargingChaseMinDistance));

				DrawDebugPoint(GetWorld(), MyLocation + FVector(0, 0, 500.0f), 2.0f, FColor::White);

				DrawDebugLine(GetWorld(), MyLocation + FVector(0, 0, 500.0f), MyLocation + FVector(0, 0, 500.0f) + (Character->GetActorRightVector() * LocalControl_MoveRightInput * 1000.0f), FColor::Green, false, -1.0f, 0, 50.0);

				DrawDebugLine(GetWorld(), MyLocation + FVector(0, 0, 600.0f), MyLocation + FVector(0, 0, 600.0f) + (Character->GetActorRightVector() * LateralMovementInput * 1000.0f), FColor::Red, false, -1.0f, 0, 50.0);
			}
		}

		if (CVarP3ChargingDebug.GetValueOnGameThread() > 0)
		{
			Character->AddDebugString(FString::Printf(TEXT("Charning TargetDistance: %.2f"), TargetDistance));
		}
	}
}

bool UP3CombatChargingPawnAction::Server_HasClearPathAhead(AP3Character* Character)
{
	if (!ensure(Character))
	{
		return true;
	}

	AAIController* AICon = Character->GetController<AAIController>();

	if (!ensure(AICon))
	{
		return true;
	}

	// 전방에 네비게이션이 있는지 확인
	if (CVarP3ChargingLookupNavigation.GetValueOnGameThread() != 0)
	{
		UNavigationSystemV1* NavSys = FNavigationSystem::GetCurrent<UNavigationSystemV1>(GetWorld());
		if (!ensure(NavSys))
		{
			return true;
		}

		const FNavAgentProperties& AgentProps = AICon->GetNavAgentPropertiesRef();

		const FVector CharacterLocation = Character->GetActorLocation();
		const FVector CharacterForward = Character->GetActorForwardVector();

		// 1미터 간격으로 1.0초 앞까지 확인 (정지를 위한 감속 시간이 1초)
		const float SweepDistance = FMath::Max(100.0f, MoveSpeed * 1.0f);
		const float STEP_DISTANCE = 100.0f;
		const int32 NUM_STEP = FMath::CeilToInt(SweepDistance / STEP_DISTANCE);

		for (int32 Step = 0; Step < NUM_STEP; ++Step)
		{
			FNavLocation ProjectedLocation;

			const FVector Location = CharacterLocation + (CharacterForward * (Step * STEP_DISTANCE));

			if (!NavSys->ProjectPointToNavigation(Location, ProjectedLocation, INVALID_NAVEXTENT, &AgentProps))
			{
				// 네비게이션 메시가 없는 위치 발견!

#if ENABLE_DRAW_DEBUG
				if (CVarP3ActionDebug.GetValueOnGameThread() != 0)
				{
					DrawDebugSphere(GetWorld(), Location, 30.0f, 16, FColor::Red, true, 3.0f);
					DrawDebugSphere(GetWorld(), CharacterLocation + FVector(0, 0, 100), 30.0f, 16, FColor::Blue, true, 3.0f);
				}
#endif
				return false;
			}

#if ENABLE_DRAW_DEBUG
			if (CVarP3ActionDebug.GetValueOnGameThread() != 0)
			{
				DrawDebugSphere(GetWorld(), Location, 30.0f, 16, FColor::Green);
			}
#endif
		}
	}

	return true;
}

void UP3CombatChargingPawnAction::Server_Tick(AP3Character* Character, float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Character)
	{
		return;
	}

	if (!bChargingEnded)
	{
		const FP3CombatCharging& CombatCharging = Character->GetP3CombatComponentBP()->GetChargings()[ChargingIndex];

		if (Server_bHitTargetCharacter && !CombatCharging.HitAnimMontageName.IsNone())
		{
			Character->StartMontageAction(CombatCharging.HitAnimMontageName);
			return;
		}

		const FName StopAnimMontageName = CombatCharging.StopAnimMontageName;

		const float ChargedDistanceSquared = (Character->GetActorLocation() - Server_StartLocation).SizeSquared();
		if (ChargedDistanceSquared > MaxDistance * MaxDistance)
		{
			Character->StartMontageAction(StopAnimMontageName);
			return;
		}

		if (!ChargingTargetActor)
		{
			Character->StartMontageAction(StopAnimMontageName);
			return;
		}

		const bool bClearPathAhead = Server_HasClearPathAhead(Character);

		if (!bClearPathAhead)
		{
			// 전방에 위험 요소가 감지됨. 차징 중단
			GetOwnerComponent()->OnActionProgress(this, STEP_END);
			return;
		}

		FVector MoveDelta2D = Character->GetActorLocation() - Server_LastLocation;
		MoveDelta2D.Z = 0;

		// See if we passed target
		if (!bPassedTarget)
		{
			const FVector MyStartLocation = Server_StartLocation;
			const FVector MyCurrentLocation = Character->GetActorLocation();
			const FVector TargetCurrentLocation = ChargingTargetActor->GetActorLocation();

			const FVector MyStartToMyCurrent = MyCurrentLocation - MyStartLocation;
			const FVector MyCurrentToTargetCurrent = TargetCurrentLocation - MyCurrentLocation;

			const bool bNewPassedTarget = (MyStartToMyCurrent.SizeSquared() > FMath::Square(300))
				&& ((MyStartToMyCurrent | MyCurrentToTargetCurrent) < 0);

			if (bNewPassedTarget)
			{
				Server_TargetPassedTimeSeconds = GetWorld()->GetTimeSeconds();

				GetOwnerComponent()->OnActionProgress(this, STEP_PASSED_TARGET);
			}
		}
		else  // Passed target
		{
			const float TimeSincePassedTarget = GetWorld()->GetTimeSeconds() - Server_TargetPassedTimeSeconds;

			if (TimeSincePassedTarget > ChargingBrakeTime)
			{
				Character->StartMontageAction(StopAnimMontageName);
				return;
			}
		}

		// If we are moving sideway, turn to moving direction
		// This makes look more realistic when it hits wall

		if (MoveDelta2D.SizeSquared() > FMath::Square(10))
		{
			const FRotator MovingDirectionRotator = FRotationMatrix::MakeFromX(MoveDelta2D).Rotator();
			const FRotator NewRotation = FMath::RInterpConstantTo(Character->GetActorRotation(), MovingDirectionRotator, DeltaSeconds, CVarP3ChargingBouncingRotateSpeed.GetValueOnGameThread());

			Character->SetActorRotation(NewRotation);
		}

		// See if we are in stuck
		Server_LastStuckCheckTimeSeconds += DeltaSeconds;

		if (Server_LastStuckCheckTimeSeconds > CVarP3ChargingStuckTickPeriod.GetValueOnGameThread())
		{
			Server_LastStuckCheckTimeSeconds = 0;

			const FVector CurrentLocation = Character->GetActorLocation();
			const float MovedDistanceSquared = (CurrentLocation - Server_LastStuckCheckLocation).SizeSquared();
			const float StuckDistance = CVarP3ChargingStuckDistance.GetValueOnGameThread();

			if (MovedDistanceSquared < FMath::Square(StuckDistance))
			{
				// Stuck
				GetOwnerComponent()->OnActionProgress(this, STEP_END);
			}

			Server_LastStuckCheckLocation = CurrentLocation;
		}

		Server_LastLocation = Character->GetActorLocation();
	}
}

void UP3CombatChargingPawnAction::Multicast_Finish(EP3PawnActionResult Result)
{
	Super::Multicast_Finish(Result);

	// Charging's finish time is server-driven for now
	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		Finish(Result);
	}
}

float UP3CombatChargingPawnAction::GetMoveSpeedMultiplier() const
{
	return MoveSpeedMultiplier;
}

void UP3CombatChargingPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetP3Character();
	if (Character)
	{
		if (Character->GetMesh())
		{
			Character->GetMesh()->OnComponentBeginOverlap.RemoveDynamic(this, &UP3CombatChargingPawnAction::Server_OnMeshBeginOverlap);
		}

		Character->OnActorHit.RemoveDynamic(this, &UP3CombatChargingPawnAction::Server_OnActorHit);
	}

	ChargingIndex = 0;
	ChargingTargetActor = nullptr;
	MaxDistance = 1.0f;
	MoveSpeed = 0.0f;
	MoveSpeedMultiplier = 1.0f;
	ChargingBrakeTime = 0.0f;
	NeedSpeedForStuck = 0.0f;
	NeedSpeedForHitCharacter = 0.0f;
	ChargingDamagePermil = 0.0f;
	Server_bHitTargetCharacter = false;

	Server_StartLocation = FVector::ZeroVector;
	Server_TargetStartLocation = FVector::ZeroVector;
	Server_StartTimeSeconds = 0.0f;
	Server_TargetPassedTimeSeconds = 0.0f;
	Server_LastStuckCheckTimeSeconds = 0.0f;
	Server_LastStuckCheckLocation = FVector::ZeroVector;
	Server_LastLocation = FVector::ZeroVector;

	Server_DamageAppliedActors.Empty();

	bPassedTarget = false;
	bChargingEnded = false;

	bLocalControl = false;
	LocalControl_MoveRightInput = 0.0f;
	LocalControl_EndingSlideProgress = 0.0f;
}

void UP3CombatChargingPawnAction::Server_OnMeshBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!OtherComp || !OtherActor)
	{
		return;
	}

	if (Server_DamageAppliedActors.Contains(OtherActor))
	{
		// Only one hit for each actor is allowed, to avoid awkward double hit
		return;
	}

	AP3Character* Character = GetP3Character();

	if (ensure(Character) && Character->GetVelocity().SizeSquared() < NeedSpeedForHitCharacter * NeedSpeedForHitCharacter)
	{
		return;
	}

	AP3Character* TargetCharacter = Cast<AP3Character>(OtherActor);

	if (TargetCharacter)
	{
		// Only character capsule is valid target, otherwise player will feel it's too much and not predictable
		if (!OtherComp->IsA(UCapsuleComponent::StaticClass()))
		{
			return;
		}
	}

	const bool bIsTargetKnockDowned = TargetCharacter && TargetCharacter->IsKnockDowned();

	if (bIsTargetKnockDowned)
	{
		return;
	}

	UP3CombatComponent* CombatComp = Character ? Character->GetP3CombatComponentBP() : nullptr;
	UP3CharacterEffectComponent* TargetCharacterEffectComp = TargetCharacter ? TargetCharacter->GetEffectComponent() : nullptr;

	if (CombatComp && TargetCharacterEffectComp)
	{
		if (TargetCharacterEffectComp->GetOverlappableBuffEffectiveLevel(EP3OverappableBuffType::Brace) >= CombatComp->GetCancelChargingBraceLevel())
		{
			return;
		}
	}

	P3Combat::FDamageActorParams DamageParams(*Character, *OtherActor);
	DamageParams.TargetComponent = Cast<UPrimitiveComponent>(OtherActor->GetRootComponent());
	DamageParams.ImpactDirection = Character->GetActorQuat().GetForwardVector();
	DamageParams.DamagePermil = ChargingDamagePermil;
	DamageParams.AttackStrength = EAnimNotifyAttackStrengthFlags::ExtraLarge;
	DamageParams.AttackDirection = EAnimNotifyAttackDirectionFlags::Push;
	DamageParams.AttackAttribute = EP3AnimNotifyAttackAttribute::Bash;

	P3Combat::Server_DamageActor(DamageParams);

	Server_DamageAppliedActors.Add(OtherActor);

	Server_bHitTargetCharacter = TargetCharacter ? true : false;
}

void UP3CombatChargingPawnAction::Server_OnActorHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	UP3PawnActionComponent* ActionComponent = Character->GetActionComponent();
	if (!ensure(ActionComponent))
	{
		return;
	}

	float SquaredHitSpeed = -1;
	for (uint32 Index = 0; Index < SquaredSpeedHistory.Capacity(); ++Index)
	{
		SquaredHitSpeed = (SquaredSpeedHistory[Index] > SquaredHitSpeed) ? SquaredSpeedHistory[Index] : SquaredHitSpeed;
	}

	const FVector HitDirection = (Hit.Location - Character->GetActorLocation()).GetSafeNormal2D();
	const bool bIsAllowedHitDirection = FVector::DotProduct(HitDirection, Character->GetActorForwardVector().GetSafeNormal2D()) >= CVarP3ChargingStuckMinDotProduct.GetValueOnGameThread();

	if (Character->IsLarge()
		&& SquaredHitSpeed > NeedSpeedForStuck * NeedSpeedForStuck
		&& bIsAllowedHitDirection
		&& OtherActor->ActorHasTag(P3Tags::StuckWhenColliding))
	{
		bool bHornBroken = false;

		TArray<UP3PartComponent*> PartComps;
		Character->GetComponents<UP3PartComponent>(PartComps);

		for (auto&& PartComp : PartComps)
		{
			//TODO: Move to data table
			const static FName PartName = FName(TEXT("Part_Horn"));
			if (PartComp->GetPartDesc().PartName == PartName)
			{
				IGameplayTagAssetInterface* TagInterface = Cast<IGameplayTagAssetInterface>(Character);
				if (TagInterface && TagInterface->HasAllMatchingGameplayTags(PartComp->GetPartDesc().GameplayTagOnBroken))
				{
					bHornBroken = true;
				}
				break;
			}
		}

		if (bHornBroken)
		{
			Character->StartMontageAction(Character->GetStuckWhenChargingWithoutHornMontageName());
		}
		else
		{
			Character->StartMontageAction(Character->GetStuckWhenChargingMontageName());
		}

		Character->Server_OnHitWallDuringCharging(OtherActor);

		AP3Destructible* Destructible = Cast<AP3Destructible>(OtherActor);

		if (Destructible && Destructible->GetFractureByLargeCharacterCharging() && !Destructible->Server_IsExploded())
		{
			Destructible->Server_Fracture();
		}

	}
}

UP3TripOverPawnAction::UP3TripOverPawnAction()
{

}

void UP3TripOverPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	//Character->GetCapsuleComponent()->AddImpulse(Character->GetActorForwardVector() * 5000 + FVector(0, 0, 3000), NAME_None, true);

	SetAnimMontage(Character->GetAnimMontages().TripOver);
	
	Super::Multicast_StartAction(Params);
}

void UP3TripOverPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const bool bServerPawn = (Character->Role == ROLE_Authority && Character->GetRemoteRole() == ROLE_SimulatedProxy);
	const bool bLocalControlPawn = (Character->Role == ROLE_AutonomousProxy);
	if (bServerPawn || bLocalControlPawn)
	{
		AgeSeconds += DeltaSeconds;

		const float MoveForwardInput = 1.0f - FMath::Pow(FMath::GetRangePct(0.0f, 2.0f, AgeSeconds), 2.0f);
		if (MoveForwardInput > 0)
		{
			Character->AddMovementInput(Character->GetActorForwardVector() * MoveForwardInput, 1.0f, true);
		}
	}
}

bool UP3TripOverPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (OtherActionType == EPawnActionType::TripOver)
	{
		return false;
	}

	return true;
}

void UP3TripOverPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AgeSeconds = 0;
}

UP3BouncingJumpPawnAction::UP3BouncingJumpPawnAction()
{

}

void UP3BouncingJumpPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	Character->GetP3CharacterMovementBP()->AddImpulse(Params.RequestParams.BouncingJump_Impulse, true);

	SetAnimMontage(Character->GetAnimMontages().BouncingJump);

	Super::Multicast_StartAction(Params);
}

bool UP3BouncingJumpPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (OtherActionType == EPawnActionType::BouncingJump)
	{
		return false;
	}

	return true;
}

UP3CharacterMontageAction::UP3CharacterMontageAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

void UP3CharacterMontageAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	// DYLEE NOTE P3-3209 작업 영역 분리
	if (!CVarP3ActionDataDriven.GetValueOnGameThread())
	{
		const FP3CharacterMontageActionDesc* Desc = Character->GetMontageActionDescs().Find(Params.RequestParams.CharacterMontage_Name);

		if (!Desc)
		{
			ActionJsonLog(Warning, "Can't find action desc",
				TEXT("Name"), Params.RequestParams.CharacterMontage_Name.ToString());
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		bMoveAndRotateAllowed = Desc->bAllowMoveAndRotate;
		bIsKnockDown = Desc->bIsKnockDown;
		bIsIgnoreFireHitAction = Desc->bIgnoreFireHitAction;
		SetCanForceStartActions(Desc->CanForceStartActions);
		CanForceStartMontageActionNames = Desc->CanForceStartMontageActionNames;

		if (Desc->StaminaConsume > 0 && Character->GetStaminaComponent())
		{
			Character->GetStaminaComponent()->ConsumeStamina(Desc->StaminaConsume);
		}

		SetAnimMontage(Desc->AnimMontage);

		PlayAnimMontage();

#if !UE_BUILD_SHIPPING
		if (Desc->AnimMontage)
		{
			AddDebugStringUntilFinish(Desc->AnimMontage->GetName());
		}
#endif
	}
	else
	{
		if (UP3PawnActionComponent* ActionComp = Cast<UP3PawnActionComponent>(GetOwnerComponent()))
		{
			const FP3CharacterMontageActionRow* Desc = ActionComp->GetCharacterMontageActionDesc(Params.RequestParams.CharacterMontage_Name);

			if (!Desc)
			{
				ActionJsonLog(Warning, "Can't find action desc",
					TEXT("Name"), Params.RequestParams.CharacterMontage_Name.ToString());
				Finish(EP3PawnActionResult::Failed);
				return;
			}

			SetActionKey(Params.RequestParams.CharacterMontage_Name);

			bMoveAndRotateAllowed = Desc->bAllowMoveAndRotate;
			bIsKnockDown = Desc->bIsKnockDown;
			// DYLEE NOTE 액션 테이블화된 내용이지만 참고를 위해 남겨둠
			//bIsIgnoreFireHitAction = Desc->bIgnoreFireHitAction;
			//SetCanForceStartActions(Desc->CanForceStartActions);
			//CanForceStartMontageActionNames = Desc->CanForceStartMontageActionNames;

			if (Desc->StaminaConsume > 0 && Character->GetStaminaComponent())
			{
				Character->GetStaminaComponent()->ConsumeStamina(Desc->StaminaConsume);
			}

			SetAnimMontage(Desc->AnimMontage);

			PlayAnimMontage();

#if !UE_BUILD_SHIPPING
			if (Desc->AnimMontage)
			{
				AddDebugStringUntilFinish(Desc->AnimMontage->GetName());
			}
#endif
		}
	}
}

bool UP3CharacterMontageAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (OtherActionType == EPawnActionType::CharacterMontage)
	{
		return false;
	}

	return true;
}

bool UP3CharacterMontageAction::CanForceFinishedByOtherAction(EPawnActionType OtherActionType, const FP3PawnActionStartRequestParams* Params) const
{
	bool bCanForceFinishedByOtherAction = Super::CanForceFinishedByOtherAction(OtherActionType, Params);
	if (!bCanForceFinishedByOtherAction)
	{
		return false;
	}

	if (OtherActionType == EPawnActionType::CombatHitFlame && bIsIgnoreFireHitAction)
	{
		return false;
	}

	if (CanForceStartMontageActionNames.Num() > 0)
	{
		if (!CanForceStartMontageActionNames.Contains(Params->CharacterMontage_Name))
		{
			return false;
		}
	}

	return true;
}

FString UP3CharacterMontageAction::GetRequestParamsDebugString(const FP3PawnActionStartRequestParams& Params) const
{
	FString DebugString = Super::GetRequestParamsDebugString(Params);

	DebugString += FString::Printf(TEXT("Montage(%s)"), *Params.CharacterMontage_Name.ToString());

	return DebugString;
}

void UP3CharacterMontageAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	bMoveAndRotateAllowed = false;
	bIsKnockDown = false;
}

void UP3CharacterMontageAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::StopFire)
	{
		if (!P3Core::IsP3NetModeServerInstance(*this))
		{
			return;
		}

		AP3Character* Character = GetP3Character();
		if (!ensure(Character))
		{
			return;
		}

		UP3FlammableComponent* FlammableComp = Character->FindComponentByClass<UP3FlammableComponent>();
		if (FlammableComp)
		{
			FlammableComp->Server_StopFire();
		}
	}
}

void UP3DownedEndPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	SetAnimMontage(Character->GetAnimMontages().DownedEnd);
	ChangeCharacterStance(EP3CharacterStance::Idle);
	
	Super::Multicast_StartAction(Params);
}

void UP3DownedEndPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::DownedEnd)
	{
		AP3Character* Character = GetP3Character();
		if (Character && P3Core::IsP3NetModeServerInstance(*this))
		{
			UP3CharacterHealthPointComponent* CharacterHealthComponent = Character->GetP3CharacterHealthComponentBP();
			if (CharacterHealthComponent)
			{
				CharacterHealthComponent->Server_Rescued();
			}
		}
	}
}

UP3RescuePawnAction::UP3RescuePawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3RescuePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	/** If Character dead, Don't rescue other character */
	AP3Character* Character = GetP3Character();
	if (!Character || Character->IsDowned())
	{
		return false;
	}

	AP3Character * RescueTargetCharacter = Cast<AP3Character>(Params.Rescue_TargetActor.Actor);
	if (!RescueTargetCharacter || !RescueTargetCharacter->IsDowned())
	{
		return false;
	}
	
	return true;
}

void UP3RescuePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character * Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	SetAnimMontage(Character->GetAnimMontages().Rescue);
	
	const bool bPlayed = PlayAnimMontage();
	if (!bPlayed)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	//Todo: Interaction Lock?
	TargetCharacter = Cast<AP3Character>(Params.RequestParams.Rescue_TargetActor.Actor);
	if (!TargetCharacter)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	FP3CharacterStore NewStore = Character->GetCharacterStoreBP();
	NewStore.RescueTargetCharacter = TargetCharacter;
	Character->SetCharacterStore(NewStore);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3CharacterHealthPointComponent* TargetHealthComp = (TargetCharacter) ? TargetCharacter->GetP3CharacterHealthComponentBP() : nullptr;
		if (TargetHealthComp)
		{
			TargetHealthComp->Server_SetUnderRescue(true);
		}
	}
}

void UP3RescuePawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);
	
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (!TargetCharacter)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (TargetCharacter->IsMounted())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (bSavedSomeone)
	{
		return;
	}

	/** If Helper move, cancel Help*/
	AP3Character* Character = GetP3Character();
	if (Character)
	{
		UP3CharacterMovementComponent * MovementComp = Character->GetP3CharacterMovementBP();
		if (MovementComp && !MovementComp->GetCurrentAcceleration().IsZero())
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	UP3CharacterHealthPointComponent* HealthComp = (Character) ? Character->GetP3CharacterHealthComponentBP() : nullptr;
	UP3CharacterHealthPointComponent* TargetHealthComp = TargetCharacter->GetP3CharacterHealthComponentBP();
	if (HealthComp && TargetHealthComp)
	{
		const int32 HealedAmount = HealthComp->Server_TickRescue(DeltaSeconds, TargetHealthComp);

		if (HealedAmount > 0)
		{
			P3Contribution::Server_AddPoint(Character, EP3ContributionType::Rescue, HealedAmount);
		}
	}
	
	if (TargetCharacter->CanBeRescued())
	{
		TargetCharacter->Server_Rescued();
		GetOwnerComponent()->OnActionProgress(this, STEP_END);
	}
	else if (!TargetCharacter->IsDowned())
	{
		Finish(EP3PawnActionResult::Success);
	}
}

void UP3RescuePawnAction::Multicast_Progress(int32 StepIndex)
{
	Super::Multicast_Progress(StepIndex);

	AP3Character * Character = GetP3Character();
	if (Character && StepIndex == STEP_END)
	{
		bSavedSomeone = true;
		bIgnoreMoveInput = true;

		const static FName SectionName = FName(TEXT("End"));
		UAnimInstance* AnimInstance = (Character->GetMesh()) ? Character->GetMesh()->GetAnimInstance() : nullptr;
		if (ensure(AnimInstance))
		{
			AnimInstance->Montage_JumpToSection(SectionName);
		}
	}
}

void UP3RescuePawnAction::Multicast_Finish(EP3PawnActionResult Result)
{
	Super::Multicast_Finish(Result);

	// Rescue's finish time is server-driven for now
	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		Finish(Result);
	}
}

void UP3RescuePawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character * Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3CharacterHealthPointComponent* HealthComp = Character->GetP3CharacterHealthComponentBP();
		if (HealthComp)
		{
			HealthComp->Server_SetRescueTickAgeSeconds(0.0f);
		}

		UP3CharacterHealthPointComponent* TargetHealthComp = (TargetCharacter) ? TargetCharacter->GetP3CharacterHealthComponentBP() : nullptr;
		if (TargetHealthComp)
		{
			TargetHealthComp->Server_SetUnderRescue(false);
		}
	}

	FP3CharacterStore NewStore = Character->GetCharacterStoreBP();
	NewStore.RescueTargetCharacter = nullptr;
	Character->SetCharacterStore(NewStore);
	
	bSavedSomeone = false;
	bIgnoreMoveInput = false;
	TargetCharacter = nullptr;
}

UP3BreakfallPawnAction::UP3BreakfallPawnAction()
{
	
}

bool UP3BreakfallPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	const AP3Character* Character = GetP3Character();
	if (!Character)
	{
		return false;
	}
	
	const UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (StaminaComp && StaminaComp->IsExhausted())
	{
		return false;
	}

	return true;
}

void UP3BreakfallPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	const AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (!ensure(StaminaComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	StaminaComp->ConsumeStamina(Character->GetBreakfallStamina());

	SetAnimMontage(Character->GetAnimationByType(EP3ActionAnimationType::BreakfallAir));
	
	Super::Multicast_StartAction(Params);
}

bool UP3BreakfallPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::CombatHit)
	{
		return true;
	}

	return false;
}

void UP3BreakfallPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	const AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (StaminaComp)
	{
		StaminaComp->SetConsumePerAction(0.0f);
	}
}

UP3ParkourClimbUp::UP3ParkourClimbUp()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_AutonomousHeadStart | UP3PlayMontagePawnAction::Flags_FlyingMode);
}

void UP3ParkourClimbUp::Autonomous_PreStartAction(const FP3PawnActionStartRequestParams& Params)
{
	SelectClimbUpMontage(Params.ParkourClimbUp_MontageIndex);

	Super::Autonomous_PreStartAction(Params);
}

void UP3ParkourClimbUp::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	if (!IsPlayedAtPreStart())
	{
		SelectClimbUpMontage(Params.RequestParams.ParkourClimbUp_MontageIndex);
	}

	Super::Multicast_StartAction(Params);
}

bool UP3ParkourClimbUp::IsDisableCollisionWithWorldObject() const
{
	if (CVarP3ParkourDisableCollision.GetValueOnGameThread() == 0)
	{
		return false;
	}

	return true;
}

void UP3ParkourClimbUp::SelectClimbUpMontage(int32 MontageIndex)
{
	const AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const UP3ParkourData* ParkourData = Character->GetParkourData();
	if (!ensure(ParkourData))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(ParkourData->ClimbUpMontages.IsValidIndex(MontageIndex)))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(ParkourData->ClimbUpMontages[MontageIndex].Montage);
}

bool UP3ExhaustPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	AP3Character* Character = GetP3Character();
	if (Character && Character->GetStaminaComponent())
	{
		if (Character->GetStaminaComponent()->GetConsumer(EStaminaConsumerLayer::Combo) != 0.0f)
		{
			return false;
		}
	}

	return Super::CanStart(Params);
}

void UP3ExhaustPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!Character->GetAnimMontages().Exhaust)
	{
		Finish(EP3PawnActionResult::Success);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().Exhaust);
	Super::Multicast_StartAction(Params);
}

void UP3ExhaustPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	AP3Character* Character = GetP3Character();
	if (Character)
	{
		const UP3StaminaPointComponent* StaminaComponent = Character->GetStaminaComponent();
		if (StaminaComponent && !StaminaComponent->IsExhausted())
		{
			Finish(EP3PawnActionResult::Success);
		}
	}
}

bool UP3ExhaustPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (OtherActionType == EPawnActionType::CombatCombo)
	{
		return true;
	}

	return Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params);
}

void UP3BuckingHangOnPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!Character->GetAnimMontages().BuckingHangOn)
	{
		Finish(EP3PawnActionResult::Success);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().BuckingHangOn);

	RemoveStaminaOfMountedCharacterPerSeconds = Params.RequestParams.BuckingEndure_RemoveStaminaOfMountedCharacterPerSeconds;

	Super::Multicast_StartAction(Params);
}

void UP3BuckingHangOnPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (!StaminaComp)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (Character->IsMounted() && !Character->IsBuckingEnduring())
	{
		StaminaComp->SetConsumer(EStaminaConsumerLayer::BuckingHangOn, RemoveStaminaOfMountedCharacterPerSeconds);
	}
	else
	{
		StaminaComp->SetConsumer(EStaminaConsumerLayer::BuckingHangOn, 0);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (!Character->IsMounted())
		{
			Finish(EP3PawnActionResult::Success);
			return;
		}

		AP3Character* MountTargetCharacter = Character->GetCharacterStoreBP().MountTargetCharacter;
		if (MountTargetCharacter && !MountTargetCharacter->IsBucking())
		{
			Finish(EP3PawnActionResult::Success);
			return;
		}
	}

}

void UP3BuckingHangOnPawnAction::Multicast_Finish(EP3PawnActionResult Result)
{
	Super::Multicast_Finish(Result);

	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		Finish(Result);
	}
}

void UP3BuckingHangOnPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (StaminaComp)
	{
		StaminaComp->SetConsumer(EStaminaConsumerLayer::BuckingHangOn, 0);
	}

}

UP3MountByRegolasMoveAction::UP3MountByRegolasMoveAction()
{

}

bool UP3MountByRegolasMoveAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!Params.MountByRegolasMove_HandleActor)
	{
		return false;
	}

	if (!Params.MountByRegolasMove_TargetCharacter)
	{
		return false;
	}

	if (!Params.MountByRegolasMove_TargetCharacter->GetMountPoints().IsValidIndex(Params.MountByRegolasMove_TargetMountIndex))
	{
		return false;
	}

	return true;
}

void UP3MountByRegolasMoveAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	HandleActor = Params.RequestParams.MountByRegolasMove_HandleActor;
	TargetCharacter = Params.RequestParams.MountByRegolasMove_TargetCharacter;
	TargetMountIndex = Params.RequestParams.MountByRegolasMove_TargetMountIndex;

	if (!HandleActor)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!TargetCharacter)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!TargetCharacter->GetMountPoints().IsValidIndex(TargetMountIndex))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().MountByRegolasMove);

	Super::Multicast_StartAction(Params);
}

void UP3MountByRegolasMoveAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	HandleActor = nullptr;
	TargetCharacter = nullptr;
	TargetMountIndex = -1;
}

void UP3MountByRegolasMoveAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::MountByRegolasMove_Hold)
	{

	}
	else if (NotifyType == EActionAnimNotifyType::MountByRegolasMove_Mount)
	{
		AP3Character* Character = GetP3Character();
		UP3CommandComponent* CommandComp = Character ? Character->GetCommandComponent() : nullptr;

		if (ensure(CommandComp))
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.Mount_Detach = false;
			CommandParams.Mount_TargetCharacter = TargetCharacter;
			CommandParams.Mount_TargetMountPointIndex = TargetMountIndex;
			CommandComp->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
		}
	}
}

UP3ThrowAwayAction::UP3ThrowAwayAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3ThrowAwayAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	return true;
}

bool UP3ThrowAwayAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	return true;
}

void UP3ThrowAwayAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UAnimMontage* Montage = Character->GetAnimMontages().ThrownAway;

	if (!Montage)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Montage);
	PlayAnimMontage();

	Character->GetP3CharacterMovementBP()->AddImpulse(Params.RequestParams.ThrowAway_Velocity, true);

	if (!Params.RequestParams.ThrowAway_Velocity.IsNearlyZero())
	{
		FRotator ImpulseRotator = (-Params.RequestParams.ThrowAway_Velocity).Rotation();

		if (Character->GetP3CharacterMovementBP()->ShouldRemainVertical())
		{
			ImpulseRotator.Pitch = 0.f;
			ImpulseRotator.Yaw = FRotator::NormalizeAxis(ImpulseRotator.Yaw);
			ImpulseRotator.Roll = 0.f;
		}

		Character->SetActorRotation(ImpulseRotator);
	}
}

void UP3ThrowAwayAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (!Server_bLanded && P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_AgeSeconds += DeltaSeconds;

		// We need to wait a little bit to character gets airborn
		if (Server_AgeSeconds > 0.1f)
		{
			AP3Character* Character = GetP3Character();

			if (!Character ||
				!Character->GetCharacterMovement() ||
				!Character->GetCharacterMovement()->IsFalling())
			{
				GetOwnerComponent()->OnActionProgress(this, PROGRESS_STEP_LANDED);

				Server_bLanded = true;
			}
		}
	}
}

void UP3ThrowAwayAction::Multicast_Progress(int32 StepIndex)
{
	Super::Multicast_Progress(StepIndex);

	if (StepIndex == PROGRESS_STEP_LANDED)
	{
		const static FName SectionName = FName(TEXT("End"));

		AP3Character* Character = GetP3Character();

		if (!Character)
		{
			return;
		}

		UAnimInstance* AnimInstance = (Character->GetMesh()) ? Character->GetMesh()->GetAnimInstance() : nullptr;
		if (ensure(AnimInstance))
		{
			AnimInstance->Montage_JumpToSection(SectionName);
		}
	}
}

void UP3ThrowAwayAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	Server_AgeSeconds = 0.0f;
	Server_bLanded = false;
}


UP3CombatReactionHitPawnAction::UP3CombatReactionHitPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3CombatReactionHitPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	return true;
}

bool UP3CombatReactionHitPawnAction::CanForceFinishedByOtherAction(EPawnActionType OtherActionType, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishedByOtherAction(OtherActionType, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::CombatRoll)
	{
		return true;
	}

	return false;
}

bool UP3CombatReactionHitPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		return false;
	}

	if (Params.CombatHit_DamageType == EP3DamageType::Flame && Character->IsFlameHitActionIgnored())
	{
		return false;
	}
	
	return true;
}

void UP3CombatReactionHitPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);
	
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AttackerActor = Params.RequestParams.ReactionHit_AttackerActor;
	ReactionName = Params.RequestParams.ReactionHit_Name;
	ReactionLayer = Params.RequestParams.ReactionHit_Layer;	
	AttackAttribute = Params.RequestParams.ReactionHit_AttackAttribute;
	TargetTransform = Params.RequestParams.ReactionHit_TargetTransform;
	HitLocation = Params.RequestParams.ReactionHit_HitLocation;
	HitBoneName = Params.RequestParams.ReactionHit_HitBoneName;
	AttackerBoneName = Params.RequestParams.ReactionHit_AttackerBoneName;	
	bSkipMontageFrame = Params.RequestParams.ReactionHit_SkipMontageFrame;
	ThrowAwayVelocity = Params.RequestParams.ReactionHit_ThrowAwayVelocity;
	bIsFrameHold = Params.RequestParams.ReactionHit_bIsFrameHold;	

	if (!AttackerActor)
	{
		AttackerActor = P3Core::GetP3World(*this)->GetActorFromActorId(Params.RequestParams.ReactionHit_AttackerActorID);
	}

	const FP3CombatReactionRow* ReactionRow = GetReactionRow(*Character);
	if (!ensure(ReactionRow))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (ReactionLayer == EP3ReactionLayer::Guard || ReactionLayer == EP3ReactionLayer::Parrying)
	{
		ThrowAwayVelocity = FVector::ZeroVector;
	}

	MoveSpeedMultiplier = ReactionRow->MoveSpeedMultiplier;
	SnapshotName = ReactionRow->Ragdoll.SnapshotName;
	
	SetPlayRate(Params.RequestParams.ReactionHit_StartMontagePlayRate);
	SetPlayMontagePosition(Params.RequestParams.ReactionHit_StartMontagePosition);	
	SetStopBlendOutTime(0.f);
	
	StartReactionAnimation(*Character, *ReactionRow);
	StartReactionMovement(*Character, *ReactionRow);

	UP3CombatResponseComponent* CombatResponseComp = Character->GetP3CombatResponseoComponent();
	if (ensure(CombatResponseComp))
	{
		CombatResponseComp->SetReactionInProgress(ReactionName, ReactionLayer, Params.RequestParams.ReactionHit_AttackDirection, Params.RequestParams.ReactionHit_AttackStrength);
	}
}

void UP3CombatReactionHitPawnAction::Multicast_StopAction(const FP3PawnActionStopMulticastParams& Params)
{
	Super::Multicast_StopAction(Params);

	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		StopAnimMontage();
		Finish(EP3PawnActionResult::Aborted);
	}	
}

void UP3CombatReactionHitPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (GetActionLocalStatus() != EP3PawnActionStatus::InProgress)
	{
		return;
	}
	
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const FP3CombatReactionRow* ReactionRow = GetReactionRow(*Character);
	if (!ensure(ReactionRow))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TickReactionAnimation(*Character, *ReactionRow, DeltaSeconds);
	TickReactionMovement(*Character, *ReactionRow, DeltaSeconds);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		Server_TickReactionStatus(*Character, *ReactionRow, DeltaSeconds);
	}
}

bool UP3CombatReactionHitPawnAction::IsIgnoreMoveInput() const
{
	AP3Character* Character = GetP3Character();	
	if (Character->GetComboComponent())
	{
		return Character->GetComboComponent()->CanMove();
	}

	return true;
}

float UP3CombatReactionHitPawnAction::GetMoveSpeedMultiplier() const
{	
	return MoveSpeedMultiplier;
}

bool UP3CombatReactionHitPawnAction::IsMoveAllowed() const
{
	AP3Character* Character = GetP3Character();

	if (Character && !(Character->IsPlayerControlled()) && !(Character->IsLarge()))
	{
		return false;
	}

	return true;
}

bool UP3CombatReactionHitPawnAction::IsRotateAllowed() const
{
	AP3Character* Character = GetP3Character();

	if (Character && !(Character->IsPlayerControlled()) && !(Character->IsLarge()))
	{
		return false;
	}

	return true;
}

bool UP3CombatReactionHitPawnAction::IsJumpAllowed() const
{
	AP3Character* Character = GetP3Character();

	if (Character && !(Character->IsPlayerControlled()) && !(Character->IsLarge()))
	{
		return false;
	}

	if (Character->GetComboComponent())
	{
		return Character->GetComboComponent()->CanJump();
	}

	return true;
}

void UP3CombatReactionHitPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);
		
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	const FP3CombatReactionRow* ReactionRow = GetReactionRow(*Character);
	if (!ensure(ReactionRow))
	{	
		return;
	}

	UP3CombatResponseComponent* CombatResponseComp = Character->GetP3CombatResponseoComponent();
	if (ensure(CombatResponseComp))
	{
		CombatResponseComp->SetReactionInProgress(NAME_None, EP3ReactionLayer::None, EAnimNotifyAttackDirectionFlags::None, EAnimNotifyAttackStrengthFlags::Ignore);
	}

	FinishReactionAnimation(*Character, *ReactionRow);
	FinishReactionMovement(*Character, *ReactionRow);

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		Server_FinishReactionStatus(*Character, *ReactionRow);
	}

	AttackerActor = nullptr;
	ReactionName = NAME_None;
	ReactionLayer = EP3ReactionLayer::None;
	TargetTransform = FTransform::Identity;
	HitLocation = FVector::ZeroVector;
	ThrowAwayVelocity = FVector::ZeroVector;
	HitBoneName = NAME_None;
	AttackerBoneName = NAME_None;
	
	MoveSpeedMultiplier = 1.f;

	SnapshotName = NAME_None;
	RagdollStartedLocation = FVector::ZeroVector;
	RagdollStartedGroundHitTimeSeconds = 0.f;
	RagdollInProgressTimeSeconds = 0.f;
	DeltaMoveInProgressTimeSeconds = 0.f;
	DownInProgressTimeSeconds = 0.f;
	LastUpdateDeltaMoveInProgressTimeSeconds = 0.f;

	bLastUpdateFalling = false;
	bLastUpdateMovingOnGround = false;	

	bRestoreMovement = false;
	RestoreMaxWalkSpeed = 0.f;
	bRestoreUseSeparateBrakingFriction = false;
	bRestsoreBlocking = false;
	bRestsoreCrouchBlocking = false;

	bSkipMontageFrame = false;
	bIsFrameHold = false;
}

void UP3CombatReactionHitPawnAction::SetAnimMontage(UAnimMontage* InAnimMontage)
{
	if (bIsFrameHold && InAnimMontage)
	{
		UAnimMontage* NewMontage = NewObject<UAnimMontage>();
		if (NewMontage)
		{				
			NewMontage->SetSkeleton(InAnimMontage->GetSkeleton());				
			NewMontage->SlotAnimTracks = InAnimMontage->SlotAnimTracks;				
			NewMontage->CompositeSections = InAnimMontage->CompositeSections;
			NewMontage->Notifies = InAnimMontage->Notifies;

			NewMontage->SequenceLength = InAnimMontage->SequenceLength;
			NewMontage->BlendIn.SetBlendTime(0.f);
			NewMontage->BlendOut.SetBlendTime(InAnimMontage->BlendOut.GetBlendTime());
			NewMontage->BlendOutTriggerTime = InAnimMontage->BlendOutTriggerTime;

			InAnimMontage = NewMontage;		
		}
	}

	Super::SetAnimMontage(InAnimMontage);
}

bool UP3CombatReactionHitPawnAction::PlayAnimMontage()
{
	UP3AnimInstance* AnimInstance = Cast<UP3AnimInstance>(GetAnimInstance());
	if (AnimInstance)
	{
		if (SnapshotName != NAME_None)
		{	
			AnimInstance->AddSnapshot(SnapshotName);	
		}		
	}

	return Super::PlayAnimMontage();
}

const FP3CombatReactionRow* UP3CombatReactionHitPawnAction::GetReactionRow(AP3Character& Character) const
{
	UP3CombatResponseComponent* CombatResponseComp = Character.GetP3CombatResponseoComponent();
	if (!ensure(CombatResponseComp))
	{
		return nullptr;
	}

	const UDataTable* ReactionTable = CombatResponseComp->GetCombatReactionTable(ReactionLayer);
	if (!ensure(ReactionTable))
	{
		return nullptr;
	}

	const FP3CombatReactionRow* ReactionRow = ReactionTable->FindRow<FP3CombatReactionRow>(ReactionName, "UP3CombatReactionHitPawnAction");
	if (!ensure(ReactionRow))
	{
		return nullptr;
	}

	return ReactionRow;
}

void UP3CombatReactionHitPawnAction::StartReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	UP3AnimInstance* AnimInstance = Cast<UP3AnimInstance>(GetAnimInstance());
	if (!ensure(AnimInstance))
	{
		return;
	}

	if (ReactionRow.Montage)
	{	
		SetAnimMontage(ReactionRow.Montage);		
		PlayAnimMontage();
	}

	if (ReactionRow.RagdollDurationSeconds > 0.f)
	{
		UCharacterMovementComponent* MovementComp = Character.GetCharacterMovement();
		if (ensure(MovementComp))
		{
			MovementComp->SetMovementMode(EMovementMode::MOVE_None);
		}

		USkeletalMeshComponent* MeshComp = Character.GetMesh();
		if (ensure(MeshComp))
		{
			RagdollStartedLocation = MeshComp->GetBoneLocation(ReactionRow.Ragdoll.PelvisBoneName);
		}

		Character.RagdollizeByAction(*this, true);

		const bool bCanCatch = ReactionRow.Ragdoll.bTryCatch && ReactionRow.Ragdoll.HitBones.Contains(AttackerBoneName) && AttackerActor;
		if (bCanCatch)
		{
			USkeletalMeshComponent* AttackerMeshComp = AttackerActor->FindComponentByClass<USkeletalMeshComponent>();
			if (AttackerMeshComp)
			{
				FVector TargetLocation = AttackerMeshComp->GetBoneLocation(AttackerBoneName);
				UPhysicsHandleComponent* HandleComponent = Character.FindComponentByClass<UPhysicsHandleComponent>();

				if (HandleComponent && !TargetLocation.IsZero())
				{					
					HandleComponent->bSoftAngularConstraint = false;
					HandleComponent->bSoftLinearConstraint = false;
					HandleComponent->GrabComponentAtLocationWithRotation(Character.GetMesh(), ReactionRow.Ragdoll.AttachBoneName, TargetLocation, FRotator::ZeroRotator);				
				}
			}
		}
	}
}

void UP3CombatReactionHitPawnAction::StartReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	UP3CharacterMovementComponent* MovementComp = Character.GetP3CharacterMovementBP();

	if (!ensure(MovementComp))
	{
		return;
	}

	if (bRestoreMovement)
	{
		MovementComp->RemoveActionForce(*this);
		MovementComp->MaxWalkSpeed = RestoreMaxWalkSpeed;
		MovementComp->bUseSeparateBrakingFriction = bRestoreUseSeparateBrakingFriction;
		bRestoreMovement = false;
	}

	if (ReactionRow.DeltaMoveCurve)
	{
		DeltaMoveInProgressTimeSeconds = 0.f;
		LastUpdateDeltaMoveInProgressTimeSeconds = 0.f;
		
		bRestoreMovement = true;
		RestoreMaxWalkSpeed = MovementComp->MaxWalkSpeed;
		bRestoreUseSeparateBrakingFriction = MovementComp->bUseSeparateBrakingFriction;

		MovementComp->bUseSeparateBrakingFriction = true;

		const float Strength = 10.f;
		MovementComp->AddActionForce(FVector::ZeroVector, Strength, *this);
	}
	else if (!ThrowAwayVelocity.IsNearlyZero())
	{		
		MovementComp->AddImpulse(ThrowAwayVelocity, true);
	}

	bLastUpdateFalling = false;
	bLastUpdateMovingOnGround = false;
}

void UP3CombatReactionHitPawnAction::TickReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds)
{
	UP3AnimInstance* AnimInstance = Cast<UP3AnimInstance>(GetAnimInstance());
	if (!AnimInstance)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}	

	if (Character.IsRagdollizedBP() && ReactionRow.RagdollDurationSeconds > 0.f)
	{
		USkeletalMeshComponent* MeshComp = Character.GetMesh();
		if (!ensure(MeshComp))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		if (RagdollInProgressTimeSeconds >= ReactionRow.RagdollDurationSeconds)
		{
			UPhysicsHandleComponent* HandleComponent = Character.FindComponentByClass<UPhysicsHandleComponent>();
			if (HandleComponent && HandleComponent->GrabbedComponent)
			{
				HandleComponent->GrabbedComponent->WakeRigidBody(HandleComponent->GrabbedBoneName);
				HandleComponent->ReleaseComponent();								
			}
		}
		else
		{
			UPhysicsHandleComponent* HandleComponent = Character.FindComponentByClass<UPhysicsHandleComponent>();
			if (HandleComponent && HandleComponent->GrabbedComponent && AttackerActor)
			{
				USkeletalMeshComponent* AttackerMeshComp = AttackerActor->FindComponentByClass<USkeletalMeshComponent>();
				if (AttackerMeshComp)
				{
					FVector TargetLocation = AttackerMeshComp->GetBoneLocation(AttackerBoneName);
					HandleComponent->SetTargetLocation(TargetLocation);
					HandleComponent->GrabbedComponent->WakeRigidBody(HandleComponent->GrabbedBoneName);
				}
			}
		}

		const bool bIsStandUp = RagdollStartedGroundHitTimeSeconds >= ReactionRow.RagdollDurationSeconds;
		if (bIsStandUp)
		{
			UAnimMontage* Montage = nullptr;
			FVector Location = FVector::ZeroVector;
			FVector NeckLocation = MeshComp->GetBoneLocation(ReactionRow.Ragdoll.NeckBoneName);
			FVector PelvisLocation = MeshComp->GetBoneLocation(ReactionRow.Ragdoll.PelvisBoneName);
			FVector RightVector = MeshComp->GetBoneQuaternion(ReactionRow.Ragdoll.PelvisBoneName).GetRightVector();

			if (RightVector.DotProduct(RightVector, FVector::UpVector) < 0.f)
			{
				Montage = ReactionRow.Ragdoll.BackMontage;
				Location = PelvisLocation - NeckLocation;
			}
			else
			{				
				Montage = ReactionRow.Ragdoll.FrontMontage;
				Location = NeckLocation - PelvisLocation;
			}			

			FRotator Rotator = FRotationMatrix::MakeFromZX(FVector(0.f, 0.f, 1.f), Location).Rotator();

			Character.SetActorRotation(Rotator);
			Character.RagdollizeByAction(*this, false);

			if (!Montage)
			{
				Finish(EP3PawnActionResult::Success);
				return;
			}

			SetAnimMontage(Montage);
			const bool bPlayed = PlayAnimMontage();
			
			if (!ensure(bPlayed))
			{
				Finish(EP3PawnActionResult::Failed);
				return;			
			}
		}
		else
		{
			FVector StartLocation = MeshComp->GetBoneLocation(ReactionRow.Ragdoll.PelvisBoneName);
			FVector EndLocation = StartLocation + -FVector::UpVector * 120.f;
			FVector HitResultLocation = FVector::ZeroVector;

			FHitResult HitResult;
			if (Character.GetWorld()->LineTraceSingleByChannel(HitResult, StartLocation, EndLocation, ECollisionChannel::ECC_Visibility))
			{
				HitResultLocation = HitResult.Location + FVector(0.f, 0.f, ReactionRow.Ragdoll.Height);
				RagdollStartedGroundHitTimeSeconds += DeltaSeconds;
			}
			else
			{
				HitResultLocation = StartLocation;
			}

			RagdollStartedLocation = FMath::VInterpTo(RagdollStartedLocation, HitResultLocation, DeltaSeconds, 30.f);
			Character.SetActorLocation(RagdollStartedLocation);						
		}

		RagdollInProgressTimeSeconds += DeltaSeconds;
	}

	if (AnimInstance->HasSnapshot(SnapshotName))
	{
		if (SnapshotInProgressTimeSeconds > ReactionRow.Ragdoll.SnapshotBlendingtTimeSeconds)
		{
			AnimInstance->RemoveSnapshot(SnapshotName);
		}

		SnapshotInProgressTimeSeconds += DeltaSeconds;		
	}

	EP3ReactionLayerAnimationType InProgressAnimationType = EP3ReactionLayerAnimationType::None;

	UP3CombatResponseComponent* CombatResponseComp = Character.GetP3CombatResponseoComponent();
	if (CombatResponseComp)
	{
		InProgressAnimationType = CombatResponseComp->GetInProgressAnimationType();
	}

	if (bSkipMontageFrame && InProgressAnimationType == EP3ReactionLayerAnimationType::SkipFrame)
	{
		Finish(EP3PawnActionResult::Success);
	}
}

void UP3CombatReactionHitPawnAction::TickReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds)
{
	UP3CharacterMovementComponent* MovementComp = Character.GetP3CharacterMovementBP();
	
	if (!MovementComp)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UAnimInstance* AnimInstance = GetAnimInstance();
	if (!AnimInstance)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UCurveVector* CurrentDeltaMoveCurve = ReactionRow.DeltaMoveCurve;
	FName CurrentSectionName = AnimInstance->Montage_GetCurrentSection(AnimInstance->GetCurrentActiveMontage());

	if (CurrentSectionName == ReactionRow.FallingOnGroundSectionName)
	{
		CurrentDeltaMoveCurve = ReactionRow.FallingOnGroundDeltaMoveCurve;
	}

	if (!CurrentDeltaMoveCurve && MovementComp->GetActionForce(*this))
	{
		MovementComp->RemoveActionForce(*this);
	}

	if (CurrentDeltaMoveCurve)
	{
		FP3CharacterMovementForce* ActionForce = MovementComp->GetActionForce(*this);
		if (ActionForce)
		{		
			const bool bIsMovingOnGround = MovementComp->IsMovingOnGround() || MovementComp->IsSwimming();
			const bool bFallingOnGround = bLastUpdateFalling && bIsMovingOnGround && ReactionRow.FallingOnGroundSectionName != NAME_None;
			const bool bFalling = bLastUpdateMovingOnGround && MovementComp->IsFalling() && ReactionRow.FallingOnGroundSectionName == NAME_None;			

			if (bFallingOnGround)
			{		
				AnimInstance->Montage_JumpToSection(ReactionRow.FallingOnGroundSectionName, AnimInstance->GetCurrentActiveMontage());
			
			}
			else if (bFalling)
			{
				MovementComp->SetMovementMode(MOVE_Falling);
				Finish(EP3PawnActionResult::Success);
			}
			else if (ReactionRow.DeltaMoveDurationSeconds <= DeltaMoveInProgressTimeSeconds)
			{
				if (ReactionRow.StoppingOnGroundSectonName != NAME_None && !MovementComp->IsFalling())
				{
					AnimInstance->Montage_JumpToSection(ReactionRow.StoppingOnGroundSectonName, AnimInstance->GetCurrentActiveMontage());					
				}
				else
				{
					MovementComp->SetMovementMode(MOVE_Falling);
					Finish(EP3PawnActionResult::Success);
				}
			}
			else
			{
				const FVector UpdateDeltaMoveCurveValue = CurrentDeltaMoveCurve->GetVectorValue(DeltaMoveInProgressTimeSeconds);
				const FVector LastUpdateDeltaMoveCurveValue = CurrentDeltaMoveCurve->GetVectorValue(LastUpdateDeltaMoveInProgressTimeSeconds);

				ActionForce->ActionTargetVelocity = (UpdateDeltaMoveCurveValue - LastUpdateDeltaMoveCurveValue) / DeltaSeconds;

				MovementComp->MaxWalkSpeed = ActionForce->ActionTargetVelocity.X;

				if (MovementComp->IsFalling() && MovementComp->Velocity.Z < 0.f)
				{
					if (FMath::Abs<float>(MovementComp->Velocity.Z) > FMath::Abs<float>(ActionForce->ActionTargetVelocity.Z))
					{
						ActionForce->ActionTargetVelocity.Z = MovementComp->Velocity.Z;
					}
				}

				FVector Direction = Character.GetActorForwardVector();

				UP3CombatResponseComponent* CombatResponseComp = Character.GetP3CombatResponseoComponent();
				if (CombatResponseComp)
				{
					Direction = CombatResponseComp->GetReactiontDirection(Character, ReactionRow.ReactiontDirection);
				}
				
				ActionForce->ActionTargetVelocity = Direction.GetSafeNormal2D() * ActionForce->ActionTargetVelocity.X + FVector(0.f, 0.f, ActionForce->ActionTargetVelocity.Z);
			}

			bLastUpdateFalling = MovementComp->IsFalling() || MovementComp->IsSwimming();
			bLastUpdateMovingOnGround = MovementComp->IsMovingOnGround() || MovementComp->IsSwimming();
		}
		else
		{			
			if (ReactionRow.StandingOnGroundSectonName != NAME_None && CurrentSectionName != ReactionRow.StandingOnGroundSectonName)
			{
				DownInProgressTimeSeconds += DeltaSeconds;

				if (ReactionRow.DownDurationSeconds <= DownInProgressTimeSeconds)
				{
					AnimInstance->Montage_JumpToSection(ReactionRow.StandingOnGroundSectonName, AnimInstance->GetCurrentActiveMontage());
					return;
				}
			}
		}

		LastUpdateDeltaMoveInProgressTimeSeconds = DeltaMoveInProgressTimeSeconds;
		DeltaMoveInProgressTimeSeconds += DeltaSeconds;
	}	
	else if (!ThrowAwayVelocity.IsNearlyZero())
	{
		const bool bIsMovingOnGround = MovementComp->IsMovingOnGround() || MovementComp->IsSwimming();
		const bool bFallingOnGround = bLastUpdateFalling && bIsMovingOnGround;		

		if (bFallingOnGround)
		{
			if (ReactionRow.FallingOnGroundSectionName == NAME_None)
			{
				Finish(EP3PawnActionResult::Failed);
				return;
			}
			else if (CurrentSectionName != ReactionRow.FallingOnGroundSectionName)
			{
				AnimInstance->Montage_JumpToSection(ReactionRow.FallingOnGroundSectionName, AnimInstance->GetCurrentActiveMontage());
				ThrowAwayVelocity = FVector::ZeroVector;
			}
		}

		bLastUpdateFalling = MovementComp->IsFalling() || MovementComp->IsFlying() || MovementComp->IsSwimming() || MovementComp->GetLastUpdateVelocity().IsNearlyZero();
		bLastUpdateMovingOnGround = MovementComp->IsMovingOnGround() || MovementComp->IsSwimming();
	}
}

void UP3CombatReactionHitPawnAction::Server_TickReactionStatus(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds)
{
	EP3ReactionLayerAnimationType InProgressAnimationType = EP3ReactionLayerAnimationType::None;

	UP3CombatResponseComponent* CombatResponseComp = Character.GetP3CombatResponseoComponent();
	if (CombatResponseComp)
	{
		InProgressAnimationType = CombatResponseComp->GetInProgressAnimationType();
	}

	if (ReactionLayer == EP3ReactionLayer::Guard)
	{
		if (InProgressAnimationType == EP3ReactionLayerAnimationType::Guard)
		{
			if (!Character.GetCharacterStoreBP().bIsBlocking)
			{
				FP3CommandRequestParams BlockingCommandParams;
				BlockingCommandParams.SetBlocking_bNewBlocking = true;
				Character.GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), BlockingCommandParams);

				bRestsoreBlocking = true;
			}
		}
			
		if (InProgressAnimationType == EP3ReactionLayerAnimationType::CrouchGuard)
		{
			if (!Character.GetCharacterStoreBP().bIsCrouchBlocking)
			{
				FP3CommandRequestParams CrouchBlockingCommandParams;
				CrouchBlockingCommandParams.SetCrouchBlocking_bNewBlocking = true;
				Character.GetCommandComponent()->RequestCommand(UP3SetCrouchBlockingCommand::StaticClass(), CrouchBlockingCommandParams);

				bRestsoreCrouchBlocking = true;
			}
		}
	}	
}

void UP3CombatReactionHitPawnAction::FinishReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	UP3AnimInstance* AnimInstance = Cast<UP3AnimInstance>(GetAnimInstance());
	if (AnimInstance)
	{
		AnimInstance->RemoveSnapshot(SnapshotName);
	}

	if (Character.IsRagdollizedBP())
	{
		UPhysicsHandleComponent* HandleComponent = Character.FindComponentByClass<UPhysicsHandleComponent>();
		if (HandleComponent && HandleComponent->GrabbedComponent)
		{
			HandleComponent->GrabbedComponent->WakeRigidBody(HandleComponent->GrabbedBoneName);
			HandleComponent->ReleaseComponent();
		}

		Character.RagdollizeByAction(*this, false);
	}	
}

void UP3CombatReactionHitPawnAction::FinishReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{
	if (bRestoreMovement)
	{
		UP3CharacterMovementComponent* MovementComp = Character.GetP3CharacterMovementBP();
		if (MovementComp && ReactionRow.DeltaMoveCurve)
		{
			MovementComp->RemoveActionForce(*this);
			MovementComp->MaxWalkSpeed = RestoreMaxWalkSpeed;
			MovementComp->bUseSeparateBrakingFriction = bRestoreUseSeparateBrakingFriction;
		}
	}
}

void UP3CombatReactionHitPawnAction::Server_FinishReactionStatus(AP3Character& Character, const FP3CombatReactionRow& ReactionRow)
{		
	if (bRestsoreBlocking)
	{
		FP3CommandRequestParams BlockingCommandParams;
		BlockingCommandParams.SetBlocking_bNewBlocking = false;
		Character.GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), BlockingCommandParams);	
	}

	if (bRestsoreCrouchBlocking)
	{
		FP3CommandRequestParams CrouchBlockingCommandParams;
		CrouchBlockingCommandParams.SetCrouchBlocking_bNewBlocking = false;
		Character.GetCommandComponent()->RequestCommand(UP3SetCrouchBlockingCommand::StaticClass(), CrouchBlockingCommandParams);				
	}
}

UP3CableMovePawnAction::UP3CableMovePawnAction()
{

}

bool UP3CableMovePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	return true;
}

bool UP3CableMovePawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{	
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::CableMove)
	{
		return false;
	}
	
	return true;
}

void UP3CableMovePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	CableWeaponActor = Params.RequestParams.CableMove_WeaponActor;
	CableHitActor = Params.RequestParams.CableMove_HitActor;		
	CableMoveImpulse = Params.RequestParams.CableMove_CableMoveImpulse;
	TargetMountPointIndex = -1;

	if (!CableWeaponActor)
	{
		CableWeaponActor = P3Core::GetP3World(*this)->GetActorFromActorId(Params.RequestParams.CableMove_WeaponActorID);
	}

	if (!CableHitActor)
	{
		CableHitActor = P3Core::GetP3World(*this)->GetActorFromActorId(Params.RequestParams.CableMove_HitActorActorID);
	}

	if (!CableWeaponActor || !CableHitActor)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3Character* CableHitCharacter = Cast<AP3Character>(CableHitActor);
	if (CableHitCharacter)
	{				
		TargetMountPointIndex = GetTargetMountPointIndex(CableHitCharacter, CableWeaponActor->GetActorLocation());
	}
			
	SetAnimMontage(Character->GetAnimMontages().CableMove);

	Character->GetP3CharacterMovementBP()->SetMovementMode(MOVE_Flying);
	Character->SetActorEnableCollision(false);
	
	Super::Multicast_StartAction(Params);
}

void UP3CableMovePawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);
	
	AP3Character* Character = GetP3Character();
	if (!Character || !CableHitActor)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	FVector TargetLocation = CableHitActor->GetActorLocation();
	AP3Character* CableHitCharacter = Cast<AP3Character>(CableHitActor);	

	if (CableHitCharacter && TargetMountPointIndex >= 0)
	{
		const FP3CharacterMountPoint& MountPoint = CableHitCharacter->GetMountPoints()[TargetMountPointIndex];
		TargetLocation = CableHitCharacter->GetMesh()->GetSocketLocation(MountPoint.SocketName);
	}

	const float CapsuleRadius = Character->GetCapsuleComponent() ? Character->GetCapsuleComponent()->GetScaledCapsuleRadius() : 100.f;
	FVector SourceLocation = Character->GetActorLocation();
	const float Size2D = (TargetLocation - SourceLocation).Size2D();
	const float ImpulseScale = (CapsuleRadius + Size2D) / 1000.f;
	FVector Impulse = (TargetLocation - SourceLocation).GetSafeNormal() * CableMoveImpulse * ImpulseScale;

	if (CableWeaponActor)
	{
		UCableComponent* CableComp = CableWeaponActor->FindComponentByClass<UCableComponent>();
		if (CableComp)
		{
			CableComp->CableLength = Size2D / ImpulseScale;
		}
	}
	
	Character->GetP3CharacterMovementBP()->AddImpulse(Impulse, false);
	
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		FCollisionObjectQueryParams ObjectQueryParams;
		FCollisionQueryParams QueryParams;

		FCollisionShape CollisionShape;
		TArray<class AActor*> IgnoredActors;

		ObjectQueryParams.AddObjectTypesToQuery(ECC_Pawn);

		Character->GetAttachedActors(IgnoredActors);
		IgnoredActors.Add(Character);
		IgnoredActors.Add(CableWeaponActor);
		QueryParams.AddIgnoredActors(IgnoredActors);

		CollisionShape.SetSphere(CapsuleRadius);

		TArray<FOverlapResult> OverlapResults;
		GetWorld()->OverlapMultiByObjectType(OverlapResults, SourceLocation, Character->GetActorQuat(), ObjectQueryParams, CollisionShape, QueryParams);

		for (const FOverlapResult& OverlapResult : OverlapResults)
		{
			AP3Character* OutHitHitCharacter = Cast<AP3Character>(OverlapResult.Actor);			
			if (OutHitHitCharacter == CableHitCharacter)
			{
				TargetMountPointIndex = GetTargetMountPointIndex(CableHitCharacter, SourceLocation);

				if (TargetMountPointIndex >= 0 && !Character->IsMounted())
				{
					UP3CommandComponent* CommandComponent = Character->GetCommandComponent();
					if (CommandComponent)
					{
						FP3CommandRequestParams CommandParams;
						CommandParams.Mount_Detach = false;
						CommandParams.Mount_TargetCharacter = CableHitCharacter;
						CommandParams.Mount_TargetMountPointIndex = TargetMountPointIndex;
						CommandComponent->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);						
					}
				}

				Finish(EP3PawnActionResult::Success);
				break;
			}	
		}
	}
}

void UP3CableMovePawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (CableWeaponActor)
	{
		UCableComponent* CableComp = CableWeaponActor->FindComponentByClass<UCableComponent>();
		if (CableComp)
		{
			CableComp->SetAttachEndTo(nullptr, NAME_None);
			CableComp->SetVisibility(false);
		}
	}

	AP3Character* Character = GetP3Character();
	if (Character)
	{
		if (Character->GetP3CharacterMovementBP()->IsFlying())
		{
			Character->GetP3CharacterMovementBP()->StopMovementImmediately();
			Character->GetP3CharacterMovementBP()->SetMovementMode(MOVE_Falling);
		}

		Character->SetActorEnableCollision(true);
	}	
}

void UP3CableMovePawnAction::Multicast_Finish(EP3PawnActionResult Result)
{
	Super::Multicast_Finish(Result);

	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		Finish(Result);
	}
}

int32 UP3CableMovePawnAction::GetTargetMountPointIndex(AP3Character* CableHitCharacter, const FVector& TargetLocation)
{
	int32 MinTargetMountPointIndex = -1;

	if (CableHitCharacter)
	{
		float MinDistanceSquared = MAX_flt;
		const int32 NumMountPoints = CableHitCharacter->GetMountPoints().Num();

		for (int32 MountPointIndex = 0; MountPointIndex < NumMountPoints; ++MountPointIndex)
		{
			if (!CableHitCharacter->IsMountPointAvailable(MountPointIndex))
			{
				continue;
			}

			const FP3CharacterMountPoint& MountPoint = CableHitCharacter->GetMountPoints()[MountPointIndex];
			const FVector SocketLocation = CableHitCharacter->GetMesh()->GetSocketLocation(MountPoint.SocketName);
			const float DistanceSquared = (SocketLocation - TargetLocation).SizeSquared();

			if (MinDistanceSquared > DistanceSquared)
			{
				MinDistanceSquared = DistanceSquared;
				MinTargetMountPointIndex = MountPointIndex;
			}
		}
	}

	return MinTargetMountPointIndex;
}

UP3RoarStunAction::UP3RoarStunAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3RoarStunAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (OtherActionType == EPawnActionType::CombatReactionHit
		|| OtherActionType == EPawnActionType::CableMove)
	{
		return false;
	}

	return Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params);
}

bool UP3RoarStunAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	/** If Character downed, Don't roar stun action */
	AP3Character* Character = GetP3Character();
	if (!Character || Character->IsDowned())
	{
		return false;
	}

	return true;
}

void UP3RoarStunAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UAnimMontage* Montage = Character->GetAnimMontages().RoarStun;

	if (!Montage)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Montage);
	PlayAnimMontage();
}

void UP3RoarStunAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (!Server_HasStunned && P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = GetP3Character();

		if (!Character ||
			!Character->GetEffectComponent() ||
			!Character->GetEffectComponent()->HasEffect(EP3CharacterEffectTypes::RoarStun))
		{
			GetOwnerComponent()->OnActionProgress(this, STEP_END);

			Server_HasStunned = true;
		}
	}
}

void UP3RoarStunAction::Multicast_Progress(int32 StepIndex)
{
	Super::Multicast_Progress(StepIndex);

	if (StepIndex == STEP_END)
	{
		const static FName SectionName = FName(TEXT("End"));

		AP3Character* Character = GetP3Character();

		if (!Character)
		{
			return;
		}

		UAnimInstance* AnimInstance = (Character->GetMesh()) ? Character->GetMesh()->GetAnimInstance() : nullptr;
		if (ensure(AnimInstance))
		{
			AnimInstance->Montage_JumpToSection(SectionName);
		}
	}
}

void UP3RoarStunAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	Server_HasStunned = false;
}

bool UP3StartItemThrowAimPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!Character || !Character->CanAiming() || Character->GetStance() == EP3CharacterStance::Combat)
	{
		return false;
	}

	return true;
}

void UP3StartItemThrowAimPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		if (!CommandComp)
		{
			return;
		}

		FP3CommandRequestParams CommandParams;
		CommandParams.SetRangedAiming_bNewAiming = true;
		CommandParams.SetRangedAiming_bChangeToCombatStance = false;
		CommandParams.SetRangedAiming_ThrowAimingItemId = Params.RequestParams.StartThrowItemAim_ThrowAimingItemId;

		CommandComp->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), CommandParams);
	}

	UAnimMontage* Montage = Character->GetAnimMontages().StartItemThrowAim;

	if (!Montage)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Montage);

	Super::Multicast_StartAction(Params);
}

bool UP3StartItemThrowAimPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::EndItemThrowAim)
	{
		return true;
	}

	return false;
}

bool UP3EndItemThrowAimPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!Character || !Character->GetCharacterStoreBP().bIsAiming)
	{
		return false;
	}

	return true;
}

void UP3EndItemThrowAimPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();

	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UAnimMontage* Montage = Character->GetAnimMontages().EndItemThrowAim;

	if (!Montage)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Montage);

	Super::Multicast_StartAction(Params);
}

bool UP3EndItemThrowAimPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::StartItemThrowAim)
	{
		return true;
	}

	return false;
}

void UP3AdaptedAttackAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (ensure(Character && Params.RequestParams.CombatAttack_Target.Actor))
		{
			TargetLocation = Params.RequestParams.CombatAttack_Target.Actor->GetActorLocation();

			// 타격점 위치
			const FVector HitLocation = GetHitLocation();

			RelativeHitLocation = Character->GetTransform().InverseTransformPosition(HitLocation);

			// 내 위치를 기준으로, 타격점의 위치
			const FVector HitOffset = HitLocation - Character->GetActorLocation();

			// 내 위치를 기준으로, 타겟의 위치
			const FVector TargetOffset = TargetLocation - Character->GetActorLocation();

			// 타격점의 방향이 타겟의 방향과 일치할 수 있게 하는 Yaw 각도를 구함
			AdaptingYawDegree = P3Core::GetYawBetweenVectors(HitOffset, TargetOffset);
			AdaptingYawDegree = FMath::RadiansToDegrees(AdaptingYawDegree);

			// 방향이 맞춰졌으므로, 거리만 보정하여 타겟 방향으로 이동하면 됨
			AdaptingMove = TargetOffset.GetSafeNormal2D() * (TargetOffset.Size() - HitOffset.Size());
		}
	}

	FAnimMontageInstance* AnimMontageInstance = GetAnimMontageInstance();

	if (AnimMontageInstance)
	{
		AnimMontageInstance->PushDisableRootMotion();

		bRootMotionDisabled = true;
	}
}

void UP3AdaptedAttackAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (CVarP3CombatUseAdaptedAttack.GetValueOnGameThread() == 0)
	{
		return;
	}

	const float AdaptSpeed = 1.0f / FMath::Max(MoveDurationSeconds, 0.01f);
	const float Progress = TickAgeSeconds * AdaptSpeed;

	if (Progress < 1.0f && bMove)
	{
		TickAgeSeconds += DeltaSeconds;

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			AP3Character* Character = GetP3Character();

			if (Character)
			{
				const float NewProgress = FMath::Min(1.0f, TickAgeSeconds * AdaptSpeed);
				const float DeltaProgress = NewProgress - Progress;

				const FRotator DeltaRotation(0, DeltaProgress * AdaptingYawDegree, 0);
				const FVector DeltaMovement = AdaptingMove * DeltaProgress;

				Character->AddActorWorldRotation(DeltaRotation);
				Character->AddActorWorldOffset(DeltaMovement);
			}
		}

#if ENABLE_DRAW_DEBUG
		if (CVarP3CombatDebug.GetValueOnGameThread() != 0)
		{
			DrawDebugSphere(GetWorld(), TargetLocation, 50.0f, 16, FColor::Red);

			AP3Character* Character = GetP3Character();

			if (Character)
			{
				DrawDebugSphere(GetWorld(), Character->GetTransform().TransformPosition(RelativeHitLocation), 50.0f, 16, FColor::Green);

				Character->AddDebugString(FString::Printf(TEXT("Adapt Progress: %.2f%%"), Progress * 100.0f));
			}
		}
#endif
	}
}

void UP3AdaptedAttackAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (bRootMotionDisabled)
	{
		FAnimMontageInstance* AnimMontageInstance = GetAnimMontageInstance();

		if (AnimMontageInstance)
		{
			AnimMontageInstance->PopDisableRootMotion();

			bRootMotionDisabled = false;
		}
	}

	TargetLocation = FVector::ZeroVector;
	AdaptingYawDegree = 0.0f;
	AdaptingMove = FVector::ZeroVector;
	TickAgeSeconds = 0.0f;
	bRootMotionDisabled = false;
	bMove = false;
	MoveDurationSeconds = 0.0f;
}

void UP3AdaptedAttackAction::OnActionAnimNotifyStateBegin(EActionAnimNotifyStateType NotifyStateType, float Duration)
{
	Super::OnActionAnimNotifyStateBegin(NotifyStateType, Duration);

	if (NotifyStateType == EActionAnimNotifyStateType::AdaptAttackMoveBegin)
	{
		ensure(!bMove);
		ensureMsgf(Duration >= 0.1f, TEXT("Adapted attack notify duration is too short"));

		bMove = true;
		MoveDurationSeconds = FMath::Max(Duration, 0.1f);
	}
}

void UP3AdaptedAttackAction::OnActionAnimNotifyStateEnd(EActionAnimNotifyStateType NotifyStateType)
{
	Super::OnActionAnimNotifyStateEnd(NotifyStateType);

	if (NotifyStateType == EActionAnimNotifyStateType::AdaptAttaackMoveEnd)
	{
		ensure(bMove);

		bMove = false;

		if (bRootMotionDisabled)
		{
			FAnimMontageInstance* AnimMontageInstance = GetAnimMontageInstance();

			if (AnimMontageInstance)
			{
				AnimMontageInstance->PopDisableRootMotion();

				bRootMotionDisabled = false;
			}
		}
	}
}

class UAnimMontage* UP3AdaptedAttackAction::GetAttackMontage(const FP3PawnActionStartRequestParams& Params) const
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		return nullptr;
	}

	AActor* AttackTargetActor = Params.CombatAttack_Target.Actor;

	if (!ensure(AttackTargetActor))
	{
		return nullptr;
	}

	UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();

	if (!ensure(CombatComp))
	{
		return nullptr;
	}

	if (!ensure(Params.CombatAttack_SkillIndex >= 0))
	{
		return nullptr;
	}

	UAnimMontage* Montage = nullptr;

	const FP3CmsCombatSkill* CmsCombatSkill = CombatComp->GetCmsCombatSkill(Params.CombatAttack_SkillIndex);
	if (CmsCombatSkill)
	{
		if (CmsCombatSkill->AdaptedAnimations.Num() > 0)
		{
			const FVector ForwardVector = Character->GetActorForwardVector().GetSafeNormal2D();
			const FVector TargetDirection = (AttackTargetActor->GetActorLocation() - Character->GetActorLocation()).GetSafeNormal2D();

			const float TargetDegree = FMath::RadiansToDegrees(P3Core::GetYawBetweenVectors(ForwardVector, TargetDirection));

			float MinDeltaDegree = 360.0f;
			int32 MinDeltaIndex = -1;

			for (int32 Index = 0; Index < CmsCombatSkill->AdaptedAnimations.Num(); ++Index)
			{
				const FP3SkillAdaptedAnimation& Anim = CmsCombatSkill->AdaptedAnimations[Index];

				const float DeltaDegree = FMath::Abs(FMath::FindDeltaAngleDegrees(TargetDegree, Anim.TargetDirectionDegree));

				if (DeltaDegree <= MinDeltaDegree)
				{
					MinDeltaDegree = DeltaDegree;
					MinDeltaIndex = Index;
				}
			}

			if (ensure(CmsCombatSkill->AdaptedAnimations.IsValidIndex(MinDeltaIndex)))
			{
				Montage = CmsCombatSkill->AdaptedAnimations[MinDeltaIndex].AnimMontage.LoadSynchronous();
			}
		}
		else
		{
			Montage = CmsCombatSkill->AnimMontage.LoadSynchronous();
		}
	}
	else
	{
		ActionJsonLog(Warning, "Invalid skill index", TEXT("SkillIndex"), Params.CombatAttack_SkillIndex);
	}

	return Montage;
}

FVector UP3AdaptedAttackAction::GetHitLocation() const
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character) || !ensure(Character->GetMesh()) || !ensure(Character->GetCharacterMovement()))
	{
		return FVector::ZeroVector;
	}

	FVector OutHitLocation = Character->GetActorLocation();

	const UAnimMontage* Montage = GetAnimMontage();

	if (!ensure(Montage))
	{
		return OutHitLocation;
	}

	// 타격 타이밍과 위치 우선 순위
	// 1. UAnimNotify_AdaptedAttackHit
	// 2. UAnimNotify_Hit 중 bUseAsAdaptedAttackHit 가 true 인 것
	// 3. UAnimNotify_Hit 중 첫 번째

	// 루트 모션
	// UAnimNotifyState_AdaptedAttackMove 가 끝나는 시점부터 타격 타이밍까지만 고려함

	const TArray<FAnimNotifyEvent>& AnimNotifyEvents = Montage->Notifies;
	UAnimNotify_AdaptedAttackHit* AdaptedHitNotfiy = nullptr;
	float HitTime = 0.0f;

	// Adapted Hit Notify 찾기 (옵션)
	for (const FAnimNotifyEvent& NotifyEvent : AnimNotifyEvents)
	{
		AdaptedHitNotfiy = Cast<UAnimNotify_AdaptedAttackHit>(NotifyEvent.Notify);

		if (AdaptedHitNotfiy)
		{
			HitTime = NotifyEvent.GetTriggerTime();
			break;
		}
	}

	// Move Notify State 와 첫 Hit Notify 찾기 (AdaptedHitNotfiy 이 존재할 경우, Hit Notify 는 찾지 않음)
	float MoveNotifyBegin = 0.0f;
	float MoveNotifyEnd = 0.0f;
	UAnimNotify_Hit* HitNotify = nullptr;

	if (!AdaptedHitNotfiy)
	{
		HitTime = 10E5f;
	}

	for (const FAnimNotifyEvent& NotifyEvent : AnimNotifyEvents)
	{
		if (!AdaptedHitNotfiy && (!HitNotify || !HitNotify->bUseAsAdaptedAttackHit))
		{
			if (UAnimNotify_Hit* ThisHitNotify = Cast<UAnimNotify_Hit>(NotifyEvent.Notify))
			{
				const float TriggerTime = NotifyEvent.GetTriggerTime();

				if (HitTime > TriggerTime || ThisHitNotify->bUseAsAdaptedAttackHit)
				{
					HitTime = TriggerTime;
					HitNotify = ThisHitNotify;
				}
			}
		}

		if (UAnimNotifyState_AdaptedAttackMove* MoveNotify = Cast<UAnimNotifyState_AdaptedAttackMove>(NotifyEvent.NotifyStateClass))
		{
			MoveNotifyBegin = NotifyEvent.GetTriggerTime();
			MoveNotifyEnd = NotifyEvent.GetEndTriggerTime();
		}
	}

	// Move notify state 가 존재해야 한다
	ensure(MoveNotifyEnd > 0.0f);
	// 타격 시점은 항상 보정 이동이 끝난 뒤에 있어야 한다
	ensure(!HitNotify || HitTime > MoveNotifyEnd);
	ensure(!AdaptedHitNotfiy || HitTime > MoveNotifyEnd);

	// 타격 위치 계산 하기
	if (ensure(HitNotify || AdaptedHitNotfiy))
	{
		const FTransform MeshTransform = Character->GetMesh()->GetComponentTransform();
		FTransform RootMotionTransform = Montage->ExtractRootMotionFromTrackRange(MoveNotifyEnd, HitTime);
		FTransform SocketTransform = FTransform::Identity;
		FName HitSocketName = AdaptedHitNotfiy ? AdaptedHitNotfiy->SocketName : HitNotify->SocketName;

		if (HitSocketName.IsNone())
		{
			SocketTransform = Character->GetMesh()->GetRelativeTransform().Inverse();
		}
		else
		{
			SocketTransform = P3Core::ExtractMontageBoneTransformFromPosition(*Character->GetMesh(), *Montage, HitTime, HitSocketName);
		}

		FTransform Transform = SocketTransform * RootMotionTransform * MeshTransform;

		if (AdaptedHitNotfiy)
		{
			OutHitLocation = Transform.TransformPosition(AdaptedHitNotfiy->Offset);
		}
		else if (HitNotify)
		{
			const FP3CmsCombatHit* CmsCombatHit = P3Cms::GetCombatHit(HitNotify->CmsCombatHitKey);

			if (!ensure(CmsCombatHit))
			{
				return OutHitLocation;
			}

			if (!CmsCombatHit->ConeRotation.IsNearlyZero())
			{
				Transform = Transform * FQuat(CmsCombatHit->ConeRotation);
			}

			OutHitLocation = Transform.TransformPosition(FVector(CmsCombatHit->AttackRange * 0.5f, 0, 0));
		}
	}
	
	return OutHitLocation;
}

bool UP3CarryingOnBackStartPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

 	if (!Params.CarryOnBack_TargetCharacter)
 	{
 		ActionJsonLog(Warning, "Cannot carry on back start. No target character");
 		return false;
	}

	const UP3PawnActionComponent* ActionComp = Params.CarryOnBack_TargetCharacter->GetActionComponent();
	if (!ActionComp)
	{
		ActionJsonLog(Warning, "Cannot carry on back start. No target ActionComponent");
		return false;
	}

	// 구조용 업기&업히기 액션은 쌍으로 동작해야 한다
	// 장차 액션간 협력을 관리하는 무언가가 생길 수도 있으나
	// 일단 여기서는 업기가 제어하는 것으로 한다
	if (!ActionComp->CanStartAction(EPawnActionType::CarriedOnBackStart))
	{
		ActionJsonLog(Warning, "Cannot carry on back start. Target character cannot start action");
		return false;
	}

	return true;
}

void UP3CarryingOnBackStartPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3CommandComponent* CommandComp = Character->GetCommandComponent();
	if (!ensure(CommandComp))
	{
		ActionJsonLog(Warning, "Cannot carry on back start. No subject CommandComponent");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	RescueTarget = Params.RequestParams.CarryOnBack_TargetCharacter;
	if (!ensure(RescueTarget))
	{
		ActionJsonLog(Warning, "Cannot carry on back start. No target character");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PawnActionComponent* TargetActionComp = RescueTarget->GetActionComponent();
	if (!ensure(TargetActionComp))
	{
		ActionJsonLog(Warning, "Cannot carry on back start. No target ActionComponent");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	// 구조 대상을 기준으로 업기 시작할 방향을 계산한다
	// : 업기 시작 위치로의 위치 보정, 재생할 모션 결정
	RescueDirection = CalcRescueDirection();

	UAnimMontage* RescuerAnimMontage = GetRescuerAnimMontage(RescueDirection);
	if (!RescuerAnimMontage)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(RescuerAnimMontage);
	Character->OnPickupAnimNotify.AddUniqueDynamic(this, &UP3CarryingOnBackStartPawnAction::OnCarryOnBackStartAnimNotify);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		FP3PawnActionStartRequestParams DerivedActionParams;
		DerivedActionParams.CarryOnBack_TargetCharacter = Character;
		DerivedActionParams.CarryOnBack_RescueDirection = RescueDirection;
		TargetActionComp->StartAction(EPawnActionType::CarriedOnBackStart, _FUNCTION_TEXT, DerivedActionParams);
	}

	Super::Multicast_StartAction(Params);
}

void UP3CarryingOnBackStartPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (!bIsMove)
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	if (TickAgeSeconds >= MoveDurationSeconds)
	{
		return;
	}

	DeltaSeconds = FMath::Min(DeltaSeconds, MoveDurationSeconds - TickAgeSeconds);
	TickAgeSeconds += DeltaSeconds;
	ensure(TickAgeSeconds <= MoveDurationSeconds);
	float Pct = DeltaSeconds / MoveDurationSeconds;
	Character->AddActorWorldOffset(RescueStartTranslation * Pct);
	Character->AddActorWorldRotation(RescueStartRotation * Pct);
}

void UP3CarryingOnBackStartPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	RescueTarget = nullptr;

	bIsMove = false;
	MoveDurationSeconds = 0.f;
	TickAgeSeconds = 0.f;
}

void UP3CarryingOnBackStartPawnAction::OnActionAnimNotifyStateBegin(EActionAnimNotifyStateType NotifyStateType, float Duration)
{
	Super::OnActionAnimNotifyStateBegin(NotifyStateType, Duration);

 	if (NotifyStateType == EActionAnimNotifyStateType::AdaptAttackMoveBegin)
 	{
 		ensure(!bIsMove);
 		ensureMsgf(Duration >= 0.1f, TEXT("Carry start notify duration is too short"));
 
		if (CalcRescuerOffset())
		{
			bIsMove = true;
			MoveDurationSeconds = FMath::Max(Duration, 0.1f);
		}
 	}
}

void UP3CarryingOnBackStartPawnAction::OnActionAnimNotifyStateEnd(EActionAnimNotifyStateType NotifyStateType)
{
	Super::OnActionAnimNotifyStateEnd(NotifyStateType);

 	if (NotifyStateType == EActionAnimNotifyStateType::AdaptAttaackMoveEnd)
 	{
 		ensure(bIsMove);
 
		bIsMove = false;
 	}
}

void UP3CarryingOnBackStartPawnAction::OnCarryOnBackStartAnimNotify()
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	Character->OnPickupAnimNotify.RemoveDynamic(this, &UP3CarryingOnBackStartPawnAction::OnCarryOnBackStartAnimNotify);

	if (!ensure(RescueTarget))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3CommandComponent* CommandComp = RescueTarget->GetCommandComponent();
		if (ensure(CommandComp))
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.Mount_Detach = false;
			CommandParams.Mount_TargetCharacter = Character;
			CommandParams.Mount_TargetMountPointIndex = 0;
			CommandParams.Mount_bRescuing = true;
			CommandComp->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
		}
	}
}

EP3RescueDirection UP3CarryingOnBackStartPawnAction::CalcRescueDirection() const
{
	// 구조자의 RescuerSocket 에 가장 가까운 구조 대상의 TargetSocket 을 찾는다
	// 이 소켓의 이름에서 방향을 얻는다

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		ActionJsonLog(Log, "Calc rescue direction failed");
		return EP3RescueDirection::None;
	}

	const USkeletalMeshComponent* Mesh = Character->GetMesh();
	if (!ensure(Mesh))
	{
		ActionJsonLog(Log, "Calc rescue direction failed");
		return EP3RescueDirection::None;
	}

	if (!Mesh->DoesSocketExist(RescuerSocketName))
	{
		ActionJsonLog(Log, "Calc rescue direction failed");
		return EP3RescueDirection::None;
	}

	if (!ensure(RescueTarget))
	{
		ActionJsonLog(Log, "Calc rescue direction failed");
		return EP3RescueDirection::None;
	}

	const USkeletalMeshComponent* TargetMesh = RescueTarget->GetMesh();
	if (!TargetMesh)
	{
		ActionJsonLog(Log, "Calc rescue direction failed");
		return EP3RescueDirection::None;
	}

	FVector RescuerLocation = Mesh->GetSocketLocation(RescuerSocketName);
	FString TargetSocketNameStr = TEXT("");
	float RescuerTargetDist = 10E5;
	for (const FName& SocketName : TargetMesh->GetAllSocketNames())
	{
		FString SocketNameStr = SocketName.ToString();
		if (!SocketNameStr.StartsWith(FindTargetSocketNameStr))
		{
			continue;
		}

		float Dist = FVector::Distance(TargetMesh->GetSocketLocation(SocketName), RescuerLocation);
		if (Dist < RescuerTargetDist)
		{
			TargetSocketNameStr = SocketNameStr;
			RescuerTargetDist = Dist;
		}
	}

	if (TargetSocketNameStr.IsEmpty())
	{
		ActionJsonLog(Log, "Calc rescue direction failed");
		return EP3RescueDirection::None;
	}

	EP3RescueDirection OutRescueDirection = GetRescueDirection(TargetSocketNameStr);

	ActionJsonLog(Log, "Calc rescue direction",
		TEXT("DirStr"), *TargetSocketNameStr,
		TEXT("Dir"), EnumToStringShort(EP3RescueDirection, OutRescueDirection));

	return OutRescueDirection;
}

FString UP3CarryingOnBackStartPawnAction::GetTargetSocketName(EP3RescueDirection InRescueDirection) const
{
	return FindTargetSocketNameStr + EnumToStringShort(EP3RescueDirection, InRescueDirection);
}

EP3RescueDirection UP3CarryingOnBackStartPawnAction::GetRescueDirection(FString& TargetSocketNameStr) const
{
	FString RescueDirectionStr = TargetSocketNameStr.Replace(*FindTargetSocketNameStr, TEXT(""));
	if (RescueDirectionStr == TEXT("Left"))
	{
		return EP3RescueDirection::Left;
	}
	else if (RescueDirectionStr == TEXT("Right"))
	{
	 	return EP3RescueDirection::Right;
	}
	else if (RescueDirectionStr == TEXT("Front"))
	{
		return EP3RescueDirection::Front;
	}
	else if (RescueDirectionStr == TEXT("Rear"))
	{
		return EP3RescueDirection::Rear;
	}
	else
	{
		return EP3RescueDirection::None;
	}
}

UAnimMontage* UP3CarryingOnBackStartPawnAction::GetRescuerAnimMontage(EP3RescueDirection InRescueDirection) const
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return nullptr;
	}

	if (InRescueDirection == EP3RescueDirection::None)
	{
		InRescueDirection = EP3RescueDirection::Left;
	}

	if (!Character->GetAnimMontages().CarryingOnBackStarts.Contains(InRescueDirection))
	{
		return nullptr;
	}

	return Character->GetAnimMontages().CarryingOnBackStarts[InRescueDirection];
}

bool UP3CarryingOnBackStartPawnAction::CalcRescuerOffset()
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	const USkeletalMeshComponent* Mesh = Character->GetMesh();
	if (!ensure(Mesh))
	{
		return false;
	}

	if (!Mesh->DoesSocketExist(RescuerSocketName))
	{
		return false;
	}

	if (!ensure(RescueTarget))
	{
		return false;
	}

	const USkeletalMeshComponent* TargetMesh = RescueTarget->GetMesh();
	if (!TargetMesh)
	{
		return false;
	}

	FTransform RescuerTransform = Mesh->GetSocketTransform(RescuerSocketName);
	FName TargetSocketName = *GetTargetSocketName(RescueDirection);
	FTransform TargetTransform = TargetMesh->GetSocketTransform(TargetSocketName);

	RescueStartTranslation = TargetTransform.GetTranslation() - RescuerTransform.GetTranslation();
	RescueStartRotation = TargetTransform.Rotator() - RescuerTransform.Rotator();

	return true;
}

bool UP3CarriedOnBackStartPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!Params.CarryOnBack_TargetCharacter)
	{
		ActionJsonLog(Warning, "Cannot carry on back start. No rescuer character");
		return false;
	}

	return true;
}

void UP3CarriedOnBackStartPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	Rescuer = Params.RequestParams.CarryOnBack_TargetCharacter;
	if (!ensure(Rescuer))
	{
		ActionJsonLog(Warning, "Cannot carry on back start. No rescuer character");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UAnimMontage* RescueTargetAnimMontage = GetRescueTargetAnimMontage(Params.RequestParams.CarryOnBack_RescueDirection);
	if (!RescueTargetAnimMontage)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(RescueTargetAnimMontage);

	Super::Multicast_StartAction(Params);
}

bool UP3CarriedOnBackStartPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::CombatReactionHit,
	});

	return InterruptableActionTypes.Contains(OtherActionType);
}

void UP3CarriedOnBackStartPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	Rescuer = nullptr;
}

UAnimMontage* UP3CarriedOnBackStartPawnAction::GetRescueTargetAnimMontage(EP3RescueDirection RescueDirection) const
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return nullptr;
	}

	if (RescueDirection == EP3RescueDirection::None)
	{
		RescueDirection = EP3RescueDirection::Left;
	}

	if (!Character->GetAnimMontages().CarriedOnBackStarts.Contains(RescueDirection))
	{
		return nullptr;
	}

	return Character->GetAnimMontages().CarriedOnBackStarts[RescueDirection];
}

// DYLEE TODO CarryOnBack(Start|End) 업기 시작/종료 액션 중복 구현이 대부분인데, 정리하면 좋을 것
bool UP3CarryingOnBackEndPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	if (Character->GetCharacterStoreBP().MountRiderCharacters.Num() == 0)
	{
		ActionJsonLog(Warning, "Cannot carry on back end. No rider");
		return false;
	}

	const AP3Character* RescueTargetCandidate = Character->GetCharacterStoreBP().MountRiderCharacters[0];
	if (!RescueTargetCandidate)
	{
		ActionJsonLog(Warning, "Cannot carry on back end. No rider");
		return false;
	}

	const UP3PawnActionComponent* ActionComp = RescueTargetCandidate->GetActionComponent();
	if (!ActionComp)
	{
		ActionJsonLog(Warning, "Cannot carry on back end. No target ActionComponent");
		return false;
	}

	if (!ActionComp->CanStartAction(EPawnActionType::CarriedOnBackEnd))
	{
		ActionJsonLog(Warning, "Cannot carry on back end. Target character cannot start action");
		return false;
	}

	return true;
}

void UP3CarryingOnBackEndPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!Character->GetAnimMontages().CarryingOnBackEnd)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(Character->GetCharacterStoreBP().MountRiderCharacters.Num() != 0))
	{
		ActionJsonLog(Warning, "Cannot carry on back end. No rider");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	RescueTarget = Character->GetCharacterStoreBP().MountRiderCharacters[0];
	if (!ensure(RescueTarget))
	{
		ActionJsonLog(Warning, "Cannot carry on back end. No target character");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PawnActionComponent* TargetActionComp = RescueTarget->GetActionComponent();
	if (!ensure(TargetActionComp))
	{
		ActionJsonLog(Warning, "Cannot carry on back end. No target ActionComponent");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().CarryingOnBackEnd);
	Character->OnPickupAnimNotify.AddUniqueDynamic(this, &UP3CarryingOnBackEndPawnAction::OnCarryOnBackEndAnimNotify);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		FP3PawnActionStartRequestParams DerivedActionParams;
		DerivedActionParams.CarryOnBack_TargetCharacter = Character;
		TargetActionComp->StartAction(EPawnActionType::CarriedOnBackEnd, _FUNCTION_TEXT, DerivedActionParams);
	}

	Super::Multicast_StartAction(Params);
}

void UP3CarryingOnBackEndPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	RescueTarget = nullptr;
}

void UP3CarryingOnBackEndPawnAction::OnCarryOnBackEndAnimNotify()
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	Character->OnPickupAnimNotify.RemoveDynamic(this, &UP3CarryingOnBackEndPawnAction::OnCarryOnBackEndAnimNotify);

	if (!ensure(RescueTarget))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3CommandComponent* CommandComp = RescueTarget->GetCommandComponent();
		if (ensure(CommandComp))
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.Mount_Detach = true;
			CommandComp->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
		}
	}
}

bool UP3CarriedOnBackEndPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	const FP3CharacterStore& CharacterStore = Character->GetCharacterStoreBP();

	if (!CharacterStore.MountTargetCharacter)
	{
		return false;
	}

	if (!CharacterStore.bMountingByRescuer)
	{
		return false;
	}

	return true;
}

void UP3CarriedOnBackEndPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!Character->GetAnimMontages().CarriedOnBackEnd)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	const AP3Character* Rescuer = Character->GetCharacterStoreBP().MountTargetCharacter;
	if (!Rescuer)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	SetAnimMontage(Character->GetAnimMontages().CarriedOnBackEnd);

	Super::Multicast_StartAction(Params);
}

