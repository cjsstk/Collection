// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PickupAction.h"

#include "Components/CapsuleComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "DestructibleComponent.h"
#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "GameFramework/Controller.h"
#include "Kismet/GameplayStatics.h"

#include "Action/P3PawnActionComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "GameMode/P3ContributionSystem.h"
#include "Item/P3ItemActor.h"
#include "Item/P3ItemManager.h"
#include "Network/P3WorldNet.h"
#include "P3Backpack.h"
#include "P3Character.h"
#include "P3ConsumableComponent.h"
#include "P3Destructible.h"
#include "P3CharacterHealthPointComponent.h"
#include "P3Combat.h"
#include "P3GameInstance.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3IngredientComponent.h"
#include "P3InteractableComponent.h"
#include "P3InventoryComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3PickupComponent.h"
#include "P3PickupableComponent.h"
#include "P3Physics.h"
#include "P3PlayerController.h"
#include "P3ServerWorld.h"
#include "P3Spear.h"
#include "P3StaminaPointComponent.h"
#include "P3SwitchActor.h"
#include "P3Tags.h"
#include "P3World.h"

extern TAutoConsoleVariable<int32> CVarP3PickupDebug;

static TAutoConsoleVariable<float> CVarP3ThrowPawnCollisionCoolTimeSecondsDebug(
    TEXT("p3.throwPawnCollisionCoolTimeSeconds"),
	0.3,
    TEXT("Object's collision response against pawn will be disabled during this time after throw"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3UseConsumableSpeedMultiplier(
    TEXT("p3.useConsumableSpeedMultiplier"),
    0.5f,
    TEXT("Move speed multiplier while using a consumable"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3PickupUseInterpolation(
	TEXT("p3.pickupUseInterpolation"),
	1,
	TEXT("If set 1, object will snap to hand using interpolation"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3PickupZOffset(
	TEXT("p3.pickupZOffset"),
	-20.0f,
	TEXT("Temporal offset due to socket position not matching hands"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ThrowVelocityMultiplierForMiddle(
	TEXT("p3.throwVelocityMultiplierForMiddle"),
	0.7f,
	TEXT("Throw velocity multiplier when backpack weight is middle"), ECVF_Cheat);


UP3PickupPawnAction::UP3PickupPawnAction()
	: bInInterpolatedAttaching(false)
	, bAttached(false)
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3PickupPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!ensure(Params.Pickup_ObjectActor))
	{
		return false;
	}

	UP3PickupableComponent* PickupableComponent = Params.Pickup_ObjectActor->FindComponentByClass<UP3PickupableComponent>();
	if (!PickupableComponent)
	{
		return false;
	}

	if (PickupableComponent->GetPickupableType() != EP3PickupableType::Spear && Params.Pickup_ObjectActor->GetAttachParentActor())
	{
		return false;
	}

	if (PickupableComponent->IsPickupToInventory())
	{
		UClass* ItemActorClass = Params.Pickup_ObjectActor->GetClass();
		itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
		if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
		{
			P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
			return false;
		}
	}

	if (P3Core::IsP3NetModeServerInstance(*this) && PickupableComponent->Server_IsInteractionLocked())
	{
		return false;
	}

	return true;
}

bool UP3PickupPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::UseConsumable,
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3PickupPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	TargetActor = Params.RequestParams.Pickup_ObjectActor;
	AttachSocketName = Params.RequestParams.Pickup_AttachSocketName;
	AttachOffset = FVector::ZeroVector;
	bInInterpolatedAttaching = false;
	bAttached = false;

	if (!ensure(TargetActor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(GetOwnerComponent()) || !ensure(GetOwnerComponent()->GetOwner()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
	if (!PickupableComp)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetActor->SetReplicateMovement(false);

	bIsPickupToInventory = PickupableComp->IsPickupToInventory();
	PickupableType = PickupableComp->GetPickupableType();
	bDoNotRotate = PickupableComp->IsDoNotRotateDuringPickup();

	UStaticMeshComponent* StaticMeshComp = TargetActor->FindComponentByClass<UStaticMeshComponent>();
	if (PickupableType == EP3PickupableType::Harvest
		|| (StaticMeshComp && StaticMeshComp->DoesSocketExist(FName("PickupPoint"))))
	{
		bDoNotRotate = false;
	}

	if (PickupableType == EP3PickupableType::Spear && TargetActor->GetAttachParentActor())
	{
		TargetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	}

	if (bIsPickupToInventory)
	{
		UClass* ItemActorClass = TargetActor->GetClass();
		TargetItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
		if (!ensure(TargetItemCmsKey != INVALID_ITEMKEY))
		{
			P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		bServer_Pickedup = false;
		PickupableComp->Server_SetInteractionLock(this, true);
		PickupableComp->Server_PickupStarted.Broadcast(PickupableComp, Character);
	}

	// Rotate character to face target
	// NOTE: maybe Autonomous should turn earlier at pre-start, to avoid conflict with movement-sync
	const FVector DirToTarget = TargetActor->GetActorLocation() - GetOwnerComponent()->GetOwner()->GetActorLocation();
	GetOwnerComponent()->GetOwner()->SetActorRotation(FQuat::FindBetween(FVector(1, 0, 0), DirToTarget.GetSafeNormal2D()));

	Character->OnPickupAnimNotify.AddUniqueDynamic(this, &UP3PickupPawnAction::OnPickupAnimNotify);

	UAnimMontage* Montage = Character->GetAnimMontages().Pickup;

	if (PickupableType == EP3PickupableType::Harvest)
	{
		// TODO: we don't have any flags to see if this object is planted(require harvest) or just placed(require pickup) for now.
		// So, I just use physics as flag
		if (TargetActor->GetRootComponent() && TargetActor->GetRootComponent()->IsAnySimulatingPhysics())
		{
			Montage = Character->GetAnimMontages().PickupHarvestable;
		}
		else
		{
			Montage = Character->GetAnimMontages().Harvest;
		}
	}
	else if (PickupableType == EP3PickupableType::Spear || PickupableType == EP3PickupableType::Item || bIsPickupToInventory)
	{
		Montage = Character->GetAnimMontages().PickupHodableFromGround;
	}

	SetAnimMontage(Montage);

	const bool bPlayed = PlayAnimMontage();
	if (!bPlayed)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!bIsPickupToInventory)
	{
		PickupableComp->DisablePhysicsForPickup();
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();
	if (PickupComp)
	{
		PickupComp->OnPickupActionStarted(TargetActor);
	}
}

FVector UP3PickupPawnAction::GetTargetLocation() const
{
	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		AActor* OwnerActor = GetOwnerActor();

		if (OwnerActor)
		{
			return OwnerActor->GetActorLocation();
		}
		else
		{
			return FVector::ZeroVector;
		}
	}

	if (!ensure(TargetActor))
	{
		return Character->GetActorLocation();
	}

	FVector TargetLocation = FVector::ZeroVector;

	UStaticMeshComponent* StaticMeshComp = TargetActor->FindComponentByClass<UStaticMeshComponent>();
	if (StaticMeshComp && StaticMeshComp->DoesSocketExist(FName("PickupPoint")))
	{
		ensure(!bDoNotRotate);

		TargetLocation = Character->GetMesh()->GetSocketLocation(AttachSocketName);
		TargetLocation += StaticMeshComp->GetSocketTransform(FName("PickupPoint"), ERelativeTransformSpace::RTS_Actor).GetTranslation();
		TargetActor->SetActorRelativeRotation(FRotator(0, 0, 90));
	}
	else
	{
		if (bDoNotRotate)
		{
			TargetLocation = Character->GetMesh()->GetSocketTransform(AttachSocketName).GetTranslation() + AttachOffset;
		}
		else
		{
			TargetLocation = Character->GetMesh()->GetSocketTransform(AttachSocketName).TransformPosition(AttachOffset);
		}
	}

	return TargetLocation;
}

void UP3PickupPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (GetActionServerStatus() != EP3PawnActionStatus::InProgress)
	{
		// TargetActor is only valid after multicast start
		return;
	}

	if (!TargetActor)
	{
		if (GetActionLocalStatus() != EP3PawnActionStatus::Finished)
		{
			P3JsonLog(Warning, "Pickup action failed. No target");
			Finish(EP3PawnActionResult::Failed);
		}
		return;
	}

	if (bInInterpolatedAttaching)
	{
		AP3Character* Character = GetP3Character();

		if (Character && Character->GetMesh())
		{
			const FVector CurrentLocation = TargetActor->GetActorLocation();
			FVector TargetLocation = GetTargetLocation();

			const float DistanceSquared = (TargetLocation - CurrentLocation).SizeSquared();
			if (DistanceSquared < 1)
			{
				bInInterpolatedAttaching = false;
				TargetActor->SetActorLocation(TargetLocation);
			}
			else
			{
				const float Alpha = FMath::Clamp(DeltaSeconds * 10.0f, 0.05f, 0.5f);
				const FVector NewLocation = FMath::Lerp(CurrentLocation, TargetLocation, Alpha);
				TargetActor->SetActorLocation(NewLocation);
			}

#if ENABLE_DRAW_DEBUG
			if (CVarP3PickupDebug.GetValueOnGameThread() != 0)
			{
				DrawDebugPoint(GetWorld(), CurrentLocation, 10.0f, FColor::Green, false, -1.0f, 1);
				DrawDebugPoint(GetWorld(), TargetLocation, 10.0f, FColor::Red, false, -1.0f, 1);

				DrawDebugDirectionalArrow(GetWorld(), Character->GetMesh()->GetSocketTransform(AttachSocketName).GetLocation(), TargetLocation, 20.0f, FColor::Red, false, -1.0f, 0, 3.0f);
			}
#endif
		}
	}
	else if (bAttached)
	{
		TargetActor->SetActorLocation(GetTargetLocation());
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3PickupDebug.GetValueOnGameThread() != 0)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

		if (Character && Character->GetMesh())
		{
			DrawDebugPoint(GetWorld(), Character->GetMesh()->GetSocketTransform(AttachSocketName).GetLocation(), 5.0f, FColor::White, false, -1.0f, 1);

			DrawDebugPoint(GetWorld(), TargetActor->GetActorLocation(), 5.0f, FColor::Green, false, -1.0f, 1);
		}
	}
#endif
}

void UP3PickupPawnAction::FinishToIdle()
{
	const bool bIsBothResultSuccess = GetActionLocalResult() == EP3PawnActionResult::Success && GetActionServerResult() == EP3PawnActionResult::Success;

	if (bIsBothResultSuccess)
	{
		if (bInInterpolatedAttaching)
		{
			AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
			if (Character && Character->GetMesh() && TargetActor)
			{
				FVector TargetLocation = GetTargetLocation();

				TargetActor->SetActorLocation(TargetLocation);
			}

			bInInterpolatedAttaching = false;
		}

		if (bIsPickupToInventory)
		{
			OnPickupAnimNotify();
		}
		else
		{
			if (PickupableType != EP3PickupableType::Harvest)
			{
				ChangeCharacterStance(EP3CharacterStance::Pickup);
			}

			if (bDoNotRotate && bAttached && TargetActor && TargetActor->GetRootComponent())
			{
				const FTransform WorldTransform = TargetActor->GetRootComponent()->GetComponentTransform();
				TargetActor->GetRootComponent()->SetAbsolute(false, false, true);
				TargetActor->GetRootComponent()->SetWorldTransform(WorldTransform);
			}
		}
	}
	else
	{
		// Not success, lets revert everything we did in this action
		if (TargetActor && bAttached)
		{
			TargetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		}

		ChangeCharacterStance(EP3CharacterStance::Idle);
	}

	AP3Character* Character = GetP3Character();
	UP3PickupComponent* PickupComp = Character ? Character->GetPickupComponent() : nullptr;

	if (PickupComp)
	{
		PickupComp->OnPickupActionFinished(bIsBothResultSuccess, TargetActor);
	}


	if (Character)
	{
		Character->OnPickupAnimNotify.RemoveDynamic(this, &UP3PickupPawnAction::OnPickupAnimNotify);
	}

	if (P3Core::IsP3NetModeServerInstance(*this) && TargetActor)
	{
		UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
		if (PickupableComp && PickupableComp->Server_IsInteractionLocked())
		{
			PickupableComp->Server_SetInteractionLock(this, false);
		}

		bServer_Pickedup = false;
	}

	if (TargetActor)
	{
		TargetActor->SetReplicateMovement(true);
	}

	TargetActor = nullptr;
	TargetItemCmsKey = INVALID_ITEMKEY;
	PickupableType = EP3PickupableType::None;
	AttachSocketName = FName();
	AttachOffset = FVector::ZeroVector;
	bInInterpolatedAttaching = false;
	bAttached = false;
	bIsPickupToInventory = false;

	Super::FinishToIdle();
}

void UP3PickupPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::Pickup)
	{
		OnPickupAnimNotify();
	}
	else if (NotifyType == EActionAnimNotifyType::Harvest)
	{
		OnPickupAnimNotify();
	}
	else if (NotifyType == EActionAnimNotifyType::PutIntoBag)
	{
		if (P3Core::IsP3NetModeServerInstance(*this) && TargetActor)
		{
			Server_PutIntoBag();
		}
	}
}

void UP3PickupPawnAction::OnPickupAnimNotify()
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character) || !ensure(Character->GetMesh()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(TargetActor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (TargetActor->GetAttachParentActor() && TargetActor->GetAttachParentActor() != Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3WorldNetBase* WorldNet = nullptr;

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	if (bIsPickupToInventory)
	{
		if (P3Core::IsP3NetModeServerInstance(*Character))
		{
			if (!bServer_Pickedup)
			{
				bServer_Pickedup = true;

				UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
				if (!ensure(InvenComp))
				{
					Finish(EP3PawnActionResult::Failed);
					return;
				}

				if (!InvenComp->CanAddItem(TargetItemCmsKey, TargetItemAmount))
				{
					FText ErrorMessage = P3LOC_ITEM("CannotOwnThisItem");
					P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);
					Finish(EP3PawnActionResult::Failed);
					return;
				}

				TargetActor->Destroy();

				InvenComp->Server_AddItemByKeyAndCount(TargetItemCmsKey, TargetItemAmount);
			}
		}
	}
	else
	{
		const FTransform SocketTransform = Character->GetMesh()->GetSocketTransform(AttachSocketName);

		if (bDoNotRotate && TargetActor->GetRootComponent())
		{
			TargetActor->GetRootComponent()->SetAbsolute(true, true, true);
		}

		if (PickupableType == EP3PickupableType::Spear)
		{
			TargetActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, AttachSocketName);

			ChangeCharacterStance(EP3CharacterStance::Pickup);
		}
		else if (PickupableType == EP3PickupableType::Harvest)
		{
			TargetActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, AttachSocketName);
		}
		else
		{
			UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());
			if (!ensure(PrimComp))
			{
				Finish(EP3PawnActionResult::Failed);
				return;
			}

			{
				// Rotate character towards object
				const FVector Direction = TargetActor->GetActorLocation() - GetOwnerComponent()->GetOwner()->GetActorLocation();

				GetOwnerComponent()->GetOwner()->SetActorRotation(FQuat::FindBetween(FVector(1, 0, 0), Direction.GetSafeNormal2D()));
			}

			if (bAttachAtCenterBottom)
			{
				const FBox BoundBox = PrimComp->Bounds.GetBox();
				const FVector BoundCenter = BoundBox.GetCenter();
				const FVector AttachLocation = FVector(BoundCenter.X, BoundCenter.Y, BoundBox.Min.Z);

				AttachOffset = TargetActor->GetActorLocation() - AttachLocation;

				// Try little bit harder to perfectly stick to hands
				const FTransform RightHandTransform = Character->GetMesh()->GetSocketTransform(FName(TEXT("Bip01-R-Hand")));
				const FTransform LeftHandTransform = Character->GetMesh()->GetSocketTransform(FName(TEXT("Bip01-L-Hand")));

				const FVector RightHandOffset = RightHandTransform.GetLocation() - SocketTransform.GetLocation();
				const FVector LeftHandOffset = LeftHandTransform.GetLocation() - SocketTransform.GetLocation();

				FCollisionQueryParams CollisionQueryParams;
				FHitResult RightHandHitResult, LeftHandHitResult;

				const FVector RightLineStart = AttachLocation + RightHandOffset;
				const bool bFoundRightHandLineTracePoint = PrimComp->LineTraceComponent(RightHandHitResult, RightLineStart, BoundCenter, CollisionQueryParams);

				const FVector LeftLineStart = AttachLocation + LeftHandOffset;
				const bool bFoundLeftHandLineTracePoint = PrimComp->LineTraceComponent(LeftHandHitResult, LeftLineStart, BoundCenter, CollisionQueryParams);

				if (bFoundRightHandLineTracePoint && bFoundLeftHandLineTracePoint)
				{
					const FVector HandToCenter = (BoundCenter - ((RightLineStart + LeftLineStart) * 0.5f)).GetSafeNormal();
					const float Distance = (RightHandHitResult.Distance + LeftHandHitResult.Distance) * 0.5f;

					AttachOffset -= Distance * HandToCenter;

#if ENABLE_DRAW_DEBUG
					if (CVarP3PickupDebug.GetValueOnGameThread() != 0)
					{
						DrawDebugLine(GetWorld(), RightLineStart, RightHandHitResult.ImpactPoint, FColor::Green, false, 5.0f, 0, 3.0f);

						DrawDebugLine(GetWorld(), LeftLineStart, LeftHandHitResult.ImpactPoint, FColor::Green, false, 5.0f, 0, 3.0f);
					}
#endif
				}

				AttachOffset += FVector(0, 0, CVarP3PickupZOffset.GetValueOnGameThread());
			}
			else
			{
				const FVector TargetBoundCenter = PrimComp->Bounds.GetBox().GetCenter();

				FHitResult HitResult;
				FCollisionQueryParams CollisionQueryParams;

				const FVector TraceStart = SocketTransform.GetLocation();
				const FVector TraceEnd = TargetBoundCenter;

				const bool bFoundLineTracePoint = PrimComp->LineTraceComponent(HitResult, TraceStart, TraceEnd, CollisionQueryParams);

#if ENABLE_DRAW_DEBUG
				if (CVarP3PickupDebug.GetValueOnGameThread() != 0)
				{
					DrawDebugPoint(GetWorld(), TargetBoundCenter, 10.0f, FColor::Black, false, 5.0f);

					if (bFoundLineTracePoint)
					{
						DrawDebugPoint(GetWorld(), HitResult.Location, 10.0f, FColor::Yellow, false, 5.0f);

						DrawDebugDirectionalArrow(GetWorld(), TraceStart, TraceEnd, 20.0f, FColor::Green, false, 5.0f, 0, 3.0f);
					}
					else
					{
						DrawDebugDirectionalArrow(GetWorld(), TraceStart, TraceEnd, 20.0f, FColor::Red, false, 5.0f, 0, 3.0f);
					}
				}
#endif

				if (bFoundLineTracePoint)
				{
					AttachOffset = TargetActor->GetActorLocation() - HitResult.Location;

					// Try little bit harder to perfectly stick to hands
					const FTransform RightHandTransform = Character->GetMesh()->GetSocketTransform(FName(TEXT("Bip01-R-Hand")));
					const FTransform LeftHandTransform = Character->GetMesh()->GetSocketTransform(FName(TEXT("Bip01-L-Hand")));

					const FVector RightHandOffset = RightHandTransform.GetLocation() - SocketTransform.GetLocation();
					const FVector LeftHandOffset = LeftHandTransform.GetLocation() - SocketTransform.GetLocation();

					FHitResult RightHandHitResult, LeftHandHitResult;

					const FVector RightLineStart = HitResult.Location + RightHandOffset;
					const bool bFoundRightHandLineTracePoint = PrimComp->LineTraceComponent(RightHandHitResult, RightLineStart, TargetBoundCenter, CollisionQueryParams);

					const FVector LeftLineStart = HitResult.Location + LeftHandOffset;
					const bool bFoundLeftHandLineTracePoint = PrimComp->LineTraceComponent(LeftHandHitResult, LeftLineStart, TargetBoundCenter, CollisionQueryParams);

					if (bFoundRightHandLineTracePoint && bFoundLeftHandLineTracePoint)
					{
						const float Distance = (RightHandHitResult.Distance + LeftHandHitResult.Distance) * 0.5f;

						AttachOffset -= Distance * (AttachOffset.GetSafeNormal());
					}
				}
				else
				{
					// Fall back to bounding box approach
					FVector TargetBoudingSphereCenter(ForceInitToZero);
					float TargetBoundingSphereRadius(0);
					P3Core::GetActorSphereBounds(*TargetActor, TargetBoudingSphereCenter, TargetBoundingSphereRadius);

					const FVector ObjectCenterToSocket = SocketTransform.GetLocation() - TargetBoudingSphereCenter;
					const FVector BoundEdge = TargetBoudingSphereCenter + (ObjectCenterToSocket.GetSafeNormal() * TargetBoundingSphereRadius);
					const FVector HitOffset = TargetActor->GetActorLocation() - BoundEdge;

#if ENABLE_DRAW_DEBUG
					if (CVarP3PickupDebug.GetValueOnGameThread() != 0)
					{
						DrawDebugPoint(GetWorld(), BoundEdge, 10.0f, FColor::Black, false, 5.0f);
						DrawDebugSphere(GetWorld(), TargetBoudingSphereCenter, TargetBoundingSphereRadius, 24, FColor::Black, false, 5.0f);
					}
#endif
					AttachOffset = HitOffset;
				}
			}

			TargetActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::KeepWorldTransform, AttachSocketName);

			ChangeCharacterStance(EP3CharacterStance::Pickup);
		}

		if (!bDoNotRotate)
		{
			AttachOffset = SocketTransform.InverseTransformVector(AttachOffset);
		}
	}



	if (CVarP3PickupUseInterpolation.GetValueOnGameThread() == 0)
	{
		const FVector TargetLocation = GetTargetLocation();

		TargetActor->SetActorLocation(TargetLocation);
	}
	else
	{
		bInInterpolatedAttaching = true;
	}

	bAttached = true;
}

void UP3PickupPawnAction::Server_PutIntoBag()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);
	if (!ensure(WorldNet))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	// TODO: Want to check in CanStart
	UClass* ItemActorClass = TargetActor->GetClass();
	itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
	if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!InvenComp->CanAddItem(ItemCmsKey, TargetItemAmount))
	{
		FText ErrorMessage = P3LOC_ITEM("CannotOwnThisItem");
		P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetActor->Destroy();

	InvenComp->Server_AddItemByKeyAndCount(ItemCmsKey, TargetItemAmount);
}

UP3PutdownPawnAction::UP3PutdownPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3PutdownPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!GetOwnerComponent() || !GetOwnerComponent()->GetOwner())
	{
		return false;
	}

	UP3PickupComponent* PickupComp = GetOwnerComponent()->GetOwner()->FindComponentByClass<UP3PickupComponent>();
	if (!ensure(PickupComp))
	{
		return false;
	}

	if (!ensure(PickupComp->GetPickuppedActor()))
	{
		return false;
	}

	return true;
}

void UP3PutdownPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();

	if (!ensure(Character) || !ensure(Character->GetMesh()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PickupComponent* PickupComp = GetOwnerComponent()->GetOwner()->FindComponentByClass<UP3PickupComponent>();
	if (!ensure(PickupComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetActor = PickupComp->GetPickuppedActor();
	if (!ensure(TargetActor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
	const bool bIsSpear = (PickupableComp && PickupableComp->GetPickupableType() == EP3PickupableType::Spear);
	if (bIsSpear)
	{
		// TODO: We don't have putdown animation for spear, so we just drop it for now
		PickupComp->OnPutdownActionFinished();
		Finish(EP3PawnActionResult::Success);
		return;
	}

	AttachSocketName = Params.RequestParams.Putdown_AttachSocketName;
	ensure(!AttachSocketName.IsNone());
	
	bDoNotRotate = PickupableComp && PickupableComp->IsDoNotRotateDuringPickup();

	if (bDoNotRotate)
	{
		const FTransform SocketTransform = Character->GetMesh()->GetSocketTransform(AttachSocketName);

		AttachedRelativeTransform = TargetActor->GetActorTransform();
		AttachedRelativeTransform.SetTranslation(TargetActor->GetActorLocation() - SocketTransform.GetTranslation());
	}
	else
	{
		AttachedRelativeTransform = TargetActor->GetRootComponent()->GetRelativeTransform();
	}


	SetAnimMontage(Character->GetAnimMontages().Putdown);

	const bool bPlayed = PlayAnimMontage();

	if (!bPlayed)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	ensure(TargetActor->GetRootComponent() && TargetActor->GetRootComponent()->GetAttachParent());
	TargetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());
	if (PrimComp)
	{
		if (ensure(PickupableComp))
		{
			PickupableComp->RestorePhysicsForPutdown(Character);
		}

		if (IsAuthority(GetOwnerComponent()->GetOwner()))
		{
			AP3Destructible* Destructible = Cast<AP3Destructible>(TargetActor);
			if (Destructible)
			{
				Destructible->Server_SetPOIOriginLocation(GetOwnerComponent()->GetOwner()->GetActorLocation());
			}
		}
	}
	
	Character->MoveIgnoreActorAdd(TargetActor);
}

void UP3PutdownPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (!TargetActor)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (!bAbortMoveObjectToHand && !bPutdownAnimNotified)
		{
			const float Alpha = 1.0f;//FMath::Clamp(DeltaSeconds * 10.0f, 0.01f, 0.1f);
			const FVector CurrentLocation = TargetActor->GetActorLocation();
			const FTransform SocketTransform = Character->GetMesh()->GetSocketTransform(AttachSocketName);

			FTransform TargetTransform;
			
			if (bDoNotRotate)
			{
				TargetTransform = AttachedRelativeTransform;
				TargetTransform.AddToTranslation(SocketTransform.GetTranslation());
			}
			else
			{
				TargetTransform = AttachedRelativeTransform * SocketTransform;
			}

			const float DistanceSquared = (TargetTransform.GetLocation() - CurrentLocation).SizeSquared();
			if (DistanceSquared < 200 * 200)
			{
				FTransform NewTransform;
				NewTransform.Blend(TargetActor->GetTransform(), TargetTransform, Alpha);

				FHitResult HitResult;
				TargetActor->SetActorTransform(NewTransform, true, &HitResult);

#if ENABLE_DRAW_DEBUG
				if (CVarP3PickupDebug.GetValueOnGameThread() != 0 && P3Core::IsP3NetModeServerInstance(*this))
				{
					P3Core::GetP3World(*this)->GetServerWorld()->SendDebugDrawSphere(NewTransform.GetLocation(), 10.0f, FColor::Green, 5.0f);
				}
#endif
			}
			else
			{
				bAbortMoveObjectToHand = true;
			}
		}
	}
}

void UP3PutdownPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = GetP3Character();

	if (Result == EP3PawnActionResult::Success && Character && TargetActor && bPutdownAnimNotified)
	{
		// If object is still overlapping with character, push it away
		// Otherwise character will get hit by once it's physics is restored at Finish()
		UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());
		if (PrimComp)
		{
			const float SweepDistance = 100.0f;
			const FVector SweepDir = Character->GetActorForwardVector();

			FCollisionShape Shape;
			Shape.SetCapsule(Character->GetCapsuleComponent()->GetScaledCapsuleRadius(), Character->GetCapsuleComponent()->GetScaledCapsuleHalfHeight());
			FHitResult HitResult;
			const bool bHit = PrimComp->SweepComponent(HitResult, Character->GetActorLocation() + (SweepDir * -SweepDistance), Character->GetActorLocation(), Character->GetActorQuat(), Shape);

			if (bHit)
			{
				TargetActor->AddActorWorldOffset(SweepDir * (SweepDistance - HitResult.Distance), true);
			}
		}
	}

	if (TargetActor)
	{
		UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
		if (ensure(PickupableComp))
		{
			PickupableComp->RestorePhysicsAfterPutdown();
		}
		else
		{
			// TODO: temporal workaround before every consumable have pickupable
			UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());
			if (PrimComp)
			{
				PrimComp->SetSimulatePhysics(true);
			}
		}
	}

	if (Character && TargetActor)
	{
		Character->MoveIgnoreActorRemove(TargetActor);
	}

	if (Result == EP3PawnActionResult::Success)
	{
		UP3PickupComponent* PickupComp = GetOwnerComponent()->GetOwner()->FindComponentByClass<UP3PickupComponent>();
		if (PickupComp)
		{
			PickupComp->OnPutdownActionFinished();
		}
	}

	ChangeCharacterStance(EP3CharacterStance::Idle);

	AttachSocketName = FName();
	AttachedRelativeTransform.SetIdentity();
	TargetActor = nullptr;
	bPutdownAnimNotified = false;
	bAbortMoveObjectToHand = false;
}

void UP3PutdownPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::Putdown)
	{
		bPutdownAnimNotified = true;

		ChangeCharacterStance(EP3CharacterStance::Idle);
	}
}

UP3ThrowPawnAction::UP3ThrowPawnAction()
{
	/** Work around: To avoid error when Throw inventory item in succession */
	//SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_CannotStartIfAnyMontageIsPlaying);
}

bool UP3ThrowPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!GetOwnerComponent() || !GetOwnerComponent()->GetOwner())
	{
		return false;
	}

	UP3PickupComponent* PickupComp = GetOwnerComponent()->GetOwner()->FindComponentByClass<UP3PickupComponent>();
	if (!ensure(PickupComp))
	{
		return false;
	}

	if (!ensure(PickupComp->GetPickuppedActor()))
	{
		return false;
	}

	return true;
}

void UP3ThrowPawnAction::Server_FillAuthorityStartParams(const FP3PawnActionStartRequestParams& RequestParams, FP3PawnActionStartAuthorityParams& OutParams) const
{
	Super::Server_FillAuthorityStartParams(RequestParams, OutParams);
	
	if (GetOwnerComponent() && GetOwnerComponent()->GetOwner())
	{
		UP3PickupComponent* PickupComp = GetOwnerComponent()->GetOwner()->FindComponentByClass<UP3PickupComponent>();
		if (ensure(PickupComp))
		{
			OutParams.Throw_WorldVelocity = PickupComp->GetThrowVelocity();
		}
	}
}

void UP3ThrowPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PickupComponent* PickupComp = Character->FindComponentByClass<UP3PickupComponent>();

	if (!ensure(PickupComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetActor = PickupComp->GetPickuppedActor();

	if (!ensure(TargetActor) || !ensure(!TargetActor->IsActorBeingDestroyed()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();

	const bool bIsSpear = (PickupableComp && PickupableComp->GetPickupableType() == EP3PickupableType::Spear);

	ThrowWorldVelocity = Params.RequestParams.Throw_Rotator.RotateVector(Params.AuthorityParams.Throw_WorldVelocity);

	ensure(!ThrowWorldVelocity.ContainsNaN());
	ensure(!bThrown);

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (InvenComp && InvenComp->IsCarryingBackpack())
	{
		EP3BackpackWeight BackpackWeight = InvenComp->GetBackpackWeight();
		ThrowWorldVelocity *= BackpackWeight >= EP3BackpackWeight::Middle ? CVarP3ThrowVelocityMultiplierForMiddle.GetValueOnGameThread() : 1.0f;
	}

	FRotator CharacterRotation = Params.RequestParams.Throw_Rotator;
	CharacterRotation.Pitch = 0.f;
	CharacterRotation.Yaw = FRotator::NormalizeAxis(CharacterRotation.Yaw);
	CharacterRotation.Roll = 0.f;

	Character->SetActorRotation(CharacterRotation);
	Character->OnThrowAnimNotify.AddUniqueDynamic(this, &UP3ThrowPawnAction::OnThrowAnimNotify);

	if (bIsSpear)
	{
		SetAnimMontage(Character->GetAnimMontages().ThrowJavelin);
	}
	else if (!PickupableComp
		|| PickupableComp->GetPickupableType() == EP3PickupableType::ElementFragment
		|| PickupableComp->GetPickupableType() == EP3PickupableType::Item)
	{
		SetAnimMontage(Character->GetAnimMontages().ThrowOneHand);
	}
	else
	{
		SetAnimMontage(Character->GetAnimMontages().Throw);
	}

	ChangeCharacterStance(EP3CharacterStance::Idle);

	Super::Multicast_StartAction(Params);
}

void UP3ThrowPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (bThrown)
	{
		ThrownAge += DeltaSeconds;

		if (ThrownAge > CVarP3ThrowPawnCollisionCoolTimeSecondsDebug.GetValueOnGameThread())
		{
			// It must gone far away, we can turn collision back on
			if (bPawnCollisionOffed)
			{
				UPrimitiveComponent* PrimComp = TargetActor ? Cast<UPrimitiveComponent>(TargetActor->GetRootComponent()) : nullptr;

				if (PrimComp)
				{
					// #Throw_PawnCollisionToggle
					PrimComp->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
				}

				bPawnCollisionOffed = false;
			}
		}
	}
}

bool UP3ThrowPawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	if (OtherActionType == EPawnActionType::StartItemThrowAim)
	{
		return true;
	}

	return false;
}

void UP3ThrowPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());

	if (Character)
	{
		Character->OnThrowAnimNotify.RemoveDynamic(this, &UP3ThrowPawnAction::OnThrowAnimNotify);
	}

	if (bPawnCollisionOffed)
	{
		UPrimitiveComponent* PrimComp = TargetActor ? Cast<UPrimitiveComponent>(TargetActor->GetRootComponent()) : nullptr;

		if (PrimComp)
		{
			// #Throw_PawnCollisionToggle
			PrimComp->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
		}
	}

	if (!bThrown && TargetActor)
	{
		TargetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

		UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());

		if (PrimComp)
		{
			UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
			if (PickupableComp)
			{
				PickupableComp->RestorePhysicsAfterPutdown();
			}
			else
			{
				PrimComp->SetSimulatePhysics(true);
			}
		}
	}

	UP3PickupComponent* PickupComp = Character->FindComponentByClass<UP3PickupComponent>();
	if (ensure(PickupComp))
	{
		PickupComp->OnThrowActionFinished();
	}

	ChangeCharacterStance(EP3CharacterStance::Idle);

	TargetActor = nullptr;
	ThrowWorldVelocity = FVector::ZeroVector;
	bThrown = false;
	ThrownAge = 0;
	bPawnCollisionOffed = false;
}

void UP3ThrowPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::Throw)
	{
		OnThrowAnimNotify();
	}
}

void UP3ThrowPawnAction::OnThrowAnimNotify()
{
	if (!GetOwnerComponent() || !GetOwnerComponent()->GetOwner())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3PickupComponent* PickupComp = GetOwnerComponent()->GetOwner()->FindComponentByClass<UP3PickupComponent>();
	if (!ensure(PickupComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(TargetActor) || !ensure(!TargetActor->IsActorBeingDestroyed()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	// TODO-FIXME: This must be done only from server, otherwise if one side fails, final status will be different

	TargetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	TargetActor->Instigator = GetP3Character();

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(TargetActor->GetRootComponent());

	if (PrimComp)
	{
		UP3PickupableComponent* PickupableComp = TargetActor->FindComponentByClass<UP3PickupableComponent>();
		if (PickupableComp)
		{
			PickupableComp->RestorePhysicsAfterPutdown();
		}
		else
		{
			PrimComp->SetSimulatePhysics(true);
		}

		AP3ItemActor* ItemActor = Cast<AP3ItemActor>(TargetActor);
		if (ItemActor && GetP3Character())
		{
			ItemActor->DisablePawnCollisionUntilLeaveCharacter(*GetP3Character());
		}

		const bool bIsSpear = PickupableComp && (PickupableComp->GetPickupableType() == EP3PickupableType::Spear);

		// Make fly!
		const FVector Velocity = bIsSpear ? ThrowWorldVelocity * 2 : ThrowWorldVelocity;
		PrimComp->SetPhysicsLinearVelocity(Velocity);
		PrimComp->SetPhysicsAngularVelocityInDegrees(FVector::ZeroVector);

		if (bIsSpear)
		{
			PrimComp->SetWorldRotation(Velocity.Rotation());
		}

		// TODO: Prepare for multiple Primitive component
		// Object is still overlapped with character, lets turn collision off for a while
		// This will be reverted at Finish
		// #Throw_PawnCollisionToggle
		//if (PrimComp->GetCollisionResponseToChannel(ECC_Pawn) == ECR_Block)
		//{
		//	PrimComp->SetCollisionResponseToChannel(ECC_Pawn, ECR_Ignore);
		//	bPawnCollisionOffed = true;
		//}

		if (IsAuthority(GetOwnerComponent()->GetOwner()))
		{
			AP3Destructible* Destructible = Cast<AP3Destructible>(TargetActor);
			if (Destructible)
			{
				Destructible->Server_SetPOIOriginLocation(GetOwnerComponent()->GetOwner()->GetActorLocation());
			}
		}
	}

	PickupComp->OnThrowActionFinished();

	bThrown = true;
}

UP3PickupHoldablePawnAction::UP3PickupHoldablePawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3PickupHoldablePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!ensure(Params.PickupHoldable_ObjectActor))
	{
		return false;
	}

	if (!ensure(Params.PickupHoldable_HolderType != EP3HoldType::Count))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	if (!ensure(Character->GetHolderComponentByHoldType(Params.PickupHoldable_HolderType)))
	{
		return false;
	}

	if (!ensure(Params.PickupHoldable_ObjectActor.Actor))
	{
		return false;
	}

	UClass* ItemActorClass = Params.PickupHoldable_ObjectActor.Actor->GetClass();
	itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
	if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
		return false;
	}

	const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(ItemCmsKey);

	if (!ensure(CmsHoldable))
	{
		return false;
	}

	if (IsTempWeapon(CmsHoldable->WeaponType))
	{
		// You can only have 1 temp weapon
		UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();

		if (InventoryComp && InventoryComp->HasTempWeapon())
		{
			return false;
		}
	}

	UP3HoldableComponent* HoldableComp = Params.PickupHoldable_ObjectActor.Actor->FindComponentByClass<UP3HoldableComponent>();

	if (!ensure(HoldableComp))
	{
		return false;
	}

	if (P3Core::IsP3NetModeServerInstance(*this) && HoldableComp->Server_IsInteractionLocked())
	{
		return false;
	}

	return true;
}

bool UP3PickupHoldablePawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::UseConsumable,
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3PickupHoldablePawnAction::Server_FillAuthorityStartParams(const FP3PawnActionStartRequestParams& RequestParams, FP3PawnActionStartAuthorityParams& OutParams) const
{
	Super::Server_FillAuthorityStartParams(RequestParams, OutParams);

	const AActor* ItemActor = RequestParams.PickupHoldable_ObjectActor.Actor;
	if (!ensure(ItemActor))
	{
		return;
	}

	// TODO: Holdable actor(Weapon Actor) must have had FItem already before here.
	const itemkey ItemKey = P3Cms::GetItemKeyFromActorClass(ItemActor->GetClass());
	if (!ensure(ItemKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Error, "Failed to get item key", TEXT("ItemActor"), *ItemActor->GetName());
		return;
	}

	UP3ItemManager* ItemManager = P3Core::GetItemManager(*this);
	if (ensure(ItemManager))
	{
		const FP3Item Item = ItemManager->CreateItem(ItemKey, 1, "PickupHoldablePawnAction");

		if (ensure(Item.IsValid()))
		{
			OutParams.PickupHoldable_ObjectItem = Item;
		}
	};
}

void UP3PickupHoldablePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetItem = Params.AuthorityParams.PickupHoldable_ObjectItem;
	TargetActor = Params.RequestParams.PickupHoldable_ObjectActor.Actor;
	CharacterItemSlot = FP3ItemUtil::GetCharacterItemSlotFromHoldType(Params.RequestParams.PickupHoldable_HolderType);
	HolderComponent = Character->GetHolderComponentByHoldType(Params.RequestParams.PickupHoldable_HolderType);
	bHolded = false;

	if (!ensure(TargetItem.IsValid()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(TargetActor) || !ensure(CharacterItemSlot != EP3CharacterItemSlot::Invalid) || !ensure(HolderComponent))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(GetOwnerComponent()) || !ensure(GetOwnerComponent()->GetOwner()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3HoldableComponent* HoldableComp = TargetActor->FindComponentByClass<UP3HoldableComponent>();
		if (!HoldableComp)
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
		HoldableComp->Server_SetInteractionLock(this, true);
	}

	// NOTE: maybe Autonomous should turn earlier at pre-start, to avoid conflict with movement-sync
	const FVector Direction = TargetActor->GetActorLocation() - GetOwnerComponent()->GetOwner()->GetActorLocation();
	GetOwnerComponent()->GetOwner()->SetActorRotation(FQuat::FindBetween(FVector(1, 0, 0), Direction.GetSafeNormal2D()));

	SetAnimMontage(Character->GetAnimMontages().PickupHodableFromGround);

	const bool bPlayed = PlayAnimMontage();
	if (!bPlayed)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
}

void UP3PickupHoldablePawnAction::TickAction(float DeltaSeconds)
{

}

void UP3PickupHoldablePawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (Result != EP3PawnActionResult::Failed)
	{
		Hold();
	}

	if (P3Core::IsP3NetModeServerInstance(*this) && TargetActor)
	{
		UP3HoldableComponent* HoldableComp = TargetActor->FindComponentByClass<UP3HoldableComponent>();
		if (HoldableComp && HoldableComp->Server_IsInteractionLocked())
		{
			HoldableComp->Server_SetInteractionLock(this, false);
		}
	}

	TargetItem = FP3Item::InvalidItem;
	TargetActor = nullptr;
	HolderComponent = nullptr;
	bHolded = false;
}

void UP3PickupHoldablePawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::Pickup)
	{
		Hold();
	}
}

void UP3PickupHoldablePawnAction::Hold()
{
	if (bHolded)
	{
		return;
	}

	bHolded = true;

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(TargetActor) || !ensure(HolderComponent))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3WorldNetBase* WorldNet = nullptr;
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	if (HolderComponent->GetHoldingActor())
	{
		// Remove from holder
		AActor* OldHoldingActor = Character->RemoveHoldingActorByAction(*this, HolderComponent);
		int32 OldHoldingActorItemKey = INVALID_ITEMKEY;

		if (P3Core::IsP3NetModeServerInstance(*this) && Character->IsPlayerControlled())
		{
			// Prepare item
			const FP3Item ItemToInven = InvenComp->GetItemBySlot(CharacterItemSlot);
			OldHoldingActorItemKey = ItemToInven.Key;
			ensure(ItemToInven.IsValid());

			if (ensure(OldHoldingActor))
			{
				OldHoldingActor->Destroy();
			}

			// Write to DB
			WorldNet->SendUpdateCharacterItemSlot(Character->GetCharacterStoreBP().CharacterId, ItemToInven.Id, EP3CharacterItemSlot::Inventory); //-V522

			// Update slot in inventory
			InvenComp->Server_ChangeItemSlot(ItemToInven.Id, EP3CharacterItemSlot::Inventory);

			// Weapon ID to recover
			HolderComponent->Server_SetRecoveryAfterTempWeaponItem(ItemToInven);
		}

		// Remove from other holder
		const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(OldHoldingActorItemKey);
		if (CmsHoldable)
		{
			EP3WeaponType OldHoldingWeaponType = CmsHoldable->WeaponType;
			EP3HoldType OtherHoldType = (HolderComponent->GetHoldType() == EP3HoldType::LeftHand) ? EP3HoldType::RightHand : EP3HoldType::LeftHand;
			const FP3Item OtherHandItem = InvenComp->GetItemBySlot(FP3ItemUtil::GetCharacterItemSlotFromHoldType(OtherHoldType));
			const FP3CmsHoldable* OtherHandCmsHoldable = P3Cms::GetItemHoldable(OtherHandItem.Key);

			if (OtherHandCmsHoldable && OtherHandCmsHoldable->WeaponType == OldHoldingWeaponType)
			{
				UP3HolderComponent* OtherHolderComp = Character->GetHolderComponentByHoldType(OtherHoldType);

				// Remove from holder
				AActor* OldOtherHoldingActor = Character->RemoveHoldingActorByAction(*this, OtherHolderComp);

				if (P3Core::IsP3NetModeServerInstance(*this) && Character->IsPlayerControlled())
				{
					// Prepare item
					EP3CharacterItemSlot CharacterOtherItemSlot = FP3ItemUtil::GetCharacterItemSlotFromHoldType(OtherHoldType);
					const FP3Item OtherItemToInven = InvenComp->GetItemBySlot(CharacterOtherItemSlot);

					if (OldOtherHoldingActor)
					{
						OldOtherHoldingActor->Destroy();
					}

					// Write to DB
					WorldNet->SendUpdateCharacterItemSlot(Character->GetCharacterStoreBP().CharacterId, OtherItemToInven.Id, EP3CharacterItemSlot::Inventory); //-V522

					// Update slot in inventory
					InvenComp->Server_ChangeItemSlot(OtherItemToInven.Id, EP3CharacterItemSlot::Inventory);

					// Weapon ID to recover
					OtherHolderComp->Server_SetRecoveryAfterTempWeaponItem(OtherItemToInven);
				}
			}
		}
	}

	// Hold item
	Character->SetHoldingActorByAction(this, HolderComponent, TargetActor, true);

	if (P3Core::IsP3NetModeServerInstance(*this) && Character->IsPlayerControlled())
	{
		// Add to inventory
		InvenComp->Server_AddItem(TargetItem, CharacterItemSlot);
	}

	ChangeCharacterStance(EP3CharacterStance::Combat);

	if (Character->GetCharacterStoreBP().bIsAiming)
	{
		const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(TargetItem.Key);
		if (ensure(CmsHoldable))
		{
			if (!IsRangedWeapon(CmsHoldable->WeaponType))
			{
				Character->SetAimingByAction(*this, false);
			}
		}
	}
}

bool UP3PutdownHoldablePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!ensure(Params.PutdownHoldable_ObjectActor))
	{
		return false;
	}

	if (!ensure(GetOwnerComponent()) || !ensure(GetOwnerComponent()->GetOwner()))
	{
		return false;
	}

	UP3HolderComponent* HolderComp = P3Core::GetActorComponentByName<UP3HolderComponent>(*GetOwnerComponent()->GetOwner(), Params.PutdownHoldable_HolderComponentName);

	if (!ensure(HolderComp))
	{
		return false;
	}

	if (!ensure(HolderComp->GetOwner() == GetOwnerComponent()->GetOwner()))
	{
		return false;
	}

	if (!ensure(HolderComp->GetHoldingActor() == Params.PutdownHoldable_ObjectActor.Actor))
	{
		return false;
	}

	return true;
}

void UP3PutdownHoldablePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3HolderComponent* HolderComp = P3Core::GetActorComponentByName<UP3HolderComponent>(*GetOwnerComponent()->GetOwner(), Params.RequestParams.PutdownHoldable_HolderComponentName);
	if (!ensure(HolderComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(HolderComp->GetHoldingActor() == Params.RequestParams.PutdownHoldable_ObjectActor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3WorldNetBase* WorldNet = nullptr;
	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	if (!IsTempWeapon(Character->GetRightHandWeaponType()))
	{
		// Prepare item
		const EP3CharacterItemSlot Slot = FP3ItemUtil::GetCharacterItemSlotFromHoldType(HolderComp->GetHoldType());
		const FP3Item Item = InvenComp->GetItemBySlot(Slot);

		// Remove from holder
		Character->RemoveHoldingActorByAction(*this, HolderComp);

		if (P3Core::IsP3NetModeServerInstance(*Character))
		{
			// Remove from inventory
			InvenComp->Server_RemoveItem(Item.Id);
		}
	}
	else
	{
		if (P3Core::IsP3NetModeServerInstance(*Character))
		{
			Server_RecoveryAfterTempWeapon();
		}		
	}

	ChangeCharacterStance(EP3CharacterStance::Idle);

	Finish(EP3PawnActionResult::Success);
}

UP3PickupConsumablePawnAction::UP3PickupConsumablePawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3PickupConsumablePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!ensure(Params.PickupConsumable_ObjectActor))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();

	if (!ensure(Character))
	{
		return false;
	}

	if (!ensure(Params.PickupConsumable_ObjectActor.IsValidIdOrReplicated()))
	{
		return false;
	}

	if (!Params.PickupConsumable_ObjectActor.Actor)
	{
		return false;
	}

	UClass* ItemActorClass = Params.PickupConsumable_ObjectActor.Actor->GetClass();
	itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
	if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
		return false;
	}

	UP3ConsumableComponent* ConsumableComp = Params.PickupConsumable_ObjectActor.Actor->FindComponentByClass<UP3ConsumableComponent>();

	if (!ensure(ConsumableComp))
	{
		return false;
	}

	if (P3Core::IsP3NetModeServerInstance(*this) && ConsumableComp->Server_IsInteractionLocked())
	{
		return false;
	}

	return true;
}

bool UP3PickupConsumablePawnAction::CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const
{
	if (Super::CanForceFinishOtherAction(OtherActionType, OtherActionAgeSeconds, Params))
	{
		return true;
	}

	const TArray<EPawnActionType> InterruptableActionTypes({
		EPawnActionType::UseConsumable,
		});

	const bool bInList = InterruptableActionTypes.Contains(OtherActionType);

	return bInList;
}

void UP3PickupConsumablePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetActor = Params.RequestParams.PickupConsumable_ObjectActor.Actor;
	if (!TargetActor)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UClass* ItemActorClass = TargetActor->GetClass();
	TargetItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
	if (!ensure(TargetItemCmsKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(GetOwnerComponent()) || !ensure(GetOwnerComponent()->GetOwner()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3ConsumableComponent* ConsumableComp = TargetActor->FindComponentByClass<UP3ConsumableComponent>();
		if (!ConsumableComp)
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
		ConsumableComp->Server_SetInteractionLock(this, true);

		bServer_Pickedup = false;
	}

	// NOTE: maybe Autonomous should turn earlier at pre-start, to avoid conflict with movement-sync
	const FVector Direction = TargetActor->GetActorLocation() - GetOwnerComponent()->GetOwner()->GetActorLocation();
	GetOwnerComponent()->GetOwner()->SetActorRotation(FQuat::FindBetween(FVector(1, 0, 0), Direction.GetSafeNormal2D()));

	SetAnimMontage(Character->GetAnimMontages().PickupHodableFromGround);

	const bool bPlayed = PlayAnimMontage();
	if (!bPlayed)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
}

void UP3PickupConsumablePawnAction::TickAction(float DeltaSeconds)
{
}

void UP3PickupConsumablePawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (Result != EP3PawnActionResult::Failed)
		{
			Server_Pickup();
		}
	
		if (TargetActor)
		{
			UP3ConsumableComponent* ConsumableComp = TargetActor->FindComponentByClass<UP3ConsumableComponent>();
			if (ConsumableComp && ConsumableComp->Server_IsInteractionLocked())
			{
				ConsumableComp->Server_SetInteractionLock(this, false);
			}
		}

		bServer_Pickedup = false;
	}

	TargetActor = nullptr;
	TargetItemCmsKey = INVALID_ITEMKEY;
}

void UP3PickupConsumablePawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::Pickup)
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			Server_Pickup();
		}
	}
}

void UP3PickupConsumablePawnAction::Server_Pickup()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (bServer_Pickedup)
	{
		return;
	}

	bServer_Pickedup = true;

	AP3Character* Character = Cast<AP3Character>(GetOwnerComponent()->GetOwner());
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!ensure(TargetActor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);
	if (!ensure(WorldNet))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!InvenComp->CanAddItem(TargetItemCmsKey, TargetItemAmount))
	{
		FText ErrorMessage = P3LOC_ITEM("CannotOwnThisItem");
		P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	TargetActor->Destroy();

	InvenComp->Server_AddItemByKeyAndCount(TargetItemCmsKey, TargetItemAmount);
}

UP3UseConsumablePawnAction::UP3UseConsumablePawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3UseConsumablePawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	switch (Character->GetCharacterStoreBP().Stance)
	{
	case EP3CharacterStance::Idle:
	case EP3CharacterStance::Combat:
		// Ok
		break;
	default:
		return false;
	}

	if (Character->IsGliding())
	{
		return false;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return false;
	}

	if (!InventoryComp->HasConsumable(Params.UseConsumable_ItemId))
	{
		return false;
	}

	return true;
}

void UP3UseConsumablePawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	ConsumableItemId = Params.RequestParams.UseConsumable_ItemId;
	if (!ensure(ConsumableItemId != INVALID_ITEMID))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	const FP3Item Item = InventoryComp->GetItem(ConsumableItemId);
	if (!ensure(Item.IsValid()))
	{
		return;
	}

	CmsConsumable = *P3Cms::GetItemConsumable(Item.Key);
	if (CmsConsumable.ItemKey == INVALID_ITEMKEY)
	{
		return;
	}

	bAllowMoveInputDuringConsumeAction = CmsConsumable.bAllowMoveInputDuringConsumeAction;

	switch (CmsConsumable.AnimType)
	{
	case EP3ConsumableAnimType::Drink:
		if (Character->IsClimbing())
		{
			SetAnimMontage(Character->GetAnimMontages().UsePotionDuringClimbing);
		}
		else
		{
			SetAnimMontage(Character->GetAnimMontages().UsePotion);
		}
		break;
	case EP3ConsumableAnimType::BlowShofar:
		SetAnimMontage(Character->GetAnimMontages().BlowShofar);
		break;
	case EP3ConsumableAnimType::SkewerEat:
		SetAnimMontage(Character->GetAnimMontages().SkewerEat);
		break;
	case EP3ConsumableAnimType::PutDownForUseItem:
		SetAnimMontage(Character->GetAnimMontages().PutDownForUseItem);
		break;
	case EP3ConsumableAnimType::SetUpBomb:
		SetAnimMontage(Character->GetAnimMontages().SetUpBomb);
		break;
	case EP3ConsumableAnimType::EquipElemental:
		SetAnimMontage(Character->GetAnimMontages().EquipElemental);
		break;
	default:
		ensure(0);
		break;
	}

	const bool bPlayed = PlayAnimMontage();
	if (!bPlayed)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (CmsConsumable.AnimType == EP3ConsumableAnimType::EquipElemental)
	{
		if (Character->GetCharacterStoreBP().Stance == EP3CharacterStance::Idle)
		{
			ChangeCharacterStance(EP3CharacterStance::Combat);
		}
	}
	else if (Character->GetCharacterStoreBP().Stance == EP3CharacterStance::Combat)
	{
		ChangeCharacterStance(EP3CharacterStance::Idle);
	}

	/** Show using item only client */
	if (P3Core::IsP3NetModeClient(*Character))
	{
		if (Params.RequestParams.UseConsumable_bHoldItemOnConsume)
		{
			Client_bDestoryHoldingItemOnUseNotify = Params.RequestParams.UseConsumable_bDestoryHoldingItemOnUseNotify;

			const FP3CmsItem& CmsItem = P3Cms::GetItem(Item.Key);
			if (!ensure(!CmsItem.ItemActorClass.IsNull()))
			{
				return;
			}

			FActorSpawnParameters SpawnParams;
			SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			SpawnedActorOnHold = GetWorld()->SpawnActor<AActor>(CmsItem.ItemActorClass.LoadSynchronous(), SpawnParams);
			if (ensure(SpawnedActorOnHold))
			{
				TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
				SpawnedActorOnHold->GetComponents(PrimComps);

				for (UPrimitiveComponent* PrimComp : PrimComps)
				{
					PrimComp->SetSimulatePhysics(false);
					PrimComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
					PrimComp->SetCollisionResponseToAllChannels(ECR_Ignore);
				}

				/** Find socket */
				UP3PickupComponent* PickupComp = Character->GetPickupComponent();
				if (!ensure(PickupComp))
				{
					return;
				}

				EP3PickupableType PickupableType = EP3PickupableType::Harvest;

				UP3PickupableComponent* PickupableComp = SpawnedActorOnHold->FindComponentByClass<UP3PickupableComponent>();
				if (PickupableComp)
				{
					PickupableComp->DisablePhysicsForPickup();
					PickupableType = PickupableComp->GetPickupableType();
				}

				const FName SocketName = PickupComp->GetAttachSocketName(PickupableType);

				SpawnedActorOnHold->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, SocketName);
			}
		}
	}
}

void UP3UseConsumablePawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (GetActionLocalStatus() == EP3PawnActionStatus::Finished)
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (Character->IsGliding())
	{
		Finish(EP3PawnActionResult::Failed);
	}
}

bool UP3UseConsumablePawnAction::IsIgnoreMoveInput() const 
{ 
	AP3Character* Character = GetP3Character();
	return (Character && Character->IsClimbing()) || !bAllowMoveInputDuringConsumeAction;
}

float UP3UseConsumablePawnAction::GetMoveSpeedMultiplier() const
{
	return CVarP3UseConsumableSpeedMultiplier.GetValueOnGameThread();
}

void UP3UseConsumablePawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (SpawnedActorOnHold)
	{
		SpawnedActorOnHold->Destroy();
		SpawnedActorOnHold = nullptr;
	}

	ConsumableItemId = INVALID_ITEMID;
}

void UP3UseConsumablePawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType != EActionAnimNotifyType::UseItem)
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	UP3HealthPointComponent* HealthPointComp = Character->GetP3HealthComponentBP();
	if (!ensure(HealthPointComp))
	{
		return;
	}

	UP3StaminaPointComponent* StaminaPointComp = Character->GetStaminaComponent();
	if (!ensure(StaminaPointComp))
	{
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return;
	}

	UP3WorldNetBase* WorldNet = nullptr;
	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			return;
		}
	}

	if (GIsClient)
	{
		const bool bAffectToHealth = (CmsConsumable.HealAmount > 0);
		const bool bAffectToStamina = (CmsConsumable.MaxStaminaAmount > 0);
		const bool bPlayHealEffect = (bAffectToHealth || bAffectToStamina);

		if (bPlayHealEffect)
		{
			UGameplayStatics::SpawnEmitterAttached(CmsConsumable.HealEffectParticle, Character->GetRootComponent());
		}

		if (Client_bDestoryHoldingItemOnUseNotify)
		{
			if (SpawnedActorOnHold)
			{
				SpawnedActorOnHold->Destroy();
				SpawnedActorOnHold = nullptr;
			}
		}
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		bool bFailedToUse = false;

		if (CmsConsumable.HealAmount > 0)
		{
			P3Contribution::Server_AddPoint(Character, EP3ContributionType::HealByConsumption, CmsConsumable.HealAmount);

			P3Combat::ChangeActorHealth(Character, *HealthPointComp, CmsConsumable.HealAmount, EP3HealthChangeReason::Consumable);
		}
		
		if (CmsConsumable.MaxStaminaAmount > 0)
		{
			const int32 NewMaxStaminaPoint = StaminaPointComp->GetMaxStaminaPoint() + CmsConsumable.MaxStaminaAmount;
			StaminaPointComp->SetMaxStaminaPoint(NewMaxStaminaPoint);
		}

		if (CmsConsumable.SpawnActorClass.Get())
		{
			FTransform SpawnTransform = Character->GetActorTransform();
			const FVector SpawnOffset2D(CmsConsumable.SpawnActorOffset.X, CmsConsumable.SpawnActorOffset.Y, 100);
			const FVector RayStart = SpawnTransform.TransformPosition(SpawnOffset2D);
			const FVector RayEnd = RayStart + SpawnTransform.TransformVector(FVector(0, 0, -300));

			FHitResult HitResult;
			const bool bHit = GetWorld()->LineTraceSingleByChannel(HitResult, RayStart, RayEnd, ECC_Pawn);
			
			if (bHit)
			{
				// Do not allow spawned object on spawned object (stacking)
				const AActor* HittedActor = HitResult.GetActor();
				const bool bStacking = HittedActor && HittedActor->Tags.Contains(P3Tags::SpawendByConsumable);

				if (bStacking)
				{
					bFailedToUse = true;

					FText ErrorMessage = P3LOC_ITEM("CannotSpawnOnSpawnedItem");
					P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);

				}
				else
				{
					SpawnTransform.SetLocation(HitResult.Location + FVector(0, 0, CmsConsumable.SpawnActorOffset.Z));

					FActorSpawnParameters SpawnParams;
					SpawnParams.Instigator = Character;
					SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
					AActor* SpawnedActor = GetWorld()->SpawnActor<AActor>(CmsConsumable.SpawnActorClass.Get(), SpawnTransform, SpawnParams);
					if (ensure(SpawnedActor))
					{
						SpawnedActor->Tags.Add(P3Tags::SpawendByConsumable);
						SpawnedActor->Instigator = Character;
					}
				}
			}
			else
			{
				bFailedToUse = true;

				FText ErrorMessage = P3LOC_ITEM("CannotSpawnHere");
				P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);
			}
		}

		if (CmsConsumable.AttachFlagActorClass.Get())
		{
			if (Character->GetCharacterStoreBP().FlagActor)
			{
				Character->Server_DetachFlag();
			}
			else
			{
				Character->Server_AttachFlag(CmsConsumable.AttachFlagActorClass.Get());
			}
		}

		if (CmsConsumable.BuffKey != INVALID_BUFFKEY)
		{
			UP3CharacterEffectComponent* EffectComp = Character->GetEffectComponent();

			if (EffectComp)
			{
#if !UE_BUILD_SHIPPING
				// Since there is no way to turn this buff off for now, it must has expire duration
				const FP3CmsCharacterBuffRow* CmsBuff = P3Cms::GetCharacterBuff(CmsConsumable.BuffKey);
				ensureMsgf(CmsBuff&& CmsBuff->BuffDuration > 0.0f, TEXT("Buff from item must has limited duration. Consumable Item Key: %d"), CmsConsumable.ItemKey);
#endif
				EffectComp->Server_AddBuff(CmsConsumable.BuffKey, this);
			}
		}

		if (!bFailedToUse)
		{
			InventoryComp->Server_RemoveItemByIdAndCount(ConsumableItemId, 1);
		}
	}
}

bool UP3SwitchingPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!ensure(Params.Switching_SwitchActor.IsValidIdOrReplicated()))
	{
		return false;
	}

	return true;
}

void UP3SwitchingPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	if (!ensure(Params.RequestParams.Switching_SwitchActor.IsValidIdOrReplicated()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3SwitchActor* SwitchActor = Cast<AP3SwitchActor>(Params.RequestParams.Switching_SwitchActor.Actor);

	if (!ensure(SwitchActor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*SwitchActor))
	{
		SwitchActor->Server_ToggleSwitch(Params.RequestParams.Switching_bOn);
	}

	Finish(EP3PawnActionResult::Success);
}

UP3InteractPawnAction::UP3InteractPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3InteractPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!ensure(Params.Interact_InteracteeActor.Actor))
	{
		return false;
	}

	UP3InteractableComponent* Comp = Params.Interact_InteracteeActor.Actor->FindComponentByClass<UP3InteractableComponent>();

	if (!ensure(Comp) || !Comp->IsInteractionAllowed())
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	if (Character->IsPickuped())
	{
		return false;
	}

	return true;
}

void UP3InteractPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	if (!ensure(Params.RequestParams.Interact_InteracteeActor.Actor))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InteractableComponent* InteractableComp = Params.RequestParams.Interact_InteracteeActor.Actor->FindComponentByClass<UP3InteractableComponent>();
	if (!ensure(InteractableComp) || !InteractableComp->IsInteractionAllowed())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (!Character->GetAnimMontages().Interaction || Character->IsClimbing() || !InteractableComp->IsPlayInteractionAnimation())
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			if (!InteractableComp->Server_OnInteract(GetOwnerActor()))
			{
				Finish(EP3PawnActionResult::Failed);
				return;
			}
		}

		Finish(EP3PawnActionResult::Success);
		return;
	}

	UP3LootingInteractableComponent* LootingInteractableComp = Cast<UP3LootingInteractableComponent>(InteractableComp);
	if (LootingInteractableComp)
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			bSuccessLooting = LootingInteractableComp->Server_PickLootItem();
		}

		switch (LootingInteractableComp->GetLootingInteractableType())
		{
		case EP3LootingInteractableType::Collect:
			SetAnimMontage(Character->GetAnimMontages().Collect);
			break;
		case EP3LootingInteractableType::Extract:
		{
			SetAnimMontage(Character->GetAnimMontages().Extract);

			TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
			Params.RequestParams.Interact_InteracteeActor.Actor->GetComponents(PrimComps);

			for (UPrimitiveComponent* PrimComp : PrimComps)
			{
				SavedCollisionEnabled.Add(PrimComp, PrimComp->GetCollisionEnabled());
				SavedCollisionResponse.Add(PrimComp, PrimComp->GetCollisionResponseToChannels());

				if (PrimComp == Params.RequestParams.Interact_InteracteeActor.Actor->GetRootComponent())
				{
					PrimComp->SetSimulatePhysics(false);
				}

				PrimComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
				PrimComp->SetCollisionResponseToAllChannels(ECR_Ignore);
			}

			bInInterpolatedAttaching = true;

			Character->NativeAttachElementalCatcher();
			break;
		}
		case EP3LootingInteractableType::Catch:
			SetAnimMontage(Character->GetAnimMontages().Catch);
			break;
		case EP3LootingInteractableType::Harvest:
			SetAnimMontage(Character->GetAnimMontages().Harvest);
			break;
		case EP3LootingInteractableType::Mining:
			SetAnimMontage(Character->GetAnimMontages().Mining);
			break;
		case EP3LootingInteractableType::Pluck:
			SetAnimMontage(Character->GetAnimMontages().Pluck);
			break;
		default:
			P3JsonLog(Warning, "Invalid LootingInteractableType", TEXT("LootingInteractableType"), EnumToString(EP3LootingInteractableType, LootingInteractableComp->GetLootingInteractableType()));
			break;
		}
	}
	else
	{
		SetAnimMontage(Character->GetAnimMontages().Interaction);
	}

	if (!PlayAnimMontage())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	InteracteeActor = Params.RequestParams.Interact_InteracteeActor.Actor;
	bHoldLootItemOnInteract = Params.RequestParams.Interact_bHoldLootItemOnInteract;
}

void UP3InteractPawnAction::Multicast_Finish(EP3PawnActionResult Result)
{
	Super::Multicast_Finish(Result);

	if (Result == EP3PawnActionResult::Failed)
	{
		StopAnimMontage();
	}

	if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		Finish(Result);
	}
}

void UP3InteractPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (!InteracteeActor || InteracteeActor->IsActorBeingDestroyed())
		{
			if (!bSuccessInteract)
			{
				Finish(EP3PawnActionResult::Failed);
			}
		}

		if (bInInterpolatedAttaching && InteracteeActor)
		{
			static const FName SocketName = FName("item_hand_L");

			AP3Character* Character = GetP3Character();

			if (Character && Character->GetMesh())
			{
				const FVector CurrentLocation = InteracteeActor->GetActorLocation();
				FVector TargetLocation = Character->GetMesh()->GetSocketLocation(SocketName);

				const FRotator CurrentRotation = InteracteeActor->GetActorRotation();
				FRotator TargetRotation = Character->GetMesh()->GetSocketRotation(SocketName);

				const float DistanceSquared = (TargetLocation - CurrentLocation).SizeSquared();
				if (DistanceSquared < 1)
				{
					bInInterpolatedAttaching = false;
					InteracteeActor->SetActorLocation(TargetLocation);
					InteracteeActor->SetActorRotation(TargetRotation);
					InteracteeActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, SocketName);
				}
				else
				{
					const float Alpha = FMath::Clamp(DeltaSeconds * 10.0f, 0.05f, 0.5f);

					const FVector NewLocation = FMath::Lerp(CurrentLocation, TargetLocation, Alpha);
					InteracteeActor->SetActorLocation(NewLocation);

					const FRotator NewRotator = FMath::Lerp(CurrentRotation, TargetRotation, Alpha);
					InteracteeActor->SetActorRotation(NewRotator);
				}
			}
		}
	}
}

bool UP3InteractPawnAction::IsIgnoreMoveInput() const
{
	if (InteracteeActor)
	{
		UP3InteractableComponent* InteractableComp = InteracteeActor->FindComponentByClass<UP3InteractableComponent>();
		return (InteractableComp && !InteractableComp->IsAllowMoveOnAnimPlaying());
	}

	return true;
}

void UP3InteractPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		if (LootItemActor)
		{
			LootItemActor->Destroy();
		}
	}

	Rollback();

	AP3Character* Character = GetP3Character();
	if (ensure(Character))
	{
		Character->NativeDetachElementalCatcher();
	}

	bSuccessInteract = false;
	InteracteeActor = nullptr;
	bHoldLootItemOnInteract = false;
	bSuccessLooting = false;
}

void UP3InteractPawnAction::FinishToIdle()
{
	const bool bIsBothResultSuccess = GetActionLocalResult() == EP3PawnActionResult::Success && GetActionServerResult() == EP3PawnActionResult::Success;

	if (!bIsBothResultSuccess)
	{
		Rollback();
	}

	Super::FinishToIdle();
}

void UP3InteractPawnAction::Rollback()
{
	if (!InteracteeActor)
	{
		return;
	}

	UP3InteractableComponent* InteractableComp = InteracteeActor->FindComponentByClass<UP3InteractableComponent>();
	if (!ensure(InteractableComp))
	{
		return;
	}

	UP3LootingInteractableComponent* LootingInteractableComp = Cast<UP3LootingInteractableComponent>(InteractableComp);
	if (LootingInteractableComp)
	{
		switch (LootingInteractableComp->GetLootingInteractableType())
		{
		case EP3LootingInteractableType::Extract:
		{
			TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
			InteracteeActor->GetComponents(PrimComps);

			for (UPrimitiveComponent* PrimComp : PrimComps)
			{
				if (PrimComp == InteracteeActor->GetRootComponent())
				{
					PrimComp->SetSimulatePhysics(true);
				}

				const ECollisionEnabled::Type* CollisionEnabled = SavedCollisionEnabled.Find(PrimComp);
				if (CollisionEnabled)
				{
					PrimComp->SetCollisionEnabled(*CollisionEnabled);
				}

				const FCollisionResponseContainer* CollisionResponse = SavedCollisionResponse.Find(PrimComp);
				if (CollisionResponse)
				{
					PrimComp->SetCollisionResponseToChannels(*CollisionResponse);
				}
			}

			InteracteeActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		}
		}
	}
}

void UP3InteractPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::Interact)
	{
		AP3Character* Character = GetP3Character();
		if (ensure(Character))
		{
			Character->NativeDetachElementalCatcher();
		}

		if (!InteracteeActor)
		{
			return;
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			UP3InteractableComponent* InteractableComp = InteracteeActor->FindComponentByClass<UP3InteractableComponent>();

			if (InteractableComp && InteractableComp->IsInteractionAllowed())
			{
				bSuccessInteract = InteractableComp->Server_OnInteract(GetOwnerActor());
				if (!bSuccessInteract)
				{
					Finish(EP3PawnActionResult::Failed);
				}
			}
		}

		if (P3Core::IsP3NetModeClientInstance(*this))
		{
			if (bSuccessLooting && bHoldLootItemOnInteract)
			{
				UP3LootingInteractableComponent* LootingInteractableComp = InteracteeActor->FindComponentByClass<UP3LootingInteractableComponent>();
				if (!ensure(LootingInteractableComp))
				{
					return;
				}

				FActorSpawnParameters Params;
				Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

				LootItemActor = GetWorld()->SpawnActor<AActor>(LootingInteractableComp->GetLootItemActorClass(), Params);
				if (!ensure(LootItemActor))
				{
					return;
				}

				TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
				LootItemActor->GetComponents(PrimComps);

				for (UPrimitiveComponent* PrimComp : PrimComps)
				{
					if (PrimComp == LootItemActor->GetRootComponent())
					{
						PrimComp->SetSimulatePhysics(false);
					}
					PrimComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
					PrimComp->SetCollisionResponseToAllChannels(ECR_Ignore);
				}

				if (Character)
				{
					const FName SocketName = (LootingInteractableComp->GetLootingInteractableType() == EP3LootingInteractableType::Collect) ? FName("item_hand_L") : FName("item_hand_R");
					LootItemActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, SocketName);
				}
			}
		}
	}
	else if (NotifyType == EActionAnimNotifyType::DropInteracteeActor)
	{
		if (!InteracteeActor)
		{
			return;
		}

		UP3InteractableComponent* InteractableComp = InteracteeActor->FindComponentByClass<UP3InteractableComponent>();
		if (!ensure(InteractableComp))
		{
			return;
		}

		UP3LootingInteractableComponent* LootingInteractableComp = Cast<UP3LootingInteractableComponent>(InteractableComp);
		if (!LootingInteractableComp)
		{
			return;
		}

		switch (LootingInteractableComp->GetLootingInteractableType())
		{
		case EP3LootingInteractableType::Extract:
		{
			TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
			InteracteeActor->GetComponents(PrimComps);
			for (UPrimitiveComponent* PrimComp : PrimComps)
			{
				if (PrimComp == InteracteeActor->GetRootComponent())
				{
					PrimComp->SetSimulatePhysics(true);
				}

				const ECollisionEnabled::Type* CollisionEnabled = SavedCollisionEnabled.Find(PrimComp);
				if (CollisionEnabled)
				{
					PrimComp->SetCollisionEnabled(*CollisionEnabled);
				}

				const FCollisionResponseContainer* CollisionResponse = SavedCollisionResponse.Find(PrimComp);
				if (CollisionResponse)
				{
					PrimComp->SetCollisionResponseToChannels(*CollisionResponse);
				}

				PrimComp->SetCollisionResponseToChannel(ECollisionChannel::ECC_Pawn, ECR_Ignore);
			}

			InteracteeActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
			InteracteeActor = nullptr;
		}
		}
	}
	else if (NotifyType == EActionAnimNotifyType::DestroyHoldingLootActor)
	{
		if (P3Core::IsP3NetModeClientInstance(*this))
		{
			if (LootItemActor)
			{
				LootItemActor->Destroy();
			}
		}
	}
}

UP3HoldFromInventoryPawnAction::UP3HoldFromInventoryPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3HoldFromInventoryPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	if (Character->IsPickuped())
	{
		return false;
	}

	if (Character->GetCharacterStoreBP().ThrowAimingItemId != INVALID_ITEMID)
	{
		return false;
	}

	if (Params.HoldItemFromInventory_ItemId == INVALID_ITEMID)
	{
		ensure(0);
		return false;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return false;
	}

	const FP3Item Item = InventoryComp->GetItem(Params.HoldItemFromInventory_ItemId);
	if (!ensure(Item.IsValid()))
	{
		return false;
	}

	return true;
}

void UP3HoldFromInventoryPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);
	
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}
	
	SetAnimMontage(Character->GetAnimMontages().TakeOutItemFromBag);

	if (!PlayAnimMontage())
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			return;
		}

		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		if (!ensure(CommandComp))
		{
			return;
		}

		const FP3Item Item = InventoryComp->GetItem(Params.RequestParams.HoldItemFromInventory_ItemId);
		if (!ensure(Item.IsValid()))
		{
			return;
		}

		const FP3CmsItem& CmsItem = P3Cms::GetItem(Item.Key);
		if (!ensure(!CmsItem.ItemActorClass.IsNull()))
		{
			return;
		}

		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

		AActor* ItemActor = GetWorld()->SpawnActor<AActor>(CmsItem.ItemActorClass.LoadSynchronous(), SpawnParams);
		if (!ensure(ItemActor))
		{
			return;
		}

		InventoryComp->Server_RemoveItemByIdAndCount(Item.Id, 1);

		FP3CommandRequestParams CommandParams;
		CommandParams.HoldItem_ItemActor = ItemActor;
		CommandComp->RequestCommand(UP3HoldItemCommand::StaticClass(), CommandParams);
	}

	ChangeCharacterStance(EP3CharacterStance::Pickup);
}

UP3PickupBackpackPawnAction::UP3PickupBackpackPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3PickupBackpackPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	if (!Params.PickupBackpack_BackpackActor || !Params.PickupBackpack_BackpackActor->IsA(AP3Backpack::StaticClass()))
	{
		return false;
	}

	return true;
}

void UP3PickupBackpackPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	BackpackActor = Params.RequestParams.PickupBackpack_BackpackActor;
	if (!ensure(BackpackActor))
	{
		P3JsonLog(Error, "BackpackActor doesn't exist");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		if (!ensure(CommandComp))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		FP3CommandRequestParams CommandParams;
		CommandParams.PickupBackpack_BackpackActor = BackpackActor;
		CommandParams.PickupBackpack_AttachSocketName = Params.RequestParams.PickupBackpack_AttachSocketName;

		CommandComp->RequestCommand(UP3PickupBackpackCommand::StaticClass(), CommandParams);
	}

	Finish(EP3PawnActionResult::Success);
}

UP3PutdownBackpackPawnAction::UP3PutdownBackpackPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3PutdownBackpackPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		return false;
	}

	if (!InventoryComp->IsCarryingBackpack())
	{
		return false;
	}

	return true;
}

void UP3PutdownBackpackPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();
	if (!ensure(InventoryComp))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	AP3Backpack* BackpackActor = InventoryComp->GetBackpackActor();
	if (!ensure(BackpackActor))
	{
		P3JsonLog(Error, "Carrying BackpackActor doesn't exist");
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		if (!ensure(CommandComp))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		FP3CommandRequestParams CommandParams;
		CommandParams.PutdownBackpack_BackpackActor = BackpackActor;

		CommandComp->RequestCommand(UP3PutdownBackpackCommand::StaticClass(), CommandParams);
	}

	Finish(EP3PawnActionResult::Success);
}
