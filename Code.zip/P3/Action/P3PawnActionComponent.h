// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Animation/AnimMontage.h"
#include "Containers/Queue.h"
#include "Network/Lib/P3NetCore.h"
#include "P3PawnAction.h"
#include "P3PawnActionComponent.generated.h"

/**
 * Requested Action Status
 * Used on action status changed event
 */
UENUM()
enum class EP3RequestedActionStatus
{
	Requested,
	StartFailed,
	Started,
	Finished
};

struct FP3LastChangedActionStatus
{
	int32 RequestId = 0;
	EP3RequestedActionStatus Status = EP3RequestedActionStatus::Requested;
};

/**
 * Requested Action Status Changed event
 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3RequestedActionStatusChanged, int32, RequestId, EP3RequestedActionStatus, Status);

/**
 * Action Net Packets
 */
USTRUCT()
struct FP3NetActionStartRequestParams
{
	GENERATED_BODY()

	UPROPERTY()
	EPawnActionType ActionType = EPawnActionType::Invalid;

	UPROPERTY()
	FP3PawnActionStartRequestParams RequestParams;
};

USTRUCT()
struct FP3NetActionStopRequestParams
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ActionId = -1;

	UPROPERTY()
	FP3PawnActionStopRequestParams RequestParams;
};

USTRUCT()
struct FP3NetForceFinishActionParams
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ActionId = -1;

	UPROPERTY()
	EPawnActionType ActionType = EPawnActionType::Invalid;
};

USTRUCT()
struct FP3NetStartActionFailed
{
	GENERATED_BODY()

	UPROPERTY()
	int32 RequestId = 0;

	UPROPERTY()
	EPawnActionType ActionType = EPawnActionType::Invalid;
};

USTRUCT()
struct FP3NetStartAction
{
	GENERATED_BODY()

	UPROPERTY()
	EPawnActionType ActionType = EPawnActionType::Invalid;

	UPROPERTY()
	FP3PawnActionStartMulticastParams Params;
};

USTRUCT()
struct FP3NetStopAction
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ActionId = -1;

	UPROPERTY()
	FP3PawnActionStopMulticastParams Params;
};

USTRUCT()
struct FP3NetFinishAction
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ActionId = -1;

	UPROPERTY()
	EPawnActionType ActionType = EPawnActionType::Invalid;

	UPROPERTY()
	EP3PawnActionResult Result = EP3PawnActionResult::Success;
};

USTRUCT()
struct FP3NetForceFinishAction
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ActionId = -1;

	UPROPERTY()
	EPawnActionType ActionType = EPawnActionType::Invalid;

	UPROPERTY()
	EP3PawnActionResult Result = EP3PawnActionResult::Success;
};

USTRUCT()
struct FP3NetProgressAction
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ActionId = -1;

	UPROPERTY()
	EPawnActionType ActionType = EPawnActionType::Invalid;

	UPROPERTY()
	int32 StepIndex = -1;
};

/**
 * Pawn Action Component
 */
UCLASS()
class P3_API UP3PawnActionComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3PawnActionComponent();
	
	bool RegisterAction(EPawnActionType ActionType, EPawnActionCategory ActionCategory, UP3PawnAction* Action);

	void InitializeActions();

	// DYLEE NOTE GetCharacterMontageActionDesc() 임시 대체 (이 구현도 없애야 함)
	const FP3CharacterMontageActionRow* GetCharacterMontageActionDesc(FName MontargeActionKey) const;

	/** 
	 * Requests
	 */
	/** Returns request id or 0 if failed */
	int32 StartAction(EPawnActionType ActionType, const FString& DebugContext, const FP3PawnActionStartRequestParams& Params = FP3PawnActionStartRequestParams());
	bool StopAction(int32 ActionId, const FP3PawnActionStopRequestParams& Params = FP3PawnActionStopRequestParams());
	void Server_StopActionByRequestId(int32 RequestId);

	/** Abort current actions and discard queued actions */
	void Server_Reset();

	/** Query */
	UFUNCTION(BlueprintCallable)
	EPawnActionType GetActiveActionType() const;
	int32 GetActiveActionId() const;
	float GetActiveActionStartTimeSeconds() const;
	bool Server_IsActionInQueue(EPawnActionType ActionType) const;
	bool IsActionInProgress(EPawnActionType ActionType) const;
	bool HasAction(EPawnActionType ActionType) const;
	bool IsIgnoreMoveInput() const;
	bool IsInKnockBack() const;
	bool IsInKnockDown() const;
	bool CanStartAction(EPawnActionType ActionType) const;
	bool CanStartGliding() const;
	bool CanStartJump() const;
	bool CanStartClimb() const;
	bool CanSprint() const;
	bool CanRegenStamina() const;
	bool IsDisableCollisionWithWorldObject() const;
	float GetMoveSpeedMultiplier() const;
	bool IsMoveAllowed() const;
	bool IsRotateAllowed() const;
	bool IsJumpAllowed() const;
	EP3RequestedActionStatus GetActionStatusByRequestId(int32 RequestId) const;
	const TArray<int32>& GetChainedActionRequestIds() const { return ChainedActionRequestIds; }

	/** Event from Action */
	void OnActionFinished(UP3PawnAction& Action);
	void OnActionFinishedToIdle(UP3PawnAction& Action);
	void OnActionProgress(UP3PawnAction* Action, int32 StepIndex);

	/** Event from Network */
	void Client_OnDisconnected();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	void Server_Tick(float DeltaSeconds);
	void Server_TickStartActionQueue();

	/** Active action is interruptable? (by next action) */
	bool CanInterruptActiveAction(EPawnActionType NextActionType, const FP3PawnActionStartRequestParams* NextActionParams) const;
	FName GetActionKey(EPawnActionType InActionType, const FP3PawnActionStartRequestParams* InActionParams) const;
	template <typename Row, typename Type>
	EP3ActionEdgeType GetActionEdgeType(const UDataTable* Table, Type From, Type To) const;

	UP3PawnAction* GetActionByType(EPawnActionType Type) const;
	UP3PawnAction* GetActiveAction() const;

	UFUNCTION()
	void Server_HandleRequestCommand(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Server_HandleStopCommand(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Server_HandleForceFinishCommand(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Client_HandleStartActionFailed(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleStartAction(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleStopAction(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleFinishAction(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleForceFinishAction(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleProgressAction(const FP3DediToClientHandlerParams& Params);

	int32 Autonomous_StartAction(EPawnActionType ActionType, const FP3PawnActionStartRequestParams& Params);
	int32 Server_StartAction(EPawnActionType ActionType, const FP3PawnActionStartRequestParams& Params);

	bool Server_StartActionInternal(EPawnActionType StartActionType, const FP3PawnActionStartRequestParams& Params);
	bool Server_StopActionInternal(int32 ActionId, const FP3PawnActionStopRequestParams& Params);

	bool Server_ForceFinishAction(EPawnActionType ActionType, EP3PawnActionResult Result);

	void StartActionInternal(EPawnActionType StartActionType, const FP3PawnActionStartMulticastParams& Params);
	void StopActionInternal(int32 ActionId, const FP3PawnActionStopMulticastParams& Params);
	void FinishActionInternal(int32 ActionId, EPawnActionType ActionType, EP3PawnActionResult Result);
	void ForceFinishActionInternal(int32 ActionId, EPawnActionType ActionType, EP3PawnActionResult Result);
	void ProgressActionInternal(int32 ActionId, EPawnActionType ActionType, int32 StepIndex);

public:
	FP3RequestedActionStatusChanged OnRequestedActionStatusChanged;
	static const FName AIMessage_ActionStarted;
	static const FName AIMessage_ActionFinished;
	static const FName AIMessage_ActionStartFailed;
	static const FName AIMessage_ChainedActionRequested;

private:

	/** Actions */
	UPROPERTY(Transient)
	TArray<UP3PawnAction*> Actions;

	/** 
	 * Last started action id
	 */
	int32 Server_CurrentActionId;

	/**
	 * Request id
	 */
	int32 Autonomous_NextRequestId = 1;
	int32 Server_NextRequestId = 1;
	FP3LastChangedActionStatus Autonomous_LastChangedActionStatus;
	FP3LastChangedActionStatus Server_LastChangedActionStatus;

	/** 
	 * Request queue
	 */
	EPawnActionType Autonomous_QueuedStartActionType = EPawnActionType::Invalid;
	FP3PawnActionStartRequestParams Autonomous_QueuedStartActionParams;

	/** 
	 * [Server] Start action queue
	 * Since in server side, one may Start action within a action, either intended or not intended
	 * So we have to queue it first and execute it on next tick to avoid conflict
	 */
	struct FStartActionQueueItem
	{
		EPawnActionType ActionType;
		FP3PawnActionStartRequestParams Params;
	};
	TArray<FStartActionQueueItem> Server_StartActionQueue;

	/** 
	 * Set true within tick scope 
	 * we need this to detect action start request within action tick
	 * which means chain(consecutive) action
	 */
	bool bTickScope = false;

	/**
	 * If any action is chained(requested within action)
	 * it's request id will be stored here and can be used by BTTask
	 */
	TArray<int32> ChainedActionRequestIds;

	UPROPERTY(EditDefaultsOnly, Category = "P3Action")
	const UDataTable* ActionTable = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = "P3Action")
	const UDataTable* MontageActionTable = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = "P3Action")
	const UDataTable* ActionCategoryEdgeTable = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = "P3Action")
	const UDataTable* ActionTypeEdgeTable = nullptr;

	UPROPERTY(EditDefaultsOnly, Category = "P3Action")
	const UDataTable* ActionKeyEdgeTable = nullptr;
};

template <typename Row, typename Type>
EP3ActionEdgeType UP3PawnActionComponent::GetActionEdgeType(const UDataTable* Table, Type From, Type To) const
{
	if (!Table)
	{
		return EP3ActionEdgeType::Invalid;
	}

	EP3ActionEdgeType EdgeType = EP3ActionEdgeType::Invalid;

	TArray<Row*> EdgeRows;
	Table->GetAllRows("P3PawnActionComponent::GetActionEdgeType", EdgeRows);

	for (auto* EdgeRow : EdgeRows)
	{
		if (!ensure(EdgeRow))
		{
			continue;
		}

		if (From != EdgeRow->From || To != EdgeRow->To)
		{
			continue;
		}

		if (EdgeRow->EdgeType == EP3ActionEdgeType::NotAllowed)
		{
			return EdgeRow->EdgeType;
		}
		else if (ensure(EdgeRow->EdgeType == EP3ActionEdgeType::Allowed))
		{
			EdgeType = EdgeRow->EdgeType;
		}
	}

	return EdgeType;
}
