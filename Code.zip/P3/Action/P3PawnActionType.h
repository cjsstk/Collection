// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

/**
 * Pawn Action Category
 */
UENUM(Blueprintable)
enum class EPawnActionCategory : uint8
{
	Invalid,
	Dead,
	Movement,
	Combat,
	Pickup,
	CrowdControl,
	Reaction
};

/**
 * Pawn Action Type
 */
UENUM(BlueprintType)
enum class EPawnActionType : uint8
{
	Invalid,
	Spawn,	
	ClimbStart,
	ClimbJump,
	ClimbDown,
	ClimbEnd,
	ParkourClimbUp,
	DrawWeapon,
	PutAwayWeapon,
	CombatRoll,
	CombatAttack,
	CombatRangedAttack,
	CombatProjectileSkillAttack,
	CombatAdaptedAttack,
	CombatHit,
	CombatCombo,
	CombatCharging,
	StartBlock,
	StopBlock,
	Pickup,
	PickupHoldable,
	PickupConsumable,
	PickupBackpack,
	UseConsumable,
	HoldItemFromInventory,
	Interact,
	Switching,
	Putdown,
	PutdownHoldable,
	PutdownBackpack,
	Throw,
	ChangeHoldable,
	Ragdollize,
	Unragdollize,
	ThrowWeapon,
	RecallThrownWeapon,
	PullHarpoon,
	TripOver,
	BouncingJump,
	CharacterMontage,
	DownedEnd,
	Rescue,
	Breakfall,
	Exhaust,
	BuckingHangOn,
	Cook,	
	MountByRegolasMove,
	ThrownAway,
	RoarStun,
	CombatReactionHit,
	CableMove,
	CombatHitFlame,
	StartItemThrowAim,
	EndItemThrowAim,
	CarryingOnBackStart,
	CarryingOnBackEnd,
	CarriedOnBackStart,
	CarriedOnBackEnd,
	Count		UMETA(Hidden)
};

UENUM(BlueprintType)
enum class EP3RescueDirection : uint8
{
	None,
	Left,
	Right,
	Front,
	Rear,
	Count UMETA(Hidden)
};
