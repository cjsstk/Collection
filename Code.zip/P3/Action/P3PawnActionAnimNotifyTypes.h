// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

UENUM(Blueprintable)
enum class EActionAnimNotifyType : uint8
{
	Invalid,
	Pickup,
	Putdown,
	Throw,
	ClimbEndLanded,
	Fire,
	DrawWeapon,
	DrawShield,
	DrawSupportHoldable,
	PutawayWeapon,
	PutawayShield,
	PutawaySupportHoldable,
	ThrowWeapon,
	UseItem,
	DownedEnd,
	DropAllRiders,
	Interact,
	Harvest,					// Harvested object will be attached to hand at this time
	PutIntoBag,					// Use this to detach object from hand and put into inventory
	StopFire,
	MountByRegolasMove_Hold,
	MountByRegolasMove_Mount,
	DropInteracteeActor,
	DestroyHoldingLootActor,	// Destroy actor that attached when lootingInteracted
};

UENUM()
enum class EActionAnimNotifyStateType : uint8
{
	AdaptAttackMoveBegin,
	AdaptAttaackMoveEnd
};
