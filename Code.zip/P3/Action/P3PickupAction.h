// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Action/P3PawnAction.h"
#include "P3PickupableType.h"
#include "P3PickupAction.generated.h"

/** 
 * Pickup Action
 */
UCLASS(BlueprintType)
class P3_API UP3PickupPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3PickupPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void FinishToIdle() override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	UFUNCTION()
	void OnPickupAnimNotify();

	void Server_PutIntoBag();

	FVector GetTargetLocation() const;

	/** Picking up actor */
	UPROPERTY()
	AActor* TargetActor;
	itemkey TargetItemCmsKey = INVALID_ITEMKEY;
	int32 TargetItemAmount = 1;

	EP3PickupableType PickupableType = EP3PickupableType::None;

	/** Socket name which object attach to */
	FName AttachSocketName;

	/** Best spot to attach that actor to my socket */
	FVector AttachOffset;

	/** Are we moving object towards hand now? */
	bool bInInterpolatedAttaching;

	/** Did we attach target to character? We need to remember this so that we can revert */
	bool bAttached;

	bool bIsPickupToInventory = false;

	bool bServer_Pickedup = false;

	   
	/** 
	 * If object is heavy, it's better not to rotate during pickup 
	 * If this is true, AttachOffset is in world space
	 */
	bool bDoNotRotate = true;

	/**
	 * If this is true, object's center bottom will be used instead of ray casting to select attach offset
	 */
	bool bAttachAtCenterBottom = true;
};


/** 
 * Pickup Holdable Action
 */
UCLASS(BlueprintType)
class P3_API UP3PickupHoldablePawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3PickupHoldablePawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual void Server_FillAuthorityStartParams(const FP3PawnActionStartRequestParams& RequestParams, FP3PawnActionStartAuthorityParams& OutParams) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType);

private:
	void Hold();

	/** Picking up item */
	FP3Item TargetItem = FP3Item::InvalidItem;

	/** Picking up actor */
	UPROPERTY()
	AActor* TargetActor = nullptr;

	UPROPERTY()
	class UP3HolderComponent* HolderComponent = nullptr;

	EP3CharacterItemSlot CharacterItemSlot = EP3CharacterItemSlot::Invalid;
	bool bHolded = false;
};


/**
 * Pickup Consumable Action
 */
UCLASS(BlueprintType)
class P3_API UP3PickupConsumablePawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3PickupConsumablePawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType);

private:
	void Server_Pickup();

	/** Picking up actor */
	UPROPERTY()
	AActor* TargetActor = nullptr;
	itemkey TargetItemCmsKey = INVALID_ITEMKEY;
	int32 TargetItemAmount = 1;

	bool bServer_Pickedup = false;
};


/**
 * Use Consumable Action
 */
UCLASS(BlueprintType)
class P3_API UP3UseConsumablePawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3UseConsumablePawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanStartGliding() const override { return true; }
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool IsIgnoreMoveInput() const;
	virtual float GetMoveSpeedMultiplier() const;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType);

private:
	FP3ItemId ConsumableItemId = INVALID_ITEMID;

	UPROPERTY()
	AActor* SpawnedActorOnHold = nullptr;

	UPROPERTY()
	FP3CmsConsumable CmsConsumable;

	bool bAllowMoveInputDuringConsumeAction = true;
	bool Client_bDestoryHoldingItemOnUseNotify = false;
};


/**
 * Hold Item from Inventory Action
 * took out item from inventory and hold it on hand
 */
UCLASS(BlueprintType)
class P3_API UP3HoldFromInventoryPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3HoldFromInventoryPawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual bool CanStartGliding() const override { return false; }
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual bool IsIgnoreMoveInput() const { return true; }
};


/** 
 * Interact Action
 */
UCLASS(BlueprintType)
class P3_API UP3InteractPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	/** 
	 * UP3PawnAction interfaces
	 */
	UP3InteractPawnAction();

	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void Multicast_Finish(EP3PawnActionResult Result) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool IsIgnoreMoveInput() const;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void FinishToIdle() override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	void Rollback();

	UPROPERTY(Transient)
	AActor* InteracteeActor;

	TMap<UPrimitiveComponent*, ECollisionEnabled::Type> SavedCollisionEnabled;
	TMap<UPrimitiveComponent*, FCollisionResponseContainer> SavedCollisionResponse;

	bool bSuccessInteract = false;

	/**
	 * UP3LootingInteractable
	 */
	UPROPERTY(Transient)
	AActor* LootItemActor = nullptr;

	bool bHoldLootItemOnInteract = false;
	bool bSuccessLooting = false;
	bool bInInterpolatedAttaching = false;
};

/** 
 * Switching Action
 */
UCLASS(BlueprintType)
class P3_API UP3SwitchingPawnAction : public UP3PawnAction
{
	GENERATED_BODY()

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
};


/** 
 * Putdown Action
 */
UCLASS(BlueprintType)
class P3_API UP3PutdownPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3PutdownPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	FName AttachSocketName;

	/** Object's transform relative to attached socket */
	FTransform AttachedRelativeTransform;

	UPROPERTY()
	AActor* TargetActor = nullptr;

	/** We move target object along with attach socket until putdown anim notify */
	bool bPutdownAnimNotified = false;

	/** Or, we abort moving object if doesn't follow our order, possibly colliding something */
	bool bAbortMoveObjectToHand = false;

	/** 
	 * If object is heavy, it's better not to rotate during pickup 
	 * If this is true, AttachedRelativeTransform's location is in world space
	 */
	bool bDoNotRotate = true;
};


/** 
 * Putdown holdable Action
 */
UCLASS(BlueprintType)
class P3_API UP3PutdownHoldablePawnAction : public UP3PawnAction
{
	GENERATED_BODY()

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
};



/** 
 * Throw Action
 */
UCLASS(BlueprintType)
class P3_API UP3ThrowPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3ThrowPawnAction();

	/** 
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Server_FillAuthorityStartParams(const FP3PawnActionStartRequestParams& RequestParams, FP3PawnActionStartAuthorityParams& OutParams) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void TickAction(float DeltaSeconds) override;
	virtual bool CanForceFinishOtherAction(EPawnActionType OtherActionType, float OtherActionAgeSeconds, const FP3PawnActionStartRequestParams* Params) const;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	UFUNCTION()
	void OnThrowAnimNotify();

	UPROPERTY()
	AActor* TargetActor = nullptr;

	FVector ThrowWorldVelocity;

	bool bThrown = false;
	float ThrownAge = 0;
	bool bPawnCollisionOffed = false;
};

/**
 * Pick up backpack Action
 */
UCLASS(BlueprintType)
class P3_API UP3PickupBackpackPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3PickupBackpackPawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

private:
	UPROPERTY(Transient)
	AActor* BackpackActor = nullptr;

};

/**
 * Put down backpack Action
 */
UCLASS(BlueprintType)
class P3_API UP3PutdownBackpackPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3PutdownBackpackPawnAction();

	/**
	 * UP3PawnAction interfaces
	 */
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;

private:

};
