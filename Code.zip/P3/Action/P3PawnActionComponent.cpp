// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PawnActionComponent.h"

#include "Animation/AnimInstance.h"
#include "BrainComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"

#include "Action/P3PickupAction.h"
#include "Crafting/P3CraftingAction.h"
#include "P3Core.h"
#include "P3Character.h"
#include "P3Log.h"
#include "P3World.h"
#include "P3WorldNetCore.h"

const FName UP3PawnActionComponent::AIMessage_ActionStarted = TEXT("ActionStarted");
const FName UP3PawnActionComponent::AIMessage_ActionFinished = TEXT("ActionFinished");
const FName UP3PawnActionComponent::AIMessage_ActionStartFailed = TEXT("ActionStartFailed");
const FName UP3PawnActionComponent::AIMessage_ChainedActionRequested = TEXT("ChainedActionRequested");

static TAutoConsoleVariable<int32> CVarP3ActionTestStartFailOnServer(
    TEXT("p3.actionTestStartFailOnServer"),
    0,
    TEXT("1: Fail every action request on server"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3ActionDebug(
    TEXT("p3.actionDebug"),
    0,
    TEXT("0: off, 1: simple debug info, 2: detailed debug info"), ECVF_Cheat);

#undef ActionJsonLog
#define ActionJsonLog(Verbosity, Subject, ...) \
	P3JsonLogWithCategory(P3ActionLog, Verbosity, Subject,	\
		TEXT("Pawn"), (GetOwner() ? GetOwner()->GetName() : TEXT("NULL")),	\
		TEXT("Role"), GetOwner() ? P3Core::GetNetModeStr(P3Core::GetP3NetMode(*GetOwner())) : TEXT("NONE"),	\
		##__VA_ARGS__)

static void _UpdatePointerFromId(FP3PawnActionStartRequestParams& Params, const UObject& WorldContextObject)
{
	UStruct* ParamStruct = FP3PawnActionStartRequestParams::StaticStruct();
	UField* Field = ParamStruct->Children;
	while (Field)
	{
		UStructProperty* StructProperty = Cast<UStructProperty>(Field);
		if (StructProperty && StructProperty->Struct == FP3ActorPointerAndId::StaticStruct())
		{
			FP3ActorPointerAndId* P3ActorPointerAndId = StructProperty->ContainerPtrToValuePtr<FP3ActorPointerAndId>(&Params);
			if (ensure(P3ActorPointerAndId) && P3ActorPointerAndId->ActorId != INVALID_ACTORID)
			{
				P3ActorPointerAndId->UpdatePointerFromId(WorldContextObject);
			}
		}

		Field = Field->Next;
	}
}

UP3PawnActionComponent::UP3PawnActionComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	Server_CurrentActionId = 0;

	Actions.AddZeroed((int32)EPawnActionType::Count);
}

void UP3PawnActionComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3PawnActionComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void UP3PawnActionComponent::OnActionFinished(UP3PawnAction& Action)
{
	ActionJsonLog(Display, "Action finished", 
		TEXT("ActionType"), EnumToStringShort(EPawnActionType, Action.GetActionType()),
		TEXT("ActionId"), Action.GetActionId(),
		TEXT("Result"), EnumToStringShort(EP3PawnActionResult, Action.GetActionLocalResult()));
	
	if (P3Core::IsP3NetModeServerInstance(*GetWorld()))
	{
		UP3World* P3World = P3Core::GetP3World(*this);

		if (P3World)
		{
			// Action must have valid id unless it's not even started on server side yet(must be failed to start)
			ensure(Action.GetActionId() != 0 || Action.GetActionServerStatus() == EP3PawnActionStatus::Idle);

			const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
			ensure(ActorId != INVALID_ACTORID);

			FP3NetFinishAction NetParams;
			NetParams.ActionId = Action.GetActionId();
			NetParams.ActionType = Action.GetActionType();
			NetParams.Result = Action.GetActionLocalResult();

			P3World->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Client_HandleFinishAction);
		}

		FinishActionInternal(Action.GetActionId(), Action.GetActionType(), Action.GetActionLocalResult());
	}
}

void UP3PawnActionComponent::OnActionFinishedToIdle(UP3PawnAction& Action)
{
	if (Action.GetAutonomousRequestId() != 0 && IsAutonomousProxy(GetOwner()))
	{
		OnRequestedActionStatusChanged.Broadcast(Action.GetAutonomousRequestId(), EP3RequestedActionStatus::Finished);

		AP3Character* Character = Cast<AP3Character>(GetOwner());
		AController* Controller = Character ? Character->GetController() : nullptr;
		if (Controller)
		{
			FAIMessage Msg(UP3PawnActionComponent::AIMessage_ActionFinished, this, Action.GetAutonomousRequestId(), true);
			FAIMessage::Send(Controller, Msg);
		}

		Autonomous_LastChangedActionStatus.RequestId = Action.GetAutonomousRequestId();
		Autonomous_LastChangedActionStatus.Status = EP3RequestedActionStatus::Finished;
	}
	else if (Action.GetServerRequestId() != 0 && IsAuthority(GetOwner()))
	{
		OnRequestedActionStatusChanged.Broadcast(Action.GetServerRequestId(), EP3RequestedActionStatus::Finished);

		AP3Character* Character = Cast<AP3Character>(GetOwner());
		AController* Controller = Character ? Character->GetController() : nullptr;
		if (Controller)
		{
			FAIMessage Msg(UP3PawnActionComponent::AIMessage_ActionFinished, this, Action.GetServerRequestId(), true);
			FAIMessage::Send(Controller, Msg);
		}

		Server_LastChangedActionStatus.RequestId = Action.GetServerRequestId();
		Server_LastChangedActionStatus.Status = EP3RequestedActionStatus::Finished;
	}
}

void UP3PawnActionComponent::OnActionProgress(UP3PawnAction* Action, int32 StepIndex)
{
	if (P3Core::IsP3NetModeServerInstance(*GetWorld()))
	{
		const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
		ensure(ActorId != INVALID_ACTORID);

		FP3NetProgressAction NetParams;
		NetParams.ActionId = Action->GetActionId();
		NetParams.ActionType = Action->GetActionType();
		NetParams.StepIndex = StepIndex;

		P3Core::GetP3World(*this)->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Client_HandleProgressAction);

		ProgressActionInternal(Action->GetActionId(), Action->GetActionType(), StepIndex);
	}
}

void UP3PawnActionComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	ensure(bTickScope == false);
	TGuardValue<bool> TickScope(bTickScope, true);

	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_Tick(DeltaTime);
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	for (UP3PawnAction* Action : Actions)
	{
		if (!Action)
		{
			continue;
		}

		if (Action->GetActionLocalStatus() != EP3PawnActionStatus::Idle || 
			Action->GetActionServerStatus() != EP3PawnActionStatus::Idle)
		{
			Action->TickAction(DeltaTime);

#if !UE_BUILD_SHIPPING
			if (Character && CVarP3ActionDebug.GetValueOnGameThread() != 0)
			{
				Character->AddDebugString(FString::Printf(TEXT("[Action] #%d. %s: Local(%s), Server(%s)\n"),
					Action->GetActionId(),
					*EnumToStringShort(EPawnActionType, Action->GetActionType()),
					*EnumToStringShort(EP3PawnActionStatus, Action->GetActionLocalStatus()),
					*EnumToStringShort(EP3PawnActionStatus, Action->GetActionServerStatus())));

				if (!Action->GetDebugString().IsEmpty())
				{
					Character->AddDebugString(Action->GetDebugString());
				}
			}
#endif
		}
	}
}

void UP3PawnActionComponent::Server_Tick(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	// See if we need to abort active action
	UP3PawnAction* ActiveAction = GetActiveAction();
	if (ActiveAction)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character && Character->IsActionCategoryDisabled(ActiveAction->GetActionCategory()))
		{
			Server_ForceFinishAction(ActiveAction->GetActionType(), EP3PawnActionResult::Aborted);
		}
	}

	Server_TickStartActionQueue();
}

void UP3PawnActionComponent::Server_TickStartActionQueue()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	FStartActionQueueItem Item;
	int32 NumProcessed = 0;

	while (Server_StartActionQueue.Num() > 0)
	{
		Item = Server_StartActionQueue[0];
		Server_StartActionQueue.RemoveAt(0);

		const bool bStarted = Server_StartActionInternal(Item.ActionType, Item.Params);
		if (bStarted)
		{
			OnRequestedActionStatusChanged.Broadcast(Item.Params.ServerRequestId, EP3RequestedActionStatus::Started);

			AP3Character* Character = Cast<AP3Character>(GetOwner());
			AController* Controller = Character ? Character->GetController() : nullptr;
			if (Controller)
			{
				FAIMessage Msg(UP3PawnActionComponent::AIMessage_ActionStarted, this, Item.Params.ServerRequestId, true);
				FAIMessage::Send(Controller, Msg);
			}

			Server_LastChangedActionStatus.RequestId = Item.Params.ServerRequestId;
			Server_LastChangedActionStatus.Status = EP3RequestedActionStatus::Started;
		}
		else
		{
			OnRequestedActionStatusChanged.Broadcast(Item.Params.ServerRequestId, EP3RequestedActionStatus::StartFailed);

			AP3Character* Character = Cast<AP3Character>(GetOwner());
			AController* Controller = Character ? Character->GetController() : nullptr;
			if (Controller)
			{
				FAIMessage Msg(UP3PawnActionComponent::AIMessage_ActionStartFailed, this, Item.Params.ServerRequestId, true);
				FAIMessage::Send(Controller, Msg);
			}

			Server_LastChangedActionStatus.RequestId = Item.Params.ServerRequestId;
			Server_LastChangedActionStatus.Status = EP3RequestedActionStatus::StartFailed;
		}

		if (++NumProcessed > 100)
		{
			// Is this infinite loop?
			ensure(0);
			break;
		}
	}
}

bool UP3PawnActionComponent::CanInterruptActiveAction(EPawnActionType NextActionType, const FP3PawnActionStartRequestParams* NextActionParams) const
{
	UP3PawnAction* ActiveAction = GetActiveAction();
	if (!ensure(ActiveAction))
	{
		return false;
	}

	const FName& NextActionKey = GetActionKey(NextActionType, NextActionParams);
	if (!ensure(!NextActionKey.IsNone()))
	{
		ActionJsonLog(Warning, "Get action edge data failed",
			TEXT("NextActionType"), EnumToString(EPawnActionType, NextActionType),
			TEXT("NextActionParams"), NextActionParams ? NextActionParams->CharacterMontage_Name.ToString() : TEXT(""));
		return false;
	}

	const FP3ActionRow* NextActionRow = ActionTable->FindRow<FP3ActionRow>(NextActionKey, _FUNCTION_TEXT);
	if (!ensure(NextActionRow))
	{
		return false;
	}

	ActionJsonLog(Verbose, "Check active action is interruptable",
		TEXT("ActiveActionType"), EnumToString(EPawnActionType, ActiveAction->GetActionType()),
		TEXT("ActiveActionCategory"), EnumToString(EPawnActionCategory, ActiveAction->GetActionCategory()),
		TEXT("ActiveActionKey"), ActiveAction->GetActionKey().ToString(),
		TEXT("NextActionType"), EnumToString(EPawnActionType, NextActionRow->ActionType),
		TEXT("NextActionCategory"), EnumToString(EPawnActionCategory, NextActionRow->ActionCategory),
		TEXT("NextActionKey"), NextActionKey.ToString());

	EP3ActionEdgeType EdgeType = GetActionEdgeType<FP3ActionCategoryEdgeRow, EPawnActionCategory>(ActionCategoryEdgeTable, ActiveAction->GetActionCategory(), NextActionRow->ActionCategory);
	if (EdgeType == EP3ActionEdgeType::NotAllowed)
	{
		return false;
	}

	EPawnActionType ActiveActionType = ActiveAction->GetActionType();
	EdgeType = FMath::Max(EdgeType, GetActionEdgeType<FP3ActionTypeEdgeRow, EPawnActionType>(ActionTypeEdgeTable, ActiveActionType, NextActionRow->ActionType));
	if (EdgeType == EP3ActionEdgeType::NotAllowed)
	{
		return false;
	}

	EdgeType = FMath::Max(EdgeType, GetActionEdgeType<FP3ActionKeyEdgeRow, FName>(ActionKeyEdgeTable, ActiveAction->GetActionKey(), NextActionKey));
	if (EdgeType == EP3ActionEdgeType::NotAllowed)
	{
		return false;
	}

	return EdgeType == EP3ActionEdgeType::Allowed;
}

FName UP3PawnActionComponent::GetActionKey(EPawnActionType InActionType, const FP3PawnActionStartRequestParams* InActionParams) const
{
	if (!ensure(ActionTable))
	{
		return NAME_None;
	}

	if (InActionType == EPawnActionType::CharacterMontage && InActionParams && MontageActionTable)
	{
		const FName& ActionKey = InActionParams->CharacterMontage_Name;
		if (ActionTable->FindRowUnchecked(ActionKey) && MontageActionTable->FindRowUnchecked(ActionKey))
		{
			return ActionKey;
		}
	}
	else if (UP3PawnAction* Action = GetActionByType(InActionType))
	{
		return Action->GetActionKey();
	}

	return NAME_None;
}

bool UP3PawnActionComponent::RegisterAction(EPawnActionType ActionType, EPawnActionCategory ActionCategory, UP3PawnAction* Action)
{
	ActionJsonLog(Display, "Register action",
		TEXT("ActionType"), EnumToString(EPawnActionType, ActionType),
		TEXT("ActionCategory"), EnumToString(EPawnActionCategory, ActionCategory),
		TEXT("ActionClass"), Action->GetClass()->GetName());

	const int32 ActionIndex = StaticCast<int32>(ActionType);

	if (!Actions.IsValidIndex(ActionIndex))
	{
		ensureMsgf(0, TEXT("Invalid action type to register. Type: %d"), ActionIndex);
		return false;
	}

	if (Actions[ActionIndex] != nullptr)
	{
		if (ActionType == EPawnActionType::CharacterMontage)
		{
			// DYLEE TODO MontageAction 이 인스턴스화되면 이것도 제거
			// (CharacterMontage 액션은 하나의 인스턴스를 공용으로 사용하고 있다)
		}
		else
		{
			ensure(0);
			ActionJsonLog(Warning, "Register action failed", TEXT("Error"), TEXT("Already existing action"), TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
			return false;
		}
	}

	Actions[ActionIndex] = Action;

	Action->OnRegister(this, ActionType, ActionCategory);

	return true;
}

void UP3PawnActionComponent::InitializeActions()
{
	// DYLEE NOTE P3-3209 작업 영역 분리
	if (!ensure(CVarP3ActionDataDriven.GetValueOnGameThread()))
	{
		return;
	}

	if (!ensure(ActionTable))
	{
		ensureMsgf(0, TEXT("Invalid action table"));
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		ensureMsgf(0, TEXT("Invalid owner (should be P3Character)"));
		return;
	}

	ActionTable->ForeachRow<FP3ActionRow>(_FUNCTION_TEXT, [&](const FName& Key, const FP3ActionRow& Row)
	{
		UP3PawnAction* Action = NewObject<UP3PawnAction>(this, Row.ActionClass);
		if (ensure(Action))
		{
			// DYLEE TODO 개별 MontageAction 이 인스턴스화되면 이것도 제거
			Action->SetActionKey(Key);

			// DYLEE TODO 생략된 하드 코딩 대응 필요
			// 특정 애니메이션, 컴포넌트 의존성 검사
			RegisterAction(Row.ActionType, Row.ActionCategory, Action);
		}
	});
}

const FP3CharacterMontageActionRow* UP3PawnActionComponent::GetCharacterMontageActionDesc(FName MontargeActionKey) const
{
	// DYLEE NOTE P3-3209 작업 영역 분리
	ensure(CVarP3ActionDataDriven.GetValueOnGameThread());

	if (MontageActionTable)
	{
		return MontageActionTable->FindRow<FP3CharacterMontageActionRow>(MontargeActionKey, _FUNCTION_TEXT);
	}

	return nullptr;
}

void UP3PawnActionComponent::Client_OnDisconnected()
{
	for (UP3PawnAction* Action : Actions)
	{
		if (!Action)
		{
			continue;
		}

		if (Action->GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
		{
			Action->ForceFinish(EP3PawnActionResult::Aborted);
		}

		if (Action->GetActionServerStatus() == EP3PawnActionStatus::InProgress)
		{
			Action->Multicast_Finish(EP3PawnActionResult::Aborted);
		}

		if (Action->GetActionLocalStatus() == EP3PawnActionStatus::Finished && Action->GetActionServerStatus() == EP3PawnActionStatus::Idle)
		{
			// This may be the case that autonomous requests and server does not replied yet,
			// but since the role has already changed to authority, IsAutonomousProxy cannot be checked here.
			Action->Autonomous_FailedToStart();
		}

		ensure(Action->GetActionLocalStatus() == EP3PawnActionStatus::Idle);
		ensure(Action->GetActionServerStatus() == EP3PawnActionStatus::Idle);
	}

	Autonomous_LastChangedActionStatus = FP3LastChangedActionStatus();
}

EPawnActionType UP3PawnActionComponent::GetActiveActionType() const
{
	UP3PawnAction* Action = GetActiveAction();

	if (Action)
	{
		return Action->GetActionType();
	}

	return EPawnActionType::Invalid;
}

int32 UP3PawnActionComponent::GetActiveActionId() const
{
	UP3PawnAction* Action = GetActiveAction();

	if (Action)
	{
		return Action->GetActionId();
	}

	return 0;
}

float UP3PawnActionComponent::GetActiveActionStartTimeSeconds() const
{
	UP3PawnAction* Action = GetActiveAction();

	if (Action)
	{
		return Action->GetStartTimeSeconds();
	}

	return 0.0f;
}

bool UP3PawnActionComponent::IsActionInProgress(EPawnActionType ActionType) const
{
	UP3PawnAction* Action = GetActionByType(ActionType);

	if (!Action)
	{
		return false;
	}

	const bool bInProgress = (Action->GetActionLocalStatus() == EP3PawnActionStatus::InProgress ||
							  Action->GetActionServerStatus() == EP3PawnActionStatus::InProgress);

	return bInProgress;
}

bool UP3PawnActionComponent::HasAction(EPawnActionType ActionType) const
{
	const UP3PawnAction* Action = GetActionByType(ActionType);

	return (Action != nullptr);
}

bool UP3PawnActionComponent::Server_IsActionInQueue(EPawnActionType ActionType) const
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	for (const FStartActionQueueItem& Item : Server_StartActionQueue)
	{
		if (Item.ActionType == ActionType)
		{
			return true;
		}
	}

	return false;
}

bool UP3PawnActionComponent::IsIgnoreMoveInput() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return false;
	}

	return ActiveAction->IsIgnoreMoveInput();
}

bool UP3PawnActionComponent::IsInKnockBack() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return false;
	}

	return ActiveAction->IsKnockBack();
}

bool UP3PawnActionComponent::IsInKnockDown() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return false;
	}

	return ActiveAction->IsInKnockDown();
}

float UP3PawnActionComponent::GetMoveSpeedMultiplier() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return 1.0f;
	}

	return ActiveAction->GetMoveSpeedMultiplier();
}

bool UP3PawnActionComponent::IsMoveAllowed() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->IsMoveAllowed();
}

bool UP3PawnActionComponent::IsRotateAllowed() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->IsRotateAllowed();
}

bool UP3PawnActionComponent::IsJumpAllowed() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->IsJumpAllowed();
}

EP3RequestedActionStatus UP3PawnActionComponent::GetActionStatusByRequestId(int32 RequestId) const
{
	const FP3LastChangedActionStatus* LastActionStatus = nullptr;

	if (IsAutonomousProxy(GetOwner()))
	{
		LastActionStatus = &Autonomous_LastChangedActionStatus;
	}
	else
	{
		LastActionStatus = &Server_LastChangedActionStatus;
	}

	if (RequestId < LastActionStatus->RequestId)
	{
		return EP3RequestedActionStatus::Finished;
	}
	else if (RequestId > LastActionStatus->RequestId)
	{
		return EP3RequestedActionStatus::Requested;
	}
	else
	{
		return LastActionStatus->Status;
	}
}

bool UP3PawnActionComponent::CanStartAction(EPawnActionType ActionType) const
{
	UP3PawnAction* Action = GetActionByType(ActionType);

	if (!Action)
	{
		return false;
	}

	if (Action->GetActionLocalStatus() != EP3PawnActionStatus::Idle || Action->GetActionServerStatus() != EP3PawnActionStatus::Idle)
	{
		return false;
	}

	UP3PawnAction* ActiveAction = GetActiveAction();

	if (ActiveAction)
	{
		// DYLEE NOTE P3-3209 작업 영역 분리
		bool bInterruptable = true;
		if (!CVarP3ActionDataDriven.GetValueOnGameThread())
		{
			const float ActiveActionAge = GetWorld()->GetTimeSeconds() - ActiveAction->GetStartTimeSeconds();
			bInterruptable = Action->CanForceFinishOtherAction(ActiveAction->GetActionType(), ActiveActionAge, nullptr) || ActiveAction->CanForceFinishedByOtherAction(ActionType, nullptr);
		}
		else
		{
			bInterruptable = CanInterruptActiveAction(ActionType, nullptr);
		}

		if (!bInterruptable)
		{
			return false;
		}
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (Character && Character->IsDead() && !Action->CanStartOnDead())
	{
		return false;
	}

	if (Character && Character->IsDowned() && !Action->CanStartOnDowned())
	{
		return false;
	}

	return true;
}

bool UP3PawnActionComponent::CanStartGliding() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->CanStartGliding();
}

bool UP3PawnActionComponent::CanStartJump() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->CanStartJump();
}

bool UP3PawnActionComponent::CanStartClimb() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->CanStartClimb();
}

bool UP3PawnActionComponent::CanSprint() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->CanSprint();
}

bool UP3PawnActionComponent::CanRegenStamina() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return true;
	}

	return ActiveAction->CanRegenStamina();
}


bool UP3PawnActionComponent::IsDisableCollisionWithWorldObject() const
{
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (!ActiveAction)
	{
		return false;
	}

	return ActiveAction->IsDisableCollisionWithWorldObject();
}

int32 UP3PawnActionComponent::StartAction(EPawnActionType ActionType, const FString& DebugContext, const FP3PawnActionStartRequestParams& Params)
{
	ensure(!DebugContext.IsEmpty());

	const UP3PawnAction* Action = GetActionByType(ActionType);

	ActionJsonLog(Display, "Start action",
		TEXT("ActionType"), EnumToString(EPawnActionType, ActionType),
		TEXT("DebugContext"), DebugContext,
		TEXT("Params"), Action ? Action->GetRequestParamsDebugString(Params) : TEXT(""));

	int32 RequestId = 0;

	if (IsAutonomousProxy(GetOwner()))
	{
		if (!P3Core::IsConnectedToDedi(this))
		{
			ActionJsonLog(Error, "Start action requested failed. Not connected yet");
			return 0;
		}
		
		RequestId = Autonomous_StartAction(ActionType, Params);
	}
	else if (P3Core::IsP3NetModeServerInstance(*this))
	{
		RequestId = Server_StartAction(ActionType, Params);
	}
	else
	{
		ensure(0);
		ActionJsonLog(Error, "Start action requested but not autonomouse or server");
		return 0;
	}

	if (bTickScope)
	{
		UP3PawnAction* ActiveAction = GetActiveAction();

		if (ActiveAction && ActiveAction->GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
		{
			// Chain action is started

			const int32 ActiveActionRequestId = ActiveAction->GetServerRequestId()
				? ActiveAction->GetServerRequestId() : ActiveAction->GetAutonomousRequestId();

			if (ChainedActionRequestIds.Num() == 0)
			{
				// This first chain
				ChainedActionRequestIds.Add(ActiveActionRequestId);
			}

			ChainedActionRequestIds.Add(RequestId);

			AP3Character* Character = Cast<AP3Character>(GetOwner());
			AController* Controller = Character ? Character->GetController() : nullptr;
			FAIMessage Msg(UP3PawnActionComponent::AIMessage_ChainedActionRequested, this, ActiveActionRequestId, true);
			FAIMessage::Send(Controller, Msg);
		}
	}
	else
	{
		ChainedActionRequestIds.Empty();
	}

	return RequestId;
}

void UP3PawnActionComponent::Server_StopActionByRequestId(int32 RequestId)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (RequestId <= 0)
	{
		ActionJsonLog(Error, "Invalid request id to stop", TEXT("RequestId"), RequestId);
		return;
	}

	// See if it's still on queue
	for (auto&& Iter = Server_StartActionQueue.CreateIterator(); Iter; ++Iter)
	{
		const FStartActionQueueItem& Item = *Iter;
		if (Item.Params.ServerRequestId == RequestId)
		{
			ActionJsonLog(Verbose, "Queued action is removed with request id",
				TEXT("RequestId"), RequestId,
				TEXT("ActionType"), EnumToString(EPawnActionType, Item.ActionType));

			Iter.RemoveCurrent();
			return;
		}
	}

	// See if current action is that one
	UP3PawnAction* ActiveAction = GetActiveAction();
	if (!ActiveAction)
	{
		return;
	}

	if (ActiveAction->GetServerRequestId() == RequestId)
	{
		ActionJsonLog(Verbose, "Stopping active action with request id",
			TEXT("RequestId"), RequestId,
			TEXT("ActionType"), EnumToString(EPawnActionType, ActiveAction->GetActionType()));

		Server_ForceFinishAction(ActiveAction->GetActionType(), EP3PawnActionResult::Success);
	}
}

void UP3PawnActionComponent::Server_Reset()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	StopAction(GetActiveActionId());
	Server_StartActionQueue.Empty();
}

int32 UP3PawnActionComponent::Autonomous_StartAction(EPawnActionType ActionType, const FP3PawnActionStartRequestParams& Params)
{
	Autonomous_QueuedStartActionType = EPawnActionType::Invalid;

	if (!IsAutonomousProxy(GetOwner()))
	{
		ensure(0);
		return 0;
	}

	UP3PawnAction* Action = GetActionByType(ActionType);

	if (!Action)
	{
		ActionJsonLog(Warning, "Action start failed, no action",
			TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return 0;
	}

	if (!Action->CanStart(Params))
	{
		ActionJsonLog(Warning, "Action start failed, can start condition failed",
			TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return 0;
	}

	// See if any action is still active
	UP3PawnAction* ActiveAction = GetActiveAction();

	if (ActiveAction)
	{
		const float ActiveActionAge = GetWorld()->GetTimeSeconds() - ActiveAction->GetStartTimeSeconds();

		if (ActiveAction->GetActionServerStatus() == EP3PawnActionStatus::Finished && 
			ActiveAction->GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
		{
			// If it's already finished on server side, we can just finish it locally, too

			ActiveAction->ForceFinish(ActiveAction->GetActionServerResult());

			ensure(ActiveAction->GetActionServerStatus() == EP3PawnActionStatus::Idle &&
				ActiveAction->GetActionLocalStatus() == EP3PawnActionStatus::Idle);

			ActiveAction = nullptr;
		}
		else
		{
			bool bInterruptable = true;

			// DYLEE NOTE P3-3209 작업 영역 분리
			if (!CVarP3ActionDataDriven.GetValueOnGameThread())
			{
				bInterruptable = Action->CanForceFinishOtherAction(ActiveAction->GetActionType(), ActiveActionAge, &Params) || ActiveAction->CanForceFinishedByOtherAction(ActionType, &Params);
			}
			else
			{
				bInterruptable = CanInterruptActiveAction(ActionType, &Params);
			}

			if (!bInterruptable)
			{
				if (ActiveAction->CanBeForceFinishedByPlayer())
				{
					// Be a lamb, ask for force finish active action and start requested action again once it's finish
					Autonomous_QueuedStartActionType = ActionType;
					Autonomous_QueuedStartActionParams = Params;

					const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
					ensure(ActorId != INVALID_ACTORID);

					FP3NetForceFinishActionParams NetParams;
					NetParams.ActionId = ActiveAction->GetActionId();
					NetParams.ActionType = ActiveAction->GetActionType();

					P3Core::GetP3World(*this)->Client_SendPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Server_HandleForceFinishCommand);
				}

				ActionJsonLog(Warning, "Action start failed, other action is stil active",
					TEXT("ActionType"), EnumToString(EPawnActionType, ActionType),
					TEXT("ActiveActionType"), EnumToString(EPawnActionType, ActiveAction->GetActionType()));

				return 0;
			}
		}
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (Character && Character->IsDead() && !Action->CanStartOnDead())
	{
		ActionJsonLog(Warning, "Action start failed, character is dead", TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return 0;
	}
	
	if (Character && Character->IsDowned() && !Action->CanStartOnDowned())
	{
		ActionJsonLog(Warning, "Server Action start failed, character is downed", TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return false;
	}

	Action->Autonomous_PreStartAction(Params);

	ActionJsonLog(Display, "Autonomouse Action started. Requesting to server",
		TEXT("ActionType"), EnumToString(EPawnActionType, ActionType),
		TEXT("RequestId"), Autonomous_NextRequestId);

	const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	FP3NetActionStartRequestParams NetParams;
	NetParams.ActionType = ActionType;
	NetParams.RequestParams = Params;
	NetParams.RequestParams.AutonomousRequestId = Autonomous_NextRequestId;

	P3Core::GetP3World(*this)->Client_SendPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Server_HandleRequestCommand);

	Autonomous_NextRequestId = (Autonomous_NextRequestId == MAX_int32) ? 1 : (Autonomous_NextRequestId + 1);

	return NetParams.RequestParams.AutonomousRequestId;
}

int32 UP3PawnActionComponent::Server_StartAction(EPawnActionType ActionType, const FP3PawnActionStartRequestParams& Params)
{
	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		ensure(0);
		return 0;
	}

	FP3PawnActionStartRequestParams QueuedParams = Params;
	QueuedParams.ServerRequestId = Server_NextRequestId;
	
	Server_StartActionQueue.Add(FStartActionQueueItem({ ActionType, QueuedParams }));

	Server_NextRequestId = (Server_NextRequestId == MAX_int32) ? 1 : (Server_NextRequestId + 1);

	return QueuedParams.ServerRequestId;
}

bool UP3PawnActionComponent::StopAction(int32 ActionId, const FP3PawnActionStopRequestParams& Params)
{
	if (!IsAutonomousProxy(GetOwner()) && !IsAuthority(GetOwner()))
	{
		ensureMsgf(0, TEXT("Only Server or owner can stop action"));
		ActionJsonLog(Warning, "Start action failed. Not an owner");
		return false;
	}

	UP3PawnAction* Action = GetActiveAction();

	if (!Action)
	{
		ActionJsonLog(Warning, "Action stop failed, no action");
		return false;
	}

	if (Action->GetActionId() != ActionId)
	{
		ActionJsonLog(Warning, "Server Action stop failed, action id not match",
			TEXT("ActionId"), ActionId, TEXT("ActiveActionId"), Action->GetActionId());
		return false;
	}
	
	ActionJsonLog(Display, "Stop action",
		TEXT("ActionType"), EnumToString(EPawnActionType, Action->GetActionType()));

	if (P3Core::IsP3NetModeServerInstance(*GetWorld()))
	{
		ensure(Action->GetActionServerStatus() == EP3PawnActionStatus::InProgress);

		Server_StopActionInternal(Action->GetActionId(), Params);
	}
	else
	{
		ensure(Action->GetActionLocalStatus() == EP3PawnActionStatus::InProgress);

		const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
		ensure(ActorId != INVALID_ACTORID);

		FP3NetActionStopRequestParams NetParams;
		NetParams.ActionId = Action->GetActionId();
		NetParams.RequestParams = Params;

		P3Core::GetP3World(*this)->Client_SendPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Server_HandleStopCommand);
	}

	return true;
}

bool UP3PawnActionComponent::Server_ForceFinishAction(EPawnActionType ActionType, EP3PawnActionResult Result)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	UP3PawnAction* Action = GetActionByType(ActionType);

	if (!Action)
	{
		ActionJsonLog(Warning, "Force finish action failed, no action",
			TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return false;
	}

	if (Action->GetActionServerStatus() == EP3PawnActionStatus::Idle)
	{
		ActionJsonLog(Warning, "Force finish action failed, already in idle",
			TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return false;
	}

	ActionJsonLog(Display, "Server force finishing action", 
		TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));

	const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	FP3NetForceFinishAction NetParams;
	NetParams.ActionId = Action->GetActionId();
	NetParams.ActionType = Action->GetActionType();
	NetParams.Result = Result;

	P3Core::GetP3World(*this)->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Client_HandleForceFinishAction);

	ForceFinishActionInternal(Action->GetActionId(), Action->GetActionType(), Result);

	return true;
}

UP3PawnAction* UP3PawnActionComponent::GetActionByType(EPawnActionType Type) const
{
	const int32 Index = StaticCast<int32>(Type);
	if (ensure(Actions.IsValidIndex(Index)))
	{
		return Actions[Index];
	}

	return nullptr;
}

UP3PawnAction* UP3PawnActionComponent::GetActiveAction() const
{
	for (UP3PawnAction* Action : Actions)
	{
		if (!Action)
		{
			continue;
		}

		if (Action->GetActionLocalStatus() != EP3PawnActionStatus::Idle ||
			Action->GetActionServerStatus() != EP3PawnActionStatus::Idle)
		{
			return Action;
		}
	}

	return nullptr;
}

void UP3PawnActionComponent::Server_HandleRequestCommand(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetActionStartRequestParams NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		FP3PawnActionStartRequestParams CopiedParams = NetParams.RequestParams;
		_UpdatePointerFromId(CopiedParams, *this);

		const bool bSucceed = Server_StartActionInternal(NetParams.ActionType, CopiedParams);

		ActionJsonLog(Display, "Server handled request command", 
			TEXT("ActionType"), EnumToStringShort(EPawnActionType, NetParams.ActionType),
			TEXT("RequestId"), NetParams.RequestParams.AutonomousRequestId,
			TEXT("Result"), bSucceed ? TEXT("Success") : TEXT("Failed"));

		if (!bSucceed)
		{
			const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
			ensure(ActorId != INVALID_ACTORID);

			FP3NetStartActionFailed NetStartFailed;
			NetStartFailed.RequestId = NetParams.RequestParams.AutonomousRequestId;
			NetStartFailed.ActionType = NetParams.ActionType;

			P3Core::GetP3World(*this)->Server_SendPacketToPlayerReliable(Params.NetConnInfo, this, ActorId, GetOwner(), NetStartFailed, EP3NetComponentType::Action, &UP3PawnActionComponent::Client_HandleStartActionFailed);
		}
	}
}

void UP3PawnActionComponent::Server_HandleStopCommand(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetActionStopRequestParams NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		const bool bSucceed = Server_StopActionInternal(NetParams.ActionId, NetParams.RequestParams);

		if (!bSucceed)
		{
			// TODO: ClientStopActionFailed(ActionId);
		}
	}
}

void UP3PawnActionComponent::Server_HandleForceFinishCommand(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetForceFinishActionParams NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		// TODO: let player finish any actions for now

		bool bSuccessfullyFinished = false;

		UP3PawnAction* ActiveAction = GetActiveAction();

		if (ActiveAction
			&& ActiveAction->GetActionId() == NetParams.ActionId
			&& ActiveAction->GetActionType() == NetParams.ActionType
			&& ActiveAction->CanBeForceFinishedByPlayer())
		{
			Server_ForceFinishAction(NetParams.ActionType, EP3PawnActionResult::Success);
		}
	}
}

void UP3PawnActionComponent::Client_HandleStartActionFailed(const FP3DediToClientHandlerParams& Params)
{
	FP3NetStartActionFailed NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		ActionJsonLog(Warning, "Server failed to start action",
			TEXT("ActionType"), EnumToString(EPawnActionType, NetParams.ActionType));

		ensure(IsLocalControlledActor(GetOwner()));

		UP3PawnAction* Action = GetActionByType(NetParams.ActionType);

		if (!Action)
		{
			ensureMsgf(0, TEXT("Invalid action type: %d"), static_cast<int32>(NetParams.ActionType));
			return;
		}

		if (IsAutonomousProxy(GetOwner()))
		{
			Action->Autonomous_FailedToStart();
		}

		if (NetParams.RequestId != 0)
		{
			OnRequestedActionStatusChanged.Broadcast(NetParams.RequestId, EP3RequestedActionStatus::StartFailed);

			AP3Character* Character = Cast<AP3Character>(GetOwner());
			AController* Controller = Character ? Character->GetController() : nullptr;
			FAIMessage Msg(UP3PawnActionComponent::AIMessage_ActionStartFailed, this, NetParams.RequestId, true);
			FAIMessage::Send(Controller, Msg);

			Autonomous_LastChangedActionStatus.RequestId = NetParams.RequestId;
			Autonomous_LastChangedActionStatus.Status = EP3RequestedActionStatus::StartFailed;
		}
	}
}

void UP3PawnActionComponent::Client_HandleStartAction(const FP3DediToClientHandlerParams& Params)
{
	FP3NetStartAction NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		StartActionInternal(NetParams.ActionType, NetParams.Params);

		if (NetParams.Params.RequestParams.AutonomousRequestId != 0 && IsAutonomousProxy(GetOwner()))
		{
			OnRequestedActionStatusChanged.Broadcast(NetParams.Params.RequestParams.AutonomousRequestId, EP3RequestedActionStatus::Started);

			AP3Character* Character = Cast<AP3Character>(GetOwner());
			AController* Controller = Character ? Character->GetController() : nullptr;
			FAIMessage Msg(UP3PawnActionComponent::AIMessage_ActionStarted, this, NetParams.Params.RequestParams.AutonomousRequestId, true);
			FAIMessage::Send(Controller, Msg);

			Autonomous_LastChangedActionStatus.RequestId = NetParams.Params.RequestParams.AutonomousRequestId;
			Autonomous_LastChangedActionStatus.Status = EP3RequestedActionStatus::Started;
		}
	}
}

void UP3PawnActionComponent::Client_HandleStopAction(const FP3DediToClientHandlerParams& Params)
{
	FP3NetStopAction NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		StopActionInternal(NetParams.ActionId, NetParams.Params);
	}
}

void UP3PawnActionComponent::Client_HandleFinishAction(const FP3DediToClientHandlerParams& Params)
{
	FP3NetFinishAction NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		FinishActionInternal(NetParams.ActionId, NetParams.ActionType, NetParams.Result);
	}
}

void UP3PawnActionComponent::Client_HandleForceFinishAction(const FP3DediToClientHandlerParams& Params)
{
	FP3NetForceFinishAction NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		ForceFinishActionInternal(NetParams.ActionId, NetParams.ActionType, NetParams.Result);
	}
}

void UP3PawnActionComponent::Client_HandleProgressAction(const FP3DediToClientHandlerParams& Params)
{
	FP3NetProgressAction NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		ProgressActionInternal(NetParams.ActionId, NetParams.ActionType, NetParams.StepIndex);
	}
}

bool UP3PawnActionComponent::Server_StartActionInternal(EPawnActionType StartActionType, const FP3PawnActionStartRequestParams& Params)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (CVarP3ActionTestStartFailOnServer.GetValueOnGameThread() == 1)
	{
		ActionJsonLog(Display, "Action start request is denied due to test flag", TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType));
		return false;
	}

	UP3PawnAction* Action = GetActionByType(StartActionType);

	if (!Action)
	{
		ActionJsonLog(Warning, "Server Action start failed, no action", TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType));
		return false;
	}

	// See if any action is still active
	{
		UP3PawnAction* ActiveAction = GetActiveAction();

		if (ActiveAction)
		{
			// DYLEE NOTE P3-3209 작업 영역 분리
			bool bInterruptable = false;
			if (!CVarP3ActionDataDriven.GetValueOnGameThread())
			{
				const float ActiveActionAge = GetWorld()->GetTimeSeconds() - ActiveAction->GetStartTimeSeconds();
				bInterruptable = Action->CanForceFinishOtherAction(ActiveAction->GetActionType(), ActiveActionAge, &Params) || ActiveAction->CanForceFinishedByOtherAction(StartActionType, &Params);
			}
			else
			{
				bInterruptable = CanInterruptActiveAction(StartActionType, &Params);
			}

			if (bInterruptable)
			{
				const bool bActiveActionFinished = Server_ForceFinishAction(ActiveAction->GetActionType(), EP3PawnActionResult::Success);

				if (!bActiveActionFinished)
				{
					ActionJsonLog(Warning, "Server Action start failed, other action is stil active and failed to force finish",
						TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType),
						TEXT("ActiveActionType"), EnumToString(EPawnActionType, ActiveAction->GetActionType()),
						TEXT("ActionDebugString"), ActiveAction->GetDebugString());
					return false;
				}
			}
			else
			{
				ActionJsonLog(Warning, "Server Action start failed, other action is stil active and cannot force finish",
					TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType),
					TEXT("ActiveActionType"), EnumToString(EPawnActionType, ActiveAction->GetActionType()),
					TEXT("ActionDebugString"), ActiveAction->GetDebugString());
				return false;
			}
		}
	}

	if (Action->GetActionLocalStatus() != EP3PawnActionStatus::Idle || Action->GetActionServerStatus() != EP3PawnActionStatus::Idle)
	{
		ActionJsonLog(Warning, "Server Action start failed, action not in idle", TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType));
		return false;
	}

	if (!Action->CanStart(Params))
	{
		ActionJsonLog(Warning, "Server Action start failed, can start condition failed", TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType));
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (Character && Character->IsDead() && !Action->CanStartOnDead())
	{
		ActionJsonLog(Warning, "Server Action start failed, character is dead", TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType));
		return false;
	}

	Server_CurrentActionId = (Server_CurrentActionId == MAX_int32) ? 1 : (Server_CurrentActionId + 1);

	ActionJsonLog(Display, "Action started on server",
		TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType),
		TEXT("ActionId"), Server_CurrentActionId);

	FP3PawnActionStartMulticastParams StartParams;
	StartParams.ActionId = Server_CurrentActionId;
	StartParams.RequestParams = Params;

	Action->Server_FillAuthorityStartParams(StartParams.RequestParams, StartParams.AuthorityParams);

	const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	FP3NetStartAction NetParams;
	NetParams.ActionType = StartActionType;
	NetParams.Params = StartParams;

	P3Core::GetP3World(*this)->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Client_HandleStartAction);

	StartActionInternal(StartActionType, StartParams);

	return true;
}

bool UP3PawnActionComponent::Server_StopActionInternal(int32 ActionId, const FP3PawnActionStopRequestParams& Params)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	UP3PawnAction* Action = GetActiveAction();

	if (!Action)
	{
		ActionJsonLog(Warning, "Server Action stop failed, no action", TEXT("ActionId"), ActionId);
		return false;
	}

	if (Action->GetActionId() != ActionId)
	{
		ActionJsonLog(Warning, "Server Action stop failed, action id not match",
			TEXT("ActionId"), ActionId, TEXT("ActiveActionId"), Action->GetActionId());
		return false;
	}

	FP3PawnActionStopMulticastParams StopParams;
	StopParams.ActionId = ActionId;
	StopParams.RequestParams = Params;

	Action->Server_FillAuthorityStopParams(StopParams.AuthorityParams);

	const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	FP3NetStopAction NetParams;
	NetParams.ActionId = ActionId;
	NetParams.Params = StopParams;

	P3Core::GetP3World(*this)->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetParams, EP3NetComponentType::Action, &UP3PawnActionComponent::Client_HandleStopAction);

	StopActionInternal(ActionId, StopParams);

	return true;
}

void UP3PawnActionComponent::StartActionInternal(EPawnActionType StartActionType, const FP3PawnActionStartMulticastParams& Params)
{
	if (GetActionByType(StartActionType) == nullptr)
	{
		ensureMsgf(0, TEXT("Invalid start action type: %d"), static_cast<int32>(StartActionType));
		return;
	}

	FP3PawnActionStartMulticastParams CopiedParams = Params;
	_UpdatePointerFromId(CopiedParams.RequestParams, *this);

	if (P3Core::IsP3NetModeClient(*GetOwner()))
	{
		// If any action is still on going in local, force finish it
		UP3PawnAction* ActiveAction = GetActiveAction();

		if (ActiveAction)
		{
			if (ActiveAction->GetActionId() == 0)
			{
				// This action must be started by me
				ensure(IsAutonomousProxy(GetOwner()));
				ensure((ActiveAction->GetActionLocalStatus() == EP3PawnActionStatus::InProgress || ActiveAction->GetActionLocalStatus() == EP3PawnActionStatus::Finished)
					&& ActiveAction->GetActionServerStatus() == EP3PawnActionStatus::Idle);
			}
			else
			{
				// This action must be finished by server but not yet finished in local, lets force finish it
				if (ensure(ActiveAction->GetActionLocalStatus() == EP3PawnActionStatus::InProgress && ActiveAction->GetActionServerStatus() == EP3PawnActionStatus::Finished))
				{
					ActiveAction->ForceFinish(ActiveAction->GetActionServerResult());

					ensure(ActiveAction->GetActionLocalStatus() == EP3PawnActionStatus::Idle);
					ensure(ActiveAction->GetActionServerStatus() == EP3PawnActionStatus::Idle);
				}
			}
		}
	}
	else
	{
		// In case of servers, there should not be any active action. This should be checked at ServerStartAction
		ensure(!GetActiveAction());
	}

	UP3PawnAction* Action = GetActionByType(StartActionType);

	if (!Action)
	{
		ActionJsonLog(Warning, "Action failed to start", TEXT("Error"), TEXT("No action instance"), TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType));
		return;
	}

	if (!ensure(Action->GetActionServerStatus() == EP3PawnActionStatus::Idle ||
		        Action->GetActionServerStatus() == EP3PawnActionStatus::Finished))
	{
		ActionJsonLog(Warning, "Action failed to start", 
			TEXT("Error"), TEXT("Action is not in idle"), 
			TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType),
			TEXT("LocalStatus"), EnumToStringShort(EP3PawnActionStatus, Action->GetActionLocalStatus()),
			TEXT("ServerStatus"), EnumToStringShort(EP3PawnActionStatus, Action->GetActionServerStatus()));
		return;
	}

	ensure(Action->GetActionLocalStatus() == EP3PawnActionStatus::Idle || IsLocalControlledActor(GetOwner()));
	ensure(Action->GetActionServerStatus() == EP3PawnActionStatus::Idle);

	Action->Multicast_StartAction(CopiedParams);

	ActionJsonLog(Display, "Action started by multicast", 
		TEXT("ActionId"), CopiedParams.ActionId, 
		TEXT("ActionType"), EnumToString(EPawnActionType, StartActionType));
}

void UP3PawnActionComponent::StopActionInternal(int32 ActionId, const FP3PawnActionStopMulticastParams& Params)
{
	UP3PawnAction* Action = GetActiveAction();

	if (!Action)
	{
		ActionJsonLog(Warning, "Action failed to stop", TEXT("Error"), TEXT("No action instance"), TEXT("ActionId"), ActionId);
		return;
	}

	if (Action->GetActionId() != ActionId)
	{
		ActionJsonLog(Warning, "Action stop failed, action id not match",
			TEXT("ActionId"), ActionId, TEXT("ActiveActionId"), Action->GetActionId());
		return;
	}

	Action->Multicast_StopAction(Params);

	ActionJsonLog(Display, "Action stopped by multicast",
		TEXT("ActionId"), ActionId);
}

void UP3PawnActionComponent::FinishActionInternal(int32 ActionId, EPawnActionType ActionType, EP3PawnActionResult Result)
{
	UP3PawnAction* Action = GetActionByType(ActionType);

	if (!Action)
	{
		ActionJsonLog(Warning, "Action failed to finish", 
			TEXT("Error"), TEXT("No action instance"), 
			TEXT("ActionType"), EnumToString(EPawnActionType, ActionType),
			TEXT("ActionId"), ActionId);
		return;
	}

	if (Action->GetActionServerStatus() != EP3PawnActionStatus::InProgress)
	{
		ActionJsonLog(Warning, "Action failed to finish", 
			TEXT("Error"), TEXT("Action is not in progress"),
			TEXT("ActionType"), EnumToString(EPawnActionType, ActionType),
			TEXT("ActionId"), ActionId);
		return;
	}

	ActionJsonLog(Display, "Action finished by multicast", 
		TEXT("ActionType"), EnumToString(EPawnActionType, ActionType),
		TEXT("ActionId"), ActionId);

	Action->Multicast_Finish(Result);

	if (IsAutonomousProxy(GetOwner()))
	{
		if (Action->GetActionLocalStatus() == EP3PawnActionStatus::Idle && Action->GetActionServerStatus() == EP3PawnActionStatus::Idle)
		{
			if (Autonomous_QueuedStartActionType != EPawnActionType::Invalid)
			{
				StartAction(Autonomous_QueuedStartActionType, _FUNCTION_TEXT, Autonomous_QueuedStartActionParams);

				ensure(Autonomous_QueuedStartActionType == EPawnActionType::Invalid);
			}
		}
	}
}

void UP3PawnActionComponent::ForceFinishActionInternal(int32 ActionId, EPawnActionType ActionType, EP3PawnActionResult Result)
{
	UP3PawnAction* Action = GetActionByType(ActionType);

	if (!Action)
	{
		ActionJsonLog(Warning, "Action failed to force finish", TEXT("Error"), TEXT("No action instance"), TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return;
	}

	if (Action->GetActionServerStatus() == EP3PawnActionStatus::Idle)
	{
		ActionJsonLog(Warning, "Action failed to force finish", TEXT("Error"), TEXT("Action is already in idle"), TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return;
	}

	ActionJsonLog(Display, "Action force finished by multicast", 
		TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));

	if (Action->GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
	{
		Action->ForceFinish(Result);
	}

	ensure(Action->GetActionLocalStatus() != EP3PawnActionStatus::InProgress);

	if (IsAutonomousProxy(GetOwner()))
	{
		if (Action->GetActionLocalStatus() == EP3PawnActionStatus::Idle && Action->GetActionServerStatus() == EP3PawnActionStatus::Idle)
		{
			if (Autonomous_QueuedStartActionType != EPawnActionType::Invalid)
			{
				StartAction(Autonomous_QueuedStartActionType, _FUNCTION_TEXT, Autonomous_QueuedStartActionParams);

				ensure(Autonomous_QueuedStartActionType == EPawnActionType::Invalid);
			}
		}
	}
}

void UP3PawnActionComponent::ProgressActionInternal(int32 ActionId, EPawnActionType ActionType, int32 StepIndex)
{
	UP3PawnAction* Action = GetActionByType(ActionType);

	if (!Action)
	{
		ActionJsonLog(Warning, "Action failed to progress", TEXT("Error"), TEXT("No action instance"), TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return;
	}

	if (Action->GetActionId() != ActionId)
	{
		ActionJsonLog(Warning, "Action failed to progress", TEXT("Error"), TEXT("Id not matching"), TEXT("RequestedId"), ActionId, TEXT("LocalId"), Action->GetActionId());
		return;
	}

	if (Action->GetActionServerStatus() == EP3PawnActionStatus::Idle)
	{
		ActionJsonLog(Warning, "Action failed to progress", TEXT("Error"), TEXT("Action is in idle"), TEXT("ActionType"), EnumToString(EPawnActionType, ActionType));
		return;
	}
	
	Action->Multicast_Progress(StepIndex);
}
