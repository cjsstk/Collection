// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3Core.h"

class FNetBitWriter;
class FNetBitReader;

enum class EP3UDPLocalMessageType : uint8
{
	None = 0,
	Shutdown = 1,
	Listen = 2,
	Connect = 3,
	Disconnect = 4,
};

enum class EP3UDPMessageType : uint8
{
	None = 0,
	Close = 1,
	Hello = 2,
	Welcome = 3,
	Ping = 4,
	Pong = 5,
	ConsoleCommand = 9,
	UnrealRaw = 10,
	WorldMessage = 11,
	ZoneChange = 12,
};

struct IP3UDPMessage
{
	virtual EP3UDPMessageType GetType() const = 0;
	virtual int32 GetMaxBits() const = 0;
	virtual void Serialize(FNetBitWriter& Writer) = 0;
	virtual void Deserialize(FNetBitReader& Reader) = 0;
};

struct FP3UDPMessage : public IP3UDPMessage
{
	EP3UDPMessageType Type = EP3UDPMessageType::None;

	explicit FP3UDPMessage(EP3UDPMessageType InType) : Type(InType) {}

	virtual ~FP3UDPMessage() {}

	virtual int32 GetMaxBits() const override { return 1024; }
};

struct FP3UDPMessageClose final : public FP3UDPMessage
{
	FP3UDPMessageClose();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::Close; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessageHello final : public FP3UDPMessage
{
	uint8 IsLittleEndian = 0;
	FString PlayerId;

	FP3UDPMessageHello();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::Hello; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessageWelcome final : public FP3UDPMessage
{
	FP3UDPMessageWelcome();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::Welcome; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessagePing final : public FP3UDPMessage
{
	uint32 PingId = 0;
	int32 PingTimeMsec = 0;

	FP3UDPMessagePing();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::Ping; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessagePong final : public FP3UDPMessage
{
	uint32 PingId = 0;
	float FrameTimeMsec = 0.f;

	FP3UDPMessagePong();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::Pong; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessageConsoleCommand final : public FP3UDPMessage
{
	FString Command;

	FP3UDPMessageConsoleCommand();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::ConsoleCommand; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessageUnrealRaw final : public FP3UDPMessage
{
	FP3UDPMessageUnrealRaw();

	actorid ActorId = INVALID_ACTORID;
	uint16 ComponentType = 0;
	FString FunctionName;
	TArray<uint8> Buffer;

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::UnrealRaw; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessageWorld final : public FP3UDPMessage
{
	TArray<uint8> Buffer;

	FP3UDPMessageWorld();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::WorldMessage; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};

struct FP3UDPMessageZoneChange final : public FP3UDPMessage
{
	FP3UDPMessageZoneChange();

	virtual EP3UDPMessageType GetType() const override { return EP3UDPMessageType::ZoneChange; }
	virtual int32 GetMaxBits() const override;
	virtual void Serialize(FNetBitWriter& Writer) override;
	virtual void Deserialize(FNetBitReader& Reader) override;
};
