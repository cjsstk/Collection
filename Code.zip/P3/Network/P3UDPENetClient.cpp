// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UDPENetClient.h"

#include "CoreNet.h"

#include "P3GameInstance.h"
#include "P3ClientWorld.h"
#include "P3UDPMessage.h"
#include "P3World.h"
#include "P3Log.h"
#include "pb/game.pb.h"

extern TAutoConsoleVariable<float> CVarP3PingUpdatePeriodSecondsDebug;

void UP3UDPENetClient::Initialize(UP3GameInstance* InGameInstance)
{
	Super::Initialize(InGameInstance);

	InitThread();
}

void UP3UDPENetClient::InitThread()
{
	if (bUseThread)
	{
		check(!ENetThreadRunnable.IsValid() && !ENetThread.IsValid());

		ENetThreadRunnable = MakeUnique<FP3ENetThreadRunnable>(*this);

		ENetThread.Reset(FRunnableThread::Create(ENetThreadRunnable.Get(), *FString::Printf(TEXT("UP3UDPENetClient Receive Thread")), 0, TPri_AboveNormal));
	}
}

void UP3UDPENetClient::Shutdown()
{
	if (CurrentConnId != INVALID_NETCONNID)
	{
		FP3UDPMessageClose MessageClose;
		SendMessageToNetworkChannel(CurrentConnId, MessageClose);
	}

	Super::Shutdown();
}

void UP3UDPENetClient::Close(const P3NetConnId NetConnId/* = INVALID_NETCONNID*/)
{
	CHECK_GAME_THREAD;

	ensure(NetConnId == INVALID_NETCONNID);

	UP3UDPENet::Close(P3NetConnId(CurrentConnId));

	UE_LOG(P3UDPNetLog, Display, TEXT("Close server connection: %d"), CurrentConnId.X);
}

void UP3UDPENetClient::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (Client_IsConnected())
	{
		const FDateTime Now = FDateTime::Now();

		const FTimespan TimeSinceUpdate = Now - PingTime.LastPingSentTime;

		if (TimeSinceUpdate.GetTotalSeconds() > CVarP3PingUpdatePeriodSecondsDebug.GetValueOnGameThread())
		{
			PingTime.LastPingSentTime = Now;

			FP3UDPMessagePing MessagePing;
			MessagePing.PingId = ++PingTime.PingId;
			MessagePing.PingTimeMsec = PingTime.PingTimeMsec;
			SendMessageToGameChannel(CurrentConnId, MessagePing, ENET_PACKET_FLAG_UNSEQUENCED);
		}
	}

	UpdateStat();
}

bool UP3UDPENetClient::Init(UP3World* InP3World, const FString& InHost/* = TEXT("")*/, int32 InPort/* = 0*/)
{
	CHECK_GAME_THREAD;

	if (!ensure(InP3World) || !ensure(InP3World->GetClientWorld()))
	{
		return false;
	}

	ensure(P3World == nullptr);

	P3World = InP3World;

	ShutdownUnrealNetDriver(P3World->GetWorld());

	SetHost(InHost, InPort);

	ensure(CurrentConnId == INVALID_NETCONNID);

	CurrentConnId = INVALID_NETCONNID;

	SendLocalMessage(EP3UDPLocalMessageType::Connect);

	ConnStatus = EP3NetConnStatus::Connecting;

	return true;
}

void UP3UDPENetClient::Update()
{
	Flush();
	Poll();
}

bool UP3UDPENetClient::Client_SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bForceReliable)
{
	uint32 SentBytes = SendUnrealRawMessage(CurrentConnId, ActorId, Actor, Buffer, Header, bForceReliable);

	if (SentBytes == 0)
	{
		return false;
	}

	StatSentBytes += SentBytes;
	++StatSentMessages;

	return true;
}

void UP3UDPENetClient::HandleConnectEvent(const ENetEvent& Event)
{
	CheckThread();

	if (!ensure(Event.type == ENET_EVENT_TYPE_CONNECT))
	{
		return;
	}

	Super::HandleConnectEvent(Event);

	FP3UDPMessageHello MessageHello;

	bool IsLittleEndian = uint8(PLATFORM_LITTLE_ENDIAN);
	check(IsLittleEndian == !!IsLittleEndian);

	MessageHello.IsLittleEndian = IsLittleEndian;

	if (GameInstance)
	{
		if (GameInstance->GetGameNetMode() == EP3NetMode::Standalone || GameInstance->GetGameNetMode() == EP3NetMode::ListenServer)
		{
			MessageHello.PlayerId = TEXT("Standalone");
		}
	}

	SendMessageOnNetworkThread(Event.peer, MessageHello);
}

void UP3UDPENetClient::HandleDisconnectEvent(const ENetEvent& Event)
{
	CheckThread();

	if (!ensure(Event.type == ENET_EVENT_TYPE_DISCONNECT))
	{
		return;
	}

	if (ENetThreadRunnable.IsValid())
	{
		ENetThreadRunnable->Cleanup(true);
	}

	Super::HandleDisconnectEvent(Event);

	if (NetHost.IsValid())
	{
		NetHost.Reset();
	}
}

void UP3UDPENetClient::HandleReceiveEvent(const ENetEvent& Event)
{
	CheckThread();

	if (!ensure(Event.type == ENET_EVENT_TYPE_RECEIVE))
	{
		return;
	}

	if (!ensure(Event.packet))
	{
		return;
	}

	ENetPeer* Peer = Event.peer;

	if (!ensure(Peer))
	{
		return;
	}

	EP3ENetChannelType ChannelType = StaticCast<EP3ENetChannelType>(Event.channelID);

	if (ChannelType == EP3ENetChannelType::Game)
	{
		Super::HandleReceiveEvent(Event);
	}
	else if (ChannelType == EP3ENetChannelType::Network)
	{
		if (Event.packet->data && Event.packet->dataLength > 0)
		{
			const P3NetConnId ConnId = FP3ENetUtil::PeerIdToNetConnId(Peer);

			bool bNeedsByteSwapping = false;

			const P3ENetPeerSharedPtr NetPeer = GetNetPeer(ConnId);

			if (!NetPeer.IsValid() || !NetPeer->IsConnected())
			{
				return;
			}

			bNeedsByteSwapping = NetPeer->bNeedsByteSwapping;

			EP3UDPMessageType MessageType = EP3UDPMessageType::None;

			const uint32 DataLen = StaticCast<uint32>(Event.packet->dataLength);

			const uint32 BitSize = DataLen << 3;

			FNetBitReader Reader(nullptr, Event.packet->data, BitSize);

			Reader.SetByteSwapping(bNeedsByteSwapping);

			Reader << MessageType;

			if (MessageType == EP3UDPMessageType::Close)
			{
				FP3UDPMessageClose MessageClose;

				MessageClose.Deserialize(Reader);

				Disconnect(Peer);
			}
			else if (MessageType == EP3UDPMessageType::Welcome)
			{
				FP3UDPMessageWelcome MessageWelcome;

				MessageWelcome.Deserialize(Reader);
			}
			else
			{
				ensure(0);
				UE_LOG(P3UDPNetLog, Warning, TEXT("Invalid UDP Message Type: %u"), MessageType);
			}
		}
	}
}

void UP3UDPENetClient::HandleConnectOnGameThread(const FP3ENetConnectEvent* Event)
{
	CHECK_GAME_THREAD;

	if (!ensure(Event))
	{
		return;
	}

	if (Event->bSuccess)
	{
		CurrentConnId = Event->ConnId;

		if (P3World && P3World->GetClientWorld())
		{
			P3World->GetClientWorld()->OnConnected();
		}

		ConnStatus = EP3NetConnStatus::Connected;
	}
	else
	{
		Zone = NAME_None;
		CurrentConnId = INVALID_NETCONNID;
		ConnStatus = EP3NetConnStatus::Closed;

		if (P3World && P3World->GetClientWorld())
		{
			P3World->GetClientWorld()->OnConnectFailed();
			P3World = nullptr;
		}
	}
}

void UP3UDPENetClient::HandleDisconnectOnGameThread(const FP3ENetDisconnectEvent* Event)
{
	CHECK_GAME_THREAD;

	if (!ensure(Event))
	{
		return;
	}

	if (P3World && P3World->GetClientWorld())
	{
		P3World->GetClientWorld()->OnDisconnected();
		P3World = nullptr;
	}

	FString AddressStr = FP3ENetUtil::GetAddressFromENetAddress(Event->Address);

	P3JsonUDPLog(Display, "Disconnected from server", TEXT("ConnId"), Event->ConnId.X, TEXT("Host"), *AddressStr, TEXT("Port"), Event->Address.port);

	CurrentConnId = INVALID_NETCONNID;
	ConnStatus = EP3NetConnStatus::Closed;
}

void UP3UDPENetClient::HandleReceiveOnGameThread(const FP3ENetReceiveEvent* Event)
{
	CHECK_GAME_THREAD;

	if (!ensure(Event))
	{
		return;
	}

	const P3NetConnId ConnId = Event->ConnId;

	EP3UDPMessageType MessageType = EP3UDPMessageType::None;

	TArray<uint8> Buffer(Event->Buffer);

	const int32 CountBits = Buffer.Num() << 3;

	FNetBitReader Reader(nullptr, Buffer.GetData(), CountBits);

	Reader.SetByteSwapping(Event->bNeedsByteSwapping);

	Reader << MessageType;

	switch (MessageType)
	{
	case EP3UDPMessageType::Pong:
	{
		FP3UDPMessagePong MessagePong;

		MessagePong.Deserialize(Reader);

		if (MessagePong.PingId == PingTime.PingId)
		{
			const FDateTime Now = FDateTime::Now();

			PingTime.PingTimeMsec = FMath::FloorToInt((Now - PingTime.LastPingSentTime).GetTotalMilliseconds());
			PingTime.ServerFrameTimeMsec = MessagePong.FrameTimeMsec;
			PingTime.LastPingUpdatedTime = Now;
		}

		/** ENet 내부에서 측정되는 RTT값이기 때문에 PingId와 상관없이 복사한다. */
		PingTime.RoundTripTimeMsec = Event->RoundTripTimeMsec;

		break;
	}
	case EP3UDPMessageType::UnrealRaw:
	{
		if (P3World == nullptr)
		{
			UWorld* World = GameInstance ? GameInstance->GetCurrentWorld() : nullptr;

			if (!ensure(World))
			{
				return;
			}

			P3World = P3Core::GetP3World(*World);
		}

		if (!ensure(P3World))
		{
			return;
		}

		FP3UDPMessageUnrealRaw MessageUnrealRaw;

		MessageUnrealRaw.Deserialize(Reader);

		FP3NetHeader Header;
		Header.ComponentType = StaticCast<EP3NetComponentType>(MessageUnrealRaw.ComponentType);
		Header.HandlerFunctionName = *MessageUnrealRaw.FunctionName;

		FP3NetConnInfo NetConnInfo;
		NetConnInfo.UDPConnId = ConnId;

		P3World->Client_HandlePacketBuffer(NetConnInfo, MessageUnrealRaw.ActorId, nullptr, MessageUnrealRaw.Buffer, Header);

		break;
	}
	case EP3UDPMessageType::WorldMessage:
	{
		FP3UDPMessageWorld MessageWorld;

		MessageWorld.Deserialize(Reader);

		HandleWorldMessage(MessageWorld);

		break;
	}
	case EP3UDPMessageType::ZoneChange:
	{
		FP3UDPMessageZoneChange MessageZoneChange;

		MessageZoneChange.Deserialize(Reader);

		Close();

		break;
	}
	default:
	{
		ensure(0);
		UE_LOG(P3UDPNetLog, Warning, TEXT("Invalid UDP Message Type: %u"), MessageType);
		return;
	}
	}

	StatRecvBytes += Reader.GetNumBytes();
	++StatRecvMessages;
}

bool UP3UDPENetClient::IsValid() const
{
	return Super::IsValid() && (NetHost->connectedPeers == 1);
}

bool UP3UDPENetClient::Client_IsConnected() const
{
	return (ConnStatus == EP3NetConnStatus::Connected) && (CurrentConnId != INVALID_NETCONNID);
}

EP3NetConnStatus UP3UDPENetClient::Client_GetConnStatus() const
{
	return ConnStatus;
}

FP3NetStat UP3UDPENetClient::GetAvgConnStat() const
{
	return NetStat;
}

void UP3UDPENetClient::UpdateStat()
{
	const double CurrentRealtimeSeconds = FPlatformTime::Seconds();
	const float RealTime = StaticCast<float>(CurrentRealtimeSeconds - StatUpdateTime);

	if (RealTime >= 1.0f)
	{
		NetStat.SentBytesPerSecond = FMath::TruncToInt(static_cast<float>(StatSentBytes) / RealTime);
		NetStat.RecvBytesPerSecond = FMath::TruncToInt(static_cast<float>(StatRecvBytes) / RealTime);
		NetStat.SentMessagesPerSecond = FMath::TruncToInt(static_cast<float>(StatSentMessages) / RealTime);
		NetStat.RecvMessagesPerSecond = FMath::TruncToInt(static_cast<float>(StatRecvMessages) / RealTime);

		StatSentBytes = 0;
		StatRecvBytes = 0;
		StatSentMessages = 0;
		StatRecvMessages = 0;

		StatUpdateTime = CurrentRealtimeSeconds;
	}
}

void UP3UDPENetClient::SendConsoleCommand(const FString& Command)
{
	FP3UDPMessageConsoleCommand MessageCommand;
	MessageCommand.Command = Command;
	SendMessageToGameChannel(CurrentConnId, MessageCommand);
}

void UP3UDPENetClient::Client_SendWorldMessage(const ::google::protobuf::Message& Message)
{
	const int32 MessageSize = StaticCast<int32>(Message.ByteSizeLong());

	TArray<uint8> MessageBuffer;
	MessageBuffer.SetNum(MessageSize);

	const bool bSuccess = Message.SerializeToArray(MessageBuffer.GetData(), MessageSize);

	if (bSuccess)
	{
		FP3UDPMessageWorld UDPMessage;
		UDPMessage.Buffer = MessageBuffer;
		SendMessageToGameChannel(CurrentConnId, UDPMessage);
	}
}

void UP3UDPENetClient::Client_SendZoneChange()
{
	FP3UDPMessageZoneChange Message;
	SendMessageToGameChannel(CurrentConnId, Message);
}

void UP3UDPENetClient::HandleWorldMessage(const struct FP3UDPMessageWorld& Message)
{
	UP3ClientWorld* ClientWorld = P3World ? P3World->GetClientWorld() : nullptr;

	if (!ensure(ClientWorld))
	{
		return;
	}

	pb::D2CWorldMessage WorldMessage;

	WorldMessage.ParseFromArray(Message.Buffer.GetData(), Message.Buffer.Num());

	ClientWorld->HandleWorldMessage(WorldMessage);
}
