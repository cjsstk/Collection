// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "IpConnection.h"

#include "Lib/P3NetCore.h"

#include "P3NetConnection.generated.h"

class UP3ActorChannel;

typedef TMap<AActor*, UP3ActorChannel*> P3ActorChannelMap;
typedef TMap<actorid, UP3ActorChannel*> P3ActorIdChannelMap;


struct FP3QueuedActorMessage
{
	/** The raw message data */
	TArray<uint8> Data;

	/** The bit size of the message */
	uint32 CountBits;

	bool bReliable;

	UP3ActorChannel* Channel;

	void SerializeBunch(OUT FOutBunch& Bunch);

	/**
	 * Base constructor
	 */
	FP3QueuedActorMessage()
		: Data()
		, CountBits(0)
		, bReliable(false)
		, Channel(nullptr)
	{
	}
};

UCLASS(transient)
class UP3NetConnection : public UIpConnection
{
	GENERATED_UCLASS_BODY()

	//~ Begin NetConnection Interface
//	virtual void InitBase(UNetDriver* InDriver, class FSocket* InSocket, const FURL& InURL, EConnectionState InState, int32 InMaxPacket = 0, int32 InPacketOverhead = 0) override;
	virtual void InitRemoteConnection(UNetDriver* InDriver, class FSocket* InSocket, const FURL& InURL, const class FInternetAddr& InRemoteAddr, EConnectionState InState, int32 InMaxPacket = 0, int32 InPacketOverhead = 0) override;
	virtual void InitLocalConnection(UNetDriver* InDriver, class FSocket* InSocket, const FURL& InURL, EConnectionState InState, int32 InMaxPacket = 0, int32 InPacketOverhead = 0) override;
//	virtual void LowLevelSend(void* Data, int32 CountBits, FOutPacketTraits& Traits) override;
//	FString LowLevelGetRemoteAddress(bool bAppendPort = false) override;
//	FString LowLevelDescribe() override;
//	virtual int32 GetAddrAsInt(void) override;
//	virtual int32 GetAddrPort(void) override;
//	virtual TSharedPtr<FInternetAddr> GetInternetAddr() override;
//	virtual FString RemoteAddressToString() override;
	virtual void Tick() override;
 	virtual void CleanUp() override;
	virtual void LowLevelSend(void* Data, int32 CountBits, FOutPacketTraits& Traits) override;
	//~ End NetConnection Interface

	void SetConnectionId(P3NetConnId ConnId) { ConnectionId = ConnId; }
	P3NetConnId GetConnectionId() const { return ConnectionId; }

public:
	void RemoveActorChannel(AActor* Actor, actorid ActorId)
	{
		ActorChannels.Remove(Actor);
		ActorIdChannels.Remove(ActorId);
	}

	void AddActorChannel(AActor* Actor, UP3ActorChannel* Channel, actorid ActorId)
	{
		ActorChannels.Add(Actor, Channel);
		ActorIdChannels.Add(ActorId, Channel);
	}

	UP3ActorChannel* FindActorChannelRef(AActor* Actor)
	{
		return ActorChannels.FindRef(Actor);
	}

	UP3ActorChannel** FindActorChannel(AActor* Actor)
	{
		return ActorChannels.Find(Actor);
	}

	bool ContainsActorChannel(AActor* Actor)
	{
		return ActorChannels.Contains(Actor);
	}

	int32 ActorChannelsNum() const
	{
		return ActorChannels.Num();
	}

	UP3ActorChannel* FindActorIdChannelRef(actorid ActorId)
	{
		return ActorIdChannels.FindRef(ActorId);
	}

	P3ActorChannelMap::TConstIterator ActorChannelConstIterator() const
	{
		return ActorChannels.CreateConstIterator();
	}

	const P3ActorChannelMap& ActorChannelMap() const
	{
		return ActorChannels;
	}

	bool IsMessageQueueEmpty() const { return QueuedMessages.Num() == 0; }

	bool QueueMessage(FOutBunch* Bunch, UP3ActorChannel* ActorChannel);

	static void MakeBunch(OUT FOutBunch& Bunch, UP3ActorChannel* Channel, bool bReliable);

public:
	FDateTime LastPingReceivedTime = FDateTime(0); // for server

	FP3PingTime PingTime; // for client

private:
	enum { MAX_QUEUED_ACTOR_MESSAGES = 32768 };

	P3NetConnId ConnectionId = INVALID_NETCONNID;
	P3ActorChannelMap ActorChannels;
	P3ActorIdChannelMap ActorIdChannels;
	TArray<FP3QueuedActorMessage> QueuedMessages;
};
