// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Interfaces/IHttpRequest.h"
#include "P3Core.h"
#include "P3DedimanHelper.generated.h"

USTRUCT()
struct FP3DediItemResponse
{
	GENERATED_BODY()

	UPROPERTY()
	int32 Id;

	UPROPERTY()
	FString Name;

	UPROPERTY()
	FString MapName;

	UPROPERTY()
	FString ZoneName;

	UPROPERTY()
	FString Host;

	UPROPERTY()
	int32 ListenPort;

	UPROPERTY()
	int32 UDPPort;

	UPROPERTY()
	bool bRunning;
};

USTRUCT()
struct FP3DediInfoListResponse
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FP3DediItemResponse> Dedis;
};

USTRUCT()
struct FP3DediInfoResponse
{
	GENERATED_BODY()

	UPROPERTY()
	FP3DediItemResponse Dedi;
};

USTRUCT()
struct FP3RegisterDedimanResponse
{
	GENERATED_BODY()

	UPROPERTY()
	uint32 ZoneChannelId;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3DedimanHelperOnGetZoneChannels, const FP3DediInfoListResponse&, DediInfoList, bool, bWasSuccessful);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3DedimanHelperOnAllocZoneChannel, const FP3DediInfoResponse&, DediInfo, bool, bWasSuccessful);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3DedimanHelperOnRegisterToDediman, uint32, ZoneChannelId, bool, bWasSuccessful);

UCLASS()
class UP3DedimanHelper : public UObject
{
	GENERATED_BODY()

public:
	virtual ~UP3DedimanHelper() {}

	void Initialize(class UP3GameInstance* InGameInstance);
	void Shutdown();

	void GetZoneChannels(const FString& ZoneName);
	void AllocZoneChannel(const FString& ZoneName, charid CharacterId, const TCHAR* CharacterName);
	void AllocZoneChannelForce(int32 ChannelId, charid CharacterId, const TCHAR* CharacterName);
	void RegisterToDediman(const TCHAR* ZoneName, const TCHAR* Host, int32 GamePort, int32 GameUDPPort, int32 AdminPort);
	void UnregisterFromDediman(uint32 ZoneChannelId);

	FP3DedimanHelperOnGetZoneChannels OnGetZoneChannels;
	FP3DedimanHelperOnAllocZoneChannel OnAllocZoneChannel;
	FP3DedimanHelperOnAllocZoneChannel OnAllocZoneChannelForce;
	FP3DedimanHelperOnRegisterToDediman OnRegisterDediman;

	FString GetDedimanURL() const;
	void SetDedimanURL(const FString& URL) { DedimanURL = URL; }


private:
	void OnGetZoneChannelsResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);
	void OnAllocZoneChannelResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);
	void OnAllocZoneChannelForceResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);
	void OnRegisterDedimanResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	FString DedimanURL;
};
