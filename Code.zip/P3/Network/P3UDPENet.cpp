// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UDPENet.h"

#include "CoreNet.h"

#include "P3GameInstance.h"
#include "P3UDPMessage.h"
#include "P3World.h"
#include "P3Log.h"

DECLARE_CYCLE_STAT(TEXT("P3ENet Send"), STAT_P3ENet_Send, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3ENet Receive"), STAT_P3ENet_Recv, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3ENet Poll"), STAT_P3ENet_Poll, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3ENet Flush"), STAT_P3ENet_Flush, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3ENet HostService"), STAT_P3ENet_HostService, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3ENet HandleEvent"), STAT_P3ENet_HandleEvent, STATGROUP_P3);

DECLARE_DWORD_COUNTER_STAT(TEXT("P3ENet Num Connections"), STAT_P3ENet_NumConnections, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ENet Num SendEnqueue"), STAT_P3ENet_NumSendEnqueue, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ENet Num SendDequeue"), STAT_P3ENet_NumSendDequeue, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ENet Num ReceiveEnqueue"), STAT_P3ENet_NumRecvEnqueue, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3ENet Num ReceiveDequeue"), STAT_P3ENet_NumRecvDequeue, STATGROUP_P3);

TAutoConsoleVariable<int32> CVarP3ENetMaxConnections(
	TEXT("p3.enetMaxConnections"),
	100,
	TEXT("The maximum number of client connections"));

TAutoConsoleVariable<int32> CVarP3ENetMaxChannels(
	TEXT("p3.enetMaxChannels"),
	2,
	TEXT("The maximum number of channels that send or receive"));

TAutoConsoleVariable<int32> CVarP3ENetHostWaitTimeMS(
	TEXT("p3.enetHostWaitTimeMS"),
	10,
	TEXT("If p3.enetHostWaitTimeMS is true, the number of milliseconds to use as the timeout value for enet_host_service on the receive thread."));

static TAutoConsoleVariable<int32> CVarP3ENetIncomingBandwidth(
	TEXT("p3.enetIncomingBandwidth"),
	0,
	TEXT("If 0, assume any amount of incoming bandwidth"));

static TAutoConsoleVariable<int32> CVarP3ENetOutgoingBandwidth(
	TEXT("p3.enetOutgoingBandwidth"),
	0,
	TEXT("If 0, assume any amount of outgoing bandwidth"));

extern TAutoConsoleVariable<int32> CVarP3NetUDPUseThread;

//////////////////////////////////////////////////////////////////////////////////////////////
// FP3ENetUtil

P3NetConnId FP3ENetUtil::PeerIdToNetConnId(const ENetPeer* Peer)
{
	return !ensure(Peer) ? INVALID_NETCONNID : P3NetConnId(Peer->incomingPeerID + 1);
}

FString FP3ENetUtil::GetAddressFromENetAddress(const ENetAddress& Address)
{
	char AddrStr[16] = { 0, };

	int32 Ret = enet_address_get_host_ip(&Address, AddrStr, sizeof(AddrStr));

	if (Ret != 0)
	{
		UE_LOG(P3UDPNetLog, Warning, TEXT("Invalid address: %u"), Address.host);
		return FString();
	}

	return AddrStr;
}

//////////////////////////////////////////////////////////////////////////////////////////////
// FP3ENetPeer

void FP3ENetPeer::CleanupPeer()
{
	if (Peer)
	{
		enet_peer_disconnect(Peer, 0);

		Peer = nullptr;
	}
}

//////////////////////////////////////////////////////////////////////////////////////////////
// UP3UDPENet

void UP3UDPENet::Initialize(UP3GameInstance* InGameInstance)
{
	CHECK_GAME_THREAD;

	GameInstance = InGameInstance;

	int32 bResult = enet_initialize();

	check(bResult == 0);

	bUseThread = CVarP3NetUDPUseThread.GetValueOnGameThread() != 0;
}

void UP3UDPENet::InitThread()
{
	if (bUseThread)
	{
		check(!ENetThreadRunnable.IsValid() && !ENetThread.IsValid());

		ENetThreadRunnable = MakeUnique<FP3ENetThreadRunnable>(*this);

		ENetThread.Reset(FRunnableThread::Create(ENetThreadRunnable.Get(), *FString::Printf(TEXT("UP3UDPENet Receive Thread")), 0, TPri_AboveNormal));
	}
}

void UP3UDPENet::Shutdown()
{
	CHECK_GAME_THREAD;

	SendLocalMessage(EP3UDPLocalMessageType::Shutdown);

	if (ENetThread.IsValid())
	{
		ENetThread->WaitForCompletion();
	}

	ENetThread.Reset();
	ENetThreadRunnable.Reset();

	for (auto& Entry : MappedNetPeers)
	{
		P3ENetPeerSharedRef NetPeer = Entry.Value;

		ensure(NetPeer.GetSharedReferenceCount() == 2);

		if (NetPeer->Peer)
		{
			enet_peer_disconnect(NetPeer->Peer, 0);

			enet_peer_reset(NetPeer->Peer);

			NetPeer->Peer = nullptr;
		}
	}

	MappedNetPeers.Empty();

	if (NetHost.IsValid())
	{
// 		enet_host_destroy(NetHost.Get());
// 		NetHost.Reset();
	}

	P3World = nullptr;

	enet_deinitialize();
}

void UP3UDPENet::Close(const P3NetConnId NetConnId/* = INVALID_NETCONNID*/)
{
	CHECK_GAME_THREAD;

	if (!ensure(NetConnId != INVALID_NETCONNID))
	{
		return;
	}

	FP3UDPMessageClose MessageClose;
	SendMessageToNetworkChannel(NetConnId, MessageClose);

	SendLocalMessage(EP3UDPLocalMessageType::Disconnect, NetConnId);
}

void UP3UDPENet::Disconnect(const ENetPeer* Peer, bool bCleanup/* = true*/)
{
	CheckThread();

	if (!ensure(Peer))
	{
		return;
	}

	if (RemoveNetPeer(Peer, bCleanup))
	{
		const P3NetConnId ConnId = FP3ENetUtil::PeerIdToNetConnId(Peer);

		if (ENetThreadRunnable.IsValid())
		{
			FP3EnetEventParam EventParam;
			EventParam.EventType = EP3ENetEventType::Disconnect;
			EventParam.ConnId = ConnId;
			EventParam.Address = Peer->address;
			EventParam.bSuccess = true;

			ENetThreadRunnable->AddEventToGameThread(EventParam);
		}
		else
		{
			FP3ENetDisconnectEvent DisconnectEvent(ConnId, Peer->address);
			HandleDisconnectOnGameThread(&DisconnectEvent);
		}
	}
}

bool UP3UDPENet::InitENetHost(ENetAddress* Address, uint32 MaxConnections, uint32 IncomingBandwidth, uint32 OutgoingBandwidth)
{
	check(!NetHost.IsValid());

	if (IsServer())
	{
		check(Address != nullptr);
	}
	else
	{
		check(Address == nullptr);
	}

	uint32 MaxChannelCounts = CVarP3ENetMaxChannels.GetValueOnAnyThread();

	ENetHost* NetHostPtr = enet_host_create(Address, // create the host with binding address
		StaticCast<size_t>(MaxConnections),
		StaticCast<size_t>(MaxChannelCounts),
		IncomingBandwidth,
		OutgoingBandwidth
	);

	if (!ensure(NetHostPtr))
	{
		UE_LOG(P3UDPNetLog, Fatal, TEXT("failed to create enet host"));
		return false;
	}

	NetHost = TSharedRef<ENetHost, ESPMode::ThreadSafe>(NetHostPtr, [](ENetHost* InNetHost) {
		enet_host_destroy(InNetHost);
	});

	check(NetHost.IsValid());

	return true;
}

void UP3UDPENet::Listen()
{
	CheckThread();

	check(IsServer());
	check(Port != 0);

	ENetAddress Address;

	if (Host.IsEmpty())
	{
		Address.host = ENET_HOST_ANY;
	}
	else
	{
		enet_address_set_host(&Address, TCHAR_TO_ANSI(*Host));
	}

	Address.port = StaticCast<uint16>(Port);

	FString AddressStr = FP3ENetUtil::GetAddressFromENetAddress(Address);

	const uint32 MaxConnections = CVarP3ENetMaxConnections.GetValueOnAnyThread();
	const uint32 IncomingBandwidth = CVarP3ENetIncomingBandwidth.GetValueOnAnyThread();
	const uint32 OutgoingBandwidth = CVarP3ENetOutgoingBandwidth.GetValueOnAnyThread();

	if (!ensure(InitENetHost(&Address, MaxConnections, IncomingBandwidth, OutgoingBandwidth)))
	{
		P3JsonUDPLog(Fatal, "failed to ENet UDP listen", TEXT("Host"), *AddressStr, TEXT("Port"), Address.port);
		return;
	}

	WaitMilliseconds = CVarP3ENetHostWaitTimeMS.GetValueOnAnyThread();

	P3JsonUDPLog(Display, "ENet UDP Listen", TEXT("Host"), *AddressStr, TEXT("Port"), Address.port);
}

void UP3UDPENet::Connect()
{
	CheckThread();

	check(!IsServer());
	check(!Host.IsEmpty() && Port != 0);

	if (NetHost.IsValid())
	{
		NetHost.Reset();
	}

	const uint32 MaxConnections = 1;
	const uint32 IncomingBandwidth = CVarP3ENetIncomingBandwidth.GetValueOnAnyThread();
	const uint32 OutgoingBandwidth = CVarP3ENetOutgoingBandwidth.GetValueOnAnyThread();

	if (!ensure(InitENetHost(nullptr, 1, IncomingBandwidth, OutgoingBandwidth)))
	{
		return;
	}

	P3JsonUDPLog(Display, "ENet UDP Try to connect", TEXT("Host"), Host, TEXT("Port"), Port);

	ENetAddress ServerAddr;
	enet_address_set_host(&ServerAddr, TCHAR_TO_ANSI(*Host));
	ServerAddr.port = StaticCast<uint16>(Port);

	FString AddressStr = FP3ENetUtil::GetAddressFromENetAddress(ServerAddr);

	ENetPeer* Peer = enet_host_connect(NetHost.Get(), &ServerAddr, StaticCast<size_t>(CVarP3ENetMaxChannels.GetValueOnAnyThread()), 0);

	if (!ensure(Peer))
	{
		return;
	}

	ENetEvent ConnectEvent;

	bool bSuccess = (enet_host_service(NetHost.Get(), &ConnectEvent, ConnectTimeoutMilliseconds) > 0) && (ConnectEvent.type == ENET_EVENT_TYPE_CONNECT);

	if (!bSuccess)
	{
		enet_peer_reset(Peer);

		P3JsonUDPLog(Warning, "connection to %s:%d failed", TEXT("Host"), *AddressStr, TEXT("Port"), ServerAddr.port);

		if (ENetThreadRunnable.IsValid())
		{
			FP3EnetEventParam EventParam;
			EventParam.EventType = EP3ENetEventType::Connect;
			EventParam.bSuccess = false;

			ENetThreadRunnable->AddEventToGameThread(EventParam);
		}
		else
		{
			FP3ENetConnectEvent ConnectFailedEvent;
			HandleConnectOnGameThread(&ConnectFailedEvent);
		}

		return;
	}

	HandleConnectEvent(ConnectEvent);

	WaitMilliseconds = 5;

	P3JsonUDPLog(Display, "Connected to dedi server", TEXT("Host"), *AddressStr, TEXT("Port"), ServerAddr.port);
}

void UP3UDPENet::Poll()
{
	SCOPE_CYCLE_COUNTER(STAT_P3ENet_Poll);

	if (!IsValid())
	{
		return;
	}

	ENetEvent Event;
	/* Wait up to WaitMilliseconds for an event. */
	int32 Ret = 0;

	{
		SCOPE_CYCLE_COUNTER(STAT_P3ENet_HostService);
		Ret = enet_host_service(NetHost.Get(), &Event, WaitMilliseconds);
	}

	if (Ret == 0)
	{
		return;
	}

	if (Ret < 0)
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("ENet host service end with error: %d "), Ret);
		return;
	}

	if (ensure(Event.peer))
	{
		HandleENetEvent(Event);
	}
}

void UP3UDPENet::HandleENetEvent(const ENetEvent& Event)
{
	switch (Event.type)
	{
	case ENET_EVENT_TYPE_NONE:
	{
		break;
	}
	case ENET_EVENT_TYPE_CONNECT:
	{
		HandleConnectEvent(Event);
		break;
	}
	case ENET_EVENT_TYPE_DISCONNECT:
	{
		HandleDisconnectEvent(Event);
		break;
	}
	case ENET_EVENT_TYPE_RECEIVE:
	{
		if (Event.packet)
		{
			HandleReceiveEvent(Event);

			/* Clean up the packet now that we're done using it. */
			enet_packet_destroy(Event.packet);
		}
		else
		{
			ensure(0);
			UE_LOG(P3UDPNetLog, Error, TEXT("ENet packet is null"));
		}
		break;
	}
	default:
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("Unhandle event type: %d "), Event.type);
		break;
	}
	}
}

void UP3UDPENet::HandleConnectEvent(const ENetEvent& Event)
{
	CheckThread();

	if (!ensure(Event.type == ENET_EVENT_TYPE_CONNECT))
	{
		return;
	}

	ENetPeer* Peer = Event.peer;

	if (!ensure(Peer && Peer->state == ENET_PEER_STATE_CONNECTED))
	{
		return;
	}

	P3ENetPeerSharedPtr ENetPeer = AddNetPeer(Peer);

	if (ensure(ENetPeer.IsValid() && ENetPeer->IsConnected()))
	{
		if (ENetThreadRunnable.IsValid())
		{
			FP3EnetEventParam EventParam;
			EventParam.EventType = EP3ENetEventType::Connect;
			EventParam.ConnId = ENetPeer->GetConnId();
			EventParam.Address = Peer->address;
			EventParam.bSuccess = true;

			ENetThreadRunnable->AddEventToGameThread(EventParam);
		}
		else
		{
			FP3ENetConnectEvent ConnectEvent(ENetPeer->GetConnId(), Peer->address, true);
			HandleConnectOnGameThread(&ConnectEvent);
		}
	}
}
void UP3UDPENet::HandleDisconnectEvent(const ENetEvent& Event)
{
	CheckThread();

	if (!ensure(Event.type == ENET_EVENT_TYPE_DISCONNECT))
	{
		return;
	}

	ENetPeer* Peer = Event.peer;

	if (!ensure(Peer))
	{
		return;
	}

	Disconnect(Peer);
}

void UP3UDPENet::HandleReceiveEvent(const ENetEvent& Event)
{
	CheckThread();

	SCOPE_CYCLE_COUNTER(STAT_P3ENet_Recv);

	if (!ensure(Event.type == ENET_EVENT_TYPE_RECEIVE))
	{
		return;
	}

	if (!ensure(Event.packet))
	{
		return;
	}

	ENetPeer* Peer = Event.peer;

	if (!ensure(Peer))
	{
		return;
	}

	const P3NetConnId ConnId = FP3ENetUtil::PeerIdToNetConnId(Peer);

	if (!ensure(ConnId != INVALID_NETCONNID))
	{
		return;
	}

	const P3ENetPeerSharedPtr ENetPeer = GetNetPeer(ConnId);

	if (!ENetPeer.IsValid() || ENetPeer->GetConnId() == INVALID_NETCONNID)
	{
		return;
	}

	if (!ensure(ENetPeer->GetConnId() == ConnId))
	{
		return;
	}

	EP3ENetChannelType ChannelType = StaticCast<EP3ENetChannelType>(Event.channelID);

	if (ChannelType == EP3ENetChannelType::Game)
	{
		uint32 DataLen = StaticCast<uint32>(Event.packet->dataLength);

		if (ENetThreadRunnable.IsValid())
		{
			FP3EnetEventParam EventParam;
			EventParam.EventType = EP3ENetEventType::Receive;
			EventParam.ConnId = ConnId;
			EventParam.ChannelType = StaticCast<EP3ENetChannelType>(Event.channelID);
			EventParam.Data = Event.packet->data;
			EventParam.DataLen = DataLen;
			EventParam.bNeedsByteSwapping = ENetPeer->bNeedsByteSwapping;
			EventParam.RoundTripTime = Peer->roundTripTime;
			EventParam.bSuccess = true;

			ENetThreadRunnable->AddEventToGameThread(EventParam);
		}
		else
		{
			FP3ENetReceiveEvent ReceiveEvent(ConnId, Event.packet->data, DataLen, ENetPeer->bNeedsByteSwapping, Peer->roundTripTime);
			HandleReceiveOnGameThread(&ReceiveEvent);
		}
	}
}

void UP3UDPENet::Update()
{
	Flush();
	Poll();
}

void UP3UDPENet::Tick(float DeltaSeconds)
{
	CHECK_GAME_THREAD;

	SET_DWORD_STAT(STAT_P3ENet_NumConnections, MappedNetPeers.Num());

	const double CurrentRealtime = FPlatformTime::Seconds();

	const float DeltaRealtime = CurrentRealtime - LastTickDispatchRealtime;

	LastTickDispatchRealtime = CurrentRealtime;

	const float TickLogThreshold = 0.5f;

	if (DeltaRealtime < TickLogThreshold)
	{
	}

	if (ENetThreadRunnable.IsValid())
	{
		TArray<P3ENetEventSharedRef> IncomingEvents;

		ENetThreadRunnable->GetEventsFromNetworkThread(IncomingEvents);

		SET_DWORD_STAT(STAT_P3ENet_NumRecvDequeue, IncomingEvents.Num());

		for (P3ENetEventSharedRef IncomingEvent : IncomingEvents)
		{
			if (!HandleP3ENetEvent(IncomingEvent))
			{
				break;
			}
		}
	}
	else
	{
		Update();
	}
}

bool UP3UDPENet::HandleP3ENetEvent(P3ENetEventSharedRef Event)
{
	CHECK_GAME_THREAD;

	SCOPE_CYCLE_COUNTER(STAT_P3ENet_HandleEvent);

	const EP3ENetEventType EventType = Event->GetType();

	switch (EventType)
	{
	case EP3ENetEventType::Connect:
		HandleConnectOnGameThread(Event->SafeCastToConnectEvent());
		break;
	case EP3ENetEventType::Disconnect:
		HandleDisconnectOnGameThread(Event->SafeCastToDisconnectEvent());
		break;
	case EP3ENetEventType::Receive:
		HandleReceiveOnGameThread(Event->SafeCastToReceiveEvent());
		break;
	default:
		ensure(0);
		UE_LOG(P3UDPNetLog, Error, TEXT("Invalid ENet event type: %u"), EventType);
		return false;
	}

	return true;
}

void UP3UDPENet::HandleLocalMessage(const EP3UDPLocalMessageType MessageType, const P3NetConnId ConnId)
{
	CheckThread();

	switch (MessageType)
	{
	case EP3UDPLocalMessageType::Shutdown:
		ensure(ConnId == INVALID_NETCONNID);

		if (ENetThreadRunnable.IsValid())
		{
			ENetThreadRunnable->Stop();
		}
		break;
	case EP3UDPLocalMessageType::Listen:
		ensure(ConnId == INVALID_NETCONNID);

		Listen();
		break;
	case EP3UDPLocalMessageType::Connect:
		ensure(ConnId == INVALID_NETCONNID);

		Connect();
		break;
	case EP3UDPLocalMessageType::Disconnect:
	{
		ensure(ConnId != INVALID_NETCONNID);

		const P3ENetPeerSharedPtr ENetPeer = GetNetPeer(ConnId);

		if (ENetPeer.IsValid() && ENetPeer->IsConnected())
		{
			Disconnect(ENetPeer->Peer, false);
		}

		break;
	}
	default:
		ensure(0);
		UE_LOG(P3UDPNetLog, Error, TEXT("Invalid local message type: %u"), MessageType);
		break;
	}
}

P3ENetPeerSharedPtr UP3UDPENet::AddNetPeer(ENetPeer* Peer)
{
	CheckThread();

	if (!ensure(Peer))
	{
		return P3ENetPeerSharedPtr(nullptr);
	}

	const P3NetConnId ConnId = FP3ENetUtil::PeerIdToNetConnId(Peer);

	ensure(!MappedNetPeers.Contains(ConnId));

	P3ENetPeerSharedPtr ENetPeer = MappedNetPeers.Add(ConnId, P3ENetPeerSharedRef(new FP3ENetPeer(Peer)));

	return ENetPeer;
}

bool UP3UDPENet::RemoveNetPeer(const ENetPeer* Peer, bool bCleanup/* = true*/)
{
	CheckThread();

	if (!ensure(Peer))
	{
		return false;
	}

	const P3NetConnId ConnId = FP3ENetUtil::PeerIdToNetConnId(Peer);

	P3ENetPeerSharedRef* NetPeer = MappedNetPeers.Find(ConnId);

	if (NetPeer)
	{
		ensure(ConnId == FP3ENetUtil::PeerIdToNetConnId((*NetPeer)->Peer));

		if (!bCleanup)
		{
			(*NetPeer)->Peer = nullptr;
		}

		MappedNetPeers.Remove(ConnId);

		return true;
	}

	return false; // already removed
}

P3ENetPeerSharedPtr UP3UDPENet::GetNetPeer(const P3NetConnId ConnId)
{
	CheckThread();

	P3ENetPeerSharedRef* NetPeer = MappedNetPeers.Find(ConnId);

	if (NetPeer)
	{
		return *NetPeer;
	}

	return nullptr;
}

const P3ENetPeerSharedPtr UP3UDPENet::GetNetPeer(const P3NetConnId ConnId) const
{
	CheckThread();

	const P3ENetPeerSharedRef* NetPeer = MappedNetPeers.Find(ConnId);

	if (NetPeer)
	{
		return *NetPeer;
	}

	return nullptr;
}

void UP3UDPENet::Flush()
{
	if (ENetThreadRunnable.IsValid())
	{
		SCOPE_CYCLE_COUNTER(STAT_P3ENet_Flush);

		int32 SendCount = 0;

		TArray<P3SendPacketSharedRef> OutgoingPackets;

		ENetThreadRunnable->GetPacketsFromGameThread(OutgoingPackets);

		SET_DWORD_STAT(STAT_P3ENet_NumSendDequeue, OutgoingPackets.Num());

		for (P3SendPacketSharedRef OutgoingPacket : OutgoingPackets)
		{
			if (OutgoingPacket->ChannelType == EP3ENetChannelType::Game)
			{
				if (SendToPeer(OutgoingPacket->ConnId, OutgoingPacket->ChannelType, OutgoingPacket->Buffer.GetData(), OutgoingPacket->Buffer.Num(), OutgoingPacket->Flag))
				{
					++SendCount;
				}
				else
				{
					continue;
				}
			}
			else if (OutgoingPacket->ChannelType == EP3ENetChannelType::Network)
			{
				if (SendToPeer(OutgoingPacket->ConnId, OutgoingPacket->ChannelType, OutgoingPacket->Buffer.GetData(), OutgoingPacket->Buffer.Num(), OutgoingPacket->Flag))
				{
					++SendCount;
				}
				else
				{
					continue;
				}
			}
			else if (OutgoingPacket->ChannelType == EP3ENetChannelType::Local)
			{
				if (ensure(OutgoingPacket->Buffer.Num() == 1))
				{
					EP3UDPLocalMessageType MessageType = StaticCast<EP3UDPLocalMessageType>(OutgoingPacket->Buffer[0]);

					HandleLocalMessage(MessageType, OutgoingPacket->ConnId);
				}
			}
			else
			{
				ensure(0);
				continue;
			}
		}
	}
}

uint32 UP3UDPENet::SendUnrealRawMessage(const P3NetConnId ConnId, const actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bForceReliable)
{
	CHECK_GAME_THREAD;

	if (!ensure(ConnId != INVALID_NETCONNID))
	{
		return 0;
	}

	FP3UDPMessageUnrealRaw Message;

	Message.ActorId = ActorId;
	Message.ComponentType = StaticCast<uint16>(Header.ComponentType);
	Message.FunctionName = Header.HandlerFunctionName.ToString();
	Message.Buffer = Buffer;

	return SendMessageToGameChannel(ConnId, Message);
}

uint32 UP3UDPENet::SendMessageToGameChannel(const P3NetConnId ConnId, FP3UDPMessage& Message, const ENetPacketFlag Flag/* = ENET_PACKET_FLAG_RELIABLE*/)
{
	return SendMessage(ConnId, Message, Flag, true);
}

uint32 UP3UDPENet::SendMessageToNetworkChannel(const P3NetConnId ConnId, struct FP3UDPMessage& Message, const ENetPacketFlag Flag/* = ENET_PACKET_FLAG_RELIABLE*/)
{
	return SendMessage(ConnId, Message, Flag, false);
}

uint32 UP3UDPENet::SendMessage(const P3NetConnId ConnId, FP3UDPMessage& Message, const ENetPacketFlag Flag, const bool bGameChannel)
{
	CHECK_GAME_THREAD;

	if (!ensure(ConnId != INVALID_NETCONNID))
	{
		return 0;
	}

	FNetBitWriter Writer(Message.GetMaxBits());

	Message.Serialize(Writer);

	const uint32 MessageNumBytes = StaticCast<uint32>(Writer.GetNumBytes());

	const EP3ENetChannelType ChannelType = bGameChannel ? EP3ENetChannelType::Game : EP3ENetChannelType::Network;

	if (ENetThreadRunnable.IsValid())
	{
		ENetThreadRunnable->AddPacketToNetworkThread(ConnId, ChannelType, Writer.GetData(), MessageNumBytes, Flag);

		return MessageNumBytes;
	}
	else
	{
		if (NetHost.IsValid())
		{
			if (SendToPeer(ConnId, ChannelType, Writer.GetData(), MessageNumBytes, Flag))
			{
				return MessageNumBytes;
			}
		}
	}

	return 0;
}

uint32 UP3UDPENet::SendMessageOnNetworkThread(ENetPeer* Peer, FP3UDPMessage& Message, const ENetPacketFlag Flag/* = ENET_PACKET_FLAG_RELIABLE*/)
{
	CheckThread();

	if (!ensure(Peer))
	{
		return 0;
	}

	FNetBitWriter Writer(Message.GetMaxBits());

	Message.Serialize(Writer);

	const uint32 MessageNumBytes = StaticCast<uint32>(Writer.GetNumBytes());

	if (NetHost.IsValid())
	{
		if (SendToPeerInternal(Peer, EP3ENetChannelType::Network, Writer.GetData(), MessageNumBytes, Flag, true))
		{
			return MessageNumBytes;
		}
	}

	return 0;
}

void UP3UDPENet::SendLocalMessage(EP3UDPLocalMessageType MessageType, const P3NetConnId ConnId/* = INVALID_NETCONNID*/)
{
	CHECK_GAME_THREAD;

	if (ENetThreadRunnable.IsValid())
	{
		TArray<uint8> Buffer;
		Buffer.AddUninitialized(1);
		Buffer[0] = StaticCast<uint8>(MessageType);

		ENetThreadRunnable->AddPacketToNetworkThread(ConnId, EP3ENetChannelType::Local, Buffer.GetData(), Buffer.Num());
	}
	else
	{
		HandleLocalMessage(MessageType, ConnId);
	}
}

bool UP3UDPENet::SendToPeer(const P3NetConnId ConnId, const EP3ENetChannelType ChannelType, const uint8* Data, const uint32 DataLen, const ENetPacketFlag Flag)
{
	CheckThread();

	if (!ensure(ConnId != INVALID_NETCONNID))
	{
		return false;
	}

	const P3ENetPeerSharedPtr ENetPeer = GetNetPeer(ConnId);

	if (!ENetPeer.IsValid())
	{
		return false;
	}

	return SendToPeerInternal(ENetPeer->Peer, ChannelType, Data, DataLen, Flag, false);
}

bool UP3UDPENet::SendToPeerInternal(ENetPeer* Peer, const EP3ENetChannelType ChannelType, const uint8* Data, const uint32 DataLen, const ENetPacketFlag Flag, bool bFlush)
{
	CheckThread();

	SCOPE_CYCLE_COUNTER(STAT_P3ENet_Send);

	if (DataLen == 0)
	{
		return false;
	}

	if (!ensure(ChannelType == EP3ENetChannelType::Game || ChannelType == EP3ENetChannelType::Network))
	{
		return false;
	}

	if (!ensure(Peer))
	{
		return false;
	}

	if (Peer->state != ENET_PEER_STATE_CONNECTED)
	{
		return false;
	}

	if (!IsValid())
	{
		return false;
	}

	ENetPacket* Packet = enet_packet_create(Data, StaticCast<size_t>(DataLen), Flag);

	if (!ensure(Packet))
	{
		return false;
	}

	const uint8 ChannelId = StaticCast<uint8>(ChannelType);

	if (enet_peer_send(Peer, ChannelId, Packet) == 0)
	{
		if (bFlush)
		{
			enet_host_flush(NetHost.Get());
		}

		return true;
	}

	return false;
}

bool UP3UDPENet::IsValid() const
{
	return NetHost.IsValid();
}

void UP3UDPENet::CheckThread() const
{
	if (ENetThreadRunnable.IsValid())
	{
		CHECK_NETWORK_THREAD;
	}
	else
	{
		CHECK_GAME_THREAD;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// UP3UDPENet::FP3ReceiveThreadRunnable

UP3UDPENet::FP3ENetThreadRunnable::FP3ENetThreadRunnable(UP3UDPENet& ENet)
	: OwningENet(ENet)
	, bIsRunning(false)
{
}

UP3UDPENet::FP3ENetThreadRunnable::~FP3ENetThreadRunnable()
{
}

uint32 UP3UDPENet::FP3ENetThreadRunnable::Run()
{
	bIsRunning = true;

	while (bIsRunning)
	{
		OwningENet.Update();
	}

	return 0;
}

void UP3UDPENet::FP3ENetThreadRunnable::Stop()
{
	bIsRunning = false;

	Cleanup();
}

void UP3UDPENet::FP3ENetThreadRunnable::Cleanup(bool bSendQueueOnly/* = false*/)
{
	if (!bSendQueueOnly)
	{
		FRWScopeLock ReceiveQueueLock(ReceiveQueueRWLock, SLT_Write);
		ReceiveQueue.Empty();
	}

	{
		FRWScopeLock SendQueueLock(SendQueueRWLock, SLT_Write);
		SendQueue.Empty();
	}
}

bool UP3UDPENet::FP3ENetThreadRunnable::IsRunning() const
{
	return bIsRunning;
}

bool UP3UDPENet::FP3ENetThreadRunnable::AddEventToGameThread(FP3EnetEventParam& Param)
{
	CHECK_NETWORK_THREAD;

	P3ENetEventSharedPtr Event(nullptr);

	switch (Param.EventType)
	{
	case EP3ENetEventType::Connect:
		Event = P3ENetEventSharedRef(new FP3ENetConnectEvent(Param.ConnId, Param.Address, Param.bSuccess));
		break;
	case EP3ENetEventType::Disconnect:
		Event = P3ENetEventSharedRef(new FP3ENetDisconnectEvent(Param.ConnId, Param.Address));
		break;
	case EP3ENetEventType::Receive:
		Event = P3ENetEventSharedRef(new FP3ENetReceiveEvent(Param.ConnId, Param.Data, Param.DataLen, Param.bNeedsByteSwapping, Param.RoundTripTime));
		break;
	default:
		ensure(0);
		UE_LOG(P3UDPNetLog, Error, TEXT("Invalid ENet event type: %u"), Param.EventType);
		return false;
	}

	if (!Event.IsValid())
	{
		return false;
	}

	FRWScopeLock Lock(ReceiveQueueRWLock, SLT_Write);
	ReceiveQueue.Add(Event.ToSharedRef());

	SET_DWORD_STAT(STAT_P3ENet_NumRecvEnqueue, ReceiveQueue.Num());

	return true;
}

void UP3UDPENet::FP3ENetThreadRunnable::GetEventsFromNetworkThread(TArray<P3ENetEventSharedRef>& IncomingEvents)
{
	CHECK_GAME_THREAD;

	FRWScopeLock Lock(ReceiveQueueRWLock, SLT_Write);
	Exchange(ReceiveQueue, IncomingEvents);
}

bool UP3UDPENet::FP3ENetThreadRunnable::AddPacketToNetworkThread(const P3NetConnId ConnId, const EP3ENetChannelType ChannelType, const uint8* Data, const uint32 DataLen, const ENetPacketFlag Flag/* = ENET_PACKET_FLAG_RELIABLE*/)
{
	CHECK_GAME_THREAD;

	P3SendPacketSharedRef OutgoingPacket(new FP3SendPacket());

	OutgoingPacket->ConnId = ConnId;
	OutgoingPacket->ChannelType = ChannelType;
	OutgoingPacket->Flag = Flag;

	if (Data && DataLen > 0)
	{
		OutgoingPacket->Buffer.Append(Data, DataLen);
	}

	{
		FRWScopeLock Lock(SendQueueRWLock, SLT_Write);
		SendQueue.Add(OutgoingPacket);

		SET_DWORD_STAT(STAT_P3ENet_NumSendEnqueue, SendQueue.Num());
	}

	return true;
}

void UP3UDPENet::FP3ENetThreadRunnable::GetPacketsFromGameThread(TArray<P3SendPacketSharedRef>& OutgoingPackets)
{
	CHECK_NETWORK_THREAD;

	FRWScopeLock Lock(SendQueueRWLock, SLT_Write);
	Exchange(SendQueue, OutgoingPackets);
}

uint32 UP3UDPENet::FP3ENetThreadRunnable::GetRecvQueueNum() const
{
	uint32 Num = 0;

	{
		FRWScopeLock Lock(ReceiveQueueRWLock, SLT_ReadOnly);
		Num = ReceiveQueue.Num();
	}

	return Num;
}

uint32 UP3UDPENet::FP3ENetThreadRunnable::GetSendQueueNum() const
{
	uint32 Num = 0;

	{
		FRWScopeLock Lock(SendQueueRWLock, SLT_ReadOnly);
		Num = SendQueue.Num();
	}

	return Num;
}
