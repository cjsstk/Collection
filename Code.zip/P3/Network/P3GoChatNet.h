// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Lib/P3Net.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/chat.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/chat.pb.h"
#endif

#include "P3GoChatNet.generated.h"

UCLASS()
class UP3GoChatNet : public UObject, public IP3BaseNet
{
	GENERATED_BODY()

public:
	virtual ~UP3GoChatNet() {}

	void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet);
	void Shutdown();

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event);
	virtual void HandleListenEvent(const FP3NetListenEvent& Event) {}
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event) {}
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event);
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event);
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event) {}

	void Connect();

	const FString& GetHost();
	void SetHost(const FString& InHost);
	int32 GetPort();
	void SetPort(int32 InPort);

private:
	void Send(pb::CC2CSType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);

	void SendEnter();

	void HandleEnterRes(const pb::CS2CCEnterRes& Message);

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	UPROPERTY()
	UP3Net* Net = nullptr;

	FString Host;
	int32 Port = 0;
	P3NetConnId ConnId = INVALID_NETCONNID;
};
