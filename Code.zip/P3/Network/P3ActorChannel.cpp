// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ActorChannel.h"

#include "Engine/NetConnection.h"

#include "P3ActorInterface.h"
#include "P3Core.h"
#include "P3Log.h"
#include "P3NetConnection.h"
#include "P3UnrealUDPNet.h"

UP3ActorChannel::UP3ActorChannel(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	ChType = CHTYPE_Actor;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	ChName = NAME_Actor;
}

void UP3ActorChannel::Init(UNetConnection* InConnection, int32 InChIndex, EChannelCreateFlags CreateFlags)
{
	Super::Init(InConnection, InChIndex, CreateFlags);
}

int64 UP3ActorChannel::Close(EChannelCloseReason Reason)
{
	int64 NumBits = UChannel::Close(Reason);

	if (Actor)
	{
		if (P3Connection)
		{
			P3Connection->RemoveActorChannel(Actor, ActorNetId);
		}

		Actor = nullptr;
		ActorNetId = INVALID_ACTORID;
	}

	P3Connection = nullptr;

	return NumBits;
}

bool UP3ActorChannel::CleanUp(const bool bForDestroy, EChannelCloseReason CloseReason)
{
	checkf(Connection != nullptr, TEXT("UP3ActorChannel::CleanUp: Connection is null!"));
	checkf(Connection->Driver != nullptr, TEXT("UP3ActorChannel::CleanUp: Connection->Driver is null!"));

	const bool bIsServer = Connection->Driver->IsServer();

	if (!bIsServer)
	{
		if (UDPNet)
		{
			check(bIsServer == UDPNet->IsServer());

			if (!bIsClientLocalActor && ActorNetId != INVALID_ACTORID)
			{
				UDPNet->Client_DestroyActor(ActorNetId);
			}
		}
	}

	SetClosingFlag();

	// We check for -1 here, which will be true if this channel has already been closed but still needed to process bunches before fully closing
	if (ChIndex >= 0)
	{
		return UChannel::CleanUp(bForDestroy, CloseReason);
	}
	else
	{
		// Because we set Connection = OldConnection; above when we set ChIndex to -1, we have to null it here explicitly to make sure the connection is cleared by the time we leave CleanUp
		Connection = nullptr;
	}

	return true;
}

void UP3ActorChannel::SetClosingFlag()
{
	if (Actor)
	{
		if (P3Connection)
		{
			P3Connection->RemoveActorChannel(Actor, ActorNetId);
		}

		Actor = nullptr;
		ActorNetId = INVALID_ACTORID;
	}

	P3Connection = nullptr;

	UChannel::SetClosingFlag();
}

void UP3ActorChannel::ReceivedBunch(FInBunch& Bunch)
{
	check(!Closing);

	if (Broken || bTornOff)
	{
		return;
	}

	// We can process this bunch now
	ProcessBunch(Bunch);
}

void UP3ActorChannel::ProcessBunch(FInBunch& Bunch)
{
	if (Broken)
	{
		return;
	}

	if (!ensure(UDPNet))
	{
		return;
	}

	if (Bunch.bClose == 1)
	{
		return;
	}

	while (!Bunch.AtEnd() && Connection != nullptr && Connection->State != USOCK_Closed)
	{
		UDPNet->GetMessageHandler().ReceivedBunch(this, Bunch);
	}
}

void UP3ActorChannel::Tick()
{
	UChannel::Tick();
}

bool UP3ActorChannel::CanSendBunch() const
{
	const int32 MaxReliableBuffer = RELIABLE_BUFFER - 10;

	const int32 OutGoingBunchNum = Connection ? Connection->GetOutgoingBunches().Num() : 0;

	bool bAvailableBunch = NumOutRec + OutGoingBunchNum < MaxReliableBuffer;
	if (!bAvailableBunch)
	{
		//UE_LOG(P3UDPNetLog, Log, TEXT("Can not send bunch - NumOutRec: %i OutgoingNum: %i"), NumOutRec, OutGoingBunchNum);
	}

	return bAvailableBunch;
}

FPacketIdRange UP3ActorChannel::SendBunch(FOutBunch* Bunch, bool Merge)
{
	return UChannel::SendBunch(Bunch, Merge);
}

bool UP3ActorChannel::SendBunch(FOutBunch* Bunch, OUT FPacketIdRange& PacketId)
{
	if (!Bunch || Bunch->IsError())
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("Actor channel bunch overflowed"));

		return false;
	}

	if (Closing)
	{
		return false;
	}

	if (!ensure(Connection))
	{
		return false;
	}

	if (!ensure(Connection->Channels[ChIndex] == this))
	{
		return false;
	}

	if (!ensure(UDPNet))
	{
		return false;
	}

	if (Bunch->bReliable && UDPNet->IsServer())
	{
		if (!CanSendBunch())
		{
			Connection->FlushNet(true);
			return true;
		}
	}

	PacketId = SendBunch(Bunch, false);

	return PacketId.First != INDEX_NONE && PacketId.Last != INDEX_NONE;
}

bool UP3ActorChannel::CanStopTicking() const
{
	return UChannel::CanStopTicking();
}

void UP3ActorChannel::ReceivedNak(int32 NakPacketId)
{
	UChannel::ReceivedNak(NakPacketId);
}

FString UP3ActorChannel::Describe()
{
	return UChannel::Describe();
}

void UP3ActorChannel::AppendExportBunches(TArray< FOutBunch* >& OutExportBunches)
{
	UChannel::AppendExportBunches(OutExportBunches);
}

void UP3ActorChannel::AppendMustBeMappedGuids(FOutBunch* Bunch)
{
	UChannel::AppendMustBeMappedGuids(Bunch);
}

void UP3ActorChannel::Serialize(FArchive& Ar)
{
	UChannel::Serialize(Ar);
}

bool UP3ActorChannel::ReadyForDormancy(bool suppressLogs)
{
	return false;
}

void UP3ActorChannel::StartBecomingDormant()
{
	if (bPendingDormancy || Dormant)
	{
		return;
	}

	if (Connection)
	{
		//UE_LOG(P3UDPNetLog, Log, TEXT("StartBecomingDormant: %s"), *Describe());

		bPendingDormancy = 1;
		Dormant = 0;

		Connection->StartTickingChannel(this);
	}
}

void UP3ActorChannel::AddedToChannelPool()
{
	UChannel::AddedToChannelPool();
}

void UP3ActorChannel::BecomeDormant()
{
	UE_LOG(P3UDPNetLog, Log, TEXT("BecomeDormant: %s"), *Describe());
	bPendingDormancy = 0;
	Dormant = 1;
}

void UP3ActorChannel::Server_InitChannel(AActor* InActor, UP3UnrealUDPNet* InUDPNet, const TArray<uint8>* SpawnData/* = nullptr*/)
{
	check(InUDPNet);

	if (!ensure(InUDPNet->IsServer()))
	{
		return;
	}

	bool bBaseActorChannel = ChIndex == UP3UnrealUDPNet::BaseActorChannelIndex;

	if (!bBaseActorChannel)
	{
		if (!ensure(InActor))
		{
			return;
		}
	}

	UDPNet = InUDPNet;

	if (Connection)
	{
		if (!ensure(P3Connection == nullptr))
		{
			return;
		}

		P3Connection = UP3UnrealUDPNet::GetP3Connection(Connection);
	}

	if (!ensure(P3Connection))
	{
		return;
	}

	SetChannelActor(InActor);

	SpawnChannelActor(SpawnData);

	StartBecomingDormant();
}

void UP3ActorChannel::Client_InitChannel(AActor* InActor, UP3UnrealUDPNet* InUDPNet)
{
	check(InUDPNet);

	if (!ensure(!InUDPNet->IsServer()))
	{
		return;
	}

	UDPNet = InUDPNet;

	if (Connection)
	{
		if (!ensure(P3Connection == nullptr))
		{
			return;
		}

		P3Connection = UP3UnrealUDPNet::GetP3Connection(Connection);
	}

	if (!ensure(P3Connection))
	{
		return;
	}

	SetChannelActor(InActor);
}

void UP3ActorChannel::SetChannelActor(AActor* InActor, bool bIsLocalActor/* = false*/)
{
	check(!Closing);
	check(Actor == nullptr);

	Actor = InActor;

	if (Actor)
	{
		IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
		actorid ActorId = ActorInterface ? ActorInterface->GetActorId() : INVALID_ACTORID;

		check(ActorId != INVALID_ACTORID);

		ActorNetId = ActorId;

		if (ensure(P3Connection))
		{
			P3Connection->AddActorChannel(Actor, this, ActorId);
		}
	}

	bIsClientLocalActor = bIsLocalActor;

// 	if (Actor)
// 	{
// 		UE_LOG(P3UDPNetLog, Log, TEXT("%s(%d) actor(%s)"), *GetName(), ChIndex, *Actor->GetName());
// 	}
// 	else
// 	{
// 		UE_LOG(P3UDPNetLog, Log, TEXT("%s(%d)"), *GetName(), ChIndex);
// 	}
}

void UP3ActorChannel::SpawnChannelActor(const TArray<uint8>* SpawnData)
{
	if (!ensure(ActorNetId))
	{
		return;
	}

	EP3NetComponentType ComponentType = EP3NetComponentType::ActorChannel;

	FOutBunch Bunch(this, 0);

	Bunch << ActorNetId;
	Bunch << ComponentType;

	if (SpawnData != nullptr)
	{
		Bunch << const_cast<TArray<uint8>&>(*SpawnData);
	}
	else
	{
		TArray<uint8> Data;
		Bunch << Data;
	}

	if (!Bunch.IsError())
	{
		Bunch.bReliable = true;
		SendBunch(&Bunch, false);
	}
}

int64 UP3ActorChannel::SetChannelActorForDestroy()
{
	int64 NumBits = 0;
	check(Connection);
	check(Connection->Channels[ChIndex] == this);

	if (!Closing && (Connection->State == USOCK_Open || Connection->State == USOCK_Pending))
	{
		// Send a close notify, and wait for ack.
		FOutBunch CloseBunch(this, 1);
		check(!CloseBunch.IsError());
		check(CloseBunch.bClose);
		CloseBunch.bReliable = 1;
		PRAGMA_DISABLE_DEPRECATION_WARNINGS
		CloseBunch.bDormant = 0;
		PRAGMA_ENABLE_DEPRECATION_WARNINGS
		CloseBunch.CloseReason = EChannelCloseReason::Destroyed;

		SendBunch(&CloseBunch, 0);
		NumBits = CloseBunch.GetNumBits();
	}

	return NumBits;
}
