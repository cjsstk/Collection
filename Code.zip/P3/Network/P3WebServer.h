// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3WebServer.generated.h"

UCLASS()
class UP3WebServer : public UObject
{
	GENERATED_BODY()

public:
	virtual ~UP3WebServer() {}

	void Initialize(class UP3GameInstance* InGameInstance);
	void Shutdown();
	void Tick(float DeltaTime);

	int32 GetPort() const { return ListenPort; }

	void OnRequest(const struct FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody);

private:
	void HandleStatus(const struct FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody);
	void HandlePlayers(const struct FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody);
	void HandleCrash(const struct FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody);
	void HandleQuit(const struct FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody);

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	struct lws_context* Context = nullptr;
	int32 ListenPort = 0;
};
