// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PlayerNet.h"

#include "GameFramework/GameStateBase.h"
#include "GameFramework/PlayerState.h"

#include "P3GameInstance.h"
#include "P3GameMode.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3World.h"
#include "P3WorldNet.h"

static TAutoConsoleVariable<int32> CVarP3DediListenPort(
	TEXT("p3.dediListenPort"),
	8901,
	TEXT("Listen port for dedi server"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3DediListenRetryIntervalSeconds(
	TEXT("p3.dediListenRetryIntervalSeconds"),
	3.0f,
	TEXT("Interval when retry to listen"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3DediListenMaxSocketSendPerMessage(
	TEXT("p3.dediListenMaxSocketSendPerMessage"),
	0,
	TEXT("Maximum socket send limit per message (If exceeds, disconnect)"), ECVF_Default);

void UP3PlayerNet::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	GameInstance = InGameInstance;
	Net = InNet;

	Port = CVarP3DediListenPort.GetValueOnGameThread();

	FString PortStr;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3DediListenPort="), PortStr))
	{
		Port = FCString::Atoi(*PortStr);
	}
}

void UP3PlayerNet::Shutdown()
{
	ListenerConnId = INVALID_NETCONNID;
	PlayerSessions.Reset();
	ConnIds.Reset();
}

void UP3PlayerNet::HandleListenEvent(const FP3NetListenEvent& Event)
{
	if (!Event.bSuccess)
	{
		P3JsonNetLog(Error, "Failed to listen", TEXT("ConnId"), Event.ConnId.X);

		if (Event.ConnId == ListenerConnId)
		{
			ListenerConnId = INVALID_NETCONNID;
		}
	}

	P3JsonNetLog(Display, "Listen success", TEXT("ConnId"), Event.ConnId.X);
}

void UP3PlayerNet::HandleAcceptEvent(const FP3NetAcceptEvent& Event)
{
	ConnIds.Add(Event.AcceptedConnId);
}

void UP3PlayerNet::HandleCloseEvent(const FP3NetCloseEvent& Event)
{
	if (Event.ConnId == ListenerConnId)
	{
		P3JsonNetLog(Error, "Player listener is closed", TEXT("ConnId"), Event.ConnId.X);
		ListenerConnId = INVALID_NETCONNID;
		return;
	}

	P3JsonNetLog(Display, "Player conn is closed", TEXT("ConnId"), Event.ConnId.X);

	UWorld* World = GameInstance->GetCurrentWorld();

	if (ensure(World))
	{
		FP3NetConnInfo NetConnInfo;
		NetConnInfo.TCPConnId = Event.ConnId;
		P3Core::GetP3World(*World)->GetServerWorld()->NetOnPlayerDisconnected(NetConnInfo);
	}

	PlayerSessions.Remove(Event.ConnId);
	int32 RemoveCount = ConnIds.Remove(Event.ConnId);
	ensure(RemoveCount == 1);
}

void UP3PlayerNet::HandleRecvPbEvent(const FP3NetRecvPbEvent& Event)
{
	if (!ensure(ConnIds.Contains(Event.ConnId)))
	{
		P3JsonNetLog(Error, "Invalid player conn id", TEXT("ConnId"), Event.ConnId.X);
		return;
	}

	P3JsonNetLog(Verbose, "Player Message",
		TEXT("ConnId"), Event.ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::C2DType_Name((pb::C2DType)Event.MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Event.Message->DebugString().c_str())));

	switch (Event.MessageType)
	{
	case pb::C2D_PING:
		HandlePing(Event.ConnId, StaticCastSharedRef<const pb::C2DPing>(Event.Message).Get());
		break;

	case pb::C2D_HELLO:
		HandleHello(Event.ConnId, StaticCastSharedRef<const pb::C2DHello>(Event.Message).Get());
		break;

	case pb::C2D_CONSOLE_COMMAND:
		HandleConsoleCommand(Event.ConnId, StaticCastSharedRef<const pb::C2DConsoleCommand>(Event.Message).Get());
		break;

	case pb::C2D_UNREAL_RAW:
		HandleUnrealRaw(Event.ConnId, StaticCastSharedRef<const pb::C2DUnrealRaw>(Event.Message).Get());
		break;

	case pb::C2D_WORLD_MESSAGE:
		HandleWorldMessage(Event.ConnId, StaticCastSharedRef<const pb::C2DWorldMessage>(Event.Message).Get());
		break;

	case pb::C2D_ECHO_REQ:
		HandleEchoReq(Event.ConnId, StaticCastSharedRef<const pb::C2DEchoReq>(Event.Message).Get());
		break;

	case pb::C2D_ZONE_CHANGE:
		HandleZoneChange(Event.ConnId, StaticCastSharedRef<const pb::C2DZoneChange>(Event.Message).Get());
		break;

	default:
		P3JsonNetLog(Error, "Invalid C2D message type", TEXT("ConnId"), Event.ConnId.X, TEXT("MessageType"), Event.MessageType);
		break;
	}
}

void UP3PlayerNet::Listen()
{
	check(Net);

	TDescMap DescMap;
	DescMap.Add(pb::C2D_PING, pb::C2DPing::descriptor());
	DescMap.Add(pb::C2D_HELLO, pb::C2DHello::descriptor());
	DescMap.Add(pb::C2D_CONSOLE_COMMAND, pb::C2DHello::descriptor());
	DescMap.Add(pb::C2D_UNREAL_RAW, pb::C2DUnrealRaw::descriptor());
	DescMap.Add(pb::C2D_WORLD_MESSAGE, pb::C2DWorldMessage::descriptor());
	DescMap.Add(pb::C2D_ZONE_CHANGE, pb::C2DZoneChange::descriptor());
#if !UE_BUILD_SHIPPING
	DescMap.Add(pb::C2D_ECHO_REQ, pb::C2DEchoReq::descriptor());
#endif

	static const int32 MaxBacklog = 5;
	const float RetryIntervalSeconds = CVarP3DediListenRetryIntervalSeconds.GetValueOnGameThread();
	const int MaxSocketSendPerMessage = CVarP3DediListenMaxSocketSendPerMessage.GetValueOnGameThread();

	P3JsonNetLog(Display, "Create player listener",
		TEXT("Port"), Port,
		TEXT("MaxBacklog"), MaxBacklog,
		TEXT("RetryIntervalSeconds"), RetryIntervalSeconds);

	ListenerConnId = Net->Listen(this, "Player", Port, MaxBacklog, DescMap, RetryIntervalSeconds, MaxSocketSendPerMessage);
}

void UP3PlayerNet::Close(P3NetConnId ConnId)
{
	check(Net);

	ensure(ConnId != INVALID_NETCONNID);

	Net->Close(ConnId);
}

void UP3PlayerNet::Send(P3NetConnId ConnId, pb::D2CType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Net);

	ensure(ConnId != INVALID_NETCONNID);

	P3JsonNetLog(Verbose, "SendMessage (Player)",
		TEXT("ConnId"), ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::D2CType_Name(MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Message->DebugString().c_str())));

	Net->SendPb(ConnId, MessageType, Message);
}

void UP3PlayerNet::SendToAll(pb::D2CType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Net);

	P3JsonNetLog(Verbose, "SendMessage (Players)",
		TEXT("ListenerConnId"), ListenerConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::D2CType_Name(MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Message->DebugString().c_str())));

	for (auto It : PlayerSessions)
	{
		const FP3PlayerSession& Session = It.Value;

		if (!Session.bIsLocalConnection)
		{
			Net->SendPb(It.Key, MessageType, Message);
		}
	}
}

bool UP3PlayerNet::IsLocalConnection(P3NetConnId ConnId) const
{
	const FP3PlayerSession* SessionPtr = PlayerSessions.Find(ConnId);

	if (!SessionPtr)
	{
		return false;
	}

	return SessionPtr->bIsLocalConnection;
}

bool UP3PlayerNet::IsConnected(P3NetConnId ConnId) const
{
	return PlayerSessions.Contains(ConnId);
}

void UP3PlayerNet::HandlePing(P3NetConnId ConnId, const pb::C2DPing& Message)
{
	check(GameInstance && Net);

	UWorld* World = GameInstance->GetCurrentWorld();
	AP3GameMode* GameMode = World ? World->GetAuthGameMode<AP3GameMode>() : nullptr;
	float FrameTimeMsec = GameMode ? GameMode->GetAverageFrameTimeMsec() : 0.0f;

	TSharedRef<pb::D2CPong, ESPMode::ThreadSafe> Res(new pb::D2CPong());
	Res->set_ping_id(Message.ping_id());
	Res->set_server_frame_time_msec(FrameTimeMsec);

	Net->SendPb(ConnId, pb::D2C_PONG, Res);
}

void UP3PlayerNet::HandleHello(P3NetConnId ConnId, const pb::C2DHello& Message)
{
	check(GameInstance && Net);

	if (PlayerSessions.Contains(ConnId))
	{
		P3JsonNetLog(Error, "Already in player session", TEXT("ConnId"), ConnId.X);
		Net->Close(ConnId);
		return;
	}

	UWorld* World = GameInstance->GetCurrentWorld();
	if (!World || !World->GetGameState())
	{
		P3JsonNetLog(Error, "No world yet", TEXT("ConnId"), ConnId.X);
		Net->Close(ConnId);
		return;
	}

	FP3PlayerSession Session;
	Session.ConnId = ConnId;
	Session.bIsLocalConnection = Message.player_id() == "Standalone";

	PlayerSessions.Add(ConnId, Session);

	P3JsonNetLog(Display, "Player session created", TEXT("ConnId"), ConnId.X);
}

void UP3PlayerNet::HandleConsoleCommand(P3NetConnId ConnId, const pb::C2DConsoleCommand& Message)
{
	FString Command = UTF8_TO_TCHAR(Message.command().c_str());

	P3JsonNetLog(Warning, "Received console command",
		TEXT("ConnId"), ConnId.X,
		TEXT("Command"), *Command);

	GEngine->DeferredCommands.Add(Command);
}

void UP3PlayerNet::HandleUnrealRaw(P3NetConnId ConnId, const pb::C2DUnrealRaw& Message)
{
	check(GameInstance && Net);

	actorid ActorId = Message.actor_id();

	const ::std::string Source = Message.buffer();
	TArray<uint8> Buffer;
	Buffer.SetNumUninitialized(StaticCast<int32>(Source.length()));
	FMemory::Memcpy(Buffer.GetData(), Source.c_str(), Source.length());

	const FName HandlerFunctionName = UTF8_TO_TCHAR(Message.handler_function_name().c_str());

	P3JsonNetLog(Verbose, "UnrealRaw",
		TEXT("ActorId"), ActorId,
		TEXT("HandlerFunctionName"), HandlerFunctionName.ToString());

	UWorld* World = GameInstance->GetCurrentWorld();

	if (!World)
	{
		P3JsonNetLog(Error, "No world", TEXT("ConnId"), ConnId.X);
		return;
	}

	FP3PlayerSession* Session = PlayerSessions.Find(ConnId);

	if (!ensure(Session))
	{
		P3JsonNetLog(Error, "No session", TEXT("ConnId"), ConnId.X);
		return;
	}

	FP3NetHeader Header;
	Header.ComponentType = StaticCast<EP3NetComponentType>(Message.component_type());
	Header.HandlerFunctionName = HandlerFunctionName;

	FP3NetConnInfo NetConnInfo;
	NetConnInfo.TCPConnId = ConnId;
	P3Core::GetP3World(*World)->Server_HandlePacketBuffer(NetConnInfo, ActorId, nullptr, Buffer, Header);
}

void UP3PlayerNet::HandleWorldMessage(P3NetConnId ConnId, const pb::C2DWorldMessage& Message)
{
	check(GameInstance && Net);

	UWorld* World = GameInstance->GetCurrentWorld();

	if (!ensure(World))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = P3Core::GetP3World(*World)->GetServerWorld();

	if (!ensure(ServerWorld))
	{
		return;
	}

	FP3NetConnInfo NetConn;
	NetConn.TCPConnId = P3NetConnId(ConnId);

	ServerWorld->SendWorldMessageToWorldServer(NetConn, Message);
}

void UP3PlayerNet::HandleEchoReq(P3NetConnId ConnId, const pb::C2DEchoReq& Message)
{
	check(GameInstance && Net);

	TSharedRef<pb::D2CEchoRes, ESPMode::ThreadSafe> Res(new pb::D2CEchoRes());
	Res->set_buffer(Message.buffer());

	Net->SendPb(ConnId, pb::D2C_ECHO_RES, Res);
}

void UP3PlayerNet::HandleZoneChange(P3NetConnId ConnId, const pb::C2DZoneChange& Message)
{
	check(GameInstance && Net);

	TSharedRef<pb::D2CZoneChangeRes, ESPMode::ThreadSafe> Res(new pb::D2CZoneChangeRes());

	Net->SendPb(ConnId, pb::D2C_ZONE_CHANGE_RES, Res);
}

void UP3PlayerNet::Tick(float DeltaTime)
{
	check(Net);
}
