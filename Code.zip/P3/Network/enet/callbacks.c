/** 
 @file callbacks.c
 @brief ENet callback functions
*/

// Disable 4668, using undefined preprocessor (__cplusplus), this is needed since this file is using c compiler, not c++ compiler
#ifdef _MSC_VER
	#pragma warning(push)
	#pragma warning(disable:4668)
#endif

//#define ENET_BUILDING_LIB 1
#include "Network/enet/enet.h"

#ifdef _MSC_VER
	#pragma warning(pop)	// disable:4668
#endif

static ENetCallbacks callbacks = { malloc, free, abort };

int
enet_initialize_with_callbacks (ENetVersion version, const ENetCallbacks * inits)
{
   if (version < ENET_VERSION_CREATE (1, 3, 0))
     return -1;

   if (inits -> malloc != NULL || inits -> free != NULL)
   {
      if (inits -> malloc == NULL || inits -> free == NULL)
        return -1;

      callbacks.malloc = inits -> malloc;
      callbacks.free = inits -> free;
   }
      
   if (inits -> no_memory != NULL)
     callbacks.no_memory = inits -> no_memory;

   return enet_initialize ();
}

ENetVersion
enet_linked_version (void)
{
    return ENET_VERSION;
}
           
void *
enet_malloc (size_t size)
{
   void * memory = callbacks.malloc (size);

   if (memory == NULL)
     callbacks.no_memory ();

   return memory;
}

void
enet_free (void * memory)
{
   callbacks.free (memory);
}

