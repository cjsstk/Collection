// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Lib/P3Net.h"
#include "Protocol/P3ChatProtocol.h"
#include "P3ChatNet.generated.h"

DECLARE_MULTICAST_DELEGATE_ThreeParams(UP3ChatNetOnChat, const FString&, uint32, const FString&);

UCLASS()
class UP3ChatNet : public UObject, public IP3BaseNet, public IP3ChatSCPacketHandler
{
	GENERATED_BODY()

public:
	virtual ~UP3ChatNet() {}

	void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet);
	void Shutdown();

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event);
	virtual void HandleListenEvent(const FP3NetListenEvent& Event) {}
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event) {}
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event);
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event) {}
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event);

	void Connect(float InitialDelaySeconds = 0.0f);
	void Close();
	void Send(TSharedRef<const FP3NetCSMessage, ESPMode::ThreadSafe> Message);
	EP3NetConnStatus GetConnStatus() const;

	const FString& GetHost() { return Host; }
	void SetHost(const FString& InHost) { Host = InHost; }
	int32 GetPort() { return Port; }
	void SetPort(int32 InPort) { Port = InPort; }

	UP3ChatNetOnChat OnChat;

private:
	// IP3ChatSCPacketHandler Interface
	virtual void HandleProceed(const FP3ChatProtocol::FSCProceed& Message) override;
	virtual void HandleCreateReply(const FP3ChatProtocol::FSCCreateReply& Message) override;
	virtual void HandleJoinReply(const FP3ChatProtocol::FSCJoinReply& Message) override;
	virtual void HandleLeaveReply(const FP3ChatProtocol::FSCLeaveReply& Message) override;
	virtual void HandleChatReply(const FP3ChatProtocol::FSCChatReply& Message) override;
	virtual void HandleChat(const FP3ChatProtocol::FSCChat& Message) override;

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	UPROPERTY()
	UP3Net* Net = nullptr;

	FString Host;
	int32 Port = 0;
	P3NetConnId ConnId = INVALID_NETCONNID;
	EP3NetConnStatus ConnStatus = EP3NetConnStatus::Closed;
};
