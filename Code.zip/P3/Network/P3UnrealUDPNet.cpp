// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UnrealUDPNet.h"

#include "DataChannel.h"
#include "Engine/Engine.h"
#include "Engine/GameEngine.h"
#include "GameFramework/GameModeBase.h"
#include "Misc/TimeGuard.h"
#include "Net/NetworkProfiler.h"
#include "NetworkVersion.h"
#include "ProfilingDebugging/CsvProfiler.h"

#include "P3ActorChannel.h"
#include "P3ActorInterface.h"
#include "P3Channel.h"
#include "P3ClientWorld.h"
#include "P3ServerWorld.h"
#include "P3GameMode.h"
#include "P3Log.h"
#include "P3NetConnection.h"
#include "P3PackageMapClient.h"
#include "P3World.h"

static TAutoConsoleVariable<float> CVarP3ClientDisconnectionDetectIntervalSeconds(
	TEXT("p3.clientDisconnectionDetectIntervalSeconds"),
	30.0f,
	TEXT("Interval when client disconneted from dedi server"), ECVF_Default);

extern TAutoConsoleVariable<float> CVarP3PingUpdatePeriodSecondsDebug;
extern TAutoConsoleVariable<float> CVarP3NetStatUpdatePeriod;

int32 UP3UnrealUDPNet::NetDriveCount = 0;

UP3Channel* UP3UnrealUDPNet::GetControlChannel(const UNetConnection* Connection)
{
	if (!ensure(Connection))
	{
		return nullptr;
	}

	if (!Connection->Channels[ControlChannelIndex])
	{
		return nullptr;
	}

	return GetP3Channel<UP3Channel>(Connection->Channels[ControlChannelIndex]);
}

UP3NetConnection* UP3UnrealUDPNet::GetP3Connection(UNetConnection* Connection)
{
	if (!ensure(Connection))
	{
		return nullptr;
	}

	return Cast<UP3NetConnection>(Connection);
}

UWorld* UP3UnrealUDPNet::CreateDummyWorld()
{
	UWorld* NewWorld = UWorld::CreateWorld(EWorldType::None, false);

	if (!ensure(NewWorld))
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("failed to create dummy world"));
		return nullptr;
	}

	NewWorld->bBegunPlay = 1;
	NewWorld->bActorsInitialized = 1;

	if (GEngine)
	{
		FWorldContext& CurContext = GEngine->CreateNewWorldContext(EWorldType::None);
		CurContext.SetCurrentWorld(NewWorld);
	}

	return NewWorld;
}

UNetDriver* UP3UnrealUDPNet::CreateOrChangeNetDriver(UWorld* NewWorld, UWorld* OldWorld, const FName& NetDriverDefName/* = NAME_None*/)
{
	check(NewWorld);

	UNetDriver* NewNetDriver = nullptr;

	UGameEngine* GameEngine = Cast<UGameEngine>(GEngine);

	if (GameEngine)
	{
		FNetDriverDefinition NewDriverEntry;
		NewDriverEntry.DefName = NetDriverDefName;
		NewDriverEntry.DriverClassName = TEXT("/Script/OnlineSubsystemUtils.IpNetDriver");
		NewDriverEntry.DriverClassNameFallback = NewDriverEntry.DriverClassName;
		GameEngine->NetDriverDefinitions.Add(NewDriverEntry);

		FName NewDriverName = NetDriverDefName;
		if (NetDriverDefName != NAME_None)
		{
			NewDriverName = *FString::Printf(TEXT("%s_%i"), *NetDriverDefName.ToString(), NetDriveCount++);
		}

		if (GameEngine->CreateNamedNetDriver(NewWorld, NewDriverName, NetDriverDefName))
		{
			NewNetDriver = GameEngine->FindNamedNetDriver(NewWorld, NewDriverName);
		}

		if (!ensure(NewNetDriver))
		{
			UE_LOG(P3UDPNetLog, Error, TEXT("failed to create netdriver: %s"), *NewDriverName.ToString());
			return nullptr;
		}

		if (OldWorld)
		{
			UNetDriver* OldNetDriver = OldWorld->GetNetDriver();

			if (OldNetDriver)
			{
				FWorldContext& OldWorldContext = GameEngine->GetWorldContextFromWorldChecked(OldWorld);
				FWorldContext& NewWorldContext = GameEngine->GetWorldContextFromWorldChecked(NewWorld);
				Swap(OldWorldContext.ActiveNetDrivers, NewWorldContext.ActiveNetDrivers);

				OldWorld->SetNetDriver(NewNetDriver);

				FLevelCollection* const SourceCollection = OldWorld->FindCollectionByType(ELevelCollectionType::DynamicSourceLevels);
				if (SourceCollection)
				{
					SourceCollection->SetNetDriver(nullptr);
				}
				FLevelCollection* const StaticCollection = OldWorld->FindCollectionByType(ELevelCollectionType::StaticLevels);
				if (StaticCollection)
				{
					StaticCollection->SetNetDriver(nullptr);
				}

				GameEngine->ShutdownWorldNetDriver(OldWorld);

				NewNetDriver = OldNetDriver;
			}
		}
	}

	if (NewNetDriver)
	{
		NewNetDriver->SetWorld(NewWorld);
		NewWorld->SetNetDriver(NewNetDriver);

		if (OldWorld == nullptr)
		{
			NewNetDriver->InitConnectionClass();
			FLevelCollection* const Collection = (FLevelCollection*)NewWorld->GetActiveLevelCollection();
			if (Collection != nullptr)
			{
				Collection->SetNetDriver(NewNetDriver);
			}
		}
		else
		{
			FLevelCollection* const SourceCollection = NewWorld->FindCollectionByType(ELevelCollectionType::DynamicSourceLevels);
			if (SourceCollection)
			{
				SourceCollection->SetNetDriver(NewNetDriver);
			}
			FLevelCollection* const StaticCollection = NewWorld->FindCollectionByType(ELevelCollectionType::StaticLevels);
			if (StaticCollection)
			{
				StaticCollection->SetNetDriver(NewNetDriver);
			}

			if ((NewNetDriver->MaxInternetClientRate < NewNetDriver->MaxClientRate) && (NewNetDriver->MaxInternetClientRate > 2500))
			{
				NewNetDriver->MaxClientRate = NewNetDriver->MaxInternetClientRate;
			}

			NewWorld->NextSwitchCountdown = NewNetDriver->ServerTravelPause;
		}
	}

	return NewNetDriver;
}

void UP3UnrealUDPNet::Initialize(UP3GameInstance*)
{
	NetworkNotify.UDPNet = this;
	MessageHandler.SetUDPNet(this);

	bState = EP3UDPNetState::Inactived;

	UE_LOG(P3UDPNetLog, Log, TEXT("Unreal UDP Net is Active"));
}

bool UP3UnrealUDPNet::Init(UP3World* InP3World, const FString& InHost/* = TEXT("")*/, int32 InPort/* = 0*/)
{
	UWorld* InWorld = InP3World->GetWorld();

	if (!InHost.IsEmpty())
	{
		Host = InHost;
	}

	if (InPort != 0)
	{
		Port = InPort;
	}

	FURL ServerURL;

	if (Host.IsEmpty())
	{
		Host = ServerURL.UrlConfig.DefaultHost;
	}

	if (Port == 0)
	{
		Port = ServerURL.UrlConfig.DefaultPort;
	}

	if (bServer)
	{
		check(InWorld);

		if (!ensure(bState == EP3UDPNetState::Inactived))
		{
			return false;
		}

		if (GEngine && GEngine->IsEditor())
		{
			return InitNetDriver(InWorld, EP3NetDriverMode::None);
		}
		else
		{
			return InitNetDriver(InWorld, EP3NetDriverMode::DefaultServerMode);
			//return InitNetDriver(InWorld, EP3NetDriverMode::LinkDummyWorld, true);
		}
	}
	else
	{
		if (!ensure(bState == EP3UDPNetState::Inactived))
		{
			return false;
		}

		return InitNetDriver(InWorld, EP3NetDriverMode::DefaultClientMode);
		//return InitNetDriver(InWorld, EP3NetDriverMode::UnlinkWorld, false);
	}
}

void UP3UnrealUDPNet::Shutdown()
{
	WorldTickHook.UnregisterTickEvents();

	if (bServer)
	{
		if (GEngine)
		{
			GEngine->ShutdownWorldNetDriver(DummyWorld ? DummyWorld : GameWorld);
		}
	}
	else
	{
		if (NetDriver && NetDriver->ServerConnection)
		{
			NetDriver->ServerConnection->CleanUp();
		}

		if (GEngine && DummyWorld)
		{
			GEngine->ShutdownWorldNetDriver(DummyWorld);
		}
	}

	if (DummyWorld)
	{
		DummyWorld->DestroyWorld(false);
		DummyWorld = nullptr;
	}

	NetDriver = nullptr;
	GameWorld = nullptr;

	MappedClientConnectionAddrs.Empty();
	PendingActorChannels.Empty();

	bState = EP3UDPNetState::Inactived;
}

void UP3UnrealUDPNet::Close(P3NetConnId ConnId/* = INVALID_NETCONNID*/)
{
	if (bServer)
	{
		UNetConnection* Connection = Server_GetConnection(ConnId);

		if (Connection)
		{
			Connection->CleanUp();
		}
	}
	else
	{
		Shutdown();
	}
}

void UP3UnrealUDPNet::CloseConnection(UNetConnection* Connection)
{
	if (!ensure(Connection))
	{
		return;
	}

	if (!ensure(GameWorld))
	{
		return;
	}

	if (bServer)
	{
		const UP3NetConnection* P3Connection = GetP3Connection(Connection);

		P3NetConnId ConnId = P3Connection ? P3Connection->GetConnectionId() : INVALID_NETCONNID;

		if (ConnId != INVALID_NETCONNID)
		{
			Server_RemoveConnection(ConnId);

			UP3World* P3World = P3Core::GetP3World(*GameWorld);
			UP3ServerWorld* ServerWorld = P3World ? P3World->GetServerWorld() : nullptr;

			if (ensure(ServerWorld))
			{
				FP3NetConnInfo NetConnInfo;
				NetConnInfo.UDPConnId = ConnId;

				ServerWorld->NetOnPlayerDisconnected(NetConnInfo);
			}
		}
	}
	else
	{
		UP3World* P3World = P3Core::GetP3World(*GameWorld);
		UP3ClientWorld* ClientWorld = P3World ? P3World->GetClientWorld() : nullptr;

		if (ensure(ClientWorld))
		{
			ClientWorld->OnDisconnected();
		}

		bSuccessfullyConnected = false;
		bSentJoinRequest = false;
		bCreatedBaseActorChannel = false;
		bNotifyConnected = false;
	}
}

bool UP3UnrealUDPNet::InitNetDriver(UWorld* InWorld, uint32 InNetDriverMode)
{
	check(bState != EP3UDPNetState::Actived);
	check(GEngine);

	if (bServer)
	{
		check(InWorld);
	}

	GameWorld = InWorld;
	NetDriverMode = InNetDriverMode;

	if (NetDriverMode == WorldNetDriver)
	{
		verifyf(bServer, TEXT("Client can not start with WorldNetDriver"));

		NetDriver = GameWorld ? GameWorld->GetNetDriver() : nullptr;
		if (NetDriver)
		{
			NetDriver->Notify = StaticCast<FNetworkNotify*>(&NetworkNotify);

			check(NetDriver->Notify);

			GameWorld->OnTickDispatch().Remove(NetDriver->TickDispatchDelegateHandle);
			GameWorld->OnPostTickDispatch().Remove(NetDriver->PostTickDispatchDelegateHandle);
			GameWorld->OnTickFlush().Remove(NetDriver->TickFlushDelegateHandle);
			GameWorld->OnPostTickFlush().Remove(NetDriver->PostTickFlushDelegateHandle);

			WorldTickHook.RegisterTickEvents(NetDriver);
		}
	}
	else if (NetDriverMode == UnlinkWorld)
	{
		verifyf(!bServer, TEXT("Server can not start with UnlinkWorld"));

		check(NetDriver == nullptr);

		NetDriver = CreateOrChangeNetDriver(GameWorld, nullptr, "P3NetDriver");

		if (NetDriver)
		{
			GameWorld->SetNetDriver(nullptr);
			NetDriver->SetWorld(nullptr);

			WorldTickHook.RegisterTickEvents(NetDriver);
		}
	}
	else if (NetDriverMode == LinkDummyWorld)
	{
		check(NetDriver == nullptr);

		DummyWorld = CreateDummyWorld();

		if (DummyWorld)
		{
			if (bServer)
			{
				NetDriver = CreateOrChangeNetDriver(DummyWorld, GameWorld, NAME_GameNetDriver);
			}
			else
			{
				NetDriver = CreateOrChangeNetDriver(DummyWorld, nullptr, "P3NetDriver");
			}

			if (NetDriver)
			{
				DummyWorld->OnTickDispatch().Remove(NetDriver->TickDispatchDelegateHandle);
				DummyWorld->OnPostTickDispatch().Remove(NetDriver->PostTickDispatchDelegateHandle);
				DummyWorld->OnTickFlush().Remove(NetDriver->TickFlushDelegateHandle);
				DummyWorld->OnPostTickFlush().Remove(NetDriver->PostTickFlushDelegateHandle);

				WorldTickHook.RegisterTickEvents(NetDriver);

				if (bServer)
				{
					NetDriver->Notify = StaticCast<FNetworkNotify*>(&NetworkNotify);

					check(NetDriver->Notify);
				}
			}
		}
	}
	else
	{
		return true;
	}

	check(NetDriver);

	NetDriver->SetReplicationDriver(nullptr);

	InitChannel();

	NetDriver->NetConnectionClass = UP3NetConnection::StaticClass();

	UClass* NetConnClass = NetDriver->NetConnectionClass;
	UProperty* OldPostConstructLink = nullptr;
	UNetConnection* DefConn = nullptr;
	UProperty* PackageMapProp = nullptr;
	TSubclassOf<UPackageMap> OldClass;

	if (NetConnClass)
	{
		DefConn = Cast<UNetConnection>(NetConnClass->GetDefaultObject());

		if (DefConn)
		{
			OldClass = DefConn->PackageMapClass;
			OldPostConstructLink = NetConnClass->PostConstructLink;
			PackageMapProp = FindFieldChecked<UProperty>(NetConnClass, TEXT("PackageMapClass"));

			// Hack - force property initialization for the PackageMapClass property, so changing its default value works.
			check(PackageMapProp != nullptr && PackageMapProp->PostConstructLinkNext == nullptr);

			PackageMapProp->PostConstructLinkNext = NetConnClass->PostConstructLink;
			NetConnClass->PostConstructLink = PackageMapProp;
			DefConn->PackageMapClass = UP3PackageMapClient::StaticClass();
		}
	}

	if (bServer)
	{
		NetDriver->RecentlyDisconnectedTrackingTime = 0;
	}
	else
	{
		Client_Connect();

		if (DefConn)
		{
			DefConn->PackageMapClass = OldClass;

			if (NetConnClass)
			{
				NetConnClass->PostConstructLink = OldPostConstructLink;
			}

			if (PackageMapProp)
			{
				PackageMapProp->PostConstructLinkNext = nullptr;
			}
		}
	}

	NetDriver->InitialConnectTimeout = FMath::Max(NetDriver->InitialConnectTimeout, ConnectTimeOut);
	NetDriver->ConnectionTimeout = FMath::Max(NetDriver->ConnectionTimeout, ConnectTimeOut);

	bState = EP3UDPNetState::Actived;
	return true;
}

void UP3UnrealUDPNet::InitChannel()
{
	check(NetDriver);

	NetDriver->ChannelDefinitionMap[NAME_Control].ChannelClass = UP3Channel::StaticClass();

	const int32 Num = NetDriver->ChannelDefinitions.RemoveAll([](const FChannelDefinition& Def) -> bool {
		return Def.ChannelName == NAME_Voice;
	});

	if (Num > 0)
	{
		FChannelDefinition* ChannelDefinition = NetDriver->ChannelDefinitionMap.Find(NAME_Voice);
		if (ChannelDefinition)
		{
			NetDriver->ChannelDefinitionMap.Remove(NAME_Voice);
		}
	}

	NetDriver->ChannelDefinitionMap[NAME_Actor].ChannelClass = UP3ActorChannel::StaticClass();
}

// bool UP3UnrealUDPNet::Server_Listen()
// {
// 	check(DummyWorld);
// 	check(NetDriver);
// 	check(Host.IsEmpty() && Port != 0);
// 
// 	FURL ServerURL;
// 	ServerURL.Host = Host;
// 	ServerURL.Port = Port;
// 
// 	FString Error;
// 	if (!NetDriver->InitListen(&NetworkNotify, ServerURL, false, Error))
// 	{
// 		GEngine->BroadcastNetworkFailure(DummyWorld, NetDriver, ENetworkFailure::NetDriverListenFailure, Error);
// 		UE_LOG(P3UDPNetLog, Error, TEXT("Failed to listen: %s"), *Error);
// 		NetDriver->SetWorld(nullptr);
// 		NetDriver = nullptr;
// 		FLevelCollection* SourceCollection = DummyWorld->FindCollectionByType(ELevelCollectionType::DynamicSourceLevels);
// 		if (SourceCollection)
// 		{
// 			SourceCollection->SetNetDriver(nullptr);
// 		}
// 		FLevelCollection* StaticCollection = DummyWorld->FindCollectionByType(ELevelCollectionType::StaticLevels);
// 		if (StaticCollection)
// 		{
// 			StaticCollection->SetNetDriver(nullptr);
// 		}
// 		return false;
// 	}
// 
// 	return true;
// }

bool UP3UnrealUDPNet::Client_Connect()
{
	check(NetDriver);
	check(!Host.IsEmpty() && Port != 0);

	FURL ServerURL;
	ServerURL.Host = Host;
	ServerURL.Port = Port;

	FString ConnectionError = "Error creating P3 network driver.";

	if (NetDriver->InitConnect(&NetworkNotify, ServerURL, ConnectionError))
	{
		UNetConnection* ServerConn = NetDriver->ServerConnection;
		if (!ensure(ServerConn))
		{
			return false;
		}

		UP3Channel* P3Channel = GetControlChannel(ServerConn);
		if (P3Channel)
		{
			P3Channel->SetUDPNet(this);
		}

		// Kick off the connection handshake
		if (ServerConn->Handler.IsValid())
		{
			ServerConn->Handler->BeginHandshaking(
				FPacketHandlerHandshakeComplete::CreateUObject(this, &UP3UnrealUDPNet::Client_SendInitialJoin));
		}
		else
		{
			Client_SendInitialJoin();
		}
	}
	else
	{
		// error initializing the network stack...
		UE_LOG(P3UDPNetLog, Warning, TEXT("error initializing the network stack"));
		GEngine->DestroyNamedNetDriver(DummyWorld ? DummyWorld : GameWorld, NetDriver->NetDriverName);
		NetDriver = nullptr;

		// ConnectionError should be set by calling InitConnect...however, if we set NetDriver to NULL without setting a
		// value for ConnectionError, we'll trigger the assertion at the top of UP3UnrealUDPNet::Tick() so make sure it's set
		if (ConnectionError.Len() == 0)
		{
			ConnectionError = "Error initializing network layer.";
		}

		return false;
	}

	return true;
}

void UP3UnrealUDPNet::Client_SendInitialJoin()
{
	if (!ensure(!bServer))
	{
		return;
	}

	if (!ensure(NetDriver))
	{
		return;
	}

	UNetConnection* ServerConn = NetDriver->ServerConnection;
	if (ensure(ServerConn))
	{
		uint8 IsLittleEndian = uint8(PLATFORM_LITTLE_ENDIAN);
		check(IsLittleEndian == !!IsLittleEndian); // should only be one or zero

		uint32 LocalNetworkVersion = FNetworkVersion::GetLocalNetworkVersion();

		UE_LOG(P3UDPNetLog, Log, TEXT("UPendingNetGame::SendInitialJoin: Sending hello. %s"), *ServerConn->Describe());

		FString EncryptionToken = TEXT("");
		FNetControlMessage<NMT_Hello>::Send(ServerConn, IsLittleEndian, LocalNetworkVersion, EncryptionToken);
		ServerConn->FlushNet();
	}
}

void UP3UnrealUDPNet::Client_SendJoin()
{
	if (!ensure(!bServer))
	{
		return;
	}

	if (!ensure(NetDriver))
	{
		return;
	}

	UNetConnection* ServerConn = NetDriver->ServerConnection;
	if (ensure(ServerConn))
	{
		bSentJoinRequest = true;
		FNetControlMessage<NMT_Join>::Send(ServerConn);
		ServerConn->FlushNet();
	}
}

void UP3UnrealUDPNet::Tick(float DeltaSeconds)
{
	if (bState == EP3UDPNetState::Inactived)
	{
		return;
	}

	if (WorldTickHook.IsEnabled())
	{
		WorldTickHook.TickDispatch(DeltaSeconds);

		if (bServer)
		{
			TickNetServer(DeltaSeconds);
		}
		else
		{
			TickNetClient(DeltaSeconds);
		}

		WorldTickHook.TickFlush(DeltaSeconds);
	}

	UpdateStat();
}

void UP3UnrealUDPNet::TickNetClient(float DeltaSeconds)
{
	SCOPE_TIME_GUARD(TEXT("UP3UnrealUDPNet::TickNetClient"));

	if (bServer)
	{
		return;
	}

	if (!NetDriver || !NetDriver->ServerConnection)
	{
		return;
	}

	if (bSuccessfullyConnected && !bSentJoinRequest)
	{
		Client_SendJoin();
	}

	if (NetDriver->ServerConnection->State == USOCK_Open)
	{
		if (bCreatedBaseActorChannel && !bNotifyConnected)
		{
			check(GameWorld);

			UP3World* P3World = P3Core::GetP3World(*GameWorld);
			check(P3World);
			check(P3World->GetClientWorld());

			P3World->GetClientWorld()->OnConnected();
			bNotifyConnected = true;
		}

		UP3NetConnection* P3Connection = GetP3Connection(NetDriver->ServerConnection);

		if (ensure(P3Connection))
		{
			const FDateTime Now = FDateTime::Now();

			const FTimespan TimeSinceUpdate = Now - P3Connection->PingTime.LastPingSentTime;
			if (TimeSinceUpdate.GetTotalSeconds() > CVarP3PingUpdatePeriodSecondsDebug.GetValueOnGameThread())
			{
				++P3Connection->PingTime.PingId;

				P3Connection->PingTime.LastPingSentTime = Now;

				FNetControlMessage<NMT_P3Ping>::Send(NetDriver->ServerConnection, P3Connection->PingTime.PingId, P3Connection->PingTime.PingTimeMsec);
			}
		}
	}
	else if (NetDriver->ServerConnection->State == USOCK_Closed)
	{
		// If our net driver has lost connection to the server,
		// and there isn't a PendingNetGame, throw a network failure error.

		// 			check(GEngine);
		// 			UWorld* World = DummyWorld ? DummyWorld : GameWorld;
		// 			if (GEngine->PendingNetGameFromWorld(World) == nullptr)
		// 			{
		// 				const FString Error = "Your connection to the host has been lost.";
		// 				GEngine->BroadcastNetworkFailure(World, NetDriver, ENetworkFailure::ConnectionLost, Error);
		// 			}
	}

// 	InPacketLost = NetDriver->ServerConnection->InPacketsLost;
// 	OutPacketsLost = NetDriver->ServerConnection->OutPacketsLost;
// 	InTotalPacketsLost = NetDriver->ServerConnection->InTotalPacketsLost;
// 	OutTotalPacketsLost = NetDriver->ServerConnection->OutTotalPacketsLost;
// 
// 	if (InPacketLost != 0 || OutPacketsLost != 0 || InTotalPacketsLost != 0 || OutTotalPacketsLost != 0)
// 	{
// 		//UE_LOG(P3UDPNetLog, Log, TEXT("In:%d Out:%d TotalIn:%d TotalOut:%d"), InPacketLost, OutPacketsLost, InTotalPacketsLost, OutTotalPacketsLost);
// 	}
}

void UP3UnrealUDPNet::TickNetServer(float DeltaSeconds)
{
	if (!bServer)
	{
		return;
	}

	const FDateTime Now = FDateTime::Now();

	TArray<UP3NetConnection*> DisconnectedConnetions;

	for (UNetConnection* const ClientConnection : NetDriver->ClientConnections)
	{
		if (!ensure(ClientConnection))
		{
			continue;
		}

		if (ClientConnection->ClientLoginState == EClientLoginState::ReceivedJoin)
		{
			UP3NetConnection* P3Connection = UP3UnrealUDPNet::GetP3Connection(ClientConnection);

			if (ensure(P3Connection))
			{
				const FTimespan TimeSinceUpdate = Now - P3Connection->LastPingReceivedTime;

				if (TimeSinceUpdate.GetTotalSeconds() > CVarP3ClientDisconnectionDetectIntervalSeconds.GetValueOnGameThread())
				{
					DisconnectedConnetions.Add(P3Connection);
				}
			}
		}
	}

	for (const UP3NetConnection* const P3Connection : DisconnectedConnetions)
	{
		if (ensure(P3Connection))
		{
			UE_LOG(P3UDPNetLog, Log, TEXT("disconnect timeout: client(%d)"), P3Connection->GetConnectionId().X);
			Close(P3Connection->GetConnectionId());
		}
	}

	DisconnectedConnetions.Empty();
}

void UP3UnrealUDPNet::Server_SendChallengeControlMessage(UNetConnection* Connection)
{
	if (!ensure(bServer))
	{
		return;
	}

	if (ensure(Connection))
	{
		if (Connection->State != USOCK_Invalid && Connection->State != USOCK_Closed && Connection->Driver)
		{
			Connection->Challenge = FString::Printf(TEXT("%08X"), FPlatformTime::Cycles());
			Connection->SetExpectedClientLoginMsgType(NMT_Login);
			FNetControlMessage<NMT_Challenge>::Send(Connection, Connection->Challenge);
			Connection->FlushNet();
		}
		else
		{
			UE_LOG(P3UDPNetLog, Error, TEXT("SendChallengeControlMessage: connection in invalid state. %s"), *Connection->Describe());
		}
	}
	else
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("SendChallengeControlMessage: Connection is null."));
	}
}

void UP3UnrealUDPNet::Server_WelcomePlayer(UNetConnection* Connection)
{
	if (!ensure(bServer))
	{
		return;
	}

	if (ensure(Connection))
	{
		//Connection->SendPackageMap();

		FString LevelName;
		FString GameName;
		FString RedirectURL;

		if (GameWorld)
		{
			if (GameWorld->GetCurrentLevel() && GameWorld->GetCurrentLevel()->GetOutermost())
			{
				LevelName = GameWorld->GetCurrentLevel()->GetOutermost()->GetName();
			}

			if (GameWorld->GetAuthGameMode())
			{
				GameName = GameWorld->GetAuthGameMode()->GetClass()->GetPathName();
			}
		}

		FNetControlMessage<NMT_Welcome>::Send(Connection, LevelName, GameName, RedirectURL);
		Connection->FlushNet();

		// don't count initial join data for netspeed throttling
		// as it's unnecessary, since connection won't be fully open until it all gets received, and this prevents later gameplay data from being delayed to "catch up"
		Connection->QueuedBits = 0;
		Connection->SetClientLoginState(EClientLoginState::Welcomed);		// Client has been told to load the map, will respond via SendJoin
	}
	else
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("Server_WelcomePlayer: Connection is null."));
	}
}

UP3ActorChannel* UP3UnrealUDPNet::Server_CreateActorChannel(P3NetConnId ConnId, AActor* Actor, FP3NetSpawnActorParams* SpawnActorParam/* = nullptr*/)
{
	if (!ensure(bServer))
	{
		return nullptr;
	}

	UNetConnection * Connection = Server_GetConnection(ConnId);

	if (!ensure(Connection))
	{
		return nullptr;
	}

	return Server_CreateActorChannel(Connection, Actor, SpawnActorParam);
}

UP3ActorChannel* UP3UnrealUDPNet::Server_CreateActorChannel(UNetConnection* Connection, AActor* Actor, FP3NetSpawnActorParams* SpawnActorParam)
{
	if (!ensure(bServer))
	{
		return nullptr;
	}

	if (!ensure(Connection))
	{
		return nullptr;
	}

	UP3ActorChannel* ActorChannel = nullptr;

	if (Actor == nullptr)
	{
		if (!ensure(Connection->Channels[BaseActorChannelIndex] == nullptr))
		{
			UE_LOG(P3UDPNetLog, Error, TEXT("CreateActorChannel: Channel was already created."));
			return nullptr;
		}

		UChannel* Channel = Connection->CreateChannelByName(NAME_Actor, EChannelCreateFlags::OpenedLocally, BaseActorChannelIndex);

		if (!ensure(Channel))
		{
			UE_LOG(P3UDPNetLog, Error, TEXT("CreateActorChannel: failed to create base ActorChannel"));
			return nullptr;
		}

		if (!ensure(BaseActorChannelIndex == Channel->ChIndex))
		{
			UE_LOG(P3UDPNetLog, Error, TEXT("CreateActorChannel: invalid ActorChannel index(%d)"), Channel->ChIndex);
			return nullptr;
		}

		ActorChannel = GetP3Channel<UP3ActorChannel>(Channel);

		if (ensure(ActorChannel))
		{
			ActorChannel->Server_InitChannel(Actor, this, nullptr);
		}
	}
	else
	{
		UChannel* Channel = Connection->CreateChannelByName(NAME_Actor, EChannelCreateFlags::OpenedLocally);

		if (!ensure(Channel))
		{
			IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
			actorid ActorId = ActorInterface ? ActorInterface->GetActorId() : INVALID_ACTORID;
			UE_LOG(P3UDPNetLog, Error, TEXT("CreateActorChannel: failed to create ActorChannel - Actor: %d"), ActorId);
			return nullptr;
		}

		ActorChannel = GetP3Channel<UP3ActorChannel>(Channel);

		if (ensure(ActorChannel))
		{
			if (SpawnActorParam != nullptr)
			{
				if (ensure(GameWorld))
				{
					UP3World* P3World = P3Core::GetP3World(*GameWorld);
					FP3StoreBitWriter BitWriter(P3World, 256, true);
					FP3NetSpawnActorParams::StaticStruct()->SerializeBin(BitWriter, SpawnActorParam);

					const TArray<uint8>& SpawnData = *BitWriter.GetBuffer();
					ActorChannel->Server_InitChannel(Actor, this, &SpawnData);
				}
			}
			else
			{
				ActorChannel->Server_InitChannel(Actor, this, nullptr);
			}
		}
	}

	return ActorChannel;
}

void UP3UnrealUDPNet::Server_DestroyActorChannel(P3NetConnId ConnId, actorid ActorId)
{
	if (!ensure(bServer))
	{
		return;
	}

	if (ensure(ActorId != INVALID_ACTORID))
	{
		UNetConnection* Connection = Server_GetConnection(ConnId);

		if (!Connection)
		{
			return;
		}

		UP3NetConnection* P3Connection = GetP3Connection(Connection);

		if (ensure(P3Connection))
		{
			UP3ActorChannel* ActorChannel = P3Connection->FindActorIdChannelRef(ActorId);

			if (ActorChannel)
			{
				ActorChannel->SetChannelActorForDestroy();

				ActorChannel->ConditionalCleanUp(true, EChannelCloseReason::Destroyed);
			}
		}
	}
}

void UP3UnrealUDPNet::Client_SetChannelActor(actorid ActorId, AActor* Actor, bool bIsLocalActor)
{
	if (!ensure(!bServer))
	{
		return;
	}

	int32 Index = -1;
	for (UP3ActorChannel* ActorChannel : PendingActorChannels)
	{
		++Index;
		if (ActorChannel && ActorChannel->GetActorId() == ActorId)
		{
			ActorChannel->SetChannelActor(Actor, bIsLocalActor);
			break;
		}
	}

	if (ensure(Index != -1))
	{
		PendingActorChannels.RemoveAt(Index);
	}
}

P3NetConnId UP3UnrealUDPNet::InitNetConnection(UNetConnection* Connection)
{
	if (!ensure(Connection))
	{
		return INVALID_NETCONNID;
	}

	P3NetConnId ConnId = INVALID_NETCONNID;

	UP3NetConnection* P3Connection = UP3UnrealUDPNet::GetP3Connection(Connection);

	if (ensure(P3Connection))
	{
		ConnId = P3NetConnId(IncreaseSequenceId());

		P3Connection->SetConnectionId(ConnId);
	}

	return ConnId;
}

bool UP3UnrealUDPNet::Server_AddConnection(UNetConnection* NewConnection)
{
	if (!ensure(bServer))
	{
		return false;
	}

	if (ensure(NewConnection))
	{
		TSharedPtr<FInternetAddr> ConnAddr = NewConnection->GetInternetAddr();

		if (ConnAddr.IsValid())
		{
			P3NetConnId ConnId = InitNetConnection(NewConnection);

			if (ConnId != INVALID_NETCONNID)
			{
				MappedClientConnectionAddrs.Add(ConnId, ConnAddr);

				return true;
			}
		}
	}

	return false;
}

void UP3UnrealUDPNet::Server_RemoveConnection(P3NetConnId ClientConnId)
{
	if (!ensure(bServer))
	{
		return;
	}

	if (ensure(ClientConnId != INVALID_NETCONNID))
	{
		verify(MappedClientConnectionAddrs.Remove(ClientConnId) == 1);
	}
	else
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("client connection ID is invalid"));
	}
}

UNetConnection* UP3UnrealUDPNet::Server_GetConnection(P3NetConnId ClientConnId) const
{
	if (!ensure(bServer))
	{
		return nullptr;
	}

	if (ensure(ClientConnId != INVALID_NETCONNID))
	{
		const TSharedPtr<FInternetAddr>* ClientConnAddr = MappedClientConnectionAddrs.Find(ClientConnId);
		if (ClientConnAddr && ClientConnAddr->IsValid())
		{
			const TSharedRef<FInternetAddr> AddrRef = ClientConnAddr->ToSharedRef();

			UNetConnection** ClientConnection = NetDriver->MappedClientConnections.Find(AddrRef);
			if (ClientConnection && *ClientConnection)
			{
				return *ClientConnection;
			}
		}
	}
	else
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("client connection ID is invalid"));
	}

	return nullptr;
}

bool UP3UnrealUDPNet::Server_IsConnected(P3NetConnId ClientConnId) const
{
	if (!ensure(bServer))
	{
		return false;
	}

	const UNetConnection* Connection = Server_GetConnection(ClientConnId);
	if (Connection && Connection->State == USOCK_Open)
	{
		return true;
	}

	UE_LOG(P3UDPNetLog, Error, TEXT("can not find client connection: %d"), ClientConnId.X);
	return false;
}

bool UP3UnrealUDPNet::Client_IsConnected() const
{
	if (!ensure(!bServer))
	{
		return false;
	}

	if (NetDriver && NetDriver->ServerConnection)
	{
		return NetDriver->ServerConnection->State == USOCK_Open;
	}

	return false;
}

EP3NetConnStatus UP3UnrealUDPNet::Client_GetConnStatus() const
{
	if (!ensure(!bServer))
	{
		return EP3NetConnStatus::Closed;
	}

	if (NetDriver && NetDriver->ServerConnection)
	{
		if (NetDriver->ServerConnection->State == USOCK_Pending)
		{
			return EP3NetConnStatus::Connecting;
		}
		else if (NetDriver->ServerConnection->State == USOCK_Open)
		{
			return EP3NetConnStatus::Connected;
		}
	}

	return EP3NetConnStatus::Closed;
}

void UP3UnrealUDPNet::Client_SpawnActor(const TArray<uint8>& SpawnData)
{
	if (!ensure(!bServer))
	{
		return;
	}

	if (SpawnData.Num() > 0)
	{
		if (ensure(GameWorld))
		{
			UP3World* P3World = P3Core::GetP3World(*GameWorld);

			if (ensure(P3World))
			{
				FP3NetSpawnActorParams SpawnParam;

				const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, SpawnData, SpawnParam);

				if (ensure(bSerializeSucceeded))
				{
					UP3ClientWorld* ClientWorld = P3World->GetClientWorld();

					if (ensure(ClientWorld))
					{
						ClientWorld->SpawnActor(SpawnParam);

						AActor* Actor = P3World->GetActorFromActorId(SpawnParam.ActorId);

						if (ensure(Actor))
						{
							Client_SetChannelActor(SpawnParam.ActorId, Actor, false);
						}
					}
				}
			}
		}
	}
}

void UP3UnrealUDPNet::Client_DestroyActor(actorid ActorId)
{
	if (!ensure(!bServer))
	{
		return;
	}

	if (GameWorld)
	{
		UP3World* P3World = P3Core::GetP3World(*GameWorld);

		if (ensure(P3World))
		{
			UP3ClientWorld* ClientWorld = P3World->GetClientWorld();

			if (ensure(ClientWorld))
			{
				ClientWorld->DestroyActor(ActorId);
			}
		}
	}
}

void UP3UnrealUDPNet::Client_AddPendingActorChannel(UP3ActorChannel* ActorChannel)
{
	PendingActorChannels.Add(ActorChannel);
}

void UP3UnrealUDPNet::SendControlMessage(UNetConnection* Connection, EP3ControlCommand ControlCommand, TArray<uint8>& Data)
{
	if (ensure(Connection))
	{
		FNetControlMessage<NMT_P3Control>::Send(Connection, ControlCommand, Data);
	}
	else
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("SendControlMessage: connection is null: %d"), ControlCommand);
	}
}

void UP3UnrealUDPNet::ReceiveControlMesasge(UNetConnection* Connection, EP3ControlCommand ControlCommand, TArray<uint8>& Data)
{
	switch (ControlCommand)
	{
		case EP3ControlCommand::Command_None:
		{
			ensure(0);
			break;
		}
		default:
			break;
	}
}

void UP3UnrealUDPNet::HandleUnrealRaw(UNetConnection* Connection, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, EP3NetComponentType ComponentType, const FString& HandlerFunction)
{
	if (!ensure(Connection))
	{
		return;
	}

	if (!ensure(GameWorld))
	{
		return;
	}

	UP3World* P3World = P3Core::GetP3World(*GameWorld);

	if (!ensure(P3World))
	{
		return;
	}

	UP3NetConnection* P3Connection = UP3UnrealUDPNet::GetP3Connection(Connection);

	if (!ensure(P3Connection))
	{
		return;
	}

	FP3NetConnInfo NetConnInfo;
	NetConnInfo.UDPConnId = P3Connection->GetConnectionId();

	if (NetConnInfo.UDPConnId != INVALID_NETCONNID)
	{
		FP3NetHeader Header;
		Header.ComponentType = ComponentType;
		Header.HandlerFunctionName = *HandlerFunction;

		if (bServer)
		{
			P3World->Server_HandlePacketBuffer(NetConnInfo, ActorId, Actor, Buffer, Header);
		}
		else
		{
			P3World->Client_HandlePacketBuffer(NetConnInfo, ActorId, Actor, Buffer, Header);
		}
	}

	++StatRecvMessages;
}

bool UP3UnrealUDPNet::Client_SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bForceReliable)
{
	if (bState != EP3UDPNetState::Actived)
	{
		return false;
	}
	
	if (!ensure(!bServer))
	{
		return false;
	}
	
	if (ensure(NetDriver && NetDriver->ServerConnection))
	{
		TArray<uint8> TempBuffer(Buffer);

		return MessageHandler.SendToActorChannel(NetDriver->ServerConnection, ActorId, Actor, TempBuffer, Header.ComponentType, Header.HandlerFunctionName, bForceReliable);
	}
	
	return false;
}

bool UP3UnrealUDPNet::Server_SendPacketBuffer(P3NetConnId ClientConnId, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable)
{
	if (bState != EP3UDPNetState::Actived)
	{
		return false;
	}

	if (!ensure(bServer))
	{
		return false;
	}

	UNetConnection* ClientConnection = Server_GetConnection(ClientConnId);

	if (ClientConnection)
	{
		TArray<uint8> TempBuffer(Buffer);

		return MessageHandler.SendToActorChannel(ClientConnection, ActorId, Actor, TempBuffer, Header.ComponentType, Header.HandlerFunctionName, bReliable);
	}

	return false;
}

bool UP3UnrealUDPNet::Server_MulticastPacketBufferToActor(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable)
{
	if (bState != EP3UDPNetState::Actived)
	{
		return false;
	}

	if (!ensure(bServer))
	{
		return false;
	}

	TArray<uint8> TempBuffer(Buffer);

	for (UNetConnection* const ClientConnection : NetDriver->ClientConnections)
	{
		if (ClientConnection)
		{
			MessageHandler.SendToActorChannel(ClientConnection, ActorId, Actor, TempBuffer, Header.ComponentType, Header.HandlerFunctionName, bReliable);
		}
		else
		{
			UE_LOG(P3UDPNetLog, Error, TEXT("Server_MulticastPacketBuffer failed: Actor(%lld) Func(%s)"), ActorId, *Header.HandlerFunctionName.ToString());
		}
	}

	return true;
}

void UP3UnrealUDPNet::HandlePing(UNetConnection* Connection, uint32 PingId, int32 /*Unreference Parameter: PingTime*/)
{
	if (!bServer)
	{
		return;
	}

	UP3NetConnection* P3Connection = GetP3Connection(Connection);

	if (!ensure(P3Connection))
	{
		return;
	}

	const AP3GameMode* GameMode = GameWorld ? GameWorld->GetAuthGameMode<AP3GameMode>() : nullptr;
	float FrameTimeMsec = GameMode ? GameMode->GetAverageFrameTimeMsec() : 0.0f;

	FNetControlMessage<NMT_P3Pong>::Send(Connection, PingId, FrameTimeMsec);

	P3Connection->LastPingReceivedTime = FDateTime::Now();
}

void UP3UnrealUDPNet::HandlePong(uint32 PingId, float ServerFrameTimeMsec)
{
	if (bServer)
	{
		return;
	}

	if (NetDriver && NetDriver->ServerConnection)
	{
		UP3NetConnection* P3Connetion = GetP3Connection(NetDriver->ServerConnection);

		if (ensure(P3Connetion))
		{
			if (PingId != P3Connetion->PingTime.PingId)
			{
				return;
			}

			const FDateTime Now = FDateTime::Now();
			P3Connetion->PingTime.PingTimeMsec = FMath::FloorToInt((Now - P3Connetion->PingTime.LastPingSentTime).GetTotalMilliseconds());
			P3Connetion->PingTime.ServerFrameTimeMsec = ServerFrameTimeMsec;
			P3Connetion->PingTime.LastPingUpdatedTime = Now;
		}
	}
}

void UP3UnrealUDPNet::UpdateStat()
{
	const double CurrentRealtimeSeconds = FPlatformTime::Seconds();
	const float RealTime = StaticCast<float>(CurrentRealtimeSeconds - StatUpdateTime);

	if (RealTime < CVarP3NetStatUpdatePeriod.GetValueOnAnyThread())
	{
		return;
	}

	NetStat.SentBytesPerSecond = FMath::TruncToInt(static_cast<float>(StatSentBytes) / RealTime);
	NetStat.RecvBytesPerSecond = FMath::TruncToInt(static_cast<float>(StatRecvBytes) / RealTime);
	NetStat.SentMessagesPerSecond = FMath::TruncToInt(static_cast<float>(StatSentMessages) / RealTime);
	NetStat.RecvMessagesPerSecond = FMath::TruncToInt(static_cast<float>(StatRecvMessages) / RealTime);

	StatSentBytes = 0;
	StatRecvBytes = 0;
	StatSentMessages = 0;
	StatRecvMessages = 0;

	StatUpdateTime = CurrentRealtimeSeconds;

// 	P3JsonNetLog(VeryVerbose, "P3 Network stat",
// 		TEXT("Sent B/s"), Stat.SentBytesPerSecond,
// 		TEXT("Recv B/s"), Stat.RecvBytesPerSecond,
// 		TEXT("Sent M/s"), Stat.SentMessagesPerSecond,
// 		TEXT("Recv M/s"), Stat.RecvMessagesPerSecond);
}

int32 UP3UnrealUDPNet::GetPingTimeMsec() const
{
	if (NetDriver && NetDriver->ServerConnection)
	{
		UP3NetConnection* P3Connection = GetP3Connection(NetDriver->ServerConnection);

		if (ensure(P3Connection))
		{
			return P3Connection->PingTime.PingTimeMsec;
		}
	}

	return 0;
}

FDateTime UP3UnrealUDPNet::GetPingUpdatedTime() const
{
	if (NetDriver && NetDriver->ServerConnection)
	{
		UP3NetConnection* P3Connection = GetP3Connection(NetDriver->ServerConnection);

		if (ensure(P3Connection))
		{
			return P3Connection->PingTime.LastPingUpdatedTime;
		}
	}

	return FDateTime(0);
}

float UP3UnrealUDPNet::GetServerFrameTimeMsec() const
{
	if (NetDriver && NetDriver->ServerConnection)
	{
		UP3NetConnection* P3Connection = GetP3Connection(NetDriver->ServerConnection);

		if (ensure(P3Connection))
		{
			return P3Connection->PingTime.ServerFrameTimeMsec;
		}
	}

	return 0.f;
}

FP3NetStat UP3UnrealUDPNet::GetAvgConnStat() const
{
	if (bServer)
	{
		FP3NetStat OutNetStat;

		if (NetDriver)
		{
			for (const UNetConnection* const ClientConnection : NetDriver->ClientConnections)
			{
				if (!ClientConnection)
				{
					continue;
				}

				OutNetStat.SentBytesPerSecond += ClientConnection->OutBytesPerSecond;
				OutNetStat.RecvBytesPerSecond += ClientConnection->InBytesPerSecond;
				OutNetStat.SentMessagesPerSecond += ClientConnection->OutPacketsPerSecond;
				OutNetStat.RecvMessagesPerSecond += ClientConnection->InPacketsPerSecond;
			}
		}

		return OutNetStat;
	}

	return NetStat;
}
