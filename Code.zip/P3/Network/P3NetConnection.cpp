// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetConnection.h"

#include "P3ActorChannel.h"
#include "P3Log.h"
#include "P3UnrealUDPNet.h"

// DECLARE_CYCLE_STAT(TEXT("P3UDPNet_Receive"), STAT_P3UDPNet_Receive, STATGROUP_P3); // use UIpNetDriver's STAT_IpNetDriver_RecvFromSocket
// DECLARE_CYCLE_STAT(TEXT("P3UDPNet_Send"), STAT_P3UDPNet_Send, STATGROUP_P3); // use UIpConnection's STAT_IpConnection_SendToSocket
DECLARE_DWORD_COUNTER_STAT(TEXT("P3UDPNet Num QueuedMessages"), STAT_P3UDPNet_NumQueuedMessages, STATGROUP_P3);

constexpr int32 MaxSendCountPerTick = RELIABLE_BUFFER * 4;

void FP3QueuedActorMessage::SerializeBunch(OUT FOutBunch& Bunch)
{
	UP3NetConnection::MakeBunch(Bunch, Channel, bReliable);

	Bunch.SerializeBits(Data.GetData(), CountBits);
}

void UP3NetConnection::MakeBunch(OUT FOutBunch& Bunch, UP3ActorChannel* Channel, bool bReliable)
{
	if (!ensure(Channel && Channel->Connection))
	{
		return;
	}

	Bunch.Channel = Channel;
	Bunch.ChIndex = Channel->ChIndex;
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	Bunch.ChType = Channel->ChType;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	Bunch.ChName = Channel->ChName;
	Bunch.bReliable = bReliable;

	Bunch.SetByteSwapping(Channel->Connection->bNeedsByteSwapping);
	Bunch.SetAllowResize(true);
	Bunch.SetAllowOverflow(false);
}

UP3NetConnection::UP3NetConnection(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UP3NetConnection::InitRemoteConnection(UNetDriver* InDriver, class FSocket* InSocket, const FURL& InURL, const class FInternetAddr& InRemoteAddr, EConnectionState InState, int32 InMaxPacket/* = 0*/, int32 InPacketOverhead/* = 0*/)
{
	Super::InitRemoteConnection(InDriver, InSocket, InURL, InRemoteAddr, InState, InMaxPacket, InPacketOverhead);
}

void UP3NetConnection::InitLocalConnection(UNetDriver* InDriver, class FSocket* InSocket, const FURL& InURL, EConnectionState InState, int32 InMaxPacket/* = 0*/, int32 InPacketOverhead/* = 0*/)
{
	Super::InitLocalConnection(InDriver, InSocket, InURL, InState, InMaxPacket, InPacketOverhead);
}

void UP3NetConnection::Tick()
{
	SET_DWORD_STAT(STAT_P3UDPNet_NumQueuedMessages, QueuedMessages.Num());

	int32 Count = 0;

	// attempt to send queued messages
	while (QueuedMessages.Num() > 0)
	{
		FP3QueuedActorMessage& Message = QueuedMessages[0];

		if (!Message.Channel || !Message.Channel->Connection)
		{
			QueuedMessages.RemoveAt(0, 1);
			continue;
		}

		if (!Message.Channel->CanSendBunch())
		{
			break;
		}

		FOutBunch Bunch(Message.Channel->Connection->PackageMap, Message.CountBits);

		Message.SerializeBunch(Bunch);

		if (Bunch.IsError())
		{
			QueuedMessages.RemoveAt(0, 1);

			if (Message.Channel->Connection)
			{
				Message.Channel->Connection->Close();
			}

			break;
		}

		Message.Channel->SendBunch(&Bunch, true);

		QueuedMessages.RemoveAt(0, 1);

		++Count;

		if (Count >= MaxSendCountPerTick)
		{
			break;
		}
	}

	if (Count > 0)
	{
		FlushNet(true);

		UE_LOG(P3UDPNetLog, Log, TEXT("Messages Sent (%i): Queue(%i)"), Count, QueuedMessages.Num());

		if (QueuedMessages.Num() == 0)
		{
		}
	}

	Super::Tick();
}

void UP3NetConnection::CleanUp()
{
	//ConnectionId = INVALID_NETCONNID;
	ActorChannels.Empty();
	ActorIdChannels.Empty();
	QueuedMessages.Empty();

	Super::CleanUp();
}

void UP3NetConnection::LowLevelSend(void* Data, int32 CountBits, FOutPacketTraits& Traits)
{
	//SCOPE_CYCLE_COUNTER(STAT_P3UDPNet_Send);
	Super::LowLevelSend(Data, CountBits, Traits);
}

bool UP3NetConnection::QueueMessage(FOutBunch* Bunch, UP3ActorChannel* ActorChannel)
{
	if (!ensure(Bunch))
	{
		return false;
	}

	if (!ensure(Driver && Driver->IsServer()))
	{
		return false;
	}

	// 	if (!Connection || !Connection->PackageMap)
	// 	{
	// 		return false;
	// 	}

	if (QueuedMessages.Num() >= MAX_QUEUED_ACTOR_MESSAGES)
	{
		// we're out of room in our extra buffer as well, so kill the connection
		UE_LOG(P3UDPNetLog, Log, TEXT("Overflowed actor channel message queue, disconnecting client"));

		return false;
	}
	else
	{
		int32 Index = QueuedMessages.AddZeroed();
		FP3QueuedActorMessage& CurMessage = QueuedMessages[Index];

		// 		FNetBitWriter BitWriter(Connection->PackageMap, Connection->GetMaxSingleBunchSizeBits());
		// 		BitWriter.SerializeBits(Bunch->GetData(), Bunch->GetNumBits());
		// 		CurMessage.Data.AddUninitialized(BitWriter.GetNumBytes());
		// 		FMemory::Memcpy(CurMessage.Data.GetData(), BitWriter.GetData(), BitWriter.GetNumBytes());
		// 		CurMessage.CountBits = BitWriter.GetNumBits();

		CurMessage.Data.AddUninitialized(Bunch->GetNumBytes());
		FMemory::Memcpy(CurMessage.Data.GetData(), Bunch->GetData(), Bunch->GetNumBytes());

		CurMessage.CountBits = Bunch->GetNumBits();
		CurMessage.bReliable = Bunch->bReliable;
		CurMessage.Channel = ActorChannel;

		//UE_LOG(P3UDPNetLog, Log, TEXT("Queue Reliable(%i): Func(%s)"), Bunch->bReliable, *FuncName);

		//UE_LOG(P3UDPNetLog, Log, TEXT("add queue message(%i): %s"), QueuedMessages.Num(), *HandlerFunction);
	}

	return true;
}
