// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Lib/P3Net.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/game.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/game.pb.h"
#endif

#include "P3DediNet.generated.h"

UCLASS()
class UP3DediNet : public UObject, public IP3BaseNet
{
	GENERATED_BODY()

public:
	virtual ~UP3DediNet() {}

	void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet);
	void Shutdown();
	void Tick(float DeltaTime);

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event);
	virtual void HandleListenEvent(const FP3NetListenEvent& Event) {}
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event) {}
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event);
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event);
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event) {}

	void Connect();
	void Close();
	void Send(pb::C2DType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);

	void SendConsoleCommand(const FString& Command);

	void SendZoneChange();

	EP3NetConnStatus GetConnStatus() const;

	const FString& GetHost() const;
	void SetHost(const FString& InHost);
	int32 GetPort() const;
	void SetPort(int32 InPort);
	FName GetZone() const;
	void SetZone(FName InZone);

	int32 GetPingTimeMsec() const { return PingTime.PingTimeMsec; }
	FDateTime GetPingUpdatedTime() const { return PingTime.LastPingUpdatedTime; }
	float GetServerFrameTimeMsec() const { return PingTime.ServerFrameTimeMsec; }

private:
	void InitConsoleCommand();

	void HandlePong(const pb::D2CPong& Message);
	void HandleUnrealRaw(const pb::D2CUnrealRaw& Message);
	void HandleWorldMessage(const pb::D2CWorldMessage& Message);
	void HandleZoneChangeRes(const pb::D2CZoneChangeRes& Message);

	void OnConsoleCommandConnect(const TArray<FString>& Args);

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	UPROPERTY()
	UP3Net* Net = nullptr;

	FString Host;
	int32 Port = 0;
	FName Zone;
	P3NetConnId ConnId = INVALID_NETCONNID;
	EP3NetConnStatus ConnStatus = EP3NetConnStatus::Closed;
	FP3PingTime PingTime;
	struct IConsoleCommand* ConsoleCommandConnect = nullptr;
};
