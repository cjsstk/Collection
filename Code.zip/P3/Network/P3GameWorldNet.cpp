// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3GameWorldNet.h"

#include "Lib/P3Net.h"
#include "Lib/P3Packer.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3World.h"
#include "Widget/P3LoginHUDWidget.h"

#include "Engine/NetConnection.h"
#include "JsonObjectConverter.h"

static TAutoConsoleVariable<FString> CVarP3GameWorldHost(
	TEXT("p3.gameWorldHost"),
	TEXT("localhost"),
	TEXT("Hostname for world server (from client)"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3GameWorldPort(
	TEXT("p3.gameWorldPort"),
	8801,
	TEXT("Port for world server (from client)"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3GameWorldMaxRetryCount(
	TEXT("p3.gameWorldMaxRetryCount"),
	3,
	TEXT("Maximum retry count when try to connect world server (from client)"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3GameWorldRetryIntervalSeconds(
	TEXT("p3.gameWorldRetryIntervalSeconds"),
	0.5f,
	TEXT("Interval when retry to connect world server (from client)"), ECVF_Default);

void UP3GameWorldNet::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	GameInstance = InGameInstance;
	Net = InNet;

	Host = CVarP3GameWorldHost.GetValueOnGameThread();
	Port = CVarP3GameWorldPort.GetValueOnGameThread();
}

void UP3GameWorldNet::Shutdown()
{
	ConnId = INVALID_NETCONNID;
}

void UP3GameWorldNet::HandleConnectEvent(const FP3NetConnectEvent& Event)
{
	if (Event.bSuccess)
	{
		P3JsonNetLog(Display, "GameWorldNet: Connected");
	}
	else
	{
		P3JsonNetLog(Warning, "GameWorldNet: Failed to connect");
		ConnId = INVALID_NETCONNID;
	}

	if (ensure(LoginHUDWidget.IsValid()))
	{
		LoginHUDWidget->OnConnectedToGameWorld(*this, Event.bSuccess);
	}
}

void UP3GameWorldNet::HandleCloseEvent(const FP3NetCloseEvent& Event)
{
	P3JsonNetLog(Warning, "GameWorldNet: Closed", TEXT("ConnId"), Event.ConnId.X);
	ConnId = INVALID_NETCONNID;
}

void UP3GameWorldNet::HandleRecvPbEvent(const FP3NetRecvPbEvent& Event)
{
	P3JsonNetLog(Verbose, "GameWorld Message",
		TEXT("ConnId"), Event.ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::WU2CLType_Name((pb::WU2CLType)Event.MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Event.Message->DebugString().c_str())));

	switch (Event.MessageType)
	{
	case pb::WU2CL_LOGIN_RES:
		HandleLoginRes(StaticCastSharedRef<const pb::WU2CLLoginRes>(Event.Message).Get());
		break;

	case pb::WU2CL_LIST_CHARACTERS_RES:
		HandleListCharactersRes(StaticCastSharedRef<const pb::WU2CLListCharactersRes>(Event.Message).Get());
		break;

	case pb::WU2CL_CREATE_CHARACTER_RES:
		HandleCreateCharacterRes(StaticCastSharedRef<const pb::WU2CLCreateCharacterRes>(Event.Message).Get());
		break;

	case pb::WU2CL_DELETE_CHARACTER_RES:
		HandleDeleteCharacterRes(StaticCastSharedRef<const pb::WU2CLDeleteCharacterRes>(Event.Message).Get());
		break;

	case pb::WU2CL_SELECT_CHARACTER_RES:
		HandleSelectCharacterRes(StaticCastSharedRef<const pb::WU2CLSelectCharacterRes>(Event.Message).Get());
		break;

	default:
		P3JsonNetLog(Display, "invalid GameWorld message type", TEXT("ConnId"), Event.ConnId.X, TEXT("Message"), Event.MessageType);
		break;
	}
}

void UP3GameWorldNet::Connect(UP3LoginHUDWidget* InLoginHUDWidget)
{
	check(Net);

	if (!ensure(InLoginHUDWidget))
	{
		P3JsonNetLog(Warning, "GameWorldNet: Invalid login hud widget");
		return;
	}

	if (!ensure(ConnId == INVALID_NETCONNID))
	{
		P3JsonNetLog(Warning, "GameWorldNet: Connection already exists. Try connect later", TEXT("ConnId"), ConnId.X);
		return;
	}

	LoginHUDWidget = InLoginHUDWidget;

	TDescMap DescMap;
	DescMap.Add(pb::WU2CL_LOGIN_RES, pb::WU2CLLoginRes::descriptor());
	DescMap.Add(pb::WU2CL_LIST_CHARACTERS_RES, pb::WU2CLListCharactersRes::descriptor());
	DescMap.Add(pb::WU2CL_CREATE_CHARACTER_RES, pb::WU2CLCreateCharacterRes::descriptor());
	DescMap.Add(pb::WU2CL_DELETE_CHARACTER_RES, pb::WU2CLDeleteCharacterRes::descriptor());
	DescMap.Add(pb::WU2CL_SELECT_CHARACTER_RES, pb::WU2CLSelectCharacterRes::descriptor());

	FP3NetConnectParams Params;
	Params.Name = TEXT("GameWorld");
	Params.Host = Host;
	Params.Port = Port;
	Params.InitialDelaySeconds = 0.0f;
	Params.MaxRetryCount = CVarP3GameWorldMaxRetryCount.GetValueOnGameThread();
	Params.RetryIntervalSeconds = CVarP3GameWorldRetryIntervalSeconds.GetValueOnGameThread();
	Params.MaxSocketSendPerMessage = 0;
	Params.bEnableStat = false;

	ConnId = Net->ConnectPb(this, Params, DescMap);
}

void UP3GameWorldNet::Close()
{
	check(Net);

	if (!ensure(ConnId != INVALID_NETCONNID))
	{
		P3JsonNetLog(Warning, "GameWorldNet: Connection is not connected", TEXT("ConnId"), ConnId.X);
		return;
	}

	Net->Close(ConnId);
}

void UP3GameWorldNet::Send(pb::CL2WUType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Net);

	P3JsonNetLog(Verbose, "SendMessage (GameWorld)",
		TEXT("ConnId"), ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::CL2WUType_Name(MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Message->DebugString().c_str())));

	Net->SendPb(ConnId, MessageType, Message);
}

void UP3GameWorldNet::SetHost(const FString& InHost)
{
	Host = InHost;
}

void UP3GameWorldNet::SetPort(int32 InPort)
{
	Port = InPort;
}

void UP3GameWorldNet::HandleLoginRes(const pb::WU2CLLoginRes& Message)
{
	if (!ensure(LoginHUDWidget.IsValid()))
	{
		Net->Close(ConnId);
		return;
	}

	LoginHUDWidget->OnLoginReply(*this, Message);
}

void UP3GameWorldNet::HandleListCharactersRes(const pb::WU2CLListCharactersRes& Message)
{
	if (!ensure(LoginHUDWidget.IsValid()))
	{
		Net->Close(ConnId);
		return;
	}

	LoginHUDWidget->OnListCharactersReply(*this, Message);
}

void UP3GameWorldNet::HandleCreateCharacterRes(const pb::WU2CLCreateCharacterRes& Message)
{
	if (!ensure(LoginHUDWidget.IsValid()))
	{
		Net->Close(ConnId);
		return;
	}

	LoginHUDWidget->OnCreateCharacterReply(*this, Message);
}

void UP3GameWorldNet::HandleDeleteCharacterRes(const pb::WU2CLDeleteCharacterRes& Message)
{
	if (!ensure(LoginHUDWidget.IsValid()))
	{
		Net->Close(ConnId);
		return;
	}

	LoginHUDWidget->OnDeleteCharacterReply(*this, Message);
}

void UP3GameWorldNet::HandleSelectCharacterRes(const pb::WU2CLSelectCharacterRes& Message)
{
	if (!ensure(LoginHUDWidget.IsValid()))
	{
		Net->Close(ConnId);
		return;
	}

	LoginHUDWidget->OnSelectCharacterReply(*this, Message);
}

void UP3GameWorldNet::SendLogin(const FString& AuthToken)
{
	TSharedRef<pb::CL2WULogin, ESPMode::ThreadSafe> Message(new pb::CL2WULogin());
	Message->set_token(TCHAR_TO_UTF8(*AuthToken));

	Send(pb::CL2WU_LOGIN, Message);
}

void UP3GameWorldNet::SendListCharacters()
{
	P3JsonNetLog(Display, "GameWorldNet: Send List Character");

	TSharedRef<pb::CL2WUListCharacters, ESPMode::ThreadSafe> Message(new pb::CL2WUListCharacters());

	Send(pb::CL2WU_LIST_CHARACTERS, Message);
}

void UP3GameWorldNet::SendCreateCharacter(const FString& Name, EP3CharClass CharClass, const FString& HairName, const FString& ArmorName)
{
	P3JsonNetLog(Display, "GameWorldNet: Send Create Character", TEXT("Name"), Name);

	TSharedRef<pb::CL2WUCreateCharacter, ESPMode::ThreadSafe> Message(new pb::CL2WUCreateCharacter());
	Message->set_char_name(TCHAR_TO_UTF8(*Name));
	Message->set_char_class(StaticCast<uint32>(CharClass));
	Message->set_hair(TCHAR_TO_UTF8(*HairName));
	Message->set_armor(TCHAR_TO_UTF8(*ArmorName));

	Send(pb::CL2WU_CREATE_CHARACTER, Message);
}

void UP3GameWorldNet::SendDeleteCharacter(charid CharacterId)
{
	P3JsonNetLog(Display, "GameWorldNet: Send Delete Character", TEXT("CharId"), CharacterId);

	TSharedRef<pb::CL2WUDeleteCharacter, ESPMode::ThreadSafe> Message(new pb::CL2WUDeleteCharacter());
	Message->set_char_id(CharacterId);

	Send(pb::CL2WU_DELETE_CHARACTER, Message);
}

void UP3GameWorldNet::SendSelectCharacter(charid CharacterId)
{
	P3JsonNetLog(Display, "GameWorldNet: Send Select Character", TEXT("CharId"), CharacterId);

	TSharedRef<pb::CL2WUSelectCharacter, ESPMode::ThreadSafe> Message(new pb::CL2WUSelectCharacter());
	Message->set_char_id(CharacterId);

	Send(pb::CL2WU_SELECT_CHARACTER, Message);
}
