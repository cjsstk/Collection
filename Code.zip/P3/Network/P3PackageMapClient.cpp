// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PackageMapClient.h"

UP3PackageMapClient::UP3PackageMapClient(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

bool UP3PackageMapClient::SerializeObject(FArchive& Ar, UClass* InClass, UObject*& Obj, FNetworkGUID* OutNetGUID/* = nullptr*/)
{
	return Super::SerializeObject(Ar, InClass, Obj, OutNetGUID);
}
