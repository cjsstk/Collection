// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Lib/P3Net.h"

#include "Item/P3Item.h"
#include "P3CmsTypes.h"
#include "P3Quest.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "pb/dedilistener.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "pb/dedilistener.pb.h"
#endif

#include "P3WorldNet.generated.h"

namespace pb
{
	class C2DWorldMessage;
}

DECLARE_MULTICAST_DELEGATE_TwoParams(UP3WorldNetOnWorld, const FString&, const FString&);

UCLASS()
class UP3WorldNetBase : public UObject, public IP3BaseNet
{
	GENERATED_BODY()

public:
	virtual ~UP3WorldNetBase() {}

	// UObject
	virtual class UWorld* GetWorld() const override;

	virtual void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet);
	virtual void Shutdown() {}
	virtual void Tick(float DeltaTime) {}

	virtual void Connect() {}
	virtual void Close() {}
	virtual void Send(pb::DD2WDType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message) {}
	virtual EP3NetConnStatus GetConnStatus() const { return EP3NetConnStatus::Closed; }

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event) {};
	virtual void HandleListenEvent(const FP3NetListenEvent& Event) {}
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event) {}
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event) {};
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event);
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event) {}

	void SendRegister(const TCHAR* Name);
	void SendLoadCharacter(int64 AccountId, charid CharacterId, const FString& ZoneName, uint32 ZoneChannelId);
	void SendSaveCharacter(charid CharacterId, const FString& MapName, const FString& ZoneName, const FVector& InPos, const FVector& InRot,
		int32 CharLevel, int32 ExperiencePoint);
	void SendCreateCharacterItem(charid CharacterId, const FP3Item& Item, EP3CharacterItemSlot Slot);
	void SendDeleteCharacterItem(charid CharacterId, FP3ItemId ItemId);
	void SendUpdateCharacterItemSlot(charid CharacterId, FP3ItemId ItemId, EP3CharacterItemSlot Slot);
	void SendUpdateCharacterItemStack(charid CharacterId, FP3ItemId ItemId, int32 Stack);
	void SendCreateQuest(charid CharacterId, questkey QuestKey);
	void SendUpdateQuest(charid CharacterId, questkey QuestKey, EP3QuestState State, int32 PhaseIndex, int32 ActionIndex);
	void SendUpdateCharacterHair(charid CharacterId, const FString& HairName);
	void SendUpdateCharacterArmor(charid CharacterId, const FString& ArmorName);
	void SendRequestPlayerList(charid CharacterId);
	void SendInviteParty(charid InviterCharId, const FString& InviterName, const FString& InviteeName);
	void SendInvitePartyResponse(charid InviteeCharId, uint32 Response);
	void SendLeaveParty(charid CharacterId);

protected:
	void HandleRegisterRes(const pb::WD2DDRegisterRes& Message);
	void HandleLoadCharacterRes(const pb::WD2DDLoadCharacterRes& Message);
	void HandlePlayerListRes(const pb::WD2DDPlayerListRes& Message);
	void HandleInviteParty(const pb::WD2DDInviteParty& Message);
	void HandlePartyMessage(const pb::WD2DDPartyMessage& Message);
	void HandleLeavePartyRes(const pb::WD2DDLeavePartyRes& Message);

	template <class MESSAGE>
	void HandleResult(const MESSAGE& Message);

	void ListenToPlayerNet();

	UPROPERTY(Transient)
	class UP3GameInstance* GameInstance = nullptr;
};

template <class MESSAGE>
void UP3WorldNetBase::HandleResult(const MESSAGE& Message)
{
	ensure(Message.err() == pb::WD2DDErrorNone);
}

UCLASS()
class UP3WorldNet : public UP3WorldNetBase
{
	GENERATED_BODY()

public:
	virtual ~UP3WorldNet() {}

	virtual void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet) override;
	virtual void Shutdown() override;

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event) override;
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event) override;

	virtual void Connect() override;
	virtual void Close() override;
	virtual void Send(pb::DD2WDType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message) override;
	virtual EP3NetConnStatus GetConnStatus() const override;

	const FString& GetHost() { return Host; }
	void SetHost(const FString& InHost) { Host = InHost; }
	int32 GetPort() { return Port; }
	void SetPort(int32 InPort) { Port = InPort; }

	UP3WorldNetOnWorld OnWorld;

private:
	UPROPERTY()
	UP3Net* Net = nullptr;

	FString Host;
	int32 Port = 0;
	P3NetConnId ConnId = INVALID_NETCONNID;
	EP3NetConnStatus ConnStatus = EP3NetConnStatus::Closed;
};

UCLASS()
class UP3WorldNetLocal : public UP3WorldNetBase
{
	GENERATED_BODY()

public:
	virtual ~UP3WorldNetLocal() {}

	virtual void Tick(float DeltaTime) override;

	virtual void Connect() override;
	virtual void Send(pb::DD2WDType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message) override;
	virtual EP3NetConnStatus GetConnStatus() const override;

private:
	void HandleRegister(const pb::DD2WDRegister& Req);
	void HandleLoadCharacter(const pb::DD2WDLoadCharacter& Req);

	struct WorldNetLocalMessage
	{
		uint16 MessageType;
		TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message;

		WorldNetLocalMessage(uint16 InMessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> InMessage)
			: MessageType(InMessageType)
			, Message(InMessage)
		{
		}
	};

	TArray<WorldNetLocalMessage> Responses;
};
