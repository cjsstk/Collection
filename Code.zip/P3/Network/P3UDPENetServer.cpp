// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UDPENetServer.h"

#include "CoreNet.h"

#include "P3GameInstance.h"
#include "P3GameMode.h"
#include "P3ServerWorld.h"
#include "P3UDPMessage.h"
#include "P3World.h"
#include "P3WorldNet.h"
#include "P3Log.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "pb/game.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "pb/game.pb.h"
#endif

void UP3UDPENetServer::Initialize(UP3GameInstance* InGameInstance)
{
	Super::Initialize(InGameInstance);

	InitThread();
}

void UP3UDPENetServer::InitThread()
{
	if (bUseThread)
	{
		check(!ENetThreadRunnable.IsValid() && !ENetThread.IsValid());

		ENetThreadRunnable = MakeUnique<FP3ENetServerThreadRunnable>(*this);

		ENetThread.Reset(FRunnableThread::Create(ENetThreadRunnable.Get(), *FString::Printf(TEXT("UP3UDPENetServer Receive Thread")), 0, TPri_AboveNormal));
	}
}

void UP3UDPENetServer::Shutdown()
{
	Super::Shutdown();

	ClientConnIds.Empty();
}

void UP3UDPENetServer::Close(const P3NetConnId NetConnId/* = INVALID_NETCONNID*/)
{
	CHECK_GAME_THREAD;

	if (!ensure(NetConnId != INVALID_NETCONNID))
	{
		return;
	}

	UP3UDPENet::Close(NetConnId);

	UE_LOG(P3UDPNetLog, Display, TEXT("Close client connection: %d"), NetConnId.X);
}

void UP3UDPENetServer::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
}

bool UP3UDPENetServer::Init(UP3World* InP3World, const FString& InHost/* = TEXT("")*/, int32 InPort/* = 0*/)
{
	CHECK_GAME_THREAD;

	if (!ensure(InP3World) || !ensure(InP3World->GetServerWorld()))
	{
		return false;
	}

	ensure(P3World == nullptr);

	P3World = InP3World;

	ShutdownUnrealNetDriver(P3World->GetWorld());

	SetHost(InHost, InPort);

	SendLocalMessage(EP3UDPLocalMessageType::Listen);

	return true;
}

bool UP3UDPENetServer::Server_SendPacketBuffer(P3NetConnId ClientConnId, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bForceReliable)
{
	uint32 SentBytes = SendUnrealRawMessage(ClientConnId, ActorId, Actor, Buffer, Header, bForceReliable);

	if (SentBytes == 0)
	{
		return false;
	}

	return true;
}

bool UP3UDPENetServer::Server_IsConnected(P3NetConnId ClientConnId) const
{
	return ClientConnIds.Contains(ClientConnId);
}

void UP3UDPENetServer::HandleReceiveEvent(const ENetEvent& Event)
{
	CheckThread();

	if (!ensure(Event.type == ENET_EVENT_TYPE_RECEIVE))
	{
		return;
	}

	if (!ensure(Event.packet))
	{
		return;
	}

	ENetPeer* Peer = Event.peer;

	if (!ensure(Peer))
	{
		return;
	}

	EP3ENetChannelType ChannelType = StaticCast<EP3ENetChannelType>(Event.channelID);

	if (ChannelType == EP3ENetChannelType::Game)
	{
		Super::HandleReceiveEvent(Event);
	}
	else if (ChannelType == EP3ENetChannelType::Network)
	{
		if (Event.packet->data && Event.packet->dataLength > 0)
		{
			const P3NetConnId ConnId = FP3ENetUtil::PeerIdToNetConnId(Peer);

			P3ENetPeerSharedPtr NetPeer = GetNetPeer(ConnId);

			if (NetPeer.IsValid())
			{
				EP3UDPMessageType MessageType = EP3UDPMessageType::None;

				const uint32 DataLen = StaticCast<uint32>(Event.packet->dataLength);

				const uint32 BitSize = DataLen << 3;

				FNetBitReader Reader(nullptr, Event.packet->data, BitSize);

				Reader.SetByteSwapping(NetPeer->bNeedsByteSwapping);

				Reader << MessageType;

				if (MessageType == EP3UDPMessageType::Close)
				{
					FP3UDPMessageClose MessageClose;

					MessageClose.Deserialize(Reader);

					Disconnect(Peer);
				}
				else if (MessageType == EP3UDPMessageType::Hello)
				{
					FP3UDPMessageHello MessageHello;

					MessageHello.Deserialize(Reader);

					uint8 OtherPlatformIsLittle = MessageHello.IsLittleEndian;

					checkSlow(OtherPlatformIsLittle == !!OtherPlatformIsLittle);

					uint8 IsLittleEndian = uint8(PLATFORM_LITTLE_ENDIAN);
					check(IsLittleEndian == !!IsLittleEndian);

					NetPeer->bNeedsByteSwapping = (OtherPlatformIsLittle ^ IsLittleEndian);

					FP3UDPMessageWelcome MessageWelcome;
					SendMessageOnNetworkThread(NetPeer->Peer, MessageWelcome);
				}
				else
				{
					ensure(0);
					UE_LOG(P3UDPNetLog, Warning, TEXT("Invalid UDP Message Type: %u"), MessageType);
				}
			}
		}
	}
}

void UP3UDPENetServer::HandleConnectOnGameThread(const FP3ENetConnectEvent* Event)
{
	CHECK_GAME_THREAD;

	if (!ensure(Event))
	{
		return;
	}

	FString AddressStr = FP3ENetUtil::GetAddressFromENetAddress(Event->Address);

	ensure(!ClientConnIds.Contains(Event->ConnId));

	ClientConnIds.Add(Event->ConnId);

	P3JsonUDPLog(Display, "Client Connected", TEXT("ConnId"), Event->ConnId.X, TEXT("Host"), *AddressStr, TEXT("Port"), Event->Address.port);
}

void UP3UDPENetServer::HandleDisconnectOnGameThread(const FP3ENetDisconnectEvent* Event)
{
 	CHECK_GAME_THREAD;

	if (!ensure(Event))
	{
		return;
	}

	FString AddressStr = FP3ENetUtil::GetAddressFromENetAddress(Event->Address);

	ClientConnIds.Remove(Event->ConnId);

	P3JsonUDPLog(Display, "Client Disconnected", TEXT("ConnId"), Event->ConnId.X, TEXT("Host"), *AddressStr, TEXT("Port"), Event->Address.port);

	if (P3World && P3World->GetServerWorld())
	{
		FP3NetConnInfo NetConnInfo;
		NetConnInfo.UDPConnId = P3NetConnId(Event->ConnId);

		P3World->GetServerWorld()->NetOnPlayerDisconnected(NetConnInfo);
	}
}

void UP3UDPENetServer::HandleReceiveOnGameThread(const FP3ENetReceiveEvent* Event)
{
	CHECK_GAME_THREAD;

	if (!ensure(Event))
	{
		return;
	}

	const P3NetConnId ConnId = Event->ConnId;

	EP3UDPMessageType MessageType = EP3UDPMessageType::None;

	TArray<uint8> Buffer(Event->Buffer);

	const int32 CountBits = Buffer.Num() << 3;

	FNetBitReader Reader(nullptr, Buffer.GetData(), CountBits);

	Reader.SetByteSwapping(Event->bNeedsByteSwapping);

	Reader << MessageType;

	switch (MessageType)
	{
	case EP3UDPMessageType::Ping:
	{
		FP3UDPMessagePing MessagePing;

		MessagePing.Deserialize(Reader);

		UWorld* World = GameInstance ? GameInstance->GetCurrentWorld() : nullptr;
		AP3GameMode* GameMode = World ? World->GetAuthGameMode<AP3GameMode>() : nullptr;
		float FrameTimeMsec = GameMode ? GameMode->GetAverageFrameTimeMsec() : 0.0f;

		FP3UDPMessagePong MessagePong;
		MessagePong.PingId = MessagePing.PingId;
		MessagePong.FrameTimeMsec = FrameTimeMsec;
		SendMessageToGameChannel(ConnId, MessagePong);

		break;
	}
	case EP3UDPMessageType::ConsoleCommand:
	{
		FP3UDPMessageConsoleCommand MessageCommand;

		MessageCommand.Deserialize(Reader);

		if (GEngine)
		{
			GEngine->DeferredCommands.Add(MessageCommand.Command);
		}

		break;
	}
	case EP3UDPMessageType::UnrealRaw:
	{
		if (P3World == nullptr)
		{
			UWorld* World = GameInstance ? GameInstance->GetCurrentWorld() : nullptr;

			if (!ensure(World))
			{
				return;
			}

			P3World = P3Core::GetP3World(*World);
		}

		if (!ensure(P3World))
		{
			return;
		}

		FP3UDPMessageUnrealRaw MessageUnrealRaw;

		MessageUnrealRaw.Deserialize(Reader);

		FP3NetHeader Header;
		Header.ComponentType = StaticCast<EP3NetComponentType>(MessageUnrealRaw.ComponentType);
		Header.HandlerFunctionName = *MessageUnrealRaw.FunctionName;

		FP3NetConnInfo NetConnInfo;
		NetConnInfo.UDPConnId = P3NetConnId(ConnId);

		P3World->Server_HandlePacketBuffer(NetConnInfo, MessageUnrealRaw.ActorId, nullptr, MessageUnrealRaw.Buffer, Header);

		break;
	}
	case EP3UDPMessageType::WorldMessage:
	{
		FP3UDPMessageWorld MessageWorld;

		MessageWorld.Deserialize(Reader);

		HandleWorldMessage(ConnId, MessageWorld);

		break;
	}
	case EP3UDPMessageType::ZoneChange:
	{
		FP3UDPMessageZoneChange MessageZoneChange;

		MessageZoneChange.Deserialize(Reader);

		SendMessageToGameChannel(ConnId, MessageZoneChange);
		break;
	}
	default:
	{
		ensure(0);
		UE_LOG(P3UDPNetLog, Warning, TEXT("Invalid UDP Message Type: %u"), MessageType);
		return;
	}
	}
}

bool UP3UDPENetServer::IsValid() const
{
	return Super::IsValid();
}

void UP3UDPENetServer::Server_SendWorldMessage(P3NetConnId ConnId, const ::google::protobuf::Message& Message)
{
	const int32 MessageSize = StaticCast<int32>(Message.ByteSizeLong());

	TArray<uint8> MessageBuffer;
	MessageBuffer.SetNum(MessageSize);

	const bool bSuccess = Message.SerializeToArray(MessageBuffer.GetData(), MessageSize);

	if (bSuccess)
	{
		FP3UDPMessageWorld UDPMessage;
		UDPMessage.Buffer = MessageBuffer;
		SendMessageToGameChannel(ConnId, UDPMessage);
	}
}

void UP3UDPENetServer::HandleWorldMessage(P3NetConnId ConnId, const FP3UDPMessageWorld& Message)
{
	if (Message.Buffer.Num() <= 0)
	{
		return;
	}

	UP3WorldNetBase* WorldNet = GameInstance ? GameInstance->GetWorldNet() : nullptr;

	if (!ensure(WorldNet))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = P3World ? P3World->GetServerWorld() : nullptr;

	if (!ensure(ServerWorld))
	{
		return;
	}	

	FP3NetConnInfo NetConn;
	NetConn.UDPConnId = P3NetConnId(ConnId);

	pb::C2DWorldMessage WorldMessage;

	WorldMessage.ParseFromArray(Message.Buffer.GetData(), Message.Buffer.Num());

	ServerWorld->SendWorldMessageToWorldServer(NetConn, WorldMessage);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// UP3UDPENetServer::FP3ServerReceiveThreadRunnable

UP3UDPENetServer::FP3ENetServerThreadRunnable::FP3ENetServerThreadRunnable(UP3UDPENet& ENet)
	: FP3ENetThreadRunnable(ENet)
{
}

UP3UDPENetServer::FP3ENetServerThreadRunnable::~FP3ENetServerThreadRunnable()
{
}
