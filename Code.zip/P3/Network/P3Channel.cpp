// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Channel.h"

#include "P3UnrealUDPNet.h"

IMPLEMENT_CONTROL_CHANNEL_MESSAGE(P3JoinSuccess);
IMPLEMENT_CONTROL_CHANNEL_MESSAGE(P3Control);
IMPLEMENT_CONTROL_CHANNEL_MESSAGE(P3Ping);
IMPLEMENT_CONTROL_CHANNEL_MESSAGE(P3Pong);

UP3Channel::UP3Channel(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, UDPNet(nullptr)
{
	PRAGMA_DISABLE_DEPRECATION_WARNINGS
	ChType = CHTYPE_Control;
	PRAGMA_ENABLE_DEPRECATION_WARNINGS
	ChName = NAME_Control;
}

int64 UP3Channel::Close(EChannelCloseReason Reason)
{
	int64 NumBits = Super::Close(Reason);

	if (UDPNet && Connection)
	{
		UDPNet->CloseConnection(Connection);
	}

	return NumBits;
}

bool UP3Channel::CleanUp(const bool bForDestroy, EChannelCloseReason CloseReason)
{
	return Super::CleanUp(bForDestroy, CloseReason);
}

void UP3Channel::ReceivedBunch(FInBunch& Bunch)
{
	check(!Closing);

	// If this is a new client connection inspect the raw packet for endianess
	if (Connection && bNeedsEndianInspection && !CheckEndianess(Bunch))
	{
		// Send close bunch and shutdown this connection
		UE_LOG(LogNet, Warning, TEXT("UControlChannel::ReceivedBunch: NetConnection::Close() [%s] [%s] from CheckEndianess(). FAILED. Closing connection."),
			Connection->Driver ? *Connection->Driver->NetDriverName.ToString() : TEXT("NULL"),
			Connection->OwningActor ? *Connection->OwningActor->GetName() : TEXT("No Owner"));

		Connection->Close();
		return;
	}

	// Process the packet
	while (!Bunch.AtEnd() && Connection != nullptr && Connection->State != USOCK_Closed) // if the connection got closed, we don't care about the rest
	{
		uint8 MessageType;
		Bunch << MessageType;
		if (Bunch.IsError())
		{
			break;
		}
		int32 Pos = Bunch.GetPosBits();

		if (Connection->Driver)
		{
			// we handle Actor channel failure notifications ourselves
			if (MessageType == NMT_ActorChannelFailure)
			{
				if (Connection->Driver->ServerConnection == nullptr)
				{
					int32 ChannelIndex;

					if (FNetControlMessage<NMT_ActorChannelFailure>::Receive(Bunch, ChannelIndex))
					{
						UE_LOG(LogNet, Log, TEXT("Server connection received: %s"), FNetControlMessageInfo::GetName(MessageType));

						// Check if Channel index provided by client is valid and within range of channel on server
						if (ChannelIndex >= 0 && ChannelIndex < Connection->Channels.Num())
						{
						}
						else
						{
							UE_LOG(LogNet, Warning, TEXT("UControlChannel::RecievedBunch: The client is sending an actor channel failure message with an invalid actor channel index."));
						}
					}
				}
			}
			else
			{
				// Process control message on client/server connection
				if (Connection->Driver->Notify)
				{
					Connection->Driver->Notify->NotifyControlMessage(Connection, MessageType, Bunch);
				}
			}
		}

		// if the message was not handled, eat it ourselves
		if (Pos == Bunch.GetPosBits() && !Bunch.IsError())
		{
			switch (MessageType)
			{
				case NMT_Hello:
					FNetControlMessage<NMT_Hello>::Discard(Bunch);
					break;
				case NMT_Welcome:
					FNetControlMessage<NMT_Welcome>::Discard(Bunch);
					break;
				case NMT_Upgrade:
					FNetControlMessage<NMT_Upgrade>::Discard(Bunch);
					break;
				case NMT_Challenge:
					FNetControlMessage<NMT_Challenge>::Discard(Bunch);
					break;
				case NMT_Netspeed:
					FNetControlMessage<NMT_Netspeed>::Discard(Bunch);
					break;
				case NMT_Login:
					FNetControlMessage<NMT_Login>::Discard(Bunch);
					break;
				case NMT_Failure:
					FNetControlMessage<NMT_Failure>::Discard(Bunch);
					break;
				case NMT_Join:
					//FNetControlMessage<NMT_Join>::Discard(Bunch);
					break;
				case NMT_Skip:
					FNetControlMessage<NMT_Skip>::Discard(Bunch);
					break;
				case NMT_Abort:
					FNetControlMessage<NMT_Abort>::Discard(Bunch);
					break;
				case NMT_PCSwap:
					FNetControlMessage<NMT_PCSwap>::Discard(Bunch);
					break;
				case NMT_ActorChannelFailure:
					FNetControlMessage<NMT_ActorChannelFailure>::Discard(Bunch);
					break;
				case NMT_DebugText:
					FNetControlMessage<NMT_DebugText>::Discard(Bunch);
					break;
				case NMT_NetGUIDAssign:
					FNetControlMessage<NMT_NetGUIDAssign>::Discard(Bunch);
					break;
				case NMT_EncryptionAck:
					//FNetControlMessage<NMT_EncryptionAck>::Discard(Bunch);
					break;
				case NMT_P3Control:
					FNetControlMessage<NMT_P3Control>::Discard(Bunch);
					break;
				case NMT_P3Ping:
					FNetControlMessage<NMT_P3Ping>::Discard(Bunch);
					break;
				case NMT_P3Pong:
					FNetControlMessage<NMT_P3Pong>::Discard(Bunch);
					break;
				case NMT_P3JoinSuccess:
					//FNetControlMessage<NMT_JoinSuccess>::Discard(Bunch);
					break;
				default:
					// if this fails, a case is missing above for an implemented message type
					// or the connection is being sent potentially malformed packets
					// @PotentialDOSAttackDetection
					check(!FNetControlMessageInfo::IsRegistered(MessageType));

					UE_LOG(LogNet, Log, TEXT("Received unknown control channel message %i. Closing connection."), int32(MessageType));

					Connection->Close();

					return;
			}
		}
		if (Bunch.IsError())
		{
			UE_LOG( LogNet, Error, TEXT( "Failed to read control channel message '%s'" ), FNetControlMessageInfo::GetName( MessageType ) );
			break;
		}
	}

	if (Bunch.IsError())
	{
		UE_LOG( LogNet, Error, TEXT( "UControlChannel::ReceivedBunch: Failed to read control channel message" ) );

		if (Connection)
		{
			Connection->Close();
		}
	}
}

FPacketIdRange UP3Channel::SendBunch(FOutBunch* Bunch, bool Merge)
{
	return Super::SendBunch(Bunch, Merge);
}
