// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3DediNet.h"

#include "Engine/NetConnection.h"
#include "JsonObjectConverter.h"

#include "Lib/P3Net.h"
#include "Lib/P3Packer.h"
#include "P3Core.h"
#include "P3ClientWorld.h"
#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3UnrealUDPNet.h"
#include "P3World.h"

static TAutoConsoleVariable<FString> CVarP3DediHost(
	TEXT("p3.dediHost"),
	TEXT("127.0.0.1"),
	TEXT("Hostname for dedi server"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3DediPort(
	TEXT("p3.dediPort"),
	8901,
	TEXT("Port for dedi server"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3DediMaxRetryCount(
	TEXT("p3.dediMaxRetryCount"),
	0,
	TEXT("Maximum retry count when try to connect dedi server"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3DediRetryIntervalSeconds(
	TEXT("p3.dediRetryIntervalSeconds"),
	1.0f,
	TEXT("Interval when retry to connect dedi server"), ECVF_Default);

extern TAutoConsoleVariable<float> CVarP3PingUpdatePeriodSecondsDebug;

void UP3DediNet::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	GameInstance = InGameInstance;
	Net = InNet;

	Host = CVarP3DediHost.GetValueOnGameThread();
	Port = CVarP3DediPort.GetValueOnGameThread();

	FString PortStr;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3DediPort="), PortStr))
	{
		Port = FCString::Atoi(*PortStr);
	}

	InitConsoleCommand();
}

void UP3DediNet::InitConsoleCommand()
{
	IConsoleManager& ConsoleManager = IConsoleManager::Get();

	for (int32 Index = 0; Index < 10; ++Index)
	{
		FString ConsoleCommandName("p3.connectDedi");

		if (Index > 0)
		{
			ConsoleCommandName = FString::Printf(TEXT("p3.connectDedi%d"), Index + 1);
		}

		IConsoleObject* ConsoleObject = ConsoleManager.FindConsoleObject(*ConsoleCommandName);

		if (ConsoleObject)
		{
			continue;
		}

		ConsoleCommandConnect = ConsoleManager.RegisterConsoleCommand(
			*ConsoleCommandName,
			TEXT("Connect to dedicated server"),
			FConsoleCommandWithArgsDelegate::CreateUObject(this, &UP3DediNet::OnConsoleCommandConnect),
			ECVF_Cheat
		);
		return;
	}

	P3JsonNetLog(Warning, "Failed to register console command p3.connectDedi");
}

void UP3DediNet::Shutdown()
{
	Zone = NAME_None;
	ConnId = INVALID_NETCONNID;
	ConnStatus = EP3NetConnStatus::Closed;
	
	if (ConsoleCommandConnect)
	{
		IConsoleManager::Get().UnregisterConsoleObject(ConsoleCommandConnect);
		ConsoleCommandConnect = nullptr;
	}
}

void UP3DediNet::OnConsoleCommandConnect(const TArray<FString>& Args)
{
	if (Args.Num() > 0)
	{
		Host = Args[0];
	}

	if (Args.Num() > 1)
	{
		Port = FCString::Atoi(*Args[1]);
	}

	Connect();
}

EP3NetConnStatus UP3DediNet::GetConnStatus() const
{
	return ConnStatus;
}

const FString& UP3DediNet::GetHost() const
{
	return Host;
}

void UP3DediNet::SetHost(const FString& InHost)
{
	Host = InHost;
}

int32 UP3DediNet::GetPort() const
{
	return Port;
}

void UP3DediNet::SetPort(int32 InPort)
{
	Port = InPort;
}

FName UP3DediNet::GetZone() const
{
	return Zone;
}

void UP3DediNet::SetZone(FName InZone)
{
	Zone = InZone;
}

void UP3DediNet::HandleConnectEvent(const FP3NetConnectEvent& Event)
{
	check(GameInstance && Net);

	UP3ClientWorld* ClientWorld = GameInstance->GetCurrentWorld() ? P3Core::GetP3World(*GameInstance->GetCurrentWorld()) ? P3Core::GetP3World(*GameInstance->GetCurrentWorld())->GetClientWorld() : nullptr : nullptr;

	if (!Event.bSuccess)
	{
		P3JsonNetLog(Warning, "Failed to connect dedi server");
		Zone = NAME_None;
		ConnId = INVALID_NETCONNID;
		ConnStatus = EP3NetConnStatus::Closed;

		if (ClientWorld)
		{
			ClientWorld->OnConnectFailed();
		}
		return;
	}

	P3JsonNetLog(Display, "Dedi conn is connected");

	ConnStatus = EP3NetConnStatus::Connected;

	FString PlayerId;
	if (GameInstance->GetGameNetMode() == EP3NetMode::Standalone || GameInstance->GetGameNetMode() == EP3NetMode::ListenServer)
	{
		PlayerId = TEXT("Standalone");
	}

	TSharedRef<pb::C2DHello, ESPMode::ThreadSafe> Message(new pb::C2DHello());
	Message->set_player_id(TCHAR_TO_UTF8(*PlayerId));

	Send(pb::C2D_HELLO, Message);

	if (ClientWorld)
	{
		ClientWorld->OnConnected();
	}
}

void UP3DediNet::HandleCloseEvent(const FP3NetCloseEvent& Event)
{
	P3JsonNetLog(Display, "Dedi server connection is closed", TEXT("ConnId"), Event.ConnId.X);

	Zone = NAME_None;
	ConnId = INVALID_NETCONNID;
	ConnStatus = EP3NetConnStatus::Closed;

	UWorld* World = GameInstance->GetCurrentWorld();
	if (World)
	{
		P3Core::GetP3World(*World)->GetClientWorld()->OnDisconnected();
	}
}

void UP3DediNet::HandleRecvPbEvent(const FP3NetRecvPbEvent& Event)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3DediNet_HandleRecvEvent"), STAT_P3DediNet_HandleRecvEvent, STATGROUP_P3);

	P3JsonNetLog(Verbose, "Dedi Message",
		TEXT("ConnId"), Event.ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::D2CType_Name((pb::D2CType)Event.MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Event.Message->DebugString().c_str())));

	switch (Event.MessageType)
	{
	case pb::D2C_PONG:
		HandlePong(StaticCastSharedRef<const pb::D2CPong>(Event.Message).Get());
		break;

	case pb::D2C_UNREAL_RAW:
		HandleUnrealRaw(StaticCastSharedRef<const pb::D2CUnrealRaw>(Event.Message).Get());
		break;

	case pb::D2C_WORLD_MESSAGE:
		HandleWorldMessage(StaticCastSharedRef<const pb::D2CWorldMessage>(Event.Message).Get());
		break;

	case pb::D2C_ZONE_CHANGE_RES:
		HandleZoneChangeRes(StaticCastSharedRef<const pb::D2CZoneChangeRes>(Event.Message).Get());
		break;

	default:
		P3JsonNetLog(Error, "Invalid D2C message type", TEXT("ConnId"), Event.ConnId.X, TEXT("MessageType"), Event.MessageType);
		break;
	}
}

void UP3DediNet::Connect()
{
	check(Net);

	if (!ensure(ConnStatus == EP3NetConnStatus::Closed))
	{
		P3JsonNetLog(Error, "Dedi connection already exists. Try connect later", TEXT("ConnId"), ConnId.X);
		return;
	}

	TDescMap DescMap;
	DescMap.Add(pb::D2C_PONG, pb::D2CPong::descriptor());
	DescMap.Add(pb::D2C_UNREAL_RAW, pb::D2CUnrealRaw::descriptor());
	DescMap.Add(pb::D2C_WORLD_MESSAGE, pb::D2CWorldMessage::descriptor());
	DescMap.Add(pb::D2C_ZONE_CHANGE_RES, pb::D2CZoneChangeRes::descriptor());

	FP3NetConnectParams Params;
	Params.Name = TEXT("Dedi");
	Params.Host = Host;
	Params.Port = Port;
	Params.InitialDelaySeconds = 0.0f;
	Params.MaxRetryCount = CVarP3DediMaxRetryCount.GetValueOnGameThread();
	Params.RetryIntervalSeconds = CVarP3DediRetryIntervalSeconds.GetValueOnGameThread();
	Params.MaxSocketSendPerMessage = 0;
	Params.bEnableStat = true;

	ConnId = Net->ConnectPb(this, Params, DescMap);
	ConnStatus = EP3NetConnStatus::Connecting;
}

void UP3DediNet::Close()
{
	check(Net);
	ensure(ConnStatus == EP3NetConnStatus::Connected);

	Net->Close(ConnId);
	ConnStatus = EP3NetConnStatus::Closing;
}

void UP3DediNet::HandlePong(const pb::D2CPong& Message)
{
	if (Message.ping_id() != PingTime.PingId)
	{
		return;
	}

	const FDateTime Now = FDateTime::Now();

	PingTime.PingTimeMsec = FMath::FloorToInt((Now - PingTime.LastPingSentTime).GetTotalMilliseconds());
	PingTime.ServerFrameTimeMsec = Message.server_frame_time_msec();
	PingTime.LastPingUpdatedTime = Now;

	P3JsonNetLog(Verbose, "Pong",
		TEXT("PingTimeMsec"), PingTime.PingTimeMsec,
		TEXT("ServerFrameTimeMsec"), PingTime.ServerFrameTimeMsec);
}

void UP3DediNet::HandleUnrealRaw(const pb::D2CUnrealRaw& Message)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3DediNet_HandleUnrealRaw"), STAT_P3DediNet_HandleUnrealRaw, STATGROUP_P3);

	check(GameInstance && Net);

	actorid ActorId = Message.actor_id();

	const ::std::string Source = Message.buffer();
	TArray<uint8> Buffer;
	Buffer.SetNumUninitialized(StaticCast<int32>(Source.length()));
	FMemory::Memcpy(Buffer.GetData(), Source.c_str(), Source.length());

	const FName HandlerFunctionName = UTF8_TO_TCHAR(Message.handler_function_name().c_str());

	P3JsonNetLog(Verbose, "UnrealRaw",
		TEXT("ActorId"), ActorId,
		TEXT("HandlerFunctionName"), HandlerFunctionName.ToString());

	UWorld* World = GameInstance->GetCurrentWorld();

	if (!World)
	{
		P3JsonNetLog(Error, "No world", TEXT("ConnId"), ConnId.X);
		return;
	}

	FP3NetHeader Header;
	Header.ComponentType = StaticCast<EP3NetComponentType>(Message.component_type());
	Header.HandlerFunctionName = HandlerFunctionName;

	FP3NetConnInfo NetConnInfo;
	NetConnInfo.TCPConnId = ConnId;
	P3Core::GetP3World(*World)->Client_HandlePacketBuffer(NetConnInfo, ActorId, nullptr, Buffer, Header);
}

void UP3DediNet::HandleWorldMessage(const pb::D2CWorldMessage& Message)
{
	check(GameInstance && Net);

	UWorld* World = GameInstance->GetCurrentWorld();

	if (!ensure(World))
	{
		return;
	}

	UP3World* P3World = P3Core::GetP3World(*World);

	if (!ensure(P3World))
	{
		return;
	}

	UP3ClientWorld* ClientWorld = P3World->GetClientWorld();

	if (!ensure(ClientWorld))
	{
		return;
	}

	ClientWorld->HandleWorldMessage(Message);
}

void UP3DediNet::HandleZoneChangeRes(const pb::D2CZoneChangeRes& Message)
{
	Close();
}

void UP3DediNet::Send(pb::C2DType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Net);

	P3JsonNetLog(Verbose, "SendMessage (Dedi)",
		TEXT("ConnId"), ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::C2DType_Name(MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Message->DebugString().c_str())));

	Net->SendPb(ConnId, MessageType, Message);
}

void UP3DediNet::Tick(float DeltaTime)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3DediNet_Tick"), STAT_P3DediNet_Tick, STATGROUP_P3);

	if (ConnStatus != EP3NetConnStatus::Connected)
	{
		return;
	}

	const FDateTime Now = FDateTime::Now();

	const FTimespan TimeSinceUpdate = Now - PingTime.LastPingSentTime;
	if (TimeSinceUpdate.GetTotalSeconds() > CVarP3PingUpdatePeriodSecondsDebug.GetValueOnGameThread())
	{
		++PingTime.PingId;

		PingTime.LastPingSentTime = Now;

		TSharedRef<pb::C2DPing, ESPMode::ThreadSafe> Message(new pb::C2DPing());
		Message->set_ping_id(PingTime.PingId);
		Message->set_ping_time_msec(PingTime.PingTimeMsec);

		Send(pb::C2D_PING, Message);
	}
}

void UP3DediNet::SendConsoleCommand(const FString& Command)
{
	TSharedRef<pb::C2DConsoleCommand, ESPMode::ThreadSafe> Message(new pb::C2DConsoleCommand());
	Message->set_command(TCHAR_TO_UTF8(*Command));

	Send(pb::C2D_CONSOLE_COMMAND, Message);
}

void UP3DediNet::SendZoneChange()
{
	TSharedRef<pb::C2DZoneChange, ESPMode::ThreadSafe> Message(new pb::C2DZoneChange());

	Send(pb::C2D_ZONE_CHANGE, Message);
}
