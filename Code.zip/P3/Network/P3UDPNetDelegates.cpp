// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UDPNetDelegates.h"

#include "DataChannel.h"
#include "Engine/LocalPlayer.h"
#include "Engine/NetDriver.h"
#include "Misc/TimeGuard.h"
#include "NetworkVersion.h"

#include "P3Channel.h"
#include "P3ActorChannel.h"
#include "P3ClientWorld.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3NetConnection.h"
#include "P3UnrealUDPNet.h"
#include "P3World.h"

/**
 * FP3WorldTickHook
 */
void FP3WorldTickHook::RegisterTickEvents(UNetDriver* NetDriver)
{
	check(NetDriver);
	TickDispatchDelegateHandle = OnTickDispatch().AddUObject(NetDriver, &UNetDriver::TickDispatch);
	PostTickDispatchDelegateHandle = OnPostTickDispatch().AddUObject(NetDriver, &UNetDriver::PostTickDispatch);
	TickFlushDelegateHandle = OnTickFlush().AddUObject(NetDriver, &UNetDriver::TickFlush);
	PostTickFlushDelegateHandle = OnPostTickFlush().AddUObject(NetDriver, &UNetDriver::PostTickFlush);
	Enabled = true;
}

void FP3WorldTickHook::UnregisterTickEvents()
{
	OnTickDispatch().Remove(TickDispatchDelegateHandle);
	OnPostTickDispatch().Remove(PostTickDispatchDelegateHandle);
	OnTickFlush().Remove(TickFlushDelegateHandle);
	OnPostTickFlush().Remove(PostTickFlushDelegateHandle);
	Enabled = false;
}

void FP3WorldTickHook::TickDispatch(float DeltaSeconds)
{
	SCOPE_TIME_GUARD(TEXT("FP3WorldTickHook::Tick"));
	//CSV_SCOPED_TIMING_STAT(Basic, FP3WorldTickHook_TickDispatch);

	{
		// 		CSV_SCOPED_TIMING_STAT(Basic, FP3WorldTickHook_TickDispatch_NetWorldTickTime);
		// 		SCOPE_CYCLE_COUNTER(STAT_NetFP3WorldTickHookTime);
		// 		SCOPE_TIME_GUARD(TEXT("FP3WorldTickHook::TickDispatch - NetTick"));
		// 		LLM_SCOPE(ELLMTag::Networking);
		// Update the net code and fetch all incoming packets.
		BroadcastTickDispatch(DeltaSeconds);
		BroadcastPostTickDispatch();
	}
}

void FP3WorldTickHook::TickFlush(float DeltaSeconds)
{
	const float RealDeltaSeconds = DeltaSeconds;

	// Update net and flush networking.
	// Tick all net drivers
	{
		// 		CSV_SCOPED_TIMING_STAT(Basic, FP3WorldTickHook_TickFlush_NetBroadcastTickTime);
		// 		SCOPE_CYCLE_COUNTER(STAT_NetBroadcastTickTime);
		BroadcastTickFlush(RealDeltaSeconds); // note: undilated time is being used here
	}

	// PostTick all net drivers
	{
		//CSV_SCOPED_TIMING_STAT(Basic, FP3WorldTickHook_TickFlush_NetBroadcastPostTickTime);
		BroadcastPostTickFlush(RealDeltaSeconds); // note: undilated time is being used here
	}
}

/**
 * FP3NetworkNotify
 */
EAcceptConnection::Type FP3NetworkNotify::NotifyAcceptingConnection()
{
	if (!UDPNet || !UDPNet->IsServer())
	{
		// We are a client and we don't welcome incoming connections.
		UE_LOG(P3UDPNetLog, Error, TEXT("NotifyAcceptingConnection: Client refused"));
		return EAcceptConnection::Reject;
	}

	// Server is up and running.
	if (UDPNet->NetDriver)
	{
		UE_CLOG(!UDPNet->NetDriver->DDoS.CheckLogRestrictions(), P3UDPNetLog, Log, TEXT("NotifyAcceptingConnection: Server %s accept"), *UDPNet->GetName());
	}
	return EAcceptConnection::Accept;
}

void FP3NetworkNotify::NotifyAcceptedConnection(UNetConnection* Connection)
{
	if (!Connection)
	{
		ensure(0);
		return;
	}

	if (!UDPNet || !UDPNet->IsServer())
	{
		ensure(0);
		return;
	}

	UE_LOG(P3UDPNetLog, Log, TEXT("NotifyAcceptedConnection: Name: %s, TimeStamp: %s, %s"), *UDPNet->GetName(), FPlatformTime::StrTimestamp(), *Connection->Describe());
	//NETWORK_PROFILER(GNetworkProfiler.TrackEvent(TEXT("OPEN"), *(GetName() + TEXT(" ") + Connection->LowLevelGetRemoteAddress()), Connection));
}

bool FP3NetworkNotify::NotifyAcceptingChannel(UChannel* Channel)
{
	check(UDPNet);
	check(Channel);
	check(Channel->Connection);
	check(Channel->Connection->Driver);
	UNetDriver* NetDriver = Channel->Connection->Driver;
	check(NetDriver == UDPNet->NetDriver);

	if (!NetDriver)
	{
		ensure(0);
		return false;
	}

	if (!NetDriver->IsServer())
	{
		if (!ensure(NetDriver->ServerConnection == Channel->Connection))
		{
			return false;
		}

		// We are a client and the server has just opened up a new channel.
		if (NetDriver->ChannelDefinitionMap[Channel->ChName].bServerOpen)
		{
			if (Channel->ChName == NAME_Actor)
			{
				// Actor channel.
				UP3ActorChannel* ActorChannel = UP3UnrealUDPNet::GetP3Channel<UP3ActorChannel>(Channel);

				if (ActorChannel)
				{
					if (ActorChannel->ChIndex == UP3UnrealUDPNet::BaseActorChannelIndex)
					{
						UDPNet->bCreatedBaseActorChannel = true;
					}

					ActorChannel->Client_InitChannel(nullptr, UDPNet);
				}
			}

			//UE_LOG(P3UDPNetLog, Log, TEXT("NotifyAcceptingChannel %i/%s client %s"), Channel->ChIndex, *Channel->ChType.ToString(), *GetFullName());
			return true;
		}
		else
		{
			// Unwanted channel type.
			UE_LOG(P3UDPNetLog, Error, TEXT("Client refusing unwanted channel of type %s"), *Channel->ChName.ToString());
			return false;
		}
	}
	else
	{
		// We are the server.
		if (NetDriver->ChannelDefinitionMap[Channel->ChName].bClientOpen)
		{
			if (Channel->ChName == NAME_Control)
			{
				UP3Channel* P3Channel = UP3UnrealUDPNet::GetP3Channel<UP3Channel>(Channel);

				if (P3Channel)
				{
					P3Channel->SetUDPNet(UDPNet);
				}
				else
				{
					ensure(0);
				}
			}

			// The client has opened initial channel.
			UE_LOG(P3UDPNetLog, Log, TEXT("NotifyAcceptingChannel %s %i server %s: Accepted"), *Channel->ChName.ToString(), Channel->ChIndex, *UDPNet->GetFullName());
			return true;
		}
		else
		{
			// Client can't open any other kinds of channels.
			UE_LOG(P3UDPNetLog, Error, TEXT("NotifyAcceptingChannel %s %i server %s: Refused"), *Channel->ChName.ToString(), Channel->ChIndex, *UDPNet->GetFullName());
			return false;
		}

	}

	return false;
}

void FP3NetworkNotify::NotifyControlMessage(UNetConnection* Connection, uint8 MessageType, FInBunch& Bunch)
{
	if (!Connection || !Connection->Driver)
	{
		ensure(0);
		return;
	}

	if (Connection->Driver->IsServer())
	{
		Server_NotifyControlMessage(Connection, MessageType, Bunch);
	}
	else
	{
		Client_NotifyControlMessage(Connection, MessageType, Bunch);
	}
}

void FP3NetworkNotify::Client_NotifyControlMessage(UNetConnection* Connection, uint8 MessageType, FInBunch& Bunch)
{
	check(UDPNet);

	if (!ensure(Connection))
	{
		return;
	}

	if (!ensure(!UDPNet->IsServer()))
	{
		return;
	}

	UNetConnection* ServerConn = UDPNet->NetDriver ? UDPNet->NetDriver->ServerConnection : nullptr;

	if (!ensure(Connection == ServerConn))
	{
		return;
	}

	switch (MessageType)
	{
		case NMT_Welcome:
		{
			// Server accepted connection.
			FString GameName;
			FString RedirectURL;

			FURL URL;
			if (FNetControlMessage<NMT_Welcome>::Receive(Bunch, URL.Map, GameName, RedirectURL))
			{
				UE_LOG(P3UDPNetLog, Log, TEXT("Welcomed by server (Level: %s, Game: %s)"), *URL.Map, *GameName);
				// Send out netspeed now that we're connected
				FNetControlMessage<NMT_Netspeed>::Send(Connection, Connection->CurrentNetSpeed);

				// We have successfully connected
				// TickWorldTravel will load the map and call LoadMapCompleted which eventually calls SendJoin
				UDPNet->bSuccessfullyConnected = true;
			}
			else
			{
				URL.Map.Empty();
			}

			break;
		}
		case NMT_Challenge:
		{
			// Challenged by server.
			if (FNetControlMessage<NMT_Challenge>::Receive(Bunch, Connection->Challenge))
			{
				FName OnlinePlatformName = NAME_None;
				Connection->ClientResponse = TEXT("0");
				FString URLString = UDPNet->Host + ":" + FString::FromInt(UDPNet->Port);
				FString OnlinePlatformNameString = OnlinePlatformName.ToString();

				FNetControlMessage<NMT_Login>::Send(Connection, Connection->ClientResponse, URLString, Connection->PlayerId, OnlinePlatformNameString);
				Connection->FlushNet();
			}
			else
			{
				Connection->Challenge.Empty();
			}

			break;
		}
		case NMT_Failure:
		{
			// our connection attempt failed for some reason, for example a synchronization mismatch (bad GUID, etc) or because the server rejected our join attempt (too many players, etc)
			// here we can further parse the string to determine the reason that the server closed our connection and present it to the user

			FString ErrorMsg;

			if (FNetControlMessage<NMT_Failure>::Receive(Bunch, ErrorMsg))
			{
				if (ErrorMsg.IsEmpty())
				{
					ErrorMsg = "Pending Connection Failed.";
				}

				// This error will be resolved in TickWorldTravel()
				FString ConnectionError = ErrorMsg;

				// Force close the session
				UE_LOG(P3UDPNetLog, Error, TEXT("NetConnection::Close() [%s] [%s] from NMT_Failure %s"),
					Connection->Driver ? *Connection->Driver->NetDriverName.ToString() : TEXT("NULL"),
					Connection->OwningActor ? *Connection->OwningActor->GetName() : TEXT("No Owner"),
					*ConnectionError);

				Connection->Close();
			}

			break;
		}
		case NMT_P3Control:
		{
			EP3ControlCommand ControlCommand = EP3ControlCommand::Command_None;

			TArray<uint8> Data;

			if (FNetControlMessage<NMT_P3Control>::Receive(Bunch, ControlCommand, Data))
			{
				UDPNet->ReceiveControlMesasge(Connection, ControlCommand, Data);
			}

			break;
		}
		case NMT_P3Pong:
		{
			uint32 PingId = 0;
			float ServerFrameTimeMsec = 0.f;

			if (FNetControlMessage<NMT_P3Pong>::Receive(Bunch, PingId, ServerFrameTimeMsec))
			{
				UDPNet->HandlePong(PingId, ServerFrameTimeMsec);
			}

			break;
		}
		case NMT_P3JoinSuccess:
		{
			Connection->LastReceiveTime = UDPNet->NetDriver ? UDPNet->NetDriver->Time : 0;
			Connection->State = USOCK_Open;

			UDPNet->InitNetConnection(Connection);

			break;
		}
		default:
		{
			break;
		}
	}
}

void FP3NetworkNotify::Server_NotifyControlMessage(UNetConnection* Connection, uint8 MessageType, FInBunch& Bunch)
{
	if (!Connection || !UDPNet || !UDPNet->IsServer())
	{
		ensure(0);
		return;
	}

	if (!Connection->IsClientMsgTypeValid(MessageType))
	{
		// If we get here, either code is mismatched on the client side, or someone could be spoofing the client address
		UE_LOG(P3UDPNetLog, Error, TEXT("IsClientMsgTypeValid FAILED (%i): Remote Address = %s"), (int)MessageType, *Connection->LowLevelGetRemoteAddress());
		Bunch.SetError();
		return;
	}

	switch (MessageType)
	{
		case NMT_Hello:
		{
			uint8 IsLittleEndian = 0;
			uint32 RemoteNetworkVersion = 0;
			uint32 LocalNetworkVersion = FNetworkVersion::GetLocalNetworkVersion();
			FString EncryptionToken;

			if (FNetControlMessage<NMT_Hello>::Receive(Bunch, IsLittleEndian, RemoteNetworkVersion, EncryptionToken))
			{
				if (!FNetworkVersion::IsNetworkCompatible(LocalNetworkVersion, RemoteNetworkVersion))
				{
					UE_LOG(P3UDPNetLog, Log, TEXT("NotifyControlMessage: Client connecting with invalid version. LocalNetworkVersion: %i, RemoteNetworkVersion: %i"), LocalNetworkVersion, RemoteNetworkVersion);
					//FNetControlMessage<NMT_Upgrade>::Send(Connection, LocalNetworkVersion);
					Connection->FlushNet(true);
					Connection->Close();
	#if USE_SERVER_PERF_COUNTERS
					//PerfCountersIncrement(TEXT("ClosedConnectionsDueToIncompatibleVersion"));
	#endif
				}
				else
				{
					if (EncryptionToken.IsEmpty())
					{
						UDPNet->Server_SendChallengeControlMessage(Connection);
					}
				}
			}

			break;
		}
		case NMT_Netspeed:
		{
			int32 Rate;

			if (FNetControlMessage<NMT_Netspeed>::Receive(Bunch, Rate))
			{
				Connection->CurrentNetSpeed = FMath::Clamp(Rate, 1800, UDPNet->NetDriver->MaxClientRate);
				UE_LOG(P3UDPNetLog, Log, TEXT("Client netspeed is %i"), Connection->CurrentNetSpeed);
			}

			break;
		}
		case NMT_Login:
		{
			// Admit or deny the player here.
			FUniqueNetIdRepl UniqueIdRepl;
			FString OnlinePlatformName;

			// Expand the maximum string serialization size, to accommodate extremely large Fortnite join URL's.
			Bunch.ArMaxSerializeSize += (16 * 1024 * 1024);

			bool bReceived = FNetControlMessage<NMT_Login>::Receive(Bunch, Connection->ClientResponse, Connection->RequestURL,
				UniqueIdRepl, OnlinePlatformName);

			Bunch.ArMaxSerializeSize -= (16 * 1024 * 1024);

			if (bReceived)
			{
				UE_LOG(P3UDPNetLog, Log, TEXT("Login request: %s userId: %s platform: %s"), *Connection->RequestURL, UniqueIdRepl.IsValid() ? *UniqueIdRepl.ToDebugString() : TEXT("UNKNOWN"), *OnlinePlatformName);

				// keep track of net id for player associated with remote connection
				Connection->PlayerId = UniqueIdRepl;

				UDPNet->Server_WelcomePlayer(Connection);
			}
			else
			{
				Connection->ClientResponse.Empty();
				Connection->RequestURL.Empty();
			}

			break;
		}
		case NMT_Failure:
		{
			// our connection attempt failed for some reason, for example a synchronization mismatch (bad GUID, etc) or because the server rejected our join attempt (too many players, etc)
			// here we can further parse the string to determine the reason that the server closed our connection and present it to the user
			FString EntryURL = TEXT("?failed");
			FString ErrorMsg;

			if (FNetControlMessage<NMT_Failure>::Receive(Bunch, ErrorMsg))
			{
				if (ErrorMsg.IsEmpty())
				{
					ErrorMsg = "Connection Failed.";
				}

				//GEngine->BroadcastNetworkFailure(this, NetDriver, ENetworkFailure::FailureReceived, ErrorMsg);
				Connection->Close();
			}

			break;
		}
		case NMT_Join:
		{
			UP3Channel* ControlChannel = UP3UnrealUDPNet::GetControlChannel(Connection);

			if (!ensure(ControlChannel))
			{
				return;
			}

			UP3ActorChannel* ActorChannel = UDPNet->Server_CreateActorChannel(Connection, nullptr, nullptr); // Create base actor channel

			if (!ensure(ActorChannel) || !ensure(ActorChannel->ChIndex == UP3UnrealUDPNet::BaseActorChannelIndex))
			{
				return;
			}

			bool bSuccess = UDPNet->Server_AddConnection(Connection);

			if (bSuccess)
			{
				Connection->SetClientLoginState(EClientLoginState::ReceivedJoin);

				FNetControlMessage<NMT_P3JoinSuccess>::Send(Connection);
				Connection->FlushNet();

				// @TODO FIXME - TEMP HACK? - clear queue on join
				Connection->QueuedBits = 0;

				UP3NetConnection* P3Connection = UP3UnrealUDPNet::GetP3Connection(Connection);

				if (ensure(P3Connection))
				{
					P3Connection->LastPingReceivedTime = FDateTime::Now();
				}
			}
			else
			{
				ActorChannel->ConditionalCleanUp(true, EChannelCloseReason::Destroyed);
			}

			break;
		}
		case NMT_P3Control:
		{
			EP3ControlCommand ControlCommand = EP3ControlCommand::Command_None;

			TArray<uint8> Data;

			if (FNetControlMessage<NMT_P3Control>::Receive(Bunch, ControlCommand, Data))
			{
				UDPNet->ReceiveControlMesasge(Connection, ControlCommand, Data);
			}

			break;
		}
		case NMT_P3Ping:
		{
			uint32 PingId = 0;
			int32 PingTime = 0;

			if (FNetControlMessage<NMT_P3Ping>::Receive(Bunch, PingId, PingTime))
			{
				UDPNet->HandlePing(Connection, PingId, PingTime);
			}

			break;
		}
		default:
		{
			break;
		}
	}
}
