// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/ControlChannel.h"
#include "Net/DataChannel.h"

#include "Lib/P3NetCore.h"
#include "P3Core.h"
#include "P3WorldNetCore.h"

#include "P3Channel.generated.h"

enum class EP3ControlCommand : uint8
{
	Command_None	= 0,
};

DEFINE_CONTROL_CHANNEL_MESSAGE_ZEROPARAM(P3JoinSuccess, 101);
DEFINE_CONTROL_CHANNEL_MESSAGE_TWOPARAM(P3Control, 102, EP3ControlCommand, TArray<uint8>);
DEFINE_CONTROL_CHANNEL_MESSAGE_TWOPARAM(P3Ping, 103, uint32, int32);
DEFINE_CONTROL_CHANNEL_MESSAGE_TWOPARAM(P3Pong, 104, uint32, float);

UCLASS(transient)
class UP3Channel : public UControlChannel
{
	GENERATED_UCLASS_BODY()

	/** UChannel */
	virtual int64 Close(EChannelCloseReason Reason) override;
	virtual void ReceivedBunch(class FInBunch& Bunch) override;
	virtual FPacketIdRange SendBunch(FOutBunch* Bunch, bool Merge) override;

public:
	void SetUDPNet(class UP3UnrealUDPNet* InUDPNet) { UDPNet = InUDPNet; }

protected:
	/** UChannel */
	virtual bool CleanUp(const bool bForDestroy, EChannelCloseReason CloseReason) override;

private:
	class UP3UnrealUDPNet* UDPNet = nullptr;

	class FNetworkNotify* Notify = nullptr;
};
