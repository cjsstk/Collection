// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "PreWindowsApi.h"
#include "Windows.h"
#include "HideWindowsPlatformTypes.h"
#endif

#include "Containers/CircularQueue.h"
#include "HAL/Runnable.h"
#include "HAL/RunnableThread.h"

#include "Network/Lib/P3NetProtocol.h"
#include "Network/enet/enet.h"

#include "P3Core.h"
#include "P3UDPNetwork.h"
#include "P3WorldNetCore.h"

#include "P3UDPENet.generated.h"

#define CHECK_GAME_THREAD check(IsInGameThread())
#define CHECK_NETWORK_THREAD check(!IsInGameThread())

enum class EP3UDPLocalMessageType : uint8;
enum class EP3UDPMessageType : uint8;

using P3ENetPacketFlag = _ENetPacketFlag;

enum class EP3ENetChannelType : uint8
{
	Game = 0, // Handle message on game-thread
	Network = 1, // Handle message on network-thread
	Local = 2, // Game thread -> Network thread
	Max = 3
};

enum class EP3ENetEventType : int32
{
	None = _ENetEventType::ENET_EVENT_TYPE_NONE,
	Connect = _ENetEventType::ENET_EVENT_TYPE_CONNECT,
	Disconnect = _ENetEventType::ENET_EVENT_TYPE_DISCONNECT,
	Receive = _ENetEventType::ENET_EVENT_TYPE_RECEIVE,
};

class FP3ENetUtil : FNoncopyable
{
public:
	static P3NetConnId PeerIdToNetConnId(const ENetPeer* Peer);
	static FString GetAddressFromENetAddress(const ENetAddress& Address);

private:
	FP3ENetUtil() = delete;
};

struct FP3EnetEventParam
{
	EP3ENetEventType EventType = EP3ENetEventType::None;
	P3NetConnId ConnId = INVALID_NETCONNID;
	EP3ENetChannelType ChannelType = EP3ENetChannelType::Max;
	ENetAddress Address;
	const uint8* Data = nullptr;
	uint32 DataLen = 0;
	bool bNeedsByteSwapping = false;
	uint32 RoundTripTime = 0;
	bool bSuccess = false;
};

struct FP3ENetEvent
{
	explicit FP3ENetEvent(P3NetConnId InConnId)
		: ConnId(InConnId)
	{
		CreationTimeSeconds = FPlatformTime::Seconds();
	}

	virtual ~FP3ENetEvent() {}

	virtual EP3ENetEventType GetType() const = 0;
	virtual const struct FP3ENetConnectEvent* SafeCastToConnectEvent() const { return nullptr; }
	virtual const struct FP3ENetDisconnectEvent* SafeCastToDisconnectEvent() const { return nullptr; }
	virtual const struct FP3ENetReceiveEvent* SafeCastToReceiveEvent() const { return nullptr; }

	P3NetConnId ConnId = INVALID_NETCONNID;
	double CreationTimeSeconds = 0.0;
};

using P3ENetEventSharedRef = TSharedRef<FP3ENetEvent, ESPMode::ThreadSafe>;
using P3ENetEventSharedPtr = TSharedPtr<FP3ENetEvent, ESPMode::ThreadSafe>;

struct FP3ENetConnectEvent : public FP3ENetEvent
{
	FP3ENetConnectEvent()
		: FP3ENetEvent(INVALID_NETCONNID)
		, bSuccess(false)
	{
	}

	FP3ENetConnectEvent(const P3NetConnId InConnId, const ENetAddress& InAddress, bool bInSuccess)
		: FP3ENetEvent(InConnId)
		, Address(InAddress)
		, bSuccess(bInSuccess)
	{
	}

	virtual EP3ENetEventType GetType() const override { return EP3ENetEventType::Connect; }
	virtual const FP3ENetConnectEvent* SafeCastToConnectEvent() const override { return this; }

	ENetAddress Address;
	bool bSuccess = false;
};

struct FP3ENetDisconnectEvent : public FP3ENetEvent
{
	FP3ENetDisconnectEvent(const P3NetConnId InConnId, const ENetAddress& InAddress)
		: FP3ENetEvent(InConnId)
		, Address(InAddress)
	{
	}

	virtual EP3ENetEventType GetType() const override { return EP3ENetEventType::Disconnect; }
	virtual const FP3ENetDisconnectEvent* SafeCastToDisconnectEvent() const override { return this; }

	ENetAddress Address;
};

struct FP3ENetReceiveEvent : public FP3ENetEvent
{
	FP3ENetReceiveEvent(const P3NetConnId InConnId, const uint8* Data, const uint32 DataLen, bool bInNeedsByteSwapping, const uint32 InRoundTripTimeMsec)
		: FP3ENetEvent(InConnId)
		, bNeedsByteSwapping(bInNeedsByteSwapping)
		, RoundTripTimeMsec(InRoundTripTimeMsec)
	{
		if (Data && DataLen > 0)
		{
			Buffer.Append(Data, DataLen);
		}
	}

	virtual EP3ENetEventType GetType() const override { return EP3ENetEventType::Receive; }
	virtual const FP3ENetReceiveEvent* SafeCastToReceiveEvent() const override { return this; }

	TArray<uint8> Buffer;
	bool bNeedsByteSwapping = false;
	uint32 RoundTripTimeMsec = 0;
};

struct FP3ENetPeer
{
	FP3ENetPeer() {}

	explicit FP3ENetPeer(ENetPeer* InPeer)
		: Peer(InPeer)
	{
	}

	~FP3ENetPeer()
	{
		CleanupPeer();
	}

	bool IsConnected() const
	{
		return Peer && (Peer->state == ENET_PEER_STATE_CONNECTED);
	}

	P3NetConnId GetConnId() const
	{
		return Peer ? FP3ENetUtil::PeerIdToNetConnId(Peer) : INVALID_NETCONNID;
	}

	ENetPeer* Peer = nullptr;
	bool bNeedsByteSwapping = false;

private:
	void CleanupPeer();
};

using P3ENetPeerSharedRef = TSharedRef<FP3ENetPeer, ESPMode::ThreadSafe>;
using P3ENetPeerSharedPtr = TSharedPtr<FP3ENetPeer, ESPMode::ThreadSafe>;

UCLASS()
class UP3UDPENet : public UP3UDPNetwork
{
	GENERATED_BODY()

protected:
	// from IUDPNetBase
	virtual void Initialize(class UP3GameInstance* InGameInstance) override;
	virtual void Shutdown() override;
	virtual void Close(const P3NetConnId NetConnId = INVALID_NETCONNID) override;
	virtual void Tick(float DeltaSeconds) override;

	virtual void InitThread();
	virtual void Update();
	virtual void HandleConnectEvent(const ENetEvent& Event);
	virtual void HandleDisconnectEvent(const ENetEvent& Event);
	virtual void HandleReceiveEvent(const ENetEvent& Event);
	virtual void HandleConnectOnGameThread(const FP3ENetConnectEvent* Event) {}
	virtual void HandleDisconnectOnGameThread(const FP3ENetDisconnectEvent* Event) {}
	virtual void HandleReceiveOnGameThread(const FP3ENetReceiveEvent* Event) {}
	virtual bool IsValid() const;

	bool InitENetHost(ENetAddress* Address, uint32 MaxConnections, uint32 IncomingBandwidth, uint32 OutgoingBandwidth);

	void Disconnect(const ENetPeer* Peer, bool bCleanup = true);
	void Listen();
	void Connect();

	P3ENetPeerSharedPtr AddNetPeer(ENetPeer* Peer);
	bool RemoveNetPeer(const ENetPeer* Peer, bool bCleanup = true);
	P3ENetPeerSharedPtr GetNetPeer(const P3NetConnId ConnId);
	const P3ENetPeerSharedPtr GetNetPeer(const P3NetConnId ConnId) const;

	bool HandleP3ENetEvent(P3ENetEventSharedRef Event);
	void HandleLocalMessage(const EP3UDPLocalMessageType MessageType, const P3NetConnId ConnId);

	uint32 SendUnrealRawMessage(const P3NetConnId ConnId, const actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bForceReliable);
	uint32 SendMessageToGameChannel(const P3NetConnId ConnId, struct FP3UDPMessage& Message, const ENetPacketFlag Flag = ENET_PACKET_FLAG_RELIABLE);
	uint32 SendMessageToNetworkChannel(const P3NetConnId ConnId, struct FP3UDPMessage& Message, const ENetPacketFlag Flag = ENET_PACKET_FLAG_RELIABLE);
	uint32 SendMessage(const P3NetConnId ConnId, FP3UDPMessage& Message, const ENetPacketFlag Flag, const bool bGameChannel);
	uint32 SendMessageOnNetworkThread(ENetPeer* Peer, FP3UDPMessage& Message, const ENetPacketFlag Flag = ENET_PACKET_FLAG_RELIABLE); // to network channel
	void SendLocalMessage(EP3UDPLocalMessageType MessageType, const P3NetConnId ConnId = INVALID_NETCONNID);
	void CheckThread() const;

	void Poll();
	void Flush();

private:
	void HandleENetEvent(const ENetEvent& Event);

	bool SendToPeer(const P3NetConnId ConnId, const EP3ENetChannelType ChannelType, const uint8* Data, const uint32 DataLen, const ENetPacketFlag Flag);
	bool SendToPeerInternal(ENetPeer* Peer, const EP3ENetChannelType ChannelType, const uint8* Data, const uint32 DataLen, const ENetPacketFlag Flag, bool bFlush);

public:
	UP3GameInstance* GameInstance = nullptr;

	UP3World* P3World = nullptr;

	TSharedPtr<ENetHost, ESPMode::ThreadSafe> NetHost;

	struct FP3SendPacket
	{
		P3NetConnId ConnId;
		EP3ENetChannelType ChannelType;
		ENetPacketFlag Flag;
		TArray<uint8> Buffer;

		FP3SendPacket()
			: ConnId(INVALID_NETCONNID)
			, ChannelType(EP3ENetChannelType::Game)
			, Flag(ENET_PACKET_FLAG_RELIABLE)
		{
		}

		FP3SendPacket(const P3NetConnId InConnId, const EP3ENetChannelType InChannelType, const ENetPacketFlag InFlag)
			: ConnId(InConnId)
			, ChannelType(InChannelType)
			, Flag(InFlag)
		{
		}
	};

	using P3SendPacketSharedRef = TSharedRef<FP3SendPacket, ESPMode::ThreadSafe>;

	class FP3ENetThreadRunnable : public FRunnable
	{
	public:
		explicit FP3ENetThreadRunnable(UP3UDPENet& ENet);
		virtual ~FP3ENetThreadRunnable();

		virtual uint32 Run() override;
		virtual void Stop() override;

		void Cleanup(bool bSendQueueOnly = false);
		bool IsRunning() const;

		bool AddEventToGameThread(FP3EnetEventParam& Param);
		void GetEventsFromNetworkThread(TArray<P3ENetEventSharedRef>& IncomingEvents);

		bool AddPacketToNetworkThread(const P3NetConnId ConnId, const EP3ENetChannelType ChannelType, const uint8* Data, const uint32 DataLen, const ENetPacketFlag Flag = ENET_PACKET_FLAG_RELIABLE);
		void GetPacketsFromGameThread(TArray<P3SendPacketSharedRef>& OutgoingPackets);

		uint32 GetRecvQueueNum() const;
		uint32 GetSendQueueNum() const;

	private:

		UP3UDPENet& OwningENet;

		/** Running flag. The Run() function will return shortly after setting this to false. */
		TAtomic<bool> bIsRunning;

		/** The Run() function is the producer, UP3UDPENet::Tick on the game thread is the consumer. */
		TArray<P3ENetEventSharedRef> ReceiveQueue; // if enetUseThread is true, enqueue(network thread) dequeue(game thread)
		mutable FRWLock ReceiveQueueRWLock;

		/** The Send() function is the producer, UP3UDPENet::Flush on the network thread is the consumer. */
		TArray<P3SendPacketSharedRef> SendQueue; // if enetUseThread is true, enqueue(game thread) dequeue(network thread)
		mutable FRWLock SendQueueRWLock;
	};

	/** Receive thread runnable object. */
	TUniquePtr<FP3ENetThreadRunnable> ENetThreadRunnable;

	/** Receive thread object. */
	TUniquePtr<FRunnableThread> ENetThread;

	double LastTickDispatchRealtime = 0;

	uint32 WaitMilliseconds = 0;

protected:
	bool bUseThread = false;

	static const uint32 ConnectTimeoutMilliseconds = 5000;

private:
	using P3ENetPeerMap = TMap<P3NetConnId, P3ENetPeerSharedRef>;

	P3ENetPeerMap MappedNetPeers;
};
