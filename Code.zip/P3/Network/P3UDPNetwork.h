// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Lib/P3NetCore.h"

#include "P3UDPNetwork.generated.h"

namespace google
{
	namespace protobuf
	{
		class Message;
	}
}

enum class EP3UDPMessageType : uint8;

class IP3UDPBaseNet
{
public:
	virtual void Initialize(class UP3GameInstance* InGameInstance) = 0;
	virtual void Shutdown() = 0;
	virtual void Close(P3NetConnId ConnId = INVALID_NETCONNID) = 0;
	virtual void Tick(float DeltaSeconds) = 0;
};

UCLASS()
class UP3BaseUDPNet : public UObject, public IP3UDPBaseNet
{
	GENERATED_BODY()

public:
	virtual void Initialize(class UP3GameInstance* InGameInstance) override {}
	virtual void Shutdown() override {}
	virtual void Close(P3NetConnId NetConnId = INVALID_NETCONNID) override {}
	virtual void Tick(float DeltaSeconds) override {}
};

UCLASS()
class UP3UDPNetwork : public UP3BaseUDPNet
{
	GENERATED_BODY()

protected:
	UP3UDPNetwork();

public:
	static UP3UDPNetwork* CreateUDPNet(class UP3GameInstance* InGameInstance, EP3NetProtocol InProtocol, bool bInServer);
	static void ShutdownUnrealNetDriver(class UWorld* World);

	virtual bool Init(class UP3World* InP3World, const FString& InHost = TEXT(""), int32 InPort = 0) { return false; }
	virtual bool Server_SendPacketBuffer(P3NetConnId ClientConnId, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const struct FP3NetHeader& Header, bool bReliable) { return false; }
	virtual class UP3ActorChannel* Server_CreateActorChannel(P3NetConnId ConnId, AActor* Actor, struct FP3NetSpawnActorParams* SpawnActorParam = nullptr) { return nullptr; }
	virtual void Server_DestroyActorChannel(P3NetConnId ConnId, actorid ActorId) {}
	virtual bool Server_IsConnected(P3NetConnId ClientConnId) const { return false; }
	virtual bool Client_SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const struct FP3NetHeader& Header, bool bForceReliable) { return false; }
	virtual void Client_SetChannelActor(actorid ActorId, AActor* Actor, bool bIsLocalActor) {}
	virtual void Client_DestroyActor(actorid ActorId) {}
	virtual EP3NetConnStatus Client_GetConnStatus() const { return EP3NetConnStatus::Closed; }
	virtual bool Client_IsConnected() const { return false; }
	virtual FP3NetStat GetAvgConnStat() const { return FP3NetStat(); }
	virtual int32 GetPingTimeMsec() const { return 0; }
	virtual FDateTime GetPingUpdatedTime() const { return FDateTime(0); }
	virtual float GetServerFrameTimeMsec() const { return 0.f; }
	virtual bool IsServer() const { return bServer; }
	virtual void SendConsoleCommand(const FString& Command) {}
	virtual void Client_SendWorldMessage(const ::google::protobuf::Message& Message) {}
	virtual void Client_SendZoneChange() {}
	virtual void Server_SendWorldMessage(P3NetConnId ConnId, const ::google::protobuf::Message& Message) {}

	bool IsLocalConnection(P3NetConnId ClientConnId) const { return false; }

	EP3NetProtocol GetProtocol() const { return Protocol; }

	FName GetZone() const { return Zone; }
	void SetZone(const FName& InZone) { Zone = InZone; }

	void SetHost(const FString& InHost, int32 InPort);

	int32 GetPort() const { return Port; }

	int32 GetNewConnSequenceId() { return FPlatformAtomics::InterlockedIncrement(&ConnSequenceId); }

protected:
	bool bServer = false;

	EP3NetProtocol Protocol = EP3NetProtocol::None;

	FString Host;

	int32 Port = 0;

	FName Zone;

	volatile int32 ConnSequenceId = 0;

	uint32 ServerDesiredSocketReceiveBufferBytes;
	uint32 ServerDesiredSocketSendBufferBytes;
	uint32 ClientDesiredSocketReceiveBufferBytes;
	uint32 ClientDesiredSocketSendBufferBytes;
};
