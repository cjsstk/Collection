// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Engine/NetworkDelegates.h"

class FP3WorldTickHook
{
public:
	DECLARE_EVENT_OneParam(FP3WorldTickHook, FOnNetTickEvent, float);
	DECLARE_EVENT(FP3WorldTickHook, FOnTickFlushEvent);

	/** Network Tick events */
	FOnNetTickEvent & OnTickDispatch() { return TickDispatchEvent; }
	FOnTickFlushEvent & OnPostTickDispatch() { return PostTickDispatchEvent; }
	FOnNetTickEvent & OnTickFlush() { return TickFlushEvent; }
	FOnTickFlushEvent & OnPostTickFlush() { return PostTickFlushEvent; }

	void RegisterTickEvents(class UNetDriver* NetDriver);
	void UnregisterTickEvents();

	void TickDispatch(float DeltaSeconds);
	void TickFlush(float DeltaSeconds);

	bool IsEnabled() const { return Enabled; }

private:
	/** All registered net drivers TickDispatch() */
	void BroadcastTickDispatch(float DeltaTime)
	{
		TickDispatchEvent.Broadcast(DeltaTime);
	}

	/** All registered net drivers PostTickDispatch() */
	void BroadcastPostTickDispatch()
	{
		PostTickDispatchEvent.Broadcast();
	}

	/** All registered net drivers TickFlush() */
	void BroadcastTickFlush(float DeltaTime)
	{
		TickFlushEvent.Broadcast(DeltaTime);
	}

	/** All registered net drivers PostTickFlush() */
	void BroadcastPostTickFlush(float DeltaTime)
	{
		PostTickFlushEvent.Broadcast();
	}

	/** Event to gather up all net drivers and call TickDispatch at once */
	FOnNetTickEvent TickDispatchEvent;

	/** Event to gather up all net drivers and call PostTickDispatch at once */
	FOnTickFlushEvent PostTickDispatchEvent;

	/** Event to gather up all net drivers and call TickFlush at once */
	FOnNetTickEvent TickFlushEvent;

	/** Event to gather up all net drivers and call PostTickFlush at once */
	FOnTickFlushEvent PostTickFlushEvent;

	/** Handles to various registered delegates */
	FDelegateHandle TickDispatchDelegateHandle;
	FDelegateHandle PostTickDispatchDelegateHandle;
	FDelegateHandle TickFlushDelegateHandle;
	FDelegateHandle PostTickFlushDelegateHandle;

	bool Enabled = false;
};

class FP3NetworkNotify : public FNetworkNotify
{
public:
	/** FNetworkNotify */
	virtual EAcceptConnection::Type NotifyAcceptingConnection() override;
	virtual void NotifyAcceptedConnection(class UNetConnection* Connection) override;
	virtual bool NotifyAcceptingChannel(class UChannel* Channel) override;
	virtual void NotifyControlMessage(UNetConnection* Connection, uint8 MessageType, class FInBunch& Bunch) override;

	void Client_NotifyControlMessage(UNetConnection* Connection, uint8 MessageType, FInBunch& Bunch);
	void Server_NotifyControlMessage(UNetConnection* Connection, uint8 MessageType, FInBunch& Bunch);

	class UP3UnrealUDPNet* UDPNet = nullptr;
};
