// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/game.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/game.pb.h"
#endif

#include "Lib/P3Net.h"
#include "P3PlayerNet.generated.h"

struct FP3PlayerSession
{
	P3NetConnId ConnId = INVALID_NETCONNID;
	bool bIsLocalConnection = false;
};

UCLASS()
class UP3PlayerNet : public UObject, public IP3BaseNet
{
	GENERATED_BODY()

public:
	virtual ~UP3PlayerNet() {}

	void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet);
	void Shutdown();
	void Tick(float DeltaTime);

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event) {}
	virtual void HandleListenEvent(const FP3NetListenEvent& Event);
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event);
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event);
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event);
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event) {}

	void Listen();
	void Close(P3NetConnId ConnId);
	void Send(P3NetConnId ConnId, pb::D2CType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);
	void SendToAll(pb::D2CType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);

	int32 GetPort() const { return Port; }
	int32 GetPlayerCount() const { return PlayerSessions.Num(); }
	bool IsLocalConnection(P3NetConnId ConnId) const;
	bool IsConnected(P3NetConnId ConnId) const;

private:
	void HandlePing(P3NetConnId ConnId, const pb::C2DPing& Message);
	void HandleHello(P3NetConnId ConnId, const pb::C2DHello& Message);
	void HandleConsoleCommand(P3NetConnId ConnId, const pb::C2DConsoleCommand& Message);
	void HandleUnrealRaw(P3NetConnId ConnId, const pb::C2DUnrealRaw& Message);
	void HandleWorldMessage(P3NetConnId ConnId, const pb::C2DWorldMessage& Message);
	void HandleEchoReq(P3NetConnId ConnId, const pb::C2DEchoReq& Message);
	void HandleZoneChange(P3NetConnId ConnId, const pb::C2DZoneChange& Message);

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	UPROPERTY()
	UP3Net* Net = nullptr;

	int32 Port = 0;
	P3NetConnId ListenerConnId = INVALID_NETCONNID;
	TArray<P3NetConnId> ConnIds;
	TMap<P3NetConnId, FP3PlayerSession> PlayerSessions;
};
