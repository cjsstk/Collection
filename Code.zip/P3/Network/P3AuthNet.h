// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/auth.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/auth.pb.h"
#endif

#include "CoreMinimal.h"
#include "Lib/P3Net.h"
#include "P3WorldServerInfo.h"
#include "P3AuthNet.generated.h"

DECLARE_MULTICAST_DELEGATE_OneParam(UP3AuthNetOnConnected, bool);
DECLARE_MULTICAST_DELEGATE_TwoParams(UP3AuthNetOnSignUp, bool, const FString&);
DECLARE_MULTICAST_DELEGATE_ThreeParams(UP3AuthNetOnLogin, bool, const FString&, const TArray<FP3WorldServerInfo>&);

UCLASS()
class UP3AuthNet : public UObject, public IP3BaseNet
{
	GENERATED_BODY()

public:
	virtual ~UP3AuthNet() {}

	void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet);
	void Shutdown();

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event);
	virtual void HandleListenEvent(const FP3NetListenEvent& Event) {}
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event) {}
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event);
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event);
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event) {}

	void Connect();
	void SignUp(const FString& Account, const FString& Password);
	void Login(const FString& Account, const FString& Password);

	const FString& GetHost();
	void SetHost(const FString& InHost);
	int32 GetPort();
	void SetPort(int32 InPort);

	UP3AuthNetOnConnected OnConnected;
	UP3AuthNetOnSignUp OnSignUp;
	UP3AuthNetOnLogin OnLogin;

private:
	void Send(pb::C2AType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);
	void HandleSignUpRes(const pb::A2CSignUpRes& Message);
	void HandleLoginRes(const pb::A2CLoginRes& Message);

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	UPROPERTY()
	UP3Net* Net = nullptr;

	FString Host;
	int32 Port = 0;
	P3NetConnId ConnId = INVALID_NETCONNID;
};
