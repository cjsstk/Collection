// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UDPNetwork.h"

#include "Misc/CommandLine.h"

#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3UDPENetClient.h"
#include "P3UDPENetServer.h"
#include "P3UnrealUDPNet.h"

TAutoConsoleVariable<int32> CVarP3NetUDPUseThread(
	TEXT("p3.netUDPUseThread"),
	1,
	TEXT("If true, the UDP Network will call the socket's RecvFrom, SendTo function on a separate thread (not the game thread)"));

UP3UDPNetwork::UP3UDPNetwork()
	: ServerDesiredSocketReceiveBufferBytes(0x20000)
	, ServerDesiredSocketSendBufferBytes(0x20000)
	, ClientDesiredSocketReceiveBufferBytes(0x8000)
	, ClientDesiredSocketSendBufferBytes(0x8000)
{
}

UP3UDPNetwork* UP3UDPNetwork::CreateUDPNet(UP3GameInstance* InGameInstance, EP3NetProtocol InProtocol, bool bInServer)
{
	UP3UDPNetwork* UDPNetwork = nullptr;

	if (InProtocol == EP3NetProtocol::UnrealUDP)
	{
		UDPNetwork = NewObject<UP3UnrealUDPNet>();
		UDPNetwork->Initialize(InGameInstance);
	}
	else if (InProtocol == EP3NetProtocol::ENetUDP)
	{
		if (bInServer)
		{
			UDPNetwork = NewObject<UP3UDPENetServer>();
			UDPNetwork->Initialize(InGameInstance);
		}
		else
		{
			UDPNetwork = NewObject<UP3UDPENetClient>();
			UDPNetwork->Initialize(InGameInstance);
		}
	}
	else
	{
		checkf(0, TEXT("invalid UDP protocol: %u"), InProtocol);
	}

	if (UDPNetwork)
	{
		UDPNetwork->bServer = bInServer;

		UDPNetwork->Protocol = InProtocol;

		FURL ServerURL;

		UDPNetwork->SetHost(ServerURL.UrlConfig.DefaultHost, ServerURL.UrlConfig.DefaultPort);
	}

	return UDPNetwork;
}

void UP3UDPNetwork::ShutdownUnrealNetDriver(UWorld* World)
{
	if (!ensure(World))
	{
		return;
	}

	UNetDriver* NetDriver = World->GetNetDriver();

	if (NetDriver)
	{
		World->OnTickDispatch().Remove(NetDriver->TickDispatchDelegateHandle);
		World->OnPostTickDispatch().Remove(NetDriver->PostTickDispatchDelegateHandle);
		World->OnTickFlush().Remove(NetDriver->TickFlushDelegateHandle);
		World->OnPostTickFlush().Remove(NetDriver->PostTickFlushDelegateHandle);

		FLevelCollection* const SourceCollection = World->FindCollectionByType(ELevelCollectionType::DynamicSourceLevels);
		if (SourceCollection)
		{
			SourceCollection->SetNetDriver(nullptr);
		}
		FLevelCollection* const StaticCollection = World->FindCollectionByType(ELevelCollectionType::StaticLevels);
		if (StaticCollection)
		{
			StaticCollection->SetNetDriver(nullptr);
		}

		if (GEngine)
		{
			GEngine->ShutdownWorldNetDriver(World);
		}
	}
}

void UP3UDPNetwork::SetHost(const FString& InHost, int32 InPort)
{
	if (!InHost.IsEmpty())
	{
		Host = InHost;
	}

	if (InPort != 0)
	{
		Port = InPort;
	}
}
