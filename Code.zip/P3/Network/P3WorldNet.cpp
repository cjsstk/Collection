// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3WorldNet.h"

#include "Engine/NetConnection.h"
#include "GameFramework/GameModeBase.h"
#include "JsonObjectConverter.h"
#include "Kismet/GameplayStatics.h"
#include "Misc/CommandLine.h"

#include "Item/P3ItemManager.h"
#include "Lib/P3Net.h"
#include "Lib/P3Packer.h"
#include "P3Cms.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3PlayerNet.h"
#include "P3ServerWorld.h"
#include "P3UDPENetServer.h"
#include "P3UnrealUDPNet.h"
#include "P3World.h"

static TAutoConsoleVariable<FString> CVarP3WorldHost(
	TEXT("p3.worldHost"),
	TEXT("localhost"),
	TEXT("Hostname for world server"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3WorldPort(
	TEXT("p3.worldPort"),
	8701,
	TEXT("Port for world server"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3WorldMaxRetryCount(
	TEXT("p3.worldMaxRetryCount"),
	5,
	TEXT("Maximum retry count when try to connect world server"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3WorldRetryIntervalSeconds(
	TEXT("p3.worldRetryIntervalSeconds"),
	1.0f,
	TEXT("Interval when retry to connect world server"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3DefaultCharClass(
	TEXT("p3.defaultCharClass"),
	1, // Melee (see EP3CharClass)
	TEXT("Default character class on non world server mode"), ECVF_Default);

UWorld* UP3WorldNetBase::GetWorld() const
{
	if (GameInstance)
	{
		return GameInstance->GetCurrentWorld();
	}

	return nullptr;
}

//////////////////////////////////////////////////////////////////////////
// UP3WorldNetBase
//////////////////////////////////////////////////////////////////////////

void UP3WorldNetBase::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	GameInstance = InGameInstance;
}

void UP3WorldNetBase::SendRegister(const TCHAR* Name)
{
	TSharedRef<pb::DD2WDRegister, ESPMode::ThreadSafe> Message(new pb::DD2WDRegister());
	Message->set_name(TCHAR_TO_UTF8(Name));

	Send(pb::DD2WD_REGISTER, Message);
}

void UP3WorldNetBase::SendLoadCharacter(int64 AccountId, charid CharacterId, const FString& ZoneName, uint32 ZoneChannelId)
{
	TSharedRef<pb::DD2WDLoadCharacter, ESPMode::ThreadSafe> Message(new pb::DD2WDLoadCharacter());
	Message->set_account_id(AccountId);
	Message->set_char_id(CharacterId);
	Message->set_zone(TCHAR_TO_UTF8(*ZoneName));
	Message->set_zone_channel_id(ZoneChannelId);

	Send(pb::DD2WD_LOAD_CHARACTER, Message);
}

void UP3WorldNetBase::SendSaveCharacter(charid CharacterId, const FString& MapName, const FString& ZoneName, const FVector& InPos, const FVector& InRot,
	int32 CharLevel, int32 ExperiencePoint)
{
	TSharedRef<pb::DD2WDSaveCharacter, ESPMode::ThreadSafe> Message(new pb::DD2WDSaveCharacter());
	Message->set_char_id(CharacterId);
	Message->set_map(TCHAR_TO_UTF8(*MapName));
	Message->set_zone(TCHAR_TO_UTF8(*ZoneName));

	Message->mutable_pos()->set_x(InPos.X);
	Message->mutable_pos()->set_y(InPos.Y);
	Message->mutable_pos()->set_z(InPos.Z);

	Message->mutable_rot()->set_x(InRot.X);
	Message->mutable_rot()->set_y(InRot.Y);
	Message->mutable_rot()->set_z(InRot.Z);

	Message->set_char_level(CharLevel);
	Message->set_experience_point(ExperiencePoint);

	Send(pb::DD2WD_SAVE_CHARACTER, Message);
}

void UP3WorldNetBase::SendCreateCharacterItem(charid CharacterId, const FP3Item& Item, EP3CharacterItemSlot Slot)
{
	if (!ensure(CharacterId != INVALID_CHARID && Item.IsValid()))
	{
		return;
	}

	TSharedRef<pb::DD2WDCreateCharacterItem, ESPMode::ThreadSafe> Message(new pb::DD2WDCreateCharacterItem());
	Message->set_char_id(CharacterId);

	pb::CharacterItem* CharacterItem = Message->mutable_char_item();
	CharacterItem->set_id(Item.Id.ToUInt64());
	CharacterItem->set_cms_key(Item.Key);
	CharacterItem->set_stack(1);
	CharacterItem->set_slot((uint8)Slot);

	Send(pb::DD2WD_CREATE_CHARACTER_ITEM, Message);
}

void UP3WorldNetBase::SendDeleteCharacterItem(charid CharacterId, FP3ItemId ItemId)
{
	if (!ensure(CharacterId != INVALID_CHARID && ItemId != INVALID_ITEMID))
	{
		return;
	}

	TSharedRef<pb::DD2WDDeleteCharacterItem, ESPMode::ThreadSafe> Message(new pb::DD2WDDeleteCharacterItem());
	Message->set_char_id(CharacterId);
	Message->set_item_id(ItemId.ToUInt64());

	Send(pb::DD2WD_DELETE_CHARACTER_ITEM, Message);
}

void UP3WorldNetBase::SendUpdateCharacterItemSlot(charid CharacterId, FP3ItemId ItemId, EP3CharacterItemSlot Slot)
{
	if (!ensure(CharacterId != INVALID_CHARID && ItemId != INVALID_ITEMID))
	{
		return;
	}

	TSharedRef<pb::DD2WDUpdateCharacterItemSlot, ESPMode::ThreadSafe> Message(new pb::DD2WDUpdateCharacterItemSlot());
	Message->set_char_id(CharacterId);

	pb::CharacterItemSlot* ItemSlot = Message->add_item_slots();
	ItemSlot->set_item_id(ItemId.ToUInt64());
	ItemSlot->set_slot((uint8)Slot);

	Send(pb::DD2WD_UPDATE_CHARACTER_ITEM_SLOT, Message);
}

void UP3WorldNetBase::SendUpdateCharacterItemStack(charid CharacterId, FP3ItemId ItemId, int32 Stack)
{
	if (!ensure(CharacterId != INVALID_CHARID && ItemId != INVALID_ITEMID && Stack > 0))
	{
		return;
	}

	TSharedRef<pb::DD2WDUpdateCharacterItemStack, ESPMode::ThreadSafe> Message(new pb::DD2WDUpdateCharacterItemStack());
	Message->set_char_id(CharacterId);

	pb::CharacterItemStack* ItemStack = Message->add_item_stacks();
	ItemStack->set_item_id(ItemId.ToUInt64());
	ItemStack->set_stack(Stack);

	Send(pb::DD2WD_UPDATE_CHARACTER_ITEM_STACK, Message);
}

void UP3WorldNetBase::SendCreateQuest(charid CharacterId, questkey QuestKey)
{
	if (!ensure(CharacterId != INVALID_CHARID && QuestKey != INVALID_QUESTKEY))
	{
		return;
	}

	P3JsonNetLog(Display, "Send message to World",
		TEXT("CharacterId"), CharacterId,
		TEXT("QuestKey"), QuestKey);

	TSharedRef<pb::DD2WDCreateQuest, ESPMode::ThreadSafe> Message(new pb::DD2WDCreateQuest());
	Message->set_char_id(CharacterId);
	Message->set_quest_key(QuestKey);

	Send(pb::DD2WD_CREATE_QUEST, Message);
}

void UP3WorldNetBase::SendUpdateQuest(charid CharacterId, questkey QuestKey, EP3QuestState State, int32 PhaseIndex, int32 ActionIndex)
{
	if (!ensure(CharacterId != INVALID_CHARID && QuestKey != INVALID_QUESTKEY))
	{
		return;
	}

	P3JsonNetLog(Display, "Send message to World",
		TEXT("CharacterId"), CharacterId,
		TEXT("QuestKey"), QuestKey,
		TEXT("State"), *EnumToStringShort(EP3QuestState, State),
		TEXT("PhaseIndex"), PhaseIndex,
		TEXT("ActionIndex"), ActionIndex);

	TSharedRef<pb::DD2WDUpdateQuest, ESPMode::ThreadSafe> Message(new pb::DD2WDUpdateQuest());
	Message->set_char_id(CharacterId);

	pb::Quest* Quest = Message->mutable_quest();
	Quest->set_key(QuestKey);
	Quest->set_state((uint32)State);
	Quest->set_phase_index(PhaseIndex);
	Quest->set_action_index(ActionIndex);

	Send(pb::DD2WDType::DD2WD_UPDATE_QUEST, Message);
}

void UP3WorldNetBase::SendUpdateCharacterHair(charid CharacterId, const FString& HairName)
{
	if (!ensure(CharacterId != INVALID_CHARID) || !ensure(!HairName.IsEmpty()))
	{
		return;
	}

	TSharedRef<pb::DD2WDUpdateCharacterHair, ESPMode::ThreadSafe> Message(new pb::DD2WDUpdateCharacterHair());
	Message->set_char_id(CharacterId);
	Message->set_hair(TCHAR_TO_UTF8(*HairName));
	Send(pb::DD2WDType::DD2WD_UPDATE_CHARACTER_HAIR, Message);
}

void UP3WorldNetBase::SendUpdateCharacterArmor(charid CharacterId, const FString& ArmorName)
{
	if (!ensure(CharacterId != INVALID_CHARID) || !ensure(!ArmorName.IsEmpty()))
	{
		return;
	}

	TSharedRef<pb::DD2WDUpdateCharacterArmor, ESPMode::ThreadSafe> Message(new pb::DD2WDUpdateCharacterArmor());
	Message->set_char_id(CharacterId);
	Message->set_armor(TCHAR_TO_UTF8(*ArmorName));
	Send(pb::DD2WDType::DD2WD_UPDATE_CHARACTER_ARMOR, Message);
}

void UP3WorldNetBase::SendRequestPlayerList(charid CharacterId)
{
	if (!ensure(CharacterId != INVALID_CHARID))
	{
		return;
	}

	TSharedRef<pb::DD2WDPlayerList, ESPMode::ThreadSafe> Message(new pb::DD2WDPlayerList());
	Message->set_char_id(CharacterId);
	Send(pb::DD2WDType::DD2WD_PLAYER_LIST, Message);
}

void UP3WorldNetBase::SendInviteParty(charid InviterCharId, const FString& InviterName, const FString& InviteeName)
{
	if (!ensure(InviterCharId != INVALID_CHARID))
	{
		return;
	}

	if (!ensure(!InviterName.IsEmpty()))
	{
		return;
	}

	if (!ensure(!InviteeName.IsEmpty()))
	{
		return;
	}

	TSharedRef<pb::DD2WDInviteParty, ESPMode::ThreadSafe> Message(new pb::DD2WDInviteParty());
	Message->set_inviter_char_id(InviterCharId);
	Message->set_inviter_name(TCHAR_TO_UTF8(*InviterName));
	Message->set_invitee_name(TCHAR_TO_UTF8(*InviteeName));
	Send(pb::DD2WDType::DD2WD_INVITE_PARTY, Message);
}

void UP3WorldNetBase::SendInvitePartyResponse(charid InviteeCharId, uint32 Response)
{
	if (!ensure(InviteeCharId != INVALID_CHARID))
	{
		return;
	}

	TSharedRef<pb::DD2WDInvitePartyResponse, ESPMode::ThreadSafe> Message(new pb::DD2WDInvitePartyResponse());
	Message->set_invitee_char_id(InviteeCharId);
	Message->set_invite_response(StaticCast<pb::PartyDefine>(Response));
	Send(pb::DD2WDType::DD2WD_INVITE_PARTY_RESPONSE, Message);
}

void UP3WorldNetBase::SendLeaveParty(charid CharacterId)
{
	if (!ensure(CharacterId != INVALID_CHARID))
	{
		return;
	}

	TSharedRef<pb::DD2WDLeaveParty, ESPMode::ThreadSafe> Message(new pb::DD2WDLeaveParty());
	Message->set_char_id(CharacterId);
	Send(pb::DD2WDType::DD2WD_LEAVE_PARTY, Message);
}

void UP3WorldNetBase::HandleRecvPbEvent(const FP3NetRecvPbEvent& Event)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3WorldNet_HandleRecvEvent"), STAT_P3WorldNet_HandleRecvEvent, STATGROUP_P3);

	P3JsonNetLog(Verbose, "World Message",
		TEXT("ConnId"), Event.ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::WD2DDType_Name((pb::WD2DDType)Event.MessageType).c_str())));

	switch (Event.MessageType)
	{
	case pb::WD2DD_REGISTER_RES:
		HandleRegisterRes(StaticCastSharedRef<const pb::WD2DDRegisterRes>(Event.Message).Get());
		break;

	case pb::WD2DD_LOAD_CHARACTER_RES:
		HandleLoadCharacterRes(StaticCastSharedRef<const pb::WD2DDLoadCharacterRes>(Event.Message).Get());
		break;

	case pb::WD2DD_SAVE_CHARACTER_RES:
		HandleResult<pb::WD2DDSaveCharacterRes>(StaticCastSharedRef<const pb::WD2DDSaveCharacterRes>(Event.Message).Get());
		break;

	case pb::WD2DD_CREATE_CHARACTER_ITEM_RES:
		HandleResult<pb::WD2DDCreateCharacterItemRes>(StaticCastSharedRef<const pb::WD2DDCreateCharacterItemRes>(Event.Message).Get());
		break;

	case pb::WD2DD_DELETE_CHARACTER_ITEM_RES:
		HandleResult<pb::WD2DDDeleteCharacterItemRes>(StaticCastSharedRef<const pb::WD2DDDeleteCharacterItemRes>(Event.Message).Get());
		break;

	case pb::WD2DD_UPDATE_CHARACTER_ITEM_SLOT_RES:
		HandleResult<pb::WD2DDUpdateCharacterItemSlotRes>(StaticCastSharedRef<const pb::WD2DDUpdateCharacterItemSlotRes>(Event.Message).Get());
		break;

	case pb::WD2DD_UPDATE_CHARACTER_ITEM_STACK_RES:
		HandleResult<pb::WD2DDUpdateCharacterItemStackRes>(StaticCastSharedRef<const pb::WD2DDUpdateCharacterItemStackRes>(Event.Message).Get());
		break;

	case pb::WD2DD_CREATE_QUEST_RES:
		HandleResult<pb::WD2DDCreateQuestRes>(StaticCastSharedRef<const pb::WD2DDCreateQuestRes>(Event.Message).Get());
		break;

	case pb::WD2DD_UPDATE_QUEST_RES:
		HandleResult<pb::WD2DDUpdateQuestRes>(StaticCastSharedRef<const pb::WD2DDUpdateQuestRes>(Event.Message).Get());
		break;

	case pb::WD2DD_UPDATE_CHARACTER_HAIR_RES:
		HandleResult<pb::WD2DDUpdateCharacterHairRes>(StaticCastSharedRef<const pb::WD2DDUpdateCharacterHairRes>(Event.Message).Get());
		break;

	case pb::WD2DD_UPDATE_CHARACTER_ARMOR_RES:
		HandleResult<pb::WD2DDUpdateCharacterArmorRes>(StaticCastSharedRef<const pb::WD2DDUpdateCharacterArmorRes>(Event.Message).Get());
		break;

	case pb::WD2DD_PLAYER_LIST_RES:
		HandlePlayerListRes(StaticCastSharedRef<const pb::WD2DDPlayerListRes>(Event.Message).Get());
		break;

	case pb::WD2DD_INVITE_PARTY_RES:
		HandleResult<pb::WD2DDInvitePartyRes>(StaticCastSharedRef<const pb::WD2DDInvitePartyRes>(Event.Message).Get());
		break;

	case pb::WD2DD_INVITE_PARTY:
		HandleInviteParty(StaticCastSharedRef<const pb::WD2DDInviteParty>(Event.Message).Get());
		break;

	case pb::WD2DD_INVITE_PARTY_RESPONSE_RES:
		HandleResult<pb::WD2DDInvitePartyResponseRes>(StaticCastSharedRef<const pb::WD2DDInvitePartyResponseRes>(Event.Message).Get());
		break;

	case pb::WD2DD_PARTY_MESSAGE:
		HandlePartyMessage(StaticCastSharedRef<const pb::WD2DDPartyMessage>(Event.Message).Get());
		break;

	case pb::WD2DD_LEAVE_PARTY_RES:
		HandleLeavePartyRes(StaticCastSharedRef<const pb::WD2DDLeavePartyRes>(Event.Message).Get());
		break;

	default:
		P3JsonNetLog(Display, "invalid World message type", TEXT("ConnId"), Event.ConnId.X, TEXT("Type"), Event.MessageType);
		break;
	}
}

void UP3WorldNetBase::HandleRegisterRes(const pb::WD2DDRegisterRes& Message)
{
	check(GameInstance);

	UP3World* World = GameInstance->GetP3World();
	if (!ensure(World))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = World->GetServerWorld();
	if (!ensure(ServerWorld))
	{
		return;
	}

	ServerWorld->HandleRegisterRes(Message);

	GameInstance->GetPartyManager().SetWorldDediConnId(Message.world_dedi_id());

	ListenToPlayerNet();
}

void UP3WorldNetBase::HandleLoadCharacterRes(const pb::WD2DDLoadCharacterRes& Message)
{
	check(GameInstance);

	UP3World* World = GameInstance->GetP3World();
	if (!ensure(World))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = World->GetServerWorld();
	if (!ensure(ServerWorld))
	{
		return;
	}

	ServerWorld->HandleLoadCharacterRes(Message);
}

void UP3WorldNetBase::HandlePlayerListRes(const pb::WD2DDPlayerListRes& Message)
{
	check(GameInstance);

	if (Message.err() != pb::WD2DDErrorNone)
	{
		P3JsonLog(Error, "request player list error", TEXT("CharId"), UINT64_TO_STR(Message.char_id()));
		return;
	}

	charid CharId = Message.char_id();

	if (!ensure(CharId != INVALID_CHARID))
	{
		return;
	}

	UP3World* World = GameInstance->GetP3World();
	if (!ensure(World))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = World->GetServerWorld();
	if (!ensure(ServerWorld))
	{
		return;
	}

	FP3NetConnInfo NetConn = ServerWorld->GetPlayerConnInfoFromCharId(CharId);

	if (!ensure(FP3NetUtil::IsTCPConnection(NetConn) || FP3NetUtil::IsUDPConnection(NetConn)))
	{
		return;
	}

	const pb::PlayerList& RelayMessage = Message.player_list();

	ServerWorld->SendWorldMessageToClient(NetConn, pb::D2CWorldRelayMessageType::D2CWorldRelayPlayerList, RelayMessage);
}

void UP3WorldNetBase::HandleInviteParty(const pb::WD2DDInviteParty& Message)
{
	check(GameInstance);

	charid InviteeCharId = Message.invitee_char_id();

	if (!ensure(InviteeCharId != INVALID_CHARID))
	{
		return;
	}

	UP3World* World = GameInstance->GetP3World();
	if (!ensure(World))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = World->GetServerWorld();
	if (!ensure(ServerWorld))
	{
		return;
	}

	FP3NetConnInfo NetConn = ServerWorld->GetPlayerConnInfoFromCharId(InviteeCharId);

	if (!ensure(FP3NetUtil::IsTCPConnection(NetConn) || FP3NetUtil::IsUDPConnection(NetConn)))
	{
		return;
	}

	const pb::PartyInvitation& RelayMessage = Message.invitation();

	ServerWorld->SendWorldMessageToClient(NetConn, pb::D2CWorldRelayMessageType::D2CWorldRelayPartyInvitation, RelayMessage);
}

void UP3WorldNetBase::HandlePartyMessage(const pb::WD2DDPartyMessage& Message)
{
	check(GameInstance);

	UP3World* World = GameInstance->GetP3World();
	if (!ensure(World))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = World->GetServerWorld();
	if (!ensure(ServerWorld))
	{
		return;
	}

	pb::D2CWorldRelayMessageType RelayMessageType = pb::D2CWorldRelayMessageType::D2CWorldRelayInvalid;
	const ProtobufMessage* RelayMessage = nullptr;

	if (Message.has_join())
	{
		const pb::PartyMembersJoin& PartyJoin = Message.join();

		const partyid PartyId = PartyJoin.party_id();

		if (!ensure(PartyId != NON_PARTY_ID))
		{
			return;
		}

		bool bCreateParty = PartyJoin.create_party();

		if (bCreateParty)
		{
		}

		RelayMessageType = pb::D2CWorldRelayMessageType::D2CWorldRelayPartyMembersJoin;
		RelayMessage = &PartyJoin;
	}
	else if (Message.has_leave())
	{
		const pb::PartyMembersLeave& PartyLeave = Message.leave();

		const partyid PartyId = PartyLeave.party_id();

		if (!ensure(PartyId != NON_PARTY_ID))
		{
			return;
		}

		bool bRemoveParty = PartyLeave.remove_party();

		if (bRemoveParty)
		{
		}

		RelayMessageType = pb::D2CWorldRelayMessageType::D2CWorldRelayPartyMembersLeave;
		RelayMessage = &PartyLeave;
	}
	else
	{
		ensure(0);
		return;
	}

	if (!ensure(RelayMessage))
	{
		return;
	}

 	for (const uint64 CharId : Message.member_char_ids())
 	{
		if (CharId != INVALID_CHARID)
		{
			FP3NetConnInfo NetConn = ServerWorld->GetPlayerConnInfoFromCharId(CharId);

			if (!ensure(FP3NetUtil::IsTCPConnection(NetConn) || FP3NetUtil::IsUDPConnection(NetConn)))
			{
				continue;
			}
 
 			ServerWorld->SendWorldMessageToClient(NetConn, RelayMessageType, *RelayMessage);
 		}
 	}
}

void UP3WorldNetBase::HandleLeavePartyRes(const pb::WD2DDLeavePartyRes& Message)
{
	charid CharId = Message.char_id();

	if (!ensure(CharId != INVALID_CHARID))
	{
		return;
	}

	check(GameInstance);

	UP3World* World = GameInstance->GetP3World();
	if (!ensure(World))
	{
		return;
	}

	UP3ServerWorld* ServerWorld = World->GetServerWorld();
	if (!ensure(ServerWorld))
	{
		return;
	}

	FP3NetConnInfo NetConn = ServerWorld->GetPlayerConnInfoFromCharId(CharId);

	if (!ensure(FP3NetUtil::IsTCPConnection(NetConn) || FP3NetUtil::IsUDPConnection(NetConn)))
	{
		return;
	}

	pb::PartyLeaveRes RelayMessage;
	RelayMessage.set_success(Message.err() == pb::WD2DDError::WD2DDErrorNone);

	ServerWorld->SendWorldMessageToClient(NetConn, pb::D2CWorldRelayMessageType::D2CWorldRelayPartyLeaveRes, RelayMessage);
}

//////////////////////////////////////////////////////////////////////////
// UP3WorldNet
//////////////////////////////////////////////////////////////////////////

void UP3WorldNet::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	Super::Initialize(InGameInstance, InNet);
	Net = InNet;

	Host = CVarP3WorldHost.GetValueOnGameThread();
	Port = CVarP3WorldPort.GetValueOnGameThread();

	// Override from command-line option
	FString CmdWorldHost;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3WorldHost="), CmdWorldHost))
	{
		Host = CmdWorldHost;
	}

	int32 CmdWorldPort;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3WorldPort="), CmdWorldPort))
	{
		Port = CmdWorldPort;
	}
}

void UP3WorldNet::Shutdown()
{
	ConnId = INVALID_NETCONNID;
	ConnStatus = EP3NetConnStatus::Closed;
}

EP3NetConnStatus UP3WorldNet::GetConnStatus() const
{
	return ConnStatus;
}

static FString _GetNameForRegistering(const UWorld& World)
{
	const FString ComputerName = FPlatformProcess::ComputerName();

	FString WindowTitle;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3WindowTitle="), WindowTitle))
	{
		return ComputerName + " " + WindowTitle;
	}

	const AGameModeBase* GameMode = World.GetAuthGameMode();
	if (GameMode)
	{
		FString ZoneName = UGameplayStatics::ParseOption(GameMode->OptionsString, TEXT("Zone"));
		if (!ZoneName.IsEmpty())
		{
			return ComputerName + " " + ZoneName;
		}
	}

	return ComputerName;
}

void UP3WorldNet::HandleConnectEvent(const FP3NetConnectEvent& Event)
{
	check(Net);

	if (!Event.bSuccess)
	{
		P3JsonNetLog(Warning, "Failed to connect world server");
		ConnId = INVALID_NETCONNID;
		ConnStatus = EP3NetConnStatus::Closed;
		return;
	}

	P3JsonNetLog(Display, "World conn is connected");
	ConnStatus = EP3NetConnStatus::Connected;

	UWorld* World = GameInstance ? GameInstance->GetCurrentWorld() : nullptr;

	if (World)
	{
		SendRegister(*_GetNameForRegistering(*World));
	}
}

void UP3WorldNet::HandleCloseEvent(const FP3NetCloseEvent& Event)
{
	P3JsonNetLog(Display, "World server connection is closed", TEXT("ConnId"), Event.ConnId.X);

	ConnId = INVALID_NETCONNID;
	ConnStatus = EP3NetConnStatus::Closed;

	OnWorld.Broadcast("System", FString::Printf(TEXT("Connection closed")));
}

void UP3WorldNet::Connect()
{
	check(Net);

	if (ConnStatus != EP3NetConnStatus::Closed)
	{
		P3JsonNetLog(Warning, "World connection already exists. Try connect later", TEXT("ConnId"), ConnId.X);
		return;
	}

	TDescMap DescMap;
	DescMap.Add(pb::WD2DD_REGISTER_RES, pb::WD2DDRegisterRes::descriptor());
	DescMap.Add(pb::WD2DD_LOAD_CHARACTER_RES, pb::WD2DDLoadCharacterRes::descriptor());
	DescMap.Add(pb::WD2DD_SAVE_CHARACTER_RES, pb::WD2DDSaveCharacterRes::descriptor());
	DescMap.Add(pb::WD2DD_CREATE_CHARACTER_ITEM_RES, pb::WD2DDCreateCharacterItemRes::descriptor());
	DescMap.Add(pb::WD2DD_DELETE_CHARACTER_ITEM_RES, pb::WD2DDDeleteCharacterItemRes::descriptor());
	DescMap.Add(pb::WD2DD_UPDATE_CHARACTER_ITEM_SLOT_RES, pb::WD2DDUpdateCharacterItemSlotRes::descriptor());
	DescMap.Add(pb::WD2DD_UPDATE_CHARACTER_ITEM_STACK_RES, pb::WD2DDUpdateCharacterItemStackRes::descriptor());
	DescMap.Add(pb::WD2DD_CREATE_QUEST_RES, pb::WD2DDCreateQuestRes::descriptor());
	DescMap.Add(pb::WD2DD_UPDATE_QUEST_RES, pb::WD2DDUpdateQuestRes::descriptor());
	DescMap.Add(pb::WD2DD_UPDATE_CHARACTER_HAIR_RES, pb::WD2DDUpdateCharacterHairRes::descriptor());
	DescMap.Add(pb::WD2DD_UPDATE_CHARACTER_ARMOR_RES, pb::WD2DDUpdateCharacterArmorRes::descriptor());
	DescMap.Add(pb::WD2DD_PLAYER_LIST_RES, pb::WD2DDPlayerListRes::descriptor());
	DescMap.Add(pb::WD2DD_INVITE_PARTY_RES, pb::WD2DDInvitePartyRes::descriptor());
	DescMap.Add(pb::WD2DD_INVITE_PARTY, pb::WD2DDInviteParty::descriptor());
	DescMap.Add(pb::WD2DD_INVITE_PARTY_RESPONSE_RES, pb::WD2DDInvitePartyResponseRes::descriptor());
	DescMap.Add(pb::WD2DD_PARTY_MESSAGE, pb::WD2DDPartyMessage::descriptor());
	DescMap.Add(pb::WD2DD_LEAVE_PARTY_RES, pb::WD2DDLeavePartyRes::descriptor());

	FP3NetConnectParams Params;
	Params.Name = TEXT("World");
	Params.Host = Host;
	Params.Port = Port;
	Params.InitialDelaySeconds = 0.0f;
	Params.MaxRetryCount = CVarP3WorldMaxRetryCount.GetValueOnGameThread();
	Params.RetryIntervalSeconds = CVarP3WorldRetryIntervalSeconds.GetValueOnGameThread();
	Params.MaxSocketSendPerMessage = 0;
	Params.bEnableStat = false;

	ConnId = Net->ConnectPb(this, Params, DescMap);
	ConnStatus = EP3NetConnStatus::Connecting;
}

void UP3WorldNet::Close()
{
	check(Net);

	if (ConnStatus != EP3NetConnStatus::Connected)
	{
		P3JsonNetLog(Warning, "World connection is not connected", TEXT("ConnId"), ConnId.X);
		return;
	}

	Net->Close(ConnId);
	ConnStatus = EP3NetConnStatus::Closing;
}

void UP3WorldNet::Send(pb::DD2WDType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Net);

	P3JsonNetLog(Verbose, "SendMessage (World)",
		TEXT("ConnId"), ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::DD2WDType_Name(MessageType).c_str())));

	Net->SendPb(ConnId, MessageType, Message);
}

void UP3WorldNetBase::ListenToPlayerNet()
{
	if (ensure(GameInstance))
	{
		UP3PlayerNet* PlayerNet = GameInstance->GetPlayerNet();

		if (PlayerNet)
		{
			PlayerNet->Listen();
		}

		UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork();

		if (UDPNetwork)
		{
			UP3World* P3World = GameInstance->GetP3World();

			UDPNetwork->Init(P3World);
		}
	}
}

//////////////////////////////////////////////////////////////////////////
// UP3WorldNetLocal
//////////////////////////////////////////////////////////////////////////

void UP3WorldNetLocal::Connect()
{
	UWorld* World = GameInstance ? GameInstance->GetCurrentWorld() : nullptr;

	if (World)
	{
		SendRegister(*_GetNameForRegistering(*World));
	}
}

void UP3WorldNetLocal::Send(pb::DD2WDType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(GameInstance);

	switch (MessageType)
	{
	case pb::DD2WD_REGISTER:
		HandleRegister(StaticCastSharedRef<const pb::DD2WDRegister>(Message).Get());
		break;
	case pb::DD2WD_LOAD_CHARACTER:
		HandleLoadCharacter(StaticCastSharedRef<const pb::DD2WDLoadCharacter>(Message).Get());
		break;
	}
}

EP3NetConnStatus UP3WorldNetLocal::GetConnStatus() const
{
	return EP3NetConnStatus::Connected;
}

void UP3WorldNetLocal::HandleRegister(const pb::DD2WDRegister& Req)
{
	TSharedRef<pb::WD2DDRegisterRes, ESPMode::ThreadSafe> Message(new pb::WD2DDRegisterRes());
	Message->set_machine_id_for_item_id(1);

	Responses.Add(WorldNetLocalMessage(pb::DD2WD_REGISTER, Message));

	ListenToPlayerNet();
}

void UP3WorldNetLocal::HandleLoadCharacter(const pb::DD2WDLoadCharacter& Req)
{
	EP3CharClass CharClass = (EP3CharClass)CVarP3DefaultCharClass.GetValueOnGameThread();

	TSharedRef<pb::WD2DDLoadCharacterRes, ESPMode::ThreadSafe> Message(new pb::WD2DDLoadCharacterRes());
	Message->set_err(pb::WD2DDErrorNone);
	Message->set_account_id(Req.account_id());
	Message->set_char_id(Req.char_id());
	Message->set_char_name(TCHAR_TO_UTF8(*FString::Printf(TEXT("%s_%d"), *GameInstance->GetAccountName(), Req.char_id()))); // Use account as character name for world-less mode
	Message->set_char_class((uint8)CharClass);
// 	FVector Pos;
// 	FVector Rot;
	Message->set_char_level(1);
	Message->set_experience_point(0);

	for (const FP3CmsInitialItem* InitialItem : P3Cms::GetInitialItems(CharClass))
	{
		pb::CharacterItem* MessageItem = Message->add_items();
		if (MessageItem)
		{
			UP3ItemManager* ItemManager = P3Core::GetItemManager(*this);
			if (ensure(ItemManager))
			{
				const FP3Item Item = ItemManager->CreateItem(InitialItem->ItemCmsKey, InitialItem->Stack, "UP3WorldNetLocal::HandleLoadCharacter");

				if (ensure(Item.IsValid()))
				{
					MessageItem->set_id(Item.Id.ToUInt64());
					MessageItem->set_cms_key(Item.Key);
					MessageItem->set_stack(Item.Stack);
					MessageItem->set_slot((uint8)InitialItem->Slot);
				}
			};
		}
	}

	Responses.Add(WorldNetLocalMessage(pb::DD2WD_LOAD_CHARACTER, Message));
}

void UP3WorldNetLocal::Tick(float DeltaTime)
{
	if (Responses.Num() > 0)
	{
		for (WorldNetLocalMessage Res : Responses)
		{
			TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message = Res.Message;

			TSharedRef<FP3NetRecvPbEvent, ESPMode::ThreadSafe> Event(new FP3NetRecvPbEvent(Message));
			//Event->ConnId = Conn.GetId();
			Event->MessageType = Res.MessageType;

			HandleRecvPbEvent(*Event);
		}
		Responses.Reset();
	}
}
