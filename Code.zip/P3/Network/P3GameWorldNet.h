// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Lib/P3Net.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "pb/userlistener.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "pb/userlistener.pb.h"
#endif

#include "P3GameWorldNet.generated.h"

enum class EP3CharClass : uint8;

UCLASS()
class UP3GameWorldNet : public UObject, public IP3BaseNet
{
	GENERATED_BODY()

public:
	virtual ~UP3GameWorldNet() {}

	void Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet);
	void Shutdown();

	// IP3BaseNet Interface
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event);
	virtual void HandleListenEvent(const FP3NetListenEvent& Event) {}
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event) {}
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event);
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event);
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event) {}

	void Connect(class UP3LoginHUDWidget* LoginHUDWidget);
	void Close();
	void Send(pb::CL2WUType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);

	void SetHost(const FString& InHost);
	void SetPort(int32 InPort);

	void SendLogin(const FString& AuthToken);
	void SendListCharacters();
	void SendCreateCharacter(const FString& Name, EP3CharClass CharClass, const FString& HairName, const FString& ArmorName);
	void SendDeleteCharacter(charid CharacterId);
	void SendSelectCharacter(charid CharacterId);

private:
	void HandleLoginRes(const pb::WU2CLLoginRes& Message);
	void HandleListCharactersRes(const pb::WU2CLListCharactersRes& Message);
	void HandleCreateCharacterRes(const pb::WU2CLCreateCharacterRes& Message);
	void HandleDeleteCharacterRes(const pb::WU2CLDeleteCharacterRes& Message);
	void HandleSelectCharacterRes(const pb::WU2CLSelectCharacterRes& Message);


	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	UPROPERTY()
	UP3Net* Net = nullptr;

	FString Host;
	int32 Port = 0;
	P3NetConnId ConnId = INVALID_NETCONNID;

	TWeakObjectPtr<class UP3LoginHUDWidget> LoginHUDWidget;
};
