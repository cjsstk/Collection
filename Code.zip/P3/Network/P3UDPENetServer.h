// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3UDPENet.h"

#include "P3UDPENetServer.generated.h"

UCLASS()
class UP3UDPENetServer final : public UP3UDPENet
{
	GENERATED_BODY()

public:
	// form IUDPNetBase
	virtual void Initialize(class UP3GameInstance* InGameInstance) override;
	virtual void Shutdown() override;
	virtual void Close(const P3NetConnId NetConnId = INVALID_NETCONNID) override;
	virtual void Tick(float DeltaSeconds) override;

	// form UP3UDPNetwork
	virtual bool Init(class UP3World* InP3World, const FString& InHost = TEXT(""), int32 InPort = 0) override;
	virtual bool Server_SendPacketBuffer(P3NetConnId ClientConnId, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) override;
	virtual void Server_SendWorldMessage(P3NetConnId ConnId, const ::google::protobuf::Message& Message) override;
	virtual bool Server_IsConnected(P3NetConnId ClientConnId) const override;
	virtual bool IsServer() const override { return true; }

	// from UP3UDPENet
	virtual void InitThread() override;
	virtual void HandleReceiveEvent(const ENetEvent& Event) override;
	virtual void HandleConnectOnGameThread(const FP3ENetConnectEvent* Event) override;
	virtual void HandleDisconnectOnGameThread(const FP3ENetDisconnectEvent* Event) override;
	virtual void HandleReceiveOnGameThread(const FP3ENetReceiveEvent* Event) override;
	virtual bool IsValid()const override;

private:
	void HandleWorldMessage(P3NetConnId ConnId, const struct FP3UDPMessageWorld& Message);

private:
	class FP3ENetServerThreadRunnable final : public FP3ENetThreadRunnable
	{
	public:
		explicit FP3ENetServerThreadRunnable(UP3UDPENet& ENet);
		~FP3ENetServerThreadRunnable();

	protected:
	};

private:
	TSet<P3NetConnId> ClientConnIds;
};
