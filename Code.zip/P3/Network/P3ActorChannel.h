// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Engine/Channel.h"

#include "Lib/P3NetCore.h"
#include "P3Core.h"
#include "P3WorldNetCore.h"

#include "P3ActorChannel.generated.h"

class AActor;
class UNetConnection;

class UP3NetConnection;
class UP3UnrealUDPNet;

UCLASS(transient)
class UP3ActorChannel : public UChannel
{
	GENERATED_UCLASS_BODY()

	/////////////////////////////////////////////////////////////////////////////////
	/** UChannel */
	virtual void Init(UNetConnection* InConnection, int32 InChIndex, EChannelCreateFlags CreateFlags) override;
	virtual void SetClosingFlag() override;
	virtual void ReceivedBunch(class FInBunch& Bunch) override;
	virtual void Tick() override;
	virtual bool CanStopTicking() const override;

	virtual void ReceivedNak(int32 NakPacketId) override;
	virtual int64 Close(EChannelCloseReason Reason) override;
	virtual FString Describe() override;

	/** Append any export bunches */
	virtual void AppendExportBunches(TArray< FOutBunch* >& OutExportBunches) override;

	/** Append any "must be mapped" guids to front of bunch. These are guids that the client will wait on before processing this bunch. */
	virtual void AppendMustBeMappedGuids(FOutBunch* Bunch) override;

	virtual void Serialize(FArchive& Ar) override;

	/** Returns true if channel is ready to go dormant (e.g., all outstanding property updates have been ACK'd) */
	virtual bool ReadyForDormancy(bool debug = false) override;
	/** Puts the channel in a state to start becoming dormant. It will not become dormant until ReadyForDormancy returns true in Tick */
	virtual void StartBecomingDormant() override;

	virtual void AddedToChannelPool() override;

	virtual FPacketIdRange SendBunch(FOutBunch* Bunch, bool Merge) override;
	/////////////////////////////////////////////////////////////////////////////////
public:
	bool SendBunch(FOutBunch* Bunch, OUT FPacketIdRange& PacketId);
	
	void Server_InitChannel(AActor* InActor, UP3UnrealUDPNet* InUDPNet, const TArray<uint8>* SpawnData = nullptr);
	void Client_InitChannel(AActor* InActor, UP3UnrealUDPNet* InUDPNet);

	void SetChannelActor(AActor* InActor, bool bIsLocalActor = false);
	void SpawnChannelActor(const TArray<uint8>* SpawnData);

	bool CanSendBunch() const;

	void SetActorId(actorid ActorId) { ActorNetId = ActorId; }
	actorid GetActorId() const { return ActorNetId; }

	UP3NetConnection* GetP3Connection() const { return P3Connection; }
	AActor* GetActor() const { return Actor; }

	int64 SetChannelActorForDestroy();

protected:
	/** UChannel */
	virtual bool CleanUp(const bool bForDestroy, EChannelCloseReason CloseReason) override;
	/** Closes the actor channel but with a 'dormant' flag set so it can be reopened */
	virtual void BecomeDormant() override;

private:
	void ProcessBunch(FInBunch& Bunch);	

	/** Cached referenced to the UDP Net that owns this actor channel */
	UP3UnrealUDPNet* UDPNet = nullptr;

	actorid ActorNetId = INVALID_ACTORID; // currently equal to actorid

	AActor* Actor = nullptr;

	bool bIsClientLocalActor = false;

	UP3NetConnection* P3Connection = nullptr;
};
