// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3GoChatNet.h"
#include "P3GameInstance.h"
#include "P3Log.h"

void UP3GoChatNet::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	GameInstance = InGameInstance;
	Net = InNet;

	Host = "127.0.0.1";
	Port = 8021;
}

void UP3GoChatNet::Shutdown()
{
	ConnId = INVALID_NETCONNID;
}

const FString& UP3GoChatNet::GetHost()
{
	return Host;
}

void UP3GoChatNet::SetHost(const FString& InHost)
{
	Host = InHost;
}

int32 UP3GoChatNet::GetPort()
{
	return Port;
}

void UP3GoChatNet::SetPort(int32 InPort)
{
	Port = InPort;
}

void UP3GoChatNet::HandleConnectEvent(const FP3NetConnectEvent& Event)
{
	if (Event.bSuccess)
	{
		P3JsonNetLog(Display, "Chat conn is connected");

		SendEnter();
	}
	else
	{
		P3JsonNetLog(Warning, "Failed to connect chat server");
		ConnId = INVALID_NETCONNID;
	}
}

void UP3GoChatNet::HandleCloseEvent(const FP3NetCloseEvent& Event)
{
	P3JsonNetLog(Display, "Chat server connection is closed", TEXT("ConnId"), Event.ConnId.X);
	ConnId = INVALID_NETCONNID;
}

void UP3GoChatNet::HandleRecvPbEvent(const FP3NetRecvPbEvent& Event)
{
	P3JsonNetLog(Verbose, "Chat Message",
		TEXT("ConnId"), Event.ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::CS2CCType_Name((pb::CS2CCType)Event.MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Event.Message->DebugString().c_str())));

	switch (Event.MessageType)
	{
	case pb::CS2CCType::CS2CC_ENTER_RES:
		HandleEnterRes(StaticCastSharedRef<const pb::CS2CCEnterRes>(Event.Message).Get());
		break;

	default:
		P3JsonNetLog(Error, "Invalid CS2CC message type", TEXT("ConnId"), Event.ConnId.X, TEXT("MessageType"), Event.MessageType);
		break;
	}
}

void UP3GoChatNet::HandleEnterRes(const pb::CS2CCEnterRes& Message)
{
	if (Message.err() != pb::CS2CCError::CS2CCErrorNone)
	{
		P3JsonNetLog(Error, "Failed to enter (Chat)", TEXT("ConnId"), ConnId.X, TEXT("error"), Message.err());
	}
}

void UP3GoChatNet::Connect()
{
	check(Net);

	if (!ensure(ConnId == INVALID_NETCONNID))
	{
		P3JsonNetLog(Error, "Already has auth connection");
		return;
	}

	TDescMap DescMap;
	DescMap.Add(pb::CS2CC_ENTER_RES, pb::CS2CCEnterRes::descriptor());

	FP3NetConnectParams Params;
	Params.Name = TEXT("Chat");
	Params.Host = Host;
	Params.Port = Port;
	Params.InitialDelaySeconds = 0.0f;
	Params.MaxRetryCount = 0;
	Params.RetryIntervalSeconds = 0.0f;
	Params.MaxSocketSendPerMessage = 0;
	Params.bEnableStat = false;

	ConnId = Net->ConnectPb(this, Params, DescMap);
}

void UP3GoChatNet::Send(pb::CC2CSType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Net);

	P3JsonNetLog(Verbose, "SendMessage (Chat)",
		TEXT("ConnId"), ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::CC2CSType_Name(MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Message->DebugString().c_str())));

	Net->SendPb(ConnId, MessageType, Message);
}

void UP3GoChatNet::SendEnter()
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	FString UserName = GameInstance->GetCharacterName();

	TSharedRef<pb::CC2CSEnter, ESPMode::ThreadSafe> Message(new pb::CC2CSEnter());
	Message->set_user_name(TCHAR_TO_UTF8(*UserName));

	Send(pb::CC2CS_ENTER, Message);
}
