// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3DedimanHelper.h"

#include "Http.h"
#include "JsonObjectConverter.h"

static TAutoConsoleVariable<FString> CVarP3DedimanURL(
	TEXT("p3.dedimanURL"),
	TEXT("http://localhost:9000"),
	TEXT("Dediman URL"), ECVF_Default);

void UP3DedimanHelper::Initialize(class UP3GameInstance* InGameInstance)
{
	GameInstance = InGameInstance;
}

void UP3DedimanHelper::Shutdown()
{
	GameInstance = nullptr;
}

void UP3DedimanHelper::GetZoneChannels(const FString& ZoneName)
{
	TSharedRef<IHttpRequest> Request = FHttpModule::Get().CreateRequest();

	const FString URL = FString::Printf(TEXT("%s/api/client/zone_channels?zone=%s"), *GetDedimanURL(), *ZoneName);

	Request->SetURL(URL);
	Request->SetVerb("GET");
	Request->OnProcessRequestComplete().BindUObject(this, &UP3DedimanHelper::OnGetZoneChannelsResponse);
	Request->ProcessRequest();
}

void UP3DedimanHelper::OnGetZoneChannelsResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	FP3DediInfoListResponse DediInfoList;

	if (!bWasSuccessful)
	{
		OnGetZoneChannels.Broadcast(DediInfoList, false);
		return;
	}

	bool bParseSuccess = FJsonObjectConverter::JsonObjectStringToUStruct<FP3DediInfoListResponse>(Response->GetContentAsString(), &DediInfoList, 0, 0);

	OnGetZoneChannels.Broadcast(DediInfoList, bParseSuccess);
}

void UP3DedimanHelper::AllocZoneChannel(const FString& ZoneName, charid CharacterId, const TCHAR* CharacterName)
{
	TSharedRef<IHttpRequest> Request = FHttpModule::Get().CreateRequest();

	const FString URL = FString::Printf(TEXT("%s/api/client/characters"), *GetDedimanURL());

	Request->SetURL(URL);
	Request->SetVerb("POST");
	Request->SetHeader("Content-Type", TEXT("application/json"));
	Request->SetContentAsString(FString::Printf(TEXT("{\"zone\":\"%s\",\"character_id\":\"%llu\",\"character_name\":\"%s\"}"), *ZoneName, CharacterId, CharacterName));
	Request->OnProcessRequestComplete().BindUObject(this, &UP3DedimanHelper::OnAllocZoneChannelResponse);
	Request->ProcessRequest();
}

void UP3DedimanHelper::OnAllocZoneChannelResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	FP3DediInfoResponse DediInfo;

	if (!bWasSuccessful)
	{
		OnAllocZoneChannel.Broadcast(DediInfo, false);
		return;
	}

	bool bParseSuccess = FJsonObjectConverter::JsonObjectStringToUStruct<FP3DediInfoResponse>(Response->GetContentAsString(), &DediInfo, 0, 0);

	OnAllocZoneChannel.Broadcast(DediInfo, bParseSuccess);
}

void UP3DedimanHelper::AllocZoneChannelForce(int32 ZoneChannelId, charid CharacterId, const TCHAR* CharacterName)
{
	TSharedRef<IHttpRequest> Request = FHttpModule::Get().CreateRequest();

	const FString URL = FString::Printf(TEXT("%s/api/client/characters"), *GetDedimanURL());

	Request->SetURL(URL);
	Request->SetVerb("POST");
	Request->SetHeader("Content-Type", TEXT("application/json"));
	Request->SetContentAsString(FString::Printf(TEXT("{\"zone_channel_id\":%d,\"character_id\":\"%llu\",\"character_name\":\"%s\"}"), ZoneChannelId, CharacterId, CharacterName));
	Request->OnProcessRequestComplete().BindUObject(this, &UP3DedimanHelper::OnAllocZoneChannelForceResponse);
	Request->ProcessRequest();
}

void UP3DedimanHelper::OnAllocZoneChannelForceResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	FP3DediInfoResponse DediInfo;

	if (!bWasSuccessful)
	{
		OnAllocZoneChannelForce.Broadcast(DediInfo, false);
		return;
	}

	bool bParseSuccess = FJsonObjectConverter::JsonObjectStringToUStruct<FP3DediInfoResponse>(Response->GetContentAsString(), &DediInfo, 0, 0);

	OnAllocZoneChannelForce.Broadcast(DediInfo, bParseSuccess);
}

void UP3DedimanHelper::RegisterToDediman(const TCHAR* ZoneName, const TCHAR* Host, int32 GamePort, int32 GameUDPPort, int32 AdminPort)
{
	TSharedRef<IHttpRequest> Request = FHttpModule::Get().CreateRequest();

	const FString URL = FString::Printf(TEXT("%s/api/dedi/zone_channels"), *GetDedimanURL());
	const FString Body = FString::Printf(TEXT("{\"zoneName\":\"%s\",\"host\":\"%s\",\"gamePort\":%d,\"gameUdpPort\":%d,\"adminPort\":%d}"),
		ZoneName, Host, GamePort, GameUDPPort, AdminPort);

	Request->SetURL(URL);
	Request->SetVerb("POST");
	Request->SetHeader("Content-Type", TEXT("application/json"));
	Request->SetContentAsString(Body);
	Request->OnProcessRequestComplete().BindUObject(this, &UP3DedimanHelper::OnRegisterDedimanResponse);
	Request->ProcessRequest();
}

void UP3DedimanHelper::OnRegisterDedimanResponse(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful)
{
	if (!bWasSuccessful)
	{
		OnRegisterDediman.Broadcast(0, false);
		return;
	}

	FP3RegisterDedimanResponse Body;
	bool bParseSuccess = FJsonObjectConverter::JsonObjectStringToUStruct<FP3RegisterDedimanResponse>(Response->GetContentAsString(), &Body, 0, 0);

	OnRegisterDediman.Broadcast(Body.ZoneChannelId, bParseSuccess);
}

void UP3DedimanHelper::UnregisterFromDediman(uint32 ZoneChannelId)
{
	TSharedRef<IHttpRequest> Request = FHttpModule::Get().CreateRequest();

	const FString URL = FString::Printf(TEXT("%s/api/dedi/zone_channels/%u"), *GetDedimanURL(), ZoneChannelId);

	Request->SetURL(URL);
	Request->SetVerb("DELETE");
	Request->ProcessRequest();
}

FString UP3DedimanHelper::GetDedimanURL() const
{
	return DedimanURL.IsEmpty() ? CVarP3DedimanURL.GetValueOnGameThread() : DedimanURL;
}
