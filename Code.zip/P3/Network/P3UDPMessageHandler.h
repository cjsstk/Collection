// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3Core.h"

class UP3ActorChannel;

enum class EP3NetComponentType : uint16;

class UP3UnrealUDPNet;

class FP3UDPMessageHandler
{
public:
	FP3UDPMessageHandler() {}

	bool SendToActorChannel(UNetConnection* Connection, actorid ActorId, AActor* Actor, TArray<uint8>& Buffer, EP3NetComponentType ComponentType, const FName& HandlerFunctionName, bool bReliable);

	void ReceivedBunch(UP3ActorChannel* ActorChannel, FInBunch& Bunch);

	void SetUDPNet(UP3UnrealUDPNet* InUDPNet) { UDPNet = InUDPNet; }

private:
	static void AddHandlerFunctionName(const FString& FunctionName, bool bReliable, int32 BufferSize);

private:
	UP3UnrealUDPNet* UDPNet = nullptr;

	static TArray<FString> HandlerFuncNames;
};
