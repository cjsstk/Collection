// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ChatNet.h"

#include "Lib/P3Net.h"
#include "Lib/P3Packer.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3World.h"

#include "Engine/NetConnection.h"
#include "JsonObjectConverter.h"

static TAutoConsoleVariable<FString> CVarP3ChatHost(
	TEXT("p3.chatHost"),
	TEXT("chat.p3-xlgames.com"),
	TEXT("Hostname for chat server"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3ChatPort(
	TEXT("p3.chatPort"),
	8021,
	TEXT("Port for chat server"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3ChatMaxRetryCount(
	TEXT("p3.chatMaxRetryCount"),
	120,
	TEXT("Maximum retry count when try to connect chat server"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3ChatRetryIntervalSeconds(
	TEXT("p3.chatRetryIntervalSeconds"),
	1.0f,
	TEXT("Interval when retry to connect chat server"), ECVF_Default);

static TAutoConsoleVariable<float> CVarP3ChatAutoReconnectDelaySeconds(
	TEXT("p3.chatAutoReconnectDelaySeconds"),
	2.0f,
	TEXT("Delay when reconnect chat server"), ECVF_Default);

void UP3ChatNet::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	GameInstance = InGameInstance;
	Net = InNet;

	Host = CVarP3ChatHost.GetValueOnGameThread();
	Port = CVarP3ChatPort.GetValueOnGameThread();
}

void UP3ChatNet::Shutdown()
{
	ensure(GameInstance && Net);

	GameInstance = nullptr;
	Net = nullptr;

	ConnId = INVALID_NETCONNID;
	ConnStatus = EP3NetConnStatus::Closed;
}

EP3NetConnStatus UP3ChatNet::GetConnStatus() const
{
	return ConnStatus;
}

void UP3ChatNet::HandleConnectEvent(const FP3NetConnectEvent& Event)
{
	if (!(GameInstance && Net))
	{
		return;
	}

	if (!Event.bSuccess)
	{
		P3JsonNetLog(Warning, "Failed to connect chat server");
		ConnId = INVALID_NETCONNID;
		ConnStatus = EP3NetConnStatus::Closed;
		return;
	}

	P3JsonNetLog(Display, "Chat conn is connected");
	ConnStatus = EP3NetConnStatus::Connected;
}

void UP3ChatNet::HandleCloseEvent(const FP3NetCloseEvent& Event)
{
	if (!(GameInstance && Net))
	{
		return;
	}

	P3JsonNetLog(Display, "Chat server connection is closed", TEXT("ConnId"), Event.ConnId.X);

	ConnId = INVALID_NETCONNID;
	ConnStatus = EP3NetConnStatus::Closed;

	OnChat.Broadcast("System", 0, FString::Printf(TEXT("Connection closed")));

	Connect(CVarP3ChatAutoReconnectDelaySeconds.GetValueOnGameThread());
}

void UP3ChatNet::HandleRecvExEvent(const FP3NetRecvExEvent& Event)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ChatNet_HandleRecvEvent"), STAT_P3ChatNet_HandleRecvEvent, STATGROUP_P3);

	if (!(GameInstance && Net))
	{
		return;
	}

	const FP3ChatProtocol::ESCPacketType MessageType = StaticCast<FP3ChatProtocol::ESCPacketType>(Event.MessageType);

	P3JsonNetLog(Verbose, "Chat Message",
		TEXT("ConnId"), Event.ConnId.X,
		TEXT("MessageType"), FP3ChatProtocol::GetSCPacketTypeStr(MessageType));

	if (!P3ChatSCPacketDispatch(this, Event.Message))
	{
		P3JsonNetLog(Error, "Unknown message type",
			TEXT("Protocol"), TEXT("Chat"),
			TEXT("ConnId"), Event.ConnId.X,
			TEXT("Type"), Event.MessageType);
	}
}

void UP3ChatNet::Connect(float InitialDelaySeconds)
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	if (ConnStatus != EP3NetConnStatus::Closed)
	{
		P3JsonNetLog(Warning, "Chat connection already exists. Try connect later", TEXT("ConnId"), ConnId.X);
		return;
	}

	TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol(new FP3ChatProtocol());

	FP3NetConnectParams Params;
	Params.Name = TEXT("Chat");
	Params.Host = Host;
	Params.Port = Port;
	Params.InitialDelaySeconds = InitialDelaySeconds;
	Params.MaxRetryCount = CVarP3ChatMaxRetryCount.GetValueOnGameThread();
	Params.RetryIntervalSeconds = CVarP3ChatRetryIntervalSeconds.GetValueOnGameThread();
	Params.MaxSocketSendPerMessage = 0;
	Params.bEnableStat = false;

	ConnId = Net->ConnectEx(this, Params, Protocol);
	ConnStatus = EP3NetConnStatus::Connecting;
}

void UP3ChatNet::Close()
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	if (ConnStatus != EP3NetConnStatus::Connected)
	{
		P3JsonNetLog(Warning, "Chat connection is not connected", TEXT("ConnId"), ConnId.X);
		return;
	}

	Net->Close(ConnId);
	ConnStatus = EP3NetConnStatus::Closing;
}

void UP3ChatNet::HandleProceed(const FP3ChatProtocol::FSCProceed& Message)
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	TSharedRef<FP3ChatProtocol::FCSJoin, ESPMode::ThreadSafe> Req(new FP3ChatProtocol::FCSJoin());
	Req->ChannelName = "Global";
	Req->UserName = GameInstance->GetCharacterName();

	Send(Req);
}

void UP3ChatNet::HandleCreateReply(const FP3ChatProtocol::FSCCreateReply& Message)
{
	// Not implemented yet
}

void UP3ChatNet::HandleJoinReply(const FP3ChatProtocol::FSCJoinReply& Message)
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	P3JsonNetLog(Verbose, "Join Reply", TEXT("Channel"), Message.ChannelName, TEXT("Result"), (int32)Message.Result);

	if (Message.Result == FP3ChatProtocol::EChannelResult::Ok)
	{
		OnChat.Broadcast("System", 0, FString::Printf(TEXT("Joined channel [%s]"), *Message.ChannelName));
	}
	else
	{
		OnChat.Broadcast("System", 0, FString::Printf(TEXT("Failed to join: %s"), FP3ChatProtocol::GetChannelResultStr(Message.Result)));
	}
}

void UP3ChatNet::HandleLeaveReply(const FP3ChatProtocol::FSCLeaveReply& Message)
{
	// Not implemented yet
}

void UP3ChatNet::HandleChatReply(const FP3ChatProtocol::FSCChatReply& Message)
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	if (Message.Result != FP3ChatProtocol::EChannelResult::Ok)
	{
		OnChat.Broadcast("System", 0, FString::Printf(TEXT("Failed to chat: %s"), FP3ChatProtocol::GetChannelResultStr(Message.Result)));
	}
}

void UP3ChatNet::HandleChat(const FP3ChatProtocol::FSCChat& Message)
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	OnChat.Broadcast(Message.UserName, Message.ZoneChannelId, Message.Msg);
}

void UP3ChatNet::Send(TSharedRef<const FP3NetCSMessage, ESPMode::ThreadSafe> Message)
{
	if (!ensure(GameInstance && Net))
	{
		return;
	}

	P3JsonNetLog(Verbose, "SendMessage (Chat)",
		TEXT("ConnId"), ConnId.X,
		TEXT("MessageType"), FP3ChatProtocol::GetCSPacketTypeStr(StaticCast<FP3ChatProtocol::ECSPacketType>(Message->GetType())));

	Net->SendEx(ConnId, Message);
}
