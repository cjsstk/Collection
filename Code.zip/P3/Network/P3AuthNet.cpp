// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AuthNet.h"
#include "P3Log.h"
#include "P3GameInstance.h"

static TAutoConsoleVariable<FString> CVarP3AuthHost(
	TEXT("p3.authHost"),
	TEXT("auth.p3-xlgames.com"),
	TEXT("Hostname for auth server"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3AuthPort(
	TEXT("p3.authPort"),
	8001,
	TEXT("Port for auth server"), ECVF_Default);

void UP3AuthNet::Initialize(class UP3GameInstance* InGameInstance, UP3Net* InNet)
{
	GameInstance = InGameInstance;
	Net = InNet;

	Host = CVarP3AuthHost.GetValueOnGameThread();
	Port = CVarP3AuthPort.GetValueOnGameThread();
}

void UP3AuthNet::Shutdown()
{
	ConnId = INVALID_NETCONNID;
}

const FString& UP3AuthNet::GetHost()
{
	return Host;
}

void UP3AuthNet::SetHost(const FString& InHost)
{
	Host = InHost;
}

int32 UP3AuthNet::GetPort()
{
	return Port;
}

void UP3AuthNet::SetPort(int32 InPort)
{
	Port = InPort;
}

void UP3AuthNet::HandleConnectEvent(const FP3NetConnectEvent& Event)
{
	if (Event.bSuccess)
	{
		P3JsonNetLog(Display, "Auth conn is connected");
	}
	else
	{
		P3JsonNetLog(Warning, "Failed to connect auth server");
		ConnId = INVALID_NETCONNID;
	}

	OnConnected.Broadcast(Event.bSuccess);
}

void UP3AuthNet::HandleCloseEvent(const FP3NetCloseEvent& Event)
{
	P3JsonNetLog(Display, "Auth server connection is closed", TEXT("ConnId"), Event.ConnId.X);
	ConnId = INVALID_NETCONNID;
}

void UP3AuthNet::HandleRecvPbEvent(const FP3NetRecvPbEvent& Event)
{
	P3JsonNetLog(Verbose, "Auth Message",
		TEXT("ConnId"), Event.ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::A2CType_Name((pb::A2CType)Event.MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Event.Message->DebugString().c_str())));

	switch (Event.MessageType)
	{
	case pb::A2C_SIGN_UP_RES:
		HandleSignUpRes(StaticCastSharedRef<const pb::A2CSignUpRes>(Event.Message).Get());
		break;

	case pb::A2C_LOGIN_RES:
		HandleLoginRes(StaticCastSharedRef<const pb::A2CLoginRes>(Event.Message).Get());
		break;

	default:
		P3JsonNetLog(Error, "Invalid A2C message type", TEXT("ConnId"), Event.ConnId.X, TEXT("MessageType"), Event.MessageType);
		break;
	}
}

void UP3AuthNet::HandleSignUpRes(const pb::A2CSignUpRes& Message)
{
	bool bSignUpSuccess = false;
	FString ErrorMessage;

	switch (Message.err())
	{
	case pb::ERR_SUCCESS:
		bSignUpSuccess = true;
		break;
	case pb::ERR_INTERNAL_ERROR:
		ErrorMessage = FString::Printf(TEXT("Server error (%d)"), Message.err());
		break;
	case pb::ERR_INVALID_ACCOUNT:
		ErrorMessage = FString::Printf(TEXT("Invalid account (%d)"), Message.err());
		break;
	case pb::ERR_ALREADY_EXIST:
		ErrorMessage = FString::Printf(TEXT("Already exist (%d)"), Message.err());
		break;
	default:
		ErrorMessage = FString::Printf(TEXT("Unknown error (%d)"), Message.err());
		break;
	}

	OnSignUp.Broadcast(bSignUpSuccess, ErrorMessage);
}

void UP3AuthNet::HandleLoginRes(const pb::A2CLoginRes& Message)
{
	check(GameInstance);

	const bool bLoginSuccess = !Message.token().empty();
	const FString Account = UTF8_TO_TCHAR(Message.account().c_str());
	const FString Token = UTF8_TO_TCHAR(Message.token().c_str());

	TArray<FP3WorldServerInfo> Dedis;

	if (bLoginSuccess)
	{
		GameInstance->SetAccountName(Account);
		GameInstance->SetAuthToken(Token);

		int32 NumDedi = Message.dedis_size();
		for (int32 Index = 0; Index < NumDedi; ++Index)
		{
			const ::pb::DediInfo& Info = Message.dedis(Index);

			FP3WorldServerInfo ConvertedInfo;
			ConvertedInfo.Name = UTF8_TO_TCHAR(Info.name().c_str());
			ConvertedInfo.Address = UTF8_TO_TCHAR(Info.address().c_str());
			ConvertedInfo.Port = Info.port();

			Dedis.Add(ConvertedInfo);
		}
	}

	OnLogin.Broadcast(bLoginSuccess, Account, Dedis);
}

void UP3AuthNet::Connect()
{
	check(Net);

	if (!ensure(ConnId == INVALID_NETCONNID))
	{
		P3JsonNetLog(Error, "Already has auth connection");
		return;
	}

	TDescMap DescMap;
	DescMap.Add(pb::A2C_SIGN_UP_RES, pb::A2CSignUpRes::descriptor());
	DescMap.Add(pb::A2C_LOGIN_RES, pb::A2CLoginRes::descriptor());

	FP3NetConnectParams Params;
	Params.Name = TEXT("Auth");
	Params.Host = Host;
	Params.Port = Port;
	Params.InitialDelaySeconds = 0.0f;
	Params.MaxRetryCount = 0;
	Params.RetryIntervalSeconds = 0.0f;
	Params.MaxSocketSendPerMessage = 0;
	Params.bEnableStat = false;

	ConnId = Net->ConnectPb(this, Params, DescMap);
}

void UP3AuthNet::SignUp(const FString& Account, const FString& Password)
{
	TSharedRef<pb::C2ASignUpReq, ESPMode::ThreadSafe> Message(new pb::C2ASignUpReq());
	Message->set_account(TCHAR_TO_UTF8(*Account));
	Message->set_password(TCHAR_TO_UTF8(*Password));

	Send(pb::C2A_SIGN_UP_REQ, Message);
}

void UP3AuthNet::Login(const FString& Account, const FString& Password)
{
	TSharedRef<pb::C2ALoginReq, ESPMode::ThreadSafe> Message(new pb::C2ALoginReq());
	Message->set_account(TCHAR_TO_UTF8(*Account));
	Message->set_password(TCHAR_TO_UTF8(*Password));

	Send(pb::C2A_LOGIN_REQ, Message);
}

void UP3AuthNet::Send(pb::C2AType MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Net);

	P3JsonNetLog(Verbose, "SendMessage (Auth)",
		TEXT("ConnId"), ConnId.X,
		TEXT("MessageType"), FString(UTF8_TO_TCHAR(pb::C2AType_Name(MessageType).c_str())),
		TEXT("DebugString"), FString(UTF8_TO_TCHAR(Message->DebugString().c_str())));

	Net->SendPb(ConnId, MessageType, Message);
}
