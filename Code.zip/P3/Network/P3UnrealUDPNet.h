// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Engine/NetDriver.h"
//#include "UnrealNames.h"

#include "Lib/P3NetCore.h"
#include "P3Core.h"
#include "P3UDPMessageHandler.h"
#include "P3UDPNetDelegates.h"
#include "P3UDPNetwork.h"
#include "P3WorldNetCore.h"

#include "P3UnrealUDPNet.generated.h"

class AActor;
class UWorld;
class UNetConnection;

struct FP3NetHeader;

class UP3ActorChannel;
class UP3Channel;
class UP3NetConnection;

enum class EP3ControlCommand : uint8;


UENUM()
enum class EP3UnrealUDPNetFlags : uint32
{
	None = 0x00000000,	// No flags
};

ENUM_CLASS_FLAGS(EP3UnrealUDPNetFlags);

UCLASS()
class UP3UnrealUDPNet final : public UP3UDPNetwork
{
	GENERATED_BODY()

	friend class FP3NetworkNotify;
	friend class FP3UDPMessageHandler;

	enum EP3NetDriverMode : uint32
	{
		None, // editor
		WorldNetDriver, // server only
		UnlinkWorld, // client only
		LinkDummyWorld,

		DefaultClientMode = LinkDummyWorld,
		DefaultServerMode = WorldNetDriver,
	};

	enum EP3UDPNetState : uint32
	{
		Invalid,
		Inactived,
		Actived,
	};

public:
	// from UP3UDPNetwork
	virtual void Client_DestroyActor(actorid ActorId) override;

	FP3UDPMessageHandler& GetMessageHandler() { return MessageHandler; }

	void CloseConnection(UNetConnection* Connection);

	static UP3NetConnection* GetP3Connection(UNetConnection* Connection);

private:
	// from IUDPNetBase
	virtual void Initialize(class UP3GameInstance* InGameInstance) override;
	virtual void Shutdown() override;
	virtual void Close(P3NetConnId ConnId = INVALID_NETCONNID) override;

	// from UP3UDPNetwork
	virtual bool Init(class UP3World* InP3World, const FString& InHost = TEXT(""), int32 InPort = 0) override;
	virtual bool Server_SendPacketBuffer(P3NetConnId ClientConnId, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) override;
	virtual bool Server_IsConnected(P3NetConnId ClientConnId) const override;
	virtual UP3ActorChannel* Server_CreateActorChannel(P3NetConnId ConnId, AActor* Actor, FP3NetSpawnActorParams* SpawnActorParam = nullptr) override;
	virtual void Server_DestroyActorChannel(P3NetConnId ConnId, actorid ActorId) override;
	virtual bool Client_SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bForceReliable) override;
	virtual void Client_SetChannelActor(actorid ActorId, AActor* Actor, bool bIsLocalActor) override;
	virtual bool Client_IsConnected() const override;
	virtual EP3NetConnStatus Client_GetConnStatus() const override;
	virtual FP3NetStat GetAvgConnStat() const override;
	virtual int32 GetPingTimeMsec() const override;
	virtual FDateTime GetPingUpdatedTime() const override;
	virtual float GetServerFrameTimeMsec() const override;

	void Tick(float DeltaSeconds);

	bool IsActive() const { return bState == EP3UDPNetState::Actived; }

	void Client_SpawnActor(const TArray<uint8>& SpawnData);
	void Client_AddPendingActorChannel(UP3ActorChannel* ActorChannel);

	bool Server_MulticastPacketBufferToActor(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable);

	void SendControlMessage(UNetConnection* Connection, EP3ControlCommand ControlCommand, TArray<uint8>& Data);
	void ReceiveControlMesasge(UNetConnection* Connection, EP3ControlCommand ControlCommand, TArray<uint8>& Data);

	void HandlePing(UNetConnection* Connection, uint32 PingId, int32 PingTime);
	void HandlePong(uint32 PingId, float ServerFrameTimeMsec);

	void HandleUnrealRaw(UNetConnection* Connection, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, EP3NetComponentType ComponentType, const FString& HandlerFunction);

	static UP3Channel* GetControlChannel(const UNetConnection* Connection);	

	UWorld* GetGameWorld() const { return GameWorld; }

	P3NetConnId InitNetConnection(UNetConnection* Connection);

	template<typename T>
	static T* GetP3Channel(UChannel* Channel)
	{
		return Cast<T>(Channel);
	}
	
private:
	bool InitNetDriver(UWorld* InWorld, uint32 InNetDriverMode);
	void InitChannel();

	//bool Server_Listen();
	bool Client_Connect();

	void Client_SendInitialJoin();
	void Client_SendJoin();

	UP3ActorChannel* Server_CreateActorChannel(UNetConnection* Connection, AActor* Actor, FP3NetSpawnActorParams* SpawnActorParam);
	void Server_SendChallengeControlMessage(UNetConnection* Connection);
	void Server_WelcomePlayer(UNetConnection* Connection);

	bool Server_AddConnection(UNetConnection* NewConnection);
	void Server_RemoveConnection(P3NetConnId ClientConnId);
	UNetConnection* Server_GetConnection(P3NetConnId ClientConnId) const;

	void TickNetClient(float DeltaSeconds);
	void TickNetServer(float DeltaSeconds);

	int32 IncreaseSequenceId() { return FPlatformAtomics::InterlockedIncrement(&ConnSequenceId); }

	void UpdateStat();

	static UWorld* CreateDummyWorld();
	static UNetDriver* CreateOrChangeNetDriver(UWorld* NewWorld, UWorld* OldWorld, const FName& NetDriverDefName = NAME_None);

public:
	static constexpr int32 ControlChannelIndex = 0;
	static constexpr int32 BaseActorChannelIndex = 1;

private:
	UWorld* GameWorld = nullptr;
	UWorld* DummyWorld = nullptr;
	UNetDriver* NetDriver = nullptr;

	TMap<P3NetConnId, TSharedPtr<FInternetAddr>> MappedClientConnectionAddrs; // only server

	FP3WorldTickHook WorldTickHook;
	FP3NetworkNotify NetworkNotify;

	bool bSuccessfullyConnected = false; // only client
	bool bSentJoinRequest = false; // only client
	bool bCreatedBaseActorChannel = false; // only client
	bool bNotifyConnected = false; // only client

	TArray<UP3ActorChannel*> PendingActorChannels; // only client

	EP3UnrealUDPNetFlags UnrealUDPNetFlag = EP3UnrealUDPNetFlags::None;
	uint32 NetDriverMode = EP3NetDriverMode::None;
	EP3UDPNetState bState = EP3UDPNetState::Invalid;

	uint32 ListenPort = 0; // only server

	FP3UDPMessageHandler MessageHandler;

	float ConnectTimeOut = 60000.0f; // only client

	//TSortedMap<FString, int32> FunctionNames;

	volatile int32 ConnSequenceId = 0; // only server

	static int32 NetDriveCount; // only server

	FP3NetStat NetStat;
	double StatUpdateTime = 0.0;
	int32 StatSentBytes = 0;
	int32 StatRecvBytes = 0;
	int32 StatSentMessages = 0;
	int32 StatRecvMessages = 0;

	int32 InPacketLost = 0;
	int32 OutPacketsLost = 0;
	int32 InTotalPacketsLost = 0;
	int32 OutTotalPacketsLost = 0;
};
