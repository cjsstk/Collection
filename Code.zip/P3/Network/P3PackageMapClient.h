// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Engine/PackageMapClient.h"

#include "P3PackageMapClient.generated.h"

UCLASS(transient)
class UP3PackageMapClient : public UPackageMapClient
{
	GENERATED_UCLASS_BODY()

	// UPackageMap Interface
	virtual bool SerializeObject(FArchive& Ar, UClass* InClass, UObject*& Obj, FNetworkGUID* OutNetGUID = nullptr);
	virtual bool SerializeNewActor(FArchive& Ar, class UActorChannel *Channel, class AActor*& Actor) override { return true; }

	virtual bool WriteObject(FArchive& Ar, UObject* InOuter, FNetworkGUID NetGUID, FString ObjName) override { return true; }

	virtual void ReceivedNak(const int32 NakPacketId) override {}
	virtual void ReceivedAck(const int32 AckPacketId) override {}
	virtual void NotifyBunchCommit(const int32 OutPacketId, const FOutBunch* OutBunch) override {}
	virtual void GetNetGUIDStats(int32 &AckCount, int32 &UnAckCount, int32 &PendingCount) override {}

	virtual void NotifyStreamingLevelUnload(UObject* UnloadedLevel) override {}

	virtual bool PrintExportBatch() override { return true; }

	virtual void			LogDebugInfo(FOutputDevice & Ar) override {}
	virtual UObject *		GetObjectFromNetGUID(const FNetworkGUID& NetGUID, const bool bIgnoreMustBeMapped) override { return nullptr; }
	virtual FNetworkGUID	GetNetGUIDFromObject(const UObject* InObject) const override { return FNetworkGUID();  }
	virtual bool			IsGUIDBroken(const FNetworkGUID& NetGUID, const bool bMustBeRegistered) const override { return true; }

	/** Returns true if this guid is directly pending, or depends on another guid that is pending */
	virtual bool			IsGUIDPending(const FNetworkGUID& NetGUID) const { return true; }

	/** Set rather this actor is associated with a channel with queued bunches */
	virtual void			SetHasQueuedBunches(const FNetworkGUID& NetGUID, bool bHasQueuedBunches) {}

	virtual void Serialize(FArchive& Ar) override {}

protected:
	virtual UObject* ResolvePathAndAssignNetGUID(const FNetworkGUID& NetGUID, const FString& PathName) override { return nullptr; }
};
