// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3WebServer.h"

#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3World.h"

// Work around a conflict between a UI namespace defined by engine code and a typedef in OpenSSL
#define UI UI_ST
THIRD_PARTY_INCLUDES_START
#if PLATFORM_WINDOWS
#include "PreWindowsApi.h"
#endif
#include "libwebsockets.h"
THIRD_PARTY_INCLUDES_END
#undef UI

static void WebSocketLog(int Level, const char* Line)
{
	switch (Level)
	{
	case LLL_ERR:
		UE_LOG(P3WebSocketLog, Error, TEXT("%s"), ANSI_TO_TCHAR(Line));
		break;
	case LLL_WARN:
		UE_LOG(P3WebSocketLog, Warning, TEXT("%s"), ANSI_TO_TCHAR(Line));
		break;
	default:
		UE_LOG(P3WebSocketLog, Display, TEXT("%s"), ANSI_TO_TCHAR(Line));
	};
}

struct FP3PerSessionData
{
	FString Path;
	lws_token_indexes Method;
	TArray<uint8> ResponseBodyBuf;
};

static bool GetHttpMethod(lws* Wsi, lws_token_indexes& OutMethod)
{
	static const lws_token_indexes HttpMethods[] = {
		WSI_TOKEN_GET_URI,
		WSI_TOKEN_POST_URI,
		WSI_TOKEN_OPTIONS_URI,
		WSI_TOKEN_PUT_URI,
		WSI_TOKEN_PATCH_URI,
		WSI_TOKEN_DELETE_URI,
		WSI_TOKEN_CONNECT,
		WSI_TOKEN_HEAD_URI,
	};

	for (int32 Index = 0; Index < ARRAY_COUNT(HttpMethods); ++Index)
	{
		lws_token_indexes Method = HttpMethods[Index];
		if (lws_hdr_total_length(Wsi, Method))
		{
			OutMethod = Method;
			return true;
		}
	}
	return false;
}

static int WebSocketCallback(lws* Wsi, enum lws_callback_reasons Reason, void* User, void* In, size_t Len)
{
	struct lws_context* Context = lws_get_context(Wsi);
	UP3WebServer* Server = (UP3WebServer*)lws_context_user(Context);
	FP3PerSessionData* PerSessionData = (FP3PerSessionData*)User;
	uint8 Buf[LWS_PRE + 2048];
	uint8* Start = &Buf[LWS_PRE];
	uint8* Pos = Start;
	uint8* End = &Buf[sizeof(Buf) - 1];

	switch (Reason)
	{
	case LWS_CALLBACK_HTTP:
	{
		PerSessionData->Path = ANSI_TO_TCHAR((ANSICHAR*)In);
		if (!GetHttpMethod(Wsi, PerSessionData->Method))
		{
			P3JsonLogWithCategory(P3WebSocketLog, Warning, "LWS_CALLBACK_HTTP (invalid-method)",
				TEXT("Path"), *PerSessionData->Path);
			return 1;
		}

		P3JsonLogWithCategory(P3WebSocketLog, Display, "LWS_CALLBACK_HTTP",
			TEXT("Path"), *PerSessionData->Path,
			TEXT("Method"), PerSessionData->Method);

		int32 StatusCode = 0;
		FString ResponseBody;
		Server->OnRequest(*PerSessionData, StatusCode, ResponseBody);

		FTCHARToUTF8 UTF8Body(*ResponseBody);
		PerSessionData->ResponseBodyBuf.Append((uint8*)UTF8Body.Get(), UTF8Body.Length());

		if (lws_add_http_common_headers(Wsi, StatusCode, "application/json; charset=utf-8", UTF8Body.Length(), &Pos, End))
		{
			return 1;
		}

		if (lws_finalize_write_http_header(Wsi, Start, &Pos, End))
		{
			return 1;
		}

		if (PerSessionData->ResponseBodyBuf.Num() > 0)
		{
			lws_callback_on_writable(Wsi);
		}
		else
		{
			if (lws_http_transaction_completed(Wsi))
			{
				return 1;
			}
		}

		return 0;
	}
	case LWS_CALLBACK_HTTP_WRITEABLE:
	{
		P3JsonLogWithCategory(P3WebSocketLog, Display, "LWS_CALLBACK_HTTP_WRITEABLE", TEXT("Path"), *PerSessionData->Path);
		if (lws_write(Wsi, PerSessionData->ResponseBodyBuf.GetData(), StaticCast<SIZE_T>(PerSessionData->ResponseBodyBuf.Num()), LWS_WRITE_HTTP_FINAL))
		{
			return 1;
		}

		if (lws_http_transaction_completed(Wsi))
		{
			return 1;
		}

		return 0;
	}

	case LWS_CALLBACK_CLOSED_HTTP:
	{
		if (ensure(PerSessionData))
		{
			P3JsonLogWithCategory(P3WebSocketLog, Display, "LWS_CALLBACK_CLOSED_HTTP", TEXT("Path"), *PerSessionData->Path);
			PerSessionData->Path.Empty();
			PerSessionData->ResponseBodyBuf.Empty();
		}
		return 0;
	}
	}

	return lws_callback_http_dummy(Wsi, Reason, User, In, Len);
}

static struct lws_protocols Protocols[] = {
	{ "http", WebSocketCallback, sizeof(FP3PerSessionData), 0 },
	{ nullptr, nullptr, 0, 0 }
};

void UP3WebServer::Initialize(class UP3GameInstance* InGameInstance)
{
	GameInstance = InGameInstance;

	int32 Port = 0;
	FString PortStr;
	if (FParse::Value(FCommandLine::Get(), TEXT("-P3WebPort="), PortStr))
	{
		Port = FCString::Atoi(*PortStr);
	}
	if (Port <= 0)
	{
		P3JsonLogWithCategory(P3WebSocketLog, Warning, "Not start http server", TEXT("Port"), Port);
		return;
	}

	P3JsonLogWithCategory(P3WebSocketLog, Display, "Start http server", TEXT("Port"), Port);

	lws_set_log_level(LLL_ERR | LLL_WARN | LLL_NOTICE | LLL_DEBUG | LLL_INFO, WebSocketLog);

	struct lws_context_creation_info Info;
	FMemory::Memzero(Info);
	Info.port = Port;
	Info.protocols = Protocols;
	Info.options = LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;
	Info.user = this;

	Context = lws_create_context(&Info);
	ListenPort = Port;
}

void UP3WebServer::Shutdown()
{
	if (Context)
	{
		lws_context_destroy(Context);
		Context = nullptr;
	}

	GameInstance = nullptr;
}

void UP3WebServer::Tick(float DeltaTime)
{
	if (Context)
	{
		lws_service(Context, 0);
	}
}

void UP3WebServer::OnRequest(const FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody)
{
	if (Session.Path.StartsWith("/status"))
	{
		HandleStatus(Session, OutStatusCode, OutBody);
	}
	else if (Session.Path.StartsWith("/players"))
	{
		HandlePlayers(Session, OutStatusCode, OutBody);
	}
	else if (Session.Path.StartsWith("/crash"))
	{
		HandleCrash(Session, OutStatusCode, OutBody);
	}
	else if (Session.Path.StartsWith("/quit"))
	{
		HandleQuit(Session, OutStatusCode, OutBody);
	}
	else
	{
		OutStatusCode = 404;
		OutBody = "";
	}
}

void UP3WebServer::HandleStatus(const FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody)
{
	OutStatusCode = 200;

	if (!GameInstance)
	{
		OutBody = "{\"status\":\"no-game-instance\"}";
		return;
	}

	UP3World* P3World = GameInstance->GetP3World();
	if (!P3World)
	{
		OutBody = "{\"status\":\"no-p3-world\"}";
		return;
	}

	UP3ServerWorld* ServerWorld = P3World->GetServerWorld();
	if (!ServerWorld)
	{
		OutBody = "{\"status\":\"no-server-world\"}";
		return;
	}

	if (!ServerWorld->IsReady())
	{
		OutBody = "{\"status\":\"not-ready\"}";
		return;
	}

	OutBody = "{\"status\":\"ready\"}";
}

void UP3WebServer::HandlePlayers(const FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody)
{
	OutStatusCode = 200;

	if (!GameInstance)
	{
		OutBody = "{}";
		return;
	}

	UP3World* P3World = GameInstance->GetP3World();
	if (!P3World)
	{
		OutBody = "{}";
		return;
	}

	UP3ServerWorld* ServerWorld = P3World->GetServerWorld();
	if (!ServerWorld)
	{
		OutBody = "{}";
		return;
	}

	OutBody = ServerWorld->GetPlayersAsJson();
}

void UP3WebServer::HandleCrash(const FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody)
{
	if (Session.Method != WSI_TOKEN_POST_URI)
	{
		OutStatusCode = 404;
		OutBody = "";
		return;
	}

	if (!GameInstance)
	{
		OutStatusCode = 500;
		OutBody = "{}";
		return;
	}

	UWorld* World = GameInstance->GetWorld();
	if (!World)
	{
		OutStatusCode = 500;
		OutBody = "{}";
		return;
	}

	OutStatusCode = 200;
	OutBody = "{}";

#if !UE_BUILD_SHIPPING
	P3JsonLog(Error, "Crash in 5 seconds (by http)");

	FTimerHandle DummyHandle;
	World->GetTimerManager().SetTimer(DummyHandle, FTimerDelegate::CreateLambda([]()
	{
		uint32* Ptr = nullptr;
		*Ptr = 1;
	}), 5.0f, false);
#endif
}

void UP3WebServer::HandleQuit(const FP3PerSessionData& Session, int32& OutStatusCode, FString& OutBody)
{
	if (Session.Method != WSI_TOKEN_POST_URI)
	{
		OutStatusCode = 404;
		OutBody = "";
		return;
	}

	if (!GameInstance)
	{
		OutStatusCode = 500;
		OutBody = "{}";
		return;
	}

	UWorld* World = GameInstance->GetWorld();
	if (!World)
	{
		OutStatusCode = 500;
		OutBody = "{}";
		return;
	}

	OutStatusCode = 200;
	OutBody = "{}";

	P3JsonLog(Error, "Shutdown in 5 seconds (by http)");

	FTimerHandle DummyHandle;
	World->GetTimerManager().SetTimer(DummyHandle, FTimerDelegate::CreateLambda([]()
	{
		FPlatformMisc::RequestExit(false);
	}), 5.0f, false);
}
