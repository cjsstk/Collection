// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UDPMessageHandler.h"

#include "P3ActorChannel.h"
#include "P3Channel.h"
#include "P3Core.h"
#include "P3Log.h"
#include "P3NetConnection.h"
#include "P3UnrealUDPNet.h"

TArray<FString> FP3UDPMessageHandler::HandlerFuncNames;

DECLARE_CYCLE_STAT(TEXT("P3UDPNet_SendMessages"), STAT_P3UDPNet_SendMessages, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3UDPNet_HandleMessages"), STAT_P3UDPNet_HandleMessages, STATGROUP_P3);

void FP3UDPMessageHandler::AddHandlerFunctionName(const FString& FunctionName, bool bReliable, int32 BufferSize)
{
	if (!HandlerFuncNames.Contains(FunctionName))
	{
		/*
			Server -> Client

			Reliable:1 Client_HandleAckGoodMove
			Reliable:1 Client_HandleAdjustPosition
			Reliable:0 Client_HandleAnimalMovement
			Reliable:0 Client_HandleCharacterMovement
			Reliable:1 Client_HandleDead
			Reliable:1 Client_HandleExecuteCommand
			Reliable:1 Client_HandleFinishAction
			Reliable:1 Client_HandleForceFinishAction
			Reliable:1 Client_HandleHit
			Reliable:1 Client_HandleRevive
			Reliable:1 Client_HandleStartAction
			Reliable:1 Client_HandleStopAction
			Reliable:1 Client_HandleSyncActorMovement
			Reliable:0 Client_HandleSyncTimeOfDay
			Reliable:0 Client_HandleToastMessage
			Reliable:1 HandleDestroyActor
			Reliable:1 HandleSpawnActor
			Reliable:1 HandleSyncActorStore
			Reliable:1 HandleSyncActorTransform

			////////////////////////////////////////

			Client -> Server

			Reliable:1 HandleEnter
			Reliable:1 Server_HandleForceFinishCommand
			Reliable:0 Server_HandleMove
			Reliable:0 Server_HandleMoveDual
			Reliable:0 Server_HandleMoveOld
			Reliable:1 Server_HandleRequestCommand
			Reliable:1 Server_HandleStopCommand
		*/

		HandlerFuncNames.Add(FunctionName);

		UE_LOG(P3UDPNetLog, Log, TEXT("Reliable:%i Function:%s Size:%i"), bReliable, *FunctionName, BufferSize);
	}
}

bool FP3UDPMessageHandler::SendToActorChannel(UNetConnection* Connection, actorid ActorId, AActor* Actor, TArray<uint8>& Buffer,
	EP3NetComponentType ComponentType, const FName& HandlerFunctionName, bool bReliable)
{
	if (!ensure(UDPNet))
	{
		return false;
	}

	if (!Connection || !Connection->PackageMap)
	{
		return false;
	}

	if (Connection->State != USOCK_Open)
	{
		return false;
	}

	UP3ActorChannel* ActorChannel = nullptr;

	UP3NetConnection* P3Connection = UP3UnrealUDPNet::GetP3Connection(Connection);

	if (!ensure(P3Connection))
	{
		return false;
	}

	if (Actor)
	{
		ActorChannel = P3Connection->FindActorChannelRef(Actor);
	}
	else
	{
		UChannel* Channel = P3Connection->Channels[UP3UnrealUDPNet::BaseActorChannelIndex];
		if (ensure(Channel))
		{
			ActorChannel = UP3UnrealUDPNet::GetP3Channel<UP3ActorChannel>(Channel);
		}
	}

	FString FunctionName = HandlerFunctionName.ToString();

	if (!ensure(ActorChannel))
	{
		UE_LOG(P3UDPNetLog, Error, TEXT("ActorChannel is null - Func: %s"), *FunctionName);
		return false;
	}

	FP3UDPMessageHandler::AddHandlerFunctionName(FunctionName, bReliable, Buffer.Num());

	const int32 MaxBytes = Buffer.Num() + FunctionName.GetCharArray().Num() + 18; // ActorId(8) + EP3NetComponentType(2) + DataLen(4) + FunctionNameLen(4)

	const int32 MaxBits = (MaxBytes * 8) - 7;

	FOutBunch Bunch(Connection->PackageMap, MaxBits);

	UP3NetConnection::MakeBunch(Bunch, ActorChannel, bReliable);

	if (Bunch.IsError())
	{
		UE_LOG(P3UDPNetLog, Log, TEXT("failed to send bunch. Actor: %s Function: %s"), *Actor->GetName(), *FunctionName);
		return false;
	}

	Bunch << ActorId;
	Bunch << ComponentType;
	Bunch << FunctionName;
	Bunch << Buffer;

	if (UDPNet->IsServer() && !P3Connection->IsMessageQueueEmpty())
	{
		if (!P3Connection->QueueMessage(&Bunch, ActorChannel))
		{
			P3Connection->Close();
			return false;
		}

		return true;
	}

	FPacketIdRange PacketId;

	bool bSuccess = false;

	{
		SCOPE_CYCLE_COUNTER(STAT_P3UDPNet_SendMessages);
		bSuccess = ActorChannel->SendBunch(&Bunch, PacketId);
	}

	if (!bSuccess)
	{
		if (MaxBits == Bunch.GetNumBits())
		{
			UE_LOG(P3UDPNetLog, Log, TEXT("failed to send bunch. Reliable: %i Function: %s Bytes: %i(%i)"), bReliable, *FunctionName, MaxBytes, MaxBits);
		}
		else
		{
			UE_LOG(P3UDPNetLog, Log, TEXT("failed to send bunch. Reliable: %i Function: %s Bytes: %i(%i) BunchBytes: %i(%i)"), bReliable, *FunctionName, MaxBytes, MaxBits, Bunch.GetNumBytes(), Bunch.GetNumBits());
		}

		Connection->Close();
		return false;
	}

	if (PacketId.First == INDEX_NONE && PacketId.Last == INDEX_NONE)
	{
		if (UDPNet->IsServer() && !P3Connection->QueueMessage(&Bunch, ActorChannel))
		{
			P3Connection->Close();
			return false;
		}
	}
	else
	{
		UDPNet->StatSentBytes += Bunch.GetNumBytes();
		++UDPNet->StatSentMessages;
	}

	if (bReliable)
	{
		//Connection->FlushNet(true);
	}

	//UE_LOG(P3UDPNetLog, Log, TEXT("Send: Func: %s Size: %i Actor: %s"), *HandlerFunction, MaxBytes, Actor ? *Actor->GetName() : TEXT("None"));

	return bSuccess;
}

void FP3UDPMessageHandler::ReceivedBunch(UP3ActorChannel* ActorChannel, FInBunch& Bunch)
{
	if (!ensure(UDPNet))
	{
		return;
	}

	if (!ensure(ActorChannel))
	{
		return;
	}

	actorid ActorId;
	EP3NetComponentType ComponentType;

	Bunch << ActorId;
	Bunch << ComponentType;

	if (ActorChannel->GetActor() && ActorChannel->GetActor()->GetName() == "None")
	{
		ensure(0);
		return;
	}

	if (ComponentType != EP3NetComponentType::ActorChannel)
	{
		if (ensure(ActorChannel->Connection))
		{
			FString HandlerFunction;
			TArray<uint8> Buffer;

			Bunch << HandlerFunction;
			Bunch << Buffer;

			{
				SCOPE_CYCLE_COUNTER(STAT_P3UDPNet_HandleMessages);
				UDPNet->HandleUnrealRaw(ActorChannel->Connection, ActorId, ActorChannel->GetActor(), Buffer, ComponentType, HandlerFunction);
			}
		}
	}
	else
	{
		if (!UDPNet->IsServer())
		{
			TArray<uint8> SpawnData;
			Bunch << SpawnData;

			if (ActorId != INVALID_ACTORID)
			{
				ActorChannel->SetActorId(ActorId);

				UDPNet->Client_AddPendingActorChannel(ActorChannel);

				UDPNet->Client_SpawnActor(SpawnData);
			}
			else
			{
				check(ActorChannel->ChIndex == UP3UnrealUDPNet::BaseActorChannelIndex);
			}
		}
	}

	UDPNet->StatRecvBytes += Bunch.GetNumBytes();
	++UDPNet->StatRecvMessages;
}
