// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Network/Lib/P3NetProtocol.h"

class FP3ChatProtocol : public FP3NetProtocol
{
public:

enum class ECSPacketType : uint16
{
    None = 0,
    Create = 1,
    Join = 2,
    Leave = 3,
    Chat = 4,
    Max = 5
};

static const TCHAR* GetCSPacketTypeStr(ECSPacketType Type)
{
    switch (Type)
    {
    case ECSPacketType::None: return TEXT("None");
    case ECSPacketType::Create: return TEXT("Create");
    case ECSPacketType::Join: return TEXT("Join");
    case ECSPacketType::Leave: return TEXT("Leave");
    case ECSPacketType::Chat: return TEXT("Chat");
    case ECSPacketType::Max: return TEXT("Max");
    default: return TEXT("Unknown");
    }
}

enum class ESCPacketType : uint16
{
    None = 0,
    Proceed = 1,
    CreateReply = 2,
    JoinReply = 3,
    LeaveReply = 4,
    ChatReply = 5,
    Chat = 6,
    Max = 7
};

static const TCHAR* GetSCPacketTypeStr(ESCPacketType Type)
{
    switch (Type)
    {
    case ESCPacketType::None: return TEXT("None");
    case ESCPacketType::Proceed: return TEXT("Proceed");
    case ESCPacketType::CreateReply: return TEXT("CreateReply");
    case ESCPacketType::JoinReply: return TEXT("JoinReply");
    case ESCPacketType::LeaveReply: return TEXT("LeaveReply");
    case ESCPacketType::ChatReply: return TEXT("ChatReply");
    case ESCPacketType::Chat: return TEXT("Chat");
    case ESCPacketType::Max: return TEXT("Max");
    default: return TEXT("Unknown");
    }
}

enum class EChannelResult : uint8
{
    Ok = 1,
    NoChannel = 2,
    NotInChannel = 3,
    InternalError = 99,
};

static const TCHAR* GetChannelResultStr(EChannelResult Type)
{
    switch (Type)
    {
    case EChannelResult::Ok: return TEXT("Ok");
    case EChannelResult::NoChannel: return TEXT("NoChannel");
    case EChannelResult::NotInChannel: return TEXT("NotInChannel");
    case EChannelResult::InternalError: return TEXT("InternalError");
    default: return TEXT("Unknown");
    }
}


class FCSCreate : public FP3NetCSMessage
{
public:
    FString ChannelName;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ECSPacketType::Create);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackStringLE(Buf, InOutPos, ChannelName))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, ChannelName))
        {
            return false;
        }
        return true;
    }
};

class FCSJoin : public FP3NetCSMessage
{
public:
    FString ChannelName;
    FString UserName;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ECSPacketType::Join);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackStringLE(Buf, InOutPos, ChannelName))
        {
            return false;
        }
        if (!FP3Packer::PackStringLE(Buf, InOutPos, UserName))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, ChannelName))
        {
            return false;
        }
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, UserName))
        {
            return false;
        }
        return true;
    }
};

class FCSLeave : public FP3NetCSMessage
{
public:
    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ECSPacketType::Leave);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        return true;
    }
};

class FCSChat : public FP3NetCSMessage
{
public:
    uint64 ZoneChannelId;
    FString Msg;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ECSPacketType::Chat);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackUInt64LE(Buf, InOutPos, ZoneChannelId))
        {
            return false;
        }
        if (!FP3Packer::PackStringLE(Buf, InOutPos, Msg))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackUInt64LE(Buf, BufPos, ZoneChannelId))
        {
            return false;
        }
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, Msg))
        {
            return false;
        }
        return true;
    }
};


class FSCProceed : public FP3NetSCMessage
{
public:
    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ESCPacketType::Proceed);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        return true;
    }
};

class FSCCreateReply : public FP3NetSCMessage
{
public:
    FString ChannelName;
    EChannelResult Result;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ESCPacketType::CreateReply);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackStringLE(Buf, InOutPos, ChannelName))
        {
            return false;
        }
        if (!FP3Packer::PackUInt8LE(Buf, InOutPos, (uint8)Result))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, ChannelName))
        {
            return false;
        }
        if (!FP3Packer::UnpackUInt8LE(Buf, BufPos, (uint8&)Result))
        {
            return false;
        }
        return true;
    }
};

class FSCJoinReply : public FP3NetSCMessage
{
public:
    FString ChannelName;
    EChannelResult Result;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ESCPacketType::JoinReply);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackStringLE(Buf, InOutPos, ChannelName))
        {
            return false;
        }
        if (!FP3Packer::PackUInt8LE(Buf, InOutPos, (uint8)Result))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, ChannelName))
        {
            return false;
        }
        if (!FP3Packer::UnpackUInt8LE(Buf, BufPos, (uint8&)Result))
        {
            return false;
        }
        return true;
    }
};

class FSCLeaveReply : public FP3NetSCMessage
{
public:
    EChannelResult Result;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ESCPacketType::LeaveReply);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackUInt8LE(Buf, InOutPos, (uint8)Result))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackUInt8LE(Buf, BufPos, (uint8&)Result))
        {
            return false;
        }
        return true;
    }
};

class FSCChatReply : public FP3NetSCMessage
{
public:
    EChannelResult Result;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ESCPacketType::ChatReply);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackUInt8LE(Buf, InOutPos, (uint8)Result))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackUInt8LE(Buf, BufPos, (uint8&)Result))
        {
            return false;
        }
        return true;
    }
};

class FSCChat : public FP3NetSCMessage
{
public:
    FString UserName;
    uint64 ZoneChannelId;
    FString Msg;

    virtual uint16 GetType() const override
    {
        return StaticCast<uint16>(ESCPacketType::Chat);
    }

    virtual bool Pack(TArray<uint8>& Buf, int32& InOutPos) const override
    {
        if (!FP3Packer::PackStringLE(Buf, InOutPos, UserName))
        {
            return false;
        }
        if (!FP3Packer::PackUInt64LE(Buf, InOutPos, ZoneChannelId))
        {
            return false;
        }
        if (!FP3Packer::PackStringLE(Buf, InOutPos, Msg))
        {
            return false;
        }
        return true;
    }

    virtual bool Unpack(const TArray<uint8>& Buf) override
    {
        int32 BufPos = 0;
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, UserName))
        {
            return false;
        }
        if (!FP3Packer::UnpackUInt64LE(Buf, BufPos, ZoneChannelId))
        {
            return false;
        }
        if (!FP3Packer::UnpackStringLE(Buf, BufPos, Msg))
        {
            return false;
        }
        return true;
    }
};

FP3NetMessage* CreateSCMessage(uint16 Type) const
{
    switch (StaticCast<ESCPacketType>(Type))
    {
    case ESCPacketType::Proceed: return new FSCProceed();
    case ESCPacketType::CreateReply: return new FSCCreateReply();
    case ESCPacketType::JoinReply: return new FSCJoinReply();
    case ESCPacketType::LeaveReply: return new FSCLeaveReply();
    case ESCPacketType::ChatReply: return new FSCChatReply();
    case ESCPacketType::Chat: return new FSCChat();
    }
    return nullptr;
}
}; // FP3ChatProtocol

class IP3ChatSCPacketHandler
{
public:
    virtual ~IP3ChatSCPacketHandler() {}
    virtual void HandleProceed(const FP3ChatProtocol::FSCProceed& Message) = 0;
    virtual void HandleCreateReply(const FP3ChatProtocol::FSCCreateReply& Message) = 0;
    virtual void HandleJoinReply(const FP3ChatProtocol::FSCJoinReply& Message) = 0;
    virtual void HandleLeaveReply(const FP3ChatProtocol::FSCLeaveReply& Message) = 0;
    virtual void HandleChatReply(const FP3ChatProtocol::FSCChatReply& Message) = 0;
    virtual void HandleChat(const FP3ChatProtocol::FSCChat& Message) = 0;
};

inline bool P3ChatSCPacketDispatch(IP3ChatSCPacketHandler* Handler, TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> Message)
{
    switch (StaticCast<FP3ChatProtocol::ESCPacketType>(Message->GetType()))
    {
    case FP3ChatProtocol::ESCPacketType::Proceed:
        Handler->HandleProceed(StaticCastSharedRef<const FP3ChatProtocol::FSCProceed>(Message).Get());
        return true;

    case FP3ChatProtocol::ESCPacketType::CreateReply:
        Handler->HandleCreateReply(StaticCastSharedRef<const FP3ChatProtocol::FSCCreateReply>(Message).Get());
        return true;

    case FP3ChatProtocol::ESCPacketType::JoinReply:
        Handler->HandleJoinReply(StaticCastSharedRef<const FP3ChatProtocol::FSCJoinReply>(Message).Get());
        return true;

    case FP3ChatProtocol::ESCPacketType::LeaveReply:
        Handler->HandleLeaveReply(StaticCastSharedRef<const FP3ChatProtocol::FSCLeaveReply>(Message).Get());
        return true;

    case FP3ChatProtocol::ESCPacketType::ChatReply:
        Handler->HandleChatReply(StaticCastSharedRef<const FP3ChatProtocol::FSCChatReply>(Message).Get());
        return true;

    case FP3ChatProtocol::ESCPacketType::Chat:
        Handler->HandleChat(StaticCastSharedRef<const FP3ChatProtocol::FSCChat>(Message).Get());
        return true;

    }
    return false;
}
