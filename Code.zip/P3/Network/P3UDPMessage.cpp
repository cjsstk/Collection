// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3UDPMessage.h"

#include "CoreNet.h"

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessageClose
FP3UDPMessageClose::FP3UDPMessageClose()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessageClose::GetMaxBits() const
{
	return 1 << 3; // 1 = MessageType(1)
}

void FP3UDPMessageClose::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
}

void FP3UDPMessageClose::Deserialize(FNetBitReader& Reader)
{
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessageHello
FP3UDPMessageHello::FP3UDPMessageHello()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessageHello::GetMaxBits() const
{
	return (PlayerId.GetCharArray().Num() + 6) << 3; // 6 = MessageType(1) + IsLittleEndian(1) + PlayerIdLen(4)
}

void FP3UDPMessageHello::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
	Writer << IsLittleEndian;
	Writer << PlayerId;
}

void FP3UDPMessageHello::Deserialize(FNetBitReader& Reader)
{
	Reader << IsLittleEndian;
	Reader << PlayerId;
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessageWelcome
FP3UDPMessageWelcome::FP3UDPMessageWelcome()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessageWelcome::GetMaxBits() const
{
	return 1 << 3; // 1 = MessageType(1)
}

void FP3UDPMessageWelcome::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
}

void FP3UDPMessageWelcome::Deserialize(FNetBitReader& Reader)
{
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessagePing
FP3UDPMessagePing::FP3UDPMessagePing()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessagePing::GetMaxBits() const
{
	return 9 << 3; // 9 = MessageType(1) + PingId(4) + PingTimeMsec(4)
}

void FP3UDPMessagePing::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
	Writer << PingId;
	Writer << PingTimeMsec;
}

void FP3UDPMessagePing::Deserialize(FNetBitReader& Reader)
{
	Reader << PingId;
	Reader << PingTimeMsec;
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessagePong
FP3UDPMessagePong::FP3UDPMessagePong()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessagePong::GetMaxBits() const
{
	return 9 << 3; // 9 = MessageType(1) + PingId(4) + FrameTimeMsec(4)
}

void FP3UDPMessagePong::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
	Writer << PingId;
	Writer << FrameTimeMsec;
}

void FP3UDPMessagePong::Deserialize(FNetBitReader& Reader)
{
	Reader << PingId;
	Reader << FrameTimeMsec;
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessageConsoleCommand
FP3UDPMessageConsoleCommand::FP3UDPMessageConsoleCommand()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessageConsoleCommand::GetMaxBits() const
{
	return (Command.GetCharArray().Num() + 5) << 3; // 5 = MessageType(1) + CommandLen(4)
}

void FP3UDPMessageConsoleCommand::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
	Writer << Command;
}

void FP3UDPMessageConsoleCommand::Deserialize(FNetBitReader& Reader)
{
	Reader << Command;
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessageUnrealRaw
FP3UDPMessageUnrealRaw::FP3UDPMessageUnrealRaw()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessageUnrealRaw::GetMaxBits() const
{
	return (Buffer.Num() + FunctionName.GetCharArray().Num() + 19) << 3; // 19 = MessageType(1) + ActorId(8) + EP3NetComponentType(2) + DataLen(4) + FunctionNameLen(4)
}

void FP3UDPMessageUnrealRaw::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
	Writer << ActorId;
	Writer << ComponentType;
	Writer << FunctionName;
	Writer << Buffer;
}

void FP3UDPMessageUnrealRaw::Deserialize(FNetBitReader& Reader)
{
	Reader << ActorId;
	Reader << ComponentType;
	Reader << FunctionName;
	Reader << Buffer;
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessageWorld
FP3UDPMessageWorld::FP3UDPMessageWorld()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessageWorld::GetMaxBits() const
{
	return (Buffer.Num() + 1) << 3; // 3 = MessageType(1)
}

void FP3UDPMessageWorld::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
	Writer << Buffer;
}

void FP3UDPMessageWorld::Deserialize(FNetBitReader& Reader)
{
	Reader << Buffer;
}

///////////////////////////////////////////////////////////////////////////
// FP3UDPMessageZoneChange
FP3UDPMessageZoneChange::FP3UDPMessageZoneChange()
	: FP3UDPMessage(GetType())
{
}

int32 FP3UDPMessageZoneChange::GetMaxBits() const
{
	return 1 << 3; // 2 = MessageType(1)
}

void FP3UDPMessageZoneChange::Serialize(FNetBitWriter& Writer)
{
	ensure(Type == GetType());

	Writer << Type;
}

void FP3UDPMessageZoneChange::Deserialize(FNetBitReader& Reader)
{
}
