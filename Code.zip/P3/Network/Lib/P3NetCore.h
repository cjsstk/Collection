// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "P3Core.h"
#include "P3NetCore.generated.h"

// To disable protocol buffer warning, remove this after replace protocol buf with ours
#pragma warning (disable : 4946)


static const int32 P3NET_PB_PACKET_HEADER_SIZE = 10;
static const int32 P3NET_EX_PACKET_HEADER_SIZE = 4;
static const int32 P3NET_MAX_MESSAGE_SIZE = 9182;

P3DefineId(P3NetConnId)
const static P3NetConnId INVALID_NETCONNID = P3NetConnId(0);

enum class EP3NetConnStatus
{
	Closed,
	Connecting,
	Connected,
	Closing,
};

enum class EP3NetProtocol : uint8
{
	None,
	TCP,
	UnrealUDP,
	ENetUDP,
};

struct FP3NetStat
{
	int32 SentBytesPerSecond = 0;
	int32 RecvBytesPerSecond = 0;
	int32 SentMessagesPerSecond = 0;
	int32 RecvMessagesPerSecond = 0;
	int32 StatSendFailsPerSecond = 0;
	int32 StatMaxSendBuffer = 0;
};

struct FP3NetConnInfo
{
	P3NetConnId TCPConnId = INVALID_NETCONNID;
	P3NetConnId UDPConnId = INVALID_NETCONNID;
};

USTRUCT()
struct FP3ClientToDediHandlerParams
{
	GENERATED_BODY()

	FP3NetConnInfo NetConnInfo;
	TArray<uint8> Buffer;
};

USTRUCT()
struct FP3DediToClientHandlerParams
{
	GENERATED_BODY()

	FP3NetConnInfo NetConnInfo;
	TArray<uint8> Buffer;
	AActor* Actor;
};

struct FP3NetUtil : FNoncopyable
{
	static bool IsUDPConnection(const FP3NetConnInfo& NetConnInfo);
	static bool IsTCPConnection(const FP3NetConnInfo& NetConnInfo);
	static bool IsNetConnValid(const FP3NetConnInfo& NetConnInfo);

private:
	FP3NetUtil() = delete;
};

struct FP3PingTime
{
	/** Last ping sent time */
	FDateTime LastPingSentTime = FDateTime(0);
	
	/** Last ping acked time */
	FDateTime LastPingUpdatedTime = FDateTime(0);
	
	/** Last acked ping time */
	int32 PingTimeMsec = 0;

	// 실제 네트워크상의 메시지 왕복 시간
	int32 RoundTripTimeMsec = 0;
	
	/** Server frame time from last ping */
	float ServerFrameTimeMsec = 0.0f;
	
	/** Ping sent sequence id, to recover from packet loss */
	uint32 PingId = 0;
};
