// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3NetThread.h"
#include "P3Net.generated.h"

class IP3BaseNet
{
public:
	virtual ~IP3BaseNet() {}
	virtual void HandleConnectEvent(const FP3NetConnectEvent& Event) = 0;
	virtual void HandleListenEvent(const FP3NetListenEvent& Event) = 0;
	virtual void HandleAcceptEvent(const FP3NetAcceptEvent& Event) = 0;
	virtual void HandleCloseEvent(const FP3NetCloseEvent& Event) = 0;
	virtual void HandleRecvPbEvent(const FP3NetRecvPbEvent& Event) = 0;
	virtual void HandleRecvExEvent(const FP3NetRecvExEvent& Event) = 0;
};

UCLASS()
class UP3Net : public UObject
{
	GENERATED_BODY()

public:
	UP3Net();

	void Initialize();
	void Shutdown();
	void Tick(float DeltaTime);

	P3NetConnId Listen(IP3BaseNet* Net, const FString& ConnName, int32 Port, int32 MaxBacklog, const TDescMap& DescMap, float RetryIntervalSeconds, int32 MaxSocketSendPerMessage);
	P3NetConnId ConnectPb(IP3BaseNet* Net, const FP3NetConnectParams& Params, const TDescMap& DescMap);
	P3NetConnId ConnectEx(IP3BaseNet* Net, const FP3NetConnectParams& Params, TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol);
	void SendPb(P3NetConnId ConnId, uint16 MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);
	void SendEx(P3NetConnId ConnId, TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> Message);
	void Close(P3NetConnId ConnId);

	FP3NetStat GetAvgConnStat() const;

private:
	// Common handlers
	void HandleConnectEvent(IP3BaseNet& Net, const FP3NetConnectEvent& Event);
	void HandleListenEvent(IP3BaseNet& Net, const FP3NetListenEvent& Event);
	void HandleAcceptEvent(IP3BaseNet& Net, const FP3NetAcceptEvent& Event);
	void HandleCloseEvent(IP3BaseNet& Net, const FP3NetCloseEvent& Event);
	void HandleRecvPbEvent(IP3BaseNet& Net, const FP3NetRecvPbEvent& Event);
	void HandleRecvExEvent(IP3BaseNet& Net, const FP3NetRecvExEvent& Event);

	class FP3NetThread* Thread = nullptr;

	TMap<P3NetConnId, IP3BaseNet*> ConnNetMap;
};
