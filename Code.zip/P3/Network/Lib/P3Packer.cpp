// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Packer.h"
#include "P3Test.h"

#if P3_BUILD_WITH_TEST

#include "AutomationTest.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3PackerBigEndianTest, "P3.Packer.BigEndian", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3PackerBigEndianTest::RunTest(const FString& Parameters)
{
	uint8 Buf[256];
	int32 Pos = 0;

	FP3Packer::PackUInt32BE(Buf, Pos, 0xDEADBEEF);
	P3_ASSERT_EQUAL(Pos, 4);
	P3_ASSERT_EQUAL(Buf[Pos - 4], 0xDE);
	P3_ASSERT_EQUAL(Buf[Pos - 3], 0xAD);
	P3_ASSERT_EQUAL(Buf[Pos - 2], 0xBE);
	P3_ASSERT_EQUAL(Buf[Pos - 1], 0xEF);

	FP3Packer::PackUInt16BE(Buf, Pos, 0xCAFE);
	P3_ASSERT_EQUAL(Pos, 6);
	P3_ASSERT_EQUAL(Buf[Pos - 2], 0xCA);
	P3_ASSERT_EQUAL(Buf[Pos - 1], 0xFE);

	FP3Packer::PackInt32BE(Buf, Pos, 0x1A2B3C4D);
	P3_ASSERT_EQUAL(Pos, 10);
	P3_ASSERT_EQUAL(Buf[Pos - 4], 0x1A);
	P3_ASSERT_EQUAL(Buf[Pos - 3], 0x2B);
	P3_ASSERT_EQUAL(Buf[Pos - 2], 0x3C);
	P3_ASSERT_EQUAL(Buf[Pos - 1], 0x4D);

	Pos = 0;

	P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32BE(Buf, Pos), 0xDEADBEEF);
	P3_ASSERT_EQUAL(Pos, 4);
	P3_ASSERT_EQUAL(FP3Packer::UnpackUInt16BE(Buf, Pos), 0xCAFE);
	P3_ASSERT_EQUAL(Pos, 6);
	P3_ASSERT_EQUAL(FP3Packer::UnpackInt32BE(Buf, Pos), 0x1A2B3C4D);
	P3_ASSERT_EQUAL(Pos, 10);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3PackerLittleEndianTest, "P3.Packer.LittleEndian", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3PackerLittleEndianTest::RunTest(const FString& Parameters)
{
	TArray<uint8> Buf;
	int32 Pos = 0;

	// Test not enough buffer
	P3_ASSERT_EQUAL(FP3Packer::PackUInt32LE(Buf, Pos, 0xDEADBEEF), false);

	// Test not enough buffer (1 byte)
	Buf.SetNumUninitialized(3);
	P3_ASSERT_EQUAL(FP3Packer::PackUInt32LE(Buf, Pos, 0xDEADBEEF), false);

	// Test PackUInt32LE
	Buf.SetNumUninitialized(4);
	P3_ASSERT_EQUAL(FP3Packer::PackUInt32LE(Buf, Pos, 0xDEADBEEF), true);
	P3_ASSERT_EQUAL(Pos, 4);
	P3_ASSERT_EQUAL(Buf[Pos - 4], 0xEF);
	P3_ASSERT_EQUAL(Buf[Pos - 3], 0xBE);
	P3_ASSERT_EQUAL(Buf[Pos - 2], 0xAD);
	P3_ASSERT_EQUAL(Buf[Pos - 1], 0xDE);

	// Test not enough buffer
	P3_ASSERT_EQUAL(FP3Packer::PackUInt16LE(Buf, Pos, 0xCAFE), false);

	// Test PackUInt16LE
	Buf.SetNumUninitialized(6);
	P3_ASSERT_EQUAL(FP3Packer::PackUInt16LE(Buf, Pos, 0xCAFE), true);
	P3_ASSERT_EQUAL(Pos, 6);
	P3_ASSERT_EQUAL(Buf[Pos - 2], 0xFE);
	P3_ASSERT_EQUAL(Buf[Pos - 1], 0xCA);

	// Test PackUInt64LE
	Buf.SetNumUninitialized(14);
	P3_ASSERT_EQUAL(FP3Packer::PackUInt64LE(Buf, Pos, 0xFEEDFACECAFEBEEF), true);
	P3_ASSERT_EQUAL(Pos, 14);
	P3_ASSERT_EQUAL(Buf[Pos - 8], 0xEF);
	P3_ASSERT_EQUAL(Buf[Pos - 7], 0xBE);
	P3_ASSERT_EQUAL(Buf[Pos - 6], 0xFE);
	P3_ASSERT_EQUAL(Buf[Pos - 5], 0xCA);
	P3_ASSERT_EQUAL(Buf[Pos - 4], 0xCE);
	P3_ASSERT_EQUAL(Buf[Pos - 3], 0xFA);
	P3_ASSERT_EQUAL(Buf[Pos - 2], 0xED);
	P3_ASSERT_EQUAL(Buf[Pos - 1], 0xFE);

	// Test PackInt32LE
	Buf.SetNumUninitialized(18);
	P3_ASSERT_EQUAL(FP3Packer::PackInt32LE(Buf, Pos, 0x1A2B3C4D), true);
	P3_ASSERT_EQUAL(Pos, 18);
	P3_ASSERT_EQUAL(Buf[Pos - 4], 0x4D);
	P3_ASSERT_EQUAL(Buf[Pos - 3], 0x3C);
	P3_ASSERT_EQUAL(Buf[Pos - 2], 0x2B);
	P3_ASSERT_EQUAL(Buf[Pos - 1], 0x1A);

	Pos = 0;

	// Test UnpackUInt32LE
	uint32 Value32 = 0;
	P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32LE(Buf, Pos, Value32), true);
	P3_ASSERT_EQUAL(Value32, 0xDEADBEEF);
	P3_ASSERT_EQUAL(Pos, 4);

	// Test UnpackUInt16LE
	uint16 Value16 = 0;
	P3_ASSERT_EQUAL(FP3Packer::UnpackUInt16LE(Buf, Pos, Value16), true);
	P3_ASSERT_EQUAL(Value16, 0xCAFE);
	P3_ASSERT_EQUAL(Pos, 6);

	// Test UnpackUInt64LE
	uint64 Value64 = 0;
	P3_ASSERT_EQUAL(FP3Packer::UnpackUInt64LE(Buf, Pos, Value64), true);
	P3_ASSERT_EQUAL(Value64, 0xFEEDFACECAFEBEEF);
	P3_ASSERT_EQUAL(Pos, 14);

	// Test UnpackInt32LE
	int32 SignedValue32 = 0;
	P3_ASSERT_EQUAL(FP3Packer::UnpackInt32LE(Buf, Pos, SignedValue32), true);
	P3_ASSERT_EQUAL(SignedValue32, 0x1A2B3C4D);
	P3_ASSERT_EQUAL(Pos, 18);

	// Test not enough buffer (1 byte)
	Pos = 0;
	Buf.SetNumUninitialized(1);
	P3_ASSERT_EQUAL(FP3Packer::UnpackUInt16LE(Buf, Pos, Value16), false);

	// Test PackStringLE
	Pos = 0;
	Buf.SetNumUninitialized(8);
	FString ValueStr = "String";
	P3_ASSERT_EQUAL(FP3Packer::PackStringLE(Buf, Pos, ValueStr), true);
	P3_ASSERT_EQUAL(Pos, 8);
	P3_ASSERT_EQUAL(Buf[Pos - 8], 0x06); // String Length
	P3_ASSERT_EQUAL(Buf[Pos - 7], 0x00); // String Length
	P3_ASSERT_EQUAL(Buf[Pos - 6], 'S');
	P3_ASSERT_EQUAL(Buf[Pos - 5], 't');
	P3_ASSERT_EQUAL(Buf[Pos - 4], 'r');
	P3_ASSERT_EQUAL(Buf[Pos - 3], 'i');
	P3_ASSERT_EQUAL(Buf[Pos - 2], 'n');
	P3_ASSERT_EQUAL(Buf[Pos - 1], 'g');

	// Test UnpackStringLE
	Pos = 0;
	ValueStr = "";
	P3_ASSERT_EQUAL(FP3Packer::UnpackStringLE(Buf, Pos, ValueStr), true);
	P3_ASSERT_EQUAL(Pos, 8);
	P3_ASSERT_EQUAL_STR(ValueStr, "String");

	// Test not enough buffer (1 byte)
	Pos = 0;
	Buf.SetNumUninitialized(7);
	ValueStr = "";
	P3_ASSERT_EQUAL(FP3Packer::UnpackStringLE(Buf, Pos, ValueStr), false);
	P3_ASSERT_EQUAL(Pos, 0);

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3PackerListTest, "P3.Packer.List", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3PackerListTest::RunTest(const FString& Parameters)
{
	class FListItem
	{
	public:
		uint64 Id;
		FString Name;

		bool Pack(TArray<uint8>& Buf, int32& InOutPos) const
		{
			if (!FP3Packer::PackUInt64LE(Buf, InOutPos, Id))
			{
				return false;
			}
			if (!FP3Packer::PackStringLE(Buf, InOutPos, Name))
			{
				return false;
			}
			return true;
		}

		bool Unpack(const TArray<uint8>& Buf, int32& Pos)
		{
			if (!FP3Packer::UnpackUInt64LE(Buf, Pos, Id))
			{
				return false;
			}
			if (!FP3Packer::UnpackStringLE(Buf, Pos, Name))
			{
				return false;
			}
			return true;
		}
	};

	TArray<uint8> Buf;
	int32 Pos = 0;

	// Pack one byte
	Buf.SetNumUninitialized(1);
	P3_ASSERT_EQUAL(FP3Packer::PackUInt8LE(Buf, Pos, 0xCA), true);
	P3_ASSERT_EQUAL(Pos, 1);

	// Generate List
	TArray<FListItem> List;        // 33 = 2 + 16 + 15
	FListItem Item;
	Item.Id = 101;                 // 8 bytes
	Item.Name = TEXT("schumi");    // 8 = 2 + 6 bytes
	List.Add(Item);
	Item.Id = 103;                 // 8 bytes
	Item.Name = TEXT("essem");     // 7 = 2 + 5 bytes
	List.Add(Item);

	// Pack list
	Buf.SetNumUninitialized(1 + 33);
	P3_ASSERT_EQUAL(FP3Packer::PackList(Buf, Pos, List), true);
	P3_ASSERT_EQUAL(Pos, 1 + 33);

	// Reset position
	Pos = 0;

	// Unpack one byte
	uint8 Value8 = 0;
	P3_ASSERT_EQUAL(FP3Packer::UnpackUInt8LE(Buf, Pos, Value8), true);
	P3_ASSERT_EQUAL(Pos, 1);
	P3_ASSERT_EQUAL(Value8, 0xCA);

	// Unpack List
	TArray<FListItem> OutList;
	P3_ASSERT_EQUAL(FP3Packer::UnpackList(Buf, Pos, OutList), true);
	P3_ASSERT_EQUAL(Pos, 1 + 33);
	P3_ASSERT_EQUAL(OutList.Num(), 2);
	P3_ASSERT_EQUAL(OutList[0].Id, 101);
	P3_ASSERT_EQUAL_STR(OutList[0].Name, "schumi");
	P3_ASSERT_EQUAL(OutList[1].Id, 103);
	P3_ASSERT_EQUAL_STR(OutList[1].Name, "essem");

	return true;
}

#endif // UE_BUILD_SHIPPING
