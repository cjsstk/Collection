// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Net.h"
#include "P3Log.h"
#include "P3GameInstance.h"
#include "P3World.h"
#include "Misc/CommandLine.h"

//////////////////////////////////////////////////////////////////////////
// UP3Net
//////////////////////////////////////////////////////////////////////////

UP3Net::UP3Net()
{
}

void UP3Net::Initialize()
{
	P3JsonNetLog(Display, "Initialize P3Net");

	GOOGLE_PROTOBUF_VERIFY_VERSION;

	ensure(!Thread);
	Thread = new FP3NetThread(TEXT("P3NetThread"));
}

void UP3Net::Shutdown()
{
	P3JsonNetLog(Display, "Shutdown P3Net");

	if (ensure(Thread))
	{
		Thread->EnsureCompletion();
		delete Thread;
		Thread = nullptr;
	}
}

void UP3Net::Tick(float DeltaTime)
{
	check(Thread);

	TArray<TSharedRef<const FP3NetEvent, ESPMode::ThreadSafe>> Events = Thread->FetchEvents();
	for (TSharedRef<const FP3NetEvent, ESPMode::ThreadSafe> Event : Events)
	{
		IP3BaseNet** NetPtr = ConnNetMap.Find(Event->ConnId);
		if (!NetPtr || !*NetPtr)
		{
			P3JsonNetLog(Error, "Invalid conn id", TEXT("ConnId"), Event->ConnId.X);
			continue;
		}

		switch (Event->GetType())
		{
		case EP3NetEventType::Connect:
			HandleConnectEvent(**NetPtr, *Event->SafeCastToConnectEvent());
			break;

		case EP3NetEventType::Listen:
			HandleListenEvent(**NetPtr, *Event->SafeCastToListenEvent());
			break;

		case EP3NetEventType::Accept:
			HandleAcceptEvent(**NetPtr, *Event->SafeCastToAcceptEvent());
			break;

		case EP3NetEventType::Close:
			HandleCloseEvent(**NetPtr, *Event->SafeCastToCloseEvent());
			break;

		case EP3NetEventType::RecvPb:
			HandleRecvPbEvent(**NetPtr, *Event->SafeCastToRecvPbEvent());
			break;

		case EP3NetEventType::RecvEx:
			HandleRecvExEvent(**NetPtr, *Event->SafeCastToRecvExEvent());
			break;

		default:
			P3JsonNetLog(Error, "Unknown network event type",
				TEXT("Type"), StaticCast<int>(Event->GetType()));
		}
	}
}

void UP3Net::HandleConnectEvent(IP3BaseNet& Net, const FP3NetConnectEvent& Event)
{
	P3JsonNetLog(Verbose, "Handle ConnectEvent", TEXT("ConnId"), Event.ConnId.X);

	if (!Event.bSuccess)
	{
		ConnNetMap.Remove(Event.ConnId);
	}

	Net.HandleConnectEvent(Event);
}

void UP3Net::HandleListenEvent(IP3BaseNet& Net, const FP3NetListenEvent& Event)
{
	P3JsonNetLog(Verbose, "Handle ListenEvent", TEXT("ConnId"), Event.ConnId.X);

	if (!Event.bSuccess)
	{
		ConnNetMap.Remove(Event.ConnId);
	}

	Net.HandleListenEvent(Event);
}

void UP3Net::HandleAcceptEvent(IP3BaseNet& Net, const FP3NetAcceptEvent& Event)
{
	P3JsonNetLog(Verbose, "Handle AcceptEvent", TEXT("ConnId"), Event.ConnId.X);

	ConnNetMap.Add(Event.AcceptedConnId, &Net);
	Net.HandleAcceptEvent(Event);
}

void UP3Net::HandleCloseEvent(IP3BaseNet& Net, const FP3NetCloseEvent& Event)
{
	P3JsonNetLog(Verbose, "Handle CloseEvent", TEXT("ConnId"), Event.ConnId.X);

	ConnNetMap.Remove(Event.ConnId);
	Net.HandleCloseEvent(Event);
}

void UP3Net::HandleRecvPbEvent(IP3BaseNet& Net, const FP3NetRecvPbEvent& Event)
{
	P3JsonNetLog(Verbose, "Handle RecvEvent", TEXT("ConnId"), Event.ConnId.X);

	Net.HandleRecvPbEvent(Event);
}

void UP3Net::HandleRecvExEvent(IP3BaseNet& Net, const FP3NetRecvExEvent& Event)
{
	P3JsonNetLog(Verbose, "Handle RecvEvent", TEXT("ConnId"), Event.ConnId.X);

	Net.HandleRecvExEvent(Event);
}

P3NetConnId UP3Net::Listen(IP3BaseNet* Net, const FString& ConnName, int32 Port, int32 MaxBacklog, const TDescMap& DescMap, float RetryIntervalSeconds, int32 MaxSocketSendPerMessage)
{
	check(Thread);

	P3JsonNetLog(Display, "Listen", TEXT("Port"), Port);

	P3NetConnId ConnId = Thread->CreateListener(ConnName, TEXT("0.0.0.0"), Port, MaxBacklog, DescMap, RetryIntervalSeconds, MaxSocketSendPerMessage, true);

	ConnNetMap.Add(ConnId, Net);

	return ConnId;
}

P3NetConnId UP3Net::ConnectPb(IP3BaseNet* Net, const FP3NetConnectParams& Params, const TDescMap& DescMap)
{
	check(Thread);

	P3JsonNetLog(Display, "Connect", TEXT("Host"), Params.Host, TEXT("Port"), Params.Port);

	const P3NetConnId ConnId = Thread->CreateConnPb(Params, DescMap);
	ConnNetMap.Add(ConnId, Net);

	return ConnId;
}

P3NetConnId UP3Net::ConnectEx(IP3BaseNet* Net, const FP3NetConnectParams& Params, TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol)
{
	check(Thread);

	P3JsonNetLog(Display, "Connect", TEXT("Host"), Params.Host, TEXT("Port"), Params.Port);

	const P3NetConnId ConnId = Thread->CreateConnEx(Params, Protocol);
	ConnNetMap.Add(ConnId, Net);

	return ConnId;
}

void UP3Net::SendPb(P3NetConnId ConnId, uint16 MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	check(Thread);

	Thread->SendPb(ConnId, MessageType, Message);
}

void UP3Net::SendEx(P3NetConnId ConnId, TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> Message)
{
	check(Thread);

	Thread->SendEx(ConnId, Message);
}

void UP3Net::Close(P3NetConnId ConnId)
{
	check(Thread);

	Thread->CloseConn(ConnId);
}

FP3NetStat UP3Net::GetAvgConnStat() const
{
	check(Thread);

	FP3NetStat Stat;
	Stat.SentBytesPerSecond = Thread->GetAvgSentBytesPerSecond();
	Stat.RecvBytesPerSecond = Thread->GetAvgRecvBytesPerSecond();
	Stat.SentMessagesPerSecond = Thread->GetAvgSentMessagesPerSecond();
	Stat.RecvMessagesPerSecond = Thread->GetAvgRecvMessagesPerSecond();

	return Stat;
}
