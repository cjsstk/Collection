// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Network/Lib/P3NetConnPb.h"
#include "Network/Lib/P3NetConnEx.h"
#include "HAL/Runnable.h"
#include "HAL/ThreadSafeBool.h"

//////////////////////////////////////////////////////////////////////////
// Params
//////////////////////////////////////////////////////////////////////////

struct FP3NetConnectParams
{
	FString Name;
	FString Host;
	int32 Port = 0;
	float InitialDelaySeconds = 0.0f;
	int32 MaxRetryCount = 0;
	float RetryIntervalSeconds = 0.0f;
	int32 MaxSocketSendPerMessage = 0;
	bool bEnableStat = false;
};

//////////////////////////////////////////////////////////////////////////
// FP3NetEvent
//////////////////////////////////////////////////////////////////////////

enum class EP3NetEventType
{
	Connect,
	Listen,
	Accept,
	Close,
	RecvPb,
	RecvEx,
};

struct FP3NetEvent
{
	FP3NetEvent() { CreationTimeSeconds = FPlatformTime::Seconds(); }
	virtual ~FP3NetEvent() {}

	virtual EP3NetEventType GetType() const = 0;
	virtual const struct FP3NetConnectEvent* SafeCastToConnectEvent() const { return nullptr; }
	virtual const struct FP3NetListenEvent* SafeCastToListenEvent() const { return nullptr; }
	virtual const struct FP3NetAcceptEvent* SafeCastToAcceptEvent() const { return nullptr; }
	virtual const struct FP3NetCloseEvent* SafeCastToCloseEvent() const { return nullptr; }
	virtual const struct FP3NetRecvPbEvent* SafeCastToRecvPbEvent() const { return nullptr; }
	virtual const struct FP3NetRecvExEvent* SafeCastToRecvExEvent() const { return nullptr; }

	P3NetConnId ConnId = INVALID_NETCONNID;
	double CreationTimeSeconds = 0.0;
};

struct FP3NetConnectEvent : public FP3NetEvent
{
	virtual EP3NetEventType GetType() const override { return EP3NetEventType::Connect; }
	virtual const FP3NetConnectEvent* SafeCastToConnectEvent() const override { return this; }

	bool bSuccess = false;
};

struct FP3NetListenEvent : public FP3NetEvent
{
	virtual EP3NetEventType GetType() const override { return EP3NetEventType::Listen; }
	virtual const FP3NetListenEvent* SafeCastToListenEvent() const override { return this; }

	bool bSuccess = false;
};

struct FP3NetAcceptEvent : public FP3NetEvent
{
	virtual EP3NetEventType GetType() const override { return EP3NetEventType::Accept; }
	virtual const FP3NetAcceptEvent* SafeCastToAcceptEvent() const override { return this; }

	P3NetConnId AcceptedConnId = INVALID_NETCONNID;
};

struct FP3NetCloseEvent : public FP3NetEvent
{
	virtual EP3NetEventType GetType() const override { return EP3NetEventType::Close; }
	virtual const FP3NetCloseEvent* SafeCastToCloseEvent() const override { return this; }
};

struct FP3NetRecvPbEvent : public FP3NetEvent
{
	FP3NetRecvPbEvent(TSharedRef<const google::protobuf::Message, ESPMode::ThreadSafe> InMessage)
		: Message(InMessage)
	{}

	virtual EP3NetEventType GetType() const override { return EP3NetEventType::RecvPb; }
	virtual const FP3NetRecvPbEvent* SafeCastToRecvPbEvent() const override { return this; }

	uint16 MessageType = 0;
	TSharedRef<const google::protobuf::Message, ESPMode::ThreadSafe> Message;
};

struct FP3NetRecvExEvent : public FP3NetEvent
{
	FP3NetRecvExEvent(TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> InMessage)
		: Message(InMessage)
	{}

	virtual EP3NetEventType GetType() const override { return EP3NetEventType::RecvEx; }
	virtual const FP3NetRecvExEvent* SafeCastToRecvExEvent() const override { return this; }

	uint16 MessageType = 0;
	TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> Message;
};

//////////////////////////////////////////////////////////////////////////
// FP3NetTask
//////////////////////////////////////////////////////////////////////////

enum class EP3NetTaskType
{
	Listen,
	ConnectPb,
	ConnectEx,
};

struct FP3NetTask
{
	virtual ~FP3NetTask() {}

	virtual EP3NetTaskType GetType() const = 0;
	virtual struct FP3NetListenTask* SafeCastToListenTask() { return nullptr; }
	virtual struct FP3NetConnectPbTask* SafeCastToConnectPbTask() { return nullptr; }
	virtual struct FP3NetConnectExTask* SafeCastToConnectExTask() { return nullptr; }

	double ScheduleTimeSeconds;
};

struct FP3NetTaskComparer
{
	bool operator()(const TSharedPtr<FP3NetTask>& A, const TSharedPtr<FP3NetTask>& B) const
	{
		return A->ScheduleTimeSeconds < B->ScheduleTimeSeconds;
	}
};

struct FP3NetListenTask : public FP3NetTask
{
	virtual EP3NetTaskType GetType() const override { return EP3NetTaskType::Listen; }
	virtual FP3NetListenTask* SafeCastToListenTask() override { return this; }

	P3NetConnId ConnId = INVALID_NETCONNID;
	FString ConnName;
	FString BindAddress;
	int32 BindPort = 0;
	int32 MaxBacklog = 5;
	int32 MaxSocketSendPerMessage = 0;
	TDescMap DescMap;
	double RetryIntervalSeconds = 0.0;
	bool bEnableStat = false;
};

struct FP3NetConnectPbTask : public FP3NetTask
{
	virtual EP3NetTaskType GetType() const override { return EP3NetTaskType::ConnectPb; }
	virtual FP3NetConnectPbTask* SafeCastToConnectPbTask() override { return this; }

	P3NetConnId ConnId = INVALID_NETCONNID;
	FP3NetConnectParams Params;
	TDescMap DescMap;
	int32 RetryCount = 0;
};

struct FP3NetConnectExTask : public FP3NetTask
{
	virtual EP3NetTaskType GetType() const override { return EP3NetTaskType::ConnectEx; }
	virtual FP3NetConnectExTask* SafeCastToConnectExTask() override { return this; }

	P3NetConnId ConnId = INVALID_NETCONNID;
	FP3NetConnectParams Params;
	TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol;
	int32 RetryCount = 0;
};

//////////////////////////////////////////////////////////////////////////
// FP3NetThread
//////////////////////////////////////////////////////////////////////////

class FP3NetThread : public FRunnable
{
public:
	FP3NetThread(const TCHAR* ThreadName);

	virtual bool Init() override;
	virtual uint32 Run() override;
	virtual void Stop() override;
	virtual void Exit() override;

	void EnsureCompletion();

	P3NetConnId CreateConnPb(const FP3NetConnectParams& Params, const TDescMap& DescMap);
	P3NetConnId CreateConnEx(const FP3NetConnectParams& Params, TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol);
	P3NetConnId CreateListener(const FString& ConnName, const FString& BindAddress, int32 BindPort, int32 MaxBacklog, const TDescMap& DescMap, float RetryIntervalSeconds, int32 MaxSocketSendPerMessage, bool bEnableStat);
	void CloseConn(P3NetConnId ConnId);
	void SendPb(P3NetConnId ConnId, uint16 MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message);
	void SendEx(P3NetConnId ConnId, TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> Message);

	TArray<TSharedRef<const FP3NetEvent, ESPMode::ThreadSafe>> FetchEvents();

	int32 GetAvgSentBytesPerSecond() const { return AvgSentBytesPerSecond.GetValue(); }
	int32 GetAvgRecvBytesPerSecond() const { return AvgRecvBytesPerSecond.GetValue(); }
	int32 GetAvgSentMessagesPerSecond() const { return AvgSentMessagesPerSecond.GetValue(); }
	int32 GetAvgRecvMessagesPerSecond() const { return AvgRecvMessagesPerSecond.GetValue(); }

private:
	void HandleRequests();
	void HandleConnectPbRequest(const struct FP3NetConnectPbRequest& Request);
	void HandleConnectExRequest(const struct FP3NetConnectExRequest& Request);
	void HandleListenRequest(const struct FP3NetListenRequest& Request);
	void HandleSendPbRequest(const struct FP3NetSendPbRequest& Request);
	void HandleSendExRequest(const struct FP3NetSendExRequest& Request);
	void HandleCloseRequest(const struct FP3NetCloseRequest& Request);

	void HandleTasks();
	void HandleListenTask(const FP3NetListenTask& Task);
	void HandleConnectPbTask(const FP3NetConnectPbTask& Task);
	void HandleConnectExTask(const FP3NetConnectExTask& Task);

	void AcceptConns();
	void FlushMessages();
	void ReceiveMessages();
	bool ReceivePbMessages(FP3NetConnPb& Conn);
	bool ReceiveExMessages(FP3NetConnEx& Conn);
	void UpdateStat(int32 TickTimeMsec);

	void CloseConn(TSharedRef<class FP3NetConn>);

	// Accessed only from game thread
	FRunnableThread* Thread = nullptr;

	// Accessed only from network thread
	TArray<TSharedRef<class FP3NetConn>> Conns;
	TArray<TSharedRef<class FP3NetListener>> Listeners;
	TArray<TSharedPtr<FP3NetTask>> Tasks;

	// Shared data
	FThreadSafeCounter NextConnId = 0;
	FThreadSafeBool bStop = false;
	FThreadSafeCounter AvgSentBytesPerSecond;
	FThreadSafeCounter AvgRecvBytesPerSecond;
	FThreadSafeCounter AvgSentMessagesPerSecond;
	FThreadSafeCounter AvgRecvMessagesPerSecond;

	double LastStatDumpTimeSeconds = 0.0;

	FRWLock RequestsLocker;

	using P3NetRequestSharedPtr = TSharedRef<const struct FP3NetRequest, ESPMode::ThreadSafe>;
	TArray<P3NetRequestSharedPtr> Requests;

	FRWLock EventsLocker;
	TArray<TSharedRef<const FP3NetEvent, ESPMode::ThreadSafe>> Events;
};
