// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetConn.h"
#include "P3Packer.h"
#include "P3Log.h"
#include "SocketSubsystem.h"
#include "Sockets.h"

TAutoConsoleVariable<int32> CVarP3NetMaxMessageSize(
	TEXT("p3.netMaxMessageSize"),
	1024 * 1024, // 1MB
	TEXT("Max message size for p3 network"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3NetMaxSendBufferSize(
	TEXT("p3.netMaxSendBufferSize"),
	100 * 1024 * 1024, // 100MB
	TEXT("Max send buffer size for p3 network"), ECVF_Default);

TAutoConsoleVariable<float> CVarP3NetStatUpdatePeriod(
	TEXT("p3.netStatUpdatePeriod"),
	1.0f,
	TEXT("Update period for calculate network stat"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3NetSimulateSlowReceive(
	TEXT("p3.netSimulateSlowReceive"),
	0,
	TEXT("If value is greater than 0, only receive once per value"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3NetNoDelay(
	TEXT("p3.netNoDelay"),
	1,
	TEXT("Use tcp no delay option"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3NetLingerTimeout(
	TEXT("p3.netLingerTimeout"),
	0,
	TEXT("Use tcp socket SO_LINGER option, value is timeout seconds"), ECVF_Default);


FP3NetConn::FP3NetConn(P3NetConnId InId, const FString& InName)
	: Id(InId)
	, Name(InName)
{
}

P3NetConnId FP3NetConn::GetId() const
{
	return Id;
}

const FString& FP3NetConn::GetName() const
{
	return Name;
}

const FString& FP3NetConn::GetRemoteAddress() const
{
	return RemoteAddress;
}

const FP3NetStat& FP3NetConn::GetStat() const
{
	return Stat;
}

bool FP3NetConn::Connect(const FString& Hostname, int32 Port)
{
	ensure(!Socket);

	if (Socket)
	{
		Close();
	}

	ISocketSubsystem* SocketSubSystem = ISocketSubsystem::Get();
	check(SocketSubSystem);

	TSharedRef<FInternetAddr> Address = SocketSubSystem->CreateInternetAddr();

	bool bIsValid = false;
	Address->SetIp(*Hostname, bIsValid);
	Address->SetPort(Port);

	if (!bIsValid)
	{
		FAddressInfoResult AddressInfoResult = SocketSubSystem->GetAddressInfo(*Hostname, nullptr, EAddressInfoFlags::Default, NAME_None);

		if (AddressInfoResult.ReturnCode != SE_NO_ERROR || AddressInfoResult.Results.Num() == 0)
		{
			P3JsonNetConnLog(*this, Error, "Failed to look up hostname", TEXT("Hostname"), *Hostname, TEXT("Error"), AddressInfoResult.ReturnCode);
			return false;
		}

		Address->SetRawIp(AddressInfoResult.Results[0].Address->GetRawIp());
	}

	FSocket* NewSocket = SocketSubSystem->CreateSocket(NAME_Stream, TEXT("P3NetConn"));

	if (!NewSocket)
	{
		P3JsonNetConnLog(*this, Error, "Failed to create socket");
		return false;
	}

	bool bIsConnected = NewSocket->Connect(*Address);

	if (!bIsConnected)
	{
		P3JsonNetConnLog(*this, Warning, "Failed to connect",
			TEXT("Hostname"), *Hostname,
			TEXT("Port"), Port);
		SocketSubSystem->DestroySocket(NewSocket);
		return false;
	}

	InitFromSocket(NewSocket);

	return true;
}

bool FP3NetConn::InitFromSocket(class FSocket* InSocket)
{
	if (!ensure(InSocket))
	{
		return false;
	}

	Socket = InSocket;

	ISocketSubsystem* SocketSubSystem = ISocketSubsystem::Get();
	if (ensure(SocketSubSystem))
	{
		TSharedPtr<FInternetAddr> PeerAddress = SocketSubSystem->CreateInternetAddr();
		Socket->GetPeerAddress(*PeerAddress);
		RemoteAddress = PeerAddress->ToString(true);
	}

	Socket->SetNonBlocking(true);

	if (CVarP3NetLingerTimeout.GetValueOnAnyThread() > 0)
	{
		Socket->SetLinger(true, CVarP3NetLingerTimeout.GetValueOnAnyThread());
	}

	if (CVarP3NetNoDelay.GetValueOnAnyThread() > 0)
	{
		P3JsonNetConnLog(*this, Display, "Turn on TCP_NODELAY");
		Socket->SetNoDelay(true);
		Socket->SetQuickAck(true);
	}

	return true;
}

#if P3_BUILD_WITH_TEST
void FP3NetConn::InjectTestSocket(FSocket* TestSocket)
{
	Socket = TestSocket;
}
#endif

void FP3NetConn::Close()
{
	ISocketSubsystem* SocketSubSystem = ISocketSubsystem::Get();
	check(SocketSubSystem);

	if (ensure(Socket))
	{
		if (CVarP3NetLingerTimeout.GetValueOnAnyThread() > 0)
		{
			Socket->Shutdown(ESocketShutdownMode::Read);
		}

		Socket->Close();
		SocketSubSystem->DestroySocket(Socket);
		Socket = nullptr;
	}
}

void FP3NetConn::UpdateStat()
{
	const double CurrentRealtimeSeconds = FPlatformTime::Seconds();
	const float RealTime = StaticCast<float>(CurrentRealtimeSeconds - StatUpdateTime);

	if (RealTime < CVarP3NetStatUpdatePeriod.GetValueOnAnyThread())
	{
		return;
	}

	Stat.SentBytesPerSecond = FMath::TruncToInt(static_cast<float>(StatSentBytes) / RealTime);
	Stat.RecvBytesPerSecond = FMath::TruncToInt(static_cast<float>(StatRecvBytes) / RealTime);
	Stat.SentMessagesPerSecond = FMath::TruncToInt(static_cast<float>(StatSentMessages) / RealTime);
	Stat.RecvMessagesPerSecond = FMath::TruncToInt(static_cast<float>(StatRecvMessages) / RealTime);
	Stat.StatSendFailsPerSecond = FMath::TruncToInt(static_cast<float>(StatSendFails) / RealTime);
	Stat.StatMaxSendBuffer = StatMaxSendBuffer;

	StatSentBytes = 0;
	StatRecvBytes = 0;
	StatSentMessages = 0;
	StatRecvMessages = 0;
	StatSendFails = 0;
	StatMaxSendBuffer = 0;

	StatUpdateTime = CurrentRealtimeSeconds;

	P3JsonNetConnLog(*this, VeryVerbose, "P3 Network stat",
		TEXT("Sent B/s"), Stat.SentBytesPerSecond,
		TEXT("Recv B/s"), Stat.RecvBytesPerSecond,
		TEXT("Sent M/s"), Stat.SentMessagesPerSecond,
		TEXT("Recv M/s"), Stat.RecvMessagesPerSecond,
		TEXT("SendFail"), Stat.StatSendFailsPerSecond,
		TEXT("MaxSendBuffer"), Stat.StatMaxSendBuffer);
}
