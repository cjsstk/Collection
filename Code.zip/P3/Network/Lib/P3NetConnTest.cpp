// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetConnPb.h"
#include "P3Packer.h"
#include "Sockets.h"
#include "P3Test.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/game.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/game.pb.h"
#endif

extern TAutoConsoleVariable<int32> CVarP3NetMaxMessageSize;

#if P3_BUILD_WITH_TEST

#include "AutomationTest.h"

/**
 * Socket for testing FP3NetConnPb
 *
 * No real network connection
 * Receive the data sent before (like echo)
 * Sends and receives just one byte per call
 */
class FP3TestSocket : public FSocket
{
public:
	virtual bool Shutdown(ESocketShutdownMode Mode) { return true; }
	virtual bool Close() { return true; }
	virtual bool Bind(const FInternetAddr& Addr) { return true; }
	virtual bool Connect(const FInternetAddr& Addr) { return true; }
	virtual bool Listen(int32 MaxBacklog) { return true; }
	virtual bool WaitForPendingConnection(bool& bHasPendingConnection, const FTimespan& WaitTime) { return true; }
	virtual bool HasPendingData(uint32& PendingDataSize) { return true; }
	virtual class FSocket* Accept(const FString& InSocketDescription) { return nullptr; }
	virtual class FSocket* Accept(FInternetAddr& OutAddr, const FString& InSocketDescription) { return nullptr; }
	virtual bool Wait(ESocketWaitConditions::Type Condition, FTimespan WaitTime) { return true; }
	virtual ESocketConnectionState GetConnectionState() { return SCS_Connected; }
	virtual void GetAddress(FInternetAddr& OutAddr) {}
	virtual bool GetPeerAddress(FInternetAddr& OutAddr) { return true; }
	virtual bool SetNonBlocking(bool bIsNonBlocking = true) { return true; }
	virtual bool SetBroadcast(bool bAllowBroadcast = true) { return true; }
	virtual bool JoinMulticastGroup(const FInternetAddr& GroupAddress) { return true; }
	virtual bool JoinMulticastGroup(const FInternetAddr& GroupAddress, const FInternetAddr& InterfaceAddress) { return true; }
	virtual bool LeaveMulticastGroup(const FInternetAddr& GroupAddress) { return true; }
	virtual bool LeaveMulticastGroup(const FInternetAddr& GroupAddress, const FInternetAddr& InterfaceAddress) { return true; }
	virtual bool SetMulticastLoopback(bool bLoopback) { return true; }
	virtual bool SetMulticastTtl(uint8 TimeToLive) { return true; }
	virtual bool SetMulticastInterface(const FInternetAddr& InterfaceAddress) { return true; }
	virtual bool SetReuseAddr(bool bAllowReuse = true) { return true; }
	virtual bool SetLinger(bool bShouldLinger = true, int32 Timeout = 0) { return true; }
	virtual bool SetRecvErr(bool bUseErrorQueue = true) { return true; }
	virtual bool SetNoDelay(bool bUseNoDelay = true) { return true; }
	virtual bool SetQuickAck(bool bUseQuickAck = true) { return true; }
	virtual bool SetSendBufferSize(int32 Size, int32& NewSize) { return true; }
	virtual bool SetReceiveBufferSize(int32 Size, int32& NewSize) { return true; }
	virtual int32 GetPortNo() { return true; }

	virtual bool Send(const uint8* Data, int32 Count, int32& BytesSent) override
	{
		if (Count <= 0)
		{
			return false;
		}

		LocalBuffer[LocalBufferWritePos++] = Data[0];
		BytesSent = 1;

		return true;
	}

	virtual bool Recv(uint8* Data, int32 BufferSize, int32& BytesRead, ESocketReceiveFlags::Type Flags = ESocketReceiveFlags::None) override
	{
		if (BufferSize <= 0)
		{
			return false;
		}

		if (LocalBufferReadPos >= LocalBufferWritePos)
		{
			BytesRead = 0;
			return true;
		}

		Data[0] = LocalBuffer[LocalBufferReadPos++];
		BytesRead = 1;

		return true;
	}

	uint8 LocalBuffer[1024 * 1024];
	uint32 LocalBufferWritePos = 0;
	uint32 LocalBufferReadPos = 0;
};

IMPLEMENT_GET_PRIVATE_VAR(FP3NetConnPb, RecvBufPos, int32);
IMPLEMENT_GET_PROTECTED_FUNC(FP3NetConnPb, PopMessageRaw, bool, P3_ARG_WITH_COMMAS(bool& bOutHasMessage, uint16& OutMessageType, TArray<uint8>& OutMessageBuf), P3_ARG_WITH_COMMAS(bOutHasMessage, OutMessageType, OutMessageBuf));

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3NetConnPbBasicTest, "P3.NetConn.Basic", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3NetConnPbBasicTest::RunTest(const FString& Parameters)
{
	FP3TestSocket TestSocket;

	FP3NetConnPb Conn(P3NetConnId(1), "Test", TDescMap(), 0);
	Conn.InjectTestSocket(&TestSocket);

	pb::C2DHello Message;
	Message.set_player_id("schumi");
	const TArray<uint8> TestData({ 0x0a, 0x06, 0x73, 0x63, 0x68, 0x75, 0x6d, 0x69 });
	const uint32 TestMessageType = pb::C2D_HELLO;

	{
		Conn.Send(TestMessageType, Message);
		for (int32 i = 0; i < 100; ++i)
		{
			Conn.Flush();
		}

		P3_ASSERT_EQUAL(TestSocket.LocalBufferWritePos, P3NET_PB_PACKET_HEADER_SIZE + TestData.Num());

		int32 Pos = 0;
		uint32 SendSeq = 1;
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32BE(TestSocket.LocalBuffer, Pos), TestData.Num());
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32BE(TestSocket.LocalBuffer, Pos), SendSeq++);
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt16BE(TestSocket.LocalBuffer, Pos), TestMessageType);
		P3_ASSERT_EQUAL_MEMORY(&TestSocket.LocalBuffer[Pos], TestData.GetData(), StaticCast<SIZE_T>(TestData.Num()));
		Pos += TestData.Num();
	}

	{
		bool bHasMessage = false;
		uint16 MessageType = 0;
		TArray<uint8> MessageBuf;

		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_FALSE(bHasMessage);

		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), 0);

		// Recv data from LocalBuffer
		for (int32 i = 0; i < 100; ++i)
		{
			Conn.Recv();
		}

		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), P3NET_PB_PACKET_HEADER_SIZE + TestData.Num());

		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_TRUE(bHasMessage);
		P3_ASSERT_EQUAL(MessageType, TestMessageType);
		P3_ASSERT_EQUAL(MessageBuf.Num(), TestData.Num());
		P3_ASSERT_EQUAL_TARRAY(MessageBuf, TestData);
		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), 0);

		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);
		P3_ASSERT_FALSE(bHasMessage);
	}

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3NetConnPbMultipleTest, "P3.NetConn.Multiple", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3NetConnPbMultipleTest::RunTest(const FString& Parameters)
{
	FP3TestSocket TestSocket;

	FP3NetConnPb Conn(P3NetConnId(1), "Test", TDescMap(), 0);
	Conn.InjectTestSocket(&TestSocket);

	pb::C2DHello FirstMessage;
	FirstMessage.set_player_id("ab");
	const TArray<uint8> FirstData({ 0x0a, 0x02, 0x61, 0x62 });
	const uint32 FirstMessageType = pb::C2D_HELLO;

	pb::C2DConsoleCommand SecondMessage;
	SecondMessage.set_command("cdefgh");
	const TArray<uint8> SecondData({ 0x0a, 0x06, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68 });
	const uint32 SecondMessageType = pb::C2D_CONSOLE_COMMAND;

	{
		Conn.Send(FirstMessageType, FirstMessage);
		for (int32 i = 0; i < 100; ++i)
		{
			Conn.Flush();
		}

		P3_ASSERT_EQUAL(TestSocket.LocalBufferWritePos, P3NET_PB_PACKET_HEADER_SIZE + FirstData.Num());

		int32 Pos = 0;
		uint32 SendSeq = 1;
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32BE(TestSocket.LocalBuffer, Pos), FirstData.Num());
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32BE(TestSocket.LocalBuffer, Pos), SendSeq++);
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt16BE(TestSocket.LocalBuffer, Pos), FirstMessageType);
		P3_ASSERT_EQUAL_MEMORY(&TestSocket.LocalBuffer[Pos], FirstData.GetData(), StaticCast<SIZE_T>(FirstData.Num()));
		Pos += FirstData.Num();

		Conn.Send(SecondMessageType, SecondMessage);
		for (int32 i = 0; i < 100; ++i)
		{
			Conn.Flush();
		}

		P3_ASSERT_EQUAL(TestSocket.LocalBufferWritePos, P3NET_PB_PACKET_HEADER_SIZE + FirstData.Num() + P3NET_PB_PACKET_HEADER_SIZE + SecondData.Num());

		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32BE(TestSocket.LocalBuffer, Pos), SecondData.Num());
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt32BE(TestSocket.LocalBuffer, Pos), SendSeq++);
		P3_ASSERT_EQUAL(FP3Packer::UnpackUInt16BE(TestSocket.LocalBuffer, Pos), SecondMessageType);
		P3_ASSERT_EQUAL_MEMORY(&TestSocket.LocalBuffer[Pos], SecondData.GetData(), StaticCast<SIZE_T>(SecondData.Num()));
		Pos += SecondData.Num();
	}

	{
		bool bHasMessage = false;
		uint16 MessageType = 0;
		uint32 MessageSize = 0;

		TArray<uint8> MessageBuf;

		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);
		P3_ASSERT_FALSE(bHasMessage);

		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), 0);

		// Recv data from LocalBuffer
		for (int32 i = 0; i < 100; ++i)
		{
			Conn.Recv();
		}

		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), P3NET_PB_PACKET_HEADER_SIZE + FirstData.Num() + P3NET_PB_PACKET_HEADER_SIZE + SecondData.Num());

		// Pop first message
		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_TRUE(bHasMessage);
		P3_ASSERT_EQUAL(MessageType, FirstMessageType);
		P3_ASSERT_EQUAL(MessageBuf.Num(), FirstData.Num());
		P3_ASSERT_EQUAL_TARRAY(MessageBuf, FirstData);
		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), P3NET_PB_PACKET_HEADER_SIZE + SecondData.Num());

		// Pop second message
		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_TRUE(bHasMessage);
		P3_ASSERT_EQUAL(MessageType, SecondMessageType);
		P3_ASSERT_EQUAL(MessageBuf.Num(), SecondData.Num());
		P3_ASSERT_EQUAL_TARRAY(MessageBuf, SecondData);
		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), 0);

		// No more message
		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);
		P3_ASSERT_FALSE(bHasMessage);
	}

	return true;
}

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3NetConnPbPartialTest, "P3.NetConn.Partial", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
bool FP3NetConnPbPartialTest::RunTest(const FString& Parameters)
{
	FP3TestSocket TestSocket;

	FP3NetConnPb Conn(P3NetConnId(1), "Test", TDescMap(), 0);
	Conn.InjectTestSocket(&TestSocket);

	pb::C2DHello FirstMessage;
	FirstMessage.set_player_id("ab");
	const TArray<uint8> FirstData({ 0x0a, 0x02, 0x61, 0x62 });
	const uint32 FirstMessageType = pb::C2D_HELLO;

	pb::C2DConsoleCommand SecondMessage;
	SecondMessage.set_command("cdefgh");
	const TArray<uint8> SecondData({ 0x0a, 0x06, 0x63, 0x64, 0x65, 0x66, 0x67, 0x68 });
	const uint32 SecondMessageType = pb::C2D_CONSOLE_COMMAND;

	Conn.Send(FirstMessageType, FirstMessage);
	Conn.Send(SecondMessageType, SecondMessage);
	for (int32 i = 0; i < 100; ++i)
	{
		Conn.Flush();
	}

	{
		bool bHasMessage = false;
		uint16 MessageType = 0;
		uint32 MessageSize = 0;
		int32 RecvPos = 0;
		int32 TargetRecvPos = 0;

		TArray<uint8> MessageBuf;

		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_FALSE(bHasMessage);

		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), 0);

		// Recv partial from first data
		TargetRecvPos = P3NET_PB_PACKET_HEADER_SIZE + FirstData.Num() / 2;
		for (int32 i = RecvPos; i < TargetRecvPos; ++i)
		{
			Conn.Recv();
		}
		RecvPos = TargetRecvPos;

		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), TargetRecvPos);

		P3_ASSERT_FALSE(bHasMessage);

		// Recv left data of first and partial from second
		TargetRecvPos = P3NET_PB_PACKET_HEADER_SIZE + FirstData.Num() + P3NET_PB_PACKET_HEADER_SIZE + SecondData.Num() / 2;
		for (int32 i = RecvPos; i < TargetRecvPos; ++i)
		{
			Conn.Recv();
		}
		RecvPos = TargetRecvPos;

		// Pop first message
		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_TRUE(bHasMessage);
		P3_ASSERT_EQUAL(MessageType, FirstMessageType);
		P3_ASSERT_EQUAL(MessageBuf.Num(), FirstData.Num());
		P3_ASSERT_EQUAL_TARRAY(MessageBuf, FirstData);
		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), P3NET_PB_PACKET_HEADER_SIZE + SecondData.Num() / 2);

		// Try pop second message
		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_FALSE(bHasMessage);

		// Recv left data of second
		for (int32 i = 0; i < 100; ++i)
		{
			Conn.Recv();
		}

		// Pop second message
		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);

		P3_ASSERT_TRUE(bHasMessage);
		P3_ASSERT_EQUAL(MessageType, SecondMessageType);
		P3_ASSERT_EQUAL(MessageBuf.Num(), SecondData.Num());
		P3_ASSERT_EQUAL_TARRAY(MessageBuf, SecondData);
		P3_ASSERT_EQUAL(GET_PRIVATE(FP3NetConnPb, &Conn, RecvBufPos), 0);

		// No more message
		CALL_PROTECTED(FP3NetConnPb, &Conn, PopMessageRaw)(bHasMessage, MessageType, MessageBuf);
		P3_ASSERT_FALSE(bHasMessage);
	}

	return true;
}

#endif // P3_BUILD_WITH_TEST
