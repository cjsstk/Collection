// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetConnPb.h"
#include "P3Packer.h"
#include "P3Log.h"
#include "SocketSubsystem.h"
#include "Sockets.h"

DECLARE_CYCLE_STAT(TEXT("P3NetConnPb Send"), STAT_P3NetConnPb_Send, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnPb Flush"), STAT_P3NetConnPb_Flush, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnPb Flush_SocketSend"), STAT_P3NetConnPb_Flush_SocketSend, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnPb Recv"), STAT_P3NetConnPb_Recv, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnPb Recv_SocketRecv"), STAT_P3NetConnPb_Recv_SocketRecv, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnPb PopMessage"), STAT_P3NetConnPb_PopMessage, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnPb PopMessageRaw"), STAT_P3NetConnPb_PopMessageRaw, STATGROUP_P3);

extern TAutoConsoleVariable<int32> CVarP3NetMaxMessageSize;
extern TAutoConsoleVariable<int32> CVarP3NetMaxSendBufferSize;
extern TAutoConsoleVariable<int32> CVarP3NetSimulateSlowReceive;

FP3NetConnPb::FP3NetConnPb(P3NetConnId InId, const FString& InConnName, const TDescMap& InDescMap, int32 InMaxSocketSendPerMessage)
	: FP3NetConn(InId, InConnName)
	, DescMap(InDescMap)
	, MaxSocketSendPerMessage(InMaxSocketSendPerMessage)
{
	MaxMessageSize = CVarP3NetMaxMessageSize.GetValueOnAnyThread();
	RecvBuf.SetNum(P3NET_PB_PACKET_HEADER_SIZE + MaxMessageSize);
}

bool FP3NetConnPb::BuildMessageFromProtobuf(uint8* Buffer, int32 InPos, int32 MessageSize, uint16 Type, const ::google::protobuf::Message& Message)
{
	int32 Pos = InPos;

	FP3Packer::PackUInt32BE(Buffer, Pos, StaticCast<uint32>(MessageSize));
	FP3Packer::PackUInt32BE(Buffer, Pos, SendSeq);
	FP3Packer::PackUInt16BE(Buffer, Pos, Type);
	check(Pos == InPos + P3NET_PB_PACKET_HEADER_SIZE);

	if (MessageSize > 0)
	{
		const bool bSuccess = Message.SerializeToArray(Buffer + Pos, MessageSize);
		if (!bSuccess)
		{
			P3JsonNetConnLog(*this, Error, "Failed to serialize packet", TEXT("Type"), Type);
			return false;
		}
	}

	++SendSeq;
	++StatSentMessages;

	return true;
}

bool FP3NetConnPb::Send(uint16 Type, const ::google::protobuf::Message& Message)
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnPb_Send);

	const int32 MessageSize = StaticCast<int32>(Message.ByteSizeLong());
	if (MessageSize > MaxMessageSize)
	{
		P3JsonNetConnLog(*this, Error, "Max message size exceeded", TEXT("Type"), Type, TEXT("Size"), MessageSize);
		return false;
	}

	const int32 LastPos = SendBuf.Num();
	const int32 NewBufferSize = LastPos + P3NET_PB_PACKET_HEADER_SIZE + MessageSize;

	const int32 MaxSendBufferSize = CVarP3NetMaxSendBufferSize.GetValueOnAnyThread();
	if (NewBufferSize > MaxSendBufferSize)
	{
		P3JsonNetConnLog(*this, Error, "Max send buffer size exceeded",
			TEXT("Type"), Type,
			TEXT("Size"), MessageSize,
			TEXT("MaxSendBufferSize"), MaxSendBufferSize);
		return false;
	}

	SendBuf.SetNum(NewBufferSize);

	int32 Pos = LastPos;

	if (!BuildMessageFromProtobuf(SendBuf.GetData(), Pos, MessageSize, Type, Message))
	{
		return false;
	}
	//const FString MessageHead = BytesToHex(&SendBuf[LastPos], P3NET_PB_PACKET_HEADER_SIZE);
	//P3JsonNetConnLog(*this, VeryVerbose, "SendHeader",
	//	TEXT("Size"), StaticCast<int32>(MessageSize),
	//	TEXT("Seq"), SendSeq,
	//	TEXT("MessageType"), Type,
	//	TEXT("MessageHead"), *MessageHead);

	if (NewBufferSize > StatMaxSendBuffer)
	{
		StatMaxSendBuffer = NewBufferSize;
	}

	return true;
}

bool FP3NetConnPb::Flush()
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnPb_Flush);

	if (!ensure(Socket))
	{
		return false;
	}

	if (SendBuf.Num() == 0)
	{
		return true;
	}

	int32 BytesSent = 0;
	bool bSuccess = false;
	{
		SCOPE_CYCLE_COUNTER(STAT_P3NetConnPb_Flush_SocketSend);
		bSuccess = Socket->Send(SendBuf.GetData(), SendBuf.Num(), BytesSent);
	}

	if (BytesSent > 0)
	{
		StatSentBytes += BytesSent;

		const int32 BytesLeft = SendBuf.Num() - BytesSent;
		if (BytesLeft == 0)
		{
			SendBuf.Reset();
		}
		else if (BytesLeft > 0)
		{
			FMemory::Memmove(SendBuf.GetData(), &SendBuf[BytesSent], StaticCast<SIZE_T>(BytesLeft));
			SendBuf.SetNum(BytesLeft);
		}
	}

	if (!bSuccess)
	{
		ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get();
		check(SocketSubsystem);

		const ESocketErrors Error = SocketSubsystem->GetLastErrorCode();
		if (Error == SE_NO_ERROR || Error == SE_EWOULDBLOCK)
		{
			++StatSendFails;
			P3JsonNetConnLog(*this, Verbose, "Sending packet failed",
				TEXT("Size"), SendBuf.Num(),
				TEXT("BytesSent"), BytesSent,
				TEXT("BufferSize"), SendBuf.Num(),
				TEXT("ErrorCode"), StaticCast<int32>(Error),
				TEXT("Error"), SocketSubsystem->GetSocketError(Error));
		}
		else
		{
			P3JsonNetConnLog(*this, Warning, "Failed to send packet",
				TEXT("Size"), SendBuf.Num(),
				TEXT("BytesSent"), BytesSent,
				TEXT("BufferSize"), SendBuf.Num(),
				TEXT("ErrorCode"), StaticCast<int32>(Error),
				TEXT("Error"), SocketSubsystem->GetSocketError(Error));
			return false;
		}
	}

	return true;
}

bool FP3NetConnPb::Recv()
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnPb_Recv);

	if (!ensure(Socket))
	{
		return false;
	}

#if !UE_BUILD_SHIPPING
	int32 SimulateSlowReceive = CVarP3NetSimulateSlowReceive.GetValueOnAnyThread();
	if (SimulateSlowReceive > 0)
	{
		++DebugRecvCounter;
		if (DebugRecvCounter % SimulateSlowReceive != 0)
		{
			return true;
		}
		DebugRecvCounter = 0;
	}
#endif

	check(RecvBufPos <= RecvBuf.Num());

	int32 BytesRead = 0;
	bool bSuccess = false;
	{
		SCOPE_CYCLE_COUNTER(STAT_P3NetConnPb_Recv_SocketRecv);
		bSuccess = Socket->Recv(&RecvBuf[RecvBufPos], RecvBuf.Num() - RecvBufPos, BytesRead);
	}
	if (!bSuccess)
	{
		ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get();
		check(SocketSubsystem);

		const ESocketErrors Error = SocketSubsystem->GetLastErrorCode();
		ensure(Error != SE_EWOULDBLOCK);

		if (Error == SE_NO_ERROR)
		{
			P3JsonNetConnLog(*this, Display, "Connection closed");
		}
		else
		{
			P3JsonNetConnLog(*this, Warning, "Failed to recv packet",
				TEXT("ErrorCode"), StaticCast<int32>(Error),
				TEXT("Error"), SocketSubsystem->GetSocketError(Error));
		}
		return false;
	}

	RecvBufPos += BytesRead;
	StatRecvBytes += BytesRead;

	//P3JsonNetConnLog(*this, VeryVerbose, "Recv",
	//	TEXT("BytesRead"), BytesRead,
	//	TEXT("RecvBufPos"), RecvBufPos);

	return true;
}

bool FP3NetConnPb::PopMessageRaw(bool& bOutHasMessage, uint16& OutMessageType, TArray<uint8>& OutMessageBuf)
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnPb_PopMessageRaw);

	// Default value for output parameters
	bOutHasMessage = false;
	OutMessageType = 0;

	if (RecvBufPos < P3NET_PB_PACKET_HEADER_SIZE)
	{
		// Need more data
		return true;
	}

	int32 ReadPos = 0;
	uint32 MessageSize = FP3Packer::UnpackUInt32BE(RecvBuf.GetData(), ReadPos);

	if (MessageSize > StaticCast<uint32>(MaxMessageSize))
	{
		P3JsonNetConnLog(*this, Error, "Too large message size", TEXT("Size"), (int64)MessageSize);
		return false;
	}

	int32 PacketSize = P3NET_PB_PACKET_HEADER_SIZE + MessageSize;
	if (RecvBufPos < PacketSize)
	{
		// Need more data
		return true;
	}

	uint32 Seq = FP3Packer::UnpackUInt32BE(RecvBuf.GetData(), ReadPos);
	uint16 MessageType = FP3Packer::UnpackUInt16BE(RecvBuf.GetData(), ReadPos);

	//FString MessageHead = BytesToHex(&RecvBuf[ReadPos], 10);
	//P3JsonNetConnLog(*this, VeryVerbose, "PopMessageRaw",
	//	TEXT("Size"), StaticCast<int32>(MessageSize),
	//	TEXT("Seq"), StaticCast<int32>(Seq),
	//	TEXT("RecvSeq"), RecvSeq,
	//	TEXT("MessageType"), MessageType,
	//	TEXT("RecvBufPos"), RecvBufPos,
	//	TEXT("MessageHead"), *MessageHead);

	if (!ensure(Seq == RecvSeq))
	{
		P3JsonNetConnLog(*this, Error, "Invalid recv seq number",
			TEXT("Seq"), (int64)Seq,
			TEXT("RecvSeq"), (int64)RecvSeq);
		return false;
	}

	ensure(ReadPos == P3NET_PB_PACKET_HEADER_SIZE);
	++RecvSeq;

	// Set output parameters
	bOutHasMessage = true;
	OutMessageType = MessageType;
	OutMessageBuf.SetNum(MessageSize);

	if (MessageSize > 0)
	{
		FMemory::Memcpy(OutMessageBuf.GetData(), &RecvBuf[ReadPos], StaticCast<SIZE_T>(MessageSize));
	}

	// Move extra data to front if available
	if (RecvBufPos > PacketSize)
	{
		FMemory::Memmove(RecvBuf.GetData(), &RecvBuf[PacketSize], StaticCast<SIZE_T>(RecvBufPos - PacketSize));
	}

	RecvBufPos -= PacketSize;

	++StatRecvMessages;

	return true;
}

bool FP3NetConnPb::PopMessage(bool& bOutHasMessage, uint16& OutMessageType, TSharedPtr<google::protobuf::Message, ESPMode::ThreadSafe>& OutMessage)
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnPb_PopMessage);

	// Default value for output parameters
	bOutHasMessage = false;
	OutMessageType = 0;

	bool bHasMessage = false;
	uint16 MessageType = 0;

	TArray<uint8> MessageBuf;
	bool bSuccess = PopMessageRaw(bHasMessage, MessageType, MessageBuf);

	if (!bSuccess)
	{
		// Error log is in PopMessageRaw function
		return false;
	}

	if (!bHasMessage)
	{
		return true;
	}

	const google::protobuf::Descriptor** Desc = DescMap.Find(MessageType);
	if (Desc == nullptr)
	{
		P3JsonNetConnLog(*this, Error, "Invalid message type", TEXT("MessageType"), MessageType);
		return false;
	}

	TSharedPtr<google::protobuf::Message, ESPMode::ThreadSafe> Message(google::protobuf::MessageFactory::generated_factory()->GetPrototype(*Desc)->New());
	if (!Message.IsValid())
	{
		P3JsonNetConnLog(*this, Error, "Failed to new message", TEXT("MessageType"), MessageType);
		return false;
	}

	if (MessageBuf.Num() > 0)
	{
		bSuccess = Message->ParseFromArray(MessageBuf.GetData(), MessageBuf.Num());

		if (!bSuccess)
		{
			P3JsonNetConnLog(*this, Error, "Failed to new message", TEXT("MessageType"), MessageType);
			return false;
		}
	}

	// Set output parameters
	bOutHasMessage = true;
	OutMessageType = MessageType;
	OutMessage = Message;

	return true;
}
