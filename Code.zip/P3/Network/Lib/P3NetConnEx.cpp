// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetConnEx.h"
#include "P3Packer.h"
#include "P3Log.h"
#include "SocketSubsystem.h"
#include "Sockets.h"

DECLARE_CYCLE_STAT(TEXT("P3NetConnEx Send"), STAT_P3NetConnEx_Send, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnEx Flush"), STAT_P3NetConnEx_Flush, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnEx Flush_SocketSend"), STAT_P3NetConnEx_Flush_SocketSend, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnEx Recv"), STAT_P3NetConnEx_Recv, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnEx Recv_SocketRecv"), STAT_P3NetConnEx_Recv_SocketRecv, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnEx PopMessage"), STAT_P3NetConnEx_PopMessage, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3NetConnEx PopMessageRaw"), STAT_P3NetConnEx_PopMessageRaw, STATGROUP_P3);

extern TAutoConsoleVariable<int32> CVarP3NetMaxMessageSize;
extern TAutoConsoleVariable<int32> CVarP3NetMaxSendBufferSize;
extern TAutoConsoleVariable<int32> CVarP3NetSimulateSlowReceive;

FP3NetConnEx::FP3NetConnEx(P3NetConnId InId, const FString& InName, TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> InProtocol, int32 InMaxSocketSendPerMessage)
	: FP3NetConn(InId, InName)
	, MaxSocketSendPerMessage(InMaxSocketSendPerMessage)
	, Protocol(InProtocol)
{
	MaxMessageSize = CVarP3NetMaxMessageSize.GetValueOnAnyThread();
	SendMessageBuf.SetNum(MaxMessageSize);
	RecvBuf.SetNum(P3NET_EX_PACKET_HEADER_SIZE + MaxMessageSize);
}

bool FP3NetConnEx::Send(const FP3NetMessage& Message)
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnEx_Send);

	const uint16 Type = Message.GetType();
	int32 MessageSize = 0;
	if (!Message.Pack(SendMessageBuf, MessageSize))
	{
		P3JsonNetConnLog(*this, Error, "Failed to pack message", TEXT("Type"), Type);
		return false;
	}

	if (MessageSize > MaxMessageSize)
	{
		P3JsonNetConnLog(*this, Error, "Max message size exceeded", TEXT("Type"), Type, TEXT("Size"), MessageSize);
		return false;
	}

	const int32 LastPos = SendBuf.Num();
	const int32 NewBufferSize = LastPos + P3NET_EX_PACKET_HEADER_SIZE + MessageSize;

	const int32 MaxSendBufferSize = CVarP3NetMaxSendBufferSize.GetValueOnAnyThread();
	if (NewBufferSize > MaxSendBufferSize)
	{
		P3JsonNetConnLog(*this, Error, "Max send buffer size exceeded",
			TEXT("Type"), Type,
			TEXT("Size"), MessageSize,
			TEXT("MaxSendBufferSize"), MaxSendBufferSize);
		return false;
	}

	SendBuf.SetNum(NewBufferSize);

	int32 Pos = LastPos;
	FP3Packer::PackUInt16LE(SendBuf, Pos, StaticCast<uint16>(MessageSize + 2)); // In ex protocol, size is type size + message size
	FP3Packer::PackUInt16LE(SendBuf, Pos, Type);
	check(Pos == LastPos + P3NET_EX_PACKET_HEADER_SIZE);

	if (MessageSize > 0)
	{
		FMemory::Memcpy(SendBuf.GetData() + Pos, SendMessageBuf.GetData(), StaticCast<SIZE_T>(MessageSize));
	}

	//const FString MessageHead = BytesToHex(&SendBuf[LastPos], P3NET_EX_PACKET_HEADER_SIZE);
	//P3JsonNetConnLog(*this, VeryVerbose, "SendHeader",
	//	TEXT("Size"), StaticCast<int32>(MessageSize),
	//	TEXT("MessageType"), Type,
	//	TEXT("MessageHead"), *MessageHead);

	++StatSentMessages;
	if (NewBufferSize > StatMaxSendBuffer)
	{
		StatMaxSendBuffer = NewBufferSize;
	}

	return true;
}

bool FP3NetConnEx::Flush()
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnEx_Flush);

	if (!ensure(Socket))
	{
		return false;
	}

	if (SendBuf.Num() == 0)
	{
		return true;
	}

	int32 BytesSent = 0;
	bool bSuccess = false;
	{
		SCOPE_CYCLE_COUNTER(STAT_P3NetConnEx_Flush_SocketSend);
		bSuccess = Socket->Send(SendBuf.GetData(), SendBuf.Num(), BytesSent);
	}

	if (BytesSent > 0)
	{
		StatSentBytes += BytesSent;

		const int32 BytesLeft = SendBuf.Num() - BytesSent;
		if (BytesLeft == 0)
		{
			SendBuf.Reset();
		}
		else if (BytesLeft > 0)
		{
			FMemory::Memmove(SendBuf.GetData(), &SendBuf[BytesSent], StaticCast<SIZE_T>(BytesLeft));
			SendBuf.SetNum(BytesLeft);
		}
	}

	if (!bSuccess)
	{
		check(BytesSent == 0);

		ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get();
		check(SocketSubsystem);

		const ESocketErrors Error = SocketSubsystem->GetLastErrorCode();
		if (Error == SE_NO_ERROR || Error == SE_EWOULDBLOCK)
		{
			++StatSendFails;
			P3JsonNetConnLog(*this, Verbose, "Sending packet failed",
				TEXT("Size"), SendBuf.Num(),
				TEXT("BytesSent"), BytesSent,
				TEXT("BufferSize"), SendBuf.Num(),
				TEXT("ErrorCode"), StaticCast<int32>(Error),
				TEXT("Error"), SocketSubsystem->GetSocketError(Error));
		}
		else
		{
			P3JsonNetConnLog(*this, Warning, "Failed to send packet",
				TEXT("Size"), SendBuf.Num(),
				TEXT("BytesSent"), BytesSent,
				TEXT("BufferSize"), SendBuf.Num(),
				TEXT("ErrorCode"), StaticCast<int32>(Error),
				TEXT("Error"), SocketSubsystem->GetSocketError(Error));
			return false;
		}
	}

	return true;
}

bool FP3NetConnEx::Recv()
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnEx_Recv);

	if (!ensure(Socket))
	{
		return false;
	}

#if !UE_BUILD_SHIPPING
	const int32 SimulateSlowReceive = CVarP3NetSimulateSlowReceive.GetValueOnAnyThread();

	if (SimulateSlowReceive > 0)
	{
		++DebugRecvCounter;
		if (DebugRecvCounter % SimulateSlowReceive != 0)
		{
			return true;
		}
		DebugRecvCounter = 0;
	}
#endif

	check(RecvBufPos <= RecvBuf.Num());

	int32 BytesRead = 0;
	bool bSuccess = false;
	{
		SCOPE_CYCLE_COUNTER(STAT_P3NetConnEx_Recv_SocketRecv);
		bSuccess = Socket->Recv(&RecvBuf[RecvBufPos], RecvBuf.Num() - RecvBufPos, BytesRead);
	}

	if (!bSuccess)
	{
		ISocketSubsystem* SocketSubsystem = ISocketSubsystem::Get();
		check(SocketSubsystem);

		const ESocketErrors Error = SocketSubsystem->GetLastErrorCode();
		ensure(Error != SE_EWOULDBLOCK);

		if (Error == SE_NO_ERROR)
		{
			P3JsonNetConnLog(*this, Display, "Connection closed");
		}
		else
		{
			P3JsonNetConnLog(*this, Warning, "Failed to recv packet",
				TEXT("ErrorCode"), StaticCast<int32>(Error),
				TEXT("Error"), SocketSubsystem->GetSocketError(Error));
		}
		return false;
	}

	RecvBufPos += BytesRead;
	StatRecvBytes += BytesRead;

	//P3JsonNetConnLog(*this, VeryVerbose, "Recv",
	//	TEXT("BytesRead"), BytesRead,
	//	TEXT("RecvBufPos"), RecvBufPos);

	return true;
}

bool FP3NetConnEx::PopMessageRaw(bool& bOutHasMessage, uint16& OutMessageType, TArray<uint8>& OutMessageBuf)
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnEx_PopMessageRaw);

	// Default value for output parameters
	bOutHasMessage = false;
	OutMessageType = 0;

	if (RecvBufPos < P3NET_EX_PACKET_HEADER_SIZE)
	{
		// Need more data
		return true;
	}

	int32 ReadPos = 0;
	uint16 MessageSize = 0;

	check(FP3Packer::UnpackUInt16LE(RecvBuf, ReadPos, MessageSize));
	MessageSize -= 2; // In ex protocol, size is type size + message size

	if (StaticCast<int32>(MessageSize) > MaxMessageSize)
	{
		P3JsonNetConnLog(*this, Error, "Too large message size", TEXT("Size"), (int64)MessageSize);
		return false;
	}

	const int32 PacketSize = P3NET_EX_PACKET_HEADER_SIZE + MessageSize;

	if (RecvBufPos < PacketSize)
	{
		// Need more data
		return true;
	}

	uint16 MessageType = 0;
	check(FP3Packer::UnpackUInt16LE(RecvBuf, ReadPos, MessageType));

	//FString MessageHead = BytesToHex(&RecvBuf[ReadPos], 10);
	//P3JsonNetConnLog(*this, VeryVerbose, "PopMessageRaw",
	//	TEXT("Size"), StaticCast<int32>(MessageSize),
	//	TEXT("Seq"), StaticCast<int32>(Seq),
	//	TEXT("RecvSeq"), RecvSeq,
	//	TEXT("MessageType"), MessageType,
	//	TEXT("RecvBufPos"), RecvBufPos,
	//	TEXT("MessageHead"), *MessageHead);

	ensure(ReadPos == P3NET_EX_PACKET_HEADER_SIZE);

	// Set output parameters
	bOutHasMessage = true;
	OutMessageType = MessageType;
	OutMessageBuf.SetNum(MessageSize);

	if (MessageSize > 0)
	{
		FMemory::Memcpy(OutMessageBuf.GetData(), &RecvBuf[ReadPos], MessageSize);
	}

	// Move extra data to front if available
	if (RecvBufPos > PacketSize)
	{
		FMemory::Memmove(RecvBuf.GetData(), &RecvBuf[PacketSize], StaticCast<SIZE_T>(RecvBufPos - PacketSize));
	}

	RecvBufPos -= PacketSize;

	++StatRecvMessages;

	return true;
}

bool FP3NetConnEx::PopMessage(bool& bOutHasMessage, uint16& OutMessageType, TSharedPtr<FP3NetMessage, ESPMode::ThreadSafe>& OutMessage)
{
	SCOPE_CYCLE_COUNTER(STAT_P3NetConnEx_PopMessage);

	// Default value for output parameters
	bOutHasMessage = false;
	OutMessageType = 0;

	bool bHasMessage = false;
	uint16 MessageType = 0;

	TArray<uint8> MessageBuf;
	const bool bSuccess = PopMessageRaw(bHasMessage, MessageType, MessageBuf);

	if (!bSuccess)
	{
		// Error log is in PopMessageRaw function
		return false;
	}

	if (!bHasMessage)
	{
		return true;
	}

	TSharedPtr<FP3NetMessage, ESPMode::ThreadSafe> Message(Protocol->CreateSCMessage(MessageType));

	if (!Message.IsValid())
	{
		P3JsonNetConnLog(*this, Error, "Failed to new message", TEXT("MessageType"), MessageType);
		return false;
	}

	if (MessageBuf.Num() > 0)
	{
		const bool bUnpackSuccess = Message->Unpack(MessageBuf);

		if (!bUnpackSuccess)
		{
			P3JsonNetConnLog(*this, Error, "Failed to new message", TEXT("MessageType"), MessageType);
			return false;
		}
	}

	// Set output parameters
	bOutHasMessage = true;
	OutMessageType = MessageType;
	OutMessage = Message;

	return true;
}
