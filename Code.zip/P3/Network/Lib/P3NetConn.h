// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "IPAddress.h"

#include "P3NetCore.h"
#include "P3Test.h"

//////////////////////////////////////////////////////////////////////////
// FP3NetConn
//////////////////////////////////////////////////////////////////////////

class FP3NetConn
{
public:
	FP3NetConn(P3NetConnId InId, const FString& InConnName);
	virtual ~FP3NetConn() {}

	virtual class FP3NetConnPb* SafeCastToNetConnPb() { return nullptr; }
	virtual class FP3NetConnEx* SafeCastToNetConnEx() { return nullptr; }

	P3NetConnId GetId() const;
	const FString& GetName() const;
	const FString& GetRemoteAddress() const;
	const FP3NetStat& GetStat() const;

	bool Connect(const FString& Hostname, int32 Port);
	bool InitFromSocket(class FSocket* InSocket);
	void Close();
	void UpdateStat();

	void SetEnableStat(bool bEnable) { bEnabledStat = bEnable; }
	bool IsEnabledStat() const { return bEnabledStat; }

	/**
	 * Helper functions for Test
	 */
#if P3_BUILD_WITH_TEST
	void InjectTestSocket(class FSocket* TestSocket);
#endif

protected:
	P3NetConnId Id = INVALID_NETCONNID;
	FString Name;
	class FSocket* Socket = nullptr;
	FString RemoteAddress;

	// Stat
	FP3NetStat Stat;
	double StatUpdateTime = 0.0;
	int32 StatSentBytes = 0;
	int32 StatRecvBytes = 0;
	int32 StatSentMessages = 0;
	int32 StatRecvMessages = 0;
	int32 StatSendFails = 0;
	int32 StatMaxSendBuffer = 0;

	bool bEnabledStat = false;
};
