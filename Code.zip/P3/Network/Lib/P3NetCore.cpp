// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetCore.h"

bool FP3NetUtil::IsUDPConnection(const FP3NetConnInfo& NetConnInfo)
{
	return NetConnInfo.UDPConnId != INVALID_NETCONNID;
}

bool FP3NetUtil::IsTCPConnection(const FP3NetConnInfo& NetConnInfo)
{
	return NetConnInfo.TCPConnId != INVALID_NETCONNID;
}

bool FP3NetUtil::IsNetConnValid(const FP3NetConnInfo& NetConnInfo)
{
	return (NetConnInfo.TCPConnId != INVALID_NETCONNID) || (NetConnInfo.UDPConnId != INVALID_NETCONNID);
}
