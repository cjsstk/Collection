// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetListener.h"
#include "P3Log.h"
#include "SocketSubsystem.h"
#include "Sockets.h"

static TAutoConsoleVariable<int32> CVarP3NetReuseAddr(
	TEXT("p3.netReuseAddr"),
	1,
	TEXT("Use socket option REUSEADDR for p3 network"), ECVF_Default);

P3NetConnId FP3NetListener::GetId() const
{
	return Id;
}

const FString& FP3NetListener::GetConnName() const
{
	return ConnName;
}

const TDescMap& FP3NetListener::GetDescMap() const
{
	return DescMap;
}

int32 FP3NetListener::GetMaxSocketSendPerMessage() const
{
	return MaxSocketSendPerMessage;
}

bool FP3NetListener::Listen(const FString& BindAddress, int32 BindPort, int32 MaxBacklog)
{
	ensure(!Socket);

	if (Socket)
	{
		Close();
	}

	ISocketSubsystem* SocketSubSystem = ISocketSubsystem::Get();
	check(SocketSubSystem);

	TSharedRef<FInternetAddr> Address = SocketSubSystem->CreateInternetAddr();

	bool bIsValid = false;
	Address->SetIp(*BindAddress, bIsValid);
	Address->SetPort(BindPort);

	if (!bIsValid)
	{
		P3JsonNetLog(Error, "Invalid address for bind",
			TEXT("Id"), Id.X,
			TEXT("Name"), *ConnName,
			TEXT("BindAddress"), *BindAddress,
			TEXT("BindPort"), BindPort);
		return false;
	}

	FSocket* NewSocket = SocketSubSystem->CreateSocket(NAME_Stream, TEXT("P3Listener"));

	if (!NewSocket)
	{
		P3JsonNetLog(Fatal, "Failed to create socket", TEXT("Id"), Id.X, TEXT("Name"), *ConnName); //-V111
		return false;
	}

	if (CVarP3NetReuseAddr.GetValueOnAnyThread() > 0)
	{
		P3JsonNetLog(Display, "Set ReuseAddr socket option",
			TEXT("Id"), Id.X,
			TEXT("Name"), *ConnName);
		NewSocket->SetReuseAddr();
	}

	if (!NewSocket->Bind(*Address))
	{
		P3JsonNetLog(Error, "Failed to bind",
			TEXT("Id"), Id.X,
			TEXT("Name"), *ConnName,
			TEXT("BindAddress"), *BindAddress,
			TEXT("BindPort"), BindPort);
		SocketSubSystem->DestroySocket(NewSocket);
		return false;
	}

	if (!NewSocket->Listen(MaxBacklog))
	{
		P3JsonNetLog(Error, "Failed to listen",
			TEXT("Id"), Id.X,
			TEXT("Name"), *ConnName,
			TEXT("BindAddress"), *BindAddress,
			TEXT("BindPort"), BindPort);
		SocketSubSystem->DestroySocket(NewSocket);
		return false;
	}

	Socket = NewSocket;

	return true;
}

void FP3NetListener::Close()
{
	ISocketSubsystem* SocketSubSystem = ISocketSubsystem::Get();
	check(SocketSubSystem);

	if (ensure(Socket))
	{
		Socket->Close();
		SocketSubSystem->DestroySocket(Socket);
		Socket = nullptr;
	}
}

bool FP3NetListener::Accept(FSocket*& ClientSocket)
{
	if (!ensure(Socket))
	{
		return false;
	}

	bool bHasPendingConnection = false;
	const bool bSuccess = Socket->HasPendingConnection(bHasPendingConnection);

	if (!bSuccess)
	{
		return false;
	}

	if (!bHasPendingConnection)
	{
		return true; // Not an error
	}

	ClientSocket = Socket->Accept(TEXT("P3AcceptedSocket"));

	return true;
}
