// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NetThread.h"
#include "P3NetListener.h"
#include "P3NetConn.h"
#include "P3Log.h"
#include "RunnableThread.h"

DECLARE_CYCLE_STAT(TEXT("P3Net_Run"), STAT_P3Net_Run, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_SendPb"), STAT_P3Net_SendPb, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_SendEx"), STAT_P3Net_SendEx, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_HandleRequests"), STAT_P3Net_HandleRequests, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_HandleTasks"), STAT_P3Net_HandleTasks, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_AcceptConns"), STAT_P3Net_AcceptConns, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_FlushMessages"), STAT_P3Net_FlushMessages, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_ReceiveMessages"), STAT_P3Net_ReceiveMessages, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_ReceivePbMessages"), STAT_P3Net_ReceivePbMessages, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_ReceiveExMessages"), STAT_P3Net_ReceiveExMessages, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_UpdateStat"), STAT_P3Net_UpdateStat, STATGROUP_P3);
DECLARE_CYCLE_STAT(TEXT("P3Net_FetchEvents"), STAT_P3Net_FetchEvents, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3Net Num Conns"), STAT_P3Net_NumConns, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3Net Num Listeners"), STAT_P3Net_NumListeners, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3Net Num Tasks"), STAT_P3Net_NumTasks, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3Net Num Requests"), STAT_P3Net_NumRequests, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3Net Num Events"), STAT_P3Net_NumEvents, STATGROUP_P3);
DECLARE_DWORD_COUNTER_STAT(TEXT("P3Net Num FetchEvents"), STAT_P3Net_NumFetchEvents, STATGROUP_P3);

TAutoConsoleVariable<int32> CVarP3NetStatDumpIntervalMsec(
	TEXT("p3.netStatDumpIntervalMsec"),
	10000,
	TEXT("Stat dump interval. If 0, do not dump"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3NetDelayMsec(
	TEXT("p3.netDelayMsec"),
	0,
	TEXT("Simulate net latency. If not 0, 0 ~ Value of Random delay will be added"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3NetRecvDelayMsec(
	TEXT("p3.netRecvDelayMsec"),
	0,
	TEXT("Simulate net receive delay. If not 0, received packet will be processed after fixed delay"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3NetMaxFlushTryNumForGracefulShutdown(
	TEXT("p3.netMaxFlushTryNumForGracefulShutdown"),
	10,
	TEXT("Maximum number of flush attempts for graceful shutdown"), ECVF_Cheat);

//////////////////////////////////////////////////////////////////////////
// FP3NetRequest
//////////////////////////////////////////////////////////////////////////

enum class EP3NetRequestType
{
	ConnectPb,
	ConnectEx,
	Listen,
	SendPb,
	SendEx,
	Close,
};

struct FP3NetRequest
{
	virtual ~FP3NetRequest() {}

	virtual EP3NetRequestType GetType() const = 0;
	virtual const struct FP3NetConnectPbRequest* SafeCastToConnectPbRequest() const { return nullptr; }
	virtual const struct FP3NetConnectExRequest* SafeCastToConnectExRequest() const { return nullptr; }
	virtual const struct FP3NetListenRequest* SafeCastToListenRequest() const { return nullptr; }
	virtual const struct FP3NetSendPbRequest* SafeCastToSendPbRequest() const { return nullptr; }
	virtual const struct FP3NetSendExRequest* SafeCastToSendExRequest() const { return nullptr; }
	virtual const struct FP3NetCloseRequest* SafeCastToCloseRequest() const { return nullptr; }

	P3NetConnId ConnId = INVALID_NETCONNID;
};

struct FP3NetConnectPbRequest : public FP3NetRequest
{
	virtual EP3NetRequestType GetType() const { return EP3NetRequestType::ConnectPb; }
	virtual const struct FP3NetConnectPbRequest* SafeCastToConnectPbRequest() const override { return this; }

	FP3NetConnectParams Params;
	TDescMap DescMap;
};

struct FP3NetConnectExRequest : public FP3NetRequest
{
	virtual EP3NetRequestType GetType() const { return EP3NetRequestType::ConnectEx; }
	virtual const struct FP3NetConnectExRequest* SafeCastToConnectExRequest() const override { return this; }

	FP3NetConnectParams Params;
	TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol;
};

struct FP3NetListenRequest : public FP3NetRequest
{
	virtual EP3NetRequestType GetType() const { return EP3NetRequestType::Listen; }
	virtual const struct FP3NetListenRequest* SafeCastToListenRequest() const override { return this; }

	FString ConnName;
	FString BindAddress;
	int32 BindPort = 0;
	int32 MaxBacklog = 5;
	int32 MaxSocketSendPerMessage = 0;
	TDescMap DescMap;
	float RetryIntervalSeconds = 0.0f;
	bool bEnableStat = false;
};

struct FP3NetSendPbRequest : public FP3NetRequest
{
	FP3NetSendPbRequest(TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> InMessage)
		: Message(InMessage)
	{}

	virtual EP3NetRequestType GetType() const { return EP3NetRequestType::SendPb; }
	virtual const struct FP3NetSendPbRequest* SafeCastToSendPbRequest() const override { return this; }

	uint16 Type = 0;
	TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message;
};

struct FP3NetSendExRequest : public FP3NetRequest
{
	FP3NetSendExRequest(TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> InMessage)
		: Message(InMessage)
	{}

	virtual EP3NetRequestType GetType() const { return EP3NetRequestType::SendEx; }
	virtual const struct FP3NetSendExRequest* SafeCastToSendExRequest() const override { return this; }

	TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> Message;
};

struct FP3NetCloseRequest : public FP3NetRequest
{
	virtual EP3NetRequestType GetType() const { return EP3NetRequestType::Close; }
	virtual const struct FP3NetCloseRequest* SafeCastToCloseRequest() const override { return this; }
};

//////////////////////////////////////////////////////////////////////////
// FP3NetThread
//////////////////////////////////////////////////////////////////////////

#define CHECK_GAME_THREAD check(IsInGameThread())
#define CHECK_NETWORK_THREAD check(!IsInGameThread())

FP3NetThread::FP3NetThread(const TCHAR* ThreadName)
{
	CHECK_GAME_THREAD;

	Thread = FRunnableThread::Create(this, ThreadName, 0, TPri_AboveNormal);
}

bool FP3NetThread::Init()
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Display, "Initialize P3NetThread");

	return true;
}

uint32 FP3NetThread::Run()
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Display, "Start running P3NetThread");

	while (!bStop)
	{
		// TODO: Replace with socket select or event-based something
		FPlatformProcess::Sleep(0.001f);

		const double StartTimeSeconds = FPlatformTime::Seconds();

		SET_DWORD_STAT(STAT_P3Net_NumConns, Conns.Num());
		SET_DWORD_STAT(STAT_P3Net_NumListeners, Listeners.Num());
		SET_DWORD_STAT(STAT_P3Net_NumTasks, Tasks.Num());

		RequestsLocker.ReadLock();
		const int32 RequestsNum = Requests.Num();
		RequestsLocker.ReadUnlock();

		SET_DWORD_STAT(STAT_P3Net_NumRequests, RequestsNum);

		EventsLocker.ReadLock();
		const int32 EventsNum = Events.Num();
		EventsLocker.ReadUnlock();

		SET_DWORD_STAT(STAT_P3Net_NumEvents, EventsNum);

		{
			SCOPE_CYCLE_COUNTER(STAT_P3Net_Run);

			HandleRequests();
			AcceptConns();
			FlushMessages();
			ReceiveMessages();
			HandleTasks();
		}

		if (CVarP3NetDelayMsec.GetValueOnAnyThread() != 0)
		{
			const int32 RandomMsec = FMath::Rand() % CVarP3NetDelayMsec.GetValueOnAnyThread();
			FPlatformProcess::Sleep(RandomMsec * 0.001f);
		}

		const int32 TickTimeMsec = FMath::TruncToInt((FPlatformTime::Seconds() - StartTimeSeconds) * 1000.0);
		UpdateStat(TickTimeMsec);
	}

	// Try to handle requests added before stop signal
	HandleRequests();

	// Try to flush remaining data
	int32 TryNum = 0;
	while (true)
	{
		FlushMessages();

		bool bHasRemainingData = false;
		for (TSharedRef<FP3NetConn> Conn : Conns)
		{
			FP3NetConnPb* ConnPb = Conn->SafeCastToNetConnPb();
			if (ConnPb && ConnPb->HasRemainingData())
			{
				bHasRemainingData = true;
				break;
			}

			FP3NetConnEx* ConnEx = Conn->SafeCastToNetConnEx();
			if (ConnEx && ConnEx->HasRemainingData())
			{
				bHasRemainingData = true;
				break;
			}
		}

		if (!bHasRemainingData)
		{
			break;
		}

		++TryNum;

		if (TryNum >= CVarP3NetMaxFlushTryNumForGracefulShutdown.GetValueOnAnyThread())
		{
			P3JsonNetLog(Error, "There is unsent data but shutdown anyway");
			break;
		}
	}

	return 0;
}

void FP3NetThread::Stop()
{
	CHECK_GAME_THREAD;

	P3JsonNetLog(Display, "Stop P3NetThread");

	bStop = true;
}

void FP3NetThread::Exit()
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Display, "Exit P3NetThread");

	RequestsLocker.WriteLock();
	Requests.Empty();
	RequestsLocker.WriteUnlock();

	EventsLocker.WriteLock();
	Events.Empty();
	EventsLocker.WriteUnlock();

	Tasks.Empty();

	for (TSharedRef<FP3NetConn> Conn : Conns)
	{
		Conn->Close();
	}
	Conns.Empty();

	for (TSharedRef<FP3NetListener> Listener : Listeners)
	{
		Listener->Close();
	}
	Listeners.Empty();
}

void FP3NetThread::EnsureCompletion()
{
	CHECK_GAME_THREAD;

	Stop();

	if (Thread)
	{
		Thread->WaitForCompletion();
	}
}

P3NetConnId FP3NetThread::CreateConnPb(const FP3NetConnectParams& Params, const TDescMap& DescMap)
{
	CHECK_GAME_THREAD;

	const P3NetConnId ConnId(NextConnId.Increment());

	TSharedRef<FP3NetConnectPbRequest, ESPMode::ThreadSafe> Request(new FP3NetConnectPbRequest());
	Request->ConnId = ConnId;
	Request->Params = Params;
	Request->DescMap = DescMap;

	RequestsLocker.WriteLock();
	Requests.Add(Request);
	RequestsLocker.WriteUnlock();

	return ConnId;
}

P3NetConnId FP3NetThread::CreateConnEx(const FP3NetConnectParams& Params, TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol)
{
	CHECK_GAME_THREAD;

	const P3NetConnId ConnId(NextConnId.Increment());

	TSharedRef<FP3NetConnectExRequest, ESPMode::ThreadSafe> Request(new FP3NetConnectExRequest());
	Request->ConnId = ConnId;
	Request->Params = Params;
	Request->Protocol = Protocol;

	RequestsLocker.WriteLock();
	Requests.Add(Request);
	RequestsLocker.WriteUnlock();

	return ConnId;
}

P3NetConnId FP3NetThread::CreateListener(const FString& ConnName, const FString& BindAddress, int32 BindPort, int32 MaxBacklog, const TDescMap& DescMap, float RetryIntervalSeconds, int32 MaxSocketSendPerMessage, bool bEnableStat)
{
	CHECK_GAME_THREAD;

	P3NetConnId ConnId(NextConnId.Increment());

	TSharedRef<FP3NetListenRequest, ESPMode::ThreadSafe> Request(new FP3NetListenRequest());
	Request->ConnId = ConnId;
	Request->ConnName = ConnName;
	Request->BindAddress = BindAddress;
	Request->BindPort = BindPort;
	Request->MaxBacklog = MaxBacklog;
	Request->MaxSocketSendPerMessage = MaxSocketSendPerMessage;
	Request->DescMap = DescMap;
	Request->RetryIntervalSeconds = RetryIntervalSeconds;
	Request->bEnableStat = bEnableStat;

	RequestsLocker.WriteLock();
	Requests.Add(Request);
	RequestsLocker.WriteUnlock();

	return ConnId;
}

void FP3NetThread::SendPb(P3NetConnId ConnId, uint16 MessageType, TSharedRef<const ::google::protobuf::Message, ESPMode::ThreadSafe> Message)
{
	CHECK_GAME_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_SendPb);

	TSharedRef<FP3NetSendPbRequest, ESPMode::ThreadSafe> Request(new FP3NetSendPbRequest(Message));
	Request->ConnId = ConnId;
	Request->Type = MessageType;

	FRWScopeLock RequestsLock(RequestsLocker, SLT_Write);
	Requests.Add(Request);
}

void FP3NetThread::SendEx(P3NetConnId ConnId, TSharedRef<const FP3NetMessage, ESPMode::ThreadSafe> Message)
{
	CHECK_GAME_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_SendEx);

	TSharedRef<FP3NetSendExRequest, ESPMode::ThreadSafe> Request(new FP3NetSendExRequest(Message));
	Request->ConnId = ConnId;

	FRWScopeLock RequestsLock(RequestsLocker, SLT_Write);
	Requests.Add(Request);
}

void FP3NetThread::CloseConn(P3NetConnId ConnId)
{
	CHECK_GAME_THREAD;

	TSharedRef<FP3NetCloseRequest, ESPMode::ThreadSafe> Request(new FP3NetCloseRequest());
	Request->ConnId = ConnId;

	FRWScopeLock RequestsLock(RequestsLocker, SLT_Write);
	Requests.Add(Request);
}

void FP3NetThread::HandleRequests()
{
	CHECK_NETWORK_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_HandleRequests);

	TArray<P3NetRequestSharedPtr> NewRequests;

	RequestsLocker.WriteLock();
	Exchange(Requests, NewRequests);
	RequestsLocker.WriteUnlock();

	for (P3NetRequestSharedPtr Request : NewRequests)
	{
		switch (Request->GetType())
		{
		case EP3NetRequestType::ConnectPb:
			HandleConnectPbRequest(*Request->SafeCastToConnectPbRequest());
			break;

		case EP3NetRequestType::ConnectEx:
			HandleConnectExRequest(*Request->SafeCastToConnectExRequest());
			break;

		case EP3NetRequestType::Listen:
			HandleListenRequest(*Request->SafeCastToListenRequest());
			break;

		case EP3NetRequestType::SendPb:
			HandleSendPbRequest(*Request->SafeCastToSendPbRequest());
			break;

		case EP3NetRequestType::SendEx:
			HandleSendExRequest(*Request->SafeCastToSendExRequest());
			break;

		case EP3NetRequestType::Close:
			HandleCloseRequest(*Request->SafeCastToCloseRequest());
			break;

		default:
			P3JsonNetLog(Error, "Unknown network request type", TEXT("Type"), StaticCast<int>(Request->GetType()));
		}
	}
}

void FP3NetThread::HandleConnectPbRequest(const FP3NetConnectPbRequest& Request)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle ConnectRequest");

	TSharedRef<FP3NetConnectPbTask> Task(new FP3NetConnectPbTask());
	Task->ScheduleTimeSeconds = FPlatformTime::Seconds() + Request.Params.InitialDelaySeconds;
	Task->ConnId = Request.ConnId;
	Task->Params = Request.Params;
	Task->DescMap = Request.DescMap;
	Task->RetryCount = 0;

	Tasks.HeapPush(Task, FP3NetTaskComparer());
}

void FP3NetThread::HandleConnectExRequest(const FP3NetConnectExRequest& Request)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle ConnectRequest");

	TSharedRef<FP3NetConnectExTask> Task(new FP3NetConnectExTask());
	Task->ScheduleTimeSeconds = FPlatformTime::Seconds() + Request.Params.InitialDelaySeconds;
	Task->ConnId = Request.ConnId;
	Task->Params = Request.Params;
	Task->Protocol = Request.Protocol;
	Task->RetryCount = 0;

	Tasks.HeapPush(Task, FP3NetTaskComparer());
}

void FP3NetThread::HandleListenRequest(const FP3NetListenRequest& Request)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle ListenRequest");

	TSharedRef<FP3NetListenTask> Task(new FP3NetListenTask());
	Task->ScheduleTimeSeconds = FPlatformTime::Seconds();
	Task->ConnId = Request.ConnId;
	Task->ConnName = Request.ConnName;
	Task->BindAddress = Request.BindAddress;
	Task->BindPort = Request.BindPort;
	Task->MaxBacklog = Request.MaxBacklog;
	Task->MaxSocketSendPerMessage = Request.MaxSocketSendPerMessage;
	Task->DescMap = Request.DescMap;
	Task->RetryIntervalSeconds = Request.RetryIntervalSeconds;
	Task->bEnableStat = Request.bEnableStat;

	Tasks.HeapPush(Task, FP3NetTaskComparer());
}

void FP3NetThread::HandleSendPbRequest(const FP3NetSendPbRequest& Request)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle SendRequest");

	TSharedRef<FP3NetConn>* ConnPtr = Conns.FindByPredicate([&Request](TSharedRef<const FP3NetConn> Conn) { return Conn->GetId() == Request.ConnId; });
	if (!ConnPtr)
	{
		P3JsonNetLog(Verbose, "Cannot find connection", TEXT("ConnId"), Request.ConnId.X);
		return;
	}

	TSharedRef<FP3NetConnPb> Conn = StaticCastSharedRef<FP3NetConnPb>(*ConnPtr);
	const bool bSuccess = Conn->Send(Request.Type, *Request.Message);

	if (!bSuccess)
	{
		P3JsonNetConnLog(*Conn, Warning, "Failed to send message");
		CloseConn(Conn);
	}
}

void FP3NetThread::HandleSendExRequest(const FP3NetSendExRequest& Request)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle SendRequest");

	TSharedRef<FP3NetConn>* ConnPtr = Conns.FindByPredicate([&Request](TSharedRef<const FP3NetConn> Conn) { return Conn->GetId() == Request.ConnId; });
	if (!ConnPtr)
	{
		P3JsonNetLog(Verbose, "Cannot find connection", TEXT("ConnId"), Request.ConnId.X);
		return;
	}

	TSharedRef<FP3NetConnEx> Conn = StaticCastSharedRef<FP3NetConnEx>(*ConnPtr);
	const bool bSuccess = Conn->Send(*Request.Message);

	if (!bSuccess)
	{
		P3JsonNetConnLog(*Conn, Warning, "Failed to send message");
		CloseConn(Conn);
	}
}

void FP3NetThread::HandleCloseRequest(const FP3NetCloseRequest& Request)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle CloseRequest");

	TSharedRef<FP3NetConn>* ConnPtr = Conns.FindByPredicate([&Request](TSharedRef<const FP3NetConn> Conn) { return Conn->GetId() == Request.ConnId; });
	if (!ConnPtr)
	{
		P3JsonNetLog(Warning, "Cannot find connection", TEXT("ConnId"), Request.ConnId.X);
		return;
	}

	CloseConn(*ConnPtr);
}

void FP3NetThread::HandleTasks()
{
	CHECK_NETWORK_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_HandleTasks);

	Tasks.VerifyHeap(FP3NetTaskComparer());

	while (Tasks.Num() > 0)
	{
		if (Tasks.HeapTop()->ScheduleTimeSeconds > FPlatformTime::Seconds())
		{
			return;
		}

		TSharedPtr<FP3NetTask> Task;
		Tasks.HeapPop(Task, FP3NetTaskComparer());

		switch (Task->GetType())
		{
		case EP3NetTaskType::Listen:
			HandleListenTask(*Task->SafeCastToListenTask());
			break;

		case EP3NetTaskType::ConnectPb:
			HandleConnectPbTask(*Task->SafeCastToConnectPbTask());
			break;

		case EP3NetTaskType::ConnectEx:
			HandleConnectExTask(*Task->SafeCastToConnectExTask());
			break;

		default:
			P3JsonNetLog(Error, "Unknown network request type", TEXT("Type"), StaticCast<int>(Task->GetType()));
		}
	}
}

void FP3NetThread::HandleListenTask(const FP3NetListenTask& Task)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle ListenTask");

	TSharedRef<FP3NetListener> Listener(new FP3NetListener(Task.ConnId, Task.ConnName, Task.DescMap, Task.MaxSocketSendPerMessage));
	const bool bSuccess = Listener->Listen(Task.BindAddress, Task.BindPort, Task.MaxBacklog);

	if (!bSuccess)
	{
		P3JsonNetLog(Warning, "Failed to listen",
			TEXT("BindAddress"), *Task.BindAddress,
			TEXT("BindPort"), Task.BindPort);

		TSharedRef<FP3NetListenTask> NewTask(new FP3NetListenTask());
		*NewTask = Task;

		NewTask->ScheduleTimeSeconds = FPlatformTime::Seconds() + NewTask->RetryIntervalSeconds;
		Tasks.HeapPush(NewTask, FP3NetTaskComparer());
		return;
	}

	Listener->SetEnableStat(Task.bEnableStat);

	Listeners.Add(Listener);

	TSharedRef<FP3NetListenEvent, ESPMode::ThreadSafe> Event(new FP3NetListenEvent());
	Event->ConnId = Task.ConnId;
	Event->bSuccess = bSuccess;

	P3JsonNetLog(Verbose, "Fire ListenEvent",
		TEXT("ConnId"), Event->ConnId.X,
		TEXT("bSuccess"), Event->bSuccess);

	FRWScopeLock EventsLock(EventsLocker, SLT_Write);
	Events.Add(Event);
}

void FP3NetThread::HandleConnectPbTask(const FP3NetConnectPbTask& Task)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle ConnectTask");

	TSharedRef<FP3NetConn> Conn(new FP3NetConnPb(Task.ConnId, Task.Params.Name, Task.DescMap, Task.Params.MaxSocketSendPerMessage));
	const bool bConnected = Conn->Connect(*Task.Params.Host, Task.Params.Port);

	if (!bConnected)
	{
		P3JsonNetConnLog(*Conn, Warning, "Failed to connect",
			TEXT("Hostname"), *Task.Params.Host,
			TEXT("Port"), Task.Params.Port);

		TSharedRef<FP3NetConnectPbTask> NewTask(new FP3NetConnectPbTask());
		*NewTask = Task;

		if (NewTask->RetryCount < NewTask->Params.MaxRetryCount)
		{
			P3JsonNetConnLog(*Conn, Warning, "Retry",
				TEXT("RetryCount"), NewTask->RetryCount,
				TEXT("MaxRetryCount"), NewTask->Params.MaxRetryCount,
				TEXT("RetryIntervalSeconds"), NewTask->Params.RetryIntervalSeconds);

			NewTask->RetryCount += 1;
			NewTask->ScheduleTimeSeconds = FPlatformTime::Seconds() + NewTask->Params.RetryIntervalSeconds;
			Tasks.HeapPush(NewTask, FP3NetTaskComparer());
			return;
		}
	}

	if (bConnected)
	{
		Conn->SetEnableStat(Task.Params.bEnableStat);

		Conns.Add(Conn);
	}

	TSharedRef<FP3NetConnectEvent, ESPMode::ThreadSafe> Event(new FP3NetConnectEvent());
	Event->ConnId = Task.ConnId;
	Event->bSuccess = bConnected;

	P3JsonNetConnLog(*Conn, Verbose, "Fire ConnectEvent", TEXT("bSuccess"), Event->bSuccess);

	FRWScopeLock EventsLock(EventsLocker, SLT_Write);
	Events.Add(Event);
}

void FP3NetThread::HandleConnectExTask(const FP3NetConnectExTask& Task)
{
	CHECK_NETWORK_THREAD;

	P3JsonNetLog(Verbose, "Handle ConnectTask");

	TSharedRef<FP3NetConn> Conn(new FP3NetConnEx(Task.ConnId, Task.Params.Name, Task.Protocol, Task.Params.MaxSocketSendPerMessage));
	const bool bConnected = Conn->Connect(*Task.Params.Host, Task.Params.Port);

	if (!bConnected)
	{
		P3JsonNetConnLog(*Conn, Warning, "Failed to connect",
			TEXT("Hostname"), *Task.Params.Host,
			TEXT("Port"), Task.Params.Port);

		TSharedRef<FP3NetConnectExTask> NewTask(new FP3NetConnectExTask());
		*NewTask = Task;

		if (NewTask->RetryCount < NewTask->Params.MaxRetryCount)
		{
			P3JsonNetConnLog(*Conn, Warning, "Retry",
				TEXT("RetryCount"), NewTask->RetryCount,
				TEXT("MaxRetryCount"), NewTask->Params.MaxRetryCount,
				TEXT("RetryIntervalSeconds"), NewTask->Params.RetryIntervalSeconds);

			NewTask->RetryCount += 1;
			NewTask->ScheduleTimeSeconds = FPlatformTime::Seconds() + NewTask->Params.RetryIntervalSeconds;
			Tasks.HeapPush(NewTask, FP3NetTaskComparer());
			return;
		}
	}

	if (bConnected)
	{
		Conn->SetEnableStat(Task.Params.bEnableStat);

		Conns.Add(Conn);
	}

	TSharedRef<FP3NetConnectEvent, ESPMode::ThreadSafe> Event(new FP3NetConnectEvent());
	Event->ConnId = Task.ConnId;
	Event->bSuccess = bConnected;

	P3JsonNetConnLog(*Conn, Verbose, "Fire ConnectEvent", TEXT("bSuccess"), Event->bSuccess);

	FRWScopeLock EventsLock(EventsLocker, SLT_Write);
	Events.Add(Event);
}

void FP3NetThread::AcceptConns()
{
	CHECK_NETWORK_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_AcceptConns);

	TArray<TSharedRef<FP3NetListener>> ListenersToBeClosed;

	for (TSharedRef<FP3NetListener> Listener : Listeners)
	{
		FSocket* ClientSocket = nullptr;
		bool bSuccess = Listener->Accept(ClientSocket);

		if (!bSuccess)
		{
			ListenersToBeClosed.Add(Listener);
			continue;
		}

		if (!ClientSocket)
		{
			continue;
		}

		P3NetConnId NewConnId(NextConnId.Increment());

		TSharedRef<FP3NetConn> Conn(new FP3NetConnPb(NewConnId, Listener->GetConnName(), Listener->GetDescMap(), Listener->GetMaxSocketSendPerMessage()));
		Conn->InitFromSocket(ClientSocket);

		Conn->SetEnableStat(Listener->IsEnabledStat() ? true : false);

		Conns.Add(Conn);

		TSharedRef<FP3NetAcceptEvent, ESPMode::ThreadSafe> Event(new FP3NetAcceptEvent());
		Event->ConnId = Listener->GetId();
		Event->AcceptedConnId = Conn->GetId();

		P3JsonNetConnLog(*Conn, Verbose, "Fire AcceptEvent", TEXT("ListenerConnId"), Event->ConnId.X);

		EventsLocker.WriteLock();
		Events.Add(Event);
		EventsLocker.WriteUnlock();
	}

	for (TSharedRef<FP3NetListener>& Listener : ListenersToBeClosed)
	{
		Listener->Close();
	}
}

void FP3NetThread::FlushMessages()
{
	CHECK_NETWORK_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_FlushMessages);

	TArray<TSharedRef<FP3NetConn>> ConnsToBeClosed;

	for (TSharedRef<FP3NetConn> Conn : Conns)
	{
		bool bSuccess = true;

		FP3NetConnPb* ConnPb = Conn->SafeCastToNetConnPb();
		if (ConnPb)
		{
			bSuccess = ConnPb->Flush();
		}

		FP3NetConnEx* ConnEx = Conn->SafeCastToNetConnEx();
		if (ConnEx)
		{
			bSuccess = ConnEx->Flush();
		}

		if (!bSuccess)
		{
			ConnsToBeClosed.Add(Conn);
		}
	}

	for (TSharedRef<FP3NetConn>& Conn : ConnsToBeClosed)
	{
		CloseConn(Conn);
	}

}

void FP3NetThread::ReceiveMessages()
{
	CHECK_NETWORK_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_ReceiveMessages);

	TArray<TSharedRef<FP3NetConn>> ConnsToBeClosed;

	for (TSharedRef<FP3NetConn> Conn : Conns)
	{
		bool bSuccess = false;

		FP3NetConnPb* ConnPb = Conn->SafeCastToNetConnPb();

		if (ConnPb)
		{
			bSuccess = ReceivePbMessages(*ConnPb);
		}

		FP3NetConnEx* ConnEx = Conn->SafeCastToNetConnEx();

		if (ConnEx)
		{
			bSuccess = ReceiveExMessages(*ConnEx);
		}

		if (!bSuccess)
		{
			ConnsToBeClosed.Add(Conn);
		}
	}

	for (TSharedRef<FP3NetConn>& Conn : ConnsToBeClosed)
	{
		CloseConn(Conn);
	}
}

bool FP3NetThread::ReceivePbMessages(FP3NetConnPb& Conn)
{
	SCOPE_CYCLE_COUNTER(STAT_P3Net_ReceivePbMessages);

	const bool bSuccess = Conn.Recv();

	if (!bSuccess)
	{
		return false;
	}

	while (true)
	{
		bool bHasMessage;
		uint16 MessageType = 0;
		TSharedPtr<google::protobuf::Message, ESPMode::ThreadSafe> Message = nullptr;
		const bool bPopSuccess = Conn.PopMessage(bHasMessage, MessageType, Message);

		if (!bPopSuccess)
		{
			return false;
		}

		if (!bHasMessage)
		{
			return true;
		}

		check(MessageType != 0 && Message.IsValid());

		TSharedRef<FP3NetRecvPbEvent, ESPMode::ThreadSafe> Event(new FP3NetRecvPbEvent(Message.ToSharedRef()));
		Event->ConnId = Conn.GetId();
		Event->MessageType = MessageType;

		P3JsonNetConnLog(Conn, Verbose, "Fire RecvEvent", TEXT("MessageType"), Event->MessageType);

		EventsLocker.WriteLock();
		Events.Add(Event);
		EventsLocker.WriteUnlock();
	}

	return true;
}

bool FP3NetThread::ReceiveExMessages(FP3NetConnEx& Conn)
{
	SCOPE_CYCLE_COUNTER(STAT_P3Net_ReceiveExMessages);

	const bool bSuccess = Conn.Recv();

	if (!bSuccess)
	{
		return false;
	}

	while (true)
	{
		bool bHasMessage;
		uint16 MessageType = 0;
		TSharedPtr<FP3NetMessage, ESPMode::ThreadSafe> Message = nullptr;
		const bool bPopSuccess = Conn.PopMessage(bHasMessage, MessageType, Message);

		if (!bPopSuccess)
		{
			return false;
		}

		if (!bHasMessage)
		{
			return true;
		}

		check(MessageType != 0 && Message.IsValid());

		TSharedRef<FP3NetRecvExEvent, ESPMode::ThreadSafe> Event(new FP3NetRecvExEvent(Message.ToSharedRef()));
		Event->ConnId = Conn.GetId();
		Event->MessageType = MessageType;

		P3JsonNetConnLog(Conn, Verbose, "Fire RecvEvent", TEXT("MessageType"), Event->MessageType);

		EventsLocker.WriteLock();
		Events.Add(Event);
		EventsLocker.WriteUnlock();
	}

	return true;
}

void FP3NetThread::UpdateStat(int32 TickTimeMsec)
{
	CHECK_NETWORK_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_UpdateStat);

	int32 TotalSentBytesPerSecond = 0;
	int32 TotalRecvBytesPerSecond = 0;
	int32 TotalSentMessagesPerSecond = 0;
	int32 TotalRecvMessagesPerSecond = 0;

	int NumConns = 0;
	int32 MaxSendFailsPerSecond = 0;
	TSharedPtr<FP3NetConn> MaxSendFailConn;
	int32 MaxSendBufferInSecond = 0;
	TSharedPtr<FP3NetConn> MaxSendBufferConn;

	for (TSharedRef<FP3NetConn> Conn : Conns)
	{
		if (!Conn->IsEnabledStat())
		{
			continue;
		}

		Conn->UpdateStat();
		const FP3NetStat& Stat = Conn->GetStat();
		TotalSentBytesPerSecond += Stat.SentBytesPerSecond;
		TotalRecvBytesPerSecond += Stat.RecvBytesPerSecond;
		TotalSentMessagesPerSecond += Stat.SentMessagesPerSecond;
		TotalRecvMessagesPerSecond += Stat.RecvMessagesPerSecond;

		if (Stat.StatSendFailsPerSecond > MaxSendFailsPerSecond)
		{
			MaxSendFailsPerSecond = Stat.StatSendFailsPerSecond;
			MaxSendFailConn = Conn;
		}

		if (Stat.StatMaxSendBuffer > MaxSendBufferInSecond)
		{
			MaxSendBufferInSecond = Stat.StatMaxSendBuffer;
			MaxSendBufferConn = Conn;
		}

		++NumConns;
	}

	if (NumConns > 0)
	{
		AvgSentBytesPerSecond.Set(TotalSentBytesPerSecond / NumConns);
		AvgRecvBytesPerSecond.Set(TotalRecvBytesPerSecond / NumConns);
		AvgSentMessagesPerSecond.Set(TotalSentMessagesPerSecond / NumConns);
		AvgRecvMessagesPerSecond.Set(TotalRecvMessagesPerSecond / NumConns);
	}
	else
	{
		AvgSentBytesPerSecond.Reset();
		AvgRecvBytesPerSecond.Reset();
		AvgSentMessagesPerSecond.Reset();
		AvgRecvMessagesPerSecond.Reset();
	}

	// 일정 간격으로 덤프를 남긴다. (누적 평균은 아니며 덤프 시점 기준 샘플 값이다)
	const double Now = FPlatformTime::Seconds();
	const double StatDumpIntervalSeconds = (double)CVarP3NetStatDumpIntervalMsec.GetValueOnAnyThread() / 1000.0;
	if (Now - LastStatDumpTimeSeconds >= StatDumpIntervalSeconds)
	{
		// 서버 로그에서 이 로그만 실시간으로 관찰하고 싶다면 p3.jsonLogSingleLine를 1로 켜고 아래 명령어를 사용한다.
		// tail -f P3.log | grep "Network Statistics" | sed -e "s/.*Display: //" | jq .
		// 특정 필드만 보고 싶거나 포멧팅해서 보고 싶다면 jq의 -r 옵션을 사용할 수 있다.
		// 예제) jq -r "(.TickTime | tostring) + \" \" + (.TotalSentBytesPerSecond | tostring)"
		P3JsonNetLog(Display, "Network Statistics (PerSecond)",
			TEXT("TickTime"), TickTimeMsec,
			TEXT("SentBytes"), TotalSentBytesPerSecond,
			TEXT("RecvBytes"), TotalRecvBytesPerSecond,
			TEXT("SentMessages"), TotalSentMessagesPerSecond,
			TEXT("RecvMessages"), TotalRecvMessagesPerSecond,
			TEXT("MaxSendFails"), MaxSendFailsPerSecond,
			TEXT("MaxSendFailRemote"), MaxSendFailConn.IsValid() ? *MaxSendFailConn->GetRemoteAddress() : TEXT("None"),
			TEXT("MaxSendBuffer"), MaxSendBufferInSecond,
			TEXT("MaxSendBufferRemote"), MaxSendBufferConn.IsValid() ? *MaxSendBufferConn->GetRemoteAddress() : TEXT("None"));

		LastStatDumpTimeSeconds = Now;
	}
}

void FP3NetThread::CloseConn(TSharedRef<FP3NetConn> Conn)
{
	CHECK_NETWORK_THREAD;

	Conn->Close();
	Conns.RemoveSwap(Conn);

	TSharedRef<FP3NetCloseEvent, ESPMode::ThreadSafe> Event(new FP3NetCloseEvent());
	Event->ConnId = Conn->GetId();

	P3JsonNetConnLog(*Conn, Verbose, "Fire CloseEvent");

	FRWScopeLock EventsLock(EventsLocker, SLT_Write);
	Events.Add(Event);
}

TArray<TSharedRef<const FP3NetEvent, ESPMode::ThreadSafe>> FP3NetThread::FetchEvents()
{
	CHECK_GAME_THREAD;
	SCOPE_CYCLE_COUNTER(STAT_P3Net_FetchEvents);

	TArray<TSharedRef<const FP3NetEvent, ESPMode::ThreadSafe>> OutEvents;

	const double DelaySeconds = (double)CVarP3NetRecvDelayMsec.GetValueOnAnyThread() / 1000.0;
	if (DelaySeconds <= 0)
	{
		EventsLocker.WriteLock();
		OutEvents = MoveTemp(Events);
		EventsLocker.WriteUnlock();
	}
	else
	{
		EventsLocker.WriteLock();
		const double CurrentTimeSeconds = FPlatformTime::Seconds();
		int32 Count = Events.Num();
		for (int32 Index = 0; Index < Events.Num(); ++Index)
		{
			TSharedRef<const FP3NetEvent, ESPMode::ThreadSafe> Event = Events[Index];
			if (CurrentTimeSeconds - Event->CreationTimeSeconds < DelaySeconds)
			{
				Count = Index;
				break;
			}
		}
		if (Count > 0)
		{
			OutEvents.Reserve(Count);
			for (int32 Index = 0; Index < Count; ++Index)
			{
				OutEvents.Add(Events[Index]);
			}
			Events.RemoveAt(0, Count);
		}
		EventsLocker.WriteUnlock();
	}

	SET_DWORD_STAT(STAT_P3Net_NumFetchEvents, OutEvents.Num());

	return OutEvents;
}
