// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

/**
* Structure for byte packing/unpacking functions
*/
struct FP3Packer
{
	static inline bool PackBool(TArray<uint8>& Buf, int32& InOutPos, bool Value)
	{
		if (InOutPos + 1 > Buf.Num())
		{
			return false;
		}
		Buf[InOutPos++] = Value ? 1 : 0;
		return true;
	}

	static inline bool UnpackBool(const TArray<uint8>& Buf, int32& InOutPos, bool& OutValue)
	{
		if (InOutPos + 1 > Buf.Num())
		{
			return false;
		}
		OutValue = Buf[InOutPos++] != 0;
		return true;
	}

	static inline void PackInt32BE(uint8* Buf, int32& InOutPos, int32 Value)
	{
		Buf[InOutPos++] = (Value >> 24) & 0xFF;
		Buf[InOutPos++] = (Value >> 16) & 0xFF;
		Buf[InOutPos++] = (Value >> 8) & 0xFF;
		Buf[InOutPos++] = Value & 0xFF;
	}

	static inline void PackUInt32BE(uint8* Buf, int32& InOutPos, uint32 Value)
	{
		Buf[InOutPos++] = (Value >> 24) & 0xFF;
		Buf[InOutPos++] = (Value >> 16) & 0xFF;
		Buf[InOutPos++] = (Value >> 8) & 0xFF;
		Buf[InOutPos++] = Value & 0xFF;
	}

	static inline void PackUInt16BE(uint8* Buf, int32& InOutPos, uint16 Value)
	{
		Buf[InOutPos++] = (Value >> 8) & 0xFF;
		Buf[InOutPos++] = Value & 0xFF;
	}

	static inline int32 UnpackInt32BE(uint8* Buf, int32& InOutPos)
	{
		int32 Value = 0;
		Value += Buf[InOutPos++] << 24;
		Value += Buf[InOutPos++] << 16;
		Value += Buf[InOutPos++] << 8;
		Value += Buf[InOutPos++];
		return Value;
	}

	static inline uint32 UnpackUInt32BE(uint8* Buf, int32& InOutPos)
	{
		uint32 Value = 0;
		Value += Buf[InOutPos++] << 24;
		Value += Buf[InOutPos++] << 16;
		Value += Buf[InOutPos++] << 8;
		Value += Buf[InOutPos++];
		return Value;
	}

	static inline uint16 UnpackUInt16BE(uint8* Buf, int32& InOutPos)
	{
		uint16 Value = 0;
		Value += Buf[InOutPos++] << 8;
		Value += Buf[InOutPos++];
		return Value;
	}

	static inline bool PackUInt64LE(TArray<uint8>& Buf, int32& InOutPos, uint64 Value)
	{
		if (InOutPos + 8 > Buf.Num())
		{
			return false;
		}
		Buf[InOutPos++] = Value & 0xFF;
		Buf[InOutPos++] = (Value >> 8) & 0xFF;
		Buf[InOutPos++] = (Value >> 16) & 0xFF;
		Buf[InOutPos++] = (Value >> 24) & 0xFF;
		Buf[InOutPos++] = (Value >> 32) & 0xFF;
		Buf[InOutPos++] = (Value >> 40) & 0xFF;
		Buf[InOutPos++] = (Value >> 48) & 0xFF;
		Buf[InOutPos++] = (Value >> 56) & 0xFF;
		return true;
	}

	static inline bool PackInt32LE(TArray<uint8>& Buf, int32& InOutPos, int32 Value)
	{
		if (InOutPos + 4 > Buf.Num())
		{
			return false;
		}
		Buf[InOutPos++] = Value & 0xFF;
		Buf[InOutPos++] = (Value >> 8) & 0xFF;
		Buf[InOutPos++] = (Value >> 16) & 0xFF;
		Buf[InOutPos++] = (Value >> 24) & 0xFF;
		return true;
	}

	static inline bool PackUInt32LE(TArray<uint8>& Buf, int32& InOutPos, uint32 Value)
	{
		if (InOutPos + 4 > Buf.Num())
		{
			return false;
		}
		Buf[InOutPos++] = Value & 0xFF;
		Buf[InOutPos++] = (Value >> 8) & 0xFF;
		Buf[InOutPos++] = (Value >> 16) & 0xFF;
		Buf[InOutPos++] = (Value >> 24) & 0xFF;
		return true;
	}

	static inline bool PackUInt16LE(TArray<uint8>& Buf, int32& InOutPos, uint16 Value)
	{
		if (InOutPos + 2 > Buf.Num())
		{
			return false;
		}
		Buf[InOutPos++] = Value & 0xFF;
		Buf[InOutPos++] = (Value >> 8) & 0xFF;
		return true;
	}

	static inline bool PackUInt8LE(TArray<uint8>& Buf, int32& InOutPos, uint8 Value)
	{
		if (InOutPos + 1 > Buf.Num())
		{
			return false;
		}
		Buf[InOutPos++] = Value;
		return true;
	}

	static inline bool PackFloat32LE(TArray<uint8>& Buf, int32& InOutPos, float Value)
	{
		if (InOutPos + 4 > Buf.Num())
		{
			return false;
		}
		*((float*)&Buf[InOutPos]) = Value;
		InOutPos += 4;
		return true;
	}

	static inline bool PackVector3LE(TArray<uint8>& Buf, int32& InOutPos, FVector Value)
	{
		if (!PackFloat32LE(Buf, InOutPos, Value.X))
		{
			return false;
		}
		if (!PackFloat32LE(Buf, InOutPos, Value.Y))
		{
			return false;
		}
		if (!PackFloat32LE(Buf, InOutPos, Value.Z))
		{
			return false;
		}
		return true;
	}

	template<typename T>
	static bool PackList(TArray<uint8>& Buf, int32& InOutPos, TArray<T> List)
	{
		// Remember position
		int32 ListSizePos = InOutPos;

		// Reserve 2 bytes for list size
		uint16 ListSizeBytes = 0;
		if (!PackUInt16LE(Buf, InOutPos, ListSizeBytes))
		{
			return false;
		}

		for (const T& Item : List)
		{
			if (!Item.Pack(Buf, InOutPos))
			{
				return false;
			}
		}

		// Write list size at the position remembered
		ListSizeBytes = (uint16)(InOutPos - ListSizePos - 2);
		return ensure(PackUInt16LE(Buf, ListSizePos, ListSizeBytes));
	}

	static inline bool UnpackUInt64LE(const TArray<uint8>& Buf, int32& InOutPos, uint64& OutValue)
	{
		if (InOutPos + 8 > Buf.Num())
		{
			return false;
		}
		OutValue = 0;
		OutValue += (uint64)Buf[InOutPos++];
		OutValue += (uint64)Buf[InOutPos++] << 8;
		OutValue += (uint64)Buf[InOutPos++] << 16;
		OutValue += (uint64)Buf[InOutPos++] << 24;
		OutValue += (uint64)Buf[InOutPos++] << 32;
		OutValue += (uint64)Buf[InOutPos++] << 40;
		OutValue += (uint64)Buf[InOutPos++] << 48;
		OutValue += (uint64)Buf[InOutPos++] << 56;
		return true;
	}

	static inline bool UnpackInt32LE(const TArray<uint8>& Buf, int32& InOutPos, int32& OutValue)
	{
		if (InOutPos + 4 > Buf.Num())
		{
			return false;
		}
		OutValue = 0;
		OutValue += Buf[InOutPos++];
		OutValue += Buf[InOutPos++] << 8;
		OutValue += Buf[InOutPos++] << 16;
		OutValue += Buf[InOutPos++] << 24;
		return true;
	}

	static inline bool UnpackUInt32LE(const TArray<uint8>& Buf, int32& InOutPos, uint32& OutValue)
	{
		if (InOutPos + 4 > Buf.Num())
		{
			return false;
		}
		OutValue = 0;
		OutValue += Buf[InOutPos++];
		OutValue += Buf[InOutPos++] << 8;
		OutValue += Buf[InOutPos++] << 16;
		OutValue += Buf[InOutPos++] << 24;
		return true;
	}

	static inline bool UnpackUInt16LE(const TArray<uint8>& Buf, int32& InOutPos, uint16& OutValue)
	{
		if (InOutPos + 2 > Buf.Num())
		{
			return false;
		}
		OutValue = 0;
		OutValue += Buf[InOutPos++];
		OutValue += Buf[InOutPos++] << 8;
		return true;
	}

	static inline bool UnpackUInt8LE(const TArray<uint8>& Buf, int32& InOutPos, uint8& OutValue)
	{
		if (InOutPos + 1 > Buf.Num())
		{
			return false;
		}
		OutValue = Buf[InOutPos++];
		return true;
	}

	static inline bool UnpackFloat32LE(const TArray<uint8>& Buf, int32& InOutPos, float& OutValue)
	{
		if (InOutPos + 4 > Buf.Num())
		{
			return false;
		}
		OutValue = *((float*)&Buf[InOutPos]);
		InOutPos += 4;
		return true;
	}

	static inline bool UnpackVector3LE(const TArray<uint8>& Buf, int32& InOutPos, FVector& OutValue)
	{
		if (!UnpackFloat32LE(Buf, InOutPos, OutValue.X))
		{
			return false;
		}
		if (!UnpackFloat32LE(Buf, InOutPos, OutValue.Y))
		{
			return false;
		}
		if (!UnpackFloat32LE(Buf, InOutPos, OutValue.Z))
		{
			return false;
		}
		return true;
	}

	static inline bool PackStringLE(TArray<uint8>& Buf, int32& InOutPos, const FString& Value)
	{
		// TODO: Optimize this code (Write UTF8 to buffer directly without null terminator)
		const ANSICHAR* Str = TCHAR_TO_UTF8(*Value);
		const int32 Len = FCStringAnsi::Strlen(Str);

		if (!ensure(Len <= UINT16_MAX))
		{
			return false;
		}

		if (!PackUInt16LE(Buf, InOutPos, StaticCast<const uint16>(Len)))
		{
			return false;
		}

		if (InOutPos + Len > Buf.Num())
		{
			return false;
		}

		FMemory::Memcpy(Buf.GetData() + InOutPos, Str, StaticCast<SIZE_T>(Len));
		InOutPos += Len;

		return true;
	}

	static inline bool UnpackStringLE(const TArray<uint8>& Buf, int32& InOutPos, FString& OutValue)
	{
		uint16 Len = 0;
		if (!UnpackUInt16LE(Buf, InOutPos, Len))
		{
			return false;
		}

		const int32 Len32 = StaticCast<int32>(Len);

		if (InOutPos + Len32 > Buf.Num())
		{
			InOutPos -= 2; // Restore InOutPos
			return false;
		}

		// TODO: Optimize this code (Do not use temporary array)
		TArray<uint8> AnsiStr;
		AnsiStr.SetNumUninitialized(Len32 + 1);
		FMemory::Memcpy(AnsiStr.GetData(), Buf.GetData() + InOutPos, StaticCast<SIZE_T>(Len32));
		AnsiStr[Len32] = '\0';
		InOutPos += Len32;

		OutValue = UTF8_TO_TCHAR(AnsiStr.GetData());

		return true;
	}

	template<typename T>
	static bool UnpackList(const TArray<uint8>& Buf, int32& InOutPos, TArray<T>& OutList)
	{
		uint16 ListSizeBytes = 0;
		if (!UnpackUInt16LE(Buf, InOutPos, ListSizeBytes))
		{
			return false;
		}

		OutList.Reset();
		int32 EndPos = InOutPos + (int32)ListSizeBytes;
		while (InOutPos < EndPos)
		{
			T Char;
			if (!Char.Unpack(Buf, InOutPos))
			{
				return false;
			}
			OutList.Add(Char);
		}

		return (InOutPos == EndPos);
	}
};
