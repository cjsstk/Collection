// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3NetConn.h"
#include "P3Packer.h"

class FP3NetMessage
{
public:
	virtual ~FP3NetMessage() {}
	virtual uint16 GetType() const = 0;
	virtual bool Pack(TArray<uint8>& OutBuf, int32& InOutPos) const = 0;
	virtual bool Unpack(const TArray<uint8>& Buf) = 0;
};

class FP3NetSCMessage : public FP3NetMessage
{
public:
	virtual ~FP3NetSCMessage() {}
};

class FP3NetCSMessage : public FP3NetMessage
{
public:
	virtual ~FP3NetCSMessage() {}
};

class FP3NetProtocol
{
public:
	virtual ~FP3NetProtocol() {}
	virtual FP3NetMessage* CreateSCMessage(uint16 Type) const = 0;
};
