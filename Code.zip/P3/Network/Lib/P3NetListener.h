// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Core.h"
#include "P3NetConnPb.h"

//////////////////////////////////////////////////////////////////////////
// FP3NetListener
//////////////////////////////////////////////////////////////////////////

class FP3NetListener
{
public:
	FP3NetListener(P3NetConnId InId, const FString& InConnName, const TDescMap& InDescMap, int32 InMaxSocketSendPerMessage)
		: Id(InId)
		, ConnName(InConnName)
		, DescMap(InDescMap)
		, MaxSocketSendPerMessage(InMaxSocketSendPerMessage)
	{}

	P3NetConnId GetId() const;
	const FString& GetConnName() const;
	const TDescMap& GetDescMap() const;
	int32 GetMaxSocketSendPerMessage() const;

	bool Listen(const FString& BindAddres, int32 BindPort, int32 MaxBacklog);
	void Close();
	bool Accept(FSocket*& ClientSocket);

	void SetEnableStat(bool bEnable) { bEnabledStat = bEnable; }
	bool IsEnabledStat() const { return bEnabledStat; }

private:
	P3NetConnId Id = INVALID_NETCONNID;
	class FSocket* Socket = nullptr;

	/** Apply to accepted sockets */
	FString ConnName;
	TDescMap DescMap;
	int32 MaxSocketSendPerMessage = 0;
	bool bEnabledStat = false;
};
