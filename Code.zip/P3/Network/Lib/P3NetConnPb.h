// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3NetConn.h"
#include "P3Test.h"

#pragma warning (push)
#pragma warning (disable : 4668)
#include "google/protobuf/stubs/port.h"
#include "google/protobuf/message.h"
#pragma warning (pop)

//////////////////////////////////////////////////////////////////////////
// FP3NetConnPb (Protocol Buffer)
//////////////////////////////////////////////////////////////////////////

typedef TMap<uint16, const google::protobuf::Descriptor*> TDescMap;

class FP3NetConnPb : public FP3NetConn
{
public:
	FP3NetConnPb(P3NetConnId InId, const FString& InConnName, const TDescMap& InDescMap, int32 InMaxSocketSendPerMessage);

	virtual FP3NetConnPb* SafeCastToNetConnPb() override { return this; }

	bool Send(uint16 Type, const ::google::protobuf::Message& Message);
	bool Flush();
	bool Recv();
	bool PopMessage(bool& bOutHasMessage, uint16& OutMessageType, TSharedPtr<google::protobuf::Message, ESPMode::ThreadSafe>& OutMessage);
	bool HasRemainingData() const { return SendBuf.Num() > 0; }

protected:
	/**
	 * Theses functions have to be private
	 * But CALL_PRIVATE macro is broken and CALL_PROTECTED is alive, so use protected for a while
	 */
	bool PopMessageRaw(bool& bOutHasMessage, uint16& OutMessageType, TArray<uint8>& OutMessageBuf);

private:
	bool BuildMessageFromProtobuf(uint8* Buffer, int32 InPos, int32 MessageSize, uint16 Type, const ::google::protobuf::Message& Message);

private:
	TDescMap DescMap;
	int32 MaxMessageSize = 0;
	int32 MaxSocketSendPerMessage = 0;
	uint32 SendSeq = 1;
	uint32 RecvSeq = 1;

	TArray<uint8> SendBuf;
	TArray<uint8> RecvBuf;
	int32 RecvBufPos = 0;

#if !UE_BUILD_SHIPPING
	// Debug
	int32 DebugRecvCounter = 0;
#endif
};
