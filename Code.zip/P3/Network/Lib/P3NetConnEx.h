// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3NetConn.h"
#include "P3NetProtocol.h"
#include "P3Packer.h"

//////////////////////////////////////////////////////////////////////////
// FP3NetConnEx
//////////////////////////////////////////////////////////////////////////

class FP3NetConnEx : public FP3NetConn
{
public:
	FP3NetConnEx(P3NetConnId InId, const FString& InName, TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> InProtocol, int32 InMaxSocketSendPerMessage);

	virtual FP3NetConnEx* SafeCastToNetConnEx() override { return this; }

	bool Send(const FP3NetMessage& Message);
	bool Flush();
	bool Recv();
	bool PopMessage(bool& bOutHasMessage, uint16& OutMessageType, TSharedPtr<FP3NetMessage, ESPMode::ThreadSafe>& OutMessage);
	bool HasRemainingData() const { return SendBuf.Num() > 0; }

protected:
	/**
	 * Theses functions have to be private
	 * But CALL_PRIVATE macro is broken and CALL_PROTECTED is alive, so use protected for a while
	 */
	bool PopMessageRaw(bool& bOutHasMessage, uint16& OutMessageType, TArray<uint8>& OutMessageBuf);

private:
	int32 MaxMessageSize = 0;
	int32 MaxSocketSendPerMessage = 0;
	TSharedPtr<const FP3NetProtocol, ESPMode::ThreadSafe> Protocol;

	/* Temporary buffer to calculate message size */
	TArray<uint8> SendMessageBuf;

	TArray<uint8> SendBuf;
	TArray<uint8> RecvBuf;
	int32 RecvBufPos = 0;

#if !UE_BUILD_SHIPPING
	// Debug
	int32 DebugRecvCounter = 0;
#endif
};
