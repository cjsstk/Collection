// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "P3UDPENet.h"

#include "P3UDPENetClient.generated.h"

UCLASS()
class UP3UDPENetClient final : public UP3UDPENet
{
	GENERATED_BODY()

public:
	// form IUDPNetBase
	virtual void Initialize(class UP3GameInstance* InGameInstance) override;
	virtual void Shutdown() override;
	virtual void Close(const P3NetConnId NetConnId = INVALID_NETCONNID) override;
	virtual void Tick(float DeltaSeconds) override;

	// form UP3UDPNetwork
	virtual bool Init(class UP3World* InP3World, const FString& InHost = TEXT(""), int32 InPort = 0) override;
	virtual bool Client_IsConnected() const override;
	virtual EP3NetConnStatus Client_GetConnStatus() const override;
	virtual FP3NetStat GetAvgConnStat() const override;
	virtual bool Client_SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bForceReliable) override;
	virtual bool IsServer() const override { return false; }
	virtual void SendConsoleCommand(const FString& Command) override;
	virtual void Client_SendWorldMessage(const ::google::protobuf::Message& Message) override;
	virtual void Client_SendZoneChange() override;
	virtual int32 GetPingTimeMsec() const override { return PingTime.PingTimeMsec; }
	virtual FDateTime GetPingUpdatedTime() const override { return PingTime.LastPingUpdatedTime; }
	virtual float GetServerFrameTimeMsec() const override { return PingTime.ServerFrameTimeMsec; }

	// from UP3UDPENet
	virtual void InitThread() override;
	virtual void Update() override;
	virtual void HandleConnectEvent(const ENetEvent& Event) override;
	virtual void HandleDisconnectEvent(const ENetEvent& Event) override;
	virtual void HandleReceiveEvent(const ENetEvent& Event) override;
	virtual void HandleConnectOnGameThread(const FP3ENetConnectEvent* Event) override;
	virtual void HandleDisconnectOnGameThread(const FP3ENetDisconnectEvent* Event) override;
	virtual void HandleReceiveOnGameThread(const FP3ENetReceiveEvent* Event) override;
	virtual bool IsValid() const override;

private:
	void UpdateStat();

	void HandleWorldMessage(const struct FP3UDPMessageWorld& Message);

private:
	P3NetConnId CurrentConnId = INVALID_NETCONNID; // handle on game thread

	EP3NetConnStatus ConnStatus = EP3NetConnStatus::Closed;

	FP3PingTime PingTime;

	FP3NetStat NetStat;
	double StatUpdateTime = 0.0;
	int32 StatSentBytes = 0;
	int32 StatRecvBytes = 0;
	int32 StatSentMessages = 0;
	int32 StatRecvMessages = 0;

	int32 InPacketLost = 0;
	int32 OutPacketsLost = 0;
	int32 InTotalPacketsLost = 0;
	int32 OutTotalPacketsLost = 0;
};
