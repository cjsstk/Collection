// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CombatShapeCollision.h"

#include "DrawDebugHelpers.h"

#include "P3Character.h"
#include "P3Cms.h"
#include "P3Combat.h"
#include "P3Physics.h"

extern TAutoConsoleVariable<int32> CVarP3CombatAttackRangeDebug;

TAutoConsoleVariable<int32> CVarP3CombatShapCollision(
	TEXT("p3.combatShapCollision"),
	1,
	TEXT("1: enable. 0: disable"), ECVF_Cheat);

UP3CombatBoxComponent::UP3CombatBoxComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	bWantsInitializeComponent = true;	
}

void UP3CombatBoxComponent::InitializeComponent()
{
	Super::InitializeComponent();
	
	CanCharacterStepUpOn = ECanBeCharacterBase::ECB_No;
	
	SetGenerateOverlapEvents(false);
	SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Deactivate();
}

void UP3CombatBoxComponent::UninitializeComponent()
{
	Super::UninitializeComponent();
		
}

void UP3CombatBoxComponent::ActivateCombatCollision(const FName& InCmsCombatHitKey, AP3Character* InOwnerCharacter, int32 InMaxOverlapCount, float InOverlapBufferClearTimeSeconds)
{
	if (CVarP3CombatShapCollision.GetValueOnGameThread() == 0)
	{
		return;
	}

	Activate();
	
	CmsCombatHitKey = InCmsCombatHitKey;
	OwnerCharacter = InOwnerCharacter;

	MaxOverlapCount = InMaxOverlapCount;
	OverlapBufferClearTimeSeconds = InOverlapBufferClearTimeSeconds;

	OverlapCountBuffer.Reset();
}

void UP3CombatBoxComponent::DeactivateCombatCollision()
{
	Deactivate();

	CmsCombatHitKey = NAME_None;
	OwnerCharacter = nullptr;	
}

void UP3CombatBoxComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!IsActive())
	{
		LastUpdateLocation = GetComponentLocation();
		return;
	}

	TickDamageActor();
}

void UP3CombatBoxComponent::TickDamageActor()
{
	if (!OwnerCharacter || CmsCombatHitKey == NAME_None)
	{
		return;
	}

	const FP3CmsCombatHit* CmsCombatHit = P3Cms::GetCombatHit(CmsCombatHitKey);
	if (!ensure(CmsCombatHit))
	{
		return;
	}

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(OwnerCharacter);
	{
		TArray<AActor*>AttachedActors;
		OwnerCharacter->GetAttachedActors(AttachedActors);
		QueryParams.AddIgnoredActors(AttachedActors);
	}

	const float DesiredTick = 1.f / 30.f;
	const float DeltaTick = GetWorld()->GetDeltaSeconds() / DesiredTick;
	const float LocationRatio = 20.f;
	const float LocationOffset = DeltaTick * LocationRatio;
	const float BoxExtentRatio = FMath::Max<float>(1.f, FMath::Min<float>(DeltaTick, 2.f));

	FCollisionShape Shape;
	Shape.SetBox(GetScaledBoxExtent() * BoxExtentRatio);

	FVector CurrentLocation = GetComponentLocation() + OwnerCharacter->GetActorForwardVector() * LocationOffset;
	const FQuat& CurrentRotator = GetComponentRotation().Quaternion();
	FVector CurrentImpactDirection = CurrentRotator.GetForwardVector();

	TArray<FHitResult> HitResults;
	GetWorld()->SweepMultiByChannel(HitResults, LastUpdateLocation, CurrentLocation, CurrentRotator, ECC_COMBAT, Shape, QueryParams);

	for (const FHitResult& HitResult : HitResults)
	{
		AActor* HitActor = HitResult.GetActor();
		if (!HitActor)
		{
			continue;
		}

		FP3OverlapCountBuffer& FindOverlapCountBuffer = OverlapCountBuffer.FindOrAdd(HitActor);
		if (FindOverlapCountBuffer.OverlapCount != 0)
		{
			if (FindOverlapCountBuffer.OverlapCount >= MaxOverlapCount)
			{
				continue;
			}

			if (FindOverlapCountBuffer.OverlapStartTimeSeconds < OverlapBufferClearTimeSeconds)
			{
				FindOverlapCountBuffer.OverlapStartTimeSeconds += GetWorld()->GetDeltaSeconds();
				continue;
			}
		}

		FindOverlapCountBuffer.OverlapCount++;
		FindOverlapCountBuffer.OverlapStartTimeSeconds = 0.f;

		P3Combat::FDamageActorParams DamageParams(*OwnerCharacter, *HitActor);
		DamageParams.AttackStrength = CmsCombatHit->AttackStrength;
		DamageParams.AttackDirection = CmsCombatHit->AttackDirection;
		DamageParams.AttackAttribute = CmsCombatHit->AttackAttribute;
		DamageParams.TagName = CmsCombatHit->TagName;
		DamageParams.TargetComponent = HitResult.GetComponent();
		DamageParams.TargetHitItemIndex = HitResult.Item;
		DamageParams.WeaponType = OwnerCharacter->GetRightHandWeaponType();
		DamageParams.ImpactDirection = CurrentImpactDirection;
		DamageParams.BoneName = HitResult.BoneName;
		DamageParams.AttackBoneName = NAME_None;
		DamageParams.DamagePermil = CmsCombatHit->DamagePermil;
		DamageParams.DamageDestructiblePermil = CmsCombatHit->DamageDestructiblePermil;
		DamageParams.bCanDamageAlly = CmsCombatHit->bCanDamageAlly;
		DamageParams.HitLocation = &HitResult.ImpactPoint;
		DamageParams.bIsFrameHold = CmsCombatHit->bIsFrameHold;
		DamageParams.CmsCombatHitKey = CmsCombatHitKey;
		DamageParams.CmsCameraShakeKey = CmsCombatHit->CmsCameraShakeName;

		P3Combat::Server_DamageActor(DamageParams);
	}
	
	LastUpdateLocation = CurrentLocation;

	if (CVarP3CombatAttackRangeDebug.GetValueOnGameThread() != 0)
	{
		DrawDebugBox(GetWorld(), CurrentLocation, Shape.GetExtent(), CurrentRotator, FColor::Red, false, 1.f);
	}
}
