// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3SwampVolume.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"

AP3SwampVolume::AP3SwampVolume()
{
	FluidFriction = 50;
	bWaterVolume = true;
}

void AP3SwampVolume::ActorEnteredVolume(class AActor* Other)
{
	Super::ActorEnteredVolume(Other);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(Other);
		if (Character && Character->GetEffectComponent())
		{
			Character->GetEffectComponent()->Server_AddEffect(EP3CharacterEffectTypes::Swamp, *this);
		}
	}
}

void AP3SwampVolume::ActorLeavingVolume(class AActor* Other)
{
	Super::ActorLeavingVolume(Other);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(Other);
		if (Character && Character->GetEffectComponent())
		{
			Character->GetEffectComponent()->Server_RemoveEffect(EP3CharacterEffectTypes::Swamp, *this);
		}
	}
}
