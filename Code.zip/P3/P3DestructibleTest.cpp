// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Destructible.h"
#include "P3Test.h"

extern TAutoConsoleVariable<int32> CVarP3NetMaxMessageSize;

#if P3_BUILD_WITH_TEST

#include "AutomationTest.h"

IMPLEMENT_SIMPLE_AUTOMATION_TEST(FP3CalcDamagedMeshIndexTest, "P3.Destructible.CalcDamagedMeshIndex", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

bool FP3CalcDamagedMeshIndexTest::RunTest(const FString& Parameters)
{
	{
		// Full health
		const int32 Index = AP3Destructible::CalcDamagedMeshIndex(10, 10, 2);
		P3_ASSERT_EQUAL(Index, -1);
	}

	{
		// First damage must change the model to give better feedback to player
		const int32 Index = AP3Destructible::CalcDamagedMeshIndex(9, 10, 2);
		P3_ASSERT_EQUAL(Index, 0);
	}

	{
		// Test large HP
		const int32 Index1 = AP3Destructible::CalcDamagedMeshIndex(1, 10, 2);
		P3_ASSERT_EQUAL(Index1, 1);

		const int32 Index2 = AP3Destructible::CalcDamagedMeshIndex(0, 10, 2);
		P3_ASSERT_EQUAL(Index2, 2);
	}

	{
		// If artist put 3 models and set HP as 3, each hit must change model

		const int32 Index1 = AP3Destructible::CalcDamagedMeshIndex(3, 3, 2);
		P3_ASSERT_EQUAL(Index1, -1);

		const int32 Index2 = AP3Destructible::CalcDamagedMeshIndex(2, 3, 2);
		P3_ASSERT_EQUAL(Index2, 0);

		const int32 Index3 = AP3Destructible::CalcDamagedMeshIndex(1, 3, 2);
		P3_ASSERT_EQUAL(Index3, 1);

		const int32 Index4 = AP3Destructible::CalcDamagedMeshIndex(0, 3, 2);
		P3_ASSERT_EQUAL(Index4, 2);
	}

	{
		// Only a one damaged model case

		const int32 Index1 = AP3Destructible::CalcDamagedMeshIndex(3, 3, 1);
		P3_ASSERT_EQUAL(Index1, -1);

		const int32 Index2 = AP3Destructible::CalcDamagedMeshIndex(2, 3, 1);
		P3_ASSERT_EQUAL(Index2, 0);

		const int32 Index3 = AP3Destructible::CalcDamagedMeshIndex(1, 3, 1);
		P3_ASSERT_EQUAL(Index3, 0);

		const int32 Index4 = AP3Destructible::CalcDamagedMeshIndex(0, 3, 1);
		P3_ASSERT_EQUAL(Index4, 1);
	}

	return true;
}

#endif // P3_BUILD_WITH_TEST
