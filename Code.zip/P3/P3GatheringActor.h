// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3GatheringActor.generated.h"

/**
 * 인터렉션으로 아이템을 얻을 수 있는 액터
 */
UCLASS()
class P3_API AP3GatheringActor : public AP3Actor
{
	GENERATED_BODY()

public:
	AP3GatheringActor();

private:
	UPROPERTY(VisibleAnywhere)
	class UP3LootingInteractableComponent* LootingInteractableComponent = nullptr;

};
