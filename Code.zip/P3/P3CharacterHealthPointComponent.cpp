// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CharacterHealthPointComponent.h"

#include "Action/P3PawnActionComponent.h"
#include "GameMode/P3ContributionSystem.h"
#include "P3ActorInterface.h"
#include "P3Character.h"
#include "P3World.h"

#include "Engine/World.h"

extern TAutoConsoleVariable<int32> CVarP3HealthDebug;

static TAutoConsoleVariable<int32> CVarP3EnableDown(
	TEXT("p3.enableDown"),
	1,
	TEXT("1: enable Down. 0: disable Down"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3RestoreHealthPointOnRescued(
	TEXT("p3.restoreHealthPointOnRescued"),
	0.1,
	TEXT("1: 100%. 0: 0% "), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3EnableNotApplyDamageOnDowned(
	TEXT("p3.enableNotApplyDamageOnDowned"),
	1,
	TEXT("1: not apply damage. 0: apply damage "), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3NotApplyDamageOnDownedTimeSeconds(
	TEXT("p3.notApplyDamageOnDownedTimeSeconds"),
	1.0f,
	TEXT("Character doesn't apply damage on downed during this time"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3DownedTickDamageMultiplierDuringCarrying(
	TEXT("p3.downedTickDamageMultiplierDuringCarrying"),
	1.0f,
	TEXT("Set how fast rescue can be done"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3RescueSpeedMultiplier(
	TEXT("p3.rescueSpeedMultiplier"),
	0.5f,
	TEXT("Set how fast rescue can be done"), ECVF_Cheat);

TAutoConsoleVariable<float> CVarP3DownedHealthPointMultiplier(
	TEXT("p3.downedHealthPointMultiplier"),
	1.0f,
	TEXT("Downed health point multiplier"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3DownedHealthPointMinusDamageMultiplier(
	TEXT("p3.downedHealthPointMinusDamageMultiplier"),
	2,
	TEXT("Downed health point minus damage multiplier"), ECVF_Cheat);


UP3CharacterHealthPointComponent::UP3CharacterHealthPointComponent()
{

}

void UP3CharacterHealthPointComponent::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	if (!Archive.IsLoading())
	{
		Archive << Net_MaxDownedHealthPoint;
		Archive << Net_DownedHealthPoint;
		Archive << Net_bDowned;
		Archive << Net_bUnderRescue;
	}
	else
	{
		bool NewbDowned;

		Archive << Net_MaxDownedHealthPoint;
		Archive << Net_DownedHealthPoint;
		Archive << NewbDowned;
		Archive << Net_bUnderRescue;

		if (Net_bDowned != NewbDowned)
		{
			Net_bDowned = NewbDowned;
			OnDownedChanged.Broadcast(Net_bDowned);
		}
	}
}

bool UP3CharacterHealthPointComponent::Server_CanBeAppliedDamage() const
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (CVarP3EnableNotApplyDamageOnDowned.GetValueOnGameThread() == 0)
	{
		return true;
	}

	return (Server_NotApplyDamageOnDownedTickSeconds <= 0.0f);
}

bool UP3CharacterHealthPointComponent::CanBeRescued() const
{
	return (GetDownedHealthPoint() >= GetMaxDownedHealthPoint() && IsDowned());
}

void UP3CharacterHealthPointComponent::DownedEndOnDead()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetDowned(false);
	}
}

void UP3CharacterHealthPointComponent::Server_SetRescueTickAgeSeconds(float InRescueTickAgeSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}
	Server_RescueTickAgeSeconds = InRescueTickAgeSeconds;

	Server_SetDirty(*this);
}

void UP3CharacterHealthPointComponent::Server_ReduceDownedHealthPoint(int32 InReduceAmount)
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (Server_CanBeAppliedDamage())
		{
			const int32 ReduceAmount = (InReduceAmount >= 0) ? InReduceAmount : InReduceAmount * CVarP3DownedHealthPointMinusDamageMultiplier.GetValueOnGameThread();
			Server_SetDownedHealthPoint(Net_DownedHealthPoint - ReduceAmount);
		}
	}
}

void UP3CharacterHealthPointComponent::Server_RestoreDownedHealthPoint(int32 InRestoreAmount)
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetDownedHealthPoint(Net_DownedHealthPoint + InRestoreAmount);
	}
}

void UP3CharacterHealthPointComponent::Server_SetUnderRescue(const bool InbUnderRescue)
{
	if (GetOwner() && P3Core::IsP3NetModeServerInstance(*this))
	{
		Net_bUnderRescue = InbUnderRescue;

		Server_SetDirty(*this);
	}
}

void UP3CharacterHealthPointComponent::Server_Rescued()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const int32 RestoreHealthPoint = FMath::FloorToInt((float)GetMaxHealthPoint() * CVarP3RestoreHealthPointOnRescued.GetValueOnGameThread());
	SetHealthPointInternal(RestoreHealthPoint, true, false);
	Server_SetDowned(false);
	Server_NotApplyDamageOnDownedTickSeconds = 0.0f;
	Server_RescuedNum++;

	Server_SetDirty(*this);
}

int32 UP3CharacterHealthPointComponent::Server_TickRescue(float DeltaSeconds, UP3CharacterHealthPointComponent* TargetHealthComp)
{
	int32 HealedAmount = 0;

	Server_SetRescueTickAgeSeconds(GetRescueTickAgeSeconds() + DeltaSeconds);

	int32 LoopCounter = 0;
	while (RescueTickSeconds > 0 && GetRescueTickAgeSeconds() >= RescueTickSeconds)
	{
		Server_SetRescueTickAgeSeconds(GetRescueTickAgeSeconds() - RescueTickSeconds);

		if (TargetHealthComp && TargetHealthComp->GetDownedHealthPoint() > 0)
		{
			const int32 RestoreAmount = (TargetHealthComp->GetMaxDownedHealthPoint() * RescueAmountPermil * CVarP3RescueSpeedMultiplier.GetValueOnGameThread()) / 1000;
			TargetHealthComp->Server_RestoreDownedHealthPoint(RestoreAmount);

			HealedAmount += RestoreAmount;
		}

		if (++LoopCounter > 1000)
		{
			ensure(0);
			break;
		}
	}

	return HealedAmount;
}

void UP3CharacterHealthPointComponent::Server_TickDownedDamage()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const AP3Character* Character = Cast<AP3Character>(GetOwner());

	const bool bBeingCarried = Character && (Character->GetCharacterStoreBP().MountTargetCharacter != nullptr);
	const int32 Damage = bBeingCarried ? DownedTickDamageDuringCarrying * CVarP3DownedTickDamageMultiplierDuringCarrying.GetValueOnGameThread() : DownedTickDamage;

	const int32 NewHealthPoint = Net_DownedHealthPoint - Damage;

	Server_SetDownedHealthPoint(NewHealthPoint);
}

void UP3CharacterHealthPointComponent::Server_SetDownedHealthPoint(int32 InHealthPoint)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const int32 OldDownedHealthPoint = Net_DownedHealthPoint;

	Net_DownedHealthPoint = FMath::Clamp(InHealthPoint, 0, Net_MaxDownedHealthPoint);

	Server_SetDirty(*this);

	if (OldDownedHealthPoint != 0 && Net_DownedHealthPoint == 0)
	{
		Server_OnDead();
	}
}

void UP3CharacterHealthPointComponent::Server_TickNotApplyDamage(float DeltaTime)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_NotApplyDamageOnDownedTickSeconds <= 0.0f)
	{
		return;
	}

	Server_NotApplyDamageOnDownedTickSeconds = FMath::Max(Server_NotApplyDamageOnDownedTickSeconds - DeltaTime, 0.0f);

}

void UP3CharacterHealthPointComponent::Server_TickRemoveRescuedPenalty(float DeltaTime)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_RescuedNum <= 0)
	{
		return;
	}

	Server_CurrentRescuedPenaltyAgeSeconds += DeltaTime;
	if (Server_CurrentRescuedPenaltyAgeSeconds > RescuedPenaltyDuration)
	{
		Server_RescuedNum--;
		Server_CurrentRescuedPenaltyAgeSeconds = 0.0f;
	}
}

void UP3CharacterHealthPointComponent::BeginPlay()
{
	Super::BeginPlay();

	// TODO: activate only when needed(like downed ...)
	SetComponentTickEnabled(true);
}

void UP3CharacterHealthPointComponent::OnRegister()
{
	Super::OnRegister();
}

void UP3CharacterHealthPointComponent::OnUnregister()
{
	Super::OnUnregister();
}

void UP3CharacterHealthPointComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_TickDowned(DeltaTime);
		Server_TickNotApplyDamage(DeltaTime);
		Server_TickRemoveRescuedPenalty(DeltaTime);
	}

	if (CVarP3HealthDebug.GetValueOnGameThread() != 0)
	{
		IP3ActorInterface* P3Actor = Cast<IP3ActorInterface>(GetOwner());
		if (P3Actor)
		{
			P3Actor->AddDebugString(FString::Printf(TEXT("Downed: %s"), (Net_bDowned) ? TEXT("true") : TEXT("false")));
			P3Actor->AddDebugString(FString::Printf(TEXT("Character Downed HP: %d/%d"), Net_DownedHealthPoint, Net_MaxDownedHealthPoint));
			P3Actor->AddDebugString(FString::Printf(TEXT("UnderRescue: %s"), (Net_bUnderRescue) ? TEXT("true") : TEXT("false")));

			if (P3Core::IsP3NetModeServerInstance(*this))
			{
				P3Actor->AddDebugString(FString::Printf(TEXT("RescuedNum: %d"), Server_RescuedNum));
				P3Actor->AddDebugString(FString::Printf(TEXT("CurrentRescuedPenaltyAgeSeconds: %f"), Server_CurrentRescuedPenaltyAgeSeconds));
				P3Actor->AddDebugString(FString::Printf(TEXT("NotApplyDamageTime: %f"), Server_NotApplyDamageOnDownedTickSeconds));
			}
		}
	}
}

void UP3CharacterHealthPointComponent::Server_SetDowned(bool InDowned)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Net_bDowned = InDowned;
	OnDownedChanged.Broadcast(Net_bDowned);

	if (!InDowned)
	{
		Net_DownedHealthPoint = 0;
	}
	else
	{
		Server_NotApplyDamageOnDownedTickSeconds = CVarP3NotApplyDamageOnDownedTimeSeconds.GetValueOnGameThread();
	}

	Server_SetDirty(*this);
}

void UP3CharacterHealthPointComponent::Server_TickDowned(float DeltaTime)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_bDowned && !Net_bUnderRescue)
	{
		Server_DownedDamageTickAgeSeconds += DeltaTime;

		int32 LoopCounter = 0;

		while (DownedDamageTickSeconds > 0 && Server_DownedDamageTickAgeSeconds >= DownedDamageTickSeconds)
		{
			Server_DownedDamageTickAgeSeconds -= DownedDamageTickSeconds;
			Server_TickDownedDamage();

			if (++LoopCounter > 1000)
			{
				ensure(0);
				break;
			}
		}
	}
}

void UP3CharacterHealthPointComponent::OnMaxHealthPointChanged()
{
	Super::OnMaxHealthPointChanged();

	Net_MaxDownedHealthPoint = (GetMaxHealthPoint() * DownedHealthPointPermil * CVarP3DownedHealthPointMultiplier.GetValueOnGameThread()) / 1000;

	if (Net_DownedHealthPoint > Net_MaxDownedHealthPoint)
	{
		Net_DownedHealthPoint = Net_MaxDownedHealthPoint;
	}
}

void UP3CharacterHealthPointComponent::OnHealthPointChanged(int32 PrevHealthPoint, int32 CurrentHealthPoint)
{
	Super::OnHealthPointChanged(PrevHealthPoint, CurrentHealthPoint);

	if (P3Core::IsP3NetModeServerInstance(*this) && PrevHealthPoint != 0 && CurrentHealthPoint == 0)
	{
		if (CVarP3EnableDown.GetValueOnGameThread() != 0)
		{
			// Base health is empty, become downed
			Server_StartDowned();
		}
	}

}

bool UP3CharacterHealthPointComponent::IsDeadInternal() const
{
	return (GetHealthPoint() == 0 && (Net_DownedHealthPoint == 0 || CVarP3EnableDown.GetValueOnGameThread() == 0));
}

void UP3CharacterHealthPointComponent::Server_OnDeadInternal()
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	Server_RescuedNum = 0;
}

void UP3CharacterHealthPointComponent::Server_StartDowned()
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	Net_DownedHealthPoint = Net_MaxDownedHealthPoint * FMath::Pow(0.5f, Server_RescuedNum);

	Server_SetDowned(true);
	Server_SetDirty(*this);

	Server_DownedDamageTickAgeSeconds = 0;

	P3Contribution::Server_AddPoint(Cast<AP3Character>(GetOwner()), EP3ContributionType::Down, 1);
}

