// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Delegates/Delegate.h"
#include "GameFramework/Actor.h"

#include "P3Core.h"
#include "P3StoreArchive.h"
#include "P3Version.h"
#include "P3WorldNetCore.h"
#include "Network/Lib/P3NetCore.h"

#include "P3World.generated.h"

#define Client_SendPacket(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Client_SendPacketInternal(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ))

#define Client_SendPacketReliable(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Client_SendPacketInternal(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ), true)

#define Server_SendPacketToPlayer(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Server_SendPacketToPlayerInternal(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, true, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ))

#define Server_SendPacketToPlayerReliable(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Server_SendPacketToPlayerInternal(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, true, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ), true)

#define Server_SendPacketToPlayerForce(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Server_SendPacketToPlayerInternal(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, false, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ))

#define Server_SendPacketToPlayerForceReliable(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Server_SendPacketToPlayerInternal(NetConnInfo, HandlerObject, HandlerActorId, Actor, Packet, ComponentType, false, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ), true)

#define Server_SendRawDataToPlayer(NetConnInfo, HandlerObject, HandlerActorId, Actor, RawData, ComponentType, HandlerFunction) Server_SendRawDataToPlayerInternal(NetConnInfo, HandlerObject, HandlerActorId, Actor, RawData, ComponentType, true, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ))

#define Server_SendRawDataToPlayerReliable(NetConnInfo, HandlerObject, HandlerActorId, Actor, RawData, ComponentType, HandlerFunction) Server_SendRawDataToPlayerInternal(NetConnInfo, HandlerObject, HandlerActorId, Actor, RawData, ComponentType, true, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ), true)

#define Server_MulticastPacket(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Server_MulticastPacketInternal(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ))

#define Server_MulticastPacketReliable(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction) Server_MulticastPacketInternal(HandlerObject, HandlerActorId, Actor, Packet, ComponentType, HandlerFunction, STATIC_FUNCTION_FNAME( TEXT( #HandlerFunction ) ), true)

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3ServerWorldActorAdded, int64, ActorId, AActor*, Actor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3ServerWorldActorRemoved, int64, ActorId, AActor*, Actor);

USTRUCT()
struct FTestParams
{
	GENERATED_BODY()

	UPROPERTY()
	ESpawnActorCollisionHandlingMethod CollisionHandlingMethod;
};

/**
 * Attachment data of non-p3 actor which attached to p3 actor
 * actor must be level-actor(static actor) so that we can find it with name
 */
USTRUCT()
struct FP3NetAttachedLevelActor
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ParentActorId = INVALID_ACTORID;

	UPROPERTY()
	FString ChildActorLevelName;

	UPROPERTY()
	FString ChildActorName;

	UPROPERTY()
	FP3NetTransform ChildRelativeTransform = FP3NetTransform(FTransform::Identity);

	UPROPERTY()
	FString AttachedComponentName;

	UPROPERTY()
	FName AttachedSocketName = NAME_None;
};

USTRUCT()
struct FP3NetActorStoreData
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId = INVALID_ACTORID;

	UPROPERTY()
	TArray<uint8> ActorStoreData;

	UPROPERTY()
	TArray<FP3NetStoreData> ComponentStoreData;

	UPROPERTY()
	TArray<FP3NetAttachedLevelActor> AttachedLevelActors;
};



/**
 * Actor information from client to dedicated server
 * ie) Player character, Weapons
 */
USTRUCT()
struct FP3NetPlayerOwnActor
{
	GENERATED_BODY()

	UPROPERTY()
	int64 ActorId = INVALID_ACTORID;

	UPROPERTY()
	FString ClassName;

	UPROPERTY()
	FP3NetTransform Transform;
};

/**
 * Entry point of player, connecting to server
 */
USTRUCT()
struct FP3NetPlayerEnterWorld
{
	GENERATED_BODY()

	/** Development mode only */
	UPROPERTY()
	FString Account;

	UPROPERTY()
	FString Token;

	UPROPERTY()
	uint64 CharacterId;

	UPROPERTY()
	FP3Version Version;

	UPROPERTY()
	TArray<FP3NetPlayerOwnActor> OwnActors;
};

/**
 * Enter world response from server
 */
USTRUCT()
struct FP3NetPlayerEnterWorldResponse
{
	GENERATED_BODY()

	UPROPERTY()
	FP3Version ServerVersion;

	UPROPERTY()
	uint32 ZoneChannelId;

	/** Old id to New id */
	UPROPERTY()
	TMap<int64, int64> RemapOwnActors;

	/** Current time of day */
	UPROPERTY()
	float TimeOfDayInSeconds = 0;

	/** Time of day = Game time * ratio */
	UPROPERTY()	
	float GameTimeToTimeOfDayRatio = 1.0f;
};

/**
 * Enter world fail response from server
 */
USTRUCT()
struct FP3NetPlayerEnterWorldFailResponse
{
	GENERATED_BODY()

	UPROPERTY()
	FP3Version ServerVersion;

	UPROPERTY()
	FString DebugMessage;
};

/**
 * Remap own actor from server
 */
USTRUCT()
struct FP3NetPlayerRemapOwnActor
{
	GENERATED_BODY()

	UPROPERTY()
	int64 RemapOldOwnActor;

	UPROPERTY()
	int64 RemapNewOwnActor;
};

/** 
 * Toast message
 */
USTRUCT()
struct FP3NetToastMessage
{
	GENERATED_BODY()

	UPROPERTY()
	FText Message;
};

/** 
 * Damage Foliage
 */
USTRUCT()
struct FP3NetDamageFoliage
{
	GENERATED_BODY()

	UPROPERTY()
	FString LevelName;

	UPROPERTY()
	FString ActorName;

	UPROPERTY()
	FString ComponentName;

	UPROPERTY()
	int32 ItemIndex = -1;
};

/**
 * Damage actor without command component
 */
USTRUCT()
struct FP3NetDamageNonCommandActor
{
	GENERATED_BODY()

	UPROPERTY()
	AActor* TargetActor = nullptr;

	UPROPERTY()
	AActor* SourceActor = nullptr;

	UPROPERTY()
	int32 DamageAmount = 0;

	UPROPERTY()
	UPrimitiveComponent* TargetComponent = nullptr;

	UPROPERTY()
	int32 HitItemIndex = 0;

	UPROPERTY()
	bool bHasHitLocation = false;

	/** Only valid when bHasHitLocation is true */
	UPROPERTY()
	FVector HitLocation = FVector::ZeroVector;

};

/** 
 * Time of Day
 */
USTRUCT()
struct FP3TimeOfDay
{
	GENERATED_BODY()

	/** Current time. Default 9AM */
	UPROPERTY()
	float TimeOfDayInSeconds = 3600 * 9;

	/** Time of day = Game time * ratio. Defaut 1Hour in real life is 1Day in game */
	UPROPERTY()
	float GameTimeToTimeOfDayRatio = 24.0f;
};

/** 
 * The Great, World.
 */
UCLASS(BlueprintType)
class UP3World : public UObject
{
	GENERATED_BODY()

	friend class UP3ClientWorld;
	friend class UP3ServerWorld;

public:
	UP3World();
	virtual ~UP3World();

	void Initialize(class UP3GameInstance* InGameInstance);
	void Shutdown();

	void BeginPlay(UWorld* InWorld);
	void Tick(float DeltaSeconds);

	void RegisterActor(AActor& Actor);

	UP3GameInstance* GetGameInstance() const { return GameInstance; }
	AActor* GetActorFromActorId(actorid ActorId) const;
	actorid GetActorIdFromActor(const AActor* Actor) const;
	const TMap<int64, AActor*>& GetActors() const { return Actors; }

	UFUNCTION(BlueprintCallable)
	class AP3WorldSystem* GetWorldSystem() const { return Net_WorldSystem; }

	/** Client query */
	UFUNCTION(BlueprintCallable)
	class UP3ClientWorld* GetClientWorld() const;

	/** Server query */
	class UP3ServerWorld* GetServerWorld() const;

	/** Message */
	void Server_SendToastMessage(const AActor& Actor, const FText& Message);
	void Server_SendToastMessageToAll(const FText& Message);

	/**
	 * Flocking (TODO: maybe move to it's own system?)
	 */
	void Server_FireScareFlockEvent(const FVector& Location, float Radius, float DurationSeconds);

	/**
	 * Foliage (TODO: maybe move to it's own system?)
	 */
	void Server_DamageFoliage(AActor& FoliageActor, UPrimitiveComponent& Component, int32 ItemIndex);

	/**
	 * Combat (TODO: maybe move to it's own system?)
	 */
	void Server_DamageNonCommandActor(AActor& TargetActor, AActor& SourceActor, int32 DamageAmount, UPrimitiveComponent* TargetComponent, int32 HitItemIndex, const FVector* HitLocation);

	/**
	 * Time of Day
	 */
	float GetTimeOfDaySeconds() const { return TimeOfDay.TimeOfDayInSeconds; }
	const FP3TimeOfDay& GetTimeOfDay() const { return TimeOfDay; }

	/**
	 * Zone Volumes
	 */
	void RegisterZoneVolume(const class AP3ZoneVolume* ZoneVolume);
	void UnregisterZoneVolume(const class AP3ZoneVolume* ZoneVolume);
	FName GetZoneFromLocation(const FVector& Location) const;

	/**
	 * Quest Zone Volumes
	 */
	void RegisterQuestVolume(const class AP3QuestVolume* QuestVolume);
	void UnregisterQuestVolume(const class AP3QuestVolume* QuestVolume);
	const class AP3QuestVolume* GetQuestVolume(const struct FGameplayTagContainer& GameplayTagsAll) const;

	/**
	 * Quest Actors
	 */
	void RegisterQuestActor(class AP3Actor* Actor);
	void UnregisterQuestActor(class AP3Actor* Actor);
	class AP3Actor* GetQuestActor(const struct FGameplayTagContainer& GameplayTagsAll) const;

	/** Sequence */
	void AddSequencePlayer(class ULevelSequencePlayer* Player);
	void RemoveSequencePlayer(class ULevelSequencePlayer* Player);
	bool IsSequencePossessedObject(const UObject& Object) const;

	/** UObject */
	virtual class UWorld* GetWorld() const override { return World; }

	/**
	 * Messy templates to support networking transition (Unreal replication -> P3Net)
	 */
	template <typename PacketType, typename UserClass, typename... VarTypes>
	bool Client_SendPacketInternal(const UserClass* Object, actorid ActorId, AActor* Actor, const PacketType& Packet, EP3NetComponentType ComponentType, typename TMemFunPtrType<false, UserClass, void (VarTypes..., const FP3ClientToDediHandlerParams&)>::Type InFunc, FName HandlerFunctionName, bool bReliable = false)
	{
		FP3StoreBitWriter BitWriter(this, 256, true);
		PacketType::StaticStruct()->SerializeBin(BitWriter, const_cast<PacketType*>(&Packet));

		if (ensure(!BitWriter.IsError()))
		{
			FP3NetHeader Header;
			Header.ComponentType = ComponentType;
			Header.HandlerFunctionName = HandlerFunctionName;

			return Client_SendPacketBuffer(ActorId, Actor, *BitWriter.GetBuffer(), Header, bReliable);
		}

		return false;
	}

	template <typename PacketType, typename UserClass, typename... VarTypes>
	bool Server_SendPacketToPlayerInternal(const FP3NetConnInfo& NetConnInfo, const UserClass* Object, actorid ActorId, AActor* Actor, const PacketType& Packet, EP3NetComponentType ComponentType, bool bCheckPlayerStatus, typename TMemFunPtrType<false, UserClass, void(VarTypes..., const FP3DediToClientHandlerParams&)>::Type InFunc, FName HandlerFunctionName, bool bReliable = false)
	{
		FP3StoreBitWriter BitWriter(this, 256, true);
		PacketType::StaticStruct()->SerializeBin(BitWriter, const_cast<PacketType*>(&Packet));

		if (ensure(!BitWriter.IsError()))
		{
			FP3NetHeader Header;
			Header.ComponentType = ComponentType;
			Header.HandlerFunctionName = HandlerFunctionName;

			return Server_SendPacketBufferToPlayer(NetConnInfo, ActorId, Actor, *BitWriter.GetBuffer(), Header, bCheckPlayerStatus, bReliable);
		}

		return false;
	}

	template <typename UserClass, typename... VarTypes>
	bool Server_SendRawDataToPlayerInternal(const FP3NetConnInfo& NetConnInfo, const UserClass* Object, actorid ActorId, AActor* Actor, const TArray<uint8>& RawData, EP3NetComponentType ComponentType, bool bCheckPlayerStatus, typename TMemFunPtrType<false, UserClass, void(VarTypes..., const FP3DediToClientHandlerParams&)>::Type InFunc, FName HandlerFunctionName, bool bReliable = false)
	{
		FP3NetHeader Header;
		Header.ComponentType = ComponentType;
		Header.HandlerFunctionName = HandlerFunctionName;

		return Server_SendPacketBufferToPlayer(NetConnInfo, ActorId, Actor, RawData, Header, bCheckPlayerStatus, bReliable);
	}

	template <typename PacketType, typename UserClass, typename... VarTypes>
	void Server_MulticastPacketInternal(const UserClass* Object, actorid ActorId, AActor* Actor, const PacketType& Packet, EP3NetComponentType ComponentType, typename TMemFunPtrType<false, UserClass, void (VarTypes..., const FP3DediToClientHandlerParams&)>::Type InFunc, FName HandlerFunctionName, bool bRelaible = false)
	{
		FP3StoreBitWriter BitWriter(this, 512, true);
		PacketType::StaticStruct()->SerializeBin(BitWriter, const_cast<PacketType*>(&Packet));

		if (ensure(!BitWriter.IsError()))
		{
			FP3NetHeader Header;
			Header.ComponentType = ComponentType;
			Header.HandlerFunctionName = HandlerFunctionName;

			Server_MulticastPacketBuffer(ActorId, Actor, *BitWriter.GetBuffer(), Header, bRelaible);
		}
	}

	void Client_HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header);
	void Server_HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header);

	/**
	 * Console commands
	 */
	void OnDumpConsoleCommand(const TArray<FString>& Args);

	/**
	 * Actor cache
	 */
	void AddToActorCache(UClass* ActorClass, AActor* Actor);
	void RemoveFromActorCache(UClass* ActorClass, AActor* Actor);

	template<typename ActorClass>
	void FindActorsFromCache(TArray<ActorClass*>& OutActors) const
	{
		TArray<TWeakObjectPtr<AActor>> MatchingActors;
		CachedActors.MultiFind(ActorClass::StaticClass(), MatchingActors);

		for (TWeakObjectPtr<AActor>& ActorPtr : MatchingActors)
		{
			ActorClass* Actor = Cast<ActorClass>(ActorPtr.Get());

			if (Actor)
			{
				OutActors.Add(Actor);
			}
		}
	}

private:
	void Server_Tick(float DeltaSeconds);
	void TickUnrealNetModeDebug(float DeltaSeconds);

	bool Client_SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const;
	bool Server_MulticastPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const;
	bool Server_SendPacketBufferToPlayer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bCheckPlayerStatus, bool bReliable) const;

	void Server_AddActor(AActor* Actor);
	void Multicast_DamageNonCommandActor(const FP3NetDamageNonCommandActor& NetDamage);

	/** 
	 * Engine event handlers
	 */
	UFUNCTION()
	void Server_OnActorDestroyed(AActor* Actor);

	UFUNCTION()
	void Client_OnLevelAddedToWorld(ULevel* InLevel, UWorld* InWorld);

	UFUNCTION()
	void Server_OnLevelAddedToWorld(ULevel* InLevel, UWorld* InWorld);

	UFUNCTION()
	void Server_OnLevelRemovedFromWorld(ULevel* InLevel, UWorld* InWorld);

	UFUNCTION()
	void OnPreLoadMap(const FString& MapName);

	UFUNCTION()
	void OnPostLoadMapWithWorld(UWorld* LoadedWorld);

	UFUNCTION()
	void OnWorldDestroyed(UWorld* DestroyedWorld);

	UFUNCTION()
	void OnHUDPostRender(class AHUD* HUD, class UCanvas* Canvas);

	EP3NetMode GetP3NetMode() const;

	UPROPERTY()
	class UP3GameInstance* GameInstance = nullptr;

	UPROPERTY()
	UWorld* World = nullptr;

	/** VIP actors */
	actorid Server_NextId = 1;

	/** Registered actors. [ActorId, Actor*] */
	UPROPERTY(Transient)
	TMap<int64, AActor*> Actors;

	FP3ServerWorldActorAdded Server_ActorAdded;
	FP3ServerWorldActorRemoved Server_ActorRemoved;

	/** */
	UPROPERTY()
	TArray<AActor*> Server_BeginPlayQueue;

	/** Ticker */
	class FP3WorldTick* WorldTick = nullptr;

	/** 
	 * Sub systems
	 */
	UPROPERTY(Transient)
	class UP3ServerWorld* Server_World;

	UPROPERTY(Transient)
	class UP3ClientWorld* Client_World;

	UPROPERTY(Transient)
	class AP3WorldSystem* Net_WorldSystem;

	UPROPERTY(Transient)
	TArray<class AFlockManager*> Server_FlockManagers;

	UPROPERTY(Transient)
	TArray<const class AP3ZoneVolume*> ZoneVolumes;

	UPROPERTY(Transient)
	TArray<const class AP3QuestVolume*> QuestVolumes;

	UPROPERTY(Transient)
	TArray<class AP3Actor*> QuestActors;

	/** Sequence players */
	UPROPERTY(Transient)
	TArray<class ULevelSequencePlayer*> SequencePlayers;

	/** 
	 * Actor list for search-heavy actor classes
	 */
	TMultiMap<TWeakObjectPtr<UClass>, TWeakObjectPtr<AActor>> CachedActors;

	FP3TimeOfDay TimeOfDay;

	/** Debug purpose only! Do not use directly, use GetNetMode() */
	mutable EP3NetMode Debug_NetMode = EP3NetMode::MAX;
	float NetModeDebugPrintTimeSeconds = 0.0f;

	/** 
	 * Delegate Handlers
	 */
	FDelegateHandle Client_LevelAddedToWorldDelegateHandle;

	/** Console commands */
	IConsoleCommand* ConsoleCommandDump;
};
