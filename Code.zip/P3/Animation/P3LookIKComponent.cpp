// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3LookIKComponent.h"

#include "Components/SkeletalMeshComponent.h"
#include "Engine/World.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Character.h"
#include "GameFramework/Pawn.h"

UP3LookIK::UP3LookIK()
{
}

bool UP3LookIK::GetLookAtTargetLocation(FVector& OutLocation) const
{
	if (!CurrentTargetActor)
	{
		return false;
	}

	APawn* TargetPawn = Cast<APawn>(CurrentTargetActor);
	if (TargetPawn)
	{
		FRotator EyeRotator;
		TargetPawn->GetActorEyesViewPoint(OutLocation, EyeRotator);
	}
	else
	{
		OutLocation = CurrentTargetActor->GetActorLocation();
	}

	return true;
}

void UP3LookIK::TickLookIK(class APawn& OwnerPawn, float DeltaTime)
{
	// Do not run this on server since it's meaningless(and it must be meaningless)
	ensure(GIsClient);

	TickTarget(OwnerPawn, DeltaTime);

	PickNewTarget();
}

void UP3LookIK::TickTarget(class APawn& OwnerPawn, float DeltaSeconds)
{
	// Update old candidates
	for (FInterestingActor& InterestingActor : InterestingActors)
	{
		UpdateInterestingActor(OwnerPawn, InterestingActor);
	}

	FCollisionObjectQueryParams ObjectQueryParams(ECC_Pawn);
	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(&OwnerPawn);

	FCollisionShape Sphere;
	Sphere.SetSphere(LookIKConfig.TargetDistance);

	TArray<struct FOverlapResult> OverlapResults;

	// Find pawns
	OwnerPawn.GetWorld()->OverlapMultiByObjectType(OverlapResults, OwnerPawn.GetActorLocation(), FQuat::Identity, ObjectQueryParams, Sphere, QueryParams);

	for (const FOverlapResult& OverlapResult : OverlapResults)
	{
		AActor* Actor = OverlapResult.GetActor();
		if (Actor)
		{
			AddOrUpdateTarget(OwnerPawn, *Actor);
		}
	}
}

void UP3LookIK::AddOrUpdateTarget(class APawn& OwnerPawn, AActor& Actor)
{
	FInterestingActor* Found = InterestingActors.FindByPredicate([&Actor](const FInterestingActor& InterestingActor) -> bool {
		return (&Actor == InterestingActor.Actor.Get());
	});

	if (Found)
	{
		UpdateInterestingActor(OwnerPawn, *Found);
	}
	else
	{
		FInterestingActor NewInterestingActor;
		NewInterestingActor.Actor = &Actor;

		UpdateInterestingActor(OwnerPawn, NewInterestingActor);

		InterestingActors.Add(MoveTemp(NewInterestingActor));
	}
}

void UP3LookIK::UpdateInterestingActor(class APawn& OwnerPawn, struct FInterestingActor& InterestingActor)
{
	AActor* TargetActor = InterestingActor.Actor.Get();

	if (!TargetActor)
	{
		return;
	}

	const FVector MyLocation = OwnerPawn.GetActorLocation();
	const FVector TargetLocation = TargetActor->GetActorLocation();

	InterestingActor.LastUpdatedTimeSeconds = OwnerPawn.GetWorld()->GetTimeSeconds();
	InterestingActor.DistanceSquared = (TargetLocation - MyLocation).SizeSquared();
}

void UP3LookIK::PickNewTarget()
{
	FInterestingActor* PickedActor = nullptr;
	float MaxPoints = 0;

	const float MaxDistanceSquared = FMath::Square(LookIKConfig.TargetDistance);

	for (FInterestingActor& InterestingActor : InterestingActors)
	{
		if (!InterestingActor.Actor.Get())
		{
			return;
		}

		const float Points = (MaxDistanceSquared - InterestingActor.DistanceSquared) / MaxDistanceSquared;

		if (MaxPoints < Points)
		{
			MaxPoints = Points;
			PickedActor = &InterestingActor;
		}
	}

	if (PickedActor)
	{
		CurrentTargetActor = PickedActor->Actor.Get();
		ensure(CurrentTargetActor);
	}
	else
	{
		CurrentTargetActor = nullptr;
	}
}
