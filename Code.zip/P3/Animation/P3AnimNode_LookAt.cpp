// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AnimNode_LookAt.h"

#include "Animation/AnimInstanceProxy.h"
#include "AnimationCoreLibrary.h"


#include "Engine/SkeletalMeshSocket.h"
#include "P3AnimInstance.h"

#include "P3Log.h"

static TAutoConsoleVariable<int32> CVarP3EnableLookIKSocket(
	TEXT("p3.enableLookIKSocket"),
	1,
	TEXT(""), ECVF_Cheat);

FP3AnimNode_LookAt::FP3AnimNode_LookAt()
	: LookAtTarget(FVector(100.f, 0.f, 0.f))
	, LookAtAxis(DefaultLookAtAxis)
	, bUseLookUpAxis(false)
	, LookUpAxis(DefaultLookUpAxis)
{
}

void FP3AnimNode_LookAt::UpdateInternal(const FAnimationUpdateContext& Context)
{
	FAnimNode_SkeletalControlBase::UpdateInternal(Context);
	ensure(CVarP3EnableLookIK.GetValueOnAnyThread());

	CurrentDeltaTimeSeconds = Context.GetDeltaTime();
}

void FP3AnimNode_LookAt::Initialize_AnyThread(const FAnimationInitializeContext& Context)
{
	FAnimNode_SkeletalControlBase::Initialize_AnyThread(Context);
}

void FP3AnimNode_LookAt::EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms)
{
	check(OutBoneTransforms.Num() == 0);

	if (!ensure(CVarP3EnableLookIK.GetValueOnAnyThread()))
	{
		return;
	}

	// set up current transforms (neck bones, socket)
	InitializeLookAtInfos(Output);

	// get target location
	FVector TargetLocationInComponentSpace = Output.AnimInstanceProxy->GetComponentTransform().InverseTransformPosition(LookAtTarget);

	// adjust neck rotations
	AdjustNecks(TargetLocationInComponentSpace);

	// Set New Transform 
	ApplyDeltaRotations(OutBoneTransforms);
}

bool FP3AnimNode_LookAt::IsValidToEvaluate(const USkeleton* Skeleton, const FBoneContainer& RequiredBones)
{
	if (!CVarP3EnableLookIK.GetValueOnAnyThread())
	{
		return false;
	}

	if (!bIsEnabled)
	{
		return false;
	}

	FCompactPoseBoneIndex LastBoneIndex = InvalidBoneIndex;
	for (FP3LookAtNeckInfo& NeckInfo : NeckInfos)
	{
		if (!NeckInfo.BoneToModify.IsValidToEvaluate(RequiredBones))
		{
			return false;
		}

		NeckInfo.BoneIndex = NeckInfo.BoneToModify.GetCompactPoseIndex(RequiredBones);
		if (NeckInfo.BoneIndex < LastBoneIndex)
		{
			return false;
		}
		LastBoneIndex = NeckInfo.BoneIndex;
	}

	if (!CVarP3EnableLookIKSocket.GetValueOnAnyThread())
	{
		return true;
	}

	if (BaseSocketInfo.SocketName == NAME_None)
	{
		return false;
	}

	const USkeletalMeshSocket* Socket = Skeleton->FindSocket(BaseSocketInfo.SocketName);
	if (!Socket)
	{
		return false;
	}

	const FCompactPoseBoneIndex SocketBoneIndex{ RequiredBones.GetPoseBoneIndexForBoneName(Socket->BoneName) };
	for (int32 NeckIndex = 0; NeckIndex < NeckInfos.Num(); ++NeckIndex)
	{
		const FP3LookAtNeckInfo& NeckInfo = NeckInfos[NeckIndex];
		if (NeckInfo.BoneIndex == SocketBoneIndex)
		{
			BaseSocketInfo.ParentNeckInfoIndex = NeckIndex;
			return true;
		}
	}

	return false;
}

// 매번 재계산 필요 x
FName FP3AnimNode_LookAt::GetModifyBoneNames() const
{
	FString BoneNames = TEXT("");
	for (const FP3LookAtNeckInfo& Info : NeckInfos)
	{
		if (BoneNames.Len() != 0)
		{
			BoneNames += TEXT(", ");
		}
		BoneNames += Info.BoneToModify.BoneName.ToString();
	}

	return FName(*BoneNames);
}

void FP3AnimNode_LookAt::InitializeBoneReferences(const FBoneContainer& RequiredBones)
{
	for (FP3LookAtNeckInfo& NeckInfo : NeckInfos)
	{
		NeckInfo.BoneToModify.Initialize(RequiredBones);
	}
}

void FP3AnimNode_LookAt::InitializeLookAtInfos(FComponentSpacePoseContext& Context)
{
	if (!ensure(Context.AnimInstanceProxy))
	{
		return;
	}

	const USkeletalMeshComponent& MeshComp = *Context.AnimInstanceProxy->GetSkelMeshComponent();
	const FBoneContainer& BoneContainer = Context.Pose.GetPose().GetBoneContainer();
	for (FP3LookAtNeckInfo& NeckInfo : NeckInfos)
	{
		ensure(NeckInfo.BoneToModify.IsValidToEvaluate(BoneContainer));
		NeckInfo.ComponentTransform = Context.Pose.GetComponentSpaceTransform(NeckInfo.BoneIndex);
		NeckInfo.CurrentTransform = NeckInfo.ComponentTransform;

		FCompactPoseBoneIndex ParentBoneIndex = BoneContainer.GetParentBoneIndex(NeckInfo.BoneIndex);
		FTransform ParentComponentTransform = Context.Pose.GetComponentSpaceTransform(ParentBoneIndex);
		NeckInfo.LocalTransform = NeckInfo.ComponentTransform.GetRelativeTransform(ParentComponentTransform);

		//NeckInfo.LookAtRotation = FRotator::ZeroRotator;
	}

	if (MeshComp.GetSocketByName(BaseSocketInfo.SocketName))
	{
		ensure(BaseSocketInfo.SocketName != NAME_None);

		const USkeletalMeshSocket* Socket = MeshComp.GetSocketByName(BaseSocketInfo.SocketName);
		BaseSocketInfo.LocalTransform = Socket->GetSocketLocalTransform();
	}
}

void FP3AnimNode_LookAt::AdjustNecks(const FVector& TargetLocationInComponentSpace)
{
	// 총 회전량을 각 시선 처리 요소들에게 분배
	// (반경, 반응 속도 등의 제약을 반영)
	// TODO 각종 제약이 자연스러운 회전량 분배에 영향을 준다면 반복 처리를 넣어보자

	TArray<FRotator> NeckRotations;
	FRotator TargetRotation = CalcTargetRotation(TargetLocationInComponentSpace);
	DivideNeckRotations(TargetRotation, NeckRotations); 
	//ensure(NeckRotations.Num() == NeckInfos.Num());
	RotateNecks(NeckRotations);
}

FRotator FP3AnimNode_LookAt::CalcTargetRotation(const FVector& TargetLocationInComponentSpace) const
{
	if (!bIsValidTarget)
	{
		return FRotator::ZeroRotator;
	}

	// get base transform (first bone or socket)
	const FTransform BaseTransform = GetBaseTransform();
	// lookat vector
	FVector LookAtVector = LookAtAxis.GetTransformedAxis(BaseTransform);
	// find look up vector in local space
	FVector LookUpVector = LookUpAxis.GetTransformedAxis(BaseTransform);
	// Find new transform from look at info
	FRotator TargetRotation = AnimationCore::SolveAim(BaseTransform, TargetLocationInComponentSpace, LookAtVector, bUseLookUpAxis, LookUpVector).Rotator();

	// 간단한 시야 처리
	// TODO 경계를 넘나드는 경우 대응 필요
	if (FMath::Abs(TargetRotation.Pitch) > SightRange.Pitch || FMath::Abs(TargetRotation.Yaw) > SightRange.Yaw)
	{
		return FRotator::ZeroRotator;
	}

	return TargetRotation;
}

void FP3AnimNode_LookAt::DivideNeckRotations(const FRotator& TargetRotation, TArray<FRotator>& OutNeckRotations)
{
	TArray<float> PitchWeights, YawWeights;
	PitchWeights.Empty(NeckInfos.Num());
	YawWeights.Empty(NeckInfos.Num());
	OutNeckRotations.Empty(NeckInfos.Num());
	
	float PitchWeightSum = 0.f;
	float YawWeightSum = 0.f;
	for (const FP3LookAtNeckInfo& NeckInfo : NeckInfos)
	{
		PitchWeights.Add(NeckInfo.Weight);
		PitchWeightSum += NeckInfo.Weight;
		YawWeights.Add(NeckInfo.Weight);
		YawWeightSum += NeckInfo.Weight;
		OutNeckRotations.Add(FRotator::ZeroRotator);
	}

	// 단순 pitch, yaw 분배라서 인간 형태의 척추-목(-눈) 구조에서만 의도대로 동작한다

	for (int32 NeckIndex = 0; NeckIndex < NeckInfos.Num(); ++NeckIndex)
	{
		FP3LookAtNeckInfo& NeckInfo = NeckInfos[NeckIndex];

		float MaxDeltaInTick = NeckInfo.RotationLimit / NeckInfo.InterpolationTimeSeconds * CurrentDeltaTimeSeconds;

		if (PitchWeightSum > 0.f)
		{
			float IdealAngle = TargetRotation.Pitch * (PitchWeights[NeckIndex] / PitchWeightSum);
			float RangedAngle = FMath::Clamp(IdealAngle, -NeckInfo.RotationLimit, NeckInfo.RotationLimit);
			float DeltaInTick = FMath::Clamp(RangedAngle - NeckInfo.LookAtRotation.Pitch, -MaxDeltaInTick, MaxDeltaInTick);
			OutNeckRotations[NeckIndex].Pitch = NeckInfo.LookAtRotation.Pitch + DeltaInTick;
		}

		if (YawWeightSum > 0.f)
		{
			float IdealAngle = TargetRotation.Yaw * (YawWeights[NeckIndex] / YawWeightSum);
			float RangedAngle = FMath::Clamp(IdealAngle, -NeckInfo.RotationLimit, NeckInfo.RotationLimit);
			float DeltaInTick = FMath::Clamp(RangedAngle - NeckInfo.LookAtRotation.Yaw, -MaxDeltaInTick, MaxDeltaInTick);
			OutNeckRotations[NeckIndex].Yaw = NeckInfo.LookAtRotation.Yaw + DeltaInTick;
		}
	}
}

void FP3AnimNode_LookAt::RotateNecks(const TArray<FRotator>& Rotations)
{
	if (!ensure(Rotations.Num() == NeckInfos.Num()))
	{
		return;
	}

	if (!ensure(Rotations.Num() && NeckInfos.Num()))
	{
		return;
	}

	for (int32 NeckIndex = 0; NeckIndex < NeckInfos.Num(); ++NeckIndex)
	{
		ensure(Rotations.IsValidIndex(NeckIndex));
		FP3LookAtNeckInfo& NeckInfo = NeckInfos[NeckIndex];
		NeckInfo.LookAtRotation = Rotations[NeckIndex];
	}

	NeckInfos[0].CurrentTransform = NeckInfos[0].ComponentTransform;
	for (int32 NeckIndex = 0; NeckIndex < NeckInfos.Num(); ++NeckIndex)
	{
		FP3LookAtNeckInfo& NeckInfo = NeckInfos[NeckIndex];

		FTransform BoneTransform = FTransform::Identity;
		if (NeckIndex == 0)
		{
			BoneTransform = NeckInfo.ComponentTransform;
		}
		else if (NeckInfos.IsValidIndex(NeckIndex - 1))
		{
			BoneTransform = NeckInfo.LocalTransform * NeckInfos[NeckIndex - 1].CurrentTransform;
		}
		else
		{
			ensureMsgf(false, TEXT("?"));
		}
		
		BoneTransform.SetRotation(NeckInfo.LookAtRotation.Quaternion() * BoneTransform.GetRotation());
		NeckInfo.CurrentTransform = BoneTransform;
	}
}

FTransform FP3AnimNode_LookAt::GetBaseTransform() const
{
	if (CVarP3EnableLookIKSocket.GetValueOnAnyThread() && ensure(NeckInfos.IsValidIndex(BaseSocketInfo.ParentNeckInfoIndex)))
	{
		return BaseSocketInfo.LocalTransform * NeckInfos[BaseSocketInfo.ParentNeckInfoIndex].CurrentTransform;
	}
	else if (ensure(NeckInfos.Num() > 0))
	{
		return NeckInfos[NeckInfos.Num() - 1].CurrentTransform;
	}
	else
	{
		ensureMsgf(0, TEXT("Invalid look at bone infos"));
		return FTransform::Identity;
	}
}

void FP3AnimNode_LookAt::ApplyDeltaRotations(TArray<FBoneTransform>& OutBoneTransforms) const
{
	for (const FP3LookAtNeckInfo& NeckInfo : NeckInfos)
	{
		OutBoneTransforms.Add(FBoneTransform(NeckInfo.BoneIndex, NeckInfo.CurrentTransform));
	}
}

