// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3LookIKComponent.generated.h"

/** Look IK Config parameters */
USTRUCT(BlueprintType)
struct FP3LookIKConfig
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	FName LookDirectionSocketName;

	/** When something interest is closer than this, look at it */
	UPROPERTY(EditAnywhere)
	float TargetDistance = 500;
};

/**
 * Look IK
 * - find interesting target
 * - compare animated look direction and target direction
 * - if it's small enough(within neck's rotation angle), ask anim instance to rotate neck or more bones
 */
UCLASS()
class P3_API UP3LookIK : public UObject
{
	GENERATED_BODY()

public:
	UP3LookIK();

	/** Return false if no target */
	bool GetLookAtTargetLocation(FVector& OutLocation) const;

	void TickLookIK(class APawn& OwnerPawn, float DeltaTime);
	
private:
	struct FInterestingActor
	{
		TWeakObjectPtr<AActor> Actor;
		float LastUpdatedTimeSeconds = 0;
		float DistanceSquared = 0;
	};

	void TickTarget(class APawn& OwnerPawn, float DeltaSeconds);
	void AddOrUpdateTarget(class APawn& OwnerPawn, AActor& Actor);
	void UpdateInterestingActor(class APawn& OwnerPawn, FInterestingActor& InterestingActor);
	void PickNewTarget();

	//void TickIK(float DeltaSeconds);

	UPROPERTY(EditAnywhere)
	FP3LookIKConfig LookIKConfig;

	/** Look at target candidates */
	TArray<FInterestingActor> InterestingActors;

	/** Actor which we are looking at */
	UPROPERTY(Transient)
	AActor* CurrentTargetActor;
};
