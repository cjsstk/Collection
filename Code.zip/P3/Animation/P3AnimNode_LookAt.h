// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "BoneControllers/AnimNode_SkeletalControlBase.h"
#include "CommonAnimTypes.h"
#include "Animation/AnimNodeBase.h"
#include "P3AnimNode_LookAt.generated.h"

// TODO 최적화?

static const FCompactPoseBoneIndex InvalidBoneIndex{ INDEX_NONE };
static const FVector DefaultLookAtAxis(0.f, 1.f, 0.f);
static const FVector DefaultLookUpAxis(0.f, 0.f, 1.f);

// TODO 눈?
// struct FP3LookAtEyeInfo

/** LookIK 요소 - 목 */
USTRUCT()
struct FP3LookAtNeckInfo
{
	GENERATED_BODY()

	/** 타겟 목 뼈 */
	UPROPERTY(EditAnywhere)
	FBoneReference BoneToModify;

	/** 보간 시간(초) : 최대 가동 범위까지 도달하는 데 걸리는 시간 */
	UPROPERTY(EditAnywhere)
	float InterpolationTimeSeconds = 1.0f;
	
	/** LookIK 요소간 가중치 */
	UPROPERTY(EditAnywhere)
	float Weight = 1.0f;

	/** 뼈 가동 범위 제한 */
	UPROPERTY(EditAnywhere)
	float RotationLimit = 0.0f;

// 여기부턴 구현 편의 요소
	FCompactPoseBoneIndex BoneIndex = InvalidBoneIndex;
	FTransform LocalTransform = FTransform::Identity;
	FTransform ComponentTransform = FTransform::Identity;
	FTransform CurrentTransform = FTransform::Identity;
	FRotator LookAtRotation = FRotator::ZeroRotator;
};

/** LookIK 기준 위치 설정(소켓) */
USTRUCT()
struct FP3LookAtBaseSocketInfo
{
	GENERATED_BODY()

	/** 소켓 이름 */
	UPROPERTY(EditAnywhere)
	FName SocketName = NAME_None;

// 여기부턴 구현 편의 요소
	int32 ParentNeckInfoIndex = -1;
	FTransform LocalTransform = FTransform::Identity;
	FTransform ComponentTransform = FTransform::Identity;
};

/**
 * Smoother version of FAnimNode_LookAt
 */
USTRUCT()
struct P3_API FP3AnimNode_LookAt : public FAnimNode_SkeletalControlBase
{
	GENERATED_BODY()

	/**
	 * 시선 처리 요소 중 목 뼈 정보
	 * 뿌리부터 말단까지 연결된 뼈의 목록이어야 한다
	 */
	UPROPERTY(EditAnywhere, Category = "Neck")
	TArray<FP3LookAtNeckInfo> NeckInfos;

	/** 시선 처리 기준 위치로 삼을 소켓 */
	UPROPERTY(EditAnywhere, Category = "BaseSocket")
	FP3LookAtBaseSocketInfo BaseSocketInfo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = LookAt, meta = (PinShownByDefault))
	FVector LookAtTarget = FVector::ZeroVector;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = LookAt, meta = (PinShownByDefault))
	bool bIsValidTarget = false;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = LookAt, meta = (PinShownByDefault))
	bool bIsEnabled = false;

	UPROPERTY(EditAnywhere)
	FAxis LookAtAxis = DefaultLookAtAxis;

	UPROPERTY(EditAnywhere)
	bool bUseLookUpAxis = false;

	UPROPERTY(EditAnywhere)
	FAxis LookUpAxis = DefaultLookUpAxis;

	UPROPERTY(EditAnywhere)
	FRotator SightRange = FRotator(90.f, 120.f, 0.f);

	FP3AnimNode_LookAt();

	// FAnimNode_Base interface
	virtual void UpdateInternal(const FAnimationUpdateContext& Context) override;
	virtual void Initialize_AnyThread(const FAnimationInitializeContext& Context) override;
	// End of FAnimNode_Base interface

	// FAnimNode_SkeletalControlBase interface
	virtual void EvaluateSkeletalControl_AnyThread(FComponentSpacePoseContext& Output, TArray<FBoneTransform>& OutBoneTransforms) override;
	virtual bool IsValidToEvaluate(const USkeleton* Skeleton, const FBoneContainer& RequiredBones) override;
	// End of FAnimNode_SkeletalControlBase interface

	// for AnimGraphNode_LookAt
	FName GetModifyBoneNames() const;

private:
	// FAnimNode_SkeletalControlBase interface
	virtual void InitializeBoneReferences(const FBoneContainer& RequiredBones) override;
	// End of FAnimNode_SkeletalControlBase interface

	void InitializeLookAtInfos(FComponentSpacePoseContext& Context);
	void AdjustNecks(const FVector& TargetLocationInComponentSpace);
	/** Calculate rotation from base to target */
	FRotator CalcTargetRotation(const FVector& TargetLocationInComponentSpace) const;
	void DivideNeckRotations(const FRotator& TargetRotation, TArray<FRotator>& OutNeckRotations);
	void RotateNecks(const TArray<FRotator>& Rotations);
	/** Get look at base transform(base socket or last neck) */
	FTransform GetBaseTransform() const;
	void ApplyDeltaRotations(TArray<FBoneTransform>& OutBoneTransforms) const;

	float CurrentDeltaTimeSeconds = 0.f;
};
