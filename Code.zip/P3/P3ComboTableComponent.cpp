// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ComboTableComponent.h"

#include "Animation/AnimInstance.h"
#include "Components/CapsuleComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/PlayerController.h"
#include "Particles/ParticleSystemComponent.h"
#include "SlateBlueprintLibrary.h"
#include "UserWidget.h"
#include "Kismet/GameplayStatics.h"

#include "Action/P3PawnActionComponent.h"
#include "P3AnimNotify.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3CharacterMovementComponent.h"
#include "Command/P3CommandComponent.h"
#include "P3HoldableComponent.h"
#include "P3Log.h"
#include "P3Physics.h"
#include "P3StaminaPointComponent.h"
#include "P3Weapon.h"

const FName UP3ComboTableComponent::Name_RootCombo = (TEXT("Root"));

extern TAutoConsoleVariable<int32> CVarP3CombatDebug;

TAutoConsoleVariable<float> CVarP3ComboInputStackClearTimeSeconds(
	TEXT("p3.comboInputStackClearTimeSeconds"),
	0.5f,
	TEXT("stack input clearing time"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ComboAutoMoveTowardsTargetInputScale(
	TEXT("p3.comboAutoMoveTowardsTargetInputScale"),
	0.25f,
	TEXT("automatically move to last damaged target"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3ComboAutoMoveTowardsTarget(
	TEXT("p3.comboAutoMoveTowardsTarget"),
	0,
	TEXT("0: not move, 1: auto move"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3ComboTargetCondition(
	TEXT("p3.comboTargetCondition"),
	0,
	TEXT("0: disable, 1: enable"), ECVF_Cheat);

#undef ComboJsonLog
#define ComboJsonLog(Verbosity, Subject, ...) \
	P3JsonLogWithCategory(P3ComboLog, Verbosity, Subject,	\
		TEXT("Ani"), ComboContext.ActiveComboAnimationName,	\
		TEXT("BeforeAni"), ComboContext.BeforeActiveComboAnimationName,	\
		TEXT("MoveBlock"), ComboContext.LocalControl_bIsAnimNotifyInputMoveBlock,	\
		TEXT("TrunBlock"), ComboContext.LocalControl_bIsAnimNotifyInputTurnBlock,	\
		TEXT("CamMoveBlock"), ComboContext.LocalControl_bIsAnimNotifyInputCameraMoveBlock,	\
		TEXT("ActionBlock"), ComboContext.LocalControl_bIsAnimNotifyPlayActionBlock,	\
		TEXT("AutoMove"), ComboContext.LocalControl_bIsAnimNotifyAutoMoveTowardsTarget,	\
		TEXT("Stance"), EnumToStringShort(EP3CharacterStance, ComboContext.Stance),	\
		TEXT("bIsBlockingMode"), ComboContext.bIsBlockingMode,	\
		TEXT("bIsCrouchBlockingMode"), ComboContext.bIsCrouchBlockingMode,	\
		TEXT("bIsBouncingMode"), ComboContext.bIsBouncingMode, \
		TEXT("bIsMeleeAiming"), ComboContext.bIsMeleeAiming, \
		TEXT("bIsRangedAiming"), ComboContext.bIsRangedAiming, \
		TEXT("bIsStumbling"), ComboContext.bIsStumbling, \
		TEXT("bIsExhausted"), ComboContext.bIsExhausted, \
		TEXT("bIsMovingOnGround"), ComboContext.bIsMovingOnGround, \
		TEXT("bIsFalling"), ComboContext.bIsFalling, \
		TEXT("bIsFlying"), ComboContext.bIsFlying, \
		TEXT("bIsAscending"), ComboContext.bIsAscending, \
		TEXT("bIsMoving"), ComboContext.bIsMoving, \
		TEXT("bCanCombat"), ComboContext.bCanCombat, \
		TEXT("bIsKnockDown"), ComboContext.bIsKnockDown, \
		TEXT("bIsKnockBack"), ComboContext.bIsKnockBack, \
		TEXT("bCanBlock"), ComboContext.bCanBlock, \
		TEXT("bIsMounted"), ComboContext.bIsMounted, \
		TEXT("bHasStunEffect"), ComboContext.bHasStunEffect, \
		TEXT("bIsDamageReceived"), ComboContext.bIsDamageReceived, \
		TEXT("DamageReceivedComboName"), ComboContext.DamageReceivedComboName, \
		TEXT("CurrentStaminaPoint"), ComboContext.CurrentStaminaPoint, \
		TEXT("InputStackClearTimeSeconds"), ComboContext.InputStackClearTimeSeconds, \
		##__VA_ARGS__)

UP3ComboTableComponent::UP3ComboTableComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	bWantsInitializeComponent = true;
}

void UP3ComboTableComponent::OnRegister()
{
	Super::OnRegister();	
}

void UP3ComboTableComponent::OnUnregister()
{
	Super::OnUnregister();	
}

void UP3ComboTableComponent::InitializeComponent()
{
	Super::InitializeComponent();	

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (ensure(Character))
	{
		Character->OnInputPressLeftButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnPressLeftButton);
		Character->OnInputReleaseLeftButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnReleaseLeftButton);
		Character->OnInputPressRightButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnPressRightButton);
		Character->OnInputReleaseRightButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnReleaseRightButton);
		Character->OnInputPressClassButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnPressClassButton);
		Character->OnInputReleaseClassButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnReleaseClassButton);
		Character->OnInputStartSprint.AddUniqueDynamic(this, &UP3ComboTableComponent::OnPressSprintButton);
		Character->OnInputStopSprint.AddUniqueDynamic(this, &UP3ComboTableComponent::OnReleaseSprintButton);
		Character->OnInputMoveForward.AddUniqueDynamic(this, &UP3ComboTableComponent::OnInputMoveForward);
		Character->OnInputMoveRight.AddUniqueDynamic(this, &UP3ComboTableComponent::OnInputMoveRight);
		Character->OnInputPressJumpButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnPressJumpButton);
		Character->OnInputReleaseJumpButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnReleaseJumpButton);
		Character->OnInputStartSpecialAttack.AddUniqueDynamic(this, &UP3ComboTableComponent::OnStartSpecialAttackButton);
		Character->OnInputStopSpecialAttack.AddUniqueDynamic(this, &UP3ComboTableComponent::OnStopSpecialAttackButton);
		Character->OnInputPressEvadeButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnPressEvadeButton);
		Character->OnInputReleaseEvadeButton.AddUniqueDynamic(this, &UP3ComboTableComponent::OnReleaseEvadeButton);		

		if (ensure(Character->GetActionComponent()))
		{
			Character->GetActionComponent()->OnRequestedActionStatusChanged.AddUniqueDynamic(this, &UP3ComboTableComponent::OnActionStatusChanged);
		}

		UAnimInstance* AnimInstance = Character->GetMesh() ? Character->GetMesh()->GetAnimInstance() : nullptr;
		if (AnimInstance)
		{
			AnimInstance->OnMontageStarted.AddUniqueDynamic(this, &UP3ComboTableComponent::OnMontageStarted);
		}

		ComboContext.Character = Character;
	}

	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_InputFlags);	
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_InputButtonPressTimeSeconds);
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_InputDirectionType);
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_Notify);
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_Status);
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_Action);
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_Movement);	
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_Damage);
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_Effect);
	ConditionFunctionPointers.Add(&UP3ComboTableComponent::Condition_Target);
	
	ConditionStartedFunctionPointers.Add(&UP3ComboTableComponent::Condition_Notify);
	ConditionStartedFunctionPointers.Add(&UP3ComboTableComponent::Condition_Status);
	ConditionStartedFunctionPointers.Add(&UP3ComboTableComponent::Condition_Action);
	ConditionStartedFunctionPointers.Add(&UP3ComboTableComponent::Condition_Movement);
	ConditionStartedFunctionPointers.Add(&UP3ComboTableComponent::Condition_Damage);
	ConditionStartedFunctionPointers.Add(&UP3ComboTableComponent::Condition_Effect);
	ConditionStartedFunctionPointers.Add(&UP3ComboTableComponent::Condition_Target);

	ExecutionFunctionPointers.Add(&UP3ComboTableComponent::Execution_Action);
	ExecutionFunctionPointers.Add(&UP3ComboTableComponent::Execution_Command);
	ExecutionFunctionPointers.Add(&UP3ComboTableComponent::Execution_InputFlags);
	ExecutionFunctionPointers.Add(&UP3ComboTableComponent::Execution_Camera);
	ExecutionFunctionPointers.Add(&UP3ComboTableComponent::Execution_Stamina);
	ExecutionFunctionPointers.Add(&UP3ComboTableComponent::Execution_MoveTowardsTarget);
	ExecutionFunctionPointers.Add(&UP3ComboTableComponent::Execution_Movement);
}

void UP3ComboTableComponent::UninitializeComponent()
{
	Super::UninitializeComponent();	

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (ensure(Character))
	{
		Character->OnInputPressLeftButton.RemoveDynamic(this, &UP3ComboTableComponent::OnPressLeftButton);
		Character->OnInputReleaseLeftButton.RemoveDynamic(this, &UP3ComboTableComponent::OnReleaseLeftButton);
		Character->OnInputPressRightButton.RemoveDynamic(this, &UP3ComboTableComponent::OnPressRightButton);
		Character->OnInputReleaseRightButton.RemoveDynamic(this, &UP3ComboTableComponent::OnReleaseRightButton);
		Character->OnInputPressClassButton.RemoveDynamic(this, &UP3ComboTableComponent::OnPressClassButton);
		Character->OnInputReleaseClassButton.RemoveDynamic(this, &UP3ComboTableComponent::OnReleaseClassButton);
		Character->OnInputStartSprint.RemoveDynamic(this, &UP3ComboTableComponent::OnPressSprintButton);
		Character->OnInputStopSprint.RemoveDynamic(this, &UP3ComboTableComponent::OnReleaseSprintButton);
		Character->OnInputMoveForward.RemoveDynamic(this, &UP3ComboTableComponent::OnInputMoveForward);
		Character->OnInputMoveRight.RemoveDynamic(this, &UP3ComboTableComponent::OnInputMoveRight);
		Character->OnInputPressJumpButton.RemoveDynamic(this, &UP3ComboTableComponent::OnPressJumpButton);
		Character->OnInputReleaseJumpButton.RemoveDynamic(this, &UP3ComboTableComponent::OnReleaseJumpButton);
		Character->OnInputStartSpecialAttack.RemoveDynamic(this, &UP3ComboTableComponent::OnStartSpecialAttackButton);
		Character->OnInputStopSpecialAttack.RemoveDynamic(this, &UP3ComboTableComponent::OnStopSpecialAttackButton);
		Character->OnInputPressEvadeButton.RemoveDynamic(this, &UP3ComboTableComponent::OnPressEvadeButton);
		Character->OnInputReleaseEvadeButton.RemoveDynamic(this, &UP3ComboTableComponent::OnReleaseEvadeButton);		

		if (ensure(Character->GetActionComponent()))
		{
			Character->GetActionComponent()->OnRequestedActionStatusChanged.RemoveDynamic(this, &UP3ComboTableComponent::OnActionStatusChanged);
		}

		UAnimInstance* AnimInstance = Character->GetMesh() ? Character->GetMesh()->GetAnimInstance() : nullptr;
		if (AnimInstance)
		{
			AnimInstance->OnMontageStarted.RemoveDynamic(this, &UP3ComboTableComponent::OnMontageStarted);
		}

		ComboContext.Character = nullptr;
	}
}

void UP3ComboTableComponent::BeginPlay()
{
	Super::BeginPlay();	
}

void UP3ComboTableComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void UP3ComboTableComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!IsComboEnabled())
	{
		return;
	}

	if (!ComboContext.Character.IsValid())
	{
		ensure(0);
		return;
	}

	TickChangeWeapon();

	ComboContext.Stance = ComboContext.Character->GetStance();
	ComboContext.bIsBlockingMode = ComboContext.Character->GetCharacterStoreBP().bIsBlocking;
	ComboContext.bIsCrouchBlockingMode = ComboContext.Character->GetCharacterStoreBP().bIsCrouchBlocking;
	ComboContext.bIsBouncingMode = ComboContext.Character->GetCharacterStoreBP().bIsBouncingMode;
	ComboContext.bIsMeleeAiming = ComboContext.Character->GetCharacterStoreBP().bIsMeleeAiming;
	ComboContext.bIsRangedAiming = ComboContext.Character->GetCharacterStoreBP().bIsAiming;
	ComboContext.bIsStumbling = ComboContext.Character->GetCharacterStoreBP().bIsStumbling;
	ComboContext.bCanCombat = ComboContext.Character->CanCombat();
	ComboContext.bCanBlock = ComboContext.Character->CanBlock();
	ComboContext.bIsMounted = ComboContext.Character->IsMounted();

	UP3StaminaPointComponent* StaminaComp = ComboContext.Character->GetStaminaComponent();
	if (ensure(StaminaComp))
	{
		ComboContext.bIsExhausted = StaminaComp->IsExhausted();
		ComboContext.CurrentStaminaPoint = StaminaComp->GetStaminaPoint();
	}
	else
	{
		ComboContext.bIsExhausted = false;
	}

	UP3CharacterMovementComponent* MovementComp = ComboContext.Character->GetP3CharacterMovementBP();
	if (ensure(MovementComp))
	{
		ComboContext.bIsMovingOnGround = MovementComp->IsMovingOnGround();
		ComboContext.bIsFalling = MovementComp->IsFalling();
		ComboContext.bIsFlying = MovementComp->IsFlying();
		ComboContext.bIsAscending = MovementComp->Velocity.Z > 0.f;
		ComboContext.bIsMoving = !MovementComp->Velocity.IsZero();
		ComboContext.MaxJumpHeight = MovementComp->GetMaxJumpHeight();
		ComboContext.CurrentSpeed = MovementComp->Velocity.Size2D();
	}
	else
	{
		ComboContext.bIsMovingOnGround = false;
		ComboContext.bIsFalling = false;
		ComboContext.bIsFlying = false;
		ComboContext.bIsAscending = false;
		ComboContext.bIsMoving = false;
		ComboContext.MaxJumpHeight = 0.f;
		ComboContext.CurrentSpeed = 0.f;
	}

	UP3CharacterEffectComponent* EffectComp = ComboContext.Character->GetEffectComponent();
	if (ensure(EffectComp))
	{
		ComboContext.bHasStunEffect = EffectComp->HasStunEffect();
	}
	else
	{
		ComboContext.bHasStunEffect = false;
	}

	UP3PawnActionComponent* ActionComp = ComboContext.Character->GetActionComponent();
	if (ensure(ActionComp))
	{
		ComboContext.bIsKnockDown = ActionComp->IsInKnockDown();
		ComboContext.bIsKnockBack = ActionComp->IsInKnockBack();
		ComboContext.ActiveActionType = ActionComp->GetActiveActionType();

		if (ComboContext.ActiveActionType != EPawnActionType::Invalid
			&& ComboContext.RequestedActionType != EPawnActionType::Invalid			
			&& ComboContext.RequestedActionType != ComboContext.ActiveActionType)
		{
			ClearCombo(false);			
		}
	}
	else
	{
		ComboContext.bIsKnockDown = false;
		ComboContext.bIsKnockBack = false;
	}

	if (!P3Core::IsP3NetModeStandalone(*ComboContext.Character) 
		&& P3Core::IsP3NetModeServerInstance(*ComboContext.Character))
	{
		return;
	}

	if (ComboContext.ActiveActionType == EPawnActionType::Invalid 
		|| ComboContext.ActiveActionType == EPawnActionType::CombatCombo
		|| ComboContext.ActiveActionType == EPawnActionType::CombatRoll)
	{
		if (CurrentComboName == UP3ComboTableComponent::Name_RootCombo)
		{
			for (const FP3ComboEdgeRow& ComboEdgeRow : ComboEdgeTable)
			{
				if (ComboEdgeRow.ComboName != UP3ComboTableComponent::Name_RootCombo)
				{
					continue;
				}

				if (!TickStartedCondition(DeltaTime, ComboEdgeRow))
				{
					continue;
				}

				const FP3ComboRow* ComboRow = ComboTable.Find(ComboEdgeRow.NextComboName);
				if (!ensure(ComboRow))
				{
					continue;
				}

				StartCombo(*ComboRow);
				CurrentComboName = ComboEdgeRow.NextComboName;
				break;
			}
		}
		else
		{
			const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);

			if (ensure(ComboRow))
			{
				ProgressCombo(*ComboRow, DeltaTime);

				FName NextComboName = NAME_None;
				for (const FP3ComboEdgeRow& ComboEdgeRow : ComboEdgeTable)
				{
					if (ComboEdgeRow.ComboName == UP3ComboTableComponent::Name_RootCombo)
					{
						continue;
					}

					if (ComboEdgeRow.ComboName != CurrentComboName)
					{
						continue;
					}

					if (!TickStartedCondition(DeltaTime, ComboEdgeRow))
					{
						continue;
					}

					const FP3ComboRow* NextComboRow = ComboTable.Find(ComboEdgeRow.NextComboName);
					if (!ensure(NextComboRow))
					{
						continue;
					}
					
					ComboContext.NextComboName = NextComboRow->ComboName;
					ComboContext.NextComboAnimationName = NextComboRow->AnimationName;					

					ExitCombo(*ComboRow);
					ResetCombo();
					StartCombo(*NextComboRow);
					NextComboName = ComboEdgeRow.NextComboName;
					break;

				}

				if (TickInProgressCondition(DeltaTime, *ComboRow))
				{
					CurrentComboName = NextComboName == NAME_None ? CurrentComboName : NextComboName;
				}
				else
				{
					if (NextComboName == NAME_None)
					{
						ExitCombo(*ComboRow);
						ResetCombo();						
					}
					else
					{
						CurrentComboName = NextComboName;
					}

					ComboContext.Target = nullptr;
				}
			}
		}
	}
	
	TickInputButtonPressTimeSeconds(DeltaTime);
	TickInputStack(DeltaTime);
	TickCommand();
	TickCamera();	

	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::NormalAttackUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::PrivateActionUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SpecialAttackUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::ClassAttackUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SprintUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::JumpUp);	
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::EvadeUp);	
}

void UP3ComboTableComponent::Client_OnDisconnected()
{
	ClearCombo();	
}

bool UP3ComboTableComponent::IsComboEnabled() const
{
	return bIsComboEnabled;
}

bool UP3ComboTableComponent::IsNotifyStateSignalEnabled(const FName& SignalName)
{
	UP3PawnActionComponent* ActionComp = ComboContext.Character.IsValid() ? ComboContext.Character->GetActionComponent() : nullptr;
	if (ensure(ActionComp))
	{
		if (ActionComp->GetActiveActionType() == EPawnActionType::CombatCombo
			|| ActionComp->GetActiveActionType() == EPawnActionType::CombatReactionHit)
		{
			return ComboContext.NotifyStateSignal.FindRef(SignalName) == true;
		}
	}

	return true;
}

void UP3ComboTableComponent::OnPressLeftButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::NormalAttackDown);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::NormalAttackUp);
}

void UP3ComboTableComponent::OnReleaseLeftButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::NormalAttackUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::NormalAttackDown);
}

void UP3ComboTableComponent::OnPressRightButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::PrivateActionDown);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::PrivateActionUp);
}

void UP3ComboTableComponent::OnReleaseRightButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::PrivateActionUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::PrivateActionDown);
}

void UP3ComboTableComponent::OnPressClassButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::ClassAttackDown);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::ClassAttackUp);
}

void UP3ComboTableComponent::OnReleaseClassButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::ClassAttackUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::ClassAttackDown);
}

void UP3ComboTableComponent::OnPressSprintButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SprintDown);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SprintUp);
}

void UP3ComboTableComponent::OnReleaseSprintButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SprintUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SprintDown);
}

void UP3ComboTableComponent::OnInputMoveForward(float InValue)
{
	if (InValue == 0.f || !ensure(ComboContext.Character.IsValid()))
	{
		ComboContext.InputForwardDirection = FVector::ZeroVector;
		RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveForward);
		RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveBack);
		return;
	}

	ComboContext.InputForwardDirection = FRotationMatrix(FRotator(0.f, ComboContext.Character->GetControlRotation().Yaw, 0.f)).GetUnitAxis(EAxis::X) * InValue;

	if (InValue > 0.f)
	{
		AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveForward);		
	}
	else
	{
		AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveBack);
	}
}

void UP3ComboTableComponent::OnInputMoveRight(float InValue)
{
	if (InValue == 0.f || !ensure(ComboContext.Character.IsValid()))
	{
		ComboContext.InputRightDirection = FVector::ZeroVector;
		RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveRight);
		RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveLeft);
		return;
	}

	ComboContext.InputRightDirection = FRotationMatrix(FRotator(0.f, ComboContext.Character->GetControlRotation().Yaw, 0.f)).GetUnitAxis(EAxis::Y) * InValue;
	
	if (InValue > 0.f)
	{
		AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveRight);
	}
	else
	{
		AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveLeft);
	}
}

void UP3ComboTableComponent::OnPressJumpButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::JumpDown);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::JumpUp);

	const bool bIsJumpInterrup = ComboContext.Character->bPressedJump && CurrentComboName != UP3ComboTableComponent::Name_RootCombo;
	if(bIsJumpInterrup)
	{
		ClearCombo();

		UP3PawnActionComponent* ActionComp = ComboContext.Character->GetActionComponent();
		if (ActionComp)
		{
			ActionComp->StopAction(ActionComp->GetActiveActionId(), FP3PawnActionStopRequestParams());
		}
	}
}

void UP3ComboTableComponent::OnReleaseJumpButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::JumpUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::JumpDown);
}

void UP3ComboTableComponent::OnStartSpecialAttackButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SpecialAttackDown);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SpecialAttackUp);
}

void UP3ComboTableComponent::OnStopSpecialAttackButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SpecialAttackUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::SpecialAttackDown);
}

void UP3ComboTableComponent::OnPressEvadeButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::EvadeDown);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::EvadeUp);
}

void UP3ComboTableComponent::OnReleaseEvadeButton()
{
	AddFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::EvadeUp);
	RemoveFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::EvadeDown);
}

void UP3ComboTableComponent::OnActionStatusChanged(int32 RequestId, EP3RequestedActionStatus Status)
{			
	if (Status == EP3RequestedActionStatus::Started)
	{	
		ComboContext.ReceivedActionId = RequestId;
		
		UP3PawnActionComponent* ActionComp = ComboContext.Character.IsValid() ? ComboContext.Character->GetActionComponent() : nullptr;
		if (ensure(ActionComp))
		{
			if (ComboContext.RequestedActionId != RequestId
				&& ActionComp->GetActiveActionType() != EPawnActionType::CombatCombo)
			{
				if (CurrentComboName != UP3ComboTableComponent::Name_RootCombo)
				{
					const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);
					if (ComboRow)
					{
						ExitCombo(*ComboRow);
					}

					ResetCombo();
				}
			}

			ComboContext.ActiveActionType = ActionComp->GetActiveActionType();
		}
	}
	else if (Status == EP3RequestedActionStatus::Finished || Status == EP3RequestedActionStatus::StartFailed )
	{	
		if (ComboContext.RequestedActionId == RequestId)
		{		
			ComboContext.RequestedActionId = 0;
		}

		ComboContext.ActiveActionType = EPawnActionType::Invalid;
	}
}

void UP3ComboTableComponent::OnMontageStarted(UAnimMontage* Montage)
{
	ComboContext.bIsMontageStarted = true;
}

void UP3ComboTableComponent::SetComboWeapon(const UDataTable* ComboDataTable, const UDataTable* ComboEdgeDataTable)
{
	static const FString ContextString(TEXT("UP3ComboTableComponent::SetComboWeapon"));

	if (!ensure(ComboDataTable) || !ensure(ComboEdgeDataTable))
	{
		return;
	}
	
	ComboTable.Reset();
	ComboEdgeTable.Reset();

	TArray<FP3ComboRow*> ComboTableRows;
	ComboDataTable->GetAllRows<FP3ComboRow>(ContextString, ComboTableRows);

	for (FP3ComboRow* ComboRow : ComboTableRows)
	{
		if (!ensure(ComboRow))
		{
			continue;
		}		
		
		ComboTable.Add(ComboRow->ComboName, *ComboRow);
	}
	
	TArray<FP3ComboEdgeRow*> EdgeTableRows;
	ComboEdgeDataTable->GetAllRows<FP3ComboEdgeRow>(ContextString, EdgeTableRows);
			
	for (FP3ComboEdgeRow* EdgeRow : EdgeTableRows)
	{	
		if (!ensure(EdgeRow))
		{
			continue;
		}

		ComboEdgeTable.Add(*EdgeRow);
	}

	ClearCombo();
}

void UP3ComboTableComponent::TickChangeWeapon()
{
	const EP3WeaponType NewWeaponType = ComboContext.Character.IsValid() ? ComboContext.Character->GetRightHandWeaponType() : EP3WeaponType::None;

	if (NewWeaponType != EP3WeaponType::None && NewWeaponType != WeaponType)
	{
		const FP3ComboDataTable* FindComboDataTable = ComboWeaponDataTable.Find(NewWeaponType);

		if (ensure(FindComboDataTable))
		{
			if (CurrentComboName != UP3ComboTableComponent::Name_RootCombo)
			{
				const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);
				if (ComboRow)
				{
					ExitCombo(*ComboRow);
				}
			}

			WeaponType = NewWeaponType;
			SetComboWeapon(FindComboDataTable->ComboDataTable, FindComboDataTable->ComboEdgeDataTable);			
		}
	}
}

bool UP3ComboTableComponent::TickStartedCondition(float DeltaTime, const FP3ComboEdgeRow& ComboEdgeRow)
{
	bool bCanStartCombo = true;

	ComboContext.ExecutionInputFlags = ComboEdgeRow.InputFlags | (1 << ComboEdgeRow.InputAllFlags);

	for (auto Itr = ConditionFunctionPointers.CreateConstIterator(); Itr; ++Itr)
	{
		bCanStartCombo = (*Itr)(ComboContext, ComboEdgeRow);
		if (!bCanStartCombo)
		{
			return bCanStartCombo;
		}
	}
		
	return bCanStartCombo;
}

bool UP3ComboTableComponent::TickInProgressCondition(float DeltaTime, const FP3ComboRow& ComboRow)
{
	bool bIsInProgressCombo = false;	

	TickMoveTowardsTarget();

	if (ComboRow.bInputPressHold)
	{
		bIsInProgressCombo = IsInputPressHoldCondition(ComboRow);

		if (!bIsInProgressCombo)
		{
			UP3PawnActionComponent* ActionComp = ComboContext.Character->GetActionComponent();
			if (ActionComp && ActionComp->IsActionInProgress(ComboContext.RequestedActionType))
			{
				if (ActionComp->GetActiveActionId() != 0)
				{
					ActionComp->StopAction(ActionComp->GetActiveActionId(), FP3PawnActionStopRequestParams());
				}
				else
				{
					bIsInProgressCombo = true;
				}
			}
		}
		
		return bIsInProgressCombo;
	}

	if (TickInterruptableCondition(DeltaTime, ComboRow))
	{
		return false;
	}

	bIsInProgressCombo = ComboContext.RequestedActionId != 0;
	
	return bIsInProgressCombo;
}

bool UP3ComboTableComponent::TickInterruptableCondition(float DeltaTime, const FP3ComboRow& ComboRow)
{	
	const static FName NAME_Move = TEXT("Move");

	const bool bIsMoveInterrup = !ComboContext.LocalControl_bIsAnimNotifyInputMoveBlock
		&& ComboContext.ActiveActionType == EPawnActionType::CombatCombo
		&& ComboContext.bIsMontageStarted
		&& ComboContext.NotifyStateSignal.FindRef(NAME_Move)
		&& (HasFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveForward)
			|| HasFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveBack)
			|| HasFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveRight)
			|| HasFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveLeft));
	
	if (bIsMoveInterrup)
	{
		UAnimInstance* AnimInstance = ComboContext.Character->GetMesh() ? ComboContext.Character->GetMesh()->GetAnimInstance() : nullptr;		
		if (AnimInstance)
		{
			const UAnimMontage* Montage = AnimInstance->GetCurrentActiveMontage();
			if (!Montage || AnimInstance->Montage_GetPosition(Montage) > 0.2f)
			{
				UP3PawnActionComponent* ActionComp = ComboContext.Character->GetActionComponent();
				if (ActionComp && ActionComp->IsActionInProgress(ComboContext.ActiveActionType))
				{
					ActionComp->StopAction(ActionComp->GetActiveActionId(), FP3PawnActionStopRequestParams());
					return true;	
				}
			}
		}
	}

	const bool bIsRootInterrup = ComboContext.NotifyStateSignal.FindRef(Name_RootCombo) == true;

	if (bIsRootInterrup)
	{
		for (const FP3ComboEdgeRow& ComboEdgeRow : ComboEdgeTable)
		{
			if (ComboEdgeRow.ComboName != UP3ComboTableComponent::Name_RootCombo)
			{
				continue;
			}

			if (ComboEdgeRow.NextComboName == CurrentComboName)
			{
				continue;
			}

			if (!TickStartedCondition(DeltaTime, ComboEdgeRow))
			{
				continue;
			}

			return true;
		}
	}

	return false;
}

void UP3ComboTableComponent::TickInputButtonPressTimeSeconds(float DeltaTime)
{
	for (int32 i = 0; i < (int32)EP3ComboTableInputFlags::Count; ++i)
	{
		if (ComboContext.InputButtonPressTimeSeconds.Num() <= i)
		{
			ensure(0);
			return;
		}

		if (HasFlags(ComboContext.ComboInputFlags,(EP3ComboTableInputFlags)i))
		{			
			ComboContext.InputButtonPressTimeSeconds[i] += DeltaTime;
		}
		else
		{
			ComboContext.InputButtonPressTimeSeconds[i] = 0.f;
		}
	}
}

void UP3ComboTableComponent::TickInputStack(float DeltaTime)
{
	if (ComboContext.InputFlagStack.Num() == 0)
	{
		return;
	}

	if (InputFlagStackTimeSecondsForPop > ComboContext.InputStackClearTimeSeconds)
	{
		ComboContext.InputFlagStack.RemoveAt(0, 1, false);
		InputFlagStackTimeSecondsForPop = 0.f;
	}

	InputFlagStackTimeSecondsForPop += DeltaTime;
}

void UP3ComboTableComponent::TickMoveTowardsTarget()
{	
	if (CVarP3ComboAutoMoveTowardsTarget.GetValueOnGameThread() == 0)
	{
		return;
	}

	if (!ComboContext.LocalControl_bIsAnimNotifyAutoMoveTowardsTarget)
	{
		return;
	}
	
	if (!ComboContext.Character.IsValid())
	{
		return;
	}

	FVector AutoMoveTowardsTargetDirection = FVector::ZeroVector;
	float AutoMoveTowardsTargetInputScale = CVarP3ComboAutoMoveTowardsTargetInputScale.GetValueOnGameThread();
	
	if (!ComboContext.LocalControl_bIsAnimNotifyInputMoveBlock
		&& (HasFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveForward)
		|| HasFlags(ComboContext.ComboInputFlags, EP3ComboTableInputFlags::MoveRight)))
	{
		AutoMoveTowardsTargetDirection = ComboContext.InputForwardDirection + ComboContext.InputRightDirection;
	}	
	else
	{
		if (!ComboContext.Target.IsValid())
		{
			return;
		}
		
		if (ComboContext.Character->IsOverlappingActor(ComboContext.Target.Get()))
		{
			AutoMoveTowardsTargetInputScale = 0.f;
		}
		else
		{
			float CapsuleDistance = 0.f;
			const UCapsuleComponent* CapsuleComp = ComboContext.Target->FindComponentByClass<UCapsuleComponent>();

			if (CapsuleComp)
			{
				CapsuleDistance += CapsuleComp->GetScaledCapsuleRadius();
			}

			if (ComboContext.Character->GetCapsuleComponent())
			{
				CapsuleDistance += ComboContext.Character->GetCapsuleComponent()->GetScaledCapsuleRadius() * 2.5f;
			}

			AutoMoveTowardsTargetDirection = ComboContext.Target->GetActorLocation() - ComboContext.Character->GetActorLocation();

			float Dist2D = AutoMoveTowardsTargetDirection.Size2D();
			Dist2D = CapsuleDistance < Dist2D ? Dist2D : 0.f;

			AutoMoveTowardsTargetInputScale = Dist2D / ComboContext.MoveTowardsTargetIntervalDistance * ComboContext.MoveTowardsTargetMultiplyInputScale;
		}
	}
		
	ComboContext.Character->AddMovementInput(AutoMoveTowardsTargetDirection.GetSafeNormal2D(), AutoMoveTowardsTargetInputScale, true);
}

void UP3ComboTableComponent::TickCommand()
{
	TArray<TSubclassOf<class UP3Command>> CommandClass;
	
	if (ComboContext.RequestedCommandParams.ChangeStance_NewStance != ComboContext.CommandParams.ChangeStance_NewStance)
	{
		CommandClass.Add(UP3ChangeStanceCommand::StaticClass());
	}

	if (ComboContext.RequestedCommandParams.SetMeleeAiming_bNewAiming != ComboContext.CommandParams.SetMeleeAiming_bNewAiming)
	{
		CommandClass.Add(UP3SetMeleeAimingCommand::StaticClass());
	}

	if (ComboContext.RequestedCommandParams.SetRangedAiming_bNewAiming != ComboContext.CommandParams.SetRangedAiming_bNewAiming)
	{
		CommandClass.Add(UP3SetRangedAimingCommand::StaticClass());
	}

	if (ComboContext.RequestedCommandParams.SetBouncing_bNewBouncingMode != ComboContext.CommandParams.SetBouncing_bNewBouncingMode)
	{
		CommandClass.Add(UP3SetBouncingModeCommand::StaticClass());
	}

	if (ComboContext.RequestedCommandParams.SetBlocking_bNewBlocking != ComboContext.CommandParams.SetBlocking_bNewBlocking)
	{
		CommandClass.Add(UP3SetBlockingCommand::StaticClass());
	}

	if (ComboContext.RequestedCommandParams.SetCrouchBlocking_bNewBlocking != ComboContext.CommandParams.SetCrouchBlocking_bNewBlocking)
	{
		CommandClass.Add(UP3SetCrouchBlockingCommand::StaticClass());
	}

	if (CommandClass.Num() <= 0)
	{
		return;
	}
	
	UP3CommandComponent* CommandComp = ComboContext.Character.IsValid() ? ComboContext.Character->GetCommandComponent() : nullptr;
	if (!ensure(CommandComp))
	{
		return;
	}

	for (const TSubclassOf<class UP3Command>& Class : CommandClass)
	{
		CommandComp->RequestCommand(Class, ComboContext.CommandParams);
	}	

	ComboContext.RequestedCommandParams = ComboContext.CommandParams;
}

void UP3ComboTableComponent::TickCamera()
{
	if (!ComboCameraTable)
	{
		return;
	}

	ComboContext.SocketOffset = FVector::ZeroVector;
	ComboContext.TargetArmLengthRatio = 1.f;
	ComboContext.FieldOfViewRatio = 1.f;	

	ComboContext.SocketOffsetInterpSpeedRatio = 1.f;
	ComboContext.TargetArmLengthInterpSpeedRatio = 1.f;
	ComboContext.FieldOfViewInterpSpeedRatio = 1.f;

	ComboContext.CameraFollowSpeed = 0.f;

	if (CurrentComboName != Name_RootCombo)
	{
		const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);
		if (ComboRow)
		{
			ComboContext.SocketOffset = ComboRow->SocketOffset;
			ComboContext.TargetArmLengthRatio = ComboRow->TargetArmLengthRatio;
			ComboContext.FieldOfViewRatio = ComboRow->FieldOfViewRatio;
			ComboContext.CameraFollowSpeed = ComboRow->CameraFollowSpeed;

			if (ComboRow->SocketOffsetInterpSpeedRatioCurve)
			{
				ComboContext.SocketOffsetInterpSpeedRatio = ComboRow->SocketOffsetInterpSpeedRatioCurve->GetFloatValue(CurrentComboProgressTimeSeconds);
			}

			if (ComboRow->TargetArmLengthInterpSpeedRatioCurve)
			{
				ComboContext.TargetArmLengthInterpSpeedRatio = ComboRow->TargetArmLengthInterpSpeedRatioCurve->GetFloatValue(CurrentComboProgressTimeSeconds);
			}

			if (ComboRow->FieldOfViewInterpSpeedRatioCurve)
			{
				ComboContext.FieldOfViewInterpSpeedRatio = ComboRow->FieldOfViewInterpSpeedRatioCurve->GetFloatValue(CurrentComboProgressTimeSeconds);
			}						
		}
	}	

	static const FString ContextString(TEXT("UP3ComboTableComponent::TickCamera"));

	TArray<FP3ComboCameraTable*> ComboCameraRows;
	ComboCameraTable->GetAllRows<FP3ComboCameraTable>(ContextString, ComboCameraRows);

	for (FP3ComboCameraTable* ComboCameraRow : ComboCameraRows)
	{
		if (!ensure(ComboCameraRow))
		{
			continue;
		}

		if (ComboCameraRow->WeaponType != WeaponType
			|| ComboCameraRow->CharacterStance != ComboContext.Stance)
		{
			continue;
		}

		ComboContext.SocketOffset += ComboCameraRow->SocketOffset;
		ComboContext.TargetArmLengthRatio *= ComboCameraRow->TargetArmLengthRatio;
		ComboContext.FieldOfViewRatio *= ComboCameraRow->FieldOfViewRatio;		
		break;
	}
}

void UP3ComboTableComponent::StartCombo(const FP3ComboRow& ComboRow)
{	
	const bool bIsStarted = true;
	
	CurrentComboName = ComboRow.ComboName;

	for (auto Itr = ExecutionFunctionPointers.CreateConstIterator(); Itr; ++Itr)
	{
		(*Itr)(ComboContext, ComboRow, bIsStarted);
	}	

	OnComboStarted.Broadcast(ComboRow);

	ComboJsonLog(Display, "start combo");
}

void UP3ComboTableComponent::ExitCombo(const FP3ComboRow& ComboRow)
{
	const bool bIsStarted = false;
	
	for (auto Itr = ExecutionFunctionPointers.CreateConstIterator(); Itr; ++Itr)
	{
		(*Itr)(ComboContext, ComboRow, bIsStarted);
	}

	ComboJsonLog(Display, "exit combo");
}

void UP3ComboTableComponent::ProgressCombo(const FP3ComboRow& ComboRow, float DeltaTime)
{	
	if (ComboRow.bStartAimShake && ComboRow.AimShakeCurve)
	{
		AimOffset = FMath::RandPointInCircle(ComboRow.AimShakeCurve->GetFloatValue(CurrentComboProgressTimeSeconds));
	}

	CurrentComboProgressTimeSeconds += DeltaTime;
}

void UP3ComboTableComponent::ResetCombo()
{
	for (int32 i = 0; i < (int32)EP3ComboTableInputFlags::Count; ++i)
	{
		if (ComboContext.InputButtonPressTimeSeconds.Num() <= i)
		{
			ensure(0);
			break;
		}

		ComboContext.InputButtonPressTimeSeconds[i] = 0.f;	
	}

	ComboContext.InputFlagStack.Reset();
	InputFlagStackTimeSecondsForPop = 0.f;
	ComboContext.InputStackClearTimeSeconds = CVarP3ComboInputStackClearTimeSeconds.GetValueOnGameThread();
		
	ComboContext.LocalControl_bIsAnimNotifyInputMoveBlock = false;
	ComboContext.LocalControl_bIsAnimNotifyInputTurnBlock = false;
	ComboContext.LocalControl_bIsAnimNotifyInputCameraMoveBlock = false;
	ComboContext.LocalControl_bIsAnimNotifyInputButtonStack = false;

	ComboContext.bIsDamageReceived = false;
	ComboContext.DamageReceivedComboName = NAME_None,

	ComboContext.ConsumeStaminaPerSecond = 0.f;
	ComboContext.SpeedMultiplier = 1.f;
	ComboContext.RotationYawMultiplier = 1.f;

	ComboContext.SocketOffset = FVector::ZeroVector;
	ComboContext.TargetArmLengthRatio = 1.f;
	ComboContext.FieldOfViewRatio = 1.f;

	ComboContext.SocketOffsetInterpSpeedRatio = 1.f;
	ComboContext.TargetArmLengthInterpSpeedRatio = 1.f;
	ComboContext.FieldOfViewInterpSpeedRatio = 1.f;

	ComboContext.RestoreViewPitchMin = 0.f;
	ComboContext.RestoreViewPitchMax = 0.f;
	ComboContext.RestoreViewYawMin = 0.f;
	ComboContext.RestoreViewYawMax = 0.f;

	ComboContext.bIsMontageStarted = false;

	CurrentComboProgressTimeSeconds = 0.f;	

	CurrentComboName = UP3ComboTableComponent::Name_RootCombo;
	AimOffset = FVector2D::ZeroVector;
}

void UP3ComboTableComponent::ClearCombo(bool bInputClear)
{
	if (CurrentComboName != UP3ComboTableComponent::Name_RootCombo)
	{
		const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);
		if (ComboRow)
		{
			ExitCombo(*ComboRow);
		};
	}

	ResetCombo();
	ComboContext.RequestedActionType = EPawnActionType::Invalid;

	if (bInputClear)
	{
		ComboContext.ComboInputFlags = 0;
	}	
}

bool UP3ComboTableComponent::IsInputPressHoldCondition(const FP3ComboRow& ComboRow) const
{	
	bool bConditionResult = false;
	
	if (ComboRow.InputPressHoldAllFlags != 0)
	{
		bConditionResult = HasFlags(ComboContext.ComboInputFlags, ComboRow.InputPressHoldAllFlags);
		
		if(!bConditionResult)
		{
			return bConditionResult;
		}
	}

	if (ComboRow.InputPressHoldAnyFlags != 0)
	{
		bConditionResult = ComboContext.ComboInputFlags == 0 || HasFlags(ComboContext.ComboInputFlags, ComboRow.InputPressHoldAnyFlags) || bConditionResult;
	}

	bConditionResult = !ComboContext.bIsExhausted  && ComboContext.bIsMovingOnGround && bConditionResult;
		
	return bConditionResult;
}

FString UP3ComboTableComponent::GetInputFlagsString(const FP3ComboEdgeRow& ComboEdgeRow)
{
	FString InputFlagsString;

	for (int32 i = 0; i < (int32)EP3ComboTableInputFlags::Count; ++i)
	{
		if (HasFlags(ComboEdgeRow.InputFlags, (EP3ComboTableInputFlags)i))
		{			
			FString HasInputFlagString = GetInputFlagToString((EP3ComboTableInputFlags)i);
			if (!InputFlagsString.IsEmpty() && !HasInputFlagString.IsEmpty())
			{
				InputFlagsString += TEXT(" Or ");
			}

			InputFlagsString += HasInputFlagString;
		}

		if (HasFlags(ComboEdgeRow.InputAllFlags, (EP3ComboTableInputFlags)i))
		{						
			FString HasInputFlagString = GetInputFlagToString((EP3ComboTableInputFlags)i);
			if (!InputFlagsString.IsEmpty() && !HasInputFlagString.IsEmpty())
			{
				InputFlagsString += TEXT(" And ");
			}

			InputFlagsString += HasInputFlagString;
		}
	}

	FString InputDirectionTypeString;
	FString CameraInputDirectionTypeString;

	if (ComboEdgeRow.CheckInputDirection)
	{
		InputDirectionTypeString = GetInputDirectionTypeToString(ComboEdgeRow.InputDirectionType);
	}

	if (ComboEdgeRow.CheckCameraInputDirection)
	{
		CameraInputDirectionTypeString = GetInputDirectionTypeToString(ComboEdgeRow.CameraInputDirectionType);
	}

	if (!InputDirectionTypeString.IsEmpty())
	{
		InputFlagsString += TEXT(" And ") + InputDirectionTypeString;
	}

	if (!CameraInputDirectionTypeString.IsEmpty())
	{
		InputFlagsString += TEXT(" And ") + CameraInputDirectionTypeString;
	}		

	return InputFlagsString;
}

FString UP3ComboTableComponent::GetInputFlagToString(EP3ComboTableInputFlags InputFlags)
{
	FString InputFlagsString;

	switch (InputFlags)
	{
		case EP3ComboTableInputFlags::NormalAttackDown:
		{
			InputFlagsString = TEXT("MouseLeft");
			break;
		}
		case EP3ComboTableInputFlags::PrivateActionDown:
		{
			InputFlagsString =TEXT("MouseRight");
			break;
		}
		case EP3ComboTableInputFlags::SpecialAttackDown:
		{
			InputFlagsString = TEXT("F");
			break;
		}
		case EP3ComboTableInputFlags::SprintDown:
		{
			InputFlagsString = TEXT("Shift");
			break;
		}
		case EP3ComboTableInputFlags::MoveForward:
		{
			InputFlagsString = TEXT("W");
			break;
		}
		case EP3ComboTableInputFlags::MoveBack:
		{
			InputFlagsString =TEXT("S");
			break;
		}
		case EP3ComboTableInputFlags::MoveRight:
		{
			InputFlagsString = TEXT("D");
			break;
		}
		case EP3ComboTableInputFlags::MoveLeft:
		{
			InputFlagsString = TEXT("A");
			break;
		}
		case EP3ComboTableInputFlags::JumpDown:
		{
			InputFlagsString = TEXT("Space");
			break;
		}
		case EP3ComboTableInputFlags::EvadeDown:
		{
			InputFlagsString = TEXT("Ctrl");
			break;
		}
	}

	return InputFlagsString;
}

FString UP3ComboTableComponent::GetInputDirectionTypeToString(EP3ComboTableInputDirectionType InputDirectionType)
{
	FString InputFlagsString;

	switch (InputDirectionType)
	{
		case EP3ComboTableInputDirectionType::Forward:
		{
			InputFlagsString = TEXT("Forward");
			break;
		}
		case EP3ComboTableInputDirectionType:: ForwardRight:
		{
			InputFlagsString = TEXT("ForwardRight");
			break;
		}
		case EP3ComboTableInputDirectionType::Right:
		{
			InputFlagsString = TEXT("Right");
			break;
		}
		case EP3ComboTableInputDirectionType::BackwardRight:
		{
			InputFlagsString = TEXT("BackwardRight");
			break;
		}
		case EP3ComboTableInputDirectionType::Backward:
		{
			InputFlagsString = TEXT("Backward");
			break;
		}
		case EP3ComboTableInputDirectionType::BackwardLeft:
		{
			InputFlagsString = TEXT("BackwardLeft");
			break;
		}
		case EP3ComboTableInputDirectionType::Left:
		{
			InputFlagsString = TEXT("Left");
			break;
		}
		case EP3ComboTableInputDirectionType::ForwardLeft:
		{
			InputFlagsString = TEXT("ForwardLeft");
			break;
		}
	}

	return InputFlagsString;
}

void UP3ComboTableComponent::SetNotifyStateSignal(const FName& SignalName, bool bIsEnabled)
{
	ComboContext.NotifyStateSignal.FindOrAdd(SignalName) = bIsEnabled;
}

bool UP3ComboTableComponent::CanCombo() const
{
	return ComboContext.bCanCombat && ComboContext.Stance == EP3CharacterStance::Combat && !ComboContext.bIsMounted;
}

bool UP3ComboTableComponent::CanMove() const
{
	return !ComboContext.LocalControl_bIsAnimNotifyInputMoveBlock;
}

bool UP3ComboTableComponent::CanTurn() const
{
	return !ComboContext.LocalControl_bIsAnimNotifyInputTurnBlock;
}

bool UP3ComboTableComponent::CanJump() const
{
	const static FName NAME_Jump = TEXT("Jump");
	const bool bCanJumpRangedAiming = !IsElementalistWeapon(WeaponType) && ComboContext.bIsRangedAiming;

	return CurrentComboName == Name_RootCombo
		|| ComboContext.bIsBlockingMode
		|| ComboContext.bIsCrouchBlockingMode
		|| ComboContext.bIsMeleeAiming
		|| bCanJumpRangedAiming
		|| ComboContext.NotifyStateSignal.FindRef(NAME_Jump);
}

bool UP3ComboTableComponent::CanCameraMove() const
{
	return !ComboContext.LocalControl_bIsAnimNotifyInputCameraMoveBlock;
}

bool UP3ComboTableComponent::CanStartedCondition(const FP3ComboEdgeRow& ComboEdgeRow)
{
	bool bCanStartCombo = true;

	for (auto Itr = ConditionStartedFunctionPointers.CreateConstIterator(); Itr; ++Itr)
	{
		bCanStartCombo = (*Itr)(ComboContext, ComboEdgeRow);
		if (!bCanStartCombo)
		{
			return bCanStartCombo;
		}
	}

	return bCanStartCombo;
}

FRotator UP3ComboTableComponent::GetControlRotation() const
{
	const FVector ControlNormalDirection = (ComboContext.InputForwardDirection + ComboContext.InputRightDirection).GetSafeNormal();
	if (ControlNormalDirection == FVector::ZeroVector)
	{
		return GetOwner()->GetActorRotation();
	}

	return ControlNormalDirection.Rotation();
}

void UP3ComboTableComponent::LocalControl_SetCrossHairPosition(UWidget* Widget)
{
	if (!ensure(Widget))
	{
		return;
	}

	if (!ensure(IsLocalControlledActor(GetOwner())))
	{
		return;
	}

	if (!ensure(ComboContext.Character.IsValid()) || !ComboContext.bIsRangedAiming)
	{
		return;
	}

	Widget->SetRenderTranslation(AimOffset);

	FVector TraceStart;
	FVector TraceDirection;
	FVector2D ViewportPosition;

	const FGeometry& Geometry = Widget->GetCachedGeometry();
	const FVector2D& LocalSize = Geometry.GetLocalSize();
	const FVector2D LocalCoordinate(LocalSize.X * 0.5f, LocalSize.Y * 0.5f);
	const FVector2D AbsoluteCoordinate = Geometry.LocalToAbsolute(LocalCoordinate);

	USlateBlueprintLibrary::AbsoluteToViewport(GetWorld(), AbsoluteCoordinate, LocalControl_CrossHairPosition, ViewportPosition);
}

FString UP3ComboTableComponent::GetNextComboInputString()
{
	FString ComboNextInputString;

	for (const FP3ComboEdgeRow& ComboEdgeRow : ComboEdgeTable)
	{
		if (ComboEdgeRow.ComboName != CurrentComboName)
		{
			continue;
		}

		if (!CanStartedCondition(ComboEdgeRow))
		{
			continue;
		}

		FString ComboInputString = GetInputFlagsString(ComboEdgeRow);
		if (!ComboInputString.IsEmpty())
		{
			ComboNextInputString += ComboInputString + FString::Printf(TEXT(" --> %s\n"), *ComboEdgeRow.NextComboName.ToString());			
		}
	}

	return ComboNextInputString;
}

FVector UP3ComboTableComponent::GetLaunchLocation() const
{
	if (!ensure(ComboContext.Character.IsValid()))
	{
		return FVector::ZeroVector;
	}

	FVector LaunchLocation = ComboContext.Character->GetActorLocation();
	const AP3Weapon* WeaponActor = Cast<AP3Weapon>(ComboContext.Character->GetRightHandWeaponActor());

	if (ensure(WeaponActor))
	{
		LaunchLocation = WeaponActor->GetActorLocation();
		ensure(P3GetMuzzleLocation(*WeaponActor, LaunchLocation));
	}

	return LaunchLocation;
}

FRotator UP3ComboTableComponent::GetAimRotation(const FVector& LauncherLocation) const
{
	const APlayerController* Controller = ComboContext.Character.IsValid() ? Cast<APlayerController>(ComboContext.Character->GetController()) : nullptr;
	if (!ensure(Controller))
	{
		return FRotator::ZeroRotator;
	}

	if (!ComboContext.bIsRangedAiming)
	{
		return GetAimRotation();
	}

	FVector WorldLocation = FVector::ZeroVector;
	FVector WorldDirection = FVector::ZeroVector;
	FRotator LocalControl_AimRotation = ComboContext.Character->GetActorRotation();

	if (Controller->DeprojectScreenPositionToWorld(LocalControl_CrossHairPosition.X + AimOffset.X, LocalControl_CrossHairPosition.Y + AimOffset.Y, WorldLocation, WorldDirection))
	{
		float TraceDistance = 10000.0f;

		FHitResult HitResult;
		FCollisionQueryParams CollisionQueryParams;
		CollisionQueryParams.AddIgnoredActor(ComboContext.Character.Get());
		CollisionQueryParams.AddIgnoredActor(ComboContext.Character->GetRightHandWeaponActor());

		FVector TraceEnd = WorldLocation + WorldDirection * TraceDistance;

		if (GetWorld()->LineTraceSingleByChannel(HitResult, WorldLocation, TraceEnd, ECC_PROJECTILE, CollisionQueryParams))
		{
			if (HitResult.Actor.IsValid())
			{
				const bool bIsFront = (ComboContext.Character->GetActorForwardVector() | ((ComboContext.Character->GetActorLocation() - HitResult.Actor->GetActorLocation()).GetSafeNormal2D())) <= 0.f;
				if (bIsFront)
				{
					TraceDistance = HitResult.Distance;
				}
			}
		}

		WorldLocation = WorldLocation + WorldDirection * TraceDistance;
			   
		LocalControl_AimRotation = (WorldLocation - LauncherLocation).Rotation();

		if (CVarP3CombatDebug.GetValueOnGameThread() != 0)
		{
			DrawDebugSphere(GetWorld(), WorldLocation, 50.0f, 16, FColor::Red, true, 3.0f);
			DrawDebugSphere(GetWorld(), LauncherLocation, 50.0f, 16, FColor::Green, true, 3.0f);
		}
	}

	return LocalControl_AimRotation;
}

FRotator UP3ComboTableComponent::GetAimRotation() const
{
	if (!ComboContext.Character.IsValid())
	{
		return FRotator::ZeroRotator;
	}

	FRotator LocalControl_AimRotation = ComboContext.Character->GetActorRotation();
	
	LocalControl_AimRotation.Pitch += AimOffset.X; 
	LocalControl_AimRotation.Yaw += AimOffset.Y;

	return LocalControl_AimRotation;
}

FRotator UP3ComboTableComponent::GetAimingStartRotation() const
{
	return ComboContext.AimingStartRotation;
}

FVector UP3ComboTableComponent::GetDeprojectWorldLocation() const
{
	const APlayerController* Controller = ComboContext.Character.IsValid() ? Cast<APlayerController>(ComboContext.Character->GetController()) : nullptr;
	if (!ensure(Controller))
	{
		return FVector::ZeroVector;
	}

	FVector WorldLocation = FVector::ZeroVector;
	FVector WorldDirection = FVector::ZeroVector;	

	if (Controller->DeprojectScreenPositionToWorld(LocalControl_CrossHairPosition.X + AimOffset.X, LocalControl_CrossHairPosition.Y + AimOffset.Y, WorldLocation, WorldDirection))
	{
		float TraceDistance = 10000.0f;

		FHitResult HitResult;
		FCollisionQueryParams CollisionQueryParams;
		CollisionQueryParams.AddIgnoredActor(ComboContext.Character.Get());
		CollisionQueryParams.AddIgnoredActor(ComboContext.Character->GetRightHandWeaponActor());

		FVector TraceEnd = WorldLocation + WorldDirection * TraceDistance;

		if (GetWorld()->LineTraceSingleByChannel(HitResult, WorldLocation, TraceEnd, ECC_WorldDynamic, CollisionQueryParams))
		{
			TraceDistance = HitResult.Distance;
		}

		WorldLocation = WorldLocation + WorldDirection * TraceDistance;
	}

	return WorldLocation;
}

float UP3ComboTableComponent::GetMoveSpeedMultiplier() const
{	
	if (ComboContext.Stance == EP3CharacterStance::Combat)
	{
		switch (WeaponType)
		{
		case EP3WeaponType::GreatSword:
		{
			return ComboContext.SpeedMultiplier * 0.6f;
		}
		break;
		}
	}

	return ComboContext.SpeedMultiplier;
}

float UP3ComboTableComponent::GetRotationYawRateMultiplier() const
{
	return ComboContext.RotationYawMultiplier;
}

void UP3ComboTableComponent::OnAnimNotify(const UAnimNotify& AnimNotify)
{
	if (AnimNotify.IsA(UAnimNotify_LaunchProjectile::StaticClass()))
	{
	}
}

void UP3ComboTableComponent::OnReceiveDamage(AP3Character* ReceiveDamageTarget)
{	
	ComboContext.bIsDamageReceived = true;
	ComboContext.DamageReceivedComboName = CurrentComboName;
	ComboContext.DamageReceivedTarget = ReceiveDamageTarget;
}

void UP3ComboTableComponent::OnGiveDamage(AP3Character* GiveDamageTarget)
{
	ComboContext.DamageGivenTarget = GiveDamageTarget;
}

void UP3ComboTableComponent::OnRevive()
{
	ClearCombo();
}

void UP3ComboTableComponent::OnDownedChanged()
{
	ClearCombo();
}

void UP3ComboTableComponent::OnDead()
{
	ClearCombo();
}

UAnimMontage* UP3ComboTableComponent::GetAnimByAction(EP3ActionAnimationType DesireAnimationType) const
{
	UP3ComboActionMontageData* const* FindComboActionMontages = ComboActionMontages.Find(WeaponType);
	if (FindComboActionMontages && *FindComboActionMontages)
	{
		UAnimMontage* const* FindAnimation = (*FindComboActionMontages)->ActionAnimations.Find(DesireAnimationType);
		if (ensure(FindAnimation))
		{
			return *FindAnimation;
		}
	}

	ensure(0);
	return nullptr;
}

UAnimMontage* UP3ComboTableComponent::GetComboAnimationByTableName(const FName& AnimationName) const
{
	UAnimMontage* FindComboMontage = nullptr;

	const UP3ComboMontageData* ComboMontageData = ComboMontages.FindRef(WeaponType);
	if (ComboMontageData)
	{
		FindComboMontage = ComboMontageData->ComboAnimations.FindRef(AnimationName);
	}	

	ensure(FindComboMontage);
	return FindComboMontage;
}

UAnimMontage* UP3ComboTableComponent::GetComboWeaponAnimationByTableName(const FName& AnimationName) const
{
	UAnimMontage* FindComboMontage = nullptr;

	const UP3ComboWeaponMontageData* ComboWeaponMontageData = ComboWeaponMontages.FindRef(WeaponType);
	if (ComboWeaponMontageData)
	{
		FindComboMontage = ComboWeaponMontageData->WeaponAnimations.FindRef(AnimationName);
	}

	ensure(FindComboMontage);
	return FindComboMontage;
}

int32 UP3ComboTableComponent::GetAimOffsetAnimationIndex() const
{
	if (!ComboContext.bIsRangedAiming || CurrentComboName == Name_RootCombo)
	{
		return 0;
	}

	const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);
	if (!ComboRow)
	{
		return 0;
	}

	return ComboRow->SelectedAimOffsetAnimationIndex;
}

int32 UP3ComboTableComponent::GetCombatRunBlendSpeaceIndex() const 
{
	if (ComboContext.Stance != EP3CharacterStance::Combat || CurrentComboName == Name_RootCombo)
	{
		return 0;
	}

	const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);
	if (!ComboRow)
	{
		return 0;
	}

	return ComboRow->SelectedCombatRunBlendSpeaceIndex;
}

const FVector2D UP3ComboTableComponent::GetAimOffset(float Scale) const
{
	return AimOffset * Scale;
}

const FP3ComboRow* UP3ComboTableComponent::GetComboRow(const FName& ComboName) const
{
	return ComboName == NAME_None ? ComboTable.Find(CurrentComboName) : ComboTable.Find(ComboName);
}

const bool UP3ComboTableComponent::IsInProgressRootCombo() const
{
	return CurrentComboName == Name_RootCombo;
}

const bool UP3ComboTableComponent::IsStaminaRegenAllowed() const
{
	const FP3ComboRow* ComboRow = GetComboRow(CurrentComboName);
	if (ComboRow)
	{
		return ComboRow->ConsumeStamina <= 0.f;
	}

	return true;
}

void UP3ComboTableComponent::AddFlags(int32& InOutFlags, EP3ComboTableInputFlags AddFlags)
{
	InOutFlags |= (1 << (int32)AddFlags);

	ComboContext.InputFlagStack.Push(AddFlags);
	
	if (ComboContext.InputFlagStack.Num() >= FP3ComboTableContext::MaxInputFlagStack)
	{
		ComboContext.InputFlagStack.RemoveAt(0, 1, false);
	}	
}

void UP3ComboTableComponent::RemoveFlags(int32& InOutFlags, EP3ComboTableInputFlags RemoveFlags)
{
	InOutFlags &= ~((1 << (int32)RemoveFlags));
}

bool UP3ComboTableComponent::HasFlags(int32 InFlags, int32 HasFlags)
{
	return (InFlags & HasFlags) > 0;
}

bool UP3ComboTableComponent::HasFlags(int32 InFlags, EP3ComboTableInputFlags HasFlags)
{
	return (InFlags & (1 << (int32)HasFlags)) > 0;
}

bool UP3ComboTableComponent::HasAllFlags(int32 InFlags, int32 HasAllFlags)
{
	if (HasAllFlags == 0)
	{
		return true;
	}

	for (int32 i = 0; i < (int32)EP3ComboTableInputFlags::Count; ++i)
	{
		if (HasFlags(InFlags, (EP3ComboTableInputFlags)i))
		{
			if (!HasFlags(InFlags, HasAllFlags))
			{
				return false;
			}
		}
	}

	return true;
}

FRotator UP3ComboTableComponent::GetComboStartRotation(const FP3ComboTableContext& ComboContext, EP3ComboTableStartRotationType ComboStartRotationType)
{
	FRotator Rotator = FRotator::ZeroRotator;

	switch (ComboStartRotationType)
	{
	case EP3ComboTableStartRotationType::CameraForward:
	{
		const APlayerController* Controller = ComboContext.Character.IsValid() ? Cast<APlayerController>(ComboContext.Character->GetController()) : nullptr;
		if (Controller && Controller->PlayerCameraManager)
		{
			Rotator.Yaw = FRotator::NormalizeAxis(Controller->PlayerCameraManager->GetCameraRotation().Yaw);
		}
		break;
	}
	case EP3ComboTableStartRotationType::ControlForward:
	{
		Rotator = ((ComboContext.InputForwardDirection + ComboContext.InputRightDirection).GetSafeNormal()).Rotation();
		break;
	}
	case EP3ComboTableStartRotationType::TargetDirection:
	{
		if (ComboContext.Target.IsValid())
		{
			Rotator = ((ComboContext.Target->GetActorLocation() - ComboContext.Character->GetActorLocation()).GetSafeNormal()).Rotation();
		}
		break;
	}
	}

	return Rotator;
}
EP3ComboTableInputDirectionType UP3ComboTableComponent::GetInputDirectionType(const FP3ComboTableContext& ComboContext, const FVector& ForwardVector, const FVector& RightVector)
{
	const static EP3ComboTableInputDirectionType InputDirectionType[] = {
		EP3ComboTableInputDirectionType::Forward,
		EP3ComboTableInputDirectionType::ForwardRight,
		EP3ComboTableInputDirectionType::Right,
		EP3ComboTableInputDirectionType::BackwardRight,
		EP3ComboTableInputDirectionType::Backward,
		EP3ComboTableInputDirectionType::BackwardLeft,
		EP3ComboTableInputDirectionType::Left,
		EP3ComboTableInputDirectionType::ForwardLeft,
		EP3ComboTableInputDirectionType::Forward,
	};

	FVector InputDirection = ComboContext.InputForwardDirection + ComboContext.InputRightDirection;
	InputDirection.Normalize();

	if (InputDirection.IsZero())
	{
		return EP3ComboTableInputDirectionType::None;
	}

	float InputDirectionToDegrees180 = FMath::RadiansToDegrees(FMath::Acos(FVector::DotProduct(ForwardVector.GetSafeNormal2D(), InputDirection)));
	InputDirectionToDegrees180 *= FVector::DotProduct(RightVector.GetSafeNormal2D(), InputDirection) < 0.f ? -1.f : 1.f;

	int32 InputDirectionToIndex = FMath::FloorToInt((FRotator::ClampAxis(InputDirectionToDegrees180) + 22.5f) / 45.f);
	check(InputDirectionToIndex >= 0 && InputDirectionToIndex <= (int32)EP3ComboTableInputDirectionType::Count);

	return InputDirectionType[InputDirectionToIndex];
}

bool UP3ComboTableComponent::Condition_InputFlags(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{	
	if (!ComboEdgeRow.CheckInput && !ComboEdgeRow.CheckInputStack)
	{
		return true;
	}

	bool bConditionResult = false;

	const bool bCanInputStackStart = ComboEdgeRow.CheckInputStack
		&& ComboEdgeRow.InputStack.Num() > 0 && ComboEdgeRow.InputStack.Num() <= ComboContext.InputFlagStack.Num();

	const bool bCanInputStackStartStatus = ComboContext.LocalControl_bIsAnimNotifyInputButtonStack
		|| ComboEdgeRow.ComboName == UP3ComboTableComponent::Name_RootCombo
		|| ComboContext.bIsBlockingMode
		|| ComboContext.bIsCrouchBlockingMode
		|| ComboContext.bIsMeleeAiming
		|| ComboContext.bIsRangedAiming;

	if (bCanInputStackStart && bCanInputStackStartStatus)
	{
		int32 EdgeInputStackIndex = 0;

		if (ComboEdgeRow.bIsInputStackSequence)
		{
			for (const EP3ComboTableInputFlags& Itr : ComboContext.InputFlagStack)
			{
				if (!ComboEdgeRow.InputStack.IsValidIndex(EdgeInputStackIndex))
				{
					break;
				}

				if (ComboEdgeRow.InputStack[EdgeInputStackIndex] == Itr)
				{
					EdgeInputStackIndex++;
				}
				else
				{
					EdgeInputStackIndex = 0;
				}
			}
		}
		else
		{
			for (const EP3ComboTableInputFlags& Itr : ComboEdgeRow.InputStack)
			{
				if (ComboContext.InputFlagStack.Contains(Itr))
				{
					EdgeInputStackIndex++;
				}
			}
		}

		bConditionResult = EdgeInputStackIndex >= ComboEdgeRow.InputStack.Num();
	}

	if (ComboEdgeRow.CheckInput)
	{
		return HasFlags(ComboContext.ComboInputFlags, ComboEdgeRow.InputFlags) && HasAllFlags(ComboContext.ComboInputFlags, ComboEdgeRow.InputAllFlags) || bConditionResult;
	}

	return bConditionResult;
}

bool UP3ComboTableComponent::Condition_InputButtonPressTimeSeconds(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	if (!ComboEdgeRow.CheckInputPressTime)
	{
		return true;
	}

	for (int32 i = 0; i < (int32)EP3ComboTableInputFlags::Count; ++i)
	{
		if (ComboContext.InputButtonPressTimeSeconds.Num() <= i)
		{
			ensure(0);
			return false;
		}

		if (!HasFlags(ComboEdgeRow.InputPressTimeFlags, (EP3ComboTableInputFlags)i))
		{
			continue;
		}
		
		if (ComboEdgeRow.InputPressTimeSeconds.X - ComboEdgeRow.InputPressTimeSeconds.Y == 0.f
			&& ComboEdgeRow.InputPressTimeSeconds.X <= ComboContext.InputButtonPressTimeSeconds[i])
		{
			return true;
		}

		if(ComboEdgeRow.InputPressTimeSeconds.X <= ComboContext.InputButtonPressTimeSeconds[i] 
			&& ComboEdgeRow.InputPressTimeSeconds.Y >= ComboContext.InputButtonPressTimeSeconds[i])
		{
			return true;
		}			
	}

	return false;
}

bool UP3ComboTableComponent::Condition_InputDirectionType(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	if (ComboEdgeRow.CheckInputDirection)
	{
		return GetInputDirectionType(ComboContext, ComboContext.Character->GetActorForwardVector(), ComboContext.Character->GetActorRightVector()) == ComboEdgeRow.InputDirectionType;
	}

	if (ComboEdgeRow.CheckCameraInputDirection)
	{
		AController* Controller = ComboContext.Character->GetController();
		if (Controller)
		{
			const FRotator ControlRotation = Controller->GetControlRotation();
			const FVector CameraForwardVector = ControlRotation.RotateVector(FVector(1.f, 0.f, 0.f));
			const FVector CameraRightVector = ControlRotation.RotateVector(FVector(0.f, 1.f, 0.f));

			return GetInputDirectionType(ComboContext, CameraForwardVector, CameraRightVector) == ComboEdgeRow.CameraInputDirectionType;
		}
	}
	
	return true;
}

bool UP3ComboTableComponent::Condition_Notify(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	bool bConditionResult = true;

	if (ComboEdgeRow.CheckAnimNotifyStateSignal)
	{
		bConditionResult = ComboContext.NotifyStateSignal.FindRef(ComboEdgeRow.AnimNotifyStateSignalName) == true;
	}
	
	return bConditionResult;
}

bool UP3ComboTableComponent::Condition_Status(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	bool bConditionResult = true;

	if (ComboEdgeRow.CheckCharacterStance)
	{
		bConditionResult = ComboContext.Stance == ComboEdgeRow.CharacterStance;
	}

	if (ComboEdgeRow.CheckBlockingMode)
	{
		bConditionResult = ComboContext.bIsBlockingMode == ComboEdgeRow.bIsBlockingMode && bConditionResult;
	}

	if (ComboEdgeRow.CheckCrouchBlockingMode)
	{
		bConditionResult = ComboContext.bIsBlockingMode == ComboEdgeRow.bIsCrouchBlockingMode && bConditionResult;
	}

	if (ComboEdgeRow.CheckBouncingMode)
	{
		bConditionResult = ComboContext.bIsBouncingMode == ComboEdgeRow.bIsBouncingMode && bConditionResult;
	}

	if (ComboEdgeRow.CheckMeleeAiming)
	{
		bConditionResult = ComboContext.bIsMeleeAiming == ComboEdgeRow.bIsMeleeAiming && bConditionResult;
	}

	if (ComboEdgeRow.CheckRangedAiming)
	{
		bConditionResult = ComboContext.bIsRangedAiming == ComboEdgeRow.bIsRangedAiming && bConditionResult;
	}

	if (ComboEdgeRow.CheckExhausted)
	{
		bConditionResult = ComboContext.bIsExhausted == ComboEdgeRow.bIsExhausted && bConditionResult;
	}
	
	if (ComboEdgeRow.CheckKnockDown)
	{
		bConditionResult = ComboContext.bIsKnockDown == ComboEdgeRow.bIsKnockDown && bConditionResult;
	}

	if (ComboEdgeRow.CheckKnockBack)
	{
		bConditionResult = ComboContext.bIsKnockBack == ComboEdgeRow.bIsKnockBack && bConditionResult;
	}

	if (ComboEdgeRow.CheckCanBlock)
	{
		bConditionResult = ComboContext.bCanBlock == ComboEdgeRow.bCanBlock && bConditionResult;
	}

	if (ComboEdgeRow.CheckMounted)
	{
		bConditionResult = ComboContext.bIsMounted == ComboEdgeRow.bIsMounted && bConditionResult;
	}

	if (ComboEdgeRow.CheckStumbling)
	{
		bConditionResult = ComboContext.bIsStumbling == ComboEdgeRow.bIsStumbling && bConditionResult;
	}

	if (ComboEdgeRow.CheckStamina)
	{
		bConditionResult = ComboContext.CurrentStaminaPoint >= ComboEdgeRow.Stamina && bConditionResult;
	}

	bConditionResult = !ComboContext.bIsExhausted && bConditionResult;

	return bConditionResult;		
}

bool UP3ComboTableComponent::Condition_Action(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	if (!ComboEdgeRow.CheckActionType)
	{
		return true;
	}

	bool bConditionResult = true;

	UP3PawnActionComponent* ActionComp = ComboContext.Character.IsValid() ? ComboContext.Character->GetActionComponent() : nullptr;
	if (ensure(ActionComp))
	{
		bConditionResult = ActionComp->GetActiveActionType() == ComboEdgeRow.ActionType;
	}

	return bConditionResult;
}

bool UP3ComboTableComponent::Condition_Movement(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	bool bConditionResult = true;

	if (ComboEdgeRow.CheckMovingOnGround)
	{
		bConditionResult = ComboContext.bIsMovingOnGround == ComboEdgeRow.bIsMovingOnGround;
	}

	if (ComboEdgeRow.CheckFalling)
	{
		bConditionResult = ComboContext.bIsFalling == ComboEdgeRow.bIsFalling && bConditionResult;
	}

	if (ComboEdgeRow.CheckFlying)
	{
		bConditionResult = ComboContext.bIsFlying == ComboEdgeRow.bIsFlying && bConditionResult;
	}

	if (ComboEdgeRow.CheckAscending)
	{
		bConditionResult = ComboContext.bIsAscending == ComboEdgeRow.bIsAscending && bConditionResult;
	}

	if (ComboEdgeRow.CheckMoving)
	{
		bConditionResult = ComboContext.bIsMoving == ComboEdgeRow.bIsMoving && bConditionResult;
	}

	if (ComboEdgeRow.CheckJumpHeight)
	{
		if (!ComboContext.bIsMovingOnGround && ComboContext.Character.IsValid())
		{
			FCollisionQueryParams CollisionQueryParams(SCENE_QUERY_STAT(LineTraceSingleByChannel), true, ComboContext.Character.Get());
			FHitResult HitResult;
			FVector TraceStart = ComboContext.Character->GetActorLocation();
			FVector TraceEnd = TraceStart + (-FVector::UpVector) * ComboEdgeRow.JumpHeight;

			bConditionResult = !ComboContext.Character->GetWorld()->LineTraceSingleByChannel(HitResult, TraceStart, TraceEnd, ECC_Visibility, CollisionQueryParams) && bConditionResult;
		}
	}

	if (ComboEdgeRow.CheckSpeed)
	{
		bConditionResult = (ComboContext.CurrentSpeed >= ComboEdgeRow.Speed.X && ComboContext.CurrentSpeed <= ComboEdgeRow.Speed.Y) && bConditionResult;
	}

	return bConditionResult;
}

bool UP3ComboTableComponent::Condition_Damage(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	bool bConditionResult = true;

	if (ComboEdgeRow.CheckDamageReceived)
	{
		bConditionResult = ComboContext.bIsDamageReceived == ComboEdgeRow.bIsDamageReceived && ComboContext.DamageReceivedComboName == ComboEdgeRow.DamageReceivedComboName;
	}

	return bConditionResult;
}

bool UP3ComboTableComponent::Condition_Effect(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	if (!ComboEdgeRow.CheckHasEffect)
	{
		return true;
	}

	UP3CharacterEffectComponent* EffectComp = ComboContext.Character.IsValid() ? ComboContext.Character->GetEffectComponent() : nullptr;

	if (!ensure(EffectComp))
	{
		return false;
	}

	bool bConditionResult = true;
	bool bHasEffectAll = false;
	bool bHasEffectAny = ComboEdgeRow.HasEffectsAny.Num() == 0;
	int32 HasEffectsAllCount = 0;

	for (EP3CharacterEffectTypes EffectType : ComboEdgeRow.HasEffectsAll)
	{
		if (EffectComp->HasEffect(EffectType))
		{
			HasEffectsAllCount++;
		}
	}	

	for (EP3CharacterEffectTypes EffectType : ComboEdgeRow.HasEffectsAny)
	{
		if (EffectComp->HasEffect(EffectType))
		{
			bHasEffectAny = true;
			break;
		}			
	}

	bHasEffectAll = HasEffectsAllCount == ComboEdgeRow.HasEffectsAll.Num();
	bConditionResult = bHasEffectAll && bHasEffectAny;

	return bConditionResult;
}

bool UP3ComboTableComponent::Condition_Target(const FP3ComboTableContext& ComboContext, const FP3ComboEdgeRow& ComboEdgeRow)
{
	if (CVarP3ComboTargetCondition.GetValueOnGameThread() == 0)
	{
		return true;
	}

	bool bConditionResult = true;

	if (!ComboEdgeRow.CheckTarget)
	{
		return true;
	}

	TArray<AActor*> TargetResults;
	TArray<AActor*> OverlappedResults;
	float TargetDistanceSquared2D = 0.f;

	static const FName TraceTag("Condition_Target");	
	FCollisionQueryParams CollisionQueryParams;
	CollisionQueryParams.TraceTag = TraceTag;
	CollisionQueryParams.AddIgnoredActor(ComboContext.Character.Get());

	FCollisionObjectQueryParams QueryParams;
	QueryParams.AddObjectTypesToQuery(ECC_Pawn);
	QueryParams.AddObjectTypesToQuery(ECC_WorldStatic);
	QueryParams.AddObjectTypesToQuery(ECC_Destructible);
		
	for (const FP3ComboTarget& TargetAny : ComboEdgeRow.TryTargetAny)
	{
		FCollisionShape CollisionShape;
		TArray<FOverlapResult> OverlapResults;

		CollisionShape.SetSphere(TargetAny.DistanceRange.Size());

		if (TargetAny.CheckDamage)
		{
			if (TargetAny.bIsDamageReceived)
			{
				OverlappedResults.AddUnique(ComboContext.DamageReceivedTarget.Get());
			}

			if (TargetAny.bIsDamageGiven)
			{
				OverlappedResults.AddUnique(ComboContext.DamageGivenTarget.Get());
			}
		}
		else
		{
			ComboContext.Character->GetWorld()->OverlapMultiByObjectType(OverlapResults, ComboContext.Character->GetActorLocation(), FQuat::Identity, QueryParams, CollisionShape, CollisionQueryParams);

			for (FOverlapResult& Result : OverlapResults)
			{
				if (!Result.GetActor())
				{
					continue;
				}

				if (!Result.GetActor()->IsA(AP3Character::StaticClass()) && !Result.GetActor()->IsA(AP3Actor::StaticClass()))
				{
					continue;
				}

				OverlappedResults.AddUnique(Result.GetActor());				
			}
		}

		for (AActor* OverlappedActor : OverlappedResults)
		{
			if (!ensure(OverlappedActor))
			{
				continue;
			}

			if (TargetAny.CheckClass)
			{
				bool bIsSameClass = false;
				for (const UClass* Class : TargetAny.ClassAny)
				{
					if (OverlappedActor->IsA(Class))
					{
						bIsSameClass = true;
						break;
					}
				}

				if (!bIsSameClass)
				{
					continue;
				}
			}

			if (TargetAny.CheckDistance)
			{
				FVector Direction = ComboContext.Character->GetActorLocation() - OverlappedActor->GetActorLocation();
				if (Direction.Size2D() > TargetAny.DistanceRange.X)
				{
					continue;
				}

				if (Direction.Z > TargetAny.DistanceRange.Y)
				{
					continue;
				}
			}

			if (TargetAny.CheckAngle)
			{
				FVector Direction = (OverlappedActor->GetActorLocation() - ComboContext.Character->GetActorLocation()).GetSafeNormal2D();
				FVector Forward = ComboContext.Character->GetActorForwardVector();

				const float Radian = FMath::Atan2(Forward.X * Direction.Y - Direction.X * Forward.Y, Forward.X * Direction.X + Forward.Y * Direction.Y);
				const float Degrees = FMath::RadiansToDegrees(Radian);

				if (Degrees < 0.f)
				{
					if (Degrees < TargetAny.AngleRange.X)
					{
						continue;
					}
				}
				else
				{
					if (Degrees > TargetAny.AngleRange.Y)
					{
						continue;
					}
				}				
			}

			if (TargetAny.CheckActionType)
			{
				const UP3PawnActionComponent* ActionComp = OverlappedActor->FindComponentByClass<UP3PawnActionComponent>();
				if (ActionComp && ActionComp->GetActiveActionType() != TargetAny.ActionType)
				{
					continue;
				}
			}

			AP3Character* OverlappedCharacter = Cast<AP3Character>(OverlappedActor);
			if (OverlappedCharacter)
			{
				if (TargetAny.CheckCharacterStance)
				{
					if (OverlappedCharacter->GetStance() != TargetAny.CharacterStance)
					{
						continue;
					}
				}

				if (TargetAny.CheckFaction)
				{
					if ((OverlappedCharacter->GetFaction() == ComboContext.Character->GetFaction()) != TargetAny.bIsSameFaction)
					{
						continue;
					}
				}

				if (TargetAny.CheckLarge)
				{
					if (OverlappedCharacter->IsLarge() != TargetAny.bIsLarge)
					{
						continue;
					}
				}
			}

			TargetResults.Add(OverlappedActor);

			float DistanceSquared2D = (ComboContext.Character->GetActorLocation() - OverlappedActor->GetActorLocation()).SizeSquared2D();
			if (TargetDistanceSquared2D < DistanceSquared2D)
			{				
				TargetDistanceSquared2D = DistanceSquared2D;
			}
		}

		if (TargetResults.Num() > 0)
		{
			break;
		}
	}

	const FVector SourceLocation = ComboContext.Character->GetActorLocation();
	const FVector SourceForward = ComboContext.Character->GetActorForwardVector();
	const float SourceDistanceSquared = TargetDistanceSquared2D;

	TargetResults.Sort([SourceLocation, SourceForward, SourceDistanceSquared](const AActor& A, const AActor& B)
	{
		float ForwardDot = ((A.GetActorLocation() - SourceLocation).GetSafeNormal() | SourceForward);
		float DistanceSquared = (A.GetActorLocation() - SourceLocation).SizeSquared();
		const float PointA = (ForwardDot * SourceDistanceSquared) + (SourceDistanceSquared - DistanceSquared);

		ForwardDot = ((B.GetActorLocation() - SourceLocation).GetSafeNormal() | SourceForward);
		DistanceSquared = (B.GetActorLocation() - SourceLocation).SizeSquared();
		const float PointB = (ForwardDot * SourceDistanceSquared) + (SourceDistanceSquared - DistanceSquared);

		return PointA < PointB;
	});

	const_cast<FP3ComboTableContext*>(&ComboContext)->Target = TargetResults.Num() > 0 ? TargetResults.Top() : nullptr;

	bConditionResult = ComboContext.Target.IsValid() ? true : ComboEdgeRow.bRunWithoutTarget;
	return bConditionResult;
}

void UP3ComboTableComponent::Execution_Action(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted)
{
	if (!ensure(ComboContext.Character.IsValid()))
	{
		return;
	}

	if (!bIsStarted)
	{
		if (ComboContext.ActiveActionType == EPawnActionType::CombatCombo 
			&& ComboContext.NextComboAnimationName == NAME_None
			&& ComboContext.CurrentComboName != ComboContext.NextComboName)
		{
			UAnimInstance* AnimInstance = ComboContext.Character->GetMesh() ? ComboContext.Character->GetMesh()->GetAnimInstance() : nullptr;
			const UAnimMontage* Montage = ComboContext.Character->GetCurrentMontage();

			if (AnimInstance && Montage)
			{
				AnimInstance->Montage_Stop(Montage->GetDefaultBlendOutTime(), Montage);
			}
		}

		return;
	}

	if (ComboRow.AnimationName != NAME_None && ComboRow.ActionType != EPawnActionType::Invalid)
	{		
		UP3PawnActionComponent* ActionComp = ComboContext.Character->GetActionComponent();
		UP3ComboTableComponent* ComboComp = ComboContext.Character->GetComboComponent();

		if (!ensure(ActionComp) || !ensure(ComboComp))
		{
			return;
		}

		if (ComboRow.ActionType == EPawnActionType::CombatCombo 
			&& !ComboComp->GetComboAnimationByTableName(ComboRow.AnimationName))
		{
			return;
		}
	
		FP3PawnActionStartRequestParams Params;			
		Params.Combo_Name = ComboRow.ComboName;
		Params.Combo_ChracterRotator = GetComboStartRotation(ComboContext, ComboRow.StartRotationType);		

		if (!Params.Combo_ChracterRotator.IsZero())
		{
			ComboContext.Character->SetActorRotation(Params.Combo_ChracterRotator);
		}

		Params.Combo_DeprojectWorldLocation = ComboComp->GetDeprojectWorldLocation();

		ComboContext.RequestedActionId = ActionComp->StartAction(ComboRow.ActionType, _FUNCTION_TEXT, Params);

		if (ComboContext.RequestedActionId != 0)
		{			
			ComboContext.RequestedActionType = ComboRow.ActionType;
			ComboContext.BeforeActiveComboAnimationName = ComboContext.ActiveComboAnimationName;
			ComboContext.ActiveComboAnimationName = ComboRow.AnimationName;			
			ComboContext.NextComboAnimationName = NAME_None;
			ComboContext.CurrentComboName = ComboRow.ComboName;
			ComboContext.AimingStartRotation = ComboComp->GetAimRotation(ComboComp->GetLaunchLocation());
		}
	}
}

void UP3ComboTableComponent::Execution_Command(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted)
{	
	const FP3ComboStatus& ComboStatus = bIsStarted ? ComboRow.EntryComboStatus : (ComboRow.bAutoOffStatus ? FP3ComboStatus() : ComboRow.ExitComboStatus);

	if (ComboStatus.bChangeStanceToCombat)
	{			
		ComboContext.CommandParams.ChangeStance_NewStance = EP3CharacterStance::Combat;
	}
		
	ComboContext.CommandParams.SetMeleeAiming_bNewAiming = ComboStatus.bStartMeleeAiming;
	ComboContext.CommandParams.SetRangedAiming_bNewAiming = ComboStatus.bStartRangedAiming;
	ComboContext.CommandParams.SetBouncing_bNewBouncingMode = ComboStatus.bStartBouncingMode;
	ComboContext.CommandParams.SetBlocking_bNewBlocking = ComboStatus.bStartBlockingMode;
	ComboContext.CommandParams.SetCrouchBlocking_bNewBlocking = ComboStatus.bStartCrouchBlockingMode;
}

void UP3ComboTableComponent::Execution_InputFlags(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted)
{
	if (!bIsStarted)
	{		
		return;
	}

	if (ComboRow.bClearInputFlags)
	{
		ComboContext.ComboInputFlags &= ~ComboContext.ExecutionInputFlags;
	}

	ComboContext.InputFlagStack.Reset();
	ComboContext.InputStackClearTimeSeconds = ComboRow.InputStackClearTimeSeconds;
}

void UP3ComboTableComponent::Execution_Camera(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted)
{
	const APlayerController* Controller = ComboContext.Character.IsValid() ? Cast<APlayerController>(ComboContext.Character->GetController()) : nullptr;
	if (!Controller || !Controller->PlayerCameraManager)
	{
		return;
	}

	if (bIsStarted)
	{												
		if (ComboRow.LimitPitchDegrees != 0.f)
		{
			const FVector LookForward = Controller->GetControlRotation().RotateVector(FVector(1.f, 0.f, 0.f)).GetSafeNormal();
			float PitchDegree = FMath::RadiansToDegrees(FMath::Acos(FVector::DotProduct(LookForward, FVector::UpVector)));

			PitchDegree = -(PitchDegree - 90.f);
							
			ComboContext.RestoreViewPitchMin = Controller->PlayerCameraManager->ViewPitchMin;
			ComboContext.RestoreViewPitchMax = Controller->PlayerCameraManager->ViewPitchMax;

			Controller->PlayerCameraManager->ViewPitchMin = PitchDegree - ComboRow.LimitPitchDegrees;
			Controller->PlayerCameraManager->ViewPitchMax = PitchDegree + ComboRow.LimitPitchDegrees;
		}

		if (ComboRow.LimitYawDegrees != 0.f)
		{						
			const FVector LookForward = Controller->GetControlRotation().RotateVector(FVector(1.f, 0.f, 0.f)).GetSafeNormal2D();
			const float Sin = FVector::ForwardVector.X * LookForward.Y - LookForward.X * FVector::ForwardVector.Y;
			const float Cos = FVector::ForwardVector.X * LookForward.X + FVector::ForwardVector.Y * LookForward.Y;

			const float YawRadian = FMath::Atan2(Sin, Cos);
			float YawDegree = FMath::RadiansToDegrees(YawRadian);

			if (YawDegree < 0.f)
			{
				YawDegree = 360.f + YawDegree;
			}

			ComboContext.RestoreViewYawMin = Controller->PlayerCameraManager->ViewYawMin;
			ComboContext.RestoreViewYawMax = Controller->PlayerCameraManager->ViewYawMax;

			Controller->PlayerCameraManager->ViewYawMin = YawDegree - ComboRow.LimitYawDegrees;
			Controller->PlayerCameraManager->ViewYawMax = YawDegree + ComboRow.LimitYawDegrees;
		}

		if (!ComboRow.CmsCameraShakeKey.IsNone())
		{
			const FP3CmsCameraShakeRow* CmsCameraShakeRow = P3Cms::GetCameraShake(ComboRow.CmsCameraShakeKey);
			if (!CmsCameraShakeRow)
			{
				return;
			}

			if (CmsCameraShakeRow->bStandaloneLocalPlay)
			{
				ComboContext.Character->Client_PlayCameraShake(ComboRow.CmsCameraShakeKey);
			}
			else
			{
				UP3CommandComponent* CommandComp = ComboContext.Character.IsValid() ? ComboContext.Character->GetCommandComponent() : nullptr;
				if (CommandComp)
				{
					FP3CommandRequestParams CommandParams;
					CommandParams.CmsCameraShakeKey = ComboRow.CmsCameraShakeKey;
					CommandParams.CameraShakeLocation = ComboContext.Character->GetActorLocation();
					CommandParams.CameraShakeActor = ComboContext.Character.Get();
					CommandComp->RequestCommand(UP3CameraShakeCommand::StaticClass(), CommandParams);
				}
			}
		}
	}
	else
	{
		if (ComboRow.LimitPitchDegrees != 0.f)
		{
			Controller->PlayerCameraManager->ViewPitchMin = ComboContext.RestoreViewPitchMin;
			Controller->PlayerCameraManager->ViewPitchMax = ComboContext.RestoreViewPitchMax;
		}

		if (ComboRow.LimitYawDegrees != 0.f)
		{
			Controller->PlayerCameraManager->ViewYawMin = ComboContext.RestoreViewYawMin;
			Controller->PlayerCameraManager->ViewYawMax = ComboContext.RestoreViewYawMax;
		}
	}
}

void UP3ComboTableComponent::Execution_Stamina(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted)
{
	if (!bIsStarted)
	{
		return;
	}

	ComboContext.ConsumeStaminaPerSecond = ComboRow.ConsumeStaminaPerSecond;
}

void UP3ComboTableComponent::Execution_MoveTowardsTarget(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted)
{
	if (!bIsStarted)
	{
		return;
	}

	ComboContext.MoveTowardsTargetIntervalDistance = ComboRow.IntervalDistance;
	ComboContext.MoveTowardsTargetMultiplyInputScale = ComboRow.MultiplyInputScale;
}

void UP3ComboTableComponent::Execution_Movement(FP3ComboTableContext& ComboContext, const FP3ComboRow& ComboRow, const bool bIsStarted)
{
	if (!bIsStarted)
	{
		return;
	}

	ComboContext.SpeedMultiplier = ComboRow.SpeedMultiplier;
	ComboContext.RotationYawMultiplier = ComboRow.RotationYawMultiplier;
}

FString UP3ComboTableComponent::GetDebugString() const
{
	FString OutString;

	OutString += FString::Printf(TEXT("%s : %f\n"), *CurrentComboName.ToString(), CurrentComboProgressTimeSeconds);

	OutString += FString::Printf(TEXT("%s\n"), *EnumToString(EPawnActionType, ComboContext.ActiveActionType));
	OutString += FString::Printf(TEXT("%s->%s\n"), *ComboContext.BeforeActiveComboAnimationName.ToString(), *ComboContext.ActiveComboAnimationName.ToString());

	const FVector ControlNormalDirection = (ComboContext.InputForwardDirection + ComboContext.InputRightDirection).GetSafeNormal();
	OutString += FString::Printf(TEXT("%f : %f : %f\n"), ControlNormalDirection.X, ControlNormalDirection.Y, ControlNormalDirection.Z);
	
	OutString += FString::Printf(TEXT("RequestedActionId:%d : ReceivedActionId:%d\n"), ComboContext.RequestedActionId, ComboContext.ReceivedActionId);	
	
	OutString += FString::Printf(TEXT("InputMoveBlock:%d "), ComboContext.LocalControl_bIsAnimNotifyInputMoveBlock);
	OutString += FString::Printf(TEXT("InputTurnBlock:%d "), ComboContext.LocalControl_bIsAnimNotifyInputTurnBlock);
	OutString += FString::Printf(TEXT("InputTurnBlock:%d "), ComboContext.LocalControl_bIsAnimNotifyInputCameraMoveBlock);
	OutString += FString::Printf(TEXT("InputStack:%d "), ComboContext.LocalControl_bIsAnimNotifyInputButtonStack);
	OutString += FString::Printf(TEXT("ActionBlock:%d\n"), ComboContext.LocalControl_bIsAnimNotifyPlayActionBlock);

	OutString += FString::Printf(TEXT("Stance:%s\n"), *EnumToString(EP3CharacterStance, ComboContext.Stance));
	OutString += FString::Printf(TEXT("IsBlockingMode:%d "), ComboContext.bIsBlockingMode);
	OutString += FString::Printf(TEXT("IsCrouchBlockingMode:%d "), ComboContext.bIsCrouchBlockingMode);
	OutString += FString::Printf(TEXT("IsBouncingMode:%d "), ComboContext.bIsBouncingMode);
	OutString += FString::Printf(TEXT("IsMeleeAiming:%d "), ComboContext.bIsMeleeAiming);
	OutString += FString::Printf(TEXT("IsRangedAiming:%d\n"), ComboContext.bIsRangedAiming);
	OutString += FString::Printf(TEXT("IsStumbling:%d "), ComboContext.bIsStumbling);
	OutString += FString::Printf(TEXT("IsExhausted:%d "), ComboContext.bIsExhausted);
	OutString += FString::Printf(TEXT("IsMovingOnGround:%d "), ComboContext.bIsMovingOnGround);
	OutString += FString::Printf(TEXT("IsFalling:%d "), ComboContext.bIsFalling);
	OutString += FString::Printf(TEXT("IsFlying:%d\n"), ComboContext.bIsFlying);
	OutString += FString::Printf(TEXT("IsAscending:%d "), ComboContext.bIsAscending);
	OutString += FString::Printf(TEXT("IsMoving:%d "), ComboContext.bIsMoving);
	OutString += FString::Printf(TEXT("CanCombat:%d "), ComboContext.bCanCombat);
	OutString += FString::Printf(TEXT("IsKnockDown:%d "), ComboContext.bIsKnockDown);
	OutString += FString::Printf(TEXT("IsKnockBack:%d\n"), ComboContext.bIsKnockBack);
	OutString += FString::Printf(TEXT("CanBlock:%d "), ComboContext.bCanBlock);
	OutString += FString::Printf(TEXT("IsMounted:%d "), ComboContext.bIsMounted);
	OutString += FString::Printf(TEXT("HasStunEffect:%d "), ComboContext.bHasStunEffect);
	OutString += FString::Printf(TEXT("IsDamageReceived:%d "), ComboContext.bIsDamageReceived);
	OutString += FString::Printf(TEXT("CurrentStaminaPoint:%f "), ComboContext.CurrentStaminaPoint);
	OutString += FString::Printf(TEXT("MaxJumpHeight:%f\n"), ComboContext.MaxJumpHeight);
	
	for (int32 i = 0; i < (int32)EP3ComboTableInputFlags::Count; ++i)
	{
		if (HasFlags(ComboContext.ComboInputFlags,(EP3ComboTableInputFlags)i))
		{
			OutString += FString::Printf(TEXT("%s\n"), *EnumToString(EP3ComboTableInputFlags, (EP3ComboTableInputFlags)(i)));
		}
	}

	for (int32 i = 0; i < (int32)EP3ComboTableInputFlags::Count; ++i)
	{
		if (ComboContext.InputButtonPressTimeSeconds[i] > 0.f)
		{
			OutString += FString::Printf(TEXT("%f\n"), ComboContext.InputButtonPressTimeSeconds[i]);
		}
	}

	for (const EP3ComboTableInputFlags& Itr : ComboContext.InputFlagStack)
	{
		OutString += FString::Printf(TEXT("%s\n"), *EnumToString(EP3ComboTableInputFlags, Itr));
	}

	if (CurrentComboName == Name_RootCombo)
	{
		return OutString;
	}

	const FP3ComboRow* ComboRow = ComboTable.Find(CurrentComboName);
	if (ComboRow)
	{		
		OutString += FString::Printf(TEXT("===================ComboRow===================\n"));
		OutString += FString::Printf(TEXT("%s\n"), *EnumToString(EPawnActionType, ComboRow->ActionType));
		OutString += FString::Printf(TEXT("%s : %s \n"), *ComboRow->AnimationName.ToString(), *EnumToString(EP3ComboTableStartRotationType, ComboRow->StartRotationType));		
		OutString += FString::Printf(TEXT("StartAimShake:%d "), ComboRow->bStartAimShake);
		OutString += FString::Printf(TEXT("ClearInputFlags:%d "), ComboRow->bClearInputFlags);
		OutString += FString::Printf(TEXT("ConsumeStamina:%f "), ComboRow->ConsumeStamina);
		OutString += FString::Printf(TEXT("ConsumeStaminaPerSecond:%f\n"), ComboRow->ConsumeStaminaPerSecond);

		OutString += FString::Printf(TEXT("ChangeStanceToCombat:%d "), ComboRow->EntryComboStatus.bChangeStanceToCombat);
		OutString += FString::Printf(TEXT("StartMeleeAiming:%d "), ComboRow->EntryComboStatus.bStartMeleeAiming);
		OutString += FString::Printf(TEXT("StartRangedAiming:%d "), ComboRow->EntryComboStatus.bStartRangedAiming);
		OutString += FString::Printf(TEXT("StartBouncingMode:%d "), ComboRow->EntryComboStatus.bStartBouncingMode);
		OutString += FString::Printf(TEXT("StartBlockingMode:%d "), ComboRow->EntryComboStatus.bStartBlockingMode);
		OutString += FString::Printf(TEXT("StartCrouchBlockingMode:%d "), ComboRow->EntryComboStatus.bStartCrouchBlockingMode);
	}

	if (ComboContext.Target.IsValid())
	{
		const UCapsuleComponent* CapsuleComp = ComboContext.Target->FindComponentByClass<UCapsuleComponent>();		
		float CapsuleHeight = 100.f;
		if (CapsuleComp)
		{
			CapsuleHeight = CapsuleComp->GetScaledCapsuleRadius() * 2.f;
		}

		const FVector LineStart = ComboContext.Target->GetActorLocation() + ComboContext.Target->GetActorUpVector() * CapsuleHeight;
		const FVector LineEnd = LineStart + ComboContext.Target->GetActorUpVector() * CapsuleHeight;
		const float ArrowSize = 3000.f;
		const FColor ArrowColor = FColor(255, 0, 0);		

		DrawDebugDirectionalArrow(ComboContext.Target->GetWorld(), LineEnd, LineStart, ArrowSize, ArrowColor);
	}

	return OutString;
}
