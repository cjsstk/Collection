// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3IngredientComponent.h"

UP3IngredientComponent::UP3IngredientComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}
