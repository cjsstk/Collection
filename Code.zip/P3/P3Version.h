// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "P3Version.generated.h"

/** 빌드 정보 */
USTRUCT(BlueprintType)
struct FP3Version
{
	GENERATED_BODY()

public:
	/** 젠킨스 빌드 번호 */
	UPROPERTY(BlueprintReadOnly)
	FString BuildNumber;

	/** 빌드 시점 Git 해시 */
	UPROPERTY(BlueprintReadOnly)
	FString Git;

	/** 빌드 시점 브랜치 이름 */
	UPROPERTY(BlueprintReadOnly)
	FString Branch;
};
