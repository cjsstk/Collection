// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3Backpack.generated.h"

/**
 * 플레이어가 아이템을 넣고 다니는 배낭 액터
 */
UCLASS()
class P3_API AP3Backpack : public AP3Actor
{
	GENERATED_BODY()

public:
	AP3Backpack();

	void Server_SetBackpackOwnerID(charid InOwnerCharacterId);

	virtual void NetSerialize(FArchive& Archive) override;
protected:

private:
	UPROPERTY(VisibleAnywhere)
	class USkeletalMeshComponent* SkeletalMeshComponent = nullptr;

	UPROPERTY()
	class UP3PickupableComponent* PickupableComponent = nullptr;

	charid Net_OwnerCharacterID = INVALID_CHARID;
};
