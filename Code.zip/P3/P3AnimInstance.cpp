// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AnimInstance.h"

#include "Animation/AnimSequenceBase.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"

#include "Action/P3PawnActionComponent.h"
#include "Animation/P3LookIKComponent.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3ComboTableComponent.h"
#include "P3HolderComponent.h"
#include "P3Log.h"
#include "P3PickupableComponent.h"
#include "P3PickupComponent.h"

TAutoConsoleVariable<int32> CVarP3EnableLookIK(
	TEXT("p3.enableLookIK"),
	0,
	TEXT("1: enable. 0: disable"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3LookIKDebug(
	TEXT("p3.lookIKDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3TurnAnimDebug(
	TEXT("p3.turnAnimDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3PickupUseIK(
	TEXT("p3.pickupUseIK"),
	0,
	TEXT("1: use, 0: don't use"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3EmoteAnimDebug(
	TEXT("p3.emoteAnimDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

void UP3AnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	AP3Character* Character = Cast<AP3Character>(TryGetPawnOwner());

	if (LookIK && Character && Character->GetMesh() && CVarP3EnableLookIK.GetValueOnGameThread())
	{
		LookIK->TickLookIK(*Character, DeltaSeconds);

		bHasValidLookAtTarget = LookIK->GetLookAtTargetLocation(LookAtTargetLocation);

#if ENABLE_DRAW_DEBUG
		if (CVarP3LookIKDebug.GetValueOnGameThread() > 0)
		{
			if (bHasValidLookAtTarget)
			{
				DrawDebugSphere(GetWorld(), LookAtTargetLocation, 30.0f, 12, FColor::Green);
			}
		}
#endif
	}
	else
	{
		bHasValidLookAtTarget = false;
		LookAtTargetLocation = FVector::ZeroVector;
	}

	if (bUseTurnAnimation)
	{
		TickTurnAnimation(DeltaSeconds, Character);
	}

	TickCharacter(Character);
	TickPickupArmIK(DeltaSeconds);
}

void UP3AnimInstance::TickCharacter(class AP3Character* Character)
{
	Stance = EP3CharacterStance::Idle;
	PickupableType = EP3PickupableType::None;
	bEntangled = false;
	bRoarStunned = false;
	bStunned = false;
	bInSwamp = false;
	bStumbling = false;
	bIsInCombatStance = false;
	bPlayCombatStanceAnim = false;
	CombatRunBlendSpeaceIndex = 0;
	bIsItemThrowAiming = false;

	if (!Character)
	{
		return;
	}

	Stance = Character->GetStance();
	bIsInCombatStance = (Character->GetStance() == EP3CharacterStance::Combat);
	bStumbling = Character->GetCharacterStoreBP().bIsStumbling;

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();
	AActor* PickuppedActor = nullptr;
	if (PickupComp)
	{
		PickuppedActor = PickupComp->GetPickuppedActor() ? PickupComp->GetPickuppedActor() : PickupComp->GetActorInPickupAction();
	}

	if (PickuppedActor)
	{
		UP3PickupableComponent* PickupableComp = PickuppedActor->FindComponentByClass<UP3PickupableComponent>();
		if (PickupableComp)
		{
			PickupableType = PickupableComp->GetPickupableType();
		}
	}

	bIsItemThrowAiming = Character->GetCharacterStoreBP().bIsAiming && (Character->GetCharacterStoreBP().ThrowAimingItemId != INVALID_ITEMID);

	UP3CharacterEffectComponent* EffectComp = Character->GetEffectComponent();
	if (EffectComp && EffectComp->HasEffect(EP3CharacterEffectTypes::Swamp))
	{
		bInSwamp = true;
	}
	if (EffectComp && EffectComp->HasEffect(EP3CharacterEffectTypes::Entangle))
	{
		bEntangled = true;
	}
	if (EffectComp && EffectComp->HasEffect(EP3CharacterEffectTypes::RoarStun))
	{
		bRoarStunned = true;
	}
	if (EffectComp && EffectComp->HasEffect(EP3CharacterEffectTypes::Stun))
	{
		bStunned = true;
	}

	bPlayCombatStanceAnim = (Character->GetStance() == EP3CharacterStance::Combat);

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (ActionComp)
	{
		const EPawnActionType ActiveActionType = ActionComp->GetActiveActionType();
		if (ActiveActionType == EPawnActionType::DrawWeapon)
		{
			bPlayCombatStanceAnim = true;
		}
		else if (ActiveActionType == EPawnActionType::PutAwayWeapon)
		{
			bPlayCombatStanceAnim = false;
		}
	}

	if (Character->GetComboComponent())
	{
		CombatRunBlendSpeaceIndex = Character->GetComboComponent()->GetCombatRunBlendSpeaceIndex();
	}

	if (Stance == EP3CharacterStance::Combat || Character->GetCharacterStoreBP().bIsAiming)
	{
		LastCombatStanceTimeSeconds = GetWorld()->GetTimeSeconds();
		bUseCombatIdle = true;
	}
	else
	{
		bUseCombatIdle = (GetWorld()->GetTimeSeconds() < (LastCombatStanceTimeSeconds + CombatIdleDurationSeconds));
	}
}

void UP3AnimInstance::NativeBeginPlay()
{
	Super::NativeBeginPlay();

	if (GIsClient)
	{
		LookIK = NewObject<UP3LookIK>(this, TEXT("LookIK"), RF_Transient);
	}

	bIsDedicatedServer = IsRunningDedicatedServer();
}

void UP3AnimInstance::OnTurnAnimationStarted()
{
	if (ensure(bStartTurnAnimation))
	{
		bStartTurnAnimation = false;

		ensure(bPlayingTurnAnimation);
	}
}

void UP3AnimInstance::OnTurnAnimationFinished()
{
	if (ensure(bPlayingTurnAnimation))
	{
		bPlayingTurnAnimation = false;
		bStartTurnAnimation = false;
		TurnAnimEstimatedFinishTimeSeconds = 0;
	}

	// COMMENT-OUT: do not reset following members, since they are still in use for state transition blending
	//SelectedTurnAnimSequence = nullptr;
	//SelectedTurnAnimPlayRate = 1.0f;
}

void UP3AnimInstance::TickTurnAnimation(float DeltaSeconds, AP3Character* Character)
{
	if (!bStartTurnAnimation && !bPlayingTurnAnimation)
	{
		ConsiderTurnAnimation(DeltaSeconds);
	}

	if (bStartTurnAnimation)
	{
		// Consider cancel turn animation if moving
		if (Character)
		{
			if (Character->GetVelocity().SizeSquared2D() > 1.0f)
			{
				bStartTurnAnimation = false;
			}
		}
	}

	if (bStartTurnAnimation || bPlayingTurnAnimation)
	{
		if (GetWorld()->GetTimeSeconds() > TurnAnimEstimatedFinishTimeSeconds)
		{
			// Looks like Anim Graph is stuck or changed to some other State Machine
			// We should not wait for it, otherwise turn anim will not be shown at all from here
			bPlayingTurnAnimation = false;
			bStartTurnAnimation = false;
			TurnAnimEstimatedFinishTimeSeconds = 0;
		}
	}

	if (bPlayingTurnAnimation)
	{
		if (CVarP3TurnAnimDebug.GetValueOnGameThread() != 0)
		{
			if (Character)
			{
				Character->AddDebugString(FString::Printf(TEXT("Turn Sequence: %s"), SelectedTurnAnimSequence ? *SelectedTurnAnimSequence->GetName() : TEXT("NULL")));
				Character->AddDebugString(FString::Printf(TEXT("Turn Play Rate: %.2f"), SelectedTurnAnimPlayRate));
			}
		}
	}
}

void UP3AnimInstance::ConsiderTurnAnimation(float DeltaSeconds)
{
	ensure(!bStartTurnAnimation && !bPlayingTurnAnimation);

	if (DeltaSeconds == 0.0f)
	{
		// When pawn is spawned from spawner, this gets called with delta 0 by InitAnim()
		// In this case, BaseAimRotation seems not ready yet, meaning we cannot decide turn rotation here.
		return;
	}

	ACharacter* Character = Cast<ACharacter>(TryGetPawnOwner());
	if (!Character || !Character->GetMovementComponent())
	{
		return;
	}

	if (Character->GetVelocity().SizeSquared2D() > 0.0f)
	{
		return;
	}

	const float YawDelta = FMath::UnwindDegrees((Character->GetBaseAimRotation() - Character->GetActorRotation()).Yaw);
	const float YawDeltaAbs = FMath::Abs(YawDelta);

	// Note we need to avoid 180 since we have no idea weather pawn will turn left or right
	if (YawDeltaAbs > (45.0f * 0.5f) && !FMath::IsNearlyEqual(YawDeltaAbs, 180.0f, 1.0f))
	{
		const int32 YawIndex5 = FMath::RoundToInt(YawDeltaAbs / 45.0f);
		if (ensure(YawIndex5 >= 0 && YawIndex5 < 5))
		{
			const bool bTurnRight = (YawDelta > 0);

			UAnimSequenceBase* AnimSequences5[] = {
				// NOTE R45 is doubly used for first index for testing
				bTurnRight ? AnimSequence_Turn_R45 : AnimSequence_Turn_L45,
				bTurnRight ? AnimSequence_Turn_R45 : AnimSequence_Turn_L45,
				bTurnRight ? AnimSequence_Turn_R90 : AnimSequence_Turn_L90,
				bTurnRight ? AnimSequence_Turn_R135 : AnimSequence_Turn_L135,
				bTurnRight ? AnimSequence_Turn_R180 : AnimSequence_Turn_L180
			};
			float AnimSequeceYaw5[] = {
				45, 45, 90, 135, 180
			};
			static_assert(ARRAY_COUNT(AnimSequences5) == 5, "Must be 5");
			static_assert(ARRAY_COUNT(AnimSequeceYaw5) == 5, "Must be 5");

			SelectedTurnAnimSequence = AnimSequences5[YawIndex5];

			if (SelectedTurnAnimSequence && SelectedTurnAnimSequence->GetPlayLength() > 0)
			{
				const float AnimTurnSpeed = AnimSequeceYaw5[YawIndex5] / SelectedTurnAnimSequence->GetPlayLength();
				const float PawnTurnSpeed = Character->GetCharacterMovement()->RotationRate.Yaw;

				// If pawn turns faster than animation, we need to play faster
				const float TurnSpeedRate = PawnTurnSpeed / AnimTurnSpeed;

				// If pawn turn less or more than animation, we need to play faster or slower
				const float TurnDegreeRate = AnimSequeceYaw5[YawIndex5] / YawDeltaAbs;

				bStartTurnAnimation = true;
				bPlayingTurnAnimation = true;
				SelectedTurnAnimPlayRate = /*TurnSpeedRate * */TurnDegreeRate;
				TurnAnimationRotationDegreePerSecond = AnimTurnSpeed;
				TurnAnimEstimatedFinishTimeSeconds = GetWorld()->GetTimeSeconds() + SelectedTurnAnimSequence->GetPlayLength() + 3.0f;	// 3.0 is just some ballpark margin for node transition

				if (CVarP3TurnAnimDebug.GetValueOnGameThread() != 0)
				{
					UE_LOG(P3Log, Display, TEXT("Turn Animation Selected: %s"), *SelectedTurnAnimSequence->GetName());
					UE_LOG(P3Log, Display, TEXT("  Yaw: %.0f Degree"), YawDelta);
					UE_LOG(P3Log, Display, TEXT("  Pawn Turn Speed: %.2f"), PawnTurnSpeed);
					UE_LOG(P3Log, Display, TEXT("  Anim Turn Speed: %.2f"), AnimTurnSpeed);
					UE_LOG(P3Log, Display, TEXT("  Turn Speed Rate: %.2f"), TurnSpeedRate);
					UE_LOG(P3Log, Display, TEXT("  Turn Angle Rate: %.2f"), TurnDegreeRate);
					UE_LOG(P3Log, Display, TEXT("  Final Play Speed Rate: %.2f"), SelectedTurnAnimPlayRate);
				}

			}
		}
	}
}

void UP3AnimInstance::TickPickupArmIK(float DeltaSeconds)
{
	const float OldPickupArmIKRightHandAlpha = PickupArmIKRightHandAlpha;
	const float OldPickupArmIKLeftHandAlpha = PickupArmIKLeftHandAlpha;

	PickupArmIKRightHandAlpha = 0.0f;
	PickupArmIKLeftHandAlpha = 0.0f;
	PickupArmIKRightHandEffectorLocation = FVector::ZeroVector;
	PickupArmIKLeftHandEffectorLocation = FVector::ZeroVector;

	if (CVarP3PickupUseIK.GetValueOnGameThread() == 0)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(TryGetPawnOwner());

	if (!Character || !Character->GetMesh())
	{
		return;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();
	AActor* PickuppedActor = PickupComp ? PickupComp->GetPickuppedActor() : nullptr;

	if (!PickuppedActor)
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();

	if (ActionComp && ActionComp->GetActiveActionType() != EPawnActionType::Invalid)
	{
		return;
	}


	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(PickuppedActor->GetRootComponent());
	if (!PrimComp)
	{
		return;
	}

	const float SweepStartZ = -30.0f;
	const float SweepEndZ = 10.0f;

	const FTransform RightHandTransform = Character->GetMesh()->GetSocketTransform(FName(TEXT("Bip01-R-Hand")));
	const FTransform LeftHandTransform = Character->GetMesh()->GetSocketTransform(FName(TEXT("Bip01-L-Hand")));
	const FVector RightHandSweepStartLocation = RightHandTransform.GetTranslation() + FVector(0, 0, SweepStartZ);
	const FVector LeftHandSweepStartLocation = LeftHandTransform.GetTranslation() + FVector(0, 0, SweepStartZ);
	const FVector UpVector = Character->GetActorUpVector();
	const FVector Sweep = UpVector * (SweepEndZ - SweepStartZ);
	const FTransform MeshTransform = Character->GetMesh()->GetComponentTransform();

	FCollisionQueryParams CollisionQueryParams;
	FHitResult RightHandHitResult, LeftHandHitResult;

	const bool bFoundRightHandLineTracePoint = PrimComp->LineTraceComponent(RightHandHitResult, RightHandSweepStartLocation, RightHandSweepStartLocation + Sweep, CollisionQueryParams);

	const bool bFoundLeftHandLineTracePoint = PrimComp->LineTraceComponent(LeftHandHitResult, LeftHandSweepStartLocation, LeftHandSweepStartLocation + Sweep, CollisionQueryParams);

	if (bFoundRightHandLineTracePoint)
	{
		PickupArmIKRightHandAlpha = FMath::Min(OldPickupArmIKRightHandAlpha + DeltaSeconds, 1.0f);
		PickupArmIKRightHandEffectorLocation = MeshTransform.InverseTransformPosition(RightHandHitResult.Location);
	}
	else
	{
		PickupArmIKRightHandAlpha = FMath::Max(OldPickupArmIKRightHandAlpha - DeltaSeconds, 0.0f);
	}

	if (bFoundLeftHandLineTracePoint)
	{
		PickupArmIKLeftHandAlpha = FMath::Min(OldPickupArmIKLeftHandAlpha + DeltaSeconds, 1.0f);
		PickupArmIKLeftHandEffectorLocation = MeshTransform.InverseTransformPosition(LeftHandHitResult.Location);
	}
	else
	{
		PickupArmIKLeftHandAlpha = FMath::Max(OldPickupArmIKLeftHandAlpha - DeltaSeconds, 0.0f);
	}
}

int32 UP3AnimInstance::GetAimOffsetAnimationIndex() const
{
	AP3Character* Character = Cast<AP3Character>(TryGetPawnOwner());

	if (Character && Character->GetComboComponent())
	{
		return  Character->GetComboComponent()->GetAimOffsetAnimationIndex();
	}

	return 0;
}

int32 UP3AnimInstance::GetCombatRunBlendSpeaceIndex() const
{
	AP3Character* Character = Cast<AP3Character>(TryGetPawnOwner());

	if (Character && Character->GetComboComponent())
	{
		return Character->GetComboComponent()->GetCombatRunBlendSpeaceIndex();
	}

	return 0;
}

const FVector2D UP3AnimInstance::GetAimOffset(float Scale) const
{
	AP3Character* Character = Cast<AP3Character>(TryGetPawnOwner());

	if (Character && Character->GetComboComponent())
	{
		return Character->GetComboComponent()->GetAimOffset(Scale);
	}

	return FVector2D::ZeroVector;
}

void UP3AnimInstance::AddSnapshot(const FName& SnapshotName)
{
	SavePoseSnapshot(SnapshotName);
	PoseSnapshot.Add(SnapshotName);
}

void UP3AnimInstance::RemoveSnapshot(const FName& SnapshotName)
{
	PoseSnapshot.Remove(SnapshotName);
}

bool UP3AnimInstance::HasSnapshot(const FName SnapshotName) const
{
	return PoseSnapshot.Contains(SnapshotName);
}

void UP3AnimInstance::SetPoseAsset(const FName& PoseName, float Weight)
{
	PoseAsset.FindOrAdd(PoseName) = Weight;
}

void UP3AnimInstance::SetPoseAssetAlpha(float Alpha)
{
	PoseAssetAlpha = Alpha;
}

float UP3AnimInstance::GetPoseAssetWeight(const FName PoseName) const
{
	return PoseAsset.FindRef(PoseName);
}

float UP3AnimInstance::GetPoseAssetAlpha() const
{
	return PoseAssetAlpha;
}

void UP3AnimInstance::SetCCDAlpha(const FName& CCDName, float Alpha)
{
	CCDAlpha.Add(CCDName, Alpha);
}

void UP3AnimInstance::SetCCDEffectLocation(const FName& CCDName, const FVector& EffectLocation)
{
	CCDEffectLocation.Add(CCDName, EffectLocation);
}

void UP3AnimInstance::ClearCCDEffectLocation()
{
	CCDEffectLocation.Reset();
}

float UP3AnimInstance::GetCCDAlpha(const FName CCDName) const
{
	return CCDAlpha.FindRef(CCDName);
}

FVector UP3AnimInstance::GetCCDEffectLocation(const FName CCDName) const
{
	return CCDEffectLocation.FindRef(CCDName);
}

void UP3OrcAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();

	AnimSequenceSet = Cast<UP3OrcAnimSequnceData>(UP3OrcAnimSequnceData::StaticClass()->ClassDefaultObject);
}

void UP3OrcAnimInstance::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	AP3Character* Character = Cast<AP3Character>(TryGetPawnOwner());

	if (!Character)
	{
		return;
	}

	// 무기 장착 여부에 따라 애니메이션이 갈림
	bool HasWeapon = false;

	if (Character->GetRightHandHolderComponent())
	{
		HasWeapon = Character->GetRightHandHolderComponent()->IsHold();
	}
	else if (Character->GetLeftHandHolderComponent())
	{
		HasWeapon = Character->GetLeftHandHolderComponent()->IsHold();
	}

	if (HasWeapon)
	{
		AnimSequenceSet = DefaultAnimSequenceSet;
	}
	else
	{
		AnimSequenceSet = FistAnimSequenceSet;
	}

	EmoteAnim.EmoteAnimationStart = (Character->GetEmote()).EmoteAnimationStart;
	EmoteAnim.EmoteAnimationLoop = (Character->GetEmote()).EmoteAnimationLoop;
	EmoteAnim.EmoteAnimationEnd = (Character->GetEmote()).EmoteAnimationEnd;

	if (CVarP3EmoteAnimDebug.GetValueOnGameThread() != 0)
	{
		if (Character)
		{
			Character->AddDebugString(FString::Printf(TEXT("Is Emote?: %s"), Character->IsInEmote() ? TEXT("True") : TEXT("False")));
			Character->AddDebugString(FString::Printf(TEXT("Emote Start Sequence: %s"), (EmoteAnim.EmoteAnimationStart) ? *((EmoteAnim.EmoteAnimationStart)->GetName()) : TEXT("NULL")));
			Character->AddDebugString(FString::Printf(TEXT("Emote Loop Sequence: %s"), (EmoteAnim.EmoteAnimationLoop) ? *((EmoteAnim.EmoteAnimationLoop)->GetName()) : TEXT("NULL")));
			Character->AddDebugString(FString::Printf(TEXT("Emote End Sequence: %s"), (EmoteAnim.EmoteAnimationEnd) ? *((EmoteAnim.EmoteAnimationEnd)->GetName()) : TEXT("NULL")));
		}
	}
}
