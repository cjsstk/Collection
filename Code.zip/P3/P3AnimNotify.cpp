// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AnimNotify.h"

#include "Components/SkeletalMeshComponent.h"
#include "EngineUtils.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "PhysicalMaterials/PhysicalMaterial.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3CombatComponent.h"
#include "P3CombatResponseComponent.h"
#include "P3CombatShapeCollision.h"
#include "P3ComboTableComponent.h"
#include "P3GameState.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3Log.h"
#include "P3PartComponent.h"
#include "P3Projectile.h"
#include "P3PlayerController.h"
#include "P3SpawnerActor.h"

UP3CombatComponent* _GetCombatComponent(USkeletalMeshComponent* MeshComp)
{
	if (!MeshComp)
	{
		return nullptr;
	}

	AP3Character* Character = Cast<AP3Character>(MeshComp->GetOwner());
	if (!Character)
	{
		return nullptr;
	}

	return Character->GetP3CombatComponentBP();
}

UP3ComboTableComponent* _GetComboComponent(USkeletalMeshComponent* MeshComp)
{
	if (!MeshComp)
	{
		return nullptr;
	}

	AP3Character* Character = Cast<AP3Character>(MeshComp->GetOwner());
	if (!Character)
	{
		return nullptr;
	}

	return Character->GetComboComponent();
}

void UAnimNotifyState_AttackMove::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	UP3CombatComponent* CombatComp = _GetCombatComponent(MeshComp);
	if (CombatComp)
	{
		CombatComp->OnAttackMoveAnimNotifyBegin();
	}
}

void UAnimNotifyState_AttackMove::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	UP3CombatComponent* CombatComp = _GetCombatComponent(MeshComp);
	if (CombatComp)
	{
		CombatComp->OnAttackMoveAnimNotifyEnd();
	}
}

void UAnimNotify_Action::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);
	
	if (ActionNotifyType == EActionAnimNotifyType::Invalid)
	{
		P3JsonLog(Warning, "Invalid action notfiy found", TEXT("Animation"), Animation ? Animation->GetFName() : TEXT("NULL"));
	}

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		ensure(ActionNotifyType != EActionAnimNotifyType::Invalid);

		Character->OnActionAnimNotify.Broadcast(ActionNotifyType);
	}
}

FString UAnimNotify_Action::GetNotifyName_Implementation() const
{  
	return FString(TEXT("Action:")) + EnumToStringShort(EActionAnimNotifyType, ActionNotifyType);
}

void UAnimNotify_Pickup::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		Character->OnPickupAnimNotify.Broadcast();
	}
}

void UAnimNotify_Throw::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		Character->OnThrowAnimNotify.Broadcast();
	}
}

void UAnimNotifyState_ReactionBlock::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{		
		if (bIsPlayHitAnimationBlock)
		{
			Character->SetIgnoredHitAnimation(true);

			if (Character->GetMesh())
			{
				HitAnimationBlockMaterial = Character->GetMesh()->CreateDynamicMaterialInstance(0);
				if (HitAnimationBlockMaterial)
				{						
					HitAnimationBlockMaterial->SetScalarParameterValue(NAME_ParameterHitAnimationBlock, 1.f);					
				}
			}
		}

		if (bIsPlayHitRotatorBlock)
		{
			Character->SetIgnoredHitRotator(true);		
		}
	}
}

void UAnimNotifyState_ReactionBlock::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{	
		if (bIsPlayHitAnimationBlock)
		{
			Character->SetIgnoredHitAnimation(false);

			if (HitAnimationBlockMaterial)
			{
				HitAnimationBlockMaterial->SetScalarParameterValue(NAME_ParameterHitAnimationBlock, 0.f);
			}
		}

		if (bIsPlayHitRotatorBlock)
		{
			Character->SetIgnoredHitRotator(false);
		}
	}
}

void UAnimNotifyState_AutoMoveTowardsTarget::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboComponent = Character->GetComboComponent();
		if (ensure(ComboComponent))
		{
			ComboComponent->SetAutoMoveTowardsTarget(true);						
		}
	}
}

void UAnimNotifyState_AutoMoveTowardsTarget::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboComponent = Character->GetComboComponent();
		if (ensure(ComboComponent))
		{
			ComboComponent->SetAutoMoveTowardsTarget(false);						
		}
	}
}

void UAnimNotify_LaunchProjectile::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{			
		if (!IsLocalControlledActor(Character))
		{
			return;
		}
		
		if (CameraShakeClass)
		{
			AP3PlayerController* Controller = Cast<AP3PlayerController>(Character->GetController());
			if (Controller)
			{
				Controller->ClientPlayCameraShake(CameraShakeClass);
			}
		}
		
		UP3CommandComponent* CommandComp = Character->GetCommandComponent();
		UP3ComboTableComponent* ComboComp = Character->GetComboComponent();

		if (!CommandComp || !ComboComp)
		{
			return;
		}				

		FP3CommandRequestParams CommandParams;
		CommandParams.LaunchProjectile_Location = ComboComp->GetLaunchLocation() + LaunchLocationOffset;
		CommandParams.LaunchProjectile_Rotation = ComboComp->GetAimRotation();
		CommandParams.LaunchProjectile_ConsumeStamina = ConsumeStamina;

		if (UsingAimRotationType == EP3UsingAimRotationType::UntilNotify)
		{
			CommandParams.LaunchProjectile_Rotation = ComboComp->GetAimRotation(CommandParams.LaunchProjectile_Location);
		}
		else if (UsingAimRotationType == EP3UsingAimRotationType::FixingAtStartingMontage)
		{
			CommandParams.LaunchProjectile_Rotation = ComboComp->GetAimingStartRotation();
		}

		CommandParams.LaunchProjectile_Rotation = CommandParams.LaunchProjectile_Rotation.RotateVector(LaunchDirection.GetSafeNormal()).ToOrientationRotator();

		if (ProjectileClass.Get())
		{
			CommandParams.LaunchProjectile_Class = ProjectileClass;		
		}
		else
		{
			// If projectile class is not set, get it from weapon

			AActor* WeaponActor = Character->GetRightHandWeaponActor();
			const FP3CmsHoldable* CmsHoldable = WeaponActor ? P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(WeaponActor->GetClass())) : nullptr;
			if (CmsHoldable)
			{
				CommandParams.LaunchProjectile_Class = CmsHoldable->ProjectileClass.LoadSynchronous();
			}
		}

		CommandComp->RequestCommand(UP3LaunchProjectileCommand::StaticClass(), CommandParams);
	}
}

void UAnimNotifyState_ShowProjectile::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		if (!P3Core::IsP3NetModeClientInstance(*Character))
		{
			return;
		}

		UP3CombatComponent* CombatComp = Character->GetP3CombatComponentBP();
		if (CombatComp)
		{
			CombatComp->Client_ShowProjectile(ProjectileClass, AttachBoneName, true);
		}
	}
}

void UAnimNotifyState_ShowProjectile::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		if (!P3Core::IsP3NetModeClientInstance(*Character))
		{
			return;
		}

		UP3CombatComponent* CombatComponent = Character->GetP3CombatComponentBP();
		if (CombatComponent)
		{
			CombatComponent->Client_ShowProjectile(ProjectileClass, AttachBoneName, false);
		}
	}
}

void UAnimNotifyState_StartBuff::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		if (!P3Core::IsP3NetModeServerInstance(*Character))
		{
			return;
		}

		UP3CharacterEffectComponent* EffectComp = Character->GetEffectComponent();
		if (EffectComp)
		{
			EffectComp->Server_AddBuff(CmsBuffKey, this);
		}
	}
}

void UAnimNotifyState_StartBuff::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;

	if (Character && P3Core::IsP3NetModeServerInstance(*Character))
	{
		const FP3CmsCharacterBuffRow* CharacterBuff = P3Cms::GetCharacterBuff(CmsBuffKey);
		if (!CharacterBuff)
		{
			return;
		}

		if (!CharacterBuff->bIsChanneling)
		{
			return;
		}

		UP3CharacterEffectComponent* EffectComp = Character->GetEffectComponent();
		if (EffectComp)
		{
			EffectComp->Server_RemoveBuffBySourceObject(this);
		}
	}
}

void UAnimNotifyState_ActivatePart::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character && P3Core::IsP3NetModeServerInstance(*Character))
	{
		TArray<UActorComponent*> PartComps = Character->GetComponentsByClass(UP3PartComponent::StaticClass());
		for (UActorComponent* ActorComp : PartComps)
		{
			UP3PartComponent* PartComponent = Cast<UP3PartComponent>(ActorComp);
			if (ensure(PartComponent))
			{
				if (ActivatePartNames.Contains(PartComponent->GetPartDesc().PartName))
				{
					PartComponent->Server_ActivatePart();
				}
			}
		}
	}
}

void UAnimNotifyState_ActivatePart::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character && P3Core::IsP3NetModeServerInstance(*Character))
	{
		TArray<UActorComponent*> PartComps = Character->GetComponentsByClass(UP3PartComponent::StaticClass());
		for (UActorComponent* ActorComp : PartComps)
		{
			UP3PartComponent* PartComponent = Cast<UP3PartComponent>(ActorComp);
			if (ensure(PartComponent))
			{
				if (ActivatePartNames.Contains(PartComponent->GetPartDesc().PartName))
				{
					PartComponent->Server_DeactivatePart();
				}
			}
		}
	}
}

void UAnimNotifyState_DeactivatePart::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character && P3Core::IsP3NetModeServerInstance(*Character))
	{
		TArray<UActorComponent*> PartComps = Character->GetComponentsByClass(UP3PartComponent::StaticClass());
		for (UActorComponent* ActorComp : PartComps)
		{
			UP3PartComponent* PartComponent = Cast<UP3PartComponent>(ActorComp);
			if (ensure(PartComponent))
			{
				if (DeactivatePartNames.Contains(PartComponent->GetPartDesc().PartName))
				{
					PartComponent->Server_DeactivatePart();
				}
			}
		}
	}
}

void UAnimNotifyState_DeactivatePart::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character && P3Core::IsP3NetModeServerInstance(*Character))
	{
		TArray<UActorComponent*> PartComps = Character->GetComponentsByClass(UP3PartComponent::StaticClass());
		for (UActorComponent* ActorComp : PartComps)
		{
			UP3PartComponent* PartComponent = Cast<UP3PartComponent>(ActorComp);
			if (ensure(PartComponent))
			{
				if (DeactivatePartNames.Contains(PartComponent->GetPartDesc().PartName))
				{
					PartComponent->Server_ActivatePart();
				}
			}
		}
	}
}

void UAnimNotifyState_BoneAttack::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	UP3CombatComponent* CombatComp = _GetCombatComponent(MeshComp);
	if (CombatComp)
	{
		CombatComp->OnAttackWithSkeletalMeshPhysicsBegin(BoneNames, this, Animation);
	}
}

void UAnimNotifyState_BoneAttack::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	UP3CombatComponent* CombatComp = _GetCombatComponent(MeshComp);
	if (CombatComp)
	{
		CombatComp->OnAttackWithSkeletalMeshPhysicsEnd(BoneNames, this, Animation);
	}
}

void UAnimNotifyState_ComboSignal::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetNotifyStateSignal(SignalName, true);
		}
	}
}

void UAnimNotifyState_ComboSignal::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetNotifyStateSignal(SignalName, false);
		}
	}
}

FString UAnimNotifyState_ComboSignal::GetNotifyName_Implementation() const
{
	return FString(TEXT("ComboSignal:")) + SignalName.ToString();
}

void UAnimNotifyState_MoveInputIgnore::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputMoveBlock(true);
		}
	}
}

void UAnimNotifyState_MoveInputIgnore::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputMoveBlock(false);
		}
	}
}

void UAnimNotifyState_TurnInputIgnore::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputTurnBlock(true);
		}
	}
}

void UAnimNotifyState_TurnInputIgnore::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputTurnBlock(false);
		}
	}
}

void UAnimNotifyState_CameraMoveInputIgnore::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputCameraMoveBlock(true);
		}
	}
}

void UAnimNotifyState_CameraMoveInputIgnore::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputCameraMoveBlock(false);
		}
	}
}

void UAnimNotifyState_InputStack::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputStackBlock(true);
		}
	}
}

void UAnimNotifyState_InputStack::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3ComboTableComponent* ComboTableComponent = Character->GetComboComponent();
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->SetInputStackBlock(false);
		}
	}
}

void UAnimNotifyState_ReactionLayerAnimation::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3CombatResponseComponent* CombatResponseComponent = Character->GetP3CombatResponseoComponent();
		if (ensure(CombatResponseComponent))
		{
			CombatResponseComponent->SetInProgressAnimationType(ReactionLayerAnimationType);
		}
	}
}

void UAnimNotifyState_ReactionLayerAnimation::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3CombatResponseComponent* CombatResponseComponent = Character->GetP3CombatResponseoComponent();
		if (ensure(CombatResponseComponent))
		{
			CombatResponseComponent->SetInProgressAnimationType(EP3ReactionLayerAnimationType::None);
		}
	}
}

void UAnimNotify_BlowHorn::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	if (!MeshComp || !P3Core::IsP3NetModeServerInstance(*MeshComp))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(MeshComp->GetOwner());
	if (!Character)
	{
		return;
	}

	const FVector CharacterLocation = Character->GetActorLocation();
	const float RadiusSquared = FMath::Square(Radius);

	// TODO: replace with something like Sweep?
	for (TActorIterator<AP3ReinforceSpawnerActor> Iter(Character->GetWorld()); Iter; ++Iter)
	{
		AP3ReinforceSpawnerActor* Spawner = *Iter;
		if (!Spawner)
		{
			continue;
		}

		const float DistanceSquared = (Spawner->GetActorLocation() - CharacterLocation).SizeSquared();

		if (DistanceSquared < RadiusSquared)
		{
			Spawner->Server_OnHornBlown(Character);
		}
	}
}

void UAnimNotifyState_CombatWeaponCollision::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);	

	if (!MeshComp)
	{
		return;
	}

	if (!P3Core::IsP3NetModeServerInstance(*MeshComp))
	{
		return;
	}	

	AP3Character* Character = Cast<AP3Character>(MeshComp->GetOwner());
	if (!Character)
	{
		return;
	}
	
	if (bActiveRightHand)
	{ 
		const AActor* RightHandWeaponActor = Character->GetHoldingActorByHoldType(EP3HoldType::RightHand);
		if (RightHandWeaponActor)
		{
			UP3CombatBoxComponent* CombatBoxComp = RightHandWeaponActor->FindComponentByClass<UP3CombatBoxComponent>();
			if (CombatBoxComp)
			{
				CombatBoxComp->ActivateCombatCollision(CmsCombatHitKey, Character, MaxOverlapCount, OverlapBufferClearTimeSeconds);
			}
		}

	}

	if (bActiveLeftHand)
	{
		const AActor* LeftHandWeaponActor = Character->GetHoldingActorByHoldType(EP3HoldType::LeftHand);
		if (LeftHandWeaponActor)
		{
			UP3CombatBoxComponent* CombatBoxComp = LeftHandWeaponActor->FindComponentByClass<UP3CombatBoxComponent>();
			if (CombatBoxComp)
			{
				CombatBoxComp->ActivateCombatCollision(CmsCombatHitKey, Character, MaxOverlapCount, OverlapBufferClearTimeSeconds);
			}
		}
	}		
}

void UAnimNotifyState_CombatWeaponCollision::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	if (!MeshComp)
	{
		return;
	}

	if (!P3Core::IsP3NetModeServerInstance(*MeshComp))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(MeshComp->GetOwner());
	if (!Character)
	{
		return;
	}	

	if (bActiveRightHand)
	{
		const AActor*RightHandWeaponActor = Character->GetHoldingActorByHoldType(EP3HoldType::RightHand);
		if (RightHandWeaponActor)
		{
			UP3CombatBoxComponent* CombatBoxComp = RightHandWeaponActor->FindComponentByClass<UP3CombatBoxComponent>();
			if (CombatBoxComp)
			{
				CombatBoxComp->DeactivateCombatCollision();
			}
		}
	}

	if (bActiveLeftHand)
	{
		const AActor* LeftHandWeaponActor = Character->GetHoldingActorByHoldType(EP3HoldType::LeftHand);
		if (LeftHandWeaponActor)
		{
			UP3CombatBoxComponent* CombatBoxComp = LeftHandWeaponActor->FindComponentByClass<UP3CombatBoxComponent>();
			if (CombatBoxComp)
			{
				CombatBoxComp->DeactivateCombatCollision();
			}
		}
	}	
}

void UAnimNotify_FootStep::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	if (!MeshComp)
	{
		return;
	}

	if (!MeshComp->HasBegunPlay())
	{
		return;
	}

	if (IsRunningDedicatedServer())
	{
		return;
	}
		
#if !UE_BUILD_SHIPPING
	if (Animation && !MeshComp->DoesSocketExist(SocketName))
	{
		P3JsonLog(Warning, "Invalid foot step socket",
			TEXT("Animation"), Animation->GetFName(),
			TEXT("SocketName"), SocketName);
	}
#endif

	const FVector SocketLocation = MeshComp->GetSocketLocation(SocketName);
	
	FCollisionQueryParams QueryParams;
	QueryParams.TraceTag = FName(TEXT("FootStep"));
	QueryParams.bReturnPhysicalMaterial = true;
	QueryParams.bIgnoreTouches = true;
	QueryParams.AddIgnoredActor(MeshComp->GetOwner());

	if (MeshComp->GetOwner())
	{
		TArray<AActor*> AttachedActors;
		MeshComp->GetOwner()->GetAttachedActors(AttachedActors);
		QueryParams.AddIgnoredActors(AttachedActors);
	}

	FHitResult HitResult;

	const bool bHit = MeshComp->GetWorld()->LineTraceSingleByChannel(HitResult, SocketLocation, SocketLocation + FVector(0, 0, -100), ECC_Pawn, QueryParams);

	if (bHit)
	{
		UPhysicalMaterial* PhysicalMaterial = HitResult.PhysMaterial.Get();

		if (PhysicalMaterial)
		{
			const UP3GameResource& Resource = P3Core::GetGameResource(MeshComp);

			// TODO: Cache this
			for (const FP3SurfaceEffect& SurfaceEffect : Resource.SurfaceEffects)
			{
				if (SurfaceEffect.SurfaceType != PhysicalMaterial->SurfaceType)
				{
					continue;
				}

				if (bAttachToSocket)
				{
					UParticleSystemComponent* ParticleComp = UGameplayStatics::SpawnEmitterAttached(SurfaceEffect.Particle, MeshComp, SocketName, AttachedTransform.GetLocation(), AttachedTransform.GetRotation().Rotator(), AttachedTransform.GetScale3D() * SurfaceEffect.ParticleScale * ParticleScale);
				}
				else
				{
					UParticleSystemComponent* ParticleComp = UGameplayStatics::SpawnEmitterAtLocation(MeshComp->GetWorld(), SurfaceEffect.Particle, HitResult.ImpactPoint, FRotator::ZeroRotator,
						FVector(SurfaceEffect.ParticleScale * ParticleScale));
				}

				//if (ParticleComp)
				//{
				//	// TODO ...
				//	//const static FName NAME_Velocity(TEXT("Velocity"));
				//	//ParticleComp->SetVectorParameter(NAME_Velocity, Socket.Velocity);
				//}
			}
		}
	}
}

void UAnimNotifyState_ReactionSignal::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3CombatResponseComponent* CombatResponseComponent = Character->GetP3CombatResponseoComponent();
		if (CombatResponseComponent)
		{
			CombatResponseComponent->SetNotifyStateSignal(SignalName, true);
		}
	}
}

void UAnimNotifyState_ReactionSignal::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		UP3CombatResponseComponent* CombatResponseComponent = Character->GetP3CombatResponseoComponent();
		if (CombatResponseComponent)
		{
			CombatResponseComponent->SetNotifyStateSignal(SignalName, false);
		}
	}
}

FString UAnimNotifyState_ReactionSignal::GetNotifyName_Implementation() const
{
	return FString(TEXT("ReactionSignal:")) + SignalName.ToString();
}

void UAnimNotify_CameraShake::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::Notify(MeshComp, Animation);

	if (!GIsClient)
	{
		return;
	}

	if (!MeshComp)
	{
		return;
	}	

	AP3Character* Character = Cast<AP3Character>(MeshComp->GetOwner());
	if (!Character)
	{
		return;
	}
	
	const FP3CmsCameraShakeRow* CmsCameraShakeRow = P3Cms::GetCameraShake(CmsCameraShakeKey);
	if (!CmsCameraShakeRow)
	{
		return;
	}

	APawn* LocalPawn = P3Core::GetLocalPawn(Character->GetWorld());
	if (!LocalPawn)
	{
		return;
	}

	float Distance = (Character->GetActorLocation() - LocalPawn->GetActorLocation()).Size();

	if (CmsCameraShakeRow->bStandaloneLocalPlay)
	{
		if (IsLocalControlledActor(Character))
		{			
			Character->Client_PlayCameraShake(CmsCameraShakeKey, Distance);
		}
	}
	else
	{	
		Character->Client_PlayCameraShake(CmsCameraShakeKey, Distance);
	}			
}

void UAnimNotifyState_StashWeapon::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;

	UP3HolderComponent* HolderComp = Character ? Character->GetHolderComponentByHoldType(HoldType) : nullptr;

	if (HolderComp)
	{
		HolderComp->Stash();
	}
}

void UAnimNotifyState_StashWeapon::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;

	UP3HolderComponent* HolderComp = Character ? Character->GetHolderComponentByHoldType(HoldType) : nullptr;

	if (HolderComp)
	{
		HolderComp->Hold();
	}
}

void UAnimNotifyState_AdaptedAttackMove::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		Character->OnActionAnimNotifyStateBegin.Broadcast(EActionAnimNotifyStateType::AdaptAttackMoveBegin, TotalDuration);
	}
}

void UAnimNotifyState_AdaptedAttackMove::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);

	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		Character->OnActionAnimNotifyStateEnd.Broadcast(EActionAnimNotifyStateType::AdaptAttaackMoveEnd);
	}
}

void UAnimNotify_AddBuff::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	AP3Character* Character = MeshComp ? Cast<AP3Character>(MeshComp->GetOwner()) : nullptr;
	if (Character)
	{
		if (!P3Core::IsP3NetModeServerInstance(*Character))
		{
			return;
		}

		UP3CharacterEffectComponent* EffectComp = Character->GetEffectComponent();
		if (EffectComp)
		{
			EffectComp->Server_AddBuff(CmsBuffKey, this);
		}
	}
}
