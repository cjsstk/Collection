// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ModuleManager.h"
#include "P3Version.h"

class FP3GameModule : public FDefaultGameModuleImpl
{
public:
	static FP3GameModule* Get() { return GameModule; }

	virtual void StartupModule() override;
	virtual void PostLoadCallback() override;
	virtual void ShutdownModule() override;

	const FP3Version& GetVersion() const { return Version; }

private:
	void OnConsoleCommandCrash(const TArray<FString>& Args);

	void LoadStringTables();
	void ReleaseStringTables();

	static FP3GameModule* GameModule;

	FP3Version Version;
	IConsoleCommand* ConsoleCommandCrash = nullptr;
	TArray<FString> StringTableIds;
};
