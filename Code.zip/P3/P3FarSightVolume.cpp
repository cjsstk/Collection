// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3FarSightVolume.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"

void AP3FarSightVolume::NotifyActorBeginOverlap(class AActor* OtherActor)
{
	Super::NotifyActorBeginOverlap(OtherActor);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(OtherActor);

		if (Character && Character->GetEffectComponent())
		{
			Character->GetEffectComponent()->Server_AddEffect(EP3CharacterEffectTypes::FarSight, *this);
		}
	}
}

void AP3FarSightVolume::NotifyActorEndOverlap(class AActor* OtherActor)
{
	Super::NotifyActorEndOverlap(OtherActor);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(OtherActor);

		if (Character && Character->GetEffectComponent())
		{
			Character->GetEffectComponent()->Server_RemoveEffect(EP3CharacterEffectTypes::FarSight, *this);
		}
	}
}
