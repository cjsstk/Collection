// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "Network/Lib/P3NetCore.h"

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/game.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/game.pb.h"
#endif

#include "Network/P3DedimanHelper.h"
#include "P3ClientPlayer.h"
#include "P3WorldNetCore.h"
#include "Party/P3Party.h"

#include "P3ClientWorld.generated.h"

using ProtobufMessage = ::google::protobuf::Message;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3ClientWorldPlayersListChanged);

DECLARE_MULTICAST_DELEGATE_OneParam(FP3PlayerCharacterListOnLoad, const FP3ClientPlayerCharacters&);
DECLARE_MULTICAST_DELEGATE_OneParam(FP3PartyMembersOnAddOrRemove, const FP3PartyMembers&);

UENUM()
enum class EDediConnectionState
{
	Initial,
	MapLoading, // Will connect server after loading
	Connecting,
	Connected,
	WaitDediInfo, // Will connect server after getting server info
	Closing,
	Closed,
};

USTRUCT()
struct FP3NetClientPlayers
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FP3ClientPlayer> Players;
};

UCLASS(BlueprintType)
class UP3ClientWorld : public UObject
{
	GENERATED_BODY()

public:
	void BeginPlay(class UP3World* InP3World);
	void Shutdown();

	void Tick(float DeltaSeconds);

	void InitConsoleCommands();
	void CleanupConsoleCommands();

	void OnConnected();
	void OnConnectFailed();
	void OnDisconnected();

	const uint32 GetZoneChannelId() const { return ZoneChannelId; }

	UFUNCTION(BlueprintCallable)
	const TArray<FP3ClientPlayer>& GetPlayers() const { return Players; }

	class AP3Character* FindPlayerCharacterByName(const FText& Name) const;

	UFUNCTION(BlueprintCallable)
	void ChangeWorld(const FString& LevelName);

	void StartZoneAutoChange() { bZoneAutoChange = true; }
	void StopZoneAutoChange() { bZoneAutoChange = false; }

	bool SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const;
	void HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header);
	void SendWorldRelayMessage(enum pb::C2DWorldRelayMessageType RelayMessageType, const ProtobufMessage& RelayMessage);

	void ForeachProfileResult(int32 ProfileIndex, TFunctionRef<bool(const FString& FunctionName, int32 PacketCount, float DurationSeconds)> Func);

	void SpawnActor(const FP3NetSpawnActorParams& Params);
	void DestroyActor(actorid ActorId);

	/**
	 * Packet handlers
	 */
	UFUNCTION()
	void HandleEnterResponse(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void HandleEnterFailResponse(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void HandlePlayerList(const struct FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void HandleSpawnActor(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void HandleDestroyActor(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void HandleSyncActorStore(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void HandleActorSyncEnd(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void HandleSyncActorTransform(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleSyncActorComponentTransform(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleSyncActorMovement(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleCharacterMovement(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleAnimalMovement(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleDamageFoliage(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleDamageNonCommandActor(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleToastMessage(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleSyncTimeOfDay(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleDebugDraw(const FP3DediToClientHandlerParams& Params);

	// handle world message
	void HandleWorldMessage(const pb::D2CWorldMessage& WorldMessage);
	void HandleWorldMessagePlayerList(const pb::D2CWorldRelayMessage& WorldRelayMessage);
	void HandleWorldMessagePartyInvitation(const pb::D2CWorldRelayMessage& WorldRelayMessage);
	void HandleWorldMessagePartyMembersJoin(const pb::D2CWorldRelayMessage& WorldRelayMessage);
	void HandleWorldMessagePartyMembersLeave(const pb::D2CWorldRelayMessage& WorldRelayMessage);
	void HandleWorldMessagePartyLeaveRes(const pb::D2CWorldRelayMessage& WorldRelayMessage);

	FP3ClientWorldPlayersListChanged OnPlayersListChanged;

	FP3PlayerCharacterListOnLoad OnLoadPlayerCharList;
	FP3PartyMembersOnAddOrRemove OnAddOrRemovePartyMembers;

private:	
	void SyncActorTransform(AActor* Actor, const FP3NetActorTransform& NetTransform);
	void SendMovement();
	void TickActorDebug();

	void SetDediConnectionState(EDediConnectionState State);
	bool UpdateCurrentTileZoneNames();

	void TickDediConnectionState();
	void TickDediConnectionStateMapLoading();
	void TickDediConnectionStateConnected();
	void TickDediConnectionStateClosed();
	void DisconnectFromDedi();

	void TickBGM();

	void FlushZoneChangeTicks();

	bool IsSequencePossessedObject(const UObject& Object) const;

	void OnActorAdded(AActor* Actor);
	void OnActorRemoved(AActor* Actor);

	UFUNCTION()
	void OnDediInfo(const FP3DediInfoResponse& Response, bool bWasSuccessful);

	UFUNCTION()
	void OnHUDPostRender(class AHUD* HUD, class UCanvas* Canvas);

	UPROPERTY(Transient)
	class UP3World* P3World;

	uint32 ZoneChannelId = 0;

	TArray<FP3ClientPlayer> Players;

	actorid MyCharacterActorId = INVALID_ACTORID;
	FP3NetConnInfo EnterNetConnInfo;
	float LastActorSyncedTimeSeconds = 0;

	/** Client own actors. Only valid before enter world */
	UPROPERTY(Transient)
	TMap<int64, AActor*> TemporalOwnActors;

	UPROPERTY(Transient)
	TArray<class AP3Character*> CharacterActors;
	
	/**
	 * Console commands
	 */

	/** Control dedicated server connection by current location */
	EDediConnectionState DediConnectionState = EDediConnectionState::Initial;
	TArray<FName> CurrentTileZoneNames;
	bool bZoneAutoChange = true;
	float LastEnterWorldFailTimeSeconds = 0.0f;

	/**
	 * 월드 변경 프로세스
	 */
	struct FChangeWorld
	{
		enum class EStatus
		{
			None,
			ClosingDediNet,
			LoadingLevel
		};

		EStatus Status = EStatus::None;
		FString NewLevelName;
	};
	FChangeWorld ChangeWorldProgress;

	/**
	 * Packet profiles
	 */
	mutable FP3WorldPacketProfile PacketProfileHistory;
	FP3WorldPacketProfile PacketProfileResult;
	float PacketProfileWritingSeconds = 0;

	/**
	 * 데디 서버에 연결이 되었던 횟수
	 * 로비에서 TickDediConnectionStateClosed 체크를 회피하기 위한 변수
	 */
	uint32 DediConnectedCount = 0;
};
