// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3SpawnerActor.h"

#include "Components/BillboardComponent.h"
#include "Components/DrawSphereComponent.h"
#include "Engine/CollisionProfile.h"

#include "AI/P3AIController.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3PointOfInterest.h"
#include "P3SpawnerComponent.h"

#if WITH_EDITORONLY_DATA
#include "UObject/ConstructorHelpers.h"
#endif

AP3PawnSpawnerActor::AP3PawnSpawnerActor()
{
	bNetLoadOnClient = false;

	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("SceneComponent"));
	SceneComponent->bVisible = true;
	RootComponent = SceneComponent;
	
#if UE_EDITOR
	PreviewSphereComponent = CreateDefaultSubobject<UDrawSphereComponent>(TEXT("PreviewSphereComponent"));
	PreviewSphereComponent->bDrawOnlyIfSelected = true;
	PreviewSphereComponent->bUseEditorCompositing = true;
	PreviewSphereComponent->SetCollisionProfileName(UCollisionProfile::NoCollision_ProfileName);
	PreviewSphereComponent->SetupAttachment(SceneComponent);
#endif


#if WITH_EDITORONLY_DATA
	ArrowComponent = CreateEditorOnlyDefaultSubobject<UArrowComponent>(TEXT("Arrow"));

	if (!IsRunningCommandlet())
	{
		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			FName ID_Navigation;
			FText NAME_Navigation;
			FConstructorStatics()
				: ID_Navigation(TEXT("Navigation"))
				, NAME_Navigation(FText::AsCultureInvariant("Navigation"))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (ArrowComponent)
		{
			ArrowComponent->ArrowColor = FColor(150, 200, 255);
			ArrowComponent->ArrowSize = 1.0f;
			ArrowComponent->bTreatAsASprite = true;
			ArrowComponent->SpriteInfo.Category = ConstructorStatics.ID_Navigation;
			ArrowComponent->SpriteInfo.DisplayName = ConstructorStatics.NAME_Navigation;
			ArrowComponent->SetupAttachment(SceneComponent);
			ArrowComponent->bIsScreenSizeScaled = true;
		}
	}

	EditorSprite = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("EditorSprite"));

	if (!IsRunningCommandlet())
	{
		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> SpriteTextureObject;
			FConstructorStatics()
				: SpriteTextureObject(TEXT("/Engine/EditorResources/Ai_Spawnpoint"))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (EditorSprite)
		{
			EditorSprite->Sprite = ConstructorStatics.SpriteTextureObject.Get();
			EditorSprite->RelativeScale3D = FVector(1.0f);
			EditorSprite->bHiddenInGame = true;
			EditorSprite->SetupAttachment(SceneComponent);
			EditorSprite->bAbsoluteScale = true;
			EditorSprite->bIsScreenSizeScaled = true;
		}
	}

#endif // WITH_EDITORONLY_DATA
	 
	SpawnerComponent = CreateDefaultSubobject<UP3SpawnerComponent>(TEXT("SpawnerComponent"));
	SpawnerComponent->SetupAttachment(SceneComponent);

#if WITH_EDITOR
	FCoreUObjectDelegates::OnObjectPropertyChanged.AddUObject(this, &AP3PawnSpawnerActor::OnSpawnerValueChanged);
#endif
}

#if UE_EDITOR
void AP3PawnSpawnerActor::PostLoad()
{
	Super::PostLoad();

	if (PreviewSphereComponent && SpawnerComponent)
	{
		PreviewSphereComponent->SetSphereRadius(SpawnerComponent->GetRandom2DRadius());
	}

	if (SpawnerComponent)
	{
		// Temp hot fix
		// Spawner component's relative location is exactly opposite of actor location, this is due to code error(not attach to root)
		SpawnerComponent->SetRelativeTransform(FTransform::Identity);
	}
}
#endif


void AP3PawnSpawnerActor::ConvertSpawnerActorToTargetActor()
{
#if UE_EDITOR
	UClass* ActorClass = SpawnerComponent->GetSpawnActorClass().Get();
	if (ActorClass)
	{
		FActorSpawnParameters Params;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		const FTransform Transform = GetActorTransform();

		GetWorld()->SpawnActor(ActorClass, &Transform, Params);

		Destroy(true);
	}
#endif
}

void AP3PawnSpawnerActor::BeginPlay()
{
	if (SpawnerComponent)
	{
		SpawnerComponent->OnSpawn.AddUniqueDynamic(this, &AP3PawnSpawnerActor::OnSpawn);

		// Temp hot fix
		// Spawner component's relative location is exactly opposite of actor location, this is due to code error(not attach to root)
		SpawnerComponent->SetRelativeTransform(FTransform::Identity);
	}

	Super::BeginPlay();
}

void AP3PawnSpawnerActor::Reset()
{
	Super::Reset();

	SpawnerComponent->ResetSpawnerComponent();
}

void AP3PawnSpawnerActor::AddPointOfInterest(class AP3PointOfInterest* POI)
{
	RandomPointOfInterests.Add(POI);
}

void AP3PawnSpawnerActor::ClearPointOfInterests()
{
	RandomPointOfInterests.Empty();
}

void AP3PawnSpawnerActor::OnSpawnerValueChanged(UObject* Object, FPropertyChangedEvent& PropertyChangedEvent)
{
	if (Object == SpawnerComponent)
	{
		if (PreviewSphereComponent)
		{
			PreviewSphereComponent->SetSphereRadius(SpawnerComponent->GetRandom2DRadius());
		}
	}
}

void AP3PawnSpawnerActor::OnSpawn(class UP3SpawnerComponent* InSpawnerComponent, AActor* SpawnedActor)
{
	APawn* SpawnedPawn = Cast<APawn>(SpawnedActor);
	AP3AIController* AIController = SpawnedPawn ? Cast<AP3AIController>(SpawnedPawn->GetController()) : nullptr;

	if (AIController)
	{
		if (RandomPointOfInterests.Num() > 0)
		{
			const int32 RandomIndex = FMath::Rand() % RandomPointOfInterests.Num();
			AIController->SetPointOfInterest(RandomPointOfInterests[RandomIndex]);
		}

		AIController->SetRouteList(RouteList);
		AIController->SetEmoteAnimName(InitialEmoteName);

		if (OverrideBehaviorTree)
		{
			AIController->RunBehaviorTree(OverrideBehaviorTree);
		}
	}
}


AP3ReinforceSpawnerActor::AP3ReinforceSpawnerActor()
{
	PrimaryActorTick.bCanEverTick = false;

	if (GetSpawnerComponent())
	{
		GetSpawnerComponent()->SetAutoActivate(false);
	}
}

void AP3ReinforceSpawnerActor::BeginPlay()
{
	Super::BeginPlay();
	
}

void AP3ReinforceSpawnerActor::Server_OnHornBlown(class AP3Character* Character)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!GetSpawnerComponent())
	{
		return;
	}

	ClearPointOfInterests();

	if (Character)
	{
		FActorSpawnParameters POISpawnParams;
		POISpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

		AP3PointOfInterest* POI = GetWorld()->SpawnActor<AP3PointOfInterest>(Character->GetActorLocation(), FRotator::ZeroRotator, POISpawnParams);

		if (ensure(POI))
		{
			// Since default lifespan of POI is short, let it stay little bit longer
			POI->SetLifeSpan(30);

			AddPointOfInterest(POI);
		}
	}

	GetSpawnerComponent()->Activate();
}
