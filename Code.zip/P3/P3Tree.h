// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3ActorInterface.h"
#include "P3Tree.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3TreeOnDropFruit);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3TreeOnCutdownedTrunkHitGround);

UCLASS()
class P3_API AP3Tree : public AP3Actor
{
	GENERATED_BODY()
	
public:
	AP3Tree();

	virtual void PostActorCreated() override;
	virtual void OnConstruction(const FTransform& Transform) override;
	virtual void PreInitializeComponents() override;
	virtual void BeginPlay() override;
	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser) override;
	virtual void NetSerialize(FArchive& Archive) override;

	bool IsCutDowned() const { return Net_bCutDowned; }
	void Server_SleepTree(bool bNewSleep);

protected:
	virtual void Tick(float DeltaTime) override;
	virtual void Client_OnEvent(FName EventName, int32 Param) override;

private:
	UFUNCTION()
	void Server_OnHealthPointComponentDead();

	/** Process cut down. Let trunk mesh fell down */
	void CutDown();
	
	UFUNCTION()
	void Server_OnTrunkMeshHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);

	/** Change trunk to destructible, if assigned */
	void FractureDestructibleTrunk();

	UFUNCTION()
	void DropLeaves();

	UFUNCTION()
	void DestroyLeaves();

	void DestroyTrunkMesh();

	void ApplyDynamicMaterialRandomInstanceId();
	void UpdateBurntDynamicMaterial();

	void SleepChanged();

public:
	FP3TreeOnDropFruit OnTreeDropFruit;

	UPROPERTY(BlueprintAssignable)
	FP3TreeOnCutdownedTrunkHitGround OnCutdownedTrunkHitGround;

private:
	UPROPERTY(VisibleDefaultsOnly)
	class UP3HealthPointComponent* HealthPointComponent;

	UPROPERTY(VisibleDefaultsOnly)
	class UStaticMeshComponent* RootMeshComponent;

	UPROPERTY(VisibleDefaultsOnly)
	class UStaticMeshComponent* TrunkMeshComponent;

	UPROPERTY(VisibleDefaultsOnly)
	class UStaticMeshComponent* TrunkLeavesMeshComponent;

	UPROPERTY(VisibleDefaultsOnly)
	class UP3LootDropComponent* LootDropComponent;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	TArray<class UStaticMesh*> ChoppingPartMeshes;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	class UMaterialInterface* ChoppingPartMaterial;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	class UDestructibleMesh* TrunkDestructableMesh;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	class UParticleSystem* ChoppingParticle;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float ChoppingParticleZOffset = 100.0f;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FVector ChoppingParticleScale = FVector::OneVector;

	/** 
	 * (optional) If set, this mesh will replace Trunk Mesh Component
	 * Use this as simpler mesh when default trunk mesh is too complex 
	 */
	UPROPERTY(EditDefaultsOnly, Category = "Cutdown")
	class UParticleSystem* CutDownParticle;

	UPROPERTY(EditDefaultsOnly, Category = "Cutdown")
	FVector CutDownParticleScale = FVector::OneVector;

	UPROPERTY(EditDefaultsOnly, Category = "Cutdown")
	class UStaticMesh* CutDownedTrunkMesh;

	/** Set how long artificial torque will be applied towards impulse direction after cut-down */
	UPROPERTY(EditDefaultsOnly, Category = "Cutdown")
	float AfterCutdownTorqueTimeSeconds = 3.0f;

	/** If set higher, cut-downed trunk will rotate towards impulse direction more quickly */
	UPROPERTY(EditDefaultsOnly, Category = "Cutdown")
	float AfterCutdownTorqueStrength = 0.5f;

	/** Set falling speed of leave mesh after cutdown */
	UPROPERTY(EditDefaultsOnly, Category = "Cutdown")
	float AfterCutdownLeavesDropSpeed = 500.0f;

	/** Speed of burnt ratio material effect */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float BurntMaterialEffectSpeed = 0.02f;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float LeavesBurntMaterialEffectDelaySeconds = 5.0f;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float LeavesBurntMaterialEffectSpeed = 0.5f;

	/** If set true, root mesh's collision will be disabled after cut down. This helps player's movement */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bDisableRootMeshPawnCollisionAfterCutdown = false;

	UPROPERTY(Transient)
	TArray<class UStaticMeshComponent*> ChoppingPartMeshComponents;

	UPROPERTY(Transient)
	class UP3FlammableComponent* FlammableComponent;

	UPROPERTY(Transient)
	class ADestructibleActor* TrunkDestructibleActor;

	TArray<int32> Net_ChoppedParts;
	FVector Net_ChopImpulseDirection = FVector::ZeroVector;
	bool Net_bCutDowned = false;
	bool Net_bTrunkFractured = false;
	bool Net_bLootDropped = false;
	bool Net_bTreeSleep = false;

	/** When cut-down happens? */
	float CutDownedTimeSeconds = 0;

	bool bDroppingLeaves = false;

	float BurningAgeSeconds = 0.0f;

	/** 트렁크 파괴, 디스트럭터블 생성 지연 ( PG_PrePhysics 틱에 수행하기 위해 ) */
	bool bPendingToReplaceTrunk = false;
};
