// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CharacterEffectComponent.h"

#include "DrawDebugHelpers.h"

#include "Action/P3PawnActionComponent.h"
#include "Chemical/P3Chemical.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3Combat.h"
#include "P3Core.h"
#include "P3GameState.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3StaminaPointComponent.h"
#include "P3World.h"


static TAutoConsoleVariable<int32> CVarP3BuffDebug(
	TEXT("p3.buffDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ScareDebug(
	TEXT("p3.scareDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);


UP3CharacterEffectComponent::UP3CharacterEffectComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	Server_Effects.AddDefaulted((int32)EP3CharacterEffectTypes::Count);
	MoveSpeedEffects.AddDefaulted((int32)EP3MoveSpeedEffectLayer::Count);
	Server_OverlappableBuffs.AddDefaulted((int32)EP3OverappableBuffType::Count);
}

void UP3CharacterEffectComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_TickExpireBuffs();
		Server_TickApplyBuffs(DeltaTime);
		Server_UpdateOverlappable();
	}

	if (CVarP3BuffDebug.GetValueOnGameThread() > 0)
	{
		const float Now = GetWorld()->GetTimeSeconds();

		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (ensure(Character))
		{
			for (const FP3CharacterBuff& Buff : Net_CharacterBuffs.CharacterBuffs)
			{
				FString DebugString = FString::Printf(TEXT("%s(%s)")
					, *Buff.CmsCharacterBuff.BuffName.ToString()
					, *EnumToStringShort(EP3CharacterBuffImplType, Buff.CmsCharacterBuff.BuffImplType));

				if (P3Core::IsP3NetModeServerInstance(*this))
				{
					DebugString += FString::Printf(TEXT(", Duration: %.2f/%.2f, Interval: %.2f")
						, Buff.ExpireAtTimeSeconds < 0 ? -1.0f : Buff.ExpireAtTimeSeconds - Now
						, Buff.CmsCharacterBuff.BuffDuration
						, Buff.LeftIntervalTimeSeconds);
				}
				Character->AddDebugString(DebugString);
			}

			for (auto&& Iter : Net_OverlappableBuffEffectiveLevels)
			{
				const EP3OverappableBuffType OverlappableBuffType = Iter.Key;

				FString DebugString = FString::Printf(TEXT("%s: %d"),
					*EnumToStringShort(EP3OverappableBuffType, OverlappableBuffType), Iter.Value);

				Character->AddDebugString(DebugString);
			}
		}
	}

	if (CVarP3ScareDebug.GetValueOnGameThread() > 0)
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			AP3Character* Character = Cast<AP3Character>(GetOwner());
			if (ensure(Character))
			{
				for (int32 Index = 0; Index < Server_OverlappableBuffs.Num(); ++Index)
				{
					const EP3OverappableBuffType OverlappableBuffType = EP3OverappableBuffType(Index);

					FOverlappableBuff& OverlappableBuff = Server_OverlappableBuffs[Index];

					if (OverlappableBuff.BaseLevel > 0)
					{
						FString DebugString = FString::Printf(TEXT("%s: %d (Own: %d, Overlap: %d)"),
							*EnumToStringShort(EP3OverappableBuffType, OverlappableBuffType),
							OverlappableBuff.BaseLevel + OverlappableBuff.OverlappedLevel,
							OverlappableBuff.BaseLevel, OverlappableBuff.OverlappedLevel);

						Character->AddDebugString(DebugString);

						DrawDebugSphere(GetWorld(), Character->GetActorLocation(), OverlappableBuff.EffectRadius, 32, FColor::Red);
						DrawDebugSphere(GetWorld(), Character->GetActorLocation(), OverlappableBuff.OverlapRadius, 32, FColor::Green);
					}
				}
			}
		}
	}
}

void UP3CharacterEffectComponent::Server_AddEffect(EP3CharacterEffectTypes EffectType, UObject& SourceObject)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	if (Character && Character->GetCharacterStoreBP().bGodMode)
	{
		return;
	}

	if (!ensure(Server_Effects.IsValidIndex((int32)EffectType)))
	{
		return;
	}

	TArray<FP3CharacterEffectInstance>& EffectInstances = Server_Effects[(int32)EffectType];

	FP3CharacterEffectInstance* AlreadyExistedInstance = EffectInstances.FindByPredicate([&SourceObject](const FP3CharacterEffectInstance& Instance) -> bool {
		return (Instance.SourceObject.Get() == &SourceObject);
	});

	if (AlreadyExistedInstance)
	{
		ensure(0);
		P3JsonLog(Warning, "Character effect is added but already exists",
			TEXT("EffectType"), EnumToStringShort(EP3CharacterEffectTypes, EffectType),
			TEXT("Source"), SourceObject.GetName());
		return;
	}

	FP3CharacterEffectInstance NewInstance;
	NewInstance.SourceObject = &SourceObject;
	EffectInstances.Add(NewInstance);

	if (EffectType == EP3CharacterEffectTypes::RoarStun)
	{
		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		if (ActionComp)
		{
			ActionComp->StartAction(EPawnActionType::RoarStun, _FUNCTION_TEXT);
		}
	}

	Server_UpdateNetEffects();
}

void UP3CharacterEffectComponent::Server_RemoveEffect(EP3CharacterEffectTypes EffectType, UObject& SourceObject)
{
	if (!ensure(Server_Effects.IsValidIndex((int32)EffectType)))
	{
		return;
	}

	TArray<FP3CharacterEffectInstance>& EffectInstances = Server_Effects[(int32)EffectType];

	const int32 NumRemoved = EffectInstances.RemoveAll([&SourceObject](const FP3CharacterEffectInstance& Instance) -> bool {
		return (Instance.SourceObject.Get() == &SourceObject);
	});

	if (NumRemoved > 0)
	{
		Server_UpdateNetEffects();
	}

	if (NumRemoved == 0)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		ensure(Character && Character->GetCharacterStoreBP().bGodMode);
	}
}

bool UP3CharacterEffectComponent::HasEffect(EP3CharacterEffectTypes EffectType) const
{
	return Net_Effects.Contains(EffectType);
}

bool UP3CharacterEffectComponent::HasStunEffect() const
{
	return HasEffect(EP3CharacterEffectTypes::Entangle) || HasEffect(EP3CharacterEffectTypes::RoarStun) || HasEffect(EP3CharacterEffectTypes::Stun);
}

int32 UP3CharacterEffectComponent::Server_AddBuff(const int32 BuffKey, UObject* SourceObject)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return -1;
	}

	if (!ensure(GetWorld()))
	{
		return -1;
	}

	const FP3CmsCharacterBuffRow* CmsCharacterBuff = P3Cms::GetCharacterBuff(BuffKey);
	if (!ensure(CmsCharacterBuff))
	{
		return -1;
	}

	const float Now = GetWorld()->GetTimeSeconds();

	FP3CharacterBuff CharacterBuff;
	CharacterBuff.Server_SourceObject = SourceObject;
	CharacterBuff.GenerateID = Server_NextBuffId;
	CharacterBuff.BuffKey = BuffKey;
	CharacterBuff.CmsCharacterBuff = *CmsCharacterBuff;
	CharacterBuff.ExpireAtTimeSeconds = (CmsCharacterBuff->BuffDuration <= 0.0f) ? -1.0f : Now + CmsCharacterBuff->BuffDuration;

	switch (CharacterBuff.CmsCharacterBuff.BuffImplType)
	{
	case EP3CharacterBuffImplType::None:
		break;

	case EP3CharacterBuffImplType::DamageOverTime:
	{
		const FP3CmsDamageOverTimeBuffImplRow* CmsDamageOverTimeBuff = P3Cms::GetDamageOverTimeBuffImpl(CharacterBuff.CmsCharacterBuff.BuffImpleKey);
		if (ensure(CmsDamageOverTimeBuff))
		{
			CharacterBuff.LeftIntervalTimeSeconds = CmsDamageOverTimeBuff->IntervalTimeSeconds;
		}
		break;
	}
	case EP3CharacterBuffImplType::HealOverTime:
	{
		const FP3CmsHealOverTimeBuffImplRow* CmsHealOverTimeBuff = P3Cms::GetHealOverTimeBuffImpl(CharacterBuff.CmsCharacterBuff.BuffImpleKey);
		if (ensure(CmsHealOverTimeBuff))
		{
			CharacterBuff.LeftIntervalTimeSeconds = CmsHealOverTimeBuff->HealIntervalTimeSeconds;
		}
		break;
	}
	case EP3CharacterBuffImplType::AttributeModifier:
		break;
	case EP3CharacterBuffImplType::RegenStamina:
	{
		const FP3CmsRegenStaminaBuffImplRow* CmsRegenStaminaBuff = P3Cms::GetRegenStaminaBuffImpl(CharacterBuff.CmsCharacterBuff.BuffImpleKey);
		if (ensure(CmsRegenStaminaBuff))
		{
			CharacterBuff.LeftIntervalTimeSeconds = CmsRegenStaminaBuff->RegenIntervalTimeSeconds;
		}
		break;
	}
	case EP3CharacterBuffImplType::Overlappable:
	{
		const FP3CmsOverlappableBuffImplRow* CmsOverlappableBuff = P3Cms::GetOverlappableBuffImpl(CharacterBuff.CmsCharacterBuff.BuffImpleKey);
		if (ensure(CmsOverlappableBuff))
		{
			CharacterBuff.OverlappableBuffType = CmsOverlappableBuff->OverlappableBuffType;
			CharacterBuff.BaseLevel = CmsOverlappableBuff->BaseLevel;
			CharacterBuff.EffectRadius = CmsOverlappableBuff->EffectRadius;
			CharacterBuff.OverlappableRadius = CmsOverlappableBuff->OverlapRadius;
		}
		break;
	}
	case EP3CharacterBuffImplType::Provoke:
	{
		const FP3CmsProvokeBuffImplRow* CmsTemptationBuff = P3Cms::GetProvokeBuffImpl(CharacterBuff.CmsCharacterBuff.BuffImpleKey);
		if (ensure(CmsTemptationBuff))
		{
			CharacterBuff.ProvokeLevel = CmsTemptationBuff->ProvokeLevel;
		}
		break;
	}
	case EP3CharacterBuffImplType::Reaction:
	{
		const FP3CmsReactionBuffImplRow* CmsReactionBuff = P3Cms::GetReactionBuffImpl(CharacterBuff.CmsCharacterBuff.BuffImpleKey);
		if (ensure(CmsReactionBuff))
		{			
			CharacterBuff.bCanReaction = CmsReactionBuff->bCanReaction;
			CharacterBuff.bCanDamage = CmsReactionBuff->bCanDamage;
			CharacterBuff.OverrideReactionLayer = CmsReactionBuff->OverrideReactionLayer;
			CharacterBuff.OverrideAttackDirection = CmsReactionBuff->OverrideAttackDirection;
			CharacterBuff.OverrideAttackStrength = CmsReactionBuff->OverrideAttackStrength;
		}
		break;
	}
	case EP3CharacterBuffImplType::SummonActor:
	{
		const FP3CmsSummonBuffImplRow* CmsSummonBuff = P3Cms::GetSummonBuffImpl(CharacterBuff.CmsCharacterBuff.BuffImpleKey);
		if (ensure(CmsSummonBuff))
		{
			if (CmsSummonBuff->ActorClass.LoadSynchronous())
			{
				FActorSpawnParameters SpawnParams;
				SpawnParams.Instigator = Cast<APawn>(GetOwner());
				SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

				AActor* SpawnedActor = GetWorld()->SpawnActor<AActor>(CmsSummonBuff->ActorClass.Get(), GetOwner()->GetActorLocation(), GetOwner()->GetActorRotation(), SpawnParams);

				if (ensure(SpawnedActor))
				{
					CharacterBuff.Server_SummonedActor = SpawnedActor;
				}
			}
		}
		break;
	}
	default:
		ensure(0);
		break;
	}

	Net_CharacterBuffs.CharacterBuffs.Add(CharacterBuff);

	UP3AttributesComponent* AttributeComp = GetOwner()->FindComponentByClass<UP3AttributesComponent>();
	if (AttributeComp)
	{
		AttributeComp->UpdateAttributes();
	}

	Server_NextBuffId = (Server_NextBuffId == MAX_int32) ? 1 : (Server_NextBuffId + 1);

	Server_SetDirty(*this);

	return CharacterBuff.GenerateID; 
}

bool UP3CharacterEffectComponent::HasBuffByBuffKey(int32 BuffKey) const
{
	for (const FP3CharacterBuff& Buff : Net_CharacterBuffs.CharacterBuffs)
	{
		if (Buff.BuffKey == BuffKey)
		{
			return true;
		}
	}

	return false;
}

void UP3CharacterEffectComponent::Server_RemoveBuff(const int32 GenerateID)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	int32 NumRemoved = 0;

	for (int32 Index = 0; Index < Net_CharacterBuffs.CharacterBuffs.Num(); ++Index)
	{
		FP3CharacterBuff& Buff = Net_CharacterBuffs.CharacterBuffs[Index];

		if (Buff.GenerateID == GenerateID)
		{
			Server_OnBuffRemoved(Buff);

			Net_CharacterBuffs.CharacterBuffs.RemoveAt(Index);
			--Index;

			++NumRemoved;
		}
	}

	ensure(NumRemoved > 0);

	if (NumRemoved > 0 && P3Core::GetP3World(*this))
	{
		UP3AttributesComponent* AttributeComp = GetOwner()->FindComponentByClass<UP3AttributesComponent>();
		if (AttributeComp)
		{
			AttributeComp->UpdateAttributes();
		}

		Server_SetDirty(*this);
	}
}

void UP3CharacterEffectComponent::Server_RemoveBuffBySourceObject(UObject* SourceObject)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(SourceObject))
	{
		return;
	}

	TArray<int32> FoundBuffIds;

	for (const FP3CharacterBuff& Buff : Net_CharacterBuffs.CharacterBuffs)
	{
		if (Buff.Server_SourceObject.Get() == SourceObject)
		{
			FoundBuffIds.Add(Buff.GenerateID);
		}
	}

	ensure(FoundBuffIds.Num() > 0);

	for (int32 BuffId : FoundBuffIds)
	{
		Server_RemoveBuff(BuffId);
	}
}

const TArray<FP3CharacterBuff>& UP3CharacterEffectComponent::GetBuffs()
{
	return Net_CharacterBuffs.CharacterBuffs;
}

int32 UP3CharacterEffectComponent::Server_GetOverlappableBuffBaseLevel(EP3OverappableBuffType OverlappableBuffType) const
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return 0;
	}

	const int32 Index = static_cast<int32>(OverlappableBuffType);

	if (ensure(Server_OverlappableBuffs.IsValidIndex(Index)))
	{
		return Server_OverlappableBuffs[Index].BaseLevel;
	}

	return 0;
}

float UP3CharacterEffectComponent::Server_GetOverlappableBuffOverlapRadius(EP3OverappableBuffType OverlappableBuffType) const
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return 0;
	}

	const int32 Index = static_cast<int32>(OverlappableBuffType);

	if (ensure(Server_OverlappableBuffs.IsValidIndex(Index)))
	{
		return Server_OverlappableBuffs[Index].OverlapRadius;
	}

	return 0;
}

int32 UP3CharacterEffectComponent::GetOverlappableBuffEffectiveLevel(EP3OverappableBuffType OverlappableBuffType) const
{
	const int32* Level = Net_OverlappableBuffEffectiveLevels.Find(OverlappableBuffType);

	if (!Level)
	{
		return 0;
	}

	return *Level;
}

int32 UP3CharacterEffectComponent::GetBuffProvokeLevel() const
{
	int ProvokeLevel = 0;

	for (const FP3CharacterBuff& Buff : Net_CharacterBuffs.CharacterBuffs)
	{
		ProvokeLevel += Buff.ProvokeLevel;
	}

	return ProvokeLevel;
}

void UP3CharacterEffectComponent::SetMoveSpeedEffect(EP3MoveSpeedEffectLayer Layer, float Multiplier, UObject* SourceObject)
{
	if (!ensure(MoveSpeedEffects.IsValidIndex((int32)Layer)))
	{
		return;
	}

	FMoveSpeedEffect& Effect = MoveSpeedEffects[(int32)Layer];

	if (SourceObject && Effect.SourceObject.Get() && SourceObject != Effect.SourceObject.Get())
	{
		ensureMsgf(0, TEXT("Object1(%s), Object2(%s)"),
			SourceObject ? *SourceObject->GetName() : TEXT("NULL"),
			Effect.SourceObject.Get() ? *Effect.SourceObject->GetName() : TEXT("NULL"));

		P3JsonLog(Warning, "Multiple source found on character move speed effect",
			TEXT("Object1"), SourceObject ? *SourceObject->GetName() : TEXT("NULL"),
			TEXT("Object2"), Effect.SourceObject.Get() ? *Effect.SourceObject->GetName() : TEXT("NULL"));
	}

	Effect.Multiplier = Multiplier;
	Effect.SourceObject = SourceObject;
}

float UP3CharacterEffectComponent::GetMoveSpeedMultiplier() const
{
	float Multiplier = 1.0f;

	// TODO: maybe we might need to come up with custom logic to sum things up
	for (const FMoveSpeedEffect& Effect : MoveSpeedEffects)
	{
		Multiplier *= Effect.Multiplier;
	}

	return Multiplier;
}

FString UP3CharacterEffectComponent::GetDebugString() const
{
	FString OutString;

	for (int32 TypeIndex = 0; TypeIndex < Server_Effects.Num(); ++TypeIndex)
	{
		const TArray<FP3CharacterEffectInstance>& Instances = Server_Effects[TypeIndex];

		for (const FP3CharacterEffectInstance& Instance : Instances)
		{
			OutString += FString::Printf(TEXT("%s : %s\n"),
			*EnumToStringShort(EP3CharacterEffectTypes, TypeIndex), Instance.SourceObject.IsValid() ? *Instance.SourceObject->GetName() : TEXT("NULL"));
		}
	}

	return OutString;
}

void UP3CharacterEffectComponent::NetSerialize(FArchive& Archive)
{
	Archive << Net_Effects;
	FP3CharacterBuffs::StaticStruct()->SerializeBin(Archive, &Net_CharacterBuffs);
	Archive << Net_OverlappableBuffEffectiveLevels;
}

void UP3CharacterEffectComponent::Server_TickExpireBuffs()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	UWorld* World = GetWorld();

	if (!ensure(World))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}
	if (Character && Character->GetCharacterStoreBP().bGodMode)
	{
		return;
	}

	const float Now = World->GetTimeSeconds();

	TArray<int32> ExpiredBuffIds;

	for (const FP3CharacterBuff& Buff : Net_CharacterBuffs.CharacterBuffs)
	{
		if (Buff.ExpireAtTimeSeconds >= 0 && Buff.ExpireAtTimeSeconds <= Now)
		{
			ExpiredBuffIds.Add(Buff.GenerateID);
		}

		// 전투 시 해제 해야 하는 버프 체크
		const FP3CmsCharacterBuffRow* CmsCharacterBuff = P3Cms::GetCharacterBuff(Buff.BuffKey);
		if (CmsCharacterBuff && CmsCharacterBuff->bRemoveBuffInCombatStance)
		{
			if (Character->GetStance() == EP3CharacterStance::Combat)
			{
				ExpiredBuffIds.Add(Buff.GenerateID);
			}
		}
	}

	for (int32 BuffId : ExpiredBuffIds)
	{
		Server_RemoveBuff(BuffId);
	}

	if (ExpiredBuffIds.Num() > 0)
	{
		UP3AttributesComponent* AttributeComp = GetOwner()->FindComponentByClass<UP3AttributesComponent>();
		if (AttributeComp)
		{
			AttributeComp->UpdateAttributes();
		}

		Server_SetDirty(*this);
	}
}

void UP3CharacterEffectComponent::Server_TickApplyBuffs(float DeltaTime)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (FP3CharacterBuff& Buff : Net_CharacterBuffs.CharacterBuffs)
	{
		switch (Buff.CmsCharacterBuff.BuffImplType)
		{
		case EP3CharacterBuffImplType::None:
			break;

		case EP3CharacterBuffImplType::DamageOverTime:
			Buff.LeftIntervalTimeSeconds -= DeltaTime;
			if (Buff.LeftIntervalTimeSeconds <= 0.0f)
			{
				const FP3CmsDamageOverTimeBuffImplRow* CmsDamageOverTimeBuff = P3Cms::GetDamageOverTimeBuffImpl(Buff.CmsCharacterBuff.BuffImpleKey);

				if (!ensure(CmsDamageOverTimeBuff))
				{
					continue;
				}

				Buff.LeftIntervalTimeSeconds = CmsDamageOverTimeBuff->IntervalTimeSeconds;

				AP3Character* Character = Cast<AP3Character>(GetOwner());
				UP3CommandComponent* CommandComp = Character ? Character->GetCommandComponent() : nullptr;
				if (ensure(CommandComp))
				{
					FP3CommandRequestParams CommandParams;
					CommandParams.ApplyDamage_DamageAmount = CmsDamageOverTimeBuff->DamageAmount;
					// TODO: Need buff source
					CommandParams.ApplyDamage_SourceActor = nullptr;
					CommandParams.ApplyDamage_HitLocation = Character->GetActorLocation();
					CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::DamageOverTime;
					CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
				}
			}
			break;

		case EP3CharacterBuffImplType::HealOverTime:
			Buff.LeftIntervalTimeSeconds -= DeltaTime;
			if (Buff.LeftIntervalTimeSeconds <= 0.0f)
			{
				const FP3CmsHealOverTimeBuffImplRow* CmsHealOverTimeBuff = P3Cms::GetHealOverTimeBuffImpl(Buff.CmsCharacterBuff.BuffImpleKey);
				if (!ensure(CmsHealOverTimeBuff))
				{
					continue;
				}

				Buff.LeftIntervalTimeSeconds = CmsHealOverTimeBuff->HealIntervalTimeSeconds;
				const float HealAmount = CmsHealOverTimeBuff->HealAmount;

				if (GetOwner())
				{
					P3Combat::ChangeActorHealth(nullptr, *GetOwner(), HealAmount, EP3HealthChangeReason::DamageOverTime);
				}
			}
			break;

		case EP3CharacterBuffImplType::AttributeModifier:
			break;

		case EP3CharacterBuffImplType::RegenStamina:
			Buff.LeftIntervalTimeSeconds -= DeltaTime;
			if (Buff.LeftIntervalTimeSeconds <= 0.0f)
			{
				const FP3CmsRegenStaminaBuffImplRow* CmsRegenStaminaBuff = P3Cms::GetRegenStaminaBuffImpl(Buff.CmsCharacterBuff.BuffImpleKey);
				if (!ensure(CmsRegenStaminaBuff))
				{
					continue;
				}

				Buff.LeftIntervalTimeSeconds = CmsRegenStaminaBuff->RegenIntervalTimeSeconds;
				const float RegenAmount = CmsRegenStaminaBuff->RegenAmount;

				AP3Character* Character = Cast<AP3Character>(GetOwner());
				UP3StaminaPointComponent* StaminaComp = Character ? Character->GetStaminaComponent() : nullptr;
				if (ensure(StaminaComp) && !StaminaComp->IsExhausted())
				{
					StaminaComp->RestoreStaminaPoint(RegenAmount);
				}
			}
			break;

		case EP3CharacterBuffImplType::Overlappable:
			break;
		case EP3CharacterBuffImplType::Provoke:
			break;
		case EP3CharacterBuffImplType::Reaction:
			break;
		case EP3CharacterBuffImplType::SummonActor:
			break;
		default:
			ensure(0);
			break;
		}
	}
}

void UP3CharacterEffectComponent::Server_UpdateNetEffects()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!GetOwner())
	{
		return;
	}

	TSet<EP3CharacterEffectTypes> NewEffects;

	for (int32 TypeIndex = 0; TypeIndex < Server_Effects.Num(); ++TypeIndex)
	{
		if (Server_Effects[TypeIndex].Num() > 0)
		{
			NewEffects.Add(StaticCast<EP3CharacterEffectTypes>(TypeIndex));
		}
	}

	if (NewEffects.Num() != Net_Effects.Num() || Net_Effects.Union(NewEffects).Num() != NewEffects.Num())
	{
		Net_Effects = NewEffects;

		Server_SetDirty(*this);
	}
}

void UP3CharacterEffectComponent::Server_UpdateOverlappable()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();

	TMap<EP3OverappableBuffType, int32> NewOverlappableBuffEffectiveLevels;

	for (int32 OverlappableBuffType = 0; OverlappableBuffType < Server_OverlappableBuffs.Num(); ++OverlappableBuffType)
	{
		FOverlappableBuff& OverlappableBuff = Server_OverlappableBuffs[OverlappableBuffType];

		OverlappableBuff.BaseLevel = 0;

		// First see if we have buff
		for (const FP3CharacterBuff& CharacterBuff : Net_CharacterBuffs.CharacterBuffs)
		{
			if ((int32)CharacterBuff.OverlappableBuffType == OverlappableBuffType)
			{
				if (OverlappableBuff.BaseLevel < CharacterBuff.BaseLevel)
				{
					OverlappableBuff.BaseLevel = CharacterBuff.BaseLevel;
					OverlappableBuff.EffectRadius = CharacterBuff.EffectRadius;
					OverlappableBuff.OverlapRadius = CharacterBuff.OverlappableRadius;
				}
			}
		}

		// If we have scare buff, lets consider stacking it with nearby allies
		OverlappableBuff.OverlapSources.Empty();
		OverlappableBuff.OverlappedLevel = 0;

		if (OverlappableBuff.BaseLevel > 0 && OwnerActor)
		{
			const FVector& MyLocation = OwnerActor->GetActorLocation();

			const TArray<class AP3Character*>& Characters = P3Core::GetP3World(*this)->GetServerWorld()->GetCharacters();

			for (AP3Character* Character : Characters)
			{
				if (Character == OwnerActor)
				{
					continue;
				}

				UP3CharacterEffectComponent* OtherEffectComp = Character->GetEffectComponent();

				if (OtherEffectComp && OtherEffectComp->Server_GetOverlappableBuffBaseLevel(EP3OverappableBuffType(OverlappableBuffType)) > 0)
				{
					const float DistanceSquared = (Character->GetActorLocation() - MyLocation).SizeSquared();

					if (DistanceSquared < FMath::Square(OtherEffectComp->Server_GetOverlappableBuffOverlapRadius(EP3OverappableBuffType(OverlappableBuffType))))
					{
						OverlappableBuff.OverlapSources.Add(OtherEffectComp);

						OverlappableBuff.OverlappedLevel += OtherEffectComp->Server_GetOverlappableBuffBaseLevel(EP3OverappableBuffType(OverlappableBuffType));
					}
				}
			}
		}

		const int32 EffectiveLevel = OverlappableBuff.BaseLevel + OverlappableBuff.OverlappedLevel;

		if (EffectiveLevel > 0)
		{
			NewOverlappableBuffEffectiveLevels.Add((EP3OverappableBuffType)OverlappableBuffType, OverlappableBuff.BaseLevel + OverlappableBuff.OverlappedLevel);
		}
	}

	if (!Net_OverlappableBuffEffectiveLevels.OrderIndependentCompareEqual(NewOverlappableBuffEffectiveLevels))
	{
		Net_OverlappableBuffEffectiveLevels = NewOverlappableBuffEffectiveLevels;

		Server_SetDirty(*this);
	}
}

void UP3CharacterEffectComponent::Server_OnBuffRemoved(FP3CharacterBuff& Buff)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Buff.Server_SummonedActor.Get())
	{
		Buff.Server_SummonedActor.Get()->Destroy();
		Buff.Server_SummonedActor.Reset();
	}
}
