// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "P3PlayerController.h"
#include "P3NpcStressTestPlayerController.generated.h"

UCLASS()
class P3_API AP3NpcStressTestPlayerController : public AP3PlayerController
{
	GENERATED_BODY()

public:
	virtual void Tick(float DeltaSeconds) override;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason);

private:
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerSpawnNpcs(const TArray<FString>& Args);
	bool ServerSpawnNpcs_Validate(const TArray<FString>& Args);
	void ServerSpawnNpcs_Implementation(const TArray<FString>& Args);

	UFUNCTION(Client, Reliable)
	void ClientSpawnStatus(int32 Current, int32 Total);
	void ClientSpawnStatus_Implementation(int32 Current, int32 Total);

	void OnConsoleCommandSpawnNpcs(const TArray<FString>& Args);

	UPROPERTY(EditAnywhere, Category = "P3")
	TSubclassOf<class AActor> SpawnActorClass;

	UPROPERTY(EditAnywhere, Category = "P3")
	float SpawnPerSeconds = 10.0f;

	UPROPERTY(EditAnywhere, Category = "P3")
	int32 NpcDistance = 1000;

	UPROPERTY()
	TArray<class AActor*> SpawnedNpcs;

	int32 TargetNpcNum = 0;
	int32 CurrnetNpcNum = 0;
	float LastSpawnTimeSeconds = 0.0f;

	IConsoleCommand* ConsoleCommandSpawnNpcs = nullptr;
};
