// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "FoliageInstancedStaticMeshComponent.h"
#include "P3GrassFoliageComponent.generated.h"

/**
 * 
 */
UCLASS()
class P3_API UP3GrassFoliageComponent : public UFoliageInstancedStaticMeshComponent
{
	GENERATED_BODY()
	
private:
	UP3GrassFoliageComponent();
	
	UFUNCTION()
	void OnInstancePointDamage(int32 InstanceIndex, float Damage, class AController* InstigatedBy, FVector HitLocation, FVector ShotFromDirection, const class UDamageType* DamageType, AActor* DamageCauser);

	UFUNCTION()
	void OnInstanceRadialDamage(const TArray<int32>& Instances, const TArray<float>& Damages, class AController* InstigatedBy, FVector Origin, float MaxRadius, const class UDamageType* DamageType, AActor* DamageCauser);
};
