// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3TemporaryWeaponType.generated.h"

UENUM(Blueprintable)
enum class EP3TemporaryWeaponType : uint8
{
	None UMETA(Hidden),
	Javelin,
};