// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Item/P3Item.h"
#include "P3CharacterEmoteAnimation.h"
#include "P3CharacterStance.h"
#include "P3Core.h"
#include "P3Cms.h"
#include "P3HoldType.h"
#include "P3CharacterStore.generated.h"

USTRUCT(Blueprintable)
struct FP3CharacterStore
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FText DisplayName;

	UPROPERTY()
	uint64 CharacterId = INVALID_CHARID;

	UPROPERTY(BlueprintReadOnly)
	EP3CharClass CharClass = EP3CharClass::Melee;

	UPROPERTY(BlueprintReadOnly)
	FName HairName;

	UPROPERTY(BlueprintReadOnly)
	FName ArmorName;

	UPROPERTY(BlueprintReadOnly)
	EP3CharacterStance Stance = EP3CharacterStance::Idle;

	UPROPERTY(BlueprintReadOnly)
	int32 CharLevel = 0;

	UPROPERTY(BlueprintReadOnly)
	bool bIsBlocking = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsCrouchBlocking = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsBouncingMode = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsAiming = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsChangingThrowable = false;

	UPROPERTY(BlueprintReadOnly)
	FP3ItemId ThrowAimingItemId = INVALID_ITEMID;

	UPROPERTY(BlueprintReadOnly)
	bool bIsMeleeAiming = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsRagdollized = false;

	UPROPERTY(BlueprintReadOnly)
	bool bKnockDowned = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsStumbling = false;

	UPROPERTY(BlueprintReadOnly)
	bool bIsFlameHitMotionIgnored = false;

	UPROPERTY(BlueprintReadOnly)
	bool bGodMode = false;

	UPROPERTY(BlueprintReadOnly)
	bool bNoTargetMode = false;

	UPROPERTY(BlueprintReadOnly)
	bool bOnQuestCutscene = false;

	UPROPERTY(BlueprintReadOnly)
	FP3Item ThrownWeaponItem = FP3Item::InvalidItem;

	UPROPERTY(BlueprintReadOnly)
	TWeakObjectPtr<class AP3Weapon> ThrownWeapon;

	UPROPERTY(BlueprintReadOnly)
	EP3HoldType ThrownWeaponHoldType = EP3HoldType::Count;

	UPROPERTY(BlueprintReadOnly)
	TWeakObjectPtr<class AP3Weapon> RecallingThrownWeapon;

	// Set if I'm riding this character
	UPROPERTY(BlueprintReadOnly)
	class AP3Character* MountTargetCharacter = nullptr;

	// Set if I'm riding this character
	UPROPERTY(BlueprintReadOnly)
	int32 MountPointIndex = -1;

	// Set if player is carrying by rescuer
	UPROPERTY(BlueprintReadOnly)
	bool bMountingByRescuer = false;

	// Set if Someone is mounting me
	// Key: My MountPointIndex, Value: Rider character
	UPROPERTY(BlueprintReadOnly)
	TMap<int32, AP3Character*> MountRiderCharacters;

	// Value: My MountPoint's index
	UPROPERTY(BlueprintReadOnly)
	TArray<int32> DisabledMountPoints;

	// Set if I rescue this character
	UPROPERTY(BlueprintReadOnly)
	class AP3Character* RescueTargetCharacter = nullptr;

	UPROPERTY(BlueprintReadOnly)
	class AActor* FlagActor = nullptr;

	UPROPERTY(BlueprintReadOnly)
	FP3CharacterEmoteAnimation Emote;

	UPROPERTY(BlueprintReadOnly)
	bool bInEmote = false;
};
