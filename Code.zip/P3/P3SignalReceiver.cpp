// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3SignalReceiver.h"

#include "DrawDebugHelpers.h"
#include "Engine/NetDriver.h"
#include "Kismet/GameplayStatics.h"
#include "LevelSequenceActor.h"
#include "Particles/Emitter.h"

#include "P3Core.h"
#include "P3Destructible.h"
#include "P3ServerWorld.h"
#include "P3SpawnerComponent.h"
#include "P3World.h"

const FName AP3LinearActuator::NAME_Signal = FName(TEXT("Signal"));
const FName AP3LevelSequencePlayer::NAME_PlaySequence = (TEXT("PlaySequence"));
const FName AP3LevelSequencePlayer::NAME_StopSequence = (TEXT("StopSequence"));
const FName AP3DestructibleDropper::NAME_DropSignal = (TEXT("DropSignal"));

AP3SignalReceiver::AP3SignalReceiver()
{
}

void AP3SignalReceiver::NetSerialize(FArchive & Archive)
{
	Super::NetSerialize(Archive);

	if (!Archive.IsLoading())
	{
		Archive << Net_bOn;
	}
	else
	{
		bool bNewOn = false;

		Archive << bNewOn;

		if (bNewOn != Net_bOn)
		{
			Net_bOn = bNewOn;
			Client_OnSignal(bNewOn);
		}
	}
}

void AP3SignalReceiver::Server_Signal(bool bOn)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	Net_bOn = bOn;

	Server_SetDirty(*this);

	Server_OnSignal(bOn);
	ReceiveSignalBP(bOn);
}


/**
 * Servo
 */

AP3Servo::AP3Servo()
{
	PrimaryActorTick.bCanEverTick = true;

	MountComponent = CreateDefaultSubobject<USceneComponent>(TEXT("MountComponent"));
	RootComponent = MountComponent;

	AxleComponent = CreateDefaultSubobject<USceneComponent>(TEXT("AxleComponent"));
	AxleComponent->SetupAttachment(MountComponent);

	SetReplicates(true);
	SetReplicateMovement(true);
	AxleComponent->SetIsReplicated(true);
}

void AP3Servo::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	//DrawDebugString(GetWorld(), FVector(0, 0, 0), FString::Printf(TEXT("%.2f/%.2f, %.2f"), CurrentAngleDegree, MaxRotationAngleDegree, CurrentRotateDirection), this);

	if (CurrentRotateDirection == 0)
	{
		return;
	}

	CurrentAngleDegree += AngVelDegreePerSecond * CurrentRotateDirection;

	if (CurrentAngleDegree <= 0.0f)
	{
		CurrentAngleDegree = 0.0f;
		CurrentRotateDirection = 0.0f;
	}
	else if (CurrentAngleDegree >= MaxRotationAngleDegree)
	{
		CurrentAngleDegree = MaxRotationAngleDegree;
		CurrentRotateDirection = 0.0f;
	}

	AxleComponent->SetRelativeRotation(FRotator(CurrentAngleDegree, 0.0f, 0.0f));
}

void AP3Servo::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	CurrentRotateDirection = bOn ? 1.0f : -1.0f;
}


/** 
 *	Out runner servo
 */

AP3OutrunnerServo::AP3OutrunnerServo()
{
	PrimaryActorTick.bCanEverTick = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));

	SetReplicates(true);
	SetReplicateMovement(true);
	ReplicatedMovement.RotationQuantizationLevel = ERotatorQuantization::ShortComponents;
}

void AP3OutrunnerServo::BeginPlay()
{
	Super::BeginPlay();

	DefaultRotator = GetActorRotation();
}

void AP3OutrunnerServo::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	//DrawDebugString(GetWorld(), FVector(0, 0, 0),
	//	FString::Printf(TEXT("%.2f/%.2f, %.2f"), CurrentAngleDegree, MaxRotationAngleDegree, CurrentRotateDirection),
	//	this, FColor::White, 0.0f, true);

	if (CurrentRotateDirection == 0)
	{
		return;
	}

	CurrentAngleDegree += AngVelDegreePerSecond * CurrentRotateDirection * DeltaTime;

	if (CurrentAngleDegree <= 0.0f)
	{
		CurrentAngleDegree = 0.0f;
		CurrentRotateDirection = 0.0f;
	}
	else if (MaxRotationAngleDegree != -1.0f && CurrentAngleDegree >= MaxRotationAngleDegree)
	{
		CurrentAngleDegree = MaxRotationAngleDegree;
		CurrentRotateDirection = 0.0f;
	}

	RootComponent->SetRelativeRotation(DefaultRotator + FRotator(CurrentAngleDegree, 0.0f, 0.0f));
}

void AP3OutrunnerServo::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	CurrentRotateDirection = bOn ? 1.0f : -1.0f;
}


/** 
 * Linear actuator
 */

AP3LinearActuator::AP3LinearActuator()
{
	PrimaryActorTick.bCanEverTick = true;

	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComponent"));
	RootComponent->SetMobility(EComponentMobility::Movable);

	SetReplicates(true);
	SetReplicateMovement(true);
}

void AP3LinearActuator::BeginPlay()
{
	Super::BeginPlay();

	DefaultLocation = GetActorLocation();

	if (GetParentActor() && GetRootComponent())
	{
		DefaultLocation = GetRootComponent()->GetRelativeTransform().GetLocation();
	}
}

void AP3LinearActuator::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	//DrawDebugString(GetWorld(), FVector(0, 0, 0),
	//	FString::Printf(TEXT("%.2f/%.2f, %.2f"), CurrentAngleDegree, MaxRotationAngleDegree, CurrentRotateDirection),
	//	this, FColor::White, 0.0f, true);

	if (CurrentMoveDirection == 0)
	{
		return;
	}

	CurrentTravel += Speed * CurrentMoveDirection * DeltaTime;

	if (CurrentTravel <= 0.0f)
	{
		CurrentTravel = 0.0f;
		CurrentMoveDirection = 0.0f;
	}
	else if (CurrentTravel >= MaxTravelDistance)
	{
		CurrentTravel = MaxTravelDistance;
		CurrentMoveDirection = 0.0f;
	}

	MoveForwardVector = GetParentActor() ? FVector(1, 0, 0) : GetActorForwardVector();

	RootComponent->SetRelativeLocation(DefaultLocation + MoveForwardVector * CurrentTravel);
}

void AP3LinearActuator::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	CurrentMoveDirection = bOn ? 1.0f : -1.0f;

	Server_MulticastEvent(NAME_Signal, bOn ? 1 : 0);
}

void AP3LinearActuator::Multicast_OnSignal(bool bOn)
{
	if (bOn && OnSound)
	{
		UGameplayStatics::PlaySoundAtLocation(this, OnSound, GetActorLocation());
	}
	else if (!bOn && OffSound)
	{
		UGameplayStatics::PlaySoundAtLocation(this, OffSound, GetActorLocation());
	}
}

void AP3LinearActuator::Client_OnEvent(FName EventName, int32 Param)
{
	Super::Client_OnEvent(EventName, Param);

	if (EventName == NAME_Signal)
	{
		Multicast_OnSignal(Param == 1);
	}
}

/** 
 * Spawner activator (Server only)
 */

AP3SpawnerActivator::AP3SpawnerActivator()
{
	bNetLoadOnClient = false;
}

void AP3SpawnerActivator::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (AActor* SpawnerActor : SpawnerActors)
	{
		if (!ensure(SpawnerActor))
		{
			continue;
		}

		UP3SpawnerComponent* SpawnerComp = SpawnerActor->FindComponentByClass<UP3SpawnerComponent>();
		if (ensure(SpawnerComp))
		{
			if (bOn)
			{
				SpawnerComp->Activate();
			}
			else
			{
				SpawnerComp->Deactivate();
			}
		}
	}
}

AP3LevelSequencePlayer::AP3LevelSequencePlayer()
{
	// Client need to load this from level so that LevelSequenceActor can be valid
	bLevelPersistence = true;
}

void AP3LevelSequencePlayer::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!bOn)
	{
		return;
	}
	
	if (!LevelSequenceActor)
	{
		return;
	}

	if (Server_bPlaying)
	{
		return;
	}
	
	if (LevelSequenceActor->SequencePlayer)
	{
		Server_bPlaying = true;

		P3Core::GetP3World(*this)->AddSequencePlayer(LevelSequenceActor->SequencePlayer);

		Server_MulticastEvent(NAME_PlaySequence, 0);
	}
}

void AP3LevelSequencePlayer::Client_OnEvent(FName EventName, int32 Param)
{
	Super::Client_OnEvent(EventName, Param);

	if (EventName == NAME_PlaySequence)
	{
		if (ensure(LevelSequenceActor))
		{
			LevelSequenceActor->SequencePlayer->OnStop.AddUniqueDynamic(this, &AP3LevelSequencePlayer::OnSequenceStop);
			LevelSequenceActor->SequencePlayer->OnFinished.AddUniqueDynamic(this, &AP3LevelSequencePlayer::OnSequenceFinished);

			LevelSequenceActor->SequencePlayer->Play();
		}
	}
	else if (EventName == NAME_StopSequence)
	{
		if (ensure(LevelSequenceActor))
		{
			if (LevelSequenceActor->SequencePlayer && LevelSequenceActor->SequencePlayer->IsPlaying())
			{
				LevelSequenceActor->SequencePlayer->Stop();
			}
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			if (OnFinishedSignalReceiver)
			{
				OnFinishedSignalReceiver->Server_Signal(true);
			}
		}
	}
}

void AP3LevelSequencePlayer::OnSequenceStop()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_MulticastEvent(NAME_StopSequence, 0);

		if (LevelSequenceActor)
		{
			P3Core::GetP3World(*this)->RemoveSequencePlayer(LevelSequenceActor->SequencePlayer);
		}

		Server_bPlaying = false;
	}
}

void AP3LevelSequencePlayer::OnSequenceFinished()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_MulticastEvent(NAME_StopSequence, 0);

		if (LevelSequenceActor)
		{
			P3Core::GetP3World(*this)->RemoveSequencePlayer(LevelSequenceActor->SequencePlayer);
		}

		Server_bPlaying = false;
	}
}

AP3DestructibleDropper::AP3DestructibleDropper()
{
	// Client need to load this from level so that LevelSequenceActor can be valid
	bLevelPersistence = true;
}

void AP3DestructibleDropper::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_bDropped)
	{
		return;
	}

	if (ensure(TargetDestructible))
	{
		TargetDestructible->EnablePhysics();
	}

	Server_MulticastEvent(NAME_DropSignal, 0);

	Server_bDropped = true;
}

void AP3DestructibleDropper::Client_OnEvent(FName EventName, int32 Param)
{
	Super::Client_OnEvent(EventName, Param);

	if (EventName == NAME_DropSignal)
	{
		if (TargetDestructible)
		{
			TargetDestructible->EnablePhysics();
		}
	}
}

AP3SetActorVisible::AP3SetActorVisible()
{
	bLevelPersistence = true;
}

void AP3SetActorVisible::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Multicast_OnSignal(bOn);
}

void AP3SetActorVisible::Client_OnSignal(bool bOn)
{
	Super::Client_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	Multicast_OnSignal(bOn);
}

void AP3SetActorVisible::Multicast_OnSignal(bool bOn)
{
	for (AActor* TargetActor : TargetActors)
	{
		if (!TargetActor)
		{
			continue;
		}

		if (!TargetActor->GetRootComponent())
		{
			continue;
		}

		TargetActor->GetRootComponent()->SetVisibility(bOn, true);
	}
}

AP3EmitterActivator::AP3EmitterActivator()
{
	bLevelPersistence = true;
}

void AP3EmitterActivator::Server_OnSignal(bool bOn)
{
	Super::Server_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Multicast_OnSignal(bOn);
}

void AP3EmitterActivator::Client_OnSignal(bool bOn)
{
	Super::Client_OnSignal(bOn);

	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	Multicast_OnSignal(bOn);
}

void AP3EmitterActivator::Multicast_OnSignal(bool bOn)
{
	for (AEmitter* Emitter : TargetEmitters)
	{
		if (!Emitter)
		{
			continue;
		}

		if (bOn)
		{
			Emitter->Activate();
		}
		else
		{
			Emitter->Deactivate();
		}
	}
}
