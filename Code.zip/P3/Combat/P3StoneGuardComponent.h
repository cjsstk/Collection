// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "GameplayTagContainer.h"

#include "P3StoneGuardComponent.generated.h"

/**
 * Server Only
 * Pull tagged objects and attach to owner actor
 * And rotate them around owner actor
 */
UCLASS(Blueprintable, ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3StoneGuardComponent : public USceneComponent
{
	GENERATED_BODY()

public:	
	UP3StoneGuardComponent();

	void Server_PrepareBlast();

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

private:
	void Server_FindStones();
	void Server_FindTargetLocations();
	void Server_StartPullingIn();
	void Server_StartOrbit();

	void Server_TickPullingIn(float DeltaSeconds);
	void Server_TickOrbiting(float DeltaSeconds);
	void Server_TickRaising(float DeltaSeconds);

	void Server_Blast();

	enum class EState
	{
		Idle,
		PullingIn,
		Orbiting,
		Raising,
		Blasting
	};

	const static FName NAME_StartOrbiting;
	const static FName NAME_PrepareBlast;

	/**
	 * Only objects with any of this gameplay tags will be pulled in
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer GameplayTagsAny;

	/**
	 * Only objects within this range will be pulled in
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float StoneSearchRadius = 3000;

	/**
	 * Only characters within this range will be targeted
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float TargetSearchRadius = 5000;

	/**
	 * This amount will be added to TargetLocation's Z value
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float TargetLocationZOffset = 200;

	/**
	 * How long does it takes to pull in stones?
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float PullInDurationSeconds = 2.0f;

	/**
	 * Pulled objects will rotate around actor at this distance
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float OrbitRadius = 500;

	/**
	 * This amount will be added to OwnerLocation's value
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FVector OrbitCenterOffset = FVector::ZeroVector;

	/**
	 * Orbit min z offset
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float OrbitMinHeightRange = 0.0f;

	/**
	 * Orbit max z offset
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float OrbitMaxHeightRange = 100.0f;

	/**
	 * Orbit speed in Degrees/Second
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float OrbitAngularVelocityInDegrees = 30;

	/**
	 * Raising duration before blasting
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float RaisingDurationSeconds = 3.0f;

	/**
	 * Raising minimum height before blasting
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float RaisingMinHeight = 300;

	/**
	 * Raising maximum height before blasting
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float RaisingMaxHeight = 500;

	/**
	 * Stone throwing min speed on blasting
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float BlastMinSpeed = 2000;

	/**
	 * Stone throwing max speed on blasting
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	float BlastMaxSpeed = 4000;

	/**
	 * Maximum number of stones flying to the player
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	int32 MaxStoneNumForOnePlayer = 4;

	UPROPERTY(Transient)
	TArray<AActor*> Server_StoneActors;

	UPROPERTY(Transient)
	TArray<FVector> Server_TargetCharacterLocations;

	/** Random orbit z offset for each stones */
	TArray<float> Server_StoneZOffsets;

	EState CurrentState = EState::Idle;

	/** Time since pulling started */
	float Server_PullingAgeSeconds = 0;

	/** Time since raising started */
	float Server_RaisingAgeSeconds = 0;

	/** Time since blasting started */
	float Server_BlastingAgeSeconds = 0;
};

/** 
 * ServerOnly
 * Find UStoneGuardComponent within same actor and call Blast
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3StoneGuardBlasterComponent : public USceneComponent
{
	GENERATED_BODY()

public:
	UP3StoneGuardBlasterComponent();

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
};
