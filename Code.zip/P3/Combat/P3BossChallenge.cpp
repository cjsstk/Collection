// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BossChallenge.h"

#include "Components/Image.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerStart.h"
#include "LevelSequenceActor.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "GameMode/P3ContributionSystem.h"
#include "P3Character.h"
#include "P3CharacterHealthPointComponent.h"
#include "P3Core.h"
#include "P3GameMode.h"
#include "P3HolderComponent.h"
#include "P3InventoryComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3PlayerController.h"
#include "P3RevivePointActor.h"
#include "P3SpawnerActor.h"
#include "P3SpawnerComponent.h"
#include "P3World.h"
#include "Widget/P3BossTimerWidget.h"

const FName AP3BossChallengeActor::NAME_PlayFailedSequence = FName(TEXT("PlayFailedSequence"));
const FName AP3BossChallengeActor::NAME_PlaySucceededSequence = FName(TEXT("PlaySucceededSequence"));

TAutoConsoleVariable<float> CVarP3BossChallengeExtraTimeLimitSecondsMode(
	TEXT("p3.bossChallengeExtraTimeLimitSeconds"),
	0.0f,
	TEXT("Time Limit = TimeLimitSeconds + BossChallengeExtraTimeLimitSeconds"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3BossChallengePlayerDeadCountModifier(
	TEXT("p3.bossChallengePlayerDeadCountModifier"),
	0,
	TEXT("Set 2 to increase 2 more lives, set -2 to decrease 2 lives"), ECVF_Cheat);


void AP3BossChallengeActor::Server_OnPlayerDead(const AActor& PlayerActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_CurrentState != EState::Idle)
	{
		return;
	}

	const int32 EffectiveNumMaxPlayerDead = NumMaxPlayerDead + CVarP3BossChallengePlayerDeadCountModifier.GetValueOnGameThread();

	Server_NumPlayerDead = FMath::Min(Server_NumPlayerDead + 1, EffectiveNumMaxPlayerDead);

	FString SourceName = PlayerActor.GetName();

	const AP3Character* SourceCharacter = Cast<AP3Character>(&PlayerActor);
	if (SourceCharacter)
	{
		SourceName = SourceCharacter->GetCharacterStoreBP().DisplayName.ToString();
	}

	FFormatNamedArguments Arguments;
	Arguments.Add(TEXT("Player"), FText::AsCultureInvariant(*SourceName));
	Arguments.Add(TEXT("CurrentDeadCount"), FText::AsNumber(Server_NumPlayerDead));
	Arguments.Add(TEXT("MaxDeadCount"), FText::AsNumber(EffectiveNumMaxPlayerDead));

	FText Message = FText::Format(P3LOC_BOSS("PlayerDied"), Arguments);
	P3Core::GetP3World(*this)->Server_SendToastMessageToAll(Message);

	if (Server_NumPlayerDead >= EffectiveNumMaxPlayerDead)
	{
		Server_OnFailed();
	}
}

void AP3BossChallengeActor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaSeconds);
	}
}

void AP3BossChallengeActor::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	float PrevExtra = Net_ExtraTimeLimitSeconds;
	EState PrevState = Net_CurrentState;

	Archive << Net_ChallengeLeftTimeSeconds;
	Archive << Net_ExtraTimeLimitSeconds;
	Archive << Net_CurrentState;

	if (Archive.IsLoading() && P3Core::IsP3NetModeClientInstance(*this))
	{
		if (PrevState != Net_CurrentState)
		{
			if (Net_CurrentState == EState::Idle)
			{
				Client_OnStartChallenge();
			}
			else
			{
				Client_OnFinishChallenge();
			}
		}
		else if (PrevExtra != Net_ExtraTimeLimitSeconds)
		{
			Client_OnUpdateTimer();
		}
	}
}

void AP3BossChallengeActor::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		AP3Character* Character = Cast<AP3Character>(GetInstigator());
		if (ensure(Character))
		{
			Character->OnCharacterDead.AddUniqueDynamic(this, &AP3BossChallengeActor::Server_OnOwnerDead);
		}

		Net_ChallengeLeftTimeSeconds = TimeLimitSeconds;
		Net_CurrentState = EState::Idle;

		Server_SetDirty(*this);

		AP3ContributionSystem* ContributionSystem = P3Core::GetContributionSystem(*this);

		if (ContributionSystem)
		{
			ContributionSystem->Server_Reset();
		}
	}

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		if (Net_CurrentState == EState::Idle)
		{
			Client_OnStartChallenge();
		}
		else
		{
			Client_OnFinishChallenge();
		}
	}
}

void AP3BossChallengeActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		Client_OnFinishChallenge();
	}
}

void AP3BossChallengeActor::Client_OnEvent(FName EventName, int32 Param)
{
	Super::Client_OnEvent(EventName, Param);

	if (EventName == NAME_PlayFailedSequence)
	{
		Multicast_PlayFailedSequence();
	}
	else if (EventName == NAME_PlaySucceededSequence)
	{
		Multicast_PlaySucceededSequence();
	}
}

void AP3BossChallengeActor::Server_Tick(float TickSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_CurrentState != EState::Idle)
	{
		return;
	}

	Net_ChallengeLeftTimeSeconds -= TickSeconds;

	float NewExtraTimeLimitSeconds = CVarP3BossChallengeExtraTimeLimitSecondsMode.GetValueOnGameThread();
	if (Net_ExtraTimeLimitSeconds != NewExtraTimeLimitSeconds)
	{
		Net_ChallengeLeftTimeSeconds += NewExtraTimeLimitSeconds - Net_ExtraTimeLimitSeconds;
		Net_ExtraTimeLimitSeconds = NewExtraTimeLimitSeconds;

		TArray<float> ToRemove;
		for (auto& Key : Server_SentNotifyKeys)
		{
			if (Key < Net_ChallengeLeftTimeSeconds)
			{
				ToRemove.Add(Key);
			}
		}

		for (auto& Key : ToRemove)
		{
			Server_SentNotifyKeys.Remove(Key);
		}
	}

	Server_SetDirty(*this);

	if (Net_ChallengeLeftTimeSeconds <= 0.0f)
	{
		Server_OnTimeOverd();
		return;
	}

	for (auto& Elem : NotifyMessages)
	{
		if (Server_SentNotifyKeys.Find(Elem.Key))
		{
			continue;
		}

		if (Net_ChallengeLeftTimeSeconds <= Elem.Key)
		{
			P3Core::GetP3World(*this)->Server_SendToastMessageToAll(Elem.Value);
			Server_SentNotifyKeys.Add(Elem.Key);
		}
	}
}

void AP3BossChallengeActor::Client_ResetUI()
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	if (Net_CurrentState == EState::Idle)
	{
		Client_OnStartChallenge();
	}
	else
	{
		Client_OnFinishChallenge();
	}
}

void AP3BossChallengeActor::Client_OnStartChallenge()
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
	if (!PlayerController)
	{
		return;
	}

	if (UP3BossTimerWidget* BossTimer = PlayerController->GetBossTimerWidget())
	{
		BossTimer->SetVisibility(ESlateVisibility::HitTestInvisible);
		BossTimer->StartTimer(TimeLimitSeconds, Net_ChallengeLeftTimeSeconds);
	}

	if (UImage* Minimap = PlayerController->GetMinimapImage())
	{
		Minimap->SetVisibility(ESlateVisibility::Collapsed);
	}

	PlayerController->ToastMessageBP(StartMessage);
}

void AP3BossChallengeActor::Client_OnUpdateTimer()
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
	if (!PlayerController)
	{
		return;
	}

	if (UP3BossTimerWidget* BossTimer = PlayerController->GetBossTimerWidget())
	{
		BossTimer->StartTimer(TimeLimitSeconds, Net_ChallengeLeftTimeSeconds);
	}
}

void AP3BossChallengeActor::Client_OnFinishChallenge()
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
	if (!PlayerController)
	{
		return;
	}

	if (UP3BossTimerWidget* BossTimer = PlayerController->GetBossTimerWidget())
	{
		BossTimer->SetVisibility(ESlateVisibility::Collapsed);
		BossTimer->ResetTimer();
	}

	if (UImage* Minimap = PlayerController->GetMinimapImage())
	{
		Minimap->SetVisibility(ESlateVisibility::HitTestInvisible);
	}
}

void AP3BossChallengeActor::Server_OnOwnerDead()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_CurrentState != EState::Idle)
	{
		return;
	}

	Server_OnSucceeded();
}

void AP3BossChallengeActor::OnFailedSequenceStop()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_ResetActorsAfterFail();
	}

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
		if (PlayerController)
		{
			PlayerController->ShowContributionBoard(true);
		}
	}
}

void AP3BossChallengeActor::OnFailedSequenceFinished()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_ResetActorsAfterFail();
	}

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
		if (PlayerController)
		{
			PlayerController->ShowContributionBoard(true);
		}
	}
}

void AP3BossChallengeActor::OnSucceededSequenceStop()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_ResetActorsAfterSuccess();
	}

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
		if (PlayerController)
		{
			PlayerController->ShowContributionBoard(true);
		}
	}
}

void AP3BossChallengeActor::OnSucceededSequenceFinished()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_ResetActorsAfterSuccess();
	}

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
		if (PlayerController)
		{
			PlayerController->ShowContributionBoard(true);
		}
	}
}

void AP3BossChallengeActor::Server_OnTimeOverd()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	P3Core::GetP3World(*this)->Server_SendToastMessageToAll(TimeOverMessage);

	Server_OnFailed();
}

void AP3BossChallengeActor::Server_OnFailed()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	ensure(Net_CurrentState == EState::Idle);

	Net_CurrentState = EState::Failed;

	Server_SetDirty(*this);

	Server_SentNotifyKeys.Empty();

	if (GetInstigator())
	{
		GetInstigator()->Destroy();
	}

	if (FailedLevelSequence)
	{
		Server_MulticastEvent(NAME_PlayFailedSequence, 0);
	}
	else
	{
		Server_ResetActorsAfterFail();
	}
}

void AP3BossChallengeActor::Server_OnSucceeded()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	ensure(Net_CurrentState == EState::Idle);

	Net_CurrentState = EState::Succeeded;

	Server_SetDirty(*this);

	Server_SentNotifyKeys.Empty();

	if (GetInstigator())
	{
		GetInstigator()->Destroy();
	}

	if (SucceededLevelSequence)
	{
		Server_MulticastEvent(NAME_PlaySucceededSequence, 0);
	}
	else
	{
		Server_ResetActorsAfterSuccess();
	}
}

void AP3BossChallengeActor::Multicast_PlayFailedSequence()
{
	if (!ensure(FailedLevelSequence))
	{
		return;
	}

	LevelSequenceActor = GetWorld()->SpawnActor<ALevelSequenceActor>();
	if (ensure(LevelSequenceActor))
	{
		LevelSequenceActor->PlaybackSettings.bHideHud = true;
		LevelSequenceActor->PlaybackSettings.bDisableMovementInput = true;
		LevelSequenceActor->PlaybackSettings.bDisableLookAtInput = true;

		LevelSequenceActor->SetSequence(FailedLevelSequence);

		LevelSequenceActor->SequencePlayer->OnStop.AddUniqueDynamic(this, &AP3BossChallengeActor::OnFailedSequenceStop);
		LevelSequenceActor->SequencePlayer->OnFinished.AddUniqueDynamic(this, &AP3BossChallengeActor::OnFailedSequenceFinished);

		LevelSequenceActor->SequencePlayer->Play();
	}
}

void AP3BossChallengeActor::Multicast_PlaySucceededSequence()
{
	if (!ensure(SucceededLevelSequence))
	{
		return;
	}

	LevelSequenceActor = GetWorld()->SpawnActor<ALevelSequenceActor>();
	if (ensure(LevelSequenceActor))
	{
		LevelSequenceActor->PlaybackSettings.bHideHud = true;
		LevelSequenceActor->PlaybackSettings.bDisableMovementInput = true;
		LevelSequenceActor->PlaybackSettings.bDisableLookAtInput = true;

		LevelSequenceActor->SetSequence(SucceededLevelSequence);

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			LevelSequenceActor->SequencePlayer->OnStop.AddUniqueDynamic(this, &AP3BossChallengeActor::OnSucceededSequenceStop);
			LevelSequenceActor->SequencePlayer->OnFinished.AddUniqueDynamic(this, &AP3BossChallengeActor::OnSucceededSequenceFinished);
		}

		LevelSequenceActor->SequencePlayer->Play();
	}
}

void AP3BossChallengeActor::Server_ResetActorsAfterFail()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (TActorIterator<AP3PawnSpawnerActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AP3PawnSpawnerActor* Actor = *Iter;
		if (Actor)
		{
			Actor->Reset();
		}
	}

	if (ResetOnFailOrSuccessActorGameplayTagsAny.Num() > 0)
	{
		for (TActorIterator<AP3Actor> Iter(GetWorld()); Iter; ++Iter)
		{
			AP3Actor* Actor = *Iter;
			if (Actor && Actor->HasAnyMatchingGameplayTags(ResetOnFailOrSuccessActorGameplayTagsAny))
			{
				Actor->Reset();
			}
		}
	}

	AP3GameMode* GameMode = P3Core::GetP3GameMode(*this);
	if (!ensure(GameMode))
	{
		return;
	}

	UP3ReviveAtNearestPointPlayerReviver* PlayerReviver = Cast< UP3ReviveAtNearestPointPlayerReviver>(GameMode->GetPlayerReviver());
	if (!PlayerReviver)
	{
		return;
	}

	for (TActorIterator<AP3Character> Iter(GetWorld()); Iter; ++Iter)
	{
		AP3Character* Character = *Iter;
		if (!Character || !Character->IsPlayerControlled())
		{
			continue;
		}

		Character->Server_InitDefaultItems();

		UP3CommandComponent* CommandComp = Character->GetCommandComponent();

		if (!ensure(CommandComp))
		{
			continue;
		}

		FTransform RestartTransform = PlayerReviver->GetReviveTransform(Character);

		if (Character->IsDead())
		{
			Character->Revive(RestartTransform);
		}
		else
		{
			if (Character->IsDowned())
			{
				UP3CharacterHealthPointComponent* HPComp = Character->GetP3CharacterHealthComponentBP();

				if (ensure(HPComp))
				{
					HPComp->Server_Rescued();
				}
				Character->GetP3CharacterHealthComponentBP()->Server_Rescued();
			}

			UP3HealthPointComponent* HPComp = Character->GetP3HealthComponentBP();

			if (ensure(HPComp))
			{
				HPComp->SetHealthPoint(HPComp->GetMaxHealthPoint());
			}

			FP3CommandRequestParams Params;
			Params.Teleport_Location = RestartTransform.GetLocation();
			Params.Teleport_Rotation = RestartTransform.GetRotation().Rotator();
			CommandComp->RequestCommand(UP3TeleportCommand::StaticClass(), Params);
		}

		if (IsTempWeapon(Character->GetRightHandWeaponType()))
		{
			FP3CommandRequestParams CommandParams;
			if (ensure(UP3RecoveryAfterTempWeaponCommand::Server_BuildParams(GetWorld(), *Character, CommandParams)))
			{
				Character->GetCommandComponent()->RequestCommand(UP3RecoveryAfterTempWeaponCommand::StaticClass(), CommandParams);
			}
		}

		FP3CommandRequestParams Params;
		Params.ChangeStance_NewStance = EP3CharacterStance::Idle;
		CommandComp->RequestCommand(UP3ChangeStanceCommand::StaticClass(), Params);
	}
}

void AP3BossChallengeActor::Server_ResetActorsAfterSuccess()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (TActorIterator<AP3PawnSpawnerActor> Iter(GetWorld()); Iter; ++Iter)
	{
		AP3PawnSpawnerActor* Actor = *Iter;
		if (Actor)
		{
			Actor->Reset();
		}
	}

	for (TActorIterator<AP3Character> Iter(GetWorld()); Iter; ++Iter)
	{
		AP3Character* Character = *Iter;
		if (Character && Character->IsPlayerControlled())
		{
			Character->Server_InitDefaultItems();
		}
	}
}

void UP3BossChallengeComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this) && ensure(BossChallengeActorClass.Get()))
	{
		FActorSpawnParameters SpawnParams;
		SpawnParams.Instigator = Cast<APawn>(GetOwner());

		Server_ChallengeActor = GetWorld()->SpawnActor<AP3BossChallengeActor>(BossChallengeActorClass.Get(), SpawnParams);
	}
}
