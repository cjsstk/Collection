// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "P3Actor.h"
#include "P3BossChallenge.generated.h"

/**
 * Manage boss challenge event
 * Must be attached to boss character
 * Has Success/Fail condition
 * Handles these two condition by playing level sequence and reset players and level actors

 * Notice this actor should be Singleton in World.
 * because UI visibility is controled by this actor.
 */
UCLASS(Blueprintable, ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API AP3BossChallengeActor : public AP3Actor
{
	GENERATED_BODY()

public:
	void Server_OnPlayerDead(const AActor& PlayerActor);

	/** AP3Actor */
	virtual void Tick(float DeltaSeconds) override;
	virtual void NetSerialize(FArchive& Archive) override;

	void Client_ResetUI();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Client_OnEvent(FName EventName, int32 Param) override;

private:
	void Server_Tick(float TickSeconds);

	void Client_OnStartChallenge();
	void Client_OnUpdateTimer();
	void Client_OnFinishChallenge();

	UFUNCTION()
	void OnFailedSequenceStop();

	UFUNCTION()
	void OnFailedSequenceFinished();

	UFUNCTION()
	void OnSucceededSequenceStop();

	UFUNCTION()
	void OnSucceededSequenceFinished();

	UFUNCTION()
	void Server_OnOwnerDead();

	void Server_OnFailed();
	void Server_OnSucceeded();
	void Server_OnTimeOverd();

	UFUNCTION()
	void Multicast_PlayFailedSequence();
	void Multicast_PlaySucceededSequence();

	void Server_ResetActorsAfterFail();
	void Server_ResetActorsAfterSuccess();

	enum class EState
	{
		Invalid,
		Idle,
		Failed,
		Succeeded,
	};

	const static FName NAME_PlayFailedSequence;
	const static FName NAME_PlaySucceededSequence;

	/** If set > 0, when player died more than this number, challenge is failed */
	UPROPERTY(EditDefaultsOnly, Category = "Fail Condition")
	int32 NumMaxPlayerDead = 5;

	/** If time is over, challenge is failed */
	UPROPERTY(EditDefaultsOnly, Category = "Fail Condition")
	float TimeLimitSeconds = 1200.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Message")
	TMap<float, FText> NotifyMessages;

	UPROPERTY(EditDefaultsOnly, Category = "Message")
	FText StartMessage;

	UPROPERTY(EditDefaultsOnly, Category = "Message")
	FText TimeOverMessage;

	/** To avoid dulpicated notification */
	TSet<float> Server_SentNotifyKeys;

	float Net_ChallengeLeftTimeSeconds = -1.0f;
	float Net_ExtraTimeLimitSeconds = 0.0f;

	/** Any actors with this gameplay tag will be reset on both fail and success */
	// TODO	: Success 에선 하지 않고 있으므로 변수명을 바꾸거나, Success 때도 하게 변경하기
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FGameplayTagContainer ResetOnFailOrSuccessActorGameplayTagsAny;

	UPROPERTY(EditAnywhere, Category = "Failed")
	class ULevelSequence* FailedLevelSequence;

	UPROPERTY(EditAnywhere, Category = "Succeeded")
	class ULevelSequence* SucceededLevelSequence;

	EState Net_CurrentState = EState::Invalid;

	UPROPERTY(Transient)
	class ALevelSequenceActor* LevelSequenceActor;

	int32 Server_NumPlayerDead = 0;
};

/**
 * Spawn AP3BossChallengeActor and attach it to owner actor via Instigator
 */
UCLASS(Blueprintable, ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3BossChallengeComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	AP3BossChallengeActor* Server_GetBossChallengeActor() const { return Server_ChallengeActor; }

protected:
	virtual void BeginPlay() override;

private:
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<AP3BossChallengeActor> BossChallengeActorClass;

	UPROPERTY(Transient)
	AP3BossChallengeActor* Server_ChallengeActor;
};
