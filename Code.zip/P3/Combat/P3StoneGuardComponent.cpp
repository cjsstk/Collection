// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3StoneGuardComponent.h"

#include "Components/PrimitiveComponent.h"
#include "Engine/World.h"
#include "GameplayTagAssetInterface.h"

#include "Action/P3PawnActionComponent.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3Destructible.h"
#include "P3Log.h"
#include "P3PainCausingComponent.h"

const FName UP3StoneGuardComponent::NAME_StartOrbiting = FName(TEXT("StartOrbiting"));
const FName UP3StoneGuardComponent::NAME_PrepareBlast = FName(TEXT("PrepareBlast"));

UP3StoneGuardComponent::UP3StoneGuardComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3StoneGuardComponent::Server_PrepareBlast()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (AActor* StoneActor : Server_StoneActors)
	{
		if (!StoneActor)
		{
			continue;
		}

		AP3Actor* P3StoneActor = Cast<AP3Actor>(StoneActor);
		if (P3StoneActor)
		{
			P3StoneActor->Server_MulticastEvent(NAME_PrepareBlast, 0);
		}
	}

	CurrentState = EState::Raising;
	Server_RaisingAgeSeconds = 0;
}

void UP3StoneGuardComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_FindStones();
		Server_StartPullingIn();
	}
}

void UP3StoneGuardComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		switch (CurrentState)
		{
		case EState::PullingIn:
			Server_TickPullingIn(DeltaTime);
			break;

		case EState::Orbiting:
			Server_TickOrbiting(DeltaTime);
			break;

		case EState::Raising:
			Server_TickRaising(DeltaTime);
			break;

		case EState::Blasting:
			Server_BlastingAgeSeconds += DeltaTime;
			if (Server_BlastingAgeSeconds > 1.0f)
			{
				// TODO: I thought I need to do something here... but I decide not to. Maybe need to change my mind again?

				Server_StoneActors.Empty();
				DestroyComponent();
			}
			break;
		}
	}
}

void UP3StoneGuardComponent::Server_FindStones()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)) || !GetWorld())
	{
		return;
	}

	Server_StoneActors.Empty();

	if (GameplayTagsAny.Num() == 0)
	{
		// If gameplay tag is empty, we can't select which one to pull
		ensure(0);
		P3JsonLog(Warning, "Gameplay tag is empty", TEXT("Actor"), GetOwner() ? GetOwner()->GetName() : TEXT("NULL"));
		return;
	}

	{
		FCollisionObjectQueryParams ObjectParams(FCollisionObjectQueryParams::AllDynamicObjects);
		FCollisionQueryParams QueryParams;
		FCollisionShape Sphere;
		Sphere.SetSphere(StoneSearchRadius);

		TArray<struct FOverlapResult> Overlaps;

		GetWorld()->OverlapMultiByObjectType(Overlaps, GetComponentLocation(), FQuat::Identity, ObjectParams, Sphere, QueryParams);

		for (const FOverlapResult& Overlap : Overlaps)
		{
			AActor* OverlapActor = Overlap.Actor.Get();
			
			if (!OverlapActor)
			{
				continue;
			}

			if (OverlapActor->GetAttachParentActor())
			{
				continue;
			}

			IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(OverlapActor);
			if (GameplayTagAsset)
			{
				const bool bTagFound = GameplayTagAsset->HasAnyMatchingGameplayTags(GameplayTagsAny);
				if (bTagFound)
				{
					Server_StoneActors.AddUnique(OverlapActor);
				}
			}
		}
	}

	for (AActor* StoneActor : Server_StoneActors)
	{
		AP3Destructible* Destructible = Cast<AP3Destructible>(StoneActor);

		if (Destructible)
		{
			Destructible->Server_SetHitIgnoreActors(Server_StoneActors);
			Destructible->Server_AddHitIgnoreActor(GetOwner());
			Destructible->Server_SetExplosionIgnoreActors(Server_StoneActors);
			Destructible->Server_AddExplosionIgnoreActor(GetOwner());
		}

		Server_StoneZOffsets.Add(FMath::RandRange(OrbitMinHeightRange, OrbitMaxHeightRange));

		StoneActor->SetLifeSpan(15.0f);
	}
}

void UP3StoneGuardComponent::Server_FindTargetLocations()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)) || !GetWorld())
	{
		return;
	}

	Server_TargetCharacterLocations.Empty();

	FCollisionObjectQueryParams ObjectParams(FCollisionObjectQueryParams::AllDynamicObjects);
	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(GetOwner());

	FCollisionShape Sphere;
	Sphere.SetSphere(TargetSearchRadius);

	TArray<struct FOverlapResult> Overlaps;

	GetWorld()->OverlapMultiByObjectType(Overlaps, GetComponentLocation(), FQuat::Identity, ObjectParams, Sphere, QueryParams);

	for (const FOverlapResult& Overlap : Overlaps)
	{
		AP3Character* OverlapCharacter = Cast<AP3Character>(Overlap.Actor.Get());
		if (!OverlapCharacter)
		{
			continue;
		}

		const FVector& TargetLocation = OverlapCharacter->GetActorLocation();

		const float TargetDistanceSquared = FVector::DistSquared(GetComponentLocation(), TargetLocation);

		if (TargetDistanceSquared < OrbitRadius * OrbitRadius)
		{
			continue;
		}

		Server_TargetCharacterLocations.Add(TargetLocation);
	}
}

void UP3StoneGuardComponent::Server_StartPullingIn()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	ensure(CurrentState == EState::Idle);

	CurrentState = EState::PullingIn;
	Server_PullingAgeSeconds = 0;

	for (AActor* StoneActor : Server_StoneActors)
	{
		if (!StoneActor)
		{
			continue;
		}

		StoneActor->DisableComponentsSimulatePhysics();
		
		UP3PainCausingComponent* PainCausingComp = StoneActor->FindComponentByClass<UP3PainCausingComponent>();
		if (PainCausingComp)
		{
			PainCausingComp->Activate();
		}
	}
}

void UP3StoneGuardComponent::Server_StartOrbit()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	ensure(CurrentState == EState::PullingIn);

	for (AActor* StoneActor : Server_StoneActors)
	{
		if (!StoneActor)
		{
			continue;
		}

		AP3Actor* P3StoneActor = Cast<AP3Actor>(StoneActor);
		if (P3StoneActor)
		{
			P3StoneActor->Server_MulticastEvent(NAME_StartOrbiting, 0);
		}
	}

	CurrentState = EState::Orbiting;
}

void UP3StoneGuardComponent::Server_TickPullingIn(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_PullingAgeSeconds = FMath::Min(Server_PullingAgeSeconds + DeltaSeconds, PullInDurationSeconds);

	const FVector MyLocation = GetComponentLocation();
	const FQuat MyQuat = GetComponentQuat();
	const FVector CenterLocation = MyLocation + MyQuat.RotateVector(OrbitCenterOffset);

	/** For pull in stone to horizontal */
	//const FVector MyUp = GetComponentQuat().GetUpVector();
	const FVector MyUp = FVector(0, 0, 1);

	bool bStillPullingIn = false;

	check(Server_StoneActors.Num() == Server_StoneZOffsets.Num());

	for (int32 StoneIndex = 0; StoneIndex < Server_StoneActors.Num(); ++StoneIndex)
	{
		AActor* StoneActor = Server_StoneActors[StoneIndex];

		if (!StoneActor)
		{
			continue;
		}

		// Stone has own blueprint timeline which enable physics
		// And if stone is spawned too late, it might still physicalized
		StoneActor->DisableComponentsSimulatePhysics();

		const FVector StoneLocation = StoneActor->GetActorLocation();
		FVector CenterToStoneDir = (StoneLocation - CenterLocation).GetSafeNormal();
		CenterToStoneDir -= (CenterToStoneDir | MyUp) * MyUp;
		const FVector OrbitLocation = CenterLocation + (CenterToStoneDir * OrbitRadius) + (MyUp * Server_StoneZOffsets[StoneIndex]);

		const float DistanceToOrbitSquared = (OrbitLocation - StoneLocation).SizeSquared();
		if (DistanceToOrbitSquared > 10.0f)
		{
			bStillPullingIn = true;

			const float Alpha = (PullInDurationSeconds > SMALL_NUMBER) ? FMath::Clamp(Server_PullingAgeSeconds / PullInDurationSeconds, 0.0f, 1.0f) : 1.0f;

			const FVector NewStoneLocation = FMath::Lerp(StoneLocation, OrbitLocation, Alpha);

			StoneActor->SetActorLocation(NewStoneLocation);
		}
	}

	if (!bStillPullingIn || (Server_PullingAgeSeconds >= PullInDurationSeconds))
	{
		// Pulling process is finished, lets do some orbiting
		Server_StartOrbit();
	}
}

void UP3StoneGuardComponent::Server_TickOrbiting(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const FVector MyLocation = GetComponentLocation();
	const FQuat MyQuat = GetComponentQuat();
	const FVector CenterLocation = MyLocation + MyQuat.RotateVector(OrbitCenterOffset);
	const FRotator OrbitDeltaRotation = FRotator(0, DeltaSeconds * OrbitAngularVelocityInDegrees, 0);

	check(Server_StoneActors.Num() == Server_StoneZOffsets.Num());

	for (AActor* StoneActor : Server_StoneActors)
	{
		if (!StoneActor)
		{
			continue;
		}

		const FVector StoneLocation = StoneActor->GetActorLocation();
		const FVector CenterToStoneDir = (StoneLocation - CenterLocation).GetSafeNormal();

		/** For rotate stone to horizontal always */
		/*const FVector CenterToStoneLocalDir = MyQuat.UnrotateVector(CenterToStoneDir);
		const FVector NewOrbitLocalLocation = OrbitDeltaRotation.RotateVector(CenterToStoneLocalDir * OrbitRadius);
		const FVector NewOrbitLocation = CenterLocation + MyQuat.RotateVector(NewOrbitLocalLocation);*/

		const FVector NewOrbitLocalLocation = OrbitDeltaRotation.RotateVector(CenterToStoneDir * OrbitRadius);
		const FVector NewOrbitLocation = CenterLocation + NewOrbitLocalLocation;

		StoneActor->SetActorLocation(NewOrbitLocation);
	}
}

void UP3StoneGuardComponent::Server_TickRaising(float DeltaSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_RaisingAgeSeconds += DeltaSeconds;

	for (AActor* StoneActor : Server_StoneActors)
	{
		if (!StoneActor)
		{
			continue;
		}

		const float Speed = RaisingDurationSeconds > 0 ? FMath::RandRange(RaisingMinHeight, RaisingMaxHeight) / RaisingDurationSeconds : 0.0f;

		StoneActor->AddActorWorldOffset(FVector(0, 0, Speed * DeltaSeconds), true);
	}

	if (Server_RaisingAgeSeconds >= RaisingDurationSeconds)
	{
		Server_Blast();
	}
}

void UP3StoneGuardComponent::Server_Blast()
{
	CurrentState = EState::Blasting;
	Server_BlastingAgeSeconds = 0;

	Server_FindTargetLocations();

	TMap<FVector, int32> SelectedTargetLocations;

	const FVector MyLocation = GetComponentLocation();

	if (MaxStoneNumForOnePlayer > 0)
	{
		for (const FVector& TargetCharacterLocation : Server_TargetCharacterLocations)
		{
			Server_StoneActors.Sort([TargetCharacterLocation](const AActor& Lhs, const AActor& Rhs) -> bool
			{
				const FVector LhsLocation = Lhs.GetActorLocation();
				const FVector RhsLocation = Rhs.GetActorLocation();

				float LhsSquaredDistance = FVector::DistSquared(TargetCharacterLocation, LhsLocation);
				float RhsSquaredDistance = FVector::DistSquared(TargetCharacterLocation, RhsLocation);

				return (LhsSquaredDistance < RhsSquaredDistance);
			});

			TArray<AActor*> StonesToRemove;

			for (AActor* StoneActor : Server_StoneActors)
			{
				if (!StoneActor)
				{
					continue;
				}

				int32* SelectedNum = SelectedTargetLocations.Find(TargetCharacterLocation);
				if (SelectedNum && *SelectedNum >= MaxStoneNumForOnePlayer)
				{
					break;
				}

				UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(StoneActor->GetRootComponent());
				if (!ensure(PrimComp))
				{
					continue;
				}

				if (SelectedNum)
				{
					*SelectedNum += 1;
				}
				else
				{
					SelectedTargetLocations.Add(TargetCharacterLocation, 1);
				}

				// Shoot
				AP3Destructible* Destructible = Cast<AP3Destructible>(StoneActor);
				if (Destructible)
				{
					Destructible->Server_SetMinImpulseSizeToExplode(1);
				}

				const FVector StoneLocation = StoneActor->GetActorLocation();
				const FVector TargetLocation = TargetCharacterLocation + FVector(0, 0, TargetLocationZOffset);

				FVector StoneToTargetDir = (TargetLocation - StoneLocation).GetSafeNormal();

				const float BlastSpeed = FMath::RandRange(BlastMinSpeed, BlastMaxSpeed);

				PrimComp->SetSimulatePhysics(true);
				PrimComp->SetPhysicsLinearVelocity(StoneToTargetDir * BlastSpeed);

				UP3PainCausingComponent* PainCausingComp = StoneActor->FindComponentByClass<UP3PainCausingComponent>();
				if (PainCausingComp)
				{
					PainCausingComp->Deactivate();
				}

				StonesToRemove.Add(StoneActor);
			}

			// Remove shot stones
			for (AActor* RemovedStone : StonesToRemove)
			{
				Server_StoneActors.Remove(RemovedStone);
			}
			StonesToRemove.Empty();
		}
	}

	// Shoot remained stones
	for (AActor* RemainedStoneActor : Server_StoneActors)
	{
		if (!RemainedStoneActor)
		{
			continue;
		}

		UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(RemainedStoneActor->GetRootComponent());
		if (!ensure(PrimComp))
		{
			continue;
		}

		AP3Destructible* Destructible = Cast<AP3Destructible>(RemainedStoneActor);
		if (Destructible)
		{
			Destructible->Server_SetMinImpulseSizeToExplode(1);
		}

		const FVector StoneLocation = RemainedStoneActor->GetActorLocation();
		FVector StoneToTargetDir = (StoneLocation - MyLocation).GetSafeNormal2D();

		const float BlastSpeed = FMath::RandRange(BlastMinSpeed, BlastMaxSpeed);

		PrimComp->SetSimulatePhysics(true);
		PrimComp->SetPhysicsLinearVelocity(StoneToTargetDir * BlastSpeed);

		UP3PainCausingComponent* PainCausingComp = RemainedStoneActor->FindComponentByClass<UP3PainCausingComponent>();
		if (PainCausingComp)
		{
			PainCausingComp->Deactivate();
		}
	}
}

UP3StoneGuardBlasterComponent::UP3StoneGuardBlasterComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3StoneGuardBlasterComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		UP3StoneGuardComponent* StoneGuardComp = GetOwner()->FindComponentByClass<UP3StoneGuardComponent>();
		if (ensure(StoneGuardComp))
		{
			StoneGuardComp->Server_PrepareBlast();
		}
	}
}

void UP3StoneGuardBlasterComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	DestroyComponent();
}
