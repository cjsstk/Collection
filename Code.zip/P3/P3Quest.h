// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Core.h"
#include "P3Cms.h"
#include "P3QuestDesc.h"
#include "P3Quest.generated.h"


DECLARE_MULTICAST_DELEGATE_OneParam(FP3OnQuestUpdated, questkey);

UENUM()
enum class EP3QuestState : uint8
{
	PrepareNextPhase,
	PhaseStart,
	CheckCondition,
	PrepareNextAction,
	DoAction,
	WaitingAction,
	Done,
	Invalid,
	Error,
};

// todo : maybe don't need this struct
USTRUCT()
struct FP3QuestData
{
	GENERATED_BODY()

	int32 PhaseIndex = -1;

	int32 ActionIndex = -1;

	UPROPERTY()
	EP3QuestState State = EP3QuestState::PrepareNextPhase;

	float ElapsedTimeSeconds = 0.0f;
};

const static FP3QuestData DEFAULT_QUEST_DATA;

inline FArchive& operator<<(FArchive& Archive, FP3QuestData& QuestData)
{
	Archive << QuestData.PhaseIndex;
	Archive << QuestData.ActionIndex;
	Archive << QuestData.State;
	Archive << QuestData.ElapsedTimeSeconds;

	return Archive;
}

UCLASS()
class UP3Quest : public UObject
{
	GENERATED_BODY()

public:
	/** Initialize */
	void InitQuest(class UP3QuestComponent* InQuestComponent, questkey InQuestKey);
	void InitQuestData(const FP3QuestData& InQuestData);

	/** Update quest data (used to client sync) */
	void UpdateQuestData(const FP3QuestData& InQuestData);

	/** Get quest data */
	void GetQuestData(FP3QuestData& QuestData) const;

	/** Some action is only in client */
	void OnActionFinishCallback();


	/** Tick */
	void Tick(float DeltaTimeSeconds);

	/** Proceed manually */
	bool ManuallyProceed();


	/** Quest Title */
	const FText& GetTitle() const;

	/** Quest Description */
	const FText& GetDescription() const;

	/** Quest Phase Description */
	const FText& GetPhaseDescription() const;


	/** Return true if data is valid */
	bool IsValid() const;

	/** Return true if data is valid and process(tick) is needed */
	bool IsActive() const;

	/** Return true if action is going on */
	bool IsWaitingActionFinished() const;

	/** Return true if phase is manually proceedable */
	bool IsManuallyProceedable() const;

	bool IsWatchingCutscene() const;


	FString GetDebugString(int32 DebugLevel) const;


	/** Update delegate (for client ui) */
	FP3OnQuestUpdated OnQuestUpdated;

private:
	bool CanNextPhase() const;
	bool CanNextAction() const;
	const UP3QuestActionDesc* GetNextAction() const;

	/**
	 * Check conditions
	 * @return true if all condition check succeed
	 */
	bool CheckConditions();
	bool CheckCondition(const UP3QuestConditionDesc* ConditionDesc);

	/**
	 * Do action
	 * @return whether we should wait something finished
	 * (Return value is important to handle quest state well)
	 */
	bool DoAction(const UP3QuestActionDesc* ActionDesc);

	/**
	 * Play FastForward
	 */
	void PlayFastForwardPhase(int32 InPhaseIndex, int32 ToActionIndex = -1, EP3QuestState InState = EP3QuestState::Done);

	/** For communicate with character and world */
	UPROPERTY(Transient)
	class UP3QuestComponent* QuestComponent = nullptr;

	questkey QuestKey = INVALID_QUESTKEY;

	UPROPERTY(EditDefaultsOnly)
	const UP3QuestDesc* QuestDesc;

	int32 PhaseIndex = -1;

	int32 ActionIndex = -1;

	UPROPERTY(Transient)
	EP3QuestState State = EP3QuestState::Invalid;

	float ElapsedTimeSeconds = 0.0f;
};

class UP3WorldNetBase;
class UP3QuestComponent;

struct FP3QuestUtil : FNoncopyable
{
	static void Server_CreateQuest(UP3WorldNetBase& WorldNet, UP3QuestComponent& QuestComp, charid CharacterId, questkey QuestKey);
	static void Server_UpdateQuest(UP3WorldNetBase& WorldNet, UP3QuestComponent& QuestComp, charid CharacterId, questkey QuestKey, EP3QuestState State, int32 PhaseIndex, int32 ActionIndex);

private:
	FP3QuestUtil();
};
