// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Components/BoxComponent.h"

#include "P3CombatShapeCollision.generated.h"

USTRUCT()
struct FP3OverlapCountBuffer
{
	GENERATED_BODY()

	int32 OverlapCount = 0;
	float OverlapStartTimeSeconds = 0.f;	
};

UCLASS(Blueprintable, meta = (BlueprintSpawnableComponent))
class P3_API UP3CombatBoxComponent : public UBoxComponent
{
	GENERATED_BODY()

public:
	UP3CombatBoxComponent();
	
	virtual void InitializeComponent() override;
	virtual void UninitializeComponent() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction) override;
	
	void ActivateCombatCollision(const FName& InCmsCombatHitKey, class AP3Character* InOwnerCharacter, int32 InMaxOverlapCount, float InOverlapBufferClearTimeSeconds);
	void DeactivateCombatCollision();

private:
	void TickDamageActor();

	FName CmsCombatHitKey = NAME_None;
	
	FVector LastUpdateLocation = FVector::ZeroVector;	

	int32 MaxOverlapCount = 0;
	float OverlapBufferClearTimeSeconds = 0.f;	

	UPROPERTY(Transient)
	TMap<AActor*, FP3OverlapCountBuffer> OverlapCountBuffer;

	UPROPERTY(Transient)
	AP3Character* OwnerCharacter = nullptr;
};

