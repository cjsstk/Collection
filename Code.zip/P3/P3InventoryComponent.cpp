// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3InventoryComponent.h"

#include "Components/PrimitiveComponent.h"
#include "Engine/World.h"
#include "GameFramework/Actor.h"

#include "Action/P3PawnActionComponent.h"
#include "Chemical/P3FlammableComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "Item/P3ItemManager.h"
#include "Network/P3WorldNet.h"
#include "Widget/P3BackpackInventoryWidget.h"
#include "P3Backpack.h"
#include "P3Character.h"
#include "P3Cms.h"
#include "P3ConsumableComponent.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3HoldableComponent.h"
#include "P3Log.h"
#include "P3PlayerController.h"
#include "P3Weapon.h"
#include "P3World.h"

static TAutoConsoleVariable<int32> CVarP3BackpackWeightOverride(
	TEXT("p3.backpackWeightOverride"),
	-1,
	TEXT("-1: Disable debug, 0: No backpack, 1: Light, 2: Middle, 3: Heavy"), ECVF_Cheat);

class FP3ItemIdFinder
{
public:
	FP3ItemIdFinder(FP3ItemId InItemId) : ItemId(InItemId) {}
	bool operator()(const FP3CharacterItem& CharacterItem) const
	{
		return CharacterItem.Item.Id == ItemId;
	}

private:
	FP3ItemId ItemId = INVALID_ITEMID;
};

class FP3ItemKeyFinder
{
public:
	FP3ItemKeyFinder(itemkey InItemCmsKey) : ItemCmsKey(InItemCmsKey) {}
	bool operator()(const FP3CharacterItem& CharacterItem) const
	{
		return CharacterItem.Item.Key == ItemCmsKey;
	}

private:
	itemkey ItemCmsKey = INVALID_ITEMKEY;
};

class FP3ItemSlotFinder
{
public:
	FP3ItemSlotFinder(EP3CharacterItemSlot InItemSlot) : ItemSlot(InItemSlot) {}
	bool operator()(const FP3CharacterItem& CharacterItem) const
	{
		return CharacterItem.Slot == ItemSlot;
	}

private:
	EP3CharacterItemSlot ItemSlot = EP3CharacterItemSlot::Invalid;
};



UP3InventoryComponent::UP3InventoryComponent()
{
	ThrowableQuickSlotItems.Init(INVALID_ITEMKEY, QuickSlotNum);
	ConsumableQuickSlotItems.Init(INVALID_ITEMKEY, QuickSlotNum);
}

void UP3InventoryComponent::BeginPlay()
{
	Super::BeginPlay();
}

uint64 UP3InventoryComponent::GetCharacterId() const
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!Character)
	{
		return INVALID_CHARID;
	}

	return Character->GetCharacterStoreBP().CharacterId;
}

void UP3InventoryComponent::Server_InitItems(const TArray<FP3CharacterItem>& Items)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (const FP3CharacterItem& CharacterItem : Items)
	{
		ensure(CharacterItem.Item.IsValid());
		ensure(!GetItem(CharacterItem.Item.Id).IsValid());

		Net_CharacterItems.Add(CharacterItem);
	}

	Server_SetDirty(*this);

	OnChangeConsumable.Broadcast();
}

bool UP3InventoryComponent::Server_AddItemByKeyAndCount(itemkey ItemKey, int32 Stack)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	FP3Item FoundItem = GetItemByKey(ItemKey);

	if (FoundItem.IsValid())
	{
		// Already have that item, just increase stack

		if (!ensure(Server_IncreaseItemStack(FoundItem.Id, Stack)))
		{
			P3JsonLog(Error, "Failed to increase item stack (failed to increase)",
				TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), GetCharacterId()),
				TEXT("ItemId"), *FoundItem.Id.ToString(),
				TEXT("CurStack"), FoundItem.Stack,
				TEXT("ReqStack"), Stack);
			return false;
		}
	}
	else
	{
		// Didn't have that item, add new item

		UP3ItemManager* ItemManager = P3Core::GetItemManager(*this);
		if (ensure(ItemManager))
		{
			const FP3Item NewItem = ItemManager->CreateItem(ItemKey, Stack, "UP3InventoryComponent::AddItemByKeyAndCount");

			if (!ensure(NewItem.IsValid()))
			{
				P3JsonLog(Error, "Failed to increase item stack (failed to create item)",
					TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), GetCharacterId()),
					TEXT("ItemId"), *NewItem.Id.ToString(),
					TEXT("ReqStack"), Stack);
				return false;
			}

			if (!ensure(Server_AddItem(NewItem, EP3CharacterItemSlot::Inventory)))
			{
				P3JsonLog(Error, "Failed to increase item stack (failed to add)",
					TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), GetCharacterId()),
					TEXT("ItemId"), *NewItem.Id.ToString(),
					TEXT("ReqStack"), Stack);
				return false;
			}
		};
	}

	return true;
}

bool UP3InventoryComponent::Server_RemoveItemByIdAndCount(FP3ItemId ItemId, int32 Stack)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	FP3Item Item = GetItem(ItemId);

	if (!ensure(Item.IsValid()))
	{
		P3JsonLog(Error, "Failed to decrease item stack (invalid)",
			TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), GetCharacterId()),
			TEXT("ItemId"), *ItemId.ToString(),
			TEXT("ReqStack"), Stack);
		return false;
	}

	if (!ensure(Item.Stack >= Stack))
	{
		P3JsonLog(Error, "Failed to decrease item stack (not enough stack)",
			TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), GetCharacterId()),
			TEXT("ItemId"), *ItemId.ToString(),
			TEXT("CurStack"), Item.Stack,
			TEXT("ReqStack"), Stack);
		return false;
	}

	if (Item.Stack == Stack)
	{
		if (!ensure(Server_RemoveItem(ItemId)))
		{
			P3JsonLog(Error, "Failed to decrease item stack (failed to decrease)",
				TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), GetCharacterId()),
				TEXT("ItemId"), *ItemId.ToString(),
				TEXT("CurStack"), Item.Stack,
				TEXT("ReqStack"), Stack);
			return false;
		}
	}
	else
	{
		if (!ensure(Server_DecreaseItemStack(ItemId, Stack)))
		{
			P3JsonLog(Error, "Failed to decrease item stack (failed to decrease)",
				TEXT("CharacterId"), *FString::Printf(TEXT("%lld"), GetCharacterId()),
				TEXT("ItemId"), *ItemId.ToString(),
				TEXT("CurStack"), Item.Stack,
				TEXT("ReqStack"), Stack);
			return false;
		}
	}

	return true;
}

bool UP3InventoryComponent::Server_AddItem(const FP3Item& Item, EP3CharacterItemSlot Slot)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (!ensure(Item.IsValid()))
	{
		return false;
	}

	if (!ensure(!GetItem(Item.Id).IsValid()))
	{
		return false;
	}

	Net_CharacterItems.Add(FP3CharacterItem{ Item, Slot });

	Server_SetDirty(*this);

	OnChangeConsumable.Broadcast();

	// Write to DB
	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (ensure(WorldNet) && ensure(Character))
	{
		WorldNet->SendCreateCharacterItem(Character->GetCharacterStoreBP().CharacterId, Item, Slot);
	}

	return true;
}

bool UP3InventoryComponent::Server_RemoveItem(FP3ItemId ItemId)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	bool bRemoved = false;

	for (auto Iter = Net_CharacterItems.CreateIterator(); Iter; ++Iter)
	{
		const FP3CharacterItem& CharacterItem = *Iter;
		if (CharacterItem.Item.Id == ItemId)
		{
			Iter.RemoveCurrent();

			Server_SetDirty(*this);

			OnChangeConsumable.Broadcast();

			bRemoved = true;

			break;
		}
	}

	if (bRemoved)
	{
		// Write to DB
		UP3WorldNetBase* WorldNet = P3GetWorldNet(this);
		AP3Character* Character = Cast<AP3Character>(GetOwner());

		if (ensure(WorldNet) && ensure(Character))
		{
			WorldNet->SendDeleteCharacterItem(Character->GetCharacterStoreBP().CharacterId, ItemId);
		}
	}

	return bRemoved;
}

bool UP3InventoryComponent::Server_IncreaseItemStack(FP3ItemId ItemId, int32 Stack)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	FP3CharacterItem* CharacterItem = Net_CharacterItems.FindByPredicate(FP3ItemIdFinder(ItemId));
	if (!CharacterItem)
	{
		return false;
	}

	// TODO: better check max stack count from CMS
	CharacterItem->Item.Stack += Stack;

	Server_SetDirty(*this);

	OnChangeConsumable.Broadcast();

	// Write to DB
	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (ensure(WorldNet) && ensure(Character))
	{
		WorldNet->SendUpdateCharacterItemStack(Character->GetCharacterStoreBP().CharacterId, ItemId, CharacterItem->Item.Stack);
	}

	return true;
}

bool UP3InventoryComponent::Server_DecreaseItemStack(FP3ItemId ItemId, int32 Stack)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	FP3CharacterItem* CharacterItem = Net_CharacterItems.FindByPredicate(FP3ItemIdFinder(ItemId));
	if (!CharacterItem || CharacterItem->Item.Stack <= Stack)
	{
		return false;
	}

	CharacterItem->Item.Stack -= Stack;

	Server_SetDirty(*this);

	OnChangeConsumable.Broadcast();

	// Write to DB
	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (ensure(WorldNet) && ensure(Character))
	{
		WorldNet->SendUpdateCharacterItemStack(Character->GetCharacterStoreBP().CharacterId, ItemId, CharacterItem->Item.Stack);
	}

	return true;
}

bool UP3InventoryComponent::Server_ChangeItemSlot(FP3ItemId ItemId, EP3CharacterItemSlot Slot)
{
	// TODO: Need better idea here
	// Changing weapon depends on the order of holdables in bag
	// So we need to remove an item and append it to the end of bag

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	FP3Item Item = GetItem(ItemId);
	if (!ensure(Item.IsValid()))
	{
		return false;
	}

	if (!ensure(Slot != EP3CharacterItemSlot::Invalid))
	{
		return false;
	}

	Server_RemoveItem(ItemId);
	Server_AddItem(Item, Slot);

	return true;
}

AActor* UP3InventoryComponent::SpawnItemActor(FP3ItemId ItemId) const
{
	const FP3Item Item = GetItem(ItemId);

	if (!ensure(Item.IsValid()))
	{
		return nullptr;
	}

	AActor* Actor = FP3ItemUtil::SpawnItemActor(GetWorld(), Item.Key);

	return Actor;
}

FP3Item UP3InventoryComponent::GetItem(FP3ItemId ItemId) const
{
	const FP3CharacterItem* CharacterItem = Net_CharacterItems.FindByPredicate(FP3ItemIdFinder(ItemId));
	return CharacterItem ? CharacterItem->Item : FP3Item::InvalidItem;
}

FP3Item UP3InventoryComponent::GetItemByKey(itemkey CmsKey) const
{
	const FP3CharacterItem* CharacterItem = Net_CharacterItems.FindByPredicate(FP3ItemKeyFinder(CmsKey));
	return CharacterItem ? CharacterItem->Item : FP3Item::InvalidItem;
}

FP3Item UP3InventoryComponent::GetItemBySlot(EP3CharacterItemSlot Slot) const
{
	const FP3CharacterItem* CharacterItem = Net_CharacterItems.FindByPredicate(FP3ItemSlotFinder(Slot));
	return CharacterItem ? CharacterItem->Item : FP3Item::InvalidItem;
}

TArray<FP3Item> UP3InventoryComponent::GetItemsBySlot(EP3CharacterItemSlot Slot, bool bExcludeWeapons) const
{
	TArray<FP3Item> InventoryItems;

	for (const FP3CharacterItem& CharacterItem : Net_CharacterItems)
	{
		if (CharacterItem.Slot == EP3CharacterItemSlot::Inventory)
		{
			// Exclude weapons
			if (bExcludeWeapons)
			{
				const FP3CmsHoldable* ItemHoldable = P3Cms::GetItemHoldable(CharacterItem.Item.Key);
				if (ItemHoldable)
				{
					continue;
				}
			}

			InventoryItems.Add(CharacterItem.Item);
		}
	}

	return InventoryItems;
}

FP3Item UP3InventoryComponent::FindHoldableItem(EP3HoldType HoldType, EP3WeaponType WeaponType) const
{
	for (const FP3CharacterItem& CharacterItem : Net_CharacterItems)
	{
		if (CharacterItem.Slot != EP3CharacterItemSlot::Inventory)
		{
			continue;
		}

		const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(CharacterItem.Item.Key);
		if (CmsHoldable && CmsHoldable->HoldTypes.Contains(HoldType))
		{
			if (WeaponType == EP3WeaponType::None || WeaponType == CmsHoldable->WeaponType)
			{
				return CharacterItem.Item;
			}
		}
	}

	return FP3Item::InvalidItem;
}

bool UP3InventoryComponent::HasItem(FP3ItemId ItemId) const
{
	return Net_CharacterItems.ContainsByPredicate(FP3ItemIdFinder(ItemId));
}

bool UP3InventoryComponent::HasTempWeapon() const
{
	for (const FP3CharacterItem& CharacterItem : Net_CharacterItems)
	{
		const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(CharacterItem.Item.Key);

		if (CmsHoldable && IsTempWeapon(CmsHoldable->WeaponType))
		{
			return true;
		}
	}

	return false;
}

int32 UP3InventoryComponent::GetNumItemsByKey(itemkey ItemKey) const
{
	int32 Sum = 0;

	for (const FP3CharacterItem& CharacterItem : Net_CharacterItems)
	{
		if (CharacterItem.Item.Key == ItemKey)
		{
			Sum += CharacterItem.Item.Stack;
		}
	}

	return Sum;
}

bool UP3InventoryComponent::CanAddItem(itemkey ItemKey, int32 Amount) const
{
	const FP3CmsItem& ItemDesc = P3Cms::GetItem(ItemKey);
	if (ItemDesc.MaxCountInInventory <= 0)
	{
		return true;
	}

	if (GetNumItemsByKey(ItemKey) + Amount <= ItemDesc.MaxCountInInventory)
	{
		return true;
	}

	return false;
}

TArray<FP3Item> UP3InventoryComponent::GetThrowableItems(bool bOnlyQuickSlot) const
{
	TArray<FP3Item> ThrowableItems;

	if (bOnlyQuickSlot)
	{
		for (itemkey ItemKey : ThrowableQuickSlotItems)
		{
			if (ItemKey == INVALID_ITEMKEY)
			{
				continue;
			}

			const FP3CmsThrowable* ItemThrowable = P3Cms::GetItemThrowable(ItemKey);
			FP3Item QuickSlotItem = GetItemByKey(ItemKey);
			if (ItemThrowable && QuickSlotItem.IsValid())
			{
				ThrowableItems.Add(QuickSlotItem);
			}
		}
	}
	else
	{
		for (const FP3CharacterItem& CharacterItem : Net_CharacterItems)
		{
			if (CharacterItem.Slot != EP3CharacterItemSlot::Inventory)
			{
				continue;
			}

			// Exclude weapons
			const FP3CmsHoldable* ItemHoldable = P3Cms::GetItemHoldable(CharacterItem.Item.Key);
			const FP3CmsThrowable* ItemThrowable = P3Cms::GetItemThrowable(CharacterItem.Item.Key);
			if (ItemHoldable || !ItemThrowable)
			{
				continue;
			}

			ThrowableItems.Add(CharacterItem.Item);
		}
	}

	return ThrowableItems;
}

TArray<FP3Item> UP3InventoryComponent::GetConsumableItems(bool bOnlyQuickSlot) const
{
	TArray<FP3Item> ConsumableItems;

	if (bOnlyQuickSlot)
	{
		for (itemkey ItemKey : ConsumableQuickSlotItems)
		{
			if (ItemKey == INVALID_ITEMKEY)
			{
				continue;
			}

			const FP3CmsConsumable* ItemConsumable = P3Cms::GetItemConsumable(ItemKey);
			FP3Item QuickSlotItem = GetItemByKey(ItemKey);
			if (ItemConsumable && QuickSlotItem.IsValid())
			{
				ConsumableItems.Add(QuickSlotItem);
			}
		}
	}
	else
	{
		for (const FP3CharacterItem& CharacterItem : Net_CharacterItems)
		{
			if (CharacterItem.Slot != EP3CharacterItemSlot::Inventory)
			{
				continue;
			}

			// Exclude weapons
			const FP3CmsHoldable* ItemHoldable = P3Cms::GetItemHoldable(CharacterItem.Item.Key);
			const FP3CmsConsumable* ItemConsumable = P3Cms::GetItemConsumable(CharacterItem.Item.Key);
			if (ItemHoldable || !ItemConsumable)
			{
				continue;
			}

			ConsumableItems.Add(CharacterItem.Item);
		}
	}

	return ConsumableItems;
}

bool UP3InventoryComponent::HasConsumable(FP3ItemId ItemId) const
{
	for (const FP3CharacterItem& CharacterItem : Net_CharacterItems)
	{
		if (CharacterItem.Slot != EP3CharacterItemSlot::Inventory)
		{
			continue;
		}

		if (CharacterItem.Item.Id == ItemId)
		{
			return P3Cms::GetItemConsumable(CharacterItem.Item.Key) != nullptr;
		}
	}

	return false;
}

const TArray<itemkey>& UP3InventoryComponent::GetQuickSlotItems(EP3InventoryQuickSlotType QuickSlotType) const
{
	static TArray<itemkey> DummyQuickSlotItems;

	switch (QuickSlotType)
	{
	case EP3InventoryQuickSlotType::Throwable:
		return ThrowableQuickSlotItems;
	case EP3InventoryQuickSlotType::Consumable:
		return ConsumableQuickSlotItems;
	default:
		ensure(0);
		break;
	}

	return DummyQuickSlotItems;
}

void UP3InventoryComponent::SetQuickSlotItem(EP3InventoryQuickSlotType QuickSlotType, int32 QuickSlotIndex, itemkey NewItemKey)
{
	switch (QuickSlotType)
	{
	case EP3InventoryQuickSlotType::Throwable:
	{
		int32 PrevIndex = ThrowableQuickSlotItems.IndexOfByKey(NewItemKey);
		if (PrevIndex != INDEX_NONE)
		{
			ThrowableQuickSlotItems[PrevIndex] = INVALID_ITEMKEY;
		}

		if (ThrowableQuickSlotItems.IsValidIndex(QuickSlotIndex))
		{
			ThrowableQuickSlotItems[QuickSlotIndex] = NewItemKey;
		}
		break;
	}
	case EP3InventoryQuickSlotType::Consumable:
	{
		int32 PrevIndex = ConsumableQuickSlotItems.IndexOfByKey(NewItemKey);
		if (PrevIndex != INDEX_NONE)
		{
			ConsumableQuickSlotItems[PrevIndex] = INVALID_ITEMKEY;
		}

		if (ConsumableQuickSlotItems.IsValidIndex(QuickSlotIndex))
		{
			ConsumableQuickSlotItems[QuickSlotIndex] = NewItemKey;
		}
		break;
	}
	default:
		ensure(0);
		break;
	}

	OnChangeQuickSlot.Broadcast();
}

void UP3InventoryComponent::SetBackpackActor(class AP3Backpack* InBackpackActor)
{
	if (MyBackpackActor && InBackpackActor)
	{
		ensure(0);
		return;
	}

	MyBackpackActor = InBackpackActor;
}

EP3BackpackWeight UP3InventoryComponent::GetBackpackWeight() const
{
	if (CVarP3BackpackWeightOverride.GetValueOnGameThread() >= 0)
	{
		return (EP3BackpackWeight)(CVarP3BackpackWeightOverride.GetValueOnGameThread());
	}

	int32 BackpackItemNum = GetItemsBySlot(EP3CharacterItemSlot::Backpack, true).Num();
	int32 ItemNumPercentage = (BackpackItemNum * 100 / BackpackSizeNum);

	return ItemNumPercentage >= ItemNumPercentageForHeavy ? EP3BackpackWeight::Heavy : ItemNumPercentage >= ItemNumPercentageForMiddle ? EP3BackpackWeight::Middle : EP3BackpackWeight::Light;
}

void UP3InventoryComponent::NetSerialize(FArchive& Archive)
{
	if (!Archive.IsLoading())
	{
		Archive << Net_CharacterItems;
	}
	else
	{
		TArray<FP3CharacterItem> NewCharacterItems;
		Archive << NewCharacterItems;

		TArray<FP3CharacterItem> AddedCharacterItems, RemovedCharacterItems;
		_DiffArray(Net_CharacterItems, NewCharacterItems, &AddedCharacterItems, &RemovedCharacterItems);

		Net_CharacterItems = MoveTemp(NewCharacterItems);

		SortInvenItems();

		if (AddedCharacterItems.ContainsByPredicate(FP3ItemSlotFinder(EP3CharacterItemSlot::Inventory)) ||
			RemovedCharacterItems.ContainsByPredicate(FP3ItemSlotFinder(EP3CharacterItemSlot::Inventory)))
		{
			OnChangeConsumable.Broadcast();
		}
	}
}

void UP3InventoryComponent::SortInvenItems()
{
	Net_CharacterItems.StableSort([](const FP3CharacterItem& A, const FP3CharacterItem& B) {
		const FP3CmsItem& ItemADesc = P3Cms::GetItem(A.Item.Key);
		const FP3CmsItem& ItemBDesc = P3Cms::GetItem(B.Item.Key);

		if (ItemADesc.Category == ItemBDesc.Category)
		{
			return A.Item.Key < B.Item.Key;
		}

		return ItemADesc.Category < ItemBDesc.Category;
	});
}
