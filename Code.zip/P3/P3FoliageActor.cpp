// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3FoliageActor.h"

#include "Components/StaticMeshComponent.h"
#include "DestructibleActor.h"
#include "DestructibleComponent.h"

#include "P3Core.h"
#include "P3DestructibleComponent.h"

const static FName CollisionProfileNameFoliage(TEXT("GrassFoliage"));

AP3FoliageActor::AP3FoliageActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;

	bReplicateMovement = false;

	DestructibleComponent = CreateDefaultSubobject<UP3DestructibleComponent>(TEXT("DestructibleComponent"));

	if (DestructibleComponent)
	{
		DestructibleComponent->SetMobility(EComponentMobility::Stationary);
		DestructibleComponent->SetupDestructible(true, 1, 0.0f);
		DestructibleComponent->SetCollisionProfileName(CollisionProfileNameFoliage);

		// Let leaves fall through everything, which Hani says to be better
		FCollisionResponseContainer CollisionResponse;
		CollisionResponse.SetAllChannels(ECR_Ignore);

		DestructibleComponent->OverrideDebrisCollisionResponse(CollisionResponse);

		RootComponent = DestructibleComponent;
	}
}
