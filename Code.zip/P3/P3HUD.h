// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/HUD.h"
#include "P3HUD.generated.h"

/**
 * In game HUD
 */
UCLASS()
class P3_API AP3HUD : public AHUD
{
	GENERATED_BODY()
	
public:
	class UP3InGameActionWidget* GetInGameActionWidget() const { return InGameActionWidget; }
	class UP3SubtitleWidget* GetSubtitleWidget() const { return SubtitleWidget; }

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

private:
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class UUserWidget> HealthBarsWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class UP3InGameActionWidget> InGameActionWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class UUserWidget> SubtitleWidgetClass;

	UPROPERTY(Transient)
	class UUserWidget* HealthBarsWidget;

	UPROPERTY(Transient)
	class UP3InGameActionWidget* InGameActionWidget;

	UPROPERTY(Transient)
	class UP3SubtitleWidget* SubtitleWidget;
};
