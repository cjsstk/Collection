// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ActorInterface.h"

#include "Engine/World.h"

#include "P3ServerWorld.h"
#include "P3World.h"

UP3ActorInterface::UP3ActorInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void IP3ActorInterface::RegisterToP3World(AActor& Self)
{
	UWorld* World = Self.GetWorld();

	if (World && World->IsGameWorld())
	{
		UP3World* P3World = P3Core::GetP3World(Self);

		if (ensure(P3World))
		{
			P3World->RegisterActor(Self);
		}
	}
}

void IP3ActorInterface::Server_SetDirty(AActor& Self)
{
	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(Self);

	if (ServerWorld)
	{
		ServerWorld->AddDirtyActor(GetActorId());
	}
}
