// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Actor.h"

#include "DrawDebugHelpers.h"

#include "P3Core.h"
#include "P3Store.h"
#include "P3World.h"
#include "P3WorldNetCore.h"

AP3Actor::AP3Actor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;

	bReplicates = true;
	bReplicateMovement = true;
	bAlwaysRelevant = true;
	bNetLoadOnClient = false;

	StoreComponent = CreateDefaultSubobject<UP3StoreComponent>(TEXT("StoreComponent"));
}

void AP3Actor::PostInitializeComponents()
{
	Super::PostInitializeComponents();

	RegisterToP3World(*this);
}

void AP3Actor::Client_NetAttachChanged()
{
	RecvAttachChanged();
}

void AP3Actor::AddDebugString(const FString& InDebugString, bool bAddNewLine /*= true*/)
{
	P3ActorDebugString += InDebugString;

	if (bAddNewLine)
	{
		P3ActorDebugString += TEXT("\n");
	}
}

UP3StoreComponent* AP3Actor::GetStoreComponent() const
{
	return StoreComponent;
}

void AP3Actor::Server_MulticastEvent(FName EventName, int32 Param)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Client_OnEvent(EventName, Param);

	ensure(ActorId != INVALID_ACTORID);

	UP3World* World = P3Core::GetP3World(*this);
	check(World);

	FNetP3ActorEvent NetEvent;
	NetEvent.EventName = EventName;
	NetEvent.Param = Param;

	World->Server_MulticastPacketReliable(this, ActorId, this, NetEvent, EP3NetComponentType::None, &AP3Actor::Client_HandleEvent);
}

void AP3Actor::Client_HandleEvent(const struct FP3DediToClientHandlerParams& Params)
{
	FNetP3ActorEvent NetEvent;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetEvent);

	if (ensure(bSerializeSucceeded))
	{
		Client_OnEvent(NetEvent.EventName, NetEvent.Param);
	}
}

void AP3Actor::AddGameplayTags(const FGameplayTagContainer& TagContainer)
{
	GameplayTagContainer.AppendTags(TagContainer);
}

void AP3Actor::RemoveGameplayTags(const FGameplayTagContainer& TagContainer)
{
	GameplayTagContainer.RemoveTags(TagContainer);
}

void AP3Actor::GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const
{
	TagContainer = GameplayTagContainer;
}

void AP3Actor::BeginPlay()
{
	Super::BeginPlay();

	ensureMsgf(bReplicates, TEXT("P3Actor must set bReplicates true. Name: %s"), *GetName());
	ensureMsgf(!bNetLoadOnClient, TEXT("P3Actor must set bNetLoadOnClient false. Name: %s"), *GetName());
}

void AP3Actor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	ensureMsgf(bReplicates, TEXT("P3Actor must set bReplicates true. Name: %s"), *GetName());
	ensureMsgf(!bNetLoadOnClient, TEXT("P3Actor must set bNetLoadOnClient false. Name: %s"), *GetName());

#if ENABLE_DRAW_DEBUG
	if (!P3ActorDebugString.IsEmpty())
	{
		DrawDebugString(GetWorld(), FVector(0, 0, 100), P3ActorDebugString, this, FColor::White, 0, true);
		P3ActorDebugString.Empty();
	}
#endif
}

void AP3Actor::Client_OnEvent(FName EventName, int32 Param)
{
	Client_RecvEvent(EventName, Param);
}
