#pragma once

#include "CoreMinimal.h"
#include "JsonWriter.h"
#include "Policies/CondensedJsonPrintPolicy.h"
#include "UObject/Package.h"

DECLARE_LOG_CATEGORY_EXTERN(P3Log, Display, All);
DECLARE_LOG_CATEGORY_EXTERN(P3ActionLog, Warning, All);
DECLARE_LOG_CATEGORY_EXTERN(P3CombatLog, Display, All);
DECLARE_LOG_CATEGORY_EXTERN(P3ComboLog, Display, All);
DECLARE_LOG_CATEGORY_EXTERN(P3PartCompLog, Display, All);
DECLARE_LOG_CATEGORY_EXTERN(P3NetLog, Display, All);
DECLARE_LOG_CATEGORY_EXTERN(P3WorldLog, Display, All);
DECLARE_LOG_CATEGORY_EXTERN(P3UDPNetLog, Log, All);
DECLARE_LOG_CATEGORY_EXTERN(P3WebSocketLog, Warning, All);

#define INT64_TO_STR(X) *FString::Printf(TEXT("%lld"), (X))
#define UINT64_TO_STR(X) *FString::Printf(TEXT("%llu"), (X))

void P3SendJsonLogToServer(const FString& JsonString);

template <typename JsonWriterType, typename ValueType>
typename TEnableIf<TAreTypesEqual<ValueType, FString>::Value || TIsPODType<ValueType>::Value>::Type P3MakeJsonLogInternalWriteValue(JsonWriterType& JsonWriter, const TCHAR* Key, const ValueType& Value)
{
	JsonWriter.WriteValue(Key, Value);
}


FString P3MakeJsonLogInteralWriteValue_ObjectToString(const UStruct* StructDefinition, const void* Struct);

template <typename JsonWriterType, typename ValueType>
typename TEnableIf<!TAreTypesEqual<ValueType, FString>::Value && !TIsPODType<ValueType>::Value>::Type P3MakeJsonLogInternalWriteValue(JsonWriterType& JsonWriter, const TCHAR* Key, const ValueType& Value)
{
	FString ObjectString = P3MakeJsonLogInteralWriteValue_ObjectToString(ValueType::StaticStruct(), &Value);

	JsonWriter.WriteRawJSONValue(Key, ObjectString);
}

template <typename JsonWriterType>
void P3MakeJsonLogInternalWriteValue(JsonWriterType& JsonWriter, const TCHAR* Key, const FName& Value)
{
	JsonWriter.WriteValue(Key, Value.ToString());
}

template <typename JsonWriterType>
inline void P3MakeJsonLogInternal(JsonWriterType& JsonWriter)
{
	// This is not a miss typing. This really is Empty. Just here to end recursion of variadic template
}

template <typename JsonWriterType, typename ValueType, typename ... RestKeyValueTypes>
inline void P3MakeJsonLogInternal(JsonWriterType& JsonWriter, const TCHAR* Key, const ValueType& Value, const RestKeyValueTypes&... RestKeyValues)
{
	static const int RestKeyValueCount = sizeof...(RestKeyValueTypes);
	static_assert(RestKeyValueCount % 2 == 0, "Json Log Parameter should be Key-Value pair!");

	P3MakeJsonLogInternalWriteValue(JsonWriter, Key, Value);

	if (RestKeyValueCount > 0)
	{
		P3MakeJsonLogInternal(JsonWriter, RestKeyValues...);
	}
}

extern TAutoConsoleVariable<int32> CVarP3JsonLogSingleLine;

template <typename ... KeyValueTypes>
inline FString P3MakeJsonLog(const TCHAR* Verbosity, const TCHAR* Subject, const KeyValueTypes&... KeyValues)
{
	static const int KeyValueCount = sizeof...(KeyValueTypes);
	static_assert(KeyValueCount % 2 == 0, "Json Log Parameter should be Key-Value pair!");

	FString JsonString;

	if (CVarP3JsonLogSingleLine.GetValueOnAnyThread() > 0)
	{
		TSharedRef<TJsonWriter<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>> JsonWriter = TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>::Create(&JsonString);
		P3MakeJsonLogString(JsonWriter.Get(), Verbosity, Subject, KeyValues...);
	}
	else
	{
		TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>> JsonWriter = TJsonWriterFactory<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>::Create(&JsonString);
		P3MakeJsonLogString(JsonWriter.Get(), Verbosity, Subject, KeyValues...);
	}

	P3SendJsonLogToServer(JsonString);

	return JsonString;
}

template <typename JsonWriterType, typename ... KeyValueTypes>
inline void P3MakeJsonLogString(JsonWriterType& JsonWriter, const TCHAR* Verbosity, const TCHAR* Subject, const KeyValueTypes&... KeyValues)
{
	static const int KeyValueCount = sizeof...(KeyValueTypes);

	JsonWriter.WriteObjectStart();
	JsonWriter.WriteValue(TEXT("Verbosity"), Verbosity);
	JsonWriter.WriteValue(TEXT("LogMessage"), Subject);

	if (KeyValueCount > 0)
	{
		P3MakeJsonLogInternal(JsonWriter, KeyValues...);
	}

	//if (CVarLogMemoryStats.GetValueOnAnyThread() != 0)
	//{
	//	JsonWriter.WriteValue(TEXT("Process Physical Memory (MB)"), int64(FPlatformMemory::GetStats().UsedPhysical / 1024 /1024));

	//	if (CVarLogMemoryStats.GetValueOnAnyThread() >= 2)
	//	{
	//		FGenericMemoryStats MemStat;
	//		GMalloc->GetAllocatorStats(MemStat);

	//		for (auto&& Iter : MemStat.Data)
	//		{
	//			JsonWriter.WriteValue(Iter.Key, (int64)Iter.Value);
	//		}
	//	}
	//}

	JsonWriter.WriteObjectEnd();
	JsonWriter.Close();
}

#if PLATFORM_LINUX
	#define _FUNCTION_TEXT ANSI_TO_TCHAR(__FUNCTION__)
#else
	#define _FUNCTION_TEXT TEXT(__FUNCTION__)
#endif

#if NO_LOGGING
	#define P3JsonLog(...)
#else // NO_LOGGING
	/**
		* P3JsonLog
		* Usage : Subject doesn't need to be wrapped by TEXT() macro
		*			any number of Key, Value pair can be followed
		* Example : P3JsonLog(Warning, "We have problem, Huston", TEXT("From"), SenderName, TEXT("Status"), Status)
	*/
	#define _STRINGIFY_INTERNAL(x) #x
	#define _STRINGIFY(x) _STRINGIFY_INTERNAL(x)
	#define _FILE_AND_LINE TEXT(__FILE__ "(" _STRINGIFY(__LINE__) ")")

	#define P3JsonLogWithCategory(Category, Verbosity, Subject, ...) \
	{ \
		FString JsonString__; \
		if (!Category.IsSuppressed(ELogVerbosity::Verbosity)) \
		{ \
			JsonString__ = P3MakeJsonLog(TEXT(#Verbosity), TEXT(Subject), TEXT("Func_"), _FUNCTION_TEXT, TEXT("File_"), _FILE_AND_LINE, ##__VA_ARGS__); \
		} \
		UE_LOG(Category, Verbosity, TEXT("%s"), *JsonString__); \
	} \

	#define P3JsonLog(Verbosity, Subject, ...) P3JsonLogWithCategory(P3Log, Verbosity, Subject, ##__VA_ARGS__);
	#define P3JsonNetLog(Verbosity, Subject, ...) P3JsonLogWithCategory(P3NetLog, Verbosity, Subject, ##__VA_ARGS__);
	#define P3JsonWorldLog(Verbosity, Subject, ...) P3JsonLogWithCategory(P3WorldLog, Verbosity, Subject, ##__VA_ARGS__);
	#define P3JsonUDPLog(Verbosity, Subject, ...) P3JsonLogWithCategory(P3UDPNetLog, Verbosity, Subject, ##__VA_ARGS__);

	#define P3JsonNetConnLog(Conn, Verbosity, Subject, ...) \
		P3JsonLogWithCategory(P3NetLog, Verbosity, Subject, \
			TEXT("Name"), *(Conn).GetName(), \
			TEXT("Id"), (Conn).GetId().X, \
			TEXT("Remote"), *(Conn).GetRemoteAddress(), \
			##__VA_ARGS__)
#endif


template<typename EnumType>
FString TEnumToString(const TCHAR* EnumTypeName, EnumType Value)
{
	UEnum* Enum = FindObject<UEnum>(ANY_PACKAGE, EnumTypeName, true);
	return Enum ? Enum->GetNameByValue(static_cast<int32>(Value)).ToString() : FString();
}

template<typename EnumType>
FString TEnumToStringShort(const TCHAR* EnumTypeName, EnumType Value)
{
	UEnum* Enum = FindObject<UEnum>(ANY_PACKAGE, EnumTypeName, true);
	FString EnumValueString = Enum ? Enum->GetNameByValue(static_cast<int32>(Value)).ToString() : FString();

	const int32 NamespacePosition = EnumValueString.Find(TEXT("::"));

	if (NamespacePosition != INDEX_NONE)
	{
		EnumValueString = EnumValueString.RightChop(NamespacePosition + 2);
	}

	return EnumValueString;
}

#define EnumToString(EnumType, EnumValue) TEnumToString(TEXT(#EnumType), (EnumValue))
#define EnumToStringShort(EnumType, EnumValue) TEnumToStringShort(TEXT(#EnumType), (EnumValue))

/**
 * Log time took for a scope
 */
struct FScoppedTimeLogger
{
	FScoppedTimeLogger(const FString& InName)
		: Name(InName)
	{
		StartTimeSeconds = FPlatformTime::Seconds();
	}

	~FScoppedTimeLogger()
	{
		const double DurationSeconds = FPlatformTime::Seconds() - StartTimeSeconds;

		UE_LOG(P3Log, Display, TEXT("%s took %.2f ms"), *Name, DurationSeconds * 1000.0);
	}

	FString Name;
	double StartTimeSeconds;
};
