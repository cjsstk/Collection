// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3IngredientComponent.generated.h"

UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3IngredientComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3IngredientComponent();
};
