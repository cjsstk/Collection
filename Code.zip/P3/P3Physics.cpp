// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Physics.h"

#include "PhysicsEngine/PhysicsSettings.h"

FName P3Physics::GetSurfaceName(EPhysicalSurface SurfaceType)
{
	const TArray<FPhysicalSurfaceName>& PhysicalSurfaceNames = UPhysicsSettings::Get()->PhysicalSurfaces;

	for (const FPhysicalSurfaceName& PhysicalSurfaceName : PhysicalSurfaceNames)
	{
		if (PhysicalSurfaceName.Type == SurfaceType)
		{
			return PhysicalSurfaceName.Name;
		}
	}

	return NAME_None;
}
