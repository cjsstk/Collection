// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3CraftingAction.h"

#include "Action/P3PawnActionComponent.h"
#include "Chemical/P3FlammableComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "Network/P3WorldNet.h"
#include "P3Character.h"
#include "P3GameInstance.h"
#include "P3InventoryComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3PickupComponent.h"
#include "P3PlayerController.h"
#include "P3ServerWorld.h"
#include "P3World.h"

UP3CookingPawnAction::UP3CookingPawnAction()
{
	SetAnimMontageActionFlags(UP3PlayMontagePawnAction::Flags_DisableAutoPlay);
}

bool UP3CookingPawnAction::CanStart(const FP3PawnActionStartRequestParams& Params) const
{
	if (!Super::CanStart(Params))
	{
		return false;
	}

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		return false;
	}

	const FP3CmsCookingRecipe* CmsRecipe = P3Cms::GetCookingRecipe(Params.Cooking_RecipeKey);

	if (!ensure(CmsRecipe) || !ensure(!CmsRecipe->OutcomeActorClass.IsNull()))
	{
		return false;
	}

	UClass* OutcomeActorClass = CmsRecipe->OutcomeActorClass.LoadSynchronous();
	itemkey CookedItemKey = P3Cms::GetItemKeyFromActorClass(OutcomeActorClass);
	if (!ensure(CookedItemKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), OutcomeActorClass ? *OutcomeActorClass->GetName() : TEXT("null"));
		return false;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		return false;
	}

	if (!InvenComp->CanAddItem(CookedItemKey, OutcomeItemAmount))
	{
		const FText ErrorMessage = P3LOC_ITEM("CannotOwnThisItem");
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);
		}
		else
		{
			AP3PlayerController* PlayerController = Cast<AP3PlayerController>(Character->GetController());
			if (ensure(PlayerController))
			{
				PlayerController->ToastMessageBP(ErrorMessage);
			}
		}
		return false;
	}

	return true;
}

void UP3CookingPawnAction::Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params)
{
	Super::Multicast_StartAction(Params);

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	RecipeKey = Params.RequestParams.Cooking_RecipeKey;
	Cooker = Params.RequestParams.Cooking_CookerActor;

	const FP3CmsCookingRecipe* CmsRecipe = P3Cms::GetCookingRecipe(RecipeKey);

	if (!ensure(CmsRecipe) || !ensure(!CmsRecipe->OutcomeActorClass.IsNull()))
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	FinishTimeSeconds = GetWorld()->GetTimeSeconds() + CmsRecipe->CookingDurationSeconds;

	if (!CmsRecipe->CookingActorClass.IsNull() && P3Core::IsP3NetModeClientInstance(*this))
	{
		// Hide holding actor and replace it with cooking actor

		UP3PickupComponent* PickupComp = Character->GetPickupComponent();
		if (ensure(PickupComp && PickupComp->GetPickuppedActor()))
		{
			const FTransform SpawnTransform(PickupComp->GetPickuppedActor()->GetActorTransform());
			FActorSpawnParameters SpawnParams;
			SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			CookingActor = GetWorld()->SpawnActor<AActor>(CmsRecipe->CookingActorClass.LoadSynchronous(), SpawnTransform, SpawnParams);

			if (CookingActor)
			{
				CookingActor->DisableComponentsSimulatePhysics();
				CookingActor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetIncludingScale, PickupComp->GetAttachSocketName(EP3PickupableType::Item));

				PickupComp->GetPickuppedActor()->SetActorHiddenInGame(true);
			}
		}
	}

	SetAnimMontage(Character->GetAnimMontages().Cook);

	PlayAnimMontage();
}

void UP3CookingPawnAction::Multicast_Progress(int32 StepIndex)
{
	Super::Multicast_Progress(StepIndex);

	if (StepIndex == PROGRESS_STEP_COOKED)
	{
		if (CookingActor)
		{
			// Food actor is spawned now, we can remove temporal actor now
			CookingActor->Destroy();
			CookingActor = nullptr;
		}
	}
}

void UP3CookingPawnAction::TickAction(float DeltaSeconds)
{
	Super::TickAction(DeltaSeconds);

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		Finish(EP3PawnActionResult::Failed);
		return;
	}

	if (Cooker)
	{
		UP3FlammableComponent* FlammableComp = Cooker->FindComponentByClass<UP3FlammableComponent>();
		if (!bCookFinished && FlammableComp && !FlammableComp->IsInFire())
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}
	}

	if (FinishTimeSeconds> 0 && GetWorld()->GetTimeSeconds() > FinishTimeSeconds && !bCookFinished)
	{
		bCookFinished = true;

		Character->GetMesh()->GetAnimInstance()->Montage_JumpToSection(FName(TEXT("End")));

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			Server_ConvertIngredientToFood();
		}
	}
}

void UP3CookingPawnAction::Finish(EP3PawnActionResult Result)
{
	Super::Finish(Result);

	if (P3Core::IsP3NetModeServerInstance(*this) && Result == EP3PawnActionResult::Success && !Server_bDidPutIntoBag)
	{
		// Somehow put into bag notify was not called
		ensure(0);
		Server_PutFoodIntoBag();
	}

	if (CookingActor && P3Core::IsP3NetModeClientInstance(*this))
	{
		// Restore pickupped actor's visibility

		AP3Character* Character = GetP3Character();
		UP3PickupComponent* PickupComp = Character ? Character->GetPickupComponent() : nullptr;

		if (PickupComp && PickupComp->GetPickuppedActor())
		{
			PickupComp->GetPickuppedActor()->SetActorHiddenInGame(false);
		}

		CookingActor->Destroy();
	}

	Cooker = nullptr;
	CookingActor = nullptr;
	SpawnedFoodActor = nullptr;
	OutcomeItemKey = INVALID_ITEMKEY;
	RecipeKey = NAME_None;
	FinishTimeSeconds = 0;
	bCookFinished = false;
	Server_bDidPutIntoBag = false;
}

void UP3CookingPawnAction::OnActionAnimNotify(EActionAnimNotifyType NotifyType)
{
	Super::OnActionAnimNotify(NotifyType);

	if (NotifyType == EActionAnimNotifyType::PutIntoBag)
	{
		if (P3Core::IsP3NetModeServerInstance(*this) && SpawnedFoodActor)
		{
			Server_PutFoodIntoBag();
		}
	}
}

void UP3CookingPawnAction::Server_ConvertIngredientToFood()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(Cooker))
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (!Character)
	{
		return;
	}

	const FP3CmsCookingRecipe* CmsRecipe = P3Cms::GetCookingRecipe(RecipeKey);

	if (!ensure(CmsRecipe) || !ensure(!CmsRecipe->OutcomeActorClass.IsNull()))
	{
		return;
	}

	UClass* OutcomeActorClass = CmsRecipe->OutcomeActorClass.LoadSynchronous();
	OutcomeItemKey = P3Cms::GetItemKeyFromActorClass(OutcomeActorClass);
	if (!ensure(OutcomeItemKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), OutcomeActorClass ? *OutcomeActorClass->GetName() : TEXT("null"));
		return;
	}

	UP3InventoryComponent* InvenComp = Character->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		return;
	}

	if (!InvenComp->CanAddItem(OutcomeItemKey, OutcomeItemAmount))
	{
		FText ErrorMessage = P3LOC_ITEM("CannotOwnThisItem");
		P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);
		return;
	}

	UP3PickupComponent* PickupComp = Character->GetPickupComponent();
	if (!ensure(PickupComp))
	{
		return;
	}

	// See if every ingredients are on hands
	TArray<AActor*> HoldingActors;

	// TODO: support multiple pickupped items
	HoldingActors.Add(PickupComp->GetPickuppedActor());

	bool bHasAllIngredient = true;

	for (const auto& IngredientActorClass : CmsRecipe->IngredientActorClasses)
	{
		if (IngredientActorClass.IsNull())
		{
			ensure(0);
			continue;
		}

		bool bFound = false;

		for (int32 HoldingActorIndex = 0; HoldingActorIndex < HoldingActors.Num(); ++HoldingActorIndex)
		{
			if (HoldingActors[HoldingActorIndex] && HoldingActors[HoldingActorIndex]->IsA(IngredientActorClass.LoadSynchronous()))
			{
				bFound = true;
				HoldingActors.RemoveAt(HoldingActorIndex);
				break;
			}
		}

		if (!bFound)
		{
			bHasAllIngredient = false;
			break;
		}
	}
	
	if (!bHasAllIngredient)
	{
		// This should not happen, everything must be checked before
		ensure(0);
		return;
	}

	ensure(HoldingActors.Num() == 0);

	// TODO: support multiple pickupped items
	HoldingActors.Add(PickupComp->GetPickuppedActor());

	const FTransform SpawnTransform(FQuat::Identity, Cooker->GetActorLocation() + FVector(0, 0, 100));
	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	SpawnedFoodActor = GetWorld()->SpawnActor<AActor>(CmsRecipe->OutcomeActorClass.LoadSynchronous(), SpawnTransform, SpawnParams);
	
	ensure(SpawnedFoodActor);

	// Remove ingredient actors
	for (AActor* HoldingActor : HoldingActors)
	{
		HoldingActor->Destroy(true);
	}

	Character->GetCommandComponent()->RequestCommand(UP3ClearPickuppedActorCommand::StaticClass(), FP3CommandRequestParams());

	FP3CommandRequestParams CommandParams;
	CommandParams.HoldItem_ItemActor = SpawnedFoodActor;

	Character->GetCommandComponent()->RequestCommand(UP3HoldItemCommand::StaticClass(), CommandParams);

	GetOwnerComponent()->OnActionProgress(this, PROGRESS_STEP_COOKED);
}

void UP3CookingPawnAction::Server_PutFoodIntoBag()
{
	if (!SpawnedFoodActor)
	{
		// Can be possible when max possession exceeds
		return;
	}

	if (Server_bDidPutIntoBag)
	{
		ensure(0);
		return;
	}

	Server_bDidPutIntoBag = true;

	AP3Character* Character = GetP3Character();
	UP3InventoryComponent* InvenComp = Character ? Character->GetInventoryComponentBP() : nullptr;
	if (!ensure(InvenComp))
	{
		if (GetActionLocalStatus() == EP3PawnActionStatus::InProgress)
		{
			Finish(EP3PawnActionResult::Failed);
		}
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*Character))
	{
		UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);
		if (!ensure(WorldNet))
		{
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		if (!InvenComp->CanAddItem(OutcomeItemKey, OutcomeItemAmount))
		{
			FText ErrorMessage = P3LOC_ITEM("CannotOwnThisItem");
			P3Core::GetP3World(*this)->GetServerWorld()->SendToastMessage(*Character, ErrorMessage);
			Finish(EP3PawnActionResult::Failed);
			return;
		}

		SpawnedFoodActor->Destroy();

		InvenComp->Server_AddItemByKeyAndCount(OutcomeItemKey, OutcomeItemAmount);
	}
}
