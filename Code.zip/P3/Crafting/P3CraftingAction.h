// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#include "Action/P3PawnAction.h"
#include "P3CraftingAction.generated.h"

/**
 * Cooking
 */
UCLASS(BlueprintType)
class P3_API UP3CookingPawnAction : public UP3PlayMontagePawnAction
{
	GENERATED_BODY()

	UP3CookingPawnAction();

public:
	/**
	* UP3PawnAction interfaces
	*/
	virtual bool CanStart(const FP3PawnActionStartRequestParams& Params) const override;
	virtual void Multicast_StartAction(const FP3PawnActionStartMulticastParams& Params) override;
	virtual void Multicast_Progress(int32 StepIndex) override;
	virtual void TickAction(float DeltaSeconds) override;

protected:
	virtual void Finish(EP3PawnActionResult Result) override;
	virtual void OnActionAnimNotify(EActionAnimNotifyType NotifyType) override;

private:
	void Server_ConvertIngredientToFood();
	void Server_PutFoodIntoBag();

	enum { PROGRESS_STEP_COOKED = 1 };

	UPROPERTY(Transient)
	AActor* Cooker = nullptr;

	/** Temporal actor during cooking (like stick or pan) */
	UPROPERTY(Transient)
	AActor* CookingActor = nullptr;

	UPROPERTY(Transient)
	AActor* SpawnedFoodActor = nullptr;

	itemkey OutcomeItemKey = INVALID_ITEMKEY;
	int32 OutcomeItemAmount = 1;
	FName RecipeKey = NAME_None;
	float FinishTimeSeconds = 0;
	bool bCookFinished = false;
	bool Server_bDidPutIntoBag = false;
};
