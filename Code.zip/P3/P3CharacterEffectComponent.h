// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "P3CharacterEffectTypes.h"
#include "P3Cms.h"
#include "P3StoreInterface.h"

#include "P3CharacterEffectComponent.generated.h"

struct FMoveSpeedEffect
{
	TWeakObjectPtr<class UObject> SourceObject;
	float Multiplier = 1.0f;
};

struct FP3CharacterEffectInstance
{
	TWeakObjectPtr<class UObject> SourceObject;
};

USTRUCT()
struct FP3CharacterBuff
{
	GENERATED_BODY()

	TWeakObjectPtr<class UObject> Server_SourceObject;

	UPROPERTY()
	int32 GenerateID = 0;
	
	UPROPERTY()
	int32 BuffKey = 0;

	UPROPERTY()
	FP3CmsCharacterBuffRow CmsCharacterBuff;

	/** Buff will be removed at this time. < 0 means no expire(infinite) */
	UPROPERTY()
	float ExpireAtTimeSeconds = 0.0f;

	/** Optional */
	UPROPERTY()
	float LeftIntervalTimeSeconds = 0.0f;

	/** 
	 * Overlappable 
	 */
	UPROPERTY()
	EP3OverappableBuffType OverlappableBuffType = EP3OverappableBuffType::Scare;

	UPROPERTY()
	int32 BaseLevel = 0;

	UPROPERTY()
	float EffectRadius = 0;

	UPROPERTY()
	float OverlappableRadius = 0;

	/**
	 * Provoke
	 */
	UPROPERTY()
	int32 ProvokeLevel = 0;

	/**
	* Reaction
	*/
	UPROPERTY()
	bool bCanReaction = true;

	UPROPERTY()
	bool bCanDamage = true;

	UPROPERTY()
	EP3ReactionLayer OverrideReactionLayer = EP3ReactionLayer::None;

	UPROPERTY()
	EAnimNotifyAttackDirectionFlags OverrideAttackDirection = EAnimNotifyAttackDirectionFlags::None;

	UPROPERTY()
	EAnimNotifyAttackStrengthFlags OverrideAttackStrength = EAnimNotifyAttackStrengthFlags::Ignore;

	/**
	 * Summon
	 */
	UPROPERTY()
	TWeakObjectPtr<class AActor> Server_SummonedActor;
};

USTRUCT()
struct FP3CharacterBuffs
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FP3CharacterBuff> CharacterBuffs;
};

/** 
 * Container for any effect on character
 */
UCLASS(ClassGroup = (P3))
class P3_API UP3CharacterEffectComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3CharacterEffectComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** 
	 * Effects
	 */
	void Server_AddEffect(EP3CharacterEffectTypes EffectType, UObject& SourceObject);
	void Server_RemoveEffect(EP3CharacterEffectTypes EffectType, UObject& SourceObject);
	bool HasEffect(EP3CharacterEffectTypes EffectType) const;
	bool HasStunEffect() const;

	/**
	 * Buff
	 */
	UFUNCTION(BlueprintCallable)
	int32 Server_AddBuff(const int32 BuffKey, UObject* SourceObject);

	UFUNCTION(BlueprintCallable, BlueprintPure)
	bool HasBuffByBuffKey(int32 BuffKey) const;

	void Server_RemoveBuff(const int32 GenerateID);
	void Server_RemoveBuffBySourceObject(UObject* SourceObject);
	const TArray<FP3CharacterBuff>& GetBuffs();
	int32 Server_GetOverlappableBuffBaseLevel(EP3OverappableBuffType OverlappableBuffType) const;
	float Server_GetOverlappableBuffOverlapRadius(EP3OverappableBuffType OverlappableBuffType) const;

	UFUNCTION(BlueprintCallable)
	int32 GetOverlappableBuffEffectiveLevel(EP3OverappableBuffType OverlappableBuffType) const;

	int32 GetBuffProvokeLevel() const;

	/**
	 * Move Speed
	 */
	void SetMoveSpeedEffect(EP3MoveSpeedEffectLayer Layer, float Multiplier, UObject* SourceObject);
	float GetMoveSpeedMultiplier() const;

	FString GetDebugString() const;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

private:
	void Server_TickExpireBuffs();
	void Server_TickApplyBuffs(float DeltaTime);
	void Server_UpdateNetEffects();
	void Server_UpdateOverlappable();

	void Server_OnBuffRemoved(FP3CharacterBuff& Buff);

	TArray<TArray<FP3CharacterEffectInstance>> Server_Effects;
	int32 Server_NextBuffId = 0;

	FP3CharacterBuffs Net_CharacterBuffs;
	TSet<EP3CharacterEffectTypes> Net_Effects;

	TArray<FMoveSpeedEffect> MoveSpeedEffects;

	/**
	 * OverlappableBuff
	 */
	struct FOverlappableBuff
	{
		int32 BaseLevel = 0;
		float EffectRadius = 0;
		float OverlapRadius = 0;

		/** Nearby pawn's effect component which has same buff */
		TArray<TWeakObjectPtr<UP3CharacterEffectComponent>> OverlapSources;

		/** Overlapped buff levels by nearby pawn's buff */
		int32 OverlappedLevel = 0;
	};

	TArray<FOverlappableBuff> Server_OverlappableBuffs;
	TMap<EP3OverappableBuffType, int32> Net_OverlappableBuffEffectiveLevels;
};
