#include "P3Log.h"

#include "Http.h"
#include "JsonObjectConverter.h"
#include "Misc/App.h"

#include "P3.h"
#include "P3Version.h"

DEFINE_LOG_CATEGORY(P3Log);
DEFINE_LOG_CATEGORY(P3ActionLog);
DEFINE_LOG_CATEGORY(P3CombatLog);
DEFINE_LOG_CATEGORY(P3ComboLog);
DEFINE_LOG_CATEGORY(P3PartCompLog);
DEFINE_LOG_CATEGORY(P3NetLog);
DEFINE_LOG_CATEGORY(P3WorldLog);
DEFINE_LOG_CATEGORY(P3UDPNetLog);
DEFINE_LOG_CATEGORY(P3WebSocketLog);

TAutoConsoleVariable<int32> CVarP3JsonLogSingleLine(
	TEXT("p3.jsonLogSingleLine"),
	0,
	TEXT("1: print json as a single line. 0: print json log as multiline"), ECVF_Default);

TAutoConsoleVariable<FString> CVarP3LogServerURL(
	TEXT("p3.logServerUrl"),
	"http://enzo:5054",
	TEXT("Log server url"), ECVF_Default);

FString P3MakeJsonLogInteralWriteValue_ObjectToString(const UStruct* StructDefinition, const void* Struct)
{
	FString String;
	FJsonObjectConverter::UStructToJsonObjectString(StructDefinition, Struct, String, 0, 0);

	return String;
}

void P3SendJsonLogToServer(const FString& JsonString)
{
	if (!FSlateApplication::IsInitialized())
	{
		return;
	}

	FString LogServerURL = CVarP3LogServerURL.GetValueOnAnyThread();
	if (LogServerURL.IsEmpty())
	{
		return;
	}

	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<TCHAR>> Reader = TJsonReaderFactory<>::Create(JsonString);
	bool bResult = FJsonSerializer::Deserialize(Reader, JsonObject);
	ensure(bResult);

	if (FP3GameModule::Get())
	{
		const FP3Version& Version = FP3GameModule::Get()->GetVersion();
		JsonObject->SetStringField(TEXT("BuildNumber"), Version.BuildNumber);
		JsonObject->SetStringField(TEXT("GitVersion"), Version.Git);
		JsonObject->SetStringField(TEXT("Branch"), Version.Branch);
	}

	JsonObject->SetStringField(TEXT("PlatformUserName"), FString(FPlatformProcess::UserName()));
	JsonObject->SetStringField(TEXT("Platform"), FString(FPlatformProperties::IniPlatformName()));
	JsonObject->SetStringField(TEXT("Installed"), FApp::IsEngineInstalled() ? FString("Yes") : FString("No"));

	FString AugmentedJsonString;
	TSharedRef<TJsonWriter<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>> Writer =
		TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>::Create(&AugmentedJsonString);

	bResult = FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);
	ensure(bResult);

	TSharedRef<IHttpRequest> SendJsonRequest = FHttpModule::Get().CreateRequest();
	SendJsonRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	SendJsonRequest->SetURL(LogServerURL);
	SendJsonRequest->SetVerb("PUT");
	SendJsonRequest->SetContentAsString(AugmentedJsonString);
	SendJsonRequest->ProcessRequest();
}
