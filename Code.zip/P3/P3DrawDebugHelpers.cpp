// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3DrawDebugHelpers.h"
#include "DrawDebugHelpers.h"

void P3DrawDebugArc(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 NumSides,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority, float Thickness)
{
	if (!ensure(NumSides > 0))
	{
		return;
	}

	const float StartAngle = -Angle / 2.0f;
	FVector LastVertex = Base + (X * FMath::Cos(StartAngle) + Y * FMath::Sin(StartAngle)) * Radius;

	for (int32 SideIndex = 1; SideIndex <= NumSides; SideIndex++)
	{
		const float CurrentAngle = StartAngle + Angle / NumSides * SideIndex;
		const FVector Vertex = Base + (X * FMath::Cos(CurrentAngle) + Y * FMath::Sin(CurrentAngle)) * Radius;
		DrawDebugLine(&World, LastVertex, Vertex, Color, bPersistent, LifeTime, DepthPriority, Thickness);
		LastVertex = Vertex;
	}
}

void P3DrawDebugCircularSector(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 NumSides,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority, float Thickness)
{
	if (!ensure(NumSides > 0))
	{
		return;
	}

	const float StartAngle = -Angle / 2.0f;
	const FVector StartVertex = Base + (X * FMath::Cos(StartAngle) + Y * FMath::Sin(StartAngle)) * Radius;
	DrawDebugLine(&World, Base, StartVertex, Color, bPersistent, LifeTime, DepthPriority, Thickness);

	float EndAngle = Angle / 2.0f;
	const FVector EndVertex = Base + (X * FMath::Cos(EndAngle) + Y * FMath::Sin(EndAngle)) * Radius;
	DrawDebugLine(&World, Base, EndVertex, Color, bPersistent, LifeTime, DepthPriority, Thickness);

	P3DrawDebugArc(World, Base, X, Y, Radius, Angle, NumSides, Color, bPersistent, LifeTime, DepthPriority, Thickness);
}

void P3DrawDebugSolidCircularSector(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 NumSides,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority)
{
	if (!ensure(NumSides > 0))
	{
		return;
	}

	TArray<FVector> Verts;
	TArray<int32> Indices;
	int32 Index = 0;

	const int32 BaseIndex = Verts.Add(Base);

	float StartAngle = -Angle / 2.0f;

	FVector StartVertex = Base + (X * FMath::Cos(StartAngle) + Y * FMath::Sin(StartAngle)) * Radius;
	const int32 StartVertexIndex = Verts.Add(StartVertex);

	int32 LastVertexIndex = StartVertexIndex;

	for (int32 SideIndex = 1; SideIndex <= NumSides; SideIndex++)
	{
		const float CurrentAngle = StartAngle + Angle / NumSides * SideIndex;
		const FVector Vertex = Base + (X * FMath::Cos(CurrentAngle) + Y * FMath::Sin(CurrentAngle)) * Radius;

		int32 VertexIndex = Verts.Add(Vertex);

		Indices.Add(BaseIndex);
		Indices.Add(LastVertexIndex);
		Indices.Add(VertexIndex);

		LastVertexIndex = VertexIndex;
	}

	DrawDebugMesh(&World, Verts, Indices, Color, bPersistent, LifeTime, DepthPriority);
}

void P3DrawDebugSolidCylinder(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Height, int32 NumSides,
	const FColor& Color, bool bDrawLine, const FColor& LineColor, float LineThickness, bool bPersistent, float LifeTime, uint8 DepthPriority)
{
	if (!ensure(NumSides > 0))
	{
		return;
	}

	TArray<FVector> Verts;
	TArray<int32> Indices;
	int32 Index = 0;

	const FVector Z = FVector::CrossProduct(X, Y).GetSafeNormal();

	FVector LowerBase = Base - Z * Height / 2.0f;
	const int32 LowerBaseIndex = Verts.Add(LowerBase);

	FVector UpperBase = LowerBase + Z * Height;
	const int32 UpperBaseIndex = Verts.Add(UpperBase);

	const float Angle = 2.0f * PI;
	const float StartAngle = 0.0f;

	const FVector StartLowerVertex = LowerBase + (X * FMath::Cos(StartAngle) + Y * FMath::Sin(StartAngle)) * Radius;
	const int32 StartLowerVertexIndex = Verts.Add(StartLowerVertex);

	const FVector StartUpperVertex = StartLowerVertex + Z * Height;
	const int32 StartUpperVertexIndex = Verts.Add(StartUpperVertex);

	int32 LastLowerVertexIndex = StartLowerVertexIndex;
	int32 LastUpperVertexIndex = StartUpperVertexIndex;

	for (int32 SideIndex = 1; SideIndex <= NumSides; SideIndex++)
	{
		const float CurrentAngle = StartAngle + Angle / NumSides * SideIndex;

		const FVector LowerVertex = LowerBase + (X * FMath::Cos(CurrentAngle) + Y * FMath::Sin(CurrentAngle)) * Radius; 
		const int32 LowerVertexIndex = Verts.Add(LowerVertex);

		const FVector UpperVertex = LowerVertex + Z * Height;
		const int32 UpperVertexIndex = Verts.Add(UpperVertex);

		// Lower pie
		Indices.Add(LowerBaseIndex);
		Indices.Add(LowerVertexIndex);
		Indices.Add(LastLowerVertexIndex);

		// Upper pie
		Indices.Add(UpperBaseIndex);
		Indices.Add(LastUpperVertexIndex);
		Indices.Add(UpperVertexIndex);

		// Upper triangle of side
		Indices.Add(LastUpperVertexIndex);
		Indices.Add(LastLowerVertexIndex);
		Indices.Add(UpperVertexIndex);

		// Lower triangle of side
		Indices.Add(UpperVertexIndex);
		Indices.Add(LastLowerVertexIndex);
		Indices.Add(LowerVertexIndex);

		if (bDrawLine)
		{
			DrawDebugLine(&World, Verts[LastLowerVertexIndex], LowerVertex, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
			DrawDebugLine(&World, Verts[LastUpperVertexIndex], UpperVertex, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		}

		LastLowerVertexIndex = LowerVertexIndex;
		LastUpperVertexIndex = UpperVertexIndex;
	}

	DrawDebugMesh(&World, Verts, Indices, Color, bPersistent, LifeTime, DepthPriority);
}

void P3DrawDebugSolidCylindricalSector(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, float Height, int32 NumSides,
	const FColor& Color, bool bDrawLine, const FColor& LineColor, float LineThickness, bool bPersistent, float LifeTime, uint8 DepthPriority)
{
	if (!ensure(NumSides > 0))
	{
		return;
	}

	TArray<FVector> Verts;
	TArray<int32> Indices;
	int32 Index = 0;

	const FVector Z = FVector::CrossProduct(X, Y).GetSafeNormal();

	FVector LowerBase = Base - Z * Height / 2.0f;
	const int32 LowerBaseIndex = Verts.Add(LowerBase);

	FVector UpperBase = LowerBase + Z * Height;
	const int32 UpperBaseIndex = Verts.Add(UpperBase);

	const float StartAngle = -Angle / 2.0f;

	const FVector StartLowerVertex = LowerBase + (X * FMath::Cos(StartAngle) + Y * FMath::Sin(StartAngle)) * Radius;
	const int32 StartLowerVertexIndex = Verts.Add(StartLowerVertex);

	const FVector StartUpperVertex = StartLowerVertex + Z * Height;
	const int32 StartUpperVertexIndex = Verts.Add(StartUpperVertex);

	// Upper triangle on left side rectangle
	Indices.Add(UpperBaseIndex);
	Indices.Add(StartLowerVertexIndex);
	Indices.Add(StartUpperVertexIndex);

	// Lower triangle on left side rectangle
	Indices.Add(UpperBaseIndex);
	Indices.Add(LowerBaseIndex);
	Indices.Add(StartLowerVertexIndex);

	if (bDrawLine)
	{
		DrawDebugLine(&World, UpperBase, StartUpperVertex, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		DrawDebugLine(&World, LowerBase, StartLowerVertex, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		DrawDebugLine(&World, UpperBase, LowerBase, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		DrawDebugLine(&World, StartUpperVertex, StartLowerVertex, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
	}

	int32 LastLowerVertexIndex = StartLowerVertexIndex;
	int32 LastUpperVertexIndex = StartUpperVertexIndex;

	for (int32 SideIndex = 1; SideIndex <= NumSides; SideIndex++)
	{
		const float CurrentAngle = StartAngle + Angle / NumSides * SideIndex;

		const FVector LowerVertex = LowerBase + (X * FMath::Cos(CurrentAngle) + Y * FMath::Sin(CurrentAngle)) * Radius;
		const int32 LowerVertexIndex = Verts.Add(LowerVertex);

		const FVector UpperVertex = LowerVertex + Z * Height;
		const int32 UpperVertexIndex = Verts.Add(UpperVertex);

		// Lower pie
		Indices.Add(LowerBaseIndex);
		Indices.Add(LowerVertexIndex);
		Indices.Add(LastLowerVertexIndex);

		// Upper pie
		Indices.Add(UpperBaseIndex);
		Indices.Add(LastUpperVertexIndex);
		Indices.Add(UpperVertexIndex);

		// Upper triangle of side
		Indices.Add(LastUpperVertexIndex);
		Indices.Add(LastLowerVertexIndex);
		Indices.Add(UpperVertexIndex);

		// Lower triangle of side
		Indices.Add(UpperVertexIndex);
		Indices.Add(LastLowerVertexIndex);
		Indices.Add(LowerVertexIndex);

		if (bDrawLine)
		{
			DrawDebugLine(&World, Verts[LastLowerVertexIndex], LowerVertex, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
			DrawDebugLine(&World, Verts[LastUpperVertexIndex], UpperVertex, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		}

		LastLowerVertexIndex = LowerVertexIndex;
		LastUpperVertexIndex = UpperVertexIndex;
	}

	// Upper triangle on right side rectangle
	Indices.Add(UpperBaseIndex);
	Indices.Add(LastUpperVertexIndex);
	Indices.Add(LastLowerVertexIndex);

	// Lower triangle on right side rectangle
	Indices.Add(UpperBaseIndex);
	Indices.Add(LastLowerVertexIndex);
	Indices.Add(LowerBaseIndex);

	if (bDrawLine)
	{
		DrawDebugLine(&World, UpperBase, Verts[LastUpperVertexIndex], LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		DrawDebugLine(&World, LowerBase, Verts[LastLowerVertexIndex], LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		DrawDebugLine(&World, UpperBase, LowerBase, LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
		DrawDebugLine(&World, Verts[LastUpperVertexIndex], Verts[LastLowerVertexIndex], LineColor, bPersistent, LifeTime, DepthPriority, LineThickness);
	}

	DrawDebugMesh(&World, Verts, Indices, Color, bPersistent, LifeTime, DepthPriority);
}

void P3DrawDebugSolidSphere(const UWorld& World, const FVector& Center, float Radius, int32 Segments,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority)
{
	TArray<FVector> Verts;
	TArray<int32> Indices;
	int32 Index = 0;

	// Need at least 4 segments

	Segments = FMath::Max(Segments, 4);

	FVector Vertex1, Vertex2, Vertex3, Vertex4;
	const float AngleInc = 2.f * PI / float(Segments);
	int32 NumSegmentsY = Segments / 2;
	float Latitude = AngleInc;
	int32 NumSegmentsX;
	float Longitude;
	float SinY1 = 0.0f, CosY1 = 1.0f, SinY2, CosY2;
	float SinX, CosX;

	while (NumSegmentsY--)
	{
		SinY2 = FMath::Sin(Latitude);
		CosY2 = FMath::Cos(Latitude);

		Vertex1 = FVector(SinY1, 0.0f, CosY1) * Radius + Center;
		Vertex3 = FVector(SinY2, 0.0f, CosY2) * Radius + Center;

		int32 Vertex1Index = Verts.Add(Vertex1);
		int32 Vertex3Index = Verts.Add(Vertex3);

		Longitude = AngleInc;

		NumSegmentsX = Segments;
		while (NumSegmentsX--)
		{
			SinX = FMath::Sin(Longitude);
			CosX = FMath::Cos(Longitude);

			Vertex2 = FVector((CosX * SinY1), (SinX * SinY1), CosY1) * Radius + Center;
			Vertex4 = FVector((CosX * SinY2), (SinX * SinY2), CosY2) * Radius + Center;

			const int32 Vertex2Index = Verts.Add(Vertex2);
			const int32 Vertex4Index = Verts.Add(Vertex4);

			//DrawDebugLine(&World, Verts[Vertex1Index], Verts[Vertex2Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);
			//DrawDebugLine(&World, Verts[Vertex2Index], Verts[Vertex4Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);
			//DrawDebugLine(&World, Verts[Vertex4Index], Verts[Vertex1Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);

			Indices.Add(Vertex1Index); //-V525
			Indices.Add(Vertex2Index); //-V525
			Indices.Add(Vertex4Index); //-V525

			Indices.Add(Vertex1Index); //-V525
			Indices.Add(Vertex4Index); //-V525
			Indices.Add(Vertex3Index); //-V525

			Vertex1Index = Vertex2Index;
			Vertex3Index = Vertex4Index;

			Longitude += AngleInc;
		}

		SinY1 = SinY2;
		CosY1 = CosY2;

		Latitude += AngleInc;
	}

	DrawDebugMesh(&World, Verts, Indices, Color, bPersistent, LifeTime, DepthPriority);
}

void P3DrawDebugSolidSphericalWedge(const UWorld& World, const FVector& Base, const FVector& X, const FVector& Y, float Radius, float Angle, int32 Segments,
	const FColor& Color, bool bPersistent, float LifeTime, uint8 DepthPriority, float Thickness)
{
	TArray<FVector> Verts;
	TArray<int32> Indices;
	int32 Index = 0;

	const int32 BaseIndex = Verts.Add(Base);
	const FMatrix Rot = FRotationMatrix::MakeFromXY(X, Y);

	// Need at least 4 segments

	Segments = FMath::Max(Segments, 4);

	// Sphere part

	FVector Vertex1, Vertex2, Vertex3, Vertex4;
	const float AngleInc = 2.f * PI / float(Segments);
	const float AngleIncX = Angle / float(Segments);
	const float StartAngleX = -Angle / 2.0f;
	int32 NumSegmentsY = Segments / 2;
	float Latitude = AngleInc;
	int32 NumSegmentsX;
	float Longitude;
	float SinY1 = 0.0f, CosY1 = 1.0f, SinY2, CosY2;
	float SinX, CosX;

	while (NumSegmentsY--)
	{
		SinX = FMath::Sin(StartAngleX);
		CosX = FMath::Cos(StartAngleX);

		SinY2 = FMath::Sin(Latitude);
		CosY2 = FMath::Cos(Latitude);

		Vertex1 = Rot.TransformVector(FVector((CosX * SinY1), (SinX * SinY1), CosY1) * Radius) + Base;
		Vertex3 = Rot.TransformVector(FVector((CosX * SinY2), (SinX * SinY2), CosY2) * Radius) + Base;

		int32 Vertex1Index = Verts.Add(Vertex1);
		int32 Vertex3Index = Verts.Add(Vertex3);

		Longitude = StartAngleX + AngleIncX;

		NumSegmentsX = Segments;
		while (NumSegmentsX--)
		{
			SinX = FMath::Sin(Longitude);
			CosX = FMath::Cos(Longitude);

			Vertex2 = Rot.TransformVector(FVector((CosX * SinY1), (SinX * SinY1), CosY1) * Radius) + Base;
			Vertex4 = Rot.TransformVector(FVector((CosX * SinY2), (SinX * SinY2), CosY2) * Radius) + Base;

			const int32 Vertex2Index = Verts.Add(Vertex2);
			const int32 Vertex4Index = Verts.Add(Vertex4);

			//DrawDebugLine(&World, Verts[Vertex1Index], Verts[Vertex2Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);
			//DrawDebugLine(&World, Verts[Vertex2Index], Verts[Vertex4Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);
			//DrawDebugLine(&World, Verts[Vertex4Index], Verts[Vertex1Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);

			Indices.Add(Vertex1Index); //-V525
			Indices.Add(Vertex2Index); //-V525
			Indices.Add(Vertex4Index); //-V525

			Indices.Add(Vertex1Index); //-V525
			Indices.Add(Vertex4Index); //-V525
			Indices.Add(Vertex3Index); //-V525

			Vertex1Index = Vertex2Index;
			Vertex3Index = Vertex4Index;

			Longitude += AngleIncX;
		}

		SinY1 = SinY2;
		CosY1 = CosY2;

		Latitude += AngleInc;
	}

	// Center line

	Vertex1 = Rot.TransformVector(FVector(0.0f, 0.0f, Radius)) + Base;
	Vertex2 = Rot.TransformVector(FVector(0.0f, 0.0f, -Radius)) + Base;

	DrawDebugLine(&World, Vertex1, Vertex2, Color, bPersistent, LifeTime, DepthPriority, Thickness);

	// Left and right sides

	Latitude = AngleInc;
	SinY1 = 0.0f;
	CosY1 = 1.0f;
	NumSegmentsY = Segments / 2;

	while (NumSegmentsY--)
	{
		SinX = FMath::Sin(StartAngleX);
		CosX = FMath::Cos(StartAngleX);

		SinY2 = FMath::Sin(Latitude);
		CosY2 = FMath::Cos(Latitude);

		// Left Side
		{
			Longitude = StartAngleX;

			SinX = FMath::Sin(Longitude);
			CosX = FMath::Cos(Longitude);

			Vertex2 = Rot.TransformVector(FVector((CosX * SinY1), (SinX * SinY1), CosY1) * Radius) + Base;
			Vertex4 = Rot.TransformVector(FVector((CosX * SinY2), (SinX * SinY2), CosY2) * Radius) + Base;

			const int32 Vertex2Index = Verts.Add(Vertex2);
			const int32 Vertex4Index = Verts.Add(Vertex4);

			DrawDebugLine(&World, Verts[Vertex2Index], Verts[Vertex4Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);

			Indices.Add(BaseIndex);
			Indices.Add(Vertex2Index);
			Indices.Add(Vertex4Index);
		}

		// Right Side
		{
			Longitude = StartAngleX + Angle;

			SinX = FMath::Sin(Longitude);
			CosX = FMath::Cos(Longitude);

			Vertex2 = Rot.TransformVector(FVector((CosX * SinY1), (SinX * SinY1), CosY1) * Radius) + Base;
			Vertex4 = Rot.TransformVector(FVector((CosX * SinY2), (SinX * SinY2), CosY2) * Radius) + Base;

			const int32 Vertex2Index = Verts.Add(Vertex2);
			const int32 Vertex4Index = Verts.Add(Vertex4);

			DrawDebugLine(&World, Verts[Vertex2Index], Verts[Vertex4Index], Color, bPersistent, LifeTime, DepthPriority, Thickness);

			Indices.Add(BaseIndex);
			Indices.Add(Vertex2Index);
			Indices.Add(Vertex4Index);
		}

		SinY1 = SinY2;
		CosY1 = CosY2;

		Latitude += AngleInc;
	}

	DrawDebugMesh(&World, Verts, Indices, Color, bPersistent, LifeTime, DepthPriority);
}
