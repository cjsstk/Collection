// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BGMPlayer.h"

#include "Components/AudioComponent.h"
#include "Engine/Engine.h"
#include "Kismet/GameplayStatics.h"

#include "P3Core.h"
#include "P3GameState.h"
#include "P3GameUserSettings.h"

void UP3BGMPlayer::PlayNormalBGM()
{
	SetBGMMode(EP3BGMMode::Normal);
}

void UP3BGMPlayer::PlayBossBattleBGM()
{
	SetBGMMode(EP3BGMMode::BossBattle);
}

void UP3BGMPlayer::StopBossBattleBGM()
{
	SetBGMMode(EP3BGMMode::Normal);
}

void UP3BGMPlayer::Tick()
{
	// Release finished fade-out components
	FadeOutAudioComponents.RemoveAll([](UAudioComponent* AudioComp) -> bool {
		if (!AudioComp || !AudioComp->IsPlaying())
		{
			if (AudioComp)
			{
				AudioComp->DestroyComponent();
			}
			return true;
		}
		return false;
	});

	// Update volume from user setting
	float Volume = 1.0f;
	if (AudioComponent)
	{
		UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());
		if (UserSettings)
		{
			Volume = UserSettings->GetBGMVolume();

			AudioComponent->SetVolumeMultiplier(Volume);
		}
	}

	// Consider fade out
	if (AudioComponent)
	{
		bool bNewFadeOut = false;

		APlayerController* PlayerController = GetWorld()->GetFirstPlayerController();
		if (PlayerController && PlayerController->bCinematicMode)
		{
			bNewFadeOut = true;
		}

		if (bFadeOut != bNewFadeOut)
		{
			bFadeOut = bNewFadeOut;

			if (bFadeOut)
			{
				AudioComponent->FadeOut(1.0f, 0.0f);
			}
			else
			{
				AudioComponent->FadeIn(3.0f, Volume);
			}
		}
	}
}

void UP3BGMPlayer::SetBGMMode(EP3BGMMode InMode)
{
	if (CurrentBGMMode == InMode)
	{
		return;
	}

	CurrentBGMMode = InMode;
	CurrentBGMIndex = 0;

	Play();
}

void UP3BGMPlayer::Play()
{
	if (AudioComponent)
	{
		AudioComponent->FadeOut(5.0f, 0.0f);
		FadeOutAudioComponents.Add(AudioComponent);
		AudioComponent = nullptr;
	}

	const UP3GameResource& GameResource = P3Core::GetGameResource(this);
	const TArray<class USoundBase*>* BGMList = nullptr;

	switch (CurrentBGMMode)
	{
	case EP3BGMMode::Normal:
		BGMList = &GameResource.BGMList;
		break;
	case EP3BGMMode::BossBattle:
		BGMList = &GameResource.BossBattleBGMList;
		break;
	default:
		ensureMsgf(0, TEXT("Unhandled BGM Mode: %d"), StaticCast<int32>(CurrentBGMMode));
	}

	USoundBase* Sound = nullptr;

	if (BGMList && BGMList->Num() > 0)
	{
		CurrentBGMIndex = CurrentBGMIndex % BGMList->Num();
		Sound = BGMList->GetData()[CurrentBGMIndex];
	}

	if (Sound)
	{
		const float VolumeMultiplier = 1.0f;
		const float PitchMultiplier = 1.0f;
		const float StartTime = 0.0f;
		USoundConcurrency* ConcurrencySettings = nullptr;
		const bool bPersistAcrossLevelTransition = false;
		const bool bAutoDestroy = false;

		AudioComponent = UGameplayStatics::SpawnSound2D(this, Sound, VolumeMultiplier, PitchMultiplier, StartTime, ConcurrencySettings, bPersistAcrossLevelTransition, bAutoDestroy);

		if (bFadeOut)
		{
			AudioComponent->Stop();
		}
	}
}
