// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Tree.h"

#include "Components/StaticMeshComponent.h"
#include "DestructibleActor.h"
#include "DestructibleComponent.h"
#include "Engine/CollisionProfile.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "TimerManager.h"

#include "Chemical/P3FlammableComponent.h"
#include "P3Core.h"
#include "P3FruitComponent.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3LootDropComponent.h"
#include "P3Physics.h"
#include "P3World.h"

const static FName Name_CutDownedTrunkHitGround = TEXT("CutDownedTrunkHitGround");
const static FName Name_TreePerInstanceRandom = TEXT("TreePerInstanceRandom");

TAutoConsoleVariable<int32> CVarP3TreeUseSleep(
	TEXT("p3.treeUseSleep"),
	1,
	TEXT("1: use sleep, 0: no sleep. Using sleep can lower CPU usage both client and server"), ECVF_Cheat);

TAutoConsoleVariable<float> CVarP3TreeTickIntervalSeconds(
	TEXT("p3.treeTickIntervalSeconds"),
	0.3f,
	TEXT("Default tree tick interval"), ECVF_Cheat);


AP3Tree::AP3Tree()
{
	HealthPointComponent = CreateDefaultSubobject<UP3HealthPointComponent>(TEXT("HealthPointComponent"));
	HealthPointComponent->SetMaxHealthPoint(3);
	HealthPointComponent->Server_SetServerOnly(true);

	RootMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("RootMeshComponent"));
	RootMeshComponent->SetCollisionProfileName(UCollisionProfile::BlockAll_ProfileName);
	RootMeshComponent->SetMobility(EComponentMobility::Static);
	RootComponent = RootMeshComponent;

	TrunkMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("TrunkMeshComponent"));
	TrunkMeshComponent->SetCollisionProfileName(UCollisionProfile::BlockAll_ProfileName);
	TrunkMeshComponent->SetupAttachment(RootMeshComponent);
	// Trunk is not affected by combat before cut down
	TrunkMeshComponent->SetCollisionResponseToChannel(ECC_COMBAT, ECR_Ignore);
	// Since trunk is kind of long, physics gets weird when it spins(affect by gyro effect)
	// So, need to make it not spin too much..
	TrunkMeshComponent->SetAngularDamping(2.0f);

	TrunkLeavesMeshComponent = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("TrunkLeavesMeshComponent"));
	TrunkLeavesMeshComponent->SetupAttachment(TrunkMeshComponent);
	TrunkLeavesMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	LootDropComponent = CreateDefaultSubobject<UP3LootDropComponent>(TEXT("LootDropComponent"));
	LootDropComponent->SetupAttachment(TrunkMeshComponent);

	// Since tree can't move, lets start without movement replication
	bReplicateMovement = false;
}

void AP3Tree::PostActorCreated()
{
	Super::PostActorCreated();

}

void AP3Tree::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
}

void AP3Tree::PreInitializeComponents()
{
	Super::PreInitializeComponents();
}

void AP3Tree::BeginPlay()
{
	Super::BeginPlay();

	if (HealthPointComponent && P3Core::IsP3NetModeServerInstance(*this))
	{
		HealthPointComponent->OnDead.AddUniqueDynamic(this, &AP3Tree::Server_OnHealthPointComponentDead);
	}

	for (int32 Index = 0; Index < ChoppingPartMeshes.Num(); ++Index)
	{
		UStaticMesh* StaticMesh = ChoppingPartMeshes[Index];
		if (!ensure(StaticMesh))
		{
			continue;
		}

		FName CompName(*FString::Printf(TEXT("ChoppingPartMeshComponent%d"), Index));
		UStaticMeshComponent* MeshComp = NewObject<UStaticMeshComponent>(this, CompName);

		if (ensure(MeshComp))
		{
			MeshComp->RegisterComponent();
			MeshComp->AttachToComponent(RootMeshComponent, FAttachmentTransformRules::KeepRelativeTransform);
			MeshComp->SetStaticMesh(StaticMesh);
			if (ChoppingPartMaterial)
			{
				MeshComp->SetMaterial(0, ChoppingPartMaterial);
			}
			ChoppingPartMeshComponents.Add(MeshComp);
		}
	}

	FlammableComponent = FindComponentByClass<UP3FlammableComponent>();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SleepTree(true);
	}

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		ApplyDynamicMaterialRandomInstanceId();
	}

	PrimaryActorTick.TickInterval = CVarP3TreeTickIntervalSeconds.GetValueOnGameThread() * FMath::RandRange(0.9f, 1.1f);

	// P3Tree::Tick() 함수에 TG_PrePhysics 틱 그룹에 수행되어야 하는 내용이 포함되어 있다
	//
	// PrimitiveComponent::OnComponentHit() 충돌 검사 시점에 액터를 스폰하니 즉시 렌더링되지 않는데
	// 해당 로직이 수행되는 틱 그룹(TG_EndPhysics) 때문인 것으로 생각됨
	// (액터 스폰 즉시 RenderState 생성 및 Transform 값도 일치함에도 불구하고 렌더링은 안됨)
	ensureMsgf(PrimaryActorTick.TickGroup == ETickingGroup::TG_PrePhysics, TEXT("Tree's TickGroup should be TG_PrePhysics"));
}

void AP3Tree::Server_SleepTree(bool bNewSleep)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (CVarP3TreeUseSleep.GetValueOnGameThread() == 0)
	{
		bNewSleep = false;
	}

	if (Net_bTreeSleep == bNewSleep)
	{
		return;
	}

	Net_bTreeSleep = bNewSleep;

	SleepChanged();

	Server_SetDirty(*this);
}

void AP3Tree::SleepChanged()
{
	if (Net_bTreeSleep)
	{
		//TInlineComponentArray<UP3FlammableComponent*> FlammableComps;
		//GetComponents(FlammableComps);

		//for (UP3FlammableComponent* FlammableComp : FlammableComps)
		//{
		//	FlammableComp->UnregisterComponent();
		//}

		TInlineComponentArray<UP3HealthPointComponent*> HealthPointComps;
		GetComponents(HealthPointComps);

		for (UP3HealthPointComponent* HealthPointComp : HealthPointComps)
		{
			HealthPointComp->UnregisterComponent();
		}
	}
	else
	{
		//TInlineComponentArray<UP3FlammableComponent*> FlammableComps;
		//GetComponents(FlammableComps);

		//for (UP3FlammableComponent* FlammableComp : FlammableComps)
		//{
		//	FlammableComp->RegisterComponent();
		//}

		TInlineComponentArray<UP3HealthPointComponent*> HealthPointComps;
		GetComponents(HealthPointComps);

		for (UP3HealthPointComponent* HealthPointComp : HealthPointComps)
		{
			HealthPointComp->RegisterComponent();
		}
	}
}

float AP3Tree::TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return Super::TakeDamage(DamageAmount, DamageEvent, EventInstigator, DamageCauser);
	}

	if (!Net_bCutDowned && DamageCauser)
	{
		const FVector CauserDir = (DamageCauser->GetActorLocation() - GetActorLocation()).GetSafeNormal2D();
		const FVector ActorLocation = GetActorLocation();

		TArray<UStaticMeshComponent*> SortedChoppingPartMeshComponents = ChoppingPartMeshComponents;
		SortedChoppingPartMeshComponents.Remove(nullptr);

		SortedChoppingPartMeshComponents.Sort([&CauserDir, &ActorLocation](const UStaticMeshComponent& A, UStaticMeshComponent& B) -> bool {
			if (A.IsBeingDestroyed())
			{
				return false;
			}
			if (B.IsBeingDestroyed())
			{
				return true;
			}
			const FVector DirA = (A.Bounds.GetSphere().Center - ActorLocation).GetSafeNormal2D();
			const FVector DirB = (B.Bounds.GetSphere().Center - ActorLocation).GetSafeNormal2D();

			return ((CauserDir | DirA) > (CauserDir | DirB));
		});

		for (UStaticMeshComponent* PartComp : SortedChoppingPartMeshComponents)
		{
			if (PartComp && !PartComp->IsBeingDestroyed())
			{
				PartComp->DestroyComponent();

				const int32 Index = ChoppingPartMeshComponents.Find(PartComp);

				Net_ChoppedParts.Add(Index);

				Server_SetDirty(*this);

				break;
			}
		}

		Net_ChopImpulseDirection = -CauserDir;
	}

	OnTreeDropFruit.Broadcast();

	return Super::TakeDamage(DamageAmount, DamageEvent, EventInstigator, DamageCauser);
}

void AP3Tree::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	const bool bOldCutDowned = Net_bCutDowned;
	const bool bOldSleep = Net_bTreeSleep;

	Archive << Net_ChoppedParts;
	Archive << Net_ChopImpulseDirection;
	Archive << Net_bCutDowned;
	Archive << Net_bTrunkFractured;
	Archive << Net_bLootDropped;
	Archive << Net_bTreeSleep;

	if (Archive.IsLoading())
	{
		for (int32 Index : Net_ChoppedParts)
		{
			if (!ensure(ChoppingPartMeshComponents.IsValidIndex(Index)))
			{
				continue;
			}

			UStaticMeshComponent* PartComp = ChoppingPartMeshComponents[Index];

			if (PartComp && !PartComp->IsBeingDestroyed())
			{
				PartComp->DestroyComponent();

				if (ChoppingParticle)
				{
					const FVector ParticleLocationOffset = FVector(0, 0, ChoppingParticleZOffset);
					UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), ChoppingParticle, PartComp->GetComponentLocation() + ParticleLocationOffset, PartComp->GetComponentRotation(), ChoppingParticleScale);
				}
			}
		}

		if (!bOldCutDowned && Net_bCutDowned)
		{
			CutDown();
		}

		if ((Net_bLootDropped || Net_bTrunkFractured) && !bPendingToReplaceTrunk)
		{
			if (TrunkMeshComponent && !TrunkMeshComponent->IsBeingDestroyed())
			{
				DestroyTrunkMesh();
			}

			if (!bDroppingLeaves && TrunkLeavesMeshComponent && !TrunkLeavesMeshComponent->IsBeingDestroyed())
			{
				TrunkLeavesMeshComponent->DestroyComponent();
				TrunkLeavesMeshComponent = nullptr;
			}
		}

		if (Net_bTreeSleep != bOldSleep)
		{
			SleepChanged();
		}
	}
}

void AP3Tree::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	bool bFastTickNeeded = false;

	if (bPendingToReplaceTrunk)
	{
		bPendingToReplaceTrunk = false;

		DropLeaves();
		FractureDestructibleTrunk();
	}

	if (Net_bCutDowned && AfterCutdownTorqueStrength > 0 && !Net_ChopImpulseDirection.IsZero()
		&& TrunkMeshComponent && TrunkMeshComponent->IsSimulatingPhysics())
	{
		const float TimeAfterCutdownSeconds = GetWorld()->GetTimeSeconds() - CutDownedTimeSeconds;
		if (TimeAfterCutdownSeconds < 5.0f)
		{
			const FVector Torque = (FVector(0, 0, 1) ^ Net_ChopImpulseDirection).GetSafeNormal() * DeltaTime * AfterCutdownTorqueStrength;
			TrunkMeshComponent->AddAngularImpulseInRadians(Torque, NAME_None, true);

			bFastTickNeeded = true;
		}
	}

	if (bDroppingLeaves && TrunkLeavesMeshComponent)
	{
		TrunkLeavesMeshComponent->AddWorldOffset(FVector(0, 0, DeltaTime * -AfterCutdownLeavesDropSpeed));

		bFastTickNeeded = true;
	}

	if (FlammableComponent && FlammableComponent->IsInFire())
	{
		BurningAgeSeconds += DeltaTime;

		UpdateBurntDynamicMaterial();

		if (Net_bTreeSleep && P3Core::IsP3NetModeServerInstance(*this))
		{
			Server_SleepTree(false);
		}

		bFastTickNeeded = true;
	}

	if (bFastTickNeeded && PrimaryActorTick.TickInterval != 0.0f)
	{
		PrimaryActorTick.TickInterval = 0;
	}
	else if (!bFastTickNeeded && PrimaryActorTick.TickInterval == 0.0f)
	{
		PrimaryActorTick.TickInterval = CVarP3TreeTickIntervalSeconds.GetValueOnGameThread() * FMath::RandRange(0.9f, 1.1f);
	}
}

void AP3Tree::Client_OnEvent(FName EventName, int32 Param)
{
	Super::Client_OnEvent(EventName, Param);

	if (EventName == Name_CutDownedTrunkHitGround)
	{
		//DropLeaves();
		//FractureDestructibleTrunk();

		bPendingToReplaceTrunk = true;

		OnCutdownedTrunkHitGround.Broadcast();
	}
}

void AP3Tree::Server_OnHealthPointComponentDead()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_bCutDowned)
	{
		// Ok this is our second death, which means cut-downed trunk is chopped again
		// So got to drop something
		if (!Net_bLootDropped && LootDropComponent && LootDropComponent->HasItems())
		{
			LootDropComponent->Server_RollDiceAndDrop();

			DestroyTrunkMesh();

			Net_bLootDropped = true;

			Server_SetDirty(*this);
		}

		return;
	}

	Net_bCutDowned = true;

	CutDown();

	Server_SetDirty(*this);

	if (HealthPointComponent)
	{
		HealthPointComponent->Server_Revive(HealthPointComponent->GetMaxHealthPoint());
	}
}

void AP3Tree::CutDown()
{
	ensure(Net_bCutDowned);

	bReplicateMovement = true;

	if (RootMeshComponent)
	{
		RootMeshComponent->SetCollisionResponseToChannel(ECC_COMBAT, ECR_Ignore);

		if (bDisableRootMeshPawnCollisionAfterCutdown)
		{
			RootMeshComponent->SetCollisionResponseToChannel(ECC_Pawn, ECR_Ignore);
			RootMeshComponent->SetCanEverAffectNavigation(false);
		}
	}

	if (ensure(TrunkMeshComponent))
	{
		TrunkMeshComponent->SetCollisionProfileName(UCollisionProfile::PhysicsActor_ProfileName);
		TrunkMeshComponent->SetCollisionResponseToChannel(ECC_COMBAT, ECR_Block);
		TrunkMeshComponent->SetSimulatePhysics(true);
		TrunkMeshComponent->SetIsReplicated(true);

		if (CutDownedTrunkMesh)
		{
			TrunkMeshComponent->SetStaticMesh(CutDownedTrunkMesh);
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			FBodyInstance* BI = TrunkMeshComponent->GetBodyInstance();
			if (ensure(BI))
			{
				BI->SetInstanceNotifyRBCollision(true);

				TrunkMeshComponent->OnComponentHit.AddUniqueDynamic(this, &AP3Tree::Server_OnTrunkMeshHit);
			}
			else
			{
				// Bail out
				Server_MulticastEvent(Name_CutDownedTrunkHitGround, 0);
			}
		}
	}

	//if (TrunkLeavesMeshComponent && TrunkLeavesMeshComponent->GetStaticMesh())
	//{
	//	FTimerHandle DummyHandle;
	//	GetWorld()->GetTimerManager().SetTimer(DummyHandle, this, &AP3Tree::DropLeaves, 5.0f);
	//}

	for (UStaticMeshComponent* PartComp : ChoppingPartMeshComponents)
	{
		if (PartComp)
		{
			PartComp->DestroyComponent();
		}
	}

	if (CutDownParticle)
	{
		const FVector ParticleLocationOffset = FVector(0, 0, ChoppingParticleZOffset);
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), CutDownParticle, RootMeshComponent->GetComponentLocation() + ParticleLocationOffset, RootMeshComponent->GetComponentRotation(), CutDownParticleScale);
	}

	CutDownedTimeSeconds = GetWorld()->GetTimeSeconds();
}

void AP3Tree::Server_OnTrunkMeshHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const float ElapsedTimeAfterCutDown = GetWorld()->GetTimeSeconds() - CutDownedTimeSeconds;

	if (ElapsedTimeAfterCutDown > 2.0f)
	{
		const float TrunkMass = HitComponent->GetMass();

		if (NormalImpulse.SizeSquared() > FMath::Square(TrunkMass * 100))
		{
			FBodyInstance* BI = TrunkMeshComponent->GetBodyInstance();
			if (ensure(BI))
			{
				BI->SetInstanceNotifyRBCollision(false);

				TrunkMeshComponent->OnComponentHit.RemoveDynamic(this, &AP3Tree::Server_OnTrunkMeshHit);
			}

			Server_MulticastEvent(Name_CutDownedTrunkHitGround, 0);
		}
	}
}

void AP3Tree::FractureDestructibleTrunk()
{
	ensure(Net_bCutDowned);

	if (!TrunkDestructableMesh)
	{
		return;
	}

	if (TrunkDestructibleActor)
	{
		return;
	}

	FTransform Transform = GetActorTransform();

	if (TrunkMeshComponent)
	{
		TrunkMeshComponent->UnWeldFromParent();
		TrunkMeshComponent->SetSimulatePhysics(false);
		TrunkMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		TrunkMeshComponent->SetVisibility(false, true);

		if (TrunkLeavesMeshComponent)
		{
			TrunkLeavesMeshComponent->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
			TrunkLeavesMeshComponent->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepWorldTransform);
			TrunkLeavesMeshComponent->SetVisibility(true);
		}

		Transform = TrunkMeshComponent->GetComponentTransform();

		DestroyTrunkMesh();
	}

	TrunkDestructibleActor = GetWorld()->SpawnActorDeferred<ADestructibleActor>(ADestructibleActor::StaticClass(), Transform, nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AlwaysSpawn);

	if (ensure(TrunkDestructibleActor))
	{
		TrunkDestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_Camera, ECR_Ignore);
		TrunkDestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_Pawn, ECR_Ignore);
		TrunkDestructibleActor->GetDestructibleComponent()->GetBodyInstance()->SetResponseToChannel(ECC_WorldDynamic, ECR_Ignore);
		TrunkDestructibleActor->GetDestructibleComponent()->SetDestructibleMesh(TrunkDestructableMesh);
		TrunkDestructibleActor->GetDestructibleComponent()->SetSimulatePhysics(true);
		TrunkDestructibleActor->GetDestructibleComponent()->ApplyRadiusDamage(1, Transform.GetLocation(), 1000, 1000, true);
		TrunkDestructibleActor->FinishSpawning(Transform);
		TrunkDestructibleActor->SetLifeSpan(10.0f);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Net_bTrunkFractured = true;
		Server_SetDirty(*this);
	}
}

void AP3Tree::DropLeaves()
{
	if (!TrunkLeavesMeshComponent || !TrunkLeavesMeshComponent->GetStaticMesh())
	{
		return;
	}

	const FTransform Transform = TrunkLeavesMeshComponent->GetComponentTransform();
	TrunkLeavesMeshComponent->SetAbsolute(true, true, true);
	TrunkLeavesMeshComponent->SetWorldTransform(Transform);
	//TrunkLeavesMeshComponent->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
	//TrunkLeavesMeshComponent->SetSimulatePhysics(true);
	//TrunkLeavesMeshComponent->SetCollisionEnabled(ECollisionEnabled::PhysicsOnly);
	TrunkLeavesMeshComponent->SetCollisionResponseToAllChannels(ECR_Ignore);

	FTimerHandle DummyHandle;
	GetWorld()->GetTimerManager().SetTimer(DummyHandle, this, &AP3Tree::DestroyLeaves, 10.0f);

	bDroppingLeaves = true;
}

void AP3Tree::DestroyLeaves()
{
	if (!TrunkLeavesMeshComponent)
	{
		return;
	}

	TrunkLeavesMeshComponent->DestroyComponent(true);
	TrunkLeavesMeshComponent = nullptr;

	bDroppingLeaves = false;
}

void AP3Tree::DestroyTrunkMesh()
{
	if (!TrunkMeshComponent)
	{
		return;
	}

	TArray<USceneComponent*> TrunkChildComponents;
	TrunkMeshComponent->GetChildrenComponents(true, TrunkChildComponents);

	for (USceneComponent* ChildComp : TrunkChildComponents)
	{
		ChildComp->DestroyComponent();
	}

	TrunkMeshComponent->DestroyComponent();
	TrunkMeshComponent = nullptr;
}

void AP3Tree::ApplyDynamicMaterialRandomInstanceId()
{
	const FVector ActorLocation = GetActorLocation();
	const float PerInstanceId = FMath::Frac(ActorLocation.X + ActorLocation.Y + ActorLocation.Z);

	if (!Net_bCutDowned && TrunkMeshComponent)
	{
		for (int32 MaterialIndex = 0; MaterialIndex < TrunkMeshComponent->GetNumMaterials(); ++MaterialIndex)
		{
			UMaterialInstanceDynamic* DynamicMaterial = TrunkMeshComponent->CreateDynamicMaterialInstance(MaterialIndex);
			if (DynamicMaterial)
			{
				DynamicMaterial->SetScalarParameterValue(Name_TreePerInstanceRandom, PerInstanceId);
			}
		}
	}

	if (!Net_bCutDowned && TrunkLeavesMeshComponent)
	{
		for (int32 MaterialIndex = 0; MaterialIndex < TrunkLeavesMeshComponent->GetNumMaterials(); ++MaterialIndex)
		{
			UMaterialInstanceDynamic* DynamicMaterial = TrunkLeavesMeshComponent->CreateDynamicMaterialInstance(MaterialIndex);
			if (DynamicMaterial)
			{
				DynamicMaterial->SetScalarParameterValue(Name_TreePerInstanceRandom, PerInstanceId);
			}
		}
	}
}

void AP3Tree::UpdateBurntDynamicMaterial()
{
	const static FName NAME_BurntRatio("BurntRatio");

	const float BurntRatio = FMath::Min(BurningAgeSeconds * BurntMaterialEffectSpeed, 1.0f);
	const float LeavesBurntRatio = FMath::Clamp((BurningAgeSeconds - LeavesBurntMaterialEffectDelaySeconds) * LeavesBurntMaterialEffectSpeed, 0.0f, 1.0f);

	if (RootMeshComponent)
	{
		for (int32 MaterialIndex = 0; MaterialIndex < RootMeshComponent->GetNumMaterials(); ++MaterialIndex)
		{
			UMaterialInstanceDynamic* DynamicMaterial = RootMeshComponent->CreateDynamicMaterialInstance(MaterialIndex);
			if (DynamicMaterial)
			{
				DynamicMaterial->SetScalarParameterValue(NAME_BurntRatio, BurntRatio);
			}
		}
	}

	if (!Net_bCutDowned && TrunkMeshComponent)
	{
		for (int32 MaterialIndex = 0; MaterialIndex < TrunkMeshComponent->GetNumMaterials(); ++MaterialIndex)
		{
			UMaterialInstanceDynamic* DynamicMaterial = TrunkMeshComponent->CreateDynamicMaterialInstance(MaterialIndex);
			if (DynamicMaterial)
			{
				DynamicMaterial->SetScalarParameterValue(NAME_BurntRatio, BurntRatio);
			}
		}
	}

	if (!Net_bCutDowned && TrunkLeavesMeshComponent)
	{
		for (int32 MaterialIndex = 0; MaterialIndex < TrunkLeavesMeshComponent->GetNumMaterials(); ++MaterialIndex)
		{
			UMaterialInstanceDynamic* DynamicMaterial = TrunkLeavesMeshComponent->CreateDynamicMaterialInstance(MaterialIndex);
			if (DynamicMaterial)
			{
				DynamicMaterial->SetScalarParameterValue(NAME_BurntRatio, LeavesBurntRatio);
			}
		}
	}

	for (UStaticMeshComponent* ChoppingPartMeshComp : ChoppingPartMeshComponents)
	{
		if (ChoppingPartMeshComp)
		{
			for (int32 MaterialIndex = 0; MaterialIndex < ChoppingPartMeshComp->GetNumMaterials(); ++MaterialIndex)
			{
				UMaterialInstanceDynamic* DynamicMaterial = ChoppingPartMeshComp->CreateDynamicMaterialInstance(MaterialIndex);
				if (DynamicMaterial)
				{
					DynamicMaterial->SetScalarParameterValue(NAME_BurntRatio, BurntRatio);
				}
			}
		}
	}
}
