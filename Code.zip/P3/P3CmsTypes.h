// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

using itemkey = int32;
const static itemkey INVALID_ITEMKEY = 0;

using buffkey = int32;
const static buffkey INVALID_BUFFKEY = 0;

using questkey = int32;
const static questkey INVALID_QUESTKEY = -1;