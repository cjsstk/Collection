// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3EquipmentComponent.h"
#include "P3Character.h"
#include "P3Part.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"

UP3EquipmentComponent::UP3EquipmentComponent()
{
	PrimaryComponentTick.bCanEverTick = true;	
	bAutoActivate = true;	

	Parts.Reserve((int32)EP3PartType::Count);
}

void UP3EquipmentComponent::OnRegister()
{
	Super::OnRegister();

	Character = Cast<AP3Character>(GetOwner());

	if (ensure(Character))
	{
		Character->OnInputStartMobilePart.AddUniqueDynamic(this, &UP3EquipmentComponent::OnStartMobilePart);
		Character->OnInputStopMobilePart.AddUniqueDynamic(this, &UP3EquipmentComponent::OnStopMobilePart);
	}
}

void UP3EquipmentComponent::OnUnregister()
{
	Super::OnUnregister();

	if (ensure(Character))
	{	
		Character->OnInputStartMobilePart.RemoveDynamic(this, &UP3EquipmentComponent::OnStartMobilePart);
		Character->OnInputStopMobilePart.RemoveDynamic(this, &UP3EquipmentComponent::OnStopMobilePart);
	}
}

void UP3EquipmentComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	
	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_TickComponent();
	}
}

void UP3EquipmentComponent::BeginPlay()
{
	Super::BeginPlay();	
}

void UP3EquipmentComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void UP3EquipmentComponent::AddPart(const TArray<AP3Part*>& InPartsRef)
{
	for (AP3Part* Part : InPartsRef)
	{
		if (IsValidPartType(Part->GetPartType()))
		{
			Parts.Add(Part->GetPartType(), Part);
			Part->AddStartPart(Character);
		}
	}		
}

const AP3Part* UP3EquipmentComponent::AddPart(AP3Part* InPart)
{
	const AP3Part* RemovePartResult = nullptr;

	if (ensure(InPart))
	{
		RemovePartResult = RemovePart(InPart);

		Parts.Add(InPart->GetPartType(), InPart);
		InPart->AddStartPart(Character);
	}

	return RemovePartResult;
}

const AP3Part* UP3EquipmentComponent::RemovePart(const AP3Part* InPart)
{
	const AP3Part* RemovePartResult = nullptr;

	if (ensure(InPart))
	{
		if (IsValidPartType(InPart->GetPartType()))
		{
			RemovePartResult = Parts[InPart->GetPartType()];
			Parts[InPart->GetPartType()]->RemoveStopPart(Character);
			Parts.Remove(InPart->GetPartType());
		}
	}

	return RemovePartResult;
}

void UP3EquipmentComponent::StartPart(int32 TypeIndex)
{	
	EP3PartType PartType = (EP3PartType)TypeIndex;

	if (IsValidPartType(PartType))
	{
		Parts[PartType]->StartPart(Character);
	}
}

void UP3EquipmentComponent::StopPart(int32 TypeIndex)
{
	EP3PartType PartType = (EP3PartType)TypeIndex;

	if (IsValidPartType(PartType))
	{
		Parts[PartType]->StopPart(Character);
	}
}

void UP3EquipmentComponent::StopPartInterrupt(int32 TypeIndex)
{
	EP3PartType PartType = (EP3PartType)TypeIndex;

	if (IsValidPartType(PartType))
	{
		Parts[PartType]->StopPartInterrupt(Character);
	}
}

bool UP3EquipmentComponent::Server_CanPartStart(int32 TypeIndex) const
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));
	
	EP3PartType PartType = (EP3PartType)TypeIndex;

	if (IsValidPartType(PartType))
	{
		return !Parts[PartType]->Server_BeginInterruptCondition(Character);
	}

	return true;
}


bool UP3EquipmentComponent::CanPartFlags(EP3PartType PartType, int32 Flags) const
{
	if (IsValidPartType(PartType))
	{
		return Parts[PartType]->CanPartFlags(PartType, Flags);
	}

	return false;
}

void UP3EquipmentComponent::Server_TickComponent()
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	for (const auto& Iter : Parts)
	{
		if (Iter.Value->Server_TickInterruptCondition(Character))
		{
			UP3CommandComponent* CommandComponent = Character->GetCommandComponent();
			if (ensure(CommandComponent))
			{
				FP3CommandRequestParams Params;
				Params.PartType = (int32)Iter.Key;
				Params.SetPart_bStart = false;
				Params.SetPart_bInterrupt = true;
				CommandComponent->RequestCommand(UP3StartPartCommand::StaticClass(), Params);
			}
		}
	}
}

bool UP3EquipmentComponent::IsValidPartType(EP3PartType PartType) const
{
	return Parts.Contains(PartType) && ensure(Parts[PartType]);
}

void UP3EquipmentComponent::OnStartMobilePart()
{
	EP3PartType PartType = EP3PartType::Mobile;

	if (!ensure(Character) || !IsValidPartType(PartType))
		return;

	UP3CommandComponent* CommandComponent = Character->GetCommandComponent();
	if (ensure(CommandComponent))
	{
		FP3CommandRequestParams Params;
		Params.PartType = (int32)PartType;
		Params.SetPart_bStart = true;
		Params.SetPart_bInterrupt = false;
		CommandComponent->RequestCommand(UP3StartPartCommand::StaticClass(), Params);			
	}
}

void UP3EquipmentComponent::OnStopMobilePart()
{	
	EP3PartType PartType = EP3PartType::Mobile;

	if (!ensure(Character) || !IsValidPartType(PartType))
		return;
					
	UP3CommandComponent* CommandComponent = Character->GetCommandComponent();
	if (ensure(CommandComponent))
	{
		FP3CommandRequestParams Params;
		Params.PartType = (int32)PartType;
		Params.SetPart_bStart = false;
		Params.SetPart_bInterrupt = false;
		CommandComponent->RequestCommand(UP3StartPartCommand::StaticClass(), Params);
	}			
}
