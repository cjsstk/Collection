// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3StoreArchive.h"

#include "UObject/CoreNet.h"

#include "P3Core.h"
#include "P3World.h"

enum EObjectStoreType : uint8
{
	OST_Null,
	OST_ActorId,	// P3 Actor id
	OST_Path,		// FSoftObjectPath
	OST_ActorComponentWithActorId,
	OST_ActorComponentWithActorName
};

/**
 * FP3StoreBitWriter
 */

FP3StoreBitWriter::FP3StoreBitWriter(class UP3World* InWorld, int64 InMaxBits, bool AllowResize /*= false*/)
	: FBitWriter(InMaxBits, AllowResize)
	, World(InWorld)
{

}

FArchive& FP3StoreBitWriter::operator<<(UObject*& Value)
{
	uint8 StoreType = OST_Null;
	actorid ActorId = INVALID_ACTORID;
	FString ObjectPath;
	FString LevelName;
	FString ActorName;
	FString ComponentName;

	if (Value != nullptr)
	{
		AActor* Actor = Cast<AActor>(Value);
		if (Actor)
		{
			ActorId = World->GetActorIdFromActor(Actor);

			if (ensure(ActorId != INVALID_ACTORID))
			{
				StoreType = OST_ActorId;
			}
		}
		else if (UActorComponent* ActorComp = Cast<UActorComponent>(Value))
		{
			ComponentName = ActorComp->GetName();

			AActor* OwnerActor = ActorComp->GetOwner();
			if (ensure(OwnerActor))
			{
				ActorId = World->GetActorIdFromActor(OwnerActor);
				if (ActorId != INVALID_ACTORID)
				{
					StoreType = OST_ActorComponentWithActorId;
				}
				else if (OwnerActor->IsNetStartupActor())
				{
					ULevel* Level = Cast<ULevel>(OwnerActor->GetOuter());
					if (ensure(Level))
					{
						LevelName = Level->GetOuter()->GetName();
						ActorName = OwnerActor->GetName();
						StoreType = OST_ActorComponentWithActorName;
					}
				}
				else
				{
					ensure(0);
				}
			}
		}
		else
		{
			StoreType = OST_Path;

			FSoftObjectPath SoftObjectPath(Value);
			ObjectPath = SoftObjectPath.ToString();
		}
	}

	// FNetworkGUID GUID = (ensure(Connection)) ? Connection->PackageMap->GetNetGUIDFromObject(Value) : FNetworkGUID();

	*this << StoreType;

	switch (StoreType)
	{
	case OST_Null:
		break;

	case OST_ActorId:
		*this << ActorId;
		break;

	case OST_Path:
		*this << ObjectPath;
		break;

	case OST_ActorComponentWithActorId:
		*this << ActorId;
		*this << ComponentName;
		break;

	case OST_ActorComponentWithActorName:
		*this << LevelName;
		*this << ActorName;
		*this << ComponentName;
		break;

	default:
		ensureMsgf(0, TEXT("Invalid store type to write. %u"), StoreType);
	}

	return *this;
}

FArchive& FP3StoreBitWriter::operator<<(FName& Value)
{
	FString StringValue = Value.ToString();

	*this << StringValue;

	return *this;
}


FArchive& FP3StoreBitWriter::operator<<(struct FWeakObjectPtr& Value)
{
	UObject* Object = Value.Get();

	*this << Object;

	return *this;
}

/**
 * FP3StoreBitReader
 */

FP3StoreBitReader::FP3StoreBitReader(class UP3World* InWorld, uint8* Src /*= nullptr*/, int64 CountBits /*= 0*/)
	: FBitReader(Src, CountBits)
	, World(InWorld)
{

}

FArchive& FP3StoreBitReader::operator<<(UObject*& Value)
{
	Value = nullptr;

	uint8 StoreType = OST_Null;

	*this << StoreType;

	if (StoreType == OST_Null)
	{
		Value = nullptr;
	}
	else if (StoreType == OST_ActorId)
	{
		actorid ActorId;

		*this << ActorId;

		Value = World->GetActorFromActorId(ActorId);

		ensure(Value || (ActorId == INVALID_ACTORID));
	}
	else if (StoreType == OST_Path)
	{
		FString ObjectPath;

		*this << ObjectPath;

		FSoftObjectPath SoftObjectPath(ObjectPath);

		Value = SoftObjectPath.TryLoad();
	}
	else if (StoreType == OST_ActorComponentWithActorId)
	{
		actorid ActorId;
		FString ComponentName;

		*this << ActorId;
		*this << ComponentName;

		AActor* Actor = World->GetActorFromActorId(ActorId);
		if (Actor)
		{
			Value = P3Core::GetActorComponentByName<UActorComponent>(*Actor, ComponentName);
		}
	}
	else if (StoreType == OST_ActorComponentWithActorName)
	{
		FString LevelName;
		FString ActorName;
		FString ComponentName;

		*this << LevelName;
		*this << ActorName;
		*this << ComponentName;

		AActor* Actor = P3Core::FindActorByName(World->GetWorld(), LevelName, ActorName);
		if (Actor)
		{
			Value = P3Core::GetActorComponentByName<UActorComponent>(*Actor, ComponentName);
		}
	}
	else
	{
		ensureMsgf(0, TEXT("Invalid store type to read. %u"), StoreType);
	}

	return *this;
}

FArchive& FP3StoreBitReader::operator<<(FName& Value)
{
	FString StringValue;

	*this << StringValue;

	Value = FName(*StringValue);

	return *this;
}


FArchive& FP3StoreBitReader::operator<<(struct FWeakObjectPtr& Value)
{
	UObject* Object = nullptr;

	*this << Object;

	Value = Object;

	return *this;
}

/**
 * FP3ActorIdWriter
 */

FArchive& FP3ActorIdWriter::operator<<(UObject*& Value)
{
	AActor* Actor = Cast<AActor>(Value);
	if (Actor)
	{
		UP3World* World = P3Core::GetP3World(*Value);

		if (ensure(World))
		{
			actorid ActorId = World->GetActorIdFromActor(Actor);

			if (ActorId != INVALID_ACTORID)
			{
				ActorIds.Add(ActorId);
			}
		}
	}

	return *this;
}
