// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AggroComponent.h"

#include "Net/UnrealNetwork.h"

#include "P3Character.h"
#include "P3HealthPointComponent.h"

static TAutoConsoleVariable<int32> CVarP3AggroDebug(
	TEXT("p3.aggroDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

UP3AggroComponent::UP3AggroComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	bReplicates = true;
}

void UP3AggroComponent::OnRegister()
{
	Super::OnRegister();

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (ensure(Character))
	{
		Character->OnCharacterDead.AddUniqueDynamic(this, &UP3AggroComponent::OnCharacterDead);
	}
}

void UP3AggroComponent::OnUnregister()
{
	Super::OnUnregister();

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (Character)
	{
		Character->OnCharacterDead.RemoveDynamic(this, &UP3AggroComponent::OnCharacterDead);
	}
}

void UP3AggroComponent::BeginPlay()
{
	Super::BeginPlay();
}


void UP3AggroComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	RemoveInvalidItems();

	if (CVarP3AggroDebug.GetValueOnGameThread() != 0)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character)
		{
			TArray<FP3AggroItem> ItemsForDebug = Items;
			ItemsForDebug.StableSort([](const FP3AggroItem& Item1, const FP3AggroItem& Item2) -> bool {
				return (Item1.Point > Item2.Point);
			});

			Character->AddDebugString(TEXT("<Aggro>"));

			for (const FP3AggroItem& Item : ItemsForDebug)
			{
				AActor* Actor = Item.Actor.Get();

				Character->AddDebugString(FString::Printf(TEXT("[%d] %s"), Item.Point, Actor ? *Actor->GetName() : TEXT("NULL")));
			}
		}
	}
}

void UP3AggroComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UP3AggroComponent, Items);
}

void UP3AggroComponent::OnHit(AActor* SourceActor, int32 Damage)
{
	if (!SourceActor)
	{
		return;
	}

	if (Damage < 0)
	{
		return;
	}

	UP3HealthPointComponent* HealthPointComponent = SourceActor->FindComponentByClass<UP3HealthPointComponent>();
	if (!HealthPointComponent)
	{
		// If source doesn't have HP, just ignore it (ex. Swamp)
		return;
	}

	FP3AggroItem& Item = FindOrCreateItemByActor(*SourceActor);
	
	Item.Point += Damage;
}

void UP3AggroComponent::OnSight(AActor* SourceActor)
{
	if (!SourceActor)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(SourceActor);
	AP3Character* OwnerCharacter = Cast<AP3Character>(GetOwner());
	if (!Character || !OwnerCharacter)
	{
		return;
	}

	// Only enemy can be on sight
	if (Character->GetGenericTeamId() == OwnerCharacter->GetGenericTeamId() || Character->GetGenericTeamId() == FGenericTeamId::NoTeam)
	{
		return;
	}


	FindOrCreateItemByActor(*SourceActor);
}

void UP3AggroComponent::ClearAggro()
{
	Items.Reset();
}

void UP3AggroComponent::ResetAggro(int32 RandomRange)
{
	for (FP3AggroItem& Item : Items)
	{
		Item.Point = FMath::RandHelper(RandomRange);
	}
}

void UP3AggroComponent::ResetAggroOf(const AActor& Actor, int32 RandomRange)
{
	for (FP3AggroItem& Item : Items)
	{
		if (Item.Actor.Get() == &Actor)
		{
			Item.Point = FMath::RandHelper(RandomRange);
			return;
		}
	}
}

void UP3AggroComponent::RemoveAggroOf(const AActor& Actor)
{
	Items.RemoveAll([&Actor](const FP3AggroItem& Item) -> bool
	{
		return Item.Actor.Get() == &Actor;
	});
}

void UP3AggroComponent::MakeAsTop(AActor& Actor)
{
	int32 TopPoint = 0;

	for (const FP3AggroItem& Item : Items)
	{
		TopPoint = FMath::Max(TopPoint, Item.Point);
	}

	FP3AggroItem& Item = FindOrCreateItemByActor(Actor);
	Item.Point = TopPoint + 1;
}

AActor* UP3AggroComponent::GetTopActor()
{
	RemoveInvalidItems();
	SortItems();

	if (Items.Num() > 0)
	{
		return Items[0].Actor.Get();
	}

	return nullptr;
}

TArray<AActor*> UP3AggroComponent::GetAllActors() const
{
	TArray<AActor*> Actors;

	Actors.Reserve(Items.Num());

	for (const FP3AggroItem& Item : Items)
	{
		AActor* Actor = Item.Actor.Get();

		if (Actor)
		{
			Actors.Add(Actor);
		}
	}

	return Actors;
}

const TArray<FP3AggroItem>& UP3AggroComponent::GetSortedAggroItems() const
{
	SortedItems = Items;
	SortedItems.StableSort([](const FP3AggroItem& Item1, const FP3AggroItem& Item2) -> bool {
		return (Item1.Point > Item2.Point);
	});

	return SortedItems;
}

void UP3AggroComponent::SortItems()
{
	Items.StableSort([](const FP3AggroItem& Item1, const FP3AggroItem& Item2) -> bool {
		return (Item1.Point > Item2.Point);
	});
}

void UP3AggroComponent::RemoveInvalidItems()
{
	AActor* Owner = GetOwner();

	Items.RemoveAll([Owner](const FP3AggroItem& Item) -> bool
	{
		if (!Item.Actor.IsValid())
		{
			return true;
		}

		if (Item.Actor->IsActorBeingDestroyed())
		{
			return true;
		}

		// Hotfix to prevent self-attacking.
		// TODO: Fix root cause
		if (Item.Actor == Owner)
		{
			return true;
		}

		if (!ensure(Item.Point >= 0))
		{
			return true;
		}

		AP3Character* Character = Cast<AP3Character>(Item.Actor);

		if (Character && Item.LastDeadTime < Character->GetLastDeadTimeSeconds())
		{
			return true;
		}

		return false;
	});
}

FP3AggroItem* UP3AggroComponent::FindItemByActor(AActor& Actor)
{
	FP3AggroItem* Item = Items.FindByPredicate([&Actor](const FP3AggroItem& Item) -> bool {
		return (Item.Actor.Get() == &Actor);
	});

	return Item;
}

FP3AggroItem& UP3AggroComponent::FindOrCreateItemByActor(AActor& Actor)
{
	ensure(&Actor != GetOwner());

	FP3AggroItem* Item = FindItemByActor(Actor);
	if (Item)
	{
		return *Item;
	}

	float LastDeadTimeSeconds = 0.0f;

	AP3Character* Character = Cast<AP3Character>(&Actor);
	if (Character)
	{
		LastDeadTimeSeconds = Character->GetLastDeadTimeSeconds();
	}

	Items.Add(FP3AggroItem({ &Actor, 0, LastDeadTimeSeconds }));

	return Items.Last();
}

void UP3AggroComponent::OnCharacterDead()
{
	Items.Reset();
}
