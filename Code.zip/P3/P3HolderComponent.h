// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"

#include "Item/P3Item.h"
#include "P3Core.h"
#include "P3HoldType.h"
#include "P3WeaponType.h"
#include "P3StoreInterface.h"

#include "P3HolderComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FP3HoldingChanged, class UP3HolderComponent*, HolderComponent, AActor*, HoldingActor);

USTRUCT(Blueprintable)
struct FP3HoldableAttachParams
{
	GENERATED_BODY()

	/** Character socket name that holdable actor attach to */
	UPROPERTY(EditAnywhere, Category = "P3")
	FName SocketName;

	/** Relative location in socket space */
	UPROPERTY(EditAnywhere, Category = "P3")
	FVector Location = FVector::ZeroVector;

	/** Relative rotation in socket space */
	UPROPERTY(EditAnywhere, Category = "P3")
	FRotator Rotation = FRotator::ZeroRotator;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3HolderComponent : public USceneComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3HolderComponent();

	virtual void DestroyComponent(bool bPromoteChildren = false) override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	
	void SetHoldingActor(AActor* NewHoldingActor, bool bHold);
	AActor* RemoveHoldingActor();

	// Put holdable object into holding socket
	UFUNCTION(BlueprintCallable)
	void HoldBP() { Hold(); }
	void Hold();

	// Put holdable object into stash socket or hide
	UFUNCTION(BlueprintCallable)
	void StashBP() { Stash(); }
	void Stash();

	// If the holdable is in hand, return true
	UFUNCTION(BlueprintCallable)
	bool IsHold() const { return bHold; }

	EP3HoldType GetHoldType() const { return HoldType; }
	AActor* GetHoldingActor() const { return HoldingActor; }

	TSubclassOf<AActor> GetDefaultHoldingActorClass(EP3CharClass CharClass) const;

	FTransform GetHoldSocketTransform() const;

	void OnCharacterHiddenChanged(bool bNewHidden);

	/** Set item to recover after temporary weapon destruction or throw */
	void Server_SetRecoveryAfterTempWeaponItem(FP3Item InRecoveryAfterTempWeaponItem) { RecoveryAfterTempWeaponItem = InRecoveryAfterTempWeaponItem; }

	/** Get item to recover after temporary weapon destruction or throw */
	const FP3Item& Server_GetRecoveryAfterTempWeaponItem() const { return RecoveryAfterTempWeaponItem; }

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	FP3HoldingChanged OnHold;
	FP3HoldingChanged OnStash;
	FP3HoldingChanged OnActorRemoved;

protected:
	virtual void BeginPlay() override;
	
private:
	const FP3HoldableAttachParams& FindHoldParams() const;
	const FP3HoldableAttachParams& FindStashParams() const;

	/** Allowed hold type */
	UPROPERTY(EditAnywhere, Category = "P3")
	EP3HoldType HoldType;

	/** Character socket name that holdable actor attach to */
	UPROPERTY(EditAnywhere, Category = "P3")
	FP3HoldableAttachParams DefaultHoldParams;
	
	UPROPERTY(EditAnywhere, Category = "P3")
	FP3HoldableAttachParams DefaultStashParams;

	UPROPERTY(EditAnywhere, Category = "P3")
	TMap<EP3WeaponType, FP3HoldableAttachParams> WeaponHoldParams;

	UPROPERTY(EditAnywhere, Category = "P3")
	TMap<EP3WeaponType, FP3HoldableAttachParams> WeaponStashParams;

	/** Hide object during stash */
	UPROPERTY(EditAnywhere, Category = "P3")
	bool bHiddenInStash = false;

	/** Optional - If set, it will be spawned automatically and hold */
	UPROPERTY(EditAnywhere, Category = "P3")
	TMap<EP3CharClass, TSubclassOf<AActor>> DefaultHoldingActorClass;

	/** Actor(Spawned by Item) which we are holding now */
	UPROPERTY(Transient)
	AActor* HoldingActor;

	UPROPERTY(Transient)
	bool bHold = false;

	/** Holding actor's components which has PhysicsOnly Collision Enabled. We store these to restore at detach */
	UPROPERTY(Transient)
	TArray<UPrimitiveComponent*> PhysicsOnlyComponents;

	/** Holding actor's components which has QueryAndPhysics Collision Enabled. We store these to restore at detach */
	UPROPERTY(Transient)
	TArray<UPrimitiveComponent*> QueryAndPhysicsComponents;

	/** ItemsID to recover after temporary weapon destruction */
	FP3Item RecoveryAfterTempWeaponItem = FP3Item::InvalidItem;
};
