// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Weapon.h"

#include "Components/AudioComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Components/TextRenderComponent.h"
#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "Materials/MaterialInstanceDynamic.h"
#include "Particles/ParticleSystemComponent.h"

#include "P3Core.h"
#include "Command/P3CommandComponent.h"
#include "P3GameState.h"
#include "P3Log.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3InventoryComponent.h"
#include "P3Projectile.h"
#include "P3World.h"


static TAutoConsoleVariable<int32> CVarP3WeaponUsableCountDebug(
    TEXT("p3.weaponUsableCountDebug"),
    0,
    TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3WeaponDestoryTimeSecondes(
	TEXT("p3.weaponDestoryTimeSecondes"),
	1.0f,
	TEXT("Time to remove Weapon"), ECVF_Cheat);

AP3Weapon::AP3Weapon()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

void AP3Weapon::BeginPlay()
{
	Super::BeginPlay();
	
	if (!LootEffectParticle)
	{
		LootEffectParticle = P3Core::GetGameResource(this).LootEffectParticle;
	}

	UClass* ItemActorClass = GetClass();
	ItemKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
	if (!ensure(ItemKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));

#if !UE_BUILD_SHIPPING
		UTextRenderComponent* TextRenderComponent = NewObject<UTextRenderComponent>(this, TEXT("TextRenderComponent"));
		TextRenderComponent->RegisterComponent();
		TextRenderComponent->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
		TextRenderComponent->SetText(FText::AsCultureInvariant("Missing in CMS"));
		TextRenderComponent->SetHorizontalAlignment(EHTA_Center);
		TextRenderComponent->SetXScale(2.0f);
		TextRenderComponent->SetYScale(2.0f);
#endif
	}

	const FP3CmsHoldable* CmsHoldablePtr = P3Cms::GetItemHoldable(ItemKey);
	if (CmsHoldablePtr)
	{
		CmsHoldable = *CmsHoldablePtr;
	}

	HoldableComponent = FindComponentByClass<UP3HoldableComponent>();

	UStaticMeshComponent* StaticMeshComp = FindComponentByClass<UStaticMeshComponent>();
	if (StaticMeshComp)
	{
		DestroyMaterial = StaticMeshComp->CreateDynamicMaterialInstance(0);
	}
}

void AP3Weapon::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// See If the weapon run out of durability
	if (IsRunOutOfDurability() && !IsActorBeingDestroyed())
	{			
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			if (CVarP3WeaponDestoryTimeSecondes.GetValueOnGameThread() <= DestoryTimeSeconds)
			{
				Destroy();
			}
		}
		else
		{
			UpdateDestoryDynamicMaterial(DeltaTime);						
		}		

		if (P3Core::IsP3NetModeStandalone(*this))
		{
			UpdateDestoryDynamicMaterial(DeltaTime);
		}

		DestoryTimeSeconds += DeltaTime;
	}

	if (bIsThrowFlying)
	{
		if (ThrowFlyingAudioComponent)
		{
			const float CurrentSpeed = GetVelocity().Size();
			const float SpeedRatio = ThrowSpeed > 0 ? CurrentSpeed / ThrowSpeed : 1.0f;

			ThrowFlyingAudioComponent->SetVolumeMultiplier(FMath::Clamp(SpeedRatio, 0.0f, 2.0f));
			ThrowFlyingAudioComponent->SetPitchMultiplier(FMath::Clamp(SpeedRatio, 0.5f, 2.0f));
		}
		
		AddActorLocalRotation(FRotator(DeltaTime * -1800.0f, 0, 0));
	}
	else if (bIsRecallFlying && P3Core::IsP3NetModeServerInstance(*this) && ensure(RecallHolderComponent))
	{
		RecallAgeSeconds += DeltaTime;
		RecallDuration = FMath::Max(RecallDuration, 0.01f);

		const float RecallAgeRatio = RecallAgeSeconds / RecallDuration;
		const float Alpha = FMath::Clamp(RecallAgeRatio * RecallAgeRatio, 0.0f, 1.0f);

		const FVector TargetSocketLocation = RecallHolderComponent->GetHoldSocketTransform().GetLocation();
		const FVector OriginalOffset = (TargetSocketLocation - RecallStartLocation);
		const FVector RightVector = (OriginalOffset ^ FVector(0, 0, 1)).GetSafeNormal();
		const float OriginalDistance = OriginalOffset.Size();
		FVector NewLocatin = FMath::Lerp(RecallStartLocation, TargetSocketLocation, Alpha);

		// Add some right side curve
		NewLocatin += (RightVector * FMath::Sin(Alpha * PI)) * OriginalDistance * 0.2f;

		SetActorLocation(NewLocatin);
		AddActorLocalRotation(FRotator(DeltaTime * -1800.0f, 0, 0));

		if (Alpha >= 1.0f)
		{
			OnThrowRecallFinished();
		}
	}

	const bool bIsAttached = (GetAttachParentActor() != nullptr);

	// See if we need to spawn loot effect
	if (LootEffectParticle && IsPlayerUsable())
	{
		if (!bIsAttached && !LootEffectParticleComponent)
		{
			LootEffectParticleComponent = UGameplayStatics::SpawnEmitterAttached(LootEffectParticle, GetRootComponent(), FName(), FVector::ZeroVector, FRotator::ZeroRotator, EAttachLocation::KeepRelativeOffset);
			if (LootEffectParticleComponent)
			{
				LootEffectParticleComponent->bAbsoluteRotation = true;
				LootEffectParticleComponent->SetWorldRotation(FRotator::ZeroRotator);
			}
		}
		else if (bIsAttached && LootEffectParticleComponent)
		{
			LootEffectParticleComponent->DestroyComponent();
		}
	}

	// Attached weapons doesn't need movement replication for now
	if (bIsAttached)
	{
		SetReplicateMovement(false);
	}
	else
	{
		SetReplicateMovement(true);
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3WeaponUsableCountDebug.GetValueOnGameThread() != 0)
	{
		if (CmsHoldable.MaxUsableCountByPlayer > -1)
		{
			DrawDebugString(GetWorld(), GetActorLocation(), FString::Printf(TEXT("Weapon : %s, UsableCount : (%d/%d)"), *GetName(), UseCountByPlayer, CmsHoldable.MaxUsableCountByPlayer), nullptr, FColor::White, 0.0f, true);
		}
		else
		{
			DrawDebugString(GetWorld(), GetActorLocation(), FString::Printf(TEXT("Weapon : %s, UsableCount : inf"), *GetName()), nullptr, FColor::White, 0.0f, true);
		}
		
	}
#endif
}

void AP3Weapon::Server_Throw(const FVector& ThrowDirection, class AActor* SourceActor)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		ensure(0);
		return;
	}

	if (GetParentActor())
	{
		ensure(0);
		P3JsonLog(Warning, "Failed to throw weapon, attached to something");
		return;
	}

	SetActorRotation(ThrowDirection.Rotation());

	if (!ThrowMovementComponent)
	{
		ThrowMovementComponent = NewObject<UP3WeaponThrowMovementComponent>(this);
		ThrowMovementComponent->PrimaryComponentTick.bCanEverTick = true;
		ThrowMovementComponent->bIsHomingProjectile = false;
		ThrowMovementComponent->bRotationFollowsVelocity = false;
		ThrowMovementComponent->bInitialVelocityInLocalSpace = false;
		ThrowMovementComponent->InitialSpeed = ThrowSpeed;
		//ThrowMovementComponent->HomingAccelerationMagnitude = 1000.0f;
		ThrowMovementComponent->Velocity = ThrowDirection * ThrowSpeed;
		ThrowMovementComponent->OnProjectileStop.AddUniqueDynamic(this, &AP3Weapon::OnThrowFlyingStopped);
		ThrowMovementComponent->RegisterComponent();

		if (SourceActor)
		{
			TArray<AActor*> IgnoreHitActors;
			SourceActor->GetAttachedActors(IgnoreHitActors);
			IgnoreHitActors.Add(SourceActor);
			ThrowMovementComponent->SetIgnoreHitActors(IgnoreHitActors);
		}

	}
	else
	{
		//ThrowMovementComponent->SetHomingTargetLocation(TargetLocation);
		ThrowMovementComponent->Velocity = ThrowDirection * ThrowSpeed;
		ThrowMovementComponent->SetUpdatedComponent(GetRootComponent());
	}

	if (ThrowFlyingSound)
	{
		if (!ThrowFlyingAudioComponent)
		{
			ThrowFlyingAudioComponent = NewObject<UAudioComponent>(this);
			ThrowFlyingAudioComponent->SetupAttachment(GetRootComponent());
			ThrowFlyingAudioComponent->RegisterComponent();
		}

		ThrowFlyingAudioComponent->SetSound(ThrowFlyingSound);
		ThrowFlyingAudioComponent->FadeIn(0.4f, 1.0f, 0.0f);
	}

	bIsThrowFlying = true;
}

void AP3Weapon::Server_ThrowPhysically(const FVector& ThrowDirection, class AActor* SourceActor)
{
	SetActorRotation(ThrowDirection.Rotation());

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
	
	if (!ensure(PrimComp))
	{
		return;
	}

	PrimComp->SetPhysicsLinearVelocity(ThrowDirection * ThrowSpeed);
	PrimComp->SetPhysicsAngularVelocityInDegrees(GetActorRotation().RotateVector(ThrowAngularVelocity));

	Instigator = Cast<APawn>(SourceActor);
}

void AP3Weapon::Server_Recall(class UP3HolderComponent* HolderComponent)
{
	RecallHolderComponent = HolderComponent;
	bIsRecallFlying = true;

	RecallStartLocation = GetActorLocation();
	RecallAgeSeconds = 0;

	const FVector TargetSocketLocation = RecallHolderComponent->GetHoldSocketTransform().GetLocation();
	const FVector OriginalOffset = (TargetSocketLocation - RecallStartLocation);
	const float OriginalDistance = OriginalOffset.Size();

	RecallDuration = OriginalDistance / FMath::Max(ThrowSpeed, 0.1f);
}

void AP3Weapon::StopRecall()
{
	RecallHolderComponent = nullptr;
	bIsRecallFlying = false;

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
	if (PrimComp)
	{
		PrimComp->SetSimulatePhysics(true);
	}
}

void AP3Weapon::Server_SetLastFiredProjectile(class AP3Projectile* Projectile)
{
	 Net_LastFiredProjectile = Projectile;

	 Server_SetDirty(*this);
}

bool AP3Weapon::IsRunOutOfDurability() const
{
	if (CmsHoldable.MaxUsableCountByPlayer > -1)
	{
		return (UseCountByPlayer >= CmsHoldable.MaxUsableCountByPlayer);
	}

	return false;
}

bool AP3Weapon::CanPickupCandidate() const
{
	return !IsActorBeingDestroyed() && DestoryTimeSeconds <= 0.f;
}

void AP3Weapon::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	Archive << Net_LastFiredProjectile;
}

void AP3Weapon::OnThrowRecallFinished()
{
	OnRecallFinished.Broadcast(this);

	bIsRecallFlying = false;
	RecallHolderComponent = nullptr;

	if (ThrowRecallCameraShake)
	{
		APlayerController* PlayerController = GetWorld()->GetFirstPlayerController();
		if (PlayerController && PlayerController->PlayerCameraManager)
		{
			PlayerController->PlayerCameraManager->PlayWorldCameraShake(
				GetWorld(), ThrowRecallCameraShake, GetActorLocation(),
				ThrowRecallCameraShakeInnerRadius, ThrowRecallCameraShakeOuterRadius, 1.0f, true);
		}
	}
}

void AP3Weapon::OnThrowFlyingStopped(const struct FHitResult& ImpactResult)
{
	if (ThrowFlyingAudioComponent)
	{
		ThrowFlyingAudioComponent->Stop();
	}

	if (ThrowLandSound)
	{
		UGameplayStatics::PlaySoundAtLocation(this, ThrowLandSound, GetActorLocation());
	}

	bIsThrowFlying = false;
}

void AP3Weapon::UpdateDestoryDynamicMaterial(float DeltaTime)
{
	if (DestroyMaterial)
	{
		const static FName NAME_ParameterPower = FName(TEXT("Power"));
		const static float ParameterPower = CVarP3WeaponDestoryTimeSecondes.GetValueOnGameThread() * 100.f;
		const float Alpha = DestoryTimeSeconds / CVarP3WeaponDestoryTimeSecondes.GetValueOnGameThread();
		
		const float DestoryPower = FMath::InterpExpoIn<float>(0.f, ParameterPower, Alpha);
		DestroyMaterial->SetScalarParameterValue(NAME_ParameterPower, DestoryPower);
	}
}

void UP3WeaponThrowMovementComponent::HandleImpact(const FHitResult& Hit, float TimeSlice/*=0.f*/, const FVector& MoveDelta /*= FVector::ZeroVector*/)
{
	AActor* HitActor = Hit.GetActor();
	if (HitActor && IgnoreHitActors.Contains(HitActor))
	{
		return;
	}

	Super::HandleImpact(Hit, TimeSlice, MoveDelta);
}

bool UP3WeaponThrowMovementComponent::HandleDeflection(FHitResult& Hit, const FVector& OldVelocity, const uint32 NumBounces, float& SubTickTimeRemaining)
{
	AActor* HitActor = Hit.GetActor();
	if (HitActor && IgnoreHitActors.Contains(HitActor))
	{
		return true;
	}

	return Super::HandleDeflection(Hit, OldVelocity, NumBounces, SubTickTimeRemaining);
}
