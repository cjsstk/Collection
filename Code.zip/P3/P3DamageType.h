#pragma once
// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "P3DamageType.generated.h"

UENUM(Blueprintable)
enum class EP3DamageType : uint8
{
	None UMETA(Hidden),
	Combat,
	Flame,
	Count UMETA(Hidden),
};
