// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "FoliageInstancedStaticMeshComponent.h"
#include "P3TreeFoliageComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3TreeFoliageComponent : public UFoliageInstancedStaticMeshComponent
{
	GENERATED_BODY()

public:	

protected:
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void ReplaceToP3Tree();

	UPROPERTY(EditDefaultsOnly, Category = P3)
	TSubclassOf<AActor> ReplaceActorClass;
};
