// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3GameMode.h"

#include "Animation/AnimationAsset.h"
#include "Engine/LevelStreaming.h"
#include "Engine/WorldComposition.h"
#include "GameFramework/PlayerState.h"
#include "Internationalization/Regex.h"
#include "Kismet/GameplayStatics.h"
#include "NavigationSystem.h"
#include "UObject/ConstructorHelpers.h"

#if UE_EDITOR
#include "Editor.h"
#include "Layout/SScrollBox.h"
#endif

#include "GameMode/P3ContributionSystem.h"
#include "P3BGMPlayer.h"
#include "P3ClientWorld.h"
#include "P3Core.h"
#include "P3Character.h"
#include "P3GameInstance.h"
#include "P3GameState.h"
#include "P3Log.h"
#include "P3PlayerController.h"
#include "P3RevivePointActor.h"


#if UE_EDITOR
class SDialogPickWorldCompositionPlayType : public SWindow
{
public:
	SLATE_BEGIN_ARGS(SDialogPickWorldCompositionPlayType)
	{
	}
		SLATE_ARGUMENT(FText, Title)
		SLATE_ARGUMENT(TArray<FName>, ZoneNames)
	SLATE_END_ARGS()

	enum class EPlayType
	{
		Streaming,
		LoadedLevelOnly,
		SelectedZone
	};

	void Construct(const FArguments& InArgs)
	{
		TSharedPtr<SScrollBox> ScrollBox;

		SWindow::Construct(SWindow::FArguments()
			.Title(InArgs._Title)
			.SupportsMinimize(false)
			.SupportsMaximize(false)
			//.SizingRule( ESizingRule::Autosized )
			.ClientSize(FVector2D(450, 450))
			[
				//SAssignNew(VerticalBox, SVerticalBox)
				SAssignNew(ScrollBox, SScrollBox)
			]);

		TSharedRef<SVerticalBox> VerticalBox = SNew(SVerticalBox);
		ScrollBox->AddSlot().AttachWidget(VerticalBox);

		{
			FOnClicked OnClicked;
			OnClicked.BindLambda([this] {
				this->UserResponse = EAppReturnType::Ok;
				this->SelectedPlayType = EPlayType::LoadedLevelOnly;
				this->RequestDestroyWindow();

				return FReply::Handled();
			});

			FText ButtonText = FText::AsCultureInvariant(TEXT("<로딩된 레벨만>"));

			TSharedRef<SButton> Button = SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.OnClicked(OnClicked)
				[
					SNew(STextBlock)
					.Text(ButtonText)
				];

			VerticalBox->AddSlot().AttachWidget(Button);
		}

		{
			FOnClicked OnClicked;
			OnClicked.BindLambda([this] {
				this->UserResponse = EAppReturnType::Ok;
				this->SelectedPlayType = EPlayType::Streaming;
				this->RequestDestroyWindow();

				return FReply::Handled();
			});

			FText ButtonText = FText::AsCultureInvariant(TEXT("<스트리밍>"));

			TSharedRef<SButton> Button = SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.OnClicked(OnClicked)
				[
					SNew(STextBlock)
					.Text(ButtonText)
				];

			VerticalBox->AddSlot().AttachWidget(Button);
		}

		for (FName ZoneName : InArgs._ZoneNames)
		{
			FOnClicked OnClicked;
			OnClicked.BindLambda([ZoneName, this] {
				this->UserResponse = EAppReturnType::Ok;
				this->SelectedPlayType = EPlayType::SelectedZone;
				this->SelectedZoneName = ZoneName;
				this->RequestDestroyWindow();

				return FReply::Handled();
			});

			FText ButtonText = FText::AsCultureInvariant(ZoneName.ToString());

			TSharedRef<SButton> Button = SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Left)
				.OnClicked(OnClicked)
				[
					SNew(STextBlock)
					.Text(ButtonText)
				];

			VerticalBox->AddSlot().AttachWidget(Button);
		}
	}

	/** Displays the dialog in a blocking fashion */
	EAppReturnType::Type ShowModal()
	{
		GEditor->EditorAddModalWindow(SharedThis(this));
		return UserResponse;
	}

	EPlayType GetSelectedPlayType() const { return SelectedPlayType; }
	FName GetSelectedZoneName() const { return SelectedZoneName; }

private:
	EAppReturnType::Type UserResponse = EAppReturnType::Cancel;
	EPlayType SelectedPlayType = EPlayType::Streaming;
	FName SelectedZoneName;
	

};
#endif // UE_EDITOR


AP3GameMode::AP3GameMode()
{
	DefaultPawnClass = AP3Character::StaticClass();
	GameStateClass = AP3GameState::StaticClass();

	PrimaryActorTick.bCanEverTick = true;
}

void AP3GameMode::PreInitializeComponents()
{
	Super::PreInitializeComponents();
}

static FString _StrippedMapName(const FString& MapName)
{
	const FRegexPattern PieMapPattern(TEXT("UEDPIE_\\d_"));
	FRegexMatcher Matcher(PieMapPattern, MapName);
	FString StrippedMapName = MapName;

	if (Matcher.FindNext())
	{
		int32 Beginning = Matcher.GetMatchBeginning();
		int32 Ending = Matcher.GetMatchEnding();
		StrippedMapName = MapName.Mid(Ending, MapName.Len());
	}

	return StrippedMapName;
}

void AP3GameMode::InitGame(const FString& MapName, const FString& Options, FString& ErrorMessage)
{
	Super::InitGame(MapName, Options, ErrorMessage);

	UWorld* World = GetWorld();

#if WITH_EDITORONLY_DATA
	if (World->IsPlayInEditor() && World->WorldComposition)
	{
		TArray<FName> ZoneNames;

		const TArray<FWorldCompositionTile>& Tiles = World->WorldComposition->GetTilesList();
		for (const FWorldCompositionTile& Tile : Tiles)
		{
			for (const FName& ZoneName : Tile.Info.P3ZoneNames)
			{
				ZoneNames.AddUnique(ZoneName);
			}
		}

		ZoneNames.Sort([](const FName& A, const FName& B) -> bool {
			return A.FastLess(B);
		});

		TSharedRef<SDialogPickWorldCompositionPlayType> PickPlayTypeDialog = SNew(SDialogPickWorldCompositionPlayType)
			.Title(FText::AsCultureInvariant(TEXT("플레이타입을 선택하세요")))
			.ZoneNames(ZoneNames);
		
		//if (PickPlayTypeDialog->ShowModal() != EAppReturnType::Cancel)
		//{
		//	if (PickPlayTypeDialog->GetSelectedPlayType() == SDialogPickWorldCompositionPlayType::EPlayType::LoadedLevelOnly)
			{
				UP3GameInstance* GameInstance = P3Core::GetP3GameInstanceChecked(*this);

				for (ULevelStreaming* LevelStreaming : World->WorldComposition->TilesStreaming)
				{
					// We need to manually load level
					LevelStreaming->bDisableDistanceStreaming = true;

					if (GameInstance && GameInstance->GetEditorSteramingLevelPackageNames().Contains(LevelStreaming->PackageNameToLoad))
					{
						LevelStreaming->bShouldBlockOnLoad	= true;
						LevelStreaming->SetShouldBeLoaded(true);
						LevelStreaming->SetShouldBeVisible(true);

						UE_LOG(P3Log, Display, TEXT("Loading streaming level: %s"), *LevelStreaming->PackageNameToLoad.ToString());
					}
					else
					{
						LevelStreaming->SetShouldBeLoaded(false);
						LevelStreaming->SetShouldBeVisible(false);
					}
				}

				bStopZoneAutoChange = true;
			}
		//	else if (PickPlayTypeDialog->GetSelectedPlayType() == SDialogPickWorldCompositionPlayType::EPlayType::SelectedZone)
		//	{
		//		const FName SelectedZoneName = PickPlayTypeDialog->GetSelectedZoneName();

		//		TSet<FName> ZoneLevelPackageNames;

		//		for (const FWorldCompositionTile& Tile : Tiles)
		//		{
		//			if (Tile.Info.P3ZoneNames.Contains(SelectedZoneName))
		//			{
		//				ZoneLevelPackageNames.Add(FName(*_StrippedMapName(Tile.PackageName.ToString())));
		//			}
		//		}

		//		for (ULevelStreaming* LevelStreaming : World->WorldComposition->TilesStreaming)
		//		{
		//			// We need to manually load level
		//			LevelStreaming->bDisableDistanceStreaming = true;

		//			if (ZoneLevelPackageNames.Contains(FPackageName::GetShortFName(LevelStreaming->PackageNameToLoad.ToString())))
		//			{
		//				LevelStreaming->bShouldBlockOnLoad	= true;
		//				LevelStreaming->SetShouldBeLoaded(true);
		//				LevelStreaming->SetShouldBeVisible(true);

		//				UE_LOG(P3Log, Display, TEXT("Loading streaming level: %s"), *LevelStreaming->PackageNameToLoad.ToString());
		//			}
		//			else
		//			{
		//				LevelStreaming->SetShouldBeLoaded(false);
		//				LevelStreaming->SetShouldBeVisible(false);
		//			}
		//		}

		//		bStopZoneAutoChange = true;
		//	}
		//}
	}
#endif

	if (P3Core::IsP3NetModeDedicatedServer(*this))
	{
		const FName ZoneName = FName(*UGameplayStatics::ParseOption(Options, TEXT("Zone")));

		if (World->WorldComposition && ensure(!ZoneName.IsNone()))
		{
			P3JsonLog(Display, "Init Dedi Game with World Composition", TEXT("Zone"), ZoneName.ToString());

			TSet<FName> ZoneLevelPackageNames;

			const TArray<FWorldCompositionTile>& Tiles = World->WorldComposition->GetTilesList();
			for (const FWorldCompositionTile& Tile : Tiles)
			{
				if (Tile.Info.P3ZoneNames.Contains(ZoneName))
				{
					ZoneLevelPackageNames.Add(Tile.PackageName);
				}
			}

			for (ULevelStreaming* LevelStreaming : World->WorldComposition->TilesStreaming)
			{
				// We need to manually load level
				LevelStreaming->bDisableDistanceStreaming = true;

				if (ZoneLevelPackageNames.Contains(LevelStreaming->PackageNameToLoad))
				{
					LevelStreaming->bShouldBlockOnLoad	= true;
					LevelStreaming->SetShouldBeLoaded(true);
					LevelStreaming->SetShouldBeVisible(true);

					UE_LOG(P3Log, Display, TEXT("Loading streaming level: %s"), *LevelStreaming->PackageNameToLoad.ToString());
				}
				else
				{
					LevelStreaming->SetShouldBeLoaded(false);
					LevelStreaming->SetShouldBeVisible(false);
				}
			}
		}
	}

	GetWorld()->FlushLevelStreaming(EFlushLevelStreamingType::Full);

	if (GIsClient && GetWorld()->WorldComposition)
	{
		GetWorld()->bRequestedBlockOnAsyncLoading = true;
	}
}

FString AP3GameMode::InitNewPlayer(APlayerController* NewPlayerController, const FUniqueNetIdRepl& UniqueId, const FString& Options, const FString& Portal)
{
	FString Result = Super::InitNewPlayer(NewPlayerController, UniqueId, Options, Portal);

	AP3PlayerController* P3PlayerController = Cast<AP3PlayerController>(NewPlayerController);

	if (P3PlayerController)
	{
		P3PlayerController->Server_SetOptions(Options);
	}

	return Result;
}

void AP3GameMode::StartPlay()
{
	Super::StartPlay();

	BGMPlayer = NewObject<UP3BGMPlayer>(this);
	BGMPlayer->PlayNormalBGM();

	Server_SetPlayerReviver(NewObject<UP3ReviveAtNearestPointPlayerReviver>(this));

	if (bStopZoneAutoChange)
	{
		UP3World* P3World = P3Core::GetP3World(*this);
		UP3ClientWorld* ClientWorld = P3World ? P3World->GetClientWorld() : nullptr;
		if (ClientWorld)
		{
			ClientWorld->StopZoneAutoChange();
		}
	}
}

APawn* AP3GameMode::SpawnDefaultPawnFor_Implementation(AController* NewPlayer, AActor* StartSpot)
{
	// Don't allow pawn to be spawned with any pitch or roll
	FRotator StartRotation(ForceInit);
	StartRotation.Yaw = StartSpot->GetActorRotation().Yaw;
	FVector StartLocation = StartSpot->GetActorLocation();

	AP3PlayerController* P3PlayerController = Cast<AP3PlayerController>(NewPlayer);
	if (P3PlayerController)
	{
		const FString& Options = P3PlayerController->Server_GetOptions();

		if (UGameplayStatics::HasOption(Options, TEXT("PosX")))
		{
			StartLocation.X = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("PosX")));
			StartLocation.Y = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("PosY")));
			StartLocation.Z = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("PosZ")));

			StartRotation.Roll = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("RotX")));
			StartRotation.Pitch = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("RotY")));
			StartRotation.Yaw = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("RotZ")));

			FRotator ControlRotation;
			ControlRotation.Roll = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("CRotX")));
			ControlRotation.Pitch = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("CRotY")));
			ControlRotation.Yaw = FCString::Atof(*UGameplayStatics::ParseOption(Options, TEXT("CRotZ")));

			P3PlayerController->SetControlRotation(ControlRotation);
		}
	}

	FTransform Transform = FTransform(StartRotation, StartLocation);
	return SpawnDefaultPawnAtTransform(NewPlayer, Transform);
}

class USkeleton* AP3GameMode::GetSkeletonFromAnimation(const class UAnimationAsset* AnimationAsset)
{
	if (!AnimationAsset)
	{
		return nullptr;
	}

	return AnimationAsset->GetSkeleton();
}

void AP3GameMode::Server_SetPlayerReviver(class UP3PlayerReviver* NewPlayerReviver)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (!NewPlayerReviver)
	{
		return;
	}

	if (Server_PlayerReviver)
	{
		Server_PlayerReviver->StopReviver();
		Server_PlayerReviver = nullptr;
	}

	Server_PlayerReviver = NewPlayerReviver;
	Server_PlayerReviver->StartReviver();
}

void AP3GameMode::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	float DiffTimeSeconds = FApp::GetCurrentTime() - FApp::GetLastTime();
	float RawFrameTimeMsec = DiffTimeSeconds * 1000.0f;
	AverageFrameTimeMsec = 0.9f * AverageFrameTimeMsec + 0.1f * RawFrameTimeMsec;

	if (BGMPlayer)
	{
		BGMPlayer->Tick();
	}

	UNavigationSystemV1* NavSys = UNavigationSystemV1::GetNavigationSystem(this);
		
	if (NavSys)
	{
		if (P3Core::IsP3NetModeClient(*this))
		{
			NavSys->SetMaxSimultaneousTileGenerationJobsCount(1);
		}
	}
}
