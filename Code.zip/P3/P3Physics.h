// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

#define ECC_CLIMB		ECC_GameTraceChannel1	// Trace
#define ECC_COMBAT		ECC_GameTraceChannel2	// Trace
#define ECC_FLAME		ECC_GameTraceChannel3	// Object
#define ECC_PROJECTILE	ECC_GameTraceChannel4	// Object

namespace P3Physics
{
	FName GetSurfaceName(EPhysicalSurface SurfaceType);
}
