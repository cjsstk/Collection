// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3CharacterEmoteAnimation.generated.h"

USTRUCT(Blueprintable)
struct FP3CharacterEmoteAnimation
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AnimationSequence")
	class UAnimSequenceBase* EmoteAnimationStart = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AnimationSequence")
	class UAnimSequenceBase* EmoteAnimationLoop = nullptr;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "AnimationSequence")
	class UAnimSequenceBase* EmoteAnimationEnd = nullptr;
};
