// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Character.h"

#include "Animation/AnimInstance.h"
#include "BrainComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "Engine/World.h"
#include "Camera/CameraComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/InputComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/StaticMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/Controller.h"
#include "GameFramework/SpringArmComponent.h"
#include "GameFramework/PlayerController.h"
#include "HeadMountedDisplayFunctionLibrary.h"
#include "Particles/ParticleSystemComponent.h"
#include "Perception/AIPerceptionComponent.h"
#include "Perception/AIPerceptionTypes.h"
#include "Perception/AISense_Hearing.h"
#include "Net/UnrealNetwork.h"
#include "Kismet/KismetMathLibrary.h"

#include "Action/P3PawnActionComponent.h"
#include "AI/P3AIController.h"
#include "Character/P3CharacterTemperatureComponent.h"
#include "Chemical/P3FlammableComponent.h"
#include "Chemical/P3WetComponent.h"
#include "Combat/P3BossChallenge.h"
#include "Command/P3CommandComponent.h"
#include "Crafting/P3CraftingAction.h"
#include "GameMode/P3ContributionSystem.h"
#include "Item/P3Item.h"
#include "Item/P3ItemManager.h"
#include "Network/P3WorldNet.h"
#include "P3.h"
#include "P3AggroComponent.h"
#include "P3AnimNotify.h"
#include "P3AnimInstance.h"
#include "P3AttributesComponent.h"
#include "P3Backpack.h"
#include "P3CharacterEffectComponent.h"
#include "P3CharacterHealthPointComponent.h"
#include "P3CharacterMovementComponent.h"
#include "P3CombatComponent.h"
#include "P3CombatResponseComponent.h"
#include "P3ComboTableComponent.h"
#include "P3Combat.h"
#include "P3DamageMetersComponent.h"
#include "P3Destructible.h"
#include "P3EquipmentComponent.h"
#include "P3ExperiencePointComponent.h"
#include "P3GameInstance.h"
#include "P3GameUserSettings.h"
#include "P3GameState.h"
#include "P3HealthPointComponent.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3InventoryComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3LootDropComponent.h"
#include "P3PartComponent.h"
#include "P3PartInventoryComponent.h"
#include "P3PickupableComponent.h"
#include "P3PickupComponent.h"
#include "P3PushComponent.h"
#include "P3PlayerController.h"
#include "P3Projectile.h"
#include "P3ServerPlayerController.h"
#include "P3ServerWorld.h"
#include "P3StaminaPointComponent.h"
#include "P3Store.h"
#include "P3ThreatListComponent.h"
#include "P3Weapon.h"
#include "P3Tags.h"
#include "P3Tree.h"
#include "P3QuestComponent.h"

#if WITH_EDITOR
#include "AssetRegistryModule.h"
#include "Logging/MessageLog.h"
#include "Misc/UObjectToken.h"
#endif

#if PLATFORM_WINDOWS
#include "AllowWindowsPlatformTypes.h"
#include "Network/pb/dedilistener.pb.h"
#include "HideWindowsPlatformTypes.h"
#else
#include "Network/pb/dedilistener.pb.h"
#endif

extern TAutoConsoleVariable<int32> CVarP3HealthDebug;
extern TAutoConsoleVariable<int32> CVarP3DefaultCharClass;

TAutoConsoleVariable<int32> CVarP3BlockingMovementMode(
	TEXT("p3.blockingMovementMode"),
	1,
	TEXT("0: same as normal, 1: always turn character to camera direction, 2: same with 1 but turn camera to character first"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3StanceDebug(
	TEXT("p3.stanceDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3FallDamageToDropPickableDebug(
	TEXT("p3.fallDamageToDropPickupable"),
	0,
	TEXT("Character damaged larger than this number, drop current Pickable item"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3GameplayTagDebug(
	TEXT("p3.gameplayTagDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3CharacterNotMovingAffectNavigationTimeSeconds(
	TEXT("p3.characterNotMovingAffectNavigationTimeSeconds"),
	-1,
	TEXT("If character doesn't move for this seconds, character affects navigation. set <= 0 to disable this feature"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3PutAwayTimeBySprint(
	TEXT("p3.putAwayTimeBySprint"),
	0.2f,
	TEXT("Character put away weapon if sprint time is shorter than specified value (in seconds)"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3AutoPutAwayBySprint(
	TEXT("p3.autoPutAwayBySprint"),
	1,
	TEXT("1: enable AutoPutAway. 0: disable AutoPutAway"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3HoldingKeyDurationSeconds(
	TEXT("p3.holdingKeyDurationSeconds"),
	1.0f,
	TEXT("How long does it takes to holding key actually effects?"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3HoldingKeyMinDurationSeconds(
	TEXT("p3.holdingKeyMinDurationSeconds"),
	0.3f,
	TEXT("If holding less than this, release event will arise"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CharacterDebug(
	TEXT("p3.characterDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ControllerRotationDebug(
	TEXT("p3.controllerRotationDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ItemDebug(
	TEXT("p3.itemDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3AttributeDebug(
	TEXT("p3.attributeDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3AIDebug(
	TEXT("p3.aiDebug"),
	0,
	TEXT("0: None, 1: Behavior Tree, 2: Blackboard"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3RangeWeaponAimMode(
	TEXT("p3.rangeWeaponAimMode"),
	1,
	TEXT("0: Player should toggle aim mode. 1: aim mode is defaulted. can't be turned off"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ClothSimulationDistance(
	TEXT("p3.clothSimulationDistance"),
	3000,
	TEXT("Characters further than this will pause cloth simulation"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ConsumableUIAutoCloseTime(
	TEXT("p3.consumableUIAutoCloseTime"),
	3.0f,
	TEXT("Consumable UI is closed after the specified  time"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3HitDamageCooldownTimeSeconds(
	TEXT("p3.hitDamageCooldownTimeSeconds"),
	1.0f,
	TEXT("Character will not take physical-hit damage by same actor twice within this time"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3MountDebug(
	TEXT("p3.mountDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3MountPointDebug(
	TEXT("p3.mountPointDebug"),
	0,
	TEXT("Draw mount point"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3MountedCameraDistanceMultiplier(
	TEXT("p3.mountedCameraDistanceMultiplier"),
	2.0f,
	TEXT("Camera distance multiplier during mounted"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3MountedCameraBackOriginRotation(
	TEXT("p3.mountedCameraBackOriginRotation"),
	1,
	TEXT("1: Camera come back origin rotation during mounted"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3MountedCameraBackOriginRotationSpeed(
	TEXT("p3.mountedCameraBackOriginRotationSpeed"),
	0.9f,
	TEXT("Camera speed of come back origin rotation during mounted"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3CharacterEffectDebug(
	TEXT("p3.characterEffectDebug"),
	0,
	TEXT("1: enable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3PlayerRagdollMaxSeconds(
	TEXT("p3.playerRagdollMaxSeconds"),
	10.0f,
	TEXT("Max ragdoll duration for player"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3StaminaConsumptionDuringChargingMultiplier(
	TEXT("p3.staminaConsumptiondDuringChargingMultiplier"),
	1.0f,
	TEXT("stamina consumption multiplier during charging"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3StaminaConsumptionOfLargeCharacterSprintMultiplier(
	TEXT("p3.staminaConsumptionOfLargeCharacterSprintMultiplier"),
	0.2f,
	TEXT("stamina consumption of Large Character multiplier during sprint"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3EnableCorssHairMode(
	TEXT("p3.enableCrossHairMode"),
	0,
	TEXT("0: disable, 1: enable"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3ComboTableDebug(
	TEXT("p3.comboTableDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3TeamIDDebug(
	TEXT("p3.teamIDDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3RescueByHoldingInput(
	TEXT("p3.rescueByHoldingInput"),
	1,
	TEXT("1: holding interaction key will rescue. 0: holding interaction key will carry"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3RotateCameraOnMountingResuced(
	TEXT("p3.rotateCameraOnMountingRescued"),
	0,
	TEXT("1: rotate camera on mounting rescued. 0: not rotate camera on mounting rescued"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3SlidingCameraOffset(
	TEXT("p3.slidingCameraOffset"),
	1,
	TEXT("0: disable, 1: enable"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3SlidingCameraArmLength(
	TEXT("p3.slidingCameraArmLength"),
	1,
	TEXT("0: disable, 1: enable"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3SlidingCameraFollow(
	TEXT("p3.slidingCameraFollow"),
	1,
	TEXT("0: disable, 1: enable"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SlidingCameraFollowSpeed(
	TEXT("p3.slidingCameraFollowSpeed"),
	5.0f,
	TEXT("Camera speed of look at characters's back on sliding"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3SlidingCameraFOV(
	TEXT("p3.slidingCameraFOV"),
	0,
	TEXT("0: disable, 1: enable"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3DisableInteractionInCombatStance(
	TEXT("p3.disableInteractionInCombatStance"),
	1,
	TEXT("Set 0 to allow interaction during combat stance. This can make combat difficult, around objects"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3AllowInteractionDuringPutawayWeaponAction(
	TEXT("p3.allowInteractionDuringPutawayWeaponAction"),
	1,
	TEXT("Set 1 to allow interaction during put away weapon, to make it easier"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ReviveFadeOutDurationSeconds(
	TEXT("p3.reviveFadeOutDurationSeconds"),
	6.0f,
	TEXT("on revive, fade out seconds"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3ReviveFadeInDurationSeconds(
	TEXT("p3.reviveFadeInDurationSeconds"),
	1.5f,
	TEXT("on revive, fade in seconds"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3UseCharacterServerLOD(
	TEXT("p3.useCharacterServerLOD"),
	1,
	TEXT("0: disable LOD"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3CharacterServerLODSleepDistance(
	TEXT("p3.characterServerLODSleepDistance"),
	20000.0f,
	TEXT("If player is further than this, server character will be in sleep state"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3CharacterServerLODDebug(
	TEXT("p3.characterServerLODDebug"),
	0,
	TEXT("1: enable debug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3UseStumble(
	TEXT("p3.useStumble"),
	0,
	TEXT("Toggle stumbling feature"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3ActionDataDriven(
	TEXT("p3.actionDataDriven"),
	0,
	TEXT(""), ECVF_Cheat);

//////////////////////////////////////////////////////////////////////////
// FP3CharacterInitData

FP3CharacterInitData& FP3CharacterInitData::operator=(const FP3CharacterInitParams& Source)
{
	CharLevel = Source.CharLevel;
	ExperiencePoint = Source.ExperiencePoint;
	Items = Source.Items;
	return *this;
}

void FP3CharacterInitData::Clear()
{
	CharLevel = 0;
	ExperiencePoint = 0;
	Items.Empty();
}

bool FP3CharacterInitData::IsItemListEmpty() const
{
	return Items.Num() == 0;
}

//////////////////////////////////////////////////////////////////////////
// AP3Character

AP3Character::AP3Character(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<UP3CharacterMovementComponent>(ACharacter::CharacterMovementComponentName))
{
	bAlwaysRelevant = true;
	bNetLoadOnClient = false;

	// Set size for collision capsule
	GetCapsuleComponent()->InitCapsuleSize(42.f, 96.0f);

	// Generate hit event
	GetCapsuleComponent()->BodyInstance.bNotifyRigidBodyCollision = true;

	// set our look rates for input
	BaseLookRightRate = 45.f;
	BaseLookUpRate = 45.f;

	CameraMinDistance = 100.0f;
	CameraMaxDistance = 500.0f;
	CameraDefaultDistance = 300.0f;

	// Don't rotate when the controller rotates. Let that just affect the camera.
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	// We need to keep jump pressed to start sliding
	JumpMaxHoldTime = 2.0f;

	// Configure character movement
	GetCharacterMovement()->bOrientRotationToMovement = true; // Character moves in the direction of input...	
	GetCharacterMovement()->RotationRate = FRotator(540.0f, 540.0f, 0.0f); // ...at this rotation rate
	GetCharacterMovement()->JumpZVelocity = 400.f;
	GetCharacterMovement()->AirControl = 0.2f;
	GetCharacterMovement()->TouchForceFactor = 0.0f;
	GetCharacterMovement()->RepulsionForce = 0.0f;

	// Create a camera boom (pulls in towards the player if there is a collision)
	CameraBoom = CreateDefaultSubobject<USpringArmComponent>(TEXT("CameraBoom"));
	CameraBoom->SetupAttachment(RootComponent);
	CameraBoom->TargetArmLength = CameraDefaultDistance; // The camera follows at this distance behind the character	
	CameraBoom->bUsePawnControlRotation = true; // Rotate the arm based on the controller
	CameraBoom->PrimaryComponentTick.bStartWithTickEnabled = false;
	CameraBoom->PrimaryComponentTick.bAllowTickOnDedicatedServer = false;
	CameraBoom->PrimaryComponentTick.SetTickFunctionEnable(false);
	CameraBoom->bTickInEditor = false;
	CameraBoom->bAutoActivate = false;

	// Create a follow camera
	FollowCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FollowCamera"));
	FollowCamera->SetupAttachment(CameraBoom, USpringArmComponent::SocketName); // Attach the camera to the end of the boom and let the boom adjust to match the controller orientation
	FollowCamera->bUsePawnControlRotation = false; // Camera does not rotate relative to arm
	FollowCamera->PrimaryComponentTick.bStartWithTickEnabled = false;
	FollowCamera->PrimaryComponentTick.bAllowTickOnDedicatedServer = false;
	FollowCamera->PrimaryComponentTick.SetTickFunctionEnable(false);
	FollowCamera->bAutoActivate = false;

	AudioListenerPositionComponent = CreateDefaultSubobject<USceneComponent>(TEXT("AudioListenerPosition"));
	AudioListenerPositionComponent->SetupAttachment(RootComponent);
	AudioListenerPositionComponent->SetComponentTickEnabled(false);

	if (GetMesh())
	{
		// Force dedicated server to update animations
		//GetMesh()->MeshComponentUpdateFlag = EMeshComponentUpdateFlag::AlwaysTickPoseAndRefreshBones;
	}


	// Note: The skeletal mesh and anim blueprint references on the Mesh component (inherited from Character) 
	// are set in the derived blueprint asset named MyCharacter (to avoid direct content references in C++)

	ActionComponent = CreateDefaultSubobject<UP3PawnActionComponent>(TEXT("ActionComponent"));
	CommandComponent = CreateDefaultSubobject<UP3CommandComponent>(TEXT("CommandComponent"));
	StaminaComponent = CreateDefaultSubobject<UP3StaminaPointComponent>(TEXT("StaminaComponent"));
	PickupComponent = CreateDefaultSubobject<UP3PickupComponent>(TEXT("PickupComponent"));
	PushComponent = CreateDefaultSubobject<UP3PushComponent>(TEXT("PushComponent"));
	TemperatureComponent = CreateDefaultSubobject<UP3CharacterTemperatureComponent>(TEXT("TemperatureComponent"));
	TemperatureComponent->SetupAttachment(RootComponent);
	FlammableComponent = CreateDefaultSubobject<UP3FlammableComponent>(TEXT("FlammableComponent"));
	FlammableComponent->SetupAttachment(RootComponent);
	WetComponent = CreateDefaultSubobject<UP3WetComponent>(TEXT("WetComponent"));
	InventoryComponent = CreateDefaultSubobject<UP3InventoryComponent>(TEXT("InventoryComponent"));
	StoreComponent = CreateDefaultSubobject<UP3StoreComponent>(TEXT("StoreComponent"));
	EquipmentComponent = CreateDefaultSubobject<UP3EquipmentComponent>(TEXT("EquipmentComponent"));
	PartInventoryComponent = CreateDefaultSubobject<UP3PartInventoryComponent>(TEXT("PartInventoryComponent"));
	EffectComponent = CreateDefaultSubobject<UP3CharacterEffectComponent>(TEXT("EffectComponent"));
	QuestComponent = CreateDefaultSubobject<UP3QuestComponent>(TEXT("QuestComponent"));

	JumpMaxCount = 10E5;

}

void AP3Character::PostActorCreated()
{
	Super::PostActorCreated();

	RegisterToP3World(*this);
}

void AP3Character::Client_OnDisconnected()
{
	if (ActionComponent)
	{
		ActionComponent->Client_OnDisconnected();
	}

	if (ComboTableComponent)
	{
		ComboTableComponent->Client_OnDisconnected();
	}

	if (GetP3CharacterMovementBP())
	{
		GetP3CharacterMovementBP()->Client_ClearMovementData();
	}

	CharacterStore = FP3CharacterStore();
}

void AP3Character::NetSerialize(FArchive& Archive)
{
	if (Archive.IsLoading())
	{
		Net_bInitialized = true;
	}

	Archive << Net_bAIControlled;
	Archive << Net_bPlayerControlled;
	Archive << Net_PartHealthPoints;
	Archive << Net_AIDebugString;
	Archive << Net_bShowHealthBar;
	Archive << Server_LOD;

	Net_GameplayTagContainer.Serialize(Archive);

	if (Archive.IsLoading())
	{
		FP3CharacterStore NewStore;
		FP3CharacterStore::StaticStruct()->SerializeBin(Archive, &NewStore);
		SetCharacterStoreBySync(NewStore);
	}
	else
	{
		FP3CharacterStore::StaticStruct()->SerializeBin(Archive, &CharacterStore);
	}
}

class UP3StoreComponent* AP3Character::GetStoreComponent() const
{
	return StoreComponent;
}

void AP3Character::NetSerializeMovement(FArchive& Archive)
{
	if (Archive.IsLoading())
	{
		const uint8 OldReplicatedMovementMode = ReplicatedMovementMode;

		Archive << NetMovement_AimRotator;
		Archive << ReplicatedMovementMode;

#if FIXME_CHARACTER_MOVEMENT_CLIENT_AUTHORITY
		Archive << LastControlInputVector;
#endif

		if (GetCharacterMovement())
		{
			GetCharacterMovement()->bNetworkUpdateReceived = true;
			GetCharacterMovement()->bNetworkMovementModeChanged =
				(GetCharacterMovement()->bNetworkMovementModeChanged
					|| (OldReplicatedMovementMode != ReplicatedMovementMode));
		}
	}
	else
	{
		if (GetCharacterMovement())
		{
			ReplicatedMovementMode = GetCharacterMovement()->PackNetworkMovementMode();
		}

		if (Controller)
		{
			NetMovement_AimRotator = Controller->GetControlRotation();
		}
		else
		{
			NetMovement_AimRotator = GetActorRotation();
		}

		Archive << NetMovement_AimRotator;
		Archive << ReplicatedMovementMode;

#if FIXME_CHARACTER_MOVEMENT_CLIENT_AUTHORITY
		Archive << LastControlInputVector;
#endif
	}
}

void AP3Character::Server_SetPlayerControlled(bool bPlayerControlled)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	Net_bInitialized = true;
	Net_bPlayerControlled = bPlayerControlled;

	Server_SetDirty(*this);
}

void AP3Character::Server_InitBaseInfo(const FP3CharacterInitParams& Params)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	CharacterStore.CharacterId = Params.CharacterId;
	CharacterStore.DisplayName = Params.DisplayName;
	CharacterStore.CharClass = Params.CharClass;
	CharacterStore.HairName = Params.HairName;
	CharacterStore.ArmorName = Params.ArmorName;

	if (ensure(InventoryComponent))
	{
		InventoryComponent->Server_InitItems(Params.Items);
	}

	if (ensure(QuestComponent))
	{
		QuestComponent->Server_InitQuests(Params.Quests);
	}

	ensure(InitialCharData.IsItemListEmpty());

	InitialCharData = Params;
}

void AP3Character::Server_InitDefaultItems()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!InventoryComponent)
	{
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);

	if (!ensure(WorldNet))
	{
		return;
	}

	const UP3GameRule& GameRule = P3Core::GetGameRule(*this);

	for (auto&& Iter : GameRule.DefaultInventoryItems)
	{
		const itemkey ItemKey = Iter.Key;
		int32 NumItems = Iter.Value;

		const FP3CmsItem& ItemDesc = P3Cms::GetItem(ItemKey);
		if (ItemDesc.MaxCountInInventory > 0 && NumItems > ItemDesc.MaxCountInInventory)
		{
			NumItems = ItemDesc.MaxCountInInventory;
		}

		const int32 NumExistingItems = InventoryComponent->GetNumItemsByKey(ItemKey);

		if (NumExistingItems < NumItems)
		{
			if (NumExistingItems > 0)
			{
				const FP3Item Item = InventoryComponent->GetItemByKey(ItemKey);
				ensure(Item.IsValid());

				InventoryComponent->Server_AddItemByKeyAndCount(ItemKey, NumItems - NumExistingItems);
			}
			else
			{
				UP3ItemManager* ItemManager = P3Core::GetItemManager(*this);
				if (ensure(ItemManager))
				{
					const FP3Item Item = ItemManager->CreateItem(ItemKey, NumItems, "InitDefaultItems");

					if (ensure(Item.IsValid()))
					{
						InventoryComponent->Server_AddItem(Item);
					}
				};
			}
		}
	}

	Server_SetDirty(*this);
}

void AP3Character::Standalone_InitBaseInfo()
{
	AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());
	if (!MyController || !MyController->IsLocalController())
	{
		return;
	}

	UP3World* P3World = P3Core::GetP3World(*this);
	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();
	if (!ensure(GameInstance))
	{
		return;
	}

	charid CharacterId = GameInstance->GetCharacterId();
	FText DisplayName = FText::AsCultureInvariant(GameInstance->GetAccountName());
	EP3CharClass CharClass = (EP3CharClass)CVarP3DefaultCharClass.GetValueOnGameThread();
	int32 CharLevel = 1;
	int32 ExperiencePoint = 0;

	FName HairName;
	FName ArmorName;

	// Select random hair for now
	const UDataTable* HairTable = P3Cms::GetCharacterHairTable();

	if (HairTable)
	{
		const TArray<FName> HairNames = HairTable->GetRowNames();
		if (HairNames.Num() > 0)
		{
			HairName = HairNames[FMath::Rand() % HairNames.Num()];
		}
	}

	// Select random armor for now
	const UDataTable* ArmorTable = P3Cms::GetCharacterArmorTable();

	if (ArmorTable)
	{
		const TArray<FName> ArmorNames = ArmorTable->GetRowNames();
		if (ArmorNames.Num() > 0)
		{
			ArmorName = ArmorNames[FMath::Rand() % ArmorNames.Num()];
		}
	}

	TArray<FP3CharacterItem> DBItems;

	for (const FP3CmsInitialItem* InitialItem : P3Cms::GetInitialItems(CharClass))
	{
		UP3ItemManager* ItemManager = P3Core::GetItemManager(*this);
		if (ensure(ItemManager))
		{
			const FP3Item Item = ItemManager->CreateItem(InitialItem->ItemCmsKey, InitialItem->Stack, "Standalone_InitBaseInfo");

			if (ensure(Item.IsValid()))
			{
				FP3CharacterItem DBItem;
				DBItem.Item.Id = Item.Id;
				DBItem.Item.Key = Item.Key;
				DBItem.Item.Stack = Item.Stack;
				DBItem.Slot = InitialItem->Slot;
				DBItems.Add(DBItem);
			}
		}
	}

	FP3CharacterInitParams Params = {
		CharacterId,
		DisplayName,
		CharClass,
		HairName,
		ArmorName,
		CharLevel,
		ExperiencePoint,
		DBItems
	};

	Server_InitBaseInfo(Params);
	Server_InitDefaultItems();

	if (InventoryComponent)
	{
		InventoryComponent->SortInvenItems();

		InventoryComponent->OnChangeConsumable.Broadcast();
	}
}

void AP3Character::SetCharacterStore(const FP3CharacterStore& InCharacterStore)
{
	FP3CharacterStore OldStore = CharacterStore;

	CharacterStore = InCharacterStore;

	OnCharacterStoreChanged.Broadcast(OldStore, CharacterStore);

	ConsiderChangeWeaponAttachment();
}

void AP3Character::SetCharacterStoreBySync(const FP3CharacterStore& InCharacterStore)
{
	if (!CharacterStore.bIsRagdollized && InCharacterStore.bIsRagdollized)
	{
		Ragdollize();
	}
	else if (CharacterStore.bIsRagdollized && !InCharacterStore.bIsRagdollized)
	{
		Unragdollize();
	}

	SetCharacterStore(InCharacterStore);

	UpdateHairComponent();
	UpdateArmorComponent();

	UP3AttributesComponent* AttributeComp = FindComponentByClass<UP3AttributesComponent>();
	if (AttributeComp)
	{
		AttributeComp->SetLevel(CharacterStore.CharLevel);
		AttributeComp->UpdateAttributes();
	}

	if (ExperienceComponent)
	{
		ExperienceComponent->SetMaxExperiencePoint(CharacterStore.CharLevel);
	}
}

void AP3Character::SetCharacterStoreByAction(const class UP3PawnAction& Action, const FP3CharacterStore& InCharacterStore)
{
	SetCharacterStore(InCharacterStore);
}

void AP3Character::SetCharacterStoreByCommand(const class UP3Command& Command, const FP3CharacterStore& InCharacterStore)
{
	SetCharacterStore(InCharacterStore);
}

class UP3CharacterMovementComponent* AP3Character::GetP3CharacterMovementBP() const
{
	return Cast<UP3CharacterMovementComponent>(GetCharacterMovement());
}

class UP3HealthPointComponent* AP3Character::GetP3HealthComponentBP() const
{
	return HealthComponent;
}

class UP3CharacterHealthPointComponent* AP3Character::GetP3CharacterHealthComponentBP() const
{
	return Cast<UP3CharacterHealthPointComponent>(HealthComponent);
}

void AP3Character::AddForbiddenVolume(AP3ForbiddenVolume * Volume)
{
	if (AP3PlayerController* PCon = Cast<AP3PlayerController>(GetController()))
	{
		return PCon->AddForbiddenVolume(Volume);
	}
	else if (AP3AIController* AICon = Cast<AP3AIController>(GetController()))
	{
		return AICon->AddForbiddenVolume(Volume);
	}
}

void AP3Character::RemoveForbiddenVolume(AP3ForbiddenVolume * Volume)
{
	if (AP3PlayerController* PCon = Cast<AP3PlayerController>(GetController()))
	{
		return PCon->RemoveForbiddenVolume(Volume);
	}
	else if (AP3AIController* AICon = Cast<AP3AIController>(GetController()))
	{
		return AICon->RemoveForbiddenVolume(Volume);
	}
}

bool AP3Character::IsInForbiddenVolume() const
{
	if (AP3PlayerController* PCon = Cast<AP3PlayerController>(GetController()))
	{
		return PCon->IsInForbiddenVolume();
	}
	else if (AP3AIController* AICon = Cast<AP3AIController>(GetController()))
	{
		return AICon->IsInForbiddenVolume();
	}

	return false;
}

void AP3Character::Client_PlayCameraShake(const FName& CmsCameraShakeKey, float Distance)
{	
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	const FP3CmsCameraShakeRow* CmsCameraShakeRow = P3Cms::GetCameraShake(CmsCameraShakeKey);
	if (!CmsCameraShakeRow)
	{
		return;
	}

	float ShakeScale = 1.f;
	if (CmsCameraShakeRow->CurveDistanceScale)
	{
		ShakeScale = CmsCameraShakeRow->CurveDistanceScale->GetFloatValue(Distance);
	}
	
	APlayerController* PlayerController = Cast<APlayerController>(GetWorld()->GetFirstPlayerController());
	if (PlayerController)
	{
		PlayerController->ClientPlayCameraShake(CmsCameraShakeRow->CameraShakeClass, ShakeScale);	
	}
}

void AP3Character::AddGameplayTagsBP(const FGameplayTagContainer& TagContainer)
{
	Net_GameplayTagContainer.AppendTags(TagContainer);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetDirty(*this);
	}
}

void AP3Character::RemoveGameplayTagsBP(const FGameplayTagContainer& TagContainer)
{
	Net_GameplayTagContainer.RemoveTags(TagContainer);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetDirty(*this);
	}
}

void AP3Character::HitByLargeObjectBP(AActor* ObjectActor)
{
	if (!ensure(GetMesh()))
	{
		return;
	}

	Ragdollize();

	if (GetP3HealthComponentBP())
	{
		P3Combat::ChangeActorHealth(ObjectActor, *this, -GetP3HealthComponentBP()->GetHealthPoint(), EP3HealthChangeReason::HitByLargeObject);
	}
}

void AP3Character::SetStanceByAction(const class UP3PawnAction& Action, EP3CharacterStance InStance, bool bUpdateWeaponAttachment)
{
	if (CharacterStore.Stance == InStance)
	{
		return;
	}

	P3JsonLog(Verbose, "Character stance changed by action",
		TEXT("Character"), *GetName(),
		TEXT("OldStance"), EnumToStringShort(EP3CharacterStance, CharacterStore.Stance),
		TEXT("NewStance"), EnumToStringShort(EP3CharacterStance, InStance),
		TEXT("ActionType"), EnumToStringShort(EPawnActionType, Action.GetActionType()),
		TEXT("ActionId"), Action.GetActionId());

	SetStanceInternal(InStance, bUpdateWeaponAttachment);
}

void AP3Character::SetStanceByCommand(const class UP3Command& Command, EP3CharacterStance InStance, bool bUpdateWeaponAttachment)
{
	if (CharacterStore.Stance == InStance)
	{
		return;
	}

	P3JsonLog(Verbose, "Character stance changed by command",
		TEXT("Character"), *GetName(),
		TEXT("OldStance"), EnumToStringShort(EP3CharacterStance, CharacterStore.Stance),
		TEXT("NewStance"), EnumToStringShort(EP3CharacterStance, InStance),
		TEXT("CommandClass"), Command.GetClass()->GetName());

	SetStanceInternal(InStance, bUpdateWeaponAttachment);
}

void AP3Character::SetStanceInternal(EP3CharacterStance InStance, bool bUpdateWeaponAttachment)
{
	const EP3CharacterStance OldStance = CharacterStore.Stance;

	CharacterStore.Stance = InStance;

	if (bUpdateWeaponAttachment)
	{
		ConsiderChangeWeaponAttachment();
	}

	if (CharacterStore.bIsAiming && CharacterStore.Stance != EP3CharacterStance::Combat)
	{
		CharacterStore.bIsAiming = false;
	}
}

void AP3Character::ConsiderChangeWeaponAttachment()
{
	const EPawnActionType ActiveActionType = ActionComponent ? ActionComponent->GetActiveActionType() : EPawnActionType::Invalid;

	if (ActiveActionType == EPawnActionType::PutAwayWeapon || ActiveActionType == EPawnActionType::DrawWeapon)
	{
		// During draw or put away weapon action, action will take care of weapon attachment
		return;
	}

	UP3HolderComponent* LeftHandHolder = GetLeftHandHolderComponent();
	AP3Weapon* LeftHandWeapon = Cast<AP3Weapon>(LeftHandHolder ? LeftHandHolder->GetHoldingActor() : nullptr);
	const bool bHasSupportHoldable = LeftHandWeapon ? LeftHandWeapon->IsSupportHoldable() : false;

	bool bAttachWeapon = false;
	bool bAttachShield = false;

	if (GetStance() == EP3CharacterStance::Combat)
	{
		const bool bRoarStunned = EffectComponent && EffectComponent->HasEffect(EP3CharacterEffectTypes::RoarStun);
		const bool bStunned = EffectComponent && EffectComponent->HasEffect(EP3CharacterEffectTypes::Stun);

		if (!bRoarStunned || !bStunned)
		{
			bAttachWeapon = true;
			bAttachShield = true;
		}
	}

	if (bAttachWeapon)
	{
		NativeAttachWeapon();
	}
	else
	{
		NativeDetachWeapon();
	}

	if (bAttachShield)
	{
		NativeAttachShield();
	}
	else
	{
		NativeDetachShield();
	}
}

void AP3Character::LocalControl_CloseConsumableUI()
{
	if (!ensure(IsLocalControlledActor(this)))
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		LocalControl_bConsumableUIOpened = false;
		LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;

		OnInputCloseConsumableUI.Broadcast();
	}
}

bool AP3Character::CanAttack() const
{
	if (IsDead())
	{
		return false;
	}

	if (IsCarryingBackpack())
	{
		return false;
	}

	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
	if (MovementComp && MovementComp->IsClimbing())
	{
		// Do not attack while climbing
		return false;
	}

	if (PickupComponent && PickupComponent->GetPickuppedActor())
	{
		// Do not attack while picked up something
		return false;
	}

	if (IsBuckingEnduring())
	{
		return false;
	}

	return true;
}

bool AP3Character::HasSomethingToInteract() const
{
	// Pickup
	UP3PickupComponent* PickupComp = PickupComponent;
	if (PickupComp && PickupComp->GetPickupCandidateActor())
	{
		return true;
	}

	// Put down Pickupable
	if (PickupComp && PickupComp->CanPutDown())
	{
		return true;
	}

	// Climb Down
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
	if (MovementComp && MovementComp->IsClimbDownAvailable())
	{
		return true;
	}

	return false;
}

bool AP3Character::CanInteract() const
{
	if (CVarP3DisableInteractionInCombatStance.GetValueOnGameThread() == 1)
	{
		if (GetStance() == EP3CharacterStance::Combat)
		{
			bool bAllowDuringPutaway = false;

			if (CVarP3AllowInteractionDuringPutawayWeaponAction.GetValueOnGameThread() != 0)
			{
				if (ActionComponent && ActionComponent->GetActiveActionType() == EPawnActionType::PutAwayWeapon)
				{
					bAllowDuringPutaway = true;
				}
			}

			if (!bAllowDuringPutaway)
			{
				return false;
			}
		}
	}

	if (HasSomethingToInteract())
	{
		return true;
	}

	return false;
}

void AP3Character::SetBlockingByCommand(const class UP3Command& Command, bool bIsBlocking)
{
	if (CharacterStore.bIsBlocking == bIsBlocking)
	{
		return;
	}

	P3JsonLog(Verbose, "Character blocking changed",
		TEXT("Character"), *GetName(),
		TEXT("NewBlocking"), bIsBlocking ? TEXT("True") : TEXT("False"));

	CharacterStore.bIsBlocking = bIsBlocking;
	StartBlockTimeSeconds = bIsBlocking ? GetWorld()->GetTimeSeconds() : 0.f;

	if (bIsBlocking)
	{
		ReceiveStartBlockBP();

		if (CVarP3BlockingMovementMode.GetValueOnGameThread() == 2)
		{
			AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());

			if (MyController && MyController->IsLocalController())
			{
				MyController->LookForward(GetActorRotation());
			}
		}
	}
	else
	{
		ReceiveStopBlockBP();
	}
}

void AP3Character::SetCrouchBlockingByCommand(const class UP3Command& Command, bool bIsBlocking)
{
	if (CharacterStore.bIsCrouchBlocking == bIsBlocking)
	{
		return;
	}

	P3JsonLog(Verbose, "Character crouchblocking changed",
		TEXT("Character"), *GetName(),
		TEXT("NewBlocking"), bIsBlocking ? TEXT("True") : TEXT("False"));

	CharacterStore.bIsCrouchBlocking = bIsBlocking;
	StartBlockTimeSeconds = bIsBlocking ? GetWorld()->GetTimeSeconds() : 0.f;

	if (bIsBlocking)
	{
		ReceiveStartBlockBP();

		if (CVarP3BlockingMovementMode.GetValueOnGameThread() == 2)
		{
			AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());

			if (MyController && MyController->IsLocalController())
			{
				MyController->LookForward(GetActorRotation());
			}
		}
	}
	else
	{
		ReceiveStopBlockBP();
	}
}

void AP3Character::SetBouncingModeByCommand(const class UP3Command& Command, bool bIsBouncingMode)
{
	FP3CharacterStore NewStore = CharacterStore;

	NewStore.bIsBouncingMode = bIsBouncingMode;

	SetCharacterStore(NewStore);
}

void AP3Character::SetPushingByCommand(const class UP3Command& Command, bool bIsPushing, AActor* PushingTargetActor)
{
	FP3CharacterStore NewStore = CharacterStore;

	if (bIsPushing && ensure(PushingTargetActor))
	{
		NewStore.Stance = EP3CharacterStance::Push;

		if (PushComponent)
		{
			PushComponent->SetPushTargetActor(PushingTargetActor);
		}
	}
	else
	{
		if (NewStore.Stance == EP3CharacterStance::Push)
		{
			NewStore.Stance = EP3CharacterStance::Idle;

			if (PushComponent)
			{
				PushComponent->SetPushTargetActor(nullptr);
			}
		}
	}

	SetCharacterStore(NewStore);
}

void AP3Character::SetKnockDownedByCommand(const class UP3Command& Command, bool bNewKnockDowned, float DurationSeconds)
{
	FP3CharacterStore NewStore = CharacterStore;

	NewStore.bKnockDowned = bNewKnockDowned;

	SetCharacterStore(NewStore);

	if (bNewKnockDowned)
	{
		Server_KnockDownFinishTime = GetWorld()->GetTimeSeconds() + DurationSeconds;
	}
	else
	{
		Server_KnockDownFinishTime = 0.0f;
	}
}

void AP3Character::SetGodModeByCommand(const class UP3Command& Command, bool bNewGodMode)
{
	FP3CharacterStore NewStore = CharacterStore;

	NewStore.bGodMode = bNewGodMode;

	SetCharacterStore(NewStore);
}

void AP3Character::SetAimingByAction(const class UP3PawnAction& Action, bool bIsAiming)
{
	if (CharacterStore.bIsAiming == bIsAiming)
	{
		return;
	}

	P3JsonLog(Verbose, "Character aiming changed",
		TEXT("Character"), *GetName(),
		TEXT("NewAiming"), bIsAiming ? TEXT("True") : TEXT("False"));

	CharacterStore.bIsAiming = bIsAiming;

	if (bIsAiming)
	{
		if (CVarP3BlockingMovementMode.GetValueOnGameThread() == 2)
		{
			AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());

			if (MyController && MyController->IsLocalController())
			{
				MyController->LookForward(GetActorRotation());
			}
		}
	}
}

void AP3Character::SetAimingByCommand(const UP3Command& Command, bool bIsAiming)
{
	if (CharacterStore.bIsAiming == bIsAiming)
	{
		return;
	}

	P3JsonLog(Verbose, "Character aiming changed",
		TEXT("Character"), *GetName(),
		TEXT("NewAiming"), bIsAiming ? TEXT("True") : TEXT("False"));

	CharacterStore.bIsAiming = bIsAiming;

	if (bIsAiming)
	{
		if (CVarP3BlockingMovementMode.GetValueOnGameThread() == 2)
		{
			AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());

			if (MyController && MyController->IsLocalController())
			{
				MyController->LookForward(GetActorRotation());
			}
		}
	}
}

void AP3Character::RagdollizeByAction(const class UP3PawnAction& Action, bool bRagdollize)
{
	if (bRagdollize)
	{
		Ragdollize();
	}
	else
	{
		Unragdollize();
	}
}

void AP3Character::RagdollizeByCommand(const class UP3Command& Command, bool bRagdollize)
{
	if (bRagdollize)
	{
		Ragdollize();
	}
	else
	{
		Unragdollize();
	}
}

void AP3Character::SetHoldingActorByAction(const class UP3PawnAction* Action, class UP3HolderComponent* HolderComponent, AActor* HoldingActor, bool bHold)
{
	if (!ensure(HolderComponent))
	{
		return;
	}

	if (!ensure(HoldingActor))
	{
		return;
	}

	HolderComponent->SetHoldingActor(HoldingActor, bHold);

	if (HolderComponent->GetHoldType() == EP3HoldType::RightHand)
	{
		AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());
		if (MyController)
		{
			MyController->OnChangeWeapon(HolderComponent, HoldingActor);
		}
	}
}

void AP3Character::SetHoldingActorByCommand(const UP3Command& Command, class UP3HolderComponent* HolderComponent, AActor* HoldingActor, bool bHold)
{
	if (!ensure(HolderComponent))
	{
		return;
	}

	if (!ensure(HoldingActor))
	{
		return;
	}

	HolderComponent->SetHoldingActor(HoldingActor, bHold);

	if (HolderComponent->GetHoldType() == EP3HoldType::RightHand)
	{
		AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());
		if (MyController)
		{
			MyController->OnChangeWeapon(HolderComponent, HoldingActor);
		}
	}
}

AActor* AP3Character::RemoveHoldingActorByAction(const class UP3PawnAction& Action, class UP3HolderComponent* HolderComponent)
{
	if (!ensure(HolderComponent))
	{
		return nullptr;
	}

	AActor* OutActor = HolderComponent->RemoveHoldingActor();

	return OutActor;
}

AActor* AP3Character::RemoveHoldingActorByCommand(const UP3Command& Command, class UP3HolderComponent* HolderComponent)
{
	if (!ensure(HolderComponent))
	{
		return nullptr;
	}

	return HolderComponent->RemoveHoldingActor();
}

void AP3Character::SetRecallingWeaponByAction(const class UP3PawnAction& Action, class AP3Weapon* Weapon)
{
	CharacterStore.RecallingThrownWeapon = Weapon;
}

void AP3Character::SetThrownWeaponByAction(const class UP3PawnAction& Action, const FP3Item& Item, class AP3Weapon* Weapon, class UP3HolderComponent* HolderComponent)
{
	CharacterStore.ThrownWeaponItem = Item;
	CharacterStore.ThrownWeapon = Weapon;
	CharacterStore.ThrownWeaponHoldType = HolderComponent->GetHoldType();
}

void AP3Character::SetStumblingByCommand(const class UP3Command& Command, bool bIsStumbling)
{
	if (CVarP3UseStumble.GetValueOnGameThread() == 0)
	{
		bIsStumbling = false;
	}

	CharacterStore.bIsStumbling = bIsStumbling;
}

void AP3Character::SetTimeDelation(float TimeDilation, float DurationSeconds)
{
	// COMMENT-OUT. TODO: Time Delation broke Character ragdoll(Behemoth's bear and tail)
	//CustomTimeDilation = TimeDilation;
	//TimeDilationResetTime = GetWorld()->GetTimeSeconds() + DurationSeconds;
}

int32 AP3Character::GetPartHealthPoint(int32 PartIndex) const
{
	if (!ensure(Net_PartHealthPoints.IsValidIndex(PartIndex)))
	{
		return 0;
	}

	return Net_PartHealthPoints[PartIndex];
}

void AP3Character::SetPartHealthPoint(int32 PartIndex, int32 HealthPoint)
{
	if (!ensure(Net_PartHealthPoints.IsValidIndex(PartIndex)) || !ensure(Parts.IsValidIndex(PartIndex)))
	{
		return;
	}

	const int32 MaxHealth = HealthComponent ? HealthComponent->GetMaxHealthPoint() : 0;

	Net_PartHealthPoints[PartIndex] = FMath::Clamp(HealthPoint, 0, (MaxHealth * Parts[PartIndex].HealthPointPermil) / 1000);
}

void AP3Character::SetIgnoredHitAnimation(bool bInIgnoredHitAnimation)
{
	bIgnoredHitAnimation = bInIgnoredHitAnimation;
}

void AP3Character::SetIgnoredHitRotator(bool bInIgnoredHitRotator)
{
	bIgnoredHitRotator = bInIgnoredHitRotator;
}

void AP3Character::Server_StartStumble(float DurationSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)) || !CommandComponent)
	{
		return;
	}

	Server_StumblingEndTimeSeconds = FMath::Max(Server_StumblingEndTimeSeconds, GetWorld()->GetTimeSeconds() + DurationSeconds);

	FP3CommandRequestParams Params;
	Params.SetStumbling_bIsStumbling = true;

	CommandComponent->RequestCommand(UP3SetStumblingCommand::StaticClass(), Params);
}

void AP3Character::Server_SetHair(const FName& HairName)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	CharacterStore.HairName = HairName;

	UpdateHairComponent();

	Server_SetDirty(*this);

	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);

	if (WorldNet)
	{
		WorldNet->SendUpdateCharacterHair(CharacterStore.CharacterId, HairName.ToString());
	}
}

void AP3Character::Server_SetArmor(const FName& ArmorName)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	CharacterStore.ArmorName = ArmorName;

	UpdateArmorComponent();

	Server_SetDirty(*this);

	UP3WorldNetBase* WorldNet = P3GetWorldNet(this);

	if (WorldNet)
	{
		WorldNet->SendUpdateCharacterArmor(CharacterStore.CharacterId, ArmorName.ToString());
	}
}

void AP3Character::Debug_Server_StartStumble(float DurationSeconds)
{
	Server_StartStumble(DurationSeconds);
}

void AP3Character::Debug_SetStance(EP3CharacterStance Stance)
{
	SetStanceInternal(Stance, true);
}

void AP3Character::Debug_SetSprint(bool bSprint)
{
	GetP3CharacterMovementBP()->SetSprint(bSprint);
}

bool AP3Character::CanCombat() const
{
	if (IsGliding())
	{
		return false;
	}

	if (IsPushing())
	{
		return false;
	}

	if (IsClimbing())
	{
		return false;
	}

	if (IsPickuped())
	{
		return false;
	}

	if (IsDeadOrDowned())
	{
		return false;
	}

	if (IsRescuing())
	{
		return false;
	}

	return true;
}

bool AP3Character::CanBlock() const
{
	if (StaminaComponent && StaminaComponent->GetStaminaPoint() <= 0.0f)
	{
		return false;
	}

	if (GetStance() != EP3CharacterStance::Idle && GetStance() != EP3CharacterStance::Combat)
	{
		// Only allow on idle & combat stance
		return false;
	}

	if (IsClimbing() || IsGliding() || IsPushing() || HasStun() || IsMounted())
	{
		return false;
	}

	UP3StaminaPointComponent* StaminaComp = GetStaminaComponent();

	if (StaminaComp && StaminaComp->IsExhausted())
	{
		return false;
	}

	EP3WeaponType RightHandWeaponType = GetRightHandWeaponType();

	if (IsPlayerControlled() && !IsShieldWeapon(RightHandWeaponType))
	{
		return false;
	}

	if (IsDeadOrDowned())
	{
		return false;
	}

	if (IsRescuing())
	{
		return false;
	}

	return true;
}

bool AP3Character::CanAiming() const
{
	if (GetStance() != EP3CharacterStance::Idle && GetStance() != EP3CharacterStance::Combat)
	{
		// Only allow on idle & combat stance
		return false;
	}

	if (IsClimbing() || IsGliding() || IsPushing() || HasStun() || IsMounted())
	{
		return false;
	}

	if (IsDeadOrDowned())
	{
		return false;
	}

	return true;
}

bool AP3Character::CanThrowConsumable() const
{
	if (IsGliding() || IsClimbing() || IsMounted())
	{
		return false;
	}

	if (!CharacterStore.bIsAiming)
	{
		return false;
	}

	return true;
}

bool AP3Character::CanHitAnimation() const
{
	return !bIgnoredHitAnimation;
}

bool AP3Character::CanHitRotator() const
{
	return !bIgnoredHitRotator;
}

bool AP3Character::IsClimbing() const
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (CharacterMovementComp)
	{
		return CharacterMovementComp->IsClimbing();
	}
	return false;
}

void AP3Character::BreakClimbingByCommand(class UP3Command& Command)
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (ensure(CharacterMovementComp) && CharacterMovementComp->IsClimbing())
	{
		CharacterMovementComp->SetMovementMode(MOVE_Falling);
	}
}

void AP3Character::MountByCommand(const class UP3Command& Command, AP3Character* Target, int32 MountPointIndex, bool bRescue)
{
	if (!ensure(Target))
	{
		return;
	}

	if (!ensure(Target->GetMountPoints().IsValidIndex(MountPointIndex)))
	{
		return;
	}

	if (!GetCharacterMovement())
	{
		return;
	}

	if (!Target->GetMesh())
	{
		return;
	}

	if (!GetMesh())
	{
		return;
	}

	const FP3CharacterMountPoint& MountPoint = Target->GetMountPoints()[MountPointIndex];

	GetCapsuleComponent()->AttachToComponent(Target->GetMesh(), FAttachmentTransformRules::KeepWorldTransform, MountPoint.SocketName);
	GetCapsuleComponent()->SetAbsolute(false, false, true);
	GetCapsuleComponent()->SetRelativeTransform(GetMesh()->GetRelativeTransform().Inverse());
	GetCharacterMovement()->SetMovementMode(MOVE_None);
	GetCharacterMovement()->bIgnoreClientMovementErrorChecksAndCorrection = true;

	CharacterStore.MountTargetCharacter = Target;
	CharacterStore.MountPointIndex = MountPointIndex;
	CharacterStore.bMountingByRescuer = bRescue;

	SetStanceByCommand(Command, EP3CharacterStance::Combat, false);

	NativeDetachWeapon();
	NativeDetachShield();
	NativeAttachDagger();
}

void AP3Character::DismountByCommand(const class UP3Command& Command)
{
	if (!CharacterStore.MountTargetCharacter)
	{
		return;
	}

	AP3Character* OldMountTargetCharacter = CharacterStore.MountTargetCharacter;

	FRotator Rotation = GetActorRotation();
	Rotation.Roll = 0;
	Rotation.Pitch = 0;

	GetCapsuleComponent()->DetachFromComponent(FDetachmentTransformRules::KeepWorldTransform);
	GetCapsuleComponent()->SetWorldRotation(Rotation);
	GetCharacterMovement()->SetMovementMode(MOVE_Falling);
	GetCharacterMovement()->bIgnoreClientMovementErrorChecksAndCorrection = false;

	CharacterStore.MountTargetCharacter = nullptr;
	CharacterStore.MountPointIndex = -1;
	CharacterStore.bMountingByRescuer = false;

	// Update weapon attachment
	SetStanceInternal(GetStance(), true);
	NativeDetachDagger();

	LastUnmountTimeSeconds = GetWorld()->GetTimeSeconds();

	// If we got stuck in some objects, teleport to mounted character
	FComponentQueryParams QueryParams;
	QueryParams.bIgnoreTouches = true;
	QueryParams.AddIgnoredActor(this);
	QueryParams.AddIgnoredActor(OldMountTargetCharacter);

	TArray<struct FHitResult> HitResults;
	GetWorld()->ComponentSweepMulti(HitResults, GetCapsuleComponent(), GetActorLocation(), OldMountTargetCharacter->GetActorLocation(), GetActorRotation(), QueryParams);

	if (HitResults.Num() > 0)
	{
		SetActorLocation(OldMountTargetCharacter->GetActorLocation());
	}
}

void AP3Character::SetRiderByCommand(const class UP3Command& Command, AP3Character* Rider, int32 MountPointIndex)
{
	if (!ensure(MountPoints.IsValidIndex(MountPointIndex)))
	{
		return;
	}

	if (Rider)
	{
		CharacterStore.MountRiderCharacters.Add(MountPointIndex, Rider);
	}
	else
	{
		CharacterStore.MountRiderCharacters.Remove(MountPointIndex);
	}
}

void AP3Character::SetBuckingEndureByCommand(const class UP3Command& Command, const bool bIsBuckingEndure)
{
	bBuckingEndurePressed = bIsBuckingEndure;
}

bool AP3Character::IsActionCategoryDisabled(EPawnActionCategory ActionCategory) const
{
	const bool bHasStunEffect = EffectComponent && EffectComponent->HasStunEffect();

	switch (ActionCategory)
	{
	case EPawnActionCategory::Dead:
		break;

	case EPawnActionCategory::Movement:
		if (bHasStunEffect)	// -V1037
		{
			return true;
		}
		break;

	case  EPawnActionCategory::Combat:
		if (bHasStunEffect)
		{
			return true;
		}
		break;

	case EPawnActionCategory::Pickup:
		if (bHasStunEffect)
		{
			return true;
		}
		break;

	case EPawnActionCategory::CrowdControl:
		break;

	case EPawnActionCategory::Reaction:
		break;

	default:
		ensureMsgf(0, TEXT("Invalid action category: %d"), StaticCast<int32>(ActionCategory));
	}

	return false;
}

bool AP3Character::IsFlameHitActionIgnored() const
{
	const FP3CmsCharacter* CharacterDesc = P3Cms::GetCharacter(GetCmsCharacterKey());
	if (CharacterDesc)
	{
		return CharacterDesc->bIgnoreFlameHitAction;
	}

	return false;
}

bool AP3Character::CanGlide() const
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
	if (!MovementComp)
	{
		return false;
	}

	if (!MovementComp->IsFalling())
	{
		return false;
	}

	if (IsPickuped())
	{
		return false;
	}

	if (IsMounted())
	{
		return false;
	}

	if (IsGliding())
	{
		return false;
	}

	if (ActionComponent && !ActionComponent->CanStartGliding())
	{
		return false;
	}

	if (CharacterStore.bIsBlocking)
	{
		return false;
	}

	if (CharacterStore.bIsCrouchBlocking)
	{
		return false;
	}

	if (CharacterStore.bIsMeleeAiming)
	{
		return false;
	}

	return true;
}

bool AP3Character::IsGliding() const
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (CharacterMovementComp)
	{
		return CharacterMovementComp->IsGliding();
	}
	return false;
}

void AP3Character::BreakGlidingByAction(class UP3PawnAction& Action)
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (ensure(CharacterMovementComp) && CharacterMovementComp->IsGliding())
	{
		CharacterMovementComp->SetMovementMode(MOVE_Falling);
	}
}

void AP3Character::BreakGlidingByCommand(class UP3Command& Command)
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (ensure(CharacterMovementComp) && CharacterMovementComp->IsGliding())
	{
		CharacterMovementComp->SetMovementMode(MOVE_Falling);
	}
}

bool AP3Character::IsSliding() const
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (CharacterMovementComp)
	{
		return CharacterMovementComp->IsSliding();
	}
	return false;
}

bool AP3Character::IsHoldingFireBP() const
{
	TInlineComponentArray<UP3HolderComponent*> HolderComponents;
	GetComponents(HolderComponents);

	for (const UP3HolderComponent* HolderComp : HolderComponents)
	{
		AActor* HoldingActor = HolderComp->GetHoldingActor();
		if (!HoldingActor || !HolderComp->IsHold())
		{
			continue;
		}

		UP3FlammableComponent* FlammableComp = HoldingActor->FindComponentByClass<UP3FlammableComponent>();
		if (FlammableComp && FlammableComp->IsInFire())
		{
			return true;
		}
	}

	return false;
}

bool AP3Character::CanThrowWeaponBP() const
{
	TInlineComponentArray<UP3HolderComponent*> HolderComponents;
	GetComponents(HolderComponents);

	for (const UP3HolderComponent* HolderComp : HolderComponents)
	{
		AP3Weapon* Weapon = Cast<AP3Weapon>(HolderComp->GetHoldingActor());
		if (!Weapon)
		{
			continue;
		}

		const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(Weapon->GetClass()));
		if (!CmsHoldable)
		{
			continue;
		}

		if (CmsHoldable->WeaponType != EP3WeaponType::SwordAndShield)
		{
			continue;
		}

		// TODO: maybe we need 'Throwable' flag
		return true;
	}

	return false;
}

AP3Weapon* AP3Character::GetRecallingThrownWeaponBP() const
{
	return CharacterStore.RecallingThrownWeapon.Get();
}

bool AP3Character::IsInLookingForward() const
{
	AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());

	return MyController && MyController->IsInLookingForward();
}

bool AP3Character::IsDead() const
{
	return (HealthComponent && HealthComponent->IsDead());
}

bool AP3Character::IsDowned() const
{
	UP3CharacterHealthPointComponent* CharacterHealthComponent = GetP3CharacterHealthComponentBP();
	return (CharacterHealthComponent && CharacterHealthComponent->IsDowned());
}

bool AP3Character::IsDeadOrDowned() const
{
	UP3CharacterHealthPointComponent* CharacterHealthComponent = GetP3CharacterHealthComponentBP();
	if (HealthComponent && HealthComponent->IsDead())
	{
		return true;
	}
	else if (CharacterHealthComponent && CharacterHealthComponent->IsDowned())
	{
		return true;
	}

	return false;
}

bool AP3Character::IsRescuing() const
{
	return CharacterStore.RescueTargetCharacter != nullptr;
}

bool AP3Character::CanBeRescued() const
{
	UP3CharacterHealthPointComponent* CharacterHealthComponent = GetP3CharacterHealthComponentBP();
	return (CharacterHealthComponent && CharacterHealthComponent->CanBeRescued());
}

bool AP3Character::IsBurning() const
{
	UP3FlammableComponent* FlammableComp = GetFlammableComponent();
	if (FlammableComp)
	{
		return FlammableComp->IsInFire();
	}

	return false;

}

void AP3Character::Revive(const FTransform& RevivePointTransform) const
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	P3JsonLog(Display, "Revive Character",
		TEXT("Character"), *GetName(),
		TEXT("CharacterId"), UINT64_TO_STR(CharacterStore.CharacterId),
		TEXT("RevivePointTransform"), RevivePointTransform.ToString());

	if (HealthComponent)
	{
		HealthComponent->Server_Revive(HealthComponent->GetMaxHealthPoint());
	}

	UP3FlammableComponent* FlammableComp = GetFlammableComponent();
	if (FlammableComp)
	{
		FlammableComp->Server_StopFire();
	}

	UP3WetComponent* WetComp = GetWetComponent();
	if (WetComp && WetComp->IsWet())
	{
		WetComp->Server_Dry();
	}

	FVector CapsuleHalfHeight = FVector(0, 0, GetCapsuleComponent()->GetScaledCapsuleHalfHeight());
	FP3CommandRequestParams TeleportParams;
	TeleportParams.Teleport_Location = RevivePointTransform.GetLocation() + CapsuleHalfHeight;
	TeleportParams.Teleport_Rotation = RevivePointTransform.GetRotation().Rotator();

	GetCommandComponent()->RequestCommand(UP3TeleportCommand::StaticClass(), TeleportParams);
}

void AP3Character::Server_Rescued() const
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (ActionComponent)
	{
		ActionComponent->StartAction(EPawnActionType::DownedEnd, _FUNCTION_TEXT);
	}
}

const UP3CharacterAnimMontageData& AP3Character::GetAnimMontages() const
{
	if (AnimMontageData)
	{
		return *AnimMontageData;
	}

	return *Cast<UP3CharacterAnimMontageData>(UP3CharacterAnimMontageData::StaticClass()->ClassDefaultObject);
}

UAnimMontage* AP3Character::GetAnimationByType(EP3ActionAnimationType DesireAnimationType) const
{
	UAnimMontage* Montage = nullptr;

	if (ComboTableComponent && ComboTableComponent->IsComboEnabled())
	{
		Montage = ComboTableComponent->GetAnimByAction(DesireAnimationType);
	}

	if (!Montage && AnimActionMontageData)
	{
		UAnimMontage* const* FindAnimation = AnimActionMontageData->Animations.Find(DesireAnimationType);
		if (ensure(FindAnimation))
		{
			Montage = *FindAnimation;
		}
	}

	return Montage;
}

const FP3CharacterEmoteAnimation* AP3Character::FindEmoteByName(const FName& DesireEmoteName) const
{
	if (DesireEmoteName.IsNone())
	{
		return nullptr;
	}

	if (!EmoteAnimSequenceData)
	{
		return nullptr;
	}

	FP3CharacterEmoteAnimation* FindEmoteAnimation = EmoteAnimSequenceData->Emotes.Find(DesireEmoteName);
 	if (FindEmoteAnimation)
 	{
		return FindEmoteAnimation;
	}

	return nullptr;
}

bool AP3Character::IsPushing() const
{
	return (GetStance() == EP3CharacterStance::Push);
}

bool AP3Character::IsMounted() const
{
	return CharacterStore.MountTargetCharacter != nullptr;
}

bool AP3Character::CanMount() const
{
	return bCanMount;
}

bool AP3Character::IsBuckingEnduring() const
{
	return (IsMounted() && CharacterStore.MountTargetCharacter->IsBucking() && bBuckingEndurePressed);
}

bool AP3Character::IsCarryingDownedCharacter() const
{
	auto CarryingCharacterPointer = CharacterStore.MountRiderCharacters.Find(0);

	return (CarryingCharacterPointer && *CarryingCharacterPointer && (*CarryingCharacterPointer)->IsDowned());
}

bool AP3Character::IsMountingByRescuer() const
{
	return CharacterStore.bMountingByRescuer;
}

bool AP3Character::IsOnGround() const
{
	const UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (CharacterMovementComp == nullptr)
	{
		return false;
	}

	const bool bIsGliding = CharacterMovementComp->IsGliding();
	const bool bIsClimbing = CharacterMovementComp->IsClimbing();
	const bool bIsFalling = CharacterMovementComp->IsFalling();
	const bool bIsSwimming = CharacterMovementComp->IsSwimming();

	return !bIsGliding && !bIsClimbing && !bIsFalling && !bIsSwimming;
}

bool AP3Character::CanSprint() const
{
	if (CVarP3AutoPutAwayBySprint.GetValueOnGameThread() > 0
		&& GetStance() == EP3CharacterStance::Combat
		&& IsPlayerControlled())
	{
		return false;
	}

	if (ActionComponent && !ActionComponent->CanSprint())
	{
		return false;
	}

	return true;
}

bool AP3Character::HasRiderOnMountPoint(int32 MountPointIndex) const
{
	if (!MountPoints.IsValidIndex(MountPointIndex))
	{
		return false;
	}

	return CharacterStore.MountRiderCharacters.Contains(MountPointIndex);
}

bool AP3Character::IsMountPointAvailable(int32 MountPointIndex) const
{
	if (!MountPoints.IsValidIndex(MountPointIndex))
	{
		return false;
	}

	if (CharacterStore.MountRiderCharacters.Contains(MountPointIndex))
	{
		return false;
	}

	if (CharacterStore.DisabledMountPoints.Contains(MountPointIndex))
	{
		return false;
	}

	return true;
}

bool AP3Character::HasStun() const
{
	return (EffectComponent && EffectComponent->HasStunEffect());
}

bool AP3Character::IsPickuped() const
{
	return (GetStance() == EP3CharacterStance::Pickup);
}

bool AP3Character::IsKnockDowned() const
{
	if (CharacterStore.bKnockDowned)
	{
		return true;
	}

	if (ActionComponent && ActionComponent->IsInKnockDown())
	{
		return true;
	}

	return false;
}

bool AP3Character::IsCarryingBackpack() const
{
	return (InventoryComponent && InventoryComponent->IsCarryingBackpack());
}

void AP3Character::PostInitProperties()
{
	Super::PostInitProperties();

	CharacterStore.HairName = DefaultHairName;

#if WITH_EDITOR
	// TODO: Make CombatSkills Transient and dynamically load from CMS
	// Below code does not working
	//CombatSkills = FP3Cms::GetCharacterCombatSkills(CmsCharacterKey);
#endif
}

void AP3Character::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeStandalone(*this))
	{
		// In standalone mode, EnterWorld is skipped. (also Server_InitBaseInfo)
		// We need to call Server_InitBaseInfo before BeginPlay. (any good idea?)
		Standalone_InitBaseInfo();
	}

	if (ParkourDataClass.Get())
	{
		ParkourData = NewObject<UP3ParkourData>(this, ParkourDataClass.Get(), TEXT("ParkourData"));
	}

	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
	if (MovementComp)
	{
		bDefaultUseControllerDesiredRotation = MovementComp->bUseControllerDesiredRotation;
	}

	if (Controller && Controller->IsA(AP3AIController::StaticClass()))
	{
		AggroComponent = NewObject<UP3AggroComponent>(this, TEXT("AggroComponent"));
		if (AggroComponent)
		{
			AggroComponent->RegisterComponent();
			AggroComponent->SetIsReplicated(true); // for debugging at client
		}

		HealthComponent = NewObject<UP3HealthPointComponent>(this, TEXT("HealthPointComponent"));
		HealthComponent->RegisterComponent();

		ThreatListComponent = NewObject<UP3ThreatListComponent>(this, TEXT("ThreatListComponent"));
		if (ThreatListComponent)
		{
			ThreatListComponent->RegisterComponent();
		}
	}
	else
	{
		HealthComponent = NewObject<UP3CharacterHealthPointComponent>(this, TEXT("HealthPointComponent"));
		HealthComponent->RegisterComponent();

		if (P3Core::IsP3NetModeClientInstance(*this))
		{
			//if (Controller && Controller->IsLocalPlayerController())
			{
				ExperienceComponent = NewObject<UP3ExperiencePointComponent>(this, TEXT("ExperienceComponent"));
				ExperienceComponent->RegisterComponent();
			}
		}
		else
		{
			ExperienceComponent = NewObject<UP3ExperiencePointComponent>(this, TEXT("ExperienceComponent"));
			ExperienceComponent->RegisterComponent();
		}
	}

	if (CombatComponentClass.Get())
	{
		CombatComponent = NewObject<UP3CombatComponent>(this, CombatComponentClass.Get(), TEXT("CombatComponent"));
		if (ensure(CombatComponent))
		{
			CombatComponent->RegisterComponent();
		}
	}

	if (ComboComponentClass.Get())
	{
		ComboTableComponent = NewObject<UP3ComboTableComponent>(this, ComboComponentClass.Get(), TEXT("ComboTableComponent"));
		if (ensure(ComboTableComponent))
		{
			ComboTableComponent->RegisterComponent();
		}
	}

	if (CombatResponseComponentClass.Get())
	{
		CombatResponseComponent = NewObject<UP3CombatResponseComponent>(this, CombatResponseComponentClass.Get(), TEXT("CombatResponseComponent"));
		if (ensure(CombatResponseComponent))
		{
			CombatResponseComponent->RegisterComponent();
		}
	}
	
	LocalControl_CameraBoomTargetArmLength = CameraDefaultDistance;
	LocalControl_DefaultFOV = FollowCamera ? FollowCamera->FieldOfView : 70.0f;

	if (HealthComponent)
	{
		HealthComponent->OnDead.AddUniqueDynamic(this, &AP3Character::OnDead);
		HealthComponent->OnRevive.AddUniqueDynamic(this, &AP3Character::OnRevive);

		UP3CharacterHealthPointComponent* CharacterHealthComponent = Cast<UP3CharacterHealthPointComponent>(HealthComponent);
		if (CharacterHealthComponent)
		{
			CharacterHealthComponent->OnDownedChanged.AddUniqueDynamic(this, &AP3Character::OnDownedChanged);
		}
	}

	TArray<UP3PartComponent*> PartComponents;
	GetComponents<UP3PartComponent>(PartComponents);
	for (auto&& PartComponent : PartComponents)
	{
		PartComponent->OnPartBroken.AddUniqueDynamic(this, &AP3Character::OnPartBroken);
	}

	if (ActionComponent)
	{
		// DYLEE NOTE P3-3209 작업 영역 분리
		if (!CVarP3ActionDataDriven.GetValueOnGameThread())
		{
			if (GetAnimMontages().Spawn)
			{
				ActionComponent->RegisterAction(EPawnActionType::Spawn, EPawnActionCategory::Dead, NewObject<UP3SpawnPawnAction>());
			}
			
			ActionComponent->RegisterAction(EPawnActionType::DrawWeapon, EPawnActionCategory::Combat, NewObject<UP3DrawWeaponPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::PutAwayWeapon, EPawnActionCategory::Combat, NewObject<UP3PutawayWeaponPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatRoll, EPawnActionCategory::Movement, NewObject<UP3CombatRollPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatAttack, EPawnActionCategory::Combat, NewObject<UP3CombatAttackPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatRangedAttack, EPawnActionCategory::Combat, NewObject<UP3CombatRangedAttackPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatProjectileSkillAttack, EPawnActionCategory::Combat, NewObject<UP3CombatProjectileSkillAttackPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatAdaptedAttack, EPawnActionCategory::Combat, NewObject<UP3AdaptedAttackAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatHit, EPawnActionCategory::Combat, NewObject<UP3CombatHitPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatCombo, EPawnActionCategory::Combat, NewObject<UP3ComboAttackPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatCharging, EPawnActionCategory::Combat, NewObject<UP3CombatChargingPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::StartBlock, EPawnActionCategory::Combat, NewObject<UP3StartBlockPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::StopBlock, EPawnActionCategory::Combat, NewObject<UP3StopBlockPawnAction>());			
			ActionComponent->RegisterAction(EPawnActionType::ChangeHoldable, EPawnActionCategory::Combat, NewObject<UP3ChangeHoldablePawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::Ragdollize, EPawnActionCategory::Movement, NewObject<UP3RagdollizePawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::Unragdollize, EPawnActionCategory::Movement, NewObject<UP3UnRagdollizePawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::ThrowWeapon, EPawnActionCategory::Combat, NewObject<UP3ThrowWeaponPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::RecallThrownWeapon, EPawnActionCategory::Combat, NewObject<UP3RecallThrownWeaponPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::PullHarpoon, EPawnActionCategory::Combat, NewObject<UP3PullHarpoonPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::TripOver, EPawnActionCategory::Movement, NewObject<UP3TripOverPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::BouncingJump, EPawnActionCategory::Movement, NewObject<UP3BouncingJumpPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CharacterMontage, EPawnActionCategory::Movement, NewObject<UP3CharacterMontageAction>());			
			ActionComponent->RegisterAction(EPawnActionType::DownedEnd, EPawnActionCategory::Dead, NewObject<UP3DownedEndPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::Rescue, EPawnActionCategory::Combat, NewObject<UP3RescuePawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::Breakfall, EPawnActionCategory::Movement, NewObject<UP3BreakfallPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::Exhaust, EPawnActionCategory::Movement, NewObject<UP3ExhaustPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::BuckingHangOn, EPawnActionCategory::Movement, NewObject<UP3BuckingHangOnPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::Cook, EPawnActionCategory::Movement, NewObject<UP3CookingPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::ThrownAway, EPawnActionCategory::Combat, NewObject<UP3ThrowAwayAction>());
			ActionComponent->RegisterAction(EPawnActionType::RoarStun, EPawnActionCategory::CrowdControl, NewObject<UP3RoarStunAction>());
			ActionComponent->RegisterAction(EPawnActionType::CombatReactionHit, EPawnActionCategory::Reaction, NewObject<UP3CombatReactionHitPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CableMove, EPawnActionCategory::Movement, NewObject<UP3CableMovePawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::StartItemThrowAim, EPawnActionCategory::Combat, NewObject<UP3StartItemThrowAimPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::EndItemThrowAim, EPawnActionCategory::Combat, NewObject<UP3EndItemThrowAimPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CarryingOnBackStart, EPawnActionCategory::Combat, NewObject<UP3CarryingOnBackStartPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CarryingOnBackEnd, EPawnActionCategory::Combat, NewObject<UP3CarryingOnBackEndPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CarriedOnBackStart, EPawnActionCategory::Combat, NewObject<UP3CarriedOnBackStartPawnAction>());
			ActionComponent->RegisterAction(EPawnActionType::CarriedOnBackEnd, EPawnActionCategory::Combat, NewObject<UP3CarriedOnBackEndPawnAction>());
		}
		else
		{
			// DYLEE TODO 액션 구현이 잘 분리되면 BeinPlay() 이전 시점에 수행해보기
			ActionComponent->InitializeActions();
		}
	}

	const bool bStartSpawnAction = (Client_ServerGameTimeSinceCreation < 2.0f)
		&& GetWorld()
		&& GetWorld()->HasBegunPlay()
		&& GetActionComponent()
		&& GetActionComponent()->HasAction(EPawnActionType::Spawn);

	if (bStartSpawnAction)
	{
		if (GetMesh())
		{
			// Make mesh stop right at the beginning of spawn montage
			GetMesh()->GetAnimInstance()->Montage_Play(GetAnimMontages().Spawn);
			GetMesh()->TickAnimation(0.0f, false);
			GetMesh()->RefreshBoneTransforms();
			GetMesh()->GetAnimInstance()->Montage_Pause(GetAnimMontages().Spawn);
		}
	}

	// Server side initialize
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Net_bAIControlled = (Cast<AAIController>(GetController()) != nullptr);

		Server_InitHolderComponents();

		if (bStartSpawnAction)
		{
			GetActionComponent()->StartAction(EPawnActionType::Spawn, _FUNCTION_TEXT);
		}

		if (InitialCharData.CharLevel == 0)
		{
			const FP3CmsCharacter* CmsCharacter = P3Cms::GetCharacter(GetCmsCharacterKey());
			if (CmsCharacter)
			{
				CharacterStore.CharLevel = CmsCharacter->Level;
			}
			else
			{
				/** default level is 1 */
				CharacterStore.CharLevel = 1;
			}
		}
		else
		{
			CharacterStore.CharLevel = InitialCharData.CharLevel;
		}

		if (ExperienceComponent)
		{
			ExperienceComponent->Server_InitExperiencePoint(InitialCharData.ExperiencePoint, InitialCharData.CharLevel);
		}
	}

	UP3HolderComponent* RightHandHolderComp = GetRightHandHolderComponent();
	if (RightHandHolderComp)
	{
		RightHandHolderComp->OnHold.AddUniqueDynamic(this, &AP3Character::OnHold);
		RightHandHolderComp->OnStash.AddUniqueDynamic(this, &AP3Character::OnStash);
		RightHandHolderComp->OnActorRemoved.AddUniqueDynamic(this, &AP3Character::OnHolderActorRemoved);
	}

	// Init part HP
	Net_PartHealthPoints.Init(0, Parts.Num());
	if (HealthComponent)
	{
		const int32 MaxHealthPoint = HealthComponent->GetMaxHealthPoint();

		for (int32 PartIndex = 0; PartIndex < Parts.Num(); ++PartIndex)
		{
			const FP3CharacterPart& Part = Parts[PartIndex];
			if (Part.HealthPointPermil > 0)
			{
				Net_PartHealthPoints[PartIndex] = (MaxHealthPoint * Part.HealthPointPermil) / 1000;
			}
		}
	}

	// Init HP base on attribute
	UP3AttributesComponent* AttributeComp = FindComponentByClass<UP3AttributesComponent>();
	if (AttributeComp)
	{
		AttributeComp->SetLevel(CharacterStore.CharLevel);
		AttributeComp->UpdateAttributes();

		const int32 MaxHealthPoint = AttributeComp->GetAttribute(EP3Attribute::MaxHealth);

		if (HealthComponent)
		{
			HealthComponent->SetMaxHealthPoint(MaxHealthPoint);
			HealthComponent->SetHealthPoint(MaxHealthPoint);
		}
	}

	UpdateHairComponent();
	UpdateArmorComponent();

	DefaultCameraOffset = CameraBoom->SocketOffset;

	InitialCharData.Clear();
}

void AP3Character::Server_InitHolderComponents()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Net_bAIControlled)
	{
		for (const FP3CharacterItem& DBItem : InitialCharData.Items)
		{
			const EP3CharacterItemSlot Slot = (EP3CharacterItemSlot)DBItem.Slot;
			if (Slot == EP3CharacterItemSlot::RightHand)
			{
				UP3HolderComponent* RightHandHolderComp = GetRightHandHolderComponent();
				if (RightHandHolderComp)
				{
					FP3Item NewHoldingItem = DBItem.Item;
					Server_InitHolderComponent(RightHandHolderComp, NewHoldingItem);
				}
			}
			else if (Slot == EP3CharacterItemSlot::LeftHand)
			{
				UP3HolderComponent* LeftHandHolderComp = GetLeftHandHolderComponent();
				if (LeftHandHolderComp)
				{
					FP3Item NewHoldingItem = DBItem.Item;
					Server_InitHolderComponent(LeftHandHolderComp, NewHoldingItem);
				}
			}
		}

		InitialCharData.Items.Empty();
	}
	else
	{
		ensure(InitialCharData.IsItemListEmpty());

		TInlineComponentArray<UP3HolderComponent*> HolderComponents;
		GetComponents(HolderComponents);

		for (UP3HolderComponent* HolderComp : HolderComponents)
		{
			UClass* HoldingActorClass = HolderComp->GetDefaultHoldingActorClass(CharacterStore.CharClass).Get();
			if (HoldingActorClass)
			{
				const itemkey ItemKey = P3Cms::GetItemKeyFromActorClass(HoldingActorClass);
				if (!ensure(ItemKey != INVALID_ITEMKEY))
				{
					P3JsonLog(Error, "Invalid item key", TEXT("HoldingActorClass"), *HoldingActorClass->GetName());
					continue;
				}

				UP3ItemManager* ItemManager = P3Core::GetItemManager(*this);
				if (ensure(ItemManager))
				{
					const FP3Item Item = ItemManager->CreateItem(ItemKey, 1, "InitHolderComponents");

					if (ensure(Item.IsValid()))
					{
						Server_InitHolderComponent(HolderComp, Item);
					}
				};
			}
		}
	}
}

void AP3Character::Server_InitHolderComponent(UP3HolderComponent* HolderComp, const FP3Item& Item)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(HolderComp))
	{
		return;
	}

	UClass* ItemClass = P3Cms::GetActorClassFromItemKey(Item.Key);
	if (!ensure(ItemClass))
	{
		return;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AActor* NewHoldingActor = GetWorld()->SpawnActor(ItemClass, nullptr, nullptr, SpawnParams);
	if (!ensure(NewHoldingActor))
	{
		return;
	}

	HolderComp->SetHoldingActor(NewHoldingActor, false);
}

void AP3Character::UpdateHairComponent()
{
	if (HairComponent)
	{
		HairComponent->DestroyComponent();
		HairComponent = nullptr;
	}

	const UDataTable* HairTable = P3Cms::GetCharacterHairTable();

	if (!CharacterStore.HairName.IsNone() && HairTable)
	{
		const FP3CmsCharacterHair* Hair = HairTable->FindRow<FP3CmsCharacterHair>(CharacterStore.HairName, TEXT("UpdateHairComponent"));

		if (Hair && Hair->SkeletalMesh && GetMesh())
		{
			HairComponent = NewObject<USkeletalMeshComponent>(this, TEXT("HairComponent"));
			HairComponent->SetRelativeRotation(FRotator(90, 0, 180));
			HairComponent->SetupAttachment(GetMesh(), TEXT("Hair_Item_Bone"));
			HairComponent->RegisterComponent();
			HairComponent->SetSkeletalMesh(Hair->SkeletalMesh);
			HairComponent->SetMaterial(0, Hair->Material);
			HairComponent->SetAnimInstanceClass(Hair->AnimationBlueprintClass);
			HairComponent->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
			HairComponent->SetReceivesDecals(false);
		}
	}
}

void AP3Character::UpdateArmorComponent()
{
	if (ArmorComponent)
	{
		ArmorComponent->DestroyComponent();
		ArmorComponent = nullptr;
	}

	const UDataTable* ArmorTable = P3Cms::GetCharacterArmorTable();

	if (!CharacterStore.ArmorName.IsNone() && ArmorTable)
	{
		const FP3CmsCharacterArmor* Armor = ArmorTable->FindRow<FP3CmsCharacterArmor>(CharacterStore.ArmorName, TEXT("UpdateArmorComponent"));

		if (Armor && Armor->SkeletalMesh && GetMesh())
		{
			ArmorComponent = NewObject<USkeletalMeshComponent>(this, TEXT("ArmorComponent"));
			ArmorComponent->SetupAttachment(GetMesh());
			ArmorComponent->RegisterComponent();
			ArmorComponent->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
			ArmorComponent->SetSkeletalMesh(Armor->SkeletalMesh);
			ArmorComponent->SetMasterPoseComponent(GetMesh());
			ArmorComponent->SetReceivesDecals(false);

			for (int32 MaterialIndex = 0; MaterialIndex < Armor->Materials.Num(); ++MaterialIndex)
			{
				UMaterialInterface* Material = Armor->Materials[MaterialIndex];

				ArmorComponent->SetMaterial(MaterialIndex, Material);
			}
		}
	}
}

void AP3Character::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (HealthComponent)
	{
		HealthComponent->OnDead.RemoveDynamic(this, &AP3Character::OnDead);
		HealthComponent->OnRevive.RemoveDynamic(this, &AP3Character::OnRevive);

		UP3CharacterHealthPointComponent* CharacterHealthComponent = Cast<UP3CharacterHealthPointComponent>(HealthComponent);
		if (CharacterHealthComponent)
		{
			CharacterHealthComponent->OnDownedChanged.RemoveDynamic(this, &AP3Character::OnDownedChanged);
		}
	}

	if (CombatComponent)
	{
		CombatComponent->DestroyComponent();
		CombatComponent = nullptr;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (CharacterStore.FlagActor)
		{
			CharacterStore.FlagActor->Destroy();
		}
	}
}

void AP3Character::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (IsLocalControlledActor(this))
	{
		if (HoldingKeyStatus.bIsHolding && !HoldingKeyStatus.bIsHoldingSucceeded)
		{
			HoldingKeyStatus.HoldingAgeSeconds += DeltaSeconds;

			if (HoldingKeyStatus.HoldingAgeSeconds > CVarP3HoldingKeyDurationSeconds.GetValueOnGameThread())
			{
				HoldingKeyStatus.bIsHoldingSucceeded = true;

				if (HoldingKeyStatus.InputType == EHoldingKeyInputType::Rescue)
				{
					if (CanInteract() && PickupComponent && PickupComponent->HasRescueCandidate())
					{
						if (CVarP3RescueByHoldingInput.GetValueOnGameThread() > 0)
						{
							OnStartInteract();
						}
						else if (ActionComponent)
						{
							FP3PawnActionStartRequestParams ActionParams;
							ActionParams.CarryOnBack_TargetCharacter = Cast<AP3Character>(PickupComponent->GetPickupCandidateActor());
							ActionComponent->StartAction(EPawnActionType::CarryingOnBackStart, _FUNCTION_TEXT, ActionParams);
						}
					}
				}
				else if (HoldingKeyStatus.InputType == EHoldingKeyInputType::PutdownHoldable)
				{
					if (PickupComponent)
					{
						if (PickupComponent->CanPutDownHoldable())
						{
							PickupComponent->PutdownHoldable();
						}
					}
				}
				else if (HoldingKeyStatus.InputType == EHoldingKeyInputType::PickUpBackpack)
				{
					if (CanInteract() && PickupComponent && PickupComponent->HasBackpackCandidate())
					{
						if (ActionComponent)
						{
							FP3PawnActionStartRequestParams ActionParams;
							ActionParams.PickupBackpack_BackpackActor = Cast<AP3Backpack>(PickupComponent->GetPickupCandidateActor());
							ActionParams.PickupBackpack_AttachSocketName = FName("Backpack");

							ActionComponent->StartAction(EPawnActionType::PickupBackpack, _FUNCTION_TEXT, ActionParams);
						}
					}
				}
			}
		}

		LocalControl_TickCameraBoomOffset(DeltaSeconds);
		LocalControl_TickCameraArmLength(DeltaSeconds);
		LocalControl_TickCameraFOV(DeltaSeconds);
		LocalControl_TickConsumableUI(DeltaSeconds);
		LocalControl_TickCameraRotation(DeltaSeconds);
		LocalControl_TickSprinting(DeltaSeconds);
		LocalControl_TickConsiderMount(DeltaSeconds);
	}

	TickIgnoreMoveInput();
	TickCustomSpeedMultiplier();
	TickCustomRotationRate();
	TickAllowMove();
	TickAllowRotate();
	TickAllowJump();
	TickMovementRotationMode();
	TickStamina();
	TickAffectNavigation(DeltaSeconds);
	TickMeshUpdateFlags();
	TickAllowClimb();
	TickAllowParkour();
	TickEffect();
	TickGliding();
	TickURO();
	TickCollision();

	ConsiderChangeWeaponAttachment();

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		Client_TickMinimapIconMeshComponent();
		Client_TickToggleClothSimulation();
		Client_TickBreathEffect();
	}

	if (IsRagdollizedBP())
	{
		TickMoveCapsuleDuringRagdoll();
	}

	if (bUnragollizing)
	{
		TickUnragdollizing(DeltaSeconds);
	}

	if (IsPushing() && GetStance() == EP3CharacterStance::Combat)
	{
		if (P3Core::IsP3NetModeServerInstance(*this) && ActionComponent)
		{
			// TODO: maybe do this with command?
			ActionComponent->StartAction(EPawnActionType::PutAwayWeapon, _FUNCTION_TEXT);
		}
	}

	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	//if (MovementComp)
	//{
	//	MovementComp->Server_SetOverrideAllowedPositionErrorSquared(IsPushing() ? 100 : -1);
	//}

	if (StaminaComponent)
	{
		// Disable sprint if no stamina
		if (MovementComp)
		{
			const bool bSprintDisable = StaminaComponent->GetStaminaPoint() <= 0.0f || !CanSprint();
			MovementComp->SetSprintDisabled(bSprintDisable);
		}

		if (MovementComp && (IsAutonomousProxy(this) || IsAuthority(this)))
		{
			const bool bOutOfStamina = (StaminaComponent->GetStaminaPoint() <= 0.0f);
			const bool bIsClimbJumping = ActionComponent && ActionComponent->IsActionInProgress(EPawnActionType::ClimbJump);

			// Stop climbing if no stamina
			if (bOutOfStamina && MovementComp->IsClimbing() && !bIsClimbJumping)
			{
				MovementComp->SetMovementMode(MOVE_Falling);
			}

			// Stop gliding if no stamina
			if (bOutOfStamina && MovementComp->IsGliding())
			{
				MovementComp->SetMovementMode(MOVE_Falling);
			}

			const bool bIsSliding = MovementComp->IsSliding();
			if (bIsSliding && HasStun())
			{
				MovementComp->SetMovementMode(MOVE_Walking);
			}
		}
	}

	if (EffectComponent)
	{
		if (MovementComp && (IsAutonomousProxy(this) || IsAuthority(this)))
		{
			const bool bIsClimbing = MovementComp->IsClimbing();
			const bool HasStunEffect = EffectComponent->HasStunEffect();

			// Stop climbing if the character is stunned
			if (bIsClimbing && HasStunEffect)
			{
				MovementComp->SetMovementMode(MOVE_Falling);
			}
		}
	}

	if (MovementComp)
	{
		MovementComp->ClearCustomWalkingRotation();
	}

	if (IsPushing() && PushComponent->IsRotateChracterTowardPushDirectionEnabled())
	{
		const FVector PushDirection = PushComponent->GetPushDirection().GetSafeNormal2D();

		if (MovementComp && !PushDirection.IsZero())
		{
			FRotator WalkingRotator = FQuat::FindBetweenNormals(FVector(1, 0, 0), PushDirection).Rotator();
			MovementComp->SetCustomWalkingRotation(WalkingRotator);
		}
	}

	if (TimeDilationResetTime > 0.0f)
	{
		if (TimeDilationResetTime < GetWorld()->GetTimeSeconds() || IsDead())
		{
			TimeDilationResetTime = 0.0f;
			CustomTimeDilation = 1.0f;
		}
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaSeconds);
	}
	
	// Clean up null pointers in rider list (This can happen if rider actor is destroyed)
	for (auto Iter = CharacterStore.MountRiderCharacters.CreateIterator(); Iter; ++Iter)
	{
		if (Iter.Value() == nullptr)
		{
			Iter.RemoveCurrent();
		}
	}

#if ENABLE_DRAW_DEBUG
	TickAIDebug();

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		Client_DebugDraw();
	}
#endif
}

void AP3Character::SetActorHiddenInGame(bool bNewHidden)
{
	Super::SetActorHiddenInGame(bNewHidden);

	TInlineComponentArray<UP3HolderComponent*> HolderComps;
	GetComponents(HolderComps);

	for (UP3HolderComponent* HolderComp : HolderComps)
	{
		HolderComp->OnCharacterHiddenChanged(bNewHidden);
	}
}

void AP3Character::TickCustomSpeedMultiplier()
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (!MovementComp)
	{
		return;
	}

	float CustomSpeedMultiplier = EffectComponent ? EffectComponent->GetMoveSpeedMultiplier() : 1.0f;

	// Absolute multiplier, order by inverse priority

	if (PickupComponent)
	{
		AActor* PickuppedActor = PickupComponent->GetPickuppedActor();
		if (PickuppedActor)
		{
			UP3PickupableComponent* PickupableComp = PickuppedActor->FindComponentByClass<UP3PickupableComponent>();
			if (PickupableComp && PickupableComp->GetPickupableType() == EP3PickupableType::Spear)
			{
				CustomSpeedMultiplier = 0.9f;
			}
			else
			{
				CustomSpeedMultiplier = 0.3f;
			}
		}
	}

	if (IsPushing() && PushComponent)
	{
		const float PushSpeed = PushComponent->GetPushMovementSpeed(PushComponent->GetPushTargetActor());
		CustomSpeedMultiplier = MovementComp->GetMaxSpeed() > 0 ? PushSpeed / MovementComp->GetMaxSpeed() : 0.0f;
	}

	if (CharacterStore.bIsBlocking)
	{
		CustomSpeedMultiplier = MovementComp->GetBlockingWalkSpeedMultiplier();
	}

	if (CharacterStore.bIsCrouchBlocking)
	{
		CustomSpeedMultiplier = MovementComp->GetCrunchBlockingWalkSpeedMultiplier();
	}

	if (InventoryComponent && InventoryComponent->IsCarryingBackpack())
	{
		switch (InventoryComponent->GetBackpackWeight())
		{
		case EP3BackpackWeight::Heavy:
			CustomSpeedMultiplier = MovementComp->GetHeavyBackpackSpeedMultiplier();
			break;
		case EP3BackpackWeight::Middle:
			CustomSpeedMultiplier = MovementComp->GetMiddleBackpackSpeedMultiplier();
			break;
		case EP3BackpackWeight::Light:
			CustomSpeedMultiplier = MovementComp->GetLightBackpackSpeedMultiplier();
			break;
		}
	}

	// Relative multipliers

	if (CharacterStore.bIsMeleeAiming)
	{
		CustomSpeedMultiplier *= MovementComp->GetMeleeAimingSpeedMultiplier();
	}

	if (CharacterStore.bIsAiming)
	{
		CustomSpeedMultiplier *= MovementComp->GetAimingSpeedMultiplier();

		if (CharacterStore.ThrowAimingItemId != INVALID_ITEMID)
		{
			// TODO: Work around to match up with animation speed
			CustomSpeedMultiplier *= 0.5f;
		}
	}

	if (StaminaComponent && StaminaComponent->IsExhausted())
	{
		CustomSpeedMultiplier *= MovementComp->GetExhaustSpeedMultiplier();
	}

	if (ActionComponent)
	{
		CustomSpeedMultiplier *= ActionComponent->GetMoveSpeedMultiplier();
	}

	if (EffectComponent)
	{
		// Swamp ...
		CustomSpeedMultiplier *= EffectComponent->GetMoveSpeedMultiplier();
	}

	if (ComboTableComponent)
	{
		CustomSpeedMultiplier *= ComboTableComponent->GetMoveSpeedMultiplier();
	}

	if (CharacterStore.bIsStumbling)
	{
		CustomSpeedMultiplier *= MovementComp->GetStumblingSpeedMultiplier();
	}

	if (EffectComponent && EffectComponent->HasEffect(EP3CharacterEffectTypes::Slow))
	{
		CustomSpeedMultiplier *= 0.5f;
	}

	if (EffectComponent && EffectComponent->HasEffect(EP3CharacterEffectTypes::Entangle))
	{
		CustomSpeedMultiplier = 0;
	}

	if (EffectComponent && EffectComponent->HasEffect(EP3CharacterEffectTypes::RoarStun))
	{
		CustomSpeedMultiplier = 0;
	}

	if (EffectComponent && EffectComponent->HasEffect(EP3CharacterEffectTypes::Stun))
	{
		CustomSpeedMultiplier = 0;
	}

	if (CharacterStore.bKnockDowned)
	{
		CustomSpeedMultiplier = 0;
	}

	if (CharacterStore.bIsStumbling)
	{
		CustomSpeedMultiplier = 0;
	}

	if (CharacterStore.bGodMode)
	{
		CustomSpeedMultiplier = 3.0f;
	}

	MovementComp->SetCustomWalkSpeedMultiplier(CustomSpeedMultiplier);
}

void AP3Character::TickCustomRotationRate()
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (!MovementComp)
	{
		return;
	}

	UP3AnimInstance* AnimInstance = GetMesh() ? Cast<UP3AnimInstance>(GetMesh()->GetAnimInstance()) : nullptr;

	if (!AnimInstance)
	{
		return;
	}

	FRotator RotationRate = MovementComp->RotationRate;

	if (AnimInstance->IsPlayingTurnAnimation())
	{
		RotationRate.Yaw = AnimInstance->GetTurnAnimationRotationDegreePerSecond();

		MovementComp->SetCustomRotationRate(true, RotationRate);
	}
	else
	{		
		if (ComboTableComponent)
		{
			if (ComboTableComponent->CanTurn())
			{
				RotationRate.Yaw *= ComboTableComponent->GetRotationYawRateMultiplier();
				MovementComp->SetCustomRotationRate(true, RotationRate);
			}
			else
			{
				MovementComp->SetCustomRotationRate(true, FRotator::ZeroRotator);
			}
		}
		else
		{
			MovementComp->SetCustomRotationRate(false, RotationRate);
		}
	}
}

void AP3Character::TickIgnoreMoveInput()
{
	AController* MyController = GetController();

	if (!MyController || !MyController->IsLocalController())
	{
		return;
	}

	bool bNewIgnoreMoveInput = false;

	if (IsDeadOrDowned())
	{
		bNewIgnoreMoveInput = true;
	}
	else if (ActionComponent && ActionComponent->IsIgnoreMoveInput())
	{
		bNewIgnoreMoveInput = true;
	}
	else if (EffectComponent
		&& (EffectComponent->HasEffect(EP3CharacterEffectTypes::Entangle)
			|| EffectComponent->HasEffect(EP3CharacterEffectTypes::RoarStun)
			|| EffectComponent->HasEffect(EP3CharacterEffectTypes::Stun)))
	{
		bNewIgnoreMoveInput = true;
	}

	if (bIgnoredMoveInput != bNewIgnoreMoveInput)
	{
		UE_LOG(P3Log, Verbose, TEXT("Change ignore move input. New Value: %s"), bNewIgnoreMoveInput ? TEXT("true") : TEXT("false"));

		bIgnoredMoveInput = bNewIgnoreMoveInput;

		MyController->SetIgnoreMoveInput(bIgnoredMoveInput);
	}
}

void AP3Character::TickAllowMove()
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (!MovementComp)
	{
		return;
	}

	bool bNewMoveAllowed = true;

	if (ActionComponent)
	{
		bNewMoveAllowed = ActionComponent->IsMoveAllowed();
	}

	MovementComp->SetAllowMove(bNewMoveAllowed);
}

void AP3Character::TickAllowRotate()
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (!MovementComp)
	{
		return;
	}

	bool bNewRotateAllowed = true;

	if (ActionComponent)
	{
		bNewRotateAllowed = ActionComponent->IsRotateAllowed();
	}

	if (CharacterStore.bIsStumbling)
	{
		bNewRotateAllowed = false;
	}

	MovementComp->SetAllowRotate(bNewRotateAllowed);
}

void AP3Character::TickAllowJump()
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (!MovementComp)
	{
		return;
	}

	bool bNewJumpAllowed = true;

	if (ActionComponent)
	{
		bNewJumpAllowed = ActionComponent->IsJumpAllowed();
	}

	MovementComp->SetJumpAllowed(bNewJumpAllowed);
}

void AP3Character::Server_TickBlocking()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!CommandComponent)
	{
		return;
	}

	if (CharacterStore.bIsBlocking || CharacterStore.bIsCrouchBlocking)
	{
		bool bStopBlocking = false;

		if (!CanBlock())
		{
			bStopBlocking = true;
		}

		if (bStopBlocking)
		{
			if (CharacterStore.bIsBlocking)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetBlocking_bNewBlocking = false;
				CommandComponent->RequestCommand(UP3SetBlockingCommand::StaticClass(), CommandParams);
			}

			if (CharacterStore.bIsCrouchBlocking)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetCrouchBlocking_bNewBlocking = false;
				CommandComponent->RequestCommand(UP3SetCrouchBlockingCommand::StaticClass(), CommandParams);
			}
		}
	}
}

void AP3Character::Server_TickAiming()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!CommandComponent)
	{
		return;
	}

	if (CharacterStore.bIsAiming || CharacterStore.bIsMeleeAiming)
	{
		if (!CanAiming())
		{
			if (CharacterStore.bIsAiming)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetRangedAiming_bNewAiming = false;
				CommandComponent->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), CommandParams);
			}

			if (CharacterStore.bIsMeleeAiming)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetMeleeAiming_bNewAiming = false;
				CommandComponent->RequestCommand(UP3SetMeleeAimingCommand::StaticClass(), CommandParams);
			}
		}
	}
}

void AP3Character::Server_TickDestoryObjects()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!IsLarge())
	{
		return;
	}

	if (!GetMesh())
	{
		return;
	}

	TArray<FOverlapResult> Overlaps;
	// note this will optionally include overlaps with components in the same actor (depending on bIgnoreChildren). 
	FComponentQueryParams Params(SCENE_QUERY_STAT(UpdateLargeCharacterMeshOverlap), this);
	//Params.bIgnoreBlocks = true;	//We don't care about blockers since we only route overlap events to real overlaps
	Params.bIgnoreBlocks = false;
	FCollisionResponseParams ResponseParam;

	GetMesh()->InitSweepCollisionParams(Params, ResponseParam);
	GetMesh()->ComponentOverlapMulti(Overlaps, GetWorld(), GetMesh()->GetComponentLocation(), GetMesh()->GetComponentQuat(), GetMesh()->GetCollisionObjectType(), Params);

	for (const FOverlapResult& Overlap : Overlaps)
	{
		AActor* OverlappedActor = Overlap.GetActor();

		AP3Tree* Tree = Cast<AP3Tree>(OverlappedActor);
		if (Tree && !Tree->IsCutDowned())
		{
			P3Combat::FDamageActorParams DamageParams(*this, *OverlappedActor);
			DamageParams.ImpactDirection = (OverlappedActor->GetActorLocation() - GetActorLocation()).GetSafeNormal();

			P3Combat::Server_DamageActor(DamageParams);
		}

		AP3Destructible* Destructible = !Tree ? Cast<AP3Destructible>(OverlappedActor) : nullptr;
		if (Destructible && Destructible->GetFractureByLargeCharacterOverlap() && !Destructible->Server_IsExploded() && !Destructible->Server_GetHitIgnoreActors().Contains(this))
		{
			Destructible->Server_Fracture();
		}
	}
}

void AP3Character::Server_ConsiderDismount()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!CharacterStore.MountTargetCharacter)
	{
		return;
	}

	if (!CommandComponent || !StaminaComponent)
	{
		return;
	}

	bool bDismount = false;

	if (!CharacterStore.bMountingByRescuer)
	{
		if (StaminaComponent->IsExhausted())
		{
			P3JsonLog(Verbose, "Character Dismount Reason : Exhausted", TEXT("Character"), *GetName());
			bDismount = true;
		}

		if (!bDismount && IsDowned())
		{
			P3JsonLog(Verbose, "Character Dismount Reason : Dead or Downed", TEXT("Character"), *GetName());
			bDismount = true;
		}
	}

	if (!bDismount && IsRagdollizedBP())
	{
		P3JsonLog(Verbose, "Character Dismount Reason : Ragdollized", TEXT("Character"), *GetName());
		bDismount = true;
	}

	if (!bDismount && IsDead())
	{
		P3JsonLog(Verbose, "Character Dismount Reason : Dead or Downed", TEXT("Character"), *GetName());
		bDismount = true;
	}

	if (!bDismount && IsKnockDowned())
	{
		P3JsonLog(Verbose, "Character Dismount Reason : KnockDowned", TEXT("Character"), *GetName());
		bDismount = true;
	}

	if (!bDismount && CharacterStore.MountTargetCharacter->IsDeadOrDowned())
	{
		P3JsonLog(Verbose, "Character Dismount Reason : Mount Target is Dead or Downed",
			TEXT("Character"), *GetName(),
			TEXT("MountTargetCharacter"), CharacterStore.MountTargetCharacter->GetName());
		bDismount = true;
	}

	if (!bDismount && CharacterStore.MountTargetCharacter->IsActorBeingDestroyed())
	{
		P3JsonLog(Verbose, "Character Dismount Reason : Mount Target is Destoyed",
			TEXT("Character"), *GetName(),
			TEXT("MountTargetCharacter"), CharacterStore.MountTargetCharacter->GetName());
		bDismount = true;
	}

	if (bDismount)
	{
		FP3CommandRequestParams CommandParams;
		CommandParams.Mount_Detach = true;
		CommandComponent->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
	}
}

void AP3Character::Server_TickLOD()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (CVarP3UseCharacterServerLOD.GetValueOnGameThread() == 0 || P3Core::IsP3NetModeClientInstance(*this))
	{
		Server_LOD = EP3CharacterServerLOD::Normal;
		return;
	}

	if (IsPlayerControlled() || IsLarge())
	{
		Server_LOD = EP3CharacterServerLOD::Normal;
		return;
	}

	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(*this);

	if (!ServerWorld)
	{
		return;
	}

	// See if any players around
	const FVector MyLocation = GetActorLocation();
	const float SleepDistanceSquared = FMath::Square(CVarP3CharacterServerLODSleepDistance.GetValueOnGameThread());
	const TArray<UP3ServerPlayer*>& Players = ServerWorld->GetPlayers();

	bool bHasPlayerWithinSleepDistance = false;

	for (const UP3ServerPlayer* Player : Players)
	{
		const APawn* Pawn = Player && Player->PlayerController ? Player->PlayerController->GetPawn() : nullptr;

		if (!Pawn)
		{
			continue;
		}

		const FVector PlayerLocation = Pawn->GetActorLocation();
		const float DistanceSquared = (MyLocation - PlayerLocation).SizeSquared();

		if (DistanceSquared < SleepDistanceSquared)
		{
			bHasPlayerWithinSleepDistance = true;
			break;
		}
	}

	if (bHasPlayerWithinSleepDistance)
	{
		Server_LOD = EP3CharacterServerLOD::Normal;
	}
	else
	{
		Server_LOD = EP3CharacterServerLOD::Sleep;
	}

	if (CVarP3CharacterServerLODDebug.GetValueOnGameThread() != 0)
	{
		Server_SetDirty(*this);
	}
}

void AP3Character::Server_ApplyLOD()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Server_LOD == EP3CharacterServerLOD::Normal)
	{
		if (GetCharacterMovement())
		{
			GetCharacterMovement()->SetComponentTickEnabled(true);
		}

		if (GetMesh())
		{
			GetMesh()->SetComponentTickEnabled(true);
		}

		AAIController* AICon = Cast<AAIController>(GetController());

		if (AICon && AICon->GetBrainComponent())
		{
			AICon->GetBrainComponent()->SetComponentTickEnabled(true);
		}
	}
	else if (Server_LOD == EP3CharacterServerLOD::Sleep)
	{
		if (GetCharacterMovement())
		{
			GetCharacterMovement()->SetComponentTickEnabled(false);
		}

		if (GetMesh())
		{
			GetMesh()->SetComponentTickEnabled(false);
		}

		AAIController* AICon = Cast<AAIController>(GetController());

		if (AICon && AICon->GetBrainComponent())
		{
			AICon->GetBrainComponent()->SetComponentTickEnabled(false);
		}
	}
	else
	{
		// Not handled
		ensure(0);
	}
}

void AP3Character::TickAffectNavigation(float DeltaSeconds)
{
	if (CVarP3CharacterNotMovingAffectNavigationTimeSeconds.GetValueOnGameThread() <= 0)
	{
		return;
	}

	if (GetCharacterMovement() && GetCharacterMovement()->Velocity.IsZero())
	{
		NotMovingAgeSecondsForAffectNavigation += DeltaSeconds;

		if (NotMovingAgeSecondsForAffectNavigation > CVarP3CharacterNotMovingAffectNavigationTimeSeconds.GetValueOnGameThread())
		{
			SetCanAffectNavigationGeneration(true);
		}
	}
	else
	{
		NotMovingAgeSecondsForAffectNavigation = 0;

		SetCanAffectNavigationGeneration(false);
	}
}

void AP3Character::TickMovementRotationMode()
{
	UCharacterMovementComponent* MovementComp = GetCharacterMovement();
	if (!MovementComp)
	{
		return;
	}

	bool bUseControllerDesiredRotation = bDefaultUseControllerDesiredRotation;

	if (!IsInLookingForward()
		&& GetCharacterStoreBP().bIsBlocking
		&& CVarP3BlockingMovementMode.GetValueOnGameThread())
	{
		bUseControllerDesiredRotation = true;
	}

	if (GetCharacterStoreBP().bIsMeleeAiming)
	{
		bUseControllerDesiredRotation = true;
	}

	if (GetCharacterStoreBP().bIsAiming)
	{				
		bUseControllerDesiredRotation = true;		
	}

	if (PickupComponent && PickupComponent->IsAimingThrowing())
	{
		bUseControllerDesiredRotation = true;
	}

	MovementComp->bUseControllerDesiredRotation = bUseControllerDesiredRotation;
	MovementComp->bOrientRotationToMovement = !bUseControllerDesiredRotation;
}

void AP3Character::LocalControl_TickCameraBoomOffset(float DeltaSeconds)
{
	if (!CameraBoom)
	{
		return;
	}

	FVector NewOffset = DefaultCameraOffset;
	float OffsetInterpSpeedRatio = 1.f;

	if (IsSliding() && CVarP3SlidingCameraOffset.GetValueOnGameThread())
	{
		NewOffset += SlidingCameraOffset;
	}
	else
	{
		if (ComboTableComponent)
		{
			NewOffset += ComboTableComponent->GetSocketOffset();
			OffsetInterpSpeedRatio = ComboTableComponent->GetSocketOffsetInterpSpeedRatio();
		}

		if (CombatComponent && CombatComponent->IsCrossHairMode())
		{
			NewOffset += AimModeCameraOffset;
		}
	}

	CameraBoom->SocketOffset = FMath::VInterpTo(CameraBoom->SocketOffset, NewOffset, DeltaSeconds, 10.0f * OffsetInterpSpeedRatio);
}

void AP3Character::LocalControl_TickCameraArmLength(float DeltaSeconds)
{
	float ArmLengthInterpSpeedRatio = 1.f;
	float NewArmLength = LocalControl_CameraBoomTargetArmLength;

	if (IsSliding() && CVarP3SlidingCameraArmLength.GetValueOnGameThread())
	{
		NewArmLength = SlidingCameraDistance;
	}
	else if (IsMounted())
	{
		NewArmLength *= CVarP3MountedCameraDistanceMultiplier.GetValueOnGameThread();
	}
	else
	{
		if (LocalControl_RangeZoomMode)
		{
			NewArmLength = RangeZoomCameraDistance;
		}

		if (ComboTableComponent)
		{
			NewArmLength *= ComboTableComponent->GetTargetArmLengthRatio();
			ArmLengthInterpSpeedRatio = ComboTableComponent->GetTargetArmLengthInterpSpeedRatio();
		}
	}

	SetCameraBoomDistance(
		FMath::Lerp(
			CameraBoom->TargetArmLength,
			NewArmLength,
			FMath::Min(DeltaSeconds * 10.0f * ArmLengthInterpSpeedRatio, 1.0f)));
}

void AP3Character::LocalControl_TickCameraFOV(float DeltaSeconds)
{
	if (!FollowCamera)
	{
		return;
	}

	float FieldOfViewRatio = 1.f;
	float FieldOfViewInterpSpeedRatio = 1.f;

	if (IsSliding() && CVarP3SlidingCameraFOV.GetValueOnGameThread())
	{
		FieldOfViewRatio *= 0.85f;
	}
	else
	{
		if (ComboTableComponent)
		{
			FieldOfViewRatio = ComboTableComponent->GetFieldOfViewRatio();
			FieldOfViewInterpSpeedRatio = ComboTableComponent->GetFieldOfViewInterpSpeedRatio();
		}

		if (LocalControl_RangeZoomMode)
		{
			FieldOfViewRatio *= 0.8f;
		}
	}

	float BaseFieldOfView = LocalControl_DefaultFOV;

	UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());
	if (UserSettings)
	{
		BaseFieldOfView = UserSettings->GetFieldOfView();
	}

	FollowCamera->SetFieldOfView(
		FMath::Lerp(
			FollowCamera->FieldOfView,
			BaseFieldOfView * FieldOfViewRatio,
			FMath::Min(DeltaSeconds * 10.0f * FieldOfViewInterpSpeedRatio, 1.0f))
	);
}

void AP3Character::LocalControl_TickConsumableUI(float DeltaSeconds)
{
	if (!LocalControl_bConsumableUIOpened)
	{
		return;
	}

	LocalControl_ConsumableUIOpenedAgeSeconds += DeltaSeconds;

	if (LocalControl_ConsumableUIOpenedAgeSeconds > CVarP3ConsumableUIAutoCloseTime.GetValueOnGameThread())
	{
		LocalControl_bConsumableUIOpened = false;
		LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;

		OnInputCloseConsumableUI.Broadcast();
	}
}

void AP3Character::LocalControl_TickCameraRotation(float DeltaSeconds)
{
	AController* CharacterController = GetController();
	
	if (!CharacterController)
	{
		return;
	}

	if (IsMounted() && CVarP3MountedCameraBackOriginRotation.GetValueOnGameThread())
	{
		if ((CVarP3RotateCameraOnMountingResuced.GetValueOnGameThread() > 0 && CharacterStore.bMountingByRescuer) || !CharacterStore.bMountingByRescuer)
		{
			const FRotator CurrentRotation = CharacterController->GetControlRotation();
			const FRotator DestRotation = UKismetMathLibrary::MakeRotFromX(-GetActorUpVector());
			const float LerpSpeed = FMath::Clamp(DeltaSeconds * CVarP3MountedCameraBackOriginRotationSpeed.GetValueOnGameThread(), 0.0f, 1.0f);

			FRotator NewRotation = FMath::Lerp(CurrentRotation, DestRotation, LerpSpeed);
			NewRotation.Roll = 0.0f;

			CharacterController->SetControlRotation(NewRotation);
		}
	}
	else if (IsSliding() && CVarP3SlidingCameraFollow.GetValueOnGameThread())
	{
		const FRotator CurrentRotation = CharacterController->GetControlRotation();
		const FRotator DestRotation = GetActorRotation();
		const float LerpSpeed = FMath::Clamp(DeltaSeconds * CVarP3SlidingCameraFollowSpeed.GetValueOnGameThread(), 0.0f, 1.0f);

		const FRotator NewRotation = FMath::Lerp(CurrentRotation, DestRotation, LerpSpeed);

		CharacterController->SetControlRotation(NewRotation);
	}
	else
	{
		if (ComboTableComponent && ComboTableComponent->GetCameraFollowSpeed() > 0.f)
		{
			const FRotator CurrentRotation = CharacterController->GetControlRotation();
			const FRotator DestRotation = ComboTableComponent->GetAimingStartRotation();
			const float LerpSpeed = FMath::Clamp(DeltaSeconds *  ComboTableComponent->GetCameraFollowSpeed(), 0.0f, 1.0f);

			const FRotator NewRotation = FMath::Lerp(CurrentRotation, DestRotation, LerpSpeed);

			CharacterController->SetControlRotation(NewRotation);
		}
	}

	if (CVarP3ControllerRotationDebug.GetValueOnGameThread() > 0)
	{
		const FRotator CurrentRotation = CharacterController->GetControlRotation();
		AddDebugString(FString::Printf(TEXT("[ControllerRotation] Pitch: %.1f, Yaw: %.1f, Roll: %.1f"), CurrentRotation.Pitch, CurrentRotation.Yaw, CurrentRotation.Roll));
	}
}

void AP3Character::LocalControl_TickConsiderMount(float DeltaSeconds)
{
	if (!ensure(IsLocalControlledActor(this)))
	{
		return;
	}

	bCanMount = false;

	if (GetAttachParentActor())
	{
		// Already attached to something
		return;
	}

	MountOverlappedCharacter = nullptr;
	MountOverlappedPointIndex = -1;

	if (!CommandComponent || !GetCharacterMovement())
	{
		return;
	}

	if (LastUnmountTimeSeconds > 0 && GetWorld()->GetTimeSeconds() - LastUnmountTimeSeconds < 5.0f)
	{
		// Do not mount if we just mounted (and possibly still falling)
		return;
	}

	if (!GetCharacterMovement()->IsFalling())
	{
		return;
	}

	const FVector MyLocation = GetActorLocation();

	FComponentQueryParams QueryParams;
	QueryParams.AddIgnoredActor(this);
	TArray<AActor*> AttachedActors;
	GetAttachedActors(AttachedActors);
	QueryParams.AddIgnoredActors(AttachedActors);

	TArray<FOverlapResult> OverlapResults;
	GetWorld()->ComponentOverlapMultiByChannel(OverlapResults, GetCapsuleComponent(), GetActorLocation(), GetActorRotation(), ECC_Pawn, QueryParams, FCollisionObjectQueryParams(ECC_Pawn));

	float MinDistanceSquared = MAX_flt;

	const AActor* MyRootActor = P3Core::GetAttachRootActor(this, true);

	for (const FOverlapResult& OverlapResult : OverlapResults)
	{
		AP3Character* OverlappedCharacter = Cast<AP3Character>(OverlapResult.GetActor());
		if (!OverlappedCharacter || !OverlappedCharacter->GetMesh())
		{
			continue;
		}

		if (!OverlappedCharacter->IsLarge())
		{
			continue;
		}

		const AActor* OverlappedRootActor = P3Core::GetAttachRootActor(OverlappedCharacter, true);
		if (MyRootActor == OverlappedRootActor)
		{
			continue;
		}

		int32 TargetMountPointIndex = -1;

		const int32 NumMountPoints = OverlappedCharacter->GetMountPoints().Num();
		for (int32 MountPointIndex = 0; MountPointIndex < NumMountPoints; ++MountPointIndex)
		{
			if (!OverlappedCharacter->IsMountPointAvailable(MountPointIndex))
			{
				continue;
			}

			const FP3CharacterMountPoint& MountPoint = OverlappedCharacter->GetMountPoints()[MountPointIndex];
			const FVector SocketLocation = OverlappedCharacter->GetMesh()->GetSocketLocation(MountPoint.SocketName);
			const float DistanceSquared = (SocketLocation - MyLocation).SizeSquared();
			if (DistanceSquared < FMath::Square(MountPoint.MountStartRadius))
			{
				if (MinDistanceSquared > DistanceSquared)
				{
					MinDistanceSquared = DistanceSquared;
					TargetMountPointIndex = MountPointIndex;
				}
			}
		}

		if (TargetMountPointIndex != -1)
		{
			MountOverlappedCharacter = OverlappedCharacter;
			MountOverlappedPointIndex = TargetMountPointIndex;
			break;
		}
	}	
	
	if (MountOverlappedCharacter && MountOverlappedPointIndex != -1)
	{	
		bCanMount = true;
	}
}

void AP3Character::TickStamina()
{
	if (!StaminaComponent)
	{
		return;
	}

	bool bNewRegenAllowed = true;

	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	// Consume stamina during sprint
	if (MovementComp && MovementComp->GetSprintingPressed() && MovementComp->MovementMode == MOVE_Walking && !MovementComp->Velocity.IsZero() && !MovementComp->GetSprintDisabled())
	{
		if (IsLarge())
		{
			bNewRegenAllowed = false;
			StaminaComponent->SetConsumer(EStaminaConsumerLayer::Sprint, StaminaConsumePerSecondDuringSprint * CVarP3StaminaConsumptionOfLargeCharacterSprintMultiplier.GetValueOnGameThread());
		}
		else
		{
			bNewRegenAllowed = false;
			StaminaComponent->SetConsumer(EStaminaConsumerLayer::Sprint, StaminaConsumePerSecondDuringSprint);
		}
	}
	else
	{
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Sprint, 0);
	}

	// Consume stamina during charging
	if (ActionComponent && ActionComponent->GetActiveActionType() == EPawnActionType::CombatCharging)
	{
		bNewRegenAllowed = false;
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::CombatCharging, StaminaConsumePerSecondDuringCharging * CVarP3StaminaConsumptionDuringChargingMultiplier.GetValueOnGameThread());
	}
	else
	{
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::CombatCharging, 0);
	}

	// Consume stamina during combo
	if (ActionComponent && ActionComponent->GetActiveActionType() == EPawnActionType::CombatCombo)
	{
		if (ComboTableComponent && !ComboTableComponent->IsStaminaRegenAllowed())
		{
			bNewRegenAllowed = false;
		}
	}

	// Consume stamina during climbing
	if (MovementComp && MovementComp->IsClimbing())
	{
		bNewRegenAllowed = false;
		
		if (MovementComp->GetCurrentAcceleration().IsZero())
		{
			StaminaComponent->SetConsumer(EStaminaConsumerLayer::Climbing, 0);
		}
		else
		{
			StaminaComponent->SetConsumer(EStaminaConsumerLayer::Climbing, StaminaConsumePerSecondDuringClimbing);
		}
	}
	else
	{
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Climbing, 0);
	}

	// Consume stamina during blocking
	if (CharacterStore.bIsBlocking)
	{
		bNewRegenAllowed = false;
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Blocking, StaminaConsumePerSecondDuringBlocking);
	}
	else
	{
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Blocking, 0);
	}

	// Consume stamina during gliding
	if (IsGliding())
	{
		bNewRegenAllowed = false;
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Gliding, StaminaConsumePerSecondDuringGliding);
	}
	else
	{
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Gliding, 0);
	}

	// Consume stamina during pushing
	if (CharacterStore.Stance == EP3CharacterStance::Push)
	{
		bNewRegenAllowed = false;
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Pushing, StaminaConsumePerSecondDuringPushing);
	}
	else
	{
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Pushing, 0);
	}

	// Consume stamina during mount
	if (IsMounted())
	{
		bNewRegenAllowed = false;
		const float EnduringMultiplier = IsBuckingEnduring() ? StaminaConsumeEnduringMultiplier : 1.0f;
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Mounted, StaminaConsumePerSecondDuringMounting * EnduringMultiplier);
	}
	else
	{
		StaminaComponent->SetConsumer(EStaminaConsumerLayer::Mounted, 0);
	}
	
	if (bNewRegenAllowed && ActionComponent && !ActionComponent->CanRegenStamina())
	{
		bNewRegenAllowed = false;
	}

	if (MovementComp && MovementComp->IsFalling())
	{
		bNewRegenAllowed = false;
	}

	StaminaComponent->SetRegenAllowed(bNewRegenAllowed);
}

void AP3Character::MoveBlockedBy(const FHitResult& Impact)
{
	Super::MoveBlockedBy(Impact);

	if (PushComponent)
	{
		PushComponent->OnMoveBlockedBy(Impact);
	}
} 

void AP3Character::Landed(const FHitResult& Hit)
{
	Super::Landed(Hit);

	if (GetMovementComponent() && -GetMovementComponent()->Velocity.Z > HardLandingDamageMinSpeed)
	{
		const float Speed = -GetMovementComponent()->Velocity.Z;

		// Note clamp to 1.1 instead of 1.0 to avoid precision problem
		const float DamageRate = FMath::Clamp(HardLandingDamagePerSpeed > 0 ? (Speed - HardLandingDamageMinSpeed) / HardLandingDamagePerSpeed : 0, 0.0f, 1.1f);
		const int32 FallDamage = (HealthComponent) ? HealthComponent->GetMaxHealthPoint() * DamageRate : 0;

		if (FallDamage > 0 && HealthComponent)
		{	
#if FIXME_CHARACTER_MOVEMENT_CLIENT_AUTHORITY
			// In client authority mode, server doesn't call this function
			// So client have to report to server
			if (ensure(P3Core::IsP3NetModeClientInstance(*this)) && IsLocalControlledActor(this) && ensure(CommandComponent))
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.ApplyDamage_DamageAmount = FallDamage;
				CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Fall;
				CommandComponent->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
			}

#else
			P3Combat::ChangeActorHealth(nullptr, *HealthComponent, -FallDamage, EP3HealthChangeReason::Fall);
#endif
			// If Damaged, Drop Pickable Item
			if (FallDamage > CVarP3FallDamageToDropPickableDebug.GetValueOnGameThread()
				&& P3Core::IsP3NetModeServerInstance(*this))
			{
				FP3CommandRequestParams CommandParams;
				GetCommandComponent()->RequestCommand(UP3DropPickableCommand::StaticClass(), CommandParams);
			}
		}
	}
}

// Override
void AP3Character::OnMovementModeChanged(EMovementMode PrevMovementMode, uint8 PreviousCustomMode /*= 0*/)
{
	// Note: GetP3CharacterMovement()->IsGliding() is needed to change to gliding mode at multiplayer
	if (!GetP3CharacterMovementBP()->IsSliding()
		&& (!bPressedJump || !(GetCharacterMovement()->IsFalling() || GetP3CharacterMovementBP()->IsGliding())))
	{
		ResetJumpState();
	}

	// Recored jump force start time for proxies. Allows us to expire the jump even if not continually ticking down a timer.
	if (bProxyIsJumpForceApplied && GetCharacterMovement()->IsFalling())
	{
		ProxyJumpForceStartedTime = GetWorld()->GetTimeSeconds();
	}

	if (IsLocalControlledActor(this) && GetP3CharacterMovementBP()->IsGliding())
	{
		LocalControl_CloseConsumableUI();
	}

	K2_OnMovementModeChanged(PrevMovementMode, GetCharacterMovement()->MovementMode, PreviousCustomMode, GetCharacterMovement()->CustomMovementMode);
	MovementModeChangedDelegate.Broadcast(this, PrevMovementMode, PreviousCustomMode);
}

void AP3Character::OnRep_Controller()
{
	Super::OnRep_Controller();

	if (IsLocallyControlled())
	{
		CreateCameraAndBoom();
	}
	else
	{
		DestroyCameraAndBoom();
	}
}

void AP3Character::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	if (IsPlayerControlled() && IsLocallyControlled())
	{
		CreateCameraAndBoom();
	}
	else
	{
		DestroyCameraAndBoom();
	}
}

void AP3Character::UnPossessed()
{
	Super::UnPossessed();

	DestroyCameraAndBoom();
}

bool AP3Character::ApplyImpactPhysicsForces(const FHitResult& Impact, const FVector& ImpactAcceleration, const FVector& ImpactVelocity, float MaxSpeed)
{
	if (PushComponent)
	{
		return PushComponent->ApplyImpactPhysicsForces(Impact, ImpactAcceleration, ImpactVelocity, MaxSpeed);
	}

	return false;
}

void AP3Character::OnPreMovementTick()
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (!MovementComp)
	{
		return;
	}

	const bool bIsInKnockBackAction = (ActionComponent && ActionComponent->IsInKnockBack());

	MovementComp->SetbIsInKnockBack(bIsInKnockBackAction);
}

void AP3Character::NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	Super::NotifyHit(MyComp, Other, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);

	const bool bNotMyFloor = (GetCharacterMovement() && GetCharacterMovement()->CurrentFloor.HitResult.Component != OtherComp);
	const bool bImInstigator = (Other && (Other->GetInstigator() == this));

	if (bNotMyFloor
		&& !bImInstigator
		&& OtherComp && OtherComp->IsSimulatingPhysics()
		&& (MyComp == GetCapsuleComponent()) && !IsDeadOrDowned()
		&& Other && !Other->ActorHasTag(P3Tags::NoHitDamage))
	{
		const float MyMass = GetCharacterMovement()->Mass;
		const float OtherMass = OtherComp->GetMass();

		if (MyMass > KINDA_SMALL_NUMBER && OtherMass > KINDA_SMALL_NUMBER && !NormalImpulse.IsNearlyZero())
		{
			const float MassRatio = OtherMass / (OtherMass + MyMass);
			const FVector OtherAngularVelocity = OtherComp->GetPhysicsAngularVelocityInDegrees();
			const FVector OtherVelocity = OtherComp->GetPhysicsLinearVelocityAtPoint(HitLocation);
			const FVector MyVelocity = GetVelocity();
			//const FVector ImpulseFromVelocity = OtherVelocity * OtherMass;
			//const float NormalImpulseFromVelocitySize = ImpulseFromVelocity | HitNormal;
			//const FVector NormalImpuseFromVelocity = HitNormal * NormalImpulseFromVelocitySize;
			const float NormalSpeed = OtherVelocity | HitNormal;
			const float ImpulseSize = NormalImpulse.Size();//FMath::Min(NormalImpulse.Size(), NormalImpulseFromVelocitySize);
			const float EstimatedTargetSpeed = ImpulseSize / OtherMass;

			bool bOtherImpulseApplied = false;

			//// Sometimes, it looks like character can penetrate into other object, maybe due to nature of asynchronous of physics
			//// We can assume if other object is moving away, this is the case and ignore
			//// ie) Player get damaged during walk into physical-plank(see-saw)
			//const float OtherNormalSpeed = OtherVelocity | HitNormal;
			//const float OtherIsMovingAway = (OtherNormalSpeed <= 0);

			if (P3Core::IsP3NetModeServerInstance(*this))
			{
				const float CoolDonwTimeSeconds = CVarP3HitDamageCooldownTimeSeconds.GetValueOnGameThread();
				const float Now = GetWorld()->GetTimeSeconds();
				const float* LastTimeSeconds = Server_LastHitDamageTimes.Find(Other);
				bool bInCooldown = false;
				if (LastTimeSeconds && Now - *LastTimeSeconds < CoolDonwTimeSeconds)
				{
					bInCooldown = true;
				}

				// TODO: Speed check seems not working sometimes, maybe other object is already forced to stop by impact
				if (!bInCooldown && /*!OtherIsMovingAway && */EstimatedTargetSpeed > 100)
				{
					const float MinImpulseSizeForDamage = MyMass * 100;

					// Apply damage on strong impact
					if (ImpulseSize > MinImpulseSizeForDamage)
					{
						const float DamagePerImpulse = MyMass * 20;
 						float Damage = (ImpulseSize - MinImpulseSizeForDamage) / DamagePerImpulse;

						const int32 CurrentHealthPoint = GetP3HealthComponentBP()->GetHealthPoint();

						// Start Hit action
						// If the character is PC, (instead of damage) push back or knock down
						EAnimNotifyAttackStrengthFlags AttackStrength = EAnimNotifyAttackStrengthFlags::Medium;
						if (CurrentHealthPoint < Damage)
						{
							AttackStrength = EAnimNotifyAttackStrengthFlags::Large;
						}

						if (IsPlayerControlled())
						{
							Damage = 0.f;
						}

						P3Combat::FDamageActorParams DamageParams(*Other, *this);
						DamageParams.AttackStrength = AttackStrength;
						DamageParams.AttackDirection = EAnimNotifyAttackDirectionFlags::Push;
						DamageParams.AttackAttribute = EP3AnimNotifyAttackAttribute::Bash;
						DamageParams.TargetComponent = Hit.GetComponent();
						DamageParams.TargetHitItemIndex = Hit.FaceIndex;
						DamageParams.BoneName = Hit.BoneName;
						DamageParams.WeaponType = EP3WeaponType::None;
						DamageParams.TrueDamage = Damage;
						DamageParams.ImpactDirection = (GetActorLocation() - HitLocation).GetSafeNormal();

						P3Combat::Server_DamageActor(DamageParams);

						//bOtherImpulseApplied = true;
						//DrawDebugDirectionalArrow(GetWorld(), Hit.Location, Hit.Location + (Hit.ImpactNormal * 100.0f), 10.0f, FColor::Red, true, 10.0f);

						Server_LastHitDamageTimes.Add(Other, Now);
					}
				}
			}

			const FVector PushedOffsetByImpulse = -NormalImpulse / MyMass * GetWorld()->GetDeltaSeconds();
			const FVector ClampedPushedOffset = PushedOffsetByImpulse.GetClampedToMaxSize(
				-Hit.PenetrationDepth + (NormalSpeed * GetWorld()->GetDeltaSeconds()));

			GetCapsuleComponent()->AddWorldOffset(ClampedPushedOffset, true);

			if (/*!OtherIsMovingAway && */!bOtherImpulseApplied)
			{
				// Let that object not blocked by Capsule Component
				OtherComp->AddImpulse(MassRatio * -NormalImpulse);
			}
		}
	}

	if (Other && ActionComponent && P3Core::IsP3NetModeServerInstance(*this))
	{
		if (!IsKnockDowned() && IsLarge())
		{
			UP3PickupableComponent* PickupableComp = Other->FindComponentByClass<UP3PickupableComponent>();
			if (PickupableComp && PickupableComp->IsTripOverLargeCharacter())
			{
				ActionComponent->StartAction(EPawnActionType::TripOver, _FUNCTION_TEXT, FP3PawnActionStartRequestParams());

				if (OtherComp)
				{
					OtherComp->AddImpulse(-HitNormal.GetSafeNormal2D() * FMath::RandRange(500.0f, 2000.0f), NAME_None, true);
				}
			}
		}

		UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
		if (MovementComp && (MovementComp->IsFlying() || MovementComp->IsFalling() || MovementComp->IsGliding()))
		{
			AP3Character* Character = Cast<AP3Character>(Other);

			if (Character && Character->CharacterStore.bIsBouncingMode)
			{
				const bool bIsFront = (Character->GetActorQuat().GetForwardVector() | HitNormal.GetSafeNormal2D()) > 0.f;
				if (bIsFront)
				{
					FP3PawnActionStartRequestParams Params;
					Params.BouncingJump_Impulse = FVector(0.f, 0.f, 1300.f);
					ActionComponent->StartAction(EPawnActionType::BouncingJump, _FUNCTION_TEXT, Params);
				}
			}
		}
	}
}

bool AP3Character::IsPlayerControlled() const
{
	if (Net_bInitialized)
	{
		return Net_bPlayerControlled;
	}

	return Super::IsPlayerControlled();
}

void AP3Character::OnRep_ReplicatedMovement()
{
	if (CharacterStore.bIsRagdollized)
	{
		// TODO: FIX-ME: During ragdoll, capsule follows ragdoll mesh and this can be quite different from client to server
		// So, we just ignore syncing for now
		return;
	}

	Super::OnRep_ReplicatedMovement();
}

void AP3Character::PostNetReceiveVelocity(const FVector& NewVelocity)
{
	UMovementComponent* MoveComponent = GetMovementComponent();
	if (MoveComponent)
	{
		MoveComponent->Velocity = NewVelocity;
	}
}

void AP3Character::SpawnDefaultController()
{
	// Overriding APawn::SpawnDefaultController, since P3 client is not NM_Client and creates AI controller which we don't want to

	if (Controller != nullptr || !P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (AIControllerClass != nullptr)
	{
		FActorSpawnParameters SpawnInfo;
		SpawnInfo.Instigator = Instigator;
		SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		SpawnInfo.OverrideLevel = GetLevel();
		SpawnInfo.ObjectFlags |= RF_Transient;	// We never want to save AI controllers into a map
		AController* NewController = GetWorld()->SpawnActor<AController>(AIControllerClass, GetActorLocation(), GetActorRotation(), SpawnInfo);
		if (NewController != nullptr)
		{
			// if successful will result in setting this->Controller 
			// as part of possession mechanics
			NewController->Possess(this);
		}
	}
}

FVector AP3Character::ConsumeMovementInputVector()
{
#if FIXME_CHARACTER_MOVEMENT_CLIENT_AUTHORITY
	if (Role == ROLE_SimulatedProxy)
	{
		// Simulated proxy will receive input by NetSerializeMovement
		// and if we continue to ConsumeMovementInputVector, it will be zeroed
		return LastControlInputVector;
	}
#endif

	return Super::ConsumeMovementInputVector();
}

FRotator AP3Character::GetBaseAimRotation() const
{
	if (Controller)
	{
		// In case of Local player and server, we have controller
		return Controller->GetControlRotation();
	}

	// Others, we are using this custom value
	return NetMovement_AimRotator;
}

void AP3Character::SetBase(UPrimitiveComponent* NewBaseComponent, const FName BoneName /*= NAME_None*/, bool bNotifyActor /*= true*/)
{
	const bool bBaseChanged = (NewBaseComponent != BasedMovement.MovementBase);

	Super::SetBase(NewBaseComponent, BoneName, bNotifyActor);

	if (bBaseChanged)
	{
		LastBaseChangedTimeSeconds = GetWorld() ? GetWorld()->GetTimeSeconds() : -1.0f;
	}

	if (bBaseChanged && NewBaseComponent && NewBaseComponent->GetOwner())
	{
		// We need hit event for AP3FallingStepFloorActor::NotifyHit
		NewBaseComponent->GetOwner()->NotifyHit(NewBaseComponent, this, GetCapsuleComponent(), false, GetActorLocation(), GetActorQuat().GetUpVector(), FVector::ZeroVector, FHitResult());
	}
}

void AP3Character::StartAttackByAI()
{
	OnStartAttack();
}

void AP3Character::StopAttackByAI()
{
	OnStopAttack();
}

void AP3Character::NativeAttachWeapon()
{
	if (bWeaponAttached)
	{
		return;
	}

	if (IsMounted())
	{
		return;
	}

	// If support holdable is in left hand, stash it.
	if (bSupportHoldableAttached)
	{
		NativeDetachSupportHoldable();
	}

	ReceiveAttachWeapon();

	UP3HolderComponent* RightHandHolderComp = GetRightHandHolderComponent();
	if (RightHandHolderComp)
	{	
		RightHandHolderComp->Hold();
	}

	bWeaponAttached = true;
}

void AP3Character::NativeAttachShield()
{
	if (bShieldAttached)
	{
		return;
	}

	if (IsMounted())
	{
		return;
	}

	// If the left hand holdable is support holdable, do not hold shield.
	UP3HolderComponent* LeftHandHolderComp = GetLeftHandHolderComponent();
	if (LeftHandHolderComp)
	{
		AP3Weapon* HoldingActor = Cast<AP3Weapon>(LeftHandHolderComp->GetHoldingActor());
		if (HoldingActor && HoldingActor->IsSupportHoldable())
		{
			return;
		}
		else
		{
			LeftHandHolderComp->Hold();
		}
	}

	bShieldAttached = true;
}

void AP3Character::NativeAttachDagger()
{
	if (!CharacterStore.bMountingByRescuer)
	{
		AttachDagger();
	}
}

void AP3Character::NativeAttachSupportHoldable()
{
	if (bSupportHoldableAttached)
	{
		return;
	}

	UP3HolderComponent* LeftHandHolderComp = GetLeftHandHolderComponent();
	if (LeftHandHolderComp)
	{	
		LeftHandHolderComp->Hold();
	}

	bSupportHoldableAttached = true;
}

void AP3Character::NativeAttachElementalCatcher()
{
	AttachElementalCatcher();
}

void AP3Character::NativeDetachWeapon()
{
	if (!bWeaponAttached)
	{
		return;
	}

	UP3HolderComponent* RightHandHolderComp = GetRightHandHolderComponent();
	if (RightHandHolderComp)
	{	
		RightHandHolderComp->Stash();
	}

	bWeaponAttached = false;
}

void AP3Character::NativeDetachShield()
{
	if (!bShieldAttached)
	{
		return;
	}

	UP3HolderComponent* LeftHandHolderComp = GetLeftHandHolderComponent();
	if (LeftHandHolderComp)
	{	
		LeftHandHolderComp->Stash();
	}

	bShieldAttached = false;
}

void AP3Character::NativeDetachDagger()
{
	DetachDagger();
}

void AP3Character::NativeDetachSupportHoldable()
{
	if (!bSupportHoldableAttached)
	{
		return;
	}

	UP3HolderComponent* LeftHandHolderComp = GetLeftHandHolderComponent();
	if (LeftHandHolderComp)
	{	
		LeftHandHolderComp->Stash();
	}

	bSupportHoldableAttached = false;
}

void AP3Character::NativeDetachElementalCatcher()
{
	DetachElementalCatcher();
}

void AP3Character::AddGameplayTags(const FGameplayTagContainer& TagContainer)
{
	AddGameplayTagsBP(TagContainer);
}

void AP3Character::RemoveGameplayTags(const struct FGameplayTagContainer& TagContainer)
{
	RemoveGameplayTagsBP(TagContainer);
}

void AP3Character::AddDebugString(const FString& InDebugString, bool bAddNewLine/* = true*/)
{
	DebugString += InDebugString;

	if (bAddNewLine)
	{
		DebugString += TEXT("\n");
	}
}

bool AP3Character::CanBeSeenFrom(const FVector& ObserverLocation, FVector& OutSeenLocation, int32& NumberOfLoSChecksPerformed, float& OutSightStrength, const AActor* IgnoreActor /*= NULL*/) const
{
	static const FName NAME_AILineOfSight = FName(TEXT("TestPawnLineOfSight"));

	if (!GetRootComponent())
	{
		return false;
	}

	// See body, head, feet
	const TArray<FVector> PerceptibleLocations = {
		GetActorLocation(),
		GetActorLocation()+((GetRootComponent()->GetUpVector())*(GetSimpleCollisionHalfHeight()-GetSimpleCollisionRadius())),
		GetActorLocation()-((GetRootComponent()->GetUpVector())*(GetSimpleCollisionHalfHeight()-GetSimpleCollisionRadius())),
	};

	FHitResult HitResult;

	for (int i = 0; i < PerceptibleLocations.Num(); i++)
	{
		const bool bHit = GetWorld()->LineTraceSingleByObjectType(HitResult, ObserverLocation, PerceptibleLocations[i]
			, FCollisionObjectQueryParams(ECC_TO_BITFIELD(ECC_WorldStatic) | ECC_TO_BITFIELD(ECC_WorldDynamic))
			, FCollisionQueryParams(NAME_AILineOfSight, true, IgnoreActor));

		NumberOfLoSChecksPerformed++;

		if (bHit == false || (HitResult.Actor.IsValid() && HitResult.Actor->IsOwnedBy(this))) {
			OutSeenLocation = PerceptibleLocations[i];
			OutSightStrength = 1;

			return true;
		}
	}

	OutSightStrength = 0;
	return false;
}

int32 AP3Character::StartMontageAction(const FName& MontageActionName)
{
	if (!ActionComponent)
	{
		return 0;
	}

	FP3PawnActionStartRequestParams Params;
	Params.CharacterMontage_Name = MontageActionName;

	const int32 RequestId = ActionComponent->StartAction(EPawnActionType::CharacterMontage, _FUNCTION_TEXT, Params);

	return RequestId;
}

void AP3Character::SetAIPerceptionComponent(UP3AIPerceptionComponent* AIPerceptionComponentBP)
{
	AIPerceptionComponent = AIPerceptionComponentBP;
}

//////////////////////////////////////////////////////////////////////////
// Input

void AP3Character::SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent)
{
	// Set up gameplay key bindings
	check(PlayerInputComponent);

	// Combination
	PlayerInputComponent->BindAction("LeftTrigger", IE_Pressed, this, &AP3Character::OnPressLeftTrigger);
	PlayerInputComponent->BindAction("LeftTrigger", IE_Released, this, &AP3Character::OnReleaseLeftTrigger);
	PlayerInputComponent->BindAction("RightTrigger", IE_Pressed, this, &AP3Character::OnPressRightTrigger);
	PlayerInputComponent->BindAction("RightTrigger", IE_Released, this, &AP3Character::OnReleaseRightTrigger);

	// UI
	PlayerInputComponent->BindAction("ToggleCursorMode", IE_Released, this, &AP3Character::OnToggleCursorMode);
	PlayerInputComponent->BindAction("ToggleCrossHairMode", IE_Released, this, &AP3Character::OnToggleCrossHairMode);
	PlayerInputComponent->BindAction("AimAssist", IE_Pressed, this, &AP3Character::OnAimAssistPressed);
	PlayerInputComponent->BindAction("AimAssist", IE_Released, this, &AP3Character::OnAimAssistReleased);
	//PlayerInputComponent->BindAction("Inventory", IE_Pressed, this, &AP3Character::OnShowInventory);
	//PlayerInputComponent->BindAction("Consumable", IE_Pressed, this, &AP3Character::OnToggleConsumableUI);
	//PlayerInputComponent->BindAction("ConsumableNext", IE_Pressed, this, &AP3Character::OnNextConsumable);
	//PlayerInputComponent->BindAction("ConsumablePrev", IE_Pressed, this, &AP3Character::OnPrevConsumable);
	PlayerInputComponent->BindAction("OpenChat", IE_Pressed, this, &AP3Character::OnOpenChatPressed);
	PlayerInputComponent->BindAction("Home", IE_Pressed, this, &AP3Character::OnToggleMainMenuUI);

	// Camera
	PlayerInputComponent->BindAxis("CameraZoom", this, &AP3Character::OnCameraZoom);
	PlayerInputComponent->BindAction("ToggleCameraZoom", IE_Released, this, &AP3Character::OnToggleCameraZoom);
	PlayerInputComponent->BindAction("LockOn", IE_Pressed, this, &AP3Character::OnLockOnPressed);
	PlayerInputComponent->BindAction("LockOn", IE_Released, this, &AP3Character::OnLockOnReleased);
	PlayerInputComponent->BindAction("LockOnNext", IE_Pressed, this, &AP3Character::OnNextLockOn);
	PlayerInputComponent->BindAction("LockOnPrev", IE_Pressed, this, &AP3Character::OnPrevLockOn);
	PlayerInputComponent->BindAction("LookAssist", IE_Pressed, this, &AP3Character::OnLookAssist);

	// Common Action
	PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AP3Character::OnStartJump);
	PlayerInputComponent->BindAction("Jump", IE_Released, this, &AP3Character::OnStopJump);
	PlayerInputComponent->BindAction("Evade", IE_Pressed, this, &AP3Character::OnStartEvade);
	PlayerInputComponent->BindAction("Evade", IE_Released, this, &AP3Character::OnStopEvade);
	PlayerInputComponent->BindAction("Sprint", IE_Pressed, this, &AP3Character::OnStartSprint);
	PlayerInputComponent->BindAction("Sprint", IE_Released, this, &AP3Character::OnStopSprint);
	PlayerInputComponent->BindAction("Throw", IE_Pressed, this, &AP3Character::OnThrowPressed);
	PlayerInputComponent->BindAction("Throw", IE_Released, this, &AP3Character::OnThrowReleased);
	
	// Weapon Action	
	PlayerInputComponent->BindAction("Weapon_Normal_Attack", IE_Pressed, this, &AP3Character::OnWeaponNormalAttackPressed);
	PlayerInputComponent->BindAction("Weapon_Normal_Attack", IE_Released, this, &AP3Character::OnWeaponNormalAttackReleased);
	PlayerInputComponent->BindAction("Weapon_Special_Attack", IE_Pressed, this, &AP3Character::OnWeaponSpecialAttackPressed);
	PlayerInputComponent->BindAction("Weapon_Special_Attack", IE_Released, this, &AP3Character::OnWeaponSpecialAttackReleased);
	PlayerInputComponent->BindAction("Weapon_Class_Attack", IE_Pressed, this, &AP3Character::OnWeaponClassAttackPressed);
	PlayerInputComponent->BindAction("Weapon_Class_Attack", IE_Released, this, &AP3Character::OnWeaponClassAttackReleased);
	PlayerInputComponent->BindAction("Weapon_Private_Action", IE_Pressed, this, &AP3Character::OnWeaponPrivateActionPressed);
	PlayerInputComponent->BindAction("Weapon_Private_Action", IE_Released, this, &AP3Character::OnWeaponPrivateActionReleased);
		
	// Debugging or development
	PlayerInputComponent->BindAction("ChangeWeapon", IE_Pressed, this, &AP3Character::OnStartChangeWeapon);
	PlayerInputComponent->BindAction("ChangeWeapon", IE_Released, this, &AP3Character::OnStopChangeWeapon);
	PlayerInputComponent->BindAction("MobilePart", IE_Pressed, this, &AP3Character::OnStartMobilePart);
	PlayerInputComponent->BindAction("MobilePart", IE_Released, this, &AP3Character::OnStopMobilePart);		
	PlayerInputComponent->BindAction("ConnectDedi", IE_Pressed, this, &AP3Character::OnConnectDediPressed);
	PlayerInputComponent->BindAction("GodMode", IE_Pressed, this, &AP3Character::OnToggleGodMode);
	PlayerInputComponent->BindAction("PutDownHoldable", IE_Pressed, this, &AP3Character::OnStartPutDownHoldable);
	PlayerInputComponent->BindAction("PutDownHoldable", IE_Released, this, &AP3Character::OnStopPutDownHoldable);


	// We have 2 versions of the rotation bindings to handle different kinds of devices differently
	// "turn" handles devices that provide an absolute delta, such as a mouse.
	// "turnrate" is for devices that we choose to treat as a rate of change, such as an analog joystick
	PlayerInputComponent->BindAxis("MoveForward", this, &AP3Character::MoveForward);
	PlayerInputComponent->BindAxis("MoveRight", this, &AP3Character::MoveRight);
	PlayerInputComponent->BindAxis("LookRight", this, &AP3Character::LookRight);
	PlayerInputComponent->BindAxis("LookRightRate", this, &AP3Character::LookRightRate);
	PlayerInputComponent->BindAxis("LookUp", this, &AP3Character::LookUp);
	PlayerInputComponent->BindAxis("LookUpRate", this, &AP3Character::LookUpAtRate);
	PlayerInputComponent->BindAction("LookForward", IE_Released, this, &AP3Character::OnLookForward);

	// handle touch devices
	PlayerInputComponent->BindTouch(IE_Pressed, this, &AP3Character::TouchStarted);
	PlayerInputComponent->BindTouch(IE_Released, this, &AP3Character::TouchStopped);

	// VR headset functionality
	PlayerInputComponent->BindAction("ResetVR", IE_Pressed, this, &AP3Character::OnResetVR);	
}

void AP3Character::SetBreathParticleComponent(UParticleSystemComponent* InBreathParticleComponent)
{
	BreathParticleComponent = InBreathParticleComponent;
}

bool AP3Character::CanJumpInternal_Implementation() const
{
	if (IsDeadOrDowned())
	{
		return false;
	}

	if (IsRescuing())
	{
		return false;
	}

	if (ActionComponent && (ActionComponent->IsIgnoreMoveInput() || !ActionComponent->CanStartJump()))
	{
		return false;
	}

	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (!MovementComp)
	{
		return false;
	}

	// Ensure the character isn't currently crouched.
	bool bCanJump = !bIsCrouched;

	// Ensure that the CharacterMovement state is valid
	bCanJump &= MovementComp->IsJumpAllowed() &&
				!MovementComp->bWantsToCrouch &&
				!MovementComp->IsSliding() &&
				// Can only jump from the ground, or multi-jump if already falling, or climbing
				(MovementComp->IsMovingOnGround() || (MovementComp->IsFalling() && CanGlide()) || MovementComp->IsClimbing() || MovementComp->IsGliding());

	if (bCanJump
		&& EffectComponent
		&& (EffectComponent->HasEffect(EP3CharacterEffectTypes::Entangle)
			|| EffectComponent->HasEffect(EP3CharacterEffectTypes::RoarStun)
			|| EffectComponent->HasEffect(EP3CharacterEffectTypes::Stun)))
	{
		bCanJump = false;
	}

	if (bCanJump)
	{
		// Ensure JumpHoldTime and JumpCount are valid.
		if (GetJumpMaxHoldTime() <= 0.0f || !bWasJumping)
		{
			if (JumpCurrentCount == 0 && MovementComp->IsFalling())
			{
				bCanJump = JumpMaxCount > 1;
			}
			else
			{
				bCanJump = JumpCurrentCount < JumpMaxCount;
			}
		}
		else
		{
			ensure(bWasJumping);

			// Only consider IsJumpProviding force as long as:
			// A) The jump limit hasn't been met OR
			// B) The jump limit has been met AND we were already jumping
			bCanJump = (IsJumpProvidingForce()) &&
						(JumpCurrentCount < JumpMaxCount ||
						(JumpCurrentCount == JumpMaxCount));
		}
	}

	return bCanJump;
}

void AP3Character::OnToggleCursorMode()
{
	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());

	if (!PlayerController)
	{
		return;
	}

	PlayerController->SetCursorMode(!PlayerController->IsCursorMode());
}

void AP3Character::OnToggleCrossHairMode()
{
	if (CVarP3EnableCorssHairMode.GetValueOnGameThread() == 0)
	{
		return;
	}

	if (IsDeadOrDowned())
	{
		return;
	}

	//OnInputToggleCrossHairMode.Broadcast();

	if (CommandComponent)
	{
		FP3CommandRequestParams Params;
		Params.SetMeleeAiming_bNewAiming = !GetCharacterStoreBP().bIsMeleeAiming;
		CommandComponent->RequestCommand(UP3SetMeleeAimingCommand::StaticClass(), Params);
	}
}

void AP3Character::OnPressLeftTrigger()
{
	bLeftTriggerPressed = true;
}

void AP3Character::OnReleaseLeftTrigger()
{
	bLeftTriggerPressed = false;
}

void AP3Character::OnPressRightTrigger()
{
	bRightTriggerPressed = true;
}

void AP3Character::OnReleaseRightTrigger()
{
	bRightTriggerPressed = false;
}

void AP3Character::OnStartJump()
{
	if (IsDeadOrDowned())
	{
		return;
	}

	if (CharacterStore.MountTargetCharacter != nullptr && CommandComponent)
	{
		FP3CommandRequestParams CommandParams;
		CommandParams.Mount_Detach = true;
		CommandParams.Mount_DeatchWithEjection = true;
		CommandComponent->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
		return;
	}

	bool bCanJump = true;

	if (ComboTableComponent)
	{
		bCanJump = ComboTableComponent->CanJump();
	}

	if (bRightTriggerPressed)
	{
		OnStartEvade();
	}
	else if(bCanJump)
	{
		Jump();
	}

	OnInputPressJumpButton.Broadcast();
}

void AP3Character::OnStopJump()
{			
	StopJumping();
		
	OnInputReleaseJumpButton.Broadcast();
}

void AP3Character::OnStartEvade()
{
	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (ActionComponent && !GetMovementComponent()->IsFalling() && CanCombat())
	{ 		
		if (ComboTableComponent && ComboTableComponent->IsNotifyStateSignalEnabled(TEXT("Evade")))
		{		
			FP3PawnActionStartRequestParams Params;
			Params.Roll_Rotator = ComboTableComponent->GetControlRotation();
			Params.Roll_Direction = Params.Roll_Rotator.Vector();
			Params.Roll_CharacterForwardVector = GetActorForwardVector();

			ActionComponent->StartAction(EPawnActionType::CombatRoll, _FUNCTION_TEXT, Params);
		}
	}

	OnInputPressEvadeButton.Broadcast();
}

void AP3Character::OnStopEvade()
{
	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	OnInputReleaseEvadeButton.Broadcast();
}

void AP3Character::OnStartAttack()
{
	LocalControl_CloseConsumableUI();

	if (!CanAttack() || IsDeadOrDowned())
	{
		return;
	}

	const EP3WeaponType WeaponType = GetRightHandWeaponType();

	if (IsRangedWeapon(WeaponType))
	{
		// See if we have harpoon that already launched
		AP3Weapon* GunWeapon = Cast<AP3Weapon>(GetRightHandWeaponActor());
		if (ensure(GunWeapon) && GunWeapon->GetLastFiredProjectile())
		{
			AP3Projectile* Projectile = GunWeapon->GetLastFiredProjectile();
			if (Projectile && !Projectile->IsActorBeingDestroyed() && Projectile->IsHarpoon())
			{
				FP3PawnActionStartRequestParams Params;
				ActionComponent->StartAction(EPawnActionType::PullHarpoon, _FUNCTION_TEXT, Params);
				return;
			}
		}
	}

	if (CharacterStore.ThrownWeapon.IsValid() && CharacterStore.ThrownWeaponHoldType != EP3HoldType::Count)
	{
		UP3HolderComponent* HolderComp = GetHolderComponentByHoldType(CharacterStore.ThrownWeaponHoldType);
		if (HolderComp)
		{
			const bool bThrownWeaponIsFree = !CharacterStore.ThrownWeapon->GetAttachParentActor();
			const bool bMyHandIsFree = !HolderComp->GetHoldingActor();

			if (bThrownWeaponIsFree && bMyHandIsFree)
			{
				FP3PawnActionStartRequestParams Params;
				Params.RecallThrownWeapon_WeaponItem = CharacterStore.ThrownWeaponItem;
				Params.RecallThrownWeapon_WeaponActor = CharacterStore.ThrownWeapon.Get();
				Params.RecallThrownWeapon_HoldType = CharacterStore.ThrownWeaponHoldType;
				ActionComponent->StartAction(EPawnActionType::RecallThrownWeapon, _FUNCTION_TEXT, Params);
				return;
			}
		}
	}

	OnInputStartAttack.Broadcast();
}

void AP3Character::OnStopAttack()
{
	if (IsDeadOrDowned())
	{
		return;
	}

	OnInputStopAttack.Broadcast();
}

void AP3Character::OnStartSprint()
{
	if (IsMounted())
	{
		if (CommandComponent)
		{
			FP3CommandRequestParams Params;
			Params.BuckingEndure_bNewEndure = true;
			CommandComponent->RequestCommand(UP3BuckingEndureCommand::StaticClass(), Params);
		}
	}
	else
	{
		OnInputStartSprint.Broadcast();

		if (IsPlayerControlled() && CVarP3AutoPutAwayBySprint.GetValueOnGameThread() > 0)
		{
			if (GetStance() == EP3CharacterStance::Combat && CombatComponent)
			{
				CombatComponent->PutAwayWeapon();
			}
		}

		StartSpirntTimeSeconds = GetWorld()->GetTimeSeconds();
	}
}

void AP3Character::OnStopSprint()
{
	if (IsMounted())
	{
		if (CommandComponent)
		{
			FP3CommandRequestParams Params;
			Params.BuckingEndure_bNewEndure = false;
			CommandComponent->RequestCommand(UP3BuckingEndureCommand::StaticClass(), Params);
		}
	}
	else
	{
		OnInputStopSprint.Broadcast();

		if (IsPlayerControlled() && CVarP3AutoPutAwayBySprint.GetValueOnGameThread() == 0)
		{
			if (GetStance() == EP3CharacterStance::Combat && CombatComponent)
			{
				float SprintTimeSeconds = GetWorld()->GetTimeSeconds() - StartSpirntTimeSeconds;
				if (SprintTimeSeconds <= CVarP3PutAwayTimeBySprint.GetValueOnAnyThread())
				{
					CombatComponent->PutAwayWeapon();
				}
			}
		}
	}
}

void AP3Character::OnStartInteract()
{
	if (IsAutonomousProxy(this) || IsAuthority(this))
	{
		// Pickup
		UP3PickupComponent* PickupComp = PickupComponent;
		if (PickupComp && PickupComp->GetPickupCandidateActor())
		{
			PickupComp->Pickup();
			return;
		}

		// Put down Pickupable
		if (PickupComp && PickupComp->CanPutDown())
		{
			PickupComp->Putdown();
			return;
		}

		// Climb Down
		UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
		if (MovementComp && MovementComp->IsClimbDownAvailable())
		{
			if (ensure(ActionComponent))
			{
				ActionComponent->StartAction(EPawnActionType::ClimbDown, _FUNCTION_TEXT);
			}
			return;
		}
	}
}

void AP3Character::OnStopInteract()
{

}

void AP3Character::OnAimAssistPressed()
{
	if (!ensure(IsLocalControlledActor(this)))
	{
		return;
	}

	if (IsRangedWeapon(GetRightHandWeaponType()) && CharacterStore.bIsAiming)
	{
		if (CombatComponent)
		{
			CombatComponent->LocalControl_SetAssistAim(true);
		}
	}
}

void AP3Character::OnAimAssistReleased()
{
	if (!ensure(IsLocalControlledActor(this)))
	{
		return;
	}

	if (CombatComponent)
	{
		CombatComponent->LocalControl_SetAssistAim(false);
	}
}

void AP3Character::OnThrowPressed()
{
	if (!ensure(IsLocalControlledActor(this)))
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}
	else
	{
		if (PickupComponent && PickupComponent->CanThrow())
		{
			PickupComponent->AimThrow();
		}
	}

	//else if (CanThrowWeaponBP())
	//{
	//	if (!CharacterStore.bIsAiming)
	//	{
	//		FP3CommandRequestParams Params;
	//		Params.SetRangedAiming_bNewAiming = true;
	//		GetCommandComponent()->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), Params);
	//	}
	//}
}

void AP3Character::OnThrowReleased()
{
	if (!ensure(IsLocalControlledActor(this)))
	{
		return;
	}


	if (CanThrowConsumable())
	{
		// ConsumableUI가 항상 열려있게 바뀌었고 Consumable Throw 인풋을 UI가 직접 관리하고 있으므로 필요없게 됨. 
		/*OnInputThrowConsumable.Broadcast();

		LocalControl_bConsumableUIOpened = false;
		LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;
		return;*/
	}
	else if (PickupComponent && PickupComponent->CanThrow())
	{
		PickupComponent->Throw();
	}

	//else if (CanThrowWeaponBP() && CharacterStore.bIsAiming)
	//{
	//	FP3CommandRequestParams Params;
	//	Params.SetRangedAiming_bNewAiming = false;
	//	GetCommandComponent()->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), Params);
	//}
}

void AP3Character::OnStartBlock()
{
	LocalControl_CloseConsumableUI();

	if (ComboTableComponent && ComboTableComponent->IsComboEnabled())
	{
		return;		
	}

	const EP3WeaponType WeaponType = GetRightHandWeaponType();

	if (CVarP3RangeWeaponAimMode.GetValueOnGameThread() == 0)
	{
		if (IsRangedWeapon(WeaponType) && ActionComponent)
		{
			FP3CommandRequestParams Params;
			Params.SetRangedAiming_bNewAiming = !CharacterStore.bIsAiming;
			GetCommandComponent()->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), Params);
			return;
		}
	}
	
	if (IsRangedWeapon(WeaponType) && GetStance() == EP3CharacterStance::Combat)
	{
		LocalControl_RangeZoomMode = true;
	}
	else
	{
		if (ActionComponent)
		{
			ActionComponent->StartAction(EPawnActionType::StartBlock, _FUNCTION_TEXT);
		}
	}
}

void AP3Character::OnStopBlock()
{
	if (ComboTableComponent && ComboTableComponent->IsComboEnabled())
	{
		return;
	}

	if (LocalControl_RangeZoomMode && IsRangedWeapon(GetRightHandWeaponType()))
	{
		LocalControl_RangeZoomMode = false;
	}
	else if (ActionComponent && CharacterStore.bIsBlocking)
	{
		ActionComponent->StartAction(EPawnActionType::StopBlock, _FUNCTION_TEXT);
	}
}

void AP3Character::OnStartChangeWeapon()
{
	if (IsMounted())
	{
		return;
	}

	if (IsTempWeapon(GetRightHandWeaponType()))
	{
		HoldingKeyStatus.StartHolding(EHoldingKeyInputType::PutdownHoldable);
	}
}

void AP3Character::OnStopChangeWeapon()
{
	if (!ensure(IsLocalControlledActor(this)))
	{
		return;
	}

	if (IsMounted())
	{
		return;
	}

	if (HoldingKeyStatus.bIsHolding && HoldingKeyStatus.InputType == EHoldingKeyInputType::PutdownHoldable)
	{
		HoldingKeyStatus.bIsHolding = false;

		if (HoldingKeyStatus.HoldingAgeSeconds > CVarP3HoldingKeyMinDurationSeconds.GetValueOnGameThread())
		{
			return;
		}
	}

	// Currently, this action is shared with consumable ui. Will be replaced
	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}

	// [7/26/2019 mrhwang] Comment-out: No you don't. We need temp weapon.
	//// If is a temp weapon, put it down
	//if (IsTempWeapon(GetRightHandWeaponType()))
	//{
	//	OnStopPutDownHoldable();
	//	return;
	//}

	if (!ensure(InventoryComponent) || !ensure(ActionComponent))
	{
		return;
	}
	
	UP3HolderComponent* RightHandHolderComp = nullptr;
	UP3HolderComponent* LeftHandHolderComp = nullptr;

	TInlineComponentArray<UP3HolderComponent*> HolderComps;
	GetComponents(HolderComps);

	for (UP3HolderComponent* HolderComp : HolderComps)
	{
		if (HolderComp->GetHoldType() == EP3HoldType::RightHand)
		{
			RightHandHolderComp = HolderComp;		
		}
		else
		if (HolderComp->GetHoldType() == EP3HoldType::LeftHand)
		{
			LeftHandHolderComp = HolderComp;
		}
	}

	FP3PawnActionStartRequestParams Params;
	EP3WeaponType NewRightWeaponType = EP3WeaponType::None;

	const FP3Item NewRightHandWeaponItem = InventoryComponent->FindHoldableItem(EP3HoldType::RightHand);
	if (RightHandHolderComp && NewRightHandWeaponItem.Id != INVALID_ITEMID)
	{			
		Params.ChangeHoldable_RightHoldType = RightHandHolderComp->GetHoldType();
		Params.ChangeHoldable_InvenToRightHolderItemId = NewRightHandWeaponItem.Id;
		Params.ChangeHoldable_HolderToRightInvenItem = InventoryComponent->GetItemBySlot(EP3CharacterItemSlot::RightHand);

		const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(NewRightHandWeaponItem.Key);
		if (CmsHoldable)
		{
			NewRightWeaponType = CmsHoldable->WeaponType;
		}
	}

	const FP3Item NewLeftHandWeaponItem = InventoryComponent->FindHoldableItem(EP3HoldType::LeftHand, NewRightWeaponType);
	if (LeftHandHolderComp)
	{
		Params.ChangeHoldable_LeftHoldType = LeftHandHolderComp->GetHoldType();
		Params.ChangeHoldable_InvenToLeftHolderItemId = NewLeftHandWeaponItem.Id;
		Params.ChangeHoldable_HolderToLeftInvenItem = InventoryComponent->GetItemBySlot(EP3CharacterItemSlot::LeftHand);
	}

	if (Params.ChangeHoldable_InvenToRightHolderItemId != INVALID_ITEMID)
	{
		ActionComponent->StartAction(EPawnActionType::ChangeHoldable, _FUNCTION_TEXT, Params);
	}	
}

void AP3Character::OnStartPutDownHoldable()
{
	if (PickupComponent && PickupComponent->CanPutDownHoldable())
	{
		HoldingKeyStatus.StartHolding(EHoldingKeyInputType::PutdownHoldable);
	}
}

void AP3Character::OnStopPutDownHoldable()
{
	if (HoldingKeyStatus.bIsHolding && HoldingKeyStatus.InputType == EHoldingKeyInputType::PutdownHoldable)
	{
		HoldingKeyStatus.bIsHolding = false;
		HoldingKeyStatus.HoldingAgeSeconds = 0;
	}
}

void AP3Character::OnResetVR()
{
	UHeadMountedDisplayFunctionLibrary::ResetOrientationAndPosition();
}

void AP3Character::OnToggleGodMode()
{
	FP3CommandRequestParams Params;
	Params.SetGodMode_bNewGodMode = !CharacterStore.bGodMode;
	Params.SetGodMode_bNewNoTargetMode = CharacterStore.bNoTargetMode;
	GetCommandComponent()->RequestCommand(UP3SetGodModeCommand::StaticClass(), Params);
}

void AP3Character::TouchStarted(ETouchIndex::Type FingerIndex, FVector Location)
{
	Jump();
}

void AP3Character::TouchStopped(ETouchIndex::Type FingerIndex, FVector Location)
{
	StopJumping();
}

void AP3Character::Server_AttachFlag(UClass* ActorClass)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(ActorClass))
	{
		return;
	}

	if (CharacterStore.FlagActor)
	{
		Server_DetachFlag();
	}

	ensure(!CharacterStore.FlagActor);

	FActorSpawnParameters SpawnParams;
	SpawnParams.Instigator = this;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AActor* SpawnedActor = GetWorld()->SpawnActor<AActor>(ActorClass, SpawnParams);

	if (ensure(SpawnedActor))
	{
		SpawnedActor->AttachToComponent(GetMesh(), FAttachmentTransformRules::KeepRelativeTransform, FlagAttachSocketName);

		CharacterStore.FlagActor = SpawnedActor;
	}

	Server_SetDirty(*this);
}

void AP3Character::Server_DetachFlag()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!CharacterStore.FlagActor)
	{
		return;
	}

	CharacterStore.FlagActor->Destroy();
	CharacterStore.FlagActor = nullptr;

	Server_SetDirty(*this);
}

void AP3Character::LookRight(float Rate)
{
	if (!ComboTableComponent || ComboTableComponent->CanCameraMove())
	{
		AddControllerYawInput(Rate);
	}

	if (Rate != 0.f)
	{
		OnInputMoveLook.Broadcast(Rate);
	}
}

void AP3Character::LookRightRate(float Rate)
{
	UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());
	if (UserSettings)
	{
		if (CharacterStore.bIsAiming)
		{
			Rate *= UserSettings->GetPadAimCameraSensitivity();
		}
		else
		{
			Rate *= UserSettings->GetPadCameraSensitivity();
		}
	}

	if (!ComboTableComponent || ComboTableComponent->CanCameraMove())
	{
		// calculate delta for this frame from the rate information
		AddControllerYawInput(Rate * BaseLookRightRate * GetWorld()->GetDeltaSeconds());
	}

	if (Rate != 0.f)
	{
		OnInputMoveLook.Broadcast(Rate);
	}
}

void AP3Character::LookUp(float Rate)
{
	if (!ComboTableComponent || ComboTableComponent->CanCameraMove())
	{
		AddControllerPitchInput(Rate);
	}

	if (Rate != 0.f)
	{
		OnInputMoveLook.Broadcast(Rate);
	}
}

void AP3Character::LookUpAtRate(float Rate)
{
	UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());
	if (UserSettings)
	{
		if (CharacterStore.bIsAiming)
		{
			Rate *= UserSettings->GetPadAimCameraSensitivity();
		}
		else
		{
			Rate *= UserSettings->GetPadCameraSensitivity();
		}
	}

	if (!ComboTableComponent || ComboTableComponent->CanCameraMove())
	{
		// calculate delta for this frame from the rate information
		AddControllerPitchInput(Rate * BaseLookUpRate * GetWorld()->GetDeltaSeconds());
	}

	if (Rate != 0.f)
	{
		OnInputMoveLook.Broadcast(Rate);
	}
}

void AP3Character::OnLookForward()
{
	if (bLeftTriggerPressed)
	{
		OnToggleCameraZoom();
		return;
	}

	AP3PlayerController* MyController = Cast<AP3PlayerController>(GetController());

	if (MyController)
	{
		MyController->LookForward(GetActorRotation());
	}
}

void AP3Character::MoveForward(float Value)
{
	if (!LocalControl_bMainMenuUIOpened)
	{
		if (Value != 0.0f)
		{
			if (!ComboTableComponent || ComboTableComponent->CanMove())
			{
				Move2D(FVector2D(Value, 0));
			}
		}

		OnInputMoveForward.Broadcast(Value);
	}
}

void AP3Character::MoveRight(float Value)
{
	if (!LocalControl_bMainMenuUIOpened)
	{
		if (Value != 0.0f)
		{
			if (!ComboTableComponent || ComboTableComponent->CanMove())
			{
				Move2D(FVector2D(0, Value));
			}
		}

		OnInputMoveRight.Broadcast(Value);
	}
}

void AP3Character::Move2D(const FVector2D& Movement)
{
	if (Controller != NULL)
	{
		const bool bIsSwimming = GetCharacterMovement() && GetCharacterMovement()->IsSwimming();
		const bool bIsClimbing = GetP3CharacterMovementBP() && GetP3CharacterMovementBP()->IsClimbing();

		FRotator Rotation = bIsClimbing ? GetActorRotation() : Controller->GetControlRotation();

		if (!bIsSwimming)
		{
			Rotation = FRotator(0, Rotation.Yaw, 0);
		}

		if (Movement.X != 0.0f)	// -V550
		{
			const FVector Direction = FRotationMatrix(Rotation).GetUnitAxis(EAxis::X);
			AddMovementInput(Direction, Movement.X);
		}

		if (Movement.Y != 0.0f) // -V550
		{
			const FVector Direction = FRotationMatrix(Rotation).GetUnitAxis(EAxis::Y);
			AddMovementInput(Direction, Movement.Y);
		}
	}
}

void AP3Character::OnCameraZoom(float Value)
{
	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetController());
	if (!PlayerController)
	{
		return;
	}

	if (Value != 0.0f)	// -V550
	{
		const int32 ZoomDirection = (PlayerController->IsInvertCameraZoomDirection()) ? -1 : 1;
		Value *= ZoomDirection;

		const float Multiplier = (Value >= 0) ? 1.0f / (1.0f + (Value * 0.1f)) : 1.0f + (-Value * 0.1f);

		LocalControl_CameraBoomTargetArmLength *= Multiplier;
		LocalControl_CameraBoomTargetArmLength = FMath::Clamp(LocalControl_CameraBoomTargetArmLength, CameraMinDistance, CameraMaxDistance);
	}
}

void AP3Character::SetCameraBoomDistance(float Distance)
{
	if (!CameraBoom)
	{
		return;
	}

	CameraBoom->TargetArmLength = FMath::Clamp(Distance, CameraMinDistance, CameraMaxDistance);

	//const float DistanceRatio = (CameraBoom->TargetArmLength - CameraMinDistance) / (CameraMaxDistance - CameraMinDistance);
	//const FVector CameraPivotAtCloseUp(0, 0, 50);
	//const FVector CameraPivotAtWide(0, 0, 0);
	//const FVector CameraPivot = FMath::Lerp(CameraPivotAtCloseUp, CameraPivotAtWide, DistanceRatio);

	//CameraBoom->SetRelativeLocation(CameraPivot);
}

void AP3Character::TickMeshUpdateFlags()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (GetMesh())
		{
			GetMesh()->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPoseAndRefreshBones;
		}
	}
}

void AP3Character::TickCharacterDebug()
{
	const int32 DebugLevel = CVarP3CharacterDebug.GetValueOnGameThread();
	if (DebugLevel == 0)
	{
		return;
	}

	AddDebugString(FString::Printf(TEXT("ActorId: %d"), ActorId));
	AddDebugString(FString::Printf(TEXT("Name: %s"), *GetName()));

	if (CharacterStore.bNoTargetMode)
	{
		AddDebugString(TEXT("NoTarget"));
	}
}

void AP3Character::TickItemDebug()
{
	const int32 DebugLevel = CVarP3ItemDebug.GetValueOnGameThread();
	if (DebugLevel == 0)
	{
		return;
	}

	UP3InventoryComponent* InvenComp = GetInventoryComponentBP();
	if (!InvenComp)
	{
		return;
	}

	const TArray<FP3CharacterItem>& CharacterItems = InvenComp->GetCharacterItems();

	AddDebugString(TEXT("Holder"));
	for (int32 Index = 0; Index < CharacterItems.Num(); ++Index)
	{
		const FP3CharacterItem& CharacterItem = CharacterItems[Index];
		if (CharacterItem.Slot == EP3CharacterItemSlot::Inventory)
		{
			continue;
		}

		const FString SlotName = EnumToStringShort(EP3CharacterItemSlot, CharacterItem.Slot);
		const FP3CmsItem& CmsItem = P3Cms::GetItem(CharacterItem.Item.Key);
		FString ActorName = "<no-holder>";
		const TCHAR* HoldStatus = TEXT("<no-holder>");

		const UP3HolderComponent* HolderComp = GetHolderComponentByHoldType(FP3ItemUtil::GetHoldTypeFromCharacterItemSlot(CharacterItem.Slot));
		if (HolderComp)
		{
			ActorName = HolderComp->GetHoldingActor() ? HolderComp->GetHoldingActor()->GetName() : FString("<none>");
			HoldStatus = HolderComp->IsHold() ? TEXT("Hold") : TEXT("Stash");
		}

		AddDebugString(FString::Printf(TEXT("   %s: Id(%s) Key(%d) Stack(%d) Name(%s) Actor(%s) %s"),
			*SlotName, *CharacterItem.Item.Id.ToString(), CharacterItem.Item.Key, CharacterItem.Item.Stack,
			*CmsItem.DisplayName.ToString(), *ActorName, HoldStatus));
	}

	AddDebugString(TEXT("Inventory"));
	for (int32 Index = 0; Index < CharacterItems.Num(); ++Index)
	{
		const FP3CharacterItem& CharacterItem = CharacterItems[Index];
		if (CharacterItem.Slot != EP3CharacterItemSlot::Inventory)
		{
			continue;
		}

		const FP3CmsItem& CmsItem = P3Cms::GetItem(CharacterItem.Item.Key);
		const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(CharacterItem.Item.Key);

		if (DebugLevel == 2)
		{
			if (CmsHoldable)
			{
				const FString WeaponType = EnumToStringShort(EP3WeaponType, CmsHoldable->WeaponType);
				TArray<FString> HoldTypes;
				for (EP3HoldType HoldType : CmsHoldable->HoldTypes)
				{
					HoldTypes.Add(EnumToStringShort(EP3HoldType, HoldType));
				}

				AddDebugString(FString::Printf(TEXT("   %d: Id(%s) Key(%d) Stack(%d) Name(%s), Weapon(%s), Hold(%s)"),
					Index, *CharacterItem.Item.Id.ToString(), CharacterItem.Item.Key, CharacterItem.Item.Stack, *CmsItem.DisplayName.ToString(),
					*WeaponType, *FString::Join(HoldTypes, TEXT(", "))));
			}
		}
		else
		{
			AddDebugString(FString::Printf(TEXT("   %d: Id(%s) Key(%d) Stack(%d) Name(%s)"),
				Index, *CharacterItem.Item.Id.ToString(), CharacterItem.Item.Key, CharacterItem.Item.Stack, *CmsItem.DisplayName.ToString()));
		}
	}
}

void AP3Character::TickAIDebug()
{
	const int32 DebugLevel = CVarP3AIDebug.GetValueOnGameThread();
	FString NewAIDebugString;

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (DebugLevel != 0)
		{
			AAIController* AIController = Cast<AAIController>(GetController());

			if (AIController)
			{
				// Update AIDebugString
				UBrainComponent* BrainComp = AIController->GetBrainComponent();
				if (BrainComp)
				{
					if (DebugLevel == 1)
					{
						NewAIDebugString = BrainComp->GetDebugInfoString();
					}
					else if (DebugLevel == 2)
					{
						NewAIDebugString = BrainComp->GetBlackboardComponent()->GetDebugInfoString(EBlackboardDescription::KeyWithValue);
					}
				}

				// Update alert state
				AP3AIController* P3AIController = Cast<AP3AIController>(GetController());
				if (P3AIController)
				{
					NewAIDebugString.Append(FString::Printf(TEXT("Alert: %s\n"), P3AIController->IsInAlert() ?  TEXT("true") : TEXT("false")));

					if (P3AIController->IsReturningFromCombat())
					{
						NewAIDebugString.Append(FString::Printf(TEXT("Returning: %.1f\n"), P3AIController->GetReturningFromCombatAgeSeconds()));
					}

					NewAIDebugString.Append(FString::Printf(TEXT("Target: %s\n"), *P3AIController->GetDebugString()));
				}
			}
		}

		if (Net_AIDebugString != NewAIDebugString)
		{
			Net_AIDebugString = NewAIDebugString;

			Server_SetDirty(*this);
		}
	}

	// Display AIDebugString
	if (DebugLevel != 0 && GIsClient && !Net_AIDebugString.IsEmpty())
	{
		AddDebugString(Net_AIDebugString);
	}
}

void AP3Character::TickMountedDebug()
{
	if (CVarP3MountDebug.GetValueOnGameThread())
	{
		AddDebugString(TEXT("Mounted Info"));

		FString RiderCharacters = TEXT("");

		for (auto&& Iter : CharacterStore.MountRiderCharacters)
		{
			AP3Character* RiderCharacter = Iter.Value;

			if (!RiderCharacters.IsEmpty())
			{
				RiderCharacters.Append(TEXT(", "));
			}

			RiderCharacters.Append(*RiderCharacter->GetName());
		}

		AddDebugString(FString::Printf(TEXT(" Riders : [%s]"), *RiderCharacters));

		FString DisabledMountPoints = TEXT("");

		for (auto point : CharacterStore.DisabledMountPoints)
		{
			if (!DisabledMountPoints.IsEmpty())
			{
				DisabledMountPoints.Append(TEXT(", "));
			}

			DisabledMountPoints.AppendInt(point);
		}

		AddDebugString(FString::Printf(TEXT(" DisabledPoints : [%s]"), *DisabledMountPoints));
	}
}

void AP3Character::TickAllowClimb()
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();

	if (!CharacterMovementComp)
	{
		return;
	}

	bool bAllowClimb = true;

	UP3PawnActionComponent* ActionComp = GetActionComponent();

	if (CharacterStore.Stance == EP3CharacterStance::Pickup)
	{
		bAllowClimb = false;
	}
	else if (ActionComp && !ActionComp->CanStartClimb())
	{
		bAllowClimb = false;
	}

	CharacterMovementComp->SetAllowClimb(bAllowClimb);
}

void AP3Character::TickAllowParkour()
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (!CharacterMovementComp)
	{
		return;
	}

	if (CharacterStore.Stance == EP3CharacterStance::Idle
		|| CharacterStore.Stance == EP3CharacterStance::Combat)
	{
		CharacterMovementComp->SetAllowParkour(true);
	}
	else
	{
		CharacterMovementComp->SetAllowParkour(false);
	}
}

void AP3Character::Client_TickToggleClothSimulation()
{
	bool bNewEnableClothSimulation = true;

	if (IsLocalControlledActor(this) || IsLarge())
	{
		bNewEnableClothSimulation = true;
	}
	else
	{
		APlayerController* LocalPlayerController = GetWorld()->GetFirstPlayerController();
		if (LocalPlayerController && LocalPlayerController->GetViewTarget())
		{
			const float DistanceSquared = (LocalPlayerController->GetViewTarget()->GetActorLocation() - GetActorLocation()).SizeSquared();
			
			if (DistanceSquared > FMath::Square(CVarP3ClothSimulationDistance.GetValueOnGameThread()))
			{
				bNewEnableClothSimulation = false;
			}
		}
	}

	if (Client_EnableClothSimulation != bNewEnableClothSimulation)
	{
		Client_EnableClothSimulation = bNewEnableClothSimulation;

		TInlineComponentArray<USkeletalMeshComponent*, 8> SkeletalMeshComponents;
		GetComponents(SkeletalMeshComponents);

		for (USkeletalMeshComponent* SkeletalMeshComp : SkeletalMeshComponents)
		{
			if (Client_EnableClothSimulation)
			{
				SkeletalMeshComp->ResumeClothingSimulation();
			}
			else
			{
				SkeletalMeshComp->SuspendClothingSimulation();
			}
		}
	}
}

void AP3Character::Client_TickBreathEffect()
{
	if (!BreathParticleComponent)
	{
		return;
	}

	const bool bBreathVisible = (TemperatureComponent && TemperatureComponent->IsBreathVisible());

	if (bBreathVisible)
	{
		if (!BreathParticleComponent->IsActive())
		{
			BreathParticleComponent->Activate(true);
		}
	}
	else
	{
		if (BreathParticleComponent->IsActive())
		{
			BreathParticleComponent->Deactivate();
		}
	}
}

void AP3Character::Client_DebugDraw()
{
#if ENABLE_DRAW_DEBUG

	if (CVarP3StanceDebug.GetValueOnGameThread())
	{
		AddDebugString(FString::Printf(TEXT("Stance: %s"), *EnumToStringShort(EP3CharacterStance, CharacterStore.Stance)));
		AddDebugString(FString::Printf(TEXT("Blocking: %s"), CharacterStore.bIsBlocking ? TEXT("true") : TEXT("false")));
		AddDebugString(FString::Printf(TEXT("Aiming: %s"), CharacterStore.bIsAiming ? TEXT("true") : TEXT("false")));
		AddDebugString(FString::Printf(TEXT("MeleeAiming: %s"), CharacterStore.bIsMeleeAiming ? TEXT("true") : TEXT("false")));
		AddDebugString(FString::Printf(TEXT("KnockDowned: %s"), CharacterStore.bKnockDowned ? TEXT("true") : TEXT("false")));
		AddDebugString(FString::Printf(TEXT("Stumbling: %s"), CharacterStore.bIsStumbling ? TEXT("true") : TEXT("false")));
	}

	if (CVarP3GameplayTagDebug.GetValueOnGameThread())
	{
		AddDebugString(TEXT("[GameplayTags]"));

		for (const FGameplayTag& Tag : Net_GameplayTagContainer)
		{
			AddDebugString(Tag.ToString());
		}
	}

	if (CVarP3AttributeDebug.GetValueOnGameThread())
	{
		UP3AttributesComponent* AttributeComp = FindComponentByClass<UP3AttributesComponent>();
		if (AttributeComp)
		{
			AddDebugString(FString::Printf(TEXT("[Attribute] Level: %d"), AttributeComp->GetLevel()));

			for (int32 AttributeIndex = P3AttributeStart; AttributeIndex < P3AttributeEnd; ++AttributeIndex)
			{
				const int32 Value = AttributeComp->GetAttribute(static_cast<EP3Attribute>(AttributeIndex));

				AddDebugString(FString::Printf(TEXT("  %s : %d"), *EnumToStringShort(EP3Attribute, AttributeIndex), Value));
			}
		}
	}

	if (CVarP3HealthDebug.GetValueOnGameThread() && HealthComponent)
	{
		// Empty line to avoid overlap with Health component debug string
		AddDebugString("");

		const int32 MaxHealthPoint = HealthComponent->GetMaxHealthPoint();

		for (int32 PartIndex = 0; PartIndex < Parts.Num(); ++PartIndex)
		{
			const FP3CharacterPart& Part = Parts[PartIndex];

			if (!Net_PartHealthPoints.IsValidIndex(PartIndex))
			{
				break;
			}

			if (Part.HealthPointPermil != 0)
			{
				AddDebugString(FString::Printf(TEXT("Part(#%d): HP(%d/%d)"),
					PartIndex, Net_PartHealthPoints[PartIndex], (MaxHealthPoint * Part.HealthPointPermil) / 1000));
			}
		}
	}

	if (CVarP3MountPointDebug.GetValueOnGameThread() != 0 && GetMesh())
	{
		for (const FP3CharacterMountPoint& MountPoint : MountPoints)
		{
			const FVector Location = GetMesh()->GetSocketLocation(MountPoint.SocketName);

			DrawDebugSphere(GetWorld(), Location, MountPoint.MountStartRadius, 16, FColor::Red);
			DrawDebugString(GetWorld(), Location, MountPoint.SocketName.ToString(), nullptr, FColor::Green, 0.0f, true);
		}
	}

	TickCharacterDebug();
	TickItemDebug();

	if (EffectComponent && CVarP3CharacterEffectDebug.GetValueOnGameThread() != 0)
	{
		AddDebugString(EffectComponent->GetDebugString());
	}

	if (ComboTableComponent && CVarP3ComboTableDebug.GetValueOnGameThread() != 0)
	{
		AddDebugString(ComboTableComponent->GetDebugString());
	}

	if (!DebugString.IsEmpty())
	{
		DrawDebugString(GetWorld(), FVector(0, 0, 100), DebugString, this, FColor::White, 0, true);

		DebugString.Empty();
	}
	if (CVarP3TeamIDDebug.GetValueOnGameThread())
	{
		AddDebugString(FString::Printf(TEXT("TeamID: %d"), (int32)GetGenericTeamId()));
	}

	if (CVarP3CharacterServerLODDebug.GetValueOnGameThread() != 0)
	{
		AddDebugString(FString::Printf(TEXT("ServerLOD: %s"), *EnumToStringShort(EP3CharacterServerLOD, Server_LOD)));
	}

#endif	// ENABLE_DRAW_DEBUG
}

void AP3Character::Server_Tick(float TickSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (CommandComponent && GetStance() == EP3CharacterStance::Combat && !CanCombat())
	{
		FP3CommandRequestParams Params;
		Params.ChangeStance_NewStance = EP3CharacterStance::Idle;
		GetCommandComponent()->RequestCommand(UP3ChangeStanceCommand::StaticClass(), Params);
	}

	if (CommandComponent && CharacterStore.bKnockDowned)
	{
		if (Server_KnockDownFinishTime < GetWorld()->GetTimeSeconds())
		{
			FP3CommandRequestParams Params;
			Params.SetKnockDowned_bNewKnowDowned = false;
			CommandComponent->RequestCommand(UP3SetKnockDownedCommand::StaticClass(), Params);
		}
	}

	// Clean up old hit timers
	const float Now = GetWorld()->GetTimeSeconds();
	const float HitCooldownTimeSeconds = CVarP3HitDamageCooldownTimeSeconds.GetValueOnGameThread();
	for (auto Iter = Server_LastHitDamageTimes.CreateIterator(); Iter; ++Iter)
	{
		const AActor* Actor = Iter.Key();
		const float TimeSeconds = Iter.Value();
		if (!Actor || (Now - TimeSeconds) > HitCooldownTimeSeconds)
		{
			Iter.RemoveCurrent();
			continue;
		}
	}

	// Tick Stumble duration
	if (CommandComponent && CharacterStore.bIsStumbling && Server_StumblingEndTimeSeconds > 0)
	{
		if (Server_StumblingEndTimeSeconds < GetWorld()->GetTimeSeconds())
		{
			Server_StumblingEndTimeSeconds = 0;

			FP3CommandRequestParams Params;
			Params.SetStumbling_bIsStumbling = false;

			CommandComponent->RequestCommand(UP3SetStumblingCommand::StaticClass(), Params);
		}
	}

	// Timeout player ragdoll
	if (CommandComponent && IsRagdollizedBP() && IsPlayerControlled())
	{
		const float RagdolledSeconds = GetWorld()->GetTimeSeconds() - RagdollStartedTimeSeconds;
		if (RagdolledSeconds > CVarP3PlayerRagdollMaxSeconds.GetValueOnGameThread())
		{
			FP3CommandRequestParams Params;
			Params.Ragdollize_bRagdoll = false;

			CommandComponent->RequestCommand(UP3RagdollizeCommand::StaticClass(), Params);
		}
	}

    // Start Exhaust Action
	const bool bIsNotNullExhaustMontage = (GetAnimMontages().Exhaust != nullptr);
	const bool bIsStanimaExhausted = StaminaComponent && StaminaComponent->IsExhausted();
	const bool bCanStartExhaust = ActionComponent && ActionComponent->CanStartAction(EPawnActionType::Exhaust) && !ActionComponent->IsActionInProgress(EPawnActionType::Exhaust);
	if (bIsNotNullExhaustMontage && bIsStanimaExhausted && bCanStartExhaust)
	{
		if (IsOnGround())
		{
			ActionComponent->StartAction(EPawnActionType::Exhaust, _FUNCTION_TEXT);
		}
	}

	// Report noise(= make noise) when player walk or run
	UCharacterMovementComponent* MovementComponent = GetCharacterMovement();
	const float MaxWalkSpeed = MovementComponent ? MovementComponent->MaxWalkSpeed : 0.0f;
	const bool IsFalling = MovementComponent ? MovementComponent->IsFalling() : false;
	const bool IsUnNoisyMoving = IsFalling || IsGliding();
	if (IsPlayerControlled() && !IsUnNoisyMoving && (GetVelocity().Size() >= MaxWalkSpeed))
	{
		UAISense_Hearing::ReportNoiseEvent(GetWorld(), GetActorLocation(), 1.f, this, 1500.f);
	}
	
	Server_TickBlocking();
	Server_TickAiming();

	Server_ConsiderDismount();
	Server_TickMounting();
	Server_TickLOD();
	Server_ApplyLOD();
	Server_TickDestoryObjects();

	TickMountedDebug();
}

void AP3Character::TickGliding()
{
	UP3CharacterMovementComponent* CharacterMovementComp = GetP3CharacterMovementBP();
	if (!ensure(CharacterMovementComp) || !CharacterMovementComp->IsGliding())
	{
		return;
	}

	if (EffectComponent && EffectComponent->HasStunEffect())
	{
		CharacterMovementComp->SetMovementMode(MOVE_Falling);
	}
}

void AP3Character::Server_TickMounting()
{
	if (P3Core::IsP3NetModeClient(*this))
	{
		return;
	}

	if (!IsMounted())
	{
		if (CVarP3MountDebug.GetValueOnGameThread())
		{
			AddDebugString(TEXT("MountingDebug"));
			AddDebugString(TEXT(" MountingTarget : [NULL]"));
		}
		return;
	}

	bool bShouldDismount = false;
	bool bPlayKnockdown = false;

	if (EffectComponent && EffectComponent->HasStunEffect())
	{
		bShouldDismount = true;
	}

	AP3Character* MountTargetCharacter = CharacterStore.MountTargetCharacter;
	const int32 CurrentMountPointIndex = CharacterStore.MountPointIndex;

	if (!MountTargetCharacter)
	{
		bShouldDismount = true;
	}
	else
	{
		if (MountTargetCharacter->GetCharacterStoreBP().DisabledMountPoints.Contains(CurrentMountPointIndex))
		{
			bShouldDismount = true;
		}
		else
		{
			// See if character hit any static object
			if (GetCapsuleComponent())
			{
				const static FName Name_Trace(TEXT("Mount Character Overlap Check"));

				FCollisionQueryParams QueryParams(Name_Trace);
				QueryParams.AddIgnoredActor(this);
				QueryParams.AddIgnoredActor(MountTargetCharacter);
				QueryParams.bIgnoreTouches = true;

				FCollisionResponseParams ResponseParams;
				ResponseParams.CollisionResponse.SetAllChannels(ECR_Ignore);
				ResponseParams.CollisionResponse.SetResponse(ECC_WorldStatic, ECR_Block);

				TArray<AActor*> AttachedActors;
				GetAttachedActors(AttachedActors);
				QueryParams.AddIgnoredActors(AttachedActors);
				MountTargetCharacter->GetAttachedActors(AttachedActors);
				QueryParams.AddIgnoredActors(AttachedActors);

				FCollisionShape Shape;
				Shape.SetSphere(GetCapsuleComponent()->GetScaledCapsuleRadius());

				TArray<FHitResult> HitResults;

				GetWorld()->SweepMultiByChannel(HitResults, GetCapsuleComponent()->GetComponentLocation(), GetCapsuleComponent()->GetComponentLocation() + FVector(0, 0, 1), GetCapsuleComponent()->GetComponentQuat(), ECC_Pawn, Shape, QueryParams, ResponseParams);

				if (HitResults.Num() > 0)
				{
					bShouldDismount = true;
					bPlayKnockdown = true;
				}
			}
		}
	}

	if (CVarP3MountDebug.GetValueOnGameThread())
	{
		AddDebugString(TEXT("Mounting Info"));
		AddDebugString(FString::Printf(TEXT(" Target : [%s]"),
			MountTargetCharacter ? *MountTargetCharacter->GetName() : TEXT("NULL")));
		AddDebugString(FString::Printf(TEXT(" Index : [%d]"), CurrentMountPointIndex));
		AddDebugString(FString::Printf(TEXT(" bShouldDismount : [%d]"), bShouldDismount));
	}

	if (bShouldDismount && CommandComponent)
	{
		FP3CommandRequestParams CommandParams;
		CommandParams.Mount_Detach = true;
		CommandComponent->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
	}

	if (bPlayKnockdown && ActionComponent)
	{
		FP3PawnActionStartRequestParams HitParams;
		HitParams.CombatHit_Damage = 0;
		HitParams.CombatHit_SourceActor = MountTargetCharacter;
		HitParams.CombatHit_bIsPushBack = false;
		HitParams.CombatHit_bIsKnockDown = true;
		GetActionComponent()->StartAction(EPawnActionType::CombatHit, _FUNCTION_TEXT, HitParams);
	}
}

void AP3Character::Ragdollize()
{
	if (IsRagdollizedBP())
	{
		return;
	}

	if (!GetMesh())
	{
		return;
	}

	RagdollStartedTimeSeconds = GetWorld()->GetTimeSeconds();

	CharacterStore.bIsRagdollized = true;

	// If we were already on unragdollizing, RagdollMeshTransform is already set and Mesh transform is interpolated value which should not be used
	if (!bUnragollizing)
	{
		RagdollMeshTransform = GetMesh()->GetRelativeTransform();
	}
	bUnragollizing = false;

	//GetCharacterMovement()->ApplyAccumulatedForces(0.0f);

	GetMesh()->SetCollisionProfileName(TEXT("Ragdoll"));
	//GetMesh()->SetAllBodiesBelowSimulatePhysics(FName(TEXT("Bip01-Pelvis")), true, false);
	//GetMesh()->SetAllBodiesBelowSimulatePhysics(FName(TEXT("ROOT")), true, false);
	GetMesh()->SetAllBodiesSimulatePhysics(true);
	GetMesh()->SetAllBodiesPhysicsBlendWeight(1.0f);
	//GetMesh()->SetPhysicsLinearVelocity(GetCharacterMovement()->Velocity);

	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::QueryOnly);

	GetCharacterMovement()->bIgnoreClientMovementErrorChecksAndCorrection = true;
}

void AP3Character::Unragdollize()
{
	GetMesh()->SetCollisionProfileName(TEXT("CharacterMesh"));
	GetMesh()->SetAllBodiesSimulatePhysics(false);
	GetMesh()->AttachToComponent(GetCapsuleComponent(), FAttachmentTransformRules::KeepWorldTransform);

	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);

	GetP3CharacterMovementBP()->SetMovementMode(MOVE_Falling);
	GetCharacterMovement()->bIgnoreClientMovementErrorChecksAndCorrection = false;
	
	CharacterStore.bIsRagdollized = false;

	bUnragollizing = true;
	UnragdollizeAge = 0;
	UnragdollizeStartTransform = GetMesh()->GetRelativeTransform();
	RagdollStartedTimeSeconds = 0;
}

void AP3Character::TickMoveCapsuleDuringRagdoll()
{
	ensure(CharacterStore.bIsRagdollized);

	const FTransform NewTransform = GetMesh()->GetComponentToWorld();

	GetCapsuleComponent()->SetWorldLocation(NewTransform.GetLocation() - RagdollMeshTransform.GetLocation());
}

void AP3Character::TickUnragdollizing(float DeltaSeconds)
{
	UnragdollizeAge += DeltaSeconds;

	const float Alpha = FMath::Clamp(UnragdollizeAge, 0.0f, 1.0f);

	FTransform NewTransform;
	NewTransform.Blend(UnragdollizeStartTransform, RagdollMeshTransform, Alpha);

	GetMesh()->SetRelativeTransform(NewTransform);

	GetMesh()->SetAllBodiesPhysicsBlendWeight(1.0f -Alpha);

	if (Alpha >= 1.0f)
	{
		bUnragollizing = false;
	}
}

void AP3Character::TickURO()
{
	if (!GetMesh() || !GetMesh()->AnimUpdateRateParams)
	{
		return;
	}


	int32 BaseNonRenderedUpdateRate = 4;
	bool bEnableURO = true;

	if (IsLarge())
	{
		BaseNonRenderedUpdateRate = 1;
		bEnableURO = false;
	}
	else if (Role == ENetRole::ROLE_Authority && GetRemoteRole() == ENetRole::ROLE_AutonomousProxy)
	{
		// Dedicated server
		// Note we need to check with role to support PIE. since PIE is using listen-server

		if (IsPlayerControlled())
		{
			// Player character on Dedicated server should not use URO to avoid sync error
			// TODO: maybe this is only needed during doing some Action
			BaseNonRenderedUpdateRate = 1;
		}
	}

	GetMesh()->AnimUpdateRateParams->BaseNonRenderedUpdateRate = BaseNonRenderedUpdateRate;
	GetMesh()->bEnableUpdateRateOptimizations = bEnableURO;
}

void AP3Character::TickCollision()
{
	if (!GetCapsuleComponent())
	{
		return;
	}

	bool bDisableWorldObject = false;

	if (ActionComponent)
	{
		bDisableWorldObject |= ActionComponent->IsDisableCollisionWithWorldObject();
	}

	if (bDisableWorldObject)
	{
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldStatic, ECR_Ignore);
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Ignore);
	}
	else
	{
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldStatic, ECR_Block);
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Block);
	}
}

void AP3Character::LocalControl_TickSprinting(float DeltaSeconds)
{
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
	if (!MovementComp || !MovementComp->GetSprintingPressed())
	{
		return;
	}
	if (IsMounted())
	{
		return;
	}

	if (IsPlayerControlled() && CVarP3AutoPutAwayBySprint.GetValueOnGameThread() > 0)
	{
		if (ActionComponent && ActionComponent->CanStartAction(EPawnActionType::PutAwayWeapon))
		{
			if (GetStance() == EP3CharacterStance::Combat && CombatComponent)
			{
				CombatComponent->PutAwayWeapon();
			}
		}
	}

}

void AP3Character::Client_TickMinimapIconMeshComponent()
{
	UStaticMesh* MinimapMesh = nullptr;
	UMaterialInterface* MinimapMaterial = nullptr;
	FVector MinimapScale = FVector(1.0f);

	const UP3GameResource& GameResource = P3Core::GetGameResource(this);

	if (IsLocalControlledActor(this))
	{
		MinimapMesh = GameResource.MinimapLocalPlayerIconMesh;
		MinimapMaterial = GameResource.MinimapLocalPlayerIconMaterial;
		MinimapScale = GameResource.MinimapLocalPlayerIconScale;
	}
	else if (IsPlayerControlled())
	{
		if (IsDowned())
		{
			MinimapMesh = GameResource.MinimapDownedPlayerIconMesh;
			MinimapMaterial = GameResource.MinimapDownedPlayerIconMaterial;
		}
		else
		{
			MinimapMesh = GameResource.MinimapPlayerIconMesh;
			MinimapMaterial = GameResource.MinimapPlayerIconMaterial;
		}

		MinimapScale = GameResource.MinimapPlayerIconScale;
	}

	if (MinimapMesh)
	{
		if (!MinimapIconMeshComponent)
		{
			MinimapIconMeshComponent = NewObject<UStaticMeshComponent>(this, TEXT("MinimapIconMeshComponent"));
			MinimapIconMeshComponent->RegisterComponent();
			MinimapIconMeshComponent->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
			MinimapIconMeshComponent->SetAbsolute(false, false, true);
			MinimapIconMeshComponent->SetRelativeLocation(FVector(0, 0, 5000));
			MinimapIconMeshComponent->SetRelativeRotation(FRotator(-90, 0, 0));
			MinimapIconMeshComponent->SetSimulatePhysics(false);
			MinimapIconMeshComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			MinimapIconMeshComponent->SetCastShadow(false);

			APlayerController* PC = GetWorld()->GetFirstPlayerController();
			if (PC)
			{
				PC->HiddenPrimitiveComponents.Add(MinimapIconMeshComponent);
			}
		}

		MinimapIconMeshComponent->SetRelativeScale3D(MinimapScale);
		MinimapIconMeshComponent->SetStaticMesh(MinimapMesh);
		MinimapIconMeshComponent->SetMaterial(0, MinimapMaterial);
	}
	else
	{
		if (MinimapIconMeshComponent)
		{
			APlayerController* PC = GetWorld()->GetFirstPlayerController();
			if (PC)
			{
				PC->HiddenPrimitiveComponents.Remove(MinimapIconMeshComponent);
			}

			MinimapIconMeshComponent->DestroyComponent();
			MinimapIconMeshComponent = nullptr;
		}
	}
}

void AP3Character::TickEffect()
{
	const bool bInSwamp = (EffectComponent && EffectComponent->HasEffect(EP3CharacterEffectTypes::Swamp));
	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

	if (MovementComp)
	{
		if (bInSwamp)
		{
			// In swamp, you can't swim freely
			MovementComp->SetShouldRemainVertial(true);
			MovementComp->SetConstraintZAccel(true);
			MovementComp->Buoyancy = 0.5f;	// TODO: maybe not a good idea. need override parameter instead of overwrite property
		}
		else
		{
			MovementComp->SetShouldRemainVertial(false);
			MovementComp->SetConstraintZAccel(false);
			MovementComp->Buoyancy = 1.0f;;	// TODO: maybe not a good idea. need override parameter instead of overwrite property
		}
	}

	if (bInSwamp && P3Core::IsP3NetModeServerInstance(*this))
	{
		// Kill if drowned to swamp
		const float ImmersionDepth = MovementComp ? MovementComp->ImmersionDepth() : 0.0f;
		if (bInSwamp && ImmersionDepth >= 1.0f && ensure(HealthComponent) && ensure(CommandComponent))
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.ApplyDamage_DamageAmount = HealthComponent->GetMaxHealthPoint();
			CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Swamp;
			CommandComponent->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
		}
	}
}

void AP3Character::CreateCameraAndBoom()
{
	if (ensure(CameraBoom))
	{
		CameraBoom->Activate(true);
	}

	if (ensure(FollowCamera))
	{
		FollowCamera->Activate(true);
	}

	//// Create a camera boom (pulls in towards the player if there is a collision)
	//CameraBoom = NewObject<USpringArmComponent>(this, TEXT("CameraBoom"), RF_Transient);
	//CameraBoom->AttachToComponent(RootComponent, FAttachmentTransformRules::KeepRelativeTransform);
	//CameraBoom->TargetArmLength = CameraDefaultDistance; // The camera follows at this distance behind the character	
	//CameraBoom->bUsePawnControlRotation = true; // Rotate the arm based on the controller
	//CameraBoom->RegisterComponent();

	//// Create a follow camera
	//FollowCamera = NewObject<UCameraComponent>(this, TEXT("FollowCamera"), RF_Transient);
	//FollowCamera->AttachToComponent(CameraBoom, FAttachmentTransformRules::KeepRelativeTransform, USpringArmComponent::SocketName); // Attach the camera to the end of the boom and let the boom adjust to match the controller orientation
	//FollowCamera->bUsePawnControlRotation = false; // Camera does not rotate relative to arm
	//FollowCamera->RegisterComponent();
}

void AP3Character::DestroyCameraAndBoom()
{
	if (ensure(CameraBoom))
	{
		CameraBoom->Deactivate();
	}

	if (ensure(FollowCamera))
	{
		FollowCamera->Deactivate();
	}

	//if (CameraBoom)
	//{
	//	CameraBoom->DestroyComponent();
	//	CameraBoom = nullptr;
	//}

	//if (FollowCamera)
	//{
	//	FollowCamera->DestroyComponent();
	//	FollowCamera = nullptr;
	//}
}

void AP3Character::OnToggleCameraZoom()
{
	/*if (LocalControl_CameraBoomTargetArmLength == CameraMinDistance)
	{
		LocalControl_CameraBoomTargetArmLength = CameraDefaultDistance;
	}
	else if (LocalControl_CameraBoomTargetArmLength == CameraDefaultDistance)
	{
		LocalControl_CameraBoomTargetArmLength = CameraMaxDistance;
	}
	else if (LocalControl_CameraBoomTargetArmLength == CameraMaxDistance)
	{
		LocalControl_CameraBoomTargetArmLength = CameraMinDistance;
	}
	else
	{
		LocalControl_CameraBoomTargetArmLength = CameraDefaultDistance;
	}*/

}

void AP3Character::OnLockOnPressed()
{
	OnInputPressLockOnButton.Broadcast();
}

void AP3Character::OnLockOnReleased()
{
	OnInputReleaseLockOnButton.Broadcast();
}

void AP3Character::OnNextLockOn()
{
	OnInputNextLockOn.Broadcast();
}

void AP3Character::OnPrevLockOn()
{
	OnInputPrevLockOn.Broadcast();
}

void AP3Character::OnLookAssist()
{
	OnInputLookAssist.Broadcast();
}

void AP3Character::OnStartMobilePart()
{
	OnInputStartMobilePart.Broadcast();
}

void AP3Character::OnStopMobilePart()
{
	OnInputStopMobilePart.Broadcast();
}

void AP3Character::OnShowInventory()
{
	OnInputShowInventory.Broadcast();
}

void AP3Character::OnToggleMainMenuUI()
{
	LocalControl_bMainMenuUIOpened = !LocalControl_bMainMenuUIOpened;
}

// Deprecated
void AP3Character::OnToggleConsumableUI()
{
	LocalControl_bConsumableUIOpened = !LocalControl_bConsumableUIOpened;
	LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;

	if (LocalControl_bConsumableUIOpened)
	{
		OnInputOpenConsumableUI.Broadcast();
	}
	else
	{
		OnInputCloseConsumableUI.Broadcast();
	}
}

void AP3Character::OnNextConsumable()
{
	if (LocalControl_bConsumableUIOpened)
	{
		LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;

		OnInputNextConsumable.Broadcast();
	}
}

void AP3Character::OnPrevConsumable()
{
	if (LocalControl_bConsumableUIOpened)
	{
		LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;

		OnInputPrevConsumable.Broadcast();
	}
}

void AP3Character::OnUseConsumable()
{
	if (LocalControl_bConsumableUIOpened)
	{
		OnInputUseConsumable.Broadcast();

		LocalControl_bConsumableUIOpened = false;
		LocalControl_ConsumableUIOpenedAgeSeconds = 0.0f;

		LocalControl_UseConsumableTimeSeconds = GetWorld()->GetTimeSeconds();
	}
}

void AP3Character::OnOpenChatPressed()
{
	OnInputOpenChat.Broadcast();
}

void AP3Character::OnConnectDediPressed()
{
	OnInputConnectDedi.Broadcast();
}

void AP3Character::OnWeaponNormalAttackPressed()
{
	if (!CanAttack())
	{
		return;
	}

	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened || LocalControl_UseConsumableTimeSeconds == GetWorld()->GetTimeSeconds())
	{
		return;
	}

	// If mounted, do mounted attack
	if (IsMounted())
	{
		if (ActionComponent)
		{
			FP3PawnActionStartRequestParams Params;
			Params.CombatAttack_Target = GetCharacterStoreBP().MountTargetCharacter;
			Params.CombatAttack_bIsMountedAttack = true;
			ActionComponent->StartAction(EPawnActionType::CombatAttack, _FUNCTION_TEXT, Params);
			return;
		}
	}
	else
	{
		OnInputPressLeftButton.Broadcast();
	}

	// Backward compatibility for non-combo character (X4Female)
	OnStartAttack();
}

void AP3Character::OnWeaponNormalAttackReleased()
{
	if (!CanAttack())
	{
		return;
	}

	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}

	OnInputReleaseLeftButton.Broadcast();

	// Backward compatibility for non-combo character (X4Female)
	OnStopAttack();
}

void AP3Character::OnWeaponSpecialAttackPressed()
{
	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		OnInputHoldItemFromInventory.Broadcast();
		return;
	}

	if (CharacterStore.ThrowAimingItemId != INVALID_ITEMID)
	{
		// Do nothing if holding an item to throw
		return;
	}

	if (IsDowned())
	{
		if (IsAutonomousProxy(this) || IsAuthority(this))
		{
			UP3CharacterHealthPointComponent* HealthComp = GetP3CharacterHealthComponentBP();
			if (CommandComponent && HealthComp)
			{
				FP3CommandRequestParams RequestParams;
				RequestParams.ApplyDamage_DamageAmount = HealthComp->GetMaxDownedHealthPoint();
				RequestParams.ApplyDamage_Reason = EP3HealthChangeReason::QuickDeath;
				CommandComponent->RequestCommand(UP3ApplyDamageCommand::StaticClass(), RequestParams);
			}
		}
	}

	if (CharacterStore.MountRiderCharacters.Num() > 0)
	{
		// Putdown carrying character
		if (ActionComponent)
		{
			ActionComponent->StartAction(EPawnActionType::CarryingOnBackEnd, _FUNCTION_TEXT);
		}
	}
	else if (CanInteract())
	{
		if (PickupComponent
			&& (PickupComponent->HasPickupToInvenCandidate()
				|| PickupComponent->HasRescueCandidate()
				|| PickupComponent->HasTempWeaponCandidate()
				|| PickupComponent->HasBackpackCandidate()
				)
			)
		{
			// This is a fast-track
			// If we have something to pickup which can be stored to inventory like looting items
			// We just do it right away without Put away Weapon action, to make gameplay more smoother
			// Without this, player must put away weapon, pickup and draw weapon again

			if (PickupComponent->HasRescueCandidate())
			{
				// [7/25/2019 mrhwang] Rescuing downed player is added to this fast track
				HoldingKeyStatus.StartHolding(EHoldingKeyInputType::Rescue);
			}
			else if (PickupComponent->HasBackpackCandidate())
			{
				HoldingKeyStatus.StartHolding(EHoldingKeyInputType::PickUpBackpack);
			}
			else
			{
				OnStartInteract();
			}
		}
		// Comment-out: This makes player confusing
		//else if (GetStance() == EP3CharacterStance::Combat && CombatComponent)
		//{
		//	if (ActionComponent && ActionComponent->CanStartAction(EPawnActionType::PutAwayWeapon))
		//	{
		//		CombatComponent->PutAwayWeapon();
		//	}
		//}
		else
		{
			OnStartInteract();
		}
	}
	else if (CanAttack())
	{
		if (MountOverlappedCharacter && MountOverlappedPointIndex != -1 && CommandComponent)
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.Mount_Detach = false;
			CommandParams.Mount_TargetCharacter = MountOverlappedCharacter;
			CommandParams.Mount_TargetMountPointIndex = MountOverlappedPointIndex;
			CommandComponent->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
		}
		else
		{
			OnInputStartSpecialAttack.Broadcast();
		}
	}
	else if(IsCarryingBackpack())
	{
		if (ensure(ActionComponent))
		{
			ActionComponent->StartAction(EPawnActionType::PutdownBackpack, _FUNCTION_TEXT);
		}
	}
}

void AP3Character::OnWeaponSpecialAttackReleased()
{
	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (HoldingKeyStatus.bIsHolding)
	{
		switch (HoldingKeyStatus.InputType)
		{
		case EHoldingKeyInputType::Rescue:
			if (CanInteract() && HoldingKeyStatus.HoldingAgeSeconds < CVarP3HoldingKeyMinDurationSeconds.GetValueOnGameThread())
			{
				if (ActionComponent)
				{
					FP3PawnActionStartRequestParams ActionParams;
					ActionParams.CarryOnBack_TargetCharacter = Cast<AP3Character>(PickupComponent->GetPickupCandidateActor());
					ActionComponent->StartAction(EPawnActionType::CarryingOnBackStart, _FUNCTION_TEXT, ActionParams);
				}
				else
				{
					OnStartInteract();
				}
			}
			break;
		case EHoldingKeyInputType::PickUpBackpack:
			if (CanInteract())
			{
				if (HoldingKeyStatus.HoldingAgeSeconds < CVarP3HoldingKeyMinDurationSeconds.GetValueOnGameThread())
				{
					// open backpack
					OnInputOpenBackpackInventory.Broadcast();
				}
				else
				{
					// pick up backpack
					if (ActionComponent)
					{
						FP3PawnActionStartRequestParams ActionParams;
						ActionParams.PickupBackpack_BackpackActor = Cast<AP3Backpack>(PickupComponent->GetPickupCandidateActor());
						ActionParams.PickupBackpack_AttachSocketName = FName("Backpack");

						ActionComponent->StartAction(EPawnActionType::PickupBackpack, _FUNCTION_TEXT , ActionParams);
					}
				}
			}
			break;
		}

		HoldingKeyStatus.bIsHolding = false;
		HoldingKeyStatus.HoldingAgeSeconds = 0;


		/*if (CanInteract() && HoldingKeyStatus.HoldingAgeSeconds < CVarP3HoldingKeyMinDurationSeconds.GetValueOnGameThread())
		{
			if (CVarP3RescueByHoldingInput.GetValueOnGameThread() > 0)
			{
				if (ActionComponent)
				{
					FP3PawnActionStartRequestParams ActionParams;
					ActionParams.CarryOnBack_TargetCharacter = Cast<AP3Character>(PickupComponent->GetPickupCandidateActor());
					ActionComponent->StartAction(EPawnActionType::CarryingOnBackStart, _FUNCTION_TEXT, ActionParams);
				}
			}
			else
			{
				OnStartInteract();
			}
		}

		HoldingKeyStatus.bIsHolding = false;
		HoldingKeyStatus.HoldingAgeSeconds = 0;*/
	}

	if (CharacterStore.ThrowAimingItemId != INVALID_ITEMID)
	{
		// Do nothing if holding an item to throw
		return;
	}

	if (!CanAttack())
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}

	OnInputStopSpecialAttack.Broadcast();
}

void AP3Character::OnWeaponClassAttackPressed()
{
	const bool bCanStartedClassAttack = IsElementalistWeapon(GetRightHandWeaponType());

	if (!bCanStartedClassAttack)
	{
		OnWeaponNormalAttackPressed();
		return;
	}

	if (!CanAttack())
	{
		return;
	}

	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened || LocalControl_UseConsumableTimeSeconds == GetWorld()->GetTimeSeconds())
	{
		return;
	}

	OnInputPressClassButton.Broadcast();
}

void AP3Character::OnWeaponClassAttackReleased()
{
	const bool bCanStartedClassAttack = IsElementalistWeapon(GetRightHandWeaponType());

	if (!bCanStartedClassAttack)
	{
		OnWeaponNormalAttackReleased();
		return;
	}

	if (!CanAttack())
	{
		return;
	}

	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}

	OnInputReleaseClassButton.Broadcast();
}

void AP3Character::OnWeaponPrivateActionPressed()
{	
	if (!CanAttack())
	{
		return;
	}

	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}

	if (GetStance() != EP3CharacterStance::Combat)
	{
		return;
	}

	OnInputPressRightButton.Broadcast();

	// Backward compatibility for non-combo character (X4Female)
	OnStartBlock();
}

void AP3Character::OnWeaponPrivateActionReleased()
{
	if (!CanAttack())
	{
		return;
	}

	if (LocalControl_bMainMenuUIOpened)
	{
		return;
	}

	if (LocalControl_bConsumableUIOpened)
	{
		return;
	}

	OnInputReleaseRightButton.Broadcast();

	// Backward compatibility for non-combo character (X4Female)
	OnStopBlock();
}

void AP3Character::OnStartClimb()
{
	OnStopSprint();
}

void AP3Character::OnDead()
{
	LastDeadTimeSeconds = GetWorld()->GetTimeSeconds();

	if (GetCapsuleComponent())
	{
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Overlap);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		TInlineComponentArray<UP3LootDropComponent*> LootDropComponents;
		GetComponents(LootDropComponents);

		for (UP3LootDropComponent* LootDropComp : LootDropComponents)
		{
			LootDropComp->Server_RollDiceAndDrop();
		}

		P3Combat::Server_DamageActor(this, EP3ReactionLayer::Dead);

		if (CharacterStore.bIsBlocking)
		{
			FP3CommandRequestParams Params;
			Params.SetBlocking_bNewBlocking = false;
			GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), Params);
		}

		if (CharacterStore.bIsMeleeAiming)
		{
			FP3CommandRequestParams Params;
			Params.SetMeleeAiming_bNewAiming = false;
			CommandComponent->RequestCommand(UP3SetMeleeAimingCommand::StaticClass(), Params);
		}

		if (CharacterStore.bIsAiming)
		{
			FP3CommandRequestParams Params;
			Params.SetRangedAiming_bNewAiming = false;
			CommandComponent->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), Params);
		}

		if (CharacterStore.bIsStumbling)
		{
			FP3CommandRequestParams Params;
			Params.SetStumbling_bIsStumbling = false;
			CommandComponent->RequestCommand(UP3SetStumblingCommand::StaticClass(), Params);
		}

		if (IsMounted())
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.Mount_Detach = true;
			CommandComponent->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
		}

		if (IsPickuped())
		{
			FP3CommandRequestParams CommandParams;
			CommandComponent->RequestCommand(UP3DropPickableCommand::StaticClass(), CommandParams);
		}

		UP3CharacterHealthPointComponent* CharacterHealthComponent = GetP3CharacterHealthComponentBP();
		if (CharacterHealthComponent)
		{
			CharacterHealthComponent->DownedEndOnDead();
		}

		UP3CombatComponent* CombatComp = GetP3CombatComponentBP();
		if (CombatComp)
		{
			AP3Character* LastDamageSource = CombatComp->Server_GetLastDamageSource();
			UP3DamageMetersComponent* SourceDamageMetersComponent = LastDamageSource ? LastDamageSource->FindComponentByClass<UP3DamageMetersComponent>() : nullptr;
			if (SourceDamageMetersComponent)
			{
				SourceDamageMetersComponent->Server_AddKill(this);
			}

			if (IsPlayerControlled())
			{
				UP3BossChallengeComponent* BossChallengeComponent = LastDamageSource ? LastDamageSource->FindComponentByClass<UP3BossChallengeComponent>() : nullptr;
				if (BossChallengeComponent && BossChallengeComponent->Server_GetBossChallengeActor())
				{
					BossChallengeComponent->Server_GetBossChallengeActor()->Server_OnPlayerDead(*this);
				}
			}

			CombatComp->Server_SetLastDamageSource(nullptr);
		}


		// If the character is NPC, the NPC drops holdable
		if (!IsPlayerControlled())
		{
			const bool bLeftHandHolder = (GetLeftHandHolderComponent() != nullptr);
			const bool bRightHandHoler = (GetRightHandHolderComponent() != nullptr);
			AP3Weapon* LeftHandWeapon = bLeftHandHolder ? (Cast<AP3Weapon>(GetLeftHandHolderComponent()->GetHoldingActor())) : nullptr;
			AP3Weapon* RightHandWeapon = bRightHandHoler ? (Cast<AP3Weapon>(GetRightHandWeaponActor())) : nullptr;

			FP3CommandRequestParams Params;
			if (LeftHandWeapon)
			{
				const bool bSupportHoldable = LeftHandWeapon->IsSupportHoldable();
				// If the weapon is support holdable, destroy immediately.
				if (bSupportHoldable)
				{
					LeftHandWeapon->Destroy();
				}
				else
				{
					if (!(LeftHandWeapon->IsPlayerUsable()))
					{
						LeftHandWeapon->SetLifeSpan(LifespanAfterDead);
					}

					Params.DropHoldable_HoldType = EP3HoldType::LeftHand;
					GetCommandComponent()->RequestCommand(UP3DropHoldableCommand::StaticClass(), Params);
				}
			}
			if (RightHandWeapon)
			{
				if (!(RightHandWeapon->IsPlayerUsable()))
				{
					RightHandWeapon->SetLifeSpan(LifespanAfterDead);
				}

				Params.DropHoldable_HoldType = EP3HoldType::RightHand;
				GetCommandComponent()->RequestCommand(UP3DropHoldableCommand::StaticClass(), Params);
			}
		}

		if (IsPlayerControlled())
		{
			P3Contribution::Server_AddPoint(this, EP3ContributionType::Dead, 1);
		}
	}

	/*if (P3Core::IsP3NetModeClientInstance(*this) && IsLocalControlledActor(this))
	{
		APlayerController* PlayerController = Cast<APlayerController>(GetController());
		if (PlayerController && PlayerController->PlayerCameraManager)
		{
			PlayerController->PlayerCameraManager->StartCameraFade(0.0f, 1.0f, CVarP3ReviveFadeOutDurationSeconds.GetValueOnAnyThread(), FLinearColor::Black, true, false);
		}
	}*/

	if (!IsPlayerControlled() && LifespanAfterDead > 0)
	{
		SetLifeSpan(LifespanAfterDead);
	}

	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
	if (MovementComp && MovementComp->IsClimbing())
	{
		MovementComp->SetMovementMode(MOVE_Falling);
	}

	if (StaminaComponent)
	{
		StaminaComponent->SetMaxStaminaPoint(100.0f);
	}

	if (ComboTableComponent)
	{
		ComboTableComponent->OnDead();
	}

	OnCharacterDead.Broadcast();
	ReceiveDeadBP();
}

void AP3Character::OnDownedChanged(bool bDowned)
{
	if (bDowned)
	{
		if (GetCapsuleComponent())
		{
			// TODO: Push 방식은 버그 가능성 있으니 Pull 방식으로 교체 필요
			GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			P3Combat::Server_DamageActor(this, EP3ReactionLayer::Downed);

			if (CharacterStore.bIsBlocking)
			{
				FP3CommandRequestParams Params;
				Params.SetBlocking_bNewBlocking = false;
				GetCommandComponent()->RequestCommand(UP3SetBlockingCommand::StaticClass(), Params);
			}

			if (CharacterStore.bIsMeleeAiming)
			{
				FP3CommandRequestParams Params;
				Params.SetMeleeAiming_bNewAiming = false;
				CommandComponent->RequestCommand(UP3SetMeleeAimingCommand::StaticClass(), Params);
			}

			if (CharacterStore.bIsAiming)
			{
				FP3CommandRequestParams Params;
				Params.SetRangedAiming_bNewAiming = false;
				CommandComponent->RequestCommand(UP3SetRangedAimingCommand::StaticClass(), Params);
			}

			if (CharacterStore.bIsStumbling)
			{
				FP3CommandRequestParams Params;
				Params.SetStumbling_bIsStumbling = false;
				CommandComponent->RequestCommand(UP3SetStumblingCommand::StaticClass(), Params);
			}

			if (IsPickuped())
			{
				FP3CommandRequestParams CommandParams;
				CommandComponent->RequestCommand(UP3DropPickableCommand::StaticClass(), CommandParams);
			}

			if (IsMounted())
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.Mount_Detach = true;
				CommandComponent->RequestCommand(UP3MountCommand::StaticClass(), CommandParams);
			}
		}

		UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
		if (MovementComp && MovementComp->IsClimbing())
		{
			MovementComp->SetMovementMode(MOVE_Falling);
		}

		UP3ComboTableComponent* ComboTableComp = GetComboComponent();
		if (ComboTableComp)		
		{
			ComboTableComp->OnDownedChanged();
		}
	}
	else
	{
		if (IsDead())
		{
			return;
		}

		if (GetCapsuleComponent())
		{
			GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
			GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Block);
		}

		if (IsRagdollizedBP())
		{
			Unragdollize();
		}

		if (!IsPlayerControlled() && LifespanAfterDead > 0)
		{
			SetLifeSpan(0);
		}

		UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();

		if (MovementComp)
		{
			MovementComp->StopMovementImmediately();
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			UP3PawnActionComponent* ActionComp = GetActionComponent();
			if (ActionComp)
			{
				ActionComp->StopAction(ActionComp->GetActiveActionId());
			}
		}

		GetCapsuleComponent()->SetAllPhysicsAngularVelocityInRadians(FVector::ZeroVector);
		GetCapsuleComponent()->SetAllPhysicsLinearVelocity(FVector::ZeroVector);
	}
}

void AP3Character::OnRevive()
{
	if (GetCapsuleComponent())
	{
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
		GetCapsuleComponent()->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Block);
	}

	if (IsRagdollizedBP())
	{
		Unragdollize();
	}

	if (!IsPlayerControlled() && LifespanAfterDead > 0)
	{
		SetLifeSpan(0);
	}

	UP3CharacterMovementComponent* MovementComp = GetP3CharacterMovementBP();
	if (MovementComp)
	{
		MovementComp->StopMovementImmediately();
	}

	UP3StaminaPointComponent* StaminaComp = GetStaminaComponent();
	if (StaminaComp)
	{
		StaminaComp->FillUpStaminaPoint();
	}

	UP3ComboTableComponent* ComboTableComp = GetComboComponent();
	if (ComboTableComp)
	{
		ComboTableComp->OnRevive();
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		UP3PawnActionComponent* ActionComp = GetActionComponent();
		if (ActionComp)
		{
			ActionComp->Server_Reset();
		}
	}

	/*if (P3Core::IsP3NetModeClientInstance(*this) && IsLocalControlledActor(this))
	{
		APlayerController* PlayerController = Cast<APlayerController>(GetController());
		if (PlayerController && PlayerController->PlayerCameraManager)
		{
			PlayerController->PlayerCameraManager->SetManualCameraFade(0.0f, FLinearColor::Black, true);
		}
	}*/

	GetCapsuleComponent()->SetAllPhysicsAngularVelocityInRadians(FVector::ZeroVector);
	GetCapsuleComponent()->SetAllPhysicsLinearVelocity(FVector::ZeroVector);

	OnCharacterRevive.Broadcast();

	ReceiveReviveBP();
}

void AP3Character::OnHold(UP3HolderComponent* HolderComponnet, AActor* HoldingActor)
{	
	
}

void AP3Character::OnStash(UP3HolderComponent* HolderComponnet, AActor* StashingActor)
{

}

void AP3Character::OnHolderActorRemoved(UP3HolderComponent* HolderComponnet, AActor* StashingActor)
{

}

void AP3Character::OnPartBroken(class UP3PartComponent* InPartComponent)
{
	if (InPartComponent && InPartComponent->GetPartDesc().DisableMountPointGameplayTagOnBroken.Num() > 0)
	{
		for (int32 Index = 0; Index < MountPoints.Num(); ++Index)
		{
			const bool bHasDisableTag = MountPoints[Index].GameplayTagDisableByPart.HasAny(InPartComponent->GetPartDesc().DisableMountPointGameplayTagOnBroken);
			if (bHasDisableTag)
			{
				CharacterStore.DisabledMountPoints.AddUnique(Index);
			}
		}
	}
}

const UP3CharacterSounds* AP3Character::GetCharacterSounds() const
{
	const AP3Weapon* Weapon = Cast<AP3Weapon>(GetRightHandWeaponActor());
	
	if (Weapon && Weapon->GetCharacterSounds())
	{
		return Weapon->GetCharacterSounds();
	}
		
	return Sounds;
}

void AP3Character::GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const
{
	TagContainer = Net_GameplayTagContainer;
}

AActor* AP3Character::GetRightHandWeaponActor() const
{
	UP3HolderComponent* RightHandHolderComp = GetHolderComponentByHoldType(EP3HoldType::RightHand);

	if (!RightHandHolderComp)
	{
		return nullptr;
	}

	return RightHandHolderComp->GetHoldingActor();
}


AActor* AP3Character::GetHoldingActorByHoldType(EP3HoldType HoldType) const
{
	UP3HolderComponent* HolderComp = GetHolderComponentByHoldType(HoldType);

	if (HolderComp)
	{
		return HolderComp->GetHoldingActor();
	}

	return nullptr;
}

FP3HoldingKeyStatus AP3Character::GetHoldingKeyStatus() const
{
	return HoldingKeyStatus;
}

EP3WeaponType AP3Character::GetRightHandWeaponType() const
{
	AActor* HoldingActor = GetRightHandWeaponActor();
	if (!HoldingActor)
	{
		return EP3WeaponType::None;
	}

	const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(HoldingActor->GetClass()));
	if (!ensure(CmsHoldable))
	{
		return EP3WeaponType::None;
	}

	return CmsHoldable->WeaponType;
}

UP3HolderComponent* AP3Character::GetHolderComponentByHoldType(EP3HoldType HoldType) const
{
	TInlineComponentArray<UP3HolderComponent*> HolderComps;
	GetComponents(HolderComps);

	for (UP3HolderComponent* HolderComp : HolderComps)
	{
		if (HolderComp->GetHoldType() == HoldType)
		{
			return HolderComp;
		}
	}

	return nullptr;
}

UP3HolderComponent* AP3Character::GetRightHandHolderComponent() const
{
	UP3HolderComponent* HolderComp = GetHolderComponentByHoldType(EP3HoldType::RightHand);

	return HolderComp;
}

UP3HolderComponent* AP3Character::GetLeftHandHolderComponent() const
{
	UP3HolderComponent* HolderComp = GetHolderComponentByHoldType(EP3HoldType::LeftHand);

	return HolderComp;
}

#if WITH_EDITOR
void AP3Character::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	static const FName CmsCharacterKeyName = "CmsCharacterKey";

	if (PropertyChangedEvent.GetPropertyName() == CmsCharacterKeyName)
	{
		CombatSkills.Reset();

		TArray<const FP3CmsCombatSkill*> CmsCombatSkills = P3Cms::GetCharacterCombatSkills(CmsCharacterKey);
		for (const FP3CmsCombatSkill* CmsSkill : CmsCombatSkills)
		{
			CombatSkills.Add(*CmsSkill);
		}
	}
}

EDataValidationResult AP3Character::IsDataValid(TArray<FText>& ValidationErrors)
{
	EDataValidationResult Result = Super::IsDataValid(ValidationErrors);

	if (!P3Cms::IsLoaded())
	{
		P3Cms::Initialize();
	}

	// Check missing Hit CMS
	if (GetMesh() && GetMesh()->SkeletalMesh && GetMesh()->SkeletalMesh->Skeleton)
	{
		USkeleton* Skeleton = GetMesh()->SkeletalMesh->Skeleton;

		// Following codes are copied from USkeleton::CollectAnimationNotifies

		// need to verify if these pose is used by anybody else
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));

		// @Todo : remove it when we know the asset registry is updated
		// meanwhile if you remove this, this will miss the links
		//AnimationNotifies.Empty();
		TArray<FAssetData> AssetList;
		AssetRegistryModule.Get().GetAssetsByClass(UAnimSequenceBase::StaticClass()->GetFName(), AssetList, true);

		// do not clear AnimationNotifies. We can't remove old ones yet. 
		FString CurrentSkeletonName = FAssetData(Skeleton).GetExportTextName();
		for (auto Iter = AssetList.CreateConstIterator(); Iter; ++Iter)
		{
			const FAssetData& Asset = *Iter;
			const FString SkeletonValue = Asset.GetTagValueRef<FString>(TEXT("Skeleton"));
			if (SkeletonValue == CurrentSkeletonName)
			{
				UAnimSequenceBase* AnimSequence = Cast<UAnimSequenceBase>(Asset.ToSoftObjectPath().TryLoad());

				if (ensure(AnimSequence))
				{
					for (const FAnimNotifyEvent& NotifyEvent : AnimSequence->Notifies)
					{
						UAnimNotifyState_BoneAttack* BoneAttack = Cast<UAnimNotifyState_BoneAttack>(NotifyEvent.NotifyStateClass);

						if (BoneAttack)
						{
							const FName& CmsHitKey = BoneAttack->GetCmsCombatHitKey();

							if (!P3Cms::GetCombatHit(CmsHitKey))
							{
								FFormatNamedArguments Arguments;
								Arguments.Add(TEXT("CmsHitKey"), FText::AsCultureInvariant(CmsHitKey.ToString()));
								Arguments.Add(TEXT("CharacterActorName"), FText::AsCultureInvariant(GetName()));
								Arguments.Add(TEXT("AnimationName"), FText::AsCultureInvariant(AnimSequence->GetName()));

								FText ErrorMsg = FText::Format(FText::AsCultureInvariant(TEXT("CMS Hit Key {CmsHitKey} 가 CMS에 존재하지 않습니다. Character: {CharacterActorName}, Animation: {AnimationName}. 맵 체크에서 링크를 확인하세요.")), Arguments);
								ValidationErrors.Add(ErrorMsg);

								// Add to map check error
								FMessageLog("MapCheck").Error()
									->AddToken(FUObjectToken::Create(AnimSequence))
									->AddToken(FTextToken::Create(FText::Format(FText::AsCultureInvariant(TEXT("{CmsHitKey} : Cms Hit Key 가 CMS에 존재하지 않습니다.")), Arguments)));

								Result = EDataValidationResult::Invalid;
							}
						}
					}
				}
			}
		}
	}

	return Result;
}
#endif // WITH_EDITOR

int32 AP3Character::GetExperiencePoint() const
{
	return ExperienceComponent ? ExperienceComponent->GetExperiencePoint() : 0;
}

void AP3Character::Server_SetCharLevel(int32 InLevel)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	CharacterStore.CharLevel = InLevel;

	UP3AttributesComponent* AttributeComp = FindComponentByClass<UP3AttributesComponent>();
	if (AttributeComp)
	{
		AttributeComp->SetLevel(CharacterStore.CharLevel);
		AttributeComp->UpdateAttributes();
	}

	UP3World* P3World = P3Core::GetP3World(*this);

	if (P3World)
	{
		Server_SetDirty(*this);
		P3Core::GetP3World(*this)->GetServerWorld()->OnCharacterLevelChanged(*this);
	}
}

void AP3Character::Server_ShowHealthBar(bool bShow)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_bShowHealthBar == bShow)
	{
		return;
	}

	Net_bShowHealthBar = bShow;

	Server_SetDirty(*this);
}

//////////////////////////////////////////////////////////////////////////
// UP3ParkourData

int32 UP3ParkourData::GetNearestClimbUpMontageIndex(float Height) const
{
	float MinimumErorr = MAX_flt;
	int32 OutIndex = -1;

	for (int32 Index = 0; Index < ClimbUpMontages.Num(); ++Index)
	{
		const FP3ParkourClimbUpMontage& Montage = ClimbUpMontages[Index];

		const float Error = FMath::Abs(Montage.Height - Height);

		if (MinimumErorr > Error)
		{
			MinimumErorr = Error;
			OutIndex = Index;
		}
	}

	return OutIndex;
}


FGenericTeamId FactionToGenericTeamId(EP3Faction Faction)
{
	static_assert(TIsSame<__underlying_type(EP3Faction), uint8>::Value, TEXT("Faction must be uint8 to be conversion to FGenericTeamId"));

	return FGenericTeamId(static_cast<uint8>(Faction));
}

