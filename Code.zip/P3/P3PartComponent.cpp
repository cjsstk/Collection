// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PartComponent.h"

#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/Character.h"

#include "P3ActorInterface.h"
#include "P3AttributesComponent.h"
#include "P3Core.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3World.h"

#define PartCompJsonLog(Verbosity, Subject, ...) \
	P3JsonLogWithCategory(P3PartCompLog, Verbosity, Subject,	\
		TEXT("Owner"), GetOwner() ? GetOwner()->GetName() : TEXT("NULL"),	\
		TEXT("Part"), *GetName(), \
		##__VA_ARGS__)

extern TAutoConsoleVariable<int32> CVarP3HealthDebug;

UP3PartComponent::UP3PartComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3PartComponent::OnRegister()
{
	Super::OnRegister();

	if (DefaultSkeletalMesh)
	{
		const FName SkeletalMeshComponentName = MakeUniqueObjectName(GetOwner(), USkeletalMeshComponent::StaticClass(), GetFName());
		SkeletalMeshComponent = NewObject<USkeletalMeshComponent>(GetOwner(), SkeletalMeshComponentName, RF_Transient);
		if (ensure(SkeletalMeshComponent))
		{
			SkeletalMeshComponent->RegisterComponent();
			SkeletalMeshComponent->SetSkeletalMesh(DefaultSkeletalMesh);
			SkeletalMeshComponent->AttachToComponent(GetOwner()->GetRootComponent(), FAttachmentTransformRules::SnapToTargetIncludingScale);
			SkeletalMeshComponent->SetCanEverAffectNavigation(false);
			SkeletalMeshComponent->bUseAttachParentBound = true;
			SkeletalMeshComponent->bReceivesDecals = false;
			SkeletalMeshComponent->MarkRenderStateDirty();

			if (bUseCharacterAsMasterSkeleton)
			{
				ACharacter* Character = Cast<ACharacter>(GetOwner());
				if (Character)
				{
					SkeletalMeshComponent->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetIncludingScale);
					SkeletalMeshComponent->SetMasterPoseComponent(Character->GetMesh());
				}
			}
		}
	}
}

void UP3PartComponent::OnUnregister()
{
	Super::OnUnregister();

	if (SkeletalMeshComponent)
	{
		SkeletalMeshComponent->DestroyComponent();
		SkeletalMeshComponent = nullptr;
	}
}

void UP3PartComponent::BeginPlay()
{
	Super::BeginPlay();

	Net_bActivated = bActivatePartOnBegin;

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_InitHealthPoint();

		Server_RestoreTickAgeSeconds = GetWorld()->GetTimeSeconds() + PartDesc.RestoreTickSeconds;
	}
}

void UP3PartComponent::Server_SetBroken(bool bNewBroken)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	PartCompJsonLog(Display, "SetBroken", TEXT("OldBroken"), Net_bBroken, TEXT("NewBroken"), bNewBroken);

	Net_bBroken = bNewBroken;

	OnBrokenStatusChanged();

	Server_SetDirty(*this);
}

void UP3PartComponent::OnBrokenStatusChanged()
{
	PartCompJsonLog(Display, "OnBrokenStatusChanged", TEXT("Broken"), Net_bBroken);

	UpdateMesh();

	if (PartDesc.GameplayTagOnBroken.Num() > 0)
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(GetOwner());
		if (ensure(P3ActorInterface))
		{
			P3ActorInterface->AddGameplayTags(PartDesc.GameplayTagOnBroken);
		}
	}

	if (Net_bBroken)
	{
		OnPartBroken.Broadcast(this);
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (Net_bBroken && PartDesc.AutoRepairTimeSeconds > 0)
		{
			ensure(Server_RepairTimeSeconds == 0);
			Server_RepairTimeSeconds = GetWorld()->GetTimeSeconds() + PartDesc.AutoRepairTimeSeconds;
		}
	}
}

void UP3PartComponent::UpdateMesh()
{
	if (!SkeletalMeshComponent)
	{
		return;
	}

	USkeletalMesh* NewSkeletalMesh = nullptr;

	if (Net_bBroken)
	{
		NewSkeletalMesh = BrokenSkeletalMesh;
	}
	else
	{
		if (DamagedSkeltalMeshes.IsValidIndex(Net_DamagedMeshIndex))
		{
			NewSkeletalMesh = DamagedSkeltalMeshes[Net_DamagedMeshIndex];
		}
		else
		{
			NewSkeletalMesh = DefaultSkeletalMesh;
		}
	}

	if (NewSkeletalMesh)
	{
		PartCompJsonLog(Display, "UpdateMesh", TEXT("NewMesh"), *NewSkeletalMesh->GetName());
		SkeletalMeshComponent->SetSkeletalMesh(NewSkeletalMesh);

		// There may be overridden materials (from cut scene or somewhere)
		SkeletalMeshComponent->EmptyOverrideMaterials();
	}
}

void UP3PartComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (Server_RepairTimeSeconds != 0)
		{
			if (GetWorld()->GetTimeSeconds() > Server_RepairTimeSeconds)
			{
				Server_RepairTimeSeconds = 0;
				Server_SetHealthPoint(Server_MaxHealthPoint);
				PartCompJsonLog(Display, "Repaired");
			}
		}

		if (!Net_bBroken && PartDesc.RestoreTickSeconds > 0.0f
			&& Server_HealthPoint != Server_MaxHealthPoint
			&& GetWorld()->GetTimeSeconds() > Server_RestoreTickAgeSeconds)
		{
			Server_RestoreTickAgeSeconds = GetWorld()->GetTimeSeconds() + PartDesc.RestoreTickSeconds;
			const int32 NewHealthPoint = Server_GetHealthPoint() + PartDesc.RestoreHealthPointAmount;
			Server_SetHealthPoint(NewHealthPoint);
		}
	}

	if (CVarP3HealthDebug.GetValueOnGameThread() != 0)
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(GetOwner());
		if (P3ActorInterface)
		{
			P3ActorInterface->AddDebugString(FString::Printf(TEXT("[Part] %s. HP(%d/%d), Active: %s, Broken: %s")
				, *GetName(), Server_HealthPoint, Server_MaxHealthPoint
				, Net_bActivated ? TEXT("true") : TEXT("false")
				, Net_bBroken ? TEXT("true") : TEXT("false")));
		}
	}
}

void UP3PartComponent::Server_SetHealthPoint(int32 InHealthPoint)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Net_bActivated && Server_HealthPoint > InHealthPoint)
	{
		return;
	}

	Server_HealthPoint = FMath::Clamp(InHealthPoint, 0, Server_MaxHealthPoint);

	if (Server_HealthPoint == 0 && !Net_bBroken)
	{
		Server_SetBroken(true);
	}
	else if (Server_HealthPoint > 0 && Net_bBroken)
	{
		Server_SetBroken(false);
	}

	int32 NewDamagedMeshIndex = -1;

	if (DamagedSkeltalMeshes.Num() > 0 && Server_MaxHealthPoint > 0)
	{
		const float HealthRatio = (float)InHealthPoint / Server_MaxHealthPoint;
		const float HealthStep = HealthRatio * (DamagedSkeltalMeshes.Num() + 1);
		NewDamagedMeshIndex = FMath::Clamp(FMath::FloorToInt(HealthStep), 0, DamagedSkeltalMeshes.Num());

		if (NewDamagedMeshIndex == DamagedSkeltalMeshes.Num())
		{
			NewDamagedMeshIndex= -1;
		}
		else
		{
			// We invert this since it's more intuitive to editor UI
			NewDamagedMeshIndex = DamagedSkeltalMeshes.Num() - 1 - NewDamagedMeshIndex;
		}
	}

	if (Net_DamagedMeshIndex != NewDamagedMeshIndex)
	{
		PartCompJsonLog(Display, "DamagedMeshIndex changed", TEXT("Old"), Net_DamagedMeshIndex, TEXT("New"), NewDamagedMeshIndex);

		Net_DamagedMeshIndex = NewDamagedMeshIndex;

		UpdateMesh();

		Server_SetDirty(*this);
	}
}

void UP3PartComponent::Server_InitHealthPoint()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}
	
	UP3HealthPointComponent* HealthPointComponent = GetOwner()->FindComponentByClass<UP3HealthPointComponent>();
	if (HealthPointComponent)
	{
		Server_MaxHealthPoint = (HealthPointComponent->GetMaxHealthPoint() * PartDesc.HealthPointPermil / 1000);
		Server_HealthPoint = Server_MaxHealthPoint;
	}
	else
	{
		UP3AttributesComponent* AttributeComp = GetOwner()->FindComponentByClass<UP3AttributesComponent>();
		if (AttributeComp)
		{
			AttributeComp->UpdateAttributes();

			const int32 MaxHealthPoint = AttributeComp->GetAttribute(EP3Attribute::MaxHealth);

			Server_MaxHealthPoint = (MaxHealthPoint * PartDesc.HealthPointPermil / 1000);
			Server_HealthPoint = Server_MaxHealthPoint;
		}
	}
}

bool UP3PartComponent::CanBeDamagedByTemporaryWeaponType(EP3TemporaryWeaponType WeaponType) const
{
	return CanBeDamagedTemporaryWeaponTypes.Contains(WeaponType);
}

void UP3PartComponent::NetSerialize(FArchive& Archive)
{
	const bool bOldBroken = Net_bBroken;
	const int32 OldDamagedMeshIndex = Net_DamagedMeshIndex;

	Archive << Net_bBroken;
	Archive << Net_bActivated;
	Archive << Net_DamagedMeshIndex;

	if (CVarP3HealthDebug.GetValueOnGameThread() != 0)
	{
		Archive << Server_MaxHealthPoint;
		Archive << Server_HealthPoint;
		Archive << Server_RepairTimeSeconds;
		Archive << Server_RestoreTickAgeSeconds;
	}

	if (Archive.IsLoading() && bOldBroken != Net_bBroken)
	{
		OnBrokenStatusChanged();
	}

	if (Archive.IsLoading() && OldDamagedMeshIndex != Net_DamagedMeshIndex)
	{
		PartCompJsonLog(Display, "DamagedMeshIndex changed", TEXT("Old"), OldDamagedMeshIndex, TEXT("New"), Net_DamagedMeshIndex);

		UpdateMesh();
	}
}

void UP3PartComponent::OnPartDamaged(const FVector& HitLocation, const FVector& ImpactDirection)
{
	if (!Net_bActivated)
	{
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_LastHitDirection = ImpactDirection;
	}

	OnPartCombatDamaged.Broadcast(HitLocation);
}

void UP3PartComponent::Server_ActivatePart()
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		ensure(0);
		return;
	}

	PartCompJsonLog(Display, "Activated");

	Net_bActivated = true;

	Server_SetDirty(*this);
}

void UP3PartComponent::Server_DeactivatePart()
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		ensure(0);
		return;
	}

	PartCompJsonLog(Display, "Deactivated");

	Net_bActivated = false;

	Server_SetDirty(*this);
}
