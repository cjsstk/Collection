// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

/**
 * P3 Faction
 */
UENUM(Blueprintable)
enum class EP3Faction : uint8
{
	None,
	Player1,
	Player2,
	NPC1,
	NPC2,
};
