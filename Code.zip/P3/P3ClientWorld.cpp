// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3ClientWorld.h"

#include "Components/PrimitiveComponent.h"
#include "DrawDebugHelpers.h"
#include "EngineUtils.h"
#include "Engine/LevelStreaming.h"
#include "Engine/WorldComposition.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/GameModeBase.h"
#include "GameFramework/HUD.h"
#include "GameFramework/PlayerController.h"
#include "Http.h"
#include "HttpManager.h"
#include "PhysicsReplication.h"
#include "Kismet/GameplayStatics.h"

#include "Action/P3PawnActionComponent.h"
#include "Command/P3CommandComponent.h"
#include "Network/Lib/P3NetCore.h"
#include "Network/P3ChatNet.h"
#include "Network/P3DedimanHelper.h"
#include "Network/P3DediNet.h"
#include "Network/P3GoChatNet.h"
#include "Network/P3UDPENetClient.h"
#include "Network/P3UnrealUDPNet.h"
#include "P3Actor.h"
#include "P3AnimalCharacter.h"
#include "P3BGMPlayer.h"
#include "P3Character.h"
#include "P3CharacterMovementComponent.h"
#include "P3DestructibleComponent.h"
#include "P3GameInstance.h"
#include "P3GameMode.h"
#include "P3HealthPointComponent.h"
#include "P3InventoryComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3PlayerController.h"
#include "P3ServerWorld.h"
#include "P3StoreArchive.h"
#include "P3World.h"
#include "P3WorldNetCore.h"
#include "P3QuestComponent.h"
#include "World/P3WorldSystem.h"

extern TAutoConsoleVariable<int32> CVarP3WorldPacketProfile;
extern TAutoConsoleVariable<int32> CVarP3WorldDebugPacket;
extern TAutoConsoleVariable<int32> CVarP3CharacterMovementServerDriven;

TAutoConsoleVariable<int32> CVarP3ZoneDebug(
	TEXT("p3.zoneDebug"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ZoneAutoChange(
	TEXT("p3.zoneAutoChange"),
	1,
	TEXT("0: Off. 1: Change zone server by location (need dediman)"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3ZoneDisconnectOnEmpty(
	TEXT("p3.zoneDisconnectOnEmpty"),
	0,
	TEXT("If set 0, client will not disconnect from zone when it moves out of zone volume"), ECVF_Default);

static TAutoConsoleVariable<int32> CVarP3ZoneChangeForceFlush(
	TEXT("p3.zoneChangeForceFlush"),
	1,
	TEXT("If set 1, zone change process will be force flushed within same tick to avoid actor disappear artifact"), ECVF_Default);

TAutoConsoleVariable<int32> CVarP3WorldDebugTransform(
	TEXT("p3.worldDebugTransform"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3TODDebug(
	TEXT("p3.todDebug"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ActorDebug(
	TEXT("p3.actorDebug"),
	0,
	TEXT("0: Debug off. 1: Debug On"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3EnterWorldRetryIntervalSeconds(
	TEXT("p3.enterWorldRetryIntervalSeconds"),
	5.0f,
	TEXT("Retry interval if entering world fails"), ECVF_Default);

static void _ApplyNetAttachedLevelActors(TArray<FP3NetAttachedLevelActor>& NetAttachedLevelActors, AActor& Actor)
{
	for (const FP3NetAttachedLevelActor& NetAttach : NetAttachedLevelActors)
	{
		AActor* ChildActor = P3Core::FindActorByName(Actor.GetWorld(), NetAttach.ChildActorLevelName, NetAttach.ChildActorName);

		if (!ensure(ChildActor))
		{
			continue;
		}

		USceneComponent* ParentComponent = P3Core::GetActorComponentByName<USceneComponent>(Actor, NetAttach.AttachedComponentName);

		if (ensure(ParentComponent))
		{
			ChildActor->AttachToComponent(ParentComponent, FAttachmentTransformRules::KeepRelativeTransform, NetAttach.AttachedSocketName);
		}

		ChildActor->SetActorRelativeTransform(NetAttach.ChildRelativeTransform.ToTransform());
	}
}

static void _SyncReplicatedPhysicsSimulation(AActor* Actor)
{
	if (Actor->bReplicateMovement
		&& Actor->GetRootComponent()
		&& (Actor->GetRootComponent()->IsSimulatingPhysics() != Actor->ReplicatedMovement.bRepPhysics))
	{
		UPrimitiveComponent* RootPrimComp = Cast<UPrimitiveComponent>(Actor->GetRootComponent());
		if (RootPrimComp)
		{
			RootPrimComp->SetSimulatePhysics(Actor->ReplicatedMovement.bRepPhysics);

			if (!Actor->ReplicatedMovement.bRepPhysics)
			{
				if (UWorld* World = Actor->GetWorld())
				{
					if (FPhysScene* PhysScene = World->GetPhysicsScene())
					{
						if (FPhysicsReplication* PhysicsReplication = PhysScene->GetPhysicsReplication())
						{
							PhysicsReplication->RemoveReplicatedTarget(RootPrimComp);
						}
					}
				}
			}
		}
	}
}

static void _ApplyNetMovement(const FP3NetMovement& NetMovement, AActor* Actor)
{
	if (!ensure(Actor))
	{
		return;
	}

	if (!Actor->bReplicateMovement)
	{
		return;
	}

	if (Actor->GetAttachParentActor())
	{
		// Since FP3NetMovement is only used for non-attached actor, we can just detach here
		Actor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	}

	// Note OnRep_ReplicatedMovement crash at UCharacterMovementComponent::SmoothCorrection in debug build server instance
	//if (ensure(Actor->Role == ROLE_SimulatedProxy) && !P3Core::IsP3NetModeServerInstance(*Actor))
	// FIXME: turned off. ROLE_Standalone also crashed in debug build. got to fix them..
	if (1)
	{
		if (CVarP3WorldDebugTransform.GetValueOnGameThread() != 0)
		{
			DrawDebugDirectionalArrow(Actor->GetWorld(), Actor->GetActorLocation(), NetMovement.Location, 20.0f, FColor::Green, false, 5.0f);
		}

		Actor->ReplicatedMovement.LinearVelocity = NetMovement.LinearVelocity;
		Actor->ReplicatedMovement.AngularVelocity = NetMovement.AngularVelocity;
		Actor->ReplicatedMovement.Location = NetMovement.Location;
		Actor->ReplicatedMovement.Rotation = NetMovement.Rotation;
		Actor->ReplicatedMovement.bSimulatedPhysicSleep = NetMovement.bSimulatedPhysicSleep;
		Actor->ReplicatedMovement.bRepPhysics = NetMovement.bRepPhysics;

		Actor->OnRep_ReplicatedMovement();

		// TODO: UE4 original replication is optimzied with AActor::PreNetReceive(), AActor::PostNetReceive(). Mimic it!
		_SyncReplicatedPhysicsSimulation(Actor);
	}
	else
	{
		Actor->ReplicatedMovement.LinearVelocity = NetMovement.LinearVelocity;
		Actor->ReplicatedMovement.AngularVelocity = NetMovement.AngularVelocity;
		Actor->ReplicatedMovement.Location = NetMovement.Location;
		Actor->ReplicatedMovement.Rotation = NetMovement.Rotation;

		Actor->SetActorLocationAndRotation(NetMovement.Location, NetMovement.Rotation, false);
		Actor->PostNetReceiveVelocity(NetMovement.LinearVelocity);

		if (CVarP3WorldDebugTransform.GetValueOnGameThread() != 0)
		{
			DrawDebugDirectionalArrow(Actor->GetWorld(), Actor->GetActorLocation(), NetMovement.Location, 20.0f, FColor::Green, false, 5.0f);
		}
	}
}

void UP3ClientWorld::BeginPlay(UP3World* InP3World)
{
	check(InP3World);

	P3World = InP3World;

	InitConsoleCommands();
	AHUD::OnHUDPostRender.AddUObject(this, &UP3ClientWorld::OnHUDPostRender);

	UP3DedimanHelper* DedimanHelper = P3GetDedimanHelper(this);

	if (ensure(DedimanHelper))
	{
		DedimanHelper->OnAllocZoneChannel.AddUniqueDynamic(this, &UP3ClientWorld::OnDediInfo);
	}

	ensure(!P3Core::IsConnectedToDedi(this));

	SetDediConnectionState(EDediConnectionState::Closed);

	if (ensure(P3World->GetGameInstance()) && ensure(GetWorld()->GetAuthGameMode()))
	{
		// 클라이언트가 맵 로딩을 완료한 후 접속을 요청하기 위해 EDediConnectionState::MapLoading 로 기다림
		const FString& Options = GetWorld()->GetAuthGameMode()->OptionsString;
		const int32 DediConnect = UGameplayStatics::GetIntOption(Options, TEXT("DediConnect"), 0);

		if (DediConnect == 1)
		{
			SetDediConnectionState(EDediConnectionState::MapLoading);
		}
	}
}

void UP3ClientWorld::Shutdown()
{
	UP3DedimanHelper* DedimanHelper = P3GetDedimanHelper(this);

	if (DedimanHelper)
	{
		DedimanHelper->OnAllocZoneChannel.RemoveDynamic(this, &UP3ClientWorld::OnDediInfo);
	}

	AHUD::OnHUDPostRender.RemoveAll(this);
	CleanupConsoleCommands();
}

void UP3ClientWorld::Tick(float DeltaSeconds)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3World_Client_Tick"), STAT_P3World_Client_Tick, STATGROUP_P3);

	TickDediConnectionState();
	SendMovement();
	TickBGM();
	TickActorDebug();

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0)
	{
		PacketProfileWritingSeconds += DeltaSeconds;

		if (PacketProfileWritingSeconds > 5.0f)
		{
			for (int32 Index = 0; Index < ARRAY_COUNT(PacketProfileHistory.NumPackets); ++Index)
			{
				PacketProfileHistory.NumPackets[Index].ValueSort(TGreater<int32>());
			}

			PacketProfileResult = MoveTemp(PacketProfileHistory);
			PacketProfileResult.DurationSeconds = PacketProfileWritingSeconds;

			PacketProfileWritingSeconds = 0.0f;
		}
	}
}

void UP3ClientWorld::InitConsoleCommands()
{
}

void UP3ClientWorld::CleanupConsoleCommands()
{
}

void UP3ClientWorld::OnConnected()
{
	P3JsonWorldLog(Display, "Client Connected");

	ensure(MyCharacterActorId == INVALID_ACTORID);
	ensure(!FP3NetUtil::IsNetConnValid(EnterNetConnInfo));
	ensure(LastActorSyncedTimeSeconds == 0.0f);
	
	TemporalOwnActors.Empty();

	UP3GameInstance* GameInstance = P3World ? P3World->GetGameInstance() : nullptr;

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		APawn* LocalPawn = P3Core::GetLocalPawn(GetWorld());
		TArray<AActor*> LocalPawnsChildActors;

		if (ensure(LocalPawn))
		{
			LocalPawn->GetAttachedActors(LocalPawnsChildActors);
		}

		ensure(P3World->GetActors().Num() == 0);

		// We need to destroy any actors which is flagged as 'bNetLoadOnClient = false'
		// In Unreal network, this is done by ULevel::InitializeNetworkActors()
		UWorld* World = GetWorld();
		if (ensure(World))
		{
			for (FActorIterator ActorIter(World); ActorIter; ++ActorIter)
			{
				AActor* Actor = *ActorIter;

				if (Actor == LocalPawn)
				{
					continue;
				}

				// FixMe: This is workaround to avoid destroy game mode which is bNetLoadOnClient true
				IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
				if (ActorInterface == nullptr)
				{
					continue;
				}

				if (ActorInterface->IsLevelPersistence())
				{
					continue;
				}

				if (Actor && !Actor->bNetLoadOnClient)
				{
					Actor->Destroy(true);
				}
			}
		}

		// Initialize own actors
		actorid ActorId = 1;

		if (ensure(LocalPawn))
		{
			TemporalOwnActors.Add(ActorId++, LocalPawn);
		}

		for (AActor* Actor : LocalPawnsChildActors)
		{
			if (Cast<IP3ActorInterface>(Actor) == nullptr)
			{
				continue;
			}

			TemporalOwnActors.Add(ActorId++, Actor);
		}
	}
	else
	{
		TemporalOwnActors = P3World->GetActors();
	}

	FP3NetPlayerEnterWorld NetEnterWorld;
	NetEnterWorld.Account = GameInstance ? GameInstance->GetAccountName() : "Unknown";
	NetEnterWorld.Token = GameInstance ? GameInstance->GetAuthToken() : "";
	NetEnterWorld.CharacterId = GameInstance ? GameInstance->GetCharacterId() : 0;
	NetEnterWorld.Version = GameInstance ? GameInstance->GetVersion() : FP3Version();

	for (auto&& Iter : TemporalOwnActors)
	{
		const actorid ActorId = Iter.Key;
		const AActor* Actor = Iter.Value;

		if (Actor)
		{
			FP3NetPlayerOwnActor NetPlayerOwnActor;
			NetPlayerOwnActor.ActorId = ActorId;
			NetPlayerOwnActor.ClassName = Actor->GetClass()->GetPathName();
			NetPlayerOwnActor.Transform = Actor->GetActorTransform();

			NetEnterWorld.OwnActors.Add(NetPlayerOwnActor);
		}
	}

	if (ensure(GetWorld()))
	{
		// For the case when world connection is failed without any response
		LastEnterWorldFailTimeSeconds = GetWorld()->GetTimeSeconds();
	}

	SetDediConnectionState(EDediConnectionState::Connected);

	P3World->Client_SendPacketReliable((UP3ServerWorld*)(nullptr), INVALID_ACTORID, nullptr, NetEnterWorld, EP3NetComponentType::ServerWorld, &UP3ServerWorld::HandleEnter);

	++DediConnectedCount;

	if (GameInstance)
	{
		UP3GoChatNet* GoChatNet = GameInstance->GetGoChatNet();

		if (GoChatNet)
		{
			GoChatNet->Connect();
		}
	}
}

void UP3ClientWorld::OnConnectFailed()
{
	P3JsonWorldLog(Display, "Client ConnectFailed");

	SetDediConnectionState(EDediConnectionState::Closed);
}

void UP3ClientWorld::OnDisconnected()
{
	P3JsonWorldLog(Display, "Client Disconnected");

	MyCharacterActorId = INVALID_ACTORID;
	EnterNetConnInfo = FP3NetConnInfo();
	LastActorSyncedTimeSeconds = 0;

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		APawn* LocalPawn = P3Core::GetLocalPawn(GetWorld());

		if (LocalPawn)
		{
			if (CVarP3CharacterMovementServerDriven.GetValueOnGameThread() != 0)
			{
				LocalPawn->Role = ROLE_Authority;
			}
		}

		AP3Character* Character = Cast<AP3Character>(LocalPawn);
		if (Character)
		{
			Character->Client_OnDisconnected();
		}

		// Remove every P3 World Actors except local player character
		TMap<int64, AActor*> OldActors = P3World->Actors;
		for (auto&& Iter : OldActors)
		{
			AActor* Actor = Iter.Value;
			if (!Actor)
			{
				continue;
			}

			IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
			if (ensure(ActorInterface))
			{
				ActorInterface->SetActorId(INVALID_ACTORID);
			}

			if (ActorInterface && ActorInterface->IsLevelPersistence())
			{
				continue;
			}

			if (Actor == LocalPawn)
			{
				// Skip my character
				continue;
			}

			OnActorRemoved(Iter.Value);

			Actor->Destroy(true);
			P3World->Actors.Remove(Iter.Key);
		}

		for (auto&& Iter : P3World->Actors)
		{
			OnActorRemoved(Iter.Value);
		}

		P3World->Actors.Empty();
	}

	SetDediConnectionState(EDediConnectionState::Closed);

	if (ensure(P3World->GetGameInstance()))
	{
		P3World->GetGameInstance()->SetServerVersion(FP3Version());
	}

	if (ChangeWorldProgress.Status == FChangeWorld::EStatus::ClosingDediNet)
	{
		ensure(!ChangeWorldProgress.NewLevelName.IsEmpty());

		UGameplayStatics::OpenLevel(this, FName(*ChangeWorldProgress.NewLevelName));

		ChangeWorldProgress.Status = FChangeWorld::EStatus::LoadingLevel;

		// 맵 로딩이 완료될 때까지 데디 접속을 연기함
		SetDediConnectionState(EDediConnectionState::MapLoading);
	}

	Players.Empty();
	OnPlayersListChanged.Broadcast();
}

AP3Character* UP3ClientWorld::FindPlayerCharacterByName(const FText& Name) const
{
	for (AP3Character* Character : CharacterActors)
	{
		if (Character
			&& Character->IsPlayerControlled()
			&& Character->GetCharacterStoreBP().DisplayName.EqualToCaseIgnored(Name))
		{
			return Character;
		}
	}

	return nullptr;
}

void UP3ClientWorld::ChangeWorld(const FString& LevelName)
{
	if (ChangeWorldProgress.Status != FChangeWorld::EStatus::None)
	{
		ensure(0);
		P3JsonLog(Error, "Change world is requested but already in progress",
			TEXT("In-progress level name"), ChangeWorldProgress.NewLevelName,
			TEXT("Requested level name"), LevelName);
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return;
	}

	ChangeWorldProgress.Status = FChangeWorld::EStatus::ClosingDediNet;
	ChangeWorldProgress.NewLevelName = LevelName;

	DisconnectFromDedi();
}

void UP3ClientWorld::HandleEnterResponse(const FP3DediToClientHandlerParams& Params)
{
	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return;
	}

	APawn* LocalPawn = P3Core::GetLocalPawn(GetWorld());

	FP3NetPlayerEnterWorldResponse NetResponse;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetResponse);

	if (ensure(bSerializeSucceeded))
	{
		if (ensure(P3World->GetGameInstance()))
		{
			P3World->GetGameInstance()->SetServerVersion(NetResponse.ServerVersion);
		}

		ZoneChannelId = NetResponse.ZoneChannelId;
		LastEnterWorldFailTimeSeconds = 0.0f;

		P3World->TimeOfDay.TimeOfDayInSeconds = NetResponse.TimeOfDayInSeconds;
		P3World->TimeOfDay.GameTimeToTimeOfDayRatio = NetResponse.GameTimeToTimeOfDayRatio;

		for (auto&& Iter : NetResponse.RemapOwnActors)
		{
			const actorid OldId = Iter.Key;
			const actorid NewId = Iter.Value;

			if (OldId == INVALID_ACTORID)
			{
				ensure(0);
				continue;
			}

			AActor** ActorPtr = TemporalOwnActors.Find(OldId);

			if (ensure(ActorPtr))
			{
				ensure(NewId != INVALID_ACTORID);

				TemporalOwnActors.Remove(OldId);
				P3World->Actors.Add(NewId, *ActorPtr);
				
				OnActorAdded(*ActorPtr);

				IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(*ActorPtr);
				if (ensure(ActorInterface))
				{
					ActorInterface->SetActorId(NewId);
				}

				if (*ActorPtr && *ActorPtr == LocalPawn)
				{
					MyCharacterActorId = NewId;
				}

				UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork();

				if (UDPNetwork)
				{
					UDPNetwork->Client_SetChannelActor(NewId, *ActorPtr, true);
				}
			}
		}

		ensure(TemporalOwnActors.Num() == 0);
		ensure(MyCharacterActorId != INVALID_ACTORID);

		TemporalOwnActors.Empty();
	}

	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		if (LocalPawn)
		{
			if (CVarP3CharacterMovementServerDriven.GetValueOnGameThread() != 0)
			{
				LocalPawn->Role = ROLE_AutonomousProxy;

				AP3Character* Character = Cast<AP3Character>(LocalPawn);
				if (Character)
				{
					if (Character->GetCharacterMovement())
					{
						Character->GetCharacterMovement()->bEnablePhysicsInteraction = false;
					}
				}
			}
			else
			{
				LocalPawn->Role = ROLE_Authority;
			}
		}
	}

	EnterNetConnInfo = Params.NetConnInfo;
}

void UP3ClientWorld::HandleEnterFailResponse(const FP3DediToClientHandlerParams& Params)
{
	FP3NetPlayerEnterWorldFailResponse NetResponse;
	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetResponse);
	if (!ensure(bSerializeSucceeded))
	{
		P3JsonLog(Error, "Failed to deserialize FP3NetPlayerEnterWorldFailResponse");
		return;
	}

	UWorld* World = GetWorld();
	if (!ensure(World))
	{
		P3JsonLog(Error, "No world");
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(World->GetFirstPlayerController());
	if (!ensure(PlayerController))
	{
		P3JsonLog(Error, "No player controller");
		return;
	}

	P3JsonLog(Error, "Failed to enter world", TEXT("Message"), *NetResponse.DebugMessage);

#if UE_BUILD_SHIPPING
	PlayerController->ToastMessageBP(P3LOC_LOGIN("FailedToEnterDedi"));
#else
	PlayerController->ToastMessageBP(FText::AsCultureInvariant(NetResponse.DebugMessage));
#endif

	LastEnterWorldFailTimeSeconds = World->GetTimeSeconds();
}

void UP3ClientWorld::HandlePlayerList(const FP3DediToClientHandlerParams& Params)
{
	FP3NetClientPlayers Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		Players = Packet.Players;
		OnPlayersListChanged.Broadcast();
	}
}

void UP3ClientWorld::HandleSpawnActor(const FP3DediToClientHandlerParams& Params)
{
	FP3NetSpawnActorParams NetParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		SpawnActor(NetParams);

		if (ensure(P3World))
		{
			AActor* Actor = P3World->GetActorFromActorId(NetParams.ActorId);

			if (ensure(Actor))
			{
				if (ensure(P3World->GetGameInstance()))
				{
					UP3UDPNetwork* UDPNetwork = P3World->GetGameInstance()->GetUDPNetwork();

					if (UDPNetwork)
					{
						UDPNetwork->Client_SetChannelActor(NetParams.ActorId, Actor, false);
					}
				}
			}
		}
	}
}

void UP3ClientWorld::HandleDestroyActor(const FP3DediToClientHandlerParams& Params)
{
	FP3NetActorId NetActorId;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetActorId);

	if (ensure(bSerializeSucceeded))
	{
		DestroyActor(NetActorId.ActorId);
	}
}

void UP3ClientWorld::HandleSyncActorStore(const FP3DediToClientHandlerParams& Params)
{
	FP3NetActorStoreData NetActorStoreData;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetActorStoreData);

	if (!ensure(bSerializeSucceeded))
	{
		return;
	}

	AActor* Actor = Params.Actor ? Params.Actor : P3World->GetActorFromActorId(NetActorStoreData.ActorId);

	if (!ensure(Actor))
	{
		return;
	}

	IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);

	if (ensure(ActorInterface))
	{
		if (NetActorStoreData.ActorStoreData.Num() > 0)
		{
			// TODO: BitReader expect non const buffer strangely.... got to fix that...
			TArray<uint8> TmpBuffer = NetActorStoreData.ActorStoreData;

			FP3StoreBitReader BitReader(P3Core::GetP3World(*this), TmpBuffer.GetData(), TmpBuffer.Num() * sizeof(uint8) * 8);
			ActorInterface->NetSerialize(BitReader);

			ensure(!BitReader.IsError());
		}

		if (NetActorStoreData.ComponentStoreData.Num() > 0)
		{
			UP3StoreComponent* StoreComponent = ActorInterface->GetStoreComponent();
			if (StoreComponent)
			{
				StoreComponent->SyncWithNetBuffer(nullptr, NetActorStoreData.ComponentStoreData);
			}
		}
	}

	_ApplyNetAttachedLevelActors(NetActorStoreData.AttachedLevelActors, *Actor);
}

void UP3ClientWorld::HandleActorSyncEnd(const FP3DediToClientHandlerParams& Params)
{
	LastActorSyncedTimeSeconds = GetWorld()->GetTimeSeconds();
}

void UP3ClientWorld::HandleSyncActorTransform(const FP3DediToClientHandlerParams& Params)
{
	FP3NetActorTransform NetActorTransform;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacketNonStruct(P3World, Params.Buffer, NetActorTransform);

	if (!ensure(bSerializeSucceeded))
	{
		return;
	}

	SyncActorTransform(Params.Actor, NetActorTransform);
}

void UP3ClientWorld::SpawnActor(const FP3NetSpawnActorParams& Params)
{
	P3JsonWorldLog(Verbose, "Client_SpawnActor",
		TEXT("ActorId"), Params.ActorId,
		TEXT("Class"), Params.ClassName,
		TEXT("NetMode"), P3Core::GetNetModeStr(P3Core::GetP3NetMode(GetWorld())));

	AActor* Actor = nullptr;

	if (((P3Core::GetP3NetMode(GetWorld()) == EP3NetMode::Standalone)
		|| (P3Core::GetP3NetMode(GetWorld()) == EP3NetMode::ListenServer)))
	{
		ensure(Params.StandaloneActorPointer != 0);
		Actor = reinterpret_cast<AActor*>(Params.StandaloneActorPointer);

		if (!ensure(Actor))
		{
			P3JsonWorldLog(Error, "Failed to spawn client actor with pointer",
				TEXT("ActorId"), Params.ActorId,
				TEXT("Class"), Params.ClassName,
				TEXT("NetMode"), P3Core::GetNetModeStr(P3Core::GetP3NetMode(GetWorld())));
			return;
		}
	}
	else if (Params.bLevelPersistence)
	{
		Actor = P3Core::FindActorByName(GetWorld(), Params.LevelName, Params.ActorName);

		if (!ensure(Actor))
		{
			P3JsonWorldLog(Error, "Failed to spawn persistence client actor",
				TEXT("ActorId"), Params.ActorId, TEXT("Class"), Params.ClassName, TEXT("ActorName"), Params.ActorName);

			// TODO: send Server_HandleClientSpawnActorFailed
			return;
		}

		Actor->Role = ROLE_SimulatedProxy;
	}
	else
	{
		const double StartTime = FPlatformTime::Seconds();

		UClass* ActorClass = StaticLoadClass(AActor::StaticClass(), NULL, *Params.ClassName);

		if (!ensure(ActorClass))
		{
			P3JsonWorldLog(Error, "Failed to spawn client actor. Can't find class",
				TEXT("ActorId"), Params.ActorId, TEXT("Class"), Params.ClassName);
			return;
		}

		FActorSpawnParameters SpawnParams;
		SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		SpawnParams.bDeferConstruction = true;
		SpawnParams.bRemoteOwned = true;
		SpawnParams.bNoFail = true;

		FTransform Transform(Params.Rotation, Params.Location, Params.Scale3D);

		ensure(GetWorld()->GetAuthGameMode());

		Actor = GetWorld()->SpawnActor<AActor>(ActorClass, Transform, SpawnParams);

		if (!ensure(Actor))
		{
			P3JsonWorldLog(Error, "Failed to spawn client actor",
				TEXT("ActorId"), Params.ActorId, TEXT("Class"), Params.ClassName);
			return;
		}

		AP3Character* Character = Cast<AP3Character>(Actor);
		if (Character)
		{
			Character->Client_SetServerGameTimeSinceCreation(Params.GameTimeSinceCreation);
		}

		Actor->FinishSpawning(Transform);
		Actor->PostNetInit();

		const double Duration = FPlatformTime::Seconds() - StartTime;

		if (Duration > 0.01f)
		{
			UE_LOG(P3WorldLog, Display, TEXT("Spawn took %.2f ms: Actor(%lld) Name(%s)"), Duration * 0.001, Params.ActorId, *Actor->GetName());
		}
	}

	UP3StoreComponent* StoreComponent = Actor->FindComponentByClass<UP3StoreComponent>();
	if (StoreComponent && Params.StoreData.Num() > 0)
	{
		StoreComponent->SyncWithNetBuffer(nullptr, Params.StoreData);
	}


	Actor->Tags.Add(NAME_ClientActor);

	if (((P3Core::GetP3NetMode(GetWorld()) == EP3NetMode::Standalone) 
		|| (P3Core::GetP3NetMode(GetWorld()) == EP3NetMode::ListenServer)))
	{
		ensure(P3World->Actors.Find(Params.ActorId) != nullptr);
	}
	else
	{
		ensure(P3World->Actors.Find(Params.ActorId) == nullptr);
	}

	P3World->Actors.Add(Params.ActorId, Actor);

	OnActorAdded(Actor);

	IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Actor);
	if (ensure(ActorInterface))
	{
		ActorInterface->SetActorId(Params.ActorId);
	}
}

void UP3ClientWorld::DestroyActor(actorid ActorId)
{
	AActor** ActorPtr = P3World ? P3World->Actors.Find(ActorId) : nullptr;

	if (ActorPtr)
	{
		OnActorRemoved(*ActorPtr);

		if (*ActorPtr)
		{
			(*ActorPtr)->Destroy(true);

			IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(*ActorPtr);
			if (ensure(ActorInterface))
			{
				ActorInterface->SetActorId(INVALID_ACTORID);
			}
		}

		P3World->Actors.Remove(ActorId);
	}
}

void UP3ClientWorld::SyncActorTransform(AActor* Actor, const FP3NetActorTransform& NetTransform)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3World_Client_SyncActorTransform"), STAT_P3World_Client_SyncActorTransform, STATGROUP_P3);

	if (NetTransform.ActorId == MyCharacterActorId)
	{
		// TODO: do what we need to do
		return;
	}

	if (!Actor)
	{
		Actor = P3World->GetActorFromActorId(NetTransform.ActorId);

		if (!Actor)
		{
			// In case if standalone/listen, actor can be already removed from Actors list by Server P3World, otherwise it should never happen
			ensure(P3Core::IsP3NetModeServerInstance(*this));
			return;
		}
	}

	if (!Actor->bReplicateMovement)
	{
		return;
	}

	bool bAttachChanged = false;

	//if (NetTransform.AttachedActorId != INVALID_ACTORID)
	if (NetTransform.bAttached)
	{
		//AActor** AttachedParentActorPtr = P3World->Actors.Find(NetTransform.AttachedActorId);

		//if (!AttachedParentActorPtr || !(*AttachedParentActorPtr))
		//{
		//	// This could happen if parent actor is not spawned yet
		//	return;
		//}

		if (!NetTransform.AttachedComponent)
		{
			// This could happen if parent actor is not spawned yet
			return;
		}

		//AActor* AttachedParentActor = *AttachedParentActorPtr;

		bool bIsAttachValid = true;

		//if (Actor->GetAttachParentActor() != AttachedParentActor
		if ((Actor->GetRootComponent() && Actor->GetRootComponent()->GetAttachParent() != NetTransform.AttachedComponent)
			|| Actor->GetAttachParentSocketName() != NetTransform.AttachedSocketName)
		{
			//USceneComponent* AttachedComp = P3Core::GetActorComponentByName<USceneComponent>(*AttachedParentActor, NetTransform.AttachedComponentName);
			USceneComponent* AttachedComp = NetTransform.AttachedComponent;

			if (ensure(AttachedComp))
			{
				UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(Actor->GetRootComponent());
				if (PrimComp)
				{
					PrimComp->SetSimulatePhysics(false);
				}

				const bool bSucceeded = Actor->GetRootComponent()->AttachToComponent(AttachedComp, FAttachmentTransformRules::KeepWorldTransform, NetTransform.AttachedSocketName);
				ensure(bSucceeded);

				bIsAttachValid = bSucceeded;
				bAttachChanged = bSucceeded;
			}
		}

		if (bIsAttachValid)
		{
			Actor->SetActorRelativeTransform(NetTransform.Transform.ToTransform());

			if (CVarP3WorldDebugTransform.GetValueOnGameThread() != 0)
			{
				DrawDebugSphere(Actor->GetWorld(), Actor->GetActorLocation(), 50.0f, 12, FColor::Blue);
			}
		}
	}
	else
	{
		if (Actor->GetAttachParentActor())
		{
			ensureMsgf(0, TEXT("ActorName: %s, LocalParentActorName"), *Actor->GetName(), *Actor->GetAttachParentActor()->GetName());

			Actor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

			bAttachChanged = true;
		}

		Actor->SetActorRelativeTransform(NetTransform.Transform.ToTransform());

		if (CVarP3WorldDebugTransform.GetValueOnGameThread() != 0)
		{
			DrawDebugSphere(Actor->GetWorld(), NetTransform.Transform.Translation, 50.0f, 12, FColor::Blue);
		}
	}

	if (bAttachChanged)
	{
		AP3Actor* P3Actor = Cast<AP3Actor>(Actor);
		if (P3Actor)
		{
			P3Actor->Client_NetAttachChanged();
		}
	}

	++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_ActorClassNameReceived].FindOrAdd((Actor)->GetClass()->GetFName());
	++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_ActorNameReceived].FindOrAdd((Actor)->GetFName());
}

void UP3ClientWorld::SendMovement()
{
	if (CVarP3CharacterMovementServerDriven.GetValueOnGameThread() != 0)
	{
		return;
	}

	if (MyCharacterActorId == INVALID_ACTORID)
	{
		return;
	}

	if (!P3Core::IsConnectedToDedi(this))
	{
		return;
	}

	AActor* MyActor = P3World->GetActorFromActorId(MyCharacterActorId);

	if (ensure(MyActor))
	{
		if (MyActor->GetAttachParentActor())
		{
			FP3NetActorTransform NetActorTransform;
			NetActorTransform.ActorId = MyCharacterActorId;
			NetActorTransform.Transform = MyActor->GetActorTransform();

			P3World->Client_SendPacketReliable((UP3ServerWorld*)(nullptr), INVALID_ACTORID, MyActor, NetActorTransform, EP3NetComponentType::None, &UP3ServerWorld::HandleSyncActorTransform);
		}
		else
		{
			MyActor->GatherCurrentMovement();

			// NOTE: Reference AActor::GatherCurrentMovement()
			FP3NetMovement NetMovement;
			NetMovement.ActorId = MyCharacterActorId;
			NetMovement.LinearVelocity = MyActor->ReplicatedMovement.LinearVelocity;
			NetMovement.AngularVelocity = MyActor->ReplicatedMovement.AngularVelocity;
			NetMovement.Location = MyActor->ReplicatedMovement.Location;
			NetMovement.Rotation = MyActor->ReplicatedMovement.Rotation;
			NetMovement.bSimulatedPhysicSleep = MyActor->ReplicatedMovement.bSimulatedPhysicSleep;
			NetMovement.bRepPhysics = MyActor->ReplicatedMovement.bRepPhysics;

			P3World->Client_SendPacketReliable((UP3ServerWorld*)(nullptr), INVALID_ACTORID, MyActor, NetMovement, EP3NetComponentType::None, &UP3ServerWorld::HandleSyncActorMovement);

			AP3Character* Character = Cast<AP3Character>(MyActor);
			if (Character)
			{
				FP3StoreBitWriter BitWriter(P3World, 256, true);
				Character->NetSerializeMovement(BitWriter);
				ensure(!BitWriter.IsError());

				FP3NetActorIdAndByteArray NetData;
				NetData.ActorId = MyCharacterActorId;
				NetData.ByteArray = *BitWriter.GetBuffer();

				P3World->Client_SendPacket((UP3ServerWorld*)(nullptr), INVALID_ACTORID, MyActor, NetData, EP3NetComponentType::None, &UP3ServerWorld::HandleCharacterMovement);
			}
		}
	}
}

void UP3ClientWorld::TickActorDebug()
{
	if (CVarP3ActorDebug.GetValueOnGameThread() == 0)
	{
		return;
	}

	if (!P3World)
	{
		return;
	}

	APawn* LocalPawn = P3Core::GetLocalPawn(GetWorld());

	if (!LocalPawn)
	{
		return;
	}

	const FVector LocalPawnLocation = LocalPawn->GetActorLocation();

	for (auto&& Iter : P3World->Actors)
	{
		AActor* Actor = Iter.Value;

		if (!Actor)
		{
			continue;
		}

		IP3ActorInterface* P3Actor = Cast<IP3ActorInterface>(Actor);

		if (!P3Actor)
		{
			continue;
		}

		const float DistanceSquared = (Actor->GetActorLocation() - LocalPawnLocation).SizeSquared();

		if (DistanceSquared < FMath::Square(5000))
		{
			const FString DebugString = FString::Printf(TEXT("[%ld] %s"), P3Actor->GetActorId(), *Actor->GetName());

			P3Actor->AddDebugString(DebugString);
		}
	}
}

void UP3ClientWorld::SetDediConnectionState(EDediConnectionState State)
{
	P3JsonLog(Display, "SetDediConnectionState",
		TEXT("From"), EnumToStringShort(EDediConnectionState, DediConnectionState),
		TEXT("To"), EnumToStringShort(EDediConnectionState, State));

	DediConnectionState = State;
}

bool UP3ClientWorld::UpdateCurrentTileZoneNames()
{
	UWorld* World = GetWorld();

	if (!ensure(World) || !World->WorldComposition)
	{
		return false;
	}

	APawn* LocalPawn = P3Core::GetLocalPawn(World);

	if (!LocalPawn)
	{
		return false;
	}

	bool bUpdated = false;

	const FName ZoneName = P3World->GetZoneFromLocation(LocalPawn->GetActorLocation());

	if (CVarP3ZoneDisconnectOnEmpty.GetValueOnGameThread() == 0)
	{
		if (ZoneName == NAME_None)
		{
			return false;
		}
	}

	CurrentTileZoneNames.Empty();
	CurrentTileZoneNames.Add(ZoneName);

	bUpdated = true;

	return bUpdated;
}

void UP3ClientWorld::TickDediConnectionState()
{
	switch (DediConnectionState)
	{
	case EDediConnectionState::MapLoading:
		TickDediConnectionStateMapLoading();
		break;

	case EDediConnectionState::Connected:
		TickDediConnectionStateConnected();
		break;

	case EDediConnectionState::Closed:
		TickDediConnectionStateClosed();
		break;
	}
}

void UP3ClientWorld::TickDediConnectionStateMapLoading()
{
	if (!ensure(DediConnectionState == EDediConnectionState::MapLoading))
	{
		return;
	}

	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return;
	}

	UWorld* World = GetWorld();

	if (!ensure(World) || !ensure(World->GetAuthGameMode()))
	{
		return;
	}

	if (World->WorldComposition)
	{
		int32 NumPendingLevels = 0;
		int32 NumLoadedLevels = 0;
		for (ULevelStreaming* LevelStreaming : World->GetStreamingLevels())
		{
			if (LevelStreaming->HasLoadRequestPending())
			{
				++NumPendingLevels;
			}

			if (LevelStreaming->HasLoadedLevel())
			{
				++NumLoadedLevels;
			}
		}

		//UE_LOG(P3Log, Display, TEXT("NumPendingLevels: %d/%d/%d"), NumPendingLevels, NumLoadedLevels, World->GetStreamingLevels().Num());

		if (NumLoadedLevels == 0 || NumPendingLevels > 0)
		{
			return;
		}
	}

	// 맵로딩 완료, 데디 접속 시작

	if (ChangeWorldProgress.Status == FChangeWorld::EStatus::LoadingLevel)
	{
		ChangeWorldProgress.Status = FChangeWorld::EStatus::None;
		ChangeWorldProgress.NewLevelName.Empty();
	}

	AGameModeBase* GameMode = World->GetAuthGameMode();

	if (!ensure(GameMode))
	{
		return;
	}

	const FString& Options = GameMode->OptionsString;
	const FString DediAddress = UGameplayStatics::ParseOption(Options, TEXT("DediAddress"));
	const FString DediZone = UGameplayStatics::ParseOption(Options, TEXT("DediZone"));

	UP3DediNet* DediNet = GameInstance->GetDediNet();

	if (DediNet)
	{
		const int32 DediPort = UGameplayStatics::GetIntOption(Options, TEXT("DediPort"), 0);

		ensure(DediNet->GetConnStatus() == EP3NetConnStatus::Closed);
		DediNet->SetHost(DediAddress);
		DediNet->SetPort(DediPort);
		DediNet->SetZone(FName(*DediZone));
		DediNet->Connect();
	}
	else
	{
		UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork();

		ensure(UDPNetwork->Client_GetConnStatus() == EP3NetConnStatus::Closed);

		const int32 UDPPort = UGameplayStatics::GetIntOption(Options, TEXT("Port"), 0);

		UDPNetwork->SetZone(FName(*DediZone));

		UDPNetwork->Init(P3World, DediAddress, UDPPort);
	}

	// Connect chat server only if connect to dedi server

	UP3ChatNet* ChatNet = P3World->GetGameInstance()->GetChatNet();

	if (ensure(ChatNet))
	{
		ChatNet->Connect();
	}

	SetDediConnectionState(EDediConnectionState::Connecting);
}

void UP3ClientWorld::FlushZoneChangeTicks()
{
	UWorld* World = GetWorld();

	if (!bZoneAutoChange || !World || !World->WorldComposition)
	{
		return;
	}
	
	UP3GameInstance* GameInstance = P3Core::GetP3GameInstance(*this);
	check(GameInstance);

	const float TimeLimitSeconds = 60.0f;
	const float AbortAtSeconds = FPlatformTime::Seconds() + TimeLimitSeconds;

	// Wait until connection closed (OnDisconnected)
	while (DediConnectionState != EDediConnectionState::Closed)
	{
		GameInstance->ForceTickNet(0.1f);

		if (FPlatformTime::Seconds() > AbortAtSeconds)
		{
			ensure(0);
			return;
		}
	}

	ensure(LastActorSyncedTimeSeconds == 0.0f);

	// Get Dedi info
	TickDediConnectionStateClosed();

	//if (!ensure(DediConnectionState == EDediConnectionState::WaitDediInfo))
	if (DediConnectionState != EDediConnectionState::WaitDediInfo)
	{
		return;
	}

	// Wait for dedi info (OnDediInfo)
	while (DediConnectionState != EDediConnectionState::Connecting)
	{
		FHttpModule::Get().GetHttpManager().Tick(0.1f);
			   
		if (FPlatformTime::Seconds() > AbortAtSeconds)
		{
			ensure(0);
			return;
		}
	}

	// New connection must be requested at OnDediInfo
	if (!ensure(DediConnectionState == EDediConnectionState::Connecting))	// -V547
	{
		return;
	}

	// Wait for connection (OnConnected)
	while (DediConnectionState != EDediConnectionState::Connected)
	{
		GameInstance->ForceTickNet(0.1f);
			   
		if (FPlatformTime::Seconds() > AbortAtSeconds)
		{
			ensure(0);
			return;
		}
	}
	
	// Enter world is requested from OnConnected

	// Wait for enter world response
	while (!FP3NetUtil::IsNetConnValid(EnterNetConnInfo))
	{
		GameInstance->ForceTickNet(0.1f);
			   
		if (FPlatformTime::Seconds() > AbortAtSeconds)
		{
			ensure(0);
			return;
		}
	}

	// Wait for actor sync
	while (LastActorSyncedTimeSeconds == 0.0f)
	{
		GameInstance->ForceTickNet(0.1f);

		FPlatformProcess::Sleep(0.01f);
			   
		if (FPlatformTime::Seconds() > AbortAtSeconds)
		{
			ensure(0);
			return;
		}
	}
}

bool UP3ClientWorld::IsSequencePossessedObject(const UObject& Object) const
{
	if (P3World)
	{
		return P3World->IsSequencePossessedObject(Object);
	}

	return false;
}

void UP3ClientWorld::TickDediConnectionStateConnected()
{
	if (!ensure(DediConnectionState == EDediConnectionState::Connected))
	{
		return;
	}

	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return;
	}

	if (CVarP3ZoneAutoChange.GetValueOnGameThread() == 0)
	{
		return;
	}

	if (!bZoneAutoChange)
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!ensure(World) || !World->WorldComposition)
	{
		return;
	}

	UP3DediNet* DediNet = P3GetDediNet(this);
	UP3UDPNetwork* UDPNetwork = nullptr;

	if (DediNet)
	{
		// Ensure dedi conn status
		if (!ensure(DediNet->GetConnStatus() == EP3NetConnStatus::Connected))
		{
			return;
		}
	}
	else
	{
		UDPNetwork = GameInstance->GetUDPNetwork();

		if (UDPNetwork)
		{
			if (!ensure(UDPNetwork->Client_GetConnStatus() == EP3NetConnStatus::Connected))
			{
				return;
			}
		}
		else
		{
			checkf(0, TEXT("No available network"));
			return;
		}
	}

	bool bUpdated = UpdateCurrentTileZoneNames();

	if (bUpdated)
	{
		FName CurrentZone = DediNet ? DediNet->GetZone() : (UDPNetwork ? UDPNetwork->GetZone() : NAME_None);

		ensure(!CurrentZone.ToString().IsEmpty());

		if (!CurrentTileZoneNames.Contains(CurrentZone))
		{
			P3JsonLog(Display, "Out of zone", TEXT("Current"), *CurrentZone.ToString());

			DisconnectFromDedi();

			if (CVarP3ZoneChangeForceFlush.GetValueOnGameThread() != 0)
			{
				FlushZoneChangeTicks();
			}
		}
	}
}

void UP3ClientWorld::TickDediConnectionStateClosed()
{
	if (DediConnectedCount == 0)
	{
		return;
	}

	if (CVarP3ZoneAutoChange.GetValueOnGameThread() == 0)
	{
		return;
	}

	if (!bZoneAutoChange)
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!ensure(World))
	{
		return;
	}

	UP3GameInstance* GameInstance = Cast<UP3GameInstance>(World->GetGameInstance());
	if (!ensure(GameInstance))
	{
		return;
	}

	// Consider changing zone only in stable state
	if (!ensure(DediConnectionState == EDediConnectionState::Closed))
	{
		return;
	}

	// Prevent spam
	if (World->GetTimeSeconds() - LastEnterWorldFailTimeSeconds < CVarP3EnterWorldRetryIntervalSeconds.GetValueOnGameThread())
	{
		return;
	}

	UP3DediNet* DediNet = P3GetDediNet(this);
	UP3UDPNetwork* UDPNetwork = DediNet ? nullptr : GameInstance->GetUDPNetwork();

	if (DediNet)
	{
		if (!ensure(DediNet->GetConnStatus() == EP3NetConnStatus::Closed))
		{
			return;
		}
	}
	else if (UDPNetwork)
	{
		if (!ensure(UDPNetwork->Client_GetConnStatus() == EP3NetConnStatus::Closed))
		{
			return;
		}
	}
	else
	{
		checkf(0, TEXT("No available network"));
		return;
	}

	UP3DedimanHelper* DedimanHelper = P3GetDedimanHelper(this);

	if (!ensure(DedimanHelper))
	{
		return;
	}

	if (World->WorldComposition)
	{
		UpdateCurrentTileZoneNames();

		if (CurrentTileZoneNames.Num() > 0)
		{
			// TODO: Just pick first zone for now, change it later
			const FString ZoneName = CurrentTileZoneNames[0].ToString();
			const charid CharacterId = GameInstance->GetCharacterId();
			const FString& CharacterName = GameInstance->GetCharacterName();
			DedimanHelper->AllocZoneChannel(ZoneName, CharacterId, *CharacterName);

			SetDediConnectionState(EDediConnectionState::WaitDediInfo);
		}
	}
	else
	{
		FName ZoneName;

		if (DediNet)
		{
			ZoneName = DediNet->GetZone();
		}
		else if (UDPNetwork)
		{
			ZoneName = UDPNetwork->GetZone();
		}

		// 커넥션 실패를 하면 ZoneName이 초기화되기 때문에 월드로부터 얻어온다.
		FString CurZoneName = (ZoneName == NAME_None) ? World->GetMapName() : ZoneName.ToString();

		if (!CurZoneName.IsEmpty())
		{
			const charid CharacterId = GameInstance->GetCharacterId();
			const FString& CharacterName = GameInstance->GetCharacterName();
			DedimanHelper->AllocZoneChannel(CurZoneName, CharacterId, *CharacterName);

			SetDediConnectionState(EDediConnectionState::WaitDediInfo);
		}
	}
}

void UP3ClientWorld::DisconnectFromDedi()
{
	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();
	if (!ensure(GameInstance))
	{
		return;
	}

	SetDediConnectionState(EDediConnectionState::Closing);

	if (UP3DediNet* DediNet = P3GetDediNet(this))
	{
		DediNet->SendZoneChange();
	}
	else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
	{
		UDPNetwork->Client_SendZoneChange();
	}
}

void UP3ClientWorld::TickBGM()
{
	AP3GameMode* P3GameMode = Cast<AP3GameMode>(GetWorld()->GetAuthGameMode());
	UP3BGMPlayer* BGMPlayer = P3GameMode ? P3GameMode->GetBGMPlayer() : nullptr;
	if (BGMPlayer)
	{
		// See if there is any angry large character
		bool bHasCombatStanceLargeCharacter = false;
		for (AP3Character* Character : CharacterActors)
		{
			if (!Character || Character->IsActorBeingDestroyed() || Character->IsDead())
			{
				continue;
			}

			if (Character->IsLarge() && Character->GetStance() == EP3CharacterStance::Combat)
			{
				bHasCombatStanceLargeCharacter = true;
			}
		}

		if (bHasCombatStanceLargeCharacter)
		{
			BGMPlayer->PlayBossBattleBGM();
		}
		else
		{
			BGMPlayer->StopBossBattleBGM();
		}
	}
}

void UP3ClientWorld::OnActorAdded(AActor* Actor)
{
	AP3Character* Character = Cast<AP3Character>(Actor);
	if (Character)
	{
		CharacterActors.AddUnique(Character);
	}

	if (Actor && Actor->IsA(AP3WorldSystem::StaticClass()) && P3World)
	{
		P3World->Net_WorldSystem = Cast< AP3WorldSystem>(Actor);
	}
}

void UP3ClientWorld::OnActorRemoved(AActor* Actor)
{
	AP3Character* Character = Cast<AP3Character>(Actor);
	if (Character)
	{
		CharacterActors.Remove(Character);
	}
}

void UP3ClientWorld::OnHUDPostRender(class AHUD* HUD, class UCanvas* Canvas)
{
	if (HUD->GetWorld() != GetWorld())
	{
		return;
	}

	float X = 50;
	float Y = 150;

	if (CVarP3ZoneDebug.GetValueOnGameThread() > 0)
	{
		HUD->DrawText(FString::Printf(TEXT("[Current Tile Zone List]")), FLinearColor::White, X, Y); Y += 20;

		for (const FName& ZoneName : CurrentTileZoneNames)
		{
			HUD->DrawText(*ZoneName.ToString(), FLinearColor::White, X, Y); Y += 20;
		}
	}

	if (CVarP3TODDebug.GetValueOnGameThread() > 0 && P3World)
	{
		const float Hour = FMath::Frac(P3World->TimeOfDay.TimeOfDayInSeconds / (3600 * 24)) * 24.0f;

		HUD->DrawText(FString::Printf(TEXT("Time of Day: %.2f, Ratio: %.2f"),
			Hour, P3World->TimeOfDay.GameTimeToTimeOfDayRatio), FLinearColor::White, X, Y); Y += 20;
	}
}

void UP3ClientWorld::OnDediInfo(const FP3DediInfoResponse& Response, bool bWasSuccessful)
{
	if (!ensure(CVarP3ZoneAutoChange.GetValueOnGameThread() > 0))
	{
		return;
	}

	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return;
	}

	if (!bZoneAutoChange)
	{
		return;
	}

	//if (!ensure(DediConnectionState == EDediConnectionState::WaitDediInfo))
	if (DediConnectionState != EDediConnectionState::WaitDediInfo)
	{
		return;
	}

	if (!bWasSuccessful)
	{
		SetDediConnectionState(EDediConnectionState::Closed);
		return;
	}

	UP3DediNet* DediNet = P3GetDediNet(this);

	if (DediNet)
	{
		if (!ensure(DediNet->GetConnStatus() == EP3NetConnStatus::Closed))
		{
			SetDediConnectionState(EDediConnectionState::Closed);
			return;
		}

		DediNet->SetHost(Response.Dedi.Host);
		DediNet->SetPort(Response.Dedi.ListenPort);
		DediNet->SetZone(FName(*Response.Dedi.ZoneName));
		DediNet->Connect();
	}
	else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
	{
		if (!ensure(UDPNetwork->Client_GetConnStatus() == EP3NetConnStatus::Closed))
		{
			SetDediConnectionState(EDediConnectionState::Closed);
			return;
		}

		if (P3World)
		{
			UDPNetwork->SetZone(FName(*Response.Dedi.ZoneName));
			UDPNetwork->Init(P3World, Response.Dedi.Host, Response.Dedi.UDPPort);
		}
	}
	else
	{
		checkf(0, TEXT("No available network"));
		return;
	}

	SetDediConnectionState(EDediConnectionState::Connecting);
}

void UP3ClientWorld::Client_HandleSyncActorComponentTransform(const FP3DediToClientHandlerParams& Params)
{
	FP3NetActorComponentTransform NetTransform;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacketNonStruct(P3World, Params.Buffer, NetTransform);

	if (!ensure(bSerializeSucceeded))
	{
		return;
	}

	if (NetTransform.ActorId == MyCharacterActorId)
	{
		// TODO: do what we need to do
		return;
	}

	if (NetTransform.ComponentName.IsEmpty())
	{
		ensure(0);
		return;
	}

	AActor* Actor = Params.Actor ? Params.Actor : P3World->GetActorFromActorId(NetTransform.ActorId);

	if (!Actor)
	{
		// In case if standalone/listen, actor can be already removed from Actors list by Server P3World, otherwise it should never happen
		ensure(P3Core::IsP3NetModeServerInstance(*this));
		return;
	}

	USceneComponent* TargetComponent = nullptr;

	const TSet<UActorComponent*>& Components = Actor->GetComponents();
	for (auto&& Iter : Components)
	{
		USceneComponent* Comp = Cast<USceneComponent>(Iter);
		if (Comp && Comp->GetName().Equals(NetTransform.ComponentName, ESearchCase::CaseSensitive))
		{
			TargetComponent = Comp;
			break;
		}
	}

	if (!TargetComponent)
	{
		P3JsonWorldLog(Warning, "SyncActorComponent failed : TargetComponent is not exist.", TEXT("OwnerName"), *Actor->GetName());
		return;
	}

	if (IsSequencePossessedObject(*TargetComponent))
	{
		return;
	}

	FString MyAttachParentName = TargetComponent->GetAttachParent() ? TargetComponent->GetAttachParent()->GetName() : TEXT("");
	if (MyAttachParentName == NetTransform.AttachParentComponentName)
	{
		TargetComponent->SetRelativeTransform(NetTransform.Transform.ToTransform());
	}

	if (TargetComponent->bHiddenInGame != NetTransform.bHiddenInGame)
	{
		TargetComponent->SetHiddenInGame(NetTransform.bHiddenInGame);
	}
}

void UP3ClientWorld::Client_HandleSyncActorMovement(const FP3DediToClientHandlerParams& Params)
{
	FP3NetMovement NetMovement;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetMovement);

	if (ensure(bSerializeSucceeded))
	{
		if (NetMovement.ActorId == MyCharacterActorId)
		{
			// TODO: do what we need to do
			return;
		}

		AActor* Actor = Params.Actor ? Params.Actor : P3World->GetActorFromActorId(NetMovement.ActorId);

		if (!Actor)
		{
			// In case if standalone/listen, actor can be already removed from Actors list by Server P3World, otherwise it should never happen
			ensure(P3Core::IsP3NetModeServerInstance(*this));
			return;
		}

		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_ActorClassNameReceived].FindOrAdd((Actor)->GetClass()->GetFName());
		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_ActorNameReceived].FindOrAdd((Actor)->GetFName());

		if (IsSequencePossessedObject(*Actor))
		{
			return;
		}

		_ApplyNetMovement(NetMovement, Actor);
	}
}

void UP3ClientWorld::Client_HandleCharacterMovement(const FP3DediToClientHandlerParams& Params)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3World_Client_HandleCharacterMovement"), STAT_P3World_Client_HandleCharacterMovement, STATGROUP_P3);

	FP3NetActorIdAndByteArray NetData;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetData);

	if (ensure(bSerializeSucceeded))
	{
		if (NetData.ActorId == MyCharacterActorId)
		{
			// TODO: do what we need to do
			return;
		}

		AActor* Actor = Params.Actor ? Params.Actor : P3World->GetActorFromActorId(NetData.ActorId);

		if (!Actor)
		{
			ensure(0);
			return;
		}

		if (IsSequencePossessedObject(*Actor))
		{
			return;
		}

		AP3Character* Character = Cast<AP3Character>(Actor);
		if (!ensure(Character))
		{
			return;
		}

		// TODO: BitReader expect non const buffer strangely.... got to fix that...
		TArray<uint8> TmpBuffer = NetData.ByteArray;

		FP3StoreBitReader BitReader(P3World, TmpBuffer.GetData(), TmpBuffer.Num() * sizeof(uint8) * 8);
		Character->NetSerializeMovement(BitReader);
		ensure(!BitReader.IsError());
	}
}

void UP3ClientWorld::Client_HandleAnimalMovement(const FP3DediToClientHandlerParams& Params)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3World_Client_HandleCharacterMovement"), STAT_P3World_Client_HandleCharacterMovement, STATGROUP_P3);

	FP3NetActorIdAndByteArray NetData;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetData);

	if (ensure(bSerializeSucceeded))
	{
		if (NetData.ActorId == MyCharacterActorId)
		{
			// TODO: do what we need to do
			return;
		}

		AActor* Actor = Params.Actor ? Params.Actor : P3World->GetActorFromActorId(NetData.ActorId);

		if (!Actor)
		{
			ensure(0);
			return;
		}

		if (IsSequencePossessedObject(*Actor))
		{
			return;
		}

		AP3AnimalCharacter* Character = Cast<AP3AnimalCharacter>(Actor);
		if (!ensure(Character))
		{
			return;
		}

		// TODO: BitReader expect non const buffer strangely.... got to fix that...
		TArray<uint8> TmpBuffer = NetData.ByteArray;

		FP3StoreBitReader BitReader(P3World, TmpBuffer.GetData(), TmpBuffer.Num() * sizeof(uint8) * 8);
		Character->NetSerializeMovement(BitReader);
		ensure(!BitReader.IsError());
	}
}

void UP3ClientWorld::Client_HandleToastMessage(const FP3DediToClientHandlerParams& Params)
{
	FP3NetToastMessage NetMessage;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetMessage);

	if (ensure(bSerializeSucceeded))
	{
		if (!ensure(GetWorld()))
		{
			return;
		}

		AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
		if (ensure(PlayerController))
		{
			PlayerController->ToastMessageBP(NetMessage.Message);
		}
	}
}

void UP3ClientWorld::Client_HandleSyncTimeOfDay(const FP3DediToClientHandlerParams& Params)
{
	FP3NetTimeOfDay NetTimeOfDay;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetTimeOfDay);

	if (ensure(bSerializeSucceeded))
	{
		P3World->TimeOfDay.TimeOfDayInSeconds = NetTimeOfDay.TimeOfDayInSeconds;
		P3World->TimeOfDay.GameTimeToTimeOfDayRatio = NetTimeOfDay.GameTimeToTimeOfDayRatio;
	}
}

void UP3ClientWorld::Client_HandleDebugDraw(const FP3DediToClientHandlerParams& Params)
{
	FP3NetDebugDraw NetDebugDraw;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetDebugDraw);

	if (ensure(bSerializeSucceeded))
	{
		switch (NetDebugDraw.DebugDrawType)
		{
		case EP3NetDebugDrawType::Sphere:
			DrawDebugSphere(GetWorld(), NetDebugDraw.Location, NetDebugDraw.SphereRadius, 12, NetDebugDraw.Color, false, NetDebugDraw.LifeTime);
			break;

		default:
			ensure(0);
		}
	}
}

void UP3ClientWorld::Client_HandleDamageFoliage(const FP3DediToClientHandlerParams& Params)
{
	FP3NetDamageFoliage NetDamageFoliage;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetDamageFoliage);

	if (ensure(bSerializeSucceeded))
	{
		AActor* Actor = P3Core::FindActorByName(GetWorld(), NetDamageFoliage.LevelName, NetDamageFoliage.ActorName);

		if (Actor)
		{
			FPointDamageEvent PointDamageEvent;
			PointDamageEvent.Damage = 1;
			PointDamageEvent.HitInfo.Component = P3Core::GetActorComponentByName<UPrimitiveComponent>(*Actor, NetDamageFoliage.ComponentName);
			PointDamageEvent.HitInfo.Item = NetDamageFoliage.ItemIndex;
			Actor->TakeDamage(1, PointDamageEvent, nullptr, nullptr);
		}
	}
}

void UP3ClientWorld::Client_HandleDamageNonCommandActor(const FP3DediToClientHandlerParams& Params)
{
	FP3NetDamageNonCommandActor NetDamage;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3World, Params.Buffer, NetDamage);

	if (ensure(bSerializeSucceeded) && ensure(P3World))
	{
		P3World->Multicast_DamageNonCommandActor(NetDamage);
	}
}

bool UP3ClientWorld::SendPacketBuffer(actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header, bool bReliable) const
{
	if (!ensure(GetWorld()))
	{
		return false;
	}

	if (!ensure(P3World))
	{
		return false;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return false;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
	if (!ensure(PlayerController))
	{
		return false;
	}

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0)
	{
		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_HandlerNameSent].FindOrAdd(Header.HandlerFunctionName);
	}

	UP3DediNet* DediNet = GameInstance->GetDediNet();

	if (DediNet)
	{
		if (DediNet->GetConnStatus() == EP3NetConnStatus::Connected)
		{
			TSharedRef<pb::C2DUnrealRaw, ESPMode::ThreadSafe> Message(new pb::C2DUnrealRaw());
			Message->set_actor_id(ActorId);
			Message->set_buffer(Buffer.GetData(), StaticCast<size_t>(Buffer.Num()));
			Message->set_component_type(StaticCast<uint32>(Header.ComponentType));
			Message->set_handler_function_name(TCHAR_TO_UTF8(*Header.HandlerFunctionName.ToString()));

			DediNet->Send(pb::C2DType::C2D_UNREAL_RAW, Message);
			return true;
		}
	}
	else if (UP3UDPNetwork* UDPNetwork = GameInstance->GetUDPNetwork())
	{
		return UDPNetwork->Client_SendPacketBuffer(ActorId, Actor, Buffer, Header, bReliable);
	}
	else
	{
		checkf(0, TEXT("No available network"));
	}

	return false;
}

void UP3ClientWorld::HandlePacketBuffer(const FP3NetConnInfo& NetConnInfo, actorid ActorId, AActor* Actor, const TArray<uint8>& Buffer, const FP3NetHeader& Header)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3ClientWorld_HandlePacket"), STAT_P3ClientWorld_HandlePacketBuffer, STATGROUP_P3);

	if (CVarP3WorldDebugPacket.GetValueOnGameThread() != 0)
	{
		P3JsonWorldLog(Display, "Client_HandlePacketBuffer", TEXT("ActorId"), ActorId, TEXT("Function"), Header.HandlerFunctionName.ToString());
	}

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0)
	{
		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_HandlerNameReceived].FindOrAdd(Header.HandlerFunctionName);
	}

	UObject* HandlerObject = nullptr;

	if (ActorId == INVALID_ACTORID)
	{
		if (Header.ComponentType == EP3NetComponentType::None)
		{
			HandlerObject = P3World;
		}
		else if (Header.ComponentType == EP3NetComponentType::ClientWorld)
		{
			HandlerObject = this;
		}
		else
		{
			ensureMsgf(0, TEXT("Invalid component type: %d"), (int32)Header.ComponentType);
		}
	}
	else
	{
		if (Actor == nullptr)
		{
			Actor = P3World ? P3World->GetActorFromActorId(ActorId) : nullptr;
		}

		if (ensure(Actor))
		{
			if (Header.ComponentType == EP3NetComponentType::None)
			{
				HandlerObject = Actor;
			}
			else if (Header.ComponentType == EP3NetComponentType::Command)
			{
				HandlerObject = Actor->FindComponentByClass<UP3CommandComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::Action)
			{
				HandlerObject = Actor->FindComponentByClass<UP3PawnActionComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::Health)
			{
				HandlerObject = Actor->FindComponentByClass<UP3HealthPointComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::CharacterMovement)
			{
				HandlerObject = Actor->FindComponentByClass<UP3CharacterMovementComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::Destructible)
			{
				HandlerObject = Actor->FindComponentByClass<UP3DestructibleComponent>();
			}
			else if (Header.ComponentType == EP3NetComponentType::Quest)
			{
				HandlerObject = Actor->FindComponentByClass<UP3QuestComponent>();
			}
			else
			{
				ensureMsgf(0, TEXT("Invalid component type: %d"), (int32)Header.ComponentType);
			}
		}
	}

	if (!ensure(HandlerObject))
	{
		P3JsonWorldLog(Warning, "Client handle packet buffer failed. No Actor found", TEXT("ActorId"), ActorId);
		return;
	}

	if (CVarP3WorldPacketProfile.GetValueOnGameThread() != 0 && ActorId != INVALID_ACTORID)
	{
		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_ActorClassNameReceived].FindOrAdd(HandlerObject->GetClass()->GetFName());
		++PacketProfileHistory.NumPackets[EP3WorldPacketProfileType::WPP_ActorNameReceived].FindOrAdd(HandlerObject->GetFName());
	}

	UFunction* HandlerFunction = HandlerObject->FindFunction(Header.HandlerFunctionName);

	if (!ensure(HandlerFunction))
	{
		P3JsonWorldLog(Warning, "Client handle packet buffer failed. No handler function found",
			TEXT("HandlerFunctionName"), Header.HandlerFunctionName.ToString());
		return;
	}

	TArray<uint8> TempBuffer = Buffer;

	FP3DediToClientHandlerParams Params;
	Params.NetConnInfo = NetConnInfo;
	Params.Buffer = Buffer;
	Params.Actor = Actor;

	HandlerObject->ProcessEvent(HandlerFunction, &Params);
}

void UP3ClientWorld::ForeachProfileResult(int32 ProfileIndex, TFunctionRef<bool(const FString& FunctionName, int32 PacketCount, float DurationSeconds)> Func)
{
	for (auto&& Iter : PacketProfileResult.NumPackets[ProfileIndex])
	{
		if (Func(Iter.Key.ToString(), Iter.Value, PacketProfileResult.DurationSeconds))
		{
			break;
		}
	}
}

void UP3ClientWorld::SendWorldRelayMessage(pb::C2DWorldRelayMessageType RelayMessageType, const ProtobufMessage& RelayMessage)
{
	if (!ensure(P3World))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World->GetGameInstance();

	if (!ensure(GameInstance))
	{
		return;
	}

	TSharedRef<pb::C2DWorldMessage, ESPMode::ThreadSafe> WorldMessage(new pb::C2DWorldMessage());

	pb::C2DWorldRelayMessage* WorldRelayMessage = WorldMessage->mutable_message();

	if (!ensure(WorldRelayMessage))
	{
		return;
	}

	ProtobufMessage* DstMessage = nullptr;

	switch (RelayMessageType)
	{
	case pb::C2DWorldRelayMessageType::C2DWorldRelayPlayerListReq:
		DstMessage = WorldRelayMessage->mutable_player_list_req();
		break;
	case pb::C2DWorldRelayMessageType::C2DWorldRelayPartyInvite:
		DstMessage = WorldRelayMessage->mutable_party_invite();
		break;
	case pb::C2DWorldRelayMessageType::C2DWorldRelayPartyInvitationRes:
		DstMessage = WorldRelayMessage->mutable_party_invitation_res();
		break;
	case pb::C2DWorldRelayMessageType::C2DWorldRelayPartyLeave:
		DstMessage = WorldRelayMessage->mutable_party_leave();
		break;
	default:
		ensure(0);
		P3JsonWorldLog(Warning, "invalid world relay message");
		break;
	}

	if (ensure(DstMessage))
	{
		if (!ensure(RelayMessage.GetTypeName() == DstMessage->GetTypeName()))
		{
			return;
		}

		auto CopyProtobuf = [](const ProtobufMessage& Src, ProtobufMessage& Dst) -> bool {
			if (Src.GetDescriptor() == Dst.GetDescriptor())
			{
				if (Src.ByteSizeLong() > 0)
				{
					Dst.CopyFrom(Src);
				}
				return true;
			}
			return false;
		};

		const bool bValidMessage = CopyProtobuf(RelayMessage, *DstMessage);

		if (!ensure(bValidMessage))
		{
			return;
		}

		UP3DediNet* DediNet = GameInstance->GetDediNet();
		UP3UDPNetwork* UDPNetwork = DediNet ? nullptr : GameInstance->GetUDPNetwork();

		if (DediNet)
		{
			DediNet->Send(pb::C2DType::C2D_WORLD_MESSAGE, WorldMessage);
		}
		else if (ensure(UDPNetwork))
		{
			UDPNetwork->Client_SendWorldMessage(WorldMessage.Get());
		}
	}
}

void UP3ClientWorld::HandleWorldMessage(const pb::D2CWorldMessage& WorldMessage)
{
	const pb::D2CWorldRelayMessage& RelayMessage = WorldMessage.message();

	uint32 WorldMessageType = RelayMessage.message_type();

	switch (WorldMessageType)
	{
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPlayerList:
		HandleWorldMessagePlayerList(RelayMessage);
		break;
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyInvitation:
		HandleWorldMessagePartyInvitation(RelayMessage);
		break;
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyMembersJoin:
		HandleWorldMessagePartyMembersJoin(RelayMessage);
		break;
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyMembersLeave:
		HandleWorldMessagePartyMembersLeave(RelayMessage);
		break;
	case pb::D2CWorldRelayMessageType::D2CWorldRelayPartyLeaveRes:
		HandleWorldMessagePartyLeaveRes(RelayMessage);
		break;
	default:
		ensure(0);
		break;
	}
}

void UP3ClientWorld::HandleWorldMessagePlayerList(const pb::D2CWorldRelayMessage& WorldRelayMessage)
{
	if (!ensure(WorldRelayMessage.has_player_list()))
	{
		return;
	}

	FP3ClientPlayerCharacters PlayerChars;

	const pb::PlayerList& PlayerList = WorldRelayMessage.player_list();

	for (const pb::PlayerList_Player& Player : PlayerList.players())
	{
		PlayerChars.PlayerCharList.Add(FP3ClientPlayerCharacter(UTF8_TO_TCHAR(Player.char_name().c_str()),
			StaticCast<EP3CharClass>(Player.char_class()), Player.char_level(), UTF8_TO_TCHAR(Player.zone().c_str())));
	}

	OnLoadPlayerCharList.Broadcast(PlayerChars);
}

void UP3ClientWorld::HandleWorldMessagePartyInvitation(const pb::D2CWorldRelayMessage& WorldRelayMessage)
{
	if (!ensure(WorldRelayMessage.has_party_invitation()))
	{
		return;
	}

	APawn* LocalPawn = P3Core::GetLocalPawn(GetWorld());

	if (!ensure(LocalPawn))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(LocalPawn);
	if (!ensure(Character))
	{
		return;
	}

	const pb::PartyInvitation& PartyInvitation = WorldRelayMessage.party_invitation();

	const FString& InviterName = UTF8_TO_TCHAR(PartyInvitation.inviter_name().c_str());

	pb::C2DWorldRelayMessage_PartyInvitationRes Message;
	Message.set_response(pb::PartyDefine::AcceptInvitation);

	SendWorldRelayMessage(pb::C2DWorldRelayMessageType::C2DWorldRelayPartyInvitationRes, Message);
}

void UP3ClientWorld::HandleWorldMessagePartyMembersJoin(const pb::D2CWorldRelayMessage& WorldRelayMessage)
{
	if (!ensure(WorldRelayMessage.has_party_members_join()))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World ? P3World->GetGameInstance() : nullptr;

	if (!ensure(GameInstance))
	{
		return;
	}

	UP3ChatNet* ChatNet = GameInstance->GetChatNet();

	FP3PartyMembers PartyMembers(true);

	const pb::PartyMembersJoin PartyMembersJoin = WorldRelayMessage.party_members_join();

	for (const pb::PartyMember& Member : PartyMembersJoin.party_members())
	{
		FString CharName = UTF8_TO_TCHAR(Member.char_name().c_str());

		// 파티멤버 리스트에 자기 자신도 표시 (기획 요청)
		//if (CharName != GameInstance->GetCharacterName())
		{
			PartyMembers.PartyMemberList.Add(FP3PartyMember(CharName, StaticCast<EP3CharClass>(Member.char_class()), Member.char_level()));
		}

		if (ChatNet)
		{
			FString ChatMsg = FString::Printf(TEXT("%s joined party"), *CharName);

			ChatNet->OnChat.Broadcast("Party", 0, ChatMsg);
		}
	}

	if (PartyMembers.PartyMemberList.Num() > 0)
	{
		OnAddOrRemovePartyMembers.Broadcast(PartyMembers);
	}
}

void UP3ClientWorld::HandleWorldMessagePartyMembersLeave(const pb::D2CWorldRelayMessage& WorldRelayMessage)
{
	if (!ensure(WorldRelayMessage.has_party_members_leave()))
	{
		return;
	}

	UP3GameInstance* GameInstance = P3World ? P3World->GetGameInstance() : nullptr;

	if (!ensure(GameInstance))
	{
		return;
	}

	UP3ChatNet* ChatNet = GameInstance->GetChatNet();

	FP3PartyMembers PartyMembers(false);

	const pb::PartyMembersLeave& PartyMembersLeave = WorldRelayMessage.party_members_leave();

	for (const auto& MemberName : PartyMembersLeave.member_names())
	{
		FString CharName = UTF8_TO_TCHAR(MemberName.c_str());

		// 파티멤버 리스트에 자기 자신도 표시 (기획 요청)
		//if (CharName != GameInstance->GetCharacterName())
		{
			PartyMembers.PartyMemberList.Add(FP3PartyMember(CharName));
		}

		if (ChatNet)
		{
			FString ChatMsg = FString::Printf(TEXT("%s leaved party"), *CharName);

			ChatNet->OnChat.Broadcast("Party", 0, ChatMsg);
		}
	}

	if (PartyMembers.PartyMemberList.Num() > 0)
	{
		OnAddOrRemovePartyMembers.Broadcast(PartyMembers);
	}
}

void UP3ClientWorld::HandleWorldMessagePartyLeaveRes(const pb::D2CWorldRelayMessage& WorldRelayMessage)
{
	if (!ensure(WorldRelayMessage.has_party_leave_res()))
	{
		return;
	}

	const pb::PartyLeaveRes& PartyLeaveRes = WorldRelayMessage.party_leave_res();

	bool bSuccess = PartyLeaveRes.success();

	OnAddOrRemovePartyMembers.Broadcast(FP3PartyMembers(false));
}
