// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

UENUM(Blueprintable)
enum class EP3HoldType : uint8
{
	RightHand,
	LeftHand,
	Count
};
