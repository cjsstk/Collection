// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "UObject/NoExportTypes.h"
#include "P3BGMPlayer.generated.h"

enum class EP3BGMMode
{
	Invalid,
	Normal,
	BossBattle
};

/**
 * BGM Player
 */
UCLASS()
class P3_API UP3BGMPlayer : public UObject
{
	GENERATED_BODY()
	
public:
	void PlayNormalBGM();

	void PlayBossBattleBGM();
	void StopBossBattleBGM();

	void Tick();

private:
	void SetBGMMode(EP3BGMMode InMode);
	void Play();

	UPROPERTY(Transient)
	UAudioComponent* AudioComponent;

	UPROPERTY(Transient)
	TArray<UAudioComponent*> FadeOutAudioComponents;

	EP3BGMMode CurrentBGMMode = EP3BGMMode::Invalid;
	int32 CurrentBGMIndex = 0;

	/** Did we fade out for some reason? (like playing cutscene) */
	bool bFadeOut = false;
};
