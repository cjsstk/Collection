// Copyright 2018 XL Games, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Network/Lib/P3NetCore.h"
#include "P3CharacterMovementComponent.generated.h"

UENUM(BlueprintType)
enum EP3MovementMode
{
	P3Movement_None,
	P3Movement_Climbing,
	P3Movement_Gliding,
	P3Movement_Sliding
};

USTRUCT(Blueprintable)
struct FClimbingStatus
{
	GENERATED_BODY()

	UPROPERTY()
	bool bConsiderClimbing;

	UPROPERTY()
	bool bIsLandingOnRoof;

	UPROPERTY()
	float LandingAgeSeconds;

	UPROPERTY()
	FVector ClimbingWallNormal;

	// Put some delay on walking -> climbing transition
	UPROPERTY()
	float WalkingToClimbingTransitionTimeLeft;

	UPROPERTY()
	float JumpVelocity;

	FClimbingStatus() 
		: bConsiderClimbing(false)
		, bIsLandingOnRoof(false)
		, LandingAgeSeconds(0)
		, ClimbingWallNormal(1.0f, 0, 0)
		, WalkingToClimbingTransitionTimeLeft(0)
		, JumpVelocity(0)
	{
	}
};

USTRUCT()
struct FP3NetServerMoveOld
{
	GENERATED_BODY()

	UPROPERTY()
	float OldTimeStamp;
	
	UPROPERTY()
	FVector_NetQuantize10 OldAccel;
	
	UPROPERTY()
	uint8 OldMoveFlags;
};

USTRUCT()
struct FP3NetServerMove
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeStamp;
	
	UPROPERTY()
	FVector_NetQuantize10 InAccel;
	
	UPROPERTY()
	FVector_NetQuantize100 ClientLoc;
	
	UPROPERTY()
	uint8 CompressedMoveFlags;
	
	UPROPERTY()
	uint8 ClientRoll;
	
	UPROPERTY()
	uint32 View;
	
	UPROPERTY()
	UPrimitiveComponent* ClientMovementBase;

	UPROPERTY()
	FName ClientBaseBoneName;
	
	UPROPERTY()
	uint8 ClientMovementMode;
};

USTRUCT()
struct FP3NetServerMoveDual
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeStamp0;
	
	UPROPERTY()
	FVector_NetQuantize10 InAccel0;

	UPROPERTY()
	uint8 PendingFlags;

	UPROPERTY()
	uint32 View0;

	UPROPERTY()
	float TimeStamp;
	
	UPROPERTY()
	FVector_NetQuantize10 InAccel;
	
	UPROPERTY()
	FVector_NetQuantize100 ClientLoc;
	
	UPROPERTY()
	uint8 NewFlags;
	
	UPROPERTY()
	uint8 ClientRoll;
	
	UPROPERTY()
	uint32 View;
	
	UPROPERTY()
	UPrimitiveComponent* ClientMovementBase;

	UPROPERTY()
	FName ClientBaseBoneName;
	
	UPROPERTY()
	uint8 ClientMovementMode;
};

USTRUCT()
struct FP3NetAckGoodMove
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeStamp;
};

USTRUCT()
struct FP3NetVeryShortAdjustPosition
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeStamp;

	UPROPERTY()
	FVector NewLoc;

	UPROPERTY()
	UPrimitiveComponent* NewBase;

	UPROPERTY()
	FName NewBaseBoneName;

	UPROPERTY()
	bool bHasBase;

	UPROPERTY()
	bool bBaseRelativePosition;

	UPROPERTY()
	uint8 ServerMovementMode;
};

USTRUCT()
struct FP3NetAdjustPosition
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeStamp;

	UPROPERTY()
	FVector NewLoc;

	UPROPERTY()
	FVector NewVel;

	UPROPERTY()
	UPrimitiveComponent* NewBase;

	UPROPERTY()
	FName NewBaseBoneName;

	UPROPERTY()
	bool bHasBase;

	UPROPERTY()
	bool bBaseRelativePosition;

	UPROPERTY()
	uint8 ServerMovementMode;
};

USTRUCT()
struct FP3NetAdjustRootMotionSourcePosition
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeStamp;

	UPROPERTY()
	FRootMotionSourceGroup ServerRootMotion;
	
	UPROPERTY()
	bool bHasAnimRootMotion;
	
	UPROPERTY()
	float ServerMontageTrackPosition;
	
	UPROPERTY()
	FVector ServerLoc;
	
	UPROPERTY()
	FVector_NetQuantizeNormal ServerRotation;
	
	UPROPERTY()
	float ServerVelZ;
	
	UPROPERTY()
	UPrimitiveComponent* ServerBase;
	
	UPROPERTY()
	FName ServerBoneName;
	
	UPROPERTY()
	bool bHasBase;
	
	UPROPERTY()
	bool bBaseRelativePosition;
	
	UPROPERTY()
	uint8 ServerMovementMode;
};


USTRUCT()
struct FP3NetAdjustRootMotionPosition
{
	GENERATED_BODY()

	UPROPERTY()
	float TimeStamp;

	UPROPERTY()
	float ServerMontageTrackPosition;

	UPROPERTY()
	FVector ServerLoc;

	UPROPERTY()
	FVector_NetQuantizeNormal ServerRotation;

	UPROPERTY()
	float ServerVelZ;

	UPROPERTY()
	UPrimitiveComponent* ServerBase;

	UPROPERTY()
	FName ServerBoneName;

	UPROPERTY()
	bool bHasBase;

	UPROPERTY()
	bool bBaseRelativePosition;

	UPROPERTY()
	uint8 ServerMovementMode;
};


/**
 * Force
 * any impulse or forces from outside
 * we need this to make net-sync smoother
 */
struct FP3CharacterMovementForce
{
	enum class EType
	{
		Wind,
		Action,
	};

	TWeakObjectPtr<UObject> SourceObject;
	EType Type = EType::Wind;

	/** Wind */
	FVector WindTargetVelocity = FVector::ZeroVector;
	float WindStrength = 1.0f;

	/** Action */
	FVector ActionTargetVelocity = FVector::ZeroVector;
	float ActionStrength = 1.0f;
};

/**
 * P3 Character movement component
 */
UCLASS()
class UP3CharacterMovementComponent : public UCharacterMovementComponent
{
	GENERATED_BODY()
	
public:
	UP3CharacterMovementComponent();

	// BEGIN UActorComponent Interface
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction) override;
	
	//BEGIN UMovementComponent Interface
	virtual float GetMaxSpeed() const override;
	virtual bool IsMovingOnGround() const override;
	virtual void SetUpdatedComponent(USceneComponent* NewUpdatedComponent) override;

	// BEGIN UCharacterMovementComponent Interface
	virtual void SetMovementMode(EMovementMode NewMovementMode, uint8 NewCustomMode = 0) override;
	virtual void PhysicsRotation(float DeltaTime) override;
	virtual bool ShouldRemainVertical() const override;
	virtual bool DoJump(bool bReplayingMoves) override;
	virtual class FNetworkPredictionData_Client* GetPredictionData_Client() const override;
	virtual void UpdateFromCompressedFlags(uint8 Flags) override;
	virtual void ApplyImpactPhysicsForces(const FHitResult& Impact, const FVector& ImpactAcceleration, const FVector& ImpactVelocity) override;
	virtual float GetMaxBrakingDeceleration() const override;
	virtual void CalcVelocity(float DeltaTime, float Friction, bool bFluid, float BrakingDeceleration) override;
	virtual void ApplyVelocityBraking(float DeltaTime, float Friction, float BrakingDeceleration) override;
	virtual bool ApplyRequestedMove(float DeltaTime, float MaxAccel, float MaxSpeed, float Friction, float BrakingDeceleration, FVector& OutAcceleration, float& OutRequestedSpeed) override;
	virtual void StopMovementImmediately() override;
	virtual FVector ConsumeInputVector() override;
	virtual void MoveAlongFloor(const FVector& InVelocity, float DeltaSeconds, FStepDownResult* OutStepDownResult = NULL) override;
	virtual FRotator GetDeltaRotation(float DeltaTime) const override;
	virtual FVector GetImpartedMovementBaseVelocity() const override;
	virtual void ApplyAccumulatedForces(float DeltaSeconds) override;
	virtual bool StepUp(const FVector& GravDir, const FVector& Delta, const FHitResult &Hit, struct UCharacterMovementComponent::FStepDownResult* OutStepDownResult = NULL) override;
	virtual bool ResolvePenetrationImpl(const FVector& Adjustment, const FHitResult& Hit, const FQuat& NewRotation) override;
	virtual void HandleImpact(const FHitResult& Hit, float TimeSlice=0.f, const FVector& MoveDelta = FVector::ZeroVector) override;
	class AP3Character* GetP3Character() const;
	
	bool GetSprintingPressed() const { return bSprintingPressed; }
	void SetSprintDisabled(bool bInDisabled) { bSprintDisabled = bInDisabled; }
	bool GetSprintDisabled() const { return bSprintDisabled; }

	void SetCustomWalkSpeedMultiplier(float SpeedMultiplier) { CustomWalkSpeedMultiplier = SpeedMultiplier; }

	void SetCustomWalkingRotation(const FRotator& NewRotator) { CustomWalkingRotator = NewRotator; bHasCustomWalkingRotator = true; }
	void ClearCustomWalkingRotation() { bHasCustomWalkingRotator = false; }

	void Server_SetOverrideAllowedPositionErrorSquared(float ErrorSquared) { Server_OverrideAllowedPositionErrorSquared = ErrorSquared; }

	void SetAllowMove(bool bAllow) { bMoveAllowed = bAllow; };
	void SetAllowRotate(bool bAllow) { bRotateAllowed = bAllow; };
	void SetbIsInKnockBack(bool bInKnockBack) { bIsInKnockBack = bInKnockBack; }
	void SetShouldRemainVertial(bool bInShouldRemainVertial) { bShouldRemainVertial = bInShouldRemainVertial; }
	void SetConstraintZAccel(bool bInConstraintZAccel) { bConstraintZAccel = bInConstraintZAccel; }
	void SetAllowClimb(bool bAllow) { bClimbAllowed = bAllow; }
	void SetAllowParkour(bool bAllow) { bParkourAllowed = bAllow; }
	void SetDelayTimeForRetryClimb(const float InCanClimbLeftSeconds) { CanClimbLeftSeconds = InCanClimbLeftSeconds; }

	/**
	*  Get speed multiplier
	*/
	float GetBlockingWalkSpeedMultiplier() const { return BlockingWalkSpeedMultiplier; }
	float GetCrunchBlockingWalkSpeedMultiplier() const { return CrunchBlockingWalkSpeedMultiplier; }
	float GetMeleeAimingSpeedMultiplier() const { return MeleeAimingSpeedMultiplier; }
	float GetAimingSpeedMultiplier() const { return AimingSpeedMultiplier; }
	float GetExhaustSpeedMultiplier() const { return ExhaustSpeedMultiplier; }
	float GetStumblingSpeedMultiplier() const { return StumblingSpeedMultiplier; }
	float GetHeavyBackpackSpeedMultiplier() const { return HeavyBackpackSpeedMultiplier; }
	float GetMiddleBackpackSpeedMultiplier() const { return MiddleBackpackSpeedMultiplier; }
	float GetLightBackpackSpeedMultiplier() const { return LightBackpackSpeedMultiplier; }

	/**
	 * Custom rotation rate
	 */
	void SetCustomRotationRate(bool bInUseCustomRotationRate, const FRotator& InCustomRotationRate);

	/**
	 * Forces
	 */
	void AddWindForce(const FVector& TargetVelocity, float Strength, UObject& SourceObject);
	void RemoveWindForce(UObject& SourceObject);

	void AddActionForce(const FVector& TargetVelocity, float Strength, UObject& SourceObject);
	FP3CharacterMovementForce* GetActionForce(UObject& SourceObject);
	void RemoveActionForce(UObject& SourceObject);

	/**
	 * See if we can start gliding with jump
	 */
	UFUNCTION(BlueprintCallable)
	bool IsGlidingPossibleWithJump() const;

	UFUNCTION(BlueprintCallable)
	bool IsClimbing() const { return P3MovementMode == P3Movement_Climbing; }

	UFUNCTION(BlueprintCallable)
	bool IsInWalkingToClimbingTransition() const { return (P3MovementMode == P3Movement_Climbing) && ClimbingStatus.WalkingToClimbingTransitionTimeLeft != 0.0f; }

	UFUNCTION(BlueprintCallable)
	bool IsLandingOnRoof() const { return (P3MovementMode == P3Movement_Climbing) && ClimbingStatus.bIsLandingOnRoof; }

	UFUNCTION(BlueprintCallable)
	bool IsClimbDownAvailable() const { return (MovementMode == MOVE_Walking && bClimbDownAvailable); }

	UFUNCTION(BlueprintCallable)
	bool IsClimbJumping() const { return (ClimbingStatus.JumpVelocity > 0.0f); }

	UFUNCTION(BlueprintCallable)
	bool IsGliding() const { return P3MovementMode == P3Movement_Gliding; }

	UFUNCTION(BlueprintCallable)
	bool IsSliding() const { return P3MovementMode == P3Movement_Sliding; }

	UFUNCTION(BlueprintCallable)
	bool IsCrippled() const { return bCrippled; }

	/** 지면 경사의 급한 정도, 범위는 [0.0, 1.0] */
	UFUNCTION(BlueprintCallable)
	float GetSlopeRatio() const;

	UFUNCTION(BlueprintCallable)
	bool IsSlopeUpward() const;
	
	// Animation Notification
	void OnClimbAnimNotify();

	void SetSprint(bool bNewSprint);
	void SetCrippled(bool bNewCrippled);
	void SetStroll(bool bNewStroll);

	/** Returns true if the floor result hit a slidable surface. */
	bool IsSlidableFloor() const;

	bool IsSlidableFloorAngle() const;

	void Client_ClearMovementData();

protected:
	virtual void PhysCustom(float DeltaTime, int32 Iterations) override;
	virtual void ProcessLanded(const FHitResult& Hit, float RemainingTime, int32 Iterations) override;
	virtual void SetPostLandedPhysics(const FHitResult& Hit) override;
	virtual FVector NewFallVelocity(const FVector& InitialVelocity, const FVector& Gravity, float DeltaTime) const override;
	virtual void CapsuleTouched(UPrimitiveComponent* OverlappedComp, AActor* Other, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult) override;
	virtual FVector ConstrainInputAcceleration(const FVector& InputAcceleration) const override;

private:
	void TickCharacterComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction);
	void TickConsiderClimbing(float DeltaTime);
	void TickCalcFallingTime(float DeltaTime);

	// See if we have cliff ahead and we can hang on it (change to climb mode)
	void TickConsiderClimbDown(float DeltaTime);

	void ConsiderGliding();

	void PhysClimbing(float DeltaTime, int32 Iterations);
	void PhysGliding(float DeltaTime, int32 Iterations);
	void PhysSliding(float DeltaTime, int32 Iterations);

	void ChangeToClimbing();

	bool CanTryParkour() const;

	bool IsClimbStartActionInProgress() const;
	bool IsClimbEndActionInProgress() const;
	bool IsClimbDownActionInProgress() const;

	UFUNCTION()
	void OnStartSprint();

	UFUNCTION()
	void OnStopSprint();

	UFUNCTION()
	void OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit);

	/**
	 * Networking
	 */
	virtual class FNetworkPredictionData_Client_Character* GetPredictionData_Client_Character() const override;
	virtual void ServerMoveOld(float OldTimeStamp, FVector_NetQuantize10 OldAccel, uint8 OldMoveFlags) override;
	virtual void ServerMove(float TimeStamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8 CompressedMoveFlags, uint8 ClientRoll, uint32 View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) override;
	virtual void ServerMoveDual(float TimeStamp0, FVector_NetQuantize10 InAccel0, uint8 PendingFlags, uint32 View0, float TimeStamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8 NewFlags, uint8 ClientRoll, uint32 View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) override;
	virtual void ServerMoveDualHybridRootMotion(float TimeStamp0, FVector_NetQuantize10 InAccel0, uint8 PendingFlags, uint32 View0, float TimeStamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8 NewFlags, uint8 ClientRoll, uint32 View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) override;
	virtual void ServerMoveHandleClientError(float ClientTimeStamp, float DeltaTime, const FVector& Accel, const FVector& RelativeClientLocation, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) override;
	virtual void ClientAckGoodMove(float TimeStamp) override;
	virtual void ClientVeryShortAdjustPosition(float TimeStamp, FVector NewLoc, UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode) override;
	virtual void ClientAdjustPosition(float TimeStamp, FVector NewLoc, FVector NewVel, UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode) override;
	virtual void ClientAdjustRootMotionSourcePosition(float TimeStamp, FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, FVector ServerLoc, FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode) override;
	virtual void ClientAdjustRootMotionPosition(float TimeStamp, float ServerMontageTrackPosition, FVector ServerLoc, FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode) override;

	virtual bool ServerCheckClientError(float ClientTimeStamp, float DeltaTime, const FVector& Accel, const FVector& ClientWorldLocation, const FVector& RelativeClientLocation, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode) override;

	UFUNCTION()
	void Server_HandleMoveOld(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Server_HandleMove(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Server_HandleMoveDual(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Server_HandleMoveDualHybridRootMotion(const FP3ClientToDediHandlerParams& Params);

	UFUNCTION()
	void Client_HandleAckGoodMove(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleVeryShortAdjustPosition(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleAdjustPosition(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleAdjustRootMotionSourcePosition(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleAdjustRootMotionPosition(const FP3DediToClientHandlerParams& Params);

	UPROPERTY(Category="Character Movement (P3 General Settings)", EditAnywhere)
	float WalkingToClimbingTransitionDuration;

	UPROPERTY(Category="Character Movement (P3 General Settings)", EditAnywhere)
	FVector GlidingAirDrag;

	UPROPERTY(Category="Character Movement: Stroll", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float StrollSpeedMultiplier = 0.25f;

	UPROPERTY(Category="Character Movement: Sprint", EditAnywhere, meta=(ClampMin="1", UIMin="1"))
	float SprintSpeedMultiplier = 1.5f;

	UPROPERTY(Category="Character Movement: Crippled", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float CrippledRunSpeedMultiplier = 0.2f;

	UPROPERTY(Category="Character Movement: Blocking", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float BlockingWalkSpeedMultiplier = 0.3f;

	UPROPERTY(Category="Character Movement: Crunch Blocking", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float CrunchBlockingWalkSpeedMultiplier = 0.1f;

	UPROPERTY(Category="Character Movement: MeleeAiming", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float MeleeAimingSpeedMultiplier = 0.5f;

	UPROPERTY(Category="Character Movement: Aiming", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float AimingSpeedMultiplier = 0.5f;

	UPROPERTY(Category="Character Movement: Exhaust", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float ExhaustSpeedMultiplier = 0.5f;

	UPROPERTY(Category="Character Movement: Stumbling", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float StumblingSpeedMultiplier = 0.5f;

	UPROPERTY(Category="Character Movement: Climbing", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	bool bCanClimb = true;

	UPROPERTY(Category="Character Movement Climbing", EditAnywhere)
	FRotator ClimbRotationRate;

	UPROPERTY(Category="Character Movement: Climbing", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float MaxClimbSpeed;

	/** Initial velocity (instantaneous vertical acceleration) when jumping. */
	UPROPERTY(Category="Character Movement: Climbing", EditAnywhere, meta=(DisplayName="Jump Z Velocity", ClampMin="0", UIMin="0"))
	float ClimbJumpZVelocity;

	/** Minimum X value of wall normal in pawn space for walk-to-climbing transition. Set it low to avoid awkward snapping during wall-sliding */
	UPROPERTY(Category="Character Movement: Climbing", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float WalkToClimbX;

	UPROPERTY(Category="Character Movement: Gliding", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float MaxGlidingSpeed;

	UPROPERTY(Category="Character Movement Gliding", EditAnywhere)
	FRotator GlidingRotationRate;

	/** Sliding is possible if the slope is higher than this value. */
	UPROPERTY(Category = "Character Movement: Sliding", EditAnywhere, meta = (ClampMin = "0.0", ClampMax = "90.0", UIMin = "0.0", UIMax = "90.0"))
	float SlidableFloorAngle;
	float SlidableFloorZ;

	/** 오르막 경사면에서의 감속 정도, [ 0.0, 1.0 ] (경사 정도에 비례) */
	UPROPERTY(Category = "Character Movement: Slope", EditAnywhere)
	float InclineSlowDown = 0.7f;

	UPROPERTY(Category="Character Movement: Sliding", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float MaxSlidingSpeed;

	UPROPERTY(Category="Character Movement Sliding", EditAnywhere)
	FRotator SlidingRotationRate;

	/** Max walk speed during carrying someone */
	UPROPERTY(Category="Character Movement: Carrying", EditAnywhere, meta=(ClampMin="0", UIMin="0"))
	float MaxCarryingDownedCharacterSpeed = 300.0f;

	UPROPERTY(Category = "Character Movement: Backpack", EditAnywhere, meta = (ClampMin = "0", UIMin = "0"))
	float HeavyBackpackSpeedMultiplier = 0.2f;

	UPROPERTY(Category = "Character Movement: Backpack", EditAnywhere, meta = (ClampMin = "0", UIMin = "0"))
	float MiddleBackpackSpeedMultiplier = 0.5f;

	UPROPERTY(Category = "Character Movement: Backpack", EditAnywhere, meta = (ClampMin = "0", UIMin = "0"))
	float LightBackpackSpeedMultiplier = 0.7f;

	/** If set true, character will pitch around to match ground angle */
	UPROPERTY(Category = "Ground Alignment", EditAnywhere)
	bool bUseGroundAlignment = false;

	UPROPERTY(Category = "Ground Alignment", EditAnywhere)
	FVector GroundAlignmentFrontLocation = FVector(100, 0, 100);

	UPROPERTY(Category = "Ground Alignment", EditAnywhere)
	float GroundAlignmentFrontSweepDistance = 200;

	UPROPERTY(Category = "Ground Alignment", EditAnywhere)
	FVector GroundAlignmentRearLocation = FVector(-100, 0, 100);

	UPROPERTY(Category = "Ground Alignment", EditAnywhere)
	float GroundAlignmentRearSweepDistance = 200;

	UPROPERTY()
	TEnumAsByte<enum EP3MovementMode> P3MovementMode;

	UPROPERTY()
	FClimbingStatus ClimbingStatus;

	// if true, player is pressed sprint button
	// not replicated. only valid for local client
	bool bSprintingPressed;

	// Sometimes sprint is just not an option (like empty stamina)
	bool bSprintDisabled;

	// become true if hang-forward is possible, meaning we have a cliff ahead and we can climb down
	bool bClimbDownAvailable;

	// If true, the character is crippled
	bool bCrippled = false;

	// If true, the character walk slowly
	bool bStroll = false;

	/** In some cases, like playing turning-animation, we need custom rotation rate */
	bool bUseCustomRotationRate = false;
	FRotator CustomRotationRate = FRotator(0, 0, 0);

	float CustomWalkSpeedMultiplier;
	FRotator CustomWalkingRotator;
	bool bHasCustomWalkingRotator;
	bool bMoveAllowed = true;
	bool bRotateAllowed = true;
	bool bIsInKnockBack = false;
	bool bClimbAllowed = false;
	bool bParkourAllowed = false;
	bool bShouldRemainVertial = false;
	bool bConstraintZAccel = false;
	FVector EffectiveAccel = FVector::ZeroVector;
	float LastStuckCheckTimeSeconds = 0.0f;
	FVector LastStuckCheckLocation = FVector::ZeroVector;

	int32 GlidingJumpCount = 0;

	float CanClimbLeftSeconds = 0.0f;

	float CurrentFallingTimeAgeSeconds = 0.0f;
	float FallingReturnHomeCoolDown = 3.0f;
	float CurrentFallingReturnHomeCoolDownAgeSeconds = 0.0f;

	/** override AGameNetworkManager::MAXPOSITIONERRORSQUARED. used on ServerCheckClientError() */
	float Server_OverrideAllowedPositionErrorSquared = -1;

	FVector Debug_LastLocation = FVector::ZeroVector;

	TArray<FP3CharacterMovementForce> Forces;
};

class FP3NetworkPredictionData_Client_Character : public FNetworkPredictionData_Client_Character
{
public:
	FP3NetworkPredictionData_Client_Character(const UCharacterMovementComponent& ClientMovement);

	virtual FSavedMovePtr AllocateNewMove() override;
};

class FP3SavedMove_Character : public FSavedMove_Character
{
public:
	enum CompressedFlags
	{
		FLAG_SprintPressed = FLAG_Custom_0
	};

	virtual void Clear() override;
	virtual void SetMoveFor(ACharacter* C, float InDeltaTime, FVector const& NewAccel, class FNetworkPredictionData_Client_Character& ClientData) override;
	virtual bool CanCombineWith(const FSavedMovePtr& NewMove, ACharacter* InPawn, float MaxDelta) const override;
	virtual uint8 GetCompressedFlags() const override;
	virtual void PostUpdate(ACharacter* C, EPostUpdateMode PostUpdateMode) override;

	uint32 bSprintPressed:1;
};
