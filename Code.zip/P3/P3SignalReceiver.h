// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "GameFramework/Actor.h"
#include "P3SignalReceiver.generated.h"


/** 
 * Simple object that receive signal from other things (like switch)
 */
UCLASS(Blueprintable)
class P3_API AP3SignalReceiver : public AP3Actor
{
	GENERATED_BODY()
	
public:	
	AP3SignalReceiver();

	/** AP3Actor */
	virtual void NetSerialize(FArchive& Archive) override;

	UFUNCTION(BlueprintCallable, Category = P3)
	void SignalBP(bool bOn) { Server_Signal(bOn); }
	void Server_Signal(bool bOn);

	UFUNCTION(BlueprintCallable, Category = P3)
	bool GetCurrentSignalBP() const { return GetCurrentSignal(); }
	bool GetCurrentSignal() const { return Net_bOn; }

protected:
	virtual void Server_OnSignal(bool bOn) {}
	virtual void Client_OnSignal(bool bOn) {}

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveSignalBP(bool bOn);

private:
	bool Net_bOn = false;
};


/** 
 * Servo rotate pitch to target angle if any signal is given
 * MountComponent is static
 * AxleComponent is rotating
 * NOTE: not tested yet!
 */
UCLASS(Blueprintable)
class P3_API AP3Servo : public AP3SignalReceiver
{
	GENERATED_BODY()
	
public:	
	AP3Servo();

	virtual void Tick(float DeltaTime) override;

protected:
	virtual void Server_OnSignal(bool bOn);

private:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta=(AllowPrivateAccess = "true"))
	USceneComponent* MountComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, meta=(AllowPrivateAccess = "true"))
	USceneComponent* AxleComponent;

	UPROPERTY(EditAnywhere, Category = P3)
	float MaxRotationAngleDegree = 90;

	UPROPERTY(EditAnywhere, Category = P3)
	float AngVelDegreePerSecond = 30;


	float CurrentAngleDegree = 0;
	float CurrentRotateDirection = 0;
};


/** 
 * Servo rotate pitch to target angle if any signal is given
 * Actor itself rotates
 * This is favored over AP3Servo since this is easier to attach other actor in editor viewport
 */
UCLASS(Blueprintable)
class P3_API AP3OutrunnerServo : public AP3SignalReceiver
{
	GENERATED_BODY()
	
public:	
	AP3OutrunnerServo();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

protected:
	virtual void Server_OnSignal(bool bOn);

private:
	// Max Rotation, set -1 for inifinty rotation
	UPROPERTY(EditAnywhere, Category = P3)
	float MaxRotationAngleDegree = 90;

	UPROPERTY(EditAnywhere, Category = P3)
	float AngVelDegreePerSecond = 30;

	FRotator DefaultRotator = FRotator::ZeroRotator;

	float CurrentAngleDegree = 0;
	float CurrentRotateDirection = 0;
};


/** 
 * Linear actuator
 * move along X axis
 */
UCLASS(Blueprintable)
class P3_API AP3LinearActuator : public AP3SignalReceiver
{
	GENERATED_BODY()
	
public:	
	AP3LinearActuator();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = P3)
	float GetCurrentTravel() const { return CurrentTravel; }

protected:
	virtual void Server_OnSignal(bool bOn) override;
	
private:
	static const FName NAME_Signal;

	void Multicast_OnSignal(bool bOn);

	virtual void Client_OnEvent(FName EventName, int32 Param) override;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = true), Category = P3)
	float MaxTravelDistance = 100;

	UPROPERTY(EditAnywhere, Category = P3)
	float Speed = 20;

	UPROPERTY(EditAnywhere, Category = P3)
	class USoundBase* OnSound;

	UPROPERTY(EditAnywhere, Category = P3)
	class USoundBase* OffSound;

	FVector DefaultLocation = FVector::ZeroVector;
	FVector MoveForwardVector = FVector::ZeroVector;

	bool bCurrentSignal = false;
	float CurrentTravel = 0;
	float CurrentMoveDirection = 0;

};

/** 
 * Spawner activator (Server only)
 */
UCLASS(Blueprintable)
class P3_API AP3SpawnerActivator : public AP3SignalReceiver
{
	GENERATED_BODY()

public:
	AP3SpawnerActivator();

protected:
	virtual void Server_OnSignal(bool bOn) override;

private:
	UPROPERTY(EditAnywhere, Category = P3)
	TArray<AActor*> SpawnerActors;
};

/** 
 * Level Sequence Player
 */
UCLASS(Blueprintable)
class P3_API AP3LevelSequencePlayer : public AP3SignalReceiver
{
	GENERATED_BODY()

public:
	AP3LevelSequencePlayer();

protected:
	virtual void Server_OnSignal(bool bOn) override;
	virtual void Client_OnEvent(FName EventName, int32 Param) override;

private:
	const static FName NAME_PlaySequence;
	const static FName NAME_StopSequence;

	/** Set signal receiver which will get signaled when sequence finished */
	UPROPERTY(EditInstanceOnly)
	class AP3SignalReceiver* OnFinishedSignalReceiver;

	UFUNCTION()
	void OnSequenceStop();

	UFUNCTION()
	void OnSequenceFinished();

	UPROPERTY(EditAnywhere, Category = P3)
	class ALevelSequenceActor* LevelSequenceActor;

	bool Server_bPlaying = false;
};


/**
 * Destructible Dropper
 */
UCLASS(Blueprintable)
class P3_API AP3DestructibleDropper : public AP3SignalReceiver
{
	GENERATED_BODY()

public:
	AP3DestructibleDropper();

protected:
	virtual void Server_OnSignal(bool bOn) override;
	virtual void Client_OnEvent(FName EventName, int32 Param) override;

private:
	const static FName NAME_DropSignal;

	UPROPERTY(EditInstanceOnly, Category = P3)
	class AP3Destructible* TargetDestructible;

	bool Server_bDropped = false;
};


/**
 * Set Actor's Visible
 */
UCLASS(Blueprintable)
class P3_API AP3SetActorVisible : public AP3SignalReceiver
{
	GENERATED_BODY()

public:
	AP3SetActorVisible();

protected:
	virtual void Server_OnSignal(bool bOn) override;
	virtual void Client_OnSignal(bool bOn) override;

private:
	void Multicast_OnSignal(bool bOn);

	UPROPERTY(EditAnywhere, Category = P3)
	TArray<AActor*> TargetActors;
};


/**
 * Actiavete/Deactivate Emitter
 */
UCLASS(Blueprintable)
class P3_API AP3EmitterActivator : public AP3SignalReceiver
{
	GENERATED_BODY()

public:
	AP3EmitterActivator();

protected:
	virtual void Server_OnSignal(bool bOn) override;
	virtual void Client_OnSignal(bool bOn) override;

private:
	void Multicast_OnSignal(bool bOn);

	UPROPERTY(EditAnywhere, Category = P3)
	TArray<class AEmitter*> TargetEmitters;
};
