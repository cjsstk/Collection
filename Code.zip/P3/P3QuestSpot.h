// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3QuestSpot.generated.h"

/**
 * Any location
 * Only used by Quest
 */
UCLASS()
class P3_API AP3QuestSpot : public AP3Actor
{
	GENERATED_BODY()

public:
	AP3QuestSpot();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UPROPERTY(Transient)
	class UBillboardComponent* EditorSprite;
};
