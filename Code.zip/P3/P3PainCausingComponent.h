// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "GameplayTagContainer.h"

#include "P3Combat.h"
#include "P3OverlapComponent.h"
#include "P3PainCausingComponent.generated.h"

UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3PainCausingComponent : public UP3OverlapComponent
{
	GENERATED_BODY()

public:	
	UP3PainCausingComponent();

	UFUNCTION(BlueprintCallable)
	void SetImpactDirection(const FVector& InImpactDirection) { ImpactDirection = InImpactDirection; }

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Server_OverlappedActorAdded(AActor& Actor) override;

private:
	UFUNCTION()
	void Server_OnHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit);

	UFUNCTION()
	void Server_OnOverlapTimer();

	/** Return true if damage is applied */
	bool Server_DamageOveralppedActors();

	/** Return true if damage is applied */
	bool Server_DamageActor(AActor* Actor, bool bIsBeginOverlap = false);

	/** If > 0, Hit event will trigger damage */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = P3, meta = (AllowPrivateAccess = "true"))
	int32 HitDamageAmount = 0;

	/** If > 0, Overlapped actors will get damage for every OverlapDamageTickSeconds */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = P3, meta = (AllowPrivateAccess = "true"))
	int32 OverlapDamageAmount = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = P3, meta = (AllowPrivateAccess = "true"))
	float OverlapDamageTickSeconds = 2.0f;

	/** If > 0, Overlapped actor will get damage once at the begin overlap. -1 does not generate hit action */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = P3, meta = (AllowPrivateAccess = "true"))
	int32 BeginOverlapDamageAmount = -1;

	/** If true, give damage on overlapped only once */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bGiveDamageOnlyOnce = false;

	/** If true, give not damage to instigator */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bIgnoreInstigator = true;

	/** If set false, hit action will not be triggered */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bPlayHitAction = true;

	/** 피격 리액션 정도, 단 대상이 크다면(IsLarge) 최소값 적용 */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = P3, meta = (AllowPrivateAccess = "true"))
	EAnimNotifyAttackStrengthFlags AttackStrength = EAnimNotifyAttackStrengthFlags::Medium;

	UPROPERTY(EditAnywhere, Category = P3)
	FVector ImpactDirection = FVector::ZeroVector;

	/**
	 * If set, actors that has any of this gameplaytag will be ignored
	 */
	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer IgnoreGameplayTagsAny;

	float OverlapDamageTickAgeSeconds = 0;

	UPROPERTY(Transient)
	TSet<AActor*> DamagedActors;

	FTimerHandle Server_OverlapTimerHandle;
};
