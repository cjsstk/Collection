// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Action/P3PawnAction.h"
#include "P3PickupableType.h"
#include "P3PickupComponent.generated.h"

/** 
 * Pickup Component
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3PickupComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3PickupComponent();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	AActor* GetPickupCandidateActorBP() const { return GetPickupCandidateActor(); }
	AActor* GetPickupCandidateActor() const { return PickupCandidate.GetActor(); }

	/** Return true if has pickup candidate and it will be pickup to inventory right away */
	bool HasPickupToInvenCandidate() const;

	/** Return true if pickup candidate is downed and need rescue */
	bool HasRescueCandidate() const;

	/** Return true if pickup candidate is temp weapon */
	bool HasTempWeaponCandidate() const;

	/** Return true if pickup candidate is backpack */
	bool HasBackpackCandidate() const;

	void SetPickuppedActor(AActor* InPickuppedActor);
	AActor* GetPickuppedActor() const { return PickuppedActor; }
	void HoldActor(AActor* Actor, bool bSetAsPickupedActor);

	AActor* GetActorInPickupAction() const { return ActorInPickupAction; }

	const FVector& GetThrowVelocity() const { return ThrowVelocity; }

	const FName GetAttachSocketName(EP3PickupableType PickupableType) const;

	UFUNCTION(BlueprintCallable)
	bool CanThrowBP() const { return CanThrow(); }
	bool CanThrow() const { return (PickuppedActor != nullptr); }

	UFUNCTION(BlueprintCallable)
	bool CanPutDownBP() const { return CanPutDown(); }
	bool CanPutDown() const;

	UFUNCTION(BlueprintCallable)
	bool CanPutDownHoldableBP() const { return CanPutDownHoldable(); }
	bool CanPutDownHoldable() const;

	bool IsPuttingDown() const;
	bool IsAimingThrowing() const { return bIsAimingThrowing; }

	/** Event from action */
	void OnPickupActionStarted(AActor* TargetActor);
	void OnPickupActionFinished(bool bSuccess, AActor* TargetActor);
	void OnPutdownActionFinished();
	void OnThrowActionFinished();
	
	void Pickup();
	void Putdown();
	void PutdownHoldable();
	void AimThrow();
	void Throw();

private:
	void LocalControll_UpdatePickupCandidate();
	void PickupActor(AActor& TargetActor, class UP3HolderComponent* HolderComponent);

	/** Max mass to pick up */
	UPROPERTY(EditDefaultsOnly, Category = Pickup)
	float MaxPickupableMass;

	/** Max distance to pick up */
	UPROPERTY(EditDefaultsOnly, Category = Pickup)
	float PickupRange;

	/** Throwing velocity in pawn's space */
	UPROPERTY(EditDefaultsOnly, Category = Pickup)
	FVector ThrowVelocity;

	/** My socket names which object will be attached to, for each pickupable types */
	UPROPERTY(EditDefaultsOnly, Category = Pickup)
	TMap<EP3PickupableType, FName> AttachSocketNames;

	/** This is only used during pickup Action */
	UPROPERTY(Transient)
	AActor* ActorInPickupAction = nullptr;

	/** We have picked up something */
	UPROPERTY(Transient)
	AActor* PickuppedActor = nullptr;

	/** Temporal client-only actor for aiming pose */
	UPROPERTY(Transient)
	AActor* Client_TempAimingActor = nullptr;

	/** Best actor that can be picked up around me */
	FP3Silhouetter PickupCandidate;

	UPROPERTY(Transient)
	class UP3HolderComponent* PickupCandidateHolderComponent = nullptr;
	
	bool bInInterpolatedAttaching = false;
	bool bIsAimingThrowing = false;
};
