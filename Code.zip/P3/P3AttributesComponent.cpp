// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AttributesComponent.h"
#include "Net/UnrealNetwork.h"
#include "P3CharacterEffectComponent.h"
#include "P3Log.h"

UP3AttributesComponent::UP3AttributesComponent()
	: Level(0)
	, Attributes()
{
	Attributes.SetNumZeroed(P3AttributeEnd);
}

void UP3AttributesComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3AttributesComponent::ApplyModifier(const FP3AttributeModifier& Modifier)
{
	int32 Base = Attributes[(int32)Modifier.Attribute];

	int32 AddValue = 0;
	int32 MultiplyValue = 1000;

	switch (Modifier.Operator)
	{
	case EP3AttributeOperator::Add:
		AddValue += Modifier.Value;
		break;
	case EP3AttributeOperator::Multiply:
		MultiplyValue *= (Modifier.Value * 0.001f);
		break;
	default:
		ensureMsgf(false, TEXT("Unknown attribute operator %d"), (int32)Modifier.Operator);
		break;
	}

	Attributes[(int32)Modifier.Attribute] = ((int64)Base + AddValue) * MultiplyValue / 1000;
}

int32 UP3AttributesComponent::GetLevel() const
{
	return Level;
}

void UP3AttributesComponent::SetLevel(int32 NewLevel)
{
	Level = NewLevel;
}

int32 UP3AttributesComponent::GetAttribute(EP3Attribute Attribute) const
{
	return Attributes[StaticCast<int32>(Attribute)];
}

void UP3AttributesComponent::UpdateAttributes()
{
	for (int32 i = P3AttributeStart; i < P3AttributeEnd; ++i)
	{
		EP3Attribute Attribute = StaticCast<EP3Attribute>(i);

		int32 Base = CalcBase(Attribute);

		Attributes[i] = (int32)Base;
	}

	for (const FP3AttributeModifier& Modifier : Modifiers)
	{
		ApplyModifier(Modifier);
	}

	UP3CharacterEffectComponent* EffectComp = GetOwner() ? GetOwner()->FindComponentByClass<UP3CharacterEffectComponent>() : nullptr;
	if (EffectComp)
	{
		const TArray<FP3CharacterBuff> Buffs = EffectComp->GetBuffs();
		for (const auto& Buff : Buffs)
		{
			if (Buff.CmsCharacterBuff.BuffImplType == EP3CharacterBuffImplType::AttributeModifier)
			{
				const FP3CmsAttributeModifierBuffImplRow* AttributeModifierBuff = P3Cms::GetAttributeModifierBuffImpl(Buff.CmsCharacterBuff.BuffImpleKey);
				if (AttributeModifierBuff)
				{
					ApplyModifier(AttributeModifierBuff->Modifier);
				}
			}
		}
	}

	OnUpdateAttributes.Broadcast();
}

void UP3AttributesComponent::Test_SetLevelBP(int32 NewLevel)
{
	Level = NewLevel;
	UpdateAttributes();
}
