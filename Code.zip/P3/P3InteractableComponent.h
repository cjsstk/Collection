// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3HoldType.h"
#include "P3LootDropComponent.h"
#include "P3StoreInterface.h"
#include "P3InteractableComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnInteracted, class AActor*, Interactor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3OnInteractionSuccessed);

UENUM(Blueprintable)
enum class EP3InteractableType : uint8
{
	None,
	Cooker,	// This is cooking device. If interactor holds ingredient, we can make some food out of it
	Talk
};

UENUM(Blueprintable)
enum class EP3LootingInteractableType : uint8
{
	Collect,
	Extract,
	Catch,
	Harvest,
	Mining,
	Pluck
};

UCLASS( ClassGroup=(P3), meta=(BlueprintSpawnableComponent) )
class P3_API UP3InteractableComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()
public:
	UP3InteractableComponent();

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	bool Server_OnInteract(class AActor* Interactor);

	UFUNCTION(BlueprintCallable)
	void Server_SetInteractionAllowed(bool bNewAllowed);

	bool IsInteractionAllowed() const;

	UFUNCTION(BlueprintCallable)
	EP3InteractableType GetInteractableType() const { return InteractableType; }
	bool IsPlayInteractionAnimation() const { return bPlayInteractAnimation; }
	virtual	bool IsAllowMoveOnAnimPlaying() const { return false; }

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	UPROPERTY(BlueprintAssignable)
	FP3OnInteracted Server_OnInteracted;

	UPROPERTY(BlueprintAssignable)
	FP3OnInteractionSuccessed Client_OnInteractionSuccessed;

protected:
	virtual bool Server_OnInteractInternal(class AActor* Interactor) { return true; }
	void Client_OnInteractSuccessed();

	bool Net_bInteractionAllowed = true;

	bool Net_bInteractionSuccessed = false;

	UPROPERTY(EditDefaultsOnly, Category = "Interactable")
	bool bAutoAllowInteractionOnBegin = true;

	UPROPERTY(EditDefaultsOnly, Category = "Interactable")
	bool bAllowInteractionOnOwnerDead = true;

	UPROPERTY(EditDefaultsOnly, Category = "Interactable")
	bool bAutoDestoryActorOnMaxInteraction = true;

	UPROPERTY(EditDefaultsOnly, Category = "Interactable")
	EP3InteractableType InteractableType = EP3InteractableType::None;

	/** if -1, can interact infinity */
	UPROPERTY(EditDefaultsOnly, Category = "Interactable")
	int32 MaxInteractionCount = -1;

	int32 Server_CurrentInteractNum = 0;

	UPROPERTY(EditDefaultsOnly, Category = "Interactable")
	bool bPlayInteractAnimation = true;
};


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3LootingInteractableComponent : public UP3InteractableComponent
{
	GENERATED_BODY()

public:
	UP3LootingInteractableComponent();

	virtual bool Server_OnInteractInternal(class AActor* Interactor) override;
	virtual	bool IsAllowMoveOnAnimPlaying() const override;

	bool Server_PickLootItem();

	UFUNCTION(BlueprintCallable)
	EP3LootingInteractableType GetLootingInteractableType() const { return LootingInteractableType; }

	bool IsHoldLootItemOnInteract() const { return bHoldLootItemOnInteract; }
	UClass* GetLootItemActorClass () const { return Net_LootItemActor.GetDefaultObject()->GetClass(); }

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

private:
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bHoldLootItemOnInteract = true;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	EP3LootingInteractableType LootingInteractableType = EP3LootingInteractableType::Collect;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FP3LootItemContainer ItemContainer;

	UPROPERTY()
	TSubclassOf<AActor> Net_LootItemActor;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FText InteractionFailText;
};


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3ChangeWeaponInteractableComponent : public UP3InteractableComponent
{
	GENERATED_BODY()

public:
	UP3ChangeWeaponInteractableComponent();

	virtual bool Server_OnInteractInternal(class AActor* Interactor) override;

private:
	UPROPERTY(EditAnywhere, Category = "P3")
	TMap<EP3HoldType, TSubclassOf<AActor>> NewWeaponActorClass;
};


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3TalkableComponent : public UP3InteractableComponent
{
	GENERATED_BODY()

public:
	UP3TalkableComponent();

	virtual bool Server_OnInteractInternal(class AActor* Interactor) override;
};


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3ClothChangerComponent : public UP3InteractableComponent
{
	GENERATED_BODY()

public:
	virtual bool Server_OnInteractInternal(class AActor* Interactor) override;
};


UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3HairChangerComponent : public UP3InteractableComponent
{
	GENERATED_BODY()

public:
	virtual bool Server_OnInteractInternal(class AActor* Interactor) override;
};

UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3BackpackInteractableComponent : public UP3InteractableComponent
{
	GENERATED_BODY()

public:
	virtual bool Server_OnInteractInternal(class AActor* Interactor) override;

private:
	UPROPERTY(EditDefaultsOnly, meta = (AllowPrivateAccess = "true"))
	class TSubclassOf<class AP3Backpack> BackpackActorClass;

};
