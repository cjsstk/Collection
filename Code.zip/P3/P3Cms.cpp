// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Cms.h"

#include "AssetRegistryModule.h"
#include "FileHelper.h"
#include "Paths.h"

#if WITH_EDITOR
#include "EditorFramework/AssetImportData.h"
#endif

#include "P3Log.h"

namespace P3Cms
{

static UP3Cms* Cms = nullptr;

const static FP3CmsCombatHit DummyCombatHit;
const static FP3CmsItem DummyItem;
const static FP3CmsQuest DummyQuest;

#if WITH_EDITOR
static void ResetDataTableFromCSV(IAssetRegistry& AssetRegistry, UDataTable*& DataTable, const FString& ObjectName, UScriptStruct* RowStruct)
{
	FString PackageName = FString::Printf(TEXT("/Game/CMS/%s"), *ObjectName);
	FString AssetPath = FString::Printf(TEXT("%s.%s"), *PackageName, *ObjectName);

	DataTable = LoadObject<UDataTable>(nullptr, *AssetPath);
	if (!DataTable)
	{
		UPackage* Package = CreatePackage(nullptr, *PackageName);
		DataTable = NewObject<UDataTable>(Package, FName(*ObjectName), RF_Public | RF_Standalone);
		if (!ensure(DataTable))
		{
			return;
		}

		AssetRegistry.AssetCreated(DataTable);
	}

	DataTable->RowStruct = RowStruct;
	FString FilePath = FPaths::ProjectContentDir() / TEXT("CMS") / FString::Printf(TEXT("%s.csv"), *ObjectName);

	FString CSV;
	bool bResult = FFileHelper::LoadFileToString(CSV, *FilePath);
	if (!ensure(bResult))
	{
		DataTable = nullptr;
		return;
	}

	TArray<FString> Problems = DataTable->CreateTableFromCSVString(CSV);
	if (!ensure(Problems.Num() == 0))
	{
		DataTable = nullptr;
		return;
	}

	FAssetImportInfo Info;
	Info.Insert(FAssetImportInfo::FSourceFile(FilePath));
	DataTable->AssetImportData->SourceData = MoveTemp(Info);

	UPackage* Package = DataTable->GetOutermost();
	if (ensure(Package))
	{
		Package->SetDirtyFlag(false);
	}

	DataTable->AddToRoot();
}
#endif

static void LoadDataTable(UDataTable*& DataTable, const FString& ObjectName)
{
	FScoppedTimeLogger TimeLogger("Loading CMS DataTable " + ObjectName);

	FString PackageName = FString::Printf(TEXT("/Game/CMS/%s"), *ObjectName);
	FString AssetPath = FString::Printf(TEXT("%s.%s"), *PackageName, *ObjectName);

	DataTable = LoadObject<UDataTable>(nullptr, *AssetPath);
	if (!ensure(DataTable))
	{
		P3JsonLog(Error, "No CMS data table", TEXT("Table"), *ObjectName);
		return;
	}

	DataTable->AddToRoot();
}

static void UnloadDataTable(UDataTable*& DataTable)
{
	if (DataTable)
	{
		DataTable->RemoveFromRoot();
		DataTable = nullptr;
	}
}

#if WITH_EDITOR
static void ResetDataTables()
{
	P3JsonLog(Display, "Reset CMS Tables...");

	ensureMsgf(0, TEXT("New UP3Cms doesn't support this yet!"));

	//FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>("AssetRegistry");
	//IAssetRegistry& AssetRegistry = AssetRegistryModule.Get();

	//ResetDataTableFromCSV(AssetRegistry, CharactersTable, "Characters", FP3CmsCharacter::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CharacterHairsTable, "ReturnedFemaleHairs", FP3CmsCharacterHair::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CharacterArmorsTable, "ReturnedFemaleArmors", FP3CmsCharacterArmor::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CombatSkillsTable, "CombatSkills", FP3CmsCombatSkill::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CombatHitsTable, "CombatHits", FP3CmsCombatHit::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CookingRecipesTable, "CookingRecipes", FP3CmsCookingRecipe::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CharacterBuffsTable, "CharacterBuffs", FP3CmsCharacterBuffRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, HealOverTimeBuffImplsTable, "HealOverTimeBuffImpls", FP3CmsHealOverTimeBuffImplRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, AttributeModifierBuffImplesTable, "AttributeModifierBuffImpls", FP3CmsAttributeModifierBuffImplRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, OverlappableBuffImplesTable, "OverlappableBuffImples", FP3CmsOverlappableBuffImplRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, RegenStaminaBuffImplsTable, "RegenStaminaBuffImpls", FP3CmsRegenStaminaBuffImplRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, ProvokeBuffImplsTable, "ProvokeBuffImples", FP3CmsProvokeBuffImplRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, ReactionBuffImplsTable, "ReactionBuffImples", FP3CmsReactionBuffImplRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, SummonBuffImplsTable, "SummonBuffImpls", FP3CmsSummonBuffImplRow::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CharacterExperiencePointsTable, "CharacterExperiencePoints", FP3CmsCharacterExperiencePoint::StaticStruct());
	//ResetDataTableFromCSV(AssetRegistry, CameraShakeTable, "CameraShakeTable", FP3CmsCameraShakeRow::StaticStruct());
}
#endif

static void LoadDataTables()
{
	P3JsonLog(Display, "Loading CMS Tables...");

	const FStringAssetReference CmsAssetReference = TEXT("/Game/CMS/Cms.Cms_C");
	UClass* CmsBlueprintClass = Cast<UClass>(CmsAssetReference.TryLoad());
	
	if (ensure(CmsBlueprintClass))
	{
		Cms = NewObject<UP3Cms>(GetTransientPackage(), CmsBlueprintClass);

		if (ensure(Cms))
		{
			Cms->AddToRoot();
			Cms->InitCms();
		}
	}
}

static void UnloadDataTables()
{
	P3JsonLog(Display, "Unloading CMS Tables...");

	if (Cms)
	{
		Cms->RemoveFromRoot();
		Cms = nullptr;
	}
}

bool IsLoaded()
{
	if (Cms)
	{
		return true;
	}

	return false;
}

void Initialize()
{
	if (IsRunningCommandlet())
	{
		return;
	}

#if P3_CMS_USE_CSV_AS_SOURCE
	#if WITH_EDITOR
		ResetDataTables();
	#else
		LoadDataTables();
	#endif
#else
	LoadDataTables();
#endif
}

void Reload()
{
	if (IsRunningCommandlet())
	{
		return;
	}

	UnloadDataTables();
	LoadDataTables();
}

void Shutdown()
{
	if (IsRunningCommandlet())
	{
		return;
	}

	UnloadDataTables();
}

TArray<const FP3CmsCombatSkill*> GetCharacterCombatSkills(FName CmsCharacterKey)
{
	TArray<const FP3CmsCombatSkill*> CharacterCombatSkills;

	if (CmsCharacterKey.IsNone())
	{
		return CharacterCombatSkills;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->CombatSkills)
	{
		return CharacterCombatSkills;
	}

	Cms->CmsData->CombatSkills->ForeachRow<FP3CmsCombatSkill>("FP3Cms::GetCharacterCombatSkills", [CmsCharacterKey, &CharacterCombatSkills](const FName& Key, const FP3CmsCombatSkill& Value)
	{
		if (Value.CmsCharacterKey == CmsCharacterKey)
		{
			CharacterCombatSkills.Add(&Value);
		}
	});

	return CharacterCombatSkills;
}

const FP3CmsCombatHit* GetCombatHit(FName CmsCombatHitKey)
{
	if (CmsCombatHitKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->CombatHits)
	{
		return nullptr;
	}

	return Cms->CmsData->CombatHits->FindRow<FP3CmsCombatHit>(CmsCombatHitKey, TEXT("FP3Cms::GetCombatHit"));
}

const FP3CmsCombatHit& GetCombatHitOrDummy(FName CmsCombatHitKey)
{
	const FP3CmsCombatHit* CombatHit = GetCombatHit(CmsCombatHitKey);
	return CombatHit ? *CombatHit : DummyCombatHit;
}

const FP3CmsItem& GetItem(itemkey ItemKey)
{
	if (ItemKey == INVALID_ITEMKEY)
	{
		return DummyItem;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->Items)
	{
		return DummyItem;
	}

	const FP3CmsItem* Item = Cms->CmsData->Items->FindRow<FP3CmsItem>(FName(*FString::FromInt(ItemKey)), TEXT("FP3Cms::GetItem"));
	return Item ? *Item: DummyItem;
}

itemkey GetItemKeyFromActorClass(const UClass* ActorClass)
{
	if (!ActorClass)
	{
		return INVALID_ITEMKEY;
	}

	if (!Cms)
	{
		return INVALID_ITEMKEY;
	}

	TSoftClassPtr<AActor> ActorClassPtr(ActorClass);

	itemkey* ItemKeyPtr = Cms->ActorClassToItemKey.Find(ActorClassPtr);

	return ItemKeyPtr ? *ItemKeyPtr : INVALID_ITEMKEY;
}

UClass* GetActorClassFromItemKey(itemkey ItemKey)
{
	if (!Cms)
	{
		return nullptr;
	}

	const TSoftClassPtr<AActor>* ActorClassPtr = Cms->ItemKeyToActorClass.Find(ItemKey);

	return ActorClassPtr ? ActorClassPtr->LoadSynchronous() : nullptr;
}

const FP3CmsQuest& GetQuest(questkey QuestKey)
{
	if (QuestKey == INVALID_ITEMKEY)
	{
		return DummyQuest;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->Quests)
	{
		return DummyQuest;
	}

	const FP3CmsQuest* Quest = Cms->CmsData->Quests->FindRow<FP3CmsQuest>(FName(*FString::FromInt(QuestKey)), TEXT("FP3Cms::GetQuest"));
	return Quest ? *Quest : DummyQuest;
}

questkey GetQuestKeyFromQuestDesc(const UP3QuestDesc* QuestDesc)
{
	if (!QuestDesc || !Cms)
	{
		return INVALID_QUESTKEY;
	}

	questkey* QuestKeyPtr = Cms->QuestDescToQuestKey.Find(QuestDesc);

	return QuestKeyPtr ? *QuestKeyPtr : INVALID_QUESTKEY;
}

const UP3QuestDesc* GetQuestDescFromQuestKey(questkey QuestKey)
{
	if (!Cms)
	{
		return nullptr;
	}

	auto Iter = Cms->QuestKeyToQuestDesc.Find(QuestKey);

	return Iter ? *Iter : nullptr;
}

const FP3CmsHoldable* GetItemHoldable(itemkey ItemKey)
{
	if (ItemKey == INVALID_ITEMKEY)
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->Holdables)
	{
		return nullptr;
	}

	TArray<FP3CmsHoldable*> CmsHoldables;
	Cms->CmsData->Holdables->GetAllRows<FP3CmsHoldable>("FP3Cms::GetItemHoldables", CmsHoldables);

	for (const FP3CmsHoldable* CmsHoldable: CmsHoldables)
	{
		if (CmsHoldable->ItemKey == ItemKey)
		{
			// Return first holdable. There must not be more than one holdable in item.
			return CmsHoldable;
		}
	}

	return nullptr;
}

const FP3CmsConsumable* GetItemConsumable(itemkey ItemKey)
{
	if (ItemKey == INVALID_ITEMKEY)
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->Consumables)
	{
		return nullptr;
	}

	TArray<FP3CmsConsumable*> CmsConsumables;
	Cms->CmsData->Consumables->GetAllRows<FP3CmsConsumable>("FP3Cms::GetItemConsumables", CmsConsumables);

	for (const FP3CmsConsumable* CmsConsumable: CmsConsumables)
	{
		if (CmsConsumable->ItemKey == ItemKey)
		{
			// Return first consumable. There must not be more than one consumable in item.
			return CmsConsumable;
		}
	}

	return nullptr;
}

const FP3CmsThrowable* GetItemThrowable(itemkey ItemKey)
{
	if (ItemKey == INVALID_ITEMKEY)
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->Throwables)
	{
		return nullptr;
	}

	TArray<FP3CmsThrowable*> CmsThrowables;
	Cms->CmsData->Throwables->GetAllRows<FP3CmsThrowable>("FP3Cms::GetItemThrowables", CmsThrowables);

	for (const FP3CmsThrowable* CmsThrowable : CmsThrowables)
	{
		if (CmsThrowable->ItemKey == ItemKey)
		{
			return CmsThrowable;
		}
	}

	return nullptr;
}

TArray<const FP3CmsInitialItem*> GetInitialItems(EP3CharClass CharClass)
{
	TArray<const FP3CmsInitialItem*> InitialItems;

	if (!Cms || !Cms->CmsData || !Cms->CmsData->InitialItems)
	{
		return InitialItems;
	}

	Cms->CmsData->InitialItems->ForeachRow<FP3CmsInitialItem>("FP3Cms::GetInitialItems", [CharClass, &InitialItems](const FName& Key, const FP3CmsInitialItem& Value)
	{
		if (Value.CharClass == EP3CharClass::Invalid || Value.CharClass == CharClass)
		{
			InitialItems.Add(&Value);
		}
	});

	return InitialItems;
}

const FP3CmsCharacterBuffRow* GetCharacterBuff(int32 CmsCharacterBuffKey)
{
	if (CmsCharacterBuffKey < 0)
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->CharacterBuffs)
	{
		return nullptr;
	}

	return Cms->CmsData->CharacterBuffs->FindRow<FP3CmsCharacterBuffRow>(FName(*FString::FromInt(CmsCharacterBuffKey)), TEXT("FP3Cms::GetCharacterBuff"));
}

const FP3CmsHealOverTimeBuffImplRow* GetHealOverTimeBuffImpl(FName CmsHealOverTimeBuffKey)
{
	if (CmsHealOverTimeBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->HealOverTimeBuffImpls)
	{
		return nullptr;
	}

	return Cms->CmsData->HealOverTimeBuffImpls->FindRow<FP3CmsHealOverTimeBuffImplRow>(CmsHealOverTimeBuffKey, TEXT("FP3Cms::GetHealOverTimeBuffImpl"));
}

const FP3CmsDamageOverTimeBuffImplRow* GetDamageOverTimeBuffImpl(FName CmsDamageOverTimeBuffKey)
{
	if (CmsDamageOverTimeBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->DamageOverTimeBuffImpls)
	{
		return nullptr;
	}

	return Cms->CmsData->DamageOverTimeBuffImpls->FindRow<FP3CmsDamageOverTimeBuffImplRow>(CmsDamageOverTimeBuffKey, TEXT("FP3Cms::GetDamageOverTimeBuffImpl"));
}

const FP3CmsAttributeModifierBuffImplRow* GetAttributeModifierBuffImpl(FName CmsAttributeModifierBuffKey)
{
	if (CmsAttributeModifierBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->AttributeModifierBuffImples)
	{
		return nullptr;
	}

	return Cms->CmsData->AttributeModifierBuffImples->FindRow<FP3CmsAttributeModifierBuffImplRow>(CmsAttributeModifierBuffKey, TEXT("FP3Cms::GetAttributeModifierBuffImpl"));
}

const FP3CmsOverlappableBuffImplRow* GetOverlappableBuffImpl(FName CmsOverlappableBuffKey)
{
	if (CmsOverlappableBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->OverlappableBuffImples)
	{
		return nullptr;
	}

	return Cms->CmsData->OverlappableBuffImples->FindRow<FP3CmsOverlappableBuffImplRow>(CmsOverlappableBuffKey, TEXT("FP3Cms::GetOverlappableBuffImpl"));
}

const FP3CmsRegenStaminaBuffImplRow* GetRegenStaminaBuffImpl(FName CmsRegenStaminaBuffKey)
{
	if (CmsRegenStaminaBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->RegenStaminaBuffImpls)
	{
		return nullptr;
	}

	return Cms->CmsData->RegenStaminaBuffImpls->FindRow<FP3CmsRegenStaminaBuffImplRow>(CmsRegenStaminaBuffKey, TEXT("FP3Cms::GetRegenStaminaBuffImpl"));
}

const FP3CmsProvokeBuffImplRow* GetProvokeBuffImpl(FName CmsProvokeBuffKey)
{
	if (CmsProvokeBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->ProvokeBuffImpls)
	{
		return nullptr;
	}

	return Cms->CmsData->ProvokeBuffImpls->FindRow<FP3CmsProvokeBuffImplRow>(CmsProvokeBuffKey, TEXT("FP3Cms::GetProvokeBuffImpl"));
}

const FP3CmsReactionBuffImplRow* GetReactionBuffImpl(FName CmsReactionBuffKey)
{
	if (CmsReactionBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->ReactionBuffImpls)
	{
		return nullptr;
	}

	return Cms->CmsData->ReactionBuffImpls->FindRow<FP3CmsReactionBuffImplRow>(CmsReactionBuffKey, TEXT("FP3Cms::GetReactionBuffImpl"));
}

const FP3CmsSummonBuffImplRow* GetSummonBuffImpl(FName CmsSummonBuffKey)
{
	if (CmsSummonBuffKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->SummonBuffImpls)
	{
		return nullptr;
	}

	return Cms->CmsData->SummonBuffImpls->FindRow<FP3CmsSummonBuffImplRow>(CmsSummonBuffKey, TEXT("FP3Cms::GetSummonBuffImpl"));
}

const FP3CmsCameraShakeRow* GetCameraShake(FName CmsCameraShakeKey)
{
	if (CmsCameraShakeKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->CameraShakes)
	{
		return nullptr;
	}
	
	return Cms->CmsData->CameraShakes->FindRow<FP3CmsCameraShakeRow>(CmsCameraShakeKey, TEXT("FP3Cms::GetCameraShake"));
}

TArray<UScriptStruct*> GetAllRowStructs()
{
	TArray<UScriptStruct*> RowStructs;

	for (TFieldIterator<UProperty> PropIt(UP3CmsData::StaticClass()); PropIt; ++PropIt)
	{
		UProperty* Property = *PropIt;
		UStructProperty* StructProperty = Cast<UStructProperty>(Property);

		if (StructProperty)
		{
			RowStructs.Add(StructProperty->Struct);
		}
	}

	return RowStructs;
}

FName FindCookingRecipeKeyWithIngredient(const TArray<AActor*>& IngredientActors)
{
	if (!Cms || !Cms->CmsData || !Cms->CmsData->CookingRecipes)
	{
		return NAME_None;
	}

	TArray<TSoftClassPtr<AActor>> IngredientActorClasses;

	for (const AActor* IngredientActor : IngredientActors)
	{
		if (IngredientActor)
		{
			IngredientActorClasses.Add(IngredientActor->GetClass());
		}
	}

	if (!ensure(Cms->CmsData->CookingRecipes->GetRowStruct() && Cms->CmsData->CookingRecipes->GetRowStruct()->IsChildOf(FP3CmsCookingRecipe::StaticStruct())))
	{
		return NAME_None;
	}

	const auto& RowMap = Cms->CmsData->CookingRecipes->GetRowMap();

	for (const auto& Iter : RowMap)
	{
		const FP3CmsCookingRecipe* Recipe = reinterpret_cast<FP3CmsCookingRecipe*>(Iter.Value);

		if (Recipe && Recipe->IngredientActorClasses == IngredientActorClasses)
		{
			return Iter.Key;
		}
	}

	return NAME_None;
}

const FP3CmsCookingRecipe* GetCookingRecipe(const FName& RecipeKey)
{
	if (RecipeKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->CookingRecipes)
	{
		return nullptr;
	}

	return Cms->CmsData->CookingRecipes->FindRow<FP3CmsCookingRecipe>(RecipeKey, TEXT("FP3Cms::GetCookingRecipe"));
}

const FP3CmsCharacter* GetCharacter(const FName& CmsCharacterKey)
{
	if (CmsCharacterKey.IsNone())
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->Characters)
	{
		return nullptr;
	}

	return Cms->CmsData->Characters->FindRow<FP3CmsCharacter>(CmsCharacterKey, TEXT("FP3Cms::GetCharacter"));
}

const FP3CmsCharacterExperiencePoint* GetCharacterExperiencePoint(int32 CharLevelKey)
{
	if (CharLevelKey == 0)
	{
		return nullptr;
	}

	if (!Cms || !Cms->CmsData || !Cms->CmsData->CharacterExperiencePoints)
	{
		return nullptr;
	}

	if (CharLevelKey > Cms->CmsData->CharacterExperiencePoints->GetRowMap().Num())
	{
		return nullptr;
	}

	return Cms->CmsData->CharacterExperiencePoints->FindRow<FP3CmsCharacterExperiencePoint>(FName(*FString::FromInt(CharLevelKey)), TEXT("FP3Cms::GetExperiencePoint"));
}

const UDataTable* GetCharacterHairTable()
{
	if (!Cms || !Cms->CmsData)
	{
		return nullptr;
	}

	return Cms->CmsData->CharacterHairs;
}

const UDataTable* GetCharacterArmorTable()
{
	if (!Cms || !Cms->CmsData)
	{
		return nullptr;
	}

	return Cms->CmsData->CharacterArmors;
}

} // namespace P3Cms

void UP3Cms::InitCms()
{
	if (IsRunningCommandlet())
	{
		return;
	}

#if P3_CMS_USE_CSV_AS_SOURCE
#if WITH_EDITOR
	ResetDataTables();
#else
	LoadDataTables();
#endif
#else // P3_CMS_USE_CSV_AS_SOURCE
	LoadDataTables();
#endif // P3_CMS_USE_CSV_AS_SOURCE

	UpdateDerivedCaches();
}

void UP3Cms::LoadDataTables()
{
	P3JsonLog(Display, "Loading CMS Tables...");
}

void UP3Cms::UpdateDerivedCaches()
{
	ItemKeyToActorClass.Empty();
	ActorClassToItemKey.Empty();
	QuestKeyToQuestDesc.Empty();
	QuestDescToQuestKey.Empty();

	if (!CmsData)
	{
		return;
	}

	for (auto&& Iter : CmsData->Items->GetRowMap())
	{
		itemkey ItemKey = FCString::Atoi(*Iter.Key.ToString());
		FP3CmsItem* CmsItem = reinterpret_cast<FP3CmsItem*>(Iter.Value);
		if (!CmsItem || CmsItem->ItemActorClass.IsNull())
		{
			P3JsonLog(Error, "Invalid cms item found", TEXT("ItemKey"), ItemKey);
			continue;
		}

		ItemKeyToActorClass.Add(ItemKey, CmsItem->ItemActorClass); // check exist
		ActorClassToItemKey.Add(CmsItem->ItemActorClass, ItemKey);
	}

	for (auto&& Iter : CmsData->Quests->GetRowMap())
	{
		questkey QuestKey = FCString::Atoi(*Iter.Key.ToString());
		FP3CmsQuest* CmsQuest = reinterpret_cast<FP3CmsQuest*>(Iter.Value);
		if (!CmsQuest || !CmsQuest->QuestDesc)
		{
			P3JsonLog(Error, "Invalid cms quest found", TEXT("QuestKey"), QuestKey);
			continue;
		}

		QuestKeyToQuestDesc.Add(QuestKey, CmsQuest->QuestDesc); // check exist
		QuestDescToQuestKey.Add(CmsQuest->QuestDesc, QuestKey);
	}
}
