// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3GameUserSettings.h"

#include "Engine/World.h"

#include "P3BGMPlayer.h"
#include "P3GameMode.h"

static TAutoConsoleVariable<float> CVarP3FieldOfViewMin(
	TEXT("p3.fieldOfViewMin"),
	65,
	TEXT("Set minimum field of view"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3FieldOfViewMax(
	TEXT("p3.fieldOfViewMax"),
	80,
	TEXT("Set maximum field of view"), ECVF_Cheat);

void UP3GameUserSettings::SetBGMVolume(float InVolume)
{
	BGMVolume = InVolume;
}

void UP3GameUserSettings::SetPadCameraSensitivity(float InSensitivity)
{
	PadCameraSensitivity = InSensitivity;
}

void UP3GameUserSettings::SetPadAimCameraSensitivity(float InSensitivity)
{
	PadAimCameraSensitivity = InSensitivity;
}

void UP3GameUserSettings::SetFieldOfView(float InFieldOfView)
{
	FieldOfView = InFieldOfView;
}
