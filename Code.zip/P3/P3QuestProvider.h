// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/TriggerBox.h"
#include "P3QuestProvider.generated.h"

/**
 * TriggerBox.Overlap -> Character.QuestComponent.StartQuest
 */
UCLASS()
class P3_API AP3QuestProvider : public ATriggerBox
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Quest")
	const class UP3QuestDesc* Quest = nullptr;

protected:
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void OnActorOverlapped(AActor* OverlappedActor, AActor* OtherActor);

	void StartQuest(class AP3Character* Character);
};
