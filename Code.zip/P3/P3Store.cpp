// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Store.h"

#include "GameFramework/Actor.h"
#include "GameFramework/PlayerController.h"
#include "TimerManager.h"

#include "Engine/NetConnection.h"
#include "Engine/World.h"
#include "P3ActorInterface.h"
#include "P3Core.h"
#include "P3Log.h"
#include "P3PlayerController.h"
#include "P3StoreArchive.h"
#include "P3StoreInterface.h"
#include "P3World.h"

void UP3StoreBase::OnStoreChanged() const
{
	if (StoreComponent)
	{
		StoreComponent->OnStoreChanged(*this);
	}
}

UP3StoreComponent::UP3StoreComponent()
{
	bReplicates = true;
}

void UP3StoreComponent::BeginPlay()
{
	Super::BeginPlay();

	ensure(GetOwner() && (Cast<IP3ActorInterface>(GetOwner()) != nullptr));

	// Make it sure only 1 store component per actor
	ensure(GetOwner()->GetComponentsByClass(UP3StoreComponent::StaticClass()).Num() == 1);
}

void UP3StoreComponent::WriteNetBuffer(TArray<FP3NetStoreData>& OutData, const TSet<FName>* ComponentNames) const
{
	APlayerController* PlayerController = GetWorld()->GetFirstPlayerController();
	UNetConnection* Connection = PlayerController ? PlayerController->NetConnection : nullptr;

	const TSet<UActorComponent*>& Components = GetOwner()->GetComponents();

	for (UActorComponent* Comp : Components)
	{
		IP3ComponentInterface* StoreInterface = Cast<IP3ComponentInterface>(Comp);
		if (StoreInterface && !StoreInterface->IsNetSerializeDisabled())
		{
			if (!ComponentNames || ComponentNames->Contains(Comp->GetFName()))
			{
				FP3StoreBitWriter BitWriter(P3Core::GetP3World(*this), 256, true);

				StoreInterface->NetSerialize(BitWriter);

				FP3NetStoreData NetData;
				NetData.Name = Comp->GetName();
				NetData.ClassName = Comp->GetClass()->GetPathName();
				NetData.bIsInstanceComponent = (Comp->CreationMethod == EComponentCreationMethod::Instance);
				NetData.Buffer = *BitWriter.GetBuffer();

				// TODO: too many buffer copies. got to use FBitWriterMark with shared buffer
				OutData.Add(NetData);
			}
		}
	}
}

void UP3StoreComponent::SyncWithNetBuffer(class UNetConnection* Connection, const TArray<FP3NetStoreData>& NetData)
{
	const TSet<UActorComponent*>& Components = GetOwner()->GetComponents();

	for (const FP3NetStoreData& Data : NetData)
	{
		UActorComponent* FoundComponent = nullptr;

		for (UActorComponent* Comp : Components)
		{
			if (Comp->GetName() == Data.Name)
			{
				FoundComponent = Comp;
				break;
			}
		}

		if (!FoundComponent && Data.bIsInstanceComponent)
		{
			UClass* ActorClass = StaticLoadClass(UActorComponent::StaticClass(), NULL, *Data.ClassName);
			if (ensure(ActorClass))
			{
				FoundComponent = NewObject<UActorComponent>(GetOwner(), ActorClass, FName(*Data.Name));
				if (ensure(FoundComponent))
				{
					USceneComponent* SceneComponent = Cast<USceneComponent>(FoundComponent);
					if (SceneComponent && !GetOwner()->GetRootComponent())
					{
						GetOwner()->SetRootComponent(SceneComponent);
					}

					FoundComponent->RegisterComponent();
				}
			}
		}

		if (!ensure(FoundComponent))
		{
			continue;
		}

		IP3ComponentInterface* StoreInterface = Cast<IP3ComponentInterface>(FoundComponent);

		if (ensure(StoreInterface))
		{
			// TODO: BitReader expect non const buffer strangely.... got to fix that...
			TArray<uint8> TmpBuffer = Data.Buffer;

			FP3StoreBitReader BitReader(P3Core::GetP3World(*this), TmpBuffer.GetData(), Data.Buffer.Num() * sizeof(uint8) * 8);
			StoreInterface->NetSerialize(BitReader);
		}
	}
}

void UP3StoreComponent::RegisterStore(UObject* Owner, UP3StoreBase* Store)
{
	ensure(StoreMap.Find(Owner) == nullptr);

	StoreMap.Add(Owner, Store);
}

void UP3StoreComponent::UnregisterStore(UObject* Owner, UP3StoreBase* Store)
{
	StoreMap.Remove(Owner);
}

void UP3StoreComponent::OnStoreChanged(const UP3StoreBase& Store)
{

}

//void UP3StoreComponent::RequestSync()
//{
//	AP3PlayerController* MyPlayerController = Cast<AP3PlayerController>(GetWorld()->GetFirstPlayerController());
//
//	if (ensure(MyPlayerController))
//	{
//		MyPlayerController->RequestSyncStore(this);
//	}
//}

//void UP3StoreComponent::RequestDelayedSync()
//{
//	P3JsonLog(Display, "Store requesting delayed sync");
//
//	FTimerHandle DummyHandle;
//	TWeakObjectPtr<UP3StoreComponent> ThisPtr(this);
//
//	GetWorld()->GetTimerManager().SetTimer(DummyHandle, FTimerDelegate::CreateLambda([ThisPtr]()
//	{
//		if (ThisPtr.IsValid())
//		{
//			ThisPtr->RequestSync();
//		}
//	}), 1.0f, false);
//}

void UP3StoreComponent::Sync(const TArray<UObject*>& Objects, const TArray<UP3StoreBase*>& Stores)
{
	StoreMap.Empty();

	ensure(Objects.Num() == Stores.Num());

	const int32 NumItems = FMath::Min(Objects.Num(), Stores.Num());

	for (int32 Index = 0; Index < NumItems; ++Index)
	{
		if (!ensure(Objects[Index]) || !ensure(Stores[Index]))
		{
			continue;
		}

		StoreMap.Add(Objects[Index], Stores[Index]);

		Stores[Index]->OnStoreSynced.Broadcast();
	}
}

