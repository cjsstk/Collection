// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PickupableComponent.h"

#include "Components/PrimitiveComponent.h"
#include "DrawDebugHelpers.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystemComponent.h"

#include "Action/P3PickupAction.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3GameState.h"
#include "P3Physics.h"
#include "P3PickupComponent.h"

static TAutoConsoleVariable<int32> CVarP3PickupableLockDebug(
	TEXT("p3.pickupableLockDebug"),
	0,
	TEXT("1: enable debug. 0: disable dibug"), ECVF_Cheat);

UP3PickupableComponent::UP3PickupableComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3PickupableComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (!IsRunningDedicatedServer())
	{
		TickPickupableEffect();
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3PickupableLockDebug.GetValueOnGameThread() != 0)
	{
		DrawDebugString(GetWorld(), GetOwner()->GetActorLocation(), FString::Printf(TEXT("Locked = %s, OwnerActorId = %d"),
			Server_bIsInteractionLocked ? TEXT("True") : TEXT("False"),
			LockerAction ? Cast<AP3Character>(LockerAction->GetOwnerActor())->GetActorId() : 0),
			nullptr, FColor::White, 0.0f, true);
	}
#endif
}

void UP3PickupableComponent::TickPickupableEffect()
{
	AActor* OwnerActor = GetOwner();

	if (!OwnerActor)
	{
		return;
	}

	const bool bIsAttached = (OwnerActor->GetAttachParentActor() != nullptr);

	UParticleSystem* EffectParticle = P3Core::GetGameResource(this).LootEffectParticle;

	if (!bIsAttached && !PickupableEffectParticleComponent && EffectParticle)
	{
		PickupableEffectParticleComponent = UGameplayStatics::SpawnEmitterAttached(EffectParticle, OwnerActor->GetRootComponent(), FName(), FVector::ZeroVector, FRotator::ZeroRotator, EAttachLocation::KeepRelativeOffset);

		if (PickupableEffectParticleComponent)
		{
			PickupableEffectParticleComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
			PickupableEffectParticleComponent->bAbsoluteRotation = true;
			PickupableEffectParticleComponent->SetWorldRotation(FRotator::ZeroRotator);
		}
	}
	else if (bIsAttached && PickupableEffectParticleComponent)
	{
		PickupableEffectParticleComponent->DestroyComponent();
	}
}

void UP3PickupableComponent::DisablePhysicsForPickup()
{
	AActor* Owner = GetOwner();
	if (!ensure(Owner))
	{
		return;
	}

	TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
	Owner->GetComponents(PrimComps);

	for (UPrimitiveComponent* PrimComp : PrimComps)
	{
		SavedCollisionEnabled.Add(PrimComp, PrimComp->GetCollisionEnabled());
		SavedCollisionResponse.Add(PrimComp, PrimComp->GetCollisionResponseToChannels());

		const bool bFlame = (PrimComp->GetCollisionResponseToChannel(ECC_FLAME) != ECR_Ignore);

		PrimComp->SetSimulatePhysics(false);
		PrimComp->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		PrimComp->SetCollisionResponseToAllChannels(ECR_Ignore);
		PrimComp->SetCollisionResponseToChannel(ECC_COMBAT, ECR_Overlap);

		if (bFlame)
		{
			PrimComp->SetCollisionResponseToChannel(ECC_FLAME, ECR_Overlap);
		}
	}
}

void UP3PickupableComponent::RestorePhysicsForPutdown(class AP3Character* Character)
{
	AActor* Owner = GetOwner();
	if (!ensure(Owner))
	{
		return;
	}

	TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
	Owner->GetComponents(PrimComps);

	for (UPrimitiveComponent* PrimComp : PrimComps)
	{
		const ECollisionEnabled::Type* CollisionEnabled = SavedCollisionEnabled.Find(PrimComp);
		if (CollisionEnabled && CollisionEnabledHasQuery(*CollisionEnabled))
		{
			PrimComp->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		}

		const FCollisionResponseContainer* CollisionResponse = SavedCollisionResponse.Find(PrimComp);
		if (CollisionResponse)
		{
			PrimComp->SetCollisionResponseToChannels(*CollisionResponse);
		}
		PrimComp->SetCollisionResponseToChannel(ECC_Camera, ECR_Ignore);

		if (Character)
		{
			TArray<AActor*> ChildActors;
			Character->GetAttachedActors(ChildActors);

			PrimComp->IgnoreActorWhenMoving(Character, true);
			for (AActor* Actor : ChildActors)
			{
				PrimComp->IgnoreActorWhenMoving(Actor, true);
			}
		}
	}
}

void UP3PickupableComponent::RestorePhysicsAfterPutdown()
{
	AActor* Owner = GetOwner();
	if (!ensure(Owner))
	{
		return;
	}

	TInlineComponentArray<UPrimitiveComponent*, 8> PrimComps;
	Owner->GetComponents(PrimComps);

	for (UPrimitiveComponent* PrimComp : PrimComps)
	{
		if (PrimComp == Owner->GetRootComponent())
		{
			PrimComp->SetSimulatePhysics(true);
		}

		const ECollisionEnabled::Type* CollisionEnabled = SavedCollisionEnabled.Find(PrimComp);
		if (CollisionEnabled)
		{
			PrimComp->SetCollisionEnabled(*CollisionEnabled);
		}
		const FCollisionResponseContainer* CollisionResponse = SavedCollisionResponse.Find(PrimComp);
		if (CollisionResponse)
		{
			PrimComp->SetCollisionResponseToChannels(*CollisionResponse);
		}
		PrimComp->ClearMoveIgnoreActors();
	}
}

void UP3PickupableComponent::Server_SetInteractionLock(class UP3PickupPawnAction* InLockerAction, bool bInInteractionLocked)
{
	/** Try to Lock this Component */
	if (bInInteractionLocked)
	{
		if (Server_IsInteractionLocked() || LockerAction)
		{
			ensure(0);
			return;
		}
		LockerAction = InLockerAction;
	}
	/** Try to Unlock this Component */
	else
	{
		if (!Server_IsInteractionLocked() || !LockerAction || LockerAction != InLockerAction)
		{
			ensure(0);
			return;
		}
		LockerAction = nullptr;
	}

	Server_bIsInteractionLocked = bInInteractionLocked;
}
