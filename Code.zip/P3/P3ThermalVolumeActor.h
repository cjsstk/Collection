// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3ThermalVolumeActor.generated.h"

/**
 * Thermal Volume (ascending air current)
 */
UCLASS(Blueprintable)
class P3_API AP3ThermalVolumeActor : public AP3Actor
{
	GENERATED_BODY()

	AP3ThermalVolumeActor();

	virtual void NotifyActorBeginOverlap(AActor* OtherActor) override;
	virtual void NotifyActorEndOverlap(AActor* OtherActor) override;

	virtual void NetSerialize(FArchive& Archive) override;

	UFUNCTION(BlueprintCallable)
	bool IsThermalActive() const { return Net_bThermalActive; }

	UFUNCTION(BlueprintCallable)
	void Server_SetThermalActive(bool bInActive);

protected:
	virtual void BeginPlay() override;
	virtual void Client_OnEvent(FName EventName, int32 Param) override;

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveThermalActivateChanged(bool bActivate);

private:
	void ThermalActiveChanged();

	UPROPERTY(EditAnywhere, Category = "Thermal")
	FVector TargetVelocity = FVector(0, 0, 400);

	UPROPERTY(EditAnywhere, Category = "Thermal")
	float Strength = 10.0f;

	/** Set true if this thermal is active as default */
	UPROPERTY(EditAnywhere, Category = "Thermal")
	bool bDefaultThermalActive = true;

	bool Net_bThermalActive = true;
};
