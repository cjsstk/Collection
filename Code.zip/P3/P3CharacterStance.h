// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

UENUM(Blueprintable)
enum class EP3CharacterStance : uint8
{
	Idle,
	Pickup,
	Push,
	Combat
};
