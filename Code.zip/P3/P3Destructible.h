// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "Network/Lib/P3NetCore.h"
#include "P3Destructible.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3DestructibleFratured, class AP3Destructible*, Destructible);

USTRUCT()
struct FNetExplode
{
	GENERATED_BODY()

	UPROPERTY()
	FVector HitLocation;
	
	UPROPERTY()
	FVector ImpulseDir;
	
	UPROPERTY()
	float ImpulseStrength;
};

UCLASS()
class P3_API AP3Destructible : public AP3Actor
{
	GENERATED_BODY()
	
public:	
	AP3Destructible();

	void Server_SetPOIOriginLocation(const FVector& Location);

	UFUNCTION(BlueprintCallable)
	void EnablePhysics();

	UFUNCTION(BlueprintCallable)
	void DisablePhysics();

	UFUNCTION(BlueprintCallable)
	void Server_EnableDestruction(bool bEnable);

	void Server_SetMinImpulseSizeToExplode(float Impulse);
	void Server_SetHitIgnoreActors(const TArray<AActor*>& Actors);
	void Server_AddHitIgnoreActor(AActor* Actor);
	const TArray<AActor*>& Server_GetHitIgnoreActors() const { return Server_HitIgnoreActors; }
	void Server_SetExplosionIgnoreActors(const TArray<AActor*>& Actors);
	void Server_AddExplosionIgnoreActor(AActor* Actor);

	UFUNCTION()
	void Client_OnExplode(const FP3DediToClientHandlerParams& Params);

	bool Server_IsExploded() const { return Server_bExploded; }
	bool IsExploded() const { return Multicast_bExploded; }

	UFUNCTION(BlueprintCallable)
	void Server_HitByLargeCharacter();

	void Server_Fracture();

	bool GetFractureByLargeCharacterOverlap() const { return bFractureByLargeCharacterOverlap; }
	bool GetFractureByLargeCharacterCharging() const { return bFractureByLargeCharacterCharging; }

	UFUNCTION(BlueprintCallable)
	class ADestructibleActor* GetSpawnedDestructibleActor() const { return DestructibleActor; }

	virtual void PostInitializeComponents() override;

	virtual void NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;

	/** AP3Actor */
	virtual void NetSerialize(FArchive& Archive) override;

#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

	/**
	 * Return index of damaged mesh for given health point
	 * returns -1 if not damaged at all
	 * returns NumDamagedMeshes if fully damaged
	 */
	static int32 CalcDamagedMeshIndex(int32 HealthPoint, int32 MaxHealthPoint, int32 NumDamagedMeshes);

	UPROPERTY(BlueprintAssignable)
	FP3DestructibleFratured DestructibleFractured;

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

private:
	void Server_Explode(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength);
	void MulticastExplode(const FVector& HitLocation, const FVector& ImpulseDir, float ImpulseStrength);

	void Server_CreateHealthPointComponent();

	void DamagedMeshIndexChanged();

	void Server_SetSleep(bool bNewSleep);
	void SleepChanged();

	UFUNCTION()
	void Server_OnHealthChanged(class UP3HealthPointComponent* HealthPointComponent, int32 OldHealthPoint, int32 NewHealthPoint);

	UPROPERTY(VisibleAnywhere, meta = (AllowPrivateAccess = "true"))
	class UStaticMeshComponent* StaticMeshComponent;

	UPROPERTY(Transient)
	class UP3HealthPointComponent* HealthPointComponent;

	/** Toggle Static mesh physics simulation */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	bool bStatic = false;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	bool bEnableDestruction = true;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	class UStaticMesh* StaticMesh;

	/** Optional. If set 4 meshes, each mesh will be used when HP amount become 20%, 40%, 60%, 80%. (Default static mesh will be used on 81~100%) */
	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	TArray<class UStaticMesh*> DamagedStaticMeshes;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	class UDestructibleMesh* DestructableMesh;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible")
	TArray<class UMaterialInterface*> Materials;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Explosion")
	class UParticleSystem* ExplosionParticle;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Explosion")
	float ExplosionParticleScale = 1.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Destructible - Explosion")
	class USoundBase* ExplosionSound;

	/** < 0 means no explosion by physical impulse */
	UPROPERTY(EditAnywhere, Category = "Destructible - Explosion")
	float MinImpulseSizeToExplode = 100000;

	UPROPERTY(EditAnywhere, Category = "Destructible - Explosion")
	float DestructibleImpulseMultiplier = 1.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Explosion")
	float LifespanAfterHit = 5.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Explosion")
	float DebrisLifespan = 5.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	float Damage = 50.0f;

	/** Damage will be multiplied by this to ally character */
	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	int32 DamageToAllyPermil = 1000;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Destructible - Damage", meta = (AllowPrivateAccess = "true"))
	float DamageRadius = 500.0f;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	bool bKnockDown = false;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	float KnockDownDurationSeconds = 0;

	UPROPERTY(EditAnywhere, Category = "Destructible - Damage")
	float HitActionImpulseSpeed = 1000.0f;

	/** If set, burn around up to Damage Radius */
	UPROPERTY(EditAnywhere, Category = "Destructible - Fire")
	bool bBurn = false;

	/** Near by Flammable components will take burn for this amount of time */
	UPROPERTY(EditAnywhere, Category = "Destructible - Fire", meta = (EditCondition = "bBurn"))
	float BurnPower = 1.0f;

	/** If set true, splash water on Damage Radius */
	UPROPERTY(EditAnywhere, Category = "Destructible - Water")
	bool bWaterSplash = false;

	/** Set actor class for water splash */
	UPROPERTY(EditAnywhere, Category = "Destructible - Water", meta = (EditCondition = "bWaterSplash"))
	TSubclassOf<AActor> WaterPuddleActorClass;

	/** Set it > 0 to make it combat-compatible */
	UPROPERTY(EditAnywhere, Category = "Destructible")
	float HealthPoint = 0.0f;

	/** Set true to allow large character fracture this object by overlapping  */
	UPROPERTY(EditAnywhere, Category = "Destructible")
	bool bFractureByLargeCharacterOverlap = true;

	/** Set true to allow large character fracture this object by charging action  */
	UPROPERTY(EditAnywhere, Category = "Destructible")
	bool bFractureByLargeCharacterCharging = true;

	UPROPERTY(Transient)
	class ADestructibleActor* DestructibleActor;

	/** Actor list that hit event will not trigger destruction */
	UPROPERTY(Transient)
	TArray<AActor*> Server_HitIgnoreActors;

	/** Actor list that will not affected by explosion */
	UPROPERTY(Transient)
	TArray<AActor*> Server_ExplosionIgnoreActors;

	bool Server_bHasPOIOriginLocation = false;
	FVector Server_POIOriginLocation = FVector::ZeroVector;

	bool Server_bExploded = false;
	float ExplodedAgeSeconds = 0;

	bool Multicast_bExploded = false;

	/**
	 * Current damaged static mesh index
	 * Only valid if DamagedStaticMeshes is not empty
	 */
	int32 Net_DamagedMeshIndex = -1;

	bool Net_bSleep = false;
};
