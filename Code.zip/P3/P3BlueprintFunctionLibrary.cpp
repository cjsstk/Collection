// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BlueprintFunctionLibrary.h"

#include "Misc/FileHelper.h"
#include "Misc/Paths.h"
#include "Animation/AnimInstance.h"
#include "Engine/Engine.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "Command/P3CommandComponent.h"
#include "Chemical/P3FlammableComponent.h"
#include "P3Combat.h"
#include "P3Core.h"
#include "P3Character.h"
#include "P3GameState.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"
#include "P3Physics.h"
#include "P3WeaponType.h"
#include "P3World.h"

bool UP3BlueprintFunctionLibrary::IsP3NetModeServer(UObject* WorldContextObject)
{
	if (!ensure(WorldContextObject) || !ensure(WorldContextObject->GetWorld()))
	{
		return false;
	}

	return P3Core::IsP3NetModeServerInstance(*WorldContextObject->GetWorld());
}

bool UP3BlueprintFunctionLibrary::IsP3NetModeServerInstance(UObject* WorldContextObject)
{
	if (!ensure(WorldContextObject) || !ensure(WorldContextObject->GetWorld()))
	{
		return false;
	}

	return P3Core::IsP3NetModeServerInstance(*WorldContextObject->GetWorld());
}

UP3World* UP3BlueprintFunctionLibrary::GetP3World(UObject* WorldContextObject)
{
	if (!ensure(WorldContextObject) || !ensure(WorldContextObject->GetWorld()))
	{
		return nullptr;
	}

	return P3Core::GetP3World(*WorldContextObject);
}

class AActor* UP3BlueprintFunctionLibrary::GetP3WorldParticleActor(UObject* WorldContextObject)
{
	return P3Core::GetP3WorldParticleActor(WorldContextObject);
}

FString UP3BlueprintFunctionLibrary::GetChangeLog()
{
	FString OutLog;

	FString FilePath = FPaths::ProjectContentDir() / TEXT("BuildNonAsset") / TEXT("ChangeLog.txt");

	const bool bSuccess = FFileHelper::LoadFileToString(OutLog, *FilePath);

	if (!bSuccess)
	{
		UE_LOG(P3Log, Warning, TEXT("Failed to load change log from file"));
		return FString();
	}

	return OutLog;
}

float UP3BlueprintFunctionLibrary::GetSlotMontageLocalWeight(class UAnimInstance* AnimInstance, FName SlotNodeName)
{
	if (!AnimInstance)
	{
		return 0;
	}

	const float SlotWeight = AnimInstance->GetSlotMontageLocalWeight(SlotNodeName);

	return SlotWeight;
}

void UP3BlueprintFunctionLibrary::ExplodeBP(UObject* WorldContextObject, const FVector& Location, float Radius, float Damage, float ImpulseVelocity, bool bKnockDown, float KnockDownDurationSeconds, const TArray<AActor*>& IgnoreActors)
{
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

	if (!World)
	{
		return;
	}

	if (!P3Core::IsP3NetModeServerInstance(*World))
	{
		return;
	}

	TArray<AActor*> OverlapActors;

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(Radius);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActors(IgnoreActors);

	TArray<FOverlapResult> OverlapResults;
	World->OverlapMultiByChannel(OverlapResults, Location, FQuat::Identity, ECC_Pawn, CollisionShape, QueryParams);

	TArray<AActor*> HitActors;

	for (const FOverlapResult& OverlapResult : OverlapResults)
	{
		AActor* Actor = OverlapResult.Actor.Get();
		if (!Actor)
		{
			continue;
		}

		UP3PawnActionComponent* ActionComp = Actor->FindComponentByClass<UP3PawnActionComponent>();

		if (ActionComp)
		{
			if (HitActors.Contains(Actor))
			{
				continue;
			}

			HitActors.Add(Actor);

			const FVector& SourceToTargetDirection = (Actor->GetActorLocation() - Location).GetSafeNormal();

			// TODO: maybe we need to add attack action id to make it clear
			FP3PawnActionStartRequestParams Params;
			Params.CombatHit_Damage = Damage;
			Params.CombatHit_SourceActor = nullptr;
			Params.CombatHit_Location = Location;
			//Params.CombatHitImpactLocalDirection = TargetActor->GetActorRotation().UnrotateVector(DamageEvent.ImpactDirection);
			Params.CombatHit_bIsKnockDown = bKnockDown;
			Params.CombatHit_KnockDownDurationSeconds = KnockDownDurationSeconds;
			Params.CombatHit_Impulse = SourceToTargetDirection * ImpulseVelocity * 80;	// 80 here for Velocity -> Impulse conversion

			//// Rotate to source target, except player
			//if (!Actor || !Actor->GetNetOwningPlayer())
			//{
			//	Params.CombatHit_Rotator = (-SourceToTargetDirection).Rotation();
			//}

			ActionComp->StartAction(EPawnActionType::CombatHit, _FUNCTION_TEXT, Params);

			UP3CommandComponent* CommandComp = Actor->FindComponentByClass<UP3CommandComponent>();
			if (CommandComp)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.ApplyDamage_DamageAmount = Damage;
				CommandParams.ApplyDamage_SourceActor = nullptr;
				CommandParams.ApplyDamage_HitLocation = Location;
				CommandParams.ApplyDamage_Reason = EP3HealthChangeReason::Explode;

				CommandComp->RequestCommand(UP3ApplyDamageCommand::StaticClass(), CommandParams);
			}
		}
		else
		{
			// TODO: this works for now, but we have to find a good way to Broadcast to client
			P3Combat::ChangeActorHealth(nullptr, *Actor, -Damage, EP3HealthChangeReason::Explode);
		}
	}
}

void UP3BlueprintFunctionLibrary::Server_BurnAround(UObject* WorldContextObject, const FVector& Location, float Radius, float BurnSeconds, const TArray<AActor*>& IgnoreActors, UObject* SourceObject)
{
	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);

	if (!World)
	{
		return;
	}

	if (!ensure(P3Core::IsP3NetModeServerInstance(*World)))
	{
		return;
	}

	TArray<AActor*> OverlapActors;

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(Radius);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActors(IgnoreActors);

	TArray<FOverlapResult> OverlapResults;
	World->OverlapMultiByChannel(OverlapResults, Location, FQuat::Identity, ECC_FLAME, CollisionShape, QueryParams);

	for (const FOverlapResult& OverlapResult : OverlapResults)
	{
		AActor* Actor = OverlapResult.Actor.Get();
		UP3FlammableComponent* FlammableComp = Actor ? Actor->FindComponentByClass<UP3FlammableComponent>() : nullptr;
		if (FlammableComp)
		{
			FlammableComp->Server_Burn(BurnSeconds, SourceObject);
		}
	}
}

bool UP3BlueprintFunctionLibrary::IsTempWeapon(EP3WeaponType WeaponType)
{
	return ::IsTempWeapon(WeaponType);
}

bool UP3BlueprintFunctionLibrary::GetAllBlueprintNamesInPath(FName Path, TArray<FName>& Result, UClass* BaseClass)
{
	return P3Core::GetAllBlueprintNamesInPath(Path, Result, BaseClass);
}

void UP3BlueprintFunctionLibrary::CreateChildActor(class UChildActorComponent* ChildActorComp)
{
	ChildActorComp->CreateChildActor();
}

void UP3BlueprintFunctionLibrary::HttpRequestURL(UObject* WorldContextObject, const FString& Url, bool& bSucceeded, FString& StringContent, struct FLatentActionInfo LatentInfo)
{
	bSucceeded = false;
	StringContent = FString();

	if (UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::Assert))
	{
		FLatentActionManager& LatentActionManager = World->GetLatentActionManager();
		if (LatentActionManager.FindExistingAction<FLatentHttpRequestAction>(LatentInfo.CallbackTarget, LatentInfo.UUID) == NULL)
		{
			FHttpModule* Http = &FHttpModule::Get();

			TSharedRef<IHttpRequest> Request = Http->CreateRequest();
			Request->SetURL(Url);
			Request->SetVerb("GET");
			Request->SetHeader(TEXT("User-Agent"), "X-UnrealEngine-Agent");
			Request->SetHeader("Content-Type", TEXT("application/json"));

			FLatentHttpRequestAction* Action = new FLatentHttpRequestAction(Request, bSucceeded, StringContent, LatentInfo);

			LatentActionManager.AddNewAction(LatentInfo.CallbackTarget, LatentInfo.UUID, Action);
		}
	}
}

void UP3BlueprintFunctionLibrary::HttpRequestNewRanking(UObject* WorldContextObject, const FString& Url, const FString& Stage, const FString& Name, int32 Record, bool& bSucceeded, FString& StringContent, struct FLatentActionInfo LatentInfo)
{
	bSucceeded = false;
	StringContent = FString();

	if (UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::Assert))
	{
		FLatentActionManager& LatentActionManager = World->GetLatentActionManager();
		if (LatentActionManager.FindExistingAction<FLatentHttpRequestAction>(LatentInfo.CallbackTarget, LatentInfo.UUID) == NULL)
		{
			FHttpModule* Http = &FHttpModule::Get();

			TSharedRef<IHttpRequest> Request = Http->CreateRequest();
			Request->SetURL(Url);
			Request->SetVerb("POST");
			Request->SetHeader(TEXT("User-Agent"), "X-UnrealEngine-Agent");
			Request->SetHeader("Content-Type", TEXT("application/json"));
			Request->SetContentAsString(FString::Printf(TEXT("{\"version\":\"milestone2\",\"stage\":\"%s\",\"name\":\"%s\",\"time\":%d}"), *Stage, *Name, Record));

			FLatentHttpRequestAction* Action = new FLatentHttpRequestAction(Request, bSucceeded, StringContent, LatentInfo);

			LatentActionManager.AddNewAction(LatentInfo.CallbackTarget, LatentInfo.UUID, Action);
		}
	}
}

void UP3BlueprintFunctionLibrary::Server_CommandTeleportCharacter(class AP3Character* Character, const FVector& Location, const FRotator& Rotation)
{
	if (!ensure(Character))
	{
		return;
	}

	FP3CommandRequestParams Params;
	Params.Teleport_Location = Location;
	Params.Teleport_Rotation = Rotation;

	Character->GetCommandComponent()->RequestCommand(UP3TeleportCommand::StaticClass(), Params);
}

void UP3BlueprintFunctionLibrary::Server_SendToastMessageToPlayerByCharacter(class AP3Character* Character, const FText& Message)
{
	if (!ensure(Character))
	{
		return;
	}

	P3Core::GetP3World(*Character)->Server_SendToastMessage(*Character, Message);
}

void UP3BlueprintFunctionLibrary::Server_SendToastMessageToAllPlayers(UObject* WorldContextObject, const FText& Message)
{
	if (!ensure(WorldContextObject))
	{
		return;
	}

	P3Core::GetP3World(*WorldContextObject)->Server_SendToastMessageToAll(Message);
}

FLatentHttpRequestAction::FLatentHttpRequestAction(TSharedRef<IHttpRequest> InHttpRequest, bool& bInOutSucceeded, FString& InOutString, const FLatentActionInfo& LatentInfo) 
	: ExecutionFunction(LatentInfo.ExecutionFunction)
	, OutputLink(LatentInfo.Linkage)
	, CallbackTarget(LatentInfo.CallbackTarget)
	, OutString(InOutString)
	, bOutSucceeded(bInOutSucceeded)
	, Request(InHttpRequest)
{
	bOutSucceeded = false;

	Request->OnProcessRequestComplete().BindRaw(this, &FLatentHttpRequestAction::OnHttpResponseReceived);
	Request->ProcessRequest();
}

FLatentHttpRequestAction::~FLatentHttpRequestAction()
{
	Request->OnProcessRequestComplete().Unbind();
}

void FLatentHttpRequestAction::UpdateOperation(FLatentResponse& Response)
{
	if (bCompleted)
	{
		Request->OnProcessRequestComplete().Unbind();
	}

	Response.FinishAndTriggerIf(bCompleted, ExecutionFunction, OutputLink, CallbackTarget);
}

void FLatentHttpRequestAction::OnHttpResponseReceived(FHttpRequestPtr InRequest, FHttpResponsePtr Response, bool bWasSuccessful)
{
	bCompleted = true;
	bOutSucceeded = bWasSuccessful;

	if (bWasSuccessful)
	{
		OutString = Response.IsValid() ? Response->GetContentAsString() : FString();
	}
}

#if WITH_EDITOR
FString FLatentHttpRequestAction::GetDescription() const
{
	return FString::Printf(TEXT("HttpRequest"));
}
#endif	// WITH_EDITOR
