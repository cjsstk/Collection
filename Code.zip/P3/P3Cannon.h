// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3SignalReceiver.h"
#include "P3Cannon.generated.h"

UCLASS()
class P3_API AP3Cannon : public AP3Actor
{
	GENERATED_BODY()
	
public:	
	AP3Cannon();

	virtual void Tick(float DeltaTime) override;
	virtual void Reset() override;

	UFUNCTION(BlueprintCallable)
	void Server_EnableFire(bool bEnable) { Server_bCanFire = bEnable; }
	void SetOverloaded(bool bInOverload);

	void Server_AddCannonBalls(int32 InNum);

	UFUNCTION(BlueprintImplementableEvent)
	void OnChangeOverloadedBP(bool bInOverloaded);

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveCannonBallChanged(int32 OldBalls, int32 NewBalls);

	virtual void NetSerialize(FArchive& Archive) override;

protected:
	virtual void BeginPlay() override;

private:
	UFUNCTION()
	void Fire(bool bOnFire);

	void Server_SetCurrentCannonBall(int32 NewCurrentCannonBall);

	/** Spawn Projectile Class */
	UPROPERTY(EditDefaultsOnly, Category = SpawnProjectile)
	TSubclassOf<AP3Actor> SpawnProjectileClass;

	UPROPERTY(BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	int32 Net_NumLoadedCannonBalls = 0;

	/** -1 is infinite Fire */
	UPROPERTY(EditDefaultsOnly)
	int32 DefaultNumLoadedCannonBalls = 0;

	UPROPERTY(EditDefaultsOnly)
	int32 MaxFireCount = 3;

	int32 Server_NumFired = 0;

	bool Server_bIsInfiniteCannonBall = false;
	bool Server_bCanFire = false;
	bool Net_bIsOverloaded = false;
};


UCLASS()
class P3_API AP3CannonBallInserter : public AP3SignalReceiver
{
public:
	GENERATED_BODY()

protected:
	virtual void Server_OnSignal(bool bOn) override;

private:
	UPROPERTY(EditInstanceOnly)
	AP3Cannon* CannonActor;
};