// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PushComponent.h"
#include "P3Character.h"
#include "P3PickupComponent.h"
#include "P3PushableComponent.h"
#include "P3StaminaPointComponent.h"
#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Engine/World.h"

static TAutoConsoleVariable<int32> CVarP3PushDebug(
    TEXT("p3.pushDebug"),
    0,
    TEXT("0: debug off. 1: debug on"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3PushImpactTimeoutSeconds(
    TEXT("p3.pushImpactTimeoutSeconds"),
    0.5f,
    TEXT("If no more impact reported for this duration, stop pushing"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3PushLockRotation(
    TEXT("p3.pushLockRotation"),
    1,
    TEXT("1: lock character rotation towards pushing direction. 0: dont' do that"), ECVF_Cheat);

UP3PushComponent::UP3PushComponent()
	: LastPushableImpactTime(0)
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UP3PushComponent::BeginPlay()
{
	Super::BeginPlay();
}

void UP3PushComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (!ensure(Character))
		{
			return;
		}

		AActor* TargetActor = CurrentTargetActor;

		// If we have target, see if it's still valid
		if (TargetActor)
		{
			bool bStopPushing = false;

			// Check timeout
			const float CurrentTime = GetWorld()->GetTimeSeconds();
			const float TimeSinceNoImpact = CurrentTime - LastPushableImpactTime;

			if (TimeSinceNoImpact > CVarP3PushImpactTimeoutSeconds.GetValueOnGameThread())
			{
				// Timeout
				bStopPushing = true;
			}
			else if (!Character->IsOnGround())
			{
				bStopPushing = true;
			}
			else
			{
				// See if player still want to push it
				const FVector CharacterAccelerationDir = Character->GetLastMovementInputVector();
				if (!CharacterAccelerationDir.IsNearlyZero() 
					&& ((CharacterAccelerationDir | LastPushableImpact.Normal) >= -0.5f))
				{
					// Player doesn't want to push it anymore
					bStopPushing = true;
				}
			}

			if (bStopPushing)
			{
				FP3CommandRequestParams CommandParams;
				CommandParams.SetPushing_bNewPushing = false;

				Character->GetCommandComponent()->RequestCommand(UP3SetPushingCommand::StaticClass(), CommandParams);
			}
		}
	}
}

void UP3PushComponent::NetSerialize(FArchive& Archive)
{
	Archive << CurrentTargetActor;
}

void UP3PushComponent::SetPushTargetActor(AActor* Actor)
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (CurrentTargetActor)
		{
			UP3PushableComponent* PushableComp = CurrentTargetActor->FindComponentByClass<UP3PushableComponent>();
			if (ensure(PushableComp))
			{
				PushableComp->Server_RemovePusher(*GetOwner());
			}
		}
	}

	CurrentTargetActor = Actor;

	if (CurrentTargetActor)
	{
		UP3PushableComponent* PushableComp = Actor->FindComponentByClass<UP3PushableComponent>();

		if (ensure(PushableComp))
		{
			bLockPushDirection = PushableComp->IsLockPushDirection();
		}
		else
		{
			bLockPushDirection = false;
		}

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			if (ensure(PushableComp))
			{
				PushableComp->Server_AddPusher(*GetOwner());
			}
		}
	}
}

void UP3PushComponent::OnMoveBlockedBy(const FHitResult& Impact)
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	if (!Character->IsOnGround())
	{
		return;
	}

	if (Character->GetCharacterStoreBP().Stance == EP3CharacterStance::Push)
	{
		// Was already pushing, see if it's same object. if it is, we have nothing to do now
		if (CurrentTargetActor == Impact.GetActor())
		{
			LastPushableImpact = Impact;
			LastPushableImpactTime = GetWorld()->GetTimeSeconds();
			return;
		}
	}

	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		return;
	}

	AActor* TargetActor = Impact.GetActor();
	if (!TargetActor)
	{
		return;
	}

	// See if it's pushable object
	UP3PushableComponent* PushableComp = TargetActor->FindComponentByClass<UP3PushableComponent>();

	if (!PushableComp)
	{
		return;
	}

	// See if character is actually moving toward that object
	const FVector CharacterMoveDir = Character->GetVelocity().GetSafeNormal();
	if ((CharacterMoveDir | Impact.Normal) < 0)
	{
		UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
		
		if (ActionComp)
		{
			FP3CommandRequestParams CommandParams;
			CommandParams.SetPushing_bNewPushing = true;
			CommandParams.SetPushing_PushingTargetActor = TargetActor;

			Character->GetCommandComponent()->RequestCommand(UP3SetPushingCommand::StaticClass(), CommandParams);
		}

		LastPushableImpact = Impact;
		LastPushableImpactTime = GetWorld()->GetTimeSeconds();
	}
}

bool UP3PushComponent::ApplyImpactPhysicsForces(const FHitResult& Impact, const FVector& ImpactAcceleration, const FVector& ImpactVelocity, float MaxSpeed)
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return false;
	}

	if (Character->GetStance() == EP3CharacterStance::Pickup)
	{
		AActor* TargetActor = Impact.Actor.Get();
		if (TargetActor && TargetActor->FindComponentByClass<UP3PushableComponent>())
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	UP3StaminaPointComponent* StaminaComponent = Character->GetStaminaComponent();
	if (StaminaComponent && StaminaComponent->GetStaminaPoint() <= 0)
	{
		return true;
	}

	if (Character->GetStance() == EP3CharacterStance::Push 
		&& CurrentTargetActor == Impact.Actor.Get())
	{
		if (UPrimitiveComponent* ImpactComponent = Impact.GetComponent())
		{
			FBodyInstance* BI = ImpactComponent->GetBodyInstance(Impact.BoneName);
			if (BI != nullptr && BI->IsInstanceSimulatingPhysics())
			{
				const float PushSpeed = GetPushMovementSpeed(Impact.GetActor());
				const float BodyMass = FMath::Max(BI->GetBodyMass(), 1.0f);

				const FVector CurrentVelocity = ImpactComponent->GetPhysicsLinearVelocityAtPoint(Impact.ImpactPoint);
				const FVector TargetVelocity = ImpactAcceleration.IsZero() ? ImpactVelocity.GetSafeNormal() * PushSpeed : ImpactAcceleration.GetSafeNormal() * PushSpeed;
				const FVector TargetDirection = TargetVelocity.GetSafeNormal();
				const float TargetSpeed = TargetVelocity.Size();
				const float CurrentSpeed = TargetDirection | CurrentVelocity;
				const float SpeedDiff = TargetSpeed - CurrentSpeed;
				const float VelocityRatio = FMath::Clamp(1.0f - (CurrentSpeed / FMath::Max(0.01f, TargetSpeed)), 0.0f, 1.0f);

				const float ImpulseSpeed = SpeedDiff * 0.5f;

				if (ImpulseSpeed > 0)
				{
					// TODO: limit max impulse
					const float ImpulseStrength = ImpulseSpeed * BodyMass;

					const FVector Impulse = LastPushableImpact.ImpactNormal * -1.0f * ImpulseStrength;

					if (CVarP3PushDebug.GetValueOnGameThread() != 0)
					{
						Character->AddDebugString(
							FString::Printf(TEXT("[Push] Impulse(%6.2f kg-m/s, %4.2f m/s), Speed(Curr %4.2f : Target %4.2f : Diff %4.2f m/s), Mass(%5.2f)"), 
							ImpulseStrength, ImpulseSpeed,
							CurrentSpeed, TargetSpeed, SpeedDiff, BodyMass));
					}

					UP3PushableComponent* PushableComp = CurrentTargetActor ? CurrentTargetActor->FindComponentByClass<UP3PushableComponent>() : nullptr;
					
					if (PushableComp && PushableComp->IsLockPushDirection())
					{
						ImpactComponent->AddImpulse(Impulse, Impact.BoneName);
					}
					else
					{
						ImpactComponent->AddImpulseAtLocation(Impulse, Impact.ImpactPoint, Impact.BoneName);
					}
				}

				return true;
			}
		}
	}
	else
	{
		// Not in push stance
		AActor* TargetActor = Impact.Actor.Get();
		UP3PushableComponent* PushableComp = TargetActor ? TargetActor->FindComponentByClass<UP3PushableComponent>() : nullptr;

		if (PushableComp)
		{
			// Do not apply impulse to pushable if we are not in push stance
			return true;
		}
	}

	return false;
}

bool UP3PushComponent::IsRotateChracterTowardPushDirectionEnabled() const
{
	return (CVarP3PushLockRotation.GetValueOnGameThread() == 1);
}

FVector UP3PushComponent::GetPushDirection() const
{
	if (!LastPushableImpact.GetActor())
	{
		return FVector::ZeroVector;
	}

	//LastPushableImpact.GetActor()->GetActorTransform().TransformPosition()

	return -LastPushableImpact.Normal;
}

float UP3PushComponent::GetPushMovementSpeed(const AActor* TargetActor) const
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return 0.0f;
	}

	if (!ensure(Character->GetCharacterMovement()))
	{
		return 0.0f;
	}

	const float MaxSpeed = Character->GetCharacterMovement()->MaxWalkSpeed;

	return MaxSpeed * 0.1f;
}
