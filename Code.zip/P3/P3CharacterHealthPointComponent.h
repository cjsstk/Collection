// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3HealthPointComponent.h"
#include "P3CharacterHealthPointComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3HealthPointCompOnDownedChanged, bool, bDowned);

UCLASS()
class P3_API UP3CharacterHealthPointComponent : public UP3HealthPointComponent
{
	GENERATED_BODY()

public:
	UP3CharacterHealthPointComponent();

	virtual void NetSerialize(FArchive& Archive) override;

	UFUNCTION(BlueprintCallable)
	bool IsDowned() const { return Net_bDowned; }

	bool Server_CanBeAppliedDamage() const;

	bool CanBeRescued() const;

	UFUNCTION(BlueprintCallable)
	int32 GetDownedHealthPoint() const { return Net_DownedHealthPoint; }

	UFUNCTION(BlueprintCallable)
	int32 GetMaxDownedHealthPoint() const { return Net_MaxDownedHealthPoint; }

	UFUNCTION(BlueprintCallable)
	int32 GetDownedHealthPointPermil() const { return DownedHealthPointPermil; }

	float GetRescueTickSeconds() const { return RescueTickSeconds; }
	int32 GetRescueAmountPermil() const { return RescueAmountPermil; }
	float GetRescueTickAgeSeconds() const { return Server_RescueTickAgeSeconds; }

	void DownedEndOnDead();

	void Server_SetRescueTickAgeSeconds(float InRescueTickAgeSeconds);

	void Server_ReduceDownedHealthPoint(int32 InReduceAmount);

	/** Rescue */
	void Server_RestoreDownedHealthPoint(int32 InRestoreAmount);
	void Server_SetUnderRescue(const bool InbUnderRescue);
	void Server_Rescued();
	int32 Server_TickRescue(float DeltaSeconds, UP3CharacterHealthPointComponent* TargetHealthComp);

	FP3HealthPointCompOnDownedChanged OnDownedChanged;

protected:
	virtual void BeginPlay() override;
	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	virtual void OnMaxHealthPointChanged() override;
	virtual void OnHealthPointChanged(int32 PrevHealthPoint, int32 CurrentHealthPoint) override;
	virtual bool IsDeadInternal() const override;
	virtual void Server_OnDeadInternal();

private:
	/** 
	 * Downed
	 */
	void Server_SetDowned(bool InDowned);
	void Server_TickDowned(float DeltaTime);
	void Server_StartDowned();
	void Server_TickDownedDamage();
	void Server_SetDownedHealthPoint(int32 InHealthPoint);
	void Server_TickNotApplyDamage(float DeltaTime);

	/** If set 1000, downed health point will be 100% of base health point */
	UPROPERTY(EditDefaultsOnly)
	int32 DownedHealthPointPermil = 1000;

	/** If downed, character will take damage on each tick times */
	UPROPERTY(EditDefaultsOnly)
	int32 DownedDamageTickSeconds = 1.0f;

	/** If downed and not being carried, character will take this amount of damage on each tick */
	UPROPERTY(EditDefaultsOnly)
	int32 DownedTickDamage = 20;

	/** If downed and being carried, character will take this amount of damage on each tick */
	UPROPERTY(EditDefaultsOnly)
	int32 DownedTickDamageDuringCarrying = 2;

	float Server_DownedDamageTickAgeSeconds = 0.0f;

	int32 Net_MaxDownedHealthPoint = 0;
	int32 Net_DownedHealthPoint = 0;

	bool Net_bDowned = false;

	/** 
	 * Rescue
	 */
	void Server_TickRemoveRescuedPenalty(float DeltaTime);

	int32 Server_RescuedNum = 0;

	UPROPERTY(EditDefaultsOnly)
	float RescuedPenaltyDuration = 30.0f;

	 /** If Rescue, character will restore DownedHealthPoint of targetCharacter on each tick times */
	UPROPERTY(EditDefaultsOnly)
	float RescueTickSeconds = 0.1f;

	/** If Rescue, character will restore this amount of DownedHealthPoint of targetCharacter */
	UPROPERTY(EditDefaultsOnly)
	int32 RescueAmountPermil = 10;

	float Server_CurrentRescuedPenaltyAgeSeconds = 0.0f;
	float Server_RescueTickAgeSeconds = 0.0f;
	float Server_NotApplyDamageOnDownedTickSeconds = 0.0f;
	bool Net_bUnderRescue = false;
};
