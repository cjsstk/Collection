// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "P3ServerPlayerController.generated.h"

/**
 * Server Player Controller
 *	this is P3 version of PlayerController on Server side
 */
UCLASS()
class P3_API AP3ServerPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	virtual bool IsLocalController() const override;
	virtual bool NotifyServerReceivedClientData(APawn* InPawn, float TimeStamp) override;

	void HandleGMCommand(const TArray<FString>& Args) const;

private:
	void HandleGMCommandSpawnWeapon(const TArray<FString>& Args) const;
	void HandleGMCommandTOD(const TArray<FString>& Args) const;
	void HandleGMCommandSetHealth(const TArray<FString>& Args) const;
	void HandleGMCommandGetItemPackage(const TArray<FString>& Args) const;
	void HandleGMCommandKillNPC(const TArray<FString>& Args) const;
};
