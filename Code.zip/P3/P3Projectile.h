// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3WeaponType.h"
#include "Network/Lib/P3NetCore.h"
#include "P3Projectile.generated.h"


USTRUCT()
struct FNetProjectileHit
{
	GENERATED_BODY()

	UPROPERTY()
	int64 TargetActorId = INVALID_ACTORID;

	UPROPERTY()
	FVector HitLocation = FVector::ZeroVector;

	UPROPERTY()
	FVector HitNormal = FVector::ZeroVector;

	UPROPERTY()
	FName BoneName = NAME_None;
};

USTRUCT()
struct FNetHarpoonHit
{
	GENERATED_BODY()

	UPROPERTY()
	bool bHit = false;

	UPROPERTY()
	FVector HitLocation;

	/** Optional. Only used with simulated target actor */
	UPROPERTY()
	int64 TargetActorId; 
	
	/** Optional */
	UPROPERTY()
	FString ComponentName;
};

UCLASS()
class AP3Projectile : public AP3Actor
{
	GENERATED_BODY()

public:
	AP3Projectile();

	/** Set source character who fire this projectile */
	void Server_SetSourceCharacter(class AP3Character* InSourceCharacter);

	/** Set weapon actor which fire this projectile */
	void Server_SetWeaponActor(AActor* InWeaponActor);

	FORCEINLINE class UProjectileMovementComponent* GetProjectileMovement() const { return ProjectileMovement; }

	bool IsRotating() const { return bIsRotating; }
	bool IsHarpoon() const { return bIsHarpoon; }
	float GetDamageMultiplier() const { return DamageMultiplier; }
	float GetHitImpulseMass() const { return HitImpulseMass; }
	TSubclassOf<AP3Projectile> GetBuffProjectileClass(int32 BuffKey) const;
	const TMap<int32, TSubclassOf<AP3Projectile>>& GetBuffProjectileClasses() const { return BuffProjectileClasses; }

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void BeginDestroy() override;
	virtual void NotifyHit(class UPrimitiveComponent* MyComp, AActor* Other, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit) override;

	/** Net */
	virtual void NetSerialize(FArchive& Archive) override;

	/** Packet handlers */
	UFUNCTION()
	void Client_HandleHit(const FP3DediToClientHandlerParams& Params);

	/** Blueprint events */
	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveProjectileHit(AActor* OtherActor);

private:
	void Server_OnHit(class UPrimitiveComponent* MyComp, AActor* OtherAtor, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit);
	void Client_OnHit(int64 TargetActorId, const FVector& HitLocation, const FVector& HitNormal, const FName& BoneName);

	void ProcessHarpoonHit(const FHitResult& Hit);
	void ProcessProjectileHit(int64 TargetActorId, const FVector& HitLocation, const FVector& HitNormal, const FName& BoneName);

	UFUNCTION()
	void Server_OnAttachedActorDestroyed(AActor* DestroyedActor);

	/** Harpoon projectile makes Cable attached between projectile and weapon */
	UPROPERTY(EditAnywhere, Category = Gun)
	bool bIsHarpoon = false;

	/** If set true, the projectile rotate along the rotator(RotatingAnglePerSecond)*/
	UPROPERTY(EditAnywhere, Category = Projectile)
	bool bIsRotating = false;

	/** The projectile rotate along this rotator(X = Roll, Y = Pitch, Z = Yaw)*/
	UPROPERTY(EditAnywhere, Category=Projectile, meta=(EditCondition="bIsRotating"))
	FRotator RotatingAnglePerSecond = FRotator(0.0f, 0.0f, 0.0f);

	/** Hitcms name to use */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	FName CmsCombatHitKey = NAME_None;

	/** Destroy projectile on hit */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	bool bDestroyOnHit = true;

	/** Multiply to final damage  */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	float DamageMultiplier = 1.0f;

	/** For area damage (0: no area damage)  */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	float AreaDamageRadius = 0.0f;

	/** Actual impulse by hit will be HitImpulseMass * Velocity  */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	float HitImpulseMass = 1.0f;

	/** For arrow afterimage lifetime */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	float HitSpawnActorLifeSpan = 0;

	/** Trail particle */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	class UParticleSystem* TrailParticle;

	/** Trail particle Transform*/
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	FTransform TrailParticleTransform;

	/** (Do not use. Got to go) Trail */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	bool bEnabledTrail = true;

	/** Launch sound */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	class USoundBase* LaunchSound;

	/** Hit particle */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	class UParticleSystem* HitParticle;

	/** Attach particle to bone */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	class UParticleSystem* HitAttachedParticle;

	/** Hit sound */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	class USoundBase* HitSound;

	/** Sphere collision component */
	UPROPERTY(VisibleDefaultsOnly, Category = Projectile)
	class USphereComponent* CollisionComp;

	/** [Optional] Buff Key to projectile table. If character has buff, projectile can be changed to something else */
	UPROPERTY(EditDefaultsOnly, Category = Projectile)
	TMap<int32, TSubclassOf<AP3Projectile>> BuffProjectileClasses;

	/** Projectile movement component */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Movement, meta = (AllowPrivateAccess = "true"))
	class UProjectileMovementComponent* ProjectileMovement;

	/** Trail particle component */
	UPROPERTY(Transient)
	class UParticleSystemComponent* TrailParticleComponent;

	/** Character who fire this projectile */
	UPROPERTY()
	class AP3Character* Server_SourceCharacter;

	/** Weapon which fire this projectile */
	UPROPERTY(Transient, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	AActor* Net_WeaponActor;

	FNetHarpoonHit Net_HarpoonHit;
};
