// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3InteractableComponent.h"

#include "Action/P3PawnActionComponent.h"
#include "Network/P3WorldNet.h"
#include "P3Backpack.h"
#include "P3Character.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3HealthPointComponent.h"
#include "P3HolderComponent.h"
#include "P3InventoryComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3ServerWorld.h"
#include "P3World.h"
#include "P3QuestComponent.h"

UP3InteractableComponent::UP3InteractableComponent()
{

}

void UP3InteractableComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_SetInteractionAllowed(bAutoAllowInteractionOnBegin);
	}
}

void UP3InteractableComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

bool UP3InteractableComponent::Server_OnInteract(class AActor* Interactor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (!IsInteractionAllowed())
	{
		return false;
	}

	if (!Server_OnInteractInternal(Interactor))
	{
		return false;
	}

	Server_OnInteracted.Broadcast(Interactor);

	Server_CurrentInteractNum++;
	if (MaxInteractionCount != -1 && Server_CurrentInteractNum >= MaxInteractionCount)
	{
		Server_SetInteractionAllowed(false);
		if (GetOwner() && bAutoDestoryActorOnMaxInteraction)
		{
			GetOwner()->Destroy();
		}
	}

	if (!Net_bInteractionSuccessed)
	{
		Net_bInteractionSuccessed = true;
		Server_SetDirty(*this);
	}

	return true;
}

void UP3InteractableComponent::Server_SetInteractionAllowed(bool bNewAllowed)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (Net_bInteractionAllowed == bNewAllowed)
	{
		return;
	}

	Net_bInteractionAllowed = bNewAllowed;

	Server_SetDirty(*this);
}

bool UP3InteractableComponent::IsInteractionAllowed() const
{
	UP3HealthPointComponent* HealthPointComp = GetOwner()->FindComponentByClass<UP3HealthPointComponent>();
	if (HealthPointComp && HealthPointComp->IsDead())
	{
		return bAllowInteractionOnOwnerDead;
	}

	return Net_bInteractionAllowed;
}

void UP3InteractableComponent::NetSerialize(FArchive& Archive)
{
	Archive << Net_bInteractionAllowed;
	Archive << Net_bInteractionSuccessed;

	if (Net_bInteractionSuccessed && P3Core::IsP3NetModeClientInstance(*this))
	{
		Client_OnInteractSuccessed();
	}
}

void UP3InteractableComponent::Client_OnInteractSuccessed()
{
	if (!P3Core::IsP3NetModeClientInstance(*this))
	{
		return;
	}

	Client_OnInteractionSuccessed.Broadcast();
}

UP3LootingInteractableComponent::UP3LootingInteractableComponent()
{

}

bool UP3LootingInteractableComponent::Server_OnInteractInternal(class AActor* Interactor)
{
	if (!Super::Server_OnInteractInternal(Interactor))
	{
		return false;
	}

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	UP3World* World = P3Core::GetP3World(*this);
	if (!World)
	{
		return false;
	}

	UP3ServerWorld* ServerWorld = World->GetServerWorld();
	if (!ServerWorld)
	{
		return false;
	}

	AP3Character* InteractorCharacter = Cast<AP3Character>(Interactor);
	if (!InteractorCharacter)
	{
		return false;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(Interactor);
	if (!ensure(WorldNet))
	{
		return false;
	}

	UP3InventoryComponent* InvenComp = InteractorCharacter->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		return false;
	}

	if (!Net_LootItemActor)
	{
		FText FailText;
		switch (LootingInteractableType)
		{
		case EP3LootingInteractableType::Collect:
			FailText = P3LOC_ITEM("FailedToCollect");
			break;
		case EP3LootingInteractableType::Extract:
			FailText = P3LOC_ITEM("FailedToExtract");
			break;
		case EP3LootingInteractableType::Catch:
			FailText = P3LOC_ITEM("FailedToCatch");
			break;
		case EP3LootingInteractableType::Harvest:
			FailText = P3LOC_ITEM("FailedToHarvest");
			break;
		case EP3LootingInteractableType::Mining:
			FailText = P3LOC_ITEM("FailedToMining");
			break;
		case EP3LootingInteractableType::Pluck:
			FailText = P3LOC_ITEM("FailedToPluck");
			break;
		default:
			P3JsonLog(Warning, "Invalid LootingInteractableType", TEXT("LootingInteractableType"), EnumToString(EP3LootingInteractableType, LootingInteractableType));
			break;
		}

		if (!InteractionFailText.IsEmpty())
		{
			FailText = InteractionFailText;
		}

		ServerWorld->SendToastMessage(*InteractorCharacter, FailText);
		return true;
	}

	UClass* ItemActorClass = Net_LootItemActor.GetDefaultObject()->GetClass();
	itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
	if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
	{
		P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
		return false;
	}

	const int32 Amount = 1;
	if (!InvenComp->CanAddItem(ItemCmsKey, Amount))
	{
		FText ErrorMessage = P3LOC_ITEM("CannotOwnThisItem");
		ServerWorld->SendToastMessage(*InteractorCharacter, ErrorMessage);
		return false;
	}

	InvenComp->Server_AddItemByKeyAndCount(ItemCmsKey, Amount);

	FText LootItemNameMessage = P3Cms::GetItem(ItemCmsKey).DisplayName;
	ServerWorld->SendToastMessage(*InteractorCharacter, LootItemNameMessage);

	return true;
}

bool UP3LootingInteractableComponent::IsAllowMoveOnAnimPlaying() const
{
	switch (LootingInteractableType)
	{
	case EP3LootingInteractableType::Collect:
	case EP3LootingInteractableType::Catch:
	case EP3LootingInteractableType::Extract:
	case EP3LootingInteractableType::Harvest:
	case EP3LootingInteractableType::Mining:
		return false;
	case EP3LootingInteractableType::Pluck:
		return true;
	default:
		ensure(0);
		break;
	}

	return false;
}

bool UP3LootingInteractableComponent::Server_PickLootItem()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	const FP3LootDropResultItem& LootItem = P3Loot::RollDiceAndPickOne(ItemContainer);
	Net_LootItemActor = LootItem.SpawnActor;

	Server_SetDirty(*this);

	return Net_LootItemActor ? true : false;
}

void UP3LootingInteractableComponent::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	Archive << Net_LootItemActor;
}

UP3ChangeWeaponInteractableComponent::UP3ChangeWeaponInteractableComponent()
{

}

bool UP3ChangeWeaponInteractableComponent::Server_OnInteractInternal(class AActor* Interactor)
{
	Super::Server_OnInteractInternal(Interactor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	AP3Character* InteractorCharacter = Cast<AP3Character>(Interactor);
	if (!InteractorCharacter)
	{
		return false;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(Interactor);
	if (!ensure(WorldNet))
	{
		return false;
	}

	UP3InventoryComponent* InvenComp = InteractorCharacter->GetInventoryComponentBP();
	if (!ensure(InvenComp))
	{
		return false;
	}

	UP3PawnActionComponent* ActionComp = InteractorCharacter->GetActionComponent();
	if (!ensure(ActionComp))
	{
		return false;
	}

	/** Can't change temporary weapon */
	const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(InvenComp->GetItemBySlot(EP3CharacterItemSlot::RightHand).Key);
	if (CmsHoldable && IsTempWeapon(CmsHoldable->WeaponType))
	{
		UP3World* World = P3Core::GetP3World(*this);
		if (World)
		{
			World->GetServerWorld()->SendToastMessage(*InteractorCharacter, P3LOC_ITEM("CannotChangeTemporaryWeapon"));
		}
		return false;
	}

	/** Add new weapons */
	itemkey RightItemKey = INVALID_ITEMKEY;
	itemkey LeftItemKey = INVALID_ITEMKEY;

	for (auto&& NewWeaponClass : NewWeaponActorClass)
	{
		UClass* WeaponClass = NewWeaponClass.Value.Get();
		itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(WeaponClass);
		if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
		{
			P3JsonLog(Warning, "Invalid item key", TEXT("Class"), WeaponClass ? *WeaponClass->GetName() : TEXT("null"));
			return false;
		}

		if (NewWeaponClass.Key == EP3HoldType::RightHand)
		{
			RightItemKey = ItemCmsKey;
		}
		else if (NewWeaponClass.Key == EP3HoldType::LeftHand)
		{
			LeftItemKey = ItemCmsKey;
		}

		InvenComp->Server_AddItemByKeyAndCount(ItemCmsKey, 1);
	}

	/** Change weapons */
	UP3HolderComponent* RightHandHolderComp = nullptr;
	UP3HolderComponent* LeftHandHolderComp = nullptr;

	TInlineComponentArray<UP3HolderComponent*> HolderComps;
	InteractorCharacter->GetComponents(HolderComps);

	for (UP3HolderComponent* HolderComp : HolderComps)
	{
		if (HolderComp->GetHoldType() == EP3HoldType::RightHand)
		{
			RightHandHolderComp = HolderComp;
		}
		else if(HolderComp->GetHoldType() == EP3HoldType::LeftHand)
		{
			LeftHandHolderComp = HolderComp;
		}
	}

	FP3PawnActionStartRequestParams Params;

	const FP3Item NewRightHandWeaponItem = InvenComp->GetItemByKey(RightItemKey);
	if (RightHandHolderComp && NewRightHandWeaponItem.Id != INVALID_ITEMID)
	{
		Params.ChangeHoldable_RightHoldType = RightHandHolderComp->GetHoldType();
		Params.ChangeHoldable_InvenToRightHolderItemId = NewRightHandWeaponItem.Id;
		Params.ChangeHoldable_HolderToRightInvenItem = InvenComp->GetItemBySlot(EP3CharacterItemSlot::RightHand);
	}

	const FP3Item NewLeftHandWeaponItem = InvenComp->GetItemByKey(LeftItemKey);
	if (LeftHandHolderComp)
	{
		Params.ChangeHoldable_LeftHoldType = LeftHandHolderComp->GetHoldType();
		Params.ChangeHoldable_InvenToLeftHolderItemId = NewLeftHandWeaponItem.Id;
		Params.ChangeHoldable_HolderToLeftInvenItem = InvenComp->GetItemBySlot(EP3CharacterItemSlot::LeftHand);
	}

	if (Params.ChangeHoldable_InvenToRightHolderItemId != INVALID_ITEMID)
	{
		Params.ChangeHoldable_bRemovePrevWeaponAfterChange = true;
		ActionComp->StartAction(EPawnActionType::ChangeHoldable, _FUNCTION_TEXT, Params);
	}

	return true;
}

UP3TalkableComponent::UP3TalkableComponent()
{
	bAutoAllowInteractionOnBegin = true;
	bAllowInteractionOnOwnerDead = false;
	bAutoDestoryActorOnMaxInteraction = false;
	InteractableType = EP3InteractableType::Talk;
	bPlayInteractAnimation = false;
}

bool UP3TalkableComponent::Server_OnInteractInternal(class AActor* Interactor)
{
	Super::Server_OnInteractInternal(Interactor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	AP3Character* InteractorCharacter = Cast<AP3Character>(Interactor);
	if (!InteractorCharacter)
	{
		return false;
	}

	UP3QuestComponent* QuestComp = InteractorCharacter->GetQuestComponent();
	if (!ensure(QuestComp))
	{
		return false;
	}

	return QuestComp->Server_ManuallyProceed();
}

bool UP3ClothChangerComponent::Server_OnInteractInternal(class AActor* Interactor)
{
	Super::Server_OnInteractInternal(Interactor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(Interactor);

	if (!Character)
	{
		return false;
	}

	const UDataTable* ArmorTable = P3Cms::GetCharacterArmorTable();

	if (ArmorTable)
	{
		const TArray<FName> ArmorNames = ArmorTable->GetRowNames();

		if (ArmorNames.Num() > 0)
		{
			int32 Index = ArmorNames.Find(Character->GetCharacterStoreBP().ArmorName);

			if (Index == INDEX_NONE)
			{
				Index = 0;
			}

			Index = (Index + 1) % ArmorNames.Num();

			const FName NewArmorName = ArmorNames[Index];

			Character->Server_SetArmor(NewArmorName);
		}
	}

	return true;
}

bool UP3HairChangerComponent::Server_OnInteractInternal(class AActor* Interactor)
{
	Super::Server_OnInteractInternal(Interactor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(Interactor);

	if (!Character)
	{
		return false;
	}

	const UDataTable* HairTable = P3Cms::GetCharacterHairTable();

	if (HairTable)
	{
		const TArray<FName> HairNames = HairTable->GetRowNames();

		if (HairNames.Num() > 0)
		{
			int32 Index = HairNames.Find(Character->GetCharacterStoreBP().HairName);

			if (Index == INDEX_NONE)
			{
				Index = 0;
			}

			Index = (Index + 1) % HairNames.Num();

			const FName NewHairName = HairNames[Index];

			Character->Server_SetHair(NewHairName);
		}
	}

	return true;
}

bool UP3BackpackInteractableComponent::Server_OnInteractInternal(class AActor* Interactor)
{
	Super::Server_OnInteractInternal(Interactor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(Interactor);
	if (!Character)
	{
		return false;
	}

	if (Character->IsCarryingBackpack())
	{
		return false;
	}

	UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
	if (!ActionComp)
	{
		return false;
	}

	AP3Backpack* BackpackActor = GetWorld()->SpawnActor<AP3Backpack>(BackpackActorClass, Character->GetActorLocation(), Character->GetActorRotation(), FActorSpawnParameters());
	if (!BackpackActor)
	{
		return false;
	}

	FP3PawnActionStartRequestParams ActionParams;
	ActionParams.PickupBackpack_BackpackActor = Cast<AActor>(BackpackActor);
	ActionParams.PickupBackpack_AttachSocketName = FName("Backpack");

	ActionComp->StartAction(EPawnActionType::PickupBackpack, _FUNCTION_TEXT, ActionParams);

	return true;
}
