// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "GameFramework/Actor.h"

#include "P3Character.h"
#include "P3Core.h"
#include "P3ThreatListComponent.generated.h"


USTRUCT()
struct FP3ThreatActor
{
	GENERATED_BODY()

	UPROPERTY()
	AActor* Actor;

	UPROPERTY()
	float ThreatPoint = 0.0f;
};


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3ThreatListComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UP3ThreatListComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

protected:
	virtual void BeginPlay() override;

private:
	void Server_Tick(float DeltaSeconds);

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float IncreaseThreatPointPerSecond = 0.0f;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float DecreaseThreatPointPerSecond = 1.0f;

	UPROPERTY()
	TArray<FP3ThreatActor> ThreatList;

	float MaxThreatPoint = 100.0f;
};
