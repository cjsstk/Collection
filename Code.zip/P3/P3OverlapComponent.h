// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/SceneComponent.h"
#include "P3CharacterEffectTypes.h"
#include "P3OverlapComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnOverlappedActorAdded, AActor*, OverlappedActor);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnOverlappedActorRemoved, AActor*, OverlappedActor);

/**
 * Overlap Component
 * handles overlapping actors
 * needs to be activated
 * has option to check only from child components (oppose to all actor components)
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3OverlapComponent : public USceneComponent
{
	GENERATED_BODY()

public:	
	UP3OverlapComponent();

	virtual void Activate(bool bReset = false) override;
	virtual void Deactivate() override;

	UFUNCTION(BlueprintCallable)
	const TSet<AActor*>& Server_GetOverlappedActors() const { return Server_OverlappedActors; }

	UPROPERTY(BlueprintAssignable)
	FP3OnOverlappedActorAdded Server_OnOverlappedActorAdded;

	UPROPERTY(BlueprintAssignable)
	FP3OnOverlappedActorRemoved Server_OnOverlappedActorRemoved;

protected:
	virtual void BeginPlay() override;
	virtual void Server_OverlappedActorAdded(AActor& Actor) {}
	virtual void Server_OverlappedActorRemoved(AActor& Actor) {}

private:
	void Server_AddOverlappingActors();
	void Server_OnActivated();
	void Server_OnDeactivated();
	void Server_AddOverlappedActor(AActor* Actor);
	void Server_RemoveOverlappedActor(AActor* Actor);

	UFUNCTION()
	void Server_OnActorBeginOverlap(AActor* OverlappedActor, AActor* OtherActor);

	UFUNCTION()
	void Server_OnActorEndOverlap(AActor* OverlappedActor, AActor* OtherActor);

	UFUNCTION()
	void Server_OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void Server_OnComponentEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

	/** If false, overlap handling will be disabled */
	UPROPERTY(EditDefaultsOnly, Category = Overlap)
	bool bEnableOverlap = true;

	/** If true, only overlap event from this component's child is valid */
	UPROPERTY(EditDefaultsOnly, Category = Overlap)
	bool bChildComponentOverlapOnly = false;

	/** Ignore overlap result of components in this list*/
	UPROPERTY(EditDefaultsOnly, Category = Overlap, meta = (EditCondition="bChildComponentOverlapOnly"))
	TArray<UClass*> IgnoreComponentClasses;

	UPROPERTY(Transient)
	TSet<AActor*> Server_OverlappedActors;
};
