// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Perception/AIPerceptionComponent.h"
#include "P3AIPerceptionComponent.generated.h"

/**
 * 
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3AIPerceptionComponent : public UAIPerceptionComponent
{
	GENERATED_BODY()

};
