// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3BuffTriggerComponent.h"

#include "P3Character.h"
#include "P3CharacterEffectComponent.h"

void UP3BuffTriggerComponent::Server_OverlappedActorAdded(AActor& Actor)
{
	Super::Server_OverlappedActorAdded(Actor);

	if (bOnlyInstigator && GetOwner() && &Actor != GetOwner()->Instigator)
	{
		return;
	}

	if (TriggerFactions.Num() > 0)
	{
		AP3Character* Character = Cast<AP3Character>(&Actor);
		if (Character)
		{
			EP3Faction Faction = Character->GetFaction();
			if (!TriggerFactions.Contains(Faction))
			{
				return;
			}
		}
	}

	UP3CharacterEffectComponent* EffectComp = Actor.FindComponentByClass<UP3CharacterEffectComponent>();
	if (EffectComp)
	{
		EffectComp->Server_AddBuff(CmsBuffKey, this);
	}
}