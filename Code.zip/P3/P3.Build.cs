// Copyright 2018 XLGames, Inc. All Rights Reserved.

using UnrealBuildTool;

public class P3 : ModuleRules
{
	public P3(ReadOnlyTargetRules Target) : base(Target)
	{
        //bFasterWithoutUnity = true;

        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
        
        PublicDependencyModuleNames.AddRange(new string[] {
            "Core",
            "CoreUObject",
            "Engine",
            "Foliage",
            "InputCore",
            "HeadMountedDisplay",
            "libprotobuf",
            "libWebSockets",
            "Sockets",
            "PacketHandler",
            "JsonUtilities",
            "ApexDestruction",
            "AIModule",
            "GameplayTasks",
            "GameplayTags",
            "UMG",
            "Slate",
            "SlateCore",
            "Http",
            "Json",
            "NavigationSystem",
            "Landscape",
            "MovieScene",
            "LevelSequence",
            "OnlineSubsystemUtils",
            "zlib",
            "PerfCounters",
            "CableComponent",
            "PhysX",
            "PhysicsCore",
            "APEX",
            "AnimGraphRuntime",
            "AnimationCore",
        });

        if (Target.bBuildEditor == true)
        {
            PublicDependencyModuleNames.AddRange(new string[] {
                "NetcodeUnitTest",
                "UnrealEd",
                "AssetRegistry"
            });
        }
    }
}
