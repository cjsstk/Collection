// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3RagdollComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/CapsuleComponent.h"

UP3RagdollComponent::UP3RagdollComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	PrimaryComponentTick.SetTickFunctionEnable(false);
}

void UP3RagdollComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	if (bRagollized)
	{
		TickMoveCapsuleDuringRagdoll();
	}

	if (bUnragollizing)
	{
		TickUnragdollizing(DeltaTime);
	}
}

void UP3RagdollComponent::Ragdollize()
{
	ACharacter* Character = GetOwnerCharacter();

	if (!Character || !Character->GetMesh())
	{
		ensure(0);
		return;
	}

	if (bRagollized)
	{
		return;
	}

	bRagollized = true;

	// If we were already on unragdollizing, RagdollMeshTransform is already set and Mesh transform is interpolated value which should not be used
	if (!bUnragollizing)
	{
		RagdollMeshTransform = Character->GetMesh()->GetRelativeTransform();
	}
	bUnragollizing = false;

	//GetCharacterMovement()->ApplyAccumulatedForces(0.0f);

	Character->GetMesh()->SetCollisionProfileName(TEXT("Ragdoll"));
	//Character->GetMesh()->SetAllBodiesBelowSimulatePhysics(FName(TEXT("Bip01-Pelvis")), true, false);
	//Character->GetMesh()->SetAllBodiesBelowSimulatePhysics(FName(TEXT("ROOT")), true, false);
	Character->GetMesh()->SetAllBodiesSimulatePhysics(true);
	Character->GetMesh()->SetAllBodiesPhysicsBlendWeight(1.0f);
	//Character->GetMesh()->SetPhysicsLinearVelocity(GetCharacterMovement()->Velocity);

	Character->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::QueryOnly);

	PrimaryComponentTick.SetTickFunctionEnable(true);
}

void UP3RagdollComponent::Unragdollize()
{
	ACharacter* Character = GetOwnerCharacter();

	if (!Character || !Character->GetMesh())
	{
		ensure(0);
		return;
	}

	if (!bRagollized)
	{
		return;
	}

	bRagollized = false;

	Character->GetMesh()->SetCollisionProfileName(TEXT("CharacterMesh"));
	Character->GetMesh()->SetAllBodiesSimulatePhysics(false);
	Character->GetMesh()->AttachToComponent(Character->GetCapsuleComponent(), FAttachmentTransformRules::KeepWorldTransform);

	Character->GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);

	Character->GetCharacterMovement()->SetMovementMode(MOVE_Falling);

	bUnragollizing = true;
	UnragdollizeAge = 0;
	UnragdollizeStartTransform = Character->GetMesh()->GetRelativeTransform();
}

void UP3RagdollComponent::TickMoveCapsuleDuringRagdoll()
{
	ensure(bRagollized);

	ACharacter* Character = GetOwnerCharacter();

	if (!Character || !Character->GetMesh())
	{
		ensure(0);
		return;
	}

	const FTransform NewTransform = Character->GetMesh()->GetComponentToWorld();

	Character->GetCapsuleComponent()->SetWorldLocation(NewTransform.GetLocation() - RagdollMeshTransform.GetLocation());
}

void UP3RagdollComponent::TickUnragdollizing(float DeltaSeconds)
{
	ensure(bUnragollizing);

	ACharacter* Character = GetOwnerCharacter();

	if (!Character || !Character->GetMesh())
	{
		ensure(0);
		return;
	}

	UnragdollizeAge += DeltaSeconds;

	const float Alpha = FMath::Clamp(UnragdollizeAge, 0.0f, 1.0f);

	FTransform NewTransform;
	NewTransform.Blend(UnragdollizeStartTransform, RagdollMeshTransform, Alpha);

	Character->GetMesh()->SetRelativeTransform(NewTransform);
	Character->GetMesh()->SetAllBodiesPhysicsBlendWeight(1.0f - Alpha);

	if (Alpha >= 1.0f)
	{
		bUnragollizing = false;

		PrimaryComponentTick.SetTickFunctionEnable(false);
	}
}

class ACharacter* UP3RagdollComponent::GetOwnerCharacter() const
{
	ACharacter* Character = Cast<ACharacter>(GetOwner());

	return Character;
}
