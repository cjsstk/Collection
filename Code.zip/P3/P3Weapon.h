// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameFramework/ProjectileMovementComponent.h"

#include "P3Actor.h"
#include "P3Cms.h"

#include "P3Weapon.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3WeaponRecallFinished, class AP3Weapon*, Weapon);

UCLASS()
class P3_API AP3Weapon : public AP3Actor
{
	GENERATED_BODY()
	
public:	
	AP3Weapon();

	virtual void Tick(float DeltaTime) override;

	void Server_Throw(const FVector& ThrowDirection, class AActor* SourceActor);
	void Server_ThrowPhysically(const FVector& ThrowDirection, class AActor* SourceActor);
	void Server_Recall(class UP3HolderComponent* HolderComponent);
	void StopRecall();

	void Server_SetLastFiredProjectile(class AP3Projectile* Projectile);
	class AP3Projectile* GetLastFiredProjectile() const { return Net_LastFiredProjectile; }

	itemkey GetItemKey() const { return ItemKey; }
	const FP3CmsHoldable& GetCmsHoldable() const { return CmsHoldable; }
	class UP3HoldableComponent* GetHoldableComponent() const { return HoldableComponent; }

	bool CanBeHeldTo(EP3CharClass CharClass) const { return (HoldableClasses.Num() == 0) || HoldableClasses.Contains(CharClass); }
	const class UP3CharacterSounds* GetCharacterSounds() const { return Sounds; }
	float GetMoveSpeedMultiplayerDuringAttack() const { return MoveSpeedMultiplayerDuringAttack; }
	int32 GetNumProjectiles() const { return NumProjectiles; }
	float GetProjectileRandomConeDegree() const { return ProjectileRandomConeDegree; }
	USoundBase* GetProjectileFireSound() const { return ProjectileFireSound; }
	float GetFireRate() const { return FireRate; }
	float GetActionStamina() const { return ActionStamina; }
	EP3WeaponType GetWeaponType() const { return CmsHoldable.WeaponType; };
	bool IsContainingHoldType(EP3HoldType HoldType) const { return CmsHoldable.HoldTypes.Contains(HoldType); };
	bool IsSupportHoldable() { return CmsHoldable.IsSupportHoldable; }
	
	void IncreaseUseCountByPlayer() { ++UseCountByPlayer; }
	bool IsRunOutOfDurability() const;

	bool CanPickupCandidate() const;

	UFUNCTION(BlueprintCallable)
	bool IsPlayerUsable() { return CmsHoldable.IsPlayerUsable; }

	UFUNCTION(BlueprintCallable)
	bool IsThrownFlyingBP() const { return bIsThrowFlying; }

	UFUNCTION(BlueprintCallable)
	bool IsRecallFlyingBP() const { return bIsRecallFlying; }

	UFUNCTION(BlueprintImplementableEvent)
	void Multicast_OnFireBP();

	/** Net */
	virtual void NetSerialize(FArchive& Archive) override;

	FP3WeaponRecallFinished OnRecallFinished;

protected:
	virtual void BeginPlay() override;

private:
	void OnThrowRecallFinished();

	UFUNCTION()
	void OnThrowFlyingStopped(const struct FHitResult& ImpactResult);
		
	void UpdateDestoryDynamicMaterial(float DeltaTime);

	/* Empty array means any class can hold */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TArray<EP3CharClass> HoldableClasses;

	UPROPERTY(EditAnywhere, Category = P3)
	float MoveSpeedMultiplayerDuringAttack = 1.0f;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	UP3CharacterSounds* Sounds = nullptr;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* ThrowFlyingSound;

	UPROPERTY(EditAnywhere, Category = P3)
	USoundBase* ThrowLandSound;

	UPROPERTY(EditAnywhere, Category = P3)
	TSubclassOf<class UCameraShake> ThrowRecallCameraShake;

	UPROPERTY(EditAnywhere, Category = P3)
	float ThrowRecallCameraShakeInnerRadius = 100.0f;

	UPROPERTY(EditAnywhere, Category = P3)
	float ThrowRecallCameraShakeOuterRadius = 1000.0f;

	UPROPERTY(EditAnywhere, Category = P3)
	float ThrowSpeed = 2000.0f;

	UPROPERTY(EditAnywhere, Category = P3)
	FVector ThrowAngularVelocity = FVector(0, -1800, 0);

	/** In case of gun-type, number of projectiles for each fire */
	UPROPERTY(EditAnywhere, Category = Gun)
	int32 NumProjectiles = 1;

	/** In case of gun-type, random cone degree for each projectile */
	UPROPERTY(EditAnywhere, Category = Gun)
	float ProjectileRandomConeDegree = 0.0f;

	/** In case of gun-type, fire sound */
	UPROPERTY(EditAnywhere, Category = Gun)
	class USoundBase* ProjectileFireSound;

	/** In case of gun-type, fire animation speed multiplier */
	UPROPERTY(EditAnywhere, Category = Gun)
	float FireRate = 1.0f;

	/** Required stamina for each action (attack, fire) */
	UPROPERTY(EditAnywhere, Category = Gun)
	float ActionStamina = 0.0f;

	/** Particle that will be spawned if weapon is not owned by anyone */
	UPROPERTY(EditAnywhere, Category = Loot)
	class UParticleSystem* LootEffectParticle;

	UPROPERTY(Transient)
	class UP3HoldableComponent* HoldableComponent = nullptr;

	UPROPERTY(Transient)
	class UP3WeaponThrowMovementComponent* ThrowMovementComponent = nullptr;

	UPROPERTY(Transient)
	class UAudioComponent* ThrowFlyingAudioComponent = nullptr;

	UPROPERTY(Transient)
	class UP3HolderComponent* RecallHolderComponent = nullptr;

	UPROPERTY(Transient)
	class UParticleSystemComponent* LootEffectParticleComponent = nullptr;

	UPROPERTY(Transient)
	class AP3Projectile* Net_LastFiredProjectile = nullptr;

	UPROPERTY(Transient)
	class UMaterialInstanceDynamic* DestroyMaterial = nullptr;

	itemkey ItemKey = INVALID_ITEMKEY;
	FP3CmsHoldable CmsHoldable;

	bool bIsThrowFlying = false;
	bool bIsRecallFlying = false;
	float RecallAgeSeconds = 0;
	float RecallDuration = 1.0f;

	FVector RecallStartLocation = FVector::ZeroVector;

	int32 UseCountByPlayer = 0;
	float DestoryTimeSeconds = 0.f;	
};

UCLASS()
class P3_API UP3WeaponThrowMovementComponent : public UProjectileMovementComponent
{
	GENERATED_BODY()

public:
	void SetIgnoreHitActors(const TArray<AActor*>& InIgnoreHitActors) { IgnoreHitActors = InIgnoreHitActors; }

private:
	virtual void HandleImpact(const FHitResult& Hit, float TimeSlice = 0.f, const FVector& MoveDelta = FVector::ZeroVector) override;
	virtual bool HandleDeflection(FHitResult& Hit, const FVector& OldVelocity, const uint32 NumBounces, float& SubTickTimeRemaining) override;

	UPROPERTY(Transient)
	TArray<AActor*> IgnoreHitActors;
};
