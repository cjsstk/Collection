// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"

#include "AI/P3Route.h"
#include "P3TripType.h"
#include "P3SpawnerActor.generated.h"

UCLASS(ConversionRoot, ComponentWrapperClass)
class AP3PawnSpawnerActor : public AActor
{
	GENERATED_BODY()

public:
	AP3PawnSpawnerActor();

#if UE_EDITOR
	virtual void PostLoad() override;
#endif
	virtual void BeginPlay() override;
	virtual void Reset() override;

	UFUNCTION(CallInEditor, Category = P3)
	void ConvertSpawnerActorToTargetActor();

	UFUNCTION(BlueprintCallable)
	UP3SpawnerComponent* GetSpawnerComponent() const { return SpawnerComponent; }

protected:
	void AddPointOfInterest(class AP3PointOfInterest* POI);
	void ClearPointOfInterests();
	
private:
	void OnSpawnerValueChanged(UObject* Object, FPropertyChangedEvent& PropertyChangedEvent);

	UFUNCTION()
	void OnSpawn(class UP3SpawnerComponent* SpawnerComponent, AActor* SpawnedActor);

	UPROPERTY()
	USceneComponent* SceneComponent;

	UPROPERTY(VisibleAnywhere)
	UP3SpawnerComponent* SpawnerComponent;
	
	UPROPERTY(Transient)
	class UDrawSphereComponent* PreviewSphereComponent;

	/** Arrow component to indicate forward direction of start */
#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
	class UBillboardComponent* EditorSprite;

	UPROPERTY()
	class UArrowComponent* ArrowComponent;
#endif

	/** Override AI Controller's behavior tree */
	UPROPERTY(EditAnywhere, Category = "Pawn Spawner")
	class UBehaviorTree* OverrideBehaviorTree;

	/** Spawned pawn will pick one random POI in this list and move towards it */
	UPROPERTY(EditAnywhere, Category = "Pawn Spawner")
	TArray<class AP3PointOfInterest*> RandomPointOfInterests;

	/** 스폰된 Pawn이 사용할 route 방식 리스트 */
	UPROPERTY(EditAnywhere, Category = "Pawn Spawner")
	TArray<FP3Route> RouteList;

	/** 스폰된 Pawn의 시작 시 Emote 사용 여부*/
	UPROPERTY(EditAnywhere, Category = "Pawn Spawner", meta = (InlineEditConditionToggle))
	bool bInitialEmote = false;

	/** 스폰된 Pawn의 시작 Emote */
	UPROPERTY(EditAnywhere, Category = "Pawn Spawner", meta = (EditCondition = "bInitialEmote"))
	FName InitialEmoteName = NAME_None;
};


UCLASS()
class P3_API AP3ReinforceSpawnerActor : public AP3PawnSpawnerActor
{
	GENERATED_BODY()
	
public:	
	AP3ReinforceSpawnerActor();

	void Server_OnHornBlown(class AP3Character* Character);

protected:
	virtual void BeginPlay() override;
};
