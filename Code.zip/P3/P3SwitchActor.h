// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3Faction.h"
#include "P3SwitchActor.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FP3OnSwitchToggle, bool, bOn);

/** 
 * Switch actor
 */
UCLASS(Blueprintable)
class P3_API AP3SwitchActor : public AP3Actor
{
	GENERATED_BODY()
	
public:	
	AP3SwitchActor();

	virtual void Tick(float DeltaTime) override;
	virtual float TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser) override;
	virtual void Reset() override;

	/** AP3Actor */
	virtual void NetSerialize(FArchive& Archive) override;

	UFUNCTION(BlueprintCallable)
	bool IsSwitchOnBP() const { return IsSwitchOn(); }
	bool IsSwitchOn() const { return bOn; }
	
	UFUNCTION(BlueprintCallable)
	void ToggleSwitchBP(bool bInOn);
	void Server_ToggleSwitch(bool bInOn);
	
	UFUNCTION(BlueprintCallable)
	void Server_SetSignalReceiever(class AP3SignalReceiver* InSignalReceiver);

	UFUNCTION(BlueprintImplementableEvent)
	void ReceiveToggleSwitchBP(bool bInOn);

	UPROPERTY(BlueprintAssignable)
	FP3OnSwitchToggle OnSwitchToggleBP;

protected:
	virtual void BeginPlay() override;
	virtual void OnToggleSwitch(bool bInOn);

private:
	void Client_OnToggleSwitch(bool bInOn);
	void OnToggleByDamageTimer();

#if WITH_EDITORONLY_DATA
	/** Billboard used to see the switch in the editor */
	UPROPERTY()
	UBillboardComponent* SpriteComponent;
#endif

	UPROPERTY(EditAnywhere, Category = "Switch")
	bool bDefaultOn = false;

	/** If true, switch can be toggled by Damage */
	UPROPERTY(EditAnywhere, Category = "Switch")
	bool bToggleByDamage = true;

	/** If >= 0, number of toggling switch will be limited until Reset() called */
	UPROPERTY(EditAnywhere, Category = "Switch")
	int32 MaxToggleCount = -1;

	/** If > 0, switch cannot be toggled on again within this time */
	UPROPERTY(EditAnywhere, Category = "Switch")
	float ToggleOnCooldownSeconds = 0;

	UPROPERTY()
	bool bOn = false;

	UPROPERTY(EditInstanceOnly)
	class AP3SignalReceiver* SignalReceiver;

	float Server_LastToggleTime = 0.0f;
	FTimerHandle Server_ToggleByDamageTimerHandle;

	/** Total toggle count */
	int32 Server_NumToggled = 0;

	/** Switch on will be possible again after this time. Only valid when SwitchOnCooldownSeconds > 0 */
	float Server_SwitchOnCooldownFinishSeconds = 0;
};


/** 
 * Health triggered switch actor (Server only!)
 */
UCLASS(Blueprintable)
class P3_API AP3HealthTriggeredSwitchActor : public AP3SwitchActor
{
	GENERATED_BODY()

public:
	AP3HealthTriggeredSwitchActor();

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UFUNCTION()
	void OnHealthChange(class UP3HealthPointComponent* Component, int32 OldHealthPoint, int32 NewHealthPoint);

	/** Which actor do we watch for health point? */
	UPROPERTY(EditAnywhere, Category = "Health Triggered Switch")
	AActor* WatchActor;

	/** (-1 ~ 100) If health is same or below this percentage, switch is triggered. -1 means no trigger */
	UPROPERTY(EditAnywhere, Category = "Health Triggered Switch")
	float MinHealthPercent = -1.0f;
};


/** 
 * Shape Triggered Switch Actor (Server only!)
 */
UCLASS(Blueprintable, abstract, ConversionRoot)
class P3_API AP3ShapeTriggeredSwitchBaseActor : public AP3SwitchActor
{
	GENERATED_BODY()

public:
	AP3ShapeTriggeredSwitchBaseActor(const FObjectInitializer& ObjectInitializer);

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	class UShapeComponent* GetCollisionComponent() const { return CollisionComponent; }

	UFUNCTION(BlueprintImplementableEvent)
	void Server_ReceiveOverlapTriggered(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComponent);

	const TSet<AActor*>& GetTriggeredActors() const { return TriggeredActors; }

	UFUNCTION()
	void OnBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult);

	UFUNCTION()
	void OnEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

private:
	/** Shape component used for collision */
	UPROPERTY(Category = "Shape Triggered Switch", VisibleAnywhere, BlueprintReadOnly, meta = (AllowPrivateAccess = "true"))
	class UShapeComponent* CollisionComponent;

	/** If set, any character that has this faction will trigger switch */
	UPROPERTY(EditAnywhere, Category = "Shape Triggered Switch")
	TArray<EP3Faction> TriggerFactions;

	/** If set, any P3Actor/P3Character that has any of this tags will trigger switch */
	UPROPERTY(EditAnywhere, Category = "Shape Triggered Switch")
	FGameplayTagContainer TriggerGameplayTagsAny;

	/** If set, any P3Actor/P3Character that has all of this tags will trigger switch */
	UPROPERTY(EditAnywhere, Category = "Shape Triggered Switch")
	FGameplayTagContainer TriggerGameplayTagsAll;

	/** When the number of P3Actors/P3Characters that can trigger switch is over or same this number, the switch will be triggered */
	UPROPERTY(EditAnywhere, Category = "Shape Triggered Switch", meta=(UIMin = 1, ClampMin = 1))
	int32 MinimumTriggerActorsCount = 1;

	/** Actors that triggered this switch (Subset of currently overlapped actors) */
	UPROPERTY(Transient)
	TSet<AActor*> TriggeredActors;
};


/**
 * Box Triggered Switch Actor (Server only!)
 */
UCLASS(Blueprintable)
class P3_API AP3BoxTriggeredSwitchActor : public AP3ShapeTriggeredSwitchBaseActor
{
	GENERATED_BODY()

public:
	AP3BoxTriggeredSwitchActor(const FObjectInitializer& ObjectInitializer);
};

/** 
 * Sphere Triggered Switch Actor (Server only!)
 */
UCLASS(Blueprintable)
class P3_API AP3SphereTriggeredSwitchActor : public AP3ShapeTriggeredSwitchBaseActor
{
	GENERATED_BODY()

public:
	AP3SphereTriggeredSwitchActor(const FObjectInitializer& ObjectInitializer);
};


/** 
 * Interactable switch
 *	can be toggled with player's interaction input
 */
UCLASS(Blueprintable)
class P3_API AP3InteractableSwitchActor : public AP3SwitchActor
{
	GENERATED_BODY()

	AP3InteractableSwitchActor();

protected:
	virtual void BeginPlay() override;
	virtual void OnToggleSwitch(bool bInOn) override;

private:
	UPROPERTY(EditDefaultsOnly, Category = "Interactable Switch")
	bool bAllowInteractionDuringOn = true;

	UPROPERTY(EditDefaultsOnly, Category = "Interactable Switch")
	bool bAllowInteractionDuringOff = true;

	UFUNCTION()
	void Server_OnInteracted(class AActor* Interactor);

	UPROPERTY()
	class UP3InteractableComponent* InteractableComponent;
};



/** 
 * Health triggered switch actor (Server only!)
 */
UCLASS(Blueprintable)
class P3_API AP3TimerSwitch : public AP3SwitchActor
{
	GENERATED_BODY()

public:
	AP3TimerSwitch();

protected:
	virtual void BeginPlay() override;
	virtual void OnToggleSwitch(bool bInOn) override;

private:
	void Server_StartTimer();

	UFUNCTION()
	void Server_OnTurnOnTimer();

	UFUNCTION()
	void Server_OnTurnOffTimer();

	/** If switch is offed. It will be turned on after this time. < 0 means timer off */
	UPROPERTY(EditAnywhere, Category = "Timer Switch")
	float TurnOnTimeSeconds = 10.0f;

	/** If switch is on. It will be turned off after this time. < 0 means timer off */
	UPROPERTY(EditAnywhere, Category = "Timer Switch")
	float TurnOffTimeSeconds = 10.0f;

	FTimerHandle TurnOnTimerHandle;
	FTimerHandle TurnOffTimerHandle;
};
