// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PartInventoryComponent.h"
#include "P3Core.h"
#include "Widget/P3InventoryWidget.h"
#include "Widget/P3InventorySlotWidget.h"

#include "P3Character.h"
#include "P3EquipmentComponent.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"

UP3PartInventoryComponent::UP3PartInventoryComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	InventoryParts.Reserve(8);	
}

void UP3PartInventoryComponent::OnRegister()
{
	Super::OnRegister();

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (ensure(Character))
	{
		Character->OnInputShowInventory.AddUniqueDynamic(this, &UP3PartInventoryComponent::OnShowInventory);
	}
}

void UP3PartInventoryComponent::OnUnregister()
{
	Super::OnUnregister();

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (ensure(Character))
	{
		Character->OnInputShowInventory.RemoveDynamic(this, &UP3PartInventoryComponent::OnShowInventory);
	}

	/*if (InventoryWidget)
	{
		for (int32 i = 0; i < InventoryWidget->GetSlotNum(); ++i)
		{
			UP3InventorySlotWidget* SlotWidget = InventoryWidget->GetSlotWidget(i);
			if (!ensure(SlotWidget)) continue;

			SlotWidget->OnSlotPressed.RemoveDynamic(this, &UP3PartInventoryComponent::OnSlotPressed);
		}
	}*/
}

void UP3PartInventoryComponent::NetSerialize(FArchive& Archive)
{
	Archive << InventoryParts;	

	UP3EquipmentComponent* PartComponent = GetOwner()->FindComponentByClass<UP3EquipmentComponent>();
	if (ensure(PartComponent))
	{
		for (int32 i = 0; i < InventoryParts.Num(); ++i)
		{			
			if (InventoryParts[i]->IsHolder())
			{
				PartComponent->AddPart(HolderParts);
			}

			InventoryParts[i]->SetSlotIndex(i);
		}		
	}

	/*if (InventoryWidget)
	{		
		for (int32 i = 0; i < InventoryWidget->GetSlotNum(); ++i)
		{
			UP3InventorySlotWidget* SlotWidget = InventoryWidget->GetSlotWidget(i);
			if (!ensure(SlotWidget)) continue;

			SlotWidget->OnSlotPressed.AddUniqueDynamic(this, &UP3PartInventoryComponent::OnSlotPressed);

			if (InventoryParts.IsValidIndex(i))
			{
				SlotWidget->SetTextBlocName(InventoryParts[i]->GetPartName());
			}
		}
	}*/
}

void UP3PartInventoryComponent::Server_BeginPlayP3World()
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.Owner = GetOwner();
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	for (const auto& Iter : PartClass)
	{
		if(!Iter.Key) continue;

		AP3Part* Part = GetWorld()->SpawnActor<AP3Part>(Iter.Key, SpawnInfo);
		if (ensure(Part))
		{			
			Part->SetEnableHolder(Iter.Value);
			InventoryParts.Add(Part);
		}
	}
}

void UP3PartInventoryComponent::BeginPlay()
{
	Super::BeginPlay();

	if (!P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		LocalControll_BeginPlay();
	}	
}

void UP3PartInventoryComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
}

void UP3PartInventoryComponent::LocalControll_BeginPlay()
{
	ensure(!P3Core::IsP3NetModeServerInstance(*this));

	//const AP3Character* Character = Cast<AP3Character>(GetOwner());
	//if (ensure(Character))
	//{
	//	APlayerController* PlayerCtrl = Cast<APlayerController>(Character->GetController());
	//	if (!PlayerCtrl)
	//		return;

	//	InventoryWidget = CreateWidget<UP3InventoryWidget>(PlayerCtrl, UP3InventoryWidget::StaticClass());
	//	if (ensure(InventoryWidget))
	//	{
	//		DefaultSlotCount = FMath::Max<int32>(DefaultSlotCount, PartClass.Num());

	//		InventoryWidget->SetSlotCount(DefaultSlotCount);
	//		InventoryWidget->AddToViewport();
	//	}
	//}
}

bool UP3PartInventoryComponent::CanHolder(int32 SlotIndex) const
{
	return InventoryParts.IsValidIndex(SlotIndex) && !InventoryParts[SlotIndex]->IsHolder();		
}

void UP3PartInventoryComponent::OnShowInventory()
{
	/*if (ensure(InventoryWidget))
	{
		InventoryWidget->ShowInventory();
	}*/
}

void UP3PartInventoryComponent::OnSlotPressed(int32 SlotIndex)
{	
	const AP3Character* Character = Cast<AP3Character>(GetOwner());	
	if (ensure(Character) && CanHolder(SlotIndex))
	{
		UP3CommandComponent* CommandComponent = Character->GetCommandComponent();
		if (ensure(CommandComponent))
		{
			FP3CommandRequestParams Params;
			Params.SetPart_bAdd = true;
			Params.SlotIndex = SlotIndex;

			CommandComponent->RequestCommand(UP3StartPartCommand::StaticClass(), Params);
		}
	}

	/*if (ensure(InventoryWidget))
	{
		InventoryWidget->HiddenInventory();
	}*/
}

void UP3PartInventoryComponent::HolderPart(int32 SlotIndex)
{
	if (!CanHolder(SlotIndex)) return;

	/*UP3EquipmentComponent* PartComponent = GetOwner()->FindComponentByClass<UP3EquipmentComponent>();
	if (ensure(PartComponent))
	{
		const AP3Part* RemovePart = PartComponent->AddPart(InventoryParts[SlotIndex]);
		if (InventoryWidget)
		{
			if (RemovePart)
			{
				InventoryWidget->SetSlotName(RemovePart->GetPartName(), RemovePart->GetSlotIndex());
			}
			
			InventoryWidget->SetSlotName(NAME_None, SlotIndex);			
		}
	}*/
}

