// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PickupComponent.h"

#include "Components/PrimitiveComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "DestructibleComponent.h"
#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "GameFramework/Controller.h"
#include "Kismet/GameplayStatics.h"

#include "Action/P3PawnActionComponent.h"
#include "Action/P3PickupAction.h"
#include "Chemical/P3FlammableComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Backpack.h"
#include "P3Character.h"
#include "P3ConsumableComponent.h"
#include "P3Destructible.h"
#include "P3CharacterHealthPointComponent.h"
#include "P3HoldableComponent.h"
#include "P3HolderComponent.h"
#include "P3InteractableComponent.h"
#include "P3InventoryComponent.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3PickupableComponent.h"
#include "P3Physics.h"
#include "P3PlayerController.h"
#include "P3QuestComponent.h"
#include "P3ServerWorld.h"
#include "P3Spear.h"
#include "P3StaminaPointComponent.h"
#include "P3SwitchActor.h"
#include "P3Weapon.h"
#include "P3World.h"

TAutoConsoleVariable<int32> CVarP3PickupDebug(
    TEXT("p3.pickupDebug"),
    0,
    TEXT("1: enable debug. 0: disable dibug"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3SwitchUseInteractionDebug(
    TEXT("p3.switchUseInteraction"),
    0,
    TEXT("1: use interaction key to toggle switch"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3MountRegolasMoveRadiusScale(
	TEXT("p3.mountRegolasMoveRadiusScale"),
	2.0f,
	TEXT("Mount point radius is scaled by this during regolas move"), ECVF_Cheat);


static bool _IsRegolasMountingJavelin(APawn* MyActor, AActor* JavelinActor, AP3Character** OutMountTargetCharacter, int32* OutMountPointIndex)
{
	if (!JavelinActor)
	{
		return false;
	}

	UP3JavelinComponent* JavelinComp = JavelinActor->FindComponentByClass<UP3JavelinComponent>();
	if (JavelinComp
		&& JavelinComp->GetImpaledCharacter()
		&& JavelinComp->GetImpaledCharacter()->IsLarge()
		&& JavelinComp->GetImpaledCharacter() != MyActor
		&& JavelinComp->GetImpaledCharacter()->GetMesh())
	{
		const FVector JavelinLocation = JavelinActor->GetActorLocation();
		AP3Character* TargetCharacter = JavelinComp->GetImpaledCharacter();
		const TArray<FP3CharacterMountPoint>& MountPoints = TargetCharacter->GetMountPoints();

		int32 TargetMountPointIndex = -1;

		// Find nearest available mount point
		const float RegolasMoveRadiusScale = CVarP3MountRegolasMoveRadiusScale.GetValueOnGameThread();
		float MinDistanceSquared = MAX_flt;
		const int32 NumMountPoints = TargetCharacter->GetMountPoints().Num();
		for (int32 MountPointIndex = 0; MountPointIndex < NumMountPoints; ++MountPointIndex)
		{
			if (!TargetCharacter->IsMountPointAvailable(MountPointIndex))
			{
				continue;
			}

			const FP3CharacterMountPoint& MountPoint = TargetCharacter->GetMountPoints()[MountPointIndex];
			const FVector SocketLocation = TargetCharacter->GetMesh()->GetSocketLocation(MountPoint.SocketName);
			const float DistanceSquared = (SocketLocation - JavelinLocation).SizeSquared();

			if (DistanceSquared < FMath::Square(MountPoint.MountStartRadius * RegolasMoveRadiusScale))
			{
				if (MinDistanceSquared > DistanceSquared)
				{
					MinDistanceSquared = DistanceSquared;
					TargetMountPointIndex = MountPointIndex;
				}
			}
		}

		if (TargetMountPointIndex == -1)
		{
			// No mount point is available
			return false;
		}

		if (OutMountTargetCharacter)
		{
			*OutMountTargetCharacter = TargetCharacter;
		}

		if (OutMountPointIndex)
		{
			*OutMountPointIndex = TargetMountPointIndex;
		}

		return true;
	}

	return false;
}

UP3PickupComponent::UP3PickupComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	MaxPickupableMass = 500;
	PickupRange = 200;
	ThrowVelocity.Set(1200, 0, 100);

	bInInterpolatedAttaching = false;
}

void UP3PickupComponent::BeginPlay()
{
	Super::BeginPlay();

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	// DYLEE NOTE P3-3209 작업 영역 분리
	if (!CVarP3ActionDataDriven.GetValueOnGameThread())
	{
		UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
		if (ensure(ActionComp))
		{
			ActionComp->RegisterAction(EPawnActionType::Pickup, EPawnActionCategory::Pickup, NewObject<UP3PickupPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::PickupHoldable, EPawnActionCategory::Pickup, NewObject<UP3PickupHoldablePawnAction>());
			ActionComp->RegisterAction(EPawnActionType::PickupConsumable, EPawnActionCategory::Pickup, NewObject<UP3PickupConsumablePawnAction>());
			ActionComp->RegisterAction(EPawnActionType::PickupBackpack, EPawnActionCategory::Pickup, NewObject<UP3PickupBackpackPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::UseConsumable, EPawnActionCategory::Pickup, NewObject<UP3UseConsumablePawnAction>());
			ActionComp->RegisterAction(EPawnActionType::HoldItemFromInventory, EPawnActionCategory::Pickup, NewObject<UP3HoldFromInventoryPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::Interact, EPawnActionCategory::Pickup, NewObject<UP3InteractPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::Switching, EPawnActionCategory::Pickup, NewObject<UP3SwitchingPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::Putdown, EPawnActionCategory::Pickup, NewObject<UP3PutdownPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::PutdownHoldable, EPawnActionCategory::Pickup, NewObject<UP3PutdownHoldablePawnAction>());
			ActionComp->RegisterAction(EPawnActionType::PutdownBackpack, EPawnActionCategory::Pickup, NewObject<UP3PutdownBackpackPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::Throw, EPawnActionCategory::Pickup, NewObject<UP3ThrowPawnAction>());
			ActionComp->RegisterAction(EPawnActionType::MountByRegolasMove, EPawnActionCategory::Pickup, NewObject<UP3MountByRegolasMoveAction>());
		}
	}
	else
	{
	}

	if (Character && Character->GetController() && Character->GetController()->IsLocalPlayerController())
	{
		PickupCandidate.Enable(true);
	}
	else
	{
		PickupCandidate.Enable(false);
	}
}

void UP3PickupComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (PickuppedActor && PickuppedActor->IsActorBeingDestroyed())
	{
		PickuppedActor = nullptr;
	}

	LocalControll_UpdatePickupCandidate();

	if (!PickuppedActor)
	{
		bIsAimingThrowing = false;

		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			AP3Character* Character = Cast<AP3Character>(GetOwner());
			if (Character && Character->GetStance() == EP3CharacterStance::Pickup)
			{
				UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
				if (ActionComp && ActionComp->GetActiveActionType() == EPawnActionType::Invalid)
				{
					UP3CommandComponent* CommandComp = Character->GetCommandComponent();
					if (ensure(CommandComp))
					{
						FP3CommandRequestParams Params;
						Params.ChangeStance_NewStance = EP3CharacterStance::Idle;
						CommandComp->RequestCommand(UP3ChangeStanceCommand::StaticClass(), Params);
					}
				}
			}
		}
	}
	else
	{
		if (P3Core::IsP3NetModeServerInstance(*this))
		{
			AP3Character* Character = Cast<AP3Character>(GetOwner());
			if (Character && Character->HasStun())
			{
				FP3CommandRequestParams CommandParams;
				Character->GetCommandComponent()->RequestCommand(UP3DropPickableCommand::StaticClass(), CommandParams);
			}
		}
	}

	if (!HasBackpackCandidate())
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character && IsLocalControlledActor(Character) && Character->IsPlayerControlled() && Character->LocalControl_IsBackpackUIOpened())
		{
			Character->OnInputCloseBackpackInventory.Broadcast();
		}
	}

	// Show client only object
	//if (P3Core::IsP3NetModeStandalone(*GetOwner()) || !P3Core::IsP3NetModeServerInstance(*GetOwner()))
	//{
	//	AP3Character* Character = Cast<AP3Character>(GetOwner());
	//	if (Character)
	//	{
	//		if (!Character->GetCharacterStoreBP().bIsAiming || Character->GetCharacterStoreBP().bIsChangingThrowable)
	//		{
	//			if (Client_TempAimingActor)
	//			{
	//				Client_TempAimingActor->Destroy();
	//				Client_TempAimingActor = nullptr;
	//			}
	//		}
	//		else
	//		{
	//			// Note this should not called from non-standalone server, since P3Actor will get replicated to client and makes problem (like collision)
	//			const bool bAimingItem = Character && Character->GetCharacterStoreBP().ThrowAimingItemId != INVALID_ITEMID;

	//			if (bAimingItem && !Client_TempAimingActor)
	//			{
	//				UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();

	//				if (InventoryComp)
	//				{
	//					Client_TempAimingActor = InventoryComp->SpawnItemActor(Character->GetCharacterStoreBP().ThrowAimingItemId);

	//					if (Client_TempAimingActor)
	//					{
	//						HoldActor(Client_TempAimingActor, false);
	//					}
	//				}
	//			}
	//		}
	//	}
	//}

	if (CVarP3PickupDebug.GetValueOnGameThread() != 0)
	{
		if (PickuppedActor)
		{
			AP3Character* Character = Cast<AP3Character>(GetOwner());
			if (Character)
			{
				Character->AddDebugString(FString::Printf(TEXT("Pickupped: %s"), *PickuppedActor->GetName()));
			}
		}
	}
}

bool UP3PickupComponent::HasPickupToInvenCandidate() const
{
	AActor* CandiateActor = PickupCandidate.GetActor();

	if (!CandiateActor)
	{
		return false;
	}

	if (CandiateActor->FindComponentByClass<UP3ConsumableComponent>() != nullptr)
	{
		return true;
	}

	if (UP3PickupableComponent* PickupableComp = CandiateActor->FindComponentByClass<UP3PickupableComponent>())
	{
		if (PickupableComp->IsPickupToInventory())
		{
			return true;
		}
	}

	return false;
}

bool UP3PickupComponent::HasRescueCandidate() const
{
	AActor* CandiateActor = PickupCandidate.GetActor();

	if (!CandiateActor)
	{
		return false;
	}

	UP3CharacterHealthPointComponent* HealthComp = CandiateActor->FindComponentByClass<UP3CharacterHealthPointComponent>();

	if (HealthComp && HealthComp->IsDowned())
	{
		return true;
	}

	return false;
}

bool UP3PickupComponent::HasTempWeaponCandidate() const
{
	AP3Weapon* CandiateWeapon = Cast<AP3Weapon>(PickupCandidate.GetActor());

	if (!CandiateWeapon)
	{
		return false;
	}

	const bool bTempWeapon = IsTempWeapon(CandiateWeapon->GetWeaponType());

	return bTempWeapon;
}

bool UP3PickupComponent::HasBackpackCandidate() const
{
	AP3Backpack* CandiateBackpack = Cast<AP3Backpack>(PickupCandidate.GetActor());

	return CandiateBackpack ? true : false;
}

void UP3PickupComponent::SetPickuppedActor(AActor* InPickuppedActor)
{
	PickuppedActor = InPickuppedActor;
}

void UP3PickupComponent::HoldActor(AActor* Actor, bool bSetAsPickupedActor)
{
	if (!Actor)
	{
		return;
	}

	if (bSetAsPickupedActor && PickuppedActor && IsValid(PickuppedActor))
	{
		ensure(0);
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	Actor->DisableComponentsSimulatePhysics();

	EP3PickupableType PickupableType = EP3PickupableType::Harvest;

	UP3PickupableComponent* PickupableComp = Actor->FindComponentByClass<UP3PickupableComponent>();
	if (PickupableComp)
	{
		PickupableComp->DisablePhysicsForPickup();
		PickupableType = PickupableComp->GetPickupableType();
	}

	const FName* SocketName = AttachSocketNames.Find(PickupableType);
	ensure(SocketName);

	Actor->AttachToComponent(Character->GetMesh(), FAttachmentTransformRules::SnapToTargetNotIncludingScale, SocketName ? *SocketName : NAME_None);

	if (bSetAsPickupedActor)
	{
		SetPickuppedActor(Actor);
	}
}

const FName UP3PickupComponent::GetAttachSocketName(EP3PickupableType PickupableType) const
{
	const FName* SocketName = AttachSocketNames.Find(PickupableType);
	return SocketName ? *SocketName : NAME_None;
}

void UP3PickupComponent::LocalControll_UpdatePickupCandidate()
{
	APawn* MyPawn = Cast<APawn>(GetOwner());
	
	if (!MyPawn || !IsLocalControlledActor(MyPawn) || !MyPawn->IsPlayerControlled())
	{
		PickupCandidate.SetActor(nullptr);
		PickupCandidateHolderComponent = nullptr;
		return;
	}

	// Comment-out: To cook, you need to hold ingredient and interact with cooker
	//if (PickuppedActor)
	//{
	//	// You need more hands to pickup another one
	//	PickupCandidate.SetActor(nullptr);
	//	PickupCandidateHolderComponent = nullptr;
	//	return;
	//}

	TInlineComponentArray<UP3HolderComponent*> HolderComponents;
	GetOwner()->GetComponents(HolderComponents);

	AActor* NewPickupCandidate = nullptr;

	// See if we have anything new in front of us
	AActor* Owner = GetOwner();

	FCollisionShape CollisionShape;
	CollisionShape.SetSphere(PickupRange);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(Owner);

	TArray<FOverlapResult> OverlapResults;
	GetWorld()->OverlapMultiByChannel(OverlapResults, Owner->GetActorLocation(), Owner->GetActorQuat(), ECC_WorldDynamic, CollisionShape, QueryParams);

	const FVector ForwardVec = Owner->GetActorQuat().GetForwardVector();
	const FVector UpVec = Owner->GetActorQuat().GetUpVector();
	float BestCandidatePoint = 0;
	UP3HolderComponent* BestCandidateHolderComp = nullptr;

	for (const FOverlapResult& Result : OverlapResults)
	{
		AActor* Actor = Result.GetActor();
		if (!Actor)
		{
			continue;
		}

		AP3Weapon* Weapon = Cast<AP3Weapon>(Actor);
		if (Weapon && (!Weapon->CanPickupCandidate() || !Weapon->IsPlayerUsable()))
		{
			continue;
		}

		AP3Destructible* Destructible = Cast<AP3Destructible>(Actor);
		if (Destructible && Destructible->IsExploded())
		{
			continue;
		}

		if (Actor->GetAttachParentActor() == Owner)
		{
			continue;
		}

		AP3SwitchActor* SwitchActor = nullptr;

		if (CVarP3SwitchUseInteractionDebug.GetValueOnGameThread() != 0)
		{
			SwitchActor = Cast<AP3SwitchActor>(Actor);
		}

		const FVector LocationDiff = Actor->GetActorLocation() - Owner->GetActorLocation();
		const FVector Direction2D = (LocationDiff - ((LocationDiff | UpVec) * UpVec)).GetSafeNormal();
		const float ForwardDot = (Direction2D | ForwardVec);

		// Should be in front of me
		if (ForwardDot < 0.5)
		{
			continue;
		}

		// Should have those component to pick up
		UP3PickupableComponent* PickupableComp = Actor->FindComponentByClass<UP3PickupableComponent>();
		UP3HoldableComponent* HoldableComp = Actor->FindComponentByClass<UP3HoldableComponent>();
		UP3ConsumableComponent* ConsumableComp = Actor->FindComponentByClass<UP3ConsumableComponent>();
		UP3InteractableComponent* InteractableComp = Actor->FindComponentByClass<UP3InteractableComponent>();
		UP3CharacterHealthPointComponent* HealthComp = Actor->FindComponentByClass<UP3CharacterHealthPointComponent>();

		if (!PickupableComp && !HoldableComp && !ConsumableComp && !InteractableComp && !SwitchActor && !HealthComp)
		{
			continue;
		}

		if (HoldableComp && HoldableComp->GetHolderComponent() != nullptr)
		{
			// Already attached to something
			continue;
		}

		UP3HolderComponent* MatchedHolderComp = nullptr;

		if (PickupableComp)
		{
			if (PickupableComp->GetPickupableType() != EP3PickupableType::Spear)
			{
				UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(Actor->GetRootComponent());
			
				if (!PrimComp)
				{
					// Not interested
					continue;
				}

				// Comment-out: we want these items to be placed in world without physics so that we can place it anywhere
				//// It got to be physical, except spear, which might be stuck on something
				//if (!PrimComp->IsAnySimulatingPhysics())
				//{
				//	continue;
				//}

				if (PrimComp->IsAnySimulatingPhysics() && PrimComp->GetMass() > MaxPickupableMass)
				{
					// Too heavy
					continue;
				}
			}
		}
		else if (HoldableComp)
		{
			// Ok this is tricky one
			// When javelin is pinned to boss monster near mount point
			// Player can use that javelin to mount.
			if (_IsRegolasMountingJavelin(MyPawn, Actor, nullptr, nullptr))
			{
				// Good to go
			}
			else
			{
				UClass* ItemActorClass = Actor->GetClass();
				itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
				if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
				{
					P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
					continue;
				}

				const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(ItemCmsKey);
				if (!ensure(CmsHoldable))
				{
					P3JsonLog(Warning, "Missing cms holdable", TEXT("Class"), *Actor->GetClass()->GetName());
					continue;
				}

				for (EP3HoldType HoldType : CmsHoldable->HoldTypes)
				{
					for (UP3HolderComponent* HolderComp : HolderComponents)
					{
						if (HolderComp->GetHoldType() == HoldType)
						{
							MatchedHolderComp = HolderComp;
							break;
						}
					}

					if (MatchedHolderComp)
					{
						break;
					}
				}

				if (!MatchedHolderComp)
				{
					continue;
				}
			}
		}
		else if (ConsumableComp)
		{
			UClass* ItemActorClass = Actor->GetClass();
			itemkey ItemCmsKey = P3Cms::GetItemKeyFromActorClass(ItemActorClass);
			if (!ensure(ItemCmsKey != INVALID_ITEMKEY))
			{
				P3JsonLog(Warning, "Invalid item key", TEXT("Class"), ItemActorClass ? *ItemActorClass->GetName() : TEXT("null"));
				continue;
			}

			const FP3CmsConsumable* CmsConsumable = P3Cms::GetItemConsumable(ItemCmsKey);
			if (!ensure(CmsConsumable))
			{
				P3JsonLog(Warning, "Missing cms consumable", TEXT("Class"), *Actor->GetClass()->GetName());
				continue;
			}
		}
		else if (InteractableComp)
		{
			if (!InteractableComp->IsInteractionAllowed())
			{
				continue;
			}

			if (InteractableComp->GetInteractableType() == EP3InteractableType::Talk)
			{
				AP3Character* Character = Cast<AP3Character>(Owner);
				UP3QuestComponent* QuestComp = Character ? Character->GetQuestComponent() : nullptr;

				if (!QuestComp || !QuestComp->IsManuallyProceedable())
				{
					continue;
				}
			}
		}
		else if (SwitchActor)
		{
			// Nothing to check for now
		}
		else if (HealthComp && !HealthComp->IsDowned())
		{
			continue;
		}

		// Calculate Directional and Distance point to pick best candidate
		const float DistanceSquared = (Actor->GetActorLocation() - Owner->GetActorLocation()).SizeSquared();
		const float Point = (ForwardDot * (PickupRange * PickupRange)) + ((PickupRange * PickupRange) - DistanceSquared);

#if ENABLE_DRAW_DEBUG
		if (CVarP3PickupDebug.GetValueOnGameThread() > 0)
		{
			DrawDebugString(GetWorld(), Actor->GetActorLocation(), FString::Printf(TEXT("Dist(%.1f), Forward(%.1f), Point(%.1f)"), DistanceSquared, ForwardDot, Point), nullptr, FColor::White, 0.0f, true);
		}
#endif

		if (Point > BestCandidatePoint)
		{
			NewPickupCandidate = Actor;
			BestCandidatePoint = Point;
			BestCandidateHolderComp = MatchedHolderComp;
		}
	}

	PickupCandidate.SetActor(NewPickupCandidate);
	PickupCandidateHolderComponent = BestCandidateHolderComp;

#if ENABLE_DRAW_DEBUG
	if (CVarP3PickupDebug.GetValueOnGameThread() != 0)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character)
		{
			for (auto&& Iter : AttachSocketNames)
			{
				const FName& SocketName = Iter.Value;
				const FTransform SocketTransform = Character->GetMesh()->GetSocketTransform(SocketName);

				DrawDebugCoordinateSystem(GetWorld(), SocketTransform.GetLocation(), SocketTransform.Rotator(), 20.0f);
			}
		}
	}
#endif
}

void UP3PickupComponent::Pickup()
{
	if (PickupCandidate.GetActor())
	{
		PickupActor(*PickupCandidate.GetActor(), PickupCandidateHolderComponent);

		PickupCandidate.SetActor(nullptr);
		PickupCandidateHolderComponent = nullptr;
	}
}

void UP3PickupComponent::PickupActor(AActor& TargetActor, UP3HolderComponent* HolderComponent)
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
	if (ensure(ActionComp))
	{
		UP3CharacterHealthPointComponent* TargetCharacterHealthComp = TargetActor.FindComponentByClass<UP3CharacterHealthPointComponent>();
		if (TargetCharacterHealthComp && TargetCharacterHealthComp->IsDowned())
		{
			if (PickuppedActor)
			{
				ensure(0);
				return;
			}

			FP3PawnActionStartRequestParams Params;
			Params.Rescue_TargetActor = &TargetActor;

			ActionComp->StartAction(EPawnActionType::Rescue, _FUNCTION_TEXT, Params);
		}
		else if (UP3PickupableComponent* PickupableComp = TargetActor.FindComponentByClass<UP3PickupableComponent>())
		{
			if (PickuppedActor)
			{
				return;
			}

			const EP3PickupableType PickupableType = PickupableComp->GetPickupableType();
			const FName* SocketName = AttachSocketNames.Find(PickupableType);
			ensure(SocketName);

			FP3PawnActionStartRequestParams Params;
			Params.Pickup_ObjectActor = &TargetActor;
			Params.Pickup_AttachSocketName = SocketName ? *SocketName : NAME_None;

			ActionComp->StartAction(EPawnActionType::Pickup, _FUNCTION_TEXT, Params);
		}
		else if (TargetActor.FindComponentByClass<UP3HoldableComponent>() != nullptr)
		{
			if (PickuppedActor)
			{
				return;
			}

			AP3Character* MountTargetCharacter = nullptr;
			int32 MountPointIndex = -1;

			if (_IsRegolasMountingJavelin(Character, &TargetActor, &MountTargetCharacter, &MountPointIndex))
			{
				FP3PawnActionStartRequestParams Params;
				Params.MountByRegolasMove_HandleActor = &TargetActor;
				Params.MountByRegolasMove_TargetCharacter = MountTargetCharacter;
				Params.MountByRegolasMove_TargetMountIndex = MountPointIndex;

				ActionComp->StartAction(EPawnActionType::MountByRegolasMove, _FUNCTION_TEXT, Params);
			}
			else
			{
				const FP3CmsHoldable* CmsHoldable = P3Cms::GetItemHoldable(P3Cms::GetItemKeyFromActorClass(TargetActor.GetClass()));

				if (CmsHoldable && IsTempWeapon(CmsHoldable->WeaponType))
				{
					// You can only have 1 temp weapon
					UP3InventoryComponent* InventoryComp = Character->GetInventoryComponentBP();

					if (InventoryComp && InventoryComp->HasTempWeapon())
					{
						P3Core::Client_ToastMessageBP(GetWorld(), P3LOC_ITEM("CannotPickupAnotherTempWeapon"));
						return;
					}
				}

				FP3PawnActionStartRequestParams Params;
				Params.PickupHoldable_ObjectActor = &TargetActor;
				Params.PickupHoldable_HolderType = HolderComponent->GetHoldType();

				ActionComp->StartAction(EPawnActionType::PickupHoldable, _FUNCTION_TEXT, Params);
			}
		}
		else if (TargetActor.FindComponentByClass<UP3ConsumableComponent>() != nullptr)
		{
			if (PickuppedActor)
			{
				return;
			}

			FP3PawnActionStartRequestParams Params;
			Params.PickupConsumable_ObjectActor = &TargetActor;

			ActionComp->StartAction(EPawnActionType::PickupConsumable, _FUNCTION_TEXT, Params);
		}
		else if (UP3InteractableComponent* InteractableComp = TargetActor.FindComponentByClass<UP3InteractableComponent>())
		{
			if (InteractableComp->GetInteractableType() == EP3InteractableType::Cooker)
			{
				UP3FlammableComponent* FlammableComp = TargetActor.FindComponentByClass<UP3FlammableComponent>();
				if (!FlammableComp || FlammableComp->IsInFire())
				{
					TArray<AActor*> IngredientActors;

					// TODO: support multiple pickupped items
					IngredientActors.Add(GetPickuppedActor());

					const FName RecipeKey = P3Cms::FindCookingRecipeKeyWithIngredient(IngredientActors);

					if (!RecipeKey.IsNone())
					{
						FP3PawnActionStartRequestParams Params;
						Params.Cooking_RecipeKey = RecipeKey;
						Params.Cooking_CookerActor = &TargetActor;

						ActionComp->StartAction(EPawnActionType::Cook, _FUNCTION_TEXT, Params);
					}
				}
			}
			else if (InteractableComp->GetInteractableType() == EP3InteractableType::Talk)
			{
				UP3CommandComponent* CommandComp = Character ? Character->GetCommandComponent() : nullptr;

				if (CommandComp)
				{
					FP3CommandRequestParams Params;
					Params.TalkTargetActor = &TargetActor;
					CommandComp->RequestCommand(UP3TalkCommand::StaticClass(), Params);
				}
			}
			else
			{
				UP3LootingInteractableComponent* LootingInteractComp = Cast<UP3LootingInteractableComponent>(InteractableComp);

				FP3PawnActionStartRequestParams Params;
				Params.Interact_InteracteeActor = &TargetActor;
				Params.Interact_bHoldLootItemOnInteract = LootingInteractComp ? LootingInteractComp->IsHoldLootItemOnInteract() : false;

				ActionComp->StartAction(EPawnActionType::Interact, _FUNCTION_TEXT, Params);
			}
		}
		else if (TargetActor.IsA(AP3SwitchActor::StaticClass()))
		{
			FP3PawnActionStartRequestParams Params;
			Params.Switching_SwitchActor = &TargetActor;
			Params.Switching_bOn = !Cast<AP3SwitchActor>(&TargetActor)->IsSwitchOn();

			ActionComp->StartAction(EPawnActionType::Switching, _FUNCTION_TEXT, Params);
		}
		else
		{
			ensure(0);
		}
	}
}

bool UP3PickupComponent::CanPutDown() const
{
	return (PickuppedActor != nullptr);
}

bool UP3PickupComponent::CanPutDownHoldable() const
{
	if (!GetOwner())
	{
		return false;
	}

	TInlineComponentArray<UP3HolderComponent*> HolderComponents;
	GetOwner()->GetComponents(HolderComponents);
	
	for (UP3HolderComponent* HolderComp : HolderComponents)
	{
		if (HolderComp->GetHoldingActor())
		{
			return true;
		}
	}

	return false;
}

bool UP3PickupComponent::IsPuttingDown() const
{
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
	if (ensure(ActionComp))
	{
		return ActionComp->IsActionInProgress(EPawnActionType::Putdown);
	}

	return false;
}

// TODO: do something better
static bool _IsActorItemized(const AActor& Actor)
{
	return Actor.bHidden;
}

void UP3PickupComponent::OnPickupActionStarted(AActor* TargetActor)
{
	ActorInPickupAction = TargetActor;
}

void UP3PickupComponent::OnPickupActionFinished(bool bSuccess, AActor* TargetActor)
{
	if (bSuccess && TargetActor)
	{
		// TODO: maybe better to be delegate
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		AP3PlayerController* Controller = Character ? Cast<AP3PlayerController>(Character->GetController()) : nullptr;
		if (Controller && Controller->IsLocalController())
		{
			Controller->OnPickup(TargetActor);
		}

		if (_IsActorItemized(*TargetActor))
		{
			// Already inserted into inventory. No need to hold it here
			PickuppedActor = nullptr;
		}
		else
		{
			PickuppedActor = TargetActor;
		}
	}
	else
	{
		PickuppedActor = nullptr;
	}

	ActorInPickupAction = nullptr;
}

void UP3PickupComponent::OnPutdownActionFinished()
{
	PickuppedActor = nullptr;
}

void UP3PickupComponent::OnThrowActionFinished()
{
	PickuppedActor = nullptr;
}

void UP3PickupComponent::Putdown()
{
	if (!ensure(PickuppedActor))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
	if (ensure(ActionComp))
	{
		FP3PawnActionStartRequestParams Params;

		UP3PickupableComponent* PickupableComp = PickuppedActor->FindComponentByClass<UP3PickupableComponent>();
		if (ensure(PickupableComp))
		{
			const EP3PickupableType PickupableType = PickupableComp->GetPickupableType();
			const FName* SocketName = AttachSocketNames.Find(PickupableType);
			ensure(SocketName);

			Params.Putdown_AttachSocketName = SocketName ? *SocketName : NAME_None;
		}

		ActionComp->StartAction(EPawnActionType::Putdown, _FUNCTION_TEXT, Params);
	}

}

void UP3PickupComponent::PutdownHoldable()
{
	ensure(CanPutDownHoldable());

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	TInlineComponentArray<UP3HolderComponent*> HolderComponents;
	GetOwner()->GetComponents(HolderComponents);

	UP3HolderComponent* PutdownHolderComp = nullptr;

	for (UP3HolderComponent* HolderComp : HolderComponents)
	{
		if (HolderComp->GetHoldingActor())
		{
			PutdownHolderComp = HolderComp;
			break;
		}
	}

	if (!ensure(PutdownHolderComp))
	{
		return;
	}

	AActor* HoldingActor = PutdownHolderComp->GetHoldingActor();

	if (!ensure(HoldingActor))
	{
		return;
	}

	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
	if (ensure(ActionComp))
	{
		FP3PawnActionStartRequestParams Params;
		Params.PutdownHoldable_ObjectActor = HoldingActor;
		Params.PutdownHoldable_HolderComponentName = PutdownHolderComp->GetName();

		ActionComp->StartAction(EPawnActionType::PutdownHoldable, _FUNCTION_TEXT, Params);
	}
}

void UP3PickupComponent::AimThrow()
{
	if (!ensure(PickuppedActor))
	{
		return;
	}

	bIsAimingThrowing = true;
}

void UP3PickupComponent::Throw()
{
	if (!ensure(PickuppedActor))
	{
		return;
	}

	if (!ensure(bIsAimingThrowing))
	{
		return;
	}

	bIsAimingThrowing = false;

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
	if (ensure(ActionComp))
	{
		FP3PawnActionStartRequestParams Params;

		if (Character->GetCharacterStoreBP().bIsAiming)
		{
			Params.Throw_Rotator = Character->GetControlRotation();
		}
		else
		{
			Params.Throw_Rotator = Character->GetActorRotation();
		}

		ActionComp->StartAction(EPawnActionType::Throw, _FUNCTION_TEXT, Params);
	}
}
