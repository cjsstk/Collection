// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Network/Lib/P3NetCore.h"
#include "P3StoreInterface.h"
#include "P3ExperiencePointComponent.generated.h"

UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class P3_API UP3ExperiencePointComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:
	UP3ExperiencePointComponent();

protected:
	virtual void BeginPlay() override;

public:
	virtual void OnRegister() override;
	virtual void OnUnregister() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	int32 GetMaxExperiencePoint() const;

	UFUNCTION(BlueprintCallable)
	int32 GetExperiencePoint() const { return ExperiencePoint; }

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	void SetMaxExperiencePoint(int32 CharLevel);

	void Server_InitExperiencePoint(int32 InExperiencePoint, int32 InCharLevel);
	void Server_AddExperiencePoint(int32 InExperiencePoint);

private:
	int32 ExperiencePoint = 0;
	int32 MaxExperiencePoint = 0;
};
