// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

UENUM(Blueprintable)
enum class EP3PickupableType : uint8
{
	None,
	OverHeadRock,		// (Default) Middle sized rock. Use both hand to hold it above head. Throw at middle range
	Spear,				// Throw-able spear. Use right hand to hold it. Throw at long range
	Harvest,			// Something grow on ground
	ElementFragment,	// Fire, Water, Wind element fragment
	Item,
	Count UMETA(Hidden)
};
