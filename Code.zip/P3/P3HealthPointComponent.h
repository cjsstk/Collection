// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Network/Lib/P3NetCore.h"
#include "P3StoreInterface.h"
#include "P3HealthPointComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FP3HealthPointCompOnHealthChange, class UP3HealthPointComponent*, Component, int32, OldHealthPoint, int32, NewHealthPoint);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3HealthPointCompOnDead);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FP3HealthPointCompOnRevive);

USTRUCT()
struct FP3NetRevive
{
	GENERATED_BODY()

	UPROPERTY()
	int32 HealthPoint = 0;
};

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3HealthPointComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3HealthPointComponent();

	virtual void OnRegister() override;
	virtual void OnUnregister() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UFUNCTION()
	void OnTakeAnyDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, AActor* DamageCauser);

	UFUNCTION(BlueprintCallable)
	bool IsDead() const { return IsDeadInternal(); }

	UFUNCTION(BlueprintCallable)
	float GetDeadTimeSeconds() const { return DeadTimeSeconds; }

	UFUNCTION(BlueprintCallable)
	float GetReviveTimeSeconds() const { return ReviveTimeSeconds; }

	UFUNCTION(BlueprintCallable)
	int32 GetMaxHealthPointBP() const { return MaxHealthPoint; }
	int32 GetMaxHealthPoint() const { return MaxHealthPoint; }

	UFUNCTION(BlueprintCallable)
	int32 GetHealthPointBP() const { return HealthPoint; }
	int32 GetHealthPoint() const { return HealthPoint; }

	UFUNCTION(BlueprintCallable)
	void SetMaxHealthPoint(int32 InMaxHealthPoint);

	UFUNCTION(BlueprintCallable)
	void SetHealthPoint(int32 InHealthPoint);

	UFUNCTION(BlueprintCallable)
	void ReviveBP(int32 InHealthPoint) { Server_Revive(InHealthPoint); }

	UFUNCTION(BlueprintCallable)
	void Server_Revive(int32 InHealthPoint);

	UFUNCTION(BlueprintCallable)
	void MulticastSetHealthPointBP(int32 InHealthPoint);

	void Server_SetServerOnly(bool bInServerOnly) { bServer_ServerOnly = bInServerOnly; }
	bool Server_IsServerOnly() const { return bServer_ServerOnly; }

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;
	virtual bool IsNetSerializeDisabled() const { return Server_IsServerOnly(); }

	UPROPERTY(BlueprintAssignable)
	FP3HealthPointCompOnDead OnDead;

	UPROPERTY(BlueprintAssignable)
	FP3HealthPointCompOnRevive OnRevive;

	UPROPERTY(BlueprintAssignable)
	FP3HealthPointCompOnHealthChange OnChange;

protected:
	virtual void BeginPlay() override;
	virtual void OnMaxHealthPointChanged() {}
	virtual void OnHealthPointChanged(int32 PrevHealthPoint, int32 CurrentHealthPoint) {};
	virtual bool IsDeadInternal() const { return HealthPoint == 0; }
	virtual void Server_OnDeadInternal() {}
	virtual void Server_SetDirty(const UActorComponent& Self) override;

	void SetHealthPointInternal(int32 InHealthPoint, bool bIsRevive, bool bIsSync);
	void Server_OnDead();

private:
	void MulticastCharacterDead();
	void MulticastCharacterRevive(int32 NewHealthPoint);

	UFUNCTION()
	void Client_HandleDead(const FP3DediToClientHandlerParams& Params);

	UFUNCTION()
	void Client_HandleRevive(const FP3DediToClientHandlerParams& Params);

	UPROPERTY(EditAnywhere)
	int32 MaxHealthPoint;

	int32 HealthPoint = 0;

	float DeadTimeSeconds;
	float ReviveTimeSeconds;

	bool bServer_ServerOnly = false;
};
