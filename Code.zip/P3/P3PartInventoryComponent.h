// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3StoreInterface.h"

#include "P3PartInventoryComponent.generated.h"


UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class P3_API UP3PartInventoryComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:		
	UP3PartInventoryComponent();	

	virtual void OnRegister() override;
	virtual void OnUnregister() override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;
	virtual void Server_BeginPlayP3World() override;

	void HolderPart(int32 SlotIndex);

protected:	
	virtual void BeginPlay() override;

public:		
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

		
private:
	void LocalControll_BeginPlay();
	bool CanHolder(int32 SlotIndex) const;

	UFUNCTION(BlueprintCallable, Category = P3)
	void OnShowInventory();
	
	UFUNCTION()
	void OnSlotPressed(int32 SlotIndex);

	UPROPERTY(EditAnywhere, Category = "P3")
	int32 DefaultSlotCount = 8;

	UPROPERTY(EditAnywhere, Category = "P3")	
	TMap<TSubclassOf<class AP3Part>,bool> PartClass;

	UPROPERTY()
	TArray<class AP3Part*> InventoryParts;
	
	UPROPERTY()
	TArray<class AP3Part*> HolderParts;

	UPROPERTY()
	class UP3InventoryWidget* InventoryWidget = nullptr;
};
