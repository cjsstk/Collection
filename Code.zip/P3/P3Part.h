// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3Actor.h"
#include "P3Part.generated.h"

UENUM(Blueprintable)
enum class EP3PartType : uint8
{		
	Mobile,
	Weapon,
	Assist,
	Count UMETA(Hidden),
};

UENUM(Blueprintable)
enum class EP3PartInputType : uint8
{
	None UMETA(Hidden),
	Passive,
	Combo,
	Charging,
	Toggle,
	Down,
	Up,
	Count UMETA(Hidden),
};

UENUM(Blueprintable)
enum class EP3PartViewType : uint8
{
	None UMETA(Hidden),
	Always,
	AlwaysHolder,
	InProgress,
	Count UMETA(Hidden),
};

UENUM(Meta = (Bitflags))
enum class EP3MobilePartFlags
{	
	Sliding,
	Boost,
	SuperJump, 
	Hovering
};

UCLASS(Blueprintable)
class P3_API AP3Part : public AP3Actor
{
	GENERATED_BODY()
	
public:
	AP3Part();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	
	void AddStartPart(const class AP3Character* Character);
	void RemoveStopPart(const class AP3Character* Character);
	void StartPart(const class AP3Character* Character);	
	void StopPart(const class AP3Character* Character);
	void StopPartInterrupt(const class AP3Character* Character);
	
	EP3PartType GetPartType() const { return PartType; }
	EP3PartViewType GetPartViewType() const { return PartViewType; }
	const FName& GetPartName() const { return PartName; }
	
	void SetEnableHolder(bool bEnable) { bHolder = bEnable; }
	bool IsHolder() const { return bHolder; }

	void SetSlotIndex(int32 InSlotIndex) { SlotIndex = InSlotIndex; }
	int32 GetSlotIndex() const { return SlotIndex; }	

	bool CanPartFlags(EP3PartType Type, int32 Flag) const;
	bool Server_BeginInterruptCondition(const class AP3Character* Character) const;
	bool Server_TickInterruptCondition(const class AP3Character* Character) const;
	
private:
	void AttachPart(const class AP3Character* Character);
	void DetachPart();
	
	void ActivateInternal(const class AP3Character* Character);
	void DeactivateInternal(const class AP3Character* Character);	
		
	UPROPERTY(VisibleAnywhere, Category = P3)
	class UStaticMeshComponent* StaticMeshComponent = nullptr;
		
	UPROPERTY(EditAnywhere, Category = P3)
	FName PartName = NAME_None;

	UPROPERTY(EditAnywhere, Category = P3)
	FName HoldSocketName = NAME_None;
	
	UPROPERTY(EditAnywhere, Category = P3)
	FVector HoldLocation = FVector::ZeroVector;
	
	UPROPERTY(EditAnywhere, Category = P3)
	FRotator HoldRotation = FRotator::ZeroRotator;

	UPROPERTY(EditAnywhere, Category = P3)
	EP3PartType PartType = EP3PartType::Mobile;

	UPROPERTY(EditAnywhere, Category = P3)
	EP3PartInputType PartInputType = EP3PartInputType::Passive;

	UPROPERTY(EditAnywhere, Category = P3)
	float Cost = 0.f;

	UPROPERTY(EditAnywhere, Category = P3)
	EP3PartViewType PartViewType = EP3PartViewType::Always;
	
	UPROPERTY(EditAnywhere, Meta = (Bitmask, BitmaskEnum = "EP3MobilePartFlags"), Category = P3)
	int32 MobilePartFlags = 0;
	
	bool bPlaying = false;		
	bool bHolder = false;
	int32 SlotIndex = 0;
	TArray<int32, TInlineAllocator<(int32)EP3PartType::Count>> PartFlags;
};
