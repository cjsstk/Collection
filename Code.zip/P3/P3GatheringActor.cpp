// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3GatheringActor.h"

#include "P3InteractableComponent.h"

AP3GatheringActor::AP3GatheringActor()
{
	LootingInteractableComponent = CreateDefaultSubobject<UP3LootingInteractableComponent>(TEXT("LootingInteractable"));
}
