// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"

#include "P3Cms.h"

#include "P3CombatResponseComponent.generated.h"

USTRUCT()
struct FP3RequestResponseParams
{
	GENERATED_BODY()

	void Reset()
	{
		AttackerActor = nullptr;
		AttackerActorID = -1;

		ReactionName = NAME_None;		
		Layer = EP3ReactionLayer::None;
		
		TargetTransform = FTransform::Identity;
		HitLocation = FVector::ZeroVector;
		HitBoneName = NAME_None;
		bIsFrameHold = false;
	}

	UPROPERTY(Transient)
	class AActor* AttackerActor = nullptr;
	
	int64 AttackerActorID = -1;
	FName ReactionName = NAME_None;
	EP3ReactionLayer Layer = EP3ReactionLayer::None;	
	FTransform TargetTransform = FTransform::Identity;
	FVector HitLocation = FVector::ZeroVector;
	
	FName HitBoneName = NAME_None;	
	bool bIsFrameHold = false;	
};

UCLASS(ClassGroup = (P3), Blueprintable, meta = (BlueprintSpawnableComponent))
class P3_API UP3CombatResponseComponent : public UActorComponent
{
	GENERATED_BODY()

public:		
	UP3CombatResponseComponent();

	virtual void InitializeComponent() override;
	virtual void UninitializeComponent() override;

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	void StartReaction(const FP3RequestResponseParams& InRequestReactionParams);	

	const UDataTable* GetCombatReactionTable(EP3ReactionLayer ReactionLayer) const;
	const UDataTable* GetCombatReactionOverlapRuleTable(EP3ReactionLayer ReactionLayer) const;

	const FVector GetReactiontDirection(class AP3Character& Character, EP3ReactiontDirection DesirDirection);

	void IncreaseOverlapCount();
	void ResetOverlapCount();
	int32 GetOverlapCount() const;		
	
	void SetReactionInProgress(FName ReactionName, EP3ReactionLayer Layer, EAnimNotifyAttackDirectionFlags AttackDirection, EAnimNotifyAttackStrengthFlags AttackStrength);
	const FName& GetInProgressName() const;
	EP3ReactionLayer GetInProgressLayer() const;	
	EAnimNotifyAttackDirectionFlags GetInProgressAttackDirection() const;
	EAnimNotifyAttackStrengthFlags GetInProgressAttackStrength() const;

	void SetInProgressAnimationType(EP3ReactionLayerAnimationType InReactionLayerAnimationType);
	EP3ReactionLayerAnimationType GetInProgressAnimationType() const;

	void SetNotifyStateSignal(const FName& SignalName, bool bIsEnabled);
	bool IsNotifyStateSignalEnabled(const FName& SignalName) const;

	void SetLastUpdateAttackerActor(AActor* InLastUpdateAttackerActor);
	AActor* GetLastUpdateAttackerActor() const;

	void SetLastUpdateCmsCombatHitKey(FName InLastUpdateCmsCombatHitKey);
	FName GetLastUpdateCmsCombatHitKey() const;
	
protected:		
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	/** Reaction Table */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<EP3ReactionLayer, UDataTable*> ReactionTable;

	/** Reaction OverlapRule Table */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<EP3ReactionLayer, UDataTable*> ReactionOverlapRuleTable;

private:
	void StartReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void StartMeshShake(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void StartReactionMovement(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void StartReactionMesh(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void Server_StartReactionStatus(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void Client_StartReactioUI(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void Client_StartReactioCamera(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);

	void TickReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds);
	void TickReactionMesh(AP3Character& Character, const FP3CombatReactionRow& ReactionRow, float DeltaSeconds);

	void FinishReactionAnimation(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void FinishMeshShake(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);	
	void FinishReactionMesh(AP3Character& Character, const FP3CombatReactionRow& ReactionRow);
	void FinishReaction();
	
	const FP3CombatReactionRow* GetReactionRow() const;		

	FP3RequestResponseParams RequestReactionParams;
		
	float CCDInProgressTimeSeconds = 0.f;
	float PoseAssetInProgressTimeSeconds = 0.f;
	float MorpthInProgressTimeSeconds = 0.f;
	float PhysicsBlendBoneInProgressTimeSeconds = 0.f;
	float FrameHoldInProgressTimeSeconds = 0.f;

	FVector RestoreMeshLocation = FVector::ZeroVector;
	bool bRestsoreMeshShake = false;

	TMap<FName, bool> NotifyStateSignal;
		
	int32 ReactionOverlapCount = 0;
	FName InProgressReactionName = NAME_None;
	EP3ReactionLayer InProgressLayer = EP3ReactionLayer::None;	
	EAnimNotifyAttackDirectionFlags InProgressAttackDirection = EAnimNotifyAttackDirectionFlags::None;
	EAnimNotifyAttackStrengthFlags InProgressAttackStrength = EAnimNotifyAttackStrengthFlags::Ignore;
	EP3ReactionLayerAnimationType InProgressReactionLayerAnimationType = EP3ReactionLayerAnimationType::None;

	UPROPERTY(Transient)
	AActor* LastUpdateAttackerActor = nullptr;
	FName LastUpdateCmsCombatHitKey = NAME_None;
};
