// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3QuestVolume.h"
#include "Components/BrushComponent.h"
#include "P3Core.h"
#include "P3World.h"

AP3QuestVolume::AP3QuestVolume()
{
	if (GetBrushComponent())
	{
		GetBrushComponent()->SetCollisionResponseToAllChannels(ECR_Ignore);
	}
}

bool AP3QuestVolume::IsLevelBoundsRelevant() const
{
	return true;
}

void AP3QuestVolume::GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const
{
	TagContainer = GameplayTagContainer;
}

void AP3QuestVolume::BeginPlay()
{
	Super::BeginPlay();

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->RegisterQuestVolume(this);
	}
}

void AP3QuestVolume::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		P3World->UnregisterQuestVolume(this);
	}

	Super::EndPlay(EndPlayReason);
}
