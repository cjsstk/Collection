// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3Backpack.h"

#include "Components/SkeletalMeshComponent.h"

#include "P3InteractableComponent.h"
#include "P3PickupableComponent.h"

AP3Backpack::AP3Backpack()
{
	SkeletalMeshComponent = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("BackpackMesh"));
	SkeletalMeshComponent->SetupAttachment(RootComponent);

	PickupableComponent = CreateDefaultSubobject<UP3PickupableComponent>(TEXT("Pickupable"));
}

void AP3Backpack::Server_SetBackpackOwnerID(charid InOwnerCharacterId)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Net_OwnerCharacterID = InOwnerCharacterId;

	Server_SetDirty(*this);
}

void AP3Backpack::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	Archive << Net_OwnerCharacterID;
}
