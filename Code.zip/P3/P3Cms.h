// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "Engine/DataTable.h"
#include "GameplayTagContainer.h"

#include "Action/P3PawnActionType.h"
#include "P3AttributesComponent.h"
#include "P3CharacterItemSlots.h"
#include "P3CmsTypes.h"
#include "P3HoldType.h"
#include "P3WeaponType.h"
#include "P3Cms.generated.h"

/** 
 * If set true, editor will always import CMS asset from csv during start-up
 * This was default behavior with google drive method
 * But currently disabled due to complexity of asset-referencing
 */

#define P3_CMS_USE_CSV_AS_SOURCE 0

UENUM(BlueprintType)
enum class EP3CharClass : uint8
{
	Invalid = 0,
	Melee = 1,
	Ranged = 2,
};

USTRUCT(BlueprintType)
struct FP3CmsCharacter : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText DisplayName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Level = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bIgnoreFlameHitAction = false;
};

USTRUCT(BlueprintType)
struct FP3CmsCharacterHair : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	FName Name;

	UPROPERTY(EditDefaultsOnly)
	USkeletalMesh* SkeletalMesh;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class UAnimInstance> AnimationBlueprintClass;

	UPROPERTY(EditDefaultsOnly)
	UMaterialInterface* Material;
};

USTRUCT(BlueprintType)
struct FP3CmsCharacterArmor : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	FName Name;

	UPROPERTY(EditDefaultsOnly)
	USkeletalMesh* SkeletalMesh;

	UPROPERTY(EditDefaultsOnly)
	TArray<UMaterialInterface*> Materials;
};

/**
 * Target Type for Combat Skill
 */
UENUM(BlueprintType)
enum class EP3CombatSkillTarget : uint8
{
	Current,
	FarthestInAggroList,
};

/**
 * Adapted Skill 용 애니메이션
 */
USTRUCT(Blueprintable)
struct FP3SkillAdaptedAnimation
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly)
	float TargetDirectionDegree = 0.0f;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UAnimMontage> AnimMontage;
};

/**
 * Adapted Skill 용 애니메이션 리스트
 */
UCLASS(Blueprintable)
class UP3SkillAdaptedAnimationSet : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	TArray<FP3SkillAdaptedAnimation> Animations;
};

/**
 * Combat Skill
 * AI 의 공격 스킬
 */
USTRUCT(Blueprintable)
struct FP3CmsCombatSkill : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	FName CmsCharacterKey;

	/** 스킬 사용 후 다음 스킬을 사용할 수 있을 때까지의 시간 */
	UPROPERTY(EditDefaultsOnly)
	float CooldownTimeSeconds = 0.0f;

	/** 애니메이션 */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimMontage> AnimMontage;

	/** Adapted 용 애니메이션 (옵션. 지정될 경우 AnimMontage 은 무시됨) */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TArray<FP3SkillAdaptedAnimation> AdaptedAnimations;

	/** 공격 거리 */
	UPROPERTY(EditDefaultsOnly, Category = "Range")
	float AttackRange = 0.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Range")
	float AttackAngleDegree = 0.0f;

	UPROPERTY(EditDefaultsOnly, Category = "Range")
	float AttackDistanceZ = 0.0f;

	/** 날뛰는 로데오 모션인가? true 일 경우 탑승자가 로데오 액션을 취함 */
	UPROPERTY(EditDefaultsOnly, Category = "Mode")
	bool bIsBucking = false;

	/** true 로 할 경우, Adapted Attack 으로 발동됨 (타겟이 정확하게 맞을 수 있게 공격 모션 중 캐릭터의 위치와 각도가 보정됨) */
	UPROPERTY(EditDefaultsOnly, Category = "Mode")
	bool bAdapted = false;

	/** true 로 할 경우, 루트 모션 이동 경로 상에 네비게이션 메시 외부가 있으면 액션을 실패시킴 */
	UPROPERTY(EditDefaultsOnly, Category = "Mode")
	bool bSafeRootMotion = false;

	/** If set > 0, given stamina will be used when this skill starts */
	UPROPERTY(EditDefaultsOnly, Category = "Stamina")
	float StaminuaConsume = 0.0f;

	/** 매달린 캐릭터의 스테미나 소모량 */
	UPROPERTY(EditDefaultsOnly, Category = "Stamina")
	float RemoveStaminaOfMountedCharacterPerSeconds = 0.0f;

	/** 더 이상 사용하지 않음. AI 가 타겟을 선택할 때 사용할 규칙 */
	UPROPERTY(EditDefaultsOnly, Category = "Target")
	EP3CombatSkillTarget Target = EP3CombatSkillTarget::Current;

	/**
	 * If set, owner character must has any of this gameplaytag to use this skill
	 */
	UPROPERTY(EditAnywhere, Category = "GameplayTags")
	FGameplayTagContainer RequiredGameplayTagsAny;

	/**
	 * If set and owner character has any of this gameplaytag, skill is not available
	 */
	UPROPERTY(EditAnywhere, Category = "GameplayTags")
	FGameplayTagContainer DisableGameplaytagsAny;

	/**
	 * 더 이상 사용하지 않음. 투사체
	 */
	UPROPERTY(EditDefaultsOnly, Category = "Projectile")
	TSoftClassPtr<class AP3Projectile> ProjectileClass;

	UPROPERTY(EditDefaultsOnly, Category = "Projectile")
	FName ProjectileLaunchSocketName;

	/**
	 * Hit Notify 시점에 Actor 를 소환함
	 */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn")
	TSoftClassPtr<class AActor> SpawnActorClass;
};

UENUM(Meta = (Bitflags))
enum class EAnimNotifyAttackDirectionFlags : int32
{
	None UMETA(Hidden),
	Left,
	Right,
	Up,
	Down,
	Pull,
	Push
};

UENUM(Blueprintable, Meta = (Bitflags))
enum class EAnimNotifyAttackStrengthFlags : uint8
{	
	Ignore,
	Small,
	Medium,
	Large,
	ExtraLarge,
	ThrowAttack
};

UENUM()
enum class EP3AnimNotifyAttackAttribute : int32
{
	Slash,
	Pierce,
	Bash,	
};

UENUM(Meta = (Bitflags))
enum class EAnimNotifyAttackPartFlags : int32
{
	Body,
	LeftHolder,
	RightHolder
};

UENUM(Blueprintable)
enum class EP3ReactionLayer : uint8
{
	None UMETA(Hidden),
	Default,
	Air,
	Dead,
	Downed,
	Climbing,
	Gliding,
	Sliding,
	Mounting,

	FrontDown,
	BackDown,

	Guard,
	CounterGuard,
	Parrying,
	CounterParrying,
};

UENUM()
enum class EP3ReactionLayerAnimationType : uint8
{
	None,
	FrontDown,
	BackDown,
	Guard,
	CrouchGuard,
	SkipFrame,
	OverlapSkipFrame,
};

UENUM(BlueprintType)
enum class EP3ReactiontDirection : uint8
{
	OffenceForward,
	OffenceBack,
	OffenceRight,
	OffenceLeft,
	DefenceForward,
	DefenceBack,
	DefenceRight,
	DefenceLeft,
	HitForward,
	HitBack,
	HitRight,
	HitLeft,
	Count			UMETA(Hidden),
};

UENUM(BlueprintType)
enum class EP3ReactionCheckAttackDirection : uint8
{
	Any,
	Front,
	Back,
};

USTRUCT(Blueprintable)
struct FP3CmsCombatHit : public FTableRowBase
{
	GENERATED_BODY()

public:
	/** 리액션 유발에 사용하는 공격 강도 설정 */
	UPROPERTY(EditAnywhere, Category = "Attack")
	EAnimNotifyAttackStrengthFlags AttackStrength = EAnimNotifyAttackStrengthFlags::Small;

	/** 리액션 유발에 사용하는 공격 방향 설정 */
	UPROPERTY(EditAnywhere, Category = "Attack")
	EAnimNotifyAttackDirectionFlags AttackDirection = EAnimNotifyAttackDirectionFlags::Left;

	/** 리액션 유발에 사용하는 공격 타입 설정 */
	UPROPERTY(EditAnywhere, Category = "Attack")
	EP3AnimNotifyAttackAttribute AttackAttribute = EP3AnimNotifyAttackAttribute::Slash;
	
	/** 공격 가능 최대 거리 설정 */
	UPROPERTY(EditAnywhere, Category = "Sweep")
	float AttackRange = 200.0f;

	/** 공격 가능 최대 각도 설정 */
	UPROPERTY(EditAnywhere, Category = "Sweep")
	float ConeHalfAngleDegree = 45.0f;

	/** 정면을 기준으로 공격 방향 설정 */
	UPROPERTY(EditAnywhere, Category = "Sweep")
	FRotator ConeRotation = FRotator::ZeroRotator;

	/** Damage Multiplier. In ‰ (1000 means 100%) (Destructible has it's own multiplier. see DamageDestructiblePermil) */
	UPROPERTY(EditAnywhere, Category = "Damage")
	int32 DamagePermil = 1000;

	/** Damage Multiplier to Destructible. In ‰ (1000 means 100%) */
	UPROPERTY(EditAnywhere, Category = "Damage")
	int32 DamageDestructiblePermil = 1000;

	/** 같은 편 공격 가능 유무 설정 */
	UPROPERTY(EditAnywhere, Category = "Damage")
	bool bCanDamageAlly = false;

	/** 리액션 테이블에 설정하는 CheckTagName과 연동하는 TagName */
	UPROPERTY(EditAnywhere, Category = "Reaction")
	FName TagName = NAME_None;

	/** 경직 기능 사용 유무 설정 */
	UPROPERTY(EditAnywhere, Category = "Reaction")
	bool bIsFrameHold = false;

	/** 공격 성공시 공격자에 사용될 카메라 흔들기 키 이름 */
	UPROPERTY(EditAnywhere, Category = "Camera")
	FName CmsCameraShakeName = NAME_None;
	
	/** 히트시 스폰하고 싶은 액터 설정 */
	UPROPERTY(EditAnywhere, Category = "Spawn")
	TSoftClassPtr<AActor> SpawnActorClass;

	/** 히트시 스폰한 액터 위치을 히트된 대상의 위치로 설정 */
	UPROPERTY(EditAnywhere, Category = "Spawn")
	bool bSpawnActorAtTarget = false;
};

USTRUCT(Blueprintable)
struct FP3CmsCookingRecipe : public FTableRowBase
{
	GENERATED_BODY()

public:
	/** Result of cooking */
	UPROPERTY(EditAnywhere, Category = "Cooking")
	TSoftClassPtr<AActor> OutcomeActorClass;

	/** Ingredients for this recipe */
	UPROPERTY(EditAnywhere, Category = "Cooking")
	TArray<TSoftClassPtr<AActor>> IngredientActorClasses;

	/** Optional. If set, player holds this actor instead of ingredient items during cooking process */
	UPROPERTY(EditAnywhere, Category = "Cooking")
	TSoftClassPtr<AActor> CookingActorClass;

	/** Set how long cook takes */
	UPROPERTY(EditAnywhere, Category = "Cooking")
	float CookingDurationSeconds = 5.0f;
};

UENUM(BlueprintType)
enum class EP3ItemCategory : uint8
{
	Potion,
	ChemicalElement,
	TempWeapon,
	Ingredient,
	Etc,
};

USTRUCT(Blueprintable)
struct FP3CmsItem : public FTableRowBase
{
	GENERATED_BODY()

public:
	/** 개발용 메모 (게임에 아무런 영향을 주지 않는 단순 관리용 목적) */
	UPROPERTY(EditDefaultsOnly)
	FString Comment;

	/** 이름 */
	UPROPERTY(EditDefaultsOnly)
	FText DisplayName;

	/** 설명 */
	UPROPERTY(EditDefaultsOnly)
	FText Description;

	/** 분류 */
	UPROPERTY(EditDefaultsOnly)
	EP3ItemCategory Category = EP3ItemCategory::Etc;

	/** 아이콘 */
	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> Icon = nullptr;

	/** 매칭되는 아이템 액터 클래스 */
	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<class AActor> ItemActorClass;

	/** 인벤토리내에 소지 한도 (0은 제한 없음) */
	UPROPERTY(EditDefaultsOnly)
	int32 MaxCountInInventory = 0;

	/** 요리 재료로 사용될 수 있는지 여부 */
	UPROPERTY(EditDefaultsOnly)
	bool bIsIngredient = false;
};

USTRUCT(Blueprintable)
struct FP3CmsQuest : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	const class UP3QuestDesc* QuestDesc;
};

USTRUCT(Blueprintable)
struct FP3ActionRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	EPawnActionType ActionType = EPawnActionType::Invalid;

	UPROPERTY(EditDefaultsOnly)
	EPawnActionCategory ActionCategory = EPawnActionCategory::Invalid;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class UP3PawnAction> ActionClass;

	/**
	 * 이전 액션 중단 규칙
	 */

	 /** 이 액션이 중단시킬 수 있는 ActionCategory, (구체적일수록, 허용보다 금지가 우선 순위가 높다) */
	UPROPERTY(EditDefaultsOnly)
	TArray<EPawnActionCategory> InterruptableTarget_ActionCategories;

	/** 이 액션이 중단시킬 수 있는 ActionType, (구체적일수록, 허용보다 금지가 우선 순위가 높다) */
	UPROPERTY(EditDefaultsOnly)
	TArray<EPawnActionType> InterruptableTarget_ActionTypes;

	/** 이 액션이 중단시킬 수 있는 MontageActionName, (구체적일수록, 허용보다 금지가 우선 순위가 높다) */
	UPROPERTY(EditDefaultsOnly)
	TArray<FName> InterruptableTarget_MontageActionNames;

	/** 이 액션이 중단시킬 수 없는 ActionCategory, (구체적일수록, 허용보다 금지가 우선 순위가 높다) */
	UPROPERTY(EditDefaultsOnly)
	TArray<EPawnActionCategory> NotInterruptableTarget_ActionCategories;

	/** 이 액션이 중단시킬 수 없는 ActionType, (구체적일수록, 허용보다 금지가 우선 순위가 높다) */
	UPROPERTY(EditDefaultsOnly)
	TArray<EPawnActionType> NotInterruptableTarget_ActionTypes;

	/** 이 액션이 중단시킬 수 없는 MontageActionName, (구체적일수록, 허용보다 금지가 우선 순위가 높다) */
	UPROPERTY(EditDefaultsOnly)
	TArray<FName> NotInterruptableTarget_MontageActionNames;
};

// DYLEE NOTE P3-3246 작업 중
// P3Character::FP3CharacterMontageActionDesc 가져옴
USTRUCT(Blueprintable)
struct FP3CharacterMontageActionRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "MontageAction")
	class UAnimMontage* AnimMontage;

	/** If set false, character is not allowed to move by it self */
	UPROPERTY(EditDefaultsOnly, Category = "MontageAction")
	bool bAllowMoveAndRotate = false;

	/** If set true, character is not allowed to move by it self */
	UPROPERTY(EditDefaultsOnly, Category = "MontageAction")
	bool bIsKnockDown = false;

	/** If set > 0, given stamina will be used when this action starts */
	UPROPERTY(EditDefaultsOnly, Category = "MontageAction")
	float StaminaConsume = 0.0f;
};

UENUM(Blueprintable)
enum class EP3ActionEdgeType : uint8
{
	Invalid,
	Allowed,
	NotAllowed
};

USTRUCT(Blueprintable)
struct FP3ActionCategoryEdgeRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	EP3ActionEdgeType EdgeType = EP3ActionEdgeType::Allowed;

	UPROPERTY(EditDefaultsOnly)
	EPawnActionCategory From = EPawnActionCategory::Invalid;

	UPROPERTY(EditDefaultsOnly)
	EPawnActionCategory To = EPawnActionCategory::Invalid;
};

USTRUCT(Blueprintable)
struct FP3ActionTypeEdgeRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	EP3ActionEdgeType EdgeType = EP3ActionEdgeType::Allowed;

	UPROPERTY(EditDefaultsOnly)
	EPawnActionType From = EPawnActionType::Invalid;

	UPROPERTY(EditDefaultsOnly)
	EPawnActionType To = EPawnActionType::Invalid;
};

USTRUCT(Blueprintable)
struct FP3ActionKeyEdgeRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	EP3ActionEdgeType EdgeType = EP3ActionEdgeType::Allowed;

	UPROPERTY(EditDefaultsOnly)
	FName From = NAME_None;

	UPROPERTY(EditDefaultsOnly)
	FName To = NAME_None;
};

// TODO: Move holdable fields to Weapon actor!

USTRUCT(Blueprintable)
struct FP3CmsHoldable : public FTableRowBase
{
	GENERATED_BODY()

public:
	/** 개발용 메모 (게임에 아무런 영향을 주지 않는 단순 관리용 목적) */
	UPROPERTY(EditDefaultsOnly)
	FString Comment;

	UPROPERTY(EditDefaultsOnly)
	int32 ItemKey;

	UPROPERTY(EditDefaultsOnly)
	TArray<EP3HoldType> HoldTypes;

	UPROPERTY(EditDefaultsOnly)
	EP3WeaponType WeaponType;

	/** If true, player can use the weapon.*/
	UPROPERTY(EditDefaultsOnly)
	bool IsPlayerUsable = true;

	/** If true, this holdable is for support(extra)*/
	UPROPERTY(EditDefaultsOnly)
	bool IsSupportHoldable = false;

	/** If -1, Player can use the weapon infinitely*/
	UPROPERTY(EditDefaultsOnly)
	int32 MaxUsableCountByPlayer = -1;

	/** Projectile class for gun */
	UPROPERTY(EditAnywhere, Category = "P3")
	TSoftClassPtr<class AP3Projectile> ProjectileClass;

	/** Muzzle socket name for gun */
	UPROPERTY(EditAnywhere, Category = "P3")
	FName MuzzleSocketName;
};

UENUM(Blueprintable)
enum class EP3ConsumableAnimType : uint8
{
	Drink,
	BlowShofar,
	SkewerEat,
	PutDownForUseItem,
	SetUpBomb,
	EquipElemental,
};

USTRUCT(Blueprintable)
struct FP3CmsConsumable : public FTableRowBase
{
	GENERATED_BODY()

public:
	/** 개발용 메모 (게임에 아무런 영향을 주지 않는 단순 관리용 목적) */
	UPROPERTY(EditDefaultsOnly)
	FString Comment;

	UPROPERTY(EditDefaultsOnly)
	int32 ItemKey;

	/** Icon texture used by UI */
	UPROPERTY(EditDefaultsOnly)
	class UTexture2D* Icon = nullptr;

	UPROPERTY(EditDefaultsOnly)
	bool bHoldItemOnConsume = false;

	UPROPERTY(EditDefaultsOnly)
	bool bDestroyHoldingItemOnUseNotify = false;

	UPROPERTY(EditDefaultsOnly)
	bool bAllowMoveInputDuringConsumeAction = true;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	EP3ConsumableAnimType AnimType = EP3ConsumableAnimType::Drink;

	/** [Optional] How much increase health point */
	UPROPERTY(EditDefaultsOnly, Category = "Heal")
	int32 HealAmount = 0;

	/** [Optional] Effect particle spawned at heal timing */
	UPROPERTY(EditDefaultsOnly, Category = "Effect")
	UParticleSystem* HealEffectParticle = nullptr;

	/** [Optional] How much increase Max stamina point */
	UPROPERTY(EditDefaultsOnly, Category = "Stamina")
	int32 MaxStaminaAmount = 0;

	/** [Optional] If set, a actor will be spawn near character */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn")
	TSubclassOf<class AActor> SpawnActorClass;

	/** [Optional] Offset for SpawnActorClass */
	UPROPERTY(EditDefaultsOnly, Category = "Spawn")
	FVector SpawnActorOffset = FVector(200, 0, -100);

	/** [Optional] If set, flag mesh will be attached to character */
	UPROPERTY(EditDefaultsOnly, Category = "Flag")
	TSubclassOf<class AActor> AttachFlagActorClass;

	/** [Optional] If set, owner will get this buff */
	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	int32 BuffKey = INVALID_BUFFKEY;
};

USTRUCT(Blueprintable)
struct FP3CmsThrowable : public FTableRowBase
{
	GENERATED_BODY()

public:
	/** 개발용 메모 (게임에 아무런 영향을 주지 않는 단순 관리용 목적) */
	UPROPERTY(EditDefaultsOnly)
	FString Comment;

	UPROPERTY(EditDefaultsOnly)
	int32 ItemKey;

	UPROPERTY(EditDefaultsOnly)
	class UTexture2D* Icon = nullptr;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<class AActor> ItemActorClass;
};

USTRUCT(Blueprintable)
struct FP3CmsInitialItem : public FTableRowBase
{
	GENERATED_BODY()

public:
	/** To give all class, select invalid */
	UPROPERTY(EditDefaultsOnly)
	EP3CharClass CharClass = EP3CharClass::Invalid;

	UPROPERTY(EditDefaultsOnly)
	EP3CharacterItemSlot Slot = EP3CharacterItemSlot::Inventory;

	UPROPERTY(EditDefaultsOnly)
	int32 ItemCmsKey;

	UPROPERTY(EditDefaultsOnly)
	int32 Stack;
};

UENUM(Blueprintable)
enum class EP3CharacterBuffImplType : uint8
{
	None,
	DamageOverTime,
	HealOverTime,
	AttributeModifier,
	RegenStamina,
	Overlappable,
	Provoke,
	Reaction,
	SummonActor
};

USTRUCT(Blueprintable)
struct FP3CmsCharacterBuffRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Buff")
	FName BuffName;

	UPROPERTY(EditAnywhere, Category = "Buff")
	EP3CharacterBuffImplType BuffImplType = EP3CharacterBuffImplType::HealOverTime;

	UPROPERTY(EditAnywhere, Category = "Buff")
	FName BuffImpleKey;

	/** Buff's life time in seconds. 0 <= means infinite */
	UPROPERTY(EditAnywhere, Category = "Buff")
	float BuffDuration = 5.0f;

	/** If set true, Start Buff anim notify state will remove buff at state finish */
	UPROPERTY(EditAnywhere, Category = "Buff")
	bool bIsChanneling = false;

	/** 전투 시 버프 해제 여부 */
	UPROPERTY(EditAnywhere, Category = "Buff")
	bool bRemoveBuffInCombatStance = false;
};

USTRUCT(Blueprintable)
struct FP3CmsDamageOverTimeBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Damage Over Time")
	float DamageAmount = 0.0f;

	UPROPERTY(EditAnywhere, Category = "Damage Over Time")
	float IntervalTimeSeconds = 0.0f;
};

USTRUCT(Blueprintable)
struct FP3CmsHealOverTimeBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Heal Over Time")
	float HealAmount = 0.0f;

	UPROPERTY(EditAnywhere, Category = "Heal Over Time")
	float HealIntervalTimeSeconds = 0.0f;
};

USTRUCT(Blueprintable)
struct FP3CmsAttributeModifierBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Attribute Modifier")
	FP3AttributeModifier Modifier;
};

UENUM(BlueprintType)
enum class EP3OverappableBuffType : uint8
{
	Scare,		// Threating
	Brace,		// Defensive Position
	BraceHard,	// Defensive Position with more strength
	Count	UMETA(Hidden)
};


USTRUCT(Blueprintable)
struct FP3CmsOverlappableBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Overlappable")
	EP3OverappableBuffType OverlappableBuffType = EP3OverappableBuffType::Scare;

	/** Strength of this buff */
	UPROPERTY(EditAnywhere, Category = "Overlappable")
	int32 BaseLevel = 1;

	/** Effect radius of this buff */
	UPROPERTY(EditAnywhere, Category = "Overlappable")
	float EffectRadius = 1000.0f;

	/** If other pawn has same buff within this radius, their buff level will add up */
	UPROPERTY(EditAnywhere, Category = "Overlappable")
	float OverlapRadius = 300;
};

USTRUCT(Blueprintable)
struct FP3CmsCharacterExperiencePoint : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly)
	FName Level;

	UPROPERTY(EditDefaultsOnly)
	int32 MaxExperiencePoint;
};

USTRUCT(Blueprintable)
struct FP3CmsRegenStaminaBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "StaminaRegen")
	float RegenAmount = 0.0f;

	UPROPERTY(EditAnywhere, Category = "StaminaRegen")
	float RegenIntervalTimeSeconds = 0.0f;
};

USTRUCT(Blueprintable)
struct FP3CmsProvokeBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Provoke")
	int32 ProvokeLevel = 1;
};

USTRUCT(Blueprintable)
struct FP3CmsReactionBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "IgnoreReaction")
	bool bCanReaction = true;
	
	UPROPERTY(EditAnywhere, Category = "IgnoreReaction")
	bool bCanDamage = true;

	UPROPERTY(EditAnywhere, Category = "OverrideReaction")
	EP3ReactionLayer OverrideReactionLayer = EP3ReactionLayer::None;

	UPROPERTY(EditAnywhere, Category = "OverrideReaction")
	EAnimNotifyAttackDirectionFlags OverrideAttackDirection = EAnimNotifyAttackDirectionFlags::None;

	UPROPERTY(EditAnywhere, Category = "OverrideReaction")
	EAnimNotifyAttackStrengthFlags OverrideAttackStrength = EAnimNotifyAttackStrengthFlags::Ignore;
};

USTRUCT(Blueprintable)
struct FP3CmsSummonBuffImplRow : public FTableRowBase
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = "Summon")
	TSoftClassPtr<class AActor> ActorClass;
};

USTRUCT(BlueprintType)
struct FCCDReaction
{
	GENERATED_BODY()

	/** CCD 적용 본의 웨이트 값 */
	UPROPERTY(EditDefaultsOnly)
	float Alpha = 0.f;

	/** CCD 적용 본의 이동 커브 */
	UPROPERTY(EditDefaultsOnly)
	class UCurveVector* CurveVector = nullptr;
};

USTRUCT(BlueprintType)
struct FRagdollReaction
{
	GENERATED_BODY()

	/** 렉돌 종료 후 뒤로 누워있을 시 일어서는 모션 */
	UPROPERTY(EditDefaultsOnly)
	UAnimMontage* BackMontage = nullptr;

	/** 렉돌 종료 후 앞으로 누워있을 시 일어서는 모션 */
	UPROPERTY(EditDefaultsOnly)	
	UAnimMontage* FrontMontage = nullptr;

	/** 렉돌 종료 후 앞뒤 판단에 사용할 Neck 본 이름 */
	UPROPERTY(EditDefaultsOnly)
	FName NeckBoneName = TEXT("Bip01-Neck");

	/** 렉돌 종료 후 앞뒤 판단에 사용할 Pelvis 본 이름 */
	UPROPERTY(EditDefaultsOnly)
	FName PelvisBoneName = TEXT("Bip01-Pelvis");

	/** 렉돌 종료 후 출력할 모션과의 스냅샷 이름 */
	UPROPERTY(EditDefaultsOnly)
	FName SnapshotName = NAME_None;

	/** 스냅샷 블랜딩 시간*/
	UPROPERTY(EditDefaultsOnly)
	float SnapshotBlendingtTimeSeconds = 0.25f;

	/** 렉돌시 땅 충돌 판단에 사용하는 높이 */
	UPROPERTY(EditDefaultsOnly)
	float Height = 97.f;	

	/** 렉돌시 잡기 어테치 허용 유무 */
	UPROPERTY(EditDefaultsOnly)
	bool bTryCatch = false;

	/** 렉돌시 잡기 어테치 허용 히트 본 이름 리스트 */
	UPROPERTY(EditDefaultsOnly, Meta = (EditCondition = "bTryCatch"))
	TArray<FName> HitBones;

	/** 렉돌시 잡기 어테치 허용할 상대 히트 본 이름 */
	UPROPERTY(EditDefaultsOnly, Meta = (EditCondition = "bTryCatch"))
	FName AttachBoneName = NAME_None;
};

USTRUCT(BlueprintType)
struct FMorpthReaction
{
	GENERATED_BODY()

	/** 모프타켓 동작 시킬 본 리스트 이름 */
	UPROPERTY(EditDefaultsOnly)
	TArray<FName> MorpthName;

	/** 모프타켓 동작 시 본 웨이트 커브 */
	UPROPERTY(EditDefaultsOnly)
	UCurveFloat* MorpthCurve = nullptr;
};

USTRUCT(BlueprintType)
struct FPhysicsBlendBone
{
	GENERATED_BODY()

	/** 힘을 줄 본 이름과 가중치 */
	UPROPERTY(EditDefaultsOnly)
	TMap<FName, float> PhysicsBlendBoneWeight;	
};

USTRUCT(BlueprintType)
struct FFXReaction
{
	GENERATED_BODY()

	/** 출력시킬 파티클 에셋 */
	UPROPERTY(EditDefaultsOnly, Category = FX)
	class UParticleSystem* HitParticle = nullptr;

	/** 파티클 초기 생성 위치 */
	UPROPERTY(EditDefaultsOnly, Category = FX)
	FVector SpawnLocationOffset = FVector::ZeroVector;

	/** 파티클 초기 생성 방향 */
	UPROPERTY(EditDefaultsOnly, Category = FX)
	FRotator SpawnRotation = FRotator::ZeroRotator;

	/** 파티클 초기 생성 스케일 */
	UPROPERTY(EditDefaultsOnly, Category = FX)
	FVector SpawnScale = FVector::OneVector;

	/** 충돌 방향으로 FX 자동 회전 유무 */
	UPROPERTY(EditDefaultsOnly, Category = FX)
	bool bImpactRotation = true;

	/** 히트 사운드 에셋 */
	UPROPERTY(EditDefaultsOnly, Category = Sound)
	class USoundBase* HitSound = nullptr;

	/** 히트 사운드 볼륨 크기 비율 */
	UPROPERTY(EditDefaultsOnly, Category = Sound)
	float VolumeMultiplier = 1.f;

	/** 히트 사운드 볼륨 피치 비율 */
	UPROPERTY(EditDefaultsOnly, Category = Sound)
	float PitchMultiplier = 1.f;

	/** 히트 사운드 시작 위치 */
	UPROPERTY(EditDefaultsOnly, Category = Sound)
	float StartTimeSeconds = 0.f;
};

USTRUCT(Blueprintable)
struct FP3CombatReactionRow : public FTableRowBase
{
	GENERATED_BODY()

	/** 리액션 이름 */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName ReactionName = NAME_None;

	/** 같은 팀의 데미지도 리액션으로 처리 유무 */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	bool bCanDamageAlly = false;

	/** 노티파이에 설정한 시그널 이름 구간에만 동작 */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName CheckSingalName = NAME_None;

	/** Hit CMS에 설정한 TagName에 동작 */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName CheckTagName = NAME_None;

	/** 히트 대상과의 상대적 방향 */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	EP3ReactionCheckAttackDirection CheckAttackDirection = EP3ReactionCheckAttackDirection::Any;

	/** 공격자의 Hit CMS에 설정한 공격 강도 */
	UPROPERTY(EditDefaultsOnly, Category = CMS, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackStrengthFlags"))
	int32 AttackStrengthFlags = 0;	

	/** 공격자의 Hit CMS에 설정한 공격 방향 */
	UPROPERTY(EditDefaultsOnly, Category = CMS, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackDirectionFlags"))
	int32 AttackDirectionFlags = 0;

	/** 타격된 파츠 */
	UPROPERTY(EditDefaultsOnly, Category = CMS, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackPartFlags"))
	int32 AttackPartFlags = 1;

	/** 리액션 출력 에니메이션 */
	UPROPERTY(EditDefaultsOnly, Category = Animation)
	UAnimMontage* Montage = nullptr;

	/** CCD 사용할 본 이름과 웨이트 정보 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationCCD)
	TMap<FName, FCCDReaction> CCDAlpha;

	/** CCD 적용 거리 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationCCD)
	float CCDResponseDist = 0.f;

	/** CCD 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationCCD)
	float CCDDurationSeconds = 0.f;

	/** 포즈 에셋에 사용할 본 이름과 알파값 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationPoseAsset)
	TMap<FName, float> PoseAsset;

	/** 포즈 에셋에 본에 적용할 이동 커브 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationPoseAsset)
	UCurveFloat* PoseAssetCurve = nullptr;

	/** 포즈 에셋 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationPoseAsset)
	float PoseAssetDurationSeconds = 0.f;

	/** 렉돌 셋팅 정보 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationRagdoll)
	FRagdollReaction Ragdoll;

	/** 렉돌 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationRagdoll)
	float RagdollDurationSeconds = 0.f;

	/** 모프 타켓 본 이름과 정보 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationMorpth)
	TMap<FName, FMorpthReaction> Morpth;

	/** 모프 타켓 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationMorpth)
	float MorpthDurationSeconds = 0.f;

	/** 경직 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationHold)
	float FrameHoldDurationSeconds = 0.25f;

	/** 경직 메쉬 흔들기 유무 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationHold)
	bool bMeshShake = true;
		
	/** 공격자만 경직 유무 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationHold)
	bool bAttackerFrameHoldOnly = false;

	/** 경직시 흔들리는 강도 */
	UPROPERTY(EditDefaultsOnly, Category = AnimationHold)
	float MeshShakeStrength = 800.f;

	/** 리액션 발동시에 데미지 가감율 */
	UPROPERTY(EditDefaultsOnly, Category = Damage)
	float DamageRatio = 1.f;

	/** 공격대상을 바라볼 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	bool bHitRotator = false;

	/** 델타 커브 이동시 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float DeltaMoveDurationSeconds = 0.f;

	/** 델타 커브 이동후 땅에 충돌후 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float DownDurationSeconds = 0.f;

	/** 델타 커브 이동 커브 에셋 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	UCurveVector* DeltaMoveCurve = nullptr;

	/** 델타 커브 이동후 땅에 충돌후 추가 이동 커브 에셋 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	UCurveVector* FallingOnGroundDeltaMoveCurve = nullptr;

	/** 델타 커브 동작중 공중 상태 후 땅 충돌 시 출력할 섹션 이름 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	FName FallingOnGroundSectionName = NAME_None;

	/** 델타 커브 종료후에 땅에 붙어 있는 경우 출력할 섹션 이름 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	FName StoppingOnGroundSectonName = NAME_None;

	/** 델타 커브 이동후 땅에 충돌하고 DownDurationSeconds 후에 출력할 섹션 이름 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	FName StandingOnGroundSectonName = NAME_None;

	/** 바라보고 싶은 방향 설정 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	EP3ReactiontDirection ReactiontDirection = EP3ReactiontDirection::DefenceBack;

	/** 이동 속도 변경 비율 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float MoveSpeedMultiplier = 1.f;

	/** 이동 시키고 싶은 강도. EP3ReactiontDirection 방향으로 이동 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float ImpulseStrength = 0.f;

	/** 이동 시키고 싶은 2차원 강도. EP3ReactiontDirection 방향으로 이동 */
	UPROPERTY(EditDefaultsOnly, Category = Movement)
	float ImpulseStrength2D = 0.f;

	/** MeshImpulseStrength 설정시 영향받을 본과 웨이트 */
	UPROPERTY(EditDefaultsOnly, Category = Mesh)
	TMap<FName, FPhysicsBlendBone> PhysicsBlendBone;

	/** MeshImpulseStrength 설정시 유지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = Mesh)
	float PhysicsBlendBoneDurationSeconds = 0.f;

	/** PhysicsBlendBone 설정한 본에 적용할 강도 */
	UPROPERTY(EditDefaultsOnly, Category = Mesh)
	float MeshImpulseStrength = 0.f;

	/** PhysicsBlendBone 설정한 본에 적용할 2차원 강도 */
	UPROPERTY(EditDefaultsOnly, Category = Mesh)
	float MeshImpulseStrength2D = 0.f;

	/** PhysicsBlendBone 설정한 본에 적용할 방향 */
	UPROPERTY(EditDefaultsOnly, Category = Mesh)
	EP3ReactiontDirection MeshImpulsetDirection = EP3ReactiontDirection::DefenceBack;

	/** 가드 상태일시 가드 깰 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool bBreakGuard = false;

	/** 앉기 가드 상태일시 가드 깰 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool bBreakCrounchGuard = false;

	/** 소비시킬 스테미너 양 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	float StaminaAmount = 0.f;

	/** 왼쪽 파츠을 떨어트릴 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool bDropLeftHandHoldable = false;

	/** 오른쪽 파츠을 떨어트릴 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool bDropRightHandHoldable = false;

	/** 무엇인가 들고 있다면 떨어트릴 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	bool bDropPickable = true;

	/** 떨어트리고 싶은 강도 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	float DropImpulseSize = 0.f;

	/** 떨어트리고 삭제되기 까지 시간 */
	UPROPERTY(EditDefaultsOnly, Category = Status)
	float DropHoldableItemLifeSpan = 30.f;

	/** 리액션 발동시 출력시킬 FX 설정 */
	UPROPERTY(EditDefaultsOnly, Category = FX)
	TMap<EP3AnimNotifyAttackAttribute, FFXReaction> VFX;

	/** 리액션 발동시 출력시킬 카메라 쉐이크 키 */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	FName CmsReactionCameraShakeKey = NAME_None;

	/** 리액션은 발동하지 않지만 데미지만 발동시 카메라 쉐이크 키 */
	UPROPERTY(EditDefaultsOnly, Category = Camera)
	FName CmsDamageCameraShakeKey = NAME_None;

	/** 모션 설정이 없지만 현 진행 액션을 강제로 중단 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Action)
	bool bForceStopAction = false;
};

USTRUCT(Blueprintable)
struct FP3CombatReactionOverlapRuleRow : public FTableRowBase
{
	GENERATED_BODY()

	/** 체크 할 히트 카운트 MIN/MAX 설정 */
	UPROPERTY(EditDefaultsOnly, Category = Condition)
	FVector2D OverlapRange = FVector2D::ZeroVector;

	/** 현재 진행중인 레이어 */
	UPROPERTY(EditDefaultsOnly, Category = Condition)
	EP3ReactionLayer InProgressLayer = EP3ReactionLayer::None;

	/** 중복 체크 하고 싶은 공격자와의 상대적 방향  */
	UPROPERTY(EditDefaultsOnly, Category = Condition)
	EP3ReactionCheckAttackDirection CheckAttackDirection = EP3ReactionCheckAttackDirection::Any;

	/** 추가로 발동된 공격 강도  */
	UPROPERTY(EditDefaultsOnly, Category = Condition, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackStrengthFlags"))
	int32 StartAttackStrengthFlags = 0;

	/** 현재 발동중인 공격 강도  */
	UPROPERTY(EditDefaultsOnly, Category = Condition, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackStrengthFlags"))
	int32 InProgressAttackStrengthFlags = 0;

	/** 추가로 발동된 공격 방향  */
	UPROPERTY(EditDefaultsOnly, Category = Condition, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackDirectionFlags"))
	int32 StartAttackDirectionFlags = 0;

	/** 현재 발동중인 공격 방향  */
	UPROPERTY(EditDefaultsOnly, Category = Condition, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackDirectionFlags"))
	int32 InProgressAttackDirectionFlags = 0;

	/** 현재 발동중인 파츠 */
	UPROPERTY(EditDefaultsOnly, Category = Condition, Meta = (Bitmask, BitmaskEnum = "EAnimNotifyAttackPartFlags"))
	int32 StartAttackPartFlags = 1;

	/** 추가로 발동된 리액션 이름 */
	UPROPERTY(EditDefaultsOnly, Category = Condition)
	FName StartReactionName = NAME_None;

	/** 현재 발동중인 리액션 이름 */
	UPROPERTY(EditDefaultsOnly, Category = Condition)
	FName InProgressReactionName = NAME_None;

	/** 조건이 맞으면 중복 출력 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Reaction)
	bool bSkipReaction = false;

	/** 조건이 맞으면 실행시킬 리액션 이름 */
	UPROPERTY(EditDefaultsOnly, Category = Reaction, Meta = (EditCondition = "!bSkipReaction"))
	FName OverrideReactionName = NAME_None;

	/** 조건이 맞으면 누적하여 증가시킬 몽타주 시작 위치 */
	UPROPERTY(EditDefaultsOnly, Category = Animation, Meta = (EditCondition = "!bSkipReaction"))
	float IncrememtStartMontagePosition = 0.f;

	/** 조건이 맞으면 누적하여 증가시킬 몽타주 시작 속도 */
	UPROPERTY(EditDefaultsOnly, Category = Animation, Meta = (EditCondition = "!bSkipReaction"))
	float IncrememtStartMontagePlayRate = 0.f;	

	/** 노티파이에 EP3ReactionLayerAnimationType::SkipFrame구간이 되면 리액션 스킵 유무 */
	UPROPERTY(EditDefaultsOnly, Category = Animation, Meta = (EditCondition = "!bSkipReaction"))
	bool bSkipMontageFrame = false;
};

USTRUCT(Blueprintable)
struct FP3CmsCameraShakeRow : public FTableRowBase
{
	GENERATED_BODY()

	/** If true, play only local character */
	UPROPERTY(EditDefaultsOnly)
	bool bStandaloneLocalPlay = false;

	/** Shake scale value by distance */
	UPROPERTY(EditDefaultsOnly, Meta = (EditCondition = "!bStandaloneLocalPlay"))
	UCurveFloat* CurveDistanceScale = nullptr;
	
	/** Camera shake asset */
	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<class UCameraShake> CameraShakeClass;
};

namespace P3Cms
{
	bool IsLoaded();
	void Initialize();
	void Reload();
	void Shutdown();

	TArray<const FP3CmsCombatSkill*> GetCharacterCombatSkills(FName CmsCharacterKey);
	const FP3CmsCombatHit* GetCombatHit(FName CmsCombatHitKey);
	const FP3CmsCombatHit& GetCombatHitOrDummy(FName CmsCombatHitKey);
	FName FindCookingRecipeKeyWithIngredient(const TArray<AActor*>& IngredientActors);
	const FP3CmsCookingRecipe* GetCookingRecipe(const FName& RecipeKey);
	const FP3CmsItem& GetItem(itemkey ItemKey);
	itemkey GetItemKeyFromActorClass(const UClass* ActorClass);
	UClass* GetActorClassFromItemKey(itemkey ItemKey);
	const FP3CmsQuest& GetQuest(questkey QuestKey);
	questkey GetQuestKeyFromQuestDesc(const UP3QuestDesc* QuestDesc);
	const UP3QuestDesc* GetQuestDescFromQuestKey(questkey QuestKey);
	const FP3CmsHoldable* GetItemHoldable(itemkey ItemKey);
	const FP3CmsConsumable* GetItemConsumable(itemkey ItemKey);
	const FP3CmsThrowable* GetItemThrowable(itemkey ItemKey);
	TArray<const FP3CmsInitialItem*> GetInitialItems(EP3CharClass CharClass);
	const FP3CmsCharacterBuffRow* GetCharacterBuff(int32 CmsCharacterBuffKey);
	const FP3CmsHealOverTimeBuffImplRow* GetHealOverTimeBuffImpl(FName CmsHealOverTimeBuffKey);
	const FP3CmsDamageOverTimeBuffImplRow* GetDamageOverTimeBuffImpl(FName CmsDamageOverTimeBuffKey);
	const FP3CmsAttributeModifierBuffImplRow* GetAttributeModifierBuffImpl(FName CmsAttributeModifierBuffKey);
	const FP3CmsOverlappableBuffImplRow* GetOverlappableBuffImpl(FName CmsOverlappableBuffKey);
	const FP3CmsCharacter* GetCharacter(const FName& CmsCharacterKey);
	const FP3CmsCharacterExperiencePoint* GetCharacterExperiencePoint(int32 CharLevelKey);
	const FP3CmsRegenStaminaBuffImplRow* GetRegenStaminaBuffImpl(FName CmsRegenStaminaBuffKey);
	const FP3CmsProvokeBuffImplRow* GetProvokeBuffImpl(FName CmsProvokeBuffKey);
	const FP3CmsReactionBuffImplRow* GetReactionBuffImpl(FName CmsReactionBuffKey);
	const FP3CmsSummonBuffImplRow* GetSummonBuffImpl(FName CmsSummonBuffKey);
	const FP3CmsCameraShakeRow* GetCameraShake(FName CmsCameraShakeKey);

	const UDataTable* GetCharacterHairTable();
	const UDataTable* GetCharacterArmorTable();

	// Used for commandlet
	TArray<UScriptStruct*> GetAllRowStructs();
};

UCLASS()
class UP3CmsData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "Character")
	UDataTable* Characters;

	UPROPERTY(EditDefaultsOnly, Category = "Character")
	UDataTable* CharacterHairs;

	UPROPERTY(EditDefaultsOnly, Category = "Character")
	UDataTable* CharacterArmors;

	UPROPERTY(EditDefaultsOnly, Category = "Character")
	UDataTable* CharacterExperiencePoints;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* InitialItems;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* CookingRecipes;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* Holdables;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* Consumables;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* Throwables;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* Items;

	UPROPERTY(EditDefaultsOnly, Category = "Quest")
	UDataTable* Quests;
	
	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UDataTable* CombatHits;

	UPROPERTY(EditDefaultsOnly, Category = "Combat")
	UDataTable* CombatSkills;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* CharacterBuffs;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* DamageOverTimeBuffImpls;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* HealOverTimeBuffImpls;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* AttributeModifierBuffImples;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* OverlappableBuffImples;
	
	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* RegenStaminaBuffImpls;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* ProvokeBuffImpls;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* ReactionBuffImpls;

	UPROPERTY(EditDefaultsOnly, Category = "Combat|Buff")
	UDataTable* SummonBuffImpls;

	UPROPERTY(EditDefaultsOnly, Category = "FX")
	UDataTable* CameraShakes;
};


UCLASS(Blueprintable)
class UP3Cms : public UObject
{
	GENERATED_BODY()

public:
	void InitCms();

	void LoadDataTables();
	void UpdateDerivedCaches();

	UPROPERTY(EditDefaultsOnly, Transient)
	UP3CmsData* CmsData;

	/**
	 * 파생 캐시 데이터
	 */
	TMap<itemkey, TSoftClassPtr<AActor>> ItemKeyToActorClass;
	TMap<TSoftClassPtr<AActor>, itemkey> ActorClassToItemKey;
	TMap<questkey, const UP3QuestDesc*> QuestKeyToQuestDesc;
	TMap<const UP3QuestDesc*, questkey> QuestDescToQuestKey;
};
