// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Volume.h"
#include "GameplayTagAssetInterface.h"
#include "P3QuestVolume.generated.h"

/**
 * ZoneVolume + GameplayTag
 */
UCLASS()
class P3_API AP3QuestVolume : public AVolume, public IGameplayTagAssetInterface
{
	GENERATED_BODY()

public:
	AP3QuestVolume();

	virtual bool IsLevelBoundsRelevant() const override;

	/** IGameplayTagAssetInterface */
	virtual void GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const override;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UPROPERTY(EditAnywhere, Category = "P3Quest")
	FGameplayTagContainer GameplayTagContainer;
};
