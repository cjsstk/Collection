// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "P3CharacterEffectTypes.generated.h"

UENUM()
enum class EP3MoveSpeedEffectLayer
{
	Swamp,
	Count	UMETA(Hidden)
};

UENUM()
enum class EP3CharacterEffectTypes
{
	Swamp,			// Can't swim. Can't go up and down. Buoyancy is reduced so character will be submerged
	FarSight,
	Slow,			// Movement speed is reduced by 50%
	Entangle,		// Movement is not available. Any action is not available. (Like stun, but different animation)
	RoarStun,		// Movement is not available. Any action is not available. (Like stun, but different animation)
	Stun,			// Movement is not available. Any action is not available.
	Count	UMETA(Hidden)
};
