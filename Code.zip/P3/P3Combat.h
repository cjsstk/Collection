// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Action/P3PawnAction.h"
#include "P3Cms.h"
#include "P3CharacterEffectComponent.h"
#include "P3HealthChangeReason.h"
#include "P3PartComponent.h"
#include "P3TemporaryWeaponType.h"
#include "P3WeaponType.h"

enum class EP3GiveDamageResult
{
	NoEffect,
	HitAction,
	Blocked,
	Immediate,
};

class UP3Command;
class UP3HealthPointComponent;
class UP3PawnAction;
class AP3Character;
class AP3Projectile;

namespace P3Combat
{
	struct FDamageActorParams
	{
		FDamageActorParams(AActor& InSourceActor, AActor& InTargetActor)
			: SourceActor(InSourceActor)
			, TargetActor(InTargetActor)
		{
		}

		AActor& SourceActor;
		AActor& TargetActor;

		EAnimNotifyAttackStrengthFlags AttackStrength = EAnimNotifyAttackStrengthFlags::Small;				
		EAnimNotifyAttackDirectionFlags AttackDirection = EAnimNotifyAttackDirectionFlags::Left;
		EP3AnimNotifyAttackAttribute AttackAttribute = EP3AnimNotifyAttackAttribute::Slash;

		FName TagName = NAME_None;
		UPrimitiveComponent* TargetComponent = nullptr;
		EP3WeaponType WeaponType = EP3WeaponType::None;
		FVector ImpactDirection = FVector::ZeroVector;
		FName BoneName = NAME_None;
		FName AttackBoneName = NAME_None;
		int32 TrueDamage = 0;				// this damage applys to target without considering any attributes
		int32 DamagePermil = 1000;
		int32 DamageDestructiblePermil = 1000;
		int32 AllyDamagePermil = 1000;
		bool bCanDamageAlly = false;		
		bool bIsFrameHold = false;
		FName CmsCombatHitKey = NAME_None;
		FName CmsCameraShakeKey = NAME_None;
		FVector ThrowAwayVelocity = FVector::ZeroVector;
		
		/** Optional */
		int32 TargetHitItemIndex = -1;
		const AP3Projectile* Projectile = nullptr;
		const FVector* HitLocation = nullptr;
		EP3TemporaryWeaponType TemporaryWeaponType = EP3TemporaryWeaponType::None;
		EP3HealthChangeReason Reason = EP3HealthChangeReason::Unknown;
	};

	struct FPartDamageParams
	{		
		int32 PartIndex = -1;
		float PartDamageMultiplier = 1.0f;

		bool bIsCriticalPart = false;
		bool bIsArmorPart = false;
		bool bIgnoreArmor = false;

		class UP3PartComponent* PartComponent = nullptr;
	};

	void Server_Explode(AActor& SourceActor, const FVector& Location, float Radius, float Damage, int32 AllyDamagePermil, float ImpulseVelocity, bool bKnockDown, float KnockDownDurationSeconds, const TArray<AActor*>& IgnoreActors);

	EP3GiveDamageResult Server_DamageActor(const FDamageActorParams& Params);
	EP3GiveDamageResult Server_DamageActor(AP3Character* TargetCharacter, EP3ReactionLayer ReactionLayer);	

	bool ChangeActorHealth(AActor* SourceActor, AActor& TargetActor, int32 Amount, EP3HealthChangeReason Reason);
	bool ChangeActorHealth(AActor* SourceActor, AP3Character& TargetCharacter, int32 Amount, EP3HealthChangeReason Reason);
	bool ChangeActorHealth(AActor* SourceActor, UP3HealthPointComponent& HealthComp, int32 Amount, EP3HealthChangeReason Reason);

	EP3ReactionLayer Server_GetCharacterTargetReactionLayer(const FDamageActorParams& Params, AP3Character* TargetCharacter);
	const FP3CombatReactionRow* Server_GetCharacterTargetReactionCms(EP3ReactionLayer ReactionLayer, const FDamageActorParams& Params, AP3Character* TargetCharacter, EAnimNotifyAttackDirectionFlags AttackDirection, EAnimNotifyAttackStrengthFlags AttackStrength, EAnimNotifyAttackPartFlags AttackPart);
	const FP3CombatReactionRow* Server_GetCharacterTargetReactionCms(EP3ReactionLayer ReactionLayer, AP3Character* TargetCharacter);
	const FP3CombatReactionRow* Server_GetCharacterTargetOverlapReactionCms(EP3ReactionLayer ReactionLayer, AP3Character* TargetCharacter, const FName& ReactionName);
	bool Server_GetCharacterTargetReactionOverrideBuffer(AP3Character* TargetCharacter, FP3CharacterBuff& CharacterBuff);
	bool Server_CheckAttackDirection(EP3ReactionCheckAttackDirection CheckAttackDirection, const FVector& SourceActorLocation, AP3Character* TargetCharacter);

	bool Server_CharacterTargetReaction(EP3ReactionLayer ReactionLayer, const FP3CombatReactionRow* ReactionRow, const FDamageActorParams& Params, AP3Character* TargetCharacter, EAnimNotifyAttackPartFlags AttackPart);
	bool Server_CharacterTargetVFX(EP3ReactionLayer ReactionLayer, const FP3CombatReactionRow* ReactionRow, const FVector* HitLocation, const FVector& ImpactDirection, EP3AnimNotifyAttackAttribute AttackAttribute, AP3Character* TargetCharacter);
	const FP3CombatReactionRow* Server_CharacterSourceReaction(EP3ReactionLayer& ReactionLayer, const FDamageActorParams& Params, AP3Character* SourceCharacter);
	const FP3CombatReactionRow* Server_GetCharacterTargetReactionOverlapRule(EP3ReactionLayer ReactionLayer, const FP3CombatReactionRow* ReactionRow, FP3PawnActionStartRequestParams& RequestParams, const FVector& SourceActorLocation,
		EAnimNotifyAttackStrengthFlags AttackStrength, EAnimNotifyAttackDirectionFlags AttackDirection, EAnimNotifyAttackPartFlags AttackPart, AP3Character* TargetCharacter);

	void Server_GetTargetPartDamageParam(FPartDamageParams& DamageParams, const FDamageActorParams& Params, AP3Character* TargetCharacter);	
	bool Server_CanStartAction(const FP3CombatReactionRow* ReactionRow);
	bool Server_CanStartCommand(const FP3CombatReactionRow* ReactionRow, EP3ReactionLayer ReactionLayer);

	void Multicast_ApplyDamageByCommand(AActor& TargetActor, AActor* SourceActor, int32 Damage, int32 PartIndex, EP3WeaponType WeaponType, EP3HealthChangeReason Reason, const UP3Command& Command);
	AActor* FindTargetInRange(const AP3Character& MyCharacter, float Range, bool bFrontOnly);
	AActor* FindTargetForAI(const AP3Character& MyCharacter, float SearchRange, bool bSearchFrontOnly, float AggroRangeLimit);

} // P3Combat

