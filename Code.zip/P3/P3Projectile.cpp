// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3Projectile.h"

#include "ContentStreaming.h"
#include "Components/SphereComponent.h"
#include "DrawDebugHelpers.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "GameFramework/WorldSettings.h"
#include "Kismet/GameplayStatics.h"
#include "Particles/ParticleSystemComponent.h"

#include "P3Character.h"
#include "P3Core.h"
#include "P3Combat.h"
#include "P3GameMode.h"
#include "P3GameState.h"
#include "P3Physics.h"
#include "P3World.h"

static TAutoConsoleVariable<int32> CVarP3ProjectileDebug(
	TEXT("p3.projectileDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

AP3Projectile::AP3Projectile()
{
	// Use a sphere as a simple collision representation
	CollisionComp = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComp"));
	CollisionComp->InitSphereRadius(5.0f);
	CollisionComp->SetCollisionProfileName(TEXT("Projectile"));
	CollisionComp->SetWalkableSlopeOverride(FWalkableSlopeOverride(WalkableSlope_Unwalkable, 0.f));
	CollisionComp->SetCanEverAffectNavigation(false);
	CollisionComp->CanCharacterStepUpOn = ECB_No;

	// Set as root component
	RootComponent = CollisionComp;

	// Use a ProjectileMovementComponent to govern this projectile's movement
	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileComp"));
	ProjectileMovement->UpdatedComponent = CollisionComp;
	ProjectileMovement->InitialSpeed = 3000.f;
	ProjectileMovement->MaxSpeed = 3000.f;
	ProjectileMovement->bRotationFollowsVelocity = true;
	ProjectileMovement->bShouldBounce = false;
	ProjectileMovement->MoveComponentFlags |= MOVECOMP_IgnoreBases;

	// Die after 30 seconds by default
	InitialLifeSpan = 30.0f;

	//bReplicates = true;
	bReplicateMovement = true;

	GetRootComponent()->SetAbsolute(true, true, true);
}

void AP3Projectile::BeginPlay()
{
	Super::BeginPlay();

	if (GIsClient && LaunchSound)
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), LaunchSound, GetActorLocation());
	}

	if (GIsClient && TrailParticle)
	{
		TrailParticleComponent = NewObject<UParticleSystemComponent>(P3Core::GetP3WorldParticleActor(this));
		if (TrailParticleComponent)
		{
			TrailParticleComponent->SetTemplate(TrailParticle);
			TrailParticleComponent->SetRelativeTransform(TrailParticleTransform);
			TrailParticleComponent->AttachToComponent(GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
			TrailParticleComponent->bAutoDestroy = true;

			TrailParticleComponent->RegisterComponentWithWorld(GetWorld());
			TrailParticleComponent->ActivateSystem(true);

			// Notify the texture streamer so that PSC gets managed as a dynamic component.
			IStreamingManager::Get().NotifyPrimitiveUpdated(TrailParticleComponent);
		}
	}
}

void AP3Projectile::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (IsRotating())
	{
		AddActorLocalRotation(DeltaTime * RotatingAnglePerSecond);
	}
}

void AP3Projectile::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (TrailParticleComponent)
	{
		TrailParticleComponent->DeactivateSystem();
	}
}

void AP3Projectile::BeginDestroy()
{
	if (TrailParticleComponent && !TrailParticleComponent->IsBeingDestroyed())
	{
		TrailParticleComponent->DestroyComponent();
		TrailParticleComponent = nullptr;
	}

	Super::BeginDestroy();
}

void AP3Projectile::Server_SetSourceCharacter(class AP3Character* InSourceCharacter)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Server_SourceCharacter = InSourceCharacter;

	UPrimitiveComponent* PrimitiveComp = Cast<UPrimitiveComponent>(GetRootComponent());

	if (PrimitiveComp && Server_SourceCharacter)
	{
		/** TODO This part is temporary. We have to make new functions for restoring physics later.*/
		TArray<AActor*> ChildActors;
		Server_SourceCharacter->GetAttachedActors(ChildActors);

		PrimitiveComp->IgnoreActorWhenMoving(Server_SourceCharacter, true);
		for (AActor* Actor : ChildActors)
		{
			PrimitiveComp->IgnoreActorWhenMoving(Actor, true);
		}

		// You need to attach to source to make 'MOVECOMP_IgnoreBases' works
		PrimitiveComp->AttachToComponent(Server_SourceCharacter->GetRootComponent(), FAttachmentTransformRules::KeepWorldTransform);
	}
}

void AP3Projectile::Server_SetWeaponActor(AActor* InWeaponActor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	Net_WeaponActor = InWeaponActor;
}

void AP3Projectile::NotifyHit(class UPrimitiveComponent* MyComp, AActor* OtherActor, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult& Hit)
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_OnHit(MyComp, OtherActor, OtherComp, bSelfMoved, HitLocation, HitNormal, NormalImpulse, Hit);
	}
}

void AP3Projectile::Server_OnHit(class UPrimitiveComponent* MyComp, AActor * OtherActor, class UPrimitiveComponent* OtherComp, bool bSelfMoved, FVector HitLocation, FVector HitNormal, FVector NormalImpulse, const FHitResult & Hit)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3ProjectileDebug.GetValueOnGameThread() != 0)
	{
		DrawDebugCrosshairs(GetWorld(), Hit.Location, GetActorRotation(), 100.0f, FColor::Red, false, 3.0f, 0);
	}
#endif

	if (OtherActor && (OtherActor == this || OtherActor == Server_SourceCharacter || OtherActor == Net_WeaponActor))
	{
		return;
	}

	AP3Projectile* OtherProjectile = Cast<AP3Projectile>(OtherActor);
	if (OtherProjectile && OtherProjectile->Net_WeaponActor == Net_WeaponActor)
	{
		// Ignore if we are born from same gun(like shot gun)
		return;
	}

	UP3World* World = P3Core::GetP3World(*this);
	check(World);

	ensure(GetActorId() != INVALID_ACTORID);

	FNetProjectileHit NetParams;
	NetParams.HitLocation = HitLocation;
	NetParams.HitNormal = HitNormal;
	NetParams.TargetActorId = Cast<const IP3ActorInterface>(OtherActor) ? World->GetActorIdFromActor(OtherActor) : INVALID_ACTORID;
	NetParams.BoneName = Hit.BoneName;
	
	ProcessProjectileHit(NetParams.TargetActorId, NetParams.HitLocation, NetParams.HitNormal, NetParams.BoneName);

	if (P3Core::IsP3NetModeStandalone(*this))
	{
		Client_OnHit(NetParams.TargetActorId, NetParams.HitLocation, NetParams.HitNormal, NetParams.BoneName);
	}

	World->Server_MulticastPacketReliable(this, GetActorId(), GetOwner(), NetParams, EP3NetComponentType::None, &AP3Projectile::Client_HandleHit);
	
	AActor* SourceActor = Server_SourceCharacter;
	if (!Server_SourceCharacter)
	{
		if (Instigator)
		{
			SourceActor = Instigator;
		}
		else
		{
			// TODO Prepare a situation when the source character is disappeared
			SourceActor = this;
		}
	}

	const FP3CmsCombatHit* CmsCombatHit = P3Cms::GetCombatHit(CmsCombatHitKey);

	if (AreaDamageRadius > 0)
	{
		const FVector& MyLocation = GetActorLocation();

		FCollisionShape CollisionShape;
		CollisionShape.SetSphere(AreaDamageRadius);

		FCollisionQueryParams QueryParams;
		QueryParams.AddIgnoredActor(this);
		QueryParams.AddIgnoredActor(Instigator);

		TArray<FOverlapResult> OverlapResults;
		GetWorld()->OverlapMultiByChannel(OverlapResults, Hit.Location, FQuat::Identity, ECC_COMBAT, CollisionShape, QueryParams);

		TArray<AActor*, TInlineAllocator<12>> ProcessedActors;

		for (const FOverlapResult& Result : OverlapResults)
		{
			AActor* TargetActor = Result.GetActor();
			if (TargetActor && !ProcessedActors.Contains(TargetActor))
			{
				// See if explosion reach target
				{
					FCollisionQueryParams RayQueryParams;
					RayQueryParams.AddIgnoredActor(this);
					RayQueryParams.AddIgnoredActor(Instigator);
					RayQueryParams.AddIgnoredActor(TargetActor);					

					TArray<AActor*> TargetChildActors;
					TargetActor->GetAllChildActors(TargetChildActors);
					RayQueryParams.AddIgnoredActors(TargetChildActors);

					TArray<AActor*> TargetAttachedActors;
					TargetActor->GetAttachedActors(TargetAttachedActors);
					RayQueryParams.AddIgnoredActors(TargetAttachedActors);

					FHitResult HitResult;
					const bool bHit = GetWorld()->LineTraceSingleByChannel(HitResult, MyLocation, TargetActor->GetActorLocation(), ECC_PROJECTILE, RayQueryParams);

					if (bHit)
					{
						continue;
					}
				}

				ProcessedActors.Add(TargetActor);

				P3Combat::FDamageActorParams DamageParams(*SourceActor, *TargetActor);

				DamageParams.TargetComponent = Result.GetComponent();
				DamageParams.TargetHitItemIndex = Result.ItemIndex;
				DamageParams.WeaponType = EP3WeaponType::Gun;
				DamageParams.ImpactDirection = (TargetActor->GetActorLocation() - Hit.Location).GetSafeNormal();
				DamageParams.BoneName = Hit.BoneName;
				DamageParams.Projectile = this;
				DamageParams.HitLocation = &HitLocation;

				if (CmsCombatHit)
				{
					DamageParams.AttackStrength = CmsCombatHit->AttackStrength;
					DamageParams.AttackDirection = CmsCombatHit->AttackDirection;
					DamageParams.AttackAttribute = CmsCombatHit->AttackAttribute;
					DamageParams.TagName = CmsCombatHit->TagName;
					DamageParams.DamagePermil = CmsCombatHit->DamagePermil;
					DamageParams.DamageDestructiblePermil = CmsCombatHit->DamageDestructiblePermil;
					DamageParams.bCanDamageAlly = CmsCombatHit->bCanDamageAlly;
					DamageParams.bIsFrameHold = CmsCombatHit->bIsFrameHold;
					DamageParams.CmsCameraShakeKey = CmsCombatHit->CmsCameraShakeName;
				}

				P3Combat::Server_DamageActor(DamageParams);
			}
		}
	}
	else if (OtherActor)
	{
		P3Combat::FDamageActorParams DamageParams(*SourceActor, *OtherActor);

		DamageParams.TargetComponent = OtherComp;
		DamageParams.TargetHitItemIndex = Hit.Item;
		DamageParams.WeaponType = EP3WeaponType::Gun;
		DamageParams.ImpactDirection = GetVelocity().GetSafeNormal();
		DamageParams.BoneName = Hit.BoneName;
		DamageParams.Projectile = this;
		DamageParams.HitLocation = &Hit.Location;

		if (CmsCombatHit)
		{
			DamageParams.AttackStrength = CmsCombatHit->AttackStrength;
			DamageParams.AttackDirection = CmsCombatHit->AttackDirection;
			DamageParams.AttackAttribute = CmsCombatHit->AttackAttribute;
			DamageParams.TagName = CmsCombatHit->TagName;
			DamageParams.DamagePermil = CmsCombatHit->DamagePermil;
			DamageParams.DamageDestructiblePermil = CmsCombatHit->DamageDestructiblePermil;
			DamageParams.bCanDamageAlly = CmsCombatHit->bCanDamageAlly;			
			DamageParams.bIsFrameHold = CmsCombatHit->bIsFrameHold;
			DamageParams.CmsCameraShakeKey = CmsCombatHit->CmsCameraShakeName;
		}

		P3Combat::Server_DamageActor(DamageParams);
	}

	if (OtherActor && !OtherActor->IsA(AP3Character::StaticClass()))
	{
		// Only add impulse and destroy projectile if we hit a physics
		if (OtherComp && OtherComp->IsSimulatingPhysics())
		{
			OtherComp->AddImpulseAtLocation(GetVelocity() * HitImpulseMass, GetActorLocation());
		}
	}

	World->Server_FireScareFlockEvent(GetActorLocation(), 500, 2.0f);

	if (IsHarpoon() && OtherActor && OtherComp)
	{
		const actorid HitP3ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(OtherActor);
		const bool HitP3Actor = (HitP3ActorId != INVALID_ACTORID);
		const bool HitSimulatingActor = OtherComp->IsSimulatingPhysics();

		Net_HarpoonHit.bHit = true;
		Net_HarpoonHit.HitLocation = GetActorLocation();

		if (HitP3Actor && HitSimulatingActor)
		{
			Net_HarpoonHit.TargetActorId = HitP3ActorId;
			Net_HarpoonHit.ComponentName = OtherComp->GetName();
		}

		ProcessHarpoonHit(Hit);

		Server_SetDirty(*this);
	}

	ReceiveProjectileHit(OtherActor);

	if (HitSpawnActorLifeSpan > 0.f)
	{
		SetLifeSpan(HitSpawnActorLifeSpan);
	}
	else if (bDestroyOnHit)
	{
		Destroy();
	}
}

void AP3Projectile::ProcessHarpoonHit(const FHitResult& Hit)
{
	if (!ensure(Net_HarpoonHit.bHit))
	{
		return;
	}

	UP3World* World = P3Core::GetP3World(*this);
	AActor* TargetActor = World ? World->GetActorFromActorId(Net_HarpoonHit.TargetActorId) : nullptr;

	if (TargetActor)
	{
		UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
		if (PrimComp)
		{
			PrimComp->SetSimulatePhysics(false);
			PrimComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		}

		SetActorEnableCollision(false);

		const FTransform OldTransform = GetActorTransform();
		GetRootComponent()->SetAbsolute(false, false, true);

		USceneComponent* Component = P3Core::GetActorComponentByName<USceneComponent>(*TargetActor, Net_HarpoonHit.ComponentName);
		if (ensure(Component))
		{
			FAttachmentTransformRules AttachRule = FAttachmentTransformRules::KeepWorldTransform;
			AttachRule.bWeldSimulatedBodies = true;
			AttachToComponent(Component, AttachRule);
		}

		// Looks like AttachRule not works well...
		GetRootComponent()->SetWorldTransform(OldTransform);
	}

	ProjectileMovement->StopSimulating(Hit);
}

void AP3Projectile::ProcessProjectileHit(int64 TargetActorId, const FVector& HitLocation, const FVector& HitNormal, const FName& BoneName)
{
	if (IsHarpoon())
	{
		return;
	}

	if (HitSpawnActorLifeSpan <= 0)
	{
		return;
	}

	UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(GetRootComponent());
	if (PrimComp)
	{
		PrimComp->SetSimulatePhysics(false);
		PrimComp->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}

	DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	GetRootComponent()->SetAbsolute(false, false, false);

	SetActorLocation(HitLocation);
	AddActorLocalOffset(FVector(10, 0, 0));

	if (TargetActorId != INVALID_ACTORID)
	{
		AActor* TargetActor = P3Core::GetP3World(*this)->GetActorFromActorId(TargetActorId);
		if (TargetActor)
		{
			FAttachmentTransformRules AttachRule = FAttachmentTransformRules::KeepWorldTransform;
			AttachRule.bWeldSimulatedBodies = true;

			USkeletalMeshComponent* AttachComponent = Cast<USkeletalMeshComponent>(TargetActor->GetComponentByClass(USkeletalMeshComponent::StaticClass()));
			if (AttachComponent)
			{
				AttachToComponent(AttachComponent, AttachRule, BoneName);
			}
			else
			{
				AttachToActor(TargetActor, AttachRule, BoneName);
			}

			if (P3Core::IsP3NetModeServerInstance(*this))
			{
				TargetActor->OnDestroyed.AddUniqueDynamic(this, &AP3Projectile::Server_OnAttachedActorDestroyed);
			}
		}
	}

	ProjectileMovement->StopSimulating(FHitResult());
}

void AP3Projectile::Server_OnAttachedActorDestroyed(AActor* DestroyedActor)
{
	Destroy();
}

void AP3Projectile::Client_OnHit(int64 TargetActorId, const FVector& HitLocation, const FVector& HitNormal, const FName& BoneName)
{
	if (TrailParticleComponent)
	{
		TrailParticleComponent->DeactivateSystem();
	}

	if (HitParticle)
	{
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), HitParticle, GetActorLocation());
	}

	if (HitSound)
	{
		UGameplayStatics::PlaySoundAtLocation(GetWorld(), HitSound, GetActorLocation());
	}

	ProcessProjectileHit(TargetActorId, HitLocation, HitNormal, BoneName);
	
	if (HitAttachedParticle)
	{
		AActor* TargetActor = P3Core::GetP3World(*this)->GetActorFromActorId(TargetActorId);
		if (TargetActor)
		{
			USkeletalMeshComponent* AttachComponent = Cast<USkeletalMeshComponent>(TargetActor->GetComponentByClass(USkeletalMeshComponent::StaticClass()));
			if (AttachComponent)
			{
				UGameplayStatics::SpawnEmitterAttached(HitAttachedParticle, AttachComponent, BoneName, HitLocation, HitNormal.ToOrientationRotator(), EAttachLocation::KeepWorldPosition);
			}
		}
	}
}

void AP3Projectile::Client_HandleHit(const FP3DediToClientHandlerParams& Params)
{	
	FNetProjectileHit NetParams;
	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetParams);

	if (ensure(bSerializeSucceeded))
	{
		Client_OnHit(NetParams.TargetActorId, NetParams.HitLocation, NetParams.HitNormal, NetParams.BoneName);
	}
}

void AP3Projectile::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	if (Archive.IsLoading())
	{
		const bool bOldHarpoonHit = Net_HarpoonHit.bHit;

		Archive << Net_WeaponActor;
		FNetHarpoonHit::StaticStruct()->SerializeBin(Archive, &Net_HarpoonHit);

		if (!bOldHarpoonHit && Net_HarpoonHit.bHit)
		{
			ProcessHarpoonHit(FHitResult());
		}
	}
	else
	{
		Archive << Net_WeaponActor;
		FNetHarpoonHit::StaticStruct()->SerializeBin(Archive, &Net_HarpoonHit);
	}
}
