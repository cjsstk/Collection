// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3StoreInterface.h"

#include "P3ActorInterface.h"
#include "P3ServerWorld.h"

UP3ComponentInterface::UP3ComponentInterface(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void IP3ComponentInterface::Server_SetDirty(const UActorComponent& Self)
{
	UP3ServerWorld* ServerWorld = P3Core::GetP3ServerWorld(Self);

	if (ServerWorld)
	{
		IP3ActorInterface* ActorInterface = Cast<IP3ActorInterface>(Self.GetOwner());

		if (ensure(ActorInterface))
		{
			ServerWorld->AddDirtyComponent(ActorInterface->GetActorId(), Self.GetFName());
		}
	}
}

int64 IP3ComponentInterface::GetOwnerActorId(const UActorComponent& Self) const
{
	static_assert(TIsSame<int64, actorid>::Value, "actorid is not int64. change function signature");

	AActor* OwnerActor = Self.GetOwner();
	IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(OwnerActor);

	if (P3ActorInterface)
	{
		return P3ActorInterface->GetActorId();
	}

	return INVALID_ACTORID;
}
