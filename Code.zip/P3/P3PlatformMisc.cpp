// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PlatformMisc.h"

#if PLATFORM_WINDOWS
#include "Windows/AllowWindowsPlatformTypes.h"
#include "Windows/MinWindows.h"
#include "Windows/HideWindowsPlatformTypes.h"
#endif

void FP3PlatformMisc::SetConsoleWindowTitle(const TCHAR* Title)
{
#if PLATFORM_WINDOWS
	SetConsoleTitle(Title);
#endif
}
