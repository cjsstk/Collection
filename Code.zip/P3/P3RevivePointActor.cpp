// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3RevivePointActor.h"
#include "P3BlueprintFunctionLibrary.h"

#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Components/TextRenderComponent.h"
#include "EngineUtils.h"					// For TActorIterator
#include "Engine/PlayerStartPIE.h"			// For PlayerStart
#include "TimerManager.h"

#include "P3Core.h"
#include "P3Character.h"
#include "P3GameState.h"
#include "P3Localization.h"
#include "P3World.h"

static TAutoConsoleVariable<int32> CVarP3ReviveWaitSeconds(
	TEXT("p3.reviveWaitSeconds"),
	5,
	TEXT("Seconds to wait for Revive"), ECVF_Cheat);


AP3RevivePointActor::AP3RevivePointActor()
{
	SceneComponent = CreateDefaultSubobject<USceneComponent>(TEXT("DefaultSceneComponent"));
	BoxComponent = CreateDefaultSubobject<UBoxComponent>(TEXT("BoxComponent"));
	TextRenderComponent = CreateDefaultSubobject<UTextRenderComponent>(TEXT("TextRenderComponent"));

	BoxComponent->SetupAttachment(SceneComponent);
	BoxComponent->SetBoxExtent(FVector(80.0f, 80.0f, 80.0f));
	TextRenderComponent->SetupAttachment(SceneComponent);
}

void AP3RevivePointActor::BeginPlay()
{
	Super::BeginPlay();
}

void AP3RevivePointActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	TextRenderComponent->AddLocalRotation(FRotator(0, DeltaTime * 100.0f, 0));
}

UP3PlayerReviver::UP3PlayerReviver()
{

}

void UP3PlayerReviver::StartReviver()
{
	GetWorld()->GetTimerManager().SetTimer(ReviveTimerHandle, this, &UP3PlayerReviver::TickRevivePlayer, 1.0f, true);
}

void UP3PlayerReviver::StopReviver()
{
	if (ReviveTimerHandle.IsValid() && GetWorld())
	{
		GetWorld()->GetTimerManager().ClearTimer(ReviveTimerHandle);
	}
}

UP3ReviveAtNearestPointPlayerReviver::UP3ReviveAtNearestPointPlayerReviver()
{

}

void UP3ReviveAtNearestPointPlayerReviver::StartReviver()
{
	Super::StartReviver();

	for (TActorIterator<AP3RevivePointActor> Iter(GetWorld(), AP3RevivePointActor::StaticClass()); Iter; ++Iter)
	{
		if (!ensure(*Iter))
		{
			continue;
		}
		AddRevivePoint(*Iter);
	}
}

FTransform UP3ReviveAtNearestPointPlayerReviver::GetReviveTransform(const AP3Character* Character) const
{
	FTransform ReviveTransform = FTransform::Identity;

	float RandRangeX = 150.0f, RandRangeY = 150.0f; // DYLEE TODO : hard coding..

	if (AP3RevivePointActor* RevivePoint = GetNearestRevivePoint(Character))
	{
		ReviveTransform = RevivePoint->GetActorTransform();

		if (UBoxComponent* BoxComp = RevivePoint->GetBoxComponent())
		{
			ReviveTransform = BoxComp->GetComponentTransform();

			RandRangeX = BoxComp->GetScaledBoxExtent().X * RevivePoint->GetActorScale().X;
			RandRangeY = BoxComp->GetScaledBoxExtent().Y * RevivePoint->GetActorScale().Y;

			const float BoxHalfX = BoxComp->GetScaledBoxExtent().X * RevivePoint->GetActorScale().X;
			const float BoxHalfY = BoxComp->GetScaledBoxExtent().Y * RevivePoint->GetActorScale().Y;
		}
	}
	else
	{
		for (TActorIterator<APlayerStart> It(GetWorld()); It; ++It)
		{
			if (APlayerStart* Start = *It)
			{
				ReviveTransform = Start->GetActorTransform();
				break;
			}
		}
	}

	const float RandX = FMath::RandRange(-RandRangeX, RandRangeX);
	const float RandY = FMath::RandRange(-RandRangeY, RandRangeY);

	ReviveTransform.AddToTranslation(FVector(RandX, RandY, 0));

	return ReviveTransform;
}

void UP3ReviveAtNearestPointPlayerReviver::TickRevivePlayer()
{
	Super::TickRevivePlayer();

	for (TActorIterator<AActor> Iter(GetWorld(), AP3Character::StaticClass()); Iter; ++Iter)
	{
		AP3Character* Character = Cast<AP3Character>(*Iter);
		if (!ensure(Character))
		{
			continue;
		}

		if (!Character->IsPlayerControlled() || !Character->IsDead())
		{
			continue;
		}

		const actorid ActorId = P3Core::GetP3World(*this)->GetActorIdFromActor(Character);

		int32* CountDown = PlayerReviveCountdown.Find(ActorId);

		if (CountDown)
		{
			*CountDown -= 1;
			if (*CountDown <= 0)
			{
				FTransform ReviveTransform = GetReviveTransform(Character);
				if (!ReviveTransform.Equals(FTransform::Identity))
				{
					Character->Revive(ReviveTransform);
				}

				PlayerReviveCountdown.Remove(ActorId);
			}
			else
			{
				FFormatNamedArguments Arguments;
				Arguments.Add(TEXT("Second"), FText::AsNumber(*CountDown));
				UP3BlueprintFunctionLibrary::Server_SendToastMessageToPlayerByCharacter(Character, FText::Format(P3LOC_CHARACTER("ReviveInSeconds"), Arguments));
			}
		}
		else
		{
			PlayerReviveCountdown.Add(ActorId, CVarP3ReviveWaitSeconds.GetValueOnAnyThread());
		}
	}
}

void UP3ReviveAtNearestPointPlayerReviver::AddRevivePoint(AP3RevivePointActor* NewRevivePoint)
{
	if (NewRevivePoint)
	{
		RevivePoints.Add(NewRevivePoint);
	}
}

AP3RevivePointActor* UP3ReviveAtNearestPointPlayerReviver::GetNearestRevivePoint(const class AP3Character* Character) const
{
	if (!ensure(Character))
	{
		return nullptr;
	}
	if (RevivePoints.Num() == 0)
	{
		return nullptr;
	}

	UP3World* P3World = P3Core::GetP3World(*this);
	if (!P3World)
	{
		return nullptr;
	}

	AP3RevivePointActor* NearestPoint = nullptr;

	float NearestDistanceSquared = MAX_flt;

	const FName CharacterZoneName = P3World->GetZoneFromLocation(Character->GetActorLocation());

	for (AP3RevivePointActor* PointActor : RevivePoints)
	{
		if (CharacterZoneName == PointActor->GetZoneNameToBelong())
		{
			return PointActor;
		}

		const float DistanceSquared = FVector::DistSquared(Character->GetActorLocation(), PointActor->GetActorLocation());

		if (NearestDistanceSquared > DistanceSquared)
		{
			NearestDistanceSquared = DistanceSquared;
			NearestPoint = PointActor;
		}
	}

	return NearestPoint;
}
