// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3CharacterEffectTypes.h"
#include "P3CharacterSpeedModifierComponent.generated.h"


/** 
 * Change overlapped character's movement speed
 */
UCLASS( ClassGroup=(P3), meta=(BlueprintSpawnableComponent) )
class P3_API UP3CharacterSpeedModifierComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3CharacterSpeedModifierComponent();

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** Customizable speed multiplier. ex) more deeper actor goes, more slower */
	virtual float GetSpeedMultiplierForActor(const AActor* Actor) { return SpeedMultiplier; }

private:
	UFUNCTION()
	void OnBeginOverlap(AActor* OverlappedActor, AActor* OtherActor);

	UFUNCTION()
	void OnEndOverlap(AActor* OverlappedActor, AActor* OtherActor);

	UPROPERTY(EditAnywhere, Category = P3)
	EP3MoveSpeedEffectLayer EffectLayer = EP3MoveSpeedEffectLayer::Swamp;

	UPROPERTY(EditAnywhere, Category = P3)
	float SpeedMultiplier = 0.5f;

	UPROPERTY(Transient)
	TArray<class ACharacter*> OverlappedCharacters;
};
