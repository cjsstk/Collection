// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3OverlapComponent.h"

#include "Components/PrimitiveComponent.h"
#include "GameFramework/Actor.h"

#include "P3Core.h"

TAutoConsoleVariable<int32> CVarP3OverlapDebug(
	TEXT("p3.overlapDebug"),
	0,
	TEXT("1: debug on, 0: debug off"), ECVF_Cheat);

UP3OverlapComponent::UP3OverlapComponent()
{
	bAutoActivate = true;
}

void UP3OverlapComponent::Activate(bool bReset /*= false*/)
{
	Super::Activate(bReset);

	if (IsActive() && P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_OnActivated();
	}
}

void UP3OverlapComponent::Deactivate()
{
	Super::Deactivate();

	if (!IsActive() && P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_OnDeactivated();
	}
}

void UP3OverlapComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_AddOverlappingActors();
	}
}

void UP3OverlapComponent::Server_AddOverlappingActors()
{
	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	TSet<AActor*> OverlappingActors;

	if (bChildComponentOverlapOnly)
	{
		P3Core::GetChildComponentOverlappingActors(this, OverlappingActors);
	}
	else
	{
		OwnerActor->GetOverlappingActors(OverlappingActors);
	}

	for (AActor* OverlappingActor : OverlappingActors)
	{
		Server_AddOverlappedActor(OverlappingActor);
	}
}

void UP3OverlapComponent::Server_OnActivated()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!bEnableOverlap)
	{
		return;
	}

	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		return;
	}


	// Register overlap handlers
	if (bChildComponentOverlapOnly)
	{
		TArray<USceneComponent*> ChildComponents;
		GetChildrenComponents(true, ChildComponents);

		for (USceneComponent* ChildComp : ChildComponents)
		{
			UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(ChildComp);
			if (PrimComp)
			{
				PrimComp->OnComponentBeginOverlap.AddUniqueDynamic(this, &UP3OverlapComponent::Server_OnComponentBeginOverlap);
				PrimComp->OnComponentEndOverlap.AddUniqueDynamic(this, &UP3OverlapComponent::Server_OnComponentEndOverlap);
			}
		}
	}
	else
	{
		OwnerActor->OnActorBeginOverlap.AddUniqueDynamic(this, &UP3OverlapComponent::Server_OnActorBeginOverlap);
		OwnerActor->OnActorEndOverlap.AddUniqueDynamic(this, &UP3OverlapComponent::Server_OnActorEndOverlap);
	}

	// Initialize overlapping actors
	Server_AddOverlappingActors();
}

void UP3OverlapComponent::Server_OnDeactivated()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	AActor* OwnerActor = GetOwner();
	if (!OwnerActor)
	{
		return;
	}

	// Unregister overlap handlers
	if (bChildComponentOverlapOnly)
	{
		TArray<USceneComponent*> ChildComponents;
		GetChildrenComponents(true, ChildComponents);

		for (USceneComponent* ChildComp : ChildComponents)
		{
			UPrimitiveComponent* PrimComp = Cast<UPrimitiveComponent>(ChildComp);
			if (PrimComp)
			{
				PrimComp->OnComponentBeginOverlap.RemoveDynamic(this, &UP3OverlapComponent::Server_OnComponentBeginOverlap);
				PrimComp->OnComponentEndOverlap.RemoveDynamic(this, &UP3OverlapComponent::Server_OnComponentEndOverlap);
			}
		}
	}
	else
	{
		OwnerActor->OnActorBeginOverlap.RemoveDynamic(this, &UP3OverlapComponent::Server_OnActorBeginOverlap);
		OwnerActor->OnActorEndOverlap.RemoveDynamic(this, &UP3OverlapComponent::Server_OnActorEndOverlap);
	}

	// Clean up overlapping actors
	TSet<AActor*> CopiedOverlappedActors = Server_OverlappedActors;
	for (AActor* Actor : CopiedOverlappedActors)
	{
		Server_RemoveOverlappedActor(Actor);
	}
	ensure(Server_OverlappedActors.Num() == 0);
}

void UP3OverlapComponent::Server_AddOverlappedActor(AActor* Actor)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(Actor) || !GetOwner())
	{
		return;
	}

	if (Actor == GetOwner())
	{
		return;
	}

	if (Server_OverlappedActors.Contains(Actor))
	{
		return;
	}

	Server_OverlappedActors.Add(Actor);

	Server_OverlappedActorAdded(*Actor);

	Server_OnOverlappedActorAdded.Broadcast(Actor);
}

void UP3OverlapComponent::Server_RemoveOverlappedActor(AActor* Actor)
{
	if (!ensure(Actor))
	{
		return;
	}

	const int32 NumRemoved = Server_OverlappedActors.Remove(Actor);

	if (NumRemoved)
	{
		Server_OverlappedActorRemoved(*Actor);

		Server_OnOverlappedActorRemoved.Broadcast(Actor);
	}
}

void UP3OverlapComponent::Server_OnActorBeginOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (!ensure(bEnableOverlap))
	{
		return;
	}

	if (!ensure(IsActive()))
	{
		return;
	}

	if (bChildComponentOverlapOnly)
	{
		ensure(0);
		return;
	}

	Server_AddOverlappedActor(OtherActor);
}

void UP3OverlapComponent::Server_OnActorEndOverlap(AActor* OverlappedActor, AActor* OtherActor)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	Server_RemoveOverlappedActor(OtherActor);
}

void UP3OverlapComponent::Server_OnComponentBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (!ensure(bEnableOverlap))
	{
		return;
	}

	if (!ensure(IsActive()))
	{
		return;
	}

	if (!ensure(bChildComponentOverlapOnly))
	{
		return;
	}

	if (IgnoreComponentClasses.Num() > 0)
	{
		for (const UClass* IgroreComponent : IgnoreComponentClasses)
		{
			if (OtherComp && OtherComp->IsA(IgroreComponent))
			{
				return;
			}
		}
	}

	Server_AddOverlappedActor(OtherActor);
}

void UP3OverlapComponent::Server_OnComponentEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (!P3Core::IsP3NetModeServerInstance(*this))
	{
		return;
	}

	if (IgnoreComponentClasses.Num() > 0)
	{
		for (const UClass* IgroreComponent : IgnoreComponentClasses)
		{
			if (OtherComp && OtherComp->IsA(IgroreComponent))
			{
				return;
			}
		}
	}

	Server_RemoveOverlappedActor(OtherActor);
}
