// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3CharacterEffectTypes.h"
#include "P3OverlapComponent.h"
#include "P3EffectTriggerComponent.generated.h"


USTRUCT()
struct FP3PendingActor
{
	GENERATED_BODY()

	UPROPERTY()
	AActor* Actor;

	UPROPERTY()
	float EffectDelayTime = 0.0f;
};

UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3EffectTriggerComponent : public UP3OverlapComponent
{
	GENERATED_BODY()

public:	
	UP3EffectTriggerComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	const TSet<AActor*>& GetAffectedActors() const { return Server_AffectedActors; }

protected:
	virtual void BeginPlay() override;
	virtual void Server_OverlappedActorAdded(AActor& Actor) override;
	virtual void Server_OverlappedActorRemoved(AActor& Actor) override;

private:
	void Server_Tick(float DeltaTime);

	/** If true, Instigator is ignored on overlapped */
	UPROPERTY(EditDefaultsOnly, Category = Effect)
	bool bIgnoreInstigator = true;

	/** If over 0, overlapped actors have random time delay before the actors get effect */
	UPROPERTY(EditDefaultsOnly, Category = Effect, meta=(UIMin = 0.0f, ClampMin = 0.0f))
	float MaxDelayRandomTime = 0.0f;

	UPROPERTY(EditDefaultsOnly, Category = Effect)
	EP3CharacterEffectTypes EffectType = EP3CharacterEffectTypes::Slow;

	UPROPERTY(Transient)
	TSet<AActor*> Server_AffectedActors;

	UPROPERTY(Transient)
	TArray<FP3PendingActor> Server_PendingActors;
};
