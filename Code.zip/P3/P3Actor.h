// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GameplayTagAssetInterface.h"

#include "P3ActorInterface.h"
#include "Network/Lib/P3NetCore.h"
#include "P3Actor.generated.h"

USTRUCT()
struct FNetP3ActorEvent
{
	GENERATED_BODY()

	UPROPERTY()
	FName EventName;
	
	UPROPERTY()
	int32 Param;
};

UCLASS()
class P3_API AP3Actor : public AActor, public IGameplayTagAssetInterface, public IP3ActorInterface
{
	GENERATED_BODY()
	
public:	
	AP3Actor(const FObjectInitializer& ObjectInitializer = FObjectInitializer::Get());
	
	virtual void Client_NetAttachChanged();

	UFUNCTION(BlueprintCallable)
	void AddDebugStringBP(const FString& InDebugString, bool bAddNewLine = true) { AddDebugString(InDebugString, bAddNewLine); }

	/** 
	 * Simple Network event
	 */
	UFUNCTION(BlueprintCallable)
	void Server_MulticastEvent(FName EventName, int32 Param);

	UFUNCTION()
	void Client_HandleEvent(const struct FP3DediToClientHandlerParams& Params);

	/** IGameplayTagAssetInterface */
	virtual void GetOwnedGameplayTags(FGameplayTagContainer& TagContainer) const override;

	/**
	 * IP3ActorInterface
	 */
	virtual actorid GetActorId() const override { return ActorId; }
	virtual void SetActorId(actorid Id) override { ActorId = Id; }
	virtual void AddGameplayTags(const FGameplayTagContainer& TagContainer) override;
	virtual void RemoveGameplayTags(const FGameplayTagContainer& TagContainer) override;
	virtual void AddDebugString(const FString& InDebugString, bool bAddNewLine = true) override;
	virtual void NetSerialize(FArchive& Archive) override {}
	virtual class UP3StoreComponent* GetStoreComponent() const;
	virtual bool IsLevelPersistence() const override { return bLevelPersistence; }

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void PostInitializeComponents() override;

	// TODO: Change name to Multicast
	virtual void Client_OnEvent(FName EventName, int32 Param);
	
	// TODO: Change name to Multicast
	UFUNCTION(BlueprintImplementableEvent)
	void Client_RecvEvent(FName EventName, int32 Param);

	UFUNCTION(BlueprintImplementableEvent)
	void RecvAttachChanged();

	/** If true, Client will load this actor from level and sync from server by name (instead of spawn new actor) */
	UPROPERTY(EditAnywhere, Category = P3)
	bool bLevelPersistence = false;

private:
	actorid ActorId = INVALID_ACTORID;

	UPROPERTY(EditAnywhere, Category = P3)
	FGameplayTagContainer GameplayTagContainer;

	UPROPERTY(Transient)
	class UP3StoreComponent* StoreComponent;

	/** Debug string */
	FString P3ActorDebugString;
};
