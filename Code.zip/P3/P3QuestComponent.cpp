// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3QuestComponent.h"

#include "AssetRegistryModule.h"
#include "EngineUtils.h"
#include "Kismet/KismetMathLibrary.h"
#include "LevelSequenceActor.h"
#include "ScriptDelegates.h"

#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "Network/P3WorldNet.h"
#include "P3Character.h"
#include "P3ClientWorld.h"
#include "P3Core.h"
#include "P3GameInstance.h"
#include "P3Log.h"
#include "P3PlayerController.h"
#include "P3QuestSpot.h"
#include "P3QuestSwitchActor.h"
#include "P3QuestVolume.h"
#include "P3ServerWorld.h"
#include "P3World.h"
#include "Widget/P3WalkieTalkieWidget.h"
#include "Widget/P3QuestListWidget.h"


static TAutoConsoleVariable<int32> CVarP3QuestDebug(
	TEXT("p3.questDebug"),
	0,
	TEXT("2: detail, 1: simple. 0: disable"), ECVF_Cheat);


int32 GenerateRequestId()
{
	static int32 RequestId = 0;

	RequestId = (RequestId + 1) % 100;

	return RequestId;
}

UP3QuestComponent::UP3QuestComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
}

void UP3QuestComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_Tick(DeltaTime);
	}

	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		Client_Tick(DeltaTime);
	}
}

void UP3QuestComponent::NetSerialize(FArchive& Archive)
{
	TMap<questkey, FP3QuestData> QuestDatas;

	if (Archive.IsLoading())
	{
		// TODO : Different processing is needed depending on Actor Role ( Remote Role? )
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (!Character || !Character->IsLocallyControlled())
		{
			return;
		}

		Archive << QuestDatas;

		// remove

		TArray<questkey> RemoveQuestKeys;

		for (auto& Iter : Quests)
		{
			UP3Quest* Quest = Iter.Value;

			if (!ensure(Quest))
			{
				continue;
			}

			if (!ensure(Quest->IsValid()))
			{
				continue;
			}

			if (!QuestDatas.Contains(Iter.Key))
			{
				RemoveQuestKeys.AddUnique(Iter.Key);
			}
		}

		for (questkey QuestKey : RemoveQuestKeys)
		{
			Client_RemoveQuest(QuestKey);
		}

		// update or add

		for (auto& Iter : QuestDatas)
		{
			FP3QuestData& QuestData = Iter.Value;

			if (Quests.Contains(Iter.Key))
			{
				UP3Quest* Quest = *Quests.Find(Iter.Key);

				Quest->UpdateQuestData(QuestData);
			}
			else
			{
				Client_AddQuest(Iter.Key);
			}
		}
	}
	else
	{
		for (auto& Iter : Quests)
		{
			UP3Quest* Quest = Iter.Value;

			if (!ensure(Quest))
			{
				continue;
			}

			if (!ensure(Quest->IsValid()))
			{
				continue;
			}

			FP3QuestData& QuestData = QuestDatas.Add(Iter.Key);

			Quest->GetQuestData(QuestData);
		}

		Archive << QuestDatas;
	}
}

void UP3QuestComponent::Server_InitQuests(const TMap<questkey, FP3QuestData>& QuestDatas)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	for (auto& Iter : QuestDatas)
	{
		Server_InitQuest(Iter.Key, Iter.Value);
	}

	Server_SetDirty(*this);
}

void UP3QuestComponent::Server_Tick(float DeltaTimeSeconds)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	TArray<questkey> QuestKeys;
	Quests.GetKeys(QuestKeys);

	for (questkey QuestKey : QuestKeys)
	{
		if (!Quests.Find(QuestKey))
		{
			continue;
		}

		UP3Quest* Quest = *Quests.Find(QuestKey);

		if (!ensure(Quest))
		{
			continue;
		}

		if (!ensure(Quest->IsValid()))
		{
			continue;
		}

		ProcessingQuestKey = QuestKey;

		Quest->Tick(DeltaTimeSeconds);
	}

	ProcessingQuestKey = INVALID_QUESTKEY;
}

void UP3QuestComponent::Client_Tick(float DeltaTimeSeconds)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	if (CVarP3QuestDebug.GetValueOnGameThread() <= 0)
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());
	if (!ensure(Character))
	{
		return;
	}

	if (Quests.Num() == 0)
	{
		return;
	}

	FString DebugString = TEXT("Quest");

	for (auto& Elem : Quests)
	{
		UP3Quest* Quest = Elem.Value;

		if (!ensure(Quest))
		{
			continue;
		}

		if (!ensure(Quest->IsValid()))
		{
			continue;
		}

		DebugString += TEXT("\n  ");
		DebugString += Quest->GetDebugString(CVarP3QuestDebug.GetValueOnGameThread());
	}

	Character->AddDebugString(DebugString);
}

bool UP3QuestComponent::Server_StartQuest(questkey QuestKey)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (!ensure(QuestKey != INVALID_QUESTKEY))
	{
		return false;
	}

	if (Quests.Contains(QuestKey))
	{
		return false;
	}

	Server_AddQuest(QuestKey);

	return true;
}

bool UP3QuestComponent::Server_ManuallyProceed()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	for (auto& Elem : Quests)
	{
		UP3Quest* Quest = Elem.Value;

		if (!ensure(Quest))
		{
			continue;
		}

		if (!ensure(Quest->IsValid()))
		{
			continue;
		}

		if (Quest->IsManuallyProceedable())
		{
			bool bResult = Quest->ManuallyProceed();

			if (bResult)
			{
				Server_SetDirty(*this);

				return true;
			}
			else
			{
				return false;
			}
		}
	}

	return false;
}

bool UP3QuestComponent::IsManuallyProceedable() const
{
	for (auto& Elem : Quests)
	{
		UP3Quest* Quest = Elem.Value;

		if (Quest && Quest->IsManuallyProceedable())
		{
			return true;
		}
	}

	return false;
}

const AP3QuestVolume* UP3QuestComponent::FindQuestVolume(const FGameplayTagContainer& GameplayTag) const
{
	UP3World* P3World = P3Core::GetP3World(*this);

	if (!ensure(P3World))
	{
		return nullptr;
	}

	return P3World->GetQuestVolume(GameplayTag);
}

AP3SwitchActor* UP3QuestComponent::FindSwitchActor(const FGameplayTagContainer& GameplayTag) const
{
	UP3World* P3World = P3Core::GetP3World(*this);

	if (!ensure(P3World))
	{
		return nullptr;
	}

	return Cast<AP3SwitchActor>(P3World->GetQuestActor(GameplayTag));
}

AP3QuestSpot* UP3QuestComponent::FindQuestSpot(const FGameplayTagContainer& GameplayTag) const
{
	UP3World* P3World = P3Core::GetP3World(*this);

	if (!ensure(P3World))
	{
		return nullptr;
	}

	return Cast<AP3QuestSpot>(P3World->GetQuestActor(GameplayTag));
}

AP3QuestBoxTriggeredSwitchActor* UP3QuestComponent::FindQuestBoxTriggeredSwitchActor(const FGameplayTagContainer& GameplayTag) const
{
	UP3World* P3World = P3Core::GetP3World(*this);

	if (!ensure(P3World))
	{
		return nullptr;
	}

	return Cast<AP3QuestBoxTriggeredSwitchActor>(P3World->GetQuestActor(GameplayTag));
}

bool UP3QuestComponent::Server_ToggleSwitch(const FGameplayTagContainer& SwitchGameplayTagAll, bool bNewSwitchState)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	P3JsonLog(Display, "Server_ToggleSwitch", TEXT("Character"), *GetOwner()->GetName(), TEXT("TagString"), SwitchGameplayTagAll.ToStringSimple());

	AP3SwitchActor* SwitchActor = FindSwitchActor(SwitchGameplayTagAll);

	if (!SwitchActor)
	{
		P3JsonLog(Warning, "No switch to toggle");
		return false;
	}

	SwitchActor->ToggleSwitchBP(bNewSwitchState);

	return false;
}

bool UP3QuestComponent::Server_PlaySequence(ULevelSequence* LevelSequence, bool bDisableMovementInput, bool bDisableLookAtInput, bool bHidePlayer, bool bHideHud, bool bDisableCameraCuts, bool bNeedFinishCallback)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (!LevelSequence)
	{
		return false;
	}

	P3JsonLog(Display, "Server_PlaySequence", TEXT("Character"), *GetOwner()->GetName());

	FP3NetQuestActionParams ActionParams;

	ActionParams.ActionType = EP3QuestActionType::PlaySequence;
	ActionParams.LevelSequence = LevelSequence;
	ActionParams.bDisableMovementInput = bDisableMovementInput;
	ActionParams.bDisableLookAtInput = bDisableLookAtInput;
	ActionParams.bHidePlayer = bHidePlayer;
	ActionParams.bHideHud = bHideHud;
	ActionParams.bDisableCameraCuts = bDisableCameraCuts;
	ActionParams.bNeedFinishCallback = bNeedFinishCallback;

	if (bNeedFinishCallback)
	{
		int32 RequestId = GenerateRequestId();

		ActionParams.RequestId = RequestId;

		Server_WatchingRequestIds.Add(RequestId, ProcessingQuestKey);
	}

	Server_RequestAction(ActionParams);

	return bNeedFinishCallback;
}

void UP3QuestComponent::Client_PlaySequence(ULevelSequence* LevelSequence, bool bDisableMovementInput, bool bDisableLookAtInput, bool bHidePlayer, bool bHideHud, bool bDisableCameraCuts, bool bNeedFinishCallback, int32 RequestId)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	if (!LevelSequenceActor)
	{
		LevelSequenceActor = GetWorld()->SpawnActor<ALevelSequenceActor>();

		P3Core::GetP3World(*this)->AddSequencePlayer(LevelSequenceActor->SequencePlayer);

		if (bNeedFinishCallback)
		{
			LevelSequenceActor->SequencePlayer->OnStop.AddUniqueDynamic(this, &UP3QuestComponent::Client_OnSequenceStop);
			LevelSequenceActor->SequencePlayer->OnFinished.AddUniqueDynamic(this, &UP3QuestComponent::Client_OnSequenceFinished);
		}
	}

	if (!ensure(LevelSequenceActor))
	{
		return;
	}

	LevelSequenceActor->PlaybackSettings.bDisableMovementInput = bDisableMovementInput;
	LevelSequenceActor->PlaybackSettings.bDisableLookAtInput = bDisableLookAtInput;
	LevelSequenceActor->PlaybackSettings.bHidePlayer = bHidePlayer;
	LevelSequenceActor->PlaybackSettings.bHideHud = bHideHud;
	LevelSequenceActor->PlaybackSettings.bDisableCameraCuts = bDisableCameraCuts;

	LevelSequenceActor->SetSequence(LevelSequence);
	LevelSequenceActor->SequencePlayer->Play();

	if (bNeedFinishCallback)
	{
		Client_WatchingRequestId = RequestId;
	}
	else
	{
		Client_WatchingRequestId = -1;
	}
}

bool UP3QuestComponent::Server_DeriveQuest(const UP3QuestDesc* QuestDesc)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (!ensure(QuestDesc))
	{
		return false;
	}

	P3JsonLog(Display, "Server_DriveQuest", TEXT("Character"), *GetOwner()->GetName());

	questkey QuestKey = P3Cms::GetQuestKeyFromQuestDesc(QuestDesc);

	if (QuestKey == INVALID_QUESTKEY)
	{
		return false;
	}

	Server_AddQuest(QuestKey);

	return false;
}

void UP3QuestComponent::Server_AddQuest(questkey QuestKey)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(QuestKey != INVALID_QUESTKEY))
	{
		return;
	}

	if (!ensure(!Quests.Contains(QuestKey)))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);

	if (!ensure(WorldNet))
	{
		return;
	}

	UP3Quest* Quest = AddQuestInternal(QuestKey);

	if (!ensure(Quest))
	{
		return;
	}

	FP3QuestUtil::Server_CreateQuest(*WorldNet, *this, Character->GetCharacterStoreBP().CharacterId, QuestKey);

	Quest->OnQuestUpdated.AddUObject(this, &UP3QuestComponent::Server_OnQuestUpdated);

	Server_SetDirty(*this);
}

bool UP3QuestComponent::Server_SpawnCharacter(UClass* Class, const FGameplayTagContainer& SpawnSpotGameplayTagAll)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	P3JsonLog(Display, "Server_SpawnCharacter", TEXT("Character"), *GetOwner()->GetName(), TEXT("TagString"), SpawnSpotGameplayTagAll.ToStringSimple());

	AP3QuestSpot* Spot = FindQuestSpot(SpawnSpotGameplayTagAll);

	if (!Spot)
	{
		P3JsonLog(Warning, "No spot to spawn");
		return false;
	}

	FTransform SpawnTransform = Spot->GetTransform();

	GetWorld()->SpawnActor(Class, &SpawnTransform);

	return false;
}

bool UP3QuestComponent::Server_SendWalkieTalkieMessage(const FText& Message)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	P3JsonLog(Display, "Server_SendWalkieTalkieMessage", TEXT("Character"), *GetOwner()->GetName(), TEXT("Message"), Message.ToString());

	FP3NetQuestActionParams ActionParams;

	ActionParams.ActionType = EP3QuestActionType::SendWalkieTalkieMessage;
	ActionParams.Message = Message;

	Server_RequestAction(ActionParams);

	return false;
}

void UP3QuestComponent::Client_SendWalkieTalkieMessage(const FText& Message)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(Character->GetController());

	if (!ensure(PlayerController))
	{
		return;
	}

	UP3WalkieTalkieWidget* WalkieTalkieWidget = PlayerController->GetWalkieTalkieWidget();

	if (!ensure(WalkieTalkieWidget))
	{
		return;
	}

	WalkieTalkieWidget->SetMessage(Message);
}

bool UP3QuestComponent::Server_LookAt(const FGameplayTagContainer& LookAtTargetSpotGameplayTagAll)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	P3JsonLog(Display, "Server_LookAt", TEXT("Character"), *GetOwner()->GetName(), TEXT("TagString"), LookAtTargetSpotGameplayTagAll.ToStringSimple());

	AP3QuestSpot* Spot = FindQuestSpot(LookAtTargetSpotGameplayTagAll);

	if (!Spot)
	{
		P3JsonLog(Warning, "No spot to look at");
		return false;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return false;
	}

	UP3CommandComponent* CommandComp = Character->GetCommandComponent();

	if (!ensure(CommandComp))
	{
		return false;
	}

	FP3CommandRequestParams Params;

	Params.LookAtTargetLocation = Spot->GetActorLocation();

	CommandComp->RequestCommand(UP3LookAtCommand::StaticClass(), Params);

	return false;
}

void UP3QuestComponent::Server_InitQuest(questkey QuestKey, const FP3QuestData& QuestData)
{
	if (!ensure(QuestKey != INVALID_QUESTKEY))
	{
		return;
	}

	if (!ensure(!Quests.Contains(QuestKey)))
	{
		return;
	}

	UP3Quest* Quest = AddQuestInternal(QuestKey);

	if (!ensure(Quest))
	{
		return;
	}

	Quest->InitQuestData(QuestData);

	Quest->OnQuestUpdated.AddUObject(this, &UP3QuestComponent::Server_OnQuestUpdated);
}

UP3Quest* UP3QuestComponent::AddQuestInternal(questkey QuestKey)
{
	if (!ensure(QuestKey != INVALID_QUESTKEY))
	{
		return nullptr;
	}

	if (!ensure(!Quests.Contains(QuestKey)))
	{
		return nullptr;
	}

	UP3Quest* Quest = NewObject<UP3Quest>();
	Quest->InitQuest(this, QuestKey);
	Quests.Add(QuestKey, Quest);
	return Quest;
}

void UP3QuestComponent::Server_RequestAction(const FP3NetQuestActionParams& ActionParams)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	const FP3NetConnInfo ConnId = P3Core::GetP3World(*this)->GetServerWorld()->GetPlayerConnInfoFromActor(*GetOwner());

	const actorid ActorId = GetOwnerActorId(*this);

	P3Core::GetP3World(*this)->Server_SendPacketToPlayerReliable(ConnId, this, ActorId, GetOwner(), ActionParams, EP3NetComponentType::Quest, &UP3QuestComponent::Client_HandleRequest);
}

void UP3QuestComponent::Client_HandleRequest(const FP3DediToClientHandlerParams& Params)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	FP3NetQuestActionParams ActionParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, ActionParams);

	if (ensure(bSerializeSucceeded))
	{
		if (ActionParams.ActionType == EP3QuestActionType::PlaySequence)
		{
			Client_PlaySequence(ActionParams.LevelSequence, ActionParams.bDisableMovementInput, ActionParams.bDisableLookAtInput, ActionParams.bHidePlayer, ActionParams.bHideHud, ActionParams.bDisableCameraCuts, ActionParams.bNeedFinishCallback, ActionParams.RequestId);
		}
		else if (ActionParams.ActionType == EP3QuestActionType::SendWalkieTalkieMessage)
		{
			Client_SendWalkieTalkieMessage(ActionParams.Message);
		}
		else
		{
			ensure(false);
		}
	}
}

void UP3QuestComponent::Client_ReplyActionFinished(const FP3NetQuestActionParams& ActionParams)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	const actorid ActorId = GetOwnerActorId(*this);

	P3Core::GetP3World(*this)->Client_SendPacketReliable(this, ActorId, GetOwner(), ActionParams, EP3NetComponentType::Quest, &UP3QuestComponent::Server_HandleReply);
}

void UP3QuestComponent::Server_HandleReply(const FP3ClientToDediHandlerParams& Params)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	FP3NetQuestActionParams ActionParams;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, ActionParams);

	if (ensure(bSerializeSucceeded))
	{
		if (!ensure(Server_WatchingRequestIds.Contains(ActionParams.RequestId)))
		{
			return;
		}

		questkey QuestKey = Server_WatchingRequestIds.FindChecked(ActionParams.RequestId);

		if (!ensure(Quests.Find(QuestKey)))
		{
			return;
		}

		UP3Quest* Quest = *Quests.Find(QuestKey);

		if (!ensure(Quest))
		{
			return;
		}

		if (!ensure(Quest->IsWaitingActionFinished()))
		{
			return;
		}

		Quest->OnActionFinishCallback();

		Server_WatchingRequestIds.Remove(ActionParams.RequestId);
	}
}

void UP3QuestComponent::Client_AddQuest(questkey QuestKey)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	if (!ensure(QuestKey != INVALID_QUESTKEY))
	{
		return;
	}

	UP3Quest* Quest = NewObject<UP3Quest>();

	Quest->InitQuest(this, QuestKey);

	Quests.Add(QuestKey, Quest);

	// ui
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(Character->GetController());

	if (!ensure(PlayerController))
	{
		return;
	}

	UP3QuestListWidget* QuestListWidget = PlayerController->GetQuestListWidget();

	if (!ensure(QuestListWidget))
	{
		return;
	}

	QuestListWidget->Add(Quest);
}

void UP3QuestComponent::Client_RemoveQuest(questkey QuestKey)
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	auto QuestIter = Quests.Find(QuestKey);

	if (!ensure(QuestIter))
	{
		return;
	}

	UP3Quest* Quest = *QuestIter;

	Quests.Remove(QuestKey);

	// ui
	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return;
	}

	AP3PlayerController* PlayerController = Cast<AP3PlayerController>(Character->GetController());

	if (!ensure(PlayerController))
	{
		return;
	}

	UP3QuestListWidget* QuestListWidget = PlayerController->GetQuestListWidget();

	if (!ensure(QuestListWidget))
	{
		return;
	}

	QuestListWidget->Remove(Quest);
}

void UP3QuestComponent::Server_OnQuestUpdated(questkey QuestKey)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!ensure(QuestKey != INVALID_QUESTKEY))
	{
		return;
	}

	if (!ensure(Quests.Contains(QuestKey)))
	{
		return;
	}

	AP3Character* Character = Cast<AP3Character>(GetOwner());

	if (!ensure(Character))
	{
		return;
	}

	UP3WorldNetBase* WorldNet = P3GetWorldNet(Character);

	if (!ensure(WorldNet))
	{
		return;
	}

	UP3Quest* Quest = *Quests.Find(QuestKey);

	if (!ensure(Quest))
	{
		return;
	}

	FP3QuestData QuestData;

	Quest->GetQuestData(QuestData);

	FP3QuestUtil::Server_UpdateQuest(*WorldNet, *this, Character->GetCharacterStoreBP().CharacterId, QuestKey, QuestData.State, QuestData.PhaseIndex, QuestData.ActionIndex);

	FP3CharacterStore CharacterStore = Character->GetCharacterStoreBP();

	if (CharacterStore.bOnQuestCutscene != Quest->IsWatchingCutscene())
	{
		CharacterStore.bOnQuestCutscene = Quest->IsWatchingCutscene();
		Character->SetCharacterStore(CharacterStore);
	}

	Server_SetDirty(*this);
}

void UP3QuestComponent::Client_OnSequenceStop()
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	if (ensure(LevelSequenceActor))
	{
		P3Core::GetP3World(*this)->RemoveSequencePlayer(LevelSequenceActor->SequencePlayer);
	}

	if (Client_WatchingRequestId != -1)
	{
		FP3NetQuestActionParams ActionParams;

		ActionParams.RequestId = Client_WatchingRequestId;

		Client_ReplyActionFinished(ActionParams);

		Client_WatchingRequestId = -1;
	}
}

void UP3QuestComponent::Client_OnSequenceFinished()
{
	if (!ensure(P3Core::IsP3NetModeClientInstance(*this)))
	{
		return;
	}

	if (ensure(LevelSequenceActor))
	{
		P3Core::GetP3World(*this)->RemoveSequencePlayer(LevelSequenceActor->SequencePlayer);
	}

	if (Client_WatchingRequestId != -1)
	{
		FP3NetQuestActionParams ActionParams;

		ActionParams.RequestId = Client_WatchingRequestId;

		Client_ReplyActionFinished(ActionParams);

		Client_WatchingRequestId = -1;
	}
}
