// Copyright 2018 XLGames, Inc. All Rights Reserved.


#include "P3SmokeActor.h"

#include "Components/SphereComponent.h"
#include "Components/DecalComponent.h"
#include "DrawDebugHelpers.h"
#include "Kismet/GameplayStatics.h"
#include "LandscapeHeightfieldCollisionComponent.h"
#include "Particles/ParticleSystemComponent.h"
#include "Particles/ParticleSystem.h"

#include "P3GameState.h"

TAutoConsoleVariable<int32> CVarP3FireballSmokeActorDebug(
	TEXT("p3.FireballSmokeActorDebug"),
	0,
	TEXT("0: Disable debug 1: Enable debug "), ECVF_Cheat);

AP3SmokeActor::AP3SmokeActor()
{
	SphereComponent = CreateDefaultSubobject<USphereComponent>(TEXT("SphereComponent"));
	SphereComponent->SetupAttachment(RootComponent);

	DecalComponent = CreateDefaultSubobject<UDecalComponent>(TEXT("DecalComponent"));
	DecalComponent->SetupAttachment(SphereComponent);
	DecalComponent->bDestroyOwnerAfterFade = true;
}

void AP3SmokeActor::SpawnSmoke()
{
	if (!SmokeParticle)
	{
		return;
	}

	AP3GameState* GameState = Cast<AP3GameState>(GetWorld()->GetGameState());
	if (!GameState)
	{
		return;
	}

	AP3WorldParticleActor* WorldParticleActor = GameState->GetWorldParticleActor();
	if (!WorldParticleActor)
	{
		return;
	}

	const FVector LineStart = GetActorLocation() + (GetActorUpVector() * 100.0f);
	const FVector LineEnd = GetActorLocation() + (GetActorUpVector() * -300.0f);

	FCollisionQueryParams QueryParams;
	QueryParams.AddIgnoredActor(Instigator);

	FCollisionResponseParams ResponseParams;
	ResponseParams.CollisionResponse.SetAllChannels(ECR_Ignore);
	ResponseParams.CollisionResponse.SetResponse(ECC_WorldStatic, ECR_Block);
	ResponseParams.CollisionResponse.SetResponse(ECC_WorldDynamic, ECR_Block);
	ResponseParams.CollisionResponse.SetResponse(ECC_Destructible, ECR_Block);

	FHitResult HitResult;

	bHitFound = GetWorld()->LineTraceSingleByChannel(HitResult, LineStart, LineEnd, ECC_Pawn, QueryParams, ResponseParams);

	if (bHitFound)
	{
		ParticleComp = UGameplayStatics::SpawnEmitterAttached(SmokeParticle, WorldParticleActor->GetRootComponent(), NAME_None, HitResult.Location, FRotator::ZeroRotator, EAttachLocation::KeepWorldPosition);
	}
	else
	{
		ParticleComp = UGameplayStatics::SpawnEmitterAttached(SmokeParticle, WorldParticleActor->GetRootComponent(), NAME_None, GetActorLocation(), FRotator::ZeroRotator, EAttachLocation::KeepWorldPosition);
	}

	if (ParticleComp)
	{
		ParticleComp->AttachToComponent(SphereComponent, FAttachmentTransformRules::KeepWorldTransform);
	}
}

void AP3SmokeActor::BeginPlay()
{
	Super::BeginPlay();

	SpawnSmoke();
}

void AP3SmokeActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (ParticleComp && ParticleComp->IsActive())
	{
		ParticleComp->Deactivate();
	}
}

void AP3SmokeActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (ParticleComp)
	{
		if (!bSmokeEnd && ParticleComp->IsActive())
		{
			CurrentSmokeLifeTime += DeltaTime;

			if (CurrentSmokeLifeTime >= SmokeParticleLiftTime)
			{
				ParticleComp->Deactivate();
				bSmokeEnd = true;
			}
		}
	}

	if (CVarP3FireballSmokeActorDebug.GetValueOnGameThread() > 0)
	{
		const FVector LineStart = GetActorLocation() + (GetActorUpVector() * 100.0f);
		const FVector LineEnd = GetActorLocation() + (GetActorUpVector() * -300.0f);
		DrawDebugLine(GetWorld(), LineStart, LineEnd, FColor::Red, false, 5.0f, 0, 3.0f);

		if (!ParticleComp)
		{
			AddDebugString(FString::Printf(TEXT("NoParticleComp")));
		}

		AddDebugString(FString::Printf(TEXT("HitFound: %s"), bHitFound ? TEXT("true") : TEXT("false")));
		AddDebugString(FString::Printf(TEXT("LifeTime: [%.1f / %.1f]"), CurrentSmokeLifeTime, SmokeParticleLiftTime));
		AddDebugString(FString::Printf(TEXT("SmokeEnd: %s"), bSmokeEnd ? TEXT("true") : TEXT("false")));
	}
}
