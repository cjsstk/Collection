// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3OverlapComponent.h"
#include "P3CountingFractureComponent.generated.h"

/**
 * Fracture Destructible by counting overlap events
 */
UCLASS(ClassGroup = (P3), meta = (BlueprintSpawnableComponent))
class P3_API UP3CountingFractureComponent : public UP3OverlapComponent
{
	GENERATED_BODY()

public:
	UP3CountingFractureComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

protected:
	virtual void Server_OverlappedActorAdded(AActor& Actor) override;

private:
	void Server_Fracture();

	UPROPERTY(EditDefaultsOnly, Category = Overlap)
	int32 OverlapCountToDestroy = 1;

	int32 Server_OverlapCount = 0;
};
