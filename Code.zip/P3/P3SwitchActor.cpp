// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3SwitchActor.h"

#include "Engine//World.h"
#include "Components/BillboardComponent.h"
#include "Components/BoxComponent.h"
#include "Components/SphereComponent.h"
#include "DrawDebugHelpers.h"
#include "GameplayTagAssetInterface.h"

#include "P3Core.h"
#include "P3Character.h"
#include "P3SignalReceiver.h"
#include "P3HealthPointComponent.h"
#include "P3InteractableComponent.h"
#include "P3Log.h"
#include "P3World.h"

static TAutoConsoleVariable<int32> CVarP3SwitchDebug(
	TEXT("p3.switchDebug"),
	0,
	TEXT("Toggling switch debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SwitchToggleCoolTimeSeconds(
	TEXT("p3.switchToggleCoolTimeSeconds"),
	0.5f,
	TEXT("Toggling switch is ignored if tried within this time"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SwitchToggleByDamageDelaySeconds(
	TEXT("p3.switchToggleByDamageDelaySeconds"),
	0.1f,
	TEXT("Toggling switch by combat is delayed so that other method(like collision) can apply first. Must be smaller than p3.switchToggleCoolTimeSeconds"), ECVF_Cheat);


namespace
{
	static const FColor P3TriggerBaseColor(100, 255, 100, 255);
	static const FName P3TriggerCollisionProfileName(TEXT("Trigger"));
}


AP3SwitchActor::AP3SwitchActor()
{
	PrimaryActorTick.bCanEverTick = true;

//#if WITH_EDITORONLY_DATA
//	SpriteComponent = CreateEditorOnlyDefaultSubobject<UBillboardComponent>(TEXT("Sprite"));
//	if (SpriteComponent)
//	{
//		// Structure to hold one-time initialization
//		struct FConstructorStatics
//		{
//			ConstructorHelpers::FObjectFinderOptional<UTexture2D> TriggerTextureObject;
//			FName ID_Triggers;
//			FText NAME_Triggers;
//			FConstructorStatics()
//				: TriggerTextureObject(TEXT("/Engine/EditorResources/S_Trigger"))
//				, ID_Triggers(TEXT("Triggers"))
//				, NAME_Triggers(FText::AsCultureInvariant("Triggers"))
//			{
//			}
//		};
//		static FConstructorStatics ConstructorStatics;
//
//		SpriteComponent->Sprite = ConstructorStatics.TriggerTextureObject.Get();
//		SpriteComponent->RelativeScale3D = FVector(0.5f, 0.5f, 0.5f);
//		SpriteComponent->bHiddenInGame = false;
//		SpriteComponent->Sprite = ConstructorStatics.TriggerTextureObject.Get();
//		SpriteComponent->SpriteInfo.Category = ConstructorStatics.ID_Triggers;
//		SpriteComponent->SpriteInfo.DisplayName = ConstructorStatics.NAME_Triggers;
//		SpriteComponent->bIsScreenSizeScaled = true;
//	}
//#endif // WITH_EDITORONLY_DATA
}

void AP3SwitchActor::BeginPlay()
{
	Super::BeginPlay();
	
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (bDefaultOn)
		{
			Server_ToggleSwitch(true);
		}
	}
}

void AP3SwitchActor::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (CVarP3SwitchDebug.GetValueOnGameThread() != 0)
	{
		FString DebugString = FString::Printf(TEXT("%s"), bOn ? TEXT("On") : TEXT("Off"));

		const float Cooldown = Server_SwitchOnCooldownFinishSeconds - GetWorld()->GetTimeSeconds();

		if (Cooldown > 0)
		{
			DebugString += FString::Printf(TEXT(", Cooldown: %.2f"), Cooldown);
		}
		
		DrawDebugString(GetWorld(), GetActorLocation(), DebugString, nullptr, FColor::White, 0.0f, true);
	}
}

float AP3SwitchActor::TakeDamage(float DamageAmount, struct FDamageEvent const& DamageEvent, class AController* EventInstigator, AActor* DamageCauser)
{
	const float OutAppliedDamage = Super::TakeDamage(DamageAmount, DamageEvent, EventInstigator, DamageCauser);

	if (!bToggleByDamage || P3Core::IsP3NetModeClient(*this))
	{
		return OutAppliedDamage;
	}

	if (Server_ToggleByDamageTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(Server_ToggleByDamageTimerHandle);
	}

	// We need some delay here, so that if this damage is caused by something with physical, that can apply first
	// and this one(toggle by damage) can be ignored by CVarP3SwitchToggleCoolTimeSeconds
	GetWorld()->GetTimerManager().SetTimer(Server_ToggleByDamageTimerHandle, this, &AP3SwitchActor::OnToggleByDamageTimer, CVarP3SwitchToggleByDamageDelaySeconds.GetValueOnGameThread(), false);

	return OutAppliedDamage;
}

void AP3SwitchActor::Reset()
{
	Super::Reset();

	Server_NumToggled = 0;

	if (P3Core::IsP3NetModeDedicatedServer(*this))
	{
		if (IsSwitchOn() != bDefaultOn)
		{
			Server_ToggleSwitch(bDefaultOn);
		}
	}
}

void AP3SwitchActor::NetSerialize(FArchive& Archive)
{
	Super::NetSerialize(Archive);

	if (!Archive.IsLoading())
	{
		Archive << bOn;
	}
	else
	{
		bool bNewOn = false;

		Archive << bNewOn;

		if (bNewOn != bOn)
		{
			Client_OnToggleSwitch(bNewOn);
		}
	}
}

void AP3SwitchActor::OnToggleByDamageTimer()
{
	Server_ToggleSwitch(!IsSwitchOn());
}

void AP3SwitchActor::Client_OnToggleSwitch(bool bInOn)
{
	if (P3Core::IsP3NetModeDedicatedServer(*this))
	{
		ensure(0);
		return;
	}

	if (bOn == bInOn)
	{
		return;
	}

	bOn = bInOn;

	// TODO: maybe makes these server/client separated?
	OnToggleSwitch(bInOn);
	ReceiveToggleSwitchBP(bInOn);
}

void AP3SwitchActor::ToggleSwitchBP(bool bInOn)
{
	if (ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		Server_ToggleSwitch(bInOn);
	}
}

void AP3SwitchActor::Server_ToggleSwitch(bool bInOn)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (bOn == bInOn)
	{
		return;
	}

	if (MaxToggleCount >= 0 && Server_NumToggled >= MaxToggleCount)
	{
		P3JsonLog(Display, "Switch toggle denied. Max toggle count reached",
			TEXT("Switch"), GetName(), TEXT("MaxCount"), MaxToggleCount, TEXT("CurrentCount"), Server_NumToggled);
		return;
	}

	if (bInOn)
	{
		if (ToggleOnCooldownSeconds > 0)
		{
			const float Now = GetWorld()->GetTimeSeconds();

			if (Now < Server_SwitchOnCooldownFinishSeconds)
			{
				P3JsonLog(Verbose, "Switch toggle denied. Toggle On cooldown is not finished yet",
					TEXT("Switch"), GetName(), TEXT("Cooldown"), Server_SwitchOnCooldownFinishSeconds, TEXT("TimeLeft"), Server_SwitchOnCooldownFinishSeconds - Now);
				return;
			}

			Server_SwitchOnCooldownFinishSeconds = Now + ToggleOnCooldownSeconds;
		}
		else
		{
			Server_SwitchOnCooldownFinishSeconds = 0;
		}
	}

	++Server_NumToggled;

	UWorld* World = GetWorld();

	if (Server_LastToggleTime != 0.0f && World 
		&& World->GetTimeSeconds() - Server_LastToggleTime < CVarP3SwitchToggleCoolTimeSeconds.GetValueOnGameThread())
	{
		// In cool down stage
		return;
	}

	if (World && Server_ToggleByDamageTimerHandle.IsValid())
	{
		World->GetTimerManager().ClearTimer(Server_ToggleByDamageTimerHandle);
	}

	bOn = bInOn;
	Server_LastToggleTime = World ? World->GetTimeSeconds() : 0.0f;

	OnToggleSwitch(bInOn);
	ReceiveToggleSwitchBP(bInOn);

	Server_SetDirty(*this);
}

void AP3SwitchActor::Server_SetSignalReceiever(class AP3SignalReceiver* InSignalReceiver)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	SignalReceiver = InSignalReceiver;
}

void AP3SwitchActor::OnToggleSwitch(bool bInOn)
{
	OnSwitchToggleBP.Broadcast(bInOn);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (SignalReceiver)
		{
			SignalReceiver->Server_Signal(bInOn);
		}
	}
}


AP3HealthTriggeredSwitchActor::AP3HealthTriggeredSwitchActor()
{
	bNetLoadOnClient = false;
}

/**
 * Health triggered switch actor
 */

void AP3HealthTriggeredSwitchActor::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (WatchActor)
		{
			UP3HealthPointComponent* HealthComp = WatchActor->FindComponentByClass<UP3HealthPointComponent>();
			if (ensure(HealthComp))
			{
				HealthComp->OnChange.AddUniqueDynamic(this, &AP3HealthTriggeredSwitchActor::OnHealthChange);
			}
		}
	}
}

void AP3HealthTriggeredSwitchActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (WatchActor)
		{
			UP3HealthPointComponent* HealthComp = WatchActor->FindComponentByClass<UP3HealthPointComponent>();
			if (ensure(HealthComp))
			{
				HealthComp->OnChange.RemoveDynamic(this, &AP3HealthTriggeredSwitchActor::OnHealthChange);
			}
		}
	}
}

void AP3HealthTriggeredSwitchActor::OnHealthChange(class UP3HealthPointComponent* Component, int32 OldHealthPoint, int32 NewHealthPoint)
{
	if (!Component)
	{
		return;
	}

	const float MaxHealthPoint = Component->GetMaxHealthPoint();
	const float HealthPercent = (MaxHealthPoint > 0) ? 100.0f * (NewHealthPoint / MaxHealthPoint) : 0.0f;
	
	if (MinHealthPercent >= 0 && HealthPercent <= MinHealthPercent)
	{
		Server_ToggleSwitch(true);
	}
}


/** 
 * Shape Triggered Switch Actor (Server only!)
 */

AP3ShapeTriggeredSwitchBaseActor::AP3ShapeTriggeredSwitchBaseActor(const FObjectInitializer& ObjectInitializer)
{
	bNetLoadOnClient = false;

	// AP3ShapeTriggeredSwitchBaseActor is requesting UShapeComponent which is abstract, however it is responsibility
	// of a derived class to override this type with ObjectInitializer.SetDefaultSubobjectClass.
	CollisionComponent = CreateAbstractDefaultSubobject<UShapeComponent>(TEXT("CollisionComp"));
	if (CollisionComponent)
	{
		RootComponent = CollisionComponent;
		CollisionComponent->bHiddenInGame = true;
	}
}

void AP3ShapeTriggeredSwitchBaseActor::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (ensure(CollisionComponent))
		{
			CollisionComponent->OnComponentBeginOverlap.AddUniqueDynamic(this, &AP3ShapeTriggeredSwitchBaseActor::OnBeginOverlap);
			CollisionComponent->OnComponentEndOverlap.AddUniqueDynamic(this, &AP3ShapeTriggeredSwitchBaseActor::OnEndOverlap);
		}
	}
}

void AP3ShapeTriggeredSwitchBaseActor::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (CollisionComponent)
		{
			CollisionComponent->OnComponentBeginOverlap.RemoveDynamic(this, &AP3ShapeTriggeredSwitchBaseActor::OnBeginOverlap);
			CollisionComponent->OnComponentEndOverlap.RemoveDynamic(this, &AP3ShapeTriggeredSwitchBaseActor::OnEndOverlap);
		}
	}
}

void AP3ShapeTriggeredSwitchBaseActor::OnBeginOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	bool Triggered = false;

	if (TriggerFactions.Num() > 0)
	{
		AP3Character* Character = Cast<AP3Character>(OtherActor);
		
		if (Character && TriggerFactions.Contains(Character->GetFaction()))
		{
			Triggered = true;
		}
	}

	if (!Triggered && (TriggerGameplayTagsAny.Num() > 0 || TriggerGameplayTagsAll.Num() > 0))
	{
		IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(OtherActor);
		if (GameplayTagAsset)
		{
			const bool bHasAll = GameplayTagAsset->HasAllMatchingGameplayTags(TriggerGameplayTagsAll);
			const bool bHasAny = (TriggerGameplayTagsAny.Num() == 0) || GameplayTagAsset->HasAnyMatchingGameplayTags(TriggerGameplayTagsAny);

			if (bHasAll && bHasAny)
			{
				Triggered = true;
			}
		}
	}

	if (Triggered)
	{
		TriggeredActors.Add(OtherActor);

		if (TriggeredActors.Num() >= MinimumTriggerActorsCount)
		{
			Server_ToggleSwitch(true);

			Server_ReceiveOverlapTriggered(OverlappedComponent, OtherActor, OtherComp);
		}
	}
}

void AP3ShapeTriggeredSwitchBaseActor::OnEndOverlap(UPrimitiveComponent* OverlappedComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
	if (IsSwitchOn())
	{
		// See if everyone has left
		TriggeredActors.Remove(OtherActor);

		if (TriggeredActors.Num() < MinimumTriggerActorsCount)
		{
			// Looks like room is empty enough
			Server_ToggleSwitch(false);
		}
	}
}


AP3BoxTriggeredSwitchActor::AP3BoxTriggeredSwitchActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<UBoxComponent>(TEXT("CollisionComp")))
{
	UBoxComponent* BoxCollisionComponent = CastChecked<UBoxComponent>(GetCollisionComponent());

	BoxCollisionComponent->ShapeColor = P3TriggerBaseColor;
	BoxCollisionComponent->InitBoxExtent(FVector(40.0f, 40.0f, 40.0f));
	BoxCollisionComponent->SetCollisionProfileName(P3TriggerCollisionProfileName);
}


AP3SphereTriggeredSwitchActor::AP3SphereTriggeredSwitchActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer.SetDefaultSubobjectClass<USphereComponent>(TEXT("CollisionComp")))
{
	USphereComponent* SphereCollisionComponent = CastChecked<USphereComponent>(GetCollisionComponent());

	SphereCollisionComponent->ShapeColor = P3TriggerBaseColor;
	SphereCollisionComponent->InitSphereRadius(100.0f);
	SphereCollisionComponent->SetCollisionProfileName(P3TriggerCollisionProfileName);
}


AP3InteractableSwitchActor::AP3InteractableSwitchActor()
{
	InteractableComponent = CreateDefaultSubobject<UP3InteractableComponent>(TEXT("InteractableComponent"));
}

void AP3InteractableSwitchActor::BeginPlay()
{
	Super::BeginPlay();

	if (InteractableComponent && P3Core::IsP3NetModeServerInstance(*this))
	{
		InteractableComponent->Server_OnInteracted.AddUniqueDynamic(this, &AP3InteractableSwitchActor::Server_OnInteracted);
	}
}

void AP3InteractableSwitchActor::OnToggleSwitch(bool bInOn)
{
	Super::OnToggleSwitch(bInOn);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (InteractableComponent)
		{
			if ((!bAllowInteractionDuringOn && bInOn)
				|| (!bAllowInteractionDuringOff && !bInOn))
			{
				InteractableComponent->Server_SetInteractionAllowed(false);
			}
			else
			{
				InteractableComponent->Server_SetInteractionAllowed(true);
			}
		}
	}
}

void AP3InteractableSwitchActor::Server_OnInteracted(class AActor* Interactor)
{
	Server_ToggleSwitch(!IsSwitchOn());
}

AP3TimerSwitch::AP3TimerSwitch()
{
	bNetLoadOnClient = false;
}

void AP3TimerSwitch::BeginPlay()
{
	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_StartTimer();
	}
}

void AP3TimerSwitch::OnToggleSwitch(bool bInOn)
{
	Super::OnToggleSwitch(bInOn);

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_StartTimer();
	}
}

void AP3TimerSwitch::Server_StartTimer()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (TurnOnTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(TurnOnTimerHandle);
	}

	if (TurnOffTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(TurnOffTimerHandle);
	}

	if (IsSwitchOn() && TurnOffTimeSeconds >= 0)
	{
		GetWorld()->GetTimerManager().SetTimer(TurnOffTimerHandle, this, &AP3TimerSwitch::Server_OnTurnOffTimer, TurnOffTimeSeconds);
	}
	else if (!IsSwitchOn() && TurnOnTimeSeconds >= 0)
	{
		GetWorld()->GetTimerManager().SetTimer(TurnOnTimerHandle, this, &AP3TimerSwitch::Server_OnTurnOnTimer, TurnOnTimeSeconds);
	}
}

void AP3TimerSwitch::Server_OnTurnOnTimer()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	TurnOnTimerHandle.Invalidate();

	Server_ToggleSwitch(true);
}

void AP3TimerSwitch::Server_OnTurnOffTimer()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	TurnOffTimerHandle.Invalidate();

	Server_ToggleSwitch(false);
}
