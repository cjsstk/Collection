// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "P3StoreInterface.h"
#include "P3PushComponent.generated.h"


UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class P3_API UP3PushComponent : public UActorComponent, public IP3ComponentInterface
{
	GENERATED_BODY()

public:	
	UP3PushComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** IP3StoreInterface */
	virtual void NetSerialize(FArchive& Archive) override;

	void SetPushTargetActor(AActor* Actor);
	AActor* GetPushTargetActor() const { return CurrentTargetActor; }

	bool IsLockPushDirection() const { return bLockPushDirection; }

	void OnMoveBlockedBy(const FHitResult& Impact);

	/** 
	 * Called from movement controller
	 * return true if handled by character, otherwise movement controller handles impact
	 */
	bool ApplyImpactPhysicsForces(const FHitResult& Impact, const FVector& ImpactAcceleration, const FVector& ImpactVelocity, float MaxSpeed);

	//bool IsPushing() const { return CurrentTargetActor != nullptr; }
	bool IsRotateChracterTowardPushDirectionEnabled() const;
	FVector GetPushDirection() const;

	float GetPushMovementSpeed(const AActor* TargetActor) const;

protected:
	virtual void BeginPlay() override;

	/** 
	 * Last Impact from character movement component 
	 * Actors which doesn't have PushableComponent is ignored
	 */
	FHitResult LastPushableImpact;

	/** Time of last impact */
	float LastPushableImpactTime;

	/** Pushing target */
	UPROPERTY(Transient)
	AActor* CurrentTargetActor;

	/** Cache lock property from target actor */
	bool bLockPushDirection = false;
};
