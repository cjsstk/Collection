// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ChildActorComponent.h"
#include "P3StoreInterface.h"
#include "P3FruitComponent.generated.h"

/**
 * Drop something from Tree
 */
UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class P3_API UP3FruitComponent : public UChildActorComponent
{
	GENERATED_BODY()
	
public:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	UFUNCTION()
	void Server_Despawn();

	UFUNCTION()
	void Server_OnTreeTakeAnyDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, AActor* DamageCauser);

	UFUNCTION()
	void Server_OnFruitTakeAnyDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, AActor* DamageCauser);

	void Server_TakeDamage();

	/** Possibility of spawning child actor in 1/10000 */
	UPROPERTY(EditDefaultsOnly, Category = "Fruit")
	int32 SpawnChancePer10000 = 10000;

	/** How long fruit actor will stay in world after drop? 0 <= means forever */
	UPROPERTY(EditDefaultsOnly, Category = "Fruit")
	float FruitActorLifeSpanSeconds = 30;

	bool Server_bDespawn = false;
	bool Server_bDropped = false;
};
