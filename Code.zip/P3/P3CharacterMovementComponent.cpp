// Copyright 2018 XL Games, Inc. All Rights Reserved.

#include "P3CharacterMovementComponent.h"

#include "Animation/AnimInstance.h"
#include "Camera/PlayerCameraManager.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "DrawDebugHelpers.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/Character.h"
#include "GameFramework/GameNetworkManager.h"
#include "GameFramework/PhysicsVolume.h"
#include "GameFramework/PlayerController.h"
#include "Navigation/PathFollowingComponent.h"
#include "Net/PerfCountersHelpers.h"
#include "PhysicalMaterials/PhysicalMaterial.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "P3Character.h"
#include "P3CharacterEffectComponent.h"
#include "P3Core.h"
#include "P3DrawDebugHelpers.h"
#include "P3GameState.h"
#include "P3GameUserSettings.h"
#include "P3Localization.h"
#include "P3Log.h"
#include "P3Physics.h"
#include "P3PhysicalMaterial.h"
#include "P3PlayerController.h"
#include "P3PushableComponent.h"
#include "P3PushComponent.h"
#include "P3ServerWorld.h"
#include "P3StaminaPointComponent.h"
#include "P3World.h"
#include "P3WorldNetCore.h"

static TAutoConsoleVariable<int32> CVarP3MovementDebug(
    TEXT("p3.movementDebug"),
    0,
    TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);


static TAutoConsoleVariable<int32> CVarP3SlidingDebug(
	TEXT("p3.slidingDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

TAutoConsoleVariable<int32> CVarP3CharacterMovementServerDriven(
    TEXT("p3.characterMovementServerDriven"),
    1,
    TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3MovementCombine(
	TEXT("p3.movementCombine"),
	1,
	TEXT("1: enable combine, 0: disable combine"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ClimbDownForwardSweepDebug(
    TEXT("p3.movementClimbDownForwardSweep"),
    150,
    TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ClimbDownDownwardSweepDebug(
    TEXT("p3.movementClimbDownDownwardSweep"),
    300,
    TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3ClimbDownBackwardSweepDebug(
    TEXT("p3.movementClimbDownBackwardSweep"),
    100,
    TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3MovementSyncBase(
	TEXT("p3.movementSyncBase"),
	1,
	TEXT("0: disable character movement base component sync. 1: enable"), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3GlidingDebug(
	TEXT("p3.glidingDebug"),
	0,
	TEXT("1: enable debug. 0: disable debug"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3GlidingCheckSphereRadius(
	TEXT("p3.glidingCheckSphereRadius"),
	5.0f,
	TEXT("Radius of sphere on check gliding height"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3GlidingEnableHeight(
	TEXT("p3.glidingEnableHeight"),
	100.0f,
	TEXT("Can Glide height"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SlidingStuckTickPeriod(
	TEXT("p3.slidingStuckTickPeriod"),
	0.1f,
	TEXT("Sliding check tick period in seconds"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SlidingStuckDistance(
	TEXT("p3.slidingStuckDistance"),
	10.0f,
	TEXT("If actor doesn't move more than this, it's stuck"), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SlidingMaxSpeedMultiplier(
	TEXT("p3.slidingMaxSpeedMultiplier"),
	1.2f,
	TEXT(""), ECVF_Cheat);

//static TAutoConsoleVariable<float> CVarP3SlidingSlipperyFactor(
//	TEXT("p3.slidingSlipperyFactor"),
//	1.f/0.7f,
//	TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SlidingSlopeBrakeFactor(
	TEXT("p3.slidingSlopeBrakeFactor"),
	1.0f,
	TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SlidingUpHillBrakeFactor(
	TEXT("p3.slidingUpHillBrakeFactor"),
	1.0f,
	TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<float> CVarP3SlidingSlopeAccelerationMultiplier(
	TEXT("p3.slidingSlopeAccelerationMultiplier"),
	0.1f,
	TEXT(""), ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarP3NoRotationDuringFalling(
	TEXT("p3.movementNoRotationDuringFalling"),
	1,
	TEXT("1: Do not allow rotate character during falling(jumping)"), ECVF_Cheat);


static TAutoConsoleVariable<int32> CVarP3CharacterBasedControlOnSliding(
	TEXT("p3.CharacterBasedControlOnSliding"),
	1,
	TEXT("Control is based on character's orientation"), ECVF_Cheat);


static const FString PerfCounter_NumServerMoves = TEXT("NumServerMoves");
static const FString PerfCounter_NumServerMoveCorrections = TEXT("NumServerMoveCorrections");

template<typename TEnum>
static FORCEINLINE FString GetEnumValueAsString(const FString& Name, TEnum Value)
{
  const UEnum* enumPtr = FindObject<UEnum>(ANY_PACKAGE, *Name, true);
    if (!enumPtr)
	{
	    return FString("Invalid");
	}
    return enumPtr->GetNameByValue((int64)Value).ToString();
}

UP3CharacterMovementComponent::UP3CharacterMovementComponent()
{
	SlidableFloorAngle = 40.0f;
	SlidableFloorZ = FMath::Cos(FMath::DegreesToRadians(SlidableFloorAngle));
	SlidingRotationRate = FRotator(70.f, 75.0f, 0.f);

	RotationRate = FRotator(360.f, 360.0f, 0.0f);

	WalkingToClimbingTransitionDuration = 0.2f;
	GlidingAirDrag.Set(0, 0.1f, 0.8f);
	GlidingRotationRate = FRotator(0.0f, 70.0f, 0.0f);
	StrollSpeedMultiplier = 0.25f;
	SprintSpeedMultiplier = 1.5f;
	CrippledRunSpeedMultiplier = 0.2f;
	ClimbRotationRate = FRotator(100, 100, 100);
	MaxClimbSpeed = 100;
	ClimbJumpZVelocity = 600;
	WalkToClimbX = 0.8f;
	MaxGlidingSpeed = 600;
	MaxSlidingSpeed = 1000;
	bTouchForceScaledToMass = false;

	P3MovementMode = P3Movement_None;

	bSprintingPressed = false;
	bSprintDisabled = false;
	bClimbDownAvailable = false;

	CustomWalkSpeedMultiplier = 1.0f;
	CustomWalkingRotator = FRotator(0, 0, 0);
	bHasCustomWalkingRotator = false;
}

void UP3CharacterMovementComponent::OnRegister()
{
	Super::OnRegister();

	AP3Character* Character = GetP3Character();

	if (Character)
	{
		Character->OnInputStartSprint.AddUniqueDynamic(this, &UP3CharacterMovementComponent::OnStartSprint);
		Character->OnInputStopSprint.AddUniqueDynamic(this, &UP3CharacterMovementComponent::OnStopSprint);

		// DYLEE NOTE P3-3209 작업 영역 분리
		if (!CVarP3ActionDataDriven.GetValueOnGameThread())
		{
			UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
			if (ensure(ActionComp))
			{
				ActionComp->RegisterAction(EPawnActionType::ClimbStart, EPawnActionCategory::Movement, NewObject<UP3ClimbStartPawnAction>());
				ActionComp->RegisterAction(EPawnActionType::ClimbJump, EPawnActionCategory::Movement, NewObject<UP3ClimbJumpPawnAction>());
				ActionComp->RegisterAction(EPawnActionType::ClimbDown, EPawnActionCategory::Movement,
					UP3PlayMontagePawnAction::NewAction(Character->GetAnimMontages().ClimbDown, UP3PlayMontagePawnAction::Flags_AutonomousHeadStart));
				ActionComp->RegisterAction(EPawnActionType::ClimbEnd, EPawnActionCategory::Movement, NewObject<UP3ClimbEndPawnAction>());
				ActionComp->RegisterAction(EPawnActionType::ParkourClimbUp, EPawnActionCategory::Movement, NewObject<UP3ParkourClimbUp>());
			}
		}
		else
		{
		}
	}
}

void UP3CharacterMovementComponent::OnUnregister()
{
	AP3Character* Character = GetP3Character();

	if (Character)
	{
		Character->OnInputStartSprint.RemoveDynamic(this, &UP3CharacterMovementComponent::OnStartSprint);
		Character->OnInputStopSprint.RemoveDynamic(this, &UP3CharacterMovementComponent::OnStopSprint);
	}

	Super::OnUnregister();
}

void UP3CharacterMovementComponent::TickComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("UP3CharacterMovementComponent_TickComponent"), STAT_UP3CharacterMovementComponent_TickComponent, STATGROUP_P3);

	AP3Character* Character = GetP3Character();
	if (Character)
	{
		Character->OnPreMovementTick();
	}

	if (CVarP3CharacterMovementServerDriven.GetValueOnGameThread() != 0)
	{
		TickCharacterComponent(DeltaTime, TickType, ThisTickFunction);
	}
	else
	{
		Super::TickComponent(DeltaTime, TickType, ThisTickFunction);
	}

	if (CanClimbLeftSeconds > 0.0f)
	{
		CanClimbLeftSeconds > DeltaTime ? SetDelayTimeForRetryClimb(CanClimbLeftSeconds - DeltaTime) : 
            SetDelayTimeForRetryClimb(0.0f);
	}

	if (bCanClimb && P3MovementMode == P3Movement_None && (ClimbingStatus.bConsiderClimbing || IsClimbDownActionInProgress()))
	{
		ClimbingStatus.bConsiderClimbing = false;
		if (bClimbAllowed)
		{
			TickConsiderClimbing(DeltaTime);
		}
	}
	else if (bCanClimb && MovementMode == MOVE_Walking)
	{
		TickConsiderClimbDown(DeltaTime);
	}

	if (MovementMode == MOVE_Falling)
	{
		TickCalcFallingTime(DeltaTime);
	}
	else
	{
		CurrentFallingTimeAgeSeconds = 0.0f;
	}

	if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
	{
		if (Character)
		{
			const FVector LocationDiff = Character->GetActorLocation() - Debug_LastLocation;
			const FVector ActualWorldVelocity = LocationDiff / FMath::Max(0.0001f, DeltaTime);
			const FVector ActualVelocity = Character->GetActorQuat().UnrotateVector(ActualWorldVelocity);

			Debug_LastLocation = Character->GetActorLocation();

			Character->AddDebugString(FString::Printf(TEXT("MovementMode: %s, Custom: %s"),
				*EnumToStringShort(EMovementMode, MovementMode),
				*EnumToStringShort(EP3MovementMode, P3MovementMode)));

			Character->AddDebugString(FString::Printf(TEXT("Velocity: %.2f, %.2f, %.2f(%.2f), MaxSpeed: %.2f, Multiplier: %.2f"),
				Velocity.X, Velocity.Y, Velocity.Z, Velocity.Size(), GetMaxSpeed(), CustomWalkSpeedMultiplier));

			Character->AddDebugString(FString::Printf(TEXT("Actual Velocity: %.2f, %.2f, %.2f (%.2f)"),
				ActualVelocity.X, ActualVelocity.Y, ActualVelocity.Z, ActualVelocity.Size()));

			Character->AddDebugString(FString::Printf(TEXT("Floor: %s, %s, %.0f Degree, Physics material: %s, Surface: %d"),
				CurrentFloor.IsWalkableFloor() ? TEXT("Walkable") : TEXT("Not Walkable"),
				IsSlidableFloor() ? TEXT("Slidable") : TEXT("Not Slidable"),
				FMath::RadiansToDegrees(FMath::Acos(CurrentFloor.HitResult.ImpactNormal.Z)),
				CurrentFloor.HitResult.PhysMaterial.IsValid() ? *CurrentFloor.HitResult.PhysMaterial->GetName() : TEXT("NULL"),
				CurrentFloor.HitResult.PhysMaterial.IsValid() ? (int32)CurrentFloor.HitResult.PhysMaterial->SurfaceType : -1));

			Character->AddDebugString(FString::Printf(TEXT("WalkableFloorZ: %.2f, ImpactNormalZ: %.2f, SlopeRatio: %.2f, Direction: %s, SlopeSpeedMultiplier: %.2f"),
				GetWalkableFloorZ(), CurrentFloor.HitResult.ImpactNormal.Z,
				GetSlopeRatio(), IsSlopeUpward() ? TEXT("Uphill") : TEXT("Downhill"),
				IsSlopeUpward() ? 1.f - FMath::Clamp(InclineSlowDown, 0.f, 1.f) * GetSlopeRatio() : 0.f));

			Character->AddDebugString(FString::Printf(TEXT("JumpCurrentCount: %d, bPressedJump: %d"),\
				Character->JumpCurrentCount, Character->bPressedJump));

			Character->AddDebugString(FString::Printf(TEXT("ClimbLeftTime: %.2f"), CanClimbLeftSeconds));
			Character->AddDebugString(FString::Printf(TEXT("CurrentFallingTime: %.2f"), CurrentFallingTimeAgeSeconds));

			const FVector TopOfCapsule = GetActorLocation() + FVector(0.f, 0.f, CharacterOwner->GetSimpleCollisionHalfHeight());
			float HeightOffset = 0.f;
			// Forward Vector Debug
			{
				const FColor DebugColor = FColor::Red;
				HeightOffset += 15.f;
				const FVector DebugLocation = TopOfCapsule + FVector(0.f, 0.f, HeightOffset);
				DrawDebugDirectionalArrow(GetWorld(), DebugLocation, DebugLocation + UpdatedComponent->GetForwardVector()*100.0f,
					100.f, DebugColor, false, -1.f, (uint8)'\000', 2.f);

				FString DebugText = FString::Printf(TEXT("ForwardVec | Velocity : %.2f "), UpdatedComponent->GetForwardVector() | Velocity);
				DrawDebugString(GetWorld(), DebugLocation + FVector(0.f, 0.f, 5.f), DebugText, nullptr, DebugColor, 0.f, true);
			}
			// Velocity Debug
			{
				const FColor DebugColor = FColor::Green;
				HeightOffset += 15.f;
				const FVector DebugLocation = TopOfCapsule + FVector(0.f, 0.f, HeightOffset);
				DrawDebugDirectionalArrow(GetWorld(), DebugLocation, DebugLocation + Velocity,
					100.f, DebugColor, false, -1.f, (uint8)'\000', 2.f);

				FString DebugText = FString::Printf(TEXT("Velocity: %s (Speed: %.2f) (Max: %.2f)"), *Velocity.ToCompactString(), Velocity.Size(), GetMaxSpeed());
				DrawDebugString(GetWorld(), DebugLocation + FVector(0.f, 0.f, 5.f), DebugText, nullptr, DebugColor, 0.f, true);
			}
			// Effective Acceleration Debug
			{
				const FColor DebugColor = FColor::Yellow;
				HeightOffset += 15.f;
				const float MaxAccelerationLineLength = 200.f;
				const float CurrentMaxAccel = GetMaxAcceleration();
				const float CurrentAccelAsPercentOfMaxAccel = CurrentMaxAccel > 0.f ? EffectiveAccel.Size() / CurrentMaxAccel : 1.f;
				const FVector DebugLocation = TopOfCapsule + FVector(0.f, 0.f, HeightOffset);
				DrawDebugDirectionalArrow(GetWorld(), DebugLocation,
					DebugLocation + EffectiveAccel.GetSafeNormal(SMALL_NUMBER) * CurrentAccelAsPercentOfMaxAccel * MaxAccelerationLineLength,
					25.f, DebugColor, false, -1.f, (uint8)'\000', 2.f);

				FString DebugText = FString::Printf(TEXT("Effective Acceleration: %s (size: %.2f)"), *Acceleration.ToCompactString(), EffectiveAccel.Size());
				DrawDebugString(GetWorld(), DebugLocation + FVector(0.f, 0.f, 5.f), DebugText, nullptr, DebugColor, 0.f, true);
			}
		}
	}
}

// This function mimics UCharacterMovementComponent::TickComponent with P3 network
void UP3CharacterMovementComponent::TickCharacterComponent(float DeltaTime, enum ELevelTick TickType, FActorComponentTickFunction *ThisTickFunction)
{
	SCOPED_NAMED_EVENT(UCharacterMovementComponent_TickComponent, FColor::Yellow);
	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3CharacterMovementComponent_TickCharacterComponent"), STAT_P3CharacterMovementComponent_TickCharacterComponent, STATGROUP_P3);
	//SCOPE_CYCLE_COUNTER(STAT_CharacterMovement);
	//SCOPE_CYCLE_COUNTER(STAT_CharacterMovementTick);
	//CSV_SCOPED_TIMING_STAT(CharacterMovement, CharacterMovementTick);

	const FVector InputVector = ConsumeInputVector();
	if (!HasValidData() || ShouldSkipUpdate(DeltaTime))
	{
		return;
	}

	UPawnMovementComponent::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// Super tick may destroy/invalidate CharacterOwner or UpdatedComponent, so we need to re-check.
	if (!HasValidData())
	{
		return;
	}

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		SendClientAdjustment();
	}

	// See if we fell out of the world.
	AP3Character* P3Character = Cast<AP3Character>(CharacterOwner);
	const bool bIsSimulatingPhysics = UpdatedComponent->IsSimulatingPhysics()
		|| (P3Character && P3Character->IsRagdollizedBP());
	if (CharacterOwner->Role == ROLE_Authority && (!bCheatFlying || bIsSimulatingPhysics) && !CharacterOwner->CheckStillInWorld())
	{
		return;
	}

	// We don't update if simulating physics (eg ragdolls).
	if (bIsSimulatingPhysics)
	{
		// Update camera to ensure client gets updates even when physics move him far away from point where simulation started
		if (CharacterOwner->Role == ROLE_AutonomousProxy && IsNetMode(NM_Client))
		{
			APlayerController* PC = Cast<APlayerController>(CharacterOwner->GetController());
			APlayerCameraManager* PlayerCameraManager = (PC ? PC->PlayerCameraManager : NULL);
			if (PlayerCameraManager != NULL && PlayerCameraManager->bUseClientSideCameraUpdates)
			{
				PlayerCameraManager->bShouldSendClientSideCameraUpdate = true;
			}
		}

		ClearAccumulatedForces();
		return;
	}

	AvoidanceLockTimer -= DeltaTime;

	if (CharacterOwner->Role > ROLE_SimulatedProxy)
	{
		//SCOPE_CYCLE_COUNTER(STAT_CharacterMovementNonSimulated);

		// If we are a client we might have received an update from the server.
		//const bool bIsClient = (CharacterOwner->Role == ROLE_AutonomousProxy && IsNetMode(NM_Client));
		const bool bIsClient = CharacterOwner->Role == ROLE_AutonomousProxy && CharacterOwner->IsLocallyControlled();
		if (bIsClient)
		{
			ClientUpdatePositionAfterServerUpdate();
		}

		// Allow root motion to move characters that have no controller.
		if (CharacterOwner->IsLocallyControlled()/* || (!CharacterOwner->Controller && bRunPhysicsWithNoController)*/ 
			/*|| (!CharacterOwner->Controller && CharacterOwner->IsPlayingRootMotion()) comment-out: p3 server doesn't have PC, and this makes root motion too fast(double tick)*/)
		{
			{
				//SCOPE_CYCLE_COUNTER(STAT_CharUpdateAcceleration);

				// We need to check the jump state before adjusting input acceleration, to minimize latency
				// and to make sure acceleration respects our potentially new falling state.
				CharacterOwner->CheckJumpInput(DeltaTime);

				// apply input to acceleration
				Acceleration = ScaleInputAcceleration(ConstrainInputAcceleration(InputVector));
				AnalogInputModifier = ComputeAnalogInputModifier();
			}

			if (CharacterOwner->Role == ROLE_Authority)
			{
				PerformMovement(DeltaTime);
			}
			else if (bIsClient)
			{
				ReplicateMoveToServer(DeltaTime, Acceleration);
			}
		}
		else if (CharacterOwner->GetRemoteRole() == ROLE_AutonomousProxy)
		{
			// Server ticking for remote client.
			// Between net updates from the client we need to update position if based on another object,
			// otherwise the object will move on intermediate frames and we won't follow it.
			MaybeUpdateBasedMovement(DeltaTime);
			MaybeSaveBaseLocation();

			// Smooth on listen server for local view of remote clients. We may receive updates at a rate different than our own tick rate.
			static IConsoleVariable* CVarNetEnableListenServerSmoothing = 
				IConsoleManager::Get().FindConsoleVariable(TEXT("p.NetEnableListenServerSmoothing"));
			if (CVarNetEnableListenServerSmoothing 
				&& CVarNetEnableListenServerSmoothing->GetInt() != 0
				&& !bNetworkSmoothingComplete && IsNetMode(NM_ListenServer))
			{
				SmoothClientPosition(DeltaTime);
			}
		}
	}
	else if (CharacterOwner->Role == ROLE_SimulatedProxy)
	{
		if (bShrinkProxyCapsule)
		{
			AdjustProxyCapsuleSize();
		}
		SimulatedTick(DeltaTime);
	}

	if (bUseRVOAvoidance)
	{
		UpdateDefaultAvoidance();
	}

	if (bEnablePhysicsInteraction)
	{
		//SCOPE_CYCLE_COUNTER(STAT_CharPhysicsInteraction);
		ApplyDownwardForce(DeltaTime);
		ApplyRepulsionForce(DeltaTime);
	}

#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
	static IConsoleVariable* CVarVisualizeMovement =
		IConsoleManager::Get().FindConsoleVariable(TEXT("p.VisualizeMovement"));

	const bool bVisualizeMovement = (CVarVisualizeMovement && CVarVisualizeMovement->GetInt() > 0);
	if (bVisualizeMovement)
	{
		VisualizeMovement();
	}
#endif // !(UE_BUILD_SHIPPING || UE_BUILD_TEST)

}

void UP3CharacterMovementComponent::SetMovementMode(EMovementMode NewMovementMode, uint8 NewCustomMode /*= 0*/)
{
	if (P3MovementMode == P3Movement_Climbing && NewMovementMode == MOVE_Falling)
	{
        SetDelayTimeForRetryClimb(0.6f);
	}
	else if (NewMovementMode == MOVE_Walking)
	{
        SetDelayTimeForRetryClimb(0.0f);
	}

	if (P3MovementMode != NewCustomMode)
	{
		P3MovementMode = static_cast<EP3MovementMode>(NewCustomMode);

		ClimbingStatus.bIsLandingOnRoof = false;

		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			UE_LOG(P3Log, Display, TEXT("Set MovementMode: %s, Custom: %s"), 
				*GetEnumValueAsString<EMovementMode>("EMovementMode", NewMovementMode),
				*GetEnumValueAsString<EP3MovementMode>("EP3MovementMode", P3MovementMode));
		}
	}

	Super::SetMovementMode(NewMovementMode, NewCustomMode);
}

void UP3CharacterMovementComponent::SetUpdatedComponent(USceneComponent* NewUpdatedComponent)
{
	UPrimitiveComponent* OldComponent = Cast<UPrimitiveComponent>(UpdatedComponent);

	if (OldComponent)
	{
		OldComponent->OnComponentHit.RemoveDynamic(this, &UP3CharacterMovementComponent::OnHit);
	}

	Super::SetUpdatedComponent(NewUpdatedComponent);

	UPrimitiveComponent* NewComponent = Cast<UPrimitiveComponent>(UpdatedComponent);

	if (NewComponent)
	{
		NewComponent->OnComponentHit.AddUniqueDynamic(this, &UP3CharacterMovementComponent::OnHit);
	}
}

float UP3CharacterMovementComponent::GetMaxSpeed() const
{
	float MaxSpeed = 0.0f;

	if (!bMoveAllowed)
	{
		return 0.0f;
	}

	switch (P3MovementMode)
	{
	case P3Movement_None:
	{
		float SpeedMultiplier = 1.0f;
		if (bStroll)
		{
			SpeedMultiplier = StrollSpeedMultiplier;
		}
		else if (bSprintingPressed && !bSprintDisabled)
		{
			SpeedMultiplier *= SprintSpeedMultiplier;
		}
		if (bCrippled)
		{
			SpeedMultiplier *= CrippledRunSpeedMultiplier;
		}

		{
			switch (MovementMode)
			{
			case MOVE_Walking:
			case MOVE_NavWalking:
			{
				MaxSpeed = IsCrouching() ? MaxWalkSpeedCrouched : MaxWalkSpeed;
				AP3Character* Character = GetP3Character();
				if (Character && Character->IsCarryingDownedCharacter())
				{
					MaxSpeed = MaxCarryingDownedCharacterSpeed;
				}
				break;
			}
			case MOVE_Falling:
			{
				MaxSpeed = MaxWalkSpeed;
				break;
			}
			case MOVE_Swimming:
			{
				MaxSpeed = MaxSwimSpeed;
				break;
			}
			case MOVE_Flying:
			{
				MaxSpeed = MaxFlySpeed;
				break;
			}
			case MOVE_Custom:
			{
				MaxSpeed = MaxCustomMovementSpeed;
				break;
			}
			case MOVE_None:
			default:
				MaxSpeed = 0.f;
			}
		}

		MaxSpeed = MaxSpeed * SpeedMultiplier * CustomWalkSpeedMultiplier;
		break;
	}
	case P3Movement_Climbing:
		MaxSpeed = MaxClimbSpeed;
		break;
	case P3Movement_Gliding:
		MaxSpeed = MaxGlidingSpeed;
		break;
	case P3Movement_Sliding:
		MaxSpeed = MaxSlidingSpeed * CVarP3SlidingMaxSpeedMultiplier.GetValueOnGameThread();
		break;
	default:
		ensure(0);
		MaxSpeed = Super::GetMaxSpeed();
	}

	return MaxSpeed;
}

bool UP3CharacterMovementComponent::IsMovingOnGround() const
{
	if ((P3MovementMode == P3Movement_Sliding) && UpdatedComponent)
	{
		return true;
	}

	return Super::IsMovingOnGround();
}

void UP3CharacterMovementComponent::PhysicsRotation(float DeltaTime)
{
	if (P3MovementMode == P3Movement_Climbing)
	{
		if (!HasValidData() || ClimbingStatus.ClimbingWallNormal.ContainsNaN() || (!CharacterOwner->Controller && !bRunPhysicsWithNoController))
		{
			return;
		}
		const FRotator CurrentRotation = UpdatedComponent->GetComponentRotation(); // Normalized
		CurrentRotation.DiagnosticCheckNaN(TEXT("UP3CharacterMovementComponent::PhysicsRotation(): CurrentRotation"));

		TGuardValue<FRotator> RotationRateYawGuard(RotationRate, ClimbRotationRate);

		FRotator DeltaRot = GetDeltaRotation(DeltaTime);
		DeltaRot.DiagnosticCheckNaN(TEXT("UP3CharacterMovementComponent::PhysicsRotation(): GetDeltaRotation"));

		FRotator DesiredRotation = (-ClimbingStatus.ClimbingWallNormal).Rotation();

		// Accumulate a desired new rotation.
		const float AngleTolerance = 1e-3f;

		if (!CurrentRotation.Equals(DesiredRotation, AngleTolerance))
		{
			// PITCH
			if (!FMath::IsNearlyEqual(CurrentRotation.Pitch, DesiredRotation.Pitch, AngleTolerance))
			{
				DesiredRotation.Pitch = FMath::FixedTurn(CurrentRotation.Pitch, DesiredRotation.Pitch, DeltaRot.Pitch);
			}

			// YAW
			if (!FMath::IsNearlyEqual(CurrentRotation.Yaw, DesiredRotation.Yaw, AngleTolerance))
			{
				DesiredRotation.Yaw = FMath::FixedTurn(CurrentRotation.Yaw, DesiredRotation.Yaw, DeltaRot.Yaw);
			}

			// ROLL
			if (!FMath::IsNearlyEqual(CurrentRotation.Roll, DesiredRotation.Roll, AngleTolerance))
			{
				DesiredRotation.Roll = FMath::FixedTurn(CurrentRotation.Roll, DesiredRotation.Roll, DeltaRot.Roll);
			}

			// Set the new rotation.
			DesiredRotation.DiagnosticCheckNaN(TEXT("UP3CharacterMovementComponent::PhysicsRotation(): DesiredRotation"));
			MoveUpdatedComponent(FVector::ZeroVector, DesiredRotation, true);
		}
	}
	else if (MovementMode == MOVE_Walking && bHasCustomWalkingRotator)
	{
		MoveUpdatedComponent(FVector::ZeroVector, CustomWalkingRotator, true);
	}
	else
	{
		Super::PhysicsRotation(DeltaTime);

		if ((IsMovingOnGround() && bUseGroundAlignment) ||
			(CustomMovementMode == P3Movement_Sliding))
		{
			FCollisionShape Sphere;
			Sphere.SetSphere(50.0f);

			FCollisionQueryParams Params;
			Params.AddIgnoredActor(GetCharacterOwner());

			FHitResult FrontHitResult;
			FHitResult RearHitResult;

			FCollisionResponseParams Response;
			Response.CollisionResponse = UpdatedComponent->GetCollisionResponseToChannels();

			const FVector FrontSweepStart = UpdatedComponent->GetComponentToWorld().TransformPosition(GroundAlignmentFrontLocation);
			const FVector FrontSweepEnd = UpdatedComponent->GetComponentToWorld().TransformPosition(GroundAlignmentFrontLocation + FVector(0, 0, -GroundAlignmentFrontSweepDistance));
			const FVector RearSweepStart = UpdatedComponent->GetComponentToWorld().TransformPosition(GroundAlignmentRearLocation);
			const FVector RearSweepEnd = UpdatedComponent->GetComponentToWorld().TransformPosition(GroundAlignmentRearLocation + FVector(0, 0, -GroundAlignmentRearSweepDistance));

			bool bFrontSweepHit = GetWorld()->SweepSingleByChannel(FrontHitResult, FrontSweepStart, FrontSweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);
			bool bRearSweepHit = GetWorld()->SweepSingleByChannel(RearHitResult, RearSweepStart, RearSweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

			if (bFrontSweepHit && bRearSweepHit)
			{
				const FVector HitLine = (FrontHitResult.Location - RearHitResult.Location);
				FRotator AlignedRotation = HitLine.Rotation();
				AlignedRotation.Pitch = FMath::ClampAngle(AlignedRotation.Pitch, -70.0f, 70.0f);

				const FRotator CurrentRotation = UpdatedComponent->GetComponentRotation(); // Normalized
				CurrentRotation.DiagnosticCheckNaN(TEXT("UP3CharacterMovementComponent::PhysicsRotation(): CurrentRotation"));

				const float AngleTolerance = 1e-3f;
				if (!CurrentRotation.Equals(AlignedRotation, AngleTolerance))
				{
					// Change pitch
					if (!FMath::IsNearlyEqual(CurrentRotation.Pitch, AlignedRotation.Pitch, AngleTolerance))
					{
						FRotator NewRotation = CurrentRotation;

						const FRotator DeltaRot = GetDeltaRotation(DeltaTime);
						DeltaRot.DiagnosticCheckNaN(TEXT("UP3CharacterMovementComponent::PhysicsRotation(): GetDeltaRotation"));

						NewRotation.Pitch = FMath::FixedTurn(CurrentRotation.Pitch, AlignedRotation.Pitch, DeltaRot.Pitch);

						NewRotation.DiagnosticCheckNaN(TEXT("CharacterMovementComponent::PhysicsRotation(): NewRotation"));
						MoveUpdatedComponent(FVector::ZeroVector, NewRotation, /*bSweep*/ false);
					}
				}
			}

#if ENABLE_DRAW_DEBUG
			if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
			{
				::DrawDebugSphere(GetWorld(), FrontSweepStart, Sphere.GetSphereRadius(), 16, FColor::Green);
				::DrawDebugSphere(GetWorld(), RearSweepStart, Sphere.GetSphereRadius(), 16, FColor::Green);
				::DrawDebugLine(GetWorld(), FrontSweepStart, FrontSweepEnd, FColor::Green);
				::DrawDebugLine(GetWorld(), RearSweepStart, RearSweepEnd, FColor::Green);

				if (bFrontSweepHit)
				{
					::DrawDebugSphere(GetWorld(), FrontHitResult.Location, Sphere.GetSphereRadius(), 16, FColor::Red);
				}
				if (bRearSweepHit)
				{
					::DrawDebugSphere(GetWorld(), RearHitResult.Location, Sphere.GetSphereRadius(), 16, FColor::Red);
				}
			}
#endif
		}
	}
}

bool UP3CharacterMovementComponent::ShouldRemainVertical() const
{
	if (bShouldRemainVertial)
	{
		return true;
	}

	if (P3MovementMode == P3Movement_Climbing)
	{
		return false;
	}

	return Super::ShouldRemainVertical();
}

bool UP3CharacterMovementComponent::DoJump(bool bReplayingMoves)
{
 	if (MovementMode == MOVE_Falling)
	{
		AP3Character* Character = GetP3Character();

		// We need to check this condition to avoid change to glide immediately
		const bool bNotFirstJump = Character && Character->JumpCurrentCount > 0;

 		if (bNotFirstJump && Character->CanJump() && !Character->bWasJumping)
		{
			ConsiderGliding();
			return true;
		}

		// Nothing you can do for now. Maybe we can do some rocket-shoes?
		return true;
	}
	else if (P3MovementMode == P3Movement_Climbing)
	{
		if (CharacterOwner &&
			(IsAutonomousProxy(CharacterOwner) || 
			(IsAuthority(CharacterOwner) && CharacterOwner->GetRemoteRole() == ROLE_SimulatedProxy)))
		{
			AP3Character* Character = GetP3Character();
			UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
			if (ensure(ActionComp))
			{
				ActionComp->StartAction(EPawnActionType::ClimbJump, _FUNCTION_TEXT);
			}
		}
		return true;
	}
	else if (P3MovementMode == P3Movement_Gliding)
	{
		if (CharacterOwner && CharacterOwner->JumpCurrentCount != GlidingJumpCount && CharacterOwner->CanJump())
		{
			SetMovementMode(MOVE_Falling);
		}
		return true;
	}

	if (!IsJumpAllowed())
	{
		return false;
	}

	return Super::DoJump(bReplayingMoves);
}

class FNetworkPredictionData_Client* UP3CharacterMovementComponent::GetPredictionData_Client() const
{
	if (ClientPredictionData == nullptr)
	{
		UP3CharacterMovementComponent* MutableThis = const_cast<UP3CharacterMovementComponent*>(this);
		MutableThis->ClientPredictionData = new FP3NetworkPredictionData_Client_Character(*this);
	}

	return ClientPredictionData;
}

void UP3CharacterMovementComponent::UpdateFromCompressedFlags(uint8 Flags)
{
	Super::UpdateFromCompressedFlags(Flags);

	bSprintingPressed = ((Flags & FP3SavedMove_Character::FLAG_SprintPressed) != 0);
}

void UP3CharacterMovementComponent::ApplyImpactPhysicsForces(const FHitResult& Impact, const FVector& ImpactAcceleration, const FVector& ImpactVelocity)
{
	if (bEnablePhysicsInteraction && Impact.bBlockingHit)
	{
		AP3Character* Character = GetP3Character();

		if (Character)
		{
			const bool bHandled = Character->ApplyImpactPhysicsForces(Impact, ImpactAcceleration, ImpactVelocity, GetMaxSpeed());

			if (bHandled)
			{
				return;
			}
		}
	}

	Super::ApplyImpactPhysicsForces(Impact, ImpactAcceleration, ImpactVelocity);
}

float UP3CharacterMovementComponent::GetMaxBrakingDeceleration() const
{
	if (bIsInKnockBack)
	{
		return 0.0f;
	}

	return Super::GetMaxBrakingDeceleration();
}

void UP3CharacterMovementComponent::CalcVelocity(float DeltaTime, float Friction, bool bFluid, float BrakingDeceleration)
{
	EffectiveAccel = Acceleration;

	if (CustomMovementMode == P3Movement_Sliding)
	{
		if (UpdatedComponent && CurrentFloor.IsWalkableFloor())
		{
			Friction = 0;

			// Force reduce sideways
			const FVector RightVec = UpdatedComponent->GetRightVector();
			EffectiveAccel -= (Velocity.GetSafeNormal() | RightVec) * RightVec * GetMaxAcceleration() * 2.0f;

			const FVector ForwardVec = UpdatedComponent->GetForwardVector();

			// Brake
			float SlidableAngle = SlidableFloorAngle;
			if (UP3PhysicalMaterial* PhysicalMaterial = Cast<UP3PhysicalMaterial>(CurrentFloor.HitResult.PhysMaterial))
			{
				// DYLEE TODO : should have consider SlidableSlopeBehavior
				SlidableAngle = PhysicalMaterial->GetSlidableSlopeOverride().GetSlidableSlopeAngle();
			}

			float SlopeBrake = FMath::Max(0.0f, FMath::Min(1.0f,
				FMath::GetRangePct(SlidableAngle, 0.0f, FMath::RadiansToDegrees(FMath::Acos(CurrentFloor.HitResult.ImpactNormal.Z)))));
			ensure(SlopeBrake >= 0.0f && SlopeBrake <= 1.0f);

			const FVector SlopeVec = (CurrentFloor.HitResult.ImpactNormal ^ FVector(0.0f, 0.0f, GetGravityZ()) ^ CurrentFloor.HitResult.ImpactNormal).GetSafeNormal();
			float UphilBrake = FMath::GetRangePct(1.0f, -1.0f, ForwardVec | SlopeVec);
			ensure(UphilBrake >= 0.0f && UphilBrake <= 1.0f);

			P3JsonLog(Verbose, "calc deceleration",
				TEXT("SlopeBrake"), SlopeBrake,
				TEXT("SlopeBrakeFactor"), CVarP3SlidingSlopeBrakeFactor.GetValueOnGameThread(),
				TEXT("UphilBrake"), UphilBrake,
				TEXT("UphilBrakeFactor"), CVarP3SlidingUpHillBrakeFactor.GetValueOnGameThread());

			SlopeBrake *= CVarP3SlidingSlopeBrakeFactor.GetValueOnGameThread();
			UphilBrake *= CVarP3SlidingUpHillBrakeFactor.GetValueOnGameThread();

			EffectiveAccel -= (SlopeBrake + UphilBrake) * GetMaxAcceleration() * ForwardVec;
		}
	}
	else
	{
		AP3Character* Character = GetP3Character();

		if (Character && Character->IsPushing())
		{
			//UP3PushComponent* PushComponent = Character->GetPushComponent();

			//if (PushComponent && PushComponent->IsLockPushDirection())
			//{
				const FVector RightVector = UpdatedComponent->GetRightVector();
				EffectiveAccel -= (EffectiveAccel | RightVector) * RightVector;
			//}
		}
	}

	TGuardValue<FVector> AccelGuard(Acceleration, EffectiveAccel);

	Super::CalcVelocity(DeltaTime, Friction, bFluid, BrakingDeceleration);
}

void UP3CharacterMovementComponent::ApplyVelocityBraking(float DeltaTime, float Friction, float BrakingDeceleration)
{
	if (bIsInKnockBack)
	{
		Friction *= 0.1f;
	}

	Super::ApplyVelocityBraking(DeltaTime, Friction, BrakingDeceleration);
}

bool UP3CharacterMovementComponent::ApplyRequestedMove(float DeltaTime, float MaxAccel, float MaxSpeed, float Friction, float BrakingDeceleration, FVector& OutAcceleration, float& OutRequestedSpeed)
{
	if (bIsInKnockBack)
	{
		return false;
	}

	return Super::ApplyRequestedMove(DeltaTime, MaxAccel, MaxSpeed, Friction, BrakingDeceleration, OutAcceleration, OutRequestedSpeed);
}

void UP3CharacterMovementComponent::StopMovementImmediately()
{
	if (bIsInKnockBack)
	{
		return;
	}

	Super::StopMovementImmediately();
}

FVector UP3CharacterMovementComponent::ConsumeInputVector()
{
#if FIXME_CHARACTER_MOVEMENT_CLIENT_AUTHORITY
	if (GetOwnerRole() == ROLE_SimulatedProxy)
	{
		// Simulated proxy will receive input by NetSerializeMovement
		// and if we continue to ConsumeMovementInputVector, it will be zeroed
		return PawnOwner ? PawnOwner->GetLastMovementInputVector() : FVector::ZeroVector;
	}
#endif

	if (P3MovementMode == P3Movement_Sliding && CVarP3CharacterBasedControlOnSliding.GetValueOnGameThread() && CharacterOwner && CharacterOwner->Controller)
	{
		FVector ConsumedInputVector = Super::ConsumeInputVector();
		FRotator CharacterRotation = UpdatedComponent->GetComponentRotation();
		FRotator ControlRotation = CharacterOwner->Controller->GetControlRotation();

		if (CVarP3SlidingDebug.GetValueOnGameThread() && !ConsumedInputVector.IsNearlyZero())
		{
			auto DebugLocation = GetActorLocation();
			{
				auto CharacterOrientedInputVector = CharacterRotation.RotateVector(ControlRotation.UnrotateVector(ConsumedInputVector)) * FVector(1.0f, 1.0f, 0.0f);
				DrawDebugDirectionalArrow(GetWorld(), DebugLocation,
					DebugLocation + CharacterOrientedInputVector * 100.0f,
					100.f, FColor::Red, false, -1.f, (uint8)'\000', 2.f);
			}
		}

		return CharacterRotation.RotateVector(ControlRotation.UnrotateVector(ConsumedInputVector)) * FVector(1.0f, 1.0f, 0.0f);
	}
	else
	{
		return Super::ConsumeInputVector();
	}
}

void UP3CharacterMovementComponent::MoveAlongFloor(const FVector& InVelocity, float DeltaSeconds, FStepDownResult* OutStepDownResult /*= NULL*/)
{
	float MaxSpeed = GetMaxSpeed();

	if ((MovementMode == MOVE_Walking || MovementMode == MOVE_NavWalking)
		&& (!HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity()))
	{
		// Slow down on inclined slope
		if (CurrentFloor.IsWalkableFloor() && IsSlopeUpward())
		{
			const float SlopeRatio = GetSlopeRatio();
			ensureMsgf(SlopeRatio >= 0.f && SlopeRatio <= 1.f, TEXT("Invalid SlopeRatio"));
			MaxSpeed *= 1.f - FMath::Clamp(InclineSlowDown, 0.f, 1.f) * SlopeRatio;
		}

		Super::MoveAlongFloor(InVelocity.GetClampedToMaxSize(MaxSpeed), DeltaSeconds, OutStepDownResult);
	}
	else
	{
		Super::MoveAlongFloor(InVelocity, DeltaSeconds, OutStepDownResult);
	}

	// Stop sliding if the character is in stuck
	if ((CharacterOwner->GetLocalRole() == ROLE_Authority) || (CharacterOwner->GetRemoteRole() == ROLE_AutonomousProxy))
	{
		LastStuckCheckTimeSeconds += DeltaSeconds;
		if (LastStuckCheckTimeSeconds > CVarP3SlidingStuckTickPeriod.GetValueOnGameThread())
		{
			LastStuckCheckTimeSeconds = 0.0f;

			const FVector CurrentLocation = CharacterOwner->GetActorLocation();
			const float MovedDistanceSquared = (CurrentLocation - LastStuckCheckLocation).SizeSquared();
			const float StuckDistance = CVarP3SlidingStuckDistance.GetValueOnGameThread();

			if (MovedDistanceSquared < FMath::Square(StuckDistance))
			{
				// Stuck
				LastStuckCheckTimeSeconds = 0.0f;
				SetMovementMode(MOVE_Walking);
			}

			LastStuckCheckLocation = CurrentLocation;
		}
	}

}

static float GetAxisDeltaRotation(float InAxisRotationRate, float DeltaTime)
{
	return (InAxisRotationRate >= 0.f) ? (InAxisRotationRate * DeltaTime) : 360.f;
}

// Override UCharacterMovementComponent
FRotator UP3CharacterMovementComponent::GetDeltaRotation(float DeltaTime) const
{
	FRotator EffectiveRotationRate = RotationRate;

	if (bUseCustomRotationRate)
	{
		EffectiveRotationRate = CustomRotationRate;
	}

	if (CustomMovementMode == P3Movement_Sliding)
	{
		EffectiveRotationRate = SlidingRotationRate;
	}
	else if (CustomMovementMode == P3Movement_Gliding)
	{
		EffectiveRotationRate = GlidingRotationRate;
	}

	if (CVarP3NoRotationDuringFalling.GetValueOnGameThread() == 1 && IsFalling())
	{
		EffectiveRotationRate = FRotator::ZeroRotator;
	}

	if (!bRotateAllowed)
	{
		EffectiveRotationRate = FRotator::ZeroRotator;
	}

	return FRotator(GetAxisDeltaRotation(EffectiveRotationRate.Pitch, DeltaTime), GetAxisDeltaRotation(EffectiveRotationRate.Yaw, DeltaTime), GetAxisDeltaRotation(EffectiveRotationRate.Roll, DeltaTime));
}

FVector UP3CharacterMovementComponent::GetImpartedMovementBaseVelocity() const
{
	const float OldVelocitySize = Velocity.Size2D();

	AP3Character* P3Character = GetP3Character();
	if (P3Character && P3Character->GetLastBaseChangedTimeSeconds() >= 0)
	{
		const float SecondsSinceThisBase = GetWorld()->GetTimeSeconds() - P3Character->GetLastBaseChangedTimeSeconds();
		if (SecondsSinceThisBase < 0.1f)
		{
			// You need to stay on a same base component for some time to get Imparted-velocity effect
			// This is needed to avoid character to be snapped by some small and fast moving objects (like arrow or small rock)
			return FVector::ZeroVector;
		}
	}

	FVector OutVelocity = Super::GetImpartedMovementBaseVelocity();

	if (FMath::Abs(OldVelocitySize - Velocity.Size2D()) >= 900.0f)
	{
		UPrimitiveComponent* MovementBase = CharacterOwner->GetMovementBase();
		if (MovementBase)
		{
			P3JsonLog(Warning, "BaseActor when the speed difference is large", TEXT("ActorName"), MovementBase->GetName());
		}
	}

	return OutVelocity;
}

void UP3CharacterMovementComponent::ApplyAccumulatedForces(float DeltaSeconds)
{
	for (auto&& Iter = Forces.CreateIterator(); Iter; ++Iter)
	{
		const FP3CharacterMovementForce& Force = *Iter;

		if (!Force.SourceObject.IsValid())
		{
			Iter.RemoveCurrent();
			continue;
		}

		switch (Force.Type)
		{
		case FP3CharacterMovementForce::EType::Wind:
			if (IsGliding())
			{
				const float Alpha = FMath::Clamp(Force.WindStrength * DeltaSeconds, 0.0f, 1.0f);
				const FVector ImpulseVelocity = (Force.WindTargetVelocity - Velocity) * Alpha;
				PendingImpulseToApply += ImpulseVelocity;
			}
			break;
		case FP3CharacterMovementForce::EType::Action:
		{
			const float Alpha = FMath::Clamp(Force.ActionStrength * DeltaSeconds, 0.0f, 1.0f);
			const FVector ImpulseVelocity = (Force.ActionTargetVelocity - Velocity) * Alpha;
			PendingImpulseToApply += ImpulseVelocity;
		}
		break;

		default:
			ensure(0);
		}
	}

	Super::ApplyAccumulatedForces(DeltaSeconds);
}

/**
 * Return -1 if not parkour climbing is possible (no low height wall)
 * otherwise, return height of wall so that proper montage can be played
 */
static float _FindParkourClimbUpHeight(ACharacter* CharacterOwner, USceneComponent* UpdatedComponent)
{
	if (!ensure(CharacterOwner) || !ensure(UpdatedComponent) || !ensure(UpdatedComponent->GetWorld()))
	{
		return false;
	}

	float CapsuleRadius, CapsuleHalfHeight;
	CharacterOwner->GetCapsuleComponent()->GetScaledCapsuleSize(CapsuleRadius, CapsuleHalfHeight);

	const float SWEEP_SPHERE_RADIUS = 20.0f;
	const float ROOF_START_Z = CapsuleHalfHeight + SWEEP_SPHERE_RADIUS + 10.0f;
	const float SWEEP_DISTANCE = CapsuleHalfHeight * 1.5f;

	const FVector MyLocation = UpdatedComponent->GetComponentLocation();
	const FVector MyUpVector = UpdatedComponent->GetComponentQuat().GetUpVector();
	const FVector MyForwardVector = UpdatedComponent->GetComponentQuat().GetForwardVector();

	UWorld* World = UpdatedComponent->GetWorld();

	FCollisionShape Sphere;
	Sphere.SetSphere(SWEEP_SPHERE_RADIUS);

	FHitResult HitResult;
	FCollisionQueryParams Params;
	FCollisionResponseParams Response;
	Params.AddIgnoredActor(CharacterOwner);

	// See if we have empty area up there
	{
		const FVector SweepStart = MyLocation + (MyUpVector * ROOF_START_Z);
		const FVector SweepEnd = SweepStart + (MyForwardVector * SWEEP_DISTANCE);

		const bool bUpperFrontAreaBlocked = World->SweepSingleByChannel(HitResult, SweepStart, SweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

#if ENABLE_DRAW_DEBUG
		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			::DrawDebugCapsule(World, (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
				!bUpperFrontAreaBlocked ? FColor::Green : FColor::Red, false, 1.0f);

			if (bUpperFrontAreaBlocked)
			{
				::DrawDebugPoint(World, HitResult.ImpactPoint, 10.0f, FColor::Green);
			}
		}
#endif

		if (bUpperFrontAreaBlocked)
		{
			return -1.0f;
		}
	}

	{
		// See if we can climb up all the way there without banging head to something
		const FVector SweepStart = MyLocation;
		const FVector SweepEnd = SweepStart + (MyUpVector * ROOF_START_Z);

		const bool bHasUpperBlocker = World->SweepSingleByChannel(HitResult, SweepStart, SweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

#if ENABLE_DRAW_DEBUG
		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			::DrawDebugCapsule(World, (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
				!bHasUpperBlocker ? FColor::Green : FColor::Red, false, 1.0f);

			if (bHasUpperBlocker)
			{
				::DrawDebugPoint(World, HitResult.ImpactPoint, 10.0f, FColor::Green);
			}
		}
#endif

		if (bHasUpperBlocker)
		{
			return -1.0f;
		}
	}
	
	{
		// Ok find out height of the wall
		const FVector SweepStart = MyLocation + (MyUpVector * ROOF_START_Z) + (MyForwardVector * CapsuleRadius * 2);
		const FVector SweepEnd = SweepStart + (-MyUpVector * (ROOF_START_Z + CapsuleHalfHeight));

		const bool bFoundRoof = World->SweepSingleByChannel(HitResult, SweepStart, SweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

#if ENABLE_DRAW_DEBUG
		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			::DrawDebugCapsule(World, (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
				!bFoundRoof ? FColor::Green : FColor::Red, false, 1.0f);

			if (bFoundRoof)
			{
				::DrawDebugPoint(World, HitResult.ImpactPoint, 10.0f, FColor::Green);
			}
		}
#endif

		if (bFoundRoof)
		{
			UPrimitiveComponent* HitPrimComp = HitResult.Component.Get();
			if (HitPrimComp && HitPrimComp->GetCollisionObjectType() == ECC_Pawn)
			{
				// Do not jump into other pawn. I mean for now.
				return -1.0f;
			}
		}

		if (!bFoundRoof)
		{
			return -1.0f;
		}

		// TODO: See if you can stand up after climbing, without colliding to something

		const float OutHeight = CapsuleHalfHeight + (ROOF_START_Z - HitResult.Distance) - Sphere.GetSphereRadius();

		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			P3JsonLog(Display, "Parkour", TEXT("Height"), OutHeight);
		}

		return OutHeight;
	}
}

// Return true if Parkour action is requested
static bool _LocalControl_TryParkour(AP3Character* Character, USceneComponent* UpdatedComponent, float MaxStepHeight)
{
	if (!Character)
	{
		return false;
	}

	ensure(IsLocalControlledActor(Character));

	bool bParkourActionRequested = false;

	const float ParkourClimbHeight = _FindParkourClimbUpHeight(Character, UpdatedComponent);
	if (ParkourClimbHeight > 0)
	{
		float CapsuleRadius, CapsuleHalfHeight;
		Character->GetCapsuleComponent()->GetScaledCapsuleSize(CapsuleRadius, CapsuleHalfHeight);

		if (ParkourClimbHeight > MaxStepHeight && ParkourClimbHeight < CapsuleHalfHeight * 2.0f)
		{
			const UP3ParkourData* ParkourData = Character->GetParkourData();
			if (ParkourData)
			{
				UP3PawnActionComponent* ActionComp = Character->GetActionComponent();
				if (ensure(ActionComp))
				{
					FP3PawnActionStartRequestParams ActionParams;
					ActionParams.ParkourClimbUp_MontageIndex = ParkourData->GetNearestClimbUpMontageIndex(ParkourClimbHeight);
					if (ensure(ActionParams.ParkourClimbUp_MontageIndex != -1))
					{
						ActionComp->StartAction(EPawnActionType::ParkourClimbUp, _FUNCTION_TEXT, ActionParams);
									
						bParkourActionRequested = true;
					}
				}
			}
		}
	}

	return bParkourActionRequested;
}

bool UP3CharacterMovementComponent::StepUp(const FVector& GravDir, const FVector& Delta, const FHitResult &Hit, struct UCharacterMovementComponent::FStepDownResult* OutStepDownResult /*= NULL*/)
{
	const FVector PrevLocation = UpdatedComponent ? UpdatedComponent->GetComponentLocation() : FVector::ZeroVector;
	const bool bStepUpResult = Super::StepUp(GravDir, Delta, Hit, OutStepDownResult);
	const FVector CurrentLocation = UpdatedComponent ? UpdatedComponent->GetComponentLocation() : FVector::ZeroVector;

	const bool bCanTryParkour = (!bStepUpResult && bParkourAllowed) || CanTryParkour();

	if (bCanTryParkour && IsLocalControlledActor(CharacterOwner))
	{
		bool bTryParkour = !bStepUpResult;

		if (!bTryParkour)
		{
			if (!Delta.IsNearlyZero())
			{
				const FVector Moved = CurrentLocation - PrevLocation;
				const float MovedTowardsDelta = Delta | Moved;

				if (MovedTowardsDelta < (Delta | Delta) * 0.5f)
				{
					// Try parkour if we are not moving
					bTryParkour = true;
				}
			}
		}

		if (bTryParkour && !IsFalling())
		{
			// Don't parkour pushable unless we are falling(jumping)
			if (Hit.GetActor() && Hit.GetActor()->FindComponentByClass<UP3PushableComponent>())
			{
				bTryParkour = false;
			}
		}

		if (bTryParkour)
		{
			const bool bParkourActionRequested = _LocalControl_TryParkour(GetP3Character(), UpdatedComponent, MaxStepHeight);

			if (bParkourActionRequested)
			{
				return false;
			}
		}
	}

	return bStepUpResult;
}

bool UP3CharacterMovementComponent::ResolvePenetrationImpl(const FVector& InAdjustment, const FHitResult& Hit, const FQuat& NewRotation)
{
	FVector Adjustment = InAdjustment;

	if (Hit.Actor.IsValid() && Hit.Actor->IsA(ACharacter::StaticClass()))
	{
		Adjustment += FVector(FMath::FRandRange(-0.5f, 0.5f), FMath::FRandRange(-0.5f, 0.5f), FMath::FRandRange(-0.5f, 0.5f));
		P3JsonLog(Verbose, "Add jitter when resolving penetration with Character",
			TEXT("ResolveTarget"), *Hit.Actor.Get()->GetName(),
			TEXT("InAdjustment"), InAdjustment.ToString(),
			TEXT("Adjustment"), Adjustment.ToString());
	}

	return Super::ResolvePenetrationImpl(Adjustment, Hit, NewRotation);
}

void UP3CharacterMovementComponent::HandleImpact(const FHitResult& Hit, float TimeSlice/*=0.f*/, const FVector& MoveDelta /*= FVector::ZeroVector*/)
{
	Super::HandleImpact(Hit, TimeSlice, MoveDelta);
}

AP3Character* UP3CharacterMovementComponent::GetP3Character() const
{
	AP3Character* Character = Cast<AP3Character>(CharacterOwner);

	return Character;
}

void UP3CharacterMovementComponent::SetCustomRotationRate(bool bInUseCustomRotationRate, const FRotator& InCustomRotationRate)
{
	bUseCustomRotationRate = bInUseCustomRotationRate;
	CustomRotationRate = InCustomRotationRate;
}

void UP3CharacterMovementComponent::AddWindForce(const FVector& TargetVelocity, float Strength, UObject& SourceObject)
{
	const FP3CharacterMovementForce* DuplicatedForce = Forces.FindByPredicate([&SourceObject](const FP3CharacterMovementForce& Force) -> bool {
		return (Force.SourceObject.Get() == &SourceObject);
	});

	if (DuplicatedForce)
	{
		ensure(0);
		return;
	}

	FP3CharacterMovementForce NewForce;
	NewForce.SourceObject = &SourceObject;
	NewForce.Type = FP3CharacterMovementForce::EType::Wind;
	NewForce.WindTargetVelocity = TargetVelocity;
	NewForce.WindStrength = Strength;

	Forces.Add(NewForce);
}

void UP3CharacterMovementComponent::RemoveWindForce(UObject& SourceObject)
{
	Forces.RemoveAll([&SourceObject](const FP3CharacterMovementForce& Force) -> bool {
		return (Force.SourceObject.Get() == &SourceObject);
	});
}

void UP3CharacterMovementComponent::AddActionForce(const FVector& TargetVelocity, float Strength, UObject& SourceObject)
{
	const FP3CharacterMovementForce* DuplicatedForce = Forces.FindByPredicate([&SourceObject](const FP3CharacterMovementForce& Force) -> bool {
		return (Force.SourceObject.Get() == &SourceObject);
	});

	if (DuplicatedForce)
	{
		ensure(0);
		return;
	}

	FP3CharacterMovementForce NewForce;
	NewForce.SourceObject = &SourceObject;
	NewForce.Type = FP3CharacterMovementForce::EType::Action;
	NewForce.ActionTargetVelocity = TargetVelocity;
	NewForce.ActionStrength = Strength;

	Forces.Add(NewForce);
}

FP3CharacterMovementForce* UP3CharacterMovementComponent::GetActionForce(UObject& SourceObject)
{
	return Forces.FindByPredicate([&SourceObject](const FP3CharacterMovementForce& Force) -> bool {
		return (Force.SourceObject.Get() == &SourceObject);
	});	
}

void UP3CharacterMovementComponent::RemoveActionForce(UObject& SourceObject)
{
	Forces.RemoveAll([&SourceObject](const FP3CharacterMovementForce& Force) -> bool {
		return (Force.SourceObject.Get() == &SourceObject);
	});
}

float UP3CharacterMovementComponent::GetSlopeRatio() const
{
	return FMath::GetRangePct(
		1.0f, GetWalkableFloorZ(),
		CurrentFloor.HitResult.ImpactNormal.Z);
}

bool UP3CharacterMovementComponent::IsSlopeUpward() const
{
	return (CurrentFloor.HitResult.ImpactNormal | Velocity) < 0.f;
}

void UP3CharacterMovementComponent::OnClimbAnimNotify()
{
	ClimbingStatus.bConsiderClimbing = true;
}

void UP3CharacterMovementComponent::SetSprint(bool bNewSprint)
{
	bSprintingPressed = bNewSprint;
}

void UP3CharacterMovementComponent::SetCrippled(bool bNewCrippled)
{
	bCrippled = bNewCrippled;
}

void UP3CharacterMovementComponent::SetStroll(bool bNewStroll)
{
	bStroll = bNewStroll;
}

bool UP3CharacterMovementComponent::IsSlidableFloor() const
{
	return CurrentFloor.IsWalkableFloor() && IsSlidableFloorAngle();
}

bool UP3CharacterMovementComponent::IsSlidableFloorAngle() const
{
	float TestSlidableZ = SlidableFloorZ;

	if (UP3PhysicalMaterial* PhysicalMaterial = Cast<UP3PhysicalMaterial>(CurrentFloor.HitResult.PhysMaterial))
	{
		const FSlidableSlopeOverride& SlopeOverride = PhysicalMaterial->GetSlidableSlopeOverride();
		TestSlidableZ = SlopeOverride.ModifySlidableFloorZ(TestSlidableZ);
	}

	return CurrentFloor.HitResult.ImpactNormal.Z < TestSlidableZ;
}

void UP3CharacterMovementComponent::PhysCustom(float DeltaTime, int32 Iterations)
{
	Super::PhysCustom(DeltaTime, Iterations);

	switch (P3MovementMode)
	{
	case P3Movement_Climbing:
		PhysClimbing(DeltaTime, Iterations);
		break;

	case P3Movement_Gliding:
		PhysGliding(DeltaTime, Iterations);
		break;

	case P3Movement_Sliding:
		PhysSliding(DeltaTime, Iterations);
		break;

	default:
		ensureMsgf(0, TEXT("Invalid custom movement mode: %d"), P3MovementMode.GetValue());
	}
}

// Override UCharacterMovementComponent::ProcessLanded
void UP3CharacterMovementComponent::ProcessLanded(const FHitResult& Hit, float RemainingTime, int32 Iterations)
{
	if (CharacterOwner && CharacterOwner->ShouldNotifyLanded(Hit))
	{
		CharacterOwner->Landed(Hit);
	}
	if (IsFalling() || P3MovementMode == P3Movement_Gliding)
	{
		if (GetGroundMovementMode() == MOVE_NavWalking)
		{
			// verify navmesh projection and current floor
			// otherwise movement will be stuck in infinite loop:
			// navwalking -> (no navmesh) -> falling -> (standing on something) -> navwalking -> ....

			const FVector TestLocation = GetActorFeetLocation();
			FNavLocation NavLocation;

			const bool bHasNavigationData = FindNavFloor(TestLocation, NavLocation);
			if (!bHasNavigationData || NavLocation.NodeRef == INVALID_NAVNODEREF)
			{
				SetGroundMovementMode(MOVE_Walking);
				// TODO: log
				//UE_LOG(LogNavMeshMovement, Verbose, TEXT("ProcessLanded(): %s tried to go to NavWalking but couldn't find NavMesh! Using Walking instead."), *GetNameSafe(CharacterOwner));
			}
		}

		SetPostLandedPhysics(Hit);
	}

	IPathFollowingAgentInterface* PathFollowingAgent = GetPathFollowingAgent();
	if (PathFollowingAgent)
	{
		PathFollowingAgent->OnLanded();
	}

	StartNewPhysics(RemainingTime, Iterations);
}

// Override UCharacterMovementComponent
void UP3CharacterMovementComponent::SetPostLandedPhysics(const FHitResult& Hit)
{
	if (CharacterOwner)
	{
		bool bHandled = false;

		if (CanEverSwim() && IsInWater())
		{
			SetMovementMode(MOVE_Swimming);

			bHandled = true;
		}
		else if (CharacterOwner->bPressedJump && CharacterOwner->JumpCurrentCount == 1 && UpdatedComponent)
		{
			FindFloor(UpdatedComponent->GetComponentLocation(), CurrentFloor, false, NULL);

			if (CurrentFloor.IsWalkableFloor()
				&& ((CurrentFloor.HitResult.ImpactNormal | UpdatedComponent->GetForwardVector()) > 0)
				&& IsSlidableFloor())
			{
				SetMovementMode(MOVE_Custom, P3Movement_Sliding);

				Velocity = GetMaxSpeed() * UpdatedComponent->GetForwardVector();

				bHandled = true;
			}
		}

		if (!bHandled)
		{
			const FVector PreImpactAccel = Acceleration + (IsFalling() ? FVector(0.f, 0.f, GetGravityZ()) : FVector::ZeroVector);
			const FVector PreImpactVelocity = Velocity;

			if (DefaultLandMovementMode == MOVE_Walking ||
				DefaultLandMovementMode == MOVE_NavWalking ||
				DefaultLandMovementMode == MOVE_Falling)
			{
				SetMovementMode(GetGroundMovementMode());
			}
			else
			{
				SetDefaultMovementMode();
			}

			ApplyImpactPhysicsForces(Hit, PreImpactAccel, PreImpactVelocity);
		}
	}
}

// Override UCharacterMovementComponent::NewFallVelocity
FVector UP3CharacterMovementComponent::NewFallVelocity(const FVector& InitialVelocity, const FVector& Gravity, float DeltaTime) const
{
	FVector Result = InitialVelocity;
	bool bApplyTerminalLimit = false;

	if (!Gravity.IsZero() && (bApplyGravityWhileJumping || !(CharacterOwner && CharacterOwner->IsJumpProvidingForce())))
	{
		// Apply gravity.
		Result += Gravity * DeltaTime;

		bApplyTerminalLimit = true;
	}

	if (P3MovementMode == P3Movement_Gliding && ensure(UpdatedComponent))
	{
		// Apply gliding drag
		const FQuat Quat = UpdatedComponent->GetComponentQuat();
		const FVector LocalVelocity = Quat.Inverse() * Result;
		FVector LocalDragRate = GlidingAirDrag * DeltaTime;
		LocalDragRate = LocalDragRate.ComponentMin(FVector(1, 1, 1));
		const FVector LocalDrag = LocalVelocity * LocalDragRate;
		const FVector Drag = Quat * LocalDrag;

		Result -= Drag;

		bApplyTerminalLimit = true;
	}

	if (bApplyTerminalLimit)
	{
		const FVector GravityDir = Gravity.GetSafeNormal();
		const float TerminalLimit = FMath::Abs(GetPhysicsVolume()->TerminalVelocity);

		// Don't exceed terminal velocity.
		if ((Result | GravityDir) > TerminalLimit)
		{
			Result = FVector::PointPlaneProject(Result, FVector::ZeroVector, GravityDir) + GravityDir * TerminalLimit;
		}
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
	{
		DrawDebugString(GetWorld(), FVector(0, 0, -50), FString::Printf(TEXT("Speed: %.2fm/s"), Result.Size() * 0.01f), GetPawnOwner(), FColor::White, 0, true);
	}
#endif

	return Result;
}

void UP3CharacterMovementComponent::CapsuleTouched(UPrimitiveComponent* OverlappedComp, AActor* Other, UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
	if (!bEnablePhysicsInteraction)
	{
		return;
	}

	if (OtherComp != NULL && OtherComp->IsAnySimulatingPhysics())
	{
		const FVector OtherLoc = OtherComp->GetComponentLocation();
		const FVector Loc = UpdatedComponent->GetComponentLocation();
		FVector ImpulseDir = FVector(OtherLoc.X - Loc.X, OtherLoc.Y - Loc.Y, 0.25f).GetSafeNormal();
		ImpulseDir = (ImpulseDir + Velocity.GetSafeNormal2D()) * 0.5f;
		ImpulseDir.Normalize();

		FName BoneName = NAME_None;
		if (OtherBodyIndex != INDEX_NONE)
		{
			BoneName = ((USkinnedMeshComponent*)OtherComp)->GetBoneName(OtherBodyIndex);
		}

		float TouchForceFactorModified = TouchForceFactor;

		if ( bTouchForceScaledToMass )
		{
			FBodyInstance* BI = OtherComp->GetBodyInstance(BoneName);
			TouchForceFactorModified *= BI ? BI->GetBodyMass() : 1.0f;
		}

		float ImpulseStrength = FMath::Clamp(Velocity.Size2D() * TouchForceFactorModified, 
			MinTouchForce > 0.0f ? MinTouchForce : -FLT_MAX, 
			MaxTouchForce > 0.0f ? MaxTouchForce : FLT_MAX);

		if (ImpulseStrength != 0.0f)
		{
			FVector Impulse = ImpulseDir * ImpulseStrength;
			OtherComp->AddImpulse(Impulse, BoneName);
		}
	}
}

FVector UP3CharacterMovementComponent::ConstrainInputAcceleration(const FVector& InputAcceleration) const
{
	if (bConstraintZAccel)
	{
		return FVector(InputAcceleration.X, InputAcceleration.Y, 0.f);
	}

	return Super::ConstrainInputAcceleration(InputAcceleration);
}

static bool _FindFrontalWall(
	ACharacter* CharacterOwner, USceneComponent* UpdatedComponent, float WalkableFloorZ, bool bSkipSimulated, FVector* OutWallNormal/*Nullable*/)
{
	if (!ensure(UpdatedComponent))
	{
		return false;
	}

	if (!ensure(CharacterOwner))
	{
		return false;
	}

	struct FSweeper
	{
		FSweeper(bool bInSkipSimulated) : bSkipSimulated(bInSkipSimulated) {}

		bool bSkipSimulated;
		FHitResult HitResult;

		bool Sweep(UWorld* World, float SphereRadius, const FVector& Start, const FVector& End)
		{
			FCollisionShape Sphere;
			Sphere.SetSphere(SphereRadius);

			FCollisionQueryParams Params;
			FCollisionResponseParams Response;

			bool bHasFrontWall = World->SweepSingleByChannel(HitResult, Start, End, FQuat::Identity, ECC_CLIMB, Sphere, Params, Response);

			if (bSkipSimulated)
			{
				AActor* Actor = HitResult.GetActor();
				UPrimitiveComponent* Component = HitResult.GetComponent();
				if (Component && Component->IsAnySimulatingPhysics())
				{
					bHasFrontWall = false;
				}
			}

#if ENABLE_DRAW_DEBUG
			if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
			{
				::DrawDebugCapsule(World, (End + Start) * 0.5f, (End - Start).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((End - Start)).ToQuat(),
					bHasFrontWall ? FColor::Green : FColor::Red, false, 3.0f);

				if (bHasFrontWall)
				{
					::DrawDebugPoint(World, HitResult.ImpactPoint, 20.0f, FColor::Blue);
				}
			}
#endif

			return bHasFrontWall;
		}
	};

	float CapsuleRadius, CapsuleHalfHeight;
	CharacterOwner->GetCapsuleComponent()->GetScaledCapsuleSize(CapsuleRadius, CapsuleHalfHeight);

	const float SWEEP_SPHERE_RADIUS = 10.0f;
	const float SWEEP_DISTANCE = CapsuleHalfHeight * 1.2f;		// 1.2f here is just to make climbable angle wider
	const float SHOULDER_Z = CapsuleHalfHeight - SWEEP_SPHERE_RADIUS;
	const float KNEE_Z = -CapsuleHalfHeight + CapsuleRadius;

	const FVector Location = UpdatedComponent->GetComponentLocation();
	const FVector UpVec = UpdatedComponent->GetComponentQuat().GetUpVector();
	const FVector RightVec = UpdatedComponent->GetComponentQuat().GetRightVector();
	const FVector ForwardVec = UpdatedComponent->GetComponentQuat().GetForwardVector();
	UWorld* World = UpdatedComponent->GetWorld();
	
	// Find wall from knee
	FSweeper KneeSweeper(bSkipSimulated);
	{
		const FVector SweepStart = Location + (UpVec * KNEE_Z);
		const FVector SweepEnd = SweepStart + (ForwardVec * SWEEP_DISTANCE);

		const bool bHasFrontWall = KneeSweeper.Sweep(World, SWEEP_SPHERE_RADIUS, SweepStart, SweepEnd);

		if (!bHasFrontWall)
		{
			// Don't have wall
			return false;
		}

		//if (KneeSweeper.HitResult.ImpactNormal.Z > WalkableFloorZ + 0.1f)
		//{
		//	// Wall is walkable
		//	return false;
		//}

		if (OutWallNormal)
		{
			*OutWallNormal = KneeSweeper.HitResult.ImpactNormal;
		}
	}
	
	// Find wall from Shoulder - Center
	FSweeper ShoulderSweeper(bSkipSimulated);
	{
		const FVector SweepStart = Location	+ (UpVec * SHOULDER_Z);
		const FVector SweepEnd = SweepStart + (ForwardVec * SWEEP_DISTANCE);

		const bool bHasFrontWall = ShoulderSweeper.Sweep(World, SWEEP_SPHERE_RADIUS, SweepStart, SweepEnd);

		if (!bHasFrontWall)
		{
			// Don't have wall
			return false;
		}
	}

	const float ShoulderHalfWidth = CapsuleRadius;
	
	// Find wall from Shoulder - Left
	FSweeper LeftShoulderSweeper(bSkipSimulated);
	{
		const FVector SweepStart = Location	+ (UpVec* SHOULDER_Z) - (RightVec * ShoulderHalfWidth);
		const FVector SweepEnd = SweepStart + (ForwardVec * SWEEP_DISTANCE)	+ (RightVec * ShoulderHalfWidth * 0.5f);

		const bool bHasFrontWall = LeftShoulderSweeper.Sweep(World, SWEEP_SPHERE_RADIUS, SweepStart, SweepEnd);

		if (!bHasFrontWall)
		{
			// Don't have wall
			return false;
		}
	}

	// Find wall from Shoulder - Right
	FSweeper RightShoulderSweeper(bSkipSimulated);
	{
		const FVector SweepStart = Location + (UpVec * SHOULDER_Z) + (RightVec * ShoulderHalfWidth);
		const FVector SweepEnd = SweepStart + (ForwardVec * SWEEP_DISTANCE) - (RightVec * ShoulderHalfWidth * 0.5f);

		const bool bHasFrontWall = RightShoulderSweeper.Sweep(World, SWEEP_SPHERE_RADIUS, SweepStart, SweepEnd);

		if (!bHasFrontWall)
		{
			// Don't have wall
			return false;
		}
	}

	if (OutWallNormal)
	{
		const FVector ShoulderHitCenter = (LeftShoulderSweeper.HitResult.Location + RightShoulderSweeper.HitResult.Location) * 0.5f;
		const FVector VerticalLine = (ShoulderSweeper.HitResult.Location - KneeSweeper.HitResult.Location).GetSafeNormal();

		*OutWallNormal = (VerticalLine ^ ((*OutWallNormal) ^ VerticalLine)).GetSafeNormal();

		const FVector HorizontalLine = LeftShoulderSweeper.HitResult.Location - RightShoulderSweeper.HitResult.Location;

		*OutWallNormal = (HorizontalLine ^ ((*OutWallNormal) ^ HorizontalLine)).GetSafeNormal();

		// TEST: Reduce horizontal aligning to avoid jittering
		//const FVector HorizontalAlignedNormal = (HorizontalLine ^ ((*OutWallNormal) ^ HorizontalLine)).GetSafeNormal();
		//const FPlane ShoulderNormalPlane(
		//	ShoulderHitCenter, 
		//	ShoulderHitCenter + UpdatedComponent->GetComponentQuat().GetUpVector(),
		//	ShoulderHitCenter + ShoulderSideAlignedNormal);

		//const float DistanceToShoulderPlane = FMath::Abs(ShoulderNormalPlane.PlaneDot(UpdatedComponent->GetComponentLocation()));
		//const float Alpha = 1.0f - FMath::Clamp(DistanceToShoulderPlane / 50.0f, 0.01f, 1.0f);

		//*OutWallNormal = FMath::Lerp(*OutWallNormal, ShoulderSideAlignedNormal, Alpha);

		// TEST: Sphere Intersection Normal to Yaw Rotation
		//FSweeper CenterSweeper(bSkipSimulated);
		//{
		//	const FVector SweepStart = UpdatedComponent->GetComponentLocation();
		//	const FVector SweepEnd = SweepStart;

		//	const bool bHasFrontWall = CenterSweeper.Sweep(UpdatedComponent->GetWorld(), CapsuleRadius * 1.3f, SweepStart, SweepEnd);

		//	if (bHasFrontWall)
		//	{
		//		const FVector CenterWallNormalSide = (CenterSweeper.HitResult.ImpactNormal ^ UpdatedComponent->GetComponentQuat().GetUpVector());

		//		if (!((*OutWallNormal) - CenterWallNormalSide).IsNearlyZero(0.01f))
		//		{
		//			*OutWallNormal = (CenterWallNormalSide ^ ((*OutWallNormal) ^ CenterWallNormalSide)).GetSafeNormal();
		//		}

		//		::DrawDebugDirectionalArrow(UpdatedComponent->GetWorld(), 
		//			CenterSweeper.HitResult.ImpactPoint, 
		//			CenterSweeper.HitResult.ImpactPoint + (CenterSweeper.HitResult.ImpactNormal * 100.0f), 20.0f, FColor::Cyan, false, -1, 0, 5);
		//	}
		//}
	}

	return true;
}

static bool _FindClimbLandingRoof(ACharacter* CharacterOwner, USceneComponent* UpdatedComponent)
{
	if (!ensure(CharacterOwner) || !ensure(UpdatedComponent))
	{
		return false;
	}

	float CapsuleRadius, CapsuleHalfHeight;
	CharacterOwner->GetCapsuleComponent()->GetScaledCapsuleSize(CapsuleRadius, CapsuleHalfHeight);

	const float ROOT_MOTION_UP_DISTANCE = 200.0f;
	const float UP_MARGIN = 20.0f;
	const float SWEEP_SPHERE_RADIUS = 20.0f;
	const float ROOF_START_Z = ROOT_MOTION_UP_DISTANCE - CapsuleHalfHeight + SWEEP_SPHERE_RADIUS - UP_MARGIN;
	const float SWEEP_DISTANCE = CapsuleHalfHeight * 1.5f;

	const FVector HorizontalForwardVector = UpdatedComponent->GetComponentQuat().GetForwardVector().GetSafeNormal2D();

	FCollisionShape Sphere;
	Sphere.SetSphere(SWEEP_SPHERE_RADIUS);

	FHitResult HitResult;
	FCollisionQueryParams Params;
	FCollisionResponseParams Response;
	Params.AddIgnoredActor(CharacterOwner);

	bool bHasFrontWall = false;

	// See if we have empty spot forward at upper area
	{
		const FVector SweepStart = UpdatedComponent->GetComponentLocation() + (UpdatedComponent->GetComponentQuat().GetUpVector() * ROOF_START_Z);
		const FVector SweepEnd = SweepStart + (HorizontalForwardVector * SWEEP_DISTANCE);

		bHasFrontWall = UpdatedComponent->GetWorld()->SweepSingleByChannel(HitResult, SweepStart, SweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

#if ENABLE_DRAW_DEBUG
	if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
	{
		::DrawDebugCapsule(UpdatedComponent->GetWorld(), (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
			!bHasFrontWall ? FColor::Green : FColor::Red, false, 1.0f);

		if (bHasFrontWall)
		{
			::DrawDebugPoint(UpdatedComponent->GetWorld(), HitResult.ImpactPoint, 10.0f, FColor::Green);
		}
	}
#endif
	}

	if (!bHasFrontWall)
	{
		// See if we can climb up all the way there
		const FVector SweepStart = UpdatedComponent->GetComponentLocation();
		const FVector SweepEnd = SweepStart + (UpdatedComponent->GetComponentQuat().GetUpVector() * ROOF_START_Z);

		const bool bHasUpperBlocker = UpdatedComponent->GetWorld()->SweepSingleByChannel(HitResult, SweepStart, SweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

#if ENABLE_DRAW_DEBUG
		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			::DrawDebugCapsule(UpdatedComponent->GetWorld(), (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
				!bHasUpperBlocker ? FColor::Green : FColor::Red, false, 1.0f);
		}
#endif

		if (!bHasUpperBlocker)
		{
			return true;
		}
	}

	return false;
}

static bool _HasValidGroundDuringClimbLanding(USceneComponent* UpdatedComponent, const FVector& FeetLocation)
{
	if (!ensure(UpdatedComponent))
	{
		return false;
	}

	{
		const FVector SweepStart = FeetLocation;
		const FVector SweepEnd = SweepStart + (UpdatedComponent->GetComponentQuat().GetForwardVector() * 50.0f);

		FCollisionShape Sphere;
		Sphere.SetSphere(20.0f);

		FHitResult HitResult;
		FCollisionQueryParams Params;
		FCollisionResponseParams Response;

		const bool bHasFrontWall = UpdatedComponent->GetWorld()->SweepSingleByChannel(HitResult, SweepStart, SweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

#if ENABLE_DRAW_DEBUG
		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			::DrawDebugCapsule(UpdatedComponent->GetWorld(), (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
				bHasFrontWall ? FColor::Green : FColor::Red, false, 5.0f);

			if (bHasFrontWall)
			{
				::DrawDebugPoint(UpdatedComponent->GetWorld(), HitResult.ImpactPoint, 10.0f, FColor::Green);
			}
		}
#endif

		if (bHasFrontWall)
		{
			return true;
		}
	}

	{
		const FVector SweepStart = FeetLocation;
		const FVector SweepEnd = SweepStart + (UpdatedComponent->GetComponentQuat().GetUpVector() * -100.0f);

		FCollisionShape Sphere;
		Sphere.SetSphere(20.0f);

		FHitResult HitResult;
		FCollisionQueryParams Params;
		FCollisionResponseParams Response;

		const bool bHasGround = UpdatedComponent->GetWorld()->SweepSingleByChannel(HitResult, SweepStart, SweepEnd, FQuat::Identity, ECC_Pawn, Sphere, Params, Response);

#if ENABLE_DRAW_DEBUG
		if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
		{
			::DrawDebugCapsule(UpdatedComponent->GetWorld(), (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
				bHasGround ? FColor::Green : FColor::Red, false, 5.0f);

			if (bHasGround)
			{
				::DrawDebugPoint(UpdatedComponent->GetWorld(), HitResult.ImpactPoint, 10.0f, FColor::Green);
			}
		}
#endif

		if (bHasGround)
		{
			return true;
		}
	}

	return false;
}

void UP3CharacterMovementComponent::TickConsiderClimbing(float DeltaTime)
{
	ensure(P3MovementMode == P3Movement_None);

	if (!UpdatedComponent || CanClimbLeftSeconds > 0.0f)
	{
		return;
	}

	if (P3MovementMode == P3Movement_Sliding)
	{
		return;
	}

	AP3Character* Character = GetP3Character();
	if (Character && Character->GetStaminaComponent()->IsExhausted())
	{
		return;
	}

	ClimbingStatus.WalkingToClimbingTransitionTimeLeft = 0;

	const FVector LocalAcceleration = UpdatedComponent->GetComponentQuat().Inverse() * Acceleration;

	const bool bClimbDownActionInProgress = IsClimbDownActionInProgress();

	if (LocalAcceleration.X > 0 || bClimbDownActionInProgress)
	{
		bool bHasFrontalWall = _FindFrontalWall(CharacterOwner, UpdatedComponent, GetWalkableFloorZ(), (MovementMode == MOVE_Walking), &ClimbingStatus.ClimbingWallNormal);

		if (bHasFrontalWall)
		{
			if (MovementMode == MOVE_Walking && !bClimbDownActionInProgress)
			{
				if (-UpdatedComponent->GetComponentQuat().UnrotateVector(ClimbingStatus.ClimbingWallNormal).X < WalkToClimbX)
				{
					// Yaw angle is not enough
					return;
				}

				ClimbingStatus.WalkingToClimbingTransitionTimeLeft = WalkingToClimbingTransitionDuration;
			}

			if (bClimbDownActionInProgress)
			{
				Velocity.Set(0, 0, 0);
			}

			ChangeToClimbing();
		}
	}
}

void UP3CharacterMovementComponent::TickCalcFallingTime(float DeltaTime)
{
	CurrentFallingTimeAgeSeconds += DeltaTime;

	CurrentFallingReturnHomeCoolDownAgeSeconds = FMath::Clamp(CurrentFallingReturnHomeCoolDownAgeSeconds + DeltaTime, 0.0f, FallingReturnHomeCoolDown);
	if (CurrentFallingReturnHomeCoolDownAgeSeconds >= FallingReturnHomeCoolDown)
	{
		const UP3GameRule& GameRule = P3Core::GetGameRule(*this);

		if (GameRule.AcceptableFallingTimeSeconds > 0 && CurrentFallingTimeAgeSeconds >= GameRule.AcceptableFallingTimeSeconds)
		{
			AP3Character* Character = GetP3Character();
			if (!ensure(Character))
			{
				return;
			}

			StopMovementImmediately();

			AP3PlayerController* PlayerController = Cast<AP3PlayerController>(Character->GetController());
			if (PlayerController)
			{
				PlayerController->ReturnHome();
				PlayerController->ToastMessageBP(P3LOC_CHARACTER("SummonedByLongFalling"));
			}

			CurrentFallingReturnHomeCoolDownAgeSeconds = 0.0f;
		}
	}
}

void UP3CharacterMovementComponent::TickConsiderClimbDown(float DeltaTime)
{
	bClimbDownAvailable = false;

	if (!ensure(UpdatedPrimitive))
	{
		return;
	}

	const float CliffSweepDistance = CVarP3ClimbDownForwardSweepDebug.GetValueOnGameThread();
	const float CliffSweepDepth = CVarP3ClimbDownDownwardSweepDebug.GetValueOnGameThread();
	const float CliffHoldingDistance = CVarP3ClimbDownBackwardSweepDebug.GetValueOnGameThread();

	// First, we should have nothing that blocks me ahead
	{
		const FVector SweepStart = UpdatedPrimitive->GetComponentLocation();
		const FVector SweepEnd = SweepStart + (UpdatedPrimitive->GetComponentQuat().GetForwardVector() * CliffSweepDistance);
		const FQuat InitialRotationQuat = UpdatedPrimitive->GetComponentTransform().GetRotation();

		FComponentQueryParams Params(SCENE_QUERY_STAT(MoveComponent), UpdatedPrimitive->GetOwner());
		FCollisionResponseParams ResponseParam;
		UpdatedPrimitive->InitSweepCollisionParams(Params, ResponseParam);
		Params.bIgnoreTouches = true;

		TArray<FHitResult> HitResults;
		const bool bHit = GetWorld()->ComponentSweepMulti(HitResults, UpdatedPrimitive, SweepStart, SweepEnd, InitialRotationQuat, Params);

		if (bHit)
		{
			// Found blocker ahead, can't hang
			return;
		}

//#if ENABLE_DRAW_DEBUG
//		if (CVarP3MovementDebug.GetValueOnGameThread() > 1)
//		{
//			::DrawDebugCapsule(UpdatedComponent->GetWorld(), (SweepEnd + SweepStart) * 0.5f, (SweepEnd - SweepStart).Size() * 0.5f + Sphere.GetCapsuleRadius(), Sphere.GetCapsuleRadius(), FRotationMatrix::MakeFromZ((SweepEnd - SweepStart)).ToQuat(),
//				bHasFrontWall ? FColor::Green : FColor::Red, false, 1.0f);
//
//			if (bHasFrontWall)
//			{
//				::DrawDebugPoint(UpdatedComponent->GetWorld(), HitResult.ImpactPoint, 10.0f, FColor::Green);
//			}
//		}
//#endif
	}

	// See if we don't have ground ahead
	{
		const FVector SweepStart = UpdatedPrimitive->GetComponentLocation() + (UpdatedPrimitive->GetComponentQuat().GetForwardVector() * CliffSweepDistance);
		const FVector SweepEnd = SweepStart + (UpdatedPrimitive->GetComponentQuat().GetUpVector() * -CliffSweepDepth);
		const FQuat InitialRotationQuat = UpdatedPrimitive->GetComponentTransform().GetRotation();

		FComponentQueryParams Params(SCENE_QUERY_STAT(MoveComponent), UpdatedPrimitive->GetOwner());
		FCollisionResponseParams ResponseParam;
		UpdatedPrimitive->InitSweepCollisionParams(Params, ResponseParam);
		Params.bIgnoreTouches = true;

		TArray<FHitResult> HitResults;
		const bool bHit = GetWorld()->ComponentSweepMulti(HitResults, UpdatedPrimitive, SweepStart, SweepEnd, InitialRotationQuat, Params);

		if (bHit)
		{
			// Found blocker down there, can't hang
			return;
		}
	}

	// See if we have something to hold on
	{
		const FVector SweepStart = UpdatedPrimitive->GetComponentLocation() 
			+ (UpdatedPrimitive->GetComponentQuat().GetForwardVector() * CliffSweepDistance)
			+ (UpdatedPrimitive->GetComponentQuat().GetUpVector() * -CliffSweepDepth);
		const FVector SweepEnd = SweepStart + (UpdatedPrimitive->GetComponentQuat().GetForwardVector() * -CliffHoldingDistance);
		const FQuat InitialRotationQuat = UpdatedPrimitive->GetComponentTransform().GetRotation();

		FComponentQueryParams Params(SCENE_QUERY_STAT(MoveComponent), UpdatedPrimitive->GetOwner());
		FCollisionResponseParams ResponseParam;
		UpdatedPrimitive->InitSweepCollisionParams(Params, ResponseParam);
		Params.bIgnoreTouches = true;

		TArray<FHitResult> HitResults;
		const bool bHit = GetWorld()->ComponentSweepMulti(HitResults, UpdatedPrimitive, SweepStart, SweepEnd, InitialRotationQuat, Params);

		if (!bHit)
		{
			// Nothing to hold on
			return;
		}
	}

	bClimbDownAvailable = true;
}

bool UP3CharacterMovementComponent::IsGlidingPossibleWithJump() const
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return false;
	}

	UP3StaminaPointComponent* StaminaComp = Character->GetStaminaComponent();
	if (!StaminaComp || StaminaComp->IsExhausted())
	{
		return false;
	}


	bool bEffectedWind = false;
	bool bFoundFloor = false;

	for (const FP3CharacterMovementForce& Force : Forces)
	{
		if (Force.Type == FP3CharacterMovementForce::EType::Wind)
		{
			bEffectedWind = true;
			break;
		}
	}

	if (!bEffectedWind)
	{
		FHitResult HitResult;

		FCollisionQueryParams Params;
		Params.AddIgnoredActor(Character);

		TArray<AActor*> AttachedActors;
		Character->GetAttachedActors(AttachedActors);
		Params.AddIgnoredActors(AttachedActors);

		const float SphereRadius = CVarP3GlidingCheckSphereRadius.GetValueOnGameThread();
		FCollisionShape Shape;
		Shape.SetSphere(SphereRadius);

		float CapsuleRadius, CapsuleHalfHeight;
		CharacterOwner->GetCapsuleComponent()->GetScaledCapsuleSize(CapsuleRadius, CapsuleHalfHeight);

		const FVector StartLocation = Character->GetActorLocation() - FVector(0, 0, CapsuleHalfHeight);
		const FVector EndLocation = StartLocation - FVector(0, 0, CVarP3GlidingEnableHeight.GetValueOnGameThread());

		bFoundFloor = GetWorld()->SweepSingleByChannel(HitResult, StartLocation, EndLocation, FQuat::Identity, ECC_Pawn, Shape, Params);

		if (CVarP3GlidingDebug.GetValueOnGameThread() > 0)
		{
			AActor* FloorActor = HitResult.GetActor();
			UActorComponent* FloorComp = HitResult.GetComponent();

			DrawDebugSphere(GetWorld(), EndLocation, SphereRadius, 20, FColor::Red, true, 5, 0, 1);
		}
	}

	return (!bFoundFloor || bEffectedWind);
}

void UP3CharacterMovementComponent::ConsiderGliding()
{
	AP3Character* Character = GetP3Character();
	if (!ensure(Character))
	{
		return;
	}

	if (IsGlidingPossibleWithJump())
	{
		GlidingJumpCount = Character->JumpCurrentCount + 1;
		SetMovementMode(MOVE_Custom, P3Movement_Gliding);
	}
}

void UP3CharacterMovementComponent::PhysClimbing(float DeltaTime, int32 Iterations)
{
	if (DeltaTime < MIN_TICK_TIME)
	{
		return;
	}

	if (!ensure(UpdatedComponent))
	{
		return;
	}

	ClimbingStatus.WalkingToClimbingTransitionTimeLeft = FMath::Max(0.0f, ClimbingStatus.WalkingToClimbingTransitionTimeLeft - DeltaTime);

	if (ClimbingStatus.WalkingToClimbingTransitionTimeLeft > 0)
	{
		// Still in transition, if player stop moving forward, cancel climbing

		const FVector LocalAcceleration = UpdatedComponent->GetComponentQuat().Inverse() * Acceleration;

		if (!ClimbingStatus.bIsLandingOnRoof && LocalAcceleration.X <= 0)
		{
			ClimbingStatus.WalkingToClimbingTransitionTimeLeft = 0;

			SetMovementMode(MOVE_Falling);
			StartNewPhysics(DeltaTime, Iterations);
			return;
		}
	}

	if (bSprintingPressed)
	{
		SetMovementMode(MOVE_Falling);
		StartNewPhysics(DeltaTime, Iterations);
		return;
	}

	float RemainingTime = DeltaTime;

	while ((RemainingTime >= MIN_TICK_TIME) && (Iterations < MaxSimulationIterations) && CharacterOwner && (CharacterOwner->Controller || bRunPhysicsWithNoController || /*HasAnimRootMotion() || CurrentRootMotion.HasOverrideVelocity() || */(CharacterOwner->Role == ROLE_SimulatedProxy)))
	{
		Iterations++;
		bJustTeleported = false;
		const float TimeTick = GetSimulationTimeStep(RemainingTime, Iterations);
		RemainingTime -= TimeTick;
		
		FVector DeltaMovement(FVector::ZeroVector);

		if (ClimbingStatus.bIsLandingOnRoof)
		{
			ClimbingStatus.LandingAgeSeconds += TimeTick;

			const bool bHasValidGroundToLand = _HasValidGroundDuringClimbLanding(UpdatedComponent, GetActorFeetLocation());

			if (!bHasValidGroundToLand || (ClimbingStatus.LandingAgeSeconds > 1.5f))	// Todo: get timeout seconds from landing animation length
			{
				SetMovementMode(MOVE_Falling);
				StartNewPhysics(RemainingTime, Iterations);
				return;
			}
		}

		if (HasAnimRootMotion() || CurrentRootMotion.HasOverrideVelocity())
		{
			Velocity.Set(0, 0, 0);
			ApplyRootMotionToVelocity(TimeTick);

			DeltaMovement = Velocity * TimeTick;
		}
		else
		{
			CalcVelocity(TimeTick, GroundFriction, false, GetMaxBrakingDeceleration());

			ClimbingStatus.JumpVelocity = FMath::Max(0.0f, ClimbingStatus.JumpVelocity + (GetGravityZ() * TimeTick));

			DeltaMovement = Velocity * TimeTick;

			DeltaMovement = UpdatedComponent->GetComponentQuat().Inverse() * DeltaMovement;
			DeltaMovement.Z = DeltaMovement.X;
			DeltaMovement.X = FMath::Max(FMath::Abs(DeltaMovement.Z) + FMath::Abs(DeltaMovement.Y), 0.0f) * 0.1f;	// Always stick to the wall
			DeltaMovement = UpdatedComponent->GetComponentQuat() * DeltaMovement;

			DeltaMovement.Z += ClimbingStatus.JumpVelocity * TimeTick;

			//DeltaMovement -= ClimbingStatus.ClimbingWallNormal * (DeltaMovement | ClimbingStatus.ClimbingWallNormal);
		}

		FHitResult Hit;
		SafeMoveUpdatedComponent(DeltaMovement, UpdatedComponent->GetComponentQuat(), true, Hit);

		if (!HasValidData() || ClimbingStatus.ClimbingWallNormal.ContainsNaN())
		{
			return;
		}

		float SubTimeTickRemaining = TimeTick * (1.f - Hit.Time);

		if (Hit.bBlockingHit)
		{
			if (IsValidLandingSpot(UpdatedComponent->GetComponentLocation(), Hit))
			{
				RemainingTime += SubTimeTickRemaining;

				SetMovementMode(MOVE_Walking);
				StartNewPhysics(RemainingTime, Iterations);
				return;
			}

			// TODO.. resolve collision
			// Copy from UCharacterMovementComponent::PhysFalling line 4021

			const FVector SlideDeltaMovement = ComputeSlideVector(DeltaMovement, 1.f - Hit.Time, Hit.Normal, Hit);

			SafeMoveUpdatedComponent(SlideDeltaMovement, UpdatedComponent->GetComponentQuat(), true, Hit);

			if (Hit.bBlockingHit)
			{
				// Hit second spot, bail out
				return;
			}
		}

		if (ClimbingStatus.WalkingToClimbingTransitionTimeLeft <= 0.0f
			&& !IsClimbStartActionInProgress()
			&& !IsClimbEndActionInProgress())
		{
			// See if we can walk from here

			const FVector PawnLocation = UpdatedComponent->GetComponentLocation();
			FFindFloorResult FloorResult;
			FindFloor(PawnLocation, FloorResult, false);
			if (FloorResult.IsWalkableFloor()/* && IsValidLandingSpot(PawnLocation, FloorResult.HitResult)*/)
			{
				RemainingTime += SubTimeTickRemaining;
				SetMovementMode(MOVE_Walking);
				StartNewPhysics(RemainingTime, Iterations);
				//ProcessLanded(FloorResult.HitResult, RemainingTime, Iterations);
				return;
			}
		}

		if (!ClimbingStatus.bIsLandingOnRoof && DeltaMovement.Z > 0)
		{
			const bool bFoundRoof =  _FindClimbLandingRoof(CharacterOwner, UpdatedComponent);
			if (bFoundRoof)
			{
				ClimbingStatus.bIsLandingOnRoof = true;
				ClimbingStatus.LandingAgeSeconds = 0;

				if (CharacterOwner &&
					(IsAutonomousProxy(CharacterOwner) || 
					(IsAuthority(CharacterOwner) && CharacterOwner->GetRemoteRole() == ROLE_SimulatedProxy)))
				{
					AP3Character* Character = GetP3Character();
					UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
					if (ensure(ActionComp))
					{
						ActionComp->StartAction(EPawnActionType::ClimbEnd, _FUNCTION_TEXT);
					}
				}
			}
		}

		if (!ClimbingStatus.bIsLandingOnRoof)
		{
			const bool bHasFrontalWall = _FindFrontalWall(CharacterOwner, UpdatedComponent, GetWalkableFloorZ(), (MovementMode == MOVE_Walking), &ClimbingStatus.ClimbingWallNormal);

			if (!bHasFrontalWall)
			{
				SetMovementMode(MOVE_Falling);
				StartNewPhysics(RemainingTime, Iterations);
				return;
			}
		}
	}
}

void UP3CharacterMovementComponent::PhysGliding(float DeltaTime, int32 Iterations)
{
	if (DeltaTime < MIN_TICK_TIME)
	{
		return;
	}

	TGuardValue<float> RestoreAirControl(AirControl, 1.0f);
	TGuardValue<float> RestoreGravityScale(GravityScale, 0.3f);

	FVector FallAcceleration = GetFallingLateralAcceleration(DeltaTime);
	FallAcceleration.Z = 0.f;
	const bool bHasAirControl = (FallAcceleration.SizeSquared2D() > 0.f);

	float remainingTime = DeltaTime;
	while ((remainingTime >= MIN_TICK_TIME) && (Iterations < MaxSimulationIterations))
	{
		Iterations++;
		const float timeTick = GetSimulationTimeStep(remainingTime, Iterations);
		remainingTime -= timeTick;

		const FVector OldLocation = UpdatedComponent->GetComponentLocation();
		const FQuat PawnRotation = UpdatedComponent->GetComponentQuat();
		bJustTeleported = false;

		RestorePreAdditiveRootMotionVelocity();

		FVector OldVelocity = Velocity;
		FVector VelocityNoAirControl = Velocity;

		// Apply input
		if (!HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity())
		{
			const float MaxDecel = GetMaxBrakingDeceleration();
			// Compute VelocityNoAirControl
			if (bHasAirControl)
			{
				// Find velocity *without* acceleration.
				TGuardValue<FVector> RestoreAcceleration(Acceleration, FVector::ZeroVector);
				TGuardValue<FVector> RestoreVelocity(Velocity, Velocity);
				Velocity.Z = 0.f;
				CalcVelocity(timeTick, FallingLateralFriction, false, MaxDecel);
				VelocityNoAirControl = FVector(Velocity.X, Velocity.Y, OldVelocity.Z);
			}

			// Compute Velocity
			{
				// Acceleration = FallAcceleration for CalcVelocity(), but we restore it after using it.
				TGuardValue<FVector> RestoreAcceleration(Acceleration, FallAcceleration);
				Velocity.Z = 0.f;
				CalcVelocity(timeTick, FallingLateralFriction, false, MaxDecel);
				Velocity.Z = OldVelocity.Z;
			}

			// Just copy Velocity to VelocityNoAirControl if they are the same (ie no acceleration).
			if (!bHasAirControl)
			{
				VelocityNoAirControl = Velocity;
			}
		}

		// Apply gravity
		const FVector Gravity(0.f, 0.f, GetGravityZ());
		Velocity = NewFallVelocity(Velocity, Gravity, timeTick);
		VelocityNoAirControl = NewFallVelocity(VelocityNoAirControl, Gravity, timeTick);
		const FVector AirControlAccel = (Velocity - VelocityNoAirControl) / timeTick;

		ApplyRootMotionToVelocity(timeTick);

		if (bNotifyApex && CharacterOwner->Controller && (Velocity.Z <= 0.f))
		{
			// Just passed jump apex since now going down
			bNotifyApex = false;
			NotifyJumpApex();
		}


		// Move
		FHitResult Hit(1.f);
		FVector Adjusted = 0.5f * (OldVelocity + Velocity) * timeTick;
		SafeMoveUpdatedComponent(Adjusted, PawnRotation, true, Hit);

		if (!HasValidData())
		{
			return;
		}

		float LastMoveTimeSlice = timeTick;
		float subTimeTickRemaining = timeTick * (1.f - Hit.Time);

		if (IsSwimming()) //just entered water
		{
			remainingTime += subTimeTickRemaining;
			StartSwimming(OldLocation, OldVelocity, timeTick, remainingTime, Iterations);
			return;
		}
		else if (Hit.bBlockingHit)
		{
			if (IsValidLandingSpot(UpdatedComponent->GetComponentLocation(), Hit))
			{
				remainingTime += subTimeTickRemaining;
				ProcessLanded(Hit, remainingTime, Iterations);
				return;
			}
			else
			{
				// Compute impact deflection based on final velocity, not integration step.
				// This allows us to compute a new velocity from the deflected vector, and ensures the full gravity effect is included in the slide result.
				Adjusted = Velocity * timeTick;

				// See if we can convert a normally invalid landing spot (based on the hit result) to a usable one.
				if (!Hit.bStartPenetrating && ShouldCheckForValidLandingSpot(timeTick, Adjusted, Hit))
				{
					const FVector PawnLocation = UpdatedComponent->GetComponentLocation();
					FFindFloorResult FloorResult;
					FindFloor(PawnLocation, FloorResult, false);
					if (FloorResult.IsWalkableFloor() && IsValidLandingSpot(PawnLocation, FloorResult.HitResult))
					{
						remainingTime += subTimeTickRemaining;
						ProcessLanded(FloorResult.HitResult, remainingTime, Iterations);
						return;
					}
				}

				HandleImpact(Hit, LastMoveTimeSlice, Adjusted);

				// If we've changed physics mode, abort.
				if (!HasValidData() || !IsGliding())
				{
					return;
				}

				// Limit air control based on what we hit.
				// We moved to the impact point using air control, but may want to deflect from there based on a limited air control acceleration.
				if (bHasAirControl)
				{
					const bool bCheckLandingSpot = false; // we already checked above.
					const FVector AirControlDeltaV = LimitAirControl(LastMoveTimeSlice, AirControlAccel, Hit, bCheckLandingSpot) * LastMoveTimeSlice;
					Adjusted = (VelocityNoAirControl + AirControlDeltaV) * LastMoveTimeSlice;
				}

				const FVector OldHitNormal = Hit.Normal;
				const FVector OldHitImpactNormal = Hit.ImpactNormal;
				FVector Delta = ComputeSlideVector(Adjusted, 1.f - Hit.Time, OldHitNormal, Hit);

				// Compute velocity after deflection (only gravity component for RootMotion)
				if (subTimeTickRemaining > KINDA_SMALL_NUMBER && !bJustTeleported)
				{
					const FVector NewVelocity = (Delta / subTimeTickRemaining);
					Velocity = HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity() ? FVector(Velocity.X, Velocity.Y, NewVelocity.Z) : NewVelocity;
				}

				if (subTimeTickRemaining > KINDA_SMALL_NUMBER && (Delta | Adjusted) > 0.f)
				{
					// Move in deflected direction.
					SafeMoveUpdatedComponent(Delta, PawnRotation, true, Hit);

					if (Hit.bBlockingHit)
					{
						// hit second wall
						LastMoveTimeSlice = subTimeTickRemaining;
						subTimeTickRemaining = subTimeTickRemaining * (1.f - Hit.Time);

						if (IsValidLandingSpot(UpdatedComponent->GetComponentLocation(), Hit))
						{
							remainingTime += subTimeTickRemaining;
							ProcessLanded(Hit, remainingTime, Iterations);
							return;
						}

						HandleImpact(Hit, LastMoveTimeSlice, Delta);

						// If we've changed physics mode, abort.
						if (!HasValidData() || !IsGliding())
						{
							return;
						}

						const float VERTICAL_SLOPE_NORMAL_Z = 0.001f; // Slope is vertical if Abs(Normal.Z) <= this threshold. Accounts for precision problems that sometimes angle normals slightly off horizontal for vertical surface.

						// Act as if there was no air control on the last move when computing new deflection.
						if (bHasAirControl && Hit.Normal.Z > VERTICAL_SLOPE_NORMAL_Z)
						{
							const FVector LastMoveNoAirControl = VelocityNoAirControl * LastMoveTimeSlice;
							Delta = ComputeSlideVector(LastMoveNoAirControl, 1.f, OldHitNormal, Hit);
						}

						FVector PreTwoWallDelta = Delta;
						TwoWallAdjust(Delta, Hit, OldHitNormal);

						// Limit air control, but allow a slide along the second wall.
						if (bHasAirControl)
						{
							const bool bCheckLandingSpot = false; // we already checked above.
							const FVector AirControlDeltaV = LimitAirControl(subTimeTickRemaining, AirControlAccel, Hit, bCheckLandingSpot) * subTimeTickRemaining;

							// Only allow if not back in to first wall
							if (FVector::DotProduct(AirControlDeltaV, OldHitNormal) > 0.f)
							{
								Delta += (AirControlDeltaV * subTimeTickRemaining);
							}
						}

						// Compute velocity after deflection (only gravity component for RootMotion)
						if (subTimeTickRemaining > KINDA_SMALL_NUMBER && !bJustTeleported)
						{
							const FVector NewVelocity = (Delta / subTimeTickRemaining);
							Velocity = HasAnimRootMotion() && !CurrentRootMotion.HasOverrideVelocity() ? FVector(Velocity.X, Velocity.Y, NewVelocity.Z) : NewVelocity;
						}

						// bDitch=true means that pawn is straddling two slopes, neither of which he can stand on
						bool bDitch = ((OldHitImpactNormal.Z > 0.f) && (Hit.ImpactNormal.Z > 0.f) && (FMath::Abs(Delta.Z) <= KINDA_SMALL_NUMBER) && ((Hit.ImpactNormal | OldHitImpactNormal) < 0.f));
						SafeMoveUpdatedComponent(Delta, PawnRotation, true, Hit);
						if (Hit.Time == 0.f)
						{
							// if we are stuck then try to side step
							FVector SideDelta = (OldHitNormal + Hit.ImpactNormal).GetSafeNormal2D();
							if (SideDelta.IsNearlyZero())
							{
								SideDelta = FVector(OldHitNormal.Y, -OldHitNormal.X, 0).GetSafeNormal();
							}
							SafeMoveUpdatedComponent(SideDelta, PawnRotation, true, Hit);
						}

						if (bDitch || IsValidLandingSpot(UpdatedComponent->GetComponentLocation(), Hit) || Hit.Time == 0.f)
						{
							remainingTime = 0.f;
							ProcessLanded(Hit, remainingTime, Iterations);
							return;
						}
						else if (GetPerchRadiusThreshold() > 0.f && Hit.Time == 1.f && OldHitImpactNormal.Z >= GetWalkableFloorZ())
						{
							// We might be in a virtual 'ditch' within our perch radius. This is rare.
							const FVector PawnLocation = UpdatedComponent->GetComponentLocation();
							const float ZMovedDist = FMath::Abs(PawnLocation.Z - OldLocation.Z);
							const float MovedDist2DSq = (PawnLocation - OldLocation).SizeSquared2D();
							if (ZMovedDist <= 0.2f * timeTick && MovedDist2DSq <= 4.f * timeTick)
							{
								Velocity.X += 0.25f * GetMaxSpeed() * (FMath::FRand() - 0.5f);
								Velocity.Y += 0.25f * GetMaxSpeed() * (FMath::FRand() - 0.5f);
								Velocity.Z = FMath::Max<float>(JumpZVelocity * 0.25f, 1.f);
								Delta = Velocity * timeTick;
								SafeMoveUpdatedComponent(Delta, PawnRotation, true, Hit);
							}
						}
					}
				}
			}
		}

		if (Velocity.SizeSquared2D() <= KINDA_SMALL_NUMBER * 10.f)
		{
			Velocity.X = 0.f;
			Velocity.Y = 0.f;
		}
	}
}

void UP3CharacterMovementComponent::PhysSliding(float DeltaTime, int32 Iterations)
{
	if (CharacterOwner && CharacterOwner->Role != ROLE_SimulatedProxy)
	{
		bool bStopSliding = false;

		if (CharacterOwner->JumpCurrentCount == 0 || CharacterOwner->bPressedJump == 0)
		{
			bStopSliding = true;
		}
		else if (Velocity.Size() < 10.0f)
		{
			bStopSliding = true;
		}

		// Stop sliding if moving backward
		if ((UpdatedComponent->GetForwardVector() | Velocity) < 0.0f)
		{
			bStopSliding = true;
		}

		if (bStopSliding)
		{
			SetMovementMode(MOVE_Walking);
		}
	}

	PhysWalking(DeltaTime, Iterations);
}

void UP3CharacterMovementComponent::ChangeToClimbing()
{
	const EMovementMode OldMovementMode = MovementMode;

	SetMovementMode(EMovementMode::MOVE_Custom, static_cast<uint8>(P3Movement_Climbing));

	P3MovementMode = P3Movement_Climbing;

	ClimbingStatus.JumpVelocity = 0.0f;

	if (OldMovementMode == MOVE_Walking)
	{
		// In case of walking -> climbing, we need to jump a little bit.
		// Otherwise, PhysClimbing will detect ground and finish climbing right away

		if (CharacterOwner &&
			(IsAutonomousProxy(CharacterOwner) ||
			(IsAuthority(CharacterOwner) && CharacterOwner->GetRemoteRole() == ROLE_SimulatedProxy)))
		{
			AP3Character* Character = GetP3Character();
			UP3PawnActionComponent* ActionComp = Character ? Character->GetActionComponent() : nullptr;
			if (ensure(ActionComp))
			{
				ActionComp->StartAction(EPawnActionType::ClimbStart, _FUNCTION_TEXT);
			}
		}
	}

	if (IsLocalControlledActor(CharacterOwner))
	{
		AP3Character* Character = GetP3Character();
		if (Character)
		{
			Character->OnStartClimb();
		}
	}
}


bool UP3CharacterMovementComponent::CanTryParkour() const
{
	if (!bParkourAllowed)
	{
		return false;
	}

	UP3GameUserSettings* UserSettings = Cast<UP3GameUserSettings>(GEngine->GetGameUserSettings());
	if (UserSettings)
	{
		const bool bJumpInputRequired = UserSettings->GetUseJumpToParkour();

		if (bJumpInputRequired
			&& (!CharacterOwner || !CharacterOwner->bPressedJump))
		{
			return false;
		}
	}

	return true;
}

bool UP3CharacterMovementComponent::IsClimbStartActionInProgress() const
{
	AP3Character* Character = GetP3Character();
	UP3PawnActionComponent* ActionComp = (Character ? Character->GetActionComponent() : nullptr);

	if (!ActionComp)
	{
		return false;
	}

	return ActionComp->IsActionInProgress(EPawnActionType::ClimbStart);
}

bool UP3CharacterMovementComponent::IsClimbEndActionInProgress() const
{
	AP3Character* Character = GetP3Character();
	UP3PawnActionComponent* ActionComp = (Character ? Character->GetActionComponent() : nullptr);

	if (!ActionComp)
	{
		return false;
	}

	return ActionComp->IsActionInProgress(EPawnActionType::ClimbEnd);
}

bool UP3CharacterMovementComponent::IsClimbDownActionInProgress() const
{
	AP3Character* Character = GetP3Character();
	UP3PawnActionComponent* ActionComp = (Character ? Character->GetActionComponent() : nullptr);

	if (!ActionComp)
	{
		return false;
	}

	return ActionComp->IsActionInProgress(EPawnActionType::ClimbDown);
}

void UP3CharacterMovementComponent::ServerMoveOld(float OldTimeStamp, FVector_NetQuantize10 OldAccel, uint8 OldMoveFlags)
{
	FP3NetServerMoveOld Packet;
	Packet.OldTimeStamp = OldTimeStamp;
	Packet.OldAccel = OldAccel;
	Packet.OldMoveFlags = OldMoveFlags;

	UP3World* P3World = P3Core::GetP3World(*this);
	const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	P3World->Client_SendPacket(this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Server_HandleMoveOld);
}

void UP3CharacterMovementComponent::ServerMove(float TimeStamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8 CompressedMoveFlags, uint8 ClientRoll, uint32 View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode)
{
	FP3NetServerMove Packet;
	Packet.TimeStamp = TimeStamp;
	Packet.InAccel = InAccel;
	Packet.ClientLoc = ClientLoc;
	Packet.CompressedMoveFlags = CompressedMoveFlags;
	Packet.ClientRoll = ClientRoll;
	Packet.View = View;
	Packet.ClientMovementBase = CVarP3MovementSyncBase.GetValueOnGameThread() == 0 ? nullptr : ClientMovementBase;
	Packet.ClientBaseBoneName = ClientBaseBoneName;
	Packet.ClientMovementMode = ClientMovementMode;

	UP3World* P3World = P3Core::GetP3World(*this);
	const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	P3World->Client_SendPacket(this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Server_HandleMove);
}

void UP3CharacterMovementComponent::ServerMoveDual(float TimeStamp0, FVector_NetQuantize10 InAccel0, uint8 PendingFlags, uint32 View0, float TimeStamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8 NewFlags, uint8 ClientRoll, uint32 View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode)
{
	FP3NetServerMoveDual Packet;
	Packet.TimeStamp0 = TimeStamp0;
	Packet.InAccel0 = InAccel0;
	Packet.PendingFlags = PendingFlags;
	Packet.View0 = View0;
	Packet.TimeStamp = TimeStamp;
	Packet.InAccel = InAccel;
	Packet.ClientLoc = ClientLoc;
	Packet.NewFlags = NewFlags;
	Packet.ClientRoll = ClientRoll;
	Packet.View = View;
	Packet.ClientMovementBase = CVarP3MovementSyncBase.GetValueOnGameThread() == 0 ? nullptr : ClientMovementBase;
	Packet.ClientBaseBoneName = ClientBaseBoneName;
	Packet.ClientMovementMode = ClientMovementMode;

	UP3World* P3World = P3Core::GetP3World(*this);
	const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	P3World->Client_SendPacket(this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Server_HandleMoveDual);
}

void UP3CharacterMovementComponent::ServerMoveDualHybridRootMotion(float TimeStamp0, FVector_NetQuantize10 InAccel0, uint8 PendingFlags, uint32 View0, float TimeStamp, FVector_NetQuantize10 InAccel, FVector_NetQuantize100 ClientLoc, uint8 NewFlags, uint8 ClientRoll, uint32 View, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode)
{
	FP3NetServerMoveDual Packet;
	Packet.TimeStamp0 = TimeStamp0;
	Packet.InAccel0 = InAccel0;
	Packet.PendingFlags = PendingFlags;
	Packet.View0 = View0;
	Packet.TimeStamp = TimeStamp;
	Packet.InAccel = InAccel;
	Packet.ClientLoc = ClientLoc;
	Packet.NewFlags = NewFlags;
	Packet.ClientRoll = ClientRoll;
	Packet.View = View;
	Packet.ClientMovementBase = CVarP3MovementSyncBase.GetValueOnGameThread() == 0 ? nullptr : ClientMovementBase;
	Packet.ClientBaseBoneName = ClientBaseBoneName;
	Packet.ClientMovementMode = ClientMovementMode;

	UP3World* P3World = P3Core::GetP3World(*this);
	const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	P3World->Client_SendPacketReliable(this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Server_HandleMoveDualHybridRootMotion);
}

// P3 Override version
void UP3CharacterMovementComponent::ServerMoveHandleClientError(float ClientTimeStamp, float DeltaTime, const FVector& Accel, const FVector& RelativeClientLoc, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode)
{
	if (RelativeClientLoc == FVector(1.f,2.f,3.f)) // first part of double servermove
	{
		return;
	}

	FNetworkPredictionData_Server_Character* ServerData = GetPredictionData_Server_Character();
	check(ServerData);

	// Don't prevent more recent updates from being sent if received this frame.
	// We're going to send out an update anyway, might as well be the most recent one.
	APlayerController* PC = Cast<APlayerController>(CharacterOwner->GetController());
	if( (ServerData->LastUpdateTime != GetWorld()->TimeSeconds))
	{
		const AGameNetworkManager* GameNetworkManager = (const AGameNetworkManager*)(AGameNetworkManager::StaticClass()->GetDefaultObject());
		if (GameNetworkManager->WithinUpdateDelayBounds(PC, ServerData->LastUpdateTime))
		{
			return;
		}
	}

	// Offset may be relative to base component
	FVector ClientLoc = RelativeClientLoc;
	if (MovementBaseUtility::UseRelativeLocation(ClientMovementBase))
	{
		FVector BaseLocation;
		FQuat BaseRotation;
		MovementBaseUtility::GetMovementBaseTransform(ClientMovementBase, ClientBaseBoneName, BaseLocation, BaseRotation);
		ClientLoc += BaseLocation;
	}

	// Client may send a null movement base when walking on bases with no relative location (to save bandwidth).
	// In this case don't check movement base in error conditions, use the server one (which avoids an error based on differing bases). Position will still be validated.
	if (ClientMovementBase == nullptr && ClientMovementMode == MOVE_Walking)
	{
		ClientMovementBase = CharacterOwner->GetBasedMovement().MovementBase;
		ClientBaseBoneName = CharacterOwner->GetBasedMovement().BoneName;
	}

	// Compute the client error from the server's position
	// If client has accumulated a noticeable positional error, correct them.
	bNetworkLargeClientCorrection = ServerData->bForceClientUpdate;
	if (ServerData->bForceClientUpdate || ServerCheckClientError(ClientTimeStamp, DeltaTime, Accel, ClientLoc, RelativeClientLoc, ClientMovementBase, ClientBaseBoneName, ClientMovementMode))
	{
		UPrimitiveComponent* MovementBase = CharacterOwner->GetMovementBase();
		ServerData->PendingAdjustment.NewVel = Velocity;
		ServerData->PendingAdjustment.NewBase = MovementBase;
		ServerData->PendingAdjustment.NewBaseBoneName = CharacterOwner->GetBasedMovement().BoneName;
		ServerData->PendingAdjustment.NewLoc = FRepMovement::RebaseOntoZeroOrigin(UpdatedComponent->GetComponentLocation(), this);
		ServerData->PendingAdjustment.NewRot = UpdatedComponent->GetComponentRotation();

		ServerData->PendingAdjustment.bBaseRelativePosition = MovementBaseUtility::UseRelativeLocation(MovementBase);
		if (ServerData->PendingAdjustment.bBaseRelativePosition)
		{
			// Relative location
			ServerData->PendingAdjustment.NewLoc = CharacterOwner->GetBasedMovement().Location;
			
			// TODO: this could be a relative rotation, but all client corrections ignore rotation right now except the root motion one, which would need to be updated.
			//ServerData->PendingAdjustment.NewRot = CharacterOwner->GetBasedMovement().Rotation;
		}


#if !UE_BUILD_SHIPPING
		const static IConsoleVariable* NetShowCorrections = IConsoleManager::Get().FindConsoleVariable(TEXT("p.NetShowCorrections"));
		const static IConsoleVariable* NetCorrectionLifetime = IConsoleManager::Get().FindConsoleVariable(TEXT("p.NetCorrectionLifetime"));

		if (NetShowCorrections && NetShowCorrections->GetInt() != 0 && NetCorrectionLifetime)
		{
			const FVector LocDiff = UpdatedComponent->GetComponentLocation() - ClientLoc;
			const FString BaseString = MovementBase ? MovementBase->GetPathName(MovementBase->GetOutermost()) : TEXT("None");
			UE_LOG(LogNetPlayerMovement, Warning, TEXT("*** Server: Error for %s at Time=%.3f is %3.3f LocDiff(%s) ClientLoc(%s) ServerLoc(%s) Base: %s Bone: %s Accel(%s) Velocity(%s)"),
				*GetNameSafe(CharacterOwner), ClientTimeStamp, LocDiff.Size(), *LocDiff.ToString(), *ClientLoc.ToString(), *UpdatedComponent->GetComponentLocation().ToString(), *BaseString, *ServerData->PendingAdjustment.NewBaseBoneName.ToString(), *Accel.ToString(), *Velocity.ToString());
			const float DebugLifetime = NetCorrectionLifetime->GetFloat();
			DrawDebugCapsule(GetWorld(), UpdatedComponent->GetComponentLocation(), CharacterOwner->GetSimpleCollisionHalfHeight(), CharacterOwner->GetSimpleCollisionRadius(), FQuat::Identity, FColor(100, 255, 100), true, DebugLifetime);
			DrawDebugCapsule(GetWorld(), ClientLoc                    , CharacterOwner->GetSimpleCollisionHalfHeight(), CharacterOwner->GetSimpleCollisionRadius(), FQuat::Identity, FColor(255, 100, 100), true, DebugLifetime);
		}
#endif

		ServerData->LastUpdateTime = GetWorld()->TimeSeconds;
		ServerData->PendingAdjustment.DeltaTime = DeltaTime;
		ServerData->PendingAdjustment.TimeStamp = ClientTimeStamp;
		ServerData->PendingAdjustment.bAckGoodMove = false;
		ServerData->PendingAdjustment.MovementMode = PackNetworkMovementMode();

#if USE_SERVER_PERF_COUNTERS
		PerfCountersIncrement(PerfCounter_NumServerMoveCorrections);
#endif
	}
	else
	{
		const AGameNetworkManager* GameNetworkManager = (const AGameNetworkManager*)(AGameNetworkManager::StaticClass()->GetDefaultObject());
		//if (GameNetworkManager->ClientAuthorativePosition)
		// [7/29/2019 mrhwang] P3 override, we don't want use client location while attached, since it's world location and has a lot of errors
		if (GameNetworkManager->ClientAuthorativePosition && !UpdatedComponent->GetAttachParent())
		{
			const FVector LocDiff = UpdatedComponent->GetComponentLocation() - ClientLoc; //-V595
			if (!LocDiff.IsZero() || ClientMovementMode != PackNetworkMovementMode() || GetMovementBase() != ClientMovementBase || (CharacterOwner && CharacterOwner->GetBasedMovement().BoneName != ClientBaseBoneName))
			{
				// Just set the position. On subsequent moves we will resolve initially overlapping conditions.
				UpdatedComponent->SetWorldLocation(ClientLoc, false); //-V595

				// Trust the client's movement mode.
				ApplyNetworkMovementMode(ClientMovementMode);

				// Update base and floor at new location.
				SetBase(ClientMovementBase, ClientBaseBoneName);
				UpdateFloorFromAdjustment();

				// Even if base has not changed, we need to recompute the relative offsets (since we've moved).
				SaveBaseLocation();

				LastUpdateLocation = UpdatedComponent ? UpdatedComponent->GetComponentLocation() : FVector::ZeroVector;
				LastUpdateRotation = UpdatedComponent ? UpdatedComponent->GetComponentQuat() : FQuat::Identity;
				LastUpdateVelocity = Velocity;
			}
		}

		// acknowledge receipt of this successful servermove()
		ServerData->PendingAdjustment.TimeStamp = ClientTimeStamp;
		ServerData->PendingAdjustment.bAckGoodMove = true;
	}

#if USE_SERVER_PERF_COUNTERS
	PerfCountersIncrement(PerfCounter_NumServerMoves);
#endif

	ServerData->bForceClientUpdate = false;
}

void UP3CharacterMovementComponent::ClientAckGoodMove(float TimeStamp)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	FP3NetAckGoodMove Packet;
	Packet.TimeStamp = TimeStamp;

	UP3World* P3World = P3Core::GetP3World(*this);
	const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
	ensure(ActorId != INVALID_ACTORID);

	const FP3NetConnInfo ConnId = P3World->GetServerWorld()->GetPlayerConnInfoFromActor(*GetOwner());

	P3World->Server_SendPacketToPlayerReliable(ConnId, this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Client_HandleAckGoodMove);
}

void UP3CharacterMovementComponent::ClientVeryShortAdjustPosition(float TimeStamp, FVector NewLoc, UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	FP3NetVeryShortAdjustPosition Packet;
	Packet.TimeStamp = TimeStamp;
	Packet.NewLoc = NewLoc;
	Packet.NewBase = CVarP3MovementSyncBase.GetValueOnGameThread() == 0 ? nullptr : NewBase;
	Packet.NewBaseBoneName = NewBaseBoneName;
	Packet.bHasBase = bHasBase;
	Packet.bBaseRelativePosition = bBaseRelativePosition;
	Packet.ServerMovementMode = ServerMovementMode;

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
		ensure(ActorId != INVALID_ACTORID);

		const FP3NetConnInfo NetConnInfo = P3World->GetServerWorld()->GetPlayerConnInfoFromActor(*GetOwner());

		P3World->Server_SendPacketToPlayerReliable(NetConnInfo, this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Client_HandleVeryShortAdjustPosition);
	}
}

void UP3CharacterMovementComponent::ClientAdjustPosition(float TimeStamp, FVector NewLoc, FVector NewVel, UPrimitiveComponent* NewBase, FName NewBaseBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode)
{
	if (P3Core::IsP3NetModeClientInstance(*this) && GetOwnerRole() == ROLE_AutonomousProxy)
	{
		// This function can be called from ClientVeryShortAdjustPosition_Implementation on autonomous client, odd. but true.
		Super::ClientAdjustPosition(TimeStamp, NewLoc, NewVel, NewBase, NewBaseBoneName, bHasBase, bBaseRelativePosition, ServerMovementMode);
		return;
	}

	ensure(P3Core::IsP3NetModeServerInstance(*this));

	FP3NetAdjustPosition Packet;
	Packet.TimeStamp = TimeStamp;
	Packet.NewLoc = NewLoc;
	Packet.NewVel = NewVel;
	Packet.NewBase = CVarP3MovementSyncBase.GetValueOnGameThread() == 0 ? nullptr : NewBase;
	Packet.NewBaseBoneName = NewBaseBoneName;
	Packet.bHasBase = bHasBase;
	Packet.bBaseRelativePosition = bBaseRelativePosition;
	Packet.ServerMovementMode = ServerMovementMode;

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
		ensure(ActorId != INVALID_ACTORID);

		const FP3NetConnInfo NetConnInfo = P3World->GetServerWorld()->GetPlayerConnInfoFromActor(*GetOwner());

		P3World->Server_SendPacketToPlayerReliable(NetConnInfo, this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Client_HandleAdjustPosition);
	}
}

void UP3CharacterMovementComponent::ClientAdjustRootMotionSourcePosition(float TimeStamp, FRootMotionSourceGroup ServerRootMotion, bool bHasAnimRootMotion, float ServerMontageTrackPosition, FVector ServerLoc, FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	FP3NetAdjustRootMotionSourcePosition Packet;
	Packet.TimeStamp = TimeStamp;
	Packet.ServerRootMotion = ServerRootMotion;
	Packet.bHasAnimRootMotion = bHasAnimRootMotion;
	Packet.ServerMontageTrackPosition = ServerMontageTrackPosition;
	Packet.ServerLoc = ServerLoc;
	Packet.ServerRotation = ServerRotation;
	Packet.ServerVelZ = ServerVelZ;
	Packet.ServerBase = CVarP3MovementSyncBase.GetValueOnGameThread() == 0 ? nullptr : ServerBase;
	Packet.ServerBoneName = ServerBoneName;
	Packet.bHasBase = bHasBase;
	Packet.bBaseRelativePosition = bBaseRelativePosition;
	Packet.ServerMovementMode = ServerMovementMode;

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
		ensure(ActorId != INVALID_ACTORID);

		const FP3NetConnInfo NetConnInfo = P3World->GetServerWorld()->GetPlayerConnInfoFromActor(*GetOwner());

		P3World->Server_SendPacketToPlayerReliable(NetConnInfo, this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Client_HandleAdjustRootMotionSourcePosition);
	}
}

void UP3CharacterMovementComponent::ClientAdjustRootMotionPosition(float TimeStamp, float ServerMontageTrackPosition, FVector ServerLoc, FVector_NetQuantizeNormal ServerRotation, float ServerVelZ, UPrimitiveComponent* ServerBase, FName ServerBoneName, bool bHasBase, bool bBaseRelativePosition, uint8 ServerMovementMode)
{
	ensure(P3Core::IsP3NetModeServerInstance(*this));

	FP3NetAdjustRootMotionPosition Packet;
	Packet.TimeStamp = TimeStamp;
	Packet.ServerMontageTrackPosition = ServerMontageTrackPosition;
	Packet.ServerLoc = ServerLoc;
	Packet.ServerRotation = ServerRotation;
	Packet.ServerVelZ = ServerVelZ;
	Packet.ServerBase = CVarP3MovementSyncBase.GetValueOnGameThread() == 0 ? nullptr : ServerBase;
	Packet.ServerBoneName = ServerBoneName;
	Packet.bHasBase = bHasBase;
	Packet.bBaseRelativePosition = bBaseRelativePosition;
	Packet.ServerMovementMode = ServerMovementMode;

	UP3World* P3World = P3Core::GetP3World(*this);
	if (P3World)
	{
		const actorid ActorId = P3World->GetActorIdFromActor(GetOwner());
		ensure(ActorId != INVALID_ACTORID);

		const FP3NetConnInfo NetConnInfo = P3World->GetServerWorld()->GetPlayerConnInfoFromActor(*GetOwner());

		P3World->Server_SendPacketToPlayerReliable(NetConnInfo, this, ActorId, GetOwner(), Packet, EP3NetComponentType::CharacterMovement, &UP3CharacterMovementComponent::Client_HandleAdjustRootMotionPosition);
	}
}

bool UP3CharacterMovementComponent::ServerCheckClientError(float ClientTimeStamp, float DeltaTime, const FVector& Accel, const FVector& ClientWorldLocation, const FVector& RelativeClientLocation, UPrimitiveComponent* ClientMovementBase, FName ClientBaseBoneName, uint8 ClientMovementMode)
{
	// Check location difference against global setting
	// Note you cannot check error during attached for now (since location is not relative)
	if (!bIgnoreClientMovementErrorChecksAndCorrection && !UpdatedComponent->GetAttachParent())
	{
		const FVector LocDiff = UpdatedComponent->GetComponentLocation() - ClientWorldLocation;

#if ROOT_MOTION_DEBUG
		if (RootMotionSourceDebug::CVarDebugRootMotionSources.GetValueOnAnyThread() == 1)
		{
			FString AdjustedDebugString = FString::Printf(TEXT("ServerCheckClientError LocDiff(%.1f) ExceedsAllowablePositionError(%d) TimeStamp(%f)"),
				LocDiff.Size(), GetDefault<AGameNetworkManager>()->ExceedsAllowablePositionError(LocDiff), ClientTimeStamp);
			RootMotionSourceDebug::PrintOnScreen(*CharacterOwner, AdjustedDebugString);
		}
#endif
		if (Server_OverrideAllowedPositionErrorSquared >= 0)
		{
			const float LocDiffSizeSquared = LocDiff.SizeSquared();
			if (LocDiffSizeSquared > Server_OverrideAllowedPositionErrorSquared)
			{
				bNetworkLargeClientCorrection = (LocDiffSizeSquared > FMath::Square(NetworkLargeClientCorrectionDistance));
				return true;
			}
		}
		else
		{
			if (GetDefault<AGameNetworkManager>()->ExceedsAllowablePositionError(LocDiff))
			{
				bNetworkLargeClientCorrection = (LocDiff.SizeSquared() > FMath::Square(NetworkLargeClientCorrectionDistance));
				return true;
			}
		}
#if !(UE_BUILD_SHIPPING || UE_BUILD_TEST)
		static IConsoleVariable* CVarNetForceClientAdjustmentPercent = IConsoleManager::Get().FindConsoleVariable(TEXT("p.NetForceClientAdjustmentPercent"));

		if (CVarNetForceClientAdjustmentPercent && CVarNetForceClientAdjustmentPercent->GetFloat() > SMALL_NUMBER)
		{
			if (FMath::SRand() < CVarNetForceClientAdjustmentPercent->GetFloat())
			{
				UE_LOG(LogNetPlayerMovement, VeryVerbose, TEXT("** ServerCheckClientError forced by p.NetForceClientAdjustmentPercent"));
				return true;
			}
		}
#endif
	}
	else
	{
#if !UE_BUILD_SHIPPING
		static IConsoleVariable* CVarNetShowCorrections = IConsoleManager::Get().FindConsoleVariable(TEXT("p.NetShowCorrections"));

		if (CVarNetShowCorrections && CVarNetShowCorrections->GetInt() != 0)
		{
			UE_LOG(LogNetPlayerMovement, Warning, TEXT("*** Server: %s is set to ignore error checks and corrections."), *GetNameSafe(CharacterOwner));
		}
#endif // !UE_BUILD_SHIPPING
	}

	// Check for disagreement in movement mode
	const uint8 CurrentPackedMovementMode = PackNetworkMovementMode();
	if (CurrentPackedMovementMode != ClientMovementMode)
	{
		return true;
	}

	return false;
}

void UP3CharacterMovementComponent::Server_HandleMoveOld(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetServerMoveOld Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ServerMoveOld_Implementation(Packet.OldTimeStamp, Packet.OldAccel, Packet.OldMoveFlags);
	}
}

void UP3CharacterMovementComponent::Server_HandleMove(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetServerMove Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ServerMove_Implementation(Packet.TimeStamp, Packet.InAccel, Packet.ClientLoc, Packet.CompressedMoveFlags, Packet.ClientRoll, Packet.View, Packet.ClientMovementBase, Packet.ClientBaseBoneName, Packet.ClientMovementMode);
	}
}

void UP3CharacterMovementComponent::Server_HandleMoveDual(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetServerMoveDual Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ServerMoveDual_Implementation(Packet.TimeStamp0, Packet.InAccel0, Packet.PendingFlags, Packet.View0, Packet.TimeStamp, Packet.InAccel, Packet.ClientLoc, Packet.NewFlags, Packet.ClientRoll, Packet.View, Packet.ClientMovementBase, Packet.ClientBaseBoneName, Packet.ClientMovementMode);
	}
}

void UP3CharacterMovementComponent::Server_HandleMoveDualHybridRootMotion(const FP3ClientToDediHandlerParams& Params)
{
	FP3NetServerMoveDual Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ServerMoveDualHybridRootMotion_Implementation(Packet.TimeStamp0, Packet.InAccel0, Packet.PendingFlags, Packet.View0, Packet.TimeStamp, Packet.InAccel, Packet.ClientLoc, Packet.NewFlags, Packet.ClientRoll, Packet.View, Packet.ClientMovementBase, Packet.ClientBaseBoneName, Packet.ClientMovementMode);
	}
}

void UP3CharacterMovementComponent::Client_HandleAckGoodMove(const FP3DediToClientHandlerParams& Params)
{
	FP3NetAckGoodMove Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ClientAckGoodMove_Implementation(Packet.TimeStamp);
	}
}

void UP3CharacterMovementComponent::Client_HandleVeryShortAdjustPosition(const FP3DediToClientHandlerParams& Params)
{
	FP3NetVeryShortAdjustPosition Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ClientVeryShortAdjustPosition_Implementation(Packet.TimeStamp, Packet.NewLoc, Packet.NewBase, Packet.NewBaseBoneName, Packet.bHasBase, Packet.bBaseRelativePosition, Packet.ServerMovementMode);
	}
}

void UP3CharacterMovementComponent::Client_HandleAdjustPosition(const FP3DediToClientHandlerParams& Params)
{
	FP3NetAdjustPosition Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ClientAdjustPosition_Implementation(Packet.TimeStamp, Packet.NewLoc, Packet.NewVel, Packet.NewBase, Packet.NewBaseBoneName, Packet.bHasBase, Packet.bBaseRelativePosition, Packet.ServerMovementMode);
	}
}

void UP3CharacterMovementComponent::Client_HandleAdjustRootMotionSourcePosition(const FP3DediToClientHandlerParams& Params)
{
	FP3NetAdjustRootMotionSourcePosition Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ClientAdjustRootMotionSourcePosition_Implementation(Packet.TimeStamp, Packet.ServerRootMotion, Packet.bHasAnimRootMotion, Packet.ServerMontageTrackPosition, Packet.ServerLoc, Packet.ServerRotation, Packet.ServerVelZ, Packet.ServerBase, Packet.ServerBoneName, Packet.bHasBase, Packet.bBaseRelativePosition, Packet.ServerMovementMode);
	}
}

void UP3CharacterMovementComponent::Client_HandleAdjustRootMotionPosition(const FP3DediToClientHandlerParams& Params)
{
	FP3NetAdjustRootMotionPosition Packet;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, Packet);

	if (ensure(bSerializeSucceeded))
	{
		ClientAdjustRootMotionPosition_Implementation(Packet.TimeStamp, Packet.ServerMontageTrackPosition, Packet.ServerLoc, Packet.ServerRotation, Packet.ServerVelZ, Packet.ServerBase, Packet.ServerBoneName, Packet.bHasBase, Packet.bBaseRelativePosition, Packet.ServerMovementMode);
	}
}

class FNetworkPredictionData_Client_Character* UP3CharacterMovementComponent::GetPredictionData_Client_Character() const
{
	// Should only be called on client or listen server (for remote clients) in network games
	checkSlow(CharacterOwner != NULL);
	//checkSlow(CharacterOwner->Role < ROLE_Authority || (CharacterOwner->GetRemoteRole() == ROLE_AutonomousProxy && GetNetMode() == NM_ListenServer));
	//checkSlow(GetNetMode() == NM_Client || GetNetMode() == NM_ListenServer);

	if (ClientPredictionData == nullptr)
	{
		UP3CharacterMovementComponent* MutableThis = const_cast<UP3CharacterMovementComponent*>(this);
		MutableThis->ClientPredictionData = static_cast<class FNetworkPredictionData_Client_Character*>(GetPredictionData_Client());
	}

	return ClientPredictionData;
}

void UP3CharacterMovementComponent::OnStartSprint()
{
	bSprintingPressed = true;
}

void UP3CharacterMovementComponent::OnStopSprint()
{
	bSprintingPressed = false;
}

static bool _CanClimbOnHit(USceneComponent* UpdatedComponent, EMovementMode MovementMode, const FVector& ActorFeetLocation, const FHitResult& Hit)
{
	if (MovementMode != MOVE_Walking && MovementMode != MOVE_Falling)
	{
		return false;
	}

	const FQuat ActorQuat = UpdatedComponent->GetComponentQuat();
	const FVector ActorLocation = ActorFeetLocation;
	const FVector ActorFoward = ActorQuat.GetForwardVector();
	const FVector ActorUp = ActorQuat.GetUpVector();
	const FVector ImpactPointDiff = Hit.ImpactPoint - ActorFeetLocation;

	//// See if it's too low
	//const float ImpactPointHeight = ImpactPointDiff | ActorUp;
	//float MinHeight = 10.0f;

	//UCapsuleComponent* CapsuleComp = Cast<UCapsuleComponent>(UpdatedComponent);
	//if (CapsuleComp)
	//{
	//	MinHeight = CapsuleComp->GetScaledCapsuleRadius() - KINDA_SMALL_NUMBER;
	//}

	//if (ImpactPointHeight < MinHeight)
	//{
	//	return false;
	//}
	
	// See if hit point is in front of me
	const FVector ImpactPointDiff2D = (ImpactPointDiff - (ActorUp * (ImpactPointDiff | ActorUp))).GetSafeNormal();
	bool bImpactOnFront = (ImpactPointDiff2D | ActorFoward) > KINDA_SMALL_NUMBER;
	if (!bImpactOnFront)
	{
		return false;
	}

	// See if hit surface is ground or ceil
	if (FMath::Abs(Hit.ImpactNormal | FVector(0, 0, 1)) > 0.8f)
	{
		return false;
	}

	return true;
}

void UP3CharacterMovementComponent::OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!UpdatedComponent)
	{
		return;
	}

#if ENABLE_DRAW_DEBUG
	if (CVarP3MovementDebug.GetValueOnGameThread() != 0)
	{
		DrawDebugPoint(GetWorld(), Hit.ImpactPoint, 10.0f, FColor::Red, false, 5.0f);
	}
#endif

	if (bCanClimb && !ClimbingStatus.bConsiderClimbing)
	{
		if (P3MovementMode == P3Movement_None)
		{
			const bool bCanClimbOnHit = _CanClimbOnHit(UpdatedComponent, MovementMode, GetActorFeetLocation(), Hit);

			if (bCanClimbOnHit && CharacterOwner)
			{
				bool bParkourActionRequested = false;

				if (CanTryParkour() && IsFalling() && IsLocalControlledActor(CharacterOwner))
				{
					bParkourActionRequested = _LocalControl_TryParkour(GetP3Character(), UpdatedComponent, MaxStepHeight);
				}
				
				if (!bParkourActionRequested)
				{
					ClimbingStatus.bConsiderClimbing = true;
				}
			}
		}
	}
}

void UP3CharacterMovementComponent::Client_ClearMovementData()
{
	FNetworkPredictionData_Client_Character* ClientData = GetPredictionData_Client_Character();
	if (ClientData)
	{
		ClientData->SavedMoves.Empty();
		ClientData->FreeMoves.Empty();
		ClientData->PendingMove = nullptr;
		ClientData->LastAckedMove = nullptr;
		ClientData->ClientUpdateTime = 0.f;
		ClientData->CurrentTimeStamp = 0.f;
	}
}

FP3NetworkPredictionData_Client_Character::FP3NetworkPredictionData_Client_Character(const UCharacterMovementComponent& ClientMovement)
	: FNetworkPredictionData_Client_Character(ClientMovement)
{

}

FSavedMovePtr FP3NetworkPredictionData_Client_Character::AllocateNewMove()
{
	return FSavedMovePtr(new FP3SavedMove_Character());
}

void FP3SavedMove_Character::Clear()
{
	FSavedMove_Character::Clear();

	bSprintPressed = false;
}

void FP3SavedMove_Character::SetMoveFor(ACharacter* C, float InDeltaTime, FVector const& NewAccel, class FNetworkPredictionData_Client_Character& ClientData)
{
	FSavedMove_Character::SetMoveFor(C, InDeltaTime, NewAccel, ClientData);

	AP3Character* Character = Cast<AP3Character>(C);

	if (Character)
	{
		bSprintPressed = Character->GetP3CharacterMovementBP()->GetSprintingPressed();
	}
}

bool FP3SavedMove_Character::CanCombineWith(const FSavedMovePtr& NewMove, ACharacter* InPawn, float MaxDelta) const
{
	if (CVarP3MovementCombine.GetValueOnGameThread() == 0)
	{
		return false;
	}

	AP3Character* P3Character = Cast<AP3Character>(InPawn);
	if (P3Character && P3Character->GetCharacterStoreBP().MountTargetCharacter)
	{
		// If mounted, combining makes character move around awkwardly on local screen
		return false;
	}

	if (P3Character && P3Character->GetActionComponent() && P3Character->GetActionComponent()->GetActiveActionType() != EPawnActionType::Invalid)
	{
		return false;
	}

	// We need this to avoid slowed animation on server side
	// Default behavior from FSavedMove_Character doesn't check this when there is no accel
	if (NewMove->DeltaTime + DeltaTime >= MaxDelta)
	{
		return false;
	}

	if (!FSavedMove_Character::CanCombineWith(NewMove, InPawn, MaxDelta))
	{
		return false;
	}

	FP3SavedMove_Character* NewP3Move = static_cast<FP3SavedMove_Character*>(NewMove.Get());

	if (NewP3Move->bSprintPressed != bSprintPressed)
	{
		return false;
	}

	return true;
}

uint8 FP3SavedMove_Character::GetCompressedFlags() const
{
	uint8 Flags = FSavedMove_Character::GetCompressedFlags();

	if (bSprintPressed)
	{
		Flags |= FLAG_SprintPressed;
	}

	return Flags;
}

void FP3SavedMove_Character::PostUpdate(ACharacter* Character, EPostUpdateMode PostUpdateMode)
{
	//FSavedMove_Character::PostUpdate(C, PostUpdateMode);

	// Common code for both recording and after a replay.
	{
		EndPackedMovementMode = Character->GetCharacterMovement()->PackNetworkMovementMode();
		MovementMode = EndPackedMovementMode; // Deprecated, keep backwards compat until removed
		SavedLocation = Character->GetActorLocation();
		SavedRotation = Character->GetActorRotation();
		SavedVelocity = Character->GetVelocity();
#if ENABLE_NAN_DIAGNOSTIC
		const float WarnVelocitySqr = 20000.f * 20000.f;
		if (SavedVelocity.SizeSquared() > WarnVelocitySqr)
		{
			if (Character->SavedRootMotion.HasActiveRootMotionSources())
			{
				UE_LOG(P3Log, Log, TEXT("FSavedMove_Character::PostUpdate detected very high Velocity! (%s), but with active root motion sources (could be intentional)"), *SavedVelocity.ToString());
			}
			else
			{
				UE_LOG(P3Log, Warning, TEXT("FSavedMove_Character::PostUpdate detected very high Velocity! (%s)"), *SavedVelocity.ToString());
			}
		}
#endif
		UPrimitiveComponent* const MovementBase = (CVarP3MovementSyncBase.GetValueOnGameThread() == 0) ? nullptr : Character->GetMovementBase();
		EndBase = MovementBase;
		EndBoneName = Character->GetBasedMovement().BoneName;
		if (MovementBaseUtility::UseRelativeLocation(MovementBase))
		{
			SavedRelativeLocation = Character->GetBasedMovement().Location;
		}

		SavedControlRotation = Character->GetControlRotation().Clamp();
	}

	// Only save RootMotion params when initially recording
	if (PostUpdateMode == PostUpdate_Record)
	{
		const FAnimMontageInstance* RootMotionMontageInstance = Character->GetRootMotionAnimMontageInstance();
		if (RootMotionMontageInstance && !RootMotionMontageInstance->IsRootMotionDisabled())
		{
			RootMotionMontage = RootMotionMontageInstance->Montage;
			RootMotionTrackPosition = RootMotionMontageInstance->GetPosition();
			RootMotionMovement = Character->ClientRootMotionParams;
		}

		// Save off Root Motion Sources
		if( Character->SavedRootMotion.HasActiveRootMotionSources() )
		{
			SavedRootMotion = Character->SavedRootMotion;
		}

		// Don't want to combine moves that trigger overlaps, because by moving back and replaying the move we could retrigger overlaps.
		EndActorOverlapCounter = Character->NumActorOverlapEventsCounter;
		EndComponentOverlapCounter = UPrimitiveComponent::GlobalOverlapEventsCounter;
		if ((StartActorOverlapCounter != EndActorOverlapCounter) || (StartComponentOverlapCounter != EndComponentOverlapCounter))
		{
			bForceNoCombine = true;
		}
	}
	else if (PostUpdateMode == PostUpdate_Replay)	// -V547
	{
		if( Character->bClientResimulateRootMotionSources )
		{
			// When replaying moves, the next move should use the results of this move
			// so that future replayed moves account for the server correction
			Character->SavedRootMotion = Character->GetCharacterMovement()->CurrentRootMotion;
		}
	}
}
