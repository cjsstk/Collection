// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3AnimNotifyGenerator.h"
#include "P3Log.h"

void FP3AnimNotifyGenerator::Start(const UAnimMontage* InAnimMontage, float Now, float InPlayRate)
{
	AnimMontage = InAnimMontage;
	StartTimeSeconds = Now;
	AgeSeconds = 0.0f;
	LastCheckTime = Now;
	PlayRate = InPlayRate;
}

TArray<FAnimNotifyEventReference> FP3AnimNotifyGenerator::TickAndNotifies(float DeltaSeconds)
{
	TArray<FAnimNotifyEventReference> AnimNotifyEventReferences;

	if (!AnimMontage.IsValid())
	{
		return AnimNotifyEventReferences;
	}

	AgeSeconds += DeltaSeconds;

	const float Now = StartTimeSeconds + AgeSeconds;

	float CheckBeginTime = (LastCheckTime - StartTimeSeconds) * AnimMontage->RateScale * PlayRate;
	float CheckEndTime = (Now - StartTimeSeconds) * AnimMontage->RateScale * PlayRate;
	float CheckDeltaTime = CheckEndTime - CheckBeginTime;

	if (CheckBeginTime > AnimMontage->SequenceLength)
	{
		AgeSeconds = 0.f;
		LastCheckTime = StartTimeSeconds;
		return AnimNotifyEventReferences;
	}

	AnimMontage->GetAnimNotifies(CheckBeginTime, CheckDeltaTime, false, AnimNotifyEventReferences);

	//if (AnimNotifyEventReferences.Num() > 0)
	//{
	//	UE_LOG(P3Log, Display, TEXT("Length %f Begin %f End %f Delta %f Count %d"),
	//		AnimMontage->SequenceLength * AnimMontage->RateScale, CheckBeginTime, CheckEndTime, CheckDeltaTime,
	//		AnimNotifyEventReferences.Num());
	//}

	LastCheckTime = Now;

	return AnimNotifyEventReferences;
}

