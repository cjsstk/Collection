// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3PainCausingComponent.h"

#include "Engine/World.h"
#include "GameFramework/Actor.h"
#include "GameplayTagAssetInterface.h"
#include "TimerManager.h"

#include "Action/P3PawnAction.h"
#include "Action/P3PawnActionComponent.h"
#include "Command/P3Command.h"
#include "Command/P3CommandComponent.h"
#include "P3Character.h"
#include "P3HealthPointComponent.h"
#include "P3Log.h"

TAutoConsoleVariable<float> CVarP3PainCausingMinOverlapTickSeconds(
	TEXT("p3.pPainCausingMinOverlapTickSeconds"),
	0.5f,
	TEXT(""), ECVF_Cheat);


UP3PainCausingComponent::UP3PainCausingComponent()
{
	PrimaryComponentTick.bCanEverTick = false;

	bAutoActivate = true;
}


void UP3PainCausingComponent::BeginPlay()
{
	Super::BeginPlay();

	if (P3Core::IsP3NetModeServerInstance(*this))
	{
		if (HitDamageAmount > 0)
		{
			GetOwner()->OnActorHit.AddUniqueDynamic(this, &UP3PainCausingComponent::Server_OnHit);
		}

		if (OverlapDamageAmount > 0)
		{
			OverlapDamageTickSeconds = FMath::Max(OverlapDamageTickSeconds, CVarP3PainCausingMinOverlapTickSeconds.GetValueOnGameThread());

			GetWorld()->GetTimerManager().SetTimer(Server_OverlapTimerHandle, this, &UP3PainCausingComponent::Server_OnOverlapTimer, OverlapDamageTickSeconds);
		}
	}
}

void UP3PainCausingComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	if (P3Core::IsP3NetModeServerInstance(*this) && GetOwner())
	{
		GetOwner()->OnActorHit.RemoveAll(this);
	}
}

void UP3PainCausingComponent::Server_OverlappedActorAdded(AActor& Actor)
{
	Super::Server_OverlappedActorAdded(Actor);

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!IsActive())
	{
		return;
	}

	Server_DamageActor(&Actor, true);

	if (OverlapDamageAmount)
	{
		GetWorld()->GetTimerManager().SetTimer(Server_OverlapTimerHandle, this, &UP3PainCausingComponent::Server_OnOverlapTimer, OverlapDamageTickSeconds);
	}
}

void UP3PainCausingComponent::Server_OnHit(AActor* SelfActor, AActor* OtherActor, FVector NormalImpulse, const FHitResult& Hit)
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!IsActive())
	{
		return;
	}

	Server_DamageActor(OtherActor);
}

void UP3PainCausingComponent::Server_OnOverlapTimer()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	//ensure(OverlapDamageAmount > 0);
	ensure(OverlapDamageTickSeconds > 0);

	const bool bDamageApplied = Server_DamageOveralppedActors();

	if (bDamageApplied)
	{
		GetWorld()->GetTimerManager().SetTimer(Server_OverlapTimerHandle, this, &UP3PainCausingComponent::Server_OnOverlapTimer, OverlapDamageTickSeconds);
	}
}

bool UP3PainCausingComponent::Server_DamageOveralppedActors()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return false;
	}

	if (!IsActive())
	{
		return false;
	}

	//ensure(OverlapDamageAmount > 0);
	
	AActor* OwnerActor = GetOwner();

	if (!ensure(OwnerActor))
	{
		return false;
	}

	TSet<AActor*> OverlappingActors = Server_GetOverlappedActors();

	bool bDamageApplied = false;

	for (AActor* Actor : OverlappingActors)
	{
		bDamageApplied |= Server_DamageActor(Actor);
	}

	return bDamageApplied;
}

bool UP3PainCausingComponent::Server_DamageActor(AActor* Actor, bool bIsBeginOverlap)
{
	if (!IsActive())
	{
		return false;
	}

	if (!Actor || !GetOwner())
	{
		return false;
	}

	if (bIgnoreInstigator && GetOwner()->Instigator == Actor)
	{
		return false;
	}

	if (bIsBeginOverlap && BeginOverlapDamageAmount < 0)
	{
		return false;
	}

	if (IgnoreGameplayTagsAny.Num() > 0)
	{
		IGameplayTagAssetInterface* GameplayTagAsset = Cast<IGameplayTagAssetInterface>(Actor);
		if (GameplayTagAsset)
		{
			const bool bTagFound = GameplayTagAsset->HasAnyMatchingGameplayTags(IgnoreGameplayTagsAny);
			if (bTagFound)
			{
				return false;
			}
		}
	}

	if (bGiveDamageOnlyOnce && DamagedActors.Contains(Actor) && OverlapDamageAmount <= 0)
	{
		return false;
	}

	const int32 DamageAmount = bIsBeginOverlap ? BeginOverlapDamageAmount : OverlapDamageAmount;

	// Play hit action except large character
	// TODO: maybe need better approach without including character header
	AP3Character* Character = Cast<AP3Character>(Actor);
	AActor* Instigator = GetOwner()->Instigator ? GetOwner()->Instigator : GetOwner();

	if (Character)
	{
		if (Character->IsDead())
		{
			return false;
		}

		P3Combat::FDamageActorParams DamageParams(*Instigator, *Character);
		DamageParams.AttackStrength = AttackStrength;
		DamageParams.AttackDirection = EAnimNotifyAttackDirectionFlags::Push;
		DamageParams.AttackAttribute = EP3AnimNotifyAttackAttribute::Bash;
		DamageParams.WeaponType = EP3WeaponType::None;
		DamageParams.TrueDamage = DamageAmount;
		DamageParams.ImpactDirection = (Character->GetActorLocation() - Instigator->GetActorLocation()).GetSafeNormal();
		DamageParams.Reason = EP3HealthChangeReason::PainCausing;

		P3Combat::Server_DamageActor(DamageParams);
	}
	else
	{
		P3Combat::ChangeActorHealth(Instigator, *Actor, -DamageAmount, EP3HealthChangeReason::PainCausing);
	}

	DamagedActors.Add(Actor);

	return true;
}
