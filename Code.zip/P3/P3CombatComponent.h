// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "NavFilters/NavigationQueryFilter.h"

#include "P3Actor.h"
#include "P3CharacterStore.h"
#include "P3Cms.h"
#include "P3Core.h"
#include "P3WeaponType.h"
#include "P3CombatComponent.generated.h"

/** 
 * Server Main Target
 * sub module to guess character's main target on server side
 * this is especially helpful to AI to react naturally during combat (since we know which AI is main target)
 */
struct FServerMainTarget
{
	class AP3Character* GetMainTargetCharacter() const { return MainTarget.Get(); }

	void OnTick(AP3Character& MyCharacter, float DeltaSeconds);
	void OnAttack(AP3Character* AttackTarget);

private:
	void RemoveInvalidCandidates();
	void TickWatch(AP3Character& MyCharacter, float DeltaSeconds);
	void TickWatchPoint(AP3Character* WatchingCharacter, float Point, float DeltaSeconds);
	void TickChangeMainTarget();

	struct FCandidate
	{
		float AttackPoint = 0;
		float WatchPoint = 0;

		float LastWatchPoint = 0;

		TWeakObjectPtr<AP3Character> Character;
	};

	TWeakObjectPtr<AP3Character> MainTarget;
	TArray<FCandidate> Candidates;
};

USTRUCT(Blueprintable)
struct FP3CombatSkill
{
	GENERATED_BODY()

public:
	/**
	 * Static game data
	 */
	const FP3CmsCombatSkill* CmsCombatSkill = nullptr;

	/**
	 * Runtime state (TODO: Move to it's own struct?)
	 */
	float Server_NextCooldownFinishTimeSeconds = 0;
};

USTRUCT(Blueprintable)
struct FP3CombatCharging
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, Category = P3)
	UAnimMontage* AnimMontage;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName StopAnimMontageName;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName HitAnimMontageName;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	float MaxDistance = 2000;

	/** Move speed (Units per second) */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float MoveSpeed = 1000;

	/** If actor past the target, the actor stop in this seconds */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float ChargingBrakeTime = 1.0f;

	/** If target is farther than this distance, actor rotate to target */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float ChargingChaseMinDistance = 1800.f;

	/** Chasing turn ratio */
	UPROPERTY(EditDefaultsOnly, Category = P3, meta=(UIMin = "0", UIMax = "1"))
	float ChaseTurningRatio = 0.2f;

	/** Need speed for stuck */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float NeedSpeedForStuck = 2000.0f;

	/** Need speed for hit character */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float NeedSpeedForHitCharacter = 800.0f;

	/** Charging damage permil. 1000.0f is 100% */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	float ChargingDamagePermil = 1000.0f;
};

/** 
 * Combat setup for each weapon types
 */
USTRUCT(Blueprintable)
struct FP3CombatWeapon
{
public:
	GENERATED_BODY()

	/** Attack */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	UAnimMontage* NormalAttackAnim;

	/** (Optional) Move forward + Attack */
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	UAnimMontage* ForwardAttackAnim;
};

USTRUCT(Blueprintable)
struct FP3DisabledBoneData
{
public:
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, Category = P3)
	TWeakObjectPtr<UP3PartComponent> RequestPartComponent;

	UPROPERTY(EditDefaultsOnly, Category = P3)
	FName DisabledBoneName;

};

UCLASS(BlueprintType)
class P3_API UP3TurningAttackAnimationData : public UDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, Category = P3)
	TArray<UAnimMontage*> TurningAttackAnimations;
};

USTRUCT()
struct FP3UnreachableActor
{
	GENERATED_BODY()

	UPROPERTY()
	AActor* Actor;

	UPROPERTY()
	int32 AttackCount = 0;
};

UENUM()
namespace EP3PathExistanceQueryType
{
	enum Type
	{
		NavmeshRaycast2D UMETA(ToolTip = "Really Fast"),
		HierarchicalQuery UMETA(ToolTip = "Fast"),
		RegularPathFinding UMETA(ToolTip = "Slow"),
	};
}

/** 
 * Combat Component
 */
UCLASS(Blueprintable, meta=(BlueprintSpawnableComponent) )
class P3_API UP3CombatComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UP3CombatComponent();

	virtual void OnRegister() override;
	virtual void OnUnregister() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION(BlueprintCallable)
	bool IsCrossHairModeBP() const { return IsCrossHairMode(); }
	bool IsCrossHairMode() const;
	bool LocalControl_IsMeleeCrossHairMode() const;
	void LocalControl_SetAssistAim(bool bAssist);

	UFUNCTION(BlueprintCallable)
	bool IsAttacking() const;

	bool CanCombat() const;

	void PutAwayWeapon();

	bool IsActorInAttackRange(const AActor* TargetActor, int32 SkillIndex, float RangeAddition) const;

	bool IsIgnoreUnreachableActorAttack(AActor* DamageSourceActor) const;
	void Server_UpdateUnreachableActorList(AActor* DamageSourceActor);
	bool Server_DoesPathExistToDamageSourceActor(AActor* DamageSourceActor) const;

	class AP3Character* Server_GetMainTarget() const { return Server_MainTarget.GetMainTargetCharacter(); }

	const TArray<FP3CombatSkill>& GetSkills() const;
	const FP3CombatSkill* GetSkill(int32 Index) const;
	const FP3CmsCombatSkill* GetCmsCombatSkill(int32 Index) const;

	bool Server_CanUseSkill(int32 SkillIndex) const;

	const TArray<FP3CombatCharging>& GetChargings() const { return Chargings; }
	const TMap<EP3WeaponType, FP3CombatWeapon>& GetWeapons() const { return Weapons; }	
	const TArray<UP3TurningAttackAnimationData*>& GetTurningAttackAnimations() const { return TurningAttackAnimations; }

	void Server_SetLastDamageSource(AP3Character* SourceCharacter);
	class AP3Character* Server_GetLastDamageSource() const;

	UFUNCTION(BlueprintCallable)
	class AP3Character* LocalControl_GetMainTargetBP() const { return LocalControl_GetMainTarget(); }
	class AP3Character* LocalControl_GetMainTarget() const { return LocalControl_MainTarget.Get(); }

	UFUNCTION(BlueprintCallable)
	class AP3Character* LocalControl_GetCrossHairTargetBP() const { return LocalControl_GetCrossHairTarget(); }
	class AP3Character* LocalControl_GetCrossHairTarget() const { return LocalControl_CrossHairTarget.Get(); }

	UFUNCTION(BlueprintCallable)
	FRotator LocalControl_GetAimRotationBP() const { return LocalControl_AimRotation; }

	/** Skill notify */
	void Server_OnSkillStarted(int32 SkillIndex);

	/** Hit anim notify */
	void Server_OnHitNotify(const struct FP3CmsCombatHit& CombatHitDesc, const FVector& LocalImpactDirection, int32 SkillIndex, const AActor* TargetActor, const FName& CmsCombatHitKey, int32 ActionId, const UAnimSequenceBase* AnimSequence, const FName& SocketName);

	/** Attack move anim notify */
	void OnAttackMoveAnimNotifyBegin();
	void OnAttackMoveAnimNotifyEnd();

	/** Attack with skeletal mesh physics anim notify */
	void OnAttackWithSkeletalMeshPhysicsBegin(const TArray<FName>& BoneNames, class UAnimNotifyState_BoneAttack* Notify, class UAnimSequenceBase* Animation);
	void OnAttackWithSkeletalMeshPhysicsEnd(const TArray<FName>& BoneNames, class UAnimNotifyState_BoneAttack* Notify, class UAnimSequenceBase* Animation);
	
	/** Show projectile */
	void Client_ShowProjectile(const TSubclassOf<class AP3Projectile>& ProjectileClass, const FName& AttachBoneName, bool bIsEnabled);

	UFUNCTION(BlueprintCallable)
	int32 GetCancelChargingBraceLevel() const;

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:
	FP3CombatSkill* GetSkill(int32 Index);

	UFUNCTION()
	void SlowTick();

	void Server_Tick(float DeltaSeconds, AP3Character* Character);
	void Server_TickBoneAttack(float DeltaSeconds, AP3Character* Character);

	/** Return true if actor is already thrown by bone attack by same anim sequence */
	bool Server_IsAlreadyThrownByBoneAttack(const AP3Character& Character, const UAnimSequenceBase* AnimSequence) const;

	void LocalControl_TickAutoDrawWeapon();
	void LocalControl_TickAutoPutAwayWeapon();
	void LocalControl_TickAutoAttack();
	void LocalControl_TickAutoAttackSword();
	void LocalControl_TickAutoAttackGun();
	void LocalControl_TickFindTargetUnderCrossHair();
	void LocalControl_TickConsiderFindTarget();
	void LocalControl_TickMoveTowardsTarget();
	void LocalControl_TickAssistAim(float DeltaSeconds);
	bool LocalControl_LineTraceCrossHair(bool& bOutHit, FHitResult& OutHitResult, FVector* OutTraceStart, FVector* OutTraceEnd) const;
	bool LocalControl_UpdateCrossHairTargetAndAimRotation();
	void LocalControl_SearchMainTarget();
	void LocalControl_DrawWeapon();
	void LocalControl_SearchLockOnTarget();
	void LocalControl_TickCameraRotationLockOnTarget(float DeltaSeconds);
	void LocalControl_TickReleaseLockOnTarget();
	void LocalControl_Player_TickSwing(AP3Character* Character, float DeltaSeconds);

	/** Start attack input */
	UFUNCTION()
	void OnStartAttackInput();

	/** Stop attack input */
	UFUNCTION()
	void OnStopAttackInput();

	/** On character store changed */
	UFUNCTION()
	void OnCharacterStoreChanged(const FP3CharacterStore& OldStore, const FP3CharacterStore& NewStore);

	/** Input for target selection in the camera direction */
	UFUNCTION()
	void OnLockOnPressed();

	UFUNCTION()
	void OnLockOnReleased();

	UFUNCTION()
	void OnNextLockOn();

	UFUNCTION()
	void OnPrevLockOn();

	UFUNCTION()
	void OnLookAssist();

	UFUNCTION()
	void OnInputMoveLook(float Rate);

	UFUNCTION()
	void OnPartBroken(class UP3PartComponent* PartComp);

	void Server_TimeoutHitLogs();

protected:

	/** Distance to search hostile character and do auto draw weapon */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float AutoDrawWeaponHostileSearchRange = 1000;

	/** Angles to search hostile character and do auto draw weapon */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float AutoDrawWeaponHostileSearchAngleDegree = 360;

	/** Attack range */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float AttackRange;

	/** Attack angle in degree */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float AttackAngleDegree;

	/** Attack distance in z axis */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float AttackDistanceZ;

	/** Max distance to search main target */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float MainTargetSearchRange;

	/** Angle to search main target */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float MainTargetSearchAngleDegree;

	/** Chargings */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	TArray<FP3CombatCharging> Chargings;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	int32 CancelChargingBraceLevel = 1;

	/** Weapons */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	TMap<EP3WeaponType, FP3CombatWeapon> Weapons;
	
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	TArray<UP3TurningAttackAnimationData*> TurningAttackAnimations;
	
	/** Distance to search for a LockOnTarget */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	float SearchLockOnTargetDistance = 2500.f;

	/** Query type of path to damage source actor */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = P3)
	TEnumAsByte<EP3PathExistanceQueryType::Type> PathQueryTypeToDamageSource = EP3PathExistanceQueryType::HierarchicalQuery;

	/** "None" will result in default filter being used */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = P3)
	TSubclassOf<UNavigationQueryFilter> NaviQueryFilterClassToDamageSource;
	
	/** Show Projectile */
	UPROPERTY(EditDefaultsOnly, Category = P3)
	TMap<TSubclassOf<AP3Projectile>, UStaticMesh*> ShowProjectiles;

	UPROPERTY(Transient)
	UStaticMeshComponent* ShowProjectileComponent = nullptr;

private:
	/** Skill data from CMS */
	TArray<FP3CombatSkill> Skills;

	/** Player turned on cross hair mode for melee? */
	bool LocalControl_bMeleeCrossHairMode = false;

	/** Player is still pressing attack button? */
	bool LocalControl_bIsAttacking = false;

	/** Player want assist aim? */
	bool LocalControl_bAssistAim = false;

	/** Currently locked on target */
	TWeakObjectPtr<class AP3Character> LocalControl_MainTarget;

	/** Aim rotation to cross hair */
	FRotator LocalControl_AimRotation;

	/** Target under cross hair */
	TWeakObjectPtr<class AP3Character> LocalControl_CrossHairTarget;

	/** Target under cross hair */
	FP3Silhouetter LocalControl_CrossHairTargetSilhouetter;

	/** We use this time to trigger auto-put-away weapon */
	float LocalControl_AutoPutAwayWeaponTimeSeconds = 0;

	/** Last put away weapon time */
	float LocalControl_LastPutawayWeaponTimeSeconds = 0;

	/** We only move during attack move anim notify state */
	bool LocalControl_bAnimNotifyAttackMove = false;
	
	/** Server main target */
	FServerMainTarget Server_MainTarget;

	/** Slow tick timer handle */
	FTimerHandle SlowTickTimerHandle;

	/** Target list of camera direction */
	TArray<TWeakObjectPtr<class AP3Character>> LocalControl_LockOnTargets;
		
	/** Target selected in the target list*/
	int32 LocalControl_SelectedLookOnTargetIndex = -1;

	/** Silhouette of target selected in camera direction */
	FP3Silhouetter LocalControl_LockOnTargetSilhouetter;

	/** The value the camera should rotate. */
	FRotator LockOnTargetDestRotation = FRotator::ZeroRotator;

	/** Pressing the lock on button? */
	bool bLockOnButtonPressed = false;

	UPROPERTY(Transient)
	AP3Character* Server_LastDamageSource = nullptr;

	/** 
	 * Swing checker
	 */
	bool bSwing = false;
	FTransform LastWeaponTransform = FTransform::Identity;

	/** 
	 * Bone Attack
	 */
	struct FAttackBone
	{
		bool bTransformInitialized = false;
		FTransform Transform = FTransform::Identity;
	};

	struct FBoneAttackAnimNotify
	{
		TWeakObjectPtr<const class UAnimNotifyState_BoneAttack> Notify;
		TWeakObjectPtr<const class UAnimSequenceBase> Animation;
		TMap<FName, FAttackBone> Bones;

		TArray<TWeakObjectPtr<AP3Character>> ThrownCharacters;
	};

	TArray<FBoneAttackAnimNotify> BoneAttackAnimNotifies;

	int32 Server_DisableBoneRequestID = 0;

	TArray<FP3DisabledBoneData> Server_DisabledBoneNameOnBoneAttack;

	TArray<FP3UnreachableActor> UnreachableActorList;

	bool bUseHitLog = false;

	/** 
	 * Hit target history
	 * We need this to avoid 'feels like unfair' sudden double hit
	 */
	int32 Server_HitLogActionId = 0;

	/** [actor, last hit time seconds] */
	UPROPERTY(Transient)
	TMap<AActor*, float> Server_HitLogActors;
};

USTRUCT()
struct FP3DamageEvent : public FDamageEvent
{
	GENERATED_USTRUCT_BODY()

	FP3DamageEvent() {}

	/** ID for this class. NOTE this must be unique for all damage events. */
	static const int32 ClassID = 3;
	
	virtual int32 GetTypeID() const override { return FP3DamageEvent::ClassID; };
	virtual bool IsOfType(int32 InID) const override { return (FP3DamageEvent::ClassID == InID) || FDamageEvent::IsOfType(InID); };

	/** Simple API for common cases where we are happy to assume a single hit is expected, even though damage event may have multiple hits. */
	//virtual void GetBestHitInfo(AActor const* HitActor, AActor const* HitInstigator, struct FHitResult& OutHitInfo, FVector& OutImpulseDir) const override;
};
