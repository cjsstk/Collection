// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3NpcStressTestPlayerController.h"
#include "P3Log.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "Components/SkeletalMeshComponent.h"

void AP3NpcStressTestPlayerController::BeginPlay()
{
	Super::BeginPlay();

	ConsoleCommandSpawnNpcs = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("p3.spawnNpcs"),
		TEXT("Run console command in server"),
		FConsoleCommandWithArgsDelegate::CreateUObject(this, &AP3NpcStressTestPlayerController::OnConsoleCommandSpawnNpcs),
		ECVF_Cheat
	);
}

void AP3NpcStressTestPlayerController::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	IConsoleManager::Get().UnregisterConsoleObject(ConsoleCommandSpawnNpcs);
}

void AP3NpcStressTestPlayerController::OnConsoleCommandSpawnNpcs(const TArray<FString>& Args)
{
	ServerSpawnNpcs(Args);
}

bool AP3NpcStressTestPlayerController::ServerSpawnNpcs_Validate(const TArray<FString>& Args)
{
	return true;
}

void AP3NpcStressTestPlayerController::ServerSpawnNpcs_Implementation(const TArray<FString>& Args)
{
	const int32 NumNpcs = FCString::Atoi(*Args[0]);

	if (NumNpcs < 0)
	{
		return;
	}

	// Remove previous Npcs

	for (AActor* Npc : SpawnedNpcs)
	{
		Npc->Destroy();
	}

	TargetNpcNum = NumNpcs;
	LastSpawnTimeSeconds = GetWorld()->GetTimeSeconds();
}

void AP3NpcStressTestPlayerController::ClientSpawnStatus_Implementation(int32 Current, int32 Total)
{
	FString Message = FString::Printf(TEXT("Spawn %d/%d"), Current, Total);
	GEngine->AddOnScreenDebugMessage(0, 3.0f, FColor::Green, Message);
}

void AP3NpcStressTestPlayerController::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (CurrnetNpcNum >= TargetNpcNum)
	{
		return;
	}

	const float ElapsedTimeSeconds = GetWorld()->GetTimeSeconds() - LastSpawnTimeSeconds;
	const int32 NumSpawn = ElapsedTimeSeconds * SpawnPerSeconds;

	if (NumSpawn <= 0)
	{
		return;
	}

	FActorSpawnParameters ActorSpawnParams;
	ActorSpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	const int32 NumColumn = FMath::CeilToInt(FMath::Sqrt(TargetNpcNum));
	FVector NpcSpawnLocation = FVector::ZeroVector;
	const FRotator NpcSpawnRotator = FRotator::ZeroRotator;

	for (int32 Index = 0; Index < NumSpawn; ++Index)
	{
		NpcSpawnLocation.X = StaticCast<float>((CurrnetNpcNum % NumColumn) * NpcDistance);
		NpcSpawnLocation.Y = StaticCast<float>((CurrnetNpcNum / NumColumn) * NpcDistance);

		AActor* SpawnedNpc = GetWorld()->SpawnActor<AActor>(SpawnActorClass, NpcSpawnLocation, NpcSpawnRotator, ActorSpawnParams);

		if (!ensure(SpawnedNpc))
		{
			continue;
		}

		SpawnedNpcs.Add(SpawnedNpc);
		++CurrnetNpcNum;
	}

	ClientSpawnStatus(CurrnetNpcNum, TargetNpcNum);

	LastSpawnTimeSeconds = GetWorld()->GetTimeSeconds();
}
