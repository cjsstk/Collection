// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3CharacterItemSlots.generated.h"

UENUM(BlueprintType)
enum class EP3CharacterItemSlot : uint8
{
	Invalid = 0,
	Inventory = 1,
	RightHand = 2,
	LeftHand = 3,
	Backpack = 4,
};
