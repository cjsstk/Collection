// Copyright 2018 XLGames, Inc. All Rights Reserved.

#include "P3HealthPointComponent.h"

#include "Net/UnrealNetwork.h"

#include "P3Core.h"
#include "P3Character.h"
#include "P3World.h"
#include "P3WorldNetCore.h"

TAutoConsoleVariable<int32> CVarP3HealthDebug(
    TEXT("p3.healthDebug"),
    0,
    TEXT("1: enable debug. 0: disable dibug"), ECVF_Cheat);

UP3HealthPointComponent::UP3HealthPointComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;

	MaxHealthPoint = 100;
	HealthPoint = 100;
	DeadTimeSeconds = 0;
	ReviveTimeSeconds = 0;
}

void UP3HealthPointComponent::BeginPlay()
{
	Super::BeginPlay();

	HealthPoint = MaxHealthPoint;

#if !UE_BUILD_SHIPPING
	if (P3Core::IsP3NetModeClientInstance(*this))
	{
		// TODO: This is only needed for CVarP3HealthDebug
		SetComponentTickEnabled(true);
	}
#endif
}

void UP3HealthPointComponent::OnRegister()
{
	Super::OnRegister();

	if (GetOwner())
	{
		GetOwner()->OnTakeAnyDamage.AddUniqueDynamic(this, &UP3HealthPointComponent::OnTakeAnyDamage);
	}
}

void UP3HealthPointComponent::OnUnregister()
{
	Super::OnUnregister();

	if (GetOwner())
	{
		GetOwner()->OnTakeAnyDamage.RemoveDynamic(this, &UP3HealthPointComponent::OnTakeAnyDamage);
	}
}

void UP3HealthPointComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	DECLARE_SCOPE_CYCLE_COUNTER(TEXT("P3HealthPoint_Tick"), STAT_P3HealthPoint_Tick, STATGROUP_P3);

	if (CVarP3HealthDebug.GetValueOnGameThread())
	{
		IP3ActorInterface* P3ActorInterface = Cast<IP3ActorInterface>(GetOwner());
		if (P3ActorInterface)
		{
			P3ActorInterface->AddDebugString(FString::Printf(TEXT("HP(%d/%d)"), HealthPoint, MaxHealthPoint));
		}
	}
}

void UP3HealthPointComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UP3HealthPointComponent, HealthPoint);
}

void UP3HealthPointComponent::OnTakeAnyDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType, class AController* InstigatedBy, AActor* DamageCauser)
{
	//SetHealthPoint(GetHealthPoint() - Damage);
}

void UP3HealthPointComponent::SetMaxHealthPoint(int32 InMaxHealthPoint)
{
	if (ensure(InMaxHealthPoint > 0))
	{
		MaxHealthPoint = InMaxHealthPoint;
		if (MaxHealthPoint < HealthPoint)
		{
			HealthPoint = MaxHealthPoint;
		}
	}

	OnMaxHealthPointChanged();

	if (GetOwner() && GetOwner()->HasActorBegunPlay() && P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_SetDirty(*this);
	}
}

void UP3HealthPointComponent::SetHealthPoint(int32 InHealthPoint)
{
	SetHealthPointInternal(InHealthPoint, false, false);
}

void UP3HealthPointComponent::SetHealthPointInternal(int32 InHealthPoint, bool bIsRevive, bool bIsSync)
{
	if (!bIsSync && !bIsRevive && HealthPoint == 0 && InHealthPoint > 0)
	{
		ensureMsgf(false, TEXT("Use Revive first"));
		return;
	}

	// TODO: Make dedicated method for damage and move this code
	if (HealthPoint > InHealthPoint)
	{
		AP3Character* Character = Cast<AP3Character>(GetOwner());
		if (Character && Character->GetCharacterStoreBP().bGodMode)
		{
			return;
		}
	}

	const bool bWasDead = IsDead();

	int32 PrevHealthPoint = HealthPoint;
	HealthPoint = FMath::Clamp(InHealthPoint, 0, MaxHealthPoint);

	OnChange.Broadcast(this, PrevHealthPoint, HealthPoint);

	OnHealthPointChanged(PrevHealthPoint, HealthPoint);

	if (IsDead() && !bWasDead && P3Core::IsP3NetModeServerInstance(*this))
	{
		Server_OnDead();
	}

	if (GetOwner() && P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_SetDirty(*this);
	}
}

void UP3HealthPointComponent::Server_OnDead()
{
	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	if (!Server_IsServerOnly())
	{
		UP3World* World = P3Core::GetP3World(*this);
		if (World)
		{
			const actorid ActorId = World->GetActorIdFromActor(GetOwner());

			World->Server_MulticastPacketReliable(this, ActorId, GetOwner(), FP3NetDummy(), EP3NetComponentType::Health, &UP3HealthPointComponent::Client_HandleDead);
		}
	}

	Server_OnDeadInternal();
	MulticastCharacterDead();
}

void UP3HealthPointComponent::Server_Revive(int32 InHealthPoint)
{
	if (!ensure(HealthPoint == 0 && InHealthPoint > 0))
	{
		return;
	}

	if (!ensure(P3Core::IsP3NetModeServerInstance(*this)))
	{
		return;
	}

	HealthPoint = FMath::Clamp(InHealthPoint, 0, MaxHealthPoint);

	if (GetOwner() && P3Core::IsP3NetModeServerInstance(*GetOwner()))
	{
		Server_SetDirty(*this);
	}

	if (!Server_IsServerOnly())
	{
		UP3World* World = P3Core::GetP3World(*this);
		if (World)
		{
			const actorid ActorId = World->GetActorIdFromActor(GetOwner());

			FP3NetRevive NetRevive;
			NetRevive.HealthPoint = InHealthPoint;

			World->Server_MulticastPacketReliable(this, ActorId, GetOwner(), NetRevive, EP3NetComponentType::Health, &UP3HealthPointComponent::Client_HandleRevive);
		}
	}

	MulticastCharacterRevive(InHealthPoint);
}

void UP3HealthPointComponent::MulticastSetHealthPointBP(int32 InHealthPoint)
{
	ensure(P3Core::IsP3NetModeServerInstance(*GetOwner()));
	
	SetHealthPoint(InHealthPoint);
}

void UP3HealthPointComponent::NetSerialize(FArchive& Archive)
{
	if (!Archive.IsLoading())
	{
		Archive << MaxHealthPoint;
		Archive << HealthPoint;
	}
	else
	{
		int32 NewMaxHealthPoint, NewHealthPoint;

		Archive << NewMaxHealthPoint;
		Archive << NewHealthPoint;

		if (NewMaxHealthPoint != MaxHealthPoint)
		{
			SetMaxHealthPoint(NewMaxHealthPoint);
		}

		if (NewHealthPoint != HealthPoint)
		{
			SetHealthPointInternal(NewHealthPoint, false, true);
		}
	}
}

void UP3HealthPointComponent::MulticastCharacterDead()
{
	DeadTimeSeconds = GetWorld()->GetTimeSeconds();
	OnDead.Broadcast();
}

void UP3HealthPointComponent::MulticastCharacterRevive(int32 NewHealthPoint)
{
	SetHealthPointInternal(NewHealthPoint, true, false);

	ReviveTimeSeconds = GetWorld()->GetTimeSeconds();
	OnRevive.Broadcast();
}

void UP3HealthPointComponent::Client_HandleDead(const FP3DediToClientHandlerParams& Params)
{
	MulticastCharacterDead();
}

void UP3HealthPointComponent::Client_HandleRevive(const FP3DediToClientHandlerParams& Params)
{
	FP3NetRevive NetRevive;

	const bool bSerializeSucceeded = P3WorldNet::BufferToPacket(P3Core::GetP3World(*this), Params.Buffer, NetRevive);

	if (ensure(bSerializeSucceeded))
	{
		MulticastCharacterRevive(NetRevive.HealthPoint);
	}
}

void UP3HealthPointComponent::Server_SetDirty(const UActorComponent& Self)
{
	if (bServer_ServerOnly)
	{
		return;
	}

	IP3ComponentInterface::Server_SetDirty(Self);
}
