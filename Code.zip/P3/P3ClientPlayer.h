// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "P3Cms.h"
#include "P3Version.h"
#include "P3ClientPlayer.generated.h"

USTRUCT(BlueprintType)
struct FP3ClientPlayer
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FName Name;

	UPROPERTY(BlueprintReadOnly)
	EP3CharClass CharClass;

	UPROPERTY(BlueprintReadOnly)
	int32 CharLevel;

	UPROPERTY(BlueprintReadOnly)
	FP3Version Version;
};

struct FP3ClientPlayerCharacter
{
	FString CharName;
	EP3CharClass CharClass;
	int32 CharLevel;
	FString Zone;

	FP3ClientPlayerCharacter(const FString& InCharName, EP3CharClass InCharClass, int32 InCharLevel, const FString& InZone)
		: CharName(InCharName), CharClass(InCharClass), CharLevel(InCharLevel), Zone(InZone) {}
};

USTRUCT()
struct FP3ClientPlayerCharacters
{
	GENERATED_BODY()

	TArray<FP3ClientPlayerCharacter> PlayerCharList;
};
