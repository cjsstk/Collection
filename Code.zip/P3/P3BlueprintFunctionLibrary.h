// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Engine/LatentActionManager.h"
#include "LatentActions.h"
#include "Runtime/Online/HTTP/Public/Http.h"
#include "P3BlueprintFunctionLibrary.generated.h"


// Latent Http Request action
class FLatentHttpRequestAction : public FPendingLatentAction
{
public:
    FName ExecutionFunction;
    int32 OutputLink;
    FWeakObjectPtr CallbackTarget;
	FString& OutString;
	bool& bOutSucceeded;

	bool bCompleted = false;

    FLatentHttpRequestAction(TSharedRef<IHttpRequest> InHttpRequest, bool& bInOutSucceeded, FString& InOutString, const FLatentActionInfo& LatentInfo);
	~FLatentHttpRequestAction();

    virtual void UpdateOperation(FLatentResponse& Response) override;

#if WITH_EDITOR
    // Returns a human readable description of the latent operation's current state
    virtual FString GetDescription() const override;
#endif

	void OnHttpResponseReceived(FHttpRequestPtr Request, FHttpResponsePtr Response, bool bWasSuccessful);

private:
	TSharedRef<IHttpRequest> Request;
};


/**
 * Blueprint function library
 */
UCLASS(meta=(ScriptName="P3Library"))
class P3_API UP3BlueprintFunctionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "Net", meta = (WorldContext="WorldContextObject"))
	static bool IsP3NetModeServer(UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "Net", meta = (WorldContext="WorldContextObject"))
	static bool IsP3NetModeServerInstance(UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "Net", meta = (WorldContext="WorldContextObject"))
	static UP3World* GetP3World(UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "Particle", meta = (WorldContext = "WorldContextObject"))
	static class AActor* GetP3WorldParticleActor(UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "Patch")
	static FString GetChangeLog();

	UFUNCTION(BlueprintPure, Category = "Animation")
	static float GetSlotMontageLocalWeight(class UAnimInstance* AnimInstance, FName SlotNodeName);

	UFUNCTION(BlueprintCallable, Category = "Combat", meta=(WorldContext="WorldContextObject"))
	static void ExplodeBP(UObject* WorldContextObject, const FVector& Location, float Radius, float Damage, float ImpulseVelocity, bool bKnockDown, float KnockDownDurationSeconds, const TArray<AActor*>& IgnoreActors);

	UFUNCTION(BlueprintCallable, Category = "Combat", meta=(WorldContext="WorldContextObject"))
	static void Server_BurnAround(UObject* WorldContextObject, const FVector& Location, float Radius, float BurnSeconds, const TArray<AActor*>& IgnoreActors, UObject* SourceObject);

	UFUNCTION(BlueprintCallable, Category = "Weapon", meta = (WorldContext = "WorldContextObject"))
	static bool IsTempWeapon(EP3WeaponType WeaponType);

	UFUNCTION(BlueprintCallable, Category = "Utility")
	static bool GetAllBlueprintNamesInPath(FName Path, TArray<FName>& Result, UClass* BaseClass);

	UFUNCTION(BlueprintCallable, Category = "Component")
	static void CreateChildActor(class UChildActorComponent* ChildActorComp);

	UFUNCTION(BlueprintCallable, Category = "Web", meta = (Latent, LatentInfo = "LatentInfo", WorldContext="WorldContextObject"))
	static void HttpRequestURL(UObject* WorldContextObject, const FString& Url, bool& bSucceeded, FString& StringContent, struct FLatentActionInfo LatentInfo);

	UFUNCTION(BlueprintCallable, Category = "Web", meta = (Latent, LatentInfo = "LatentInfo", WorldContext="WorldContextObject"))
	static void HttpRequestNewRanking(UObject* WorldContextObject, const FString& Url, const FString& Stage, const FString& Name, int32 Record, bool& bSucceeded, FString& StringContent, struct FLatentActionInfo LatentInfo);

	UFUNCTION(BlueprintCallable, Category = "Character")
	static void Server_CommandTeleportCharacter(class AP3Character* Character, const FVector& Location, const FRotator& Rotation);

	UFUNCTION(BlueprintCallable, Category = "Message")
	static void Server_SendToastMessageToPlayerByCharacter(class AP3Character* Character, const FText& Message);

	UFUNCTION(BlueprintCallable, Category = "Message",  meta = (WorldContext="WorldContextObject"))
	static void Server_SendToastMessageToAllPlayers(UObject* WorldContextObject, const FText& Message);
};
