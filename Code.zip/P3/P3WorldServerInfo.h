// Copyright 2018 XLGames, Inc. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "P3WorldServerInfo.generated.h"

USTRUCT()
struct FP3WorldServerInfo
{
	GENERATED_BODY()

	UPROPERTY()
	FString Name;

	UPROPERTY()
	FString Address;

	UPROPERTY()
	int32 Port = 0;
};
