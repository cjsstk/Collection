// Copyright (c) 2018 XLGames, Inc. All rights reserved.
#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifyState_DropBox.generated.h"

class UAnimSequenceBase;
class USkeletalMeshComponent;

UCLASS()
class Q6_API UPlayDropBoxEffect : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	UPlayDropBoxEffect()
		: EffectMaterialSpeed(1.0f)
#if WITH_EDITORONLY_DATA
		, bRecoverDefaultMaterial(false)
#endif
		, EffectMaterialSeconds(0.0f)
	{
	}

	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration);
	virtual void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime);
	virtual void NotifyEnd(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation);

	UPROPERTY(EditAnywhere)
	UMaterialInterface* DropBoxEffectMaterial;

	UPROPERTY(EditAnywhere)
	float EffectMaterialSpeed;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere)
	bool bRecoverDefaultMaterial;
#endif

private:
	UPROPERTY(Transient)
	float EffectMaterialSeconds;

#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
	TArray<UMaterialInterface*> DefaultMaterials;
#endif
};
