// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "UnitAnimNotifies.h"
#include "CombatPlayerController.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Unit.h"
#include "Materials/MaterialInstanceDynamic.h"

void UMove::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	AUnit* Unit = Cast<AUnit>(MeshComp->GetOuter());
	if (Unit)
	{
		Unit->OnAnimNotifyMove(this->DistanceLeft, this->bBackward, TotalDuration);
	}
}

void UPlayParticleEffectOnTarget::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	AUnit* Unit = Cast<AUnit>(MeshComp->GetOuter());
	if (Unit)
	{
		Unit->OnAnimNotifyPlayParticleEffectOnTarget(this->SpawnParticleParam, this->SpawnSoundParam);
	}
}

void UPlayBeamParticleEffect::NotifyBegin(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation, float TotalDuration)
{
	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	AUnit* Unit = Cast<AUnit>(MeshComp->GetOuter());
	if (Unit)
	{
		Unit->OnAnimNotifyPlayBeamParticleEffect(this->BeamParticleEffectDesc, TotalDuration);
	}
}

void UHitWithWeight::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	AUnit* Unit = Cast<AUnit>(MeshComp->GetOuter());
	if (Unit)
	{
		Unit->OnAnimNotifyHit(this->SpawnHitParticleParam, this->SpawnHitSoundParam);
	}
}

void UFireProjectile::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	AUnit* Unit = Cast<AUnit>(MeshComp->GetOuter());
	if (Unit)
	{
		Unit->OnAnimNotifyFireProjectile(this->ProjectileEffectDesc, this->SpawnHitParticleParam, this->SpawnHitSoundParam);
	}
}

void USequenceCameraFollow::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	ACombatPlayerController* CombatPlayerController = GetCombatPlayerController(MeshComp->GetOuter());
	if (CombatPlayerController)
	{
		CombatPlayerController->SetSequenceCameraFollow(true);
	}
}

void USequenceCameraFollow::NotifyEnd(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation)
{
	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	ACombatPlayerController* CombatPlayerController = GetCombatPlayerController(MeshComp->GetOuter());
	if (CombatPlayerController)
	{
		CombatPlayerController->SetSequenceCameraFollow(false);
	}
}

struct FColorMod
{
	int32 EventID;
	int32 MeshID;

	FLinearColor RestoreColor;
	int32 MaterialIndex;
	float Duration;
	float PastTime;

	float GetCurveTime() const
	{
		return FMath::Clamp(PastTime / Duration, 0.0f, 1.0f);
	}
};
TArray<FColorMod> ColorMods;

int32 _GetColorModIndex(int32 EventID, int32 MeshID)
{
	return ColorMods.IndexOfByPredicate([=](const FColorMod& Mod)
			{
				return (Mod.EventID == EventID && Mod.MeshID == MeshID);
			});
}

void UColorCurve::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	if (!CurveColor)
	{
		return;
	}

	int32 MaterialIndex = MeshComp->GetMaterialIndex(SlotName);
	if (MaterialIndex == INDEX_NONE)
	{
		return;
	}

	UMaterialInterface* Material = MeshComp->GetMaterial(MaterialIndex);
	if (!Material)
	{
		return;
	}

	FLinearColor RestoreColor(0, 0, 0);
	FMaterialParameterInfo ParameterInfo(ParameterName);

	if (!Material->GetVectorParameterValue(ParameterInfo, RestoreColor))
	{
		return;
	}

	int32 Index = _GetColorModIndex(GetUniqueID(), MeshComp->GetUniqueID());
	if (Index == INDEX_NONE)
	{
		FColorMod NewColorMod;
		NewColorMod.EventID = GetUniqueID();
		NewColorMod.MeshID = MeshComp->GetUniqueID();
		Index = ColorMods.Add(NewColorMod);
	}

	ColorMods[Index].RestoreColor = RestoreColor;
	ColorMods[Index].MaterialIndex = MaterialIndex;
	ColorMods[Index].Duration = TotalDuration;
	ColorMods[Index].PastTime = 0.0f;
}

void UColorCurve::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime)
{
	int32 Index = _GetColorModIndex(GetUniqueID(), MeshComp->GetUniqueID());
	if (Index == INDEX_NONE)
	{
		return;
	}

	FColorMod& Modifier = ColorMods[Index];

	UMaterialInstanceDynamic* Instance = MeshComp->CreateAndSetMaterialInstanceDynamic(Modifier.MaterialIndex);
	if (Instance)
	{
		FLinearColor Color = CurveColor->GetLinearColorValue(Modifier.GetCurveTime());
		Instance->SetVectorParameterValue(ParameterName, Color);
	}

	Modifier.PastTime += FrameDeltaTime;
}

void UColorCurve::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	int32 Index = _GetColorModIndex(GetUniqueID(), MeshComp->GetUniqueID());
	if (Index == INDEX_NONE)
	{
		return;
	}

	FColorMod& Modifier = ColorMods[Index];

	UMaterialInstanceDynamic* Instance = MeshComp->CreateAndSetMaterialInstanceDynamic(Modifier.MaterialIndex);
	if (Instance)
	{
		Instance->SetVectorParameterValue(ParameterName, Modifier.RestoreColor);
	}

	ColorMods.RemoveAtSwap(Index);
}

void USpawnSkeletalMesh::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	if (!Desc.IsValid())
	{
		return;
	}

	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return;
	}

	AUnit* Unit = Cast<AUnit>(MeshComp->GetOuter());
	if (Unit)
	{
		if (!Desc.bDestroyAtEnd)
		{
			TotalDuration = Desc.Duration;
		}

		Unit->OnAnimNotifySpawnSkeletalMesh(Desc, TotalDuration, bTarget);
	}
}
