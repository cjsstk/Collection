// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Q6Enum.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "PlayCharacterVoice.generated.h"

class USoundBase;

/**
 * Play Character Voice Notify (random unlocked voice / given sound base due to system)
 */
UCLASS()
class Q6_API UPlayCharacterVoice : public UAnimNotify
{
	GENERATED_BODY()

public:
	UPlayCharacterVoice() : VoiceCategory(ECharacterVoiceCategory::None) {}

	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(EditAnywhere)
	ECharacterVoiceCategory VoiceCategory;

	UPROPERTY(EditAnywhere)
	USoundBase* Sound;
};
