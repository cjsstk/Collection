// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Curves/CurveLinearColor.h"
#include "Q6Struct.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "UnitAnimNotifies.generated.h"

/**
 * Move Notify
 */
UCLASS()
class Q6_API UMove : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	UMove() : DistanceLeft(0.f), bBackward(false) {}

	virtual void NotifyBegin(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation, float TotalDuration) override;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float DistanceLeft;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bBackward;
};

/**
 * Hit Notify
 */
UCLASS()
class Q6_API UHitWithWeight : public UAnimNotify
{
	GENERATED_BODY()

public:
	UHitWithWeight() : Weight(1.f) {}

	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float Weight;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnParticleParams SpawnHitParticleParam;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnSoundParams SpawnHitSoundParam;
};

/**
 * Fire Projectile Notify
 */
UCLASS()
class Q6_API UFireProjectile : public UHitWithWeight
{
	GENERATED_BODY()

public:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FProjectileEffectDesc ProjectileEffectDesc;
};

/**
 * Play Beam Particle Notify
 */
UCLASS()
class Q6_API UPlayBeamParticleEffect : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation, float TotalDuration) override;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FBeamParticleEffectDesc BeamParticleEffectDesc;
};

/**
 * Play Particle Effect On Target Notify
 */
UCLASS()
class Q6_API UPlayParticleEffectOnTarget : public UAnimNotify
{
	GENERATED_BODY()

public:
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnParticleParams SpawnParticleParam;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnSoundParams SpawnSoundParam;
};

/**
 * Sequence Camera Follow Notify
 */
UCLASS()
class Q6_API USequenceCameraFollow : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;
	virtual void NotifyEnd(USkeletalMeshComponent * MeshComp, UAnimSequenceBase * Animation) override;
};

UCLASS()
class Q6_API UColorCurve : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration);
	virtual void NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime);
	virtual void NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation);

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName SlotName;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName ParameterName;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	UCurveLinearColor* CurveColor;
};

UCLASS()
class Q6_API USpawnSkeletalMesh : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	USpawnSkeletalMesh()
	{
		bTarget = true;
	}

	virtual void NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration) override;

	UPROPERTY(EditAnywhere)
	FSpawnSkeletalMeshDesc Desc;

	UPROPERTY(EditAnywhere)
	bool bTarget;
};
