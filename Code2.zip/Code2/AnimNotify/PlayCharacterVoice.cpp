// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "PlayCharacterVoice.h"
#include "Sound/SoundBase.h"
#include "CombatPresenter.h"
#include "LobbyTemplate.h"
#include "MenuUnit.h"
#include "Q6CombatGameMode.h"
#include "Q6GameMode.h"
#include "Q6SoundPlayer.h"
#include "Unit.h"

void UPlayCharacterVoice::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
#if WITH_EDITOR
	UWorld* World = MeshComp->GetWorld();
	const AQ6GameModeBase* GameMode = World ? Cast<AQ6GameModeBase>(World->GetAuthGameMode()) : nullptr;
	if (!GameMode)
	{
		if (Sound)
		{
			if (Sound->IsLooping())
			{
				UE_LOG(LogAudio, Warning, TEXT("PlayCharacterVoice notify: Anim %s tried to spawn infinitely looping sound asset %s. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(Sound));
				return;
			}

			UGameplayStatics::PlaySound2D(MeshComp->GetWorld(), Sound);
		}

		return;
	}
#endif

	FCharacterType CharacterType = CharacterTypeInvalid;

	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(MeshComp);
	if (CombatGameMode)
	{
		ACombatPresenter* CombatPresenter = CombatGameMode->Presenter;
		if (CombatPresenter)
		{
			AUnit* Unit = Cast<AUnit>(MeshComp->GetOuter());
			if (Unit)
			{
				CharacterType = CombatPresenter->GetAllyCharacterType(Unit->GetUnitId());
			}

			if (CharacterType == CharacterTypeInvalid)
			{
				if (Sound)
				{
					if (Sound->IsLooping())
					{
						UE_LOG(LogAudio, Warning, TEXT("PlayCharacterVoice notify: Anim %s tried to spawn infinitely looping sound asset %s. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(Sound));
					}
					else
					{
						bool bPlayVoice = true;
						if (Unit && Unit->IsMuteDeadVoice() && VoiceCategory == ECharacterVoiceCategory::Dead)
						{
							// the some monster's dead voice could be muted when the monsters were dead at the same time
							bPlayVoice = false;
						}

						if (bPlayVoice)
						{
							GetSoundPlayer().PlayVoice(Sound);
						}
					}
				}
				return;
			}
		}
	}
	else
	{
		ULobbyCharacterComponent* LobbyCharacter = Cast<ULobbyCharacterComponent>(MeshComp->GetOuter());
		if (LobbyCharacter)
		{
			CharacterType = LobbyCharacter->GetCharacterType();
		}
		else
		{
			AMenuUnit* MenuUnit = Cast<AMenuUnit>(MeshComp->GetOuter());
			if (MenuUnit)
			{
				MenuUnit->OnAnimNotifyPlayVoice();
			}
			return;
		}
	}

	GetSoundPlayer().PlayCharacterVoice(CharacterType, VoiceCategory);
}
