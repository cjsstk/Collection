// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.


#pragma once

#include "CoreMinimal.h"
#include "Q6Enum.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "AnimNotify_Q6PlayZoneSound.generated.h"

class UAnimSequenceBase;
class USkeletalMeshComponent;
class USoundBase;

USTRUCT()
struct FZoneSounds
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	EZoneAttribute SoundAttribute = EZoneAttribute::Ground;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Ground Sound"))
	USoundBase* SoundGround;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Water Sound"))
	USoundBase* SoundWater;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Ice Sound"))
	USoundBase* SoundIce;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Grass Sound"))
	USoundBase* SoundGrass;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Rock Sound"))
	USoundBase* SoundRock;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Lava Sound"))
	USoundBase* SoundLava;

	USoundBase* GetSound(EZoneAttribute Attr) const
	{
		USoundBase* SoundAttributeArray[] = { SoundGround, SoundWater, SoundIce, SoundGrass, SoundRock, SoundLava };
		return SoundAttributeArray[(int)Attr];
	}

	auto GetAllSounds() const
	{
		return TArray<USoundBase*>{ SoundGround, SoundWater, SoundIce, SoundGrass, SoundRock, SoundLava };
	}
};

UCLASS(const, hidecategories=Object, collapsecategories, autoexpandcategories = ZoneSounds, meta=(DisplayName="Q6 Play Zone Sound"))
class Q6_API UAnimNotify_Q6PlayZoneSound : public UAnimNotify
{
	GENERATED_BODY()

public:

	UAnimNotify_Q6PlayZoneSound();

	// Begin UAnimNotify interface
	virtual FString GetNotifyName_Implementation() const override;
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
#if WITH_EDITOR
	virtual void ValidateAssociatedAssets() override;
#endif
	// End UAnimNotify interface

	UPROPERTY(EditAnywhere, Category = "ZoneSounds")
	FZoneSounds ZoneSounds;

	// Volume Multiplier
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AnimNotify", meta=(ExposeOnSpawn = true))
	float VolumeMultiplier;

	// Pitch Multiplier
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AnimNotify", meta=(ExposeOnSpawn = true))
	float PitchMultiplier;

	// If this sound should follow its owner
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	uint32 bFollow:1;

	// Socket or bone name to attach sound to
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AnimNotify", meta=(EditCondition="bFollow", ExposeOnSpawn = true))
	FName AttachName;
};



