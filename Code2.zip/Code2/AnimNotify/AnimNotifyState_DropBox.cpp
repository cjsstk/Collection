// Copyright (c) 2018 XLGames, Inc. All rights reserved.
#include "AnimNotifyState_DropBox.h"
#include "Components/SkeletalMeshComponent.h"
#include "Animation/AnimSequenceBase.h"
#include "Materials/MaterialInstanceDynamic.h"

void UPlayDropBoxEffect::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	if (!DropBoxEffectMaterial)
	{
		return;
	}

	int32 NumMaterials = MeshComp->GetNumMaterials();
#if WITH_EDITORONLY_DATA
	if (DefaultMaterials.Num() == 0)
	{
		for (int32 Index = 0; Index < NumMaterials; ++Index)
		{
			if (MeshComp->OverrideMaterials.IsValidIndex(Index))
			{
				DefaultMaterials.Add(MeshComp->OverrideMaterials[Index]);
				continue;
			}

			UMaterialInterface* Material = MeshComp->SkeletalMesh->Materials[Index].MaterialInterface;
			if (Material)
			{
				DefaultMaterials.Add(Material);
			}
		}
	}
#endif
	for (int32 Index = 0; Index < NumMaterials; ++Index)
	{
		UMaterialInstanceDynamic* DynamicMaterial = MeshComp->CreateDynamicMaterialInstance(Index, DropBoxEffectMaterial);
		DynamicMaterial->K2_CopyMaterialInstanceParameters(DropBoxEffectMaterial);
	}

	EffectMaterialSeconds = 0.0f;
}

void UPlayDropBoxEffect::NotifyTick(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float FrameDeltaTime)
{
	if (!DropBoxEffectMaterial)
	{
		return;
	}

	EffectMaterialSeconds += FrameDeltaTime * EffectMaterialSpeed;

	const static FName TimeName("Time");
	float CurrentScalarParameterValue;

	if (DropBoxEffectMaterial->GetScalarParameterValue(TimeName, CurrentScalarParameterValue))
	{
		int32 NumMaterials = MeshComp->GetNumMaterials();
		for (int32 Index = 0; Index < NumMaterials; ++Index)
		{
			UMaterialInstanceDynamic* Material = Cast<UMaterialInstanceDynamic>(MeshComp->GetMaterial(Index));
			if (Material == nullptr)
			{
				continue;
			}

			Material->SetScalarParameterValue(TimeName, EffectMaterialSeconds);
		}
	}
}

void UPlayDropBoxEffect::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
#if WITH_EDITORONLY_DATA
	if (bRecoverDefaultMaterial)
	{
		const int NumMaterials = DefaultMaterials.Num();
		for (int Index = 0; Index < NumMaterials; ++Index)
		{
			UMaterialInterface* DefaultMaterial = DefaultMaterials[Index];
			MeshComp->SetMaterial(Index, DefaultMaterial);
		}
	}
#endif
}
