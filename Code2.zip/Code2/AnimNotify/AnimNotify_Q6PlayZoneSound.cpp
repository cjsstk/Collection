// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "AnimNotify_Q6PlayZoneSound.h"
#include "Components/SkeletalMeshComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundBase.h"
#include "Animation/AnimSequenceBase.h"

#if WITH_EDITOR
#include "Logging/MessageLog.h"
#include "Misc/UObjectToken.h"
#endif

#include "Q6GameInstance.h"
/////////////////////////////////////////////////////
// UAnimNotify_Q6PlayZoneSound

UAnimNotify_Q6PlayZoneSound::UAnimNotify_Q6PlayZoneSound()
	: Super()
{
	VolumeMultiplier = 1.f;
	PitchMultiplier = 1.f;

#if WITH_EDITORONLY_DATA
	NotifyColor = FColor(196, 142, 255, 255);
#endif // WITH_EDITORONLY_DATA
}

void UAnimNotify_Q6PlayZoneSound::Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation)
{
	// Don't call super to avoid call back in to blueprints
	EZoneAttribute CurrentAttribute = ZoneSounds.SoundAttribute;

	if (UQ6GameInstance::Get(this))
	{
		CurrentAttribute = UQ6GameInstance::Get(this)->GetZoneAttribute();
	}

	USoundBase* Sound = ZoneSounds.GetSound(CurrentAttribute);

	if (Sound)
	{
		if (Sound->IsLooping())
		{
			UE_LOG(LogAudio, Warning, TEXT("PlaySound notify: Anim %s tried to spawn infinitely looping sound asset %s. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(Sound));
			return;
		}

		if (bFollow)
		{
			UGameplayStatics::SpawnSoundAttached(Sound, MeshComp, AttachName, FVector(ForceInit), EAttachLocation::SnapToTarget, false, VolumeMultiplier, PitchMultiplier);
		}
		else
		{
			UGameplayStatics::PlaySoundAtLocation(MeshComp->GetWorld(), Sound, MeshComp->GetComponentLocation(), VolumeMultiplier, PitchMultiplier);
		}
	}
}

FString UAnimNotify_Q6PlayZoneSound::GetNotifyName_Implementation() const
{
	if (USoundBase* Sound = ZoneSounds.GetSound(ZoneSounds.SoundAttribute))
	{
		return Sound->GetName();
	}
	else
	{
		return Super::GetNotifyName_Implementation();
	}
}

#if WITH_EDITOR
void UAnimNotify_Q6PlayZoneSound::ValidateAssociatedAssets()
{
	static const FName NAME_AssetCheck("AssetCheck");

	for (USoundBase* Sound: ZoneSounds.GetAllSounds())
	{
		if ((Sound != nullptr) && (Sound->IsLooping()))
		{
			UObject* ContainingAsset = GetContainingAsset();

			FMessageLog AssetCheckLog(NAME_AssetCheck);

			const FText MessageLooping = FText::Format(
				NSLOCTEXT("AnimNotify", "Sound_ShouldNotLoop", "Sound {0} used in anim notify for asset {1} is set to looping, but the slot is a one-shot (it won't be played to avoid leaking an instance per notify)."),
				FText::AsCultureInvariant(Sound->GetPathName()),
				FText::AsCultureInvariant(ContainingAsset->GetPathName()));
			AssetCheckLog.Warning()
				->AddToken(FUObjectToken::Create(ContainingAsset))
				->AddToken(FTextToken::Create(MessageLooping));

			if (GIsEditor)
			{
				AssetCheckLog.Notify(MessageLooping, EMessageSeverity::Warning, /*bForce=*/ true);
			}
		}
	}
}
#endif
