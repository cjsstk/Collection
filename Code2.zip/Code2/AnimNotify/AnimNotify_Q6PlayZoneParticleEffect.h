// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.


#pragma once

#include "CoreMinimal.h"
#include "Q6Enum.h"
#include "UObject/ObjectMacros.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "AnimNotify_Q6PlayZoneParticleEffect.generated.h"

class UAnimSequenceBase;
class UParticleSystem;
class USkeletalMeshComponent;
class UParticleSystemComponent;

USTRUCT()
struct FZoneParticles
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	EZoneAttribute ParticleAttribute = EZoneAttribute::Ground;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Ground Particle"))
	UParticleSystem* PSTemplateGround;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Water Particle"))
	UParticleSystem* PSTemplateWater;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Ice Particle"))
	UParticleSystem* PSTemplateIce;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Grass Particle"))
	UParticleSystem* PSTemplateGrass;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Rock Particle"))
	UParticleSystem* PSTemplateRock;

	UPROPERTY(EditAnywhere, meta = (DisplayName = "Lava Particle"))
	UParticleSystem* PSTemplateLava;

	UParticleSystem* GetParticle(EZoneAttribute Attr) const
	{
		UParticleSystem* PSTemplateAttributeArray[] = { PSTemplateGround, PSTemplateWater, PSTemplateIce, PSTemplateGrass, PSTemplateRock, PSTemplateLava };
		return PSTemplateAttributeArray[(int)Attr];
	}

	auto GetAllParticles() const
	{
		return TArray<UParticleSystem*>{ PSTemplateGround, PSTemplateWater, PSTemplateIce, PSTemplateGrass, PSTemplateRock, PSTemplateLava };
	}
};

UCLASS(const, hidecategories=Object, collapsecategories, autoexpandcategories = ZoneParticles, meta=(DisplayName="Q6 Play Zone Particle Effect"))
class Q6_API UAnimNotify_Q6PlayZoneParticleEffect : public UAnimNotify
{
	GENERATED_BODY()

public:

	UAnimNotify_Q6PlayZoneParticleEffect();

	// Begin UObject interface
	virtual void PostLoad() override;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
#endif
	// End UObject interface

	// Begin UAnimNotify interface
	virtual FString GetNotifyName_Implementation() const override;
	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation) override;
#if WITH_EDITOR
	virtual void ValidateAssociatedAssets() override;
#endif
	// End UAnimNotify interface

	// Particle System to Spawn
	UPROPERTY(EditAnywhere, Category = "ZoneParticles")
	FZoneParticles ZoneParticles;

	// Location offset from the socket
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AnimNotify")
	FVector LocationOffset;

	// Rotation offset from socket
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AnimNotify")
	FRotator RotationOffset;

	// Scale to spawn the particle system at
	UPROPERTY(EditAnywhere, Category="AnimNotify")
	FVector Scale;

private:
	// Cached version of the Rotation Offset already in Quat form
	FQuat RotationOffsetQuat;

protected:
	// Spawns the ParticleSystemComponent. Called from Notify.
	virtual UParticleSystemComponent* SpawnParticleSystem(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation);
public:

	// Should attach to the bone/socket
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category="AnimNotify")
	uint32 Attached:1; 	//~ Does not follow coding standard due to redirection from BP

	// SocketName to attach to
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AnimNotify")
	FName SocketName;
};



