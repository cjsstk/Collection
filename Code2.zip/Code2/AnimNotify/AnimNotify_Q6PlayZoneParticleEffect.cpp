// Copyright 1998-2019 Epic Games, Inc. All Rights Reserved.

#include "AnimNotify_Q6PlayZoneParticleEffect.h"
#include "Particles/ParticleSystem.h"
#include "Components/SkeletalMeshComponent.h"
#include "ParticleHelper.h"
#include "Kismet/GameplayStatics.h"
#include "Animation/AnimSequenceBase.h"

#if WITH_EDITOR
#include "Logging/MessageLog.h"
#include "Misc/UObjectToken.h"
#endif

#include "Q6GameInstance.h"
#include "Q6Log.h"
/////////////////////////////////////////////////////
// UAnimNotify_Q6PlayZoneParticleEffect

UAnimNotify_Q6PlayZoneParticleEffect::UAnimNotify_Q6PlayZoneParticleEffect()
	: Super()
{
	Attached = true;
	Scale = FVector(1.f);

#if WITH_EDITORONLY_DATA
	NotifyColor = FColor(192, 255, 99, 255);
#endif // WITH_EDITORONLY_DATA
}

void UAnimNotify_Q6PlayZoneParticleEffect::PostLoad()
{
	Super::PostLoad();

	RotationOffsetQuat = FQuat(RotationOffset);
}

#if WITH_EDITOR
void UAnimNotify_Q6PlayZoneParticleEffect::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (PropertyChangedEvent.MemberProperty && PropertyChangedEvent.MemberProperty->GetFName() == GET_MEMBER_NAME_CHECKED(UAnimNotify_Q6PlayZoneParticleEffect, RotationOffset))
	{
		RotationOffsetQuat = FQuat(RotationOffset);
	}
}

void UAnimNotify_Q6PlayZoneParticleEffect::ValidateAssociatedAssets()
{
	static const FName NAME_AssetCheck("AssetCheck");

	for (UParticleSystem* PSTemplate : ZoneParticles.GetAllParticles())
	{
		if ((PSTemplate != nullptr) && (PSTemplate->IsLooping()))
		{
			UObject* ContainingAsset = GetContainingAsset();

			FMessageLog AssetCheckLog(NAME_AssetCheck);

			const FText MessageLooping = FText::Format(
				NSLOCTEXT("AnimNotify", "ParticleSystem_ShouldNotLoop", "Particle system {0} used in anim notify for asset {1} is set to looping, but the slot is a one-shot (it won't be played to avoid leaking a component per notify)."),
				FText::AsCultureInvariant(PSTemplate->GetPathName()),
				FText::AsCultureInvariant(ContainingAsset->GetPathName()));
			AssetCheckLog.Warning()
				->AddToken(FUObjectToken::Create(ContainingAsset))
				->AddToken(FTextToken::Create(MessageLooping));

			if (GIsEditor)
			{
				AssetCheckLog.Notify(MessageLooping, EMessageSeverity::Warning, /*bForce=*/ true);
			}
		}
	}
}
#endif

void UAnimNotify_Q6PlayZoneParticleEffect::Notify(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation)
{
	// Don't call super to avoid unnecessary call in to blueprints
	SpawnParticleSystem(MeshComp, Animation);
}

FString UAnimNotify_Q6PlayZoneParticleEffect::GetNotifyName_Implementation() const
{
	if (UParticleSystem* PSTemplate = ZoneParticles.GetParticle(ZoneParticles.ParticleAttribute))
	{
		return PSTemplate->GetName();
	}
	else
	{
		return Super::GetNotifyName_Implementation();
	}
}

UParticleSystemComponent* UAnimNotify_Q6PlayZoneParticleEffect::SpawnParticleSystem(class USkeletalMeshComponent* MeshComp, class UAnimSequenceBase* Animation)
{
	UParticleSystemComponent* ReturnComp = nullptr;
	EZoneAttribute CurrentAttribute = ZoneParticles.ParticleAttribute;

	if (UQ6GameInstance::Get(this))
	{
		CurrentAttribute = UQ6GameInstance::Get(this)->GetZoneAttribute();
	}

	UParticleSystem* PSTemplate = ZoneParticles.GetParticle(CurrentAttribute);

	if (PSTemplate)
	{
		if (PSTemplate->IsLooping())
		{
#if !NO_LOGGING
			UE_LOG(Q6_MEDRIAN5, Warning, TEXT("Particle Notify: Anim '%s' tried to spawn infinitely looping particle system '%s'. Spawning suppressed."), *GetNameSafe(Animation), *GetNameSafe(PSTemplate));
#endif

			return ReturnComp;
		}

		if (Attached)
		{
			ReturnComp = UGameplayStatics::SpawnEmitterAttached(PSTemplate, MeshComp, SocketName, LocationOffset, RotationOffset, Scale);
		}
		else
		{
			const FTransform MeshTransform = MeshComp->GetSocketTransform(SocketName);
			FTransform SpawnTransform;
			SpawnTransform.SetLocation(MeshTransform.TransformPosition(LocationOffset));
			SpawnTransform.SetRotation(MeshTransform.GetRotation() * RotationOffsetQuat);
			SpawnTransform.SetScale3D(Scale);
			ReturnComp = UGameplayStatics::SpawnEmitterAtLocation(MeshComp->GetWorld(), PSTemplate, SpawnTransform);
		}
	}

	return ReturnComp;
}
