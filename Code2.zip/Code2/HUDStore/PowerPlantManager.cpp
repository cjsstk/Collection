#include "PowerPlantManager.h"

#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UUPowerPlantManager

UPowerPlantManager::UPowerPlantManager()
{
	InitStore(EHSType::PowerPlant);
}

void UPowerPlantManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPowerPlantLoad Out;

	ClientNetwork.WsRequest(TEXT("powerPlant/load"), Out,
		TQ6ResponseDelegate<FL2CPowerPlantLoadResp>::CreateUObject(
			const_cast<UPowerPlantManager*>(this), &UPowerPlantManager::OnLoadResp));
}

void UPowerPlantManager::ReqUpgrade() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPowerPlantUpgrade Out;

	ClientNetwork.WsRequest(TEXT("powerPlant/upgrade"), Out,
		TQ6ResponseDelegate<FL2CPowerPlantUpgradeResp>::CreateUObject(
			const_cast<UPowerPlantManager*>(this), &UPowerPlantManager::OnUpgradeResp));
}

void UPowerPlantManager::ReqUpgradeComplete() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPowerPlantUpgradeComplete Out;

	ClientNetwork.WsRequest(TEXT("powerPlant/upgradeComplete"), Out,
		TQ6ResponseDelegate<FL2CPowerPlantUpgradeCompleteResp>::CreateUObject(
			const_cast<UPowerPlantManager*>(this), &UPowerPlantManager::OnUpgradeCompleteResp));
}

void UPowerPlantManager::ReqStore(int32 StoreCount) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPowerPlantStore Out;
	Out.Count = StoreCount;

	ClientNetwork.WsRequest(TEXT("powerPlant/store"), Out,
		TQ6ResponseDelegate<FL2CPowerPlantStoreResp>::CreateUObject(
			const_cast<UPowerPlantManager*>(this), &UPowerPlantManager::OnStoreResp));
}

void UPowerPlantManager::ReqRecharge(int32 RechargeCount) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPowerPlantRecharge Out;
	Out.Count = RechargeCount;

	ClientNetwork.WsRequest(TEXT("powerPlant/recharge"), Out,
		TQ6ResponseDelegate<FL2CPowerPlantRechargeResp>::CreateUObject(
			const_cast<UPowerPlantManager*>(this), &UPowerPlantManager::OnRechargeResp));
}

#if !UE_BUILD_SHIPPING
void UPowerPlantManager::ReqDevUpgrade(int32 TargetLevel) const
{
	FC2LDevPowerPlantUpgrade Out;
	Out.Level = TargetLevel;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	ClientNetwork.WsRequest(TEXT("dev/powerPlantUpgrade"), Out,
		TQ6ResponseDelegate<FL2CPowerPlantUpgradeCompleteResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CPowerPlantUpgradeCompleteResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "Cheat power plant upgrade");
		ACTION_DISPATCH_PowerPlantUpgradeCompleteResp(Res);
	}));
}
#endif

void UPowerPlantManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UPowerPlantManager, PowerPlantLoadResp);
	REGISTER_ACTION_HANDLER(UPowerPlantManager, PowerPlantUpgradeResp);
	REGISTER_ACTION_HANDLER(UPowerPlantManager, PowerPlantUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UPowerPlantManager, PowerPlantStoreResp);
	REGISTER_ACTION_HANDLER(UPowerPlantManager, PowerPlantRechargeResp);
	REGISTER_ACTION_HANDLER(UPowerPlantManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UPowerPlantManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UPowerPlantManager, DevPowerPlantOpenResp);
}

void UPowerPlantManager::OnLoadResp(const FResError* Error, const FL2CPowerPlantLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PowerPlantLoadResp(Msg);
	GameInstance->ReqNextContent();
}

void UPowerPlantManager::OnUpgradeResp(const FResError* Error, const FL2CPowerPlantUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PowerPlantUpgradeResp(Msg);
}

void UPowerPlantManager::OnUpgradeCompleteResp(const FResError* Error, const FL2CPowerPlantUpgradeCompleteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PowerPlantUpgradeCompleteResp(Msg);
}

void UPowerPlantManager::OnStoreResp(const FResError* Error, const FL2CPowerPlantStoreResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PowerPlantStoreResp(Msg);
}

void UPowerPlantManager::OnRechargeResp(const FResError* Error, const FL2CPowerPlantRechargeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PowerPlantRechargeResp(Msg);
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, PowerPlantLoadResp)
{
	auto Action = ACTION_PARSE_PowerPlantLoadResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlantInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, PowerPlantUpgradeResp)
{
	auto Action = ACTION_PARSE_PowerPlantUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlantInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, PowerPlantUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_PowerPlantUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlantInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, PowerPlantStoreResp)
{
	auto Action = ACTION_PARSE_PowerPlantStoreResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlantInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, PowerPlantRechargeResp)
{
	auto Action = ACTION_PARSE_PowerPlantRechargeResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlantInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlant;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlant;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, DevPowerPlantOpenResp)
{
	auto Action = ACTION_PARSE_DevPowerPlantOpenResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlantInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPowerPlantManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	PowerPlantInfo = Res.PowerPlant;

	return true;
}