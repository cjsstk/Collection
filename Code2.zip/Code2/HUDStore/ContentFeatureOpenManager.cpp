#include "ContentFeatureOpenManager.h"

#include "HSAction.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "CMS/CMS_gen.h"
#include "Q6.h"

void DumpContentFeatureOpen(const FContentFeatureOpenInfo& Info)
{
	Q6JsonLogPaul(Verbose, "", Q6KV("Type", Info.Type));
}

UContentFeatureOpenManager::UContentFeatureOpenManager()
{
	InitStore(EHSType::ContentFeatureOpen);
}

const FContentFeatureOpenInfo* UContentFeatureOpenManager::Find(const EFeatureOpenType& InFeatureOpenType) const
{
	for (const auto& ContentFeatureOpenInfo : ContentFeatureOpenInfos)
	{
		const FCMSContentFeatureOpenRow& ContentFeatureOpenRow = GetCMS()->GetContentFeatureOpenRowOrDummy(ContentFeatureOpenInfo.Type);
		if (ContentFeatureOpenRow.IsInvalid())
		{
			Q6JsonLogPaul(Error, "invalid content feature open type", Q6KV("Type", ContentFeatureOpenInfo.Type));
			continue;
		}

		if (ContentFeatureOpenRow.OpenType == InFeatureOpenType)
		{
			return &ContentFeatureOpenInfo;
		}
	}
	
	return nullptr;
}

bool UContentFeatureOpenManager::IsOpenContentFeature(const EFeatureOpenType& InFeatureOpenType) const
{
#if !UE_BUILD_SHIPPING
	if (GameInstance->IsDevMode())
	{
		return true;
	}
#endif

	return Find(InFeatureOpenType) != nullptr ? true : false;
}

void UContentFeatureOpenManager::Dump() const
{
	Q6JsonLogPaul(Verbose, "== ContentFeatureOpens ==", Q6KV("Total", ContentFeatureOpenInfos.Num()));
	for (const auto& ContentFeatureOpenInfo : ContentFeatureOpenInfos)
	{
		DumpContentFeatureOpen(ContentFeatureOpenInfo);
	}
}

void UContentFeatureOpenManager::ReqList() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LContentFeatureOpenList Out;

	ClientNetwork.WsRequest(TEXT("contentFeatureOpen/list"), Out,
		TQ6ResponseDelegate<FL2CContentFeatureOpenListResp>::CreateUObject(
			const_cast<UContentFeatureOpenManager*>(this), &UContentFeatureOpenManager::OnListResp));
}

bool UContentFeatureOpenManager::CheckContentOpenedBySubPartySlotIndex(const int32 SlotIndex) const
{
	switch (SlotIndex)
	{
		case SUB_PARTY_CHARACTER_FIRST_SLOT:
			return IsOpenContentFeature(EFeatureOpenType::PartySubFirstSlot);
		case SUB_PARTY_CHARACTER_SECOND_SLOT:
			return IsOpenContentFeature(EFeatureOpenType::PartySubSecondSlot);
		case SUB_PARTY_CHARACTER_THIRD_SLOT:
			return IsOpenContentFeature(EFeatureOpenType::PartySubThirdSlot);
	}

	return true;
}

void UContentFeatureOpenManager::OnListResp(const FResError* Error, const FL2CContentFeatureOpenListResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_ContentFeatureOpenListResp(Res);
	GameInstance->ReqNextContent();
}

/////////////////////////////////////////////////////////////////////////////
// ULobbyTemplateManager Setter

bool UContentFeatureOpenManager::Add(const TArray<FContentFeatureOpenInfo>& InContentFeatureOpenInfos)
{
	if (InContentFeatureOpenInfos.Num() > 0)
	{
		for (const auto& ContentFeatureOpenInfo : InContentFeatureOpenInfos)
		{
			const FCMSContentFeatureOpenRow& ContentFeatureOpenRow = GetCMS()->GetContentFeatureOpenRowOrDummy(ContentFeatureOpenInfo.Type);
			if (ContentFeatureOpenRow.IsInvalid())
			{
				Q6JsonLogPaul(Error, "invalid content feature open type", Q6KV("Type", ContentFeatureOpenInfo.Type));
				continue;
			}

			switch (ContentFeatureOpenRow.OpenType)
			{
			case EFeatureOpenType::WeeklyMisson:
			case EFeatureOpenType::CharacterMisson:
			case EFeatureOpenType::DailyDungeon:
			case EFeatureOpenType::ShopSell:
			case EFeatureOpenType::TrainingCenter:
			case EFeatureOpenType::PartySubFirstSlot:
			case EFeatureOpenType::PartySubSecondSlot:
			case EFeatureOpenType::PartySubThirdSlot:
			{
				if (!IsOpenContentFeature(ContentFeatureOpenRow.OpenType))
				{
					ContentFeatureOpenInfos.Add(ContentFeatureOpenInfo);
				}
			}
			break;
			}
		}

		ContentFeatureAppearInfo = InContentFeatureOpenInfos[0];
	}
	else
	{
		ContentFeatureAppearInfo.Type = FContentFeatureOpenType();
	}

	return true;
}

/////////////////////////////////////////////////////////////////////////////
// ULobbyTemplateManager HUDStore Action

void UContentFeatureOpenManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, ContentFeatureOpenListResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, VacationUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(UContentFeatureOpenManager, DevContentFeatureOpenResp);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, ContentFeatureOpenListResp)
{
	auto Action = ACTION_PARSE_ContentFeatureOpenListResp(InAction);

	auto& Res = Action->GetVal();
	ContentFeatureOpenInfos = Res.ContentFeatureOpens;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, VacationUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_VacationUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}

IMPLEMENT_ACTION_HANDLER(UContentFeatureOpenManager, DevContentFeatureOpenResp)
{
	auto Action = ACTION_PARSE_DevContentFeatureOpenResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.ContentFeatureOpenInfos);
}