#pragma once

#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "CheckInManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UAttendanceManager
UCLASS()
class Q6_API UCheckInManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UCheckInManager();
	~UCheckInManager();

	FCheckInBoardType GetNextCheckInBoardType(FCheckInBoardType CurrentBoardType) const;
	FCheckInBoardType GetFirstBoardPage() const;
	const FCheckInInfo* GetCheckInInfo(FCheckInBoardType CurrentBoardType) const;

	bool HasNewCheckInBoard() const;

	// Req
	void ReqList() const;
	void ReqRewardReceive() const;

	void Dump() const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnCheckInListResp(const FResError* Error, const FL2CCheckInListResp& Res);
	void OnCheckInRewardReceiveResp(const FResError* Error, const FL2CCheckInRewardReceiveResp& Res);

	// OnActions
	DECLARE_ACTION_HANDLER(CheckInListResp);
	DECLARE_ACTION_HANDLER(CheckInRewardReceiveResp);
	DECLARE_ACTION_HANDLER(DevCheckInLoadResp);
	DECLARE_ACTION_HANDLER(CheckInClear);

	TArray<FCheckInInfo> CheckInInfos;
	TArray<FCheckInBoardType> NewCheckInBoardTypes;
};
