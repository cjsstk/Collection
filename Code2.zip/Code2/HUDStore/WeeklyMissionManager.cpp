#include "WeeklyMissionManager.h"

#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"

UWeeklyMissionManager::UWeeklyMissionManager()
{
	InitStore(EHSType::WeeklyMission);
}

void UWeeklyMissionManager::ReqLoad() const
{
	ACTION_DISPATCH_ClearWeeklyMission();

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LWeeklyMissionLoad Out;

	ClientNetwork.WsRequest(TEXT("weeklyMission/load"), Out,
		TQ6ResponseDelegate<FL2CWeeklyMissionLoadResp>::CreateUObject(
			const_cast<UWeeklyMissionManager*>(this), &UWeeklyMissionManager::OnLoadResp));
}

void UWeeklyMissionManager::ReqReward(int32 Index) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LWeeklyMissionReceiveReward Out;
	Out.Index = Index;

	ClientNetwork.WsRequest(TEXT("weeklyMission/receiveReward"), Out,
		TQ6ResponseDelegate<FL2CWeeklyMissionReceiveRewardResp>::CreateUObject(
			const_cast<UWeeklyMissionManager*>(this), &UWeeklyMissionManager::OnReceiveRewardResp));
}

void UWeeklyMissionManager::ReqBingo(int32 Index) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LWeeklyMissionReceiveBingo Out;
	Out.Index = Index;

	ClientNetwork.WsRequest(TEXT("weeklyMission/receiveBingo"), Out,
		TQ6ResponseDelegate<FL2CWeeklyMissionReceiveBingoResp>::CreateUObject(
			const_cast<UWeeklyMissionManager*>(this), &UWeeklyMissionManager::OnReceiveBingoResp));
}

void UWeeklyMissionManager::ReqShuffle() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LWeeklyMissionShuffle Out;

	ClientNetwork.WsRequest(TEXT("weeklyMission/shuffle"), Out,
		TQ6ResponseDelegate<FL2CWeeklyMissionShuffleResp>::CreateUObject(
			const_cast<UWeeklyMissionManager*>(this), &UWeeklyMissionManager::OnShuffleResp));
}

void UWeeklyMissionManager::ReqConfirm() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LWeeklyMissionConfirm Out;

	ClientNetwork.WsRequest(TEXT("weeklyMission/confirm"), Out,
		TQ6ResponseDelegate<FL2CWeeklyMissionLoadResp>::CreateUObject(
			const_cast<UWeeklyMissionManager*>(this), &UWeeklyMissionManager::OnConfirmResp));
}

void UWeeklyMissionManager::OnLoadResp(const FResError* Error, const FL2CWeeklyMissionLoadResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_WeeklyMissionLoadResp(Resp);
	GameInstance->ReqNextContent();
}

TArray<FMissionType> UWeeklyMissionManager::GetCombatWeeklyMission() const
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	TArray<FMissionType> Out;

	for(int32 MissionIndex = 0; MissionIndex < MAX_WEEKLY_MISSION; ++MissionIndex)
	{
		if (!MissionInfo.RUtc.IsValidIndex(MissionIndex))
		{
			continue;
		}

		if (!MissionInfo.M.IsValidIndex(MissionIndex))
		{
			continue;
		}

		if (!MissionInfo.MIng.IsValidIndex(MissionIndex))
		{
			continue;
		}

		if(MissionInfo.RUtc[MissionIndex] > 0)
		{
			continue;
		}

		const FMissionType& Type = MissionInfo.M[MissionIndex];
		const FCMSMissionRow& MissionRow = CMS->GetMissionRowOrDummy(Type);
		if (MissionRow.IsInvalid())
		{
			Q6JsonLogGenie(Error, "no exist mission type", Q6KV("type", Type));
			continue;
		}

		const int32 MaxValue = GetMaxValue(Type);
		if (MissionInfo.MIng[MissionIndex] >= MaxValue)
		{
			continue;
		}

		if (!MissionRow.Combat)
		{
			continue;
		}

		Out.Add(Type);
	}

	return Out;
}

void UWeeklyMissionManager::OnReceiveRewardResp(
	const FResError* Error,
	const FL2CWeeklyMissionReceiveRewardResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_WeeklyMissionRewardResp(Resp);
}

void UWeeklyMissionManager::OnReceiveBingoResp(
	const FResError* Error,
	const FL2CWeeklyMissionReceiveBingoResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_WeeklyMissionBingoResp(Resp);
}

void UWeeklyMissionManager::OnShuffleResp(
	const FResError* Error,
	const FL2CWeeklyMissionShuffleResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_WeeklyMissionShuffleResp(Resp);
}

void UWeeklyMissionManager::OnConfirmResp(const FResError* Error, const FL2CWeeklyMissionLoadResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_WeeklyMissionLoadResp(Resp);
}

void UWeeklyMissionManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, ClearWeeklyMission);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionLoadResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionRewardResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionBingoResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionShuffleResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, CheckInRewardReceiveResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, EventContentValentineDayStageEndResp);

	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, UpdateMission);

	// UI
	REGISTER_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionToast);
}

const int32 UWeeklyMissionManager::GetMaxValue(const FMissionType& Type) const
{
	const FCMSMissionRow& MissionRow = GetCMS()->GetMissionRowOrDummy(Type);
	if (MissionRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist mission type", Q6KV("type", Type));
		return INDEX_NONE;
	}

	return MissionRow.Param1;
}

const bool UWeeklyMissionManager::IsExpiredWeeklyMission() const
{
	FDateTime Now = FDateTime::Now();
	FDateTime Base = FDateTime(Now.GetYear(), 1, 1);

	FTimespan Diff = Now - Base;
	EDayOfWeekType DayOfWeekType = ConvertDayOfWeekType(Base.GetDayOfWeek());
	int32 WeekNum = FMath::CeilToInt(((Diff.GetTotalMilliseconds() / 86400000) + (int32)DayOfWeekType) / 7);
	return MissionInfo.WeekNum != WeekNum;
}

void UWeeklyMissionManager::SetMissionInfo(const FMissionInfo& InMissionInfo)
{
	check(MissionStates.IsValidIndex(0));
	check(MissionStates.IsValidIndex(1));

	MissionStates.Swap(0, 1);
	MissionInfo = InMissionInfo;
	MissionStates[1] = MissionInfo.MIng;

	check(MissionStates[0].Num() == MAX_WEEKLY_MISSION);
	check(MissionStates[1].Num() == MAX_WEEKLY_MISSION);

	for (int32 Index = 0; Index < MAX_WEEKLY_MISSION; ++Index)
	{
		check(MissionInfo.RUtc.IsValidIndex(Index));
		if (MissionInfo.RUtc[Index] > 0)
		{
			continue;
		}

		const int32 BeforeValue = MissionStates[0][Index];
		const int32 CurrValue = MissionStates[1][Index];

		if (BeforeValue == CurrValue)
		{
			continue;
		}

		const FMissionType& Type = MissionInfo.M[Index];

		const int32 MaxValue = GetMaxValue(Type);
		check(MaxValue != INDEX_NONE);

		if (BeforeValue >= MaxValue)
		{
			continue;
		}

		WeeklyMissionToastInfos.Enqueue(FWeeklyMissionToastInfo(Type
			, FMath::Clamp(BeforeValue, 0, MaxValue)
			, FMath::Clamp(CurrValue, 0, MaxValue)
			, MaxValue));
	}
}

void UWeeklyMissionManager::WeeklyMissionToastTimer()
{
	if (!WeeklyMissionToastInfos.IsEmpty())
	{
		ABaseHUD* BaseHUD = GetBaseHUD(GameInstance);
		if (BaseHUD)
		{
			FWeeklyMissionToastInfo Info;
			WeeklyMissionToastInfos.Peek(Info);

			BaseHUD->ShowMissionToast(Info);
			WeeklyMissionToastInfos.Pop();
		}
	}
	else
	{
		if (WeeklyMissionTimerHandle.IsValid()
			&& GameInstance->HasQ6TimerManager())
		{
			GameInstance->GetQ6TimerManager().ClearTimer(WeeklyMissionTimerHandle, true);
		}
	}
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, ClearWeeklyMission)
{
	MissionInfo.MissionId = FMissionId::InvalidValue();
	MissionInfo.WeekNum = 0;
	MissionInfo.ResetCount = 0;

	MissionInfo.M.Empty();
	MissionInfo.MIng.Empty();
	MissionInfo.RUtc.Empty();
	MissionInfo.BUtc.Empty();

	for (int i = 0; i < MAX_WEEKLY_MISSION; ++i)
	{
		MissionInfo.M.Add(MissionTypeInvalid);
		MissionInfo.MIng.Add(0);
		MissionInfo.RUtc.Add(0);
	}

	for (int i = 0; i < MAX_WEEKLY_BINGO; ++i)
	{
		MissionInfo.BUtc.Add(0);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionLoadResp)
{
	auto Action = ACTION_PARSE_WeeklyMissionLoadResp(InAction);
	auto& Res = Action->GetVal();

	MissionInfo = Res.Info;

	MissionStates.Add(MissionInfo.MIng);
	MissionStates.Add(MissionInfo.MIng);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionRewardResp)
{
	auto Action = ACTION_PARSE_WeeklyMissionRewardResp(InAction);
	auto& Res = Action->GetVal();

	MissionInfo = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionBingoResp)
{
	auto Action = ACTION_PARSE_WeeklyMissionBingoResp(InAction);
	auto& Res = Action->GetVal();

	MissionInfo = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionShuffleResp)
{
	auto Action = ACTION_PARSE_WeeklyMissionShuffleResp(InAction);
	auto& Res = Action->GetVal();
	MissionInfo = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	SetMissionInfo(Resp.Mission);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	const auto& Resp = Action->GetVal();

	SetMissionInfo(Resp.Mission);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	SetMissionInfo(Resp.Mission);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, RaidStageEndResp)
{
	const auto& Action = ACTION_PARSE_RaidStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	SetMissionInfo(Resp.Mission);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, CheckInRewardReceiveResp)
{
	const auto& Action = ACTION_PARSE_CheckInRewardReceiveResp(InAction);
	auto& Resp = Action->GetVal();

	SetMissionInfo(Resp.Mission);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	auto& Resp = Action->GetVal();

	SetMissionInfo(Resp.Mission);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	SetMissionInfo(Resp.Mission);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, UpdateMission)
{
	auto Action = ACTION_PARSE_UpdateMission(InAction);
	const auto& Mission = Action->GetVal();

	SetMissionInfo(Mission);

	return false;
}

IMPLEMENT_ACTION_HANDLER(UWeeklyMissionManager, WeeklyMissionToast)
{
	if (!WeeklyMissionToastInfos.IsEmpty())
	{
		if (GameInstance->HasQ6TimerManager())
		{
			FQ6TimerManager& Q6TimeManager = GameInstance->GetQ6TimerManager();
			Q6TimeManager.SetTimer(WeeklyMissionTimerHandle
				, this
				, &UWeeklyMissionManager::WeeklyMissionToastTimer
				, 2.0f
				, true
				, 0.0f);
		}
	}

	return false;
}
