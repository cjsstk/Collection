// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6ClientNetwork.h"
#include "Q6GameInstance.h"
#include "HUDStore.h"
#include "ErrCode_gen.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UHUDStoreBase
UHUDStoreBase::~UHUDStoreBase()
{
}

void UHUDStoreBase::OnError(const FResError* Error) const
{
	if (Error->Body.ErrorCode == Q6_ERROR_SAGA_TIMEOUT)
	{
		check(GameInstance);
		GameInstance->RemoveOngoingChronicleFile();
	}
	GetBaseHUD(GameInstance)->OnError(Error);
}

void UHUDStoreBase::RegisterActionHandler(EHSActionType ActionType, const FOnHSAction& ActionDelegate)
{
	check(GameInstance);
	check(GetStoreType() != EHSType::Invalid);

	GameInstance->GetHUDStore().RegisterActionHandler(GetStoreType(), ActionType, ActionDelegate);
}

void UHUDStoreBase::RegisterNullActionHandler(EHSActionType ActionType)
{
	check(GameInstance);
	check(GetStoreType() != EHSType::Invalid);

	GameInstance->GetHUDStore().RegisterNullActionHandler(GetStoreType(), ActionType);
}
