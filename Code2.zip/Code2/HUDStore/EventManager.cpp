#include "EventManager.h"

#include "CombatCube/CCEvent.h"
#include "ErrCode_gen.h"
#include "HSAction.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6GameInstance.h"
#include "LobbyHUD.h"
#include "Q6SaveGame.h"
#include "CMSTable.h"

void DumpEventSchedule(const FEventScheduleInfo& Info)
{
	const UCMS* CMS = GetCMS();
	if (CMS->IsInfinityEventScheduleFormat(Info))
	{
		Q6JsonLogRoze(Verbose, "",
			Q6KV("eventId", Info.EventId),
			Q6KV("startDate", Q6Util::GetLocalDateTimeText(Info.StartDate).ToString()),
			Q6KV("endDate", Q6Util::GetLocalDateTimeText(Info.EndDate).ToString()));
	}
	else
	{
		Q6JsonLogRoze(Verbose, "",
			Q6KV("eventId", Info.EventId),
			Q6KV("startDate", TEXT("NA")),
			Q6KV("endDate", TEXT("NA")));
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// FEventContentRoulette

FEventContentRoulette::FEventContentRoulette(const FEventContentRoulettePlayConditionInfo& InEventContentRoulettePlayConditionInfo)
	: EventContentRouletteLineUpInfo(InEventContentRoulettePlayConditionInfo.RouletteLineUpInfo)
{
	UpdatePlay(InEventContentRoulettePlayConditionInfo.RouletteInfos, true);
}

const bool FEventContentRoulette::IsSoldOut() const
{
	const TMap<FEventContentRouletteType, FEventContentRouletteInfo>* EventContentRouletteInfos = GetEventContentRouletteInfos(GetLineUp());
	if (!EventContentRouletteInfos)
	{
		return false;
	}

	const int32 LineUpTotalItemCount = GetCMS()->GetEventContentRouletteLineUpTotalItemCount(EventContentRouletteLineUpInfo);
	if (LineUpTotalItemCount <= 0)
	{
		return false;
	}

	int32 PlayCount = 0;
	for (const auto& Iter : *EventContentRouletteInfos)
	{
		const FEventContentRouletteInfo& EventContentRouletteInfo = Iter.Value;
		PlayCount += EventContentRouletteInfo.GetCount;
	}

	return PlayCount >= LineUpTotalItemCount;
}

void FEventContentRoulette::UpdateLineUp(const FEventContentRouletteLineUpInfo& InEventContentRouletteLineUpInfo)
{
	if (EventContentRouletteLineUpInfo.EventContentType == InEventContentRouletteLineUpInfo.EventContentType)
	{
		EventContentRouletteLineUpInfo = InEventContentRouletteLineUpInfo;
	}
}

void FEventContentRoulette::UpdatePlay(const TArray<FEventContentRouletteInfo>& InEventContentRouletteInfos, bool bInitialize)
{
	for (const FEventContentRouletteInfo& Info : InEventContentRouletteInfos)
	{
		if (EventContentRouletteLineUpInfo.EventContentType != Info.EventContentType)
		{
			continue;
		}

		const FCMSEventContentRouletteRow& EventContentRouletteRow = GetCMS()->GetEventContentRouletteRowOrDummy(Info.Type);
		if (EventContentRouletteRow.IsInvalid())
		{
			continue;
		}

		if (!bInitialize && EventContentRouletteLineUpInfo.LineUp != EventContentRouletteRow.LineUp)
		{
			continue;
		}

		int32 LineUp = bInitialize ? EventContentRouletteRow.LineUp : EventContentRouletteLineUpInfo.LineUp;
		TMap<FEventContentRouletteType, FEventContentRouletteInfo>* EventContentRouletteInfos = EventContentRouletteInfosMap.Find(LineUp);
		if (!EventContentRouletteInfos)
		{
			EventContentRouletteInfosMap.Add(LineUp, TMap<FEventContentRouletteType, FEventContentRouletteInfo>({ {Info.Type, Info} }));
		}
		else
		{
			FEventContentRouletteInfo* EventContentRouletteInfo = EventContentRouletteInfos->Find(Info.Type);
			if (!EventContentRouletteInfo)
			{
				EventContentRouletteInfos->Add(Info.Type, Info);
			}
			else
			{
				EventContentRouletteInfo->GetCount += Info.GetCount;
			}
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// UEventManager

UEventManager::UEventManager()
{
	InitStore(EHSType::Event);

	bScheduleChanged = false;
}

UEventManager::~UEventManager()
{
}

const FEventScheduleInfo* UEventManager::GetEventSchedule(int32 EventId) const
{
	for (const auto& Elem : EventSchedules)
	{
		const FEventScheduleInfo& EventSchedule = Elem.Value;
		if (EventSchedule.EventId != EventId)
		{
			continue;
		}

		return &EventSchedule;
	}

	return nullptr;
}

const TArray<FEventContentCategoryInfo>& UEventManager::GetPlayedStages(FEventContentType InContentType) const
{
	const FEventContentInfo* Info = NewEventContentInfos.Find(InContentType);
	return Info->Stages;
}

const int32 UEventManager::GetEventContentNumberOfDays(const FEventContentType& EventContentType) const
{
	const int32* NumberOfDays = EventContentNumberOfDays.Find(EventContentType);

	if (!NumberOfDays)
	{
		return 0;
	}

	return *NumberOfDays;
}

TArray<int32> UEventManager::GetEventPoint(FEventContentType InEventContentType) const
{
	TArray<int32> EventPoints;
	const FEventContentInfo* EventContentInfo = GetEvent(InEventContentType);

	// EventPoint - 1based
	EventPoints.Add(0);
	EventPoints.Add(EventContentInfo->Point1);
	EventPoints.Add(EventContentInfo->Point2);
	EventPoints.Add(EventContentInfo->Point3);
	EventPoints.Add(EventContentInfo->Point4);
	EventPoints.Add(EventContentInfo->Point5);
	EventPoints.Add(EventContentInfo->Point6);

	return EventPoints;
}

bool UEventManager::IsExpired(FEventContentType Type) const
{
	if (Type == EventContentTypeInvalid)
	{
		return true;
	}

	const FCMSEventContentRow& Row = GetCMS()->GetEventContentRowOrDummy(Type);
	const FEventScheduleInfo* ScheduleInfo = GetEventSchedule(Row.EventSchedule);
	if (!ScheduleInfo)
	{
		return true;
	}

	return Q6Util::GetRemainDetailTime(ScheduleInfo->CustomDate2).IsZero();
}

void UEventManager::ReqEventContentList() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentList Out;

	ClientNetwork.WsRequest(TEXT("eventContent/list"), Out,
		TQ6ResponseDelegate<FL2CEventContentListResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentListResp));
}

void UEventManager::ReqEventContentRefreshNumberOfDays(const FEventContentType& EventContentType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentRefreshNumberOfDays Out;
	Out.EventContentType = EventContentType;

	ClientNetwork.WsRequest(TEXT("eventContent/refreshNumberOfDays"), Out,
		TQ6ResponseDelegate<FL2CEventContentRefreshNumberOfDaysResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentRefreshNumberOfDaysResp));
}

void UEventManager::ReqEventContentRoulettePlay(const FEventContentType& EventContentType, const int32& PlayCount) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentRoulettePlay Out;
	Out.EventContentType = EventContentType;
	Out.PlayCount = PlayCount;

	ClientNetwork.WsRequest(TEXT("eventContent/roulettePlay"), Out,
		TQ6ResponseDelegate<FL2CEventContentRoulettePlayResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentRoulettePlayResp));
}

void UEventManager::ReqEventContentRouletteReset(const FEventContentType& EventContentType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentRouletteReset Out;

	ClientNetwork.WsRequest(TEXT("eventContent/rouletteReset"), Out,
		TQ6ResponseDelegate<FL2CEventContentRouletteResetResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentRouletteResetResp));
}

void UEventManager::ReqEventContentCollabo01StageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LEventContentCollabo01StageBegin Out;

	FEventContentCollabo01Type EventContentCollabo01Type;
	//EventContentCollabo01Type = GetCMS()->GetEventContentCollabo01Type(CombatSeed.SagaType);
	//if (EventContentCollabo01Type == EventContentCollabo01TypeInvalid)
	//{
	//	Q6JsonLogGunny(Warning, "UEventManager::ReqEventContentCollabo01StageBegin - EventContentCollabo01Type does not exist.",
	//		Q6KV("SagaType", CombatSeed.SagaType));
	//	return;
	//}

	Out.EventContentCollabo01Type = EventContentCollabo01Type;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("eventContentCollabo01/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CEventContentCollabo01StageBeginResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentCollabo01StageBeginResp));
}

void UEventManager::ReqEventContentCollabo01StageEnd(const UCCEndGameEvent* Event
	, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	FC2LEventContentCollabo01StageEnd Out;

	FEventContentCollabo01Type EventContentCollabo01Type;
	//EventContentCollabo01Type = GetCMS()->GetEventContentCollabo01Type(CombatSeed.SagaType);
	//if (EventContentCollabo01Type == EventContentCollabo01TypeInvalid)
	//{
	//	Q6JsonLogGunny(Warning, "UEventManager::ReqEventContentCollabo01StageEnd - EventContentCollabo01Type does not exist.",
	//		Q6KV("SagaType", CombatSeed.SagaType));
	//	return;
	//}

	Out.EventContentCollabo01Type = EventContentCollabo01Type;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.Result = static_cast<int32>(Event->Result);
	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;
	Out.Mission = CombatMissionInfo.WeeklyCombatMissionInfo;
	Out.CharMission = CombatMissionInfo.CharCombatMissionInfo;

	ClientNetwork.WsRequest("eventContentCollabo01/stageEnd", Out,
		TQ6ResponseDelegate<FL2CEventContentCollabo01StageEndResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentCollabo01StageEndResp));
}

void UEventManager::ReqEventContentCollabo01StoryStageClear(const FEventContentCollabo01Type& EventContentCollabo01Type, const FSagaType& SagaType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentCollabo01StoryStageClear Out;
	Out.EventContentCollabo01Type = EventContentCollabo01Type;
	Out.SagaType = SagaType;

	ClientNetwork.WsRequest(TEXT("eventContentCollabo01/storyStageClear"), Out,
		TQ6ResponseDelegate<FL2CEventContentCollabo01StoryStageClearResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentCollabo01StoryStageClearResp));
}

void UEventManager::ReqEventContentValentineDayStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LEventContentValentineDayStageBegin Out;

	FEventContentValentineDayType EventContentValentineDayType ;
	EventContentValentineDayType = GetCMS()->GetEventContentValentineDayType(CombatSeed.SagaType);
	if (EventContentValentineDayType == EventContentValentineDayTypeInvalid)
	{
		Q6JsonLogGunny(Warning, "UEventManager::ReqEventContentValentineDayStageBegin - EventContentValentineDayType does not exist.",
			Q6KV("SagaType", CombatSeed.SagaType));
		return;
	}

	Out.EventContentValentineDayType = EventContentValentineDayType;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("eventContentValentineDay/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CEventContentValentineDayStageBeginResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentValentineDayStageBeginResp));
}

void UEventManager::ReqEventContentValentineDayStageEnd(const UCCEndGameEvent* Event
	, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	FC2LEventContentValentineDayStageEnd Out;

	FEventContentValentineDayType EventContentValentineDayType;
	EventContentValentineDayType = GetCMS()->GetEventContentValentineDayType(CombatSeed.SagaType);
	if (EventContentValentineDayType == EventContentValentineDayTypeInvalid)
	{
		Q6JsonLogGunny(Warning, "UEventManager::ReqEventContentValentineDayStageEnd - EventContentValentineDayType does not exist.",
			Q6KV("SagaType", CombatSeed.SagaType));
		return;
	}

	Out.EventContentValentineDayType = EventContentValentineDayType;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.Result = static_cast<int32>(Event->Result);
	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;
	Out.Mission = CombatMissionInfo.WeeklyCombatMissionInfo;
	Out.CharMission = CombatMissionInfo.CharCombatMissionInfo;

	ClientNetwork.WsRequest("eventContentValentineDay/stageEnd", Out,
		TQ6ResponseDelegate<FL2CEventContentValentineDayStageEndResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentValentineDayStageEndResp));
}

void UEventManager::ReqEventContentValentineDayStoryStageClear(const FEventContentValentineDayType& EventContentValentineDayType, const FSagaType& SagaType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentValentineDayStoryStageClear Out;
	Out.EventContentValentineDayType = EventContentValentineDayType;
	Out.SagaType = SagaType;

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance))
	{
		LobbyHUD->ChangeHUDType(EHUDWidgetType::Dialogue);
	}

	ClientNetwork.WsRequest(TEXT("eventContentValentineDay/storyStageClear"), Out,
		TQ6ResponseDelegate<FL2CEventContentValentineDayStoryStageClearResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentValentineDayStoryStageClearResp));
}

void UEventManager::ReqEventContentMultiSideBattleStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();

	const UQ6SaveGame* SaveGame = GameInstance->GetSaveGame();
	const FPartyInfo& PartyInfo = SaveGame->GetMultisidePartyInfo();

	FEventContentMultiSideBattleStageType StageType = GetCMS()->GetEventContentMultiSideBattleStageType(CombatSeed.SagaType);
	if (StageType == EventContentMultiSideBattleStageTypeInvalid)
	{
		Q6JsonLogGunny(Warning, "UEventManager::ReqEventContentMultiSideBattleStageBegin - EventContentMultiSideBattleStageType does not exist.",
			Q6KV("SagaType", CombatSeed.SagaType));
		return;
	}

	FC2LEventContentMultiSideBattleStageBegin Out;
	Out.Type = StageType;
	Out.PetId = PartyInfo.PetId;
	Out.MainParty = PartyInfo.Main;
	Out.SubParty = PartyInfo.Sub;

	ClientNetwork.WsRequest(TEXT("eventContentMultiSideBattle/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CEventContentMultiSideBattleStageBeginResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentMultiSideBattleStageBeginResp));
}

void UEventManager::ReqEventContentMultiSideBattleStageEnd(const UCCEndGameEvent* Event, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo, int32 FinalRankScore) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();

	FEventContentMultiSideBattleStageType StageType = GetCMS()->GetEventContentMultiSideBattleStageType(CombatSeed.SagaType);
	if (StageType == EventContentMultiSideBattleStageTypeInvalid)
	{
		Q6JsonLogGunny(Warning, "UEventManager::ReqEventContentMultiSideBattleStageEnd - EventContentMultiSideBattleStageType does not exist.",
			Q6KV("SagaType", CombatSeed.SagaType));
		return;
	}

	FC2LEventContentMultiSideBattleStageEnd Out;
	Out.Type = StageType;
	Out.Result = static_cast<int32>(Event->Result);
	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;
	Out.Mission = CombatMissionInfo.WeeklyCombatMissionInfo;
	Out.CharMission = CombatMissionInfo.CharCombatMissionInfo;
	Out.BonusEventContentPointAmount = FinalRankScore;

	ClientNetwork.WsRequest("eventContentMultiSideBattle/stageEnd", Out,
		TQ6ResponseDelegate<FL2CEventContentMultiSideBattleStageEndResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentMultiSideBattleStageEndResp));
}

void UEventManager::ReqEventContentMultiSideBattleStoryStageClear(const FEventContentMultiSideBattleStageType& StageType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentMultiSideBattleStoryStageClear Out;
	Out.Type = StageType;

	ClientNetwork.WsRequest("eventContentMultiSideBattle/storyStageClear", Out,
		TQ6ResponseDelegate<FL2CEventContentMultiSideBattleStoryStageClearResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentMultiSideBattleStoryStageClearResp));
}

void UEventManager::ReqEventContentMultisideBattleRankLoad(FEventContentType EventContentType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentMultiSideBattleLoad Out;
	Out.Type = EventContentType;

	ClientNetwork.WsRequest(TEXT("eventContentMultiSideBattle/load"), Out,
		TQ6ResponseDelegate<FL2CEventContentMultiSideBattleLoadResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentMultiSideBattleRankLoadResp));
}

void UEventManager::ReqEventContentMultiSideBattleReceiveRankReward(FEventContentType InEventContentType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventContentMultiSideBattleReceiveRankReward Out;
	Out.Type = InEventContentType;

	ClientNetwork.WsRequest(TEXT("eventContentMultiSideBattle/receiveRankReward"), Out,
		TQ6ResponseDelegate<FL2CEventContentMultiSideBattleReceiveRankRewardResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentMultiSideBattleReceiveRankRewardResp));
}

#if !UE_BUILD_SHIPPING
void UEventManager::ReqDevEventContentValentineDayStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LDevEventContentValentineDayStageBegin Out;

	FEventContentValentineDayType EventContentValentineDayType;
	EventContentValentineDayType = GetCMS()->GetEventContentValentineDayType(CombatSeed.SagaType);
	if (EventContentValentineDayType == EventContentValentineDayTypeInvalid)
	{
		Q6JsonLogRoze(Warning, "UEventManager::ReqDevEventContentValentineDayStageBegin - EventContentValentineDayType does not exist.",
			Q6KV("SagaType", CombatSeed.SagaType));
		return;
	}

	Out.EventContentValentineDayType = EventContentValentineDayType;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("dev/eventContentValentineDayStageBegin"), Out,
		TQ6ResponseDelegate<FL2CEventContentValentineDayStageBeginResp>::CreateUObject(
			const_cast<UEventManager*>(this), &UEventManager::OnEventContentValentineDayStageBeginResp));
}
#endif

void UEventManager::OnEventContentListResp(const FResError* Error, const FL2CEventContentListResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_EventContentListResp(Res);
	GameInstance->ReqNextContent();
}

void UEventManager::OnEventContentRefreshNumberOfDaysResp(const FResError* Error, const FL2CEventContentRefreshNumberOfDaysResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_EventContentRefreshNumberOfDaysResp(Res);
}

void UEventManager::OnEventContentRoulettePlayResp(const FResError* Error, const FL2CEventContentRoulettePlayResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_EventContentRoulettePlayResp(Res);
}

void UEventManager::OnEventContentRouletteResetResp(const FResError* Error, const FL2CEventContentRouletteResetResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_EventContentRouletteResetResp(Res);
}

void UEventManager::OnEventContentCollabo01StageBeginResp(const FResError* Error, const FL2CEventContentCollabo01StageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnEventContentCollabo01StageBegin(Res);
}

void UEventManager::OnEventContentCollabo01StageEndResp(const FResError* Error, const FL2CEventContentCollabo01StageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnEventContentCollabo01StageEnd(Res);
}

void UEventManager::OnEventContentCollabo01StoryStageClearResp(const FResError* Error, const FL2CEventContentCollabo01StoryStageClearResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ClearDialogueRecord();
		return;
	}

	ACTION_DISPATCH_EventContentCollabo01StoryStageClearResp(Res);

	if (ALobbyHUD* Lobby = GetLobbyHUD(GameInstance))
	{
		Lobby->OnStoryStageClear();
	}
}

void UEventManager::OnEventContentValentineDayStageBeginResp(const FResError* Error, const FL2CEventContentValentineDayStageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnEventContentValentineDayStageBegin(Res);
}

void UEventManager::OnEventContentValentineDayStageEndResp(const FResError* Error, const FL2CEventContentValentineDayStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnEventContentValentineDayStageEnd(Res);
}

void UEventManager::OnEventContentValentineDayStoryStageClearResp(const FResError* Error, const FL2CEventContentValentineDayStoryStageClearResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_EventContentValentineDayStoryStageClearResp(Res);

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance))
	{
		LobbyHUD->OnStoryStageClear();
	}
}

void UEventManager::OnEventContentMultiSideBattleStageBeginResp(const FResError* Error, const FL2CEventContentMultiSideBattleStageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnEventContentMultiSideBattleStageBegin(Res);
}

void UEventManager::OnEventContentMultiSideBattleStageEndResp(const FResError* Error, const FL2CEventContentMultiSideBattleStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnEventContentMultiSideBattleStageEnd(Res);
}

void UEventManager::OnEventContentMultiSideBattleStoryStageClearResp(const FResError* Error, const FL2CEventContentMultiSideBattleStoryStageClearResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_EventContentMultiSideBattleStoryStageClearResp(Res);

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance))
	{
		LobbyHUD->OnStoryStageClear();
	}
}

void UEventManager::OnEventContentMultiSideBattleRankLoadResp(const FResError* Error, const FL2CEventContentMultiSideBattleLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_EventContentMultiSideBattleRankLoadResp(Res);
}

void UEventManager::OnEventContentMultiSideBattleReceiveRankRewardResp(const FResError* Error, const FL2CEventContentMultiSideBattleReceiveRankRewardResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_EventContentMultisideBattleReceiveRankRewardResp(Res);
}

void UEventManager::UpdateEventContentNumberOfDays(const FEventContentType& InEventContentType, const int32& InEventContentNumberOfDays)
{
	EventContentNumberOfDays.Add(InEventContentType, InEventContentNumberOfDays);
}

void UEventManager::UpdateEventContentRoulettePlay(const TArray<FEventContentRoulettePlayConditionInfo>& InEventContentRoulettePlayConditionInfos)
{
	for (const auto& PlayConditionInfo : InEventContentRoulettePlayConditionInfos)
	{
		EventContentRouletteInfos.Add(PlayConditionInfo.RouletteLineUpInfo.EventContentType, FEventContentRoulette(PlayConditionInfo));
	}
}

void UEventManager::UpdateEventContentRoulettePlay(const FEventContentType& InEventContentType, const TArray<FEventContentRouletteInfo>& InEventContentRouletteInfos)
{
	FEventContentRoulette* EventContentRoulette = EventContentRouletteInfos.Find(InEventContentType);
	if (!EventContentRoulette)
	{
		FEventContentRoulettePlayConditionInfo EventContentRoulettePlayConditionInfo;
		EventContentRoulettePlayConditionInfo.RouletteLineUpInfo.EventContentType = InEventContentType;
		EventContentRoulettePlayConditionInfo.RouletteLineUpInfo.LineUp = 1;
		EventContentRoulettePlayConditionInfo.RouletteInfos = InEventContentRouletteInfos;

		UpdateEventContentRoulettePlay(TArray<FEventContentRoulettePlayConditionInfo>({ EventContentRoulettePlayConditionInfo }));
	}
	else
	{
		EventContentRoulette->UpdatePlay(InEventContentRouletteInfos, false);
	}

	EventContentRoulettePlayResultInfos = InEventContentRouletteInfos;

	if (EventContentRoulette->IsSoldOut())
	{
		ReqEventContentRouletteReset(InEventContentType);
	}
}

void UEventManager::UpdateEventContentRouletteReset(const FEventContentRouletteLineUpInfo& InEventContentRouletteLineUpInfo)
{
	FEventContentRoulette* EventContentRoulette = EventContentRouletteInfos.Find(InEventContentRouletteLineUpInfo.EventContentType);
	if (EventContentRoulette)
	{
		EventContentRoulette->UpdateLineUp(InEventContentRouletteLineUpInfo);
	}
}

void UEventManager::UpdateEventContentInfo(const FEventContentInfo& InEventContentInfo)
{
	FEventContentInfo* EventContentInfo = NewEventContentInfos.Find(InEventContentInfo.Type);
	if (!EventContentInfo)
	{
		NewEventContentInfos.Add(InEventContentInfo.Type, InEventContentInfo);
	}
	else
	{
		EventContentInfo->State = InEventContentInfo.State;
		EventContentInfo->Point1 = InEventContentInfo.Point1;
		EventContentInfo->Point2 = InEventContentInfo.Point2;
		EventContentInfo->Point3 = InEventContentInfo.Point3;
		EventContentInfo->Point4 = InEventContentInfo.Point4;
		EventContentInfo->Point5 = InEventContentInfo.Point5;
		EventContentInfo->Point6 = InEventContentInfo.Point6;
		EventContentInfo->WattInfo = InEventContentInfo.WattInfo;
		EventContentInfo->Stages = InEventContentInfo.Stages;
		EventContentInfo->MultiSideBattleInfo = InEventContentInfo.MultiSideBattleInfo;
	}
}

void UEventManager::UpdateMultisideBattleInfo(const FEventContentMultiSideBattleInfo& InMultisideBattleInfo)
{
	for (auto& Iter : NewEventContentInfos)
	{
		const FEventContentMultiSideBattleInfo& MultisideInfo = Iter.Value.MultiSideBattleInfo;
		if (MultisideInfo.Id == InMultisideBattleInfo.Id)
		{
			Iter.Value.MultiSideBattleInfo = InMultisideBattleInfo;
			return;
		}
	}
}

bool UEventManager::HasPlayableMultiside() const
{
	const UCMS* CMS = GetCMS();
	for (const auto& Iter : NewEventContentInfos)
	{
		const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(Iter.Key);
		if (EventContentRow.Category != EEventContentCategory::MultiSideBattle)
		{
			continue;
		}

		if (Iter.Value.State == EEventContentState::Play)
		{
			return true;
		}
	}

	return false;
}

/////////////////////////////////////////////////////////////////////////////
// Event HUDStore Action

void UEventManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UEventManager, CheckInRewardReceiveResp);
	REGISTER_ACTION_HANDLER(UEventManager, SummonBoxScheduleResp);
	REGISTER_ACTION_HANDLER(UEventManager, ShopSaleScheduleResp);
	REGISTER_ACTION_HANDLER(UEventManager, ContentsResetTime);
	REGISTER_ACTION_HANDLER(UEventManager, ShopListResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentListResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentRefreshNumberOfDaysResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentRoulettePlayResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentRouletteResetResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UEventManager, DevEventContentNumberOfDaysResp);
	REGISTER_ACTION_HANDLER(UEventManager, DevEventContentAddPointResp);
	REGISTER_ACTION_HANDLER(UEventManager, DevEventContentRechargeWattResp);
	REGISTER_ACTION_HANDLER(UEventManager, DevEventContentRouletteResetResp);
	REGISTER_ACTION_HANDLER(UEventManager, ShopBuyItemResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentMultisideBattleReceiveRankRewardResp);
	REGISTER_ACTION_HANDLER(UEventManager, EventContentMultiSideBattleRankLoadResp);
}

void UEventManager::InitEventSchedules(const TArray<FEventScheduleInfo>& EventScheduleArray)
{
	EventSchedules.Reset();
	for (const FEventScheduleInfo& EventSchedule : EventScheduleArray)
	{
		EventSchedules.Add(EventSchedule.EventId, EventSchedule);
	}
}

IMPLEMENT_ACTION_HANDLER(UEventManager, SummonBoxScheduleResp)
{
	auto Action = ACTION_PARSE_SummonBoxScheduleResp(InAction);
	auto& Res = Action->GetVal();

	EventSchedules.Reset();
	InitEventSchedules(Res.ScheduleInfos);

	bScheduleChanged = false;

	return false;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, CheckInRewardReceiveResp)
{
	const auto Action = ACTION_PARSE_CheckInRewardReceiveResp(InAction);
	const FL2CCheckInRewardReceiveResp& Res = Action->GetVal();

	EventSchedules.Reset();
	InitEventSchedules(Res.EventSchedules);

	bScheduleChanged = false;

	return false;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, ShopSaleScheduleResp)
{
	auto Action = ACTION_PARSE_ShopSaleScheduleResp(InAction);
	auto& Res = Action->GetVal();

	EventSchedules.Reset();
	InitEventSchedules(Res.ScheduleInfos);

	bScheduleChanged = false;

	return false;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, ContentsResetTime)
{
	bScheduleChanged = true;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, ShopListResp)
{
	auto Action = ACTION_PARSE_ShopListResp(InAction);
	auto& Res = Action->GetVal();

	EventSchedules.Reset();
	InitEventSchedules(Res.ScheduleInfos);

	bScheduleChanged = false;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentListResp)
{
	auto Action = ACTION_PARSE_EventContentListResp(InAction);

	auto& Resp = Action->GetVal();

	for (const FEventContentInfo& Iter : Resp.Infos)
	{
		UpdateEventContentInfo(Iter);
	}

	if (!HasPlayableMultiside())
	{
		UQ6SaveGame* SaveGame = GameInstance->GetSaveGame();
		SaveGame->ResetMultisidePartyInfo();
	}

	UpdateEventContentRoulettePlay(Resp.RoulettePlayConditionInfos);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentRefreshNumberOfDaysResp)
{
	auto Action = ACTION_PARSE_EventContentRefreshNumberOfDaysResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentNumberOfDays(Resp.EventContentType, Resp.EventContentNumberOfDays);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentRoulettePlayResp)
{
	auto Action = ACTION_PARSE_EventContentRoulettePlayResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentRoulettePlay(Resp.EventContentType, Resp.PlayResultInfos);
	UpdateEventContentInfo(Resp.EventContentInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentRouletteResetResp)
{
	auto Action = ACTION_PARSE_EventContentRouletteResetResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentRouletteReset(Resp.RouletteLineUpInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentInfo(Resp.EventContentInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentInfo(Resp.EventContentInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentInfo(Resp.EventContentInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentInfo(Resp.EventContentInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentInfo(Resp.EventContentInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, DevEventContentNumberOfDaysResp)
{
	auto Action = ACTION_PARSE_DevEventContentNumberOfDaysResp(InAction);
	auto& Resp = Action->GetVal();

	TArray<FEventContentType> EventContentTypes;
	EventContentNumberOfDays.GetKeys(EventContentTypes);
	for (const auto& EventContentType : EventContentTypes)
	{
		UpdateEventContentNumberOfDays(EventContentType, Resp.EventContentNumberOfDays);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, DevEventContentAddPointResp)
{
	auto Action = ACTION_PARSE_DevEventContentAddPointResp(InAction);
	auto& Resp = Action->GetVal();

	if (!Resp.EventContentInfo.Id.IsInvalid())
	{
		UpdateEventContentInfo(Resp.EventContentInfo);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, DevEventContentRechargeWattResp)
{
	auto Action = ACTION_PARSE_DevEventContentRechargeWattResp(InAction);
	auto& Resp = Action->GetVal();

	if (!Resp.EventContentInfo.Id.IsInvalid())
	{
		UpdateEventContentInfo(Resp.EventContentInfo);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, DevEventContentRouletteResetResp)
{
	auto Action = ACTION_PARSE_DevEventContentRouletteResetResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentRouletteReset(Resp.RouletteLineUpInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, ShopBuyItemResp)
{
	auto Action = ACTION_PARSE_ShopBuyItemResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentInfo(Resp.EventContentInfo);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateEventContentInfo(Resp.EventContentInfo);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateMultisideBattleInfo(Resp.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UEventManager, EventContentMultiSideBattleRankLoadResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleRankLoadResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateMultisideBattleInfo(Resp.Info);
	return true;
}
