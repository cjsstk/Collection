#pragma once

#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "TrainingCenterManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FRewardInfo;
struct FCombatMissionInfo;
class UCCEndGameEvent;

///////////////////////////////////////////////////////////////////////////////////////////
// UTrainingCenterManager
UCLASS()
class Q6_API UTrainingCenterManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UTrainingCenterManager();

	// Req
	void ReqTrainingCenterHistory(bool bEnterLobby = true) const;
	void ReqStageBegin() const;
	void ReqStageEnd(const UCCEndGameEvent* Event
		, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const;

#if !UE_BUILD_SHIPPING
	void ReqDevStageBegin() const;
#endif

	// Getter
	const FTrainingCenterRecord& GetHistory() const { return History; }

	bool IsCleared() const;
	bool IsLastStep(FTrainingCenterType Type) const;
	bool IsHistoryExpired() const;
	bool IsFirstSaga(FTrainingCenterType Type, FSagaType SagaType) const;
	bool IsLastSaga(FTrainingCenterType Type, FSagaType SagaType) const;
	bool IsFirstSagaOnStep(FSagaType SagaType) const;
	bool IsLastSagaOnStep(FSagaType SagaType) const;

	ETrainingStepState GetTrainingStepState(FTrainingCenterType InType) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnTrainingCenterLoadResp(const FResError* Error, const FL2CTrainingCenterLoadResp& Res, bool bEnterLobby);
	void OnStageBeginResp(const FResError* Error, const FL2CTrainingCenterStageBeginResp& Res);
	void OnStageEndResp(const FResError* Error, const FL2CTrainingCenterStageEndResp& Res);

	// On Actions
	DECLARE_ACTION_HANDLER(TrainingCenterLoadResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterResetResp);

private:
	void UpdateTrainingCenterHistory(const FTrainingCenterRecord& NewHistory);

	UPROPERTY()
	FTrainingCenterRecord History;
};
