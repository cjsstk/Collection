#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "CodexManager.generated.h"

UCLASS()
class Q6_API UCodexManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UCodexManager();

	void ReqListChar(int32 PageNo = 0) const;
	void ReqListSculpture(int32 PageNo = 0) const;
	void ReqListRelic(int32 PageNo = 0) const;
	void ReqClearNewChar(FCodexCharId Id) const;
	void ReqClearNewSculpture(FCodexSculptureId Id) const;
	void ReqClearNewRelic(FCodexRelicId Id) const;
	void ReqClearNewCharacterAll(const TArray<FCodexCharId>& Ids) const;
	void ReqClearNewSculptureAll(const TArray<FCodexSculptureId>& Ids) const;
	void ReqClearNewRelicAll(const TArray<FCodexRelicId>& Ids) const;

	void OnListCharResp(const FResError* Error, const FL2CCodexListCharResp& Resp);
	void OnListSculptureResp(const FResError* Error, const FL2CCodexListSculptureResp& Resp);
	void OnListRelicResp(const FResError* Error, const FL2CCodexListRelicResp& Resp);
	void OnClearNewCharResp(const FResError* Error, const FL2CCodexClearNewCharResp& Resp);
	void OnClearNewSculptureResp(const FResError* Error, const FL2CCodexClearNewSculptureResp& Resp);
	void OnClearNewRelicResp(const FResError* Error, const FL2CCodexClearNewRelicResp& Resp);
	void OnClearNewAllResp(const FResError* Error, const FL2CCodexClearNewAllResp& Resp);

	const FCodexCharInfo* FindChar(const FCharacterType& Type) const;
	const FCodexSculptureInfo* FindSculpture(const FSculptureType& Type) const;
	const FCodexRelicInfo* FindRelic(const FRelicType& Type) const;

	TArray<const FCMSCharacterRow*> GetCodexCharacterRows() const;
	TArray<const FCMSSculptureRow*> GetCodexSculptureRows() const;
	TArray<const FCMSRelicRow*> GetCodexRelicRows() const;

	const TMap<FCharacterType, FCodexCharInfo>& GetCodexChars() const { return Chars; }
	const TMap<FSculptureType, FCodexSculptureInfo>& GetCodexSculptures() const { return Sculptures; }
	const TMap<FRelicType, FCodexRelicInfo>& GetCodexRelics() const { return Relics; }

	void Dump() const;

protected:
	virtual void RegisterActionHandlers() override;

	DECLARE_ACTION_HANDLER(ClearCodexChar);
	DECLARE_ACTION_HANDLER(ClearCodexSculpture);
	DECLARE_ACTION_HANDLER(ClearCodexRelic);
	DECLARE_ACTION_HANDLER(CodexListCharResp);
	DECLARE_ACTION_HANDLER(CodexListSculptureResp);
	DECLARE_ACTION_HANDLER(CodexListRelicResp);
	DECLARE_ACTION_HANDLER(CodexClearNewCharResp);
	DECLARE_ACTION_HANDLER(CodexClearNewSculptureResp);
	DECLARE_ACTION_HANDLER(CodexClearNewRelicResp);
	DECLARE_ACTION_HANDLER(CodexClearNewAllResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(SummonPickupResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(VacationEndResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(CharacterUnbindResp);

	// UI
	DECLARE_ACTION_HANDLER(CodexClearCharNew);
	DECLARE_ACTION_HANDLER(CodexClearSculptureNew);
	DECLARE_ACTION_HANDLER(CodexClearRelicNew);

	// Cheater
	DECLARE_ACTION_HANDLER(DevCharacterNewResp);
	DECLARE_ACTION_HANDLER(DevRelicNewResp);
	DECLARE_ACTION_HANDLER(DevSculptureNewResp);
	DECLARE_ACTION_HANDLER(DevAvatarAddResp);

	void DumpChar() const;
	void DumpSculpture() const;
	void DumpRelic() const;

private:
	TMap<FCharacterType, FCodexCharInfo> Chars;
	TMap<FSculptureType, FCodexSculptureInfo> Sculptures;
	TMap<FRelicType, FCodexRelicInfo> Relics;
};
