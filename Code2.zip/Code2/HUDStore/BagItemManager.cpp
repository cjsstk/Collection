#include "BagItemManager.h"
#include "HSAction.h"
#include "Q6.h"
#include "Q6GameInstance.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Static Functions

void DefaultBagItemInfo(FBagItemInfo * Info)
{
	Info->BagItemId = FBagItemId::InvalidValue();;
	Info->UserId = FUserId();
	Info->Type = BagItemTypeInvalid;
	Info->StackSize = 0;
	Info->Newly = 0;
	Info->Created = 0;
}

void DumpBagItem(const FBagItemInfo& Info)
{
	Q6JsonLogHekel(Verbose, "",
		Q6KV("Id", Info.BagItemId),
		Q6KV("User", Info.UserId),
		Q6KV("Type", Info.Type),
		Q6KV("StackSize", Info.StackSize),
		Q6KV("Newly", Info.Newly),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));
}

///////////////////////////////////////////////////////////////////////////////////////////
// FBagItem

FBagItem::FBagItem(const FBagItemInfo & InInfo)
{
	Info = InInfo;
}

void FBagItem::Update(const FBagItemInfo& InInfo)
{
	Info = InInfo;
}

///////////////////////////////////////////////////////////////////////////////////////////
// UBagItemManager

UBagItemManager::UBagItemManager()
{
	InitStore(EHSType::BagItem);

	bSorted = false;
}

void UBagItemManager::Dump() const
{
	Q6JsonLogHekel(Verbose, "== BagItems ==",
		Q6KV("Total", BagItems.Num()));
	for (const auto& Item : BagItems)
	{
		const FBagItem& BagItem = Item.Value;
		DumpBagItem(BagItem.GetInfo());
	}
}

void UBagItemManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearBag();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LBagItemList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("bagItem/list"), Out,
		TQ6ResponseDelegate<FL2CBagItemListResp>::CreateUObject(
			const_cast<UBagItemManager*>(this), &UBagItemManager::OnListResp));
}

void UBagItemManager::OnListResp(const FResError* Error, const FL2CBagItemListResp& Msg)
{
	Q6JsonLogHekel(Warning, "list resp");

	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ACTION_DISPATCH_BagItemListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		// TODO: refresh UI, list finished
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void UBagItemManager::OnLoadResp(const FResError* Error, const FL2CBagItemLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	// load, clearNew, setLock
	ACTION_DISPATCH_BagItemLoadResp(Msg);
}

void UBagItemManager::ReqClearNew(const FBagItemId& Id) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LBagItemClearNew Out;
	Out.BagItemId = Id;

	ClientNetwork.WsRequest(TEXT("bagItem/clearNew"), Out,
		TQ6ResponseDelegate<FL2CBagItemLoadResp>::CreateUObject(
			const_cast<UBagItemManager*>(this), &UBagItemManager::OnLoadResp));
}

const FBagItem* const UBagItemManager::Find(int64 Id) const
{
	return BagItems.Find(Id);
}

const int32 UBagItemManager::GetBagItemCount(FBagItemType ItemType) const
{
	for (const auto& Elem : BagItems)
	{
		const FBagItemInfo& BagItemInfo = Elem.Value.GetInfo();
		if (BagItemInfo.Type != ItemType)
		{
			continue;
		}

		return BagItemInfo.StackSize;
	}

	return 0;
}

bool UBagItemManager::HasEnoughBagItem(const FBagItemType& ItemType, int32 RequireCount) const
{
	int32 ItemCount = GetBagItemCount(ItemType);
	if (ItemCount < RequireCount)
	{
		return false;
	}

	return true;
}

bool UBagItemManager::HasEnoughBagItem(const TArray<const FCMSBagItemRow*>& InBagItems, const TArray<int32>& RequireCounts) const
{
	check(InBagItems.Num() <= RequireCounts.Num());

	for (int32 i = 0; i < InBagItems.Num(); ++i)
	{
		check(InBagItems[i]);

		if (!HasEnoughBagItem(InBagItems[i]->CmsType(), RequireCounts[i]))
		{
			return false;
		}
	}

	return true;
}

/////////////////////////////////////////////////////////////////////////////
// UBagItemManager Setter

bool UBagItemManager::AddBagItem(const FBagItemInfo& Info)
{
	BagItems.Add(Info.BagItemId, Info);
	return true;
}

bool UBagItemManager::RemoveBagItem(int64 Id)
{
	return (BagItems.Remove(Id) > 0);
}

bool UBagItemManager::UpdateBagItem(const FBagItemInfo& Info)
{
	if (Info.StackSize <= 0)
	{
		return (BagItems.Remove(Info.BagItemId) > 0);
	}

	BagItems.Add(Info.BagItemId, Info);
	return true;
}

bool UBagItemManager::UpdateBagItems(const TArray<FBagItemInfo>& InBagItems)
{
	bool Ret = false;
	for (const FBagItemInfo& Info : InBagItems)
	{
		Ret |= UpdateBagItem(Info);
	}

	bSorted = false;
	return Ret;
}

void UBagItemManager::SortBagItems()
{
	if (bSorted)
	{
		return;
	}

	const UCMS* CMS = GetCMS();
	BagItems.ValueSort([CMS](const FBagItem& BagItemA, const FBagItem& BagItemB)
	{
		const FBagItemInfo& BagItemInfoA = BagItemA.GetInfo();
		const FBagItemInfo& BagItemInfoB = BagItemB.GetInfo();

		const FCMSBagItemRow& BagItemARow = CMS->GetBagItemRowOrDummy(BagItemInfoA.Type);
		const FCMSBagItemRow& BagItemBRow = CMS->GetBagItemRowOrDummy(BagItemInfoB.Type);

		if (BagItemARow.Category == BagItemBRow.Category)
		{
			if (BagItemARow.Grade == BagItemBRow.Grade)
			{
				if (BagItemARow.Type == BagItemBRow.Type)
				{
					return BagItemInfoA.StackSize > BagItemInfoB.StackSize;
				}

				return BagItemARow.Type < BagItemBRow.Type;
			}

			return BagItemARow.Grade < BagItemBRow.Grade;
		}

		return BagItemARow.Category < BagItemBRow.Category;
	});

	bSorted = true;
}

/////////////////////////////////////////////////////////////////////////////
// UBagItemManager HUDStore Action

void UBagItemManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UBagItemManager, ClearBag);
	REGISTER_ACTION_HANDLER(UBagItemManager, BagItemLoadResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, BagItemListResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, BagItemRemoveResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, CharacterPromoteResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, CharacterUnbindResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, CharacterEvoluteResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, CharacterTurnSkillLevelResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, RelicPromoteResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SculpturePromoteResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, PyramidUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, PyramidPortalBoostUseResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, PowerPlantUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, DevTrainingCenterClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, VacationUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, VacationStartResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, PetSkillUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, PetParkUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, TempleUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, TempleArtifactUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, TempleArtifactBoostResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, ShopBuyItemResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, BagItemSort);
	REGISTER_ACTION_HANDLER(UBagItemManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, EventContentMultisideBattleReceiveRankRewardResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SmelterIncStockResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SmelterDecStockResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SmelterReceiveResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, SmelterUpgradeResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, AlchemylabIncStockResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, AlchemylabDecStockResp);
	REGISTER_ACTION_HANDLER(UBagItemManager, AlchemylabUpgradeResp);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, ClearBag)
{
	BagItems.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, BagItemLoadResp)
{
	auto Action = ACTION_PARSE_BagItemLoadResp(InAction);

	auto& Res = Action->GetVal();

	bSorted = false;
	return AddBagItem(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, BagItemListResp)
{
	auto Action = ACTION_PARSE_BagItemListResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, BagItemRemoveResp)
{
	auto Action = ACTION_PARSE_BagItemRemoveResp(InAction);
	auto& Res = Action->GetVal();

	bool Ret = false;
	for (int64 Id : Res.BagItemIds)
	{
		Ret |= RemoveBagItem(Id);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, CharacterPromoteResp)
{
	auto Action = ACTION_PARSE_CharacterPromoteResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, CharacterUnbindResp)
{
	auto Action = ACTION_PARSE_CharacterUnbindResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, CharacterEvoluteResp)
{
	auto Action = ACTION_PARSE_CharacterEvoluteResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, CharacterTurnSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterTurnSkillLevelResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, RelicPromoteResp)
{
	auto Action = ACTION_PARSE_RelicPromoteResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SculpturePromoteResp)
{
	auto Action = ACTION_PARSE_SculpturePromoteResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, PyramidUpgradeResp)
{
	auto Action = ACTION_PARSE_PyramidUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, PyramidPortalBoostUseResp)
{
	auto Action = ACTION_PARSE_PyramidPortalBoostUseResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, PowerPlantUpgradeResp)
{
	auto Action = ACTION_PARSE_PowerPlantUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, VacationUpgradeResp)
{
	auto Action = ACTION_PARSE_VacationUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, VacationStartResp)
{
	auto Action = ACTION_PARSE_VacationStartResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, PetSkillUpgradeResp)
{
	auto Action = ACTION_PARSE_PetSkillUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, PetParkUpgradeResp)
{
	auto Action = ACTION_PARSE_PetParkUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, TempleUpgradeResp)
{
	auto Action = ACTION_PARSE_TempleUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, TempleArtifactUpgradeResp)
{
	auto Action = ACTION_PARSE_TempleArtifactUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, TempleArtifactBoostResp)
{
	auto Action = ACTION_PARSE_TempleArtifactBoostResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, ShopBuyItemResp)
{
	auto Action = ACTION_PARSE_ShopBuyItemResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, BagItemSort)
{
	SortBagItems();

	return true;
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SmelterIncStockResp)
{
	auto Action = ACTION_PARSE_SmelterIncStockResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItem(Res.BagItem);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SmelterDecStockResp)
{
	auto Action = ACTION_PARSE_SmelterDecStockResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItem(Res.BagItem);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SmelterReceiveResp)
{
	auto Action = ACTION_PARSE_SmelterReceiveResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItem(Res.BagItem);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, SmelterUpgradeResp)
{
	auto Action = ACTION_PARSE_SmelterUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, AlchemylabIncStockResp)
{
	auto Action = ACTION_PARSE_AlchemylabIncStockResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, AlchemylabDecStockResp)
{
	auto Action = ACTION_PARSE_AlchemylabDecStockResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}

IMPLEMENT_ACTION_HANDLER(UBagItemManager, AlchemylabUpgradeResp)
{
	auto Action = ACTION_PARSE_AlchemylabUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateBagItems(Res.BagItems);
}
