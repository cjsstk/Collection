#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "CharacterManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FCharacterId;
struct FCharacterInfo;
struct FCharacterType;

enum class EItemGrade : uint8;

///////////////////////////////////////////////////////////////////////////////////////////
// FCharacter

struct FCharacter
{
public:
	FCharacter(const FCharacterInfo& InInfo);
	const FCharacterInfo& GetInfo() const { return Info; }
	const FCharacterId& GetId() const { return Info.CharacterId; }

	void Update(const FCharacterInfo& InInfo);
	void UpdateSkillLevel(ESkillCategory InCategory, int32 InNewLevel, int32 InTurnSkillIndex);

	void SetNewly(int32 Newly) { Info.Newly = Newly; }
	void SetStashed(int32 Stashed) { Info.Stashed = Stashed; }
	void SetIllust(int32 Illust) { Info.Illust = Illust; }

	bool IsStashed() const { return Info.Stashed > 0; }
	bool IsNewly() const { return Info.Newly > 0; }

	mutable int64 Hp;	// buffer for sort, calculated just before sort
	mutable int64 Atk;	// buffer for sort, calculated just before sort
	mutable int64 Def;	// buffer for sort, calculated just before sort

private:
	FCharacterInfo Info;
};

///////////////////////////////////////////////////////////////////////////////////////////
// UCharacterManager

UCLASS()
class Q6_API UCharacterManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UCharacterManager();

	void ReqList(int32 PageNo = 0) const;
	void ReqLoad(const FCharacterId& CharacterId) const;
	void ReqClearNew(const TArray<FCharacterId>& CharacterIds) const;
	void ReqSetLock(const FCharacterId& Id, bool bLock) const;
	void ReqAddXp(const FCharacterId& TargetId, const TArray<int64>& SourceIds) const;
	void ReqPromote(const FCharacterId& TargetId) const;
	void ReqUnbind(const FCharacterId& TargetId) const;
	void ReqEvolute(const FCharacterId& TargetId) const;
	void ReqUpgradeTurnSkillLevel(const FCharacterId& TargetId, int32 InTurnSkillIndex) const;
	void ReqUpgradeUltimateSkillLevel(const FCharacterId& TargetId, const TArray<int64>& SourceIds) const;
	void ReqSetStash(const TArray<int64>& TargetIds, bool bStashed) const;
	void ReqSetIllust(const FCharacterId& TargetId, int32 InIllustNum) const;

	TArray<const FCharacter*> GetCharacters(ESortMenu SortMenu, ESortCategory Category, bool bStashed = false) const;
	const TMap<FCharacterId, FCharacter>& GetAllCharacters() const { return Characters; }

	void SortByPicked(TArray<const FCharacter*>& OutCharacters, const TArray<FCharacterId>& CharacterIds) const;

	const FCharacter* Find(const FCharacterId& Id) const;
	const FCharacterInfo* FindHighestLevelCharacter(FCharacterType CharacterType) const;
	bool HasCharacter(FCharacterType CharacterType) const;
	bool HasCharacter(EItemGrade InGrade) const;
	bool IsMyCharacter(const FCharacterId& Id) const { return MyCharacters.Contains(Id); }

	FCharacterId GetFirstCharacterIdByCharacterType(FCharacterType CharacterType) const;
	const FCharacter* GetHighestLevelCharacter(FCharacterType CharacterType) const;
	int32 GetAllCharacterNum() const { return Characters.Num(); }
	int32 GetStashedCharacterNum(bool bStashed) const;

	void Dump() const;

	bool IsEqualCharacterType(const FCharacterId& CharacterIdA, const FCharacterId& CharacterIdB) const;
	TArray<FCharacterType> GetCharacterTypes(const TArray<FCharacterId>& CharacterIds) const;
	TMap<FCharacterType, const FCharacterInfo*> GetPortalConnectCharacters() const;
	TMap<FCharacterType, const FCharacterInfo*> GetVacationCharacters() const;

	bool GetMyWeedInfo(FCharacterInfo& Info) const;
	bool IsWeed(FCharacterId CharacterId) const;

	bool HasUpgradedCharacter() const;

	/* Skills */
	const FCMSSkillRow* GetCharacterTurnSkillRow(const FCharacterId& InCharacterId, int32 InSkillIndex) const;
	const FCMSSkillUpgradeCostRow* GetTurnSkillUpgradeCostRow(const FCharacterId InCharacterId, int32 InSkillIndex) const;
	void GetCharacterTurnSkillLevels(const FCharacterId& InCharacterId, TArray<int32>& OutCharacterLevels) const;
	int32 GetGoldForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const;
	bool HasEnoughGoldForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const;
	bool HasEnoughMaterialsForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const;
	bool IsEnoughLevelForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const;
	bool IsEnoughStarForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const;
	int32 GetLeastUpUltimateSkillLevel(const FCharacterId& InCharacterId) const;

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CCharacterListResp& Msg);
	void OnLoadResp(const FResError* Error, const FL2CCharacterLoadResp& Msg);
	void OnAddXpResp(const FResError* Error, const FL2CCharacterAddXpResp& Msg);
	void OnPromoteResp(const FResError* Error, const FL2CCharacterPromoteResp& Msg);
	void OnUnbindResp(const FResError* Error, const FL2CCharacterUnbindResp& Msg);
	void OnEvoluteResp(const FResError* Error, const FL2CCharacterEvoluteResp& Msg);
	void OnUpgradeTurnSkillLevelResp(const FResError* Error, const FL2CCharacterUpgradeTurnSkillLevelResp& Msg);
	void OnUpgradeUltimateSkillLevelResp(const FResError* Error, const FL2CCharacterUpgradeUltimateSkillLevelResp& Msg);
	void OnSetStashResp(const FResError* Error, const FL2CCharacterSetStashResp& Msg);
	void OnSetIllustResp(const FResError* Error, const FL2CCharacterSetIllustResp& Msg);
	void OnClearNewResp(const FResError* Error, const FL2CCharacterClearNewResp& Msg);

private:
	FCharacter* Find(const FCharacterId& Id);
	int32 GetTurnSkillLevel(const FCharacterId InCharacterId, int32 InSkillIndex) const;

	void AddCharacter(const FCharacterInfo& Info);
	void Removed(const FCharacterId& Id);
	void SetCharacterSkillLevel(const FCharacterId& InCharacterId, ESkillCategory InCategory, int32 NewSkillLevel, int32 OldSkillLevel, int32 TurnSkillIndex);

	DECLARE_ACTION_HANDLER(ClearMyCharacters);
	DECLARE_ACTION_HANDLER(CharacterListResp);
	DECLARE_ACTION_HANDLER(CharacterLoadResp);
	DECLARE_ACTION_HANDLER(CharacterAddXpResp);
	DECLARE_ACTION_HANDLER(CharacterRemoveResp);
	DECLARE_ACTION_HANDLER(CharacterPromoteResp);
	DECLARE_ACTION_HANDLER(CharacterUnbindResp);
	DECLARE_ACTION_HANDLER(CharacterEvoluteResp);
	DECLARE_ACTION_HANDLER(CharacterSkillLevelResp);
	DECLARE_ACTION_HANDLER(CharacterTurnSkillLevelResp);
	DECLARE_ACTION_HANDLER(CharacterUltimateSkillLevelResp);
	DECLARE_ACTION_HANDLER(CharacterSetStashResp);
	DECLARE_ACTION_HANDLER(CharacterSetIllustResp);
	DECLARE_ACTION_HANDLER(CharacterClearNewResp);
	DECLARE_ACTION_HANDLER(DevCharacterNewResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(SummonPickupResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(ShopSellItemResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);

	TMap<FCharacterId, FCharacter> Characters;	// CharacterId, FCharacter
	TSet<FCharacterId> MyCharacters;			// CharacterId
};

void DumpCharacter(const FCharacterInfo& Info);
