#pragma once

#include "HSActionType.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Action Types

UENUM()
enum class EHSActionType : uint16
{
	Invalid = 0,
	// Internal
	AccountName,
	WattInfo,
	GemConsume,
	ClearMyCharacters,
	ClearBag,
	ClearRelic,
	ClearSculpture,
	ClearParty,
	ClearActRecord,
	ClearUserRecord,
	ClearCodexChar,
	ClearCodexSculpture,
	ClearCodexRelic,
	ClearWeeklyMission,
	ClearCharMission,
	ClearEventMission,
	ClearTitle,
	ClearLobbyTemplate,
	FriendshipCollect,
	SystemJoker,
	RandomJoker,
	FriendJoker,
	FriendJokerFromPopup,
	OwnedJoker,
	UpdateCurrency,
	UpdateMission,
	UpdateCharMission,
	ContentsResetTime,
	UserSetTutorials,

	// Network Event
	NetworkReconnected,

	//// Packet
	// Lobby
	AuthEnterLobbyResp,
	AuthEnterLobbyFinalResp,
	// Result
	UserAddXpResp,
	UserRenameResp,
	//Currency
	CurrencyLoadResp,
	// Character
	CharacterListResp,
	CharacterLoadResp,
	CharacterAddXpResp,
	CharacterPromoteResp,
	CharacterUnbindResp,
	CharacterEvoluteResp,
	CharacterRemoveResp,
	CharacterSkillLevelResp,
	CharacterTurnSkillLevelResp,
	CharacterUltimateSkillLevelResp,
	CharacterSetStashResp,
	CharacterSetIllustResp,
	CharacterClearNewResp,
	// Character Bond
	BondLoadResp,
	// Friend
	FriendLoadResp,
	FriendCooltimeListResp,
	FriendCandidatesResp,
	FriendErrorResp,
	FriendSearchResp,
	FriendRequestResp,
	FriendDeclineResp,
	FriendAcceptResp,
	FriendRemoveResp,
	FriendConfirmResp,
	FriendNotifyAccept,
	FriendNotifyRemove,
	FriendNotifyJokerSetChange,
	FriendNotifyRequest,
	FriendNotifyAvatarChange,
	FriendNotifyNicknameChanged,
	// Friendship
	FriendshipCollectResp,
	// JokerSet
	JokerSetLoadResp,
	JokerSetSaveResp,
	JokerSetUseResp,
	// Mail
	MailListResp,
	MailReceiveResp,
	MailRefreshListResp,
	// Party
	PartyLoadResp,
	PartySaveResp,

	// BagItem
	BagItemLoadResp,
	BagItemListResp,
	BagItemRemoveResp,
	// Saga
	SagaLoadResp,
	SagaStageBeginResp,
	SagaStageEndResp,
	SagaStoryStageClearResp,
	// Special
	SpecialLoadResp,
	SpecialStageBeginResp,
	SpecialStageEndResp,
	SpecialStoryStageClearResp,
	// Daily
	DailyStageBeginResp,
	DailyStageEndResp,
	DailyListResp,
	// Raid
	RaidListResp,
	RaidOpenNof,
	RaidCanEnterNof,
	RaidPrepareResp,
	RaidReqTimeout,
	RaidPrepareTimeout,
	RaidReadyTimeout,
	RaidOpenNofTimeout,
	RaidStageEndResp,
	RaidStageEndNof,
	RaidSkillUsedResp,
	RaidEnterNofTimeout,
	RaidEnterNof,
	RaidEndNof,
	RaidSkillsNof,
	RaidSkillsTimeout,
	RaidBossHealthNof,
	RaidEmoticonNof,
	RaidSharePartyResp,
	RaidSharePartyNof,
	RaidFinalStageBeginResp,
	RaidFinalStageEndResp,
	RaidFullNof,
	RaidKickTimeoutNof,
	RegularRaidRegisterResp,
	RegularRaidReadyResp,
	RegularRaidMatchedNoti,
	// Summon
	SummonLoadResp,
	SummonBoxScheduleResp,
	SummonPurchaseResp,
	SummonPickupResp,
	// Relic
	RelicLoadResp,
	RelicListResp,
	RelicRemoveResp,
	RelicAddXpResp,
	RelicPromoteResp,
	RelicTierUpResp,
	RelicSetStashResp,
	RelicClearNewResp,
	// Sculpture
	SculptureLoadResp,
	SculptureListResp,
	SculptureRemoveResp,
	SculptureAddXpResp,
	SculpturePromoteResp,
	SculptureTierUpResp,
	SculptureSetStashResp,
	SculptureClearNewResp,
	// ActRecord
	ActRecordLoadResp,
	ActRecordListResp,
	ActRecordRemoveResp,
	// UserRecord
	UserRecordListResp,
	UserRecordRezCountResp,
	// codex
	CodexListCharResp,
	CodexListSculptureResp,
	CodexListRelicResp,
	CodexClearNewCharResp,
	CodexClearNewSculptureResp,
	CodexClearNewRelicResp,
	CodexClearNewAllResp,
	// weekly mission
	WeeklyMissionLoadResp,
	WeeklyMissionRewardResp,
	WeeklyMissionBingoResp,
	WeeklyMissionShuffleResp,
	// smelter
	SmelterLoadResp,
	SmelterIncStockResp,
	SmelterDecStockResp,
	SmelterReceiveResp,
	SmelterUpgradeResp,
	SmelterUpgradeCompleteResp,
	SmelterProduceResp,
	// alchemylab
	AlchemylabLoadResp,
	AlchemylabIncStockResp,
	AlchemylabDecStockResp,
	AlchemylabReceiveResp,
	AlchemylabUpgradeResp,
	AlchemylabUpgradeCompleteResp,
	AlchemylabProduceResp,
	// char mission
	CharMissionListResp,
	CharMissionRewardResp,
	// event mission
	EventMissionListResp,
	// user title
	TitleListResp,
	TitleChangeResp,
	DevTitleAddResp,
	// TrainingCenter
	TrainingCenterLoadResp,
	TrainingCenterStageBeginResp,
	TrainingCenterStageEndResp,
	// Pyramid
	PyramidLoadResp,
	PyramidPortalConnectResp,
	PyramidUpgradeResp,
	PyramidUpgradeCompleteResp,
	PyramidPortalBoostUseResp,
	PyramidPortalWarpResp,
	// Temple
	TempleLoadResp,
	TempleUpgradeResp,
	TempleUpgradeCompleteResp,
	TempleArtifactUseResp,
	TempleArtifactBoostResp,
	TempleArtifactUpgradeResp,
	TempleHarvestResp,
	// PowerPlant
	PowerPlantLoadResp,
	PowerPlantUpgradeResp,
	PowerPlantUpgradeCompleteResp,
	PowerPlantStoreResp,
	PowerPlantRechargeResp,
	// Pet
	PetLoadResp,
	PetParkUpgradeResp,
	PetParkUpgradeCompleteResp,
	PetParkHarvestResp,
	PetSkillUpgradeResp,
	// Vacation
	VacationLoadResp,
	VacationUpgradeResp,
	VacationUpgradeCompleteResp,
	VacationStartResp,
	VacationEndResp,
	// Watt
	WattRechargeResp,
	// CheckIn
	CheckInListResp,
	CheckInRewardReceiveResp,
	// Shop
	ShopListResp,
	ShopSaleScheduleResp,
	ShopBuyItemResp,
	ShopSellItemResp,
	ShopClearNewResp,
	// LobbyTemplate
	LobbyTemplateListResp,
	LobbyTemplateClearNewResp,
	// LobbySet
	LobbySetLoadResp,
	LobbySetSaveResp,
	LobbySetUseResp,
	// ContentFeatureOpen
	ContentFeatureOpenListResp,
	// Event
	EventContentListResp,
	EventContentRefreshNumberOfDaysResp,
	EventContentRoulettePlayResp,
	EventContentRouletteResetResp,
	EventContentCollabo01StageBeginResp,
	EventContentCollabo01StageEndResp,
	EventContentCollabo01StoryStageClearResp,
	EventContentValentineDayStageBeginResp,
	EventContentValentineDayStageEndResp,
	EventContentValentineDayStoryStageClearResp,
	EventContentMultiSideBattleStageBeginResp,
	EventContentMultiSideBattleStageEndResp,
	EventContentMultiSideBattleStoryStageClearResp,
	EventContentMultisideBattleReceiveRankRewardResp,
	EventContentMultiSideBattleRankLoadResp,
	// Avatar
	AvatarLoadResp,
	AvatarSaveResp,
	// NewMark
	NewMarkNotifyMail,
	// BattleHelper
	StageChallengeListResp,
	StageChallengeAddResp,
	// FriendBook
	FriendBookPosted,
	FriendBookReacted,
	FriendBookReactionRemoved,
	FriendBookGetTimeline,
	FriendBookAddReaction,
	FriendBookRemoveReaction,
	FriendBookGetFeed,

	//// End of Packet

	// Cheat
	DevAddCurrencyResp,
	DevAddXpResp,
	DevBondAddResp,
	DevCharacterNewResp,
	DevRelicNewResp,
	DevSculptureNewResp,
	DevSpecialClearResp,
	DevSpecialOpenResp,
	DevStageClearResp,
	DevWattRechargeResp,
	DevWattConsumeResp,
	DevTrainingCenterClearResp,
	DevTrainingCenterResetResp,
	DevPyramidOpenResp,
	DevPyramidUpgradeResp,
	DevPyramidPortalBoostUseResp,
	DevPyramidPortalConnectResp,
	DevPyramidPortalWarpResp,
	DevPyramidPortalClearResp,
	DevTempleOpenResp,
	DevTempleArtifactsResetResp,
	DevTempleArtifactUpgradeResp,
	DevTempleProduceResp,
	DevPowerPlantOpenResp,
	DevPetParkOpenResp,
	DevPetParkProduceResp,
	DevPetSkillUpgradeResp,
	DevPetNewResp,
	DevVacationOpenResp,
	DevSmelterOpenResp,
	DevSmelterUpgradeResp,
	DevSmelterTimeResp,
	DevAlchemylabOpenResp,
	DevAlchemylabUpgradeResp,
	DevAlchemylabTimeResp,
	DevCheckInLoadResp,
	DevShopResetResp,
	DevSummonMileageSetResp,
	DevLobbyTemplateNewResp,
	DevFriendBotAllResp,
	DevFriendCooltimeResp,
	DevCharMissionSetResp,
	DevContentFeatureOpenResp,
	DevEventContentNumberOfDaysResp,
	DevEventContentAddPointResp,
	DevEventContentRechargeWattResp,
	DevEventContentRouletteResetResp,
	DevClockModResp,
	DevAvatarAddResp,
	//// End of Cheat

	//// UI
	// Menu
	MenuBack,
	MenuDoubleBack,
	MenuChange,

	// Upgrade
	UpgradeMenu,
	UpgradeInventory,
	UpgradeCategory,
	UpgradeItem,

	// Friend
	FriendCategoryChange,
	FriendJokerSetView,
	FriendReorder,
	FriendBookFilterChange,
	FriendBookReadTimeline,
	FriendBookNewFeedsFromFile,

	// Party
	PartyChange,
	PartyEdit,
	PartyPetEdit,
	PartyMain,
	PartyEventContentType,

	// JokerSet
	JokerSetChange,
	JokerSetEdit,
	JokerSetMain,

	// JokerSelect
	JokerSelect,
	JokerSetView,

	// Saga
	SagaStageList,

	// Special
	SpecialOpen,
	SpecialEpisodeList,
	SpecialCharacterStageList,
	SpecialSagaStageList,
	SpecialWonderStageList,

	// DailyDungeon
	DailyDungeonStageList,
	DailyDungeonPageChange,

	// TrainingCenter
	TrainingCenterOpen,

	// Summon
	SummonPageChange,
	SummonFriendShip,

	// InitialRewardEvent
	InitialRewardEventOpen,

	// Wonder
	WonderMenu,
	WonderSlotSelect,

	// Raid
	RaidOpen,
	UpdateRaidWhenEnterMenu,
	RaidPrepareTime,
	SetOnGoingRaid,
	RaidClearData,
	MuteRaidJoinPopup,
	RaidSelectFinal,
	RaidClearFoundType,
	RaidClearSkills,
	RaidCharInfos,
	RaidSetSkills,

	// Inventory
	InventoryOpen,
	InventoryChange,
	InventoryEdit,

	// Mail
	MailSelect,

	// CheckIn
	CheckInClear,

	// Codex
	CodexCategoryChange,
	CodexClearCharNew,
	CodexClearSculptureNew,
	CodexClearRelicNew,
	CodexEquipFullView,

	// WeeklyMission
	WeeklyMissionToast,

	// UserRecord
	UserRecordRows,

	// Sorting
	SortingInit,
	SortingChange,

	// Shop
	ShopMenuChange,

	// LobbySetting
	LobbySettingEditChange,

	// Bag
	BagItemSort,

	// Event
	EventMenuChange,

	// Multiside
	MultisidePetSave,
	MultisidePartySave,

	// Story
	StoryList,

	//// End of UI

	Max
};

static const int32 EHSActionTypeMin = static_cast<int32>(EHSActionType::Invalid) + 1;
static const int32 EHSActionTypeMax = static_cast<int32>(EHSActionType::Max);
