#include "SummonManager.h"

#include "CharacterManager.h"
#include "CodexManager.h"
#include "HSAction.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Q6SummonGameMode.h"
#include "LevelUtil.h"

///////////////////////////////////////////////////////////////////////////////////////////
// USummonManager

USummonManager::USummonManager()
{
	InitStore(EHSType::Summon);

	SummonDiskRewards.Reset();
}

USummonManager::~USummonManager()
{
}

void USummonManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSummonLoad Out;

	ClientNetwork.WsRequest(TEXT("summon/load"), Out,
		TQ6ResponseDelegate<FL2CSummonLoadResp>::CreateUObject(
			const_cast<USummonManager*>(this), &USummonManager::OnLoadResp));
}

void USummonManager::ReqBoxPurchase(const FBoxProductType& BoxId, bool bInCanRepeatSummon) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSummonPurchase Out;
	Out.BoxId = BoxId;

	ClientNetwork.WsRequest(TEXT("summon/purchase"), Out,
		TQ6ResponseDelegate<FL2CSummonPurchaseResp>::CreateUObject(
			const_cast<USummonManager*>(this), &USummonManager::OnBoxPurchaseResp, bInCanRepeatSummon));
}

void USummonManager::ReqBoxSchedule() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSummonSchedule Out;

	ClientNetwork.WsRequest(TEXT("summon/schedule"), Out,
		TQ6ResponseDelegate<FL2CSummonScheduleResp>::CreateUObject(
			const_cast<USummonManager*>(this), &USummonManager::OnBoxScheduleResp));
}

void USummonManager::ReqPickup(FBoxProductType BoxProductType, int32 ItemType, bool bInCanRepeatSummon) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSummonPickup Out;
	Out.BoxId = BoxProductType;
	Out.PickupValue = ItemType;

	ClientNetwork.WsRequest(TEXT("summon/pickup"), Out,
		TQ6ResponseDelegate<FL2CSummonPickupResp>::CreateUObject(
			const_cast<USummonManager*>(this), &USummonManager::OnPickupResp, bInCanRepeatSummon));
}

bool USummonManager::IsSummonFree(FBoxProductType usedId) const
{
	return SummonFreeInfos.Contains(usedId);
}

int32 USummonManager::GetPageIndex(int32 PageKey) const
{
	return OrderedPageList.IndexOfByKey(PageKey);
}

int32 USummonManager::GetMileage(int32 EventId) const
{
	const int32* Mileage = Mileages.Find(EventId);
	if (!Mileage)
	{
		return 0;
	}

	return *Mileage;
}

void USummonManager::OnLoadResp(const FResError* Error, const FL2CSummonLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_SummonLoadResp(Res);
	GameInstance->ReqNextContent();
}

void USummonManager::OnBoxPurchaseResp(const FResError* Error, const FL2CSummonPurchaseResp& Res, bool bInCanRepeatSummon)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	SummonResult.bCanRepeatSummon = bInCanRepeatSummon;
	// SummonManager have to take care of it before CodexManager.
	MakeSummonResult(Res);
	ACTION_DISPATCH_SummonPurchaseResp(Res);

	ShowSummonResult(Res.BoxId);
}

void USummonManager::OnBoxScheduleResp(const FResError* Error, const FL2CSummonScheduleResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SummonBoxScheduleResp(Res);
}

void USummonManager::OnPickupResp(const FResError* Error, const FL2CSummonPickupResp& Res, bool bInCanRepeatSummon)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	SummonResult.bCanRepeatSummon = bInCanRepeatSummon;
	// SummonManager have to take care of it before CodexManager.
	MakeSummonResult(Res);
	ACTION_DISPATCH_SummonPickupResp(Res);

	ShowSummonResult(Res.BoxId);
}

void USummonManager::MakeSummonResult(const FL2CSummonPurchaseResp& Res)
{
	SummonResult.BoxProductType = Res.BoxId;
	SummonResult.Categories = Res.ItemTypeList;
	SummonResult.Characters = Res.Characters;
	SummonResult.Sculptures = Res.Sculptures;
	SummonResult.Relics = Res.Relics;
	SummonResult.bPickup = false;

	FillSummonResultInternal();
}

void USummonManager::MakeSummonResult(const FL2CSummonPickupResp& Res)
{
	SummonResult.BoxProductType = Res.BoxId;
	SummonResult.Categories.Reset();
	SummonResult.Categories.Add(Res.ItemType);

	SummonResult.Characters = Res.Characters;
	SummonResult.Sculptures = Res.Sculptures;
	SummonResult.Relics = Res.Relics;

	SummonResult.bPickup = true;

	FillSummonResultInternal();
}

void USummonManager::FillSummonResultInternal()
{
	SummonResult.FirstOrNots.SetNum(SummonResult.Categories.Num());

	const UCodexManager& CodexManager = GetHUDStore().GetCodexManager();
	TArray<FCharacterType> NewChars;
	TArray<FSculptureType> NewSculptures;
	TArray<FRelicType> NewRelics;

	for (int32 i = 0, ci = 0, si = 0, ri = 0; i < SummonResult.Categories.Num(); ++i)
	{
		SummonResult.FirstOrNots[i] = false;

		switch (SummonResult.Categories[i])
		{
			case ELootCategory::CharacterCard:
				if (SummonResult.Characters.IsValidIndex(ci))
				{
					FCharacterType CharacterType = SummonResult.Characters[ci++].Type;
					if (!CodexManager.FindChar(CharacterType) && (NewChars.Find(CharacterType) == INDEX_NONE))
					{
						SummonResult.FirstOrNots[i] = true;
						NewChars.Add(CharacterType);
					}
				}
				break;
			case ELootCategory::SculptureCard:
				if (SummonResult.Sculptures.IsValidIndex(si))
				{
					FSculptureType SculptureType = SummonResult.Sculptures[si++].Type;
					if (!CodexManager.FindSculpture(SculptureType) && (NewSculptures.Find(SculptureType) == INDEX_NONE))
					{
						SummonResult.FirstOrNots[i] = true;
						NewSculptures.Add(SculptureType);
					}
				}
				break;
			case ELootCategory::RelicCard:
				if (SummonResult.Relics.IsValidIndex(ri))
				{
					FRelicType RelicType = SummonResult.Relics[ri++].Type;
					if (!CodexManager.FindRelic(RelicType) && (NewRelics.Find(RelicType) == INDEX_NONE))
					{
						SummonResult.FirstOrNots[i] = true;
						NewRelics.Add(RelicType);
					}
				}
				break;
			default:
				break;
		}
	}
}

void USummonManager::ShowSummonResult(FBoxProductType BoxProductType)
{
	const FCMSBoxProductRow& BoxRow = GetCMS()->GetBoxProductRowOrDummy(BoxProductType);
	if (BoxRow.SummonType == ESummonType::Friendship)
	{
		ACTION_DISPATCH_SummonFriendShip();
	}
	else
	{
		if (AQ6SummonGameMode* SummonGameMode = GetSummonGameMode(GameInstance))
		{
			SummonGameMode->StartShow(SummonResult);
		}
		else
		{
			ULevelUtil::LoadSummonLevel(GameInstance->GetWorld());
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// USummonManager HUDStore Action

void USummonManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(USummonManager, SummonLoadResp);
	REGISTER_ACTION_HANDLER(USummonManager, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(USummonManager, SummonBoxScheduleResp);
	REGISTER_ACTION_HANDLER(USummonManager, SummonPickupResp);
	REGISTER_ACTION_HANDLER(USummonManager, DevSummonMileageSetResp);
}

IMPLEMENT_ACTION_HANDLER(USummonManager, SummonLoadResp)
{
	auto Action = ACTION_PARSE_SummonLoadResp(InAction);
	auto& Res = Action->GetVal();

	SummonFreeInfos.Reset();
	SummonFreeInfos = Res.FreeInfos;

	Mileages.Reset();
	for (const FSummonMileageInfo& Mileage : Res.Mileages)
	{
		Mileages.Add(Mileage.EventId, Mileage.Amount);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(USummonManager, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);
	auto& Res = Action->GetVal();

	SummonFreeInfos.Reset();
	SummonFreeInfos = Res.FreeInfos;

	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(Res.BoxId);
	Mileages.Add(BoxProductRow.EventId, Res.Mileage);

	SummonDiskRewards = Res.DiskRewards;

	return true;
}

IMPLEMENT_ACTION_HANDLER(USummonManager, SummonBoxScheduleResp)
{
	auto Action = ACTION_PARSE_SummonBoxScheduleResp(InAction);
	auto& Res = Action->GetVal();

	SummonFreeInfos.Reset();
	SummonFreeInfos = Res.FreeInfos;

	OrderedPageList = GetCMS()->GetValidOrderedPageList(Res.ScheduleInfos);

	Mileages.Reset();
	for (const FSummonMileageInfo& Mileage : Res.Mileages)
	{
		Mileages.Add(Mileage.EventId, Mileage.Amount);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(USummonManager, SummonPickupResp)
{
	auto Action = ACTION_PARSE_SummonPickupResp(InAction);
	auto& Res = Action->GetVal();

	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(Res.BoxId);
	Mileages.Add(BoxProductRow.EventId, Res.Mileage);

	SummonDiskRewards = Res.DiskRewards;

	return true;
}

IMPLEMENT_ACTION_HANDLER(USummonManager, DevSummonMileageSetResp)
{
	auto Action = ACTION_PARSE_DevSummonMileageSetResp(InAction);
	auto& Res = Action->GetVal();

	Mileages.Add(Res.EventId, Res.Mileage);

	return true;
}
