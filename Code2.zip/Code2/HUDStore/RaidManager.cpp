#include "RaidManager.h"

#include "BondManager.h"
#include "CombatCube/CCAction.h"
#include "EventManager.h"
#include "CombatCube/Formula.h"
#include "HUD/BaseHUD.h"
#include "JsonObjectConverter.h"
#include "LoginHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "SagaManager.h"
#include "CharacterManager.h"
#include "UIStateManager.h"
#include "Utils/LevelUtil.h"
#include "HSAction.h"
#include "LobbyHUD.h"
#include "CCEvent.h"
#include "PartyManager.h"
#include "FriendManager.h"
#include "SystemConst_gen.h"

const float REGULAR_RAID_TICK = 1.0f;
const float REGULAR_RAID_REQ_READY_OFFSET_SEC = 2.0f;

class FRaidPush
{
public:
	FRaidPush(URaidManager* InParent)
		: Parent(InParent), GameInstance(nullptr), Inited(false)
	{
	}

	void Init(UQ6GameInstance* InGameInstance)
	{
		if (Inited) {
			return;
		}

		Inited = true;
		GameInstance = InGameInstance;

		FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
		ClientNetwork.RegisterPush(TEXT("raidOpened"), TQ6PushDelegate<FL2CRaidOpenNof>::CreateRaw(
			this, &FRaidPush::OnOpenNof));

		ClientNetwork.RegisterPush(TEXT("raidCanEnter"), TQ6PushDelegate<FL2CRaidCanEnterNof>::CreateRaw(
			this, &FRaidPush::OnCanEnterNof));

		ClientNetwork.RegisterPush(TEXT("raidEnd"), TQ6PushDelegate<FL2CRaidEndNof>::CreateRaw(
			this, &FRaidPush::OnEndNof));

		ClientNetwork.RegisterPush(TEXT("raidBossHealth"), TQ6PushDelegate<FL2CRaidBossHealthNof>::CreateRaw(
			this, &FRaidPush::OnBossHealthNof));

		ClientNetwork.RegisterPush(TEXT("raidEmoticon"), TQ6PushDelegate<FL2CRaidEmoticonNof>::CreateRaw(
			this, &FRaidPush::OnEmoticonNof));

		ClientNetwork.RegisterPush(TEXT("raidShareParty"), TQ6PushDelegate<FL2CRaidSharePartyNof>::CreateRaw(
			this, &FRaidPush::OnSharePartyNof));

		ClientNetwork.RegisterPush(TEXT("stageEndNof"), TQ6PushDelegate<FL2CRaidStageEndNof>::CreateRaw(
			this, &FRaidPush::OnStageEndNof));

		ClientNetwork.RegisterPush(TEXT("raidFullNof"), TQ6PushDelegate<FL2CRaidFullNof>::CreateRaw(
			this, &FRaidPush::OnRaidFullNof));

		ClientNetwork.RegisterPush(TEXT("raidKickTimeoutNof"), TQ6PushDelegate<FL2CRaidKickTimeoutNof>::CreateRaw(
			this, &FRaidPush::OnRaidKickTimeoutNof));

		ClientNetwork.RegisterPush(TEXT("regularRaidMatched"), TQ6PushDelegate<FL2CRegularRaidNotiMatched>::CreateRaw(
			this, &FRaidPush::OnRegularRaidMatchedNoti));
	}

	void OnOpenNof(const FL2CRaidOpenNof& Nof)
	{
		Parent->OnRaidOpenNof(Nof);
	}
	void OnCanEnterNof(const FL2CRaidCanEnterNof& Nof)
	{
		Parent->OnRaidCanEnterNof(Nof);
	}
	void OnEndNof(const FL2CRaidEndNof& Nof)
	{
		Parent->OnRaidEndNof(Nof);
	}
	void OnBossHealthNof(const FL2CRaidBossHealthNof& Nof)
	{
		Parent->OnRaidBossHealthNof(Nof);
	}
	void OnEmoticonNof(const FL2CRaidEmoticonNof& Nof)
	{
		Parent->OnRaidEmoticonNof(Nof);
	}
	void OnSharePartyNof(const FL2CRaidSharePartyNof& Nof)
	{
		Parent->OnRaidSharePartyNof(Nof);
	}
	void OnStageEndNof(const FL2CRaidStageEndNof& Nof)
	{
		Parent->OnRaidStageEndNof(Nof);
	}
	void OnRaidFullNof(const FL2CRaidFullNof& Nof)
	{
		Parent->OnRaidFullNof(Nof);
	}
	void OnRaidKickTimeoutNof(const FL2CRaidKickTimeoutNof& Nof)
	{
		Parent->OnRaidKickTimeoutNof(Nof);
	}
	void OnRegularRaidMatchedNoti(const FL2CRegularRaidNotiMatched& Noti)
	{
		Parent->OnRegularRaidMatchedNoti(Noti);
	}

private:
	URaidManager* Parent;
	UQ6GameInstance* GameInstance;
	bool Inited;
};

URaidManager::URaidManager()
	: RegularRaidTick(REGULAR_RAID_TICK)
	, SelectedRaidFinalType(RaidTypeInvalid)
	, SelectedRaidFinalId(FRaidId::InvalidValue())
	, FoundRaidType(RaidTypeInvalid)
	, TodayRaidType(RaidTypeInvalid)
{
	InitStore(EHSType::Raid);
	PushInstance = new FRaidPush(this);

	ResetRaid();
	ResetRegularRaidState();
}

URaidManager::~URaidManager()
{
	delete PushInstance;
}

void URaidManager::ReqList() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LRaidList Out;

	ClientNetwork.WsRequest(TEXT("raid/list"), Out,
		TQ6ResponseDelegate<FL2CRaidListResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnListResp));
}

void URaidManager::Tick(float DeltaTime)
{
	if (ReqTimeout > 0.f)
	{
		ExpireReq(DeltaTime);
	}
	if (PrepareTimeout > 0.f)
	{
		ExpirePrepare(DeltaTime);
	}
	if (ReadyTimeout > 0.f)
	{
		ExpireReady(DeltaTime);
	}
	if (RaidLeftSec > 0.f)
	{
		RaidLeftSec -= DeltaTime;
		if (RaidLeftSec < 0)
		{
			RaidLeftSec = 0.f;
		}
	}

	if (bMutePopup)
	{
		if (RaidJoinPopupMuteElapsedTime < RAID_JOIN_POPUP_MUTE_TIME)
		{
			RaidJoinPopupMuteElapsedTime += DeltaTime;
		}
		else
		{
			bMutePopup = false;
			RaidJoinPopupMuteElapsedTime = 0.f;
		}
	}

	if (RegularRaidState.Registered && !RegularRaidState.WaitForReqReady)
	{
		RegularRaidTick -= DeltaTime;

		if(RegularRaidTick <= 0.0f)
		{
			RegularRaidTick = REGULAR_RAID_TICK;

			const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(
				RegularRaidState.ScheduleId);
			if (ScheduleInfo)
			{
				FDateTime CustomDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate);
				CustomDate += FTimespan(0, 0, REGULAR_RAID_REQ_READY_OFFSET_SEC);

				FDateTime CustomDate2 = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate2);
				FDateTime NowDate = FDateTime::Now();
				if (CustomDate < NowDate && NowDate < CustomDate2)
				{
					RegularRaidState.WaitForReqReady = true;

					const FLobbyUIState* UIState = GetHUDStore().GetUIStateManager().GetUIState();
					if (UIState)
					{
						switch (UIState->GetHUDWidgetType())
						{
							case EHUDWidgetType::Raid:
							{
								ACTION_DISPATCH_UpdateRaidWhenEnterMenu();
							}
							break;
							default:
							{
								GameInstance->ClearBanIndices();
								OpenRaidJoinPopup(RegularRaidState.RaidType);
							}
							break;
						}
					}
					else
					{
						GameInstance->ClearBanIndices();
						OpenRaidJoinPopup(RegularRaidState.RaidType);
					}
				}
			}
		}
	}

	if (RegularRaidState.WaitForReqReady && !RegularRaidState.RespReady)
	{
		RegularRaidTick -= DeltaTime;

		if (RegularRaidTick <= 0.0f)
		{
			RegularRaidTick = REGULAR_RAID_TICK;

			const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(
				RegularRaidState.ScheduleId);
			if (ScheduleInfo)
			{
				FDateTime CustomDate2 = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate2);
				FDateTime NowDate = FDateTime::Now();
				if (NowDate > CustomDate2)
				{
					ResetRegularRaidState();
					ACTION_DISPATCH_UpdateRaidWhenEnterMenu();
				}
			}
		}
	}
}

TArray<FCharSkill> URaidManager::GetRaidTurnSkills() const
{
	if (Skills.Num() == 0)
	{
		return Skills;
	}

	TArray<FCharSkill> Ret = Skills;
	return Ret;
}

TArray<FCharSkill> URaidManager::GetRaidSupportSkills() const
{
	if (SupportSkills.Num() == 0)
	{
		return SupportSkills;
	}

	TArray<FCharSkill> Ret = SupportSkills;
	return Ret;
}

int32 URaidManager::GetSurviveCharCount() const
{
	int32 Count(0);
	for (const FRaidUserCharacterInfo& CharInfo : UserCharInfos)
	{
		if (CharInfo.Health == 0 && CharInfo.MaxHealth == 0)
		{
			++Count;
		}
		if (CharInfo.Health > 0 && CharInfo.MaxHealth > 0)
		{
			++Count;
		}
	}

	return Count;
}

void URaidManager::ClearRaidSkills()
{
	Skills.Empty();
	SupportSkills.Empty();
}

bool URaidManager::IsRaidFound() const
{
	return (GetFoundRaidType() != RaidTypeInvalid);
}

int64 URaidManager::GetRaidStartUtcByRaidId(const FRaidId& RaidId) const
{
	const FRaidFinal* RaidFinal = RaidFinals.Find(RaidId);
	if (!RaidFinal)
	{
		return 0;
	}

	return RaidFinal->GetInfo().StartUtc;
}

bool URaidManager::IsRaidListFull() const
{
	int ValidRaidResultCount = 0;
	for (const auto& Elem : RaidFinals)
	{
		if (Elem.Value.GetInfo().RewardUtc <= 0)
		{
			++ValidRaidResultCount;
		}
	}

	return  SystemConst::Q6_MAX_RAID_RESULT <= ValidRaidResultCount;
}

const TArray<FRaidParticipateUserInfo> URaidManager::GetRaidUserInfos() const
{
	TArray<FRaidParticipateUserInfo> Out;

	for (const TPair<FUserId, FRaidParticipateUserInfo>& Elem : RaidUserInfos)
	{
		Out.Add(Elem.Value);

		FRaidParticipateUserInfo& LastElem = Out.Last();
		LastElem.Healths.StableSort([](const FCharHealth& Elem1, const FCharHealth& Elem2)
		{
			if (Elem1.Health > 0 && Elem2.Health > 0)
			{
				return !Elem1.Joker;
			}
			else if (Elem1.Health > 0)
			{
				return true;
			}
			else if (Elem2.Health > 0)
			{
				return false;
			}
			else
			{
				return Elem1.MaxHealth < Elem2.MaxHealth;
			}
		});
	}

	Out.Sort([](const FRaidParticipateUserInfo& Elem1, const FRaidParticipateUserInfo& Elem2)
	{
		return Elem1.Score > Elem2.Score;
	});

	return Out;
}

void URaidManager::SetRaidSupportSkillsInfo(const TArray<FCCRaidSkillState>& InSupportSkillsHas
	, const TArray<FCCUsedCharSkillInfo>& InSupportSkillsUse)
{
	SupportSkillsHas.Reset();
	SupportSkillsUse.Reset();

	for (const auto& InSupportSkillHas : InSupportSkillsHas)
	{
		if (InSupportSkillHas.bIsUsed)
		{
			continue;
		}

		FCharSkill SupportSkillHas;
		SupportSkillHas.Slot = InSupportSkillHas.Slot;
		SupportSkillHas.CharInfo = InSupportSkillHas.CharInfo;
		SupportSkillHas.NatureType = InSupportSkillHas.NatureType;
		SupportSkillHas.Skill = FSkillType(InSupportSkillHas.SkillState.SkillType);
		SupportSkillHas.SupportSkillLevel = InSupportSkillHas.SupportSkillLevel;
		SupportSkillHas.UserName = InSupportSkillHas.UserName;
		SupportSkillHas.UserId = GetUser().GetId();
		SupportSkillHas.Attributes = InSupportSkillHas.Attributes;

		SupportSkillsHas.Add(SupportSkillHas);
	}

	const UCharacterManager& CharMan = GetHUDStore().GetCharacterManager();
	for (const auto& InSupportSkillUse : InSupportSkillsUse)
	{
		const FCharacter* Char = CharMan.Find(InSupportSkillUse.CharacterId);
		if (Char == nullptr)
		{
			continue;
		}

		const FCharacterInfo& CharacterInfo = Char->GetInfo();
		const FCharacterBond& CharacterBond = GetHUDStore().GetBondManager().GetCharacterBond(CharacterInfo.Type);

		FCharSkill SupportSkillUse;
		SupportSkillUse.Slot = InSupportSkillUse.Slot;
		SupportSkillUse.CharInfo = CharacterInfo;
		SupportSkillUse.NatureType = InSupportSkillUse.NatureType;
		SupportSkillUse.Skill = InSupportSkillUse.SkillType;
		SupportSkillUse.SupportSkillLevel = CharacterBond.SupportSkillLevel;
		SupportSkillUse.UserName = GetUser().GetNickname();
		SupportSkillUse.UserId = GetUser().GetId();
		SupportSkillUse.Attributes = InSupportSkillUse.Attributes;

		SupportSkillsUse.Add(SupportSkillUse);
	}
}

void URaidManager::SetSelectedRaidFinal(const FRaidType& Type, const FRaidId& Id)
{
	SelectedRaidFinalType = Type;
	SelectedRaidFinalId = Id;
}

void URaidManager::InitUserCharInfo()
{
	UserCharInfos.Empty();

	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FPartyInfo& PartyInfo = GetHUDStore().GetPartyManager().GetPartyInfo(
		CombatSeed.PartyId);
	for (const FPartySlot& MainSlot : PartyInfo.Main)
	{
		if (MainSlot.CharacterId.IsInvalid())
		{
			continue;
		}

		FRaidUserCharacterInfo Info;
		Info.CharacterId = MainSlot.CharacterId;

		UserCharInfos.Add(Info);
	}

	FRaidUserCharacterInfo JokerInfo;
	JokerInfo.bJoker = true;
	UserCharInfos.Add(JokerInfo);

	for (const FPartySlot& SubSlot : PartyInfo.Sub)
	{
		if (SubSlot.CharacterId.IsInvalid())
		{
			continue;
		}

		FRaidUserCharacterInfo Info;
		Info.CharacterId = SubSlot.CharacterId;

		UserCharInfos.Add(Info);
	}
}

void URaidManager::InitPushHandler()
{
	PushInstance->Init(GameInstance);
}

void URaidManager::ExpireReq(float DeltaTime)
{
	ReqTimeout -= DeltaTime;
	if (ReqTimeout <= 0.f)
	{
		ACTION_DISPATCH_RaidReqTimeout();
		ReqTimeout = 0.f;
	}
}

void URaidManager::ExpireReady(float DeltaTime)
{
	ReadyTimeout -= DeltaTime;
	if (ReadyTimeout <= 0.f)
	{
		ACTION_DISPATCH_RaidReadyTimeout();
		ReadyTimeout = 0.f;
	}
}

void URaidManager::ExpirePrepare(float DeltaTime)
{
	PrepareTimeout -= DeltaTime;
	if (PrepareTimeout <= 0.f)
	{
		if (GetLobbyHUD(GameInstance) == nullptr)
		{
			return;
		}

		const FLobbyUIState* UIState = GetHUDStore().GetUIStateManager().GetUIState();
		if (UIState == nullptr)
		{
			return;
		}

		OpenRaidType = RaidTypeInvalid;
		OpenRaidId = FRaidId::InvalidValue();
		PrepareTimeout = 0.f;

		ACTION_DISPATCH_RaidPrepareTimeout();

		FSagaType SelectedSagaType(0);
		switch (UIState->GetHUDWidgetType())
		{
			case EHUDWidgetType::JokerSelect:
			{
				const FJokerSelectUIState* JokerSelectUIState = UIState->CastToJokerSelectUIState();
				if (JokerSelectUIState == nullptr)
				{
					return;
				}

				SelectedSagaType = JokerSelectUIState->SagaType;
			}
			break;
			case EHUDWidgetType::Party:
			{
				const FPartyUIState* PartyUIState = UIState->CastToPartyUIState();
				if (PartyUIState == nullptr)
				{
					return;
				}

				SelectedSagaType = PartyUIState->SagaType;
			}
			break;
			default:
			{
				return;
			}
		}

		const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SelectedSagaType);
		if (SagaRow.IsInvalid())
		{
			return;
		}

		if (SagaRow.ContentType != EContentType::Raid)
		{
			return;
		}

		GetBaseHUD(GameInstance)->ShowNotification(ENotificationType::Short
			, Q6Util::GetLocalizedText("Lobby", "RaidPrepareTimeout"));

		GetCheckedLobbyHUD(GameInstance)->SetHUDType(EHUDWidgetType::Raid);
	}
}

void URaidManager::OpenRaidJoinPopup(FRaidType RaidType)
{
	if (bMutePopup)
	{
		return;
	}

	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	if (GetCombatHUD(GameInstance)
		&& CombatSeed.Content == EContentType::Raid)
	{
		return;
	}

	ABaseHUD* BaseHUD = GetBaseHUD(GameInstance);
	if (BaseHUD && !Cast<ALoginHUD>(BaseHUD))
	{
		BaseHUD->OpenRaidJoinPopup(RaidType);
	}
}

TArray<FCharHealth> URaidManager::GetCharHealthByUserCharInfo(const TArray<FRaidUserCharacterInfo>& InUserCharInfos) const
{
	TArray<FCharHealth> Out;
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();
	for (const FRaidUserCharacterInfo& CharInfo : InUserCharInfos)
	{
		const FCharacter* Character = CharacterManager.Find(
			FCharacterId(CharInfo.CharacterId));
		if (!Character)
		{
			const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
			switch (JokerInfo.JokerType)
			{
				case EJokerType::SystemJoker:
				case EJokerType::RandomJoker:
				{
					FCharHealth CharHealth;
					CharHealth.CharType = JokerInfo.SystemJoker;
					CharHealth.Health = CharInfo.Health;
					CharHealth.MaxHealth = CharInfo.MaxHealth;
					CharHealth.Joker = CharInfo.bJoker;
					Out.Add(CharHealth);
				}
				break;
			}
			continue;
		}

		FCharHealth CharHealth;
		CharHealth.CharType = Character->GetInfo().Type;
		CharHealth.Health = CharInfo.Health;
		CharHealth.MaxHealth = CharInfo.MaxHealth;
		CharHealth.Joker = CharInfo.bJoker;
		Out.Add(CharHealth);
	}

	return Out;
}

bool URaidManager::SetOngoingStageEndInfoByChronicle(const FString& OngoingChronicle, FC2LRaidStageEnd& Out) const
{
	TSharedPtr<FJsonObject> JsonChronicle;
	TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(OngoingChronicle);
	if (!FJsonSerializer::Deserialize(JsonReader, JsonChronicle) || !JsonChronicle.IsValid())
	{
		return false;
	}

	const TArray<TSharedPtr<FJsonValue>>* JSonActions = nullptr;
	if (!JsonChronicle->TryGetArrayField(TEXT("actions"), JSonActions))
	{
		return false;
	}

	UEnum* ActionTypeEnum = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECCActionType"), true);
	if (!ActionTypeEnum)
	{
		return false;
	}

	UEnum* TurnPhaseEnum = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECCTurnPhase"), true);
	if (!TurnPhaseEnum)
	{
		return false;
	}

	const FString SeedFieldStr(TEXT("seed"));
	const FString AvailableFieldStr(TEXT("available"));
	const FString IndexFieldStr(TEXT("index"));
	const FString ArtifactAvailableFieldStr(TEXT("artifactAvailable"));
	const FString ChangePhaseFieldStr(TEXT("changePhase"));
	const FString bGemContinueFieldStr(TEXT("bGemContinue"));

	int32 GemWipeoutContinueCount(0);
	int32 FinalTurnCount(1);
	ECCTurnPhase FinalTurnPhase(ECCTurnPhase::Prepare);
	TArray<bool> Artifacts;
	Artifacts.Reserve(MAX_ARTIFACT_COUNT);

	for (const auto& JSonAction : *JSonActions)
	{
		const TSharedPtr<FJsonObject>& JsonActionObject = JSonAction->AsObject();

		const TSharedPtr<FJsonObject>& JSonActionStructObject = JsonActionObject->GetObjectField(TEXT("Action"));

		FString ActionTypeStr = JsonActionObject->GetStringField(TEXT("ActionType"));
		ECCActionType InActionType = static_cast<ECCActionType>(ActionTypeEnum->GetValueByName(*ActionTypeStr));
		switch (InActionType)
		{
			case ECCActionType::InitCombatCube:
			{
				if (!JSonActionStructObject->TryGetField(SeedFieldStr))
				{
					return false;
				}

				const TSharedPtr<FJsonObject>& FCCCombatSeedStructObject = JSonActionStructObject->GetObjectField(SeedFieldStr);

				if (!FCCCombatSeedStructObject->TryGetField(SeedFieldStr))
				{
					return false;
				}

				const TSharedPtr<FJsonObject>& FCombatSeedStructObject = FCCCombatSeedStructObject->GetObjectField(SeedFieldStr);

				const TArray<TSharedPtr<FJsonValue>>* ArtifactAvailable = nullptr;
				if (!FCombatSeedStructObject->TryGetArrayField(ArtifactAvailableFieldStr, ArtifactAvailable))
				{
					return false;
				}

				for (const auto& Artifact : *ArtifactAvailable)
				{
					const TSharedPtr<FJsonObject>& ArtifactObject = Artifact->AsObject();
					if (!ArtifactObject->TryGetField(AvailableFieldStr))
					{
						return false;
					}

					bool bAvailable = ArtifactObject->GetBoolField(AvailableFieldStr);
					Artifacts.Add(bAvailable);
				}
			}
			break;
			case ECCActionType::ChangePhaseTo:
			{
				if (JSonActionStructObject->TryGetField(ChangePhaseFieldStr))
				{
					FString ChangePhase = JSonActionStructObject->GetStringField(ChangePhaseFieldStr);
					int64 EnumIndex = TurnPhaseEnum->GetValueByName(*ChangePhase);
					if (EnumIndex == INDEX_NONE)
					{
						return false;
					}

					FinalTurnPhase = static_cast<ECCTurnPhase>(EnumIndex);
					if (FinalTurnPhase == ECCTurnPhase::OppAttack)
					{
						++FinalTurnCount;
					}
				}
			}
			break;
			case ECCActionType::WipeoutContinue:
			{
				if (JSonActionStructObject->TryGetField(bGemContinueFieldStr))
				{
					bool bGemContinue = JSonActionStructObject->GetBoolField(bGemContinueFieldStr);
					if (bGemContinue)
					{
						++GemWipeoutContinueCount;
					}
				}
			}
			break;
			case ECCActionType::UseArtifact:
			{
				if (JSonActionStructObject->TryGetField(IndexFieldStr))
				{
					int32 ArtifactIndex = JSonActionStructObject->GetBoolField(IndexFieldStr);

					if (!Artifacts.IsValidIndex(ArtifactIndex))
					{
						return false;
					}

					Artifacts[ArtifactIndex] = false;
				}
			}
			break;
		}
	}

	Out.ArtifactAvailable = Artifacts;
	Out.GemWipeoutContinueCount = GemWipeoutContinueCount;
	Out.TurnPhase = static_cast<int32>(FinalTurnPhase);
	Out.FinalTurnCount = FinalTurnCount;

	return true;
}

void URaidManager::ChangeJokerSelectHUDWidget(const FRaidType RaidType)
{
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (SagaRow.ContentType != EContentType::Raid)
	{
		return;
	}

	ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance);
	if (!LobbyHUD)
	{
		return;
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	if (SagaRow.WattConsume > WorldUser.GetWatt())
	{
		LobbyHUD->OpenWattRechargePopup();
		return;
	}

	ACTION_DISPATCH_JokerSelect(SagaRow.CmsType(), true);
	LobbyHUD->ChangeHUDType(EHUDWidgetType::JokerSelect, true);
}

int64 URaidManager::GetRaidEnemyTotalHealth(const FRaidType RaidType) const
{
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RaidType);
	if (RaidRow.IsInvalid())
	{
		return 0;
	}

	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(SagaRow.CmsType(), 0);
	if (!WaveRow)
	{
		return 0;
	}

	TMap<FUnitType, int32> Enemies;
	Enemies.Emplace(
		FUnitType(WaveRow->Spawns01.IsValidIndex(0) ? WaveRow->Spawns01[0] : 0), WaveRow->Spawn01Level);
	Enemies.Emplace(
		FUnitType(WaveRow->Spawns02.IsValidIndex(0) ? WaveRow->Spawns02[0] : 0), WaveRow->Spawn02Level);
	Enemies.Emplace(
		FUnitType(WaveRow->Spawns03.IsValidIndex(0) ? WaveRow->Spawns03[0] : 0), WaveRow->Spawn03Level);

	int64 TotalHealth(0);
	for (const TPair<FUnitType, int32>& Enemy : Enemies)
	{
		const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(Enemy.Key);
		if (UnitRow.IsInvalid())
		{
			continue;
		}

		const FCMSAdditionalPointRow* AdditionalPointRow = GetCMS()->GetAdditionalPoint(
			SagaRow.Difficulty, UnitRow.AttributeCategory);
		if (!AdditionalPointRow)
		{
			continue;
		}

		int64 MaxHealth(0);
		int64 Atk(0);
		int64 Def(0);
		Attribute::GetUnitAttribute(GetCMS(), UnitRow.AttributeCategory, Enemy.Key
			, Enemy.Value, AdditionalPointRow->Grade, AdditionalPointRow, MaxHealth, Atk, Def);

		TotalHealth += MaxHealth;
	}

	return TotalHealth;
}

#if !UE_BUILD_SHIPPING
void URaidManager::ReqDevOpen(FRaidType Type) const
{
	FC2LDevRaidOpen Out;
	Out.RaidType = Type;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/raidOpen"), Out,
		TQ6ResponseDelegate<FL2CRaidCanEnterNof>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidCanEnterResp));
}

void URaidManager::ReqDevEnter() const
{
	if (OpenRaidType == RaidTypeInvalid ||
		OpenRaidId == FRaidId::InvalidValue())
	{
		Q6JsonLogRoze(Warning, "enter raid invalid type or id");
		return;
	}

	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();

	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(OpenRaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (SagaRow.Type != CombatSeed.SagaType)
	{
		return;
	}

	FC2LDevRaidEnter Out;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	Out.RaidType = OpenRaidType;
	Out.RaidId = OpenRaidId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/raidEnter"), Out,
		TQ6ResponseDelegate<FL2CRaidEnterNof>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidEnterNof));
}

void URaidManager::ReqDevRaidFinalStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();

	FC2LDevRaidFinalStageBegin Out;
	Out.RaidId = SelectedRaidFinalId;
	Out.RaidType = SelectedRaidFinalType;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("dev/raidFinalStageBegin"), Out,
		TQ6ResponseDelegate<FL2CRaidFinalStageBeginResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidFinalStageBeginResp));
}
#endif

void URaidManager::ReqOpen() const
{
	// should check required watt(CMS, amend watt)
	FC2LRaidOpen Out;
	Out.RaidType = FoundRaidType;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("raid/open"), Out,
		TQ6ResponseDelegate<FL2CRaidCanEnterNof>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidCanEnterResp));
}

void URaidManager::ReqPrepare() const
{
	GameInstance->ClearBanIndices();

	FC2LRaidPrepare Out;
	Out.RaidId = OpenRaidId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("raid/prepare"), Out,
		TQ6ResponseDelegate<FL2CRaidPrepareResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidPrepareResp));
}

void URaidManager::ReqUseEmoticon(int32 Emoticon) const
{
	if (OpenRaidId == FRaidId::InvalidValue()) {
		Q6JsonLogHekel(Warning, "Invalid Raid Id Use Emoticon Request");
		return;
	}

	FC2LRaidUseEmoticon Out;
	Out.RaidId = OpenRaidId;
	Out.Emoticon = Emoticon;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("raid/useEmoticon"), Out,
		TQ6ResponseDelegate<FL2CRaidEmoticonNof>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidUseEmoticonResp));
}

void URaidManager::ReqEnter() const
{
	if (OpenRaidType == RaidTypeInvalid ||
		OpenRaidId == FRaidId::InvalidValue())
	{
		Q6JsonLogHekel(Warning, "enter raid invalid type or id");
		return;
	}

	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();

	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(OpenRaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (SagaRow.Type != CombatSeed.SagaType)
	{
		return;
	}

	FC2LRaidEnter Out;

	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	Out.RaidType = OpenRaidType;
	Out.RaidId = OpenRaidId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("raid/enter"), Out,
		TQ6ResponseDelegate<FL2CRaidEnterNof>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidEnterNof));
}

void URaidManager::ReqStageEnd(const UCCEndGameEvent* Event
	, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	FC2LRaidStageEnd Out;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.Result = static_cast<int32>(Event->Result);
	Out.TurnPhase = static_cast<int32>(Event->TurnPhase);

	Out.IsCleared = false;
	switch (Event->EndReason)
	{
		case ECCEndReason::ClearUnits:
		case ECCEndReason::None:
		{
			Out.IsCleared = true;
		}
		break;
	}

	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;
	Out.RaidId = OpenRaidId;
	Out.RaidType = OpenRaidType;
	Out.Mission = CombatMissionInfo.WeeklyCombatMissionInfo;
	Out.CharMission = CombatMissionInfo.CharCombatMissionInfo;
	Out.CharHealths = GetCharHealthByUserCharInfo(UserCharInfos);

	ClientNetwork.WsRequest("raid/stageEnd", Out,
		TQ6ResponseDelegate<FL2CRaidStageEndResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidStageEndResp));
}

void URaidManager::ReqOngoingStageEnd(const FSagaType& NotFinishedSagaType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const UQ6SaveGame* SaveGameInstance = GameInstance->GetSaveGame();
	if (!SaveGameInstance)
	{
		Q6JsonLogGenie(Warning, "Ongoing Raid StageEnd Fail - UQ6SaveGame does not exist.");
		return;
	}

	const FString OngoingChronicle = GameInstance->GetOngoingChronicle();
	if (OngoingChronicle.IsEmpty())
	{
		Q6JsonLogGenie(Warning, "Ongoing Raid StageEnd Fail - OngoingChronicle does not exist.");
		return;
	}

	FC2LRaidStageEnd Out;

	Out.SagaType = NotFinishedSagaType;
	Out.Party = SaveGameInstance->GetSavedPartySlot();
	Out.Result = static_cast<int32>(ECCResult::Win);
	Out.IsCleared = false;
	Out.Chronicle = OngoingChronicle;
	Out.RaidId = SaveGameInstance->GetRaidId();
	Out.RaidType = GetCMS()->GetRaidTypeBySagaType(NotFinishedSagaType);

	if (!SetOngoingStageEndInfoByChronicle(OngoingChronicle, Out))
	{
		Q6JsonLogGenie(Warning, "Ongoing Raid StageEnd Fail - SetOngoingStageEndInfoByChronicle fail");
		return;
	}

	ClientNetwork.WsRequest("raid/stageEnd", Out,
		TQ6ResponseDelegate<FL2CRaidStageEndResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidStageEndResp));
}

void URaidManager::ReqSkillUsed(const TArray<FRaidSkillUsedElement>& Elements, const int32 Damage) const
{
	TArray<FCharSkill> CharSkills;
	CharSkills.Reserve(MAX_RAID_TURN_SKILL_USED);

	const UCharacterManager& CharMan = GetHUDStore().GetCharacterManager();

	for (const FRaidSkillUsedElement& Elem : Elements)
	{
		const FCharacter* Found = CharMan.Find(Elem.UsedChar);
		if (Found)
		{
			const FCharacterInfo& CharacterInfo = Found->GetInfo();
			const FCharacterBond& CharacterBond = GetHUDStore().GetBondManager().GetCharacterBond(CharacterInfo.Type);
			const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(CharacterInfo.Type);

			FCharSkill CharSkill;
			CharSkill.Slot = Elem.Slot;
			CharSkill.CharInfo = CharacterInfo;
			CharSkill.NatureType = UnitRow.NatureType;
			CharSkill.Skill = Elem.UsedSkill;
			CharSkill.SupportSkillLevel = CharacterBond.SupportSkillLevel;
			CharSkill.UserName = GetUser().GetNickname();
			CharSkill.UserId = GetUser().GetId();
			CharSkill.Attributes = Elem.Attributes;

			CharSkills.Add(CharSkill);
		}

		if (CharSkills.Num() == MAX_RAID_TURN_SKILL_USED)
		{
			FC2LRaidSkillUsed Out;
			Out.RaidId = OpenRaidId;
			Out.Damage = Damage;
			Out.Skills = CharSkills;

			FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
			ClientNetwork.WsRequest("raid/skillUsed", Out,
				TQ6ResponseDelegate<FL2CRaidSkillsNof>::CreateUObject(
					const_cast<URaidManager*>(this), &URaidManager::OnRaidSkillsNof));

			CharSkills.Reset();
		}
	}

	FC2LRaidSkillUsed Out;
	Out.RaidId = OpenRaidId;
	Out.Damage = Damage;
	Out.Skills = CharSkills;

	if (SupportSkillsUse.Num() != 0)
	{
		Out.SupportSkillsUse = SupportSkillsUse;
	}

	if (SupportSkillsHas.Num() != 0)
	{
		Out.SupportSkillsHas = SupportSkillsHas;
	}

	Out.CharHealths = GetCharHealthByUserCharInfo(UserCharInfos);

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest("raid/skillUsed", Out,
		TQ6ResponseDelegate<FL2CRaidSkillsNof>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidSkillsNof));
}

void URaidManager::ReqShareParty(TArray<FRaidUserCharacterInfo>& CharInfos) const
{
	FC2LRaidShareParty Out;
	Out.RaidId = OpenRaidId;

	Out.Healths = GetCharHealthByUserCharInfo(CharInfos);

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("raid/shareParty"), Out,
		TQ6ResponseDelegate<FL2CRaidSharePartyResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidSharePartyResp));
}

void URaidManager::ReqRegularRaidRegister(const FRegularRaidInfo& Info) const
{
	FC2LRegularRaidRegister Out;
	Out.Info = Info;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("regularRaid/register"), Out,
		TQ6ResponseDelegate<FL2CRegularRaidRegisterResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRegularRaidRegisterResp));
}

void URaidManager::ReqRegularRaidReady(const FRegularRaidInfo& Info) const
{
	const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(
		RegularRaidState.ScheduleId);
	if (ScheduleInfo)
	{
		FDateTime CustomDate2 = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate2);
		FDateTime NowDate = FDateTime::Now();
		if (NowDate > CustomDate2)
		{
			ACTION_DISPATCH_UpdateRaidWhenEnterMenu();
			return;
		}
	}

	FC2LRegularRaidReady Out;
	Out.Info = Info;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("regularRaid/ready"), Out,
		TQ6ResponseDelegate<FL2CRegularRaidReadyResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRegularRaidReadyResp));
}

void URaidManager::ReqRaidFinalStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LRaidFinalStageBegin Out;
	Out.RaidId = SelectedRaidFinalId;
	Out.RaidType = SelectedRaidFinalType;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("raidFinal/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CRaidFinalStageBeginResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidFinalStageBeginResp));
}

void URaidManager::ReqRaidFinalStageEnd(const UCCEndGameEvent* Event, const FString& Chronicle) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	FC2LRaidFinalStageEnd Out;
	Out.RaidId = SelectedRaidFinalId;
	Out.RaidType = SelectedRaidFinalType;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.RaidEnemyTotalHealth = GetRaidEnemyTotalHealth(Out.RaidType);
	Out.Chronicle = Chronicle;

	ClientNetwork.WsRequest("raidFinal/stageEnd", Out,
		TQ6ResponseDelegate<FL2CRaidFinalStageEndResp>::CreateUObject(
			const_cast<URaidManager*>(this), &URaidManager::OnRaidFinalStageEndResp));
}

void URaidManager::OnRaidStageEndResp(const FResError* Error, const FL2CRaidStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ResetRaid();
	ResetRegularRaidState();

	Q6JsonLogHekel(Verbose, "raid stage end", Q6KV("Saga", Res.SagaType));
	ACTION_DISPATCH_RaidStageEndResp(Res);
}

void URaidManager::OnRaidSkillUsedResp(const FResError* Error, const FL2CRaidSkillUsedResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	Q6JsonLogHekel(Verbose, "raid skill used", Q6KV("Raid Id", Res.RaidId));
	ACTION_DISPATCH_RaidSkillUsedResp(Res);
}

void URaidManager::OnRaidSkillsNof(const FResError* Error, const FL2CRaidSkillsNof& Nof)
{
	if (Error)
	{
		GetBaseHUD(GameInstance)->OnError(Error);
		return;
	}

	Q6JsonLogHekel(Verbose, "raid skills nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("Skills", Nof.Skills.Num()),
		Q6KV("TotalDamage", Nof.TotalDamage));

	ClearRaidSkills();
	ReqTimeout = RAID_REQ_TIMEOUT;

	ACTION_DISPATCH_RaidSkillsNof(Nof);
}

void URaidManager::OnRaidOpenNof(const FL2CRaidOpenNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid open nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("Type", Nof.RaidType),
		Q6KV("From", Nof.UserName));

	if (OpenRaidType != RaidTypeInvalid
		&& OpenRaidId != FRaidId::InvalidValue())
	{
		return;
	}

	ACTION_DISPATCH_RaidOpenNof(Nof);
}

void URaidManager::OnRaidCanEnterNof(const FL2CRaidCanEnterNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid can enter nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("Type", Nof.RaidType),
		Q6KV("From", Nof.UserName));

	ACTION_DISPATCH_RaidCanEnterNof(Nof);
}

void URaidManager::OnRaidCanEnterResp(const FResError* Error, const FL2CRaidCanEnterNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid can enter nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("Type", Nof.RaidType),
		Q6KV("From", Nof.UserName));

	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RaidCanEnterNof(Nof);
}

void URaidManager::OnRaidEnterNof(const FResError* Error, const FL2CRaidEnterNof& Nof)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	Q6JsonLogHekel(Verbose, "raid enter nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("Type", Nof.RaidType),
		Q6KV("Saga", Nof.SagaType),
		Q6KV("StartTime", Nof.CombatSeed.StartBattleEpoch));

	if (!Nof.Ok)
	{
		Q6JsonLogGenie(Verbose, "raid enter failed", Q6KV("RaidId", Nof.RaidId));
		return;
	}

	ReqTimeout = RAID_REQ_TIMEOUT;
	PrepareTimeout = 0.0f;

	if (GameInstance)
	{
		GameInstance->OnBeginRaid(Nof);
		GameInstance->SetRaidId(Nof.RaidId);

		InitUserCharInfo();
	}

	for (const FRaidUserInfo& UserInfo : Nof.UserInfos)
	{
		UpdateRaidUserInfos(Nof.RaidId, UserInfo);
	}
}

void URaidManager::OnRaidPrepareResp(const FResError* Error, const FL2CRaidPrepareResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	Q6JsonLogHekel(Verbose, "raid prepared resp",
		Q6KV("Id", Res.RaidId),
		Q6KV("LeftSec", Res.LeftSec),
		Q6KV("Ok", Res.Ok));

	if (!Res.Ok)
	{
		GetBaseHUD(GameInstance)->ShowNotification(ENotificationType::Short
			, Q6Util::GetLocalizedText("Lobby", "RaidPrepareUserFull"));

		ResetRaid();

		ACTION_DISPATCH_RaidPrepareResp(Res);
		return;
	}

	ChangeJokerSelectHUDWidget(OpenRaidType);

	ACTION_DISPATCH_RaidPrepareResp(Res);
}

void URaidManager::OnRaidStageEndNof(const FL2CRaidStageEndNof& Nof)
{
	Q6JsonLogHekel(Verbose, "stage end nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("UserId", Nof.UserId),
		Q6KV("UserName", Nof.UserName));

	ACTION_DISPATCH_RaidStageEndNof(Nof);
}

void URaidManager::OnRaidFullNof(const FL2CRaidFullNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid full nof",
		Q6KV("Id", Nof.RaidId));

	ABaseHUD* BaseHUD = GetBaseHUD(GameInstance);
	if (BaseHUD)
	{
		BaseHUD->CloseRaidJoinPopup();
	}

	ACTION_DISPATCH_RaidFullNof(Nof);
}

void URaidManager::OnRaidKickTimeoutNof(const FL2CRaidKickTimeoutNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid kick timeout nof",
		Q6KV("Id", Nof.RaidId));

	ABaseHUD* BaseHUD = GetBaseHUD(GameInstance);
	if (BaseHUD)
	{
		BaseHUD->CloseRaidJoinPopup();
	}

	ACTION_DISPATCH_RaidKickTimeoutNof(Nof);
}

void URaidManager::OnRaidEndNof(const FL2CRaidEndNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid end nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("Type", Nof.RaidType));

	ACTION_DISPATCH_RaidEndNof(Nof);
}

void URaidManager::OnRaidUseEmoticonResp(const FResError* Error, const FL2CRaidEmoticonNof& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RaidEmoticonNof(Res);
}

void URaidManager::OnRaidSharePartyResp(const FResError* Error, const FL2CRaidSharePartyResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RaidSharePartyResp(Res);
}

void URaidManager::OnRegularRaidRegisterResp(const FResError* Error, const FL2CRegularRaidRegisterResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RegularRaidRegisterResp(Res);
}

void URaidManager::OnRegularRaidReadyResp(const FResError* Error, const FL2CRegularRaidReadyResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RegularRaidReadyResp(Res);
}

void URaidManager::OnRegularRaidMatchedNoti(const FL2CRegularRaidNotiMatched& Noti)
{
	Q6JsonLog(Verbose, "regular-raid-matched", Q6KV("RaidId", Noti.Info.RaidId));

	if (Noti.Info.RaidId == FRaidId::InvalidValue()) {
		Q6JsonLog(Warning, "invalid-raid-id", Q6KV("RaidId", Noti.Info.RaidId));
		return;
	}

	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(Noti.Info.Type);
	if (RaidRow.IsInvalid())
	{
		Q6JsonLog(Warning, "invalid-raid-type", Q6KV("RaidType", Noti.Info.Type));
		return;
	}

	ACTION_DISPATCH_RegularRaidMatchedNoti(Noti);
}

void URaidManager::OnRaidBossHealthNof(const FL2CRaidBossHealthNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid boss health nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("TotalDamage", Nof.TotalDamage));

	ACTION_DISPATCH_RaidBossHealthNof(Nof);
}

void URaidManager::OnRaidEmoticonNof(const FL2CRaidEmoticonNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid emoticon nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("User", Nof.UserName),
		Q6KV("Emoticon", Nof.Emoticon));

	ACTION_DISPATCH_RaidEmoticonNof(Nof);
}

void URaidManager::OnRaidSharePartyNof(const FL2CRaidSharePartyNof& Nof)
{
	Q6JsonLogHekel(Verbose, "raid share party nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("User", Nof.UserName));

	ACTION_DISPATCH_RaidSharePartyNof(Nof);
}

void URaidManager::OnRaidFinalStageBeginResp(const FResError* Error, const FL2CRaidFinalStageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnRaidFinalStageBegin(Res);
}

void URaidManager::OnRaidFinalStageEndResp(const FResError* Error, const FL2CRaidFinalStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnRaidFinalStageEnd(Res);
}

void URaidManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(URaidManager, RaidListResp);
	REGISTER_ACTION_HANDLER(URaidManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, RaidStageEndNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidReqTimeout);
	REGISTER_ACTION_HANDLER(URaidManager, RaidOpenNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidCanEnterNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidPrepareResp);
	REGISTER_ACTION_HANDLER(URaidManager, RaidOpenNofTimeout);
	REGISTER_ACTION_HANDLER(URaidManager, RaidReadyTimeout);
	REGISTER_ACTION_HANDLER(URaidManager, RaidPrepareTimeout);
	REGISTER_ACTION_HANDLER(URaidManager, RaidSkillUsedResp);
	REGISTER_ACTION_HANDLER(URaidManager, RaidEnterNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidSkillsNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidEndNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidEnterNofTimeout);
	REGISTER_ACTION_HANDLER(URaidManager, RaidBossHealthNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidEmoticonNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, RaidClearData);
	REGISTER_ACTION_HANDLER(URaidManager, MuteRaidJoinPopup);
	REGISTER_ACTION_HANDLER(URaidManager, RaidSelectFinal);
	REGISTER_ACTION_HANDLER(URaidManager, RaidClearFoundType);
	REGISTER_ACTION_HANDLER(URaidManager, RaidClearSkills);
	REGISTER_ACTION_HANDLER(URaidManager, RaidCharInfos);
	REGISTER_ACTION_HANDLER(URaidManager, RaidSetSkills);
	REGISTER_ACTION_HANDLER(URaidManager, RaidSharePartyResp);
	REGISTER_ACTION_HANDLER(URaidManager, RaidSharePartyNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidFullNof);
	REGISTER_ACTION_HANDLER(URaidManager, RaidKickTimeoutNof);
	REGISTER_ACTION_HANDLER(URaidManager, RegularRaidRegisterResp);
	REGISTER_ACTION_HANDLER(URaidManager, RegularRaidReadyResp);
	REGISTER_ACTION_HANDLER(URaidManager, RegularRaidMatchedNoti);

	REGISTER_ACTION_HANDLER(URaidManager, SetOnGoingRaid);
	REGISTER_ACTION_HANDLER(URaidManager, UpdateRaidWhenEnterMenu);
	REGISTER_ACTION_HANDLER(URaidManager, RaidPrepareTime);

	REGISTER_ACTION_HANDLER(URaidManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(URaidManager, EventContentMultiSideBattleStageEndResp);
}

void URaidManager::OnListResp(const FResError* Error, const FL2CRaidListResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	Q6JsonLogPaul(Verbose, "Raid List", Q6KV("Total", Res.RaidFinals.Num()));
	for (const FRaidFinalInfo& RaidFinalInfo : Res.RaidFinals)
	{
		Q6JsonLogPaul(Verbose, "RaidFinalInfo", Q6KV("Id", RaidFinalInfo.RaidId), Q6KV("RaidType", RaidFinalInfo.Type));
	}

	ACTION_DISPATCH_RaidListResp(Res);
	GameInstance->ReqNextContent();
}

void URaidManager::AddRaidFinal(const FRaidFinalInfo& Info)
{
	if (Info.RaidId.IsInvalid()) {
		return;
	}

	if (Info.RewardUtc > 0)
	{
		return;
	}

	const FRaidFinal* RaidFinal = RaidFinals.Find(Info.RaidId);
	if (RaidFinal && RaidFinal->GetRaidEnded() == true)
	{
		return;
	}

	RaidFinals.Add(Info.RaidId, Info);
	SortRaidFinalList();
}

void URaidManager::RemoveRaidFinal(FRaidId Id)
{
	if (TodayRaidClearInfo.Date < FDateTime::Today())
	{
		TodayRaidClearInfo.TodayRaidClear = false;
		TodayRaidClearInfo.Date = FDateTime::Today();
	}

	if (!TodayRaidClearInfo.TodayRaidClear)
	{
		const FRaidFinal* RaidFinal = RaidFinals.Find(Id);
		if (RaidFinal)
		{
			FDateTime StartDateTime = Q6Util::UtcTimestampToLocalDateTime(RaidFinal->GetInfo().StartUtc);
			if (StartDateTime >= FDateTime::Today())
			{
				TodayRaidClearInfo.TodayRaidClear = true;
			}
		}
	}

	RaidFinals.Remove(Id);
	SortRaidFinalList();
}

void URaidManager::UpdateRaidUserInfos(const FRaidId& RaidId, const FRaidUserInfo& UserInfo)
{
	FRaidParticipateUserInfo* FindUserInfo = RaidUserInfos.Find(UserInfo.UserId);
	if (FindUserInfo)
	{
		FindUserInfo->RaidId = RaidId;
		FindUserInfo->UserId = UserInfo.UserId;
		FindUserInfo->Score = UserInfo.Score;
		FindUserInfo->TurnCount = UserInfo.TurnCount;
		FindUserInfo->End = UserInfo.EndUtc > 0;
		FindUserInfo->UserName = UserInfo.UserName;
		FindUserInfo->Healths = UserInfo.CharHealths;
	}
	else
	{
		FRaidParticipateUserInfo NewUserInfo;
		NewUserInfo.RaidId = RaidId;
		NewUserInfo.UserId = UserInfo.UserId;
		NewUserInfo.Score = UserInfo.Score;
		NewUserInfo.TurnCount = UserInfo.TurnCount;
		NewUserInfo.End = UserInfo.EndUtc > 0;
		NewUserInfo.UserName = UserInfo.UserName;
		NewUserInfo.Healths = UserInfo.CharHealths;

		RaidUserInfos.Emplace(NewUserInfo.UserId, NewUserInfo);
	}
}

void URaidManager::ResetRaid()
{
	OpenRaidType = RaidTypeInvalid;
	OpenRaidId = ClearedRaidId = FRaidId::InvalidValue();
	FoundRaidType = RaidTypeInvalid;
	ReadyTimeout = 0.f;
	ReqTimeout = 0.f;
	TotalDamage = 0;
	PrepareTimeout = 0.f;
	RaidLeftSec = 0.f;
	RaidJoinPopupMuteElapsedTime = 0.f;

	bMutePopup = false;

	RaidRankingInfos.Empty();
	RaidRealTimeRankInfos.Empty();
	RaidUserInfos.Empty();
}

void URaidManager::ResetRegularRaidState()
{
	RegularRaidState.RaidType = RaidTypeInvalid;
	RegularRaidState.ScheduleId = 0;
	RegularRaidState.RaidId = FRaidId::InvalidValue();
	RegularRaidState.Registered = false;
	RegularRaidState.Matched = false;
	RegularRaidState.WaitForReqReady = false;
	RegularRaidState.RespReady = false;
}

void URaidManager::ResetTodayRaidClear()
{
	if (TodayRaidClearInfo.Date < FDateTime::Today())
	{
		TodayRaidClearInfo.TodayRaidClear = false;
		TodayRaidClearInfo.Date = FDateTime::Today();
	}

	if (TodayRaidClearInfo.TodayRaidClear)
	{
		return;
	}

	for (const TPair<FRaidId, FRaidFinal>& RaidFinal : RaidFinals)
	{
		const FRaidFinalInfo& RaidFinalInfo = RaidFinal.Value.GetInfo();

		FDateTime StartDateTime = Q6Util::UtcTimestampToLocalDateTime(RaidFinalInfo.StartUtc);
		if (RaidFinalInfo.RewardUtc > 0
			&& StartDateTime >= FDateTime::Today())
		{
			TodayRaidClearInfo.TodayRaidClear = true;
			break;
		}
	}
}

void URaidManager::CheckRegularRaidOpen()
{
	UHUDStore& HUDStore = GetHUDStore();
	FSagaType LastSagaType = HUDStore.GetSagaManager().GetLastSagaType();
	if (LastSagaType < SystemConst::Q6_RAID_CERTIFICATE_SAGA)
	{
		ResetRegularRaidState();
		return;
	}

	if ((OpenRaidId != FRaidId::InvalidValue() && OpenRaidType != RaidTypeInvalid)
		|| RegularRaidState.Registered)
	{
		return;
	}

	FRaidType RaidType(RaidTypeInvalid);
	int32 ScheduleId(0);
	TArray<const FCMSRaidRow*> RaidRows = GetCMS()->GetRaidRows();
	for (const FCMSRaidRow* RaidRow : RaidRows)
	{
		if (!RaidRow)
		{
			continue;
		}

		for (const int32 RegularRaidScheduleId : RaidRow->RegularRaidScheduleIds)
		{
			const FEventScheduleInfo* ScheduleInfo = HUDStore.GetEventManager().GetEventSchedule(
				RegularRaidScheduleId);
			if (!ScheduleInfo)
			{
				continue;
			}

			FDateTime StartDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->StartDate);
			FDateTime CustomDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate);
			FDateTime NowDate = FDateTime::Now();
			if (StartDate <= NowDate && NowDate < CustomDate)
			{
				RaidType = RaidRow->CmsType();
				ScheduleId = RegularRaidScheduleId;
				break;
			}
		}
	}

	if (RaidType != RegularRaidState.RaidType
		|| ScheduleId != RegularRaidState.ScheduleId)
	{
		ResetRegularRaidState();
		RegularRaidState.RaidType = RaidType;
		RegularRaidState.ScheduleId = ScheduleId;
	}
}

bool URaidManager::IsValidRaid() const
{
	if (OpenRaidId == FRaidId::InvalidValue())
	{
		return false;
	}

	if (OpenRaidType == RaidTypeInvalid)
	{
		return false;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidListResp)
{
	const auto& Action = ACTION_PARSE_RaidListResp(InAction);
	auto& Resp = Action->GetVal();

	TodayRaidType = Resp.TodayRaidType;

	if (TodayRaidClearInfo.Date < FDateTime::Today())
	{
		TodayRaidClearInfo.TodayRaidClear = false;
		TodayRaidClearInfo.Date = FDateTime::Today();
	}

	for (const FRaidFinalInfo& Info : Resp.RaidFinals)
	{
		AddRaidFinal(Info);

		if (!TodayRaidClearInfo.TodayRaidClear)
		{
			FDateTime StartDateTime = Q6Util::UtcTimestampToLocalDateTime(Info.StartUtc);
			if (Info.RewardUtc > 0
				&& StartDateTime >= FDateTime::Today())
			{
				TodayRaidClearInfo.TodayRaidClear = true;
			}
		}
	}

	if (!Resp.OpenedRaidId.IsInvalid())
	{
		OpenRaidId = Resp.OpenedRaidId;
		OpenRaidType = Resp.OpenedRaidType;
	}
	else
	{
		if (Resp.RegisteredRegularRaid.RaidType != RaidTypeInvalid)
		{
			RegularRaidState.RaidType = Resp.RegisteredRegularRaid.RaidType;
			RegularRaidState.ScheduleId = Resp.RegisteredRegularRaid.ScheduleId;
			RegularRaidState.Registered = true;
		}
	}

	for (const FRaidUserInfo& UserInfo : Resp.UserInfos)
	{
		UpdateRaidUserInfos(Resp.OpenedRaidId, UserInfo);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidStageEndResp)
{
	const auto& Action = ACTION_PARSE_RaidStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	ClearedRaidId = Resp.RaidFinalInfo.RaidId;
	AddRaidFinal(Resp.RaidFinalInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidReqTimeout)
{
	ReqTimeout = 0.f;
	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidReadyTimeout)
{
	OpenRaidType = RaidTypeInvalid;
	OpenRaidId = FRaidId::InvalidValue();
	ReadyTimeout = 0.f;
	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidPrepareTimeout)
{
	if (RegularRaidState.Matched && RegularRaidState.RaidType)
	{
		ResetRegularRaidState();
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidOpenNofTimeout)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidEnterNofTimeout)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidSkillUsedResp)
{
	ReqTimeout = 0.f;

	auto Action = ACTION_PARSE_RaidSkillUsedResp(InAction);
	auto& Res = Action->GetVal();
	if (OpenRaidId != Res.RaidId)
	{
		Q6JsonLogHekel(Warning, "not matching raid skill use request",
			Q6KV("Open", OpenRaidId),
			Q6KV("Req", Res.RaidId));
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidCanEnterNof)
{
	ReqTimeout = 0.f;

	auto Action = ACTION_PARSE_RaidCanEnterNof(InAction);
	auto& Nof = Action->GetVal();

	if (Nof.RaidId == FRaidId::InvalidValue()) {
		Q6JsonLogHekel(Warning, "invalid raid open", Q6KV("Type", Nof.RaidType));
		return true;
	}

	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(Nof.RaidType);
	if (RaidRow.IsInvalid())
	{
		Q6JsonLogHekel(Warning, "invalid raid can enter", Q6KV("Type", Nof.RaidType));
		return true;
	}

	Q6JsonLogHekel(Verbose, "raid can enter nof",
		Q6KV("Id", Nof.RaidId),
		Q6KV("Type", Nof.RaidType));

	OpenRaidType = Nof.RaidType;
	OpenRaidId = Nof.RaidId;

	OpenRaidJoinPopup(Nof.RaidType);

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidOpenNof)
{
	auto Action = ACTION_PARSE_RaidOpenNof(InAction);
	auto& Nof = Action->GetVal();

	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(Nof.RaidType);
	if (RaidRow.IsInvalid())
	{
		Q6JsonLogHekel(Warning, "invalid raid opened", Q6KV("Type", Nof.RaidType));
		return false;
	}

	OpenRaidType = Nof.RaidType;
	OpenRaidId = Nof.RaidId;

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidPrepareResp)
{
	auto Action = ACTION_PARSE_RaidPrepareResp(InAction);
	auto& Resp = Action->GetVal();

	ReqTimeout = 0.f;

	if (Resp.RaidId != OpenRaidId)
	{
		Q6JsonLogHekel(Warning, "invalid raid prepare", Q6KV("RaidId", Resp.RaidId));
		return true;
	}

	if (!Resp.Ok)
	{
		Q6JsonLogHekel(Verbose, "prepare failed", Q6KV("RaidId", Resp.RaidId));
		return true;
	}

	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(OpenRaidType);
	if (RaidRow.IsInvalid())
	{
		Q6JsonLogHekel(Warning, "invalid raid prepare", Q6KV("Type", OpenRaidType));
		return true;
	}

	RaidLeftSec = Resp.LeftSec;
	PrepareTimeout = static_cast<float>(RaidRow.PrepareSec);

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidEnterNof)
{
	auto Action = ACTION_PARSE_RaidEnterNof(InAction);
	auto& Nof = Action->GetVal();

	OpenRaidType = Nof.RaidType;
	OpenRaidId = Nof.RaidId;

	ReqTimeout = 0.f;
	ReadyTimeout = 0.f;
	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidEndNof)
{
	auto Action = ACTION_PARSE_RaidEndNof(InAction);
	auto& Nof = Action->GetVal();

	AddRaidFinal(Nof.RaidFinalInfo);

	if (OpenRaidId == Nof.RaidId)
	{
		ResetRaid();
	}

	if(RegularRaidState.RaidId == Nof.RaidId)
	{
		ResetRegularRaidState();
	}

	return true;
}

void LogSkill(const FCharSkill& Skill)
{
	Q6JsonLogHekel(Verbose, "",
		Q6KV("CharId", Skill.CharInfo.CharacterId),
		Q6KV("CharType", Skill.CharInfo.Type),
		Q6KV("NatureType", (int32)Skill.NatureType),
		Q6KV("SkillType", Skill.Skill));
}

void LogSkills(const TArray<FCharSkill>& Skills)
{
	for (const FCharSkill& Skill : Skills)
	{
		LogSkill(Skill);
	}
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidSkillsNof)
{
	auto Action = ACTION_PARSE_RaidSkillsNof(InAction);
	auto& Nof = Action->GetVal();

	if (Nof.RaidId != OpenRaidId)
	{
		Q6JsonLogHekel(Warning, "invalid raid skill nof", Q6KV("RaidId", Nof.RaidId));
		return true;
	}

	TotalDamage = Nof.TotalDamage;
	RaidRealTimeRankInfos = Nof.Rankers;

	Q6JsonLogHekel(Warning, "skill nof",
		Q6KV("RaidId", Nof.RaidId),
		Q6KV("Skills", Nof.Skills.Num()),
		Q6KV("Support Skills", Nof.SupportSkills.Num()));

	if (Nof.Skills.Num() > 0)
	{
		Skills.Empty();
		Skills = Nof.Skills;
	}

	if (Nof.SupportSkills.Num() > 0)
	{
		SupportSkills.Empty();
		SupportSkills = Nof.SupportSkills;
	}

	LogSkills(Skills);
	LogSkills(SupportSkills);

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidBossHealthNof)
{
	auto Action = ACTION_PARSE_RaidBossHealthNof(InAction);
	auto& Nof = Action->GetVal();

	if (Nof.RaidId != OpenRaidId)
	{
		Q6JsonLogHekel(Warning, "invalid raid boss health nof",
			Q6KV("RaidId", Nof.RaidId));
		return true;
	}

	TotalDamage = Nof.TotalDamage;
	RaidRealTimeRankInfos = Nof.Rankers;

	UpdateRaidUserInfos(Nof.RaidId, Nof.UserInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidEmoticonNof)
{
	auto Action = ACTION_PARSE_RaidEmoticonNof(InAction);
	auto& Nof = Action->GetVal();

	if (Nof.RaidId != OpenRaidId)
	{
		Q6JsonLogHekel(Warning, "invalid emoticon nof",
			Q6KV("RaidId", Nof.RaidId));
		return true;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidStageEndNof)
{
	auto Action = ACTION_PARSE_RaidStageEndNof(InAction);
	auto& Nof = Action->GetVal();

	UpdateRaidUserInfos(Nof.RaidId, Nof.UserInfo);

	Q6JsonLogHekel(Warning, "raid end nof", Q6KV("UserId", Nof.UserId));
	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidSharePartyResp)
{
	auto Action = ACTION_PARSE_RaidSharePartyResp(InAction);
	auto& Resp = Action->GetVal();
	Q6JsonLogHekel(Warning, "share party resp", Q6KV("Ok", Resp.Ok));
	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RegularRaidRegisterResp)
{
	auto Action = ACTION_PARSE_RegularRaidRegisterResp(InAction);
	auto& Resp = Action->GetVal();
	Q6JsonLog(Warning, "regular-raid-register-resp", Q6KV("Succeed", Resp.Succeed));

	RegularRaidState.Registered = true;

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RegularRaidReadyResp)
{
	auto Action = ACTION_PARSE_RegularRaidReadyResp(InAction);
	auto& Resp = Action->GetVal();
	Q6JsonLog(Warning, "regular-raid-ready-resp", Q6KV("Succeed", Resp.Succeed));

	RegularRaidState.RespReady = true;

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RegularRaidMatchedNoti)
{
	auto Action = ACTION_PARSE_RegularRaidMatchedNoti(InAction);
	auto& Noti = Action->GetVal();
	Q6JsonLog(Warning, "regular-raid-matched-noti", Q6KV("RaidId", Noti.Info.RaidId), Q6KV("RaidType", Noti.Info.Type));

	RegularRaidState.RaidId = Noti.Info.RaidId;
	RegularRaidState.Matched = true;

	OpenRaidType = Noti.Info.Type;
	OpenRaidId = Noti.Info.RaidId;

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidSharePartyNof)
{
	auto Action = ACTION_PARSE_RaidSharePartyNof(InAction);
	auto& Nof = Action->GetVal();

	if (Nof.RaidId != OpenRaidId)
	{
		Q6JsonLogHekel(Warning, "invalid share party nof",
			Q6KV("RaidId", Nof.RaidId));
		return true;
	}

	Q6JsonLogHekel(Warning, "raid share party nof",
		Q6KV("UserId", Nof.UserId),
		Q6KV("NumHealths", Nof.Healths.Num()));

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);
	auto& Resp = Action->GetVal();
	ClearedRaidId = Resp.RaidId;
	RaidRankingInfos = Resp.RaidRankingInfos;

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidClearData)
{
	RemoveRaidFinal(GetClearedRaidId());

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, MuteRaidJoinPopup)
{
	if (RegularRaidState.Matched && RegularRaidState.RaidType)
	{
		ResetRaid();
		ResetRegularRaidState();
	}

	bMutePopup = true;

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Res = Action->GetVal();

	SetFoundRaidType(Res.RaidType);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	auto& Res = Action->GetVal();

	SetFoundRaidType(Res.RaidType);
	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	SetFoundRaidType(Res.RaidType);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	auto& Res = Action->GetVal();

	SetFoundRaidType(Res.RaidType);
	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	auto& Res = Action->GetVal();

	SetFoundRaidType(Res.RaidType);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	auto& Res = Action->GetVal();

	SetFoundRaidType(Res.RaidType);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	auto& Res = Action->GetVal();

	SetFoundRaidType(Res.RaidType);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidSelectFinal)
{
	auto Action = ACTION_PARSE_RaidSelectFinal(InAction);
	auto& RaidType = Action->GetVal();
	auto& RaidId = Action->GetVal2();

	SetSelectedRaidFinal(RaidType, RaidId);
	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidClearFoundType)
{
	SetFoundRaidType(RaidTypeInvalid);
	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidClearSkills)
{
	ClearRaidSkills();
	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidCharInfos)
{
	auto Action = ACTION_PARSE_RaidCharInfos(InAction);
	const TArray<FRaidUserCharacterInfo>& Res = Action->GetVal();

	for (const FRaidUserCharacterInfo& ResInfo : Res)
	{
		const int64 ResCharacterId = ResInfo.CharacterId;
		FRaidUserCharacterInfo* Find = UserCharInfos.FindByPredicate(
			[&ResCharacterId](const FRaidUserCharacterInfo& Elem)
		{
			return Elem.CharacterId == ResCharacterId;
		});
		if (Find)
		{
			Find->bPlaying = ResInfo.bPlaying;
			Find->Health = ResInfo.Health;
			Find->MaxHealth = ResInfo.MaxHealth;
		}
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidSetSkills)
{
	auto Action = ACTION_PARSE_RaidSetSkills(InAction);
	auto& SupportSkillStates = Action->GetVal();
	auto& UsedSupportSkills = Action->GetVal2();

	SetRaidSupportSkillsInfo(SupportSkillStates, UsedSupportSkills);
	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidFullNof)
{
	auto Action = ACTION_PARSE_RaidFullNof(InAction);
	auto& Nof = Action->GetVal();

	if (Nof.RaidId != OpenRaidId)
	{
		Q6JsonLogHekel(Warning, "invalid raid full nof",
			Q6KV("RaidId", Nof.RaidId));
		return true;
	}

	Q6JsonLogHekel(Warning, "raid full nof",
		Q6KV("RaidId", Nof.RaidId));

	ResetRaid();

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidKickTimeoutNof)
{
	auto Action = ACTION_PARSE_RaidKickTimeoutNof(InAction);
	auto& Nof = Action->GetVal();

	if (Nof.RaidId != OpenRaidId)
	{
		Q6JsonLogHekel(Warning, "invalid raid kick timeout nof",
			Q6KV("RaidId", Nof.RaidId));
		return true;
	}

	Q6JsonLogHekel(Warning, "raid kick timeout nof",
		Q6KV("RaidId", Nof.RaidId));

	ResetRaid();

	if (RegularRaidState.RaidId == Nof.RaidId)
	{
		ResetRegularRaidState();
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, SetOnGoingRaid)
{
	auto Action = ACTION_PARSE_SetOnGoingRaid(InAction);

	OpenRaidType = Action->GetVal();
	OpenRaidId = Action->GetVal2();

	Q6JsonLogGenie(Verbose, "ongoing raid",
		Q6KV("Type", OpenRaidType),
		Q6KV("Id", OpenRaidId));

	return false;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, UpdateRaidWhenEnterMenu)
{
	ResetTodayRaidClear();
	CheckRegularRaidOpen();

	return true;
}

IMPLEMENT_ACTION_HANDLER(URaidManager, RaidPrepareTime)
{
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(OpenRaidType);
	if (RaidRow.IsInvalid())
	{
		Q6JsonLogHekel(Warning, "invalid raid prepare", Q6KV("Type", OpenRaidType));
		return false;
	}

	PrepareTimeout = static_cast<float>(RaidRow.PrepareSec);

	return false;
}
