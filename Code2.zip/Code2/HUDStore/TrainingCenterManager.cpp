#include "TrainingCenterManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "HSAction.h"
#include "Q6GameState.h"
#include "Q6UIDefine.h"
#include "LobbyHUD.h"
#include "CCEvent.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UTrainingCenterManager

UTrainingCenterManager::UTrainingCenterManager()
{
	InitStore(EHSType::TrainingCenter);
}

void UTrainingCenterManager::ReqTrainingCenterHistory(bool bEnterLobby) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTrainingCenterLoad Out;

	ClientNetwork.WsRequest(TEXT("trainingCenter/load"), Out,
		TQ6ResponseDelegate<FL2CTrainingCenterLoadResp>::CreateUObject(
			const_cast<UTrainingCenterManager*>(this), &UTrainingCenterManager::OnTrainingCenterLoadResp, bEnterLobby));
}

void UTrainingCenterManager::ReqStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LTrainingCenterStageBegin Out;
	Out.Type = History.Type;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("trainingCenter/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CTrainingCenterStageBeginResp>::CreateUObject(
			const_cast<UTrainingCenterManager*>(this), &UTrainingCenterManager::OnStageBeginResp));
}

#if !UE_BUILD_SHIPPING
void UTrainingCenterManager::ReqDevStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();

	FC2LDevTrainingCenterStageBegin Out;
	Out.Type = History.Type;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("dev/trainingCenterStageBegin"), Out,
		TQ6ResponseDelegate<FL2CTrainingCenterStageBeginResp>::CreateUObject(
			const_cast<UTrainingCenterManager*>(this), &UTrainingCenterManager::OnStageBeginResp));
}
#endif

void UTrainingCenterManager::ReqStageEnd(const UCCEndGameEvent* Event
	, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	FC2LTrainingCenterStageEnd Out;
	Out.Type = History.Type;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.Result = static_cast<int32>(Event->Result);
	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;
	Out.Mission = CombatMissionInfo.WeeklyCombatMissionInfo;
	Out.CharMission = CombatMissionInfo.CharCombatMissionInfo;

	ClientNetwork.WsRequest("trainingCenter/stageEnd", Out,
		TQ6ResponseDelegate<FL2CTrainingCenterStageEndResp>::CreateUObject(
			const_cast<UTrainingCenterManager*>(this), &UTrainingCenterManager::OnStageEndResp));
}

bool UTrainingCenterManager::IsCleared() const
{
	const FCMSTrainingCenterRow& Row = GetCMS()->GetTrainingCenterRowOrDummy(History.Type);
	return (Row.GetEndSaga().CmsType() == History.SagaType);
}

bool UTrainingCenterManager::IsLastStep(FTrainingCenterType Type) const
{
	return !GetCMS()->HasNextStepInTrainingCenter(Type);
}

bool UTrainingCenterManager::IsHistoryExpired() const
{
	return (History.ExpireTime <= FDateTime::UtcNow().ToUnixTimestamp());
}

bool UTrainingCenterManager::IsFirstSaga(FTrainingCenterType Type, FSagaType SagaType) const
{
	const FCMSTrainingCenterRow& Row = GetCMS()->GetTrainingCenterRowOrDummy(Type);
	return (Row.GetStartSaga().CmsType() == SagaType);
}

bool UTrainingCenterManager::IsLastSaga(FTrainingCenterType Type, FSagaType SagaType) const
{
	const FCMSTrainingCenterRow& Row = GetCMS()->GetTrainingCenterRowOrDummy(Type);
	return (Row.GetEndSaga().CmsType() == SagaType);
}

bool UTrainingCenterManager::IsFirstSagaOnStep(FSagaType SagaType) const
{
	return IsFirstSaga(History.Type, SagaType);
}

bool UTrainingCenterManager::IsLastSagaOnStep(FSagaType SagaType) const
{
	return IsLastSaga(History.Type, SagaType);
}

ETrainingStepState UTrainingCenterManager::GetTrainingStepState(FTrainingCenterType InType) const
{
	if (History.Type.x > InType.x)
	{
		return ETrainingStepState::Achieved;
	}
	else if (History.Type.x < InType.x)
	{
		return ETrainingStepState::NotAchieved;
	}

	const FCMSTrainingCenterRow& InTCRow = GetCMS()->GetTrainingCenterRowOrDummy(InType);

	if (InTCRow.GetEndSaga().CmsType() != History.SagaType)
	{
		return ETrainingStepState::Trying;
	}

	return ETrainingStepState::Cleared;
}

/////////////////////////////////////////////////////////////////////////////
// UTrainingCenterManager HUDStore Action

void UTrainingCenterManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UTrainingCenterManager, TrainingCenterLoadResp);
	REGISTER_ACTION_HANDLER(UTrainingCenterManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UTrainingCenterManager, DevTrainingCenterClearResp);
	REGISTER_ACTION_HANDLER(UTrainingCenterManager, DevTrainingCenterResetResp);
}

void UTrainingCenterManager::OnTrainingCenterLoadResp(const FResError* Error, const FL2CTrainingCenterLoadResp& Res, bool bEnterLobby)
{
	if (Error)
	{
		OnError(Error);
	}
	else
	{
		ACTION_DISPATCH_TrainingCenterLoadResp(Res);
	}

	if (bEnterLobby)
	{
		GameInstance->ReqNextContent();
	}
}

void UTrainingCenterManager::OnStageBeginResp(const FResError* Error, const FL2CTrainingCenterStageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	if (!Res.Ok)
	{
		UpdateTrainingCenterHistory(Res.History);
		ACTION_DISPATCH_MenuDoubleBack();
		return;
	}

	GameInstance->OnTrainingCenterStageBegin(Res);
}

void UTrainingCenterManager::OnStageEndResp(const FResError* Error, const FL2CTrainingCenterStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnTrainingCenterStageEnd(Res);
}

IMPLEMENT_ACTION_HANDLER(UTrainingCenterManager, TrainingCenterLoadResp)
{
	auto Action = ACTION_PARSE_TrainingCenterLoadResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateTrainingCenterHistory(Resp.History);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UTrainingCenterManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateTrainingCenterHistory(Resp.History);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UTrainingCenterManager, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateTrainingCenterHistory(Resp.History);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UTrainingCenterManager, DevTrainingCenterResetResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterResetResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateTrainingCenterHistory(Resp.History);
	return true;
}

/////////////////////////////////////////////////////////////////////////////
// Setter

void UTrainingCenterManager::UpdateTrainingCenterHistory(const FTrainingCenterRecord& NewHistory)
{
	History = NewHistory;
}
