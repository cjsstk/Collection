#include "SpecialManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "HSAction.h"
#include "Q6GameState.h"
#include "CCEvent.h"
#include "WidgetUtil.h"
#include "Q6Log.h"
#include "LobbyHUD.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Static Functions

bool SpecialRecordCompare(const FSpecialRecord& LValue, const FSpecialRecord& RValue)
{
	return LValue.Episode < RValue.Episode;
}

///////////////////////////////////////////////////////////////////////////////////////////
// USpecialManager

USpecialManager::USpecialManager()
{
	InitStore(EHSType::Special);
}

void USpecialManager::ReqSpecialHistory() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSpecialLoad Out;

	ClientNetwork.WsRequest(TEXT("special/load"), Out,
		TQ6ResponseDelegate<FL2CSpecialLoadResp>::CreateUObject(
			const_cast<USpecialManager*>(this), &USpecialManager::OnSpecialLoadResp));
}

void USpecialManager::OnSpecialLoadResp(const FResError* Error, const FL2CSpecialLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_SpecialLoadResp(Res);
	GameInstance->ReqNextContent();
}

void USpecialManager::ReqStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LSpecialStageBegin Out;
	Out.Episode = SagaRow.Episode;
	Out.Stage = SagaRow.Stage;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("special/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CSpecialStageBeginResp>::CreateUObject(
			const_cast<USpecialManager*>(this), &USpecialManager::OnStageBeginResp));
}

#if !UE_BUILD_SHIPPING
void USpecialManager::ReqDevStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();

	FC2LDevSpecialStageBegin Out;
	Out.Episode = SagaRow.Episode;
	Out.Stage = SagaRow.Stage;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("dev/specialStageBegin"), Out,
		TQ6ResponseDelegate<FL2CSpecialStageBeginResp>::CreateUObject(
			const_cast<USpecialManager*>(this), &USpecialManager::OnStageBeginResp));
}
#endif

void USpecialManager::OnStageBeginResp(const FResError* Error, const FL2CSpecialStageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnSpecialStageBegin(Res);
}

void USpecialManager::ReqStageEnd(const UCCEndGameEvent* Event, const FString& Chronicle) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);
	FC2LSpecialStageEnd Out;
	Out.Episode = SagaRow.Episode;
	Out.Stage = SagaRow.Stage;
	Out.Party = CombatSeed.PartyId;
	Out.Result = static_cast<int32>(Event->Result);
	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;

	ClientNetwork.WsRequest("special/stageEnd", Out,
		TQ6ResponseDelegate<FL2CSpecialStageEndResp>::CreateUObject(
			const_cast<USpecialManager*>(this), &USpecialManager::OnStageEndResp));
}

void USpecialManager::ReqStoryStageClear(FSagaType SagaType, int32 Episode, int32 Stage) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSpecialStoryStageClear Out;
	Out.SagaType = SagaType;
	Out.Episode = Episode;
	Out.Stage = Stage;

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance))
	{
		LobbyHUD->ChangeHUDType(EHUDWidgetType::Dialogue);
	}

	ClientNetwork.WsRequest(TEXT("special/storyStageClear"), Out,
		TQ6ResponseDelegate<FL2CSpecialStoryStageClearResp>::CreateUObject(
			const_cast<USpecialManager*>(this), &USpecialManager::OnStoryStageClearResp));
}

void USpecialManager::OnStoryStageClearResp(const FResError* Error, const FL2CSpecialStoryStageClearResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ClearDialogueRecord();
		return;
	}

	ACTION_DISPATCH_SpecialStoryStageClearResp(Res);

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance))
	{
		LobbyHUD->OnStoryStageClear();
	}
}

const FSpecialStage* USpecialManager::GetSpecialStage(int32 Episode, int32 Stage) const
{
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.Episode != Episode)
		{
			continue;
		}

		for (const FSpecialStage& SpecialStage : SpecialRecord.Stages)
		{
			if (SpecialStage.Stage != Stage)
			{
				continue;
			}

			return &SpecialStage;
		}
	}

	return nullptr;
}

TArray<FSpecialRecord> USpecialManager::GetFilteredHistory(ESpecialCategory Category) const
{
	TArray<FSpecialRecord> FilteredHistory;

	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.ConditionType != Category)
		{
			if (SpecialRecord.ConditionType == ESpecialCategory::Wonder)
			{
				EWonderCategory WonderCategory = GetWonderCategory(SpecialRecord.ConditionType);
				if (WonderCategory == EWonderCategory::Main)
				{
					continue;
				}
			}
			else
			{
				continue;
			}
		}

		FilteredHistory.Add(SpecialRecord);
	}

	FilteredHistory.Sort([](const FSpecialRecord& A, const FSpecialRecord& B)
	{
		return A.Episode < B.Episode;
	});

	return FilteredHistory;
}

TArray<FSpecialStage> USpecialManager::GetSpecialStages(int32 Episode) const
{
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.Episode != Episode)
		{
			continue;
		}

		return SpecialRecord.Stages;
	}

	return TArray<FSpecialStage>();
}

TArray<FSpecialRecord> USpecialManager::GetWonderHistory(EWonderCategory WonderCategory) const
{
	TArray<FSpecialRecord> WonderHistory;

	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.ConditionType == ESpecialCategory::Wonder)
		{
			if (EWonderCategory(SpecialRecord.ConditionId) == WonderCategory)
			{
				WonderHistory.Add(SpecialRecord);
			}
		}
		else
		{
			if (WonderCategory == GetWonderCategory(SpecialRecord.ConditionType))
			{
				WonderHistory.Add(SpecialRecord);
			}
		}
	}

	return WonderHistory;
}

ESpecialCategory USpecialManager::GetSpecialCategory(int32 Episode) const
{
	for (const FSpecialRecord& Record : History)
	{
		if (Record.Episode == Episode)
		{
			return Record.ConditionType;
		}
	}

	return ESpecialCategory::None;
}

bool USpecialManager::IsFirstClearBossStage(int32 Episode, int32 Stage) const
{
	for (const FSpecialRecord& Record : History)
	{
		if (Record.ConditionType != ESpecialCategory::Saga)
		{
			continue;
		}

		if (Record.Episode != Episode)
		{
			continue;
		}

		for (const FSpecialStage& SpecialStage : Record.Stages)
		{
			if (SpecialStage.Stage == Stage)
			{
				return (SpecialStage.ClearCount == 1);
			}
		}
	}

	return false;
}

bool USpecialManager::HasOpenedStage(ESpecialCategory Category) const
{
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (Category == ESpecialCategory::Wonder)
		{
			EWonderCategory WonderCategory = EWonderCategory(SpecialRecord.ConditionId);
			if (WonderCategory != EWonderCategory::Main)
			{
				return true;
			}
		}

		if (SpecialRecord.ConditionType != Category)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool USpecialManager::HasOpenedBossStage(int32 Episode) const
{
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.ConditionType != ESpecialCategory::Saga)
		{
			continue;
		}

		if (SpecialRecord.Episode == Episode)
		{
			return true;
		}
	}

	return false;
}

bool USpecialManager::HasOpenedWonderStage(EWonderCategory WonderCategory) const
{
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.ConditionType == ESpecialCategory::Wonder)
		{
			if (EWonderCategory(SpecialRecord.ConditionId) == WonderCategory)
			{
				return true;
			}
		}
		else
		{
			if (WonderCategory == GetWonderCategory(SpecialRecord.ConditionType))
			{
				return true;
			}
		}
	}

	return false;
}

bool USpecialManager::IsClearedPrevSpecials(const TArray<const FCMSSagaRow*>& SagaRows) const
{
	if (SagaRows.Num() <= 0)
	{
		return true;
	}

	TArray<const FSpecialRecord*> FilteredRecords;
	for (const FSpecialRecord& SpecialRecord : History)
	{
		bool bPrevSpecial = SagaRows.ContainsByPredicate([SpecialRecord](const FCMSSagaRow* SagaRow)
		{
			check(SagaRow);

			return SagaRow->Episode == SpecialRecord.Episode;
		});

		FilteredRecords.Add(&SpecialRecord);
	}

	if (FilteredRecords.Num() <= 0)
	{
		return false;
	}

	for (const FCMSSagaRow* SagaRow : SagaRows)
	{
		const FSpecialRecord** FoundRecord = FilteredRecords.FindByPredicate([SagaRow](const FSpecialRecord* SpecialRecord)
		{
			return SagaRow->Episode == SpecialRecord->Episode;
		});

		if (!FoundRecord)
		{
			return false;
		}

		const FSpecialStage* SpecialStage = (*FoundRecord)->Stages.FindByPredicate([SagaRow](const FSpecialStage& InSpecialStage)
		{
			return (SagaRow->Stage == InSpecialStage.Stage) && (InSpecialStage.ClearCount > 0);
		});

		if (!SpecialStage)
		{
			return false;
		}
	}

	return true;
}

bool USpecialManager::IsClearedSpecial(FSpecialType SpecialType) const
{
	const FCMSSpecialRow& SpecialRow = GetCMS()->GetSpecialRowOrDummy(SpecialType);
	TArray<const FCMSSagaRow*> StageRows = GetCMS()->GetStageRows(EContentType::Special, SpecialRow.Episode);
	TArray<FSpecialStage> SpecialStages = GetSpecialStages(SpecialRow.Episode);
	if (StageRows.Num() != SpecialStages.Num())
	{
		return false;
	}

	for (const FSpecialStage& SpecialStage : SpecialStages)
	{
		if (SpecialStage.ClearCount <= 0)
		{
			return false;
		}
	}

	return true;
}

void USpecialManager::OnStageEndResp(const FResError* Error, const FL2CSpecialStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnSpecialStageEnd(Res);
}

/////////////////////////////////////////////////////////////////////////////
// Setter

bool USpecialManager::OpenSpecialEpisode(const FSpecialRecord& InSpecialRecord)
{
	FSpecialRecord* Found = History.FindByPredicate([&InSpecialRecord](const FSpecialRecord& SpecialRecord)
	{
		return SpecialRecord.Episode == InSpecialRecord.Episode;
	});
	if (Found)
	{
		if (Found->Stages.Num() >= InSpecialRecord.Stages.Num())
		{
			return false;
		}

		Q6JsonLogRoze(Verbose, "OpenSpecialStages", Q6KV("Episode", InSpecialRecord.Episode), Q6KV("Stage", InSpecialRecord.Stages.Num()));
		Found->Stages = InSpecialRecord.Stages;
		return true;
	}

	Q6JsonLogRoze(Verbose, "OpenSpecialEpisode", Q6KV("Episode", InSpecialRecord.Episode));
	History.Add(InSpecialRecord);
	History.Sort(SpecialRecordCompare);

	return true;
}

bool USpecialManager::SaveSpecialStage(int32 Episode, const FSpecialStage& InStage)
{
	FSpecialRecord* OutRecord = History.FindByPredicate([Episode](const FSpecialRecord& SpecialRecord)
	{
		return SpecialRecord.Episode == Episode;
	});
	if (!OutRecord)
	{
		Q6JsonLogKalms(Error, "Episode not found", Q6KV("Episode", Episode));
		return false;
	}

	Q6JsonLogKalms(Verbose, "SaveSpecialStage",
		Q6KV("Episode", Episode), Q6KV("Stage", InStage.Stage), Q6KV("ClearCount", InStage.ClearCount));

	FSpecialStage* OutStage = OutRecord->Stages.FindByPredicate([&InStage](const FSpecialStage& SpecialStage)
	{
		return SpecialStage.Stage == InStage.Stage;
	});
	if (!OutStage)
	{
		OutRecord->Stages.Add(InStage);
		return true;
	}

	OutStage->ClearCount = InStage.ClearCount;
	return true;
}

/////////////////////////////////////////////////////////////////////////////
// UCharacterManager HUDStore Action

void USpecialManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(USpecialManager, SpecialLoadResp);
	REGISTER_ACTION_HANDLER(USpecialManager, DevCharacterNewResp);
	REGISTER_ACTION_HANDLER(USpecialManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(USpecialManager, DevSpecialOpenResp);
	REGISTER_ACTION_HANDLER(USpecialManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(USpecialManager, DevBondAddResp);
	REGISTER_ACTION_HANDLER(USpecialManager, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(USpecialManager, SummonPickupResp);
	REGISTER_ACTION_HANDLER(USpecialManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(USpecialManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(USpecialManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, DevTrainingCenterClearResp);
	REGISTER_ACTION_HANDLER(USpecialManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, PyramidPortalWarpResp);
	REGISTER_ACTION_HANDLER(USpecialManager, VacationUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(USpecialManager, VacationEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(USpecialManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(USpecialManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(USpecialManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(USpecialManager, EventContentMultiSideBattleStoryStageClearResp);
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, SpecialLoadResp)
{
	auto Action = ACTION_PARSE_SpecialLoadResp(InAction);

	const auto& Res = Action->GetVal();
	History = Res.History;
	History.Sort(SpecialRecordCompare);

	return true;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, DevCharacterNewResp)
{
	auto Action = ACTION_PARSE_DevCharacterNewResp(InAction);

	const auto& Resp = Action->GetVal();
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		OpenSpecialEpisode(SpecialRecord);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, DevSpecialOpenResp)
{
	auto Action = ACTION_PARSE_DevSpecialOpenResp(InAction);

	const auto& Resp = Action->GetVal();

	return OpenSpecialEpisode(Resp.SpecialRecord);
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);

	const auto& Res = Action->GetVal();

	return SaveSpecialStage(Res.Episode, Res.SpecialStage);
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, DevBondAddResp)
{
	auto Action = ACTION_PARSE_DevBondAddResp(InAction);

	const auto& Res = Action->GetVal();

	bool Ret = false;
	for (const auto& SpecialRecord : Res.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, SummonPickupResp)
{
	auto Action = ACTION_PARSE_SummonPickupResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;

	// open new stage
	Ret |= SaveSpecialStage(Resp.Episode, Resp.SpecialStage);

	// open new episode
	for (const auto& SpecialRecord : Resp.Specials)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);

	const auto& Resp = Action->GetVal();

	return SaveSpecialStage(Resp.Episode, Resp.SpecialStage);
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, PyramidPortalWarpResp)
{
	auto Action = ACTION_PARSE_PyramidPortalWarpResp(InAction);

	const auto& Resp = Action->GetVal();

	return OpenSpecialEpisode(Resp.SpecialRecord);
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, VacationUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_VacationUpgradeCompleteResp(InAction);

	const auto& Resp = Action->GetVal();

	bool bRet = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		bRet |= OpenSpecialEpisode(SpecialRecord);
	}

	return bRet;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, VacationEndResp)
{
	auto Action = ACTION_PARSE_VacationEndResp(InAction);
	const auto& Resp = Action->GetVal();

	bool bRet = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		bRet |= OpenSpecialEpisode(SpecialRecord);
	}

	return bRet;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USpecialManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);

	const auto& Resp = Action->GetVal();
	bool Ret = false;
	for (const auto& SpecialRecord : Resp.SpecialRecords)
	{
		Ret |= OpenSpecialEpisode(SpecialRecord);
	}

	return Ret;
}
