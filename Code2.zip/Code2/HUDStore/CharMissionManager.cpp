#include "CharMissionManager.h"

#include "CharacterManager.h"
#include "ContentFeatureOpenManager.h"
#include "HUD/BaseHUD.h"
#include "PartyManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"

UCharMissionManager::UCharMissionManager()
{
	InitStore(EHSType::CharMission);
}

FCharMissionInfo* UCharMissionManager::Find(FCharacterType Type)
{
	for (FCharMissionInfo& Info : CharMissionInfos)
	{
		if (Info.CharType == Type) {
			return &Info;
		}
	}

	return nullptr;
}

void UCharMissionManager::Update(const FCharMissionInfo& Info)
{
	FCharMissionInfo* Found = Find(Info.CharType);
	if (Found)
	{
		*Found = Info;
	}
	else
	{
		CharMissionInfos.Add(Info);
	}
}

void UCharMissionManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearCharMission();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCharMissionList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("charMission/list"), Out,
		TQ6ResponseDelegate<FL2CCharMissionListResp>::CreateUObject(
			const_cast<UCharMissionManager*>(this), &UCharMissionManager::OnListResp));
}

TArray<FCCCharacterMissionInfo> UCharMissionManager::GetCombatCharacterMission(const int32 PartyId) const
{
	TArray<FCCCharacterMissionInfo> Out;

	UHUDStore& HUDStore = GetHUDStore();

	bool bOpen = HUDStore.GetContentFeatureOpenManager().IsOpenContentFeature(
		EFeatureOpenType::CharacterMisson);
	if (!bOpen)
	{
		return Out;
	}

	const UPartyManager& PartyManager = HUDStore.GetPartyManager();
	const UCharacterManager& CharacterManager = HUDStore.GetCharacterManager();

	const FPartyInfo& PartyInfo = PartyManager.GetPartyInfo(PartyId);

	TArray<FCharacterType> CurrPartyCharTypes;
	for (const FPartySlot& PartySlot : PartyInfo.Main)
	{
		const FCharacter* Char = CharacterManager.Find(PartySlot.CharacterId);
		if (Char)
		{
			CurrPartyCharTypes.Add(Char->GetInfo().Type);
		}
	}

	for (const FPartySlot& PartySlot : PartyInfo.Sub)
	{
		const FCharacter* Char = CharacterManager.Find(PartySlot.CharacterId);
		if (Char)
		{
			CurrPartyCharTypes.Add(Char->GetInfo().Type);
		}
	}

	if (CurrPartyCharTypes.Num() == 0)
	{
		return Out;
	}

	const UCMS* CMS = GetCMS();
	check(CMS);

	for (const FCharacterType& CharacterType : CurrPartyCharTypes)
	{
		const FCMSCharMissionSetRow* CharMissionSetRow = CMS->GetCharMissionSetRowByCharType(
			CharacterType);
		if (!CharMissionSetRow)
		{
			Q6JsonLogGenie(Warning, "no exist charMissionSetRow", Q6KV("charType", CharacterType));
			continue;
		}

		const TArray<const FCMSCharMissionRow*>& CharMissionRows = CharMissionSetRow->GetMission();
		for (const FCMSCharMissionRow* CharMissionRow : CharMissionRows)
		{
			if (!CharMissionRow)
			{
				continue;
			}

			if (!CharMissionRow->Combat)
			{
				continue;
			}

			FCCCharacterMissionInfo CharacterMissionInfo;
			CharacterMissionInfo.Type = CharMissionRow->CmsType();
			CharacterMissionInfo.Category = CharMissionRow->Category;
			CharacterMissionInfo.UnitType = CMS->GetUnitType(CharacterType);
			Out.Emplace(CharacterMissionInfo);
		}
	}

	return Out;
}

const FCharMissionInfo* UCharMissionManager::GetCharMissionByCharacterType(const FCharacterType& InCharacterType) const
{
	return CharMissionInfos.FindByPredicate(
		[&InCharacterType](const FCharMissionInfo& Elem)
	{
		return Elem.CharType == InCharacterType;
	});
}

const int32 UCharMissionManager::GetMaxValue(const FCharMissionType& Type) const
{
	const FCMSCharMissionRow& CharMissionRow = GetCMS()->GetCharMissionRowOrDummy(Type);
	if (CharMissionRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist charMission type", Q6KV("type", Type));
		return INDEX_NONE;
	}

	return CharMissionRow.Param1;
}

void UCharMissionManager::ReqReward(FCharacterType Type, int32 Index) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCharMissionReceiveReward Out;
	Out.CharType = Type;
	Out.Index = Index;

	ClientNetwork.WsRequest(TEXT("charMission/receiveReward"), Out,
		TQ6ResponseDelegate<FL2CCharMissionReceiveRewardResp>::CreateUObject(
			const_cast<UCharMissionManager*>(this), &UCharMissionManager::OnReceiveRewardResp));
}

void UCharMissionManager::OnListResp(const FResError* Error, const FL2CCharMissionListResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_CharMissionListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void UCharMissionManager::OnReceiveRewardResp(
	const FResError* Error,
	const FL2CCharMissionReceiveRewardResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharMissionRewardResp(Resp);
}

void UCharMissionManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UCharMissionManager, ClearCharMission);
	REGISTER_ACTION_HANDLER(UCharMissionManager, CharMissionListResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, CharMissionRewardResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, DevCharMissionSetResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, CharacterAddXpResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, CharacterTurnSkillLevelResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(UCharMissionManager, SpecialStageEndResp);

	REGISTER_ACTION_HANDLER(UCharMissionManager, UpdateCharMission);
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, ClearCharMission)
{
	CharMissionInfos.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, CharMissionListResp)
{
	auto Action = ACTION_PARSE_CharMissionListResp(InAction);

	auto& Res = Action->GetVal();
	for (const FCharMissionInfo& Info : Res.Missions)
	{
		CharMissionInfos.Add(Info);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, CharMissionRewardResp)
{
	auto Action = ACTION_PARSE_CharMissionRewardResp(InAction);
	auto& Res = Action->GetVal();
	Update(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, DevCharMissionSetResp)
{
	auto Action = ACTION_PARSE_DevCharMissionSetResp(InAction);
	auto& Res = Action->GetVal();
	Update(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, CharacterAddXpResp)
{
	auto Action = ACTION_PARSE_CharacterAddXpResp(InAction);
	auto& Res = Action->GetVal();
	if (!Res.MissionInfo.CharMissionId.IsInvalid())
	{
		Update(Res.MissionInfo);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, CharacterTurnSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterTurnSkillLevelResp(InAction);
	auto& Res = Action->GetVal();
	if (!Res.MissionInfo.CharMissionId.IsInvalid())
	{
		Update(Res.MissionInfo);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	const auto& Resp = Action->GetVal();

	for (const FCharMissionInfo& Info : Resp.CharMission)
	{
		Update(Info);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharMissionManager, UpdateCharMission)
{
	auto Action = ACTION_PARSE_UpdateCharMission(InAction);
	const auto& CharMission = Action->GetVal();

	for (const FCharMissionInfo& Info : CharMission)
	{
		Update(Info);
	}

	return false;
}
