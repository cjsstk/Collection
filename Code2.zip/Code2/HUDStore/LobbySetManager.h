#pragma once

#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "LobbySetManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FLobbySetInfo;
struct FCharacterId;

///////////////////////////////////////////////////////////////////////////////////////////
// ULobbySetManager
UCLASS()
class Q6_API ULobbySetManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	ULobbySetManager();

	// Getter
	const FLobbySetInfo& GetSelectedLobbySetInfo() const;
	FLobbySetInfo GetDummyLobbySetInfo(int32 InLobbySetId) const;
	const TArray<FLobbySetInfo>& GetLobbySetInfoList() const { return LobbySetInfoList; }
	int32 GetSelectedLobbySetId() const { return SelectedId; }

	// Req
	void ReqLobbySetLoad() const;
	void ReqLobbySetSave(const FLobbySetInfo& InLobbySetInfo) const;
	void ReqLobbySetUse(int32 LobbySetId) const;

	bool IsValidLobbySet(int32 InLobbySetId) const;
	void SelectLobbySetToUse(int32 InLobbySetId) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnLobbySetLoadResp(const FResError* Error, const FL2CLobbySetLoadResp& Res);
	void OnLobbySetSaveResp(const FResError* Error, const FL2CLobbySetSaveResp& Res);
	void OnLobbySetUseResp(const FResError* Error, const FL2CLobbySetUseResp& Res);

	// On Actions
	DECLARE_ACTION_HANDLER(LobbySetLoadResp);
	DECLARE_ACTION_HANDLER(LobbySetSaveResp);
	DECLARE_ACTION_HANDLER(LobbySetUseResp);
	DECLARE_ACTION_HANDLER(CharacterAddXpResp);
	DECLARE_ACTION_HANDLER(CharacterUltimateSkillLevelResp);
	DECLARE_ACTION_HANDLER(CharacterRemoveResp);
	DECLARE_ACTION_HANDLER(ShopSellItemResp);

private:
	void UpdateLobbySetList(const TArray<FLobbySetInfo>& InLobbySetInfoList);
	void UpdateLobbySet(const FLobbySetInfo& InLobbySetInfo);
	void UpdateSelectedLobbySet(int32 InLobbySetId, bool bShowNoti);
	void RemoveLobbySetCharacters(const TArray<FCharacterId>& InCharacterIds);

	TArray<FLobbySetInfo> LobbySetInfoList;
	int32 SelectedId;
};
