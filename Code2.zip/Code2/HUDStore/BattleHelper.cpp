// Copyright (c) 2020 XLGames, Inc. All rights reserved.

#include "BattleHelper.h"

#include "HSAction.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "CMS/CMS_gen.h"
#include "Q6.h"


UBattleHelper::UBattleHelper()
{
	InitStore(EHSType::BattleHelper);
}

#if !UE_BUILD_SHIPPING
const TMap<int32, FStageChallenge>& UBattleHelper::GetAllChallengeCount() const
{
	return StageChallenges;
}
#endif

int32 UBattleHelper::GetChallengeCount(FSagaType InSagaType, FWaveType InWaveType) const
{
	const FStageChallenge* InStageChallenge = StageChallenges.Find(InSagaType);
	if (!InStageChallenge)
	{
		return 0;
	}

	const int32* InChallengeCount = InStageChallenge->WaveChallengeCount.Find(InWaveType);
	if (!InChallengeCount)
	{
		return 0;
	}

	return *InChallengeCount;
}

void UBattleHelper::ReqStageChallengeList(FSagaType InSagaType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LStageChallengeList Out;
	Out.SagaType = InSagaType;

	ClientNetwork.WsRequest(TEXT("stageChallenge/list"), Out,
		TQ6ResponseDelegate<FL2CStageChallengeListResp>::CreateUObject(
			const_cast<UBattleHelper*>(this), &UBattleHelper::OnListResp));
}

void UBattleHelper::ReqStageChallengeAdd(FSagaType InSagaType, FWaveType InWaveType) const
{
	int32 CurrentChallengeCount = GetChallengeCount(InSagaType, InWaveType);
	++CurrentChallengeCount;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LStageChallengeAdd Out;
	Out.SagaType = InSagaType;
	Out.WaveType = InWaveType;
	Out.Challenges = CurrentChallengeCount;

	ClientNetwork.WsRequest(TEXT("stageChallenge/add"), Out,
		TQ6ResponseDelegate<FL2CStageChallengeAddResp>::CreateUObject(
			const_cast<UBattleHelper*>(this), &UBattleHelper::OnAddResp, Out));
}

void UBattleHelper::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UBattleHelper, StageChallengeListResp);
	REGISTER_ACTION_HANDLER(UBattleHelper, StageChallengeAddResp);
}

void UBattleHelper::OnListResp(const FResError* Error, const FL2CStageChallengeListResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_StageChallengeListResp(Msg);
}

void UBattleHelper::OnAddResp(const FResError* Error, const FL2CStageChallengeAddResp& Msg, FC2LStageChallengeAdd StageChallengeInfo)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_StageChallengeAdd(StageChallengeInfo);
}

IMPLEMENT_ACTION_HANDLER(UBattleHelper, StageChallengeListResp)
{
	auto Action = ACTION_PARSE_StageChallengeListResp(InAction);

	auto& Res = Action->GetVal();
	
	FStageChallenge& InStageChallenge = StageChallenges.FindOrAdd(Res.StageChallengeInfo.Type.x);
	for (auto& itWave : Res.StageChallengeInfo.WaveChallengeInfos)
	{
		int32& InChallengeCount = InStageChallenge.WaveChallengeCount.FindOrAdd(itWave.WaveType);
		InChallengeCount = itWave.Challenges;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UBattleHelper, StageChallengeAddResp)
{
	auto Action = ACTION_PARSE_StageChallengeAddResp(InAction);
	auto& Res = Action->GetVal();
	FStageChallenge& InStageChallenge = StageChallenges.FindOrAdd(Res.SagaType);
	int32& InChallengeCount = InStageChallenge.WaveChallengeCount.FindOrAdd(Res.WaveType);
	InChallengeCount = Res.Challenges;
	return true;
}
