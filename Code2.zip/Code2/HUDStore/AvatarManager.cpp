#pragma once

#include "AvatarManager.h"

#include "HSAction.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"

void DumpAvatarFrame(const FAvatarFrame& Info)
{
	Q6JsonLogRoze(Verbose, "",
		Q6KV("Type", Info.Type),
		Q6KV("Newly", Info.Newly),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));
}

void DumpAvatarEffect(const FAvatarEffect& Info)
{
	Q6JsonLogRoze(Verbose, "",
		Q6KV("Type", Info.Type),
		Q6KV("Newly", Info.Newly),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));
}

///////////////////////////////////////////////////////////////////////////////////////////
// UAvatarManager

UAvatarManager::UAvatarManager()
{
	InitStore(EHSType::Avatar);

	AvatarFrames.Reset();
	AvatarEffects.Reset();
}

void UAvatarManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAvatarLoad Out;

	ClientNetwork.WsRequest(TEXT("avatar/load"), Out,
		TQ6ResponseDelegate<FL2CAvatarLoadResp>::CreateUObject(
			const_cast<UAvatarManager*>(this), &UAvatarManager::OnLoadResp));
}

void UAvatarManager::ReqSave(const FAvatarInfo& InAvatarInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAvatarSave Out;
	Out.AvatarInfo = InAvatarInfo;

	ClientNetwork.WsRequest(TEXT("avatar/save"), Out,
		TQ6ResponseDelegate<FL2CAvatarSaveResp>::CreateUObject(
			const_cast<UAvatarManager*>(this), &UAvatarManager::OnSaveResp));
}


/////////////////////////////////////////////////////////////////////////////
// UAvatarManager HUDStore Action

void UAvatarManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UAvatarManager, AvatarLoadResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, AvatarSaveResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, EventContentMultisideBattleReceiveRankRewardResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(UAvatarManager, DevAvatarAddResp);
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, AvatarLoadResp)
{
	const auto Action = ACTION_PARSE_AvatarLoadResp(InAction);
	const auto& Resp = Action->GetVal();

	// Set avatar info

	AvatarInfo = Resp.AvatarInfo;
	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, AvatarSaveResp)
{
	const auto Action = ACTION_PARSE_AvatarSaveResp(InAction);
	const auto& Resp = Action->GetVal();

	AvatarInfo = Resp.AvatarInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, EventContentCollabo01StageEndResp)
{
	const auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	const auto& Resp = Action->GetVal();

	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, EventContentCollabo01StoryStageClearResp)
{
	const auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);
	const auto& Resp = Action->GetVal();

	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, EventContentValentineDayStageEndResp)
{
	const auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	const auto& Resp = Action->GetVal();

	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, EventContentValentineDayStoryStageClearResp)
{
	const auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);
	const auto& Resp = Action->GetVal();

	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, EventContentMultiSideBattleStageEndResp)
{
	const auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	const auto& Resp = Action->GetVal();

	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	const auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);
	const auto& Resp = Action->GetVal();

	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, EventContentMultiSideBattleStoryStageClearResp)
{
	const auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);
	const auto& Resp = Action->GetVal();

	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, MailReceiveResp)
{
	const auto Action = ACTION_PARSE_MailReceiveResp(InAction);
	const auto& Resp = Action->GetVal();
	UpdateAvatarItems(Resp.AvatarFrames, Resp.AvatarEffects);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UAvatarManager, DevAvatarAddResp)
{
	const auto Action = ACTION_PARSE_DevAvatarAddResp(InAction);
	const auto& Resp = Action->GetVal();

	if (Resp.Category == EAvatarCategory::Frame)
	{
		FAvatarFrame AvatarFrame = { FAvatarFrameType(Resp.Type), Resp.Newly, Resp.Created };
		UpdateAvatarFrame(AvatarFrame);
	}
	else if (Resp.Category == EAvatarCategory::Effect)
	{
		FAvatarEffect AvatarEffect = { FAvatarEffectType(Resp.Type), Resp.Newly, Resp.Created };
		UpdateAvatarEffect(AvatarEffect);
	}

	return true;
}


/////////////////////////////////////////////////////////////////////////////
// UAvatarManager Resp

void UAvatarManager::OnLoadResp(const FResError* Error, const FL2CAvatarLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_AvatarLoadResp(Res);
	GameInstance->ReqNextContent();
}

void UAvatarManager::OnSaveResp(const FResError* Error, const FL2CAvatarSaveResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_AvatarSaveResp(Res);
}

/////////////////////////////////////////////////////////////////////////////
// UAvatarManager Setter

void UAvatarManager::UpdateAvatarItems(const TArray<FAvatarFrame>& Frames, const TArray<FAvatarEffect>& Effects)
{
	// Set avatar frame list

	for (const FAvatarFrame& AvatarFrame : Frames)
	{
		UpdateAvatarFrame(AvatarFrame);
	}

	// Set avatar effect list

	for (const FAvatarEffect& AvatarEffect : Effects)
	{
		UpdateAvatarEffect(AvatarEffect);
	}
}

void UAvatarManager::UpdateAvatarFrame(const FAvatarFrame& Info)
{
	FAvatarFrame* AvatarFrame = AvatarFrames.Find(Info.Type);
	if (AvatarFrame)
	{
		AvatarFrame->Newly = Info.Newly;
	}
	else
	{
		AvatarFrames.Add(Info.Type, Info);
	}
}

void UAvatarManager::UpdateAvatarEffect(const FAvatarEffect& Info)
{
	FAvatarEffect* AvatarEffect = AvatarEffects.Find(Info.Type);
	if (AvatarEffect)
	{
		AvatarEffect->Newly = Info.Newly;
	}
	else
	{
		AvatarEffects.Add(Info.Type, Info);
	}
}

void UAvatarManager::RemoveAvatarFrame(FAvatarFrameType FrameType)
{
	AvatarFrames.Remove(FrameType);
}

void UAvatarManager::RemoveAvatarEffect(FAvatarEffectType EffectType)
{
	AvatarEffects.Remove(EffectType);
}
