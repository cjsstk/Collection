#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "MailManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FMailId;
struct FMailInfo;
struct FMailReceiveLog;

enum class EMailType : uint8;

///////////////////////////////////////////////////////////////////////////////////////////
// MailManager

UCLASS()
class Q6_API UMailManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UMailManager();

	// Req
	void ReqList() const;
	void ReqReceive(const TArray<FMailId>& InMailIds) const;
	void ReqRefreshList() const;

	const TArray<FMailInfo>& GetMailReceiveInfos() const { return MailReceiveInfos; }
	const TMap<FMailId, FMailInfo>& GetMailInfos() const { return MailInfos; }
	const TDoubleLinkedList<FMailReceiveLog>& GetMailReceiveLogs() const { return MailReceiveLogs; }
	const bool IsNewMail() const;
	const bool IsNewMailByType(const EMailType& MailType) const;

	const FMailInfo* Find(const FMailId& InMailId) const { return MailInfos.Find(InMailId); }

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnListResp(const FResError* Error, const FL2CMailListResp& Res);
	void OnReceiveResp(const FResError* Error, const FL2CMailReceiveResp& Res);
	void OnRefreshListResp(const FResError* Error, const FL2CMailRefreshListResp& Res);

	// On Actions
	DECLARE_ACTION_HANDLER(MailListResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(MailRefreshListResp);
	DECLARE_ACTION_HANDLER(NewMarkNotifyMail);

private:
	void AddMailReceiveInfo(const FMailInfo* InMailInfo);
	void AddMailReceiveLog(const FMailReceiveLog& InMailReceiveLog);
	void AddMailReceiveLog(const FMailInfo* InMailInfo, int32 InReceiveUtc);

	void RemoveMailInfos(const TArray<FMailId>& InMailIds);
	void RemoveMailInfos(const TArray<FMailId>& InMailIds, int32 InReceiveUtc);

	void UpdateMailList(const TArray<FMailInfo>& InMailInfos, const bool& IsRefresh);
	void UpdateMailReceiveLogList(const TArray<FMailReceiveLog> InMailReceiveLogs);

	void RefreshMailList();

	void SortMailList() { MailInfos.KeySort([](const FMailId& Left, const FMailId& Right) { return Left.S > Right.S; }); }

	TArray<FMailInfo> MailReceiveInfos;

	TMap<FMailId, FMailInfo> MailInfos;
	TDoubleLinkedList<FMailReceiveLog> MailReceiveLogs;

	bool bNewMail;
};