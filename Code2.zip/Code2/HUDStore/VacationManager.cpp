#include "VacationManager.h"

#include "HUD/BaseHUD.h"
#include "HUD/LobbyHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "SpecialManager.h"
#include "VacationWidgets.h"

TAutoConsoleVariable<int32> CVarQ6VacationEnd(
	TEXT("q6.vacationEnd"),
	0,
	TEXT("1: No have vacation days/ 0: Not work"),
	ECVF_Cheat);

///////////////////////////////////////////////////////////////////////////////////////////
// UVacationManager

UVacationManager::UVacationManager()
{
	InitStore(EHSType::Vacation);
}

void UVacationManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LVacationLoad Out;

	ClientNetwork.WsRequest(TEXT("vacation/load"), Out,
		TQ6ResponseDelegate<FL2CVacationLoadResp>::CreateUObject(
			const_cast<UVacationManager*>(this), &UVacationManager::OnLoadResp));
}

void UVacationManager::ReqUpgrade() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LVacationUpgrade Out;

	ClientNetwork.WsRequest(TEXT("vacation/upgrade"), Out,
		TQ6ResponseDelegate<FL2CVacationUpgradeResp>::CreateUObject(
			const_cast<UVacationManager*>(this), &UVacationManager::OnUpgradeResp));
}

void UVacationManager::ReqUpgradeComplete() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LVacationUpgradeComplete Out;

	ClientNetwork.WsRequest(TEXT("vacation/upgradeComplete"), Out,
		TQ6ResponseDelegate<FL2CVacationUpgradeCompleteResp>::CreateUObject(
			const_cast<UVacationManager*>(this), &UVacationManager::OnUpgradeCompleteResp));
}

void UVacationManager::ReqStart(int32 SpotIndex, FCharacterId CharacterId) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LVacationStart Out;
	Out.SpotIndex = SpotIndex;
	Out.CharacterId = CharacterId;

	ClientNetwork.WsRequest(TEXT("vacation/start"), Out,
		TQ6ResponseDelegate<FL2CVacationStartResp>::CreateUObject(
			const_cast<UVacationManager*>(this), &UVacationManager::OnStartResp));
}

void UVacationManager::ReqEnd(int32 SpotIndex) const
{
#if !UE_BUILD_SHIPPING
	if (CVarQ6VacationEnd.GetValueOnGameThread())
	{
		ReqDevEnd(SpotIndex);
		return;
	}
#endif
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LVacationEnd Out;
	Out.SpotIndex = SpotIndex;

	ClientNetwork.WsRequest(TEXT("vacation/end"), Out,
		TQ6ResponseDelegate<FL2CVacationEndResp>::CreateUObject(
			const_cast<UVacationManager*>(this), &UVacationManager::OnEndResp));
}

#if !UE_BUILD_SHIPPING
void UVacationManager::ReqDevUpgrade(int32 TargetLevel) const
{
	FC2LDevVacationUpgrade Out;
	Out.Level = TargetLevel;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	ClientNetwork.WsRequest(TEXT("dev/vacationUpgrade"), Out,
		TQ6ResponseDelegate<FL2CVacationUpgradeCompleteResp>::CreateUObject(
			const_cast<UVacationManager*>(this), &UVacationManager::OnUpgradeCompleteResp));
}

void UVacationManager::ReqDevEnd(int32 SpotIndex) const
{
	FC2LDevVacationEnd Out;
	Out.SpotIndex = SpotIndex;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	ClientNetwork.WsRequest(TEXT("dev/vacationEnd"), Out,
		TQ6ResponseDelegate<FL2CVacationEndResp>::CreateUObject(
			const_cast<UVacationManager*>(this), &UVacationManager::OnEndResp));
}

#endif

const FVacationSpot* UVacationManager::GetVacationSpot(int32 SpotIdx) const
{
	if (VacationInfo.Spots.IsValidIndex(SpotIdx))
	{
		return &VacationInfo.Spots[SpotIdx];
	}

	return nullptr;
}

int32 UVacationManager::GetRemainDays(int32 SpotIdx) const
{
	if (const FVacationSpot* Spot = GetVacationSpot(SpotIdx))
	{
		const FCMSVacationSpotRow& SpotRow = GetCMS()->GetVacationSpotRowOrDummy(Spot->VacationSpotType);
		int32 VacationSecs = FMath::Max(SpotRow.VacationDays, 0) * 24 * 60 * 60;
		if (VacationSecs == 0)
		{
			return 0;
		}

		return Q6Util::GetRemainDays(Spot->StartTime + VacationSecs);
	}

	Q6JsonLogRoze(Error, "UVacationManager::GetRemainDays - Invalid spot index", Q6KV("SpotIndex", SpotIdx));
	return 0;
}

int32 UVacationManager::GetRemainDays(FVacationSpotType SpotType) const
{
	if (SpotType == VacationSpotTypeInvalid)
	{
		Q6JsonLogRoze(Error, "UVacationManager::GetRemainDays - Invalid spot type", Q6KV("SpotType", SpotType.x));
		return 0;
	}

#if !UE_BUILD_SHIPPING
	if (CVarQ6VacationEnd.GetValueOnGameThread())
	{
		return 0;
	}
#endif

	for (int32 i = 0; i < VacationInfo.Spots.Num(); ++i)
	{
		if (VacationInfo.Spots[i].VacationSpotType == SpotType)
		{
			return GetRemainDays(i);
		}
	}

	Q6JsonLogRoze(Error, "UVacationManager::GetRemainDays - Not found opened spot", Q6KV("SpotType", SpotType.x));
	return 0;
}

bool UVacationManager::IsVacationNow(FCharacterType CharacterType) const
{
	if (CharacterType == CharacterTypeInvalid)
	{
		Q6JsonLogRoze(Error, "UVacationManager::IsVacationNow - Invalid character type");
		return false;
	}

	for (const FVacationSpot& Spot : VacationInfo.Spots)
	{
		if (Spot.CharacterType == CharacterType)
		{
			return true;
		}
	}

	return false;
}

TArray<FVacationSpotType> UVacationManager::GetOpenedSpotTypes() const
{
	TArray<const FCMSVacationSpotRow*> SpotRows;
	GetCMS()->GetVacationSpot()->GetAllRows(TEXT("GetOpenedSpotTypes"), SpotRows);

	TArray<FVacationSpotType> ValidSpotTypes;
	for (const FCMSVacationSpotRow* SpotRow : SpotRows)
	{
		check(SpotRow);

		EVacationState VacationState = GetSpotState(*SpotRow);
		if (VacationState != EVacationState::Opened)
		{
			continue;
		}

		ValidSpotTypes.AddUnique(SpotRow->CmsType());
	}

	return ValidSpotTypes;
}

EVacationState UVacationManager::GetSpotState(const FCMSVacationSpotRow& SpotRow) const
{
	if (SpotRow.UnlockLevel > VacationInfo.Level)
	{
		return EVacationState::Locked;
	}

	if (SpotRow.SpecialId == SpecialTypeInvalid || GetHUDStore().GetSpecialManager().IsClearedSpecial(FSpecialType(SpotRow.SpecialId)))
	{
		return EVacationState::Opened;
	}

	return EVacationState::Openable;
}

EVacationState UVacationManager::GetSpotState(const FVacationSpotType& VacationSpotType) const
{
	const FCMSVacationSpotRow& SpotRow = GetCMS()->GetVacationSpotRowOrDummy(VacationSpotType);
	return GetSpotState(SpotRow);
}

void UVacationManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UVacationManager, VacationLoadResp);
	REGISTER_ACTION_HANDLER(UVacationManager, VacationUpgradeResp);
	REGISTER_ACTION_HANDLER(UVacationManager, VacationUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UVacationManager, VacationStartResp);
	REGISTER_ACTION_HANDLER(UVacationManager, VacationEndResp);
	REGISTER_ACTION_HANDLER(UVacationManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UVacationManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UVacationManager, DevVacationOpenResp);
	REGISTER_ACTION_HANDLER(UVacationManager, DevSpecialClearResp);
}

void UVacationManager::OnLoadResp(const FResError* Error, const FL2CVacationLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_VacationLoadResp(Msg);
	GameInstance->ReqNextContent();
}

void UVacationManager::OnUpgradeResp(const FResError* Error, const FL2CVacationUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_VacationUpgradeResp(Msg);
}

void UVacationManager::OnUpgradeCompleteResp(const FResError* Error, const FL2CVacationUpgradeCompleteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_VacationUpgradeCompleteResp(Msg);
}

void UVacationManager::OnStartResp(const FResError* Error, const FL2CVacationStartResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_VacationStartResp(Msg);
}

void UVacationManager::OnEndResp(const FResError* Error, const FL2CVacationEndResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_VacationEndResp(Msg);

	ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance);
	if (LobbyHUD)
	{
		FVacationResult Result;
		Result.SpotType = Msg.VacationSpot.VacationSpotType;
		Result.CharacterType = Msg.VacationSpot.CharacterType;
		Result.Bond = Msg.Bond;
		Result.OldBond = Msg.OldBond;
		Result.ResultType = (EUpgradeResultType)Msg.LikeCount;

		LobbyHUD->PlayVacation(Result);
	}
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, VacationLoadResp)
{
	auto Action = ACTION_PARSE_VacationLoadResp(InAction);
	auto& Res = Action->GetVal();

	VacationInfo = Res.VacationInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, VacationUpgradeResp)
{
	auto Action = ACTION_PARSE_VacationUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	VacationInfo = Res.VacationInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, VacationUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_VacationUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	VacationInfo = Res.VacationInfo;

	if (Res.ContentFeatureOpenInfos.Num() > 0)
	{
		ABaseHUD* BaseHUD = GetBaseHUD(GameInstance);
		if (BaseHUD)
		{
			FRewardStep RewardStep;
			RewardStep.ContentFeatureOpenType = Res.ContentFeatureOpenInfos.Last().Type;

			BaseHUD->ShowGuidePopup(RewardStep);
		}
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, VacationStartResp)
{
	auto Action = ACTION_PARSE_VacationStartResp(InAction);
	auto& Res = Action->GetVal();

	int32 SpotIndex = Res.SpotIndex;
	if (VacationInfo.Spots.IsValidIndex(SpotIndex))
	{
		VacationInfo.Spots[SpotIndex] = Res.VacationSpot;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, VacationEndResp)
{
	auto Action = ACTION_PARSE_VacationEndResp(InAction);
	auto& Res = Action->GetVal();

	int32 SpotIndex = Res.SpotIndex;
	if (VacationInfo.Spots.IsValidIndex(SpotIndex))
	{
		VacationInfo.Spots[SpotIndex] = Res.VacationSpot;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	VacationInfo = Res.Vacation;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	VacationInfo = Res.Vacation;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, DevVacationOpenResp)
{
	auto Action = ACTION_PARSE_DevVacationOpenResp(InAction);
	auto& Res = Action->GetVal();

	VacationInfo = Res.VacationInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UVacationManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	VacationInfo = Res.Vacation;

	return true;
}