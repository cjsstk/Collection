#include "RelicManager.h"

#include "HSAction.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "SortingWidgets.h"
#include "UIStateManager.h"

void DefaultRelicInfo(FRelicInfo * Info)
{
	Info->RelicId = FRelicId::InvalidValue();
	Info->UserId = FUserId::InvalidValue();
	Info->Type = RelicTypeInvalid;
	Info->Level = ItemXpTypeInvalid;
	Info->Xp = 0;
	Info->Star = 0;
	Info->Grade = EItemGrade::NONE;
	Info->Locked = 0;
	Info->Newly = 0;
	Info->Created = 0;
}

void DumpRelic(const FRelicInfo& Info)
{
	Q6JsonLogHekel(Verbose, "",
		Q6KV("Id", Info.RelicId),
		Q6KV("User", Info.UserId),
		Q6KV("Type", Info.Type),
		Q6KV("Level", Info.Level),
		Q6KV("Xp", Info.Xp),
		Q6KV("Star", Info.Star),
		Q6KV("Grade", static_cast<int32>(Info.Grade)),
		Q6KV("Locked", Info.Locked),
		Q6KV("Newly", Info.Newly),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));
}

URelicManager::URelicManager()
{
	InitStore(EHSType::Relic);
}

void URelicManager::Dump() const
{
	Q6JsonLogHekel(Verbose, "== Relics ==",
		Q6KV("Total", Relics.Num()));
	for (const auto& Item : Relics)
	{
		const FRelic& Relic = Item.Value;
		DumpRelic(Relic.Info);
	}
}

void URelicManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearRelic();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LRelicList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("relic/list"), Out,
		TQ6ResponseDelegate<FL2CRelicListResp>::CreateUObject(
			const_cast<URelicManager*>(this), &URelicManager::OnListResp));
}

void URelicManager::OnListResp(const FResError* Error, const FL2CRelicListResp& Msg)
{
	Q6JsonLogHekel(Warning, "relic list resp");

	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ACTION_DISPATCH_RelicListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		// TODO: refresh UI, list finished
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void URelicManager::ReqClearNew(const TArray<FRelicId>& RelicIds) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LRelicClearNew Out;
	Out.RelicIds = RelicIds;

	ClientNetwork.WsRequest(TEXT("relic/clearNew"), Out,
		TQ6ResponseDelegate<FL2CRelicClearNewResp>::CreateUObject(
			const_cast<URelicManager*>(this), &URelicManager::OnClearNewResp));
}

void URelicManager::ReqSetLock(const FRelicId& Id, bool bLock) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LRelicSetLock Out;
	Out.RelicId = Id;
	Out.Locked = bLock ? 1 : 0;

	ClientNetwork.WsRequest(TEXT("relic/setLock"), Out,
		TQ6ResponseDelegate<FL2CRelicLoadResp>::CreateUObject(
			const_cast<URelicManager*>(this), &URelicManager::OnLoadResp));
}

void URelicManager::ReqSetStash(const TArray<int64>& TargetIds, bool bStashed) const
{
	FC2LRelicSetStash Out;
	Out.Stashed = bStashed;
	for (const int64& TargetId : TargetIds)
	{
		Out.RelicIds.Add(FRelicId(TargetId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("relic/setStash"), Out,
		TQ6ResponseDelegate<FL2CRelicSetStashResp>::CreateUObject(
			const_cast<URelicManager*>(this), &URelicManager::OnSetStashResp));
}

void URelicManager::ReqAddXp(const FRelicId& TargetId, const TArray<int64>& SourceIds) const
{
	FC2LRelicAddXp Out;
	Out.RelicId = TargetId;
	for (const int64& ItemId : SourceIds)
	{
		Out.RelicIds.Add(FRelicId(ItemId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("relic/addXp"), Out,
		TQ6ResponseDelegate<FL2CRelicAddXpResp>::CreateUObject(
			const_cast<URelicManager*>(this), &URelicManager::OnAddXpResp));
}

void URelicManager::ReqPromote(const FRelicId& TargetId) const
{
	FC2LRelicPromote Out;
	Out.RelicId = TargetId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("relic/promote"), Out,
		TQ6ResponseDelegate<FL2CRelicPromoteResp>::CreateUObject(
			const_cast<URelicManager*>(this), &URelicManager::OnPromoteResp));
}

void URelicManager::ReqTierUp(const FRelicId& TargetId, const TArray<int64>& SourceIds) const
{
	FC2LRelicTierUpgrade Out;
	Out.RelicId = TargetId;
	for (const int64& ItemId : SourceIds)
	{
		Out.RelicIds.Add(FRelicId(ItemId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("relic/tierUpgrade"), Out,
		TQ6ResponseDelegate<FL2CRelicTierUpgradeResp>::CreateUObject(
			const_cast<URelicManager*>(this), &URelicManager::OnTierUpResp));
}

bool URelicManager::IsEqualRelicType(const FRelicId& RelicIdA, const FRelicId& RelicIdB) const
{
	const FRelic* RelicA = Find(RelicIdA);
	const FRelic* RelicB = Find(RelicIdB);

	FRelicType RelicTypeA = RelicA ? RelicA->GetInfo().Type : RelicTypeInvalid;
	FRelicType RelicTypeB = RelicB ? RelicB->GetInfo().Type : RelicTypeInvalid;

	return (RelicTypeA == RelicTypeB);
}

TArray<FRelicType> URelicManager::GetRelicTypes(const TArray<FRelicId>& RelicIds) const
{
	TArray<FRelicType> RelicTypes;

	for (const FRelicId& RelicId : RelicIds)
	{
		if (const FRelic* Relic = Find(RelicId))
		{
			RelicTypes.Add(Relic->GetInfo().Type);
		}
	}

	return RelicTypes;
}

TArray<const FRelic*> URelicManager::GetRelics(ESortMenu SortMenu, ESortCategory Category, bool bStashed) const
{
	TArray<const FRelic*> FilteredList;

	const UCMS* CMS = GetCMS();
	const FSortingGroup& SortingGroup = GetUIResource().GetSortingGroup(Category);
	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, Category);
	for (auto& Elem : Relics)
	{
		const FRelic& Relic = Elem.Value;
		const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(Relic.Info.Type);
		if (Category != ESortCategory::OwnedRelicWithExp && RelicRow.XpExclusive)
		{
			continue;
		}

		if (SortingGroup.bXpCardFilter && SortingOption.bXpCardFilter && !RelicRow.XpExclusive)
		{
			continue;
		}

		if ((SortingGroup.FilterType == ESortFilterType::Tier) && !SortingOption.FilterOptions.Contains(Relic.Info.Tier))
		{
			continue;
		}

		if (Relic.IsStashed() != bStashed)
		{
			continue;
		}

		FilteredList.AddUnique(&Relic);
	}

	FSortOrdering::Sort(SortingOption, FilteredList);
	return FilteredList;
}

void URelicManager::SortByPicked(TArray<const FRelic*>& OutRelics, const TArray<FRelicId>& RelicIds) const
{
	int32 PickedIndex = 0;
	for (const FRelic* Relic : OutRelics)
	{
		if (!RelicIds.Contains(Relic->Info.RelicId))
		{
			continue;
		}

		OutRelics.Remove(Relic);
		OutRelics.Insert(Relic, PickedIndex++);
	}
}

int32 URelicManager::GetLeastUpTier(const FRelicId& TargetRelicId) const
{
	const FRelic* TargetRelic = Find(TargetRelicId);
	if (!TargetRelic)
	{
		Q6JsonLogRoze(Warning, "Not found target relic", Q6KV("RelicId", TargetRelicId));
		return 0;
	}

	int32 LeastUp = 0;
	const FRelicInfo& TargetRelicInfo = TargetRelic->Info;
	for (auto& Elem : Relics)
	{
		const FRelic& Relic = Elem.Value;
		const FRelicInfo& RelicInfo = Relic.GetInfo();
		if (RelicInfo.Type != TargetRelicInfo.Type)
		{
			continue;
		}

		if (RelicInfo.RelicId == TargetRelicInfo.RelicId)
		{
			continue;
		}

		const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(RelicInfo.Type);
		if (RelicRow.XpExclusive)
		{
			continue;
		}

		if ((LeastUp <= 0) || (LeastUp > RelicInfo.Tier))
		{
			LeastUp = RelicInfo.Tier;
		}
	}

	return LeastUp;
}

TMap<FRelicType, const FRelicInfo*> URelicManager::GetPortalConnectRelics() const
{
	TMap<FRelicType, const FRelicInfo*> RelicMap;

	for (auto& Elem : Relics)
	{
		const FRelic& Relic = Elem.Value;
		const FRelicInfo& RelicInfo = Relic.Info;

		if (RelicInfo.Grade < EItemGrade::SR)
		{
			continue;
		}

		const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(RelicInfo.Type);
		if (RelicRow.XpExclusive)
		{
			continue;
		}

		if (!RelicRow.Pyramid)
		{
			continue;
		}

		const FRelicInfo** FoundRelicInfo = RelicMap.Find(RelicInfo.Type);
		if (!FoundRelicInfo)
		{
			RelicMap.Add(RelicInfo.Type, &RelicInfo);
			continue;
		}

		if (RelicInfo.Level > (*FoundRelicInfo)->Level)
		{
			RelicMap.Add(RelicInfo.Type, &RelicInfo);
			continue;
		}

		if ((RelicInfo.Level == (*FoundRelicInfo)->Level)
			&& (RelicInfo.Tier > (*FoundRelicInfo)->Tier))
		{
			RelicMap.Add(RelicInfo.Type, &RelicInfo);
			continue;
		}
	}

	return RelicMap;
}

int32 URelicManager::GetStashedRelicNum(bool bStashed) const
{
	int32 StashedCount = 0;
	for (const auto& Elem : Relics)
	{
		const FRelic& Relic = Elem.Value;
		if (Relic.IsStashed() != bStashed)
		{
			continue;
		}

		++StashedCount;
	}

	return StashedCount;
}

bool URelicManager::HasRelic(EItemGrade InGrade) const
{
	for (const auto& Elem : Relics)
	{
		const FRelic& InRelic = Elem.Value;
		if (InRelic.GetInfo().Grade == InGrade)
		{
			return true;
		}
	}

	return false;
}

void URelicManager::OnLoadResp(const FResError* Error, const FL2CRelicLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	// load, clearNew, setLock
	ACTION_DISPATCH_RelicLoadResp(Msg);
}

void URelicManager::OnAddXpResp(const FResError* Error, const FL2CRelicAddXpResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RelicAddXpResp(Msg);
}

void URelicManager::OnPromoteResp(const FResError* Error, const FL2CRelicPromoteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RelicPromoteResp(Msg);
}

void URelicManager::OnTierUpResp(const FResError* Error, const FL2CRelicTierUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RelicTierUpResp(Msg);
}

void URelicManager::OnSetStashResp(const FResError* Error, const FL2CRelicSetStashResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RelicSetStashResp(Msg);
}

void URelicManager::OnClearNewResp(const FResError* Error, const FL2CRelicClearNewResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_RelicClearNewResp(Msg);
}

/////////////////////////////////////////////////////////////////////////////
// UBagItemManager HUDStore Action

void URelicManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(URelicManager, ClearRelic);
	REGISTER_ACTION_HANDLER(URelicManager, RelicLoadResp);
	REGISTER_ACTION_HANDLER(URelicManager, RelicListResp);
	REGISTER_ACTION_HANDLER(URelicManager, RelicRemoveResp);
	REGISTER_ACTION_HANDLER(URelicManager, RelicAddXpResp);
	REGISTER_ACTION_HANDLER(URelicManager, RelicPromoteResp);
	REGISTER_ACTION_HANDLER(URelicManager, RelicTierUpResp);
	REGISTER_ACTION_HANDLER(URelicManager, RelicSetStashResp);
	REGISTER_ACTION_HANDLER(URelicManager, RelicClearNewResp);
	REGISTER_ACTION_HANDLER(URelicManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, DevRelicNewResp);
	REGISTER_ACTION_HANDLER(URelicManager, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(URelicManager, SummonPickupResp);
	REGISTER_ACTION_HANDLER(URelicManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, VacationEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, DevBondAddResp);
	REGISTER_ACTION_HANDLER(URelicManager, DevTrainingCenterClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(URelicManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, AlchemylabReceiveResp);
	REGISTER_ACTION_HANDLER(URelicManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(URelicManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URelicManager, EventContentMultisideBattleReceiveRankRewardResp);
	REGISTER_ACTION_HANDLER(URelicManager, ShopSellItemResp);
}

IMPLEMENT_ACTION_HANDLER(URelicManager, ClearRelic)
{
	Relics.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicLoadResp)
{
	auto Action = ACTION_PARSE_RelicLoadResp(InAction);

	auto& Res = Action->GetVal();
	return Add(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicListResp)
{
	auto Action = ACTION_PARSE_RelicListResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicRemoveResp)
{
	auto Action = ACTION_PARSE_RelicRemoveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicId& Id : Res.Ids)
	{
		Ret |= Remove(Id);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicAddXpResp)
{
	auto Action = ACTION_PARSE_RelicAddXpResp(InAction);

	auto& Res = Action->GetVal();

	Add(Res.Info);
	for (const FRelicId& Id : Res.Ids)
	{
		Remove(Id);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicPromoteResp)
{
	auto Action = ACTION_PARSE_RelicPromoteResp(InAction);

	auto& Res = Action->GetVal();
	Add(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicTierUpResp)
{
	auto Action = ACTION_PARSE_RelicTierUpResp(InAction);

	auto& Res = Action->GetVal();

	Add(Res.Info);
	for (const FRelicId& Id : Res.Ids)
	{
		Remove(Id);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicSetStashResp)
{
	auto Action = ACTION_PARSE_RelicSetStashResp(InAction);

	auto& Res = Action->GetVal();
	for (const FRelicId& RelicId : Res.RelicIds)
	{
		FRelic* Relic = Relics.Find(RelicId);
		if (!Relic)
		{
			Q6JsonLogRoze(Error, "URelicManager::RelicSetStashResp - No have relic", Q6KV("RelicId", RelicId));
			continue;
		}

		Relic->SetStashed(Res.Stashed);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RelicClearNewResp)
{
	auto Action = ACTION_PARSE_RelicClearNewResp(InAction);

	auto& Res = Action->GetVal();
	for (const FRelicId& RelicId : Res.RelicIds)
	{
		FRelic* Relic = Relics.Find(RelicId);
		if (!Relic)
		{
			Q6JsonLogRoze(Error, "URelicManager::RelicClearNewResp - No have relic", Q6KV("RelicId", RelicId));
			continue;
		}

		Relic->SetNewly(0);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, DevRelicNewResp)
{
	auto Action = ACTION_PARSE_DevRelicNewResp(InAction);

	auto& Res = Action->GetVal();
	return Add(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(URelicManager, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, SummonPickupResp)
{
	auto Action = ACTION_PARSE_SummonPickupResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, VacationEndResp)
{
	auto Action = ACTION_PARSE_VacationEndResp(InAction);

	auto& Res = Action->GetVal();
	bool bRet = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		bRet |= Add(Info);
	}

	return bRet;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, DevBondAddResp)
{
	auto Action = ACTION_PARSE_DevBondAddResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, AlchemylabReceiveResp)
{
	auto Action = ACTION_PARSE_AlchemylabReceiveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FRelicInfo& Info : Res.Relics)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(URelicManager, ShopSellItemResp)
{
	auto Action = ACTION_PARSE_ShopSellItemResp(InAction);
	auto& Res = Action->GetVal();
	if (Res.Category == ELootCategory::RelicCard)
	{
		for (const FAnyId& ItemId : Res.ItemIds)
		{
			Remove(FRelicId(ItemId.S));
		}
	}

	return true;
}

/////////////////////////////////////////////////////////////////////////////
// UBagItemManager Setter

bool URelicManager::Add(const FRelicInfo& Info)
{
	Relics.Add(Info.RelicId, Info);
	return true;
}

bool URelicManager::Remove(const FRelicId& Id)
{
	return (Relics.Remove(Id) > 0);
}

bool URelicManager::Update(const FRelicInfo& Info)
{
	Add(Info);
	return true;
}
