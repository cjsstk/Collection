#pragma once

#include "Q6ClientNetwork.h"
#include "Q6Define.h"
#include "Q6Timer.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "WeeklyMissionManager.generated.h"

UCLASS()
class Q6_API UWeeklyMissionManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UWeeklyMissionManager();

	void ReqLoad() const;
	void ReqReward(int32 Index) const;
	void ReqBingo(int32 Index) const;
	void ReqShuffle() const;
	void ReqConfirm() const;

	void OnLoadResp(const FResError* Error, const FL2CWeeklyMissionLoadResp& Resp);
	void OnReceiveRewardResp(
		const FResError* Error,
		const FL2CWeeklyMissionReceiveRewardResp& Resp);
	void OnReceiveBingoResp(
		const FResError* Error,
		const FL2CWeeklyMissionReceiveBingoResp& Resp);
	void OnShuffleResp(const FResError* Error, const FL2CWeeklyMissionShuffleResp& Resp);
	void OnConfirmResp(const FResError* Error, const FL2CWeeklyMissionLoadResp& Resp);

	TArray<FMissionType> GetCombatWeeklyMission() const;
	const FMissionInfo& GetMissioninfo() const { return MissionInfo; }
	const int32 GetMaxValue(const FMissionType& Type) const;
	const bool IsExpiredWeeklyMission() const;

protected:
	virtual void RegisterActionHandlers() override;

	DECLARE_ACTION_HANDLER(ClearWeeklyMission);
	DECLARE_ACTION_HANDLER(WeeklyMissionLoadResp);
	DECLARE_ACTION_HANDLER(WeeklyMissionRewardResp);
	DECLARE_ACTION_HANDLER(WeeklyMissionBingoResp);
	DECLARE_ACTION_HANDLER(WeeklyMissionShuffleResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(CheckInRewardReceiveResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);

	DECLARE_ACTION_HANDLER(UpdateMission);

	// UI
	DECLARE_ACTION_HANDLER(WeeklyMissionToast);

private:
	void SetMissionInfo(const FMissionInfo& InMissionInfo);

	void WeeklyMissionToastTimer();

	FMissionInfo MissionInfo;

	TArray<TArray<int32>> MissionStates;

	TQueue<FWeeklyMissionToastInfo>	WeeklyMissionToastInfos;

	FQ6TimerHandle WeeklyMissionTimerHandle;
};
