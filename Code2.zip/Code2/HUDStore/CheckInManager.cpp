#include "CheckInManager.h"

#include "ErrCode_gen.h"
#include "HSAction.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6GameInstance.h"

void DumpCheckIn(const FCheckInInfo& Info)
{
	Q6JsonLogRoze(Verbose, "",
		Q6KV("boardType", Info.BoardType.x),
		Q6KV("dayCount", Info.DayCount),
		Q6KV("lastCheckIn", Q6Util::GetLocalDateTimeText(Info.LastCheckIn).ToString()));
}

///////////////////////////////////////////////////////////////////////////////////////////
// UCheckInManager

UCheckInManager::UCheckInManager()
{
	InitStore(EHSType::CheckIn);

	NewCheckInBoardTypes.Empty();
}

UCheckInManager::~UCheckInManager()
{
}

FCheckInBoardType UCheckInManager::GetNextCheckInBoardType(FCheckInBoardType CurrentBoardType) const
{
	for (int32 i = 0; i < NewCheckInBoardTypes.Num() - 1; ++i)
	{
		if (NewCheckInBoardTypes[i] == CurrentBoardType)
		{
			return NewCheckInBoardTypes[i + 1];
		}
	}

	return CheckInBoardTypeInvalid;
}

FCheckInBoardType UCheckInManager::GetFirstBoardPage() const
{
	if (NewCheckInBoardTypes.Num() > 0)
	{
		return NewCheckInBoardTypes[0];
	}

	return CheckInBoardTypeInvalid;
}

bool UCheckInManager::HasNewCheckInBoard() const
{
	return NewCheckInBoardTypes.Num() > 0;
}

const FCheckInInfo* UCheckInManager::GetCheckInInfo(FCheckInBoardType CurrentBoardType) const
{
	for (const FCheckInInfo& CheckInInfo : CheckInInfos)
	{
		if (CheckInInfo.BoardType != CurrentBoardType)
		{
			continue;
		}

		return &CheckInInfo;
	}

	return nullptr;
}

void UCheckInManager::ReqList() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCheckInList Out;

	ClientNetwork.WsRequest(TEXT("checkIn/list"), Out,
		TQ6ResponseDelegate<FL2CCheckInListResp>::CreateUObject(
			const_cast<UCheckInManager*>(this), &UCheckInManager::OnCheckInListResp));
}

void UCheckInManager::ReqRewardReceive() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCheckInRewardReceive Out;

	ClientNetwork.WsRequest(TEXT("checkIn/rewardReceive"), Out,
		TQ6ResponseDelegate<FL2CCheckInRewardReceiveResp>::CreateUObject(
			const_cast<UCheckInManager*>(this), &UCheckInManager::OnCheckInRewardReceiveResp));
}

void UCheckInManager::Dump() const
{
	Q6JsonLogRoze(Verbose, "== CheckInInfos ==",
		Q6KV("Total", CheckInInfos.Num()));
	for (const auto& CheckIn : CheckInInfos)
	{
		DumpCheckIn(CheckIn);
	}
}

void UCheckInManager::OnCheckInListResp(const FResError* Error, const FL2CCheckInListResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_CheckInListResp(Res);
	GameInstance->ReqNextContent();
}

void UCheckInManager::OnCheckInRewardReceiveResp(const FResError* Error, const FL2CCheckInRewardReceiveResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CheckInRewardReceiveResp(Res);
}

/////////////////////////////////////////////////////////////////////////////
// UCheckIn HUDStore Action

void UCheckInManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UCheckInManager, CheckInListResp);
	REGISTER_ACTION_HANDLER(UCheckInManager, CheckInRewardReceiveResp);
	REGISTER_ACTION_HANDLER(UCheckInManager, DevCheckInLoadResp);
	REGISTER_ACTION_HANDLER(UCheckInManager, CheckInClear);
}

IMPLEMENT_ACTION_HANDLER(UCheckInManager, CheckInListResp)
{
	const auto Action = ACTION_PARSE_CheckInListResp(InAction);
	const FL2CCheckInListResp& Res = Action->GetVal();

	CheckInInfos = Res.CheckInInfos;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCheckInManager, CheckInRewardReceiveResp)
{
	const auto Action = ACTION_PARSE_CheckInRewardReceiveResp(InAction);
	const FL2CCheckInRewardReceiveResp& Res = Action->GetVal();

	CheckInInfos = Res.CheckInInfos;
	NewCheckInBoardTypes = Res.NewCheckInBoardTypes;

	NewCheckInBoardTypes.Reset();
	NewCheckInBoardTypes = Res.NewCheckInBoardTypes;

	const UCMS* CMS = GetCMS();
	NewCheckInBoardTypes.Sort([CMS](const FCheckInBoardType& BoardTypeA, const FCheckInBoardType& BoardTypeB)
	{
		const FCMSCheckInBoardRow& BoardRowA = CMS->GetCheckInBoardRowOrDummy(BoardTypeA);
		const FCMSCheckInBoardRow& BoardRowB = CMS->GetCheckInBoardRowOrDummy(BoardTypeB);

		return BoardRowA.PageNum < BoardRowB.PageNum;
	});

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCheckInManager, DevCheckInLoadResp)
{
	const auto Action = ACTION_PARSE_DevCheckInLoadResp(InAction);
	const FL2CDevCheckInLoadResp& Res = Action->GetVal();
	const FCheckInInfo& NewCheckIn = Res.CheckInInfo;

	bool bFoundCheckIn = false;
	for (FCheckInInfo& CheckIn : CheckInInfos)
	{
		if (CheckIn.BoardType != NewCheckIn.BoardType)
		{
			continue;
		}

		CheckIn.OpenTime = NewCheckIn.OpenTime;
		CheckIn.DayCount = NewCheckIn.DayCount;
		CheckIn.LastCheckIn = NewCheckIn.LastCheckIn;
		bFoundCheckIn = true;
	}

	if (!bFoundCheckIn)
	{
		CheckInInfos.Add(NewCheckIn);
	}

	NewCheckInBoardTypes.Reset();
	if (Res.NewCheckInType != CheckInBoardTypeInvalid)
	{
		const FCMSCheckInBoardRow& BoardRow = GetCMS()->GetCheckInBoardRowOrDummy(Res.NewCheckInType);
		NewCheckInBoardTypes.Add(NewCheckIn.BoardType);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCheckInManager, CheckInClear)
{
	const auto Action = ACTION_PARSE_CheckInClear(InAction);

	NewCheckInBoardTypes.Empty();
	return false;
}
