#pragma once

#include "Q6ClientNetwork.h"
#include "Q6Define.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "TitleManager.generated.h"

UCLASS()
class Q6_API UTitleManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UTitleManager();

	void ReqList(int32 PageNo = 0) const;
	void Change(FUserTitleType Type) const;

	const TArray<FUserTitleType>& GetTitles() const { return Titles; }

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CUserTitleListResp& Msg);
	void OnChangeResp(const FResError* Error, const FL2CUserTitleChangeResp& Msg);

private:
	DECLARE_ACTION_HANDLER(ClearTitle);
	DECLARE_ACTION_HANDLER(TitleListResp);
	DECLARE_ACTION_HANDLER(DevTitleAddResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(ShopBuyItemResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);

	TArray<FUserTitleType> Titles;
};
