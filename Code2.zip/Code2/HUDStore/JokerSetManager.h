#pragma once

#include "CMSType_gen.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "JokerSetManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;

///////////////////////////////////////////////////////////////////////////////////////////
// UJokerManager

UCLASS()
class Q6_API UJokerSetManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:

	UJokerSetManager();

	const FJokerSet& GetJokerSet(int32 JokerSetId) const;
	int32 GetSelectedId() const { return SelectedId; }

	TArray<FCharacterId> GetCharactersInJokerSet() const;
	TArray<FRelicId> GetRelicsInJokerSet() const;
	TArray<FSculptureId> GetSculpturesInJokerSet() const;

	bool IsValidJokerSet(int32 JokerSetId) const;

public:
	// Req
	void ReqJokerSetList() const;
	void ReqJokerSetSave(const FJokerSet& JokerSet) const;
	void ReqJokerSetUse(int32 JokerSetId) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnJokerSetLoadResp(const FResError* Error, const FL2CJokerSetLoadResp& Res);
	// Action handler
	DECLARE_ACTION_HANDLER(JokerSetLoadResp);
	DECLARE_ACTION_HANDLER(JokerSetSaveResp);
	DECLARE_ACTION_HANDLER(JokerSetUseResp);

private:
	TArray<FJokerSet> JokerSetList;
	int32 SelectedId;
};
