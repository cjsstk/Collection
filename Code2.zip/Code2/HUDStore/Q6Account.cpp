#include "Q6Account.h"

#include "BaseHUD.h"
#include "Math/UnrealMathUtility.h"
#include "CMS/CMSTable.h"
#include "ErrCode_gen.h"
#include "Utils/LevelUtil.h"
#include "Q6Define.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "CharacterManager.h"
#include "BagItemManager.h"
#include "PartyManager.h"
#include "SagaManager.h"
#include "SummonManager.h"
#include "HUDStore.h"
#include "HSAction.h"
#include "LobbyObj_gen.h"
#include "SystemConst_gen.h"
#include "SystemConstHelper.h"
#include "Tutorial/LobbyTutorial.h"

///////////////////////////////////////////////////////////////////////////////////////////
// FAccountInfo

FUserInfoEx::FUserInfoEx()
	: Xp(-1)
	, FreeGem(-1)
	, PaidGem(-1)
	, SummonTicket(-1)
	, SculpturePoint(-1)
	, RelicPoint(-1)
	, FriendshipPoint(-1)
	, Gold(-1)
	, Watt(-1)
	, TitleScore(0)
	, bLevelUp(false)
	, StartXp(-1)
	, EndXp(-1)
	, MaxWatt(-1)
	, WattDiffTime(0)
	, MaxFriendCount(0)
{
}

///////////////////////////////////////////////////////////////////////////////////////////
// UWorldUser

UWorldUser::UWorldUser()
	: bFriendshipCollect(false)
{
	InitStore(EHSType::WorldUser);
}

UWorldUser::~UWorldUser()
{
}

void UWorldUser::ReqWattRecharge(EBatteryType BatteryType, int32 Count) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LWattRecharge Out;
	Out.BatteryType = BatteryType;
	Out.RechargeCount = Count;

	ClientNetwork.WsRequest(TEXT("watt/recharge"), Out,
		TQ6ResponseDelegate<FL2CWattRechargeResp>::CreateUObject(
			const_cast<UWorldUser*>(this), &UWorldUser::OnWattRechargeResp));
}

void UWorldUser::ReqCurrencyLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCurrencyLoad Out;

	ClientNetwork.WsRequest(TEXT("currency/load"), Out,
		TQ6ResponseDelegate<FL2CCurrencyLoadResp>::CreateUObject(
			const_cast<UWorldUser*>(this), &UWorldUser::OnCurrencyLoadResp));
}

void UWorldUser::ReqRename(const FString& UserName) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LUserRename Out;
	Out.UserName = UserName;

	ClientNetwork.WsRequest(TEXT("user/rename"), Out,
		TQ6ResponseDelegate<FL2CUserRenameResp>::CreateUObject(
			const_cast<UWorldUser*>(this), &UWorldUser::OnUserRenameResp));
}

void UWorldUser::ReqAddLobbyTutorialDone(ELobbyTutorial InDoneTutorial) const
{
	int32 InTutorialIndex = (int32)InDoneTutorial;
	if (IsLobbyTutorialDone(InDoneTutorial))
	{
		return;
	}

	uint64 InNewLobbyTutorialsDone = UserInfoEx.LobbyTutorialsDone;
	InNewLobbyTutorialsDone += (1ull << InTutorialIndex);

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LUserSetTutorial AllTutorialsDone;
	AllTutorialsDone.Tutorials.Add(InNewLobbyTutorialsDone >> LOBBY_TUTORIALS_UPPER_SHIFT_BITS & LOBBY_TUTORIALS_BITMASK);
	AllTutorialsDone.Tutorials.Add(InNewLobbyTutorialsDone & LOBBY_TUTORIALS_BITMASK);
	ClientNetwork.WsRequest(TEXT("user/setTutorial"), AllTutorialsDone,
		TQ6ResponseDelegate<FL2CUserSetTutorialResp>::CreateUObject(
			const_cast<UWorldUser*>(this), &UWorldUser::OnUserSetTutorialResp, InNewLobbyTutorialsDone));
}

int32 UWorldUser::GetBattery(EBatteryType BatteryType) const
{
	switch (BatteryType)
	{
		case EBatteryType::Small: return UserInfoEx.SmallBattery;
		case EBatteryType::Medium: return UserInfoEx.MediumBattery;
		case EBatteryType::Large: return UserInfoEx.LargeBattery;
	}

	return 0;
}

int32 UWorldUser::GetPoint(ESummonPointType InPointType) const
{
	EPointType PointType = GetPointType(InPointType);
	return GetPoint(PointType);
}

int32 UWorldUser::GetPoint(EPointType PointType) const
{
	switch (PointType)
	{
		case EPointType::Gold:			return GetGold();
		case EPointType::AnyGem:		return GetTotalGem();
		case EPointType::FreeGem:		return GetFreeGem();
		case EPointType::PaidGem:		return GetPaidGem();
		case EPointType::SummonTicket:	return GetSummonTicket();
		case EPointType::Sculpture:		return GetSculpturePoint();
		case EPointType::Relic:			return GetRelicPoint();
		case EPointType::Friendship:	return GetFriendshipPoint();
		case EPointType::SmallBattery:	return GetBattery(EBatteryType::Small);
		case EPointType::MediumBattery: return GetBattery(EBatteryType::Medium);
		case EPointType::LargeBattery:	return GetBattery(EBatteryType::Large);
		case EPointType::Lumicube:		return GetLumicube();
		case EPointType::CharacterDisk: return GetCharacterDisk();
		case EPointType::SculptureDisk: return GetSculptureDisk();
		case EPointType::RelicDisk:		return GetRelicDisk();
		case EPointType::Watt:			return GetWatt();
	}

	Q6JsonLogRoze(Warning, "UWorldUser::GetPoint - invalid point type", Q6KV("PointType", static_cast<int>(PointType)));
	return 0;
}

bool UWorldUser::HasEnoughCurrency(ECurrencyType InCurrencyType, int32 InRequireCost) const
{
	return GetOwnedCurrency(InCurrencyType) > InRequireCost;
}

bool UWorldUser::HasEnoughGold(int32 RequireCost) const
{
	if (GetGold() < RequireCost)
	{
		return false;
	}

	return true;
}

ECurrencyType UWorldUser::HasMaxCurrency(ECurrencyCheckType CheckType) const
{
	if (!CurrencyCheckList.IsValidIndex((int32)CheckType))
	{
		Q6JsonLogRoze(Error, "UWorldUser::HasAnyMaxCurrency - Not found currency check info", Q6KV("CheckType", (int32)CheckType));
		return ECurrencyType::None;
	}

	const FCurrencyCheckInfo& CurrencyCheckInfo = CurrencyCheckList[(int32)CheckType];
	for (const ECurrencyType& CurrencyType : CurrencyCheckInfo.CheckTypes)
	{
		if (IsMaxCurrency(CurrencyType))
		{
			return CurrencyType;
		}
	}

	return ECurrencyType::None;
}

bool UWorldUser::IsMaxCurrency(ECurrencyType CurrencyType) const
{
	int32 MaxAmount = SystemConstHelper::GetMaxCurrencyAmount(CurrencyType);
	int32 OwnedAmount = GetOwnedCurrency(CurrencyType);

	// If gem, check sum of free and paid gem
	if (CurrencyType == ECurrencyType::FreeGem)
	{
		OwnedAmount += GetOwnedCurrency(ECurrencyType::PaidGem);
	}
	else if (CurrencyType == ECurrencyType::PaidGem)
	{
		OwnedAmount += GetOwnedCurrency(ECurrencyType::FreeGem);
	}

	return OwnedAmount >= MaxAmount;
}

bool UWorldUser::IsTutorialSummon(FBoxProductType InBoxProductType) const
{
	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(InBoxProductType);
	if (BoxProductRow.GroupCount > 1)
	{
		return false;
	}

	if (BoxProductRow.SummonType == ESummonType::Basic)
	{
		return UserInfoEx.TutorialCharacterSummon <= 0;
	}

	if (BoxProductRow.SummonType == ESummonType::Sculpture)
	{
		return UserInfoEx.TutorialSculptureSummon <= 0;
	}

	if (BoxProductRow.SummonType == ESummonType::Relic)
	{
		return UserInfoEx.TutorialRelicSummon <= 0;
	}

	return false;
}

void UWorldUser::ReqFriendshipCollect() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendshipCollect Out;

	ClientNetwork.WsRequest(TEXT("friendship/collect"), Out,
		TQ6ResponseDelegate<FL2CFriendshipCollectResp>::CreateUObject(
			const_cast<UWorldUser*>(this), &UWorldUser::OnFriendshipCollectResp));
}

const FString UWorldUser::GetUserDisplayCode() const
{
	return FString::FormatAsNumber(FCString::Atoi(*UserInfoEx.UserCode) + 1000000000).Mid(2);
}

bool UWorldUser::IsLobbyTutorialDone(ELobbyTutorial InLobbyTutorial) const
{
	int32 TutorialIndex = (int32)InLobbyTutorial;
	return UserInfoEx.LobbyTutorialsDone & (1ull << TutorialIndex);
}

int32 UWorldUser::GetOwnedCurrency(ECurrencyType InCurrencyType) const
{
	switch (InCurrencyType)
	{
		case ECurrencyType::None:
			Q6JsonLogGunny(Warning, "UWorldUser::GetOwnedCurrency - You requested ECurrencyType::None");
			return 0;
		case ECurrencyType::Gold:
			return GetGold();
		case ECurrencyType::Lumicube:
			return GetLumicube();
		case ECurrencyType::CharacterDisk:
			return GetCharacterDisk();
		case ECurrencyType::SculptureDisk:
			return GetSculptureDisk();
		case ECurrencyType::RelicDisk:
			return GetRelicDisk();
		case ECurrencyType::FreeGem:
			return GetFreeGem();
		case ECurrencyType::PaidGem:
			return GetPaidGem();
		case ECurrencyType::SummonTicket:
			return GetSummonTicket();
		case ECurrencyType::SculpturePoint:
			return GetSculpturePoint();
		case ECurrencyType::RelicPoint:
			return GetRelicPoint();
		case ECurrencyType::FriendshipPoint:
			return GetFriendshipPoint();
		case ECurrencyType::SmallBattery:
			return GetBattery(EBatteryType::Small);
		case ECurrencyType::MediumBattery:
			return GetBattery(EBatteryType::Medium);
		case ECurrencyType::LargeBattery:
			return GetBattery(EBatteryType::Large);
		case ECurrencyType::Watt:
			return GetWatt();
		default:
			Q6JsonLogGunny(Warning, "UWorldUser::GetOwnedCurrency - wrong CurrencyType",
				Q6KV("ECurrencyType", static_cast<int>(InCurrencyType)));
			return 0;
	}
}

/////////////////////////////////////////////////////////////////////////////
// Setter

bool UWorldUser::UpdateByUserInfo(const FUserInfo& Info)
{
	bool Ret = UpdateByLevel(FUserLevelType(Info.Level));
	Ret |= UpdateByXp(Info.Xp);

	UserInfoEx.Title = Info.Title;
	UserInfoEx.TitleScore = Info.TitleScore;

	return Ret;
}

bool UWorldUser::UpdateByWattInfo(const FWattDiffInfo& Info)
{
	if (Info.Watt == GetWatt())
	{
		return false;
	}

	UserInfoEx.Watt = Info.Watt;
	UserInfoEx.WattDiffTime = Info.DiffTime;

	Q6JsonLogKalms(Verbose, "OnActionWattInfo", Q6KV("Watt", UserInfoEx.Watt));
	return true;
}

bool UWorldUser::UpdateByCurrencyInfo(const FCurrencyInfo& Info)
{
	bool Ret = false;
	Ret |= UpdateByFreeGem(Info.FreeGem);
	Ret |= UpdateByPaidGem(Info.PaidGem);
	Ret |= UpdateBySummonTicket(Info.SummonTicket);
	Ret |= UpdateBySculpturePoint(Info.SculpturePoint);
	Ret |= UpdateByRelicPoint(Info.RelicPoint);
	Ret |= UpdateByFriendshipPoint(Info.FriendshipPoint);
	Ret |= UpdateBySmallBattery(Info.SmallBattery);
	Ret |= UpdateByMediumBattery(Info.MediumBattery);
	Ret |= UpdateByLargeBattery(Info.LargeBattery);
	Ret |= UpdateByGold(Info.Gold);
	Ret |= UpdateByLumicube(Info.Lumicube);
	Ret |= UpdateByCharacterDisk(Info.CharacterDisk);
	Ret |= UpdateBySculptureDisk(Info.SculptureDisk);
	Ret |= UpdateByRelicDisk(Info.RelicDisk);

	return Ret;
}

bool UWorldUser::UpdateByFreeGem(int32 InFreeGem)
{
	if (InFreeGem == GetFreeGem())
	{
		return false;
	}

	UserInfoEx.FreeGem = InFreeGem;
	Q6JsonLogKalms(Display, "UpdateByFreeGem", Q6KV("FreeGem", InFreeGem));
	return true;
}

bool UWorldUser::UpdateByPaidGem(int32 InPaidGem)
{
	if (InPaidGem == GetPaidGem())
	{
		return false;
	}

	UserInfoEx.PaidGem = InPaidGem;
	Q6JsonLog(Display, "UpdateByPaidGem", Q6KV("PaidGem", InPaidGem));
	return true;
}

bool UWorldUser::UpdateBySummonTicket(int32 InSummonTicket)
{
	if (InSummonTicket == GetSummonTicket())
	{
		return false;
	}

	UserInfoEx.SummonTicket = InSummonTicket;
	Q6JsonLog(Display, "UpdateBySummonTicket", Q6KV("SummonTicket", InSummonTicket));
	return true;
}

bool UWorldUser::UpdateBySculpturePoint(int32 InSculpturePoint)
{
	if (InSculpturePoint == GetSculpturePoint())
	{
		return false;
	}

	UserInfoEx.SculpturePoint = InSculpturePoint;
	Q6JsonLog(Display, "UpdateBySculpturePoint", Q6KV("SculpturePoint", InSculpturePoint));
	return true;
}

bool UWorldUser::UpdateByRelicPoint(int32 InRelicPoint)
{
	if (InRelicPoint == GetRelicPoint())
	{
		return false;
	}

	UserInfoEx.RelicPoint = InRelicPoint;
	Q6JsonLog(Display, "UpdateByRelicPoint", Q6KV("RelicSummonPoint", InRelicPoint));
	return true;
}

bool UWorldUser::UpdateByFriendshipPoint(int32 InFriendshipPoint)
{
	if (InFriendshipPoint == GetFriendshipPoint())
	{
		return false;
	}

	UserInfoEx.FriendshipPoint = InFriendshipPoint;
	Q6JsonLog(Display, "UpdateByFriendshipPoint", Q6KV("FriendshipPoint", InFriendshipPoint));
	return true;
}

bool UWorldUser::UpdateBySmallBattery(int32 InSmallBattery)
{
	if (InSmallBattery == GetBattery(EBatteryType::Small))
	{
		return false;
	}

	UserInfoEx.SmallBattery = InSmallBattery;
	Q6JsonLogRoze(Display, "UpdateBySmallBattery", Q6KV("SmallBattery", InSmallBattery));
	return true;
}

bool UWorldUser::UpdateByMediumBattery(int32 InMediumBattery)
{
	if (InMediumBattery == GetBattery(EBatteryType::Medium))
	{
		return false;
	}

	UserInfoEx.MediumBattery = InMediumBattery;
	Q6JsonLogRoze(Display, "UpdateByMediumBattery", Q6KV("MediumBattery", InMediumBattery));
	return true;
}

bool UWorldUser::UpdateByLargeBattery(int32 InLargeBattery)
{
	if (InLargeBattery == GetBattery(EBatteryType::Large))
	{
		return false;
	}

	UserInfoEx.LargeBattery = InLargeBattery;
	Q6JsonLogRoze(Display, "UpdateByLargeBattery", Q6KV("LargeBattery", InLargeBattery));
	return true;
}

bool UWorldUser::UpdateByGold(int64 InGold)
{
	if (InGold == GetGold())
	{
		return false;
	}

	UserInfoEx.Gold = InGold;
	Q6JsonLogKalms(Verbose, "UpdateByGold", Q6KV("Gold", InGold));
	return true;
}

bool UWorldUser::UpdateByLumicube(int32 InLumicube)
{
	if (InLumicube == GetLumicube())
	{
		return false;
	}

	UserInfoEx.Lumicube = InLumicube;
	Q6JsonLogGunny(Verbose, "UpdateByLumicube", Q6KV("Lumicube", InLumicube));
	return true;
}

bool UWorldUser::UpdateByCharacterDisk(int32 InCharacterDisk)
{
	if (InCharacterDisk == GetCharacterDisk())
	{
		return false;
	}

	UserInfoEx.CharacterDisk = InCharacterDisk;
	Q6JsonLogGunny(Verbose, "UpdateByCharacterDisk", Q6KV("CharacterDisk", InCharacterDisk));
	return true;
}

bool UWorldUser::UpdateBySculptureDisk(int32 InSculptureDisk)
{
	if (InSculptureDisk == GetSculptureDisk())
	{
		return false;
	}

	UserInfoEx.SculptureDisk = InSculptureDisk;
	Q6JsonLogGunny(Verbose, "UpdateBySculptureDisk", Q6KV("SculptureDisk", InSculptureDisk));
	return true;
}

bool UWorldUser::UpdateByRelicDisk(int32 InRelicDisk)
{
	if (InRelicDisk == GetRelicDisk())
	{
		return false;
	}

	UserInfoEx.RelicDisk = InRelicDisk;
	Q6JsonLogGunny(Verbose, "UpdateByRelicDisk", Q6KV("RelicDisk", InRelicDisk));
	return true;
}

bool UWorldUser::UpdateByXp(int32 InXp)
{
	auto NewXp = FMath::Clamp(InXp, 0, GetCMS()->GetMaxXp());
	if (NewXp == GetXp())
	{
		return false;
	}

	UserInfoEx.Xp = NewXp;
	Q6JsonLogKalms(Verbose, "UpdateByXp", Q6KV("Xp", UserInfoEx.Xp), Q6KV("XpRatio(%)", GetXpRatio() * 100));
	return true;
}

bool UWorldUser::UpdateByLevel(FUserLevelType InLevel)
{
	auto NewLevel = FUserLevelType(FMath::Clamp(InLevel, MinLevel, GetCMS()->GetMaxLevel()));
	if (NewLevel == GetLevel())
	{
		UserInfoEx.bLevelUp = false;
		return false;
	}

	UserInfoEx.Level = NewLevel;
	UserInfoEx.bLevelUp = true;
	UserInfoEx.StartXp = GetCMS()->GetStartXpFromLevel(UserInfoEx.Level);
	UserInfoEx.EndXp = GetCMS()->GetEndXpFromLevel(UserInfoEx.Level);
	UserInfoEx.MaxWatt = GetCMS()->GetWattLimitFromLevel(UserInfoEx.Level);
	UserInfoEx.MaxFriendCount = GetCMS()->GetFriendLimitFromLevel(UserInfoEx.Level);
	Q6JsonLogKalms(Verbose, "UpdateByLevel", Q6KV("Level", NewLevel));
	return true;
}

bool UWorldUser::UpdateByTutorialSummon(const FUserInfo& UserInfo)
{
	bool bChanged = false;
	if (UserInfoEx.TutorialCharacterSummon != UserInfo.TutorialCharacterSummon)
	{
		UserInfoEx.TutorialCharacterSummon = UserInfo.TutorialCharacterSummon;
		bChanged = true;
	}

	if (UserInfoEx.TutorialSculptureSummon != UserInfo.TutorialSculptureSummon)
	{
		UserInfoEx.TutorialSculptureSummon = UserInfo.TutorialSculptureSummon;
		bChanged = true;
	}

	if (UserInfoEx.TutorialRelicSummon != UserInfo.TutorialRelicSummon)
	{
		UserInfoEx.TutorialRelicSummon = UserInfo.TutorialRelicSummon;
		bChanged = true;
	}

	return bChanged;
}

void UWorldUser::UpdateByLobbyTutorials(const TArray<int32>& InUserInfoTutorials)
{
	if (!InUserInfoTutorials.IsValidIndex(1))
	{
		Q6JsonLogBro(Warning, "UWorldUser::UpdateByLobbyTutorials - tutorial state is invalid");
		return;
	}

	UserInfoEx.LobbyTutorialsDone = ((uint64)InUserInfoTutorials[0]) << LOBBY_TUTORIALS_UPPER_SHIFT_BITS;
	UserInfoEx.LobbyTutorialsDone += InUserInfoTutorials[1];
	return;
}

void UWorldUser::OnFriendshipCollectResp(const FResError* Error, const FL2CFriendshipCollectResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendshipCollectResp(Msg);
}

void UWorldUser::OnWattRechargeResp(const FResError* Error, const FL2CWattRechargeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_WattRechargeResp(Msg);
}

void UWorldUser::OnCurrencyLoadResp(const FResError* Error, const FL2CCurrencyLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_CurrencyLoadResp(Msg);
	GameInstance->ReqNextContent();
}

void UWorldUser::OnUserRenameResp(const FResError* Error, const FL2CUserRenameResp& Msg)
{
	if (Error)
	{
		if (Error->Body.ErrorCode == Q6_ERROR_FORBIDDEN_WORD)
		{
			if (ABaseHUD* BaseHUD = GetBaseHUD(GameInstance))
			{
				BaseHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "BannedWordsNotify"));
			}

			return;
		}

		OnError(Error);
		return;
	}

	ACTION_DISPATCH_UserRenameResp(Msg);
}

void UWorldUser::OnUserSetTutorialResp(const FResError* Error, const FL2CUserSetTutorialResp& Msg, uint64 InLobbyTutorialsDone)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_UserSetTutorials(InLobbyTutorialsDone);
}

/////////////////////////////////////////////////////////////////////////////
// UWorldUser HUDStore Action

void UWorldUser::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UWorldUser, AccountName);
	REGISTER_ACTION_HANDLER(UWorldUser, FriendshipCollect);
	REGISTER_ACTION_HANDLER(UWorldUser, WattInfo);
	REGISTER_ACTION_HANDLER(UWorldUser, GemConsume);
	REGISTER_ACTION_HANDLER(UWorldUser, UpdateCurrency);
	REGISTER_ACTION_HANDLER(UWorldUser, AuthEnterLobbyResp);
	REGISTER_ACTION_HANDLER(UWorldUser, CurrencyLoadResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SagaStageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SpecialStageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DailyStageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, RaidEnterNof);
	REGISTER_ACTION_HANDLER(UWorldUser, RaidCanEnterNof);
	REGISTER_ACTION_HANDLER(UWorldUser, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, RaidFinalStageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, RelicPromoteResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SculpturePromoteResp);
	REGISTER_ACTION_HANDLER(UWorldUser, RelicTierUpResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SculptureTierUpResp);
	REGISTER_ACTION_HANDLER(UWorldUser, UserAddXpResp);
	REGISTER_ACTION_HANDLER(UWorldUser, UserRenameResp);
	REGISTER_ACTION_HANDLER(UWorldUser, UserSetTutorials);
	REGISTER_ACTION_HANDLER(UWorldUser, CharacterAddXpResp);
	REGISTER_ACTION_HANDLER(UWorldUser, RelicAddXpResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SculptureAddXpResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(UWorldUser, FriendshipCollectResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TrainingCenterStageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, CharacterPromoteResp);
	REGISTER_ACTION_HANDLER(UWorldUser, CharacterUnbindResp);
	REGISTER_ACTION_HANDLER(UWorldUser, CharacterEvoluteResp);
	REGISTER_ACTION_HANDLER(UWorldUser, CharacterTurnSkillLevelResp);
	REGISTER_ACTION_HANDLER(UWorldUser, CharacterUltimateSkillLevelResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PyramidUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PyramidPortalBoostUseResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PowerPlantUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PowerPlantStoreResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PowerPlantRechargeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, VacationUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, VacationStartResp);
	REGISTER_ACTION_HANDLER(UWorldUser, VacationEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, WattRechargeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PetSkillUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PetParkUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PetParkHarvestResp);
	REGISTER_ACTION_HANDLER(UWorldUser, PetParkUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TempleUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TempleArtifactUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TempleArtifactBoostResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TempleHarvestResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TempleUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevStageClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevWattRechargeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevWattConsumeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevAddXpResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevAddCurrencyResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevBondAddResp);
	REGISTER_ACTION_HANDLER(UWorldUser, DevTrainingCenterClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, MailReceiveResp);
	REGISTER_ACTION_HANDLER(UWorldUser, ShopBuyItemResp);
	REGISTER_ACTION_HANDLER(UWorldUser, ShopSellItemResp);
	REGISTER_ACTION_HANDLER(UWorldUser, WeeklyMissionShuffleResp);
	REGISTER_ACTION_HANDLER(UWorldUser, TitleChangeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentCollabo01StageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentValentineDayStageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentMultiSideBattleStageBeginResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UWorldUser, EventContentMultisideBattleReceiveRankRewardResp);
	REGISTER_ACTION_HANDLER(UWorldUser, SmelterUpgradeResp);
	REGISTER_ACTION_HANDLER(UWorldUser, AlchemylabIncStockResp);
	REGISTER_ACTION_HANDLER(UWorldUser, AlchemylabDecStockResp);
	REGISTER_ACTION_HANDLER(UWorldUser, AlchemylabReceiveResp);
	REGISTER_ACTION_HANDLER(UWorldUser, AlchemylabUpgradeResp);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, AccountName)
{
	auto Action = ACTION_PARSE_AccountName(InAction);
	UserInfoEx.AccountName = Action->GetVal();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, FriendshipCollect)
{
	if (bFriendshipCollect == false)
	{
		bFriendshipCollect = true;
		ReqFriendshipCollect();
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, WattInfo)
{
	auto Action = ACTION_PARSE_WattInfo(InAction);
	return UpdateByWattInfo(Action->GetVal());
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, GemConsume)
{
	auto Action = ACTION_PARSE_GemConsume(InAction);
	int32 FreeGem = Action->GetVal();
	int32 PaidGem = Action->GetVal2();

	return UpdateByFreeGem(FreeGem) || UpdateByPaidGem(PaidGem);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, UpdateCurrency)
{
	auto Action = ACTION_PARSE_UpdateCurrency(InAction);
	return UpdateByCurrencyInfo(Action->GetVal());
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, AuthEnterLobbyResp)
{
	auto Action = ACTION_PARSE_AuthEnterLobbyResp(InAction);

	auto& Res = Action->GetVal();
	UserInfoEx.UserId = Res.UserInfo.UserId;
	UserInfoEx.UserCode = Res.UserInfo.UserCode;
	UserInfoEx.Nickname = Res.UserInfo.Nickname;

	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByTutorialSummon(Res.UserInfo);
	UpdateByLobbyTutorials(Res.UserInfo.Tutorials);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, CurrencyLoadResp)
{
	auto Action = ACTION_PARSE_CurrencyLoadResp(InAction);

	auto& Res = Action->GetVal();

	CurrencyCheckList = Res.CurrencyCheckList;
	return UpdateByCurrencyInfo(Res.CurrencyInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SagaStageBeginResp)
{
	auto Action = ACTION_PARSE_SagaStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SpecialStageBeginResp)
{
	auto Action = ACTION_PARSE_SpecialStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	auto& Res = Action->GetVal();

	bool Ret = false;
	Ret |= UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DailyStageBeginResp)
{
	auto Action = ACTION_PARSE_DailyStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RaidFinalStageBeginResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RaidEnterNof)
{
	auto Action = ACTION_PARSE_RaidEnterNof(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RaidCanEnterNof)
{
	auto Action = ACTION_PARSE_RaidCanEnterNof(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, UserAddXpResp)
{
	auto Action = ACTION_PARSE_UserAddXpResp(InAction);

	auto& Res = Action->GetVal();

	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, UserRenameResp)
{
	auto Action = ACTION_PARSE_UserRenameResp(InAction);
	auto& Res = Action->GetVal();

	UserInfoEx.Nickname = Res.UserName;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, UserSetTutorials)
{
	auto Action = ACTION_PARSE_UserSetTutorials(InAction);
	UserInfoEx.LobbyTutorialsDone = Action->GetVal();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, CharacterAddXpResp)
{
	auto Action = ACTION_PARSE_CharacterAddXpResp(InAction);

	auto& Res = Action->GetVal();

	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RelicAddXpResp)
{
	auto Action = ACTION_PARSE_RelicAddXpResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RelicPromoteResp)
{
	auto Action = ACTION_PARSE_RelicPromoteResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, RelicTierUpResp)
{
	auto Action = ACTION_PARSE_RelicTierUpResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SculptureAddXpResp)
{
	auto Action = ACTION_PARSE_SculptureAddXpResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SculpturePromoteResp)
{
	auto Action = ACTION_PARSE_SculpturePromoteResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SculptureTierUpResp)
{
	auto Action = ACTION_PARSE_SculptureTierUpResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByFreeGem(Res.CurrencyInfo.FreeGem);
	Ret |= UpdateByPaidGem(Res.CurrencyInfo.PaidGem);
	Ret |= UpdateBySummonTicket(Res.CurrencyInfo.SummonTicket);
	Ret |= UpdateBySculpturePoint(Res.CurrencyInfo.SculpturePoint);
	Ret |= UpdateByRelicPoint(Res.CurrencyInfo.RelicPoint);
	Ret |= UpdateByFriendshipPoint(Res.CurrencyInfo.FriendshipPoint);
	Ret |= UpdateByCharacterDisk(Res.CurrencyInfo.CharacterDisk);
	Ret |= UpdateByRelicDisk(Res.CurrencyInfo.RelicDisk);
	Ret |= UpdateBySculptureDisk(Res.CurrencyInfo.SculptureDisk);
	Ret |= UpdateByTutorialSummon(Res.UserInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, FriendshipCollectResp)
{
	auto Action = ACTION_PARSE_FriendshipCollectResp(InAction);

	auto& Res = Action->GetVal();
	FriendshipCollectInfo.GainedFriendshipPoint = Res.GainedFriendshipPoint;
	FriendshipCollectInfo.MostPopularCharacterId = Res.MostPopularCharacterId;

	return UpdateByFriendshipPoint(Res.CurrencyInfo.FriendshipPoint);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TrainingCenterStageBeginResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, CharacterPromoteResp)
{
	auto Action = ACTION_PARSE_CharacterPromoteResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, CharacterUnbindResp)
{
	auto Action = ACTION_PARSE_CharacterUnbindResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, CharacterEvoluteResp)
{
	auto Action = ACTION_PARSE_CharacterEvoluteResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, WeeklyMissionShuffleResp)
{
	auto Action = ACTION_PARSE_WeeklyMissionShuffleResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, CharacterTurnSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterTurnSkillLevelResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, CharacterUltimateSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterUltimateSkillLevelResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PyramidUpgradeResp)
{
	auto Action = ACTION_PARSE_PyramidUpgradeResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, SmelterUpgradeResp)
{
	auto Action = ACTION_PARSE_SmelterUpgradeResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, AlchemylabIncStockResp)
{
	auto Action = ACTION_PARSE_AlchemylabIncStockResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, AlchemylabDecStockResp)
{
	auto Action = ACTION_PARSE_AlchemylabDecStockResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, AlchemylabReceiveResp)
{
	auto Action = ACTION_PARSE_AlchemylabReceiveResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByLumicube(Res.CurrencyInfo.Lumicube);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, AlchemylabUpgradeResp)
{
	auto Action = ACTION_PARSE_AlchemylabUpgradeResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PyramidPortalBoostUseResp)
{
	auto Action = ACTION_PARSE_PyramidPortalBoostUseResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);

	const auto& Res = Action->GetVal();
	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);
	Ret |= UpdateByTutorialSummon(Res.UserInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevWattRechargeResp)
{
	auto Action = ACTION_PARSE_DevWattRechargeResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevWattConsumeResp)
{
	auto Action = ACTION_PARSE_DevWattConsumeResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevAddXpResp)
{
	auto Action = ACTION_PARSE_DevAddXpResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByLevel(FUserLevelType(Res.UserInfo.Level));
	Ret |= UpdateByXp(Res.UserInfo.Xp);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevAddCurrencyResp)
{
	auto Action = ACTION_PARSE_DevAddCurrencyResp(InAction);

	auto& Res = Action->GetVal();
	switch (static_cast<ECurrencyType>(Res.CurrencyType))
	{
	case ECurrencyType::Gold:
		return UpdateByGold(Res.CurrencyInfo.Gold);
	case ECurrencyType::FreeGem:
		return UpdateByFreeGem(Res.CurrencyInfo.FreeGem);
	case ECurrencyType::PaidGem:
		return UpdateByPaidGem(Res.CurrencyInfo.PaidGem);
	case ECurrencyType::SummonTicket:
		return UpdateBySummonTicket(Res.CurrencyInfo.SummonTicket);
	case ECurrencyType::SculpturePoint:
		return UpdateBySculpturePoint(Res.CurrencyInfo.SculpturePoint);
	case ECurrencyType::RelicPoint:
		return UpdateByRelicPoint(Res.CurrencyInfo.RelicPoint);
	case ECurrencyType::FriendshipPoint:
		return UpdateByFriendshipPoint(Res.CurrencyInfo.FriendshipPoint);
	case ECurrencyType::SmallBattery:
		return UpdateBySmallBattery(Res.CurrencyInfo.SmallBattery);
	case ECurrencyType::MediumBattery:
		return UpdateByMediumBattery(Res.CurrencyInfo.MediumBattery);
	case ECurrencyType::LargeBattery:
		return UpdateByLargeBattery(Res.CurrencyInfo.LargeBattery);
	case ECurrencyType::Lumicube:
		return UpdateByLumicube(Res.CurrencyInfo.Lumicube);
	case ECurrencyType::CharacterDisk:
		return UpdateByCharacterDisk(Res.CurrencyInfo.CharacterDisk);
	case ECurrencyType::SculptureDisk:
		return UpdateBySculptureDisk(Res.CurrencyInfo.SculptureDisk);
	case ECurrencyType::RelicDisk:
		return UpdateByRelicDisk(Res.CurrencyInfo.RelicDisk);
	default:
		break;
	}
	return false;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevBondAddResp)
{
	auto Action = ACTION_PARSE_DevBondAddResp(InAction);

	const FL2CDevBondAddResp& Res = Action->GetVal();
	if (Res.LevelUpRewards.Num() > 0)
	{
		return UpdateByCurrencyInfo(Res.CurrencyInfo);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByUserInfo(Res.UserInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	Ret |= UpdateByCurrencyInfo(Res.CurrencyInfo);
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByCurrencyInfo(Res.CurrencyInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, ShopBuyItemResp)
{
	auto Action = ACTION_PARSE_ShopBuyItemResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByCurrencyInfo(Res.CurrencyInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, ShopSellItemResp)
{
	auto Action = ACTION_PARSE_ShopSellItemResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByCurrencyInfo(Res.CurrencyInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PowerPlantUpgradeResp)
{
	auto Action = ACTION_PARSE_PowerPlantUpgradeResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByGold(Res.CurrencyInfo.Gold);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PowerPlantStoreResp)
{
	auto Action = ACTION_PARSE_PowerPlantStoreResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByGold(Res.CurrencyInfo.Gold);
	Ret |= UpdateByWattInfo(Res.WattInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PowerPlantRechargeResp)
{
	auto Action = ACTION_PARSE_PowerPlantRechargeResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByWattInfo(Res.WattInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, VacationUpgradeResp)
{
	auto Action = ACTION_PARSE_VacationUpgradeResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByGold(Res.CurrencyInfo.Gold);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, VacationStartResp)
{
	auto Action = ACTION_PARSE_VacationStartResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByGold(Res.CurrencyInfo.Gold);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, VacationEndResp)
{
	auto Action = ACTION_PARSE_VacationEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByGold(Res.CurrencyInfo.Gold);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, WattRechargeResp)
{
	auto Action = ACTION_PARSE_WattRechargeResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = UpdateByCurrencyInfo(Res.CurrencyInfo);
	Ret |= UpdateByWattInfo(Res.WattInfo);

	return Ret;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PetSkillUpgradeResp)
{
	auto Action = ACTION_PARSE_PetSkillUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PetParkUpgradeResp)
{
	auto Action = ACTION_PARSE_PetParkUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PetParkHarvestResp)
{
	auto Action = ACTION_PARSE_PetParkHarvestResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByCurrencyInfo(Res.CurrencyInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, PetParkUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_PetParkUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByCurrencyInfo(Res.CurrencyInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TempleUpgradeResp)
{
	auto Action = ACTION_PARSE_TempleUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TempleArtifactUpgradeResp)
{
	auto Action = ACTION_PARSE_TempleArtifactUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TempleHarvestResp)
{
	auto Action = ACTION_PARSE_TempleHarvestResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByCurrencyInfo(Res.CurrencyInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TempleUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_TempleUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByCurrencyInfo(Res.CurrencyInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TempleArtifactBoostResp)
{
	auto Action = ACTION_PARSE_TempleArtifactBoostResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateByGold(Res.CurrencyInfo.Gold);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, TitleChangeResp)
{
	auto Action = ACTION_PARSE_TitleChangeResp(InAction);
	auto& Res = Action->GetVal();

	UserInfoEx.Title = Res.Type;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentCollabo01StageBeginResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentValentineDayStageBeginResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentMultiSideBattleStageBeginResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateByWattInfo(Res.WattInfo);
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UWorldUser, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);

	auto& Res = Action->GetVal();
	UpdateByUserInfo(Res.UserInfo);
	UpdateByWattInfo(Res.WattInfo);
	UpdateByCurrencyInfo(Res.CurrencyInfo);

	return true;
}
