#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "UserRecordManager.generated.h"

UCLASS()
class Q6_API UUserRecordManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UUserRecordManager();

	void ReqList(int32 PageNo = 0) const;
	void ReqResurrectionCount() const;
	int32 GetResurrectionCount() const;
	void OnListResp(const FResError* Error, const FL2CUserRecordListResp& Msg);
	void OnRezCountResp(const FResError* Error, const FL2CUserRecordRezCountResp& Msg);

	const FUserRecordInfo* Find(FUserRecordType UserRecordType) const { return Records.Find(UserRecordType); }
	const TMap<FUserRecordType, FUserRecordInfo>& GetRecords() const { return Records; }
	const TMap<FUserRecordType, const FCMSUserRecordRow*>& GetRecordRows() const { return RecordRows; }

protected:
	void RegisterActionHandlers();

	DECLARE_ACTION_HANDLER(ClearUserRecord);
	DECLARE_ACTION_HANDLER(UserRecordListResp);
	DECLARE_ACTION_HANDLER(UserRecordRezCountResp);

	// UI
	DECLARE_ACTION_HANDLER(UserRecordRows);

private:
	void UpdateRecord(const FUserRecordInfo& Info);

	TMap<FUserRecordType, FUserRecordInfo> Records;
	TMap<FUserRecordType, const FCMSUserRecordRow*> RecordRows;
};
