// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Tickable.h"
#include "Containers/Queue.h"
#include "HUDStoreInterface.h"
#include "HUDStore.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FWonderInfo;
struct FCharacterType;
struct FCMSCharUnlockElemRow;
struct FItemIconInfo;
struct FAlchemyLabType;

class UAvatarManager;
class UBagItemManager;
class UCharacterManager;
class UFriendManager;
class UHSBaseWidget;
class UJokerSetManager;
class UPartyManager;
class UQ6GameInstance;
class URelicManager;
class URewardManager;
class USagaManager;
class USculptureManager;
class UActRecordManager;
class UUserRecordManager;
class UCodexManager;
class UWeeklyMissionManager;
class UCharMissionManager;
class UEventMissionManager;
class URaidManager;
class USummonManager;
class USpecialManager;
class UUIStateManager;
class UWorldUser;
class UTrainingCenterManager;
class UPowerPlantManager;
class UPyramidManager;
class UBondManager;
class UTempleManager;
class UPetManager;
class UVacationManager;
class UDailyDungeonManager;
class UMailManager;
class UCheckInManager;
class UShopManager;
class UEventManager;
class ULobbyTemplateManager;
class ULobbySetManager;
class UNewMarkManager;
class UTitleManager;
class UContentFeatureOpenManager;
class USmelterManager;
class UAlchemylabManager;
class UBattleHelper;
class UFriendBook;

struct FRelicId;
struct FCharacterId;
struct FSculptureId;
struct FSagaType;

enum class EAttributeCategory : uint8;
enum class EInventoryType : uint8;
enum class EWonderCategory : uint8;

///////////////////////////////////////////////////////////////////////////////////////////
// UHUDStore

USTRUCT()
struct FStoreInfo
{
	GENERATED_BODY()

	TArray<UHSBaseWidget*> SubscribeWidgets;

	UPROPERTY(Transient)
	UHUDStoreBase* Store;

	FStoreInfo() : Store(nullptr) {}
	FStoreInfo(UHUDStoreBase* InStore) : Store(InStore) {}
};

UCLASS()
class UHUDStore : public UObject, public FTickableGameObject
{
	GENERATED_BODY()

public:
	friend class Action;

	UHUDStore();

	void Initialize(UQ6GameInstance* InGameInstance);
	void InitializeNetworkNotify();
	void Shutdown();
	void OnPostLoadResource();

	// Register Action
	void RegisterNullActionHandler(EHSType StoreType, EHSActionType ActionType);
	void RegisterActionHandler(EHSType StoreType, EHSActionType ActionType, const FOnHSAction& ActionDelegate);

	// Subscribe Widget
	void Subscribe(EHSType StoreType, UHSBaseWidget* Widget);
	void Unsubscribe(UHSBaseWidget* Widget);

	// Tick
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override { return true; }
	virtual bool IsTickableWhenPaused() const override { return true; }
	virtual bool IsTickableInEditor() const override { return false; }
	virtual TStatId GetStatId() const override { RETURN_QUICK_DECLARE_CYCLE_STAT(UHUDStore, STATGROUP_Tickables); }

	// Getter
	bool IsInitialized() const { return bInitializedHUDStore; }
	const UCharacterManager& GetCharacterManager() const;
	const UBagItemManager& GetBagItemManager() const;
	const URelicManager& GetRelicManager() const;
	const UFriendManager& GetFriendManager() const;
	const UJokerSetManager& GetJokerManager() const;
	const USculptureManager& GetSculptureManager() const;
	const UActRecordManager& GetActRecordManager() const;
	const UUserRecordManager& GetUserRecordManager() const;
	const UCodexManager& GetCodexManager() const;
	const UWeeklyMissionManager& GetWeeklyMissionManager() const;
	const UCharMissionManager& GetCharMissionManager() const;
	const UEventMissionManager& GetEventMissionManager() const;
	const UTitleManager& GetTitleManager() const;
	const UBondManager& GetBondManager() const;
	const URaidManager& GetRaidManager() const;
	const UPartyManager& GetPartyManager() const;
	const URewardManager& GetRewardManager() const;
	const USagaManager& GetSagaManager() const;
	const USpecialManager& GetSpecialManager() const;
	const USummonManager& GetSummonManager() const;
	const UWorldUser& GetWorldUser() const;
	const UUIStateManager& GetUIStateManager() const;
	const UTrainingCenterManager& GetTrainingCenterManager() const;
	const UPyramidManager& GetPyramidManager() const;
	const UTempleManager& GetTempleManager() const;
	const UPowerPlantManager& GetPowerPlantManager() const;
	const UPetManager& GetPetManager() const;
	const UVacationManager& GetVacationManager() const;
	const USmelterManager& GetSmelterManager() const;
	const UAlchemylabManager& GetAlchemylabManager() const;
	const UDailyDungeonManager& GetDailyDungeonManager() const;
	const UMailManager& GetMailManager() const;
	const UCheckInManager& GetCheckInManager() const;
	const UShopManager& GetShopManager() const;
	const UEventManager& GetEventManager() const;
	const ULobbyTemplateManager& GetLobbyTemplateManager() const;
	const ULobbySetManager& GetLobbySetManager() const;
	const UNewMarkManager& GetNewMarkManager() const;
	const UContentFeatureOpenManager& GetContentFeatureOpenManager() const;
	const UAvatarManager& GetAvatarManager() const;
	const UBattleHelper& GetBattleHelper() const;
	const UFriendBook& GetFriendBook() const;

	// Wonder

	FWonderInfo GetWonderInfo(EWonderCategory Category) const;
	bool CheckMigriumStockCost() const;
	bool CheckAlchemyLabStockCost(FAlchemyLabType Type) const;

	TArray<FRelicId> GetUsedRelicIds() const;
	TArray<FSculptureId> GetUsedSculptureIds() const;
	TArray<FCharacterId> GetUsedCharacterIds() const;

	bool IsUnlockedCharUnlockElem(FCharacterType InCharacterType, const FCMSCharUnlockElemRow* InElem) const;
	bool HasMaxCollection() const;
	bool IsSpecialStageOpened(FSagaType SagaType) const;

	void ReqClearNewIfNotCleared(const FItemIconInfo& ItemInfo) const;

	void ReqWonderUpgrade(EWonderCategory Category) const;
	void ReqWonderUpgradeComplete(EWonderCategory Category) const;
	void ReqWonderHarvest(EWonderCategory Category) const;

	void ReqSetStash(EInventoryType InventoryType, bool bStashed, const TArray<int64>& Ids) const;
	void ReqSetLock(EAttributeCategory AttributeType, int64 ItemId, bool bLocked) const;

private:
	void DeregisterActionHandlers();
	void UnsubscribeAll();

	void Dispatch(TSharedPtr<FHSAction> Action);
	void DispatchInternal(TSharedPtr<FHSAction> Action);

	bool OnAction(TSharedPtr<FHSAction> Action, bool bStoreDirties[]);
	// this function do nothing and only return true to guarantee notification
	bool OnActionNull(TSharedPtr<FHSAction>) { return true; }

	void ExecuteDeferredSubscriptions();

private:
	URaidManager& GetMutableRaidManager();
	UFriendManager& GetMutableFriendManager();
	UNewMarkManager& GetMutableNewMarkManager();

	TQueue<TSharedPtr<FHSAction>> ActionPool;

	struct FStoreActionHandler
	{
		EHSType StoreType;
		FOnHSAction OnAction;
	};

	struct FActionHandler
	{
		TArray<FStoreActionHandler> OnActions;
	};

	struct FDeferredSubscription
	{
		EHSType StoreType;
		UHSBaseWidget* Widget;
	};

	// Data Store
	UPROPERTY(Transient)
	TArray<FStoreInfo> StoreInfos;

	// Delegate handlers
	TMap<EHSActionType, FActionHandler> ActionHandlers;
	TSet<UHSBaseWidget*> SubscribeWidgets;

	TArray<FDeferredSubscription> DeferredSubscriptions;
	bool bDispatchingHSEvents;

	bool bInitializedHUDStore;
};
