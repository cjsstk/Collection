#include "NewMarkManager.h"

#include "UMG.h"
#include "AlchemylabManager.h"
#include "BagItemManager.h"
#include "CharacterManager.h"
#include "CharMissionManager.h"
#include "CodexManager.h"
#include "ContentFeatureOpenManager.h"
#include "DailyDungeonManager.h"
#include "FriendManager.h"
#include "HUDStore/EventManager.h"
#include "HUDStore/FriendBook.h"
#include "PetManager.h"
#include "PyramidManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6Define.h"
#include "RaidManager.h"
#include "RelicManager.h"
#include "SagaManager.h"
#include "SculptureManager.h"
#include "ShopManager.h"
#include "SmelterManager.h"
#include "SpecialManager.h"
#include "SummonManager.h"
#include "SystemConstHelper.h"
#include "TrainingCenterManager.h"
#include "TempleManager.h"
#include "VacationManager.h"
#include "WeeklyMissionManager.h"
#include "WidgetUtil.h"
#include "MailManager.h"

///////////////////////////////////////////////////////////////////////////////////////////
// FNewMarkNotifyHandler

class FNewMarkNotifyHandler
{
public:
	FNewMarkNotifyHandler() : Inited(false)
	{
	}

	void Init(UQ6GameInstance* InGameInstance)
	{
		if (Inited) {
			return;
		}

		Inited = true;

		FQ6ClientNetwork& ClientNetwork = InGameInstance->GetClientNetwork();
		ClientNetwork.RegisterPush(TEXT("newMarkNotifyMail"), TQ6PushDelegate<FL2CNewMarkNotifyMail>::CreateRaw(
			this, &FNewMarkNotifyHandler::OnNewMarkNotifyMail));
	}

	void OnNewMarkNotifyMail(const FL2CNewMarkNotifyMail& Notify)
	{
		ACTION_DISPATCH_NewMarkNotifyMail(true);
	}

private:
	bool Inited;
};


///////////////////////////////////////////////////////////////////////////////////////////
// UNewMarkManager

UNewMarkManager::UNewMarkManager()
	: NewMarkNotifyHandlerInstance(new FNewMarkNotifyHandler)
{
	InitStore(EHSType::NewMark);
}

UNewMarkManager::~UNewMarkManager()
{
	if (NewMarkNotifyHandlerInstance != nullptr)
	{
		delete NewMarkNotifyHandlerInstance;
	}
}

void UNewMarkManager::InitNotifyHandler()
{
	if (NewMarkNotifyHandlerInstance != nullptr)
	{
		NewMarkNotifyHandlerInstance->Init(GameInstance);
	}
}

ENewMarkType UNewMarkManager::GetMainSagaType() const
{
	const FSagaType LastType = GetHUDStore().GetSagaManager().GetLastSagaType();
	if (LastType == SagaTypeInvalid)
	{
		return ENewMarkType::New;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(LastType);
	if (SagaRow.StageType == EStageType::Epilogue)
	{
		const FCMSSagaRow& NextSagaRow = GetCMS()->GetSagaRowOrDummy(FSagaType(SagaRow.NextType));
		if (NextSagaRow.CmsType() == LastType)
		{
			return ENewMarkType::ComingSoon;
		}

		return ENewMarkType::New;
	}

	return ENewMarkType::None;
}

ESlateVisibility UNewMarkManager::GetMainTrainingCenterVisibility() const
{
	if (!GetHUDStore().GetContentFeatureOpenManager().IsOpenContentFeature(EFeatureOpenType::TrainingCenter))
	{
		return ESlateVisibility::Collapsed;
	}

	const UTrainingCenterManager& TrainingCenterMgr = GetHUDStore().GetTrainingCenterManager();

	if (TrainingCenterMgr.IsHistoryExpired())
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	FSagaType HistorySagaType = TrainingCenterMgr.GetHistory().SagaType;
	if (HistorySagaType == SagaTypeInvalid)
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetMainSpecialVisibility() const
{
	for (int32 n = 1; n < (int32)ESpecialCategoryMax; ++n)	// Except none category
	{
		ESlateVisibility Visibility = GetSpecialCategoryVisibility((ESpecialCategory)n);
		if (Visibility == ESlateVisibility::SelfHitTestInvisible)
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetMainRaidVisibility() const
{
	FSagaType LastSagaType = GetHUDStore().GetSagaManager().GetLastSagaType();
	if (LastSagaType < SystemConst::Q6_RAID_CERTIFICATE_SAGA)
	{
		return ESlateVisibility::Collapsed;
	}

	const URaidManager& RaidMgr = GetHUDStore().GetRaidManager();
	bool bAnyNewRaid = (RaidMgr.GetOpenRaidType() != RaidTypeInvalid);

	const TMap<FRaidId, FRaidFinal>& RaidFinals = RaidMgr.GetRaidFinals();

	for (const auto Elem : RaidFinals)
	{
		const FRaidFinal& RaidFinal = Elem.Value;
		const FRaidFinalInfo& Info = RaidFinal.GetInfo();
		bAnyNewRaid |= RaidFinal.GetRaidEnded();
	}

	if (bAnyNewRaid)
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	return ESlateVisibility::Collapsed;
}

ENewMarkType UNewMarkManager::GetNaviBarType(EHUDWidgetType HUDWidgetType) const
{
	if (HUDWidgetType == EHUDWidgetType::Wonder)
	{
		return GetMainWonderType();
	}

	if (HUDWidgetType == EHUDWidgetType::Mission)
	{
		return GetMainWeeklyMissionType();
	}

	if (HUDWidgetType == EHUDWidgetType::Summon)
	{
		return GetMainSummonType();
	}

	if (HUDWidgetType == EHUDWidgetType::Friend)
	{
		return GetFriendType();
	}

	if (HUDWidgetType == EHUDWidgetType::Codex)
	{
		return GetCodexType();
	}

//Temporary (QSIX-8331)
// 	if (HUDWidgetType == EHUDWidgetType::Shop)
// 	{
// 		return GetShopType();
// 	}

	if (HUDWidgetType == EHUDWidgetType::Collection)
	{
		return GetCollectionType();
	}

	return ENewMarkType::None;
}

ENewMarkType UNewMarkManager::GetMainWonderType() const
{
	for (int32 i = 0; i < EWonderCategoryMax; ++i)
	{
		const FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo((EWonderCategory)i);
		if (!WonderInfo.bOpened)
		{
			continue;
		}

		if (GetWonderIncomeVisibility(WonderInfo) == ESlateVisibility::SelfHitTestInvisible)
		{
			return ENewMarkType::Dot;
		}

		if (GetWonderMainVisibility(WonderInfo) == ESlateVisibility::SelfHitTestInvisible)
		{
			return ENewMarkType::Dot;
		}
	}

	return ENewMarkType::None;
}

ENewMarkType UNewMarkManager::GetMainWeeklyMissionType() const
{
	if (!GetHUDStore().GetContentFeatureOpenManager().IsOpenContentFeature(EFeatureOpenType::WeeklyMisson))
	{
		return ENewMarkType::None;
	}

	const UWeeklyMissionManager& MissionManager = GetHUDStore().GetWeeklyMissionManager();
	const FMissionInfo& MissionInfo = MissionManager.GetMissioninfo();

	if (GetWeeklyMissionConfirmVisibility(MissionInfo) == ESlateVisibility::SelfHitTestInvisible)
	{
		return ENewMarkType::Dot;
	}

	// check mission reward

	for (int32 i = 0; i < MAX_WEEKLY_MISSION; ++i)
	{
		const FMissionType& Type = MissionInfo.M[i];
		const int32 CurValue = MissionInfo.MIng[i];
		const int32 MaxValue = MissionManager.GetMaxValue(Type);
		const int32 RewardUtc = MissionInfo.RUtc[i];
		if (GetWeeklyMissionVisibility(CurValue, MaxValue, RewardUtc) == ESlateVisibility::SelfHitTestInvisible)
		{
			return ENewMarkType::Dot;
		}
	}

	// check mission bonus reward

	for (int32 i = 0; i < MAX_WEEKLY_BINGO; ++i)
	{
		if (GetWeeklyMissionBonusVisibility(i) == ESlateVisibility::SelfHitTestInvisible)
		{
		return ENewMarkType::Dot;
		}
	}

	return ENewMarkType::None;
}

ENewMarkType UNewMarkManager::GetMainSummonType() const
{
	if (GetHUDStore().GetEventManager().IsEventScheduleChanged())
	{
		return ENewMarkType::Dot;
	}

	const USummonManager& SummonMgr = GetHUDStore().GetSummonManager();
	const TArray<FBoxProductType>& FreeInfos = SummonMgr.GetSummonFreeInfos();
	if (FreeInfos.Num() > 0)
	{
		return ENewMarkType::Dot;
	}

	const TMap<int32, int32>& Mileages = SummonMgr.GetMileages();
	for (const auto& Elem : Mileages)
	{
		const int32& EventId = Elem.Key;
		const int32& Mileage = Elem.Value;

		int32 PickupMileage = GetCMS()->GetNeedPickupMileage(EventId);
		if (PickupMileage > 0 && Mileage >= PickupMileage)
		{
			return ENewMarkType::Dot;
		}
	}

	return ENewMarkType::None;
}

ENewMarkType UNewMarkManager::GetSagaEpisodeType(int32 Episode) const
{
	const FSagaType SagaType = GetHUDStore().GetSagaManager().GetLastSagaType();
	if (SagaType == SagaTypeInvalid)
	{
		return ENewMarkType::New;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	const FCMSSagaRow& NextSagaRow = GetCMS()->GetSagaRowOrDummy(FSagaType(SagaRow.NextType));

	if (Episode < NextSagaRow.Episode)
	{
		return ENewMarkType::Clear;
	}

	if (NextSagaRow.StageType == EStageType::Prologue)
	{
		return ENewMarkType::New;
	}

	return ENewMarkType::None;
}

ESlateVisibility UNewMarkManager::GetRaidVisibility(ERaidStageState RaidState) const
{
	if (RaidState == ERaidStageState::Final
		|| RaidState == ERaidStageState::Joinable)
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetSpecialCategoryVisibility(ESpecialCategory SpecialCategory) const
{
	if (SpecialCategory == ESpecialCategory::Saga)
	{
		if (GetSpecialBossCategoryVisibility() == ESlateVisibility::SelfHitTestInvisible)
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}
	else if (SpecialCategory == ESpecialCategory::Character)
	{
		const TArray<const FCMSSpecialRow*> SpecialRows = GetCMS()->GetSpecialEpisodes(ESpecialCategory::Character);
		for (const FCMSSpecialRow* Row : SpecialRows)
		{
			check(Row);

			if (GetSpecialCharacterVisibility(FCharacterType(Row->ConditionId)) == ESlateVisibility::SelfHitTestInvisible)
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}
	}
	else if (SpecialCategory == ESpecialCategory::Wonder)
	{
		for (int32 n = 1; n < EWonderCategoryMax; ++n)	// except wonder main category
		{
			if (GetSpecialWonderCategoryVisibility((EWonderCategory)n) == ESlateVisibility::SelfHitTestInvisible)
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetSpecialBossCategoryVisibility() const
{
	TArray<FSpecialRecord> History = GetHUDStore().GetSpecialManager().GetFilteredHistory(ESpecialCategory::Saga);
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.Stages.Num() == 0)
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetSpecialWonderCategoryVisibility(EWonderCategory WonderCategory) const
{
	TArray<FSpecialRecord> History = GetHUDStore().GetSpecialManager().GetWonderHistory(WonderCategory);
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.Stages.Num() == 0)
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetSpecialCharacterVisibility(FCharacterType CharacterType) const
{
	const UHUDStore& HUDStore = GetHUDStore();
	TArray<FSpecialRecord> History = HUDStore.GetSpecialManager().GetFilteredHistory(ESpecialCategory::Character);
	for (const FSpecialRecord& SpecialRecord : History)
	{
		if (SpecialRecord.ConditionId != CharacterType.x)
		{
			continue;
		}

		TArray<const FCMSSagaRow*> SagaRows = GetCMS()->GetStageRows(EContentType::Special, SpecialRecord.Episode);
		check(SpecialRecord.Stages.Num() <= SagaRows.Num());

		for (int32 i = 0; i < SagaRows.Num(); ++i)
		{
			const FCMSSagaRow* SagaRow = SagaRows[i];
			check(SagaRow);

			bool bOpened = HUDStore.IsSpecialStageOpened(SagaRow->CmsType());
			if (!bOpened)
			{
				continue;
			}

			if (!SpecialRecord.Stages.IsValidIndex(i))
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}

			const FSpecialStage& Stage = SpecialRecord.Stages[i];
			if (Stage.ClearCount == 0)
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}
	}

	return ESlateVisibility::Collapsed;
}

bool UNewMarkManager::GetDailyDungeonVisible(EDayOfWeekType DayOfWeek, EDailyDungeonCategory DailyCategory, int32 Stage) const
{
	if (!GetHUDStore().GetContentFeatureOpenManager().IsOpenContentFeature(EFeatureOpenType::DailyDungeon))
	{
		return false;
	}

	bool bNewStage = false;
	int32 AccountLevel = GetHUDStore().GetWorldUser().GetLevel();

	const UCMS* CMS = GetCMS();
	const TArray<const FCMSDailyDungeonRow*> DungeonRows = CMS->GetDailyDungeonValidRows(DayOfWeek);
	for (const FCMSDailyDungeonRow* DungeonRow : DungeonRows)
	{
		if (DungeonRow->DungeonType != DailyCategory)
		{
			continue;
		}

		bool bValidLevel = AccountLevel >= DungeonRow->MinLevel && AccountLevel <= DungeonRow->MaxLevel;
#if !UE_BUILD_SHIPPING
		if (GameInstance->IsDevMode())
		{
			bValidLevel = true;
		}
#endif

		if (!bValidLevel)
		{
			continue;
		}

		const FCMSSagaRow& SagaRow = DungeonRow->GetSaga();
		bNewStage |= (Stage & (1 << (SagaRow.Stage - 1))) == 0;
	}

	return bNewStage;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeCategory::Max);
	Visibilities[(int32)EUpgradeCategory::Character] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeCategory::Skill] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeCategory::Sculpture] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeCategory::Relic] = ESlateVisibility::Collapsed;

	TArray<ESlateVisibility> NewMarkVisibilities;
	NewMarkVisibilities = GetUpgradeCharacterVisibilities();
	if (NewMarkVisibilities.Contains(ESlateVisibility::SelfHitTestInvisible))
	{
		Visibilities[(int32)EUpgradeCategory::Character] = ESlateVisibility::SelfHitTestInvisible;
	}

	NewMarkVisibilities = GetUpgradeSkillVisibilities();
	if (NewMarkVisibilities.Contains(ESlateVisibility::SelfHitTestInvisible))
	{
		Visibilities[(int32)EUpgradeCategory::Skill] = ESlateVisibility::SelfHitTestInvisible;
	}

	NewMarkVisibilities = GetUpgradeSculptureVisibilities();
	if (NewMarkVisibilities.Contains(ESlateVisibility::SelfHitTestInvisible))
	{
		Visibilities[(int32)EUpgradeCategory::Sculpture] = ESlateVisibility::SelfHitTestInvisible;
	}

	NewMarkVisibilities = GetUpgradeRelicVisibilities();
	if (NewMarkVisibilities.Contains(ESlateVisibility::SelfHitTestInvisible))
	{
		Visibilities[(int32)EUpgradeCategory::Relic] = ESlateVisibility::SelfHitTestInvisible;
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeCharacterVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeCharacterCategory::Max);

	Visibilities[(int32)EUpgradeCharacterCategory::LevelUp] = ESlateVisibility::Collapsed;	// level up always collapsed
	Visibilities[(int32)EUpgradeCharacterCategory::Promote] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeCharacterCategory::Unbind] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeCharacterCategory::Evolute] = ESlateVisibility::Collapsed;

	const UCMS* CMS = GetCMS();
	const TMap<FCharacterId, FCharacter>& Characters = GetHUDStore().GetCharacterManager().GetAllCharacters();
	for (const auto& Elem : Characters)
	{
		const FCharacter& Character = Elem.Value;
		if (Character.IsStashed())
		{
			continue;
		}

		const FCharacterInfo& CharacterInfo = Character.GetInfo();

		if (Visibilities[(int32)EUpgradeCharacterCategory::Promote] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeCharacterCategory::Promote] = GetUpgradeCharacterVisibility(EUpgradeCharacterCategory::Promote, CharacterInfo);
		}

		if (Visibilities[(int32)EUpgradeCharacterCategory::Unbind] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeCharacterCategory::Unbind] = GetUpgradeCharacterVisibility(EUpgradeCharacterCategory::Unbind, CharacterInfo);
		}

		if (Visibilities[(int32)EUpgradeCharacterCategory::Evolute] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeCharacterCategory::Evolute] = GetUpgradeCharacterVisibility(EUpgradeCharacterCategory::Evolute, CharacterInfo);
		}
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeSkillVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeSkillCategory::Max);
	Visibilities[(int32)EUpgradeSkillCategory::TurnBegin] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeSkillCategory::Ultimate] = ESlateVisibility::Collapsed;

	const UCMS* CMS = GetCMS();
	const TMap<FCharacterId, FCharacter>& Characters = GetHUDStore().GetCharacterManager().GetAllCharacters();
	for (const auto& Elem : Characters)
	{
		const FCharacter& Character = Elem.Value;
		if (Character.IsStashed())
		{
			continue;
		}

		const FCharacterInfo& CharacterInfo = Character.GetInfo();
		if (Visibilities[(int32)EUpgradeSkillCategory::TurnBegin] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeSkillCategory::TurnBegin] = GetUpgradeSkillVisibility(EUpgradeSkillCategory::TurnBegin, CharacterInfo);
		}

		if (Visibilities[(int32)EUpgradeSkillCategory::Ultimate] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeSkillCategory::Ultimate] = GetUpgradeSkillVisibility(EUpgradeSkillCategory::Ultimate, CharacterInfo);
		}
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeSculptureVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeEquipCategory::Max);
	Visibilities[(int32)EUpgradeEquipCategory::LevelUp] = ESlateVisibility::Collapsed;	// level up always collapsed
	Visibilities[(int32)EUpgradeEquipCategory::Promote] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeEquipCategory::TierUp] = ESlateVisibility::Collapsed;

	const UCMS* CMS = GetCMS();
	const TMap<FSculptureId, FSculpture>& Sculptures = GetHUDStore().GetSculptureManager().GetAllSculptures();
	for (const auto& Elem : Sculptures)
	{
		const FSculpture& Sculpture = Elem.Value;
		const FSculptureInfo& SculptureInfo = Sculpture.GetInfo();

		if (Visibilities[(int32)EUpgradeEquipCategory::Promote] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeEquipCategory::Promote] = GetUpgradeSculptureVisibility(EUpgradeEquipCategory::Promote, SculptureInfo);
		}

		if (Visibilities[(int32)EUpgradeEquipCategory::TierUp] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeEquipCategory::TierUp] = GetUpgradeSculptureVisibility(EUpgradeEquipCategory::TierUp, SculptureInfo);
		}
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeRelicVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeEquipCategory::Max);
	Visibilities[(int32)EUpgradeEquipCategory::LevelUp] = ESlateVisibility::Collapsed;	// level up always collapsed
	Visibilities[(int32)EUpgradeEquipCategory::Promote] = ESlateVisibility::Collapsed;
	Visibilities[(int32)EUpgradeEquipCategory::TierUp] = ESlateVisibility::Collapsed;

	const UCMS* CMS = GetCMS();
	const TMap<FRelicId, FRelic>& Relics = GetHUDStore().GetRelicManager().GetAllRelics();
	for (const auto& Elem : Relics)
	{
		const FRelic& Relic = Elem.Value;
		const FRelicInfo& RelicInfo = Relic.GetInfo();

		if (Visibilities[(int32)EUpgradeEquipCategory::Promote] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeEquipCategory::Promote] = GetUpgradeRelicVisibility(EUpgradeEquipCategory::Promote, RelicInfo);
		}

		if (Visibilities[(int32)EUpgradeEquipCategory::TierUp] == ESlateVisibility::Collapsed)
		{
			Visibilities[(int32)EUpgradeEquipCategory::TierUp] = GetUpgradeRelicVisibility(EUpgradeEquipCategory::TierUp, RelicInfo);
		}
	}

	return Visibilities;
}

ESlateVisibility UNewMarkManager::GetUpgradeTurnSkillVisibility(const FCharacterId& CharacterId, int32 SkillIndex) const
{
	const UCMS* CMS = GetCMS();
	if (CanTurnSkillUpgrade(CMS, CharacterId, SkillIndex))
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	return ESlateVisibility::Collapsed;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeCharacterDetailVisibilities(FCharacterId CharacterId) const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeCharacterCategory::Max);

	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!Character)
	{
		Q6JsonLogRoze(Error, "UNewMarkManager::GetCharacterDetailUpgradeVisibilities - Not found character", Q6KV("CharacterId", CharacterId.S));
		return Visibilities;
	}

	for (int32 i = 0; i < (int32)EUpgradeCharacterCategory::Max; ++i)
	{
		Visibilities[i] = GetUpgradeCharacterVisibility((EUpgradeCharacterCategory)i, Character->GetInfo());
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeSkillDetailVisibilities(FCharacterId CharacterId) const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeSkillCategory::Max);

	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!Character)
	{
		Q6JsonLogRoze(Error, "UNewMarkManager::GetUpgradeSkillDetailVisibilities - Not found character", Q6KV("CharacterId", CharacterId.S));
		return Visibilities;
	}

	for (int32 i = 0; i < (int32)EUpgradeSkillCategory::Max; ++i)
	{
		Visibilities[i] = GetUpgradeSkillVisibility((EUpgradeSkillCategory)i, Character->GetInfo());
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeSculptureDetailVisibilities(FSculptureId SculptureId) const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeEquipCategory::Max);

	const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(SculptureId);
	if (!Sculpture)
	{
		Q6JsonLogRoze(Error, "UNewMarkManager::GetUpgradeSculptureDetailVisibilities - Not found sculpture", Q6KV("SculptureId", SculptureId.S));
		return Visibilities;
	}

	for (int32 i = 0; i < (int32)EUpgradeEquipCategory::Max; ++i)
	{
		Visibilities[i] = GetUpgradeSculptureVisibility((EUpgradeEquipCategory)i, Sculpture->GetInfo());
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetUpgradeRelicDetailVisibilities(FRelicId RelicId) const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum((int32)EUpgradeEquipCategory::Max);

	const FRelic* Relic = GetHUDStore().GetRelicManager().Find(RelicId);
	if (!Relic)
	{
		Q6JsonLogRoze(Error, "UNewMarkManager::GetUpgradeRelicDetailVisibilities - Not found relic", Q6KV("RelicId", RelicId.S));
		return Visibilities;
	}

	for (int32 i = 0; i < (int32)EUpgradeEquipCategory::Max; ++i)
	{
		Visibilities[i] = GetUpgradeRelicVisibility((EUpgradeEquipCategory)i, Relic->GetInfo());
	}

	return Visibilities;
}

void UNewMarkManager::SetContentsResetTimer()
{
	FDateTime ResetTime = Q6Util::GetNextResetLocalTime();
	int64 ResetTimeSec = ResetTime.ToUnixTimestamp();
	int64 NowSec = FDateTime::Now().ToUnixTimestamp();
	int64 RemainSec = ResetTimeSec - NowSec;

	GameInstance->GetTimerManager().SetTimer(ContentsResetTimerHandle, this, &UNewMarkManager::OnConstentsResetTime, (float)RemainSec);
}

void UNewMarkManager::OnConstentsResetTime()
{
	ACTION_DISPATCH_ContentsResetTime();

	SetContentsResetTimer();
}

ESlateVisibility UNewMarkManager::GetUpgradeCharacterVisibility(EUpgradeCharacterCategory Category, const FCharacterInfo& CharacterInfo) const
{
	if (CharacterInfo.Stashed)
	{
		return ESlateVisibility::Collapsed;
	}

	if (SystemConstHelper::IsWeed(CharacterInfo))
	{
		return ESlateVisibility::Collapsed;
	}

	const UCMS* CMS = GetCMS();
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterInfo.Type);
	if (CharacterRow.XpExclusive)
	{
		return ESlateVisibility::Collapsed;
	}

	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	if (CharacterInfo.Level < SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon))
	{
		return ESlateVisibility::Collapsed;
	}

	if (Category == EUpgradeCharacterCategory::LevelUp)
	{
		return ESlateVisibility::Collapsed;	// level up always collapsed
	}
	else if (Category == EUpgradeCharacterCategory::Evolute)
	{
		if (CharacterInfo.Moon < MAX_CHARACTER_MOON
			&& CharacterInfo.Star >= SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Evolute, CharacterInfo.Grade)
			&& CanCharacterEvolute(CMS, CharacterInfo.Moon, CharacterInfo.Grade))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}

		return ESlateVisibility::Collapsed;
	}
	else if (Category == EUpgradeCharacterCategory::Unbind)
	{
		if (CharacterInfo.Star >= SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Promote, CharacterInfo.Grade)
			&& CharacterInfo.Star < SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Unbind, CharacterInfo.Grade))
		{
			const FCMSPromoteCostRow& UnbindCostRow = CMS->GetCharacterUpStarCostRowOrDummy(EUpgradeCharacterCategory::Unbind, CharacterInfo);
			if (CanCharacterMaxLevelUp(UnbindCostRow))
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}

		return ESlateVisibility::Collapsed;
	}
	else if (Category == EUpgradeCharacterCategory::Promote)
	{
		if (CharacterInfo.Star < SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Promote, CharacterInfo.Grade))
		{
			const FCMSPromoteCostRow& PromoteCostRow = CMS->GetCharacterUpStarCostRowOrDummy(EUpgradeCharacterCategory::Promote, CharacterInfo);
			if (CanCharacterMaxLevelUp(PromoteCostRow))
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}

		return ESlateVisibility::Collapsed;
	}

	Q6JsonLogRoze(Error, "UNewMarkManager::GetUpgradeCharacterVisibility - Invalid Upgrade category");
	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetUpgradeSkillVisibility(EUpgradeSkillCategory Category, const FCharacterInfo& CharacterInfo) const
{
	if (CharacterInfo.Stashed)
	{
		return ESlateVisibility::Collapsed;
	}

	const UCMS* CMS = GetCMS();
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterInfo.Type);
	if (CharacterRow.XpExclusive)
	{
		return ESlateVisibility::Collapsed;
	}

	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	if (Category == EUpgradeSkillCategory::TurnBegin)
	{
		if (CanTurnSkillUpgrade(CMS, CharacterInfo.CharacterId))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}

		return ESlateVisibility::Collapsed;
	}
	else if (Category == EUpgradeSkillCategory::Ultimate)
	{
		bool bUltimateSkillMax = CharacterInfo.UltimateSkillLevel == CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL;
		if (!bUltimateSkillMax && !SystemConstHelper::IsWeed(CharacterInfo))
		{
			int32 TargetLevel 
				= FMath::Min(CharacterInfo.UltimateSkillLevel + CharacterMgr.GetLeastUpUltimateSkillLevel(CharacterInfo.CharacterId),
					CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);
			if (CanUltimateSkillUpgrade(CMS, CharacterInfo.UltimateSkillLevel, TargetLevel))
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}

		return ESlateVisibility::Collapsed;
	}

	Q6JsonLogRoze(Error, "UNewMarkManager::GetUpgradeSkillVisibility - Invalid Upgrade category");
	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetUpgradeSculptureVisibility(EUpgradeEquipCategory Category, const FSculptureInfo& SculptureInfo) const
{
	if (SculptureInfo.Stashed)
	{
		return ESlateVisibility::Collapsed;
	}

	const UCMS* CMS = GetCMS();
	const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(SculptureInfo.Type);
	if (SculptureRow.XpExclusive)
	{
		return ESlateVisibility::Collapsed;
	}

	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	if (Category == EUpgradeEquipCategory::LevelUp)
	{
		return ESlateVisibility::Collapsed;	// level up always collapsed
	}
	else if (Category == EUpgradeEquipCategory::Promote)
	{
		if (SculptureInfo.Star < MAX_EQUIP_STAR
			&& SculptureInfo.Level >= SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star)
			&& CanSculpturePromote(CMS, SculptureInfo.Star))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}

		return ESlateVisibility::Collapsed;
	}
	else if (Category == EUpgradeEquipCategory::TierUp)
	{
		if (SculptureInfo.Tier < CombatCubeConst::Q6_MAX_TIER)
		{
			int32 TargetTier = FMath::Min(SculptureInfo.Tier + SculptureMgr.GetLeastUpTier(SculptureInfo.SculptureId), CombatCubeConst::Q6_MAX_TIER);
			if (CanTierUpgrade(SculptureInfo.Tier, TargetTier))
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}

		return ESlateVisibility::Collapsed;
	}

	Q6JsonLogRoze(Error, "UNewMarkManager::GetUpgradeSculptureVisibility - Invalid Upgrade category");
	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetUpgradeRelicVisibility(EUpgradeEquipCategory Category, const FRelicInfo& RelicInfo) const
{
	if (RelicInfo.Stashed)
	{
		return ESlateVisibility::Collapsed;
	}

	const UCMS* CMS = GetCMS();
	const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(RelicInfo.Type);
	if (RelicRow.XpExclusive)
	{
		return ESlateVisibility::Collapsed;
	}

	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	if (Category == EUpgradeEquipCategory::LevelUp)
	{
		return ESlateVisibility::Collapsed;	// level up always collapsed
	}
	else if (Category == EUpgradeEquipCategory::Promote)
	{
		if (RelicInfo.Star < MAX_EQUIP_STAR
			&& RelicInfo.Level >= SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star)
			&& CanRelicPromote(CMS, RelicInfo.Star))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}

		return ESlateVisibility::Collapsed;
	}
	else if (Category == EUpgradeEquipCategory::TierUp)
	{
		if (RelicInfo.Tier < CombatCubeConst::Q6_MAX_TIER)
		{
			int32 TargetTier = FMath::Min(RelicInfo.Tier + RelicMgr.GetLeastUpTier(RelicInfo.RelicId), CombatCubeConst::Q6_MAX_TIER);
			if (CanTierUpgrade(RelicInfo.Tier, TargetTier))
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}

		return ESlateVisibility::Collapsed;
	}

	Q6JsonLogRoze(Error, "UNewMarkManager::GetUpgradeRelicVisibility - Invalid Upgrade category");
	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetWonderMainVisibility(const FWonderInfo& WonderInfo) const
{
	if (!WonderInfo.bOpened)
	{
		return ESlateVisibility::Collapsed;
	}

	if (WonderInfo.WonderState == EWonderUpgradeState::Normal)
	{
		if (CanWonderUpgradeStart(WonderInfo.Category, WonderInfo.Level))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	if (WonderInfo.Category == EWonderCategory::PetPark)
	{
		return GetWonderPetParkVisibility();
	}
	else if (WonderInfo.Category == EWonderCategory::Powerplant)
	{
		return ESlateVisibility::Collapsed;	// power plant always collapsed
	}
	else if (WonderInfo.Category == EWonderCategory::Pyramid)
	{
		if (GetWonderPyramidVisibilities().Contains(ESlateVisibility::SelfHitTestInvisible))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}
	else if (WonderInfo.Category == EWonderCategory::Temple)
	{
		if (GetWonderTempleVisibilities().Contains(ESlateVisibility::SelfHitTestInvisible))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}
	else if (WonderInfo.Category == EWonderCategory::Vacation)
	{
		if (GetWonderVacationVisibilities().Contains(ESlateVisibility::SelfHitTestInvisible))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}
	else if (WonderInfo.Category == EWonderCategory::MigriumRefinery)
	{
		return GetWonderMigriumRefineryVisibility();
	}
	else if (WonderInfo.Category == EWonderCategory::AlchemyLab)
	{
		return GetWonderAlchemyLabVisibility();
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetWonderUpgradeVisibility(const FWonderInfo& WonderInfo) const
{
	if (WonderInfo.Category == EWonderCategory::Main)
	{
		return ESlateVisibility::Collapsed;
	}

	// check upgrade finished

	if (WonderInfo.WonderState == EWonderUpgradeState::Upgraded)
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	// check can upgrade start

	if (WonderInfo.WonderState == EWonderUpgradeState::Normal)
	{
		if (CanWonderUpgradeStart(WonderInfo.Category, WonderInfo.Level))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetWonderIncomeVisibility(const FWonderInfo& WonderInfo) const
{
	if (WonderInfo.Category == EWonderCategory::Main)
	{
		return ESlateVisibility::Collapsed;
	}

	const FCMSWonderProductRow* ProductRow = GetCMS()->GetWonderProductRow(WonderInfo.Category, WonderInfo.Level);
	if (ProductRow && (WonderInfo.IncomeAmount >= ProductRow->MaxStorageAmount))
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	return ESlateVisibility::Collapsed;
}

TArray<ESlateVisibility> UNewMarkManager::GetWonderPyramidVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum(EPortalTypeMax - 1);

	for (int32 i = 0; i < EPortalTypeMax - 1; ++i)
	{
		Visibilities[i] = GetWonderPyramidPortalVisibility((EPortalType)(i + 1));
	}

	return Visibilities;
}

ESlateVisibility UNewMarkManager::GetWonderPyramidPortalVisibility(EPortalType PortalType) const
{
	const UHUDStore& HUDStore = GetHUDStore();
	const UPyramidManager& PyramidMgr = HUDStore.GetPyramidManager();

	int32 BuildLeftDay = PyramidMgr.GetBuildTimeLeftDays(PortalType);
	if (BuildLeftDay > 0)
	{
		int32 TotalRemainBoostCount = FMath::Max(SystemConstHelper::GetMaxBoostCount(PortalType) - PyramidMgr.GetTotalBoostUsed(PortalType), 0);
		int32 DailyRemainBoostCount = FMath::Max(SystemConstHelper::GetDailyBoostCount(PortalType) - PyramidMgr.GetDailyBoostUsed(PortalType), 0);

		const FCMSWonderCostRow* CostRow = GetCMS()->GetPortalBoostCost(PortalType);
		if (CostRow && (TotalRemainBoostCount > 0) && (DailyRemainBoostCount > 0))
		{
			int32 PyramidLevel = PyramidMgr.GetLevel();
			int32 MaterialReduceCount = SystemConstHelper::GetPortalBoostMaterialReduceCount(PyramidLevel);
			int64 OwnedGold = HUDStore.GetWorldUser().GetGold();
			int32 RequireGold = FMath::Max(CostRow->Gold - SystemConstHelper::GetPortalBoostGoldReduceCost(PyramidLevel), 0);
			bool bEnoughMaterial = HUDStore.GetBagItemManager().HasEnoughBagItem(CostRow->GetBagItem(), CostRow->ItemCount);
			if ((OwnedGold >= RequireGold) && bEnoughMaterial)
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}
	}
	else
	{
		int32 ConnectedType = PyramidMgr.GetPortalConnectedType(PortalType);
		if (ConnectedType == ITEM_TYPE_INVALID)
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}

		int32 ConnectLeftDay = PyramidMgr.GetConnectTimeLeftDays(PortalType);
		if (ConnectLeftDay <= 0)
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	return ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetWonderPetParkVisibility() const
{
	const TMap<FPetId, FPetInfo>& Pets = GetHUDStore().GetPetManager().GetPets();
	for (const auto& Elem : Pets)
	{
		const FPetInfo& PetInfo = Elem.Value;
		if (GetWonderPetSkillUpgradeVisibility(PetInfo).Contains(ESlateVisibility::SelfHitTestInvisible))
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	return ESlateVisibility::Collapsed;
}

TArray<ESlateVisibility> UNewMarkManager::GetWonderPetSkillUpgradeVisibility(const FPetInfo& PetInfo) const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum(CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	TArray<int32> PetSkillLevels;
	PetSkillLevels.Add(PetInfo.Skill1Level);
	PetSkillLevels.Add(PetInfo.Skill2Level);
	PetSkillLevels.Add(PetInfo.Skill3Level);
	check(PetSkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const FPetPark& PetPark = GetHUDStore().GetPetManager().GetPetPark();
	const TArray<const FCMSSkillRow*>& SkillRows = GetCMS()->GetPetRowOrDummy(PetInfo.Type).GetSkills();
	check(SkillRows.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		if (PetSkillLevels[i] <= 0 || PetSkillLevels[i] >= PetPark.Level)
		{
			Visibilities[i] = ESlateVisibility::Collapsed;
			continue;
		}

		if (!SkillRows[i])
		{
			Visibilities[i] = ESlateVisibility::Collapsed;
			Q6JsonLogRoze(Error, "UNewMarkManager::GetWonderPetSkillUpgradeVisibility - Not found pet skill",
				Q6KV("PetType", PetInfo.Type.x), Q6KV("SkillIndex", i));
			continue;
		}

		const FCMSSkillUpgradeCostRow& CostRow = GetCMS()->GetSkillUpgradeCostRowOrDummy(*SkillRows[i], PetSkillLevels[i] + 1);
		const TArray<const FCMSBagItemRow*>& CostBagItems = CostRow.GetBagItem();
		const int32 RequireGold = CostRow.Gold;
		const int32 CurrentGold = GetHUDStore().GetWorldUser().GetGold();
		bool bEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(CostBagItems, CostRow.BagItemCount);
		if (!bEnoughMaterials || (CurrentGold < RequireGold))
		{
			Visibilities[i] = ESlateVisibility::Collapsed;
			continue;
		}

		Visibilities[i] = ESlateVisibility::SelfHitTestInvisible;
	}

	return Visibilities;
}

TArray<ESlateVisibility> UNewMarkManager::GetWonderTempleVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum(MAX_ARTIFACT_COUNT);

	const UTempleManager& TempleMgr = GetHUDStore().GetTempleManager();
	for (int32 i = 0; i < MAX_ARTIFACT_COUNT; ++i)
	{
		const FArtifact* Artifact = TempleMgr.GetArtifact(i);
		if (!Artifact)
		{
			Visibilities[i] = ESlateVisibility::Collapsed;
			Q6JsonLogRoze(Error, "UNewMarkManager::GetWonderTempleVisibilities - Not found artifact", Q6KV("ArtifactIndex", i));
			continue;
		}

		Visibilities[i] = GetWonderTempleArtifactVisibility(*Artifact, i);
	}

	return Visibilities;
}

ESlateVisibility UNewMarkManager::GetWonderTempleArtifactVisibility(const FArtifact& Artifact, int32 ArtifactIndex) const
{
	const FTempleInfo& TempleInfo = GetHUDStore().GetTempleManager().GetTempleInfo();
	if (Artifact.Level <= 0)
	{
		return ESlateVisibility::Collapsed;
	}

	// check boosting

	if (Artifact.Level == CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		int32 RemainSeconds = GetHUDStore().GetTempleManager().GetArtifactRemainSeconds(ArtifactIndex);
		if (RemainSeconds > 0)
		{
			if (Q6Util::IsDailyResetTimePassed(Artifact.BoostedTime + 86400))	// Add boost cooltime, a day
			{
				return ESlateVisibility::SelfHitTestInvisible;
			}
		}

		return ESlateVisibility::Collapsed;
	}

	// check level up

	if (Artifact.Level >= TempleInfo.Level)
	{
		return ESlateVisibility::Collapsed;
	}

	const FCMSSkillRow& ArtifactSkillRow = GetCMS()->GetArtifactSkillRowOrDummy(ArtifactIndex);
	const FCMSSkillUpgradeCostRow& CostRow = GetCMS()->GetSkillUpgradeCostRowOrDummy(ArtifactSkillRow, Artifact.Level + 1);
	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	bool bEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(CostRow.GetBagItem(), CostRow.BagItemCount);
	if (!bEnoughMaterials || (OwnedGold < CostRow.Gold))
	{
		return ESlateVisibility::Collapsed;
	}

	return ESlateVisibility::SelfHitTestInvisible;
}

TArray<ESlateVisibility> UNewMarkManager::GetWonderVacationVisibilities() const
{
	TArray<ESlateVisibility> Visibilities;
	Visibilities.SetNum(MAX_ARTIFACT_COUNT);

	const UVacationManager& VacationMgr = GetHUDStore().GetVacationManager();
	for (int32 i = 0; i < MAX_ARTIFACT_COUNT; ++i)
	{
		const FVacationSpot* VacationSpot = VacationMgr.GetVacationSpot(i);
		if (VacationSpot)
		{
			Visibilities[i] = GetWonderVacationVisibility(*VacationSpot);
			continue;
		}

		Visibilities[i] = ESlateVisibility::Collapsed;
	}

	return Visibilities;
}

ESlateVisibility UNewMarkManager::GetWonderMigriumRefineryVisibility() const
{
	const FSmelterInfo& Info = GetHUDStore().GetSmelterManager().GetSmelterInfo();
	ESlateVisibility ProductVisibility = GetWonderMigriumProductVisibility(Info);
	if (ProductVisibility == ESlateVisibility::Collapsed)
	{
		return GetWonderMigriumStockVisibility(Info);
	}

	return ProductVisibility;
}

ESlateVisibility UNewMarkManager::GetWonderMigriumStockVisibility(const FSmelterInfo& Info) const
{
	if (Info.Product > 0)
	{
		return ESlateVisibility::Collapsed;
	}

	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(Info.Level);
	if (!SmelterRow)
	{
		Q6JsonLogRoze(Warning, "UNewMarkManager::GetWonderMigriumStockVisibility - Not found smelter row",
			Q6KV("SmelterLevel", Info.Level));
		return ESlateVisibility::Collapsed;
	}

	if ((Info.Stock + Info.Product) >= SmelterRow->ProductStock)
	{
		return ESlateVisibility::Collapsed;
	}

	bool bCanStock = GetHUDStore().CheckMigriumStockCost();
	return bCanStock ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetWonderMigriumProductVisibility(const FSmelterInfo& Info) const
{
	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(Info.Level);
	if (!SmelterRow)
	{
		Q6JsonLogRoze(Warning, "UNewMarkManager::GetWonderMigriumProductVisibility - Not found smelter row",
			Q6KV("SmelterLevel", Info.Level));
		return ESlateVisibility::Collapsed;
	}

	bool bShowNewMark = (Info.Product == SmelterRow->ProductStock);
	return bShowNewMark ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetWonderAlchemyLabVisibility() const
{
	const FAlchemylabInfo& Info = GetHUDStore().GetAlchemylabManager().GetAlchemylabInfo();
	ESlateVisibility ProductVisibility = GetWonderAlchemyLabProductVisibility(Info, false);
	return ProductVisibility;
}

ESlateVisibility UNewMarkManager::GetWonderAlchemyLabProductVisibility(const FAlchemylabInfo& Info, bool bExceptMaxCount) const
{
	bool bShowNewMark = Info.Stock <= 0 && Info.Product > 0;
	if (bExceptMaxCount)
	{
		bShowNewMark &= (Info.Product < Info.Level);
	}

	return bShowNewMark ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetWonderVacationVisibility(const FVacationSpot& VacationSpot) const
{
	if (VacationSpot.CharacterType == CharacterTypeInvalid)
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	int32 RemainDays = GetHUDStore().GetVacationManager().GetRemainDays(VacationSpot.VacationSpotType);
	if (RemainDays == 0)
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	return ESlateVisibility::Collapsed;
}

bool UNewMarkManager::CanWonderUpgradeStart(EWonderCategory WonderCategory, int32 Level) const
{
	if (Level >= WonderMaxLevel)
	{
		return false;
	}

	const FCMSWonderRow* WonderRow = GetCMS()->GetWonderRow(WonderCategory, Level + 1);
	if (WonderRow)
	{
		const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

		int32 UserLevel = WorldUser.GetLevel();
		int64 OwnedGold = WorldUser.GetGold();

		bool bEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(FBagItemType(SystemConst::Q6_WONDER_UPGRADE_MATERIAL), WonderRow->UpgradeMaterialCount);
		bool bEnoughGold = OwnedGold >= WonderRow->UpgradeGoldCost;

		if (UserLevel >= WonderRow->UserLevel && bEnoughMaterials && bEnoughGold)
		{
			return true;
		}
	}

	return false;
}

ESlateVisibility UNewMarkManager::GetWeeklyMissionVisibility(int32 CurValue, int32 MaxValue, int32 RewardUtc) const
{
	if (RewardUtc > 0)
	{
		return ESlateVisibility::Collapsed;
	}

	if (CurValue < MaxValue)
	{
		return ESlateVisibility::Collapsed;
	}

	return ESlateVisibility::SelfHitTestInvisible;
}

ESlateVisibility UNewMarkManager::GetWeeklyMissionBonusVisibility(int32 MissionBonusIndex) const
{
	const UWeeklyMissionManager& MissionMgr = GetHUDStore().GetWeeklyMissionManager();
	const FMissionInfo& MissionInfo = MissionMgr.GetMissioninfo();
	if (MissionInfo.BUtc[MissionBonusIndex] > 0)
	{
		return ESlateVisibility::Collapsed;
	}

	for (int32 i = 0; i < MAX_MISSION_BINGO_BOARD_SIZE; ++i)
	{
		int32 MissionIndex = INDEX_NONE;
		if (MissionBonusIndex < MAX_MISSION_BINGO_BOARD_SIZE)
		{
			// check horizontal bingo

			MissionIndex = (MissionBonusIndex * MAX_MISSION_BINGO_BOARD_SIZE) + i;
		}
		else if (MissionBonusIndex == MAX_MISSION_BINGO_BOARD_SIZE)
		{
			// check back-slash bingo

			MissionIndex = (MissionBonusIndex * i) + i;
		}
		else if (MissionBonusIndex < MAX_WEEKLY_BINGO - 1)
		{
			// check vertical bingo

			MissionIndex = (i * MAX_MISSION_BINGO_BOARD_SIZE) + (6 - MissionBonusIndex);
		}
		else
		{
			// check slash bingo

			MissionIndex = 2 * (i + 1);
		}

		// check mission complete

		const int32 RewardUtc = MissionInfo.RUtc[MissionIndex];
		if (RewardUtc <= 0)
		{
			return ESlateVisibility::Collapsed;
		}
	}

	return ESlateVisibility::SelfHitTestInvisible;
}

ESlateVisibility UNewMarkManager::GetWeeklyMissionConfirmVisibility(const FMissionInfo& MissionInfo) const
{
//Temporary (QSIX-8331)
// 	if (GetHUDStore().GetWeeklyMissionManager().IsExpiredWeeklyMission())
// 	{
// 		return ESlateVisibility::SelfHitTestInvisible;
// 	}
//
// 	if (!MissionInfo.Confirmed)
// 	{
// 		return ESlateVisibility::SelfHitTestInvisible;
// 	}

	return ESlateVisibility::Collapsed;
}

ENewMarkType UNewMarkManager::GetFriendType() const
{
	ENewMarkType InNewMarkType = GetFriendReceivingType();
	if (InNewMarkType != ENewMarkType::None)
	{
		return InNewMarkType;
	}

	return GetFriendBookType();
}

ENewMarkType UNewMarkManager::GetFriendReceivingType() const
{
	TArray<const FFriendInfoEx*> Friends = GetHUDStore().GetFriendManager().GetReceivingFriends();
	for (const FFriendInfoEx* Friend : Friends)
	{
		check(Friend);

		if (GetFriendReceivingVisible(*Friend))
		{
			return ENewMarkType::Dot;
		}
	}

	return ENewMarkType::None;
}

ENewMarkType UNewMarkManager::GetFriendBookType() const
{
	if (GetHUDStore().GetFriendBook().HasNewFeeds())
	{
		return ENewMarkType::Dot;
	}

	return ENewMarkType::None;
}

bool UNewMarkManager::GetFriendReceivingVisible(const FFriendInfoEx& Friend) const
{
	if (!GetHUDStore().GetFriendManager().IsConfirmedReceiving(Friend.FriendId))
	{
		return true;
	}

	return false;
}

ESlateVisibility UNewMarkManager::GetCharacterMissionsVisibility(const FCharacterType CharacterType) const
{
	if (!GetHUDStore().GetContentFeatureOpenManager().IsOpenContentFeature(EFeatureOpenType::CharacterMisson))
	{
		return ESlateVisibility::Collapsed;
	}

	const FCharMissionInfo* CharMissionInfo = GetHUDStore().GetCharMissionManager().GetCharMissionByCharacterType(CharacterType);
	if (!CharMissionInfo)
	{
		return ESlateVisibility::Collapsed;
	}

	return GetCharacterMissionVisibility(*CharMissionInfo);
}

ESlateVisibility UNewMarkManager::GetCharacterMissionVisibility(const FCharMissionInfo& MissionInfo) const
{
	const FCMSCharMissionSetRow* CharMissionSetRow = GetCMS()->GetCharMissionSetRowByCharType(MissionInfo.CharType);
	if (!CharMissionSetRow)
	{
		Q6JsonLogRoze(Error, "UNewMarkManager::GetCharacterMissionVisibility - Invalid character mission",
			Q6KV("CharacterType", MissionInfo.CharType));
		return ESlateVisibility::Collapsed;
	}

	const TArray<const FCMSCharMissionRow*>& CharMissionRows = CharMissionSetRow->GetMission();
	const TArray<int32>& MissionIng = MissionInfo.MIng;
	const TArray<int32>& RewardUtc = MissionInfo.RUtc;

	check(CharMissionRows.Num() == MAX_CHAR_MISSION);
	check(MissionIng.Num() == MAX_CHAR_MISSION);
	check(RewardUtc.Num() == MAX_CHAR_MISSION_REWARD);

	const UCharMissionManager& CharMissionMgr = GetHUDStore().GetCharMissionManager();
	for (int32 i = 0; i < MAX_CHAR_MISSION; ++i)
	{
		const int32 MaxValue = CharMissionMgr.GetMaxValue(CharMissionRows[i]->CmsType());

		if (MissionIng[i] >= MaxValue && RewardUtc[i] == 0)
		{
			return ESlateVisibility::SelfHitTestInvisible;
		}
	}

	return ESlateVisibility::Collapsed;
}

ENewMarkType UNewMarkManager::GetCodexType() const
{
	for (int32 i = 0; i < (int32)ECodexCategory::None; ++i)
	{
		if (GetCodexCategoryVisible((ECodexCategory)i))
		{
			return ENewMarkType::Dot;
		}
	}

	return ENewMarkType::None;
}

bool UNewMarkManager::GetCodexCategoryVisible(ECodexCategory Category) const
{
	const UCodexManager& CodexMgr = GetHUDStore().GetCodexManager();

	if (Category == ECodexCategory::CodexCharacter)
	{
		const TMap<FCharacterType, FCodexCharInfo>& Chars = CodexMgr.GetCodexChars();
		for (const auto& Elem : Chars)
		{
			const FCodexCharInfo& Info = Elem.Value;
			if (Info.Newly)
			{
				return true;
			}
		}
	}
	
	if (Category == ECodexCategory::CodexSculpture)
	{
		const TMap<FSculptureType, FCodexSculptureInfo>& Sculptures = CodexMgr.GetCodexSculptures();
		for (const auto& Elem : Sculptures)
		{
			const FCodexSculptureInfo& Info = Elem.Value;
			if (Info.Newly)
			{
				return true;
			}
		}
	}

	if (Category == ECodexCategory::CodexRelic)
	{
		const TMap<FRelicType, FCodexRelicInfo>& Relics = CodexMgr.GetCodexRelics();
		for (const auto& Elem : Relics)
		{
			const FCodexRelicInfo& Info = Elem.Value;
			if (Info.Newly)
			{
				return true;
			}
		}
	}

	return false;
}

ENewMarkType UNewMarkManager::GetCollectionType() const
{
	for (int32 i = 0; i < (int32)EInventoryType::Max; ++i)
	{
		ENewMarkType NewMarkType = GetCollectionCategoryType((EInventoryType)i);
		if (NewMarkType != ENewMarkType::None)
		{
			return NewMarkType;
		}
	}

	return ENewMarkType::None;
}

ENewMarkType UNewMarkManager::GetCollectionCategoryType(EInventoryType InventoryType) const
{
	if (InventoryType == EInventoryType::Character)
	{
		const TMap<FCharacterId, FCharacter>& Chars = GetHUDStore().GetCharacterManager().GetAllCharacters();
		for (const auto& Elem : Chars)
		{
			const FCharacterInfo& Info = Elem.Value.GetInfo();
			if (Info.Stashed)
			{
				continue;
			}

			if (Info.Newly)
			{
				return ENewMarkType::New;
			}

			ESlateVisibility MissionNewMarkVisibility = GetCharacterMissionsVisibility(Info.Type);
			if (MissionNewMarkVisibility == ESlateVisibility::SelfHitTestInvisible)
			{
				return ENewMarkType::Dot;
			}
		}
	}

	if (InventoryType == EInventoryType::Sculpture)
	{
		const TMap<FSculptureId, FSculpture>& Sculptures = GetHUDStore().GetSculptureManager().GetAllSculptures();
		for (const auto& Elem : Sculptures)
		{
			const FSculptureInfo& Info = Elem.Value.GetInfo();
			if (Info.Newly)
			{
				return ENewMarkType::New;
			}
		}
	}

	if (InventoryType == EInventoryType::Relic)
	{
		const TMap<FRelicId, FRelic>& Relics = GetHUDStore().GetRelicManager().GetAllRelics();
		for (const auto& Elem : Relics)
		{
			const FRelicInfo& Info = Elem.Value.GetInfo();
			if (Info.Newly)	// If selected category, newmark off
			{
				return ENewMarkType::New;
			}
		}
	}

	return ENewMarkType::None;
}

ENewMarkType UNewMarkManager::GetShopType() const
{
	// Monthly reset

	bool bEventChanged = GetHUDStore().GetEventManager().IsEventScheduleChanged();
	int32 MonthOfDay = FDateTime::UtcNow().GetDay();
	if (bEventChanged && MonthOfDay == 1)
	{
		return ENewMarkType::Dot;
	}

	// Lumicube shop

	if (GetLumicubeShopVisible())
	{
		return ENewMarkType::Dot;
	}

	// Disk shop

	for (int32 i = 0; i < ELootCategoryMax; ++i)
	{
		if (GetShopCategoryVisible(EShopCategory::DiskExchange, (ELootCategory)i))
		{
			return ENewMarkType::Dot;
		}
	}

	return ENewMarkType::None;
}

bool UNewMarkManager::GetLumicubeShopVisible() const
{
	return GetShopCategoryVisible(EShopCategory::Lumicube, ELootCategory::Lumicube);
}

bool UNewMarkManager::GetDiskShopVisible() const
{
	if (GetShopCategoryVisible(EShopCategory::DiskExchange, ELootCategory::CharacterDisk))
	{
		return true;
	}

	if (GetShopCategoryVisible(EShopCategory::DiskExchange, ELootCategory::RelicDisk))
	{
		return true;
	}

	if (GetShopCategoryVisible(EShopCategory::DiskExchange, ELootCategory::SculptureDisk))
	{
		return true;
	}

	return false;
}

bool UNewMarkManager::GetShopCategoryVisible(EShopCategory ShopCategory, ELootCategory CostCategory) const
{
	const TMap<int32, FEventScheduleInfo>& EventSchedules = GetHUDStore().GetEventManager().GetEventSchedules();
	const TArray<const FCMSShopRow*>& ShopRowArray = GetCMS()->GetShopRowsByShopCategory(ShopCategory);

	const UShopManager& ShopMgr = GetHUDStore().GetShopManager();
	for (const FCMSShopRow* ShopRow : ShopRowArray)
	{
		if (ShopRow->CostItemCategory != CostCategory)
		{
			continue;
		}

		if (!GetShopItemVisible(*ShopRow, EventSchedules.Find(ShopRow->EventScheduleId), ShopMgr.GetShopClearNewInfo(ShopRow->ShopCategory, ShopRow->CostItemCategory)))
		{
			continue;
		}

		return true;
	}

	return false;
}

bool UNewMarkManager::GetShopItemVisible(const FCMSShopRow& ShopRow, const FEventScheduleInfo* ScheduleInfo, const FShopClearNewInfo* ClearNewInfo) const
{
//Temporary (QSIX-8331)
// 	if (!ScheduleInfo)
// 	{
// 		// Invalid event period
//
// 		return false;
// 	}
//
// 	if (!ShopRow.IsMonthlyReset)
// 	{
// 		// Clear new once
//
// 		return !ClearNewInfo;
// 	}
//
// 	if (!ClearNewInfo)
// 	{
// 		// Clear new first
//
// 		return true;
// 	}
//
// 	FDateTime ClearNewTime = FDateTime::FromUnixTimestamp(ClearNewInfo->ClearNewTime);
// 	FDateTime UtcNow = FDateTime::UtcNow();
//
// 	if (ClearNewTime.GetYear() != UtcNow.GetYear())
// 	{
// 		return true;
// 	}
//
// 	if (ClearNewTime.GetMonth() != UtcNow.GetMonth())
// 	{
// 		return true;
// 	}
//
	return false;
}

ESlateVisibility UNewMarkManager::GetNewMailVisibility() const
{
	return GetHUDStore().GetMailManager().IsNewMail() ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed;
}

ESlateVisibility UNewMarkManager::GetNewMailVisibilityByMailType(const EMailType& MailType) const
{
	return GetHUDStore().GetMailManager().IsNewMailByType(MailType) ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed;
}


/////////////////////////////////////////////////////////////////////////////
// UNewMarkManager HUDStore Action

void UNewMarkManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UNewMarkManager, AuthEnterLobbyFinalResp);
	REGISTER_ACTION_HANDLER(UNewMarkManager, ContentsResetTime);
	REGISTER_ACTION_HANDLER(UNewMarkManager, NewMarkNotifyMail);
}

IMPLEMENT_ACTION_HANDLER(UNewMarkManager, AuthEnterLobbyFinalResp)
{
	GameInstance->GetTimerManager().ClearTimer(ContentsResetTimerHandle);

	SetContentsResetTimer();

	return false;
}

IMPLEMENT_ACTION_HANDLER(UNewMarkManager, ContentsResetTime)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(UNewMarkManager, NewMarkNotifyMail)
{
	return true;
}