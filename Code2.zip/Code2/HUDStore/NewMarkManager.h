#pragma once

#include "CMS_gen.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "LobbyObj_gen.h"
#include "Q6UIDefine.h"

#include "NewMarkManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FFriendInfoEx;

class FRaidFinal;
class FNewMarkNotifyHandler;

enum class EMailType : uint8;

///////////////////////////////////////////////////////////////////////////////////////////
// UNewMarkManager

UCLASS()
class Q6_API UNewMarkManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UNewMarkManager();
	~UNewMarkManager();

	void InitNotifyHandler();

	// Main

	ENewMarkType GetMainSagaType() const;
	ESlateVisibility GetMainTrainingCenterVisibility() const;
	ESlateVisibility GetMainSpecialVisibility() const;
	ESlateVisibility GetMainRaidVisibility() const;

	ENewMarkType GetMainWonderType() const;
	ENewMarkType GetMainWeeklyMissionType() const;
	ENewMarkType GetMainSummonType() const;

	// NavigationBar

	ENewMarkType GetNaviBarType(EHUDWidgetType HUDWidgetType) const;

	// Saga

	ENewMarkType GetSagaEpisodeType(int32 Episode) const;

	// Raid

	ESlateVisibility GetRaidVisibility(ERaidStageState RaidState) const;

	// Special

	ESlateVisibility GetSpecialCategoryVisibility(ESpecialCategory SpecialCategory) const;
	ESlateVisibility GetSpecialWonderCategoryVisibility(EWonderCategory WonderCategory) const;
	ESlateVisibility GetSpecialCharacterVisibility(FCharacterType CharacterType) const;
	ESlateVisibility GetSpecialBossCategoryVisibility() const;

	// DailyDungeon
	bool GetDailyDungeonVisible(EDayOfWeekType DayOfWeek, EDailyDungeonCategory DailyCategory, int32 Stage) const;

	// Upgrade

	TArray<ESlateVisibility> GetUpgradeVisibilities() const;
	TArray<ESlateVisibility> GetUpgradeCharacterVisibilities() const;
	TArray<ESlateVisibility> GetUpgradeSkillVisibilities() const;
	TArray<ESlateVisibility> GetUpgradeSculptureVisibilities() const;
	TArray<ESlateVisibility> GetUpgradeRelicVisibilities() const;
	ESlateVisibility GetUpgradeTurnSkillVisibility(const FCharacterId& CharacterId, int32 SkillIndex) const;

	// Detail

	TArray<ESlateVisibility> GetUpgradeCharacterDetailVisibilities(FCharacterId CharacterId) const;
	TArray<ESlateVisibility> GetUpgradeSkillDetailVisibilities(FCharacterId CharacterId) const;
	TArray<ESlateVisibility> GetUpgradeSculptureDetailVisibilities(FSculptureId SculptureId) const;
	TArray<ESlateVisibility> GetUpgradeRelicDetailVisibilities(FRelicId RelicId) const;

	// Wonder

	ESlateVisibility GetWonderMainVisibility(const FWonderInfo& WonderInfo) const;
	ESlateVisibility GetWonderUpgradeVisibility(const FWonderInfo& WonderInfo) const;
	ESlateVisibility GetWonderIncomeVisibility(const FWonderInfo& WonderInfo) const;
	TArray<ESlateVisibility> GetWonderPyramidVisibilities() const;
	ESlateVisibility GetWonderPyramidPortalVisibility(EPortalType PortalType) const;
	ESlateVisibility GetWonderPetParkVisibility() const;
	TArray<ESlateVisibility> GetWonderPetSkillUpgradeVisibility(const FPetInfo& PetInfo) const;
	TArray<ESlateVisibility> GetWonderTempleVisibilities() const;
	ESlateVisibility GetWonderTempleArtifactVisibility(const FArtifact& Artifact, int32 ArtifactIndex) const;
	TArray<ESlateVisibility> GetWonderVacationVisibilities() const;
	ESlateVisibility GetWonderVacationVisibility(const FVacationSpot& VacationSpot) const;
	ESlateVisibility GetWonderMigriumRefineryVisibility() const;
	ESlateVisibility GetWonderMigriumStockVisibility(const FSmelterInfo& Info) const;
	ESlateVisibility GetWonderMigriumProductVisibility(const FSmelterInfo& Info) const;
	ESlateVisibility GetWonderAlchemyLabVisibility() const;
	ESlateVisibility GetWonderAlchemyLabProductVisibility(const FAlchemylabInfo& Info, bool bExceptMaxCount) const;
	bool CanWonderUpgradeStart(EWonderCategory WonderCategory, int32 Level) const;

	// WeeklyMission

	ESlateVisibility GetWeeklyMissionVisibility(int32 CurValue, int32 MaxValue, int32 RewardUtc) const;
	ESlateVisibility GetWeeklyMissionBonusVisibility(int32 BingoUtc) const;
	ESlateVisibility GetWeeklyMissionConfirmVisibility(const FMissionInfo& MissionInfo) const;

	// Friend

	ENewMarkType GetFriendType() const;
	ENewMarkType GetFriendReceivingType() const;
	ENewMarkType GetFriendBookType() const;
	bool GetFriendReceivingVisible(const FFriendInfoEx& Friend) const;

	// Character Mission

	ESlateVisibility GetCharacterMissionsVisibility(const FCharacterType CharacterType) const;
	ESlateVisibility GetCharacterMissionVisibility(const FCharMissionInfo& MissionInfo) const;

	// Codex

	ENewMarkType GetCodexType() const;
	bool GetCodexCategoryVisible(ECodexCategory Category) const;

	// Collection

	ENewMarkType GetCollectionType() const;
	ENewMarkType GetCollectionCategoryType(EInventoryType InventoryType) const;

	// Shop

	ENewMarkType GetShopType() const;
	bool GetLumicubeShopVisible() const;
	bool GetDiskShopVisible() const;
	bool GetShopCategoryVisible(EShopCategory ShopCategory, ELootCategory CostCategory) const;
	bool GetShopItemVisible(const FCMSShopRow& ShopRow, const FEventScheduleInfo* ScheduleInfo, const FShopClearNewInfo* ClearNewInfo) const;

	// Mail
	
	ESlateVisibility GetNewMailVisibility() const;
	ESlateVisibility GetNewMailVisibilityByMailType(const EMailType& MailType) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	void OnConstentsResetTime();

	void SetContentsResetTimer();

	ESlateVisibility GetUpgradeCharacterVisibility(EUpgradeCharacterCategory Category, const FCharacterInfo& CharacterInfo) const;
	ESlateVisibility GetUpgradeSkillVisibility(EUpgradeSkillCategory Category, const FCharacterInfo& CharacterInfo) const;
	ESlateVisibility GetUpgradeSculptureVisibility(EUpgradeEquipCategory Category, const FSculptureInfo& SculptureInfo) const;
	ESlateVisibility GetUpgradeRelicVisibility(EUpgradeEquipCategory Category, const FRelicInfo& RelicInfo) const;

	// On Actions

	DECLARE_ACTION_HANDLER(AuthEnterLobbyFinalResp);
	DECLARE_ACTION_HANDLER(ContentsResetTime);
	DECLARE_ACTION_HANDLER(NewMarkNotifyMail);

	FTimerHandle ContentsResetTimerHandle;

	FNewMarkNotifyHandler* NewMarkNotifyHandlerInstance;
};
