#pragma once

#include "Q6ClientNetwork.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6UIDefine.h"
#include "LobbyTemplateManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FLobbyTemplateId;
struct FLobbyTemplateInfo;

struct FLobbyTemplate
{
	FLobbyTemplate(const FLobbyTemplateInfo& InInfo)
	{
		Info = InInfo;
	}

	const FLobbyTemplateInfo& GetInfo() const { return Info; }

private:
	FLobbyTemplateInfo Info;
};

///////////////////////////////////////////////////////////////////////////////////////////
// ULobbyTemplateManager

UCLASS()
class Q6_API ULobbyTemplateManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	ULobbyTemplateManager();

	const TMap<FLobbyTemplateId, FLobbyTemplate>& GetLobbyTemplates() const { return LobbyTemplates; }

	FLobbyTemplateType GetDefaultLobbyTemplateType() const { return DefaultTemplateInfo.Type; }
	const FLobbyTemplateInfo& GetLobbyTemplateInfo(FLobbyTemplateId InLobbyTemplateId) const;
	bool HasLobbyTemplate(FLobbyTemplateType InLobbyTemplateType) const;

	void Dump() const;

	void ReqList(int32 PageNo = 0) const;
	void ReqClearNew(const FLobbyTemplateId& Id) const;

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CLobbyTemplateListResp& Res);
	void OnClearNewResp(const FResError* Error, const FL2CLobbyTemplateClearNewResp& Msg);

	// Setter
	bool Add(const FLobbyTemplateInfo& Info);

	// Subroutines of OnAction
	DECLARE_ACTION_HANDLER(ClearLobbyTemplate);
	DECLARE_ACTION_HANDLER(LobbyTemplateListResp);
	DECLARE_ACTION_HANDLER(LobbyTemplateClearNewResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(SummonPickupResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);
	DECLARE_ACTION_HANDLER(DevLobbyTemplateNewResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);

private:
	TMap<FLobbyTemplateId, FLobbyTemplate> LobbyTemplates;

	FLobbyTemplateInfo DefaultTemplateInfo;
};

void DumpLobbyTemplate(const FLobbyTemplateInfo& Info);