#include "DailyDungeonManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "HSAction.h"
#include "LobbyHUD.h"
#include "CombatWidgets.h"
#include "CCEvent.h"
#include "Q6Log.h"

#if !UE_BUILD_SHIPPING
static FDailyDungeonRecord DummyHistory;
#endif

///////////////////////////////////////////////////////////////////////////////////////////
// UDailyDungeonManager

UDailyDungeonManager::UDailyDungeonManager()
{
	InitStore(EHSType::DailyDungeon);
}

void UDailyDungeonManager::ReqDailyList(bool bEnterLobby) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LDailyList Out;

	ClientNetwork.WsRequest(TEXT("daily/list"), Out,
		TQ6ResponseDelegate<FL2CDailyListResp>::CreateUObject(
			const_cast<UDailyDungeonManager*>(this), &UDailyDungeonManager::OnDailyListResp, bEnterLobby));
}

void UDailyDungeonManager::OnDailyListResp(const FResError* Error, const FL2CDailyListResp& Res, bool bEnterLobby)
{
	if (Error)
	{
		OnError(Error);
	}
	else
	{
		ACTION_DISPATCH_DailyListResp(Res);
	}

	if (bEnterLobby)
	{
		GameInstance->ReqNextContent();
	}
}

void UDailyDungeonManager::ReqStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LDailyStageBegin Out;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("daily/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CDailyStageBeginResp>::CreateUObject(
			const_cast<UDailyDungeonManager*>(this), &UDailyDungeonManager::OnStageBeginResp));
}

#if !UE_BUILD_SHIPPING
void UDailyDungeonManager::ReqDevStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LDevDailyStageBegin Out;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("dev/dailyStageBegin"), Out,
		TQ6ResponseDelegate<FL2CDailyStageBeginResp>::CreateUObject(
			const_cast<UDailyDungeonManager*>(this), &UDailyDungeonManager::OnStageBeginResp));
}
#endif

const FDailyDungeonRecord& UDailyDungeonManager::GetHistory(EDayOfWeekType DayOfWeek) const
{
#if !UE_BUILD_SHIPPING
	if (GameInstance->IsDevMode() && DayOfWeek != GetDayOfWeekType())
	{
		return DummyHistory;
	}

#endif
	return ClearHistory;
}

EDayOfWeekType UDailyDungeonManager::GetDayOfWeekType() const
{
#if !UE_BUILD_SHIPPING
	return GetTodayOfWeek(ClockModValue);
#else
	return GetTodayOfWeek();
#endif
}

void UDailyDungeonManager::OnStageBeginResp(const FResError* Error, const FL2CDailyStageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnDailyStageBegin(Res);
}

void UDailyDungeonManager::ReqStageEnd(const UCCEndGameEvent* Event
	, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	FC2LDailyStageEnd Out;
	Out.SagaType = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.Result = static_cast<int32>(Event->Result);
	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.HpRatio = Event->BossHpRatio;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;
	Out.Mission = CombatMissionInfo.WeeklyCombatMissionInfo;
	Out.CharMission = CombatMissionInfo.CharCombatMissionInfo;

	ClientNetwork.WsRequest("daily/stageEnd", Out,
		TQ6ResponseDelegate<FL2CDailyStageEndResp>::CreateUObject(
			const_cast<UDailyDungeonManager*>(this), &UDailyDungeonManager::OnStageEndResp));
}

void UDailyDungeonManager::OnStageEndResp(const FResError* Error, const FL2CDailyStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnDailyStageEnd(Res);
}

/////////////////////////////////////////////////////////////////////////////
// Setter

void UDailyDungeonManager::UpdateDailyDungeonClear(const FDailyDungeonRecord& NewClearDungeons)
{
	ClearHistory = NewClearDungeons;
	Q6JsonLogPaul(Verbose, "DailyDungeon", Q6KV("Promote", ClearHistory.Promote));
	Q6JsonLogPaul(Verbose, "DailyDungeon", Q6KV("Xp", ClearHistory.Xp));
	Q6JsonLogPaul(Verbose, "DailyDungeon", Q6KV("Gold", ClearHistory.Gold));
}

/////////////////////////////////////////////////////////////////////////////
// UDailyDungeonManager HUDStore Action

void UDailyDungeonManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UDailyDungeonManager, DailyListResp);
	REGISTER_ACTION_HANDLER(UDailyDungeonManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UDailyDungeonManager, DevClockModResp);
}

IMPLEMENT_ACTION_HANDLER(UDailyDungeonManager, DailyListResp)
{
	const auto& Action = ACTION_PARSE_DailyListResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateDailyDungeonClear(Action->GetVal().ClearDungeons);
#if !UE_BUILD_SHIPPING
	ClockModValue = Resp.DailyClock;
#endif

	return true;
}

IMPLEMENT_ACTION_HANDLER(UDailyDungeonManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	const auto& Resp = Action->GetVal();
	UpdateDailyDungeonClear(Resp.ClearDungeons);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UDailyDungeonManager, DevClockModResp)
{
	auto Action = ACTION_PARSE_DevClockModResp(InAction);
	const auto& Resp = Action->GetVal();

#if !UE_BUILD_SHIPPING
	ClockModValue = Resp.Value;
#endif

	return true;
}
