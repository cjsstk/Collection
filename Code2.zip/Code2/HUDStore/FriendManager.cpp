#include "FriendManager.h"
#include "ErrCode_gen.h"
#include "HSAction.h"
#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6GameInstance.h"
#include "SortingWidgets.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Static Functions


///////////////////////////////////////////////////////////////////////////////////////////
// FFriendNotifyHandler

class FFriendNotifyHandler
{
public:
	FFriendNotifyHandler()	: Inited(false)
	{
	}

	void Init(UQ6GameInstance* InGameInstance)
	{
		if (Inited) {
			return;
		}

		Inited = true;

		FQ6ClientNetwork& ClientNetwork = InGameInstance->GetClientNetwork();
		ClientNetwork.RegisterPush(TEXT("friendNotifyAccept"), TQ6PushDelegate<FL2CFriendNotifyAccept>::CreateRaw(
			this, &FFriendNotifyHandler::OnFriendNotifyAccept));

		ClientNetwork.RegisterPush(TEXT("friendNotifyRemove"), TQ6PushDelegate<FL2CFriendNotifyRemove>::CreateRaw(
			this, &FFriendNotifyHandler::OnFriendNotifyRemove));

		ClientNetwork.RegisterPush(TEXT("friendNotifyJokerSetChange"), TQ6PushDelegate<FL2CFriendNotifyJokerSetChange>::CreateRaw(
			this, &FFriendNotifyHandler::OnFriendNotifyJokerSetChange));

		ClientNetwork.RegisterPush(TEXT("friendNotifyRequest"), TQ6PushDelegate<FL2CFriendNotifyRequest>::CreateRaw(
			this, &FFriendNotifyHandler::OnFriendNotifyRequest));

		ClientNetwork.RegisterPush(TEXT("friendNotifyAvatarChange"), TQ6PushDelegate<FL2CFriendNotifyAvatarChange>::CreateRaw(
			this, &FFriendNotifyHandler::OnFriendNotifyAvatarChange));

		ClientNetwork.RegisterPush(TEXT("friendNotifyNicknameChanged"), TQ6PushDelegate<FL2CFriendNotifyNicknameChanged>::CreateRaw(
			this, &FFriendNotifyHandler::OnFriendNotifyNicknameChanged));
	}

	void OnFriendNotifyAccept(const FL2CFriendNotifyAccept& Notify)
	{
		ACTION_DISPATCH_FriendNotifyAccept(Notify);
	}

	void OnFriendNotifyRemove(const FL2CFriendNotifyRemove& Notify)
	{
		ACTION_DISPATCH_FriendNotifyRemove(Notify);
	}

	void OnFriendNotifyJokerSetChange(const FL2CFriendNotifyJokerSetChange& Notify)
	{
		ACTION_DISPATCH_FriendNotifyJokerSetChange(Notify);
	}

	void OnFriendNotifyRequest(const FL2CFriendNotifyRequest& Notify)
	{
		ACTION_DISPATCH_FriendNotifyRequest(Notify);
	}

	void OnFriendNotifyAvatarChange(const FL2CFriendNotifyAvatarChange& Notify)
	{
		ACTION_DISPATCH_FriendNotifyAvatarChange(Notify);
	}

	void OnFriendNotifyNicknameChanged(const FL2CFriendNotifyNicknameChanged& Notify)
	{
		ACTION_DISPATCH_FriendNotifyNicknameChanged(Notify);
	}

private:
	bool Inited;
};

///////////////////////////////////////////////////////////////////////////////////////////
// UFriendManager

UFriendManager::UFriendManager()
	: JokerSlot(EJokerSlotType::All)
	, bRecommendedFriend(false)
	, FriendNotifyHandlerInstance(new FFriendNotifyHandler)
#if !UE_BUILD_SHIPPING
	, DevCooltime(-1)
#endif
{
	InitStore(EHSType::Friend);
}

UFriendManager::~UFriendManager()
{
	if (FriendNotifyHandlerInstance != nullptr)
	{
		delete FriendNotifyHandlerInstance;
	}
}

void UFriendManager::InitNotifyHandler()
{
	if (FriendNotifyHandlerInstance != nullptr)
	{
		FriendNotifyHandlerInstance->Init(GameInstance);
	}
}

void UFriendManager::OnError(const FResError* Error) const
{
	Q6JsonLogNet(Error, "Resp Error",
		Q6KV("Status Code", Error->Code),
		Q6KV("Error Code", Error->Body.ErrorCode),
		Q6KV("Body", *Error->Body.Error),
		Q6KV("Formatted Error",
			GetBaseHUD(GameInstance)->MakeErrorText(FErrTextType(Error->Body.ErrorCode), Error->Body.Extra)));

	ACTION_DISPATCH_FriendErrorResp(Error->Body);
}

void UFriendManager::ReqFriendList() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendLoad Out;

	ClientNetwork.WsRequest(TEXT("friend/load"), Out,
		TQ6ResponseDelegate<FL2CFriendLoadResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendLoadResp));
}

void UFriendManager::ReqFriendCooltimeList(int32 PageNo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendCooltimeList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("friendCooltime/list"), Out,
		TQ6ResponseDelegate<FL2CFriendCooltimeListResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendCooltimeListResp));
}

void UFriendManager::ReqFriendCandidates() const
{
	auto ConnectedFriends = GetConnectedFriends();
	FSortOrdering::Sort(ESortMenu::JokerSelect, ConnectedFriends, 0);

	int32 Added = 0;
	for (const FFriendInfo* IterFriendInfo : ConnectedFriends)
	{
		if (Added >= 10)
		{
			break;
		}

		const FDateTime& ExpireDate = Q6Util::UtcTimestampToLocalDateTime(IterFriendInfo->LastLogin)
			+ FTimespan(SystemConst::Q6_FRIEND_JOKER_LAST_LOGIN_DAYS, 0, 0, 0);
		bool bLongTimeNoSee = ExpireDate < FDateTime::Now();
		if (bLongTimeNoSee)
		{
			continue;
		}

		int32 CooltimeUtc = GetCooltime(IterFriendInfo->TargetUserId);
		if (CooltimeUtc > 0)
		{
#if !UE_BUILD_SHIPPING
			int32 Cooltime = DevCooltime >= 0 ? DevCooltime : SystemConst::Q6_FRIEND_JOKER_COOLTIME;
#else
			int32 Cooltime = SystemConst::Q6_FRIEND_JOKER_COOLTIME;
#endif

			FDateTime ExpireCooltimeDate = Q6Util::UtcTimestampToLocalDateTime(CooltimeUtc) +
				FTimespan(0, 0, Cooltime, 0);
			bool bCooltime = ExpireCooltimeDate > FDateTime::Now();
			if (bCooltime)
			{
				continue;
			}
		}
		Added = Added + 1;
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendCandidates Out;
	Out.Count = Added;

	ClientNetwork.WsRequest(TEXT("friend/candidates"), Out,
		TQ6ResponseDelegate<FL2CFriendCandidatesResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendCandidatesResp));
}

void UFriendManager::ReqFriendSearch(const FString& UserCode) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendSearch Out;
	Out.UserCode = UserCode;

	ClientNetwork.WsRequest(TEXT("friend/search"), Out,
		TQ6ResponseDelegate<FL2CFriendSearchResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendSearchResp));
}

void UFriendManager::ReqFriendRequest(const FFriendInfo& FriendInfo) const
{
	check(FriendInfo.TargetUserId == FriendCandidate.TargetUserId);

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendRequest Out;
	Out.TargetUserId = FriendInfo.TargetUserId;

	ClientNetwork.WsRequest(TEXT("friend/request"), Out,
		TQ6ResponseDelegate<FL2CFriendRequestResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendRequestResp));
}

void UFriendManager::ReqFriendDecline(const FFriendInfo& FriendInfo) const
{
	check(Receiving.Find(FriendInfo.FriendId));

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendDecline Out;
	Out.FriendId = FriendInfo.FriendId;
	Out.FromUserId = FriendInfo.TargetUserId;

	ClientNetwork.WsRequest(TEXT("friend/decline"), Out,
		TQ6ResponseDelegate<FL2CFriendDeclineResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendDeclineResp));
}

void UFriendManager::ReqFriendAccept(const FFriendInfo& FriendInfo) const
{
	check(Receiving.Find(FriendInfo.FriendId));

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendAccept Out;
	Out.FriendId = FriendInfo.FriendId;
	Out.FromUserId = FriendInfo.TargetUserId;

	ClientNetwork.WsRequest(TEXT("friend/accept"), Out,
		TQ6ResponseDelegate<FL2CFriendAcceptResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendAcceptResp));
}

void UFriendManager::ReqFriendRemove(const FFriendInfo& FriendInfo) const
{
	check(Connected.Find(FriendInfo.FriendId));

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendRemove Out;
	Out.FriendId = FriendInfo.FriendId;
	Out.TargetUserId = FriendInfo.TargetUserId;

	ClientNetwork.WsRequest(TEXT("friend/remove"), Out,
		TQ6ResponseDelegate<FL2CFriendRemoveResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendRemoveResp));
}

void UFriendManager::ReqFriendConfirm() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendConfirm Out;

	ClientNetwork.WsRequest(TEXT("friend/confirm"), Out,
		TQ6ResponseDelegate<FL2CFriendConfirmResp>::CreateUObject(
			const_cast<UFriendManager*>(this), &UFriendManager::OnFriendConfirmResp));
}

TArray<const FFriendInfoEx*> UFriendManager::GetConnectedFriends() const
{
	TArray<const FFriendInfoEx*> Friends;
	Friends.Empty(Connected.Num());
	for (auto It = Connected.CreateConstIterator(); It; ++It)
	{
		Friends.Add(&It->Value);
	}

	return Friends;
}

TArray<const FFriendInfoEx*> UFriendManager::GetReceivingFriends() const
{
	TArray<const FFriendInfoEx*> Friends;
	Friends.Empty(Receiving.Num());
	for (auto It = Receiving.CreateConstIterator(); It; ++It)
	{
		Friends.Add(&It->Value);
	}

	return Friends;
}

TArray<const FFriendInfoEx*> UFriendManager::GetCandidates() const
{
	TArray<const FFriendInfoEx*> OutCandidates;
	OutCandidates.Empty(Receiving.Num());
	for (const auto& FriendInfo : Candidates)
	{
		OutCandidates.Add(&FriendInfo);
	}

	return OutCandidates;
}

const FFriendInfoEx* UFriendManager::GetFriendInfo(FUserId FriendUserId) const
{
	for (const auto& InFriendInfo : Connected)
	{
		if (InFriendInfo.Value.TargetUserId == FriendUserId)
		{
			return &(InFriendInfo.Value);
		}
	}

	return nullptr;
}

int32 UFriendManager::GetCooltime(FUserId UserId) const
{
	for (const FFriendCooltime& FC : Cooltimes)
	{
		if (FC.FriendId == UserId)
		{
			return FC.Cooltime;
		}
	}

	return 0;
}

void UFriendManager::OnFriendLoadResp(const FResError* Error, const FL2CFriendLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_FriendLoadResp(Res);
	GameInstance->ReqNextContent();
}

void UFriendManager::OnFriendCooltimeListResp(const FResError* Error, const FL2CFriendCooltimeListResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_FriendCooltimeListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		return;
	}

	ReqFriendCooltimeList(Msg.PageNo + 1);
}

void UFriendManager::OnFriendCandidatesResp(const FResError* Error, const FL2CFriendCandidatesResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendCandidatesResp(Res);
}

void UFriendManager::OnFriendSearchResp(const FResError* Error, const FL2CFriendSearchResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendSearchResp(Res);
}

void UFriendManager::OnFriendRequestResp(const FResError* Error, const FL2CFriendRequestResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendRequestResp(Res);
}

void UFriendManager::OnFriendDeclineResp(const FResError* Error, const FL2CFriendDeclineResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendDeclineResp(Res);
}

void UFriendManager::OnFriendAcceptResp(const FResError* Error, const FL2CFriendAcceptResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendAcceptResp(Res);
}

void UFriendManager::OnFriendRemoveResp(const FResError* Error, const FL2CFriendRemoveResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendRemoveResp(Res);
}

void UFriendManager::OnFriendConfirmResp(const FResError* Error, const FL2CFriendConfirmResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_FriendConfirmResp(Res);
}

void UFriendManager::UpdateConnected(const TArray<FFriendInfo>& InConnected)
{
	Connected.Empty(InConnected.Num());
	for (const auto& Friend : InConnected)
	{
		Connected.Emplace(Friend.FriendId, Friend);
	}
}

void UFriendManager::UpdateReceiving(const TArray<FFriendInfo>& InReceiving)
{
	Receiving.Empty(InReceiving.Num());
	for (const auto& Friend : InReceiving)
	{
		Receiving.Emplace(Friend.FriendId, Friend);
	}
}

void UFriendManager::UpdateCandidates(const TArray<FFriendInfo>& InCandidates)
{
	Candidates.Empty(InCandidates.Num());
	for (const auto& Friend : InCandidates)
	{
		Candidates.Emplace(Friend);
	}
}

void UFriendManager::AddCooltime(const FFriendCooltime& In)
{
	if (In.FriendId == FUserId::InvalidValue())
	{
		return;
	}

	bool Updated = false;
	for (FFriendCooltime& Item : Cooltimes)
	{
		if (Item.FriendId == In.FriendId)
		{
			Item.Cooltime = In.Cooltime;
			Updated = true;
		}
	}

	if (Updated)
	{
		return;
	}

	Cooltimes.Add(In);
}

/////////////////////////////////////////////////////////////////////////////
// Setter

/////////////////////////////////////////////////////////////////////////////
// UFriendManager HUDStore Action

void UFriendManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UFriendManager, NetworkReconnected);
	REGISTER_ACTION_HANDLER(UFriendManager, SystemJoker);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendJoker);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendJokerFromPopup);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendLoadResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendCooltimeListResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendCandidatesResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendErrorResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendSearchResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendRequestResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendDeclineResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendAcceptResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendRemoveResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendConfirmResp);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendNotifyAccept);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendNotifyRemove);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendNotifyJokerSetChange);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendNotifyRequest);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendNotifyAvatarChange);
	REGISTER_ACTION_HANDLER(UFriendManager, FriendNotifyNicknameChanged);
	REGISTER_ACTION_HANDLER(UFriendManager, DevFriendBotAllResp);
	REGISTER_ACTION_HANDLER(UFriendManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UFriendManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UFriendManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UFriendManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(UFriendManager, DevFriendCooltimeResp);
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, NetworkReconnected)
{
	ReqFriendList();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, SystemJoker)
{
	bRecommendedFriend = false;
	return false;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendJoker)
{
	auto Action = ACTION_PARSE_FriendJoker(InAction);
	FriendCandidate = Action->GetVal();
	JokerSlot = Action->GetVal2();
	bRecommendedFriend = FriendCandidate.FriendId.IsInvalid();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendJokerFromPopup) //-V524 equivalent body
{
	auto Action = ACTION_PARSE_FriendJokerFromPopup(InAction);
	FriendCandidate = Action->GetVal();
	JokerSlot = Action->GetVal2();
	bRecommendedFriend = FriendCandidate.FriendId.IsInvalid();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendLoadResp)
{
	auto Action = ACTION_PARSE_FriendLoadResp(InAction);

	const auto& Res = Action->GetVal();
	UpdateConnected(Res.Connected);
	UpdateReceiving(Res.Receiving);
	Pending = Res.Pending;
	UpdateCandidates(Res.Connected);

	ConfirmedReceivings = Res.ConfirmedReceivings;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendCooltimeListResp)
{
	auto Action = ACTION_PARSE_FriendCooltimeListResp(InAction);

	const auto& Res = Action->GetVal();
	for (const FFriendCooltime& Info : Res.Cooltimes)
	{
		AddCooltime(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendCandidatesResp)
{
	auto Action = ACTION_PARSE_FriendCandidatesResp(InAction);

	const auto& Res = Action->GetVal();
	UpdateCandidates(Res.Candidates);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendErrorResp)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendSearchResp)
{
	const FL2CFriendSearchResp& Res = ACTION_PARSE_FriendSearchResp(InAction)->GetVal();

	FriendCandidate = Res.FriendInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendRequestResp)
{
	const FL2CFriendRequestResp& Res = ACTION_PARSE_FriendRequestResp(InAction)->GetVal();

	Q6JsonLogKalms(Display, "FriendRequestResp", Q6KV("Ok", Res.Ok), Q6KV("TargetUserId", Res.FriendInfo.TargetUserId));
	if (Res.Ok)
	{
		Pending.Push(Res.FriendInfo);
		Q6JsonLogKalms(Display, "Requested", Q6KV("RequestTo", Res.FriendInfo.TargetUserId));
	}

	return Res.Ok;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendDeclineResp)
{
	const FL2CFriendDeclineResp& Res = ACTION_PARSE_FriendDeclineResp(InAction)->GetVal();

	Q6JsonLogKalms(Display, "FriendDeclineResp", Q6KV("Ok", Res.Ok), Q6KV("FriendId", Res.FriendId));
	if (Res.Ok)
	{
		auto Declined = Receiving.FindAndRemoveChecked(Res.FriendId);
		Q6JsonLogKalms(Display, "DeclinedFriend", Q6KV("TargetUserId", Declined.TargetUserId));
	}

	return Res.Ok;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendAcceptResp)
{
	const FL2CFriendAcceptResp& Res = ACTION_PARSE_FriendAcceptResp(InAction)->GetVal();

	Q6JsonLogKalms(Display, "FriendAcceptResp", Q6KV("Ok", Res.Ok), Q6KV("FriendId", Res.FriendId));
	if (Res.Ok)
	{
		auto Accepted = Receiving.FindAndRemoveChecked(Res.FriendId);
		Connected.Emplace(Res.FriendId, Accepted);
		Q6JsonLogKalms(Display, "AcceptedFriend", Q6KV("TargetUserId", Accepted.TargetUserId));
	}

	return Res.Ok;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendRemoveResp)
{
	const FL2CFriendRemoveResp& Res = ACTION_PARSE_FriendRemoveResp(InAction)->GetVal();

	Q6JsonLogKalms(Display, "FriendRemoveResp", Q6KV("Ok", Res.Ok), Q6KV("FriendId", Res.FriendId));
	if (Res.Ok)
	{
		auto Removed = Connected.FindAndRemoveChecked(Res.FriendId);
		Q6JsonLogKalms(Display, "RemovedFriend", Q6KV("TargetUserId", Removed.TargetUserId));
	}

	return Res.Ok;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendConfirmResp)
{
	const FL2CFriendConfirmResp& Res = ACTION_PARSE_FriendConfirmResp(InAction)->GetVal();
	ConfirmedReceivings = Res.ConfirmedReceivings;

	return false;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendNotifyAccept)
{
	const FL2CFriendNotifyAccept& Notify = ACTION_PARSE_FriendNotifyAccept(InAction)->GetVal();

	int32 Index = 0;
	for (const FFriendInfo& Item : Pending)
	{
		if (Item.TargetUserId == Notify.FriendUserId)
		{
			Q6JsonLogPaul(Display, "FriendNotifyAccept", Q6KV("FriendId", Item.FriendId), Q6KV("FriendName", Item.Name), Q6KV("FriendUserId", Item.TargetUserId));
			Connected.Emplace(Item.FriendId, Item);
			if (Pending.IsValidIndex(Index))
			{
				Pending.RemoveAt(Index);
			}
			break;
		}
		++Index;
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendNotifyRemove)
{
	const FL2CFriendNotifyRemove& Notify = ACTION_PARSE_FriendNotifyRemove(InAction)->GetVal();

	for (auto& Elem : Connected)
	{
		if (Elem.Value.TargetUserId == Notify.UserId)
		{
			Q6JsonLogPaul(Display, "FriendNotifyRemove", Q6KV("FriendId", Elem.Key), Q6KV("UserId", Elem.Value.TargetUserId), Q6KV("UserName", Elem.Value.Name));
			Connected.Remove(Elem.Key);
			return true;
		}
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendNotifyJokerSetChange)
{
	const FL2CFriendNotifyJokerSetChange& Notify = ACTION_PARSE_FriendNotifyJokerSetChange(InAction)->GetVal();

	for (auto It = Connected.CreateIterator(); It; ++It)
	{
		FFriendInfo& FriendInfo = It.Value();
		if (FriendInfo.TargetUserId == Notify.FriendUserId)
		{
			Q6JsonLogPaul(Display, "FriendNotifyJokerSetChange", Q6KV("FriendUserId", Notify.FriendUserId), Q6KV("JokerSetId", Notify.JokerSet.Id));
			FriendInfo.JokerSet.Id = Notify.JokerSet.Id;
			FriendInfo.JokerSet.Slots = Notify.JokerSet.Slots;
			break;
		}
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendNotifyRequest)
{
	const FL2CFriendNotifyRequest& Notify = ACTION_PARSE_FriendNotifyRequest(InAction)->GetVal();

	Receiving.Emplace(Notify.FriendInfo.FriendId, Notify.FriendInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendNotifyAvatarChange)
{
	const FL2CFriendNotifyAvatarChange& Notify = ACTION_PARSE_FriendNotifyAvatarChange(InAction)->GetVal();

	for (auto& Elem : Connected)
	{
		FFriendInfoEx& FriendInfo = Elem.Value;
		if (FriendInfo.TargetUserId == Notify.FriendUserId)
		{
			Q6JsonLogRoze(Display, "FriendNotifyAvatarChange", Q6KV("FriendUserId", Notify.FriendUserId));
			FriendInfo.Avatar = Notify.AvatarInfo;
			return true;
		}
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, FriendNotifyNicknameChanged)
{
	const FL2CFriendNotifyNicknameChanged& Noti = ACTION_PARSE_FriendNotifyNicknameChanged(InAction)->GetVal();

	bool IsDirty = false;
	for (auto& Elem : Connected)
	{
		FFriendInfoEx& FriendInfo = Elem.Value;
		if (FriendInfo.TargetUserId == Noti.UserId)
		{
			FriendInfo.Name = Noti.Nickname;
			IsDirty = true;
			break;
		}
	}

	for (auto& Elem : Pending)
	{
		FFriendInfo& FriendInfo = Elem;
		if (FriendInfo.TargetUserId == Noti.UserId)
		{
			FriendInfo.Name = Noti.Nickname;
			IsDirty = true;
			break;
		}
	}

	for (auto& Elem : Receiving)
	{
		FFriendInfoEx& FriendInfo = Elem.Value;
		if (FriendInfo.TargetUserId == Noti.UserId)
		{
			FriendInfo.Name = Noti.Nickname;
			IsDirty = true;
			break;
		}
	}

	return IsDirty;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, DevFriendBotAllResp)
{
	const FL2CDevFriendBotAllResp& Res = ACTION_PARSE_DevFriendBotAllResp(InAction)->GetVal();

	Q6JsonLogKalms(Display, "DevFriendBotAllResp", Q6KV("Ok", Res.Ok));
	if (Res.Ok)
	{
		Q6JsonLogRoze(Display, "All bot added");
	}

	return Res.Ok;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, SagaStageEndResp)
{
	const FL2CSagaStageEndResp& Res = ACTION_PARSE_SagaStageEndResp(InAction)->GetVal();
	AddCooltime(Res.Cooltime);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, SpecialStageEndResp)
{
	const FL2CSpecialStageEndResp& Res = ACTION_PARSE_SpecialStageEndResp(InAction)->GetVal();
	AddCooltime(Res.Cooltime);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, DailyStageEndResp)
{
	const FL2CDailyStageEndResp& Res = ACTION_PARSE_DailyStageEndResp(InAction)->GetVal();
	AddCooltime(Res.Cooltime);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, RaidStageEndResp)
{
	const FL2CRaidStageEndResp& Res = ACTION_PARSE_RaidStageEndResp(InAction)->GetVal();
	AddCooltime(Res.Cooltime);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendManager, DevFriendCooltimeResp)
{
	const FL2CDevFriendCooltimeResp& Res = ACTION_PARSE_DevFriendCooltimeResp(InAction)->GetVal();

#if !UE_BUILD_SHIPPING
	DevCooltime = Res.Cooltime;
#endif

	return true;
}
