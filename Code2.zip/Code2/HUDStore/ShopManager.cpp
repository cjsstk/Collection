#include "ShopManager.h"

#include "Q6.h"
#include "Q6GameInstance.h"
#include "HSAction.h"
#include "LobbyHUD.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UShopManager

UShopManager::UShopManager()
{
	InitStore(EHSType::Shop);
}

void UShopManager::ReqList(bool bEnterLobby) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LShopList Out;

	ClientNetwork.WsRequest(TEXT("shop/list"),Out,
		TQ6ResponseDelegate<FL2CShopListResp>::CreateUObject(
			const_cast<UShopManager*>(this), &UShopManager::OnListResp, bEnterLobby));
}

void UShopManager::ReqSaleSchedule() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LShopSaleSchedule Out;

	ClientNetwork.WsRequest(TEXT("shop/saleSchedule"), Out,
		TQ6ResponseDelegate<FL2CShopSaleScheduleResp>::CreateUObject(
			const_cast<UShopManager*>(this), &UShopManager::OnSaleScheduleResp));
}

void UShopManager::ReqBuyItem(const FShopType& ShopType, const int32& Count) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LShopBuyItem Out;
	Out.Type = ShopType;
	Out.Count = Count;

	ClientNetwork.WsRequest(TEXT("shop/buyItem"), Out,
		TQ6ResponseDelegate<FL2CShopBuyItemResp>::CreateUObject(
			const_cast<UShopManager*>(this), &UShopManager::OnBuyItemResp));
}

void UShopManager::ReqSellItem(const ELootCategory& Category, const TArray<int64>& ItemIds) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LShopSellItem Out;
	Out.Category = Category;
	for (const int64& ItemId : ItemIds)
	{
		Out.ItemIds.Add(FAnyId(ItemId));
	}

	ClientNetwork.WsRequest(TEXT("shop/sellItem"), Out,
		TQ6ResponseDelegate<FL2CShopSellItemResp>::CreateUObject(
			const_cast<UShopManager*>(this), &UShopManager::OnSellItemResp));
}

void UShopManager::ReqClearNew(EShopCategory ShopCategory, ELootCategory CostCategory) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LShopClearNew Out;
	Out.ShopCategory = ShopCategory;
	Out.CostCategory = CostCategory;

	ClientNetwork.WsRequest(TEXT("shop/clearNew"), Out,
		TQ6ResponseDelegate<FL2CShopClearNewResp>::CreateUObject(
			const_cast<UShopManager*>(this), &UShopManager::OnClearNewResp));
}

int32 UShopManager::GetStocks(EShopBuyType InShopBuyType, FShopType InShopType) const
{
	const TMap<int32, FShopLimitItemInfo>* ShopItemInfos = GetShopLimitItemInfos(InShopBuyType);
	const FCMSShopRow& ShopRow = GetCMS()->GetShopRowOrDummy(InShopType);
	int32 LeftCount = ShopRow.BuyLimitCount;

	// check for bought item.
	// if item exists, substract LeftCount.
	if (ShopItemInfos)
	{
		const FShopLimitItemInfo* ShopLimitInfo = ShopItemInfos->Find(static_cast<int32>(InShopType));
		if (ShopLimitInfo)
		{
			LeftCount -= ShopLimitInfo->BuyCount;
		}
	}

	return LeftCount;
}

const FShopClearNewInfo* UShopManager::GetShopClearNewInfo(EShopCategory ShopCategory, ELootCategory CostCategory) const
{
	for (const FShopClearNewInfo& Info : ShopClearNewInfoList)
	{
		if (Info.ShopCategory != ShopCategory)
		{
			continue;
		}

		if (Info.CostCategory != CostCategory)
		{
			continue;
		}

		return &Info;
	}

	return nullptr;
}

/////////////////////////////////////////////////////////////////////////////
// UShopManager HUDStore Action

void UShopManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UShopManager, ShopListResp);
	REGISTER_ACTION_HANDLER(UShopManager, ShopBuyItemResp);
	REGISTER_ACTION_HANDLER(UShopManager, ShopClearNewResp);
	REGISTER_ACTION_HANDLER(UShopManager, DevShopResetResp);
}

void UShopManager::OnListResp(const FResError* Error, const FL2CShopListResp& Res, bool bEnterLobby)
{
	if (Error)
	{
		OnError(Error);
	}
	else
	{
		ACTION_DISPATCH_ShopListResp(Res);
	}

	if (bEnterLobby)
	{
		GameInstance->ReqNextContent();
	}
}

void UShopManager::OnSaleScheduleResp(const FResError* Error, const FL2CShopSaleScheduleResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_ShopSaleScheduleResp(Res);
}

void UShopManager::OnBuyItemResp(const FResError* Error, const FL2CShopBuyItemResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	if (Res.IsMonthlyResetShopLimitItem)
	{
		MonthlyResetShopLimitItem();
	}

	if (Res.Result == EShopBuyResult::Success)
	{
		ACTION_DISPATCH_ShopBuyItemResp(Res);

		if (Res.Result == EShopBuyResult::Success)
		{
			UItemReceivedPopupWidget* ItemReceivedPopup = GetCheckedLobbyHUD(GameInstance)->OpenItemReceivedPopup();
			ItemReceivedPopup->SetBuyItem(Res.Type, Res.Count);
		}
		// Gunny Todo
		// other cases
	}
	else
	{
		// To do : error handling?
	}
}

void UShopManager::OnSellItemResp(const FResError* Error, const FL2CShopSellItemResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_ShopSellItemResp(Res);
}

void UShopManager::OnClearNewResp(const FResError* Error, const FL2CShopClearNewResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_ShopClearNewResp(Res);
}

IMPLEMENT_ACTION_HANDLER(UShopManager, ShopListResp)
{
	auto Action = ACTION_PARSE_ShopListResp(InAction);
	auto& Resp = Action->GetVal();
	ShopClearNewInfoList = Resp.ShopClearNewInfos;
	InitShopLimitItemList(Resp.ShopLimitItemInfos);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UShopManager, ShopBuyItemResp)
{
	auto Action = ACTION_PARSE_ShopBuyItemResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateShopLimitItem(EShopBuyType::None, Resp.Type, Resp.Count);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UShopManager, ShopClearNewResp)
{
	auto Action = ACTION_PARSE_ShopClearNewResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateClearInfo(Resp.ShopClearNewInfo);

	return false;
}

IMPLEMENT_ACTION_HANDLER(UShopManager, DevShopResetResp)
{
	auto Action = ACTION_PARSE_DevShopResetResp(InAction);
	auto& Resp = Action->GetVal();
	ShopClearNewInfoList.Reset();
	MonthlyResetShopLimitItem();

	return true;
}

/////////////////////////////////////////////////////////////////////////////
// Setter

void UShopManager::InitShopLimitItemList(const TArray<FShopLimitItemInfo>& InShopLimitItemInfos)
{
	ShopLimitItemInfosMap.Empty();
	for (const FShopLimitItemInfo& Info : InShopLimitItemInfos)
	{
		auto ShopLimitItemInfos = ShopLimitItemInfosMap.Find(Info.BuyType);
		if (ShopLimitItemInfos)
		{
			ShopLimitItemInfos->Add(Info.Type, Info);
		}
		else
		{
			TMap<int32, FShopLimitItemInfo> Infos{ {Info.Type, Info} };
			ShopLimitItemInfosMap.Add(Info.BuyType, Infos);
		}
	}
}

void UShopManager::MonthlyResetShopLimitItem()
{
	for (auto& ShopLimitItemInfos : ShopLimitItemInfosMap)
	{
		for (auto& Info : ShopLimitItemInfos.Value)
		{
			FShopLimitItemInfo& ShopLimitItemInfo = Info.Value;
			const FCMSShopRow& ShopRow = GetCMS()->GetShopRowOrDummy(FShopType(ShopLimitItemInfo.Type));
			if (ShopRow.IsInvalid())
			{
				continue;
			}

			if (ShopRow.IsMonthlyReset)
			{
				ShopLimitItemInfo.BuyCount = 0;
			}
		}
	}
}

void UShopManager::UpdateShopLimitItem(const EShopBuyType& InShopBuyType, const FShopType& InShopType, const int32& InCount)
{
	int32 Type = InShopType.x;
	auto ShopLimitItemInfos = ShopLimitItemInfosMap.Find(InShopBuyType);
	if (ShopLimitItemInfos)
	{
		auto Info = ShopLimitItemInfos->Find(Type);
		if (Info)
		{
			Info->BuyCount += InCount;
		}
		else
		{
			ShopLimitItemInfos->Add(Type, { InShopBuyType, Type, InCount });
		}
	}
	else
	{
		TMap<int32, FShopLimitItemInfo> Infos{ {Type, { InShopBuyType, Type, InCount } } };
		ShopLimitItemInfosMap.Add(InShopBuyType, Infos);
	}
}

void UShopManager::UpdateClearInfo(const FShopClearNewInfo& Info)
{
	FShopClearNewInfo* FoundInfo = ShopClearNewInfoList.FindByPredicate([Info](const FShopClearNewInfo& OldInfo)
	{
		return (OldInfo.ShopCategory == Info.ShopCategory) && (OldInfo.CostCategory == Info.CostCategory);
	});

	if (FoundInfo)
	{
		FoundInfo->ClearNewTime = Info.ClearNewTime;
	}
	else
	{
		ShopClearNewInfoList.Add(Info);
	}
}