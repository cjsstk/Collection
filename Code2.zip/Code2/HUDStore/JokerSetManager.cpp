#include "JokerSetManager.h"
#include "HSAction.h"
#include "LobbyHUD.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6UIDefine.h"
#include "Q6GameInstance.h"
#include "GameResource.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UJokerManager

UJokerSetManager::UJokerSetManager()
{
	InitStore(EHSType::JokerSet);
}

const FJokerSet& UJokerSetManager::GetJokerSet(int32 JokerSetId) const
{
	for (const FJokerSet& JokerSet : JokerSetList)
	{
		if (JokerSet.Id == JokerSetId)
		{
			return JokerSet;
		}
	}

	static FJokerSet DummyJokerSet;
	DummyJokerSet.Id = JokerSetId;
	DummyJokerSet.Slots.SetNumZeroed(MAX_JOKER_SLOT);

	return DummyJokerSet;
}

TArray<FCharacterId> UJokerSetManager::GetCharactersInJokerSet() const
{
	TArray<FCharacterId> JokerSetCharacters;
	for (const FJokerSet& JokerSet : JokerSetList)
	{
		for (const FJokerSlot& JokerSlot : JokerSet.Slots)
		{
			if (!JokerSlot.CharacterId.IsInvalid())
			{
				JokerSetCharacters.AddUnique(JokerSlot.CharacterId);
			}
		}
	}

	return JokerSetCharacters;
}

TArray<FRelicId> UJokerSetManager::GetRelicsInJokerSet() const
{
	TArray<FRelicId> JokerSetRelics;
	for (const FJokerSet& JokerSet : JokerSetList)
	{
		for (const FJokerSlot& JokerSlot : JokerSet.Slots)
		{
			if (!JokerSlot.RelicId.IsInvalid())
			{
				JokerSetRelics.AddUnique(JokerSlot.RelicId);
			}
		}
	}

	return JokerSetRelics;
}

TArray<FSculptureId> UJokerSetManager::GetSculpturesInJokerSet() const
{
	TArray<FSculptureId> JokerSetSculptures;
	for (const FJokerSet& JokerSet : JokerSetList)
	{
		for (const FJokerSlot& JokerSlot : JokerSet.Slots)
		{
			if (!JokerSlot.SculptureId.IsInvalid())
			{
				JokerSetSculptures.AddUnique(JokerSlot.SculptureId);
			}
		}
	}

	return JokerSetSculptures;
}

bool UJokerSetManager::IsValidJokerSet(int32 JokerSetId) const
{
	const FJokerSet& JokerSet = GetJokerSet(JokerSetId);
	for (const FJokerSlot& JokerSlot : JokerSet.Slots)
	{
		if (JokerSlot.CharacterId.IsInvalid())
		{
			return false;
		}
	}

	return true;
}

void UJokerSetManager::ReqJokerSetList() const
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LJokerSetLoad Out;

	ClientNetwork.WsRequest(TEXT("jokerSet/load"), Out,
		TQ6ResponseDelegate<FL2CJokerSetLoadResp>::CreateUObject(
			const_cast<UJokerSetManager*>(this), &UJokerSetManager::OnJokerSetLoadResp));
}

void UJokerSetManager::ReqJokerSetSave(const FJokerSet& JokerSet) const
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LJokerSetSave Out;

	Out.JokerSet = JokerSet;

	ClientNetwork.WsRequest(TEXT("jokerSet/save"), Out,
		TQ6ResponseDelegate<FL2CJokerSetSaveResp>::CreateLambda([this](const FResError* Error, const FL2CJokerSetSaveResp& Res)
	{
		if (Error)
		{
			OnError(Error);
			return;
		}

		ACTION_DISPATCH_JokerSetSaveResp(Res);
	}));
}

void UJokerSetManager::ReqJokerSetUse(int32 JokerSetId) const
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LJokerSetUse Out;

	Out.JokerSetId = JokerSetId;

	ClientNetwork.WsRequest(TEXT("jokerSet/use"), Out,
		TQ6ResponseDelegate<FL2CJokerSetUseResp>::CreateLambda([this](const FResError* Error, const FL2CJokerSetUseResp& Res)
	{
		if (Error)
		{
			OnError(Error);
			return;
		}

		ACTION_DISPATCH_JokerSetUseResp(Res);
	}));
}

void UJokerSetManager::OnJokerSetLoadResp(const FResError* Error, const FL2CJokerSetLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_JokerSetLoadResp(Res);
	GameInstance->ReqNextContent();
}

/////////////////////////////////////////////////////////////////////////////
// HUDStore Action

void UJokerSetManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UJokerSetManager, JokerSetLoadResp);
	REGISTER_ACTION_HANDLER(UJokerSetManager, JokerSetSaveResp);
	REGISTER_ACTION_HANDLER(UJokerSetManager, JokerSetUseResp);
}

IMPLEMENT_ACTION_HANDLER(UJokerSetManager, JokerSetLoadResp)
{
	auto Action = ACTION_PARSE_JokerSetLoadResp(InAction);

	const auto& Res = Action->GetVal();
	JokerSetList = Res.JokerSetList;
	SelectedId = Res.SelectedId;

	return false;
}

IMPLEMENT_ACTION_HANDLER(UJokerSetManager, JokerSetSaveResp)
{
	auto Action = ACTION_PARSE_JokerSetSaveResp(InAction);

	const FJokerSet& InJokerSet = Action->GetVal().JokerSet;
	FJokerSet* Found = JokerSetList.FindByPredicate([&InJokerSet](const FJokerSet& JokerSet) { return JokerSet.Id == InJokerSet.Id; });
	if (Found)
	{
		*Found = InJokerSet;
	}
	else
	{
		JokerSetList.Push(InJokerSet);
	}

	GetLobbyHUD(GameInstance)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "JokerSetSaved"));
	return false;
}

IMPLEMENT_ACTION_HANDLER(UJokerSetManager, JokerSetUseResp)
{
	auto Action = ACTION_PARSE_JokerSetUseResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.SelectedId != SelectedId)
	{
		SelectedId = Res.SelectedId;
		return true;
	}

	return false;
}
