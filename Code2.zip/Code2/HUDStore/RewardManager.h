#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "RewardManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;

USTRUCT()
struct FStageReward
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	int32 GainXp;
	UPROPERTY()
	int32 GainGold;
	UPROPERTY()
	TArray<FItemData> ItemList;
};

///////////////////////////////////////////////////////////////////////////////////////////
// URewardManager
UCLASS()
class Q6_API URewardManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	URewardManager();

	const FStageReward& GetStageReward() const { return StageReward; }

	const TArray<FWaveSpawnUnitKillRewardInfo>& GetWaveSpawnUnitKillRewardInfo() const { return WaveSpawnUnitKillRewardInfos; }

protected:
	virtual void RegisterActionHandlers() override;

private:
	// On Actions
	DECLARE_ACTION_HANDLER(SagaStageBeginResp);
	DECLARE_ACTION_HANDLER(DailyStageBeginResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageBeginResp);
	DECLARE_ACTION_HANDLER(SpecialStageBeginResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageBeginResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageBeginResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageBeginResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageBeginResp);

	// Combat 
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	
	// Story
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	
	// Vacation
	DECLARE_ACTION_HANDLER(VacationEndResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeCompleteResp);

	// Lobby
	DECLARE_ACTION_HANDLER(AuthEnterLobbyFinalResp);

	struct FEndRewardDesc
	{
		FEndRewardDesc() :
			bBondReward(false)
		{}

		FSagaType SagaType;
		FWeedGrowType WeedGrowType;
		bool bBondReward;
		FUserTitleType UserTitleType;
		FContentFeatureOpenType ContentFeatureOpenType;
		FEventContentType EventContentType;
	};

	void SetClearReward(int32 GainXp, const TArray<FRewardInfo>& InRewardInfo);
	void SetEndReward(const FEndRewardDesc& InDesc,
		const TArray<FRewardInfo>& InRewardInfos = TArray<FRewardInfo>(),
		const TArray<FBondLevelUpReward>& InBondRewards = TArray<FBondLevelUpReward>());
	void SetVacationReward(const FRewardInfo& InRewardInfo);
	void SetWaveSpawnUnitKillReward(const TArray<FWaveSpawnUnitKillRewardInfo>& InWaveSpawnUnitKillRewardInfos);

	void AddBond(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps);
	void AddOutro(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps);
	void AddWeedGrow(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps);
	void AddRewards(const FEndRewardDesc& InDesc, const TArray<FRewardInfo>& RewardInfos, TArray<FRewardStep>& OutRewardSteps);
	void AddFoundRaid(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps);
	void AddTitle(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps);
	void AddContentOpen(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps);

	UPROPERTY()
	FStageReward StageReward;

	UPROPERTY()
	TArray<FWaveSpawnUnitKillRewardInfo> WaveSpawnUnitKillRewardInfos;
};
