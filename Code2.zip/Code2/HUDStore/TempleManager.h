#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"
#include "Q6Define.h"
#include "SystemConst_gen.h"

#include "TempleManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UTempleManager

UCLASS()
class Q6_API UTempleManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UTempleManager();

	void ReqLoad() const;
	void ReqUpgrade() const;
	void ReqUpgradeComplete() const;
	void ReqArtifactUse(int32 Index) const;
	void ReqArtifactBoost(int32 Index) const;
	void ReqArtifactUpgrade(int32 Index) const;
	void ReqHarvest() const;

#if !UE_BUILD_SHIPPING
	void ReqDevUpgrade(int32 TargetLevel) const;
#endif

	bool IsOpen() const { return (TempleInfo.Level > 0); }
	const FTempleInfo& GetTempleInfo() const { return TempleInfo; }

	const FArtifact* GetArtifact(int32 Index) const;
	int32 GetArtifactRemainSeconds(int32 Index) const;

	bool HasOpenedArtifactCanUseInBattle() const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	static const int32 RebirthSkillIndex = CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX;

	void OnLoadResp(const FResError* Error, const FL2CTempleLoadResp& Msg);
	void OnUpgradeResp(const FResError* Error, const FL2CTempleUpgradeResp& Msg);
	void OnUpgradeCompleteResp(const FResError* Error, const FL2CTempleUpgradeCompleteResp& Msg);
	void OnArtifactUseResp(const FResError* Error, const FL2CTempleArtifactUseResp& Msg);
	void OnArtifactBoostResp(const FResError* Error, const FL2CTempleArtifactBoostResp& Msg);
	void OnArtifactUpgradeResp(const FResError* Error, const FL2CTempleArtifactUpgradeResp& Msg);
	void OnHarvestResp(const FResError* Error, const FL2CTempleHarvestResp& Msg);

	DECLARE_ACTION_HANDLER(TempleLoadResp);
	DECLARE_ACTION_HANDLER(TempleUpgradeResp);
	DECLARE_ACTION_HANDLER(TempleUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(TempleArtifactUseResp);
	DECLARE_ACTION_HANDLER(TempleArtifactBoostResp);
	DECLARE_ACTION_HANDLER(TempleArtifactUpgradeResp);
	DECLARE_ACTION_HANDLER(TempleHarvestResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DevTempleOpenResp);
	DECLARE_ACTION_HANDLER(DevTempleProduceResp);
	DECLARE_ACTION_HANDLER(DevTempleArtifactsResetResp);
	DECLARE_ACTION_HANDLER(DevTempleArtifactUpgradeResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	
	FTempleInfo TempleInfo;
};
