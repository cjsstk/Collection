#pragma once


// Internal
#define ACTION_PARSE_AccountName(InAction)						ACTION_PARSE_ONE(FString, InAction)
#define ACTION_PARSE_WattInfo(InAction)							ACTION_PARSE_ONE(FWattDiffInfo, InAction)
#define ACTION_PARSE_GemConsume(InAction)						ACTION_PARSE_TWO(int32/*freegem*/, int32/*paidgem*/, InAction)
#define ACTION_PARSE_ClearMyCharacters(InAction)				ACTION_PARSE(InAction)
#define ACTION_PARSE_ClearBag(InAction)							ACTION_PARSE(InAction)
#define ACTION_PARSE_ClearRelic(InAction)						ACTION_PARSE(InAction)
#define ACTION_PARSE_ClearParty(InAction)						ACTION_PARSE(InAction)
#define ACTION_PARSE_ClearActRecord(InAction)					ACTION_PARSE(InAction)
#define ACTION_PARSE_SystemJoker(InAction)						ACTION_PARSE_REF(FCharacterInfo, InAction)
#define ACTION_PARSE_RandomJoker(InAction)						ACTION_PARSE_REF(FCharacterInfo, InAction)
#define ACTION_PARSE_FriendJoker(InAction)						ACTION_PARSE_TWO_REF(FFriendInfo, EJokerSlotType, InAction)
#define ACTION_PARSE_FriendJokerFromPopup(InAction)				ACTION_PARSE_TWO_REF(FFriendInfo, EJokerSlotType, InAction)
#define ACTION_PARSE_OwnedJoker(InAction)						ACTION_PARSE_REF(FPartySlot, InAction)
#define ACTION_PARSE_UpdateCurrency(InAction)					ACTION_PARSE_ONE(FCurrencyInfo, InAction)
#define ACTION_PARSE_UpdateMission(InAction)					ACTION_PARSE_REF(FMissionInfo, InAction)
#define ACTION_PARSE_UpdateCharMission(InAction)				ACTION_PARSE_REF(TArray<FCharMissionInfo>, InAction)
#define ACTION_PARSE_ContentsResetTime(InACtion)				ACTION_PARSE(InAction)
#define ACTION_PARSE_UserSetTutorials(InAction)					ACTION_PARSE_ONE(uint64, InAction)

// NetworkEvent
#define ACTION_PARSE_NetworkEvent(InAction)						ACTION_PARSE_REF(FNetInfo, InAction)

//////////////////////////////////////////////////////////////////////////////
//// Packet

// Lobby
#define ACTION_PARSE_AuthEnterLobbyResp(InAction)				ACTION_PARSE_REF(FL2CAuthEnterLobbyResp, InAction)
#define ACTION_PARSE_AuthEnterLobbyFinalResp(InAction)			ACTION_PARSE_REF(FL2CAuthEnterLobbyFinalResp, InAction)

// Currency
#define ACTION_PARSE_CurrencyLoadResp(InAction)					ACTION_PARSE_REF(FL2CCurrencyLoadResp, InAction)

// Result
#define ACTION_PARSE_UserAddXpResp(InAction)					ACTION_PARSE_REF(FL2CUserAddXpResp, InAction)
#define ACTION_PARSE_UserRenameResp(InAction)					ACTION_PARSE_REF(FL2CUserRenameResp, InAction)

// Character
#define ACTION_PARSE_CharacterListResp(InAction)				ACTION_PARSE_REF(FL2CCharacterListResp, InAction)
#define ACTION_PARSE_CharacterLoadResp(InAction)				ACTION_PARSE_REF(FL2CCharacterLoadResp, InAction)
#define ACTION_PARSE_CharacterAddXpResp(InAction)				ACTION_PARSE_REF(FL2CCharacterAddXpResp, InAction)
#define ACTION_PARSE_CharacterPromoteResp(InAction)				ACTION_PARSE_REF(FL2CCharacterPromoteResp, InAction)
#define ACTION_PARSE_CharacterRemoveResp(InAction)				ACTION_PARSE_REF(FL2CCharacterRemoveResp, InAction)
#define ACTION_PARSE_CharacterSkillLevelResp(InAction)			ACTION_PARSE_ONE(FL2CCharacterSkillLevelResp, InAction)
#define ACTION_PARSE_CharacterTurnSkillLevelResp(InAction)		ACTION_PARSE_ONE(FL2CCharacterUpgradeTurnSkillLevelResp, InAction)
#define ACTION_PARSE_CharacterUltimateSkillLevelResp(InAction)	ACTION_PARSE_ONE(FL2CCharacterUpgradeUltimateSkillLevelResp, InAction)
#define ACTION_PARSE_CharacterUnbindResp(InAction)				ACTION_PARSE_ONE(FL2CCharacterUnbindResp, InAction)
#define ACTION_PARSE_CharacterEvoluteResp(InAction)				ACTION_PARSE_ONE(FL2CCharacterEvoluteResp, InAction)
#define ACTION_PARSE_CharacterSetStashResp(InAction)			ACTION_PARSE_ONE(FL2CCharacterSetStashResp, InAction)
#define ACTION_PARSE_CharacterSetIllustResp(InAction)			ACTION_PARSE_ONE(FL2CCharacterSetIllustResp, InAction)
#define ACTION_PARSE_CharacterClearNewResp(InAction)			ACTION_PARSE_ONE(FL2CCharacterClearNewResp, InAction)

// Character Bond
#define ACTION_PARSE_BondLoadResp(InAction)						ACTION_PARSE_REF(FL2CBondLoadResp, InAction)

// Friend
#define ACTION_PARSE_FriendAcceptResp(InAction)					ACTION_PARSE_REF(FL2CFriendAcceptResp, InAction)
#define ACTION_PARSE_FriendDeclineResp(InAction)				ACTION_PARSE_REF(FL2CFriendDeclineResp, InAction)
#define ACTION_PARSE_FriendLoadResp(InAction)					ACTION_PARSE_REF(FL2CFriendLoadResp, InAction)
#define ACTION_PARSE_FriendCooltimeListResp(InAction)			ACTION_PARSE_REF(FL2CFriendCooltimeListResp, InAction)
#define ACTION_PARSE_FriendCandidatesResp(InAction)				ACTION_PARSE_REF(FL2CFriendCandidatesResp, InAction)
#define ACTION_PARSE_FriendRemoveResp(InAction)					ACTION_PARSE_REF(FL2CFriendRemoveResp, InAction)
#define ACTION_PARSE_FriendRequestResp(InAction)				ACTION_PARSE_REF(FL2CFriendRequestResp, InAction)
#define ACTION_PARSE_FriendSearchResp(InAction)					ACTION_PARSE_REF(FL2CFriendSearchResp, InAction)
#define ACTION_PARSE_FriendConfirmResp(InAction)				ACTION_PARSE_REF(FL2CFriendConfirmResp, InAction)
#define ACTION_PARSE_FriendErrorResp(InAction)					ACTION_PARSE_REF(FL2CError, InAction)
#define ACTION_PARSE_FriendNotifyAccept(InAction)				ACTION_PARSE_REF(FL2CFriendNotifyAccept, InAction)
#define ACTION_PARSE_FriendNotifyRemove(InAction)				ACTION_PARSE_REF(FL2CFriendNotifyRemove, InAction)
#define ACTION_PARSE_FriendNotifyJokerSetChange(InAction)		ACTION_PARSE_REF(FL2CFriendNotifyJokerSetChange, InAction)
#define ACTION_PARSE_FriendNotifyRequest(InAction)				ACTION_PARSE_REF(FL2CFriendNotifyRequest, InAction)
#define ACTION_PARSE_FriendNotifyAvatarChange(InAction)			ACTION_PARSE_REF(FL2CFriendNotifyAvatarChange, InAction)
#define ACTION_PARSE_FriendNotifyNicknameChanged(InAction)		ACTION_PARSE_REF(FL2CFriendNotifyNicknameChanged, InAction)

// Friendship
#define ACTION_PARSE_FriendshipCollectResp(InAction)			ACTION_PARSE_REF(FL2CFriendshipCollectResp, InAction)

// JokerSet
#define ACTION_PARSE_JokerSetLoadResp(InAction)					ACTION_PARSE_REF(FL2CJokerSetLoadResp, InAction)
#define ACTION_PARSE_JokerSetSaveResp(InAction)					ACTION_PARSE_REF(FL2CJokerSetSaveResp, InAction)
#define ACTION_PARSE_JokerSetUseResp(InAction)					ACTION_PARSE_REF(FL2CJokerSetUseResp, InAction)

// Mail
#define ACTION_PARSE_MailListResp(InAction)						ACTION_PARSE_REF(FL2CMailListResp, InAction)
#define ACTION_PARSE_MailReceiveResp(InAction)					ACTION_PARSE_REF(FL2CMailReceiveResp, InAction)
#define ACTION_PARSE_MailRefreshListResp(InAction)				ACTION_PARSE_REF(FL2CMailRefreshListResp, InAction)

// Party
#define ACTION_PARSE_PartyLoadResp(InAction)					ACTION_PARSE_REF(FL2CPartyLoadResp, InAction)
#define ACTION_PARSE_PartySaveResp(InAction)					ACTION_PARSE_REF(FL2CPartySaveResp, InAction)

// Bag Item
#define ACTION_PARSE_BagItemLoadResp(InAction)					ACTION_PARSE_REF(FL2CBagItemLoadResp, InAction)
#define ACTION_PARSE_BagItemListResp(InAction)					ACTION_PARSE_REF(FL2CBagItemListResp, InAction)
#define ACTION_PARSE_BagItemRemoveResp(InAction)				ACTION_PARSE_REF(FL2CBagItemRemoveResp, InAction)

// Relic
#define ACTION_PARSE_RelicLoadResp(InAction)					ACTION_PARSE_ONE(FL2CRelicLoadResp, InAction)
#define ACTION_PARSE_RelicListResp(InAction)					ACTION_PARSE_ONE(FL2CRelicListResp, InAction)
#define ACTION_PARSE_RelicRemoveResp(InAction)					ACTION_PARSE_ONE(FL2CRelicRemoveResp, InAction)
#define ACTION_PARSE_RelicAddXpResp(InAction)					ACTION_PARSE_ONE(FL2CRelicAddXpResp, InAction)
#define ACTION_PARSE_RelicPromoteResp(InAction)					ACTION_PARSE_ONE(FL2CRelicPromoteResp, InAction)
#define ACTION_PARSE_RelicTierUpResp(InAction)					ACTION_PARSE_ONE(FL2CRelicTierUpgradeResp, InAction)
#define ACTION_PARSE_RelicSetStashResp(InAction)				ACTION_PARSE_ONE(FL2CRelicSetStashResp, InAction)
#define ACTION_PARSE_RelicClearNewResp(InAction)				ACTION_PARSE_ONE(FL2CRelicClearNewResp, InAction)

// Sculpture
#define ACTION_PARSE_SculptureLoadResp(InAction)				ACTION_PARSE_ONE(FL2CSculptureLoadResp, InAction)
#define ACTION_PARSE_SculptureListResp(InAction)				ACTION_PARSE_ONE(FL2CSculptureListResp, InAction)
#define ACTION_PARSE_SculptureRemoveResp(InAction)				ACTION_PARSE_ONE(FL2CSculptureRemoveResp, InAction)
#define ACTION_PARSE_SculptureAddXpResp(InAction)				ACTION_PARSE_ONE(FL2CSculptureAddXpResp, InAction)
#define ACTION_PARSE_SculpturePromoteResp(InAction)				ACTION_PARSE_ONE(FL2CSculpturePromoteResp, InAction)
#define ACTION_PARSE_SculptureTierUpResp(InAction)				ACTION_PARSE_ONE(FL2CSculptureTierUpgradeResp, InAction)
#define ACTION_PARSE_SculptureSetStashResp(InAction)			ACTION_PARSE_ONE(FL2CSculptureSetStashResp, InAction)
#define ACTION_PARSE_SculptureClearNewResp(InAction)			ACTION_PARSE_ONE(FL2CSculptureClearNewResp, InAction)

// ActRecord
#define ACTION_PARSE_ActRecordLoadResp(InAction)				ACTION_PARSE_ONE(FL2CActRecordLoadResp, InAction)
#define ACTION_PARSE_ActRecordListResp(InAction)				ACTION_PARSE_ONE(FL2CActRecordListResp, InAction)
#define ACTION_PARSE_ActRecordRemoveResp(InAction)				ACTION_PARSE_ONE(FL2CActRecordRemoveResp, InAction)

// UserRecord
#define ACTION_PARSE_UserRecordListResp(InAction)				ACTION_PARSE_ONE(FL2CUserRecordListResp, InAction)
#define ACTION_PARSE_UserRecordRezCountResp(InAction)			ACTION_PARSE_ONE(FL2CUserRecordRezCountResp, InAction)

// codex
#define ACTION_PARSE_CodexListCharResp(InAction)				ACTION_PARSE_ONE(FL2CCodexListCharResp, InAction)
#define ACTION_PARSE_CodexListSculptureResp(InAction)			ACTION_PARSE_ONE(FL2CCodexListSculptureResp, InAction)
#define ACTION_PARSE_CodexListRelicResp(InAction)				ACTION_PARSE_ONE(FL2CCodexListRelicResp, InAction)
#define ACTION_PARSE_CodexClearNewCharResp(InAction)			ACTION_PARSE_ONE(FL2CCodexClearNewCharResp, InAction)
#define ACTION_PARSE_CodexClearNewSculptureResp(InAction)		ACTION_PARSE_ONE(FL2CCodexClearNewSculptureResp, InAction)
#define ACTION_PARSE_CodexClearNewRelicResp(InAction)			ACTION_PARSE_ONE(FL2CCodexClearNewRelicResp, InAction)
#define ACTION_PARSE_CodexClearNewAllResp(InAction)				ACTION_PARSE_ONE(FL2CCodexClearNewAllResp, InAction)

// weekly mission
#define ACTION_PARSE_WeeklyMissionLoadResp(InAction)			ACTION_PARSE_ONE(FL2CWeeklyMissionLoadResp, InAction)
#define ACTION_PARSE_WeeklyMissionRewardResp(InAction)			ACTION_PARSE_ONE(FL2CWeeklyMissionReceiveRewardResp, InAction)
#define ACTION_PARSE_WeeklyMissionBingoResp(InAction)			ACTION_PARSE_ONE(FL2CWeeklyMissionReceiveBingoResp, InAction)
#define ACTION_PARSE_WeeklyMissionShuffleResp(InAction)			ACTION_PARSE_ONE(FL2CWeeklyMissionShuffleResp, InAction)

// smelter
#define ACTION_PARSE_SmelterLoadResp(InAction)					ACTION_PARSE_ONE(FL2CSmelterLoadResp, InAction)
#define ACTION_PARSE_SmelterIncStockResp(InAction)				ACTION_PARSE_ONE(FL2CSmelterIncStockResp, InAction)
#define ACTION_PARSE_SmelterDecStockResp(InAction)				ACTION_PARSE_ONE(FL2CSmelterDecStockResp, InAction)
#define ACTION_PARSE_SmelterReceiveResp(InAction)				ACTION_PARSE_ONE(FL2CSmelterReceiveResp, InAction)
#define ACTION_PARSE_SmelterUpgradeResp(InAction)				ACTION_PARSE_ONE(FL2CSmelterUpgradeResp, InAction)
#define ACTION_PARSE_SmelterUpgradeCompleteResp(InAction)		ACTION_PARSE_ONE(FL2CSmelterUpgradeCompleteResp, InAction)
#define ACTION_PARSE_SmelterProduceResp(InAction)				ACTION_PARSE_ONE(FL2CSmelterProduceResp, InAction)

// alchemylab
#define ACTION_PARSE_AlchemylabLoadResp(InAction)				ACTION_PARSE_ONE(FL2CAlchemylabLoadResp, InAction)
#define ACTION_PARSE_AlchemylabIncStockResp(InAction)			ACTION_PARSE_ONE(FL2CAlchemylabIncStockResp, InAction)
#define ACTION_PARSE_AlchemylabDecStockResp(InAction)			ACTION_PARSE_ONE(FL2CAlchemylabDecStockResp, InAction)
#define ACTION_PARSE_AlchemylabReceiveResp(InAction)			ACTION_PARSE_ONE(FL2CAlchemylabReceiveResp, InAction)
#define ACTION_PARSE_AlchemylabUpgradeResp(InAction)			ACTION_PARSE_ONE(FL2CAlchemylabUpgradeResp, InAction)
#define ACTION_PARSE_AlchemylabUpgradeCompleteResp(InAction)	ACTION_PARSE_ONE(FL2CAlchemylabUpgradeCompleteResp, InAction)
#define ACTION_PARSE_AlchemylabProduceResp(InAction)			ACTION_PARSE_ONE(FL2CAlchemylabProduceResp, InAction)

// char mission
#define ACTION_PARSE_CharMissionListResp(InAction)				ACTION_PARSE_ONE(FL2CCharMissionListResp, InAction)
#define ACTION_PARSE_CharMissionRewardResp(InAction)			ACTION_PARSE_ONE(FL2CCharMissionReceiveRewardResp, InAction)

// event mission
#define ACTION_PARSE_EventMissionListResp(InAction)				ACTION_PARSE_ONE(FL2CEventMissionListResp, InAction)

// user title
#define ACTION_PARSE_TitleListResp(InAction)					ACTION_PARSE_ONE(FL2CUserTitleListResp, InAction)
#define ACTION_PARSE_TitleChangeResp(InAction)					ACTION_PARSE_ONE(FL2CUserTitleChangeResp, InAction)
#define ACTION_PARSE_DevTitleAddResp(InAction)					ACTION_PARSE_ONE(FL2CDevTitleAddResp, InAction)

// Saga
#define ACTION_PARSE_SagaLoadResp(InAction)						ACTION_PARSE_REF(FL2CSagaLoadResp, InAction)
#define ACTION_PARSE_SagaStageBeginResp(InAction)				ACTION_PARSE_REF(FL2CSagaStageBeginResp, InAction)
#define ACTION_PARSE_SagaStageEndResp(InAction)					ACTION_PARSE_REF(FL2CSagaStageEndResp, InAction)
#define ACTION_PARSE_SagaStoryStageClearResp(InAction)			ACTION_PARSE_REF(FL2CSagaStoryStageClearResp, InAction)

// Special
#define ACTION_PARSE_SpecialLoadResp(InAction)					ACTION_PARSE_REF(FL2CSpecialLoadResp, InAction)
#define ACTION_PARSE_SpecialStageBeginResp(InAction)			ACTION_PARSE_REF(FL2CSpecialStageBeginResp, InAction)
#define ACTION_PARSE_SpecialStageEndResp(InAction)				ACTION_PARSE_REF(FL2CSpecialStageEndResp, InAction)
#define ACTION_PARSE_SpecialStoryStageClearResp(InAction)		ACTION_PARSE_REF(FL2CSpecialStoryStageClearResp, InAction)

// Daily
#define ACTION_PARSE_DailyStageBeginResp(InAction)				ACTION_PARSE_REF(FL2CDailyStageBeginResp, InAction)
#define ACTION_PARSE_DailyStageEndResp(InAction)				ACTION_PARSE_REF(FL2CDailyStageEndResp, InAction)
#define ACTION_PARSE_DailyListResp(InAction)					ACTION_PARSE_REF(FL2CDailyListResp, InAction)

// Raid
#define ACTION_PARSE_RaidListResp(InAction)						ACTION_PARSE_REF(FL2CRaidListResp, InAction)
#define ACTION_PARSE_RaidOpenNof(InAction)						ACTION_PARSE_REF(FL2CRaidOpenNof, InAction)
#define ACTION_PARSE_RaidPrepareResp(InAction)					ACTION_PARSE_REF(FL2CRaidPrepareResp, InAction)
#define ACTION_PARSE_RaidCanEnterNof(InAction)					ACTION_PARSE_REF(FL2CRaidCanEnterNof, InAction)
#define ACTION_PARSE_RaidStageEndResp(InAction)					ACTION_PARSE_REF(FL2CRaidStageEndResp, InAction)
#define ACTION_PARSE_RaidStageEndNof(InAction)					ACTION_PARSE_REF(FL2CRaidStageEndNof, InAction)
#define ACTION_PARSE_RaidSkillUsedResp(InAction)				ACTION_PARSE_REF(FL2CRaidSkillUsedResp, InAction)
#define ACTION_PARSE_RaidEnterNof(InAction)						ACTION_PARSE_REF(FL2CRaidEnterNof, InAction)
#define ACTION_PARSE_RaidFullNof(InAction)						ACTION_PARSE_REF(FL2CRaidFullNof, InAction)
#define ACTION_PARSE_RaidKickTimeoutNof(InAction)				ACTION_PARSE_REF(FL2CRaidKickTimeoutNof, InAction)
#define ACTION_PARSE_RaidSkillsNof(InAction)					ACTION_PARSE_REF(FL2CRaidSkillsNof, InAction)
#define ACTION_PARSE_RaidEndNof(InAction)						ACTION_PARSE_REF(FL2CRaidEndNof, InAction)
#define ACTION_PARSE_RaidBossHealthNof(InAction)				ACTION_PARSE_REF(FL2CRaidBossHealthNof, InAction)
#define ACTION_PARSE_RaidEmoticonNof(InAction)					ACTION_PARSE_REF(FL2CRaidEmoticonNof, InAction)
#define ACTION_PARSE_RaidSharePartyResp(InAction)				ACTION_PARSE_REF(FL2CRaidSharePartyResp, InAction)
#define ACTION_PARSE_RaidSharePartyNof(InAction)				ACTION_PARSE_REF(FL2CRaidSharePartyNof, InAction)
#define ACTION_PARSE_RaidFinalStageBeginResp(InAction)			ACTION_PARSE_REF(FL2CRaidFinalStageBeginResp, InAction)
#define ACTION_PARSE_RaidFinalStageEndResp(InAction)			ACTION_PARSE_REF(FL2CRaidFinalStageEndResp, InAction)
#define ACTION_PARSE_RegularRaidRegisterResp(InAction)			ACTION_PARSE_REF(FL2CRegularRaidRegisterResp, InAction)
#define ACTION_PARSE_RegularRaidReadyResp(InAction)				ACTION_PARSE_REF(FL2CRegularRaidReadyResp, InAction)
#define ACTION_PARSE_RegularRaidMatchedNoti(InAction)			ACTION_PARSE_REF(FL2CRegularRaidNotiMatched, InAction)

// Summon
#define ACTION_PARSE_SummonLoadResp(InAction)					ACTION_PARSE_REF(FL2CSummonLoadResp, InAction)
#define ACTION_PARSE_SummonPurchaseResp(InAction)				ACTION_PARSE_REF(FL2CSummonPurchaseResp, InAction)
#define ACTION_PARSE_SummonBoxScheduleResp(InAction)			ACTION_PARSE_REF(FL2CSummonScheduleResp, InAction)
#define ACTION_PARSE_SummonPickupResp(InAction)					ACTION_PARSE_REF(FL2CSummonPickupResp, InAction)

// TrainingCenter
#define ACTION_PARSE_TrainingCenterLoadResp(InAction)			ACTION_PARSE_REF(FL2CTrainingCenterLoadResp, InAction)
#define ACTION_PARSE_TrainingCenterStageBeginResp(InAction)		ACTION_PARSE_REF(FL2CTrainingCenterStageBeginResp, InAction)
#define ACTION_PARSE_TrainingCenterStageEndResp(InAction)		ACTION_PARSE_REF(FL2CTrainingCenterStageEndResp, InAction)

// Pyramid
#define ACTION_PARSE_PyramidLoadResp(InAction)					ACTION_PARSE_REF(FL2CPyramidLoadResp, InAction)
#define ACTION_PARSE_PyramidPortalConnectResp(InAction)			ACTION_PARSE_REF(FL2CPyramidPortalConnectResp, InAction)
#define ACTION_PARSE_PyramidUpgradeResp(InAction)				ACTION_PARSE_REF(FL2CPyramidUpgradeResp, InAction)
#define	ACTION_PARSE_PyramidUpgradeCompleteResp(InAction)		ACTION_PARSE_REF(FL2CPyramidUpgradeCompleteResp, InAction)
#define ACTION_PARSE_PyramidPortalBoostUseResp(InAction)		ACTION_PARSE_REF(FL2CPyramidPortalBoostUseResp, InAction)
#define ACTION_PARSE_PyramidPortalWarpResp(InAction)			ACTION_PARSE_REF(FL2CPyramidPortalWarpResp, InAction)

// Temple
#define ACTION_PARSE_TempleLoadResp(InAction)					ACTION_PARSE_REF(FL2CTempleLoadResp, InAction)
#define ACTION_PARSE_TempleUpgradeResp(InAction)				ACTION_PARSE_REF(FL2CTempleUpgradeResp, InAction)
#define ACTION_PARSE_TempleUpgradeCompleteResp(InAction)		ACTION_PARSE_REF(FL2CTempleUpgradeCompleteResp, InAction)
#define ACTION_PARSE_TempleArtifactUseResp(InAction)			ACTION_PARSE_REF(FL2CTempleArtifactUseResp, InAction)
#define ACTION_PARSE_TempleArtifactBoostResp(InAction)			ACTION_PARSE_REF(FL2CTempleArtifactBoostResp, InAction)
#define ACTION_PARSE_TempleArtifactUpgradeResp(InAction)		ACTION_PARSE_REF(FL2CTempleArtifactUpgradeResp, InAction)
#define ACTION_PARSE_TempleHarvestResp(InAction)				ACTION_PARSE_REF(FL2CTempleHarvestResp, InAction)

// PowerPlant
#define ACTION_PARSE_PowerPlantLoadResp(InAction)				ACTION_PARSE_REF(FL2CPowerPlantLoadResp, InAction)
#define ACTION_PARSE_PowerPlantUpgradeResp(InAction)			ACTION_PARSE_REF(FL2CPowerPlantUpgradeResp, InAction)
#define ACTION_PARSE_PowerPlantUpgradeCompleteResp(InAction)	ACTION_PARSE_REF(FL2CPowerPlantUpgradeCompleteResp, InAction)
#define ACTION_PARSE_PowerPlantStoreResp(InAction)				ACTION_PARSE_REF(FL2CPowerPlantStoreResp, InAction)
#define ACTION_PARSE_PowerPlantRechargeResp(InAction)			ACTION_PARSE_REF(FL2CPowerPlantRechargeResp, InAction)

// Pet
#define ACTION_PARSE_PetLoadResp(InAction)						ACTION_PARSE_REF(FL2CPetLoadResp, InAction)
#define ACTION_PARSE_PetParkUpgradeResp(InAction)				ACTION_PARSE_REF(FL2CPetParkUpgradeResp, InAction)
#define ACTION_PARSE_PetParkUpgradeCompleteResp(InAction)		ACTION_PARSE_REF(FL2CPetParkUpgradeCompleteResp, InAction)
#define ACTION_PARSE_PetParkHarvestResp(InAction)				ACTION_PARSE_REF(FL2CPetHarvestResp, InAction)
#define ACTION_PARSE_PetSkillUpgradeResp(InAction)				ACTION_PARSE_REF(FL2CPetSkillUpgradeResp, InAction)

// Vacation
#define ACTION_PARSE_VacationLoadResp(InAction)					ACTION_PARSE_REF(FL2CVacationLoadResp, InAction)
#define ACTION_PARSE_VacationUpgradeResp(InAction)				ACTION_PARSE_REF(FL2CVacationUpgradeResp, InAction)
#define ACTION_PARSE_VacationUpgradeCompleteResp(InAction)		ACTION_PARSE_REF(FL2CVacationUpgradeCompleteResp, InAction)
#define ACTION_PARSE_VacationStartResp(InAction)				ACTION_PARSE_REF(FL2CVacationStartResp, InAction)
#define ACTION_PARSE_VacationEndResp(InAction)					ACTION_PARSE_REF(FL2CVacationEndResp, InAction)

// Watt
#define ACTION_PARSE_WattRechargeResp(InAction)					ACTION_PARSE_REF(FL2CWattRechargeResp, InAction)

// CheckIn
#define ACTION_PARSE_CheckInListResp(InAction)					ACTION_PARSE_REF(FL2CCheckInListResp, InAction)
#define ACTION_PARSE_CheckInRewardReceiveResp(InAction)			ACTION_PARSE_REF(FL2CCheckInRewardReceiveResp, InAction)

// Shop
#define ACTION_PARSE_ShopListResp(InAction)						ACTION_PARSE_REF(FL2CShopListResp, InAction)
#define ACTION_PARSE_ShopSaleScheduleResp(InAction)				ACTION_PARSE_REF(FL2CShopSaleScheduleResp, InAction)
#define ACTION_PARSE_ShopBuyItemResp(InAction)					ACTION_PARSE_REF(FL2CShopBuyItemResp, InAction)
#define ACTION_PARSE_ShopSellItemResp(InAction)					ACTION_PARSE_REF(FL2CShopSellItemResp, InAction)
#define ACTION_PARSE_ShopClearNewResp(InAction)					ACTION_PARSE_REF(FL2CShopClearNewResp, InAction)

// LobbyTemplate
#define ACTION_PARSE_LobbyTemplateListResp(InAction)			ACTION_PARSE_REF(FL2CLobbyTemplateListResp, InAction)
#define ACTION_PARSE_LobbyTemplateClearNewResp(InAction)		ACTION_PARSE_REF(FL2CLobbyTemplateClearNewResp, InAction)

// LobbySet
#define ACTION_PARSE_LobbySetLoadResp(InAction)					ACTION_PARSE_REF(FL2CLobbySetLoadResp, InAction)
#define ACTION_PARSE_LobbySetSaveResp(InAction)					ACTION_PARSE_REF(FL2CLobbySetSaveResp, InAction)
#define ACTION_PARSE_LobbySetUseResp(InAction)					ACTION_PARSE_REF(FL2CLobbySetUseResp, InAction)

// ContentFeatureOpen
#define ACTION_PARSE_ContentFeatureOpenListResp(InAction)		ACTION_PARSE_REF(FL2CContentFeatureOpenListResp, InAction)

// Event
#define ACTION_PARSE_EventContentListResp(InAction)		ACTION_PARSE_REF(FL2CEventContentListResp, InAction)
#define ACTION_PARSE_EventContentRefreshNumberOfDaysResp(InAction)		ACTION_PARSE_REF(FL2CEventContentRefreshNumberOfDaysResp, InAction)
#define ACTION_PARSE_EventContentRoulettePlayResp(InAction)				ACTION_PARSE_REF(FL2CEventContentRoulettePlayResp, InAction)
#define ACTION_PARSE_EventContentRouletteResetResp(InAction)			ACTION_PARSE_REF(FL2CEventContentRouletteResetResp, InAction)
#define ACTION_PARSE_EventContentCollabo01StageBeginResp(InAction)		ACTION_PARSE_REF(FL2CEventContentCollabo01StageBeginResp, InAction)
#define ACTION_PARSE_EventContentCollabo01StageEndResp(InAction)		ACTION_PARSE_REF(FL2CEventContentCollabo01StageEndResp, InAction)
#define ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction)	ACTION_PARSE_REF(FL2CEventContentCollabo01StoryStageClearResp, InAction)
#define ACTION_PARSE_EventContentValentineDayStageBeginResp(InAction)	ACTION_PARSE_REF(FL2CEventContentValentineDayStageBeginResp, InAction)
#define ACTION_PARSE_EventContentValentineDayStageEndResp(InAction)		ACTION_PARSE_REF(FL2CEventContentValentineDayStageEndResp, InAction)
#define ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction)		ACTION_PARSE_REF(FL2CEventContentValentineDayStoryStageClearResp, InAction)
#define ACTION_PARSE_EventContentMultiSideBattleStageBeginResp(InAction)		ACTION_PARSE_REF(FL2CEventContentMultiSideBattleStageBeginResp, InAction)
#define ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction)			ACTION_PARSE_REF(FL2CEventContentMultiSideBattleStageEndResp, InAction)
#define ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction)	ACTION_PARSE_REF(FL2CEventContentMultiSideBattleStoryStageClearResp, InAction)
#define ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction)	ACTION_PARSE_REF(FL2CEventContentMultiSideBattleReceiveRankRewardResp, InAction)
#define ACTION_PARSE_EventContentMultiSideBattleRankLoadResp(InAction)			ACTION_PARSE_REF(FL2CEventContentMultiSideBattleLoadResp, InAction)

// Avatar
#define ACTION_PARSE_AvatarLoadResp(InAction)		ACTION_PARSE_REF(FL2CAvatarLoadResp, InAction)
#define ACTION_PARSE_AvatarSaveResp(InAction)		ACTION_PARSE_REF(FL2CAvatarSaveResp, InAction)

// NewMark
#define ACTION_PARSE_NewMarkNotifyMail(InAction)				ACTION_PARSE_REF(bool, InAction)

// BattleHelper
#define ACTION_PARSE_StageChallengeListResp(InAction)			ACTION_PARSE_REF(FL2CStageChallengeListResp, InAction);
#define ACTION_PARSE_StageChallengeAddResp(InAction)			ACTION_PARSE_ONE(FC2LStageChallengeAdd, InAction);

// FriendBook
#define ACTION_PARSE_FriendBookPosted(InAction)				ACTION_PARSE_REF(FL2CFriendBookNotiPosted, InAction)
#define ACTION_PARSE_FriendBookReacted(InAction)			ACTION_PARSE_REF(FL2CFriendBookNotiReacted, InAction)
#define ACTION_PARSE_FriendBookReactionRemoved(InAction)	ACTION_PARSE_REF(FL2CFriendBookNotiReactionRemoved, InAction)

#define ACTION_PARSE_FriendBookGetTimeline(InAction)		ACTION_PARSE_REF(FL2CFriendBookGetTimelineResp, InAction);
#define ACTION_PARSE_FriendBookAddReaction(InAction)		ACTION_PARSE_ONE(FC2LFriendBookAddReaction, InAction);
#define ACTION_PARSE_FriendBookRemoveReaction(InAction)		ACTION_PARSE_ONE(FC2LFriendBookRemoveReaction, InAction);
#define ACTION_PARSE_FriendBookGetFeed(InAction)			ACTION_PARSE_REF(FL2CFriendBookGetFeedResp, InAction);
#define ACTION_PARSE_FriendBookNewFeedFromFile(InAction)	ACTION_PARSE_TWO(FFriendBookFeedId, FFriendBookFeedId, InAction);

//// End of Packet
//////////////////////////////////////////////////////////////////////////////

// Cheat
#define ACTION_PARSE_DevAddCurrencyResp(InAction)				ACTION_PARSE_REF(FL2CDevAddCurrencyResp, InAction)
#define ACTION_PARSE_DevAddXpResp(InAction)						ACTION_PARSE_REF(FL2CDevAddXpResp, InAction)
#define ACTION_PARSE_DevBondAddResp(InAction)					ACTION_PARSE_REF(FL2CDevBondAddResp, InAction)
#define ACTION_PARSE_DevCharacterNewResp(InAction)				ACTION_PARSE_REF(FL2CDevCharacterNewResp, InAction)
#define ACTION_PARSE_DevRelicNewResp(InAction)					ACTION_PARSE_REF(FL2CDevRelicNewResp, InAction)
#define ACTION_PARSE_DevSculptureNewResp(InAction)				ACTION_PARSE_REF(FL2CDevSculptureNewResp, InAction)
#define ACTION_PARSE_DevSpecialClearResp(InAction)				ACTION_PARSE_REF(FL2CDevSpecialClearResp, InAction)
#define ACTION_PARSE_DevSpecialOpenResp(InAction)				ACTION_PARSE_REF(FL2CDevSpecialOpenResp, InAction)
#define ACTION_PARSE_DevStageClearResp(InAction)				ACTION_PARSE_REF(FL2CDevStageClearResp, InAction)
#define ACTION_PARSE_DevWattRechargeResp(InAction)				ACTION_PARSE_REF(FL2CDevWattRechargeResp, InAction)
#define ACTION_PARSE_DevWattConsumeResp(InAction)				ACTION_PARSE_REF(FL2CDevWattConsumeResp, InAction)
#define ACTION_PARSE_DevTrainingCenterClearResp(InAction)		ACTION_PARSE_REF(FL2CDevTrainingCenterClearResp, InAction)
#define ACTION_PARSE_DevTrainingCenterResetResp(InAction)		ACTION_PARSE_REF(FL2CDevTrainingCenterResetResp, InAction)
#define ACTION_PARSE_DevPyramidOpenResp(InAction)				ACTION_PARSE_REF(FL2CDevPyramidOpenResp, InAction)
#define ACTION_PARSE_DevPyramidUpgradeResp(InAction)			ACTION_PARSE_REF(FL2CDevPyramidUpgradeResp, InAction)
#define ACTION_PARSE_DevPyramidPortalBoostUseResp(InAction)		ACTION_PARSE_REF(FL2CDevPortalBoostUseResp, InAction)
#define ACTION_PARSE_DevPyramidPortalClearResp(InAction)		ACTION_PARSE_REF(FL2CDevPortalClearResp, InAction)
#define ACTION_PARSE_DevTempleOpenResp(InAction)				ACTION_PARSE_REF(FL2CDevTempleOpenResp, InAction)
#define ACTION_PARSE_DevTempleProduceResp(InAction)				ACTION_PARSE_REF(FL2CDevTempleProduceResp, InAction)
#define ACTION_PARSE_DevTempleArtifactsResetResp(InAction)		ACTION_PARSE_REF(FL2CDevTempleArtifactsResetResp, InAction)
#define ACTION_PARSE_DevTempleArtifactUpgradeResp(InAction)		ACTION_PARSE_REF(FL2CDevTempleArtifactUpgradeResp, InAction)
#define ACTION_PARSE_DevPowerPlantOpenResp(InAction)			ACTION_PARSE_REF(FL2CDevPowerPlantOpenResp, InAction)
#define ACTION_PARSE_DevPetParkOpenResp(InAction)				ACTION_PARSE_REF(FL2CDevPetParkOpenResp, InAction)
#define ACTION_PARSE_DevPetParkProduceResp(InAction)			ACTION_PARSE_REF(FL2CDevPetParkProduceResp, InAction)
#define ACTION_PARSE_DevPetSkillUpgradeResp(InAction)			ACTION_PARSE_REF(FL2CDevPetSkillUpgradeResp, InAction)
#define ACTION_PARSE_DevPetNewResp(InAction)					ACTION_PARSE_REF(FL2CDevPetNewResp, InAction)
#define ACTION_PARSE_DevVacationOpenResp(InAction)				ACTION_PARSE_REF(FL2CDevVacationOpenResp, InAction)
#define ACTION_PARSE_DevCheckInLoadResp(InAction)				ACTION_PARSE_REF(FL2CDevCheckInLoadResp, InAction)
#define ACTION_PARSE_DevShopResetResp(InAction)					ACTION_PARSE_REF(FL2CDevShopResetResp, InAction)
#define ACTION_PARSE_DevSummonMileageSetResp(InAction)			ACTION_PARSE_REF(FL2CDevSummonMileageSetResp, InAction)
#define ACTION_PARSE_DevLobbyTemplateNewResp(InAction)			ACTION_PARSE_REF(FL2CDevLobbyTemplateNewResp, InAction)
#define ACTION_PARSE_DevFriendBotAllResp(InAction)				ACTION_PARSE_REF(FL2CDevFriendBotAllResp, InAction)
#define ACTION_PARSE_DevFriendCooltimeResp(InAction)			ACTION_PARSE_REF(FL2CDevFriendCooltimeResp, InAction)
#define ACTION_PARSE_DevCharMissionSetResp(InAction)			ACTION_PARSE_REF(FL2CDevCharMissionSetResp, InAction)
#define ACTION_PARSE_DevContentFeatureOpenResp(InAction)		ACTION_PARSE_REF(FL2CDevContentFeatureOpenResp, InAction)
#define ACTION_PARSE_DevEventContentNumberOfDaysResp(InAction)	ACTION_PARSE_REF(FL2CDevEventContentNumberOfDaysResp, InAction)
#define ACTION_PARSE_DevEventContentAddPointResp(InAction)		ACTION_PARSE_REF(FL2CDevEventContentAddPointResp, InAction)
#define ACTION_PARSE_DevEventContentRechargeWattResp(InAction)	ACTION_PARSE_REF(FL2CDevEventContentRechargeWattResp, InAction)
#define ACTION_PARSE_DevEventContentRouletteResetResp(InAction)	ACTION_PARSE_REF(FL2CDevEventContentRouletteResetResp, InAction)
#define ACTION_PARSE_DevSmelterOpenResp(InAction)				ACTION_PARSE_REF(FL2CDevSmelterOpenResp, InAction)
#define ACTION_PARSE_DevSmelterUpgradeResp(InAction)			ACTION_PARSE_REF(FL2CDevSmelterUpgradeResp, InAction)
#define ACTION_PARSE_DevSmelterTimeResp(InAction)				ACTION_PARSE_REF(FL2CDevSmelterTimeResp, InAction)
#define ACTION_PARSE_DevAlchemylabOpenResp(InAction)			ACTION_PARSE_REF(FL2CDevAlchemylabOpenResp, InAction)
#define ACTION_PARSE_DevAlchemylabUpgradeResp(InAction)			ACTION_PARSE_REF(FL2CDevAlchemylabUpgradeResp, InAction)
#define ACTION_PARSE_DevAlchemylabTimeResp(InAction)			ACTION_PARSE_REF(FL2CDevAlchemylabTimeResp, InAction)
#define ACTION_PARSE_DevClockModResp(InAction)					ACTION_PARSE_REF(FL2CDevClockModResp, InAction)
#define ACTION_PARSE_DevAvatarAddResp(InAction)					ACTION_PARSE_REF(FL2CDevAvatarAddResp, InAction)
//////////////////////////////////////////////////////////////////////////////
//// UI

// Menu
#define ACTION_PARSE_MenuChange(InAction)						ACTION_PARSE_TWO(EHUDWidgetType, bool, InAction)
#define ACTION_PARSE_MenuBack(InAction)							ACTION_PARSE(InAction)
#define ACTION_PARSE_MenuDoubleBack(InAction)					ACTION_PARSE(InAction)

// Upgrade
#define ACTION_PARSE_UpgradeMenu(InAction)						ACTION_PARSE_ONE(FUpgradeUIState, InAction)
#define ACTION_PARSE_UpgradeInventory(InAction)					ACTION_PARSE_ONE(EUpgradeCategory, InAction)
#define ACTION_PARSE_UpgradeCategory(InAction)					ACTION_PARSE_ONE(int32, InAction)
#define ACTION_PARSE_UpgradeItem(InAction)						ACTION_PARSE_ONE(int64, InAction)

// Friend
#define ACTION_PARSE_FriendCategoryChange(InAction)				ACTION_PARSE_ONE(EFriendCategory, InAction)
#define ACTION_PARSE_FriendReorder(InAction)					ACTION_PARSE_TWO(ESortCategory, ESortDirection, InAction)
#define ACTION_PARSE_FriendBookFilterChange(InAction)			ACTION_PARSE_ONE(EFriendBookFilter, InAction)

// Party
#define ACTION_PARSE_PartyMain(InAction)						ACTION_PARSE_ONE(FSagaType, InAction)
#define ACTION_PARSE_PartyChange(InAction)						ACTION_PARSE_ONE(int32, InAction)
#define ACTION_PARSE_PartyEdit(InAction)						ACTION_PARSE_TWO(EPartyIconItemType, int32, InAction)
#define ACTION_PARSE_PartyEventContentType(InAction)			ACTION_PARSE_ONE(FEventContentType, InAction)

// JokerSet
#define ACTION_PARSE_JokerSetMain(InAction)						ACTION_PARSE_ONE(int32, InAction)
#define ACTION_PARSE_JokerSetChange(InAction)					ACTION_PARSE_ONE(int32, InAction)
#define ACTION_PARSE_JokerSetEdit(InAction)						ACTION_PARSE_TWO(EPartyIconItemType, int32, InAction)

// JokerSelect
#define ACTION_PARSE_JokerSelect(InAction)						ACTION_PARSE_TWO(FSagaType, bool, InAction)

// Saga
#define ACTION_PARSE_SagaStageList(InAction)					ACTION_PARSE_ONE(int32, InAction)

// Special
#define ACTION_PARSE_SpecialOpen(InAction)						ACTION_PARSE_ONE(FSpecialUIState, InAction)
#define ACTION_PARSE_SpecialEpisodeList(InAction)				ACTION_PARSE_ONE(ESpecialCategory, InAction)
#define ACTION_PARSE_SpecialCharacterStageList(InAction)		ACTION_PARSE_ONE(FSpecialType, InAction)
#define ACTION_PARSE_SpecialWonderStageList(InAction)			ACTION_PARSE_ONE(EWonderCategory, InAction)

// DailyDungeon
#define ACTION_PARSE_DailyDungeonStageList(InAction)			ACTION_PARSE_ONE(EDailyDungeonCategory, InAction)
#define ACTION_PARSE_DailyDungeonPageChange(InAction)			ACTION_PARSE_ONE(EDailyDungeonMenuType, InAction)

// TrainingCenter
#define ACTION_PARSE_TrainingCenterOpen(InAction)				ACTION_PARSE(InAction)

// Summon
#define ACTION_PARSE_SummonPageChange(InAction)					ACTION_PARSE_ONE(int32, InAction)
#define ACTION_PARSE_SummonFriendShip(InAction)					ACTION_PARSE(InAction)

// InitialRewardEvent
#define ACTION_PARSE_InitialRewardEventOpen(InAction)			ACTION_PARSE_ONE(FInitialRewardEventUIState, InAction)

// Wonder
#define ACTION_PARSE_WonderMenu(InAction)						ACTION_PARSE_TWO(EWonderCategory, int32, InAction)
#define ACTION_PARSE_WonderSlotSelect(InAction)					ACTION_PARSE_ONE(int32, InAction)

// Raid
#define ACTION_PARSE_RaidOpen(InAction)							ACTION_PARSE(InAction)
#define ACTION_PARSE_UpdateRaidWhenEnterMenu(InAction)			ACTION_PARSE(InAction)
#define ACTION_PARSE_RaidPrepareTime(InAction)					ACTION_PARSE(InAction)
#define ACTION_PARSE_SetOnGoingRaid(InAction)					ACTION_PARSE_TWO(FRaidType, FRaidId, InAction)
#define ACTION_PARSE_RaidClearData(InAction)					ACTION_PARSE(InAction)
#define ACTION_PARSE_MuteRaidJoinPopup(InAction)				ACTION_PARSE(InAction)
#define ACTION_PARSE_RaidSelectFinal(InAction)					ACTION_PARSE_TWO(FRaidType, FRaidId, InAction)
#define ACTION_PARSE_RaidClearFoundType(InAction)				ACTION_PARSE(InAction)
#define ACTION_PARSE_RaidClearSkills(InAction)					ACTION_PARSE(InAction)
#define ACTION_PARSE_RaidCharInfos(InAction)					ACTION_PARSE_REF(TArray<FRaidUserCharacterInfo>, InAction)
#define ACTION_PARSE_RaidSetSkills(InAction)					ACTION_PARSE_TWO_REF(TArray<FCCRaidSkillState>, TArray<FCCUsedCharSkillInfo>, InAction)

// Inventory
#define ACTION_PARSE_InventoryOpen(InAction)					ACTION_PARSE_ONE(EInventoryCategory, InAction)
#define ACTION_PARSE_InventoryChange(InAction)					ACTION_PARSE_ONE(EInventoryType, InAction)
#define ACTION_PARSE_InventoryEdit(InAction)					ACTION_PARSE_ONE(EInventoryEdit, InAction)

// Mail
#define ACTION_PARSE_MailSelect(InAction)					ACTION_PARSE(InAction)

// CheckIn
#define ACTION_PARSE_CheckInClear(InAction)					ACTION_PARSE(InAction)

// Codex
#define ACTION_PARSE_CodexCategoryChange(InAction)				ACTION_PARSE_ONE(ECodexCategory, InAction)
#define ACTION_PARSE_CodexCharClearNew(InAction)				ACTION_PARSE_ONE(FCharacterType, InAction)
#define ACTION_PARSE_CodexSculptureClearNew(InAction)			ACTION_PARSE_ONE(FSculptureType, InAction)
#define ACTION_PARSE_CodexRelicClearNew(InAction)				ACTION_PARSE_ONE(FRelicType, InAction)
#define ACTION_PARSE_CodexEquipFullView(InAction)				ACTION_PARSE_ONE(bool, InAction)

// WeeklyMission
#define ACTION_PARSE_WeeklyMissionToast(InAction)				ACTION_PARSE_ONE(TArray<FWeeklyMissionToastInfo>, InAction)

// Sort
#define ACTION_PARSE_SortingChange(InAction)					ACTION_PARSE_ONE(FSortingOption, InAction)

// Shop
#define ACTION_PARSE_ShopMenuChange(InAction)					ACTION_PARSE_TWO(EShopMenu, bool, InAction)

// LobbySetting
#define ACTION_PARSE_LobbySettingEditChange(InAction)			ACTION_PARSE_ONE(ELobbySettingEditType, InAction)

// Bag
#define ACTION_PARSE_BagItemSort(InAction)						ACTION_PARSE(InAction)

// Event
#define ACTION_PARSE_EventMenuChange(InAction)					ACTION_PARSE_TWO(EEventMenu, FEventContentType, InAction)

// Multiside
#define ACTION_PARSE_MultisidePetSave(InAction)					ACTION_PARSE_ONE(FPetId, InAction)
#define ACTION_PARSE_MultisidePartySave(InAction)				ACTION_PARSE(InAction)

// Story
#define ACTION_PARSE_StoryList(InAction)						ACTION_PARSE_ONE(EStoryMenuCategory, InAction)

//// End of UI
//////////////////////////////////////////////////////////////////////////////
