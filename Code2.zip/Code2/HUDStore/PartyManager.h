#pragma once

#include "CMSType_gen.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "PartyManager.generated.h"

static const int32 MAX_PARTY_MEMBER = 6;
static const int32 MAX_MAIN_PARTY_MEMBER = 2;
static const int32 MAX_SUB_PARTY_MEMBER = 3;

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FCharacterId;
struct FSculptureId;

enum class EPartyIconItemType : uint8;

///////////////////////////////////////////////////////////////////////////////////////////
// UPartyManager

UCLASS()
class Q6_API UPartyManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:

	UPartyManager();

	const FPartyInfo& GetPartyInfo(int32 PartyId) const;
	TArray<FCharacterId> GetCharactersInParty() const;
	TArray<FSculptureId> GetSculpturesInParty() const;
	TArray<FRelicId> GetRelicsInParty() const;
	bool ExistsInParty(EPartyIconItemType InCategory, EItemGrade InGrade) const;

	bool IsValidParty(int32 PartyId) const;

	EJokerType GetJokerType() const { return JokerType; }
	EJokerSlotType GetJokerSlotType() const { return JokerSlot; }
	const FCharacterInfo& GetSystemJokerInfo() const { return SystemJokerInfo; }
	const FFriendInfo& GetFriendJokerInfo() const { return FriendJokerInfo; }
	const FFriendJokerSlot& GetFriendJokerSlot() const
	{
		const auto& FriendJokerSet = FriendJokerInfo.JokerSet;
		check(FriendJokerSet.Slots.Num() == EJokerSlotTypeMax);
		const auto& FriendJokerSlot = FriendJokerSet.Slots[static_cast<int32>(JokerSlot)];
		return FriendJokerSlot;
	}
	const FCharacterInfo& GetRandomJokerInfo() const { return RandomJokerInfo; }
	const FPartySlot& GetOwnedJokerSlot() const { return OwnedJokerSlot; }

#if !UE_BUILD_SHIPPING
	bool CanJokerEdit() const;
#endif

	void Dump() const;

	// Req
	void ReqPartyList() const;
	void ReqPartySave(const FPartyInfo& InPartyInfo, const FPartySlot& InJokerSlot) const;
	void ReqCharacterSave(int32 PartyId, const TArray<FCharacterId>& Characters) const;
	void ReqRelicSave(int32 PartyId, const TArray<FRelicId>& Relics) const;
	void ReqSculptureSave(int32 PartyId, const TArray<FSculptureId>& Sculptures) const;
	void ReqPartyPetSave(int32 PartyId, const FPetId& PetId) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Action handler
	DECLARE_ACTION_HANDLER(SystemJoker);
	DECLARE_ACTION_HANDLER(RandomJoker);
	DECLARE_ACTION_HANDLER(FriendJoker);
	DECLARE_ACTION_HANDLER(FriendJokerFromPopup);
	DECLARE_ACTION_HANDLER(OwnedJoker);
	DECLARE_ACTION_HANDLER(MenuChange);
	DECLARE_ACTION_HANDLER(PartyLoadResp);
	DECLARE_ACTION_HANDLER(PartySaveResp);
	DECLARE_ACTION_HANDLER(PetLoadResp);	// QSIX-3268: test code
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DevPetParkOpenResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);

	FPartyInfo* Find(int32 Id);
	void Update(const FPartyInfo& InParty);

	void SetSystemJoker(const FCharacterInfo& InJokerInfo);
	void SetFriendJoker(const FFriendInfo& InFriendInfo, EJokerSlotType InJokerSlot);
	void SetRandomJoker(const FCharacterInfo& InJokerInfo);
	void SetOwnedJoker(const FPartySlot& InOwnedJokerSlot);

	void ClearForOwnedJokerSet();

	bool GetPartySlotGrade(const FPartySlot& InPartySlot, EPartyIconItemType InCategory, EItemGrade* OutGrade) const;

	// Res
	void OnPartyLoadResp(const FResError* Error, const FL2CPartyLoadResp& Res);
	void OnPartySaveResp(const FResError* Error, const FL2CPartySaveResp& Res);

	TArray<FPartyInfo> PartyList;
	EJokerType JokerType;
	EJokerSlotType JokerSlot;
	FCharacterInfo SystemJokerInfo;
	FCharacterInfo RandomJokerInfo;
	FFriendInfo FriendJokerInfo;
	FPartySlot OwnedJokerSlot;
};
