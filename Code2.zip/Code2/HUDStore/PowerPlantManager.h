#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"

#include "PowerPlantManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UPowerPlantManager

UCLASS()
class Q6_API UPowerPlantManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UPowerPlantManager();

	void ReqLoad() const;
	void ReqUpgrade() const;
	void ReqUpgradeComplete() const;
	void ReqStore(int32 StoreCount) const;
	void ReqRecharge(int32 RechargeCount) const;

#if !UE_BUILD_SHIPPING
	void ReqDevUpgrade(int32 TargetLevel) const;
#endif

	const FPowerPlantInfo& GetPowerPlant() const { return PowerPlantInfo; }

protected:
	virtual void RegisterActionHandlers() override;

private:
	void OnLoadResp(const FResError* Error, const FL2CPowerPlantLoadResp& Msg);
	void OnUpgradeResp(const FResError* Error, const FL2CPowerPlantUpgradeResp& Msg);
	void OnUpgradeCompleteResp(const FResError* Error, const FL2CPowerPlantUpgradeCompleteResp& Msg);
	void OnStoreResp(const FResError* Error, const FL2CPowerPlantStoreResp& Msg);
	void OnRechargeResp(const FResError* Error, const FL2CPowerPlantRechargeResp& Msg);

	DECLARE_ACTION_HANDLER(PowerPlantLoadResp);
	DECLARE_ACTION_HANDLER(PowerPlantUpgradeResp);
	DECLARE_ACTION_HANDLER(PowerPlantUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(PowerPlantStoreResp);
	DECLARE_ACTION_HANDLER(PowerPlantRechargeResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DevPowerPlantOpenResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);

	UPROPERTY()
	FPowerPlantInfo PowerPlantInfo;
};
