#pragma once

#include "Q6ClientNetwork.h"
#include "Q6GameState.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "RaidManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FRaidId;
struct FRaidFinalInfo;
struct FRewardInfo;
struct FCCUsedCharSkillInfo;
struct FCCRaidSkillState;
struct FCombatMissionInfo;
struct FRaidSkillUsedElement;

class UCCEndGameEvent;
class FRaidPush;

///////////////////////////////////////////////////////////////////////////////////////////
// FActRecord

USTRUCT()
struct FRaidParticipateUserInfo
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	FRaidId RaidId;

	UPROPERTY()
	FUserId UserId;

	UPROPERTY()
	FString UserName;

	UPROPERTY()
	int32 Score;

	UPROPERTY()
	bool End;

	UPROPERTY()
	int32 TurnCount;

	UPROPERTY()
	TArray<FCharHealth> Healths;
};

USTRUCT()
struct FRegularRaidState
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	FRaidType RaidType;

	UPROPERTY()
	int32 ScheduleId;

	UPROPERTY()
	FRaidId RaidId;

	UPROPERTY()
	bool Registered;

	UPROPERTY()
	bool Matched;

	UPROPERTY()
	bool WaitForReqReady;

	UPROPERTY()
	bool RespReady;
};

USTRUCT()
struct FTodayRaidClearInfo
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	FDateTime Date;

	UPROPERTY()
	bool TodayRaidClear;
};

class Q6_API FRaidFinal
{
public:
	FRaidFinal(const FRaidFinalInfo& InInfo)
		: Info(InInfo)
	{}

	const FRaidFinalInfo& GetInfo() const { return Info; }

	bool GetRaidEnded() const { return Info.End; }

private:
	FRaidFinalInfo Info;
};

///////////////////////////////////////////////////////////////////////////////////////////
// RaidManager

const float RAID_REQ_TIMEOUT = 5.f;

// Gunny HardCode.
const float RAID_JOIN_POPUP_MUTE_TIME = 300.f;

UCLASS()
class Q6_API URaidManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	URaidManager();
	~URaidManager();

	void InitPushHandler();

	static bool IsRaidResult(EContentType type) {
		return (type == EContentType::Raid || type == EContentType::RaidFinal);
	}

	// Req
	void ReqList() const;
	void ReqOpen() const; // api request
	void ReqPrepare() const;
	void ReqEnter() const;
	void ReqStageEnd(const UCCEndGameEvent* Event
		, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const;
	void ReqOngoingStageEnd(const FSagaType& NotFinishedSagaType) const;
	void ReqSkillUsed(const TArray<FRaidSkillUsedElement>& Elements, const int32 Damage) const;
	void ReqUseEmoticon(int32 Emoticon) const;
	void ReqRaidFinalStageBegin() const;
	void ReqRaidFinalStageEnd(const UCCEndGameEvent* Event, const FString& Chronicle) const;
	void ReqShareParty(TArray<FRaidUserCharacterInfo>& CharInfos) const;
	void ReqRegularRaidRegister(const FRegularRaidInfo& Info) const;
	void ReqRegularRaidReady(const FRegularRaidInfo& Info) const;

#if !UE_BUILD_SHIPPING
	void ReqDevOpen(FRaidType Type) const; // cheat
	void ReqDevEnter() const;
	void ReqDevRaidFinalStageBegin() const;
#endif

	void OnRaidOpenNof(const FL2CRaidOpenNof& Nof);
	void OnRaidCanEnterNof(const FL2CRaidCanEnterNof& Nof);
	void OnRaidCanEnterResp(const FResError* Error, const FL2CRaidCanEnterNof& Nof);
	void OnRaidEnterNof(const FResError* Error, const FL2CRaidEnterNof& Nof);
	void OnRaidStageEndResp(const FResError* Error, const FL2CRaidStageEndResp& Res);
	void OnRaidStageEndNof(const FL2CRaidStageEndNof& Nof);
	void OnRaidEndNof(const FL2CRaidEndNof& Nof);
	void OnRaidSkillUsedResp(const FResError* Error, const FL2CRaidSkillUsedResp& Res);
	void OnRaidSkillsNof(const FResError* Error, const FL2CRaidSkillsNof& Nof);
	void OnRaidBossHealthNof(const FL2CRaidBossHealthNof& Nof);
	void OnRaidEmoticonNof(const FL2CRaidEmoticonNof& Nof);
	void OnRaidFinalStageBeginResp(const FResError* Error, const FL2CRaidFinalStageBeginResp& Res);
	void OnRaidFinalStageEndResp(const FResError* Error, const FL2CRaidFinalStageEndResp& Res);
	void OnRaidPrepareResp(const FResError* Error, const FL2CRaidPrepareResp& Res);
	void OnRaidUseEmoticonResp(const FResError* Error, const FL2CRaidEmoticonNof& Res);
	void OnRaidSharePartyResp(const FResError* Error, const FL2CRaidSharePartyResp& Res);
	void OnRaidSharePartyNof(const FL2CRaidSharePartyNof& Nof);
	void OnRaidFullNof(const FL2CRaidFullNof& Nof);
	void OnRaidKickTimeoutNof(const FL2CRaidKickTimeoutNof& Nof);
	void OnRegularRaidRegisterResp(const FResError* Error, const FL2CRegularRaidRegisterResp& Res);
	void OnRegularRaidReadyResp(const FResError* Error, const FL2CRegularRaidReadyResp& Res);
	void OnRegularRaidMatchedNoti(const FL2CRegularRaidNotiMatched& Res);

	virtual void Tick(float DeltaTime) override;

	TArray<FCharSkill> GetRaidTurnSkills() const;
	TArray<FCharSkill> GetRaidSupportSkills() const;
	int32 GetSurviveCharCount() const;

	FRaidType GetOpenRaidType() const { return OpenRaidType; }
	FRaidId GetOpenRaidId() const { return OpenRaidId; }
	float GetPrepareTime() const { return PrepareTimeout; }
	FRaidId GetClearedRaidId() const { return ClearedRaidId; }
	const TArray<FRaidRankingInfo>& GetRaidRankingInfos() const { return RaidRankingInfos; }
	const TArray<FRaidRankInfo>& GetRaidRealTimeRankInfos() const { return RaidRealTimeRankInfos; }
	FRaidType GetFoundRaidType() const { return FoundRaidType; }
	int32 GetTotalDamage() const { return TotalDamage; }
	bool IsRaidFound() const;
	FRaidId GetSelectedRaidFinalId() const { return SelectedRaidFinalId; }
	FRaidType GetTodayRaidType() const { return TodayRaidType; }
	FRaidType GetRegularRaidType() const { return RegularRaidState.RaidType; }
	const FRegularRaidState& GetRegularRaidState() const { return RegularRaidState; }
	int64 GetRaidStartUtcByRaidId(const FRaidId& RaidId) const;

	const TMap<FRaidId, FRaidFinal>& GetRaidFinals() const { return RaidFinals; }
	const FRaidFinal* Find(const FRaidId& Id) const { return RaidFinals.Find(Id); }
	bool IsRaidListFull() const;
	bool IsTodayRaidClear() const { return TodayRaidClearInfo.TodayRaidClear; }

	const TArray<FRaidParticipateUserInfo> GetRaidUserInfos() const;

protected:
	virtual void RegisterActionHandlers() override;

	void SetRaidSupportSkillsInfo(const TArray<FCCRaidSkillState>& InSupportSkillsHas
		, const TArray<FCCUsedCharSkillInfo>& InSupportSkillsUse);
	void SetFoundRaidType(const FRaidType& InFoundRaidType) { FoundRaidType = InFoundRaidType; }
	void SetSelectedRaidFinal(const FRaidType& Type, const FRaidId& Id);
	void InitUserCharInfo();
	void ClearRaidSkills();

private:
	DECLARE_ACTION_HANDLER(RaidListResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidStageEndNof);
	DECLARE_ACTION_HANDLER(RaidFullNof);
	DECLARE_ACTION_HANDLER(RaidKickTimeoutNof);
	DECLARE_ACTION_HANDLER(RaidReqTimeout);
	DECLARE_ACTION_HANDLER(RaidOpenNof);
	DECLARE_ACTION_HANDLER(RaidCanEnterNof);
	DECLARE_ACTION_HANDLER(RaidPrepareResp);
	DECLARE_ACTION_HANDLER(RaidOpenNofTimeout);
	DECLARE_ACTION_HANDLER(RaidReadyTimeout);
	DECLARE_ACTION_HANDLER(RaidPrepareTimeout);
	DECLARE_ACTION_HANDLER(RaidEnterNofTimeout);
	DECLARE_ACTION_HANDLER(RaidEnterNof);
	DECLARE_ACTION_HANDLER(RaidSkillUsedResp);
	DECLARE_ACTION_HANDLER(RaidSkillsNof);
	DECLARE_ACTION_HANDLER(RaidEndNof);
	DECLARE_ACTION_HANDLER(RaidBossHealthNof);
	DECLARE_ACTION_HANDLER(RaidEmoticonNof);
	DECLARE_ACTION_HANDLER(RaidSharePartyResp);
	DECLARE_ACTION_HANDLER(RaidSharePartyNof);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(RaidClearData);
	DECLARE_ACTION_HANDLER(MuteRaidJoinPopup);
	DECLARE_ACTION_HANDLER(RaidSelectFinal);
	DECLARE_ACTION_HANDLER(RaidClearFoundType);
	DECLARE_ACTION_HANDLER(RaidClearSkills);
	DECLARE_ACTION_HANDLER(RaidCharInfos);
	DECLARE_ACTION_HANDLER(RaidSetSkills);
	DECLARE_ACTION_HANDLER(RegularRaidRegisterResp);
	DECLARE_ACTION_HANDLER(RegularRaidReadyResp);
	DECLARE_ACTION_HANDLER(RegularRaidMatchedNoti);

	DECLARE_ACTION_HANDLER(SetOnGoingRaid);
	DECLARE_ACTION_HANDLER(UpdateRaidWhenEnterMenu);
	DECLARE_ACTION_HANDLER(RaidPrepareTime);

	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);

	void OnListResp(const FResError* Error, const FL2CRaidListResp& Res);

	void AddRaidFinal(const FRaidFinalInfo& Info);
	void RemoveRaidFinal(FRaidId Id);

	void UpdateRaidUserInfos(const FRaidId& RaidId, const FRaidUserInfo& UserInfo);

	void SortRaidFinalList() { RaidFinals.KeySort([](const FRaidId& Left, const FRaidId& Right) { return Left.S > Right.S; }); }

	void ResetRaid();
	void ResetRegularRaidState();
	void ResetTodayRaidClear();
	void CheckRegularRaidOpen();

	bool IsValidRaid() const;
	void ExpireReq(float DeltaTime);
	void ExpireReady(float DeltaTime);
	void ExpirePrepare(float DeltaTime);

	void OpenRaidJoinPopup(FRaidType RaidType);

	TArray<FCharHealth> GetCharHealthByUserCharInfo(const TArray<FRaidUserCharacterInfo>& InUserCharInfos) const;

	bool SetOngoingStageEndInfoByChronicle(const FString& OngoingChronicle, FC2LRaidStageEnd& Out) const;

	void ChangeJokerSelectHUDWidget(const FRaidType RaidType);

	int64 GetRaidEnemyTotalHealth(const FRaidType RaidType) const;

	float ReqTimeout; // request may timeout if not get notification until this time
	float ReadyTimeout;
	float PrepareTimeout;
	float RaidLeftSec;
	float RaidJoinPopupMuteElapsedTime;
	float RegularRaidTick;

	bool bMutePopup;

	FRaidType OpenRaidType;
	FRaidId OpenRaidId;
	FRaidType SelectedRaidFinalType;
	FRaidId SelectedRaidFinalId;
	int32 TotalDamage;
	FRaidType FoundRaidType;

	FRegularRaidState RegularRaidState;

	FRaidId ClearedRaidId;

	TArray<FCharSkill> Skills;
	TArray<FCharSkill> SupportSkills;

	TArray<FCharSkill> SupportSkillsHas;
	TArray<FCharSkill> SupportSkillsUse;

	TMap<FRaidId, FRaidFinal> RaidFinals;

	TArray<FRaidRankingInfo> RaidRankingInfos;
	TArray<FRaidRankInfo> RaidRealTimeRankInfos;

	TMap<FUserId, FRaidParticipateUserInfo> RaidUserInfos;
	TArray<FRaidUserCharacterInfo> UserCharInfos;

	FRaidType TodayRaidType;
	FTodayRaidClearInfo TodayRaidClearInfo;

	FRaidPush* PushInstance;
};
