#include "PartyManager.h"

#include "HSAction.h"
#include "HUDStore/CharacterManager.h"
#include "HUDStore/SculptureManager.h"
#include "HUDStore/RelicManager.h"
#include "HUDStore/HUDStore.h"
#include "LobbyHUD.h"
#include "PetManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6UIDefine.h"
#include "Q6GameInstance.h"
#include "GameResource.h"

static TAutoConsoleVariable<int32> CVarQ6JokerSlotEdit(
	TEXT("q6.jokerSlotEdit"),
	0,
	TEXT("0: joker slot can't be edit. 1: can be edit."),
	ECVF_Default);

///////////////////////////////////////////////////////////////////////////////////////////
// UPartyManager

UPartyManager::UPartyManager()
	: JokerType(EJokerType::SystemJoker)
	, JokerSlot(EJokerSlotType::All)
{
	InitStore(EHSType::Party);
}

void UPartyManager::SetSystemJoker(const FCharacterInfo& InJokerInfo)
{
	JokerType = EJokerType::SystemJoker;
	SystemJokerInfo = InJokerInfo;
	GameInstance->SetSystemJoker(SystemJokerInfo.Type);
}

void UPartyManager::SetFriendJoker(const FFriendInfo& InFriendInfo, EJokerSlotType InJokerSlot)
{
	JokerType = EJokerType::FriendJoker;
	FriendJokerInfo = InFriendInfo;
	JokerSlot = InJokerSlot;
	GameInstance->SetFriendJoker(FriendJokerInfo, JokerSlot);
}

void UPartyManager::SetRandomJoker(const FCharacterInfo& InJokerInfo)
{
	JokerType = EJokerType::RandomJoker;
	RandomJokerInfo = InJokerInfo;
	GameInstance->SetRandomJoker(RandomJokerInfo.Type);
}

void UPartyManager::SetOwnedJoker(const FPartySlot& InOwnedJokerSlot)
{
	JokerType = EJokerType::OwnedJoker;
	OwnedJokerSlot = InOwnedJokerSlot;
	GameInstance->SetOwnedJoker(OwnedJokerSlot);
}

void UPartyManager::ClearForOwnedJokerSet()
{
	JokerType = EJokerType::OwnedJoker;
	OwnedJokerSlot = FPartySlot();
	GameInstance->ClearJoker();
}

const FPartyInfo& UPartyManager::GetPartyInfo(int32 PartyId) const
{
	for (const FPartyInfo& PartyInfo : PartyList)
	{
		if (PartyInfo.PartyId == PartyId)
		{
			return PartyInfo;
		}
	}

	static FPartyInfo DummyPartyInfo;
	DummyPartyInfo.PartyId = PartyId;
	DummyPartyInfo.Main.SetNumZeroed(MAX_MAIN_PARTY_MEMBER);
	DummyPartyInfo.Sub.SetNumZeroed(MAX_SUB_PARTY_MEMBER);
	DummyPartyInfo.PetId = FPetId::InvalidValue();

	return DummyPartyInfo;
}

void DumpPartyInfo(const FPartyInfo& PartyInfo)
{
	Q6JsonLog(Warning, "", Q6KV("Id", PartyInfo.PartyId));
	Q6JsonLog(Warning, "", Q6KV("PetId", PartyInfo.PetId));

	for (const FPartySlot& Slot : PartyInfo.Main)
	{
		Q6JsonLog(Warning, "",
			Q6KV("CharacterId", Slot.CharacterId),
			Q6KV("RelicId", Slot.RelicId),
			Q6KV("SculptureId", Slot.SculptureId));
	}
	for (const FPartySlot& Slot : PartyInfo.Sub)
	{
		Q6JsonLog(Warning, "",
			Q6KV("CharacterId", Slot.CharacterId),
			Q6KV("RelicId", Slot.RelicId),
			Q6KV("SculptureId", Slot.SculptureId));
	}
}

void UPartyManager::Dump() const
{
	Q6JsonLog(Warning, "Dump Parties");
	for (const FPartyInfo& PartyInfo : PartyList)
	{
		DumpPartyInfo(PartyInfo);
	}
}

TArray<FCharacterId> UPartyManager::GetCharactersInParty() const
{
	TArray<FCharacterId> PartyCharacters;
	for (const FPartyInfo& PartyInfo : PartyList)
	{
		for (const FPartySlot& PartySlot : PartyInfo.Main)
		{
			if (!PartySlot.CharacterId.IsInvalid())
			{
				PartyCharacters.AddUnique(PartySlot.CharacterId);
			}
		}

		for (const FPartySlot& PartySlot : PartyInfo.Sub)
		{
			if (!PartySlot.CharacterId.IsInvalid())
			{
				PartyCharacters.AddUnique(PartySlot.CharacterId);
			}
		}
	}

	return PartyCharacters;
}

TArray<FSculptureId> UPartyManager::GetSculpturesInParty() const
{
	TArray<FSculptureId> PartySculptures;
	for (const FPartyInfo& PartyInfo : PartyList)
	{
		for (const FPartySlot& PartySlot : PartyInfo.Main)
		{
			if (!PartySlot.SculptureId.IsInvalid())
			{
				PartySculptures.AddUnique(PartySlot.SculptureId);
			}
		}

		for (const FPartySlot& PartySlot : PartyInfo.Sub)
		{
			if (!PartySlot.SculptureId.IsInvalid())
			{
				PartySculptures.AddUnique(PartySlot.SculptureId);
			}
		}
	}

	return PartySculptures;
}

TArray<FRelicId> UPartyManager::GetRelicsInParty() const
{
	TArray<FRelicId> PartyRelics;
	for (const FPartyInfo& PartyInfo : PartyList)
	{
		for (const FPartySlot& PartySlot : PartyInfo.Main)
		{
			if (!PartySlot.RelicId.IsInvalid())
			{
				PartyRelics.AddUnique(PartySlot.RelicId);
			}
		}

		for (const FPartySlot& PartySlot : PartyInfo.Sub)
		{
			if (!PartySlot.RelicId.IsInvalid())
			{
				PartyRelics.AddUnique(PartySlot.RelicId);
			}
		}
	}

	return PartyRelics;
}

bool UPartyManager::GetPartySlotGrade(const FPartySlot& InPartySlot, EPartyIconItemType InCategory, EItemGrade* OutGrade) const
{
	if (InCategory == EPartyIconItemType::Character)
	{
		if (InPartySlot.CharacterId.IsInvalid())
		{
			return false;
		}

		const FCharacter* FoundCharacter = GetHUDStore().GetCharacterManager().Find(InPartySlot.CharacterId);
		if (!FoundCharacter)
		{
			return false;
		}
		*OutGrade = FoundCharacter->GetInfo().Grade;
		return true;
	}
	else if (InCategory == EPartyIconItemType::Sculpture)
	{
		if (InPartySlot.SculptureId.IsInvalid())
		{
			return false;
		}

		const FSculpture* FoundSculpture = GetHUDStore().GetSculptureManager().Find(InPartySlot.SculptureId);
		if (!FoundSculpture)
		{
			return false;
		}
		*OutGrade = FoundSculpture->GetInfo().Grade;
		return true;
	}
	else if (InCategory == EPartyIconItemType::Relic)
	{
		if (InPartySlot.RelicId.IsInvalid())
		{
			return false;
		}
		const FRelic* FoundRelic = GetHUDStore().GetRelicManager().Find(InPartySlot.RelicId);
		if (!FoundRelic)
		{
			return false;
		}
		*OutGrade = FoundRelic->GetInfo().Grade;
		return true;
	}

	return false;
}

bool UPartyManager::ExistsInParty(EPartyIconItemType InCategory, EItemGrade InGrade) const
{
	TArray<FCharacterId> PartyCharacters;
	for (const FPartyInfo& PartyInfo : PartyList)
	{
		for (const FPartySlot& PartySlot : PartyInfo.Main)
		{
			EItemGrade OutGrade;
			if (!GetPartySlotGrade(PartySlot, InCategory, &OutGrade))
			{
				continue;
			}

			if (OutGrade == InGrade)
			{
				return true;
			}
		}

		for (const FPartySlot& PartySlot : PartyInfo.Sub)
		{
			EItemGrade OutGrade;
			if (!GetPartySlotGrade(PartySlot, InCategory, &OutGrade))
			{
				continue;
			}

			if (OutGrade == InGrade)
			{
				return true;
			}
		}
	}

	return false;
}

bool UPartyManager::IsValidParty(int32 PartyId) const
{
	const FPartyInfo& PartyInfo = GetPartyInfo(PartyId);
	for (const FPartySlot& PartySlot : PartyInfo.Main)
	{
		if (PartySlot.CharacterId.IsInvalid())
		{
			return false;
		}
	}

	return true;
}

#if !UE_BUILD_SHIPPING
bool UPartyManager::CanJokerEdit() const
{
	return CVarQ6JokerSlotEdit.GetValueOnGameThread();
}
#endif

void UPartyManager::ReqPartyList() const
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LPartyLoad Out;

	ClientNetwork.WsRequest(TEXT("party/load"), Out,
		TQ6ResponseDelegate<FL2CPartyLoadResp>::CreateUObject(
			const_cast<UPartyManager*>(this), &UPartyManager::OnPartyLoadResp));
}

void UPartyManager::ReqPartySave(const FPartyInfo& InPartyInfo, const FPartySlot& InJokerSlot) const
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LPartySave Out;

	Out.PartyInfo = InPartyInfo;

	if (JokerType == EJokerType::OwnedJoker)
	{
		ACTION_DISPATCH_OwnedJoker(InJokerSlot);
	}

	ClientNetwork.WsRequest(TEXT("party/save"), Out,
		TQ6ResponseDelegate<FL2CPartySaveResp>::CreateUObject(
			const_cast<UPartyManager*>(this), &UPartyManager::OnPartySaveResp));
}

void UPartyManager::ReqCharacterSave(int32 PartyId, const TArray<FCharacterId>& Characters) const
{
	const int NUM_PARTY_MEMBER = MAX_MAIN_PARTY_MEMBER + MAX_SUB_PARTY_MEMBER;
	if (Characters.Num() != NUM_PARTY_MEMBER)
	{
		Q6JsonLog(Warning, "party member not match", Q6KV("Num", Characters.Num()));
		return;
	}

	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LPartySaveCharacters Out;
	Out.PartyId = PartyId;
	Out.CharacterIds = Characters;

	ClientNetwork.WsRequest(TEXT("party/saveCharacters"), Out,
		TQ6ResponseDelegate<FL2CPartySaveResp>::CreateUObject(
			const_cast<UPartyManager*>(this), &UPartyManager::OnPartySaveResp));
}

void UPartyManager::ReqRelicSave(int32 PartyId, const TArray<FRelicId>& Relics) const
{
	const int NUM_PARTY_MEMBER = MAX_MAIN_PARTY_MEMBER + MAX_SUB_PARTY_MEMBER;
	if (Relics.Num() != NUM_PARTY_MEMBER)
	{
		Q6JsonLog(Warning, "party member not match", Q6KV("Num", Relics.Num()));
		return;
	}

	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LPartySaveRelics Out;
	Out.PartyId = PartyId;
	Out.RelicIds = Relics;

	ClientNetwork.WsRequest(TEXT("party/saveRelics"), Out,
		TQ6ResponseDelegate<FL2CPartySaveResp>::CreateUObject(
			const_cast<UPartyManager*>(this), &UPartyManager::OnPartySaveResp));
}

void UPartyManager::ReqSculptureSave(int32 PartyId, const TArray<FSculptureId>& Sculptures) const
{
	const int NUM_PARTY_MEMBER = MAX_MAIN_PARTY_MEMBER + MAX_SUB_PARTY_MEMBER;
	if (Sculptures.Num() != NUM_PARTY_MEMBER)
	{
		Q6JsonLog(Warning, "party member not match", Q6KV("Num", Sculptures.Num()));
		return;
	}

	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LPartySaveSculptures Out;
	Out.PartyId = PartyId;
	Out.SculptureIds = Sculptures;

	ClientNetwork.WsRequest(TEXT("party/saveSculptures"), Out,
		TQ6ResponseDelegate<FL2CPartySaveResp>::CreateUObject(
			const_cast<UPartyManager*>(this), &UPartyManager::OnPartySaveResp));
}

void UPartyManager::ReqPartyPetSave(int32 PartyId, const FPetId& PetId) const
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LPartyPetSave Out;
	Out.PartyId = PartyId;
	Out.PetId = PetId;

	ClientNetwork.WsRequest(TEXT("party/petSave"), Out,
		TQ6ResponseDelegate<FL2CPartySaveResp>::CreateUObject(
			const_cast<UPartyManager*>(this), &UPartyManager::OnPartySaveResp));
}

void UPartyManager::OnPartyLoadResp(const FResError* Error, const FL2CPartyLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_PartyLoadResp(Res);
	GameInstance->ReqNextContent();
}

void UPartyManager::OnPartySaveResp(const FResError* Error, const FL2CPartySaveResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PartySaveResp(Res);
}

/////////////////////////////////////////////////////////////////////////////
// HUDStore Action

void UPartyManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UPartyManager, SystemJoker);
	REGISTER_ACTION_HANDLER(UPartyManager, RandomJoker);
	REGISTER_ACTION_HANDLER(UPartyManager, FriendJoker);
	REGISTER_ACTION_HANDLER(UPartyManager, FriendJokerFromPopup);
	REGISTER_ACTION_HANDLER(UPartyManager, OwnedJoker);
	REGISTER_ACTION_HANDLER(UPartyManager, MenuChange);
	REGISTER_ACTION_HANDLER(UPartyManager, PartyLoadResp);
	REGISTER_ACTION_HANDLER(UPartyManager, PartySaveResp);
	REGISTER_ACTION_HANDLER(UPartyManager, PetLoadResp);	// QSIX-3268: test code
	REGISTER_ACTION_HANDLER(UPartyManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UPartyManager, DevPetParkOpenResp);
	REGISTER_ACTION_HANDLER(UPartyManager, DevSpecialClearResp);
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, SystemJoker)
{
	auto Action = ACTION_PARSE_SystemJoker(InAction);

#if !UE_BUILD_SHIPPING
	if (CanJokerEdit())
	{
		ClearForOwnedJokerSet();
		return true;
	}
#endif

	SetSystemJoker(Action->GetVal());

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, RandomJoker)
{
	auto Action = ACTION_PARSE_RandomJoker(InAction);

#if !UE_BUILD_SHIPPING
	if (CanJokerEdit())
	{
		ClearForOwnedJokerSet();
		return true;
	}
#endif

	SetRandomJoker(Action->GetVal());

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, FriendJoker)
{
	auto Action = ACTION_PARSE_FriendJoker(InAction);

#if !UE_BUILD_SHIPPING
	if (CanJokerEdit())
	{
		ClearForOwnedJokerSet();
		return true;
	}
#endif

	SetFriendJoker(Action->GetVal(), Action->GetVal2());

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, FriendJokerFromPopup) //-V524 equivalent body
{
	auto Action = ACTION_PARSE_FriendJokerFromPopup(InAction);

#if !UE_BUILD_SHIPPING
	if (CanJokerEdit())
	{
		ClearForOwnedJokerSet();
		return true;
	}
#endif

	SetFriendJoker(Action->GetVal(), Action->GetVal2());

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, OwnedJoker)
{
	auto Action = ACTION_PARSE_OwnedJoker(InAction);

	SetOwnedJoker(Action->GetVal());

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, MenuChange)
{
	auto Action = ACTION_PARSE_MenuChange(InAction);

	if (Action->GetVal2())
	{
		FCharacterInfo EmptyJoker;
		EmptyJoker.Type = CharacterTypeInvalid;
		EmptyJoker.CharacterId = FCharacterId::InvalidValue();
		EmptyJoker.UserId = FUserId::InvalidValue();

		SetSystemJoker(EmptyJoker);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, PartyLoadResp)
{
	auto Action = ACTION_PARSE_PartyLoadResp(InAction);

	const auto& Res = Action->GetVal();
	PartyList = Res.PartyList;

	return true;
}

FPartyInfo* UPartyManager::Find(int32 Id)
{
	return PartyList.FindByPredicate([Id]
		(const FPartyInfo& Party) { return Party.PartyId == Id; });
}

void UPartyManager::Update(const FPartyInfo& InParty)
{
	FPartyInfo* Found = Find(InParty.PartyId);
	if (Found)
	{
		*Found = InParty;
	}
	else
	{
		PartyList.Push(InParty);
	}
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, PartySaveResp)
{
	auto Action = ACTION_PARSE_PartySaveResp(InAction);

	const FPartyInfo& Party = Action->GetVal().PartyInfo;
	Update(Party);
	return true;
}

// QSIX-3268: test code
IMPLEMENT_ACTION_HANDLER(UPartyManager, PetLoadResp)
{
	auto Action = ACTION_PARSE_PetLoadResp(InAction);

	const TArray<FPetInfo> Pets = Action->GetVal().Pets;
	if (Pets.Num() <= 0)
	{
		return false;
	}

	FPetId PetId = Pets[0].PetId;
	for (FPartyInfo& Party : PartyList)
	{
		if (Party.PetId > FPetId::InvalidValue())
		{
			continue;
		}

		Party.PetId = PetId;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	const TArray<FPartyInfo>& Parties = Action->GetVal().PartyList;
	for (const FPartyInfo& Party : Parties)
	{
		Update(Party);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);

	const TArray<FPartyInfo>& Parties = Action->GetVal().PartyList;
	for (const FPartyInfo& Party : Parties)
	{
		Update(Party);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, DevPetParkOpenResp)
{
	auto Action = ACTION_PARSE_DevPetParkOpenResp(InAction);

	const TArray<FPartyInfo>& Parties = Action->GetVal().PartyList;
	for (const FPartyInfo& Party : Parties)
	{
		Update(Party);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPartyManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);

	const TArray<FPartyInfo>& Parties = Action->GetVal().PartyList;
	for (const FPartyInfo& Party : Parties)
	{
		Update(Party);
	}

	return true;
}