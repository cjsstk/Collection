#include "CharacterManager.h"
#include "CMS/CMS_gen.h"
#include "Q6GameInstance.h"
#include "HSAction.h"
#include "Q6.h"
#include "BagItemManager.h"
#include "SortingWidgets.h"
#include "SystemConstHelper.h"
#include "UIStateManager.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Static Functions

void DumpCharacter(const FCharacterInfo& Info)
{
	Q6JsonLogHekel(Verbose, "",
		Q6KV("Id", Info.CharacterId.S),
		Q6KV("User", Info.UserId),
		Q6KV("Type", Info.Type),
		Q6KV("Level", Info.Level),
		Q6KV("Xp", Info.Xp),
		Q6KV("Grade", (int32)Info.Grade),
		Q6KV("Star", Info.Star),
		Q6KV("Locked", Info.Locked),
		Q6KV("Used", Info.Used),
		Q6KV("Newly", Info.Newly),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()),
		Q6KV("Ultimate", Info.UltimateSkillLevel),
		Q6KV("Turn1", Info.TurnSkill1Level),
		Q6KV("Turn2", Info.TurnSkill2Level),
		Q6KV("Turn3", Info.TurnSkill3Level)
		);
}

///////////////////////////////////////////////////////////////////////////////////////////
// FCharacter

FCharacter::FCharacter(const FCharacterInfo & InInfo)
	: Hp(0)
	, Atk(0)
	, Def(0)
{
	Info = InInfo;
}

void FCharacter::Update(const FCharacterInfo& InInfo)
{
	Info = InInfo;
}

void FCharacter::UpdateSkillLevel(ESkillCategory InCategory, int32 InNewLevel, int32 InTurnSkillIndex)
{
	switch (InCategory)
	{
	case ESkillCategory::Ultimate:
		Info.UltimateSkillLevel = InNewLevel;
		break;

	case ESkillCategory::TurnBegin:
		switch (InTurnSkillIndex)
		{
		case 0: Info.TurnSkill1Level = InNewLevel; break;
		case 1: Info.TurnSkill2Level = InNewLevel; break;
		case 2: Info.TurnSkill3Level = InNewLevel; break;
		default: break;
		}
	default:
		break;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// UCharacterManager

UCharacterManager::UCharacterManager()
{
	InitStore(EHSType::Character);
}

TArray<const FCharacter*> UCharacterManager::GetCharacters(ESortMenu SortMenu, ESortCategory Category, bool bStashed) const
{
	TArray<const FCharacter*> FilteredList;

	const UCMS* CMS = GetCMS();
	const FSortingGroup& SortingGroup = GetUIResource().GetSortingGroup(Category);
	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, Category);
	for (auto& Elem : Characters)
	{
		const FCharacter& Character = Elem.Value;
		const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(Character.GetInfo().Type);
		if (Category != ESortCategory::OwnedCharacterWithExp && CharacterRow.XpExclusive)
		{
			continue;
		}

		if (SortingGroup.bXpCardFilter && SortingOption.bXpCardFilter && !CharacterRow.XpExclusive)
		{
			continue;
		}

		const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(Character.GetInfo().Type);
		if ((SortingGroup.FilterType == ESortFilterType::Nature) && !SortingOption.FilterOptions.Contains((int32)UnitRow.NatureType) && UnitRow.NatureType != ENatureType::All)
		{
			continue;
		}

		if (Character.IsStashed() != bStashed)
		{
			continue;
		}

		FilteredList.AddUnique(&Character);
	}

	FSortOrdering::Sort(SortingOption, FilteredList);
	return FilteredList;
}

void UCharacterManager::SortByPicked(TArray<const FCharacter*>& OutCharacters, const TArray<FCharacterId>& CharacterIds) const
{
	int32 PickedIndex = 0;
	for (const FCharacter* Character : OutCharacters)
	{
		if (!CharacterIds.Contains(Character->GetInfo().CharacterId))
		{
			continue;
		}

		OutCharacters.Remove(Character);
		OutCharacters.Insert(Character, PickedIndex++);
	}
}

const FCharacter* UCharacterManager::Find(const FCharacterId& Id) const
{
	return Characters.Find(Id);
}

FCharacter* UCharacterManager::Find(const FCharacterId& Id)
{
	return Characters.Find(Id);
}

bool UCharacterManager::HasCharacter(FCharacterType CharacterType) const
{
	for (const auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		if (ItChar.GetInfo().Type == CharacterType)
		{
			return true;
		}
	}

	return false;
}

const FCharacterInfo* UCharacterManager::FindHighestLevelCharacter(FCharacterType CharacterType) const
{
	// CAUTION: this is always scanning array by type.
	const FCharacterInfo* HighestLevelChar = nullptr;
	for (const auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		if (ItChar.GetInfo().Type != CharacterType)
		{
			continue;
		}

		if (!HighestLevelChar ||
			HighestLevelChar->Level < ItChar.GetInfo().Level)
		{
			HighestLevelChar = &(ItChar.GetInfo());
		}
	}

	return HighestLevelChar;
}

bool UCharacterManager::HasCharacter(EItemGrade InGrade) const
{
	for (const auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		if (ItChar.GetInfo().Grade != InGrade)
		{
			continue;
		}

		return true;
	}

	return false;
}

FCharacterId UCharacterManager::GetFirstCharacterIdByCharacterType(FCharacterType CharacterType) const
{
	for (const auto& Elem : Characters)
	{
		const FCharacter& CurCharacter = Elem.Value;
		const FCharacterType CurCharacterType = CurCharacter.GetInfo().Type;
		if (CurCharacterType != CharacterType)
		{
			continue;
		}

		return CurCharacter.GetInfo().CharacterId;
	}

	return FCharacterId::InvalidValue();
}

const FCharacter* UCharacterManager::GetHighestLevelCharacter(FCharacterType CharacterType) const
{
	const FCharacter* CurHighestLevelCharacter = nullptr;

	for (auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		FCharacterType CurcharacterType = ItChar.GetInfo().Type;
		if (CurcharacterType != CharacterType)
		{
			continue;
		}

		if (CurHighestLevelCharacter && CurHighestLevelCharacter->GetInfo().Level >= ItChar.GetInfo().Level)
		{
			continue;
		}

		CurHighestLevelCharacter = &ItChar;
	}

	return CurHighestLevelCharacter;
}

int32 UCharacterManager::GetStashedCharacterNum(bool bStashed) const
{
	int32 StashedCount = 0;
	for (const auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		if (ItChar.IsStashed() != bStashed)
		{
			continue;
		}

		++StashedCount;
	}

	return StashedCount;
}

void UCharacterManager::Dump() const
{
	Q6JsonLogHekel(Verbose, "== Characters ==",
		Q6KV("Total", MyCharacters.Num()));
	for (const FCharacterId& MyCharId : MyCharacters)
	{
		const FCharacter* Nub = Characters.Find(MyCharId);
		if (!Nub)
		{
			continue;
		}

		const FCharacterInfo& Info = Nub->GetInfo();
		DumpCharacter(Info);
	}
}

bool UCharacterManager::IsEqualCharacterType(const FCharacterId& CharacterIdA, const FCharacterId& CharacterIdB) const
{
	const FCharacter* CharacterA = Find(CharacterIdA);
	const FCharacter* CharacterB = Find(CharacterIdB);

	FCharacterType CharacterTypeA = CharacterA ? CharacterA->GetInfo().Type : CharacterTypeInvalid;
	FCharacterType CharacterTypeB = CharacterB ? CharacterB->GetInfo().Type : CharacterTypeInvalid;

	return (CharacterTypeA == CharacterTypeB);
}

TArray<FCharacterType> UCharacterManager::GetCharacterTypes(const TArray<FCharacterId>& CharacterIds) const
{
	TArray<FCharacterType> CharacterTypes;

	for (const FCharacterId& CharacterId : CharacterIds)
	{
		if (const FCharacter* InChar = Find(CharacterId))
		{
			CharacterTypes.Add(InChar->GetInfo().Type);
		}
	}

	return CharacterTypes;
}

TMap<FCharacterType, const FCharacterInfo*> UCharacterManager::GetPortalConnectCharacters() const
{
	TMap<FCharacterType, const FCharacterInfo*> CharacterMap;

	for (auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		const FCharacterInfo& CharacterInfo = ItChar.GetInfo();
		if (CharacterInfo.Grade < EItemGrade::SR)
		{
			continue;
		}

		const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(CharacterInfo.Type);
		if (CharacterRow.XpExclusive)
		{
			continue;
		}

		if (!CharacterRow.Pyramid)
		{
			continue;
		}

		const FCharacterInfo** FoundCharacterInfo = CharacterMap.Find(CharacterInfo.Type);
		if (!FoundCharacterInfo)
		{
			CharacterMap.Add(CharacterInfo.Type, &CharacterInfo);
			continue;
		}

		if (CharacterInfo.Level > (*FoundCharacterInfo)->Level)
		{
			CharacterMap.Add(CharacterInfo.Type, &CharacterInfo);
			continue;
		}

		CharacterMap.Add(CharacterInfo.Type, &CharacterInfo);
	}

	return CharacterMap;
}

TMap<FCharacterType, const FCharacterInfo*> UCharacterManager::GetVacationCharacters() const
{
	TMap<FCharacterType, const FCharacterInfo*> CharacterMap;

	for (auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		const FCharacterInfo& CharacterInfo = ItChar.GetInfo();
		const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(CharacterInfo.Type);
		if (CharacterRow.XpExclusive)
		{
			continue;
		}

		CharacterMap.Add(CharacterInfo.Type, &CharacterInfo);
	}

	return CharacterMap;
}

bool UCharacterManager::GetMyWeedInfo(FCharacterInfo& Info) const
{
	for (const FCharacterId& MyCharId : MyCharacters)
	{
		const FCharacter* Nub = Characters.Find(MyCharId);
		if (Nub && SystemConstHelper::IsWeed(Nub->GetInfo()))
		{
			Info = Nub->GetInfo();
			return true;
		}
	}

	Q6JsonLogZagal(Warning, "GetMyWeedId - no weed");

	return false;
}

bool UCharacterManager::IsWeed(FCharacterId CharacterId) const
{
	if (const FCharacter* InChar = Find(CharacterId))
	{
		return SystemConstHelper::IsWeed(InChar->GetInfo());
	}

	return false;
}

bool UCharacterManager::HasUpgradedCharacter() const
{
	for (auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		const FCharacterInfo& CharacterInfo = ItChar.GetInfo();
		if (CharacterInfo.Level > 1)
		{
			return true;
		}
	}

	return false;
}

const FCMSSkillRow* UCharacterManager::GetCharacterTurnSkillRow(const FCharacterId& InCharacterId, int32 InSkillIndex) const
{
	const FCharacter* SelectedCharacter = Find(InCharacterId);
	if (!SelectedCharacter)
	{
		return nullptr;
	}
	const FCharacterInfo& CharacterInfo = SelectedCharacter->GetInfo();
	const FCMSUnitRow& SelectedUnitRow = GetCMS()->GetUnitRowOrDummy(CharacterInfo.Type);
	const TArray<const FCMSSkillRow*>& SelectedUnitTurnSkills = SelectedUnitRow.GetTurnSkills();

	if (!SelectedUnitTurnSkills.IsValidIndex(InSkillIndex))
	{
		Q6JsonLogGunny(Error, "SelectedUnitTurnSkills index error", Q6KV("InSkillIndex", InSkillIndex));
		return nullptr;
	}
	return SelectedUnitTurnSkills[InSkillIndex];
}

void UCharacterManager::GetCharacterTurnSkillLevels(const FCharacterId& InCharacterId, TArray<int32>& OutCharacterLevels) const
{
	const FCharacter* SelectedCharacter = Find(InCharacterId);
	if (!SelectedCharacter)
	{
		return;
	}
	const FCharacterInfo& SelectedCharacterInfo = SelectedCharacter->GetInfo();

	OutCharacterLevels.SetNum(CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
	OutCharacterLevels[0] = SelectedCharacterInfo.TurnSkill1Level;
	OutCharacterLevels[1] = SelectedCharacterInfo.TurnSkill2Level;
	OutCharacterLevels[2] = SelectedCharacterInfo.TurnSkill3Level;
}

const FCMSSkillUpgradeCostRow* UCharacterManager::GetTurnSkillUpgradeCostRow(const FCharacterId InCharacterId, int32 InSkillIndex) const
{
	const FCMSSkillRow* TurnSkillRow = GetCharacterTurnSkillRow(InCharacterId, InSkillIndex);
	if (!TurnSkillRow)
	{
		Q6JsonLogGunny(Warning, "TurnSkillRow is nullptr");
		return nullptr;
	}
	const TArray<const FCMSSkillUpgradeCostRow*>& UpgradeMaterials = TurnSkillRow->GetSkillUpgradeCost();

	TArray<int32> TurnSkillLevels;
	GetCharacterTurnSkillLevels(InCharacterId, TurnSkillLevels);

	if (!TurnSkillLevels.IsValidIndex(InSkillIndex))
	{
		Q6JsonLogGunny(Warning, "TurnSkillLevels index error", Q6KV("InSkillIndex", InSkillIndex));
		return nullptr;
	}
	const int32 TurnSkillLevelIndex = TurnSkillLevels[InSkillIndex] - 1;

	if (!UpgradeMaterials.IsValidIndex(TurnSkillLevelIndex))
	{
		return nullptr;
	}
	return UpgradeMaterials[TurnSkillLevelIndex];
}

int32 UCharacterManager::GetTurnSkillLevel(const FCharacterId InCharacterId, int32 InSkillIndex) const
{
	TArray<int32> TurnSkillLevels;
	GetCharacterTurnSkillLevels(InCharacterId, TurnSkillLevels);
	return TurnSkillLevels.IsValidIndex(InSkillIndex) ? TurnSkillLevels[InSkillIndex] : 0;
}

int32 UCharacterManager::GetGoldForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const
{
	const FCharacter* SelectedCharacter = Find(InCharacterId);
	ensure(SelectedCharacter);

	EItemGrade Grade = SelectedCharacter->GetInfo().Grade;
	int32 CurrentTurnSkillLevel = GetTurnSkillLevel(InCharacterId, InSkillIndex);
	int32 NextTurnSkillLevel = CurrentTurnSkillLevel + 1;
	if (Grade == EItemGrade::NONE || NextTurnSkillLevel < 2)
	{
		return 0;
	}

	return SystemConstHelper::GetGold4TurnSkillUpgrade(Grade, NextTurnSkillLevel);
}

bool UCharacterManager::HasEnoughGoldForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const
{
	const int32 ReqGold = GetGoldForTurnSkillUpgrade(InCharacterId, InSkillIndex);
	return GetHUDStore().GetWorldUser().HasEnoughGold(ReqGold);
}

bool UCharacterManager::HasEnoughMaterialsForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const
{
	const FCMSSkillUpgradeCostRow* UpgradeCost = GetTurnSkillUpgradeCostRow(InCharacterId, InSkillIndex);
	if (!UpgradeCost)
	{
		return false;
	}

	const TArray<const FCMSBagItemRow*>& MaterialBagItems = UpgradeCost->GetBagItem();
	const TArray<int32>& RequireMaterials = UpgradeCost->BagItemCount;

	for (int i = 0; i < MaterialBagItems.Num(); ++i)
	{
		if (!RequireMaterials.IsValidIndex(i))
		{
			Q6JsonLogGunny(Warning, "NumberOfItems index error", Q6KV("i", i));
			return false;
		}

		bool bHasEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(MaterialBagItems[i]->CmsType(), RequireMaterials[i]);

		if (!bHasEnoughMaterials)
		{
			return false;
		}
	}

	return true;
}

bool UCharacterManager::IsEnoughLevelForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const
{
	const FCharacter* SelectedCharacter = Find(InCharacterId);
	if (!SelectedCharacter)
	{
		Q6JsonLogRoze(Error, "UCharacterManager::IsEnoughLevelForTurnSkillUpgrade - Not found character", Q6KV("CharacterId", InCharacterId.S));
		return false;
	}

	const int32 CurrentTurnSkillLevel = GetTurnSkillLevel(InCharacterId, InSkillIndex);
	if (CurrentTurnSkillLevel <= 0 || CurrentTurnSkillLevel >= CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		return false;
	}

	return SystemConstHelper::CanTurnSkillUpgradeLevel(CurrentTurnSkillLevel + 1, SelectedCharacter->GetInfo().Level);
}

bool UCharacterManager::IsEnoughStarForTurnSkillUpgrade(const FCharacterId& InCharacterId, int32 InSkillIndex) const
{
	const FCharacter* SelectedCharacter = Find(InCharacterId);
	if (!SelectedCharacter)
	{
		Q6JsonLogRoze(Error, "UCharacterManager::IsEnoughStarForTurnSkillUpgrade - Not found character", Q6KV("CharacterId", InCharacterId.S));
		return false;
	}

	const int32 InSkillNumber = InSkillIndex + 1;
	const int32 NumberOfTurnSkillOnCurrentStar = SystemConstHelper::GetCharacterTurnSkillCount(SelectedCharacter->GetInfo().Star);

	return InSkillNumber <= NumberOfTurnSkillOnCurrentStar;
}

int32 UCharacterManager::GetLeastUpUltimateSkillLevel(const FCharacterId& InCharacterId) const
{
	const FCharacter* TargetCharacter = Find(InCharacterId);
	if (!TargetCharacter)
	{
		Q6JsonLogRoze(Warning, "Not found target character", Q6KV("CharacterId", InCharacterId));
		return 0;
	}

	int32 LeastUp = 0;
	const FCharacterInfo& TargetCharacterInfo = TargetCharacter->GetInfo();
	for (auto& Elem : Characters)
	{
		const FCharacter& ItChar = Elem.Value;
		const FCharacterInfo& CharacterInfo = ItChar.GetInfo();
		if (CharacterInfo.Type != TargetCharacterInfo.Type)
		{
			continue;
		}

		if (CharacterInfo.CharacterId == TargetCharacterInfo.CharacterId)
		{
			continue;
		}

		const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(CharacterInfo.Type);
		if (CharacterRow.XpExclusive)
		{
			continue;
		}

		if ((LeastUp <= 0) || (LeastUp > CharacterInfo.UltimateSkillLevel))
		{
			LeastUp = CharacterInfo.UltimateSkillLevel;
		}
	}

	return LeastUp;
}

void UCharacterManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearMyCharacters();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCharacterList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("character/list"), Out,
		TQ6ResponseDelegate<FL2CCharacterListResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnListResp));
}

void UCharacterManager::OnListResp(const FResError* Error, const FL2CCharacterListResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		Dump();
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_CharacterListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		// TODO: refresh UI, list finished
		Dump();
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		Dump();
		GameInstance->ReqNextContent();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void UCharacterManager::ReqLoad(const FCharacterId& Id) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCharacterLoad Out;
	Out.CharacterId = Id;

	ClientNetwork.WsRequest(TEXT("character/load"), Out,
		TQ6ResponseDelegate<FL2CCharacterLoadResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnLoadResp));
}

void UCharacterManager::ReqClearNew(const TArray<FCharacterId>& CharacterIds) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCharacterClearNew Out;
	Out.CharacterIds = CharacterIds;

	ClientNetwork.WsRequest(TEXT("character/clearNew"), Out,
		TQ6ResponseDelegate<FL2CCharacterClearNewResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnClearNewResp));
}

void UCharacterManager::ReqSetLock(const FCharacterId& Id, bool bLock) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCharacterSetLock Out;
	Out.CharacterId = Id;
	Out.Locked = bLock ? 1 : 0;

	ClientNetwork.WsRequest(TEXT("character/setLock"), Out,
		TQ6ResponseDelegate<FL2CCharacterLoadResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnLoadResp));
}

void UCharacterManager::OnLoadResp(const FResError* Error, const FL2CCharacterLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	// load, setLock
	ACTION_DISPATCH_CharacterLoadResp(Msg);
}

void UCharacterManager::ReqAddXp(const FCharacterId& TargetId, const TArray<int64>& SourceIds) const
{
	FC2LCharacterAddXp Out;
	Out.CharacterId = TargetId;
	for (const int64& SourceId : SourceIds)
	{
		Out.CharacterIds.Add(FCharacterId(SourceId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/addXp"), Out,
		TQ6ResponseDelegate<FL2CCharacterAddXpResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnAddXpResp));
}

void UCharacterManager::OnAddXpResp(const FResError* Error, const FL2CCharacterAddXpResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterAddXpResp(Msg);
}

void UCharacterManager::ReqPromote(const FCharacterId& TargetId) const
{
	FC2LCharacterPromote Out;
	Out.CharacterId = TargetId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/promote"), Out,
		TQ6ResponseDelegate<FL2CCharacterPromoteResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnPromoteResp));
}

void UCharacterManager::ReqUnbind(const FCharacterId& TargetId) const
{
	FC2LCharacterUnbind Out;
	Out.CharacterId = TargetId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/unbind"), Out,
		TQ6ResponseDelegate<FL2CCharacterUnbindResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnUnbindResp));
}

void UCharacterManager::ReqEvolute(const FCharacterId& TargetId) const
{
	FC2LCharacterEvolute Out;
	Out.CharacterId = TargetId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/evolute"), Out,
		TQ6ResponseDelegate<FL2CCharacterEvoluteResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnEvoluteResp));
}

void UCharacterManager::ReqUpgradeTurnSkillLevel(const FCharacterId& TargetId, int32 InTurnSkillIndex) const
{
	FC2LCharacterUpgradeTurnSkillLevel Out;
	Out.CharacterId = TargetId;
	Out.TurnSkillIndex = InTurnSkillIndex;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/upgradeTurnSkillLevel"), Out,
		TQ6ResponseDelegate<FL2CCharacterUpgradeTurnSkillLevelResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnUpgradeTurnSkillLevelResp));
}

void UCharacterManager::ReqUpgradeUltimateSkillLevel(const FCharacterId& TargetId, const TArray<int64>& SourceIds) const
{
	FC2LCharacterUpgradeUltimateSkillLevel Out;
	Out.CharacterId = TargetId;
	for (const int64& SourceId : SourceIds)
	{
		Out.CharacterIds.Add(FCharacterId(SourceId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/upgradeUltimateSkillLevel"), Out,
		TQ6ResponseDelegate<FL2CCharacterUpgradeUltimateSkillLevelResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnUpgradeUltimateSkillLevelResp));
}

void UCharacterManager::ReqSetStash(const TArray<int64>& TargetIds, bool bStashed) const
{
	FC2LCharacterSetStash Out;
	Out.Stashed = bStashed;
	for (const int64& TargetId : TargetIds)
	{
		Out.CharacterIds.Add(FCharacterId(TargetId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/setStash"), Out,
		TQ6ResponseDelegate<FL2CCharacterSetStashResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnSetStashResp));
}

void UCharacterManager::ReqSetIllust(const FCharacterId& TargetId, int32 InIllustNum) const
{
	FC2LCharacterSetIllust Out;
	Out.CharacterId = TargetId;
	Out.Illust = InIllustNum;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("character/setIllust"), Out,
		TQ6ResponseDelegate<FL2CCharacterSetIllustResp>::CreateUObject(
			const_cast<UCharacterManager*>(this), &UCharacterManager::OnSetIllustResp));
}

void UCharacterManager::OnPromoteResp(const FResError* Error, const FL2CCharacterPromoteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterPromoteResp(Msg);
}

void UCharacterManager::OnUnbindResp(const FResError* Error, const FL2CCharacterUnbindResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterUnbindResp(Msg);
}

void UCharacterManager::OnEvoluteResp(const FResError* Error, const FL2CCharacterEvoluteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterEvoluteResp(Msg);
}

void UCharacterManager::OnUpgradeTurnSkillLevelResp(const FResError* Error, const FL2CCharacterUpgradeTurnSkillLevelResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterTurnSkillLevelResp(Msg);
}

void UCharacterManager::OnUpgradeUltimateSkillLevelResp(const FResError* Error, const FL2CCharacterUpgradeUltimateSkillLevelResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterUltimateSkillLevelResp(Msg);
}

void UCharacterManager::OnSetStashResp(const FResError* Error, const FL2CCharacterSetStashResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterSetStashResp(Msg);
}

void UCharacterManager::OnSetIllustResp(const FResError* Error, const FL2CCharacterSetIllustResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterSetIllustResp(Msg);
}

void UCharacterManager::OnClearNewResp(const FResError* Error, const FL2CCharacterClearNewResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CharacterClearNewResp(Msg);
}

/////////////////////////////////////////////////////////////////////////////
// Setter

void UCharacterManager::AddCharacter(const FCharacterInfo& Info)
{
	DumpCharacter(Info);

	Characters.Add(Info.CharacterId, Info);
	if (GetUser().GetId() == Info.UserId)
	{
		MyCharacters.Add(Info.CharacterId);
	}
}

void UCharacterManager::Removed(const FCharacterId& Id)
{
	const FCharacter* Found = Find(Id);
	if (!Found)
	{
		return;
	}

	Characters.Remove(Id);
	MyCharacters.Remove(Id);
}

void UCharacterManager::SetCharacterSkillLevel(const FCharacterId& InCharacterId, ESkillCategory InCategory, int32 NewSkillLevel, int32 OldSkillLevel, int32 TurnSkillIndex)
{
	FCharacter* Found = Find(InCharacterId);
	if (!Found)
	{
		return;
	}

	Found->UpdateSkillLevel(InCategory, NewSkillLevel, TurnSkillIndex);
}


/////////////////////////////////////////////////////////////////////////////
// UCharacterManager HUDStore Action

void UCharacterManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UCharacterManager, ClearMyCharacters);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterListResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterLoadResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterAddXpResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterRemoveResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterPromoteResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterUnbindResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterEvoluteResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterSkillLevelResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterTurnSkillLevelResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterUltimateSkillLevelResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterSetStashResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterSetIllustResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, CharacterClearNewResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, DevCharacterNewResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, SummonPickupResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, DevTrainingCenterClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, ShopSellItemResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UCharacterManager, EventContentMultisideBattleReceiveRankRewardResp);
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, ClearMyCharacters)
{
	MyCharacters.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterListResp)
{
	auto Action = ACTION_PARSE_CharacterListResp(InAction);

	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterLoadResp)
{
	auto Action = ACTION_PARSE_CharacterLoadResp(InAction);

	auto& Res = Action->GetVal();
	AddCharacter(Res.Info);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterAddXpResp)
{
	auto Action = ACTION_PARSE_CharacterAddXpResp(InAction);

	auto& Res = Action->GetVal();

	AddCharacter(Res.Info);
	for (const FCharacterId& Id : Res.Ids)
	{
		Removed(Id);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterRemoveResp)
{
	auto Action = ACTION_PARSE_CharacterRemoveResp(InAction);

	auto& Res = Action->GetVal();
	for (const FCharacterId& Id : Res.CharacterIds)
	{
		Removed(Id);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterPromoteResp)
{
	auto Action = ACTION_PARSE_CharacterPromoteResp(InAction);

	auto& Res = Action->GetVal();
	AddCharacter(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterUnbindResp)
{
	auto Action = ACTION_PARSE_CharacterUnbindResp(InAction);

	auto& Res = Action->GetVal();
	AddCharacter(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterEvoluteResp)
{
	auto Action = ACTION_PARSE_CharacterEvoluteResp(InAction);

	auto& Res = Action->GetVal();
	AddCharacter(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterSkillLevelResp(InAction);
	auto& Res = Action->GetVal();
	SetCharacterSkillLevel(Res.CharacterId, (ESkillCategory)Res.Category, Res.NewSkillLevel, Res.OldSkillLevel, Res.TurnSkillIndex);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterTurnSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterTurnSkillLevelResp(InAction);

	auto& Res = Action->GetVal();
	AddCharacter(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterUltimateSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterUltimateSkillLevelResp(InAction);

	auto& Res = Action->GetVal();
	AddCharacter(Res.Info);
	for (const FCharacterId& Id : Res.Ids)
	{
		Removed(Id);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterSetStashResp)
{
	auto Action = ACTION_PARSE_CharacterSetStashResp(InAction);

	auto& Res = Action->GetVal();
	for (const FCharacterId& CharacterId : Res.CharacterIds)
	{
		FCharacter* FoundChar = Characters.Find(CharacterId);
		if (!FoundChar)
		{
			Q6JsonLogRoze(Error, "UCharacterManager::CharacterSetStashResp - No have character", Q6KV("CharacterId", CharacterId));
			continue;
		}

		FoundChar->SetStashed(Res.Stashed);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterSetIllustResp)
{
	auto Action = ACTION_PARSE_CharacterSetIllustResp(InAction);

	auto& Res = Action->GetVal();

	FCharacter* FoundChar = Characters.Find(Res.CharacterId);
	if (!FoundChar)
	{
		Q6JsonLogGunny(Error, "UCharacterManager::CharacterSetIllustResp - Character does not exist.", Q6KV("CharacterId", Res.CharacterId));
		return false;
	}

	FoundChar->SetIllust(Res.Illust);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, CharacterClearNewResp)
{
	auto Action = ACTION_PARSE_CharacterClearNewResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCharacterId& CharacterId : Res.CharacterIds)
	{
		FCharacter* FoundChar = Characters.Find(CharacterId);
		if (!FoundChar)
		{
			Q6JsonLogRoze(Error, "UCharacterManager::CharacterClearNewResp - No have character", Q6KV("CharacterId", CharacterId));
			continue;
		}

		if (Res.CharacterIds.Contains(FoundChar->GetInfo().CharacterId))
		{
			FoundChar->SetNewly(0);
		}
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, DevCharacterNewResp)
{
	auto Action = ACTION_PARSE_DevCharacterNewResp(InAction);
	auto& Res = Action->GetVal();
	AddCharacter(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, SummonPickupResp)
{
	auto Action = ACTION_PARSE_SummonPickupResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, ShopSellItemResp)
{
	auto Action = ACTION_PARSE_ShopSellItemResp(InAction);
	auto& Res = Action->GetVal();
	if (Res.Category == ELootCategory::CharacterCard)
	{
		for (const FAnyId& ItemId : Res.ItemIds)
		{
			Removed(FCharacterId(ItemId.S));
		}
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCharacterManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);
	auto& Res = Action->GetVal();
	for (const FCharacterInfo& Info : Res.Characters)
	{
		AddCharacter(Info);
	}
	return true;
}
