#include "HSAction.h"
#include "HUDStore.h"
#include "Q6.h"
#include "Q6GameInstance.h"

void Action::Dispatch(TSharedPtr<FHSAction> InAction)
{
	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	if (GameInstance)
	{
		GameInstance->GetHUDStore().Dispatch(InAction);
	}
}
