#include "RewardManager.h"

#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "RaidManager.h"
#include "SpecialManager.h"
#include "TrainingCenterManager.h"
#include "HSAction.h"

///////////////////////////////////////////////////////////////////////////////////////////
// URewardManager

URewardManager::URewardManager()
{
	InitStore(EHSType::Reward);
}

void DumpItemData(const FItemData& Item)
{
	Q6JsonLogKalms(Verbose, "OnStageBegin",
		Q6KV("ItemCategory", static_cast<int32>(Item.Category)),
		Q6KV("Type", Item.Type),
		Q6KV("Count", Item.Count));
}

void URewardManager::SetClearReward(int32 GainXp, const TArray<FRewardInfo>& InRewardInfo)
{
	const FRewardInfo* FoundInfo = InRewardInfo.FindByPredicate([](const FRewardInfo& Info)
	{
		return (Info.Type == ESagaRewardType::Clear);
	});

	if (!FoundInfo)
	{
		StageReward = FStageReward();
		return;
	}

	int32 GainGold = 0;
	int32 Others = 0;

	for (const FCurrency& Currency : FoundInfo->CurrencyList)
	{
		switch (Currency.Type)
		{
			case ECurrencyType::Gold:
				GainGold += Currency.Count;
				break;
			default:
				Others += Currency.Count;
				break;
		}
	}

	Q6JsonLogKalms(Verbose, "OnStageBegin",
		Q6KV("Items", FoundInfo->ItemList.Num()),
		Q6KV("GainXp", GainXp),
		Q6KV("GainGold", GainGold),
		Q6KV("Others", Others));

	for (const FItemData& ItemData : FoundInfo->ItemList)
	{
		DumpItemData(ItemData);
	}

	StageReward.GainXp = GainXp;
	StageReward.GainGold = GainGold;
	StageReward.ItemList = FoundInfo->ItemList;
}

void URewardManager::SetVacationReward(const FRewardInfo& InRewardInfo)
{
	TArray<FRewardInfo> RewardInfos;
	RewardInfos.Add(InRewardInfo);

	FRewardStep Step;
	Step.RewardSequence = ERewardSequence::VacationReward;
	Step.RewardIndex = 0;

	TArray<FRewardStep> RewardSteps;
	RewardSteps.Add(Step);

	// Init data, but don't save
	GameInstance->InitRewardRecord(FRewardRecord(SagaTypeInvalid, RewardSteps, RewardInfos, TArray<FBondLevelUpReward>()), false);
}

void URewardManager::SetEndReward(const FEndRewardDesc& InDesc,
	const TArray<FRewardInfo>& InRewardInfos,
	const TArray<FBondLevelUpReward>& InBondRewards)
{
	// Flow(Fixed) : BondReward -> Outro -> WeedGrow -> SagaClear -> FoundRaid or ( Title -> ContentOpen )

	TArray<FRewardStep> RewardSteps;

	AddBond(InDesc, RewardSteps);
	AddOutro(InDesc, RewardSteps);
	AddWeedGrow(InDesc, RewardSteps);
	AddRewards(InDesc, InRewardInfos, RewardSteps);
	AddFoundRaid(InDesc, RewardSteps);
	AddTitle(InDesc, RewardSteps);
	AddContentOpen(InDesc, RewardSteps);

	for (const FRewardStep& Cursor : RewardSteps)
	{
		Q6JsonLogZagal(Warning, "Reward",
			Q6KV("Type", ENUM_TO_STRING(ERewardSequence, Cursor.RewardSequence)));
	}

	// Save to file
	GameInstance->InitRewardRecord(FRewardRecord(InDesc.SagaType, RewardSteps, InRewardInfos, InBondRewards), true);
}

void URewardManager::SetWaveSpawnUnitKillReward(const TArray<FWaveSpawnUnitKillRewardInfo>& InWaveSpawnUnitKillRewardInfos)
{
	WaveSpawnUnitKillRewardInfos = InWaveSpawnUnitKillRewardInfos;
}

void URewardManager::AddBond(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps)
{
	if (!InDesc.bBondReward)
	{
		return;
	}

	FRewardStep Step;
	Step.RewardSequence = ERewardSequence::Bond;
	OutRewardSteps.Add(Step);
}

void URewardManager::AddOutro(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps)
{
	if (InDesc.SagaType == SagaTypeInvalid)
	{
		return;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InDesc.SagaType);
	if (IsStoryLikeStageType(SagaRow.StageType))
	{
		return;
	}

	FRewardStep Step;
	Step.RewardSequence = ERewardSequence::Outro;
	Step.EventContentType = InDesc.EventContentType;

	bool bAddRewardSteps = false;

	switch (SagaRow.ContentType)
	{
		case EContentType::Saga:
		case EContentType::Event:
		case EContentType::MultiSideBattle:
			bAddRewardSteps = (SagaRow.StageType != EStageType::Battle);
			break;
		case EContentType::RaidFinal:
			bAddRewardSteps = true;
			break;
		case EContentType::Special:
			if (SagaRow.StageType != EStageType::Battle)
			{
				const USpecialManager& SpecialManager = GetHUDStore().GetSpecialManager();
				ESpecialCategory Category = SpecialManager.GetSpecialCategory(SagaRow.Episode);

				if (Category == ESpecialCategory::Saga)
				{
					bAddRewardSteps = SpecialManager.IsFirstClearBossStage(SagaRow.Episode, SagaRow.Stage);
				}
				else
				{
					bAddRewardSteps = true;
				}
			}
			break;
		case EContentType::TrainingCenter:
			if (GetHUDStore().GetTrainingCenterManager().IsLastSagaOnStep(InDesc.SagaType))
			{
				Step.TrainingCenterType = GetHUDStore().GetTrainingCenterManager().GetHistory().Type;
				bAddRewardSteps = true;
			}
			break;
	}

	if (bAddRewardSteps)
	{
		OutRewardSteps.Add(Step);
	}
}

void URewardManager::AddWeedGrow(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps)
{
	if (InDesc.WeedGrowType == WeedGrowTypeInvalid)
	{
		return;
	}

	FRewardStep Step;
	Step.RewardSequence = ERewardSequence::WeedGrow;
	Step.WeedGrowType = InDesc.WeedGrowType;
	OutRewardSteps.Add(Step);
}

void URewardManager::AddRewards(const FEndRewardDesc& InDesc, const TArray<FRewardInfo>& RewardInfos, TArray<FRewardStep>& OutRewardSteps)
{
	FRewardStep Step;

	for (int32 i = 0; i < RewardInfos.Num(); i++)
	{
		ESagaRewardType RewardType = RewardInfos[i].Type;

		if (RewardType == ESagaRewardType::InitialClear)
		{
			Step.RewardSequence = ERewardSequence::StageClear;
			Step.RewardIndex = i;
			OutRewardSteps.Add(Step);
		}
		else if (RewardType == ESagaRewardType::DailyFirstClear)
		{
			Step.RewardSequence = ERewardSequence::DailyFirstClear;
			Step.RewardIndex = i;
			OutRewardSteps.Add(Step);
		}
		else if (RewardType == ESagaRewardType::TrainingCenterPhaseClear)
		{
			Step.RewardSequence = ERewardSequence::TrainingPhaseClear;
			Step.RewardIndex = i;
			OutRewardSteps.Add(Step);
		}
		else if (RewardType == ESagaRewardType::EpisodeClear)
		{
			Step.RewardSequence = ERewardSequence::EpisodeClear;
			Step.RewardIndex = i;
			OutRewardSteps.Add(Step);
		}
	}

	const FCMSContentFeatureOpenRow& Row = GetCMS()->GetContentFeatureOpenRowOrDummy(
		InDesc.ContentFeatureOpenType);
	if (Row.IsInvalid())
	{
		return;
	}

	switch (Row.OpenType)
	{
		case EFeatureOpenType::WonderPetPark:
		case EFeatureOpenType::WonderPowerplant:
		case EFeatureOpenType::WonderPyramid:
		case EFeatureOpenType::WonderTemple:
		case EFeatureOpenType::WonderVacation:
		case EFeatureOpenType::WonderAlchemyLab:
		case EFeatureOpenType::WonderSmelter:
		{
			Step.ContentFeatureOpenType = InDesc.ContentFeatureOpenType;
			Step.RewardSequence = ERewardSequence::WonderOpen;
			OutRewardSteps.Add(Step);
		}
		break;
		case EFeatureOpenType::Artifact:
		case EFeatureOpenType::Pet:
		case EFeatureOpenType::PetSecondSkill:
		case EFeatureOpenType::PetThirdSkill:
		case EFeatureOpenType::VacationSpot:
		{
			Step.ContentFeatureOpenType = InDesc.ContentFeatureOpenType;
			Step.RewardSequence = ERewardSequence::WonderReward;
			OutRewardSteps.Add(Step);
		}
		break;
	}
}

void URewardManager::AddFoundRaid(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps)
{
	if (!GetHUDStore().GetRaidManager().IsRaidFound())
	{
		return;
	}

	FRewardStep Step;
	Step.RewardSequence = ERewardSequence::FoundRaid;
	OutRewardSteps.Add(Step);
}

void URewardManager::AddTitle(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps)
{
	if (GetHUDStore().GetRaidManager().IsRaidFound())
	{
		return;
	}

	if (InDesc.UserTitleType == UserTitleTypeInvalid)
	{
		return;
	}

	FRewardStep Step;
	Step.RewardSequence = ERewardSequence::Title;
	Step.UserTitleType = InDesc.UserTitleType;
	OutRewardSteps.Add(Step);
}

void URewardManager::AddContentOpen(const FEndRewardDesc& InDesc, TArray<FRewardStep>& OutRewardSteps)
{
	if (GetHUDStore().GetRaidManager().IsRaidFound())
	{
		return;
	}

	if (InDesc.ContentFeatureOpenType == ContentFeatureOpenTypeInvalid)
	{
		return;
	}

	FRewardStep Step;
	Step.RewardSequence = ERewardSequence::ContentOpenGuide;
	Step.ContentFeatureOpenType = InDesc.ContentFeatureOpenType;

	OutRewardSteps.Add(Step);
}

void URewardManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(URewardManager, SagaStageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, DailyStageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, TrainingCenterStageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, SpecialStageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, RaidFinalStageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentCollabo01StageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentValentineDayStageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentMultiSideBattleStageBeginResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URewardManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URewardManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(URewardManager, VacationEndResp);
	REGISTER_ACTION_HANDLER(URewardManager, VacationUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(URewardManager, AuthEnterLobbyFinalResp);
}


IMPLEMENT_ACTION_HANDLER(URewardManager, SagaStageBeginResp)
{
	auto Action = ACTION_PARSE_SagaStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	SetClearReward(Res.GainXp, Res.RewardInfos);
	SetWaveSpawnUnitKillReward(Res.WaveSpawnUnitKillRewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, DailyStageBeginResp)
{
	auto Action = ACTION_PARSE_DailyStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	SetClearReward(Res.GainXp, Res.RewardInfos);
	SetWaveSpawnUnitKillReward(Res.WaveSpawnUnitKillRewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, TrainingCenterStageBeginResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	SetClearReward(Res.GainXp, Res.RewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, SpecialStageBeginResp)
{
	auto Action = ACTION_PARSE_SpecialStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	SetClearReward(Res.GainXp, Res.RewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, RaidFinalStageBeginResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	TArray<FRewardInfo> DummyRewardInfos;
	SetClearReward(Res.GainXp, DummyRewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentCollabo01StageBeginResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageBeginResp(InAction);

	auto& Res = Action->GetVal();
	SetClearReward(Res.GainXp, Res.RewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentValentineDayStageBeginResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	SetClearReward(Res.GainXp, Res.RewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentMultiSideBattleStageBeginResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageBeginResp(InAction);

	auto& Res = Action->GetVal();
	SetClearReward(Res.GainXp, Res.RewardInfos);
	return true;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;

	WaveSpawnUnitKillRewardInfos.Empty();

	SetClearReward(StageReward.GainXp, Res.RewardInfos);	// Reset stage clear reward info
	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.Type;
	Desc.WeedGrowType = Res.WeedGrowType;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;
	Desc.UserTitleType = Res.Title;

	if (Res.ContentFeatureOpenInfos.Num() > 0)
	{
		Desc.ContentFeatureOpenType = Res.ContentFeatureOpenInfos.Last().Type;
	}

	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	const auto& Res = Action->GetVal();

	FSagaType SagaType = UQ6GameInstance::Get(this)->GetCombatSeed().SagaType;

	FEndRewardDesc Desc;
	Desc.SagaType = SagaType;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;
	Desc.UserTitleType = Res.Title;

	if (Res.ContentFeatureOpenInfos.Num() > 0)
	{
		Desc.ContentFeatureOpenType = Res.ContentFeatureOpenInfos.Last().Type;
	}

	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	const auto& Res = Action->GetVal();

	FSagaType SagaType = UQ6GameInstance::Get(this)->GetCombatSeed().SagaType;

	FEndRewardDesc Desc;
	Desc.SagaType = SagaType;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;

	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;

	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;
	Desc.UserTitleType = Res.Title;
	Desc.EventContentType = Res.EventContentInfo.Type;

	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;
	Desc.UserTitleType = Res.Title;
	Desc.EventContentType = Res.EventContentInfo.Type;

	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	const auto& Res = Action->GetVal();

	const FCMSEventContentMultiSideBattleStageRow& Row =
		GetCMS()->GetEventContentMultiSideBattleStageRowOrDummy(FEventContentMultiSideBattleStageType(Res.EventContentCategoryInfo.EventContentCategoryType));

	FEndRewardDesc Desc;
	Desc.SagaType = Row.GetSaga().CmsType();
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;
	Desc.UserTitleType = Res.Title;
	Desc.EventContentType = Res.EventContentInfo.Type;

	SetEndReward(Desc, Res.RewardInfos, Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.Type;
	Desc.WeedGrowType = Res.WeedGrowType;
	Desc.bBondReward = false;
	Desc.UserTitleType = Res.Title;

	if (Res.ContentFeatureOpenInfos.Num() > 0)
	{
		Desc.ContentFeatureOpenType = Res.ContentFeatureOpenInfos.Last().Type;
	}

	SetEndReward(Desc, Res.RewardInfos);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = false;
	Desc.UserTitleType = Res.Title;

	SetEndReward(Desc, Res.RewardInfos);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = false;
	Desc.EventContentType = Res.EventContentInfo.Type;

	SetEndReward(Desc, Res.RewardInfos);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = false;
	Desc.UserTitleType = Res.Title;
	Desc.EventContentType = Res.EventContentInfo.Type;

	SetEndReward(Desc, Res.RewardInfos);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.SagaType = Res.SagaType;
	Desc.bBondReward = false;
	Desc.UserTitleType = Res.Title;
	Desc.EventContentType = Res.EventContentInfo.Type;

	SetEndReward(Desc, Res.RewardInfos);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, VacationEndResp)
{
	auto Action = ACTION_PARSE_VacationEndResp(InAction);
	const auto& Res = Action->GetVal();

	FEndRewardDesc Desc;
	Desc.bBondReward = Res.BondLevelUpRewards.Num() != 0;

	SetEndReward(Desc, TArray<FRewardInfo>(), Res.BondLevelUpRewards);

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, VacationUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_VacationUpgradeCompleteResp(InAction);
	const auto& Res = Action->GetVal();

	FRewardInfo RewardInfo;
	RewardInfo.Type = ESagaRewardType::InitialClear;

	for (const FSpecialRecord& SpecialRecord : Res.SpecialRecords)
	{
		const FCMSSpecialRow* SpecialRow = GetCMS()->GetSpecialRow(ESpecialCategory::Vacation, SpecialRecord.Episode);
		if (!SpecialRow)
		{
			continue;
		}

		FItemData ItemData;
		ItemData.Type = SpecialRow->Type;
		ItemData.Category = ELootCategory::Special;
		ItemData.Count = 1;
		RewardInfo.ItemList.Add(ItemData);
	}

	if (RewardInfo.ItemList.Num())
	{
		SetVacationReward(RewardInfo);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(URewardManager, AuthEnterLobbyFinalResp)
{
	auto Action = ACTION_PARSE_AuthEnterLobbyFinalResp(InAction);
	const auto& Res = Action->GetVal();

	SetClearReward(0, Res.RewardInfos);
	SetWaveSpawnUnitKillReward(Res.WaveSpawnUnitKillRewardInfos);

	return false;
}
