#pragma once

#include "Q6ClientNetwork.h"
#include "Q6Define.h"
#include "Q6GameState.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "CharMissionManager.generated.h"

UCLASS()
class Q6_API UCharMissionManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UCharMissionManager();

	void ReqList(int32 PageNo = 0) const;
	void ReqReward(FCharacterType Type, int32 Index) const;

	TArray<FCCCharacterMissionInfo> GetCombatCharacterMission(const int32 PartyId) const;
	const TArray<FCharMissionInfo>& GetCharMission() const { return CharMissionInfos; }
	const FCharMissionInfo* GetCharMissionByCharacterType(const FCharacterType& InCharacterType) const;
	const int32 GetMaxValue(const FCharMissionType& Type) const;

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CCharMissionListResp& Msg);
	void OnReceiveRewardResp(
		const FResError* Error,
		const FL2CCharMissionReceiveRewardResp& Resp);

private:
	DECLARE_ACTION_HANDLER(ClearCharMission);
	DECLARE_ACTION_HANDLER(CharMissionListResp);
	DECLARE_ACTION_HANDLER(CharMissionRewardResp);
	DECLARE_ACTION_HANDLER(DevCharMissionSetResp);
	DECLARE_ACTION_HANDLER(CharacterAddXpResp);
	DECLARE_ACTION_HANDLER(CharacterTurnSkillLevelResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);

	DECLARE_ACTION_HANDLER(UpdateCharMission);

	FCharMissionInfo* Find(FCharacterType Type);
	void Update(const FCharMissionInfo& Info);

	TArray<FCharMissionInfo> CharMissionInfos;

	TSet<ECharMissionCategory> CombatCharMissionCategories;
};
