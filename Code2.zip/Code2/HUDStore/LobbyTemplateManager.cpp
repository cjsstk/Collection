#include "LobbyTemplateManager.h"

#include "HSAction.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"

void DumpLobbyTemplate(const FLobbyTemplateInfo& Info)
{
	Q6JsonLogPaul(Verbose, "",
		Q6KV("Id", Info.LobbyTemplateId),
		Q6KV("Type", Info.Type),
		Q6KV("Newly", Info.Newly),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));
}

ULobbyTemplateManager::ULobbyTemplateManager()
{
	InitStore(EHSType::LobbyTemplate);

	// sunny-hard-coded-default-data
	DefaultTemplateInfo.LobbyTemplateId = FLobbyTemplateId();
	DefaultTemplateInfo.Type = FLobbyTemplateType(1);
	DefaultTemplateInfo.Newly = 0;
	DefaultTemplateInfo.Created = 0;
}

const FLobbyTemplateInfo& ULobbyTemplateManager::GetLobbyTemplateInfo(FLobbyTemplateId InLobbyTemplateId) const
{
	if (LobbyTemplates.Contains(InLobbyTemplateId))
	{
		return LobbyTemplates[InLobbyTemplateId].GetInfo();
	}

	return DefaultTemplateInfo;
}

bool ULobbyTemplateManager::HasLobbyTemplate(FLobbyTemplateType InLobbyTemplateType) const
{
	if (InLobbyTemplateType == LobbyTemplateTypeInvalid)
	{
		return true;
	}

	for (const auto& Item : LobbyTemplates)
	{
		const FLobbyTemplate& LobbyTemplate = Item.Value;
		if (LobbyTemplate.GetInfo().Type == InLobbyTemplateType)
		{
			return true;
		}
	}

	return false;
}

void ULobbyTemplateManager::Dump() const
{
	Q6JsonLogPaul(Verbose, "== LobbyTemplates ==",
		Q6KV("Total", LobbyTemplates.Num()));
	for (const auto& Item : LobbyTemplates)
	{
		const FLobbyTemplate& LobbyTemplate = Item.Value;
		DumpLobbyTemplate(LobbyTemplate.GetInfo());
	}
}

void ULobbyTemplateManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearLobbyTemplate();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LLobbyTemplateList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("lobbyTemplate/list"), Out,
		TQ6ResponseDelegate<FL2CLobbyTemplateListResp>::CreateUObject(
			const_cast<ULobbyTemplateManager*>(this), &ULobbyTemplateManager::OnListResp));
}

void ULobbyTemplateManager::OnListResp(const FResError* Error, const FL2CLobbyTemplateListResp& Res)
{
	Q6JsonLogPaul(Warning, "lobbyTemplate list resp");

	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ACTION_DISPATCH_LobbyTemplateListResp(Res);

	if (Res.PageNo >= (Res.PageTotal - 1))
	{
		// TODO: refresh UI, list finished
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	const int MaxPage = 1000;
	if (Res.PageTotal >= MaxPage ||
		Res.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogPaul(Warning, "Max Page Over",
			Q6KV("PageNo", Res.PageNo),
			Q6KV("PageTotal", Res.PageTotal));
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ReqList(Res.PageNo + 1);
}

void ULobbyTemplateManager::ReqClearNew(const FLobbyTemplateId& Id) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LLobbyTemplateClearNew Out;
	Out.LobbyTemplateId = Id;

	ClientNetwork.WsRequest(TEXT("lobbyTemplate/clearNew"), Out,
		TQ6ResponseDelegate<FL2CLobbyTemplateClearNewResp>::CreateUObject(
			const_cast<ULobbyTemplateManager*>(this), &ULobbyTemplateManager::OnClearNewResp));
}

void ULobbyTemplateManager::OnClearNewResp(const FResError* Error, const FL2CLobbyTemplateClearNewResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_LobbyTemplateClearNewResp(Res);
}

/////////////////////////////////////////////////////////////////////////////
// ULobbyTemplateManager HUDStore Action

void ULobbyTemplateManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, ClearLobbyTemplate);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, LobbyTemplateListResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, LobbyTemplateClearNewResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, SummonPickupResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, EventContentMultisideBattleReceiveRankRewardResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, DevLobbyTemplateNewResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(ULobbyTemplateManager, DevTrainingCenterClearResp);
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, ClearLobbyTemplate)
{
	LobbyTemplates.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, LobbyTemplateListResp)
{
	auto Action = ACTION_PARSE_LobbyTemplateListResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
		if (Info.Type == DefaultTemplateInfo.Type)
		{
			DefaultTemplateInfo = Info;
		}
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, LobbyTemplateClearNewResp)
{
	auto Action = ACTION_PARSE_LobbyTemplateClearNewResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, SummonPickupResp)
{
	auto Action = ACTION_PARSE_SummonPickupResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, DevLobbyTemplateNewResp)
{
	auto Action = ACTION_PARSE_DevLobbyTemplateNewResp(InAction);
	auto& Res = Action->GetVal();

	return Add(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(ULobbyTemplateManager, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FLobbyTemplateInfo& Info : Res.LobbyTemplates)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

/////////////////////////////////////////////////////////////////////////////
// ULobbyTemplateManager Setter

bool ULobbyTemplateManager::Add(const FLobbyTemplateInfo& Info)
{
	LobbyTemplates.Add(Info.LobbyTemplateId, Info);
	return true;
}
