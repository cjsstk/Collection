#pragma once

#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "FriendManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
class FFriendNotifyHandler;

struct FFriendInfoEx : FFriendInfo
{
	explicit FFriendInfoEx(const FFriendInfo& FriendInfo)
		: FFriendInfo(FriendInfo)
		, Hp(0)
		, Atk(0)
		, Def(0)
	{
	}
	mutable int32 Hp; // buffer for sort, calculated just before sort
	mutable int32 Atk; // buffer for sort, calculated just before sort
	mutable int32 Def; // buffer for sort, calculated just before sort
};

///////////////////////////////////////////////////////////////////////////////////////////
// UFriendManager
UCLASS()
class Q6_API UFriendManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UFriendManager();
	~UFriendManager();

	void InitNotifyHandler();

	// Req
	void ReqFriendList() const;
	void ReqFriendCooltimeList(int32 PageNo = 0) const;
	void ReqFriendCandidates() const;
	void ReqFriendSearch(const FString& UserCode) const;
	void ReqFriendRequest(const FFriendInfo& FriendInfo) const;
	void ReqFriendDecline(const FFriendInfo& FriendInfo) const;
	void ReqFriendAccept(const FFriendInfo& FriendInfo) const;
	void ReqFriendRemove(const FFriendInfo& FriendInfo) const;
	void ReqFriendConfirm() const;

	TArray<const FFriendInfoEx*> GetConnectedFriends() const;
	TArray<const FFriendInfoEx*> GetReceivingFriends() const;
	TArray<const FFriendInfoEx*> GetCandidates() const;
	const FFriendInfoEx* GetFriendInfo(FUserId FriendUserId) const;
	int32 GetFriendCount() const { return Connected.Num(); }
	bool IsRecommendedFriend() const { return bRecommendedFriend; }
	const FFriendInfo& GetFriendCandidate() const { return FriendCandidate; }
	EJokerSlotType GetJokerSlotType() const { return JokerSlot; }

	bool IsConfirmedReceiving(FFriendId FriendId) const { return ConfirmedReceivings.Contains(FriendId); }
	int32 GetCooltime(FUserId UserId) const;

#if !UE_BUILD_SHIPPING
	int32 GetDevCooltime() const { return DevCooltime; }
#endif

protected:
	virtual void OnError(const FResError* Error) const override;
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnFriendLoadResp(const FResError* Error, const FL2CFriendLoadResp& Res);
	void OnFriendCooltimeListResp(const FResError* Error, const FL2CFriendCooltimeListResp& Res);
	void OnFriendCandidatesResp(const FResError* Error, const FL2CFriendCandidatesResp& Res);
	void OnFriendSearchResp(const FResError* Error, const FL2CFriendSearchResp& Res);
	void OnFriendRequestResp(const FResError* Error, const FL2CFriendRequestResp& Res);
	void OnFriendDeclineResp(const FResError* Error, const FL2CFriendDeclineResp& Res);
	void OnFriendAcceptResp(const FResError* Error, const FL2CFriendAcceptResp& Res);
	void OnFriendRemoveResp(const FResError* Error, const FL2CFriendRemoveResp& Res);
	void OnFriendConfirmResp(const FResError* Error, const FL2CFriendConfirmResp& Res);

	void UpdateConnected(const TArray<FFriendInfo>& InConnected);
	void UpdateReceiving(const TArray<FFriendInfo>& InReceiving);
	void UpdateCandidates(const TArray<FFriendInfo>& InCandidates);

	void AddCooltime(const FFriendCooltime& Cooltime);

	// On Actions
	DECLARE_ACTION_HANDLER(NetworkReconnected);
	DECLARE_ACTION_HANDLER(SystemJoker);
	DECLARE_ACTION_HANDLER(FriendJoker);
	DECLARE_ACTION_HANDLER(FriendJokerFromPopup);
	DECLARE_ACTION_HANDLER(FriendLoadResp);
	DECLARE_ACTION_HANDLER(FriendCooltimeListResp);
	DECLARE_ACTION_HANDLER(FriendCandidatesResp);
	DECLARE_ACTION_HANDLER(FriendErrorResp);
	DECLARE_ACTION_HANDLER(FriendSearchResp);
	DECLARE_ACTION_HANDLER(FriendRequestResp);
	DECLARE_ACTION_HANDLER(FriendDeclineResp);
	DECLARE_ACTION_HANDLER(FriendAcceptResp);
	DECLARE_ACTION_HANDLER(FriendRemoveResp);
	DECLARE_ACTION_HANDLER(FriendConfirmResp);
	DECLARE_ACTION_HANDLER(FriendNotifyAccept);
	DECLARE_ACTION_HANDLER(FriendNotifyRemove);
	DECLARE_ACTION_HANDLER(FriendNotifyJokerSetChange);
	DECLARE_ACTION_HANDLER(FriendNotifyRequest);
	DECLARE_ACTION_HANDLER(FriendNotifyAvatarChange);
	DECLARE_ACTION_HANDLER(FriendNotifyNicknameChanged);
	DECLARE_ACTION_HANDLER(DevFriendBotAllResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(DevFriendCooltimeResp);

	TMap<FFriendId, FFriendInfoEx> Connected;
	TMap<FFriendId, FFriendInfoEx> Receiving;
	TArray<FFriendId> ConfirmedReceivings;
	TArray<FFriendInfo> Pending; // can be used to check before request, but currently not using
	TArray<FFriendInfoEx> Candidates;
	FFriendInfo FriendCandidate;
	EJokerSlotType JokerSlot;
	bool bRecommendedFriend;

	FFriendNotifyHandler* FriendNotifyHandlerInstance;
	TArray<FFriendCooltime> Cooltimes;

#if !UE_BUILD_SHIPPING
	int32 DevCooltime;
#endif
};
