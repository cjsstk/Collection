#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "BondManager.generated.h"

UCLASS()
class Q6_API UBondManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UBondManager();
	~UBondManager();

public:
	void ReqLoad() const;
	void UpdateCharacterBonds(const TArray<FCharacterBond>& InCharacterBonds);

	const FCharacterBond* Find(FCharacterType CharacterType) const { return CharacterBonds.Find(CharacterType); }
	const TMap<FCharacterType, FBondHistory>& GetHistories() const { return BondHistories; }

	const FCharacterBond& GetCharacterBond(FCharacterType CharacterType) const;
	int32 GetSupportSkillLevel(FCharacterType CharacterType) const;
protected:
	virtual void RegisterActionHandlers() override;

private:
	void OnLoadResp(const FResError* Error, const FL2CBondLoadResp& Msg);
	void UpdateCharacterBond(const FCharacterBond& InCharacterBond);

	DECLARE_ACTION_HANDLER(BondLoadResp);
	DECLARE_ACTION_HANDLER(DevBondAddResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(VacationEndResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);

private:
	TMap<FCharacterType, FCharacterBond> CharacterBonds;
	TMap<FCharacterType, FBondHistory> BondHistories;
};
