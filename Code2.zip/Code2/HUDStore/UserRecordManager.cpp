#include "UserRecordManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"

UUserRecordManager::UUserRecordManager()
{
	InitStore(EHSType::UserRecord);
}

void UUserRecordManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_UserRecordRows();
		ACTION_DISPATCH_ClearUserRecord();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LUserRecordList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("userRecord/list"), Out,
		TQ6ResponseDelegate<FL2CUserRecordListResp>::CreateUObject(
			const_cast<UUserRecordManager*>(this), &UUserRecordManager::OnListResp));
}

void UUserRecordManager::ReqResurrectionCount() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LUserRecordRezCount Out;

	ClientNetwork.WsRequest(TEXT("userRecord/rezCount"), Out,
		TQ6ResponseDelegate<FL2CUserRecordRezCountResp>::CreateUObject(
			const_cast<UUserRecordManager*>(this), &UUserRecordManager::OnRezCountResp));
}


void UUserRecordManager::OnListResp(const FResError* Error, const FL2CUserRecordListResp& Msg)
{
	Q6JsonLogHekel(Warning, "user record list resp");

	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_UserRecordListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void UUserRecordManager::OnRezCountResp(const FResError* Error, const FL2CUserRecordRezCountResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_UserRecordRezCountResp(Msg);
}

int32 UUserRecordManager::GetResurrectionCount() const
{
	const FUserRecordType RezCountUserRecordType = FUserRecordType(42);

	const FUserRecordInfo* Found = Records.Find(RezCountUserRecordType);
	if (!Found)
	{
		return 0;
	}

	return Found->Val;
}

void UUserRecordManager::UpdateRecord(const FUserRecordInfo& Info)
{
	FUserRecordInfo* Found = Records.Find(Info.Type);
	if (Found)
	{
		if (Found->UserRecordId == Info.UserRecordId)
		{
			*Found = Info;
			return;
		}
	}

	Records.Emplace(Info.Type, Info);
}

void UUserRecordManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UUserRecordManager, ClearUserRecord);
	REGISTER_ACTION_HANDLER(UUserRecordManager, UserRecordListResp);
	REGISTER_ACTION_HANDLER(UUserRecordManager, UserRecordRezCountResp);

	// UI
	REGISTER_ACTION_HANDLER(UUserRecordManager, UserRecordRows);
}

IMPLEMENT_ACTION_HANDLER(UUserRecordManager, ClearUserRecord)
{
	Records.Empty();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UUserRecordManager, UserRecordListResp)
{
	auto Action = ACTION_PARSE_UserRecordListResp(InAction);
	auto& Res = Action->GetVal();

	for (const FUserRecordInfo& Info : Res.Records)
	{
		UpdateRecord(Info);
	}

	return Res.PageNo >= (Res.PageTotal - 1);
}

IMPLEMENT_ACTION_HANDLER(UUserRecordManager, UserRecordRezCountResp)
{
	auto Action = ACTION_PARSE_UserRecordRezCountResp(InAction);
	auto& Res = Action->GetVal();

	UpdateRecord(Res.Record);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UUserRecordManager, UserRecordRows)
{
	if (RecordRows.Num() != 0)
	{
		return false;
	}

	const UCMS* CMS = GetCMS();
	if (!CMS)
	{
		return false;
	}

	CMS->GetUserRecordRows(RecordRows);

	return false;
}