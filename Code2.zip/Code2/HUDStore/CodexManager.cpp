#include "CodexManager.h"

#include "Q6.h"
#include "Q6GameInstance.h"
#include "SortingWidgets.h"
#include "UIStateManager.h"

UCodexManager::UCodexManager()
{
	InitStore(EHSType::Codex);
}

void UCodexManager::Dump() const
{
	DumpChar();
	DumpSculpture();
	DumpRelic();
}

void UCodexManager::DumpChar() const
{
	Q6JsonLogHekel(Verbose, "Characters", Q6KV("Size", Chars.Num()));
	for (const auto& It : Chars)
	{
		const FCodexCharInfo& Info = It.Value;
		Q6JsonLogHekel(Verbose, "",
			Q6KV("Id", Info.CodexCharId),
			Q6KV("Type", Info.Type),
			Q6KV("Newly", Info.Newly),
			Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));

	}
}

void UCodexManager::DumpSculpture() const
{
	Q6JsonLogHekel(Verbose, "Sculptures", Q6KV("Size", Sculptures.Num()));
	for (const auto& It : Sculptures)
	{
		const FCodexSculptureInfo& Info = It.Value;
		Q6JsonLogHekel(Verbose, "",
			Q6KV("Id", Info.CodexSculptureId),
			Q6KV("Type", Info.Type),
			Q6KV("Newly", Info.Newly),
			Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));

	}
}

void UCodexManager::DumpRelic() const
{
	Q6JsonLogHekel(Verbose, "Relics", Q6KV("Size", Relics.Num()));
	for (const auto& It : Relics)
	{
		const FCodexRelicInfo& Info = It.Value;
		Q6JsonLogHekel(Verbose, "",
			Q6KV("Id", Info.CodexRelicId),
			Q6KV("Type", Info.Type),
			Q6KV("Newly", Info.Newly),
			Q6KV("Created", Q6Util::GetLocalDateText(Info.Created).ToString()));

	}
}


const FCodexCharInfo* UCodexManager::FindChar(const FCharacterType& Type) const
{
	return Chars.Find(Type);
}

const FCodexSculptureInfo* UCodexManager::FindSculpture(const FSculptureType& Type) const
{
	return Sculptures.Find(Type);
}

const FCodexRelicInfo* UCodexManager::FindRelic(const FRelicType& Type) const
{
	return Relics.Find(Type);
}

TArray<const FCMSCharacterRow*> UCodexManager::GetCodexCharacterRows() const
{
	TArray<const FCMSCharacterRow*> Rows;
	TArray<const FCMSCharacterRow*> SubRows;
	GetCMS()->GetCodexCharacterRows(Chars, Rows, SubRows);

	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(ESortMenu::Codex, ESortCategory::NotOwnedCharacter);
	FSortOrdering::Sort(SortingOption, Rows);
	FSortOrdering::Sort(SortingOption, SubRows);

	Rows.Append(SubRows);
	return Rows;
}

TArray<const FCMSSculptureRow*> UCodexManager::GetCodexSculptureRows() const
{
	TArray<const FCMSSculptureRow*> Rows;
	TArray<const FCMSSculptureRow*> SubRows;
	GetCMS()->GetCodexSculptureRows(Sculptures, Rows, SubRows);

	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(ESortMenu::Codex, ESortCategory::NotOwnedSculpture);
	FSortOrdering::Sort(SortingOption, Rows);
	FSortOrdering::Sort(SortingOption, SubRows);

	Rows.Append(SubRows);
	return Rows;
}

TArray<const FCMSRelicRow*> UCodexManager::GetCodexRelicRows() const
{
	TArray<const FCMSRelicRow*> Rows;
	TArray<const FCMSRelicRow*> SubRows;
	GetCMS()->GetCodexRelicRows(Relics, Rows, SubRows);

	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(ESortMenu::Codex, ESortCategory::NotOwnedRelic);
	FSortOrdering::Sort(SortingOption, Rows);
	FSortOrdering::Sort(SortingOption, SubRows);

	Rows.Append(SubRows);
	return Rows;
}

void UCodexManager::ReqListChar(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearCodexChar();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexListChar Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("codex/listChar"), Out,
		TQ6ResponseDelegate<FL2CCodexListCharResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnListCharResp));
}

void UCodexManager::ReqListSculpture(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearCodexSculpture();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexListChar Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("codex/listSculpture"), Out,
		TQ6ResponseDelegate<FL2CCodexListSculptureResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnListSculptureResp));
}

void UCodexManager::ReqListRelic(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearCodexRelic();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexListChar Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("codex/listRelic"), Out,
		TQ6ResponseDelegate<FL2CCodexListRelicResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnListRelicResp));
}

void UCodexManager::ReqClearNewChar(FCodexCharId Id) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexClearNewChar Out;
	Out.Id = Id;

	ClientNetwork.WsRequest(TEXT("codex/clearNewChar"), Out,
		TQ6ResponseDelegate<FL2CCodexClearNewCharResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnClearNewCharResp));
}

void UCodexManager::ReqClearNewSculpture(FCodexSculptureId Id) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexClearNewSculpture Out;
	Out.Id = Id;

	ClientNetwork.WsRequest(TEXT("codex/clearNewSculpture"), Out,
		TQ6ResponseDelegate<FL2CCodexClearNewSculptureResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnClearNewSculptureResp));
}

void UCodexManager::ReqClearNewRelic(FCodexRelicId Id) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexClearNewRelic Out;
	Out.Id = Id;

	ClientNetwork.WsRequest(TEXT("codex/clearNewRelic"), Out,
		TQ6ResponseDelegate<FL2CCodexClearNewRelicResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnClearNewRelicResp));
}


void UCodexManager::ReqClearNewCharacterAll(const TArray<FCodexCharId>& Ids) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexClearNewAll Out;
	Out.CharIds = Ids;

	ClientNetwork.WsRequest(TEXT("codex/clearNewAll"), Out,
		TQ6ResponseDelegate<FL2CCodexClearNewAllResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnClearNewAllResp));
}

void UCodexManager::ReqClearNewSculptureAll(const TArray<FCodexSculptureId>& Ids) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexClearNewAll Out;
	Out.SculptureIds = Ids;

	ClientNetwork.WsRequest(TEXT("codex/clearNewAll"), Out,
		TQ6ResponseDelegate<FL2CCodexClearNewAllResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnClearNewAllResp));
}

void UCodexManager::ReqClearNewRelicAll(const TArray<FCodexRelicId>& Ids) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LCodexClearNewAll Out;
	Out.RelicIds = Ids;

	ClientNetwork.WsRequest(TEXT("codex/clearNewAll"), Out,
		TQ6ResponseDelegate<FL2CCodexClearNewAllResp>::CreateUObject(
			const_cast<UCodexManager*>(this), &UCodexManager::OnClearNewAllResp));
}

void UCodexManager::OnListCharResp(const FResError* Error, const FL2CCodexListCharResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_CodexListCharResp(Resp);

	if (Resp.PageNo >= (Resp.PageTotal - 1))
	{
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Resp.PageTotal >= MaxPage ||
		Resp.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Resp.PageNo),
			Q6KV("PageTotal", Resp.PageTotal));
		GameInstance->ReqNextContent();
		return;
	}

	ReqListChar(Resp.PageNo + 1);
}

void UCodexManager::OnListSculptureResp(const FResError* Error, const FL2CCodexListSculptureResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_CodexListSculptureResp(Resp);

	if (Resp.PageNo >= (Resp.PageTotal - 1))
	{
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Resp.PageTotal >= MaxPage ||
		Resp.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Resp.PageNo),
			Q6KV("PageTotal", Resp.PageTotal));
		GameInstance->ReqNextContent();
		return;
	}

	ReqListSculpture(Resp.PageNo + 1);
}


void UCodexManager::OnListRelicResp(const FResError* Error, const FL2CCodexListRelicResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_CodexListRelicResp(Resp);

	if (Resp.PageNo >= (Resp.PageTotal - 1))
	{
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Resp.PageTotal >= MaxPage ||
		Resp.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Resp.PageNo),
			Q6KV("PageTotal", Resp.PageTotal));
		GameInstance->ReqNextContent();
		return;
	}

	ReqListRelic(Resp.PageNo + 1);
}

void UCodexManager::OnClearNewCharResp(const FResError* Error, const FL2CCodexClearNewCharResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CodexClearNewCharResp(Resp);
}

void UCodexManager::OnClearNewSculptureResp(const FResError* Error, const FL2CCodexClearNewSculptureResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CodexClearNewSculptureResp(Resp);
}

void UCodexManager::OnClearNewRelicResp(const FResError* Error, const FL2CCodexClearNewRelicResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CodexClearNewRelicResp(Resp);
}

void UCodexManager::OnClearNewAllResp(const FResError* Error, const FL2CCodexClearNewAllResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_CodexClearNewAllResp(Resp);
}

void UCodexManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UCodexManager, ClearCodexChar);
	REGISTER_ACTION_HANDLER(UCodexManager, ClearCodexSculpture);
	REGISTER_ACTION_HANDLER(UCodexManager, ClearCodexRelic);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexListCharResp);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexListSculptureResp);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexListRelicResp);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexClearNewCharResp);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexClearNewSculptureResp);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexClearNewRelicResp);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexClearNewAllResp);
	REGISTER_ACTION_HANDLER(UCodexManager, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(UCodexManager, SummonPickupResp);
	REGISTER_ACTION_HANDLER(UCodexManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, VacationEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(UCodexManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UCodexManager, CharacterUnbindResp);

	// UI
	REGISTER_ACTION_HANDLER(UCodexManager, CodexClearCharNew);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexClearSculptureNew);
	REGISTER_ACTION_HANDLER(UCodexManager, CodexClearRelicNew);

	// Cheater
	REGISTER_ACTION_HANDLER(UCodexManager, DevCharacterNewResp);
	REGISTER_ACTION_HANDLER(UCodexManager, DevRelicNewResp);
	REGISTER_ACTION_HANDLER(UCodexManager, DevSculptureNewResp);
	REGISTER_ACTION_HANDLER(UCodexManager, DevAvatarAddResp);
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, ClearCodexChar)
{
	Chars.Empty();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, ClearCodexSculpture)
{
	Sculptures.Empty();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, ClearCodexRelic)
{
	Relics.Empty();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexListCharResp)
{
	auto Action = ACTION_PARSE_CodexListCharResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars)
	{
		Chars.Emplace(Codex.Type, Codex);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexListSculptureResp)
{
	auto Action = ACTION_PARSE_CodexListSculptureResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures)
	{
		Sculptures.Emplace(Codex.Type, Codex);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexListRelicResp)
{
	auto Action = ACTION_PARSE_CodexListRelicResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexRelicInfo& Codex : Res.CodexRelics)
	{
		Relics.Emplace(Codex.Type, Codex);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexClearNewCharResp)
{
	auto Action = ACTION_PARSE_CodexClearNewCharResp(InAction);
	auto& Res = Action->GetVal();

	for (auto& It : Chars)
	{
		if (It.Value.CodexCharId == Res.Codex.CodexCharId)
		{
			It.Value.Newly = 0;
			break;
		}
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexClearNewSculptureResp)
{
	auto Action = ACTION_PARSE_CodexClearNewSculptureResp(InAction);
	auto& Res = Action->GetVal();

	for (auto& It : Sculptures)
	{
		if (It.Value.CodexSculptureId == Res.Codex.CodexSculptureId)
		{
			It.Value.Newly = 0;
			break;
		}
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexClearNewRelicResp)
{
	auto Action = ACTION_PARSE_CodexClearNewRelicResp(InAction);
	auto& Res = Action->GetVal();

	for (auto& It : Relics)
	{
		if (It.Value.CodexRelicId == Res.Codex.CodexRelicId)
		{
			It.Value.Newly = 0;
			break;
		}
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexClearNewAllResp)
{
	auto Action = ACTION_PARSE_CodexClearNewAllResp(InAction);
	auto& Res = Action->GetVal();

	for (auto& It : Res.CodexChars)
	{
		FCodexCharInfo* CodexCharInfo = Chars.Find(It.Type);
		if (CodexCharInfo)
		{
			CodexCharInfo->Newly = 0;
		}
	}

	for (auto& It : Res.CodexSculptures)
	{
		FCodexSculptureInfo* CodexSculptureInfo = Sculptures.Find(It.Type);
		if (CodexSculptureInfo)
		{
			CodexSculptureInfo->Newly = 0;
		}
	}

	for (auto& It : Res.CodexRelics)
	{
		FCodexRelicInfo* CodexRelicInfo = Relics.Find(It.Type);
		if (CodexRelicInfo)
		{
			CodexRelicInfo->Newly = 0;
		}
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, SummonPickupResp)
{
	auto Action = ACTION_PARSE_SummonPickupResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars) {
		Chars.Emplace(Codex.Type, Codex);
	}

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures) {
		Sculptures.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CharacterUnbindResp)
{
	const auto& Action = ACTION_PARSE_CharacterUnbindResp(InAction);
	const auto& Res = Action->GetVal();

	const FCodexCharInfo& Codex = Res.CodexChar;
	Chars.Emplace(Codex.Type, Codex);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, VacationEndResp)
{
	auto Action = ACTION_PARSE_VacationEndResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexRelicInfo& Codex : Res.CodexRelics) {
		Relics.Emplace(Codex.Type, Codex);
	}
	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexClearCharNew)
{
	auto Action = ACTION_PARSE_CodexCharClearNew(InAction);
	auto& Res = Action->GetVal();

	FCodexCharInfo* CodexCharInfo = Chars.Find(Res);
	if (CodexCharInfo)
	{
		ReqClearNewChar(CodexCharInfo->CodexCharId);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexClearSculptureNew)
{
	auto Action = ACTION_PARSE_CodexSculptureClearNew(InAction);
	auto& Res = Action->GetVal();

	FCodexSculptureInfo* CodexSculptureInfo = Sculptures.Find(Res);
	if (CodexSculptureInfo)
	{
		ReqClearNewSculpture(CodexSculptureInfo->CodexSculptureId);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, CodexClearRelicNew)
{
	auto Action = ACTION_PARSE_CodexRelicClearNew(InAction);
	auto& Res = Action->GetVal();

	FCodexRelicInfo* CodexRelicInfo = Relics.Find(Res);
	if (CodexRelicInfo)
	{
		ReqClearNewRelic(CodexRelicInfo->CodexRelicId);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, DevCharacterNewResp)
{
	auto Action = ACTION_PARSE_DevCharacterNewResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexCharInfo& Codex : Res.CodexChars)
	{
		Chars.Emplace(Codex.Type, Codex);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, DevRelicNewResp)
{
	auto Action = ACTION_PARSE_DevRelicNewResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexRelicInfo& Codex : Res.CodexRelics)
	{
		Relics.Emplace(Codex.Type, Codex);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UCodexManager, DevSculptureNewResp)
{
	auto Action = ACTION_PARSE_DevSculptureNewResp(InAction);
	auto& Res = Action->GetVal();

	for (const FCodexSculptureInfo& Codex : Res.CodexSculptures)
	{
		Sculptures.Emplace(Codex.Type, Codex);
	}

	return true;
}


IMPLEMENT_ACTION_HANDLER(UCodexManager, DevAvatarAddResp)
{
	const auto& Action = ACTION_PARSE_DevAvatarAddResp(InAction);
	const auto& Res = Action->GetVal();

	if (Res.Category != EAvatarCategory::Character)
	{
		return false;
	}

	FCodexCharInfo* Info = Chars.Find(FCharacterType(Res.Type));
	if (!Info)
	{
		FCodexCharInfo NewInfo;
		NewInfo.CodexCharId = Res.Id;
		NewInfo.UserId = GetHUDStore().GetWorldUser().GetId();
		NewInfo.Type = FCharacterType(Res.Type);
		NewInfo.OpenedIllust = Res.Illust;
		NewInfo.Newly = Res.Newly;
		NewInfo.Created = Res.Created;
		Chars.Emplace(NewInfo.Type, NewInfo);
	}
	else
	{
		Info->OpenedIllust = Res.Illust;
	}

	return true;
}
