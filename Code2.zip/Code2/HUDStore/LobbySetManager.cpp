#include "LobbySetManager.h"
#include "HSAction.h"
#include "LobbyHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"

///////////////////////////////////////////////////////////////////////////////////////////
// ULobbySetManager

ULobbySetManager::ULobbySetManager()
{
	InitStore(EHSType::LobbySet);
}

const FLobbySetInfo& ULobbySetManager::GetSelectedLobbySetInfo() const
{
	for (const FLobbySetInfo& LobbySetInfo : LobbySetInfoList)
	{
		if (LobbySetInfo.LobbySetId == SelectedId)
		{
			return LobbySetInfo;
		}
	}

	static FLobbySetInfo DummyLobbySetInfo;
	DummyLobbySetInfo.LobbySetId = SelectedId;
	DummyLobbySetInfo.LobbyTemplateId = FLobbyTemplateId();
	DummyLobbySetInfo.CharacterIds.SetNumZeroed(MAX_LOBBY_TEMPLATE_CHAR_SLOT_COUNT);

	return DummyLobbySetInfo;
}

FLobbySetInfo ULobbySetManager::GetDummyLobbySetInfo(int32 InLobbySetId) const
{
	static FLobbySetInfo DummyLobbySetInfo;
	if (LobbySetInfoList.Num())
	{
		DummyLobbySetInfo = LobbySetInfoList[0];
	}
	else
	{
		DummyLobbySetInfo.LobbyTemplateId = FLobbyTemplateId();
		DummyLobbySetInfo.CharacterIds.SetNumZeroed(MAX_LOBBY_TEMPLATE_CHAR_SLOT_COUNT);
	}

	FLobbySetInfo OutLobbySetInfo = DummyLobbySetInfo;
	OutLobbySetInfo.LobbySetId = InLobbySetId;

	return OutLobbySetInfo;
}

void ULobbySetManager::ReqLobbySetLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LLobbySetLoad Out;

	ClientNetwork.WsRequest(TEXT("lobbySet/load"), Out,
		TQ6ResponseDelegate<FL2CLobbySetLoadResp>::CreateUObject(
			const_cast<ULobbySetManager*>(this), &ULobbySetManager::OnLobbySetLoadResp));
}

void ULobbySetManager::OnLobbySetLoadResp(const FResError* Error, const FL2CLobbySetLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_LobbySetLoadResp(Res);
	GameInstance->ReqNextContent();
}

void ULobbySetManager::ReqLobbySetSave(const FLobbySetInfo& InLobbySetInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LLobbySetSave Out;
	Out.LobbySetInfo = InLobbySetInfo;

	ClientNetwork.WsRequest("lobbySet/save", Out,
		TQ6ResponseDelegate<FL2CLobbySetSaveResp>::CreateUObject(
			const_cast<ULobbySetManager*>(this), &ULobbySetManager::OnLobbySetSaveResp));
}

void ULobbySetManager::OnLobbySetSaveResp(const FResError* Error, const FL2CLobbySetSaveResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_LobbySetSaveResp(Res);
}

void ULobbySetManager::ReqLobbySetUse(int32 LobbySetId) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LLobbySetUse Out;
	Out.LobbySetId = LobbySetId;

	ClientNetwork.WsRequest(TEXT("lobbySet/use"), Out,
		TQ6ResponseDelegate<FL2CLobbySetUseResp>::CreateUObject(
			const_cast<ULobbySetManager*>(this), &ULobbySetManager::OnLobbySetUseResp));
}

void ULobbySetManager::OnLobbySetUseResp(const FResError* Error, const FL2CLobbySetUseResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_LobbySetUseResp(Res);
}

bool ULobbySetManager::IsValidLobbySet(int32 InLobbySetId) const
{
	for (const FLobbySetInfo& LobbySetInfo : LobbySetInfoList)
	{
		if (LobbySetInfo.LobbySetId == InLobbySetId)
		{
			return true;
		}
	}

	return false;
}

void ULobbySetManager::SelectLobbySetToUse(int32 InLobbySetId) const
{
	if (IsValidLobbySet(InLobbySetId))
	{
		ReqLobbySetUse(InLobbySetId);
	}
	else
	{
		FLobbySetInfo DummyLobbySetInfo = GetDummyLobbySetInfo(InLobbySetId);
		ReqLobbySetSave(DummyLobbySetInfo);
	}
}

/////////////////////////////////////////////////////////////////////////////
// ULobbySetManager HUDStore Action

void ULobbySetManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(ULobbySetManager, LobbySetLoadResp);
	REGISTER_ACTION_HANDLER(ULobbySetManager, LobbySetSaveResp);
	REGISTER_ACTION_HANDLER(ULobbySetManager, LobbySetUseResp);
	REGISTER_ACTION_HANDLER(ULobbySetManager, CharacterAddXpResp);
	REGISTER_ACTION_HANDLER(ULobbySetManager, CharacterUltimateSkillLevelResp);
	REGISTER_ACTION_HANDLER(ULobbySetManager, CharacterRemoveResp);
	REGISTER_ACTION_HANDLER(ULobbySetManager, ShopSellItemResp);
}

IMPLEMENT_ACTION_HANDLER(ULobbySetManager, LobbySetLoadResp)
{
	auto Action = ACTION_PARSE_LobbySetLoadResp(InAction);

	auto& Resp = Action->GetVal();
	UpdateLobbySetList(Resp.LobbySetInfoList);
	UpdateSelectedLobbySet(Resp.SelectedId, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(ULobbySetManager, LobbySetSaveResp)
{
	auto Action = ACTION_PARSE_LobbySetSaveResp(InAction);

	auto& Resp = Action->GetVal();
	if (!Resp.Ok)
	{
		Q6JsonLogPaul(Warning, "FailedLobbySetSave", Q6KV("LobbyTemplateId", Resp.LobbySetInfo.LobbyTemplateId.S));
		return true;
	}
	UpdateLobbySet(Resp.LobbySetInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(ULobbySetManager, LobbySetUseResp)
{
	auto Action = ACTION_PARSE_LobbySetUseResp(InAction);

	const auto& Resp = Action->GetVal();
	UpdateSelectedLobbySet(Resp.SelectedId, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(ULobbySetManager, CharacterAddXpResp)
{
	auto Action = ACTION_PARSE_CharacterAddXpResp(InAction);

	auto& Res = Action->GetVal();
	RemoveLobbySetCharacters(Res.Ids);

	return true;
}

IMPLEMENT_ACTION_HANDLER(ULobbySetManager, CharacterUltimateSkillLevelResp)
{
	auto Action = ACTION_PARSE_CharacterUltimateSkillLevelResp(InAction);

	auto& Res = Action->GetVal();
	RemoveLobbySetCharacters(Res.Ids);

	return true;
}

IMPLEMENT_ACTION_HANDLER(ULobbySetManager, CharacterRemoveResp)
{
	auto Action = ACTION_PARSE_CharacterRemoveResp(InAction);

	auto& Res = Action->GetVal();
	RemoveLobbySetCharacters(Res.CharacterIds);

	return true;
}

IMPLEMENT_ACTION_HANDLER(ULobbySetManager, ShopSellItemResp)
{
	auto Action = ACTION_PARSE_ShopSellItemResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Category == ELootCategory::CharacterCard)
	{
		TArray<FCharacterId> CharacterIds;
		for (const FAnyId& ItemId : Res.ItemIds)
		{
			CharacterIds.Add(FCharacterId(ItemId.S));
		}
		RemoveLobbySetCharacters(CharacterIds);
	}

	return true;
}

/////////////////////////////////////////////////////////////////////////////
// Setter

void ULobbySetManager::UpdateLobbySetList(const TArray<FLobbySetInfo>& InLobbySetInfoList)
{
	LobbySetInfoList = InLobbySetInfoList;
}

void ULobbySetManager::UpdateLobbySet(const FLobbySetInfo& InLobbySetInfo)
{
	FLobbySetInfo* Found = LobbySetInfoList.FindByPredicate([&InLobbySetInfo](const FLobbySetInfo& LobbySetInfo)
	{
		return LobbySetInfo.LobbySetId == InLobbySetInfo.LobbySetId;
	});
	if (Found)
	{
		*Found = InLobbySetInfo;

		ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance);
		if (LobbyHUD)
		{
			FText LobbySetSavedText = Q6Util::GetLocalizedText("Lobby", "LobbySetSaved");
			LobbySetSavedText = FText::Format(LobbySetSavedText, SelectedId);
			LobbyHUD->ShowNotification(ENotificationType::Short, LobbySetSavedText);
		}
	}
	else
	{
		LobbySetInfoList.Push(InLobbySetInfo);
		ReqLobbySetUse(InLobbySetInfo.LobbySetId);
	}
}

void ULobbySetManager::UpdateSelectedLobbySet(int32 InLobbySetId, bool bShowNoti)
{
	SelectedId = InLobbySetId;

	if (bShowNoti)
	{
		ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance);
		if (LobbyHUD)
		{
			FText LobbySetSelectedText = Q6Util::GetLocalizedText("Lobby", "LobbySetSelected");
			LobbySetSelectedText = FText::Format(LobbySetSelectedText, SelectedId);
			LobbyHUD->ShowNotification(ENotificationType::Short, LobbySetSelectedText);
		}
	}
}

void ULobbySetManager::RemoveLobbySetCharacters(const TArray<FCharacterId>& InCharacterIds)
{
	for (FLobbySetInfo& LobbySetInfo : LobbySetInfoList)
	{
		for (const FCharacterId& CharacterId : InCharacterIds)
		{
			for (int32 i = 0; i < LobbySetInfo.CharacterIds.Num(); ++i)
			{
				if (LobbySetInfo.CharacterIds[i] == CharacterId)
				{
					LobbySetInfo.CharacterIds[i] = FCharacterId();
					break;
				}
			}
		}
	}
}