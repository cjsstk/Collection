#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"

#include "PyramidManager.generated.h"

struct FCharacterType;
struct FRelicType;
struct FSculptureType;

///////////////////////////////////////////////////////////////////////////////////////////
// UPyramidManager

UCLASS()
class Q6_API UPyramidManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UPyramidManager();

	void ReqLoad() const;
	void ReqUpgrade() const;
	void ReqUpgradeComplete() const;
	void ReqPortalBoostUse(EPortalType PortalType) const;
	void ReqPortalConnect(EPortalType PortalType, FAnyId ConnectedId) const;
	void ReqPortalWarp(EPortalType PortalType, int32 ConnectedType) const;

#if !UE_BUILD_SHIPPING
	void ReqDevUpgrade(int32 TargetLevel) const;
	void ReqDevPortalWarp(EPortalType PortalType, int32 ItemType) const;
#endif

	const FPortalRecord* GetCharacterPortal(FCharacterType CharacterType) const;
	const FPortalRecord* GetRelicPortal(FRelicType RelicType) const;
	const FPortalRecord* GetSculpturePortal(FSculptureType SculptureType) const;
	const FPortalRecord* GetConnectedPortal(EPortalType PortalType) const;

	const FPyramidInfo& GetPyramid() const { return PyramidInfo; }
	int32 GetLevel() const { return PyramidInfo.Level; }
	int32 GetPortalConnectedType(EPortalType PortalType) const;

	int32 GetTotalBoostUsed(EPortalType PortalType) const;
	int32 GetDailyBoostUsed(EPortalType PortalType) const;

	int32 GetBuildTimeLeftDays(EPortalType PortalType) const;
	int32 GetConnectTimeLeftDays(EPortalType PortalType) const;

	const FPortal* GetPortal(EPortalType PortalType) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	void AddPortalHistory(const FPortalRecord& PortalRecord);

	void OnLoadResp(const FResError* Error, const FL2CPyramidLoadResp& Msg);
	void OnUpgrade(const FResError* Error, const FL2CPyramidUpgradeResp& Msg);
	void OnUpgradeComplete(const FResError* Error, const FL2CPyramidUpgradeCompleteResp& Msg);
	void OnPortalBoostUse(const FResError* Error, const FL2CPyramidPortalBoostUseResp& Msg);
	void OnPortalConnect(const FResError* Error, const FL2CPyramidPortalConnectResp& Msg);
	void OnPortalWarp(const FResError* Error, const FL2CPyramidPortalWarpResp& Msg);

	DECLARE_ACTION_HANDLER(PyramidLoadResp);
	DECLARE_ACTION_HANDLER(PyramidUpgradeResp);
	DECLARE_ACTION_HANDLER(PyramidUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(PyramidPortalBoostUseResp);
	DECLARE_ACTION_HANDLER(PyramidPortalConnectResp);
	DECLARE_ACTION_HANDLER(PyramidPortalWarpResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DevPyramidOpenResp);
	DECLARE_ACTION_HANDLER(DevPyramidUpgradeResp);
	DECLARE_ACTION_HANDLER(DevPyramidPortalBoostUseResp);
	DECLARE_ACTION_HANDLER(DevPyramidPortalClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);

	UPROPERTY()
	FPyramidInfo PyramidInfo;

	UPROPERTY()
	TMap<FCharacterType, FPortalRecord> CharacterPortalHistory;

	UPROPERTY()
	TMap<FRelicType, FPortalRecord> RelicPortalHistory;

	UPROPERTY()
	TMap<FSculptureType, FPortalRecord> SculpturePortalHistory;
};
