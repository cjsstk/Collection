#pragma once

#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "SpecialManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FSagaType;
class UCCEndGameEvent;

///////////////////////////////////////////////////////////////////////////////////////////
// USpecialManager
UCLASS()
class Q6_API USpecialManager : public UHUDStoreBase
{
	GENERATED_BODY()

	public:
	USpecialManager();

	// Req
	void ReqSpecialHistory() const;
	void ReqStageBegin() const;
	void ReqStageEnd(const UCCEndGameEvent* Event, const FString& Chronicle) const;
	void ReqStoryStageClear(FSagaType SagaType, int32 Episode, int32 Stage) const;

#if !UE_BUILD_SHIPPING
	void ReqDevStageBegin() const;
#endif

	const TArray<FSpecialRecord>& GetHistory() const { return History; }
	const FSpecialStage* GetSpecialStage(int32 Episode, int32 Stage) const;
	TArray<FSpecialStage> GetSpecialStages(int32 Episode) const;
	TArray<FSpecialRecord> GetFilteredHistory(ESpecialCategory Category) const;
	TArray<FSpecialRecord> GetWonderHistory(EWonderCategory WonderCategory) const;

	ESpecialCategory GetSpecialCategory(int32 Episode) const;
	bool IsFirstClearBossStage(int32 Episode, int32 Stage) const;

	bool HasOpenedStage(ESpecialCategory Category) const;
	bool HasOpenedBossStage(int32 Episode) const;
	bool HasOpenedWonderStage(EWonderCategory WonderCategory) const;
	bool IsClearedPrevSpecials(const TArray<const FCMSSagaRow*>& Episodes) const;

	bool IsClearedSpecial(FSpecialType SpecialType) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnSpecialLoadResp(const FResError* Error, const FL2CSpecialLoadResp& Res);
	void OnStageBeginResp(const FResError* Error, const FL2CSpecialStageBeginResp& Res);
	void OnStageEndResp(const FResError* Error, const FL2CSpecialStageEndResp& Res);
	void OnStoryStageClearResp(const FResError* Error, const FL2CSpecialStoryStageClearResp& Res);

	// On Actions
	DECLARE_ACTION_HANDLER(SpecialLoadResp);
	DECLARE_ACTION_HANDLER(DevCharacterNewResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialOpenResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(DevBondAddResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(SummonPickupResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(PyramidPortalWarpResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(VacationEndResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);

private:
	bool OpenSpecialEpisode(const FSpecialRecord& InSpecialRecord);
	bool SaveSpecialStage(int32 Episode, const FSpecialStage& InStage);

	UPROPERTY()
	TArray<FSpecialRecord> History;
};
