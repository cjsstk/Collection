#pragma once

#include "Q6ClientNetwork.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "BagItemManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FBagItemId;

///////////////////////////////////////////////////////////////////////////////////////////
// FBagItem

class Q6_API FBagItem
{
public:
	FBagItem(const FBagItemInfo& InInfo);
	const FBagItemInfo& GetInfo() const { return Info; }
	void Update(const FBagItemInfo& InInfo);
private:
	FBagItemInfo Info;
};

///////////////////////////////////////////////////////////////////////////////////////////
// UBagItemManager

UCLASS()
class Q6_API UBagItemManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UBagItemManager();

	void ReqList(int32 PageNo = 0) const;
	void ReqClearNew(const FBagItemId& Id) const;

	void OnListResp(const FResError* Error, const FL2CBagItemListResp& Msg);
	void OnLoadResp(const FResError* Error, const FL2CBagItemLoadResp& Msg);

	void Dump() const;

	const TMap<int64, FBagItem>& GetBagItems() const { return BagItems; }
	const FBagItem* const Find(int64 Id) const;
	const int32 GetBagItemCount(FBagItemType ItemType) const;

	bool HasEnoughBagItem(const FBagItemType& ItemType, int32 RequireCount) const;
	bool HasEnoughBagItem(const TArray<const FCMSBagItemRow*>& InBagItems, const TArray<int32>& RequireCounts) const;

protected:
	virtual void RegisterActionHandlers() override;

	// Setter
	bool AddBagItem(const FBagItemInfo& Info);
	bool RemoveBagItem(int64 Id);
	bool UpdateBagItem(const FBagItemInfo& Info);
	bool UpdateBagItems(const TArray<FBagItemInfo>& InBagItems);

	void SortBagItems();

	// Subroutines of OnAction
	DECLARE_ACTION_HANDLER(ClearBag);
	DECLARE_ACTION_HANDLER(BagItemLoadResp);
	DECLARE_ACTION_HANDLER(BagItemListResp);
	DECLARE_ACTION_HANDLER(BagItemRemoveResp);
	DECLARE_ACTION_HANDLER(CharacterPromoteResp);
	DECLARE_ACTION_HANDLER(CharacterUnbindResp);
	DECLARE_ACTION_HANDLER(CharacterEvoluteResp);
	DECLARE_ACTION_HANDLER(CharacterTurnSkillLevelResp);
	DECLARE_ACTION_HANDLER(RelicPromoteResp);
	DECLARE_ACTION_HANDLER(SculpturePromoteResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(PyramidUpgradeResp);
	DECLARE_ACTION_HANDLER(PyramidPortalBoostUseResp);
	DECLARE_ACTION_HANDLER(PowerPlantUpgradeResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeResp);
	DECLARE_ACTION_HANDLER(VacationStartResp);
	DECLARE_ACTION_HANDLER(PetSkillUpgradeResp);
	DECLARE_ACTION_HANDLER(PetParkUpgradeResp);
	DECLARE_ACTION_HANDLER(TempleUpgradeResp);
	DECLARE_ACTION_HANDLER(TempleArtifactUpgradeResp);
	DECLARE_ACTION_HANDLER(TempleArtifactBoostResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(ShopBuyItemResp);
	DECLARE_ACTION_HANDLER(BagItemSort);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);
	DECLARE_ACTION_HANDLER(SmelterIncStockResp);
	DECLARE_ACTION_HANDLER(SmelterDecStockResp);
	DECLARE_ACTION_HANDLER(SmelterReceiveResp);
	DECLARE_ACTION_HANDLER(SmelterUpgradeResp);
	DECLARE_ACTION_HANDLER(AlchemylabIncStockResp);
	DECLARE_ACTION_HANDLER(AlchemylabDecStockResp);
	DECLARE_ACTION_HANDLER(AlchemylabUpgradeResp);

private:
	TMap<int64, FBagItem> BagItems;
	bool bSorted;
};
