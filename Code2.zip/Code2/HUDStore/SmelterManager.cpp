#include "SmelterManager.h"

#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"

USmelterManager::USmelterManager()
{
	InitStore(EHSType::Smelter);
	SmelterTick = 0.f;
}

void USmelterManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSmelterLoad Out;

	ClientNetwork.WsRequest(TEXT("smelter/load"), Out,
		TQ6ResponseDelegate<FL2CSmelterLoadResp>::CreateUObject(
			const_cast<USmelterManager*>(this), &USmelterManager::OnLoadResp));
}

void USmelterManager::ReqIncStock(int32 Count) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSmelterIncStock Out;
	Out.Count = Count;

	ClientNetwork.WsRequest(TEXT("smelter/incStock"), Out,
		TQ6ResponseDelegate<FL2CSmelterIncStockResp>::CreateUObject(
			const_cast<USmelterManager*>(this), &USmelterManager::OnIncStockResp));
}

void USmelterManager::ReqDecStock(int32 Count) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSmelterDecStock Out;
	Out.Count = Count;

	ClientNetwork.WsRequest(TEXT("smelter/decStock"), Out,
		TQ6ResponseDelegate<FL2CSmelterDecStockResp>::CreateUObject(
			const_cast<USmelterManager*>(this), &USmelterManager::OnDecStockResp));
}

void USmelterManager::ReqReceive() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSmelterReceive Out;

	ClientNetwork.WsRequest(TEXT("smelter/receive"), Out,
		TQ6ResponseDelegate<FL2CSmelterReceiveResp>::CreateUObject(
			const_cast<USmelterManager*>(this), &USmelterManager::OnReceiveResp));
}

void USmelterManager::ReqUpgrade() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSmelterUpgrade Out;

	ClientNetwork.WsRequest(TEXT("smelter/upgrade"), Out,
		TQ6ResponseDelegate<FL2CSmelterUpgradeResp>::CreateUObject(
			const_cast<USmelterManager*>(this), &USmelterManager::OnUpgradeResp));
}

void USmelterManager::ReqUpgradeComplete() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSmelterUpgradeComplete Out;

	ClientNetwork.WsRequest(TEXT("smelter/upgradeComplete"), Out,
		TQ6ResponseDelegate<FL2CSmelterUpgradeCompleteResp>::CreateUObject(
			const_cast<USmelterManager*>(this), &USmelterManager::OnUpgradeCompleteResp));
}

void USmelterManager::OnLoadResp(const FResError* Error, const FL2CSmelterLoadResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_SmelterLoadResp(Resp);
	GameInstance->ReqNextContent();
}

void USmelterManager::OnIncStockResp(const FResError* Error, const FL2CSmelterIncStockResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SmelterIncStockResp(Resp);
}

void USmelterManager::OnDecStockResp(const FResError* Error, const FL2CSmelterDecStockResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SmelterDecStockResp(Resp);
}

void USmelterManager::OnReceiveResp(const FResError* Error, const FL2CSmelterReceiveResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SmelterReceiveResp(Resp);
}

void USmelterManager::OnUpgradeResp(const FResError* Error, const FL2CSmelterUpgradeResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SmelterUpgradeResp(Resp);
}

void USmelterManager::OnUpgradeCompleteResp(const FResError* Error, const FL2CSmelterUpgradeCompleteResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SmelterUpgradeCompleteResp(Resp);
}

void USmelterManager::OnProduceResp(const FResError* Error, const FL2CSmelterProduceResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SmelterProduceResp(Resp);
}

static const float TICK_SMELTER = 1.f;
void USmelterManager::Tick(float DeltaTime)
{
	if (SmelterTick == 0.f)
	{
		SmelterTick = TICK_SMELTER;
		return;
	}

	SmelterTick -= DeltaTime;

	if (SmelterTick <= 0.f)
	{
		SmelterTick = TICK_SMELTER;
		if (Info.Stock == 0)
		{
			return;
		}

		const FCMSSmelterRow& Row = GetCMS()->GetSmelterRowOrDummy(FSmelterType(Info.Level));
		if (Row.IsInvalid())
		{
			return;
		}

		const int64 ProductTime = Row.ProductTime * 60;

		FDateTime Utc = FDateTime::UtcNow();
		int64 Diff = Utc.ToUnixTimestamp() - Info.StockTimeSec;
		if (Diff >= ProductTime)
		{
			FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
			FC2LSmelterProduce Out;

			ClientNetwork.WsRequest(TEXT("smelter/produce"), Out,
				TQ6ResponseDelegate<FL2CSmelterProduceResp>::CreateUObject(
					const_cast<USmelterManager*>(this), &USmelterManager::OnProduceResp));
		}
	}
}

const EIncomeState USmelterManager::GetProductionState() const
{
	if (Info.Stock == 0 && Info.Product == 0 && Info.StockTimeSec == 0)
	{
		return EIncomeState::NotStored;
	}
	else if (Info.Stock > 0 && Info.StockTimeSec > 0)
	{
		return EIncomeState::Stored;
	}
	else if (Info.Stock == 0 && Info.Product > 0)
	{
		return EIncomeState::MaxStored;
	}

	ensure(false);
	return EIncomeState::Invalid;
}

void USmelterManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(USmelterManager, SmelterLoadResp);
	REGISTER_ACTION_HANDLER(USmelterManager, DevSmelterOpenResp);
	REGISTER_ACTION_HANDLER(USmelterManager, DevSmelterUpgradeResp);
	REGISTER_ACTION_HANDLER(USmelterManager, DevSmelterTimeResp);
	REGISTER_ACTION_HANDLER(USmelterManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SmelterIncStockResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SmelterDecStockResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SmelterReceiveResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SmelterUpgradeResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SmelterUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SmelterProduceResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(USmelterManager, SpecialStoryStageClearResp);
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SmelterLoadResp)
{
	auto Action = ACTION_PARSE_SmelterLoadResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, DevSmelterOpenResp)
{
	auto Action = ACTION_PARSE_DevSmelterOpenResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, DevSmelterUpgradeResp)
{
	auto Action = ACTION_PARSE_DevSmelterUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.SmelterInfo;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, DevSmelterTimeResp)
{
	auto Action = ACTION_PARSE_DevSmelterTimeResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Smelter;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SmelterIncStockResp)
{
	auto Action = ACTION_PARSE_SmelterIncStockResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SmelterDecStockResp)
{
	auto Action = ACTION_PARSE_SmelterDecStockResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SmelterReceiveResp)
{
	auto Action = ACTION_PARSE_SmelterReceiveResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SmelterUpgradeResp)
{
	auto Action = ACTION_PARSE_SmelterUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.SmelterInfo;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SmelterUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_SmelterUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SmelterProduceResp)
{
	auto Action = ACTION_PARSE_SmelterProduceResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Smelter;
	return true;
}

IMPLEMENT_ACTION_HANDLER(USmelterManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Smelter;
	return true;
}