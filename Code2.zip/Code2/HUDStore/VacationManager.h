#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"

#include "VacationManager.generated.h"

enum class EVacationState : uint8
{
	Locked = 0,
	Openable,
	Opened,
};

struct FVacationResult;

///////////////////////////////////////////////////////////////////////////////////////////
// UVacationManager

UCLASS()
class Q6_API UVacationManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UVacationManager();

	void ReqLoad() const;
	void ReqUpgrade() const;
	void ReqUpgradeComplete() const;
	void ReqStart(int32 SpotIndex, FCharacterId CharacterId) const;
	void ReqEnd(int32 SpotIndex) const;

#if !UE_BUILD_SHIPPING
	void ReqDevUpgrade(int32 TargetLevel) const;
	void ReqDevEnd(int32 SpotIndex) const;
#endif

	const FVacationInfo& GetVacation() const { return VacationInfo; }
	const FVacationSpot* GetVacationSpot(int32 SpotIdx) const;
	int32 GetLevel() const { return VacationInfo.Level; }
	int32 GetRemainDays(int32 SpotIdx) const;
	int32 GetRemainDays(FVacationSpotType SpotType) const;
	bool IsVacationNow(FCharacterType CharacterType) const;

	TArray<FVacationSpotType> GetOpenedSpotTypes() const;
	EVacationState GetSpotState(const FVacationSpotType& VacationSpotType) const;
	EVacationState GetSpotState(const FCMSVacationSpotRow& SpotRow) const;
protected:
	virtual void RegisterActionHandlers() override;

private:
	void OnLoadResp(const FResError* Error, const FL2CVacationLoadResp& Msg);
	void OnUpgradeResp(const FResError* Error, const FL2CVacationUpgradeResp& Msg);
	void OnUpgradeCompleteResp(const FResError* Error, const FL2CVacationUpgradeCompleteResp& Msg);
	void OnStartResp(const FResError* Error, const FL2CVacationStartResp& Msg);
	void OnEndResp(const FResError* Error, const FL2CVacationEndResp& Msg);

	DECLARE_ACTION_HANDLER(VacationLoadResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(VacationStartResp);
	DECLARE_ACTION_HANDLER(VacationEndResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DevVacationOpenResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);

	UPROPERTY()
	FVacationInfo VacationInfo;
};
