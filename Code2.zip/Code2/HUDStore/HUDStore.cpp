// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "HUDStore.h"

#include "ActRecordManager.h"
#include "AvatarManager.h"
#include "BattleHelper.h"
#include "UserRecordManager.h"
#include "CodexManager.h"
#include "WeeklyMissionManager.h"
#include "CharMissionManager.h"
#include "EventMissionManager.h"
#include "BagItemManager.h"
#include "BaseWidget.h"
#include "BondManager.h"
#include "CharacterManager.h"
#include "CheckInManager.h"
#include "FriendBook.h"
#include "FriendManager.h"
#include "HSAction.h"
#include "HUDStore/EventManager.h"
#include "JokerSetManager.h"
#include "PartyManager.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "RelicManager.h"
#include "RewardManager.h"
#include "SagaManager.h"
#include "SculptureManager.h"
#include "ActRecordManager.h"
#include "BondManager.h"
#include "RaidManager.h"
#include "PowerPlantManager.h"
#include "PyramidManager.h"
#include "PetManager.h"
#include "SummonManager.h"
#include "SpecialManager.h"
#include "TempleManager.h"
#include "TrainingCenterManager.h"
#include "UIStateManager.h"
#include "Q6.h"
#include "Q6UIDefine.h"
#include "VacationManager.h"
#include "DailyDungeonManager.h"
#include "MailManager.h"
#include "NewMarkManager.h"
#include "ShopManager.h"
#include "LobbyTemplateManager.h"
#include "LobbySetManager.h"
#include "SystemConstHelper.h"
#include "TitleManager.h"
#include "ContentFeatureOpenManager.h"
#include "SmelterManager.h"
#include "AlchemylabManager.h"
#include "Q6SaveGame.h"

TAutoConsoleVariable<int32> CVarQ6WonderUpgradeNow(
	TEXT("q6.wonderUpgradeNow"),
	0,
	TEXT("1: No have upgrade lead time/ 0: Not work"),
	ECVF_Cheat);

///////////////////////////////////////////////////////////////////////////////////////////
// Profile

DECLARE_DWORD_ACCUMULATOR_STAT(TEXT("HSAction"), STAT_HSACTION, STATGROUP_HSTORE);
DECLARE_DWORD_ACCUMULATOR_STAT(TEXT("StoreBase"), STAT_STOREBASE, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("Dispatch"), STAT_Dispatch, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("DispatchInternal"), STAT_DispatchInternal, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnAction"), STAT_OnAction, STATGROUP_HSTORE);

///////////////////////////////////////////////////////////////////////////////////////////
// UHUDStore

UHUDStore::UHUDStore()
	: bDispatchingHSEvents(false)
	, bInitializedHUDStore(false)
{
}

void UHUDStore::Initialize(UQ6GameInstance* InGameInstance)
{
	check(StoreInfos.Num() == EHSType2Int32(EHSType::WorldUser));
	StoreInfos.Add(FStoreInfo(NewObject<UWorldUser>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Character));
	StoreInfos.Add(FStoreInfo(NewObject<UCharacterManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::BagItem));
	StoreInfos.Add(FStoreInfo(NewObject<UBagItemManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Relic));
	StoreInfos.Add(FStoreInfo(NewObject<URelicManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Friend));
	StoreInfos.Add(FStoreInfo(NewObject<UFriendManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::JokerSet));
	StoreInfos.Add(FStoreInfo(NewObject<UJokerSetManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Sculpture));
	StoreInfos.Add(FStoreInfo(NewObject<USculptureManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::ActRecord));
	StoreInfos.Add(FStoreInfo(NewObject<UActRecordManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::UserRecord));
	StoreInfos.Add(FStoreInfo(NewObject<UUserRecordManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Codex));
	StoreInfos.Add(FStoreInfo(NewObject<UCodexManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::WeeklyMission));
	StoreInfos.Add(FStoreInfo(NewObject<UWeeklyMissionManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::CharMission));
	StoreInfos.Add(FStoreInfo(NewObject<UCharMissionManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::EventMission));
	StoreInfos.Add(FStoreInfo(NewObject<UEventMissionManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Bond));
	StoreInfos.Add(FStoreInfo(NewObject<UBondManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Raid));
	StoreInfos.Add(FStoreInfo(NewObject<URaidManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Party));
	StoreInfos.Add(FStoreInfo(NewObject<UPartyManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Reward));
	StoreInfos.Add(FStoreInfo(NewObject<URewardManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Saga));
	StoreInfos.Add(FStoreInfo(NewObject<USagaManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Special));
	StoreInfos.Add(FStoreInfo(NewObject<USpecialManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Summon));
	StoreInfos.Add(FStoreInfo(NewObject<USummonManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Pyramid));
	StoreInfos.Add(FStoreInfo(NewObject<UPyramidManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Temple));
	StoreInfos.Add(FStoreInfo(NewObject<UTempleManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::PowerPlant));
	StoreInfos.Add(FStoreInfo(NewObject<UPowerPlantManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Pet));
	StoreInfos.Add(FStoreInfo(NewObject<UPetManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Vacation));
	StoreInfos.Add(FStoreInfo(NewObject<UVacationManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Smelter));
	StoreInfos.Add(FStoreInfo(NewObject<USmelterManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Alchemylab));
	StoreInfos.Add(FStoreInfo(NewObject<UAlchemylabManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Ui));
	StoreInfos.Add(FStoreInfo(NewObject<UUIStateManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::TrainingCenter));
	StoreInfos.Add(FStoreInfo(NewObject<UTrainingCenterManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::DailyDungeon));
	StoreInfos.Add(FStoreInfo(NewObject<UDailyDungeonManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Mail));
	StoreInfos.Add(FStoreInfo(NewObject<UMailManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::CheckIn));
	StoreInfos.Add(FStoreInfo(NewObject<UCheckInManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Shop));
	StoreInfos.Add(FStoreInfo(NewObject<UShopManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Event));
	StoreInfos.Add(FStoreInfo(NewObject<UEventManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::LobbyTemplate));
	StoreInfos.Add(FStoreInfo(NewObject<ULobbyTemplateManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::LobbySet));
	StoreInfos.Add(FStoreInfo(NewObject<ULobbySetManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::NewMark));
	StoreInfos.Add(FStoreInfo(NewObject<UNewMarkManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Title));
	StoreInfos.Add(FStoreInfo(NewObject<UTitleManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::ContentFeatureOpen));
	StoreInfos.Add(FStoreInfo(NewObject<UContentFeatureOpenManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::Avatar));
	StoreInfos.Add(FStoreInfo(NewObject<UAvatarManager>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::BattleHelper));
	StoreInfos.Add(FStoreInfo(NewObject<UBattleHelper>(this)));

	check(StoreInfos.Num() == EHSType2Int32(EHSType::FriendBook));
	StoreInfos.Add(FStoreInfo(NewObject<UFriendBook>(this)));

	check(StoreInfos.Num() == EHSTypeMax);
	SET_DWORD_STAT(STAT_STOREBASE, StoreInfos.Num());

	for (auto& StoreInfo : StoreInfos)
	{
		StoreInfo.Store->InitWithGame(InGameInstance);
		StoreInfo.Store->RegisterActionHandlers();
	}

	bInitializedHUDStore = true;
}

void UHUDStore::OnPostLoadResource()
{
	for (auto& StoreInfo : StoreInfos)
	{
		StoreInfo.Store->OnPostLoadResource();
	}
}

void UHUDStore::InitializeNetworkNotify()
{
	GetMutableRaidManager().InitPushHandler();
	GetMutableFriendManager().InitNotifyHandler();
	GetMutableNewMarkManager().InitNotifyHandler();
}

void UHUDStore::RegisterNullActionHandler(EHSType StoreType, EHSActionType ActionType)
{
	RegisterActionHandler(StoreType, ActionType, FOnHSAction::CreateUObject(this, &UHUDStore::OnActionNull));
}

void UHUDStore::RegisterActionHandler(EHSType StoreType, EHSActionType ActionType, const FOnHSAction& ActionDelegate)
{
	auto ActionHlr = ActionHandlers.Find(ActionType);
	if (ActionHlr == nullptr)
	{
		FStoreActionHandler TempStoreActionHandler;
		TempStoreActionHandler.StoreType = StoreType;
		TempStoreActionHandler.OnAction = ActionDelegate;

		FActionHandler TempActionHandler;
		TempActionHandler.OnActions.Add(MoveTemp(TempStoreActionHandler));

		ActionHandlers.Emplace(ActionType, MoveTemp(TempActionHandler));
	}
	else
	{
		bool FoundStoreActionHlr = false;
		for (auto& Elem : ActionHlr->OnActions)
		{
			if (Elem.StoreType == StoreType)
			{
				Elem.OnAction.Unbind();
				Elem.OnAction = ActionDelegate;
				FoundStoreActionHlr = true;
			}
		}

		if (!FoundStoreActionHlr)
		{
			FStoreActionHandler TempStoreActionHandler;
			TempStoreActionHandler.StoreType = StoreType;
			TempStoreActionHandler.OnAction = ActionDelegate;

			ActionHlr->OnActions.Add(MoveTemp(TempStoreActionHandler));
		}
	}
}

void UHUDStore::Subscribe(EHSType StoreType, UHSBaseWidget* Widget)
{
	UHSBaseWidget** Found = SubscribeWidgets.Find(Widget);
	if (!Found)
	{
		// why is GetInternalElement() private? no way to get element by using return valud of Add()
		SubscribeWidgets.Add(Widget);
		Found = SubscribeWidgets.Find(Widget);
		check(Found);
	}

	if (bDispatchingHSEvents)
	{
		FDeferredSubscription Subscription;
		Subscription.StoreType = StoreType;
		Subscription.Widget = Widget;

		DeferredSubscriptions.Add(Subscription);
	}
	else
	{
		StoreInfos[EHSType2Int32(StoreType)].SubscribeWidgets.AddUnique(*Found);
	}
}

void UHUDStore::Unsubscribe(UHSBaseWidget* Widget)
{
	UHSBaseWidget** Found = SubscribeWidgets.Find(Widget);
	if (!Found)
	{
		return;
	}

	if (bDispatchingHSEvents)
	{
		(*Found)->SetReceivedHSEvent(true);

		FDeferredSubscription Subscription;
		Subscription.StoreType = EHSType::Invalid;
		Subscription.Widget = Widget;

		DeferredSubscriptions.Add(Subscription);
	}
	else
	{
		for (FStoreInfo& StoreInfo : StoreInfos)
		{
			StoreInfo.SubscribeWidgets.RemoveSingleSwap(*Found);
		}

		SubscribeWidgets.Remove(*Found);
	}
}

void UHUDStore::Shutdown()
{
	UnsubscribeAll();
	DeregisterActionHandlers();
}

void UHUDStore::DeregisterActionHandlers()
{
	for (auto& Elem : ActionHandlers)
	{
		auto& ActionHlr = Elem.Value;
		for (auto& StoreActionHlr : ActionHlr.OnActions)
		{
			StoreActionHlr.OnAction.Unbind();
		}

		ActionHlr.OnActions.Empty();
	}

	ActionHandlers.Empty();
}

void UHUDStore::UnsubscribeAll()
{
	DeferredSubscriptions.Empty();

	for (FStoreInfo& StoreInfo : StoreInfos)
	{
		StoreInfo.SubscribeWidgets.Empty();
	}

	StoreInfos.Empty();
	SubscribeWidgets.Empty();
}

void UHUDStore::Dispatch(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_Dispatch);

	bool IsIdle = ActionPool.IsEmpty();
	ensure(IsIdle || InAction->IsByValue());

	ActionPool.Enqueue(InAction);
	INC_DWORD_STAT(STAT_HSACTION);

	if (IsIdle)
	{
		while (!ActionPool.IsEmpty())
		{
			TSharedPtr<FHSAction> CurAction;
			ActionPool.Peek(CurAction);
			DispatchInternal(CurAction);
			ActionPool.Pop();
			DEC_DWORD_STAT(STAT_HSACTION);
		}
	}
}

void UHUDStore::DispatchInternal(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_DispatchInternal);

	check(StoreInfos.Num() == EHSTypeMax);

	bool bStoreDirties[EHSTypeMax];
	FMemory::Memzero(bStoreDirties, sizeof(bStoreDirties));

	for (UHSBaseWidget* Widget : SubscribeWidgets)
	{
		Widget->SetReceivedHSEvent(false);
	}

	if (!OnAction(Action, bStoreDirties))
	{
		return;
	}

	bDispatchingHSEvents = true;

	for (int32 i = 0; i < StoreInfos.Num(); ++i)
	{
		if (!bStoreDirties[i])
		{
			continue;
		}

		FStoreInfo& StoreInfo = StoreInfos[i];

		for (UHSBaseWidget* Widget : StoreInfo.SubscribeWidgets)
		{
			if (!Widget->IsReceivedHSEvent())
			{
				Widget->OnHSEvent(Action);
				Widget->SetReceivedHSEvent(true);
			}
		}
	}

	bDispatchingHSEvents = false;

	ExecuteDeferredSubscriptions();
}

void UHUDStore::ExecuteDeferredSubscriptions()
{
	check(!bDispatchingHSEvents);

	if (DeferredSubscriptions.Num() <= 0)
	{
		return;
	}

	for (FDeferredSubscription& Cursor : DeferredSubscriptions)
	{
		if (Cursor.StoreType == EHSType::Invalid)
		{
			Unsubscribe(Cursor.Widget);
		}
		else
		{
			Subscribe(Cursor.StoreType, Cursor.Widget);
		}
	}

	DeferredSubscriptions.Reset();
}

bool UHUDStore::OnAction(TSharedPtr<FHSAction> Action, bool bStoreDirties[])
{
	SCOPE_CYCLE_COUNTER(STAT_OnAction);

	auto ActionHlr = ActionHandlers.Find(Action->GetActionType());
	if (!ActionHlr)
	{
		return false;
	}

	bool Ret = false;
	for (auto& Elem : ActionHlr->OnActions)
	{
		if (Elem.OnAction.IsBound())
		{
			bool& bDirty = bStoreDirties[EHSType2Int32(Elem.StoreType)];
			bDirty = Elem.OnAction.Execute(Action);
			Ret |= bDirty;
		}
	}

	return Ret;
}

void UHUDStore::Tick(float DeltaTime)
{
	for (auto& StoreInfo : StoreInfos)
	{
		StoreInfo.Store->Tick(DeltaTime);
	}
}

const UCharacterManager& UHUDStore::GetCharacterManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Character)].Store;
	return *(CastChecked<UCharacterManager>(BaseStore));
}

const UBagItemManager& UHUDStore::GetBagItemManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::BagItem)].Store;
	return *(CastChecked<UBagItemManager>(BaseStore));
}

const URelicManager& UHUDStore::GetRelicManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Relic)].Store;
	return *(CastChecked<URelicManager>(BaseStore));
}

const UFriendManager& UHUDStore::GetFriendManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Friend)].Store;
	return *(CastChecked<UFriendManager>(BaseStore));
}

const UJokerSetManager& UHUDStore::GetJokerManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::JokerSet)].Store;
	return *(CastChecked<UJokerSetManager>(BaseStore));
}

const USculptureManager& UHUDStore::GetSculptureManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Sculpture)].Store;
	return *(CastChecked<USculptureManager>(BaseStore));
}

const UActRecordManager& UHUDStore::GetActRecordManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::ActRecord)].Store;
	return *(CastChecked<UActRecordManager>(BaseStore));
}

const UUserRecordManager& UHUDStore::GetUserRecordManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::UserRecord)].Store;
	return *(CastChecked<UUserRecordManager>(BaseStore));
}

const UCodexManager& UHUDStore::GetCodexManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Codex)].Store;
	return *(CastChecked<UCodexManager>(BaseStore));
}

const UWeeklyMissionManager& UHUDStore::GetWeeklyMissionManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::WeeklyMission)].Store;
	return *(CastChecked<UWeeklyMissionManager>(BaseStore));
}

const UCharMissionManager& UHUDStore::GetCharMissionManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::CharMission)].Store;
	return *(CastChecked<UCharMissionManager>(BaseStore));
}

const UEventMissionManager& UHUDStore::GetEventMissionManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::EventMission)].Store;
	return *(CastChecked<UEventMissionManager>(BaseStore));
}

const UTitleManager& UHUDStore::GetTitleManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Title)].Store;
	return *(CastChecked<UTitleManager>(BaseStore));
}

const UBondManager& UHUDStore::GetBondManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Bond)].Store;
	return *(CastChecked<UBondManager>(BaseStore));
}

const URaidManager& UHUDStore::GetRaidManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Raid)].Store;
	return *(CastChecked<URaidManager>(BaseStore));
}

const UPartyManager& UHUDStore::GetPartyManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Party)].Store;
	return *(CastChecked<UPartyManager>(BaseStore));
}

const URewardManager& UHUDStore::GetRewardManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Reward)].Store;
	return *(CastChecked<URewardManager>(BaseStore));
}

const USagaManager& UHUDStore::GetSagaManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Saga)].Store;
	return *(CastChecked<USagaManager>(BaseStore));
}

const USpecialManager& UHUDStore::GetSpecialManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Special)].Store;
	return *(CastChecked<USpecialManager>(BaseStore));
}

const USummonManager& UHUDStore::GetSummonManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Summon)].Store;
	return *(CastChecked<USummonManager>(BaseStore));
}

const USmelterManager& UHUDStore::GetSmelterManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Smelter)].Store;
	return *(CastChecked<USmelterManager>(BaseStore));
}

const UAlchemylabManager& UHUDStore::GetAlchemylabManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Alchemylab)].Store;
	return *(CastChecked<UAlchemylabManager>(BaseStore));
}

const UUIStateManager& UHUDStore::GetUIStateManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Ui)].Store;
	return *(CastChecked<UUIStateManager>(BaseStore));
}

const UWorldUser& UHUDStore::GetWorldUser() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::WorldUser)].Store;
	return *(CastChecked<UWorldUser>(BaseStore));
}

const UTrainingCenterManager& UHUDStore::GetTrainingCenterManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::TrainingCenter)].Store;
	return *(CastChecked<UTrainingCenterManager>(BaseStore));
}

const UPyramidManager& UHUDStore::GetPyramidManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Pyramid)].Store;
	return *(CastChecked<UPyramidManager>(BaseStore));
}

const UTempleManager& UHUDStore::GetTempleManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Temple)].Store;
	return *(CastChecked<UTempleManager>(BaseStore));
}

const UPowerPlantManager& UHUDStore::GetPowerPlantManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::PowerPlant)].Store;
	return *(CastChecked<UPowerPlantManager>(BaseStore));
}

const UPetManager& UHUDStore::GetPetManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Pet)].Store;
	return *(CastChecked<UPetManager>(BaseStore));
}

const UVacationManager& UHUDStore::GetVacationManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Vacation)].Store;
	return *(CastChecked<UVacationManager>(BaseStore));
}

const UDailyDungeonManager& UHUDStore::GetDailyDungeonManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::DailyDungeon)].Store;
	return *(CastChecked<UDailyDungeonManager>(BaseStore));
}

const UMailManager& UHUDStore::GetMailManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Mail)].Store;
	return *(CastChecked<UMailManager>(BaseStore));
}

const UCheckInManager& UHUDStore::GetCheckInManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::CheckIn)].Store;
	return *(CastChecked<UCheckInManager>(BaseStore));
}

const UShopManager& UHUDStore::GetShopManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Shop)].Store;
	return *(CastChecked<UShopManager>(BaseStore));
}

const UEventManager& UHUDStore::GetEventManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Event)].Store;
	return *(CastChecked<UEventManager>(BaseStore));
}

const ULobbyTemplateManager& UHUDStore::GetLobbyTemplateManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::LobbyTemplate)].Store;
	return *(CastChecked<ULobbyTemplateManager>(BaseStore));
}

const ULobbySetManager& UHUDStore::GetLobbySetManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::LobbySet)].Store;
	return *(CastChecked<ULobbySetManager>(BaseStore));
}

const UNewMarkManager& UHUDStore::GetNewMarkManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::NewMark)].Store;
	return *(CastChecked<UNewMarkManager>(BaseStore));
}

const UContentFeatureOpenManager& UHUDStore::GetContentFeatureOpenManager() const
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::ContentFeatureOpen)].Store;
	return *(CastChecked<UContentFeatureOpenManager>(BaseStore));
}

const UAvatarManager& UHUDStore::GetAvatarManager() const
{
	auto& BaseStore = StoreInfos[EHSType2Int32(EHSType::Avatar)].Store;
	return *(CastChecked<UAvatarManager>(BaseStore));
}

const UBattleHelper& UHUDStore::GetBattleHelper() const
{
	auto& BaseStore = StoreInfos[EHSType2Int32(EHSType::BattleHelper)].Store;
	return *(CastChecked<UBattleHelper>(BaseStore));
}

const UFriendBook& UHUDStore::GetFriendBook() const
{
	auto& BaseStore = StoreInfos[EHSType2Int32(EHSType::FriendBook)].Store;
	return *(CastChecked<UFriendBook>(BaseStore));
}

UFriendManager& UHUDStore::GetMutableFriendManager()
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Friend)].Store;
	return *(CastChecked<UFriendManager>(BaseStore));
}

URaidManager& UHUDStore::GetMutableRaidManager()
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::Raid)].Store;
	return *(CastChecked<URaidManager>(BaseStore));
}

UNewMarkManager& UHUDStore::GetMutableNewMarkManager()
{
	auto BaseStore = StoreInfos[EHSType2Int32(EHSType::NewMark)].Store;
	return *(CastChecked<UNewMarkManager>(BaseStore));
}

static EWonderUpgradeState GetWonderState(bool bOpened, int64 UpgradeStartTimeSec, int64 UpgradeRemainTimeSec)
{
	if (!bOpened)
	{
		return EWonderUpgradeState::Locked;
	}

	if (UpgradeStartTimeSec <= 0)
	{
		return EWonderUpgradeState::Normal;
	}

	if (UpgradeRemainTimeSec <= 0)
	{
		return EWonderUpgradeState::Upgraded;
	}

	return  EWonderUpgradeState::Upgrading;
}

static int64 GetUpgradeTimeLeft(int64 UpgradeLeadTimeSec, int64 UpgradeStartTimeSec)
{
	if (UpgradeStartTimeSec <= 0)
	{
		return 0;
	}

	int64 UpgradeCompleteTimeSec = UpgradeStartTimeSec + UpgradeLeadTimeSec;
	return FMath::Max((int32)(UpgradeCompleteTimeSec - FDateTime::UtcNow().ToUnixTimestamp()), 0);
}

FWonderInfo UHUDStore::GetWonderInfo(EWonderCategory Category) const
{
	FWonderInfo WonderInfo;
	WonderInfo.Category = Category;

	int32 LastIncomeTimeSec = 0;
	if (Category == EWonderCategory::Pyramid)
	{
		const FPyramidInfo& PyramidInfo = GetPyramidManager().GetPyramid();
		WonderInfo.bOpened = PyramidInfo.Opened;
		WonderInfo.Level = PyramidInfo.Level;
		WonderInfo.UpgradeStartTimeSec = PyramidInfo.UpgradeTime;
	}
	else if (Category == EWonderCategory::Powerplant)
	{
		const FPowerPlantInfo& PowerPlantInfo = GetPowerPlantManager().GetPowerPlant();
		WonderInfo.bOpened = PowerPlantInfo.Opened;
		WonderInfo.Level = PowerPlantInfo.Level;
		WonderInfo.UpgradeStartTimeSec = PowerPlantInfo.UpgradeTime;
	}
	else if (Category == EWonderCategory::Vacation)
	{
		const FVacationInfo& VacationInfo = GetVacationManager().GetVacation();
		WonderInfo.bOpened = VacationInfo.Opened;
		WonderInfo.Level = VacationInfo.Level;
		WonderInfo.UpgradeStartTimeSec = VacationInfo.UpgradeTime;
	}
	else if (Category == EWonderCategory::PetPark)
	{
		const FPetPark& PetPark = GetPetManager().GetPetPark();
		WonderInfo.bOpened = (PetPark.Level > 0);
		WonderInfo.Level = (PetPark.Level == 0) ? 1 : PetPark.Level;
		WonderInfo.UpgradeStartTimeSec = PetPark.Upgraded;

		LastIncomeTimeSec = PetPark.LastIncome;
	}
	else if (Category == EWonderCategory::Temple)
	{
		const FTempleInfo& TempleInfo = GetTempleManager().GetTempleInfo();
		WonderInfo.bOpened = (TempleInfo.Level > 0);
		WonderInfo.Level = (TempleInfo.Level == 0) ? 1 : TempleInfo.Level;
		WonderInfo.UpgradeStartTimeSec = TempleInfo.UpgradeTime;

		LastIncomeTimeSec = TempleInfo.LastIncomeTime;
	}
	else if (Category == EWonderCategory::AlchemyLab)
	{
		const FAlchemylabInfo& AlchemylabInfo = GetAlchemylabManager().GetAlchemylabInfo();
		WonderInfo.bOpened = AlchemylabInfo.Opened;
		WonderInfo.Level = AlchemylabInfo.Level;
		WonderInfo.UpgradeStartTimeSec = AlchemylabInfo.UpgradeTimeSec;
	}
	else if(Category == EWonderCategory::MigriumRefinery)
	{
		const FSmelterInfo& SmelterInfo = GetSmelterManager().GetSmelterInfo();
		WonderInfo.bOpened = SmelterInfo.Opened;
		WonderInfo.Level = SmelterInfo.Level;
		WonderInfo.UpgradeStartTimeSec = SmelterInfo.UpgradeTimeSec;
	}

	// Set upgrading info

	if (WonderInfo.UpgradeStartTimeSec > 0)
	{
		WonderInfo.UpgradeLeadTimeSec = GetCMS()->GetUpgradeTimeSec(Category, WonderInfo.Level + 1);
		WonderInfo.UpgradeRemainTimeSec = CVarQ6WonderUpgradeNow.GetValueOnGameThread() ? 0 : GetUpgradeTimeLeft(WonderInfo.UpgradeLeadTimeSec, WonderInfo.UpgradeStartTimeSec);
	}

	// Set product info

	if (LastIncomeTimeSec > 0)
	{
		if (const FCMSWonderProductRow* ProductRow = GetCMS()->GetWonderProductRow(Category, WonderInfo.Level))
		{
			int32 MaxProduceCount = (int32)ProductRow->MaxStorageAmount / ProductRow->ProduceAmount;
			int32 MaxTime = (int32)(LastIncomeTimeSec + (MaxProduceCount * SystemConst::Q6_WONDER_PRODUCE_CURRENCY_TIME * 3600));
			int32 CurrentTime = FDateTime::UtcNow().ToUnixTimestamp();
			int32 ProducedTime = CurrentTime - LastIncomeTimeSec;
			int32 ProducedCount = FMath::Min((int32)ProducedTime / (SystemConst::Q6_WONDER_PRODUCE_CURRENCY_TIME * 3600), MaxProduceCount);

			WonderInfo.RemainMaxIncomeTimeSec = FMath::Max(MaxTime - CurrentTime, 0);
			WonderInfo.IncomeAmount = ProducedCount * ProductRow->ProduceAmount;
		}
	}

	WonderInfo.WonderState = GetWonderState(WonderInfo.bOpened, WonderInfo.UpgradeStartTimeSec, WonderInfo.UpgradeRemainTimeSec);
	return WonderInfo;
}

bool UHUDStore::CheckMigriumStockCost() const
{
	const FSmelterInfo& SmelterInfo = GetSmelterManager().GetSmelterInfo();
	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterInfo.Level);
	if (!SmelterRow)
	{
		return false;
	}

	const int32 BagItemCount = GetBagItemManager().GetBagItemCount(FBagItemType(SmelterRow->Material));
	if (BagItemCount < 1)
	{
		return false;
	}

	return true;
}

bool UHUDStore::CheckAlchemyLabStockCost(FAlchemyLabType Type) const
{
	const FCMSAlchemyLabRow& AlchemyLabRow = GetCMS()->GetAlchemyLabRowOrDummy(Type);
	if (AlchemyLabRow.IsInvalid())
	{
		return false;
	}

	if (GetWorldUser().GetGold() < AlchemyLabRow.CostGold)
	{
		return false;
	}

	const FCMSBagItemRow& BagItemRow = AlchemyLabRow.GetBagItem();
	if (BagItemRow.IsInvalid())
	{
		return false;
	}

	const int32 BagItemCount = GetBagItemManager().GetBagItemCount(BagItemRow.CmsType());
	if (BagItemCount < AlchemyLabRow.MaterialValue)
	{
		return false;
	}

	return true;
}

TArray<FRelicId> UHUDStore::GetUsedRelicIds() const
{
	TArray<FRelicId> UsedRelicIds;
	const UPartyManager& PartyMgr = GetPartyManager();
	UsedRelicIds.Append(PartyMgr.GetRelicsInParty());

	const UJokerSetManager& JokerMgr = GetJokerManager();
	UsedRelicIds.Append(JokerMgr.GetRelicsInJokerSet());

	const UQ6SaveGame* SaveGame = UQ6GameInstance::Get()->GetSaveGame();
	const FPartyInfo& PartyInfo = SaveGame->GetMultisidePartyInfo();

	for (const FPartySlot& Iter : PartyInfo.Main)
	{
		if (!Iter.RelicId.IsInvalid())
		{
			UsedRelicIds.AddUnique(Iter.RelicId);
		}
	}
	for (const FPartySlot& Iter : PartyInfo.Sub)
	{
		if (!Iter.RelicId.IsInvalid())
		{
			UsedRelicIds.AddUnique(Iter.RelicId);
		}
	}

	return UsedRelicIds;
}

TArray<FSculptureId> UHUDStore::GetUsedSculptureIds() const
{
	TArray<FSculptureId> UsedSculptureIds;
	const UPartyManager& PartyMgr = GetPartyManager();
	UsedSculptureIds.Append(PartyMgr.GetSculpturesInParty());

	const UJokerSetManager& JokerMgr = GetJokerManager();
	UsedSculptureIds.Append(JokerMgr.GetSculpturesInJokerSet());

	const UQ6SaveGame* SaveGame = UQ6GameInstance::Get()->GetSaveGame();
	const FPartyInfo& PartyInfo = SaveGame->GetMultisidePartyInfo();

	for (const FPartySlot& Iter : PartyInfo.Main)
	{
		if (!Iter.SculptureId.IsInvalid())
		{
			UsedSculptureIds.AddUnique(Iter.SculptureId);
		}
	}
	for (const FPartySlot& Iter : PartyInfo.Sub)
	{
		if (!Iter.SculptureId.IsInvalid())
		{
			UsedSculptureIds.AddUnique(Iter.SculptureId);
		}
	}

	return UsedSculptureIds;
}

TArray<FCharacterId> UHUDStore::GetUsedCharacterIds() const
{
	TArray<FCharacterId> UsedCharacterIds;
	const UPartyManager& PartyMgr = GetPartyManager();
	UsedCharacterIds.Append(PartyMgr.GetCharactersInParty());

	const UJokerSetManager& JokerMgr = GetJokerManager();
	UsedCharacterIds.Append(JokerMgr.GetCharactersInJokerSet());

	const UQ6SaveGame* SaveGame = UQ6GameInstance::Get()->GetSaveGame();
	const FPartyInfo& PartyInfo = SaveGame->GetMultisidePartyInfo();

	for (const FPartySlot& Iter : PartyInfo.Main)
	{
		if (!Iter.CharacterId.IsInvalid())
		{
			UsedCharacterIds.AddUnique(Iter.CharacterId);
		}
	}
	for (const FPartySlot& Iter : PartyInfo.Sub)
	{
		if (!Iter.CharacterId.IsInvalid())
		{
			UsedCharacterIds.AddUnique(Iter.CharacterId);
		}
	}

	return UsedCharacterIds;
}

bool UHUDStore::IsUnlockedCharUnlockElem(FCharacterType InCharacterType, const FCMSCharUnlockElemRow* InElem) const
{
	if (!InElem)
	{
		return false;
	}

	switch (InElem->UnlockCondCategory)
	{
		case ECharUnlockCondCategory::None:
			return true;
		case ECharUnlockCondCategory::Bond:
		{
			const UBondManager& BondManager = GetBondManager();
			const FCharacterBond& CharacterBond = BondManager.GetCharacterBond(InCharacterType);
			return CharacterBond.Level >= InElem->UnlockCondParam1;
		}
		case ECharUnlockCondCategory::CharacterLevel:
		{
			const UCharacterManager& CharacterManager = GetCharacterManager();
			const FCharacter* HighestLevelCharacter = CharacterManager.GetHighestLevelCharacter(InCharacterType);
			return HighestLevelCharacter && HighestLevelCharacter->GetInfo().Level >= InElem->UnlockCondParam1;
		}
		case ECharUnlockCondCategory::SagaClear:
		{
			const USagaManager& SagaManager = GetSagaManager();
			const FSagaType LastSagaType = SagaManager.GetLastSagaType();
			return LastSagaType >= InElem->UnlockCondParam1;
		}
		case ECharUnlockCondCategory::UserLevel:
		{
			const UWorldUser& WorldUser = GetWorldUser();
			const FUserLevelType& UserLevel = WorldUser.GetLevel();
			return UserLevel >= InElem->UnlockCondParam1;
		}
		default:
			return false;
	}
}

bool UHUDStore::HasMaxCollection() const
{
	int32 CharacterNum = GetCharacterManager().GetStashedCharacterNum(false);
	if (CharacterNum >= SystemConst::Q6_COLLECTION_SIZE)
	{
		return true;
	}

	int32 SculptureNum = GetSculptureManager().GetStashedSculptureNum(false);
	if (SculptureNum >= SystemConst::Q6_COLLECTION_SIZE)
	{
		return true;
	}

	int32 RelicNum = GetRelicManager().GetStashedRelicNum(false);
	if (RelicNum >= SystemConst::Q6_COLLECTION_SIZE)
	{
		return true;
	}

	return false;
}

bool UHUDStore::IsSpecialStageOpened(FSagaType InSagaType) const
{
	const UCMS* CMS = GetCMS();
	TArray<const FCMSSagaRow*> PrevSagaRows = CMS->GetPrevSpecialSagaRows(InSagaType);
	if (!GetSpecialManager().IsClearedPrevSpecials(PrevSagaRows))
	{
		return false;
	}

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(InSagaType);
	const TArray<const FCMSSagaPlayConditionRow*>& ConditionSagaRows = SagaRow.GetSagaPlayCondition();
	const UCharacterManager& CharacterManager = GetCharacterManager();
	const UBondManager& BondManager = GetBondManager();

	for (const FCMSSagaPlayConditionRow* Iter : ConditionSagaRows)
	{
		switch (Iter->ConditionType)
		{
			case EPlayConditionType::CharacterLevel:
			{
				const FCharacter* Character = CharacterManager.GetHighestLevelCharacter(FCharacterType(Iter->ConditionId));
				if (!Character)
				{
					Q6JsonLogGunny(Warning, "USpecialStageListWidget::IsSpecialStageOpened - Character does not exist.");
					return false;
				}

				if (Character->GetInfo().Level < Iter->ConditionValue)
				{
					return false;
				}

				break;
			}
			case EPlayConditionType::CharacterBondLevel:
			{
				const FCharacterBond* CharacterBond = BondManager.Find(FCharacterType(Iter->ConditionId));
				if (!CharacterBond)
				{
					Q6JsonLogGunny(Warning, "USpecialStageListWidget::IsSpecialStageOpened - CharacterBond does not exist.");
					return false;
				}

				if (CharacterBond->Level < Iter->ConditionValue)
				{
					return false;
				}

				break;
			}
			case EPlayConditionType::CharacterMissionSetClear:
			{
				const UCharMissionManager& CharMissionManager = GetCharMissionManager();
				const FCharMissionInfo* CharMissionInfo = CharMissionManager.GetCharMissionByCharacterType(FCharacterType(Iter->ConditionId));
				if (!CharMissionInfo)
				{
					Q6JsonLogGunny(Warning, "USpecialStageListWidget::IsSpecialStageOpened - CharMissionInfo does not exist.");
					return false;
				}

				int32 NumOfCleared = 0;
				for (int i = 0; i < MAX_CHAR_MISSION; ++i)
				{
					if (!CharMissionInfo->RUtc.IsValidIndex(i))
					{
						continue;
					}

					if (CharMissionInfo->RUtc[i] != 0)
					{
						NumOfCleared++;
					}
				}

				if (!(Iter->ConditionValue == NumOfCleared || NumOfCleared == MAX_CHAR_MISSION))
				{
					return false;
				}

				break;
			}
			case EPlayConditionType::UserRecord:
			{
				// TODO
				break;
			}
			default:
				break;
		}
	}

	return true;
}


void UHUDStore::ReqClearNewIfNotCleared(const FItemIconInfo& ItemInfo) const
{
	if (ItemInfo.AttributeType == EAttributeCategory::Character)
	{
		const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();
		const FCharacter* Character = CharMgr.Find(FCharacterId(ItemInfo.Id));
		if (Character && Character->IsNewly())
		{
			TArray<FCharacterId> CharacterIds;
			CharacterIds.Add(Character->GetId());
			CharMgr.ReqClearNew(CharacterIds);
		}
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Relic)
	{
		const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
		const FRelic* Relic = RelicMgr.Find(FRelicId(ItemInfo.Id));
		if (Relic && Relic->IsNewly())
		{
			TArray<FRelicId> RelicIds;
			RelicIds.Add(Relic->GetId());
			RelicMgr.ReqClearNew(RelicIds);
		}
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Sculpture)
	{
		const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
		const FSculpture* Sculpture = SculptureMgr.Find(FSculptureId(ItemInfo.Id));
		if (Sculpture && Sculpture->IsNewly())
		{
			TArray<FSculptureId> SculptureIds;
			SculptureIds.Add(Sculpture->GetId());
			SculptureMgr.ReqClearNew(SculptureIds);
		}
	}
}

void UHUDStore::ReqWonderUpgrade(EWonderCategory Category) const
{
	switch (Category)
	{
		case EWonderCategory::Pyramid:			GetPyramidManager().ReqUpgrade();	 return;
		case EWonderCategory::Powerplant:		GetPowerPlantManager().ReqUpgrade();	 return;
		case EWonderCategory::Vacation:			GetVacationManager().ReqUpgrade();	 return;
		case EWonderCategory::PetPark:			GetPetManager().ReqPetParkUpgrade();	 return;
		case EWonderCategory::Temple:			GetTempleManager().ReqUpgrade();	 return;
		case EWonderCategory::AlchemyLab:		GetAlchemylabManager().ReqUpgrade();	 return;
		case EWonderCategory::MigriumRefinery:		GetSmelterManager().ReqUpgrade();	 return;
	}

	Q6JsonLogRoze(Error, "UHUDStore::ReqWonderUpgrade - Invalid wonder category");
}

void UHUDStore::ReqWonderUpgradeComplete(EWonderCategory Category) const
{
#if !UE_BUILD_SHIPPING
	if (CVarQ6WonderUpgradeNow.GetValueOnGameThread())
	{
		int32 TargetLevel = GetWonderInfo(Category).Level + 1;
		switch (Category)
		{
			case EWonderCategory::Pyramid:		GetPyramidManager().ReqDevUpgrade(TargetLevel);		return;
			case EWonderCategory::Powerplant:	GetPowerPlantManager().ReqDevUpgrade(TargetLevel);	return;
			case EWonderCategory::Vacation:		GetVacationManager().ReqDevUpgrade(TargetLevel);	return;
			case EWonderCategory::PetPark:		GetPetManager().ReqDevPetParkUpgrade(TargetLevel);	return;
			case EWonderCategory::Temple:		GetTempleManager().ReqDevUpgrade(TargetLevel);		return;
			default: return;
		}
	}
#endif

	switch (Category)
	{
		case EWonderCategory::Pyramid:		GetPyramidManager().ReqUpgradeComplete();		return;
		case EWonderCategory::Powerplant:	 GetPowerPlantManager().ReqUpgradeComplete();		return;
		case EWonderCategory::Vacation:		GetVacationManager().ReqUpgradeComplete();		return;
		case EWonderCategory::PetPark:		GetPetManager().ReqPetParkUpgradeComplete();		return;
		case EWonderCategory::Temple:		GetTempleManager().ReqUpgradeComplete();		return;
		case EWonderCategory::AlchemyLab:	GetAlchemylabManager().ReqUpgradeComplete();		return;
		case EWonderCategory::MigriumRefinery:	GetSmelterManager().ReqUpgradeComplete();		return;
	}

	Q6JsonLogRoze(Error, "UHUDStore::ReqWonderUpgrade - Invalid wonder category");
}

void UHUDStore::ReqWonderHarvest(EWonderCategory Category) const
{
	if (Category == EWonderCategory::PetPark)
	{
		GetPetManager().ReqHarvest();
		return;
	}
	else if (Category == EWonderCategory::Temple)
	{
		GetTempleManager().ReqHarvest();
		return;
	}

	Q6JsonLogRoze(Error, "UHUDStore::ReqWonderHarvest - Invalid wonder category for product harvest");
}

void UHUDStore::ReqSetStash(EInventoryType InventoryType, bool bStashed, const TArray<int64>& Ids) const
{
	if (InventoryType == EInventoryType::Character)
	{
		GetCharacterManager().ReqSetStash(Ids, bStashed);
	}
	else if (InventoryType == EInventoryType::Relic)
	{
		GetRelicManager().ReqSetStash(Ids, bStashed);
	}
	else if (InventoryType == EInventoryType::Sculpture)
	{
		GetSculptureManager().ReqSetStash(Ids, bStashed);
	}
}

void UHUDStore::ReqSetLock(EAttributeCategory AttributeType, int64 ItemId, bool bLocked) const
{
	if (AttributeType == EAttributeCategory::Character)
	{
		GetCharacterManager().ReqSetLock(FCharacterId(ItemId), bLocked);
	}
	else if (AttributeType == EAttributeCategory::Relic)
	{
		GetRelicManager().ReqSetLock(FRelicId(ItemId), bLocked);
	}
	else if (AttributeType == EAttributeCategory::Sculpture)
	{
		GetSculptureManager().ReqSetLock(FSculptureId(ItemId), bLocked);
	}
}
