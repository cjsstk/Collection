#include "PyramidManager.h"

#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "SystemConstHelper.h"

TAutoConsoleVariable<int32> CVarQ6PortalConnected(
	TEXT("q6.portalConnected"),
	0,
	TEXT("1: No have connecting lead days/ 0: Not work"),
	ECVF_Cheat);

///////////////////////////////////////////////////////////////////////////////////////////
// UPyramidManager

UPyramidManager::UPyramidManager()
{
	InitStore(EHSType::Pyramid);
}

void UPyramidManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPyramidLoad Out;

	ClientNetwork.WsRequest(TEXT("pyramid/load"), Out,
		TQ6ResponseDelegate<FL2CPyramidLoadResp>::CreateUObject(
			const_cast<UPyramidManager*>(this), &UPyramidManager::OnLoadResp));
}

void UPyramidManager::ReqUpgrade() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPyramidUpgrade Out;

	ClientNetwork.WsRequest(TEXT("pyramid/upgrade"), Out,
		TQ6ResponseDelegate<FL2CPyramidUpgradeResp>::CreateUObject(
			const_cast<UPyramidManager*>(this), &UPyramidManager::OnUpgrade));
}

void UPyramidManager::ReqUpgradeComplete() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPyramidUpgradeComplete Out;

	ClientNetwork.WsRequest(TEXT("pyramid/upgradeComplete"), Out,
		TQ6ResponseDelegate<FL2CPyramidUpgradeCompleteResp>::CreateUObject(
			const_cast<UPyramidManager*>(this), &UPyramidManager::OnUpgradeComplete));
}

void UPyramidManager::ReqPortalBoostUse(EPortalType PortalType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPyramidPortalBoostUse Out;
	Out.Category = PortalType;

	ClientNetwork.WsRequest(TEXT("pyramid/portalBoostUse"), Out,
		TQ6ResponseDelegate<FL2CPyramidPortalBoostUseResp>::CreateUObject(
			const_cast<UPyramidManager*>(this), &UPyramidManager::OnPortalBoostUse));
}

void UPyramidManager::ReqPortalConnect(EPortalType PortalType, FAnyId ConnectedId) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPyramidPortalConnect Out;
	Out.Category = PortalType;
	Out.Id = ConnectedId;

	ClientNetwork.WsRequest(TEXT("pyramid/portalConnect"), Out,
		TQ6ResponseDelegate<FL2CPyramidPortalConnectResp>::CreateUObject(
			const_cast<UPyramidManager*>(this), &UPyramidManager::OnPortalConnect));
}

void UPyramidManager::ReqPortalWarp(EPortalType PortalType, int32 ConnectedType) const
{
#if !UE_BUILD_SHIPPING
	if (CVarQ6PortalConnected.GetValueOnGameThread())
	{
		ReqDevPortalWarp(PortalType, ConnectedType);
		return;
	}
#endif

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPyramidPortalWarp Out;
	Out.Category = PortalType;

	ClientNetwork.WsRequest(TEXT("pyramid/portalWarp"), Out,
		TQ6ResponseDelegate<FL2CPyramidPortalWarpResp>::CreateUObject(
			const_cast<UPyramidManager*>(this), &UPyramidManager::OnPortalWarp));
}

#if !UE_BUILD_SHIPPING
void UPyramidManager::ReqDevUpgrade(int32 TargetLevel) const
{
	FC2LDevPyramidUpgrade Out;
	Out.Level = TargetLevel;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	ClientNetwork.WsRequest(TEXT("dev/pyramidUpgrade"), Out,
		TQ6ResponseDelegate<FL2CDevPyramidUpgradeResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPyramidUpgradeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "Cheat pyramid upgrade");
		ACTION_DISPATCH_DevPyramidUpgradeResp(Res);
	}));
}

void UPyramidManager::ReqDevPortalWarp(EPortalType PortalType, int32 ItemType) const
{
	FC2LDevPortalWarp Out;
	Out.Category = PortalType;
	Out.Type = ItemType;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	ClientNetwork.WsRequest(TEXT("dev/portalWarp"), Out,
		TQ6ResponseDelegate<FL2CPyramidPortalWarpResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CPyramidPortalWarpResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "Cheat portal warp");
		ACTION_DISPATCH_PyramidPortalWarpResp(Res);
	}));
}
#endif

const FPortalRecord* UPyramidManager::GetCharacterPortal(FCharacterType CharacterType) const
{
	return CharacterPortalHistory.Find(CharacterType);
}

const FPortalRecord* UPyramidManager::GetRelicPortal(FRelicType RelicType) const
{
	return RelicPortalHistory.Find(RelicType);
}

const FPortalRecord* UPyramidManager::GetSculpturePortal(FSculptureType SculptureType) const
{
	return SculpturePortalHistory.Find(SculptureType);
}

const FPortalRecord* UPyramidManager::GetConnectedPortal(EPortalType PortalType) const
{
	const FPortal* Portal = GetPortal(PortalType);
	if (!Portal)
	{
		Q6JsonLogRoze(Error, "UPyramidManager::GetConnectedPortal - Not found portal", Q6KV("PortalType", (int32)PortalType));
		return nullptr;
	}

	if (PortalType == EPortalType::Character)
	{
		return GetCharacterPortal(FCharacterType(Portal->ConnectType));
	}
	else if (PortalType == EPortalType::Relic)
	{
		return GetRelicPortal(FRelicType(Portal->ConnectType));
	}
	else if (PortalType == EPortalType::Sculpture)
	{
		return GetSculpturePortal(FSculptureType(Portal->ConnectType));
	}

	Q6JsonLogRoze(Error, "UPyramidManager::GetConnectedPortal - No have connected portal",
		Q6KV("PortalSlot", ENUM_TO_STRING(EPortalType, PortalType)));
	return nullptr;
}

int32 UPyramidManager::GetPortalConnectedType(EPortalType PortalType) const
{
	const FPortal* Portal = GetPortal(PortalType);
	if (!Portal)
	{
		Q6JsonLogRoze(Error, "UPyramidManager::GetPortalConnectedType - Not found portal", Q6KV("PortalType", (int32)PortalType));
		return 0;
	}

	return Portal->ConnectType;
}

int32 UPyramidManager::GetTotalBoostUsed(EPortalType PortalType) const
{
	const FPortal* Portal = GetPortal(PortalType);
	if (!Portal)
	{
		Q6JsonLogRoze(Error, "UPyramidManager::GetTotalBoostUsed - Not found portal", Q6KV("PortalType", (int32)PortalType));
		return 0;
	}

	return Portal->BoostCount;
}

int32 UPyramidManager::GetDailyBoostUsed(EPortalType PortalType) const
{
	const FPortal* Portal = GetPortal(PortalType);
	if (!Portal)
	{
		Q6JsonLogRoze(Error, "UPyramidManager::GetTotalBoostUsed - Not found portal", Q6KV("PortalType", (int32)PortalType));
		return 0;
	}

	return Portal->DailyBoostUsed;
}

void UPyramidManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UPyramidManager, PyramidLoadResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, PyramidUpgradeResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, PyramidUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, PyramidPortalBoostUseResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, PyramidPortalConnectResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, PyramidPortalWarpResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, DevPyramidOpenResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, DevPyramidUpgradeResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, DevPyramidPortalBoostUseResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, DevPyramidPortalClearResp);
	REGISTER_ACTION_HANDLER(UPyramidManager, DevSpecialClearResp);
}

void UPyramidManager::AddPortalHistory(const FPortalRecord& PortalRecord)
{
	if (PortalRecord.Category == (int32)EPortalType::Character)
	{
		CharacterPortalHistory.Add(FCharacterType(PortalRecord.Type), PortalRecord);
	}
	else if (PortalRecord.Category == (int32)EPortalType::Relic)
	{
		RelicPortalHistory.Add(FRelicType(PortalRecord.Type), PortalRecord);
	}
	else if (PortalRecord.Category == (int32)EPortalType::Sculpture)
	{
		SculpturePortalHistory.Add(FSculptureType(PortalRecord.Type), PortalRecord);
	}
	else
	{
		Q6JsonLogRoze(Error, "UPyramidManager::AddPortalHistory - Invalid portal type", Q6KV("PortalId", PortalRecord.PortalId));
	}
}

void UPyramidManager::OnLoadResp(const FResError* Error, const FL2CPyramidLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_PyramidLoadResp(Msg);
	GameInstance->ReqNextContent();
}

void UPyramidManager::OnUpgrade(const FResError* Error, const FL2CPyramidUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PyramidUpgradeResp(Msg);
}

void UPyramidManager::OnUpgradeComplete(const FResError* Error, const FL2CPyramidUpgradeCompleteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PyramidUpgradeCompleteResp(Msg);
}

void UPyramidManager::OnPortalBoostUse(const FResError* Error, const FL2CPyramidPortalBoostUseResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PyramidPortalBoostUseResp(Msg);
}

void UPyramidManager::OnPortalConnect(const FResError* Error, const FL2CPyramidPortalConnectResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PyramidPortalConnectResp(Msg);
}

void UPyramidManager::OnPortalWarp(const FResError* Error, const FL2CPyramidPortalWarpResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PyramidPortalWarpResp(Msg);
}

int32 UPyramidManager::GetBuildTimeLeftDays(EPortalType PortalType) const
{
	const FPortal* Portal = GetPortal(PortalType);
	if (!Portal)
	{
		Q6JsonLogRoze(Error, "UPyramidManager::GetBuildTimeLeftDays - Not found portal", Q6KV("PortalType", (int32)PortalType));
		return 0;
	}

	int32 BuildingSecs = FMath::Max(SystemConstHelper::GetPortalBuildingDays(PortalType) - Portal->BoostCount, 0) * 24 * 60 * 60;
	if (BuildingSecs == 0)
	{
		return 0;
	}

	return Q6Util::GetRemainDays(Portal->BuildStartTime + BuildingSecs);
}

int32 UPyramidManager::GetConnectTimeLeftDays(EPortalType PortalType) const
{
	const FPortal* Portal = GetPortal(PortalType);
	if (!Portal)
	{
		Q6JsonLogRoze(Error, "UPyramidManager::GetConnectTimeLeftDays - Not found portal", Q6KV("PortalType", (int32)PortalType));
		return 0;
	}

#if !UE_BUILD_SHIPPING
	if (CVarQ6PortalConnected.GetValueOnGameThread())
	{
		return 0;
	}
#endif

	int32 BuildingSecs = FMath::Max(SystemConstHelper::GetPortalConnectingDays(PortalType), 0) * 24 * 60 * 60;
	if (BuildingSecs == 0)
	{
		return 0;
	}

	return Q6Util::GetRemainDays(Portal->ConnectStartTime + BuildingSecs);
}

const FPortal* UPyramidManager::GetPortal(EPortalType PortalType) const
{
	if (PyramidInfo.Portals.IsValidIndex((int32)PortalType - 1))
	{
		const FPortal& Portal = PyramidInfo.Portals[(int32)PortalType - 1];
		return &Portal;
	}

	return nullptr;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, PyramidLoadResp)
{
	auto Action = ACTION_PARSE_PyramidLoadResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	CharacterPortalHistory.Reset();
	RelicPortalHistory.Reset();
	SculpturePortalHistory.Reset();
	for (const FPortalRecord& PortalRecord : Res.PortalHistory)
	{
		AddPortalHistory(PortalRecord);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, PyramidUpgradeResp)
{
	auto Action = ACTION_PARSE_PyramidUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, PyramidUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_PyramidUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.Info;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, PyramidPortalBoostUseResp)
{
	auto Action = ACTION_PARSE_PyramidPortalBoostUseResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, PyramidPortalConnectResp)
{
	auto Action = ACTION_PARSE_PyramidPortalConnectResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, PyramidPortalWarpResp)
{
	auto Action = ACTION_PARSE_PyramidPortalWarpResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;
	AddPortalHistory(Res.PortalRecord);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.Pyramid;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.Pyramid;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, DevPyramidOpenResp)
{
	auto Action = ACTION_PARSE_DevPyramidOpenResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, DevPyramidUpgradeResp)
{
	auto Action = ACTION_PARSE_DevPyramidUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, DevPyramidPortalBoostUseResp)
{
	auto Action = ACTION_PARSE_DevPyramidPortalBoostUseResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, DevPyramidPortalClearResp)
{
	auto Action = ACTION_PARSE_DevPyramidPortalClearResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.PyramidInfo;

	for (auto& Elem : CharacterPortalHistory)
	{
		const FPortalRecord& PortalInfo = Elem.Value;
		if (PortalInfo.PortalId == Res.PortalId)
		{
			CharacterPortalHistory.Remove(FCharacterType(PortalInfo.Type));
			return true;
		}
	}

	for (auto& Elem : RelicPortalHistory)
	{
		const FPortalRecord& PortalInfo = Elem.Value;
		if (PortalInfo.PortalId == Res.PortalId)
		{
			RelicPortalHistory.Remove(FRelicType(PortalInfo.Type));
			return true;
		}
	}

	for (auto& Elem : SculpturePortalHistory)
	{
		const FPortalRecord& PortalInfo = Elem.Value;
		if (PortalInfo.PortalId == Res.PortalId)
		{
			SculpturePortalHistory.Remove(FSculptureType(PortalInfo.Type));
			return true;
		}
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPyramidManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	PyramidInfo = Res.Pyramid;

	return true;
}