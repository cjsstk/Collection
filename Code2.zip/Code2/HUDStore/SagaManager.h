#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"
#include "SagaManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FRewardInfo;
struct FMissionCombat;
struct FCombatMissionInfo;

class UCCEndGameEvent;

///////////////////////////////////////////////////////////////////////////////////////////
// USagaManager
UCLASS()
class Q6_API USagaManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	USagaManager();

	// Req
	void ReqSagaHistory() const;
	void ReqStageBegin() const;
	void ReqStageEnd(const UCCEndGameEvent* Event,
					 const FString& Chronicle,
					 const FCombatMissionInfo& CombatMissionInfo) const;
	void ReqStoryStageClear(FSagaType SagaType) const;

#if !UE_BUILD_SHIPPING
	void ReqDevStageBegin() const;
	void ReqDevStoryStageClear(FSagaType SagaType) const;
#endif

	FSagaType GetLastSagaType() const { return LastType; }
	bool IsStageCleared(int32 InEpisode, int32 InStage, int32 InSubStage) const;
	bool IsEpisodeCleared(int32 InEpisode) const;
	bool IsEpisodeClearingSagaType(FSagaType SagaType) const;

	int32 GetPlayingEpisode() const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnSagaLoadResp(const FResError* Error, const FL2CSagaLoadResp& Res);
	void OnStageBeginResp(const FResError* Error, const FL2CSagaStageBeginResp& Res);
	void OnStageEndResp(const FResError* Error, const FL2CSagaStageEndResp& Res);
	void OnStoryStageClearResp(const FResError* Error, const FL2CSagaStoryStageClearResp& Res);

	// On Actions
	DECLARE_ACTION_HANDLER(SagaLoadResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);

private:
	void UpdateSagaHistory(FSagaType Type);

	FSagaType LastType;
};
