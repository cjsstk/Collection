#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "RelicManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FRelicId;
struct FRelicInfo;
struct FRelicType;

struct FRelic
{
	FRelic(const FRelicInfo& InInfo)
		: Hp(0)
		, Atk(0)
		, Def(0)
	{
		Info = InInfo;
	}

	void SetStashed(int32 Stashed) { Info.Stashed = Stashed; }
	void SetNewly(int32 Newly) { Info.Newly = Newly; }

	const FRelicInfo& GetInfo() const { return Info; }
	const FRelicId& GetId() const { return Info.RelicId; }
	bool IsStashed() const { return Info.Stashed > 0; }
	bool IsNewly() const { return Info.Newly > 0; }

	FRelicInfo Info;

	mutable int64 Hp;	// buffer for sort, calculated just before sort
	mutable int64 Atk;	// buffer for sort, calculated just before sort
	mutable int64 Def;	// buffer for sort, calculated just before sort
};

///////////////////////////////////////////////////////////////////////////////////////////
// URelicManager

UCLASS()
class Q6_API URelicManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	URelicManager();

	void ReqList(int32 PageNo = 0) const;
	void ReqClearNew(const TArray<FRelicId>& RelicIds) const;
	void ReqSetLock(const FRelicId& Id, bool bLock) const;
	void ReqAddXp(const FRelicId& TargetId, const TArray<int64>& SourceIds) const;
	void ReqPromote(const FRelicId& TargetId) const;
	void ReqTierUp(const FRelicId& TargetId, const TArray<int64>& SourceIds) const;
	void ReqSetStash(const TArray<int64>& TargetIds, bool bStashed) const;

	bool IsEqualRelicType(const FRelicId& RelicIdA, const FRelicId& RelicIdB) const;
	TArray<FRelicType> GetRelicTypes(const TArray<FRelicId>& RelicIds) const;
	TArray<const FRelic*> GetRelics(ESortMenu SortMenu, ESortCategory Category, bool bStashed = false) const;
	const TMap<FRelicId, FRelic>& GetAllRelics() const { return Relics; }
	void SortByPicked(TArray<const FRelic*>& OutRelics, const TArray<FRelicId>& RelicIds) const;

	const FRelic* Find(FRelicId Id) const { return Relics.Find(Id); }
	int32 GetLeastUpTier(const FRelicId& TargetRelicId) const;
	TMap<FRelicType, const FRelicInfo*> GetPortalConnectRelics() const;
	int32 GetAllRelicNum() const { return Relics.Num(); }
	int32 GetStashedRelicNum(bool bStashed) const;
	bool HasRelic(EItemGrade InGrade) const;

	void Dump() const;

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CRelicListResp& Msg);
	void OnLoadResp(const FResError* Error, const FL2CRelicLoadResp& Msg);
	void OnAddXpResp(const FResError* Error, const FL2CRelicAddXpResp& Msg);
	void OnPromoteResp(const FResError* Error, const FL2CRelicPromoteResp& Msg);
	void OnTierUpResp(const FResError* Error, const FL2CRelicTierUpgradeResp& Msg);
	void OnSetStashResp(const FResError* Error, const FL2CRelicSetStashResp& Msg);
	void OnClearNewResp(const FResError* Error, const FL2CRelicClearNewResp& Msg);

	// Setter
	bool Add(const FRelicInfo& Info);
	bool Remove(const FRelicId& Id);
	bool Update(const FRelicInfo& Info);

	// Subroutines of OnAction
	DECLARE_ACTION_HANDLER(ClearRelic);
	DECLARE_ACTION_HANDLER(RelicLoadResp);
	DECLARE_ACTION_HANDLER(RelicListResp);
	DECLARE_ACTION_HANDLER(RelicRemoveResp);
	DECLARE_ACTION_HANDLER(RelicAddXpResp);
	DECLARE_ACTION_HANDLER(RelicPromoteResp);
	DECLARE_ACTION_HANDLER(RelicTierUpResp);
	DECLARE_ACTION_HANDLER(RelicSetStashResp);
	DECLARE_ACTION_HANDLER(RelicClearNewResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(DevRelicNewResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(SummonPickupResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(VacationEndResp);
	DECLARE_ACTION_HANDLER(DevBondAddResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(AlchemylabReceiveResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);
	DECLARE_ACTION_HANDLER(ShopSellItemResp);

private:
	TMap<FRelicId, FRelic> Relics;
};

void DumpRelic(const FRelicInfo& Info);
