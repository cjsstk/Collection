// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "HUDStoreInterface.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FResError;

enum class EHSActionType : uint16;
class UQ6GameInstance;

///////////////////////////////////////////////////////////////////////////////////////////
// Delegates

DECLARE_DELEGATE_RetVal_OneParam(bool, FOnHSAction, TSharedPtr<FHSAction>);

///////////////////////////////////////////////////////////////////////////////////////////
// Store Types

UENUM()
enum class EHSType : int8
{
	Invalid = -1,
	WorldUser,
	Character,
	BagItem,
	Relic,
	Friend,
	JokerSet,
	Sculpture,
	ActRecord,
	UserRecord,
	Codex,
	WeeklyMission,
	CharMission,
	EventMission,
	Bond,
	Raid,
	Party,
	Reward,
	Saga,
	Special,
	Summon,
	Pyramid,
	Temple,
	PowerPlant,
	Pet,
	Vacation,
	Smelter,
	Alchemylab,
	Ui,
	TrainingCenter,
	DailyDungeon,
	Mail,
	CheckIn,
	Shop,
	Event,
	LobbyTemplate,
	LobbySet,
	NewMark,
	Title,
	ContentFeatureOpen,
	Avatar,
	BattleHelper,
	FriendBook,
	Max,
};
#define EHSType2Int32(X) static_cast<int32>(X)
static const int32 EHSTypeMin = EHSType2Int32(EHSType::Invalid) + 1;
static const int32 EHSTypeMax = EHSType2Int32(EHSType::Max);
#define IS_VALID_STORE_TYPE(X) (EHSTypeMin <= (X) && (X) < EHSTypeMax)

///////////////////////////////////////////////////////////////////////////////////////////
// UHUDStoreBase

UCLASS()
class UHUDStoreBase : public UObject
{
	GENERATED_BODY()

public:
	UHUDStoreBase() : GameInstance(nullptr), StoreType(EHSType::Invalid) {}

	virtual ~UHUDStoreBase();

	virtual void RegisterActionHandlers() {}
	virtual void Tick(float) {}
	virtual void OnPostLoadResource() {}

	virtual void InitWithGame(UQ6GameInstance* InGameInstance) { GameInstance = InGameInstance; }
	EHSType GetStoreType() const { return StoreType; }

protected:
	virtual void OnError(const FResError* Error) const;

	void InitStore(EHSType InStoreType) { StoreType = InStoreType; }

	void RegisterActionHandler(EHSActionType ActionType, const FOnHSAction& ActionDelegate);
	void RegisterNullActionHandler(EHSActionType ActionType);

	UPROPERTY(Transient)
	UQ6GameInstance* GameInstance;

private:
	EHSType StoreType;
};
