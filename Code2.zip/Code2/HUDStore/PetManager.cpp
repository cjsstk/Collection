#include "PetManager.h"

#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UPetManager

UPetManager::UPetManager()
{
	InitStore(EHSType::Pet);
}

void UPetManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPetLoad Out;

	ClientNetwork.WsRequest(TEXT("pet/load"), Out,
		TQ6ResponseDelegate<FL2CPetLoadResp>::CreateUObject(
			const_cast<UPetManager*>(this), &UPetManager::OnLoadResp));
}

void UPetManager::ReqPetParkUpgrade() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPetParkUpgrade Out;

	ClientNetwork.WsRequest(TEXT("pet/parkUpgrade"), Out,
		TQ6ResponseDelegate<FL2CPetParkUpgradeResp>::CreateUObject(
			const_cast<UPetManager*>(this), &UPetManager::OnPetParkUpgradeResp));
}

void UPetManager::ReqPetParkUpgradeComplete() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPetParkUpgradeComplete Out;

	ClientNetwork.WsRequest(TEXT("pet/parkUpgradeComplete"), Out,
		TQ6ResponseDelegate<FL2CPetParkUpgradeCompleteResp>::CreateUObject(
			const_cast<UPetManager*>(this), &UPetManager::OnPetParkUpgradeCompleteResp));
}

void UPetManager::ReqPetSkillUpgrade(FPetId PetId, int32 Index) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPetSkillUpgrade Out;
	Out.PetId = PetId;
	Out.Index = Index;

	ClientNetwork.WsRequest(TEXT("pet/skillUpgrade"), Out,
		TQ6ResponseDelegate<FL2CPetSkillUpgradeResp>::CreateUObject(
			const_cast<UPetManager*>(this), &UPetManager::OnPetSkillUpgradeResp));
}

void UPetManager::ReqHarvest() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LPetHarvest Out;

	ClientNetwork.WsRequest(TEXT("pet/harvest"), Out,
		TQ6ResponseDelegate<FL2CPetHarvestResp>::CreateUObject(
			const_cast<UPetManager*>(this), &UPetManager::OnPetParkHarvestResp));
}

#if !UE_BUILD_SHIPPING
void UPetManager::ReqDevPetParkUpgrade(int32 TargetLevel) const
{
	FC2LDevPetParkUpgrade Out;
	Out.Level = TargetLevel;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	ClientNetwork.WsRequest(TEXT("dev/petParkUpgrade"), Out,
		TQ6ResponseDelegate<FL2CPetParkUpgradeCompleteResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CPetParkUpgradeCompleteResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "/c_pet_park_upgrade Ok");
		ACTION_DISPATCH_PetParkUpgradeCompleteResp(Res);
	}));
}
#endif

void UPetManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UPetManager, PetLoadResp);
	REGISTER_ACTION_HANDLER(UPetManager, PetParkUpgradeResp);
	REGISTER_ACTION_HANDLER(UPetManager, PetParkUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UPetManager, PetParkHarvestResp);
	REGISTER_ACTION_HANDLER(UPetManager, PetSkillUpgradeResp);
	REGISTER_ACTION_HANDLER(UPetManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UPetManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UPetManager, DevPetParkOpenResp);
	REGISTER_ACTION_HANDLER(UPetManager, DevPetParkProduceResp);
	REGISTER_ACTION_HANDLER(UPetManager, DevPetSkillUpgradeResp);
	REGISTER_ACTION_HANDLER(UPetManager, DevPetNewResp);
	REGISTER_ACTION_HANDLER(UPetManager, DevSpecialClearResp);
}

void DumpPetInfo(const FPetInfo& Info)
{
	Q6JsonLogZagal(Warning, "", Q6KV("PetId", Info.PetId));
	Q6JsonLogZagal(Warning, "", Q6KV("UserId", Info.UserId));
	Q6JsonLogZagal(Warning, "", Q6KV("Type", Info.Type));
	Q6JsonLogZagal(Warning, "", Q6KV("Created", Info.Created));
	Q6JsonLogZagal(Warning, "", Q6KV("Skill1Level", Info.Skill1Level));
	Q6JsonLogZagal(Warning, "", Q6KV("Skill2Level", Info.Skill2Level));
	Q6JsonLogZagal(Warning, "", Q6KV("Skill3Level", Info.Skill3Level));
}

void UPetManager::Dump() const
{
	Q6JsonLogZagal(Warning, "Dump PetInfos");

	for (const auto& Entry : Pets)
	{
		DumpPetInfo(Entry.Value);
	}
}

const FPetInfo* UPetManager::GetPetInfoByIndex(int32 Index) const
{
	int32 i = Pets.Num() - 1;
	for (const auto& Elem : Pets)
	{
		if (i == Index)
		{
			return &Elem.Value;
		}

		--i;
	}

	return nullptr;
}

int32 UPetManager::GetIndexByPetId(const FPetId& InPetId) const
{
	int32 i = Pets.Num() - 1;
	for (const auto& Elem : Pets)
	{
		const FPetId& ItPetId = Elem.Key;
		if (ItPetId == InPetId)
		{
			return i;
		}

		--i;
	}

	return INDEX_NONE;
}

const FPetInfo* UPetManager::GetPet(FPetType PetType) const
{
	for (const auto& Elem : Pets)
	{
		const FPetInfo& Info = Elem.Value;
		if (Info.Type == PetType)
		{
			return &Info;
		}
	}

	return nullptr;
}

bool UPetManager::HasPet(const FPetId& PetId) const
{
	return Pets.Contains(PetId);
}

void UPetManager::UpdatePet(const FPetInfo& Info)
{
	if (FPetInfo* PetInfo = Pets.Find(Info.PetId))
	{
		*PetInfo = Info;
	}
	else
	{
		Pets.Add(Info.PetId, Info);
	}
}

void UPetManager::OnLoadResp(const FResError* Error, const FL2CPetLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_PetLoadResp(Msg);
	GameInstance->ReqNextContent();
}

void UPetManager::OnPetParkUpgradeResp(const FResError* Error, const FL2CPetParkUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PetParkUpgradeResp(Msg);
}

void UPetManager::OnPetParkUpgradeCompleteResp(const FResError* Error, const FL2CPetParkUpgradeCompleteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PetParkUpgradeCompleteResp(Msg);
}

void UPetManager::OnPetSkillUpgradeResp(const FResError* Error, const FL2CPetSkillUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PetSkillUpgradeResp(Msg);
}

void UPetManager::OnPetParkHarvestResp(const FResError* Error, const FL2CPetHarvestResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_PetParkHarvestResp(Msg);
}

IMPLEMENT_ACTION_HANDLER(UPetManager, PetLoadResp)
{
	auto Action = ACTION_PARSE_PetLoadResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	for (const FPetInfo& Info : Res.Pets)
	{
		UpdatePet(Info);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, PetParkUpgradeResp)
{
	auto Action = ACTION_PARSE_PetParkUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, PetParkUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_PetParkUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, PetParkHarvestResp)
{
	auto Action = ACTION_PARSE_PetParkHarvestResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, PetSkillUpgradeResp)
{
	auto Action = ACTION_PARSE_PetSkillUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	UpdatePet(Res.PetInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	for (const FPetInfo& PetInfo : Res.Pets)
	{
		UpdatePet(PetInfo);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	for (const FPetInfo& PetInfo : Res.Pets)
	{
		UpdatePet(PetInfo);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, DevPetParkOpenResp)
{
	auto Action = ACTION_PARSE_DevPetParkOpenResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	for (const FPetInfo& PetInfo : Res.Pets)
	{
		UpdatePet(PetInfo);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, DevPetParkProduceResp)
{
	auto Action = ACTION_PARSE_DevPetParkProduceResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, DevPetSkillUpgradeResp)
{
	auto Action = ACTION_PARSE_DevPetSkillUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	UpdatePet(Res.PetInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, DevPetNewResp)
{
	auto Action = ACTION_PARSE_DevPetNewResp(InAction);
	auto& Res = Action->GetVal();

	UpdatePet(Res.PetInfo);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UPetManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	PetPark = Res.PetPark;

	for (const FPetInfo& PetInfo : Res.Pets)
	{
		UpdatePet(PetInfo);
	}

	return true;
}