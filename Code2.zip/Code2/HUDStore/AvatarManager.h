#pragma once

#include "Q6ClientNetwork.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6UIDefine.h"
#include "AvatarManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;

///////////////////////////////////////////////////////////////////////////////////////////
// UAvatarManager

UCLASS()
class Q6_API UAvatarManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UAvatarManager();

	// Req
	void ReqLoad() const;
	void ReqSave(const FAvatarInfo& InAvatarInfo) const;

	// Getter
	const FAvatarInfo& GetAvatarInfo() const { return AvatarInfo; }
	const TMap<FAvatarFrameType, FAvatarFrame>& GetAvatarFrames() const { return AvatarFrames; }
	const TMap<FAvatarEffectType, FAvatarEffect>& GetAvatarEffects() const { return AvatarEffects; }

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnLoadResp(const FResError* Error, const FL2CAvatarLoadResp& Res);
	void OnSaveResp(const FResError* Error, const FL2CAvatarSaveResp& Res);

	// On Actions
	DECLARE_ACTION_HANDLER(AvatarLoadResp);
	DECLARE_ACTION_HANDLER(AvatarSaveResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(DevAvatarAddResp);

	// Setter

	void UpdateAvatarItems(const TArray<FAvatarFrame>& Frames, const TArray<FAvatarEffect>& Effects);

	void UpdateAvatarFrame(const FAvatarFrame& Info);
	void UpdateAvatarEffect(const FAvatarEffect& Info);

	void RemoveAvatarFrame(FAvatarFrameType FrameType);
	void RemoveAvatarEffect(FAvatarEffectType EffectType);

	// Fields

	FAvatarInfo AvatarInfo;

	TMap<FAvatarFrameType, FAvatarFrame> AvatarFrames;
	TMap<FAvatarEffectType, FAvatarEffect> AvatarEffects;
};

void DumpAvatarFrame(const FAvatarFrame& Info);
void DumpAvatarEffect(const FAvatarEffect& Info);
