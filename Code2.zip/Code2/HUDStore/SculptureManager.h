#pragma once

#include "Q6ClientNetwork.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6UIDefine.h"

#include "SculptureManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FSculptureId;
struct FSculptureInfo;
struct FSculptureType;

struct FSculpture
{
	FSculpture(const FSculptureInfo& InInfo)
		: Hp(0)
		, Atk(0)
		, Def(0)
	{
		Info = InInfo;
	}

	const FSculptureInfo& GetInfo() const { return Info; }
	const FSculptureId& GetId() const { return Info.SculptureId; }
	bool IsStashed() const { return Info.Stashed > 0; }
	bool IsNewly() const { return Info.Newly > 0; }

	void SetNewly(int32 Newly) { Info.Newly = Newly; }
	void SetStashed(int32 Stashed) { Info.Stashed = Stashed; }

	FSculptureInfo Info;

	mutable int64 Hp;	// buffer for sort, calculated just before sort
	mutable int64 Atk;	// buffer for sort, calculated just before sort
	mutable int64 Def;	// buffer for sort, calculated just before sort
};

///////////////////////////////////////////////////////////////////////////////////////////
// USculptureManager

UCLASS()
class Q6_API USculptureManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	USculptureManager();

	void ReqList(int32 PageNo = 0) const;
	void ReqClearNew(const TArray<FSculptureId>& SculptureIds) const;
	void ReqSetLock(const FSculptureId& Id, bool bLock) const;
	void ReqAddXp(const FSculptureId& TargetId, const TArray<int64>& SourceIds) const;
	void ReqPromote(const FSculptureId& TargetId) const;
	void ReqTierUp(const FSculptureId& TargetId, const TArray<int64>& SourceIds) const;
	void ReqSetStash(const TArray<int64>& TargetIds, bool bStashed) const;

	const FSculpture* const Find(FSculptureId Id) const { return Sculptures.Find(Id); }
	bool IsEqualSculptureType(const FSculptureId& SculptureIdA, const FSculptureId& SculptureIdB) const;
	TArray<FSculptureType> GetSculptureTypes(const TArray<FSculptureId>& SculptureIds) const;
	TArray<const FSculpture*> GetSculptures(ESortMenu SortMenu, ESortCategory Category, bool bStashed = false) const;
	const TMap<FSculptureId, FSculpture>& GetAllSculptures() const { return Sculptures; }

	void SortByPicked(TArray<const FSculpture*>& OutSculptures, const TArray<FSculptureId>& SculptureIds) const;
	int32 GetLeastUpTier(const FSculptureId& TargetSculputreId) const;
	TMap<FSculptureType, const FSculptureInfo*> GetPortalConnectSculptures() const;
	int32 GetAllSculptureNum() const { return Sculptures.Num(); }
	int32 GetStashedSculptureNum(bool bStashed) const;
	bool HasSculpture(EItemGrade InGrade) const;

	void Dump() const;

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CSculptureListResp& Msg);
	void OnLoadResp(const FResError* Error, const FL2CSculptureLoadResp& Msg);
	void OnAddXpResp(const FResError* Error, const FL2CSculptureAddXpResp& Msg);
	void OnPromoteResp(const FResError* Error, const FL2CSculpturePromoteResp& Msg);
	void OnTierUpgradeResp(const FResError* Error, const FL2CSculptureTierUpgradeResp& Msg);
	void OnSetStashResp(const FResError* Error, const FL2CSculptureSetStashResp& Msg);
	void OnClearNewResp(const FResError* Error, const FL2CSculptureClearNewResp& Msg);

	// Setter
	bool Add(const FSculptureInfo& Info);
	bool Remove(const FSculptureId& Id);
	bool Update(const FSculptureInfo& Info);

	// Subroutines of OnAction
	DECLARE_ACTION_HANDLER(ClearSculpture);
	DECLARE_ACTION_HANDLER(SculptureLoadResp);
	DECLARE_ACTION_HANDLER(SculptureListResp);
	DECLARE_ACTION_HANDLER(SculptureRemoveResp);
	DECLARE_ACTION_HANDLER(SculptureAddXpResp);
	DECLARE_ACTION_HANDLER(SculpturePromoteResp);
	DECLARE_ACTION_HANDLER(SculptureTierUpResp);
	DECLARE_ACTION_HANDLER(SculptureSetStashResp);
	DECLARE_ACTION_HANDLER(SculptureClearNewResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(DevSculptureNewResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(SummonPickupResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);
	DECLARE_ACTION_HANDLER(AlchemylabReceiveResp);
	DECLARE_ACTION_HANDLER(ShopSellItemResp);

private:
	TMap<FSculptureId, FSculpture> Sculptures;
};

void DumpSculpture(const FSculptureInfo& Info);
