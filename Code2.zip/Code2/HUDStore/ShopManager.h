#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "ShopManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FShopLimitItemInfo;
struct FShopType;


///////////////////////////////////////////////////////////////////////////////////////////
// StoreManager

UCLASS()
class Q6_API UShopManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UShopManager();

	// Req
	void ReqList(bool bEnterLobby = true) const;
	void ReqSaleSchedule() const;
	void ReqBuyItem(const FShopType& ShopType, const int32& Count) const;
	void ReqSellItem(const ELootCategory& Category, const TArray<int64>& ItemIds) const;
	void ReqClearNew(EShopCategory ShopCategory, ELootCategory CostCategory) const;

	const TMap<int32, FShopLimitItemInfo>* GetShopLimitItemInfos(const EShopBuyType& ShopBuyType) const { return ShopLimitItemInfosMap.Find(ShopBuyType); }
	const FShopClearNewInfo* GetShopClearNewInfo(EShopCategory ShopCategory, ELootCategory CostCategory) const;

	int32 GetStocks(EShopBuyType InShopBuyType, FShopType InShopType) const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnListResp(const FResError* Error, const FL2CShopListResp& Res, bool bEnterLobby);
	void OnSaleScheduleResp(const FResError* Error, const FL2CShopSaleScheduleResp& Res);
	void OnBuyItemResp(const FResError* Error, const FL2CShopBuyItemResp& Res);
	void OnSellItemResp(const FResError* Error, const FL2CShopSellItemResp& Res);
	void OnClearNewResp(const FResError* Error, const FL2CShopClearNewResp& Res);

	// On Actions
	DECLARE_ACTION_HANDLER(ShopListResp);
	DECLARE_ACTION_HANDLER(ShopBuyItemResp);
	DECLARE_ACTION_HANDLER(ShopClearNewResp);
	DECLARE_ACTION_HANDLER(DevShopResetResp);

private:

	void InitShopLimitItemList(const TArray<FShopLimitItemInfo>& InShopLimitItemInfos);
	void MonthlyResetShopLimitItem();
	void UpdateShopLimitItem(const EShopBuyType& ShopBuyType, const FShopType& ShopType, const int32& Count);
	void UpdateClearInfo(const FShopClearNewInfo& Info);

	TMap<EShopBuyType, TMap<int32, FShopLimitItemInfo>> ShopLimitItemInfosMap;
	TArray<FShopClearNewInfo> ShopClearNewInfoList;
};
