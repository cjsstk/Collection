#include "BondManager.h"

#include "Q6.h"
#include "Q6GameInstance.h"
#include "WidgetUtil.h"

UBondManager::UBondManager()
{
	InitStore(EHSType::Bond);
}

UBondManager::~UBondManager()
{
}

void UBondManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	FC2LBondLoad Out;

	ClientNetwork.WsRequest(TEXT("bond/load"), Out,
		TQ6ResponseDelegate<FL2CBondLoadResp>::CreateUObject(
			const_cast<UBondManager*>(this), &UBondManager::OnLoadResp));
}

void UBondManager::UpdateCharacterBonds(const TArray<FCharacterBond>& InCharacterBonds)
{
	BondHistories.Reset();

	for (const auto& InCharacterBond : InCharacterBonds)
	{
		UpdateCharacterBond(InCharacterBond);
	}
}

const FCharacterBond& UBondManager::GetCharacterBond(FCharacterType CharacterType) const
{
	const FCharacterBond* CharacterBond = Find(CharacterType);
	if (CharacterBond)
	{
		return *CharacterBond;
	}

	static FCharacterBond DummyCharacterBond = MakeDefaultCharacterBond(GetCMS(), CharacterType);
	return DummyCharacterBond;
}

int32 UBondManager::GetSupportSkillLevel(FCharacterType CharacterType) const
{
	const FCharacterBond* CharacterBond = Find(CharacterType);
	if (!CharacterBond)
	{
		return 1;	// default support skill level
	}

	return CharacterBond->SupportSkillLevel;
}

void UBondManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UBondManager, BondLoadResp);
	REGISTER_ACTION_HANDLER(UBondManager, DevBondAddResp);
	REGISTER_ACTION_HANDLER(UBondManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, VacationEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UBondManager, EventContentMultiSideBattleStageEndResp);
}

void UBondManager::OnLoadResp(const FResError* Error, const FL2CBondLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_BondLoadResp(Msg);
	GameInstance->ReqNextContent();
}

void UBondManager::UpdateCharacterBond(const FCharacterBond& InCharacterBond)
{
	if (InCharacterBond.CharacterType == CharacterTypeInvalid)
	{
		Q6JsonLogRoze(Warning, "UBondManager::UpdateCharacterBond - Invalid character type");
		return;
	}

	const FCharacterBond* Found = CharacterBonds.Find(InCharacterBond.CharacterType);
	FBondHistory History = FBondHistory();
	History.CharacterType = InCharacterBond.CharacterType;

	if (Found)
	{
		if (Found->Level == InCharacterBond.Level)
		{
			Q6JsonLogRoze(Verbose, "Character Bond Gain Xp",
				Q6KV("CharacterType", InCharacterBond.CharacterType),
				Q6KV("Level", InCharacterBond.Level),
				Q6KV("Xp", InCharacterBond.Xp),
				Q6KV("GainXp", InCharacterBond.Xp - Found->Xp));
		}
		else
		{
			Q6JsonLogRoze(Verbose, "Character Bond Level Up",
				Q6KV("CharacterType", InCharacterBond.CharacterType),
				Q6KV("NewLevel", InCharacterBond.Level),
				Q6KV("Xp", InCharacterBond.Xp));
		}

		History.GainedXp = InCharacterBond.Xp - Found->Xp;
		History.bLevelUp = Found->Level != InCharacterBond.Level;
	}
	else
	{
		Q6JsonLogRoze(Verbose, "Character Bond New",
			Q6KV("CharacterType", InCharacterBond.CharacterType),
			Q6KV("Level", InCharacterBond.Level),
			Q6KV("Xp", InCharacterBond.Xp));

		History.GainedXp = InCharacterBond.Xp;
		History.bLevelUp = false;
	}

	BondHistories.Add(InCharacterBond.CharacterType, History);
	CharacterBonds.Add(InCharacterBond.CharacterType, InCharacterBond);
}

IMPLEMENT_ACTION_HANDLER(UBondManager, BondLoadResp)
{
	auto Action = ACTION_PARSE_BondLoadResp(InAction);

	CharacterBonds.Reset();

	const auto& Res = Action->GetVal();
	for (const FCharacterBond& CharacterBond : Res.CharacterBonds)
	{
		CharacterBonds.Add(CharacterBond.CharacterType, CharacterBond);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, DevBondAddResp)
{
	auto Action = ACTION_PARSE_DevBondAddResp(InAction);

	const auto& Res = Action->GetVal();
	UpdateCharacterBond(Res.CharacterBond);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, VacationEndResp)
{
	auto Action = ACTION_PARSE_VacationEndResp(InAction);

	const auto& Res = Action->GetVal();
	UpdateCharacterBond(Res.Bond);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	UpdateCharacterBonds(Res.CharacterBonds);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UBondManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);

	const auto& Res = Action->GetVal();
	if (Res.CharacterBonds.Num() > 0)
	{
		UpdateCharacterBonds(Res.CharacterBonds);
		return true;
	}

	return false;
}
