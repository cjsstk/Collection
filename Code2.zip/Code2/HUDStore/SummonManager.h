#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"
#include "Q6GameState.h"
#include "SummonManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;

///////////////////////////////////////////////////////////////////////////////////////////
// USummonManager

UCLASS()
class Q6_API USummonManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	USummonManager();
	~USummonManager();

public:
	// Req
	void ReqLoad() const;
	void ReqBoxPurchase(const FBoxProductType& BoxId, bool bInCanRepeatSummon) const;
	void ReqBoxSchedule() const;
	void ReqPickup(FBoxProductType BoxProductType, int32 ItemType, bool bInCanRepeatSummon) const;

	bool IsSummonFree(FBoxProductType usedId) const;
	int32 GetPageIndex(int32 PageKey) const;

	const TArray<int32>& GetOrderedPageList() const { return OrderedPageList; }
	const FSummonResult& GetSummonResult() const { return SummonResult; }
	int32 GetMileage(int32 EventId) const;
	const TArray<FSummonDiskReward>& GetSummonDiskRewards() const { return SummonDiskRewards; }
	const TArray<FBoxProductType>& GetSummonFreeInfos() const { return SummonFreeInfos; }
	const TMap<int32, int32>& GetMileages() const { return Mileages; }

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res

	void MakeSummonResult(const FL2CSummonPurchaseResp& Res);
	void MakeSummonResult(const FL2CSummonPickupResp& Res);
	void FillSummonResultInternal();

	void ShowSummonResult(FBoxProductType BoxProductType);

	void OnLoadResp(const FResError* Error, const FL2CSummonLoadResp& Res);
	void OnBoxPurchaseResp(const FResError* Error, const FL2CSummonPurchaseResp& Res, bool bInCanRepeatSummon);
	void OnBoxScheduleResp(const FResError* Error, const FL2CSummonScheduleResp& Res);
	void OnPickupResp(const FResError* Error, const FL2CSummonPickupResp& Res, bool bInCanRepeatSummon);

	DECLARE_ACTION_HANDLER(SummonLoadResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(SummonBoxScheduleResp);
	DECLARE_ACTION_HANDLER(SummonPickupResp);
	DECLARE_ACTION_HANDLER(DevSummonMileageSetResp);

	TArray<FBoxProductType> SummonFreeInfos;
	TMap<int32 /* EventId */, int32 /* Mileage*/> Mileages;
	TArray<int32> OrderedPageList;
	FSummonResult SummonResult;
	TArray<FSummonDiskReward> SummonDiskRewards;
};
