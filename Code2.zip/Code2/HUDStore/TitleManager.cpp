#include "TitleManager.h"

#include "CharacterManager.h"
#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"

UTitleManager::UTitleManager()
{
	InitStore(EHSType::Title);
}

void UTitleManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearTitle();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LUserTitleList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("userTitle/list"), Out,
		TQ6ResponseDelegate<FL2CUserTitleListResp>::CreateUObject(
			const_cast<UTitleManager*>(this), &UTitleManager::OnListResp));
}

void UTitleManager::Change(FUserTitleType Type) const
{
	if (Type != UserTitleTypeInvalid && !Titles.Contains(Type))
	{
		Q6JsonLogHekel(Warning, "Not has title change request");
		return;
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LUserTitleChange Out;
	Out.Type = Type;

	ClientNetwork.WsRequest(TEXT("userTitle/change"), Out,
		TQ6ResponseDelegate<FL2CUserTitleChangeResp>::CreateUObject(
			const_cast<UTitleManager*>(this), &UTitleManager::OnChangeResp));
}

void UTitleManager::OnListResp(const FResError* Error, const FL2CUserTitleListResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_TitleListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void UTitleManager::OnChangeResp(const FResError* Error, const FL2CUserTitleChangeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_TitleChangeResp(Msg);
}

void UTitleManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UTitleManager, ClearTitle);
	REGISTER_ACTION_HANDLER(UTitleManager, TitleListResp);
	REGISTER_ACTION_HANDLER(UTitleManager, DevTitleAddResp);
	REGISTER_ACTION_HANDLER(UTitleManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UTitleManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UTitleManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UTitleManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UTitleManager, ShopBuyItemResp);
	REGISTER_ACTION_HANDLER(UTitleManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(UTitleManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(UTitleManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(UTitleManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UTitleManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(UTitleManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UTitleManager, EventContentMultisideBattleReceiveRankRewardResp);
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, ClearTitle)
{
	Titles.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, TitleListResp)
{
	auto Action = ACTION_PARSE_TitleListResp(InAction);

	auto& Res = Action->GetVal();
	for (const FUserTitleInfo& Info : Res.Titles)
	{
		Titles.Add(Info.Type);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, DevTitleAddResp)
{
	auto Action = ACTION_PARSE_DevTitleAddResp(InAction);

	auto& Res = Action->GetVal();
	Titles.Add(Res.Type);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, ShopBuyItemResp)
{
	auto Action = ACTION_PARSE_ShopBuyItemResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTitleManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);

	auto& Res = Action->GetVal();
	if (Res.Title != UserTitleTypeInvalid)
	{
		Titles.Add(Res.Title);
	}

	return true;
}
