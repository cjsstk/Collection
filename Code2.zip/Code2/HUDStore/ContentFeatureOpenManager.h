#pragma once

#include "Q6ClientNetwork.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6UIDefine.h"
#include "ContentFeatureOpenManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FContentFeatureOpenInfo;

///////////////////////////////////////////////////////////////////////////////////////////
// UContentFeatureOpenManager

UCLASS()
class Q6_API UContentFeatureOpenManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UContentFeatureOpenManager();

	const FContentFeatureOpenInfo& GetContentFeatureAppearInfo() const { return ContentFeatureAppearInfo; }
	const TArray<FContentFeatureOpenInfo>& GetContentFeatureOpens() const { return ContentFeatureOpenInfos; }

	const FContentFeatureOpenInfo* Find(const EFeatureOpenType& InFeatureOpenType) const;
	bool IsOpenContentFeature(const EFeatureOpenType& InFeatureOpenType) const;

	void Dump() const;

	void ReqList() const;

	bool CheckContentOpenedBySubPartySlotIndex(const int32 SlotIndex) const;

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CContentFeatureOpenListResp& Res);

	// Setter
	bool Add(const TArray<FContentFeatureOpenInfo>& InContentFeatureOpenInfos);

	// Subroutines of OnAction
	DECLARE_ACTION_HANDLER(ContentFeatureOpenListResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(DevContentFeatureOpenResp);

private:
	FContentFeatureOpenInfo ContentFeatureAppearInfo;
	TArray<FContentFeatureOpenInfo> ContentFeatureOpenInfos;
};

void DumpContentFeatureOpen(const FContentFeatureOpenInfo& Info);