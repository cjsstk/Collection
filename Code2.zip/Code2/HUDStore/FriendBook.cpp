// Copyright (c) 2020 XLGames, Inc. All rights reserved.

#include "Friendbook.h"
#include "AvatarManager.h"
#include "BondManager.h"
#include "FriendManager.h"
#include "HUDStore.h"
#include "Network/LobbyObj_gen.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6Log.h"
#include "Widget/ItemWidgets.h"

#define FORMAT_FEED_IMPL(FeedCategory) FormatFeedDelegates[(int32)FeedCategory].BindLambda([&](const FCMSFriendBookFeedRow& InRow, const FFriendBookDetailedFeed& InDetailFeed, FText* OutLinkText, FItemIconInfo* OutItemInfo)
#define CMS_BOX_PRODUCT_NAME(TypeNum) (InCMS->GetBoxProductRowOrDummy(FBoxProductType(TypeNum))).DescName
#define CMS_CHARACTER_NAME(TypeNum) (InCMS->GetCharacterRowOrDummy(FCharacterType(TypeNum))).GetUnit().DescName
#define CMS_GET_TYPE_NAME(TypeName, TypeNum) (InCMS->Get##TypeName##RowOrDummy(F##TypeName##Type(TypeNum))).DescName
#define CMS_SKILL_NAME(TypeNum) (InCMS->GetSkillRowOrDummy(FSkillType(TypeNum))).DescName
#define CMS_SCULPTURE_NAME(TypeNum) (InCMS->GetSculptureRowOrDummy(FSculptureType(TypeNum))).DescName
#define CMS_RELIC_NAME(TypeNum) (InCMS->GetRelicRowOrDummy(FRelicType(TypeNum))).DescName

UFriendBook::UFriendBook()
{
	InitStore(EHSType::FriendBook);
	LastTimelineTailFeedId = FFriendBookFeedId::InvalidValue();
}

FText UFriendBook::GetUserName(const FUserId& InUserId) const
{
	if (GetHUDStore().GetWorldUser().GetId() == InUserId)
	{
		return FText::FromString(GetHUDStore().GetWorldUser().GetNickname());
	}

	const FFriendInfoEx* InFriendInfo = GetHUDStore().GetFriendManager().GetFriendInfo(InUserId);
	if (!InFriendInfo)
	{
		return FText::GetEmpty();
	}

	return FText::FromString(InFriendInfo->Name);
}

bool UFriendBook::GetItemIconInfo(const FUserId& /*InUserId*/, EItemCategory /*InCategory*/, int32 /*CMSType*/, FItemIconInfo* /*OutItemInfo*/) const
{
	return false;
}

const FAvatarInfo& UFriendBook::GetAvatarInfo(const FUserId& InUserId) const
{
	if (GetHUDStore().GetWorldUser().GetId() == InUserId)
	{
		return GetHUDStore().GetAvatarManager().GetAvatarInfo();
	}

	const FFriendInfoEx* InFriendInfo = GetHUDStore().GetFriendManager().GetFriendInfo(InUserId);
	if (!InFriendInfo)
	{
		static const FAvatarInfo DummyAvatarInfo = FAvatarInfo();
		return DummyAvatarInfo;
	}

	return InFriendInfo->Avatar;
}

void UFriendBook::SetFormatFunctions()
{
	if (!(GetGameModule()->IsCMSLoaded()))
	{
		return;
	}

	UCMS* InCMS = GetCMS();

	FormatFeedDelegates.SetNum(EFriendBookFeedCategoryMax);
	FORMAT_FEED_IMPL(EFriendBookFeedCategory::SummonCharacter)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_BOX_PRODUCT_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), CMS_CHARACTER_NAME(InDetailFeed.Param2));
		Args.Add(TEXT("3"), FText::AsNumber(InDetailFeed.Param3));
		*OutLinkText = Args[TEXT("2")].GetTextValue();
		this->GetItemIconInfo(InDetailFeed.UserId, EItemCategory::Character, InDetailFeed.Param2, OutItemInfo);
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::SummonSculpture)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_BOX_PRODUCT_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), CMS_SCULPTURE_NAME(InDetailFeed.Param2));
		Args.Add(TEXT("3"), FText::AsNumber(InDetailFeed.Param3));
		*OutLinkText = Args[TEXT("2")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::SummonRelic)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_BOX_PRODUCT_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), CMS_RELIC_NAME(InDetailFeed.Param2));
		Args.Add(TEXT("3"), FText::AsNumber(InDetailFeed.Param3));
		*OutLinkText = Args[TEXT("2")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::Character110)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_CHARACTER_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::CharacterMaxUnbind)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_CHARACTER_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::CharacterEvolution)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_CHARACTER_NAME(InDetailFeed.Param1));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::UltimateMax)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_CHARACTER_NAME(InDetailFeed.Param1));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::Bond100)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_CHARACTER_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::TurnSkill10)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_CHARACTER_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), CMS_SKILL_NAME(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::Sculpture50)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_SCULPTURE_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::SculptureTier5)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_SCULPTURE_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::Relic50)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_RELIC_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::RelicTier5)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_RELIC_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::EpisodeClear)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		const FCMSSagaRow& SagaRow = InCMS->GetSagaRowOrDummy(FSagaType(InDetailFeed.Param1));
		Args.Add(TEXT("1"), FText::AsNumber(SagaRow.Episode));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = FText::GetEmpty();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::RaidTopRank)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_GET_TYPE_NAME(Raid, InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::NewAka)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_GET_TYPE_NAME(UserTitle, InDetailFeed.Param1));
		*OutLinkText = Args[TEXT("1")].GetTextValue();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::AccountLevel)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), FText::AsNumber(InDetailFeed.Param1));
		Args.Add(TEXT("2"), FText::AsNumber(InDetailFeed.Param2));
		*OutLinkText = FText::GetEmpty();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::AvatarChange)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), CMS_CHARACTER_NAME(InDetailFeed.Param1));
		Args.Add(TEXT("2"), CMS_CHARACTER_NAME(InDetailFeed.Param2));
		*OutLinkText = FText::GetEmpty();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::JokerSet)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		*OutLinkText = FText::GetEmpty();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	FORMAT_FEED_IMPL(EFriendBookFeedCategory::Comeback)
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), this->GetUserName(InDetailFeed.UserId));
		Args.Add(TEXT("1"), FText::AsNumber(InDetailFeed.Param1));
		*OutLinkText = FText::GetEmpty();
		return FText::Format(InRow.MessageFormat, Args);;
	});

	for (int32 i = 0; i < EFriendBookFeedCategoryMax; ++i)
	{
		if (!FormatFeedDelegates[i].IsBound())
		{
			Q6JsonLogBro(Warning, "not binded to friendbook text formatter", Q6KV("index", i));
		}
	}
}

void UFriendBook::InitWithGame(UQ6GameInstance* InGameInstance)
{
	Super::InitWithGame(InGameInstance);

	SetFormatFunctions();

	FQ6ClientNetwork& ClientNetwork = InGameInstance->GetClientNetwork();
	ClientNetwork.RegisterPush(TEXT("friendBookPosted"), TQ6PushDelegate<FL2CFriendBookNotiPosted>::CreateUObject(
		this, &UFriendBook::OnFriendBookPosted));
	ClientNetwork.RegisterPush(TEXT("friendBookReacted"), TQ6PushDelegate<FL2CFriendBookNotiReacted>::CreateUObject(
		this, &UFriendBook::OnFriendBookReacted));
	ClientNetwork.RegisterPush(TEXT("friendBookReactionRemoved"), TQ6PushDelegate<FL2CFriendBookNotiReactionRemoved>::CreateUObject(
		this, &UFriendBook::OnFriendBookReactionRemoved));
}

void UFriendBook::ReqTimeline(FFriendBookFeedId InLastFeedId) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendBookGetTimeline Out;
	Out.LastFeedId = InLastFeedId; // if you want latest, FFriendBookFeedId::InvalidValue();

	ClientNetwork.WsRequest(TEXT("friendBook/getTimeline"), Out,
		TQ6ResponseDelegate<FL2CFriendBookGetTimelineResp>::CreateUObject(
			const_cast<UFriendBook*>(this), &UFriendBook::OnGetTimelineResp));
}

void UFriendBook::ReqAddReaction(FFriendBookFeedId InFeedId, EFriendBookReactionType InReaction) const
{
	const FFriendBookDetailedFeed* FriendBookFeed = FeedsMap.Find(InFeedId);
	if (!FriendBookFeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Not existing feed's reaction requested. get timeline first");
		return;
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendBookAddReaction Out;
	Out.FeedId = InFeedId;
	Out.Type = InReaction;
	Out.FeedOwnerUserId = FriendBookFeed->UserId;

	ClientNetwork.WsRequest(TEXT("friendBook/addReaction"), Out,
		TQ6ResponseDelegate<FL2CFriendBookAddReactionResp>::CreateUObject(
			const_cast<UFriendBook*>(this), &UFriendBook::OnAddReactionResp, Out));
}

void UFriendBook::ReqRemoveReaction(FFriendBookFeedId InFeedId) const
{
	const FFriendBookDetailedFeed* FriendBookFeed = FeedsMap.Find(InFeedId);
	if (!FriendBookFeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Not existing feed's remove reaction requested. get timeline first");
		return;
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendBookRemoveReaction Out;
	Out.FeedId = InFeedId;
	Out.FeedOwnerUserId = FriendBookFeed->UserId;

	ClientNetwork.WsRequest(TEXT("friendBook/removeReaction"), Out,
		TQ6ResponseDelegate<FL2CFriendBookRemoveReactionResp>::CreateUObject(
			const_cast<UFriendBook*>(this), &UFriendBook::OnRemoveReactionResp, Out));
}

void UFriendBook::ReqFeed(FFriendBookFeedId InFeedId) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LFriendBookGetFeed Out;
	Out.FeedId = InFeedId;

	ClientNetwork.WsRequest(TEXT("friendBook/getFeed"), Out,
		TQ6ResponseDelegate<FL2CFriendBookGetFeedResp>::CreateUObject(
			const_cast<UFriendBook*>(this), &UFriendBook::OnGetFeedResp));
}

TArray<const FFriendBookDetailedFeed*> UFriendBook::GetFeeds(bool bMyFeedOnly) const
{
	TArray<const FFriendBookDetailedFeed*> OutFeeds;

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	const FUserId& MyUserId = WorldUser.GetId();

	if (bMyFeedOnly)
	{
		for (auto& ItFeed : FeedsMap)
		{
			const FFriendBookDetailedFeed& ItDetailedFeed = ItFeed.Value;
			if (ItDetailedFeed.UserId != MyUserId)
			{
				continue;
			}

			OutFeeds.Add(&ItFeed.Value);
		}
	}
	else
	{
		for (auto& ItFeed : FeedsMap)
		{
			OutFeeds.Add(&ItFeed.Value);
		}
	}

	return OutFeeds;
}

const FFriendBookDetailedFeed* UFriendBook::GetFeed(FFriendBookFeedId InFeedId) const
{
	const FFriendBookDetailedFeed* InFeedPtr = FeedsMap.Find(InFeedId);
	if (!InFeedPtr)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Not existing feed", Q6KV("FeedId", InFeedId));
	}

	return InFeedPtr;
}

bool UFriendBook::HasNewFeeds() const
{
	return NewFeedNoties.Num() > 0;
}

FText UFriendBook::FormatMessage(const FFriendBookDetailedFeed& InFeedInfo, FText* OutLinkText, FItemIconInfo* OutItemInfo) const
{
	const FCMSFriendBookFeedRow& InRow = GetCMS()->GetFriendBookFeedRowOrDummy(InFeedInfo.Type);
	if (FormatFeedDelegates.IsValidIndex((int32)InRow.Category) &&
		FormatFeedDelegates[(int32)InRow.Category].IsBound())
	{
		return FormatFeedDelegates[(int32)InRow.Category].Execute(InRow, InFeedInfo, OutLinkText, OutItemInfo);
	}

	return FText::GetEmpty();
}

void UFriendBook::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookPosted);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookReacted);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookReactionRemoved);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookGetTimeline);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookAddReaction);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookRemoveReaction);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookGetFeed);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendNotifyRemove);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendRemoveResp);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookReadTimeline);
	REGISTER_ACTION_HANDLER(UFriendBook, FriendBookNewFeedsFromFile);
}

void UFriendBook::OnFriendBookPosted(const FL2CFriendBookNotiPosted& InNoti)
{
	ACTION_DISPATCH_FriendBookPosted(InNoti);
}

void UFriendBook::OnFriendBookReacted(const FL2CFriendBookNotiReacted& InNoti)
{
	ACTION_DISPATCH_FriendBookReacted(InNoti);
}

void UFriendBook::OnFriendBookReactionRemoved(const FL2CFriendBookNotiReactionRemoved& InNoti)
{
	ACTION_DISPATCH_FriendBookReactionRemoved(InNoti);
}

void UFriendBook::OnGetTimelineResp(const FResError* Error, const FL2CFriendBookGetTimelineResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	if (!Msg.Succeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Get Timeline failed");
		return;
	}

	ACTION_DISPATCH_FriendBookGetTimeline(Msg);
}

void UFriendBook::OnAddReactionResp(const FResError* Error, const FL2CFriendBookAddReactionResp& Msg, FC2LFriendBookAddReaction InReactionInfo)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	if (!Msg.Succeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Add Reaction failed");
		return;
	}

	ACTION_DISPATCH_FriendBookAddReaction(InReactionInfo);
}

void UFriendBook::OnRemoveReactionResp(const FResError* Error, const FL2CFriendBookRemoveReactionResp& Msg, FC2LFriendBookRemoveReaction InReactionInfo)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	if (!Msg.Succeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Remove Reaction failed");
		return;
	}

	ACTION_DISPATCH_FriendBookRemoveReaction(InReactionInfo);
}

void UFriendBook::OnGetFeedResp(const FResError* Error, const FL2CFriendBookGetFeedResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	if (!Msg.Succeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Get Feed failed");
		return;
	}

	ACTION_DISPATCH_FriendBookGetFeed(Msg);
}

static void CopyFeedToDetailFeed(const FFriendBookFeed& InFeed, FFriendBookDetailedFeed& OutDFeed)
{
	OutDFeed.Id = InFeed.Id;
	OutDFeed.UserId = InFeed.UserId;
	OutDFeed.Type = InFeed.Type;
	OutDFeed.Param1 = InFeed.Param1;
	OutDFeed.Param2 = InFeed.Param2;
	OutDFeed.Param3 = InFeed.Param3;
	OutDFeed.Param4 = InFeed.Param4;
	OutDFeed.Param5 = InFeed.Param5;
	OutDFeed.CreateTimeSec = InFeed.CreateTimeSec;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookPosted)
{
	auto Action = ACTION_PARSE_FriendBookPosted(InAction);

	auto& Res = Action->GetVal();
	NewFeedNoties.Add(Res.FeedId);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookReacted)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookReactionRemoved)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookGetTimeline)
{
	auto Action = ACTION_PARSE_FriendBookGetTimeline(InAction);

	auto& Res = Action->GetVal();

	if (!Res.Succeed)
	{
		return false;
	}

	for (auto& itFeed : Res.Feeds)
	{
		if (FeedsMap.Contains(itFeed.Id))
		{
			continue;
		}

		FFriendBookDetailedFeed& AddedFeed = FeedsMap.Add(itFeed.Id);
		CopyFeedToDetailFeed(itFeed, AddedFeed);
	}

	if (Res.Feeds.Num() > 0)
	{
		LastTimelineTailFeedId = Res.Feeds.Last().Id;
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookAddReaction)
{
	auto Action = ACTION_PARSE_FriendBookAddReaction(InAction);

	const FC2LFriendBookAddReaction& InReactionInfo = Action->GetVal();

	FFriendBookDetailedFeed* FriendBookFeed = FeedsMap.Find(InReactionInfo.FeedId);
	if (!FriendBookFeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Not existing feed's reaction added. get timeline first");
		return false;
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	const FUserId MyUserId = WorldUser.GetId();

	// only A single reaction to A single feed for each user.
	FriendBookFeed->Reactions.RemoveAll([MyUserId](const FFriendBookReaction& InReaction) {
		return InReaction.UserId == MyUserId;
	});

	int32 InAddedIndex = FriendBookFeed->Reactions.AddDefaulted();
	FFriendBookReaction& AddedReaction = FriendBookFeed->Reactions[InAddedIndex];
	AddedReaction.Id = FFriendBookReactionId::InvalidValue(); //
	AddedReaction.FeedId = InReactionInfo.FeedId;
	AddedReaction.Type = InReactionInfo.Type;
	AddedReaction.UserId = WorldUser.GetId();
	AddedReaction.CreateTimeSec = FDateTime::UtcNow().ToUnixTimestamp();

	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookRemoveReaction)
{
	auto Action = ACTION_PARSE_FriendBookRemoveReaction(InAction);

	const FFriendBookFeedId& FeedId = Action->GetVal().FeedId;

	FFriendBookDetailedFeed* FriendBookFeed = FeedsMap.Find(FeedId);
	if (!FriendBookFeed)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Not existing feed's reaction removed. get timeline first");
		return false;
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	const FUserId ReactionUserId = WorldUser.GetId();

	int32 RemoveReactionIndex = FriendBookFeed->Reactions.IndexOfByPredicate([ReactionUserId](const FFriendBookReaction& InReaction) {
		return InReaction.UserId == ReactionUserId;
	});
	if (RemoveReactionIndex == INDEX_NONE)
	{
		Q6JsonLogBro(Warning, "[FriendBook] Reaction not exists");
		return false;
	}

	FriendBookFeed->Reactions.RemoveAtSwap(RemoveReactionIndex);
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookGetFeed)
{
	auto Action = ACTION_PARSE_FriendBookGetFeed(InAction);

	const FFriendBookDetailedFeed& DetailedFeed = Action->GetVal().Feed;

	FFriendBookDetailedFeed* FriendBookFeed = FeedsMap.Find(DetailedFeed.Id);
	if (!FriendBookFeed)
	{
		FeedsMap.Add(DetailedFeed.Id, DetailedFeed);
		return true;
	}

	*FriendBookFeed = DetailedFeed;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendNotifyRemove)
{
	auto Action = ACTION_PARSE_FriendNotifyRemove(InAction);
	const FUserId& FriendUserId = Action->GetVal().UserId;
	return RemoveFeedByFriendUserId(FriendUserId);
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendRemoveResp)
{
	auto Action = ACTION_PARSE_FriendRemoveResp(InAction);
	const FUserId& FriendUserId = Action->GetVal().UserId;
	return RemoveFeedByFriendUserId(FriendUserId);
}

bool UFriendBook::RemoveFeedByFriendUserId(const FUserId& FriendUserId)
{
	TArray<FFriendBookFeedId> RemoveFeedIds;
	for (auto& ItFeed : FeedsMap)
	{
		const FFriendBookDetailedFeed& ItDetailedFeed = ItFeed.Value;
		if (ItDetailedFeed.UserId == FriendUserId)
		{
			RemoveFeedIds.Push(ItDetailedFeed.Id);
		}
	}

	if (RemoveFeedIds.Num() <= 0)
	{
		return false;
	}

	for (auto& ItFeed : RemoveFeedIds) {
		FeedsMap.Remove(ItFeed);
		NewFeedNoties.Remove(ItFeed);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookReadTimeline)
{
	NewFeedNoties.Empty();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UFriendBook, FriendBookNewFeedsFromFile)
{
	auto Action = ACTION_PARSE_FriendBookNewFeedFromFile(InAction);
	const FFriendBookFeedId InLatestFeedId = Action->GetVal();
	const FFriendBookFeedId InReadFeedId = Action->GetVal2();
	if (InLatestFeedId != InReadFeedId)
	{
		NewFeedNoties.Add(InLatestFeedId);
	}
	return true;
}