#include "MailManager.h"

#include "Q6GameInstance.h"
#include "HSAction.h"
#include "Q6.h"
#include "HUD/BaseHUD.h"
#include "SystemConst_gen.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UMailManager

UMailManager::UMailManager()
	: bNewMail(false)
{
	InitStore(EHSType::Mail);
}

void UMailManager::ReqList() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LMailList Out;

	ClientNetwork.WsRequest(TEXT("mail/list"),Out,
		TQ6ResponseDelegate<FL2CMailListResp>::CreateUObject(
			const_cast<UMailManager*>(this), &UMailManager::OnListResp));
}

void UMailManager::ReqReceive(const TArray<FMailId>& InMailIds) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LMailReceive Out;
	Out.MailIds = InMailIds;

	ClientNetwork.WsRequest("mail/receive", Out,
		TQ6ResponseDelegate<FL2CMailReceiveResp>::CreateUObject(
			const_cast<UMailManager*>(this), &UMailManager::OnReceiveResp));
}

void UMailManager::ReqRefreshList() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LMailRefreshList Out;

	ClientNetwork.WsRequest(TEXT("mail/refreshList"), Out,
		TQ6ResponseDelegate<FL2CMailRefreshListResp>::CreateUObject(
			const_cast<UMailManager*>(this), &UMailManager::OnRefreshListResp));
}

const bool UMailManager::IsNewMail() const
{
	return bNewMail || MailInfos.Num() > 0;
}

const bool UMailManager::IsNewMailByType(const EMailType& MailType) const
{
	for (const auto& MailInfoPair : MailInfos)
	{
		const auto& MailInfo = MailInfoPair.Value;
		if (MailInfo.Type == MailType)
		{
			return true;
		}
	}

	return false;
}

/////////////////////////////////////////////////////////////////////////////
// UMailManager HUDStore Action

void UMailManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UMailManager, MailListResp);
	REGISTER_ACTION_HANDLER(UMailManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(UMailManager, MailRefreshListResp);
	REGISTER_ACTION_HANDLER(UMailManager, NewMarkNotifyMail);
}

void UMailManager::OnListResp(const FResError* Error, const FL2CMailListResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_MailListResp(Res);
	GameInstance->ReqNextContent();
}

void UMailManager::OnReceiveResp(const FResError* Error, const FL2CMailReceiveResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	if (Res.ResultType == EMailReceiveResultType::Success)
	{
		if (Res.MailIds.Num() <= 0)
		{
			return;
		}

		ACTION_DISPATCH_MailReceiveResp(Res);
	}
	else if (Res.ResultType == EMailReceiveResultType::WattFull)
	{
		ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
		if (Q6BaseHUD)
		{
			Q6BaseHUD->OnAlert(Q6Util::GetLocalizedText("Popup", "MailWattFull"));
		}
		return;
	}

	ReqRefreshList();
}

void UMailManager::OnRefreshListResp(const FResError* Error, const FL2CMailRefreshListResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_MailRefreshListResp(Res);
	ACTION_DISPATCH_NewMarkNotifyMail(false);
}

IMPLEMENT_ACTION_HANDLER(UMailManager, MailListResp)
{
	auto Action = ACTION_PARSE_MailListResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateMailList(Resp.MailInfos, false);
	UpdateMailReceiveLogList(Resp.MailReceiveLogs);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UMailManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);
	auto& Resp = Action->GetVal();
	RemoveMailInfos(Resp.MailIds, Resp.ReceiveUtc);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UMailManager, MailRefreshListResp)
{
	auto Action = ACTION_PARSE_MailRefreshListResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateMailList(Resp.NewMailInfos, true);
	RemoveMailInfos(Resp.ExpireMailIds);
	RefreshMailList();

	return true;
}

IMPLEMENT_ACTION_HANDLER(UMailManager, NewMarkNotifyMail)
{
	auto Action = ACTION_PARSE_NewMarkNotifyMail(InAction);
	bNewMail = Action->GetVal();

	return true;
}

/////////////////////////////////////////////////////////////////////////////
// Setter

void UMailManager::AddMailReceiveInfo(const FMailInfo* InMailInfo)
{
	MailReceiveInfos.Add(*InMailInfo);
}

void UMailManager::AddMailReceiveLog(const FMailReceiveLog& InMailReceiveLog)
{
	MailReceiveLogs.AddHead(InMailReceiveLog);

	if (MailReceiveLogs.Num() > SystemConst::Q6_MAX_MAIL_RECEIVE_LOG_COUNT)
	{
		MailReceiveLogs.RemoveNode(MailReceiveLogs.GetTail());
	}
}

void UMailManager::AddMailReceiveLog(const FMailInfo* InMailInfo, int32 InReceiveUtc)
{
	FMailReceiveLog NewMailLog;
	NewMailLog.MailId = InMailInfo->MailId;
	NewMailLog.RewardType = InMailInfo->RewardType;
	NewMailLog.RewardItem = InMailInfo->RewardItem;
	NewMailLog.ReasonType = InMailInfo->ReasonType;
	NewMailLog.ReceiveUtc = InReceiveUtc;

	AddMailReceiveLog(NewMailLog);
}

void UMailManager::RemoveMailInfos(const TArray<FMailId>& InMailIds)
{
	for (const FMailId& MailId : InMailIds)
	{
		MailInfos.Remove(MailId);
	}

	SortMailList();
}

void UMailManager::RemoveMailInfos(const TArray<FMailId>& InMailIds, int32 InReceiveUtc)
{
	MailReceiveInfos.Empty();
	for (const FMailId& MailId : InMailIds)
	{
		const FMailInfo* MailInfo = MailInfos.Find(MailId);
		if (MailInfo != nullptr)
		{
			AddMailReceiveInfo(MailInfo);
			AddMailReceiveLog(MailInfo, InReceiveUtc);

			MailInfos.Remove(MailId);
		}
	}

	SortMailList();
}

void UMailManager::UpdateMailList(const TArray<FMailInfo>& InMailInfos, const bool& IsRefresh)
{
	if (!IsRefresh)
	{
		MailInfos.Empty();
	}

	for (const FMailInfo& Info : InMailInfos)
	{
		MailInfos.Add(Info.MailId, Info);
	}

	SortMailList();
}

void UMailManager::UpdateMailReceiveLogList(const TArray<FMailReceiveLog> InMailReceiveLogs)
{
	MailReceiveLogs.Empty();
	for (const FMailReceiveLog& MailReceiveLog : InMailReceiveLogs)
	{
		AddMailReceiveLog(MailReceiveLog);
	}
}

void UMailManager::RefreshMailList()
{
	if (MailInfos.Num() > SystemConst::Q6_MAX_MAIL_SHOW_COUNT)
	{
		TArray<FMailId> MailIds;
		MailInfos.GetKeys(MailIds);
		int OverCount = MailIds.Num() - SystemConst::Q6_MAX_MAIL_SHOW_COUNT;
		int LastIndex = MailIds.Num() - 1;
		for (int i = 0; i < OverCount; ++i)
		{
			MailInfos.Remove(MailIds[LastIndex - i]);
		}

		SortMailList();
	}
}