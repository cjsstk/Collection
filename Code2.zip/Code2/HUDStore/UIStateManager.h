#pragma once

#include "GameResource.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6LobbyState.h"

#include "UIStateManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UUIStateManager

UCLASS()
class Q6_API UUIStateManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UUIStateManager();
	~UUIStateManager();

	// ui state getters

	const FInventoryUIState& GetInventoryUIState() const;
	const FJokerSelectUIState& GetJokerSelectUIState() const;
	const FFriendUIState& GetFriendUIState() const;
	const FPartyUIState& GetPartyUIState() const;
	const FUpgradeUIState& GetUpgradeUIState() const;
	const FDialogueUIState& GetDialogueUIState() const;
	const FSagaUIState& GetSagaUIState() const;
	const FSpecialUIState& GetSpecialStageUIState() const;
	const FDailyDungeonUIState& GetDailyDungeonUIState() const;
	const FTrainingCenterUIState& GetTrainingCenterUIState() const;
	const FSummonUIState& GetSummonUIState() const;
	const FWonderUIState& GetWonderUIState() const;
	const FRaidUIState& GetRaidUIState() const;
	const FBondUpResultUIState& GetBondUpResultUIState() const;
	const FCodexUIState& GetCodexUIState() const;
	const FWeeklyMissionUIState& GetWeeklyMissionUIState() const;
	const FShopUIState& GetShopUIState() const;
	const FLobbySettingUIState& GetLobbySettingUIState() const;
	const FBagUIState& GetBagUIState() const;
	const FEventUIState& GetEventUIState() const;
	const FAccountUIState& GetAccountUIState() const;
	const FStoryUIState& GetStoryUIState() const;

	EHUDWidgetType GetRootHUDWidgetType() const;

	const FLobbyUIState* GetUIState() const { return CurrentUIState; }
	const FSortingOption& GetSortingOption(ESortMenu SortMenu, ESortCategory Category) const;

	bool IsChangedSortingOption(const FSortingOption& OldSortingOption) const;

protected:
	void RegisterActionHandlers() override;

private:
	template <typename T>
	void ChangeMenu(const T& UIState, bool bAddHistory, bool bResetHistory = false);

	void ClearHistory();
	void GotoBack();
	void SetWonderUpgrade(EWonderCategory Category, int32 Level);

	void DumpHistory(const FString& Caller);

	// back from menu
	bool GotoBackMenu();

	// Sorting

	bool LoadSortingFile();
	void SaveSortingFile();

	FString GetSortingFilePath();

	// Point
	DECLARE_ACTION_HANDLER(DevAddCurrencyResp);

	// Menu
	DECLARE_ACTION_HANDLER(MenuBack);
	DECLARE_ACTION_HANDLER(MenuDoubleBack);
	DECLARE_ACTION_HANDLER(MenuChange);

	// Upgrade
	DECLARE_ACTION_HANDLER(UpgradeMenu);
	DECLARE_ACTION_HANDLER(UpgradeInventory);
	DECLARE_ACTION_HANDLER(UpgradeCategory);
	DECLARE_ACTION_HANDLER(UpgradeItem);

	// Friend
	DECLARE_ACTION_HANDLER(FriendCategoryChange);
	DECLARE_ACTION_HANDLER(FriendJokerSetView);
	DECLARE_ACTION_HANDLER(FriendBookFilterChange);

	// Party
	DECLARE_ACTION_HANDLER(PartyPetEdit);
	DECLARE_ACTION_HANDLER(PartyEdit);
	DECLARE_ACTION_HANDLER(PartyChange);
	DECLARE_ACTION_HANDLER(PartyMain);
	DECLARE_ACTION_HANDLER(PartySaveResp);
	DECLARE_ACTION_HANDLER(PartyEventContentType);

	// JokerSet
	DECLARE_ACTION_HANDLER(JokerSetEdit);
	DECLARE_ACTION_HANDLER(JokerSetChange);
	DECLARE_ACTION_HANDLER(JokerSetMain);
	DECLARE_ACTION_HANDLER(JokerSetSaveResp);

	// JokerSelect
	DECLARE_ACTION_HANDLER(JokerSelect);
	DECLARE_ACTION_HANDLER(JokerSetView);
	DECLARE_ACTION_HANDLER(FriendJokerFromPopup);

	// Saga
	DECLARE_ACTION_HANDLER(SagaStageList);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);

	// Special
	DECLARE_ACTION_HANDLER(SpecialOpen);
	DECLARE_ACTION_HANDLER(SpecialEpisodeList);
	DECLARE_ACTION_HANDLER(SpecialCharacterStageList);
	DECLARE_ACTION_HANDLER(SpecialSagaStageList);
	DECLARE_ACTION_HANDLER(SpecialWonderStageList);

	// DailyDungeon
	DECLARE_ACTION_HANDLER(DailyDungeonStageList);
	DECLARE_ACTION_HANDLER(DailyDungeonPageChange);

	// TrainingCenter
	DECLARE_ACTION_HANDLER(TrainingCenterOpen);

	// Summon
	DECLARE_ACTION_HANDLER(SummonBoxScheduleResp);
	DECLARE_ACTION_HANDLER(SummonPageChange);
	DECLARE_ACTION_HANDLER(SummonFriendShip);

	// InitialRewardEvent
	DECLARE_ACTION_HANDLER(InitialRewardEventOpen);

	// Wonder
	DECLARE_ACTION_HANDLER(WonderMenu);
	DECLARE_ACTION_HANDLER(WonderSlotSelect);
	DECLARE_ACTION_HANDLER(PyramidUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(PowerPlantUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(PetParkUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(TempleUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(AlchemylabUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(SmelterUpgradeCompleteResp);

	// Raid
	DECLARE_ACTION_HANDLER(RaidOpen);

	// Inventory
	DECLARE_ACTION_HANDLER(InventoryOpen);
	DECLARE_ACTION_HANDLER(InventoryChange);
	DECLARE_ACTION_HANDLER(InventoryEdit);
	DECLARE_ACTION_HANDLER(CharacterSetStashResp);
	DECLARE_ACTION_HANDLER(RelicSetStashResp);
	DECLARE_ACTION_HANDLER(SculptureSetStashResp);

	// Mail
	DECLARE_ACTION_HANDLER(MailSelect);

	// Codex
	DECLARE_ACTION_HANDLER(CodexCategoryChange);
	DECLARE_ACTION_HANDLER(CodexEquipFullView);

	// Sorting
	DECLARE_ACTION_HANDLER(SortingInit);
	DECLARE_ACTION_HANDLER(SortingChange);

	// Shop
	DECLARE_ACTION_HANDLER(ShopMenuChange);
	DECLARE_ACTION_HANDLER(ShopBuyItemResp);

	// LobbySetting
	DECLARE_ACTION_HANDLER(LobbySettingEditChange);

	// Event
	DECLARE_ACTION_HANDLER(EnterEventMenu);	// Why do I exist?
	DECLARE_ACTION_HANDLER(EventMenuChange);

	// Multiside
	DECLARE_ACTION_HANDLER(MultisidePetSave);
	DECLARE_ACTION_HANDLER(MultisidePartySave);

	// Story
	DECLARE_ACTION_HANDLER(StoryList);

	// Dev
	DECLARE_ACTION_HANDLER(DevPyramidPortalBoostUseResp);
	DECLARE_ACTION_HANDLER(DevPyramidUpgradeResp);
	DECLARE_ACTION_HANDLER(DevPetParkUpgradeResp);
	DECLARE_ACTION_HANDLER(DevTempleUpgradeResp);

	FLobbyUIState* CurrentUIState;
	TArray<FLobbyUIState*> Histories;

	TArray<FSortingOption> SortingSelectedOptions;
	bool bSortingChanged;
};

template <typename T>
void UUIStateManager::ChangeMenu(const T& UIState, bool bAddHistory, bool bResetHistory)
{
	if (bSortingChanged)
	{
		SaveSortingFile();
	}

	bSortingChanged = false;

	if (bResetHistory)
	{
		ClearHistory();
	}

	if (!bAddHistory)
	{
		if (CurrentUIState && CurrentUIState->GetHUDWidgetType() == UIState.GetHUDWidgetType())
		{
			// change state values

			T& NewUIState = *((T*)CurrentUIState);
			NewUIState = UIState;
			DumpHistory(TEXT("ChangeMenu - Same"));
			return;
		}

		// Change new state
		if (CurrentUIState)
		{
			delete CurrentUIState;
		}

		CurrentUIState = new T(UIState);
		DumpHistory(TEXT("ChangeMenu - Change"));
		return;
	}

	if (CurrentUIState)
	{
		Histories.Add(CurrentUIState);
	}
	CurrentUIState = new T(UIState);
	DumpHistory(TEXT("ChangeMenu - Add"));
}
