#pragma once

#include "Q6Minimal.h"
#include "HSActionType.h"

///////////////////////////////////////////////////////////////////////////////////////////
// FHSAction

struct FHSAction
{
	explicit FHSAction(EHSActionType InActionType, bool bInByValue = true)
		: ActionType(InActionType), bByValue(bInByValue)
	{
	}
	virtual ~FHSAction() {}

	EHSActionType GetActionType() const { return ActionType; }
	bool IsByValue() const { return bByValue; }

private:
	EHSActionType ActionType;
	bool bByValue;
};

struct FHSNoParamAction : public FHSAction
{
	explicit FHSNoParamAction(EHSActionType InActionType)
		: FHSAction(InActionType)
	{
	}
};

template<class T>
struct FHSOneParamAction : public FHSAction
{
	explicit FHSOneParamAction(EHSActionType InActionType, const T& InVal)
		: FHSAction(InActionType), Val(InVal)
	{
	}

	const T& GetVal() const { return Val; }

private:
	const T Val;
};

template<class T, class U>
struct FHSTwoParamAction : public FHSOneParamAction<T>
{
	explicit FHSTwoParamAction(EHSActionType InActionType, const T& InVal, const U& InVal2)
		: FHSOneParamAction<T>(InActionType, InVal), Val2(InVal2)
	{
	}

	const U& GetVal2() const { return Val2; }

private:
	const U Val2;
};

template<class T>
struct FHSRefParamAction : public FHSAction
{
	explicit FHSRefParamAction(EHSActionType InActionType, const T& InVal)
		: FHSAction(InActionType, false), Val(InVal)
	{
	}

	const T& GetVal() const { return Val; }

private:
	const T& Val;
};

template<class T, class U>
struct FHSTwoRefParamAction : public FHSRefParamAction<T>
{
	explicit FHSTwoRefParamAction(EHSActionType InActionType, const T& InVal, const U& InVal2)
		: FHSRefParamAction<T>(InActionType, InVal), Val2(InVal2)
	{
	}

	const U& GetVal2() const { return Val2; }

private:
	const U& Val2;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Action

class Action
{
public:
	static void Dispatch(TSharedPtr<FHSAction> Action);
};

// Action Dispatch
#define ACTION_DISPATCH(HSAction) \
	Action::Dispatch(MakeShared<FHSNoParamAction>(EHSActionType::HSAction))
#define ACTION_DISPATCH_ONE(HSAction, Type, Val) \
	Action::Dispatch(MakeShared<FHSOneParamAction<Type>>(EHSActionType::HSAction, Val))
#define ACTION_DISPATCH_TWO(HSAction, Type, Val, Type2, Val2) \
	Action::Dispatch(MakeShared<FHSTwoParamAction<Type, Type2>>(EHSActionType::HSAction, Val, Val2))
#define ACTION_DISPATCH_REF(HSAction, Type, Val) \
	Action::Dispatch(MakeShared<FHSRefParamAction<Type>>(EHSActionType::HSAction, Val))
#define ACTION_DISPATCH_TWO_REF(HSAction, Type, Val, Type2, Val2) \
	Action::Dispatch(MakeShared<FHSTwoRefParamAction<Type, Type2>>(EHSActionType::HSAction, Val, Val2))

// Action Parse
#define ACTION_PARSE(InAction) \
	StaticCastSharedPtr<FHSNoParamAction>(InAction)
#define ACTION_PARSE_ONE(Type, InAction) \
	StaticCastSharedPtr<FHSOneParamAction<Type>>(InAction)
#define ACTION_PARSE_TWO(Type1, Type2, InAction) \
	StaticCastSharedPtr<FHSTwoParamAction<Type1, Type2>>(InAction)
#define ACTION_PARSE_REF(Type, InAction) \
	StaticCastSharedPtr<FHSRefParamAction<Type>>(InAction)
#define ACTION_PARSE_TWO_REF(Type1, Type2, InAction) \
	StaticCastSharedPtr<FHSTwoRefParamAction<Type1, Type2>>(InAction)

// Action Handler
#define DECLARE_ACTION_HANDLER(HSAction) \
	bool OnAction##HSAction(TSharedPtr<FHSAction> InAction)
#define IMPLEMENT_ACTION_HANDLER(ClassName, HSAction) \
	bool ClassName::OnAction##HSAction(TSharedPtr<FHSAction> InAction)
#define REGISTER_ACTION_HANDLER(ClassName, HSAction) \
	RegisterActionHandler(EHSActionType::HSAction, FOnHSAction::CreateUObject(this, &ClassName::OnAction##HSAction))

#include "HSActionDispatch.h"
#include "HSActionParse.h"

