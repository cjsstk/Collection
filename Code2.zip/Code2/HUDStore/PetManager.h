#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"

#include "PetManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UPetManager

UCLASS()
class Q6_API UPetManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UPetManager();

	void ReqLoad() const;
	void ReqPetParkUpgrade() const;
	void ReqPetParkUpgradeComplete() const;
	void ReqPetSkillUpgrade(FPetId PetId, int32 Index) const;
	void ReqHarvest() const;

#if !UE_BUILD_SHIPPING
	void ReqDevPetParkUpgrade(int32 TargetLevel) const;
#endif

	const FPetInfo* Find(FPetId PetId) const { return Pets.Find(PetId); }
	const FPetInfo* GetPetInfoByIndex(int32 Index) const;
	int32 GetIndexByPetId(const FPetId& InPetId) const;
	const FPetInfo* GetPet(FPetType PetType) const;
	const TMap<FPetId, FPetInfo>& GetPets() const { return Pets; }

	bool IsOpen() const { return (PetPark.Level > 0); }
	const FPetPark& GetPetPark() const { return PetPark; }
	int32 GetPetNum() const { return Pets.Num(); }
	bool HasPet(const FPetId& PetId) const;

	void Dump() const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	void UpdatePet(const FPetInfo& Info);

	void OnLoadResp(const FResError* Error, const FL2CPetLoadResp& Msg);
	void OnPetParkUpgradeResp(const FResError* Error, const FL2CPetParkUpgradeResp& Msg);
	void OnPetParkUpgradeCompleteResp(const FResError* Error, const FL2CPetParkUpgradeCompleteResp& Msg);
	void OnPetSkillUpgradeResp(const FResError* Error, const FL2CPetSkillUpgradeResp& Msg);
	void OnPetParkHarvestResp(const FResError* Error, const FL2CPetHarvestResp& Msg);

	DECLARE_ACTION_HANDLER(PetLoadResp);
	DECLARE_ACTION_HANDLER(PetParkUpgradeResp);
	DECLARE_ACTION_HANDLER(PetParkUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(PetParkHarvestResp);
	DECLARE_ACTION_HANDLER(PetSkillUpgradeResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DevPetParkOpenResp);
	DECLARE_ACTION_HANDLER(DevPetParkUpgradeResp);
	DECLARE_ACTION_HANDLER(DevPetParkProduceResp);
	DECLARE_ACTION_HANDLER(DevPetSkillUpgradeResp);
	DECLARE_ACTION_HANDLER(DevPetNewResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);

private:
	FPetPark PetPark;
	TMap<FPetId, FPetInfo> Pets;
};
