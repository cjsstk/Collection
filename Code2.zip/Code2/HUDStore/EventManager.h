#pragma once

#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "Q6ClientNetwork.h"
#include "EventManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FCombatMissionInfo;
struct FEventContentCategoryInfo;
struct FEventScheduleInfo;
struct FEventContentCollabo01Type;
struct FEventContentValentineDayType;
struct FEventContentType;
struct FSagaType;
struct EventContentRoulettePlayConditionInfo;
struct FEventContentRouletteLineUpInfo;
struct FEventContentRouletteInfo;

class UCCEndGameEvent;

///////////////////////////////////////////////////////////////////////////////////////////
// FEventContentRoulette

struct FEventContentRoulette
{
public:
	FEventContentRoulette(const FEventContentRoulettePlayConditionInfo& InEventContentRoulettePlayConditionInfo);

	const bool IsSoldOut() const;
	const int32& GetLineUp() const { return EventContentRouletteLineUpInfo.LineUp; }
	const TMap<FEventContentRouletteType, FEventContentRouletteInfo>* GetEventContentRouletteInfos(int32 InLineUp) const { return EventContentRouletteInfosMap.Find(InLineUp); }

	void UpdateLineUp(const FEventContentRouletteLineUpInfo& InEventContentRouletteLineUpInfo);
	void UpdatePlay(const TArray<FEventContentRouletteInfo>& InEventContentRouletteInfos, bool bInitialize);

private:

	FEventContentRouletteLineUpInfo EventContentRouletteLineUpInfo;
	TMap<int32 /*line-up*/, TMap<FEventContentRouletteType, FEventContentRouletteInfo>> EventContentRouletteInfosMap;
};

///////////////////////////////////////////////////////////////////////////////////////////
// UEventManager
UCLASS()
class Q6_API UEventManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UEventManager();
	~UEventManager();

	void Dump() const;

	const TMap<int32, FEventScheduleInfo>& GetEventSchedules() const { return EventSchedules; }
	const FEventScheduleInfo* GetEventSchedule(int32 EventId) const;
	const bool& IsEventScheduleChanged() const { return bScheduleChanged; }
	const FEventContentInfo* GetEvent(FEventContentType InContentType) const { return NewEventContentInfos.Find(InContentType); }
	const TMap<FEventContentType, FEventContentInfo>& GetEvents() const { return NewEventContentInfos; }
	const TArray<FEventContentRouletteInfo>& GetEventContentRoulettePlayResults() const { return EventContentRoulettePlayResultInfos; }
	const FEventContentRoulette* GetEventContentRoulette(const FEventContentType& EventContentType) const { return EventContentRouletteInfos.Find(EventContentType); }
	const TArray<FEventContentCategoryInfo>& GetPlayedStages(FEventContentType InContentType) const;
	const int32 GetEventContentNumberOfDays(const FEventContentType& EventContentType) const;
	int32 GetNumOfEvents() const { return NewEventContentInfos.Num(); }
	TArray<int32> GetEventPoint(FEventContentType InEventContentType) const;

	bool IsExpired(FEventContentType Type) const;

public:

	void ReqEventContentList() const;
	void ReqEventContentRefreshNumberOfDays(const FEventContentType& EventContentType) const;
	void ReqEventContentRoulettePlay(const FEventContentType& EventContentType, const int32& PlayCount) const;
	void ReqEventContentRouletteReset(const FEventContentType& EventContentType) const;

	void ReqEventContentCollabo01StageBegin() const;
	void ReqEventContentCollabo01StageEnd(const UCCEndGameEvent* Event
		, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const;
	void ReqEventContentCollabo01StoryStageClear(const FEventContentCollabo01Type& EventContentCollabo01Type
		, const FSagaType& SagaType) const;

	void ReqEventContentValentineDayStageBegin() const;
	void ReqEventContentValentineDayStageEnd(const UCCEndGameEvent* Event
		, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const;
	void ReqEventContentValentineDayStoryStageClear(const FEventContentValentineDayType& EventContentValentineDayType
		, const FSagaType& SagaType) const;

	// MultiSideBattle
	void ReqEventContentMultiSideBattleStageBegin() const;
	void ReqEventContentMultiSideBattleStageEnd(const UCCEndGameEvent* Event
		, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo, int32 TotalRankScore) const;
	void ReqEventContentMultiSideBattleStoryStageClear(const FEventContentMultiSideBattleStageType& StageType) const;
	void ReqEventContentMultisideBattleRankLoad(FEventContentType EventContentType) const;
	void ReqEventContentMultiSideBattleReceiveRankReward(FEventContentType InEventContentType) const;

#if !UE_BUILD_SHIPPING
	void ReqDevEventContentValentineDayStageBegin() const;
#endif

private:
	void OnEventContentListResp(const FResError* Error, const FL2CEventContentListResp& Res);
	void OnEventContentRefreshNumberOfDaysResp(const FResError* Error, const FL2CEventContentRefreshNumberOfDaysResp& Res);
	void OnEventContentRoulettePlayResp(const FResError* Error, const FL2CEventContentRoulettePlayResp& Res);
	void OnEventContentRouletteResetResp(const FResError* Error, const FL2CEventContentRouletteResetResp& Res);

	void OnEventContentCollabo01StageBeginResp(const FResError* Error, const FL2CEventContentCollabo01StageBeginResp& Res);
	void OnEventContentCollabo01StageEndResp(const FResError* Error, const FL2CEventContentCollabo01StageEndResp& Res);
	void OnEventContentCollabo01StoryStageClearResp(const FResError* Error, const FL2CEventContentCollabo01StoryStageClearResp& Res);

	void OnEventContentValentineDayStageBeginResp(const FResError* Error, const FL2CEventContentValentineDayStageBeginResp& Res);
	void OnEventContentValentineDayStageEndResp(const FResError* Error, const FL2CEventContentValentineDayStageEndResp& Res);
	void OnEventContentValentineDayStoryStageClearResp(const FResError* Error, const FL2CEventContentValentineDayStoryStageClearResp& Res);

	// MultiSideBattle
	void OnEventContentMultiSideBattleStageBeginResp(const FResError* Error, const FL2CEventContentMultiSideBattleStageBeginResp& Res);
	void OnEventContentMultiSideBattleStageEndResp(const FResError* Error, const FL2CEventContentMultiSideBattleStageEndResp& Res);
	void OnEventContentMultiSideBattleStoryStageClearResp(const FResError* Error, const FL2CEventContentMultiSideBattleStoryStageClearResp& Res);
	void OnEventContentMultiSideBattleRankLoadResp(const FResError* Error, const FL2CEventContentMultiSideBattleLoadResp& Res);
	void OnEventContentMultiSideBattleReceiveRankRewardResp(const FResError* Error, const FL2CEventContentMultiSideBattleReceiveRankRewardResp& Res);

private:
	void UpdateEventContentNumberOfDays(const FEventContentType& InEventContentType, const int32& InEventContentNumberOfDays);
	void UpdateEventContentRoulettePlay(const TArray<FEventContentRoulettePlayConditionInfo>& InEventContentRoulettePlayConditionInfo);
	void UpdateEventContentRoulettePlay(const FEventContentType& InEventContentType, const TArray<FEventContentRouletteInfo>& InEventContentRouletteInfos);
	void UpdateEventContentRouletteReset(const FEventContentRouletteLineUpInfo& InEventContentRouletteLineUpInfo);
	void UpdateEventContentInfo(const FEventContentInfo& InEventContentInfo);
	void UpdateMultisideBattleInfo(const FEventContentMultiSideBattleInfo& InMultisideBattleInfo);

	bool HasPlayableMultiside() const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// OnActions
	DECLARE_ACTION_HANDLER(CheckInRewardReceiveResp);
	DECLARE_ACTION_HANDLER(SummonBoxScheduleResp);
	DECLARE_ACTION_HANDLER(ShopSaleScheduleResp);
	DECLARE_ACTION_HANDLER(ContentsResetTime);
	DECLARE_ACTION_HANDLER(ShopListResp);
	DECLARE_ACTION_HANDLER(EventContentListResp);
	DECLARE_ACTION_HANDLER(EventContentRefreshNumberOfDaysResp);
	DECLARE_ACTION_HANDLER(EventContentRoulettePlayResp);
	DECLARE_ACTION_HANDLER(EventContentRouletteResetResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DevEventContentNumberOfDaysResp);
	DECLARE_ACTION_HANDLER(DevEventContentAddPointResp);
	DECLARE_ACTION_HANDLER(DevEventContentRechargeWattResp);
	DECLARE_ACTION_HANDLER(DevEventContentRouletteResetResp);
	DECLARE_ACTION_HANDLER(ShopBuyItemResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleRankLoadResp);

	void InitEventSchedules(const TArray<FEventScheduleInfo>& EventScheduleArray);

	TMap<int32 /* EventId */, FEventScheduleInfo> EventSchedules;
	bool bScheduleChanged;

	TArray<FEventContentRouletteInfo> EventContentRoulettePlayResultInfos;

	TMap<FEventContentType, FEventContentInfo> NewEventContentInfos;
	TMap<FEventContentType, int32> EventContentNumberOfDays;
	TMap<FEventContentType, FEventContentRoulette> EventContentRouletteInfos;
};