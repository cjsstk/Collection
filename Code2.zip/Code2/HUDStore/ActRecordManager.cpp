#include "ActRecordManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Static Functions

void DefaultActRecordInfo(FActRecordInfo * Info)
{
	Info->ActRecordId = FActRecordId::InvalidValue();
	Info->UserId = FUserId::InvalidValue();
	Info->Type = ActRecordTypeInvalid;
	Info->Val = 0;
	Info->Created = 0;
}

void DumpActRecord(const FActRecordInfo& Info)
{
	Q6JsonLogHekel(Verbose, "",
		Q6KV("Id", Info.ActRecordId),
		Q6KV("User", Info.UserId),
		Q6KV("Type", Info.Type),
		Q6KV("Val", Info.Val),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));
}

///////////////////////////////////////////////////////////////////////////////////////////
// FActRecord

FActRecord::FActRecord(const FActRecordInfo & InInfo)
{
	Info = InInfo;
}

void FActRecord::Update(const FActRecordInfo& InInfo)
{
	Info = InInfo;
}

///////////////////////////////////////////////////////////////////////////////////////////
// UActRecordManager

UActRecordManager::UActRecordManager()
{
	InitStore(EHSType::ActRecord);
}

void UActRecordManager::Dump() const
{
	Q6JsonLogHekel(Verbose, "== Act Records ==",
		Q6KV("Total", ActRecords.Num()));
	for (const auto& Item : ActRecords)
	{
		DumpActRecord(Item.GetInfo());
	}
}

bool UActRecordManager::IsToday(int64 ClearTimeStamp) const
{
	const FDateTime& CurrentTime = FDateTime::Now();
	const FDateTime& ClearedTime = CurrentTime.FromUnixTimestamp(ClearTimeStamp);

	if (ClearedTime.GetYear() != CurrentTime.GetYear())
	{
		return false;
	}
	if (ClearedTime.GetMonth() != CurrentTime.GetMonth())
	{
		return false;
	}
	if (ClearedTime.GetDay() != CurrentTime.GetDay())
	{
		return false;
	}

	return true;
}

void UActRecordManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearActRecord();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LActRecordList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("actRecord/list"), Out,
		TQ6ResponseDelegate<FL2CActRecordListResp>::CreateUObject(
			const_cast<UActRecordManager*>(this), &UActRecordManager::OnListResp));
}

void UActRecordManager::OnListResp(const FResError* Error, const FL2CActRecordListResp& Msg)
{
	Q6JsonLogHekel(Warning, "list resp");

	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ACTION_DISPATCH_ActRecordListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		// TODO: refresh UI, list finished
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void UActRecordManager::OnLoadResp(const FResError* Error, const FL2CActRecordLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_ActRecordLoadResp(Msg);
}

const FActRecord* const UActRecordManager::Find(FActRecordType Type, int32 Val) const
{
	for (const FActRecord& Item : ActRecords)
	{
		const FActRecordInfo& Info = Item.GetInfo();
		if (Info.Type == Type && Info.Val == Val) \
		{
			return &Item;
		}
	}

	return nullptr;
}

void UActRecordManager::FindRecords(FActRecordType Type, TArray<FActRecord>* Records) const
{
	for (const FActRecord& Item : ActRecords)
	{
		const FActRecordInfo& Info = Item.GetInfo();
		if (Info.Type == Type)
		{
			Records->Add(Item);
		}
	}
}

void UActRecordManager::FindDailyDungeonRecords(EDayOfWeekType InDungeonToday, TArray<FActRecord>* Records) const
{
	const UCMS* CMS = GetCMS();
	const TArray<const FCMSDailyDungeonRow*> DailyDungeons = CMS->GetDailyDungeonValidRows(InDungeonToday);

	for (const FActRecord& Item : ActRecords)
	{
		const FActRecordInfo& Info = Item.GetInfo();

		for (const FCMSDailyDungeonRow* Row : DailyDungeons)
		{
			const auto& DungeonSaga = Row->GetSaga();

			if (DungeonSaga.IsInvalid())
			{
				Q6JsonLogGunny(Warning, "UActRecordManager::FindDailyDungeonRecords - DungeonSaga index was wrong ");
				continue;
			}

			if ((FSagaType(Info.Val) == DungeonSaga.CmsType()) && IsToday(Info.Created))
			{
				Records->Add(Item);
			}
		}
	}
}

/////////////////////////////////////////////////////////////////////////////
// UActRecordManager Setter

bool UActRecordManager::AddActRecord(const FActRecordInfo& Info)
{
	if (Find(Info.Type, Info.Val))
	{
		return true;
	}

	ActRecords.Add(Info);
	return true;
}

bool UActRecordManager::RemoveRecord(FActRecordId Id)
{
	int32 Index = 0;
	for (const FActRecord& Item : ActRecords)
	{
		const FActRecordInfo& Info = Item.GetInfo();
		if (Info.ActRecordId == Id)
		{
			if (ActRecords.IsValidIndex(Index))
			{
				ActRecords.RemoveAt(Index);
			}
			break;
		}

		++Index;
	}
	return true;
}

bool UActRecordManager::UpdateActRecord(const FActRecordInfo& InInfo)
{
	if (InInfo.ActRecordId.IsInvalid()) {
		return false;
	}

	for (FActRecord& Item : ActRecords)
	{
		const FActRecordInfo& Info = Item.GetInfo();
		if (Info.Type == InInfo.Type && Info.Val == InInfo.Val)
		{
			Item.Update(InInfo);
			return true;
		}
	}

	AddActRecord(InInfo);
	return true;
}

bool UActRecordManager::UpdateActRecords(const TArray<FActRecordInfo>& Records)
{
	for (const FActRecordInfo& Info : Records)
	{
		UpdateActRecord(Info);
	}
	return true;
}


/////////////////////////////////////////////////////////////////////////////
// UActRecordManager HUDStore Action

void UActRecordManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UActRecordManager, ClearActRecord);
	REGISTER_ACTION_HANDLER(UActRecordManager, ActRecordLoadResp);
	REGISTER_ACTION_HANDLER(UActRecordManager, ActRecordListResp);
	REGISTER_ACTION_HANDLER(UActRecordManager, ActRecordRemoveResp);
}

IMPLEMENT_ACTION_HANDLER(UActRecordManager, ClearActRecord)
{
	ActRecords.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UActRecordManager, ActRecordLoadResp)
{
	auto Action = ACTION_PARSE_ActRecordLoadResp(InAction);

	auto& Res = Action->GetVal();
	return UpdateActRecord(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(UActRecordManager, ActRecordListResp)
{
	auto Action = ACTION_PARSE_ActRecordListResp(InAction);
	auto& Res = Action->GetVal();

	return UpdateActRecords(Res.ActRecords);
}

IMPLEMENT_ACTION_HANDLER(UActRecordManager, ActRecordRemoveResp)
{
	auto Action = ACTION_PARSE_ActRecordRemoveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FActRecordId& Id : Res.Ids)
	{
		Ret |= RemoveRecord(Id);
	}
	return Ret;
}
