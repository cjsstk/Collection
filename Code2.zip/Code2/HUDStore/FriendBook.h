// Copyright (c) 2020 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6ClientNetwork.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "LobbyObj_gen.h"
#include "Friendbook.generated.h"

DECLARE_DELEGATE_RetVal_FourParams(FText, FFormatMessageDelegate, const FCMSFriendBookFeedRow&, const FFriendBookDetailedFeed&, FText*, FItemIconInfo*)

struct FAvatarInfo;

enum class EItemCategory : uint8;

UCLASS()
class Q6_API UFriendBook : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UFriendBook();

	virtual void InitWithGame(UQ6GameInstance* InGameInstance) override;

	void ReqTimeline(FFriendBookFeedId InLastFeedId) const;
	void ReqAddReaction(FFriendBookFeedId InFeedId, EFriendBookReactionType InReaction) const;
	void ReqRemoveReaction(FFriendBookFeedId InFeedId) const;
	void ReqFeed(FFriendBookFeedId InFeedId) const;

	FText GetUserName(const FUserId& InUserId) const;
	bool GetItemIconInfo(const FUserId& InUserId, EItemCategory InCategory, int32 CMSType, FItemIconInfo* OutItemInfo) const;
	TArray<const FFriendBookDetailedFeed*> GetFeeds(bool bMyFeedOnly) const;
	const FFriendBookDetailedFeed* GetFeed(FFriendBookFeedId InFeedId) const;
	bool HasNewFeeds() const;

	FText FormatMessage(const FFriendBookDetailedFeed& InFeedInfo, FText* OutLinkText, FItemIconInfo* OutItemInfo) const;

	const FFriendBookFeedId& GetTailFeedId() const { return LastTimelineTailFeedId; }
	const FAvatarInfo& GetAvatarInfo(const FUserId& InUserId) const;

protected:

	virtual void RegisterActionHandlers() override;

	void OnFriendBookPosted(const FL2CFriendBookNotiPosted& InNoti);
	void OnFriendBookReacted(const FL2CFriendBookNotiReacted& InNoti);
	void OnFriendBookReactionRemoved(const FL2CFriendBookNotiReactionRemoved& InNoti);
	void OnGetTimelineResp(const FResError* Error, const FL2CFriendBookGetTimelineResp& Msg);
	void OnAddReactionResp(const FResError* Error, const FL2CFriendBookAddReactionResp& Msg, FC2LFriendBookAddReaction InReactionInfo);
	void OnRemoveReactionResp(const FResError* Error, const FL2CFriendBookRemoveReactionResp& Msg, FC2LFriendBookRemoveReaction InReactionInfo);
	void OnGetFeedResp(const FResError* Error, const FL2CFriendBookGetFeedResp& Msg);

	DECLARE_ACTION_HANDLER(FriendBookReadTimeline);
	DECLARE_ACTION_HANDLER(FriendBookPosted);
	DECLARE_ACTION_HANDLER(FriendBookReacted);
	DECLARE_ACTION_HANDLER(FriendBookReactionRemoved);
	DECLARE_ACTION_HANDLER(FriendBookGetTimeline);
	DECLARE_ACTION_HANDLER(FriendBookAddReaction);
	DECLARE_ACTION_HANDLER(FriendBookRemoveReaction);
	DECLARE_ACTION_HANDLER(FriendBookGetFeed);
	DECLARE_ACTION_HANDLER(FriendNotifyRemove);
	DECLARE_ACTION_HANDLER(FriendRemoveResp);
	DECLARE_ACTION_HANDLER(FriendBookNewFeedsFromFile);

private:

	void SetFormatFunctions();
	bool RemoveFeedByFriendUserId(const FUserId& UserId);

	TArray<FFormatMessageDelegate> FormatFeedDelegates;

	UPROPERTY()
	TMap<FFriendBookFeedId, FFriendBookDetailedFeed> FeedsMap;

	UPROPERTY()
	FFriendBookFeedId NewestFeedId;

	UPROPERTY()
	FFriendBookFeedId LastTimelineTailFeedId;

	UPROPERTY()
	TSet<FFriendBookFeedId> NewFeedNoties;
};
