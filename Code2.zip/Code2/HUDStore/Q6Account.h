#pragma once
#include "Q6Minimal.h"
#include "HUDStoreInterface.h"
#include "LobbyObj_gen.h"
#include "CMSTable.h"
#include "HSAction.h"

#include "Q6Account.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

class UQ6GameInstance;

struct FL2CFriendshipCollectResp;
struct FL2CWattRechargeResp;
struct FL2CCurrencyLoadResp;
struct FL2CUserRenameResp;
struct FL2CUserSetTutorialResp;

struct FResError;

enum class EPointType : uint8;
enum class ELobbyTutorial : uint8;

///////////////////////////////////////////////////////////////////////////////////////////
// FAccountInfo

struct FUserInfoEx
{
	// Original
	FString AccountName;
	FUserId UserId;
	FString UserCode;
	FString Nickname;
	FUserLevelType Level;
	int32 Xp;
	int32 FreeGem;
	int32 PaidGem;
	int32 SummonTicket;
	int32 SculpturePoint;
	int32 RelicPoint;
	int32 FriendshipPoint;
	int32 SmallBattery;
	int32 MediumBattery;
	int32 LargeBattery;
	int64 Gold;
	int32 Watt;
	int32 Lumicube;
	int32 CharacterDisk;
	int32 SculptureDisk;
	int32 RelicDisk;
	FUserTitleType Title;
	int32 TitleScore;
	int32 TutorialCharacterSummon;
	int32 TutorialSculptureSummon;
	int32 TutorialRelicSummon;
	uint64 LobbyTutorialsDone;

	// Derived
	bool bLevelUp;
	int32 StartXp;
	int32 EndXp;
	int32 MaxWatt;
	int32 WattDiffTime;
	int32 MaxFriendCount;

	FUserInfoEx();
};

struct FFriendshipCollectInfo
{
	int32 GainedFriendshipPoint;
	FCharacterId MostPopularCharacterId;
};

const uint32 LOBBY_TUTORIALS_BITMASK = 0x3FFFFFFF;
const int32 LOBBY_TUTORIALS_UPPER_SHIFT_BITS = 30;

///////////////////////////////////////////////////////////////////////////////////////////
// UWorldUser

UCLASS(Blueprintable)
class Q6_API UWorldUser : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UWorldUser();
	virtual ~UWorldUser();

	void ReqWattRecharge(EBatteryType BatteryType, int32 Count) const;
	void ReqCurrencyLoad() const;
	void ReqRename(const FString& UserName) const;
	void ReqAddLobbyTutorialDone(ELobbyTutorial InDoneTutorial) const;

	const FString& GetAccountName() const { return UserInfoEx.AccountName; }
	const FUserId& GetId() const { return UserInfoEx.UserId; }
	const FString& GetUserCode() const { return UserInfoEx.UserCode; }
	const FString GetUserDisplayCode() const;
	const FString& GetNickname() const { return UserInfoEx.Nickname; }
	const FUserLevelType& GetLevel() const { return UserInfoEx.Level; }
	const FUserTitleType& GetTitleType() const { return UserInfoEx.Title; }
	int32 GetTitleScore() const { return UserInfoEx.TitleScore; }
	int32 GetXp() const { return UserInfoEx.Xp; }
	int32 GetStartXp() const { return UserInfoEx.StartXp; }
	int32 GetEndXp() const { return UserInfoEx.EndXp; }
	bool IsLobbyTutorialDone(ELobbyTutorial InDoneTutorial) const;

	float GetXpRatio() const
	{
		return (UserInfoEx.EndXp > UserInfoEx.StartXp) ?
			(UserInfoEx.Xp - UserInfoEx.StartXp) / static_cast<float>(UserInfoEx.EndXp - UserInfoEx.StartXp) : 1.0f;
	}
	bool IsLevelUp() const { return UserInfoEx.bLevelUp; }
	bool IsMaxWatt() const { return (UserInfoEx.Watt >= UserInfoEx.MaxWatt); }

	int32 GetOwnedCurrency(ECurrencyType InCurrencyType) const;
	int32 GetTotalGem() const { return UserInfoEx.FreeGem + UserInfoEx.PaidGem; }
	int32 GetFreeGem() const { return UserInfoEx.FreeGem; }
	int32 GetPaidGem() const { return UserInfoEx.PaidGem; }
	int32 GetSummonTicket() const { return UserInfoEx.SummonTicket; }
	int32 GetSculpturePoint() const { return UserInfoEx.SculpturePoint; }
	int32 GetRelicPoint() const { return UserInfoEx.RelicPoint; }
	int32 GetFriendshipPoint() const { return UserInfoEx.FriendshipPoint; }
	int64 GetGold() const { return UserInfoEx.Gold; }
	int32 GetLumicube() const { return UserInfoEx.Lumicube; }
	int32 GetCharacterDisk() const { return UserInfoEx.CharacterDisk; }
	int32 GetSculptureDisk() const { return UserInfoEx.SculptureDisk; }
	int32 GetRelicDisk() const { return UserInfoEx.RelicDisk; }
	int32 GetWatt() const { return UserInfoEx.Watt; }
	int32 GetMaxWatt() const { return UserInfoEx.MaxWatt; }
	int32 GetWattDiffTime() const { return UserInfoEx.WattDiffTime; }
	int32 GetMaxFriendCount() const { return UserInfoEx.MaxFriendCount; }
	int32 GetBattery(EBatteryType BatteryType) const;

	int32 GetPoint(ESummonPointType InPointType) const;
	int32 GetPoint(EPointType PointType) const;

	bool HasEnoughCurrency(ECurrencyType InCurrencyType, int32 InRequireCost) const;
	bool HasEnoughGold(int32 RequireCost) const;
	const FFriendshipCollectInfo& GetFriendshipCollectInfo() const { return FriendshipCollectInfo; }

	ECurrencyType HasMaxCurrency(ECurrencyCheckType CheckType) const;
	bool IsMaxCurrency(ECurrencyType CurrencyType) const;
	bool IsTutorialSummon(FBoxProductType InBoxProductType) const;

protected:
	// Register actions
	virtual void RegisterActionHandlers() override;

private:
	// Setter
	bool UpdateByUserInfo(const FUserInfo& Info);
	bool UpdateByWattInfo(const FWattDiffInfo& Info);
	bool UpdateByCurrencyInfo(const FCurrencyInfo& Info);
	bool UpdateByFreeGem(int32 InFreeGem);
	bool UpdateByPaidGem(int32 InPaidGem);
	bool UpdateBySummonTicket(int32 InSummonTicket);
	bool UpdateBySculpturePoint(int32 InSculpturePoint);
	bool UpdateByRelicPoint(int32 InRelicPoint);
	bool UpdateByFriendshipPoint(int32 InFriendshipPoint);
	bool UpdateBySmallBattery(int32 InSmallBattery);
	bool UpdateByMediumBattery(int32 InMediumBattery);
	bool UpdateByLargeBattery(int32 InLargeBattery);
	bool UpdateByGold(int64 InGold);
	bool UpdateByLumicube(int32 InLumicube);
	bool UpdateByCharacterDisk(int32 InCharacterDisk);
	bool UpdateBySculptureDisk(int32 InSculptureDisk);
	bool UpdateByRelicDisk(int32 InRelicDisk);
	bool UpdateByXp(int32 InXp);
	bool UpdateByLevel(FUserLevelType InLevel);
	bool UpdateByTutorialSummon(const FUserInfo& UserInfo);
	void UpdateByLobbyTutorials(const TArray<int32>& InUserInfoTutorials);

	void ReqFriendshipCollect() const;
	void OnFriendshipCollectResp(const FResError* Error, const FL2CFriendshipCollectResp& Msg);

	void OnWattRechargeResp(const FResError* Error, const FL2CWattRechargeResp& Msg);
	void OnCurrencyLoadResp(const FResError* Error, const FL2CCurrencyLoadResp& Msg);
	void OnUserRenameResp(const FResError* Error, const FL2CUserRenameResp& Msg);
	void OnUserSetTutorialResp(const FResError* Error, const FL2CUserSetTutorialResp& Msg, uint64 InLobbyTutorialsDone);

	// Action handlers
	DECLARE_ACTION_HANDLER(AccountName);
	DECLARE_ACTION_HANDLER(FriendshipCollect);
	DECLARE_ACTION_HANDLER(WattInfo);
	DECLARE_ACTION_HANDLER(GemConsume);
	DECLARE_ACTION_HANDLER(UpdateCurrency);
	DECLARE_ACTION_HANDLER(WattRechargeResp);
	DECLARE_ACTION_HANDLER(AuthEnterLobbyResp);
	DECLARE_ACTION_HANDLER(CurrencyLoadResp);
	DECLARE_ACTION_HANDLER(SagaStageBeginResp);
	DECLARE_ACTION_HANDLER(SagaStageEndResp);
	DECLARE_ACTION_HANDLER(SagaStoryStageClearResp);
	DECLARE_ACTION_HANDLER(SpecialStageBeginResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);
	DECLARE_ACTION_HANDLER(DailyStageBeginResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(RaidEnterNof);
	DECLARE_ACTION_HANDLER(RaidCanEnterNof);
	DECLARE_ACTION_HANDLER(RaidStageEndResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageBeginResp);
	DECLARE_ACTION_HANDLER(RaidFinalStageEndResp);
	DECLARE_ACTION_HANDLER(CharacterPromoteResp);
	DECLARE_ACTION_HANDLER(CharacterUnbindResp);
	DECLARE_ACTION_HANDLER(CharacterEvoluteResp);
	DECLARE_ACTION_HANDLER(CharacterTurnSkillLevelResp);
	DECLARE_ACTION_HANDLER(CharacterUltimateSkillLevelResp);
	DECLARE_ACTION_HANDLER(UserAddXpResp);
	DECLARE_ACTION_HANDLER(UserRenameResp);
	DECLARE_ACTION_HANDLER(UserSetTutorials);
	DECLARE_ACTION_HANDLER(CharacterAddXpResp);
	DECLARE_ACTION_HANDLER(RelicAddXpResp);
	DECLARE_ACTION_HANDLER(RelicPromoteResp);
	DECLARE_ACTION_HANDLER(RelicTierUpResp);
	DECLARE_ACTION_HANDLER(SculptureAddXpResp);
	DECLARE_ACTION_HANDLER(SculpturePromoteResp);
	DECLARE_ACTION_HANDLER(SculptureTierUpResp);
	DECLARE_ACTION_HANDLER(SummonPurchaseResp);
	DECLARE_ACTION_HANDLER(FriendshipCollectResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageBeginResp);
	DECLARE_ACTION_HANDLER(TrainingCenterStageEndResp);
	DECLARE_ACTION_HANDLER(PyramidUpgradeResp);
	DECLARE_ACTION_HANDLER(PyramidPortalBoostUseResp);
	DECLARE_ACTION_HANDLER(PowerPlantUpgradeResp);
	DECLARE_ACTION_HANDLER(PowerPlantStoreResp);
	DECLARE_ACTION_HANDLER(PowerPlantRechargeResp);
	DECLARE_ACTION_HANDLER(VacationUpgradeResp);
	DECLARE_ACTION_HANDLER(VacationStartResp);
	DECLARE_ACTION_HANDLER(VacationEndResp);
	DECLARE_ACTION_HANDLER(PetSkillUpgradeResp);
	DECLARE_ACTION_HANDLER(PetParkUpgradeResp);
	DECLARE_ACTION_HANDLER(PetParkHarvestResp);
	DECLARE_ACTION_HANDLER(PetParkUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(TempleUpgradeResp);
	DECLARE_ACTION_HANDLER(TempleArtifactUpgradeResp);
	DECLARE_ACTION_HANDLER(TempleArtifactBoostResp);
	DECLARE_ACTION_HANDLER(TempleHarvestResp);
	DECLARE_ACTION_HANDLER(TempleUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(DevStageClearResp);
	DECLARE_ACTION_HANDLER(DevWattRechargeResp);
	DECLARE_ACTION_HANDLER(DevWattConsumeResp);
	DECLARE_ACTION_HANDLER(DevAddXpResp);
	DECLARE_ACTION_HANDLER(DevAddCurrencyResp);
	DECLARE_ACTION_HANDLER(DevBondAddResp);
	DECLARE_ACTION_HANDLER(DevTrainingCenterClearResp);
	DECLARE_ACTION_HANDLER(MailReceiveResp);
	DECLARE_ACTION_HANDLER(ShopBuyItemResp);
	DECLARE_ACTION_HANDLER(ShopSellItemResp);
	DECLARE_ACTION_HANDLER(WeeklyMissionShuffleResp);
	DECLARE_ACTION_HANDLER(TitleChangeResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageBeginResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StageEndResp);
	DECLARE_ACTION_HANDLER(EventContentCollabo01StoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageBeginResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentValentineDayStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageBeginResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStageEndResp);
	DECLARE_ACTION_HANDLER(EventContentMultiSideBattleStoryStageClearResp);
	DECLARE_ACTION_HANDLER(EventContentMultisideBattleReceiveRankRewardResp);
	DECLARE_ACTION_HANDLER(SmelterUpgradeResp);
	DECLARE_ACTION_HANDLER(AlchemylabIncStockResp);
	DECLARE_ACTION_HANDLER(AlchemylabDecStockResp);
	DECLARE_ACTION_HANDLER(AlchemylabReceiveResp);
	DECLARE_ACTION_HANDLER(AlchemylabUpgradeResp);

	// Control data
	bool bFriendshipCollect;
	// Base info
	FUserInfoEx UserInfoEx;
	FFriendshipCollectInfo FriendshipCollectInfo;
	TArray<FCurrencyCheckInfo> CurrencyCheckList;	// index by ECurrencyCheckType
};
