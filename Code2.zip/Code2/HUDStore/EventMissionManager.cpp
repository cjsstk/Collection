#include "EventMissionManager.h"

//#include "CharacterManager.h"
//#include "ContentFeatureOpenManager.h"
#include "HUD/BaseHUD.h"
//#include "PartyManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"

UEventMissionManager::UEventMissionManager()
{
	InitStore(EHSType::EventMission);
}

void UEventMissionManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearEventMission();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LEventMissionList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("eventMission/list"), Out,
		TQ6ResponseDelegate<FL2CEventMissionListResp>::CreateUObject(
			const_cast<UEventMissionManager*>(this), &UEventMissionManager::OnListResp));
}

void UEventMissionManager::OnListResp(const FResError* Error, const FL2CEventMissionListResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_EventMissionListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		GameInstance->ReqNextContent();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void UEventMissionManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UEventMissionManager, ClearEventMission);
	REGISTER_ACTION_HANDLER(UEventMissionManager, EventMissionListResp);
}

IMPLEMENT_ACTION_HANDLER(UEventMissionManager, ClearEventMission)
{
	Missions.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(UEventMissionManager, EventMissionListResp)
{
	auto Action = ACTION_PARSE_EventMissionListResp(InAction);

	auto& Res = Action->GetVal();
	for (const FEventMissionInfo& Info : Res.Missions)
	{
		Missions.Add(Info);
	}

	return true;
}
