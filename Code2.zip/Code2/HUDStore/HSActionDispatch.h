#pragma once

// Internal

#define ACTION_DISPATCH_AccountName(ParamVal)					ACTION_DISPATCH_ONE(AccountName, FString, ParamVal)
#define ACTION_DISPATCH_WattInfo(ParamVal)						ACTION_DISPATCH_ONE(WattInfo, FWattDiffInfo, ParamVal)
#define ACTION_DISPATCH_GemConsume(ParamVal, ParamVal2)			ACTION_DISPATCH_TWO(GemConsume, int32, ParamVal/*freegem*/, int32, ParamVal2/*paidgem*/)
#define ACTION_DISPATCH_ClearMyCharacters()						ACTION_DISPATCH(ClearMyCharacters)
#define ACTION_DISPATCH_ClearBag()								ACTION_DISPATCH(ClearBag)
#define ACTION_DISPATCH_ClearRelic()							ACTION_DISPATCH(ClearRelic)
#define ACTION_DISPATCH_ClearSculpture()						ACTION_DISPATCH(ClearSculpture)
#define ACTION_DISPATCH_ClearParty()							ACTION_DISPATCH(ClearParty)
#define ACTION_DISPATCH_ClearActRecord()						ACTION_DISPATCH(ClearActRecord)
#define ACTION_DISPATCH_ClearUserRecord()						ACTION_DISPATCH(ClearUserRecord)
#define ACTION_DISPATCH_ClearCodexChar()						ACTION_DISPATCH(ClearCodexChar)
#define ACTION_DISPATCH_ClearCodexSculpture()					ACTION_DISPATCH(ClearCodexSculpture)
#define ACTION_DISPATCH_ClearCodexRelic()						ACTION_DISPATCH(ClearCodexRelic)
#define ACTION_DISPATCH_ClearWeeklyMission()					ACTION_DISPATCH(ClearWeeklyMission)
#define ACTION_DISPATCH_ClearCharMission()						ACTION_DISPATCH(ClearCharMission)
#define ACTION_DISPATCH_ClearEventMission()						ACTION_DISPATCH(ClearEventMission)
#define ACTION_DISPATCH_ClearTitle()							ACTION_DISPATCH(ClearTitle)
#define ACTION_DISPATCH_ClearLobbyTemplate()					ACTION_DISPATCH(ClearLobbyTemplate)
#define ACTION_DISPATCH_FriendshipCollect()						ACTION_DISPATCH(FriendshipCollect)
#define ACTION_DISPATCH_SystemJoker(ParamVal)					ACTION_DISPATCH_REF(SystemJoker, FCharacterInfo, ParamVal)
#define ACTION_DISPATCH_RandomJoker(ParamVal)					ACTION_DISPATCH_REF(RandomJoker, FCharacterInfo, ParamVal)
#define ACTION_DISPATCH_FriendJoker(ParamVal,ParamVal2)			ACTION_DISPATCH_TWO_REF(FriendJoker, FFriendInfo, ParamVal, EJokerSlotType, ParamVal2)
#define ACTION_DISPATCH_FriendJokerFromPopup(ParamVal,ParamVal2) \
																ACTION_DISPATCH_TWO_REF(FriendJokerFromPopup, FFriendInfo, ParamVal, EJokerSlotType, ParamVal2)
#define ACTION_DISPATCH_OwnedJoker(ParamVal)					ACTION_DISPATCH_REF(OwnedJoker, FPartySlot, ParamVal)
#define ACTION_DISPATCH_UpdateCurrency(ParamVal)				ACTION_DISPATCH_ONE(UpdateCurrency, FCurrencyInfo, ParamVal)
#define ACTION_DISPATCH_UpdateMission(ParamVal)				ACTION_DISPATCH_REF(UpdateMission, FMissionInfo, ParamVal)
#define ACTION_DISPATCH_UpdateCharMission(ParamVal)				ACTION_DISPATCH_REF(UpdateCharMission, TArray<FCharMissionInfo>, ParamVal)
#define ACTION_DISPATCH_ContentsResetTime()						ACTION_DISPATCH(ContentsResetTime)
#define ACTION_DISPATCH_UserSetTutorials(ParamVal)				ACTION_DISPATCH_ONE(UserSetTutorials, uint64, ParamVal)

// NetworkEvent
#define ACTION_DISPATCH_NetworkReconnected()					ACTION_DISPATCH(NetworkReconnected)

//////////////////////////////////////////////////////////////////////////////
//// Packet

// Lobby
#define ACTION_DISPATCH_AuthEnterLobbyResp(Resp)				ACTION_DISPATCH_REF(AuthEnterLobbyResp, FL2CAuthEnterLobbyResp, Resp)
#define ACTION_DISPATCH_AuthEnterLobbyFinalResp(Resp)			ACTION_DISPATCH_REF(AuthEnterLobbyFinalResp, FL2CAuthEnterLobbyFinalResp, Resp)

// Currency
#define ACTION_DISPATCH_CurrencyLoadResp(Resp)					ACTION_DISPATCH_REF(CurrencyLoadResp, FL2CCurrencyLoadResp, Resp)

// Result
#define ACTION_DISPATCH_UserAddXpResp(Resp)						ACTION_DISPATCH_REF(UserAddXpResp, FL2CUserAddXpResp, Resp)
#define ACTION_DISPATCH_UserRenameResp(Resp)					ACTION_DISPATCH_REF(UserRenameResp, FL2CUserRenameResp, Resp)

// Character
#define ACTION_DISPATCH_CharacterListResp(Resp)					ACTION_DISPATCH_REF(CharacterListResp, FL2CCharacterListResp, Resp)
#define ACTION_DISPATCH_CharacterLoadResp(Resp)					ACTION_DISPATCH_REF(CharacterLoadResp, FL2CCharacterLoadResp, Resp)
#define ACTION_DISPATCH_CharacterAddXpResp(Resp)				ACTION_DISPATCH_REF(CharacterAddXpResp, FL2CCharacterAddXpResp, Resp)
#define ACTION_DISPATCH_CharacterPromoteResp(Resp)				ACTION_DISPATCH_REF(CharacterPromoteResp, FL2CCharacterPromoteResp, Resp)
#define ACTION_DISPATCH_CharacterRemoveResp(Resp)				ACTION_DISPATCH_REF(CharacterRemoveResp, FL2CCharacterRemoveResp, Resp)
#define ACTION_DISPATCH_CharacterSkillLevelResp(Resp)			ACTION_DISPATCH_ONE(CharacterSkillLevelResp, FL2CCharacterSkillLevelResp, Resp)
#define ACTION_DISPATCH_CharacterTurnSkillLevelResp(Resp)		ACTION_DISPATCH_ONE(CharacterTurnSkillLevelResp, FL2CCharacterUpgradeTurnSkillLevelResp, Resp)
#define ACTION_DISPATCH_CharacterUltimateSkillLevelResp(Resp)	ACTION_DISPATCH_ONE(CharacterUltimateSkillLevelResp, FL2CCharacterUpgradeUltimateSkillLevelResp, Resp)
#define ACTION_DISPATCH_CharacterUnbindResp(Resp)				ACTION_DISPATCH_ONE(CharacterUnbindResp, FL2CCharacterUnbindResp, Resp)
#define ACTION_DISPATCH_CharacterEvoluteResp(Resp)				ACTION_DISPATCH_ONE(CharacterEvoluteResp, FL2CCharacterEvoluteResp, Resp)
#define ACTION_DISPATCH_CharacterSetStashResp(Resp)				ACTION_DISPATCH_ONE(CharacterSetStashResp, FL2CCharacterSetStashResp, Resp)
#define ACTION_DISPATCH_CharacterSetIllustResp(Resp)			ACTION_DISPATCH_ONE(CharacterSetIllustResp, FL2CCharacterSetIllustResp, Resp)
#define ACTION_DISPATCH_CharacterClearNewResp(Resp)				ACTION_DISPATCH_ONE(CharacterClearNewResp, FL2CCharacterClearNewResp, Resp)

// Character Bond
#define ACTION_DISPATCH_BondLoadResp(Resp)						ACTION_DISPATCH_REF(BondLoadResp, FL2CBondLoadResp, Resp)

// Friend
#define ACTION_DISPATCH_FriendAcceptResp(Resp)					ACTION_DISPATCH_REF(FriendAcceptResp, FL2CFriendAcceptResp, Resp)
#define ACTION_DISPATCH_FriendDeclineResp(Resp)					ACTION_DISPATCH_REF(FriendDeclineResp, FL2CFriendDeclineResp, Resp)
#define ACTION_DISPATCH_FriendLoadResp(Resp)					ACTION_DISPATCH_REF(FriendLoadResp, FL2CFriendLoadResp, Resp)
#define ACTION_DISPATCH_FriendCooltimeListResp(Resp)			ACTION_DISPATCH_REF(FriendCooltimeListResp, FL2CFriendCooltimeListResp, Resp)
#define ACTION_DISPATCH_FriendCandidatesResp(Resp)				ACTION_DISPATCH_REF(FriendCandidatesResp, FL2CFriendCandidatesResp, Resp)
#define ACTION_DISPATCH_FriendRemoveResp(Resp)					ACTION_DISPATCH_REF(FriendRemoveResp, FL2CFriendRemoveResp, Resp)
#define ACTION_DISPATCH_FriendRequestResp(Resp)					ACTION_DISPATCH_REF(FriendRequestResp, FL2CFriendRequestResp, Resp)
#define ACTION_DISPATCH_FriendSearchResp(Resp)					ACTION_DISPATCH_REF(FriendSearchResp, FL2CFriendSearchResp, Resp)
#define ACTION_DISPATCH_FriendConfirmResp(Resp)					ACTION_DISPATCH_REF(FriendConfirmResp, FL2CFriendConfirmResp, Resp)
#define ACTION_DISPATCH_FriendErrorResp(Err)					ACTION_DISPATCH_REF(FriendErrorResp, FL2CError, Err)
#define ACTION_DISPATCH_FriendNotifyAccept(Notify)				ACTION_DISPATCH_REF(FriendNotifyAccept, FL2CFriendNotifyAccept, Notify)
#define ACTION_DISPATCH_FriendNotifyRemove(Notify)				ACTION_DISPATCH_REF(FriendNotifyRemove, FL2CFriendNotifyRemove, Notify)
#define ACTION_DISPATCH_FriendNotifyJokerSetChange(Notify)		ACTION_DISPATCH_REF(FriendNotifyJokerSetChange, FL2CFriendNotifyJokerSetChange, Notify)
#define ACTION_DISPATCH_FriendNotifyRequest(Notify)				ACTION_DISPATCH_REF(FriendNotifyRequest, FL2CFriendNotifyRequest, Notify)
#define ACTION_DISPATCH_FriendNotifyAvatarChange(Notify)		ACTION_DISPATCH_REF(FriendNotifyAvatarChange, FL2CFriendNotifyAvatarChange, Notify)
#define ACTION_DISPATCH_FriendNotifyNicknameChanged(Notify)		ACTION_DISPATCH_REF(FriendNotifyNicknameChanged, FL2CFriendNotifyNicknameChanged, Notify)

// Friendship
#define ACTION_DISPATCH_FriendshipCollectResp(Resp)				ACTION_DISPATCH_REF(FriendshipCollectResp, FL2CFriendshipCollectResp, Resp)

// JokerSet
#define ACTION_DISPATCH_JokerSetLoadResp(Resp)					ACTION_DISPATCH_REF(JokerSetLoadResp, FL2CJokerSetLoadResp, Resp)
#define ACTION_DISPATCH_JokerSetSaveResp(Resp)					ACTION_DISPATCH_REF(JokerSetSaveResp, FL2CJokerSetSaveResp, Resp)
#define ACTION_DISPATCH_JokerSetUseResp(Resp)					ACTION_DISPATCH_REF(JokerSetUseResp, FL2CJokerSetUseResp, Resp)

// Mail
#define ACTION_DISPATCH_MailListResp(Resp)						ACTION_DISPATCH_REF(MailListResp, FL2CMailListResp, Resp)
#define ACTION_DISPATCH_MailReceiveResp(Resp)					ACTION_DISPATCH_REF(MailReceiveResp, FL2CMailReceiveResp, Resp)
#define ACTION_DISPATCH_MailRefreshListResp(Resp)				ACTION_DISPATCH_REF(MailRefreshListResp, FL2CMailRefreshListResp, Resp)

// Party
#define ACTION_DISPATCH_PartyLoadResp(Resp)						ACTION_DISPATCH_REF(PartyLoadResp, FL2CPartyLoadResp, Resp)
#define ACTION_DISPATCH_PartySaveResp(Resp)						ACTION_DISPATCH_REF(PartySaveResp, FL2CPartySaveResp, Resp)

// BagItem
#define ACTION_DISPATCH_BagItemLoadResp(Resp)					ACTION_DISPATCH_REF(BagItemLoadResp, FL2CBagItemLoadResp, Resp)
#define ACTION_DISPATCH_BagItemListResp(Resp)					ACTION_DISPATCH_REF(BagItemListResp, FL2CBagItemListResp, Resp)
#define ACTION_DISPATCH_BagItemRemoveResp(Resp)					ACTION_DISPATCH_REF(BagItemRemoveResp, FL2CBagItemRemoveResp, Resp)

// Relic
#define ACTION_DISPATCH_RelicLoadResp(Resp)						ACTION_DISPATCH_ONE(RelicLoadResp, FL2CRelicLoadResp, Resp)
#define ACTION_DISPATCH_RelicListResp(Resp)						ACTION_DISPATCH_ONE(RelicListResp, FL2CRelicListResp, Resp)
#define ACTION_DISPATCH_RelicRemoveResp(Resp)					ACTION_DISPATCH_ONE(RelicRemoveResp, FL2CRelicRemoveResp, Resp)
#define ACTION_DISPATCH_RelicAddXpResp(Resp)					ACTION_DISPATCH_ONE(RelicAddXpResp, FL2CRelicAddXpResp, Resp)
#define ACTION_DISPATCH_RelicPromoteResp(Resp)					ACTION_DISPATCH_ONE(RelicPromoteResp, FL2CRelicPromoteResp, Resp)
#define ACTION_DISPATCH_RelicTierUpResp(Resp)					ACTION_DISPATCH_ONE(RelicTierUpResp, FL2CRelicTierUpgradeResp, Resp)
#define ACTION_DISPATCH_RelicSetStashResp(Resp)					ACTION_DISPATCH_ONE(RelicSetStashResp, FL2CRelicSetStashResp, Resp)
#define ACTION_DISPATCH_RelicClearNewResp(Resp)					ACTION_DISPATCH_ONE(RelicClearNewResp, FL2CRelicClearNewResp, Resp)

// Sculpture
#define ACTION_DISPATCH_SculptureLoadResp(Resp)					ACTION_DISPATCH_ONE(SculptureLoadResp, FL2CSculptureLoadResp, Resp)
#define ACTION_DISPATCH_SculptureListResp(Resp)					ACTION_DISPATCH_ONE(SculptureListResp, FL2CSculptureListResp, Resp)
#define ACTION_DISPATCH_SculptureRemoveResp(Resp)				ACTION_DISPATCH_ONE(SculptureRemoveResp, FL2CSculptureRemoveResp, Resp)
#define ACTION_DISPATCH_SculptureAddXpResp(Resp)				ACTION_DISPATCH_ONE(SculptureAddXpResp, FL2CSculptureAddXpResp, Resp)
#define ACTION_DISPATCH_SculpturePromoteResp(Resp)				ACTION_DISPATCH_ONE(SculpturePromoteResp, FL2CSculpturePromoteResp, Resp)
#define ACTION_DISPATCH_SculptureTierUpResp(Resp)				ACTION_DISPATCH_ONE(SculptureTierUpResp, FL2CSculptureTierUpgradeResp, Resp)
#define ACTION_DISPATCH_SculptureSetStashResp(Resp)				ACTION_DISPATCH_ONE(SculptureSetStashResp, FL2CSculptureSetStashResp, Resp)
#define ACTION_DISPATCH_SculptureClearNewResp(Resp)				ACTION_DISPATCH_ONE(SculptureClearNewResp, FL2CSculptureClearNewResp, Resp)

// ActRecord
#define ACTION_DISPATCH_ActRecordLoadResp(Resp)					ACTION_DISPATCH_ONE(ActRecordLoadResp, FL2CActRecordLoadResp, Resp)
#define ACTION_DISPATCH_ActRecordListResp(Resp)					ACTION_DISPATCH_ONE(ActRecordListResp, FL2CActRecordListResp, Resp)
#define ACTION_DISPATCH_ActRecordRemoveResp(Resp)				ACTION_DISPATCH_ONE(ActRecordRemoveResp, FL2CActRecordRemoveResp, Resp)

// UserRecord
#define ACTION_DISPATCH_UserRecordListResp(Resp)				ACTION_DISPATCH_ONE(UserRecordListResp, FL2CUserRecordListResp, Resp)
#define ACTION_DISPATCH_UserRecordRezCountResp(Resp)			ACTION_DISPATCH_ONE(UserRecordRezCountResp, FL2CUserRecordRezCountResp, Resp)

// codex
#define ACTION_DISPATCH_CodexListCharResp(Resp)					ACTION_DISPATCH_ONE(CodexListCharResp, FL2CCodexListCharResp, Resp)
#define ACTION_DISPATCH_CodexListSculptureResp(Resp)			ACTION_DISPATCH_ONE(CodexListSculptureResp, FL2CCodexListSculptureResp, Resp)
#define ACTION_DISPATCH_CodexListRelicResp(Resp)				ACTION_DISPATCH_ONE(CodexListRelicResp, FL2CCodexListRelicResp, Resp)
#define ACTION_DISPATCH_CodexClearNewCharResp(Resp)				ACTION_DISPATCH_ONE(CodexClearNewCharResp, FL2CCodexClearNewCharResp, Resp)
#define ACTION_DISPATCH_CodexClearNewSculptureResp(Resp)		ACTION_DISPATCH_ONE(CodexClearNewSculptureResp, FL2CCodexClearNewSculptureResp, Resp)
#define ACTION_DISPATCH_CodexClearNewRelicResp(Resp)			ACTION_DISPATCH_ONE(CodexClearNewRelicResp, FL2CCodexClearNewRelicResp, Resp)
#define ACTION_DISPATCH_CodexClearNewAllResp(Resp)				ACTION_DISPATCH_ONE(CodexClearNewAllResp, FL2CCodexClearNewAllResp, Resp)

// weekly mission
#define ACTION_DISPATCH_WeeklyMissionLoadResp(Resp)				ACTION_DISPATCH_ONE(WeeklyMissionLoadResp, FL2CWeeklyMissionLoadResp, Resp)
#define ACTION_DISPATCH_WeeklyMissionRewardResp(Resp)			ACTION_DISPATCH_ONE(WeeklyMissionRewardResp, FL2CWeeklyMissionReceiveRewardResp, Resp)
#define ACTION_DISPATCH_WeeklyMissionBingoResp(Resp)			ACTION_DISPATCH_ONE(WeeklyMissionBingoResp, FL2CWeeklyMissionReceiveBingoResp, Resp)
#define ACTION_DISPATCH_WeeklyMissionShuffleResp(Resp)			ACTION_DISPATCH_ONE(WeeklyMissionShuffleResp, FL2CWeeklyMissionShuffleResp, Resp)

// smelter
#define ACTION_DISPATCH_SmelterLoadResp(Resp)					ACTION_DISPATCH_ONE(SmelterLoadResp, FL2CSmelterLoadResp, Resp)
#define ACTION_DISPATCH_SmelterIncStockResp(Resp)				ACTION_DISPATCH_ONE(SmelterIncStockResp, FL2CSmelterIncStockResp, Resp)
#define ACTION_DISPATCH_SmelterDecStockResp(Resp)				ACTION_DISPATCH_ONE(SmelterDecStockResp, FL2CSmelterDecStockResp, Resp)
#define ACTION_DISPATCH_SmelterReceiveResp(Resp)				ACTION_DISPATCH_ONE(SmelterReceiveResp, FL2CSmelterReceiveResp, Resp)
#define ACTION_DISPATCH_SmelterUpgradeResp(Resp)				ACTION_DISPATCH_ONE(SmelterUpgradeResp, FL2CSmelterUpgradeResp, Resp)
#define ACTION_DISPATCH_SmelterUpgradeCompleteResp(Resp)		ACTION_DISPATCH_ONE(SmelterUpgradeCompleteResp, FL2CSmelterUpgradeCompleteResp, Resp)
#define ACTION_DISPATCH_SmelterProduceResp(Resp)				ACTION_DISPATCH_ONE(SmelterProduceResp, FL2CSmelterProduceResp, Resp)

// alchemylab
#define ACTION_DISPATCH_AlchemylabLoadResp(Resp)				ACTION_DISPATCH_ONE(AlchemylabLoadResp, FL2CAlchemylabLoadResp, Resp)
#define ACTION_DISPATCH_AlchemylabIncStockResp(Resp)			ACTION_DISPATCH_ONE(AlchemylabIncStockResp, FL2CAlchemylabIncStockResp, Resp)
#define ACTION_DISPATCH_AlchemylabDecStockResp(Resp)			ACTION_DISPATCH_ONE(AlchemylabDecStockResp, FL2CAlchemylabDecStockResp, Resp)
#define ACTION_DISPATCH_AlchemylabReceiveResp(Resp)				ACTION_DISPATCH_ONE(AlchemylabReceiveResp, FL2CAlchemylabReceiveResp, Resp)
#define ACTION_DISPATCH_AlchemylabUpgradeResp(Resp)				ACTION_DISPATCH_ONE(AlchemylabUpgradeResp, FL2CAlchemylabUpgradeResp, Resp)
#define ACTION_DISPATCH_AlchemylabUpgradeCompleteResp(Resp)		ACTION_DISPATCH_ONE(AlchemylabUpgradeCompleteResp, FL2CAlchemylabUpgradeCompleteResp, Resp)
#define ACTION_DISPATCH_AlchemylabProduceResp(Resp)				ACTION_DISPATCH_ONE(AlchemylabProduceResp, FL2CAlchemylabProduceResp, Resp)

// char mission
#define ACTION_DISPATCH_CharMissionListResp(Resp)				ACTION_DISPATCH_ONE(CharMissionListResp, FL2CCharMissionListResp, Resp)
#define ACTION_DISPATCH_CharMissionRewardResp(Resp)				ACTION_DISPATCH_ONE(CharMissionRewardResp, FL2CCharMissionReceiveRewardResp, Resp)

// event mission
#define ACTION_DISPATCH_EventMissionListResp(Resp)				ACTION_DISPATCH_ONE(EventMissionListResp, FL2CEventMissionListResp, Resp)

// user title
#define ACTION_DISPATCH_TitleListResp(Resp)						ACTION_DISPATCH_ONE(TitleListResp, FL2CUserTitleListResp, Resp)
#define ACTION_DISPATCH_TitleChangeResp(Resp)					ACTION_DISPATCH_ONE(TitleChangeResp, FL2CUserTitleChangeResp, Resp)
#define ACTION_DISPATCH_DevTitleAddResp(Resp)					ACTION_DISPATCH_ONE(DevTitleAddResp, FL2CDevTitleAddResp, Resp)

// Saga
#define ACTION_DISPATCH_SagaLoadResp(Resp)						ACTION_DISPATCH_REF(SagaLoadResp, FL2CSagaLoadResp, Resp)
#define ACTION_DISPATCH_SagaStageBeginResp(Resp)				ACTION_DISPATCH_REF(SagaStageBeginResp, FL2CSagaStageBeginResp, Resp)
#define ACTION_DISPATCH_SagaStageEndResp(Resp)					ACTION_DISPATCH_REF(SagaStageEndResp, FL2CSagaStageEndResp, Resp)
#define ACTION_DISPATCH_SagaStoryStageClearResp(Resp)			ACTION_DISPATCH_REF(SagaStoryStageClearResp, FL2CSagaStoryStageClearResp, Resp)

// Special
#define ACTION_DISPATCH_SpecialLoadResp(Resp)					ACTION_DISPATCH_REF(SpecialLoadResp, FL2CSpecialLoadResp, Resp)
#define ACTION_DISPATCH_SpecialStageBeginResp(Resp)				ACTION_DISPATCH_REF(SpecialStageBeginResp, FL2CSpecialStageBeginResp, Resp)
#define ACTION_DISPATCH_SpecialStageEndResp(Resp)				ACTION_DISPATCH_REF(SpecialStageEndResp, FL2CSpecialStageEndResp, Resp)
#define ACTION_DISPATCH_SpecialStoryStageClearResp(Resp)		ACTION_DISPATCH_REF(SpecialStoryStageClearResp, FL2CSpecialStoryStageClearResp, Resp)

// Daily
#define ACTION_DISPATCH_DailyStageBeginResp(Resp)				ACTION_DISPATCH_REF(DailyStageBeginResp, FL2CDailyStageBeginResp, Resp)
#define ACTION_DISPATCH_DailyStageEndResp(Resp)					ACTION_DISPATCH_REF(DailyStageEndResp, FL2CDailyStageEndResp, Resp)
#define ACTION_DISPATCH_DailyListResp(Resp)						ACTION_DISPATCH_REF(DailyListResp, FL2CDailyListResp, Resp)

// Raid
#define ACTION_DISPATCH_RaidListResp(Resp)						ACTION_DISPATCH_REF(RaidListResp, FL2CRaidListResp, Resp)
#define ACTION_DISPATCH_RaidReqTimeout()						ACTION_DISPATCH(RaidReqTimeout)
#define ACTION_DISPATCH_RaidOpenNof(Nof)						ACTION_DISPATCH_REF(RaidOpenNof, FL2CRaidOpenNof, Nof)
#define ACTION_DISPATCH_RaidCanEnterNof(Nof)					ACTION_DISPATCH_REF(RaidCanEnterNof, FL2CRaidCanEnterNof, Nof)
#define ACTION_DISPATCH_RaidPrepareResp(Resp)					ACTION_DISPATCH_REF(RaidPrepareResp, FL2CRaidPrepareResp, Resp)
#define ACTION_DISPATCH_RaidOpenNofTimeout()					ACTION_DISPATCH(RaidOpenNofTimeout)
#define ACTION_DISPATCH_RaidReadyTimeout()						ACTION_DISPATCH(RaidReadyTimeout)
#define ACTION_DISPATCH_RaidPrepareTimeout()					ACTION_DISPATCH(RaidPrepareTimeout)
#define ACTION_DISPATCH_RaidStageEndResp(Resp)					ACTION_DISPATCH_REF(RaidStageEndResp, FL2CRaidStageEndResp, Resp)
#define ACTION_DISPATCH_RaidStageEndNof(Nof)					ACTION_DISPATCH_REF(RaidStageEndNof, FL2CRaidStageEndNof, Nof)
#define ACTION_DISPATCH_RaidFullNof(Nof)						ACTION_DISPATCH_REF(RaidFullNof, FL2CRaidFullNof, Nof)
#define ACTION_DISPATCH_RaidKickTimeoutNof(Nof)					ACTION_DISPATCH_REF(RaidKickTimeoutNof, FL2CRaidKickTimeoutNof, Nof)
#define ACTION_DISPATCH_RaidSkillUsedResp(Resp)					ACTION_DISPATCH_REF(RaidSkillUsedResp, FL2CRaidSkillUsedResp, Resp)
#define ACTION_DISPATCH_RaidEnterNof(Nof)						ACTION_DISPATCH_REF(RaidEnterNof, FL2CRaidEnterNof, Nof)
#define ACTION_DISPATCH_RaidEndNof(Nof)							ACTION_DISPATCH_REF(RaidEndNof, FL2CRaidEndNof, Nof)
#define ACTION_DISPATCH_RaidSkillsNof(Nof)						ACTION_DISPATCH_REF(RaidSkillsNof, FL2CRaidSkillsNof, Nof)
#define ACTION_DISPATCH_RaidEnterNofTimeout()					ACTION_DISPATCH(RaidEnterNofTimeout)
#define ACTION_DISPATCH_RaidSkillsTimeout()						ACTION_DISPATCH(RaidSkillsTimeout)
#define ACTION_DISPATCH_RaidBossHealthNof(Nof)					ACTION_DISPATCH_REF(RaidBossHealthNof, FL2CRaidBossHealthNof, Nof)
#define ACTION_DISPATCH_RaidEmoticonNof(Nof)					ACTION_DISPATCH_REF(RaidEmoticonNof, FL2CRaidEmoticonNof, Nof)
#define ACTION_DISPATCH_RaidSharePartyResp(Resp)				ACTION_DISPATCH_REF(RaidSharePartyResp, FL2CRaidSharePartyResp, Resp)
#define ACTION_DISPATCH_RaidSharePartyNof(Nof)					ACTION_DISPATCH_REF(RaidSharePartyNof, FL2CRaidSharePartyNof, Nof)
#define ACTION_DISPATCH_RaidFinalStageBeginResp(Resp)			ACTION_DISPATCH_REF(RaidFinalStageBeginResp, FL2CRaidFinalStageBeginResp, Resp)
#define ACTION_DISPATCH_RaidFinalStageEndResp(Resp)				ACTION_DISPATCH_REF(RaidFinalStageEndResp, FL2CRaidFinalStageEndResp, Resp)
#define ACTION_DISPATCH_RegularRaidRegisterResp(Resp)			ACTION_DISPATCH_REF(RegularRaidRegisterResp, FL2CRegularRaidRegisterResp, Resp)
#define ACTION_DISPATCH_RegularRaidReadyResp(Resp)				ACTION_DISPATCH_REF(RegularRaidReadyResp, FL2CRegularRaidReadyResp, Resp)
#define ACTION_DISPATCH_RegularRaidMatchedNoti(Resp)			ACTION_DISPATCH_REF(RegularRaidMatchedNoti, FL2CRegularRaidNotiMatched, Resp)

// Summon
#define ACTION_DISPATCH_SummonLoadResp(Resp)					ACTION_DISPATCH_REF(SummonLoadResp, FL2CSummonLoadResp, Resp)
#define ACTION_DISPATCH_SummonPurchaseResp(Resp)				ACTION_DISPATCH_REF(SummonPurchaseResp, FL2CSummonPurchaseResp, Resp)
#define ACTION_DISPATCH_SummonBoxScheduleResp(Resp)				ACTION_DISPATCH_REF(SummonBoxScheduleResp, FL2CSummonScheduleResp, Resp)
#define ACTION_DISPATCH_SummonPickupResp(Resp)					ACTION_DISPATCH_REF(SummonPickupResp, FL2CSummonPickupResp, Resp)

// TrainingCenter
#define ACTION_DISPATCH_TrainingCenterLoadResp(Resp)			ACTION_DISPATCH_REF(TrainingCenterLoadResp, FL2CTrainingCenterLoadResp, Resp)
#define ACTION_DISPATCH_TrainingCenterStageBeginResp(Resp)		ACTION_DISPATCH_REF(TrainingCenterStageBeginResp, FL2CTrainingCenterStageBeginResp, Resp)
#define ACTION_DISPATCH_TrainingCenterStageEndResp(Resp)		ACTION_DISPATCH_REF(TrainingCenterStageEndResp, FL2CTrainingCenterStageEndResp, Resp)

// Pyramid
#define ACTION_DISPATCH_PyramidLoadResp(Resp)					ACTION_DISPATCH_REF(PyramidLoadResp, FL2CPyramidLoadResp, Resp)
#define ACTION_DISPATCH_PyramidPortalConnectResp(Resp)			ACTION_DISPATCH_REF(PyramidPortalConnectResp, FL2CPyramidPortalConnectResp, Resp)
#define ACTION_DISPATCH_PyramidUpgradeResp(Resp)				ACTION_DISPATCH_REF(PyramidUpgradeResp, FL2CPyramidUpgradeResp, Resp)
#define ACTION_DISPATCH_PyramidUpgradeCompleteResp(Resp)		ACTION_DISPATCH_REF(PyramidUpgradeCompleteResp, FL2CPyramidUpgradeCompleteResp, Resp)
#define ACTION_DISPATCH_PyramidPortalBoostUseResp(Resp)			ACTION_DISPATCH_REF(PyramidPortalBoostUseResp, FL2CPyramidPortalBoostUseResp, Resp)
#define ACTION_DISPATCH_PyramidPortalWarpResp(Resp)				ACTION_DISPATCH_REF(PyramidPortalWarpResp, FL2CPyramidPortalWarpResp, Resp)

// Temple
#define ACTION_DISPATCH_TempleLoadResp(Resp)					ACTION_DISPATCH_REF(TempleLoadResp, FL2CTempleLoadResp, Resp)
#define ACTION_DISPATCH_TempleUpgradeResp(Resp)					ACTION_DISPATCH_REF(TempleUpgradeResp, FL2CTempleUpgradeResp, Resp)
#define ACTION_DISPATCH_TempleUpgradeCompleteResp(Resp)			ACTION_DISPATCH_REF(TempleUpgradeCompleteResp, FL2CTempleUpgradeCompleteResp, Resp)
#define ACTION_DISPATCH_TempleArtifactUseResp(Resp)				ACTION_DISPATCH_REF(TempleArtifactUseResp, FL2CTempleArtifactUseResp, Resp)
#define ACTION_DISPATCH_TempleArtifactBoostResp(Resp)			ACTION_DISPATCH_REF(TempleArtifactBoostResp, FL2CTempleArtifactBoostResp, Resp)
#define ACTION_DISPATCH_TempleArtifactUpgradeResp(Resp)			ACTION_DISPATCH_REF(TempleArtifactUpgradeResp, FL2CTempleArtifactUpgradeResp, Resp)
#define ACTION_DISPATCH_TempleHarvestResp(Resp)					ACTION_DISPATCH_REF(TempleHarvestResp, FL2CTempleHarvestResp, Resp)

// PowerPlant
#define ACTION_DISPATCH_PowerPlantLoadResp(Resp)				ACTION_DISPATCH_REF(PowerPlantLoadResp, FL2CPowerPlantLoadResp, Resp)
#define ACTION_DISPATCH_PowerPlantUpgradeResp(Resp)				ACTION_DISPATCH_REF(PowerPlantUpgradeResp, FL2CPowerPlantUpgradeResp, Resp)
#define ACTION_DISPATCH_PowerPlantUpgradeCompleteResp(Resp)		ACTION_DISPATCH_REF(PowerPlantUpgradeCompleteResp, FL2CPowerPlantUpgradeCompleteResp, Resp)
#define ACTION_DISPATCH_PowerPlantStoreResp(Resp)				ACTION_DISPATCH_REF(PowerPlantStoreResp, FL2CPowerPlantStoreResp, Resp)
#define ACTION_DISPATCH_PowerPlantRechargeResp(Resp)			ACTION_DISPATCH_REF(PowerPlantRechargeResp, FL2CPowerPlantRechargeResp, Resp)

// Pet
#define ACTION_DISPATCH_PetLoadResp(Resp)						ACTION_DISPATCH_REF(PetLoadResp, FL2CPetLoadResp, Resp)
#define ACTION_DISPATCH_PetParkUpgradeResp(Resp)				ACTION_DISPATCH_REF(PetParkUpgradeResp, FL2CPetParkUpgradeResp, Resp)
#define ACTION_DISPATCH_PetParkUpgradeCompleteResp(Resp)		ACTION_DISPATCH_REF(PetParkUpgradeCompleteResp, FL2CPetParkUpgradeCompleteResp, Resp)
#define ACTION_DISPATCH_PetParkHarvestResp(Resp)				ACTION_DISPATCH_REF(PetParkHarvestResp, FL2CPetHarvestResp, Resp)
#define ACTION_DISPATCH_PetSkillUpgradeResp(Resp)				ACTION_DISPATCH_REF(PetSkillUpgradeResp, FL2CPetSkillUpgradeResp, Resp)

// Vacation
#define ACTION_DISPATCH_VacationLoadResp(Resp)					ACTION_DISPATCH_REF(VacationLoadResp, FL2CVacationLoadResp, Resp)
#define ACTION_DISPATCH_VacationUpgradeResp(Resp)				ACTION_DISPATCH_REF(VacationUpgradeResp, FL2CVacationUpgradeResp, Resp)
#define ACTION_DISPATCH_VacationUpgradeCompleteResp(Resp)		ACTION_DISPATCH_REF(VacationUpgradeCompleteResp, FL2CVacationUpgradeCompleteResp, Resp)
#define ACTION_DISPATCH_VacationStartResp(Resp)					ACTION_DISPATCH_REF(VacationStartResp, FL2CVacationStartResp, Resp)
#define ACTION_DISPATCH_VacationEndResp(Resp)					ACTION_DISPATCH_REF(VacationEndResp, FL2CVacationEndResp, Resp)

// Watt
#define ACTION_DISPATCH_WattRechargeResp(Resp)					ACTION_DISPATCH_REF(WattRechargeResp, FL2CWattRechargeResp, Resp)

// CheckIn
#define  ACTION_DISPATCH_CheckInListResp(Resp)					ACTION_DISPATCH_REF(CheckInListResp, FL2CCheckInListResp, Resp)
#define  ACTION_DISPATCH_CheckInRewardReceiveResp(Resp)			ACTION_DISPATCH_REF(CheckInRewardReceiveResp, FL2CCheckInRewardReceiveResp, Resp)

// Shop
#define  ACTION_DISPATCH_ShopListResp(Resp)						ACTION_DISPATCH_REF(ShopListResp, FL2CShopListResp, Resp)
#define  ACTION_DISPATCH_ShopSaleScheduleResp(Resp)				ACTION_DISPATCH_REF(ShopSaleScheduleResp, FL2CShopSaleScheduleResp, Resp)
#define  ACTION_DISPATCH_ShopBuyItemResp(Resp)					ACTION_DISPATCH_REF(ShopBuyItemResp, FL2CShopBuyItemResp, Resp)
#define  ACTION_DISPATCH_ShopSellItemResp(Resp)					ACTION_DISPATCH_REF(ShopSellItemResp, FL2CShopSellItemResp, Resp)
#define  ACTION_DISPATCH_ShopClearNewResp(Resp)					ACTION_DISPATCH_REF(ShopClearNewResp, FL2CShopClearNewResp, Resp)

// LobbyTemplate
#define  ACTION_DISPATCH_LobbyTemplateListResp(Resp)			ACTION_DISPATCH_REF(LobbyTemplateListResp, FL2CLobbyTemplateListResp, Resp)
#define  ACTION_DISPATCH_LobbyTemplateClearNewResp(Resp)		ACTION_DISPATCH_REF(LobbyTemplateClearNewResp, FL2CLobbyTemplateClearNewResp, Resp)

// LobbySet
#define  ACTION_DISPATCH_LobbySetLoadResp(Resp)					ACTION_DISPATCH_REF(LobbySetLoadResp, FL2CLobbySetLoadResp, Resp)
#define  ACTION_DISPATCH_LobbySetSaveResp(Resp)					ACTION_DISPATCH_REF(LobbySetSaveResp, FL2CLobbySetSaveResp, Resp)
#define  ACTION_DISPATCH_LobbySetUseResp(Resp)					ACTION_DISPATCH_REF(LobbySetUseResp, FL2CLobbySetUseResp, Resp);

// ContentFeatureOpen
#define  ACTION_DISPATCH_ContentFeatureOpenListResp(Resp)		ACTION_DISPATCH_REF(ContentFeatureOpenListResp, FL2CContentFeatureOpenListResp, Resp)

// Event
#define  ACTION_DISPATCH_EventContentListResp(Resp)								ACTION_DISPATCH_REF(EventContentListResp, FL2CEventContentListResp, Resp)
#define  ACTION_DISPATCH_EventContentRefreshNumberOfDaysResp(Resp)				ACTION_DISPATCH_REF(EventContentRefreshNumberOfDaysResp, FL2CEventContentRefreshNumberOfDaysResp, Resp)
#define  ACTION_DISPATCH_EventContentRoulettePlayResp(Resp)						ACTION_DISPATCH_REF(EventContentRoulettePlayResp, FL2CEventContentRoulettePlayResp, Resp)
#define  ACTION_DISPATCH_EventContentRouletteResetResp(Resp)					ACTION_DISPATCH_REF(EventContentRouletteResetResp, FL2CEventContentRouletteResetResp, Resp)
#define  ACTION_DISPATCH_EventContentCollabo01StageBeginResp(Resp)				ACTION_DISPATCH_REF(EventContentCollabo01StageBeginResp, FL2CEventContentCollabo01StageBeginResp, Resp)
#define  ACTION_DISPATCH_EventContentCollabo01StageEndResp(Resp)				ACTION_DISPATCH_REF(EventContentCollabo01StageEndResp, FL2CEventContentCollabo01StageEndResp, Resp)
#define  ACTION_DISPATCH_EventContentCollabo01StoryStageClearResp(Resp)			ACTION_DISPATCH_REF(EventContentCollabo01StoryStageClearResp, FL2CEventContentCollabo01StoryStageClearResp, Resp)
#define  ACTION_DISPATCH_EventContentValentineDayStageBeginResp(Resp)			ACTION_DISPATCH_REF(EventContentValentineDayStageBeginResp, FL2CEventContentValentineDayStageBeginResp, Resp)
#define  ACTION_DISPATCH_EventContentValentineDayStageEndResp(Resp)				ACTION_DISPATCH_REF(EventContentValentineDayStageEndResp, FL2CEventContentValentineDayStageEndResp, Resp)
#define  ACTION_DISPATCH_EventContentValentineDayStoryStageClearResp(Resp)		ACTION_DISPATCH_REF(EventContentValentineDayStoryStageClearResp, FL2CEventContentValentineDayStoryStageClearResp, Resp)
#define  ACTION_DISPATCH_EventContentMultiSideBattleStageBeginResp(Resp)		ACTION_DISPATCH_REF(EventContentMultiSideBattleStageBeginResp, FL2CEventContentMultiSideBattleStageBeginResp, Resp)
#define  ACTION_DISPATCH_EventContentMultiSideBattleStageEndResp(Resp)			ACTION_DISPATCH_REF(EventContentMultiSideBattleStageEndResp, FL2CEventContentMultiSideBattleStageEndResp, Resp)
#define  ACTION_DISPATCH_EventContentMultiSideBattleStoryStageClearResp(Resp)	ACTION_DISPATCH_REF(EventContentMultiSideBattleStoryStageClearResp, FL2CEventContentMultiSideBattleStoryStageClearResp, Resp)
#define  ACTION_DISPATCH_EventContentMultisideBattleReceiveRankRewardResp(Resp)	ACTION_DISPATCH_REF(EventContentMultisideBattleReceiveRankRewardResp, FL2CEventContentMultiSideBattleReceiveRankRewardResp, Resp)
#define  ACTION_DISPATCH_EventContentMultiSideBattleRankLoadResp(Resp)			ACTION_DISPATCH_REF(EventContentMultiSideBattleRankLoadResp, FL2CEventContentMultiSideBattleLoadResp, Resp)

// Avatar
#define  ACTION_DISPATCH_AvatarLoadResp(Resp)		ACTION_DISPATCH_REF(AvatarLoadResp, FL2CAvatarLoadResp, Resp)
#define  ACTION_DISPATCH_AvatarSaveResp(Resp)		ACTION_DISPATCH_REF(AvatarSaveResp, FL2CAvatarSaveResp, Resp)

// NewMark
#define  ACTION_DISPATCH_NewMarkNotifyMail(ParamVal)			ACTION_DISPATCH_REF(NewMarkNotifyMail, bool, ParamVal)

// BattleHelper
#define  ACTION_DISPATCH_StageChallengeListResp(Resp)		ACTION_DISPATCH_REF(StageChallengeListResp, FL2CStageChallengeListResp, Resp)
#define  ACTION_DISPATCH_StageChallengeAdd(ParamVal)		ACTION_DISPATCH_ONE(StageChallengeAddResp, FC2LStageChallengeAdd, ParamVal)

// FriendBook
#define ACTION_DISPATCH_FriendBookPosted(Resp)				ACTION_DISPATCH_REF(FriendBookPosted, FL2CFriendBookNotiPosted, Resp)
#define ACTION_DISPATCH_FriendBookReacted(Resp)				ACTION_DISPATCH_REF(FriendBookReacted, FL2CFriendBookNotiReacted, Resp)
#define ACTION_DISPATCH_FriendBookReactionRemoved(Resp)		ACTION_DISPATCH_REF(FriendBookReactionRemoved, FL2CFriendBookNotiReactionRemoved, Resp)
#define ACTION_DISPATCH_FriendBookGetTimeline(Resp)			ACTION_DISPATCH_REF(FriendBookGetTimeline, FL2CFriendBookGetTimelineResp, Resp)
#define ACTION_DISPATCH_FriendBookAddReaction(ParamVal)		ACTION_DISPATCH_ONE(FriendBookAddReaction, FC2LFriendBookAddReaction, ParamVal)
#define ACTION_DISPATCH_FriendBookRemoveReaction(ParamVal)	ACTION_DISPATCH_ONE(FriendBookRemoveReaction, FC2LFriendBookRemoveReaction, ParamVal)
#define ACTION_DISPATCH_FriendBookGetFeed(Resp)				ACTION_DISPATCH_REF(FriendBookGetFeed, FL2CFriendBookGetFeedResp, Resp)

//// End of Packet
//////////////////////////////////////////////////////////////////////////////

// Cheat
#define ACTION_DISPATCH_DevAddCurrencyResp(Resp)				ACTION_DISPATCH_REF(DevAddCurrencyResp, FL2CDevAddCurrencyResp, Resp)
#define ACTION_DISPATCH_DevAddXpResp(Resp)						ACTION_DISPATCH_REF(DevAddXpResp, FL2CDevAddXpResp, Resp)
#define ACTION_DISPATCH_DevBondAddResp(Resp)					ACTION_DISPATCH_REF(DevBondAddResp, FL2CDevBondAddResp, Resp)
#define ACTION_DISPATCH_DevCharacterNewResp(Resp)				ACTION_DISPATCH_REF(DevCharacterNewResp, FL2CDevCharacterNewResp, Resp)
#define ACTION_DISPATCH_DevRelicNewResp(Resp)					ACTION_DISPATCH_REF(DevRelicNewResp, FL2CDevRelicNewResp, Resp)
#define ACTION_DISPATCH_DevSculptureNewResp(Resp)				ACTION_DISPATCH_REF(DevSculptureNewResp, FL2CDevSculptureNewResp, Resp)
#define ACTION_DISPATCH_DevSpecialClearResp(Resp) 				ACTION_DISPATCH_REF(DevSpecialClearResp, FL2CDevSpecialClearResp, Resp)
#define ACTION_DISPATCH_DevSpecialOpenResp(Resp)				ACTION_DISPATCH_REF(DevSpecialOpenResp, FL2CDevSpecialOpenResp, Resp)
#define ACTION_DISPATCH_DevStageClearResp(Resp)					ACTION_DISPATCH_REF(DevStageClearResp, FL2CDevStageClearResp, Resp)
#define ACTION_DISPATCH_DevWattRechargeResp(Resp)				ACTION_DISPATCH_REF(DevWattRechargeResp, FL2CDevWattRechargeResp, Resp)
#define ACTION_DISPATCH_DevWattConsumeResp(Resp)				ACTION_DISPATCH_REF(DevWattConsumeResp, FL2CDevWattConsumeResp, Resp)
#define ACTION_DISPATCH_DevTrainingCenterClearResp(Resp)		ACTION_DISPATCH_REF(DevTrainingCenterClearResp, FL2CDevTrainingCenterClearResp, Resp)
#define ACTION_DISPATCH_DevTrainingCenterResetResp(Resp)		ACTION_DISPATCH_REF(DevTrainingCenterResetResp, FL2CDevTrainingCenterResetResp, Resp)
#define ACTION_DISPATCH_DevPyramidOpenResp(Resp)				ACTION_DISPATCH_REF(DevPyramidOpenResp, FL2CDevPyramidOpenResp, Resp)
#define ACTION_DISPATCH_DevPyramidUpgradeResp(Resp)				ACTION_DISPATCH_REF(DevPyramidUpgradeResp, FL2CDevPyramidUpgradeResp, Resp)
#define ACTION_DISPATCH_DevPyramidPortalBoostUseResp(Resp)		ACTION_DISPATCH_REF(DevPyramidPortalBoostUseResp, FL2CDevPortalBoostUseResp, Resp)
#define ACTION_DISPATCH_DevPyramidPortalClearResp(Resp)			ACTION_DISPATCH_REF(DevPyramidPortalClearResp, FL2CDevPortalClearResp, Resp)
#define ACTION_DISPATCH_DevTempleOpenResp(Resp)					ACTION_DISPATCH_REF(DevTempleOpenResp, FL2CDevTempleOpenResp, Resp)
#define ACTION_DISPATCH_DevTempleUpgradeResp(Resp)				ACTION_DISPATCH_REF(DevTempleUpgradeResp, FL2CDevTempleUpgradeResp, Resp)
#define ACTION_DISPATCH_DevTempleProduceResp(Resp)				ACTION_DISPATCH_REF(DevTempleProduceResp, FL2CDevTempleProduceResp, Resp)
#define ACTION_DISPATCH_DevTempleArtifactsResetResp(Resp)		ACTION_DISPATCH_REF(DevTempleArtifactsResetResp, FL2CDevTempleArtifactsResetResp, Resp)
#define ACTION_DISPATCH_DevTempleArtifactUpgradeResp(Resp)		ACTION_DISPATCH_REF(DevTempleArtifactUpgradeResp, FL2CDevTempleArtifactUpgradeResp, Resp)
#define ACTION_DISPATCH_DevPowerPlantOpenResp(Resp)				ACTION_DISPATCH_REF(DevPowerPlantOpenResp, FL2CDevPowerPlantOpenResp, Resp)
#define ACTION_DISPATCH_DevPetParkOpenResp(Resp)				ACTION_DISPATCH_REF(DevPetParkOpenResp, FL2CDevPetParkOpenResp, Resp)
#define ACTION_DISPATCH_DevPetParkUpgradeResp(Resp)				ACTION_DISPATCH_REF(DevPetParkUpgradeResp, FL2CDevPetParkUpgradeResp, Resp)
#define ACTION_DISPATCH_DevPetParkProduceResp(Resp)				ACTION_DISPATCH_REF(DevPetParkProduceResp, FL2CDevPetParkProduceResp, Resp)
#define ACTION_DISPATCH_DevPetSkillUpgradeResp(Resp)			ACTION_DISPATCH_REF(DevPetSkillUpgradeResp, FL2CDevPetSkillUpgradeResp, Resp)
#define ACTION_DISPATCH_DevPetNewResp(Resp)						ACTION_DISPATCH_REF(DevPetNewResp, FL2CDevPetNewResp, Resp)
#define ACTION_DISPATCH_DevVacationOpenResp(Resp)				ACTION_DISPATCH_REF(DevVacationOpenResp, FL2CDevVacationOpenResp, Resp)
#define ACTION_DISPATCH_DevCheckInLoadResp(Resp)				ACTION_DISPATCH_REF(DevCheckInLoadResp, FL2CDevCheckInLoadResp, Resp)
#define ACTION_DISPATCH_DevShopResetResp(Resp)					ACTION_DISPATCH_REF(DevShopResetResp, FL2CDevShopResetResp, Resp)
#define ACTION_DISPATCH_DevSummonMileageSetResp(Resp)			ACTION_DISPATCH_REF(DevSummonMileageSetResp, FL2CDevSummonMileageSetResp, Resp)
#define ACTION_DISPATCH_DevLobbyTemplateNewResp(Resp)			ACTION_DISPATCH_REF(DevLobbyTemplateNewResp, FL2CDevLobbyTemplateNewResp, Resp)
#define ACTION_DISPATCH_DevFriendBotAllResp(Resp)				ACTION_DISPATCH_REF(DevFriendBotAllResp, FL2CDevFriendBotAllResp, Resp)
#define ACTION_DISPATCH_DevFriendCooltimeResp(Resp)				ACTION_DISPATCH_REF(DevFriendCooltimeResp, FL2CDevFriendCooltimeResp, Resp)
#define ACTION_DISPATCH_DevCharMissionSetResp(Resp)				ACTION_DISPATCH_REF(DevCharMissionSetResp, FL2CDevCharMissionSetResp, Resp)
#define ACTION_DISPATCH_DevContentFeatureOpenResp(Resp)			ACTION_DISPATCH_REF(DevContentFeatureOpenResp, FL2CDevContentFeatureOpenResp, Resp)
#define ACTION_DISPATCH_DevEventContentNumberOfDaysResp(Resp)	ACTION_DISPATCH_REF(DevEventContentNumberOfDaysResp, FL2CDevEventContentNumberOfDaysResp, Resp)
#define ACTION_DISPATCH_DevEventContentAddPointResp(Resp)		ACTION_DISPATCH_REF(DevEventContentAddPointResp, FL2CDevEventContentAddPointResp, Resp)
#define ACTION_DISPATCH_DevEventContentRechargeWAttResp(Resp)	ACTION_DISPATCH_REF(DevEventContentRechargeWattResp, FL2CDevEventContentRechargeWattResp, Resp)
#define ACTION_DISPATCH_DevEventContentRouletteResetResp(Resp)	ACTION_DISPATCH_REF(DevEventContentRouletteResetResp, FL2CDevEventContentRouletteResetResp, Resp)
#define ACTION_DISPATCH_DevSmelterOpenResp(Resp)				ACTION_DISPATCH_REF(DevSmelterOpenResp, FL2CDevSmelterOpenResp, Resp)
#define ACTION_DISPATCH_DevSmelterUpgradeResp(Resp)				ACTION_DISPATCH_REF(DevSmelterUpgradeResp, FL2CDevSmelterUpgradeResp, Resp)
#define ACTION_DISPATCH_DevSmelterTimeResp(Resp)				ACTION_DISPATCH_REF(DevSmelterTimeResp, FL2CDevSmelterTimeResp, Resp)
#define ACTION_DISPATCH_DevAlchemylabOpenResp(Resp)				ACTION_DISPATCH_REF(DevAlchemylabOpenResp, FL2CDevAlchemylabOpenResp, Resp)
#define ACTION_DISPATCH_DevAlchemylabUpgradeResp(Resp)			ACTION_DISPATCH_REF(DevAlchemylabUpgradeResp, FL2CDevAlchemylabUpgradeResp, Resp)
#define ACTION_DISPATCH_DevAlchemylabTimeResp(Resp)				ACTION_DISPATCH_REF(DevAlchemylabTimeResp, FL2CDevAlchemylabTimeResp, Resp)
#define ACTION_DISPATCH_DevClockModResp(Resp)					ACTION_DISPATCH_REF(DevClockModResp, FL2CDevClockModResp, Resp)
#define ACTION_DISPATCH_DevAvatarAddResp(Resp)					ACTION_DISPATCH_REF(DevAvatarAddResp, FL2CDevAvatarAddResp, Resp)
//////////////////////////////////////////////////////////////////////////////
//// UI

// Menu
#define ACTION_DISPATCH_MenuBack()								ACTION_DISPATCH(MenuBack)
#define ACTION_DISPATCH_MenuDoubleBack()						ACTION_DISPATCH(MenuDoubleBack)
#define ACTION_DISPATCH_MenuChange(ParamVal, ParamVal2)			ACTION_DISPATCH_TWO(MenuChange, EHUDWidgetType, ParamVal, bool, ParamVal2)

// Upgrade
#define ACTION_DISPATCH_UpgradeMenu(ParamVal)					ACTION_DISPATCH_ONE(UpgradeMenu, FUpgradeUIState, ParamVal)
#define ACTION_DISPATCH_UpgradeInventory(ParamVal)				ACTION_DISPATCH_ONE(UpgradeInventory, EUpgradeCategory, ParamVal)
#define ACTION_DISPATCH_UpgradeCategory(ParamVal)				ACTION_DISPATCH_ONE(UpgradeCategory, int32, ParamVal)
#define ACTION_DISPATCH_UpgradeItem(ParamVal)					ACTION_DISPATCH_ONE(UpgradeItem, int64, ParamVal)

// Friend
#define ACTION_DISPATCH_FriendCategoryChange(ParamVal)					ACTION_DISPATCH_ONE(FriendCategoryChange, EFriendCategory, ParamVal)
#define ACTION_DISPATCH_FriendJokerSetView()							ACTION_DISPATCH(FriendJokerSetView)
#define ACTION_DISPATCH_FriendReorder(ParamVal, ParamVal2)				ACTION_DISPATCH_TWO(FriendReorder, ESortCategory, ParamVal, ESortDirection, ParamVal2)
#define ACTION_DISPATCH_FriendBookFilterChange(ParamVal)				ACTION_DISPATCH_ONE(FriendBookFilterChange, EFriendBookFilter, ParamVal)
#define ACTION_DISPATCH_FriendBookReadTimeline()						ACTION_DISPATCH(FriendBookReadTimeline)
#define ACTION_DISPATCH_FriendBookNewFeedsFromFile(ParamVal, ParamVal2)	ACTION_DISPATCH_TWO(FriendBookNewFeedsFromFile, FFriendBookFeedId, ParamVal, FFriendBookFeedId, ParamVal2)


// Party
#define ACTION_DISPATCH_PartyChange(ParamVal)					ACTION_DISPATCH_ONE(PartyChange, int32, ParamVal)
#define ACTION_DISPATCH_PartyMain(ParamVal)						ACTION_DISPATCH_ONE(PartyMain, FSagaType, ParamVal)
#define ACTION_DISPATCH_PartyEdit(ParamVal, ParamVal2)			ACTION_DISPATCH_TWO(PartyEdit, EPartyIconItemType, ParamVal, int32, ParamVal2)
#define ACTION_DISPATCH_PartyPetEdit()							ACTION_DISPATCH(PartyPetEdit);
#define ACTION_DISPATCH_PartyEventContentType(ParamVal)			ACTION_DISPATCH_ONE(PartyEventContentType, FEventContentType, ParamVal)

// JokerSet
#define ACTION_DISPATCH_JokerSetMain(ParamVal)					ACTION_DISPATCH_ONE(JokerSetMain, int32, ParamVal)
#define ACTION_DISPATCH_JokerSetChange(ParamVal)				ACTION_DISPATCH_ONE(JokerSetChange, int32, ParamVal)
#define ACTION_DISPATCH_JokerSetEdit(ParamVal, ParamVal2)		ACTION_DISPATCH_TWO(JokerSetEdit, EPartyIconItemType, ParamVal, int32, ParamVal2)

// JokerSelect
#define ACTION_DISPATCH_JokerSelect(ParamVal, ParamVal2)		ACTION_DISPATCH_TWO(JokerSelect, FSagaType, ParamVal, bool, ParamVal2)
#define ACTION_DISPATCH_JokerSetView()							ACTION_DISPATCH(JokerSetView)

// Saga
#define ACTION_DISPATCH_SagaStageList(ParamVal)					ACTION_DISPATCH_ONE(SagaStageList, int32, ParamVal)

// Special
#define ACTION_DISPATCH_SpecialOpen(ParamVal)					ACTION_DISPATCH_ONE(SpecialOpen, FSpecialUIState, ParamVal)
#define ACTION_DISPATCH_SpecialEpisodeList(ParamVal)			ACTION_DISPATCH_ONE(SpecialEpisodeList, ESpecialCategory, ParamVal)
#define ACTION_DISPATCH_SpecialCharacterStageList(ParamVal)		ACTION_DISPATCH_ONE(SpecialCharacterStageList, FSpecialType, ParamVal)
#define ACTION_DISPATCH_SpecialSagaStageList()					ACTION_DISPATCH(SpecialSagaStageList)
#define ACTION_DISPATCH_SpecialWonderStageList(ParamVal)		ACTION_DISPATCH_ONE(SpecialWonderStageList, EWonderCategory, ParamVal)

// DailyDungeon
#define ACTION_DISPATCH_DailyDungeonStageList(ParamVal)			ACTION_DISPATCH_ONE(DailyDungeonStageList, EDailyDungeonCategory, ParamVal)
#define ACTION_DISPATCH_DailyDungeonPageChange(ParamVal)		ACTION_DISPATCH_ONE(DailyDungeonPageChange, EDailyDungeonMenuType, ParamVal)

// TrainingCenter
#define ACTION_DISPATCH_TrainingCenterOpen()					ACTION_DISPATCH(TrainingCenterOpen)

// Summon
#define ACTION_DISPATCH_SummonPageChange(ParamVal)				ACTION_DISPATCH_ONE(SummonPageChange, int32, ParamVal)
#define ACTION_DISPATCH_SummonFriendShip()						ACTION_DISPATCH(SummonFriendShip)

// InitialRewardEvent
#define ACTION_DISPATCH_InitialRewardEventOpen(ParamVal)		ACTION_DISPATCH_ONE(InitialRewardEventOpen, FInitialRewardEventUIState, ParamVal)

// Wonder
#define ACTION_DISPATCH_WonderMenu(ParamVal, ParamVal2)			ACTION_DISPATCH_TWO(WonderMenu, EWonderCategory, ParamVal, int32, ParamVal2)
#define ACTION_DISPATCH_WonderSlotSelect(ParamVal)				ACTION_DISPATCH_ONE(WonderSlotSelect, int32, ParamVal)

// Raid
#define ACTION_DISPATCH_RaidOpen()								ACTION_DISPATCH(RaidOpen)
#define ACTION_DISPATCH_UpdateRaidWhenEnterMenu()				ACTION_DISPATCH(UpdateRaidWhenEnterMenu)
#define ACTION_DISPATCH_RaidPrepareTime()						ACTION_DISPATCH(RaidPrepareTime)
#define ACTION_DISPATCH_SetOnGoingRaid(ParamVal, ParamVal2)		ACTION_DISPATCH_TWO(SetOnGoingRaid, FRaidType, ParamVal, FRaidId, ParamVal2)
#define ACTION_DISPATCH_RaidClearData()							ACTION_DISPATCH(RaidClearData)
#define ACTION_DISPATCH_MuteRaidJoinPopup()						ACTION_DISPATCH(MuteRaidJoinPopup)
#define ACTION_DISPATCH_SelectFinal(ParamVal, ParamVal2)		ACTION_DISPATCH_TWO(RaidSelectFinal, FRaidType, ParamVal, FRaidId, ParamVal2)
#define ACTION_DISPATCH_RaidClearFoundType()					ACTION_DISPATCH(RaidClearFoundType)
#define ACTION_DISPATCH_RaidClearSkills()						ACTION_DISPATCH(RaidClearSkills)
#define ACTION_DISPATCH_RaidCharInfos(ParamVal)					ACTION_DISPATCH_REF(RaidCharInfos, TArray<FRaidUserCharacterInfo>, ParamVal)
#define ACTION_DISPATCH_RaidSetSkills(ParamVal, ParamVal2)		ACTION_DISPATCH_TWO_REF(RaidSetSkills, TArray<FCCRaidSkillState>, ParamVal, TArray<FCCUsedCharSkillInfo>, ParamVal2)

// Inventory
#define ACTION_DISPATCH_InventoryOpen(ParamVal)					ACTION_DISPATCH_ONE(InventoryOpen, EInventoryCategory, ParamVal)
#define ACTION_DISPATCH_InventoryChange(ParamVal)				ACTION_DISPATCH_ONE(InventoryChange, EInventoryType, ParamVal)
#define ACTION_DISPATCH_InventoryEdit(ParamVal)					ACTION_DISPATCH_ONE(InventoryEdit, EInventoryEdit, ParamVal)

// Mail
#define ACTION_DISPATCH_MailSelect()							ACTION_DISPATCH(MailSelect)

// CheckIn
#define ACTION_DISPATCH_CheckInClear()							ACTION_DISPATCH(CheckInClear)

// Codex
#define ACTION_DISPATCH_CodexCategoryChange(ParamVal)			ACTION_DISPATCH_ONE(CodexCategoryChange, ECodexCategory, ParamVal)
#define ACTION_DISPATCH_CodexClearCharNew(ParamVal)				ACTION_DISPATCH_ONE(CodexClearCharNew, FCharacterType, ParamVal)
#define ACTION_DISPATCH_CodexClearSculptureNew(ParamVal)		ACTION_DISPATCH_ONE(CodexClearSculptureNew, FSculptureType, ParamVal)
#define ACTION_DISPATCH_CodexClearRelicNew(ParamVal)			ACTION_DISPATCH_ONE(CodexClearRelicNew, FRelicType, ParamVal)
#define ACTION_DISPATCH_CodexEquipFullView(ParamVal)			ACTION_DISPATCH_ONE(CodexEquipFullView, bool, ParamVal)

// WeeklyMission
#define ACTION_DISPATCH_WeeklyMissionToast()					ACTION_DISPATCH(WeeklyMissionToast)

// UserRecord
#define ACTION_DISPATCH_UserRecordRows()						ACTION_DISPATCH(UserRecordRows)

// Sort
#define ACTION_DISPATCH_SortingInit()							ACTION_DISPATCH(SortingInit)
#define ACTION_DISPATCH_SortingChange(ParamVal)					ACTION_DISPATCH_ONE(SortingChange, FSortingOption, ParamVal)

// Shop
#define ACTION_DISPATCH_ShopMenuChange(ParamVal1, ParamVal2)	ACTION_DISPATCH_TWO(ShopMenuChange, EShopMenu, ParamVal1, bool, ParamVal2)

// LobbySetting
#define ACTION_DISPATCH_LobbySettingEditChange(ParamVal)		ACTION_DISPATCH_ONE(LobbySettingEditChange, ELobbySettingEditType, ParamVal)

// Bag
#define ACTION_DISPATCH_BagItemSort()							ACTION_DISPATCH(BagItemSort)

// Event
#define ACTION_DISPATCH_EventMenuChange(ParamVal1, ParamVal2)	ACTION_DISPATCH_TWO(EventMenuChange, EEventMenu, ParamVal1, FEventContentType, ParamVal2)

// Multiside
#define ACTION_DISPATCH_MultisidePetSave(ParamVal)				ACTION_DISPATCH_ONE(MultisidePetSave, FPetId, ParamVal)
#define ACTION_DISPATCH_MultisidePartySave()					ACTION_DISPATCH(MultisidePartySave)

// Story
#define ACTION_DISPATCH_StoryList(ParamVal)						ACTION_DISPATCH_ONE(StoryList, EStoryMenuCategory, ParamVal)

//// End of UI
//////////////////////////////////////////////////////////////////////////////
