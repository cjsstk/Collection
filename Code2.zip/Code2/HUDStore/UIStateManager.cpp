#include "UIStateManager.h"

#include "GameResource.h"
#include "HUDStore/Q6Account.h"
#include "HUDStore/JokerSetManager.h"
#include "HUDStore/SagaManager.h"
#include "JsonObjectConverter.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "Q6.h"
#include "Resource/GameResource.h"

static const FLobbyUIState DefaultMainUIState;
static const FLobbySettingUIState DefaultLobbySettingUIState;
static const FInventoryUIState DefaultInventoryUIState;
static const FJokerSelectUIState DefaultJokerSelectUIState;
static const FFriendUIState DefaultFriendUIState;
static const FPartyUIState DefaultPartyUIState;
static const FUpgradeUIState DefaultUpgradeUIState;
static const FDialogueUIState DefaultDialogueUIState;
static const FSagaUIState DefaultSagaUIState;
static const FSpecialUIState DefaultSpecialStageUIState;
static const FDailyDungeonUIState DefaultDailyDungeonUIState;
static const FTrainingCenterUIState DefaultTrainingCenterUIState;
static const FSummonUIState DefaultSummonUIState;
static const FInitialRewardEventUIState DefaultInitialRewardEventUIState;
static const FWonderUIState DefaultWonderUIState;
static const FRaidUIState DefaultRaidUIState;
static const FBondUpResultUIState DefaultBondUpResultUIState;
static const FCodexUIState DefaultCodexUIState;
static const FWeeklyMissionUIState DefaultWeeklyMissionUIState;
static const FShopUIState DefaultShopUIState;
static const FBagUIState DefaultBagUIState;
static const FEventUIState DefaultEventUIState;
static const FAccountUIState DefaultAccountUIState;
static const FStoryUIState DefaultStoryUIState;

///////////////////////////////////////////////////////////////////////////////////////////
// UUIStateManager

UUIStateManager::UUIStateManager()
	: CurrentUIState(nullptr)
{
	InitStore(EHSType::Ui);

	SortingSelectedOptions.Reset();
	bSortingChanged = false;
}

UUIStateManager::~UUIStateManager()
{
	for (FLobbyUIState* UIState : Histories)
	{
		delete UIState;
	}

	if (CurrentUIState)
	{
		delete CurrentUIState;
	}
}

bool UUIStateManager::GotoBackMenu()
{
	if (CurrentUIState && CurrentUIState->GotoBackState())
	{
		DumpHistory("GotoBackMenu");
		return true;
	}

	return false;
}

bool UUIStateManager::LoadSortingFile()
{
	FString FilePath = GetSortingFilePath();
	FString SortingJsonStr;
	if (!FFileHelper::LoadFileToString(SortingJsonStr, *FilePath))
	{
		return false;
	}

	TSharedPtr<FJsonObject> JsonSorting;
	TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(SortingJsonStr);
	if (!FJsonSerializer::Deserialize(JsonReader, JsonSorting))
	{
		return false;
	}

	const TArray<TSharedPtr<FJsonValue>>* JsonObjects = nullptr;
	if (!JsonSorting->TryGetArrayField(TEXT("SortingOptions"), JsonObjects))
	{
		return false;
	}

	TArray<FSortingOption> LoadedSortingOptions;
	for (const auto& Elem : *JsonObjects)
	{
		const TSharedPtr<FJsonObject>& JsonObject = Elem->AsObject();
		const TSharedPtr<FJsonObject>& JsonStructObject = JsonObject->GetObjectField(TEXT("Option"));

		FSortingOption SortingInfo;
		if (!FJsonObjectConverter::JsonObjectToUStruct(JsonStructObject.ToSharedRef(), FSortingOption::StaticStruct(), &SortingInfo))
		{
			return false;
		}

		LoadedSortingOptions.Add(SortingInfo);
	}

	SortingSelectedOptions = LoadedSortingOptions;
	return true;
}

void UUIStateManager::SaveSortingFile()
{
	FString FileJsonStr;
	TSharedRef<TJsonWriter<TCHAR>> JsonWriter = TJsonWriterFactory<TCHAR>::Create(&FileJsonStr);
	
	JsonWriter->WriteObjectStart();
	JsonWriter->WriteArrayStart(TEXT("SortingOptions"));
	for (const FSortingOption& SortingOption : SortingSelectedOptions)
	{
		FString SortingJsonStr;
		FJsonObjectConverter::UStructToJsonObjectString(FSortingOption::StaticStruct(), &SortingOption, SortingJsonStr, 0, 0);

		JsonWriter->WriteObjectStart();
		JsonWriter->WriteRawJSONValue(TEXT("Option"), SortingJsonStr);
		JsonWriter->WriteObjectEnd();
	}
	JsonWriter->WriteArrayEnd();
	JsonWriter->WriteObjectEnd();
	JsonWriter->Close();

	FString FilePath = GetSortingFilePath();
	if (!FFileHelper::SaveStringToFile(FileJsonStr, *FilePath))
	{
		Q6JsonLogRoze(Error, "Failed to save output file", Q6KV("FilePath", *FilePath));
	}
}


bool UUIStateManager::IsChangedSortingOption(const FSortingOption& NewSortingOption) const
{
	const FSortingOption& OldSortingOption = GetSortingOption(NewSortingOption.SortMenu, NewSortingOption.Category);
	if (OldSortingOption.OrderType != NewSortingOption.OrderType)
	{
		return true;
	}

	if (OldSortingOption.bXpCardFilter != NewSortingOption.bXpCardFilter)
	{
		return true;
	}

	if (OldSortingOption.FilterOptions.Num() != NewSortingOption.FilterOptions.Num())
	{
		return true;
	}

	for (int32 i = 0; i < OldSortingOption.FilterOptions.Num(); ++i)
	{
		if (OldSortingOption.FilterOptions[i] != NewSortingOption.FilterOptions[i])
		{
			return true;
		}
	}

	return false;
}

FString UUIStateManager::GetSortingFilePath()
{
	bool bIsLogin = UQ6GameInstance::Get(this)->IsLogin();
	if (bIsLogin)
	{
		const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
		return FPaths::ProjectSavedDir() / WorldUser.GetUserCode() + "_Sorting.json";
	}
	else
	{
		return FPaths::ProjectSavedDir() / "OfflineUser_Sorting.json";
	}

	return FPaths::ProjectSavedDir() / "Sorting.json";
}

const FInventoryUIState& UUIStateManager::GetInventoryUIState() const
{
	if (const FInventoryUIState* UIState = CurrentUIState->CastToInventoryUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetInventoryUIState - Not in inventory menu now");
	return DefaultInventoryUIState;
}

const FJokerSelectUIState& UUIStateManager::GetJokerSelectUIState() const
{
	if (const FJokerSelectUIState* UIState = CurrentUIState->CastToJokerSelectUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetJokerSelectUIState - Not in joker select menu now");
	return DefaultJokerSelectUIState;
}

const FFriendUIState& UUIStateManager::GetFriendUIState() const
{
	if (const FFriendUIState* UIState = CurrentUIState->CastToFriendUIState())
	{
		return *UIState;
	}

	Q6JsonLogZagal(Warning, "UUIStateManager::GetFriendUIState - Not in friend menu now");
	return DefaultFriendUIState;
}

const FPartyUIState& UUIStateManager::GetPartyUIState() const
{
	if (const FPartyUIState* UIState = CurrentUIState->CastToPartyUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetPartyUIState - Not in party menu now");
	return DefaultPartyUIState;
}

const FUpgradeUIState& UUIStateManager::GetUpgradeUIState() const
{
	if (const FUpgradeUIState* UIState = CurrentUIState->CastToUpgradeUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetUpgradeUIState - Not in upgrade menu now");
	return DefaultUpgradeUIState;
}

const FDialogueUIState& UUIStateManager::GetDialogueUIState() const
{
	if (const FDialogueUIState* UIState = CurrentUIState->CastToDialogueUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetDialogueUIState - Not in dialogue menu now");
	return DefaultDialogueUIState;
}

const FSagaUIState& UUIStateManager::GetSagaUIState() const
{
	if (const FSagaUIState* UIState = CurrentUIState->CastToSagaUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetSagaUIState - Not in saga menu now");
	return DefaultSagaUIState;
}

const FSpecialUIState& UUIStateManager::GetSpecialStageUIState() const
{
	if (const FSpecialUIState* UIState = CurrentUIState->CastToSpecialUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetSpecialStageUIState - Not in special stage menu now");
	return DefaultSpecialStageUIState;
}

const FSummonUIState& UUIStateManager::GetSummonUIState() const
{
	if (const FSummonUIState* UIState = CurrentUIState->CastToSummonUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetSummonUIState - Not in summon menu now");
	return DefaultSummonUIState;
}

const FDailyDungeonUIState& UUIStateManager::GetDailyDungeonUIState() const
{
	if (const FDailyDungeonUIState* UIState = CurrentUIState->CastToDailyDungeonUIState())
	{
		return *UIState;
	}

	Q6JsonLogGunny(Warning, "UUIStateManager::GetDailyDungeonUIState - No DailyDungeon now");
	return DefaultDailyDungeonUIState;
}

const FTrainingCenterUIState& UUIStateManager::GetTrainingCenterUIState() const
{
	if (const FTrainingCenterUIState* UIState = CurrentUIState->CastToTrainingCenterUIState())
	{
		return *UIState;
	}

	Q6JsonLogGunny(Warning, "UUIStateManager::GetTrainingCenterUIState - No TrainingCenter now");
	return DefaultTrainingCenterUIState;
}

const FWonderUIState& UUIStateManager::GetWonderUIState() const
{
	if (const FWonderUIState* UIState = CurrentUIState->CastToWonderUIState())
	{
		return *UIState;
	}

	Q6JsonLogGunny(Warning, "UUIStateManager::GetWonderUIState - No Wonder now");
	return DefaultWonderUIState;
}

const FRaidUIState& UUIStateManager::GetRaidUIState() const
{
	if (const FRaidUIState* UIState = CurrentUIState->CastToRaidUIState())
	{
		return *UIState;
	}

	Q6JsonLogGenie(Warning, "UUIStateManager::GetRaidUIState - No Raid now");
	return DefaultRaidUIState;
}

const FBondUpResultUIState& UUIStateManager::GetBondUpResultUIState() const
{
	if (const FBondUpResultUIState* UIState = CurrentUIState->CastToBondUpResultUIState())
	{
		return *UIState;
	}

	Q6JsonLogGunny(Warning, "UUIStateManager::GetBondUpResultUIState - No BondReward now");
	return DefaultBondUpResultUIState;
}

const FCodexUIState& UUIStateManager::GetCodexUIState() const
{
	if (const FCodexUIState* UIState = CurrentUIState->CastToCodexUIState())
	{
		return *UIState;
	}

	Q6JsonLogGenie(Warning, "UUIStateManager::GetCodexUIState - No Codex now");
	return DefaultCodexUIState;
}

const FWeeklyMissionUIState& UUIStateManager::GetWeeklyMissionUIState() const
{
	if (const FWeeklyMissionUIState* UIState = CurrentUIState->CastToWeeklyMissionUIState())
	{
		return *UIState;
	}

	Q6JsonLogGenie(Warning, "UUIStateManager::GetWeeklyMissionUIState - No WeeklyMission now");
	return DefaultWeeklyMissionUIState;
}

const FShopUIState& UUIStateManager::GetShopUIState() const
{
	if (const FShopUIState* UIState = CurrentUIState->CastToShopUIState())
	{
		return *UIState;
	}

	Q6JsonLogGunny(Warning, "UUIStateManager::GetShopUIState - No Shop now");
	return DefaultShopUIState;
}

const FLobbySettingUIState& UUIStateManager::GetLobbySettingUIState() const
{
	if (const FLobbySettingUIState* UIState = CurrentUIState->CastToLobbySettingUIState())
	{
		return *UIState;
	}

	Q6JsonLogSunny(Warning, "UUIStateManager::GetLobbySettingUIState - No LobbySetting now");
	return DefaultLobbySettingUIState;
}

const FBagUIState& UUIStateManager::GetBagUIState() const
{
	if (const FBagUIState* UIState = CurrentUIState->CastToBagUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetBagUIState - No Bag now");
	return DefaultBagUIState;
}

const FEventUIState& UUIStateManager::GetEventUIState() const
{
	if (const FEventUIState* UIState = CurrentUIState->CastToEventUIState())
	{
		return *UIState;
	}

	Q6JsonLogGunny(Warning, "UUIStateManager::GetEventUIState - No Event now");
	return DefaultEventUIState;
}

const FAccountUIState& UUIStateManager::GetAccountUIState() const
{
	if (const FAccountUIState* UIState = CurrentUIState->CastToAccountUIState())
	{
		return *UIState;
	}

	Q6JsonLogRoze(Warning, "UUIStateManager::GetAccountUIState - No account now");
	return DefaultAccountUIState;
}

const FStoryUIState& UUIStateManager::GetStoryUIState() const
{
	if (const FStoryUIState* UIState = CurrentUIState->CastToStoryUIState())
	{
		return *UIState;
	}

	Q6JsonLogZagal(Warning, "UUIStateManager::GetStoryUIState - No account now");
	return DefaultStoryUIState;
}

EHUDWidgetType UUIStateManager::GetRootHUDWidgetType() const
{
	if (Histories.IsValidIndex(0))
	{
		return Histories[0]->GetHUDWidgetType();
	}

	if (CurrentUIState)
	{
		return CurrentUIState->GetHUDWidgetType();
	}

	return EHUDWidgetType::Main;
}

const FSortingOption& UUIStateManager::GetSortingOption(ESortMenu SortMenu, ESortCategory Category) const
{
	for (const FSortingOption& SortOption : SortingSelectedOptions)
	{
		if (SortOption.Category != Category)
		{
			continue;
		}

		if (SortOption.SortMenu != SortMenu)
		{
			continue;
		}

		return SortOption;
	}

	return GetUIResource().GetDefaultSortingSelectedOption(SortMenu, Category);
}

void UUIStateManager::ClearHistory()
{
	for (FLobbyUIState* UIState : Histories)
	{
		delete UIState;
	}

	Histories.Empty();

	// Change menu to main
	if (CurrentUIState)
	{
		delete CurrentUIState;
	}

	CurrentUIState = new FLobbyUIState(DefaultMainUIState);

	DumpHistory(TEXT("Clear"));
}

void UUIStateManager::DumpHistory(const FString& Caller)
{
	if (!CurrentUIState)
	{
		return;
	}

	Q6JsonLogZagal(Warning, "History", Q6KV("Call", *Caller), Q6KV("Num", Histories.Num()));

	for (int32 i = 0; i < Histories.Num(); i++)
	{
		const FLobbyUIState* State = Histories[i];

		if (State == CurrentUIState)
		{
			Q6JsonLogZagal(Warning, "Curr", Q6KV("State", State->ToString()));
		}
		else
		{
			Q6JsonLogZagal(Warning, "Keep", Q6KV("State", State->ToString()));
		}
	}

	if (Histories.Find(CurrentUIState) == INDEX_NONE)
	{
		Q6JsonLogZagal(Warning, "Curr", Q6KV("State", CurrentUIState->ToString()));
	}
}

void UUIStateManager::GotoBack()
{
	if (GotoBackMenu())
	{
		// Changed state. It's over.
		return;
	}

	if (Histories.Num() <= 0)
	{
		ChangeMenu(DefaultMainUIState, false);
		return;
	}

	// change state and remove last history

	if (CurrentUIState)
	{
		delete CurrentUIState;
	}

	CurrentUIState = Histories.Pop();
	DumpHistory(TEXT("GotoBack"));
}

void UUIStateManager::SetWonderUpgrade(EWonderCategory Category, int32 Level)
{
	FWonderUIState WonderUIState = GetWonderUIState();
	if (WonderUIState.Category == Category)
	{
		WonderUIState.Level = Level;
		ChangeMenu(WonderUIState, false);
	}
	else if (WonderUIState.Category == EWonderCategory::Main)
	{
		WonderUIState.SelectedSlot = (int32)Category;
		ChangeMenu(WonderUIState, false);
	}
}

// HUDStore Action
void UUIStateManager::RegisterActionHandlers()
{
	// Point
	REGISTER_ACTION_HANDLER(UUIStateManager, DevAddCurrencyResp);

	// Menu
	REGISTER_ACTION_HANDLER(UUIStateManager, MenuBack);
	REGISTER_ACTION_HANDLER(UUIStateManager, MenuDoubleBack);
	REGISTER_ACTION_HANDLER(UUIStateManager, MenuChange);

	// Upgrade
	REGISTER_ACTION_HANDLER(UUIStateManager, UpgradeMenu);
	REGISTER_ACTION_HANDLER(UUIStateManager, UpgradeInventory);
	REGISTER_ACTION_HANDLER(UUIStateManager, UpgradeCategory);
	REGISTER_ACTION_HANDLER(UUIStateManager, UpgradeItem);

	// Friend
	REGISTER_ACTION_HANDLER(UUIStateManager, FriendCategoryChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, FriendJokerSetView);
	REGISTER_ACTION_HANDLER(UUIStateManager, FriendBookFilterChange);

	// Party
	REGISTER_ACTION_HANDLER(UUIStateManager, PartyPetEdit);
	REGISTER_ACTION_HANDLER(UUIStateManager, PartyEdit);
	REGISTER_ACTION_HANDLER(UUIStateManager, PartyChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, PartyMain);
	REGISTER_ACTION_HANDLER(UUIStateManager, PartySaveResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, PartyEventContentType);

	// JokerSet
	REGISTER_ACTION_HANDLER(UUIStateManager, JokerSetEdit);
	REGISTER_ACTION_HANDLER(UUIStateManager, JokerSetChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, JokerSetMain);
	REGISTER_ACTION_HANDLER(UUIStateManager, JokerSetSaveResp);

	// JokerSelect
	REGISTER_ACTION_HANDLER(UUIStateManager, JokerSelect);
	REGISTER_ACTION_HANDLER(UUIStateManager, JokerSetView);
	REGISTER_ACTION_HANDLER(UUIStateManager, FriendJokerFromPopup);

	// Saga
	REGISTER_ACTION_HANDLER(UUIStateManager, SagaStageList);
	REGISTER_ACTION_HANDLER(UUIStateManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, SagaStoryStageClearResp);

	// Special
	REGISTER_ACTION_HANDLER(UUIStateManager, SpecialOpen);
	REGISTER_ACTION_HANDLER(UUIStateManager, SpecialEpisodeList);
	REGISTER_ACTION_HANDLER(UUIStateManager, SpecialCharacterStageList);
	REGISTER_ACTION_HANDLER(UUIStateManager, SpecialSagaStageList);
	REGISTER_ACTION_HANDLER(UUIStateManager, SpecialWonderStageList);

	// DailyDungeon
	REGISTER_ACTION_HANDLER(UUIStateManager, DailyDungeonStageList);
	REGISTER_ACTION_HANDLER(UUIStateManager, DailyDungeonPageChange);

	// TrainingCenter
	REGISTER_ACTION_HANDLER(UUIStateManager, TrainingCenterOpen);

	// Summon
	REGISTER_ACTION_HANDLER(UUIStateManager, SummonBoxScheduleResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, SummonPageChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, SummonFriendShip);

	// InitialRewardEvent
	REGISTER_ACTION_HANDLER(UUIStateManager, InitialRewardEventOpen);

	// Wonder
	REGISTER_ACTION_HANDLER(UUIStateManager, WonderMenu);
	REGISTER_ACTION_HANDLER(UUIStateManager, WonderSlotSelect);
	REGISTER_ACTION_HANDLER(UUIStateManager, PyramidUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, VacationUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, PowerPlantUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, PetParkUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, TempleUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, AlchemylabUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, SmelterUpgradeCompleteResp);

	// Raid
	REGISTER_ACTION_HANDLER(UUIStateManager, RaidOpen);

	// Inventory
	REGISTER_ACTION_HANDLER(UUIStateManager, InventoryOpen);
	REGISTER_ACTION_HANDLER(UUIStateManager, InventoryChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, InventoryEdit);
	REGISTER_ACTION_HANDLER(UUIStateManager, CharacterSetStashResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, RelicSetStashResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, SculptureSetStashResp);

	// Mail
	REGISTER_ACTION_HANDLER(UUIStateManager, MailSelect);

	// Codex
	REGISTER_ACTION_HANDLER(UUIStateManager, CodexCategoryChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, CodexEquipFullView);

	// Sorting
	REGISTER_ACTION_HANDLER(UUIStateManager, SortingInit);
	REGISTER_ACTION_HANDLER(UUIStateManager, SortingChange);

	// Shop
	REGISTER_ACTION_HANDLER(UUIStateManager, ShopMenuChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, ShopBuyItemResp);

	// LobbySetting
	REGISTER_ACTION_HANDLER(UUIStateManager, LobbySettingEditChange);

	// Event
	REGISTER_ACTION_HANDLER(UUIStateManager, EventMenuChange);
	REGISTER_ACTION_HANDLER(UUIStateManager, MultisidePetSave);
	REGISTER_ACTION_HANDLER(UUIStateManager, MultisidePartySave);

	// Story
	REGISTER_ACTION_HANDLER(UUIStateManager, StoryList);

	// Dev
	REGISTER_ACTION_HANDLER(UUIStateManager, DevPyramidPortalBoostUseResp);
	REGISTER_ACTION_HANDLER(UUIStateManager, DevPyramidUpgradeResp);
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, DevAddCurrencyResp)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, MenuBack)
{
	GotoBack();

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, MenuDoubleBack)
{
	GotoBack();
	GotoBack();

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, MenuChange)
{
	const auto& Action = ACTION_PARSE_MenuChange(InAction);
	EHUDWidgetType HUDWidgetType = Action->GetVal();
	bool bHistoryClear = Action->GetVal2();

	switch (HUDWidgetType)
	{
		case EHUDWidgetType::Main:
			ChangeMenu(DefaultMainUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::LobbySetting:
			ChangeMenu(DefaultLobbySettingUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::JokerSelect:
			ChangeMenu(DefaultJokerSelectUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Party:
		{
			UQ6SaveGame* SaveGame = GameInstance->GetSaveGame();

			FPartyUIState PartyUIState = DefaultPartyUIState;
			if (SaveGame && SaveGame->GetSavedPartySlot())
			{
				PartyUIState.PageNum = SaveGame->GetSavedPartySlot();
			}

			ChangeMenu(PartyUIState, !bHistoryClear, bHistoryClear);
			break;
		}
		case EHUDWidgetType::Joker:
			{
				FPartyUIState PartyUIState = DefaultPartyUIState;
				PartyUIState.WidgetType = EPartyWidgetType::JokerSet;
				PartyUIState.PageNum = GetHUDStore().GetJokerManager().GetSelectedId();
				ChangeMenu(PartyUIState, !bHistoryClear, bHistoryClear);
			}
			break;
		case EHUDWidgetType::Collection:
			ChangeMenu(DefaultInventoryUIState, false, true);
			break;
		case EHUDWidgetType::StorageBox:
			{
				FInventoryUIState InventoryUIState = DefaultInventoryUIState;
				InventoryUIState.Category = EInventoryCategory::StorageBox;

				ChangeMenu(InventoryUIState, false, true);
			}
			break;
		case EHUDWidgetType::Dialogue:
			ChangeMenu(DefaultDialogueUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::Upgrade:
			ChangeMenu(DefaultUpgradeUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Saga:
			ChangeMenu(DefaultSagaUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::Special:
			ChangeMenu(DefaultSpecialStageUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::DailyDungeon:
			ChangeMenu(DefaultDailyDungeonUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::TrainingCenter:
			ChangeMenu(DefaultTrainingCenterUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::Summon:
			ChangeMenu(DefaultSummonUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::InitialRewardEvent:
			ChangeMenu(DefaultInitialRewardEventUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Friend:
			ChangeMenu(DefaultFriendUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Wonder:
			ChangeMenu(DefaultWonderUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Raid:
			ChangeMenu(DefaultRaidUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::BondUpResult:
			ChangeMenu(DefaultBondUpResultUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::Codex:
			ChangeMenu(DefaultCodexUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Mission:
			ChangeMenu(DefaultWeeklyMissionUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Shop:
			ChangeMenu(DefaultShopUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Bag:
			ChangeMenu(DefaultBagUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Event:
			ChangeMenu(DefaultEventUIState, true, bHistoryClear);
			break;
		case EHUDWidgetType::Account:
			ChangeMenu(DefaultAccountUIState, false, bHistoryClear);
			break;
		case EHUDWidgetType::Story:
			ChangeMenu(DefaultStoryUIState, true, bHistoryClear);
			break;
	}

	return false;
}

// Upgrade
IMPLEMENT_ACTION_HANDLER(UUIStateManager, UpgradeMenu)
{
	const auto& Action = ACTION_PARSE_UpgradeMenu(InAction);

	ChangeMenu(Action->GetVal(), false, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, UpgradeInventory)
{
	const auto& Action = ACTION_PARSE_UpgradeInventory(InAction);

	FUpgradeUIState UpgradeUIState = GetUpgradeUIState();
	UpgradeUIState.UpgradeSequence = EUpgradeSequence::Inventory;
	UpgradeUIState.Category = Action->GetVal();
	UpgradeUIState.UpgradeMenuIndex = 0;	// Default select menu

	ChangeMenu(UpgradeUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, UpgradeCategory)
{
	const auto& Action = ACTION_PARSE_UpgradeCategory(InAction);

	FUpgradeUIState UpgradeUIState = GetUpgradeUIState();
	UpgradeUIState.UpgradeMenuIndex = Action->GetVal();

	ChangeMenu(UpgradeUIState, false);

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, UpgradeItem)
{
	const auto& Action = ACTION_PARSE_UpgradeItem(InAction);

	FUpgradeUIState UpgradeUIState = GetUpgradeUIState();
	UpgradeUIState.UpgradeSequence = EUpgradeSequence::Upgrade;
	UpgradeUIState.ItemId = Action->GetVal();

	ChangeMenu(UpgradeUIState, false);

	return true;
}

// Friend
IMPLEMENT_ACTION_HANDLER(UUIStateManager, FriendCategoryChange)
{
	const auto& Action = ACTION_PARSE_FriendCategoryChange(InAction);

	FFriendUIState FriendUIState = GetFriendUIState();
	FriendUIState.FriendCategory = Action->GetVal();

	ChangeMenu(FriendUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, FriendJokerSetView)
{
	FFriendUIState FriendUIState = GetFriendUIState();
	FriendUIState.FriendMenu = EFriendMenu::JokerSetView;

	ChangeMenu(FriendUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, FriendBookFilterChange)
{
	const auto& Action = ACTION_PARSE_FriendBookFilterChange(InAction);

	FFriendUIState FriendUIState = GetFriendUIState();
	FriendUIState.FriendCategory = EFriendCategory::FriendBookFeed;
	FriendUIState.FriendBookFilter = Action->GetVal();

	ChangeMenu(FriendUIState, false);

	return true;
}

// Party
IMPLEMENT_ACTION_HANDLER(UUIStateManager, PartyPetEdit)
{
	FPartyUIState PartyUIState = GetPartyUIState();
	check(!PartyUIState.bIsEdit);
	PartyUIState.bIsPetEdit = true;

	ChangeMenu(PartyUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PartyEdit)
{
	const auto& Action = ACTION_PARSE_PartyEdit(InAction);

	FPartyUIState PartyUIState = GetPartyUIState();
	PartyUIState.bIsEdit = true;
	PartyUIState.ItemType = Action->GetVal();
	PartyUIState.SelectedSlotIdx = Action->GetVal2();

	ChangeMenu(PartyUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PartyChange)
{
	const auto& Action = ACTION_PARSE_PartyChange(InAction);

	FPartyUIState PartyUIState = GetPartyUIState();
	PartyUIState.PageNum = Action->GetVal();

	ChangeMenu(PartyUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PartyMain)
{
	const auto& Action = ACTION_PARSE_PartyMain(InAction);

	FPartyUIState PartyUIState = GetPartyUIState();
	PartyUIState.SagaType = Action->GetVal();
	if (PartyUIState.SagaType != SagaTypeInvalid)
	{
		PartyUIState.WidgetType = EPartyWidgetType::CombatReady;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(PartyUIState.SagaType);
	bool bAddHistory = false;
	if (SagaRow.ContentType == EContentType::MultiSideBattle)
	{
		if (SagaRow.StageType == EStageType::Battle)
		{
			bAddHistory = true;
		}
	}

	ChangeMenu(PartyUIState, bAddHistory);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PartySaveResp)
{
	const FPartyUIState PartyUIState = GetPartyUIState();
	if (PartyUIState.bIsPetEdit)
	{
		return true;
	}

	GotoBack();

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PartyEventContentType)
{
	const auto& Action = ACTION_PARSE_PartyEventContentType(InAction);
	FEventContentType EventContentType = Action->GetVal();

	FPartyUIState PartyUIState = GetPartyUIState();
	PartyUIState.EventContentType = EventContentType;

	ChangeMenu(PartyUIState, false);

	return true;
}

// JokerSet
IMPLEMENT_ACTION_HANDLER(UUIStateManager, JokerSetMain)
{
	const auto& Action = ACTION_PARSE_JokerSetMain(InAction);

	FPartyUIState PartyUIState = GetPartyUIState();
	PartyUIState.WidgetType = EPartyWidgetType::JokerSet;
	check(!PartyUIState.bIsEdit);
	PartyUIState.PageNum = Action->GetVal();

	ChangeMenu(PartyUIState, false, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, JokerSetChange)
{
	const auto& Action = ACTION_PARSE_JokerSetChange(InAction);

	FPartyUIState PartyUIState = GetPartyUIState();
	check(PartyUIState.WidgetType == EPartyWidgetType::JokerSet);
	PartyUIState.PageNum = Action->GetVal();

	ChangeMenu(PartyUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, JokerSetEdit)
{
	const auto& Action = ACTION_PARSE_JokerSetEdit(InAction);

	FPartyUIState PartyUIState = GetPartyUIState();
	check(PartyUIState.WidgetType == EPartyWidgetType::JokerSet);
	PartyUIState.bIsEdit = true;
	PartyUIState.ItemType = Action->GetVal();
	PartyUIState.SelectedSlotIdx = Action->GetVal2();

	ChangeMenu(PartyUIState, false);

	return true;
}

// JokerSelect
IMPLEMENT_ACTION_HANDLER(UUIStateManager, JokerSelect)
{
	const auto& Action = ACTION_PARSE_JokerSelect(InAction);

	FJokerSelectUIState JokerSelectUIState = GetJokerSelectUIState();
	JokerSelectUIState.SagaType = Action->GetVal();

	ChangeMenu(JokerSelectUIState, Action->GetVal2());

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, JokerSetView)
{
	FJokerSelectUIState JokerSelectUIState = GetJokerSelectUIState();
	JokerSelectUIState.FriendMenu = EFriendMenu::JokerSetView;

	ChangeMenu(JokerSelectUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, FriendJokerFromPopup)
{
	FJokerSelectUIState JokerSelectUIState = GetJokerSelectUIState();
	JokerSelectUIState.FriendMenu = EFriendMenu::MainView;

	ChangeMenu(JokerSelectUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SagaStageList)
{
	const auto& Action = ACTION_PARSE_SagaStageList(InAction);

	FSagaUIState SagaUIState = DefaultSagaUIState;
	SagaUIState.SagaTab = ESagaTab::Stage;
	SagaUIState.Episode = Action->GetVal();
	SagaUIState.SagaTitleText = GetGameResource().GetEpisodeAssetRow(SagaUIState.Episode).Title;

	ChangeMenu(SagaUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SagaStageEndResp)
{
	const auto& Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	if (GetHUDStore().GetSagaManager().IsEpisodeClearingSagaType(Resp.Type))
	{
		ChangeMenu(DefaultSagaUIState, false);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SagaStoryStageClearResp)
{
	const auto& Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);
	auto& Resp = Action->GetVal();

	if (GetHUDStore().GetSagaManager().IsEpisodeClearingSagaType(Resp.Type))
	{
		ChangeMenu(DefaultSagaUIState, false);
	}

	return false;
}

// SpecialStage
IMPLEMENT_ACTION_HANDLER(UUIStateManager, SpecialOpen)
{
	const auto& Action = ACTION_PARSE_SpecialOpen(InAction);

	ChangeMenu(Action->GetVal(), true, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SpecialEpisodeList)
{
	const auto& Action = ACTION_PARSE_SpecialEpisodeList(InAction);
	FSpecialUIState SpecialUIState = GetSpecialStageUIState();
	SpecialUIState.MenuType = ESpecialStageMenuType::EpisodeList;
	SpecialUIState.Category = Action->GetVal();

	ChangeMenu(SpecialUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SpecialCharacterStageList)
{
	const auto& Action = ACTION_PARSE_SpecialCharacterStageList(InAction);

	FSpecialUIState SpecialUIState = DefaultSpecialStageUIState;
	SpecialUIState.MenuType = ESpecialStageMenuType::StageList;
	SpecialUIState.Category = ESpecialCategory::Character;
	SpecialUIState.SpecialType = Action->GetVal();

	ChangeMenu(SpecialUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SpecialSagaStageList)
{
	FSpecialUIState SpecialUIState = DefaultSpecialStageUIState;
	SpecialUIState.MenuType = ESpecialStageMenuType::StageList;
	SpecialUIState.Category = ESpecialCategory::Saga;

	ChangeMenu(SpecialUIState, false);

	return true;
}


IMPLEMENT_ACTION_HANDLER(UUIStateManager, SpecialWonderStageList)
{
	const auto& Action = ACTION_PARSE_SpecialWonderStageList(InAction);

	FSpecialUIState SpecialUIState = DefaultSpecialStageUIState;
	SpecialUIState.MenuType = ESpecialStageMenuType::StageList;
	SpecialUIState.Category = ESpecialCategory::Wonder;
	SpecialUIState.Wonder = Action->GetVal();

	ChangeMenu(SpecialUIState, false);

	return true;
}

// DailyDungeon
IMPLEMENT_ACTION_HANDLER(UUIStateManager, DailyDungeonStageList)
{
	const auto& Action = ACTION_PARSE_DailyDungeonStageList(InAction);

	FDailyDungeonUIState DailyUIState = DefaultDailyDungeonUIState;
	DailyUIState.MenuType = EDailyDungeonMenuType::StageList;
	DailyUIState.DungeonCategory = Action->GetVal();

	ChangeMenu(DailyUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, DailyDungeonPageChange)
{
	const auto& Action = ACTION_PARSE_DailyDungeonPageChange(InAction);

	FDailyDungeonUIState DailyUIState = DefaultDailyDungeonUIState;
	DailyUIState.MenuType = Action->GetVal();
	DailyUIState.DungeonCategory = EDailyDungeonCategory::None;

	ChangeMenu(DailyUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, TrainingCenterOpen)
{
	ChangeMenu(DefaultTrainingCenterUIState, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, JokerSetSaveResp) //-V524 equivalent body
{
	GotoBack();

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SummonBoxScheduleResp)
{
	const auto& Action = ACTION_PARSE_SummonBoxScheduleResp(InAction);
	const auto& Resp = Action->GetVal();

	FSummonUIState SummonUIState = GetSummonUIState();
	SummonUIState.Sequence = Resp.ScheduleInfos.Num() ? ESummonSequence::Main : ESummonSequence::EmptySchedule;

	ChangeMenu(SummonUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SummonPageChange)
{
	const auto& Action = ACTION_PARSE_SummonPageChange(InAction);

	FSummonUIState SummonUIState = GetSummonUIState();
	SummonUIState.Sequence = ESummonSequence::Main;
	SummonUIState.FocusPage = Action->GetVal();

	ChangeMenu(SummonUIState, false);

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SummonFriendShip)
{
	FSummonUIState SummonUIState = GetSummonUIState();
	SummonUIState.Sequence = ESummonSequence::Result;

	ChangeMenu(SummonUIState, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, InitialRewardEventOpen)
{
	const auto& Action = ACTION_PARSE_InitialRewardEventOpen(InAction);

	ChangeMenu(Action->GetVal(), true);

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, WonderMenu)
{
	const auto& Action = ACTION_PARSE_WonderMenu(InAction);

	FWonderUIState WonderUIState = GetWonderUIState();
	WonderUIState.Category = Action->GetVal();
	WonderUIState.Level = Action->GetVal2();
	WonderUIState.SelectedSlot = 1;

	ChangeMenu(WonderUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, WonderSlotSelect)
{
	const auto& Action = ACTION_PARSE_WonderSlotSelect(InAction);

	FWonderUIState WonderUIState = GetWonderUIState();
	WonderUIState.SelectedSlot = Action->GetVal();

	ChangeMenu(WonderUIState, false);

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PyramidUpgradeCompleteResp)
{
	const auto& Action = ACTION_PARSE_PyramidUpgradeCompleteResp(InAction);
	const FL2CPyramidUpgradeCompleteResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::Pyramid, Resp.Info.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PowerPlantUpgradeCompleteResp)
{
	const auto& Action = ACTION_PARSE_PowerPlantUpgradeCompleteResp(InAction);
	const FL2CPowerPlantUpgradeCompleteResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::Powerplant, Resp.PowerPlantInfo.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, VacationUpgradeCompleteResp)
{
	const auto& Action = ACTION_PARSE_VacationUpgradeCompleteResp(InAction);
	const FL2CVacationUpgradeCompleteResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::Vacation, Resp.VacationInfo.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, PetParkUpgradeCompleteResp)
{
	const auto& Action = ACTION_PARSE_PetParkUpgradeCompleteResp(InAction);
	const FL2CPetParkUpgradeCompleteResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::PetPark, Resp.PetPark.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, TempleUpgradeCompleteResp)
{
	const auto& Action = ACTION_PARSE_TempleUpgradeCompleteResp(InAction);
	const FL2CTempleUpgradeCompleteResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::Temple, Resp.TempleInfo.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, RaidOpen)
{
	ChangeMenu(DefaultRaidUIState, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, AlchemylabUpgradeCompleteResp)
{
	const auto& Action = ACTION_PARSE_AlchemylabUpgradeCompleteResp(InAction);
	const FL2CAlchemylabUpgradeCompleteResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::AlchemyLab, Resp.Info.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SmelterUpgradeCompleteResp)
{
	const auto& Action = ACTION_PARSE_SmelterUpgradeCompleteResp(InAction);
	const FL2CSmelterUpgradeCompleteResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::MigriumRefinery, Resp.Info.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, InventoryOpen)
{
	const auto& Action = ACTION_PARSE_InventoryOpen(InAction);

	FInventoryUIState InventoryUIState = DefaultInventoryUIState;
	InventoryUIState.Category = Action->GetVal();

	ChangeMenu(InventoryUIState, false, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, InventoryChange)
{
	const auto& Action = ACTION_PARSE_InventoryChange(InAction);

	FInventoryUIState InventoryUIState = GetInventoryUIState();
	InventoryUIState.InventoryType = Action->GetVal();

	ChangeMenu(InventoryUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, InventoryEdit)
{
	const auto& Action = ACTION_PARSE_InventoryEdit(InAction);

	FInventoryUIState InventoryUIState = GetInventoryUIState();
	InventoryUIState.EditType = Action->GetVal();

	ChangeMenu(InventoryUIState, true);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, CharacterSetStashResp)
{
	const auto& Action = ACTION_PARSE_CharacterSetStashResp(InAction);

	FInventoryUIState InventoryUIState = GetInventoryUIState();
	InventoryUIState.EditType = EInventoryEdit::None;

	ChangeMenu(InventoryUIState, false, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, RelicSetStashResp)
{
	const auto& Action = ACTION_PARSE_RelicSetStashResp(InAction);

	FInventoryUIState InventoryUIState = GetInventoryUIState();
	InventoryUIState.EditType = EInventoryEdit::None;

	ChangeMenu(InventoryUIState, false, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SculptureSetStashResp)
{
	const auto& Action = ACTION_PARSE_SculptureSetStashResp(InAction);

	FInventoryUIState InventoryUIState = GetInventoryUIState();
	InventoryUIState.EditType = EInventoryEdit::None;

	ChangeMenu(InventoryUIState, false, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, MailSelect)
{
	const auto& Action = ACTION_PARSE_MailSelect(InAction);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, DevPyramidPortalBoostUseResp)
{
	const auto& Action = ACTION_PARSE_DevPyramidPortalBoostUseResp(InAction);
	const FL2CDevPortalBoostUseResp& Resp = Action->GetVal();

	FWonderUIState WonderUIState = GetWonderUIState();
	if (WonderUIState.Category == EWonderCategory::Pyramid)
	{
		WonderUIState.SelectedSlot = (int32)(Resp.Category);
		ChangeMenu(WonderUIState, false);

		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, DevPyramidUpgradeResp)
{
	const auto& Action = ACTION_PARSE_DevPyramidUpgradeResp(InAction);
	const FL2CDevPyramidUpgradeResp& Resp = Action->GetVal();

	SetWonderUpgrade(EWonderCategory::Pyramid, Resp.PyramidInfo.Level);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, CodexCategoryChange)
{
	const auto& Action = ACTION_PARSE_CodexCategoryChange(InAction);

	FCodexUIState CodexUIState = GetCodexUIState();
	CodexUIState.CodexCategory = Action->GetVal();

	ChangeMenu(CodexUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, CodexEquipFullView)
{
	const auto& Action = ACTION_PARSE_CodexEquipFullView(InAction);

	FCodexUIState CodexUIState = GetCodexUIState();
	CodexUIState.bEquipFullView = Action->GetVal();

	ChangeMenu(CodexUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SortingInit)
{
	if (!LoadSortingFile())
	{
		SortingSelectedOptions = GetUIResource().GetDefaultSortingSelectedOptions();
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, SortingChange)
{
	const auto& Action = ACTION_PARSE_SortingChange(InAction);
	const FSortingOption& NewSortingOption = Action->GetVal();

	for (FSortingOption& SortingOption : SortingSelectedOptions)
	{
		if (SortingOption.Category != NewSortingOption.Category)
		{
			continue;
		}

		if (SortingOption.SortMenu != NewSortingOption.SortMenu)
		{
			continue;
		}

		SortingOption = NewSortingOption;
		bSortingChanged = true;
		return true;
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, ShopMenuChange)
{
	const auto& Action = ACTION_PARSE_ShopMenuChange(InAction);

	bool bAddHistory = Action->GetVal2();

	FShopUIState ShopUIState = GetShopUIState();
	ShopUIState.ShopMenu = Action->GetVal();
	ShopUIState.bPlayAnim = bAddHistory;

	ChangeMenu(ShopUIState, bAddHistory);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, ShopBuyItemResp)
{
	const auto& Action = ACTION_PARSE_ShopBuyItemResp(InAction);

	FShopUIState ShopUIState = GetShopUIState();
	ShopUIState.bPlayAnim = false;

	ChangeMenu(ShopUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, LobbySettingEditChange)
{
	const auto& Action = ACTION_PARSE_LobbySettingEditChange(InAction);

	FLobbySettingUIState LobbySettingUIState = GetLobbySettingUIState();
	LobbySettingUIState.EditType = Action->GetVal();

	ChangeMenu(LobbySettingUIState, false);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, EventMenuChange)
{
	const auto& Action = ACTION_PARSE_EventMenuChange(InAction);
	FEventUIState EventUIState = DefaultEventUIState;
	EventUIState.EventMenu = Action->GetVal();
	EventUIState.EventContentType = Action->GetVal2();

	// when you enter Main menu, LobbyHUD adds history
	bool bAddHistory = Action->GetVal() != EEventMenu::Main;
	ChangeMenu(EventUIState, bAddHistory);

	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, MultisidePetSave)
{
	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, MultisidePartySave)
{
	GotoBack();
	return true;
}

IMPLEMENT_ACTION_HANDLER(UUIStateManager, StoryList)
{
	const auto& Action = ACTION_PARSE_StoryList(InAction);

	FStoryUIState StoryUIState = GetStoryUIState();
	StoryUIState.MenuType = EStoryMenuType::StoryList;
	StoryUIState.Category = Action->GetVal();
	ChangeMenu(StoryUIState, true);

	return true;
}
