#include "TempleManager.h"

#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "SystemConstHelper.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UTempleManager

UTempleManager::UTempleManager()
{
	InitStore(EHSType::Temple);
}

void UTempleManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTempleLoad Out;

	ClientNetwork.WsRequest(TEXT("temple/load"), Out,
		TQ6ResponseDelegate<FL2CTempleLoadResp>::CreateUObject(
			const_cast<UTempleManager*>(this), &UTempleManager::OnLoadResp));
}

void UTempleManager::ReqUpgrade() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTempleUpgrade Out;

	ClientNetwork.WsRequest(TEXT("temple/upgrade"), Out,
		TQ6ResponseDelegate<FL2CTempleUpgradeResp>::CreateUObject(
			const_cast<UTempleManager*>(this), &UTempleManager::OnUpgradeResp));
}

void UTempleManager::ReqUpgradeComplete() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTempleUpgradeComplete Out;

	ClientNetwork.WsRequest(TEXT("temple/upgradeComplete"), Out,
		TQ6ResponseDelegate<FL2CTempleUpgradeCompleteResp>::CreateUObject(
			const_cast<UTempleManager*>(this), &UTempleManager::OnUpgradeCompleteResp));
}

void UTempleManager::ReqArtifactUse(int32 Index) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTempleArtifactUse Out;
	Out.ArtifactIndex = Index;

	ClientNetwork.WsRequest(TEXT("temple/artifactUse"), Out,
		TQ6ResponseDelegate<FL2CTempleArtifactUseResp>::CreateUObject(
			const_cast<UTempleManager*>(this), &UTempleManager::OnArtifactUseResp));
}

void UTempleManager::ReqArtifactBoost(int32 Index) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTempleArtifactBoost Out;
	Out.ArtifactIndex = Index;

	ClientNetwork.WsRequest(TEXT("temple/artifactBoost"), Out,
		TQ6ResponseDelegate<FL2CTempleArtifactBoostResp>::CreateUObject(
			const_cast<UTempleManager*>(this), &UTempleManager::OnArtifactBoostResp));
}

void UTempleManager::ReqArtifactUpgrade(int32 Index) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTempleArtifactUpgrade Out;
	Out.ArtifactIndex = Index;

	ClientNetwork.WsRequest(TEXT("temple/artifactUpgrade"), Out,
		TQ6ResponseDelegate<FL2CTempleArtifactUpgradeResp>::CreateUObject(
			const_cast<UTempleManager*>(this), &UTempleManager::OnArtifactUpgradeResp));
}

void UTempleManager::ReqHarvest() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LTempleHarvest Out;

	ClientNetwork.WsRequest(TEXT("temple/harvest"), Out,
		TQ6ResponseDelegate<FL2CTempleHarvestResp>::CreateUObject(
			const_cast<UTempleManager*>(this), &UTempleManager::OnHarvestResp));
}

#if !UE_BUILD_SHIPPING
void UTempleManager::ReqDevUpgrade(int32 TargetLevel) const
{
	FC2LDevTempleUpgrade Out;
	Out.Level = TargetLevel;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	ClientNetwork.WsRequest(TEXT("dev/templeUpgrade"), Out,
		TQ6ResponseDelegate<FL2CTempleUpgradeCompleteResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CTempleUpgradeCompleteResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_temple_upgrade Ok");
		ACTION_DISPATCH_TempleUpgradeCompleteResp(Res);
	}));
}
#endif

const FArtifact* UTempleManager::GetArtifact(int32 Index) const
{
	if (TempleInfo.Artifacts.IsValidIndex(Index))
	{
		return &TempleInfo.Artifacts[Index];
	}

	return nullptr;
}

int32 UTempleManager::GetArtifactRemainSeconds(int32 Index) const
{
	if (!TempleInfo.Artifacts.IsValidIndex(Index))
	{
		Q6JsonLogRoze(Error, "UTempleManager::GetRemainHours - Invalid artifact index", Q6KV("ArtifactIndex", Index));
		return 0;
	}

	const FArtifact& Artifact = TempleInfo.Artifacts[Index];
	int32 SkillCooltimeDays = SystemConstHelper::GetArtifactSkillCooltime(Index);
	int32 RemainCooltimeSecs = FMath::Max(SystemConstHelper::GetArtifactSkillCooltime(Index), 0) * 24 * 60 * 60;
	if (RemainCooltimeSecs == 0)
	{
		return 0;
	}

	return (int32)Q6Util::GetRemainTime(Artifact.UsedTime + RemainCooltimeSecs).GetTotalSeconds();
}

bool UTempleManager::HasOpenedArtifactCanUseInBattle() const
{
	for (int32 i = 0; i < MAX_ARTIFACT_COUNT; ++i)
	{
		if (!TempleInfo.Artifacts.IsValidIndex(i))
		{
			continue;
		}

		const FArtifact& Artifact = TempleInfo.Artifacts[i];
		if (Artifact.Level <= 0)
		{
			continue;
		}

		const int32 SkillType = SystemConstHelper::GetArtifactSkillType(i);
		if (SkillType == TempleConst::Q6_ARTIFACT3_SKILL_ID)
		{
			// It can't use in battle, only wipeout
			continue;
		}

		return true;
	}

	return false;
}

void UTempleManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UTempleManager, TempleLoadResp);
	REGISTER_ACTION_HANDLER(UTempleManager, TempleUpgradeResp);
	REGISTER_ACTION_HANDLER(UTempleManager, TempleUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UTempleManager, TempleArtifactUseResp);
	REGISTER_ACTION_HANDLER(UTempleManager, TempleArtifactBoostResp);
	REGISTER_ACTION_HANDLER(UTempleManager, TempleArtifactUpgradeResp);
	REGISTER_ACTION_HANDLER(UTempleManager, TempleHarvestResp);
	REGISTER_ACTION_HANDLER(UTempleManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UTempleManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(UTempleManager, DevTempleOpenResp);
	REGISTER_ACTION_HANDLER(UTempleManager, DevTempleProduceResp);
	REGISTER_ACTION_HANDLER(UTempleManager, DevTempleArtifactsResetResp);
	REGISTER_ACTION_HANDLER(UTempleManager, DevTempleArtifactUpgradeResp);
	REGISTER_ACTION_HANDLER(UTempleManager, DevSpecialClearResp);
}

void UTempleManager::OnLoadResp(const FResError* Error, const FL2CTempleLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_TempleLoadResp(Msg);
	GameInstance->ReqNextContent();
}

void UTempleManager::OnUpgradeResp(const FResError* Error, const FL2CTempleUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_TempleUpgradeResp(Msg);
}

void UTempleManager::OnUpgradeCompleteResp(const FResError* Error, const FL2CTempleUpgradeCompleteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_TempleUpgradeCompleteResp(Msg);
}

void UTempleManager::OnArtifactUseResp(const FResError* Error, const FL2CTempleArtifactUseResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_TempleArtifactUseResp(Msg);
}

void UTempleManager::OnArtifactBoostResp(const FResError* Error, const FL2CTempleArtifactBoostResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_TempleArtifactBoostResp(Msg);
}

void UTempleManager::OnArtifactUpgradeResp(const FResError* Error, const FL2CTempleArtifactUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_TempleArtifactUpgradeResp(Msg);
}

void UTempleManager::OnHarvestResp(const FResError* Error, const FL2CTempleHarvestResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_TempleHarvestResp(Msg);
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, TempleLoadResp)
{
	auto Action = ACTION_PARSE_TempleLoadResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, TempleUpgradeResp)
{
	auto Action = ACTION_PARSE_TempleUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, TempleUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_TempleUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, TempleArtifactUseResp)
{
	auto Action = ACTION_PARSE_TempleArtifactUseResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, TempleArtifactBoostResp)
{
	auto Action = ACTION_PARSE_TempleArtifactBoostResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, TempleArtifactUpgradeResp)
{
	auto Action = ACTION_PARSE_TempleArtifactUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, TempleHarvestResp)
{
	auto Action = ACTION_PARSE_TempleHarvestResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.Temple;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.Temple;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, DevTempleOpenResp)
{
	auto Action = ACTION_PARSE_DevTempleOpenResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, DevTempleProduceResp)
{
	auto Action = ACTION_PARSE_DevTempleProduceResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, DevTempleArtifactsResetResp)
{
	auto Action = ACTION_PARSE_DevTempleArtifactsResetResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, DevTempleArtifactUpgradeResp)
{
	auto Action = ACTION_PARSE_DevTempleArtifactUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.TempleInfo;

	return true;
}

IMPLEMENT_ACTION_HANDLER(UTempleManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	TempleInfo = Res.Temple;

	return true;
}