#pragma once

#include "Q6ClientNetwork.h"
#include "Q6UIDefine.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "ActRecordManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FActRecordId;

///////////////////////////////////////////////////////////////////////////////////////////
// FActRecord

class Q6_API FActRecord
{
public:
	FActRecord(const FActRecordInfo& InInfo);
	const FActRecordInfo& GetInfo() const { return Info; }
	void Update(const FActRecordInfo& InInfo);
private:
	FActRecordInfo Info;
};

///////////////////////////////////////////////////////////////////////////////////////////
// UActRecordManager

UCLASS()
class Q6_API UActRecordManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UActRecordManager();

	void ReqList(int32 PageNo = 0) const;
	void OnListResp(const FResError* Error, const FL2CActRecordListResp& Msg);
	void OnLoadResp(const FResError* Error, const FL2CActRecordLoadResp& Msg);

	void Dump() const;

	const TArray<FActRecord>& GetActRecords() { return ActRecords; }
	const FActRecord* const Find(FActRecordType Type, int32 Val) const;
	void FindRecords(FActRecordType Type, TArray<FActRecord>* Records) const;
	void FindDailyDungeonRecords(EDayOfWeekType InDungeonToday, TArray<FActRecord>* Records) const;

protected:
	virtual void RegisterActionHandlers() override;

	// Setter
	bool AddActRecord(const FActRecordInfo& Info);
	bool RemoveRecord(FActRecordId Id);
	bool UpdateActRecord(const FActRecordInfo& InInfo);
	bool UpdateActRecords(const TArray<FActRecordInfo>& Records);

	// Subroutines of OnAction
	DECLARE_ACTION_HANDLER(ClearActRecord);
	DECLARE_ACTION_HANDLER(ActRecordLoadResp);
	DECLARE_ACTION_HANDLER(ActRecordListResp);
	DECLARE_ACTION_HANDLER(ActRecordRemoveResp);

private:
	bool IsToday(int64 ClearTimeStamp) const;

	TArray<FActRecord> ActRecords;
};
