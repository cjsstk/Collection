#include "SculptureManager.h"

#include "HSAction.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "SortingWidgets.h"
#include "UIStateManager.h"

void DefaultSculptureInfo(FSculptureInfo * Info)
{
	Info->SculptureId = FSculptureId::InvalidValue();
	Info->UserId = FUserId::InvalidValue();
	Info->Type = SculptureTypeInvalid;
	Info->Level = ItemXpTypeInvalid;
	Info->Xp = 0;
	Info->Star = 0;
	Info->Grade = EItemGrade::NONE;
	Info->Locked = 0;
	Info->Newly = 0;
	Info->Created = 0;
}

void DumpSculpture(const FSculptureInfo& Info)
{
	Q6JsonLogHekel(Verbose, "",
		Q6KV("Id", Info.SculptureId),
		Q6KV("User", Info.UserId),
		Q6KV("Type", Info.Type),
		Q6KV("Level", Info.Level),
		Q6KV("Xp", Info.Xp),
		Q6KV("Star", Info.Star),
		Q6KV("Grade", static_cast<int32>(Info.Grade)),
		Q6KV("Locked", Info.Locked),
		Q6KV("Newly", Info.Newly),
		Q6KV("Created", Q6Util::GetLocalDateTimeText(Info.Created).ToString()));
}

USculptureManager::USculptureManager()
{
	InitStore(EHSType::Sculpture);
}

void USculptureManager::Dump() const
{
	Q6JsonLogHekel(Verbose, "== Sculptures ==",
		Q6KV("Total", Sculptures.Num()));
	for (const auto& Item : Sculptures)
	{
		const FSculpture& Sculpture = Item.Value;
		DumpSculpture(Sculpture.Info);
	}
}

void USculptureManager::ReqList(int32 PageNo /* = 0 */) const
{
	if (PageNo == 0)
	{
		ACTION_DISPATCH_ClearSculpture();
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSculptureList Out;
	Out.PageNo = PageNo;

	ClientNetwork.WsRequest(TEXT("sculpture/list"), Out,
		TQ6ResponseDelegate<FL2CSculptureListResp>::CreateUObject(
			const_cast<USculptureManager*>(this), &USculptureManager::OnListResp));
}

void USculptureManager::OnListResp(const FResError* Error, const FL2CSculptureListResp& Msg)
{
	Q6JsonLogHekel(Warning, "sculpture list resp");

	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ACTION_DISPATCH_SculptureListResp(Msg);

	if (Msg.PageNo >= (Msg.PageTotal - 1))
	{
		// TODO: refresh UI, list finished
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	const int MaxPage = 1000;
	if (Msg.PageTotal >= MaxPage ||
		Msg.PageNo + 1 >= MaxPage)
	{
		Q6JsonLogHekel(Warning, "Max Page Over",
			Q6KV("PageNo", Msg.PageNo),
			Q6KV("PageTotal", Msg.PageTotal));
		GameInstance->ReqNextContent();
		Dump();
		return;
	}

	ReqList(Msg.PageNo + 1);
}

void USculptureManager::ReqClearNew(const TArray<FSculptureId>& SculptureIds) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSculptureClearNew Out;
	Out.SculptureIds = SculptureIds;

	ClientNetwork.WsRequest(TEXT("sculpture/clearNew"), Out,
		TQ6ResponseDelegate<FL2CSculptureClearNewResp>::CreateUObject(
			const_cast<USculptureManager*>(this), &USculptureManager::OnClearNewResp));
}

void USculptureManager::ReqSetLock(const FSculptureId& Id, bool bLock) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSculptureSetLock Out;
	Out.SculptureId = Id;
	Out.Locked = bLock ? 1 : 0;

	ClientNetwork.WsRequest(TEXT("sculpture/setLock"), Out,
		TQ6ResponseDelegate<FL2CSculptureLoadResp>::CreateUObject(
			const_cast<USculptureManager*>(this), &USculptureManager::OnLoadResp));
}

void USculptureManager::ReqAddXp(const FSculptureId& TargetId, const TArray<int64>& SourceIds) const
{
	FC2LSculptureAddXp Out;
	Out.SculptureId = TargetId;
	for (const int64& SourceId : SourceIds)
	{
		Out.SculptureIds.Add(FSculptureId(SourceId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("sculpture/addXp"), Out,
		TQ6ResponseDelegate<FL2CSculptureAddXpResp>::CreateUObject(
			const_cast<USculptureManager*>(this), &USculptureManager::OnAddXpResp));
}

void USculptureManager::ReqPromote(const FSculptureId& TargetId) const
{
	FC2LSculpturePromote Out;
	Out.SculptureId = TargetId;

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("sculpture/promote"), Out,
		TQ6ResponseDelegate<FL2CSculpturePromoteResp>::CreateUObject(
			const_cast<USculptureManager*>(this), &USculptureManager::OnPromoteResp));
}

void USculptureManager::ReqTierUp(const FSculptureId& TargetId, const TArray<int64>& SourceIds) const
{
	FC2LSculptureTierUpgrade Out;
	Out.SculptureId = TargetId;
	for (const int64& SourceId : SourceIds)
	{
		Out.SculptureIds.Add(FSculptureId(SourceId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("sculpture/tierUpgrade"), Out,
		TQ6ResponseDelegate<FL2CSculptureTierUpgradeResp>::CreateUObject(
			const_cast<USculptureManager*>(this), &USculptureManager::OnTierUpgradeResp));
}

void USculptureManager::ReqSetStash(const TArray<int64>& TargetIds, bool bStashed) const
{
	FC2LSculptureSetStash Out;
	Out.Stashed = bStashed;
	for (const int64& TargetId : TargetIds)
	{
		Out.SculptureIds.Add(FSculptureId(TargetId));
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("sculpture/setStash"), Out,
		TQ6ResponseDelegate<FL2CSculptureSetStashResp>::CreateUObject(
			const_cast<USculptureManager*>(this), &USculptureManager::OnSetStashResp));
}

bool USculptureManager::IsEqualSculptureType(const FSculptureId& SculptureIdA, const FSculptureId& SculptureIdB) const
{
	const FSculpture* SculptureA = Find(SculptureIdA);
	const FSculpture* SculptureB = Find(SculptureIdB);

	FSculptureType SculptureTypeA = SculptureA ? SculptureA->GetInfo().Type : SculptureTypeInvalid;
	FSculptureType SculptureTypeB = SculptureB ? SculptureB->GetInfo().Type : SculptureTypeInvalid;

	return (SculptureTypeA == SculptureTypeB);
}

TArray<FSculptureType> USculptureManager::GetSculptureTypes(const TArray<FSculptureId>& SculptureIds) const
{
	TArray<FSculptureType> SculptureTypes;

	for (const FSculptureId& SculptureId : SculptureIds)
	{
		if (const FSculpture* Sculpture = Find(SculptureId))
		{
			SculptureTypes.Add(Sculpture->GetInfo().Type);
		}
	}

	return SculptureTypes;
}

TArray<const FSculpture*> USculptureManager::GetSculptures(ESortMenu SortMenu, ESortCategory Category, bool bStashed) const
{
	TArray<const FSculpture*> FilteredList;

	const UCMS* CMS = GetCMS();
	const FSortingGroup& SortingGroup = GetUIResource().GetSortingGroup(Category);
	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, Category);
	for (auto& Elem : Sculptures)
	{
		const FSculpture& Sculpture = Elem.Value;
		const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(Sculpture.Info.Type);
		if (Category != ESortCategory::OwnedSculptureWithExp && SculptureRow.XpExclusive)
		{
			continue;
		}

		if (SortingGroup.bXpCardFilter && SortingOption.bXpCardFilter && !SculptureRow.XpExclusive)
		{
			continue;
		}

		if ((SortingGroup.FilterType == ESortFilterType::Tier) && !SortingOption.FilterOptions.Contains(Sculpture.Info.Tier))
		{
			continue;
		}

		if (Sculpture.IsStashed() != bStashed)
		{
			continue;
		}

		FilteredList.AddUnique(&Sculpture);
	}

	FSortOrdering::Sort(SortingOption, FilteredList);
	return FilteredList;
}

void USculptureManager::SortByPicked(TArray<const FSculpture*>& OutSculptures, const TArray<FSculptureId>& SculptureIds) const
{
	int32 PickedIndex = 0;
	for (const FSculpture* Sculpture : OutSculptures)
	{
		if (!SculptureIds.Contains(Sculpture->Info.SculptureId))
		{
			continue;
		}

		OutSculptures.Remove(Sculpture);
		OutSculptures.Insert(Sculpture, PickedIndex++);
	}
}

int32 USculptureManager::GetLeastUpTier(const FSculptureId& TargetSculputreId) const
{
	const FSculpture* TargetSculputre = Find(TargetSculputreId);
	if (!TargetSculputre)
	{
		Q6JsonLogRoze(Warning, "Not found target sculpture", Q6KV("SculptureId", TargetSculputreId));
		return 0;
	}

	int32 LeastUp = 0;
	const FSculptureInfo& TargetSculputreInfo = TargetSculputre->Info;
	for (auto& Elem : Sculptures)
	{
		const FSculpture& Sculpture = Elem.Value;
		const FSculptureInfo& SculptureInfo = Sculpture.GetInfo();
		if (SculptureInfo.Type != TargetSculputreInfo.Type)
		{
			continue;
		}

		if (SculptureInfo.SculptureId == TargetSculputreInfo.SculptureId)
		{
			continue;
		}

		const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(SculptureInfo.Type);
		if (SculptureRow.XpExclusive)
		{
			continue;
		}

		if ((LeastUp <= 0) || (LeastUp > SculptureInfo.Tier))
		{
			LeastUp = SculptureInfo.Tier;
		}
	}

	return LeastUp;
}

TMap<FSculptureType, const FSculptureInfo*> USculptureManager::GetPortalConnectSculptures() const
{
	TMap<FSculptureType, const FSculptureInfo*> SculptureMap;

	for (auto& Elem : Sculptures)
	{
		const FSculpture& Sculpture = Elem.Value;
		const FSculptureInfo& SculptureInfo = Sculpture.Info;

		if (SculptureInfo.Grade < EItemGrade::SR)
		{
			continue;
		}

		const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(SculptureInfo.Type);
		if (SculptureRow.XpExclusive)
		{
			continue;
		}

		if (!SculptureRow.Pyramid)
		{
			continue;
		}

		const FSculptureInfo** FoundSculptureInfo = SculptureMap.Find(SculptureInfo.Type);
		if (!FoundSculptureInfo)
		{
			SculptureMap.Add(SculptureInfo.Type, &SculptureInfo);
			continue;
		}

		if (SculptureInfo.Level > (*FoundSculptureInfo)->Level)
		{
			SculptureMap.Add(SculptureInfo.Type, &SculptureInfo);
			continue;
		}

		if ((SculptureInfo.Level == (*FoundSculptureInfo)->Level)
			&& (SculptureInfo.Tier > (*FoundSculptureInfo)->Tier))
		{
			SculptureMap.Add(SculptureInfo.Type, &SculptureInfo);
			continue;
		}
	}

	return SculptureMap;
}

int32 USculptureManager::GetStashedSculptureNum(bool bStashed) const
{
	int32 StashedCount = 0;
	for (const auto& Elem : Sculptures)
	{
		const FSculpture& Sculpture = Elem.Value;
		if (Sculpture.IsStashed() != bStashed)
		{
			continue;
		}

		++StashedCount;
	}

	return StashedCount;
}

bool USculptureManager::HasSculpture(EItemGrade InGrade) const
{
	for (const auto& Elem : Sculptures)
	{
		const FSculpture& InSculpture = Elem.Value;
		if (InSculpture.GetInfo().Grade == InGrade)
		{
			return true;
		}
	}

	return false;
}

void USculptureManager::OnLoadResp(const FResError* Error, const FL2CSculptureLoadResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	// load, clearNew, setLock
	ACTION_DISPATCH_SculptureLoadResp(Msg);
}

void USculptureManager::OnAddXpResp(const FResError* Error, const FL2CSculptureAddXpResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SculptureAddXpResp(Msg);
}

void USculptureManager::OnPromoteResp(const FResError* Error, const FL2CSculpturePromoteResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SculpturePromoteResp(Msg);
}

void USculptureManager::OnTierUpgradeResp(const FResError* Error, const FL2CSculptureTierUpgradeResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SculptureTierUpResp(Msg);
}

void USculptureManager::OnSetStashResp(const FResError* Error, const FL2CSculptureSetStashResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SculptureSetStashResp(Msg);
}

void USculptureManager::OnClearNewResp(const FResError* Error, const FL2CSculptureClearNewResp& Msg)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_SculptureClearNewResp(Msg);
}

/////////////////////////////////////////////////////////////////////////////
// UBagItemManager HUDStore Action

void USculptureManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(USculptureManager, ClearSculpture);
	REGISTER_ACTION_HANDLER(USculptureManager, SculptureLoadResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SculptureListResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SculptureRemoveResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SculptureAddXpResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SculpturePromoteResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SculptureTierUpResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SculptureSetStashResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SculptureClearNewResp);
	REGISTER_ACTION_HANDLER(USculptureManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, DevSculptureNewResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SummonPurchaseResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SummonPickupResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SagaStoryStageClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, SpecialStoryStageClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, DailyStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, TrainingCenterStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, DevTrainingCenterClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, RaidStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, RaidFinalStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, MailReceiveResp);
	REGISTER_ACTION_HANDLER(USculptureManager, EventContentCollabo01StageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, EventContentCollabo01StoryStageClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, EventContentValentineDayStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, EventContentValentineDayStoryStageClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, EventContentMultiSideBattleStageEndResp);
	REGISTER_ACTION_HANDLER(USculptureManager, EventContentMultiSideBattleStoryStageClearResp);
	REGISTER_ACTION_HANDLER(USculptureManager, EventContentMultisideBattleReceiveRankRewardResp);
	REGISTER_ACTION_HANDLER(USculptureManager, AlchemylabReceiveResp);
	REGISTER_ACTION_HANDLER(USculptureManager, ShopSellItemResp);
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, ClearSculpture)
{
	Sculptures.Empty();
	return false;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculptureLoadResp)
{
	auto Action = ACTION_PARSE_SculptureLoadResp(InAction);

	auto& Res = Action->GetVal();
	return Add(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculptureListResp)
{
	auto Action = ACTION_PARSE_SculptureListResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculptureRemoveResp)
{
	auto Action = ACTION_PARSE_SculptureRemoveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureId& Id : Res.Ids)
	{
		Ret |= Remove(Id);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculptureAddXpResp)
{
	auto Action = ACTION_PARSE_SculptureAddXpResp(InAction);

	auto& Res = Action->GetVal();

	Add(Res.Info);
	for (const FSculptureId& Id : Res.Ids)
	{
		Remove(Id);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculpturePromoteResp)
{
	auto Action = ACTION_PARSE_SculpturePromoteResp(InAction);

	auto& Res = Action->GetVal();
	Add(Res.Info);
	return true;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculptureTierUpResp)
{
	auto Action = ACTION_PARSE_SculptureTierUpResp(InAction);

	auto& Res = Action->GetVal();

	Add(Res.Info);
	for (const FSculptureId& Id : Res.Ids)
	{
		Remove(Id);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculptureSetStashResp)
{
	auto Action = ACTION_PARSE_SculptureSetStashResp(InAction);

	auto& Res = Action->GetVal();
	for (const FSculptureId& SculptureId : Res.SculptureIds)
	{
		FSculpture* Sculpture = Sculptures.Find(SculptureId);
		if (!Sculpture)
		{
			Q6JsonLogRoze(Error, "USculptureManager::SculptureSetStashResp - No have sculpture", Q6KV("SculptureId", SculptureId));
			continue;
		}

		Sculpture->SetStashed(Res.Stashed);
	}

	return true;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SculptureClearNewResp)
{
	auto Action = ACTION_PARSE_SculptureClearNewResp(InAction);

	auto& Res = Action->GetVal();
	for (const FSculptureId& SculptureId : Res.SculptureIds)
	{
		FSculpture* Sculpture = Sculptures.Find(SculptureId);
		if (!Sculpture)
		{
			Q6JsonLogRoze(Error, "USculptureManager::SculptureClearNewResp - No have sculpture", Q6KV("SculptureId", SculptureId));
			continue;
		}

		Sculpture->SetNewly(0);
	}

	return false;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, DevSculptureNewResp)
{
	auto Action = ACTION_PARSE_DevSculptureNewResp(InAction);

	auto& Res = Action->GetVal();
	return Add(Res.Info);
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SummonPurchaseResp)
{
	auto Action = ACTION_PARSE_SummonPurchaseResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SummonPickupResp)
{
	auto Action = ACTION_PARSE_SummonPickupResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, DailyStageEndResp)
{
	auto Action = ACTION_PARSE_DailyStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, TrainingCenterStageEndResp)
{
	auto Action = ACTION_PARSE_TrainingCenterStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, DevTrainingCenterClearResp)
{
	auto Action = ACTION_PARSE_DevTrainingCenterClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, RaidStageEndResp)
{
	auto Action = ACTION_PARSE_RaidStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, RaidFinalStageEndResp)
{
	auto Action = ACTION_PARSE_RaidFinalStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, MailReceiveResp)
{
	auto Action = ACTION_PARSE_MailReceiveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, EventContentCollabo01StageEndResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, EventContentCollabo01StoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentCollabo01StoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, EventContentValentineDayStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, EventContentValentineDayStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentValentineDayStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, EventContentMultiSideBattleStoryStageClearResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStoryStageClearResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, EventContentMultisideBattleReceiveRankRewardResp)
{
	auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, EventContentMultiSideBattleStageEndResp)
{
	auto Action = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, AlchemylabReceiveResp)
{
	auto Action = ACTION_PARSE_AlchemylabReceiveResp(InAction);

	auto& Res = Action->GetVal();
	bool Ret = false;
	for (const FSculptureInfo& Info : Res.Sculptures)
	{
		Ret |= Add(Info);
	}
	return Ret;
}

IMPLEMENT_ACTION_HANDLER(USculptureManager, ShopSellItemResp)
{
	auto Action = ACTION_PARSE_ShopSellItemResp(InAction);
	auto& Res = Action->GetVal();
	if (Res.Category == ELootCategory::SculptureCard)
	{
		for (const FAnyId& ItemId : Res.ItemIds)
		{
			Remove(FSculptureId(ItemId.S));
		}
	}

	return true;
}


/////////////////////////////////////////////////////////////////////////////
// USculptureManager Setter

bool USculptureManager::Add(const FSculptureInfo& Info)
{
	Sculptures.Add(Info.SculptureId, Info);
	return true;
}

bool USculptureManager::Remove(const FSculptureId& Id)
{
	return (Sculptures.Remove(Id) > 0);
}

bool USculptureManager::Update(const FSculptureInfo& Info)
{
	Add(Info);
	return true;
}
