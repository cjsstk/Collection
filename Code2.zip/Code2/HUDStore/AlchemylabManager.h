#pragma once
#include "Q6ClientNetwork.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "Q6Timer.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "AlchemylabManager.generated.h"

UCLASS()
class Q6_API UAlchemylabManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UAlchemylabManager();

	void ReqLoad() const;
	void ReqIncStock(FAlchemyLabType Type) const;
	void ReqDecStock() const;
	void ReqReceive() const;
	void ReqUpgrade() const;
	void ReqUpgradeComplete() const;

	void OnLoadResp(const FResError* Error, const FL2CAlchemylabLoadResp& Resp);
	void OnIncStockResp(const FResError* Error, const FL2CAlchemylabIncStockResp& Resp);
	void OnDecStockResp(const FResError* Error, const FL2CAlchemylabDecStockResp& Resp);
	void OnReceiveResp(const FResError* Error, const FL2CAlchemylabReceiveResp& Resp);
	void OnUpgradeResp(const FResError* Error, const FL2CAlchemylabUpgradeResp& Resp);
	void OnUpgradeCompleteResp(const FResError* Error, const FL2CAlchemylabUpgradeCompleteResp& Resp);
	void OnProduceResp(const FResError* Error, const FL2CAlchemylabProduceResp& Resp);

	virtual void Tick(float DeltaTime) override;

	const FAlchemylabInfo& GetAlchemylabInfo() const { return Info; }
	const EIncomeState GetProductionState() const;

protected:
	virtual void RegisterActionHandlers() override;

	DECLARE_ACTION_HANDLER(AlchemylabLoadResp);
	DECLARE_ACTION_HANDLER(DevAlchemylabOpenResp);
	DECLARE_ACTION_HANDLER(DevAlchemylabUpgradeResp);
	DECLARE_ACTION_HANDLER(DevAlchemylabTimeResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(AlchemylabIncStockResp);
	DECLARE_ACTION_HANDLER(AlchemylabDecStockResp);
	DECLARE_ACTION_HANDLER(AlchemylabReceiveResp);
	DECLARE_ACTION_HANDLER(AlchemylabUpgradeResp);
	DECLARE_ACTION_HANDLER(AlchemylabUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(AlchemylabProduceResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);

private:
	FAlchemylabInfo Info;
	float AlchemylabTick;
};
