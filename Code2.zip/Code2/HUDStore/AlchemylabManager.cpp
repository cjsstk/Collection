#include "AlchemylabManager.h"

#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"

UAlchemylabManager::UAlchemylabManager()
{
	InitStore(EHSType::Alchemylab);
	AlchemylabTick = 0.f;
}

void UAlchemylabManager::ReqLoad() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAlchemylabLoad Out;

	ClientNetwork.WsRequest(TEXT("alchemylab/load"), Out,
		TQ6ResponseDelegate<FL2CAlchemylabLoadResp>::CreateUObject(
			const_cast<UAlchemylabManager*>(this), &UAlchemylabManager::OnLoadResp));
}

void UAlchemylabManager::ReqIncStock(FAlchemyLabType Type) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAlchemylabIncStock Out;
	Out.Type = Type;

	ClientNetwork.WsRequest(TEXT("alchemylab/incStock"), Out,
		TQ6ResponseDelegate<FL2CAlchemylabIncStockResp>::CreateUObject(
			const_cast<UAlchemylabManager*>(this), &UAlchemylabManager::OnIncStockResp));
}

void UAlchemylabManager::ReqDecStock() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAlchemylabDecStock Out;

	ClientNetwork.WsRequest(TEXT("alchemylab/decStock"), Out,
		TQ6ResponseDelegate<FL2CAlchemylabDecStockResp>::CreateUObject(
			const_cast<UAlchemylabManager*>(this), &UAlchemylabManager::OnDecStockResp));
}

void UAlchemylabManager::ReqReceive() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAlchemylabReceive Out;

	ClientNetwork.WsRequest(TEXT("alchemylab/receive"), Out,
		TQ6ResponseDelegate<FL2CAlchemylabReceiveResp>::CreateUObject(
			const_cast<UAlchemylabManager*>(this), &UAlchemylabManager::OnReceiveResp));
}

void UAlchemylabManager::ReqUpgrade() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAlchemylabUpgrade Out;

	ClientNetwork.WsRequest(TEXT("alchemylab/upgrade"), Out,
		TQ6ResponseDelegate<FL2CAlchemylabUpgradeResp>::CreateUObject(
			const_cast<UAlchemylabManager*>(this), &UAlchemylabManager::OnUpgradeResp));
}

void UAlchemylabManager::ReqUpgradeComplete() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LAlchemylabUpgradeComplete Out;

	ClientNetwork.WsRequest(TEXT("alchemylab/upgradeComplete"), Out,
		TQ6ResponseDelegate<FL2CAlchemylabUpgradeCompleteResp>::CreateUObject(
			const_cast<UAlchemylabManager*>(this), &UAlchemylabManager::OnUpgradeCompleteResp));
}
void UAlchemylabManager::OnLoadResp(const FResError* Error, const FL2CAlchemylabLoadResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_AlchemylabLoadResp(Resp);
	GameInstance->ReqNextContent();
}

void UAlchemylabManager::OnIncStockResp(const FResError* Error, const FL2CAlchemylabIncStockResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_AlchemylabIncStockResp(Resp);
}

void UAlchemylabManager::OnDecStockResp(const FResError* Error, const FL2CAlchemylabDecStockResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_AlchemylabDecStockResp(Resp);
}

void UAlchemylabManager::OnReceiveResp(const FResError* Error, const FL2CAlchemylabReceiveResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_AlchemylabReceiveResp(Resp);
}

void UAlchemylabManager::OnUpgradeResp(const FResError* Error, const FL2CAlchemylabUpgradeResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_AlchemylabUpgradeResp(Resp);
}

void UAlchemylabManager::OnUpgradeCompleteResp(const FResError* Error, const FL2CAlchemylabUpgradeCompleteResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_AlchemylabUpgradeCompleteResp(Resp);
}

void UAlchemylabManager::OnProduceResp(const FResError* Error, const FL2CAlchemylabProduceResp& Resp)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	ACTION_DISPATCH_AlchemylabProduceResp(Resp);
}

static const float TICK_ALCHEMYLAB = 1.f;
void UAlchemylabManager::Tick(float DeltaTime)
{
	if (AlchemylabTick == 0.f)
	{
		AlchemylabTick = TICK_ALCHEMYLAB;
		return;
	}

	AlchemylabTick -= DeltaTime;

	if (AlchemylabTick <= 0.f)
	{
		AlchemylabTick = TICK_ALCHEMYLAB;
		if (Info.Stock == 0)
		{
			return;
		}

		const FCMSAlchemyLabRow& Row = GetCMS()->GetAlchemyLabRowOrDummy(FAlchemyLabType(Info.ProductType));
		if (Row.IsInvalid())
		{
			return;
		}

		const int64 ProductTime = Row.ProductTime * 60;

		FDateTime Utc = FDateTime::UtcNow();
		int64 Diff = Utc.ToUnixTimestamp() - Info.StockTimeSec;
		if (Diff >= ProductTime)
		{
			FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
			FC2LAlchemylabProduce Out;

			ClientNetwork.WsRequest(TEXT("alchemylab/produce"), Out,
				TQ6ResponseDelegate<FL2CAlchemylabProduceResp>::CreateUObject(
					const_cast<UAlchemylabManager*>(this), &UAlchemylabManager::OnProduceResp));
		}
	}
}

const EIncomeState UAlchemylabManager::GetProductionState() const
{
	if (Info.Stock == 0 && Info.Product == 0 && Info.StockTimeSec == 0)
	{
		return EIncomeState::NotStored;
	}
	else if (Info.Stock > 0 && Info.StockTimeSec > 0)
	{
		return EIncomeState::Stored;
	}
	else if (Info.Stock == 0 && Info.Product > 0)
	{
		return EIncomeState::MaxStored;
	}

	ensure(false);
	return EIncomeState::Invalid;
}

void UAlchemylabManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(UAlchemylabManager, AlchemylabLoadResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, DevAlchemylabOpenResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, DevAlchemylabUpgradeResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, DevAlchemylabTimeResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, DevSpecialClearResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, AlchemylabIncStockResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, AlchemylabDecStockResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, AlchemylabReceiveResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, AlchemylabUpgradeResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, AlchemylabUpgradeCompleteResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, AlchemylabProduceResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, SpecialStageEndResp);
	REGISTER_ACTION_HANDLER(UAlchemylabManager, SpecialStoryStageClearResp);
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, AlchemylabLoadResp)
{
	auto Action = ACTION_PARSE_AlchemylabLoadResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, DevAlchemylabOpenResp)
{
	auto Action = ACTION_PARSE_DevAlchemylabOpenResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, DevAlchemylabUpgradeResp)
{
	auto Action = ACTION_PARSE_DevAlchemylabUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, DevAlchemylabTimeResp)
{
	auto Action = ACTION_PARSE_DevAlchemylabTimeResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, DevSpecialClearResp)
{
	auto Action = ACTION_PARSE_DevSpecialClearResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.AlchemyLab;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, AlchemylabIncStockResp)
{
	auto Action = ACTION_PARSE_AlchemylabIncStockResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, AlchemylabDecStockResp)
{
	auto Action = ACTION_PARSE_AlchemylabDecStockResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, AlchemylabReceiveResp)
{
	auto Action = ACTION_PARSE_AlchemylabReceiveResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, AlchemylabUpgradeResp)
{
	auto Action = ACTION_PARSE_AlchemylabUpgradeResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.AlchemylabInfo;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, AlchemylabUpgradeCompleteResp)
{
	auto Action = ACTION_PARSE_AlchemylabUpgradeCompleteResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, AlchemylabProduceResp)
{
	auto Action = ACTION_PARSE_AlchemylabProduceResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.Info;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, SpecialStageEndResp)
{
	auto Action = ACTION_PARSE_SpecialStageEndResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.AlchemyLab;
	return true;
}

IMPLEMENT_ACTION_HANDLER(UAlchemylabManager, SpecialStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SpecialStoryStageClearResp(InAction);
	auto& Res = Action->GetVal();

	Info = Res.AlchemyLab;
	return true;
}