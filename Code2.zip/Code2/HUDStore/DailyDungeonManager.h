#pragma once

#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6ClientNetwork.h"
#include "DailyDungeonManager.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;
struct FDailyDungeonRecord;
struct FRewardInfo;
struct FCombatMissionInfo;
class UCCEndGameEvent;

enum class EDayOfWeekType : uint8;

///////////////////////////////////////////////////////////////////////////////////////////
// UDailyDungeonManager
UCLASS()
class Q6_API UDailyDungeonManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UDailyDungeonManager();

	// Req
	void ReqDailyList(bool bEnterLobby = true) const;
	void ReqStageBegin() const;
	void ReqStageEnd(const UCCEndGameEvent* Event
		, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const;

#if !UE_BUILD_SHIPPING
	void ReqDevStageBegin() const;

	const int32& GetClockModValue() const { return ClockModValue; }
#endif

	const FDailyDungeonRecord& GetHistory(EDayOfWeekType DayOfWeek) const;
	bool IsFirstRewardOfToday() const { return ClearHistory.Promote || ClearHistory.Xp || ClearHistory.Gold; };
	EDayOfWeekType GetDayOfWeekType() const;

protected:
	virtual void RegisterActionHandlers() override;

private:
	// Res
	void OnDailyListResp(const FResError* Error, const FL2CDailyListResp& Res, bool bEnterLobby);
	void OnStageBeginResp(const FResError* Error, const FL2CDailyStageBeginResp& Res);
	void OnStageEndResp(const FResError* Error, const FL2CDailyStageEndResp& Res);

	void UpdateDailyDungeonClear(const FDailyDungeonRecord& NewClearDungeons);

	// On Actions
	DECLARE_ACTION_HANDLER(DailyListResp);
	DECLARE_ACTION_HANDLER(DailyStageEndResp);
	DECLARE_ACTION_HANDLER(DevClockModResp);

	UPROPERTY()
	FDailyDungeonRecord ClearHistory;

#if !UE_BUILD_SHIPPING
	int32 ClockModValue;
#endif
};
