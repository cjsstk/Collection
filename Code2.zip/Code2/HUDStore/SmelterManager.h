#pragma once
#include "Q6ClientNetwork.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "Q6Timer.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "SmelterManager.generated.h"

UCLASS()
class Q6_API USmelterManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	USmelterManager();

	void ReqLoad() const;
	void ReqIncStock(int32 Count = 1) const;
	void ReqDecStock(int32 Count = 1) const;
	void ReqReceive() const;
	void ReqUpgrade() const;
	void ReqUpgradeComplete() const;

	void OnLoadResp(const FResError* Error, const FL2CSmelterLoadResp& Resp);
	void OnIncStockResp(const FResError* Error, const FL2CSmelterIncStockResp& Resp);
	void OnDecStockResp(const FResError* Error, const FL2CSmelterDecStockResp& Resp);
	void OnReceiveResp(const FResError* Error, const FL2CSmelterReceiveResp& Resp);
	void OnUpgradeResp(const FResError* Error, const FL2CSmelterUpgradeResp& Resp);
	void OnUpgradeCompleteResp(const FResError* Error, const FL2CSmelterUpgradeCompleteResp& Resp);
	void OnProduceResp(const FResError* Error, const FL2CSmelterProduceResp& Resp);

	virtual void Tick(float DeltaTime) override;

	const FSmelterInfo& GetSmelterInfo() const { return Info; }
	const EIncomeState GetProductionState() const;

protected:
	virtual void RegisterActionHandlers() override;

	DECLARE_ACTION_HANDLER(SmelterLoadResp);
	DECLARE_ACTION_HANDLER(DevSmelterOpenResp);
	DECLARE_ACTION_HANDLER(DevSmelterUpgradeResp);
	DECLARE_ACTION_HANDLER(DevSmelterTimeResp);
	DECLARE_ACTION_HANDLER(DevSpecialClearResp);
	DECLARE_ACTION_HANDLER(SmelterIncStockResp);
	DECLARE_ACTION_HANDLER(SmelterDecStockResp);
	DECLARE_ACTION_HANDLER(SmelterReceiveResp);
	DECLARE_ACTION_HANDLER(SmelterUpgradeResp);
	DECLARE_ACTION_HANDLER(SmelterUpgradeCompleteResp);
	DECLARE_ACTION_HANDLER(SmelterProduceResp);
	DECLARE_ACTION_HANDLER(SpecialStageEndResp);
	DECLARE_ACTION_HANDLER(SpecialStoryStageClearResp);

private:
	FSmelterInfo Info;
	float SmelterTick;
};
