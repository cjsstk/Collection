// Copyright (c) 2020 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6ClientNetwork.h"
#include "HUDStoreInterface.h"
#include "HSAction.h"
#include "Q6UIDefine.h"
#include "BattleHelper.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Forward Declarations

struct FHSAction;

USTRUCT()
struct FStageChallenge
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(VisibleAnywhere)
	TMap<int32, int32> WaveChallengeCount;
};

UCLASS()
class Q6_API UBattleHelper : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UBattleHelper();

#if !UE_BUILD_SHIPPING
	const TMap<int32, FStageChallenge>& GetAllChallengeCount() const;
#endif

	int32 GetChallengeCount(FSagaType InSagaType, FWaveType InWaveType) const;

	void ReqStageChallengeList(FSagaType InSagaType) const;
	void ReqStageChallengeAdd(FSagaType InSagaType, FWaveType InWaveType) const;

protected:
	virtual void RegisterActionHandlers() override;

	void OnListResp(const FResError* Error, const FL2CStageChallengeListResp& Msg);
	void OnAddResp(const FResError* Error, const FL2CStageChallengeAddResp& Msg, FC2LStageChallengeAdd StageChallengeInfo);

	DECLARE_ACTION_HANDLER(StageChallengeListResp);
	DECLARE_ACTION_HANDLER(StageChallengeAddResp);

private:

	UPROPERTY()
	TMap<int32, FStageChallenge> StageChallenges;
};