#pragma once

#include "Q6ClientNetwork.h"
#include "Q6Define.h"
#include "Q6GameState.h"
#include "HSAction.h"
#include "HUDStoreInterface.h"
#include "EventMissionManager.generated.h"

UCLASS()
class Q6_API UEventMissionManager : public UHUDStoreBase
{
	GENERATED_BODY()

public:
	UEventMissionManager();

	void ReqList(int32 PageNo = 0) const;

protected:
	virtual void RegisterActionHandlers() override;
	void OnListResp(const FResError* Error, const FL2CEventMissionListResp& Msg);

private:
	DECLARE_ACTION_HANDLER(ClearEventMission);
	DECLARE_ACTION_HANDLER(EventMissionListResp);

	TArray<FEventMissionInfo> Missions;
};
