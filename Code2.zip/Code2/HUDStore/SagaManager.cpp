#include "SagaManager.h"
#include "CombatCube/Q6GameState.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Q6GameState.h"
#include "HSAction.h"
#include "LobbyHUD.h"
#include "Network/Q6ClientNetwork.h"
#include "CombatWidgets.h"
#include "ActRecordManager.h"
#include "CCEvent.h"

///////////////////////////////////////////////////////////////////////////////////////////
// USagaManager

USagaManager::USagaManager()
{
	InitStore(EHSType::Saga);
}

void USagaManager::ReqSagaHistory() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSagaLoad Out;

	ClientNetwork.WsRequest(TEXT("saga/load"), Out,
		TQ6ResponseDelegate<FL2CSagaLoadResp>::CreateUObject(
			const_cast<USagaManager*>(this), &USagaManager::OnSagaLoadResp));
}

void USagaManager::OnSagaLoadResp(const FResError* Error, const FL2CSagaLoadResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ReqNextContent();
		return;
	}

	ACTION_DISPATCH_SagaLoadResp(Res);
	GameInstance->ReqNextContent();
}

void USagaManager::ReqStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();
	FC2LSagaStageBegin Out;
	Out.Type = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("saga/stageBegin"), Out,
		TQ6ResponseDelegate<FL2CSagaStageBeginResp>::CreateUObject(
			const_cast<USagaManager*>(this), &USagaManager::OnStageBeginResp));
}

void USagaManager::OnStageBeginResp(const FResError* Error, const FL2CSagaStageBeginResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnSagaStageBegin(Res);
}

void USagaManager::ReqStageEnd(const UCCEndGameEvent* Event
	, const FString& Chronicle, const FCombatMissionInfo& CombatMissionInfo) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	FC2LSagaStageEnd Out;
	Out.Type = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.Result = static_cast<int32>(Event->Result);
	Out.FinalTurnCount = Event->FinalTurnCount;
	Out.GemWipeoutContinueCount = Event->GemWipeoutContinueCount;
	Out.ArtifactAvailable = Event->ArtifactAvailable;
	Out.Chronicle = Chronicle;
	Out.Mission = CombatMissionInfo.WeeklyCombatMissionInfo;
	Out.CharMission = CombatMissionInfo.CharCombatMissionInfo;

	ClientNetwork.WsRequest("saga/stageEnd", Out,
		TQ6ResponseDelegate<FL2CSagaStageEndResp>::CreateUObject(
			const_cast<USagaManager*>(this), &USagaManager::OnStageEndResp));
}

void USagaManager::OnStageEndResp(const FResError* Error, const FL2CSagaStageEndResp& Res)
{
	if (Error)
	{
		OnError(Error);
		return;
	}

	GameInstance->OnSagaStageEnd(Res);
}

void USagaManager::ReqStoryStageClear(FSagaType SagaType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LSagaStoryStageClear Out;
	Out.Type = SagaType;

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance))
	{
		LobbyHUD->ChangeHUDType(EHUDWidgetType::Dialogue);
	}

	ClientNetwork.WsRequest(TEXT("saga/storyStageClear"), Out,
		TQ6ResponseDelegate<FL2CSagaStoryStageClearResp>::CreateUObject(
			const_cast<USagaManager*>(this), &USagaManager::OnStoryStageClearResp));
}

void USagaManager::OnStoryStageClearResp(const FResError* Error, const FL2CSagaStoryStageClearResp& Res)
{
	if (Error)
	{
		OnError(Error);
		GameInstance->ClearDialogueRecord();
		return;
	}

	ACTION_DISPATCH_SagaStoryStageClearResp(Res);

	ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance);
	if (LobbyHUD)
	{
		LobbyHUD->OnStoryStageClear();
	}
}

#if !UE_BUILD_SHIPPING
void USagaManager::ReqDevStageBegin() const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
	const FJokerInfo& JokerInfo = GameInstance->GetJokerInfo();

	FC2LDevSagaStageBegin Out;
	Out.Type = CombatSeed.SagaType;
	Out.Party = CombatSeed.PartyId;
	Out.BanIndices = CombatSeed.BanIndices;
	Out.JokerInfo = JokerInfo;

	ClientNetwork.WsRequest(TEXT("dev/sagaStageBegin"), Out,
		TQ6ResponseDelegate<FL2CSagaStageBeginResp>::CreateUObject(
			const_cast<USagaManager*>(this), &USagaManager::OnStageBeginResp));
}

void USagaManager::ReqDevStoryStageClear(FSagaType SagaType) const
{
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	FC2LDevSagaStoryStageClear Out;
	Out.Type = SagaType;

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance))
	{
		LobbyHUD->ChangeHUDType(EHUDWidgetType::Dialogue);
	}

	ClientNetwork.WsRequest(TEXT("dev/sagaStoryStageClear"), Out,
		TQ6ResponseDelegate<FL2CSagaStoryStageClearResp>::CreateUObject(
			const_cast<USagaManager*>(this), &USagaManager::OnStoryStageClearResp));
}
#endif

/////////////////////////////////////////////////////////////////////////////
// Setter

void USagaManager::UpdateSagaHistory(FSagaType Type)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Type);
	if (SagaRow.ContentType == EContentType::Saga)
	{
		if (LastType < Type)
		{
			LastType = Type;
			Q6JsonLogHekel(Verbose, "LastSagaType", Q6KV("Type", Type));
		}
	}
}

bool USagaManager::IsStageCleared(int32 InEpisode, int32 InStage, int32 InSubStage) const
{
	UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSagaRow& InLastSagaRow = CMS->GetSagaRowOrDummy(LastType);
	if (InLastSagaRow.Episode != InEpisode)
	{
		return InLastSagaRow.Episode > InEpisode;
	}

	if (InLastSagaRow.Stage != InStage)
	{
		return InLastSagaRow.Stage > InStage;
	}

	return InLastSagaRow.SubStage >= InSubStage;
}

bool USagaManager::IsEpisodeCleared(int32 InEpisode) const
{
	UCMS* CMS = GetCMS();
	check(CMS);

	FSagaType EpisodeClearSagaType = CMS->GetEpisodeClearSagaType(InEpisode);
	return (LastType >= EpisodeClearSagaType);
}

bool USagaManager::IsEpisodeClearingSagaType(FSagaType SagaType) const
{
	UCMS* CMS = GetCMS();
	check(CMS);

	int32 Episode = CMS->GetSagaRowOrDummy(SagaType).Episode;
	FSagaType EpisodeClearSagaType = CMS->GetEpisodeClearSagaType(Episode);

	if (SagaType == SagaTypeInvalid || EpisodeClearSagaType == SagaTypeInvalid)
	{
		return false;
	}

	return (SagaType == EpisodeClearSagaType);
}

int32 USagaManager::GetPlayingEpisode() const
{
	if (LastType == SagaTypeInvalid)
	{
		return 0;
	}

	UCMS* CMS = GetCMS();
	check(CMS);

	int32 PlayingEpisode = CMS->GetSagaRowOrDummy(LastType).Episode;
	TArray<const FCMSSagaRow*> Stages = CMS->GetStageRows(EContentType::Saga, PlayingEpisode);

	const FCMSSagaRow* LastStage = nullptr;
	if (Stages.Num() > 0)
	{
		LastStage = Stages.Last();
	}

	if (LastStage && LastStage->CmsType() == LastType)
	{
		TArray<int32> Episodes = CMS->GetEpisodes(EContentType::Saga);

		int32 CurrIndex = INDEX_NONE;
		if (Episodes.Find(PlayingEpisode, CurrIndex))
		{
			if (CurrIndex + 1 < Episodes.Num())
			{
				return Episodes[CurrIndex + 1];
			}
			else
			{
				return PlayingEpisode + 1;
			}
		}
	}

	return PlayingEpisode;
}

/////////////////////////////////////////////////////////////////////////////
// USagaManager HUDStore Action

void USagaManager::RegisterActionHandlers()
{
	REGISTER_ACTION_HANDLER(USagaManager, SagaLoadResp);
	REGISTER_ACTION_HANDLER(USagaManager, DevStageClearResp);
	REGISTER_ACTION_HANDLER(USagaManager, SagaStageEndResp);
	REGISTER_ACTION_HANDLER(USagaManager, SagaStoryStageClearResp);
}

IMPLEMENT_ACTION_HANDLER(USagaManager, SagaLoadResp)
{
	auto Action = ACTION_PARSE_SagaLoadResp(InAction);

	auto& Resp = Action->GetVal();

	UpdateSagaHistory(Resp.History.Type);

	return true;
}

IMPLEMENT_ACTION_HANDLER(USagaManager, DevStageClearResp)
{
	auto Action = ACTION_PARSE_DevStageClearResp(InAction);
	auto& Resp = Action->GetVal();
	UpdateSagaHistory(Resp.Type);
	return true;
}

IMPLEMENT_ACTION_HANDLER(USagaManager, SagaStageEndResp)
{
	auto Action = ACTION_PARSE_SagaStageEndResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateSagaHistory(Resp.Type);
	return true;
}

IMPLEMENT_ACTION_HANDLER(USagaManager, SagaStoryStageClearResp)
{
	auto Action = ACTION_PARSE_SagaStoryStageClearResp(InAction);
	auto& Resp = Action->GetVal();

	UpdateSagaHistory(Resp.Type);
	return true;
}