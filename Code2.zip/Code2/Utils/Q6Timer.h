// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Engine/EngineTypes.h"
#include "Q6GameInstance.h"

struct FQ6TimerHandle
{
	uint64 Handle;

	FQ6TimerHandle() : Handle(0) {}

	bool IsValid() const
	{
		return Handle != 0;
	}

	void Invalidate()
	{
		Handle = 0;
	}

	bool operator==(const FQ6TimerHandle& Other) const
	{
		return Handle == Other.Handle;
	}

	bool operator!=(const FQ6TimerHandle& Other) const
	{
		return Handle != Other.Handle;
	}
};


struct FQ6TimerData
{
	/** If true, this timer will loop indefinitely.  Otherwise, it will be destroyed when it expires. */
	uint8 bLoop;

	/** Time between set and fire, or repeat frequency if looping. */
	int64 RateTicks;

	int64 ExpireDateTimeTicks;

	/** Holds the delegate to call. */
	FTimerUnifiedDelegate TimerDelegate;

	FQ6TimerHandle TimerHandle;

	FQ6TimerData()
		: bLoop(false)
		, RateTicks(0)
		, ExpireDateTimeTicks(0)
	{}

	/** Operator less, used to sort the heap based on time until execution. **/
	bool operator<(const FQ6TimerData& Other) const
	{
		return ExpireDateTimeTicks < Other.ExpireDateTimeTicks;
	}

	void Clear()
	{
		TimerDelegate.Unbind();
		TimerHandle.Invalidate();
	}
};

struct FQ6TimerManager
{
public:
	FQ6TimerManager(UQ6GameInstance* InGameInstance);
	~FQ6TimerManager();

	bool Tick(float DeltaTime);

	template< class UserClass >
	FORCEINLINE void SetTimer(FQ6TimerHandle& InOutHandle, UserClass* InObj, typename FTimerDelegate::TUObjectMethodDelegate< UserClass >::FMethodPtr InTimerMethod, float InRate, bool InbLoop, float InFirstDelay = -1.f)
	{
		InternalSetTimer(InOutHandle, FTimerUnifiedDelegate(FTimerDelegate::CreateUObject(InObj, InTimerMethod)), InRate, InbLoop, InFirstDelay);
	}

	template< class UserClass >
	FORCEINLINE void SetTimer(FQ6TimerHandle& InOutHandle, UserClass* InObj, typename FTimerDelegate::TUObjectMethodDelegate_Const< UserClass >::FMethodPtr InTimerMethod, float InRate, bool InbLoop, float InFirstDelay = -1.f)
	{
		InternalSetTimer(InOutHandle, FTimerUnifiedDelegate(FTimerDelegate::CreateUObject(InObj, InTimerMethod)), InRate, InbLoop, InFirstDelay);
	}

	FORCEINLINE void SetTimer(FQ6TimerHandle& InOutHandle, FTimerDelegate const& InDelegate, float InRate, bool InbLoop, float InFirstDelay = -1.f)
	{
		InternalSetTimer(InOutHandle, FTimerUnifiedDelegate(InDelegate), InRate, InbLoop, InFirstDelay);
	}

	FORCEINLINE void SetTimer(FQ6TimerHandle& InOutHandle, FTimerDynamicDelegate const& InDelegate, float InRate, bool InbLoop, float InFirstDelay = -1.f)
	{
		InternalSetTimer(InOutHandle, FTimerUnifiedDelegate(InDelegate), InRate, InbLoop, InFirstDelay);
	}

	FORCEINLINE void SetTimer(FQ6TimerHandle& InOutHandle, TFunction<void(void)>&& InDelegate, float InRate, bool InbLoop, float InFirstDelay = -1.f)
	{
		InternalSetTimer(InOutHandle, FTimerUnifiedDelegate(MoveTemp(InDelegate)), InRate, InbLoop, InFirstDelay);
	}

	bool IsTimerActive(FQ6TimerHandle InHandle) const;

	void ClearTimer(const FQ6TimerHandle& InHandle, bool bReserve = false);

private:

	void InternalSetTimer(FQ6TimerHandle& InOutHandle, FTimerUnifiedDelegate && InDelegate, float InRate, bool InbLoop, float InFirstDelay = -1.f);

	void ValidateTimerHandle(FQ6TimerHandle& InOutHandle);

	TArray<FQ6TimerData> Q6TimerList;
	TArray<FQ6TimerHandle> Q6ClearTimerReservedList;

	uint64 LastAssignedQ6TimerHandle;

	UQ6GameInstance* GameInstance;

};