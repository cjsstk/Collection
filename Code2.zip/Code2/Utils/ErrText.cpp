#include "ErrText.h"

#include "CMS_gen.h"


FString OnErrNoParam(UCMS* CMS, FErrTextType ErrType)
{
	const FCMSErrTextRow& Row = CMS->GetErrTextRowOrDummy(ErrType);
	return Row.Text;
}

int32 GetExtraAt(int32 idx, const TArray<int32>& Extra)
{
	if (idx < 0 || idx >= Extra.Num())
	{
		return 0;
	}

	return Extra[idx];
}

FString OnErrAddXp(UCMS* CMS, FErrTextType ErrType, const FString& UserName, const TArray<int32>& Extra)
{
	int32 Xp = GetExtraAt(0, Extra);
	const FCMSErrTextRow& Row = CMS->GetErrTextRowOrDummy(ErrType);
	FFormatNamedArguments Args;
	Args.Add(TEXT("USER_NAME"), FText::FromString(UserName));
	Args.Add(TEXT("XP"), FText::FromString(FString::FromInt(Xp)));
	FText ShowText = FText::Format(FText::FromString(Row.Text), Args);
	return ShowText.ToString();
}

FString OnErrCharacterUpdate(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra)
{
	int32 CharType = GetExtraAt(0, Extra);
	const FCMSErrTextRow& ErrRow = CMS->GetErrTextRowOrDummy(ErrType);
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(FCharacterType(CharType));
	FFormatNamedArguments Args;
	Args.Add(TEXT("CHAR_NAME"), UnitRow.DescName);
	FText ShowText = FText::Format(FText::FromString(ErrRow.Text), Args);
	return ShowText.ToString();
}

FString OnErrParam2(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra)
{
	const FCMSErrTextRow& Row = CMS->GetErrTextRowOrDummy(ErrType);
	FFormatNamedArguments Args;
	Args.Add(TEXT("0"), FText::FromString(FString::FromInt(GetExtraAt(0, Extra))));
	Args.Add(TEXT("1"), FText::FromString(FString::FromInt(GetExtraAt(1, Extra))));
	FText ShowText = FText::Format(FText::FromString(Row.Text), Args);
	return ShowText.ToString();
}

FString OnErrParam1(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra)
{
	const FCMSErrTextRow& Row = CMS->GetErrTextRowOrDummy(ErrType);
	FFormatNamedArguments Args;
	Args.Add(TEXT("0"), FText::FromString(FString::FromInt(GetExtraAt(0, Extra))));
	FText ShowText = FText::Format(FText::FromString(Row.Text), Args);
	return ShowText.ToString();
}

FString OnNotEnoughMaterial(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra)
{
	int32 ItemType = GetExtraAt(0, Extra);
	const FCMSBagItemRow& ItemRow = CMS->GetBagItemRowOrDummy(FBagItemType(ItemType));
	FFormatNamedArguments Args;
	Args.Add(TEXT("ITEM_NAME"), ItemRow.DescName);

	const FCMSErrTextRow& Row = CMS->GetErrTextRowOrDummy(ErrType);
	FText ShowText = FText::Format(FText::FromString(Row.Text), Args);
	return ShowText.ToString();
}
