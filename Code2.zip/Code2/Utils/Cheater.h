#pragma once

#if !UE_BUILD_SHIPPING

#include "Engine.h"

enum class ESkillCategory : uint8;
enum class ECurrencyType : uint8;

class UQ6GameInstance;

struct FCharacterId;

class FCheater
{
public:

	FCheater();
	~FCheater();

	void Init(UQ6GameInstance* InGameInstance);
	void Shutdown();

private:
	void OpenCheatCommandHelpPopup();

	void DevMode(const TArray<FString>& Args);
	void Test(const TArray<FString>& Args);
	void AddXp(const TArray<FString>& Args);
	void AddFreeGem(const TArray<FString>& Args);
	void AddPaidGem(const TArray<FString>& Args);
	void AddSummonTicket(const TArray<FString>& Args);
	void AddSculpturePoint(const TArray<FString>& Args);
	void AddRelicPoint(const TArray<FString>& Args);
	void AddFriendshipPoint(const TArray<FString>& Args);
	void AddGold(const TArray<FString>& Args);
	void AddBattery(const TArray<FString>& Args);
	void SelfKick(const TArray<FString>& Args);
	void BondAdd(const TArray<FString>& Args);
	void RaidOpen(const TArray<FString>& Args);
	void RaidPrepare(const TArray<FString>& Args);
	void RaidEnd(const TArray<FString>& Args);
	void RaidSkillUse(const TArray<FString>& Args);
	void RaidRegister(const TArray<FString>& Args);
	void RaidPass(const TArray<FString>& Args);
	void RaidUseEmoticon(const TArray<FString>& Args);
	void RaidShareParty(const TArray<FString>& Args);
	void RegularRaidRegister(const TArray<FString>& Args);
	void RegularRaidReady(const TArray<FString>& Args);
	void CharacterNew(const TArray<FString>& Args);
	void CharacterAll(const TArray<FString>& Args);
	void CharacterDel(const TArray<FString>& Args);
	void CharacterMod(const TArray<FString>& Args);
	void CharacterApiTest(const TArray<FString>& Args);
	void CharacterCheatUltimateSkillLevel(const TArray<FString>& Args);
	void CharacterCheatSupportSkillLevel(const TArray<FString>& Args);
	void CharacterCheatTurnSkillLevel(const TArray<FString>& Args);
	void CharacterTurnSkillLevel(const TArray<FString>& Args);
	void CharacterUltimateSkillLevel(const TArray<FString>& Args);
	void BagItemNew(const TArray<FString>& Args);
	void BagItemDel(const TArray<FString>& Args);
	void BagItemMod(const TArray<FString>& Args);
	void RelicNew(const TArray<FString>& Args);
	void RelicDel(const TArray<FString>& Args);
	void RelicMod(const TArray<FString>& Args);
	void RelicApiTest(const TArray<FString>& Args);
	void SculptureNew(const TArray<FString>& Args);
	void SculptureDel(const TArray<FString>& Args);
	void SculptureMod(const TArray<FString>& Args);
	void ActRecordNew(const TArray<FString>& Args);
	void ActRecordDel(const TArray<FString>& Args);
	void ActRecordMod(const TArray<FString>& Args);
	void CodexClearNew(const TArray<FString>& Args);
	void DailyClockMod(const TArray<FString>& Args);
	void DailyList(const TArray<FString>& Args);
	void PartySave(const TArray<FString>& Args);
	void PartyPetSave(const TArray<FString>& Args);
	void SpecialClear(const TArray<FString>& Args);
	void SpecialOpen(const TArray<FString>& Args);
	void StageClear(const TArray<FString>& Args);
	void WattRecharge(const TArray<FString>& Args);
	void WattConsume(const TArray<FString>& Args);
	void TrainingCenterClear(const TArray<FString>& Args);
	void TrainingCenterReset(const TArray<FString>& Args);
	void PyramidOpen(const TArray<FString>& Args);
	void PyramidPortalConnect(const TArray<FString>& Args);
	void PyramidPortalBoostUse(const TArray<FString>& Args);
	void PyramidUpgrade(const TArray<FString>& Args);
	void PyramidPortalClear(const TArray<FString>& Args);
	void PyramidPortalWarp(const TArray<FString>& Args);
	void TempleOpen(const TArray<FString>& Args);
	void TempleUpgrade(const TArray<FString>& Args);
	void TempleArtifactsReset(const TArray<FString>& Args);
	void TempleArtifactUpgrade(const TArray<FString>& Args);
	void TempleArtifactUse(const TArray<FString>& Args);
	void PowerPlantOpen(const TArray<FString>& Args);
	void PowerPlantUpgrade(const TArray<FString>& Args);
	void PetParkOpen(const TArray<FString>& Args);
	void PetParkUpgrade(const TArray<FString>& Args);
	void PetSkillUpgrade(const TArray<FString>& Args);
	void PetNew(const TArray<FString>& Args);
	void VacationOpen(const TArray<FString>& Args);
	void VacationUpgrade(const TArray<FString>& Args);
	void SmelterOpen(const TArray<FString>& Args);
	void SmelterInc(const TArray<FString>& Args);
	void SmelterDec(const TArray<FString>& Args);
	void SmelterReceive(const TArray<FString>& Args);
	void SmelterUpgrade(const TArray<FString>& Args);
	void SmelterTime(const TArray<FString>& Args);
	void SmelterUpgradeComplete(const TArray<FString>& Args);
	void AlchemylabOpen(const TArray<FString>& Args);
	void AlchemylabInc(const TArray<FString>& Args);
	void AlchemylabDec(const TArray<FString>& Args);
	void AlchemylabReceive(const TArray<FString>& Args);
	void AlchemylabUpgrade(const TArray<FString>& Args);
	void AlchemylabTime(const TArray<FString>& Args);
	void GotoDialogue(const TArray<FString>& Args);
	void SkillNoteFix(const TArray<FString>& Args);
	void SkillNoteShuffle(const TArray<FString>& Args);
	void MailSend(const TArray<FString>& Args);
	void CheckInDay(const TArray<FString>& Args);
	void ShopReset(const TArray<FString>& Args);
	void TempleProduce(const TArray<FString>& Args);
	void PetParkProduce(const TArray<FString>& Args);
	void AddLumicube(const TArray<FString>& Args);
	void AddCharacterDisk(const TArray<FString>& Args);
	void AddSculptureDisk(const TArray<FString>& Args);
	void AddRelicDisk(const TArray<FString>& Args);
	void WeeklyMissionReward(const TArray<FString>& Args);
	void CharMissionReward(const TArray<FString>& Args);
	void WeeklyMissionBingo(const TArray<FString>& Args);
	void WeeklyMissionShuffle(const TArray<FString>& Args);
	void WeeklyMissionReset(const TArray<FString>& Args);
	void UserRecordList(const TArray<FString>& Args);
	void SetSummonMileage(const TArray<FString>& Args);
	void CharMissionSet(const TArray<FString>& Args);
	void LobbyTemplateNew(const TArray<FString>& Args);
	void JokerSetCharacterSave(const TArray<FString>& Args);
	void FriendAdd(const TArray<FString>& Args);
	void FriendBotAll(const TArray<FString>& Args);
	void FriendCooltimeSet(const TArray<FString>& Args);
	void SummonCountSet(const TArray<FString>& Args);
	void CheckInOpenTime(const TArray<FString>& Args);
	void TitleAdd(const TArray<FString>& Args);
	void TitleChange(const TArray<FString>& Args);
	void ShopBuy(const TArray<FString>& Args);
	void ContentFeatureOpen(const TArray<FString>& Args);
	void EventContentReward(const TArray<FString>& Args);
	void EventContentNumberOfDays(const TArray<FString>& Args);
	void EventContentMultiSideBattleLoad(const TArray<FString>& Args);
	void EventContentMultiSideBattleReceiveRankReward(const TArray<FString>& Args);
	void EventContentAddPoint(const TArray<FString>& Args);
	void EventContentRechargeWatt(const TArray<FString>& Args);
	void EventContentRouletteReset(const TArray<FString>& Args);
	void AvatarAdd(const TArray<FString>& Args);
	void FriendBookFeedAdd(const TArray<FString>& Args);
	void FriendBookReactionAdd(const TArray<FString>& Args);
	void FriendBookReactionRemove(const TArray<FString>& Args);
	void FriendBookFeedLoad(const TArray<FString>& Args);
	void FriendBookTimelineLoad(const TArray<FString>& Args);

	void CheatSkillLevelInternal(const FCharacterId& InCharacterId, ESkillCategory InCategory, int32 InSkillLevel, int32 InTurnSkillIndex);
	void AddCurrencyInternal(ECurrencyType CurrencyType, int32 GainValue);

	void LoadCommandHistory();
	void SaveCommandHistory();

	void AddCommandHistory(const FString& Command, const TArray<FString>& Args);

	FString GetCommandHistoryFilePath() { return FPaths::ProjectSavedDir() / "CommandHistory.txt"; }

	UQ6GameInstance* GameInstance;
	TArray<IConsoleObject*> CheatObjects;
	TArray<IConsoleObject*> ShortcutObjects;
	IConsoleObject* HelpObject;

	TArray<FString> CommandHistory;
};

#endif //!UE_BUILD_SHIPPING