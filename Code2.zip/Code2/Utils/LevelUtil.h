// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"

#include "GameResource.h"
#include "LevelUtil.generated.h"

class ACombatLocator;
class ALevelSequenceActor;
class AResultLocator;
class ACameraLayerActor;
class USkeletalMesh;
class UFileMediaSource;


UCLASS(MinimalAPI)
class USimpleCallback : public UObject
{
	GENERATED_BODY()

public:
	UFUNCTION()
	void OnExecute();

	void SetCallback(FSimpleDelegate InDelegate) {Delegate = InDelegate;}

private:
	FSimpleDelegate Delegate;
};

/**
 * Helper functions related to level (map)
 */
UCLASS()
class Q6_API ULevelUtil : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	static void LoadLoginLevel(const UWorld* World);
	static void LoadLobbyLevel(const UWorld* World);
	static void LoadSummonLevel(const UWorld* World);
	static void LoadSagaLevel(const UWorld* World, FSagaType SagaType);
	static void LoadSagaLightPreset(const UWorld* World, const FString& LightPreset);
	static void LoadSagaLevelEffect(const UWorld* World, int32 Episode, int32 Stage, int32 Wave);
	static void LoadSkeletalMesh(USkeletalMeshComponent* SkelMeshComp, const FUnitModelAssetRow& Row, int32 ModelType, bool bDestroyOwnerParticles, bool bOverrideMaterial = false, bool bSubDissolveMaterialClear = true, bool bSpawnParticle = true);
	static class AQ6Capture2D* FindCaptureActor(const UWorld* World, FName Tag);
	static void BindMeshModel(const UWorld* World, AQ6Capture2D* CaptureActor, int ModelType);
	static void SetCurrentCaptureActor(const UWorld* World, bool bEnable, FName Tag);

	static ACombatLocator* FindCombatLocator(const UWorld* World, int32 Group, int32 Wave, ECombatMultiSide CombatMultiSide = ECombatMultiSide::Main);
	static ACameraLayerActor* FindCameraLayerActor(const UWorld* World, ECameraLayerIndex layer);
	static AResultLocator* FindResultLocator(const UWorld* World);

	static void EmptyLocators(UWorld* World);

	static int32 ConvertSlot3to5(int32 Slot, int32 NumSlots, bool bForceDefault);
	static void LoadZoneAttribute(const UWorld* World);
#if WITH_EDITOR
	/**
	* Build things
	*/
	static void BuildCombatCameraCulling(const UWorld* World);
#endif // WITH_EDITOR

	static void LayerActorVisibilityChange(const UWorld* World, FName LayerName);

	static void PlayMovie(int32 Episode, int32 Stage, int32 SubStage, FSimpleDelegate InFinishedCallback = FSimpleDelegate());

	UFUNCTION(BlueprintCallable, Category = Movie)
	static void PlayMovie(UFileMediaSource* FileMeidaSource);
};