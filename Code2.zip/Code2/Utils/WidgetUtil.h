// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "HUD/Q6UIDefine.h"
#include "Layout/Geometry.h"
#include "LobbyObj_gen.h"
#include "Q6Enum.h"
#include "Q6UIDefine.h"
#include "Q6Minimal.h"
#include "WidgetUtil.generated.h"

class UWidgetAnimation;
class UCMS;
class UUserWidget;
class UWidget;
class UImage;
struct FCharacterId;
struct FCMSPromoteCostRow;
struct FCMSSagaRow;
struct FItemIconInfo;
struct FUnitType;
struct FRelicType;
struct FSummonInfo;

enum class ENatureType : uint8;
enum class EUpgradeCategory : uint8;
enum class EStageType : uint8;
enum class ESlateVisibility : uint8;
enum class EDetailItemType : uint8;
enum class ERewardType : uint8;
enum class ESagaRewardType : uint8;

// Z-Order

const static int32 ZORDER_BELOW_HUD = 100;

const static int32 ZORDER_HUDWIDGET = 200;
const static int32 ZORDER_SELL_SHOP_WIDGET = 202;
const static int32 ZORDER_EVENT_SHOP_WIDGET = 203;
const static int32 ZORDER_STAGE_TITLE = 204;
const static int32 ZORDER_EPISODE_TITLE = 205;
const static int32 ZORDER_BAR = 210;
const static int32 ZORDER_CLEAR_UI = 290;
const static int32 ZORDER_BLACKOUT = 300;
const static int32 ZORDER_DIALOGUE_SKIP = 310;
const static int32 ZORDER_SKILL_ANIMATION = 550;
const static int32 ZORDER_POPUP = 800;
const static int32 ZORDER_NOTIFICATION = 810;
const static int32 ZORDER_MISSION_TOAST = 820;
const static int32 ZORDER_TUTORIAL = 890;
const static int32 ZORDER_ERROR_POPUP = 900;

const static int32 ZORDER_DEBUG = 1000;

const static int32 ZORDER_TOUCH_EFFECT = 10000;
const static int32 ZORDER_MEDIA_PLAYER = 10100;

bool SetWidgetVisibilityFromName(UUserWidget* Parent, FName WidgetName, ESlateVisibility Visibility);
UWidgetAnimation* GetWidgetAnimationFromName(UUserWidget* Widget, FName AnimationName);
UWidgetAnimation* GetNullableWidgetAnimationFromName(UUserWidget* Widget, FName AnimationName);
bool FindWidgetGeometry(const UWidget* Widget, FGeometry* OutGeometry);

TArray<FCharacterId> GetPreciousCharacters(const UCMS* CMS, const TArray<FCharacterId>& CharacterIds);
bool HasPreciousItem(const UCMS* CMS, EUpgradeCategory ItemCategory, const TArray<int64>& CharacterIds);
bool HasHighTierEquip(const UCMS* CMS, EUpgradeCategory ItemCategory, int32 BaseTier, const TArray<int64>& EquipIds);
bool HasHighUltLevel(const UCMS* CMS, int32 BaseLevel, const TArray<int64>& CharacterIds);
bool CanCharacterMaxLevelUp(const FCMSPromoteCostRow& PromoteCostRow);
bool CanRelicPromote(const UCMS* CMS, int32 CurrentStar);
bool CanSculpturePromote(const UCMS* CMS, int32 CurrentStar);
bool CanTierUpgrade(int32 CurrentTier, int32 TargetTier);
bool CanItemPromote(const FCMSPromoteCostRow& PromoteCostRow);
bool CanCharacterEvolute(const UCMS* CMS, int32 Moon, EItemGrade ItemGrade);
bool CanTurnSkillUpgrade(const UCMS* CMS, const FCharacterId& CharacterID);
bool CanTurnSkillUpgrade(const UCMS* CMS, const FCharacterId& CharacterId, int32 TurnSkillIndex);
bool CanUltimateSkillUpgrade(const UCMS* CMS, int32 CurrentLevel, int32 TargetLevel);

void ConvertCharacterToItemInfo(EAttributeCategory AttributeType, const FCharacterInfo& CharacterInfo, const FCharacterBond& CharacterBond, FItemIconInfo* OutInfo);
void ConvertSculptureToItemInfo(const FSculptureInfo& SculptureInfo, FItemIconInfo* OutInfo);
void ConvertRelicToItemInfo(const FRelicInfo& RelicInfo, FItemIconInfo* OutInfo);

void MakeDefaultCharacterItemInfo(const FCMSCharacterRow& CharacterRow, FItemIconInfo* OutInfo);
void MakeDefaultRelicItemInfo(const FCMSRelicRow& RelicRow, FItemIconInfo* OutInfo);
void MakeDefaultSculptureItemInfo(const FCMSSculptureRow& SculptureRow, FItemIconInfo* OutInfo);

EPointType GetPointType(ESummonPointType InPointType);
EPointType GetPointType(ECurrencyType InCurrencyType);
EPointType GetPointType(ELootCategory InLootCategory);
ECurrencyType GetCurrencyType(ELootCategory ItemCategory);
bool IsCollectionCategory(ELootCategory InLootCategory);

EDayOfWeek ConvertDayOfWeekTypeToUE4(EDayOfWeekType DayOfWeek);
EDayOfWeekType ConvertDayOfWeekType(EDayOfWeek DayOfWeek);
EDayOfWeekType GetTodayOfWeek(int32 ClockModValue = 0);

ERewardType GetRewardType(ESagaRewardType RewardType);

FText MakeStageNumberText(const FCMSSagaRow& SagaRow);
bool IsStoryLikeStageType(EStageType StageType);
bool IsEventContentType(EContentType ContentType);

FString GetEquipEffectsStr(int32 Tier, const TArray<const FCMSBuffRow*>& Buffs);

EDialogueType ConvertToDialogueType(EContentType ContentType);

EWonderCategory GetWonderCategory(ESpecialCategory SpecialCategory);
EWonderCategory GetWonderCategory(ELootCategory LootCategory);
EWonderCategory GetWonderCategory(EFeatureOpenType FeatureOpenType);

EFeatureOpenType GetFeatureOpenType(EWonderCategory WonderCategory);

FText GetWonerNameText(EWonderCategory WonderCategory);

////////////////////////////////////
FText BuildToolTipDesc(int32 SkillType, int32 SkillLevelOrTier, ESkillCategory BornCategory, bool bSimpleNotice = false);
FText BuildToolTipBuffEffectDesc(FBuffEffectType BuffEffectType, int32 BuffLevel, ESkillCategory BornCategory, bool bSimpleNotice = false);
FText BuildBuffEffectName(FBuffEffectType BuffEffectType, bool bSimpleNotice = false);

FCharacterBond MakeDefaultCharacterBond(const UCMS* CMS, FCharacterType CharacterType);

EDetailItemType GetItemFrameType(const FSummonInfo& SummonInfo);
EDetailItemType GetItemFrameType(const FItemIconInfo& InItemInfo);

EDetailItemType GetItemFrameType(const FCharacterType CharacterType);
EDetailItemType GetItemFrameType(const FSculptureType SculptureType);
EDetailItemType GetItemFrameType(const FRelicType RelicType);

int32 GetTurnSkillLevel(const FCharacterInfo& Info, int32 SkillIndex);
int32 GetUpgradedTurnSkillIndex(const FCharacterInfo& NewInfo, const FCharacterInfo& OldInfo);

void SetNewMark(UImage* NewMarkImage, ENewMarkType NewMarkType);

UENUM()
enum class EToolTipSheet : uint8
{
	SkillEffect,
	BuffEffect,
	BuffDuration,
	BuffHitCount,
};

UENUM()
enum class EToolTipUnit : uint8
{
	Integer,
	Percent,
};

USTRUCT()
struct FToolTipElement
{
	GENERATED_USTRUCT_BODY()
	FToolTipElement() : Sheet(EToolTipSheet::SkillEffect), Type(0), ParamIdx(2), Unit(EToolTipUnit::Integer) {}

	UPROPERTY()
	EToolTipSheet Sheet;

	UPROPERTY()
	int32 Type;

	UPROPERTY()
	int32 ParamIdx;

	UPROPERTY()
	EToolTipUnit Unit;
};

USTRUCT()
struct FToolTipDesc
{
	GENERATED_USTRUCT_BODY()
	FToolTipDesc() {}

	UPROPERTY()
	TArray<FToolTipElement> Elements;

	UPROPERTY()
	FString Msg;
};
