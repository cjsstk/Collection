// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6Log.h"
#include "HAL/IConsoleManager.h"
#include "HAL/MemoryMisc.h"
#include "JsonObjectConverter.h"
#include "UltimateMobileKit.h"
#include "HttpModule.h"
#include "Q6Util.h"
#include "VersionNumber.h"

#if (!NO_LOGGING)
DEFINE_LOG_CATEGORY(Q6);
DEFINE_LOG_CATEGORY(Q6_AUTO);
DEFINE_LOG_CATEGORY(Q6_NET);
DEFINE_LOG_CATEGORY(Q6_CMS);
DEFINE_LOG_CATEGORY(Q6_CHEATER);
DEFINE_LOG_CATEGORY(Q6_SUNNY);
DEFINE_LOG_CATEGORY(Q6_BRO);
DEFINE_LOG_CATEGORY(Q6_ROZE);
DEFINE_LOG_CATEGORY(Q6_MILD);
DEFINE_LOG_CATEGORY(Q6_KALMS);
DEFINE_LOG_CATEGORY(Q6_OBIWAN);
DEFINE_LOG_CATEGORY(Q6_HEKEL);
DEFINE_LOG_CATEGORY(Q6_MOON);
DEFINE_LOG_CATEGORY(Q6_GUNNY);
DEFINE_LOG_CATEGORY(Q6_ZAGAL);
DEFINE_LOG_CATEGORY(Q6_GENIE);
DEFINE_LOG_CATEGORY(Q6_PAUL);
DEFINE_LOG_CATEGORY(Q6_MEDRIAN5);
DEFINE_LOG_CATEGORY(Q6_PAWN);
#endif

#if (!UE_BUILD_SHIPPING)
TAutoConsoleVariable<FString> CVarQ3LogUrl(
	TEXT("q6.LogUrl"),
	TEXT(""), //not working http://q6.xlgames.corp:8081
	TEXT("URL to send Q6 client logs\n"),
	ECVF_Default);
#endif

TAutoConsoleVariable<int32> CVarLogMemoryStats(
	TEXT("q6.logMemoryStats"),
#if PLATFORM_ANDROID || PLATFORM_IOS
	0,
#else
	0,
#endif
	TEXT("Add memory stats to every Q6 logs"),
	ECVF_Cheat);

#if PLATFORM_ANDROID || PLATFORM_IOS
#define GET_INITIALIZED_FIREBASE_INTERNAL(firebase, target) F##firebase##target * GetInitialized##firebase##target() \
{ \
	FUltimateMobileKit* UltimateMobileKit = FUltimateMobileKit::Get(); \
	if (!UltimateMobileKit) { return nullptr; } \
	TSharedPtr<F##firebase##target, ESPMode::ThreadSafe> InFirebase = UltimateMobileKit->Get##firebase##target(); \
	if (InFirebase.IsValid()) { \
		if (!InFirebase->IsInitialized()) { InFirebase->Init(); } \
		return InFirebase.Get(); \
	} \
	return nullptr; \
}

#define GET_INITIALIZED_FIREBASE(target) GET_INITIALIZED_FIREBASE_INTERNAL(Firebase, target)

GET_INITIALIZED_FIREBASE(Crashlytics);
GET_INITIALIZED_FIREBASE(Analytics);
#else
FFirebaseCrashlytics* GetInitializedFirebaseCrashlytics() { return nullptr; }
FFirebaseAnalytics* GetInitializedFirebaseAnalytics() { return nullptr; }
#endif

#if (!UE_BUILD_SHIPPING)
void Q6SendJsonLogToLogstachServer(int32 LogPriority, const FString& JsonString)
{
	static FString Q6LogUrlString = CVarQ3LogUrl.GetValueOnAnyThread();
	if (Q6LogUrlString.IsEmpty()) {
		return;
	}

	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<TCHAR>> Reader = TJsonReaderFactory<>::Create(JsonString);
	bool bResult = FJsonSerializer::Deserialize(Reader, JsonObject);
	ensure(bResult);

	JsonObject->SetStringField(TEXT("Revision"), FString(BUILD_VERSION_SHORT_STRING));
	JsonObject->SetStringField(TEXT("PlatformUserName"), FString(FPlatformProcess::UserName()));
	JsonObject->SetStringField(TEXT("Platform"), FString(FPlatformProperties::IniPlatformName()));
	JsonObject->SetStringField(TEXT("Device"), Q6Util::GetDeviceModel());
	JsonObject->SetStringField(TEXT("Installed"), FApp::IsEngineInstalled() ? FString("Yes") : FString("No"));

	FString AugmentedJsonString;
	TSharedRef<TJsonWriter<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>> Writer =
		TJsonWriterFactory<TCHAR, TCondensedJsonPrintPolicy<TCHAR>>::Create(&AugmentedJsonString);
	bResult = FJsonSerializer::Serialize(JsonObject.ToSharedRef(), Writer);
	ensure(bResult);

	TSharedRef<IHttpRequest> SendJsonRequest = (&FHttpModule::Get())->CreateRequest();
	SendJsonRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	SendJsonRequest->SetURL(CVarQ3LogUrl.GetValueOnAnyThread());
	SendJsonRequest->SetVerb("POST");
	SendJsonRequest->SetContentAsString(AugmentedJsonString);
	SendJsonRequest->ProcessRequest();
}
#endif

void Q6SendJsonLogToServer(int32 LogPriority, const FString& JsonString)
{
#if PLATFORM_ANDROID || PLATFORM_IOS
	FFirebaseCrashlytics* FirebaseCrashlytics = GetInitializedFirebaseCrashlytics();
	if (FirebaseCrashlytics)
	{
		FirebaseCrashlytics->WriteLogWithTagAndPriority(JsonString, "Q6", LogPriority);
		//FirebaseCrashlytics->WriteLog(JsonString);
	}
#endif
#if (!UE_BUILD_SHIPPING)
	Q6SendJsonLogToLogstachServer(LogPriority, JsonString);
#endif
}

void Q6SetUserNameToFirebaseCrashlytics(const FString& InUserName)
{
#if PLATFORM_ANDROID || PLATFORM_IOS
	FFirebaseCrashlytics* FirebaseCrashlytics = GetInitializedFirebaseCrashlytics();
	if (FirebaseCrashlytics)
	{
		FirebaseCrashlytics->SetUsername(InUserName);
	}
#endif
}

void Q6SetStringToFirebaseCrashlytics(const FString& InKey, const FString& InValue)
{
#if PLATFORM_ANDROID || PLATFORM_IOS
	FFirebaseCrashlytics* FirebaseCrashlytics = GetInitializedFirebaseCrashlytics();
	if (FirebaseCrashlytics)
	{
		FirebaseCrashlytics->SetString(InKey, InValue);
	}
#endif
}

FString Q6MakeJsonLogInteralWriteValue_ObjectToString(const UStruct* StructDefinition, const void* Struct)
{
	FString String;
	FJsonObjectConverter::UStructToJsonObjectString(StructDefinition, Struct, String, 0ll, 0ll, 0, nullptr, false);
	return MoveTemp(String);
}

void Q6MakeJsonLogPost(int32 LogPriority, const FString& JsonString, TJsonWriter<TCHAR, Q6JsonLogPrintPolicy>* JsonWriter)
{
	if (CVarLogMemoryStats.GetValueOnAnyThread() != 0)
	{
		JsonWriter->WriteValue(TEXT("Process Physical Memory (MB)"), int64(FPlatformMemory::GetStats().UsedPhysical / 1024 / 1024));

		if (CVarLogMemoryStats.GetValueOnAnyThread() >= 2)
		{
			FGenericMemoryStats MemStat;
			GMalloc->GetAllocatorStats(MemStat);

			for (auto&& Iter : MemStat.Data)
			{
				JsonWriter->WriteValue(Iter.Key, (int64)Iter.Value);
			}
		}
	}

	JsonWriter->WriteObjectEnd();
	JsonWriter->Close();

	if (LogPriority > 0)
	{
		Q6SendJsonLogToServer(LogPriority, JsonString);
	}
}
