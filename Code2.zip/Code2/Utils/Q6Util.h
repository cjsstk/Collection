// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "CMS_gen.h"

enum class EHUDWidgetType : uint8;
enum class EPointType : uint8;
enum class EProfileCategory : uint8;

class FMT19937Uint32;

class Q6Util
{
public:
	Q6Util() = delete;

	static FString GetDeviceModel();
	static FString GetCurrentCultureCountryCode();
	static FDateTime UtcTimestampToLocalDateTime(int64 UtcTimestamp);
	static FText GetHappendTime(int64 HappenedTime, bool bShowDateAfterMonth = false);
	static FText GetLocalDateText(int64 UtcTimestamp);
	static FText GetLocalDatePeriodText(const FDateTime& StartDate, const FDateTime& EndDate);
	static FText AttachZeroToFront(int32 InNumber);
	static FText GetLocalDateTimeText(int64 UtcTimestamp);
	static FText ConvertDayOfWeekTypeToText(EDayOfWeekType DayOfWeekType);
	static FText GetShortTimeText(int64 TotalSeconds);
	static FText GetRemainTimeText(int64 TotalSeconds);
	static FText GetProductionTimeText(int32 InDays, int32 InHours, int32 InMinutes, int32 InSeconds);
	static bool IsDailyResetTimePassed(int64 UtcTimestamp);
	static FTimespan GetRemainTime(int64 EndUtcTimestamp);
	static FTimespan GetRemainDetailTime(int64 EndUtcTimestamp);
	static int32 GetRemainDays(int64 EndUtcTimestamp);
	static FDateTime GetNextResetLocalTime();
	static FText GetLocalizedText(const FString& Namespace, const FString& Key);
	static FText GetLocalizedTextOrKey(const FString& Namespace, const FString& Key);
	static FText GetVersionText(bool bDisplayVersion, bool bBinaryRevision, bool bPatchRevision);
	static FText GetFormattedBytesText(float InBytes);
	static FText GetPointText(EPointType PointType);
	static FText GetCurrencyText(ECurrencyType InCurrencyType);
	static FText GetMaxCurrencyText(ECurrencyCheckType CheckType, ECurrencyType InCurrencyType);
	static FText GetMaxCollectionText(ECurrencyCheckType CheckType);
	static FText GetContentText(EContentType InContentType);
	static FText GetCharacterProfileText(EProfileCategory Category);
	static void ShuffleArray(TArray<int32>& InOutArray);
	static void ShuffleArray(FMT19937Uint32& InRng, TArray<int32>& InOutArray);
	static bool IsValidCultureText(const FText& InText);
	static FText GetUpgradeResultText(EUpgradeResultType InResultType);
	static FText GetNotOpenedYetText(int32 Episode, int32 Stage, int32 SubStage);

private:
	static FDateTime GetResetLocalTime(int64 UtcTimestamp);

	static bool IsValidCultureTextInternal(const TCHAR Char);
	static bool GetCultureUnicodeRange(const FString& CultureCode, TCHAR* StartUnicode, TCHAR* EndUnicode);
};
