#include "Cheater.h"

#if !UE_BUILD_SHIPPING

#include "ActRecordManager.h"
#include "UserRecordManager.h"
#include "BagItemManager.h"
#include "CCEvent.h"
#include "CharacterManager.h"
#include "CheckInManager.h"
#include "GameResource.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "HUD/BaseHUD.h"
#include "HUD/LobbyHUD.h"
#include "PartyManager.h"
#include "PetManager.h"
#include "PowerPlantManager.h"
#include "PyramidManager.h"
#include "Q6.h"
#include "Q6Util.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "RaidManager.h"
#include "RelicManager.h"
#include "DailyDungeonManager.h"
#include "SculptureManager.h"
#include "SystemConst_gen.h"
#include "TempleManager.h"
#include "VacationManager.h"
#include "CombatCube.h"
#include "Q6CombatGameMode.h"
#include "CodexManager.h"
#include "WeeklyMissionManager.h"
#include "CharMissionManager.h"
#include "TitleManager.h"
#include "ShopManager.h"
#include "SmelterManager.h"
#include "AlchemylabManager.h"
#include "HUDStore/EventManager.h"
#include "FriendManager.h"

FCheater::FCheater()
	: GameInstance(nullptr)
{
}

FCheater::~FCheater()
{
}

void FCheater::Init(UQ6GameInstance* InGameInstance)
{
	GameInstance = InGameInstance;
	CommandHistory.Reset();

	typedef void (FCheater::*ReqMemFn)(const TArray<FString>&);

	struct FConsoleCommandInfo
	{
		int32 ShortcutNum;
		const TCHAR* Command;
		const TCHAR* Usage;
		ReqMemFn Handler;
	};

	FConsoleCommandInfo Commands[] =
	{
		{ 0, TEXT("/c_dev_mode"), TEXT("/c_dev_mode <on | off>"), &FCheater::DevMode },
		{ 1, TEXT("/c_test"), TEXT("/c_test"), &FCheater::Test },
		{ 2, TEXT("/c_add_xp"), TEXT("/c_add_xp <xp>"), &FCheater::AddXp },
		{ 3, TEXT("/c_add_free_gem"), TEXT("/c_add_free_gem <gem>"), &FCheater::AddFreeGem },
		{ 4, TEXT("/c_add_paid_gem"), TEXT("/c_add_paid_gem <count>"), &FCheater::AddPaidGem },
		{ 5, TEXT("/c_add_summon_ticket"), TEXT("/c_add_summon_ticket <count>"), &FCheater::AddSummonTicket },
		{ 6, TEXT("/c_add_sculpture_point"), TEXT("/c_add_sculpture_point <count>"), &FCheater::AddSculpturePoint },
		{ 7, TEXT("/c_add_relic_point"), TEXT("/c_add_relic_point <count>"), &FCheater::AddRelicPoint },
		{ 8, TEXT("/c_add_friendship_point"), TEXT("/c_add_friendship_point <count>"), &FCheater::AddFriendshipPoint },
		{ 9, TEXT("/c_add_gold"), TEXT("/c_add_gold <gold>"), &FCheater::AddGold },
		{ 10, TEXT("/c_bond_add"), TEXT("/c_bond_add <type> <xp>"), &FCheater::BondAdd },
		{ 11, TEXT("/c_selfkick"), TEXT("/c_selfkick"), &FCheater::SelfKick },
		{ 12, TEXT("/c_raid_open"), TEXT("/c_raid_open <type>"), &FCheater::RaidOpen },
		{ 13, TEXT("/c_raid_prepare"), TEXT("/c_raid_prepare"), &FCheater::RaidPrepare },
		{ 14, TEXT("/c_raid_end"), TEXT("/c_raid_end"), &FCheater::RaidEnd },
		{ 15, TEXT("/c_raid_skill_use"), TEXT("/c_skill_use [char id, skill type, slot, attributes]..."), &FCheater::RaidSkillUse },
		{ 17, TEXT("/c_character_new"), TEXT("/c_character_new <type> [level]"), &FCheater::CharacterNew },
		{ 18, TEXT("/c_character_all"), TEXT("/c_character_all <level>"), &FCheater::CharacterAll },
		{ 19, TEXT("/c_character_del"), TEXT("/c_character_del <id>"), &FCheater::CharacterDel },
		{ 20, TEXT("/c_character_mod"), TEXT("/c_character_mod <id> <attr> <value>"), &FCheater::CharacterMod },
		{ 21, TEXT("/c_character_api_test"), TEXT("/c_character_api_test [don't use]"), &FCheater::CharacterApiTest },
		{ 22, TEXT("/c_character_cheat_ultimate_skill_level"), TEXT("/c_character_cheat_ultimate_skill_level <id> [level]"), &FCheater::CharacterCheatUltimateSkillLevel },
		{ 23, TEXT("/c_character_cheat_support_skill_level"), TEXT("/c_character_cheat_support_skill_level <id> [level]"), &FCheater::CharacterCheatSupportSkillLevel },
		{ 24, TEXT("/c_character_cheat_turn_skill_level"), TEXT("/c_character_cheat_turn_skill_level <id> [index: 0 ~ 2] [level]"), &FCheater::CharacterCheatTurnSkillLevel },
		{ 25, TEXT("/c_character_turn_skill_level"), TEXT("/c_character_turn_skill_level <id> [index: 0 ~ 2]"), &FCheater::CharacterTurnSkillLevel },
		{ 26, TEXT("/c_character_ultimate_skill_level"), TEXT("/c_character_ultimate_skill_level <id> [sourceId ...]"), &FCheater::CharacterUltimateSkillLevel },
		{ 27, TEXT("/c_bag_item_new"), TEXT("/c_bag_item_new <type> [count]"), &FCheater::BagItemNew },
		{ 28, TEXT("/c_bag_item_del"), TEXT("/c_bag_item_del <id>"), &FCheater::BagItemDel },
		{ 29, TEXT("/c_bag_item_mod"), TEXT("/c_bag_item_mod <id> <attr> <value>"), &FCheater::BagItemMod },
		{ 30, TEXT("/c_relic_new"), TEXT("/c_relic_new <type> [level]"), &FCheater::RelicNew },
		{ 31, TEXT("/c_relic_del"), TEXT("/c_relic_del <id>"), &FCheater::RelicDel },
		{ 32, TEXT("/c_relic_mod"), TEXT("/c_relic_mod <id> <attr> <value>"), &FCheater::RelicMod },
		{ 33, TEXT("/c_relic_api_test"), TEXT("/c_relic_api_test [don't use]"), &FCheater::RelicApiTest },
		{ 34, TEXT("/c_sculpture_new"), TEXT("/c_sculpture_new <type> [level]"), &FCheater::SculptureNew },
		{ 35, TEXT("/c_sculpture_del"), TEXT("/c_sculpture_del <id>"), &FCheater::SculptureDel },
		{ 36, TEXT("/c_sculpture_mod"), TEXT("/c_sculpture_mod <id> <attr> <value>"), &FCheater::SculptureMod },
		{ 37, TEXT("/c_act_record_new"), TEXT("/c_act_record_new <type> <val>"), &FCheater::ActRecordNew },
		{ 38, TEXT("/c_act_record_del"), TEXT("/c_act_record_del <id>"), &FCheater::ActRecordDel },
		{ 39, TEXT("/c_act_record_mod"), TEXT("/c_act_record_mod <id> <created>"), &FCheater::ActRecordMod },
		{ 40, TEXT("/c_daily_clock_mod"), TEXT("/c_daily_clock_mod <minutes>"), &FCheater::DailyClockMod },
		{ 41, TEXT("/c_daily_list"), TEXT("/c_daily_list"), &FCheater::DailyList },
		{ 42, TEXT("/c_party_save"), TEXT("/c_party_save <party id> <id list(5)>"), &FCheater::PartySave },
		{ 43, TEXT("/c_party_pet_save"), TEXT("/c_party_pet_save <party id> <pet id>"), &FCheater::PartyPetSave },
		{ 44, TEXT("/c_special_clear"), TEXT("/c_special_clear <episode> <stage>"), &FCheater::SpecialClear},
		{ 45, TEXT("/c_special_open"), TEXT("/c_special_open <type> <id> [stage]"), &FCheater::SpecialOpen},
		{ 46, TEXT("/c_stage_clear"), TEXT("/c_stage_clear <episode> <stage> <substage>"), &FCheater::StageClear},
		{ 47, TEXT("/c_watt_recharge"), TEXT("/c_watt_recharge <amount>"), &FCheater::WattRecharge},
		{ 48, TEXT("/c_watt_consume"), TEXT("/c_watt_consume <amount>"), &FCheater::WattConsume},
		{ 49, TEXT("/c_training_center_clear"), TEXT("/c_training_center_clear <type> <sagatype>"), &FCheater::TrainingCenterClear},
		{ 50, TEXT("/c_training_center_reset"), TEXT("/c_training_center_reset"), &FCheater::TrainingCenterReset},
		{ 51, TEXT("/c_pyramid_open"), TEXT("/c_pyramid_open"), &FCheater::PyramidOpen},
		{ 52, TEXT("/c_portal_connect"), TEXT("/c_portal_connect <slot> <type>"), &FCheater::PyramidPortalConnect },
		{ 53, TEXT("/c_portal_boost_use"), TEXT("/c_portal_boost_use <slot> <count>"), &FCheater::PyramidPortalBoostUse },
		{ 54, TEXT("/c_pyramid_upgrade"), TEXT("/c_pyramid_upgrade <level>"), &FCheater::PyramidUpgrade },
		{ 55, TEXT("/c_portal_clear"), TEXT("/c_portal_clear <slot> <type>"), &FCheater::PyramidPortalClear },
		{ 56, TEXT("/c_portal_warp"), TEXT("/c_portal_warp <slot> <type>"), &FCheater::PyramidPortalWarp },
		{ 57, TEXT("/c_temple_open"), TEXT("/c_temple_open"), &FCheater::TempleOpen },
		{ 58, TEXT("/c_temple_upgrade"), TEXT("/c_temple_upgrade <level>"), &FCheater::TempleUpgrade },
		{ 59, TEXT("/c_artifacts_reset"), TEXT("/c_artifacts_reset"), &FCheater::TempleArtifactsReset },
		{ 60, TEXT("/c_artifact_upgrade"), TEXT("/c_artifact_upgrade <index> <level>"), &FCheater::TempleArtifactUpgrade },
		{ 61, TEXT("/c_artifact_use"), TEXT("/c_artifact_use <index>"), &FCheater::TempleArtifactUse },
		{ 62, TEXT("/c_plant_open"), TEXT("/c_plant_open"), &FCheater::PowerPlantOpen },
		{ 63, TEXT("/c_plant_upgrade"), TEXT("/c_plant_upgrade <level>"), &FCheater::PowerPlantUpgrade },
		{ 64, TEXT("/c_pet_park_open"), TEXT("/c_pet_park_open"), &FCheater::PetParkOpen },
		{ 65, TEXT("/c_pet_park_upgrade"), TEXT("/c_pet_park_upgrade <level>"), &FCheater::PetParkUpgrade },
		{ 66, TEXT("/c_pet_skill_upgrade"), TEXT("/c_pet_skill_upgrade <id> <index> <level>"), &FCheater::PetSkillUpgrade },
		{ 67, TEXT("/c_pet_new"), TEXT("/c_pet_new <type>"), &FCheater::PetNew },
		{ 68, TEXT("/c_vacation_open"), TEXT("/c_vacation_open"), &FCheater::VacationOpen },
		{ 69, TEXT("/c_vacation_upgrade"), TEXT("/c_vacation_upgrade <level>"), &FCheater::VacationUpgrade },
		{ 71, TEXT("/c_add_battery"), TEXT("/c_add_battery <type> <count>"), &FCheater::AddBattery },
		{ 73, TEXT("/c_raid_register"), TEXT("/c_raid_register"), &FCheater::RaidRegister },
		{ 74, TEXT("/c_raid_cond_pass"), TEXT("/c_raid_reset"), &FCheater::RaidPass },
		{ 75, TEXT("/c_goto_dialogue"), TEXT("/c_goto_dialogue <id>"), &FCheater::GotoDialogue },
		{ 76, TEXT("/c_skill_note_fix"), TEXT("/c_skill_note_fix <slot> <note> <index>"), &FCheater::SkillNoteFix },
		{ 77, TEXT("/c_skill_note_shuffle"), TEXT("/c_skill_note_shuffle <slot>"), &FCheater::SkillNoteShuffle },
		{ 78, TEXT("/c_raid_use_emoticon"), TEXT("/c_raid_use_emoticon <id>"), &FCheater::RaidUseEmoticon },
		{ 79, TEXT("/c_mail_send"), TEXT("/c_mail_send <type> <rewardType> <rewardItemCategory> <rewardItemType> <stackSize> <isInfiniteTime> <validMin> [reason type]"), &FCheater::MailSend},
		{ 80, TEXT("/c_raid_share_party"), TEXT("/c_raid_share_party <char id, health, maxHealth, playing>..."), &FCheater::RaidShareParty },
		{ 81, TEXT("/c_check_in_day"), TEXT("/c_check_in_day <board type> [day count]..."), &FCheater::CheckInDay },
		{ 82, TEXT("/c_codex_clear_new"), TEXT("/c_codex_clear_new <kind> <id>"), &FCheater::CodexClearNew },
		{ 83, TEXT("/c_shop_reset"), TEXT("/c_shop_reset"), &FCheater::ShopReset },
		{ 84, TEXT("/c_temple_produce"), TEXT("/c_temple_produce <produced time>"), &FCheater::TempleProduce },
		{ 85, TEXT("/c_pet_park_produce"), TEXT("/c_pet_park_produce <produced time>"), &FCheater::PetParkProduce },
		{ 86, TEXT("/c_add_lumicube"), TEXT("/c_add_lumicube <count>"), &FCheater::AddLumicube },
		{ 87, TEXT("/c_add_character_disk"), TEXT("/c_add_character_disk <count>"), &FCheater::AddCharacterDisk },
		{ 88, TEXT("/c_add_sculpture_disk"), TEXT("/c_add_sculpture_disk <count>"), &FCheater::AddSculptureDisk },
		{ 89, TEXT("/c_add_relic_disk"), TEXT("/c_add_relic_disk <count>"), &FCheater::AddRelicDisk },
		{ 90, TEXT("/c_weekly_mission_reward"), TEXT("/c_weekly_mission_reward <index>"), &FCheater::WeeklyMissionReward },
		{ 91, TEXT("/c_weekly_mission_bingo"), TEXT("/c_weekly_mission_bingo <index>"), &FCheater::WeeklyMissionBingo },
		{ 92, TEXT("/c_weekly_mission_shuffle"), TEXT("/c_weekly_mission_shuffle"), &FCheater::WeeklyMissionShuffle },
		{ 93, TEXT("/c_mileage_set"), TEXT("/c_mileage_set <event id> <amount>"), &FCheater::SetSummonMileage },
		{ 94, TEXT("/c_lobby_template_new"), TEXT("/c_lobby_template_new <type>"), &FCheater::LobbyTemplateNew },
		{ 95, TEXT("/c_joker_set_character"), TEXT("/c_joker_set_character <grade> <level>"), &FCheater::JokerSetCharacterSave },
		{ 96, TEXT("/c_friend_add"), TEXT("/c_friend_add <user code>"), &FCheater::FriendAdd },
		{ 97, TEXT("/c_char_mission_reward"), TEXT("/c_char_mission_reward <char id> <index>"), &FCheater::CharMissionReward },
		{ 98, TEXT("/c_friend_bot_all"), TEXT("/c_friend_bot_all"), &FCheater::FriendBotAll },
		{ 99, TEXT("/c_summon_count_set"), TEXT("/c_summon_count_set <category> <type> <count>"), &FCheater::SummonCountSet },
		{ 100, TEXT("/c_user_record_list"), TEXT("/c_user_record_list"), &FCheater::UserRecordList },
		{ 101, TEXT("/c_check_in_open"), TEXT("/c_check_in_open <board type> <date> <time>"), &FCheater::CheckInOpenTime },
		{ 102, TEXT("/c_char_mission_set"), TEXT("/c_char_mission_set <char id> <index> <amount>"), &FCheater::CharMissionSet },
		{ 103, TEXT("/c_title_add"), TEXT("/c_title_add <type>"), &FCheater::TitleAdd },
		{ 104, TEXT("/c_title_change"), TEXT("/c_title_change <type>"), &FCheater::TitleChange },
		{ 105, TEXT("/c_shop_buy"), TEXT("/c_shop_buy <type> <count>"), &FCheater::ShopBuy },
		{ 106, TEXT("/c_weekly_mission_reset"), TEXT("/c_weekly_mission_reset"), &FCheater::WeeklyMissionReset },
		{ 107, TEXT("/c_content_feature_open"), TEXT("/c_content_feature_open <open all party sub slot>"), &FCheater::ContentFeatureOpen },
		{ 108, TEXT("/c_event_content_reward"), TEXT("/c_event_content_reward <event content id> <loot group id>"), &FCheater::EventContentReward },
		{ 109, TEXT("/c_event_content_nember_of_days"), TEXT("/c_event_content_nember_of_days <days>"), &FCheater::EventContentNumberOfDays },
		{ 110, TEXT("/c_event_content_multi_side_battle_load"), TEXT("/c_event_content_multi_side_battle_load <event content id>"), &FCheater::EventContentMultiSideBattleLoad },
		{ 111, TEXT("/c_event_content_multi_side_battle_receive_rank_reward"), TEXT("/c_event_content_multi_side_battle_receive_rank_reward <event content id>"), &FCheater::EventContentMultiSideBattleReceiveRankReward },
		{ 112, TEXT("/c_smelter_open"), TEXT("/c_smelter_open"), &FCheater::SmelterOpen },
		{ 113, TEXT("/c_smelter_inc"), TEXT("/c_smelter_inc"), &FCheater::SmelterInc },
		{ 114, TEXT("/c_smelter_dec"), TEXT("/c_smelter_dec"), &FCheater::SmelterDec },
		{ 115, TEXT("/c_smelter_receive"), TEXT("/c_smelter_receive"), &FCheater::SmelterReceive },
		{ 116, TEXT("/c_smelter_upgrade"), TEXT("/c_smelter_upgrade <level>"), &FCheater::SmelterUpgrade },
		{ 117, TEXT("/c_smelter_upgrade_complete"), TEXT("/c_smelter_upgrade_complete"), &FCheater::SmelterUpgradeComplete },
		{ 118, TEXT("/c_alchemylab_open"), TEXT("/c_alchemylab_open"), &FCheater::AlchemylabOpen },
		{ 119, TEXT("/c_alchemylab_inc"), TEXT("/c_alchemylab_inc"), &FCheater::AlchemylabInc },
		{ 120, TEXT("/c_alchemylab_dec"), TEXT("/c_alchemylab_dec"), &FCheater::AlchemylabDec },
		{ 121, TEXT("/c_alchemylab_receive"), TEXT("/c_alchemylab_receive"), &FCheater::AlchemylabReceive },
		{ 122, TEXT("/c_event_content_add_point"), TEXT("/c_event_content_add_point <event content id> <point index> <count>"), &FCheater::EventContentAddPoint },
		{ 123, TEXT("/c_avatar_add"), TEXT("/c_avatar_add <category> <type> [illust]"), &FCheater::AvatarAdd },
		{ 124, TEXT("/c_friend_book_feed_add"), TEXT("/c_friend_book_feed_add <type> <param1> <param2> <param3> <param4> <param5>"), &FCheater::FriendBookFeedAdd },
		{ 125, TEXT("/c_friend_book_reaction_add"), TEXT("/c_friend_book_reaction_add <feed id> <type> <feed-owner user id>"), &FCheater::FriendBookReactionAdd },
		{ 126, TEXT("/c_friend_book_reaction_remove"), TEXT("/c_friend_book_reaction_remove <feed id> <feed-owner user id>"), &FCheater::FriendBookReactionRemove },
		{ 127, TEXT("/c_friend_book_timeline_load"), TEXT("/c_friend_book_timeline_load <last feed id>"), &FCheater::FriendBookTimelineLoad },
		{ 128, TEXT("/c_friend_book_feed_load"), TEXT("/c_friend_book_feed_load <feed id>"), &FCheater::FriendBookFeedLoad },
		{ 129, TEXT("/c_event_content_watt_recharge"), TEXT("/c_event_content_watt_recharge <event content id> <amount>"), &FCheater::EventContentRechargeWatt },
		{ 130, TEXT("/c_smelter_time"), TEXT("/c_smelter_time <left time minute>"), &FCheater::SmelterTime },
		{ 131, TEXT("/c_event_content_roulette_reset"), TEXT("/c_event_content_roulette_reset <event content id> <line up>"), &FCheater::EventContentRouletteReset },
		{ 132, TEXT("/c_alchemylab_upgrade"), TEXT("/c_alchemylab_upgrade <level>"), &FCheater::AlchemylabUpgrade },
		{ 133, TEXT("/c_alchemylab_time"), TEXT("/c_alchemylab_time <left time minute>"), &FCheater::AlchemylabTime },
		{ 134, TEXT("/c_regular_raid_register"), TEXT("/c_regular_raid_register <raid type> <schedule type>"), &FCheater::RegularRaidRegister },
		{ 135, TEXT("/c_regular_raid_ready"), TEXT("/c_regular_raid_ready <raid type> <schedule type>"), &FCheater::RegularRaidReady },
		{ 136, TEXT("/c_friend_cooltime"), TEXT("/c_friend_cooltime <minute>"), &FCheater::FriendCooltimeSet },
		// Add new cheat command here
	};

	for (int32 i = 0; i < dimof(Commands); ++i)
	{
		FConsoleCommandInfo& Info = Commands[i];
		CheatObjects.Add(IConsoleManager::Get().RegisterConsoleCommand(
			Info.Command,
			Info.Usage,
			FConsoleCommandWithArgsDelegate::CreateRaw(this, Info.Handler),
			ECVF_Cheat)
		);

		FString ShortcutStr = FString::FromInt(Info.ShortcutNum);
		checkf(!IConsoleManager::Get().IsNameRegistered(*ShortcutStr), TEXT("FCheater::Init - Duplicate shortcut number (%d : %s)"), Info.ShortcutNum, Info.Command);

		ShortcutObjects.Add(IConsoleManager::Get().RegisterConsoleCommand(
			*ShortcutStr,
			Info.Usage,
			FConsoleCommandWithArgsDelegate::CreateRaw(this, Info.Handler),
			ECVF_Cheat)
		);
	}

	HelpObject = IConsoleManager::Get().RegisterConsoleCommand(
		*FString::Chr('h'),
		TEXT("h : open cheat command help popup"),
		FConsoleCommandDelegate::CreateRaw(this, &FCheater::OpenCheatCommandHelpPopup),
		ECVF_Cheat);

	LoadCommandHistory();
}

void FCheater::Shutdown()
{
	for (IConsoleObject* Obj : CheatObjects)
	{
		IConsoleManager::Get().UnregisterConsoleObject(Obj);
	}
	CheatObjects.Empty();

	for (IConsoleObject* Obj : ShortcutObjects)
	{
		IConsoleManager::Get().UnregisterConsoleObject(Obj);
	}
	ShortcutObjects.Empty();

	IConsoleManager::Get().UnregisterConsoleObject(HelpObject);

	GameInstance = nullptr;
}

void FCheater::DevMode(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "DevMode");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_dev_mode <on | off>");
		return;
	}

	FString Mode = *Args[0];
	if (Mode.Equals(TEXT("on"), ESearchCase::IgnoreCase))
	{
		GameInstance->SetDevMode(true);
	}
	else if (Mode.Equals(TEXT("off"), ESearchCase::IgnoreCase))
	{
		GameInstance->SetDevMode(false);
	}
	else
	{
		Q6JsonLogCheater(Warning, "Usage: /c_dev_mode <on | off>");
	}
}

void FCheater::Test(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "test cheat");

	AddCommandHistory(TEXT("/test"), Args);
}

void FCheater::AddXp(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddXp");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_xp <gainXp>");
		return;
	}

	int32 GainXp = FCString::Atoi(*Args[0]);
	if (GainXp < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_xp <gainXp>");
		return;
	}

	FC2LDevAddXp Out;
	Out.GainXp = GainXp;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/addXp"), Out,
		TQ6ResponseDelegate<FL2CDevAddXpResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevAddXpResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "cheat add xp", Q6KV("Xp", Res.UserInfo.Xp), Q6KV("Level", Res.UserInfo.Level));
		ACTION_DISPATCH_DevAddXpResp(Res);
	}));

	AddCommandHistory(TEXT("/c_add_xp"), Args);
}

void FCheater::AddFreeGem(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddFreeGem");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_free_gem <Amount>");
		return;
	}

	int32 GainValue = FCString::Atoi(*Args[0]);
	AddCurrencyInternal(ECurrencyType::FreeGem, GainValue);
	AddCommandHistory(TEXT("/c_add_free_gem"), Args);
}

void FCheater::AddPaidGem(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddPaidGem");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_paid_gem <Amount>");
		return;
	}

	int32 GainValue = FCString::Atoi(*Args[0]);
	AddCurrencyInternal(ECurrencyType::PaidGem, GainValue);
	AddCommandHistory(TEXT("/c_add_paid_gem"), Args);
}

void FCheater::AddSummonTicket(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddSummonTicket");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_summon_ticket <Amount>");
		return;
	}

	int32 GainValue = FCString::Atoi(*Args[0]);
	AddCurrencyInternal(ECurrencyType::SummonTicket, GainValue);
	AddCommandHistory(TEXT("/c_add_summon_ticket"), Args);
}

void FCheater::AddSculpturePoint(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddSculpturePoint");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_sculpture_point <Amount>");
		return;
	}

	int32 GainValue = FCString::Atoi(*Args[0]);
	AddCurrencyInternal(ECurrencyType::SculpturePoint, GainValue);
	AddCommandHistory(TEXT("/c_add_sculpture_point"), Args);
}

void FCheater::AddRelicPoint(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddRelicPoint");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_relic_point <Amount>");
		return;
	}

	int32 GainValue = FCString::Atoi(*Args[0]);
	AddCurrencyInternal(ECurrencyType::RelicPoint, GainValue);
	AddCommandHistory(TEXT("/c_add_relic_point"), Args);
}

void FCheater::AddFriendshipPoint(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddFriendshipPoint");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_friendship_point <Amount>");
		return;
	}

	int32 GainValue = FCString::Atoi(*Args[0]);
	AddCurrencyInternal(ECurrencyType::FriendshipPoint, GainValue);
	AddCommandHistory(TEXT("/c_add_friendship_point"), Args);
}

void FCheater::AddGold(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddGold");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_gold <gainGold>");
		return;
	}

	int32 GainGold = FCString::Atoi(*Args[0]);
	AddCurrencyInternal(ECurrencyType::Gold, GainGold);
	AddCommandHistory(TEXT("/c_add_gold"), Args);
}

ECurrencyType ConvertBatteryToCurrencyType(EBatteryType BatteryType)
{
	switch (BatteryType)
	{
		case EBatteryType::Small:	return ECurrencyType::SmallBattery;
		case EBatteryType::Medium:	return ECurrencyType::MediumBattery;
		case EBatteryType::Large: 	return ECurrencyType::LargeBattery;
	}

	return ECurrencyType::None;
}

void FCheater::AddBattery(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Add battery");

	if (Args.Num() != 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_gold <battery type> <count>");
		return;
	}

	EBatteryType BatteryType = (EBatteryType)FCString::Atoi(*Args[0]);
	int32 BatteryCount = FCString::Atoi(*Args[1]);
	ECurrencyType CurrencyType = ConvertBatteryToCurrencyType(BatteryType);
	AddCurrencyInternal(CurrencyType, BatteryCount);
	AddCommandHistory(TEXT("/c_add_gold"), Args);
}

void FCheater::SelfKick(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_selfkick");

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/selfKick"), FC2LDevSelfKick(),
		TQ6ResponseDelegate<FL2CDevSelfKickResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevSelfKickResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "c_selfkick done");
	}));

	AddCommandHistory(TEXT("/c_selfkick"), Args);
}

void FCheater::BondAdd(const TArray<FString>& Args)
{
	if (Args.Num() != 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_bond_add <type> <xp>");
		return;
	}

	FC2LDevBondAdd Out;
	Out.CharacterType = FCharacterType(FCString::Atoi(*Args[0]));
	Out.GainXp = FCString::Atoi(*Args[1]);

	if (Out.CharacterType <= 0 || Out.GainXp <= 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_bond_add <type> <xp>");
		return;
	}

	Q6JsonLogCheater(Warning, "cheat bond add",
		Q6KV("CharacterType", Out.CharacterType),
		Q6KV("GainXp", Out.GainXp));

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/bondAdd"), Out,
		TQ6ResponseDelegate<FL2CDevBondAddResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevBondAddResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "cheat bond add",
			Q6KV("CharacterType", Res.CharacterBond.CharacterType),
			Q6KV("Level", Res.CharacterBond.Level),
			Q6KV("Xp", Res.CharacterBond.Xp));

		for (const FBondLevelUpReward& LevelUpReward : Res.LevelUpRewards)
		{
			Q6JsonLogCheater(Warning, "cheat bond level up",
				Q6KV("CharacterType", LevelUpReward.CharacterType),
				Q6KV("NewLevel", LevelUpReward.NewLevel));
			for (const FBondReward& BondReward : LevelUpReward.Rewards)
			{
				Q6JsonLogCheater(Warning, "cheat bond level up reward",
					Q6KV("BondRewardType", (int32)BondReward.Type),
					Q6KV("BondRewardParam", BondReward.Param));
			}
		}
		ACTION_DISPATCH_DevBondAddResp(Res);
	}));

	AddCommandHistory(TEXT("/c_bond_add"), Args);
}

void FCheater::RaidOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_raid_open");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_raid_open <type>");
		return;
	}

	int32 Type = FCString::Atoi64(*Args[0]);

	FRaidType RaidType(Type);
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RaidType);
	if (RaidRow.IsInvalid())
	{
		Q6JsonLogCheater(Warning, "invalid raid row");
		return;
	}

	if (RaidRow.RegularRaidScheduleIds.Num() > 0)
	{
		Q6JsonLogCheater(Warning, "do not open regularRaid");
		return;
	}

	GetHUDStore().GetRaidManager().ReqDevOpen(RaidType);

	AddCommandHistory(TEXT("/c_raid_open"), Args);
}

void FCheater::RaidPrepare(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_raid_prepare");
	GetHUDStore().GetRaidManager().ReqPrepare();

	AddCommandHistory(TEXT("/c_raid_prepare"), Args);
}

void FCheater::RaidSkillUse(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_raid_skill_use");

	if (Args.Num() != 4)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_raid_skill_use <char id>, <skill type>, <slot>, <Attributes>");
		return;
	}

	FRaidSkillUsedElement Element;
	Element.UsedChar = FCharacterId(FCString::Atoi64(*Args[0]));

	Element.NatureType = ENatureType::Fire;
	const FCharacter* Char = GetHUDStore().GetCharacterManager().Find(Element.UsedChar);
	if (Char)
	{
		Element.NatureType = GetCMS()->GetUnitRowOrDummy(Char->GetInfo().Type).NatureType;
	}

	Element.UsedSkill = FSkillType(FCString::Atoi(*Args[1]));
	Element.Slot = FCString::Atoi(*Args[2]);
	Element.Attributes.Reset(EUnitAttributeMax);
	Element.Attributes.Init(FCString::Atoi(*Args[3]), EUnitAttributeMax);

	TArray<FRaidSkillUsedElement> RaidSkillUsedElements(&Element, 1);
	GetHUDStore().GetRaidManager().ReqSkillUsed(RaidSkillUsedElements, 1000);

	AddCommandHistory(TEXT("/c_raid_skill_use"), Args);
}

void FCheater::RaidEnd(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_raid_end");
	FC2LDevRaidEnd Out;
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/raidEnd"), Out,
		TQ6ResponseDelegate<FL2CDevRaidEndResp>::CreateLambda([Q6BaseHUD](
		const FResError* Error, const FL2CDevRaidEndResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "raid end by founder user");
	}));

	AddCommandHistory(TEXT("/c_raid_end"), Args);
}

void FCheater::RaidRegister(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_raid_register");
	FC2LDevRaidRegister Out;
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/raidRegister"), Out,
		TQ6ResponseDelegate<FL2CDevRaidRegisterResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevRaidRegisterResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "raid user registered", Q6KV("Ok", Res.Ok));
	}));

	AddCommandHistory(TEXT("/c_raid_register"), Args);
}

void FCheater::RaidPass(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_raid_cond_pass");
	FC2LDevRaidPass Out;
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/raidPass"), Out,
		TQ6ResponseDelegate<FL2CDevRaidPassResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevRaidPassResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "raid condition will be pass", Q6KV("Ok", Res.Ok));
	}));

	AddCommandHistory(TEXT("/c_raid_cond_pass"), Args);
}

void FCheater::RaidUseEmoticon(const TArray<FString>& Args)
{
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_raid_use_emoticon <id>");
		return;
	}

	int32 Id = FCString::Atoi64(*Args[0]);

	Q6JsonLogCheater(Warning, "c_raid_use_emoticon", Q6KV("Id", Id));
	GetHUDStore().GetRaidManager().ReqUseEmoticon(Id);

	AddCommandHistory(TEXT("/c_raid_use_emoticon"), Args);
}

void FCheater::RaidShareParty(const TArray<FString>& Args)
{
	if (Args.Num() < 4 ||
		Args.Num() % 4 != 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_raid_share_party <char id, health, maxHealth, playing>...");
		return;
	}

	TArray<FRaidUserCharacterInfo> PartyInfo;

	for (int32 i = 0; i < Args.Num(); i = i + 4)
	{
		FCharacterId CharacterId(FCString::Atoi64(*Args[i]));
		int32 Health = FCString::Atoi(*Args[i + 1]);
		int32 maxHealth = FCString::Atoi(*Args[i + 2]);
		bool playing = static_cast<bool>(FCString::Atoi(*Args[i + 3]));

		PartyInfo.Emplace(CharacterId, Health, maxHealth, playing, false);
	}

	Q6JsonLogCheater(Warning, "c_raid_share_party");
	GetHUDStore().GetRaidManager().ReqShareParty(PartyInfo);

	AddCommandHistory(TEXT("/c_raid_share_party"), Args);
}

void FCheater::RegularRaidRegister(const TArray<FString>& Args)
{
	if (Args.Num() != 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_regular_raid_register <raid type> <schedule type>");
		return;
	}

	FRegularRaidInfo Info;
	Info.RaidType = FRaidType(FCString::Atoi(*Args[0]));
	Info.ScheduleId = FCString::Atoi(*Args[1]);
	GetHUDStore().GetRaidManager().ReqRegularRaidRegister(Info);
	Q6JsonLogCheater(Warning, "c_regular_raid_register OK");

	AddCommandHistory(TEXT("/c_regular_raid_register"), Args);
}

void FCheater::RegularRaidReady(const TArray<FString>& Args)
{
	if (Args.Num() != 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_regular_raid_ready <raid type> <schedule type>");
		return;
	}

	FRegularRaidInfo Info;
	Info.RaidType = FRaidType(FCString::Atoi(*Args[0]));
	Info.ScheduleId = FCString::Atoi(*Args[1]);
	GetHUDStore().GetRaidManager().ReqRegularRaidReady(Info);
	Q6JsonLogCheater(Warning, "c_regular_raid_ready OK");

	AddCommandHistory(TEXT("/c_regular_raid_ready"), Args);
}

void FCheater::CharacterNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_new");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_new <type> [level]");
		return;
	}

	auto Type = FCharacterType(FCString::Atoi(*Args[0]));
	int32 Level = 1;
	if (Args.Num() > 1)
	{
		Level = FCString::Atoi(*Args[1]);
	}

	const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(Type);
	if (!CharacterRow.XpExclusive && !CharacterRow.Codex)
	{
		Q6JsonLogCheater(Warning, "invalid character (XpExclusive, Codex false)");
		return;
	}

	FC2LDevCharacterNew Out;
	Out.Type = Type;
	Out.Level = FCharacterXpType(Level);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/characterNew"), Out,
		TQ6ResponseDelegate<FL2CDevCharacterNewResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevCharacterNewResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "character added",
			Q6KV("Id", Res.Info.CharacterId),
			Q6KV("Type", Res.Info.Type),
			Q6KV("Level", Res.Info.Level),
			Q6KV("Grade", (int32)Res.Info.Grade),
			Q6KV("Star", Res.Info.Star));

		ACTION_DISPATCH_DevCharacterNewResp(Res);
	}));

	AddCommandHistory(TEXT("/c_character_new"), Args);
}

void FCheater::CharacterAll(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_all");

	UHUDStore& HUDStore = GetHUDStore();
	const UCharacterManager& CharacterMan = HUDStore.GetCharacterManager();
	const UCodexManager& CodexMan = HUDStore.GetCodexManager();
	if (Args.Num() < 1)
	{
		CharacterMan.Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_all <level>");
		return;
	}

	auto Level = FCharacterXpType(FCString::Atoi(*Args[0]));

	FC2LDevCharacterAll Out;
	Out.Level = Level;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/characterAll"), Out,
		TQ6ResponseDelegate<FL2CCharacterListResp>::CreateLambda(
			[Q6BaseHUD, &CharacterMan, &CodexMan](const FResError* Error, const FL2CCharacterListResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "character all request list");

		if (Msg.Characters.Num() == 0)
		{
			CharacterMan.ReqList();
			CodexMan.ReqListChar();
			return;
		}

		ACTION_DISPATCH_CharacterListResp(Msg);
	}));

	AddCommandHistory(TEXT("/c_character_all"), Args);
}

void FCheater::CharacterDel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_del");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_del <id>");
		Q6JsonLogCheater(Warning, "if id <= 0 then delete all");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));

	FC2LDevCharacterDel Out;
	Out.CharacterId = CharacterId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/characterDel"), Out,
		TQ6ResponseDelegate<FL2CCharacterRemoveResp>::CreateLambda([Q6BaseHUD](const FResError* Error,
			const FL2CCharacterRemoveResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_CharacterRemoveResp(Msg);
		GetHUDStore().GetCharacterManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_character_del"), Args);
}

void FCheater::CharacterMod(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_mod");

	if (Args.Num() < 3)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_mod <id> <attr> <value>");
		Q6JsonLogCheater(Warning, "attr: level, xp, grade, star, locked, used, newly");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));
	int64 Value = FCString::Atoi(*Args[2]);

	FC2LDevCharacterMod Out;
	Out.CharacterId = CharacterId;
	Out.Attr = Args[1];
	Out.Value = Value;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/characterMod"), Out,
		TQ6ResponseDelegate<FL2CCharacterLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CCharacterLoadResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "character mod request list");

		ACTION_DISPATCH_CharacterLoadResp(Msg);
	}));

	AddCommandHistory(TEXT("/c_character_mod"), Args);
}

void FCheater::CharacterApiTest(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_api_test");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_character_api_test <id>");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));
	/*
	TArray<FCharacterId> Ids;
	for (int i = 1; i < Args.Num(); ++i)
	{
		Ids.Add(FCharacterId(FCString::Atoi64(*Args[i])));
	}
	*/
	GetHUDStore().GetCharacterManager().ReqPromote(CharacterId);
	AddCommandHistory(TEXT("/c_character_api_test"), Args);
}

void FCheater::CheatSkillLevelInternal(const FCharacterId& InCharacterId, ESkillCategory InCategory, int32 InSkillLevel, int32 InTurnSkillIndex)
{
	FC2LDevCharacterSkillLevel Out;
	Out.CharacterId = InCharacterId;
	Out.SkillCategory = InCategory;
	Out.SkillLevel = InSkillLevel;
	Out.TurnSkillIndex = InTurnSkillIndex;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/characterSkillLevel"), Out,
		TQ6ResponseDelegate<FL2CCharacterSkillLevelResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CCharacterSkillLevelResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Display, "set new skill level.",
			Q6KV("CharacterId", Msg.CharacterId),
			Q6KV("Category", static_cast<int32>(Msg.Category)),
			Q6KV("OldLevel", Msg.OldSkillLevel),
			Q6KV("NewLevel", Msg.NewSkillLevel),
			Q6KV("TurnSkillIndex", Msg.TurnSkillIndex));

		ACTION_DISPATCH_CharacterSkillLevelResp(Msg);
	}));
}

void FCheater::CharacterCheatUltimateSkillLevel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_cheat_ultimate_skill_level");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_cheat_ultimate_skill_level <id> [level]");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));
	int32 inLevel = FCString::Atoi(*Args[1]);

	CheatSkillLevelInternal(CharacterId, ESkillCategory::Ultimate, inLevel, 0);

	AddCommandHistory(TEXT("/c_character_cheat_ultimate_skill_level"), Args);
}

void FCheater::CharacterCheatSupportSkillLevel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_cheat_support_skill_level");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_cheat_support_skill_level <id> [level]");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));
	int32 inLevel = FCString::Atoi(*Args[1]);

	CheatSkillLevelInternal(CharacterId, ESkillCategory::Support, inLevel, 0);

	AddCommandHistory(TEXT("/c_character_cheat_support_skill_level"), Args);
}

void FCheater::CharacterCheatTurnSkillLevel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_cheat_turn_skill_level");

	if (Args.Num() < 3)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_cheat_turn_skill_level <id> [level] [index: 0 ~ 2]");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));
	int32 inLevel = FCString::Atoi(*Args[1]);
	int32 inTurnSkillIndex = FCString::Atoi(*Args[2]);

	CheatSkillLevelInternal(CharacterId, ESkillCategory::TurnBegin, inLevel, inTurnSkillIndex);

	AddCommandHistory(TEXT("/c_character_cheat_turn_skill_level"), Args);
}

void FCheater::CharacterTurnSkillLevel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_turn_skill_level");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_turn_skill_level <id> [index: 0 ~ 2]");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));
	int32 InTurnSkillIndex = FCString::Atoi(*Args[1]);

	GetHUDStore().GetCharacterManager().ReqUpgradeTurnSkillLevel(CharacterId, InTurnSkillIndex);
	AddCommandHistory(TEXT("/c_character_turn_skill_level"), Args);
}

void FCheater::CharacterUltimateSkillLevel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_character_ultimate_skill_level");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetCharacterManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_character_ultimate_skill_level <id> [material ids]");
		return;
	}

	FCharacterId CharacterId(FCString::Atoi64(*Args[0]));
	TArray<int64> SourceIds;

	for (int32 n = 1; n < Args.Num(); ++n)
	{
		SourceIds.Add(FCString::Atoi(*Args[n]));
	}

	GetHUDStore().GetCharacterManager().ReqUpgradeUltimateSkillLevel(CharacterId, SourceIds);
	AddCommandHistory(TEXT("/c_character_ultimate_skill_level"), Args);
}

void FCheater::BagItemNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_bag_item_new");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetBagItemManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_bag_item_new <type> [count]");
		return;
	}

	auto Type = FBagItemType(FCString::Atoi(*Args[0]));
	int32 StackSize = 1;
	if (Args.Num() > 1)
	{
		StackSize = FCString::Atoi(*Args[1]);
	}

	FC2LDevBagItemNew Out;
	Out.Type = Type;
	Out.StackSize = StackSize;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/bagItemNew"), Out,
		TQ6ResponseDelegate<FL2CBagItemLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CBagItemLoadResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "bagItem added",
			Q6KV("Id", Res.Info.BagItemId),
			Q6KV("Type", Res.Info.Type),
			Q6KV("StackSize", Res.Info.StackSize));
		ACTION_DISPATCH_BagItemLoadResp(Res);
		GetHUDStore().GetBagItemManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_bag_item_new"), Args);
}

void FCheater::BagItemDel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_bag_item_del");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetBagItemManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_bag_item_del <id>");
		Q6JsonLogCheater(Warning, "if id <= 0 then delete all");
		return;
	}

	FBagItemId BagItemId = FBagItemId(FCString::Atoi64(*Args[0]));

	FC2LDevBagItemDel Out;
	Out.BagItemId = BagItemId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/bagItemDel"), Out,
		TQ6ResponseDelegate<FL2CBagItemRemoveResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CBagItemRemoveResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_BagItemRemoveResp(Msg);
		GetHUDStore().GetBagItemManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_bag_item_del"), Args);
}

void FCheater::BagItemMod(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_bag_item_mod");

	if (Args.Num() < 3)
	{
		GetHUDStore().GetBagItemManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_bag_item_mod <id> <attr> <value>");
		Q6JsonLogCheater(Warning, "attr: count, newly");
		return;
	}

	FBagItemId BagItemId = FBagItemId(FCString::Atoi64(*Args[0]));
	int64 Value = FCString::Atoi(*Args[2]);

	FC2LDevBagItemMod Out;
	Out.BagItemId = BagItemId;
	Out.Attr = Args[1];
	Out.Value = Value;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/bagItemMod"), Out,
		TQ6ResponseDelegate<FL2CBagItemLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CBagItemLoadResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "bag item mod");
		ACTION_DISPATCH_BagItemLoadResp(Msg);
	}));

	AddCommandHistory(TEXT("/c_bag_item_mod"), Args);
}

void FCheater::RelicNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_relic_new");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetRelicManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_relic_new <type> [level]");
		return;
	}

	auto Type = FRelicType(FCString::Atoi(*Args[0]));
	int32 Level = 1;
	if (Args.Num() > 1)
	{
		Level = FCString::Atoi(*Args[1]);
	}

	const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(Type);
	if (!RelicRow.XpExclusive && !RelicRow.Codex)
	{
		Q6JsonLogCheater(Warning, "invalid relic (XpExclusive, Codex false)");
		return;
	}

	FC2LDevRelicNew Out;
	Out.Type = Type;
	Out.Level = FItemXpType(Level);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/relicNew"), Out,
		TQ6ResponseDelegate<FL2CDevRelicNewResp>::CreateLambda(
			[Q6BaseHUD](const FResError* Error, const FL2CDevRelicNewResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "relic added",
			Q6KV("Id", Res.Info.RelicId),
			Q6KV("Type", Res.Info.Type),
			Q6KV("Level", Res.Info.Level),
			Q6KV("Grade", (int32)Res.Info.Grade),
			Q6KV("Star", Res.Info.Star));

		ACTION_DISPATCH_DevRelicNewResp(Res);
		GetHUDStore().GetRelicManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_relic_new"), Args);
}

void FCheater::RelicDel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_relic_del");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetRelicManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_relic_del <id>");
		Q6JsonLogCheater(Warning, "if id <= 0 then delete all");
		return;
	}

	FRelicId RelicId = FRelicId(FCString::Atoi64(*Args[0]));

	FC2LDevRelicDel Out;
	Out.RelicId = RelicId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/relicDel"), Out,
		TQ6ResponseDelegate<FL2CRelicRemoveResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CRelicRemoveResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_RelicRemoveResp(Msg);
		GetHUDStore().GetRelicManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_relic_del"), Args);
}

void FCheater::RelicMod(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_relic_mod");

	if (Args.Num() < 3)
	{
		GetHUDStore().GetRelicManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_relic_mod <id> <attr> <value>");
		Q6JsonLogCheater(Warning, "attr: level, xp, grade, star, locked, newly");
		return;
	}

	FRelicId RelicId = FRelicId(FCString::Atoi64(*Args[0]));
	int64 Value = FCString::Atoi(*Args[2]);

	FC2LDevRelicMod Out;
	Out.RelicId = RelicId;
	Out.Attr = Args[1];
	Out.Value = Value;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/relicMod"), Out,
		TQ6ResponseDelegate<FL2CRelicLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CRelicLoadResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "relic mod");
		ACTION_DISPATCH_RelicLoadResp(Msg);
		GetHUDStore().GetRelicManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_relic_mod"), Args);
}

void FCheater::RelicApiTest(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_relic_api_test");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_relic_api_test <id>");
		return;
	}

	FSculptureId Id(FCString::Atoi64(*Args[0]));

	TArray<FSculptureId> Ids;
	for (int i = 1; i < Args.Num(); ++i)
	{
		Ids.Add(FSculptureId(FCString::Atoi64(*Args[i])));
	}

	GetHUDStore().GetSculptureManager().ReqPromote(Id);
	AddCommandHistory(TEXT("/c_relic_api_test"), Args);
}

void FCheater::SculptureNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_sculpture_new");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetSculptureManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_sculpture_new <type> [level]");
		return;
	}

	auto Type = FSculptureType(FCString::Atoi(*Args[0]));
	int32 Level = 1;
	if (Args.Num() > 1)
	{
		Level = FCString::Atoi(*Args[1]);
	}

	const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(Type);
	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(Type);

	if (!SculptureRow.XpExclusive && !SculptureRow.Codex && SculptureAssetRow.UltimateWidgetClass.IsNull())
	{
		Q6JsonLogCheater(Warning, "invalid sculpture (XpExclusive, Codex false. and has no UltimateWidget)");
		return;
	}

	FC2LDevSculptureNew Out;
	Out.Type = Type;
	Out.Level = FItemXpType(Level);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/sculptureNew"), Out,
		TQ6ResponseDelegate<FL2CDevSculptureNewResp>::CreateLambda(
			[Q6BaseHUD](const FResError* Error, const FL2CDevSculptureNewResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "sculpture added",
			Q6KV("Id", Res.Info.SculptureId),
			Q6KV("Type", Res.Info.Type),
			Q6KV("Level", Res.Info.Level),
			Q6KV("Grade", (int32)Res.Info.Grade),
			Q6KV("Star", Res.Info.Star));

		ACTION_DISPATCH_DevSculptureNewResp(Res);
		GetHUDStore().GetSculptureManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_sculpture_new"), Args);
}

void FCheater::SculptureDel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_sculpture_del");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetSculptureManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_sculpture_del <id>");
		Q6JsonLogCheater(Warning, "if id <= 0 then delete all");
		return;
	}

	FSculptureId SculptureId = FSculptureId(FCString::Atoi64(*Args[0]));

	FC2LDevSculptureDel Out;
	Out.SculptureId = SculptureId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/sculptureDel"), Out,
		TQ6ResponseDelegate<FL2CSculptureRemoveResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CSculptureRemoveResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_SculptureRemoveResp(Msg);
		GetHUDStore().GetSculptureManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_sculpture_del"), Args);
}

void FCheater::SculptureMod(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_sculpture_mod");

	if (Args.Num() < 3)
	{
		GetHUDStore().GetSculptureManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_sculpture_mod <id> <attr> <value>");
		Q6JsonLogCheater(Warning, "attr: level, xp, grade, star, locked, newly");
		return;
	}

	FSculptureId SculptureId = FSculptureId(FCString::Atoi64(*Args[0]));
	int64 Value = FCString::Atoi(*Args[2]);

	FC2LDevSculptureMod Out;
	Out.SculptureId = SculptureId;
	Out.Attr = Args[1];
	Out.Value = Value;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/sculptureMod"), Out,
		TQ6ResponseDelegate<FL2CSculptureLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CSculptureLoadResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "sculpture mod");
		ACTION_DISPATCH_SculptureLoadResp(Msg);
		GetHUDStore().GetSculptureManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_sculpture_mod"), Args);
}

void FCheater::ActRecordNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_act_record_new");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetActRecordManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_act_record_new <type> <val>");
		return;
	}

	auto Type = FActRecordType(FCString::Atoi(*Args[0]));
	int32 Val = FCString::Atoi(*Args[1]);

	FC2LDevActRecordNew Out;
	Out.Type = Type;
	Out.Val = Val;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/actRecordNew"), Out,
		TQ6ResponseDelegate<FL2CActRecordLoadResp>::CreateLambda(
			[Q6BaseHUD](const FResError* Error, const FL2CActRecordLoadResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "act record added",
			Q6KV("Id", Res.Info.ActRecordId),
			Q6KV("Type", Res.Info.Type),
			Q6KV("Val", Res.Info.Val),
			Q6KV("Created", Q6Util::GetLocalDateTimeText(Res.Info.Created).ToString()));

		ACTION_DISPATCH_ActRecordLoadResp(Res);
		GetHUDStore().GetActRecordManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_act_record_new"), Args);
}

void FCheater::ActRecordDel(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_act_record_del");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetActRecordManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_act_record_del <id>");
		Q6JsonLogCheater(Warning, "if id <= 0 then delete all");
		return;
	}

	FActRecordId ActRecordId = FActRecordId(FCString::Atoi64(*Args[0]));

	FC2LDevActRecordDel Out;
	Out.ActRecordId = ActRecordId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/actRecordDel"), Out,
		TQ6ResponseDelegate<FL2CActRecordRemoveResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CActRecordRemoveResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_ActRecordRemoveResp(Msg);
		GetHUDStore().GetActRecordManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_act_record_del"), Args);
}

void FCheater::CodexClearNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_codex_clear_new");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetCodexManager().Dump();
		Q6JsonLogCheater(Warning,
			"Usage: /c_codex_clear_new <kind> <id>, 1:char/ 2:sculpture/ 3:relic");
		return;
	}

	int32 Kind = FCString::Atoi(*Args[0]);
	int64 Id = FCString::Atoi64(*Args[1]);
	if (Kind == 1)
	{
		GetHUDStore().GetCodexManager().ReqClearNewChar(FCodexCharId(Id));
	}
	else if (Kind == 2)
	{
		GetHUDStore().GetCodexManager().ReqClearNewSculpture(FCodexSculptureId(Id));
	}
	else if (Kind == 3)
	{
		GetHUDStore().GetCodexManager().ReqClearNewRelic(FCodexRelicId(Id));
	}
	else
	{
		Q6JsonLogCheater(Warning,
			"Usage: /c_codex_clear_new <kind> <id>, 1:char/ 2:sculpture/ 3:relic");
	}

	AddCommandHistory(TEXT("/c_codex_clear_new"), Args);
}

void FCheater::ActRecordMod(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_act_record_mod");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetActRecordManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_act_record_mod <id> <created>");
		return;
	}

	FActRecordId ActRecordId = FActRecordId(FCString::Atoi64(*Args[0]));
	int64 Created = FCString::Atoi(*Args[1]);

	FC2LDevActRecordMod Out;
	Out.ActRecordId = ActRecordId;
	Out.Created = Created;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/actRecordMod"), Out,
		TQ6ResponseDelegate<FL2CActRecordLoadResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CActRecordLoadResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "act record mod");
		ACTION_DISPATCH_ActRecordLoadResp(Msg);
		GetHUDStore().GetActRecordManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_act_record_mod"), Args);
}

void FCheater::DailyClockMod(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_daily_clock_mod");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_daily_clock_mod <minutes>");
		return;
	}

	int32 Minutes = FCString::Atoi64(*Args[0]);

	FC2LDevClockMod Out;
	Out.Value = Minutes;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/clockMod"), Out,
		TQ6ResponseDelegate<FL2CDevClockModResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevClockModResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "daily clock mod",
			Q6KV("Server modified minutes", Msg.Value));
		ACTION_DISPATCH_DevClockModResp(Msg);
	}));

	AddCommandHistory(TEXT("/c_daily_clock_mod"), Args);
}

void FCheater::DailyList(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_daily_list");

	GetHUDStore().GetDailyDungeonManager().ReqDailyList();
	AddCommandHistory(TEXT("/c_daily_list"), Args);
}

void FCheater::PartySave(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_party_save");

	if (Args.Num() < 6)
	{
		GetHUDStore().GetPartyManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_party_save <party id> <id list(5)>");
		return;
	}

	int32 PartyId = FCString::Atoi(*Args[0]);

	FC2LPartySaveCharacters Out;
	Out.PartyId = PartyId;

	for (int i = 0; i < 5; ++i)
	{
		Out.CharacterIds.Add(FCharacterId(FCString::Atoi(*Args[1 + i])));
	}

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("party/saveCharacters"), Out,
		TQ6ResponseDelegate<FL2CPartySaveResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CPartySaveResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "c_party_save");
		ACTION_DISPATCH_PartySaveResp(Msg);
		GetHUDStore().GetPartyManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_party_save"), Args);
}

void FCheater::PartyPetSave(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_party_pet_save");

	if (Args.Num() < 2)
	{
		GetHUDStore().GetPartyManager().Dump();
		GetHUDStore().GetPetManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_party_pet_save <party id> <pet id>");
		return;
	}

	int32 PartyId = FCString::Atoi(*Args[0]);
	if (!GetHUDStore().GetPartyManager().IsValidParty(PartyId))
	{
		Q6JsonLogCheater(Warning, "/c_party_pet_save - invalid party id");
		GetHUDStore().GetPartyManager().Dump();
		return;
	}

	FPetId PetId = FPetId(FCString::Atoi(*Args[1]));
	if (!GetHUDStore().GetPetManager().HasPet(PetId))
	{
		Q6JsonLogCheater(Warning, "/c_party_pet_save - invalid pet id");
		GetHUDStore().GetPetManager().Dump();
		return;
	}

	FPartyInfo PartyInfo = GetHUDStore().GetPartyManager().GetPartyInfo(PartyId);
	PartyInfo.PetId = PetId;

	GetHUDStore().GetPartyManager().ReqPartySave(PartyInfo, FPartySlot());
	AddCommandHistory(TEXT("/c_party_pet_save"), Args);
}

void FCheater::StageClear(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_stage_clear");

	if (Args.Num() < 3)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_stage_clear <episode> <stage> <substage>");
		return;
	}

	int32 Episode = FCString::Atoi(*Args[0]);
	int32 Stage = FCString::Atoi(*Args[1]);
	int32 SubStage = FCString::Atoi(*Args[2]);

	FSagaType Type = GetCMS()->FindSagaType(Episode, Stage, SubStage);
	if (Type == SagaTypeInvalid)
	{
		Q6JsonLogCheater(Warning, "/c_stage_clear Invalid Stage");
		return;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Type);
	if (SagaRow.ContentType != EContentType::Saga)
	{
		Q6JsonLogCheater(Warning, "/c_stage_clear Invalid ContentType");
		return;
	}

	ALobbyHUD* LobbyHUD = Cast<ALobbyHUD>(GetBaseHUD(GameInstance));
	ALobbyTutorial* LobbyTutorial = LobbyHUD ? LobbyHUD->GetLobbyTutorial() : nullptr;
	if (!LobbyHUD || !LobbyTutorial)
	{
		Q6JsonLogCheater(Warning, "/c_stage_clear Not found lobby tutorial");
		return;
	}

	FC2LDevStageClear Out;
	Out.Type = Type;
	Out.TutorialCharacterSummon = LobbyTutorial->IsCharacterSummonTutorialSagaCleared();
	Out.TutorialSculptureSummon = LobbyTutorial->IsSculptureSummonTutorialSagaCleared();
	Out.TutorialRelicSummon = LobbyTutorial->IsRelicSummonTutorialSagaCleared();

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/stageClear"), Out,
		TQ6ResponseDelegate<FL2CDevStageClearResp>::CreateLambda([LobbyHUD](const FResError* Error, const FL2CDevStageClearResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(LobbyHUD, Error);
			return;
		}

		if (Resp.Ok)
		{
			LobbyHUD->OpenItemRewardPopup(Resp.RewardInfos);

			ACTION_DISPATCH_DevStageClearResp(Resp);

			const FCMSSagaRow& InSagaRow = GetCMS()->GetSagaRowOrDummy(Resp.Type);
			Q6JsonLogCheater(Warning, "/c_stage_clear Ok", Q6KV("Episode", InSagaRow.Episode), Q6KV("Stage", InSagaRow.Stage), Q6KV("SubStage", InSagaRow.SubStage));
		}
	}));

	AddCommandHistory(TEXT("/c_stage_clear"), Args);
}

void FCheater::SpecialClear(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_special_clear");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_special_clear <episode> <stage>");
		return;
	}

	int32 Episode = FCString::Atoi(*Args[0]);
	int32 Stage = FCString::Atoi(*Args[1]);

	FC2LDevSpecialClear Out;
	Out.Episode = Episode;
	Out.Stage = Stage;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/specialClear"), Out,
		TQ6ResponseDelegate<FL2CDevSpecialClearResp>::CreateLambda([Q6BaseHUD, Episode](const FResError* Error, const FL2CDevSpecialClearResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		if (Resp.Ok)
		{
			ACTION_DISPATCH_DevSpecialClearResp(Resp);
			const auto& SpecialStage = Resp.SpecialStage;
			Q6JsonLogCheater(Verbose, "/c_special_clear Ok",
				Q6KV("Episode", Episode), Q6KV("Stage", SpecialStage.Stage), Q6KV("ClearCount", SpecialStage.ClearCount));
		}
	}));

	AddCommandHistory(TEXT("/c_special_clear"), Args);
}

void FCheater::SpecialOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_special_open");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_special_open <type> <id> [stage]");
		return;
	}

	int32 Type = FCString::Atoi(*Args[0]);
	int32 Id = FCString::Atoi(*Args[1]);
	int32 Stage = Args.IsValidIndex(2) ? FCString::Atoi(*Args[2]) : 1;

	FC2LDevSpecialOpen Out;
	Out.ConditionType = static_cast<ESpecialCategory>(Type);
	Out.ConditionId = Id;
	Out.Stage = Stage;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/specialOpen"), Out,
		TQ6ResponseDelegate<FL2CDevSpecialOpenResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevSpecialOpenResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevSpecialOpenResp(Resp);
		Q6JsonLogCheater(Verbose, "/c_special_open Ok", Q6KV("Episode", Resp.SpecialRecord.Episode));
	}));

	AddCommandHistory(TEXT("/c_special_open"), Args);
}

void FCheater::WattRecharge(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "WattRecharge");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_watt_recharge <amount>");
		return;
	}

	int32 Amount = FCString::Atoi(*Args[0]);
	if (Amount < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_watt_recharge <amount>");
		return;
	}

	FC2LDevWattRecharge Out;
	Out.Amount = Amount;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/wattRecharge"), Out,
		TQ6ResponseDelegate<FL2CDevWattRechargeResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevWattRechargeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "cheat watt recharge", Q6KV("Watt", Res.WattInfo.Watt));
		ACTION_DISPATCH_DevWattRechargeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_watt_recharge"), Args);
}

void FCheater::WattConsume(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "WattConsume");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_watt_consume <amount>");
		return;
	}

	int32 Amount = FCString::Atoi(*Args[0]);
	if (Amount < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_watt_consume <amount>");
		return;
	}

	FC2LDevWattConsume Out;
	Out.Amount = Amount;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/wattConsume"), Out,
		TQ6ResponseDelegate<FL2CDevWattConsumeResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevWattConsumeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "cheat watt consume", Q6KV("Watt", Res.WattInfo.Watt));
		ACTION_DISPATCH_DevWattConsumeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_watt_consume"), Args);
}

void FCheater::TrainingCenterClear(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_training_center_clear");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_training_center_clear <type> <sagatype>");
		return;
	}

	FTrainingCenterType Type(FCString::Atoi(*Args[0]));
	FSagaType SagaType(FCString::Atoi(*Args[1]));

	if (!GetCMS()->IsValidTrainingCenter(Type, SagaType))
	{
		Q6JsonLogCheater(Warning, "/c_training_center_clear Invalid Type or SagaType");
		return;
	}

	FC2LDevTrainingCenterClear Out;
	Out.Type = Type;
	Out.SagaType = SagaType;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/trainingCenterClear"), Out,
		TQ6ResponseDelegate<FL2CDevTrainingCenterClearResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevTrainingCenterClearResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		if (Resp.Ok)
		{
			ACTION_DISPATCH_DevTrainingCenterClearResp(Resp);

			Q6JsonLogCheater(Warning, "/c_training_center_clear Ok", Q6KV("Type", Resp.History.Type), Q6KV("SagaType", Resp.History.SagaType));
		}
	}));

	AddCommandHistory(TEXT("/c_training_center_clear"), Args);
}

void FCheater::TrainingCenterReset(const TArray<FString>& Args)
{
	FC2LDevTrainingCenterReset Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/trainingCenterReset"), Out,
		TQ6ResponseDelegate<FL2CDevTrainingCenterResetResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevTrainingCenterResetResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevTrainingCenterResetResp(Resp);

		Q6JsonLogCheater(Warning, "/c_training_center_reset Ok", Q6KV("Type", Resp.History.Type), Q6KV("SagaType", Resp.History.SagaType));
	}));

	AddCommandHistory(TEXT("/c_training_center_reset"), Args);
}

void FCheater::PyramidOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "PyramidOpen");

	FC2LDevPyramidOpen Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/pyramidOpen"), Out,
		TQ6ResponseDelegate<FL2CDevPyramidOpenResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPyramidOpenResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat pyramid opened");
		ACTION_DISPATCH_DevPyramidOpenResp(Res);
	}));

	AddCommandHistory(TEXT("/c_pyramid_open"), Args);
}

void FCheater::PyramidPortalConnect(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Pyramid portal connect");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_portal_connect <slot> <type>");
		return;
	}

	FC2LDevPortalConnect Out;
	Out.Category = static_cast<EPortalType>(FCString::Atoi(*Args[0]));
	Out.Type = FCString::Atoi(*Args[1]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/portalConnect"), Out,
		TQ6ResponseDelegate<FL2CPyramidPortalConnectResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CPyramidPortalConnectResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "Cheat pyramid portal connected");
		ACTION_DISPATCH_PyramidPortalConnectResp(Res);
	}));

	AddCommandHistory(TEXT("/c_portal_connect"), Args);
}

void FCheater::PyramidPortalBoostUse(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Pyramid portal boost use");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_portal_boost_use <slot> <count>");
		return;
	}

	FC2LDevPortalBoostUse Out;
	Out.Category = static_cast<EPortalType>(FCString::Atoi(*Args[0]));
	Out.Count = FCString::Atoi(*Args[1]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/portalBoostUse"), Out,
		TQ6ResponseDelegate<FL2CDevPortalBoostUseResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPortalBoostUseResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "Cheat pyramid portal boost used");
		ACTION_DISPATCH_DevPyramidPortalBoostUseResp(Res);
	}));

	AddCommandHistory(TEXT("/c_portal_boost_use"), Args);
}

void FCheater::PyramidUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Pyramid upgrade");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_pyramid_upgrade <level>");
		return;
	}

	GetHUDStore().GetPyramidManager().ReqDevUpgrade(FCString::Atoi(*Args[0]));
	AddCommandHistory(TEXT("/c_pyramid_upgrade"), Args);
}

void FCheater::PyramidPortalClear(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Pyramid portal clear");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_portal_clear <slot> <type>");
		return;
	}

	FC2LDevPortalClear Out;
	Out.Category = static_cast<EPortalType>(FCString::Atoi(*Args[0]));
	Out.Type = FCString::Atoi(*Args[1]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/portalClear"), Out,
		TQ6ResponseDelegate<FL2CDevPortalClearResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPortalClearResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "Cheat portal clear");
		ACTION_DISPATCH_DevPyramidPortalClearResp(Res);
	}));

	AddCommandHistory(TEXT("/c_portal_clear"), Args);
}

void FCheater::PyramidPortalWarp(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Pyramid portal warp");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_portal_warp <slot> <type>");
		return;
	}

	GetHUDStore().GetPyramidManager().ReqDevPortalWarp((EPortalType)FCString::Atoi(*Args[0]), FCString::Atoi(*Args[1]));
	AddCommandHistory(TEXT("/c_portal_warp"), Args);
}

void FCheater::TempleOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_temple_open");

	if (GetHUDStore().GetTempleManager().IsOpen())
	{
		Q6JsonLogCheater(Warning, "temple is already open.");
		return;
	}

	FC2LDevTempleOpen Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/templeOpen"), Out,
		TQ6ResponseDelegate<FL2CDevTempleOpenResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevTempleOpenResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_temple_open Ok");
		ACTION_DISPATCH_DevTempleOpenResp(Res);
	}));

	AddCommandHistory(TEXT("/c_temple_open"), Args);
}

void FCheater::TempleUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_temple_upgrade");

	if (!GetHUDStore().GetTempleManager().IsOpen())
	{
		Q6JsonLogCheater(Warning, "temple is not open. use /c_temple_open first.");
		return;
	}

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_temple_upgrade <level>");
		return;
	}

	int32 Level = FCString::Atoi(*Args[0]);
	if (!FMath::IsWithinInclusive(Level, 1, SystemConst::Q6_MAX_WONDER_LEVEL))
	{
		Q6JsonLogCheater(Warning, "Usage: <level> is ", Q6KV("Min", 1), Q6KV("Max", SystemConst::Q6_MAX_WONDER_LEVEL));
		return;
	}

	GetHUDStore().GetTempleManager().ReqDevUpgrade(Level);
	AddCommandHistory(TEXT("/c_temple_upgrade"), Args);
}

void FCheater::TempleArtifactsReset(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_artifacts_reset");

	if (!GetHUDStore().GetTempleManager().IsOpen())
	{
		Q6JsonLogCheater(Warning, "temple is not open. use /c_temple_open first.");
		return;
	}

	FC2LDevTempleArtifactsReset Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/templeArtifactsReset"), Out,
		TQ6ResponseDelegate<FL2CDevTempleArtifactsResetResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevTempleArtifactsResetResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_artifacts_reset Ok");
		ACTION_DISPATCH_DevTempleArtifactsResetResp(Res);
	}));

	AddCommandHistory(TEXT("/c_artifacts_reset"), Args);
}

void FCheater::TempleArtifactUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_artifact_upgrade");

	if (!GetHUDStore().GetTempleManager().IsOpen())
	{
		Q6JsonLogCheater(Warning, "temple is not open. use /c_temple_open first.");
		return;
	}

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_artifact_upgrade <index> <level>");
		return;
	}

	int32 Index = FCString::Atoi(*Args[0]);
	if (!FMath::IsWithin(Index, 0, SystemConst::Q6_MAX_TEMPLE_ARTIFACTS))
	{
		Q6JsonLogCheater(Warning, "Usage: <index> is zero-base", Q6KV("Min", 0), Q6KV("Max", SystemConst::Q6_MAX_TEMPLE_ARTIFACTS));
		return;
	}

	int32 Level = FCString::Atoi(*Args[1]);
	if (!FMath::IsWithinInclusive(Level, 1, SystemConst::Q6_MAX_WONDER_LEVEL))
	{
		Q6JsonLogCheater(Warning, "Usage: <level> is ", Q6KV("Min", 1), Q6KV("Max", SystemConst::Q6_MAX_WONDER_LEVEL));
		return;
	}

	FC2LDevTempleArtifactUpgrade Out;
	Out.ArtifactIndex = Index;
	Out.Level = Level;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/templeArtifactUpgrade"), Out,
		TQ6ResponseDelegate<FL2CDevTempleArtifactUpgradeResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevTempleArtifactUpgradeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_artifact_upgrade Ok");
		ACTION_DISPATCH_DevTempleArtifactUpgradeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_artifact_upgrade"), Args);
}

void FCheater::TempleArtifactUse(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_artifact_use");

	if (!GetHUDStore().GetTempleManager().IsOpen())
	{
		Q6JsonLogCheater(Warning, "temple is not open. use /c_temple_open first.");
		return;
	}

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_artifact_use <index>");
		return;
	}

	int32 Index = FCString::Atoi(*Args[0]);
	if (!FMath::IsWithin(Index, 0, SystemConst::Q6_MAX_TEMPLE_ARTIFACTS))
	{
		Q6JsonLogCheater(Warning, "Usage: <index> is zero-base", Q6KV("Min", 0), Q6KV("Max", SystemConst::Q6_MAX_TEMPLE_ARTIFACTS));
		return;
	}

	FC2LTempleArtifactUse Out;
	Out.ArtifactIndex = Index;

	GetHUDStore().GetTempleManager().ReqArtifactUse(Index);
	AddCommandHistory(TEXT("/c_artifact_use"), Args);
}

void FCheater::PowerPlantOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "PowerPlantOpen");

	FC2LDevPowerPlantOpen Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/powerPlantOpen"), Out,
		TQ6ResponseDelegate<FL2CDevPowerPlantOpenResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPowerPlantOpenResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat power plant opened");
		ACTION_DISPATCH_DevPowerPlantOpenResp(Res);
	}));

	AddCommandHistory(TEXT("/c_plant_open"), Args);
}

void FCheater::PowerPlantUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Power plant upgrade");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_plant_upgrade <level>");
		return;
	}

	GetHUDStore().GetPowerPlantManager().ReqDevUpgrade(FCString::Atoi(*Args[0]));
	AddCommandHistory(TEXT("/c_plant_upgrade"), Args);
}

void FCheater::PetParkOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_pet_park_open");

	FC2LDevPetParkOpen Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/petParkOpen"), Out,
		TQ6ResponseDelegate<FL2CDevPetParkOpenResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPetParkOpenResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_pet_park_open Ok");
		ACTION_DISPATCH_DevPetParkOpenResp(Res);
	}));

	AddCommandHistory(TEXT("/c_pet_park_open"), Args);
}

void FCheater::PetParkUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_pet_park_upgrade");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_pet_park_upgrade <level>");
		return;
	}

	int32 Level = FCString::Atoi(*Args[0]);
	if (!FMath::IsWithinInclusive(Level, 1, SystemConst::Q6_MAX_WONDER_LEVEL))
	{
		Q6JsonLogCheater(Warning, "Usage: <level> is ", Q6KV("Min", 1), Q6KV("Max", SystemConst::Q6_MAX_WONDER_LEVEL));
		return;
	}

	GetHUDStore().GetPetManager().ReqDevPetParkUpgrade(Level);
	AddCommandHistory(TEXT("/c_pet_park_upgrade"), Args);
}

void FCheater::PetSkillUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_pet_skill_upgrade");

	if (Args.Num() < 3)
	{
		GetHUDStore().GetPetManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_pet_skill_upgrade <id> <index> <level>");
		return;
	}

	FPetId PetId(FCString::Atoi64(*Args[0]));
	int32 Index = FCString::Atoi(*Args[1]);
	int32 Level = FCString::Atoi(*Args[2]);

	if (!FMath::IsWithin(Index, 0, 3))
	{
		Q6JsonLogCheater(Warning, "Usage: <index> is zero-base", Q6KV("Min", 0), Q6KV("Max", 3));
		return;
	}

	if (!FMath::IsWithinInclusive(Level, 1, SystemConst::Q6_MAX_WONDER_LEVEL))
	{
		Q6JsonLogCheater(Warning, "Usage: <level> is ", Q6KV("Min", 1), Q6KV("Max", SystemConst::Q6_MAX_WONDER_LEVEL));
		return;
	}

	FC2LDevPetSkillUpgrade Out;
	Out.PetId = PetId;
	Out.Index = Index;
	Out.Level = Level;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/petSkillUpgrade"), Out,
		TQ6ResponseDelegate<FL2CDevPetSkillUpgradeResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPetSkillUpgradeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_pet_skill_upgrade Ok");
		ACTION_DISPATCH_DevPetSkillUpgradeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_pet_skill_upgrade"), Args);
}

void FCheater::PetNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_pet_new");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetPetManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_pet_new <type>");
		return;
	}

	FPetType PetType(FCString::Atoi64(*Args[0]));
	const FCMSPetRow& PetRow = GetCMS()->GetPetRowOrDummy(PetType);
	if (PetRow.IsInvalid())
	{
		Q6JsonLogCheater(Warning, "Unknown PetType", Q6KV("Type", (int32)PetType));
		return;
	}

	FC2LDevPetNew Out;
	Out.Type = PetType;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/petNew"), Out,
		TQ6ResponseDelegate<FL2CDevPetNewResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPetNewResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_pet_new Ok");
		ACTION_DISPATCH_DevPetNewResp(Res);
		GetHUDStore().GetPetManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_pet_new"), Args);
}

void FCheater::VacationOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "VacationOpen");

	FC2LDevVacationOpen Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/vacationOpen"), Out,
		TQ6ResponseDelegate<FL2CDevVacationOpenResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevVacationOpenResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat vacation opened");
		ACTION_DISPATCH_DevVacationOpenResp(Res);
	}));

	AddCommandHistory(TEXT("/c_vacation_open"), Args);
}

void FCheater::VacationUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Vacation upgrade");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_vacation_upgrade <level>");
		return;
	}

	GetHUDStore().GetVacationManager().ReqDevUpgrade(FCString::Atoi(*Args[0]));
	AddCommandHistory(TEXT("/c_vacation_upgrade"), Args);
}

void FCheater::SmelterOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_smelter_open");

	FC2LDevSmelterOpen Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/smelterOpen"), Out,
		TQ6ResponseDelegate<FL2CDevSmelterOpenResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevSmelterOpenResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat smelter opened");
		ACTION_DISPATCH_DevSmelterOpenResp(Res);
	}));

	AddCommandHistory(TEXT("/c_smelter_open"), Args);
}

void FCheater::SmelterInc(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_smelter_inc");
	GetHUDStore().GetSmelterManager().ReqIncStock();
	AddCommandHistory(TEXT("/c_smelter_inc"), Args);
}

void FCheater::SmelterDec(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_smelter_dec");
	GetHUDStore().GetSmelterManager().ReqDecStock();
	AddCommandHistory(TEXT("/c_smelter_dec"), Args);
}

void FCheater::SmelterReceive(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_smelter_receive");
	GetHUDStore().GetSmelterManager().ReqReceive();
	AddCommandHistory(TEXT("/c_smelter_receive"), Args);
}

void FCheater::SmelterUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_smelter_upgrade");
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_smelter_upgrade <level>");
		return;
	}

	int32 Level = FCString::Atoi(*Args[0]);
	FC2LDevSmelterUpgrade Out;
	Out.Level = Level;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/smelterUpgrade"), Out,
		TQ6ResponseDelegate<FL2CDevSmelterUpgradeResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevSmelterUpgradeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat smelter upgrade");
		ACTION_DISPATCH_DevSmelterUpgradeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_smelter_upgrade"), Args);
}

void FCheater::SmelterTime(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_smelter_time");
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_smelter_time <left time minute>");
		return;
	}

	int32 Left = FCString::Atoi(*Args[0]);
	FC2LDevSmelterTime Out;
	Out.Left = Left;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/smelterTime"), Out,
		TQ6ResponseDelegate<FL2CDevSmelterTimeResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevSmelterTimeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat smelter time");
		ACTION_DISPATCH_DevSmelterTimeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_smelter_time"), Args);
}

void FCheater::SmelterUpgradeComplete(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_smelter_upgrade_complete");
	GetHUDStore().GetSmelterManager().ReqUpgradeComplete();
	AddCommandHistory(TEXT("/c_smelter_upgrade_complete"), Args);
}

void FCheater::AlchemylabOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_alchemylab_open");

	FC2LDevAlchemylabOpen Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/alchemylabOpen"), Out,
		TQ6ResponseDelegate<FL2CDevAlchemylabOpenResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevAlchemylabOpenResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat alchemylab opened");
		ACTION_DISPATCH_DevAlchemylabOpenResp(Res);
	}));

	AddCommandHistory(TEXT("/c_alchemylab_open"), Args);
}

void FCheater::AlchemylabUpgrade(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_alchemylab_upgrade");
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_alchemylab_upgrade <level>");
		return;
	}

	int32 Level = FCString::Atoi(*Args[0]);
	FC2LDevAlchemylabUpgrade Out;
	Out.Level = Level;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/alchemylabUpgrade"), Out,
		TQ6ResponseDelegate<FL2CDevAlchemylabUpgradeResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevAlchemylabUpgradeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat alchemylab upgrade");
		ACTION_DISPATCH_DevAlchemylabUpgradeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_alchemylab_upgrade"), Args);
}

void FCheater::AlchemylabTime(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_alchemylab_time");
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_alchemylab_time <left time minute>");
		return;
	}

	int32 Left = FCString::Atoi(*Args[0]);
	FC2LDevAlchemylabTime Out;
	Out.Left = Left;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/alchemylabTime"), Out,
		TQ6ResponseDelegate<FL2CDevAlchemylabTimeResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevAlchemylabTimeResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Log, "cheat alchemylab time");
		ACTION_DISPATCH_DevAlchemylabTimeResp(Res);
	}));

	AddCommandHistory(TEXT("/c_alchemylab_time"), Args);
}

void FCheater::AlchemylabInc(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_alchemylab_inc");
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_alchemylab_inc <alchemylab cms id>");
		return;
	}

	GetHUDStore().GetAlchemylabManager().ReqIncStock(FAlchemyLabType(FCString::Atoi(*Args[0])));
	AddCommandHistory(TEXT("/c_alchemylab_inc"), Args);
}

void FCheater::AlchemylabDec(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_alchemylab_dec");
	GetHUDStore().GetAlchemylabManager().ReqDecStock();
	AddCommandHistory(TEXT("/c_alchemylab_dec"), Args);
}

void FCheater::AlchemylabReceive(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_alchemylab_receive");
	GetHUDStore().GetAlchemylabManager().ReqReceive();
	AddCommandHistory(TEXT("/c_alchemylab_receive"), Args);
}

void FCheater::GotoDialogue(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Goto dialogue");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_goto_dialogue <id>");
		return;
	}

	ALobbyHUD* LobbyHUD = GetLobbyHUD(GameInstance);
	if (LobbyHUD)
	{
		int32 GotoId = FCString::Atoi(*Args[0]);
		LobbyHUD->GotoDialogue(GotoId);
	}

	AddCommandHistory(TEXT("/c_goto_dialogue"), Args);
}

void FCheater::SkillNoteFix(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Fix Skill Note.");

	if (Args.Num() < 3)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_skill_note_fix <slot> <note> <index>");
		return;
	}

	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(GameInstance);
	if (!CombatGameMode)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_skill_note_fix used on battle.");
		return;
	}

	int32 Slot = FCString::Atoi(*Args[0]);
	if (Slot < 1 || Slot > 3)
	{
		Q6JsonLogCheater(Warning, "Usage: <slot> shold be 1 ~ 3.");
		return;
	}

	int32 Index = FCString::Atoi(*Args[2]);
	if (Index < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: <index> shold be >= 0.");
		return;
	}

	ESkillNote Note;
	if (FCString::Stricmp(*Args[1], TEXT("ace")) == 0)
	{
		Note = ESkillNote::Ace;
	}
	else if (FCString::Stricmp(*Args[1], TEXT("break")) == 0)
	{
		Note = ESkillNote::Break;
	}
	else if (FCString::Stricmp(*Args[1], TEXT("closer")) == 0)
	{
		Note = ESkillNote::Closer;
	}
	else
	{
		Q6JsonLogCheater(Warning, "Usage: <note> shold be \"ace\", \"break\", \"closer\".");
		return;
	}

	CombatGameMode->CombatCube->CheatFixSkillNote(Slot, Note, Index);
	AddCommandHistory(TEXT("/c_skill_note_fix"), Args);
}

void FCheater::SkillNoteShuffle(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "Shuffle Skill Note.");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_skill_note_shuffle <slot>");
		return;
	}

	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(GameInstance);
	if (!CombatGameMode)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_skill_note_shuffle used on battle.");
		return;
	}

	int32 Slot = FCString::Atoi(*Args[0]);
	if (Slot < 1 || Slot > 3)
	{
		Q6JsonLogCheater(Warning, "Usage: <slot> shold be 1 ~ 3.");
		return;
	}

	CombatGameMode->CombatCube->CheatShuffleSkillNote(Slot);
	AddCommandHistory(TEXT("/c_skill_note_shuffle"), Args);
}

void FCheater::MailSend(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Log, "c_mail_send");

	if (Args.Num() < 7)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_send_mail <type> <rewardType> <rewardItemCategory> <rewardItemType> <stacksize> <isInfiniteTime> <validMin>");
		return;
	}

	EMailType MailType = (EMailType)FCString::Atoi(*Args[0]);
	EMailRewardType MailRewardType = (EMailRewardType)FCString::Atoi(*Args[1]);
	ELootCategory MailRewardItemCategory = (ELootCategory)FCString::Atoi(*Args[2]);
	int32 MailRewardItemType = FCString::Atoi(*Args[3]);
	int32 StackSize = FCString::Atoi(*Args[4]);
	bool IsInfiniteTime = (bool)FCString::Atoi(*Args[5]);
	int32 ValidMin = FCString::Atoi(*Args[6]);
	int32 ReasonType = Args.IsValidIndex(7) ? FCString::Atoi(*Args[7]) : 0;

	// Check Type and RewardType
	switch (MailType)
	{
		case EMailType::Normal:
			{
				switch (MailRewardType)
				{
					case EMailRewardType::BuyShop:
						// fall through
					case EMailRewardType::CheckIn:
						// fall through
					case EMailRewardType::Quest:
						break;
					case EMailRewardType::WattRefund:
						{
							if (MailRewardItemCategory != ELootCategory::Watt)
							{
								Q6JsonLogCheater(Warning, "WattRefund Have WattCategory Only", Q6KV("Type", (int32)MailType), Q6KV("RewardType", (int32)MailRewardType), Q6KV("MailRewardItemType", MailRewardItemType));
								return;
							}
						}
						break;
					default:
						{
							Q6JsonLogCheater(Warning, "MisMatch MailType And MailRewardType", Q6KV("Type", (int32)MailType), Q6KV("RewardType", (int32)MailRewardType));
							return;
						}
						break;
				}
			}
			break;
		case EMailType::Management:
			{
				switch (MailRewardType)
				{
					case EMailRewardType::Push:
						// fall through
					case EMailRewardType::GM:
						break;
					default:
						{
							Q6JsonLogCheater(Warning, "MisMatch MailType And MailRewardType", Q6KV("Type", (int32)MailType), Q6KV("RewardType", (int32)MailRewardType));
							return;
						}
						break;
				}
			}
			break;
		default:
			{
				Q6JsonLogCheater(Warning, "Unknown Type", Q6KV("Type", (int32)MailType));
				return;
			}
			break;
	}

	// Check MailRewardItemCategory and MailRewardItemType and StackSize
	switch (MailRewardItemCategory)
	{
		case ELootCategory::CharacterCard:
			{
				const FCMSCharacterRow& Row = GetCMS()->GetCharacterRowOrDummy(FCharacterType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(CharacterType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}

				// check character xp card
				if (Row.XpExclusive == true)
				{
					if (StackSize < 1)
					{
						Q6JsonLogCheater(Warning, "Character Xp Card Item StackSize Larger Than 0", Q6KV("StackSize", StackSize));
						return;
					}
				}
				else if (StackSize != 1)
				{
					Q6JsonLogCheater(Warning, "Character Card Item StackSize Must Only 1", Q6KV("StackSize", StackSize));
					return;
				}
			}
			break;
		case ELootCategory::SculptureCard:
			// fall through
		case ELootCategory::RelicCard:
			// fall through
		case ELootCategory::LobbyTemplate:
			{
				if (StackSize > 1)
				{
					Q6JsonLogCheater(Warning, "Not Stack Item StackSize Larger Than 1", Q6KV("StackSize", StackSize));
					return;
				}
			}
			// fall through
		case ELootCategory::BagItem:
			// fall through
		case ELootCategory::Pet:
			// fall through
		case ELootCategory::PetSecondSkill:
			// fall through
		case ELootCategory::PetThirdSkill:
			// fall through
		case ELootCategory::VacationSpot:
			// fall through
		case ELootCategory::Wonder:
			// fall through
		case ELootCategory::Menu:
			// fall through
		case ELootCategory::Special:
			// fall through
		case ELootCategory::Artifact:
			{
				if (MailRewardItemType < 1)
				{
					Q6JsonLogCheater(Warning, "Category Item, RewardItemType Not Set", Q6KV("MailRewardItemCategory", (int32)MailRewardItemCategory), Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}

				if (MailRewardItemCategory == ELootCategory::Artifact)
				{
					break;
				}
			}
			// fall through
		case ELootCategory::Gold:
			// fall through
		case ELootCategory::FreeGem:
			// fall through
		case ELootCategory::PaidGem:
			// fall through
		case ELootCategory::SummonTicket:
			// fall through
		case ELootCategory::SculpturePoint:
			// fall through
		case ELootCategory::RelicPoint:
			// fall through
		case ELootCategory::FriendshipPoint:
			// fall through
		case ELootCategory::SmallBattery:
			// fall through
		case ELootCategory::MediumBattery:
			// fall through
		case ELootCategory::LargeBattery:
			// fall through
		case ELootCategory::Lumicube:
			// fall through
		case ELootCategory::Watt:
			// fall through
		case ELootCategory::CharacterDisk:
			// fall through
		case ELootCategory::SculptureDisk:
			// fall through
		case ELootCategory::RelicDisk:
			{
				if (StackSize < 1)
				{
					Q6JsonLogCheater(Warning, "StackSize Less Than 1", Q6KV("StackSize", StackSize));
					return;
				}
			}
			break;
		default:
			{
				Q6JsonLogCheater(Warning, "Unknown MailRewardItemCategory", Q6KV("MailRewardItemCategory", (int32)MailRewardItemCategory));
				return;
			}
			break;
	}

	// Check Validate MailRewardItemType
	switch (MailRewardItemCategory)
	{
		case ELootCategory::CharacterCard:
			{
				const FCMSCharacterRow& Row = GetCMS()->GetCharacterRowOrDummy(FCharacterType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(CharacterType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::SculptureCard:
			{
				const FCMSSculptureRow& Row = GetCMS()->GetSculptureRowOrDummy(FSculptureType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(SculptureType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::RelicCard:
			{
				const FCMSRelicRow& Row = GetCMS()->GetRelicRowOrDummy(FRelicType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(RelicType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::BagItem:
			{
				const FCMSBagItemRow& Row = GetCMS()->GetBagItemRowOrDummy(FBagItemType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(BagItemType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::Pet:
			{
				const FCMSPetRow& Row = GetCMS()->GetPetRowOrDummy(FPetType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(PetType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::PetSecondSkill:
			// fall through
		case ELootCategory::PetThirdSkill:
			{
				const FCMSSkillRow& Row = GetCMS()->GetSkillRowOrDummy(FSkillType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(PetSkillType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
				if (Row.SkillCategory != ESkillCategory::Pet)
				{
					Q6JsonLogCheater(Warning, "Not PetSkill(PetSkillType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::VacationSpot:
			{
				const FCMSVacationSpotRow& Row = GetCMS()->GetVacationSpotRowOrDummy(FVacationSpotType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(VacationSpotType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::Wonder:
			{
				const FCMSWonderRow& Row = GetCMS()->GetWonderRowOrDummy(FWonderType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(WonderType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::Menu:
			{
				// Under Construction
				Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(MenuType)", Q6KV("MailRewardItemType", MailRewardItemType));
				return;
			}
			break;
		case ELootCategory::Special:
			{
				const FCMSSpecialRow& Row = GetCMS()->GetSpecialRowOrDummy(FSpecialType(MailRewardItemType));
				if (Row.IsInvalid())
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(SpecialType)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::Artifact:
			{
				if (MailRewardItemType < 1 || MailRewardItemType > 3)
				{
					Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(Artifact)", Q6KV("MailRewardItemType", MailRewardItemType));
					return;
				}
			}
			break;
		case ELootCategory::LobbyTemplate:
		{
			const FCMSLobbyTemplateRow& Row = GetCMS()->GetLobbyTemplateRowOrDummy(FLobbyTemplateType(MailRewardItemType));
			if (Row.IsInvalid())
			{
				Q6JsonLogCheater(Warning, "Unknown MailRewardItemType(LobbyTemplateType)", Q6KV("MailRewardItemType", MailRewardItemType));
				return;
			}
		}
			break;
		default:
			break;
	}

	FC2LDevMailSend Out;
	Out.Type = MailType;
	Out.RewardType = MailRewardType;
	Out.RewardItemCategory = MailRewardItemCategory;
	Out.RewardItemType = MailRewardItemType;
	Out.StackSize = StackSize;
	Out.IsInfiniteTime = IsInfiniteTime;
	Out.ValidMin = ValidMin;
	Out.ReasonType = ReasonType;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/mailSend"), Out,
		TQ6ResponseDelegate<FL2CDevMailSendResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevMailSendResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_mail_send", Q6KV("Result", Resp.Ok), Q6KV("MailType", (int32)Resp.Type),Q6KV("MailRewardType", (int32)Resp.RewardType),
			Q6KV("RewardItemCategory", (int32)Resp.RewardItemCategory), Q6KV("RewardItemType", Resp.RewardItemType), Q6KV("StackSize", Resp.StackSize),
			Q6KV("IsInfiniteTime", Resp.IsInfiniteTime), Q6KV("ValidMin", Resp.ValidMin), Q6KV("ReasonType", Resp.ReasonType));
	}));

	AddCommandHistory(TEXT("/c_send_mail"), Args);
}

void FCheater::CheckInDay(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_check_in_day");

	if (Args.Num() < 1)
	{
		GetHUDStore().GetCheckInManager().Dump();
		Q6JsonLogCheater(Warning, "Usage: /c_check_in_day <board type> [day count]");
		return;
	}

	FCheckInBoardType BoardType = FCheckInBoardType(FCString::Atoi64(*Args[0]));
	int32 DayCount = 1;
	if (Args.IsValidIndex(1))
	{
		DayCount = FCString::Atoi64(*Args[1]);
	}
	else
	{
		if (const FCheckInInfo* CheckInInfo = GetHUDStore().GetCheckInManager().GetCheckInInfo(BoardType))
		{
			DayCount = CheckInInfo->DayCount + 1;
		}
	}

	FC2LDevCheckInDay Out;
	Out.BoardType = BoardType;
	Out.DayCount = DayCount;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/checkInDay"), Out,
		TQ6ResponseDelegate<FL2CDevCheckInLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevCheckInLoadResp& Msg)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevCheckInLoadResp(Msg);
		GetHUDStore().GetCheckInManager().Dump();
	}));

	AddCommandHistory(TEXT("/c_check_in_day"), Args);
}

void FCheater::AddCurrencyInternal(ECurrencyType CurrencyType, int32 GainValue)
{
	FC2LDevAddCurrency Out;
	Out.CurrencyType = CurrencyType;
	Out.GainValue = GainValue;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (!Q6BaseHUD)
	{
		return;
	}

	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/addCurrency"), Out,
		TQ6ResponseDelegate<FL2CDevAddCurrencyResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevAddCurrencyResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "cheat add currency");
		ACTION_DISPATCH_DevAddCurrencyResp(Res);
	}));
}

void FCheater::ShopReset(const TArray<FString>& Args)
{
	FC2LDevShopReset Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/shopReset"), Out,
		TQ6ResponseDelegate<FL2CDevShopResetResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevShopResetResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevShopResetResp(Resp);

		Q6JsonLogCheater(Warning, "/c_shop_reset Ok");
	}));

	AddCommandHistory(TEXT("/c_shop_reset"), Args);
}

void FCheater::TempleProduce(const TArray<FString>& Args)
{
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_temple_produce <produced hour>");
		return;
	}

	FC2LDevTempleProduce Out;
	Out.ProducedHour = FCString::Atoi(*Args[0]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/templeProduce"), Out,
		TQ6ResponseDelegate<FL2CDevTempleProduceResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevTempleProduceResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevTempleProduceResp(Resp);

		Q6JsonLogCheater(Warning, "/c_temple_produce Ok");
	}));

	AddCommandHistory(TEXT("/c_temple_produce"), Args);
}

void FCheater::PetParkProduce(const TArray<FString>& Args)
{
	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_pet_park_produce <produced hour>");
		return;
	}

	FC2LDevPetParkProduce Out;
	Out.ProducedHour = FCString::Atoi(*Args[0]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/petParkProduce"), Out,
		TQ6ResponseDelegate<FL2CDevPetParkProduceResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevPetParkProduceResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevPetParkProduceResp(Resp);

		Q6JsonLogCheater(Warning, "/c_pet_park_produce Ok");
	}));

	AddCommandHistory(TEXT("/c_pet_park_produce"), Args);
}

void FCheater::AddLumicube(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddLumicube");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_lumicube <count>");
		return;
	}

	int32 Count = FCString::Atoi(*Args[0]);
	if (Count < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_lumicube <count>");
		return;
	}

	AddCurrencyInternal(ECurrencyType::Lumicube, Count);
	AddCommandHistory(TEXT("/c_add_lumicube"), Args);
}

void FCheater::AddCharacterDisk(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddCharacterDisk");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_character_disk <count>");
		return;
	}

	int32 Count = FCString::Atoi(*Args[0]);
	if (Count < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_character_disk <count>");
		return;
	}

	AddCurrencyInternal(ECurrencyType::CharacterDisk, Count);
	AddCommandHistory(TEXT("/c_add_character_disk"), Args);
}

void FCheater::AddSculptureDisk(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddSculptureDisk");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_sculpture_disk <count>");
		return;
	}

	int32 Count = FCString::Atoi(*Args[0]);
	if (Count < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_sculpture_disk <count>");
		return;
	}

	AddCurrencyInternal(ECurrencyType::SculptureDisk, Count);
	AddCommandHistory(TEXT("/c_add_sculpture_disk"), Args);
}

void FCheater::AddRelicDisk(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "AddRelicDisk");
	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_relic_disk <count>");
		return;
	}

	int32 Count = FCString::Atoi(*Args[0]);
	if (Count < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_add_relic_disk <count>");
		return;
	}

	AddCurrencyInternal(ECurrencyType::RelicDisk, Count);
	AddCommandHistory(TEXT("/c_add_relic_disk"), Args);
}

void FCheater::WeeklyMissionReward(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_weekly_mission_reward");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_weekly_mission_reward <index>");
		return;
	}

	int32 Index = FCString::Atoi64(*Args[0]);
	GetHUDStore().GetWeeklyMissionManager().ReqReward(Index);

	AddCommandHistory(TEXT("/c_weekly_mission_reward"), Args);
}

void FCheater::CharMissionReward(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_char_mission_reward");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_char_mission_reward <char id> <index>");
		return;
	}

	FCharacterType Type = FCharacterType(FCString::Atoi(*Args[0]));
	int32 Index = FCString::Atoi64(*Args[1]);
	GetHUDStore().GetCharMissionManager().ReqReward(Type, Index);

	AddCommandHistory(TEXT("/c_char_mission_reward"), Args);
}

void FCheater::WeeklyMissionBingo(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_weekly_mission_bingo");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_weekly_mission_bingo <index>");
		return;
	}

	int32 Index = FCString::Atoi64(*Args[0]);
	GetHUDStore().GetWeeklyMissionManager().ReqBingo(Index);

	AddCommandHistory(TEXT("/c_weekly_mission_bingo"), Args);
}

void FCheater::WeeklyMissionShuffle(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_weekly_mission_shuffle");
	GetHUDStore().GetWeeklyMissionManager().ReqShuffle();

	AddCommandHistory(TEXT("/c_weekly_mission_shuffle"), Args);
}

void FCheater::WeeklyMissionReset(const TArray<FString>& Args)
{
	FC2LDevWeeklyMissionReset Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/weeklyMissionReset"), Out,
		TQ6ResponseDelegate<FL2CWeeklyMissionLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CWeeklyMissionLoadResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_ClearWeeklyMission();
		ACTION_DISPATCH_WeeklyMissionLoadResp(Resp);

		Q6JsonLogCheater(Warning, "/c_weekly_mission_reset");
	}));

	AddCommandHistory(TEXT("/c_weekly_mission_reset"), Args);
}

void FCheater::UserRecordList(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_user_record_list");
	GetHUDStore().GetUserRecordManager().ReqList();

	AddCommandHistory(TEXT("/c_user_record_list"), Args);
}

void FCheater::SetSummonMileage(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_mileage_set");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_mileage_set <event id> <amount>");
		return;
	}

	FC2LDevSummonMileageSet Out;
	Out.EventId = FCString::Atoi64(*Args[0]);
	Out.Mileage = FCString::Atoi64(*Args[1]);
	if (Out.Mileage < 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_mileage_set <event id> <amount>");
		return;
	}

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/summonMileageSet"), Out,
		TQ6ResponseDelegate<FL2CDevSummonMileageSetResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevSummonMileageSetResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevSummonMileageSetResp(Resp);

		Q6JsonLogCheater(Warning, "/c_mileage_set Ok");
	}));

	AddCommandHistory(TEXT("/c_mileage_set"), Args);
}

void FCheater::CharMissionSet(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_char_mission_set");

	if (Args.Num() < 3)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_char_mission_set <char type> <index> <amount>");
		return;
	}

	FC2LDevCharMissionSet Out;
	Out.CharType = FCharacterType(FCString::Atoi(*Args[0]));
	Out.Index = FCString::Atoi64(*Args[1]);
	Out.Amount = FCString::Atoi64(*Args[2]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/charMissionSet"), Out,
		TQ6ResponseDelegate<FL2CDevCharMissionSetResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevCharMissionSetResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevCharMissionSetResp(Resp);

		Q6JsonLogCheater(Warning, "/c_char_mission_set Ok");
	}));

	AddCommandHistory(TEXT("/c_char_mission_set"), Args);
}

void FCheater::LobbyTemplateNew(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_lobby_template_new");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_lobby_template_new <type>");
		return;
	}

	auto Type = FLobbyTemplateType(FCString::Atoi(*Args[0]));

	FC2LDevLobbyTemplateNew Out;
	Out.Type = Type;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/lobbyTemplateNew"), Out,
		TQ6ResponseDelegate<FL2CDevLobbyTemplateNewResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevLobbyTemplateNewResp& Res)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevLobbyTemplateNewResp(Res);

		Q6JsonLogCheater(Warning, "lobbyTemaplte added",
			Q6KV("Id", Res.Info.LobbyTemplateId),
			Q6KV("Type", Res.Info.Type));
	}));

	AddCommandHistory(TEXT("/c_lobby_template_new"), Args);
}

void FCheater::JokerSetCharacterSave(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_joker_set_character");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_joker_set_character <grade> <level>");
		return;
	}

	FC2LDevJokerSetCharacterSave Out;
	Out.Grade = (EItemGrade)FCString::Atoi64(*Args[0]);
	Out.Level = FCString::Atoi64(*Args[1]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/jokerSetCharacterSave"), Out,
		TQ6ResponseDelegate<FL2CJokerSetSaveResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CJokerSetSaveResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_JokerSetSaveResp(Resp);

		Q6JsonLogCheater(Warning, "/c_joker_set_character Ok");
	}));

	AddCommandHistory(TEXT("/c_joker_set_character"), Args);
}

void FCheater::FriendAdd(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_friend_add");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_friend_add <user code>");
		return;
	}

	FC2LDevFriendAdd Out;
	Out.TargetUserCode = *Args[0];

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/friendAdd"), Out,
		TQ6ResponseDelegate<FL2CFriendAcceptResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CFriendAcceptResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_friend_add Ok");
	}));

	AddCommandHistory(TEXT("/c_friend_add"), Args);
}

void FCheater::TitleAdd(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_title_add");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_title_add <type>");
		return;
	}

	FC2LDevTitleAdd Out;
	Out.Type = FUserTitleType(FCString::Atoi(*Args[0]));

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/titleAdd"), Out,
		TQ6ResponseDelegate<FL2CDevTitleAddResp>::CreateLambda([Q6BaseHUD](
			const FResError* Error, const FL2CDevTitleAddResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevTitleAddResp(Resp);

		Q6JsonLogCheater(Warning, "/c_title_add Ok");
	}));

	AddCommandHistory(TEXT("/c_title_add"), Args);
}

void FCheater::TitleChange(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_title_change");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_title_change <type>");
		return;
	}

	GetHUDStore().GetTitleManager().Change(FUserTitleType(FCString::Atoi(*Args[0])));
	AddCommandHistory(TEXT("/c_title_change"), Args);
}

void FCheater::ShopBuy(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_shop_buy");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_shop_buy <type> <count>");
		return;
	}

	FShopType Type = FShopType(FCString::Atoi(*Args[0]));
	int32 Count = FCString::Atoi(*Args[1]);

	GetHUDStore().GetShopManager().ReqBuyItem(Type, Count);
	AddCommandHistory(TEXT("/c_title_change"), Args);
}

void FCheater::ContentFeatureOpen(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_content_feature_open");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_content_feature_open <open all party sub slot>");
		return;
	}

	int32 OpenAllOpenPartySubSlot = FCString::Atoi(*Args[0]) == 1 ? 1 : 0;

	FC2LDevContentFeatureOpen Out;
	Out.OpenAllPartySubSlot = OpenAllOpenPartySubSlot;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/contentFeatureOpen"), Out,
		TQ6ResponseDelegate<FL2CDevContentFeatureOpenResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevContentFeatureOpenResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevContentFeatureOpenResp(Resp);

		Q6JsonLogCheater(Warning, "/c_content_feature_open Ok");
	}));

	AddCommandHistory(TEXT("/c_content_feature_open"), Args);
}

void FCheater::EventContentReward(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_event_content_reward");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_event_content_reward <event content id> <loot gruop id>");
		return;
	}

	FEventContentType EventContentType = FEventContentType(FCString::Atoi(*Args[0]));
	FLootGroupType LootGroupType = FLootGroupType(FCString::Atoi(*Args[1]));

	FC2LDevEventContentReward Out;
	Out.EventContentType = EventContentType;
	Out.LootGroupType = LootGroupType;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();

	ClientNetwork.WsRequest(TEXT("dev/eventContentReward"), Out,
		TQ6ResponseDelegate<FL2CDevEventContentRewardResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevEventContentRewardResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_event_content_reward Ok");
	}));

	AddCommandHistory(TEXT("/c_event_content_reward"), Args);
}

void FCheater::EventContentNumberOfDays(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_event_content_number_of_days");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_event_content_number_of_days <days>");
		return;
	}

	FC2LDevEventContentNumberOfDays Out;
	Out.EventContentNumberOfDays = FCString::Atoi(*Args[0]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/eventContentNumberOfDays"), Out,
		TQ6ResponseDelegate<FL2CDevEventContentNumberOfDaysResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevEventContentNumberOfDaysResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevEventContentNumberOfDaysResp(Resp);

		Q6JsonLogCheater(Warning, "/c_event_content_number_of_days Ok");
	}));

	AddCommandHistory(TEXT("/c_event_content_number_of_days"), Args);
}

void FCheater::EventContentMultiSideBattleLoad(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_event_content_multi_side_battle_load");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_event_content_multi_side_battle_load <event content id>");
		return;
	}

	FEventContentType EventContentType = FEventContentType(FCString::Atoi(*Args[0]));
	GetHUDStore().GetEventManager().ReqEventContentMultisideBattleRankLoad(EventContentType);
	AddCommandHistory(TEXT("/c_event_content_multi_side_battle_load"), Args);
}

void FCheater::EventContentMultiSideBattleReceiveRankReward(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_event_content_multi_side_battle_load");

	if (Args.Num() < 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_event_content_multi_side_battle_load <event content id>");
		return;
	}

	FEventContentType EventContentType = FEventContentType(FCString::Atoi(*Args[0]));
	GetHUDStore().GetEventManager().ReqEventContentMultiSideBattleReceiveRankReward(EventContentType);
	AddCommandHistory(TEXT("/c_event_content_multi_side_battle_receive_rank_reward"), Args);
}

void FCheater::AvatarAdd(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_avatar_add");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_avatar_add <category> <type> <illust>");
		return;
	}

	FC2LDevAvatarAdd Out;
	Out.Category = (EAvatarCategory)FCString::Atoi(*Args[0]);
	Out.Type = FCString::Atoi(*Args[1]);
	Out.Illust = Args.IsValidIndex(2) ? FCString::Atoi(*Args[2]) : 0;

	if (Out.Category == EAvatarCategory::Frame)
	{
		const FAvatarFrameAssetRow* AssetRow = GetGameResource().GetAvatarFrameAssetRow(FAvatarFrameType(Out.Type));
		if (!AssetRow)
		{
			Q6JsonLogCheater(Warning, "FCheater::AvatarAdd - No have avatar frame asset");
			return;
		}
	}
	else if (Out.Category == EAvatarCategory::Effect)
	{
		const FAvatarEffectAssetRow* AssetRow = GetGameResource().GetAvatarEffectAssetRow(FAvatarEffectType(Out.Type));
		if (!AssetRow)
		{
			Q6JsonLogCheater(Warning, "FCheater::AvatarAdd - No have avatar effect asset");
			return;
		}
	}

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/avatarAdd"), Out,
		TQ6ResponseDelegate<FL2CDevAvatarAddResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevAvatarAddResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_avatar_add Ok");
		ACTION_DISPATCH_DevAvatarAddResp(Resp);
	}));

	AddCommandHistory(TEXT("/c_avatar_add"), Args);
}

void FCheater::FriendBookFeedAdd(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_friend_book_feed_add <type> <param1> <param2> <param3> <param4> <param5>");

	if (Args.Num() != 6)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_friend_book_feed_add <type> <param1> <param2> <param3> <param4> <param5>");
		return;
	}

	FFriendBookFeedType FeedType(FCString::Atoi(*Args[0]));
	int32 Param1 = FCString::Atoi(*Args[1]);
	int32 Param2 = FCString::Atoi(*Args[2]);
	int32 Param3 = FCString::Atoi(*Args[3]);
	int32 Param4 = FCString::Atoi(*Args[4]);
	int32 Param5 = FCString::Atoi(*Args[5]);

	FC2LDevFriendBookFeedAdd Out;
	Out.Type = FeedType;
	Out.Param1 = Param1;
	Out.Param2 = Param2;
	Out.Param3 = Param3;
	Out.Param4 = Param4;
	Out.Param5 = Param5;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/friendBookFeedAdd"), Out,
		TQ6ResponseDelegate<FL2CDevFriendBookFeedAddResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevFriendBookFeedAddResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_friend_book_feed_add Ok");
	}));

	AddCommandHistory(TEXT("/c_friend_book_feed_add"), Args);
}

void FCheater::FriendBookReactionAdd(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_friend_book_reaction_add <feed id> <type> <feed-owner user id>");

	if (Args.Num() != 3)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_friend_book_reaction_add <feed id> <type> <feed-owner user id>");
		return;
	}

	FFriendBookFeedId FeedId(FCString::Atoi64(*Args[0]));
	EFriendBookReactionType ReactionType = static_cast<EFriendBookReactionType>(FCString::Atoi(*Args[1]));
	FUserId FeedOwnerUserId(FCString::Atoi64(*Args[2]));

	FC2LFriendBookAddReaction Out;
	Out.FeedId = FeedId;
	Out.Type = ReactionType;
	Out.FeedOwnerUserId = FeedOwnerUserId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("friendBook/addReaction"), Out,
		TQ6ResponseDelegate<FL2CFriendBookAddReactionResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CFriendBookAddReactionResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_friend_book_reaction_add Ok");
	}));

	AddCommandHistory(TEXT("/c_friend_book_reaction_add"), Args);
}

void FCheater::FriendBookReactionRemove(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_friend_book_reaction_remove <feed id> <feed-owner user id>");

	if (Args.Num() != 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_friend_book_reaction_remove <feed id> <feed-owner user id>");
		return;
	}

	FFriendBookFeedId FeedId(FCString::Atoi64(*Args[0]));
	FUserId FeedOwnerUserId(FCString::Atoi64(*Args[1]));

	FC2LFriendBookRemoveReaction Out;
	Out.FeedId = FeedId;
	Out.FeedOwnerUserId = FeedOwnerUserId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("friendBook/removeReaction"), Out,
		TQ6ResponseDelegate<FL2CFriendBookRemoveReactionResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CFriendBookRemoveReactionResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_friend_book_reaction_remove Ok");
	}));

	AddCommandHistory(TEXT("/c_friend_book_reaction_remove"), Args);
}

void FCheater::FriendBookTimelineLoad(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_friend_book_timeline_load <last feed id>");

	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_friend_book_timeline_load <last feed id>");
		return;
	}

	FFriendBookFeedId FeedId(FCString::Atoi64(*Args[0]));

	FC2LFriendBookGetTimeline Out;
	Out.LastFeedId = FeedId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("friendBook/getTimeline"), Out,
		TQ6ResponseDelegate<FL2CFriendBookGetTimelineResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CFriendBookGetTimelineResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_friend_book_timeline_load Ok");
	}));

	AddCommandHistory(TEXT("/c_friend_book_timeline_load"), Args);
}

void FCheater::FriendBookFeedLoad(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_friend_book_feed_load <feed id>");

	if (Args.Num() != 1)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_friend_book_feed_load <feed id>");
		return;
	}

	FFriendBookFeedId FeedId(FCString::Atoi64(*Args[0]));

	FC2LFriendBookGetFeed Out;
	Out.FeedId = FeedId;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("friendBook/getFeed"), Out,
		TQ6ResponseDelegate<FL2CFriendBookGetFeedResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CFriendBookGetFeedResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_friend_book_feed_load Ok");
	}));

	AddCommandHistory(TEXT("/c_friend_book_feed_load"), Args);
}

void FCheater::EventContentAddPoint(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_event_content_add_point");

	if (Args.Num() < 3)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_event_content_add_point <event content id> <point index> <count>");
		return;
	}

	FEventContentType EventContentType(FCString::Atoi(*Args[0]));
	int32 PointIndex = FCString::Atoi(*Args[1]);
	int32 Count = FCString::Atoi(*Args[2]);

	FC2LDevEventContentAddPoint Out;
	Out.Type = EventContentType;
	Out.PointIndex = PointIndex;
	Out.Count = Count;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/eventContentAddPoint"), Out,
		TQ6ResponseDelegate<FL2CDevEventContentAddPointResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevEventContentAddPointResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevEventContentAddPointResp(Resp);

		Q6JsonLogCheater(Warning, "/c_event_content_add_point Ok");
	}));

	AddCommandHistory(TEXT("/c_event_content_add_point"), Args);
}

void FCheater::EventContentRechargeWatt(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_event_content_watt_recharge");

	if (Args.Num() != 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_event_content_watt_recharge <event content id> <amount>");
		return;
	}

	FEventContentType EventContentType(FCString::Atoi(*Args[0]));
	int32 Amount = FCString::Atoi(*Args[1]);

	FC2LDevEventContentRechargeWatt Out;
	Out.Type = EventContentType;
	Out.Amount = Amount;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/eventContentRechargeWatt"), Out,
		TQ6ResponseDelegate<FL2CDevEventContentRechargeWattResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevEventContentRechargeWattResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevEventContentRechargeWAttResp(Resp);

		Q6JsonLogCheater(Warning, "/c_event_content_watt_recharge Ok");
	}));

	AddCommandHistory(TEXT("/c_event_content_watt_recharge"), Args);
}

void FCheater::EventContentRouletteReset(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "c_event_content_roulette_reset");

	if (Args.Num() < 2)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_event_content_add_point <event content id> <point index> <count>");
		return;
	}

	FEventContentType EventContentType(FCString::Atoi(*Args[0]));
	int32 LineUp = FCString::Atoi(*Args[1]);

	FC2LDevEventContentRouletteReset Out;
	Out.RouletteLineUpInfo.EventContentType = EventContentType;
	Out.RouletteLineUpInfo.LineUp = LineUp;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/eventContentRouletteReset"), Out,
		TQ6ResponseDelegate<FL2CDevEventContentRouletteResetResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevEventContentRouletteResetResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		if (Resp.IsReset)
		{
			ACTION_DISPATCH_DevEventContentRouletteResetResp(Resp);
			Q6JsonLogCheater(Warning, "/c_event_content_roulette_reset Ok");
		}
		else
		{
			Q6JsonLogCheater(
				Error,
				"/c_event_content_roulette_reset",
				Q6KV("EventContentId", (int32)Resp.RouletteLineUpInfo.EventContentType),
				Q6KV("LineUp", Resp.RouletteLineUpInfo.LineUp));
		}
	}));

	AddCommandHistory(TEXT("/c_event_content_roulette_reset"), Args);
}

void FCheater::FriendBotAll(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_friend_bot_all");

	FC2LDevFriendBotAll Out;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/friendBotAll"), Out,
		TQ6ResponseDelegate<FL2CDevFriendBotAllResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevFriendBotAllResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_friend_bot_all Ok");
		ACTION_DISPATCH_DevFriendBotAllResp(Resp);
	}));

	AddCommandHistory(TEXT("/c_friend_bot_all"), Args);
}

void FCheater::FriendCooltimeSet(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_friend_cooltime");
	FC2LDevFriendCooltime Out;
	int32 Cooltime = FCString::Atoi(*Args[0]);
	Out.Cooltime = Cooltime;
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/friendCooltime"), Out,
		TQ6ResponseDelegate<FL2CDevFriendCooltimeResp>::CreateLambda(
			[Q6BaseHUD](const FResError* Error, const FL2CDevFriendCooltimeResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}
		Q6JsonLogCheater(Warning, "/c_friend_cooltime Ok");
		ACTION_DISPATCH_DevFriendCooltimeResp(Resp);
	}));
	AddCommandHistory(TEXT("/c_friend_cooltime"), Args);
}

void FCheater::SummonCountSet(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_summon_count_set");

	if (Args.Num() < 3)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_summon_count_set <category> <type> <count>");
		return;
	}

	FC2LDevSummonCountSet Out;
	Out.Category = (ELootCategory)FCString::Atoi(*Args[0]);
	Out.Type = FCString::Atoi(*Args[1]);
	Out.Count = FCString::Atoi(*Args[2]);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/summonCountSet"), Out,
		TQ6ResponseDelegate<FL2CDevSummonCountSetResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevSummonCountSetResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		Q6JsonLogCheater(Warning, "/c_summon_count_set Ok");
	}));

	AddCommandHistory(TEXT("/c_summon_count_set"), Args);
}

void FCheater::CheckInOpenTime(const TArray<FString>& Args)
{
	Q6JsonLogCheater(Warning, "/c_check_in_open_time");

	if (Args.Num() < 3)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_check_in_open_time <board type> <date> <time>");
		return;
	}

	FC2LDevCheckInOpenTime Out;
	Out.BoardType = FCheckInBoardType(FCString::Atoi(*Args[0]));
	Out.OpenTime = Args[1] + " "+ Args[2];

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("dev/checkInOpenTime"), Out,
		TQ6ResponseDelegate<FL2CDevCheckInLoadResp>::CreateLambda([Q6BaseHUD](const FResError* Error, const FL2CDevCheckInLoadResp& Resp)
	{
		if (Error)
		{
			BaseHUDOnError(Q6BaseHUD, Error);
			return;
		}

		ACTION_DISPATCH_DevCheckInLoadResp(Resp);
	}));

	AddCommandHistory(TEXT("/c_check_in_open_time"), Args);
}

void FCheater::LoadCommandHistory()
{
	FString FilePath = GetCommandHistoryFilePath();
	FString HistoryLoadStr;
	if (!FFileHelper::LoadFileToString(HistoryLoadStr, *FilePath))
	{
		return;
	}

	HistoryLoadStr.ParseIntoArrayLines(CommandHistory);
}

void FCheater::SaveCommandHistory()
{
	FString HistorySaveStr;

	for (int32 i = 0; i < CommandHistory.Num(); ++i)
	{
		HistorySaveStr.Append(CommandHistory[i]);
		HistorySaveStr.Append(TEXT("\r\n"));
	}

	FString FilePath = GetCommandHistoryFilePath();
	if (!FFileHelper::SaveStringToFile(HistorySaveStr, *FilePath))
	{
		Q6JsonLogRoze(Error, "Failed to save output file", Q6KV("FilePath", *FilePath));
	}
}

void FCheater::AddCommandHistory(const FString& Command, const TArray<FString>& Args)
{
	if (Command.Equals(TEXT("h")))
	{
		return;
	}

	FString NewCommandHistoryStr = Command;
	for (const FString& Arg : Args)
	{
		NewCommandHistoryStr.AppendChar(' ');
		NewCommandHistoryStr.Append(Arg);
	}

	if (CommandHistory.Num() >= MAX_COMMAND_HISTORY_COUNT)
	{
		CommandHistory.RemoveAt(0);
	}

	CommandHistory.Add(NewCommandHistoryStr);

	SaveCommandHistory();
}

void FCheater::OpenCheatCommandHelpPopup()
{
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (Q6BaseHUD)
	{
		Q6BaseHUD->OpenCheatCommandHelpPopup(ShortcutObjects, CommandHistory);
	}
}

#endif //!UE_BUILD_SHIPPING