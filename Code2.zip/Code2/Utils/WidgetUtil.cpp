// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "WidgetUtil.h"

#include "BagItemManager.h"
#include "CharacterManager.h"
#include "CMSTable.h"
#include "Formula.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "HUDStore/Q6Account.h"
#include "ItemWidgets.h"
#include "LobbyObj_gen.h"
#include "MovieScene.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6SummonGameMode.h"
#include "Q6UIDefine.h"
#include "RelicManager.h"
#include "SculptureManager.h"
#include "SystemConstHelper.h"
#include "UMG.h"
#include "JsonObjectConverter.h"

bool SetWidgetVisibilityFromName(UUserWidget* Parent, FName WidgetName, ESlateVisibility Visibility)
{
	if (Parent)
	{
		if (UWidget* Child = Parent->GetWidgetFromName(WidgetName))
		{
			Child->SetVisibility(Visibility);
			return true;
		}
	}

	return false;
}

UWidgetAnimation* GetWidgetAnimationFromName(UUserWidget* Widget, FName AnimationName)
{
	UWidgetAnimation* WidgetAnimation = GetNullableWidgetAnimationFromName(Widget, AnimationName);
	ensure(WidgetAnimation);

	if (!WidgetAnimation)
	{
		Q6JsonLogZagal(Warning, "No WidgetAnimation",
			Q6KV("Widget", *Widget->GetName()),
			Q6KV("Animation", *AnimationName.ToString()));
	}

	return WidgetAnimation;
}

UWidgetAnimation* GetNullableWidgetAnimationFromName(UUserWidget* Widget, FName AnimationName)
{
	UWidgetBlueprintGeneratedClass* BGClass = Cast<UWidgetBlueprintGeneratedClass>(Widget->GetClass());
	ensure(BGClass);

	for (const auto& Anim : BGClass->Animations)
	{
		FString AnimInstanceName = Anim->GetMovieScene()->GetFName().ToString();

		if (AnimInstanceName.Equals(AnimationName.ToString()))
		{
			return Anim;
		}
	}

	return nullptr;
}

FGeometry FindWidgetGeometry(const UWidget* Widget)
{
	if (!Widget)
	{
		return FGeometry();
	}

	TSharedPtr<SWidget> MyWidget = Widget->GetCachedWidget();
	if (!MyWidget.IsValid())
	{
		return FGeometry();
	}

	FWidgetPath MyWidgetPath;
	FSlateApplication::Get().GeneratePathToWidgetUnchecked(MyWidget.ToSharedRef(), MyWidgetPath);
	if (!MyWidgetPath.IsValid())
	{
		return FGeometry();
	}

	const FGeometry& MyGeometry = MyWidgetPath.Widgets.Last().Geometry;
	return MyGeometry;
}

bool FindWidgetGeometry(const UWidget* Widget, FGeometry* OutGeometry)
{
	if (!Widget)
	{
		return false;
	}

	TSharedPtr<SWidget> MyWidget = Widget->GetCachedWidget();
	if (!MyWidget.IsValid())
	{
		return false;
	}

	FWidgetPath MyWidgetPath;
	FSlateApplication::Get().GeneratePathToWidgetUnchecked(MyWidget.ToSharedRef(), MyWidgetPath);
	if (!MyWidgetPath.IsValid())
	{
		return false;
	}

	*OutGeometry = MyWidgetPath.Widgets.Last().Geometry;
	return true;
}


TArray<FCharacterId> GetPreciousCharacters(const UCMS* CMS, const TArray<FCharacterId>& CharacterIds)
{
	check(CMS);

	TArray<FCharacterId> FilteredCharacterIds;

	const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();

	for (const FCharacterId& CharacterId : CharacterIds)
	{
		const FCharacter* Character = CharMgr.Find(CharacterId);
		if (!Character)
		{
			continue;
		}

		const FCharacterInfo& CharInfo = Character->GetInfo();
		if ((int32)CharInfo.Grade >= (int32)EItemGrade::SR)
		{
			FilteredCharacterIds.Add(CharacterId);
			continue;
		}

		if (CharInfo.Level >= (SystemConstHelper::GetCharacterMaxLevel(CharInfo.Star, CharInfo.Moon)))
		{
			FilteredCharacterIds.Add(CharacterId);
			continue;
		}
	}

	return FilteredCharacterIds;
}

bool _CheckPreciousCharacter(const UCMS* CMS, const TArray<int64>& ItemIds)
{
	const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();
	for (const int64& ItemId : ItemIds)
	{
		const FCharacter* Character = CharMgr.Find(FCharacterId(ItemId));
		if (!Character)
		{
			continue;
		}

		const FCharacterInfo& CharInfo = Character->GetInfo();
		if ((int32)CharInfo.Grade >= (int32)EItemGrade::SR)
		{
			return true;
		}

		if (CharInfo.Level >= (SystemConstHelper::GetCharacterMaxLevel(CharInfo.Star, CharInfo.Moon)))
		{
			return true;
		}
	}

	return false;
}

bool _CheckPreciousRelic(const TArray<int64>& ItemIds)
{
	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	for (const int64& ItemId : ItemIds)
	{
		const FRelic* Relic = RelicMgr.Find(FRelicId(ItemId));
		if (!Relic)
		{
			continue;
		}

		const FRelicInfo& RelicInfo = Relic->Info;
		if ((int32)RelicInfo.Grade >= (int32)EItemGrade::SR)
		{
			return true;
		}

		if (RelicInfo.Level >= (SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star)))
		{
			return true;
		}
	}

	return false;
}

bool _CheckPreciousSculpture(const TArray<int64>& ItemIds)
{
	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	for (const int64& ItemId : ItemIds)
	{
		const FSculpture* Sculpture = SculptureMgr.Find(FSculptureId(ItemId));
		if (!Sculpture)
		{
			continue;
		}

		const FSculptureInfo& SculptureInfo = Sculpture->Info;
		if ((int32)SculptureInfo.Grade >= (int32)EItemGrade::SR)
		{
			return true;
		}

		if (SculptureInfo.Level >= (SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star)))
		{
			return true;
		}
	}

	return false;
}

bool HasPreciousItem(const UCMS* CMS, EUpgradeCategory ItemCategory, const TArray<int64>& ItemIds)
{
	check(CMS);

	switch (ItemCategory)
	{
		case EUpgradeCategory::Character:
			return _CheckPreciousCharacter(CMS, ItemIds);
		case EUpgradeCategory::Relic:
			return _CheckPreciousRelic(ItemIds);
		case EUpgradeCategory::Sculpture:
			return _CheckPreciousSculpture(ItemIds);
	}

	return false;
}

bool _CheckHighTierRelic(const UCMS* CMS, int32 BaseTier, const TArray<int64>& RelicIds)
{
	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	for (const int64& ItemId : RelicIds)
	{
		const FRelic* Relic = RelicMgr.Find(FRelicId(ItemId));
		if (!Relic)
		{
			continue;
		}

		const FRelicInfo& RelicInfo = Relic->Info;
		if (RelicInfo.Tier <= BaseTier)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool _CheckHighTierSculpture(const UCMS* CMS, int32 BaseTier, const TArray<int64>& SculptureIds)
{
	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	for (const int64& ItemId : SculptureIds)
	{
		const FSculpture* Sculpture = SculptureMgr.Find(FSculptureId(ItemId));
		if (!Sculpture)
		{
			continue;
		}

		const FSculptureInfo& SculptureInfo = Sculpture->Info;
		if (SculptureInfo.Tier <= BaseTier)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool HasHighTierEquip(const UCMS* CMS, EUpgradeCategory ItemCategory, int32 BaseTier, const TArray<int64>& EquipIds)
{
	check(CMS);

	switch (ItemCategory)
	{
		case EUpgradeCategory::Relic:
			return _CheckHighTierRelic(CMS, BaseTier, EquipIds);
		case EUpgradeCategory::Sculpture:
			return _CheckHighTierSculpture(CMS, BaseTier, EquipIds);
	}

	return false;
}

bool HasHighUltLevel(const UCMS* CMS, int32 BaseLevel, const TArray<int64>& CharacterIds)
{
	check(CMS);

	const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();
	for (const int64& ItemId : CharacterIds)
	{
		const FCharacter* Character = CharMgr.Find(FCharacterId(ItemId));
		if (!Character)
		{
			continue;
		}

		const FCharacterInfo& CharacterInfo = Character->GetInfo();
		if (CharacterInfo.UltimateSkillLevel <= BaseLevel)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool CanCharacterMaxLevelUp(const FCMSPromoteCostRow& PromoteCostRow)
{
	if (PromoteCostRow.Gold <= 0 || PromoteCostRow.GetBagItem().Num() <= 0)
	{
		return false;
	}

	return CanItemPromote(PromoteCostRow);
}

bool CanRelicPromote(const UCMS* CMS, int32 CurrentStar)
{
	check(CMS);

	const FCMSPromoteCostRow& PromoteCostRow = CMS->GetEquipPromoteCostRowOrDummy(EPromoteCategory::Relic, CurrentStar + 1);
	return CanItemPromote(PromoteCostRow);
}

bool CanSculpturePromote(const UCMS* CMS, int32 CurrentStar)
{
	check(CMS);

	const FCMSPromoteCostRow& PromoteCostRow = CMS->GetEquipPromoteCostRowOrDummy(EPromoteCategory::Sculpture, CurrentStar + 1);
	return CanItemPromote(PromoteCostRow);
}

bool CanTierUpgrade(int32 CurrentTier, int32 TargetTier)
{
	if (TargetTier <= CurrentTier)
	{
		return false;
	}

	int32 GoldCost = SystemConstHelper::GetEquipTierUpCost(CurrentTier, TargetTier);
	if (!GetHUDStore().GetWorldUser().HasEnoughGold(GoldCost))
	{
		return false;
	}

	return true;
}

bool CanItemPromote(const FCMSPromoteCostRow& PromoteCostRow)
{
	if (!GetHUDStore().GetWorldUser().HasEnoughGold(PromoteCostRow.Gold))
	{
		return false;
	}

	const TArray<const FCMSBagItemRow*>& MaterialItemRows = PromoteCostRow.GetBagItem();
	const UBagItemManager& BagItemMgr = GetHUDStore().GetBagItemManager();

	for (int32 i = 0; i < MaterialItemRows.Num(); ++i)
	{
		if (!BagItemMgr.HasEnoughBagItem(MaterialItemRows[i]->CmsType(), PromoteCostRow.ItemCount[i]))
		{
			return false;
		}
	}

	return true;
}

bool CanCharacterEvolute(const UCMS* CMS, int32 Moon, EItemGrade ItemGrade)
{
	check(CMS);

	int64 GoldCost = SystemConstHelper::GetCharacterEvoluteCost(Moon, ItemGrade);
	if (!GetHUDStore().GetWorldUser().HasEnoughGold(GoldCost))
	{
		return false;
	}

	const UBagItemManager& BagItemMgr = GetHUDStore().GetBagItemManager();
	FBagItemType EvoluteItemType = FBagItemType(SystemConst::Q6_CHARACTER_EVOLUTION_MATERIAL);
	if (!BagItemMgr.HasEnoughBagItem(EvoluteItemType, CharacterEvoluteMaterialCount))
	{
		return false;
	}

	return true;
}

bool CanTurnSkillUpgrade(const UCMS* CMS, const FCharacterId& CharacterId)
{
	for (int TurnSkillIndex = 0; TurnSkillIndex < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++TurnSkillIndex)
	{
		if (CanTurnSkillUpgrade(CMS, CharacterId, TurnSkillIndex))
		{
			return true;
		}
	}

	return false;
}

bool CanTurnSkillUpgrade(const UCMS* CMS, const FCharacterId& CharacterId, int32 TurnSkillIndex)
{
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();

	bool bHasEnoughGold = CharacterManager.HasEnoughGoldForTurnSkillUpgrade(CharacterId, TurnSkillIndex);
	if (!bHasEnoughGold)
	{
		return false;
	}

	bool bHasEnoughMaterials = CharacterManager.HasEnoughMaterialsForTurnSkillUpgrade(CharacterId, TurnSkillIndex);
	if (!bHasEnoughMaterials)
	{
		return false;
	}

	bool bEnoughLevel = CharacterManager.IsEnoughLevelForTurnSkillUpgrade(CharacterId, TurnSkillIndex);
	if (!bEnoughLevel)
	{
		return false;
	}

	bool bEnoughStar = CharacterManager.IsEnoughStarForTurnSkillUpgrade(CharacterId, TurnSkillIndex);
	if (!bEnoughStar)
	{
		return false;
	}

	return true;
}

bool CanUltimateSkillUpgrade(const UCMS* CMS, int32 CurrentLevel, int32 TargetLevel)
{
	check(CMS);

	if (TargetLevel <= CurrentLevel)
	{
		return false;
	}

	int32 GoldCost = SystemConstHelper::GetCharacterUltimateUpCost(CurrentLevel, TargetLevel);
	if (!GetHUDStore().GetWorldUser().HasEnoughGold(GoldCost))
	{
		return false;
	}

	return true;
}

void ConvertCharacterToItemInfo(EAttributeCategory AttributeType, const FCharacterInfo& CharacterInfo, const FCharacterBond& CharacterBond, FItemIconInfo* OutInfo)
{
	OutInfo->Id = CharacterInfo.CharacterId.S;
	OutInfo->AttributeType = AttributeType;
	OutInfo->Type = CharacterInfo.Type;
	OutInfo->Grade = CharacterInfo.Grade;
	OutInfo->Star = CharacterInfo.Star;
	OutInfo->Moon = CharacterInfo.Moon;
	OutInfo->Tier = 0;
	OutInfo->Level = CharacterInfo.Level.x;
	OutInfo->Xp = CharacterInfo.Xp;
	OutInfo->BondXp = CharacterBond.Xp;
	OutInfo->bLocked = CharacterInfo.Locked > 0;
	OutInfo->bFinalArt = CharacterInfo.Illust > 0;

	OutInfo->SetSkillLevels(CharacterInfo.TurnSkill1Level, CharacterInfo.TurnSkill2Level, CharacterInfo.TurnSkill3Level,
		CharacterInfo.UltimateSkillLevel, CharacterBond.SupportSkillLevel);
}

void ConvertSculptureToItemInfo(const FSculptureInfo& SculptureInfo, FItemIconInfo* OutInfo)
{
	OutInfo->Id = SculptureInfo.SculptureId.S;
	OutInfo->AttributeType = EAttributeCategory::Sculpture;
	OutInfo->Type = SculptureInfo.Type;
	OutInfo->Grade = SculptureInfo.Grade;
	OutInfo->Star = SculptureInfo.Star;
	OutInfo->Moon = 0;
	OutInfo->Tier = SculptureInfo.Tier;
	OutInfo->Level = SculptureInfo.Level.x;
	OutInfo->Xp = SculptureInfo.Xp;
	OutInfo->BondXp = 0;
	OutInfo->bLocked = SculptureInfo.Locked > 0;
	OutInfo->bFinalArt = false;

	OutInfo->SetSkillLevels(0, 0, 0, 0, 0);
}

void ConvertRelicToItemInfo(const FRelicInfo& RelicInfo, FItemIconInfo* OutInfo)
{
	OutInfo->Id = RelicInfo.RelicId.S;
	OutInfo->AttributeType = EAttributeCategory::Relic;
	OutInfo->Type = RelicInfo.Type;
	OutInfo->Grade = RelicInfo.Grade;
	OutInfo->Star = RelicInfo.Star;
	OutInfo->Moon = 0;
	OutInfo->Tier = RelicInfo.Tier;
	OutInfo->Level = RelicInfo.Level.x;
	OutInfo->Xp = RelicInfo.Xp;
	OutInfo->BondXp = 0;
	OutInfo->bLocked = RelicInfo.Locked > 0;
	OutInfo->bFinalArt = false;

	OutInfo->SetSkillLevels(0, 0, 0, 0, 0);
}

void MakeDefaultCharacterItemInfo(const FCMSCharacterRow& CharacterRow, FItemIconInfo* OutInfo)
{
	OutInfo->Type = CharacterRow.Type;
	OutInfo->Grade = CharacterRow.Grade;
	OutInfo->Star = CharacterRow.StartStar;
	OutInfo->Moon = 0;
	OutInfo->Level = 1;
	OutInfo->AttributeType = EAttributeCategory::Character;

	OutInfo->SetSkillLevels(1, 0, 0, 1, 1);
}

void MakeDefaultRelicItemInfo(const FCMSRelicRow& RelicRow, FItemIconInfo* OutInfo)
{
	OutInfo->Type = RelicRow.Type;
	OutInfo->Grade = RelicRow.Grade;
	OutInfo->Star = RelicRow.Star;
	OutInfo->Tier = 1;
	OutInfo->Level = 1;
	OutInfo->AttributeType = EAttributeCategory::Relic;
}

void MakeDefaultSculptureItemInfo(const FCMSSculptureRow& SculptureRow, FItemIconInfo* OutInfo)
{
	OutInfo->Type = SculptureRow.Type;
	OutInfo->Grade = SculptureRow.Grade;
	OutInfo->Star = SculptureRow.Star;
	OutInfo->Tier = 1;
	OutInfo->Level = 1;
	OutInfo->AttributeType = EAttributeCategory::Sculpture;
}

EPointType GetPointType(ESummonPointType InPointType)
{
	switch (InPointType)
	{
		case ESummonPointType::AnyGem: return EPointType::AnyGem;
		case ESummonPointType::PaidGem: return EPointType::PaidGem;
		case ESummonPointType::Friendship: return EPointType::Friendship;
		case ESummonPointType::Relic: return EPointType::Relic;
		case ESummonPointType::Sculpture: return EPointType::Sculpture;
	}

	return EPointType::None;
}

EPointType GetPointType(ECurrencyType InCurrencyType)
{
	switch (InCurrencyType)
	{
		case ECurrencyType::Gold: return EPointType::Gold;
		case ECurrencyType::FreeGem: return EPointType::AnyGem;
		case ECurrencyType::PaidGem: return EPointType::PaidGem;
		case ECurrencyType::SummonTicket: return EPointType::SummonTicket;
		case ECurrencyType::SculpturePoint: return EPointType::Sculpture;
		case ECurrencyType::RelicPoint: return EPointType::Relic;
		case ECurrencyType::FriendshipPoint: return EPointType::Friendship;
		case ECurrencyType::SmallBattery: return EPointType::SmallBattery;
		case ECurrencyType::MediumBattery: return EPointType::MediumBattery;
		case ECurrencyType::LargeBattery: return EPointType::LargeBattery;
		case ECurrencyType::Lumicube: return EPointType::Lumicube;
		case ECurrencyType::CharacterDisk: return EPointType::CharacterDisk;
		case ECurrencyType::SculptureDisk: return EPointType::SculptureDisk;
		case ECurrencyType::RelicDisk: return EPointType::RelicDisk;
	}

	return EPointType::None;
}

EPointType GetPointType(ELootCategory InLootCategory)
{
	switch (InLootCategory)
	{
		case ELootCategory::SculptureCard:
		case ELootCategory::SculpturePoint:
			return EPointType::Sculpture;
		case ELootCategory::RelicCard:
		case ELootCategory::RelicPoint:
			return EPointType::Relic;
		case ELootCategory::Gold:
			return EPointType::Gold;
		case ELootCategory::FreeGem:
			return EPointType::FreeGem;
		case ELootCategory::PaidGem:
			return EPointType::PaidGem;
		case ELootCategory::SummonTicket:
			return EPointType::SummonTicket;
		case ELootCategory::FriendshipPoint:
			return EPointType::Friendship;
		case ELootCategory::SmallBattery:
			return EPointType::SmallBattery;
		case ELootCategory::MediumBattery:
			return EPointType::MediumBattery;
		case ELootCategory::LargeBattery:
			return EPointType::LargeBattery;
		case ELootCategory::Lumicube:
			return EPointType::Lumicube;
		case ELootCategory::Watt:
			return EPointType::Watt;
		case ELootCategory::CharacterDisk:
			return EPointType::CharacterDisk;
		case ELootCategory::SculptureDisk:
			return EPointType::SculptureDisk;
		case ELootCategory::RelicDisk:
			return EPointType::RelicDisk;
	}

	return EPointType::None;
}

ECurrencyType GetCurrencyType(ELootCategory ItemCategory)
{
	switch (ItemCategory)
	{
		case ELootCategory::Gold:				return ECurrencyType::Gold;
		case ELootCategory::FreeGem:			return ECurrencyType::FreeGem;
		case ELootCategory::PaidGem:			return ECurrencyType::PaidGem;
		case ELootCategory::SummonTicket:		return ECurrencyType::SummonTicket;
		case ELootCategory::SculpturePoint:		return ECurrencyType::SculpturePoint;
		case ELootCategory::RelicPoint:			return ECurrencyType::RelicPoint;
		case ELootCategory::FriendshipPoint:	return ECurrencyType::FriendshipPoint;
		case ELootCategory::SmallBattery:		return ECurrencyType::SmallBattery;
		case ELootCategory::MediumBattery:		return ECurrencyType::MediumBattery;
		case ELootCategory::LargeBattery:		return ECurrencyType::LargeBattery;
		case ELootCategory::Lumicube:			return ECurrencyType::Lumicube;
		case ELootCategory::CharacterDisk:		return ECurrencyType::CharacterDisk;
		case ELootCategory::SculptureDisk:		return ECurrencyType::SculptureDisk;
		case ELootCategory::RelicDisk:			return ECurrencyType::RelicDisk;
	}

	return ECurrencyType::None;
}

bool IsCollectionCategory(ELootCategory InLootCetegory)
{
	if (InLootCetegory == ELootCategory::CharacterCard
		|| InLootCetegory == ELootCategory::RelicCard
		|| InLootCetegory == ELootCategory::SculptureCard)
	{
		return true;
	}

	return false;
}


EDayOfWeek ConvertDayOfWeekTypeToUE4(EDayOfWeekType DayOfWeek)
{
	switch (DayOfWeek)
	{
		case EDayOfWeekType::Sun:
			return EDayOfWeek::Sunday;
		case EDayOfWeekType::Mon:
			return EDayOfWeek::Monday;
		case EDayOfWeekType::Tue:
			return EDayOfWeek::Tuesday;
		case EDayOfWeekType::Wed:
			return EDayOfWeek::Wednesday;
		case EDayOfWeekType::Thu:
			return EDayOfWeek::Thursday;
		case EDayOfWeekType::Fri:
			return EDayOfWeek::Friday;
		case EDayOfWeekType::Sat:
			return EDayOfWeek::Saturday;
	}

	Q6JsonLogZagal(Warning, "ConvertDayOfWeekTypeToUE4 - Unreachable", Q6KV("Type", (int32)DayOfWeek));
	return EDayOfWeek::Monday;
}

EDayOfWeekType ConvertDayOfWeekType(EDayOfWeek DayOfWeek)
{
	// HardCode
	// UE4 Day of week is Monday(0)-based
	switch (DayOfWeek)
	{
		case EDayOfWeek::Monday:
			return EDayOfWeekType::Mon;
		case EDayOfWeek::Tuesday:
			return EDayOfWeekType::Tue;
		case EDayOfWeek::Wednesday:
			return EDayOfWeekType::Wed;
		case EDayOfWeek::Thursday:
			return EDayOfWeekType::Thu;
		case EDayOfWeek::Friday:
			return EDayOfWeekType::Fri;
		case EDayOfWeek::Saturday:
			return EDayOfWeekType::Sat;
		case EDayOfWeek::Sunday:
			return EDayOfWeekType::Sun;
		default:
			Q6JsonLogGunny(Warning, "ConvertDayOfWeekType - Day of week from UE4 Error");
			return EDayOfWeekType::Max;
	}
}

EDayOfWeekType GetTodayOfWeek(int32 ClockModValue)
{
	FDateTime LocalTime = FDateTime::Now();
#if !UE_BUILD_SHIPPING
	LocalTime += FTimespan::FromMinutes(ClockModValue);
#endif
	EDayOfWeek DayOfWeek = LocalTime.GetDayOfWeek();

	return ConvertDayOfWeekType(DayOfWeek);
}

ERewardType GetRewardType(ESagaRewardType RewardType)
{
	switch (RewardType)
	{
		case ESagaRewardType::Clear:
			return ERewardType::None;
		case ESagaRewardType::InitialClear:
		case ESagaRewardType::DailyFirstClear:
			return ERewardType::First;
		case ESagaRewardType::TrainingCenterPhaseClear:
			return ERewardType::Promote;
		case ESagaRewardType::FindFirst:
			return ERewardType::Found;
		case ESagaRewardType::Ranking:
			return ERewardType::Ranking;
		case ESagaRewardType::DamageBossHp:
			return ERewardType::Goal;
		case ESagaRewardType::EpisodeClear:
			return ERewardType::EpisodeClearReward;
		default:
			return ERewardType::None;
	}
}

FText MakeStageNumberText(const FCMSSagaRow& SagaRow)
{
	if (SagaRow.SubStage <= 0)
	{
		return FText::AsNumber(SagaRow.Stage);
	}

	return FText::FromString(FString::Printf(TEXT("%d-%d"), SagaRow.Stage, SagaRow.SubStage));
}

bool IsStoryLikeStageType(EStageType StageType)
{
	switch (StageType)
	{
	case EStageType::Story:
	case EStageType::Prologue:
	case EStageType::Epilogue:
		return true;
	}

	return false;
}

bool IsEventContentType(EContentType ContentType)
{
	return (ContentType == EContentType::Event
		|| ContentType == EContentType::EventMap
		|| ContentType == EContentType::MultiSideBattle);
}

FString GetEquipEffectsStr(int32 Tier, const TArray<const FCMSBuffRow*>& Buffs)
{
	FTextFormat TooltipTextFormat = Q6Util::GetLocalizedText("Lobby", "EquipEffectRow");

	FString EffectsStr;
	for (const FCMSBuffRow* BuffRow : Buffs)
	{
		check(BuffRow);

		if (BuffRow->FollowMoment != EMoment::None)
		{
			const TArray<const FCMSSkillRow*> FollowMomentSkills = BuffRow->GetFollowMomentSkill();
			for (const FCMSSkillRow* FollowMomentSkill : FollowMomentSkills)
			{
				check(FollowMomentSkill);

				FSkillType MomentSkillType = FollowMomentSkill->CmsType();
				if (MomentSkillType == SkillTypeInvalid)
				{
					continue;
				}

				FText TooltipText = FText::Format(TooltipTextFormat, BuildToolTipDesc(MomentSkillType, Tier, ESkillCategory::Equipment));
				EffectsStr.Append(TooltipText.ToString());
			}
		}

		for (const FCMSBuffEffectRow* BuffEffect : BuffRow->GetBuffEffect())
		{
			check(BuffEffect);

			FText EffectText = BuildToolTipBuffEffectDesc(BuffEffect->CmsType(), Tier, ESkillCategory::Equipment);
			FText TooltipText = FText::Format(TooltipTextFormat, EffectText);
			EffectsStr.Append(TooltipText.ToString());
		}
	}

	return EffectsStr;
}

EDialogueType ConvertToDialogueType(EContentType ContentType)
{
	switch (ContentType)
	{
		case EContentType::Saga:
			return EDialogueType::Saga;
		case EContentType::Special:
			return EDialogueType::Special;
		case EContentType::DailyDungeon:
			return EDialogueType::Daily;
		case EContentType::TrainingCenter:
			return EDialogueType::Training;
		case EContentType::Raid:
		case EContentType::RaidFinal:
			return EDialogueType::Raid;
		case EContentType::Event:
			return EDialogueType::Event;
		case EContentType::MultiSideBattle:
			return EDialogueType::MultiSide;
	}

	return EDialogueType::None;
}

EWonderCategory GetWonderCategory(ESpecialCategory SpecialCategory)
{
	switch (SpecialCategory)
	{
		case ESpecialCategory::Powerplant:
			return EWonderCategory::Powerplant;
		case ESpecialCategory::Temple:
			return EWonderCategory::Temple;
		case ESpecialCategory::Pet:
		case ESpecialCategory::PetSecondSkill:
		case ESpecialCategory::PetThirdSkill:
			return EWonderCategory::PetPark;
		case ESpecialCategory::SculpturePortal:
		case ESpecialCategory::RelicPortal:
		case ESpecialCategory::CharacterPortal:
		case ESpecialCategory::Pyramid:
			return EWonderCategory::Pyramid;
		case ESpecialCategory::Vacation:
			return EWonderCategory::Vacation;
		case ESpecialCategory::Smelter:
			return EWonderCategory::MigriumRefinery;
		case ESpecialCategory::AlchemyLab:
			return EWonderCategory::AlchemyLab;
	}
	return EWonderCategory::Main;
}

EWonderCategory GetWonderCategory(ELootCategory LootCategory)
{
	switch (LootCategory)
	{
		case ELootCategory::Artifact:
			return EWonderCategory::Temple;
		case ELootCategory::Pet:
		case ELootCategory::PetSecondSkill:
		case ELootCategory::PetThirdSkill:
			return EWonderCategory::PetPark;
		case ELootCategory::VacationSpot:
			return EWonderCategory::Vacation;
	}

	return EWonderCategory::Main;
}

EWonderCategory GetWonderCategory(EFeatureOpenType FeatureOpenType)
{
	switch (FeatureOpenType)
	{
		case EFeatureOpenType::WonderPetPark:
			return EWonderCategory::PetPark;
		case EFeatureOpenType::WonderPowerplant:
			return EWonderCategory::Powerplant;
		case EFeatureOpenType::WonderPyramid:
			return EWonderCategory::Pyramid;
		case EFeatureOpenType::WonderTemple:
			return EWonderCategory::Temple;
		case EFeatureOpenType::WonderVacation:
			return EWonderCategory::Vacation;
		case EFeatureOpenType::WonderAlchemyLab:
			return EWonderCategory::AlchemyLab;
		case EFeatureOpenType::WonderSmelter:
			return EWonderCategory::MigriumRefinery;
	}

	return EWonderCategory::Main;
}

EFeatureOpenType GetFeatureOpenType(EWonderCategory WonderCategory)
{
	switch (WonderCategory)
	{
		case EWonderCategory::Temple:
			return EFeatureOpenType::WonderTemple;
		case EWonderCategory::PetPark:
			return EFeatureOpenType::WonderPetPark;
		case EWonderCategory::Pyramid:
			return EFeatureOpenType::WonderPyramid;
		case EWonderCategory::Powerplant:
			return EFeatureOpenType::WonderPowerplant;
		case EWonderCategory::Vacation:
			return EFeatureOpenType::WonderVacation;
		case EWonderCategory::AlchemyLab:
			return EFeatureOpenType::WonderAlchemyLab;
		case EWonderCategory::MigriumRefinery:
			return EFeatureOpenType::WonderSmelter;
	}

	Q6JsonLogGenie(Warning, "GetFeatureOpenType - Unreachable"
		, Q6KV("WonderCategory", static_cast<int32>(WonderCategory)));
	return EFeatureOpenType::SpecialStage;
}

FText GetWonerNameText(EWonderCategory WonderCategory)
{
	switch (WonderCategory)
	{
		case EWonderCategory::PetPark:
			return Q6Util::GetLocalizedText("Lobby", "WonderPetPark");
		case EWonderCategory::Powerplant:
			return Q6Util::GetLocalizedText("Lobby", "WonderPowerplant");
		case EWonderCategory::Pyramid:
			return Q6Util::GetLocalizedText("Lobby", "WonderPyramid");
		case EWonderCategory::Temple:
			return Q6Util::GetLocalizedText("Lobby", "WonderTemple");
		case EWonderCategory::Vacation:
			return Q6Util::GetLocalizedText("Lobby", "WonderVacation");
		case EWonderCategory::AlchemyLab:
			return Q6Util::GetLocalizedText("Lobby", "WonderAlchemyLab");
		case EWonderCategory::MigriumRefinery:
			return Q6Util::GetLocalizedText("Lobby", "WonderMigriumRefinery");
		case EWonderCategory::Main:	
		default: // Fall through
			return FText::GetEmpty();
	}
}

FText BuildToolTipDesc(int32 SkillType, int32 SkillLevelOrTier, ESkillCategory BornCategory, bool bSimpleNotice)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillType);
	if (SkillRow.IsInvalid())
	{
		Q6JsonLog(Warning, "tooltip invalid skilltype", Q6KV("skilltype", SkillType));
		return FText::GetEmpty();
	}

	if (bSimpleNotice)
	{
		return SkillRow.DescName;
	}

	FString DescStr = SkillRow.Desc.ToString();
	DescStr = DescStr.LeftChop(1);
	DescStr = DescStr.RightChop(1);
	FToolTipDesc Desc;
	if (!FJsonObjectConverter::JsonObjectStringToUStruct(DescStr, &Desc, 0, 0))
	{
		Q6JsonLog(Warning, "tooltip parse failed", Q6KV("skilltype", SkillType));
		return SkillRow.Desc;
	}

	FFormatNamedArguments Args;
	for (int i = 0; i < Desc.Elements.Num(); ++i)
	{
		const FToolTipElement& E = Desc.Elements[i];

		int32 Value = 0;
		if (E.Sheet == EToolTipSheet::SkillEffect)
		{
			const FCMSSkillEffectRow& Row = GetCMS()->GetSkillEffectRowOrDummy(FSkillEffectType(E.Type));
			if (Row.IsInvalid())
			{
				Q6JsonLog(Warning, "tooltip invalid skilleffect", Q6KV("skilltype", SkillType), Q6KV("SkillEffectType", E.Type));
				continue;
			}

			Value = Formula::InterpolatedBySkillLevelOrTier(SkillLevelOrTier, Row.Param1Min, Row.Param1, BornCategory);
		}
		else if (E.Sheet == EToolTipSheet::BuffEffect)
		{
			const FCMSBuffEffectRow& Row = GetCMS()->GetBuffEffectRowOrDummy(FBuffEffectType(E.Type));
			if (Row.IsInvalid())
			{
				Q6JsonLog(Warning, "tooltip invalid buffeffect", Q6KV("skilltype", SkillType), Q6KV("BuffEffectType", E.Type));
				continue;
			}

			if (E.ParamIdx == 2)
			{
				Value = Formula::InterpolatedBySkillLevelOrTier(SkillLevelOrTier, Row.Param2Min, Row.Param2, BornCategory);
			}
			else if (E.ParamIdx == 3)
			{
				Value = Formula::InterpolatedBySkillLevelOrTier(SkillLevelOrTier, Row.Param3Min, Row.Param3, BornCategory);
			}
			else
			{
				Q6JsonLog(Warning, "tooltip invalid param", Q6KV("skilltype", SkillType), Q6KV("BuffEffectType", E.Type), Q6KV("param index", E.ParamIdx));
			}
		}
		else if (E.Sheet == EToolTipSheet::BuffDuration)
		{
			const FCMSBuffRow& Row = GetCMS()->GetBuffRowOrDummy(FBuffType(E.Type));
			if (Row.IsInvalid())
			{
				Q6JsonLog(Warning, "tooltip invalid Buff", Q6KV("skilltype", SkillType), Q6KV("BuffDurationType", E.Type));
				continue;
			}

			Value = Row.Duration;
		}
		else if (E.Sheet == EToolTipSheet::BuffHitCount)
		{
			const FCMSBuffRow& Row = GetCMS()->GetBuffRowOrDummy(FBuffType(E.Type));
			if (Row.IsInvalid())
			{
				Q6JsonLog(Warning, "tooltip invalid Buff", Q6KV("skilltype", SkillType), Q6KV("BuffHitCount", E.Type));
				continue;
			}

			Value = Row.HitCount;
		}
		else
		{
			Q6JsonLog(Warning, "tooltip invalid sheet", Q6KV("skilltype", SkillType), Q6KV("Sheet", (int32)E.Sheet));
		}

		Value = FMath::Abs(Value);
		FString ValueStr = FString::FromInt(Value);
		if (E.Unit == EToolTipUnit::Percent)
		{
			int32 Quotient = Value / 10;
			int32 Remainder = Value % 10;

			if (Remainder == 0)
			{
				ValueStr = FString::Printf(TEXT("%d%%"), Quotient);
			}
			else
			{
				ValueStr = FString::Printf(TEXT("%d.%d%%"), Quotient, Remainder);
			}
		}

		FString Key = FString::FromInt(i);
		Args.Add(Key, FText::FromString(ValueStr));
	}

	return FText::Format(FText::FromString(Desc.Msg), Args);
}

FText BuildToolTipBuffEffectDesc(FBuffEffectType BuffEffectType, int32 BuffLevel, ESkillCategory BornCategory, bool bSimpleNotice)
{
	const FCMSBuffEffectRow& BuffEffectRow = GetCMS()->GetBuffEffectRowOrDummy(BuffEffectType);
	if (BuffEffectRow.IsInvalid())
	{
		Q6JsonLog(Warning, "tooltip invalid buffeffect", Q6KV("BuffEffectType", BuffEffectType));
		return FText::GetEmpty();
	}

 	if (bSimpleNotice)
 	{
 		return BuffEffectRow.DescName;
 	}

	FString DescStr = BuffEffectRow.Desc.ToString();
	DescStr = DescStr.LeftChop(1);
	DescStr = DescStr.RightChop(1);
	FToolTipDesc Desc;
	if (!FJsonObjectConverter::JsonObjectStringToUStruct(DescStr, &Desc, 0, 0))
	{
		Q6JsonLog(Warning, "tooltip parse failed", Q6KV("BuffEffectType", BuffEffectType));
		return BuffEffectRow.Desc;
	}

	FFormatNamedArguments Args;
	for (int i = 0; i < Desc.Elements.Num(); ++i)
	{
		const FToolTipElement& E = Desc.Elements[i];
		int32 Value = 0;

		if (E.Sheet != EToolTipSheet::BuffEffect)
		{
			continue;
		}

		if (E.ParamIdx == 2)
		{
			Value = Formula::InterpolatedBySkillLevelOrTier(BuffLevel, BuffEffectRow.Param2Min, BuffEffectRow.Param2, BornCategory);
		}
		else if (E.ParamIdx == 3)
		{
			Value = Formula::InterpolatedBySkillLevelOrTier(BuffLevel, BuffEffectRow.Param3Min, BuffEffectRow.Param3, BornCategory);
		}
		else
		{
			Q6JsonLog(Warning, "tooltip invalid param", Q6KV("BuffEffectType", E.Type), Q6KV("param index", E.ParamIdx));
		}

		Value = FMath::Abs(Value);
		FString ValueStr = FString::FromInt(Value);
		if (E.Unit == EToolTipUnit::Percent)
		{
			int32 Quotient = Value / 10;
			int32 Remainder = Value % 10;

			if (Remainder == 0)
			{
				ValueStr = FString::Printf(TEXT("%d%%"), Quotient);
			}
			else
			{
				ValueStr = FString::Printf(TEXT("%d.%d%%"), Quotient, Remainder);
			}
		}

		FString Key = FString::FromInt(i);
		Args.Add(Key, FText::FromString(ValueStr));
	}

	return FText::Format(FText::FromString(Desc.Msg), Args);
}

FText BuildBuffEffectName(FBuffEffectType BuffEffectType, bool bSimpleNotice)
{
	const FCMSBuffEffectRow& BuffEffectRow = GetCMS()->GetBuffEffectRowOrDummy(BuffEffectType);
	if (BuffEffectRow.IsInvalid())
	{
		Q6JsonLog(Warning, "tooltip invalid buffeffect", Q6KV("BuffEffectType", BuffEffectType));
		return FText::GetEmpty();
	}

 	if (bSimpleNotice)
 	{
 		return BuffEffectRow.DescName;
 	}

	FString DescStr = BuffEffectRow.Desc.ToString();
	DescStr = DescStr.LeftChop(1);
	DescStr = DescStr.RightChop(1);
	FToolTipDesc Desc;
	if (!FJsonObjectConverter::JsonObjectStringToUStruct(DescStr, &Desc, 0, 0))
	{
		Q6JsonLog(Warning, "tooltip parse failed", Q6KV("BuffEffectType", BuffEffectType));
		return BuffEffectRow.Desc;
	}

	return FText::FromString(Desc.Msg);
}

FCharacterBond MakeDefaultCharacterBond(const UCMS* CMS, FCharacterType CharacterType)
{
	FCharacterBond CharacterBond;
	CharacterBond.CharacterType = CharacterType;
	CharacterBond.Level = FBondXpType(1);
	CharacterBond.SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	CharacterBond.Xp = 0;

	if (CharacterType != CharacterTypeInvalid)
	{
		const FCMSSystemJokerRow& R = CMS->GetSystemJokerRowOrDummy(FSystemJokerType(CharacterType.x));
		if (!R.IsInvalid())
		{
			CharacterBond.SupportSkillLevel = R.SupportSkillLevel;
		}
	}
	else
	{
		Q6JsonLogGunny(Warning, "MakeDefaultCharacterBond - CharacterType does not valid.", Q6KV("CharacterType", CharacterType));
	}

	return CharacterBond;
}

EDetailItemType GetItemFrameType(const FSummonInfo& SummonInfo)
{
	if (SummonInfo.Category == ELootCategory::CharacterCard)
	{
		return GetItemFrameType(FCharacterType(SummonInfo.Type));
	}

	if (SummonInfo.Category == ELootCategory::SculptureCard)
	{
		return GetItemFrameType(FSculptureType(SummonInfo.Type));
	}

	if (SummonInfo.Category == ELootCategory::RelicCard)
	{
		return GetItemFrameType(FRelicType(SummonInfo.Type));
	}

	return EDetailItemType::Max;
}

EDetailItemType GetItemFrameType(const FItemIconInfo& InItemInfo)
{
	if (InItemInfo.AttributeType == EAttributeCategory::Character
		|| InItemInfo.AttributeType == EAttributeCategory::FriendJoker
		|| InItemInfo.AttributeType == EAttributeCategory::SystemJoker
		|| InItemInfo.AttributeType == EAttributeCategory::RecommendJoker)
	{
		return GetItemFrameType(FCharacterType(InItemInfo.Type));
	}

	if (InItemInfo.AttributeType == EAttributeCategory::Relic)
	{
		return GetItemFrameType(FRelicType(InItemInfo.Type));
	}

	if (InItemInfo.AttributeType == EAttributeCategory::Sculpture)
	{
		return GetItemFrameType(FSculptureType(InItemInfo.Type));
	}

	return EDetailItemType::Max;
}

EDetailItemType GetItemFrameType(const FCharacterType CharacterType)
{
	if (CharacterType == CharacterTypeInvalid)
	{
		Q6JsonLogRoze(Error, "WidgetUtil::GetItemFrameType - Invalid character type");
		return EDetailItemType::Max;
	}

	const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(CharacterType);
	if (CharacterRow.XpExclusive)
	{
		return EDetailItemType::ExpCard;
	}

	return CharacterRow.Grade >= EItemGrade::SR ? EDetailItemType::SpecialCharacter : EDetailItemType::NormalCharacter;
}

EDetailItemType GetItemFrameType(const FSculptureType SculptureType)
{
	if (SculptureType == SculptureTypeInvalid)
	{
		Q6JsonLogRoze(Error, "WidgetUtil::GetItemFrameType - Invalid sculpture type");
		return EDetailItemType::Max;
	}

	const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(SculptureType);
	if (SculptureRow.XpExclusive)
	{
		return EDetailItemType::ExpCard;
	}

	return EDetailItemType::Sculpture;
}

EDetailItemType GetItemFrameType(const FRelicType RelicType)
{
	if (RelicType == SculptureTypeInvalid)
	{
		Q6JsonLogRoze(Error, "WidgetUtil::GetItemFrameType - Invalid relic type");
		return EDetailItemType::Max;
	}

	const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(RelicType);
	if (RelicRow.XpExclusive)
	{
		return EDetailItemType::ExpCard;
	}

	return EDetailItemType::Relic;
}

int32 GetTurnSkillLevel(const FCharacterInfo& Info, int32 SkillIndex)
{
	TArray<int32> TurnSkillLevels;
	TurnSkillLevels.Add(Info.TurnSkill1Level);
	TurnSkillLevels.Add(Info.TurnSkill2Level);
	TurnSkillLevels.Add(Info.TurnSkill3Level);
	check(TurnSkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	if (TurnSkillLevels.IsValidIndex(SkillIndex))
	{
		return TurnSkillLevels[SkillIndex];
	}

	Q6JsonLogRoze(Error, "WidgetUtil::GetTurnSkillLevel - Not found turn skill level", Q6KV("CharacterType", Info.Type.x), Q6KV("SkillIndex", SkillIndex));
	return 0;
}

int32 GetUpgradedTurnSkillIndex(const FCharacterInfo& NewInfo, const FCharacterInfo& OldInfo)
{
	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		int32 OldLevel = GetTurnSkillLevel(OldInfo, i);
		int32 NewLevel = GetTurnSkillLevel(NewInfo, i);
		if (NewLevel > OldLevel)
		{
			return i;
		}
	}

	return INDEX_NONE;
}

void SetNewMark(UImage* NewMarkImage, ENewMarkType NewMarkType)
{
	check(NewMarkImage);

	const FSlateBrush& NewMarkBrush = GetUIResource().GetNewMarkBrush(NewMarkType);
	NewMarkImage->SetBrush(NewMarkBrush);
}
