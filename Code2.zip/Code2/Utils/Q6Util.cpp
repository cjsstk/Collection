// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6Util.h"

#include "Misc/ConfigCacheIni.h"
#include "CoreGlobals.h"
#include "Internationalization/Culture.h"
#include "Internationalization/Internationalization.h"
#include "Math/UnitConversion.h"
#include "SystemConst_gen.h"
#include "Q6Log.h"
#include "Q6UIDefine.h"
#include "WidgetUtil.h"
#include "VersionNumber.h"
#include "Utils/Random.h"

#if PLATFORM_ANDROID
#include "AndroidRuntimeSettings.h"
#include "Android/AndroidPlatformMisc.h"
#elif PLATFORM_IOS
#include "IOSRuntimeSettings.h"
#include "IOS/IOSPlatformMisc.h"
#endif

FString Q6Util::GetDeviceModel()
{
	static FString DeviceModel = "";

	// if we've already figured it out, return it
	if (DeviceModel.Len() > 0)
	{
		return DeviceModel;
	}

#if PLATFORM_ANDROID
	DeviceModel = FAndroidMisc::GetDeviceModel();
#elif PLATFORM_IOS
	// get the device hardware type string length
	size_t DeviceIDLen;
	sysctlbyname("hw.machine", NULL, &DeviceIDLen, NULL, 0);

	// get the device hardware type
	char* DeviceID = (char*)malloc(DeviceIDLen);
	sysctlbyname("hw.machine", DeviceID, &DeviceIDLen, NULL, 0);

	// convert to NSStringt
	NSString *DeviceIDString = [NSString stringWithCString : DeviceID encoding : NSUTF8StringEncoding];
	DeviceModel = FString(DeviceIDString);
	free(DeviceID);
#elif PLATFORM_MAC
	DeviceModel = TEXT("Mac");
#elif PLATFORM_WINDOWS
	DeviceModel = TEXT("PC");
#else
	DeviceModel = "<none>";
#endif

	return DeviceModel;
}

FString Q6Util::GetCurrentCultureCountryCode()
{
	FString Language = FInternationalization::Get().GetCurrentCulture()->GetTwoLetterISOLanguageName();

	if (Language == FString(TEXT("zh")))
	{
		Language = FInternationalization::Get().GetCurrentCulture()->GetName();
		if (Language.Contains(TEXT("hans")))
		{
			Language = FString(TEXT("zh-hans"));
		}
		else if (Language.Contains(TEXT("hant")) || Language.Contains(TEXT("tw")))
		{
			Language = FString(TEXT("zh-hant"));
		}
	}

	return Language;
}

FDateTime Q6Util::UtcTimestampToLocalDateTime(int64 UtcTimestamp)
{
	FDateTime Utc = FDateTime::UtcNow();
	FDateTime Local = FDateTime::Now();
	FTimespan TimeDiff = Local - Utc;

	return FDateTime::FromUnixTimestamp(UtcTimestamp + (int64)TimeDiff.GetTotalSeconds());
}

FText Q6Util::GetHappendTime(int64 HappenedTime, bool bShowDateAfterMonth)
{
	static const int32 MINUTE = 60;
	static const int32 HOUR = 60 * MINUTE;
	static const int32 DAY = 24 * HOUR;
	static const int32 MONTH = 30 * DAY;

	const FDateTime Happened = FDateTime::FromUnixTimestamp(HappenedTime);
	const FTimespan TimeDiff = FDateTime::UtcNow() - Happened;
	const int32 TotalSeconds = (int32)TimeDiff.GetTotalSeconds();

	if (TotalSeconds < MINUTE)
	{
		return Q6Util::GetLocalizedText("Common", "JustBefore");
	}
	if (TotalSeconds < HOUR)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "MinutesBefore"), TimeDiff.GetMinutes());
	}
	if (TotalSeconds < DAY)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "HoursBefore"), TimeDiff.GetHours());
	}
	if (TotalSeconds < MONTH)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "DaysBefore"), TimeDiff.GetDays());
	}

	if (bShowDateAfterMonth)
	{
		return FText::FromString(UtcTimestampToLocalDateTime(HappenedTime).ToString(TEXT("%Y-%m-%d")));
	}
	else
	{
		return Q6Util::GetLocalizedText("Common", "MoreThanAMonthBefore");
	}

}

FText Q6Util::GetLocalDateText(int64 UtcTimestamp)
{
	FDateTime DateTime = FDateTime::FromUnixTimestamp(UtcTimestamp);
	return FText::AsDate(DateTime, EDateTimeStyle::Long);
}

// Period Text
// YY-MM-DD(DayOfWeek) ~ YY-MM-DD(DayOfWeek)
FText Q6Util::GetLocalDatePeriodText(const FDateTime& StartDate, const FDateTime& EndDate)
{
	FNumberFormattingOptions FormattingOption = FNumberFormattingOptions{};
	FormattingOption.SetUseGrouping(false);

	FText Period = FText::Format(Q6Util::GetLocalizedText("Lobby", "TrainingCenterPeriod")
		, FText::AsNumber(StartDate.GetYear(), &FormattingOption)
		, AttachZeroToFront(StartDate.GetMonth())
		, AttachZeroToFront(StartDate.GetDay())
		, ConvertDayOfWeekTypeToText(ConvertDayOfWeekType(StartDate.GetDayOfWeek()))
		, FText::AsNumber(EndDate.GetYear(), &FormattingOption)
		, AttachZeroToFront(EndDate.GetMonth())
		, AttachZeroToFront(EndDate.GetDay())
		, ConvertDayOfWeekTypeToText(ConvertDayOfWeekType(EndDate.GetDayOfWeek()))
	);

	return Period;
}

FText Q6Util::AttachZeroToFront(int32 InNumber)
{
	FText ReturnText;

	if (InNumber < 10)
	{
		FString AttchedString = FString::Printf(TEXT("%02d"), InNumber);
		ReturnText = FText::FromString(AttchedString);
	}
	else
	{
		ReturnText = FText::AsNumber(InNumber);
	}

	return ReturnText;
}

FText Q6Util::GetLocalDateTimeText(int64 UtcTimestamp)
{
	FDateTime DateTime = FDateTime::FromUnixTimestamp(UtcTimestamp);
	return FText::AsDateTime(DateTime, EDateTimeStyle::Long, EDateTimeStyle::Short);
}

FText Q6Util::ConvertDayOfWeekTypeToText(EDayOfWeekType DayOfWeekType)
{
	switch (DayOfWeekType)
	{
		case EDayOfWeekType::Sun:
			return GetLocalizedText("Lobby", "DayOfWeekSunday");
		case EDayOfWeekType::Mon:
			return GetLocalizedText("Lobby", "DayOfWeekMonday");
		case EDayOfWeekType::Tue:
			return GetLocalizedText("Lobby", "DayOfWeekTuesday");
		case EDayOfWeekType::Wed:
			return GetLocalizedText("Lobby", "DayOfWeekWednesday");
		case EDayOfWeekType::Thu:
			return GetLocalizedText("Lobby", "DayOfWeekThursday");
		case EDayOfWeekType::Fri:
			return GetLocalizedText("Lobby", "DayOfWeekFriday");
		case EDayOfWeekType::Sat:
			return GetLocalizedText("Lobby", "DayOfWeekSaturday");
		default:
			Q6JsonLogGunny(Warning, "Q6Util::ConvertDayOfWeekTypeToText - Wrong DayOfWeekType");
			return GetLocalizedText("Lobby", "DayOfWeekSunDay");
	}
}

FText Q6Util::GetShortTimeText(int64 TotalSeconds)
{
	if (TotalSeconds < 60)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "Seconds"), FText::AsNumber(TotalSeconds));
	}

	FTimespan Timespan = FTimespan::FromSeconds(TotalSeconds);
	if ((int32)Timespan.GetTotalHours() <= 0)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "Minutes"), FText::AsNumber(Timespan.GetMinutes()));
	}

	if ((int32)Timespan.GetTotalDays() <= 0)
	{
		int32 Hours = Timespan.GetHours();
		int32 Minutes = Timespan.GetMinutes();
		return FText::Format(Q6Util::GetLocalizedText("Common", "HoursMinutes"), FText::AsNumber(Hours), FText::AsNumber(Minutes));
	}

	return FText::Format(Q6Util::GetLocalizedText("Common", "Days"), FText::AsNumber(Timespan.GetDays()));
}

FText Q6Util::GetRemainTimeText(int64 TotalSeconds)
{
	if (TotalSeconds <= 60)
	{
		return Q6Util::GetLocalizedText("Common", "LessThanMinute");
	}

	FTimespan Timespan = FTimespan::FromSeconds(TotalSeconds);
	if ((int32)Timespan.GetTotalHours() <= 0)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "Minutes"), FText::AsNumber(Timespan.GetMinutes()));
	}

	if ((int32)Timespan.GetTotalDays() <= 0)
	{
		int32 Hours = Timespan.GetHours();
		int32 Minutes = Timespan.GetMinutes();
		return FText::Format(Q6Util::GetLocalizedText("Common", "HoursMinutes"), FText::AsNumber(Hours), FText::AsNumber(Minutes));
	}

	return FText::Format(Q6Util::GetLocalizedText("Common", "DaysHours"), FText::AsNumber(Timespan.GetDays()), FText::AsNumber(Timespan.GetHours()));
}

FText Q6Util::GetProductionTimeText(int32 InDays, int32 InHours, int32 InMinutes, int32 InSeconds)
{
	const FTimespan Timespan(InDays, InHours, InMinutes, InSeconds);

	const int32 Days = Timespan.GetDays();
	const int32 Hours = Timespan.GetHours();
	const int32 Minutes = Timespan.GetMinutes();
	const int32 Seconds = Timespan.GetSeconds();

	if (Days > 0)
	{
		if (Hours > 0)
		{
			return FText::Format(Q6Util::GetLocalizedText("Common", "DaysHours")
				, FText::AsNumber(Days)
				, FText::AsNumber(Hours));
		}
		else
		{
			return FText::Format(Q6Util::GetLocalizedText("Common", "Days")
				, FText::AsNumber(Days));
		}
	}
	else if (Hours > 0)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "Hours")
			, FText::AsNumber(Hours));
	}
	else if (Minutes > 0)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "Minutes")
			, FText::AsNumber(Minutes));
	}
	else
	{
		return Q6Util::GetLocalizedText("Common", "LessThanMinute");
	}
}

bool Q6Util::IsDailyResetTimePassed(int64 UtcTimestamp)
{
	FDateTime ResetTime = GetResetLocalTime(UtcTimestamp);

	return (FDateTime::Now() >= ResetTime);
}

FTimespan Q6Util::GetRemainTime(int64 EndUtcTimestamp)
{
	FDateTime ResetTime = GetResetLocalTime(EndUtcTimestamp);

	if (FDateTime::Now() >= ResetTime)
	{
		return FTimespan(0);
	}

	FTimespan DailyResetOffset = FTimespan::FromHours(SystemConst::Q6_DAILY_RESET_OFFSET_IN_HOURS);
	FTimespan RemainTime = ResetTime - (FDateTime::Now() + DailyResetOffset);
	return RemainTime;
}

FTimespan Q6Util::GetRemainDetailTime(int64 EndUtcTimestamp)
{
	FDateTime ResetTime = UtcTimestampToLocalDateTime(EndUtcTimestamp);

	if (FDateTime::Now() >= ResetTime)
	{
		return 0;
	}

	FTimespan RemainTime = ResetTime - FDateTime::Now();
	return RemainTime;
}

int32 Q6Util::GetRemainDays(int64 EndUtcTimestamp)
{
	FTimespan RemainTime = GetRemainTime(EndUtcTimestamp);
	if (RemainTime.IsZero())
	{
		return 0;
	}

	return GetRemainTime(EndUtcTimestamp).GetDays() + 1;
}

FDateTime Q6Util::GetResetLocalTime(int64 UtcTimestamp)
{
	FTimespan DailyResetOffset = FTimespan::FromHours(SystemConst::Q6_DAILY_RESET_OFFSET_IN_HOURS);
	FTimespan TimeDiff = FDateTime::Now() - FDateTime::UtcNow();

	FDateTime DateTime = FDateTime::FromUnixTimestamp(UtcTimestamp) + TimeDiff;	// To local time
	FDateTime ResetTime = DateTime.GetDate() + DailyResetOffset;

	return ResetTime;
}

bool Q6Util::IsValidCultureTextInternal(const TCHAR Char)
{
	TCHAR StartUnicode, EndUnicode;
	const FString CultureCode = GetCurrentCultureCountryCode();
	if (!GetCultureUnicodeRange(CultureCode, &StartUnicode, &EndUnicode))
	{
		return false;
	}

	if (Char < StartUnicode)
	{
		return false;
	}

	if (Char > EndUnicode)
	{
		return false;
	}

	return true;
}

bool Q6Util::GetCultureUnicodeRange(const FString& CultureCode, TCHAR* StartUnicode, TCHAR* EndUnicode)
{
	if (CultureCode == TEXT("ko"))
	{
		*StartUnicode = TEXT('\uAC00');
		*EndUnicode = TEXT('\uD7AF');
		return true;
	}

	return false;
}

FDateTime Q6Util::GetNextResetLocalTime()
{
	FDateTime ResetTime = GetResetLocalTime(FDateTime::UtcNow().ToUnixTimestamp());
	ResetTime += FTimespan::FromDays(1);

	return ResetTime;
}

FText Q6Util::GetLocalizedText(const FString& Namespace, const FString& Key)
{
	FText Text;
	FText::FindText(Namespace, Key, Text);

	return Text;
}

FText Q6Util::GetLocalizedTextOrKey(const FString& Namespace, const FString& Key)
{
	FText Text;
	if (FText::FindText(Namespace, Key, Text))
	{
		return Text;
	}

	return FText::FromString(Key);
}

FText Q6Util::GetVersionText(bool bDisplayVersion, bool bBinaryRevision, bool bPatchRevision)
{
	FString OutVersionText;
	FString DisplayVersion("X.X.X");

#if PLATFORM_ANDROID
	const UAndroidRuntimeSettings* AndroidSetting = GetDefault<UAndroidRuntimeSettings>();
	DisplayVersion = AndroidSetting->VersionDisplayName;
#elif PLATFORM_IOS
	const UIOSRuntimeSettings* IOSSetting = GetDefault<UIOSRuntimeSettings>();
	DisplayVersion = IOSSetting->VersionInfo;
#endif

	// Format for each cases
	if (bDisplayVersion)
	{
		OutVersionText = DisplayVersion;
	}

	if (bBinaryRevision)
	{
		if (!OutVersionText.IsEmpty())
		{
			OutVersionText += TEXT(" ");
		}

		FString VersionShortStr(BUILD_VERSION_SHORT_STRING);
		OutVersionText += FString::Printf(TEXT("Binary %s"), *VersionShortStr);
	}

	if (bPatchRevision)
	{
		if (!OutVersionText.IsEmpty())
		{
			OutVersionText += TEXT(" ");
		}

		OutVersionText += FString::Printf(TEXT("Patch not yet"));
	}

	return FText::FromString(OutVersionText);
}

static const FNumberFormattingOptions* GetNumberFormattingBySize(float InSize)
{
	static const FNumberFormattingOptions NoFractionSizeFormatOptions = FNumberFormattingOptions()
		.SetMinimumFractionalDigits(0)
		.SetMaximumFractionalDigits(0);

	static const FNumberFormattingOptions OneFractionSizeFormatOptions = FNumberFormattingOptions()
		.SetMinimumFractionalDigits(1)
		.SetMaximumFractionalDigits(1);

	if (InSize < 10.f)
	{
		return &OneFractionSizeFormatOptions;
	}

	return &NoFractionSizeFormatOptions;
}

FText Q6Util::GetFormattedBytesText(float InBytes)
{
	static float OneMegaByte = FUnitConversion::Convert(1.f, EUnit::Megabytes, EUnit::Bytes);
	static float OneGigaByte = FUnitConversion::Convert(1.f, EUnit::Gigabytes, EUnit::Bytes);

	if (InBytes < OneMegaByte)
	{
		InBytes = FUnitConversion::Convert(InBytes, EUnit::Bytes, EUnit::Kilobytes);
		return FText::Format(FText::FromString("{0} KB"), FText::AsNumber(InBytes, GetNumberFormattingBySize(InBytes)));
	}
	else if (InBytes < OneGigaByte)
	{
		InBytes = FUnitConversion::Convert(InBytes, EUnit::Bytes, EUnit::Megabytes);
		return FText::Format(FText::FromString("{0} MB"), FText::AsNumber(InBytes, GetNumberFormattingBySize(InBytes)));
	}

	InBytes = FUnitConversion::Convert(InBytes, EUnit::Bytes, EUnit::Gigabytes);
	return FText::Format(FText::FromString("{0} GB"), FText::AsNumber(InBytes, GetNumberFormattingBySize(InBytes)));
}

FText Q6Util::GetPointText(EPointType PointType)
{
	switch (PointType)
	{
		case EPointType::None:
			Q6JsonLogRoze(Warning, "Q6Util::GetPointText - EPointType is none.");
			return FText::GetEmpty();
		case EPointType::Gold:
			return Q6Util::GetLocalizedText("Common", "Gold");
		case EPointType::AnyGem:
			return Q6Util::GetLocalizedText("Common", "Gem");
		case EPointType::FreeGem:
			return Q6Util::GetLocalizedText("Common", "FreeGem");
		case EPointType::PaidGem:
			return Q6Util::GetLocalizedText("Common", "PaidGem");
		case EPointType::SummonTicket:
			return Q6Util::GetLocalizedText("Common", "SummonTicket");
		case EPointType::Sculpture:
			return Q6Util::GetLocalizedText("Common", "SculpturePoint");
		case EPointType::Relic:
			return Q6Util::GetLocalizedText("Common", "RelicPoint");
		case EPointType::Friendship:
			return Q6Util::GetLocalizedText("Common", "FriendShipPoint");
		case EPointType::SmallBattery:
			return Q6Util::GetLocalizedText("Common", "SmallBattery");
		case EPointType::MediumBattery:
			return Q6Util::GetLocalizedText("Common", "MediumBattery");
		case EPointType::LargeBattery:
			return Q6Util::GetLocalizedText("Common", "LargeBattery");
		case EPointType::Lumicube:
			return Q6Util::GetLocalizedText("Common", "Lumicube");
		case EPointType::CharacterDisk:
			return Q6Util::GetLocalizedText("Common", "CharacterDisk");
		case EPointType::SculptureDisk:
			return Q6Util::GetLocalizedText("Common", "SculptureDisk");
		case EPointType::RelicDisk:
			return Q6Util::GetLocalizedText("Common", "RelicDisk");
		case EPointType::Watt:
			return Q6Util::GetLocalizedText("Common", "Watt");
		default:
			Q6JsonLogRoze(Warning, "Q6Util::GetPointText - input value does not match", Q6KV("PointType", static_cast<int>(PointType)));
			return FText::GetEmpty();
	}

}

FText Q6Util::GetCurrencyText(ECurrencyType InCurrencyType)
{
	EPointType PointType = GetPointType(InCurrencyType);
	return GetPointText(PointType);
}

FText Q6Util::GetMaxCurrencyText(ECurrencyCheckType CheckType, ECurrencyType InCurrencyType)
{
	switch (CheckType)
	{
		case ECurrencyCheckType::Saga:
			return FText::Format(GetLocalizedText("Lobby", "SagaMaxCurrency"), GetCurrencyText(InCurrencyType));
		case ECurrencyCheckType::BuyGem:
			return FText::Format(GetLocalizedText("Lobby", "BuyMaxCurrency"), GetCurrencyText(InCurrencyType));
		case ECurrencyCheckType::SellCharacter:
			return FText::Format(GetLocalizedText("Lobby", "SellMaxCurrency"), GetCurrencyText(InCurrencyType));
		case ECurrencyCheckType::AllSummon:
		case ECurrencyCheckType::SculptureSummon:
		case ECurrencyCheckType::RelicSummon:
			return FText::Format(GetLocalizedText("Lobby", "SummonMaxCurrency"), GetCurrencyText(InCurrencyType));
	}

	return FText::Format(GetLocalizedText("Lobby", "MaxCurrency"), GetCurrencyText(InCurrencyType));
}

FText Q6Util::GetMaxCollectionText(ECurrencyCheckType CheckType)
{
	switch (CheckType)
	{
		case ECurrencyCheckType::Saga:
			return GetLocalizedText("Lobby", "SagaMaxCollection");
		case ECurrencyCheckType::AllSummon:
		case ECurrencyCheckType::SculptureSummon:
		case ECurrencyCheckType::RelicSummon:
			return GetLocalizedText("Lobby", "SummonMaxCollection");
		case ECurrencyCheckType::BuyGem:
			return GetLocalizedText("Lobby", "BuyMaxCollection");
	}

	return GetLocalizedText("Lobby", "MaxCollection");
}

const bool IsNumber(const TCHAR Char)
{
	return (Char >= TEXT('0') && Char <= TEXT('9'));
}

const bool IsAlphabet(const TCHAR Char)
{
	return (Char >= TEXT('A') && Char <= TEXT('Z')) || (Char >= TEXT('a') && Char <= TEXT('z'));
}

bool Q6Util::IsValidCultureText(const FText& InText)
{
	const FString& CurrentString = InText.ToString();

	for (int32 i = 0; i < CurrentString.Len(); ++i)
	{
		if (IsNumber(CurrentString[i]))
		{
			continue;
		}

		if (IsAlphabet(CurrentString[i]))
		{
			continue;
		}

		if (IsValidCultureTextInternal(CurrentString[i]))
		{
			continue;
		}

		return false;
	}

	return true;
}

FText Q6Util::GetUpgradeResultText(EUpgradeResultType InResultType)
{
	switch (InResultType)
	{
		case EUpgradeResultType::Fail:
			return GetLocalizedText("Lobby", "UpgradeFail");
		case EUpgradeResultType::Success:
			return GetLocalizedText("Lobby", "Success");
		case EUpgradeResultType::GreatSuccess:
			return GetLocalizedText("Lobby", "SuperSuccess");
		case EUpgradeResultType::BigGreatSuccess:
			return GetLocalizedText("Lobby", "UltraSuccess");
	}

	Q6JsonLogRoze(Warning, "Q6Util::GetUpgradeResultText - Not found result type text", Q6KV("ResultType", (int32)InResultType));
	return FText::GetEmpty();
}

FText Q6Util::GetNotOpenedYetText(int32 Episode, int32 Stage, int32 SubStage)
{
	if (SubStage == 0)
	{
		return FText::Format(GetLocalizedText("Lobby", "NotOpenedYet1")
			, FText::AsNumber(Episode)
			, FText::AsNumber(Stage));
	}
	else
	{
		return FText::Format(GetLocalizedText("Lobby", "NotOpenedYet2")
			, FText::AsNumber(Episode)
			, FText::AsNumber(Stage)
			, FText::AsNumber(SubStage));
	}
}

FText Q6Util::GetContentText(EContentType InContentType)
{
	switch (InContentType)
	{
		case EContentType::Saga:
			return Q6Util::GetLocalizedText("Lobby", "TitleSaga");
		case EContentType::Special:
			return Q6Util::GetLocalizedText("Lobby", "TitleSpecialStage");
		case EContentType::DailyDungeon:
			return Q6Util::GetLocalizedText("Lobby", "TitleDailyDungeon");
		case EContentType::TrainingCenter:
			return Q6Util::GetLocalizedText("Lobby", "TitleTrainingCenter");
		case EContentType::Raid:
			return Q6Util::GetLocalizedText("Lobby", "TitleRaid");
		case EContentType::RaidFinal:
			return Q6Util::GetLocalizedText("Lobby", "TitleRaidFinal");
		case EContentType::MultiSideBattle:
			return Q6Util::GetLocalizedText("Lobby", "TitleMultiside");
		case EContentType::Event:
		case EContentType::EventMap:
			return Q6Util::GetLocalizedText("Lobby", "TitleEvent");
		case EContentType::None:
		default:	// fall through
			return FText::GetEmpty();
	}
}

FText Q6Util::GetCharacterProfileText(EProfileCategory Category)
{
	FString ProfileCategoryTextKey = FString::Printf(TEXT("CharacterProfile%s"), *ENUM_TO_STRING(EProfileCategory, Category));
	return Q6Util::GetLocalizedText("Lobby", ProfileCategoryTextKey);
}

void Q6Util::ShuffleArray(TArray<int32>& InOutArray)
{
	int32 LastIndex = InOutArray.Num() - 1;
	for (int32 i = 0; i <= LastIndex; i++)
	{
		int32 Index = FMath::RandRange(i, LastIndex);
		if (i != Index)
		{
			InOutArray.Swap(i, Index);
		}
	}
}

void Q6Util::ShuffleArray(FMT19937Uint32& InRng, TArray<int32>& InOutArray)
{
	// implemented in CCAction
	for (int32 i = InOutArray.Num() - 1; i >= 1; --i)
	{
		int Candidate = InRng.Gen() % (i + 1);
		InOutArray.Swap(Candidate, i);
	}
}
