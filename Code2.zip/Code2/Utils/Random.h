// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"

/**
 * Mersenne Twister uint32 version
 * source: https://github.com/sdroege/snippets/blob/master/snippets/rand.c
 */
class FMT19937Uint32
{
public:
	explicit FMT19937Uint32(int32 NewSeed);

	/* initializes mt[N] with a seed */
	void Seed(int32 NewSeed);

	/* generates a random number on [0,0xffffffff]-interval */
	uint32 Gen();
	uint64 Gen64();

	int32 GenRandom(int MaxExclusive);

private:

	enum { N = 624 };
	enum { M = 397 };
	enum { MATRIX_A = 0x9908b0dfUL };	/* constant vector a */
	enum { UPPER_MASK = 0x80000000UL };	/* most significant w-r bits */
	enum { LOWER_MASK = 0x7fffffffUL };	/* least significant r bits */

	uint32 g_mt[N]; /* the array for the state vector  */
	uint32 g_mti;	/* mti==N+1 means mt[N] is not initialized */
};
