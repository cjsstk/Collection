#pragma once

#include "Engine.h"
#include "CMSType_gen.h"
#include "CMSTable.h"
#include "ErrCode_gen.h"

FString OnErrCharacterUpdate(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra);
FString OnErrNoParam(UCMS* CMS, FErrTextType ErrType);
FString OnErrParam1(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra);
FString OnErrParam2(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra);
FString OnErrAddXp(UCMS* CMS, FErrTextType ErrType, const FString& UserName, const TArray<int32>& Extra);
FString OnNotEnoughMaterial(UCMS* CMS, FErrTextType ErrType, const TArray<int32>& Extra);
