﻿// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "Q6Timer.h"


FQ6TimerManager::FQ6TimerManager(UQ6GameInstance* InGameInstance)
	: LastAssignedQ6TimerHandle(0)
{
	GameInstance = InGameInstance;
}

FQ6TimerManager::~FQ6TimerManager()
{
	Q6TimerList.Empty();
}

bool FQ6TimerManager::Tick(float DeltaTime)
{
	int64 Now = FDateTime::Now().GetTicks();
	while (Q6TimerList.Num() > 0)
	{
		FQ6TimerData& Top = Q6TimerList.HeapTop();
		if (Now >= Top.ExpireDateTimeTicks)
		{
			if (!Top.TimerHandle.IsValid())
			{
				Q6TimerList.HeapPopDiscard(false);
				continue;
			}

			FQ6TimerData CurTimer;

			Q6TimerList.HeapPop(CurTimer, false);

			int32 const CallCount = CurTimer.bLoop ?
				FMath::TruncToInt((Now - CurTimer.ExpireDateTimeTicks) / CurTimer.RateTicks) + 1
				: 1;

			for (int i = 0; i < CallCount; i++)
			{
				CurTimer.TimerDelegate.Execute();
			}

			if (CurTimer.bLoop)
			{
				CurTimer.ExpireDateTimeTicks += CallCount * CurTimer.RateTicks;

				Q6TimerList.HeapPush(MoveTemp(CurTimer));
			}
			else
			{
				CurTimer.Clear();
			}
		}
		else
		{
			break;
		}
	}

	if (Q6ClearTimerReservedList.Num() > 0)
	{
		for (const FQ6TimerHandle& Handle : Q6ClearTimerReservedList)
		{
			int32 Index = Q6TimerList.FindLastByPredicate([&Handle](const FQ6TimerData& Timer)
			{
				return Handle == Timer.TimerHandle;
			});
			if (Index != INDEX_NONE)
			{
				Q6TimerList.HeapRemoveAt(Index, false);
			}
		}

		Q6ClearTimerReservedList.Empty();
	}

	return true;
}

bool FQ6TimerManager::IsTimerActive(FQ6TimerHandle InHandle) const
{
	if (InHandle.IsValid())
	{
		for (const FQ6TimerData& Timer : Q6TimerList)
		{
			if (Timer.TimerHandle == InHandle)
			{
				return true;
			}
		}
	}

	return false;
}

void FQ6TimerManager::ClearTimer(const FQ6TimerHandle& InHandle, bool bReserve)
{
	if (!InHandle.IsValid())
	{
		return;
	}

	bool bIsFound = false;

	int i = 0;
	for (; i < Q6TimerList.Num(); i++)
	{
		if (Q6TimerList[i].TimerHandle == InHandle)
		{
			bIsFound = true;
			Q6TimerList[i].Clear();
			break;
		}
	}

	if (bIsFound)
	{
		Q6TimerList.HeapRemoveAt(i, false);
	}

	if (bReserve)
	{
		Q6ClearTimerReservedList.Add(InHandle);
	}
}

void FQ6TimerManager::InternalSetTimer(FQ6TimerHandle& InOutHandle, FTimerUnifiedDelegate && InDelegate, float InRate, bool InbLoop, float InFirstDelay /*= -1.f*/)
{
	check(IsInGameThread());

	if (InOutHandle.IsValid())
	{
		ClearTimer(InOutHandle);
	}

	if (InRate > 0.f)
	{
		ValidateTimerHandle(InOutHandle);

		// set up the new timer
		FQ6TimerData NewTimerData;
		NewTimerData.TimerHandle = InOutHandle;
		NewTimerData.TimerDelegate = MoveTemp(InDelegate);

		if (NewTimerData.TimerHandle.IsValid())
		{
			NewTimerData.bLoop = InbLoop;

			float FirstDelay = (InFirstDelay >= 0.f) ? InFirstDelay : InRate;

			NewTimerData.ExpireDateTimeTicks = FDateTime::Now().GetTicks();
			NewTimerData.ExpireDateTimeTicks += (int64)(10000000 * FirstDelay); // -V2003

			NewTimerData.RateTicks = 10000000 * InRate;

			Q6TimerList.HeapPush(MoveTemp(NewTimerData));
		}
	}
}

void FQ6TimerManager::ValidateTimerHandle(FQ6TimerHandle& InOutHandle)
{
	if (!InOutHandle.IsValid())
	{
		++LastAssignedQ6TimerHandle;
		InOutHandle.Handle = LastAssignedQ6TimerHandle;
	}

	checkf(InOutHandle.IsValid(), TEXT("Timer handle has wrapped around to 0!"));
}