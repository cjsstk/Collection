// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "Random.h"

FMT19937Uint32::FMT19937Uint32(int32 NewSeed)
	: g_mti(N + 1)
{
	Seed(NewSeed);
}

void FMT19937Uint32::Seed(int32 NewSeed)
{
	unsigned int *mt = g_mt;
	unsigned int mti;

	mt[0] = NewSeed;// &0xFFFFFFFF;
	for (mti = 1; mti < N; mti++) {
		mt[mti] = (1812433253UL * (mt[mti - 1] ^ (mt[mti - 1] >> 30)) + mti);
		/* See Knuth TAOCP Vol2. 3rd Ed. P.106 for multiplier. */
		/* In the previous versions, MSBs of the seed affect   */
		/* only MSBs of the array mt[].                        */
		/* 2002/01/09 modified by Makoto Matsumoto             */
		//mt[mti] &= 0xFFFFFFFF;
		/* for >32 bit machines */
	}
	g_mti = mti;
}

uint32 FMT19937Uint32::Gen()
{
	static const unsigned int mag01[2] = { 0x0UL, MATRIX_A };
	unsigned int y;
	unsigned int *mt = g_mt;
	unsigned int mti = g_mti;

	/* mag01[x] = x * MATRIX_A  for x=0,1 */

	if (mti >= N) {               /* generate N words at one time */
		int kk;

		for (kk = 0; kk < N - M; kk++) {
			y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
			mt[kk] = mt[kk + M] ^ (y >> 1) ^ mag01[y & 0x1UL];
		}
		for (; kk < N - 1; kk++) {
			y = (mt[kk] & UPPER_MASK) | (mt[kk + 1] & LOWER_MASK);
			mt[kk] = mt[kk + (M - N)] ^ (y >> 1) ^ mag01[y & 0x1UL];
		}
		y = (mt[N - 1] & UPPER_MASK) | (mt[0] & LOWER_MASK);
		mt[N - 1] = mt[M - 1] ^ (y >> 1) ^ mag01[y & 0x1UL];

		mti = 0;
	}

	y = mt[mti++];

	/* Tempering */
	y ^= (y >> 11);
	y ^= (y << 7) & 0x9d2c5680UL;
	y ^= (y << 15) & 0xefc60000UL;
	y ^= (y >> 18);

	g_mti = mti;

	return y;
}

uint64 FMT19937Uint32::Gen64()
{
	uint32 v1 = Gen();
	uint32 v2 = Gen(); //-V656
	return ((uint64)v1 << 32) | v2;
}

int32 FMT19937Uint32::GenRandom(int MaxExclusive)
{
	ensureMsgf(MaxExclusive >= 0, TEXT("Invalid param: %d"), MaxExclusive);

	if (MaxExclusive <= 0)
	{
		return 0;
	}

	int32 Random = this->Gen() % MaxExclusive;
	return Random;
}