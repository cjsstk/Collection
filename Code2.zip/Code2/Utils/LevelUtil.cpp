#include "LevelUtil.h"
#include "Camera/CameraLayerActor.h"
#include "Camera/Q6CameraLayerComponent.h"
#include "CombatLocator.h"
#include "CombatCameraComponent.h"
#include "Components/Q6DirectionalLightComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Engine/Q6DirectionalLight.h"
#include "Q6AnimInstance.h"
#include "Q6Capture2D.h"
#include "Q6Define.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "SkeletalMeshMerge.h"
#include "Unit.h"
#include "UnitLocator.h"
#include "ZoneAttributeActor.h"
#include "TodBranchActor.h"
#include "HAL/IConsoleManager.h"
#include "Animation/SkeletalMeshActor.h"
#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"

static int LevelUtilDebugMode = 0;
static FAutoConsoleVariableRef CVarLevelUtilDebugMode(
	TEXT("q6.LevelUtilDebugMode"),
	LevelUtilDebugMode,
	TEXT(""),
	ECVF_Cheat);

void ULevelUtil::LoadLoginLevel(const UWorld* World)
{
	UGameplayStatics::OpenLevel(World, TEXT("/Game/Maps/Login"), true);
}

void ULevelUtil::LoadLobbyLevel(const UWorld* World)
{
	UGameplayStatics::OpenLevel(World, TEXT("/Game/Maps/Lobby/Lobby_Composite"), true);
}

void ULevelUtil::LoadSummonLevel(const UWorld* World)
{
	UGameplayStatics::OpenLevel(World, TEXT("/Game/Maps/Summon"), true);
}

void ULevelUtil::LoadSagaLevel(const UWorld* World, FSagaType SagaType)
{
	if (SagaType == SagaTypeInvalid)
	{
		Q6JsonLogKalms(Verbose, "AntiCrash");
		return;
	}

	UCMS* CMS = GetCMS();
	check(CMS);

	const FString& SagaMapPath = CMS->GetMapPath(SagaType);
	UGameplayStatics::OpenLevel(World, *SagaMapPath, true);
}

void ULevelUtil::LoadSagaLightPreset(const UWorld* World, const FString& LightPreset)
{
	if (!World || LightPreset.IsEmpty())
	{
		return;
	}

	const FTodAssetRow* Row = GetGameResource().GetTodAssetRow(LightPreset);
	if (!Row)
	{
		Q6JsonLogMedrian5(Warning, "LoadSagaLightPreset - Failed to find row", Q6KV("RowName", LightPreset));
		return;
	}

	for (TActorIterator<AQ6DirectionalLight> It(World->GetWorld(), AQ6DirectionalLight::StaticClass()); It; ++It)
	{
		AQ6DirectionalLight* DirectionalLightActor = *It;

		if (DirectionalLightActor->IsHidden())
		{
			continue;
		}

		if (UQ6DirectionalLightComponent* Light = Cast<UQ6DirectionalLightComponent>(DirectionalLightActor->GetLightComponent()))
		{
			Light->Intensity = Row->Intensity;
			Light->LightColor = Row->LightColor;
			Light->CharacterColor = Row->CharacterColor;
			Light->AmbientColor = Row->AmbientColor;
			Light->LightBGTint = Row->LightBGTint;
			Light->ForceUpdateLightsColors();
		}
	}

	for (TActorIterator<ATodBranchActor> It(World->GetWorld(), ATodBranchActor::StaticClass()); It; ++It)
	{
		if (ATodBranchActor* TodBranchActor = *It)
		{
			TodBranchActor->ActivateBranch(Row->TodBranchIndex);
		}
	}
}

namespace
{
	void InternalLevelEffectMaterialSet(UMeshComponent* Component, const FLevelEffectAssetRow* Row, bool bSet)
	{
		if (!Component || !Row)
		{
			return;
		}

		for (const auto& DissolveMaterial : Row->DissolveMaterials)
		{
			if (Component->ComponentHasTag(DissolveMaterial.ComponentTag))
			{
				Component->SetDissolveMaterial(bSet ? DissolveMaterial.Material.LoadSynchronous() : nullptr);
			}
		}

		for (const auto& SubMaterialMaterial : Row->SubMaterials)
		{
			if (Component->ComponentHasTag(SubMaterialMaterial.ComponentTag))
			{
				Component->SetSubMaterial(bSet ? SubMaterialMaterial.Material.LoadSynchronous() : nullptr);
			}
		}
	}

	void InternalSetLevelEffect(const UWorld* World, int32 Episode, int32 Stage, int32 Wave, bool bSet)
	{
		const FLevelEffectAssetRow* Row = GetGameResource().GetLevelEffectAssetRow(Episode, Stage, Wave);

		if (!Row)
		{
			return;
		}

		for (TActorIterator<AActor> It(World->GetWorld()); It; ++It)
		{
			AActor* Actor = *It;

			if (AStaticMeshActor* StaticMeshActor = Cast<AStaticMeshActor>(Actor))
			{
				InternalLevelEffectMaterialSet(StaticMeshActor->GetStaticMeshComponent(), Row, bSet);
			}
			else if (ASkeletalMeshActor* SkeletalMeshActor = Cast<ASkeletalMeshActor>(Actor))
			{
				InternalLevelEffectMaterialSet(SkeletalMeshActor->GetSkeletalMeshComponent(), Row, bSet);
			}
			else
			{
				TInlineComponentArray<UInstancedStaticMeshComponent*> Components;
				Actor->GetComponents(Components);

				for (UInstancedStaticMeshComponent* InstancedStaticMeshComponent : Components)
				{
					InternalLevelEffectMaterialSet(InstancedStaticMeshComponent, Row, bSet);
				}
			}
		}
	}
}

void USimpleCallback::OnExecute()
{
	Delegate.ExecuteIfBound();
}

void ULevelUtil::LoadSagaLevelEffect(const UWorld* World, int32 Episode, int32 Stage, int32 Wave)
{
	const FLevelEffectAssetRow* Row = GetGameResource().GetLevelEffectAssetRow(Episode, Stage, Wave);

	if (!Row || Row->LevelEffectSequence.IsNull())
	{
		return;
	}

	InternalSetLevelEffect(World, Episode, Stage, Wave, true);

	ALevelSequenceActor* LevelSequenceActor = World->GetWorld()->SpawnActor<ALevelSequenceActor>();
	ULevelSequence* Sequence = Row->LevelEffectSequence.LoadSynchronous();
	LevelSequenceActor->LevelSequence = Sequence;
	LevelSequenceActor->PlaybackSettings.bRestoreState = true;
	LevelSequenceActor->SequencePlayer->Initialize(Sequence, LevelSequenceActor->GetLevel(), LevelSequenceActor->PlaybackSettings, LevelSequenceActor->CameraSettings);

	USimpleCallback* Callback = NewObject<USimpleCallback>(LevelSequenceActor);
	Callback->AddToRoot();
	Callback->SetCallback( FSimpleDelegate::CreateLambda([=]()
	{
		InternalSetLevelEffect(LevelSequenceActor->GetWorld(), Episode, Stage, Wave, false);
		LevelSequenceActor->SetLifeSpan(2.0f);
		Callback->RemoveFromRoot();
	}));
	LevelSequenceActor->SequencePlayer->OnFinished.AddUniqueDynamic(Callback, &USimpleCallback::OnExecute);
	LevelSequenceActor->SequencePlayer->Play();
}

ACombatLocator* ULevelUtil::FindCombatLocator(const UWorld* World, int32 Group, int32 Wave, ECombatMultiSide CombatMultiSide)
{
	ACombatLocator* DefaultLocator = nullptr;

	for (TActorIterator<ACombatLocator> It(World->GetWorld(), ACombatLocator::StaticClass()); It; ++It)
	{
		ACombatLocator* CombatLocator = *It;

		if (CombatLocator->IsCorrectLocator(Group, Wave, CombatMultiSide))
		{
			return CombatLocator;
		}
		else if (CombatLocator->IsDefaultLocator())
		{
			DefaultLocator = CombatLocator;
		}
	}

	return DefaultLocator;
}

ACameraLayerActor* ULevelUtil::FindCameraLayerActor(const UWorld* World, ECameraLayerIndex layer)
{
	for (TActorIterator<ACameraLayerActor> It(World->GetWorld(), ACameraLayerActor::StaticClass()); It; ++It)
	{
		ACameraLayerActor* LayerActor = *It;
		if (UQ6CameraLayerComponent* LayerComponent = LayerActor->GetCameraLayerComponent())
		{
			if (LayerComponent->GetCameraLayerIndex() == layer)
			{
				return LayerActor;
			}
		}
	}

	return nullptr;
}

void ULevelUtil::EmptyLocators(UWorld* World)
{
	for (TActorIterator<ACharacterLocator> It(World, ACharacterLocator::StaticClass()); It; ++It)
	{
		(*It)->Destroy();
	}

	for (TActorIterator<AMonsterLocator> It(World, AMonsterLocator::StaticClass()); It; ++It)
	{
		(*It)->Destroy();
	}
}

AResultLocator* ULevelUtil::FindResultLocator(const UWorld* World)
{
	for (TActorIterator<AResultLocator> It(World->GetWorld(), AResultLocator::StaticClass()); It; ++It)
	{
		AResultLocator* ResultLocator = *It;
		return ResultLocator;
	}

	return nullptr;
}

int32 ULevelUtil::ConvertSlot3to5(int32 Slot, int32 NumSlots, bool bForceDefault)
{
	if (NumSlots == 2 && !bForceDefault)
	{
		return Slot + 3;
	}

	return Slot;
}

#if WITH_EDITOR
void ULevelUtil::BuildCombatCameraCulling(const UWorld* World)
{
	for (TActorIterator<AActor> It(World->GetWorld()); It; ++It)
	{
		AActor* Actor = *It;

		TInlineComponentArray<UCombatCameraComponent*> Components;
		Actor->GetComponents(Components);

		for (UCombatCameraComponent* CombatCameraComponent : Components)
		{
			if (CombatCameraComponent->bUpdateCullWhileBuild)
			{
				CombatCameraComponent->UpdateCulling();
			}
		}
	}
}
#endif // WITH_EDITOR

namespace
{
	USkeletalMesh* LoadSkeletalMeshInternal(const FUnitModelAssetRow& Row, int32 ModelType)
	{
		if (LevelUtilDebugMode)
		{
			if (USkeletalMesh* FindSkeletal = GetGameResource().FindCachedSkeletalMesh(ModelType))
			{
				return FindSkeletal;
			}
		}

		USkeletalMesh* BodyMesh = Row.SkeletalMesh.LoadSynchronous();

		if (BodyMesh && Row.SkeletalMeshParts.Num())
		{
			USkeleton* Skeleton = BodyMesh->Skeleton;
			TArray<USkeletalMesh*> MeshesToMerge;
			MeshesToMerge.Reserve(Row.SkeletalMeshParts.Num() + 1);
			MeshesToMerge.Add(BodyMesh);

			for (int32 i = 0; i < Row.SkeletalMeshParts.Num(); ++i)
			{
				if (!Row.SkeletalMeshParts.IsValidIndex(i))
				{
					continue;
				}

				if (Row.SkeletalMeshParts[i].IsNull())
				{
					Q6JsonLogMedrian5(Error, "SkeletalMeshParts Slot Null", Q6KV("UnitType", ModelType), Q6KV("Parts", i));
					continue;
				}

				USkeletalMesh* SkeletalMesh = Row.SkeletalMeshParts[i].LoadSynchronous();
				if (MeshesToMerge.Contains(SkeletalMesh)) {
					FString RefString = Row.SkeletalMeshParts[i].ToString();
					Q6JsonLogMedrian5(Error, "SkeletalMeshParts Already Added", Q6KV("UnitType", ModelType), Q6KV("Parts", i), Q6KV("Mesh", *RefString));
					continue;
				}

				if (!SkeletalMesh)
				{
					FString RefString = Row.SkeletalMeshParts[i].ToString();
					Q6JsonLogMedrian5(Error, "SkeletalMeshParts Load Failed", Q6KV("UnitType", ModelType), Q6KV("Parts", i), Q6KV("Mesh", *RefString));
					continue;
				}

				if (SkeletalMesh->Skeleton != Skeleton)
				{
					FString RefString = Row.SkeletalMeshParts[i].ToString();
					Q6JsonLogMedrian5(Error, "SkeletalMeshParts Skeleton Missmatch", Q6KV("UnitType", ModelType), Q6KV("Parts", i), Q6KV("Mesh", *RefString));
					continue;
				}

				MeshesToMerge.Add(SkeletalMesh);
			}

			if (MeshesToMerge.Num())
			{
				TArray<FSkelMeshMergeSectionMapping> SectionMappings;
				TArray<FSkelMeshMergeUVTransforms> UvTransforms;

				USkeletalMesh* TempMesh = NewObject<USkeletalMesh>();
				TempMesh->Skeleton = Skeleton;

				FSkeletalMeshMerge Merger(TempMesh, MeshesToMerge, SectionMappings, 0, EMeshBufferAccess::ForceCPUAndGPU, UvTransforms.GetData(), BodyMesh->MorphTargets.Num());
				if (Merger.DoMerge())
				{
					BodyMesh = TempMesh;
				}
				else
				{
					Q6JsonLogMedrian5(Error, "SkeletalMeshParts Merge Failed!!", Q6KV("UnitType", ModelType));
				}
			}
			else
			{
				Q6JsonLogMedrian5(Error, "SkeletalMeshParts Parts Load Failed!!", Q6KV("UnitType", ModelType));
			}
			if (LevelUtilDebugMode)
			{
				GetGameResource().AddCachedSkeletalMesh(ModelType, BodyMesh);
			}
		}

		if (!BodyMesh)
		{
			if (Row.SkeletalMesh.IsNull())
			{
				Q6JsonLogSunny(Error, "Unit model has no body mesh", Q6KV("UnitType", ModelType));
			}
			else
			{
				FString RefString = Row.SkeletalMesh.ToString();
				Q6JsonLogSunny(Error, "Invalid body mesh", Q6KV("Mesh", *RefString));
			}
			BodyMesh = GetGameResource().DummySkeletalMesh.LoadSynchronous();
		}

		return BodyMesh;
	}
}

void ULevelUtil::LoadSkeletalMesh(USkeletalMeshComponent* SkelMeshComp, const FUnitModelAssetRow& Row, int32 ModelType, bool bDestroyOwnerParticles, bool bOverrideMaterial /* = false */, bool bSubDissolveMaterialClear /* = true */, bool bSpawnParticle /* = true */)
{
	if (!SkelMeshComp)
	{
		return;
	}

	if (AActor* Owner = SkelMeshComp->GetOwner())
	{
		TInlineComponentArray<UParticleSystemComponent*> PSComponents;
		Owner->GetComponents<UParticleSystemComponent>(PSComponents);
		for (UParticleSystemComponent* PSComp : PSComponents)
		{
			if (bDestroyOwnerParticles || PSComp->GetAttachParent() == SkelMeshComp)
			{
				PSComp->DestroyComponent(true);
			}
		}
	}

	SkelMeshComp->SetSkeletalMesh(LoadSkeletalMeshInternal(Row, ModelType));
	SkelMeshComp->EmptyOverrideMaterials();

	if (bSubDissolveMaterialClear)
	{
		SkelMeshComp->ClearSubMaterial();
		SkelMeshComp->ClearDissolveMaterial();
	}

	if (bOverrideMaterial)
	{
		GetGameResource().SetSkeletalMeshOverrideMaterials(SkelMeshComp, Row);
	}

	if (bSpawnParticle)
	{
		for (int32 i = 0; i < Row.ParticleSockets.Num(); ++i)
		{
			const FQ6ParticleSocket& PSocket = Row.ParticleSockets[i];
			if (PSocket.PSTemplate.IsNull())
			{
				Q6JsonLogMedrian5(Error, "SkeletalMesh Particle Null", Q6KV("UnitType", ModelType), Q6KV("Particle", i));
				continue;
			}

			if (SkelMeshComp->DoesSocketExist(Row.ParticleSockets[i].Socket))
			{
				UGameplayStatics::SpawnEmitterAttached(PSocket.PSTemplate.LoadSynchronous(), SkelMeshComp, PSocket.Socket, PSocket.Offset, PSocket.Rotation, PSocket.Scale);
			}
			else
			{
				Q6JsonLogMedrian5(Error, "SkeletalMesh Invalid Particle Socket", Q6KV("UnitType", ModelType), Q6KV("Particle", i));
			}
		}
	}
}


void ULevelUtil::LoadZoneAttribute(const UWorld* World)
{
	for (TActorIterator<AZoneAttributeActor> It(World->GetWorld(), AZoneAttributeActor::StaticClass()); It; ++It)
	{
		if (AZoneAttributeActor* EffectActor = *It)
		{
			UQ6GameInstance::Get()->SetZoneAttribute(EffectActor->GetZoneAttribute());
			break;
		}
	}
}

void ULevelUtil::SetCurrentCaptureActor(const UWorld* World, bool bEnable, FName Tag)
{
	for (TActorIterator<AQ6Capture2D> It(World->GetWorld(), AQ6Capture2D::StaticClass()); It; ++It)
	{
		AQ6Capture2D* CaptureActor = *It;
		if (CaptureActor && CaptureActor->ActorHasTag(Tag))
		{
			CaptureActor->SetActorHiddenInGame(!bEnable);
			CaptureActor->SetActorEnableCollision(bEnable);
			CaptureActor->SetActorTickEnabled(bEnable);
		}
	}
}

void ULevelUtil::BindMeshModel(const UWorld* World, AQ6Capture2D* CaptureActor, int ModelType)
{
	if (!CaptureActor || !CaptureActor->GetMesh())
	{
		return;
	}
	
	const FUnitModelAssetRow& AssetRow = GetGameResource().GetUnitModelAssetRow(ModelType);

	USkeletalMeshComponent* Mesh = CaptureActor->GetMesh();
	Mesh->SetAnimInstanceClass(nullptr);

	ULevelUtil::LoadSkeletalMesh(Mesh, AssetRow, ModelType, true);

	Mesh->SetAnimInstanceClass(AssetRow.AnimInstanceClass.LoadSynchronous());

	if (UQ6AnimInstance* AnimInstance = Cast<UQ6AnimInstance>(Mesh->GetAnimInstance()))
	{
		Mesh->SetAnimationMode(EAnimationMode::AnimationBlueprint);
		FAnimLoadingOption LoadingOption;
		LoadingOption.ModelType = ModelType;
		LoadingOption.bIsCharacter = false;
		LoadingOption.bInCombat = false;
		AnimInstance->LoadAnimations(LoadingOption, true);
		AnimInstance->SetRelaxed(true);
	}
}

AQ6Capture2D* ULevelUtil::FindCaptureActor(const UWorld* World, FName Tag)
{
	for (TActorIterator<AQ6Capture2D> It(World->GetWorld(), AQ6Capture2D::StaticClass()); It; ++It)
	{
		AQ6Capture2D* CaptureActor = *It;
		if (CaptureActor && CaptureActor->ActorHasTag(Tag))
		{
			USkeletalMeshComponent* Mesh = CaptureActor->GetMesh();
			if (Mesh)
			{
				return CaptureActor;
			}
		}
	}

	return nullptr;
}

void ULevelUtil::LayerActorVisibilityChange(const UWorld* World, FName LayerName)
{
	for (TActorIterator<AActor> It(World->GetWorld()); It; ++It)
	{
		AActor* Actor = *It;

		AWorldSettings* WorldSettings = Cast<AWorldSettings>(Actor);
		if (WorldSettings)
		{
			continue;
		}

		if (!Actor->Layers.Num())
		{
			continue;
		}

		const bool bValidLayer = (Actor->Layers.FindByKey(LayerName) != nullptr);

		Actor->SetActorHiddenInGame(!bValidLayer);
		Actor->SetActorEnableCollision(bValidLayer);
		Actor->SetActorTickEnabled(bValidLayer);

		const bool RegistCheck = Cast<ALight>(Actor) != nullptr || Cast<ASkyLight>(Actor) != nullptr;
		for (UActorComponent* Component : Actor->GetComponents())
		{
			Component->SetComponentTickEnabled(bValidLayer);

			if (RegistCheck && bValidLayer != Component->IsRegistered())
			{
				if (bValidLayer)
				{
					Component->RegisterComponent();
				}
				else
				{
					Component->UnregisterComponent();
				}
			}
		}
	}
}

void  ULevelUtil::PlayMovie(int32 Episode, int32 Stage, int32 SubStage, FSimpleDelegate InFinishedCallback)
{
	if (!GetGameResource().PlayMovie(GetGameResource().GetMovieFileMediaSource(Episode, Stage, SubStage), InFinishedCallback))
	{
		InFinishedCallback.ExecuteIfBound();
	}
}

void ULevelUtil::PlayMovie(UFileMediaSource* FileMeidaSource)
{
	GetGameResource().PlayMovie(FileMeidaSource, FSimpleDelegate());
}