// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Json.h"
#include "Logging/LogVerbosity.h"
#include "Q6Log.h"

using Q6JsonLogPrintPolicy = TCondensedJsonPrintPolicy<TCHAR>;

class FFirebaseCrashlytics;
class FFirebaseAnalytics;

FFirebaseCrashlytics* GetInitializedFirebaseCrashlytics();
FFirebaseAnalytics* GetInitializedFirebaseAnalytics();
FString Q6MakeJsonLogInteralWriteValue_ObjectToString(const UStruct* StructDefinition, const void* Struct);
void Q6SetUserNameToFirebaseCrashlytics(const FString& InUserName);
void Q6SetStringToFirebaseCrashlytics(const FString& InKey, const FString& InValue);
void Q6MakeJsonLogPost(int32 LogPriority, const FString& JsonString, TJsonWriter<TCHAR, Q6JsonLogPrintPolicy>* JsonWriter);

template <typename T>
struct TIsLogValueType
{
	enum
	{
		Value = (TIsPODType<T>::Value && !TIsPointer<T>::Value)
			|| TAreTypesEqual<T, FString>::Value
	};
};

template <typename T>
struct TIsLogRawJSONValueType
{
	enum
	{
		Value = !TIsPODType<T>::Value
			&& !TAreTypesEqual<T, FString>::Value
	};
};

template <typename PrintPolicy, typename ValueType>
typename TEnableIf<TIsLogValueType<ValueType>::Value>::Type Q6MakeJsonLogInternalWriteValue(
	TJsonWriter<TCHAR, PrintPolicy>* JsonWriter, const TCHAR* Key, const ValueType& Value)
{
	JsonWriter->WriteValue(Key, Value);
}

template <typename PrintPolicy, typename ValueType>
typename TEnableIf<TIsLogRawJSONValueType<ValueType>::Value>::Type Q6MakeJsonLogInternalWriteValue(
	TJsonWriter<TCHAR, PrintPolicy>* JsonWriter, const TCHAR* Key, const ValueType& Value)
{
	FString ObjectString = Q6MakeJsonLogInteralWriteValue_ObjectToString(ValueType::StaticStruct(), &Value);
	JsonWriter->WriteRawJSONValue(Key, ObjectString);
}

template <typename PrintPolicy, typename ValueType>
typename TEnableIf<!TAreTypesEqual<ValueType, const TCHAR*>::Value && TIsPointer<ValueType>::Value>::Type Q6MakeJsonLogInternalWriteValue(
	TJsonWriter<TCHAR, PrintPolicy>* JsonWriter, const TCHAR* Key, const ValueType& Value)
{
	if (Value)
	{
		Q6MakeJsonLogInternalWriteValue(JsonWriter, Key, *Value);
	}
	else
	{
		JsonWriter->WriteValue(Key, TEXT("(null)"));
	}
}

template <typename PrintPolicy, typename ValueType>
typename TEnableIf<TAreTypesEqual<ValueType, const TCHAR*>::Value>::Type Q6MakeJsonLogInternalWriteValue(
	TJsonWriter<TCHAR, PrintPolicy>* JsonWriter, const TCHAR* Key, const ValueType& Value)
{
	if (Value)
	{
		JsonWriter->WriteValue(Key, Value);
	}
	else
	{
		JsonWriter->WriteValue(Key, TEXT("(null)"));
	}
}

template<typename PrintPolicy, typename ValueType, typename... RestKeyValueTypes>
inline static void Q6MakeJsonLogInternal(
	TJsonWriter<TCHAR, PrintPolicy>* JsonWriter, const TPair<const TCHAR*, ValueType>& KeyValue, const RestKeyValueTypes&... RestKeyValues)
{
	Q6MakeJsonLogInternal(JsonWriter, KeyValue);
	Q6MakeJsonLogInternal(JsonWriter, RestKeyValues...);
}

template<typename PrintPolicy, typename ValueType>
inline static void Q6MakeJsonLogInternal(TJsonWriter<TCHAR, PrintPolicy>* JsonWriter, const TPair<const TCHAR*, ValueType>& KeyValue)
{
	Q6MakeJsonLogInternalWriteValue(JsonWriter, KeyValue.Key, KeyValue.Value);
}

template<typename PrintPolicy>
inline static void Q6MakeJsonLogInternal(TJsonWriter<TCHAR, PrintPolicy>*)
{ // nothing
}

template <typename... KeyValueTypes>
inline FString Q6MakeJsonLog(int32 LogPriority, const TCHAR* Verbosity, const TCHAR* Subject, const KeyValueTypes&... KeyValues)
{
	FString JsonString;

	auto JsonWriter = TJsonWriterFactory<TCHAR, Q6JsonLogPrintPolicy>::Create(&JsonString);
	JsonWriter->WriteObjectStart();
	JsonWriter->WriteValue(TEXT("Verbosity"), Verbosity);
	JsonWriter->WriteValue(TEXT("LogMessage"), Subject);
	Q6MakeJsonLogInternal(&JsonWriter.Get(), KeyValues...);
	Q6MakeJsonLogPost(LogPriority, JsonString, &JsonWriter.Get());
	return JsonString;
}

#define Q6KV(Key, Value)	MakeTuple(TEXT(Key), Value)	// Q6 Key Value

template<typename T>
FString EnumToString(const TCHAR* EnumName, const T value)
{
	UEnum* Enum = FindObject<UEnum>(ANY_PACKAGE, EnumName);
	if (Enum)
	{
		return Enum->GetNameStringByIndex(static_cast<uint8>(value));
	}

	return FString(TEXT("Unknown Enum"));
}

#define ENUM_TO_STRING(Enum, value) EnumToString(TEXT(#Enum), value)

#if NO_LOGGING

#define Q6_AUTO_LOG(...)
#define Q6JsonLog(...)
#define Q6JsonLogNet(...)
#define Q6JsonLogCms(...)
#define Q6JsonLogCheater(...)
#define Q6JsonLogSunny(...)
#define Q6JsonLogBro(...)
#define Q6JsonLogRoze(...)
#define Q6JsonLogMild(...)
#define Q6JsonLogKalms(...)
#define Q6JsonLogObiwan(...)
#define Q6JsonLogHekel(...)
#define Q6JsonLogMoon(...)
#define Q6JsonLogGunny(...)
#define Q6JsonLogZagal(...)
#define Q6JsonLogGenie(...)
#define Q6JsonLogPaul(...)
#define Q6JsonLogMedrian5(...)
#define Q6JsonLogPawn(...)
#else

DECLARE_LOG_CATEGORY_EXTERN(Q6, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_AUTO, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_NET, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_CMS, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_CHEATER, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_SUNNY, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_BRO, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_ROZE, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_MILD, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_KALMS, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_OBIWAN, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_HEKEL, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_MOON, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_GUNNY, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_ZAGAL, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_GENIE, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_PAUL, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_MEDRIAN5, All, All);
DECLARE_LOG_CATEGORY_EXTERN(Q6_PAWN, All, All);

#define FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity) PREPROCESSOR_JOIN(FIREBASE_PRIORITY_FOR_Q6_LOG_, Verbosity)

#define FIREBASE_PRIORITY_FOR_Q6_LOG_Fatal 3
#define FIREBASE_PRIORITY_FOR_Q6_LOG_Error 2
#define FIREBASE_PRIORITY_FOR_Q6_LOG_Warning 1
#define FIREBASE_PRIORITY_FOR_Q6_LOG_Display 0
#define FIREBASE_PRIORITY_FOR_Q6_LOG_Log 0
#define FIREBASE_PRIORITY_FOR_Q6_LOG_Verbose 0
#define FIREBASE_PRIORITY_FOR_Q6_LOG_VeryVerbose 0
#define FIREBASE_PRIORITY_FOR_Q6_LOG_All 0
#define FIREBASE_PRIORITY_FOR_Q6_LOG_SetColor 0

#define Q6_AUTO_LOG(Verbosity, Subject, ...) UE_LOG(Q6_AUTO, Verbosity, TEXT(Subject), ##__VA_ARGS__);

#define Q6JsonLog(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogNet(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_NET, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogCms(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_CMS, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogCheater(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_CHEATER, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogSunny(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_SUNNY, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogBro(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_BRO, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogRoze(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_ROZE, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogMild(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_MILD, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogKalms(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_KALMS, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogObiwan(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_OBIWAN, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogHekel(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_HEKEL, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogMoon(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_MOON, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogGunny(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_GUNNY, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogZagal(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_ZAGAL, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogGenie(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_GENIE, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogPaul(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_PAUL, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogMedrian5(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_MEDRIAN5, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}

#define Q6JsonLogPawn(Verbosity, Subject, ...) \
{ \
	UE_LOG(Q6_PAWN, Verbosity, TEXT("%s"), \
		*Q6MakeJsonLog(FIREBASE_PRIORITY_FOR_Q6_LOG(Verbosity), TEXT(#Verbosity), TEXT(Subject), ##__VA_ARGS__)); \
}
#endif // #if NO_LOGGING
