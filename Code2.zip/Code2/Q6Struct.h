#pragma once

#include "Q6Enum.h"
#include "Q6Type.h"
#include "CMS_gen.h"
#include "Q6Struct.generated.h"

DECLARE_DELEGATE(FSimpleDelegate)
DECLARE_DELEGATE_OneParam(FBoolParamDelegate, bool)
DECLARE_DELEGATE_OneParam(FIntParamDelegate, int32)
DECLARE_DELEGATE_OneParam(FInt64ParamDelegate, int64)
DECLARE_DELEGATE_OneParam(FFloatParamDelegate, float)

DECLARE_DELEGATE_TwoParams(FBanChoiceParamDelegate, int32, bool)
DECLARE_DELEGATE_OneParam(int32ParamDelegate, int32)
DECLARE_DELEGATE_OneParam(int32ParamDelegate, int32)
DECLARE_DELEGATE_OneParam(FUnitIdParamDelegate, FCCUnitId)
DECLARE_DELEGATE_OneParam(FSkillIdParamDelegate, FCCSkillId)

class ACombatPresenter;

class UCombatSkillGaugeFillWidget;
class UAnimSequenceBase;
class UMaterialInterface;
class UParticleSystem;
class UProgressBar;
class USkeletalMesh;
class USoundBase;

USTRUCT(BlueprintType)
struct FSubMaterialEffectParams
{
	GENERATED_BODY()

	FSubMaterialEffectParams()
		: Material(nullptr)
		, Duration(0.f)
		, Color(FLinearColor(EForceInit::ForceInit))
		, SubMaterialFalloff(0.f)
		, SubMaterialWeight(1.f)
	{}

	bool IsValid() const { return Material != nullptr; }

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	UMaterialInterface* Material;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float Duration;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FLinearColor Color;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float SubMaterialFalloff;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float SubMaterialWeight;
};

USTRUCT(BlueprintType)
struct FSpawnSkeletalMeshDesc
{
	GENERATED_BODY()

	FSpawnSkeletalMeshDesc()
		: Mesh(nullptr)
		, AnimSequence(nullptr)
		, Offset(0.0f)
		, Rotation(0.0f)
		, Scale(1.0f)
		, Duration(0.0f)
		, bDestroyAtEnd(true)
	{}

	bool IsValid() const { return (Mesh && AnimSequence); }

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	USkeletalMesh* Mesh;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	UAnimSequenceBase* AnimSequence;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName Socket;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Offset;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Rotation;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Scale;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float Duration;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bDestroyAtEnd;
};

USTRUCT(BlueprintType)
struct FSpawnSkeletalMeshParams
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnSkeletalMeshDesc Desc;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FCCUnitId UnitId;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Location;
};

USTRUCT(BlueprintType)
struct FSpawnParticleParams
{
	GENERATED_BODY()

	FSpawnParticleParams()
		: Particle(nullptr)
		, Offset(0.f)
		, Rotation(0.f)
		, Scale(1.f)
		, bAbsoluteLocation(false)
		, bAbsoluteRotation(false)
		, bAttachToUnit(false)
		, bUseNonAnimatedTransform(false)
	{}

	bool IsValid() const { return Particle != nullptr; }

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	UParticleSystem* Particle;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName Socket;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Offset;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Rotation;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Scale;

	// 1: spawns at world unless using bAttachToUnit, 0: attach to socket
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bAbsoluteLocation;

	// 1: use input rotation only, 0: include socket rotation
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bAbsoluteRotation;

	// valid when using AbsoluteLocation
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bAttachToUnit;

	// valid when using AbsoluteLocation
	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bUseNonAnimatedTransform;
};

USTRUCT(BlueprintType)
struct FSpawnRandTransParticleParams
{
	GENERATED_BODY()

	FSpawnRandTransParticleParams()
		: Particle(nullptr)
		, OffsetMin(0.f)
		, OffsetMax(0.f)
		, RotationMin(0.f)
		, RotationMax(0.f)
		, ScaleMin(1.f)
		, ScaleMax(1.f)
		, bAbsoluteLocation(false)
		, bAbsoluteRotation(false)
		, bRandomizeTransform(false)
	{}

	static FVector _GetRandomizedVector(const FVector& Min, const FVector& Max)
	{
		float RandX = FMath::RandRange(Min.X, Max.X);
		float RandY = FMath::RandRange(Min.Y, Max.Y);
		float RandZ = FMath::RandRange(Min.Z, Max.Z);

		return FVector(RandX, RandY, RandZ);
	}

	FSpawnParticleParams GetRandomizedParams()
	{
		if (!Particle)
		{
			return FSpawnParticleParams();
		}

		FSpawnParticleParams Param;
		Param.Particle = Particle;
		Param.Socket = Socket;
		Param.bAbsoluteLocation = bAbsoluteLocation;
		Param.bAbsoluteRotation = bAbsoluteRotation;

		// Randomize transform if needed
		if (bRandomizeTransform)
		{
			Param.Offset = _GetRandomizedVector(OffsetMin, OffsetMax);
			Param.Rotation = _GetRandomizedVector(RotationMin, RotationMax);
			Param.Scale = _GetRandomizedVector(ScaleMin, ScaleMax);
		}
		else
		{
			Param.Offset = OffsetMin;
			Param.Rotation = RotationMin;
			Param.Scale = ScaleMin;
		}

		return Param;
	}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	UParticleSystem* Particle;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName Socket;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector OffsetMin;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector OffsetMax;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector RotationMin;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector RotationMax;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector ScaleMin;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector ScaleMax;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bAbsoluteLocation;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bAbsoluteRotation;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bRandomizeTransform;
};

USTRUCT(BlueprintType)
struct FSpawnSoundParams
{
	GENERATED_BODY()

	FSpawnSoundParams()
		: Sound(nullptr)
		, VolumeMultiplier(1.f)
		, PitchMultiplier(1.f)
		, Delay(0.f)
	{}

	bool IsValid() const { return Sound != nullptr; }

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	USoundBase* Sound;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float VolumeMultiplier;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float PitchMultiplier;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float Delay;
};

USTRUCT(BlueprintType)
struct FPostHitInfo
{
	GENERATED_BODY()

	FPostHitInfo()
		: HitCount(1)
		, PreDelay(0.f)
		, HitInterval(0.f)
		, PostDelay(0.f)
	{}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	int32 HitCount;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float PreDelay;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float HitInterval;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float PostDelay;
};

USTRUCT(BlueprintType)
struct FSkillPostExtraEffectDesc
{
	GENERATED_BODY()

	FSkillPostExtraEffectDesc()
		: PreDelay(0.f)
		, bShowHitAnim(true)
	{}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnParticleParams ExtraParticleParams;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnSoundParams ExtraSoundParams;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnSkeletalMeshDesc ExtraMeshDesc;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float PreDelay;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bShowHitAnim;
};

USTRUCT(BlueprintType)
struct FSkillPostEffectDesc
{
	GENERATED_BODY()

	FSkillPostEffectDesc()
		: Weight(1.f)
		, bUsePostHitRandomStart(false)
		, bUseExtraEffect(false)
	{}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float Weight;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FPostHitInfo HitInfo;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bUsePostHitRandomStart;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnRandTransParticleParams HitParticleParam;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnSoundParams HitSoundParams;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSpawnSkeletalMeshDesc HitMeshDesc;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FSkillPostExtraEffectDesc ExtraEffect;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bUseExtraEffect;
};

USTRUCT(BlueprintType)
struct FSkillPostMoveDesc
{
	GENERATED_BODY()

	FSkillPostMoveDesc()
		: bMoveToTarget(false)
		, MoveBackPreDelay(0.f)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bMoveToTarget;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float MoveBackPreDelay;
};

class AProjectile;

USTRUCT(BlueprintType)
struct FProjectileEffectDesc
{
	GENERATED_BODY()

	FProjectileEffectDesc()
		: Projectile(nullptr)
		, ParticleRotation(0.f)
		, Speed(1000)
		, bPassThrough(false)
	{}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	TSoftClassPtr<AProjectile> Projectile;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector ParticleRotation;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName StartSocket;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName TargetSocket;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float Speed;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	bool bPassThrough;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FPostHitInfo HitInfo;
};

struct FSpawnProjectileParams
{
	FSpawnProjectileParams() {} // -V730
	/*FSpawnProjectileParams(const FCCSpawnProjectileParams& Params)
		, Desc(Params.Desc)
		, HitParam()
		, SourceUnitId(Params.SourceUnitId)
		, SourceTransform(ConvertToFTransform(Params.SourceTransform))
		, TargetUnitId(Params.TargetUnitId)
		, TargetLocation(ConvertToFVector(Params.TargetLocation))
	{
	}obiwan*/

	FProjectileEffectDesc Desc;
	FSpawnParticleParams HitParticleParam;
	FSpawnSoundParams HitSoundParam;

	// Source and Target can be Unit or Location(if unit id is invalid)
	FCCUnitId SourceUnitId;
	FCCUnitId TargetUnitId;
	FTransform SourceTransform;
	FVector TargetLocation;
};

USTRUCT(BlueprintType)
struct FBeamParticleEffectDesc
{
	GENERATED_BODY()

	FBeamParticleEffectDesc()
		: Particle(nullptr)
		, StartSocketOffset(0.f)
		, TargetSocketOffset(0.f)
		, Scale(1.f)
		, bDestroyAtEnd(true)
	{}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	UParticleSystem* Particle;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName StartSocket;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector StartSocketOffset;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FName TargetSocket;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector TargetSocketOffset;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	FVector Scale;

	UPROPERTY(BlueprintReadOnly, EditAnywhere, meta = (DisplayName = "Destroy Immediately", ToolTip = "Whether the particle system should be immediately destroyed at the end of the notify state or be allowed to finish"))
	bool bDestroyAtEnd;
};

struct FSpawnBeamParticleParams
{
	FBeamParticleEffectDesc Desc;
	float Duration;

	FCCUnitId SourceUnitId;
	FCCUnitId TargetUnitId;
};

namespace UnitSocket
{
	static FName Center("Center");
}

// Definition Combat Struct
USTRUCT(BlueprintInternalUseOnly)
struct FApplyTagFailedInfo
{
	GENERATED_USTRUCT_BODY()

	FApplyTagFailedInfo() : Reason(EApplyTagFailedReason::None), ReasonTag(EApplyTag::None) {}

	EApplyTagFailedReason Reason;
	EApplyTag ReasonTag;
};

USTRUCT(BlueprintInternalUseOnly)
struct FSkillAnimHitInfo
{
	GENERATED_USTRUCT_BODY()

	FSkillAnimHitInfo() : bWeightValid(false) {}

	void Empty()
	{
		HitValues.Empty();
		bWeightValid = false;
	}

	int32 GetAdded(int32 HitBegin, int32 HitEnd, int32 Total, float Div) const
	{
		int32 Added = 0;
		for (int32 i = HitBegin; i <= HitEnd; ++i)
		{
			Added += (Total * (HitValues[i] / Div));
		}
		return Added;
	}

	int32 GetTimeScaleAmount(int32 HitIdx, int32 HitMax, int32 Total, float Div) const
	{
		int32 OldHitIdx = FMath::Clamp(HitIdx - 1, 0, HitMax);
		int32 OldAmount = (HitIdx - 1 >= 0) ? (Total * (HitValues[OldHitIdx] / Div)) : 0;

		int32 NewAmount;
		if (HitIdx == HitMax)
		{
			NewAmount = Total * 1.f;
		}
		else
		{
			int32 NewHitIdx = FMath::Clamp(HitIdx, 0, HitMax);
			NewAmount = Total * (HitValues[NewHitIdx] / Div);
		}

		return NewAmount - OldAmount;
	}

	int32 GetWeightAmount(int32 HitIdx, int32 HitMax, int32 Total, float Div) const
	{
		float AmountRate = HitValues[HitIdx] / Div;
		int32 Amount = Total * AmountRate;

		if (HitIdx == HitMax)
		{
			int32 Added = GetAdded(0, HitMax - 1, Total, Div);
			Amount = Total - Added;
		}

		return Amount;
	}

	int32 GetAmount(int32 HitIdx, int32 HitMax, int32 Total, float Div) const
	{
		if (bWeightValid)
		{
			return GetWeightAmount(HitIdx, HitMax, Total, Div);
		}
		else
		{
			return GetTimeScaleAmount(HitIdx, HitMax, Total, Div);
		}
	}

	float GetHitFormulaDiv() const
	{
		float Div = 0.f;
		if (HitValues.Num())
		{
			if (bWeightValid)
			{
				for (float Value : HitValues)
				{
					Div += Value;
				}
			}
			else
			{
				Div = HitValues.Last(0);
			}
		}
		Div = Div <= 0 ? 1.f : Div;

		return Div;
	}

	float GetHitFormulaDivRange(int32 BeginIdx, int32 EndIdx)
	{
		float Div = 0.f;
		if (HitValues.Num())
		{
			BeginIdx = HitValues.IsValidIndex(BeginIdx) ? BeginIdx : 0;
			EndIdx = HitValues.IsValidIndex(EndIdx) ? EndIdx : HitValues.Num() - 1;

			if (bWeightValid)
			{
				for (int32 i = BeginIdx; i <= EndIdx; ++i)
				{
					Div += HitValues[i];
				}
			}
			else
			{
				float PrevHitValue = 0.f;
				if (HitValues.IsValidIndex(BeginIdx - 1))
				{
					PrevHitValue = HitValues[BeginIdx - 1];
					HitValues[BeginIdx - 1] = 0.f;
				}

				for (int32 i = BeginIdx; i <= EndIdx; ++i)
				{
					HitValues[i] = HitValues[i] - PrevHitValue;
				}

				Div = HitValues[EndIdx] - PrevHitValue;
			}
		}
		Div = Div <= 0.f ? 1.f : Div;

		return Div;
	}

	TArray<float> HitValues;

	// Is hit values weight or time
	bool bWeightValid;
};

USTRUCT(BlueprintInternalUseOnly)
struct FProgressUpdateTask
{
	GENERATED_BODY()

	FProgressUpdateTask() {}
	explicit FProgressUpdateTask(TWeakObjectPtr<UProgressBar> Obj, float InStart, float InTarget, float InLength,
		FSimpleDelegate InCBStart = FSimpleDelegate(), FSimpleDelegate InCBEnd = FSimpleDelegate(), FFloatParamDelegate InCBUpdate = FFloatParamDelegate())
		: WeakObj(Obj), Age(0.f), Length(InLength), StartPercent(InStart), EndPercent(InTarget), CBStart(InCBStart), CBEnd(InCBEnd), CBUpdate(InCBUpdate) {}

	TWeakObjectPtr<UProgressBar> WeakObj;

	float Age;
	float Length;
	float StartPercent;
	float EndPercent;

	FSimpleDelegate CBStart;
	FSimpleDelegate CBEnd;
	FFloatParamDelegate CBUpdate;
};

USTRUCT(BlueprintInternalUseOnly)
struct FSkillGaugeProgressUpdateTask
{
	GENERATED_BODY()

	FSkillGaugeProgressUpdateTask() {}
	explicit FSkillGaugeProgressUpdateTask(TWeakObjectPtr<UCombatSkillGaugeFillWidget> Obj, float InStart, float InTarget, float InLength,
		FSimpleDelegate InCBStart = FSimpleDelegate(), FSimpleDelegate InCBEnd = FSimpleDelegate(), FFloatParamDelegate InCBUpdate = FFloatParamDelegate())
		: WeakObj(Obj), Age(0.f), Length(InLength), StartPercent(InStart), EndPercent(InTarget), CBStart(InCBStart), CBEnd(InCBEnd), CBUpdate(InCBUpdate) {}

	TWeakObjectPtr<UCombatSkillGaugeFillWidget> WeakObj;

	float Age;
	float Length;
	float StartPercent;
	float EndPercent;

	FSimpleDelegate CBStart;
	FSimpleDelegate CBEnd;
	FFloatParamDelegate CBUpdate;
};

UCLASS(NotBlueprintable)
class UUnitHit : public UObject
{
	GENERATED_BODY()

public:
	bool IsLastHit() const { return HitIndex == (HitMax - 1); }
	void SetInfo(ENatureRelationType InNatureRelationType, FCCUnitId InSourceUnitId, FCCUnitId InTargetUnitId,
		int32 InAddedBaseHealth, int32 InAddedExtraHealth, int32 InShieldDamage, int32 InExtraShieldDamage, bool bInShieldWeakPoint,
		int32 InAddedOverKill, EHealthChangeReason InReason, int32 InHitIndex, int32 InHitMax, bool bInCritical, bool bInDodged)
	{
		NatureRelationType = InNatureRelationType;
		SourceUnitId = InSourceUnitId;
		TargetUnitId = InTargetUnitId;
		AddedBaseHealth = InAddedBaseHealth;
		AddedExtraHealth = InAddedExtraHealth;
		ShieldDamage = InShieldDamage;
		ExtraShieldDamage = InExtraShieldDamage;
		bShieldWeakPoint = bInShieldWeakPoint;
		AddedOverKill = InAddedOverKill;
		Reason = InReason;
		HitIndex = InHitIndex;
		HitMax = InHitMax;
		bCritical = bInCritical;
		bDodged = bInDodged;
	}

public:
	UPROPERTY(BlueprintReadOnly)
	ENatureRelationType NatureRelationType;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId SourceUnitId;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId TargetUnitId;

	UPROPERTY(BlueprintReadOnly)
	int32 AddedBaseHealth;

	UPROPERTY(BlueprintReadOnly)
	int32 AddedExtraHealth;

	UPROPERTY(BlueprintReadOnly)
	int32 AddedOverKill;

	UPROPERTY(BlueprintReadOnly)
	int32 ShieldDamage;

	UPROPERTY(BlueprintReadOnly)
	int32 ExtraShieldDamage;

	UPROPERTY(BlueprintReadOnly)
	bool bShieldWeakPoint;

	UPROPERTY(BlueprintReadOnly)
	EHealthChangeReason Reason;

	UPROPERTY(BlueprintReadOnly)
	int32 HitIndex;

	UPROPERTY(BlueprintReadOnly)
	int32 HitMax;

	UPROPERTY(BlueprintReadOnly)
	bool bCritical;

	UPROPERTY(BlueprintReadOnly)
	bool bDodged;
};
