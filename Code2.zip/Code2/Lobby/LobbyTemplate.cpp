// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "LobbyTemplate.h"
#include "Animation/AnimSingleNodeInstance.h"
#include "CineCameraActor.h"
#include "CineCameraComponent.h"
#include "CMSTable.h"
#include "CMS_gen.h"
#include "Components/CapsuleComponent.h"
#include "Components/Q6DirectionalLightComponent.h"
#include "Components/SceneComponent.h"
#include "HUDStore/CharacterManager.h"
#include "HUDStore/HUDStore.h"
#include "LobbyHUD.h"
#include "LobbyPlayerController.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "UnitAnimInstance.h"
#include "Utils/LevelUtil.h"

//////////////////////////////////////////////////////////////////////////////////
// ULobbyCameraComponent

ULobbyCameraComponent::ULobbyCameraComponent()
	: LobbyTemplateCameraType(ELobbyTemplateCamera::Main)
{
}

//////////////////////////////////////////////////////////////////////////////////
// ULobbyAnimationHelper

void ULobbyAnimationHelper::InitAnimations(const FLobbyAnimationInfo& InAnimInfo)
{
	WelcomeAnimation = InAnimInfo.WelcomeAnimation.AnimSequence.LoadSynchronous();

	IdleAnimations.Empty();
	for (const FAnimationInfo& IdleAnimation : InAnimInfo.IdleAnimations)
	{
		if (IdleAnimation.AnimSequence.IsNull())
		{
			continue;
		}
		IdleAnimations.Add(IdleAnimation.AnimSequence.LoadSynchronous());
	}

	InteractionAnimations.Empty();
	for (const FAnimationInfo& InteractionAnimation : InAnimInfo.InteractionAnimations)
	{
		if (InteractionAnimation.AnimSequence.IsNull())
		{
			continue;
		}
		InteractionAnimations.Add(InteractionAnimation.AnimSequence.LoadSynchronous());
	}
}

void ULobbyAnimationHelper::PlayAnimAsMontage(UUnitAnimInstance* AnimInst, UAnimSequenceBase* Anim, FOnMontageBlendingOutStarted& Delegate, bool bLoop, float BlendInTime, float BlendOutTime)
{
	if (!AnimInst)
	{
		return;
	}

	static FName DefaultSlot(TEXT("DefaultSlot"));

	UAnimMontage* Montage = AnimInst->PlaySlotAnimAsMontage(Anim, DefaultSlot, true, BlendInTime, BlendOutTime);
	if (Montage)
	{
		AnimInst->Montage_SetBlendingOutDelegate(Delegate);

		if (bLoop)
		{
			AnimInst->Montage_SetNextSection(TEXT("Default"), TEXT("Default"), Montage);
		}

		bPlayingOneShotAnim = !bLoop;
	}
}

void ULobbyAnimationHelper::OnMontageBlendingOut(UUnitAnimInstance* AnimInst, UAnimMontage* Montage, bool bInterrupted)
{
	bPlayingOneShotAnim = false;

	if (Montage && !bInterrupted)
	{
		FOnMontageBlendingOutStarted Delegate;
		PlayAnimAsMontage(AnimInst, GetRandomElement(IdleAnimations), Delegate, true, 0.25f, 0.f);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// ULobbyCharacterComponent

ULobbyCharacterComponent::ULobbyCharacterComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Index(0)
	, CharacterType(CharacterTypeInvalid)
{
}

void ULobbyCharacterComponent::InitLobbyCharacter(const FCharacterType& InCharacterType, const FLobbyAnimationInfo& InAnimInfo)
{
	if (InCharacterType == CharacterTypeInvalid)
	{
		CharacterType = InCharacterType;
		SetSkeletalMesh(nullptr);
		return;
	}

	if (InCharacterType == CharacterType)
	{
		return;
	}
	CharacterType = InCharacterType;

	// mesh
	int32 UnitType = GetCMS()->GetUnitType(CharacterType);
	int32 ModelType = GetCMS()->GetModelTypeFromUnitType(UnitType);
	const FUnitModelAssetRow& UnitModelAssetRow = GetGameResource().GetUnitModelAssetRow(ModelType);

	ULevelUtil::LoadSkeletalMesh(this, UnitModelAssetRow, ModelType, false, true);
	if (!SkeletalMesh)
	{
		return;
	}

	if (!UnitModelAssetRow.AnimInstanceClass.IsNull())
	{
		SetAnimInstanceClass(UnitModelAssetRow.AnimInstanceClass.LoadSynchronous());
		SetAnimationMode(EAnimationMode::AnimationBlueprint);
	}

	UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(GetAnimInstance());
	if (AnimInst)
	{
		AnimInst->SetDialogueMode(true);
	}

	// animations
	InitAnimations(InAnimInfo);
	if (!IsPlaying() && AnimationHelper)
	{
		PlayAnimAsMontage(GetRandomElement(AnimationHelper->IdleAnimations), true);
	}

	// capsule
	if (!CapsuleComponent)
	{
		CapsuleComponent = NewObject<UCapsuleComponent>(this, UCapsuleComponent::StaticClass(),
			MakeUniqueObjectName(this, UCapsuleComponent::StaticClass(), TEXT("CapsuleComponent")), RF_Transient);
		check(CapsuleComponent);
		CapsuleComponent->bAlwaysCreatePhysicsState = false;
		CapsuleComponent->SetupAttachment(this);
		CapsuleComponent->RegisterComponent();
		CapsuleComponent->BodyInstance.SetResponseToAllChannels(ECollisionResponse::ECR_Ignore);
		CapsuleComponent->BodyInstance.SetResponseToChannel(ECollisionChannel::ECC_GameTraceChannel1, ECollisionResponse::ECR_Block);
	}
	CapsuleComponent->SetCapsuleSize(UnitModelAssetRow.BoundRadius, UnitModelAssetRow.BoundHalfHeight);
	CapsuleComponent->SetRelativeLocation(FVector(0, 0, UnitModelAssetRow.BoundHalfHeight));
}

void ULobbyCharacterComponent::InitAnimations(const FLobbyAnimationInfo& InAnimInfo)
{
	if (AnimationHelper)
	{
		AnimationHelper = nullptr;
	}
	AnimationHelper = NewObject<ULobbyAnimationHelper>();
	AnimationHelper->InitAnimations(InAnimInfo);
}

void ULobbyCharacterComponent::PlayWelcomeAnimation()
{
	if (!AnimationHelper)
	{
		return;
	}

	PlayAnimAsMontage(AnimationHelper->WelcomeAnimation, false, 0.f, 0.25f);
}

void ULobbyCharacterComponent::ClearIntermediateState()
{
	if (SkeletalMesh)
	{
		return;
	}

	if (CapsuleComponent)
	{
		CapsuleComponent->DestroyComponent();
	}

	if (AnimationHelper)
	{
		AnimationHelper = nullptr;
	}
}

void ULobbyCharacterComponent::OnTouched()
{
	if (!SkeletalMesh || bHiddenInGame)
	{
		return;
	}

	if (!AnimationHelper ||	AnimationHelper->bPlayingOneShotAnim ||	!AnimationHelper->InteractionAnimations.Num())
	{
		return;
	}

	PlayAnimAsMontage(GetRandomElement(AnimationHelper->InteractionAnimations), false, 0.f, 0.25f);
}

void ULobbyCharacterComponent::PlayAnimAsMontage(UAnimSequenceBase* Anim, bool bLoop, float BlendInTime /* = 0.f */, float BlendOutTime /* = 0.f */)
{
	if (!AnimationHelper)
	{
		return;
	}

	FOnMontageBlendingOutStarted Delegate;
	Delegate.BindUObject(this, &ULobbyCharacterComponent::OnMontageBlendingOut);

	UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(GetAnimInstance());
	AnimationHelper->PlayAnimAsMontage(AnimInst, Anim, Delegate, bLoop, BlendInTime, BlendOutTime);
}

void ULobbyCharacterComponent::OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted)
{
	if (!AnimationHelper)
	{
		return;
	}

	UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(GetAnimInstance());
	AnimationHelper->OnMontageBlendingOut(AnimInst, Montage, bInterrupted);
}

//////////////////////////////////////////////////////////////////////////////////
// ULobbyTitleWidget

ULobbyTitleWidget::ULobbyTitleWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void ULobbyTitleWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ShowAnim = GetWidgetAnimationFromName(this, "AnimShow");
	HideAnim = GetWidgetAnimationFromName(this, "AnimHide");
}

void ULobbyTitleWidget::SetShow(bool bInShow)
{
	PlayAnimation(bInShow ? ShowAnim : HideAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// ALobbyTemplate

ALobbyTemplate::ALobbyTemplate(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CameraSwipeAngle(45.f)
	, PanoramaIntroTime(1.f)
	, CameraBlendParams()
	, CameraBlendCurve(nullptr)
	, MainViewComponentsMaterialBlendTime(0.f)
	, MainViewComponentsMaterialBlendParameterName()
	, MainViewComponentsMaterialBlendCurve(nullptr)
	, LobbyTemplateCameraType(ELobbyTemplateCamera::Main)
	, PendingLobbyTemplateCameraType(ELobbyTemplateCamera::Max)
	, MainViewComponentsMaterialBlendTimeline()
	, DefaultCameraYaw(0.f)
	, CameraYawMin(0.f)
	, CameraYawMax(0.f)
	, bSwipable(false)
	, bHasDirectionalLight(false)
{
	PrimaryActorTick.bCanEverTick = true;

	CameraBlendParams.CurveFloat = CameraBlendCurve;
}

void ALobbyTemplate::InitTemplate(const TArray<FLobbyTemplateCharacterSlotInfo>& InSlotInfos)
{
	InitTemplateCameras();
	InitTitleWidget();

	LobbyCharacters.Empty();

	TArray<UActorComponent*> Components;
	GetComponents(ULobbyCharacterComponent::StaticClass(), Components);
	for (UActorComponent* Component : Components)
	{
		ULobbyCharacterComponent* LobbyCharacter = Cast<ULobbyCharacterComponent>(Component);
		if (!LobbyCharacter)
		{
			continue;
		}

		LobbyCharacter->SetHiddenInGame(true);
		LobbyCharacters.Add(LobbyCharacter);
	}

	LobbyCharacters.Sort([](const ULobbyCharacterComponent& CharacterA, const ULobbyCharacterComponent& CharacterB)
	{
		return (CharacterA.GetIndex() < CharacterB.GetIndex());
	});

	UQ6DirectionalLightComponent* DirectionalLightComponent = Cast<UQ6DirectionalLightComponent>(GetComponentByClass(UQ6DirectionalLightComponent::StaticClass()));
	if (DirectionalLightComponent)
	{
		bHasDirectionalLight = true;
	}

	SlotInfos = InSlotInfos;
}

ACineCameraActor* ALobbyTemplate::SpawnCloneCineCameraActor(UCineCameraComponent* InCineCameraComponent)
{
	FActorSpawnParameters SpawnParam;
	SpawnParam.Name = MakeUniqueObjectName(GetWorld(), ACameraActor::StaticClass(), *FString::Printf(TEXT("TempCamera_%s"), *InCineCameraComponent->GetName()));
	SpawnParam.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	ACineCameraActor* OutCineCameraActor = GetWorld()->SpawnActor<ACineCameraActor>(
		InCineCameraComponent->GetComponentLocation(),
		InCineCameraComponent->GetComponentRotation(),
		SpawnParam);

	UCineCameraComponent* TargetComponent = OutCineCameraActor->GetCineCameraComponent();
	TargetComponent->FieldOfView = InCineCameraComponent->FieldOfView;
	TargetComponent->AspectRatio = InCineCameraComponent->AspectRatio;
	TargetComponent->bConstrainAspectRatio = InCineCameraComponent->bConstrainAspectRatio;
	TargetComponent->ProjectionMode = InCineCameraComponent->ProjectionMode;
	TargetComponent->OrthoWidth = InCineCameraComponent->OrthoWidth;
	TargetComponent->PostProcessBlendWeight = InCineCameraComponent->PostProcessBlendWeight;
	TargetComponent->PostProcessSettings = InCineCameraComponent->PostProcessSettings;
	TargetComponent->Filmback = InCineCameraComponent->Filmback;
	TargetComponent->LensSettings = InCineCameraComponent->LensSettings;
	TargetComponent->FocusSettings = InCineCameraComponent->FocusSettings;

	return OutCineCameraActor;
}

void ALobbyTemplate::InitTemplateCameras()
{
	TArray<UActorComponent*> Components;
	GetComponents(ULobbyCameraComponent::StaticClass(), Components);
	for (UActorComponent* Component : Components)
	{
		ULobbyCameraComponent* LobbyCameraComponent = Cast<ULobbyCameraComponent>(Component);
		if (!LobbyCameraComponent)
		{
			continue;
		}
		LobbyCameraComponent->SetActive(false);

		switch (LobbyCameraComponent->GetLobbyTemplateCameraType())
		{
			case ELobbyTemplateCamera::Main:
				MainCamera = SpawnCloneCineCameraActor(LobbyCameraComponent);
				LobbyCameraComponent->GetChildrenComponents(false, MainViewComponents);
				InitMainViewComponentsMaterialBlend();
				break;
			case ELobbyTemplateCamera::Panorama:
				PanoramaCamera = SpawnCloneCineCameraActor(LobbyCameraComponent);
				break;
			default:
				ensure(0);
				break;
		}
	}

	if (!MainCamera)
	{
		UCineCameraComponent* CameraComponent = Cast<UCineCameraComponent>(GetComponentByClass(UCineCameraComponent::StaticClass()));
		if (CameraComponent)
		{
			MainCamera = SpawnCloneCineCameraActor(CameraComponent);
		}
	}

	if (MainCamera)
	{
		DefaultCameraYaw = MainCamera->GetActorRotation().Yaw;
		CameraYawMin = DefaultCameraYaw - CameraSwipeAngle;
		CameraYawMax = DefaultCameraYaw + CameraSwipeAngle;
		bSwipable = CameraSwipeAngle > 0.f;
	}
}

void ALobbyTemplate::InitView(bool bShowPanoramaIntro)
{
	if (bShowPanoramaIntro)
	{
		if (PanoramaCamera)
		{
			LobbyTemplateCameraType = ELobbyTemplateCamera::Panorama;
			MainViewComponentsMaterialBlendTimeline.SetPlaybackPosition(0.f, false, false);

			SetTitleWidgetVisible(true);
		}
	}
	else
	{
		ResetView();
	}
}

void ALobbyTemplate::InitMainViewComponentsMaterialBlend()
{
	if (!MainViewComponents.Num())
	{
		return;
	}

	for (USceneComponent* MainViewComponent : MainViewComponents)
	{
		UMeshComponent* MeshComponent = Cast<UMeshComponent>(MainViewComponent);
		if (!MeshComponent)
		{
			continue;
		}

		int32 NumMaterials = MeshComponent->GetNumMaterials();
		for (int32 i = 0; i < NumMaterials; ++i)
		{
			UMaterialInterface* Material = MeshComponent->GetMaterial(i);
			UMaterialInstanceDynamic* DynamicMaterial = MeshComponent->CreateDynamicMaterialInstance(i, Material);
			DynamicMaterial->K2_CopyMaterialInstanceParameters(Material);
		}
	}

	MainViewComponentsMaterialBlendTimeline.SetTimelineLength(MainViewComponentsMaterialBlendTime);

	FOnTimelineFloatStatic InterpFunc;
	InterpFunc.BindUObject(this, &ALobbyTemplate::OnMainViewComponentsMaterialBlend);
	MainViewComponentsMaterialBlendTimeline.AddInterpFloat(MainViewComponentsMaterialBlendCurve, InterpFunc);
}

void ALobbyTemplate::InitTitleWidget()
{
	if (LobbyTitleWidgetClass.IsNull())
	{
		return;
	}

	LobbyTitleWidget = CreateWidget<ULobbyTitleWidget>(GetLocalPlayerController(this), LobbyTitleWidgetClass.LoadSynchronous());
	if (LobbyTitleWidget)
	{
		LobbyTitleWidget->AddToViewport(ZORDER_BELOW_HUD);
		LobbyTitleWidget->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void ALobbyTemplate::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (MainViewComponentsMaterialBlendCurve)
	{
		MainViewComponentsMaterialBlendTimeline.TickTimeline(DeltaTime);
	}
}

void ALobbyTemplate::Destroyed()
{
	if (LobbyTitleWidget)
	{
		LobbyTitleWidget->RemoveFromParent();
	}

	if (MainCamera)
	{
		MainCamera->Destroy();
	}
	if (PanoramaCamera)
	{
		PanoramaCamera->Destroy();
	}

	GetWorldTimerManager().ClearTimer(PanoramaIntroTimerHandle);
	PanoramaIntroTimerHandle.Invalidate();

	GetWorldTimerManager().ClearTimer(CameraBlendingTimerHandle);
	CameraBlendingTimerHandle.Invalidate();

	GetWorldTimerManager().ClearTimer(MainViewComponentsMaterialBlendTimerHandle);
	MainViewComponentsMaterialBlendTimerHandle.Invalidate();

	Super::Destroyed();
}

void ALobbyTemplate::SetCharacters(const TArray<FCharacterId>& InCharacterIds)
{
	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();

	for (int32 i = 0; i < LobbyCharacters.Num(); ++i)
	{
		if (InCharacterIds.IsValidIndex(i))
		{
			const FCharacter* Character = CharacterMgr.Find(InCharacterIds[i]);
			if (Character)
			{
				SetCharacter(i, Character->GetInfo().Type);
				continue;
			}
		}

		SetCharacter(i, CharacterTypeInvalid);
	}
}

void ALobbyTemplate::SetCharacter(int32 Index, FCharacterType InCharacterType)
{
	if (!LobbyCharacters.IsValidIndex(Index))
	{
		return;
	}

	FLobbyAnimationInfo AnimInfo;
	if (InCharacterType != CharacterTypeInvalid)
	{
		if (!IsExclusiveCharacter(Index, InCharacterType, AnimInfo))
		{
			const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(InCharacterType);
			AnimInfo = CharacterAssetRow.LobbyAnimationInfo;
		}
	}

	LobbyCharacters[Index]->InitLobbyCharacter(InCharacterType, AnimInfo);
	LobbyCharacters[Index]->SetHiddenInGame(false);
}

bool ALobbyTemplate::IsExclusiveCharacter(int32 Index, FCharacterType CharacterType, FLobbyAnimationInfo& OutAnimInfo)
{
	if (!SlotInfos.IsValidIndex(Index))
	{
		return false;
	}

	for (const FLobbyExclusiveCharacterInfo& ExclusiveInfo : SlotInfos[Index].ExclusiveInfos)
	{
		if (ExclusiveInfo.ExclusiveCharacterType == CharacterType)
		{
			OutAnimInfo = ExclusiveInfo.ExclusiveAnimationInfo;
			return true;
		}
	}

	return false;
}

void ALobbyTemplate::SetCharactersVisible(bool bVisible)
{
	for (ULobbyCharacterComponent* LobbyCharacter : LobbyCharacters)
	{
		LobbyCharacter->SetHiddenInGame(!bVisible);
	}
}

void ALobbyTemplate::PlayCharacterWelcomeAnimation(int32 InIndex)
{
	for (ULobbyCharacterComponent* LobbyCharacter : LobbyCharacters)
	{
		if (InIndex == INDEX_NONE || InIndex == LobbyCharacter->GetIndex())
		{
			LobbyCharacter->PlayWelcomeAnimation();
		}
	}
}

void ALobbyTemplate::ClearCharactersIntermediateState()
{
	for (ULobbyCharacterComponent* LobbyCharacter : LobbyCharacters)
	{
		LobbyCharacter->ClearIntermediateState();
	}
}

void ALobbyTemplate::ResetView()
{
	LobbyTemplateCameraType = ELobbyTemplateCamera::Main;
	MainViewComponentsMaterialBlendTimeline.SetPlaybackPosition(1.f, false, false);
}

void ALobbyTemplate::ResetCamera()
{
	if (!MainCamera)
	{
		return;
	}

	if (!bSwipable)
	{
		return;
	}

	FRotator CameraRot = MainCamera->GetActorRotation();
	CameraRot.Yaw = DefaultCameraYaw;
	MainCamera->SetActorRotation(CameraRot);
}

void ALobbyTemplate::RotateCamera(float ScrollVelocity)
{
	if (!MainCamera)
	{
		return;
	}

	if (!bSwipable)
	{
		return;
	}

	FRotator CameraRot = MainCamera->GetActorRotation();
	CameraRot.Yaw = FMath::ClampAngle(CameraRot.Yaw + ScrollVelocity, CameraYawMin, CameraYawMax);
	MainCamera->SetActorRotation(CameraRot);
}

void ALobbyTemplate::RotateCameraTo(int32 CharacterSlotIndex)
{
	if (!LobbyCharacters.IsValidIndex(CharacterSlotIndex))
	{
		return;
	}

	const ULobbyCharacterComponent* TargetCharacter = LobbyCharacters[CharacterSlotIndex];
	FVector Dir = TargetCharacter->GetComponentLocation() - MainCamera->GetActorLocation();
	FRotator TargetRot = Dir.ToOrientationRotator();

	FRotator CameraRot = MainCamera->GetActorRotation();
	CameraRot.Yaw = FMath::ClampAngle(TargetRot.Yaw, CameraYawMin, CameraYawMax);
	MainCamera->SetActorRotation(CameraRot);
}

void ALobbyTemplate::InputDragged(const FVector2D& DeltaLocation, float ScrollVelocity)
{
	if (PanoramaCamera && (FMath::Abs(DeltaLocation.X) < FMath::Abs(DeltaLocation.Y)))
	{
		ToggleLobbyViewTarget();
	}
	else
	{
		RotateCamera(ScrollVelocity);
	}
}

bool ALobbyTemplate::IsWidgetShowingView() const
{
	return LobbyTemplateCameraType == ELobbyTemplateCamera::Main;
}

void ALobbyTemplate::SetTimerOrExecuteDelegate(FTimerHandle& InOutHandle, FTimerDelegate InDelegate, float InTime)
{
	if (InTime > 0.f)
	{
		GetWorldTimerManager().ClearTimer(InOutHandle);
		GetWorldTimerManager().SetTimer(InOutHandle, InDelegate, InTime, false);
	}
	else
	{
		InDelegate.ExecuteIfBound();
	}
}

void ALobbyTemplate::SetToViewTarget(class APlayerController* PC)
{
	if (!PC)
	{
		return;
	}

	if (PC->PlayerCameraManager)
	{
		PC->PlayerCameraManager->BlendTimeToGo = 0.f;
	}
	if (CameraBlendingTimerHandle.IsValid())
	{
		GetWorldTimerManager().ClearTimer(CameraBlendingTimerHandle);
		CameraBlendingTimerHandle.Invalidate();
	}

	SetEnableMainViewPostProcessBlend(true);

	switch (LobbyTemplateCameraType)
	{
		case ELobbyTemplateCamera::Main:
			PC->SetViewTarget(MainCamera);
			break;
		case ELobbyTemplateCamera::Panorama:
			PC->SetViewTarget(PanoramaCamera);
			SetTimerOrExecuteDelegate(PanoramaIntroTimerHandle, FTimerDelegate::CreateUObject(this, &ALobbyTemplate::OnPanoramaIntroEnd), PanoramaIntroTime);
			break;
		default:
			break;
	}
}

void ALobbyTemplate::OnPanoramaIntroEnd()
{
	PanoramaIntroTimerHandle.Invalidate();
	ChangeLobbyViewTarget(ELobbyTemplateCamera::Main);
}

AActor* ALobbyTemplate::GetLobbyViewTarget(ELobbyTemplateCamera InType) const
{
	switch (InType)
	{
		case ELobbyTemplateCamera::Main:
			return MainCamera;
		case ELobbyTemplateCamera::Panorama:
			return PanoramaCamera;
		default:
			return nullptr;
	}
}

void ALobbyTemplate::ChangeLobbyViewTarget(ELobbyTemplateCamera InType)
{
	if (InType == LobbyTemplateCameraType)
	{
		return;
	}

	if (LobbyTemplateCameraType == ELobbyTemplateCamera::Main)
	{
		PendingLobbyTemplateCameraType = InType;
		MainViewComponentsMaterialBlendTimeline.Reverse();
		SetTimerOrExecuteDelegate(MainViewComponentsMaterialBlendTimerHandle, FTimerDelegate::CreateUObject(this, &ALobbyTemplate::OnMainViewComponentsMaterialBlendEnd), MainViewComponentsMaterialBlendTime);
	}
	else
	{
		if (LobbyTemplateCameraType == ELobbyTemplateCamera::Panorama)
		{
			SetTitleWidgetVisible(false);
		}

		SetLobbyViewTarget(InType);
		SetTimerOrExecuteDelegate(CameraBlendingTimerHandle, FTimerDelegate::CreateUObject(this, &ALobbyTemplate::OnCameraBlendingFinished), CameraBlendParams.BlendTime);
	}
}

void ALobbyTemplate::SetLobbyViewTarget(ELobbyTemplateCamera InType)
{
	ALobbyPlayerController* LobbyPC = GetLobbyPlayerController(this);
	if (!LobbyPC)
	{
		return;
	}

	AActor* NewViewTarget = GetLobbyViewTarget(InType);
	if (!NewViewTarget)
	{
		return;
	}

	if (LobbyTemplateCameraType == ELobbyTemplateCamera::Main)
	{
		SetEnableMainViewPostProcessBlend(false);
	}
	else if (InType == ELobbyTemplateCamera::Main)
	{
		SetEnableMainViewPostProcessBlend(true);
	}

	LobbyPC->SetViewTarget(NewViewTarget, CameraBlendParams);
	LobbyTemplateCameraType = InType;

	if (LobbyTemplateCameraType != ELobbyTemplateCamera::Main)
	{
		ALobbyHUD* LobbyHUD = GetLobbyHUD(this);
		if (LobbyHUD && LobbyHUD->GetCurrentHUDWidgetType() == EHUDWidgetType::Main)
		{
			LobbyHUD->SetShowMainWidgets(false);
		}
	}
}

void ALobbyTemplate::ToggleLobbyViewTarget()
{
	switch (LobbyTemplateCameraType)
	{
		case ELobbyTemplateCamera::Main:
			ChangeLobbyViewTarget(ELobbyTemplateCamera::Panorama);
			break;
		case ELobbyTemplateCamera::Panorama:
			ChangeLobbyViewTarget(ELobbyTemplateCamera::Main);
		default:
			break;
	}
}

void ALobbyTemplate::SetEnableMainViewPostProcessBlend(bool bInEnable)
{
	if (!MainCamera || !MainCamera->GetCineCameraComponent())
	{
		return;
	}

	MainCamera->GetCineCameraComponent()->SetPostProcessBlendWeight(bInEnable ? 1.f : 0.f);
}

void ALobbyTemplate::SetTitleWidgetVisible(bool bInVisible)
{
	ALobbyHUD* LobbyHUD = GetLobbyHUD(this);
	if (!LobbyHUD || LobbyHUD->GetCurrentHUDWidgetType() != EHUDWidgetType::Main)
	{
		return;
	}

	if (!LobbyTitleWidget)
	{
		return;
	}

	LobbyTitleWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LobbyTitleWidget->SetShow(bInVisible);
}

void ALobbyTemplate::OnCameraBlendingFinished()
{
	CameraBlendingTimerHandle.Invalidate();

	if (LobbyTemplateCameraType == ELobbyTemplateCamera::Main)
	{
		MainViewComponentsMaterialBlendTimeline.PlayFromStart();

		UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
		if (GameInstance && GameInstance->IsFirstShowLobby())
		{
			GameInstance->SetFirstShowLobby(false);
			PlayCharacterWelcomeAnimation(INDEX_NONE);
		}

		ALobbyHUD* LobbyHUD = GetLobbyHUD(this);
		if (LobbyHUD && LobbyHUD->GetCurrentHUDWidgetType() == EHUDWidgetType::Main)
		{
			LobbyHUD->SetShowMainWidgets(true);
		}
	}
	else if (LobbyTemplateCameraType == ELobbyTemplateCamera::Panorama)
	{
		SetTitleWidgetVisible(true);
	}
}

void ALobbyTemplate::OnMainViewComponentsMaterialBlend(float InFloat)
{
	for (USceneComponent* MainViewComponent : MainViewComponents)
	{
		UMeshComponent* MeshComponent = Cast<UMeshComponent>(MainViewComponent);
		if (!MeshComponent)
		{
			continue;
		}

		int32 NumMaterials = MeshComponent->GetNumMaterials();
		for (int32 i = 0; i < NumMaterials; ++i)
		{
			UMaterialInstanceDynamic* Material = Cast<UMaterialInstanceDynamic>(MeshComponent->GetMaterial(i));
			if (!Material)
			{
				continue;
			}

			Material->SetScalarParameterValue(MainViewComponentsMaterialBlendParameterName, InFloat);
		}
	}
}

void ALobbyTemplate::OnMainViewComponentsMaterialBlendEnd()
{
 	MainViewComponentsMaterialBlendTimerHandle.Invalidate();
	SetTimerOrExecuteDelegate(CameraBlendingTimerHandle, FTimerDelegate::CreateUObject(this, &ALobbyTemplate::OnCameraBlendingFinished), CameraBlendParams.BlendTime);

	SetLobbyViewTarget(PendingLobbyTemplateCameraType);
}
