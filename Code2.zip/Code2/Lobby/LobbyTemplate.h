// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Animation/SkeletalMeshActor.h"
#include "CineCameraComponent.h"
#include "CMS_gen.h"
#include "CoreMinimal.h"
#include "Components/SkeletalMeshComponent.h"
#include "Components/TimelineComponent.h"
#include "GameFramework/Actor.h"
#include "Resource/GameResource.h"
#include "LobbyTemplate.generated.h"

class ACineCameraActor;
class UAnimSequenceBase;
class UCapsuleComponent;
struct FCharacterType;
struct FCharacterId;

UENUM()
enum class ELobbyTemplateCamera : uint8
{
	Main,
	Panorama,
	Max,
};

UCLASS(meta = (BlueprintSpawnableComponent))
class Q6_API ULobbyCameraComponent : public UCineCameraComponent
{
	GENERATED_BODY()

public:
	ULobbyCameraComponent();

	ELobbyTemplateCamera GetLobbyTemplateCameraType() const { return LobbyTemplateCameraType; }

private:
	UPROPERTY(EditAnywhere)
	ELobbyTemplateCamera LobbyTemplateCameraType;
};

UCLASS()
class ULobbyAnimationHelper : public UObject
{
	GENERATED_BODY()

public:
	void InitAnimations(const FLobbyAnimationInfo& InAnimInfo);

	void PlayAnimAsMontage(UUnitAnimInstance* AnimInst, UAnimSequenceBase* Anim, FOnMontageBlendingOutStarted& Delegate, bool bLoop, float BlendInTime, float BlendOutTime);
	void OnMontageBlendingOut(UUnitAnimInstance* AnimInst, UAnimMontage* Montage, bool bInterrupted);

	UPROPERTY(Transient)
	UAnimSequenceBase* WelcomeAnimation;

	UPROPERTY(Transient)
	TArray<UAnimSequenceBase*> IdleAnimations;

	UPROPERTY(Transient)
	TArray<UAnimSequenceBase*> InteractionAnimations;

	bool bPlayingOneShotAnim;
};

UCLASS(meta = (BlueprintSpawnableComponent))
class Q6_API ULobbyCharacterComponent : public USkeletalMeshComponent
{
	GENERATED_BODY()

public:
	ULobbyCharacterComponent(const FObjectInitializer& ObjectInitializer);

	void InitLobbyCharacter(const FCharacterType& InCharacterType, const FLobbyAnimationInfo& InAnimInfo);

	int32 GetIndex() const { return Index; }
	FCharacterType GetCharacterType() const { return CharacterType; }

	void PlayWelcomeAnimation();
	void ClearIntermediateState();

	void OnTouched();

private:
	void InitAnimations(const FLobbyAnimationInfo& InAnimInfo);

	void PlayAnimAsMontage(UAnimSequenceBase* Anim, bool bLoop, float BlendInTime = 0.f, float BlendOutTime = 0.f);
	void OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted);

private:
	UPROPERTY(EditAnywhere)
	int32 Index;

	UPROPERTY(Transient)
	UCapsuleComponent* CapsuleComponent;

	UPROPERTY(Transient)
	ULobbyAnimationHelper* AnimationHelper;

	FCharacterType CharacterType;
};

UCLASS()
class Q6_API ULobbyTitleWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	ULobbyTitleWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	
	void SetShow(bool bInShow);
	
private:
	UPROPERTY(Transient)
	UWidgetAnimation* ShowAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HideAnim;
};

UCLASS()
class Q6_API ALobbyTemplate : public AActor
{
	GENERATED_BODY()
	
public:	
	ALobbyTemplate(const FObjectInitializer& ObjectInitializer);

public:
	void InitTemplate(const TArray<FLobbyTemplateCharacterSlotInfo>& InSlotInfos);
	void InitTemplateCameras();
	void InitView(bool bShowPanoramaIntro);
	void InitMainViewComponentsMaterialBlend();
	void InitTitleWidget();

	virtual void Tick(float DeltaTime) override;
	virtual void Destroyed() override;

	bool HasDirectionalLightComponent() const { return bHasDirectionalLight; }

	void SetToViewTarget(class APlayerController* PC);

	void SetCharacters(const TArray<FCharacterId>& InCharacterIds);
	void SetCharactersVisible(bool bVisible);
	void PlayCharacterWelcomeAnimation(int32 InIndex);
	void ClearCharactersIntermediateState();

	void ResetView();
	void ResetCamera();
	void RotateCameraTo(int32 CharacterSlotIndex);

	void InputDragged(const FVector2D& DeltaLocation, float ScrollVelocity);

	bool IsWidgetShowingView() const;

private:
	ACineCameraActor* SpawnCloneCineCameraActor(UCineCameraComponent* InCineCameraComponent);

	void SetCharacter(int32 Index, FCharacterType InCharacterType);
	bool IsExclusiveCharacter(int32 Index, FCharacterType CharacterType, FLobbyAnimationInfo& OutAnimInfo);

	void RotateCamera(float ScrollVelocity);

	AActor* GetLobbyViewTarget(ELobbyTemplateCamera InType) const;
	void ChangeLobbyViewTarget(ELobbyTemplateCamera InType);
	void SetLobbyViewTarget(ELobbyTemplateCamera InType);
	void ToggleLobbyViewTarget();

	void SetEnableMainViewPostProcessBlend(bool bInEnable);
	void SetTitleWidgetVisible(bool bInVisible);

	void SetTimerOrExecuteDelegate(FTimerHandle& InOutHandle, FTimerDelegate InDelegate, float InTime);

	void OnPanoramaIntroEnd();
	void OnCameraBlendingFinished();

	void OnMainViewComponentsMaterialBlend(float InFloat);
	void OnMainViewComponentsMaterialBlendEnd();

	UPROPERTY(EditDefaultsOnly)
	float CameraSwipeAngle;

	UPROPERTY(EditDefaultsOnly)
	float PanoramaIntroTime;

	UPROPERTY(EditDefaultsOnly)
	FViewTargetTransitionParams CameraBlendParams;

	UPROPERTY(EditDefaultsOnly)
	UCurveFloat* CameraBlendCurve;

	UPROPERTY(EditDefaultsOnly)
	float MainViewComponentsMaterialBlendTime;

	UPROPERTY(EditDefaultsOnly)
	FName MainViewComponentsMaterialBlendParameterName;

	UPROPERTY(EditDefaultsOnly)
	UCurveFloat* MainViewComponentsMaterialBlendCurve;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<ULobbyTitleWidget> LobbyTitleWidgetClass;

	UPROPERTY(Transient)
	ULobbyTitleWidget* LobbyTitleWidget;

	UPROPERTY(Transient)
	ACineCameraActor* MainCamera;

	UPROPERTY(Transient)
	ACineCameraActor* PanoramaCamera;

	UPROPERTY(Transient)
	TArray<USceneComponent*> MainViewComponents;

	UPROPERTY(Transient)
	TArray<ULobbyCharacterComponent*> LobbyCharacters;

	UPROPERTY(Transient)
	TArray<FLobbyTemplateCharacterSlotInfo> SlotInfos;

	ELobbyTemplateCamera LobbyTemplateCameraType;
	ELobbyTemplateCamera PendingLobbyTemplateCameraType;

	FTimeline MainViewComponentsMaterialBlendTimeline;

	FTimerHandle PanoramaIntroTimerHandle;
	FTimerHandle CameraBlendingTimerHandle;
	FTimerHandle MainViewComponentsMaterialBlendTimerHandle;

	float DefaultCameraYaw;
	float CameraYawMin;
	float CameraYawMax;
	bool bSwipable;

	bool bHasDirectionalLight;
};
