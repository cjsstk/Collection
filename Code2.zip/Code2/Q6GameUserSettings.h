// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "GameFramework/GameUserSettings.h"
#include "CMSType_gen.h"
#include "Q6GameUserSettings.generated.h"

USTRUCT()
struct FGameSettingData
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	int32 GraphicQuality = 2;

	UPROPERTY()
	int32 MSAAQuality = 2;

	UPROPERTY()
	int32 OutlineQuality = 2;

	UPROPERTY()
	int32 FrameRate = 1;

	UPROPERTY()
	int32 ShowUltimate = 0;

	UPROPERTY()
	float BGMVolume = 1.0f;

	UPROPERTY()
	float EffectVolume = 1.0f;

	UPROPERTY()
	float VoiceVolume = 1.0f;

	UPROPERTY()
	float UIVolume = 1.0f;

	UPROPERTY()
	float TextSpeed = 0.5f;

	UPROPERTY()
	float AutoTextSpeed = 0.5f;
};

USTRUCT()
struct FGameNoticeData
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	bool ReceiveNotice = true;

};

class UQ6GameInstance;

UCLASS(config=Q6GameUserSettings)
class Q6_API UQ6GameUserSettings : public UGameUserSettings
{
	GENERATED_BODY()

public:
	explicit UQ6GameUserSettings(const FObjectInitializer& ObjectInitializer);

	void InitSettings();

	void SetIdString(const FString& InIdString);
	void SetMD5Password(const FString& InMD5Password);

	const FString& GetIdString() const { return IdString; }
	const FString& GetMD5Password() const { return MD5Password; }

	void SetGameData(const FGameSettingData& SettingData, const FGameNoticeData& NoticeData);
	void ApplyGameData(const FGameSettingData& SettingData,
					   const FGameNoticeData& NoticeData,
					   bool bSkipSound = false);

	void ApplySoundSettings();

	const FGameSettingData& GetGameSettingData() { return GameSettingData; }
	const FGameNoticeData& GetGameNoticeData() { return GameNoticeData; }

	static UQ6GameUserSettings* Get();
	static UQ6GameUserSettings* GetSafe();

private:
	void OnDevLimitFrame(const TArray<FString>& Args);
	void UpdateGraphicQuality(int32 GraphicQuality);
	void UpdateMSAAQuality(int32 MSAAQuality);
	void UpdateOutlineQuality(int32 OutlineQuality);
	void UpdateFrameRate(int32 FrameRate);
	void UpdateSoundSettings(const FGameSettingData& SettingData);

	UPROPERTY(config)
	FString IdString;

	UPROPERTY(config)
	FString MD5Password;

	UPROPERTY(config)
	FGameSettingData GameSettingData;

	UPROPERTY(config)
	FGameNoticeData GameNoticeData;
};
