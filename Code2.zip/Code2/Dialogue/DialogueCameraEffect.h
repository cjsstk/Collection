// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "DialogueCameraEffect.generated.h"

class APostProcessVolume;
class UDialogueWidget;
class UCameraShake;
class UMaterial;
class UMaterialInstanceDynamic;
class UParticleSystem;
class UParticleSystemComponent;

UENUM()
enum class EDialogueCameraEffect : uint8
{
	None,
	PostProcess,
	WidgetAnimation,
	CameraShake,
	Particle,
	Blendable
};

UCLASS()
class UDialogueCameraEffect : public UObject
{
	GENERATED_BODY()

public:
	virtual void Restore() {}
	virtual EDialogueCameraEffect GetType() const { check(0); return EDialogueCameraEffect::None; }

	static bool IsPreset(EDialogueCameraEffect Type);
	static bool IsWorkingInFastForwarding(EDialogueCameraEffect Type);
};

UCLASS()
class UDialoguePostProcess : public UDialogueCameraEffect
{
	GENERATED_BODY()

public:
	void Apply(APostProcessVolume* InVolume, const FLinearColor& InTint, float InSaturation);

	virtual void Restore() override;
	virtual EDialogueCameraEffect GetType() const override { return EDialogueCameraEffect::PostProcess; }

private:
	UPROPERTY(Transient)
	APostProcessVolume* Volume;

	FLinearColor RestoreTint;
	float RestoreSaturation;
};

UCLASS()
class UDialogueWidgetAnim : public UDialogueCameraEffect
{
	GENERATED_BODY()

public:
	void Apply(UDialogueWidget* InWidget, const FName& InAnim, const FName& InRestoreAnim, int32 NumLoops, float Speed);

	virtual void Restore() override;
	virtual EDialogueCameraEffect GetType() const override { return EDialogueCameraEffect::WidgetAnimation; }

private:
	UPROPERTY(Transient)
	UDialogueWidget* Widget;

	FName AnimName;
	FName RestoreAnimName;
};

UCLASS()
class UDialougeCameraShake : public UDialogueCameraEffect
{
	GENERATED_BODY()

public:
	void Apply(TSubclassOf<UCameraShake> InCameraShake);

	virtual void Restore() override;
	virtual EDialogueCameraEffect GetType() const override { return EDialogueCameraEffect::CameraShake; }

private:
	TSubclassOf<UCameraShake> CameraShake;
};

UCLASS()
class UDialougeParticle : public UDialogueCameraEffect
{
	GENERATED_BODY()

public:
	void Apply(UParticleSystem* InParticle);

	virtual void Restore() override;
	virtual EDialogueCameraEffect GetType() const override { return EDialogueCameraEffect::Particle; }

private:
	UPROPERTY(Transient)
	UParticleSystemComponent* ParticleComponent;
};

UCLASS()
class UDialougeBlendable : public UDialogueCameraEffect
{
	GENERATED_BODY()

public:
	void Apply(APostProcessVolume* InVolume, UMaterialInstance* InMaterial, const FLinearColor& BaseColor, const FLinearColor& SecondColor);

	virtual void Restore() override;
	virtual EDialogueCameraEffect GetType() const override { return EDialogueCameraEffect::Blendable; }

private:
	void SetColorParameter(FName ParameterName, const FLinearColor& Value);

private:
	UPROPERTY(Transient)
	APostProcessVolume* Volume;

	UPROPERTY(Transient)
	UMaterialInstanceDynamic* Instance;
};
