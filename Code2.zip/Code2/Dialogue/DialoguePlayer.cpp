// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "DialoguePlayer.h"

#include "CharacterIntroductionWidget.h"
#include "CineCameraActor.h"
#include "CineCameraComponent.h"
#include "CombatWidgets.h"
#include "DialogueCameraEffect.h"
#include "DialogueWidget.h"
#include "Engine/Q6DirectionalLight.h"
#include "Engine/StaticMeshActor.h"
#include "EpisodeTitleWidget.h"
#include "GameAssetCache.h"
#include "GameResource.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "HUDStore/EventManager.h"
#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"
#include "LevelUtil.h"
#include "LobbyHUD.h"
#include "LobbyPlayerController.h"
#include "Misc/FrameRate.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6LobbyState.h"
#include "Q6SaveGame.h"
#include "Q6SoundPlayer.h"
#include "Q6Util.h"
#include "SagaManager.h"
#include "Sections/MovieSceneEventSection.h"
#include "SpecialManager.h"
#include "StageTitleWidget.h"
#include "Tracks/MovieSceneEventTrack.h"
#include "TrainingCenterManager.h"
#include "UIStateManager.h"
#include "UnitAnimInstance.h"

const float DEFAULT_FOCAL_LENGTH = 50.0f;
const float ZOOM_IN_FORCAL_LENGTH = 80.0f;
const float ZOOM_OUT_FORCAL_LENGTH = 30.0f;
const float BLEND_TIME = 0.25f;

static TAutoConsoleVariable<int32> CVarQ6DialogueRecordCount(
	TEXT("q6.dialogueRecordCount"),
	1,
	TEXT("dialogue recording every [count]"),
	ECVF_Default);

bool FDialogueSpeaker::Initialize()
{
	if (!SkeletalMeshActor)
	{
		Q6JsonLogZagal(Warning, "FDialogueSpeaker - No SkeletalMeshActor");
		return false;
	}

	Mesh = SkeletalMeshActor->GetSkeletalMeshComponent();
	if (!Mesh)
	{
		Q6JsonLogZagal(Warning, "FDialogueSpeaker - No SkeletalMeshComponent");
		return false;
	}

	InitialTransform = SkeletalMeshActor->GetActorTransform();

	Reset();

	return true;
}

void FDialogueSpeaker::Reset()
{
	SkeletalMeshActor->SetActorTransform(InitialTransform);
	Mesh->SetSkeletalMesh(nullptr);
	Mesh->EmptyOverrideMaterials();

	BodyIdle = nullptr;
	FaceIdle = nullptr;

	ResetPrevAssets();

	ModelType = 0;
	bIdleBlend = true;
}

void FDialogueSpeaker::SetModel(int32 InModelType)
{
	if (!InModelType)
	{
		SkeletalMeshActor->SetActorHiddenInGame(true);
	}
	else
	{
		if (ModelType != InModelType)
		{
			const FUnitModelAssetRow& Row = GetGameResource().GetUnitModelAssetRow(InModelType);

			Mesh->SetAnimInstanceClass(nullptr);
			ULevelUtil::LoadSkeletalMesh(Mesh, Row, InModelType, true, true);

			if (!Row.AnimInstanceClass.IsNull())
			{
				Mesh->SetAnimInstanceClass(Row.AnimInstanceClass.LoadSynchronous());
				Mesh->SetAnimationMode(EAnimationMode::AnimationBlueprint);

				if (UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(Mesh->GetAnimInstance()))
				{
					AnimInst->SetDialogueMode(true);
				}
			}

			ResetPrevAssets();
		}

		SkeletalMeshActor->SetActorHiddenInGame(false);
	}

	ModelType = InModelType;
}

void FDialogueSpeaker::PlayAnimation(const FDialogueAnimAssetRow* Row)
{
	if (!Row)
	{
		return;
	}

	UAnimInstance* AnimInst = Mesh->GetAnimInstance();
	if (!AnimInst)
	{
		return;
	}

	UAnimSequenceBase* BodyAsset = Row->Animation.IsNull() ? nullptr : Row->Animation.LoadSynchronous();
	BodyIdle = Row->IdleAnimation.IsNull() ? nullptr : Row->IdleAnimation.LoadSynchronous();
	FaceIdle = Row->FaceIdleAnimation.IsNull() ? nullptr : Row->FaceIdleAnimation.LoadSynchronous();
	bIdleBlend = Row->bIdleBlend;

	if (BodyAsset)
	{
		float BlendingTime = bIdleBlend ? BLEND_TIME : 0.0f;

		UAnimMontage* Montage = PlayDefaultSlot(BodyAsset, false, false, 0.f, BlendingTime);
		if (Montage)
		{
			FOnMontageBlendingOutStarted Delegate;
			Delegate.BindRaw(this, &FDialogueSpeaker::OnMontageBlendingOut);
			AnimInst->Montage_SetBlendingOutDelegate(Delegate, Montage);
		}
	}
	else
	{
		PlayDefaultSlot(BodyIdle, true, false);
		PlayFaceSlot(FaceIdle, true, false);
	}

	UpdateAnimationImmediately();
}

void FDialogueSpeaker::PlayIdleImmediately()
{
 	PlayDefaultSlot(BodyIdle, true, true);
 	PlayFaceSlot(FaceIdle, true, true);

	UpdateAnimationImmediately();
}

void FDialogueSpeaker::UpdateAnimationImmediately()
{
	if (UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(Mesh->GetAnimInstance()))
	{
		AnimInst->UpdateAnimation(0.0f, false);

		Mesh->RefreshBoneTransforms();
		Mesh->RefreshSlaveComponents();
		Mesh->UpdateComponentToWorld();
	}
}

void FDialogueSpeaker::ResetPrevAssets()
{
	PrevDefaultAsset = nullptr;
	PrevFaceAsset = nullptr;
}

UAnimMontage* FDialogueSpeaker::PlayDefaultSlot(UAnimSequenceBase* Asset, bool bLoop, bool bForce, float BlendInTime /* = 0.f */, float BlendOutTime /* = 0.f */)
{
	if (!bForce && bLoop && PrevDefaultAsset == Asset)
	{
		return nullptr;
	}

	PrevDefaultAsset = Asset;

	if (UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(Mesh->GetAnimInstance()))
	{
		static FName DefaultSlot(TEXT("DefaultSlot"));

		UAnimMontage* Montage = AnimInst->PlaySlotAnimAsMontage(Asset, DefaultSlot, true, BlendInTime, BlendOutTime);
		if (Montage && bLoop)
		{
			AnimInst->Montage_SetNextSection(TEXT("Default"), TEXT("Default"), Montage);
		}

		return Montage;
	}

	return nullptr;
}

UAnimMontage* FDialogueSpeaker::PlayFaceSlot(UAnimSequenceBase* Asset, bool bLoop, bool bForce, float BlendInTime /* = 0.f */, float BlendOutTime /* = 0.f */)
{
	if (!bForce && bLoop && PrevFaceAsset == Asset)
	{
		return nullptr;
	}

	PrevFaceAsset = Asset;

	if (UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(Mesh->GetAnimInstance()))
	{
		static FName FaceSlot(TEXT("FaceSlot"));

		UAnimMontage* Montage = AnimInst->PlaySlotAnimAsMontage(Asset, FaceSlot, false, BlendInTime, BlendOutTime);
		if (Montage && bLoop)
		{
			AnimInst->Montage_SetNextSection(TEXT("Default"), TEXT("Default"), Montage);
		}

		return Montage;
	}

	return nullptr;
}

void FDialogueSpeaker::OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted)
{
	if (Montage && !bInterrupted)
	{
		float BlendingTime = bIdleBlend ? BLEND_TIME : 0.0f;
		PlayDefaultSlot(BodyIdle, true, false, BlendingTime, 0.f);
		PlayFaceSlot(FaceIdle, true, false, BlendingTime, BlendingTime);
	}
}

ADialoguePlayer::ADialoguePlayer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bInitialized(false)
	, bContinue(false)
	, DialogueType(EDialogueType::Saga)
	, bPrologue(false)
	, bReplay(false)
	, StartId(0)
	, EndId(0)
	, DialogueId(0)
	, DialoguePlayingCount(0)
{
	PrimaryActorTick.bCanEverTick = false;
}

void ADialoguePlayer::Initialize()
{
	if (!SagaEpisodeTable || !SagaStageTable)
	{
		Q6JsonLogZagal(Warning, "No saga dialogue table");
		return;
	}

	if (!DailyEpisodeTable || !DailyStageTable)
	{
		Q6JsonLogZagal(Warning, "No daily dialogue table");
		return;
	}

	if (!TrainingEpisodeTable || !TrainingStageTable)
	{
		Q6JsonLogZagal(Warning, "No training dialogue table");
		return;
	}

	if (!VacationTemplete)
	{
		Q6JsonLogZagal(Warning, "No vacation templete table");
		return;
	}

	if (!DialogueAnimAssetTable)
	{
		Q6JsonLogZagal(Warning, "No DialogueAnimAssetTable");
		return;
	}

	if (!DialogueCameraEffectTable)
	{
		Q6JsonLogZagal(Warning, "No DialogueCameraEffectTable");
		return;
	}

	if (!PostProcessVolume)
	{
		Q6JsonLogZagal(Warning, "No PostProcessVolume");
		return;
	}

	if (!DialogueBGAssetTable)
	{
		Q6JsonLogZagal(Warning, "No DialogueBGAssetTable");
		return;
	}

	if (!DialogueCameraAnimTable)
	{
		Q6JsonLogZagal(Warning, "No DialogueCameraAnimTable");
		return;
	}

	if (!MainDirectionalLight)
	{
		Q6JsonLogSunny(Warning, "No MainDirectionalLight");
		return;
	}

	if (!BGActor)
	{
		Q6JsonLogZagal(Warning, "No BGActor");
		return;
	}

	for (FDialogueSpeaker& Speaker : Speakers)
	{
		if (!Speaker.Initialize())
		{
			return;
		}
	}

	if (StageTitleClass.IsNull())
	{
		Q6JsonLogZagal(Warning, "No StageTitleClass");
		return;
	}

	StageTitleWidget = CreateWidget<UStageTitleWidget>(GetLocalPlayerController(this), StageTitleClass.LoadSynchronous());
	if (!StageTitleWidget)
	{
		Q6JsonLogZagal(Warning, "Failed to create StageTitleWidget");
		return;
	}

	StageTitleWidget->AddToViewport(ZORDER_STAGE_TITLE);
	StageTitleWidget->OnTitleEnd.BindUObject(this, &ADialoguePlayer::OnStageTitleEnd);
	StageTitleWidget->SetVisibility(ESlateVisibility::Collapsed);

	DefaultCameraXform[0] = NoneCamera->GetActorTransform();
	DefaultCameraXform[1] = Speaker1Camera->GetActorTransform();
	DefaultCameraXform[2] = Speaker2Camera->GetActorTransform();
	DefaultCameraXform[3] = SpeakersCamera->GetActorTransform();

	bInitialized = true;
}

bool ADialoguePlayer::IsPlayableSaga(FSagaType InSagaType)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InSagaType);

	FString TypeStr;

	TypeStr = FString::Printf(TEXT("%d"), SagaRow.Episode);
	if (!SagaEpisodeTable->FindRow<FDialogueEpisodeRow>(FName(*TypeStr), TypeStr, false))
	{
		return false;
	}

	TypeStr = FString::Printf(TEXT("%d-%d-0"), SagaRow.Episode, SagaRow.Stage);
	if (!SagaStageTable->FindRow<FDialogueStageRow>(FName(*TypeStr), TypeStr, false))
	{
		return false;
	}

	return true;
}

const FDialogueEpisodeRow* ADialoguePlayer::GetEpisodeRow() const
{
	FString TypeStr;

	switch (DialogueType)
	{
		case EDialogueType::Saga:
		case EDialogueType::Special:
		case EDialogueType::Raid:
		case EDialogueType::Event:
		case EDialogueType::MultiSide:
			TypeStr = FString::Printf(TEXT("%d"), Episode);
			return SagaEpisodeTable->FindRow<FDialogueEpisodeRow>(FName(*TypeStr), TypeStr, false);
		case EDialogueType::Daily:
			TypeStr = FString::Printf(TEXT("%d"), (int32)DayOfWeek);
			return DailyEpisodeTable->FindRow<FDialogueEpisodeRow>(FName(*TypeStr), TypeStr, false);
		case EDialogueType::Training:
			TypeStr = FString::Printf(TEXT("%d"), TrainingCenterType.x);
			return TrainingEpisodeTable->FindRow<FDialogueEpisodeRow>(FName(*TypeStr), TypeStr, false);
		case EDialogueType::Vacation:
			return nullptr;
	}

	Q6JsonLogZagal(Warning, "Unknown EpisodeRow",
		Q6KV("Type", ENUM_TO_STRING(EDialogueType, DialogueType)),
		Q6KV("Key", TypeStr));

	return nullptr;
}

const FDialogueStageRow* ADialoguePlayer::GetStageRow() const
{
	FString TypeStr;

	switch (DialogueType)
	{
		case EDialogueType::Saga:
		case EDialogueType::Special:
		case EDialogueType::Raid:
		case EDialogueType::Event:
		case EDialogueType::MultiSide:
			TypeStr = FString::Printf(TEXT("%d-%d-%d"), Episode, Stage, bPrologue ? 0 : 1);
			return SagaStageTable->FindRow<FDialogueStageRow>(FName(*TypeStr), TypeStr, false);
		case EDialogueType::Daily:
			TypeStr = FString::Printf(TEXT("%d"), (int32)DayOfWeek);
			return DailyStageTable->FindRow<FDialogueStageRow>(FName(*TypeStr), TypeStr, false);
		case EDialogueType::Training:
			TypeStr = FString::Printf(TEXT("%d-%d"), TrainingCenterType.x, bPrologue ? 0 : 1);
			return TrainingStageTable->FindRow<FDialogueStageRow>(FName(*TypeStr), TypeStr, false);
		case EDialogueType::Vacation:
			return nullptr;
	}

	Q6JsonLogZagal(Warning, "Unknown StageRow",
		Q6KV("Type", ENUM_TO_STRING(EDialogueType, DialogueType)),
		Q6KV("Key", TypeStr));

	return nullptr;
}

FText ADialoguePlayer::GetStageSummaryText() const
{
	FString TypeStr;

	switch (DialogueType)
	{
		case EDialogueType::Saga:
		case EDialogueType::Special:
		case EDialogueType::Raid:
		case EDialogueType::Event:
		case EDialogueType::MultiSide:
			TypeStr = FString::Printf(TEXT("%d-%d-%d"), Episode, Stage, bPrologue ? 0 : 1);
			return Q6Util::GetLocalizedText("SagaStageSummary", TypeStr);
		case EDialogueType::Daily:
			TypeStr = FString::Printf(TEXT("%d"), (int32)DayOfWeek);
			return Q6Util::GetLocalizedText("DailyStageSummary", TypeStr);
		case EDialogueType::Training:
			TypeStr = FString::Printf(TEXT("%d-%d"), TrainingCenterType.x, bPrologue ? 0 : 1);
			return Q6Util::GetLocalizedText("TrainingStageSummary", TypeStr);
		case EDialogueType::Vacation:
			return FText::GetEmpty();
	}

	Q6JsonLogSunny(Warning, "Unknown StageSummaryText",
		Q6KV("Type", ENUM_TO_STRING(EDialogueType, DialogueType)),
		Q6KV("Key", TypeStr));

	return FText::GetEmpty();
}

const FCMSDialogueRow& ADialoguePlayer::GetDialogueRow() const
{
	return GetCMS()->GetDialogueRowOrDummy(DialogueTable, FDialogueType(DialogueId));
}

void ADialoguePlayer::ResetDialogue()
{
	bContinue = false;
	DialogueType = EDialogueType::None;
	bPrologue = true;
	bReplay = false;
	SagaType = SagaTypeInvalid;
	Episode = -1;
	Stage = 0;
	DayOfWeek = EDayOfWeekType::Max;
	TrainingCenterType = TrainingCenterTypeInvalid;
	VacationResult = FVacationResult();
	EventContentType = EventContentTypeInvalid;
}

bool ADialoguePlayer::InitDialogue()
{
	const FDialogueEpisodeRow* EpisodeRow = GetEpisodeRow();
	if (!EpisodeRow)
	{
		return false;
	}

	const FDialogueStageRow* StageRow = GetStageRow();
	if (!StageRow)
	{
		return false;
	}

	DialogueTable = EpisodeRow->DialogueTable.LoadSynchronous();

	DialogueId = StartId = StageRow->StartId;
	EndId = StageRow->EndId ? StageRow->EndId : StartId;

	Summary = GetStageSummaryText();

	CacheAssets(StageRow);

	InitSequenceAssets(StageRow);
	InitCharacterIntroductionInfos(StageRow);

	if (!bContinue)
	{
		InitTitleWidgets(EpisodeRow);
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	// If story like stage type, wait for story stage clear resp
	if (!IsStoryLikeStageType(SagaRow.StageType))
	{
		InitDialogueRecording();
	}

	return true;
}

void ADialoguePlayer::CacheAssets(const FDialogueStageRow* StageRow)
{
	TArray<FSoftObjectPath> Paths;

	if (!StageRow->Main.IsNull())
	{
		Paths.AddUnique(StageRow->Main.GetUniqueID());
	}

	if (StageRow->Stories.Num() > 0)
	{
		for (const FStorySequence& Story : StageRow->Stories)
		{
			if (!Story.Sequence.IsNull())
			{
				Paths.AddUnique(Story.Sequence.GetUniqueID());
			}
			else
			{
				Q6JsonLogZagal(Warning, "Story Sequence is null", Q6KV("DialogueId", Story.DialogueId));
			}
		}
	}

	FAssetCacheOptions CacheOptions;
	CacheOptions.bBlocking = true;
	CacheOptions.Priority = 0;

	AssetCache = GetGameResource().GetCacheManager()->CacheDialogue(StageRow->CacheModels, Paths, CacheOptions);
}

void ADialoguePlayer::InitSequenceAssets(const FDialogueStageRow* StageRow)
{
	MainSequence = nullptr;
	StorySequences.Empty();

	if (!StageRow->Main.IsNull())
	{
		MainSequence = StageRow->Main.LoadSynchronous();
	}

	for (const FStorySequence& Story : StageRow->Stories)
	{
		if (Story.Sequence.IsNull())
		{
			continue;
		}

		if (ULevelSequence* Sequence = Story.Sequence.LoadSynchronous())
		{
			StorySequences.FindOrAdd(Story.DialogueId, Sequence);
		}
		else
		{
			Q6JsonLogZagal(Warning, "Failed to load", Q6KV("Seqeunce", *Story.Sequence.GetAssetName()));
		}
	}
}

void ADialoguePlayer::InitCharacterIntroductionInfos(const FDialogueStageRow* StageRow)
{
	CharacterIntroductionInfos.Empty();

	for (const FCharacterIntroduction& Introduction : StageRow->CharacterIntroductions)
	{
		if (Introduction.Info.CharacterName.IsEmpty())
		{
			continue;
		}

		CharacterIntroductionInfos.FindOrAdd(Introduction.DialogueId, Introduction.Info);
	}
}

bool ADialoguePlayer::InitVacationDialogue()
{
	const int32 NumQuestions = 3;
	const int32 NumLines = 5;
	const int32 NumTotalLines = NumQuestions * NumLines;

	TArray<FCMSDialogueRow*> RowArray;
	VacationTemplete->GetAllRows(TEXT("InitVacation"), RowArray);

	if (RowArray.Num() != NumTotalLines)
	{
		return false;
	}

	int32 ModelType = GetCMS()->GetUnitRowOrDummy(VacationResult.Bond.CharacterType).Model;

	for (FCMSDialogueRow* Row : RowArray)
	{
		Row->Speaker1ModelType = ModelType;
	}

	const int32 IdOK = 5;
	const int32 IdNo = 4;
	const int32 NumOK = (int32)VacationResult.ResultType;

	TArray<int32> Answers;
	Answers.SetNumUninitialized(NumQuestions);

	for (int32 i = 0; i < NumQuestions; i++)
	{
		Answers[i] = i < NumOK ? IdOK : IdNo;
	}

	if (Answers[0] != Answers.Last())
	{
		Q6Util::ShuffleArray(Answers);
	}

	for (int32 i = 0; i < NumQuestions; i++)
	{
		int32 BaseIndex = NumLines * i;
		int32 Answer = Answers[i];

		RowArray[BaseIndex + 1]->NextDialogueId = BaseIndex + Answer;
		RowArray[BaseIndex + 2]->NextDialogueId = BaseIndex + Answer;
	}

	DialogueTable = VacationTemplete;

	DialogueId = StartId = 1;
	EndId = NumTotalLines;
	Summary = FText::GetEmpty();

	EpisodeTitleWidget = nullptr;
	StageTitleWidget->SetVisibility(ESlateVisibility::Collapsed);

	return true;
}

bool ADialoguePlayer::IsNeedStageTitle() const
{
	if (bContinue)
	{
		return false;
	}

	if (DialogueType == EDialogueType::Saga ||
		DialogueType == EDialogueType::Event ||
		DialogueType == EDialogueType::MultiSide)
	{
		return bPrologue;
	}

	return false;
}

bool ADialoguePlayer::IsVacationType() const
{
	return (DialogueType == EDialogueType::Vacation);
}

bool ADialoguePlayer::IsSequenceMode() const
{
	return (MainSequence != nullptr);
}

bool ADialoguePlayer::IsAutoPlaying() const
{
	return DialogueWidget->IsAutoPlaying();
}

bool ADialoguePlayer::IsFastForwarding() const
{
	return DialogueWidget->IsFastForwarding();
}

void ADialoguePlayer::InitTitleWidgets(const FDialogueEpisodeRow* EpisodeRow)
{
	bool bNeedEpisodeTitle = false;

	if (IsNeedStageTitle())
	{
		const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
		bNeedEpisodeTitle = (SagaRow.Stage == 1 && SagaRow.SubStage == 0);

		StageTitleWidget->SetVisibility(ESlateVisibility::Visible);
		StageTitleWidget->SetStageTitle(SagaRow);
	}
	else
	{
		StageTitleWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	EpisodeTitleWidget = nullptr;

	if (bNeedEpisodeTitle && !EpisodeRow->TitleWidgetClass.IsNull())
	{
		EpisodeTitleWidget = CreateWidget<UEpisodeTitleWidget>(GetLocalPlayerController(this), EpisodeRow->TitleWidgetClass.LoadSynchronous());
		if (EpisodeTitleWidget)
		{
			EpisodeTitleWidget->AddToViewport(ZORDER_EPISODE_TITLE);
			EpisodeTitleWidget->OnTitleEnd.BindUObject(this, &ADialoguePlayer::OnEpisodeTitleEnd);
			EpisodeTitleWidget->SetVisibility(ESlateVisibility::Visible);

			if (DialogueType == EDialogueType::Saga)
			{
				EpisodeTitleWidget->SetEpisodeTitle(Episode);
			}
			else if (DialogueType == EDialogueType::Event || DialogueType == EDialogueType::MultiSide)
			{
				EpisodeTitleWidget->SetEpisodeTitle(EpisodeRow->TitleText);
			}
		}
		else
		{
			Q6JsonLogZagal(Warning, "Failed to create EpisodeTitleWidget");
		}
	}
}

void ADialoguePlayer::PlaySaga(FSagaType InSagaType, bool bInPrologue, bool bInReplay, bool bInContinue)
{
	if (!bInitialized)
	{
		OnDialogueQuit(true);
		return;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InSagaType);
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogZagal(Warning, "PlaySaga - Invalid Saga");
		return;
	}

	bContinue = bInContinue;
	DialogueType = ConvertToDialogueType(SagaRow.ContentType);
	bPrologue = bInPrologue;
	bReplay = bInReplay;

	SagaType = InSagaType;
	Episode = SagaRow.Episode;
	Stage = SagaRow.Stage;

	PlayDialogue();
}

void ADialoguePlayer::PlayDaily(EDayOfWeekType InDayOfWeek, bool bInReplay, bool bInContinue)
{
	ResetDialogue();

	if (!bInitialized)
	{
		OnDialogueQuit(true);
		return;
	}

	bContinue = bInContinue;
	DialogueType = EDialogueType::Daily;
	bPrologue = true;
	bReplay = bInReplay;

	DayOfWeek = InDayOfWeek;

	PlayDialogue();
}

void ADialoguePlayer::PlayTraining(FTrainingCenterType InTrainingType, FSagaType InSagaType, bool bInPrologue, bool bInReplay, bool bInContinue)
{
	ResetDialogue();

	if (!bInitialized)
	{
		OnDialogueQuit(true);
		return;
	}

	bContinue = bInContinue;
	DialogueType = EDialogueType::Training;
	bPrologue = bInPrologue;
	bReplay = bInReplay;

	SagaType = InSagaType;
	TrainingCenterType = InTrainingType;

	PlayDialogue();
}

void ADialoguePlayer::PlayVacation(const FVacationResult& InResult)
{
	ResetDialogue();

	if (!bInitialized)
	{
		OnDialogueQuit(true);
		return;
	}

	bContinue = false;
	DialogueType = EDialogueType::Vacation;
	bPrologue = true;
	bReplay = false;

	VacationResult = InResult;

	PlayDialogue();
}

void ADialoguePlayer::PlayEvent(FEventContentType InEventContentType, FSagaType InSagaType, bool bInPrologue, bool bInReplay, bool bInContinue)
{
	ResetDialogue();

	if (!bInitialized)
	{
		OnDialogueQuit(true);
		return;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InSagaType);
	if (!IsEventContentType(SagaRow.ContentType))
	{
		Q6JsonLogRoze(Error, "ADialoguePlayer::PlayEvent - Not a event stage dialogue", Q6KV("SagaType", SagaType.x));
		return;
	}

	bContinue = bInContinue;
	DialogueType = ConvertToDialogueType(SagaRow.ContentType);
	bPrologue = bInPrologue;
	bReplay = bInReplay;

	SagaType = InSagaType;
	Episode = SagaRow.Episode;
	Stage = SagaRow.Stage;

	EventContentType = InEventContentType;

	PlayDialogue();
}

void ADialoguePlayer::PlayContinue(const FDialogueRecord& DialogueRecord, const FDialogueType PlayingDialogueType)
{
	ResetDialogue();

	// Init dialogue content

	if (DialogueRecord.DialogueType == EDialogueType::Daily
		&& DialogueRecord.DayOfWeek != EDayOfWeekType::Max)
	{
		PlayDaily(DialogueRecord.DayOfWeek, false, true);
	}
	else if (DialogueRecord.DialogueType == EDialogueType::Training)
	{
		if (DialogueRecord.TrainingCenterType == TrainingCenterTypeInvalid)
		{
			Q6JsonLogRoze(Error, "ADialoguePlayer::PlayContinue - Invalid TrainingCenterType");
			return;
		}

		PlayTraining(DialogueRecord.TrainingCenterType, DialogueRecord.SagaType, DialogueRecord.bPrologue, false, true);
	}
	else if (DialogueRecord.DialogueType == EDialogueType::Event
		|| DialogueRecord.DialogueType == EDialogueType::MultiSide)
	{
		if (DialogueRecord.EventContentType == EventContentTypeInvalid)
		{
			Q6JsonLogRoze(Error, "ADialoguePlayer::PlayContinue - Invalid EventContentType");
			return;
		}

		PlayEvent(DialogueRecord.EventContentType, DialogueRecord.SagaType, DialogueRecord.bPrologue, false, true);
	}
	else
	{
		if (DialogueRecord.SagaType == SagaTypeInvalid)
		{
			Q6JsonLogRoze(Error, "ADialoguePlayer::PlayContinue - Invalid SagaType");
			return;
		}

		PlaySaga(DialogueRecord.SagaType, DialogueRecord.bPrologue, false, true);
	}

	// Jump to dialogue id

	if (PlayingDialogueType != StartId)
	{
		DialogueWidget->OnDialogueStart();
	}

	GotoDialogue(PlayingDialogueType);
}

void ADialoguePlayer::GotoDialogue(int32 GotoId)
{
	if (FMath::IsWithinInclusive(GotoId, StartId, EndId))
	{
		FString BGName;
		FString BGMName;
		if (GotoId > StartId)
		{
			// Preset

			for (int32 i = GotoId - 1; i > StartId; --i)
			{
				DialogueId = i;
				const FCMSDialogueRow& Row = GetDialogueRow();
				if (BGName.IsEmpty() && !Row.BGMesh.IsEmpty())
				{
					BGName = Row.BGMesh;
				}

				if (BGName.IsEmpty() && !Row.BGM.IsEmpty())
				{
					BGMName = Row.BGM;
				}

				if (!BGName.IsEmpty() && !BGMName.IsEmpty())
				{
					break;
				}
			}

			// Set BG and BGM

			SetBackground(BGName);
			GetSoundPlayer().PlayMainBGM(FName(*BGMName));
		}

		DialogueId = GotoId;

		ShowNextDialogue();
	}
}

void ADialoguePlayer::PlayDialogue()
{
	bool bInitOk = false;
	if (IsVacationType())
	{
		bInitOk = InitVacationDialogue();
	}
	else
	{
		bInitOk = InitDialogue();
	}

	if (!bInitOk)
	{
		OnDialogueQuit(true);
		return;
	}

	DialoguePlayingCount = 0;

	DialogueWidget = CastChecked<UDialogueWidget>(GetCheckedLobbyHUD(this)->GetHUDWidget(EHUDWidgetType::Dialogue));
	DialogueWidget->BanChoiceDelegate.BindUObject(this, &ADialoguePlayer::OnBanChoice);
	DialogueWidget->SkipConfirmedDelegate.BindUObject(this, &ADialoguePlayer::OnDialogueSkip);
	DialogueWidget->BottomSkipDelegate.BindUObject(this, &ADialoguePlayer::OnDialogueBottomSkip);
	DialogueWidget->ShowNextDialogueDelegate.BindUObject(this, &ADialoguePlayer::ShowNextDialogue);
	DialogueWidget->DialogueEndAnimFinishedDelegate.BindUObject(this, &ADialoguePlayer::OnDialogueEndAnimFinished);
	DialogueWidget->InitWidget(DialogueType, Summary);

	GetSoundPlayer().StopMainBGM();

	if (EpisodeTitleWidget)
	{
		EpisodeTitleWidget->Start();
	}
	else if (IsNeedStageTitle())
	{
		StageTitleWidget->Start();
	}
	else
	{
		PlayDialogueInternal();
	}
}

void ADialoguePlayer::PlayDialogueInternal()
{
	GetCheckedLobbyHUD(this)->SetBlackoutDelegates(
		FBoolParamDelegate::CreateUObject(this, &ADialoguePlayer::PresetShowDialogue),
		FBoolParamDelegate::CreateUObject(this, &ADialoguePlayer::PostsetShowDialogue));

	if (MainSequence)
	{
		BGActor->SetActorHiddenInGame(true);

		if (!PlayMainSequence(MainSequence))
		{
			OnDialogueQuit(true);
			return;
		}
	}
	else
	{
		BGActor->SetActorHiddenInGame(false);

		for (FDialogueSpeaker& Speaker : Speakers)
		{
			Speaker.Reset();
		}

		FString BGMesh;
		if (IsVacationType())
		{
			BGMesh = GetGameResource().GetVacationSpotAssetRow(VacationResult.SpotType).BGMesh;
		}
		else
		{
			BGMesh = GetDialogueRow().BGMesh;
		}

		SetBackground(BGMesh);
		SetNoneCamera();

		if (!bContinue)
		{
			ShowNextDialogue();
		}
	}
}

void ADialoguePlayer::ResumeSequence()
{
	if (SequencePlayer && SequencePlayer->IsPaused())
	{
		SequencePlayer->Play();
	}
}

void ADialoguePlayer::PauseSequence()
{
	if (SequencePlayer && SequencePlayer->IsPlaying())
	{
		SequencePlayer->Pause();
	}
}

bool ADialoguePlayer::PlayMainSequence(ULevelSequence* Sequence)
{
	FMovieSceneSequencePlaybackSettings Settings;
	Settings.bHideHud = true;

	if (!ULevelSequencePlayer::CreateLevelSequencePlayer(this, Sequence, Settings, SequenceActor))
	{
		return false;
	}

	if (!ImportSequenceEvents(Sequence))
	{
		return false;
	}

	TArray<AActor*> EventReceivers = { this };
	SequenceActor->SetEventReceivers(EventReceivers);

	SequencePlayer = SequenceActor->SequencePlayer;
	SequencePlayer->OnFinished.AddUniqueDynamic(this, &ADialoguePlayer::OnDialogueEnd);
	SequencePlayer->Play();

	DialogueWidget->EnableNextClick(false);

	return true;
}

bool ADialoguePlayer::PlayStorySequence(ULevelSequence* Sequence)
{
	FMovieSceneSequencePlaybackSettings Settings;
	Settings.bHideHud = true;

	if (!ULevelSequencePlayer::CreateLevelSequencePlayer(this, Sequence, Settings, SequenceActor))
	{
		return false;
	}

	TArray<AActor*> EventReceivers = { this };
	SequenceActor->SetEventReceivers(EventReceivers);

	SequencePlayer = SequenceActor->SequencePlayer;
	SequencePlayer->OnFinished.AddUniqueDynamic(this, &ADialoguePlayer::OnStorySequenceEnd);
	SequencePlayer->Play();

	return true;
}

EDialogueEvent ParseEvent(FName EventName)
{
	static FName NameAuto(TEXT("Auto"));
	static FName NameBegin(TEXT("Begin"));
	static FName NameEnd(TEXT("End"));

	if (EventName == NameAuto)
	{
		return EDialogueEvent::Auto;
	}
	else if (EventName == NameBegin)
	{
		return EDialogueEvent::Begin;
	}
	else if (EventName == NameEnd)
	{
		return EDialogueEvent::End;
	}

	Q6JsonLogZagal(Warning, "ParseEvent - Unknown Event Name", Q6KV("Event", EventName.ToString()));
	return EDialogueEvent::Unknown;
}

void ParseParam(const FEventPayload& EventData, FDialogueEventParam& Param)
{
	FStructOnScope ParameterStruct(nullptr);
	EventData.Parameters.GetInstance(ParameterStruct);

	for (TFieldIterator<UProperty> It(ParameterStruct.GetStruct()); It; ++It)
	{
		UProperty* Property = *It;

		int32 LeftIndex = INDEX_NONE;
		FString PropertyName = Property->GetName();

		if (PropertyName.FindChar('_', LeftIndex))	// Name_2_22391847937492374
		{
			PropertyName.RemoveAt(LeftIndex, PropertyName.Len() - LeftIndex);
		}

		bool bInvalidProperty = true;

		if (UIntProperty* IntProperty = Cast<UIntProperty>(Property))
		{
			if (PropertyName.Equals(TEXT("Id")))
			{
				int32 Value = IntProperty->GetPropertyValue_InContainer(ParameterStruct.GetStructMemory());
				Param.Id = FMath::Max(1, Value);
				bInvalidProperty = false;
			}
		}

		if (bInvalidProperty)
		{
			Q6JsonLogZagal(Warning, "ParseParam - Invalid Property", Q6KV("Property", PropertyName));
		}
	}
}

bool GenerateEvents(const TArray<FDialogueEventParam>& Source, int32 StartId, int32 EndId, TArray<FDialogueEventParam>& Dest)
{
	int32 NumIds = EndId - StartId + 1;
	Dest.Reserve(NumIds);

	for (int32 i = 0; i < Source.Num(); )
	{
		const FDialogueEventParam& Param = Source[i++];

		if (Param.Event == EDialogueEvent::Auto)
		{
			Dest.Add(Param);
		}
		else if (Param.Event == EDialogueEvent::Begin)
		{
			if (!Source.IsValidIndex(i))
			{
				Q6JsonLogZagal(Warning, "GenerateEvents - Invalid Index", Q6KV("Index", i));
				return false;
			}

			if (Source[i].Event != EDialogueEvent::End)
			{
				Q6JsonLogZagal(Warning, "GenerateEvents - Free Pair not matched", Q6KV("Index", i));
				return false;
			}

			const FDialogueEventParam& EndParam = Source[i++];

			for (int32 k = Param.Id; k < EndParam.Id; k++)
			{
				FDialogueEventParam DummyParam;
				DummyParam.Event = EDialogueEvent::Begin;
				DummyParam.Id = k;
				Dest.Add(Param);
			}

			Dest.Add(EndParam);
		}
		else
		{
			Q6JsonLogZagal(Warning, "GenerateEvents - Unknown Error");
			return false;
		}
	}

	if (Dest.Num() != NumIds)
	{
		Q6JsonLogZagal(Warning, "GenerateEvents - Count Error", Q6KV("Current", Dest.Num()), Q6KV("Require", NumIds));
		return false;
	}

	return true;
}

bool ADialoguePlayer::ImportSequenceEvents(ULevelSequence* Sequence)
{
	SequenceEvents.Empty();

	UMovieScene* MovieScene = Sequence->GetMovieScene();
	if (!MovieScene)
	{
		return false;
	}

	UMovieSceneEventTrack* EventTrack = nullptr;
	if (!MovieScene->GetMasterTracks().FindItemByClass(&EventTrack))
	{
		return false;
	}

	UMovieSceneEventSection* EventSection = nullptr;
	if (!EventTrack->GetAllSections().FindItemByClass(&EventSection))
	{
		return false;
	}

	int32 NumKeyTimes = EventSection->GetEventData().GetKeyTimes().Num();

	TArray<FDialogueEventParam> ImportEvents;
	ImportEvents.Reserve(NumKeyTimes);

	for (int32 KeyIndex = 0; KeyIndex < NumKeyTimes; ++KeyIndex)
	{
		FFrameNumber EventTime = EventSection->GetEventData().GetKeyTimes()[KeyIndex];
		FEventPayload EventData = EventSection->GetEventData().GetKeyValues()[KeyIndex];

		FDialogueEventParam Param;
		Param.Frame = ConvertFrameTime(EventTime, MovieScene->GetTickResolution(), MovieScene->GetDisplayRate());
		Param.Event = ParseEvent(EventData.EventName);

		if (Param.Event == EDialogueEvent::Unknown)
		{
			return false;
		}

		ParseParam(EventData, Param);
		ImportEvents.Add(Param);
	}

	return GenerateEvents(ImportEvents, StartId, EndId, SequenceEvents);
}

FDialogueSpeaker* ADialoguePlayer::GetValidSpeaker(int32 InSpeakerId)
{
	FDialogueSpeaker* Speaker = Speakers.FindByPredicate([InSpeakerId](const FDialogueSpeaker& InSpeaker)
	{
		return InSpeaker.SpeakerId == InSpeakerId;
	});

	if (Speaker && Speaker->SkeletalMeshActor)
	{
		return Speaker;
	}

	Q6JsonLogZagal(Warning, "GetValidSpeaker - No Vaild Speaker", Q6KV("SpeakerId", InSpeakerId));
	return nullptr;
}

void ADialoguePlayer::SetSpeakerModel(int32 InSpeakerId, int32 InModelType)
{
	FDialogueSpeaker* Speaker = GetValidSpeaker(InSpeakerId);
	if (Speaker)
	{
		Speaker->SetModel(InModelType);
	}
}

void ADialoguePlayer::PlaySpeakerAnimation(int32 InSpeakerId, const FString& InExpression)
{
	FDialogueSpeaker* Speaker = GetValidSpeaker(InSpeakerId);
	if (!Speaker || !Speaker->ModelType)
	{
		return;
	}

	FString TypeStr;

	if (InExpression.IsEmpty())
	{
		TypeStr = FString::Printf(TEXT("%d_Idle"), Speaker->ModelType);
	}
	else
	{
		TypeStr = FString::Printf(TEXT("%d_%s"), Speaker->ModelType, *InExpression);
	}

	const FDialogueAnimAssetRow* Row = DialogueAnimAssetTable->FindRow<FDialogueAnimAssetRow>(FName(*TypeStr), TypeStr, false);
	if (!Row)
	{
		Q6JsonLogZagal(Warning, "PlaySpeakerAnimation - No AnimAssetRow", Q6KV("RowName", TypeStr));
		return;
	}

	Speaker->PlayAnimation(Row);
}

FName ADialoguePlayer::GetVoiceName() const
{
	FString Voice;

	switch (DialogueType)
	{
		case EDialogueType::Saga:
		case EDialogueType::Special:
		case EDialogueType::Raid:
		case EDialogueType::Event:
		case EDialogueType::MultiSide:
			Voice = FString::Printf(TEXT("%d-%d"), Episode, DialogueId);
			break;
		case EDialogueType::Daily:
			Voice = FString::Printf(TEXT("%d-%d"), (int32)DayOfWeek, DialogueId);
			break;
		case EDialogueType::Training:
			Voice = FString::Printf(TEXT("%d-%d"), TrainingCenterType.x, DialogueId);
			break;
	}

	return FName(*Voice);
}

ACineCameraActor* ADialoguePlayer::GetCamera(EDialogueCamera InCameraType) const
{
	switch (InCameraType)
	{
	case EDialogueCamera::Speaker1Cam:
		return Speaker1Camera;
	case EDialogueCamera::Speaker2Cam:
		return Speaker2Camera;
	case EDialogueCamera::SpeakersCam:
		return SpeakersCamera;
	}

	return NoneCamera;
}

void ADialoguePlayer::SetNoneCamera()
{
	ACineCameraActor* CurCamera = GetCamera(EDialogueCamera::None);
	GetLocalPlayerController(this)->SetViewTarget(CurCamera);

	HideAllSpeakers();
}

void ADialoguePlayer::SetCamera(const FCMSDialogueRow& Row)
{
	EDialogueCamera CameraType = EDialogueCamera(Row.CameraType);
	EDialogueCameraMode CameraMode = EDialogueCameraMode(Row.CameraMode);

	ACineCameraActor* CurCamera = GetCamera(CameraType);
	GetLocalPlayerController(this)->SetViewTarget(CurCamera);

	if (CameraType == EDialogueCamera::Speaker1Cam || CameraType == EDialogueCamera::Speaker2Cam)
	{
		int32 ModelType = 0;
		int32 CameraIndex = static_cast<int32>(CameraType);

		if (CameraType == EDialogueCamera::Speaker1Cam)
		{
			ModelType = Row.Speaker1ModelType;
		}
		else
		{
			ModelType = Row.Speaker2ModelType;
		}

		CurCamera->SetActorTransform(DefaultCameraXform[CameraIndex]);

		const FUnitModelCameraRow* CamRow = GetGameResource().GetUnitModelCameraRowPtr(ModelType);
		if (CamRow)
		{
			if (CameraMode == EDialogueCameraMode::ZoomIn)
			{
				CurCamera->AddActorWorldOffset(CamRow->ZoomInOffset);
			}
			else
			{
				CurCamera->AddActorWorldOffset(CamRow->DefaultOffset);
			}
		}
	}

	switch (CameraMode)
	{
		case EDialogueCameraMode::ZoomIn:
			CurCamera->GetCineCameraComponent()->CurrentFocalLength = ZOOM_IN_FORCAL_LENGTH;
			break;
		case EDialogueCameraMode::ZoomOut:
			CurCamera->GetCineCameraComponent()->CurrentFocalLength = ZOOM_OUT_FORCAL_LENGTH;
			break;
		default:
			CurCamera->GetCineCameraComponent()->CurrentFocalLength = DEFAULT_FOCAL_LENGTH;
			break;
	}
}

void ADialoguePlayer::ArrangeSpeakers(const FCMSDialogueRow& Row)
{
	EDialogueCamera CameraType = EDialogueCamera(Row.CameraType);
	int32 CameraIndex = static_cast<int32>(CameraType);

	for (FDialogueSpeaker& Speaker : Speakers)
	{
		ASkeletalMeshActor* SpeakerActor = Speaker.SkeletalMeshActor;
		if (!SpeakerActor)
		{
			continue;
		}

		if (CameraType == EDialogueCamera::SpeakersCam)
		{
			bool bHiddenInGame = true;

			if (Speaker.SpeakerId == 1)
			{
				bHiddenInGame = (Row.Speaker1ModelType == 0);
			}
			else if (Speaker.SpeakerId == 2)
			{
				bHiddenInGame = (Row.Speaker2ModelType == 0);
			}

			SpeakerActor->SetActorTransform(Speaker.InitialTransform);
			SpeakerActor->SetActorHiddenInGame(bHiddenInGame);
		}
		else if (Speaker.SpeakerId == CameraIndex)
		{
			FVector Dir = DefaultCameraXform[CameraIndex].GetLocation() - Speaker.SkeletalMeshActor->GetActorLocation();

			// Mesh rotation offset
			FRotator Rot = Dir.GetSafeNormal2D().Rotation();
			Rot.Yaw -= 90.f + float(Row.CameraAngle);

			SpeakerActor->SetActorRotation(Rot);
			SpeakerActor->SetActorHiddenInGame(false);
		}
		else
		{
			SpeakerActor->SetActorHiddenInGame(true);
		}
	}
}

void ADialoguePlayer::HideAllSpeakers()
{
	for (FDialogueSpeaker& Speaker : Speakers)
	{
		if (Speaker.SkeletalMeshActor)
		{
			Speaker.SkeletalMeshActor->SetActorHiddenInGame(true);
		}
	}
}

void ADialoguePlayer::SetCameraAnim(int32 AnimIndex)
{
	StopCameraAnim();

	if (AnimIndex <= 0)
	{
		return;
	}

	FString TypeStr = FString::Printf(TEXT("%d"), AnimIndex);
	const FDialogueCameraAnimRow* Row = DialogueCameraAnimTable->FindRow<FDialogueCameraAnimRow>(FName(*TypeStr), TypeStr, false);
	if (!Row)
	{
		Q6JsonLogZagal(Warning, "SetCameraAnim - Failed to find row", Q6KV("CameraAnim", AnimIndex));
		return;
	}

	if (Row->CameraAnim.IsNull())
	{
		Q6JsonLogZagal(Warning, "SetCameraAnim - CameraAnim is null", Q6KV("CameraAnim", AnimIndex));
		return;
	}

	if (UCameraAnim* CameraAnim = Row->CameraAnim.LoadSynchronous())
	{
		if (APlayerController* PlayerController = GetLocalPlayerController(this))
		{
			PlayerController->PlayerCameraManager->PlayCameraAnim(CameraAnim);
		}
	}
}

void ADialoguePlayer::StopCameraAnim()
{
	if (APlayerController* PlayerController = GetLocalPlayerController(this))
	{
		PlayerController->PlayerCameraManager->StopAllCameraAnims();
	}
}

void ADialoguePlayer::SetBackground(const FString& InAssetName)
{
	if (InAssetName.IsEmpty() || BGAssetName.Equals(InAssetName))
	{
		return;
	}

	const FDialogueBGAssetRow* Row = DialogueBGAssetTable->FindRow<FDialogueBGAssetRow>(FName(*InAssetName), InAssetName, false);
	if (!Row)
	{
		Q6JsonLogZagal(Warning, "SetBackground - Failed to find row", Q6KV("RowName", InAssetName));
		return;
	}

	if (Row->ActorClass.IsNull())
	{
		Q6JsonLogZagal(Warning, "SetBackground - No Actor class", Q6KV("RowName", InAssetName));
		return;
	}

	if (BGActorPath != Row->ActorClass.ToString())
	{
		ClearBackgroundActor();

		FActorSpawnParameters SpawnParam;
		SpawnParam.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		BGAssetActor = GetWorld()->SpawnActor<AActor>(Row->ActorClass.LoadSynchronous(), SpawnParam);
		if (!BGAssetActor)
		{
			Q6JsonLogZagal(Warning, "SetBackground - Failed to spawn", Q6KV("RowName", InAssetName));
			return;
		}

		BGAssetActor->AttachToActor(BGActor, FAttachmentTransformRules::KeepRelativeTransform);
		BGActorPath = Row->ActorClass.ToString();
	}

	if (!Row->Tod.IsEmpty() && !TodPresetName.Equals(Row->Tod))
	{
		ULevelUtil::LoadSagaLightPreset(GetWorld(), Row->Tod);
		TodPresetName = Row->Tod;
	}

	BGAssetName = InAssetName;
}

void ADialoguePlayer::ClearBackgroundActor()
{
	if (BGAssetActor)
	{
		BGAssetActor->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		BGAssetActor->Destroy();
		BGAssetActor = nullptr;
	}

	BGActorPath.Empty();
}

void ADialoguePlayer::ClearBackground()
{
	ClearBackgroundActor();

	BGAssetName.Empty();
	TodPresetName.Empty();
}

void ADialoguePlayer::SetCameraEffects(const TArray<int32>& InEffects, bool bPreset)
{
	CameraEffects.Reserve(InEffects.Num());

	for (int32 EffectId : InEffects)
	{
		FString TypeStr = FString::Printf(TEXT("%d"), EffectId);
		const FDialogueCameraEffectRow* Row = DialogueCameraEffectTable->FindRow<FDialogueCameraEffectRow>(FName(*TypeStr), TypeStr, false);
		if (!Row)
		{
			Q6JsonLogZagal(Warning, "SetCameraEffects - No DialogueCameraEffectRow", Q6KV("Id", EffectId));
			continue;
		}

		if (UDialogueCameraEffect::IsPreset(Row->Type) != bPreset)
		{
			continue;
		}

		if (IsFastForwarding() && !UDialogueCameraEffect::IsWorkingInFastForwarding(Row->Type))
		{
			continue;
		}

		switch (Row->Type)
		{
		case EDialogueCameraEffect::PostProcess:
			{
				UDialoguePostProcess* Effect = NewObject<UDialoguePostProcess>(this);
				Effect->Apply(PostProcessVolume, Row->Tint, Row->Saturation);
				CameraEffects.Add(Effect);
			}
			break;
		case EDialogueCameraEffect::WidgetAnimation:
			{
				UDialogueWidgetAnim* Effect = NewObject<UDialogueWidgetAnim>(this);
				Effect->Apply(DialogueWidget, Row->WidgetAnim, Row->RestoreWidgetAnim, Row->NumLoopsToPlay, Row->AnimationSpeed);
				CameraEffects.Add(Effect);
			}
			break;
		case EDialogueCameraEffect::CameraShake:
			{
				UDialougeCameraShake* Effect = NewObject<UDialougeCameraShake>(this);
				Effect->Apply(Row->CameraShake);
				CameraEffects.Add(Effect);
			}
			break;
		case EDialogueCameraEffect::Particle:
			{
				UDialougeParticle* Effect = NewObject<UDialougeParticle>(this);
				Effect->Apply(Row->Particle.LoadSynchronous());
				CameraEffects.Add(Effect);
			}
			break;
		case EDialogueCameraEffect::Blendable:
			{
				UDialougeBlendable* Effect = NewObject<UDialougeBlendable>(this);
				Effect->Apply(PostProcessVolume, Row->Blendable.LoadSynchronous(), Row->BaseColor, Row->SecondColor);
				CameraEffects.Add(Effect);
			}
			break;
		default:
			Q6JsonLogZagal(Warning, "SetCameraEffects - Unknown EDialogueCameraEffect Type", Q6KV("Id", EffectId), Q6KV("Type", (int32)Row->Type));
			break;
		}
	}
}

void ADialoguePlayer::RestoreCameraEffects(bool bPreset)
{
	TArray<UDialogueCameraEffect*> CachedEffects;
	CachedEffects.Reserve(CameraEffects.Num());

	for (auto Effect : CameraEffects)
	{
		if (UDialogueCameraEffect::IsPreset(Effect->GetType()) == bPreset)
		{
			Effect->Restore();
		}
		else
		{
			CachedEffects.Add(Effect);
		}
	}

	CameraEffects = MoveTemp(CachedEffects);
}

void ADialoguePlayer::SetChoices(const FCMSDialogueRow& InChoiceRow)
{
	TArray<FText> ChoiceTexts;
	ChoiceNextDialogueIds.Empty();

	bool bBanChoice = false;

	const FCMSDialogueRow* ChoiceRow = &InChoiceRow;

	for (int32 Id = DialogueId + 1; ChoiceRow->ChoiceId; ++Id)
	{
		ChoiceTexts.Add(ChoiceRow->Bubble);
		ChoiceNextDialogueIds.Add(ChoiceRow->NextDialogueId);
		bBanChoice |= ChoiceRow->BanChoice;

		const FCMSDialogueRow& DialogueRow = GetCMS()->GetDialogueRowOrDummy(DialogueTable, FDialogueType(Id));
		ChoiceRow = &DialogueRow;
	}

	DialogueWidget->ShowChoices(InChoiceRow, ChoiceTexts, bBanChoice);
}

bool ADialoguePlayer::ProcessMainSequence()
{
	int32 CurIdx  = DialogueId - StartId - 1;
	int32 NextIdx = CurIdx + 1;

	bool bMoveNext = (DialogueId <= EndId);

	if (SequenceEvents.IsValidIndex(CurIdx))
	{
		const FDialogueEventParam& CurParam = SequenceEvents[CurIdx];
		if (CurParam.Event == EDialogueEvent::End)
		{
			FFrameTime CurrentTime = SequencePlayer->GetCurrentTime().Time;
			if (CurrentTime < CurParam.Frame)
			{
				SequencePlayer->JumpToFrame(CurParam.Frame);
			}
			else if (SequenceEvents.IsValidIndex(NextIdx))
			{
				const FDialogueEventParam& NextParam = SequenceEvents[NextIdx];
				if (CurrentTime >= NextParam.Frame)
				{
					return bMoveNext;
				}
			}

			DialogueWidget->EnableNextClick(false);
			ResumeSequence();
			return false;
		}
	}

	return bMoveNext;
}

void ADialoguePlayer::DestroySequenceActor()
{
	if (SequencePlayer)
	{
		SequencePlayer->Stop();
		SequencePlayer = nullptr;
	}

	if (SequenceActor)
	{
		SequenceActor->Destroy();
		SequenceActor = nullptr;
	}
}

bool ADialoguePlayer::CanDialogueContinue() const
{
	if (bReplay)
	{
		return false;
	}

	if (DialogueType == EDialogueType::Vacation
		|| DialogueType == EDialogueType::None)
	{
		return false;
	}

	if (CVarQ6DialogueRecordCount.GetValueOnGameThread() <= 0)
	{
		return false;
	}

	if (!GetHUDStore().GetWorldUser().IsLobbyTutorialDone(ELobbyTutorial::GoLobbyOpen))
	{
#if !UE_BUILD_SHIPPING
		const UQ6GameInstance* Q6GameInstance = GetGameInstance<UQ6GameInstance>();
		if (Q6GameInstance && Q6GameInstance->IsDevMode())
		{
			return true;
		}
#endif
		return false;
	}

	return true;
}

void ADialoguePlayer::ShowNextDialogue()
{
	if (ULevelSequence** Sequence = StorySequences.Find(DialogueId))
	{
		if (PlayStorySequence(*Sequence))
		{
			HideAllSpeakers();
			HideForStorySequence(true);
			return;
		}
	}

	if (FCharacterIntroductionInfo* Info = CharacterIntroductionInfos.Find(DialogueId))
	{
		if (UGameplayStatics::IsGamePaused(this))
		{
			HideCharacterIntroduction();
			return;
		}

		if (ShowCharacterIntroduction(Info))
		{
			return;
		}
	}

	ShowNextDialogueInternal();
}

void ADialoguePlayer::ShowNextDialogueInternal()
{
	if (DialogueId == StartId)
	{
		DialogueWidget->OnDialogueStart();
	}
	else
	{
		if (IsSequenceMode())
		{
			if (!ProcessMainSequence())
			{
				return;
			}
		}
		else
		{
			if (DialogueId > EndId)
			{
				OnDialogueEnd();
				return;
			}
		}
	}

	RestoreCameraEffects(false);

	const FCMSDialogueRow& Row = GetDialogueRow();
	EBlackoutType BlackoutType = EBlackoutType(Row.BlackoutType);

	if (!IsFastForwarding() && BlackoutType != EBlackoutType::None)
	{
		GetCheckedLobbyHUD(this)->ShowBlackout(BlackoutType);
		DialogueWidget->ShowTopOnly();
	}
	else
	{
		PresetShowDialogue(false);
		PostsetShowDialogue(false);
	}
}

bool ADialoguePlayer::ShowCharacterIntroduction(FCharacterIntroductionInfo* InInfo)
{
	if (!CharacterIntroductionWidget)
	{
		CharacterIntroductionWidget = CreateWidget<UCharacterIntroductionWidget>(GetLocalPlayerController(this), CharacterIntroductionWidgetClass.LoadSynchronous());
		if (!CharacterIntroductionWidget)
		{
			Q6JsonLogSunny(Warning, "Failed to create CharacterIntroductionWidget");
			return false;
		}
		else
		{
			CharacterIntroductionWidget->AddToViewport(ZORDER_HUDWIDGET - 1);
			CharacterIntroductionWidget->OnCharacterIntroductionEndDelegate.BindUObject(this, &ADialoguePlayer::OnCharacterIntroductionEnd);
		}
	}
	ensure(CharacterIntroductionWidget);

	if (CharacterIntroductionWidget->SetInfo(InInfo))
	{
		DialogueWidget->ShowTopOnly();

		CharacterIntroductionWidget->PlayStart(IsAutoPlaying(), IsFastForwarding());
		CharacterIntroductionWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		for (FDialogueSpeaker& Speaker : Speakers)
		{
			Speaker.PlayIdleImmediately();
		}
		
		UGameplayStatics::SetGamePaused(this, true);
		return true;
	}
	
	CharacterIntroductionWidget->SetVisibility(ESlateVisibility::Collapsed);
	return false;
}

void ADialoguePlayer::PresetShowDialogue(bool bBlackout)
{
	const FCMSDialogueRow& Row = GetDialogueRow();

	if (!IsFastForwarding())
	{
		GetSoundPlayer().PlayMainBGM(FName(*Row.BGM));
	}

	if (!IsSequenceMode())
	{
		SetBackground(Row.BGMesh);

		if (DialogueWidget->ChangeDialogueMode(Row.Mode, Row.Area))
		{
			if (DialogueWidget->IsChatMode())
			{
				SetNoneCamera();
			}
		}

		if (DialogueWidget->IsNormalMode())
		{
			SetCamera(Row);

			if (bBlackout)
			{
				HideAllSpeakers();
			}
		}
	}

	RestoreCameraEffects(true);
	SetCameraEffects(Row.CameraEffects, true);

	if (GetCheckedLobbyHUD(this)->IsShowingBlackout())
	{
		GetCheckedLobbyHUD(this)->HideBlackout();
	}
}

void ADialoguePlayer::PostsetShowDialogue(bool bBlackout)
{
	const FCMSDialogueRow& Row = GetDialogueRow();

	if (!IsSequenceMode())
	{
		if (DialogueWidget->IsNormalMode())
		{
			SetSpeakerModel(1, Row.Speaker1ModelType);
			PlaySpeakerAnimation(1, Row.Speaker1Expression);

			SetSpeakerModel(2, Row.Speaker2ModelType);
			PlaySpeakerAnimation(2, Row.Speaker2Expression);

			ArrangeSpeakers(Row);
			SetCameraAnim(Row.CameraAnim);
		}

		if (!IsVacationType())
		{
			DialogueWidget->SetSoundData(GetVoiceName(), Row);
		}
	}

	SetCameraEffects(Row.CameraEffects, false);

	// check area
	DialogueWidget->ProcessAreaName(Row.Area);

	// check choice
	if (Row.ChoiceId)
	{
		SetChoices(Row);
	}
	else
	{
		DialogueWidget->ShowDialogueText(Row);

		UpdateDialogueRecording();

		// set next dialogue info
		DialogueId = Row.NextDialogueId ? Row.NextDialogueId : DialogueId + 1;
	}
}

void ADialoguePlayer::OnEpisodeTitleEnd()
{
	if (IsNeedStageTitle())
	{
		StageTitleWidget->Start();
	}
	else
	{
		PlayDialogueInternal();
	}
}

void ADialoguePlayer::OnStageTitleEnd()
{
	PlayDialogueInternal();
}

void ADialoguePlayer::OnBanChoice(int32 ChoiceIndex, bool bBanChoice)
{
	if (bBanChoice)
	{
		TArray<int32> BanIndices;
		BanIndices.Add(ChoiceIndex);

		UQ6GameInstance::Get(this)->UpdateBanIndices(BanIndices);
	}

	if (ChoiceNextDialogueIds.IsValidIndex(ChoiceIndex))
	{
		DialogueId = ChoiceNextDialogueIds[ChoiceIndex];
	}
}

void ADialoguePlayer::DefaultChoiceBySkip()
{
	int32 BanIndex = 0;
	TArray<int32> BanIndices;

	while (DialogueId <= EndId)
	{
		const FCMSDialogueRow* Row = &GetDialogueRow();
		if (Row->ChoiceId)
		{
			BanIndex = 0;
			BanIndices.Empty();

			while (Row->ChoiceId)
			{
				if (Row->BanChoice)
				{
					BanIndices.Add(BanIndex);
				}

				++BanIndex;
				++DialogueId;

				Row = &GetDialogueRow();
			}

			if (BanIndices.Num() > 0)
			{
				UQ6GameInstance::Get(this)->UpdateBanIndices(BanIndices);
			}
		}

		++DialogueId;
	}
}

void ADialoguePlayer::OnDialogueSkip()
{
	DefaultChoiceBySkip();

	DialogueId = EndId + 1;

	PauseSequence();

	if (DialogueWidget->IsVisible())
	{
		OnDialogueEnd();
	}
	else
	{
		OnDialogueEndAnimFinished();
	}
}

void ADialoguePlayer::OnDialogueBottomSkip()
{
	if (SequencePlayer && SequencePlayer->IsPlaying())
	{
		FFrameTime EndTime = SequencePlayer->GetEndTime().Time;
		FFrameTime JumpFrame(EndTime.FrameNumber - 1, 0.99999994f);

		SequencePlayer->JumpToFrame(JumpFrame);
	}
}

void ADialoguePlayer::OnDialogueEnd()
{
	DialogueWidget->OnDialogueEnd(IsVacationType());
}

void ADialoguePlayer::OnDialogueEndAnimFinished()
{
	if (IsVacationType())
	{
		if (!VacationResultWidget)
		{
			VacationResultWidget = CreateWidget<UVacationResultWidget>(GetLocalPlayerController(this), VacationResultClass.LoadSynchronous());
		}

		VacationResultWidget->AddToViewport(ZORDER_HUDWIDGET + 1);
		VacationResultWidget->SetResult(VacationResult);
		VacationResultWidget->OnClosedDelegate.BindUObject(this, &ADialoguePlayer::OnVacationResultClosed);

		if (VacationResult.ResultType != EUpgradeResultType::Fail)
		{
			PlaySpeakerAnimation(1, TEXT("Happy"));
		}
	}
	else
	{
		OnDialogueQuit(false);
	}
}

void ADialoguePlayer::OnStorySequenceEnd()
{
	HideForStorySequence(false);
	ShowNextDialogueInternal();
}

void ADialoguePlayer::HideCharacterIntroduction()
{
	if (CharacterIntroductionWidget)
	{
		if (!CharacterIntroductionWidget->IsPlayingEnd())
		{
			CharacterIntroductionWidget->PlayEnd();
		}
	}
	else
	{
		OnCharacterIntroductionEnd();
	}
}

void ADialoguePlayer::HideForStorySequence(bool bHide)
{
	MainDirectionalLight->SetActorHiddenInGame(bHide);

	if (BGAssetActor)
	{
		BGAssetActor->SetActorHiddenInGame(bHide);
	}

	if (DialogueWidget)
	{
		DialogueWidget->HideForStorySequence(bHide);
	}
}

void ADialoguePlayer::OnCharacterIntroductionEnd()
{
	UGameplayStatics::SetGamePaused(this, false);
	ShowNextDialogueInternal();
}

void ADialoguePlayer::InitDialogueRecording()
{
	if (CanDialogueContinue())
	{
		int32 TrainingExpireTime = GetHUDStore().GetTrainingCenterManager().GetHistory().ExpireTime;

		FDialogueRecord DialogueRecord(DialogueType,
			SagaType,
			DayOfWeek,
			TrainingCenterType,
			TrainingExpireTime,
			EventContentType,
			bPrologue);

		UQ6GameInstance::Get(this)->InitDialogueRecord(DialogueRecord, FDialogueType(DialogueId));
	}
}

void ADialoguePlayer::UpdateDialogueRecording()
{
	if (CanDialogueContinue()
		&& DialoguePlayingCount >= CVarQ6DialogueRecordCount.GetValueOnGameThread())
	{
		UQ6GameInstance::Get(this)->UpdateDialogueRecord(FDialogueType(DialogueId));
		DialoguePlayingCount = 0;
	}

	++DialoguePlayingCount;
}

void ADialoguePlayer::OnVacationResultClosed()
{
	if (VacationResultWidget && VacationResultWidget->IsInViewport())
	{
		VacationResultWidget->RemoveFromParent();
	}

	OnDialogueQuit(false);
}

void ADialoguePlayer::OnDialogueQuit(bool bError)
{
	if (UGameplayStatics::IsGamePaused(this))
	{
		UGameplayStatics::SetGamePaused(this, false);
	}

	GetCheckedLobbyHUD(this)->ClearBlackoutDelegates();
	GetCheckedLobbyHUD(this)->StopBlackout();

	if (EpisodeTitleWidget)
	{
		EpisodeTitleWidget->RemoveFromViewport();
		EpisodeTitleWidget = nullptr;
	}

	if (StageTitleWidget)
	{
		StageTitleWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	if (CharacterIntroductionWidget)
	{
		CharacterIntroductionWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	HideForStorySequence(false);
	DestroySequenceActor();

	MainSequence = nullptr;

	if (AssetCache)
	{
		AssetCache->CancelStreaming();
		AssetCache = nullptr;
	}

	ClearBackground();

	bool bPlayLobbyBGM = true;

	switch (DialogueType)
	{
		case EDialogueType::Saga:
		case EDialogueType::Special:
		case EDialogueType::Training:
		case EDialogueType::Raid:
		case EDialogueType::Event:
		case EDialogueType::MultiSide:
			OnSagaQuit(bError, bPlayLobbyBGM);
			break;
		case EDialogueType::Daily:
			GetCheckedLobbyHUD(this)->GotoBack(true);
			break;
		case EDialogueType::Vacation:
			OnVacationQuit(bError);
			break;
	}

	GetSoundPlayer().StopDialogueVoice();

	if (bPlayLobbyBGM)
	{
		GetSoundPlayer().PlayMainBGM(TEXT("Lobby"));
	}

	UQ6GameInstance::Get(this)->ClearDialogueRecord();
}

void ADialoguePlayer::OnSagaQuit(bool bError, bool& bOutLobbyBGM)
{
	ALobbyHUD* LobbyHUD = GetCheckedLobbyHUD(this);
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	if (bReplay)
	{
		if (IsStoryLikeStageType(SagaRow.StageType))
		{
			LobbyHUD->GotoBack(true);
		}
		else
		{
			if (bPrologue)
			{
				switch (DialogueType)
				{
					case EDialogueType::Training:
						PlayTraining(TrainingCenterType, SagaType, false, bReplay);
						break;
					default:
						PlaySaga(SagaType, false, bReplay);
						break;
				}

				bOutLobbyBGM = false;
			}
			else
			{
				LobbyHUD->GotoBack(true);
			}
		}
	}
	else
	{
		if (IsStoryLikeStageType(SagaRow.StageType))
		{
			LobbyHUD->ProcessReward(true);
		}
		else
		{
			if (bPrologue)
			{
				if (SagaRow.ContentType == EContentType::MultiSideBattle)
				{
					ACTION_DISPATCH_PartyMain(SagaType);
					ACTION_DISPATCH_PartyEventContentType(EventContentType);
					LobbyHUD->ChangeHUDType(EHUDWidgetType::Party, true);
				}
				else
				{
					ACTION_DISPATCH_JokerSelect(SagaType, false);
					LobbyHUD->ChangeHUDType(EHUDWidgetType::JokerSelect, true);
				}
			}
			else
			{
				LobbyHUD->ProcessReward();
			}
		}
	}
}

void ADialoguePlayer::OnVacationQuit(bool bError)
{
	if (!bError && VacationResult.IsBondLevelUp())
	{
		GetCheckedLobbyHUD(this)->ProcessReward();
	}
	else
	{
		GetCheckedLobbyHUD(this)->GotoBack(true);
	}
}

void ADialoguePlayer::OnSequenceBegin(int32 Id)
{
	ShowNextDialogue();

	DialogueWidget->EnableNextClick(true);
}

void ADialoguePlayer::OnSequenceEnd(int32 Id)
{
	if (DialogueId <= Id)
	{
		PauseSequence();
	}
	else
	{
		DialogueWidget->EnableNextClick(false);
	}
}

void ADialoguePlayer::OnSequenceAuto()
{
	ShowNextDialogue();

	DialogueWidget->EnableNextClick(false);
}

void ADialoguePlayer::OnStoryStageClear()
{
	InitDialogueRecording();
}
