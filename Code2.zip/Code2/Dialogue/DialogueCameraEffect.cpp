

#include "DialogueCameraEffect.h"
#include "Camera/CameraShake.h"
#include "DialogueWidget.h"
#include "Q6.h"

bool UDialogueCameraEffect::IsPreset(EDialogueCameraEffect Type)
{
	switch (Type)
	{
	case EDialogueCameraEffect::PostProcess:
		return true;
	}

	return false;
}

bool UDialogueCameraEffect::IsWorkingInFastForwarding(EDialogueCameraEffect Type)
{
	return (Type == EDialogueCameraEffect::PostProcess);
}

void UDialoguePostProcess::Apply(APostProcessVolume* InVolume, const FLinearColor& InTint, float InSaturation)
{
	Volume = InVolume;

	RestoreTint = InVolume->Settings.FilmWhitePoint;
	RestoreSaturation = InVolume->Settings.FilmSaturation;

	Volume->Settings.bOverride_FilmWhitePoint = true;
	Volume->Settings.FilmWhitePoint = InTint;

	Volume->Settings.bOverride_FilmSaturation = true;
	Volume->Settings.FilmSaturation = InSaturation;
}

void UDialoguePostProcess::Restore()
{
	Volume->Settings.bOverride_FilmWhitePoint = true;
	Volume->Settings.FilmWhitePoint = RestoreTint;

	Volume->Settings.bOverride_FilmSaturation = true;
	Volume->Settings.FilmSaturation = RestoreSaturation;
}

void UDialogueWidgetAnim::Apply(UDialogueWidget* InWidget, const FName& InAnim, const FName& InRestoreAnim, int32 NumLoops, float Speed)
{
	Widget = InWidget;
	AnimName = InAnim;
	RestoreAnimName = InRestoreAnim;

	int32 NumLoopsToPlay = FMath::Max(0, NumLoops);
	float PlaySpeed = FMath::Max(0.01f, Speed);

	if (UWidgetAnimation* Anim = GetWidgetAnimationFromName(Widget, AnimName))
	{
		Widget->PlayAnimation(Anim, 0.0f, NumLoopsToPlay, EUMGSequencePlayMode::Forward, PlaySpeed);
	}
}

void UDialogueWidgetAnim::Restore()
{
	if (UWidgetAnimation* Anim = GetWidgetAnimationFromName(Widget, AnimName))
	{
		Widget->StopAnimation(Anim);
	}

	if (!RestoreAnimName.IsNone())
	{
		if (UWidgetAnimation* Anim = GetWidgetAnimationFromName(Widget, RestoreAnimName))
		{
			Widget->PlayAnimation(Anim);
		}
	}
}

void UDialougeCameraShake::Apply(TSubclassOf<UCameraShake> InCameraShake)
{
	CameraShake = InCameraShake;

	APlayerController* Controller = GetLocalPlayerController(this);
	if (Controller)
	{
		Controller->ClientPlayCameraShake(CameraShake);
	}
}

void UDialougeCameraShake::Restore()
{
	APlayerController* Controller = GetLocalPlayerController(this);
	if (Controller)
	{
		Controller->ClientStopCameraShake(CameraShake);
	}
}

void UDialougeParticle::Apply(UParticleSystem* InParticle)
{
	if (APlayerController* Controller = GetLocalPlayerController(this))
	{
		if (AActor* ViewTarget = Controller->GetViewTarget())
		{
			ParticleComponent = UGameplayStatics::SpawnEmitterAttached(InParticle, ViewTarget->GetRootComponent());
		}
	}
}

void UDialougeParticle::Restore()
{
	if (ParticleComponent)
	{
		ParticleComponent->DestroyComponent();
	}
}

void UDialougeBlendable::Apply(APostProcessVolume* InVolume, UMaterialInstance* InMaterial, const FLinearColor& BaseColor, const FLinearColor& SecondColor)
{
	Volume = InVolume;
	Instance = UMaterialInstanceDynamic::Create(InMaterial, GetTransientPackage());

	if (Volume && Instance)
	{
		SetColorParameter(FName(TEXT("Base_Color")), BaseColor);
		SetColorParameter(FName(TEXT("Second_Color")), SecondColor);

		Volume->Settings.AddBlendable(Instance, 1.0f);
	}
}

void UDialougeBlendable::SetColorParameter(FName ParameterName, const FLinearColor& Value)
{
	check(Instance);

	FLinearColor Result;
	FMaterialParameterInfo ParameterInfo(ParameterName);
	if (Instance->GetVectorParameterValue(ParameterInfo, Result))
	{
		Instance->SetVectorParameterValue(ParameterName, Value);
	}
}

void UDialougeBlendable::Restore()
{
	if (Volume && Instance)
	{
		Volume->Settings.RemoveBlendable(Instance);
	}
}
