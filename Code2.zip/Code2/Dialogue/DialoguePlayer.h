// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Misc/FrameTime.h"
#include "GameFramework/Actor.h"
#include "Animation/SkeletalMeshActor.h"
#include "CMS_gen.h"
#include "Q6Enum.h"
#include "VacationWidgets.h"
#include "DialoguePlayer.generated.h"

enum class ECCFaction : uint8;

class AActor;
class ACineCameraActor;
class ALevelSequenceActor;
class AQ6DirectionalLight;
class APostProcessVolume;
class AStaticMeshActor;
class UAnimSequenceBase;
class UCharacterIntroductionWidget;
class UDataTable;
class UDialogueCameraEffect;
class UDialogueWidget;
class UEpisodeTitleWidget;
class UGameAssetCache;
class ULevelSequence;
class ULevelSequencePlayer;
class UParticleSystemComponent;
class UStageTitleWidget;
class UUnitAnimInstance;
class UVacationResultWidget;

struct FCMSDialogueRow;
struct FCharacterIntroduction;
struct FDialogueAnimAssetRow;
struct FDialogueBGAssetRow;
struct FDialogueEpisodeRow;
struct FDialogueStageRow;

UENUM()
enum class EDialogueCamera : uint8
{
	None,
	Speaker1Cam,
	Speaker2Cam,
	SpeakersCam,
	Max,
};
static const int32 EDialogueCameraMax = static_cast<int32>(EDialogueCamera::Max);

UENUM()
enum class EDialogueCameraMode : uint8
{
	None,
	ZoomIn,
	ZoomOut,
};

UENUM(BlueprintType)
enum class EDialogueEvent : uint8
{
	Unknown,
	Auto,
	Begin,
	End,
};

USTRUCT()
struct FDialogueSpeaker
{
	GENERATED_USTRUCT_BODY()

	FDialogueSpeaker()
		: SpeakerId(0)
		, SkeletalMeshActor(nullptr)
		, Mesh(nullptr)
		, BodyIdle(nullptr)
		, FaceIdle(nullptr)
		, PrevDefaultAsset(nullptr)
		, PrevFaceAsset(nullptr)
		, ModelType(0) {}

	bool Initialize();
	void Reset();

	void SetModel(int32 InModelType);
	void PlayAnimation(const FDialogueAnimAssetRow* Row);
	void PlayIdleImmediately();
	void UpdateAnimationImmediately();

	void ResetPrevAssets();

	UAnimMontage* PlayDefaultSlot(UAnimSequenceBase* Asset, bool bLoop, bool bForce, float BlendInTime = 0.f, float BlendOutTime = 0.f);
	UAnimMontage* PlayFaceSlot(UAnimSequenceBase* Asset, bool bLoop, bool bForce, float BlendInTime = 0.f, float BlendOutTime = 0.f);

	void OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted);

	UPROPERTY(EditAnywhere)
	int32 SpeakerId;

	UPROPERTY(EditAnywhere)
	ASkeletalMeshActor* SkeletalMeshActor;

	UPROPERTY(Transient)
	USkeletalMeshComponent* Mesh;

	UPROPERTY(Transient)
	UAnimSequenceBase* BodyIdle;

	UPROPERTY(Transient)
	UAnimSequenceBase* FaceIdle;

	UPROPERTY(Transient)
	UAnimSequenceBase* PrevDefaultAsset;

	UPROPERTY(Transient)
	UAnimSequenceBase* PrevFaceAsset;

	FTransform InitialTransform;
	int32 ModelType;

	bool bIdleBlend;
};

struct FDialogueEventParam
{
	FDialogueEventParam() : Event(EDialogueEvent::Auto), Id(0) {}

	FFrameTime Frame;
	EDialogueEvent Event;
	int32 Id;
};

UCLASS()
class Q6_API ADialoguePlayer : public AActor
{
	GENERATED_BODY()

public:
	ADialoguePlayer(const FObjectInitializer& ObjectInitializer);

	void Initialize();

	void PlaySaga(FSagaType InSagaType, bool bInPrologue, bool bInReplay, bool bInContinue = false);
	void PlayDaily(EDayOfWeekType InDayOfWeek, bool bInReplay, bool bInContinue = false);
	void PlayTraining(FTrainingCenterType InTrainingType, FSagaType InSagaType, bool bInPrologue, bool bInReplay, bool bInContinue = false);
	void PlayVacation(const FVacationResult& InResult);
	void PlayEvent(FEventContentType InEventContentType, FSagaType InSagaType, bool bInPrologue, bool bInReplay, bool bInContinue = false);
	void PlayContinue(const FDialogueRecord& DialogueRecord, const FDialogueType PlayingDialogueType);
	void GotoDialogue(int32 GotoId);

	bool IsPlayableSaga(FSagaType InSagaType);

	UFUNCTION(BlueprintCallable)
	void OnSequenceAuto();

	UFUNCTION(BlueprintCallable)
	void OnSequenceBegin(int32 Id);

	UFUNCTION(BlueprintCallable)
	void OnSequenceEnd(int32 Id);

	void OnStoryStageClear();

private:
	void PlayDialogue();

	void ResetDialogue();
	bool InitDialogue();
	void InitTitleWidgets(const FDialogueEpisodeRow* EpisodeRow);
	void InitSequenceAssets(const FDialogueStageRow* StageRow);
	void InitCharacterIntroductionInfos(const FDialogueStageRow* StageRow);
	void PlayDialogueInternal();

	void CacheAssets(const FDialogueStageRow* StageRow);

	bool InitVacationDialogue();

	const FDialogueEpisodeRow* GetEpisodeRow() const;
	const FDialogueStageRow* GetStageRow() const;
	FText GetStageSummaryText() const;
	const FCMSDialogueRow& GetDialogueRow() const;

	bool IsNeedStageTitle() const;
	bool IsVacationType() const;

	bool IsSequenceMode() const;
	bool IsAutoPlaying() const;
	bool IsFastForwarding() const;

	bool CanDialogueContinue() const;

	bool ProcessMainSequence();
	void ResumeSequence();
	void PauseSequence();
	void DestroySequenceActor();

	bool ImportSequenceEvents(ULevelSequence* Sequence);

	bool PlayMainSequence(ULevelSequence* Sequence);
	bool PlayStorySequence(ULevelSequence* Sequence);

	FDialogueSpeaker* GetValidSpeaker(int32 InSpeakerId);
	void SetSpeakerModel(int32 InSpeakerId, int32 InModelType);
	void PlaySpeakerAnimation(int32 InSpeakerId, const FString& InExpression);

	FName GetVoiceName() const;

	ACineCameraActor* GetCamera(EDialogueCamera InCameraType) const;

	void SetNoneCamera();
	void SetCamera(const FCMSDialogueRow& Row);

	void ArrangeSpeakers(const FCMSDialogueRow& Row);
	void HideAllSpeakers();

	void SetBackground(const FString& InAssetName);
	void ClearBackgroundActor();
	void ClearBackground();

	void SetCameraEffects(const TArray<int32>& InEffects, bool bPreset);
	void RestoreCameraEffects(bool bPreset);

	void SetCameraAnim(int32 AnimIndex);
	void StopCameraAnim();

	void SetChoices(const FCMSDialogueRow& InChoiceRow);
	void DefaultChoiceBySkip();

	void ShowNextDialogue();
	void ShowNextDialogueInternal();

	bool ShowCharacterIntroduction(FCharacterIntroductionInfo* InInfo);

	void PresetShowDialogue(bool bBlackout);
	void PostsetShowDialogue(bool bBlackout);

	void OnEpisodeTitleEnd();
	void OnStageTitleEnd();
	void OnVacationResultClosed();

	void OnBanChoice(int32 ChoiceIndex, bool bBanChoice);

	void OnDialogueQuit(bool bError);
	void OnSagaQuit(bool bError, bool& bOutLobbyBGM);
	void OnVacationQuit(bool bError);

	void OnDialogueSkip();
	void OnDialogueBottomSkip();
	void OnDialogueEndAnimFinished();

	void InitDialogueRecording();
	void UpdateDialogueRecording();

	void HideCharacterIntroduction();
	void HideForStorySequence(bool bHide);

	UFUNCTION()
	void OnDialogueEnd();

	UFUNCTION()
	void OnStorySequenceEnd();

	UFUNCTION()
	void OnCharacterIntroductionEnd();

	UPROPERTY(EditDefaultsOnly, Category = "Localization")
	TArray<UStringTable*> DialogueStringTables;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* SagaEpisodeTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* SagaStageTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* DailyEpisodeTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* DailyStageTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* TrainingEpisodeTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* TrainingStageTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* VacationTemplete;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* DialogueAnimAssetTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* DialogueCameraEffectTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* DialogueBGAssetTable;

	UPROPERTY(EditDefaultsOnly)
	UDataTable* DialogueCameraAnimTable;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UStageTitleWidget> StageTitleClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UVacationResultWidget> VacationResultClass;

	UPROPERTY(Transient)
	UDataTable* DialogueTable;

	UPROPERTY(Transient)
	UDialogueWidget* DialogueWidget;

	UPROPERTY(Transient)
	UEpisodeTitleWidget* EpisodeTitleWidget;

	UPROPERTY(Transient)
	UStageTitleWidget* StageTitleWidget;

	UPROPERTY(Transient)
	UVacationResultWidget* VacationResultWidget;

	/**
	* Manual mode stuff
	*/

	UPROPERTY(EditInstanceOnly, Category = "Speaker")
	TArray<FDialogueSpeaker> Speakers;

	UPROPERTY(EditInstanceOnly, Category = "Camera")
	ACineCameraActor* NoneCamera;

	UPROPERTY(EditInstanceOnly, Category = "Camera")
	ACineCameraActor* SpeakersCamera;

	UPROPERTY(EditInstanceOnly, Category = "Camera")
	ACineCameraActor* Speaker1Camera;

	UPROPERTY(EditInstanceOnly, Category = "Camera")
	ACineCameraActor* Speaker2Camera;

	UPROPERTY(EditInstanceOnly, Category = "Camera")
	APostProcessVolume* PostProcessVolume;

	/**
	* Sequence stuff
	*/

	UPROPERTY(Transient)
	UGameAssetCache* AssetCache;

	UPROPERTY(Transient)
	ALevelSequenceActor* SequenceActor;

	UPROPERTY(Transient)
	ULevelSequencePlayer* SequencePlayer;

	// AssetCache hold sequences.

	ULevelSequence* MainSequence;
	TMap<int32, ULevelSequence*> StorySequences;
	TArray<FDialogueEventParam> SequenceEvents;

	/**
	* Character Introduction stuff
	*/
	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCharacterIntroductionWidget> CharacterIntroductionWidgetClass;

	UCharacterIntroductionWidget* CharacterIntroductionWidget;
	TMap<int32, FCharacterIntroductionInfo> CharacterIntroductionInfos;

	/**
	* And some stuff
	*/

	UPROPERTY(EditInstanceOnly, Category = "DirectionalLight")
	AQ6DirectionalLight* MainDirectionalLight;

	UPROPERTY(EditInstanceOnly, Category = "BG")
	AActor* BGActor;

	UPROPERTY(Transient)
	AActor* BGAssetActor;

	UPROPERTY(Transient)
	TArray<UDialogueCameraEffect*> CameraEffects;

	bool bInitialized;
	bool bContinue;

	EDialogueType DialogueType;
	bool bPrologue;
	bool bReplay;

	// saga style
	FSagaType SagaType;
	int32 Episode;
	int32 Stage;

	// daily style
	EDayOfWeekType DayOfWeek;

	// training style
	FTrainingCenterType TrainingCenterType;

	// vacation style
	FVacationResult VacationResult;

	// event style
	FEventContentType EventContentType;

	int32 StartId;
	int32 EndId;
	int32 DialogueId;
	FText Summary;

	FString BGAssetName;
	FString BGActorPath;
	FString TodPresetName;

	FTransform DefaultCameraXform[EDialogueCameraMax];
	TArray<int32> ChoiceNextDialogueIds;

	int32 DialoguePlayingCount;
};
