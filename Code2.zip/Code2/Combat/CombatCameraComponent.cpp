// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatCameraComponent.h"
#include "Camera/CameraActor.h"
#include "Engine/World.h"

#if WITH_EDITORONLY_DATA

#include "RawMesh.h"
#include "Misc/FeedbackContext.h"
#include "UnrealEd.h"
#include "PropertyEditing.h"
#include "PropertyCustomizationHelpers.h"

#define LOCTEXT_NAMESPACE "CombatCameraComponentDetails"

class FCombatCameraComponentDetails : public IDetailCustomization
{
public:
	/* Make a new instance for specific detail view */
	static TSharedRef<IDetailCustomization> MakeInstance();

private:
	/* IDetailCustomization interface */
	virtual void CustomizeDetails(IDetailLayoutBuilder& DetailLayout) override;

	FReply OnUpdateCulling();
	FReply OnHideCulledActors();
	FReply OnShowCulledActors();
	FReply OnSelectCulledActors();
	FReply OnSpawnCameraActor();

private:
	TArray<TWeakObjectPtr<UCombatCameraComponent>> CombatCameraComponentList;
};

TSharedRef<IDetailCustomization> FCombatCameraComponentDetails::MakeInstance()
{
	return MakeShareable(new FCombatCameraComponentDetails);
}

void FCombatCameraComponentDetails::CustomizeDetails(IDetailLayoutBuilder& DetailLayout)
{
	const TArray<TWeakObjectPtr<UObject>>& SelectedObjects = DetailLayout.GetDetailsView()->GetSelectedObjects();

	for (int32 ObjectIndex = 0; ObjectIndex < SelectedObjects.Num(); ++ObjectIndex)
	{
		const TWeakObjectPtr<UObject>& CurrentObject = SelectedObjects[ObjectIndex];
		if (CurrentObject.IsValid())
		{
			UCombatCameraComponent* CurrentCameraComponent = Cast<UCombatCameraComponent>(CurrentObject.Get());
			if (CurrentCameraComponent != NULL)
			{
				CombatCameraComponentList.Add(CurrentCameraComponent);
			}

			AActor* Actor = Cast<AActor>(CurrentObject.Get());
			if (Actor)
			{
				TInlineComponentArray<UCombatCameraComponent*> Components;
				Actor->GetComponents(Components);

				for (UCombatCameraComponent* CombatCameraComponent : Components)
				{
					CombatCameraComponentList.Add(CombatCameraComponent);
				}
			}
		}
	}

	DetailLayout.EditCategory("Combat Camera Culling")
		.AddCustomRow(NSLOCTEXT("CombatCameraComponentDetails", "Update Culling", "Update Culling"))
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		[
			SNew(SBox)
			.WidthOverride(125)
			[
				SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Center)
				.OnClicked(this, &FCombatCameraComponentDetails::OnUpdateCulling)
				[
					SNew(STextBlock)
					.Text(NSLOCTEXT("CombatCameraComponentDetails", "Update Culling", "Update Culling"))
					.Font(IDetailLayoutBuilder::GetDetailFont())
				]
			]
		];

	DetailLayout.EditCategory("Combat Camera Culling")
		.AddCustomRow(NSLOCTEXT("CombatCameraComponentDetails", "Hide Culled Actors", "Hide Culled Actors"))
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		[
			SNew(SBox)
			.WidthOverride(125)
			[
				SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Center)
				.OnClicked(this, &FCombatCameraComponentDetails::OnHideCulledActors)
				[
					SNew(STextBlock)
					.Text(NSLOCTEXT("CombatCameraComponentDetails", "Hide Culled Actors", "Hide Culled Actors"))
					.Font(IDetailLayoutBuilder::GetDetailFont())
				]
			]
		];

	DetailLayout.EditCategory("Combat Camera Culling")
		.AddCustomRow(NSLOCTEXT("CombatCameraComponentDetails", "Show Culled Actors", "Show Culled Actors"))
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		[
			SNew(SBox)
			.WidthOverride(125)
			[
				SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Center)
				.OnClicked(this, &FCombatCameraComponentDetails::OnShowCulledActors)
				[
					SNew(STextBlock)
					.Text(NSLOCTEXT("CombatCameraComponentDetails", "Show Culled Actors", "Show Culled Actors"))
					.Font(IDetailLayoutBuilder::GetDetailFont())
				]
			]
		];

	DetailLayout.EditCategory("Combat Camera Culling")
		.AddCustomRow(NSLOCTEXT("CombatCameraComponentDetails", "Select Culled Actors", "Select Culled Actors"))
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		[
			SNew(SBox)
			.WidthOverride(125)
			[
				SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Center)
				.OnClicked(this, &FCombatCameraComponentDetails::OnSelectCulledActors)
				[
					SNew(STextBlock)
					.Text(NSLOCTEXT("CombatCameraComponentDetails", "Select Culled Actors", "Select Culled Actors"))
					.Font(IDetailLayoutBuilder::GetDetailFont())
				]
			]
		];

	DetailLayout.EditCategory("Combat Camera")
		.AddCustomRow(NSLOCTEXT("CombatCameraComponentDetails", "Spawn Combat Camera Actor", "Spawn Camera Actor"))
		.NameContent()
		[
			SNullWidget::NullWidget
		]
		.ValueContent()
		[
			SNew(SBox)
			.WidthOverride(125)
			[
				SNew(SButton)
				.ContentPadding(3)
				.VAlign(VAlign_Center)
				.HAlign(HAlign_Center)
				.OnClicked(this, &FCombatCameraComponentDetails::OnSpawnCameraActor)
				[
					SNew(STextBlock)
					.Text(NSLOCTEXT("CombatCameraComponentDetails", "Spawn Combat Camera Actor", "Spawn Camera Actor"))
					.Font(IDetailLayoutBuilder::GetDetailFont())
				]
			]
		];
}

FReply FCombatCameraComponentDetails::OnUpdateCulling()
{
	for (auto& Component : CombatCameraComponentList)
	{
		if (Component.IsValid())
		{
			Component->UpdateCulling();
		}
	}

	return FReply::Handled();
}

FReply FCombatCameraComponentDetails::OnHideCulledActors()
{
	for (auto& Component : CombatCameraComponentList)
	{
		if (Component.IsValid())
		{
			Component->HideCulledActorForEditor(true);
		}
	}

	return FReply::Handled();
}

FReply FCombatCameraComponentDetails::OnShowCulledActors()
{
	for (auto& Component : CombatCameraComponentList)
	{
		if (Component.IsValid())
		{
			Component->HideCulledActorForEditor(false);
		}
	}

	return FReply::Handled();
}

FReply FCombatCameraComponentDetails::OnSelectCulledActors()
{
	for (auto& Component : CombatCameraComponentList)
	{
		if (Component.IsValid())
		{
			Component->SelectCulledActorForEditor();
		}
	}

	return FReply::Handled();
}

FReply FCombatCameraComponentDetails::OnSpawnCameraActor()
{
	for (auto& ComponentPtr : CombatCameraComponentList)
	{
		if (ComponentPtr.IsValid())
		{
			UCombatCameraComponent* Component = ComponentPtr.Get();
			Component->SpawnCloneCameraActor();
		}
	}

	return FReply::Handled();
}

#endif // WITH_EDITORONLY_DATA


UCombatCameraComponent::UCombatCameraComponent()
{
	CullViewDistance = 5000;
	bUpdateCullWhileBuild = true;
	bHiddenCulledActorInGame = false;
}

#if WITH_EDITORONLY_DATA

void UCombatCameraComponent::RegisterCustomDetails()
{
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomClassLayout("CombatCameraComponent", FOnGetDetailCustomizationInstance::CreateStatic(&FCombatCameraComponentDetails::MakeInstance));
}

static bool _CullTest(const UCombatCameraComponent* CombatCameraComponent, const FTransform& MeshTransform, UStaticMesh* Mesh, const AActor* ExcludeActor)
{
	if (!Mesh->IsSourceModelValid(0))
	{
		return false;
	}

	// Extract the raw mesh
	FRawMesh RawMesh;
	Mesh->GetSourceModel(0).RawMeshBulkData->LoadRawMesh(RawMesh);

	int32 FaceCount = RawMesh.WedgeIndices.Num() / 3;
	ensure(FaceCount == RawMesh.FaceMaterialIndices.Num());

	FScopedSlowTask FaceSlowTask(FaceCount);
	FaceSlowTask.MakeDialog();

	FCollisionQueryParams CollisionQueryParams;
	CollisionQueryParams.bTraceComplex = true;
	CollisionQueryParams.AddIgnoredActor(ExcludeActor);

	bool bFoundVisibleVertex = false;
	for (int32 FaceIndex = 0; FaceIndex < FaceCount; ++FaceIndex)
	{
		FaceSlowTask.EnterProgressFrame(1, FText::FromString(TEXT("Culling : Processing face")));

		uint32 FaceVertexIndices[] =
		{
			RawMesh.WedgeIndices[FaceIndex * 3 + 0],
			RawMesh.WedgeIndices[FaceIndex * 3 + 1],
			RawMesh.WedgeIndices[FaceIndex * 3 + 2]
		};

		FVector FaceVerts[] =
		{
			RawMesh.VertexPositions[FaceVertexIndices[0]],
			RawMesh.VertexPositions[FaceVertexIndices[1]],
			RawMesh.VertexPositions[FaceVertexIndices[2]]
		};

		// Find shortest edge
		float ShortestEdgeLength = 10E5;
		int32 ShortestEdge = 0;
		for (int32 i = 0; i < 3; ++i)
		{
			FVector EdgeVert0 = FaceVerts[i];
			FVector EdgeVert1 = FaceVerts[(i + 1) % 3];
			float EdgeLength = (EdgeVert1 - EdgeVert0).Size();
			if (EdgeLength < ShortestEdgeLength)
			{
				ShortestEdgeLength = EdgeLength;
				ShortestEdge = i;
			}
		}

		if (ShortestEdgeLength < 0.0001f)
		{
			// Degenerated triangle found
			continue;
		}

		FVector LongEdgeVertex = FaceVerts[(ShortestEdge + 2) % 3];
		FVector ShortestEdgeVertices[] =
		{
			FaceVerts[ShortestEdge],
			FaceVerts[(ShortestEdge + 1) % 3]
		};

		// Divide shortest edge
		const float EdgeSegmentSize = 50.0f;
		int32 ShortestEdgeSegmentCount = FPlatformMath::CeilToInt(ShortestEdgeLength / EdgeSegmentSize);
		FVector ShortestEdgeSegmentUnit = (ShortestEdgeVertices[1] - ShortestEdgeVertices[0]) / ShortestEdgeSegmentCount;

		for (int32 ShortestEdgeSegment = 0; ShortestEdgeSegment <= ShortestEdgeSegmentCount; ++ShortestEdgeSegment)
		{
			FVector ShortEdgeSegmentVertex = ShortestEdgeVertices[0] + (ShortestEdgeSegmentUnit * ShortestEdgeSegment);

			// Divide long edge
			float LongEdgeLength = (LongEdgeVertex - ShortEdgeSegmentVertex).Size();
			int32 LongEdgeSegmentCount = FPlatformMath::CeilToInt(LongEdgeLength / EdgeSegmentSize);
			FVector LongEdgeSegmentUnit = (LongEdgeVertex - ShortEdgeSegmentVertex) / LongEdgeSegmentCount;

			for (int32 LongEdgeSegment = 0; LongEdgeSegment <= LongEdgeSegmentCount; ++LongEdgeSegment)
			{
				FVector LongEdgeSegmentVertex = ShortEdgeSegmentVertex + (LongEdgeSegmentUnit * LongEdgeSegment);

				FVector VertexWorldPosition = MeshTransform.TransformPosition(LongEdgeSegmentVertex);
				FVector VertexPositionInCameraSpace = CombatCameraComponent->GetComponentTransform().InverseTransformPosition(VertexWorldPosition);
				float Distance = VertexPositionInCameraSpace.Size();
				if (Distance > CombatCameraComponent->CullViewDistance)
				{
					continue;
				}

				FVector VertexPositionInCameraSpaceN = Distance > 0 ? VertexPositionInCameraSpace / Distance : FVector::ZeroVector;

				float Yaw = FPlatformMath::Atan2(VertexPositionInCameraSpaceN.Y, VertexPositionInCameraSpaceN.X);
				float Pitch = FPlatformMath::Atan2(VertexPositionInCameraSpaceN.Z, VertexPositionInCameraSpaceN.X);

				if (FPlatformMath::Abs(Pitch) > FMath::DegreesToRadians(CombatCameraComponent->FieldOfView * 0.5f / CombatCameraComponent->AspectRatio))
				{
					continue;
				}

				if (FPlatformMath::Abs(Yaw) > FMath::DegreesToRadians(CombatCameraComponent->FieldOfView * 0.5f))
				{
					continue;
				}

				FHitResult HitResult;
				
				bool bHasCollision = CombatCameraComponent->GetWorld()->LineTraceSingleByChannel(
					HitResult,
					CombatCameraComponent->GetComponentLocation(),
					VertexWorldPosition,
					ECC_Visibility,
					CollisionQueryParams);

				if (!bHasCollision)
				{
					bFoundVisibleVertex = true;
					break;
				}
			}

			if (bFoundVisibleVertex)
			{
				break;
			}
		}

		if (bFoundVisibleVertex)
		{
			break;
		}
	}

	return bFoundVisibleVertex;
}

static bool _CullTestByBounds(const UCombatCameraComponent* CombatCameraComponent, const FBoxSphereBounds& Bounds, const AActor* ExcludeActor)
{
	FCollisionQueryParams CollisionQueryParams;
	CollisionQueryParams.bTraceComplex = true;
	CollisionQueryParams.AddIgnoredActor(ExcludeActor);

	bool bFoundVisiblePoint = false;

	const float BaseSegmentSize = 50.0f;
	const FVector BoundOrigin = Bounds.GetBox().GetCenter() - Bounds.GetBox().GetExtent();
	const FVector BoundSize = Bounds.GetBox().GetSize();
	const FIntVector SegmentCount(
		FPlatformMath::CeilToInt(BoundSize.X / BaseSegmentSize),
		FPlatformMath::CeilToInt(BoundSize.Y / BaseSegmentSize),
		FPlatformMath::CeilToInt(BoundSize.Z / BaseSegmentSize));

	const FVector SegmentSize(
		SegmentCount.X ? BoundSize.X / SegmentCount.X : 0.f,
		SegmentCount.Y ? BoundSize.Y / SegmentCount.Y : 0.f,
		SegmentCount.Z ? BoundSize.Z / SegmentCount.Z : 0.f);

	for (int32 X = 0; X < SegmentCount.X; ++X)
	{
		for (int32 Y = 0; Y < SegmentCount.Y; ++Y)
		{
			for (int32 Z = 0; Z < SegmentCount.Z; ++Z)
			{
				const FVector Point = BoundOrigin + (SegmentSize * FVector(X, Y, Z));

				FVector PointInCameraSpace = CombatCameraComponent->GetComponentTransform().InverseTransformPosition(Point);

				if (PointInCameraSpace.X < 0)
				{
					continue;
				}

				float Distance = PointInCameraSpace.Size();
				if (Distance > CombatCameraComponent->CullViewDistance)
				{
					continue;
				}

				FVector PointInCameraSpaceN = Distance > 0 ? PointInCameraSpace / Distance : FVector::ZeroVector;

				float Yaw = FPlatformMath::Atan2(PointInCameraSpaceN.Y, PointInCameraSpaceN.X);
				float Pitch = FPlatformMath::Atan2(PointInCameraSpaceN.Z, PointInCameraSpaceN.X);

				if (FPlatformMath::Abs(Pitch) > FMath::DegreesToRadians(CombatCameraComponent->FieldOfView * 0.5f / CombatCameraComponent->AspectRatio))
				{
					continue;
				}

				if (FPlatformMath::Abs(Yaw) > FMath::DegreesToRadians(CombatCameraComponent->FieldOfView * 0.5))
				{
					continue;
				}

				FHitResult HitResult;

				bool bHasCollision = CombatCameraComponent->GetWorld()->LineTraceSingleByChannel(
					HitResult,
					CombatCameraComponent->GetComponentLocation(),
					Point,
					ECC_Visibility,
					CollisionQueryParams);

				if (!bHasCollision)
				{
					bFoundVisiblePoint = true;
					break;
				}
			}
		}
	}

	return bFoundVisiblePoint;
}

void UCombatCameraComponent::UpdateCulling()
{
	CulledActorList.Empty();

	FVector CameraLocation = GetComponentLocation();
	
	TArray<AStaticMeshActor*> MeshActorList;
	TArray<AEmitter*> EmitterActorList;

	for (TActorIterator<AStaticMeshActor> It(GetWorld(), AStaticMeshActor::StaticClass()); It; ++It)
	{
		AStaticMeshActor* Actor = *It;

		if (Actor->IsHidden())
		{
			// Already set as hidden, mostly merged meshes
			continue;
		}

		MeshActorList.Add(Actor);
	}

	for (TActorIterator<AEmitter> It(GetWorld(), AEmitter::StaticClass()); It; ++It)
	{
		AEmitter* Actor = *It;

		if (Actor->IsHidden())
		{
			// Already set as hidden, mostly merged meshes
			continue;
		}

		EmitterActorList.Add(Actor);
	}

	{
		FScopedSlowTask SlowTask(MeshActorList.Num());
		SlowTask.MakeDialog();

		for (int32 ActorIndex = 0; ActorIndex < MeshActorList.Num(); ++ActorIndex)
		{
			AStaticMeshActor* MeshActor = MeshActorList[ActorIndex];

			SlowTask.EnterProgressFrame(1, FText::FromString(FString::Printf(TEXT("Culling : Processing Mesh (%s)"), *MeshActor->GetName())));

			UStaticMesh* Mesh = MeshActor->GetStaticMeshComponent()->GetStaticMesh();
			if (!Mesh || !Mesh->IsSourceModelValid(0))
			{
				continue;
			}

			if (!Mesh->GetSourceModel(0).RawMeshBulkData->IsEmpty())
			{
				bool bActorVisible = _CullTest(this, MeshActor->GetStaticMeshComponent()->GetComponentTransform(), Mesh, MeshActor);

				if (!bActorVisible)
				{
					CulledActorList.Add(MeshActor);
				}
			}
		}
	}

	{
		FScopedSlowTask SlowTask(EmitterActorList.Num());
		SlowTask.MakeDialog();

		for (int32 ActorIndex = 0; ActorIndex < EmitterActorList.Num(); ++ActorIndex)
		{
			AEmitter* Actor = EmitterActorList[ActorIndex];

			SlowTask.EnterProgressFrame(1, FText::FromString(FString::Printf(TEXT("Culling : Processing Emitter (%s)"), *Actor->GetName())));

			UParticleSystemComponent* Particle = Actor->GetParticleSystemComponent();

			if (!Particle)
			{
				continue;
			}

			bool bActorVisible = _CullTestByBounds(this, Particle->CalcBounds(Particle->GetComponentToWorld()), Actor);

			if (!bActorVisible)
			{
				CulledActorList.Add(Actor);
			}
		}
	}
}

void UCombatCameraComponent::HideCulledActorForEditor(bool bHide)
{
	for (AActor* Actor : CulledActorList)
	{
		if (Actor)
		{
			Actor->SetIsTemporarilyHiddenInEditor(bHide);
		}
	}

	for (AActor* Actor : ForceHideActorList)
	{
		if (Actor)
		{
			Actor->SetIsTemporarilyHiddenInEditor(bHide);
		}
	}

	for (AActor* Actor : ForceShowActorList)
	{
		if (Actor)
		{
			Actor->SetIsTemporarilyHiddenInEditor(false);
		}
	}
}

void UCombatCameraComponent::SelectCulledActorForEditor()
{
	for (AActor* Actor : CulledActorList)
	{
		if (Actor)
		{
			GEditor->SelectActor(Actor, true, false, true);
		}
	}
}

#endif // WITH_EDITORONLY_DATA

void UCombatCameraComponent::HideCulledActorInGame(bool bHide)
{
	if (bHiddenCulledActorInGame == bHide)
	{
		return;
	}

	//Q3LogSunny(Display, "HideCulledActorInGame", TEXT("Value: %s"), bHide ? TEXT("Hide") : TEXT("Show"));

	bHiddenCulledActorInGame = bHide;

	for (AActor* Actor : CulledActorList)
	{
		if (Actor)
		{
			Actor->SetActorHiddenInGame(bHide);
		}
	}

	for (AActor* Actor : ForceHideActorList)
	{
		if (Actor)
		{
			Actor->SetActorHiddenInGame(bHide);
		}
	}

	for (AActor* Actor : ForceShowActorList)
	{
		if (Actor)
		{
			Actor->SetActorHiddenInGame(false);
		}
	}
}

void UCombatCameraComponent::CopyCameraParamsTo(UCameraComponent* TargetComponent)
{
	TargetComponent->FieldOfView = FieldOfView;
	TargetComponent->AspectRatio = AspectRatio;
	TargetComponent->bConstrainAspectRatio = bConstrainAspectRatio;
	TargetComponent->ProjectionMode = ProjectionMode;
	TargetComponent->OrthoWidth = OrthoWidth;
	TargetComponent->PostProcessBlendWeight = PostProcessBlendWeight;
	TargetComponent->PostProcessSettings = PostProcessSettings;
}

ACameraActor* UCombatCameraComponent::SpawnCloneCameraActor()
{
	FActorSpawnParameters SpawnParam;
	SpawnParam.Name = MakeUniqueObjectName(GetWorld(), ACameraActor::StaticClass(), *FString::Printf(TEXT("TempCamera_%s"), *GetOwner()->GetName()));
	SpawnParam.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	ACameraActor* CameraActor = GetWorld()->SpawnActor<ACameraActor>(
		GetComponentTransform().GetLocation(),
		GetComponentTransform().Rotator(),
		SpawnParam);

	CopyCameraParamsTo(CameraActor->GetCameraComponent());

	return CameraActor;
}

#undef LOCTEXT_NAMESPACE