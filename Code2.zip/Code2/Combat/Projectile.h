// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "Q6Define.h"
#include "Unit.h"
#include "GameFramework/Actor.h"
#include "Projectile.generated.h"

/**
 * Visual represent of Combat Cube Projectile
 */
UCLASS()
class Q6_API AProjectile : public AActor
{
	GENERATED_BODY()
	
public:
	AProjectile(const FObjectInitializer& ObjectInitializer);

	void SetParticleRotation(const FVector& InParticleRotation) { ParticleRotation = InParticleRotation; }
	void SetSpeed(float InSpeed) { Speed = InSpeed; }
	void SetPassThrough(bool bInPassThrough) { bPassThrough = bInPassThrough; }

	void SetSourceUnit(AUnit* Unit) { SourceUnit = Unit; }
	void SetTargetUnit(AUnit* Unit, const FName& Socket, const FPostHitInfo& InHitInfo, const FSpawnParticleParams& InHitParticleParam, const FSpawnSoundParams& InHitSoundParam);

	void SetStartLocation(const FVector& InLocation) { StartLocation = InLocation; }
	void SetTargetLocation(const FVector& InLocation) { TargetLocation = InLocation; }

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	float GetEstimatedLifeSpan() const { return EstimatedLifeSpan; }

	void ProjectileHit();

	UFUNCTION(BlueprintImplementableEvent, Category = "Skill")
	void OnProjectileHit();

	UFUNCTION(BlueprintCallable, Category = "Skill")
	FVector GetTargetBottomLocation() const;

	UFUNCTION(BlueprintCallable, Category = "Skill")
	AUnit* GetSourceUnit() const { return SourceUnit; }

	UFUNCTION(BlueprintCallable, Category = "Skill")
	AUnit* GetTargetUnit() const { return TargetUnit; }

private:
	FVector GetMovingLocationOffset(float TimeRate) const;

	void UpdateHit();

	void DeactivateParticles();
	void DestroyAfterDeactivate();

	void OnDestroyTimeout();

public:
	UPROPERTY(EditDefaultsOnly, Category = "Projectile")
	UCurveVector* MovingLocationOffsetCurve;

	UPROPERTY(EditDefaultsOnly, Category = "Projectile")
	float OffsetRateMin;

	UPROPERTY(EditDefaultsOnly, Category = "Projectile")
	float OffsetRateMax;

	UPROPERTY(BlueprintReadOnly, Category = "Projectile")
	float AgeRatio;

private:
	FVector ParticleRotation;
	float Speed;
	bool bPassThrough;

	UPROPERTY(Transient)
	AUnit* SourceUnit;

	UPROPERTY(Transient)
	AUnit* TargetUnit;

	FName TargetSocket;
	bool bUnitTarget;

	FVector StartLocation;
	FVector TargetLocation;

	float StartTime;
	float EstimatedLifeSpan;
	float OffsetRate;

	FTimerHandle DeactivateTimer;
	FTimerHandle DestroyTimer;

	// Hit
	FSpawnParticleParams HitParticleParam;
	FSpawnSoundParams HitSoundParam;
	FPostHitInfo HitInfo;

	FVector DirBeforeHit;
	float HitStartTime;
	float LastHitTime;
};
