// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "ZoneAttributeActor.h"
#include "Engine.h"
#include "Q6.h"

#if WITH_EDITORONLY_DATA
FText GetEnumToText(EZoneAttribute value)
{
	const UEnum* enumPtr = FindObject<UEnum>(ANY_PACKAGE, TEXT("EZoneAttribute"), true);
	if (!enumPtr)
	{
		return FText::FromString(TEXT("Invalid Enum"));
	}
	return enumPtr->GetDisplayNameTextByIndex((int32)value);;
}
#endif

AZoneAttributeActor::AZoneAttributeActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ZoneAttribute(EZoneAttribute::Ground)
{
	PrimaryActorTick.bCanEverTick = false;

#if WITH_EDITORONLY_DATA
	if (!IsRunningCommandlet())
	{
		TextRender = ObjectInitializer.CreateEditorOnlyDefaultSubobject<UTextRenderComponent>(this, TEXT("TextComponent"));

		if (TextRender)
		{
			RootComponent = TextRender;
			TextRender->XScale = 5;
			TextRender->YScale = 5;
			UpdateTextRenderText();
			TextRender->SetHiddenInGame(true);
		}
	}
#endif // WITH_EDITORONLY_DATA
}

#if WITH_EDITOR

void AZoneAttributeActor::UpdateTextRenderText()
{
	if (TextRender)
	{
		TextRender->SetText(GetEnumToText(ZoneAttribute));
	}
}

void AZoneAttributeActor::PostLoad()
{
	Super::PostLoad();

	UpdateTextRenderText();
}

void AZoneAttributeActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (!GetWorld())
	{
		// looks like changing default, not instance
		return;
	}

	UpdateTextRenderText();
}

#endif // WITH_EDITOR