// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "GameFramework/Actor.h"
#include "Particles/ParticleSystemComponent.h"
#include "Q6Minimal.h"
#include "Q6Define.h"
#include "TodBranchActor.generated.h"

class UParticleSystem;
class UStaticMesh;
class UMaterialInterface;
class AStaticMeshActor;
class AInstancedStaticMeshActor;

USTRUCT(BlueprintType)
struct FQ6BranchParticle
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	FName Comment;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch, meta = (MakeEditWidget = true))
	FTransform LocalTM;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<struct FParticleSysParam> InstanceParameters;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TSoftObjectPtr<UParticleSystem> Particle;
};

USTRUCT(BlueprintType)
struct FQ6BranchStaticMesh
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	FName Comment;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch, meta = (MakeEditWidget = true))
	FTransform LocalTM;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TSoftObjectPtr<UStaticMesh> StaticMesh;
};

USTRUCT(BlueprintType)
struct FQ6BranchMaterialSlot
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	int32 Slot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TSoftObjectPtr<UMaterialInterface> Material;
};

USTRUCT(BlueprintType)
struct FQ6BranchMaterialOverrideActor
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	FName Comment;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch, meta = (AllowedClasses="StaticMeshActor,SkeletalMeshActor"))
	AActor* Actor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchMaterialSlot> MaterialSlots;
};

USTRUCT(BlueprintType)
struct FQ6BranchInstanceSlot
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	int32 InstanceID;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchMaterialSlot> MaterialSlots;
};

USTRUCT(BlueprintType)
struct FQ6BranchMaterialOverrideInstancedActor
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	FName Comment;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	AInstancedStaticMeshActor* MergedActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchInstanceSlot> InstanceSlots;
};

USTRUCT(BlueprintType)
struct FQ6BranchObject
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchParticle> Particles;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchStaticMesh> StaticMeshes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchMaterialOverrideActor> MaterialOverrideActors;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchMaterialOverrideInstancedActor> MaterialOverrideInstancedActors;
};

UCLASS(DontCollapseCategories)
class Q6_API AInstancedStaticMeshActor : public AActor
{
	GENERATED_BODY()

public:
	AInstancedStaticMeshActor(const FObjectInitializer& ObjectInitializer);
};

UCLASS(DontCollapseCategories)
class Q6_API ATodBranchActor : public AActor
{
	GENERATED_BODY()

public:
	ATodBranchActor(const FObjectInitializer& ObjectInitializer);

	void ActivateBranch(int32 index);
#if WITH_EDITOR
	virtual void PostLoad() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

public:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TArray<FQ6BranchObject> Branches;
};