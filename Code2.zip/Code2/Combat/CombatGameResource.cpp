// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatGameResource.h"
#include "CMSTable.h"
#include "Q6Log.h"

UCurveFloat* UCombatGameResource::GetCameraBlendCurve() const
{
	return CameraBlendingCurve;
}

EViewTargetBlendFunction UCombatGameResource::GetCameraBlendFunction() const
{
	return CameraBlendFunction;
}

float UCombatGameResource::GetCameraBlendExp() const
{
	return BlendExponent;
}

UCameraAnim* UCombatGameResource::GetCameraAnimation(ECombatCamera CameraType) const
{
	switch (CameraType)
	{
		case ECombatCamera::Wave:
			return CombatWaveAnim;
		case ECombatCamera::Prepare:
			return CombatPrepareAnim;
		case ECombatCamera::AllyAll:
			return CombatAllyAllAnim;
		case ECombatCamera::Ally1:
		case ECombatCamera::Ally2:
		case ECombatCamera::Ally3:
			return CombatAllyAnim;
		case ECombatCamera::Enemy1:
		case ECombatCamera::Enemy2:
		case ECombatCamera::Enemy3:
		case ECombatCamera::Enemy4:
		case ECombatCamera::Enemy5:
			return CombatEnemyAnim;
		case ECombatCamera::Result:
			return CombatResultAnim;
		default:
			return nullptr;
	}
}

void UCombatGameResource::SetUnitBarBgImage(UImage* Image, EAttributeCategory Category) const
{
	ensure(UnitBarAssetTable);

	FString CategoryStr = ENUM_TO_STRING(EAttributeCategory, Category);
	const FUnitBarAssetRow* Row = UnitBarAssetTable->FindRow<FUnitBarAssetRow>(FName(*CategoryStr), CategoryStr, false);
	if (!Row)
	{
		return;
	}

	Image->SetBrush(Row->BarBgBrush);
}

UMaterialInterface* UCombatGameResource::GetSpawnEffectMaterial(ESpawnReason InReason, int32 InIndex) const
{
	if ((InReason == ESpawnReason::Rebirth)
		|| (InReason == ESpawnReason::WipeoutContinue)
		|| (InReason == ESpawnReason::RebirthSummon))
	{
		return RebirthEffectMaterials.IsValidIndex(InIndex) ? RebirthEffectMaterials[InIndex] : nullptr;
	}
	
	return SpawnEffectMaterials.IsValidIndex(InIndex) ? SpawnEffectMaterials[InIndex] : nullptr;
}

UParticleSystem* UCombatGameResource::GetSpawnEffectParticle(ESpawnReason InReason, int32 InIndex) const
{
	if ((InReason == ESpawnReason::Rebirth)
		|| (InReason == ESpawnReason::WipeoutContinue)
		|| (InReason == ESpawnReason::RebirthSummon))
	{
		return RebirthEffectParticles.IsValidIndex(InIndex) ? RebirthEffectParticles[InIndex] : nullptr;
	}

	return SpawnEffectParticles.IsValidIndex(InIndex) ? SpawnEffectParticles[InIndex] : nullptr;
}

USoundBase* UCombatGameResource::GetSpawnEffectSound(ESpawnReason InReason) const
{
	return ((InReason == ESpawnReason::Rebirth)
		|| (InReason == ESpawnReason::WipeoutContinue)
		|| (InReason == ESpawnReason::RebirthSummon)) ? RebirthEffectSound : SpawnEffectSound;
}

UMaterialInterface* UCombatGameResource::GetDeadEffectMaterial(int32 InIndex) const
{
	return DeadEffectMaterials.IsValidIndex(InIndex) ? DeadEffectMaterials[InIndex] : nullptr;
}

UParticleSystem* UCombatGameResource::GetDeadEffectParticle(int32 InIndex) const
{
	return DeadEffectParticles.IsValidIndex(InIndex) ? DeadEffectParticles[InIndex] : nullptr;
}

void UCombatGameResource::SetAttackOrderImage(UImage* Image, int32 AttackOrderIndex)
{
	if (!AttackOrderBrushes.IsValidIndex(AttackOrderIndex))
	{
		return;
	}

	Image->SetBrush(AttackOrderBrushes[AttackOrderIndex]);
}

void UCombatGameResource::SetSkillNoteMatchedImage(UImage* Image, int32 SkillNoteIndex)
{
	if (!SkillNoteMatchedBrushes.IsValidIndex(SkillNoteIndex))
	{
		return;
	}

	Image->SetBrush(SkillNoteMatchedBrushes[SkillNoteIndex]);
}

const FCrowdControlAssetRow& UCombatGameResource::GetCrowdControlAssetRow(FCrowdControlType Type) const
{
	ensure(CrowdControlAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), Type.x);
	const FCrowdControlAssetRow* Row = CrowdControlAssetTable->FindRow<FCrowdControlAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}
	else
	{
		Q6JsonLogSunny(Warning, "Cannot find crowd control asset row", Q6KV("CrowdControlType", Type.x));
		static FCrowdControlAssetRow Dummy;
		return Dummy;
	}
}

const FBuffIcon& UCombatGameResource::GetCrowdControlIcon(FCrowdControlType Type) const
{
	ensure(CrowdControlAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), Type.x);
	const FCrowdControlAssetRow* Row = CrowdControlAssetTable->FindRow<FCrowdControlAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return Row->Icon;
	}
	else
	{
		Q6JsonLog(Error, "Cannot find crowd control asset row", Q6KV("CrowdControlType", Type.x));
		return DummyBuffIcon;
	}
}

const FBuffIcon& UCombatGameResource::GetUnitAttributeBuffIcon(FUnitAttributeType Type, int32 Value) const
{
	ensure(UnitAttributeBuffIconAssetTable);

	// Row is 1-based
	FString TypeStr = FString::Printf(TEXT("%d"), (int32)Type + 1);
	const FUnitAttributeBuffIconAssetRow* Row = UnitAttributeBuffIconAssetTable->FindRow<FUnitAttributeBuffIconAssetRow>(FName(*TypeStr), TypeStr, false);
	if (Row)
	{
		if (Value < 0)
		{
			return Row->DebuffIcon;
		}
		else
		{
			return Row->BuffIcon;
		}
	}

	return DummyBuffIcon;
}

const FBuffIcon& UCombatGameResource::GetMomentIcon(EMoment Moment) const
{
	ensure(MomentIconAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), (int32)Moment);
	const FMomentIconAssetRow* Row = MomentIconAssetTable->FindRow<FMomentIconAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return Row->Icon;
	}
	else
	{
		Q6JsonLog(Error, "Cannot find moment icon asset row", Q6KV("Moment", (int32)Moment));
		return DummyBuffIcon;
	}
}

const FBuffIcon& UCombatGameResource::GetEffectCategoryIcon(EEffectCategory EffectCategory, int32 Value) const
{
	ensure(EffectCategoryIconAssetTable);

	// Row is 1-based
	FString TypeStr = FString::Printf(TEXT("%d"), (int32)EffectCategory + 1);
	const FEffectCategoryIconAssetRow* Row = EffectCategoryIconAssetTable->FindRow<FEffectCategoryIconAssetRow>(FName(*TypeStr), TypeStr, false);
	if (Row)
	{
		if (Value < 0)
		{
			return Row->NegativeIcon;
		}
		else
		{
			return Row->PositiveIcon;
		}
	}

	return DummyBuffIcon;
}

const FBuffIcon& UCombatGameResource::GetPointVaryIcon(EPointVaryState PointVaryState) const
{
	switch (PointVaryState)
	{
		case EPointVaryState::Consume:
			return PointVaryConsumeIcon;
		case EPointVaryState::Convert:
			return PointVaryConvertIcon;
		default:
			break;
	}

	return DummyBuffIcon;
}

const FSubMaterialEffectParams& UCombatGameResource::GetBuffEffectMaterialParams(bool bDemerit) const
{
	return bDemerit ? DebuffEffectMaterialParams : BuffEffectMaterialParams;
}

const FSpawnParticleParams& UCombatGameResource::GetBuffEffectParticleParams(bool bDemerit) const
{
	return bDemerit ? DebuffEffectParticleParams : BuffEffectParticleParams;
}

USoundBase* UCombatGameResource::GetBuffEffectSound(bool bDemerit) const
{
	return bDemerit ? DebuffEffectSound : BuffEffectSound;
}