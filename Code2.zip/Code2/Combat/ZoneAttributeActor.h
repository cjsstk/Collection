// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "GameFramework/Actor.h"
#include "Q6Define.h"
#include "ZoneAttributeActor.generated.h"

class UCombatCameraComponent;
class UBillboardComponent;
class UArrowComponent;
class UTextRenderComponent;
class AUnit;

UCLASS()
class Q6_API AZoneAttributeActor : public AActor
{
	GENERATED_BODY()

public:
	AZoneAttributeActor(const FObjectInitializer& ObjectInitializer);

#if WITH_EDITOR
	virtual void PostLoad() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	void UpdateTextRenderText();
#endif
	EZoneAttribute GetZoneAttribute() const { return ZoneAttribute; };
private:
	UPROPERTY(EditInstanceOnly, Category = "Zone Attribute")
	EZoneAttribute ZoneAttribute;

#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
	UTextRenderComponent* TextRender;
#endif
};