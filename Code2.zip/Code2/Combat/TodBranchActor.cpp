// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "TodBranchActor.h"
#include "Engine.h"
#include "Q6.h"
#include "Engine/StaticMesh.h"
#include "Engine/StaticMeshActor.h"
#include "Animation/SkeletalMeshActor.h"
#include "Particles/ParticleSystem.h"
#include "Components/StaticMeshComponent.h"
#include "Components/InstancedStaticMeshComponent.h"
#include "Components/SkeletalMeshComponent.h"

AInstancedStaticMeshActor::AInstancedStaticMeshActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

ATodBranchActor::ATodBranchActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = false;
	SetActorEnableCollision(false);
	RootComponent = CreateDefaultSubobject<USceneComponent>(TEXT("RootComonent"));
	RootComponent->SetMobility(EComponentMobility::Stationary);
}

void ATodBranchActor::ActivateBranch(int32 index)
{
	if (Branches.IsValidIndex(index))
	{
		for (const auto& BranchParticleSystem : Branches[index].Particles)
		{
			if (UParticleSystem* PSTemplate = BranchParticleSystem.Particle.LoadSynchronous())
			{
				UParticleSystemComponent* Particle = 
					UGameplayStatics::SpawnEmitterAttached(PSTemplate, 
					RootComponent, 
					NAME_None, 
					BranchParticleSystem.LocalTM.GetLocation(), 
					BranchParticleSystem.LocalTM.Rotator(),
					BranchParticleSystem.LocalTM.GetScale3D());

				Particle->InstanceParameters.Append(BranchParticleSystem.InstanceParameters);
#if WITH_EDITOR
				AddInstanceComponent(Particle);
#endif
			}
		}

		for (const auto& BranchStaticMesh : Branches[index].StaticMeshes)
		{
			UStaticMesh* LoadedStaticMesh = BranchStaticMesh.StaticMesh.LoadSynchronous();

			if (!LoadedStaticMesh)
			{
				continue;
			}

			if (UStaticMeshComponent* MeshComp = NewObject<UStaticMeshComponent>(this, BranchStaticMesh.Comment))
			{
				MeshComp->SetupAttachment(RootComponent);
#if WITH_EDITOR
				AddInstanceComponent(MeshComp);
#endif
				MeshComp->SetGenerateOverlapEvents(false);
				MeshComp->bUseDefaultCollision = true;
				MeshComp->SetStaticMesh(LoadedStaticMesh);
				MeshComp->SetMobility(RootComponent->Mobility);
				MeshComp->CastShadow = false;
				MeshComp->bReceiveMobileCSMShadows = false;
				MeshComp->SetRelativeTransform(BranchStaticMesh.LocalTM);
				MeshComp->RegisterComponent();
			}
		}

		for (const auto& BranchMaterialOverrideActor : Branches[index].MaterialOverrideActors)
		{
			if (!BranchMaterialOverrideActor.Actor)
			{
				continue;
			}

			UMeshComponent* MeshComponent = nullptr;
			if (AStaticMeshActor* StaticMeshActor = Cast<AStaticMeshActor>(BranchMaterialOverrideActor.Actor))
			{
				MeshComponent = StaticMeshActor->GetStaticMeshComponent();
			}
			else if (ASkeletalMeshActor* SkeletalMeshActor = Cast<ASkeletalMeshActor>(BranchMaterialOverrideActor.Actor))
			{
				MeshComponent = SkeletalMeshActor->GetSkeletalMeshComponent();
			}

			if (MeshComponent)
			{
				for (const auto& MaterialSlot : BranchMaterialOverrideActor.MaterialSlots)
				{
					MeshComponent->SetMaterial(MaterialSlot.Slot, MaterialSlot.Material.LoadSynchronous());
				}
			}
		}

		for (const auto& BranchMaterialOverrideInstancedActors : Branches[index].MaterialOverrideInstancedActors)
		{
			if (!BranchMaterialOverrideInstancedActors.MergedActor)
			{
				continue;
			}

			TArray<UInstancedStaticMeshComponent*> OutMeshComponentArray;
			BranchMaterialOverrideInstancedActors.MergedActor->GetComponents<UInstancedStaticMeshComponent>(OutMeshComponentArray);

			for (const auto& Instance : BranchMaterialOverrideInstancedActors.InstanceSlots)
			{
				if (UInstancedStaticMeshComponent** FindResult = OutMeshComponentArray.FindByPredicate([&Instance](UInstancedStaticMeshComponent* Item) { return NAME_INTERNAL_TO_EXTERNAL(Item->GetFName().GetNumber()) == Instance.InstanceID;}))
				{
					if (UInstancedStaticMeshComponent* InstancedStaticMeshComponent = *FindResult)
					{
						for (const auto& MaterialSlot : Instance.MaterialSlots)
						{
							InstancedStaticMeshComponent->SetMaterial(MaterialSlot.Slot, MaterialSlot.Material.LoadSynchronous());
						}
					}
				}
			}
		}
	}
}

#if WITH_EDITOR
void ATodBranchActor::PostLoad()
{
	Super::PostLoad();
}

void ATodBranchActor::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property->GetFName() == TEXT("Material"))
	{
		for (const auto& CurrentBranch : Branches)
		{
			for (const auto& BranchMaterialOverrideInstancedActors : CurrentBranch.MaterialOverrideInstancedActors)
			{
				for (const auto& Instance : BranchMaterialOverrideInstancedActors.InstanceSlots)
				{
					for (const auto& MaterialSlot : Instance.MaterialSlots)
					{
						if (UMaterialInterface* Material = MaterialSlot.Material.LoadSynchronous())
						{
							Material->CheckMaterialUsage_Concurrent(MATUSAGE_InstancedStaticMeshes);
						}
					}
				}
			}
		}
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

#endif // WITH_EDITOR