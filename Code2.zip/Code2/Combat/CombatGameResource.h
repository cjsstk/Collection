// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "UMG.h"
#include "CMS_gen.h"
#include "Q6Define.h"
#include "CombatGameResource.generated.h"

class UPaperSprite;
class UCameraAnim;

USTRUCT()
struct FDecalSpriteInfo
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly)
	UPaperSprite* PaperSprite;

	UPROPERTY(EditDefaultsOnly)
	FVector DecalOffset;
};

USTRUCT(BlueprintType)
struct FBuffIcon
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush Icon;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor BuffColor;
};

USTRUCT(BlueprintType)
struct FCrowdControlUnitAction
{
	GENERATED_USTRUCT_BODY()
	
	FCrowdControlUnitAction() : bHit(false), bShout(false), bStun(false), bPause(false) {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FX")
	TSoftObjectPtr<UMaterialInterface> StateMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FX")
	FSpawnParticleParams StateParticleParam;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FX")
	FSubMaterialEffectParams HitSubMaterialParam;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FX")
	FSpawnParticleParams HitParticleParam;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FX")
	FSpawnSoundParams SoundParam;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	bool bHit;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	bool bShout;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	bool bStun;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	bool bPause;
};

USTRUCT()
struct FCrowdControlAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FCrowdControlAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FBuffIcon Icon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Unit")
	FCrowdControlUnitAction UnitAction;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Comment")
	FString Comment;
};

USTRUCT()
struct FUnitAttributeBuffIconAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FUnitAttributeBuffIconAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FBuffIcon BuffIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FBuffIcon DebuffIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Comment")
	FString Comment;
};

USTRUCT()
struct FMomentIconAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FMomentIconAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FBuffIcon Icon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Comment")
	FString Comment;
};

USTRUCT()
struct FEffectCategoryIconAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FEffectCategoryIconAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FBuffIcon PositiveIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FBuffIcon NegativeIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Comment")
	FString Comment;
};

USTRUCT()
struct FUnitBarAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FUnitBarAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FSlateBrush BarBgBrush;
};

UCLASS(Blueprintable)
class Q6_API UCombatGameResource : public UObject
{
	GENERATED_BODY()

public:
	UCurveFloat* GetCameraBlendCurve() const;
	EViewTargetBlendFunction GetCameraBlendFunction() const;
	float GetCameraBlendExp() const;
	float GetCameraAnimBlendInTime() const { return CameraAnimBlendInTime; }
	UCameraAnim* GetCameraAnimation(ECombatCamera CameraType) const;

	const FDecalSpriteInfo& GetUnitAllyDecalInfo() const { return UnitAllyDecalInfo; }
	const FDecalSpriteInfo& GetUnitEnemyDecalInfo() const { return UnitEnemyDecalInfo; }
	void SetUnitBarBgImage(UImage* Image, EAttributeCategory Category) const;

	UMaterialInterface* GetSpawnEffectMaterial(ESpawnReason InReason, int32 InIndex) const;
	UParticleSystem* GetSpawnEffectParticle(ESpawnReason InReason, int32 InIndex) const;
	USoundBase* GetSpawnEffectSound(ESpawnReason InReason) const;

	UMaterialInterface* GetDeadEffectMaterial(int32 InIndex) const;
	UParticleSystem* GetDeadEffectParticle(int32 InIndex) const;
	USoundBase* GetDeadEffectSound() const { return DeadEffectSound; }

	const FSubMaterialEffectParams& GetHitEffectMaterialParams() const { return HitEffectMaterialParams; }

	const FSpawnParticleParams& GetShieldBrokenEffectParticleParams() const { return ShieldBrokenEffectParticleParams; }
	USoundBase* GetShieldBrokenEffectSound() const { return ShieldBrokenEffectSound; }

	void SetAttackOrderImage(UImage* Image, int32 AttackOrderIndex);
	void SetSkillNoteMatchedImage(UImage* Image, int32 SkillNoteIndex);

	const FCrowdControlAssetRow& GetCrowdControlAssetRow(FCrowdControlType Type) const;

	const FBuffIcon& GetBuffRemovalIcon() const { return BuffRemovalIcon; }
	const FBuffIcon& GetBuffRemovalFailedIcon() const { return BuffRemovalFailedIcon; }
	const FBuffIcon& GetImmuneBuffIcon() const { return ImmuneBuffIcon; }
	const FBuffIcon& GetCrowdControlIcon(FCrowdControlType Type) const;
	const FBuffIcon& GetUnitAttributeBuffIcon(FUnitAttributeType Type, int32 Value) const;
	const FBuffIcon& GetMomentIcon(EMoment Moment) const;
	const FBuffIcon& GetEffectCategoryIcon(EEffectCategory EffectCategory, int32 Value) const;
	const FBuffIcon& GetPointVaryIcon(EPointVaryState PointVaryState) const;
	const FBuffIcon& GetImmediateKillIcon() const { return ImmediateKillIcon; }

	const FSubMaterialEffectParams& GetBuffEffectMaterialParams(bool bDemerit) const;
	const FSpawnParticleParams& GetBuffEffectParticleParams(bool bDemerit) const;
	USoundBase* GetBuffEffectSound(bool bDemerit) const;

	TSubclassOf<class ALoot> GetLootActorClass() const { return LootActorClass; }

	const FSubMaterialEffectParams& GetLootEffectMaterialParams() const { return LootEffectMaterialParams; }
	const FSpawnParticleParams& GetLootEffectParticleParams() const { return LootEffectParticleParams; }
	USoundBase* GetLootEffectSound() const { return LootEffectSound; }

	const float GetDropBoxLocationOffset() const { return DropBoxLocationOffset; }
	const float GetDropBoxRandomAngleLimitMin() const { return DropBoxRandomAngleLimitMin; }
	const float GetDropBoxRandomAngleLimitMax() const { return DropBoxRandomAngleLimitMax; }
	const float GetDropBoxSpawnTimeOffset() const { return DropBoxSpawnTimeOffset; }
	const float GetDropBoxSpawnStartTimeMultiplier() const { return DropBoxSpawnStartTimeMultiplier; }
	const float GetDropBoxWaitTimeToNextWave() const { return DropBoxWaitTimeToNextWave; }

private:
	UPROPERTY(EditDefaultsOnly, Category = "Camera Blending Curve")
	UCurveFloat* CameraBlendingCurve;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Blending Function")
	TEnumAsByte<EViewTargetBlendFunction> CameraBlendFunction;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Blending Function")
	float BlendExponent;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Animation")
	float CameraAnimBlendInTime;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Animation")
	UCameraAnim* CombatWaveAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Animation")
	UCameraAnim* CombatPrepareAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Animation")
	UCameraAnim* CombatAllyAllAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Animation")
	UCameraAnim* CombatAllyAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Animation")
	UCameraAnim* CombatEnemyAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Camera Animation")
	UCameraAnim* CombatResultAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Unit Bar")
	UDataTable* UnitBarAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Unit Decal")
	FDecalSpriteInfo UnitAllyDecalInfo;

	UPROPERTY(EditDefaultsOnly, Category = "Unit Decal")
	FDecalSpriteInfo UnitEnemyDecalInfo;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Effect")
	TArray<UMaterialInterface*> SpawnEffectMaterials;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Effect")
	UParticleSystem* SpawnEffectParticle;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Effect")
	TArray<UParticleSystem*> SpawnEffectParticles;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Effect")
	USoundBase* SpawnEffectSound;

	UPROPERTY(EditDefaultsOnly, Category = "Dead Effect")
	TArray<UMaterialInterface*> DeadEffectMaterials;

	UPROPERTY(EditDefaultsOnly, Category = "Dead Effect")
	UParticleSystem* DeadEffectParticle;

	UPROPERTY(EditDefaultsOnly, Category = "Dead Effect")
	TArray<UParticleSystem*> DeadEffectParticles;

	UPROPERTY(EditDefaultsOnly, Category = "Dead Effect")
	USoundBase* DeadEffectSound;

	UPROPERTY(EditDefaultsOnly, Category = "Rebirth Effect")
	TArray<UMaterialInterface*> RebirthEffectMaterials;

	UPROPERTY(EditDefaultsOnly, Category = "Rebirth Effect")
	UParticleSystem* RebirthEffectParticle;

	UPROPERTY(EditDefaultsOnly, Category = "Rebirth Effect")
	TArray<UParticleSystem*> RebirthEffectParticles;

	UPROPERTY(EditDefaultsOnly, Category = "Rebirth Effect")
	USoundBase* RebirthEffectSound;

	UPROPERTY(EditDefaultsOnly, Category = "Hit Effect")
	FSubMaterialEffectParams HitEffectMaterialParams;

	UPROPERTY(EditDefaultsOnly, Category = "Shield Broken Effect")
	FSpawnParticleParams ShieldBrokenEffectParticleParams;

	UPROPERTY(EditDefaultsOnly, Category = "Shield Broken Effect")
	USoundBase* ShieldBrokenEffectSound;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	TArray<FSlateBrush> AttackOrderBrushes;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	TArray<FSlateBrush> SkillNoteMatchedBrushes;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	FBuffIcon DummyBuffIcon;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	FBuffIcon BuffRemovalIcon;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	FBuffIcon BuffRemovalFailedIcon;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	FBuffIcon ImmuneBuffIcon;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	UDataTable* CrowdControlAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	UDataTable* UnitAttributeBuffIconAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	UDataTable* MomentIconAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	UDataTable* EffectCategoryIconAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	FBuffIcon PointVaryConsumeIcon;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	FBuffIcon PointVaryConvertIcon;

	UPROPERTY(EditDefaultsOnly, Category = "Buff")
	FBuffIcon ImmediateKillIcon;

	UPROPERTY(EditDefaultsOnly, Category = "Buff Effect")
	FSubMaterialEffectParams BuffEffectMaterialParams;

	UPROPERTY(EditDefaultsOnly, Category = "Buff Effect")
	FSpawnParticleParams BuffEffectParticleParams;

	UPROPERTY(EditDefaultsOnly, Category = "Buff Effect")
	USoundBase* BuffEffectSound;

	UPROPERTY(EditDefaultsOnly, Category = "Debuff Effect")
	FSubMaterialEffectParams DebuffEffectMaterialParams;

	UPROPERTY(EditDefaultsOnly, Category = "Debuff Effect")
	FSpawnParticleParams DebuffEffectParticleParams;

	UPROPERTY(EditDefaultsOnly, Category = "Debuff Effect")
	USoundBase* DebuffEffectSound;

	UPROPERTY(EditDefaultsOnly, Category = "Loot")
	TSubclassOf<class ALoot> LootActorClass;

	UPROPERTY(EditDefaultsOnly, Category = "Loot Effect")
	FSubMaterialEffectParams LootEffectMaterialParams;

	UPROPERTY(EditDefaultsOnly, Category = "Loot Effect")
	FSpawnParticleParams LootEffectParticleParams;

	UPROPERTY(EditDefaultsOnly, Category = "Loot Effect")
	USoundBase* LootEffectSound;

	UPROPERTY(EditDefaultsOnly, Category = "DropBox")
	float DropBoxLocationOffset;

	UPROPERTY(EditDefaultsOnly, Category = "DropBox")
	float DropBoxRandomAngleLimitMin;

	UPROPERTY(EditDefaultsOnly, Category = "DropBox")
	float DropBoxRandomAngleLimitMax;

	UPROPERTY(EditDefaultsOnly, Category = "DropBox")
	float DropBoxSpawnTimeOffset;

	UPROPERTY(EditDefaultsOnly, Category = "DropBox")
	float DropBoxSpawnStartTimeMultiplier;

	UPROPERTY(EditDefaultsOnly, Category = "DropBox")
	float DropBoxWaitTimeToNextWave;
};
