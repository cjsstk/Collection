// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatLocator.h"
#include "CombatCameraComponent.h"
#include "Engine.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Unit.h"
#include "LevelUtil.h"


static void _InitCombatCameraComponent(UCameraComponent* CameraComponent, ECombatCamera CombatCameraType)
{
	FVector Location(ForceInitToZero);
	float Roll(0);
	float Pitch(-18.76);
	float Yaw(0);
	float FOV(40);

	switch (CombatCameraType)
	{
		case ECombatCamera::Wave:
			Location = FVector(-1133.31, 10.52, 391.41);
			Roll = -0.92;
			Yaw = -1.14;
			FOV = 38;
			break;
		case ECombatCamera::Prepare:
			Location = FVector(-766.28, 42.08, 284.48);
			Roll = -0.85;
			Pitch = -22.8;
			Yaw = -1.98;
			FOV = 38;
			break;
		case ECombatCamera::AllyAll:
			Location = FVector(-1073.31, 10.52, 381.41);
			Roll = -0.92;
			Yaw = -1.14;
			break;
		case ECombatCamera::Ally1:
			Location = FVector(-830.21, -176.79, 281);
			Roll = -0.94;
			Pitch = -20.38;
			Yaw = 7.38;
			break;
		case ECombatCamera::Ally2:
			Location =  FVector(-837.17, 23.42, 280.66);
			Roll = -0.94;
			Pitch = -20.38;
			Yaw = -1.48;
			break;
		case ECombatCamera::Ally3:
			Location = FVector(-827.28, 208.68, 281);
			Roll = -0.94;
			Pitch = -20.38;
			Yaw = -9.30;
			break;
		case ECombatCamera::EnemyAll:
			Location = FVector(-435.62, 4, 292.34);
			Pitch = -14.31;
			break;
		case ECombatCamera::Enemy1:
			Location = FVector(-210, -238, 292.34);
			Pitch = -16.86;
			FOV = 36;
			break;
		case ECombatCamera::Enemy2:
			Location = FVector(-210, 4, 292.34);
			Pitch = -16.42;
			FOV = 36;
			break;
		case ECombatCamera::Enemy3:
			Location = FVector(-210.8, 246, 292.34);
			Pitch = -16.41;
			FOV = 36;
			break;
		case ECombatCamera::Enemy4:
			Location = FVector(-210.8, -117, 292.34);
			Pitch = -16.41;
			FOV = 36;
			break;
		case ECombatCamera::Enemy5:
			Location = FVector(-210.8, 125, 292.34);
			Pitch = -16.41;
			FOV = 36;
			break;
		default:
			ensureMsgf(0, TEXT("Unhandled camera type: %d"), (int32)CombatCameraType);
			break;
	}

	CameraComponent->SetRelativeLocation(Location);
	CameraComponent->SetRelativeRotation(FRotator(Pitch, Yaw, 0));
	CameraComponent->FieldOfView = FOV;
}

static void _InitAllyPositions(USceneComponent* AllyPosition, int32 Slot)
{
	static FVector Locations[] =
	{
		FVector(-515, -151, 85),
		FVector(-618,  9, 85),
		FVector(-515,  169, 85)
	};

	static FRotator Rotations[] =
	{
		FRotator(0, 18, 0),
		FRotator(0, 0, 0),
		FRotator(0, -15, 0)
	};

	FVector Location = FVector::ZeroVector;
	FRotator Rotation = FRotator::ZeroRotator;

	int32 SlotIndex = Slot - 1;
	if (FMath::IsWithin(SlotIndex, 0, (int32)UE_ARRAY_COUNT(Locations)))
	{
		Location = Locations[SlotIndex];
		Rotation = Rotations[SlotIndex];
	}
	else
	{
		ensureMsgf(0, TEXT("Unhandled ally slot: %d"), Slot);
	}

	AllyPosition->SetRelativeLocation(Location);
	AllyPosition->SetRelativeRotation(Rotation);
}

static void _InitEnemyPositions(USceneComponent* EnemyPosition, int32 Slot)
{
	static FVector Locations[] = { FVector(298, -254, 85),
								   FVector(398,  -12, 85),
								   FVector(298,  230, 85),
								   FVector(348, -133, 85),
								   FVector(348,  109, 85) };

	int32 SlotIndex = Slot - 1;
	FVector Location = FVector::ZeroVector;

	if (FMath::IsWithin(SlotIndex, 0, (int32)UE_ARRAY_COUNT(Locations)))
	{
		Location = Locations[SlotIndex];
	}
	else
	{
		ensureMsgf(0, TEXT("Unhandled enemy slot: %d"), Slot);
	}

	EnemyPosition->SetRelativeLocation(Location);
	EnemyPosition->SetRelativeRotation(FRotator(0.0f, -180.0f, 0.0f));
}

ACombatLocator::ACombatLocator(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Group(1)
	, Wave(0)
	, CombatMultiSide(ECombatMultiSide::Main)
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* SceneComponent = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, TEXT("SceneComp"));
	RootComponent = SceneComponent;

	UEnum* CombatCameraEnum = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECombatCamera"), true);
	ensure(CombatCameraEnum);

	UCombatCameraComponent** Cameras[] =
	{
		&WaveCamera,
		&PrepareCamera,
		&AllyAllCamera,
		&Ally1Camera,
		&Ally2Camera,
		&Ally3Camera,
		&EnemyAllCamera,
		&Enemy1Camera,
		&Enemy2Camera,
		&Enemy3Camera,
		&Enemy4Camera,
		&Enemy5Camera
	};

	const FName CameraComponentNames[] =
	{
		TEXT("WaveCamera"),
		TEXT("PrepareCamera"),
		TEXT("AllyAllCamera"),
		TEXT("Ally1Camera"),
		TEXT("Ally2Camera"),
		TEXT("Ally3Camera"),
		TEXT("EnemyAllCamera"),
		TEXT("Enemy1Camera"),
		TEXT("Enemy2Camera"),
		TEXT("Enemy3Camera"),
		TEXT("Enemy4Camera"),
		TEXT("Enemy5Camera")
	};

	for (int32 i = 0; i < UE_ARRAY_COUNT(Cameras); ++i)
	{
		*Cameras[i] = ObjectInitializer.CreateDefaultSubobject<UCombatCameraComponent>(this, CameraComponentNames[i]);
#if WITH_EDITOR
		(*Cameras[i])->bConstrainAspectRatio = true;
#else
		(*Cameras[i])->bConstrainAspectRatio = false;
#endif
		(*Cameras[i])->AspectRatio = 0.5625f;
		(*Cameras[i])->PostProcessBlendWeight = 1.0f;
		(*Cameras[i])->SetupAttachment(RootComponent);
		_InitCombatCameraComponent(*Cameras[i], (ECombatCamera)i);
	}

	USceneComponent** AllyPositions[] =
	{
		&Ally1Position,
		&Ally2Position,
		&Ally3Position
	};

	const FName AllyPositionNames[] =
	{
		TEXT("Ally1Position"),
		TEXT("Ally2Position"),
		TEXT("Ally3Position")
	};

	for (int32 i = 0; i < UE_ARRAY_COUNT(AllyPositions); ++i)
	{
		*AllyPositions[i] = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, AllyPositionNames[i]);
		(*AllyPositions[i])->SetupAttachment(RootComponent);
		_InitAllyPositions(*AllyPositions[i], i+1);
	}

	USceneComponent** EnemyPositions[] =
	{
		&Enemy1Position,
		&Enemy2Position,
		&Enemy3Position,
		&Enemy4Position,
		&Enemy5Position
	};

	const FName EnemyPositionNames[] =
	{
		TEXT("Enemy1Position"),
		TEXT("Enemy2Position"),
		TEXT("Enemy3Position"),
		TEXT("Enemy4Position"),
		TEXT("Enemy5Position")
	};

	for (int32 i = 0; i < UE_ARRAY_COUNT(EnemyPositions); ++i)
	{
		*EnemyPositions[i] = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, EnemyPositionNames[i]);
		(*EnemyPositions[i])->SetupAttachment(RootComponent);
		_InitEnemyPositions(*EnemyPositions[i], i + 1);
	}

	ModelPosition = ObjectInitializer.CreateDefaultSubobject<UStaticMeshComponent>(this, FName("ModelPosition"));
	ModelPosition->SetupAttachment(RootComponent);
	ModelPosition->SetRelativeLocation(FVector(-535, 11, 9));
	ModelPosition->SetRelativeRotation(FRotator::ZeroRotator);

	PetPosition = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, FName("PetPosition"));
	PetPosition->SetupAttachment(RootComponent);
	PetPosition->SetRelativeLocation(FVector(-648, 128, 85));
	PetPosition->SetRelativeRotation(FRotator::ZeroRotator);

	AllyAllTargetPosition = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, FName("AllyAllTargetPosition"));
	AllyAllTargetPosition->SetupAttachment(RootComponent);
	AllyAllTargetPosition->SetRelativeLocation(FVector(-498, 9, 0));
	AllyAllTargetPosition->SetRelativeRotation(FRotator::ZeroRotator);

	EnemyAllTargetPosition = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, FName("EnemyAllTargetPosition"));
	EnemyAllTargetPosition->SetupAttachment(RootComponent);
	EnemyAllTargetPosition->SetRelativeLocation(FVector(258, -12, 0));
	EnemyAllTargetPosition->SetRelativeRotation(FRotator(0.0f, -180.0f, 0.0f));

#if WITH_EDITORONLY_DATA
	if (!IsRunningCommandlet())
	{
		SpriteComponent = ObjectInitializer.CreateEditorOnlyDefaultSubobject<UBillboardComponent>(this, TEXT("Sprite"));
		ArrowComponent = ObjectInitializer.CreateEditorOnlyDefaultSubobject<UArrowComponent>(this, TEXT("Arrow"));
		TextRender = ObjectInitializer.CreateEditorOnlyDefaultSubobject<UTextRenderComponent>(this, TEXT("TextComponent"));

		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> IconObject;
			FName ID_WaveLocator;
			FText NAME_WaveLocator;
			FConstructorStatics()
				: IconObject(TEXT("/Game/Dev/EditorIcons/DevCombatIcon.DevCombatIcon"))
				, ID_WaveLocator(TEXT("WaveLocator"))
				, NAME_WaveLocator(FText::FromString(FString("Wave Locator")))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (SpriteComponent)
		{
			SpriteComponent->Sprite = ConstructorStatics.IconObject.Get();
			SpriteComponent->SetRelativeScale3D(FVector(0.5f, 0.5f, 0.5f));
			SpriteComponent->SpriteInfo.Category = ConstructorStatics.ID_WaveLocator;
			SpriteComponent->SpriteInfo.DisplayName = ConstructorStatics.NAME_WaveLocator;
			SpriteComponent->bIsScreenSizeScaled = true;
			SpriteComponent->SetupAttachment(SceneComponent);
			SpriteComponent->SetHiddenInGame(true);
		}

		if (ArrowComponent)
		{
			ArrowComponent->ArrowColor = FColor(255, 200, 150);
			ArrowComponent->ArrowSize = 4.0f;
			ArrowComponent->bTreatAsASprite = true;
			ArrowComponent->SpriteInfo.Category = ConstructorStatics.ID_WaveLocator;
			ArrowComponent->SpriteInfo.DisplayName = ConstructorStatics.NAME_WaveLocator;
			ArrowComponent->SetupAttachment(SpriteComponent);
			ArrowComponent->bIsScreenSizeScaled = true;
			ArrowComponent->SetHiddenInGame(true);
		}

		if (TextRender)
		{
			TextRender->XScale = 5;
			TextRender->YScale = 5;
			TextRender->SetupAttachment(SceneComponent);
			TextRender->SetText(FText::FromString(TEXT("0")));
			TextRender->SetHiddenInGame(true);
		}
	}
#endif // WITH_EDITORONLY_DATA
}

void ACombatLocator::BeginPlay()
{
	Super::BeginPlay();

	WaveCamera->SetConstraintAspectRatio(false);
	PrepareCamera->SetConstraintAspectRatio(false);
	AllyAllCamera->SetConstraintAspectRatio(false);
	Ally1Camera->SetConstraintAspectRatio(false);
	Ally2Camera->SetConstraintAspectRatio(false);
	Ally3Camera->SetConstraintAspectRatio(false);
	EnemyAllCamera->SetConstraintAspectRatio(false);
	Enemy1Camera->SetConstraintAspectRatio(false);
	Enemy2Camera->SetConstraintAspectRatio(false);
	Enemy3Camera->SetConstraintAspectRatio(false);
}

bool ACombatLocator::IsCorrectLocator(int32 InGroup, int32 InWave, ECombatMultiSide InSide) const
{
	if ((Group == InGroup) && (Wave == InWave))
	{
		return (CombatMultiSide == InSide || CombatMultiSide == ECombatMultiSide::Both);
	}

	return false;
}

UCombatCameraComponent* ACombatLocator::GetCamera(ECombatCamera CameraType) const
{
	switch (CameraType)
	{
		case ECombatCamera::Wave:
			return WaveCamera;
		case ECombatCamera::Prepare:
			return PrepareCamera;
		case ECombatCamera::AllyAll:
			return AllyAllCamera;
		case ECombatCamera::Ally1:
			return Ally1Camera;
		case ECombatCamera::Ally2:
			return Ally2Camera;
		case ECombatCamera::Ally3:
			return Ally3Camera;
		case ECombatCamera::EnemyAll:
			return EnemyAllCamera;
		case ECombatCamera::Enemy1:
			return Enemy1Camera;
		case ECombatCamera::Enemy2:
			return Enemy2Camera;
		case ECombatCamera::Enemy3:
			return Enemy3Camera;
		case ECombatCamera::Enemy4:
			return Enemy4Camera;
		case ECombatCamera::Enemy5:
			return Enemy5Camera;
		default:
			ensure(0);
			return PrepareCamera;
	}
}

FTransform ACombatLocator::GetAllyTransform(int32 Slot) const
{
	switch (Slot)
	{
		case 1:
			return Ally1Position->GetComponentTransform();
		case 2:
			return Ally2Position->GetComponentTransform();
		case 3:
			return Ally3Position->GetComponentTransform();
	}

	Q6JsonLogZagal(Error, "Ally Wrong Slot", Q6KV("Slot", Slot));
	return GetActorTransform();
}

FTransform ACombatLocator::GetEnemyTransform(int32 Slot, int32 NumSlots, bool bForceDefault) const
{
	int32 ConvertedSlot = ULevelUtil::ConvertSlot3to5(Slot, NumSlots, bForceDefault);

	switch (ConvertedSlot)
	{
		case 1:
			return Enemy1Position->GetComponentTransform();
		case 2:
			return Enemy2Position->GetComponentTransform();
		case 3:
			return Enemy3Position->GetComponentTransform();
		case 4:
			return Enemy4Position->GetComponentTransform();
		case 5:
			return Enemy5Position->GetComponentTransform();
	}

	Q6JsonLogZagal(Error, "Wrong Slot for EnemyTransform", Q6KV("Slot", Slot), Q6KV("NumSlots", NumSlots), Q6KV("ForceDefault", bForceDefault));
	return GetActorTransform();
}

FTransform ACombatLocator::GetAllTargetTransform(ECCFaction Faction) const
{
	if (Faction == ECCFaction::Ally)
	{
		return AllyAllTargetPosition->GetComponentTransform();
	}
	else
	{
		return EnemyAllTargetPosition->GetComponentTransform();
	}
}

#if WITH_EDITOR

void ACombatLocator::UpdateTextRenderText()
{
	if (TextRender)
	{
		if (IsDefaultLocator())
		{
			TextRender->SetText(FText::FromString(FString::Printf(TEXT("Default(%d)"), Group)));
		}
		else
		{
			TextRender->SetText(FText::FromString(FString::Printf(TEXT("%d - %d"), Group, Wave)));
		}
	}
}

void ACombatLocator::PostLoad()
{
	Super::PostLoad();

	UpdateTextRenderText();
}

void ACombatLocator::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (!GetWorld())
	{
		// looks like changing default, not instance
		return;
	}

	// Check if have duplications
	for (TActorIterator<ACombatLocator> It(GetWorld(), ACombatLocator::StaticClass()); It; ++It)
	{
		ACombatLocator* WaveLocator = *It;

		if (WaveLocator == this)
		{
			continue;
		}

		if (WaveLocator->GetLevel() != GetLevel())
		{
			continue;
		}

		if (WaveLocator->GetWave() == Wave)
		{
			// have duplication
			Q6JsonLogSunny(Error, "Wave is Duplicated", Q6KV("Wave Locator", *GetName()), Q6KV("Wave", Wave));
		}
	}

	UpdateTextRenderText();
}

#endif // WITH_EDITOR

AResultLocator::AResultLocator(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
#if WITH_EDITORONLY_DATA
	, DemoUnitType(0)
#endif
{
	PrimaryActorTick.bCanEverTick = false;

	USceneComponent* SceneComponent = ObjectInitializer.CreateDefaultSubobject<USceneComponent>(this, TEXT("SceneComp"));
	RootComponent = SceneComponent;

	ResultCamera = ObjectInitializer.CreateDefaultSubobject<UCombatCameraComponent>(this, "ResultCamera");
	ResultCamera->FieldOfView = 90.0f;
#if WITH_EDITOR
	ResultCamera->bConstrainAspectRatio = true;
#else
	ResultCamera->bConstrainAspectRatio = false;
#endif
	ResultCamera->AspectRatio = 0.5625f;
	ResultCamera->PostProcessBlendWeight = 1.0f;
	ResultCamera->SetupAttachment(RootComponent);

	_InitCombatCameraComponent(ResultCamera, ECombatCamera::Wave); //temp

#if WITH_EDITORONLY_DATA
	if (!IsRunningCommandlet())
	{
		SpriteComponent = ObjectInitializer.CreateEditorOnlyDefaultSubobject<UBillboardComponent>(this, TEXT("Sprite"));
		ArrowComponent = ObjectInitializer.CreateEditorOnlyDefaultSubobject<UArrowComponent>(this, TEXT("Arrow"));

		// Structure to hold one-time initialization
		struct FConstructorStatics
		{
			ConstructorHelpers::FObjectFinderOptional<UTexture2D> IconObject;
			FName ID_ResultLocator;
			FText NAME_ResultLocator;
			FConstructorStatics()
				: IconObject(TEXT("/Game/Dev/EditorIcons/CombatFinishUnitLocatorIcon.CombatFinishUnitLocatorIcon"))
				, ID_ResultLocator(TEXT("ResultLocator"))
				, NAME_ResultLocator(FText::FromString(FString("Result Locator")))
			{
			}
		};
		static FConstructorStatics ConstructorStatics;

		if (SpriteComponent)
		{
			SpriteComponent->Sprite = ConstructorStatics.IconObject.Get();
			SpriteComponent->SetRelativeScale3D(FVector(0.5f, 0.5f, 0.5f));
			SpriteComponent->SpriteInfo.Category = ConstructorStatics.ID_ResultLocator;
			SpriteComponent->SpriteInfo.DisplayName = ConstructorStatics.NAME_ResultLocator;
			SpriteComponent->bIsScreenSizeScaled = true;
			SpriteComponent->SetupAttachment(SceneComponent);
			SpriteComponent->SetHiddenInGame(true);
		}

		if (ArrowComponent)
		{
			ArrowComponent->ArrowColor = FColor(255, 200, 150);

			ArrowComponent->ArrowSize = 4.0f;
			ArrowComponent->bTreatAsASprite = true;
			ArrowComponent->SpriteInfo.Category = ConstructorStatics.ID_ResultLocator;
			ArrowComponent->SpriteInfo.DisplayName = ConstructorStatics.NAME_ResultLocator;
			ArrowComponent->SetupAttachment(SpriteComponent);
			ArrowComponent->bIsScreenSizeScaled = true;
			ArrowComponent->SetHiddenInGame(true);
		}
	}
#endif // WITH_EDITORONLY_DATA
}

void AResultLocator::BeginPlay()
{
	Super::BeginPlay();

	ResultCamera->SetConstraintAspectRatio(false);
	ResultCamera->CulledActorList.Empty();
}

#if WITH_EDITOR

void AResultLocator::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (DemoUnitType != 0)
	{
		if (!DemoUnit)
		{
			FActorSpawnParameters SpawnParameters;
			SpawnParameters.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			DemoUnit = GetWorld()->SpawnActor<AUnit>(GetActorLocation(), GetActorRotation(), SpawnParameters);
			DemoUnit->AttachToActor(this, FAttachmentTransformRules::SnapToTargetIncludingScale);
		}

		FUnitInitParams Params;
		Params.bBlockingLoad = true;
		DemoUnit->InitUnit(DemoUnitType, Params);

		SetIsTemporarilyHiddenInEditor(true);
	}
	else
	{
		if (DemoUnit)
		{
			DemoUnit->Destroy();
			DemoUnit = nullptr;
		}

		SetIsTemporarilyHiddenInEditor(false);
	}
}

void AResultLocator::BeginDestroy()
{
	if (DemoUnit)
	{
		DemoUnit->Destroy();
		DemoUnit = nullptr;
	}

	Super::BeginDestroy();
}

#endif // WITH_EDITOR