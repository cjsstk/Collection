#include "CPInstances.h"
#include "CCEvent.h"
#include "CMS_gen.h"
#include "CombatCube.h"
#include "CombatHUD.h"
#include "CombatLocator.h"
#include "CombatPlayerController.h"
#include "CombatPresenter.h"
#include "LevelUtil.h"
#include "Loot.h"
#include "PetUnit.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6GameInstance.h"
#include "Q6CombatGameMode.h"
#include "Q6SoundPlayer.h"
#include "SubPartUnit.h"
#include "Test/AutomationHelper.h"
#include "Unit.h"
#include "UnitLocator.h"

extern TAutoConsoleVariable<float> CVarAllyCameraBlendTime;
extern TAutoConsoleVariable<float> CVarEnemyCameraBlendTime;
extern TAutoConsoleVariable<float> CVarCameraWaitingTimeRatio;

static const float DEFAULT_INSTANCE_TIMEOUT = 10.0f;
static const float SEQUENCER_PLAY_TIMEOUT = 20.0f;

TAutoConsoleVariable<int32> CVarUseCPInstanceTimeout(
	TEXT("q6.UseCPInstanceTimeout"),
	1,
	TEXT("enable combat presenter instance timeout"),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarPostHitRandomDelayMax(
	TEXT("q6.PostHitStartRandomDelayMax"),
	0.3f,
	TEXT("giving [0~X) random range to US post hit process delay"),
	ECVF_Cheat);

//////////////////////////////////////////////////////////////////////////////////
// UCPInstanceBase

UCPInstanceBase::UCPInstanceBase()
	: InstanceState(ECPInstanceState::NA)
	, bBlocking(true)
	, bResetCamera(true)
	, bUseTimeOut(true)
	, bValidTimeOut(false)
	, InstanceId(CCInstanceIdInvalid)
	, TimeoutLimit(DEFAULT_INSTANCE_TIMEOUT)
	, ElapsedTime(0.f)	
{
}

void UCPInstanceBase::SetState(ECPInstanceState InState)
{
	InstanceState = InState;
	OnInstanceState.ExecuteIfBound(InstanceState, this);
}

bool UCPInstanceBase::Prepare()
{
	check(InstanceState == ECPInstanceState::NA);

	SetState(ECPInstanceState::Prepare);

	return true;
}

void UCPInstanceBase::SetTimeOutLimit(float InTimeOutLimit, float Margin /* = 0.0f */, bool bResetElapsedTime /* = false */)
{
	float EffectiveTimeoutLimit = InTimeOutLimit + Margin;
	TimeoutLimit = EffectiveTimeoutLimit > 0.0f ? EffectiveTimeoutLimit : 0.0f;

	if (bResetElapsedTime)
	{
		ElapsedTime = 0;
	}
}

void UCPInstanceBase::Start()
{
	check(InstanceState == ECPInstanceState::Prepare);

	ElapsedTime = 0;
	BindContentDelegate();
	SetState(ECPInstanceState::Start);
	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(this);
	if (CombatGameMode)
	{
		CombatGameMode->AddSpeed((int32)GetInstanceType(), GetSpeed());
	}
}

void UCPInstanceBase::End()
{
	UnbindContentDelegate();
	SetState(ECPInstanceState::End);
	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(this);
	if (CombatGameMode)
	{
		CombatGameMode->RevertSpeed((int32)GetInstanceType());
	}
}

void UCPInstanceBase::Tick(float DeltaTime)
{
	if (CVarUseCPInstanceTimeout.GetValueOnGameThread() == 0)
	{
		return;
	}

	ElapsedTime += DeltaTime;

	if (!bUseTimeOut)
	{
		return;
	}

	if (ElapsedTime >= TimeoutLimit)
	{
		if (!bValidTimeOut)
		{
			const UEnum* EnumPtr = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECPInstanceType"), true);
			FString EnumStr = EnumPtr ? EnumPtr->GetNameStringByValue((uint8)GetInstanceType()) : FString::FromInt((uint8)GetInstanceType());
			Q6JsonLogSunny(Warning, "CPInstance Timeout", Q6KV("InstanceId", InstanceId), Q6KV("InstanceType", *EnumStr));

			bValidTimeOut = true;
		}

		ElapsedTime = 0.f;
		CombatPresenter->GetWorldTimerManager().SetTimerForNextTick(FTimerDelegate::CreateLambda([&]() {
			End();
		}));
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPSpawnInstance

UCPSpawnInstance::UCPSpawnInstance()
	: PassiveBuffInstance(nullptr)
	, InheritedBuffInstance(nullptr)
	, UnitId(CCUnitIdInvalid)
	, bUsingTurnSkillCamera(false)
	, bHUDAnimStarted(false)
	, bSpawnEffectFinished(false)
{}

FCCUnitId UCPSpawnInstance::GetUnitId() const
{
	return SpawnUnitEvent->UnitState.UnitId;
}

FCCUnitId UCPSpawnInstance::GetSourceUnitId() const
{
	return SpawnUnitEvent->SourceUnitId;
}

void UCPSpawnInstance::AddPassiveBuffEvent(const UCCCreateBuffEvent* InEvent)
{
	if (!PassiveBuffInstance)
	{
		PassiveBuffInstance = CombatPresenter->CreateInstance<UCPBuffInstance>();
		check(PassiveBuffInstance);
		PassiveBuffInstance->SetSkipEffect(true, true, false);
	}

	PassiveBuffInstance->AddBuffEvent(InEvent);
}

void UCPSpawnInstance::AddInheritedBuffEvent(const UCCCreateBuffEvent* InEvent)
{
	if (!InheritedBuffInstance)
	{
		InheritedBuffInstance = CombatPresenter->CreateInstance<UCPBuffInstance>();
		check(InheritedBuffInstance);
		InheritedBuffInstance->SetSkipEffect(true, true, false);
	}

	InheritedBuffInstance->AddBuffEvent(InEvent);
}

static bool _ShouldBlock(ESpawnReason Reason)
{
	switch (Reason)
	{
		case ESpawnReason::Summon:
		case ESpawnReason::Rebirth:
		case ESpawnReason::SubParty:
		case ESpawnReason::WipeoutContinue:
		case ESpawnReason::RebirthSummon:
			return true;
		default:
			return false;
	}
}

static bool _ShouldResetCamera(ESpawnReason Reason)
{
	switch (Reason)
	{
		case ESpawnReason::Summon:
		case ESpawnReason::Rebirth:
		case ESpawnReason::WipeoutContinue:
		case ESpawnReason::RebirthSummon:
			return true;
		default:
			return false;
	}
}

bool UCPSpawnInstance::Prepare()
{
	bBlocking = _ShouldBlock(SpawnUnitEvent->SpawnReason);
	bUseTimeOut = bBlocking;

	bResetCamera = _ShouldResetCamera(SpawnUnitEvent->SpawnReason);

	if (bUsingTurnSkillCamera)
	{
		ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
		if (PlayerController)
		{
			PlayerController->SaveCurrentCamera();
		}
	}
	else if (bResetCamera && IsAnyAttackPhase(CombatPresenter->GetTurnPhase()))
	{
		bool bNextSkillFollowing = CombatPresenter->HasEventQueued(ECCEventType::SkillUsed, ECCEventType::StartPhase);
		bool bNextPhaseFollowing = CombatPresenter->HasEventQueued(ECCEventType::StartPhase, ECCEventType::Invalid);

		bResetCamera = !bNextSkillFollowing && !bNextPhaseFollowing;
	}

	if (Super::Prepare())
	{
		if (PassiveBuffInstance)
		{
			PassiveBuffInstance->Prepare();
			PassiveBuffInstance = nullptr;
		}

		if (InheritedBuffInstance)
		{
			InheritedBuffInstance->Prepare();
			InheritedBuffInstance = nullptr;
		}

		return true;
	}

	return false;
}

static bool _HasCameraChange(ESpawnReason Reason)
{
	switch (Reason)
	{
		case ESpawnReason::Summon:
			return true;
		default:
			return false;
	}
}

static bool _HasSpawnFX(ESpawnReason Reason, bool bAlly)
{
	switch (Reason)
	{
		case ESpawnReason::Init:
			return !bAlly;
		case ESpawnReason::Summon:
		case ESpawnReason::Rebirth:
		case ESpawnReason::WipeoutContinue:
		case ESpawnReason::RebirthSummon:
			return true;
		default:
			return false;
	}
}

static bool _HasSpawnMove(ESpawnReason Reason, bool bAlly)
{
	if (!bAlly)
	{
		return false;
	}

	switch (Reason)
	{
		case ESpawnReason::SubParty:
			return true;
		case ESpawnReason::Init:
			// move is done in wave instance
		default:
			return false;
	}
}

static bool _ShouldSpawnOutCam(ESpawnReason Reason, bool bAlly)
{
	if (!bAlly)
	{
		return false;
	}

	switch (Reason)
	{
		case ESpawnReason::Init:
		case ESpawnReason::SubParty:
			return true;
		default:
			return false;
	}
}

void UCPSpawnInstance::Start()
{
	Super::Start();

	ESpawnReason SpawnReason = SpawnUnitEvent->SpawnReason;
	bool bAlly = SpawnUnitEvent->UnitState.IsAlly();
	bool bSpawnOutCam = _ShouldSpawnOutCam(SpawnReason, bAlly);

	// ChangeCombatMultiSide need not spawn unit, update the HUD only
	if (SpawnReason == ESpawnReason::ChangeCombatMultiSide)
	{
		StartHUD();
		End();
		return;
	}

	AUnit* NewUnit = CombatPresenter->SpawnUnit(SpawnUnitEvent->UnitState, bSpawnOutCam);
	if (!NewUnit)
	{
		Q6JsonLogSunny(Warning, "UCPSpawnInstance::Start - fail to spawn unit", Q6KV("UnitId", SpawnUnitEvent->UnitState.UnitId));
		End();
		return;
	}
	UnitId = NewUnit->GetUnitId();

	if (bUsingTurnSkillCamera)
	{
		CombatPresenter->DropTurnPrepareUnits();
	}

	if (_HasCameraChange(SpawnReason))
	{
		StartCamera();
	}

	if (_HasSpawnMove(SpawnReason, bAlly))
	{
		bSpawnEffectFinished = true;

		NewUnit->AnimMoveEndDelegate.BindUObject(this, &UCPSpawnInstance::StartHUD);

		FTransform WaveTransform = CombatPresenter->GetWaveTransform(NewUnit->GetOverrideFaction(), NewUnit->GetUnitState().Slot);
		NewUnit->MoveToWave(WaveTransform);
	}
	else
	{
		StartHUD();

		if (_HasSpawnFX(SpawnReason, bAlly))
		{
			AUnit* SourceUnit = NewUnit->GetSourceUnit();
			if (SourceUnit)
			{
				SourceUnit->SpawnEffectFinishedDelegate.BindUObject(this, &UCPSpawnInstance::OnSpawnEffectFinished);
			}

			NewUnit->StartSpawnFX(SpawnUnitEvent->SpawnReason);
		}
		else
		{
			OnSpawnEffectFinished();
		}
	}
}

void UCPSpawnInstance::StartCamera()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->ChangeToWaveCamera();
	}
}

void UCPSpawnInstance::StartHUD()
{
	// HUD need spawned unit so keep it after spawn unit
	GetCheckedCombatHUD(this)->OnSpawnUnit(SpawnUnitEvent);
}

void UCPSpawnInstance::OnSpawnHUDAnimFinished()
{
	bHUDAnimStarted = true;
	if (bSpawnEffectFinished)
	{
		End();
	}
}

void UCPSpawnInstance::OnSpawnEffectFinished()
{
	bSpawnEffectFinished = true;
	if (bHUDAnimStarted)
	{
		End();
	}
}

void UCPSpawnInstance::End()
{
	if (bUsingTurnSkillCamera)
	{
		CombatPresenter->RestoreTurnPrepareUnits();
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController && bResetCamera)
	{
		if (bUsingTurnSkillCamera)
		{
			PlayerController->RestoreSavedCamera(ECombatCameraBlendType::NoBlend);
		}
		else
		{
			PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend);
		}
	}

	Super::End();
}

void UCPSpawnInstance::BindContentDelegate()
{
	GetCheckedCombatHUD(this)->OnSpawnAnimFinishedDelegate.BindUObject(this, &UCPSpawnInstance::OnSpawnHUDAnimFinished);
}

void UCPSpawnInstance::UnbindContentDelegate()
{
	AUnit* SpawnedUnit = CombatPresenter->FindUnit(UnitId);
	AUnit* SourceUnit = SpawnedUnit ? SpawnedUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimMoveEndDelegate.Unbind();
		SourceUnit->SpawnEffectFinishedDelegate.Unbind();
	}

	GetCheckedCombatHUD(this)->OnSpawnAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPDeadInstance

UCPDeadInstance::UCPDeadInstance()
	: bSkipCamera(false)
{}

const TArray<FCCUnitId>& UCPDeadInstance::GetUnitIds() const
{
	return UnitDeadEvent->UnitIds;
}

void UCPDeadInstance::Start()
{
	Super::Start();

	if (CombatPresenter->GetTurnPhase() == ECCTurnPhase::TurnSkill)
	{
		CombatPresenter->DropTurnPrepareUnits();
	}

	bool bHasAllyUnits = false;
	for (const FCCUnitId& UnitId : UnitDeadEvent->UnitIds)
	{
		AUnit* TargetUnit = CombatPresenter->FindUnit(UnitId);
		ensure(TargetUnit);

		GetCheckedCombatHUD(this)->OnDead(UnitId);

		const ECCFaction TargetUnitFaction = TargetUnit->GetOverrideFaction();
		if (TargetUnitFaction == ECCFaction::Enemy && !TargetUnit->IsInvisibleDropBox())
		{
			CombatPresenter->SpawnDropBox(UnitId);
		}
		else if (TargetUnitFaction == ECCFaction::Ally)
		{
			bHasAllyUnits = true;
		}

		TargetUnit->SetDead();
	}

	CombatPresenter->TargetMonsterIfCurrentIsDead();

	if (UnitDeadEvent->IsSubPartClearing)
	{
		OnUnitDeadEffectFinished();
		return;
	}

	if (bSkipCamera)
	{
		return;
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		const int32 UnitIdsNum = UnitDeadEvent->UnitIds.Num();
		if (UnitIdsNum == 1)
		{
			AUnit* TargetUnit = CombatPresenter->FindUnit(UnitDeadEvent->UnitIds[0]);
			// ally unit is only one always
			if (TargetUnit->GetOverrideFaction() == ECCFaction::Ally)
			{
				int32 TargetSlot = TargetUnit->GetUnitState().Slot;
				PlayerController->ChangeToAllyCamera(TargetSlot);
			}
			else
			{
				PlayerController->ChangeToEnemyCamera(TargetUnit->GetSlot(), CombatPresenter->GetWaveEnemyNumSlots(), CombatPresenter->IsWaveEnemyDefaultPosition());
			}
		}
		else
		{
			if (bHasAllyUnits)
			{
				Q6JsonLogPawn(Warning, "UCPDeadInstance::Start() - ally unit must be only one");
			}
			else
			{
				PlayerController->ChangeToFactionAllCamera(ECCFaction::Enemy);

				// the monsters were dead at the same time
				const int32 PlayingDeadVoiceSlot = GetMonsterSlotOfPlayingDeadVoice(UnitIdsNum);
				for (const FCCUnitId& UnitId : UnitDeadEvent->UnitIds)
				{
					AUnit* TargetUnit = CombatPresenter->FindUnit(UnitId);
					if (TargetUnit->GetSlot() != PlayingDeadVoiceSlot)
					{
						TargetUnit->SetMuteDeadVoice(true);
					}
				}
			}
		}
	}
}

int32 UCPDeadInstance::GetMonsterSlotOfPlayingDeadVoice(int32 InNumOfDeadMonsters)
{
	check(InNumOfDeadMonsters > 1 && InNumOfDeadMonsters <= CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT);

	// pawn - slot priority of playing monster's dead voice - [2, 3, 1]
	if (InNumOfDeadMonsters == CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT)
	{
		return 2;
	}

	return CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT;
}

void UCPDeadInstance::OnUnitDeadEffectFinished()
{
	bool bUnitDeadFollowing = CombatPresenter->HasEventQueued(ECCEventType::UnitDead, ECCEventType::Invalid);
	bool bPhaseStartFollowing = CombatPresenter->HasEventQueued(ECCEventType::StartPhase, ECCEventType::Invalid);
	bool bWaveStartFollowing = CombatPresenter->HasEventQueued(ECCEventType::StartWave, ECCEventType::Invalid);

	ECPTurnPhase CPTurnPhase = CombatPresenter->CCPhaseToCPPhase(CombatPresenter->GetTurnPhase());
	switch (CPTurnPhase)
	{
		case ECPTurnPhase::TurnSkill:
			{
				bResetCamera = !bUnitDeadFollowing && !bWaveStartFollowing;
				if (bResetCamera)
				{
					CombatPresenter->RestoreTurnPrepareUnits();
				}
			}
			break;
		case ECPTurnPhase::Steady:
		case ECPTurnPhase::Attack:
			{
				bResetCamera = bResetCamera && !bUnitDeadFollowing && (!bPhaseStartFollowing || bWaveStartFollowing);
				ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
				if (bResetCamera && PlayerController)
				{
					bool bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend);
					if (!bWaitCamera)
					{
						OnCameraBlendingFinished(false);
					}
					return;
				}
			}
			break;
		default:
			break;
	}

	End();
}

void UCPDeadInstance::OnCameraBlendingFinished(bool bRestoring)
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController && PlayerController->GetCombatCameraType() == ECombatCamera::AllyAll)
	{
		End();
	}
}

void UCPDeadInstance::BindContentDelegate()
{
	for (const FCCUnitId& UnitId : UnitDeadEvent->UnitIds)
	{
		AUnit* TargetUnit = CombatPresenter->FindUnit(UnitId);
		AUnit* TargetSourceUnit = TargetUnit ? TargetUnit->GetSourceUnit() : nullptr;
		if (TargetSourceUnit)
		{
			TargetSourceUnit->DeadEffectFinishedDelegate.BindUObject(this, &UCPDeadInstance::OnUnitDeadEffectFinished);
		}
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPDeadInstance::OnCameraBlendingFinished);
	}
}

void UCPDeadInstance::UnbindContentDelegate()
{
	for (const FCCUnitId& UnitId : UnitDeadEvent->UnitIds)
	{
		AUnit* TargetUnit = CombatPresenter->FindUnit(UnitId);
		AUnit* TargetSourceUnit = TargetUnit ? TargetUnit->GetSourceUnit() : nullptr;
		if (TargetSourceUnit)
		{
			TargetSourceUnit->DeadEffectFinishedDelegate.Unbind();
		}
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// FCPSkillEffect

FCPSkillEffect::FCPSkillEffect(const UCCSkillEffectEvent* InCCEvent)
	: SourceUnitId(InCCEvent->SourceUnitId)
	, DamageEvents(InCCEvent->DamageEvents)
	, HealEvents(InCCEvent->HealEvents)
{
}

bool FCPSkillEffect::AddSkillEffect(const UCCSkillEffectEvent* InCCEvent)
{
	if (SourceUnitId != InCCEvent->SourceUnitId)
	{
		return false;
	}

	DamageEvents.Append(InCCEvent->DamageEvents);
	HealEvents.Append(InCCEvent->HealEvents);

	return true;
}

//////////////////////////////////////////////////////////////////////////////////
// UCPSkillInstance

UCPSkillInstance::UCPSkillInstance()
	: ActiveSkillOwnerGotOverKill(0)
	, OwnerUnit(nullptr)
	, OwnerFaction(ECCFaction::Max)
	, TargetType(ETargetType::Self)
	, bNoHit(false)
	, bHitFinished(false)
	, bSequenceFinished(false)
	, bEnded(false)
	, bHasSkillDrivenEffect(false)
	, bHasDeadUnit(false)
	, bDoubleSkillFollowing(false)
	, bPrepareActionFinished(false)
	, bHitStarted(false)
	, ProcessingMissingHitStartTime(0.f)
	, bProcessingDelayedHit(false)
	, ProcessingSkillEffectHitIndex(INDEX_NONE)
	, ProcessHitDelay(0.f)
	, LastProcessHitTime(0.f)
	, DelayedHitParticleParam()
	, DelayedHitSoundParam()
	, DelayedHitMeshDesc()
{
}

static void _CreateShieldBreakingUnitHits(ENatureRelationType NatureRelationType, FCPSkillEffectHit& InOutSkillEffectHit, FSkillAnimHitInfo& AnimHitPerEffect, int32 HitCount, float HitDiv, FCCUnitId SourceUnitId, const UCCSkillEffectHealthEvent& HealthEvent)
{
	TArray<int32> OverKillAmounts;
	for (int32 HitIdx = 0; HitIdx < HitCount; ++HitIdx)
	{
		int32 OverKillAmount = AnimHitPerEffect.GetAmount(HitIdx, HitCount - 1, HealthEvent.AddedOverKill, HitDiv);
		OverKillAmounts.Add(OverKillAmount);
	}

	int32 ShieldHitCount = FMath::DivideAndRoundUp(HitCount * FMath::Abs(HealthEvent.ShieldDamage), FMath::Abs(HealthEvent.AddedBaseHealth + HealthEvent.ShieldDamage));
	const float ShieldHitDiv = AnimHitPerEffect.GetHitFormulaDivRange(0, ShieldHitCount - 1);
	for (int32 ShieldHitIdx = 0; ShieldHitIdx < ShieldHitCount; ++ShieldHitIdx)
	{
		int32 BaseHealthAmount = 0;
		int32 ExtraHealthAmount = 0;
		int32 ShieldDamageAmount = AnimHitPerEffect.GetAmount(ShieldHitIdx, ShieldHitCount - 1, HealthEvent.ShieldDamage, HitDiv);
		int32 ExtraShieldDamageAmount = AnimHitPerEffect.GetAmount(ShieldHitIdx, ShieldHitCount - 1, HealthEvent.ExtraShieldDamage, HitDiv);

		UUnitHit* UnitHit = NewObject<UUnitHit>();
		UnitHit->SetInfo(NatureRelationType, SourceUnitId, HealthEvent.TargetUnitId, BaseHealthAmount, ExtraHealthAmount, ShieldDamageAmount, ExtraShieldDamageAmount, HealthEvent.IsShieldWeakPoint,
			OverKillAmounts[ShieldHitIdx], HealthEvent.Reason, ShieldHitIdx, HitCount, HealthEvent.IsCritical, HealthEvent.IsDodged);
		InOutSkillEffectHit.UnitHits.Add(UnitHit);
	}

	const float HealthHitDiv = AnimHitPerEffect.GetHitFormulaDivRange(ShieldHitCount, AnimHitPerEffect.HitValues.Num() - 1);
	for (int32 HealthHitIdx = ShieldHitCount; HealthHitIdx < HitCount; ++HealthHitIdx)
	{
		int32 BaseHealthAmount = AnimHitPerEffect.GetAmount(HealthHitIdx, HitCount - 1, HealthEvent.AddedBaseHealth, HealthHitDiv);
		int32 ExtraHealthAmount = AnimHitPerEffect.GetAmount(HealthHitIdx, HitCount - 1, HealthEvent.AddedExtraHealth, HealthHitDiv);
		int32 ShieldDamageAmount = 0;
		int32 ExtraShieldDamageAmount = 0;

		UUnitHit* UnitHit = NewObject<UUnitHit>();
		UnitHit->SetInfo(NatureRelationType, SourceUnitId, HealthEvent.TargetUnitId, BaseHealthAmount, ExtraHealthAmount, ShieldDamageAmount, ExtraShieldDamageAmount, HealthEvent.IsShieldWeakPoint,
			OverKillAmounts[HealthHitIdx], HealthEvent.Reason, HealthHitIdx, HitCount, HealthEvent.IsCritical, HealthEvent.IsDodged);
		InOutSkillEffectHit.UnitHits.Add(UnitHit);
	}
}

static void _CreateUnitHits(const ACombatPresenter* InCombatPresenter, FCPSkillEffectHit& InOutSkillEffectHit, FSkillAnimHitInfo& AnimHitPerEffect, int32 HitCount, float HitDiv, FCCUnitId SourceUnitId, const UCCSkillEffectHealthEvent& HealthEvent)
{
	ENatureRelationType NatureRelationType = InCombatPresenter->GetUnitNatureRelationType(SourceUnitId, HealthEvent.TargetUnitId);

	if (HealthEvent.Reason == EHealthChangeReason::Damage)
	{
		bool bShieldBroken = HealthEvent.AddedBaseHealth && HealthEvent.ShieldDamage;
		if (bShieldBroken && HitCount > 1)
		{
			_CreateShieldBreakingUnitHits(NatureRelationType, InOutSkillEffectHit, AnimHitPerEffect, HitCount, HitDiv, SourceUnitId, HealthEvent);
			return;
		}
	}

	for (int32 HitIdx = 0; HitIdx < HitCount; ++HitIdx)
	{
		int32 BaseHealthAmount = AnimHitPerEffect.GetAmount(HitIdx, HitCount - 1, HealthEvent.AddedBaseHealth, HitDiv);
		int32 ExtraHealthAmount = AnimHitPerEffect.GetAmount(HitIdx, HitCount - 1, HealthEvent.AddedExtraHealth, HitDiv);
		int32 OverKillAmount = AnimHitPerEffect.GetAmount(HitIdx, HitCount - 1, HealthEvent.AddedOverKill, HitDiv);
		int32 ShieldDamageAmount = AnimHitPerEffect.GetAmount(HitIdx, HitCount - 1, HealthEvent.ShieldDamage, HitDiv);
		int32 ExtraShieldDamageAmount = AnimHitPerEffect.GetAmount(HitIdx, HitCount - 1, HealthEvent.ExtraShieldDamage, HitDiv);

		UUnitHit* UnitHit = NewObject<UUnitHit>();
		UnitHit->SetInfo(NatureRelationType, SourceUnitId, HealthEvent.TargetUnitId, BaseHealthAmount, ExtraHealthAmount, ShieldDamageAmount, ExtraShieldDamageAmount, HealthEvent.IsShieldWeakPoint,
			OverKillAmount, HealthEvent.Reason, HitIdx, HitCount, HealthEvent.IsCritical, HealthEvent.IsDodged);
		InOutSkillEffectHit.UnitHits.Add(UnitHit);
	}
}

static bool _CreateHitInfo(const ACombatPresenter* InCombatPresenter, TArray<FCPSkillEffectHit>& InOutSkillEffectHits, const FCPSkillEffect& SkillEffect, FSkillAnimHitInfo& AnimHitPerEffect)
{
	const int32 HitCount = AnimHitPerEffect.HitValues.Num();
	if (!HitCount)
	{
		return false;
	}
	const float HitDiv = AnimHitPerEffect.GetHitFormulaDiv();

	for (const UCCSkillEffectHealthEvent* DamageEvent : SkillEffect.DamageEvents)
	{
		FCPSkillEffectHit& SkillEffectHit = InOutSkillEffectHits.AddDefaulted_GetRef();
		_CreateUnitHits(InCombatPresenter, SkillEffectHit, AnimHitPerEffect, HitCount, HitDiv, SkillEffect.SourceUnitId, *DamageEvent);
	}

	for (const UCCSkillEffectHealthEvent* HealEvent : SkillEffect.HealEvents)
	{
		FCPSkillEffectHit& SkillEffectHit = InOutSkillEffectHits.AddDefaulted_GetRef();
		_CreateUnitHits(InCombatPresenter, SkillEffectHit, AnimHitPerEffect, HitCount, HitDiv, SkillEffect.SourceUnitId, *HealEvent);
	}

	return true;
}

void UCPSkillInstance::GenerateSkillEffects()
{
	SkillEffects.Empty();

	if (!SkillEffectEvents.Num())
	{
		return;
	}

	ETargetType PrevTargetType = ETargetType::Self;

	for (const UCCSkillEffectEvent* SkillEffectEvent : SkillEffectEvents)
	{
		if (!SkillEffectEvent->DamageEvents.Num() && !SkillEffectEvent->HealEvents.Num())
		{
			continue;
		}

		const FCMSSkillEffectRow& SkillEffectRow = GetCMS()->GetSkillEffectRowOrDummy(FSkillEffectType(SkillEffectEvent->SkillEffectType));
		ETargetType CurTargetType = SkillEffectRow.Target;

		if (SkillEffects.Num())
		{
			if (CurTargetType == PrevTargetType)
			{
				SkillEffects.Last(0).AddSkillEffect(SkillEffectEvent);
				continue;
			}
		}

		PrevTargetType = CurTargetType;
		SkillEffects.Add(FCPSkillEffect(SkillEffectEvent));
	}
}

void UCPSkillInstance::CreateAnimHitInfo()
{
	TArray<FSkillAnimHitInfo> AnimHitsPerEffect;

	if (OwnerUnit)
	{
		OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
		OwnerUnit->GetSkillAnimNotifyInfo(SkillUsedEvent->SkillType, AnimHitsPerEffect);
	}

	GenerateSkillEffects();
	CreateAnimHitInfoInternal(AnimHitsPerEffect);

	if (!AnimHitsPerEffect.IsValidIndex(0))
	{
		return;
	}

	int32 Index = 0;
	while (AnimHitsPerEffect.IsValidIndex(Index) && SkillEffects.IsValidIndex(Index))
	{
		if (_CreateHitInfo(CombatPresenter.Get(), SkillEffectHits, SkillEffects[Index], AnimHitsPerEffect[Index]))
		{
			SkillEffects.RemoveAt(Index, 1, false);
			AnimHitsPerEffect.RemoveAt(Index, 1, false);
		}
		else
		{
			++Index;
		}
	}
}

bool UCPSkillInstance::Initialize()
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillUsedEvent->SkillType);
	TargetType = SkillRow.Target;

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (OwnerUnit)
	{
		OwnerFaction = OwnerUnit->GetOverrideFaction();
	}
	else
	{
		OwnerFaction = (CombatPresenter->GetAllyMaster().MasterId == SkillUsedEvent->UnitId) ? ECCFaction::Ally : ECCFaction::Enemy;
	}

	InitializeInternal();

	bool bAllyActiveSkill = OwnerFaction == ECCFaction::Ally && IsActiveSkill();
	SetResetCamera(!IsLastSkill() && bAllyActiveSkill);

	return true;
}

static bool _IsTargetTypeAll(ETargetType InTargetType)
{
	switch (InTargetType)
	{
		case ETargetType::FriendlyOther:
		case ETargetType::FriendlyAll:
		case ETargetType::HostileAll:
			return true;
		default:
			return false;
	}
}

bool UCPSkillInstance::Prepare()
{
	if (!Initialize())
	{
		return false;
	}

	return Super::Prepare();
}

void UCPSkillInstance::Start()
{
	Super::Start();

	CreateAnimHitInfo();
	bNoHit = !SkillEffects.Num();

	GetCheckedCombatHUD(this)->OnSkillStart(SkillUsedEvent);
	ProcessPointEvents(StartInstancePointEvents);

	StartInternal();
}

void UCPSkillInstance::StartInternal()
{
	PrepareAction();
}

void UCPSkillInstance::PrepareAction()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	check(PlayerController);

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (!OwnerUnit)
	{
		Q6JsonLogSunny(Error, "UCPSkillInstance::PrepareAction - Invalid Owner Unit", Q6KV("OwnerUnitId", SkillUsedEvent->UnitId));
		End();
		return;
	}
	OwnerUnit->SetSupporter(SkillUsedEvent->IsSupporter);

	if (OwnerFaction == ECCFaction::Ally)
	{
		CombatPresenter->SetDecalVisible(false);
	}

	AUnit* SourceUnit = OwnerUnit->GetSourceUnit();
	bool bWaitCamera = false;

	if (IsActiveSkill())
	{
		// rotate units
		if (TargetType == ETargetType::HostileSingle)
		{
			AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
			if (TargetUnit && SourceUnit)
			{
				TargetUnit->RotateToTargetUnit(SourceUnit);
				SourceUnit->RotateToTargetUnit(TargetUnit);
			}
		}
		else if (TargetType == ETargetType::HostileAll)
		{
			if (SourceUnit)
			{
				ECCFaction TargetFaction = OwnerFaction == ECCFaction::Ally ? ECCFaction::Enemy : ECCFaction::Ally;
				for (AUnit* TargetUnit : CombatPresenter->FindUnitsByFaction(TargetFaction))
				{
					TargetUnit->RotateToTargetUnit(SourceUnit);
				}

				SourceUnit->RotateToLocation(CombatPresenter->GetFactionAllTargetLocation(TargetFaction));
			}
		}

		if (OwnerFaction == ECCFaction::Ally)
		{
			bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend, false);
		}
	}

	bWaitCamera |= PrepareActionInternal();

	if (!bWaitCamera)
	{
		OnCameraBlendingFinished(false);
	}
}

void UCPSkillInstance::OnCameraBlendingFinished(bool bRestoring)
{
	if (bPrepareActionFinished)
	{
		StartAction();
		return;
	}
	bPrepareActionFinished = true;

	if (!IsActiveSkill())
	{
		StartAction();
		return;
	}

	// change to attack camera
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);

	int32 TargetSlot = CombatCubeConst::Q6_INVALID_SLOT;
	if (OwnerUnit && OwnerFaction == ECCFaction::Ally)
	{
		TargetSlot = OwnerUnit->GetUnitState().Slot;
	}
	else if (!_IsTargetTypeAll(TargetType) && TargetUnit && TargetUnit->GetOverrideFaction() == ECCFaction::Ally)
	{
		TargetSlot = TargetUnit->GetUnitState().Slot;
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	check(PlayerController);

	bool bWaitCamera = false;
	if (TargetSlot != CombatCubeConst::Q6_INVALID_SLOT)
	{
		bWaitCamera = PlayerController->ChangeToAllyCamera(TargetSlot, false);
		if (bWaitCamera)
		{
			float AllyCameraWaitingTime = CVarAllyCameraBlendTime.GetValueOnGameThread() * CVarCameraWaitingTimeRatio.GetValueOnGameThread();
			PlayerController->SetCombatCameraWaitingTime(AllyCameraWaitingTime);
		}
	}
	else
	{
		bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend, false);
	}

	if (!bWaitCamera)
	{
		OnCameraBlendingFinished(false);
	}
}

void UCPSkillInstance::StartAction()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();

		if (!IsActiveSkill())
		{
			PlayerController->SaveCurrentCamera();
		}
	}

	switch (SkillUsedEvent->SkillCategory)
	{
		case ESkillCategory::Normal:
		case ESkillCategory::Ultimate:
		case ESkillCategory::TurnBegin:
		case ESkillCategory::Moment:
		case ESkillCategory::Double:
		case ESkillCategory::Artifact:
		case ESkillCategory::Pet:
			StartActionInternal();
			break;
		case ESkillCategory::Support:
		case ESkillCategory::RaidSupport:
			End();
			break;
		case ESkillCategory::Versa:
		case ESkillCategory::Chain:
		case ESkillCategory::RaidTurnBegin:
		default:
			{
				Q6JsonLogSunny(Error, "UCPSkillInstance::StartAction - Invalid Skill Category", Q6KV("SkillCategory", (uint8)SkillUsedEvent->SkillCategory));
				End();
			}
			break;
	}
}

FCCSkillId UCPSkillInstance::GetSkillId() const
{
	return SkillUsedEvent->SkillId;
}

int32 UCPSkillInstance::GetSkillType() const
{
	return SkillUsedEvent->SkillType;
}

FCCUnitId UCPSkillInstance::GetSkillOwnerUnitId() const
{
	return SkillUsedEvent->UnitId;
}

ESkillCategory UCPSkillInstance::GetSkillCategory() const
{
	return SkillUsedEvent->SkillCategory;
}

EMoment UCPSkillInstance::GetMoment() const
{
	return SkillUsedEvent->Moment;
}

bool UCPSkillInstance::IsLastSkill() const
{
	return SkillUsedEvent->IsLast;
}

bool UCPSkillInstance::IsActiveSkill() const
{
	switch (SkillUsedEvent->SkillCategory)
	{
		case ESkillCategory::Normal:
		case ESkillCategory::Double:
		case ESkillCategory::Ultimate:
			return true;
		default:
			return false;
	}
}

bool UCPSkillInstance::IsInterruptable() const
{
	return SkillUsedEvent->SkillCategory == ESkillCategory::Normal && !IsLastSkill();
}

bool UCPSkillInstance::IsInterruptive() const
{
	return SkillUsedEvent->SkillCategory == ESkillCategory::Moment;
}

bool UCPSkillInstance::ShouldSkipBuffEffect() const
{
	switch (SkillUsedEvent->SkillCategory)
	{
		case ESkillCategory::Versa:
			return true;
		default:
			return false;
	}
}

void UCPSkillInstance::OnSequenceFinished()
{
	bSequenceFinished = true;
}

void UCPSkillInstance::OnHit(const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam)
{
	static FSpawnSkeletalMeshDesc DummyMeshDesc;

	ProcessHitEvents(HitParticleParam, HitSoundParam, DummyMeshDesc);
}

void UCPSkillInstance::OnHitPost(const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam, const FSpawnSkeletalMeshDesc& MeshDesc, bool bRandomDelay)
{
	if (bRandomDelay)
	{
		DelayedHitParticleParam = HitParticleParam;
		DelayedHitSoundParam = HitSoundParam;
		DelayedHitMeshDesc = MeshDesc;

		ProcessingSkillEffectHitIndex = 0;
		ProcessHitDelay = 0.f;
		LastProcessHitTime = GetWorld()->GetTimeSeconds();
		bProcessingDelayedHit = true;
	}
	else
	{
		ProcessHitEvents(HitParticleParam, HitSoundParam, MeshDesc);
	}
}

void UCPSkillInstance::OnFireProjectile(const FProjectileEffectDesc& Desc, const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam)
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	ensure(OwnerUnit);

	AUnit* SourceUnit = OwnerUnit->GetSourceUnit();
	ensure(SourceUnit);

	AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
	ensure(TargetUnit);

	if (SourceUnit && TargetUnit)
	{
		FSpawnProjectileParams Param;
		Param.Desc = Desc;
		Param.HitParticleParam = HitParticleParam;
		Param.HitSoundParam = HitSoundParam;
		Param.SourceTransform = SourceUnit->GetSocketTransform(Desc.StartSocket);
		Param.SourceUnitId = SourceUnit->GetUnitId();

		if (_IsTargetTypeAll(TargetType))
		{
			Param.TargetLocation = CombatPresenter->GetFactionAllTargetLocation(TargetUnit->GetOverrideFaction());
			Param.TargetUnitId = CCUnitIdInvalid;
		}
		else
		{
			Param.TargetLocation = TargetUnit->GetSocketTransform(Desc.TargetSocket).GetLocation();
			Param.TargetUnitId = TargetUnit->GetUnitId();
		}

		CombatPresenter->SpawnProjectile(Param);

		SetTimeOutLimit(DEFAULT_INSTANCE_TIMEOUT, true);
	}
}

void UCPSkillInstance::OnPlayBeamParticleEffect(const FBeamParticleEffectDesc& Desc, float TotalDuration)
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	ensure(OwnerUnit);

	AUnit* SourceUnit = OwnerUnit->GetSourceUnit();
	ensure(SourceUnit);

	AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
	ensure(TargetUnit);

	if (SourceUnit && TargetUnit)
	{
		FSpawnBeamParticleParams Param;
		Param.Desc = Desc;
		Param.Duration = TotalDuration;
		Param.SourceUnitId = SourceUnit->GetUnitId();
		Param.TargetUnitId = TargetUnit->GetUnitId();
		CombatPresenter->SpawnBeamParticle(Param);
	}
}

void UCPSkillInstance::OnPlayParticleEffectOnTarget(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam)
{
	AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Warning, "UCPSkillInstance::OnPlayParticleEffectOnTarget - Invalid TargetUnit", Q6KV("TargetUnitId", SkillUsedEvent->TargetUnitId));
		return;
	}

	TargetUnit->StartParticleEffects(ParticleParam, SoundParam);
}

void UCPSkillInstance::OnSpawnSkeletalMesh(const FSpawnSkeletalMeshDesc& Desc, float OverrideDuration, bool bTarget)
{
	AUnit* SpawnUnit = nullptr;
	if (bTarget)
	{
		SpawnUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
	}
	else
	{
		SpawnUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	}

	if (SpawnUnit)
	{
		RegisterSpawnMeshParam(SpawnUnit, Desc, OverrideDuration);
	}
}

void UCPSkillInstance::RegisterSpawnMeshParam(AUnit* Unit, const FSpawnSkeletalMeshDesc& Desc, float EndDuration, FVector Location)
{
	if (!Desc.IsValid())
	{
		return;
	}

	FSpawnSkeletalMeshParams Params;
	Params.Desc = Desc;
	Params.Location = Location;

	if (Params.Desc.bDestroyAtEnd)
	{
		if (EndDuration < 0.0f)
		{
			EndDuration = Desc.AnimSequence->GetPlayLength();
		}

		Params.Desc.Duration = EndDuration;
	}

	if (Unit)
	{
		Params.UnitId = Unit->GetUnitId();
	}

	CombatPresenter->SpawnSkeletalMesh(Params);
}

void UCPSkillInstance::AddUAEvent(const UCCUnitUAChangedEvent* InUAEvent)
{
	switch (InUAEvent->Reason)
	{
		case EPointChangeReason::SkillConsume:
			StartInstancePointEvents.AddUAEvent(InUAEvent);
			break;
		case EPointChangeReason::SkillEffect:
			FirstHitPointEvents.AddUAEvent(InUAEvent);
			break;
		default:
			LastHitPointEvents.AddUAEvent(InUAEvent);
			break;
	}
}

void UCPSkillInstance::AddSAEvent(const UCCUnitSAChangedEvent* InSAEvent)
{
	switch (InSAEvent->Reason)
	{
		case EPointChangeReason::SkillConsume:
			StartInstancePointEvents.AddSAEvent(InSAEvent);
			break;
		case EPointChangeReason::SkillEffect:
			FirstHitPointEvents.AddSAEvent(InSAEvent);
			break;
		default:
			LastHitPointEvents.AddSAEvent(InSAEvent);
			break;
	}
}

void UCPSkillInstance::AddOverKillEvent(const UCCUnitOverKillChangedEvent* InOverKillEvent)
{
	if (IsActiveSkill() && InOverKillEvent->UnitId == GetSkillOwnerUnitId())
	{
		switch (InOverKillEvent->Reason)
		{
			case EPointChangeReason::SkillConsume:
				FirstHitPointEvents.AddOverKillEvent(InOverKillEvent);
				break;
			default:
				ActiveSkillOwnerGotOverKill += InOverKillEvent->AddedOverKill;
				break;
		}
	}
	else
	{
		switch (InOverKillEvent->Reason)
		{
			case EPointChangeReason::SkillConsume:
			case EPointChangeReason::SkillEffect:	// fall through
				FirstHitPointEvents.AddOverKillEvent(InOverKillEvent);
				break;
			default:
				LastHitPointEvents.AddOverKillEvent(InOverKillEvent);
				break;
		}
	}
}

void UCPSkillInstance::ProcessPointEvents(const FCPPointEvents& InPointEvents) const
{
	for (const UCCUnitUAChangedEvent* UAEvent : InPointEvents.UAEvents)
	{
		GetCheckedCombatHUD(this)->OnUAChanged(UAEvent);
	}

	for (const UCCUnitSAChangedEvent* SAEvent : InPointEvents.SAEvents)
	{
		GetCheckedCombatHUD(this)->OnSAChanged(SAEvent);
	}

	for (const UCCUnitOverKillChangedEvent* OverKillEvent : InPointEvents.OverKillEvents)
	{
		GetCheckedCombatHUD(this)->OnOverKillChanged(OverKillEvent);
	}
}

void UCPSkillInstance::ProcessFirstHit()
{
	bHitStarted = true;
	ProcessPointEvents(FirstHitPointEvents);
}

void UCPSkillInstance::ProcessLastHit()
{
	bHitFinished = true;
	ProcessPointEvents(LastHitPointEvents);

	if (ActiveSkillOwnerGotOverKill)
	{
		ensure(ActiveSkillOwnerGotOverKill > 0);
		GetCheckedCombatHUD(this)->AddOverKill(GetSkillOwnerUnitId(), ActiveSkillOwnerGotOverKill);
		ActiveSkillOwnerGotOverKill = 0;
	}
}

void UCPSkillInstance::ProcessHit(const UUnitHit* Hit,
								  const FSpawnParticleParams& HitParticleParam,
								  const FSpawnSoundParams& HitSoundParam,
								  const FSpawnSkeletalMeshDesc& MeshDesc)
{
	AUnit* TargetUnit = CombatPresenter->FindUnit(Hit->TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Warning, "UCPSkillInstance::ProcessHit - Invalid TargetUnit", Q6KV("TargetUnitId", Hit->TargetUnitId));
		return;
	}

	if (Hit->Reason == EHealthChangeReason::Damage && !Hit->bDodged)
	{
		if (Hit->ShieldDamage)
		{
			bool bShieldBroken = Hit->AddedBaseHealth != 0;
			TargetUnit->SetShieldHit(bShieldBroken);
		}
		
		if (Hit->AddedBaseHealth)
		{
			TargetUnit->SetHit(HitParticleParam, HitSoundParam);
			RegisterSpawnMeshParam(TargetUnit, MeshDesc);
		}
	}

	int32 CurHealth = TargetUnit->GetHealth();
	TargetUnit->SetHealth(CurHealth + Hit->AddedBaseHealth + Hit->AddedExtraHealth);

	int32 CurShield = TargetUnit->GetShield();
	TargetUnit->SetShield(CurShield + Hit->ShieldDamage + Hit->ExtraShieldDamage);

	GetCheckedCombatHUD(this)->OnHit(Hit, IsActiveSkill(), bDoubleSkillFollowing);

	ActiveSkillOwnerGotOverKill -= Hit->AddedOverKill;
	CombatPresenter->SpawnLoot(TargetUnit, ELootDropType::OverKillPoint, Hit->AddedOverKill, 1);
}

void UCPSkillInstance::ProcessHitEvents(const FSpawnParticleParams& HitParticleParam,
										const FSpawnSoundParams& HitSoundParam,
										const FSpawnSkeletalMeshDesc& MeshDesc)
{
	bool bLastHit = false;

	int32 Index = 0;
	while (SkillEffectHits.IsValidIndex(Index))
	{
		if (SkillEffectHits[Index].IsEmpty())
		{
			SkillEffectHits.RemoveAt(Index, 1, false);
			continue;
		}

		ProcessHit(SkillEffectHits[Index].UnitHits[0], HitParticleParam, HitSoundParam, MeshDesc);
		SkillEffectHits[Index].UnitHits.RemoveAt(0, 1, false);

		if (SkillEffectHits[Index].IsEmpty())
		{
			SkillEffectHits.RemoveAt(Index, 1, false);
			bLastHit = true;
		}
		else
		{
			++Index;
		}
	}

	if (!bHitStarted)
	{
		ProcessFirstHit();
	}

	if (bLastHit)
	{
		ProcessLastHit();
	}
}

void UCPSkillInstance::UpdateDelayedProcessHit()
{
	bool bLastHit = false;

	int32 Index = ProcessingSkillEffectHitIndex;
	if (SkillEffectHits.IsValidIndex(Index))
	{
		if (SkillEffectHits[Index].IsEmpty())
		{
			SkillEffectHits.RemoveAt(Index, 1, false);
			return;
		}

		if (LastProcessHitTime + ProcessHitDelay > GetWorld()->GetTimeSeconds())
		{
			return;
		}

		LastProcessHitTime = GetWorld()->GetTimeSeconds();
		ProcessHitDelay = FMath::RandRange(0.f, CVarPostHitRandomDelayMax.GetValueOnGameThread());

		ProcessHit(SkillEffectHits[Index].UnitHits[0], DelayedHitParticleParam, DelayedHitSoundParam, DelayedHitMeshDesc);
		SkillEffectHits[Index].UnitHits.RemoveAt(0, 1, false);

		if (SkillEffectHits[Index].IsEmpty())
		{
			SkillEffectHits.RemoveAt(Index, 1, false);
		}
		else
		{
			++ProcessingSkillEffectHitIndex;
		}

		bLastHit = !SkillEffectHits.IsValidIndex(ProcessingSkillEffectHitIndex);
	}

	if (!bHitStarted)
	{
		ProcessFirstHit();
	}

	if (bLastHit)
	{
		bProcessingDelayedHit = false;
		ProcessLastHit();
	}
}

bool UCPSkillInstance::HasMissingHitEvents() const
{
	return SkillEffectHits.Num() || SkillEffects.Num();
}

void UCPSkillInstance::ProcessMissingHit(const UUnitHit* Hit)
{
	static FSpawnParticleParams DummyParticleParam;
	static FSpawnSoundParams DummySoundParam;
	static FSpawnSkeletalMeshDesc DummyMeshDesc;

	ProcessHit(Hit, DummyParticleParam, DummySoundParam, DummyMeshDesc);
}

void UCPSkillInstance::ProcessMissingHitEvents()
{
	ProcessingMissingHitStartTime = GetWorld()->GetTimeSeconds();

	for (const FCPSkillEffectHit& SkillEffectHit : SkillEffectHits)
	{
		for (const UUnitHit* UnitHit : SkillEffectHit.UnitHits)
		{
			ProcessMissingHit(UnitHit);
		}
	}
	SkillEffectHits.Empty();

	for (const FCPSkillEffect& SkillEffect : SkillEffects)
	{
		for (const UCCSkillEffectHealthEvent* DamageEvent : SkillEffect.DamageEvents)
		{
			UUnitHit* Hit = NewObject<UUnitHit>();
			ENatureRelationType NatureRelationType = CombatPresenter->GetUnitNatureRelationType(SkillEffect.SourceUnitId, DamageEvent->TargetUnitId);
			Hit->SetInfo(NatureRelationType, GetSkillOwnerUnitId(), DamageEvent->TargetUnitId,
				DamageEvent->AddedBaseHealth, DamageEvent->AddedExtraHealth, DamageEvent->ShieldDamage, DamageEvent->ExtraShieldDamage, DamageEvent->IsShieldWeakPoint,
				DamageEvent->AddedOverKill, EHealthChangeReason::Damage, 0, 1, DamageEvent->IsCritical, DamageEvent->IsDodged);

			ProcessMissingHit(Hit);
		}

		for (const UCCSkillEffectHealthEvent* HealEvent : SkillEffect.HealEvents)
		{
			UUnitHit* Hit = NewObject<UUnitHit>();
			Hit->SetInfo(ENatureRelationType::Normal, GetSkillOwnerUnitId(), HealEvent->TargetUnitId,
				HealEvent->AddedBaseHealth, HealEvent->AddedExtraHealth, HealEvent->ShieldDamage, HealEvent->ExtraShieldDamage, HealEvent->IsShieldWeakPoint,
				HealEvent->AddedOverKill, HealEvent->Reason, 0, 1, false, false);

			ProcessMissingHit(Hit);
		}
	}
	SkillEffects.Empty();
}

void UCPSkillInstance::OnProcessMissingHitCameraBlendingFinished(bool bRestoring)
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}

	ProcessMissingHitEvents();
}

void UCPSkillInstance::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	if (bProcessingDelayedHit)
	{
		UpdateDelayedProcessHit();
		return;
	}

	if (ProcessingMissingHitStartTime > 0.f)
	{
		float TimeNow = GetWorld()->GetTimeSeconds();
		if (TimeNow - ProcessingMissingHitStartTime > 1.5f)
		{
			EndPostProcess();
			return;
		}
	}

	if (IsCompleteEnd())
	{
		End();
		return;
	}
}

void UCPSkillInstance::End()
{
	if (bEnded)
	{
		return;
	}
	bEnded = true;

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (IsActiveSkill() && PlayerController)
	{
		if (PlayerController->IsPlayingSequence())
		{
			PlayerController->StopSequencePlayer();
		}
	}

	EndInternal();

	if (HasMissingHitEvents())
	{
		GetCheckedCombatHUD(this)->OnDamageTextAnimFinishedDelegate.BindUObject(this, &UCPSkillInstance::EndPostProcess);

		bool bNeedFullView = IsActiveSkill() ? (OwnerFaction == ECCFaction::Ally && TargetType == ETargetType::FriendlyAll) : TargetType != ETargetType::Self;
		if (bNeedFullView && PlayerController)
		{
			PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPSkillInstance::OnProcessMissingHitCameraBlendingFinished);

			ECombatCameraBlendType BlendType = IsAnyAttackPhase(CombatPresenter->GetTurnPhase()) ?
				ECombatCameraBlendType::NormalBlend : ECombatCameraBlendType::NoBlend;
			bResetCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, BlendType);
			if (!bResetCamera)
			{
				PlayerController->SetCombatCameraWaitingTime(SMALL_NUMBER);
			}
		}
		else
		{
			ProcessMissingHitEvents();
		}
	}
	else
	{
		EndPostProcess();
	}
}

void UCPSkillInstance::EndPostProcess()
{
	ProcessingMissingHitStartTime = 0.f;
	GetCheckedCombatHUD(this)->OnDamageTextAnimFinishedDelegate.Unbind();

	if (!bHitStarted)
	{
		ProcessFirstHit();
	}

	if (!bHitFinished)
	{
		ProcessLastHit();
	}

	EndPostProcessInternal();

	if (bResetCamera)
	{
		ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
		if (PlayerController)
		{
			bool bAnyAttackPhase = IsAnyAttackPhase(CombatPresenter->GetTurnPhase());
			if (bAnyAttackPhase)
			{
				PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend);
			}
			else
			{
				PlayerController->RestoreSavedCamera(ECombatCameraBlendType::NoBlend);
			}
		}

		CombatPresenter->SetDecalVisible(true);
	}

	if (!bHasSkillDrivenEffect)
	{
		CombatPresenter->OnSkillDrivenEffectEnd();
	}

	GetCheckedCombatHUD(this)->OnSkillEnd(SkillUsedEvent->UnitId, SkillUsedEvent->SkillCategory, SkillUsedEvent->IsPattern);

	if (!bDoubleSkillFollowing)
	{
		CombatPresenter->CollectLoot(OwnerUnit);
	}

	Super::End();
}

void UCPSkillInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPSkillInstance::OnCameraBlendingFinished);
	}

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimHitDelegate.BindUObject(this, &UCPSkillInstance::OnHit);
		SourceUnit->AnimFireProjectileDelegate.BindUObject(this, &UCPSkillInstance::OnFireProjectile);
		SourceUnit->AnimPlayBeamParticleEffectDelegate.BindUObject(this, &UCPSkillInstance::OnPlayBeamParticleEffect);
		SourceUnit->AnimPlayParticleEffectOnTargetDelegate.BindUObject(this, &UCPSkillInstance::OnPlayParticleEffectOnTarget);
		SourceUnit->AnimNotifySpawnSkeletalMeshDelegate.BindUObject(this, &UCPSkillInstance::OnSpawnSkeletalMesh);
	}
}

void UCPSkillInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimHitDelegate.Unbind();
		SourceUnit->AnimFireProjectileDelegate.Unbind();
		SourceUnit->AnimPlayBeamParticleEffectDelegate.Unbind();
		SourceUnit->AnimPlayParticleEffectOnTargetDelegate.Unbind();
		SourceUnit->AnimNotifySpawnSkeletalMeshDelegate.Unbind();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPMasterSkillInstance

UCPMasterSkillInstance::UCPMasterSkillInstance()
{
	bResetCamera = false;
}

void UCPMasterSkillInstance::StartInternal()
{
	End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPArtifactSkillInstance

UCPArtifactSkillInstance::UCPArtifactSkillInstance()
{
	bResetCamera = false;
}

void UCPArtifactSkillInstance::StartInternal()
{
	End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPPetSkillInstance

UCPPetSkillInstance::UCPPetSkillInstance()
{
	bResetCamera = false;
}

bool UCPPetSkillInstance::IsCompleteEnd() const
{
	return bSequenceFinished;
}

void UCPPetSkillInstance::StartInternal()
{
	APetUnit* PetUnit = CombatPresenter->GetPetUnit();
	if (!PetUnit)
	{
		End();
		return;
	}

	int32 PetSkillIndex = CombatPresenter->GetPetSkillIndex(SkillUsedEvent->SkillId);
	if (PetSkillIndex == INDEX_NONE)
	{
		End();
		return;
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PetUnit->ClearRandomIdleAnimTimer();
		PlayerController->PlayPetSkillSequence(this, PetUnit, PetSkillIndex);
	}
}

void UCPPetSkillInstance::EndInternal()
{
	APetUnit* PetUnit = CombatPresenter->GetPetUnit();
	if (PetUnit)
	{
		PetUnit->SetRandomIdleAnimTimer();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPMomentSkillInstance

UCPMomentSkillInstance::UCPMomentSkillInstance()
	: bSkipAction(false)
{
}

bool UCPMomentSkillInstance::HasHitEvents() const
{
	return SkillEffectEvents.Num();
}

void UCPMomentSkillInstance::StartInternal()
{
	End();
}

void UCPMomentSkillInstance::End()
{
	if (bEnded)
	{
		return;
	}
	bEnded = true;

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (!bSkipAction && PlayerController)
	{
		CombatPresenter->GetWorldTimerManager().ClearTimer(HitEventTimerHandle);
		CombatPresenter->GetWorldTimerManager().SetTimer(HitEventTimerHandle, this, &UCPMomentSkillInstance::EndPostProcess, 1.0f);

		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPMomentSkillInstance::OnProcessMissingHitCameraBlendingFinished);
		bResetCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend);
		if (!bResetCamera)
		{
			PlayerController->SetCombatCameraWaitingTime(SMALL_NUMBER);
		}
	}
	else
	{
		ProcessMissingHitEvents();
		EndPostProcess();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPTurnSkillInstance

UCPTurnSkillInstance::UCPTurnSkillInstance()
	: bAllyOwner(false)
{
}

void UCPTurnSkillInstance::Start()
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (!OwnerUnit)
	{
		Q6JsonLogSunny(Error, "UCPTurnSkillInstance::Start - Invalid Owner Unit", Q6KV("OwnerUnitId", SkillUsedEvent->UnitId));
		End();
		return;
	}

	bAllyOwner = OwnerFaction == ECCFaction::Ally;

	int32 TurnSkillIndex = INDEX_NONE;
	if (bAllyOwner)
	{
		TurnSkillIndex = GetCheckedCombatHUD(this)->GetSelectedTurnSkillIndex();
	}
	else
	{
		AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
		if (TargetUnit)
		{
			TurnSkillIndex = TargetUnit->GetOverrideFaction() == OwnerFaction ?
				ENEMY_TURN_SKILL_FRIENDLY_TARGET_INDEX : ENEMY_TURN_SKILL_HOSTILE_TARGET_INDEX;
		}
	}

	OwnerUnit->SetTurnSkillIndex(TurnSkillIndex);

	Super::Start();
}

bool UCPTurnSkillInstance::PrepareActionInternal()
{
	if (bAllyOwner)
	{
		return false;
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (!PlayerController)
	{
		return false;
	}

	return PlayerController->ChangeToEnemyCamera(OwnerUnit->GetSlot(), CombatPresenter->GetWaveEnemyNumSlots(), CombatPresenter->IsWaveEnemyDefaultPosition(), ECombatCameraBlendType::NormalBlend);
}

void UCPTurnSkillInstance::StartActionInternal()
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (!OwnerUnit)
	{
		Q6JsonLogSunny(Error, "UCPTurnSkillInstance::StartActionInternal - Invalid Owner Unit", Q6KV("OwnerUnitId", SkillUsedEvent->UnitId));
		End();
		return;
	}

	SetTimeOutLimit(OwnerUnit->GetTurnSkillAnimLength(), 0.1f, true);
	OwnerUnit->PlayTurnSkill();
}

void UCPTurnSkillInstance::EndInternal()
{
	if (HasMissingHitEvents() && bAllyOwner && TargetType != ETargetType::Self)
	{
		CombatPresenter->DropTurnPrepareUnits();
	}
}

void UCPTurnSkillInstance::EndPostProcessInternal()
{
	if (HasMissingHitEvents() && bAllyOwner && TargetType != ETargetType::Self)
	{
		CombatPresenter->RestoreTurnPrepareUnits();
	}
}

void UCPTurnSkillInstance::BindContentDelegate()
{
	Super::BindContentDelegate();

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimTurnSkillEndDelegate.BindUObject(this, &UCPTurnSkillInstance::End);
	}
}

void UCPTurnSkillInstance::UnbindContentDelegate()
{
	Super::UnbindContentDelegate();

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimTurnSkillEndDelegate.Unbind();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPRaidTurnSkillInstance

UCPRaidTurnSkillInstance::UCPRaidTurnSkillInstance()
{
}

void UCPRaidTurnSkillInstance::Start()
{
	Super::Start();

	bool bWaitCamera = false;
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend);
	}

	if (!bWaitCamera || !PlayerController->IsCombatCameraBlending())
	{
		GetCheckedCombatHUD(this)->OnRaidTurnSkillEffect(Event);
	}
}

void UCPRaidTurnSkillInstance::BindContentDelegate()
{
	Super::BindContentDelegate();

	GetCheckedCombatHUD(this)->OnRaidAssistStartAnimFinishedDelegate.BindUObject(this, &UCPRaidTurnSkillInstance::End);

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPRaidTurnSkillInstance::OnCameraBlendingFinished);
	}
}

void UCPRaidTurnSkillInstance::UnbindContentDelegate()
{
	Super::UnbindContentDelegate();

	GetCheckedCombatHUD(this)->OnRaidAssistStartAnimFinishedDelegate.Unbind();
}

void UCPRaidTurnSkillInstance::OnCameraBlendingFinished(bool bRestoring)
{
	GetCheckedCombatHUD(this)->OnRaidTurnSkillEffect(Event);
}

//////////////////////////////////////////////////////////////////////////////////
// UCPNormalSkillInstance

UCPNormalSkillInstance::UCPNormalSkillInstance()
	: bOwnerUnitMoveEnd(false)
{
}

bool UCPNormalSkillInstance::IsCompleteEnd() const
{
	return (bNoHit || bHitFinished) && bSequenceFinished && bOwnerUnitMoveEnd;
}

void UCPNormalSkillInstance::InitializeInternal()
{
	if (OwnerFaction != ECCFaction::Ally)
	{
		return;
	}

	if (SkillUsedEvent->SkillCategory == ESkillCategory::Normal)
	{
		const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillUsedEvent->SkillType);
		OwnerUnit->SetSkillNote(SkillRow.SkillNote);

		bDoubleSkillFollowing = SkillUsedEvent->AttackOrder >= CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT && !IsLastSkill();
		OwnerUnit->SetDoubleSkillFollowing(bDoubleSkillFollowing);
	}
}

void UCPNormalSkillInstance::StartInternal()
{
	if (SkillUsedEvent->SkillCategory == ESkillCategory::Double)
	{
		StartAction();
	}
	else
	{
		PrepareAction();
	}
}

void UCPNormalSkillInstance::StartActionInternal()
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (!OwnerUnit)
	{
		Q6JsonLogSunny(Error, "UCPNormalSkillInstance::StartActionInternal - Invalid Owner Unit", Q6KV("OwnerUnitId", SkillUsedEvent->UnitId));
		End();
		return;
	}

	AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Error, "UCPNormalSkillInstance::StartActionInternal - Invalid Target Unit", Q6KV("TargetUnitId", SkillUsedEvent->TargetUnitId));
		End();
		return;
	}

	if (OwnerFaction == ECCFaction::Enemy)
	{
		OwnerUnit->SetCCStateEffectsHidden(true);
	}

	FVector TargetLocation;
	if (_IsTargetTypeAll(TargetType))
	{
		TargetLocation = CombatPresenter->GetFactionAllTargetLocation(TargetUnit->GetOverrideFaction());
		TargetLocation.Z = OwnerUnit->GetActorLocation().Z;
	}
	else
	{
		TargetLocation = OwnerUnit->GetMoveTargetLocation(TargetUnit);
	}

	OwnerUnit->PlayNormalSkill(TargetLocation, SkillUsedEvent->SkillCategory == ESkillCategory::Double);
}

void UCPNormalSkillInstance::EndInternal()
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (OwnerUnit)
	{
		OwnerUnit->SetCCStateEffectsHidden(false);
	}
}

static void _GatherSkillSequenceActors(ACombatPresenter* InCombatPresenter, ETargetType InTargetType, AUnit* InOwnerUnit, AUnit* InTargetUnit,
	TArray<AActor*>& OutAllyUnitActors, TArray<AActor*>& OutEnemyUnitActors, TArray<AActor*>& OutOtherUnitActors)
{
	OutAllyUnitActors.Add(InOwnerUnit);

	if (!InCombatPresenter)
	{
		return;
	}

	switch (InTargetType)
	{
		case ETargetType::FriendlyAll:
		{
			InCombatPresenter->ForEachUnit([InOwnerUnit, &OutAllyUnitActors](AUnit& InUnit)
			{
				if (InUnit.GetOverrideFaction() == InOwnerUnit->GetOverrideFaction())
				{
					if (InUnit.IsDead())
					{
						return;
					}
					if (&InUnit == InOwnerUnit)
					{
						return;
					}
					OutAllyUnitActors.Add(&InUnit);
				}
			});
			break;
		}
		case ETargetType::HostileAll:
		{
			InCombatPresenter->ForEachUnit([InTargetUnit, &OutEnemyUnitActors](AUnit& InUnit)
			{
				if (InUnit.IsDead())
				{
					return;
				}
				if (InUnit.GetOverrideFaction() != InTargetUnit->GetOverrideFaction())
				{
					return;
				}
				OutEnemyUnitActors.Add(&InUnit);
			});
			break;
		}
		case ETargetType::HostileSingle:
		{
			OutEnemyUnitActors.Add(InTargetUnit);
			break;
		}
		default:
			break;
	}

	InCombatPresenter->ForEachUnit([&](AUnit& InUnit)
	{
		if (InUnit.IsDead())
		{
			return;
		}

		AUnit* InUnitPtr = &InUnit;
		if (OutAllyUnitActors.Contains(InUnitPtr) || OutEnemyUnitActors.Contains(InUnitPtr))
		{
			return;
		}

		OutOtherUnitActors.Add(InUnitPtr);
	});
}

void UCPNormalSkillInstance::OnPlayNormalSkillSequence(const FTransform& TargetTransform)
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (OwnerUnit)
	{
		OwnerUnit->SetCCStateEffectsHidden(true);
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
		AUnit* TargetSourceUnit = TargetUnit ? TargetUnit->GetSourceUnit() : nullptr;

		TArray<AActor*> AllyUnitActors;
		TArray<AActor*> EnemyUnitActors;
		TArray<AActor*> OtherUnitActors;
		_GatherSkillSequenceActors(CombatPresenter.Get(), TargetType, OwnerUnit, TargetSourceUnit, AllyUnitActors, EnemyUnitActors, OtherUnitActors);

		APetUnit* PetUnit = CombatPresenter->GetPetUnit();
		if (PetUnit)
		{
			OtherUnitActors.AddUnique(PetUnit);
		}

		PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NoBlend, false);
		PlayerController->PlayNormalSkillSequence(this, OwnerUnit, AllyUnitActors, EnemyUnitActors, OtherUnitActors, TargetTransform);
	}
	else
	{
		OnSequenceFinished();
	}
}

void UCPNormalSkillInstance::OnNormalSkillAnimFinished()
{
	if (bHasSkillDrivenEffect)
	{
		return;
	}

	if (bHasDeadUnit)
	{
		End();
	}
	else if (!IsLastSkill() && !HasMissingHitEvents())
	{
		OnInstanceState.ExecuteIfBound(ECPInstanceState::ProceedNext, this);
	}
}

void UCPNormalSkillInstance::OnOwnerUnitMoveEnd()
{
	bOwnerUnitMoveEnd = true;
}

void UCPNormalSkillInstance::BindContentDelegate()
{
	Super::BindContentDelegate();

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimSkillEndDelegate.BindUObject(this, &UCPNormalSkillInstance::OnNormalSkillAnimFinished);
		SourceUnit->AnimMoveEndDelegate.BindUObject(this, &UCPNormalSkillInstance::OnOwnerUnitMoveEnd);

		if (OwnerFaction == ECCFaction::Ally)
		{
			SourceUnit->NormalSkillSequencePlayDelegate.BindUObject(this, &UCPNormalSkillInstance::OnPlayNormalSkillSequence);
		}
		else
		{
			bSequenceFinished = true;
		}
	}
}

void UCPNormalSkillInstance::UnbindContentDelegate()
{
	Super::UnbindContentDelegate();

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimSkillEndDelegate.Unbind();
		SourceUnit->AnimMoveEndDelegate.Unbind();
		SourceUnit->NormalSkillSequencePlayDelegate.Unbind();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPUltimateSkillInstance

UCPUltimateSkillInstance::UCPUltimateSkillInstance()
	: bCameraPreActionFinished(false)
	, bHUDPreAnimFinished(false)
	, bShowSequence(false)
	, SkillPostEffect()
	, PostEffectStartTime(0.f)
	, PostHitStartTime(0.f)
	, LastPostHitTime(0.f)
	, bPostEffectFinished(false)
	, SkillPostMove()
	, PostMoveStartTime(0.f)
	, bPostMoveFinished(false)
{
}

bool UCPUltimateSkillInstance::IsCompleteEnd() const
{
	return (bNoHit || bHitFinished) && bSequenceFinished && bPostEffectFinished && bPostMoveFinished;
}

void UCPUltimateSkillInstance::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	float TimeNow = GetWorld()->GetTimeSeconds();

	UpdatePostEffect(TimeNow);
	UpdatePostMove(TimeNow);
}

void UCPUltimateSkillInstance::InitializeInternal()
{
	bHUDPreAnimFinished = OwnerFaction != ECCFaction::Ally;
}

void UCPUltimateSkillInstance::CreateAnimHitInfoInternal(TArray<FSkillAnimHitInfo>& InOutHitsPerEffect)
{	
	const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRow = OwnerUnit->GetUltimateSkillSequenceAssetRow(SkillUsedEvent->SkillType);

	SkillPostMove = UltimateSkillSequenceAssetRow.SkillPostMove;

	SkillPostEffect = UltimateSkillSequenceAssetRow.SkillPostEffect;
	int32 PostHitCount = SkillPostEffect.HitInfo.HitCount;
	if (!PostHitCount)
	{
		bPostEffectFinished = true;
		return;
	}

	if (!InOutHitsPerEffect.Num())
	{
		InOutHitsPerEffect.Add(FSkillAnimHitInfo());
	}
	FSkillAnimHitInfo& LastSkillAnimEffectInfo = InOutHitsPerEffect.Last();

	bool bPostEffectWeightValid = !FMath::IsNearlyEqual(SkillPostEffect.Weight, 1.f, KINDA_SMALL_NUMBER);
	if (bPostEffectWeightValid)
	{
		for (int32 i = 0; i < PostHitCount; ++i)
		{
			LastSkillAnimEffectInfo.bWeightValid = true;
			LastSkillAnimEffectInfo.HitValues.Add(SkillPostEffect.Weight / PostHitCount);
		}
	}
	else
	{
		float HitValue = 1.f; // assume 1 sec after last hit
		if (LastSkillAnimEffectInfo.HitValues.Num())
		{
			HitValue += LastSkillAnimEffectInfo.HitValues.Last(0);
		}

		float PostHitInterval = SkillPostEffect.HitInfo.HitInterval;

		for (int32 i = 0; i < PostHitCount; ++i)
		{
			LastSkillAnimEffectInfo.HitValues.Add(HitValue + PostHitInterval * i);
		}
	}
}

void UCPUltimateSkillInstance::StartActionInternal()
{
	bCameraPreActionFinished = true;
#if !UE_BUILD_SHIPPING
	UAutomationHelper* InAutomationHelper = CombatPresenter->GetAutomationHelper();
	if (InAutomationHelper && InAutomationHelper->IsStarted())
	{
		// Forcely, Run Ultimate Skill Sequence.
		StartSkillAction();
		return;
	}
#endif

	if (bHUDPreAnimFinished)
	{
		StartSkillAction();
	}
}

void UCPUltimateSkillInstance::OnSkillPreAnimFinished()
{
	bHUDPreAnimFinished = true;

#if !UE_BUILD_SHIPPING
	UAutomationHelper* InAutomationHelper = CombatPresenter->GetAutomationHelper();
	if (InAutomationHelper && InAutomationHelper->IsStarted())
	{
		StartSkillAction();
		return;
	}
#endif

	if (bCameraPreActionFinished)
	{
		StartSkillAction();
	}
}

void UCPUltimateSkillInstance::OnSkillAnimFinished()
{
	if (bShowSequence)
	{
		ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
		if (PlayerController)
		{
			PlayerController->ResumeSequencePlayer();
		}
	}
	else
	{
		OnSequenceFinished();
	}
}

void UCPUltimateSkillInstance::StartSkillAction()
{
	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	if (!OwnerUnit)
	{
		Q6JsonLogSunny(Error, "UCPUltimateSkillInstance::StartActionInternal - Invalid Owner Unit", Q6KV("OwnerUnitId", SkillUsedEvent->UnitId));
		End();
		return;
	}

	AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Error, "UCPUltimateSkillInstance::StartActionInternal - Invalid Target Unit", Q6KV("TargetUnitId", SkillUsedEvent->TargetUnitId));
		End();
		return;
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRow = OwnerUnit->GetUltimateSkillSequenceAssetRow(SkillUsedEvent->SkillType, false);
	if (!PlayerController || UltimateSkillSequenceAssetRow.SkillSequence.IsNull())
	{
		OnSequenceFinished();
		return;
	}

	if (UltimateSkillSequenceAssetRow.bNoSkip)
	{
		bShowSequence = true;
	}
	else
	{
		bShowSequence = UQ6GameInstance::Get(this)->ShowUltimateSequence(OwnerUnit->GetModelType(), OwnerUnit->IsEnemy());
	}

	if (bShowSequence)
	{
		SetTimeOutLimit(SEQUENCER_PLAY_TIMEOUT, 0.f, true);

		TArray<AActor*> AllyUnitActors;
		TArray<AActor*> EnemyUnitActors;
		TArray<AActor*> OtherUnitActors;

		AUnit* SourceUnit = OwnerUnit->GetSourceUnit();
		_GatherSkillSequenceActors(CombatPresenter.Get(), TargetType, SourceUnit, TargetUnit, AllyUnitActors, EnemyUnitActors, OtherUnitActors);

		APetUnit* PetUnit = CombatPresenter->GetPetUnit();
		if (PetUnit)
		{
			OtherUnitActors.AddUnique(PetUnit);
		}

		PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NoBlend, false);

		GetCheckedCombatHUD(this)->OnUltimateSkillSequenceStarted(UltimateSkillSequenceAssetRow.bNoSkip);
		GetSoundPlayer().PlaySkillBGM(UltimateSkillSequenceAssetRow.SkillBGM);
		PlayerController->PlayUltimateSkillSequence(this, UltimateSkillSequenceAssetRow.SkillSequence, SourceUnit, AllyUnitActors, EnemyUnitActors, OtherUnitActors);
	}
	else
	{
		PlayerController->PlaySkillAnimation();
	}
}

void UCPUltimateSkillInstance::OnSequenceFinished()
{
	Super::OnSequenceFinished();

	PostEffectStartTime = GetWorld()->GetTimeSeconds();

	GetSoundPlayer().StopSkillBGM();
	GetCheckedCombatHUD(this)->OnUltimateSkillSequenceFinished();

	bool bNeedFullView = OwnerFaction == ECCFaction::Ally && TargetType == ETargetType::FriendlyAll;
	if (bNeedFullView)
	{
		ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
		if (PlayerController)
		{
			PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NoBlend);
		}
	}

	if (!SkillPostMove.bMoveToTarget || !bShowSequence)
	{
		bPostMoveFinished = true;
	}
	else
	{
		OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
		ensure(OwnerUnit);

		AUnit* SourceUnit = OwnerUnit->GetSourceUnit();
		ensure(SourceUnit);

		AUnit* TargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
		ensure(TargetUnit);

		FVector TargetLocation;
		if (_IsTargetTypeAll(TargetType))
		{
			TargetLocation = CombatPresenter->GetFactionAllTargetLocation(TargetUnit->GetOverrideFaction());
			TargetLocation.Z = SourceUnit->GetActorLocation().Z;
		}
		else
		{
			TargetLocation = SourceUnit->GetMoveTargetLocation(TargetUnit);
		}

		SourceUnit->SetActorLocation(TargetLocation);
	}
}

void UCPUltimateSkillInstance::SpawnPostExtraEffect()
{
	AUnit* SkillTargetUnit = CombatPresenter->FindUnit(SkillUsedEvent->TargetUnitId);
	if (!SkillTargetUnit)
	{
		return;
	}

	TArray<AUnit*> ShowHitAnimUnits;

	if (_IsTargetTypeAll(TargetType))
	{
		ECCFaction TargetFaction = SkillTargetUnit->GetOverrideFaction();

		ShowHitAnimUnits = CombatPresenter->FindUnitsByFaction(TargetFaction);

		FVector SpawnLocation = CombatPresenter->GetFactionAllTargetLocation(TargetFaction);
		CombatPresenter->SpawnWorldParticle(SpawnLocation, SkillPostEffect.ExtraEffect.ExtraParticleParams, SkillPostEffect.ExtraEffect.ExtraSoundParams);

		RegisterSpawnMeshParam(nullptr, SkillPostEffect.ExtraEffect.ExtraMeshDesc, -1.0f, SpawnLocation);
	}
	else
	{
		ShowHitAnimUnits.Add(SkillTargetUnit);
		SkillTargetUnit->StartParticleEffects(SkillPostEffect.ExtraEffect.ExtraParticleParams, SkillPostEffect.ExtraEffect.ExtraSoundParams);

		RegisterSpawnMeshParam(SkillTargetUnit, SkillPostEffect.ExtraEffect.ExtraMeshDesc);
	}

	if (SkillPostEffect.ExtraEffect.bShowHitAnim)
	{
		for (AUnit* Unit : ShowHitAnimUnits)
		{
			if (!Unit->IsDead())
			{
				Unit->SetHit(SkillPostEffect.HitParticleParam.GetRandomizedParams(), SkillPostEffect.HitSoundParams);
				RegisterSpawnMeshParam(Unit, SkillPostEffect.HitMeshDesc);
			}
		}
	}
}

void UCPUltimateSkillInstance::OnOwnerUnitReadyToMove()
{
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimUnrelaxedDelegate.Unbind();
		SourceUnit->SetUltimateSkillState(SkillPostMove.bMoveToTarget);
	}

	if (!SkillPostMove.bMoveToTarget)
	{
		bPostMoveFinished = true;
		return;
	}

	PostMoveStartTime = GetWorld()->GetTimeSeconds();
}

void UCPUltimateSkillInstance::StartOwnerUnitPostMove()
{
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->SetMoving(true);
	}
	bPostMoveFinished = true;
}

void UCPUltimateSkillInstance::UpdatePostEffect(float TimeNow)
{
	if (bPostEffectFinished)
	{
		return;
	}

	if (PostEffectStartTime <= 0)
	{
		return;
	}

	if (TimeNow - PostEffectStartTime < SkillPostEffect.ExtraEffect.PreDelay)
	{
		return;
	}

	if (PostHitStartTime <= 0)
	{
		if (SkillPostEffect.bUseExtraEffect)
		{
			SpawnPostExtraEffect();
		}
		PostHitStartTime = TimeNow;
		return;
	}

	if (SkillPostEffect.HitInfo.HitCount <= 0)
	{
		if (SkillPostMove.bMoveToTarget && !bPostMoveFinished)
		{
			StartOwnerUnitPostMove();
		}

		if (TimeNow - LastPostHitTime < SkillPostEffect.HitInfo.PostDelay)
		{
			return;
		}

		bPostEffectFinished = true;
		return;
	}

	if (TimeNow - PostHitStartTime < SkillPostEffect.HitInfo.PreDelay)
	{
		return;
	}

	// clear sequencer driven enemy visual controls on first post hit
	if (LastPostHitTime <= 0)
	{
		ECCFaction TargetFaction = OwnerFaction == ECCFaction::Ally ? ECCFaction::Enemy : ECCFaction::Ally;
		TArray<AUnit*> TargetFactionUnits = CombatPresenter->FindUnitsByFaction(TargetFaction);
		for (AUnit* TargetFactionUnit : TargetFactionUnits)
		{
			TargetFactionUnit->SetAnimPaused(false);
			TargetFactionUnit->ClearSubMaterialEffect();
		}
	}

	if (LastPostHitTime <= 0 || SkillPostEffect.HitInfo.HitInterval <= TimeNow - LastPostHitTime)
	{
		OnHitPost(SkillPostEffect.HitParticleParam.GetRandomizedParams(), SkillPostEffect.HitSoundParams, SkillPostEffect.HitMeshDesc, SkillPostEffect.bUsePostHitRandomStart);

		LastPostHitTime = TimeNow;
		--SkillPostEffect.HitInfo.HitCount;
	}
}

void UCPUltimateSkillInstance::UpdatePostMove(float TimeNow)
{
	if (bPostMoveFinished)
	{
		return;
	}

	if (PostMoveStartTime <= 0)
	{
		return;
	}

	if (TimeNow - PostMoveStartTime < SkillPostMove.MoveBackPreDelay)
	{
		return;
	}

	StartOwnerUnitPostMove();
}

void UCPUltimateSkillInstance::EndInternal()
{
	if (OwnerUnit && OwnerUnit->IsEnemy())
	{
		const FUnitState& UnitState = OwnerUnit->GetUnitState();

		do 
		{
			if (!OwnerUnit->ShiftUltimateSkillStats())
			{
				break;
			}
		} while (UnitState.Ultimates[0].bPattern);
	}

	GetCheckedCombatHUD(this)->ShowUltimateSkipWidget(false);
}

void UCPUltimateSkillInstance::BindContentDelegate()
{
	Super::BindContentDelegate();

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	CombatHUD->OnSkillPreAnimFinishedDelegate.BindUObject(this, &UCPUltimateSkillInstance::OnSkillPreAnimFinished);
	CombatHUD->OnSkillAnimFinishedDelegate.BindUObject(this, &UCPUltimateSkillInstance::OnSkillAnimFinished);

	OwnerUnit = CombatPresenter->FindUnit(SkillUsedEvent->UnitId);
	AUnit* SourceUnit = OwnerUnit ? OwnerUnit->GetSourceUnit() : nullptr;
	if (SourceUnit)
	{
		SourceUnit->AnimUnrelaxedDelegate.BindUObject(this, &UCPUltimateSkillInstance::OnOwnerUnitReadyToMove);
	}
}

void UCPUltimateSkillInstance::UnbindContentDelegate()
{
	Super::UnbindContentDelegate();

	GetCheckedCombatHUD(this)->OnSkillPreAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPUnitApplyEffectLabelInstance

UCPUnitApplyEffectLabelInstance::UCPUnitApplyEffectLabelInstance()
	: bSingleCamera(false)
{
}

void UCPUnitApplyEffectLabelInstance::AddLabelInfo(EMoment InMoment, FCCUnitId InUnitId)
{
	for (FCPMomentLabelInfo& MomentLabelInfo : MomentLabelInfos)
	{
		if (MomentLabelInfo.Moment == InMoment)
		{
			MomentLabelInfo.UnitIds.AddUnique(InUnitId);
			return;
		}
	}

	FCPMomentLabelInfo& MomentLabelInfo = MomentLabelInfos.AddDefaulted_GetRef();
	MomentLabelInfo.Moment = InMoment;
	MomentLabelInfo.UnitIds.AddUnique(InUnitId);
}

bool UCPUnitApplyEffectLabelInstance::IsSingleTargetCamera(FCCUnitId& OutTargetUnitId)
{
	for (FCPMomentLabelInfo& MomentLabelInfo : MomentLabelInfos)
	{
		if (MomentLabelInfo.Moment == EMoment::PostDie)
		{
			if (MomentLabelInfo.UnitIds.Num() != 1)
			{
				return false;
			}

			OutTargetUnitId = MomentLabelInfo.UnitIds[0];
			break;
		}
	}

	for (FCPMomentLabelInfo& MomentLabelInfo : MomentLabelInfos)
	{
		if (MomentLabelInfo.UnitIds.Num() != 1)
		{
			return false;
		}
		else if (MomentLabelInfo.UnitIds[0] != OutTargetUnitId)
		{
			return false;
		}
	}

	return true;
}

void UCPUnitApplyEffectLabelInstance::Start()
{
	Super::Start();

	if (!MomentLabelInfos.Num())
	{
		End();
		return;
	}

	bool bWaitCamera = false;

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		if (bSingleCamera)
		{
			FCCUnitId TargetUnitId = MomentLabelInfos[0].UnitIds[0];
			AUnit* TargetUnit = CombatPresenter->FindUnit(TargetUnitId);
			if (TargetUnit)
			{
				if (TargetUnit->GetOverrideFaction() == ECCFaction::Ally)
				{
					bWaitCamera = PlayerController->ChangeToAllyCamera(TargetUnit->GetSlot());
				}
				else
				{
					bWaitCamera = PlayerController->ChangeToEnemyCamera(TargetUnit->GetSlot(), CombatPresenter->GetWaveEnemyNumSlots(), CombatPresenter->IsWaveEnemyDefaultPosition());
				}
			}
		}
		else
		{
			bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend, false);
		}
	}

	if (!bWaitCamera)
	{
		OnCameraBlendingFinished(false);
	}
}

void UCPUnitApplyEffectLabelInstance::OnCameraBlendingFinished(bool bRestoring)
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	for (FCPMomentLabelInfo& MomentLabelInfo : MomentLabelInfos)
	{
		for (FCCUnitId UnitId : MomentLabelInfo.UnitIds)
		{
			CombatHUD->PlayUnitApplyMomentEffect(UnitId, MomentLabelInfo.Moment);
		}
	}

	End();
}

void UCPUnitApplyEffectLabelInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPUnitApplyEffectLabelInstance::OnCameraBlendingFinished);
	}
}

void UCPUnitApplyEffectLabelInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPUnitNoticeInstance

UCPUnitNoticeInstance::UCPUnitNoticeInstance()
	: SourceUnitId(CCUnitIdInvalid)
	, bSkipCamera(false)
	, bSkipAction(false)
{
}

bool UCPUnitNoticeInstance::Initialize()
{
	int32 TargetUnitCount = TargetUnitIds.Num();
	if (!TargetUnitCount)
	{
		return false;
	}

	if (TargetUnitCount == 1)
	{
		bool bMasterSource = CombatPresenter->IsMaster(SourceUnitId);
		bool bSelfTarget = SourceUnitId == TargetUnitIds[0];
		bSkipCamera |= bMasterSource || bSelfTarget;
	}

	if (IsAnyAttackPhase(CombatPresenter->GetTurnPhase()))
	{
		bool bNextSkillFollowing = CombatPresenter->HasEventQueued(ECCEventType::SkillUsed, ECCEventType::StartPhase);
		bool bNextPhaseFollowing = CombatPresenter->HasEventQueued(ECCEventType::StartPhase, ECCEventType::Invalid);

		bResetCamera = !bNextSkillFollowing && !bNextPhaseFollowing;
	}
	else
	{
		bResetCamera = !bSkipCamera;
	}

	return true;
}

bool UCPUnitNoticeInstance::Prepare()
{
	if (!Initialize())
	{
		return false;
	}

	return Super::Prepare();
}

void UCPUnitNoticeInstance::Start()
{
	Super::Start();

	if (bSkipCamera)
	{
		StartAction();
		return;
	}

	if (CombatPresenter->GetTurnPhase() == ECCTurnPhase::TurnSkill)
	{
		CombatPresenter->DropTurnPrepareUnits();
	}

	bool bWaitCamera = false;

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend, false);
	}

	if (!bWaitCamera)
	{
		StartAction();
	}
}

void UCPUnitNoticeInstance::End()
{
	if (bSkipAction)
	{
		Super::End();
		return;
	}

	bool bIsInTurnSkillPhase = false;

	ECPTurnPhase CPTurnPhase = CombatPresenter->CCPhaseToCPPhase(CombatPresenter->GetTurnPhase());
	switch (CPTurnPhase)
	{
		case ECPTurnPhase::TurnSkill:
			bIsInTurnSkillPhase = true;
			// fall through
		case ECPTurnPhase::Steady:
		case ECPTurnPhase::Attack:
			CombatPresenter->SetDecalVisible(true);
			break;
		default:
			break;
	}

	if (bResetCamera)
	{
		if (bIsInTurnSkillPhase)
		{
			CombatPresenter->RestoreTurnPrepareUnits();
		}

		ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
		if (PlayerController)
		{
			bool bIsInAnyAttackPhase = IsAnyAttackPhase(CombatPresenter->GetTurnPhase());
			if (bSkipCamera && bIsInAnyAttackPhase)
			{
				PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend);
			}
			else if (bIsInTurnSkillPhase)
			{
				PlayerController->RestoreSavedCamera(ECombatCameraBlendType::NoBlend);
			}
		}
	}

	Super::End();
}

void UCPUnitNoticeInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPUnitNoticeInstance::OnCameraBlendingFinished);
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnUnitNoticeAnimFinishedDelegate.BindUObject(this, &UCPUnitNoticeInstance::OnUnitNoticeAnimFinished);
}

void UCPUnitNoticeInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnUnitNoticeAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPPointInstance

void UCPPointInstance::AddHealthEvent(const UCCUnitHealthChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	PointEvents.AddHealthEvent(InEvent);
}

void UCPPointInstance::AddUAEvent(const UCCUnitUAChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	PointEvents.AddUAEvent(InEvent);
}

void UCPPointInstance::AddSAEvent(const UCCUnitSAChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	PointEvents.AddSAEvent(InEvent);
}

void UCPPointInstance::AddOverKillEvent(const UCCUnitOverKillChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	PointEvents.AddOverKillEvent(InEvent);
}

void UCPPointInstance::StartAction()
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	static_assert(EPointVaryConsumeTypeMax == 4, "need more consume type.");

	for (const UCCUnitHealthChangedEvent* HealthEvent : PointEvents.HealthEvents)
	{
		if (HealthEvent->Reason == EHealthChangeReason::ImmediateKill)
		{
			CombatHUD->OnImmediateKill(HealthEvent->UnitId);
		}
		else
		{
			CombatHUD->OnPointChanged(HealthEvent->UnitId, EPointVaryConsumeType::Health, HealthEvent->AddedHealth);
		}
		CombatHUD->OnHealthChanged(HealthEvent);
	}

	for (const UCCUnitUAChangedEvent* UAEvent : PointEvents.UAEvents)
	{
		CombatHUD->OnPointChanged(UAEvent->UnitId, EPointVaryConsumeType::UA, UAEvent->AddedUA);
		CombatHUD->OnUAChanged(UAEvent);
	}

	for (const UCCUnitSAChangedEvent* SAEvent : PointEvents.SAEvents)
	{
		CombatHUD->OnPointChanged(SAEvent->UnitId, EPointVaryConsumeType::SA, SAEvent->AddedSA);
		CombatHUD->OnSAChanged(SAEvent);
	}

	for (const UCCUnitOverKillChangedEvent* OverKillEvent : PointEvents.OverKillEvents)
	{
		CombatHUD->OnPointChanged(OverKillEvent->UnitId, EPointVaryConsumeType::OverKillPoint, OverKillEvent->AddedOverKill);
		CombatHUD->OnOverKillChanged(OverKillEvent);
	}

	if (bSkipAction)
	{
		End();
	}
}

void UCPPointInstance::OnCameraBlendingFinished(bool bRestoring)
{
	StartAction();
}

void UCPPointInstance::OnUnitNoticeAnimFinished()
{
	End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPPointVaryInstance

UCPPointVaryInstance::UCPPointVaryInstance()
	: EventState(EPointVaryState::Consume)
	, ActionState(EPointVaryState::Consume)
{
}

void UCPPointVaryInstance::AddUpdateAttributesEvent(const UCCUpdateAttributesEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	GetCurEvents().AddUpdateAttributesEvent(InEvent);
}

void UCPPointVaryInstance::AddHealthEvent(const UCCUnitHealthChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	GetCurEvents().AddHealthEvent(InEvent);
}

void UCPPointVaryInstance::AddUAEvent(const UCCUnitUAChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	GetCurEvents().AddUAEvent(InEvent);
}

void UCPPointVaryInstance::AddSAEvent(const UCCUnitSAChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	GetCurEvents().AddSAEvent(InEvent);
}

void UCPPointVaryInstance::AddOverKillEvent(const UCCUnitOverKillChangedEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	GetCurEvents().AddOverKillEvent(InEvent);
}

void UCPPointVaryInstance::StartAction()
{
	switch (ActionState)
	{
		case EPointVaryState::Consume:
			StartConsumeAction();
			break;
		case EPointVaryState::Convert:
			StartConvertAction();
			break;
		default:
			break;
	}
}

void UCPPointVaryInstance::StartConsumeAction()
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	static_assert(EPointVaryConsumeTypeMax == 4, "need more consume type.");

	switch (PointVaryUsedEvent->ConsumeType)
	{
		case EPointVaryConsumeType::Health:
			for (const UCCUnitHealthChangedEvent* HealthEvent : ConsumeEvents.HealthEvents)
			{
				CombatHUD->OnPointVaryConsume(HealthEvent->UnitId, EPointVaryConsumeType::Health, HealthEvent->AddedHealth);
				CombatHUD->OnHealthChanged(HealthEvent);
			}
			break;
		case EPointVaryConsumeType::UA:
			for (const UCCUnitUAChangedEvent* UAEvent : ConsumeEvents.UAEvents)
			{
				CombatHUD->OnPointVaryConsume(UAEvent->UnitId, EPointVaryConsumeType::UA, UAEvent->AddedUA);
				CombatHUD->OnUAChanged(UAEvent);
			}
			break;
		case EPointVaryConsumeType::SA:
			for (const UCCUnitSAChangedEvent* SAEvent : ConsumeEvents.SAEvents)
			{
				CombatHUD->OnPointVaryConsume(SAEvent->UnitId, EPointVaryConsumeType::SA, SAEvent->AddedSA);
				CombatHUD->OnSAChanged(SAEvent);
			}
			break;
		case EPointVaryConsumeType::OverKillPoint:
			for (const UCCUnitOverKillChangedEvent* OverKillEvent : ConsumeEvents.OverKillEvents)
			{
				CombatHUD->OnPointVaryConsume(OverKillEvent->UnitId, EPointVaryConsumeType::OverKillPoint, OverKillEvent->AddedOverKill);
				CombatHUD->OnOverKillChanged(OverKillEvent);
			}
			break;
		default:
			break;
	}
}

void UCPPointVaryInstance::StartConvertAction()
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	static_assert(EPointVaryConvertTypeMax == 16, "need more convert type.");

	switch (PointVaryUsedEvent->ConvertType)
	{
		case EPointVaryConvertType::Health:
			for (const UCCUnitHealthChangedEvent* HealthEvent : ConvertEvents.HealthEvents)
			{
				CombatHUD->OnPointVaryConvert(HealthEvent->UnitId, PointVaryUsedEvent->ConvertType, HealthEvent->AddedHealth);
				CombatHUD->OnHealthChanged(HealthEvent);
			}
			break;
		case EPointVaryConvertType::UA:
			for (const UCCUnitUAChangedEvent* UAEvent : ConvertEvents.UAEvents)
			{
				CombatHUD->OnPointVaryConvert(UAEvent->UnitId, PointVaryUsedEvent->ConvertType, UAEvent->AddedUA);
				CombatHUD->OnUAChanged(UAEvent);
			}
			break;
		case EPointVaryConvertType::SA:
			for (const UCCUnitSAChangedEvent* SAEvent : ConvertEvents.SAEvents)
			{
				CombatHUD->OnPointVaryConvert(SAEvent->UnitId, PointVaryUsedEvent->ConvertType, SAEvent->AddedSA);
				CombatHUD->OnSAChanged(SAEvent);
			}
			break;
		case EPointVaryConvertType::OverKillPoint:
			for (const UCCUnitOverKillChangedEvent* OverKillEvent : ConvertEvents.OverKillEvents)
			{
				CombatHUD->OnPointVaryConvert(OverKillEvent->UnitId, PointVaryUsedEvent->ConvertType, OverKillEvent->AddedOverKill);
				CombatHUD->OnOverKillChanged(OverKillEvent);
			}
			break;
		case EPointVaryConvertType::AtkVary:
		case EPointVaryConvertType::AtkVaryper:
		case EPointVaryConvertType::DefVary:
		case EPointVaryConvertType::DefVaryper:
		case EPointVaryConvertType::CriVaryper:
		case EPointVaryConvertType::CriDamVaryper:
		case EPointVaryConvertType::UltimateVary:
		case EPointVaryConvertType::UltimateVaryper:
		case EPointVaryConvertType::DamageVary:
		case EPointVaryConvertType::DamageVaryper:
		case EPointVaryConvertType::HealVary:
		case EPointVaryConvertType::HealVaryper:
			for (const UCCUpdateAttributesEvent* UpdateAttributesEvent : ConvertEvents.UpdateAttributesEvents)
			{
				AUnit* TargetUnit = CombatPresenter->FindUnit(UpdateAttributesEvent->UnitId);
				if (TargetUnit)
				{
					TargetUnit->AddPointVaryUnitAttribute(PointVaryUsedEvent->ConvertType, UpdateAttributesEvent->AddedValue);
				}

				CombatHUD->OnPointVaryConvert(UpdateAttributesEvent->UnitId, PointVaryUsedEvent->ConvertType, UpdateAttributesEvent->AddedValue);
			}
			break;
		default:
			break;
	}

	if (bSkipAction)
	{
		End();
	}
}

void UCPPointVaryInstance::OnCameraBlendingFinished(bool bRestoring)
{
	if (ActionState == EPointVaryState::Consume)
	{
		StartAction();
	}
}

void UCPPointVaryInstance::OnUnitNoticeAnimFinished()
{
	switch (ActionState)
	{
		case EPointVaryState::Consume:
			ActionState = EPointVaryState::Convert;
			StartAction();
			break;
		case EPointVaryState::Convert:
			End();
			break;
		default:
			break;
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPBuffInstance
// Buff effect creation

UCPBuffInstance::UCPBuffInstance()
	: bSkipUnitNotices(false)
	, bSkipUnitBar(false)
	, bFromSkill(false)
{
}

static void _ValidateTarget(FCCUnitId InTargetId, TArray<FCCUnitId>& InOutTargetIds)
{
	if (InTargetId == CCUnitIdInvalid)
	{
		return;
	}

	InOutTargetIds.AddUnique(InTargetId);
}

void UCPBuffInstance::AddBuffEvent(const UCCEvent* InEvent)
{
	if (InEvent->GetEventType() == ECCEventType::CreateBuff)
	{
		const UCCCreateBuffEvent* CreateBuffEvent = CastChecked<UCCCreateBuffEvent>(InEvent);
		_ValidateTarget(CreateBuffEvent->TargetUnitId, TargetUnitIds);
	}
	else if (InEvent->GetEventType() == ECCEventType::RemoveBuff)
	{
		const UCCRemoveBuffEvent* RemoveBuffEvent = CastChecked<UCCRemoveBuffEvent>(InEvent);
		for (const FCCUnitId& UnitId : RemoveBuffEvent->UnitIds)
		{
			_ValidateTarget(UnitId, TargetUnitIds);
		}
	}
	else if (InEvent->GetEventType() == ECCEventType::RemoveBuffFailed)
	{
		const UCCRemoveBuffFailedEvent* RemoveBuffFailedEvent = CastChecked<UCCRemoveBuffFailedEvent>(InEvent);
		_ValidateTarget(RemoveBuffFailedEvent->UnitId, TargetUnitIds);
	}
	else if (InEvent->GetEventType() == ECCEventType::ImmuneBuff)
	{
		const UCCImmuneBuffEvent* ImmuneBuffEvent = CastChecked<UCCImmuneBuffEvent>(InEvent);
		_ValidateTarget(ImmuneBuffEvent->UnitId, TargetUnitIds);
	}

	BuffEvents.Add(InEvent);
}

void UCPBuffInstance::SetSkipEffectFromSkill(ESkillCategory InSkillCategory)
{
	bFromSkill = true;

	switch (InSkillCategory)
	{
		case ESkillCategory::Chain:
		case ESkillCategory::Support:
			SetSkipEffect(true, true, false);
			break;
		default:
			break;
	}
}

void UCPBuffInstance::SetSkipEffect(bool bInSkipCamera, bool bInSkipUnitNotices, bool bInSkipUnitBar)
{
	bSkipCamera |= bInSkipCamera;
	bSkipUnitNotices |= bInSkipUnitNotices;
	bSkipUnitBar |= bInSkipUnitBar;
}

void UCPBuffInstance::StartAction()
{
	bool bAnyUnitNotice = false;
	TMap<FCCUnitId, TArray<int32>> NoticedBuffTypes;

	for (const UCCEvent* Event : BuffEvents)
	{
		if (Event->GetEventType() == ECCEventType::CreateBuff)
		{
			const UCCCreateBuffEvent* CreateBuffEvent = CastChecked<UCCCreateBuffEvent>(Event);

			bool bEventNoticed = NoticedBuffTypes.Find(CreateBuffEvent->TargetUnitId) && NoticedBuffTypes[CreateBuffEvent->TargetUnitId].Contains(CreateBuffEvent->BuffType);
			bool bSkipUnitNotice = bSkipUnitNotices || bEventNoticed;

			AUnit* TargetUnit = CombatPresenter->FindUnit(CreateBuffEvent->TargetUnitId);
			if (TargetUnit)
			{
				if (CreateBuffEvent->Shield)
				{
					TargetUnit->SetMaxShield(CreateBuffEvent->Shield);
				}

				FBuffState BuffState(CreateBuffEvent->BuffId, CreateBuffEvent->BuffType, CreateBuffEvent->BuffLevel, CreateBuffEvent->Duration, CreateBuffEvent->HitCount,
									CreateBuffEvent->Multiple, CreateBuffEvent->BornCategory, CreateBuffEvent->SourceUnitId);
				if (CreateBuffEvent->IsNew)
				{
					TargetUnit->AddBuff(BuffState);
				}
				else
				{
					TargetUnit->UpdateBuff(BuffState);
				}

				if (!bSkipUnitNotices)
				{
					TargetUnit->StartBuffEffectFX(FBuffType(CreateBuffEvent->BuffType));
				}

				bSkipUnitNotice |= TargetUnit->IsDead();

				ENatureType NewNatureType = GetCMS()->GetChangeNatureTypeFromBuff(FBuffType(CreateBuffEvent->BuffType));
				if (NewNatureType != ENatureType::None)
				{
					TargetUnit->SetNature(NewNatureType);
				}
			}

			bAnyUnitNotice |= !bSkipUnitNotice;
			GetCheckedCombatHUD(this)->OnCreateBuff(CreateBuffEvent, bSkipUnitNotice, bSkipUnitBar);

			NoticedBuffTypes.FindOrAdd(CreateBuffEvent->TargetUnitId).AddUnique(CreateBuffEvent->BuffType);
		}
		else if (Event->GetEventType() == ECCEventType::ImmuneBuff)
		{
			const UCCImmuneBuffEvent* ImmuneBuffEvent = CastChecked<UCCImmuneBuffEvent>(Event);

			bAnyUnitNotice |= !bSkipUnitNotices;
			GetCheckedCombatHUD(this)->OnImmuneBuff(ImmuneBuffEvent, bSkipUnitNotices);
		}
		else if (Event->GetEventType() == ECCEventType::RemoveBuff)
		{
			const UCCRemoveBuffEvent* RemoveBuffEvent = CastChecked<UCCRemoveBuffEvent>(Event);
			check(RemoveBuffEvent->UnitIds.Num() == RemoveBuffEvent->BuffIds.Num());

			bool bSkipUnitNotice = bSkipUnitNotices || RemoveBuffEvent->Reason != ERemoveBuffReason::RemoveSkill;
			FBuffType TargetBuffType = BuffTypeInvalid;

			const int32 NumOfUnitIds = RemoveBuffEvent->UnitIds.Num();
			for (int32 i = 0; i < NumOfUnitIds; ++i)
			{
				AUnit* TargetUnit = CombatPresenter->FindUnit(RemoveBuffEvent->UnitIds[i]);
				if (TargetUnit)
				{
					if (RemoveBuffEvent->Reason == ERemoveBuffReason::Shield)
					{
						TargetUnit->SetMaxShield(0);
					}

					TargetBuffType = TargetUnit->GetBuffType(RemoveBuffEvent->BuffIds[i]);
					TargetUnit->StopBuffEffectFX(TargetBuffType);
					TargetUnit->RemoveBuff(RemoveBuffEvent->BuffIds[i]);

					const UCMS* CMS = GetCMS();
					const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(TargetUnit->GetUnitType());
					if (CMS->GetChangeNatureTypeFromBuff(TargetBuffType) != ENatureType::None)
					{
						TargetUnit->SetNature(UnitRow.NatureType);
					}
				}

				bAnyUnitNotice |= !bSkipUnitNotice;
			}

			GetCheckedCombatHUD(this)->OnRemoveBuff(RemoveBuffEvent, TargetBuffType, bSkipUnitNotice);
		}
		else if (Event->GetEventType() == ECCEventType::RemoveBuffFailed)
		{
			const UCCRemoveBuffFailedEvent* RemoveBuffFailedEvent = CastChecked<UCCRemoveBuffFailedEvent>(Event);

			bAnyUnitNotice |= !bSkipUnitNotices;
			GetCheckedCombatHUD(this)->OnRemoveBuffFailed(RemoveBuffFailedEvent, bSkipUnitNotices);
		}
	}

	if (!bAnyUnitNotice || bSkipAction)
	{
		End();
	}
}

void UCPBuffInstance::OnCameraBlendingFinished(bool bRestoring)
{
	if (!bRestoring)
	{
		StartAction();
	}
}

void UCPBuffInstance::OnUnitNoticeAnimFinished()
{
	End();
}

//////////////////////////////////////////////////////////////////////////
// UCPSetSkillTimeInstance
//////////////////////////////////////////////////////////////////////////

void UCPSetSkillTimeInstance::AddSetSkillTimeEvent(const UCCSetSkillTimeEvent* InEvent)
{
	TargetUnitIds.AddUnique(InEvent->UnitId);
	SetSkillTimeEvents.Add(InEvent);
}

void UCPSetSkillTimeInstance::StartAction()
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	for (const UCCSetSkillTimeEvent* SetSkillTimeEvent : SetSkillTimeEvents)
	{
		CombatHUD->OnSkillTimeChanged(SetSkillTimeEvent->UnitId, SetSkillTimeEvent->SetSkillTimeType, SetSkillTimeEvent->TimeDiff);
	}
}

void UCPSetSkillTimeInstance::OnCameraBlendingFinished(bool bRestoring)
{
	StartAction();
}

void UCPSetSkillTimeInstance::OnUnitNoticeAnimFinished()
{
	End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPDamageBuffInstance
// Damage effect by buff

void UCPDamageBuffInstance::SetCCEvent(const UCCDamageBuffEvent* InEvent)
{
	DamageBuffEvent = InEvent;

	const TArray<UCCDamageBuffPerUnit*>& Infos = DamageBuffEvent->GetEvents();
	DamageInfos.Append(Infos);
}

void UCPDamageBuffInstance::Start()
{
	Super::Start();

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->ResetTotalDamage();
	CombatHUD->ResetUnitNoticeCaches();

	bool bWaitCamera = false;

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::NormalBlend, false);
	}

	if (!bWaitCamera)
	{
		StartAction();
	}
}

void UCPDamageBuffInstance::OnCameraBlendingFinished(bool bRestoring)
{
	StartAction();
}

void UCPDamageBuffInstance::StartAction()
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	TArray<FCCUnitId> NoticedUnitId;

	int32 Index = 0;
	while (DamageInfos.IsValidIndex(Index))
	{
		const UCCDamageBuffPerUnit* Info = DamageInfos[Index];
		if (NoticedUnitId.Contains(Info->TargetUnitId))
		{
			++Index;
			continue;
		}

		AUnit* TargetUnit = CombatPresenter->FindUnit(Info->TargetUnitId);
		if (!TargetUnit)
		{
			Q6JsonLogSunny(Error, "UCPDamageBuffInstance::StartAction - Invalid Target Unit", Q6KV("TargetUnitId", Info->TargetUnitId));
			++Index;
			continue;
		}

		TargetUnit->SetHealth(Info->NewHealth);
		TargetUnit->StartBuffEffectFX(FBuffEffectType(Info->BuffEffectType));

		UUnitHit* HitInfo = NewObject<UUnitHit>();
		HitInfo->SetInfo(Info->NatureRelationType, CCUnitIdInvalid, Info->TargetUnitId,
			-Info->BaseDamage, 0, -Info->ShieldDamage, 0, false,
			0, EHealthChangeReason::Damage, 0, 1, false, Info->bDodged);

		CombatHUD->OnDamageBuffHit(Info);
		CombatHUD->OnHit(HitInfo, false, false);

		NoticedUnitId.AddUnique(Info->TargetUnitId);
		DamageInfos.RemoveAt(Index);
	}

	if (!DamageInfos.Num())
	{
		CombatHUD->OnUnitNoticeAnimFinishedDelegate.BindUObject(this, &UCPDamageBuffInstance::End);
	}
}

void UCPDamageBuffInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPDamageBuffInstance::OnCameraBlendingFinished);
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnUnitNoticeAnimStartDelegate.BindUObject(this, &UCPDamageBuffInstance::StartAction);
}

void UCPDamageBuffInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnUnitNoticeAnimStartDelegate.Unbind();
	CombatHUD->OnUnitNoticeAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPHealBuffInstance
// Heal effect by buff

void UCPHealBuffInstance::SetCCEvent(const UCCHealBuffEvent* InEvent)
{
	HealBuffEvent = InEvent;

	const TArray<UCCHealBuffPerUnit*>& Infos = HealBuffEvent->GetEvents();
	HealInfos.Append(Infos);
}

void UCPHealBuffInstance::StartAction()
{
	TArray<FCCUnitId> NoticedUnitId;

	int32 Index = 0;
	while (HealInfos.IsValidIndex(Index))
	{
		const UCCHealBuffPerUnit* Info = HealInfos[Index];
		if (NoticedUnitId.Contains(Info->TargetUnitId))
		{
			++Index;
			continue;
		}

		AUnit* TargetUnit = CombatPresenter->FindUnit(Info->TargetUnitId);
		if (!TargetUnit)
		{
			Q6JsonLogSunny(Error, "UCPDamageBuffInstance::StartAction - Invalid Target Unit", Q6KV("TargetUnitId", Info->TargetUnitId));
			++Index;
			continue;
		}

		TargetUnit->SetHealth(Info->NewHealth);
		TargetUnit->StartBuffEffectFX(FBuffEffectType(Info->BuffEffectType));

		UUnitHit* HitInfo = NewObject<UUnitHit>();
		HitInfo->SetInfo(ENatureRelationType::Normal, Info->SourceUnitId, Info->TargetUnitId,
			Info->Heal, 0, 0, 0, false,
			0, Info->Reason, 0, 1, false, false);

		ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
		CombatHUD->OnHealBuffHit(Info);
		CombatHUD->OnHit(HitInfo, false, false);

		NoticedUnitId.AddUnique(Info->TargetUnitId);
		HealInfos.RemoveAt(Index);
	}

	if (!HealInfos.Num())
	{
		GetCheckedCombatHUD(this)->OnUnitNoticeAnimFinishedDelegate.BindUObject(this, &UCPHealBuffInstance::End);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPHealthChangedInstance

void UCPHealthChangedInstance::Start()
{
	Super::Start();

	GetCheckedCombatHUD(this)->OnHealthChanged(HealthChangedEvent);

	if (CombatPresenter->GetTurnPhase() != ECCTurnPhase::Prepare)
	{
		End();
		return;
	}
}

void UCPHealthChangedInstance::BindContentDelegate()
{
	GetCheckedCombatHUD(this)->OnDamageTextAnimFinishedDelegate.BindUObject(this, &UCPHealthChangedInstance::End);
}

void UCPHealthChangedInstance::UnbindContentDelegate()
{
	GetCheckedCombatHUD(this)->OnDamageTextAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPCutSceneInstance

UCPCutSceneInstance::UCPCutSceneInstance()
	: Episode(0)
	, Stage(0)
	, Wave(0)
	, bIsIntro(true)
	, FadeOutTime(0.0f)
{
}

void UCPCutSceneInstance::SetCutSceneInfo(int32 InEpisode, int32 InStage, int32 InWave, bool bInIsIntro)
{
	Episode = InEpisode;
	Stage = InStage;
	Wave = InWave;
	bIsIntro = bInIsIntro;

	const FWaveSequenceAssetRow& WaveSequenceAssetRow = GetGameResource().GetWaveSequenceAssetRow(Episode, Stage, Wave);
	FadeOutTime = bIsIntro ? WaveSequenceAssetRow.IntroFadeOutTime : WaveSequenceAssetRow.OutroFadeOutTime;
}

bool UCPCutSceneInstance::Prepare()
{
	SetTimeOutLimit(SEQUENCER_PLAY_TIMEOUT);

	return Super::Prepare();
}

void UCPCutSceneInstance::Start()
{
	Super::Start();

	GetCheckedCombatHUD(this)->SetWidgetsVisible(false);

	CombatPresenter->StartCameraFadeIn();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{

		PlayerController->SequenceFinishedDelegate.BindUObject(this, &UCPCutSceneInstance::End);
		PlayerController->PlayWaveSequence(Episode, Stage, Wave, bIsIntro);

		if (PlayerController->IsPlayingSequence())
		{
			const float WaveSequenceLength = PlayerController->GetWaveSequenceLength();
			SetTimeOutLimit(WaveSequenceLength + FadeOutTime);
		}
	}
}

void UCPCutSceneInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SequenceFinishedDelegate.Unbind();
	}
}

void UCPCutSceneInstance::End()
{
	if (FadeOutTime > 0.0f)
	{
		CombatPresenter->SetCameraFadeBlackOut();

		CombatPresenter->GetWorldTimerManager().ClearTimer(FadeOutTimerHandle);
		CombatPresenter->GetWorldTimerManager().SetTimer(FadeOutTimerHandle, this, &UCPCutSceneInstance::FadeOutEnd, 1.0f, false, FadeOutTime);
	}
	else
	{
		FadeOutEnd();
	}

	bUseTimeOut = false;
}

void UCPCutSceneInstance::FadeOutEnd()
{
	GetCheckedCombatHUD(this)->SetWidgetsVisible(true);

	// if this cut scene is outro
	if (!bIsIntro)
	{
		ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
		if (PlayerController)
		{
			// next wave has the intro cut scene
			if (PlayerController->HasWaveSequence(Episode, Stage, Wave + 1, true))
			{
				// CombatHUDWidget must be hidden until playing the next intro cut scene.
				GetCheckedCombatHUD(this)->SetWidgetsVisible(false);
			}
		}
	}

	CombatPresenter->GetWorldTimerManager().ClearTimer(FadeOutTimerHandle);

	if (bIsIntro)
	{
		CombatPresenter->StartWave(StartWaveEvent);
	}

	Super::End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPWaveInstance

UCPWaveInstance::UCPWaveInstance()
	: Wave(0)
{}

void UCPWaveInstance::Start()
{
	Super::Start();

	// move allies to next wave position
	MoveUnitIds.Empty();

	TArray<AUnit*> AllyUnits = CombatPresenter->FindUnitsByFaction(ECCFaction::Ally);
	for (AUnit* Unit : AllyUnits)
	{
		if (Unit->IsDead())
		{
			continue;
		}

		MoveUnitIds.Add(Unit->GetUnitId());

		Unit->AnimMoveEndDelegate.BindUObject(this, &UCPWaveInstance::OnUnitMoveFinished, Unit->GetUnitId());

		if (Wave > 1)
		{
			Unit->AnimUnrelaxedDelegate.BindUObject(this, &UCPWaveInstance::OnUnitUnrelaxed, Unit->GetUnitId());
			Unit->SetAnimRelaxed(false);

			FTransform InstantTransform = CombatPresenter->GetAllyCameraOutTransform(Unit->GetUnitState().Slot);
			Unit->SetActorTransform(InstantTransform);
		}
		else
		{
			OnUnitUnrelaxed(Unit->GetUnitId());
		}
	}

	// pet spawn anim
	APetUnit* PetUnit = CombatPresenter->GetPetUnit();
	if (!PetUnit)
	{
		APetUnit* NewPetUnit = CombatPresenter->SpawnPetUnit();
		if (NewPetUnit)
		{
			NewPetUnit->PlaySpawnAnimation();
		}
	}
	else
	{
		PetUnit->SetActorTransform(CombatPresenter->GetPetTransform());
		PetUnit->PlaySpawnAnimation();
	}

	CombatPresenter->BindCombatCameraToController();
	CombatPresenter->StartCameraFadeIn();
	GetCheckedCombatHUD(this)->OnStartWave(StartWaveEvent);

	if (!MoveUnitIds.Num())
	{
		End();
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatPresenter->GetCombatSeed().SagaType);
	ULevelUtil::LoadSagaLevelEffect(GetWorld(), SagaRow.Episode, SagaRow.Stage, Wave);
}

void UCPWaveInstance::OnUnitUnrelaxed(const FCCUnitId InUnitId)
{
	if (!MoveUnitIds.Contains(InUnitId))
	{
		return;
	}

	AUnit* Unit = CombatPresenter->FindUnit(InUnitId);
	if (Unit)
	{
		FTransform WaveTransform = CombatPresenter->GetWaveTransform(Unit->GetOverrideFaction(), Unit->GetUnitState().Slot);
		Unit->MoveToWave(WaveTransform);
	}
}

void UCPWaveInstance::OnUnitMoveFinished(const FCCUnitId InUnitId)
{
	if (!MoveUnitIds.Contains(InUnitId))
	{
		return;
	}

	MoveUnitIds.Remove(InUnitId);
	if (!MoveUnitIds.Num())
	{
		End();
	}
}

void UCPWaveInstance::UnbindContentDelegate()
{
	TArray<AUnit*> AllyUnits = CombatPresenter->FindUnitsByFaction(ECCFaction::Ally);
	for (AUnit* Unit : AllyUnits)
	{
		Unit->AnimRelaxedDelegate.Unbind();
		Unit->AnimMoveEndDelegate.Unbind();
	}
}

void UCPWaveInstance::End()
{
	Super::End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPTurnInstance

UCPTurnInstance::UCPTurnInstance()
	: bCameraWorkFinished(false)
	, bHUDAnimFinished(false)
{
}

void UCPTurnInstance::Start()
{
	Super::Start();
	
	bool bWaitCamera = false;
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		bWaitCamera = PlayerController->ChangeToWaveCamera(ECombatCameraBlendType::NormalBlend);
	}

	if (!bWaitCamera)
	{
		OnCameraBlendingFinished(false);
	}
	
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnStartTurn(StartTurnEvent);
}

void UCPTurnInstance::OnCameraBlendingFinished(bool bRestoring)
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController && PlayerController->GetCombatCameraType() == ECombatCamera::Wave)
	{
		if (PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::LongBlend))
		{
			return;
		}
	}

	bCameraWorkFinished = true;
	if (bHUDAnimFinished)
	{
		End();
	}
}

void UCPTurnInstance::OnHUDAnimFinished()
{
	bHUDAnimFinished = true;
	if (bCameraWorkFinished)
	{
		End();
	}
}

void UCPTurnInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPTurnInstance::OnCameraBlendingFinished);
	}

	GetCheckedCombatHUD(this)->OnStartTurnPhaseAnimFinishedDelegate.BindUObject(this, &UCPTurnInstance::OnHUDAnimFinished);
}

void UCPTurnInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}

	GetCheckedCombatHUD(this)->OnStartTurnPhaseAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPPhaseInstance

UCPPhaseInstance::UCPPhaseInstance()
	: bCameraWorkFinished(false)
	, bHUDAnimFinished(false)
{
}

bool UCPPhaseInstance::ShouldSkipCamera() const
{
	if (StartPhaseEvent->Phase == ECCTurnPhase::OppTurnSkill &&
		!CombatPresenter->HasEventQueued(ECCEventType::SkillUsed, ECCEventType::StartPhase))
	{
		return true;
	}

	return false;
}

void UCPPhaseInstance::Start()
{
	Super::Start();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (ShouldSkipCamera() || !PlayerController)
	{
		bCameraWorkFinished = true;
		StartHUD();
		return;
	}

	bool bWaitCamera = false;
	switch (StartPhaseEvent->Phase)
	{
		case ECCTurnPhase::OppTurnSkill:
			bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Enemy, ECombatCameraBlendType::NoBlend);
			break;
		case ECCTurnPhase::TurnSkill:
			StartEnemyUltimateReady();
			break;
		case ECCTurnPhase::OppAttack:
		case ECCTurnPhase::ChangeCombatMultiSide:
			bWaitCamera = PlayerController->ChangeToWaveCamera(ECombatCameraBlendType::NormalBlend);
			break;
		default:
			break;
	}

	if (!bWaitCamera || !PlayerController->IsCombatCameraBlending())
	{
		OnCameraBlendingFinished(false);
	}

	StartHUD();
}

void UCPPhaseInstance::StartHUD()
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnStartPhase(StartPhaseEvent);
}

void UCPPhaseInstance::StartEnemyUltimateReady()
{
	TArray<FCCUnitId> UltimateReadyEnemyUnitIds = CombatPresenter->FindUltimateReadyEnemyIds();
	if (UltimateReadyEnemyUnitIds.Num())
	{
		CombatPresenter->ChangeToEnemyUltimateReadyPhase();

		UCPEnemyUltimateReadyInstance* EnemyUltimateReadyInstance = CombatPresenter->CreateInstance<UCPEnemyUltimateReadyInstance>();
		check(EnemyUltimateReadyInstance);
		EnemyUltimateReadyInstance->SetEnemyUnitIds(UltimateReadyEnemyUnitIds);
		EnemyUltimateReadyInstance->Prepare();
	}
	else
	{
		if (CombatPresenter->GetCombatSeed().Content == EContentType::Raid
			&& CombatPresenter->GetTurnCount() > CombatCubeConst::Q6_FIRST_TURN)
		{
			GetCheckedCombatCube(this)->UseRaidTurnSkills();
		}
	}

	End();
}

void UCPPhaseInstance::OnCameraBlendingFinished(bool bRestoring)
{
	if (IsAnyAttackPhase(StartPhaseEvent->Phase))
	{
		ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
		if (PlayerController && PlayerController->GetCombatCameraType() == ECombatCamera::Wave)
		{
			if (PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::LongBlend))
			{
				return;
			}
		}
	}

	bCameraWorkFinished = true;
	if (bHUDAnimFinished)
	{
		End();
	}
}

void UCPPhaseInstance::OnHUDAnimFinished()
{
	bHUDAnimFinished = true;
	if (bCameraWorkFinished)
	{
		End();
	}
}

void UCPPhaseInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPPhaseInstance::OnCameraBlendingFinished);
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnStartTurnPhaseAnimFinishedDelegate.BindUObject(this, &UCPPhaseInstance::OnHUDAnimFinished);
}

void UCPPhaseInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnStartTurnPhaseAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPEnemyUltimateReadyInstance

UCPEnemyUltimateReadyInstance::UCPEnemyUltimateReadyInstance()
	: bUnitAnimFinished(false)
	, bHUDAnimFinished(false)
{
}

void UCPEnemyUltimateReadyInstance::Start()
{
	Super::Start();

	SetTimeOutLimit(DEFAULT_INSTANCE_TIMEOUT);
	StartCamera();
}

void UCPEnemyUltimateReadyInstance::End()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->ChangeToPrepareCamera();
	}

	GetCheckedCombatHUD(this)->OnPrepareTurnSkillPhase();

	Super::End();
}

void UCPEnemyUltimateReadyInstance::StartCamera()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (!PlayerController || !EnemyUnitIds.Num())
	{
		bUnitAnimFinished = true;
		return;
	}

	bool bWaitCamera = false;

	const int32 EnemyUnitIdsNum = FMath::Max(EnemyUnitIds.Num(), 0);
	if (EnemyUnitIdsNum == 0 || (bUnitAnimFinished && bHUDAnimFinished))
	{
		bWaitCamera = PlayerController->ChangeToPrepareCamera();
	}
	else if (EnemyUnitIdsNum == 1)
	{
		AUnit* EnemyUnit = CombatPresenter->FindUnit(EnemyUnitIds[0]);
		if (EnemyUnit)
		{
			bWaitCamera = PlayerController->ChangeToEnemyCamera(EnemyUnit->GetSlot(), CombatPresenter->GetWaveEnemyNumSlots(), CombatPresenter->IsWaveEnemyDefaultPosition(), ECombatCameraBlendType::NoBlend);
		}
	}
	else
	{
		bWaitCamera = PlayerController->ChangeToFactionAllCamera(ECCFaction::Enemy, ECombatCameraBlendType::NoBlend);
	}

	if (!bWaitCamera || !PlayerController->IsCombatCameraBlending())
	{
		OnCameraBlendingFinished(false);
	}
}

void UCPEnemyUltimateReadyInstance::OnCameraBlendingFinished(bool bRestoring)
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (!PlayerController || PlayerController->GetCombatCameraType() == ECombatCamera::Prepare)
	{
		End();
	}
	else
	{
		for (const FCCUnitId& EnemyUnitId : EnemyUnitIds)
		{
			AUnit* EnemyUnit = CombatPresenter->FindUnit(EnemyUnitId);
			if (EnemyUnit)
			{
				bHUDAnimFinished = false;
				GetCheckedCombatHUD(this)->OnEnemyUltimateReady(EnemyUnit);

				bUnitAnimFinished = false;
				AUnit* SourceUnit = EnemyUnit->GetSourceUnit();
				if (SourceUnit)
				{
					SourceUnit->PlayShout();
				}
			}
		}
	}
}

void UCPEnemyUltimateReadyInstance::OnUnitAnimFinished()
{
	bUnitAnimFinished = true;
	if (bHUDAnimFinished)
	{
		StartCamera();
	}
}

void UCPEnemyUltimateReadyInstance::OnHUDAnimFinished()
{
	bHUDAnimFinished = true;
	if (bUnitAnimFinished)
	{
		StartCamera();
	}
}

void UCPEnemyUltimateReadyInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPEnemyUltimateReadyInstance::OnCameraBlendingFinished);
	}

	GetCheckedCombatHUD(this)->OnEnemyUltimateReadyAnimFinishedDelegate.BindUObject(this, &UCPEnemyUltimateReadyInstance::OnHUDAnimFinished);

	for (const FCCUnitId EnemyUnitId : EnemyUnitIds)
	{
		AUnit* EnemyUnit = CombatPresenter->FindUnit(EnemyUnitId);
		AUnit* SourceUnit = EnemyUnit ? EnemyUnit->GetSourceUnit() : nullptr;
		if (SourceUnit)
		{
			SourceUnit->AnimShoutEndDelegate.BindUObject(this, &UCPEnemyUltimateReadyInstance::OnUnitAnimFinished);
		}
	}
}

void UCPEnemyUltimateReadyInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}

	GetCheckedCombatHUD(this)->OnEnemyUltimateReadyAnimFinishedDelegate.Unbind();

	for (const FCCUnitId EnemyUnitId : EnemyUnitIds)
	{
		AUnit* EnemyUnit = CombatPresenter->FindUnit(EnemyUnitId);
		AUnit* SourceUnit = EnemyUnit ? EnemyUnit->GetSourceUnit() : nullptr;
		if (SourceUnit)
		{
			SourceUnit->AnimShoutEndDelegate.Unbind();
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPEnemyAttackPassInstance

void UCPEnemyAttackPassInstance::Start()
{
	Super::Start();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (!PlayerController)
	{
		End();
		return;
	}

	AUnit* EnemyUnit = CombatPresenter->FindUnit(Event->UnitId);
	if (!EnemyUnit)
	{
		End();
		return;
	}

	PlayerController->ChangeToEnemyCamera(EnemyUnit->GetSlot(), CombatPresenter->GetWaveEnemyNumSlots(), CombatPresenter->IsWaveEnemyDefaultPosition(), ECombatCameraBlendType::NoBlend);
	PlayerController->SetCombatCameraWaitingTime(1.f);
}

void UCPEnemyAttackPassInstance::OnCameraBlendingFinished(bool bRestoring)
{
	End();
}

void UCPEnemyAttackPassInstance::BindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &UCPEnemyAttackPassInstance::OnCameraBlendingFinished);
	}
}

void UCPEnemyAttackPassInstance::UnbindContentDelegate()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCPResultInstance

void UCPResultInstance::Start()
{
	Super::Start();

	bUseTimeOut = false;
	GetCheckedCombatHUD(this)->OnEndGame(EndGameEvent);
}

void UCPResultInstance::BindContentDelegate()
{
	Super::BindContentDelegate();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SequencePausedDelegate.BindUObject(this, &UCPResultInstance::OnSequenceFinished);
		PlayerController->SequenceFinishedDelegate.BindUObject(this, &UCPResultInstance::OnSequenceFinished);
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->ResultWidgetClosedDelegate.BindUObject(this, &UCPResultInstance::OnResultWidgetClosed);
	CombatHUD->WinAnimFinishedDelegate.BindUObject(this, &UCPResultInstance::OnWinAnimFinished);
}

void UCPResultInstance::UnbindContentDelegate()
{
	Super::UnbindContentDelegate();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SequencePausedDelegate.Unbind();
		PlayerController->SequenceFinishedDelegate.Unbind();
	}

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->ResultWidgetClosedDelegate.Unbind();
	CombatHUD->WinAnimFinishedDelegate.Unbind();
}

void UCPResultInstance::StartSequence()
{
	FName ResultBGM = (CombatPresenter->GetGameResult() == ECCResult::Win) ? TEXT("CombatResultWin") : TEXT("CombatResultLose");
	GetSoundPlayer().PlayMainBGM(ResultBGM, 0.0f);

	if (CombatPresenter->GetGameResult() != ECCResult::Win)
	{
		OnSequenceFinished();
		return;
	}

	FCCUnitId ResultUnitId = GetResultUnitId();
	if (ResultUnitId == CCUnitIdInvalid)
	{
		OnSequenceFinished();
		return;
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	AUnit* ResultUnit = CombatPresenter->FindUnit(ResultUnitId);

	if (PlayerController && ResultUnit)
	{
		PlayerController->PlayResultSequence(ResultUnit);
	}
	else
	{
		OnSequenceFinished();
	}
}

void UCPResultInstance::OnSequenceFinished()
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);

	switch (EndGameEvent->ContentType)
	{
		case EContentType::Raid:
			CombatHUD->PlayRaidResultAnim(false);
			break;
		case EContentType::RaidFinal:
			CombatHUD->PlayRaidResultAnim(true);
			break;
		default:
			CombatHUD->PlayRewardAnimation();
			break;
	}
}

void UCPResultInstance::OnResultWidgetClosed()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->StopResultSequence();
	}

	End();
}

void UCPResultInstance::OnWinAnimFinished()
{
	StartSequence();
}

FCCUnitId UCPResultInstance::GetResultUnitId() const
{
	FCCUnitId LastSkillUsedUnitId = CombatPresenter->GetLastSkillUsedUnitId();
	if (LastSkillUsedUnitId != CCUnitIdInvalid)
	{
		return LastSkillUsedUnitId;
	}

	FCCUnitId AnyAliveUnitId = CCUnitIdInvalid;

	CombatPresenter->IsAnyUnit([&AnyAliveUnitId](const AUnit& Unit) -> bool
	{
		// skip enemy or dead ally
		if (Unit.GetOverrideFaction() == ECCFaction::Ally && !Unit.IsDead())
		{
			AnyAliveUnitId = Unit.GetUnitId();
			return true;
		}

		return false;
	});

	return AnyAliveUnitId;
}

//////////////////////////////////////////////////////////////////////////////////
// UCPBoneDragonResultInstance

void UCPBoneDragonResultInstance::Start()
{
	Super::Start();

	bUseTimeOut = false;
	GetCheckedCombatHUD(this)->OnBoneDragonEndGame(EndGameEvent);

	StartSequence();
}

void UCPBoneDragonResultInstance::BindContentDelegate()
{
	Super::BindContentDelegate();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SequencePausedDelegate.BindUObject(this, &UCPBoneDragonResultInstance::OnSequenceFinished);
		PlayerController->SequenceFinishedDelegate.BindUObject(this, &UCPBoneDragonResultInstance::OnSequenceFinished);
	}
}

void UCPBoneDragonResultInstance::UnbindContentDelegate()
{
	Super::UnbindContentDelegate();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SequencePausedDelegate.Unbind();
		PlayerController->SequenceFinishedDelegate.Unbind();
	}
}

void UCPBoneDragonResultInstance::StartSequence()
{
	GetSoundPlayer().StopMainBGM();

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->PlayBoneDragonOutroSequence();
	}
	else
	{
		OnSequenceFinished();
	}
}

void UCPBoneDragonResultInstance::OnSequenceFinished()
{
	ULevelUtil::LoadLobbyLevel(GetWorld());

	End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPSkillFailedInstance

void UCPSkillFailedInstance::Start()
{
	Super::Start();

	GetCheckedCombatHUD(this)->OnSkillFailed(Event);
}

void UCPSkillFailedInstance::BindContentDelegate()
{
	GetCheckedCombatHUD(this)->OnSkillFailedAnimFinishedDelegate.BindUObject(this, &UCPSkillFailedInstance::End);
}

void UCPSkillFailedInstance::UnbindContentDelegate()
{
	GetCheckedCombatHUD(this)->OnSkillFailedAnimFinishedDelegate.Unbind();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPAttackPassInstance

bool UCPAttackPassInstance::Prepare()
{
	if (!Event->PhasePassUnitIds.Num())
	{
		return false;
	}

	return Super::Prepare();
}

void UCPAttackPassInstance::Start()
{
	Super::Start();

	GetCheckedCombatHUD(this)->OnSkillPass(Event->PhasePassUnitIds);

	Super::End();
}

//////////////////////////////////////////////////////////////////////////////////
// UCPDropBoxInstance

UCPDropBoxInstance::UCPDropBoxInstance()
	: bSkipFinishWaveAnim(false)
{

}

void UCPDropBoxInstance::Start()
{
	Super::Start();

	if (bSkipFinishWaveAnim)
	{
		End();
		return;
	}

	const float RemainTime = CombatPresenter->GetSpawnDropBoxRemainTime();
	if (RemainTime == 0.0f)
	{
		End();
		return;
	}

	CombatPresenter->GetWorldTimerManager().ClearTimer(CollectTimerHandle);
	CombatPresenter->GetWorldTimerManager().SetTimer(CollectTimerHandle, this, &UCPDropBoxInstance::End, 1.0f, false, RemainTime);
}

void UCPDropBoxInstance::End()
{
	Super::End();

	CombatPresenter->FinishWave(bSkipFinishWaveAnim);
}
