// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatLevelSequencePlayer.h"
#include "Engine/DirectionalLight.h"
#include "Q6Minimal.h"

//////////////////////////////////////////////////////////////////////////////////
// ACombatLevelSequenceActor
ACombatLevelSequenceActor::ACombatLevelSequenceActor(const FObjectInitializer& Init) : Super(Init, true)
{
	SequencePlayer = Init.CreateDefaultSubobject<UCombatLevelSequencePlayer>(this, "AnimationPlayer");
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatLevelSequencePlayer

UCombatLevelSequencePlayer* UCombatLevelSequencePlayer::CreateLevelSequencePlayer(UObject* WorldContextObject, ULevelSequence* InLevelSequence, FMovieSceneSequencePlaybackSettings Settings, ACombatLevelSequenceActor*& OutActor)
{
	if (InLevelSequence == nullptr)
	{
		return nullptr;
	}

	UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::LogAndReturnNull);
	if (World == nullptr)
	{
		return nullptr;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnParams.ObjectFlags |= RF_Transient;
	SpawnParams.bAllowDuringConstructionScript = true;
	ACombatLevelSequenceActor* Actor = World->SpawnActor<ACombatLevelSequenceActor>(SpawnParams);

	Actor->PlaybackSettings = Settings;
	Actor->LevelSequence = InLevelSequence;

	Actor->InitializePlayer();
	OutActor = Actor;

	return Cast<UCombatLevelSequencePlayer>(Actor->SequencePlayer);
}

void UCombatLevelSequencePlayer::OnObjectSpawned(UObject* InObject, const FMovieSceneEvaluationOperand& Operand)
{
	FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);

	AActor* SpawnedActor = Cast<AActor>(InObject);
	if (SpawnedActor && SpawnedActor->GetRootComponent())
	{
		SpawnedActor->PrestreamTextures(30.f, true, FMath::BitFlag[TEXTUREGROUP_Q6SequencePreload], true);
		auto MobilityBackup = SpawnedActor->GetRootComponent()->Mobility;
		if (SpawnedActor->GetRootComponent()->Mobility != LevelSequenceActor->GetRootComponent()->Mobility)
		{
			SpawnedActor->GetRootComponent()->SetMobility(LevelSequenceActor->GetRootComponent()->Mobility);
		}

		SpawnedActor->AttachToActor(LevelSequenceActor, AttachmentRules);
		SpawnedActor->GetRootComponent()->SetMobility(MobilityBackup);
		SequenceSpawnedActors.Add(SpawnedActor);
	}
}
