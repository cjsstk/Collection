// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatPresenter.h"

#include "AutomationHelper.h"
#include "CharacterManager.h"
#include "CharacterVoiceHelper.h"
#include "CombatCubeUtil.h"
#include "CombatHUD.h"
#include "CombatGameResource.h"
#include "CombatLocator.h"
#include "CombatPlayerController.h"
#include "CPInstances.h"
#include "DebugWidgets.h"
#include "Formula.h"
#include "GameAssetCache.h"
#include "GameResource.h"
#include "HUDStore//BattleHelper.h"
#include "HUDStore/HUDStore.h"
#include "LevelUtil.h"
#include "Loot.h"
#include "PartyManager.h"
#include "PetManager.h"
#include "PetUnit.h"
#include "Projectile.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6CombatGameState.h"
#include "Q6CombatGameStateMgr.h"
#include "Q6Define.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "Q6SoundPlayer.h"
#include "RaidManager.h"
#include "Unit.h"
#include "UnitAnimInstance.h"
#include "MainPartUnit.h"
#include "MainPartUnitAnimInstance.h"
#include "SubPartUnit.h"
#include "SystemConstHelper.h"
#include "Tutorial/CombatTutorial.h"
#include "WeeklyMissionManager.h"
#include "CharMissionManager.h"
#include "RewardManager.h"

#include "Widget/CommonWidgets.h"
#include "Camera/CameraLayerActor.h"
#include "Animation/SkeletalMeshActor.h"

static TAutoConsoleVariable<int32> CVarQ6ProjectileSpawnQueueSize(
	TEXT("q6.projectileSpawnQueueSize"),
	50,
	TEXT(""),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarQ6ProjectileSpawnPerTick(
	TEXT("q6.projectileSpawnPerTick"),
	2,
	TEXT(""),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarQ6BeamSpawnQueueSize(
	TEXT("q6.beamSpawnQueueSize"),
	10,
	TEXT(""),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarQ6BeamSpawnPerTick(
	TEXT("q6.beamSpawnPerTick"),
	1,
	TEXT(""),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarQ6SkeletalMeshSpawnQueueSize(
	TEXT("q6.skeletalMeshSpawnQueueSize"),
	10,
	TEXT(""),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarQ6SkeletalMeshSpawnPerTick(
	TEXT("q6.skeletalMeshSpawnPerTick"),
	1,
	TEXT(""),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarAllyCameraOutDistOffset(
	TEXT("q6.AllyCameraOutDistOffset"),
	600.f,
	TEXT("additional offset ally unit to be outside camera"),
	ECVF_Cheat);

#if !UE_BUILD_SHIPPING
static TAutoConsoleVariable<int32> CVarQ6Crash(
	TEXT("q6.crash"),
	0,
	TEXT("Crash client purposely"),
	ECVF_Cheat);
#endif

extern TAutoConsoleVariable<int32> CVarQ6UseLobbyCombat;

ACombatPresenter::ACombatPresenter(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, PresentTurnPhase(ECCTurnPhase::Prepare)
	, PresentResult(ECCResult::Unknown)
	, bEnemyUltimateReadyPhase(false)
	, bSteadyPhase(false)
	, PushIndex(0)
	, PopIndex(0)
	, LocatorGroup(1)
	, Wave(0)
	, WaveEnemyNumSlots(CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT)
	, bWaveEnemyDefaultPosition(false)
	, TurnCount(0)
	, TotalWaveNum(0)
	, StartBattleEpoch(0)
	, TargetedUnitId(CCUnitIdInvalid)
	, LastSkillUsedUnitId(CCUnitIdInvalid)
	, RestoredUnitId(CCUnitIdInvalid)
	, InstanceId(INITIALIZE_INSTANCE_ID)
	, LastMomentInstancesInfo(nullptr)
	, UnitAssetPreSpawnedTime(0.0f)
	, UnitAssetPreSpawnCleanupTime(0.0f)
{
	PrimaryActorTick.bCanEverTick = true;

	QueuedEvents.SetNum(MAX_QUEUED_EVENT_COUNT);
}

void ACombatPresenter::BindCombatCubeEvent(ACombatCube* InCombatCube)
{
	InCombatCube->GetStore()->OnEvent.AddDynamic(this, &ACombatPresenter::OnCombatCubeEvent);
}

AUnit* ACombatPresenter::FindUnit(FCCUnitId InUnitId)
{
#if !UE_BUILD_SHIPPING
	int32 Q6CrashOn = CVarQ6Crash.GetValueOnGameThread();
	if (Q6CrashOn)
	{
		return (AUnit*)0xDEAD;
	}
#endif

	if (!SpawnedUnits.IsValidIndex(InUnitId.X))
	{
		checkf(false, TEXT("Invalid UnitId(%d)"), InUnitId.X);
		return nullptr;
	}

	return SpawnedUnits[InUnitId.X];
}

const AUnit* ACombatPresenter::FindUnit(FCCUnitId InUnitId) const
{
#if !UE_BUILD_SHIPPING
	int32 Q6CrashOn = CVarQ6Crash.GetValueOnGameThread();
	if (Q6CrashOn)
	{
		return (AUnit*)0xDEAD;
	}
#endif

	if (!SpawnedUnits.IsValidIndex(InUnitId.X))
	{
		checkf(false, TEXT("Invalid UnitId(%d)"), InUnitId.X);
		return nullptr;
	}

	const AUnit* InUnit = SpawnedUnits[InUnitId.X];
	if (!InUnit)
	{
		//checkf(false, TEXT("Invalid Unit Id(%d)"), InUnitId.X);
		Q6JsonLogBro(Warning, "Unit is not exists");
	}

	return InUnit;
}

TArray<AUnit*> ACombatPresenter::FindUnitsByFaction(ECCFaction InFaction)
{
	TArray<AUnit*> Units;

	ForEachUnit([InFaction, &Units](AUnit& InUnit)
	{
		if (InUnit.GetOverrideFaction() == InFaction)
		{
			Units.Add(&InUnit);
		}
	});

	return Units;
}

TArray<AUnit*> ACombatPresenter::FindAliveUnitPerSlotByFaction(ECCFaction InFaction)
{
	TArray<AUnit*> Units;
	Units.AddDefaulted(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);	// MAX_SPAWNED_ALLY_UNIT == MAX_SPAWNED_ENEMY_UNIT

	ForEachUnit([InFaction, &Units](AUnit& InUnit)
	{
		if (!InUnit.IsDead() && InUnit.GetOverrideFaction() == InFaction)
		{
			const int32 UnitSlotIndex = InUnit.GetSlot() - 1;
			if (Units.IsValidIndex(UnitSlotIndex))
			{
				Units[UnitSlotIndex] = &InUnit;
			}
			else
			{
				Q6JsonLogPawn(Warning, "Unit slot is invalid", Q6KV("UnitType", InUnit.GetUnitType()), Q6KV("Slot", InUnit.GetSlot()));
			}
		}
	});

	return Units;
}

TArray<FCCUnitId> ACombatPresenter::FindUltimateReadyEnemyIds()
{
	TArray<FCCUnitId> UnitIds;

	for (AUnit* EnemyUnit : FindUnitsByFaction(ECCFaction::Enemy))
	{
		int32 NextSkillWaitdown = INVALID_WAITDOWN;
		EnemyUnit->GetNextUltimateSkillWaitdown(NextSkillWaitdown);
		if (NextSkillWaitdown == 0)
		{
			UnitIds.Add(EnemyUnit->GetUnitId());
		}
	}

	return UnitIds;
}

TArray<int32> ACombatPresenter::FindDeadUnitSlotsByFaction(ECCFaction InFaction)
{
	TArray<int32> DeadUnitSlots;

	ForEachUnit([InFaction, &DeadUnitSlots](AUnit& InUnit)
	{
		if (InUnit.GetOverrideFaction() == InFaction && InUnit.IsDead())
		{
			const int DeadUnitSlot = InUnit.GetUnitState().Slot;
			if (!DeadUnitSlots.Contains(DeadUnitSlot))
			{
				DeadUnitSlots.Add(DeadUnitSlot);
			}
		}
	});

	return DeadUnitSlots;
}

bool ACombatPresenter::IsMaster(FCCUnitId InUnitId)
{
	static_assert((int32)ECCFaction::Max == 2, "need more master.");

	if (Masters[(int32)ECCFaction::Ally].MasterId == InUnitId
		|| Masters[(int32)ECCFaction::Enemy].MasterId == InUnitId)
	{
		return true;
	}

	return false;
}

const FMasterState& ACombatPresenter::GetAllyMaster() const
{
	return Masters[(int32)ECCFaction::Ally];
}

void ACombatPresenter::UpdateDebugState(UDebugCombatWidget* DebugCombatWidget)
{
#if !UE_BUILD_SHIPPING
	if (!DebugCombatWidget)
	{
		return;
	}

	const UEnum* EventEnumPtr = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECCEventType"));
	FString DebugState("Queued Events\n");
	int32 i = PopIndex;
	while (i != PushIndex)
	{
		if (!QueuedEvents[i])
		{
			break;
		}
		DebugState += FString::Printf(TEXT("%s\n"), *(EventEnumPtr->GetNameStringByValue((int32)QueuedEvents[i]->GetEventType())));
		++i;
		if (i >= MAX_QUEUED_EVENT_COUNT)
		{
			i = 0;
		}
	}

	DebugCombatWidget->SetCombatPresenterStateText(FText::FromString(DebugState));
#endif
}

bool ACombatPresenter::IsCurrentCombatMultiSideUnit(const AUnit* Unit) const
{
	return UCombatCubeStateUtil::IsCurrentCombatMultiSide(
		CurrentCombatMultiSide,
		Unit->GetCombatMultiSide(),
		GetWaveIndex(),
		Unit->GetSpawnedWaveIndex());
}

bool ACombatPresenter::IsBossRewardWave() const
{
	if (CombatSeed.Content == EContentType::DailyDungeon)
	{
		return GetCMS()->HasBossBonusDailyDungeon(CombatSeed.SagaType) && IsLastWave();
	}

	if (CombatSeed.Content == EContentType::Raid)
	{
		return true;
	}

	return false;
}

int32 ACombatPresenter::GetBossRewardNumber()
{
	int32 BonusRewardNum = 0;
	if (CombatSeed.Content == EContentType::DailyDungeon)
	{
		if (IsLastWave())
		{
			FUnitType BossUnitType = UnitTypeInvalid;
			if (const FCMSDailyDungeonRow* Row = GetCMS()->GetDailyDungeonRow(CombatSeed.SagaType))
			{
				BossUnitType = FUnitType(Row->BossId);
			}

			TArray<AUnit*> EnemyUnits = FindUnitsByFaction(ECCFaction::Enemy);
			for (const AUnit* Unit : EnemyUnits)
			{
				if (Unit->GetUnitType() != BossUnitType)
				{
					continue;
				}

				int32 MaxHealth = Unit->GetMaxHealth();
				if (MaxHealth <= 0)
				{
					return 0;
				}

				int32 DamagedHealth = MaxHealth - Unit->GetHealth();
				BonusRewardNum = ((float)DamagedHealth / MaxHealth) * 10;
				break;
			}
		}
	}
	else if (CombatSeed.Content == EContentType::Raid)
	{
		int32 MaxHealth = 0;
		int32 DamagedHealth = 0;

		TArray<AUnit*> EnemyUnits = FindUnitsByFaction(ECCFaction::Enemy);
		for (const AUnit* Unit : EnemyUnits)
		{
			const FUnitState& UnitState = Unit->GetUnitState();

			MaxHealth += UnitState.MaxHealth;
			DamagedHealth += UnitState.MaxHealth - UnitState.Health;
		}

		if (MaxHealth <= 0)
		{
			return 0;
		}

		BonusRewardNum = ((float)DamagedHealth / MaxHealth) * 10;
	}

	return FMath::Clamp(BonusRewardNum, 0, MAX_BONUS_REWARD_MARK);
}

bool ACombatPresenter::IsCameraFading() const
{
	ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
	if (PlayerController)
	{
		return PlayerController->PlayerCameraManager->FadeTimeRemaining > 0;
	}

	return false;
}

void ACombatPresenter::SetCameraFadeBlackOut() const
{
	ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
	if (PlayerController)
	{
		PlayerController->PlayerCameraManager->SetManualCameraFade(1.0f, FLinearColor::Black, false);
	}
}

void ACombatPresenter::StartCameraFadeIn() const
{
	ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
	if (PlayerController)
	{
		PlayerController->PlayerCameraManager->StartCameraFade(1.0f, 0.0f, 0.5f, FLinearColor::Black);
	}
}

void ACombatPresenter::StartCameraFadeOut() const
{
	ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
	if (PlayerController)
	{
		PlayerController->PlayerCameraManager->StartCameraFade(0.0f, 1.0f, 0.5f, FLinearColor::Black, false, true);
	}
}

void ACombatPresenter::OnCameraBlendingFinished(bool bRestoring)
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->CameraWaitingFinishedDelegate.Unbind();
		PlayerController->ChangeToFactionAllCamera(ECCFaction::Ally, ECombatCameraBlendType::LongBlend);
	}
}

void ACombatPresenter::SetCombatMissionInfo()
{
	UHUDStore& HUDStore = GetHUDStore();

	GetCheckedCombatCube(this)->InitCombatMission(
		HUDStore.GetWeeklyMissionManager().GetCombatWeeklyMission()
		, HUDStore.GetCharMissionManager().GetCombatCharacterMission(CombatSeed.PartyId));
}

void ACombatPresenter::UpdateFinishCondition() const
{
	if (IsGameFinished())
	{
		return;
	}

	int32 LimitTurn = 0;
	int32 LimitTime = 0;
	GetCMS()->GetSagaFinishCondition(CombatSeed.SagaType, LimitTurn, LimitTime);
	if (LimitTurn > 0)
	{
		if (TurnCount >= LimitTurn)
		{
			if (CombatSeed.Content == EContentType::Raid)
			{
				GetCheckedCombatCube(this)->GetStore()->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::TurnOver));
			}
			else
			{
				if (CombatSeed.Content == EContentType::DailyDungeon)
				{
					if (IsBossRewardWave())
					{
						GetCheckedCombatCube(this)->GetStore()->Dispatch(FCCEndGameAction(ECCResult::Tied, ECCEndReason::TurnOver));
					}
					else
					{
						GetCheckedCombatCube(this)->GetStore()->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::TurnOver));
					}
				}
				else
				{
					GetCheckedCombatCube(this)->GetStore()->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::TurnOver));
				}
			}

			Q6JsonLogObiwan(Display, "over limit turn", Q6KV("limit turn", LimitTurn));
		}
	}

	if (LimitTime > 0)
	{
		int64 AccumPlaySecs = FDateTime::UtcNow().ToUnixTimestamp() - StartBattleEpoch;
		float LimitSecs = LimitTime * 60;
		if (AccumPlaySecs > LimitSecs)
		{
			if (CombatSeed.Content == EContentType::Raid)
			{
				GetCheckedCombatCube(this)->GetStore()->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::TimeOver));
			}
			else
			{
				GetCheckedCombatCube(this)->GetStore()->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::TimeOver));
			}

			Q6JsonLogObiwan(Display, "over limit time", Q6KV("limit mins", LimitTime));
		}
	}
}

void ACombatPresenter::SelectProvokedTarget(FCCUnitId InUnitId)
{
	if (RestoredUnitId == CCUnitIdInvalid)
	{
		// set first target monster
		TargetMonsterIfCurrentIsDead();
	}

	SelectTarget(InUnitId, false);
}

void ACombatPresenter::RestoreSelectTarget()
{
	AUnit* RestoreUnit = FindUnit(RestoredUnitId);
	if (RestoreUnit && RestoreUnit->IsDead() || RestoredUnitId == CCUnitIdInvalid)
	{
		// if restore unit is dead, select other monster unit
		TargetMonsterIfCurrentIsDead();
	}

	SelectTarget(RestoredUnitId, false);
}

void ACombatPresenter::OnRaidTurnSkillFinished(const UCCRaidTurnSkillFinishedEvent* Event)
{
	GetCheckedCombatHUD(this)->OnStartTurnSkillPhase();
}

void ACombatPresenter::OnRaidSkillUsed(const UCCRaidSkillUsed* Event)
{
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	RaidManager.ReqSkillUsed(Event->Elements, Event->Damage);
}

void ACombatPresenter::OnCombatWeeklyMission(const UCCMissionEvent* Event)
{
	GetCheckedCombatHUD(this)->OnCombatMission(Event);
}

void ACombatPresenter::OnSelectedPatternUltimate(const UCCSelectedPatternUltimate* Event)
{
	GetCheckedCombatHUD(this)->WarningPatternUltimate(Event);
}

void ACombatPresenter::OnChangeCombatMultiSide(const UCCChangeCombatMultiSide* Event)
{
	check(CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide);

	if (Event->bStartWave)
	{
		// use old wave index & old combat multi side
		HideCombatMultiSideUnits();

		CurrentCombatMultiSide = Event->CurrentCombatMultiSide;
		CombatMultiSideWaveRowIndex = Event->WaveRowIndex;
		Wave = Event->Wave;

		// use new wave index
		ShowCombatMultiSideUnits();

		// after spawn ally units
		UCCStartWaveEvent* NewWaveEvent = NewObject<UCCStartWaveEvent>();
		NewWaveEvent->WaveCount = Event->Wave;
		NewWaveEvent->WaveIndex = Event->Wave - 1;
		NewWaveEvent->WaveEnemyNumSlots = Event->WaveEnemyNumSlots;
		NewWaveEvent->FirstWaveIndex = 1;

		OnStartWave(NewWaveEvent);
	}
	else
	{
		OnFinishWave(false);
	}
}

void ACombatPresenter::BeginPlay()
{
	Super::BeginPlay();

	ULevelUtil::EmptyLocators(GetWorld());

	CGStateMgr = NewObject<UQ6CombatGameStateMgr>();
	if (ensure(CGStateMgr))
	{
		CGStateMgr->InitFSM(this);
	}

	int32 ProjectileSpawnQueueSize = CVarQ6ProjectileSpawnQueueSize.GetValueOnGameThread();
	SpawnProjectileQueue.Reset(new TCircularQueue<FSpawnProjectileParams>(ProjectileSpawnQueueSize));

	int32 BeamParticleSpawnQueueSize = CVarQ6BeamSpawnQueueSize.GetValueOnGameThread();
	SpawnBeamParticleQueue.Reset(new TCircularQueue<FSpawnBeamParticleParams>(BeamParticleSpawnQueueSize));

	int32 SkeletalMeshSpawnQueueSize = CVarQ6SkeletalMeshSpawnQueueSize.GetValueOnGameThread();
	SpawnSkeletalMeshQueue.Reset(new TCircularQueue<FSpawnSkeletalMeshParams>(SkeletalMeshSpawnQueueSize));

#if !UE_BUILD_SHIPPING
	AutomationHelper = NewObject<UAutomationHelper>(this);
#endif

	DropBoxSpawner = NewObject<UDropBoxSpawner>(this);
	DropBoxSpawner->BeginPlay();
}

void ACombatPresenter::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);

	SpawnProjectileQueue.Reset();
	SpawnBeamParticleQueue.Reset();
	SpawnSkeletalMeshQueue.Reset();

	DropBoxSpawner->EndPlay();
	DropBoxSpawner = nullptr;
}

void ACombatPresenter::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// prespawn waiting
	if (UnitAssetPreSpawnedTime > 0.0f)
	{
		const double CurrentTime = FApp::GetCurrentTime();
		if (CurrentTime - UnitAssetPreSpawnedTime > 3.0f)
		{
			CleanUpPreSpawnedUnitAssets();
			UnitAssetPreSpawnCleanupTime = CurrentTime;
			UnitAssetPreSpawnedTime = 0.0f;
		}
		return;
	}
	else if (UnitAssetPreSpawnCleanupTime > 0.0f)
	{
		const double CurrentTime = FApp::GetCurrentTime();
		if (CurrentTime - UnitAssetPreSpawnCleanupTime > 1.0f)
		{
			UnitAssetPreSpawnCleanupTime = 0.0f;
		}
		return;
	}

	// camera fade waiting
	if (IsCameraFading())
	{
		return;
	}

	UpdateInstance(DeltaTime);
	PumpEvent();

	if (ensure(CGStateMgr))
	{
		CGStateMgr->Update(DeltaTime);
	}

	UpdateSpawnProjectiles();
	UpdateSpawnBeamParticles();
	UpdateSpawnSkeletalMeshes();
	UpdateDynamicParticles();

	if (!CVarQ6UseLobbyCombat.GetValueOnGameThread())
	{
		UpdateFinishCondition();
	}

	DropBoxSpawner->Update();
}

void ACombatPresenter::UpdateInstance(float DeltaTime)
{
	if (QueuedInstances.Num() > 0)
	{
		UCPInstanceBase* CurInstance = QueuedInstances[0];
		if (CurInstance->GetState() == ECPInstanceState::Prepare)
		{
			CurInstance->Start();
		}
		CurInstance->Tick(DeltaTime);
	}

	for (auto NBInstance : NonBlockingQueuedInstances)
	{
		NBInstance->Tick(DeltaTime);
	}
}

void ACombatPresenter::PumpEvent()
{
	if (ensure(CGStateMgr))
	{
		const UCCEvent* Event = PeekEvent();
		if (Event != nullptr)
		{
			if (CGStateMgr->HandleInput(Event))
			{
				DequeueEvent();
				return;
			}
		}
	}
}

const UCCEvent* ACombatPresenter::PeekEvent() const
{
	if (PopIndex == PushIndex)
	{
		return nullptr;
	}

	return QueuedEvents[PopIndex];
}

void ACombatPresenter::EnqueueEvent(const UCCEvent* Event)
{
	QueuedEvents[PushIndex] = Event;
	if (++PushIndex >= MAX_QUEUED_EVENT_COUNT)
	{
		PushIndex = 0;
	}
}

const UCCEvent* ACombatPresenter::DequeueEvent()
{
	if (PopIndex == PushIndex)
	{
		return nullptr;
	}

	const UCCEvent* Event = QueuedEvents[PopIndex];
	QueuedEvents[PopIndex] = nullptr;

	if (++PopIndex >= MAX_QUEUED_EVENT_COUNT)
	{
		PopIndex = 0;
	}

	return Event;
}

bool ACombatPresenter::HasEventQueued(ECCEventType InTargetEventType, ECCEventType InEndEventType) const
{
	int32 Index = PopIndex;

	while (QueuedEvents[Index] && QueuedEvents[Index]->GetEventType() != InEndEventType)
	{
		if (QueuedEvents[Index]->GetEventType() == InTargetEventType)
		{
			return true;
		}

		if (++Index >= MAX_QUEUED_EVENT_COUNT)
		{
			Index = 0;
		}
	}

	return false;
}

UCPSkillInstance* ACombatPresenter::CreateSkillInstance(const UCCSkillUsedEvent* InSkillUsedEvent)
{
	switch (InSkillUsedEvent->SkillCategory)
	{
		case ESkillCategory::Moment:
			return CreateInstance<UCPMomentSkillInstance>(InSkillUsedEvent);
		case ESkillCategory::TurnBegin:
			return CreateInstance<UCPTurnSkillInstance>(InSkillUsedEvent);
		case ESkillCategory::Normal:
		case ESkillCategory::Double:
			return CreateInstance<UCPNormalSkillInstance>(InSkillUsedEvent);
		case ESkillCategory::Ultimate:
			return CreateInstance<UCPUltimateSkillInstance>(InSkillUsedEvent);
		case ESkillCategory::Versa:
		case ESkillCategory::Chain:
			return CreateInstance<UCPMasterSkillInstance>(InSkillUsedEvent);
		case ESkillCategory::Pet:
			return CreateInstance<UCPPetSkillInstance>(InSkillUsedEvent);
		case ESkillCategory::Artifact:
			return CreateInstance<UCPArtifactSkillInstance>(InSkillUsedEvent);
		default:
			return CreateInstance<UCPSkillInstance>(InSkillUsedEvent);
	}
}

static bool _ShouldCancelPreviousInstanceCameraReset(ECPInstanceType InInstanceType)
{
	switch (InInstanceType)
	{
		case ECPInstanceType::Spawn:
		case ECPInstanceType::Dead:
		case ECPInstanceType::Skill:
		case ECPInstanceType::MasterSkill:
		case ECPInstanceType::MomentSkill:
		case ECPInstanceType::TurnSkill:
		case ECPInstanceType::NormalSkill:
		case ECPInstanceType::UltimateSkill:
		case ECPInstanceType::Turn:
		case ECPInstanceType::Phase:
			return true;
		default:
			return false;
	}
}

void ACombatPresenter::OnInstanceState(ECPInstanceState InstanceState, UCPInstanceBase* Instance)
{
	switch (InstanceState)
	{
		case ECPInstanceState::Prepare:
			{
				if (Instance->IsBlocking())
				{
					int32 QueuedIndex = INDEX_NONE;
					QueuedIndex = QueuedInstances.Add(Instance);

					if (_ShouldCancelPreviousInstanceCameraReset(Instance->GetInstanceType()))
					{
						if (!QueuedInstances.IsValidIndex(QueuedIndex - 1))
						{
							break;
						}

						UCPInstanceBase* PreviousInstance = QueuedInstances[QueuedIndex - 1];
						PreviousInstance->SetResetCamera(false);
					}
				}
				else
				{
					NonBlockingQueuedInstances.Add(Instance);
					Instance->Start();
				}
			}
			break;
		case ECPInstanceState::ProceedNext:
			{
				UCPSkillInstance* CurSkillInstance = Cast<UCPSkillInstance>(Instance);
				if (CurSkillInstance && CurSkillInstance->IsInterruptable())
				{
					int32 InstanceIndex = QueuedInstances.IndexOfByKey(Instance);
					for (int32 i = InstanceIndex + 1; i < QueuedInstances.Num(); ++i)
					{
						if (!QueuedInstances.IsValidIndex(i))
						{
							continue;
						}

						UCPDeadInstance* DeadInstance = Cast<UCPDeadInstance>(QueuedInstances[i]);
						if (DeadInstance)
						{
							break;
						}

						UCPSkillInstance* NextSkillInstance = Cast<UCPSkillInstance>(QueuedInstances[i]);
						if (NextSkillInstance)
						{
							if (NextSkillInstance->IsInterruptive())
							{
								break;
							}

							if (NextSkillInstance->IsActiveSkill())
							{
								CurSkillInstance->End();
								NextSkillInstance->Start();
								break;
							}
						}
					}
				}
			}
			break;
		case ECPInstanceState::End:
			{
				if (Instance->IsBlocking())
				{
					int32 InstanceIndex = QueuedInstances.IndexOfByKey(Instance);
					if (ensure(InstanceIndex != INDEX_NONE))
					{
						QueuedInstances[InstanceIndex]->OnInstanceState.Unbind();
						QueuedInstances.RemoveAt(InstanceIndex);
					}
				}
				else
				{
					int32 InstanceIndex = NonBlockingQueuedInstances.IndexOfByKey(Instance);
					if (ensure(InstanceIndex != INDEX_NONE))
					{
						NonBlockingQueuedInstances[InstanceIndex]->OnInstanceState.Unbind();
						NonBlockingQueuedInstances.RemoveAt(InstanceIndex);
					}
				}

				if (SkillDrivenInfo.Instances.Contains(Instance))
				{
					SkillDrivenInfo.Instances.Remove(Instance);
					if (SkillDrivenInfo.IsEmpty())
					{
						OnSkillDrivenEffectEnd();
					}
				}
			}
			break;
		case ECPInstanceState::NA:
		case ECPInstanceState::Start:
		default:
			break;
	}
}

void ACombatPresenter::OnCombatCubeEvent(const UCCEvent* Event)
{
	switch (Event->GetEventType())
	{
		case ECCEventType::SkillUsed:
			GetCheckedCombatHUD(this)->OnSkillUsed(CastChecked<UCCSkillUsedEvent>(Event));
			break;
		default:
			break;
	}

	EnqueueEvent(Event);
}

void ACombatPresenter::OnReportError(const UCCReportErrorEvent* Event)
{
	GetCheckedCombatHUD(this)->OnReportError(Event);
}

void ACombatPresenter::OnStartGame(const UCCStartGameEvent* Event)
{
	SetCameraFadeBlackOut();

	CombatSeed = Event->CombatSeed;
	TotalWaveNum = Event->TotalWaveNum;

	LocatorGroup = GetCMS()->GetMapLocatorGroup(CombatSeed.SagaType);
	GetHUDStore().GetBattleHelper().ReqStageChallengeList(CombatSeed.SagaType);

	CacheStageAssets();

	ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
	if (PlayerController)
	{
		PlayerController->StopSequencePlayer();
	}

	PresentTurnPhase = ECCTurnPhase::Prepare;
	PresentResult = ECCResult::Unknown;
	CurrentCombatMultiSide = ECombatMultiSide::Main;
	CombatMultiSideWaveRowIndex = 0;
	CombatMultiSideTurnCount = CombatCubeConst::Q6_FIRST_TURN;

	if (CombatSeed.Content == EContentType::RaidFinal)
	{
		FRaidId RaidId = GetHUDStore().GetRaidManager().GetSelectedRaidFinalId();
		GetCheckedCombatCube(this)->SetRaidInfoToChronicle(RaidId);
	}

	CombatLocator = ULevelUtil::FindCombatLocator(GetWorld(), LocatorGroup, 1, CurrentCombatMultiSide);
	CameraLayerActor = ULevelUtil::FindCameraLayerActor(GetWorld(), ECameraLayerIndex::Layer1);

	BindCombatCameraToController();

	SpawnedUnits.Reset(CombatCubeConst::Q6_MAX_SPAWN_UNITS_PER_GAME);
	SpawnedUnits.AddZeroed(CombatCubeConst::Q6_MAX_SPAWN_UNITS_PER_GAME);
	SpawnedUnitIds.Reset();

	UCombatCubeStateUtil::ConvertCCMasterStateToMasterState(Event->MasterStates, &Masters);

	if (AutomationHelper)
	{
		AutomationHelper->GatherAllUnitTypes(CombatSeed.Units);
	}

	SetCombatMissionInfo();
	SetCharacterUnitInfos();
	SetItemDropInfo();

	GetCheckedCombatHUD(this)->OnStartGame(Event);
}

void ACombatPresenter::OnAllyWipeout(const UCCAllyWipeoutEvent* Event)
{
	GetCheckedCombatHUD(this)->OnAllyWipeout(Event);
}

void ACombatPresenter::OnEndGame(const UCCEndGameEvent* Event)
{
	PresentResult = Event->Result;

	if (CombatSeed.Content == EContentType::Raid)
	{
		GetGameInstance<UQ6GameInstance>()->RemoveOngoingChronicleFile();
	}

	UCPInstanceBase* Instance = nullptr;

	if (SystemConstHelper::IsBoneDragonSagaType(CombatSeed.SagaType))
	{
		Instance = CreateInstance<UCPBoneDragonResultInstance>(Event);
	}
	else
	{
		Instance = CreateInstance<UCPResultInstance>(Event);
	}

	Instance->Prepare();
}

void ACombatPresenter::OnStartWave(const UCCStartWaveEvent* Event)
{
	ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
	if (!PlayerController)
	{
		return;
	}

	Wave = Event->WaveIndex + 1;	// pawn - WaveCount is not counting BonusWave.

	const int32 WaveRowIndex = GetWaveRowIndex();
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(CombatSeed.SagaType, WaveRowIndex);
	if (WaveRow)
	{
		bWaveEnemyDefaultPosition = WaveRow->DefaultPosition;

		GetCombatTutorial(this)->EnterWave(WaveRow->CmsType());
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);
	if (PlayerController->HasWaveSequence(SagaRow.Episode, SagaRow.Stage, Wave, true))
	{
		StartCutScene(SagaRow.Episode, SagaRow.Stage, true, Event);
	}
	else
	{
		StartWave(Event);
	}
}

void ACombatPresenter::OnTakeTurn(const UCCTakeTurnEvent* Event)
{
	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OnTakeTurn(Event);
}

void ACombatPresenter::OnFinishWave(bool bSkipFinishWaveAnim)
{
	// before finish wave, collect the dropboxes on the ground
	UCPDropBoxInstance* DropBoxInstance = CreateInstance<UCPDropBoxInstance>();
	DropBoxInstance->SetSkipFinishWaveAnim(bSkipFinishWaveAnim);
	DropBoxInstance->Prepare();
}

void ACombatPresenter::OnStartTurn(const UCCStartTurnEvent* Event)
{
	TurnCount = Event->TurnCount;
	if (CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		CombatMultiSideTurnCount = Event->CombatMultiSideTurnCount;
	}

	if (CombatSeed.Content == EContentType::Raid
		&& TurnCount > CombatCubeConst::Q6_FIRST_TURN)
	{
		const URaidManager& RaidManager = GetHUDStore().GetRaidManager();

		GetCheckedCombatCube(this)->AddRaidTurnSkills(RaidManager.GetRaidTurnSkills(), RaidManager.GetRaidSupportSkills());
	}

	if (!IsGameFinished())
	{
		GetCheckedCombatCube(this)->SaveOngoingChronicle();
	}
	const int32 WaveRowIndex = GetWaveRowIndex();
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(CombatSeed.SagaType, WaveRowIndex);
	if (WaveRow)
	{
		GetCombatTutorial(this)->AddStageChallenge(CombatSeed.SagaType, WaveRow->CmsType());
	}

	// Units
	const TArray<FCCUnitState>& UnitStates = Event->UnitStates;
	ForEachUnit([&UnitStates](AUnit& InUnit)
	{
		const FCCUnitId& UnitId = InUnit.GetUnitId();

		const FCCUnitState* NewUnitState = UnitStates.FindByPredicate([&UnitId](const FCCUnitState& UnitState) {
			return (UnitState.UnitId == UnitId);
		});

		for (const FCCSkillState* SkillState : NewUnitState->GetSkillStates(ESkillCategory::TurnBegin))
		{
			InUnit.SetSkillCooldown(SkillState->SkillId, SkillState->Cooldown);
		}

		for (const FCCSkillState* SkillState : NewUnitState->GetSkillStates(ESkillCategory::Ultimate))
		{
			InUnit.SetSkillWaitdown(SkillState->SkillId, SkillState->Waitdown);
		}
	});

	// Masters
	for (int32 i = 0; i < (int32)ECCFaction::Max; ++i)
	{
		const FCCUnitState& CCMasterState = Event->MasterStates[i];
		UCombatCubeStateUtil::ConvertCCSkillStateToSkillState(CCMasterState.GetSkillStates(ESkillCategory::Pet), &Masters[i].Pets);
		UCombatCubeStateUtil::ConvertCCSkillStateToSkillState(CCMasterState.GetSkillStates(ESkillCategory::Artifact), &Masters[i].Artifacts);
	}

	UCPTurnInstance* TurnInstance = CreateInstance<UCPTurnInstance>(Event);
	check(TurnInstance);
	TurnInstance->Prepare();
}

void ACombatPresenter::OnUpdateBuffDurations(const UCCUpdateBuffDurationsEvent* Event)
{
	const TArray<FCCUnitState>& UnitStates = Event->UnitStates;
	ForEachUnit([&UnitStates](AUnit& InUnit)
	{
		const FCCUnitId& UnitId = InUnit.GetUnitId();

		const FCCUnitState* NewUnitState = UnitStates.FindByPredicate([&UnitId](const FCCUnitState& UnitState) {
			return (UnitState.UnitId == UnitId);
		});

		for (const FCCBuffState& BuffState : NewUnitState->Buffs)
		{
			InUnit.SetBuffDuration(BuffState.BuffType, BuffState.Duration);
		}
	});
}

void ACombatPresenter::OnStartPhase(const UCCStartPhaseEvent* Event)
{
	PresentTurnPhase = Event->Phase;
	bSteadyPhase = false;

	if (PresentTurnPhase == ECCTurnPhase::Prepare)
	{
		ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
		ForEachUnit([CombatHUD](AUnit& InUnit)
		{
			if (InUnit.ClearPointVaryUnitAttributes())
			{
				CombatHUD->ClearPointVaryUnitAttributes(InUnit.GetUnitId());
			}
		});

		// SubParty
		for (UCPSpawnInstance* SubPartySpawnInstance : SubPartySpawnInstances)
		{
			SubPartySpawnInstance->Prepare();
		}
		SubPartySpawnInstances.Empty();
		SpawnInstance = nullptr;
	}
	else if (PresentTurnPhase == ECCTurnPhase::OppTurnSkill)
	{
		PrepareMomentInstances(OnTurnBeginMomentInstancesInfo, false);
	}

	UCPPhaseInstance* PhaseInstance = CreateInstance<UCPPhaseInstance>(Event);
	check(PhaseInstance);
	PhaseInstance->Prepare();
}

void ACombatPresenter::OnSpawnUnit(const UCCSpawnUnitEvent* Event)
{
	SpawnInstance = CreateInstance<UCPSpawnInstance>(Event);
	check(SpawnInstance);

	if (SkillInstance)
	{
		ESkillCategory SkillCategory = SkillInstance->GetSkillCategory();
		bool bAllyTurnSkillDriven = PresentTurnPhase == ECCTurnPhase::TurnSkill && SkillCategory == ESkillCategory::TurnBegin;
		SpawnInstance->SetUsingTurnSkillCamera(bAllyTurnSkillDriven);

		SkillDrivenInfo.AddInstance(SpawnInstance);
		SkillSpawnInstances.Add(SpawnInstance);
	}
	else if (Event->SpawnReason == ESpawnReason::SubParty)
	{
		SubPartySpawnInstances.Add(SpawnInstance);
	}
	else
	{
		SpawnInstance->Prepare();
		SpawnInstance = nullptr;
	}
}

void ACombatPresenter::OnDespawnUnit(const UCCDespawnUnitEvent* Event)
{
	GetCheckedCombatHUD(this)->OnDespawnUnit(Event);

	AUnit* Unit = FindUnit(Event->UnitId);
	if (SpawnedUnits.IsValidIndex(Event->UnitId.X))
	{
		SpawnedUnits[Event->UnitId.X] = nullptr;
	}
	SpawnedUnitIds.Remove(Event->UnitId);

	if (Unit)
	{
		Unit->Destroy();
		Unit = nullptr;
	}
}

void ACombatPresenter::OnUnitDead(const UCCUnitDeadEvent* Event)
{
	TArray<FCCUnitId> AlreadyDeadUnitIds;
	for (const FCCUnitId& UnitId : Event->UnitIds)
	{
		AUnit* Unit = FindUnit(UnitId);
		if (!Unit)
		{
			Q6JsonLogObiwan(Warning, "already dead unit", Q6KV("UnitId", UnitId));
			AlreadyDeadUnitIds.Add(UnitId);
		}
	}

	if (AlreadyDeadUnitIds.Num() > 0)
	{
		// remove already dead unit id forcely
		UCCUnitDeadEvent* DeadEvent = const_cast<UCCUnitDeadEvent*>(Event);
		for (const FCCUnitId& AlreadyDeadUnitId : AlreadyDeadUnitIds)
		{
			DeadEvent->UnitIds.Remove(AlreadyDeadUnitId);
		}

		if (DeadEvent->UnitIds.Num() == 0)
		{
			return;
		}
	}

	UCPDeadInstance* DeadInstance = CreateInstance<UCPDeadInstance>(Event);
	check(DeadInstance);

	if (SkillInstance && SkillInstance->GetSkillId() == Event->DrivenSkillId)
	{
		SkillDeadInstances.Add(DeadInstance);
	}
	else
	{
		if (PrepareDeadUnitMomentInstances(Event->UnitIds))
		{
			DeadInstance->SetSkipCamera(true);
		}
		DeadInstance->Prepare();

		PrepareDeadUnitSpawnInstances(Event->UnitIds);
		if (!SkillSpawnInstances.Num())
		{
			SpawnInstance = nullptr;
		}
	}

	if (SkillDrivenInfo.SkillId != CCSkillIdInvalid && SkillDrivenInfo.SkillId == Event->DrivenSkillId)
	{
		SkillDrivenInfo.AddInstance(DeadInstance);
	}
}

FMomentInstancesInfo* ACombatPresenter::GetMomentInstancesInfo(EMoment InMoment)
{
	if (InMoment == EMoment::AtBuffMaxOverlap)
	{
		return LastMomentInstancesInfo;
	}

	switch (InMoment)
	{
		case EMoment::AtBuffExpire:
		case EMoment::AtTurnBegin:
		case EMoment::AtFirstSpawn:
		case EMoment::AtSpawn:
			return &OnTurnBeginMomentInstancesInfo;
		case EMoment::AtBeaten:
		case EMoment::AtDodge:
		case EMoment::PostDie:
			return &OnAttackedMomentInstancesInfo;
		case EMoment::AtAttack:
		case EMoment::AtKill:
			return &OnAttackMomentInstancesInfo;
		default:
			return nullptr;
	}
}

void ACombatPresenter::InitMomentInstancesInfo()
{
	UCPMomentSkillInstance* MomentSkillInstance = Cast<UCPMomentSkillInstance>(SkillInstance);
	if (!MomentSkillInstance)
	{
		return;
	}

	EMoment CurSkillMoment = MomentSkillInstance->GetMoment();
	FMomentInstancesInfo* MomentInstancesInfo = GetMomentInstancesInfo(CurSkillMoment);
	if (!MomentInstancesInfo)
	{
		return;
	}

	InitOrAddMomentLabelInfo(*MomentInstancesInfo, CurSkillMoment, MomentSkillInstance->GetSkillOwnerUnitId());
	MomentInstancesInfo->MomentSkillInstances.Add(MomentSkillInstance);

	LastMomentInstancesInfo = MomentInstancesInfo;
}

void ACombatPresenter::InitOrAddMomentLabelInfo(FMomentInstancesInfo& InInfo, EMoment InMoment, FCCUnitId InUnitId)
{
	if (!InInfo.LabelInstance)
	{
		InInfo.LabelInstance = CreateInstance<UCPUnitApplyEffectLabelInstance>();
	}
	check(InInfo.LabelInstance);
	InInfo.LabelInstance->AddLabelInfo(InMoment, InUnitId);
}

void ACombatPresenter::InitBuffInstance(EMoment SkillMoment)
{
	SkillBuffInstance = CreateInstance<UCPBuffInstance>();
	check(SkillBuffInstance);

	SkillBuffInstance->SetSourceUnitId(SkillInstance->GetSkillOwnerUnitId());

	FMomentInstancesInfo* MomentInstancesInfo = GetMomentInstancesInfo(SkillMoment);
	if (MomentInstancesInfo)
	{
		InitOrAddMomentLabelInfo(*MomentInstancesInfo, SkillMoment, SkillInstance->GetSkillOwnerUnitId());
		MomentInstancesInfo->UnitNoticeInstances.Add(SkillBuffInstance);
	}
	else
	{
		SkillUnitNoticeInstances.Add(SkillBuffInstance);
		SkillDrivenInfo.AddInstance(SkillBuffInstance);
	}
}

void ACombatPresenter::OnCreateBuff(const UCCCreateBuffEvent* Event)
{
	if (Event->IsPassive)
	{
		if (SpawnInstance)
		{
			SpawnInstance->AddPassiveBuffEvent(Event);
		}
		else
		{
			UCPBuffInstance* PassiveBuffInstance = CreateInstance<UCPBuffInstance>();
			check(PassiveBuffInstance);
			PassiveBuffInstance->SetSkipEffect(true, true, false);
			PassiveBuffInstance->AddBuffEvent(Event);
			PassiveBuffInstance->Prepare();
		}
		return;
	}

	if (SkillInstance)
	{
		if (SkillInstance->ShouldSkipBuffEffect())
		{
			return;
		}

		if (!SkillBuffInstance)
		{
			InitBuffInstance(SkillInstance->GetMoment());
			SkillBuffInstance->SetSkipEffectFromSkill(SkillInstance->GetSkillCategory());
		}
		SkillBuffInstance->AddBuffEvent(Event);
		return;
	}
	
	for (UCPSpawnInstance* SubPartySpawnInstance : SubPartySpawnInstances)
	{
		if (SubPartySpawnInstance->GetUnitId() == Event->TargetUnitId)
		{
			SubPartySpawnInstance->AddInheritedBuffEvent(Event);
			return;
		}
	}

	bool bUnitBarEffectOnly = Event->BornCategory == ESkillCategory::Versa ||
		Event->BornCategory == ESkillCategory::Equipment;

	UCPBuffInstance* BuffInstance = CreateInstance<UCPBuffInstance>();
	check(BuffInstance);
	BuffInstance->SetSkipEffect(bUnitBarEffectOnly, bUnitBarEffectOnly, false);
	BuffInstance->AddBuffEvent(Event);
	BuffInstance->Prepare();
}

void ACombatPresenter::OnRemoveBuff(const UCCRemoveBuffEvent* Event)
{
	if (SkillInstance)
	{
		if (SkillInstance->ShouldSkipBuffEffect())
		{
			return;
		}

		if (!SkillBuffInstance)
		{
			InitBuffInstance(SkillInstance->GetMoment());
			SkillBuffInstance->SetSkipEffectFromSkill(SkillInstance->GetSkillCategory());
		}
		SkillBuffInstance->AddBuffEvent(Event);
	}
	else
	{
		UCPBuffInstance* BuffInstance = CreateInstance<UCPBuffInstance>();
		check(BuffInstance);

		bool bRemoveSkillReason = Event->Reason == ERemoveBuffReason::RemoveSkill;
		BuffInstance->SetSkipEffect(!bRemoveSkillReason, !bRemoveSkillReason, false);

		BuffInstance->AddBuffEvent(Event);
		BuffInstance->Prepare();
	}
}

void ACombatPresenter::OnRemoveBuffFailed(const UCCRemoveBuffFailedEvent* Event)
{
	if (SkillInstance)
	{
		if (SkillInstance->ShouldSkipBuffEffect())
		{
			return;
		}

		if (!SkillBuffInstance)
		{
			InitBuffInstance(SkillInstance->GetMoment());
			SkillBuffInstance->SetSkipEffectFromSkill(SkillInstance->GetSkillCategory());
		}
		SkillBuffInstance->AddBuffEvent(Event);
	}
	else
	{
		UCPBuffInstance* BuffInstance = CreateInstance<UCPBuffInstance>();
		check(BuffInstance);

		BuffInstance->AddBuffEvent(Event);
		BuffInstance->Prepare();
	}
}

void ACombatPresenter::OnImmuneBuff(const UCCImmuneBuffEvent* Event)
{
	if (SkillInstance)
	{
		if (SkillInstance->ShouldSkipBuffEffect())
		{
			return;
		}

		if (!SkillBuffInstance)
		{
			InitBuffInstance(SkillInstance->GetMoment());
			SkillBuffInstance->SetSkipEffectFromSkill(SkillInstance->GetSkillCategory());
		}
		SkillBuffInstance->AddBuffEvent(Event);
	}
	else
	{
		UCPBuffInstance* BuffInstance = CreateInstance<UCPBuffInstance>();
		check(BuffInstance);

		BuffInstance->AddBuffEvent(Event);
		BuffInstance->Prepare();
	}
}

void ACombatPresenter::OnDamageBuff(const UCCDamageBuffEvent* Event)
{
	Q6JsonLog(Verbose, "OnDamageBuff", Q6KV("target count: ", Event->EventNum()));

	UCPDamageBuffInstance* DamageBuffInstance = CreateInstance<UCPDamageBuffInstance>(Event);
	DamageBuffInstance->Prepare();
}

void ACombatPresenter::OnHealBuff(const UCCHealBuffEvent* Event)
{
	Q6JsonLog(Verbose, "OnHealBuff", Q6KV("target count: ", Event->EventNum()));

	UCPHealBuffInstance* HealBuffInstance = CreateInstance<UCPHealBuffInstance>(Event);
	HealBuffInstance->Prepare();
}

bool ACombatPresenter::TargetMonsterIfCurrentIsDead()
{
	AUnit* TargetUnit = FindUnit(TargetedUnitId);
	if (TargetUnit && !TargetUnit->IsDead())
	{
		return false;
	}

	for (auto SlotOrder : ALLY_AUTO_TARGET_SLOT_ORDER)
	{
		const FUnitState& MonsterState = GetMonsterStateBySlot(SlotOrder);
		if (MonsterState.UnitId == CCUnitIdInvalid)
		{
			continue;
		}

		if (MonsterState.Health <= 0)
		{
			continue;
		}

		GetCheckedCombatCube(this)->SelectTarget(MonsterState.UnitId);
		return true;
	}

	return false;
}

void ACombatPresenter::SetDecalVisible(bool bVisible)
{
	FCCUnitId CurrentTargetUnitId = TargetedUnitId;
	ForEachUnit([bVisible, CurrentTargetUnitId](AUnit& InUnit)
	{
		bool bUnitVisible = bVisible ? InUnit.GetUnitId() == CurrentTargetUnitId : false;
		InUnit.SetShadowDecalMode(InUnit.GetOverrideFaction(), bUnitVisible);
	});
}

void ACombatPresenter::OnSelectTarget(const UCCTargetSelectedEvent* Event)
{
 	if (TargetedUnitId == Event->UnitId)
 	{
 		return;
 	}

	// this unit id is combatcube's player targeted id
	RestoredUnitId = Event->UnitId;

	// if show provoked enemy bar, select target by provoked only
	if (GetCheckedCombatHUD(this)->IsShowProvokedEnemyBar())
	{
		return;
	}

	// by event
	SelectTarget(Event->UnitId, true);
}

void ACombatPresenter::OnSkillFailed(const UCCSkillFailedEvent* Event)
{
	if (Event->IsBlocking)
	{
		UCPSkillFailedInstance* Instance = CreateInstance<UCPSkillFailedInstance>(Event);
		Instance->Prepare();
	}
	else
	{
		GetCheckedCombatHUD(this)->OnSkillFailed(Event);
	}
}

void ACombatPresenter::OnAttackPass(const UCCAttackPassEvent* Event)
{
	PrepareMomentInstances(OnAttackedMomentInstancesInfo, false);
	PrepareMomentInstances(OnAttackMomentInstancesInfo, false);
	LastMomentInstancesInfo = nullptr;

	ensure(!SkillSpawnInstances.Num());

	UCPAttackPassInstance* AttackPassInstance = CreateInstance<UCPAttackPassInstance>(Event);
	AttackPassInstance->Prepare();
}

void ACombatPresenter::OnSkillUsed(const UCCSkillUsedEvent* Event)
{
	Q6JsonLog(Verbose, "OnSkillUsed", Q6KV("SkillType: ", Event->SkillType));

	ensure(SkillInstance == nullptr);
	SkillInstance = CreateSkillInstance(Event);
	SkillDrivenInfo.Init(Event->SkillId, Event->SkillCategory, Event->UnitId);

	if (SkillInstance->GetSkillCategory() == ESkillCategory::Moment)
	{
		InitMomentInstancesInfo();
	}

	AUnit* Unit = FindUnit(Event->UnitId);
	if (Unit)
	{
		Unit->IncreaseSkillUsingCount(Event->SkillId);

		if (Unit->GetOverrideFaction() == ECCFaction::Ally)
		{
			LastSkillUsedUnitId = Event->UnitId;
		}
	}
}

void ACombatPresenter::OnSkillEffect(const UCCSkillEffectEvent* Event)
{
	SkillInstance->AddEffectEvent(Event);
}

static bool _HasMomentHitEvents(TArray<UCPMomentSkillInstance*>& InMomentSkillInstances)
{
	for (UCPMomentSkillInstance* MomentSkillInstance : InMomentSkillInstances)
	{
		if (MomentSkillInstance->HasHitEvents())
		{
			return true;
		}
	}

	return false;
}

static void _SetMomentLabelSingleCamera(FMomentInstancesInfo& InMomentInstancesInfo)
{
	if (!InMomentInstancesInfo.LabelInstance)
	{
		return;
	}

	FCCUnitId TargetUnitId;
	if (!InMomentInstancesInfo.LabelInstance->IsSingleTargetCamera(TargetUnitId))
	{
		return;
	}

	for (UCPUnitNoticeInstance* UnitNoticeInstance : InMomentInstancesInfo.UnitNoticeInstances)
	{
		if (!UnitNoticeInstance->GetTargetUnitIds().Num())
		{
			continue;
		}

		if (UnitNoticeInstance->GetTargetUnitIds().Num() != 1)
		{
			return;
		}

		if (UnitNoticeInstance->GetTargetUnitIds()[0] != TargetUnitId)
		{
			return;
		}
	}

	InMomentInstancesInfo.LabelInstance->SetSingleTargetCamera(true);
}

bool ACombatPresenter::PrepareMomentInstances(FMomentInstancesInfo& InMomentInstancesInfo, bool bSkipAction)
{
	if (!InMomentInstancesInfo.LabelInstance)
	{
		return false;
	}

	bool bHasHitAction = _HasMomentHitEvents(InMomentInstancesInfo.MomentSkillInstances);
	if (!bHasHitAction)
	{
		_SetMomentLabelSingleCamera(InMomentInstancesInfo);
	}

	PrepareUnitApplyEffectLabelInstance(InMomentInstancesInfo.LabelInstance);
	PrepareUnitNoticeInstances(InMomentInstancesInfo.UnitNoticeInstances, (bSkipAction || bHasHitAction), false);
	PrepareMomentSkillInstances(InMomentInstancesInfo.MomentSkillInstances, (bSkipAction || !bHasHitAction));

	return true;
}

void ACombatPresenter::PrepareUnitApplyEffectLabelInstance(UCPUnitApplyEffectLabelInstance*& UnitApplyEffectLabelInstance)
{
	if (!UnitApplyEffectLabelInstance)
	{
		return;
	}

	UnitApplyEffectLabelInstance->Prepare();
	UnitApplyEffectLabelInstance = nullptr;
}

void ACombatPresenter::PrepareUnitNoticeInstances(TArray<UCPUnitNoticeInstance *>& UnitNoticeInstances, bool bSkipAction, bool bSkillDriven /* = false */)
{
	if (!UnitNoticeInstances.Num())
	{
		return;
	}

	for (int32 i = 0; i < UnitNoticeInstances.Num(); ++i)
	{
		UCPUnitNoticeInstance* CurInstance = UnitNoticeInstances[i];

		if (UnitNoticeInstances.IsValidIndex(i + 1))
		{
			CurInstance->SetSkipAction(true);
		}
		else
		{
			CurInstance->SetSkipAction(bSkipAction);
		}

		bool bSkipCamera = bSkillDriven ? SkillInstance->GetSkillCategory() == ESkillCategory::RaidTurnBegin : true;
		CurInstance->SetSkipCamera(bSkipCamera);

		if (!CurInstance->Prepare() && bSkillDriven)
		{
			SkillDrivenInfo.Instances.Remove(CurInstance);
		}
	}

	for (UCPUnitNoticeInstance* PreparedInstance : UnitNoticeInstances)
	{
		if (PreparedInstance->GetResetCamera())
		{
			UnitNoticeInstances.Last()->SetResetCamera(true);
			break;
		}
	}

	UnitNoticeInstances.Empty();
}

void ACombatPresenter::PrepareMomentSkillInstances(TArray<UCPMomentSkillInstance *>& MomentSkillInstances, bool bSkipAction)
{
	if (!MomentSkillInstances.Num())
	{
		return;
	}

	for (int32 i = 0; i < MomentSkillInstances.Num(); ++i)
	{
		if (MomentSkillInstances.IsValidIndex(i + 1))
		{
			MomentSkillInstances[i]->SetSkipAction(true);
		}
		else
		{
			MomentSkillInstances[i]->SetSkipAction(bSkipAction);
		}
		MomentSkillInstances[i]->Prepare();
	}

	MomentSkillInstances.Empty();
}

bool ACombatPresenter::PrepareDeadUnitMomentInstances(const TArray<FCCUnitId>& DeadUnitIds)
{
	FMomentInstancesInfo DeadUnitMomentInstances;
	AddDeadUnitApplyEffectLabelInstance(DeadUnitIds, DeadUnitMomentInstances);
	AddDeadUnitNoticeInstances(DeadUnitIds, DeadUnitMomentInstances);
	AddDeadUnitMomentSkillInstances(DeadUnitIds, DeadUnitMomentInstances);

	return PrepareMomentInstances(DeadUnitMomentInstances, true);
}

static void _AddUnitApplyEffectLabelInstance(const TArray<FCCUnitId>& InUnitIds, UCPUnitApplyEffectLabelInstance* InLabelInstance, UCPUnitApplyEffectLabelInstance* OutLabelInstance)
{
	if (!InLabelInstance)
	{
		return;
	}

	for (FCPMomentLabelInfo& LabelInfo : InLabelInstance->GetLabelInfos())
	{
		for (const FCCUnitId& UnitId : InUnitIds)
		{
			if (LabelInfo.UnitIds.Contains(UnitId))
			{
				OutLabelInstance->AddLabelInfo(LabelInfo.Moment, UnitId);
				LabelInfo.UnitIds.Remove(UnitId);
			}
		}
	}
}

void ACombatPresenter::AddDeadUnitApplyEffectLabelInstance(const TArray<FCCUnitId>& DeadUnitIds, FMomentInstancesInfo& InOutMomentInstances)
{
	if (!DeadUnitIds.Num())
	{
		return;
	}

	if (!OnAttackedMomentInstancesInfo.LabelInstance && !OnAttackMomentInstancesInfo.LabelInstance)
	{
		return;
	}

	UCPUnitApplyEffectLabelInstance* DeadUnitLabelInstance = CreateInstance<UCPUnitApplyEffectLabelInstance>();
	_AddUnitApplyEffectLabelInstance(DeadUnitIds, OnAttackedMomentInstancesInfo.LabelInstance, DeadUnitLabelInstance);
	_AddUnitApplyEffectLabelInstance(DeadUnitIds, OnAttackMomentInstancesInfo.LabelInstance, DeadUnitLabelInstance);

	InOutMomentInstances.LabelInstance = DeadUnitLabelInstance;
}

static void _AddUnitNoticeInstances(const TArray<FCCUnitId>& InUnitIds, TArray<UCPUnitNoticeInstance*>& InUnitNoticeInstances, TArray<UCPUnitNoticeInstance*>& OutUnitNoticeInstances)
{
	int32 Index = 0;
	while (InUnitNoticeInstances.IsValidIndex(Index))
	{
		if (InUnitIds.Contains(InUnitNoticeInstances[Index]->GetSourceUnitId()))
		{
			OutUnitNoticeInstances.Add(InUnitNoticeInstances[Index]);
			InUnitNoticeInstances.RemoveAt(Index);
		}
		else
		{
			++Index;
		}
	}
}

void ACombatPresenter::AddDeadUnitNoticeInstances(const TArray<FCCUnitId>& DeadUnitIds, FMomentInstancesInfo& InOutMomentInstances)
{
	if (!DeadUnitIds.Num())
	{
		return;
	}

	TArray<UCPUnitNoticeInstance*> DeadUnitNoticeInstances;
	_AddUnitNoticeInstances(DeadUnitIds, OnAttackedMomentInstancesInfo.UnitNoticeInstances, DeadUnitNoticeInstances);
	_AddUnitNoticeInstances(DeadUnitIds, OnAttackMomentInstancesInfo.UnitNoticeInstances, DeadUnitNoticeInstances);

	InOutMomentInstances.UnitNoticeInstances = DeadUnitNoticeInstances;
}

static void _AddUnitMomentSkillInstances(const TArray<FCCUnitId>& InUnitIds, TArray<UCPMomentSkillInstance*>& InMomentSkillInstances, TArray<UCPMomentSkillInstance*>& OutMomentSkillInstances)
{
	int32 Index = 0;
	while (InMomentSkillInstances.IsValidIndex(Index))
	{
		if (InUnitIds.Contains(InMomentSkillInstances[Index]->GetSkillOwnerUnitId()))
		{
			OutMomentSkillInstances.Add(InMomentSkillInstances[Index]);
			InMomentSkillInstances.RemoveAt(Index);
		}
		else
		{
			++Index;
		}
	}
}

void ACombatPresenter::AddDeadUnitMomentSkillInstances(const TArray<FCCUnitId>& DeadUnitIds, FMomentInstancesInfo& InOutMomentInstances)
{
	if (!DeadUnitIds.Num())
	{
		return;
	}

	TArray<UCPMomentSkillInstance*> DeadUnitMomentSkillInstances;
	_AddUnitMomentSkillInstances(DeadUnitIds, OnAttackedMomentInstancesInfo.MomentSkillInstances, DeadUnitMomentSkillInstances);
	_AddUnitMomentSkillInstances(DeadUnitIds, OnAttackMomentInstancesInfo.MomentSkillInstances, DeadUnitMomentSkillInstances);

	InOutMomentInstances.MomentSkillInstances = DeadUnitMomentSkillInstances;
}

void ACombatPresenter::PrepareDeadUnitSpawnInstances(const TArray<FCCUnitId>& DeadUnitIds)
{
	if (!DeadUnitIds.Num())
	{
		return;
	}

	TArray<UCPSpawnInstance*> DeadUnitSpawnInstances;
	for (int32 i = SkillSpawnInstances.Num() - 1; i >= 0; --i)
	{
		FCCUnitId SpawnSourceUnitId = SkillSpawnInstances[i]->GetSourceUnitId();
		for (FCCUnitId DeadUnitId : DeadUnitIds)
		{
			if (DeadUnitId == SpawnSourceUnitId)
			{
				DeadUnitSpawnInstances.Add(SkillSpawnInstances[i]);
				SkillSpawnInstances.RemoveAt(i);
			}
		}
	}

	for (UCPSpawnInstance* DeadUnitSpawnInstance : DeadUnitSpawnInstances)
	{
		DeadUnitSpawnInstance->Prepare();
	}
}

void ACombatPresenter::OnSkillEnd(const UCCSkillEndEvent* Event)
{
	Q6JsonLog(Verbose, "OnSkillEnd", Q6KV("SkillType: ", SkillInstance->GetSkillType()));

	SkillInstance->SetHasSkillDrivenEffect(!SkillDrivenInfo.IsEmpty());
	SkillInstance->SetHasDeadUnit(HasEventQueued(ECCEventType::UnitDead, ECCEventType::SkillUsed));

	if (SkillInstance->GetSkillCategory() != ESkillCategory::Moment)
	{
		SkillInstance->Prepare();
	}

	PrepareUnitNoticeInstances(SkillUnitNoticeInstances, false, true);

	if (SkillDeadInstances.Num())
	{
		for (UCPDeadInstance* SkillDeadInstance : SkillDeadInstances)
		{
			if (PrepareDeadUnitMomentInstances(SkillDeadInstance->GetUnitIds()))
			{
				SkillDeadInstance->SetSkipCamera(true);
			}
			SkillDeadInstance->Prepare();
		}
		SkillDeadInstances.Empty();
	}

	if (!Event->IsSkillOwnerDead)
	{
		for (UCPSpawnInstance* SkillSpawnInstance : SkillSpawnInstances)
		{
			SkillSpawnInstance->Prepare();
		}
		SkillSpawnInstances.Empty();
	}

	SkillInstance = nullptr;
	SkillBuffInstance = nullptr;
	PointInstance = nullptr;
	PointVaryInstance = nullptr;
}

void ACombatPresenter::OnSkillDrivenEffectEnd()
{
	if (SkillDrivenInfo.SkillCategory == ESkillCategory::Versa ||
		SkillDrivenInfo.SkillCategory == ESkillCategory::RaidTurnBegin)
	{
		return;
	}

	// dead instance added after SkillEnd so needing double check
	if (!SkillDrivenInfo.IsEmpty())
	{
		return;
	}

	if (SkillDrivenInfo.ShouldRestoreTurnPrepareUnitsOnEnd())
	{
		RestoreTurnPrepareUnits();
	}

	GetCheckedCombatHUD(this)->OnSkillDrivenEffectEnd();
}

void ACombatPresenter::OnPointVaryUsed(const UCCPointVaryUsedEvent* Event)
{
	PointVaryInstance = CreateInstance<UCPPointVaryInstance>(Event);
	check(PointVaryInstance);
}

void ACombatPresenter::OnPointVaryStateChanged(const UCCPointVaryStateChangedEvent* Event)
{
	PointVaryInstance->SetStateChanged();
}

void ACombatPresenter::OnPointVaryEnd(const UCCPointVaryEndEvent* Event)
{
	if (SkillInstance)
	{
		PointVaryInstance->SetSourceUnitId(SkillInstance->GetSkillOwnerUnitId());

		FMomentInstancesInfo* MomentInstancesInfo = GetMomentInstancesInfo(SkillInstance->GetMoment());
		if (MomentInstancesInfo)
		{
			InitOrAddMomentLabelInfo(*MomentInstancesInfo, SkillInstance->GetMoment(), SkillInstance->GetSkillOwnerUnitId());
			MomentInstancesInfo->UnitNoticeInstances.Insert(PointVaryInstance, 0);
		}
		else
		{
			SkillUnitNoticeInstances.Insert(PointVaryInstance, 0);
			SkillDrivenInfo.AddInstance(PointVaryInstance);
		}
	}
	else
	{
		PointVaryInstance->Prepare();
	}

	// keep it null here for next point events to find its instance well
	PointVaryInstance = nullptr;
}

void ACombatPresenter::OnUpdateAttributes(const UCCUpdateAttributesEvent* Event)
{
	if (PointVaryInstance)
	{
		PointVaryInstance->AddUpdateAttributesEvent(Event);
	}

	AUnit* Unit = FindUnit(Event->UnitId);
	if (!Unit)
	{
		return;
	}

	Unit->UpdateUnitAttributes(Event->UnitAttributeType, Event->AddedValue);
}

void ACombatPresenter::InitPointInstance(EMoment SkillMoment)
{
	PointInstance = CreateInstance<UCPPointInstance>();
	check(PointInstance);

	PointInstance->SetSourceUnitId(SkillInstance->GetSkillOwnerUnitId());

	FMomentInstancesInfo* MomentInstancesInfo = GetMomentInstancesInfo(SkillMoment);
	if (MomentInstancesInfo)
	{
		InitOrAddMomentLabelInfo(*MomentInstancesInfo, SkillMoment, SkillInstance->GetSkillOwnerUnitId());
		MomentInstancesInfo->UnitNoticeInstances.Add(PointInstance);
	}
	else
	{
		SkillUnitNoticeInstances.Add(PointInstance);
		SkillDrivenInfo.AddInstance(PointInstance);
	}
}

static bool _ShouldCreatePointInstance(EHealthChangeReason InReason)
{
	if (InReason != EHealthChangeReason::ImmediateKill)
	{
		return false;
	}

	return true;
}

void ACombatPresenter::OnHealthChanged(const UCCUnitHealthChangedEvent* Event)
{
	AUnit* Unit = FindUnit(Event->UnitId);
	if (!Unit)
	{
		return;
	}
	Unit->SetHealth(Event->NewHealth);

	if (PointVaryInstance)
	{
		PointVaryInstance->AddHealthEvent(Event);
	}
	else
	{
		if (SkillInstance && SkillInstance->GetSkillId() == Event->SkillId && _ShouldCreatePointInstance(Event->Reason))
		{
			if (!PointInstance)
			{
				InitPointInstance(EMoment::None);
			}
			PointInstance->AddHealthEvent(Event);
		}
		else
		{
			UCPHealthChangedInstance* HealthChangedInstance = CreateInstance<UCPHealthChangedInstance>(Event);
			HealthChangedInstance->Prepare();
		}
	}
}

static bool _ShouldCreatePointInstance(EPointChangeReason InReason, ESkillCategory InSkillCategory)
{
	if (InReason != EPointChangeReason::SkillEffect)
	{
		return false;
	}

	switch (InSkillCategory)
	{
		case ESkillCategory::TurnBegin:
		case ESkillCategory::Moment:
		case ESkillCategory::Pet:
			return true;
		default:
			return false;
	}
}

void ACombatPresenter::OnUAChanged(const UCCUnitUAChangedEvent* Event)
{
	AUnit* Unit = FindUnit(Event->UnitId);
	if (!Unit)
	{
		return;
	}
	Unit->SetUA(Event->NewUA);

	if (PointVaryInstance)
	{
		PointVaryInstance->AddUAEvent(Event);
	}
	else if (SkillInstance)
	{
		if (_ShouldCreatePointInstance(Event->Reason, SkillInstance->GetSkillCategory()))
		{
			if (!PointInstance)
			{
				InitPointInstance(SkillInstance->GetMoment());
			}
			PointInstance->AddUAEvent(Event);
		}
		else
		{
			SkillInstance->AddUAEvent(Event);
		}
	}
	else
	{
		GetCheckedCombatHUD(this)->OnUAChanged(Event);
	}
}

void ACombatPresenter::OnSAChanged(const UCCUnitSAChangedEvent* Event)
{
	AUnit* Unit = FindUnit(Event->UnitId);
	if (!Unit)
	{
		return;
	}
	Unit->SetSA(Event->NewSA);

	if (PointVaryInstance)
	{
		PointVaryInstance->AddSAEvent(Event);
	}
	else if (SkillInstance)
	{
		if (_ShouldCreatePointInstance(Event->Reason, SkillInstance->GetSkillCategory()))
		{
			if (!PointInstance)
			{
				InitPointInstance(SkillInstance->GetMoment());
			}
			PointInstance->AddSAEvent(Event);
		}
		else
		{
			SkillInstance->AddSAEvent(Event);
		}
	}
	else
	{
		GetCheckedCombatHUD(this)->OnSAChanged(Event);
	}
}

static bool _ShouldCreateOverkillPointInstance(EPointChangeReason InReason, ESkillCategory InSkillCategory, int32 InSkillType)
{
	if (!_ShouldCreatePointInstance(InReason, InSkillCategory))
	{
		return false;
	}

	// because overkill value has been summed up
	// check whether actual skill has overkill effect
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(InSkillType);
	TArray<const FCMSSkillEffectRow*> SkillEffects = SkillRow.GetSkillEffect();

	for (const FCMSSkillEffectRow* EffectRow : SkillEffects)
	{
		if (EffectRow->EffectCategory == EEffectCategory::AddOverKillPoint)
		{
			return true;
		}
	}

	return false;
}

void ACombatPresenter::OnOverKillChanged(const UCCUnitOverKillChangedEvent* Event)
{
	AUnit* Unit = FindUnit(Event->UnitId);
	if (!Unit)
	{
		return;
	}
	Unit->SetOverKill(Event->NewOverKill);

	if (PointVaryInstance)
	{
		PointVaryInstance->AddOverKillEvent(Event);
	}
	else if (SkillInstance)
	{
		if (_ShouldCreateOverkillPointInstance(Event->Reason, SkillInstance->GetSkillCategory(), SkillInstance->GetSkillType()))
		{
			if (!PointInstance)
			{
				InitPointInstance(SkillInstance->GetMoment());
			}
			PointInstance->AddOverKillEvent(Event);
		}
		else if (Event->AddedOverKill)
		{
			SkillInstance->AddOverKillEvent(Event);
		}
	}
	else if (Event->AddedOverKill)
	{
		GetCheckedCombatHUD(this)->OnOverKillChanged(Event);
	}
}

void ACombatPresenter::InitSetSkillTimeInstance(const UCCSetSkillTimeEvent* InSetSkillTimeEvent)
{
	UCPSetSkillTimeInstance* SetSkillTimeInstance = CreateInstance<UCPSetSkillTimeInstance>();
	check(SetSkillTimeInstance);

	SetSkillTimeInstance->AddSetSkillTimeEvent(InSetSkillTimeEvent);

	SkillUnitNoticeInstances.Add(SetSkillTimeInstance);
	SkillDrivenInfo.AddInstance(SetSkillTimeInstance);
}

void ACombatPresenter::OnSetSkillCooldown(const UCCSetSkillTimeEvent* Event)
{
	if (IsMaster(Event->UnitId))
	{
		// Master skill

		for (FMasterState& Master : Masters)
		{
			FCCSkillId SkillId = Event->SkillId;

			for (FSkillState& ArtifactSkill : Master.Artifacts)
			{
				if (ArtifactSkill.SkillId != SkillId)
				{
					continue;
				}

				ArtifactSkill.Cooldown = Event->Cooldown;
				ArtifactSkill.WaitDown = Event->Waitdown;
			}

			for (FSkillState& PetSkill : Master.Pets)
			{
				if (PetSkill.SkillId != SkillId)
				{
					continue;
				}

				PetSkill.Cooldown = Event->Cooldown;
				PetSkill.WaitDown = Event->Waitdown;
			}
		}
	}
	else
	{
		AUnit* Unit = FindUnit(Event->UnitId);
		if (Unit)
		{
			Unit->SetSkillCooldown(Event->SkillId, Event->Cooldown);
			Unit->SetSkillWaitdown(Event->SkillId, Event->Waitdown);
		}
	}

	GetCheckedCombatHUD(this)->OnSetSkillCooldown(Event);

	if ((Event->SetSkillTimeType == ESetSkillTimeType::ChargeDown || Event->SetSkillTimeType == ESetSkillTimeType::Cooldown)
		&& Event->TimeDiff != 0)
	{
		InitSetSkillTimeInstance(Event);
	}
}

void ACombatPresenter::OnSetCheatSkillCooldown(const UCCSetCheatSkillCooldownEvent* Event)
{
	AUnit* Unit = FindUnit(Event->UnitId);
	if (Unit)
	{
		Unit->SetSkillCooldown(Event->SkillId, Event->Cooldown);
	}

	GetCheckedCombatHUD(this)->OnSetCheatSkillCooldown(Event);
}

void ACombatPresenter::OnRaidTurnSkillEffect(const UCCRaidTurnSkillEffectEvent* Event)
{
	UCPRaidTurnSkillInstance* Instance = CreateInstance<UCPRaidTurnSkillInstance>(Event);
	Instance->Prepare();
}

void ACombatPresenter::OnEnemyAttackPass(const UCCEnemyAttackPassEvent* Event)
{
	UCPEnemyAttackPassInstance* Instance = CreateInstance<UCPEnemyAttackPassInstance>(Event);
	Instance->Prepare();
}

static bool _IsAllyAnimRelaxedPhase(ECCTurnPhase InTurnPhase)
{
	switch (InTurnPhase)
	{
		case ECCTurnPhase::TurnSkill:
			return true;
		default:
			return false;
	}
}

void ACombatPresenter::SetAllyCharacterUnit(AUnit* InUnit, FCCUnitId InUnitId, FUnitType InUnitType)
{
	for (FCharacterUnitInfo& CharacterUnitInfo : AllyCharacterUnitInfos)
	{
		if (CharacterUnitInfo.UnitType == InUnitType)
		{
			CharacterUnitInfo.UnitId = InUnitId;
			return;
		}
	}
}

AUnit* ACombatPresenter::SpawnUnit(const FCCUnitState &InUnitState, bool bSpawnOutCam, bool bBlockingLoad)
{
	AUnit* NewUnit = nullptr;
	NewUnit = CreateUnit(InUnitState, bSpawnOutCam);

	if (!NewUnit)
	{
		return nullptr;
	}

	bool bIsAllyCharacter = InUnitState.Faction == ECCFaction::Ally && InUnitState.Category == EAttributeCategory::Character;
	if (bIsAllyCharacter)
	{
		SetAllyCharacterUnit(NewUnit, InUnitState.UnitId, InUnitState.UnitType);
	}

	FUnitState UnitState;
	UCombatCubeStateUtil::ConvertCCUnitStateToUnitState(InUnitState, &UnitState);

	bool bAnimRelaxed = UnitState.Faction == ECCFaction::Ally && _IsAllyAnimRelaxedPhase(PresentTurnPhase);
	NewUnit->InitFromUnitState(UnitState, bAnimRelaxed, bBlockingLoad);
	NewUnit->SetActorHiddenInGame(NewUnit->IsDead());

	int32 UnitIndex = InUnitState.UnitId.X;
	if (SpawnedUnits.IsValidIndex(UnitIndex))
	{
		SpawnedUnits[UnitIndex] = NewUnit;
		SpawnedUnitIds.Add(InUnitState.UnitId);
	}

	for (const FSkillState& SkillState : UnitState.TurnBegins)
	{
		NewUnit->SetSkillCooldown(SkillState.SkillId, FMath::Max(SkillState.Cooldown, 0));
	}

	for (const FSkillState& SkillState : UnitState.Ultimates)
	{
		NewUnit->SetSkillWaitdown(SkillState.SkillId, FMath::Max(SkillState.WaitDown, 0));
	}

	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		NewUnit->SetBuffDuration(BuffState.BuffType, FMath::Max(BuffState.Duration, 0));
	}

	if (AutomationHelper)
	{
		AutomationHelper->OnSpawnUnit(InUnitState);
	}

	if (InUnitState.Faction == ECCFaction::Enemy)
	{
		SetInvisibleDropBox(NewUnit);
	}

	return NewUnit;
}

AUnit* ACombatPresenter::CreateUnit(const FCCUnitState& UnitState, bool bSpawnOutCam)
{
	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(UnitState.UnitType));
	switch (CMSUnitRow.MonsterParts)
	{
		case EMonsterParts::Main:
			return CreateMainPartUnit(UnitState);
		case EMonsterParts::Sub:
			return CreateSubPartUnit(UnitState);
		default:
			break;
	}

	// set combatlocator of unit's multiside for spawning on correct transform
	ECombatMultiSide CombatLocatorCombatMultiSide = CombatLocator->GetCurrentCombatMultiSide();
	if (CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(UnitState.CombatMultiSide, CombatLocatorCombatMultiSide) && UnitState.Faction == ECCFaction::Ally)
		{
			CombatLocator = ULevelUtil::FindCombatLocator(GetWorld(), LocatorGroup, Wave, UnitState.CombatMultiSide);
		}
	}

	FTransform BaseTransform = GetWaveTransform(UnitState.Faction, UnitState.Slot);
	FTransform SpawnTransform = bSpawnOutCam ? GetAllyCameraOutTransform(UnitState.Slot) : BaseTransform;

	// restore combat locator
	if (CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CombatLocator->GetCurrentCombatMultiSide(), CombatLocatorCombatMultiSide))
		{
			CombatLocator = ULevelUtil::FindCombatLocator(GetWorld(), LocatorGroup, Wave, CombatLocatorCombatMultiSide);
		}
	}

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AUnit* NewUnit = GetWorld()->SpawnActor<AUnit>(AUnit::StaticClass(), SpawnTransform, SpawnInfo);
	NewUnit->SetBaseTransform(BaseTransform);
	return NewUnit;
}

AUnit* ACombatPresenter::CreateMainPartUnit(const FCCUnitState& UnitState)
{
	FTransform BaseTransform = GetWaveTransform(UnitState.Faction, UnitState.Slot);

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	AMainPartUnit* MainPartUnit = GetWorld()->SpawnActor<AMainPartUnit>(AMainPartUnit::StaticClass(), BaseTransform, SpawnInfo);
	MainPartUnit->SetBaseTransform(BaseTransform);

	for (AUnit* FactionUnit : FindUnitsByFaction(UnitState.Faction))
	{
		ASubPartUnit* SubPartUnit = Cast<ASubPartUnit>(FactionUnit);
		if (SubPartUnit)
		{
			MainPartUnit->AddSubPartUnitId(SubPartUnit->GetUnitId());
			SubPartUnit->SetMainPartUnitId(UnitState.UnitId);
		}
	}

	return MainPartUnit;
}

AUnit* ACombatPresenter::CreateSubPartUnit(const FCCUnitState& UnitState)
{
	FTransform BaseTransform = GetWaveTransform(UnitState.Faction, UnitState.Slot);

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	ASubPartUnit* SubPartUnit = GetWorld()->SpawnActor<ASubPartUnit>(ASubPartUnit::StaticClass(), BaseTransform, SpawnInfo);
	SubPartUnit->SetBaseTransform(BaseTransform);

	for (AUnit* FactionUnit : FindUnitsByFaction(UnitState.Faction))
	{
		AMainPartUnit* MainPartUnit = Cast<AMainPartUnit>(FactionUnit);
		if (MainPartUnit)
		{
			MainPartUnit->AddSubPartUnitId(UnitState.UnitId);
			SubPartUnit->SetMainPartUnitId(MainPartUnit->GetUnitId());
			break;
		}
	}

	return SubPartUnit;
}

APetUnit* ACombatPresenter::SpawnPetUnit()
{
	FTransform SpawnTransform = CombatLocator->GetPetTransform();

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	FPetType PetType = GetPetType();
	if (PetType == PetTypeInvalid)
	{
		return nullptr;
	}

	APetUnit* NewPetUnit = GetWorld()->SpawnActor<APetUnit>(APetUnit::StaticClass(), SpawnTransform, SpawnInfo);
	NewPetUnit->InitPetUnit(PetType, FUnitInitParams(true));

	PetUnit = NewPetUnit;

	return NewPetUnit;
}

FTransform ACombatPresenter::GetWaveTransform(ECCFaction InFaction, int32 Slot) const
{
	if (InFaction == ECCFaction::Ally)
	{
		return CombatLocator->GetAllyTransform(Slot);
	}

	return CombatLocator->GetEnemyTransform(Slot, WaveEnemyNumSlots, bWaveEnemyDefaultPosition);
}

FTransform ACombatPresenter::GetAllyCameraOutTransform(int32 Slot) const
{
	FTransform WaveTransform = CombatLocator->GetAllyTransform(Slot);
	FVector OffsetVec = -WaveTransform.GetRotation().GetNormalized().Vector() * CVarAllyCameraOutDistOffset.GetValueOnGameThread();

	FTransform OutTransform = WaveTransform;
	OutTransform.SetLocation(WaveTransform.GetLocation() + OffsetVec);

	return OutTransform;
}

FTransform ACombatPresenter::GetPetTransform() const
{
	return CombatLocator->GetPetTransform();
}

FVector ACombatPresenter::GetFactionAllTargetLocation(ECCFaction InFaction) const
{
	return CombatLocator->GetAllTargetTransform(InFaction).GetLocation();
}

int32 ACombatPresenter::GetWaveEnemyNumSlots() const
{
	return WaveEnemyNumSlots;
}

bool ACombatPresenter::IsWaveEnemyDefaultPosition() const
{
	return bWaveEnemyDefaultPosition;
}

const FCCCombatSeed& ACombatPresenter::GetCombatSeed() const
{
	return CombatSeed;
}

int32 ACombatPresenter::GetSlotByUnitId(FCCUnitId UnitId)
{
	AUnit* Unit = FindUnit(UnitId);
	if (Unit)
	{
		return Unit->GetUnitState().Slot;
	}

	return CombatCubeConst::Q6_INVALID_SLOT;
}

const FUnitState& ACombatPresenter::GetCharacterStateBySlot(int32 Slot) const
{
	static FUnitState DummyState;

	const FUnitState* UnitStatePtr = &DummyState;

	IsAnyUnit([Slot, &UnitStatePtr](const AUnit& Unit) -> bool
	{
		if (Unit.GetOverrideFaction() != ECCFaction::Ally)
		{
			return false;
		}

		if (Unit.GetUnitState().Slot != Slot)
		{
			return false;
		}

		if (Unit.IsDead())
		{
			UnitStatePtr = &Unit.GetUnitState();
			return false;
		}

		UnitStatePtr = &Unit.GetUnitState();
		return true;
	});

	return *UnitStatePtr;
}

const FUnitState& ACombatPresenter::GetMonsterStateBySlot(int32 Slot) const
{
	static FUnitState DummyState;

	const FUnitState* UnitStatePtr = &DummyState;

	IsAnyUnit([Slot, &UnitStatePtr](const AUnit& Unit) -> bool
	{
		if (Unit.GetOverrideFaction() != ECCFaction::Enemy)
		{
			return false;
		}

		if (Unit.GetUnitState().Slot != Slot)
		{
			return false;
		}

		if (Unit.IsDead())
		{
			UnitStatePtr = &Unit.GetUnitState();
			return false;
		}

		UnitStatePtr = &Unit.GetUnitState();
		return true;
	});

	return *UnitStatePtr;
}

ENatureRelationType ACombatPresenter::GetUnitNatureRelationType(const FCCUnitId& InSourceUnitId, const FCCUnitId& InTargetUnitId) const
{
	const AUnit* SourceUnit = FindUnit(InSourceUnitId);
	const AUnit* TargetUnit = FindUnit(InTargetUnitId);

	if (!SourceUnit || !TargetUnit)
	{
		Q6JsonLogRoze(Warning, "ACombatPresenter::GetNatureRelationType - Invalid Unit",
			Q6KV("SourceUnitId", InSourceUnitId), Q6KV("TargetUnitId", InTargetUnitId));
		return ENatureRelationType::Normal;
	}

	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();

	ENatureType SourceUnitNature = SourceUnit->GetNature();
	ENatureType TargetUnitNature = TargetUnit->GetNature();
	return Formula::GetNatureRelationType(GetCMS(), SourceUnit->GetOverrideFaction(), SourceUnitNature, TargetUnitNature, CombatSeed.SagaType);
}

int32 ACombatPresenter::GetSurvivorsCount(ECCFaction InFaction) const
{
	int32 SurvivorsCount = 0;
	ForEachUnit([InFaction, &SurvivorsCount](const AUnit& InUnit)
	{
		if (InUnit.GetOverrideFaction() == InFaction && !InUnit.IsDead())
		{
			++SurvivorsCount;
		}
	});

	return SurvivorsCount;
}

TArray<const AUnit*> ACombatPresenter::GetSupporters(FCCUnitId SkillUsedUnitId) const
{
	TArray<const AUnit*> Supporters;

	const AUnit* SkillUsedUnit = FindUnit(SkillUsedUnitId);
	if (!SkillUsedUnit)
	{
		return Supporters;
	}

	ECCFaction SkillUsedUnitFaction = SkillUsedUnit->GetOverrideFaction();
	
	ForEachUnit([SkillUsedUnitId, SkillUsedUnitFaction, &Supporters](const AUnit& InUnit)
	{
		if (InUnit.GetUnitId() == SkillUsedUnitId)
		{
			return;
		}

		if (InUnit.GetUnitState().Faction != SkillUsedUnitFaction)
		{
			return;
		}

		if (InUnit.GetUnitState().bSupporter)
		{
			Supporters.Add(&InUnit);
		}
	});

	return Supporters;
}

FPetType ACombatPresenter::GetPetType() const
{
	return CombatSeed.Seed.PetInfo.Type;
}

int32 ACombatPresenter::GetPetSkillIndex(FCCSkillId InSkillId) const
{
	const TArray<FSkillState>& PetSkills = GetAllyMaster().Pets;
	for (int32 i = 0; i < PetSkills.Num(); ++i)
	{
		if (PetSkills[i].SkillId == InSkillId)
		{
			return  i;
		}
	}

	return INDEX_NONE;
}

ECPTurnPhase ACombatPresenter::CCPhaseToCPPhase(ECCTurnPhase InTurnPhase) const
{
	static_assert((int32)ECCTurnPhase::OppAttack == 4, "need more master.");
	static_assert((int32)ECPTurnPhase::OppAttack == 5, "need more master.");

	switch (InTurnPhase)
	{
		case ECCTurnPhase::Prepare:
			return ECPTurnPhase::Prepare;
		case ECCTurnPhase::OppTurnSkill:
			return ECPTurnPhase::OppTurnSkill;
		case ECCTurnPhase::TurnSkill:
			{
				if (bEnemyUltimateReadyPhase)
				{
					return ECPTurnPhase::EnemyUltimateReady;
				}
				if (bSteadyPhase)
				{
					return ECPTurnPhase::Steady;
				}
				return ECPTurnPhase::TurnSkill;
			}
		case ECCTurnPhase::Attack:
			return ECPTurnPhase::Attack;
		case ECCTurnPhase::OppAttack:
			return ECPTurnPhase::OppAttack;
		case ECCTurnPhase::ChangeCombatMultiSide:
			return ECPTurnPhase::ChangeCombatMultiSide;
		default:
			ensure(0);
			break;
	}
	return ECPTurnPhase::Prepare;
}

void ACombatPresenter::ChangeToEnemyUltimateReadyPhase()
{
	bEnemyUltimateReadyPhase = true;
}

void ACombatPresenter::ChangeToTurnSkillPhase()
{
	bEnemyUltimateReadyPhase = false;
	bSteadyPhase = false;

	if (PetUnit)
	{
		PetUnit->ClearRandomIdleAnimTimer();
	}
}

void ACombatPresenter::ChangeToSteadyPhase()
{
	bSteadyPhase = true;

	DropTurnPrepareUnits();

	if (PetUnit)
	{
		PetUnit->SetRandomIdleAnimTimer();
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->ChangeToWaveCamera(ECombatCameraBlendType::NormalBlend);
		PlayerController->CameraWaitingFinishedDelegate.BindUObject(this, &ACombatPresenter::OnCameraBlendingFinished);
	}
}

int32 ACombatPresenter::GetTurnCountForWidget() const
{
	if (CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		return CombatMultiSideTurnCount;
	}

	return TurnCount;
}

int32 ACombatPresenter::GetWaveRowIndex() const
{
	if (CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		return CombatMultiSideWaveRowIndex;
	}

	return GetWaveIndex();
}

void ACombatPresenter::PickTurnPrepareUnit(FCCUnitId InUnitId, bool bInPlaySpawnAnim /* = true */)
{
	ensure(PresentTurnPhase == ECCTurnPhase::TurnSkill);

	if (InUnitId == CCUnitIdInvalid)
	{
		GetCheckedCombatHUD(this)->PickFirstAliveAlly();
		return;
	}

	CGStateMgr->StTurn->PickUnit(InUnitId, bInPlaySpawnAnim);

	if (PetUnit)
	{
		PetUnit->SetActorHiddenInGame(true);
	}

	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->ChangeToPrepareCamera();
	}
}

void ACombatPresenter::DropTurnPrepareUnits()
{
	ensure(PresentTurnPhase == ECCTurnPhase::TurnSkill);

	CGStateMgr->StTurn->DetachAllyUnits();
	GetCheckedCombatHUD(this)->SetAllyTurnSkillPhaseSelectable(false);

	if (PetUnit)
	{
		PetUnit->SetActorHiddenInGame(false);
	}
}

void ACombatPresenter::RestoreTurnPrepareUnits()
{
	ensure(PresentTurnPhase == ECCTurnPhase::TurnSkill);

	// prevent multiple call on skill driven restoring
	if (!SkillDrivenInfo.IsEmpty())
	{
		SkillDrivenInfo.SetRestoreTurnPrepareUnitsOnEnd(true);
		return;
	}

	FCCUnitId RestoreTargetUnitId = CGStateMgr->StTurn->GetRestoreTargetUnitId();
	PickTurnPrepareUnit(RestoreTargetUnitId, false);

	GetCheckedCombatHUD(this)->SetAllyTurnSkillPhaseSelectable(true);
}

//////////////////////////////////////////////////////////////////////////////////
// Wave Sequence

void ACombatPresenter::StartCutScene(int32 Episode, int32 Stage, bool bIntro, const UCCStartWaveEvent* Event)
{
	UCPCutSceneInstance* CutSceneInstance = CreateInstance<UCPCutSceneInstance>();
	ensure(CutSceneInstance);

	CutSceneInstance->SetCutSceneInfo(Episode, Stage, Wave, bIntro);
	CutSceneInstance->SetStartWaveEvent(Event);
	CutSceneInstance->Prepare();
}

void ACombatPresenter::StartWave(const UCCStartWaveEvent* Event)
{
	WaveEnemyNumSlots = Event->WaveEnemyNumSlots;
	CombatLocator = ULevelUtil::FindCombatLocator(GetWorld(), LocatorGroup, Wave, CurrentCombatMultiSide);

	UCPWaveInstance* WaveInstance = CreateInstance<UCPWaveInstance>();
	check(WaveInstance);

	WaveInstance->SetWaveInfo(Wave);
	WaveInstance->SetStartWaveEvent(Event);
	WaveInstance->Prepare();
}

void ACombatPresenter::FinishWave(bool bSkipFinishWaveAnim)
{
	DespawnAllProjectiles();
	DespawnAllDynamicParticles();
	DespawnAllSkeletalMeshes();

	// skip the outro cut scene too
	if (bSkipFinishWaveAnim)
	{
		return;
	}

	// wait the dropbox instance
	if (!CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		if (Wave > 1 && Wave < TotalWaveNum)
		{
			StartCameraFadeOut();
		}
	}
	else
	{
		if (Wave < TotalWaveNum)
		{
			StartCameraFadeOut();
		}
	}

	ACombatPlayerController* PlayerController = Cast<ACombatPlayerController>(GetLocalPlayerController(this));
	if (!PlayerController)
	{
		return;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);
	if (PlayerController->HasWaveSequence(SagaRow.Episode, SagaRow.Stage, Wave, false))
	{
		StartCutScene(SagaRow.Episode, SagaRow.Stage, false);
	}

	GetCheckedCombatHUD(this)->OnFinishWave();
}

//////////////////////////////////////////////////////////////////////////////////
// Projectile

static AProjectile* _SpawnProjectile(UWorld* World, const FTransform& StartTransform, const FProjectileEffectDesc& Desc)
{
	UClass* ProjectileClass = Desc.Projectile.LoadSynchronous();

	if (!ProjectileClass)
	{
		Q6JsonLogObiwan(Warning, "Failed to Find Projectile", Q6KV("Projectile: ", Desc.Projectile.ToString()));
		return nullptr;
	}

	if (!ProjectileClass->IsChildOf(AProjectile::StaticClass()))
	{
		Q6JsonLogObiwan(Warning, "Projectile class is not a child of AProjectile", Q6KV("Projectile: ", Desc.Projectile.ToString()));
		return nullptr;
	}

	AProjectile* Projectile = World->SpawnActorDeferred<AProjectile>(ProjectileClass, StartTransform,
		nullptr, nullptr, ESpawnActorCollisionHandlingMethod::AlwaysSpawn);

	return Projectile;
}

void ACombatPresenter::SpawnProjectile(const FSpawnProjectileParams& Params)
{
	check(SpawnProjectileQueue.IsValid());

	bool bSucceed = SpawnProjectileQueue->Enqueue(FSpawnProjectileParams(Params));

	if (!ensure(bSucceed))
	{
		Q6JsonLogObiwan(Error, "CombatPresenter Projectile queue is full", Q6KV("World", GetWorld()->GetName()));
	}
}

void ACombatPresenter::SpawnProjectileInternal(const FSpawnProjectileParams& Params)
{
	AUnit* SourceUnit(nullptr);
	AUnit* TargetUnit(nullptr);
	FTransform StartTransform;
	FVector TargetLocation;

	if (Params.SourceUnitId != CCUnitIdInvalid)
	{
		SourceUnit = FindUnit(Params.SourceUnitId);
		if (!SourceUnit)
		{
			Q6JsonLogObiwan(Warning, "Failed to spawn projectile. Can't find Source Unit", Q6KV("Source UnitId:", Params.SourceUnitId.X));
			return;
		}

		StartTransform = SourceUnit->GetSocketTransform(Params.Desc.StartSocket);
	}
	else
	{
		StartTransform = Params.SourceTransform;
	}

	if (Params.TargetUnitId != CCUnitIdInvalid)
	{
		TargetUnit = FindUnit(Params.TargetUnitId);
		if (!TargetUnit)
		{
			Q6JsonLogObiwan(Warning, "Failed to spawn projectile. Can't find Target Unit", Q6KV("Source UnitId:", Params.TargetUnitId.X));
			return;
		}

		TargetLocation = TargetUnit->GetSocketTransform(Params.Desc.TargetSocket).GetLocation();
	}
	else
	{
		TargetLocation = Params.TargetLocation;
	}

	// Rotate to target
	const FVector Dir = TargetLocation - StartTransform.GetLocation();
	const FVector DirN = Dir.GetSafeNormal();
	StartTransform.SetRotation(DirN.Rotation().Quaternion());

	AProjectile* Projectile = _SpawnProjectile(GetWorld(), StartTransform, Params.Desc);
	if (Projectile)
	{
		Projectile->SetParticleRotation(Params.Desc.ParticleRotation);
		Projectile->SetSpeed(Params.Desc.Speed);
		Projectile->SetPassThrough(Params.Desc.bPassThrough);
		Projectile->SetSourceUnit(SourceUnit);

		if (TargetUnit)
		{
			Projectile->SetTargetUnit(TargetUnit, Params.Desc.TargetSocket, Params.Desc.HitInfo, Params.HitParticleParam, Params.HitSoundParam);
		}

		Projectile->SetStartLocation(StartTransform.GetLocation());
		Projectile->SetTargetLocation(TargetLocation);

		UGameplayStatics::FinishSpawningActor(Projectile, StartTransform);
	}
}

void ACombatPresenter::UpdateSpawnProjectiles()
{
	int32 NumSpawn = CVarQ6ProjectileSpawnPerTick.GetValueOnGameThread();

	while (!SpawnProjectileQueue->IsEmpty() && NumSpawn > 0)
	{
		FSpawnProjectileParams Params;
		SpawnProjectileQueue->Dequeue(Params);

		SpawnProjectileInternal(Params);

		--NumSpawn;
	}
}

void ACombatPresenter::DespawnAllProjectiles()
{
	for (TActorIterator<AProjectile> It(GetWorld(), AProjectile::StaticClass()); It; ++It)
	{
		AProjectile* Projectile = *It;
		Projectile->Destroy();
	}

	if (SpawnProjectileQueue.IsValid())
	{
		SpawnProjectileQueue->Empty();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// World Particle

void ACombatPresenter::SpawnWorldParticle(const FVector& InLocation, const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam)
{
	UParticleSystem* Particle = ParticleParam.Particle;
	if (!Particle)
	{
		return;
	}

	UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	FVector Offset = ParticleParam.Offset;
	FVector Rotation = ParticleParam.Rotation;
	FVector Scale = ParticleParam.Scale;

	FRotator Rotator(Rotation.Y, Rotation.Z, Rotation.X);
	FTransform LocationToSpawn(Rotator, InLocation + Offset);

	UParticleSystemComponent* PSC = UGameplayStatics::SpawnEmitterAtLocation(World, Particle, LocationToSpawn);
	if (PSC)
	{
		PSC->SetRelativeScale3D(Scale);

		GetSoundPlayer().PlayEffectSound(SoundParam);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// Beam Particle

void ACombatPresenter::SpawnBeamParticle(const FSpawnBeamParticleParams& Params)
{
	check(SpawnBeamParticleQueue.IsValid());

	bool bSucceed = SpawnBeamParticleQueue->Enqueue(FSpawnBeamParticleParams(Params));

	if (!ensure(bSucceed))
	{
		Q6JsonLogSunny(Error, "CombatPresenter BeamParticle queue is full", Q6KV("World", GetWorld()->GetName()));
	}
}

void ACombatPresenter::SpawnBeamParticleInternal(const FSpawnBeamParticleParams& Params)
{
	AUnit* SourceUnit = FindUnit(Params.SourceUnitId);
	if (!SourceUnit)
	{
		Q6JsonLogSunny(Warning, "Failed to beam particle. Can't find Source Unit", Q6KV("Source UnitId:", Params.SourceUnitId.X));
		return;
	}

	AUnit* TargetUnit = FindUnit(Params.TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Warning, "Failed to spawn beam particle. Can't find Target Unit", Q6KV("Source UnitId:", Params.TargetUnitId.X));
		return;
	}

	UParticleSystem* PS = Params.Desc.Particle;
	if (!PS)
	{
		return;
	}

	UParticleSystemComponent* PSC = UGameplayStatics::SpawnEmitterAttached(PS, SourceUnit->GetMesh(), Params.Desc.StartSocket, Params.Desc.StartSocketOffset);
	if (!PSC)
	{
		return;
	}
	
	FVector WorldOffset = TargetUnit->GetActorRotation().RotateVector(Params.Desc.TargetSocketOffset);
	FVector TargetLocation = TargetUnit->GetSocketTransform(Params.Desc.TargetSocket).GetLocation() + WorldOffset;

	FVector Dir = TargetLocation - PSC->GetComponentLocation();
	Dir.Normalize();
	PSC->SetWorldRotation(Dir.Rotation());

	for (int32 EmitterIndex = 0; EmitterIndex < PSC->EmitterInstances.Num(); ++EmitterIndex)
	{
		PSC->SetBeamTargetPoint(EmitterIndex, TargetLocation, 0);
	}

	PSC->SetRelativeScale3D(Params.Desc.Scale);

	FDynamicParticleInfo Info;
	Info.Type = FDynamicParticleInfo::Beam;
	Info.Particle = PSC;
	Info.PlayStartTime = GetWorld()->GetTimeSeconds();
	Info.Duration = Params.Duration;
	Info.bDestroyAtEnd = Params.Desc.bDestroyAtEnd;
	Info.TargetUnit = TargetUnit;
	Info.TargetSocket = Params.Desc.TargetSocket;
	Info.TargetSocketOffset = Params.Desc.TargetSocketOffset;
	DynamicParticleInfos.Add(Info);
}

void ACombatPresenter::UpdateSpawnBeamParticles()
{
	int32 NumSpawn = CVarQ6BeamSpawnPerTick.GetValueOnGameThread();

	while (!SpawnBeamParticleQueue->IsEmpty() && NumSpawn > 0)
	{
		FSpawnBeamParticleParams Params;
		SpawnBeamParticleQueue->Dequeue(Params);

		SpawnBeamParticleInternal(Params);

		--NumSpawn;
	}
}

//////////////////////////////////////////////////////////////////////////////////
// Dynamic Particle

void ACombatPresenter::UpdateDynamicParticles()
{
	int32 Index = 0;
	while (DynamicParticleInfos.IsValidIndex(Index))
	{
		const FDynamicParticleInfo& Info = DynamicParticleInfos[Index];

		UParticleSystemComponent* Particle = Info.Particle.Get();
		if (!Particle)
		{
			DynamicParticleInfos.RemoveAtSwap(Index);
			continue;
		}

		float TimeNow = GetWorld()->GetTimeSeconds();
		if (Info.PlayStartTime + Info.Duration <= TimeNow)
		{
			if (Info.bDestroyAtEnd)
			{
				Particle->DestroyComponent();
			}
			else
			{
				Particle->DeactivateSystem();
			}

			DynamicParticleInfos.RemoveAtSwap(Index);
			continue;
		}

		if (Info.Type == FDynamicParticleInfo::Beam)
		{
			AUnit* TargetUnit = Info.TargetUnit;
			if (!TargetUnit)
			{
				DynamicParticleInfos.RemoveAtSwap(Index);
				continue;
			}

			FVector WorldOffset = TargetUnit->GetActorRotation().RotateVector(Info.TargetSocketOffset);
			FVector TargetLocation = TargetUnit->GetSocketTransform(Info.TargetSocket).GetLocation() + WorldOffset;

			FVector Dir = TargetLocation - Particle->GetComponentLocation();
			Dir.Normalize();
			Particle->SetWorldRotation(Dir.Rotation());

			for (int32 EmitterIndex = 0; EmitterIndex < Particle->EmitterInstances.Num(); ++EmitterIndex)
			{
				Particle->SetBeamTargetPoint(EmitterIndex, TargetLocation, 0);
			}
		}

		++Index;
	}
}

void ACombatPresenter::DespawnAllDynamicParticles()
{
	for (const FDynamicParticleInfo& Info : DynamicParticleInfos)
	{
		if (Info.Particle.IsValid())
		{
			Info.Particle->DestroyComponent();
		}
	}
	DynamicParticleInfos.Empty();

	if (SpawnBeamParticleQueue.IsValid())
	{
		SpawnBeamParticleQueue->Empty();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// SkeletalMesh

void ACombatPresenter::SpawnSkeletalMesh(const FSpawnSkeletalMeshParams& Params)
{
	check(SpawnSkeletalMeshQueue.IsValid());

	bool bSucceed = SpawnSkeletalMeshQueue->Enqueue(FSpawnSkeletalMeshParams(Params));

	if (!ensure(bSucceed))
	{
		Q6JsonLogZagal(Error, "CombatPresenter SkeletalMesh queue is full", Q6KV("World", GetWorld()->GetName()));
	}
}

void ACombatPresenter::SpawnSkeletalMeshInternal(const FSpawnSkeletalMeshParams& Params)
{
	const FSpawnSkeletalMeshDesc& Desc = Params.Desc;
	if (!Desc.IsValid())
	{
		Q6JsonLogZagal(Warning, "Failed to spawn SkeletalMesh. Resouces is null");
		return;
	}

	AUnit* Unit = nullptr;
	if (Params.UnitId != CCUnitIdInvalid)
	{
		Unit = FindUnit(Params.UnitId);
		if (!Unit)
		{
			Q6JsonLogZagal(Warning, "Failed to spawn SkeletalMesh. Can't find Unit", Q6KV("UnitId:", Params.UnitId.X));
			return;
		}
	}

	FVector Location = Desc.Offset;
	FRotator Rotator(Desc.Rotation.Y, Desc.Rotation.Z, Desc.Rotation.X);

	if (Unit)
	{
		if (Desc.Socket.IsNone())
		{
			Location += Unit->GetBottomTransform().GetLocation();
		}
		else
		{
			Location += Unit->GetSocketTransform(Desc.Socket).GetLocation();
		}
	}
	else
	{
		Location += Params.Location;
	}

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnInfo.ObjectFlags = RF_Transient;

	ASkeletalMeshActor* Actor = GetWorld()->SpawnActor<ASkeletalMeshActor>(Location, Rotator, SpawnInfo);
	if (!Actor)
	{
		Q6JsonLogZagal(Warning, "Failed to spawn SkeletalMesh.");
		return;
	}

	Actor->SetActorScale3D(Desc.Scale);

	USkeletalMeshComponent* MeshComp = Actor->GetSkeletalMeshComponent();
	MeshComp->SetSkeletalMesh(Desc.Mesh);
	MeshComp->PlayAnimation(Desc.AnimSequence, true);

	FSpawnedSkeletalMeshInfo Info;
	Info.Actor = Actor;
	Info.EndTime = GetWorld()->GetTimeSeconds() + Params.Desc.Duration;
	SpawnedSkeletalMeshInfos.Add(Info);
}

void ACombatPresenter::UpdateSpawnSkeletalMeshes()
{
	// for life time

	float TimeNow = GetWorld()->GetTimeSeconds();
	int32 Index = 0;

	while (SpawnedSkeletalMeshInfos.IsValidIndex(Index))
	{
		const FSpawnedSkeletalMeshInfo& Info = SpawnedSkeletalMeshInfos[Index];

		ASkeletalMeshActor* MeshActor = Info.Actor.Get();
		if (!MeshActor)
		{
			SpawnedSkeletalMeshInfos.RemoveAtSwap(Index);
			continue;
		}

		if (Info.EndTime < TimeNow)
		{
			MeshActor->Destroy();
			SpawnedSkeletalMeshInfos.RemoveAtSwap(Index);
			continue;
		}

		++Index;
	}

	// for spawn

	int32 NumSpawn = CVarQ6SkeletalMeshSpawnPerTick.GetValueOnGameThread();

	while (!SpawnSkeletalMeshQueue->IsEmpty() && NumSpawn > 0)
	{
		FSpawnSkeletalMeshParams Params;
		SpawnSkeletalMeshQueue->Dequeue(Params);

		SpawnSkeletalMeshInternal(Params);

		--NumSpawn;
	}
}

void ACombatPresenter::DespawnAllSkeletalMeshes()
{
	if (SpawnSkeletalMeshQueue.IsValid())
	{
		SpawnSkeletalMeshQueue->Empty();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// Loot

FVector ACombatPresenter::GetLootTargetLocation(ELootDropType InLootType, const FVector& SourceLocation)
{
	float Distance = SourceLocation.Z;
	FVector Offset(Distance, 0.f, FMath::RandRange(-Distance/4.f, Distance/4.f));
	Offset = Offset.RotateAngleAxis(FMath::RandRange(0.f, 180.f), FVector(0, 0, 1));

	FVector TargetLocation = SourceLocation + Offset;
	if (InLootType != ELootDropType::OverKillPoint)
	{
		if (CombatLocator)
		{
			TargetLocation.Z = CombatLocator->GetBottomLocationZ();
		}
		else
		{
			TargetLocation.Z = 0.f;
		}
	}

	return TargetLocation;
}

void ACombatPresenter::SpawnLoot(AUnit* InSourceUnit, ELootDropType InLootType, int32 InLootCount, int32 InLootDropCount)
{
	if (InLootCount <= 0 || InLootDropCount <= 0)
	{
		return;
	}

	FTransform Transform = InSourceUnit->GetSocketTransform(UnitSocket::Center);

	for (int32 i = 0; i < InLootCount; ++i)
	{
		ALoot* Loot = GetWorld()->SpawnActorDeferred<ALoot>(GetCombatGameResource(this)->GetLootActorClass(), Transform);
		if (!Loot)
		{
			Q6JsonLogSunny(Warning, "ACombatPresenter::SpawnLoot - fail to create loot actor");
			return;
		}

		Loot->SetLootSpawnInfo(InLootType, InLootDropCount, Transform.GetLocation(), GetLootTargetLocation(InLootType, Transform.GetLocation()));
		UGameplayStatics::FinishSpawningActor(Loot, Transform);

		LootActors.Add(Loot);
	}
}

void ACombatPresenter::CollectLoot(AUnit* InUnit)
{
	if (!InUnit)
	{
		for (ALoot* LootActor : LootActors)
		{
			LootActor->Collect();
		}
	}
	else
	{
		for (int32 i = 0; i < LootActors.Num(); ++i)
		{
			LootActors[i]->CollectToUnit(InUnit, i);
		}
	}
	LootActors.Empty();
}

void ACombatPresenter::SpawnDropBox(FCCUnitId InUnitId)
{
	DropBoxSpawner->SpawnDropBox(InUnitId);
}

float ACombatPresenter::GetSpawnDropBoxRemainTime()
{
	return DropBoxSpawner->GetSpawnDropBoxRemainTime() + GetCombatGameResource(this)->GetDropBoxWaitTimeToNextWave();
}

void ACombatPresenter::SetInvisibleDropBox(const AUnit* InEnemyUnit)
{
	if (InEnemyUnit->IsInvisibleDropBox())
	{
		const int32 InvisibleWaveIndex = Wave - 1;
		const int32 InvisibleSlot = InEnemyUnit->GetSlot();

		for (int32 i = ItemDropInfos.Num() - 1; i >= 0; --i)
		{
			const FItemDropInfo& ItemDropInfo = ItemDropInfos[i];
			if (ItemDropInfo.WaveIndex == InvisibleWaveIndex && ItemDropInfo.Slot == InvisibleSlot)
			{
				ItemDropInfos.RemoveAtSwap(i);
				break;
			}
		}

		for (int32 i = RandomSpawnItemDropInfos.Num() - 1; i >= 0; --i)
		{
			const FItemDropInfo& RandomSpawnItemDropInfo = RandomSpawnItemDropInfos[i];
			if (RandomSpawnItemDropInfo.WaveIndex == InvisibleWaveIndex && RandomSpawnItemDropInfo.Slot == InvisibleSlot)
			{
				RandomSpawnItemDropInfos.RemoveAtSwap(i);
				break;
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////
// PreCache

void ACombatPresenter::CacheStageAssets()
{
	CacheStageSequences();
	CachePetAssets();
	CacheCharacterAssets();
	CacheMonsterAssets();
	PreSpawnUnitAssets();

	UnitAssetPreSpawnedTime = FApp::GetCurrentTime();
}

void ACombatPresenter::ReleaseStageAssets()
{
	if (SequenceCache)
	{
		SequenceCache->CancelStreaming();
		SequenceCache = nullptr;
	}
}

void ACombatPresenter::CacheStageSequences()
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);

	TArray<FSoftObjectPath> SeqPaths;
	GetGameResource().GetBoneDragonOutroSequence(CombatSeed.SagaType, SeqPaths);
	GetGameResource().GetWaveSequencesOfStage(SagaRow.Episode, SagaRow.Stage, SeqPaths);
	GetGameResource().GetLevelEffectSequencesOfStage(SagaRow.Episode, SagaRow.Stage, SeqPaths);

	if (SeqPaths.Num() > 0)
	{
		FAssetCacheOptions CacheOptions;
		CacheOptions.bBlocking = true;
		CacheOptions.Priority = 0;

		SequenceCache = GetGameResource().GetCacheManager()->CacheSequences(SeqPaths, CacheOptions);
	}
}

void ACombatPresenter::CachePetAssets()
{
	PetUnitCache = nullptr;

	if (CombatSeed.Seed.PetInfo.Type == PetTypeInvalid)
	{
		return;
	}

	FUnitAssetCacheOptions CacheOptions;
	CacheOptions.bBlocking = true;
	CacheOptions.Priority = 0;
	CacheOptions.bIncludeCombatPortraits = true;
	CacheOptions.bIncludeResultSequence = true;

	PetUnitCache = GetGameResource().GetCacheManager()->CachePetUnit(CombatSeed.Seed.PetInfo.Type, CacheOptions, FGameAssetStreamDelegate());
}

void ACombatPresenter::CacheCharacterAssets()
{
	TArray<FCCCombatSeedUnit> CharacterUnits = CombatSeed.Units;
	CharacterUnits.Append(CombatSeed.SubUnits);

	for (const FCCCombatSeedUnit CharacterUnit : CharacterUnits)
	{
		FUnitAssetCacheOptions CacheOptions;
		CacheOptions.bBlocking = true;
		CacheOptions.Priority = 0;
		CacheOptions.bIncludeCombatPortraits = true;
		CacheOptions.bIncludeResultSequence = true;

		UGameAssetCache* Cache = GetGameResource().GetCacheManager()->CacheUnit(CharacterUnit.UnitType, CacheOptions, FGameAssetStreamDelegate());
		CharacterUnitCaches.Add(Cache);
	}
}

static void _AddUniqueValidateUnitType(TArray<int32>& InArray, int32 InValue)
{
	if (InValue == UnitTypeInvalid.x)
	{
		return;
	}
	
	InArray.AddUnique(InValue);
}

void ACombatPresenter::CacheMonsterAssets()
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);
	TArray<const FCMSWaveRow*> WaveRows = SagaRow.GetWave();
	
	TArray<int32> MonsterUnitTypes;
	for (const FCMSWaveRow* WaveRow : WaveRows)
	{
		for (int T : WaveRow->Spawns01)
		{
			_AddUniqueValidateUnitType(MonsterUnitTypes, T);
		}
		for (int T : WaveRow->Spawns02)
		{
			_AddUniqueValidateUnitType(MonsterUnitTypes, T);
		}
		for (int T : WaveRow->Spawns03)
		{
			_AddUniqueValidateUnitType(MonsterUnitTypes, T);
		}
	}

	for (int32 MonsterUnitType : MonsterUnitTypes)
	{
		FUnitAssetCacheOptions CacheOptions;
		CacheOptions.bBlocking = true;
		CacheOptions.Priority = 0;
		CacheOptions.bIncludeCombatPortraits = false;
		CacheOptions.bIncludeResultSequence = false;

		UGameAssetCache* Cache = GetGameResource().GetCacheManager()->CacheUnit(MonsterUnitType, CacheOptions, FGameAssetStreamDelegate());
		MonsterUnitCaches.Add(Cache);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// PreSpawn

void ACombatPresenter::PreSpawnUnitAssets()
{
	APlayerController* PlayerController = GetLocalPlayerController(this);
	if (!ensure(PlayerController))
	{
		return;
	}

	PlayerController->PlayerCameraManager->UpdateCamera(0.0f);

	FVector ViewPos;
	FRotator ViewRot;
	PlayerController->PlayerCameraManager->GetCameraViewPoint(ViewPos, ViewRot);

	const FTransform SpawnTransform(ViewPos + 500 * ViewRot.Vector());
	TArray<UParticleSystemComponent*> AnimTrailParticleComponents;

	TArray<UGameAssetCache*> AllUnitCaches = CharacterUnitCaches;
	AllUnitCaches.Append(MonsterUnitCaches);

	if (PetUnitCache)
	{
		AllUnitCaches.Add(PetUnitCache);
	}

	for (UGameAssetCache* Cache : AllUnitCaches)
	{
		// TODO-Sunny: change to baked unit resource
		for (UObject* Object : Cache->GetLoadedObjects())
		{
			if (!Object)
			{
				continue;
			}

			//UClass* ClassObject = Cast<UClass>(Object);
			//if (ClassObject && ClassObject->IsChildOf(AProjectile::StaticClass()))
			//{
			//	AProjectile* Projectile = GetWorld()->SpawnActor<AProjectile>(ClassObject, SpawnTransform);
			//	UnitProjectileCaches.Add(Projectile);
			//	continue;
			//}

			//UParticleSystem* Particle = Cast<UParticleSystem>(Object);
			//if (Particle)
			//{
			//	UParticleSystemComponent* ParticleComp = UGameplayStatics::SpawnEmitterAtLocation(GetWorld(), Particle, SpawnTransform);
			//	UnitParticleCaches.Add(ParticleComp);

			//	bool bIsAnimTrail = false;
			//	for (FParticleEmitterInstance* Inst : ParticleComp->EmitterInstances)
			//	{
			//		if (Inst && Inst->IsTrailEmitter())
			//		{
			//			bIsAnimTrail = true;
			//			break;
			//		}
			//	}

			//	if (bIsAnimTrail)
			//	{
			//		// Anim trail needed to be attached and signaled
			//		AnimTrailParticleComponents.Add(ParticleComp);
			//	}
			//	continue;
			//}

			USoundBase* Sound = Cast<USoundBase>(Object);
			if (Sound)
			{
				UGameplayStatics::PlaySound2D(GetWorld(), Sound, 0);
			}
		}
	}

	// Find already spawned unit type, to reuse it's model assets
	//FUnitType CacheUnitType;
	//if (!CombatSeed.Units.IsValidIndex(0))
	//{
	//	CacheUnitType = CombatSeed.Units[0].UnitType;
	//}

	//for (TActorIterator<AUnit> It(GetWorld(), AUnit::StaticClass()); It; ++It)
	//{
	//	AUnit* Unit = *It;
	//	if (Unit->GetUnitType() != 0)
	//	{
	//		CacheUnitType = FUnitType(Unit->GetUnitType());
	//		break;
	//	}
	//}

	//if (MaterialCacheUnits.Num() == 0)
	//{
	//	FActorSpawnParameters SpawnInfo;
	//	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	//	AUnit* Unit = GetWorld()->SpawnActor<AUnit>(AUnit::StaticClass(), SpawnTransform, SpawnInfo);
	//	Unit->InitUnit(CacheUnitType.x);
	//	Unit->SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, GetCheckedCombatGameResource(this).GetSpawnEffectMaterial(ESpawnReason::Init));
	//	MaterialCacheUnits.Add(Unit);

	//	Unit = GetWorld()->SpawnActor<AUnit>(AUnit::StaticClass(), SpawnTransform, SpawnInfo);
	//	Unit->InitUnit(CacheUnitType.x);
	//	Unit->SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, GetCheckedCombatGameResource(this).GetSpawnEffectMaterial(ESpawnReason::Rebirth));
	//	MaterialCacheUnits.Add(Unit);

	//	Unit = GetWorld()->SpawnActor<AUnit>(AUnit::StaticClass(), SpawnTransform, SpawnInfo);
	//	Unit->InitUnit(CacheUnitType.x);
	//	Unit->SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, GetCheckedCombatGameResource(this).GetDeadEffectMaterial());
	//	MaterialCacheUnits.Add(Unit);
	//}

	//check(MaterialCacheUnits.Num() > 0);

	//for (UParticleSystemComponent* ParticleComp : AnimTrailParticleComponents)
	//{
	//	ParticleComp->AttachToComponent(MaterialCacheUnits[0]->GetMesh(), FAttachmentTransformRules::KeepWorldTransform);

	//	UParticleSystemComponent::TrailEmitterArray TrailEmitters;
	//	ParticleComp->GetOwnedTrailEmitters(TrailEmitters, nullptr, false);

	//	for (FParticleAnimTrailEmitterInstance* Trail : TrailEmitters)
	//	{
	//		Trail->BeginTrail();
	//		Trail->SetTrailSourceData(FName(TEXT("Center")), FName(TEXT("Dummy")), ETrailWidthMode_FromCentre, 100);
	//	}
	//}
}

void ACombatPresenter::CleanUpPreSpawnedUnitAssets()
{
	for (UParticleSystemComponent* Particle : UnitParticleCaches)
	{
		if (Particle && !Particle->IsPendingKill())
		{
			Particle->DestroyComponent();
		}
	}

	for (AProjectile* Projectile : UnitProjectileCaches)
	{
		if (Projectile)
		{
			Projectile->Destroy();
		}
	}

	UnitParticleCaches.Empty();
	UnitProjectileCaches.Empty();

	for (AUnit* Unit : MaterialCacheUnits)
	{
		if (Unit)
		{
			Unit->SetActorHiddenInGame(true);
			Unit->Destroy(false, false);
		}
	}
	MaterialCacheUnits.Empty();
}

void ACombatPresenter::SynchronizeCCState(const FCCCombatCubeState& InState)
{
	CombatSeed = InState.CombatSeed;
	LocatorGroup = GetCMS()->GetMapLocatorGroup(CombatSeed.SagaType);
	Wave = InState.TurnState.CurrentWaveIndex + 1;	// pawn - WaveCount is not counting BonusWave.
	WaveEnemyNumSlots = InState.TurnState.WaveEnemyNumSlots;
	const int32 WaveRowIndex = GetWaveRowIndex();
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(CombatSeed.SagaType, WaveRowIndex);
	if (WaveRow)
	{
		bWaveEnemyDefaultPosition = WaveRow->DefaultPosition;
	}
	TurnCount = InState.TurnState.TurnCount;
	CurrentCombatMultiSide = InState.TurnState.CurrentCombatMultiSide;
	CombatMultiSideWaveRowIndex = UCombatCubeStateUtil::GetCombatMultiSideWaveRowIndex(CombatSeed, CurrentCombatMultiSide, InState.TurnState.CurrentWaveIndex);
	CombatMultiSideTurnCount = InState.TurnState.CombatMultiSideTurnCount;
	TotalWaveNum = InState.CombatSeed.Seed.TotalWaveNum;
	LastSkillUsedUnitId = CCUnitIdInvalid;
	//InstanceId : no need
	//SpawnProjectileQueue : no need
	//WaveSequenceCache : Initialized at CacheStageAssets
	//UnitAssetPreSpawnedTime : Initialized at CacheStageAssets
	//UnitAssetPreSpawnCleanupTime : Initialized at CacheStageAssets
	//MaterialCacheUnits : Initialized at CacheStageAssets
	//UnitParticleCaches : Initialized at CacheStageAssets
	//UnitProjectileCaches : Initialized at CacheStageAssets
	//MonsterUnitCaches : Initialized at CacheStageAssets
	//CharacterUnitCaches : Initialized at CacheStageAssets
	//AutomationHelper : no need(dev)
	SkillInstance = nullptr; // set at skill used events
	SkillBuffInstance = nullptr; // set at create buff events
	//DelayedSpawnInstances : no need
	//UnitSpawnedBuffInstance : no need
	CacheStageAssets();
	PresentTurnPhase = InState.TurnState.CurrentPhase;
	PresentResult = InState.Result;

	GetHUDStore().GetBattleHelper().ReqStageChallengeList(InState.CombatSeed.SagaType);

	CombatLocator = ULevelUtil::FindCombatLocator(GetWorld(), LocatorGroup, Wave, CurrentCombatMultiSide);
	CameraLayerActor = ULevelUtil::FindCameraLayerActor(GetWorld(), ECameraLayerIndex::Layer1);

	BindCombatCameraToController();

	SpawnedUnits.Reset(CombatCubeConst::Q6_MAX_SPAWN_UNITS_PER_GAME);
	SpawnedUnits.AddZeroed(CombatCubeConst::Q6_MAX_SPAWN_UNITS_PER_GAME);
	SpawnedUnitIds.Reset();

	PetUnit = SpawnPetUnit();

	UCombatCubeStateUtil::ConvertCCMasterStateToMasterState(InState.UnitsState.Masters, &Masters);

	SetCharacterUnitInfos();
	if (CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		ECombatMultiSide OldSpawningCombatMultiSide = CurrentCombatMultiSide;
		for (const FCCUnitState& InSpawnUnitState : InState.UnitsState.Units)
		{
			// the other multiside ally units are spawned on out of camera
			bool bIsCurrentCombatMultiSide = UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, InSpawnUnitState.CombatMultiSide, GetWaveIndex(), InSpawnUnitState.SpawnedWaveIndex);
			if (OldSpawningCombatMultiSide != InSpawnUnitState.CombatMultiSide) // -V1051
			{
				int32 SpawnUnitWave = Wave;
				if (!bIsCurrentCombatMultiSide)
				{
					SpawnUnitWave = InState.TurnState.OldCombatMultiSideWaveIndex + 1;
				}
				// set combatlocator of unit's multiside for spawning on correct transform
				CombatLocator = ULevelUtil::FindCombatLocator(GetWorld(), LocatorGroup, SpawnUnitWave, InSpawnUnitState.CombatMultiSide);
				BindCombatCameraToController();
			}

			bool bSpawnOutCam = !bIsCurrentCombatMultiSide && InSpawnUnitState.Faction == ECCFaction::Ally;
			AUnit* Unit = SpawnUnit(InSpawnUnitState, bSpawnOutCam, true);
			if (!bIsCurrentCombatMultiSide)
			{
				// the other multiside units are disabled
				Unit->SetAnimRelaxed(false);
				Unit->DisableUnit();
			}

			OldSpawningCombatMultiSide = InSpawnUnitState.CombatMultiSide;
		}

		// restore combat locator to current multiside
		if (OldSpawningCombatMultiSide != CurrentCombatMultiSide)
		{
			CombatLocator = ULevelUtil::FindCombatLocator(GetWorld(), LocatorGroup, Wave, CurrentCombatMultiSide);
			BindCombatCameraToController();
		}
	}
	else
	{
		for (const FCCUnitState& InSpawnUnitState : InState.UnitsState.Units)
		{
			// bBlockingLoad could call the finish event delegate of UGameAssetCache in this time.
			if (UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, InSpawnUnitState.CombatMultiSide, GetWaveIndex(), InSpawnUnitState.SpawnedWaveIndex))
			{
				SpawnUnit(InSpawnUnitState, false, true);
			}
		}
	}

	ForEachUnit([](AUnit& InUnit)
	{
		InUnit.SynchronizeUnitState();
	});

	CGStateMgr->SetTurnSkillState();

	PickTurnPrepareUnit(GetCharacterStateBySlot(1).UnitId);
	SetDecalVisible(true);

	SelectTarget(InState.TurnState.PlayerTargetUnitId, false);
	RestoredUnitId = TargetedUnitId;

	// TODO ui set
	GetCheckedCombatHUD(this)->SynchronizeCCState(InState);

	SetCombatMissionInfo();
	SetItemDropInfo();

	DropBoxSpawner->SynchronizeDropBox();

	SelectTarget(InState.TurnState.PlayerTargetUnitId, false);
	RestoredUnitId = TargetedUnitId;
}

void ACombatPresenter::PostSynchronizeCCState()
{
	GetCheckedCombatHUD(this)->PostSynchronizeCCState();
}

void ACombatPresenter::BindCombatCameraToController()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->BindCombatCamera(CombatLocator, Wave);
	}
}

void ACombatPresenter::AddCharacterUnitInfo(const UCharacterManager& CharacterManager, FCharacterId CharacterId)
{
	const FCharacter* Character = CharacterManager.Find(CharacterId);
	if (Character)
	{
		FCharacterUnitInfo AllyCharacterInfo;
		AllyCharacterInfo.CharacterId = CharacterId;
		AllyCharacterInfo.CharacterType = Character->GetInfo().Type;
		AllyCharacterInfo.UnitType = GetCMS()->GetUnitType(Character->GetInfo().Type);
		AllyCharacterUnitInfos.Add(AllyCharacterInfo);
	}
}

void ACombatPresenter::SetCharacterUnitInfos()
{
	AllyCharacterUnitInfos.Empty();

	UHUDStore& HUDStore = GetHUDStore();
	const UPartyManager& PartyManager = HUDStore.GetPartyManager();
	const UCharacterManager& CharacterManager = HUDStore.GetCharacterManager();
	const FPartyInfo& PartyInfo = PartyManager.GetPartyInfo(CombatSeed.PartyId);

	for (const FPartySlot& PartySlot : PartyInfo.Main)
	{
		AddCharacterUnitInfo(CharacterManager, PartySlot.CharacterId);
	}
	for (const FPartySlot& PartySlot : PartyInfo.Sub)
	{
		AddCharacterUnitInfo(CharacterManager, PartySlot.CharacterId);
	}

	UCharacterVoiceHelper* CharacterVoiceHelper = GetCharacterVoiceHelper();
	if (CharacterVoiceHelper)
	{
		for (const FCharacterUnitInfo& AllyCharacterInfo : AllyCharacterUnitInfos)
		{
			CharacterVoiceHelper->GatherCharacterVoices(AllyCharacterInfo.CharacterType);
		}
	}
}

FCharacterType ACombatPresenter::GetAllyCharacterType(FCCUnitId UnitId) const
{
	for (const FCharacterUnitInfo& Info : AllyCharacterUnitInfos)
	{
		if (Info.UnitId == UnitId)
		{
			return Info.CharacterType;
		}
	}

	return CharacterTypeInvalid;
}

void ACombatPresenter::SetItemDropInfo()
{
	FMT19937Uint32 Rng(GetCombatSeed().Seed.RandomSeed);

	ItemDropInfos.Empty();

	TArray<TArray<bool>> HasRandomSpawnItemDropInfos;
	SetRandomSpawnItemDropInfo(HasRandomSpawnItemDropInfos);	// must call before GatherEnemyInfos() because GatherEnemyInfos() use HasRandomSpawnItemDropInfos

	TArray<EItemGrade> ItemGrades;
	const FStageReward& StageReward = GetHUDStore().GetRewardManager().GetStageReward();
	bool bIsSameGrades = GatherItemGrades(StageReward.ItemList, ItemGrades);

	TArray<FEnemyInfo> EnemyInfos;
	GatherEnemyInfos(Rng, EnemyInfos, HasRandomSpawnItemDropInfos);

	ItemDropInfos.SetNum(EnemyInfos.Num());

	AssignDropBox(Rng, ItemGrades, bIsSameGrades, EnemyInfos);
	AssignGainGold(EnemyInfos);

	DropBoxSpawner->CacheDropBoxAssets();
}

void ACombatPresenter::SetRandomSpawnItemDropInfo(TArray<TArray<bool>>& OutHasRandomSpawnItemDropInfos)
{
	RandomSpawnItemDropInfos.Empty();

	// total waves count including bonus waves
	const int32 TotalWaveCount = CombatSeed.Seed.AppearanceWave.Num();

	OutHasRandomSpawnItemDropInfos.SetNum(TotalWaveCount);
	for (TArray<bool>& HasRandomSpawnItemDropInfo : OutHasRandomSpawnItemDropInfos)
	{
		// make random spawn item drop flags per slot
		HasRandomSpawnItemDropInfo.Init(false, CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
	}

	int32 RandomSpawnItemDropIndex = 0;

	const TArray<FWaveSpawnUnitKillRewardInfo>& WaveSpawnUnitKillRewardInfos = GetHUDStore().GetRewardManager().GetWaveSpawnUnitKillRewardInfo();
	for (const FWaveSpawnUnitKillRewardInfo& WaveSpawnUnitKillRewardInfo : WaveSpawnUnitKillRewardInfos)
	{
		for (const FSpawnUnitRewardInfo& SpawnUnitRewardInfo : WaveSpawnUnitKillRewardInfo.SpawnUnitRewardInfos)
		{
			const int32 WaveIndex = WaveSpawnUnitKillRewardInfo.Wave - 1;

			// if there are any rewards, add a dropbox only once
			if (SpawnUnitRewardInfo.RewardInfo.ItemList.Num() > 0 || SpawnUnitRewardInfo.RewardInfo.CurrencyList.Num() > 0)
			{
				RandomSpawnItemDropInfos.AddDefaulted(1);

				RandomSpawnItemDropInfos[RandomSpawnItemDropIndex].DropBoxes.Add((int32)EDropBoxType::RandomSpawnBox, 1);
				RandomSpawnItemDropInfos[RandomSpawnItemDropIndex].WaveIndex = WaveIndex;
				RandomSpawnItemDropInfos[RandomSpawnItemDropIndex].Slot = SpawnUnitRewardInfo.UnitIndex;

				if (OutHasRandomSpawnItemDropInfos.IsValidIndex(WaveIndex))
				{
					const int32 SlotIndex = SpawnUnitRewardInfo.UnitIndex - 1;
					if (OutHasRandomSpawnItemDropInfos[WaveIndex].IsValidIndex(SlotIndex))
					{
						OutHasRandomSpawnItemDropInfos[WaveIndex][SlotIndex] = true;
					}
				}

				RandomSpawnItemDropIndex++;
			}
		}
	}
}

bool ACombatPresenter::GatherItemGrades(const TArray<FItemData>& InItemList, TArray<EItemGrade>& OutItemGrades)
{
	bool bIsSameGrades = true;
	EItemGrade OldItemGrade = EItemGrade::NONE;
	for (const FItemData& Item : InItemList)
	{
		EItemGrade ItemGrade = GetItemGrade(Item.Category, Item.Type);
		// NRBox (Normal + Rare)
		if (ItemGrade == EItemGrade::R)
		{
			ItemGrade = EItemGrade::N;
		}
		OutItemGrades.Add(ItemGrade);

		if (OldItemGrade != EItemGrade::NONE)
		{
			bIsSameGrades &= (OldItemGrade == ItemGrade);
		}

		OldItemGrade = ItemGrade;
	}

	// sorted by grade
	if (!bIsSameGrades)
	{
		OutItemGrades.StableSort([](const EItemGrade& Grade1, const EItemGrade& Grade2)
		{
			return (int32)Grade1 > (int32)Grade2;
		});
	}

	return bIsSameGrades;
}

EItemGrade ACombatPresenter::GetItemGrade(ELootCategory InCategory, int32 InItemType)
{
	switch (InCategory)
	{
		case ELootCategory::BagItem:
			{
				const FCMSBagItemRow& BagItemRow = GetCMS()->GetBagItemRowOrDummy(FBagItemType(InItemType));
				return BagItemRow.Grade;
			}
			break;

		case ELootCategory::CharacterCard:
			{
				const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(FCharacterType(InItemType));
				return CharacterRow.Grade;
			}
			break;

		case ELootCategory::SculptureCard:
			{
				const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(FSculptureType(InItemType));
				return SculptureRow.Grade;
			}
			break;

		case ELootCategory::RelicCard:
			{
				const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(FRelicType(InItemType));
				return RelicRow.Grade;
			}
			break;

		default:
			break;
	}

	Q6JsonLogPawn(Error, "Item has Invalid Category", Q6KV("Category", (int32)InCategory));
	return EItemGrade::NONE;
}

void ACombatPresenter::GatherEnemyInfos(FMT19937Uint32& InRng, TArray<FEnemyInfo>& OutEnemyInfos, const TArray<TArray<bool>>& InHasRandomSpawnItemDropInfos)
{
	const FSagaType SagaType = GetCombatSeed().SagaType;
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	TArray<int32> RandomIndices;

	const int32 TotalWaveCount = CombatSeed.Seed.AppearanceWave.Num();
	int32 SpawnedEnemyCount = 0;
	for (int32 i = 0; i < TotalWaveCount; ++i)
	{
		const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(SagaType, i);
		if (!WaveRow)
		{
			Q6JsonLogPawn(Warning, "WaveRow index error", Q6KV("SagaType", SagaType), Q6KV("WaveCount", i));
			return;
		}

		// exclude the bonus wave
		if (IsBonusWave(WaveRow))
		{
			continue;
		}

		if (!InHasRandomSpawnItemDropInfos.IsValidIndex(i))
		{
			Q6JsonLogPawn(Warning, "WaveRow index error", Q6KV("SagaType", SagaType), Q6KV("WaveCount", i));
			return;
		}

		// exclude the random spawned enemy that has the random spawn rewards
		if (WaveRow->Spawns01[0] != UnitTypeInvalid.x && !InHasRandomSpawnItemDropInfos[i][0])
		{
			RandomIndices.Add(SpawnedEnemyCount);
			OutEnemyInfos.Emplace(FEnemyInfo(i, 1, WaveRow->Spawns01[0], WaveRow->Spawn01Level, SpawnedEnemyCount++));
		}
		if (WaveRow->Spawns02[0] != UnitTypeInvalid.x && !InHasRandomSpawnItemDropInfos[i][1])
		{
			RandomIndices.Add(SpawnedEnemyCount);
			OutEnemyInfos.Emplace(FEnemyInfo(i, 2, WaveRow->Spawns02[0], WaveRow->Spawn02Level, SpawnedEnemyCount++));
		}
		if (WaveRow->Spawns03[0] != UnitTypeInvalid.x && !InHasRandomSpawnItemDropInfos[i][2])
		{
			RandomIndices.Add(SpawnedEnemyCount);
			OutEnemyInfos.Emplace(FEnemyInfo(i, 3, WaveRow->Spawns03[0], WaveRow->Spawn03Level, SpawnedEnemyCount++));
		}
	}

	// add random score to each enemies for choosing enemies that has same score randomly
	Q6Util::ShuffleArray(InRng, RandomIndices);

	for (int32 i = 0; i < SpawnedEnemyCount; ++i)
	{
		// pawn tweak code - add some offset for sorting
		FEnemyInfo& EnemyInfo = OutEnemyInfos[RandomIndices[i]];
		EnemyInfo.HP = GetEnemyMaxHealth(SagaRow.Difficulty, EnemyInfo.Type, EnemyInfo.Level) + i;
	}

	// sorted by health
	OutEnemyInfos.StableSort([](const auto& Enemy1, const auto& Enemy2)
	{
		return Enemy1.HP > Enemy2.HP;
	});
}

int64 ACombatPresenter::GetEnemyMaxHealth(int32 InSagaDifficulty, int32 InEnemyType, int32 InLevel)
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(InEnemyType));
	FCMSAdditionalPointRow* AdditionalPoint = const_cast<FCMSAdditionalPointRow*>(GetCMS()->GetAdditionalPoint(InSagaDifficulty, UnitRow.AttributeCategory));
	if (!AdditionalPoint)
	{
		return UnitRow.HP;
	}

	int64 OutUnitMaxHealth;
	int64 OutUnitAtk;
	int64 OutUnitDef;
	Attribute::GetUnitAttribute(GetCMS(), UnitRow.AttributeCategory, UnitRow.CmsType(), InLevel, AdditionalPoint->Grade, AdditionalPoint,
		OutUnitMaxHealth, OutUnitAtk, OutUnitDef);

	return OutUnitMaxHealth;
}

void ACombatPresenter::AssignDropBox(FMT19937Uint32& InRng, const TArray<EItemGrade>& InItemGrades, bool bInIsSameGrades, const TArray<FEnemyInfo>& InEnemyInfos)
{
	const int32 EnemyNum = InEnemyInfos.Num();
	const int32 ItemNum = InItemGrades.Num();
	
	int32 CurItemNum = ItemNum;
	if (CurItemNum == 0)
	{
		return;
	}

	TArray<int32> RandomIndices;
	TArray<int32> IgnoreIndices;

	// 1st health enemy - (boss enemy)
	const int32 BossEnemyIndex = InEnemyInfos[0].Index;

	if (ItemNum < EnemyNum)
	{
		if (bInIsSameGrades)
		{
			// assign dropbox to boss enemy first
			AddDropBox(ItemDropInfos, BossEnemyIndex, InItemGrades[0]);
			CurItemNum--;

			IgnoreIndices.Add(BossEnemyIndex);
		}
		else
		{
			// assign rare dropbox to good health enemies orderly
			for (int32 i = 0; i < ItemNum; ++i)
			{
				if (InItemGrades[i] == EItemGrade::N)
				{
					break;
				}

				AddDropBox(ItemDropInfos, InEnemyInfos[i].Index, InItemGrades[i]);
				CurItemNum--;

				IgnoreIndices.Add(InEnemyInfos[i].Index);
			}
		}

		if (CurItemNum == 0)
		{
			return;
		}

		// assign normal dropbox to remain enemies randomly
		GetRandomIndices(InRng, RandomIndices, EnemyNum, IgnoreIndices);

		for (int32 i = 0; i < CurItemNum; ++i)
		{
			AddDropBox(ItemDropInfos, RandomIndices[i], InItemGrades[ItemNum - CurItemNum + i]);
		}
	}
	else
	{
		// assign dropbox to all enemies once
		for (int32 i = 0; i < EnemyNum; ++i)
		{
			AddDropBox(ItemDropInfos, InEnemyInfos[i].Index, InItemGrades[ItemNum - CurItemNum + i]);
		}

		CurItemNum -= EnemyNum;

		if (CurItemNum == 0)
		{
			return;
		}

		// assign remain dropbox to remain enemies
		for (int32 i = 0; i < CurItemNum; ++i)
		{
			EItemGrade ItemGrade = InItemGrades[ItemNum - CurItemNum + i];
			EDropBoxType DropBoxType = DropBoxSpawner->GetDropBoxType(ItemGrade);
			for (int32 j = 0; j < EnemyNum; ++j)
			{
				// assign the other grade dropbox only
				const int32 EnemyIndex = InEnemyInfos[j].Index;
				if (!ItemDropInfos[EnemyIndex].DropBoxes.Contains((int32)DropBoxType))
				{
					// enemies are sorted by hp already
					AddDropBox(ItemDropInfos, EnemyIndex, ItemGrade);
					break;
				}
			}
		}
	}
}

void ACombatPresenter::AddDropBox(TArray<FItemDropInfo>& InItemDropInfos, int32 InEnemyIndex, EItemGrade InItemGrade)
{
	EDropBoxType DropBoxType = DropBoxSpawner->GetDropBoxType(InItemGrade);

	int32* FoundDropBox = InItemDropInfos[InEnemyIndex].DropBoxes.Find((int32)DropBoxType);
	if (!FoundDropBox)
	{
		InItemDropInfos[InEnemyIndex].DropBoxes.Add((int32)DropBoxType, 1);
	}
	else
	{
		*FoundDropBox += 1;
	}
}

void ACombatPresenter::AssignGainGold(const TArray<FEnemyInfo>& InEnemyInfos)
{
	const FStageReward& StageReward = GetHUDStore().GetRewardManager().GetStageReward();
	const int32 TotalGainGold = StageReward.GainGold;

	int32 TotalHP = 0;
	for (const FEnemyInfo& EnemyInfo : InEnemyInfos)
	{
		TotalHP += EnemyInfo.HP;
	}

	if (TotalHP <= 0)
	{
		Q6JsonLogPawn(Error, "TotalHP is zero", Q6KV("TotalHP", TotalHP));
		return;
	}

	int32 SumGainGold = 0;
	for (const FEnemyInfo& EnemyInfo : InEnemyInfos)
	{
		ItemDropInfos[EnemyInfo.Index].WaveIndex = EnemyInfo.WaveIndex;
		ItemDropInfos[EnemyInfo.Index].Slot = EnemyInfo.Slot;

		const int32 GainGold = TotalGainGold * EnemyInfo.HP / TotalHP;
		ItemDropInfos[EnemyInfo.Index].GainGold = GainGold;
		SumGainGold += GainGold;
	}

	int32 DiffGainGold = TotalGainGold - SumGainGold;
	ItemDropInfos[InEnemyInfos[0].Index].GainGold += DiffGainGold;
}

void ACombatPresenter::GetRandomIndices(FMT19937Uint32& InRng, TArray<int32>& OutRandomIndices, int32 InNum, const TArray<int32>& InIgnoreIndices)
{
	OutRandomIndices.Reset(InNum);

	for (int32 i = 0; i < InNum; ++i)
	{
		if (!InIgnoreIndices.Contains(i))
		{
			OutRandomIndices.Add(i);
		}
	}

	Q6Util::ShuffleArray(InRng, OutRandomIndices);
}

bool ACombatPresenter::IsBonusWave(const FCMSWaveRow* InWaveRow) const
{
	return InWaveRow->AppearanceRatio < 1000;
}

void ACombatPresenter::ShowCombatMultiSideUnits()
{
	ForEachUnit([](AUnit& InUnit)
	{
		if (!InUnit.IsDead())
		{
			InUnit.EnableUnit();
		}
	});
}

void ACombatPresenter::HideCombatMultiSideUnits()
{
	ForEachUnit([this](AUnit& InUnit)
	{
		InUnit.DisableUnit();

		if (InUnit.GetOverrideFaction() == ECCFaction::Ally)
		{
			// move to ally camera out transform for entering movement
			InUnit.SetActorTransform(GetAllyCameraOutTransform(InUnit.GetSlot()));
		}
	});
}

void ACombatPresenter::SelectTarget(FCCUnitId InUnitId, bool bInByEvent)
{
	if (TargetedUnitId == InUnitId)
	{
		return;
	}

	TargetedUnitId = InUnitId;
	SetDecalVisible(true);

	if (bInByEvent)
	{
		// if target is selected by event, ComatHUD processes DebugCombatWidget & Tutorial
		GetCheckedCombatHUD(this)->OnSelectTarget(InUnitId);
	}
	else
	{
		GetCheckedCombatHUD(this)->SelectTarget(InUnitId);
	}
}
