// Fill out your copyright notice in the Description page of Project Settings.

#include "Projectile.h"
#include "Curves/CurveVector.h"
#include "DrawDebugHelpers.h"
#include "Q6Log.h"
#include "ParticleEmitterInstances.h"
#include "Particles/ParticleSpriteEmitter.h"
#include "Particles/ParticleSystemComponent.h"
#include "TimerManager.h"

static TAutoConsoleVariable<int32> CVarProjectile(
	TEXT("q6.projectile"),
	1,
	TEXT("1 : Normal. 0 : Disable. 2 : Debug\n"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarProjectileDurationAfterPassThrough(
	TEXT("q6.ProjectileDurationAfterPassThrough"),
	3.f,
	TEXT("time duration to deactivate after pass through the target"),
	ECVF_Cheat);

const static float HitDistance = 50;

AProjectile::AProjectile(const FObjectInitializer& ObjectInitializer) 
	: Super(ObjectInitializer)
	, MovingLocationOffsetCurve(nullptr)
	, OffsetRateMin(1.f)
	, OffsetRateMax(1.f)
	, AgeRatio(0.f)
	, ParticleRotation(EForceInit::ForceInitToZero)
	, Speed(0.f)
	, bPassThrough(false)
	, SourceUnit(nullptr)
	, TargetUnit(nullptr)
	, bUnitTarget(false)
	, StartLocation(EForceInit::ForceInitToZero)
	, TargetLocation(EForceInit::ForceInitToZero)
	, StartTime(0.f)
	, EstimatedLifeSpan(-1.f)
	, OffsetRate(1.f)
	, DirBeforeHit(EForceInit::ForceInitToZero)
	, HitStartTime(0.f)
	, LastHitTime(0.f)
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickGroup = TG_PrePhysics;
}

void AProjectile::BeginPlay()
{
	Super::BeginPlay();

	SetReplicates(false);
	
	if (CVarProjectile.GetValueOnGameThread() == 0)
	{
		Destroy();
	}

	TArray<UActorComponent*> Particles;
	GetComponents(UParticleSystemComponent::StaticClass(), Particles);

	for (auto& It : Particles)
	{
		UParticleSystemComponent* Particle = Cast<UParticleSystemComponent>(It);
		if (!Particle)
		{
			continue;
		}

		Particle->SetRelativeRotation(FQuat::MakeFromEuler(ParticleRotation));
	}

	OffsetRate = FMath::RandRange(OffsetRateMin, OffsetRateMax);
}

void AProjectile::UpdateHit()
{
	float TimeNow = GetWorld()->GetTimeSeconds();

	if (HitInfo.HitCount <= 0)
	{
		if (TimeNow - LastHitTime < HitInfo.PostDelay)
		{
			// sunny-to-check-working
			return;
		}

		if (!bPassThrough)
		{
			DestroyAfterDeactivate();
		}

		return;
	}

	if (TimeNow - HitStartTime < HitInfo.PreDelay)
	{
		return;
	}

	if (LastHitTime <= 0 || HitInfo.HitInterval <= TimeNow - LastHitTime)
	{
		if (SourceUnit)
		{
			SourceUnit->OnAnimNotifyHit(HitParticleParam, HitSoundParam);
		}

		LastHitTime = TimeNow;
		--HitInfo.HitCount;
	}
}

FVector AProjectile::GetMovingLocationOffset(float TimeRate) const
{
	if (!MovingLocationOffsetCurve)
	{
		return FVector::ZeroVector;
	}

	return MovingLocationOffsetCurve->GetVectorValue(TimeRate);
}

void AProjectile::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (DestroyTimer.IsValid())
	{
		return;
	}

	if (bUnitTarget)
	{
		if (!IsValid(TargetUnit))
		{
			Destroy();
			return;
		}

		// Update Target Location
		//FTransform TargetTransform = TargetUnit->GetSocketTransform(TargetSocket);
		//TargetLocation = TargetTransform.GetLocation();
	}

	bool bHitStarted = HitStartTime > 0.f;
	if (bHitStarted)
	{
		UpdateHit();
	}

	const FVector CurrentLocation = GetActorLocation();
	FVector Dir = TargetLocation - CurrentLocation;
	float Distance = Dir.Size();
	if (EstimatedLifeSpan < 0.0f)
	{
		if (Speed > 0.0f)
		{
			EstimatedLifeSpan = (Distance - HitDistance) / Speed;
			EstimatedLifeSpan = FMath::Clamp(EstimatedLifeSpan, 0.0f, 60.0f);
		}
		else
		{
			EstimatedLifeSpan = 1.0f;
		}

		StartTime = GetWorld()->GetTimeSeconds();
	}

	bool bPassingThrough = false;
	if (!bHitStarted)
	{
		if (Distance < HitDistance)
		{
			ProjectileHit();

			if (bPassThrough)
			{
				bPassingThrough = true;
				Dir = DirBeforeHit;
				GetWorldTimerManager().SetTimer(DeactivateTimer, this, &AProjectile::DestroyAfterDeactivate,
					CVarProjectileDurationAfterPassThrough.GetValueOnGameThread());
			}
			else
			{
				return;
			}
		}
		else
		{
			DirBeforeHit = Dir;
		}
	}
	else
	{
		if (!bPassThrough)
		{
			return;
		}
		else
		{
			bPassingThrough = true;
			Dir = DirBeforeHit;
			Distance = Speed * DeltaSeconds;
		}
	}

	// Update age
	float Age = GetWorld()->GetTimeSeconds() - StartTime;
	AgeRatio = (EstimatedLifeSpan > 0) ? Age / EstimatedLifeSpan : 1;
	AgeRatio = FMath::Clamp(AgeRatio, 0.0f, 1.0f);

	// Update transform
	FVector Location;
	if (bPassingThrough)
	{
		Location = CurrentLocation + (Dir.GetSafeNormal() * Distance);
	}
	else
	{
		FVector Offset = GetMovingLocationOffset(AgeRatio) * OffsetRate;
		Location = FMath::Lerp(StartLocation, TargetLocation, AgeRatio) + Offset;
		if (!Location.Equals(CurrentLocation))
		{
			Dir = Location - CurrentLocation;
		}
	}

	FQuat Rotation = Dir.GetSafeNormal().Rotation().Quaternion();

	FTransform NewTransform(FTransform::Identity);
	NewTransform.SetLocation(Location);
	NewTransform.SetRotation(Rotation);

	SetActorTransform(NewTransform);

	if (CVarProjectile.GetValueOnGameThread() > 1)
	{
		DrawDebugSphere(GetWorld(), TargetLocation, 10.0f, 20, FColor::Red);
		DrawDebugSphere(GetWorld(), CurrentLocation, 10.0f, 20, FColor::Green);
		DrawDebugString(GetWorld(), NewTransform.GetTranslation(), *(FString::Printf(TEXT("%.2f(%.2f/%.2f): %s"), 
			AgeRatio, Age, EstimatedLifeSpan, *GetName())), NULL, FColor::White, 0);
	}
}

void AProjectile::DeactivateParticles()
{
	DeactivateTimer.Invalidate();

	TArray<UActorComponent*> Particles;
	GetComponents(UParticleSystemComponent::StaticClass(), Particles);

	for (UActorComponent* It : Particles)
	{
		UParticleSystemComponent* Particle = Cast<UParticleSystemComponent>(It);
		if (!Particle)
		{
			continue;
		}

		if (!Particle->bWasDeactivated)
		{
			Particle->Deactivate();
		}
	}
}

void AProjectile::DestroyAfterDeactivate()
{
	DeactivateParticles();

	// Let projectile stay a little bit more for smoke-like effects
	GetWorldTimerManager().SetTimer(DestroyTimer, this, &AProjectile::OnDestroyTimeout, 3.f);
}

void AProjectile::OnDestroyTimeout()
{
	HitStartTime = 0.f;
	LastHitTime = 0.f;
	DestroyTimer.Invalidate();

#if !UE_BUILD_SHIPPING

	TArray<UActorComponent*> Particles;
	GetComponents(UParticleSystemComponent::StaticClass(), Particles);

	for (UActorComponent* It : Particles)
	{
		UParticleSystemComponent* Particle = Cast<UParticleSystemComponent>(It);
		if (!Particle)
		{
			continue;
		}

		if (Particle->GetNumActiveParticles() != 0)
		{
			Q6JsonLogObiwan(Error, "Projectile particle is still active after despawn delay",
				Q6KV("Particle", *Particle->Template->GetFullName()),
				Q6KV("Active count", Particle->GetNumActiveParticles()));

			for (const FParticleEmitterInstance* EmitterInstance : Particle->EmitterInstances)
			{
				if (EmitterInstance && EmitterInstance->ActiveParticles > 0)
				{
					Q6JsonLogObiwan(Error, "Emitter Info",
						Q6KV("Name", *EmitterInstance->SpriteTemplate->GetEmitterName().ToString()),
						Q6KV("Active count", EmitterInstance->ActiveParticles));
				}
			}
		}
	}

#endif

	Destroy();
}

void AProjectile::ProjectileHit()
{
	TArray<UActorComponent*> Particles;
	GetComponents(UParticleSystemComponent::StaticClass(), Particles);

	for (auto& It : Particles)
	{
		UParticleSystemComponent* Particle = Cast<UParticleSystemComponent>(It);
		if (!Particle)
		{
			continue;
		}

		Particle->GenerateParticleEvent("Hit", 0, FVector::ZeroVector, FVector::ZeroVector, FVector::ZeroVector);
	}

	HitStartTime = GetWorld()->GetTimeSeconds();
	LastHitTime = 0.f;

	OnProjectileHit();
}

FVector AProjectile::GetTargetBottomLocation() const
{
	if (!IsValid(TargetUnit))
	{
		return GetActorLocation();
	}

	return TargetUnit->GetBottomTransform().GetLocation();
}

void AProjectile::SetTargetUnit(AUnit* Unit, const FName& Socket, const FPostHitInfo& InHitInfo, const FSpawnParticleParams& InHitParticleParam, const FSpawnSoundParams& InHitSoundParam)
{
	bUnitTarget = true;
	TargetUnit = Unit;
	TargetSocket = Socket;

	HitInfo = InHitInfo;
	HitParticleParam = InHitParticleParam;
	HitSoundParam = InHitSoundParam;
}
