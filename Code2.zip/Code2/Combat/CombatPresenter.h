// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Containers/CircularQueue.h"
#include "CCTypes.h"
#include "CCEvent.h"
#include "CombatCube.h"
#include "Q6Define.h"
#include "Unit.h"
#include "DropBox.h"
#include "GameFramework/Actor.h"
#include "CombatPresenter.generated.h"

static const int32 MAX_QUEUED_EVENT_COUNT = 1000;

class ACombatLocator;
class ACombatPresenter;
class ACameraLayerActor;
class ALevelSequenceActor;
class ALoot;
class APetUnit;
class ASkeletalMeshActor;
class AUnit;
class UAutomationHelper;
class UCharacterManager;
class UCPInstanceBase;
class UCPSkillInstance;
class UCPMomentSkillInstance;
class UCPBuffInstance;
class UCPSpawnInstance;
class UCPDeadInstance;
class UCPUnitApplyEffectLabelInstance;
class UCPUnitNoticeInstance;
class UCPPointInstance;
class UCPPointVaryInstance;
class UDebugCombatWidget;
class UGameAssetCache;
class ULevelSequencePlayer;
class UParticleSystemComponent;
class UQ6CombatGameStateMgr;

struct FSkillAnimHitInfo;
struct FUnitState;

enum class ELootDropType : uint8;

struct FDynamicParticleInfo
{
	FDynamicParticleInfo()
		: Type()
		, Particle(nullptr)
		, PlayStartTime(0.f)
		, Duration(0.f)
		, bDestroyAtEnd(true)
		, TargetUnit(nullptr)
		, TargetSocket()
		, TargetSocketOffset(0.f)
	{}

	enum EType
	{
		Invalid,
		Beam,
	};

	EType Type;
	TWeakObjectPtr<UParticleSystemComponent> Particle;

	float PlayStartTime;
	float Duration;
	bool bDestroyAtEnd;

	AUnit* TargetUnit;
	FName TargetSocket;
	FVector TargetSocketOffset;
};

struct FSpawnedSkeletalMeshInfo
{
	FSpawnedSkeletalMeshInfo()
		: Actor(nullptr)
		, EndTime(0.0f)
	{}

	TWeakObjectPtr<ASkeletalMeshActor> Actor;
	float EndTime;
};

static FORCEINLINE bool IsAnyAttackPhase(ECCTurnPhase InTurnPhase)
{
	return InTurnPhase == ECCTurnPhase::Attack || InTurnPhase == ECCTurnPhase::OppAttack;
}

USTRUCT()
struct FSkillDrivenInfo
{
	GENERATED_USTRUCT_BODY()

	FSkillDrivenInfo()
		: SkillId(CCSkillIdInvalid)
		, SkillCategory(ESkillCategory::Normal)
		, SkillOwnerUnitId(CCUnitIdInvalid)
		, bRestoreTurnPrepareUnitsOnEnd(false)
	{}

	void Init(FCCSkillId InSkillId, ESkillCategory InSkillCategory, FCCUnitId InUnitId)
	{
		SkillId = InSkillId;
		SkillCategory = InSkillCategory;
		SkillOwnerUnitId = InUnitId;
		bRestoreTurnPrepareUnitsOnEnd = false;
	}

	bool IsEmpty() const { return !Instances.Num(); }
	void AddInstance(const UCPInstanceBase* InInstance)
	{
		Instances.Add(InInstance);
	}

	bool ShouldRestoreTurnPrepareUnitsOnEnd() const { return bRestoreTurnPrepareUnitsOnEnd; }
	void SetRestoreTurnPrepareUnitsOnEnd(bool bInRestore) { bRestoreTurnPrepareUnitsOnEnd = bInRestore; }

	UPROPERTY()
	TArray<const UCPInstanceBase*> Instances;

	UPROPERTY()
	FCCSkillId SkillId;

	UPROPERTY()
	ESkillCategory SkillCategory;

	UPROPERTY()
	FCCUnitId SkillOwnerUnitId;

	UPROPERTY()
	bool bRestoreTurnPrepareUnitsOnEnd;
};

USTRUCT()
struct FMomentInstancesInfo
{
	GENERATED_BODY()

	FMomentInstancesInfo()
		: LabelInstance(nullptr)
	{}

	UPROPERTY()
	UCPUnitApplyEffectLabelInstance* LabelInstance;

	UPROPERTY()
	TArray<UCPUnitNoticeInstance*> UnitNoticeInstances;

	UPROPERTY()
	TArray<UCPMomentSkillInstance*> MomentSkillInstances;
};

struct FUnitFilter
{
	// Return true if included
	virtual bool Filter(const AUnit& Unit) const = 0;
};

USTRUCT(BlueprintType)
struct FMasterState
{
	GENERATED_BODY()

	UPROPERTY()
	FCCUnitId MasterId;

	UPROPERTY()
	TArray<FSkillState> Pets;

	UPROPERTY()
	TArray<FSkillState> Artifacts;
};

USTRUCT()
struct FCharacterUnitInfo
{
	GENERATED_USTRUCT_BODY()

	FCharacterUnitInfo()
		: CharacterId(FCharacterId::InvalidValue())
		, CharacterType(CharacterTypeInvalid)
		, UnitId(CCUnitIdInvalid)
		, UnitType(UnitTypeInvalid)
	{}

	UPROPERTY()
	FCharacterId CharacterId;

	UPROPERTY()
	FCharacterType CharacterType;

	UPROPERTY()
	FCCUnitId UnitId;

	UPROPERTY()
	FUnitType UnitType;
};

USTRUCT()
struct FItemDropInfo
{
	GENERATED_USTRUCT_BODY()

	FItemDropInfo()
		: GainGold(0), WaveIndex(0), Slot(0)
	{}

	UPROPERTY()
	TMap<int32, int32> DropBoxes;

	UPROPERTY()
	int32 GainGold;

	UPROPERTY()
	int32 WaveIndex;

	UPROPERTY()
	int32 Slot;
};

USTRUCT()
struct FEnemyInfo
{
	GENERATED_USTRUCT_BODY()

	FEnemyInfo()
		: WaveIndex(0)
		, Slot(0)
		, Type(0)
		, Level(0)
		, Index(0)
	{}

	FEnemyInfo(int32 InWaveIndex, int32 InSlot, int32 InType, int32 InLevel, int32 InIndex)
		: WaveIndex(InWaveIndex)
		, Slot(InSlot)
		, Type(InType)
		, Level(InLevel)
		, Index(InIndex)
	{}

	UPROPERTY()
	int32 WaveIndex;

	UPROPERTY()
	int32 Slot;

	UPROPERTY()
	int32 Type;

	UPROPERTY()
	int32 Level;

	UPROPERTY()
	int32 Index;

	UPROPERTY()
	int32 HP;
};

/*
 * ACombatPresenter
 * It reflect CombatCube's state by using UE4 Engine.
 */
UCLASS()
class Q6_API ACombatPresenter : public AActor
{
	GENERATED_BODY()

public:	
	ACombatPresenter(const FObjectInitializer& ObjectInitializer);

	void BindCombatCubeEvent(ACombatCube* InCombatCube);
	void SynchronizeCCState(const FCCCombatCubeState& InState);
	void PostSynchronizeCCState();

	void BindCombatCameraToController();

	AUnit* FindUnit(FCCUnitId InUnitId);
	const AUnit* FindUnit(FCCUnitId InUnitId) const;
	TArray<AUnit*> FindUnitsByFaction(ECCFaction InFaction);
	TArray<AUnit*> FindAliveUnitPerSlotByFaction(ECCFaction InFaction);	// the element is nullable
	TArray<FCCUnitId> FindUltimateReadyEnemyIds();
	TArray<int32> FindDeadUnitSlotsByFaction(ECCFaction InFaction);

	bool IsMaster(FCCUnitId InUnitId);
	const FMasterState& GetAllyMaster() const;

	APetUnit* GetPetUnit() const { return PetUnit; }

	void UpdateDebugState(UDebugCombatWidget* DebugCombatWidget);
	UAutomationHelper* GetAutomationHelper() const { return AutomationHelper; }

	bool IsCurrentCombatMultiSideUnit(const AUnit* Unit) const;
	bool IsBossRewardWave() const;

	int32 GetBossRewardNumber();

	// visiting each unit with callback
	template<typename T>
	void ForEachUnit(T Callback)
	{
		for (auto IterUnitId : SpawnedUnitIds)
		{
			AUnit* CurUnit = FindUnit(IterUnitId);
			if (!CurUnit)
			{
				continue;
			}

			if (!IsCurrentCombatMultiSideUnit(CurUnit))
			{
				continue;
			}

			Callback(*CurUnit);
		}
	}

	// const version of above method
	template<typename T>
	void ForEachUnit(T Callback) const
	{
		for (auto IterUnitId : SpawnedUnitIds)
		{
			const AUnit* CurUnit = FindUnit(IterUnitId);
			if (!CurUnit)
			{
				continue;
			}

			if (!IsCurrentCombatMultiSideUnit(CurUnit))
			{
				continue;
			}

			Callback(*CurUnit);
		}
	}

	// The method executes the callback function once for each unit
	// until it finds one where callback returns false.
	// If such an unit is found, the method immediately returns false.
	// Otherwise, if callback returns a true for all units, the method returns true
	template<typename T>
	bool IsEveryUnit(T Callback) const
	{
		for (auto IterUnitId : SpawnedUnitIds)
		{
			const AUnit* CurUnit = FindUnit(IterUnitId);
			if (!CurUnit)
			{
				continue;
			}

			if (!IsCurrentCombatMultiSideUnit(CurUnit))
			{
				continue;
			}

			if (!Callback(*CurUnit))
			{
				return false;
			}
		}

		return true;
	}


	// The method executes the callback function once for each unit
	// until it finds one where callback returns true(or true evaluated).
	// If such an unit is found, the method immediately returns the value from callback.
	// Otherwise, it returns false
	// ReturnType should be evaluated with if
	template<typename T>
	bool IsAnyUnit(T Callback) const
	{
		for (auto IterUnitId : SpawnedUnitIds)
		{
			const AUnit* CurUnit = FindUnit(IterUnitId);
			if (!CurUnit)
			{
				continue;
			}

			if (!IsCurrentCombatMultiSideUnit(CurUnit))
			{
				continue;
			}

			if (Callback(*CurUnit))
			{
				return true;
			}
		}

		return false;
	}

protected:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
	virtual void Tick(float DeltaTime) override;

	const ACombatLocator* GetCombatLocator() const { return CombatLocator; }
	const ACameraLayerActor* GetCameraLayerActor() const { return CameraLayerActor; }
	ACameraLayerActor* GetCameraLayerActor() { return CameraLayerActor; }

	// CPInstances related
	bool HasEventQueued(ECCEventType InTargetEventType, ECCEventType InEndEventType) const;

	template<typename T>
	T* CreateInstance()
	{
		T* Instance = NewObject<T>(this);
		if (Instance)
		{
			Instance->SetCombatPresenter(this);
			Instance->SetInstanceId(InstanceId);
			Instance->OnInstanceState.BindUObject(this, &ACombatPresenter::OnInstanceState);
			InstanceId.X++;
		}

		return Instance;
	}

	template<typename T, typename U>
	T* CreateInstance(const U* InCCEvent)
	{
		T* Instance = NewObject<T>(this);
		if (Instance)
		{
			Instance->SetCombatPresenter(this);
			Instance->SetInstanceId(InstanceId);
			Instance->SetCCEvent(InCCEvent);
			Instance->OnInstanceState.BindUObject(this, &ACombatPresenter::OnInstanceState);
			InstanceId.X++;
		}

		return Instance;
	}

	UCPSkillInstance* CreateSkillInstance(const UCCSkillUsedEvent* InSkillUsedEvent);

	void OnSkillDrivenEffectEnd();

	// Unit related
	AUnit* SpawnUnit(const FCCUnitState& InUnitState, bool bSpawnOutCam, bool bBlockingLoad = false);
	APetUnit* SpawnPetUnit();

	FTransform GetWaveTransform(ECCFaction InFaction, int32 Slot) const;
	FTransform GetAllyCameraOutTransform(int32 Slot) const;
	FTransform GetPetTransform() const;
	FVector GetFactionAllTargetLocation(ECCFaction InFaction) const;

	int32 GetWaveEnemyNumSlots() const;
	bool IsWaveEnemyDefaultPosition() const;

	UFUNCTION(BlueprintCallable, Category = "CombatPresenter")
	const FCCCombatSeed& GetCombatSeed() const;

	int64 GetStartBattleEpoch() const { return StartBattleEpoch; }

	int32 GetSlotByUnitId(FCCUnitId UnitId);

	const FUnitState& GetCharacterStateBySlot(int32 Slot) const;
	const FUnitState& GetMonsterStateBySlot(int32 Slot) const;

	ENatureRelationType GetUnitNatureRelationType(const FCCUnitId& SourceUnitId, const FCCUnitId& TargetUnitId) const;
	int32 GetSurvivorsCount(ECCFaction InFaction) const;
	TArray<const AUnit*> GetSupporters(FCCUnitId SkillUsedUnitId) const;
	FCCUnitId GetLastSkillUsedUnitId() const { return LastSkillUsedUnitId; }

	FPetType GetPetType() const;
	int32 GetPetSkillIndex(FCCSkillId InSkillId) const;

	FCharacterType GetAllyCharacterType(FCCUnitId UnitId) const;

	ECPTurnPhase CCPhaseToCPPhase(ECCTurnPhase InTurnPhase) const;
	void ChangeToEnemyUltimateReadyPhase();
	void ChangeToTurnSkillPhase();
	void ChangeToSteadyPhase();

	ECCTurnPhase GetTurnPhase() const { return PresentTurnPhase; }
	int32 GetTurnCount() const { return TurnCount; }
	int32 GetTurnCountForWidget() const;
	int32 GetTotalWaveNum() const { return TotalWaveNum; }
	int32 GetLocatorGroup() const { return LocatorGroup; }
	int32 GetWave() const { return Wave; }
	int32 GetWaveIndex() const { return Wave - 1; }

	ECombatMultiSide GetCurrentCombatMultiSide() const { return CurrentCombatMultiSide; }
	int32 GetCombatMultiSideWaveRowIndex() const { return CombatMultiSideWaveRowIndex; }
	int32 GetWaveRowIndex() const;

	UFUNCTION(BlueprintPure, Category = "CombatPresent")
	ECCResult GetGameResult() const { return PresentResult; }

	bool IsGameFinished() const { return PresentResult != ECCResult::Unknown; }
	bool IsLastWave() const { return (Wave >= TotalWaveNum); }

	// Camera Fade
	void StartCameraFadeIn() const;
	void StartCameraFadeOut() const;
	void SetCameraFadeBlackOut() const;

	// Multi-layer rendering unit control
	void PickTurnPrepareUnit(FCCUnitId InUnitId, bool bInPlaySpawnAnim = true);
	void DropTurnPrepareUnits();
	void RestoreTurnPrepareUnits();

	// Target Control
	bool TargetMonsterIfCurrentIsDead();
	FCCUnitId GetTargetUnitId() const { return TargetedUnitId; }

	// Decal Control
	void SetDecalVisible(bool bVisible);

	// Wave Sequence
	void StartCutScene(int32 Episode, int32 Stage, bool bIntro, const UCCStartWaveEvent* Event = nullptr);
	void StartWave(const UCCStartWaveEvent* Event);
	void FinishWave(bool bSkipFinishWaveAnim);

	// Projectile related
	void SpawnProjectile(const FSpawnProjectileParams& Params);
	
	// World Particle Related
	void SpawnWorldParticle(const FVector& InLocation, const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam);

	// Beam Particle related
	void SpawnBeamParticle(const FSpawnBeamParticleParams& Params);

	// SkeletalMesh related
	void SpawnSkeletalMesh(const FSpawnSkeletalMeshParams& Params);

	// Loot
	FVector GetLootTargetLocation(ELootDropType InLootType, const FVector& SourceLocation);
	void SpawnLoot(AUnit* InSourceUnit, ELootDropType InLootType, int32 InLootCount, int32 InLootDropCount);
	void CollectLoot(AUnit* InUnit);

	// DropBox
	void SpawnDropBox(FCCUnitId InUnitId);
	float GetSpawnDropBoxRemainTime();
	void SetInvisibleDropBox(const AUnit* InEnemyUnit);

	// time limit, turn limit
	void SetStartBattleEpoch(int64 Epoch) { StartBattleEpoch = Epoch; }

	void SetCombatMissionInfo();

	void UpdateFinishCondition() const;

	// Item Drop
	const TArray<FItemDropInfo>& GetItemDropInfo() const { return ItemDropInfos; }
	const TArray<FItemDropInfo>& GetRandomSpawnItemDropInfo() const { return RandomSpawnItemDropInfos; }

	void SelectProvokedTarget(FCCUnitId InUnitId);
	void RestoreSelectTarget();

private:
	UFUNCTION()
	void OnCombatCubeEvent(const UCCEvent* Event);

	// Queued event callbacks
	void OnReportError(const UCCReportErrorEvent* Event);
	void OnStartGame(const UCCStartGameEvent* Event);
	void OnAllyWipeout(const UCCAllyWipeoutEvent* Event);
	void OnEndGame(const UCCEndGameEvent* Event);
	void OnStartWave(const UCCStartWaveEvent* Event);
	void OnTakeTurn(const UCCTakeTurnEvent* Event);
	void OnFinishWave(bool bSkipFinishWaveAnim);
	void OnStartTurn(const UCCStartTurnEvent* Event);
	void OnUpdateBuffDurations(const UCCUpdateBuffDurationsEvent* Event);
	void OnStartPhase(const UCCStartPhaseEvent* Event);
	void OnSpawnUnit(const UCCSpawnUnitEvent* Event);
	void OnDespawnUnit(const UCCDespawnUnitEvent* Event);
	void OnUnitDead(const UCCUnitDeadEvent* Event);
	void OnCreateBuff(const UCCCreateBuffEvent* Event);
	void OnRemoveBuff(const UCCRemoveBuffEvent* Event);
	void OnRemoveBuffFailed(const UCCRemoveBuffFailedEvent* Event);
	void OnImmuneBuff(const UCCImmuneBuffEvent* Event);
	void OnDamageBuff(const UCCDamageBuffEvent* Event);
	void OnHealBuff(const UCCHealBuffEvent* Event);
	void OnSelectTarget(const UCCTargetSelectedEvent* Event);
	void OnSkillFailed(const UCCSkillFailedEvent* Event);
	void OnAttackPass(const UCCAttackPassEvent* Event);
	void OnSkillUsed(const UCCSkillUsedEvent* Event);
	void OnSkillEffect(const UCCSkillEffectEvent* Event);
	void OnSkillEnd(const UCCSkillEndEvent* Event);
	void OnPointVaryUsed(const UCCPointVaryUsedEvent* Event);
	void OnPointVaryStateChanged(const UCCPointVaryStateChangedEvent* Event);
	void OnPointVaryEnd(const UCCPointVaryEndEvent* Event);
	void OnUpdateAttributes(const UCCUpdateAttributesEvent* Event);
	void OnHealthChanged(const UCCUnitHealthChangedEvent* Event);
	void OnUAChanged(const UCCUnitUAChangedEvent* Event);
	void OnSAChanged(const UCCUnitSAChangedEvent* Event);
	void OnOverKillChanged(const UCCUnitOverKillChangedEvent* Event);
	void OnSetSkillCooldown(const UCCSetSkillTimeEvent* Event);
	void OnSetCheatSkillCooldown(const UCCSetCheatSkillCooldownEvent* Event);
	void OnRaidTurnSkillEffect(const UCCRaidTurnSkillEffectEvent* Event);
	void OnRaidTurnSkillFinished(const UCCRaidTurnSkillFinishedEvent* Event);
	void OnRaidSkillUsed(const UCCRaidSkillUsed* Event);
	void OnCombatWeeklyMission(const UCCMissionEvent* Event);
	void OnSelectedPatternUltimate(const UCCSelectedPatternUltimate* Event);
	void OnEnemyAttackPass(const UCCEnemyAttackPassEvent* Event);
	void OnChangeCombatMultiSide(const UCCChangeCombatMultiSide* Event);

	void PumpEvent();
	const UCCEvent* PeekEvent() const;
	void EnqueueEvent(const UCCEvent* Event);
	const UCCEvent* DequeueEvent();

	// CPInstances related
	void OnInstanceState(ECPInstanceState InstanceState, UCPInstanceBase* Instance);
	void UpdateInstance(float DeltaTime);

	FMomentInstancesInfo* GetMomentInstancesInfo(EMoment InMoment);
	void InitMomentInstancesInfo();
	void InitOrAddMomentLabelInfo(FMomentInstancesInfo& InInfo, EMoment InMoment, FCCUnitId InUnitId);
	void InitBuffInstance(EMoment SkillMoment);
	void InitPointInstance(EMoment SkillMoment);
	void InitSetSkillTimeInstance(const UCCSetSkillTimeEvent* InSetSkillTimeEvent);

	bool PrepareMomentInstances(FMomentInstancesInfo& InMomentInstancesInfo, bool bSkipAction);
	void PrepareUnitApplyEffectLabelInstance(UCPUnitApplyEffectLabelInstance*& UnitApplyEffectLabelInstance);
	void PrepareUnitNoticeInstances(TArray<UCPUnitNoticeInstance*>& UnitNoticeInstances, bool bSkipAction, bool bSkillDriven = false);
	void PrepareMomentSkillInstances(TArray<UCPMomentSkillInstance*>& MomentSkillInstances, bool bSkipAction);

	bool PrepareDeadUnitMomentInstances(const TArray<FCCUnitId>& DeadUnitIds);
	void AddDeadUnitApplyEffectLabelInstance(const TArray<FCCUnitId>& DeadUnitIds, FMomentInstancesInfo& InOutMomentInstances);
	void AddDeadUnitNoticeInstances(const TArray<FCCUnitId>& DeadUnitIds, FMomentInstancesInfo& InOutMomentInstances);
	void AddDeadUnitMomentSkillInstances(const TArray<FCCUnitId>& DeadUnitIds, FMomentInstancesInfo& InOutMomentInstances);
	void PrepareDeadUnitSpawnInstances(const TArray<FCCUnitId>& DeadUnitIds);

	// Unit related
	AUnit* CreateUnit(const FCCUnitState& UnitState, bool bSpawnOutCam);
	AUnit* CreateMainPartUnit(const FCCUnitState& UnitState);
	AUnit* CreateSubPartUnit(const FCCUnitState& UnitState);

	// Projectile related
	void SpawnProjectileInternal(const FSpawnProjectileParams& Params);
	void UpdateSpawnProjectiles();
	void DespawnAllProjectiles();

	// Beam Particle related
	void SpawnBeamParticleInternal(const FSpawnBeamParticleParams& Params);
	void UpdateSpawnBeamParticles();

	// Dynamic Particle related (Beam only for now)
	void UpdateDynamicParticles();
	void DespawnAllDynamicParticles();

	// Skeletal Mesh
	void SpawnSkeletalMeshInternal(const FSpawnSkeletalMeshParams& Params);
	void UpdateSpawnSkeletalMeshes();
	void DespawnAllSkeletalMeshes();

	// Asset Caches
	void CacheStageAssets();
	void ReleaseStageAssets();
	void CacheStageSequences();
	void CachePetAssets();
	void CacheCharacterAssets();
	void CacheMonsterAssets();

	// Pre Rendering
	void PreSpawnUnitAssets();
	void CleanUpPreSpawnedUnitAssets();

	// Camera Fade
	bool IsCameraFading() const;
	void OnCameraBlendingFinished(bool bRestoring);

	// Character
	void SetAllyCharacterUnit(AUnit* InUnit, FCCUnitId InUnitId, FUnitType InUnitType);
	void AddCharacterUnitInfo(const UCharacterManager& CharacterManager, FCharacterId CharacterId);
	void SetCharacterUnitInfos();

	// Item Drop
	void SetItemDropInfo();
	void SetRandomSpawnItemDropInfo(TArray<TArray<bool>>& OutHasRandomSpawnItemDropInfos);
	bool GatherItemGrades(const TArray<FItemData>& InItemList, TArray<EItemGrade>& OutItemGrades);
	EItemGrade GetItemGrade(ELootCategory InCategory, int32 InItemType);
	void GatherEnemyInfos(FMT19937Uint32& InRng, TArray<FEnemyInfo>& OutEnemyInfos, const TArray<TArray<bool>>& InHasRandomSpawnItemDropInfos);
	int64 GetEnemyMaxHealth(int32 InSagaDifficulty, int32 InEnemyType, int32 InLevel);
	void AssignDropBox(FMT19937Uint32& InRng, const TArray<EItemGrade>& InItemGrades, bool bInIsSameGrades, const TArray<FEnemyInfo>& InEnemyInfos);
	void AssignGainGold(const TArray<FEnemyInfo>& InEnemyInfos);
	void AddDropBox(TArray<FItemDropInfo>& InItemDropInfos, int32 InEnemyIndex, EItemGrade InItemGrade);
	void GetRandomIndices(FMT19937Uint32& InRng, TArray<int32>& OutRandomIndices, int32 InNum, const TArray<int32>& InIgnoreIndices);
	bool IsBonusWave(const FCMSWaveRow* InWaveRow) const;

	// Combat Multi Side
	void ShowCombatMultiSideUnits();
	void HideCombatMultiSideUnits();

	void SelectTarget(FCCUnitId InUnitId, bool bInByEvent);

	UPROPERTY()
	TArray<const UCCEvent*> QueuedEvents;

	UPROPERTY()
	TArray<UCPInstanceBase*> QueuedInstances;

	UPROPERTY()
	TArray<UCPInstanceBase*> NonBlockingQueuedInstances;

	UPROPERTY()
	TArray<FMasterState> Masters;

	UPROPERTY()
	TArray<AUnit*> SpawnedUnits;

	UPROPERTY()
	TSet<FCCUnitId> SpawnedUnitIds;

	UPROPERTY(Transient)
	ACombatLocator* CombatLocator;

	UPROPERTY(Transient)
	ACameraLayerActor* CameraLayerActor;

	UPROPERTY()
	APetUnit* PetUnit;

	UPROPERTY(Transient)
	FSkillDrivenInfo SkillDrivenInfo;

	UPROPERTY(Transient)
	UCPSkillInstance* SkillInstance;

	UPROPERTY(Transient)
	UCPPointInstance* PointInstance;

	UPROPERTY(Transient)
	UCPPointVaryInstance* PointVaryInstance;

	UPROPERTY(Transient)
	UCPBuffInstance* SkillBuffInstance;

	UPROPERTY(Transient)
	TArray<UCPUnitNoticeInstance*> SkillUnitNoticeInstances;

	UPROPERTY(Transient)
	FMomentInstancesInfo OnTurnBeginMomentInstancesInfo;

	UPROPERTY(Transient)
	FMomentInstancesInfo OnAttackedMomentInstancesInfo;

	UPROPERTY(Transient)
	FMomentInstancesInfo OnAttackMomentInstancesInfo;

	UPROPERTY(Transient)
	UCPSpawnInstance* SpawnInstance;

	UPROPERTY(Transient)
	TArray<UCPSpawnInstance*> SkillSpawnInstances;

	UPROPERTY(Transient)
	TArray<UCPSpawnInstance*> SubPartySpawnInstances;

	UPROPERTY(Transient)
	TArray<UCPDeadInstance*> SkillDeadInstances;

	ECCTurnPhase PresentTurnPhase;
	ECCResult PresentResult;
	bool bEnemyUltimateReadyPhase;
	bool bSteadyPhase;

	// Event vars
	int32 PushIndex;
	int32 PopIndex;

	int32 LocatorGroup;
	int32 Wave;
	int32 WaveEnemyNumSlots;
	bool bWaveEnemyDefaultPosition;

	int32 TurnCount;
	int32 TotalWaveNum;
	int64 StartBattleEpoch;

	FCCCombatSeed CombatSeed;

	FCCUnitId TargetedUnitId;
	FCCUnitId LastSkillUsedUnitId;
	FCCUnitId RestoredUnitId;

	FCPInstanceId InstanceId;

	FMomentInstancesInfo* LastMomentInstancesInfo;

	ECombatMultiSide CurrentCombatMultiSide;
	int32 CombatMultiSideWaveRowIndex;
	int32 CombatMultiSideTurnCount;

	// FSM
	UPROPERTY(Transient)
	UQ6CombatGameStateMgr* CGStateMgr;
	friend class UQ6CombatGameStateMgr;

	/**
	* Delay-Spawning queues
	* we spawn only few objects for each tick to avoid sudden spike
	*/
	TUniquePtr<TCircularQueue<FSpawnProjectileParams>> SpawnProjectileQueue;
	TUniquePtr<TCircularQueue<FSpawnBeamParticleParams>> SpawnBeamParticleQueue;
	TUniquePtr<TCircularQueue<FSpawnSkeletalMeshParams>> SpawnSkeletalMeshQueue;

	TArray<FDynamicParticleInfo> DynamicParticleInfos;
	TArray<FSpawnedSkeletalMeshInfo> SpawnedSkeletalMeshInfos;

	// Character
	TArray<FCharacterUnitInfo> AllyCharacterUnitInfos;

	// Loot
	UPROPERTY(Transient)
	TArray<ALoot*> LootActors;

	// Resources
	UPROPERTY(Transient)
	UGameAssetCache* PetUnitCache;

	UPROPERTY(Transient)
	TArray<UGameAssetCache*> CharacterUnitCaches;

	UPROPERTY(Transient)
	TArray<UGameAssetCache*> MonsterUnitCaches;

	UPROPERTY(Transient)
	TArray<AProjectile*> UnitProjectileCaches;

	UPROPERTY(Transient)
	TArray<UParticleSystemComponent*> UnitParticleCaches;

	UPROPERTY(Transient)
	TArray<AUnit*> MaterialCacheUnits;

	UPROPERTY(Transient)
	UGameAssetCache* SequenceCache;

	double UnitAssetPreSpawnedTime;
	double UnitAssetPreSpawnCleanupTime;

	UPROPERTY(Transient)
	UAutomationHelper* AutomationHelper;

	TArray<FItemDropInfo> ItemDropInfos;
	TArray<FItemDropInfo> RandomSpawnItemDropInfos;

	UPROPERTY(Transient)
	UDropBoxSpawner* DropBoxSpawner;
};
