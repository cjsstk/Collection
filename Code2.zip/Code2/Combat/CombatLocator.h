// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "GameFramework/Actor.h"
#include "Q6Define.h"
#include "CombatLocator.generated.h"

class UCombatCameraComponent;
class UBillboardComponent;
class UArrowComponent;
class UTextRenderComponent;
class AUnit;

UCLASS()
class Q6_API ACombatLocator : public AActor
{
	GENERATED_BODY()
	
public:	
	ACombatLocator(const FObjectInitializer& ObjectInitializer);

	UFUNCTION(BlueprintCallable, Category = "Group")
	int32 GetGroup() const { return Group; }

	UFUNCTION(BlueprintCallable, Category = "Wave")
	int32 GetWave() const { return Wave; }

	UFUNCTION(BlueprintCallable, Category = "CombatMultiSide")
	ECombatMultiSide GetCombatMultiSide() const { return CombatMultiSide; }

	UFUNCTION(BlueprintCallable, Category = "Wave")
	bool IsDefaultLocator() const { return (Wave == 0); }

	UFUNCTION(BlueprintCallable, Category = "Wave")
	bool IsCorrectLocator(int32 InGroup, int32 InWave, ECombatMultiSide InSide) const;

	float GetBottomLocationZ() const { return GetActorLocation().Z; }

	UCombatCameraComponent* GetCamera(ECombatCamera CameraType) const;
	UStaticMeshComponent* GetModelPosition() const { return ModelPosition; }
	FTransform GetAllyTransform(int32 Slot) const;
	FTransform GetEnemyTransform(int32 Slot, int32 NumSlots, bool bForceDefault) const;
	FTransform GetAllTargetTransform(ECCFaction Faction) const;
	FTransform GetPetTransform() const { return PetPosition->GetComponentTransform(); }
	ECombatMultiSide GetCurrentCombatMultiSide() const { return CombatMultiSide; }

#if WITH_EDITOR
	virtual void PostLoad() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;

	void UpdateTextRenderText();
#endif

protected:
	virtual void BeginPlay() override;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* WaveCamera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* PrepareCamera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* AllyAllCamera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Ally1Camera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Ally2Camera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Ally3Camera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* EnemyAllCamera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Enemy1Camera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Enemy2Camera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Enemy3Camera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Enemy4Camera;

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* Enemy5Camera;

	UPROPERTY(EditAnywhere, Category = "AllyPosition")
	USceneComponent* Ally1Position;

	UPROPERTY(EditAnywhere, Category = "AllyPosition")
	USceneComponent* Ally2Position;

	UPROPERTY(EditAnywhere, Category = "AllyPosition")
	USceneComponent* Ally3Position;

	UPROPERTY(EditAnywhere, Category = "ModelPosition")
	UStaticMeshComponent* ModelPosition;

	UPROPERTY(EditAnywhere, Category = "PetPosition")
	USceneComponent* PetPosition;

	UPROPERTY(EditAnywhere, Category = "EnemyPosition")
	USceneComponent* Enemy1Position;

	UPROPERTY(EditAnywhere, Category = "EnemyPosition")
	USceneComponent* Enemy2Position;

	UPROPERTY(EditAnywhere, Category = "EnemyPosition")
	USceneComponent* Enemy3Position;

	UPROPERTY(EditAnywhere, Category = "EnemyPosition")
	USceneComponent* Enemy4Position;

	UPROPERTY(EditAnywhere, Category = "EnemyPosition")
	USceneComponent* Enemy5Position;

	UPROPERTY(EditAnywhere, Category = "AllTargetPosition")
	USceneComponent* AllyAllTargetPosition;

	UPROPERTY(EditAnywhere, Category = "AllTargetPosition")
	USceneComponent* EnemyAllTargetPosition;

private:
	UPROPERTY(EditInstanceOnly, Category = "Group")
	int32 Group;

	UPROPERTY(EditInstanceOnly, Category = "Wave")
	int32 Wave;

	UPROPERTY(EditInstanceOnly, Category = "CombatMultiSide")
	ECombatMultiSide CombatMultiSide;

#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
	UBillboardComponent* SpriteComponent;

	UPROPERTY(Transient)
	UArrowComponent* ArrowComponent;

	UPROPERTY(Transient)
	UTextRenderComponent* TextRender;
#endif
};

UCLASS()
class Q6_API AResultLocator : public AActor
{
	GENERATED_BODY()

public:
	AResultLocator(const FObjectInitializer& ObjectInitializer);

	UCombatCameraComponent* GetResultCamera() const { return ResultCamera; }

protected:
	virtual void BeginPlay() override;
#if WITH_EDITOR
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void BeginDestroy() override;
#endif

	UPROPERTY(EditAnywhere, Category = "Camera")
	UCombatCameraComponent* ResultCamera;

private:
#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
	UBillboardComponent* SpriteComponent;

	UPROPERTY(Transient)
	UArrowComponent* ArrowComponent;

	UPROPERTY(Transient)
	AUnit* DemoUnit;

	UPROPERTY(Transient, EditInstanceOnly, Category = "Demo")
	int32 DemoUnitType;
#endif
};