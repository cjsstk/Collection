// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Camera/CameraComponent.h"
#include "CombatCameraComponent.generated.h"

class ACameraActor;
/**
 * Combat Camera Component
 */
UCLASS(meta=(BlueprintSpawnableComponent))
class Q6_API UCombatCameraComponent : public UCameraComponent
{
	GENERATED_BODY()
	
public:
	UCombatCameraComponent();

	void CopyCameraParamsTo(UCameraComponent* TargetComponent);
	ACameraActor* SpawnCloneCameraActor();

	void HideCulledActorInGame(bool bHide);

#if WITH_EDITORONLY_DATA
	static void RegisterCustomDetails();

	void HideCulledActorForEditor(bool bHide);
	void SelectCulledActorForEditor();
	void UpdateCulling();
#endif

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat Camera Culling")
	float CullViewDistance;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Combat Camera Culling")
	TArray<AActor*> CulledActorList;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Combat Camera Culling")
	TArray<AActor*> ForceShowActorList;

	UPROPERTY(EditInstanceOnly, BlueprintReadWrite, Category = "Combat Camera Culling")
	TArray<AActor*> ForceHideActorList;
	
	bool bUpdateCullWhileBuild;
	bool bHiddenCulledActorInGame;
};
