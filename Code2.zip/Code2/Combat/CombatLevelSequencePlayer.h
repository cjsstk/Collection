// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"
#include "CombatLevelSequencePlayer.generated.h"


/**
 * Q6 Level Sequence Actor
 */
UCLASS()
class Q6_API ACombatLevelSequenceActor : public ALevelSequenceActor
{
	GENERATED_BODY()
	ACombatLevelSequenceActor(const FObjectInitializer& Init);
};

/**
 * Q6 Level Sequence Player
 */
UCLASS()
class Q6_API UCombatLevelSequencePlayer : public ULevelSequencePlayer
{
	GENERATED_BODY()
	
public:
	static UCombatLevelSequencePlayer* CreateLevelSequencePlayer(UObject* WorldContextObject, ULevelSequence* LevelSequence, FMovieSceneSequencePlaybackSettings Settings, ACombatLevelSequenceActor*& OutActor);
	void SetLevelSequenceActor(ACombatLevelSequenceActor* InActor) { LevelSequenceActor = InActor; }

	virtual void OnObjectSpawned(UObject* InObject, const FMovieSceneEvaluationOperand& Operand) override;

	const TArray<AActor*>& GetSequenceSpawnedActors() const { return SequenceSpawnedActors; }

private:
	UPROPERTY(Transient)
	TArray<AActor*> SequenceSpawnedActors;

	ACombatLevelSequenceActor* LevelSequenceActor;
};
