// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6Enum.h"
#include "CPInstances.generated.h"

class AUnit;
class ACombatPresenter;
class ACombatCube;
class UCPInstanceBase;
class UCPBuffInstance;
class UCCEvent;
class UCCSpawnUnitEvent;
class UCCUnitDeadEvent;
class UCCSkillUsedEvent;
class UCCSkillEffectEvent;
class UCCSkillEffectHealthEvent;
class UCCSkillFailedEvent;
class UCCAttackPassEvent;
class UCCCreateBuffEvent;
class UCCRemoveBuffEvent;
class UCCRemoveBuffFailedEvent;
class UCCImmuneBuffEvent;
class UCCDamageBuffEvent;
class UCCDamageBuffPerUnit;
class UCCHealBuffEvent;
class UCCHealBuffPerUnit;
class UCCPointVaryUsedEvent;
class UCCRaidTurnSkillEffectEvent;
class UCCUpdateAttributesEvent;
class UCCUnitHealthChangedEvent;
class UCCUnitSAChangedEvent;
class UCCUnitUAChangedEvent;
class UCCUnitOverKillChangedEvent;
class UCCStartTurnEvent;
class UCCStartPhaseEvent;
class UCCEnemyAttackPassEvent;
class UCCEndGameEvent;
class UCCSetSkillTimeEvent;
class UCCStartWaveEvent;

struct FCCUnitState;

enum class ESkillCategory : uint8;
enum class ETargetType : uint8;
enum class EDropBoxType : uint8;

DECLARE_DELEGATE_TwoParams(FCPInstanceState, ECPInstanceState, UCPInstanceBase*);

UENUM()
enum class ECPInstanceType : uint8
{
	Base,
	Spawn,
	Dead,
	Skill,
	MasterSkill,
	ArtifactSkill,
	PetSkill,
	MomentSkill,
	TurnSkill,
	RaidTurnSkill,
	NormalSkill,
	UltimateSkill,
	UnitApplyEffectLabel,
	UnitNotice,
	Point,
	PointVary,
	Buff,
	SetSkillTime,
	DamageBuff,
	HealBuff,
	HealthChanged,
	CutScene,
	Wave,
	Turn,
	Phase,
	EnemyUltimateReady,
	EnemyAttackPass,
	Result,
	BoneDragonResult,
	SkillFailed,
	AttackPass,
	DropBox,
};

USTRUCT(NotBlueprintable)
struct FCPPointEvents
{
	GENERATED_BODY()

	FCPPointEvents() {}

	void AddUpdateAttributesEvent(const UCCUpdateAttributesEvent* InEvent) { UpdateAttributesEvents.Add(InEvent); }
	void AddHealthEvent(const UCCUnitHealthChangedEvent* InEvent) { HealthEvents.Add(InEvent); }
	void AddUAEvent(const UCCUnitUAChangedEvent* InEvent) { UAEvents.Add(InEvent); }
	void AddSAEvent(const UCCUnitSAChangedEvent* InEvent) { SAEvents.Add(InEvent); }
	void AddOverKillEvent(const UCCUnitOverKillChangedEvent* InEvent) { OverKillEvents.Add(InEvent); }

	UPROPERTY(Transient)
	TArray<const UCCUpdateAttributesEvent*> UpdateAttributesEvents;

	UPROPERTY(Transient)
	TArray<const UCCUnitHealthChangedEvent*> HealthEvents;

	UPROPERTY(Transient)
	TArray<const UCCUnitUAChangedEvent*> UAEvents;

	UPROPERTY(Transient)
	TArray<const UCCUnitSAChangedEvent*> SAEvents;

	UPROPERTY(Transient)
	TArray<const UCCUnitOverKillChangedEvent*> OverKillEvents;
};

UCLASS(Abstract, NotBlueprintType)
class Q6_API UCPInstanceBase : public UObject
{
	GENERATED_BODY()

public:
	UCPInstanceBase();

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Base; }
	virtual EQ6GameSpeed GetSpeed() const { return EQ6GameSpeed::Fast; }

	virtual bool Prepare();
	virtual void Start();
	virtual void End();
	virtual void Tick(float DeltaTime);

	void SetCombatPresenter(TWeakObjectPtr<ACombatPresenter> Presenter) { CombatPresenter = Presenter; }

	FCPInstanceId GetInstanceId() const { return InstanceId; }
	void SetInstanceId(FCPInstanceId InId) { InstanceId = InId; }

	ECPInstanceState GetState() const { return InstanceState; }

	bool IsBlocking() const { return bBlocking; }

	bool GetResetCamera() const { return bResetCamera; }
	void SetResetCamera(bool bInResetCamera) { bResetCamera = bInResetCamera; }

	FCPInstanceState OnInstanceState;

protected:
	virtual void BindContentDelegate() {} // before start
	virtual void UnbindContentDelegate() {} // before end

	void SetState(ECPInstanceState InState);
	void SetTimeOutLimit(float InTimeOutLimit, float Margin = 0.0f, bool bResetElapsedTime = false);

	TWeakObjectPtr<ACombatPresenter> CombatPresenter;
	ECPInstanceState InstanceState;

	bool bBlocking;
	bool bResetCamera;
	bool bUseTimeOut;
	bool bValidTimeOut;

private:
	FCPInstanceId InstanceId;
	float TimeoutLimit;
	float ElapsedTime;
};

UCLASS(NotBlueprintType)
class Q6_API UCPSpawnInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPSpawnInstance();
	void SetCCEvent(const UCCSpawnUnitEvent* InEvent) { SpawnUnitEvent = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Spawn; }

	virtual bool Prepare() override;
	virtual void Start() override;
	virtual void End() override;

	FCCUnitId GetUnitId() const;
	FCCUnitId GetSourceUnitId() const;

	void SetUsingTurnSkillCamera(bool bInUsing) { bUsingTurnSkillCamera = bInUsing; }

	void AddPassiveBuffEvent(const UCCCreateBuffEvent* InEvent);
	void AddInheritedBuffEvent(const UCCCreateBuffEvent* InEvent);

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void StartCamera();
	void StartHUD();

	void OnSpawnHUDAnimFinished();
	void OnSpawnEffectFinished();

	UPROPERTY(Transient)
	const UCCSpawnUnitEvent* SpawnUnitEvent;

	UPROPERTY(Transient)
	UCPBuffInstance* PassiveBuffInstance;

	UPROPERTY(Transient)
	UCPBuffInstance* InheritedBuffInstance;

	FCCUnitId UnitId;

	bool bUsingTurnSkillCamera;
	bool bHUDAnimStarted;
	bool bSpawnEffectFinished;
};

UCLASS(NotBlueprintType)
class Q6_API UCPDeadInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPDeadInstance();
	void SetCCEvent(const UCCUnitDeadEvent* InEvent) { UnitDeadEvent = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Dead; }

	const TArray<FCCUnitId>& GetUnitIds() const;
	void SetSkipCamera(bool bInSkipCamera) { bSkipCamera = bInSkipCamera; }

	virtual void Start() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void OnUnitDeadEffectFinished();
	void OnCameraBlendingFinished(bool bRestoring);

	int32 GetMonsterSlotOfPlayingDeadVoice(int32 InNumOfDeadMonsters);

	UPROPERTY(Transient)
	const UCCUnitDeadEvent* UnitDeadEvent;

	bool bSkipCamera;
};

USTRUCT(NotBlueprintable)
struct FCPSkillEffect
{
	GENERATED_BODY()

	FCPSkillEffect() : SourceUnitId(CCUnitIdInvalid) {}
	explicit FCPSkillEffect(const UCCSkillEffectEvent* InCCEvent);

	bool AddSkillEffect(const UCCSkillEffectEvent* InCCEvent);

	UPROPERTY(Transient)
	FCCUnitId SourceUnitId;

	UPROPERTY(Transient)
	TArray<const UCCSkillEffectHealthEvent*> DamageEvents;

	UPROPERTY(Transient)
	TArray<const UCCSkillEffectHealthEvent*> HealEvents;
};

USTRUCT(NotBlueprintable)
struct FCPSkillEffectHit
{
	GENERATED_BODY()

	bool IsEmpty() const { return UnitHits.Num() <= 0; }

	UPROPERTY(Transient)
	TArray<const UUnitHit*> UnitHits;
};

UCLASS(NotBlueprintType)
class Q6_API UCPSkillInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPSkillInstance();
	void SetCCEvent(const UCCSkillUsedEvent* InEvent) { SkillUsedEvent = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Skill; }

	virtual bool Prepare() override;
	virtual void Start() override;
	virtual void End() override;
	virtual void Tick(float DeltaTime) override;

	FCCSkillId GetSkillId() const;
	int32 GetSkillType() const;
	FCCUnitId GetSkillOwnerUnitId() const;
	ESkillCategory GetSkillCategory() const;
	EMoment GetMoment() const;

	bool IsActiveSkill() const;
	bool IsInterruptable() const;
	bool IsInterruptive() const;

	bool ShouldSkipBuffEffect() const;
	void SetHasSkillDrivenEffect(bool bInHasSkillDrivenEffect) { bHasSkillDrivenEffect = bInHasSkillDrivenEffect; }
	void SetHasDeadUnit(bool bInHasDeadUnit) { bHasDeadUnit = bInHasDeadUnit; }

	virtual void OnSequenceFinished();

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

	void AddEffectEvent(const UCCSkillEffectEvent* EffectEvent) { SkillEffectEvents.Add(EffectEvent); }

	void AddUAEvent(const UCCUnitUAChangedEvent* InUAEvent);
	void AddSAEvent(const UCCUnitSAChangedEvent* InSAEvent);
	void AddOverKillEvent(const UCCUnitOverKillChangedEvent* InOverKillEvent);

protected:
	virtual bool Initialize();

	virtual bool IsCompleteEnd() const { return false; }
	bool IsLastSkill() const;

	void PrepareAction();
	void StartAction();
	void EndPostProcess();

	void RegisterSpawnMeshParam(AUnit* Unit, const FSpawnSkeletalMeshDesc& Desc, float EndDuration = -1.0f, FVector Location = FVector::ZeroVector);

	virtual void InitializeInternal() {};
	virtual void CreateAnimHitInfoInternal(TArray<FSkillAnimHitInfo>& InOutHitsPerEffect) {};
	virtual void StartInternal();
	virtual bool PrepareActionInternal() { return false; }
	virtual void StartActionInternal() {};
	virtual void EndInternal() {};
	virtual void EndPostProcessInternal() {};

private:
	void GenerateSkillEffects();
	void CreateAnimHitInfo();

protected:
	void OnHit(const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam);
	void OnHitPost(const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam, const FSpawnSkeletalMeshDesc& MeshDesc, bool bRandomDelay);

	bool HasMissingHitEvents() const;
	void ProcessMissingHitEvents();
	void OnProcessMissingHitCameraBlendingFinished(bool bRestoring);

private:
	void OnCameraBlendingFinished(bool bRestoring);
	void OnFireProjectile(const FProjectileEffectDesc& Desc, const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam);
	void OnPlayBeamParticleEffect(const FBeamParticleEffectDesc& Desc, float TotalDuration);
	void OnPlayParticleEffectOnTarget(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam);
	void OnSpawnSkeletalMesh(const FSpawnSkeletalMeshDesc& Desc, float OverrideDuration, bool bTarget);

	void ProcessPointEvents(const FCPPointEvents& InPointEvents) const;
	void ProcessFirstHit();
	void ProcessLastHit();

	void ProcessHit(const UUnitHit* Hit, const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam, const FSpawnSkeletalMeshDesc& MeshDesc);
	void ProcessHitEvents(const FSpawnParticleParams& HitParticleParam, const FSpawnSoundParams& HitSoundParam, const FSpawnSkeletalMeshDesc& MeshDesc);
	void UpdateDelayedProcessHit();

	void ProcessMissingHit(const UUnitHit* Hit);

protected:
	UPROPERTY()
	const UCCSkillUsedEvent* SkillUsedEvent;

	UPROPERTY()
	TArray<const UCCSkillEffectEvent*> SkillEffectEvents;

private:
	UPROPERTY()
	TArray<FCPSkillEffect> SkillEffects;

	UPROPERTY()
	TArray<FCPSkillEffectHit> SkillEffectHits;

	UPROPERTY()
	FCPPointEvents StartInstancePointEvents;

	UPROPERTY()
	FCPPointEvents FirstHitPointEvents;

	UPROPERTY()
	FCPPointEvents LastHitPointEvents;

	int32 ActiveSkillOwnerGotOverKill;

protected:
	AUnit* OwnerUnit;
	ECCFaction OwnerFaction;
	ETargetType TargetType;

	bool bNoHit;
	bool bHitFinished;
	bool bSequenceFinished;
	bool bEnded;

	bool bHasSkillDrivenEffect;
	bool bHasDeadUnit;
	bool bDoubleSkillFollowing;

private:
	bool bPrepareActionFinished;
	bool bHitStarted;
	float ProcessingMissingHitStartTime;

	bool bProcessingDelayedHit;
	int32 ProcessingSkillEffectHitIndex;
	float ProcessHitDelay;
	float LastProcessHitTime;

	FSpawnParticleParams DelayedHitParticleParam;
	FSpawnSoundParams DelayedHitSoundParam;
	FSpawnSkeletalMeshDesc DelayedHitMeshDesc;
};

UCLASS(NotBlueprintType)
class Q6_API UCPMasterSkillInstance : public UCPSkillInstance
{
	GENERATED_BODY()

public:
	UCPMasterSkillInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::MasterSkill; }

	virtual void BindContentDelegate() override {}
	virtual void UnbindContentDelegate() override {}

protected:
	virtual void StartInternal() override;
};

UCLASS(NotBlueprintType)
class Q6_API UCPArtifactSkillInstance : public UCPSkillInstance
{
	GENERATED_BODY()

public:
	UCPArtifactSkillInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::ArtifactSkill; }

protected:
	virtual void StartInternal() override;
};

UCLASS(NotBlueprintType)
class Q6_API UCPPetSkillInstance : public UCPSkillInstance
{
	GENERATED_BODY()

public:
	UCPPetSkillInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::PetSkill; }

protected:
	virtual bool IsCompleteEnd() const override;
	virtual void StartInternal() override;
	virtual void EndInternal() override;
};

UCLASS(NotBlueprintType)
class Q6_API UCPMomentSkillInstance : public UCPSkillInstance
{
	GENERATED_BODY()

public:
	UCPMomentSkillInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::MomentSkill; }

	bool HasHitEvents() const;
	void SetSkipAction(bool bInSkipAction) { bSkipAction = bInSkipAction; }

	virtual void End() override;

protected:
	virtual void StartInternal() override;

private:
	bool bSkipAction;

	FTimerHandle HitEventTimerHandle;
};

UCLASS(NotBlueprintType)
class Q6_API UCPTurnSkillInstance : public UCPSkillInstance
{
	GENERATED_BODY()

public:
	UCPTurnSkillInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::TurnSkill; }

	virtual void Start() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

protected:
	virtual bool PrepareActionInternal() override;
	virtual void StartActionInternal() override;
	virtual void EndInternal() override;
	virtual void EndPostProcessInternal() override;

private:
	bool bAllyOwner;
};

UCLASS(NotBlueprintType)
class Q6_API UCPRaidTurnSkillInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPRaidTurnSkillInstance();
	void SetCCEvent(const UCCRaidTurnSkillEffectEvent* InEvent) { Event = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::RaidTurnSkill; }

	virtual void Start() override;
	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void OnCameraBlendingFinished(bool bRestoring);

	const UCCRaidTurnSkillEffectEvent* Event;
};

UCLASS(NotBlueprintType)
class Q6_API UCPNormalSkillInstance : public UCPSkillInstance
{
	GENERATED_BODY()

public:
	UCPNormalSkillInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::NormalSkill; }

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

protected:
	virtual bool IsCompleteEnd() const override;

	virtual void InitializeInternal() override;
	virtual void StartInternal() override;
	virtual void StartActionInternal() override;
	virtual void EndInternal() override;

private:
	void OnPlayNormalSkillSequence(const FTransform& TargetTransform);
	void OnNormalSkillAnimFinished();
	void OnOwnerUnitMoveEnd();

	bool bOwnerUnitMoveEnd;
};

UCLASS(NotBlueprintType)
class Q6_API UCPUltimateSkillInstance : public UCPSkillInstance
{
	GENERATED_BODY()

public:
	UCPUltimateSkillInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::UltimateSkill; }
	virtual EQ6GameSpeed GetSpeed() const override { return EQ6GameSpeed::Speedy; }

	virtual void Tick(float DeltaTime) override;
	virtual void OnSequenceFinished() override;
	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

protected:
	virtual bool IsCompleteEnd() const override;

	virtual void InitializeInternal() override;
	virtual void CreateAnimHitInfoInternal(TArray<FSkillAnimHitInfo>& InOutHitsPerEffect) override;
	virtual void StartActionInternal() override;
	virtual void EndInternal() override;

private:
	void OnSkillPreAnimFinished();
	void OnSkillAnimFinished();

	void StartSkillAction();

	void SpawnPostExtraEffect();

	void OnOwnerUnitReadyToMove();
	void StartOwnerUnitPostMove();

	void UpdatePostEffect(float TimeNow);
	void UpdatePostMove(float TimeNow);

	bool bCameraPreActionFinished;
	bool bHUDPreAnimFinished;
	bool bShowSequence;

	FSkillPostEffectDesc SkillPostEffect;
	float PostEffectStartTime;
	float PostHitStartTime;
	float LastPostHitTime;
	bool bPostEffectFinished;

	FSkillPostMoveDesc SkillPostMove;
	float PostMoveStartTime;
	bool bPostMoveFinished;
};

USTRUCT(NotBlueprintable)
struct FCPMomentLabelInfo
{
	GENERATED_BODY()

	FCPMomentLabelInfo()
		: Moment(EMoment::None)
	{}

	EMoment Moment;
	TArray<FCCUnitId> UnitIds;
};


UCLASS(NotBlueprintType)
class Q6_API UCPUnitApplyEffectLabelInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPUnitApplyEffectLabelInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::UnitApplyEffectLabel; }

	TArray<FCPMomentLabelInfo>& GetLabelInfos() { return MomentLabelInfos; }
	void AddLabelInfo(EMoment InMoment, FCCUnitId InUnitId);

	bool IsSingleTargetCamera(FCCUnitId& OutTargetUnitId);
	void SetSingleTargetCamera(bool bInSingleCamera) { bSingleCamera = bInSingleCamera; }

	virtual void Start() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void OnCameraBlendingFinished(bool bRestoring);

	TArray<FCPMomentLabelInfo> MomentLabelInfos;
	bool bSingleCamera;
};

UCLASS(NotBlueprintType)
class Q6_API UCPUnitNoticeInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPUnitNoticeInstance();

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::UnitNotice; }

	virtual bool Prepare() override;
	virtual void Start() override;
	virtual void End() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

	FCCUnitId GetSourceUnitId() const { return SourceUnitId; }
	void SetSourceUnitId(FCCUnitId InUnitId) { SourceUnitId = InUnitId; }

	const TArray<FCCUnitId>& GetTargetUnitIds() const { return TargetUnitIds; }

	void SetSkipCamera(bool bInSkipCamera) { bSkipCamera = bInSkipCamera; }
	void SetSkipAction(bool bInSkipAction) { bSkipAction = bInSkipAction; }

protected:
	bool Initialize();
	virtual void StartAction() {}

	virtual void OnCameraBlendingFinished(bool bRestoring) {}
	virtual void OnUnitNoticeAnimFinished() {}

	FCCUnitId SourceUnitId;
	TArray<FCCUnitId> TargetUnitIds;

	bool bSkipCamera;
	bool bSkipAction;
};

UCLASS(NotBlueprintType)
class Q6_API UCPPointInstance : public UCPUnitNoticeInstance
{
	GENERATED_BODY()

public:	
	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::Point; }

	void AddHealthEvent(const UCCUnitHealthChangedEvent* InEvent);
	void AddUAEvent(const UCCUnitUAChangedEvent* InEvent);
	void AddSAEvent(const UCCUnitSAChangedEvent* InEvent);
	void AddOverKillEvent(const UCCUnitOverKillChangedEvent* InEvent);

protected:
	virtual void StartAction() override;

	virtual void OnCameraBlendingFinished(bool bRestoring) override;
	virtual void OnUnitNoticeAnimFinished() override;

private:
	UPROPERTY()
	FCPPointEvents PointEvents;
};

UCLASS(NotBlueprintType)
class Q6_API UCPPointVaryInstance : public UCPUnitNoticeInstance
{
	GENERATED_BODY()

public:
	UCPPointVaryInstance();
	void SetCCEvent(const UCCPointVaryUsedEvent* InEvent) { PointVaryUsedEvent = InEvent; }

	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::PointVary; }

	void SetStateChanged() { EventState = EPointVaryState::Convert; }
	FCPPointEvents& GetCurEvents() { return EventState == EPointVaryState::Convert ? ConvertEvents : ConsumeEvents; }

	void AddUpdateAttributesEvent(const UCCUpdateAttributesEvent* InEvent);
	void AddHealthEvent(const UCCUnitHealthChangedEvent* InEvent);
	void AddUAEvent(const UCCUnitUAChangedEvent* InEvent);
	void AddSAEvent(const UCCUnitSAChangedEvent* InEvent);
	void AddOverKillEvent(const UCCUnitOverKillChangedEvent* InEvent);

protected:
	virtual void StartAction() override;

	virtual void OnCameraBlendingFinished(bool bRestoring) override;
	virtual void OnUnitNoticeAnimFinished() override;

private:
	void StartConsumeAction();
	void StartConvertAction();

	UPROPERTY()
	const UCCPointVaryUsedEvent* PointVaryUsedEvent;

	UPROPERTY()
	FCPPointEvents ConsumeEvents;

	UPROPERTY()
	FCPPointEvents ConvertEvents;

	EPointVaryState EventState;
	EPointVaryState ActionState;
};

UCLASS(NotBlueprintType)
class Q6_API UCPBuffInstance : public UCPUnitNoticeInstance
{
	GENERATED_BODY()

public:
	UCPBuffInstance();
	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::Buff; }

	void SetSkipEffectFromSkill(ESkillCategory InSkillCategory);
	void SetSkipEffect(bool bInSkipCamera, bool bInSkipUnitNotices, bool bInSkipUnitBar);

	void AddBuffEvent(const UCCEvent* InEvent);

protected:
	virtual void StartAction() override;

	virtual void OnCameraBlendingFinished(bool bRestoring) override;
	virtual void OnUnitNoticeAnimFinished() override;

private:
	UPROPERTY()
	TArray<const UCCEvent*> BuffEvents;

	bool bSkipUnitNotices;
	bool bSkipUnitBar;
	bool bFromSkill;
};

UCLASS(NotBlueprintType)
class Q6_API UCPSetSkillTimeInstance : public UCPUnitNoticeInstance
{
	GENERATED_BODY()

public:
	virtual ECPInstanceType GetInstanceType() const override { return ECPInstanceType::SetSkillTime; }

	void AddSetSkillTimeEvent(const UCCSetSkillTimeEvent* InEvent);

	FCCUnitId GetSourceUnitId() const { return SourceUnitId; }
	void SetSourceUnitId(FCCUnitId InUnitId) { SourceUnitId = InUnitId; }

protected:
	virtual void StartAction() override;

	virtual void OnCameraBlendingFinished(bool bRestoring) override;
	virtual void OnUnitNoticeAnimFinished() override;

private:
	UPROPERTY()
	TArray<const UCCSetSkillTimeEvent*> SetSkillTimeEvents;
};

UCLASS(NotBlueprintType)
class Q6_API UCPDamageBuffInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	void SetCCEvent(const UCCDamageBuffEvent* InEvent);

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::DamageBuff; }

	virtual void Start() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

protected:
	virtual void StartAction();

private:
	void OnCameraBlendingFinished(bool bRestoring);

	UPROPERTY()
	const UCCDamageBuffEvent* DamageBuffEvent;

	UPROPERTY()
	TArray<UCCDamageBuffPerUnit*> DamageInfos;
};

UCLASS(NotBlueprintType)
class Q6_API UCPHealBuffInstance : public UCPDamageBuffInstance
{
	GENERATED_BODY()

public:
	void SetCCEvent(const UCCHealBuffEvent* InEvent);

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::HealBuff; }

private:
	void StartAction() override;

	UPROPERTY()
	const UCCHealBuffEvent* HealBuffEvent;

	UPROPERTY()
	TArray<UCCHealBuffPerUnit*> HealInfos;
};

UCLASS(NotBlueprintType)
class Q6_API UCPHealthChangedInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	void SetCCEvent(const UCCUnitHealthChangedEvent* InEvent) { HealthChangedEvent = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::HealthChanged; }

	virtual void Start() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	UPROPERTY()
	const UCCUnitHealthChangedEvent* HealthChangedEvent;
};

UCLASS(NotBlueprintType)
class Q6_API UCPCutSceneInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPCutSceneInstance();

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::CutScene; }

	virtual bool Prepare() override;
	virtual void Start() override;
	virtual void UnbindContentDelegate() override;
	virtual void End() override;

	void SetCutSceneInfo(int32 InEpisode, int32 InStage, int32 InWave, bool bInIsIntro);
	void SetStartWaveEvent(const UCCStartWaveEvent* InEvent) { StartWaveEvent = InEvent; }

private:
	void FadeOutEnd();

	int32 Episode;
	int32 Stage;
	int32 Wave;
	bool bIsIntro;
	float FadeOutTime;

	UPROPERTY()
	const UCCStartWaveEvent* StartWaveEvent;

	FTimerHandle FadeOutTimerHandle;
};

UCLASS(NotBlueprintType)
class Q6_API UCPWaveInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPWaveInstance();

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Wave; }

	virtual void Start() override;
	virtual void UnbindContentDelegate() override;
	virtual void End() override;

	void SetWaveInfo(int32 InWave) { Wave = InWave; }
	void SetStartWaveEvent(const UCCStartWaveEvent* InEvent) { StartWaveEvent = InEvent; }

private:
	void OnUnitUnrelaxed(const FCCUnitId InUnitId);
	void OnUnitMoveFinished(const FCCUnitId InUnitId);

	int32 Wave;
	TArray<FCCUnitId> MoveUnitIds;

	UPROPERTY()
	const UCCStartWaveEvent* StartWaveEvent;
};

UCLASS(NotBlueprintType)
class Q6_API UCPTurnInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPTurnInstance();
	void SetCCEvent(const UCCStartTurnEvent* InEvent) { StartTurnEvent = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Turn; }

	virtual void Start() override;
	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void OnCameraBlendingFinished(bool bRestoring);
	void OnHUDAnimFinished();

	bool bCameraWorkFinished;
	bool bHUDAnimFinished;

	UPROPERTY()
	const UCCStartTurnEvent* StartTurnEvent;
};

UCLASS(NotBlueprintType)
class Q6_API UCPPhaseInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPPhaseInstance();
	void SetCCEvent(const UCCStartPhaseEvent* InEvent) { StartPhaseEvent = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Phase; }

	virtual void Start() override;
	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	bool ShouldSkipCamera() const;
	void StartHUD();
	void StartEnemyUltimateReady();

	void OnCameraBlendingFinished(bool bRestoring);
	void OnHUDAnimFinished();

	bool bCameraWorkFinished;
	bool bHUDAnimFinished;

	UPROPERTY()
	const UCCStartPhaseEvent* StartPhaseEvent;
};

UCLASS(NotBlueprintType)
class Q6_API UCPEnemyUltimateReadyInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPEnemyUltimateReadyInstance();

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::EnemyUltimateReady; }

	virtual void Start() override;
	virtual void End() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

	void SetEnemyUnitIds(const TArray<FCCUnitId>& InUnitIds) { EnemyUnitIds = InUnitIds; }

private:
	void StartCamera();

	void OnCameraBlendingFinished(bool bRestoring);
	void OnUnitAnimFinished();
	void OnHUDAnimFinished();

	bool bUnitAnimFinished;
	bool bHUDAnimFinished;

	TArray<FCCUnitId> EnemyUnitIds;
};

UCLASS(NotBlueprintType)
class Q6_API UCPEnemyAttackPassInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	void SetCCEvent(const UCCEnemyAttackPassEvent* InEvent) { Event = InEvent; }

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::EnemyAttackPass; }

	virtual void Start() override;

	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void OnCameraBlendingFinished(bool bRestoring);

	const UCCEnemyAttackPassEvent* Event;
};

UCLASS(NotBlueprintType)
class Q6_API UCPResultInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::Result; }

	void SetCCEvent(const UCCEndGameEvent* InEvent) { EndGameEvent = InEvent; }

	virtual void Start() override;
	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void StartSequence();

	void OnSequenceFinished();
	void OnResultWidgetClosed();
	void OnWinAnimFinished();

	FCCUnitId GetResultUnitId() const;

	UPROPERTY()
	const UCCEndGameEvent* EndGameEvent;
};

UCLASS(NotBlueprintType)
class Q6_API UCPBoneDragonResultInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::BoneDragonResult; }

	void SetCCEvent(const UCCEndGameEvent* InEvent) { EndGameEvent = InEvent; }

	virtual void Start() override;
	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	void StartSequence();

	void OnSequenceFinished();

	UPROPERTY()
	const UCCEndGameEvent* EndGameEvent;
};

UCLASS(NotBlueprintType)
class Q6_API UCPSkillFailedInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::SkillFailed; }

	void SetCCEvent(const UCCSkillFailedEvent* InEvent) { Event = InEvent; }

	virtual void Start() override;
	virtual void BindContentDelegate() override;
	virtual void UnbindContentDelegate() override;

private:
	UPROPERTY()
	const UCCSkillFailedEvent* Event;
};

UCLASS(NotBlueprintType)
class Q6_API UCPAttackPassInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPAttackPassInstance() {}

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::AttackPass; }

	void SetCCEvent(const UCCAttackPassEvent* InEvent) { Event = InEvent; }

	virtual bool Prepare() override;
	virtual void Start() override;

protected:
	UPROPERTY()
	const UCCAttackPassEvent* Event;
};

UCLASS(NotBlueprintType)
class Q6_API UCPDropBoxInstance : public UCPInstanceBase
{
	GENERATED_BODY()

public:
	UCPDropBoxInstance();

	virtual ECPInstanceType GetInstanceType() const { return ECPInstanceType::DropBox; }

	void SetSkipFinishWaveAnim(bool bInSkipFinishWaveAnim) { bSkipFinishWaveAnim = bInSkipFinishWaveAnim; }

	virtual void Start() override;
	virtual void End() override;

private:
	bool bSkipFinishWaveAnim;

	FTimerHandle CollectTimerHandle;
};
