// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "GameResource.h"

#include "CMSTable.h"
#include "GameAssetCache.h"
#include "Q6Log.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "UMG.h"
#include "UIClassResource.h"
#include "LevelUtil.h"
#include "Q6Capture2D.h"
#include "Engine/Q6DirectionalLight.h"
#include "LobbyTemplate.h"
#include "Components/Q6DirectionalLightComponent.h"
#include "DropBox.h"
#include "MediaPlayerWidget.h"
#include "MediaSoundComponent.h"
#include "Q6MediaPlayer.h"
#include "Q6GameInstance.h"
#include "SystemConstHelper.h"

#define LEVEL_EFFECT_ALL_STAGE -1

static TAutoConsoleVariable<int32> CVarUsePreloadSkillAsset(
	TEXT("q6.usePreloadSkillAsset"),
#if PLATFORM_IOS
	// iOS cannot afford this due to memory issue
	0,
#else
	1,
#endif
	TEXT("Enable preloading skill assets to avoid loaidng lag. [0, 1]"),
	ECVF_Cheat);

static TAutoConsoleVariable<int32> CVarWaitUIClassAsyncLoading(
	TEXT("q6.waitUIClassAsyncLoading"),
	0,
	TEXT("Wait UI class asyncloading at lobby start"),
	ECVF_Cheat);

static void FixUnitModelAssetTable(UDataTable* Table)
{
	if (!ensure(Table))
	{
		return;
	}

	TArray<FUnitModelAssetRow *> OutRowArray;
	Table->GetAllRows("PostLoad", OutRowArray);
	for (auto& CurRow : OutRowArray)
	{

		if (FMath::IsNearlyZero(CurRow->MeshScale, KINDA_SMALL_NUMBER))
		{
			CurRow->MeshScale = 1.0f;
		}
	}
}

UGameResource::UGameResource(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	CacheManager = CreateDefaultSubobject<UGameAssetCacheManager>(TEXT("CacheManager"), true);
}

void UGameResource::PostLoad()
{
	Super::PostLoad();

	if (UIResourceClass)
	{
		UIResource = NewObject<UUIResource>(this, UIResourceClass);
	}

	if (UUIClassResourceClass)
	{
		UIClassResource = NewObject< UUIClassResource>(this, UUIClassResourceClass);
	}

	if (SoundResourceClass)
	{
		SoundResource = NewObject<USoundResource>(this, SoundResourceClass);
	}
}

const FUnitModelAssetRow& UGameResource::GetUnitModelAssetRow(FCharacterType CharacterType) const
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(CharacterType);
	return GetUnitModelAssetRow(UnitRow.Model);
}

const FUnitModelAssetRow& UGameResource::GetUnitModelAssetRow(int32 ModelType) const
{
	ensure(UnitModelAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), ModelType);
	const FUnitModelAssetRow* Row = UnitModelAssetTable->FindRow<FUnitModelAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}
	else
	{
		Q6JsonLogSunny(Warning, "Cannot find unit model asset row", Q6KV("ModelType", ModelType));

		static FQ6MaterialOverrideSlot DummyMaterial(-1, BlackMaterial);
		static FUnitModelAssetRow Dummy(DummySkeletalMesh, DummyMaterial);

		return Dummy;
	}
}

const FUnitModelAssetRow* UGameResource::GetUnitModelAssetRowPtr(int32 ModelType) const
{
	ensure(UnitModelAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), ModelType);
	const FUnitModelAssetRow* Row = UnitModelAssetTable->FindRow<FUnitModelAssetRow>(FName(*TypeStr), TypeStr, false);

	if (!Row)
	{
		Q6JsonLogBro(Warning, "Cannot find unit model asset row", Q6KV("ModelType", ModelType));
	}

	return Row;
}

const FUnitModelCameraRow* UGameResource::GetUnitModelCameraRowPtr(int32 ModelType) const
{
	ensure(UnitModelCameraTable);

	const FUnitModelAssetRow* AssetRow = GetUnitModelAssetRowPtr(ModelType);
	if (!AssetRow)
	{
		return nullptr;
	}

	if (AssetRow->CameraType == 0)
	{
		return nullptr;
	}

	FString TypeStr = FString::Printf(TEXT("%d"), AssetRow->CameraType);
	const FUnitModelCameraRow* Row = UnitModelCameraTable->FindRow<FUnitModelCameraRow>(FName(*TypeStr), TypeStr, false);
	if (!Row)
	{
		Q6JsonLogZagal(Warning, "Cannot find unit model camera row", Q6KV("ModelType", ModelType), Q6KV("CameraType", AssetRow->CameraType));
	}

	return Row;
}

const FSkillAssetRow& UGameResource::GetSkillAssetRow(int32 ModelType) const
{
	ensure(SkillAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), ModelType);
	const FSkillAssetRow* Row = SkillAssetTable->FindRow<FSkillAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}
	else
	{
		Q6JsonLogRoze(Warning, "Cannot find skill asset row", Q6KV("ModelType", ModelType));

		// Get default row
		TypeStr = FString::Printf(TEXT("%d"), 0);
		const FSkillAssetRow* DefaultRow = SkillAssetTable->FindRow<FSkillAssetRow>(FName(*TypeStr), TypeStr, false);
		if (DefaultRow)
		{
			return *DefaultRow;
		}
		else
		{
			static FSkillAssetRow Dummy(DummyTexture);
			return Dummy;
		}
	}
}

static const TCHAR* _GetSkillNoteInitial(ESkillNote SkillNote)
{
	switch (SkillNote)
	{
		case ESkillNote::None:
			return TEXT("_N");
		case ESkillNote::Ace:
			return TEXT("_A");
		case ESkillNote::Break:
			return TEXT("_B");
		case ESkillNote::Closer:
			return TEXT("_C");
		default:
			return TEXT("");
	}
}

const FNormalSkillSequenceAssetRow& UGameResource::GetNormalSkillSequenceAssetRow(int32 ModelType, ESkillNote SkillNote, bool bInAddMissingLog /* = true */) const
{
	ensure(NormalSkillSequenceAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d%s"), ModelType, _GetSkillNoteInitial(SkillNote));
	const FNormalSkillSequenceAssetRow* Row = NormalSkillSequenceAssetTable->FindRow<FNormalSkillSequenceAssetRow>(FName(*TypeStr), TypeStr, false);
	if (Row)
	{
		return *Row;
	}
	else
	{
		if (bInAddMissingLog)
		{
			Q6JsonLogSunny(Warning, "Cannot find normal skill sequence asset row", Q6KV("ModelType", ModelType), Q6KV("SkillNote", (uint8)SkillNote));
		}

		static FNormalSkillSequenceAssetRow Dummy;
		return Dummy;
	}
}

const FNormalSkillSequenceAssetRow& UGameResource::GetDoubleSkillSequenceAssetRow(int32 ModelType, bool bInAddMissingLog /* = true */) const
{
	ensure(NormalSkillSequenceAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d_D"), ModelType);
	const FNormalSkillSequenceAssetRow* Row = NormalSkillSequenceAssetTable->FindRow<FNormalSkillSequenceAssetRow>(FName(*TypeStr), TypeStr, false);
	if (Row)
	{
		return *Row;
	}
	else
	{
		if (bInAddMissingLog)
		{
			Q6JsonLogSunny(Warning, "Cannot find double skill sequence asset row", Q6KV("ModelType", ModelType));
		}

		static FNormalSkillSequenceAssetRow Dummy;
		return Dummy;
	}
}

const FUltimateSkillSequenceAssetRow& UGameResource::GetModelUltimateSkillSequenceAssetRow(int32 ModelType, bool bInAddMissingLog /* = true */) const
{
	ensure(ModelUltimateSkillSequenceAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), ModelType);
	const FUltimateSkillSequenceAssetRow* Row = ModelUltimateSkillSequenceAssetTable->FindRow<FUltimateSkillSequenceAssetRow>(FName(*TypeStr), TypeStr, false);
	if (Row)
	{
		return *Row;
	}
	else
	{
		if (bInAddMissingLog)
		{
			Q6JsonLogSunny(Warning, "Cannot find model ultimate skill sequence asset row", Q6KV("ModelType", ModelType));
		}

		static FUltimateSkillSequenceAssetRow Dummy;
		return Dummy;
	}
}

const FUltimateSkillSequenceAssetRow& UGameResource::GetSkillUltimateSkillSequenceAssetRow(int32 SkillType, bool bInAddMissingLog /* = true */) const
{
	ensure(SkillUltimateSkillSequenceAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), SkillType);
	const FUltimateSkillSequenceAssetRow* Row = SkillUltimateSkillSequenceAssetTable->FindRow<FUltimateSkillSequenceAssetRow>(FName(*TypeStr), TypeStr, false);
	if (Row)
	{
		return *Row;
	}
	else
	{
		if (bInAddMissingLog)
		{
			Q6JsonLogSunny(Warning, "Cannot find skill ultimate skill sequence asset row", Q6KV("SkillType", SkillType));
		}

		static FUltimateSkillSequenceAssetRow Dummy;
		return Dummy;
	}
}

const FWaveSequenceAssetRow& UGameResource::GetWaveSequenceAssetRow(int32 Episode, int32 Stage, int32 Wave) const
{
	ensure(WaveSequenceAssetTable);

	FString Context;
	TArray<FName> RowNames = WaveSequenceAssetTable->GetRowNames();

	for (auto& name : RowNames)
	{
		FWaveSequenceAssetRow* Row = WaveSequenceAssetTable->FindRow<FWaveSequenceAssetRow>(name, Context);
		if (Row)
		{
			if (Row->Episode == Episode && Row->Stage == Stage && Row->Wave == Wave)
			{
				return *Row;
			}
		}
	}

	static FWaveSequenceAssetRow Dummy;
	return Dummy;
}

void UGameResource::GetWaveSequencesOfStage(int32 Episode, int32 Stage, TArray<FSoftObjectPath>& OutSeqPaths) const
{
	ensure(WaveSequenceAssetTable);

	FString Context;
	TArray<FName> RowNames = WaveSequenceAssetTable->GetRowNames();

	for (auto& RowName : RowNames)
	{
		FWaveSequenceAssetRow* Row = WaveSequenceAssetTable->FindRow<FWaveSequenceAssetRow>(RowName, Context);
		if (Row)
		{
			if (Row->Episode == Episode && Row->Stage == Stage)
			{
				if (Row->IntroSequence.IsPending())
				{
					OutSeqPaths.Add(Row->IntroSequence.GetUniqueID());
				}
				if (Row->OutroSequence.IsPending())
				{
					OutSeqPaths.Add(Row->OutroSequence.GetUniqueID());
				}
			}
		}
	}
}

const FResultSequenceAssetRow& UGameResource::GetResultSequenceAssetRow(int32 ModelType) const
{
	ensure(ResultSequenceAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), ModelType);
	const FResultSequenceAssetRow* Row = ResultSequenceAssetTable->FindRow<FResultSequenceAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}
	else
	{
		Q6JsonLogSunny(Warning, "Cannot find result sequence asset row", Q6KV("UnitType", ModelType));
		static FResultSequenceAssetRow Dummy;
		return Dummy;
	}
}

const FBossSettingAssetRow& UGameResource::GetBossSettingAssetRow(int32 UnitType) const
{
	ensure(BossSettingAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), UnitType);
	const FBossSettingAssetRow* Row = BossSettingAssetTable->FindRow<FBossSettingAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}
	else
	{
		static FBossSettingAssetRow Dummy;
		return Dummy;
	}
}

const FEpisodeAssetRow& UGameResource::GetEpisodeAssetRow(int32 Episode) const
{
	ensure(EpisodeSettingAssetTable);

	FString TypeStr = FString::Printf(TEXT("%d"), Episode);
	const FEpisodeAssetRow* Row = EpisodeSettingAssetTable->FindRow<FEpisodeAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	// for comingsoon

	Row = EpisodeSettingAssetTable->FindRow<FEpisodeAssetRow>(FName(TEXT("-1")), TypeStr, true);
	if (Row)
	{
		return *Row;
	}

	static FEpisodeAssetRow Dummy;
	return Dummy;
}

const FBagItemAssetRow& UGameResource::GetBagItemAssetRow(FBagItemType BagItemType) const
{
	ensure(BagItemAssetTable);
	ensure(BagItemType != BagItemTypeInvalid);

	return FindBagItemAssetRow(BagItemAssetTable, BagItemType);
}

const FSculptureAssetRow& UGameResource::GetSculptureAssetRow(FSculptureType SculptureType) const
{
	ensure(SculptureAssetTable);
	ensure(SculptureType != SculptureTypeInvalid);

	FString TypeStr = FString::Printf(TEXT("%d"), SculptureType.x);
	const FSculptureAssetRow* Row = SculptureAssetTable->FindRow<FSculptureAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FSculptureAssetRow DummyRow;
	return DummyRow;
}

const FEquipAssetRow& UGameResource::GetRelicAssetRow(FRelicType RelicType) const
{
	ensure(RelicAssetTable);
	ensure(RelicType != RelicTypeInvalid);

	FString TypeStr = FString::Printf(TEXT("%d"), RelicType.x);
	const FEquipAssetRow* Row = RelicAssetTable->FindRow<FEquipAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FEquipAssetRow DummyRow;
	return DummyRow;
}

const FBagItemAssetRow& UGameResource::FindBagItemAssetRow(const UDataTable* DataTable, FBagItemType BagItemType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), BagItemType.x);
	const FBagItemAssetRow* Row = DataTable->FindRow<FBagItemAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FBagItemAssetRow Dummy;
	return Dummy;
}

const FEquipAssetRow* UGameResource::FindEquipAssetRow(const UDataTable* DataTable, int32 ItemType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), ItemType);
	const FEquipAssetRow* Row = DataTable->FindRow<FEquipAssetRow>(FName(*TypeStr), TypeStr, false);

	return Row;
}

const FSummonAssetRow& UGameResource::GetSummonAssetRow(int32 EventId) const
{
	FString EventIdStr = FString::Printf(TEXT("%d"), EventId);
	const FSummonAssetRow* Row = SummonAssetTable->FindRow<FSummonAssetRow>(FName(*EventIdStr), EventIdStr, false);

	if (Row)
	{
		return *Row;
	}

	static FSummonAssetRow Dummy;
	return Dummy;
}

const FDailyDungeonAssetRow& UGameResource::GetDailyDungeonAssetRow(EDayOfWeekType DayType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), (int32)DayType);
	const FDailyDungeonAssetRow* Row = DailyDungeonAssetTable->FindRow<FDailyDungeonAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FDailyDungeonAssetRow Dummy;
	return Dummy;
}

const FVacationSpotAssetRow& UGameResource::GetVacationSpotAssetRow(FVacationSpotType SpotType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), SpotType.x);
	const FVacationSpotAssetRow* Row = VacationSpotAssetTable->FindRow<FVacationSpotAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FVacationSpotAssetRow Dummy;
	return Dummy;
}

const FPetAssetRow& UGameResource::GetPetAssetRow(FPetType PetType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), PetType.x);
	const FPetAssetRow* Row = PetAssetTable->FindRow<FPetAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FPetAssetRow Dummy;
	return Dummy;
}

const FRaidAssetRow& UGameResource::GetRaidAssetRow(FSagaType SagaType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), SagaType.x);
	const FRaidAssetRow* Row = RaidAssetTable->FindRow<FRaidAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FRaidAssetRow Dummy;
	return Dummy;
}

const FTodAssetRow* UGameResource::GetTodAssetRow(FString TodPreset) const
{
	return TodAssetTable->FindRow<FTodAssetRow>(FName(*TodPreset), TodPreset, false);
}

const FCharacterAssetRow& UGameResource::GetCharacterAssetRow(FCharacterType CharacterType) const
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(CharacterType);
	return GetCharacterAssetRow(UnitRow.Model);
}

const FCharacterAssetRow& UGameResource::GetCharacterAssetRow(int32 ModelType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), ModelType);
	const FCharacterAssetRow* Row = CharacterAssetTable->FindRow<FCharacterAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FCharacterAssetRow Dummy;
	return Dummy;
}

const FCheckInAssetRow& UGameResource::GetCheckInAssetRow(FCheckInBoardType BoardType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), BoardType.x);
	const FCheckInAssetRow* Row = CheckInAssetTable->FindRow<FCheckInAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FCheckInAssetRow Dummy;
	return Dummy;
}

const FLobbyTemplateAssetRow& UGameResource::GetLobbyTemplateAssetRow(FLobbyTemplateType TemplateType) const
{
	FString TemplateTypeStr = FString::Printf(TEXT("%d"), TemplateType.x);
	const FLobbyTemplateAssetRow* Row = LobbyTemplateAssetTable->FindRow<FLobbyTemplateAssetRow>(FName(*TemplateTypeStr), TemplateTypeStr, false);

	if (Row)
	{
		return *Row;
	}

	// Get default row
	TemplateTypeStr = FString::Printf(TEXT("%d"), 0);
	const FLobbyTemplateAssetRow* DefaultRow = LobbyTemplateAssetTable->FindRow<FLobbyTemplateAssetRow>(FName(*TemplateTypeStr), TemplateTypeStr, false);

	if (DefaultRow)
	{
		return *DefaultRow;
	}

	static FLobbyTemplateAssetRow Dummy;
	return Dummy;
}

const FDropBoxTable& UGameResource::GetDropBoxTableAssetRow(int32 DropBoxSet) const
{
	FString DropBoxSetStr = FString::Printf(TEXT("%d"), DropBoxSet);
	const FDropBoxTable* Row = DropBoxAssetTable->FindRow<FDropBoxTable>(FName(*DropBoxSetStr), DropBoxSetStr, false);

	if (Row)
	{
		return *Row;
	}

	DropBoxSetStr = FString::Printf(TEXT("%d"), 0);
	const FDropBoxTable* DefaultRow = DropBoxAssetTable->FindRow<FDropBoxTable>(FName(*DropBoxSetStr), DropBoxSetStr, false);

	if (DefaultRow)
	{
		return *DefaultRow;
	}

	static FDropBoxTable Dummy;
	return Dummy;
}

void UGameResource::GetDropBoxAssetsPath(int32 DropBoxSet, EDropBoxType DropBoxType, FSoftObjectPath& OutSkeletalMeshPath, FSoftObjectPath& OutAnimationPath)
{
	const FDropBoxTable& DropBoxTable = GetDropBoxTableAssetRow(DropBoxSet);

	switch (DropBoxType)
	{
	case EDropBoxType::NRBox:
		OutSkeletalMeshPath = DropBoxTable.NRBoxSkeletalMesh.GetUniqueID();
		OutAnimationPath = DropBoxTable.NRBoxSpawnAnimation.GetUniqueID();
		break;

	case EDropBoxType::SRBox:
		OutSkeletalMeshPath = DropBoxTable.SRBoxSkeletalMesh.GetUniqueID();
		OutAnimationPath = DropBoxTable.SRBoxSpawnAnimation.GetUniqueID();
		break;

	case EDropBoxType::SSRBox:
		OutSkeletalMeshPath = DropBoxTable.SSRBoxSkeletalMesh.GetUniqueID();
		OutAnimationPath = DropBoxTable.SSRBoxSpawnAnimation.GetUniqueID();
		break;

	case EDropBoxType::RandomSpawnBox:
		OutSkeletalMeshPath = DropBoxTable.RandomSpawnBoxSkeletalMesh.GetUniqueID();
		OutAnimationPath = DropBoxTable.RandomSpawnBoxSpawnAnimation.GetUniqueID();
		break;

	case EDropBoxType::Gold:
		OutSkeletalMeshPath = DropBoxTable.GoldSkeletalMesh.GetUniqueID();
		OutAnimationPath = DropBoxTable.GoldSpawnAnimation.GetUniqueID();
		break;

	default:
		OutSkeletalMeshPath = DropBoxTable.NRBoxSkeletalMesh.GetUniqueID();
		OutAnimationPath = DropBoxTable.NRBoxSpawnAnimation.GetUniqueID();
		break;
	}
}

const FTutorialDialogueAssetRow& UGameResource::GetTutorialDialogueAssetRow(int32 TutorialDialogueType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), TutorialDialogueType);
	const FTutorialDialogueAssetRow* Row = TutorialDialogueAssetTable->FindRow<FTutorialDialogueAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FTutorialDialogueAssetRow Dummy;
	return Dummy;
}

const FTutorialGuideAssetRow& UGameResource::GetTutorialGuideAssetRow(FString GuideKey) const
{
	const FTutorialGuideAssetRow* Row = TutorialGuideAssetTable->FindRow<FTutorialGuideAssetRow>(FName(*GuideKey), GuideKey, false);

	if (Row)
	{
		return *Row;
	}

	static FTutorialGuideAssetRow Dummy;
	return Dummy;
}

const FGuideDialogueAssetRow* UGameResource::GetGuideDialogueAssetRow(int32 GuideDialogueType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), GuideDialogueType);
	return GuideDialogueAssetTable->FindRow<FGuideDialogueAssetRow>(FName(*TypeStr), TypeStr, false);
}

const FGuideActionAssetRow* UGameResource::GetGuideActionAssetRow(int32 GuideActionType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), GuideActionType);
	return GuideActionAssetTable->FindRow<FGuideActionAssetRow>(FName(*TypeStr), TypeStr, false);
}

const FAkaAssetRow* UGameResource::GetAkaAssetRowByPoint(const int32 Point) const
{
	TArray<const FAkaAssetRow*> AkaAssetRows;
	AkaAssetTable->GetAllRows("GetAkaAssetRows", AkaAssetRows);

	const FAkaAssetRow* Find(nullptr);
	for (const FAkaAssetRow* AkaAssetRow : AkaAssetRows)
	{
		if (!AkaAssetRow)
		{
			continue;
		}

		if (AkaAssetRow->Point > Point)
		{
			break;
		}
		else
		{
			Find = AkaAssetRow;
		}
	}

	return Find;
}

const FAkaAssetRow* UGameResource::GetAkaAssetRowByPoint(const int32 BefoPoint, const int32 CurrPoint) const
{
	TArray<const FAkaAssetRow*> AkaAssetRows;
	AkaAssetTable->GetAllRows("GetAkaAssetRows", AkaAssetRows);

	const FAkaAssetRow* Find(nullptr);
	for (const FAkaAssetRow* AkaAssetRow : AkaAssetRows)
	{
		if (!AkaAssetRow)
		{
			continue;
		}

		if (BefoPoint < AkaAssetRow->Point && AkaAssetRow->Point <= CurrPoint)
		{
			Find = AkaAssetRow;
		}
		else if(CurrPoint < AkaAssetRow->Point)
		{
			break;
		}
	}

	return Find;
}

const FAkaAssetRow* UGameResource::GetAkaAssetRowByIndex(int32 Index) const
{
	FString TypeStr = FString::FromInt(Index);
	return AkaAssetTable->FindRow<FAkaAssetRow>(FName(*TypeStr), TypeStr, false);
}

const TArray<EWonderCategory> UGameResource::GetSpecialWonderStageLineup() const
{
	TArray<const FSpecialWonderStageLineupAssetRow*> SpecialWonderStageLineupAssetRows;
	SpecialWonderStageLineupAssetTable->GetAllRows("GetAlchemyLabAssetRows"
		, SpecialWonderStageLineupAssetRows);

	TArray<EWonderCategory> Out;
	for (const FSpecialWonderStageLineupAssetRow* Row : SpecialWonderStageLineupAssetRows)
	{
		if (!Row)
		{
			continue;
		}

		Out.Add(Row->Category);
	}

	return Out;
}

const FAlchemyLabAssetRow* UGameResource::GetAlchemyLabAssetRowByLevel(const int32 Level) const
{
	TArray<const FAlchemyLabAssetRow*> AlchemyLabAssetRows;
	AlchemyLabAssetTable->GetAllRows("GetAlchemyLabAssetRows", AlchemyLabAssetRows);

	for (const FAlchemyLabAssetRow* AlchemyLabAssetRow : AlchemyLabAssetRows)
	{
		if (!AlchemyLabAssetRow)
		{
			continue;
		}

		if (AlchemyLabAssetRow->Level == Level)
		{
			return AlchemyLabAssetRow;
		}
	}

	Q6JsonLogGenie(Warning, "Cannot find AlchemyLabAssetRow", Q6KV("Level", Level));
	return nullptr;
}

const FCaptureAssetRow& UGameResource::GetCaptureAssetRow(int32 CapturePresetType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), CapturePresetType);
	const FCaptureAssetRow* Row = CaptureAssetTable->FindRow<FCaptureAssetRow>(FName(*TypeStr), TypeStr, false);

	if (Row)
	{
		return *Row;
	}

	static FCaptureAssetRow Dummy;
	return Dummy;
}

const FEventListAssetRow* UGameResource::GetEventListAssetRow(int32 InEventType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), InEventType);
	return EventListAssetTable->FindRow<FEventListAssetRow>(FName(*TypeStr), TypeStr, false);
}

const FEventContentCategoryAssetRow* UGameResource::GetEventContentCategoryAssetRow(EEventContentCategory InEventContentCategory) const
{
	const int32 StartRowIndex = 1;
	FString TypeStr = FString::Printf(TEXT("%d"), (int32)InEventContentCategory + StartRowIndex);
	return EventContentCategoryAssetTable->FindRow<FEventContentCategoryAssetRow>(FName(*TypeStr), TypeStr, false);
}

const FAvatarFrameAssetRow* UGameResource::GetAvatarFrameAssetRow(FAvatarFrameType InFrameType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), InFrameType.x);
	return AvatarFrameTable->FindRow<FAvatarFrameAssetRow>(FName(*TypeStr), TypeStr, false);
}

const FAvatarEffectAssetRow* UGameResource::GetAvatarEffectAssetRow(FAvatarEffectType InEffectType) const
{
	FString TypeStr = FString::Printf(TEXT("%d"), InEffectType.x);
	return AvatarEffectTable->FindRow<FAvatarEffectAssetRow>(FName(*TypeStr), TypeStr, false);
}

const FLevelEffectAssetRow* UGameResource::GetLevelEffectAssetRow(int32 Episode, int32 Stage, int32 Wave) const
{
	ensure(LevelEffectTable);

	FString Context;
	TArray<FName> RowNames = LevelEffectTable->GetRowNames();

	for (auto& name : RowNames)
	{
		FLevelEffectAssetRow* Row = LevelEffectTable->FindRow<FLevelEffectAssetRow>(name, Context);
		if (Row)
		{
			if (Row->Episode == Episode && (Row->Stage == LEVEL_EFFECT_ALL_STAGE || Row->Stage == Stage) && 1 == Wave)
			{
				return Row;
			}
		}
	}

	return nullptr;
}

void UGameResource::GetLevelEffectSequencesOfStage(int32 Episode, int32 Stage, TArray<FSoftObjectPath>& OutSeqPaths) const
{
	ensure(LevelEffectTable);

	FString Context;
	TArray<FName> RowNames = LevelEffectTable->GetRowNames();

	for (auto& RowName : RowNames)
	{
		FLevelEffectAssetRow* Row = LevelEffectTable->FindRow<FLevelEffectAssetRow>(RowName, Context);
		if (Row)
		{
			if (Row->Episode == Episode && Row->Stage == Stage)
			{
				if (Row->LevelEffectSequence.IsPending())
				{
					OutSeqPaths.Add(Row->LevelEffectSequence.GetUniqueID());
				}
			}
		}
	}
}

void UGameResource::GetBoneDragonOutroSequence(FSagaType SagaType, TArray<FSoftObjectPath>& OutSeqPaths) const
{
	if (SystemConstHelper::IsBoneDragonSagaType(SagaType))
	{
		if (!BoneDragonOutroSequence.IsNull())
		{
			OutSeqPaths.Add(BoneDragonOutroSequence.GetUniqueID());
		}
	}
}

UFileMediaSource* UGameResource::GetMovieFileMediaSource(int32 Episode, int32 Stage, int32 SubStage) const
{
	FString Context;

	for (auto& name : MovieFileMediaSourceTable->GetRowNames())
	{
		if (FFileMediaSourceAssetRow* Row = MovieFileMediaSourceTable->FindRow<FFileMediaSourceAssetRow>(name, Context))
		{
			if (Row->Episode == Episode && Row->Stage == Stage && Row->SubStage == SubStage)
			{
				return Row->FileMediaSource;
			}
		}
	}

	return nullptr;
}

void UGameResource::BeginUIClassAsyncLoading()
{
	if (!UIClassResource->TryAsyncLoading())
	{
		return;
	}

	TArray<FSoftObjectPath> Paths;
	UIClassResource->GatherStreamingPaths(Paths);

	if (Paths.Num() > 0)
	{
		float StartTime = FPlatformTime::Seconds();

		UIClassStreamingHandle = Streamable.RequestAsyncLoad(Paths, [StartTime]()
			{
				float Duration = FPlatformTime::Seconds() - StartTime;
				Q6JsonLogZagal(Warning, "UI Class AsyncLoading", Q6KV("Time", Duration));
			});
	}
}

void UGameResource::WaitUIClassAsyncLoadingComplete(float Timeout)
{
	if (UIClassStreamingHandle.IsValid())
	{
		if (CVarWaitUIClassAsyncLoading.GetValueOnGameThread() != 0)
		{
			UIClassStreamingHandle->WaitUntilComplete(Timeout);
		}

		UIClassStreamingHandle.Reset();
	}
}

void UGameResource::SetSkeletalMeshOverrideMaterials(USkeletalMeshComponent* Mesh, const FUnitModelAssetRow& Row)
{
	if (!Mesh || !Mesh->SkeletalMesh)
	{
		return;
	}

	if (!Row.Materials.Num())
	{
		return;
	}

	const int MaxMaterials = Mesh->GetNumMaterials();
	for (int32 i = 0; i < Row.Materials.Num(); ++i)
	{
		if (!Row.Materials.IsValidIndex(i))
		{
			return;
		}

		if (Row.Materials[i].Slot < MaxMaterials)
		{
			UMaterialInterface* Material = Row.Materials[i].Material.LoadSynchronous();
			if (Material)
			{
				Mesh->SetMaterial(Row.Materials[i].Slot, Material);
			}
		}
	}
}

FText UGameResource::GetRandomLoadingScreenGameTipText() const
{
	FText TipText = FText::FromString("Loading......");
	if (UIResource && UIResource->LoadingScreenTipTexts.Num() > 0)
	{
		int32 RandIndex = FMath::RandHelper(UIResource->LoadingScreenTipTexts.Num());
		TipText = UIResource->LoadingScreenTipTexts[RandIndex];
	}

	return TipText;
}

/************************************************************************/
/* UI Resource                                                          */
/************************************************************************/
UUIResource::UUIResource(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UUIResource::SetNatureTypeIcon(UImage* Image, ENatureType NatureType, bool bHasIcon)
{
	Image->SetBrush(
		bHasIcon ? GetNatureTypeIcon(NatureType) : GetNatureTypeBlankIcon(NatureType));
}

const FSlateBrush& UUIResource::GetJokerSlotIcon(EJokerSlotType JokerSlot) const
{
	int32 Index = (int32)JokerSlot;
	return (JokerSlotImages.IsValidIndex(Index) ? JokerSlotImages[Index] : DummyIconImage);
}

const FSlateBrush& UUIResource::GetNatureTypeIcon(ENatureType NatureType) const
{
	int32 Index = (int32)NatureType;
	return (NatureTypeImages.IsValidIndex(Index) ? NatureTypeImages[Index] : DummyIconImage);
}

const FSlateBrush& UUIResource::GetNatureTypeBlankIcon(ENatureType NatureType) const
{
	int32 Index = (int32)NatureType;
	return (NatureTypeBlankImages.IsValidIndex(Index) ? NatureTypeBlankImages[Index] : DummyIconImage);
}

const FSlateBrush& UUIResource::GetStageTypeBrush(EStageType StageType) const
{
	int32 Index = (int32)StageType;
	return StageTypeImages.IsValidIndex(Index) ? StageTypeImages[Index] : DummyIconImage;
}

const FNatureRelation& UUIResource::GetNatureRelation(ENatureRelationType Type) const
{
	if (NatureRelations.IsValidIndex((int32)Type))
	{
		return NatureRelations[(int32)Type];
	}

	static FNatureRelation NatureRelation;
	return NatureRelation;
}

const FSlateBrush& UUIResource::GetSummonCardFrame(EItemGrade Grade) const
{
	switch (Grade)
	{
		case EItemGrade::N:
			return SummonCardFrame.N;
		case EItemGrade::R:
			return SummonCardFrame.R;
		case EItemGrade::SR:
			return SummonCardFrame.SR;
		case EItemGrade::SSR:
			return SummonCardFrame.SSR;
	}

	return SummonCardFrame.N;
}

const FSlateBrush& UUIResource::GetSummonInfoGrade(EItemGrade Grade) const
{
	switch (Grade)
	{
		case EItemGrade::N:
			return SummonInfoGrade.N;
		case EItemGrade::R:
			return SummonInfoGrade.R;
		case EItemGrade::SR:
			return SummonInfoGrade.SR;
		case EItemGrade::SSR:
			return SummonInfoGrade.SSR;
	}

	return SummonInfoGrade.N;
}

const FSlateBrush& UUIResource::GetSummonInfoGradeBg(EItemGrade Grade) const
{
	switch (Grade)
	{
		case EItemGrade::N:
			return SummonInfoGradeBg.N;
		case EItemGrade::R:
			return SummonInfoGradeBg.R;
		case EItemGrade::SR:
			return SummonInfoGradeBg.SR;
		case EItemGrade::SSR:
			return SummonInfoGradeBg.SSR;
	}

	return SummonInfoGradeBg.N;
}

const FItemGrade& UUIResource::GetItemGrade(EItemGrade Grade) const
{
	if (ItemGrades.IsValidIndex((int32)Grade))
	{
		return ItemGrades[(int32)Grade];
	}

	static FItemGrade DefaultItemGrade;
	return DefaultItemGrade;
}

const FPointIcon& UUIResource::GetPointIcon(EPointType PointType) const
{
	if (PointIcons.IsValidIndex((int32)PointType))
	{
		return PointIcons[(int32)PointType];
	}

	static FPointIcon DefaultPointIcon;
	return DefaultPointIcon;
}

const FPointIcon& UUIResource::GetPointIcon(ECurrencyType CurrencyType) const
{
	EPointType PointType = GetPointType(CurrencyType);
	return GetPointIcon(PointType);
}

const FSlateBrush& UUIResource::GetLootCategoryIcon(ELootCategory LootCategory) const
{
	if (LootCategory == ELootCategory::Special)
	{
		return SpecialCommonIconBrush;
	}
	else if (LootCategory == ELootCategory::CharUnlockElem)
	{
		return CharUnlockElemIconBrush;
	}

	EPointType PointType = GetPointType(LootCategory);
	return GetPointIcon(PointType).SmallBrush;
}

const FSlateBrush& UUIResource::GetMoonIcon(int32 Moon) const
{
	if (MoonImages.IsValidIndex(Moon))
	{
		return MoonImages[Moon];
	}

	static FSlateBrush DefaultIconImage;
	return DefaultIconImage;
}

const FSlateBrush& UUIResource::GetTierIcon(int32 Tier) const
{
	if (TierImages.IsValidIndex(Tier))
	{
		return TierImages[Tier];
	}

	static FSlateBrush DefaultIconImage;
	return DefaultIconImage;
}

const FSlateBrush& UUIResource::GetSortDirectionIcon(ESortDirection SortDirection) const
{
	if (SortDirectionImages.IsValidIndex((int32)SortDirection))
	{
		return SortDirectionImages[(int32)SortDirection];
	}

	static FSlateBrush DefaultIconImage;
	return DefaultIconImage;
}

const FSlateBrush& UUIResource::GetWonderBG(EWonderCategory Category) const
{
	if (WonderBGBrushes.IsValidIndex((int32)Category))
	{
		return WonderBGBrushes[(int32)Category];
	}

	static FSlateBrush DummyBGBrush;
	return DummyBGBrush;
}

const FSlateBrush& UUIResource::GetWonderIcon(EWonderCategory Category) const
{
	if (WonderIconBrushes.IsValidIndex((int32)Category))
	{
		return WonderIconBrushes[(int32)Category];
	}

	static FSlateBrush DummyIconBrush;
	return DummyIconBrush;
}

const FArtifactIcon& UUIResource::GetArtifactIcon(int32 ArtifactIndex) const
{
	if (ArtifactIcons.IsValidIndex(ArtifactIndex))
	{
		return ArtifactIcons[ArtifactIndex];
	}

	static FArtifactIcon DummyIcon;
	return DummyIcon;
}

const TSoftObjectPtr<UTexture2D>& UUIResource::GetGemRebirthTexture() const
{
	return GemRebirthTexture;
}

const FSlateBrush& UUIResource::GetRaidEmoticon(int32 EmoticonIndex) const
{
	if (RaidEmoticonImages.IsValidIndex(EmoticonIndex))
	{
		return RaidEmoticonImages[EmoticonIndex];
	}

	static FSlateBrush DummyEmoticon;
	return DummyEmoticon;
}

const FSlateBrush& UUIResource::GetSpecialStageIcon(ESpecialCategory SpecialCategory) const
{
	if (SpecialStageIconBrushes.IsValidIndex((int32)SpecialCategory))
	{
		return SpecialStageIconBrushes[(int32)SpecialCategory];
	}

	return DummyIconImage;
}

const TArray<FSlateBrush>& UUIResource::GetSortingFilterIcons(ESortFilterType FilterType) const
{
	if (FilterType == ESortFilterType::Tier)
	{
		return TierImages;
	}

	if (FilterType == ESortFilterType::Nature)
	{
		return NatureTypeImages;
	}

	static TArray<FSlateBrush> DummyBrushes;
	return DummyBrushes;
}

const FSlateBrush& UUIResource::GetGemAmountIcon(EGemAmount InGemAmount) const
{
	if (GemAmountBrushes.IsValidIndex(static_cast<int>(InGemAmount)))
	{
		return GemAmountBrushes[static_cast<int>(InGemAmount)];
	}

	static FSlateBrush DummyBrush;
	return DummyBrush;
}

const FSlateBrush& UUIResource::GetFriendBookFeedIcon(EFriendBookFeedCategory InCategory) const
{
	if (FriendBookFeedBrushes.IsValidIndex((int32)InCategory))
	{
		return FriendBookFeedBrushes[(int32)InCategory];
	}

	return DummyIconImage;
}

const FSlateBrush& UUIResource::GetInitialRewardSpecialTag(EInitialRewardSpecialTagType InitialRewardSpecialTagType) const
{
	if (InitialRewardSpecialTagBrushes.IsValidIndex((int32)InitialRewardSpecialTagType))
	{
		return InitialRewardSpecialTagBrushes[(int32)InitialRewardSpecialTagType];
	}

	return DummyIconImage;
}

const FSlateBrush& UUIResource::GetShopBG(EShopMenu InShopMenu) const
{
	if (ShopBGBrushes.IsValidIndex(static_cast<int>(InShopMenu)))
	{
		return ShopBGBrushes[static_cast<int>(InShopMenu)];
	}

	return DummyIconImage;
}

const FSlateBrush& UUIResource::GetMissionToastIcon(EMissionToastIconType MissionToastType) const
{
	const uint8 Index = static_cast<uint8>(MissionToastType);
	if (MissionToastIconBrushes.IsValidIndex(Index))
	{
		return MissionToastIconBrushes[Index];
	}

	return DummyIconImage;
}

FLinearColor UUIResource::GetEpisodePartColor(int32 Part) const
{
	if (EpisodePartColors.IsValidIndex(Part))
	{
		return EpisodePartColors[Part];
	}

	return FLinearColor::Black;
}

const FText& UUIResource::GetUpgradeCharacterName(EUpgradeCharacterCategory Category) const
{
	if (UpgradeCharacterNames.IsValidIndex((int32)Category))
	{
		return UpgradeCharacterNames[(int32)Category];
	}

	return FText::GetEmpty();
}

const FText& UUIResource::GetUpgradeEquipmentName(EUpgradeEquipCategory Category) const
{
	if (UpgradeEquipmentNames.IsValidIndex((int32)Category))
	{
		return UpgradeEquipmentNames[(int32)Category];
	}

	return FText::GetEmpty();
}

const FText& UUIResource::GetUpgradeSkillName(EUpgradeSkillCategory Category) const
{
	if (UpgradeSkillNames.IsValidIndex((int32)Category))
	{
		return UpgradeSkillNames[(int32)Category];
	}

	return FText::GetEmpty();
}

void UUIResource::SetButtonStyle(UButton* InButton, bool bInEnabled) const
{
	if (!InButton)
	{
		return;
	}

	USlateWidgetStyleAsset* WidgetStyle = bInEnabled ? EnabledButtonStyle : DisabledButtonStyle;
	if (WidgetStyle)
	{
		InButton->SetStyle(*WidgetStyle->GetStyle<FButtonStyle>());
	}
}

const FSortingGroup& UUIResource::GetSortingGroup(ESortCategory Category) const
{
	if (SortingGroups.IsValidIndex((int32)Category))
	{
		return SortingGroups[(int32)Category];
	}

	static FSortingGroup DummySorting;
	return DummySorting;
}

const FSortingOption& UUIResource::GetDefaultSortingSelectedOption(ESortMenu SortMenu, ESortCategory Category) const
{
	for (const FSortingOption& SortingOption : DefaultSortingSelectedOptions)
	{
		if (SortingOption.Category != Category)
		{
			continue;
		}

		if (SortingOption.SortMenu != SortMenu)
		{
			continue;
		}

		return SortingOption;
	}

	static FSortingOption DummySorting;
	return DummySorting;
}

const FSlateBrush& UUIResource::GetNewMarkBrush(ENewMarkType NewMarkType) const
{
	if (NewMarkBrushes.IsValidIndex((int32)NewMarkType))
	{
		return NewMarkBrushes[(int32)NewMarkType];
	}

	static FSlateBrush DummyBrush;
	return DummyBrush;
}


const FSlateBrush* UUIResource::GetRaidUserRankTrophy(const int32 Index) const
{
	if (RaidUserRankTrophies.IsValidIndex(Index))
	{
		return &RaidUserRankTrophies[Index];
	}

	return nullptr;
}


const FSlateBrush* UUIResource::GetEventUserRankTrophy(const int32 Index) const
{
	if (EventUserRankTrophies.IsValidIndex(Index))
	{
		return &EventUserRankTrophies[Index];
	}

	return nullptr;
}

const FSlateBrush& UUIResource::GetReplayStoryBanner(EStoryMenuCategory Category) const
{
	int32 Index = (int32)Category;

	if (ReplayStoryBanners.IsValidIndex(Index))
	{
		return ReplayStoryBanners[Index];
	}

	static FSlateBrush DummyBrush;
	return DummyBrush;
}

const FSlateBrush& UUIResource::GetReplayStoryBG(EStoryMenuCategory Category) const
{
	int32 Index = (int32)Category;

	if (ReplayStoryBGs.IsValidIndex(Index))
	{
		return ReplayStoryBGs[Index];
	}

	static FSlateBrush DummyBrush;
	return DummyBrush;
}

/************************************************************************/
/* Sound Resource                                                       */
/************************************************************************/

USoundBase* USoundResource::GetBGM(const FName& Name) const
{
	ensure(BGMTable);

	if (!Name.IsNone())
	{
		const FBGMAssetRow* Row = BGMTable->FindRow<FBGMAssetRow>(Name, TEXT("GetBGM"), false);
		if (Row)
		{
			return Row->Sound.LoadSynchronous();
		}
	}

	return nullptr;
}

const FCharacterVoiceAssetRow* USoundResource::GetCharacterVoiceAssetRow(FCharacterType CharacterType) const
{
	ensure(CharacterVoiceTable);

	FString TypeStr = FString::FromInt(CharacterType.x);
	return CharacterVoiceTable->FindRow<FCharacterVoiceAssetRow>(FName(*TypeStr), TypeStr, false);
}

USoundBase* USoundResource::GetDialogueVoice(EDialogueType DialogueType, const FName& Name) const
{
	UDataTable* VoiceTable = nullptr;

	switch (DialogueType)
	{
		case EDialogueType::Saga:
		case EDialogueType::Special:
		case EDialogueType::Raid:
		case EDialogueType::Event:
		case EDialogueType::MultiSide:
			VoiceTable = SagaVoiceTable;
			break;
		case EDialogueType::Daily:
			VoiceTable = DailyVoiceTable;
			break;
		case EDialogueType::Training:
			VoiceTable = TrainingVoiceTable;
			break;
	}

	if (VoiceTable && !Name.IsNone())
	{
		const FDialogueVoiceAssetRow* Row = VoiceTable->FindRow<FDialogueVoiceAssetRow>(Name, TEXT("GetDialogueVoice"), false);
		if (Row)
		{
			return Row->Voice.LoadSynchronous();
		}
	}

	return nullptr;
}

USoundBase* USoundResource::GetDialogueSound(int32 SoundType) const
{
	ensure(DialogueSoundTable);

	if (SoundType > 0)
	{
		FString TypeStr = FString::Printf(TEXT("%d"), SoundType);
		const FDialogueSoundAssetRow* Row = DialogueSoundTable->FindRow<FDialogueSoundAssetRow>(FName(*TypeStr), TEXT("GetDialogueSound"), false);
		if (Row)
		{
			return Row->Sound.LoadSynchronous();
		}
	}

	return nullptr;
}

USkeletalMesh* UGameResource::FindCachedSkeletalMesh(int32 ModelType)
{
	USkeletalMesh** result = CachedMergedSkeletalMeshes.Find(ModelType);
	if (result)
	{
		return *result;
	}

	return nullptr;
}

void UGameResource::AddCachedSkeletalMesh(int32 ModelType, USkeletalMesh* SkeletalMesh)
{
	if (!FindCachedSkeletalMesh(ModelType))
	{
		CachedMergedSkeletalMeshes.Add(ModelType, SkeletalMesh);
	}
}

AQ6Capture2D* UGameResource::SpawnOrGetTutorialDialogueCapture(UWorld* World) const
{
	static const FName Tag(TEXT("Capture.Tutorial"));

	AQ6Capture2D* CaptureActor = ULevelUtil::FindCaptureActor(World, Tag);
	if (!CaptureActor)
	{
		FActorSpawnParameters SpawnParam;
		SpawnParam.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		CaptureActor = World->SpawnActor<AQ6Capture2D>(TutorialCaptureClass.LoadSynchronous(), SpawnParam);
		check(CaptureActor);
		CaptureActor->GetCaptureComponent2D()->ShowOnlyActors.Add(CaptureActor);
	}

	return CaptureActor;
}

bool UGameResource::PlayMovie(UFileMediaSource* FileMeidaSource, FSimpleDelegate InFinishedCallback)
{
	if (!FileMeidaSource)
	{
		return false;
	}

	AQ6MediaPlayer* MediaPlayer = nullptr;
	for (TActorIterator<AQ6MediaPlayer> It(GetWorld(), AQ6MediaPlayer::StaticClass()); It; ++It)
	{
		MediaPlayer = *It;
		if (MediaPlayer)
		{
			break;
		}
	}

	if (!MediaPlayer)
	{
		FActorSpawnParameters SpawnParam;
		SpawnParam.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
		MediaPlayer = GetWorld()->SpawnActor<AQ6MediaPlayer>(MediaPlayerClass.LoadSynchronous(), SpawnParam);
	}

	if (MediaPlayer)
	{
		return MediaPlayer->OpenSource(FileMeidaSource, InFinishedCallback);
	}

	return false;
}

UWorld* UGameResource::GetWorld() const
{
	if (auto GameInstance = UQ6GameInstance::Get())
	{
		if (auto Context = GameInstance->GetWorldContext())
		{
			return Context->World();
		}
	}

	return nullptr;
}