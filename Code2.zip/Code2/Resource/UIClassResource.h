// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"

#include "UIClassResource.generated.h"

class UAccountWidget;
class UNavigationBarWidget;
class UMainWidget;
class ULobbySettingWidget;
class USagaWidget;
class USummonWidget;
class UInventoryWidget;
class UPartyWidget;
class UDialogueWidget;
class UJokerSelectWidget;
class UUpgradeWidget;
class USpecialWidget;
class UFriendWidget;
class UDailyDungeonWidget;
class UTrainingCenterWidget;
class UInitialRewardEventWidget;
class UWonderWidget;
class URaidWidget;
class UBondUpResultWidget;
class UCodexWidget;
class UWeeklyMissionWidget;
class UAchievementsPageWidget;
class UAchievementsPuzzleWidget;
class UBagWidget;
class UShopWidget;
class USellShopWidget;
class UEventMainWidget;
class USettingPopupWidget;
class UGeneralShopPurchasePopupWidget;
class UGemShopPurchasePopupWidget;
class UGetAkaConfirmPopupWidget;
class UItemReceivedPopupWidget;
class UPlayRecordPopupWidget;
class USellShopPurchasePopupWidget;
class UEventRewardPopupWidget;

class UUpgradeResultWidget;
class UItemMaxLevelUpConfirmPopupWidget;
class UItemRewardPopupWidget;
class UCurrencyUsePopupWidget;
class USkillUpgradeConfirmPopupWidget;
class USortingChangePopupWidget;
class UFriendshipCollectPopupWidget;
class UBondRewardInfoPopupWidget;
class UItemSelectPopupWidget;
class UMailListPopupWidget;
class UMailReceivedPopupWidget;
class UStoryWidget;

UCLASS(Blueprintable)
class Q6_API UUIClassResource : public UObject
{
	GENERATED_BODY()

public:
	UUIClassResource(const FObjectInitializer& ObjectInitializer);

	void GatherStreamingPaths(TArray<FSoftObjectPath>& Paths);

	bool TryAsyncLoading();

	// Bar Widget Classes

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UNavigationBarWidget> NavigationBarWidgetClass;

	// Lobby Widget Classes

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UMainWidget> MainWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<ULobbySettingWidget> LobbySettingWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<USagaWidget> SagaWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<USummonWidget> SummonWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UInventoryWidget> InventoryWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UPartyWidget> PartyWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UDialogueWidget> DialogueWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UJokerSelectWidget> JokerSelectWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UUpgradeWidget> UpgradeWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<USpecialWidget> SpecialWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UFriendWidget> FriendWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UDailyDungeonWidget> DailyDungeonWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UTrainingCenterWidget> TrainingCenterWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UInitialRewardEventWidget> InitialRewardEventWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UWonderWidget> WonderWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<URaidWidget> RaidWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UBondUpResultWidget> BondUpResultWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UCodexWidget> CodexWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UWeeklyMissionWidget> WeeklyMissionWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UShopWidget> ShopWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UBagWidget> BagWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UEventMainWidget> EventMainWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UAccountWidget> AccountWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "LobbyHUDWidget")
	TSoftClassPtr<UStoryWidget> StoryWidgetClass;

	// Popup Widget Classes

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UUpgradeResultWidget> UpgradeResultWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UItemMaxLevelUpConfirmPopupWidget> PromoteConfirmPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UItemRewardPopupWidget> ItemRewardPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UCurrencyUsePopupWidget> CurrencyUsePopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<USkillUpgradeConfirmPopupWidget> SkillUpgradeConfirmPopupClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<USortingChangePopupWidget> SortingOrderFilterPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UFriendshipCollectPopupWidget> FriendshipCollectPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UBondRewardInfoPopupWidget> BondRewardInfoPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UItemSelectPopupWidget> ItemSelectPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UMailListPopupWidget> MailListPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UMailReceivedPopupWidget> MailReceivedPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<USettingPopupWidget> SettingPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UGeneralShopPurchasePopupWidget> GeneralShopPurchasePopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UGemShopPurchasePopupWidget> GemShopPurchasePopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UItemReceivedPopupWidget> ItemReceivedPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UAchievementsPageWidget> AchievementsPageWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UAchievementsPuzzleWidget> AchievementsPuzzleWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UPlayRecordPopupWidget> PlayRecordPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UGetAkaConfirmPopupWidget> GetAkaConfirmPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<USellShopPurchasePopupWidget> SellShopPurchasePopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UEventRewardPopupWidget> EventRewardPopupWidgetClass;

private:
	bool bNeedAsyncLoading;
};
