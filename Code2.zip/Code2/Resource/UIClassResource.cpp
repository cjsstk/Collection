// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "UIClassResource.h"

#include "AccountWidgets.h"
#include "BagWidgets.h"
#include "CombatReadyWidgets.h"
#include "DailyDungeonWidget.h"
#include "DialogueWidget.h"
#include "FriendWidgets.h"
#include "InventoryWidgets.h"
#include "ItemWidgets.h"
#include "MainWidgets.h"
#include "NavigationBarWidgets.h"
#include "PartyWidgets.h"
#include "RaidWidgets.h"
#include "SagaWidgets.h"
#include "SpecialWidgets.h"
#include "SummonWidgets.h"
#include "TrainingCenterWidget.h"
#include "UpgradeWidgets.h"
#include "WonderWidgets.h"

UUIClassResource::UUIClassResource(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bNeedAsyncLoading = true;
}

bool UUIClassResource::TryAsyncLoading()
{
	if (bNeedAsyncLoading)
	{
		bNeedAsyncLoading = false;
		return true;
	}

	return false;
}

void UUIClassResource::GatherStreamingPaths(TArray<FSoftObjectPath>& Paths)
{
	const int32 NumReserved = 30;
	Paths.Reset(NumReserved);

	// Bar Widget Classes

	Paths.Add(NavigationBarWidgetClass.GetUniqueID());

	// Lobby Widget Classes

	Paths.Add(MainWidgetClass.GetUniqueID());
	Paths.Add(SagaWidgetClass.GetUniqueID());
	Paths.Add(SummonWidgetClass.GetUniqueID());
	Paths.Add(InventoryWidgetClass.GetUniqueID());
	Paths.Add(PartyWidgetClass.GetUniqueID());
	Paths.Add(DialogueWidgetClass.GetUniqueID());
	Paths.Add(JokerSelectWidgetClass.GetUniqueID());
	Paths.Add(UpgradeWidgetClass.GetUniqueID());
	Paths.Add(SpecialWidgetClass.GetUniqueID());
	Paths.Add(FriendWidgetClass.GetUniqueID());
	Paths.Add(DailyDungeonWidgetClass.GetUniqueID());
	Paths.Add(TrainingCenterWidgetClass.GetUniqueID());
	Paths.Add(InitialRewardEventWidgetClass.GetUniqueID());
	Paths.Add(WonderWidgetClass.GetUniqueID());
	Paths.Add(RaidWidgetClass.GetUniqueID());
	Paths.Add(BondUpResultWidgetClass.GetUniqueID());
	Paths.Add(CodexWidgetClass.GetUniqueID());
	Paths.Add(WeeklyMissionWidgetClass.GetUniqueID());

	// Popup Widget Classes

	Paths.Add(UpgradeResultWidgetClass.GetUniqueID());
	Paths.Add(PromoteConfirmPopupWidgetClass.GetUniqueID());
	Paths.Add(ItemRewardPopupWidgetClass.GetUniqueID());
	Paths.Add(CurrencyUsePopupWidgetClass.GetUniqueID());
	Paths.Add(SkillUpgradeConfirmPopupClass.GetUniqueID());
	Paths.Add(SortingOrderFilterPopupWidgetClass.GetUniqueID());
	Paths.Add(FriendshipCollectPopupWidgetClass.GetUniqueID());
	Paths.Add(BondRewardInfoPopupWidgetClass.GetUniqueID());
	Paths.Add(ItemSelectPopupWidgetClass.GetUniqueID());
}