// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "UObject/NoExportTypes.h"
#include "GameAssetCache.generated.h"

struct FPetType;

struct FAssetCacheOptions
{
	bool bBlocking;
	uint32 Priority;
};

struct FUnitAssetCacheOptions : FAssetCacheOptions
{
	bool bIncludeCombatPortraits;
	bool bIncludeResultSequence;
};

enum class EDropBoxType : uint8;

// Delegate to get stream finished notification
DECLARE_DELEGATE(FGameAssetStreamDelegate);

/**
* Game Asset Cache
*/
UCLASS()
class UGameAssetCache : public UObject
{
	GENERATED_BODY()

public:
	UGameAssetCache();

	bool IsLoaded() const { return bLoaded; }
	void SetFinishEvent(FGameAssetStreamDelegate Delegate) { FinishEvent = Delegate; }

	void AddAnimation(const FSoftObjectPath& Path);
	void AddPortraitTexture(int32 InUnitType, int32 InModelType, const FSoftObjectPath& Path);
	void AddAnimInstance(int32 InModelType, const FSoftObjectPath& Path);
	void AddSkeletalMesh(int32 InModelType, const FSoftObjectPath& Path);
	void AddMaterial(int32 InModelType, const FSoftObjectPath& Paths);
	void AddSkillSequence(int32 InUnitType, int32 InModelType, int32 InSkillType, const FSoftObjectPath& Path);
	void AddSkillPostEffectParticle(int32 InUnitType, int32 InModelType, int32 InSkillType, const FSoftObjectPath& Path);
	void AddResultSequence(int32 InUnitType, int32 InModelType, const FSoftObjectPath& Path);
	void AddPetSkillSequence(int32 InModelType, const FSoftObjectPath& Path);
	void AddSequence(const FSoftObjectPath& Path);

	void Load(const FAssetCacheOptions& Options);
	void CancelStreaming();

	const TArray<UObject*>& GetLoadedObjects() const { return LoadedObjects; }

private:

	// PRIVATE only. can't find asset's source.
	bool Add(const FSoftObjectPath& Path);

	void AddAnimSpawningAssets();
	void LoadInternal();

	void OnAnimStreamingComplete();
	void OnStreamingComplete();

	UPROPERTY()
	TArray<FSoftObjectPath> AnimAssetPaths;

	UPROPERTY()
	TArray<FSoftObjectPath> AssetPaths;

	UPROPERTY()
	TArray<UObject*> LoadedAnimations;

	UPROPERTY()
	TArray<UObject*> LoadedObjects;

	FGameAssetStreamDelegate FinishEvent;

	bool bBlockingLoading;
	uint32 StreamPriority;

	bool bLoaded;
};

UCLASS()
class UGameAssetCacheManager : public UObject
{
	GENERATED_BODY()

public:
	UGameAssetCache* CacheUnit(int32 UnitType, const FUnitAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent);
	UGameAssetCache* CachePetUnit(FPetType PetType, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent);
	UGameAssetCache* CacheAnimations(int32 ModelType, const TArray<FSoftObjectPath>& AnimationPaths, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent);
	UGameAssetCache* CacheSkillSequences(int32 ModelType, const TArray<FSoftObjectPath>& SkillSequencePaths, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent);
	UGameAssetCache* CacheDropBox(int32 DropBoxSet, EDropBoxType DropBoxType, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent);
	UGameAssetCache* CacheDialogue(const TArray<int32> Models, const TArray<FSoftObjectPath>& SeqPaths, const FAssetCacheOptions& Options);
	UGameAssetCache* CacheSequences(const TArray<FSoftObjectPath>& Paths, const FAssetCacheOptions& Options);

private:
	void GatherModelAssets(int32 ModelType, UGameAssetCache* NewGameAssetCache);
	void GatherUnitAssets(int32 UnitType, const FUnitAssetCacheOptions& Options, UGameAssetCache* NewGameAssetCache, TArray<int32>* GatheredUnits);
	void GatherPetUnitAssets(FPetType PetType, UGameAssetCache* NewGameAssetCache, TArray<int32>* GatheredPetUnits);
};
