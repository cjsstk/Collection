// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "GameAssetCache.h"
#include "Animation/AnimNotifies/AnimNotify_PlayParticleEffect.h"
#include "AnimNotify/UnitAnimNotifies.h"
#include "CMS_gen.h"
#include "GameResource.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "DropBox.h"

UGameAssetCache::UGameAssetCache()
	: bLoaded(false)
{
}

void UGameAssetCache::AddAnimation(const FSoftObjectPath& Path)
{
	if (Path.IsValid())
	{
		AnimAssetPaths.Add(Path);
	}
	else
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid path", Q6KV("Path", *Path.GetAssetPathString()));
	}
}

bool UGameAssetCache::Add(const FSoftObjectPath& Path)
{
	if (!Path.IsValid())
	{
		return false;
	}

	AssetPaths.Add(Path);
	return true;
}

void UGameAssetCache::AddPortraitTexture(int32 InUnitType, int32 InModelType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid portrait texture", Q6KV("UnitType", InUnitType), Q6KV("ModelType", InModelType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddAnimInstance(int32 InModelType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid anim instance", Q6KV("ModelType", InModelType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddSkeletalMesh(int32 InModelType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid skeletal mesh", Q6KV("ModelType", InModelType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddMaterial(int32 InModelType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid material", Q6KV("ModelType", InModelType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddSkillSequence(int32 InUnitType, int32 InModelType, int32 InSkillType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid skill sequence", Q6KV("UnitType", InUnitType), Q6KV("ModelType", InModelType), Q6KV("SkillType", InSkillType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddSkillPostEffectParticle(int32 InUnitType, int32 InModelType, int32 InSkillType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid skill post effect particle", Q6KV("UnitType", InUnitType), Q6KV("ModelType", InModelType), Q6KV("SkillType", InSkillType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddResultSequence(int32 InUnitType, int32 InModelType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid result sequence", Q6KV("UnitType", InUnitType), Q6KV("ModelType", InModelType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddPetSkillSequence(int32 InModelType, const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogSunny(Warning, "UGameAssetCache invalid pet skill sequence", Q6KV("ModelType", InModelType), Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::AddSequence(const FSoftObjectPath& Path)
{
	if (!Add(Path))
	{
		Q6JsonLogZagal(Warning, "UGameAssetCache invalid sequence", Q6KV("Path", *Path.GetAssetPathString()));
	}
}

void UGameAssetCache::Load(const FAssetCacheOptions& Options)
{
	// NOTE : In automation, do blocking load
	bBlockingLoading = Options.bBlocking || FAutomationTestFramework::GetInstance().GetCurrentTest(); // || GEngine->IsEditor();
	StreamPriority = Options.Priority;

	if (!AnimAssetPaths.Num())
	{
		LoadInternal();
		return;
	}

	if (bBlockingLoading)
	{
		for (FSoftObjectPath& Path : AnimAssetPaths)
		{
			LoadedAnimations.Add(FSoftObjectPtr(Path).LoadSynchronous());
		}

		OnAnimStreamingComplete();
	}
	else
	{
		GetGameResource().Streamable.RequestAsyncLoad(
			AnimAssetPaths,
			FStreamableDelegate::CreateUObject(this, &UGameAssetCache::OnAnimStreamingComplete),
			StreamPriority);
	}
}

void UGameAssetCache::OnAnimStreamingComplete()
{
	if (!bBlockingLoading)
	{
		for (auto& Asset : AnimAssetPaths)
		{
			UObject* Object = Asset.ResolveObject();
			if (Object)
			{
				LoadedAnimations.Add(Object);
			}
		}
	}

	AddAnimSpawningAssets();
	LoadInternal();
}

void UGameAssetCache::AddAnimSpawningAssets()
{
	for (UObject* AnimObj : LoadedAnimations)
	{
		UAnimSequenceBase* Animation = Cast<UAnimSequenceBase>(AnimObj);
		if (!Animation || !Animation->IsNotifyAvailable())
		{
			continue;
		}

		for (const FAnimNotifyEvent& Event : Animation->Notifies)
		{
			if (UFireProjectile* FireProjectile = Cast<UFireProjectile>(Event.Notify))
			{
				if (!FireProjectile->ProjectileEffectDesc.Projectile.IsNull())
				{
					AssetPaths.AddUnique(FireProjectile->ProjectileEffectDesc.Projectile.GetUniqueID());
				}

				if (FireProjectile->SpawnHitParticleParam.Particle)
				{
					AssetPaths.AddUnique(FireProjectile->SpawnHitParticleParam.Particle->GetPathName());
				}
			}
			else if (UHitWithWeight* HitWithWeight = Cast<UHitWithWeight>(Event.Notify))
			{
				if (HitWithWeight->SpawnHitParticleParam.Particle)
				{
					AssetPaths.AddUnique(HitWithWeight->SpawnHitParticleParam.Particle->GetPathName());
				}
			}
			else if (UAnimNotify_PlayParticleEffect* PlayParticleEffect = Cast<UAnimNotify_PlayParticleEffect>(Event.Notify))
			{
				if (PlayParticleEffect->PSTemplate)
				{
					AssetPaths.AddUnique(PlayParticleEffect->PSTemplate->GetPathName());
				}
			}
		}
	}
}

void UGameAssetCache::LoadInternal()
{
	if (bBlockingLoading)
	{
		for (FSoftObjectPath& Path : AssetPaths)
		{
			LoadedObjects.Add(FSoftObjectPtr(Path).LoadSynchronous());
		}

		OnStreamingComplete();
	}
	else
	{
		GetGameResource().Streamable.RequestAsyncLoad(
			AssetPaths,
			FStreamableDelegate::CreateUObject(this, &UGameAssetCache::OnStreamingComplete),
			StreamPriority);
	}
}

void UGameAssetCache::OnStreamingComplete()
{
	if (!bBlockingLoading)
	{
		for (auto& Asset : AssetPaths)
		{
			UObject* Object = Asset.ResolveObject();
			if (Object)
			{
				LoadedObjects.Add(Object);
			}
		}
	}

	ensure(bLoaded == false);
	bLoaded = true;

	FinishEvent.ExecuteIfBound();
}

void UGameAssetCache::CancelStreaming()
{
	// TODO : we need to cancel actual streaming underlying..
	FinishEvent.Unbind();
}

UGameAssetCache* UGameAssetCacheManager::CacheUnit(int32 UnitType, const FUnitAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent)
{
	Q6JsonLogSunny(Display, "Cache Unit", Q6KV("UnitType", UnitType));

	UGameAssetCache* NewGameAssetCache = NewObject<UGameAssetCache>();
	NewGameAssetCache->SetFinishEvent(FinishEvent);

	TArray<int32> GatheredUnits;
	GatherUnitAssets(UnitType, Options, NewGameAssetCache, &GatheredUnits);

	NewGameAssetCache->Load(Options);

	Q6JsonLogSunny(Display, "Cache Unit .. done!", Q6KV("UnitType", UnitType));

	return NewGameAssetCache;
}

void UGameAssetCacheManager::GatherModelAssets(int32 ModelType, UGameAssetCache* NewGameAssetCache)
{
	const FUnitModelAssetRow& ModelAssetRow = GetGameResource().GetUnitModelAssetRow(ModelType);

	// model caching
	NewGameAssetCache->AddAnimInstance(ModelType, ModelAssetRow.AnimInstanceClass.GetUniqueID());
	NewGameAssetCache->AddSkeletalMesh(ModelType, ModelAssetRow.SkeletalMesh.GetUniqueID());

	// additional skeletalMesh parts caching
	for (TSoftObjectPtr<USkeletalMesh> PartMesh : ModelAssetRow.SkeletalMeshParts)
	{
		NewGameAssetCache->AddSkeletalMesh(ModelType, PartMesh.GetUniqueID());
	}

	for (const auto& MaterialSlot: ModelAssetRow.Materials)
	{
		NewGameAssetCache->AddMaterial(ModelType, MaterialSlot.Material.GetUniqueID());
	}
}

void UGameAssetCacheManager::GatherUnitAssets(int32 UnitType, const FUnitAssetCacheOptions& Options, UGameAssetCache* NewGameAssetCache, TArray<int32>* GatheredUnits)
{
	if (GatheredUnits->Contains(UnitType))
	{
		return;
	}
	GatheredUnits->Emplace(UnitType);

	UGameResource& GameResource = GetGameResource();
	int32 ModelType = GetCMS()->GetModelTypeFromUnitType(UnitType);
	GatherModelAssets(ModelType, NewGameAssetCache);

	// combat portraits caching
	if (Options.bIncludeCombatPortraits)
	{
		const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(UnitType));
		const FCharacterAssetRow& CharacterAssetRow = GameResource.GetCharacterAssetRow(UnitRow.Model);
		NewGameAssetCache->AddPortraitTexture(UnitType, ModelType, CharacterAssetRow.CombatPortraitTexture.GetUniqueID());
		NewGameAssetCache->AddPortraitTexture(UnitType, ModelType, CharacterAssetRow.CombatIconTexture.GetUniqueID());
	}

	// skill sequence caching
	for (int32 SkillNoteIndex = (int32)ESkillNote::None; SkillNoteIndex < ESkillNoteMax; ++SkillNoteIndex)
	{
		const FNormalSkillSequenceAssetRow& NormalSkillSequenceAssetRow = GameResource.GetNormalSkillSequenceAssetRow(ModelType, (ESkillNote)SkillNoteIndex, false);
		if (!NormalSkillSequenceAssetRow.CameraSequence.IsNull())
		{
			NewGameAssetCache->AddSkillSequence(UnitType, ModelType, SkillTypeInvalid.x, NormalSkillSequenceAssetRow.CameraSequence.GetUniqueID());
		}
	}

	const FNormalSkillSequenceAssetRow& DoubleSkillSequenceAssetRow = GameResource.GetDoubleSkillSequenceAssetRow(ModelType, false);
	if (!DoubleSkillSequenceAssetRow.CameraSequence.IsNull())
	{
		NewGameAssetCache->AddSkillSequence(UnitType, ModelType, SkillTypeInvalid.x, DoubleSkillSequenceAssetRow.CameraSequence.GetUniqueID());
	}

	const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRowFromModelType = GameResource.GetModelUltimateSkillSequenceAssetRow(ModelType, false);
	if (!UltimateSkillSequenceAssetRowFromModelType.SkillSequence.IsNull())
	{
		NewGameAssetCache->AddSkillSequence(UnitType, ModelType, SkillTypeInvalid.x, UltimateSkillSequenceAssetRowFromModelType.SkillSequence.GetUniqueID());
	}
	if (UltimateSkillSequenceAssetRowFromModelType.SkillPostEffect.HitParticleParam.Particle)
	{
		NewGameAssetCache->AddSkillPostEffectParticle(UnitType, ModelType, SkillTypeInvalid.x, UltimateSkillSequenceAssetRowFromModelType.SkillPostEffect.HitParticleParam.Particle->GetPathName());
	}

	TArray<const FCMSSkillRow*> UnitSkillRows;
	if (GetCMS()->GetUnitToNormalSkillsMap().Contains(FUnitType(UnitType)))
	{
		UnitSkillRows.Append(GetCMS()->GetUnitToNormalSkillsMap()[FUnitType(UnitType)]);
	}
	if (GetCMS()->GetUnitToUltimateSkillsMap().Contains(FUnitType(UnitType)))
	{
		UnitSkillRows.Append(GetCMS()->GetUnitToUltimateSkillsMap()[FUnitType(UnitType)]);
	}

	for (const FCMSSkillRow* SkillRow : UnitSkillRows)
	{
		const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRowFromSkillType = GameResource.GetSkillUltimateSkillSequenceAssetRow(SkillRow->Type, false);
		if (!UltimateSkillSequenceAssetRowFromSkillType.SkillSequence.IsNull())
		{
			NewGameAssetCache->AddSkillSequence(UnitType, ModelType, SkillRow->Type, UltimateSkillSequenceAssetRowFromSkillType.SkillSequence.GetUniqueID());
		}
		if (UltimateSkillSequenceAssetRowFromSkillType.SkillPostEffect.HitParticleParam.Particle)
		{
			NewGameAssetCache->AddSkillPostEffectParticle(UnitType, ModelType, SkillRow->Type, UltimateSkillSequenceAssetRowFromModelType.SkillPostEffect.HitParticleParam.Particle->GetPathName());
		}
	}

	// result sequence caching
	if (Options.bIncludeResultSequence)
	{
		const FResultSequenceAssetRow& ResultSequenceAssetRow = GameResource.GetResultSequenceAssetRow(ModelType);
		NewGameAssetCache->AddResultSequence(UnitType, ModelType, ResultSequenceAssetRow.ResultSequence.GetUniqueID());
	}
}

UGameAssetCache* UGameAssetCacheManager::CachePetUnit(FPetType PetType, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent)
{
	Q6JsonLogSunny(Display, "Cache Pet Unit", Q6KV("PetType", PetType.x));

	UGameAssetCache* NewGameAssetCache = NewObject<UGameAssetCache>();
	NewGameAssetCache->SetFinishEvent(FinishEvent);

	TArray<int32> GatheredPetUnits;
	GatherPetUnitAssets(PetType, NewGameAssetCache, &GatheredPetUnits);

	NewGameAssetCache->Load(Options);

	Q6JsonLogSunny(Display, "Cache Pet Unit .. done!", Q6KV("PetType", PetType.x));

	return NewGameAssetCache;
}

void UGameAssetCacheManager::GatherPetUnitAssets(FPetType PetType, UGameAssetCache* NewGameAssetCache, TArray<int32>* GatheredPetUnits)
{
	if (GatheredPetUnits->Contains(PetType.x))
	{
		return;
	}
	GatheredPetUnits->Emplace(PetType.x);

	UGameResource& GameResource = GetGameResource();
	int32 ModelType = GameResource.GetPetAssetRow(PetType).ModelType;
	GatherModelAssets(ModelType, NewGameAssetCache);
}

UGameAssetCache* UGameAssetCacheManager::CacheAnimations(int32 ModelType, const TArray<FSoftObjectPath>& AnimationPaths, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent)
{
	Q6JsonLogSunny(Display, "Cache Animations", Q6KV("ModelType", ModelType), Q6KV("First Anim", AnimationPaths[0].GetAssetPathString()));

	UGameAssetCache* NewGameAssetCache = NewObject<UGameAssetCache>();
	NewGameAssetCache->SetFinishEvent(FinishEvent);

	for (const FSoftObjectPath& Path : AnimationPaths)
	{
		NewGameAssetCache->AddAnimation(Path);
	}

	NewGameAssetCache->Load(Options);

	Q6JsonLogSunny(Display, "Cache Animations .. done!", Q6KV("ModelType", ModelType), Q6KV("Anim Count", AnimationPaths.Num()));

	return NewGameAssetCache;
}

UGameAssetCache* UGameAssetCacheManager::CacheSkillSequences(int32 ModelType, const TArray<FSoftObjectPath>& SkillSequencePaths, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent)
{
	Q6JsonLogSunny(Display, "Cache Skill Sequence", Q6KV("ModelType", ModelType), Q6KV("First Skill Sequence", SkillSequencePaths[0].GetAssetPathString()));

	UGameAssetCache* NewGameAssetCache = NewObject<UGameAssetCache>();
	NewGameAssetCache->SetFinishEvent(FinishEvent);

	for (const FSoftObjectPath& Path : SkillSequencePaths)
	{
		NewGameAssetCache->AddPetSkillSequence(ModelType, Path);
	}

	NewGameAssetCache->Load(Options);

	Q6JsonLogSunny(Display, "Cache Skill Sequence .. done!", Q6KV("ModelType", ModelType), Q6KV("Skill Sequence Count", SkillSequencePaths.Num()));

	return NewGameAssetCache;
}

UGameAssetCache* UGameAssetCacheManager::CacheDropBox(int32 DropBoxSet, EDropBoxType DropBoxType, const FAssetCacheOptions& Options, FGameAssetStreamDelegate FinishEvent)
{
	Q6JsonLogPawn(Display, "Cache DropBox", Q6KV("DropBoxType", (int32)DropBoxType));

	UGameAssetCache* NewGameAssetCache = NewObject<UGameAssetCache>();
	NewGameAssetCache->SetFinishEvent(FinishEvent);

	FSoftObjectPath SkeletalMeshPath;
	FSoftObjectPath AnimationPath;
	GetGameResource().GetDropBoxAssetsPath(DropBoxSet, DropBoxType, SkeletalMeshPath, AnimationPath);

	NewGameAssetCache->AddSkeletalMesh((int32)DropBoxType, SkeletalMeshPath);
	NewGameAssetCache->AddAnimation(AnimationPath);

	NewGameAssetCache->Load(Options);

	Q6JsonLogPawn(Display, "Cache DropBox .. done!", Q6KV("DropBoxType", (int32)DropBoxType));

	return NewGameAssetCache;
}

UGameAssetCache* UGameAssetCacheManager::CacheDialogue(const TArray<int32> Models, const TArray<FSoftObjectPath>& SeqPaths, const FAssetCacheOptions& Options)
{
	UGameAssetCache* NewGameAssetCache = nullptr;

	if (Models.Num() > 0 || SeqPaths.Num() > 0)
	{
		Q6JsonLog(Display, "Cache dialogue", Q6KV("Model", Models.Num()), Q6KV("Sequence", SeqPaths.Num()));

		NewGameAssetCache = NewObject<UGameAssetCache>();

		for (int32 ModelType : Models)
		{
			GatherModelAssets(ModelType, NewGameAssetCache);
		}

		for (const FSoftObjectPath& Path : SeqPaths)
		{
			NewGameAssetCache->AddSequence(Path);
		}

		NewGameAssetCache->Load(Options);

		Q6JsonLog(Display, "Cache dialogue .. done!", Q6KV("Model", Models.Num()), Q6KV("Sequence", SeqPaths.Num()));
	}

	return NewGameAssetCache;
}

UGameAssetCache* UGameAssetCacheManager::CacheSequences(const TArray<FSoftObjectPath>& Paths, const FAssetCacheOptions& Options)
{
	UGameAssetCache* NewGameAssetCache = nullptr;

	if (Paths.Num() > 0)
	{
		Q6JsonLog(Display, "Cache sequences", Q6KV("Count", Paths.Num()));

		NewGameAssetCache = NewObject<UGameAssetCache>();

		for (const FSoftObjectPath& Path : Paths)
		{
			NewGameAssetCache->AddSequence(Path);
		}

		NewGameAssetCache->Load(Options);

		Q6JsonLog(Display, "Cache sequences .. done!", Q6KV("Count", Paths.Num()));
	}

	return NewGameAssetCache;
}
