// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMS_gen.h"
#include "CombatPlayerController.h"
#include "Engine/DataTable.h"
#include "Engine/Texture2D.h"
#include "Engine/SkeletalMesh.h"
#include "Engine/StreamableManager.h"
#include "Internationalization/StringTable.h"
#include "Internationalization/StringTableCore.h"
#include "LevelSequence.h"
#include "Q6.h"
#include "Q6Enum.h"
#include "Q6Log.h"
#include "Q6Minimal.h"
#include "Q6UIDefine.h"
#include "Styling/SlateBrush.h"
#include "UMG.h"
#include "UObject/NoExportTypes.h"
#include "WidgetUtil.h"

#include "GameResource.generated.h"
class AProjectile;
class ALobbyTemplate;

class UGameAssetCacheManager;
class UUIResource;
class UGuideBase;
class UUIClassResource;
class UItemCardWidget;
class UCombatGameResource;
class USoundResource;
class UUnitAnimInstance;
class ULevelSequence;
class USkillAnimationWidget;
class USoundConcurrency;
class ULoadingScreenWidget;
class UEpisodeTitleWidget;
class UStageTitleWidget;
class UCheckInBaseWidget;
class UAnimationAsset;
class AQ6Capture2D;
class UUltimateIllustWidget;
class UFileMediaSource;
class AQ6MediaPlayer;

enum class EBuffCategory : uint8;
enum class EItemGrade : uint8;
enum class EDialogueCameraEffect : uint8;
enum class ESequencePlayPositon : uint8;
enum class EDropBoxType : uint8;

USTRUCT(BlueprintType)
struct FQ6MaterialOverrideSlot
{
	GENERATED_USTRUCT_BODY()

	FQ6MaterialOverrideSlot()
		: Slot(-1)
		, Material(nullptr)
	{}

	FQ6MaterialOverrideSlot(int32 InSlot, TSoftObjectPtr<UMaterialInterface> InMaterial)
		: Slot(InSlot)
		, Material(InMaterial)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	int32 Slot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	TSoftObjectPtr<UMaterialInterface> Material;
};

USTRUCT(BlueprintType)
struct FQ6ParticleSocket
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Particle")
	FName Socket;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Particle")
	TSoftObjectPtr<UParticleSystem> PSTemplate;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Particle")
	FVector Offset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Particle")
	FRotator Rotation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Particle")
	FVector Scale = FVector::OneVector;
};

USTRUCT(BlueprintType)
struct FStorySequence
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 DialogueId;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<ULevelSequence> Sequence;
};

USTRUCT(BlueprintType)
struct FCharacterIntroductionInfo
{
	GENERATED_USTRUCT_BODY()

	FCharacterIntroductionInfo()
		: Color(FLinearColor::Gray), Offset(FVector2D::ZeroVector)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText CharacterName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText NickName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText CastingVoice;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Color;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector2D Offset;
};

USTRUCT(BlueprintType)
struct FCharacterIntroduction
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 DialogueId;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FCharacterIntroductionInfo Info;
};

USTRUCT()
struct FCachedMergedSkeletalMesh
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	int32 ModelType;

	UPROPERTY()
	USkeletalMesh* Mesh;
};

USTRUCT()
struct FUnitModelAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FUnitModelAssetRow()
		: CameraType(0)
		, MeshScale(1.0f)
		, BoundRadius(30.f)
		, BoundHalfHeight(90.f)
		, CommonEffectIndex(0)
		, bRotatable(true)
		, bInvisibleDropBox(false)
	{}

	FUnitModelAssetRow(TSoftObjectPtr<USkeletalMesh> InSkeletalMesh, FQ6MaterialOverrideSlot& InMaterial)
		: SkeletalMesh(InSkeletalMesh)
	{
		Materials.Empty();
		Materials.Add(InMaterial);
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dialogue")
	int32 CameraType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	TSoftObjectPtr<USkeletalMesh> SkeletalMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	TArray<TSoftObjectPtr<USkeletalMesh>> SkeletalMeshParts;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	TArray<FQ6MaterialOverrideSlot> Materials;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	float MeshScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	float BoundRadius;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	float BoundHalfHeight;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	TSoftClassPtr<UAnimInstance> AnimInstanceClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Skeleton")
	TArray<FQ6ParticleSocket> ParticleSockets;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	int32 CommonEffectIndex;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	bool bRotatable;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "DropBox")
	bool bInvisibleDropBox;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FUnitModelCameraRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector DefaultOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector ZoomInOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Comment;
};

USTRUCT()
struct FSkillAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FSkillAssetRow()
	{}

	FSkillAssetRow(TSoftObjectPtr<UTexture2D> InSkillTexture)
	{
		SupportPortraitTexture = InSkillTexture;
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Ultimate Skill UI")
	FSlateBrush UltimateIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Support Skill UI")
	FSlateBrush SupportIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turn Skill UI")
	TArray<FSlateBrush> TurnSkillIcons;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turn Skill UI")
	TArray<FSlateBrush> TurnSkillStateIcons;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Support Skill UI")
	TSoftObjectPtr<UTexture2D> SupportPortraitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;

	const FSlateBrush& GetTurnSkillIcon(int32 Index) const
	{
		if (TurnSkillIcons.IsValidIndex(Index))
		{
			return TurnSkillIcons[Index];
		}

		static FSlateBrush DummyTurnSkillIcon;
		return DummyTurnSkillIcon;
	}
};

USTRUCT()
struct FNormalSkillSequenceAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FNormalSkillSequenceAssetRow()
		: SequencePlayPosition(ESequencePlayPositon::Target)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<ULevelSequence> CameraSequence;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ESequencePlayPositon SequencePlayPosition;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FUltimateSkillSequenceAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bNoSkip;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<ULevelSequence> SkillSequence;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<USoundBase> SkillBGM;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSkillPostEffectDesc SkillPostEffect;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSkillPostMoveDesc SkillPostMove;

	// UI

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> UnitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> BGTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftClassPtr<USkillAnimationWidget> WidgetAnimationClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TArray<FName> OptionalWidgetAnimationNames;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FWaveSequenceAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence")
	int32 Episode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence")
	int32 Stage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence")
	int32 Wave;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence")
	TSoftObjectPtr<ULevelSequence> IntroSequence;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence", meta=(ClampMin=0))
	float IntroFadeOutTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence")
	TSoftObjectPtr<ULevelSequence> OutroSequence;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence", meta=(ClampMin=0))
	float OutroFadeOutTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence")
	FString LevelEffect;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FResultSequenceAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sequence")
	TSoftObjectPtr<ULevelSequence> ResultSequence;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FBossSettingAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FBossSettingAssetRow() : GaugeCount(1), DecalScale(1.0f)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "HealthBar")
	int32 GaugeCount;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Decal")
	float DecalScale;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FDialogueEpisodeRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UDataTable> DialogueTable;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftClassPtr<UEpisodeTitleWidget> TitleWidgetClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText TitleText;
};

USTRUCT()
struct FDialogueStageRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<ULevelSequence> Main;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 StartId;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 EndId;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<int32> CacheModels;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FStorySequence> Stories;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FCharacterIntroduction> CharacterIntroductions;
};

USTRUCT()
struct FDialogueAnimAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FDialogueAnimAssetRow()
		: bIdleBlend(true)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UAnimSequenceBase> Animation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UAnimSequenceBase> IdleAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UAnimSequenceBase> FaceIdleAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bIdleBlend;
};

USTRUCT()
struct FDialogueBGAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftClassPtr<AActor> ActorClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FString Tod;
};

USTRUCT()
struct FDialogueVoiceAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<USoundBase> Voice;
};

USTRUCT()
struct FDialogueSoundAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<USoundBase> Sound;
};

USTRUCT()
struct FDialogueCameraAnimRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UCameraAnim> CameraAnim;
};

USTRUCT()
struct FDialogueCameraEffectRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EDialogueCameraEffect Type;

	// for PostProcess

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor Tint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Saturation;

	// for Widget Animation

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName WidgetAnim;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName RestoreWidgetAnim;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 NumLoopsToPlay;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float AnimationSpeed;

	// for CameraShake

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSubclassOf<class UCameraShake> CameraShake;

	// for Emitter

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UParticleSystem> Particle;

	// for Blendable

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UMaterialInstance> Blendable;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor BaseColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FLinearColor SecondColor;
};

USTRUCT()
struct FEpisodeAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FEpisodeAssetRow(): Part(0) {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	int32 Part;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FSlateBrush PreviewIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FSlateBrush EpisodeIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FSlateBrush Background;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FSlateBrush Character;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FText Title;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FText Desc;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FSlateBrush CharacterIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FText CharacterName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Episode")
	FText CharacterStory;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FBagItemAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()
	FBagItemAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "BagItem")
	TSoftObjectPtr<UTexture2D> ItemTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FEquipAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FEquipAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> IconTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> IllustTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText Illustrator;
};

USTRUCT()
struct FSculptureAssetRow : public FEquipAssetRow
{
	GENERATED_USTRUCT_BODY()

	FSculptureAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftClassPtr<USkillAnimationWidget> UltimateWidgetClass;
};

USTRUCT()
struct FCheckInAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FCheckInAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftClassPtr<UCheckInBaseWidget> BoardWidgetClass;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> CharacterTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> BGTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> LogoTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText RotationRewardComment;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText AnniversaryRewardComment;
};

USTRUCT(BlueprintType)
struct FVoiceInfo
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Voice")
	int32 VoiceId;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Voice")
	TSoftObjectPtr<USoundBase> Sound;
};

USTRUCT(BlueprintType)
struct FCharacterVoiceInfo
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ECharacterVoiceCategory Category;
	
	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FVoiceInfo> VoiceInfos;
};

USTRUCT()
struct FCharacterVoiceAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FCharacterVoiceAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FCharacterVoiceInfo> CharacterVoiceInfos;
};

USTRUCT(BlueprintType)
struct FAnimationInfo
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	FText Title;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> AnimSequence;
};

USTRUCT(BlueprintType)
struct FLobbyAnimationInfo
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	FAnimationInfo WelcomeAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	TArray<FAnimationInfo> IdleAnimations;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	TArray<FAnimationInfo> InteractionAnimations;
};

USTRUCT()
struct FCharacterAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FCharacterAssetRow()
		: FaceFocusingOffset(FVector(0.f, 0.f, 150.f))
		, BodyFocusingOffset(FVector(0.f, 0.f, 120.f))
		, ZoomDistanceMin(100.f)
		, ZoomDistanceMax(200.f)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FText Comment;

	// Lobby

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> BodyTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
	FLobbyAnimationInfo LobbyAnimationInfo;

	// Combat

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	TSoftObjectPtr<UTexture2D> CombatPortraitTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	TSoftObjectPtr<UTexture2D> CombatIconTexture;

	// Details

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText CharacterDesigner;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText CastingVoice;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText CastingActor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	FVector FaceFocusingOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	FVector BodyFocusingOffset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	float ZoomDistanceMin;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Camera")
	float ZoomDistanceMax;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TArray<TSoftObjectPtr<UTexture2D>> IconTextures;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TArray<TSoftObjectPtr<UTexture2D>> LongIconTextures;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TArray<TSoftObjectPtr<UTexture2D>> IllustBGTextures;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TArray<FText> Illustrators;

	const TSoftObjectPtr<UTexture2D>& GetDefaultIconTexture() const
	{
		return GetIconTexture(0);
	}

	const TSoftObjectPtr<UTexture2D>& GetIconTexture(int32 Illust) const
	{
		if (IconTextures.IsValidIndex(Illust))
		{
			return IconTextures[Illust];
		}

		static TSoftObjectPtr<UTexture2D> DummyIconTexture;
		return DummyIconTexture;
	}

	const TSoftObjectPtr<UTexture2D>& GetDefaultLongIconTexture() const
	{
		return GetLongIconTexture(0);
	}

	const TSoftObjectPtr<UTexture2D>& GetLongIconTexture(int32 Illust) const
	{
		if (LongIconTextures.IsValidIndex(Illust))
		{
			return LongIconTextures[Illust];
		}

		static TSoftObjectPtr<UTexture2D> DummyLongIconTexture;
		return DummyLongIconTexture;
	}

	const TSoftObjectPtr<UTexture2D>& GetDefaultIllustBGTexture() const
	{
		return GetIllustBGTexture(0);
	}

	const TSoftObjectPtr<UTexture2D>& GetFinalArtTexture() const
	{
		return GetIllustBGTexture(1);
	}

	const TSoftObjectPtr<UTexture2D>& GetIllustBGTexture(int32 Illust) const
	{
		if (IllustBGTextures.IsValidIndex(Illust))
		{
			return IllustBGTextures[Illust];
		}

		static TSoftObjectPtr<UTexture2D> DummyIllustBGTexture;
		return DummyIllustBGTexture;
	}

	const FText& GetDefaultIllustrator() const
	{
		return GetIllustrator(0);
	}

	const FText& GetIllustrator(int32 Illust) const
	{
		if (Illustrators.IsValidIndex(Illust))
		{
			return Illustrators[Illust];
		}

		return FText::GetEmpty();
	}
};

USTRUCT(BlueprintType)
struct FLobbyExclusiveCharacterInfo
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	int32 ExclusiveCharacterType;

	UPROPERTY(EditAnywhere)
	FLobbyAnimationInfo ExclusiveAnimationInfo;
};

USTRUCT(BlueprintType)
struct FLobbyTemplateCharacterSlotInfo
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere)
	TArray<FLobbyExclusiveCharacterInfo> ExclusiveInfos;
};

USTRUCT()
struct FLobbyTemplateAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FLobbyTemplateAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftClassPtr<ALobbyTemplate> Template;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UTexture2D> TemplateIconTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<UTexture2D> IconTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bSwipeable;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FLobbyTemplateCharacterSlotInfo> SlotInfos;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FSummonAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FSummonAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> BGTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText Description;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FText ConsumeDescription;
};

USTRUCT()
struct FDailyDungeonAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FDailyDungeonAssetRow(): DayColor(FLinearColor(EForceInit::ForceInit)) {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Title")
	FText Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Title")
	FText Description;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explanation")
	FText CharacterName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Explanation")
	FText Explanation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> BGTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	FLinearColor DayColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> PromoteTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> XpTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> GoldTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> IllustTexture;
};

USTRUCT()
struct FVacationSpotAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FVacationSpotAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> IconTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> IllustTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Dialogue")
	FString BGMesh;
};

USTRUCT()
struct FPetAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FPetAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pet")
	TSoftObjectPtr<UTexture2D> IconTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pet")
	TSoftObjectPtr<UTexture2D> IllustTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pet")
	int32 ModelType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Pet")
	FTransform MeshTransform;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Turn Skill UI")
	TArray<FSlateBrush> SkillIcons;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	TArray<FSlateBrush> SkillStateIcons;
};

USTRUCT()
struct FRaidAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FRaidAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> BGTexture;
};

USTRUCT()
struct FAvatarFrameAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FAvatarFrameAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> FrameTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> IconTexture;
};

USTRUCT()
struct FAvatarEffectAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FAvatarEffectAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UMaterialInterface> EffectMaterial;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
	TSoftObjectPtr<UTexture2D> IconTexture;
};

/**
 * Game Resource
 */
UCLASS(Blueprintable)
class Q6_API UGameResource : public UObject
{
	GENERATED_BODY()

public:
	UGameResource(const FObjectInitializer& ObjectInitializer);

	virtual void PostLoad() override;

	virtual UWorld* GetWorld() const override;

	void BeginUIClassAsyncLoading();
	void WaitUIClassAsyncLoadingComplete(float Timeout = 0.0f);

	const FUnitModelAssetRow& GetUnitModelAssetRow(FCharacterType CharacterType) const;
	const FUnitModelAssetRow& GetUnitModelAssetRow(int32 ModelType) const;
	const FUnitModelAssetRow* GetUnitModelAssetRowPtr(int32 ModelType) const;
	const FUnitModelCameraRow* GetUnitModelCameraRowPtr(int32 ModelType) const;
	const FSkillAssetRow& GetSkillAssetRow(int32 ModelType) const;
	const FNormalSkillSequenceAssetRow& GetNormalSkillSequenceAssetRow(int32 ModelType, ESkillNote SkillNote, bool bInAddMissingLog = true) const;
	const FNormalSkillSequenceAssetRow& GetDoubleSkillSequenceAssetRow(int32 ModelType, bool bInAddMissingLog = true) const;
	const FUltimateSkillSequenceAssetRow& GetModelUltimateSkillSequenceAssetRow(int32 ModelType, bool bInAddMissingLog = true) const;
	const FUltimateSkillSequenceAssetRow& GetSkillUltimateSkillSequenceAssetRow(int32 SkillType, bool bInAddMissingLog = true) const;
	const FWaveSequenceAssetRow& GetWaveSequenceAssetRow(int32 Episode, int32 Stage, int32 Wave) const;
	void GetWaveSequencesOfStage(int32 Episode, int32 Stage, TArray<FSoftObjectPath>& OutSeqPaths) const;
	const FResultSequenceAssetRow& GetResultSequenceAssetRow(int32 ModelType) const;
	const FBossSettingAssetRow& GetBossSettingAssetRow(int32 UnitType) const;
	const FEpisodeAssetRow& GetEpisodeAssetRow(int32 Episode) const;
	const FBagItemAssetRow& GetBagItemAssetRow(FBagItemType ItemType) const;
	const FSculptureAssetRow& GetSculptureAssetRow(FSculptureType SculptureType) const;
	const FEquipAssetRow& GetRelicAssetRow(FRelicType RelicType) const;
	const FSummonAssetRow& GetSummonAssetRow(int32 EventId) const;
	const FDailyDungeonAssetRow& GetDailyDungeonAssetRow(EDayOfWeekType DayType) const;
	const FVacationSpotAssetRow& GetVacationSpotAssetRow(FVacationSpotType SpotType) const;
	const FPetAssetRow& GetPetAssetRow(FPetType PetType) const;
	const FRaidAssetRow& GetRaidAssetRow(FSagaType SagaType) const;
	const FCharacterAssetRow& GetCharacterAssetRow(FCharacterType CharacterType) const;
	const FCharacterAssetRow& GetCharacterAssetRow(int32 ModelType) const;
	const FTodAssetRow* GetTodAssetRow(FString TodPreset) const;
	const FCheckInAssetRow& GetCheckInAssetRow(FCheckInBoardType BoardType) const;
	const FLobbyTemplateAssetRow& GetLobbyTemplateAssetRow(FLobbyTemplateType TemplateType) const;
	const FDropBoxTable& GetDropBoxTableAssetRow(int32 DropBoxSet) const;
	void GetDropBoxAssetsPath(int32 DropBoxSet, EDropBoxType DropBoxType, FSoftObjectPath& OutSkeletalMeshPath, FSoftObjectPath& OutAnimationPath);
	const FTutorialDialogueAssetRow& GetTutorialDialogueAssetRow(int32 TutorialDialogueType) const;
	const FTutorialGuideAssetRow& GetTutorialGuideAssetRow(FString GuideKey) const;
	const FGuideDialogueAssetRow* GetGuideDialogueAssetRow(int32 GuideDialogueType) const;
	const FGuideActionAssetRow* GetGuideActionAssetRow(int32 GuideActionType) const;
	const FAkaAssetRow* GetAkaAssetRowByPoint(const int32 Point) const;
	const FAkaAssetRow* GetAkaAssetRowByPoint(const int32 BefoPoint, const int32 CurrPoint) const;
	const FAkaAssetRow* GetAkaAssetRowByIndex(int32 Index) const;
	const TArray<EWonderCategory> GetSpecialWonderStageLineup() const;
	const FAlchemyLabAssetRow* GetAlchemyLabAssetRowByLevel(const int32 Level) const;
	const FCaptureAssetRow& GetCaptureAssetRow(int32 CapturePresetType) const;
	const FEventListAssetRow* GetEventListAssetRow(int32 InEventType) const;
	const FEventContentCategoryAssetRow* GetEventContentCategoryAssetRow(EEventContentCategory InEventContentCategory) const;
	const FAvatarFrameAssetRow* GetAvatarFrameAssetRow(FAvatarFrameType InFrameType) const;
	const FAvatarEffectAssetRow* GetAvatarEffectAssetRow(FAvatarEffectType InEffectType) const;
	const FLevelEffectAssetRow* GetLevelEffectAssetRow(int32 Episode, int32 Stage, int32 Wave) const;
	void GetLevelEffectSequencesOfStage(int32 Episode, int32 Stage, TArray<FSoftObjectPath>& OutSeqPaths) const;
	void GetBoneDragonOutroSequence(FSagaType SagaType, TArray<FSoftObjectPath>& OutSeqPaths) const;

	UFileMediaSource* GetMovieFileMediaSource(int32 Episode, int32 Stage, int32 SubStage) const;

	const UDataTable* GetLobbyTemplateAssetTable() const { return LobbyTemplateAssetTable; }

	UUIResource& GetUIResource() const { check(UIResource); return *UIResource; }
	USoundResource& GetSoundResource() const { check(SoundResource); return *SoundResource; }
	UUIClassResource& GetUIClassResource() const { check(UIClassResource); return *UIClassResource;	}
	TSubclassOf<UCombatGameResource> GetCombatGameResourceClass() const { return CombatGameResourceClass; }
	AQ6Capture2D* SpawnOrGetTutorialDialogueCapture(UWorld* World) const;
	bool PlayMovie(UFileMediaSource* FileMeidaSource, FSimpleDelegate InFinishedCallback);

	void SetSkeletalMeshOverrideMaterials(USkeletalMeshComponent* Mesh, const FUnitModelAssetRow& Row);
	FText GetRandomLoadingScreenGameTipText() const;

	UGameAssetCacheManager* GetCacheManager() const { return CacheManager; }

	UPROPERTY(EditDefaultsOnly, Category = "Dummy Assets")
	TSoftObjectPtr<UTexture2D> DummyTexture;

	UPROPERTY(EditDefaultsOnly, Category = "Dummy Assets")
	TSoftObjectPtr<USkeletalMesh> DummySkeletalMesh;

	UPROPERTY(EditDefaultsOnly, Category = "Material")
	TSoftObjectPtr<UMaterialInterface> BlackMaterial;

	UPROPERTY(EditDefaultsOnly, Category = "Loading Assets")
	USkeletalMesh* UnitLoadingMesh;

	UPROPERTY(EditDefaultsOnly, Category = "Loading Assets")
	UAnimSequenceBase* UnitLoadingAnimation;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	TSoftObjectPtr<ULevelSequence> BoneDragonOutroSequence;

	FStreamableManager Streamable;

	const static uint32 AsyncLoadPriorityForUITexture = 256;

	USkeletalMesh* FindCachedSkeletalMesh(int32 InModelType);
	void AddCachedSkeletalMesh(int32 InModelType, USkeletalMesh* InSkeletalMesh);

private:
	const FBagItemAssetRow& FindBagItemAssetRow(const UDataTable* DataTable, FBagItemType BagItemType) const;
	const FEquipAssetRow* FindEquipAssetRow(const UDataTable* DataTable, int32 ItemType) const;

	UPROPERTY(EditDefaultsOnly, Category = "Unit")
	UDataTable* UnitModelAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	UDataTable* SkillAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	UDataTable* NormalSkillSequenceAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	UDataTable* ModelUltimateSkillSequenceAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	UDataTable* SkillUltimateSkillSequenceAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	UDataTable* WaveSequenceAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	UDataTable* ResultSequenceAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Boss")
	UDataTable* BossSettingAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Episode")
	UDataTable* EpisodeSettingAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* BagItemAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* SculptureAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Item")
	UDataTable* RelicAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Dialogue")
	UDataTable* UnitModelCameraTable;

	UPROPERTY(EditDefaultsOnly, Category = "Lobby")
	UDataTable* LobbyTemplateAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Summon")
	UDataTable* SummonAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "DailyDungeon")
	UDataTable* DailyDungeonAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Vacation")
	UDataTable* VacationSpotAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Pet")
	UDataTable* PetAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Raid")
	UDataTable* RaidAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Character")
	UDataTable* CharacterAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Tod")
	UDataTable* TodAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "CheckIn")
	UDataTable* CheckInAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "DropBox")
	UDataTable* DropBoxAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Tutorial")
	UDataTable* TutorialDialogueAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Tutorial")
	UDataTable* TutorialGuideAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Guide")
	UDataTable* GuideDialogueAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Guide")
	UDataTable* GuideActionAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Aka")
	UDataTable* AkaAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "SpecialWonderStageLineup")
	UDataTable* SpecialWonderStageLineupAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "AlchemyLab")
	UDataTable* AlchemyLabAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Capture")
	UDataTable* CaptureAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Event")
	UDataTable* EventListAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Event")
	UDataTable* EventContentCategoryAssetTable;

	UPROPERTY(EditDefaultsOnly, Category = "Movie")
	UDataTable* MovieFileMediaSourceTable;

	UPROPERTY(EditDefaultsOnly, Category = "Avatar")
	UDataTable* AvatarFrameTable;

	UPROPERTY(EditDefaultsOnly, Category = "Avatar")
	UDataTable* AvatarEffectTable;

	UPROPERTY(EditDefaultsOnly, Category = "LevelEffect")
	UDataTable* LevelEffectTable;

	UPROPERTY(EditDefaultsOnly, Category = "Movie")
	TSoftClassPtr<AQ6MediaPlayer> MediaPlayerClass;

	UPROPERTY(EditDefaultsOnly, Category = "UI Resource")
	TSubclassOf<UUIResource> UIResourceClass;

	UPROPERTY(EditDefaultsOnly, Category = "UI Class Resource")
	TSubclassOf<UUIClassResource> UUIClassResourceClass;

	UPROPERTY(EditDefaultsOnly, Category = "Sound Resource")
	TSubclassOf<USoundResource> SoundResourceClass;

	UPROPERTY(EditDefaultsOnly, Category = "Combat Resource")
	TSubclassOf<UCombatGameResource> CombatGameResourceClass;

	UPROPERTY(EditDefaultsOnly, Category = "Tutorial")
	TSoftClassPtr<AQ6Capture2D> TutorialCaptureClass;

	UPROPERTY(Transient)
	UUIResource* UIResource;

	UPROPERTY(Transient)
	UUIClassResource* UIClassResource;

	UPROPERTY(Transient)
	USoundResource* SoundResource;

	UPROPERTY(Transient)
	UGameAssetCacheManager* CacheManager;

	UPROPERTY(Transient)
	TMap<int32, USkeletalMesh*> CachedMergedSkeletalMeshes;

	TSharedPtr<FStreamableHandle> UIClassStreamingHandle;
};

USTRUCT(BlueprintType)
struct FNatureRelation
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	FText RelationText;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush RelationImage;
};

USTRUCT(BlueprintType)
struct FItemGrade
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush TextBrush;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush FrameBrush;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor Color;
};

USTRUCT(BlueprintType)
struct FSummonCardFrame
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush N;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush R;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SR;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SSR;
};

USTRUCT(BlueprintType)
struct FSummonInfoGrade
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush N;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush R;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SR;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SSR;
};

USTRUCT(BlueprintType)
struct FSummonInfoGradeBg
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush N;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush R;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SR;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SSR;
};

USTRUCT(BlueprintType)
struct FSummonGradeChance
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly, meta = (ClampMin = "0", ClampMax = "100", UIMin = "0", UIMax = "100"))
	int32 N;

	UPROPERTY(EditDefaultsOnly, meta=(ClampMin="0", ClampMax="100", UIMin="0", UIMax="100"))
	int32 R;

	UPROPERTY(EditDefaultsOnly, meta=(ClampMin="0", ClampMax="100", UIMin="0", UIMax="100"))
	int32 SR;

	UPROPERTY(EditDefaultsOnly, meta=(ClampMin="0", ClampMax="100", UIMin="0", UIMax="100"))
	int32 SSR;

	int32 GetTotalChance() const { return N + R + SR + SSR; }
};

USTRUCT()
struct FSummonChanceRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSummonGradeChance N;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSummonGradeChance R;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSummonGradeChance SR;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSummonGradeChance SSR;
};

USTRUCT(BlueprintType)
struct FArtifactIcon
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	FSlateBrush MiniBrush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	FSlateBrush CombatBrush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Upgrade")
	FSlateBrush Brush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Upgrade")
	FSlateBrush BGBrush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Combat")
	TSoftObjectPtr<UTexture2D> AnimationTexture;
};

USTRUCT(BlueprintType)
struct FItemIcon
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Item")
	FSlateBrush SmallBrush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Item")
	FSlateBrush BigBrush;
};

USTRUCT(BlueprintType)
struct FPointIcon : public FItemIcon
{
	GENERATED_USTRUCT_BODY()
};

UENUM(BlueprintType)
enum class ESummonCategory : uint8
{
	Character = 0,
	Sculpture = 1,
	Relic = 2,
};

UENUM(BlueprintType)
enum class ESummonSequenceGrade : uint8
{
	N = 0,
	R = 1,
	SR = 2,
	SSR = 3,
};

UENUM(BlueprintType)
enum class ESummonForceGrade : uint8
{
	None = 0,
	N = 1,
	R = 2,
	SR = 3,
	SSR = 4,
};

USTRUCT()
struct FSummonSequenceRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Branch;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ESummonSequenceGrade Grade;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ESummonCategory Category;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Chance;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ESummonForceGrade ForceGrade;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<ULevelSequence> Sequence;
};

USTRUCT()
struct FSummonCharacterRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TSoftObjectPtr<ULevelSequence> Sequence;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FVector Offset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText Desc;
};

USTRUCT(BlueprintType)
struct FSortingGroup
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	TArray<ESortOrderType> OrderTypes;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	ESortFilterType FilterType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	bool bXpCardFilter;
};

USTRUCT(BlueprintType)
struct FSortingOption
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	ESortMenu SortMenu;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	ESortCategory Category;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	ESortOrderType OrderType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	ESortDirection Direction;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	TArray<int32> FilterOptions;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Sort")
	bool bXpCardFilter;

	bool IsAttributeOrderType() const
	{
		return ((OrderType == ESortOrderType::Atk) || (OrderType == ESortOrderType::Def) || (OrderType == ESortOrderType::Hp));
	}
};

USTRUCT(BlueprintType)
struct FMascotAsset
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mascot")
	FSlateBrush Brush;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Mascot")
	FText Speak;
};

/**
* UI Resource
*/
UCLASS(Blueprintable)
class Q6_API UUIResource : public UObject
{
	GENERATED_BODY()

public:
	UUIResource(const FObjectInitializer& ObjectInitializer);

	UFUNCTION(BlueprintCallable)
	void SetNatureTypeIcon(UImage* Image, ENatureType NatureType, bool bHasIcon);

	const FSlateBrush& GetDummyIcon() const { return DummyIconImage; }
	const FSlateBrush& GetJokerSlotIcon(EJokerSlotType JokerSlot) const;
	const FSlateBrush& GetNatureTypeIcon(ENatureType NatureType) const;
	const FSlateBrush& GetNatureTypeBlankIcon(ENatureType NatureType) const;
	const FSlateBrush& GetStageTypeBrush(EStageType StageType) const;
	const FNatureRelation& GetNatureRelation(ENatureRelationType Type) const;
	const FItemGrade& GetItemGrade(EItemGrade Grade) const;
	const FSlateBrush& GetSummonCardFrame(EItemGrade Grade) const;
	const FSlateBrush& GetSummonInfoGrade(EItemGrade Grade) const;
	const FSlateBrush& GetSummonInfoGradeBg(EItemGrade Grade) const;
	const FPointIcon& GetPointIcon(EPointType PointType) const;
	const FPointIcon& GetPointIcon(ECurrencyType CurrencyType) const;
	const FSlateBrush& GetLootCategoryIcon(ELootCategory LootCategory) const;
	const FLinearColor& GetNormalColor() { return NormalColor; };
	const FLinearColor& GetLackColor() { return LackColor; };
	const FLinearColor& GetEnoughColor() { return EnoughColor; };
	const FSlateBrush& GetMoonIcon(int32 Moon) const;
	const FSlateBrush& GetTierIcon(int32 Tier) const;
	const FSlateBrush& GetSortDirectionIcon(ESortDirection SortDirection) const;
	const FSlateBrush& GetWonderBG(EWonderCategory Category) const;
	const FSlateBrush& GetWonderIcon(EWonderCategory Category) const;
	const FArtifactIcon& GetArtifactIcon(int32 ArtifactIndex) const;
	const TSoftObjectPtr<UTexture2D>& GetGemRebirthTexture() const;
	const FSlateBrush& GetRaidEmoticon(int32 EmoticonIndex) const;
	const FSlateBrush& GetSpecialStageIcon(ESpecialCategory SpecialCategory) const;
	const FSlateBrush& GetInitialRewardSpecialTag(EInitialRewardSpecialTagType SpecialCategory) const;
	const FSlateBrush& GetShopBG(EShopMenu InShopMenu) const;
	const FSlateBrush& GetMissionToastIcon(EMissionToastIconType MissionToastType) const;
	const FItemIcon& GetMenuOpenIcon() const { return MenuOpenIconBrush; }
	const FSlateBrush& GetVacationBigIcon() const { return VacationBigIconBrush; }
	const int32 GetRaidEmoticonImagesNum() const { return RaidEmoticonImages.Num(); }
	const TArray<FSlateBrush>& GetSortingFilterIcons(ESortFilterType FilterType) const;
	const FSlateBrush& GetGemAmountIcon(EGemAmount InGemAmount) const;
	const FSlateBrush& GetFriendBookFeedIcon(EFriendBookFeedCategory InCategory) const;

	FLinearColor GetEpisodePartColor(int32 Part) const;

	const TArray<FText>& GetUpgradeCharacterNames() const { return UpgradeCharacterNames; }
	const TArray<FText>& GetUpgradeEquipmentNames() const { return UpgradeEquipmentNames; }
	const TArray<FText>& GetUpgradeSkillNames() const { return UpgradeSkillNames; }
	const FText& GetUpgradeCharacterName(EUpgradeCharacterCategory Category) const;
	const FText& GetUpgradeEquipmentName(EUpgradeEquipCategory Category) const;
	const FText& GetUpgradeSkillName(EUpgradeSkillCategory Category) const;

	const TArray<FText>& GetUpgradeCharacterTitles() const { return UpgradeCharacterTitles; }
	const TArray<FText>& GetUpgradeSkillTitles() const { return UpgradeSkillTitles; }
	const TArray<FText>& GetUpgradeSculptureTitles() const { return UpgradeSculptureTitles; }
	const TArray<FText>& GetUpgradeRelicTitles() const { return UpgradeRelicTitles; }

	void SetButtonStyle(UButton* InButton, bool bInEnabled) const;

	const FSortingGroup& GetSortingGroup(ESortCategory Category) const;
	const TArray<FSortingOption>& GetDefaultSortingSelectedOptions() const { return DefaultSortingSelectedOptions; }
	const FSortingOption& GetDefaultSortingSelectedOption(ESortMenu SortMenu, ESortCategory Category) const;

	const FSlateBrush& GetNewMarkBrush(ENewMarkType NewMarkType) const;
	const FSlateBrush* GetRaidUserRankTrophy(const int32 Index) const;
	const FSlateBrush* GetEventUserRankTrophy(const int32 Index) const;

	const FSlateBrush& GetReplayStoryBanner(EStoryMenuCategory Category) const;
	const FSlateBrush& GetReplayStoryBG(EStoryMenuCategory Category) const;

	const TArray<FMascotAsset>& GetMascotAssets() const { return MascotAssets; }

	UPROPERTY(EditDefaultsOnly, Category = "Level Loading Screen")
	TArray<FText> LoadingScreenTipTexts;

	UPROPERTY(EditDefaultsOnly, Category = "Level Loading Screen")
	TSoftClassPtr<ULoadingScreenWidget> LoadingScreenUMGWidget;

private:
	// Localization
	UPROPERTY(EditDefaultsOnly, Category = "Localization")
	TArray<UStringTable*> UIStringTables;

	UPROPERTY(EditDefaultsOnly, Category = "Upgrade")
	TArray<FText> UpgradeCharacterNames;

	UPROPERTY(EditDefaultsOnly, Category = "Upgrade")
	TArray<FText> UpgradeEquipmentNames;

	UPROPERTY(EditDefaultsOnly, Category = "Upgrade")
	TArray<FText> UpgradeSkillNames;

	// UpgradeTitle

	UPROPERTY(EditDefaultsOnly, Category = "UpgradeTitle")
	TArray<FText> UpgradeCharacterTitles;

	UPROPERTY(EditDefaultsOnly, Category = "UpgradeTitle")
	TArray<FText> UpgradeSkillTitles;

	UPROPERTY(EditDefaultsOnly, Category = "UpgradeTitle")
	TArray<FText> UpgradeSculptureTitles;

	UPROPERTY(EditDefaultsOnly, Category = "UpgradeTitle")
	TArray<FText> UpgradeRelicTitles;

	// Resources

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> NatureTypeImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> NatureTypeBlankImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> JokerSlotImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> StageTypeImages;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush DummyIconImage;

	UPROPERTY(EditDefaultsOnly)
	FSummonCardFrame SummonCardFrame;

	UPROPERTY(EditDefaultsOnly)
	FSummonInfoGrade SummonInfoGrade;

	UPROPERTY(EditDefaultsOnly)
	FSummonInfoGradeBg SummonInfoGradeBg;

	UPROPERTY(EditDefaultsOnly)
	TArray<FNatureRelation> NatureRelations;

	UPROPERTY(EditDefaultsOnly)
	TArray<FItemGrade> ItemGrades;

	UPROPERTY(EditDefaultsOnly)
	TArray<FPointIcon> PointIcons;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> BatteryImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> MoonImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> TierImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> SortDirectionImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> WonderBGBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> WonderIconBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> BondRewardImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> RaidEmoticonImages;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> SpecialStageIconBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> InitialRewardSpecialTagBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> ShopBGBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> GemAmountBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> FriendBookFeedBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> MissionToastIconBrushes;

	UPROPERTY(EditDefaultsOnly)
	FItemIcon MenuOpenIconBrush;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush VacationBigIconBrush;

	UPROPERTY(EditDefaultsOnly)
	TArray<FArtifactIcon> ArtifactIcons;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> GemRebirthTexture;

	UPROPERTY(EditDefaultsOnly)
	TArray<FLinearColor> EpisodePartColors;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor NormalColor;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor LackColor;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor EnoughColor;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> NewMarkBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> RaidUserRankTrophies;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> EventUserRankTrophies;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SpecialCommonIconBrush;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush CharUnlockElemIconBrush;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> ReplayStoryBanners;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> ReplayStoryBGs;

	// Styles

	UPROPERTY(EditDefaultsOnly)
	USlateWidgetStyleAsset* EnabledButtonStyle;

	UPROPERTY(EditDefaultsOnly)
	USlateWidgetStyleAsset* DisabledButtonStyle;

	// Sorting

	UPROPERTY(EditDefaultsOnly)
	TArray<FSortingGroup> SortingGroups;	// Order by ESortCategory

	UPROPERTY(EditDefaultsOnly)
	TArray<FSortingOption> DefaultSortingSelectedOptions;

	// WithdrawPopup

	UPROPERTY(EditDefaultsOnly, Category = "WithdrawPopup")
	TArray<FMascotAsset> MascotAssets;
};


/**
* Sound Resource
*/
USTRUCT()
struct FBGMAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "BGM")
	TSoftObjectPtr<USoundBase> Sound;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

/**
* Tod Resource
*/
USTRUCT()
struct FTodAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TOD")
	float Intensity;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TOD")
	FColor LightColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TOD")
	FLinearColor CharacterColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TOD")
	FColor AmbientColor;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TOD")
	FLinearColor LightBGTint;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "TOD")
	int32 TodBranchIndex = -1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT(BlueprintType)
struct FLevelEffectMaterialSlot
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	TSoftObjectPtr<UMaterialInterface> Material;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Branch)
	FName ComponentTag;
};

USTRUCT()
struct FLevelEffectAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level Effect")
	TSoftObjectPtr<ULevelSequence> LevelEffectSequence;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level Effect")
	int32 Episode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level Effect")
	int32 Stage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level Effect")
	TArray<FLevelEffectMaterialSlot> SubMaterials;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Level Effect")
	TArray<FLevelEffectMaterialSlot> DissolveMaterials;
};

UCLASS(Blueprintable)
class Q6_API USoundResource : public UObject
{
	GENERATED_BODY()

public:
	USoundBase* GetBGM(const FName& Name) const;
	USoundConcurrency* GetBGMConcurrency() const { return BGMConcurrency; }

	const FCharacterVoiceAssetRow* GetCharacterVoiceAssetRow(FCharacterType CharacterType) const;

	USoundBase* GetDialogueVoice(EDialogueType DialogueType, const FName& Name) const;
	USoundBase* GetDialogueSound(int32 SoundType) const;

	USoundClass* GetBGMSoundClass() const { return BGMSoundClass; }
	USoundClass* GetEffectSoundClass() const { return EffectSoundClass; }
	USoundClass* GetVoiceSoundClass() const { return VoiceSoundClass; }
	USoundClass* GetUISoundClass() const { return UISoundClass; }

private:
	UPROPERTY(EditDefaultsOnly, Category = "BGM")
	USoundConcurrency* BGMConcurrency;

	UPROPERTY(EditDefaultsOnly, Category = "BGM")
	UDataTable* BGMTable;

	UPROPERTY(EditDefaultsOnly, Category = "Character")
	UDataTable* CharacterVoiceTable;

	UPROPERTY(EditDefaultsOnly, Category = "Dialogue")
	UDataTable* SagaVoiceTable;

	UPROPERTY(EditDefaultsOnly, Category = "Dialogue")
	UDataTable* DailyVoiceTable;

	UPROPERTY(EditDefaultsOnly, Category = "Dialogue")
	UDataTable* TrainingVoiceTable;

	UPROPERTY(EditDefaultsOnly, Category = "Dialogue")
	UDataTable* DialogueSoundTable;

	UPROPERTY(EditDefaultsOnly, Category = "Sound Class")
	USoundClass* BGMSoundClass;

	UPROPERTY(EditDefaultsOnly, Category = "Sound Class")
	USoundClass* EffectSoundClass;

	UPROPERTY(EditDefaultsOnly, Category = "Sound Class")
	USoundClass* VoiceSoundClass;

	UPROPERTY(EditDefaultsOnly, Category = "Sound Class")
	USoundClass* UISoundClass;
};

USTRUCT()
struct FDropBoxTable : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SSRBox")
	FSlateBrush SSRBoxIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SSRBox")
	TSoftObjectPtr<USkeletalMesh> SSRBoxSkeletalMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SSRBox")
	TSoftObjectPtr<UAnimSequenceBase> SSRBoxSpawnAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SSRBox")
	float SSRBoxSpawnDelayTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SRBox")
	FSlateBrush SRBoxIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SRBox")
	TSoftObjectPtr<USkeletalMesh> SRBoxSkeletalMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SRBox")
	TSoftObjectPtr<UAnimSequenceBase> SRBoxSpawnAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SRBox")
	float SRBoxSpawnDelayTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NRBox")
	FSlateBrush NRBoxIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NRBox")
	TSoftObjectPtr<USkeletalMesh> NRBoxSkeletalMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NRBox")
	TSoftObjectPtr<UAnimSequenceBase> NRBoxSpawnAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "NRBox")
	float NRBoxSpawnDelayTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RandomSpawnBox")
	FSlateBrush RandomSpawnBoxIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RandomSpawnBox")
	TSoftObjectPtr<USkeletalMesh> RandomSpawnBoxSkeletalMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RandomSpawnBox")
	TSoftObjectPtr<UAnimSequenceBase> RandomSpawnBoxSpawnAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "RandomSpawnBox")
	float RandomSpawnBoxSpawnDelayTime;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gold")
	TSoftObjectPtr<USkeletalMesh> GoldSkeletalMesh;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gold")
	TSoftObjectPtr<UAnimSequenceBase> GoldSpawnAnimation;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Gold")
	float GoldSpawnDelayTime;
};

USTRUCT()
struct FTutorialDialogueAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FTutorialDialogueAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	FText Dialogue;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	FText Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	TSoftObjectPtr<UTexture2D> IconTexture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tutorial")
	int32 CaptureAssetType;
};

USTRUCT()
struct FGuideDialogueAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FGuideDialogueAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	FText Dialogue;
};

USTRUCT()
struct FGuideActionAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FGuideActionAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Guide")
	TSoftClassPtr<UGuideBase> BindClass;
};

USTRUCT()
struct FSpecialWonderStageLineupAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FSpecialWonderStageLineupAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "SpecialWonderStageLineup")
	EWonderCategory Category;
};

USTRUCT()
struct FAkaAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FAkaAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Aka")
	int32 Point;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Aka")
	FText BadgeName;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Aka")
	FSlateBrush Icon;
};

USTRUCT()
struct FAlchemyLabAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FAlchemyLabAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AlchemyLab")
	int32 Level;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AlchemyLab")
	FText EffectDesc1;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "AlchemyLab")
	FText EffectDesc2;
};

USTRUCT()
struct FCaptureAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FCaptureAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture")
	int32 ModelType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture")
	TSoftObjectPtr<UAnimationAsset> Motion;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Capture")
	FTransform MeshTransform;
};

USTRUCT()
struct FTutorialGuideAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FTutorialGuideAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText Title;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText Top;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSlateBrush Image;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FText Bottom;
};

USTRUCT()
struct FEventListAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FEventListAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Banner")
	FSlateBrush EventBanner;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Main")
	FSlateBrush EventBackground;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Main")
	FSlateBrush Logo;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Point")
	TArray<FSlateBrush> PointIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Point")
	TArray<FSlateBrush> PointItem;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stage")
	FSlateBrush StageBackground;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Button")
	FSlateBrush ShopImg;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Button")
	FSlateBrush StageImg;
};

USTRUCT()
struct FEventContentCategoryAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	FEventContentCategoryAssetRow() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Watt")
	FSlateBrush WattIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Watt")
	bool bUseWattIcon;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Tag")
	FString Comment;
};

USTRUCT()
struct FFileMediaSourceAssetRow : public FTableRowBase
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Movie")
	UFileMediaSource* FileMediaSource;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Movie")
	int32 Episode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Movie")
	int32 Stage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Movie")
	int32 SubStage;
};
