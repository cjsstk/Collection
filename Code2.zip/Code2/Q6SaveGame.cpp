// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6SaveGame.h"

#include "Kismet/GameplayStatics.h"
#include "Q6UIDefine.h"
#include "SystemConst_gen.h"
#include "WidgetUtil.h"

bool IsModifiedMultisideInfo(const FPartyInfo& InPartyInfo)
{
	if (!InPartyInfo.PetId.IsInvalid())
	{
		return true;
	}

	for (const FPartySlot& Iter : InPartyInfo.Main)
	{
		if (!Iter.CharacterId.IsInvalid())
		{
			return true;
		}
		if (!Iter.RelicId.IsInvalid())
		{
			return true;
		}
		if (!Iter.SculptureId.IsInvalid())
		{
			return true;
		}
	}

	for (const FPartySlot& Iter : InPartyInfo.Sub)
	{
		if (!Iter.CharacterId.IsInvalid())
		{
			return true;
		}
		if (!Iter.RelicId.IsInvalid())
		{
			return true;
		}
		if (!Iter.SculptureId.IsInvalid())
		{
			return true;
		}
	}

	return false;
}

UQ6SaveGame::UQ6SaveGame()
{
	SavedPartySlot = 1;

	for (int i = 0; i < NUM_OF_PARTY_MEMBER; ++i)
	{
		MultisidePartyInfo.Main.Add(FPartySlot());
		MultisidePartyInfo.Sub.Add(FPartySlot());
	}
}

void UQ6SaveGame::SetUserId(const FString& InUserId)
{
	UserId = InUserId;
}

bool UQ6SaveGame::IsFirstBossStage(int32 SagaType) const
{
	return (BossStages.Find(SagaType) == INDEX_NONE);
}

void UQ6SaveGame::AddUniqueBossStage(int32 SagaType)
{
	int32 NumStages = BossStages.Num();
	BossStages.AddUnique(SagaType);

	if (NumStages < BossStages.Num())
	{
		Save();
	}
}

bool UQ6SaveGame::IsFirstDailyDungeonOnToday() const
{
	return LastDailyDate.GetDate() < FDateTime::Today();
}

void UQ6SaveGame::UpdateDailyDungeonDate()
{
	LastDailyDate = FDateTime::Today();
	Save();
}

bool UQ6SaveGame::IsFirstUltimateSequenceOnToday(int32 ModelType, bool bEnemy)
{
	const FDateTime* ShownTime = nullptr;

	if (bEnemy)
	{
		ShownTime = EnemyUltimates.Find(ModelType);
	}
	else
	{
		ShownTime = AllyUltimates.Find(ModelType);
	}

	if (ShownTime)
	{
		return ShownTime->GetDate() < FDateTime::Today();
	}

	return true;
}

void UQ6SaveGame::UpdateUltimateSequenceDate(int32 ModelType, bool bEnemy)
{
	if (bEnemy)
	{
		FDateTime& DateTime = EnemyUltimates.FindOrAdd(ModelType);
		DateTime = FDateTime::Today();
	}
	else
	{
		FDateTime& DateTime = AllyUltimates.FindOrAdd(ModelType);
		DateTime = FDateTime::Today();
	}

	Save();
}

void UQ6SaveGame::ClearUltimateSequenceDates()
{
	AllyUltimates.Empty();
	EnemyUltimates.Empty();

	Save();
}

void UQ6SaveGame::UpdateDialogueRecord(const FDialogueRecord& InDialogueRecord)
{
	DialogueRecord = InDialogueRecord;
	Save();
}

void UQ6SaveGame::ClearDialogueRecord()
{
	DialogueRecord.Reset();
	Save();
}

void UQ6SaveGame::UpdateRaidId(const FRaidId& InRaidId)
{
	RaidId = InRaidId;
	Save();
}

void UQ6SaveGame::SetSavedPartySlot(int32 InSlot)
{
	SavedPartySlot = InSlot;
	Save();
}

void UQ6SaveGame::SetDialogueAutoPlay(bool bAutoPlay)
{
	bDialogueAutoPlay = bAutoPlay;
	Save();
}

void UQ6SaveGame::SetCombatSkillQuickUse(bool bQuickUse)
{
	bCombatSkillQuickUse = bQuickUse;
	Save();
}

void UQ6SaveGame::SetCombatDoubleSpeed(bool bDoubleSpeed)
{
	bCombatDoubleSpeed = bDoubleSpeed;
	Save();
}

void UQ6SaveGame::SetLatestFriendBookFeed(const FFriendBookFeedId& InLatestFeedId)
{
	LatestFriendBookFeedId = InLatestFeedId;
	Save();
}

void UQ6SaveGame::SetReadFriendBookFeeds()
{
	ReadFriendBookFeedId = LatestFriendBookFeedId;
	Save();
}

const TArray<int32>& UQ6SaveGame::GetBanIndices() const
{
	return BanIndices;
}

void UQ6SaveGame::UpdateBanIndices(const TArray<int32>& InBanIndices)
{
	BanIndices = InBanIndices;
	Save();
}

void UQ6SaveGame::SaveMultisidePartyInfo(const FPartyInfo& InPartyInfo)
{
	MultisidePartyInfo = InPartyInfo;
	Save();
}

void UQ6SaveGame::InitRewardRecord(const FRewardRecord& InRewardRecord, bool bSave)
{
	RewardRecord = InRewardRecord;

	if (bSave)
	{
		// volatile data
		Save();
	}
}

bool UQ6SaveGame::HeapPopRewardStep(FRewardStep& RewardStep)
{
	if (RewardRecord.RewardSteps.Num() > 0)
	{
		RewardStep = RewardRecord.RewardSteps[0];
		RewardRecord.RewardSteps.RemoveAt(0);

		Save();
		return true;
	}

	RewardRecord.SagaType = SagaTypeInvalid;
	return false;
}

void UQ6SaveGame::ClearBanIndices()
{
	BanIndices.Empty();
	Save();
}

void UQ6SaveGame::SaveMultisidePartyPet(FPetId InPetId)
{
	MultisidePartyInfo.PetId = InPetId;
	Save();
}

void UQ6SaveGame::ResetMultisidePartyInfo()
{
	if (!IsModifiedMultisideInfo(MultisidePartyInfo))
	{
		return;
	}

	MultisidePartyInfo = FPartyInfo();
	Save();
	
}

void UQ6SaveGame::Save()
{
	UGameplayStatics::SaveGameToSlot(this, UserId, 0);
}
