// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "GameFramework/Actor.h"
#include "Loot.generated.h"
class AUnit;
class UCurveVector;

UENUM()
enum class ELootDropType : uint8
{
	None,
	OverKillPoint,
};

USTRUCT(BlueprintType)
struct FLootDropTimeInfo
{
	GENERATED_BODY()

	FLootDropTimeInfo()
		: DroppingMoveTime(0.1f)
		, DroppedDelayTime(1.0f)
		, CollectingMoveTime(0.2f)
		, CollectingIntervalTime(0.05f)
	{}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float DroppingMoveTime;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float DroppedDelayTime;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float CollectingMoveTime;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	float CollectingIntervalTime;
};

UCLASS()
class Q6_API ALootDrop : public AActor
{
	GENERATED_BODY()
	
public:	
	ALootDrop(const FObjectInitializer& ObjectInitializer);

	FVector GetMovingLocationOffset(float TimeRate) const;

	UFUNCTION(BlueprintImplementableEvent)
	void StartDissolve(float InDelay);

	UPROPERTY(EditDefaultsOnly)
	FLootDropTimeInfo TimeInfo;

	UPROPERTY(EditDefaultsOnly)
	UCurveVector* MovingLocationOffsetCurve;
};

UCLASS()
class Q6_API ALoot : public AActor
{
	GENERATED_BODY()

public:
	ALoot(const FObjectInitializer& ObjectInitializer);
	virtual void Tick(float DeltaSeconds) override;

	void SetLootSpawnInfo(ELootDropType InType, int32 InDropCount, const FVector& InSourceLocation, const FVector& InTargetLocation);
	void CollectToUnit(AUnit* InUnit, int32 InIndex);
	void Collect();

protected:
	virtual void BeginPlay() override;

private:
	void StartMove(float InMoveTime, bool bCollecting);
	void CollectToUnitInternal();
	void CollectInternal();

protected:
	UPROPERTY(BlueprintReadOnly)
	ELootDropType Type;

	UPROPERTY(BlueprintReadOnly)
	int32 DropCount;

	UPROPERTY(BlueprintReadOnly)
	FVector TargetLocation;

	UPROPERTY(BlueprintReadOnly)
	AUnit* TargetUnit;

private:
	UPROPERTY(EditDefaultsOnly, Category = LootDrop)
	TSubclassOf<class ALootDrop> OverKillPointDropClass;

	UPROPERTY(Transient)
	TArray<ALootDrop*> LootDrops;

	UPROPERTY(Transient)
	FVector SourceLocation;

	UPROPERTY(Transient)
	FVector MoveStartLocation;

	UPROPERTY(Transient)
	FVector MoveDirection;

	UPROPERTY(Transient)
	FLootDropTimeInfo LootDropTimeInfo;

	float MoveTime;
	float MoveStartTime;
	float MoveEndTime;
	bool bMovinig;
	bool bCollecting;

	// Timer Handles
	FTimerHandle MoveTimerHandle;
	FTimerHandle DestroyTimerHandle;
};
