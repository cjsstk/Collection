// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/Texture2D.h"

#ifndef dimof
#define dimof(a) (sizeof(a) / sizeof(a[0]))
#endif

#ifdef PVS_STUDIO
#undef check
#undef checkf
#define check(expr) do { if (!(expr)) throw "PVS-Studio"; } while (0)
#define checkf(expr, ...) do { if (!(expr)) throw "PVS-Studio"; } while (0)
#endif


UENUM()
enum Q6TextureGroup
{
	TEXTUREGROUP_Q6SequencePreload = TEXTUREGROUP_MobileFlattened, // DefaultEngine.ini => TEXTUREGROUP_MobileFlattened.DisplayName=Q6 Sequence Preload
};

DECLARE_STATS_GROUP(TEXT("HStore"), STATGROUP_HSTORE, STATCAT_Advanced);
