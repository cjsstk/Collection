// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "Loot.h"
#include "CombatGameResource.h"
#include "CombatHUD.h"
#include "Curves/CurveVector.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Unit.h"

static TAutoConsoleVariable<float> CVarLootMoveNegativeZOffsetRateMin(
	TEXT("q6.LootMoveNegativeZOffsetRateMin"),
	-0.2f,
	TEXT("minimum z offset rate of loot drop move"),
	ECVF_Cheat);

ALootDrop::ALootDrop(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FVector ALootDrop::GetMovingLocationOffset(float TimeRate) const
{
	if (!MovingLocationOffsetCurve)
	{
		return FVector::ZeroVector;
	}

	return MovingLocationOffsetCurve->GetVectorValue(TimeRate);
}

ALoot::ALoot(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Type(ELootDropType::None)
	, DropCount(0)
	, TargetLocation(0.f)
	, TargetUnit(nullptr)
	, SourceLocation(0.f)
	, MoveStartLocation(0.f)
	, MoveDirection(0.f)
	, MoveTime(0.f)
	, MoveStartTime(0.f)
	, MoveEndTime(0.f)
	, bMovinig(false)
	, bCollecting(false)
{
	PrimaryActorTick.bCanEverTick = true;
}

void ALoot::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!bMovinig)
	{
		return;
	}

	if (bCollecting && TargetUnit)
	{
		TargetLocation = TargetUnit->GetSocketTransform(UnitSocket::Center).GetLocation();
	}

	const FVector CurrentLocation = GetActorTransform().GetLocation();
	if (FVector::PointsAreNear(CurrentLocation, TargetLocation, 5.f))
	{
		if (bCollecting)
		{
			CollectInternal();
			bCollecting = false;
		}

		SetActorTransform(FTransform(TargetLocation));
		MoveEndTime = GetWorld()->GetTimeSeconds();
		bMovinig = false;
		return;
	}

	const float MoveDeltaTime = GetWorld()->GetTimeSeconds() - MoveStartTime;
	const float Alpha = FMath::Min(MoveDeltaTime / MoveTime, 1.0f);

	FVector Offset = FVector::ZeroVector;
	if (LootDrops.Num())
	{
		Offset = LootDrops[0]->GetMovingLocationOffset(Alpha);
	}
	FVector Location = FMath::Lerp(MoveStartLocation, TargetLocation, Alpha) + MoveDirection * Offset;

	FTransform CurrentTargetTransform;
	CurrentTargetTransform.SetLocation(Location);

	SetActorTransform(CurrentTargetTransform);
}

void ALoot::SetLootSpawnInfo(ELootDropType InType, int32 InDropCount, const FVector& InSourceLocation, const FVector& InTargetLocation)
{
	Type = InType;
	DropCount = InDropCount;
	SourceLocation = InSourceLocation;
	TargetLocation = InTargetLocation;
}

void ALoot::StartMove(float InMoveTime, bool bInCollecting)
{
	MoveTime = InMoveTime;
	MoveStartLocation = GetActorTransform().GetLocation();
	MoveStartTime = GetWorld()->GetTimeSeconds();

	bCollecting = bInCollecting;
	if (bCollecting)
	{
		MoveDirection = MoveStartLocation - SourceLocation;
		MoveDirection.X = MoveDirection.X < 0.f ? FMath::RandRange(-1.0f, 0.0f) : FMath::RandRange(0.0f, 1.0f);
		MoveDirection.Y = MoveDirection.Y < 0.f ? FMath::RandRange(-1.0f, 0.0f) : FMath::RandRange(0.0f, 1.0f);
		MoveDirection.Z = MoveDirection.Z < 0.f ?
			FMath::RandRange(CVarLootMoveNegativeZOffsetRateMin.GetValueOnGameThread(), 0.0f) : FMath::RandRange(0.0f, 1.0f);
	}
	else
	{
		MoveDirection = FVector::ZeroVector;
	}

	bMovinig = true;
}

void ALoot::BeginPlay()
{
	Super::BeginPlay();

	TSubclassOf<ALootDrop> LootDropClass;
	switch (Type)
	{
		case ELootDropType::OverKillPoint:
			LootDropClass = OverKillPointDropClass;
			break;
		default:
			break;
	}

	if (!LootDropClass)
	{
		Q6JsonLogSunny(Warning, "ALoot::BeginPlay - Invalid LootDrop Type", Q6KV("LootDropType", (uint8)Type));
		return;
	}

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	for (int32 i = 0; i < DropCount; ++i)
	{
		ALootDrop* LootDrop = GetWorld()->SpawnActor<ALootDrop>(LootDropClass, SpawnInfo);
		LootDrop->AttachToComponent(RootComponent, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
		LootDrops.Add(LootDrop);

		if (i == 0)
		{
			LootDropTimeInfo.DroppingMoveTime = LootDrop->TimeInfo.DroppingMoveTime;
			LootDropTimeInfo.DroppedDelayTime = LootDrop->TimeInfo.DroppedDelayTime;
			LootDropTimeInfo.CollectingMoveTime = LootDrop->TimeInfo.CollectingMoveTime;
		}
	}

	StartMove(LootDropTimeInfo.DroppingMoveTime, false);
}

void ALoot::CollectToUnit(AUnit* InUnit, int32 InIndex)
{
	TargetUnit = InUnit;

	float Delay = 0.f;
	float TimeAfterMoveEnd = GetWorld()->GetTimeSeconds() - MoveEndTime;
	if (TimeAfterMoveEnd < LootDropTimeInfo.DroppedDelayTime)
	{
		Delay += LootDropTimeInfo.DroppedDelayTime - TimeAfterMoveEnd;
	}
	if (InIndex > 0)
	{
		Delay += InIndex * LootDropTimeInfo.CollectingIntervalTime;
	}

	if (Delay > 0.f)
	{
		GetWorldTimerManager().ClearTimer(MoveTimerHandle);
		GetWorldTimerManager().SetTimer(MoveTimerHandle, this, &ALoot::CollectToUnitInternal, Delay);
	}
	else
	{
		CollectToUnitInternal();
	}
}

void ALoot::CollectToUnitInternal()
{
	MoveTimerHandle.Invalidate();

	StartMove(LootDropTimeInfo.CollectingMoveTime, true);
}

void ALoot::Collect()
{
	float DissolveDelay = MoveTime * 0.8f;
	for (ALootDrop* LootDrop : LootDrops)
	{
		LootDrop->StartDissolve(DissolveDelay);
	}

	GetWorldTimerManager().ClearTimer(DestroyTimerHandle);
	GetWorldTimerManager().SetTimer(DestroyTimerHandle, this, &ALoot::CollectInternal, DissolveDelay + 2.f);
}

void ALoot::CollectInternal()
{
	DestroyTimerHandle.Invalidate();

	if (TargetUnit)
	{
		TargetUnit->StartLootEffectFX();

		if (Type == ELootDropType::OverKillPoint)
		{
			GetCheckedCombatHUD(this)->AddOverKill(TargetUnit->GetUnitId(), DropCount);
		}
	}

	for (ALootDrop* LootDrop : LootDrops)
	{
		LootDrop->Destroy();
	}
	LootDrops.Empty();

	Destroy();
}
