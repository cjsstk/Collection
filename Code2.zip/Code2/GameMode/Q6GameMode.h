// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "GameFramework/GameModeBase.h"
#include "Q6GameMode.generated.h"

UCLASS()
class Q6_API AQ6GameModeBase : public AGameModeBase
{
	GENERATED_BODY()
public:
	virtual void OnConstruction(const FTransform& Transform) override;
};


UCLASS()
class Q6_API AQ6LoginGameMode : public AQ6GameModeBase
{
	GENERATED_BODY()

public:
	virtual void StartPlay() override;
};

UCLASS()
class Q6_API AQ6LobbyGameMode : public AQ6GameModeBase
{
	GENERATED_BODY()

public:
	virtual void StartPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
};
