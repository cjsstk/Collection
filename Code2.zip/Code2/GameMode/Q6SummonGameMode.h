// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6GameMode.h"
#include "Q6GameState.h"

#include "Q6SummonGameMode.generated.h"

class ULevelSequence;
class ALevelSequenceActor;
class ULevelSequencePlayer;
class UParticleSystem;
class USummonBranch;
class UWorld;
class ASummonHUD;

struct FSummonBranchParam;
struct FSummonCharacterRow;

enum class ESummonCategory : uint8;
enum class ESummonSequenceGrade : uint8;
enum class ESummonForceGrade : uint8;

struct FSummonInfo
{
	int32 Type;
	ELootCategory Category;
	EItemGrade ItemGrade;
	ESummonSequenceGrade SummonGrade;
	int32 Level;
	int32 Star;
	FText Name;
	FText NickName;

	ENatureType NatureType;
	int32 Moon;

	int32 Tier;

	bool bFirst;

	bool IsCharacter() const;
	bool IsImportant() const;
};

UCLASS()
class Q6_API AQ6SummonGameMode : public AQ6GameModeBase
{
	GENERATED_BODY()

public:
	AQ6SummonGameMode(const FObjectInitializer& ObjectInitializer);

	virtual void StartPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	void StartShow(const FSummonResult& SummonResult);

	bool CheckTableValitation() const;

public:
	UFUNCTION(BlueprintCallable)
	void OnShowUI();

	UFUNCTION()
	void OnLoopStart();

	UFUNCTION()
	void OnSequenceEnd();

	UFUNCTION()
	void OnMoveToNext();

	UFUNCTION()
	void OnSkip();

	UFUNCTION()
	void OnBack();

	UFUNCTION()
	void OnInteraction();

	UFUNCTION()
	void OnSummonInfoEnd();

	UFUNCTION()
	void OnPostLoadMap(UWorld* World);

private:
	bool CheckChanceTable(ESummonSequenceGrade Grade, UDataTable* ChanceTable) const;
	bool CheckSequenceTable() const;

	ULevelSequence* GambleBranchSequence(int32 Branch, ESummonCategory Category, ESummonSequenceGrade Grade, ESummonForceGrade* OutForceGrade = nullptr);
	ESummonSequenceGrade GambleBranchGrade(int32 Branch, ESummonSequenceGrade TableGrade, ESummonSequenceGrade BeforeGrade);

	ULevelSequence* GetCharacterSequence(const FSummonInfo& Info);
	const FSummonCharacterRow* GetCharacterRow(const FSummonInfo& Info);

	int32 GetStartBranchIndex();
	ESummonSequenceGrade EvaluateCommonGrade();
	void GenerateSummonInfo(const FSummonResult& Result);

	void EvaluateCommonBranches();
	void EvaluateEachBranches();
	void EvaluateNoneCharacterBranches(const FSummonInfo& Info);
	void EvaluateCharacterBranches(const FSummonInfo& Info);

	bool PlayBranch(int32 Index, bool bJumpToSkip);
	void DestroyActiveBranch();

	void StartShowInternal(const FSummonResult& SummonResult, bool bSkipCommon = false);
	void ExecuteBranch(bool bJumpToSkip = false);
	void MoveNextBranch(int32 NextBranchIndex, bool bJumpToSkip = false);
	void SkipToNextImportantItemBranch();

	void SummonSignCustomizing();
	UParticleSystem* GetSignTemplate(const FSummonInfo& Info);

	void BackToLobby();
	void ShowInteractionUI();
	void ShowResultWidget();

	USummonBranch* CreateBranch(ULevelSequence* Seq1, bool bPauseAtEnd);
	USummonBranch* CreateBranch(ULevelSequence* Seq1, ULevelSequence* Seq2, ULevelSequence* Seq3, ULevelSequence* Seq4);
	USummonBranch* CreateBranch(ULevelSequence* Seq1, ULevelSequence* Seq2, int32 ModelType, bool bCustomInstance);
	USummonBranch* CreateBranch(const TArray<ULevelSequence*>& Sequences, const FSummonBranchParam& Param);
	USummonBranch* GetBranch(int32 Index);

	// for debugging

#if WITH_EDITOR
	void RegisterCheatCommands();
	void UnRegisterCheatCommands();
	void CheatShowCommand(const TArray<FString>& Args);
	void CheatShowNewCommand(const TArray<FString>& Args);
	void CheatCharCommand(const TArray<FString>& Args);
	void CheatCharNewCommand(const TArray<FString>& Args);

	void CheatShowInternal(const TArray<FString>& Args, bool bFirst);
	void CheatCharInternal(const TArray<FString>& Args, bool bFirst);

	TArray<IConsoleObject*> CheatObjects;
	bool bCheatingShow;
#endif	// WITH_EDITOR

private:
	UPROPERTY(EditDefaultsOnly, Category = "DataTable")
	UDataTable* NChanceTable;

	UPROPERTY(EditDefaultsOnly, Category = "DataTable")
	UDataTable* RChanceTable;

	UPROPERTY(EditDefaultsOnly, Category = "DataTable")
	UDataTable* SRChanceTable;

	UPROPERTY(EditDefaultsOnly, Category = "DataTable")
	UDataTable* SSRChanceTable;

	UPROPERTY(EditDefaultsOnly, Category = "DataTable")
	UDataTable* SummonSequenceTable;

	UPROPERTY(EditDefaultsOnly, Category = "DataTable")
	UDataTable* SummonCharacterTable;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	ULevelSequence* EnterSub;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	ULevelSequence* EnterLoop;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	ULevelSequence* EnterEnd;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	ULevelSequence* DefaultCharacterSR;

	UPROPERTY(EditDefaultsOnly, Category = "Sequence")
	ULevelSequence* DefaultCharacterSSR;

	UPROPERTY(EditDefaultsOnly, Category = "Sign")
	UParticleSystem* SummonSignCard;

	UPROPERTY(EditDefaultsOnly, Category = "Sign")
	UParticleSystem* SummonSignN;

	UPROPERTY(EditDefaultsOnly, Category = "Sign")
	UParticleSystem* SummonSignR;

	UPROPERTY(EditDefaultsOnly, Category = "Sign")
	UParticleSystem* SummonSignSR;

	UPROPERTY(EditDefaultsOnly, Category = "Sign")
	UParticleSystem* SummonSignSSR;

	UPROPERTY(Transient)
	TArray<USummonBranch*> Branches;

	UPROPERTY(Transient)
	USummonBranch* ActiveBranch;

	int32 BranchIndex;
	int32 ItemIndex;
	int32 EvaluatedItemIndex;

	bool bNowShowing;
	bool bSkipNotImportant;

	TArray<FSummonInfo> SummonInfos;

	TOptional<FVector> CraneOffset;
	bool bShouldStopCraneOffset;
};
