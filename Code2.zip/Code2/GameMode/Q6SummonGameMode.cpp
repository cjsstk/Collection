// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6SummonGameMode.h"

#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"
#include "Engine/StaticMeshActor.h"
#include "Animation/SkeletalMeshActor.h"
#include "Sections/MovieSceneEventTriggerSection.h"
#include "Tracks/MovieSceneEventTrack.h"
#include "Channels/MovieSceneEvent.h"
#include "CameraRig_Crane.h"

#include "Q6.h"
#include "Q6SoundPlayer.h"
#include "Q6LobbyState.h"
#include "GameResource.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "LevelUtil.h"
#include "SummonManager.h"
#include "UnitAnimInstance.h"
#include "SummonHUD.h"
#include "SummonBranch.h"

const int32 COMMON_BRANCHES = 2;
const int32 MAX_BRANCHES = 5;
const int32 MAX_TOTAL_CHANCE = 100;
const int32 MAX_ITEMS = 10;
const int32 INTERACTION_INDEX = 0;
const int32 RING_CUSTOMIZING_INDEX = 1;
const int32 IMPORTANT_ITEM_BEGIN_INDEX = 3;
const int32 MODEL_CUSTOMIZNG_INDEX = 4;

TAutoConsoleVariable<float> CVarCraneOffsetDuration(
	TEXT("q6.CraneOffsetDuration"),
	3.0f,
	TEXT("FastForward duration for show next"),
	ECVF_Cheat);

bool _IsValidGraceChance(int32 Branch, ESummonSequenceGrade Grade, const FSummonGradeChance& Chance)
{
	if (Chance.GetTotalChance() == MAX_TOTAL_CHANCE)
	{
		return true;
	}

	Q6JsonLogZagal(Error, "Summon - Invalid Total GradeChance",
		Q6KV("Branch", Branch),
		Q6KV("Grade", *ENUM_TO_STRING(ESummonSequenceGrade, Grade)),
		Q6KV("N", Chance.N),
		Q6KV("R", Chance.R),
		Q6KV("SR", Chance.SR),
		Q6KV("SSR", Chance.SSR));

	return false;
}

bool _IsValidGradeSequences(const TArray<const FSummonSequenceRow*>& AllRows,
							int32 Branch,
							ESummonSequenceGrade Grade,
							ESummonCategory Category)
{
	int32 TotalChance = 0;
	int32 NumCandidates = 0;

	for (const FSummonSequenceRow* Row : AllRows)
	{
		if (Row->Branch == Branch && Row->Grade == Grade && Row->Category == Category)
		{
			TotalChance += Row->Chance;
			NumCandidates++;
		}
	}

	if (NumCandidates == 0)
	{
		Q6JsonLogZagal(Error, "Summon - There is No Sequence",
			Q6KV("Branch", Branch),
			Q6KV("Grade", *ENUM_TO_STRING(ESummonSequenceGrade, Grade)),
			Q6KV("Category", *ENUM_TO_STRING(ESummonCategory, Category)));

		return false;
	}

	if (TotalChance != MAX_TOTAL_CHANCE)
	{
		Q6JsonLogZagal(Warning, "Summon - Invalid Sequence Total Chance",
			Q6KV("Branch", Branch),
			Q6KV("Grade", *ENUM_TO_STRING(ESummonSequenceGrade, Grade)),
			Q6KV("Category", *ENUM_TO_STRING(ESummonCategory, Category)),
			Q6KV("Total", TotalChance));

		return false;
	}

	return true;
}

ESummonSequenceGrade _GetGradeByChance(int32 Chance, const FSummonGradeChance& GradeChance)
{
	if (Chance < GradeChance.N)
	{
		return ESummonSequenceGrade::N;
	}
	Chance -= GradeChance.N;

	if (Chance < GradeChance.R)
	{
		return ESummonSequenceGrade::R;
	}
	Chance -= GradeChance.R;

	if (Chance < GradeChance.SR)
	{
		return ESummonSequenceGrade::SR;
	}
	Chance -= GradeChance.SR;

	ensure(Chance < GradeChance.SSR);

	return ESummonSequenceGrade::SSR;
}

const FSummonSequenceRow* _GetSequenceByChance(int32 Chance, const TArray<const FSummonSequenceRow*>& Candidates)
{
	for (const FSummonSequenceRow* Row : Candidates)
	{
		if (Chance < Row->Chance)
		{
			return Row;
		}

		Chance -= Row->Chance;
	}

	return nullptr;
}

ESummonSequenceGrade _ConvertItemToSummonGrade(EItemGrade ItemGrade)
{
	ESummonSequenceGrade SummonGrade = ESummonSequenceGrade::N;

	switch (ItemGrade)
	{
		case EItemGrade::N:
			SummonGrade = ESummonSequenceGrade::N;
			break;
		case EItemGrade::R:
			SummonGrade = ESummonSequenceGrade::R;
			break;
		case EItemGrade::SR:
			SummonGrade = ESummonSequenceGrade::SR;
			break;
		case EItemGrade::SSR:
			SummonGrade = ESummonSequenceGrade::SSR;
			break;
		default:
			Q6JsonLogZagal(Warning, "Summon - Unknown ItemGrade",
				Q6KV("Grade", *ENUM_TO_STRING(EItemGrade, ItemGrade)));
			break;
	}

	return SummonGrade;
}

ESummonCategory _ConvertItemToSummonCategory(ELootCategory Category)
{
	ESummonCategory SummonCategory = ESummonCategory::Relic;

	switch (Category)
	{
		case ELootCategory::CharacterCard:
			SummonCategory = ESummonCategory::Character;
			break;
		case ELootCategory::SculptureCard:
			SummonCategory = ESummonCategory::Sculpture;
			break;
		case ELootCategory::RelicCard:
			SummonCategory = ESummonCategory::Relic;
			break;
		default:
			Q6JsonLogZagal(Warning, "Summon - Unknown Category",
				Q6KV("Grade", *ENUM_TO_STRING(ELootCategory, Category)));
			break;
	}

	return SummonCategory;
}

ESummonSequenceGrade _ConvertToSummonSequenceGrade(ESummonForceGrade ForceGrade)
{
	ESummonSequenceGrade SequenceGrade = ESummonSequenceGrade::N;

	switch (ForceGrade)
	{
		case ESummonForceGrade::N:
			SequenceGrade = ESummonSequenceGrade::N;
			break;
		case ESummonForceGrade::R:
			SequenceGrade = ESummonSequenceGrade::R;
			break;
		case ESummonForceGrade::SR:
			SequenceGrade = ESummonSequenceGrade::SR;
			break;
		case ESummonForceGrade::SSR:
			SequenceGrade = ESummonSequenceGrade::SSR;
			break;
		default:
			Q6JsonLogZagal(Warning, "Summon - Unknown ForceGrade",
				Q6KV("Grade", *ENUM_TO_STRING(ESummonForceGrade, ForceGrade)));
			break;
	}

	return SequenceGrade;
}

FSummonInfo _ConvertToSummonInfo(ELootCategory Category, const FCharacterInfo& Info, bool bFirst)
{
	FSummonInfo SummonInfo;
	SummonInfo.Type = Info.Type.x;
	SummonInfo.Category = Category;
	SummonInfo.ItemGrade = Info.Grade;
	SummonInfo.SummonGrade = _ConvertItemToSummonGrade(Info.Grade);
	SummonInfo.Level = Info.Level.x;
	SummonInfo.Star  = Info.Star;

	const FCMSUnitRow& Row = GetCMS()->GetUnitRowOrDummy(Info.Type);

	SummonInfo.Name = Row.FullName;
	SummonInfo.NickName = Row.NickName;
	SummonInfo.NatureType = Row.NatureType;
	SummonInfo.Moon = Info.Moon;

	SummonInfo.Tier = 0;
	SummonInfo.bFirst = bFirst;

	return SummonInfo;
}

FSummonInfo _ConvertToSummonInfo(ELootCategory Category, const FSculptureInfo& Info, bool bFirst)
{
	FSummonInfo SummonInfo;
	SummonInfo.Type = Info.Type.x;
	SummonInfo.Category = Category;
	SummonInfo.ItemGrade = Info.Grade;
	SummonInfo.SummonGrade = _ConvertItemToSummonGrade(Info.Grade);
	SummonInfo.Level = Info.Level.x;
	SummonInfo.Star = Info.Star;

	const FCMSSculptureRow& Row = GetCMS()->GetSculptureRowOrDummy(Info.Type);

	SummonInfo.Name = Row.DescName;
	SummonInfo.NatureType = ENatureType::None;
	SummonInfo.Moon = 0;

	SummonInfo.Tier = Info.Tier;
	SummonInfo.bFirst = bFirst;

	return SummonInfo;
}

FSummonInfo _ConvertToSummonInfo(ELootCategory Category, const FRelicInfo& Info, bool bFirst)
{
	FSummonInfo SummonInfo;
	SummonInfo.Type = Info.Type.x;
	SummonInfo.Category = Category;
	SummonInfo.ItemGrade = Info.Grade;
	SummonInfo.SummonGrade = _ConvertItemToSummonGrade(Info.Grade);
	SummonInfo.Level = Info.Level.x;
	SummonInfo.Star = Info.Star;

	const FCMSRelicRow& Row = GetCMS()->GetRelicRowOrDummy(Info.Type);

	SummonInfo.Name = Row.DescName;
	SummonInfo.NatureType = ENatureType::None;
	SummonInfo.Moon = 0;

	SummonInfo.Tier = Info.Tier;
	SummonInfo.bFirst = bFirst;

	return SummonInfo;
}

bool FSummonInfo::IsCharacter() const
{
	return (Category == ELootCategory::CharacterCard);
}

bool FSummonInfo::IsImportant() const
{
	return (SummonGrade == ESummonSequenceGrade::SR || SummonGrade == ESummonSequenceGrade::SSR);
}

AQ6SummonGameMode::AQ6SummonGameMode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;

	Branches.SetNum(MAX_BRANCHES);

	BranchIndex = 0;
	ItemIndex = 0;
	EvaluatedItemIndex = -1;

	bNowShowing = false;
	bSkipNotImportant = false;

#if WITH_EDITOR
	bCheatingShow = false;
#endif

	bShouldStopCraneOffset = false;
}

#if WITH_EDITOR

void AQ6SummonGameMode::RegisterCheatCommands()
{
	typedef void (AQ6SummonGameMode::*ReqMemFn)(const TArray<FString>&);

	struct FCommandInfo
	{
		const TCHAR* Command;
		const TCHAR* Usage;
		ReqMemFn Handler;
	};

	FCommandInfo Commands[] =
	{
		{ TEXT("/c_summon_show"), TEXT("/c_summon_show <grade> <grade> <grade> ... (Character : 0 ~ 3, Item : 4 ~ 7)"), &AQ6SummonGameMode::CheatShowCommand },
		{ TEXT("/c_summon_show_new"), TEXT("/c_summon_show_new <grade> <grade> <grade> ... (Character : 0 ~ 3, Item : 4 ~ 7)"), &AQ6SummonGameMode::CheatShowNewCommand },
		{ TEXT("/c_summon_char"), TEXT("/c_summon_char <character type> <character type> <character type> ...."), &AQ6SummonGameMode::CheatCharCommand },
		{ TEXT("/c_summon_char_new"), TEXT("/c_summon_char_new <character type> <character type> <character type> ...."), &AQ6SummonGameMode::CheatCharNewCommand },
	};

	for (int32 i = 0; i < dimof(Commands); ++i)
	{
		FCommandInfo& Info = Commands[i];
		CheatObjects.Add(IConsoleManager::Get().RegisterConsoleCommand(
			Info.Command,
			Info.Usage,
			FConsoleCommandWithArgsDelegate::CreateUObject(this, Info.Handler),
			ECVF_Cheat)
		);
	}
}

void AQ6SummonGameMode::UnRegisterCheatCommands()
{
	for (IConsoleObject* Obj : CheatObjects)
	{
		IConsoleManager::Get().UnregisterConsoleObject(Obj);
	}
	CheatObjects.Empty();
}

void AQ6SummonGameMode::CheatShowCommand(const TArray<FString>& Args)
{
	if (Args.Num() <= 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_summon_show <grade> <grade> <grade> .... (0:R, 1:SR, 2:SSR)");
		return;
	}

	CheatShowInternal(Args, false);
}

void AQ6SummonGameMode::CheatShowNewCommand(const TArray<FString>& Args)
{
	if (Args.Num() <= 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_summon_show_new <grade> <grade> <grade> .... (0:R, 1:SR, 2:SSR)");
		return;
	}

	CheatShowInternal(Args, true);
}

void AQ6SummonGameMode::CheatShowInternal(const TArray<FString>& Args, bool bFirst)
{
	int32 NumGrades = Args.Num();

	FSummonResult Result;
	Result.Categories.Reserve(NumGrades);
	Result.FirstOrNots.SetNum(NumGrades);

	for (int32 i = 0; i < NumGrades; i++)
	{
		int32 Grade = FMath::Clamp(FCString::Atoi(*Args[i]), 0, 7);
		if (Grade < 4)	// Character
		{
			FCharacterInfo Info;
			Info.Level = FCharacterXpType(1);

			switch (Grade)
			{
				case 0:
					Info.Type = FCharacterType(501);
					Info.Grade = EItemGrade::N;
					break;
				case 1:
					Info.Type = FCharacterType(203);
					Info.Grade = EItemGrade::R;
					break;
				case 2:
					Info.Type = FCharacterType(15);
					Info.Grade = EItemGrade::SR;
					break;
				case 3:
					Info.Type = FCharacterType(14);
					Info.Grade = EItemGrade::SSR;
					break;
			}

			Result.Categories.Add(ELootCategory::CharacterCard);
			Result.Characters.Add(Info);
		}
		else  // Sculpture
		{
			FSculptureInfo Info;
			Info.Level = FItemXpType(1);
			Info.Tier = 1;

			switch (Grade)
			{
				case 4:
					Info.Type = FSculptureType(2101);
					Info.Grade = EItemGrade::N;
					break;
				case 5:
					Info.Type = FSculptureType(2201);
					Info.Grade = EItemGrade::R;
					break;
				case 6:
					Info.Type = FSculptureType(2301);
					Info.Grade = EItemGrade::SR;
					break;
				case 7:
					Info.Type = FSculptureType(2401);
					Info.Grade = EItemGrade::SSR;
					break;
			}

			Result.Categories.Add(ELootCategory::SculptureCard);
			Result.Sculptures.Add(Info);
		}

		Result.FirstOrNots[i] = bFirst;
	}

	bCheatingShow = true;

	StartShowInternal(Result);
}

void AQ6SummonGameMode::CheatCharCommand(const TArray<FString>& Args)
{
	if (Args.Num() <= 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_summon_char <character type> <character type> <character type> ....");
		return;
	}

	CheatCharInternal(Args, false);
}

void AQ6SummonGameMode::CheatCharNewCommand(const TArray<FString>& Args)
{
	if (Args.Num() <= 0)
	{
		Q6JsonLogCheater(Warning, "Usage: /c_summon_char_new <character type> <character type> <character type> ....");
		return;
	}

	CheatCharInternal(Args, true);
}

void AQ6SummonGameMode::CheatCharInternal(const TArray<FString>& Args, bool bFirst)
{
	int32 NumChars = Args.Num();

	FSummonResult Result;
	Result.Categories.Reserve(NumChars);
	Result.Characters.Reserve(NumChars);
	Result.FirstOrNots.SetNum(NumChars);

	for (int32 i = 0; i < NumChars; i++)
	{
		FCharacterType Type(FCString::Atoi(*Args[i]));

		const FCMSCharacterRow& Row = GetCMS()->GetCharacterRowOrDummy(Type);
		if (Row.IsInvalid())
		{
			continue;
		}

		FCharacterInfo Info;
		Info.Level = FCharacterXpType(1);
		Info.Type = Type;
		Info.Grade = Row.Grade;

		Result.Categories.Add(ELootCategory::CharacterCard);
		Result.Characters.Add(Info);
		Result.FirstOrNots[i] = bFirst;
	}

	bCheatingShow = true;

	StartShowInternal(Result, true);
}

#endif // WITH_EDITOR

void AQ6SummonGameMode::StartShow(const FSummonResult& SummonResult)
{
	StartShowInternal(SummonResult);
}

bool AQ6SummonGameMode::CheckTableValitation() const
{
	if (!CheckChanceTable(ESummonSequenceGrade::N, NChanceTable))
	{
		return false;
	}

	if (!CheckChanceTable(ESummonSequenceGrade::R, RChanceTable))
	{
		return false;
	}

	if (!CheckChanceTable(ESummonSequenceGrade::SR, SRChanceTable))
	{
		return false;
	}

	if (!CheckChanceTable(ESummonSequenceGrade::SSR, SSRChanceTable))
	{
		return false;
	}

	if (!CheckSequenceTable())
	{
		return false;
	}

	if (!SummonCharacterTable)
	{
		Q6JsonLogZagal(Error, "Summon - CharacterTable is NULL");
		return false;
	}

	return true;
}

bool AQ6SummonGameMode::CheckChanceTable(ESummonSequenceGrade Grade, UDataTable* ChanceTable) const
{
	if (!ChanceTable)
	{
		Q6JsonLogZagal(Error, "Summon - ChanceTable is NULL", Q6KV("Grade", *ENUM_TO_STRING(ESummonSequenceGrade, Grade)));
		return false;
	}

	for (int32 Branch = 1; Branch <= MAX_BRANCHES; Branch++)
	{
		FString TypeStr = FString::Printf(TEXT("%d"), Branch);
		const FSummonChanceRow* Row = ChanceTable->FindRow<FSummonChanceRow>(FName(*TypeStr), TEXT("Validation"), false);
		if (!Row)
		{
			Q6JsonLogZagal(Error, "Summon - SummonChanceTable has no Row", Q6KV("Branch", Branch));
			return false;
		}

		if (!_IsValidGraceChance(Branch, ESummonSequenceGrade::N, Row->N))
		{
			return false;
		}

		if (!_IsValidGraceChance(Branch, ESummonSequenceGrade::R, Row->R))
		{
			return false;
		}

		if (!_IsValidGraceChance(Branch, ESummonSequenceGrade::SR, Row->SR))
		{
			return false;
		}

		if (!_IsValidGraceChance(Branch, ESummonSequenceGrade::SSR, Row->SSR))
		{
			return false;
		}
	}

	return true;
}

bool AQ6SummonGameMode::CheckSequenceTable() const
{
	if (!SummonSequenceTable)
	{
		Q6JsonLogZagal(Error, "Summon - SummonSequenceTable is NULL");
		return false;
	}

	TArray<const FSummonSequenceRow*> AllRows;
	SummonSequenceTable->GetAllRows(TEXT("GetBranchSequences"), AllRows);

	ESummonSequenceGrade Grades[] = { ESummonSequenceGrade::N,
									  ESummonSequenceGrade::R,
									  ESummonSequenceGrade::SR,
									  ESummonSequenceGrade::SSR };

	for (int32 Branch = 1; Branch <= MAX_BRANCHES; Branch++)
	{
		for (int32 Grade = 0; Grade < dimof(Grades); Grade++)
		{
			if (!_IsValidGradeSequences(AllRows, Branch, Grades[Grade], ESummonCategory::Character))
			{
				return false;
			}
		}
	}

	if (!_IsValidGradeSequences(AllRows, 3, ESummonSequenceGrade::N, ESummonCategory::Sculpture))
	{
		return false;
	}

	if (!_IsValidGradeSequences(AllRows, 3, ESummonSequenceGrade::N, ESummonCategory::Relic))
	{
		return false;
	}

	for (int32 Branch = 4; Branch <= MAX_BRANCHES; Branch++)
	{
		for (int32 Grade = 0; Grade < dimof(Grades); Grade++)
		{
			if (!_IsValidGradeSequences(AllRows, Branch, Grades[Grade], ESummonCategory::Sculpture))
			{
				return false;
			}

			if (!_IsValidGradeSequences(AllRows, Branch, Grades[Grade], ESummonCategory::Relic))
			{
				return false;
			}
		}
	}

	return true;
}

void AQ6SummonGameMode::StartPlay()
{
	Super::StartPlay();

	if (!CheckTableValitation())
	{
		BackToLobby();
		return;
	}

	GetSoundPlayer().PlayMainBGM(TEXT("Summon"));

	FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &AQ6SummonGameMode::OnPostLoadMap);

#if WITH_EDITOR
	RegisterCheatCommands();
#endif
}

void AQ6SummonGameMode::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (CraneOffset.IsSet())
	{
		for (TActorIterator<ACameraRig_Crane> It(GetWorld(), ACameraRig_Crane::StaticClass()); It; ++It)
		{
			ACameraRig_Crane* Crane = *It;
			if (Crane)
			{
				Crane->AddActorWorldOffset(CraneOffset.GetValue());
			}
		}
	}

	if (bShouldStopCraneOffset)
	{
		CraneOffset.Reset();
		bShouldStopCraneOffset = false;
	}
}

void AQ6SummonGameMode::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
#if WITH_EDITOR
	UnRegisterCheatCommands();
#endif

	FCoreUObjectDelegates::PostLoadMapWithWorld.RemoveAll(this);
	DestroyActiveBranch();

	Super::EndPlay(EndPlayReason);
}

void AQ6SummonGameMode::OnPostLoadMap(UWorld* World)
{
	const FSummonResult& SummonResult = GetHUDStore().GetSummonManager().GetSummonResult();
	StartShow(SummonResult);
}

void AQ6SummonGameMode::StartShowInternal(const FSummonResult& SummonResult, bool bSkipCommon)
{
	GenerateSummonInfo(SummonResult);

	if (bSkipCommon)
	{
		BranchIndex = COMMON_BRANCHES;
	}
	else
	{
		BranchIndex = GetStartBranchIndex();
	}

	ItemIndex = 0;
	EvaluatedItemIndex = -1;

	bNowShowing = true;
	bSkipNotImportant = false;

	if (BranchIndex != COMMON_BRANCHES)
	{
		EvaluateCommonBranches();
	}
	else
	{
		EvaluateEachBranches();
	}

	if (ASummonHUD* HUD = GetCheckedSummonHUD(this))
	{
		HUD->ShowSkipButton(true);
		HUD->HideResultWidget();
	}

	ExecuteBranch();
}

int32 AQ6SummonGameMode::GetStartBranchIndex()
{
	for (const FSummonInfo& Info : SummonInfos)
	{
		if (Info.IsCharacter())
		{
			return 0;
		}
	}

	return COMMON_BRANCHES;
}

ESummonSequenceGrade AQ6SummonGameMode::EvaluateCommonGrade()
{
	ESummonSequenceGrade SummonGrade = ESummonSequenceGrade::N;

	for (const FSummonInfo& Info : SummonInfos)
	{
		if (!Info.IsCharacter())
		{
			continue;
		}

		if (SummonGrade < Info.SummonGrade)
		{
			SummonGrade = Info.SummonGrade;
		}
	}

	Q6JsonLogZagal(Display, "Summon - SummonGrade", Q6KV("Grade", *ENUM_TO_STRING(ESummonSequenceGrade, SummonGrade)));

	return SummonGrade;
}

void AQ6SummonGameMode::GenerateSummonInfo(const FSummonResult& Result)
{
	SummonInfos.SetNum(Result.Categories.Num());

	int32 CharacterIndex = 0;
	int32 SculptureIndex = 0;
	int32 RelicIndex = 0;

	for (int32 i = 0; i < Result.Categories.Num(); i++)
	{
		ELootCategory Category = Result.Categories[i];
		bool bFirst = Result.FirstOrNots[i];

		switch (Category)
		{
			case ELootCategory::CharacterCard:
				SummonInfos[i] = _ConvertToSummonInfo(Category, Result.Characters[CharacterIndex], bFirst);
				CharacterIndex++;
				break;
			case ELootCategory::SculptureCard:
				SummonInfos[i] = _ConvertToSummonInfo(Category, Result.Sculptures[SculptureIndex], bFirst);
				SculptureIndex++;
				break;
			case ELootCategory::RelicCard:
				SummonInfos[i] = _ConvertToSummonInfo(Category, Result.Relics[RelicIndex], bFirst);
				RelicIndex++;
				break;
		}
	}
}

USummonBranch* AQ6SummonGameMode::CreateBranch(ULevelSequence* Seq1, bool bPauseAtEnd)
{
	TArray<ULevelSequence*> Sequences;
	Sequences.Add(Seq1);

	FSummonBranchParam Param;
	Param.bPauseAtEnd = bPauseAtEnd;

	return CreateBranch(Sequences, Param);
}

USummonBranch* AQ6SummonGameMode::CreateBranch(ULevelSequence* Seq1, ULevelSequence* Seq2, ULevelSequence* Seq3, ULevelSequence* Seq4)
{
	TArray<ULevelSequence*> Sequences;
	Sequences.Add(Seq1);
	Sequences.Add(Seq2);
	Sequences.Add(Seq3);
	Sequences.Add(Seq4);

	FSummonBranchParam Param;
	Param.LoopIndex = 2;

	return CreateBranch(Sequences, Param);
}

USummonBranch* AQ6SummonGameMode::CreateBranch(ULevelSequence* Seq1, ULevelSequence* Seq2, int32 ModelType, bool bCustomInstance)
{
	TArray<ULevelSequence*> Sequences;
	Sequences.Add(Seq1);

	if (Seq2)
	{
		Sequences.Add(Seq2);
	}

	FSummonBranchParam Param;
	Param.ModelType = ModelType;
	Param.bPauseAtEnd = true;
	Param.bCustomInstance = bCustomInstance;

	return CreateBranch(Sequences, Param);
}

USummonBranch* AQ6SummonGameMode::CreateBranch(const TArray<ULevelSequence*>& Sequences, const FSummonBranchParam& Param)
{
	USummonBranch* Branch = NewObject<USummonBranch>(this);
	Branch->Initialize(Sequences, Param);

	return Branch;
}

USummonBranch* AQ6SummonGameMode::GetBranch(int32 Index)
{
	if (Branches.IsValidIndex(Index) && Branches[Index])
	{
		return Branches[Index];
	}

	Q6JsonLogZagal(Error, "Summon - Failed to GetBranch", Q6KV("Index", Index));
	return nullptr;
}

void AQ6SummonGameMode::EvaluateCommonBranches()
{
	ESummonCategory Category = ESummonCategory::Character;
	ESummonSequenceGrade TableGrade = EvaluateCommonGrade();
	ESummonSequenceGrade GambleGrade = TableGrade;

	TArray<ULevelSequence*> Sequences;
	Sequences.SetNum(COMMON_BRANCHES);

	for (int32 Index = 0; Index < COMMON_BRANCHES; Index++)
	{
		int32 Branch = Index + 1;

		GambleGrade = GambleBranchGrade(Branch, TableGrade, GambleGrade);
		Sequences[Index] = GambleBranchSequence(Branch, Category, GambleGrade);
	}

	Branches[0] = CreateBranch(Sequences[0], EnterSub, EnterLoop, EnterEnd);
	Branches[1] = CreateBranch(Sequences[1], false);
}

void AQ6SummonGameMode::EvaluateEachBranches()
{
	if (ItemIndex == EvaluatedItemIndex)
	{
		return;
	}

	const FSummonInfo& Info = SummonInfos[ItemIndex];

	if (Info.IsCharacter())
	{
		EvaluateCharacterBranches(Info);
	}
	else
	{
		EvaluateNoneCharacterBranches(Info);
	}

	EvaluatedItemIndex = ItemIndex;
}

void AQ6SummonGameMode::EvaluateNoneCharacterBranches(const FSummonInfo& Info)
{
	ESummonCategory Category = _ConvertItemToSummonCategory(Info.Category);
	ULevelSequence* Sequence = nullptr;

	for (int32 i = COMMON_BRANCHES; i < MAX_BRANCHES; i++)
	{
		int32 Branch = i + 1;

		Sequence = GambleBranchSequence(Branch, Category, ESummonSequenceGrade::N);
		Branches[i] = CreateBranch(Sequence, i == MODEL_CUSTOMIZNG_INDEX);
	}
}

void AQ6SummonGameMode::EvaluateCharacterBranches(const FSummonInfo& Info)
{
	ESummonSequenceGrade TableGrade = Info.SummonGrade;
	ESummonSequenceGrade GambleGrade = TableGrade;
	ESummonForceGrade ForceGrade = ESummonForceGrade::None;
	ESummonCategory Category = ESummonCategory::Character;

	ULevelSequence* Sequences[MAX_BRANCHES] = { nullptr, nullptr, nullptr, nullptr, nullptr };

	for (int32 i = COMMON_BRANCHES; i < MAX_BRANCHES; i++)
	{
		int32 Branch = i + 1;

		GambleGrade = GambleBranchGrade(Branch, TableGrade, GambleGrade);
		Sequences[i] = GambleBranchSequence(Branch, Category, GambleGrade, &ForceGrade);
	}

	if (ForceGrade != ESummonForceGrade::None)
	{
		Q6JsonLogZagal(Display, "Summon - Change previous by last one",
			Q6KV("ForceGrade", *ENUM_TO_STRING(ESummonForceGrade, ForceGrade)));

		ESummonSequenceGrade NewGrade = _ConvertToSummonSequenceGrade(ForceGrade);

		for (int32 i = COMMON_BRANCHES; i < MAX_BRANCHES - 1; i++)
		{
			int32 Branch = i + 1;

			Sequences[i] = GambleBranchSequence(Branch, Category, NewGrade);
		}
	}

	bool bCustomInstance = false;
	ULevelSequence* CharacterSeq = nullptr;
	int32 ModelType = GetCMS()->GetUnitRowOrDummy(FCharacterType(Info.Type)).Model;

	if (Info.IsImportant())
	{
		if (Info.bFirst)
		{
			CharacterSeq = GetCharacterSequence(Info);
		}

		if (CharacterSeq)
		{
			bCustomInstance = true;
		}
		else
		{
			switch (Info.SummonGrade)
			{
				case ESummonSequenceGrade::SR:
					CharacterSeq = DefaultCharacterSR;
					break;
				case ESummonSequenceGrade::SSR:
					CharacterSeq = DefaultCharacterSSR;
					break;
			}
		}
	}

	for (int32 i = COMMON_BRANCHES; i < MAX_BRANCHES; i++)
	{
		if (i != MODEL_CUSTOMIZNG_INDEX)
		{
			Branches[i] = CreateBranch(Sequences[i], false);
		}
		else
		{
			Branches[i] = CreateBranch(Sequences[i], CharacterSeq, ModelType, bCustomInstance);
		}
	}
}

ESummonSequenceGrade AQ6SummonGameMode::GambleBranchGrade(int32 Branch, ESummonSequenceGrade TableGrade, ESummonSequenceGrade BeforeGrade)
{
	const FSummonChanceRow* Row = nullptr;
	FString TypeStr = FString::Printf(TEXT("%d"), Branch);

	switch (TableGrade)
	{
		case ESummonSequenceGrade::N:
			Row = NChanceTable->FindRow<FSummonChanceRow>(FName(*TypeStr), TEXT("Gamble"), false);
			break;
		case ESummonSequenceGrade::R:
			Row = RChanceTable->FindRow<FSummonChanceRow>(FName(*TypeStr), TEXT("Gamble"), false);
			break;
		case ESummonSequenceGrade::SR:
			Row = SRChanceTable->FindRow<FSummonChanceRow>(FName(*TypeStr), TEXT("Gamble"), false);
			break;
		case ESummonSequenceGrade::SSR:
			Row = SSRChanceTable->FindRow<FSummonChanceRow>(FName(*TypeStr), TEXT("Gamble"), false);
			break;
	}

	if (!Row)
	{
		Q6JsonLogZagal(Warning, "Summon - GambleBranchGrade Row is null",
			Q6KV("Grade", ENUM_TO_STRING(ESummonSequenceGrade, TableGrade)));
		return ESummonSequenceGrade::N;
	}

	FSummonGradeChance GradeChance = Row->N;

	switch (BeforeGrade)
	{
		case ESummonSequenceGrade::N:
			GradeChance = Row->N;
			break;
		case ESummonSequenceGrade::R:
			GradeChance = Row->R;
			break;
		case ESummonSequenceGrade::SR:
			GradeChance = Row->SR;
			break;
		case ESummonSequenceGrade::SSR:
			GradeChance = Row->SSR;
			break;
	}

	ensure(GradeChance.GetTotalChance() == MAX_TOTAL_CHANCE);

	int32 Chance = FMath::RandHelper(MAX_TOTAL_CHANCE);
	ESummonSequenceGrade GambleGrade = _GetGradeByChance(Chance, GradeChance);

	Q6JsonLogZagal(Display, "Summon - GambleBranchGrade",
		Q6KV("Branch", Branch),
		Q6KV("TableGrade", *ENUM_TO_STRING(ESummonSequenceGrade, TableGrade)),
		Q6KV("BeforeGrade", *ENUM_TO_STRING(ESummonSequenceGrade, BeforeGrade)),
		Q6KV("Chance", Chance),
		Q6KV("Result", *ENUM_TO_STRING(ESummonSequenceGrade, GambleGrade)));

	return GambleGrade;
}

ULevelSequence* AQ6SummonGameMode::GambleBranchSequence(int32 Branch, ESummonCategory Category, ESummonSequenceGrade Grade, ESummonForceGrade* OutForceGrade)
{
	if (OutForceGrade)
	{
		*OutForceGrade = ESummonForceGrade::None;
	}

	TArray<const FSummonSequenceRow*> AllRows;
	SummonSequenceTable->GetAllRows(TEXT("GetBranchSequences"), AllRows);

	int32 TotalChance = 0;
	TArray<const FSummonSequenceRow*> Candidates;

	for (const FSummonSequenceRow* Row : AllRows)
	{
		if (Row->Branch == Branch && Row->Category == Category && Row->Grade == Grade)
		{
			TotalChance += Row->Chance;
			Candidates.Add(Row);
		}
	}

	ensure(Candidates.Num() > 0);
	ensure(TotalChance == MAX_TOTAL_CHANCE);

	// 0 <= x < MAX_TOTAL_CHANCE
	int32 Chance = FMath::RandHelper(MAX_TOTAL_CHANCE);
	const FSummonSequenceRow* SequenceRow = _GetSequenceByChance(Chance, Candidates);
	if (!SequenceRow)
	{
		Q6JsonLogZagal(Error, "Summon - SequenceRow is null",
			Q6KV("Branch", Branch),
			Q6KV("Category", *ENUM_TO_STRING(ESummonCategory, Category)),
			Q6KV("Grade", *ENUM_TO_STRING(ESummonSequenceGrade, Grade)));
		return nullptr;
	}

	ULevelSequence* Sequence = SequenceRow->Sequence.LoadSynchronous();
	if (!Sequence)
	{
		Q6JsonLogZagal(Error, "Summon - Failed to load sequence",
			Q6KV("Sequence", *SequenceRow->Sequence.ToString()));
		return nullptr;
	}

	if (OutForceGrade)
	{
		*OutForceGrade = SequenceRow->ForceGrade;
	}

	Q6JsonLogZagal(Display, "Summon - GambleBranchSequence",
		Q6KV("Branch", Branch),
		Q6KV("Grade", *ENUM_TO_STRING(ESummonSequenceGrade, Grade)),
		Q6KV("Chance", Chance),
		Q6KV("Sequence", *Sequence->GetName()));

	return Sequence;
}

const FSummonCharacterRow* AQ6SummonGameMode::GetCharacterRow(const FSummonInfo& Info)
{
	FString TypeStr = FString::Printf(TEXT("%d"), Info.Type);
	return SummonCharacterTable->FindRow<FSummonCharacterRow>(FName(*TypeStr), TypeStr, false);
}

ULevelSequence* AQ6SummonGameMode::GetCharacterSequence(const FSummonInfo& Info)
{
	const FSummonCharacterRow* Row = GetCharacterRow(Info);
	if (Row && !Row->Sequence.IsNull())
	{
		return Row->Sequence.LoadSynchronous();
	}

	return nullptr;
}

void AQ6SummonGameMode::OnLoopStart()
{
	ShowInteractionUI();
}

void AQ6SummonGameMode::OnSequenceEnd()
{
	bShouldStopCraneOffset = true;

	if (BranchIndex < MODEL_CUSTOMIZNG_INDEX)
	{
		MoveNextBranch(BranchIndex + 1);
	}
}

bool AQ6SummonGameMode::PlayBranch(int32 Index, bool bJumpToSkip)
{
	USummonBranch* Branch = GetBranch(Index);
	if (!Branch)
	{
		return false;
	}

	if (Index == INTERACTION_INDEX)
	{
		Branch->LoopBegin.BindUObject(this, &AQ6SummonGameMode::OnLoopStart);
	}

	Branch->SequenceEnd.BindUObject(this, &AQ6SummonGameMode::OnSequenceEnd);

	if (Branch->Play(this, bJumpToSkip))
	{
		ActiveBranch = Branch;

		if (Index == RING_CUSTOMIZING_INDEX)
		{
			SummonSignCustomizing();
		}

		return true;
	}

	return false;
}

void AQ6SummonGameMode::DestroyActiveBranch()
{
	if (ActiveBranch)
	{
		ActiveBranch->DestroySequenceActor();
		ActiveBranch = nullptr;
	}
}

void AQ6SummonGameMode::OnMoveToNext()
{
	if (!bNowShowing)
	{
		return;
	}

	if (BranchIndex == INTERACTION_INDEX)	// 0
	{
		if (USummonBranch* Branch = GetBranch(BranchIndex))
		{
			Branch->JumpToLoop();
		}
	}
	else if (BranchIndex == RING_CUSTOMIZING_INDEX)	// 1
	{
		MoveNextBranch(BranchIndex + 1);
	}
	else if (BranchIndex < MODEL_CUSTOMIZNG_INDEX)	// 2, 3
	{
		MoveNextBranch(MODEL_CUSTOMIZNG_INDEX, true);
	}
	else if (BranchIndex == MODEL_CUSTOMIZNG_INDEX)	// 4
	{
		if (USummonBranch* Branch = GetBranch(BranchIndex))
		{
			if (!Branch->JumpToNextSkipFrame())
			{
				if (ASummonHUD* HUD = GetCheckedSummonHUD(this))
				{
					HUD->MoveToNextSummonInfo();
				}
			}
		}
	}
}

void AQ6SummonGameMode::OnSkip()
{
	bSkipNotImportant = true;

	const FSummonInfo& Info = SummonInfos[ItemIndex];
	if (Info.IsImportant())
	{
		if (BranchIndex < IMPORTANT_ITEM_BEGIN_INDEX)
		{
			MoveNextBranch(IMPORTANT_ITEM_BEGIN_INDEX);
			return;
		}
		else if (Info.bFirst)
		{
			return;
		}
	}

	if (ASummonHUD* HUD = GetCheckedSummonHUD(this))
	{
		HUD->HideSummonInfo();
	}

	SkipToNextImportantItemBranch();
}

void AQ6SummonGameMode::OnBack()
{
	BackToLobby();
}

void AQ6SummonGameMode::OnInteraction()
{
	if (ActiveBranch)
	{
		ActiveBranch->StopLooping();
	}
}

void AQ6SummonGameMode::OnSummonInfoEnd()
{
	if (ASummonHUD* HUD = GetCheckedSummonHUD(this))
	{
		HUD->HideSummonInfo();
	}

	if (bSkipNotImportant)
	{
		SkipToNextImportantItemBranch();
	}
	else
	{
		MoveNextBranch(BranchIndex + 1);
	}
}

void AQ6SummonGameMode::MoveNextBranch(int32 NextBranchIndex, bool bJumpToSkip)
{
	if (NextBranchIndex < MAX_BRANCHES)
	{
		EvaluateEachBranches();

		BranchIndex = NextBranchIndex;
		bJumpToSkip = (NextBranchIndex == MODEL_CUSTOMIZNG_INDEX) && bJumpToSkip;

		ExecuteBranch(bJumpToSkip);
	}
	else
	{
		int32 NextItemIndex = ItemIndex + 1;

		if (NextItemIndex < SummonInfos.Num())
		{
			BranchIndex = COMMON_BRANCHES;
			ItemIndex = NextItemIndex;

			EvaluateEachBranches();
			ExecuteBranch();
		}
		else
		{
			ShowResultWidget();
		}
	}
}

void AQ6SummonGameMode::SkipToNextImportantItemBranch()
{
	for (int32 NextIndex = ItemIndex + 1; NextIndex < SummonInfos.Num(); NextIndex++)
	{
		if (SummonInfos[NextIndex].IsImportant())
		{
			ItemIndex = NextIndex;
			MoveNextBranch(IMPORTANT_ITEM_BEGIN_INDEX);
			return;
		}
	}

	BranchIndex = MAX_BRANCHES - 1;
	ItemIndex = SummonInfos.Num() - 1;

	ShowResultWidget();
}

void AQ6SummonGameMode::ExecuteBranch(bool bJumpToSkip)
{
	DestroyActiveBranch();

	if (!PlayBranch(BranchIndex, bJumpToSkip))
	{
		BackToLobby();
	}
}

void AQ6SummonGameMode::BackToLobby()
{
	bNowShowing = false;

#if WITH_EDITOR
	if (bCheatingShow)
	{
		DestroyActiveBranch();
		return;
	}
#endif

	ULevelUtil::LoadLobbyLevel(GetWorld());
}

void AQ6SummonGameMode::ShowInteractionUI()
{
	if (ASummonHUD* HUD = GetCheckedSummonHUD(this))
	{
		HUD->InteractionReady();
	}
}

void AQ6SummonGameMode::ShowResultWidget()
{
	bNowShowing = false;
	bSkipNotImportant = false;

	DestroyActiveBranch();

#if WITH_EDITOR
	if (bCheatingShow)
	{
		return;
	}
#endif

	if (ASummonHUD* HUD = GetCheckedSummonHUD(this))
	{
		HUD->ShowResultWidget();
	}
}

void AQ6SummonGameMode::OnShowUI()
{
	if (!SummonInfos.IsValidIndex(ItemIndex))
	{
		return;
	}

	const FSummonInfo& Info = SummonInfos[ItemIndex];

	if (ASummonHUD* HUD = GetCheckedSummonHUD(this))
	{
		HUD->SetSummonInfo(Info, FSimpleDelegate::CreateUObject(this, &AQ6SummonGameMode::OnSummonInfoEnd));
	}

	if (Info.IsCharacter())
	{
		const FSummonCharacterRow* Row = GetCharacterRow(Info);
		if (Row && !Row->Offset.IsZero())
		{
			CraneOffset = Row->Offset;
		}
		else
		{
			CraneOffset.Reset();
		}

		bShouldStopCraneOffset = false;
	}
}

void _SignEmitterCustomizing(AEmitter* Emitter, UParticleSystem* Template)
{
	bool bHidden = (Template == nullptr);
	Emitter->SetActorHiddenInGame(bHidden);

	if (Template)
	{
		if (UParticleSystemComponent* Comp = Emitter->GetParticleSystemComponent())
		{
			Comp->SetTemplate(Template);
		}
	}
}

void AQ6SummonGameMode::SummonSignCustomizing()
{
	TArray<AEmitter*> Emitters;
	Emitters.Reserve(MAX_ITEMS);

	for (TActorIterator<AEmitter> It(GetWorld(), AEmitter::StaticClass()); It; ++It)
	{
		AEmitter* Emitter = *It;
		if (Emitter->GetName().StartsWith(TEXT("SummonSign")))
		{
			Emitters.Add(Emitter);
		}
	}

	TArray<AEmitter*> Signs;
	Signs.SetNum(MAX_ITEMS);

	for (int32 i = 0; i < MAX_ITEMS; i++)
	{
		FName InKey(*FString::Printf(TEXT("SummonSign%d"), i + 1));
		for (AEmitter* Emitter : Emitters)
		{
			if (Emitter->GetFName().IsEqual(InKey, ENameCase::IgnoreCase, false))
			{
				Signs[i] = Emitter;
				break;
			}
		}
	}

	for (int32 i = 0; i < MAX_ITEMS; i++)
	{
		AEmitter* Emitter = Signs[i];
		if (!Emitter)
		{
			continue;
		}

		if (SummonInfos.IsValidIndex(i))
		{
			_SignEmitterCustomizing(Emitter, GetSignTemplate(SummonInfos[i]));
		}
		else
		{
			_SignEmitterCustomizing(Emitter, nullptr);
		}
	}
}

UParticleSystem* AQ6SummonGameMode::GetSignTemplate(const FSummonInfo& Info)
{
	if (Info.IsCharacter())
	{
		switch (Info.SummonGrade)
		{
			case ESummonSequenceGrade::N:
				return SummonSignN;
			case ESummonSequenceGrade::R:
				return SummonSignR;
			case ESummonSequenceGrade::SR:
				return SummonSignSR;
			case ESummonSequenceGrade::SSR:
				return SummonSignSSR;
		}
	}

	return SummonSignCard;
}
