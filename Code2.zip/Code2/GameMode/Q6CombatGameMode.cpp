// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6CombatGameMode.h"

#include "Chronicle/Chronicle.h"
#include "CombatCube.h"
#include "CombatGameResource.h"
#include "CombatHUD.h"
#include "CombatPresenter.h"
#include "GameResource.h"
#include "Kismet/GameplayStatics.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6CombatGameMode.h"
#include "Q6SoundPlayer.h"
#include "SystemConstHelper.h"
#include "Utils/LevelUtil.h"

TAutoConsoleVariable<float> CVarQ6SpeedIdle(
	TEXT("q6.speedIdle"),
	1.0f,
	TEXT("combat game play double speed ratio for idle (from 1.0 to 2.0 default 1.0)"),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarQ6SpeedUlt(
	TEXT("q6.speedUlt"),
	1.4f,
	TEXT("combat game play double speed ratio for ultimate skill (from 1.0 to 2.0 default 1.4)"),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarQ6SpeedAction(
	TEXT("q6.speedAction"),
	1.6f,
	TEXT("combat game play double speed ratio for turnskill, turnspawn, attack, hit, death, etc. (from 1.0 to 2.0 default 1.6)"),
	ECVF_Cheat);

extern TAutoConsoleVariable<int32> CVarQ6UseLobbyCombat;

AQ6CombatGameMode::AQ6CombatGameMode(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	//PrimaryActorTick.bCanEverTick = true;
}

void AQ6CombatGameMode::StartPlay()
{
	Super::StartPlay();

	bDoubleSpeed = false;
	CurrentSpeed = EQ6GameSpeed::Normal;

	CombatGameResource = NewObject<UCombatGameResource>(GetTransientPackage(), GetGameResource().GetCombatGameResourceClass());
	checkf(CombatGameResource, TEXT("Failed to create Combat game resource"));

	CombatCube = GetWorld()->SpawnActor<ACombatCube>();

	Presenter = GetWorld()->SpawnActor<ACombatPresenter>();

	ChronicleRunner = GetWorld()->SpawnActor<AChronicleRunner>();
	ChronicleRunner->SetTargets(CombatCube, Presenter);

	//ToDo : PreLoad
	StartActInternal();

	//ToDo : Adjust time CombatSound
	GetSoundPlayer().PlayMainBGM(TEXT("SagaNormal"));

#if !UE_BUILD_SHIPPING
	RegisterCheatCommands();
#endif // !UE_BUILD_SHIPPING

	// Bind Effect Attribute
	ULevelUtil::LoadZoneAttribute(GetWorld());
}

void AQ6CombatGameMode::SetGameDoubleSpeed(bool bInDoubleSpeed)
{
	bDoubleSpeed = bInDoubleSpeed;
	SetInternalGameSpeed();
}

void AQ6CombatGameMode::AddSpeed(int32 InSource, EQ6GameSpeed InSpeed)
{
	SpeedRequester.Add(InSource);
	CurrentSpeed = InSpeed;
	SetInternalGameSpeed();
}

void AQ6CombatGameMode::RevertSpeed(int32 InSource)
{
	SpeedRequester.RemoveSingle(InSource);
	SetInternalGameSpeed();
}

void AQ6CombatGameMode::SetInternalGameSpeed()
{
	if (!bDoubleSpeed)
	{
		UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 1.f);
		return;
	}

	float AppliedSpeed = 1.f;
	if (SpeedRequester.Num() == 0 ||
		CurrentSpeed == EQ6GameSpeed::Normal)
	{
		AppliedSpeed = CVarQ6SpeedIdle.GetValueOnAnyThread();
	}
	else if (CurrentSpeed == EQ6GameSpeed::Speedy)
	{
		AppliedSpeed = CVarQ6SpeedUlt.GetValueOnAnyThread();
	}
	else
	{
		AppliedSpeed = CVarQ6SpeedAction.GetValueOnAnyThread();
	}

	AppliedSpeed = FMath::Clamp(AppliedSpeed, 1.f, 2.f);
	UGameplayStatics::SetGlobalTimeDilation(GetWorld(), AppliedSpeed);
}

void AQ6CombatGameMode::StartCombatCube()
{
	const FCCCombatSeed& CombatSeed = UQ6GameInstance::Get(this)->GetCombatSeed();
	CombatCube->InitCombatCube(CombatSeed);
	ULevelUtil::LoadSagaLightPreset(GetWorld(), GetCMS()->GetLightPreset(CombatSeed.SagaType));
}

#if !UE_BUILD_SHIPPING

void AQ6CombatGameMode::RegisterCheatCommands()
{
	CheatObject = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("d"),
		TEXT("d : toggle combat debug widget"),
		FConsoleCommandDelegate::CreateUObject(this, &AQ6CombatGameMode::ToggleDebugWidget),
		ECVF_Cheat);
}

void AQ6CombatGameMode::UnRegisterCheatCommands()
{
	IConsoleManager::Get().UnregisterConsoleObject(CheatObject);
}

void AQ6CombatGameMode::ToggleDebugWidget()
{
	GetCheckedCombatHUD(this)->ToggleDebugWidget();
}

#endif // !UE_BUILD_SHIPPING

void AQ6CombatGameMode::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	// restore time dilation mod.
	UGameplayStatics::SetGlobalTimeDilation(GetWorld(), 1.f);

#if !UE_BUILD_SHIPPING
	UnRegisterCheatCommands();
#endif // !UE_BUILD_SHIPPING

	Super::EndPlay(EndPlayReason);
	UQ6GameInstance::Get()->SetZoneAttribute(EZoneAttribute::Ground);
}

void AQ6CombatGameMode::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	// for debugging overlapped CPInstances
	// GEngine->AddOnScreenDebugMessage(1, 0.5f, FColor::Yellow, FString::Printf(TEXT("Current Requester: %d"), SpeedRequester.Num()));
	// GEngine->AddOnScreenDebugMessage(2, 0.5f, FColor::Blue, FString::Printf(TEXT("Speed: %d"), (int32)CurrentSpeed));
}

void AQ6CombatGameMode::StartActInternal()
{
	ChronicleRunner->LoadOngoing();
	if (ChronicleRunner->IsLoaded())
	{
		ChronicleRunner->Run();
		return;
	}

	Presenter->BindCombatCubeEvent(CombatCube);

	if (!UQ6GameInstance::Get(this)->GetNoAuthCC())
	{
		StartCombatCube();
	}
}

FCCCombatSeed AQ6CombatGameMode::MakeCombatSeed(int32 Episode, int32 Stage, int32 SubStage, const TArray<FCCCombatSeedUnit>& Units, const TArray<FCCCombatSeedUnit>& SubUnits, const TArray<int32>& ArtifactLevels, const FPetType& PetType, const TArray<int32>& PetSkillLevels, const FCombatMultiSideInfo& CombatMultiSideInfo) const
{
	if (CVarQ6UseLobbyCombat.GetValueOnGameThread())
	{
		UQ6GameInstance::Get()->SetNoAuthCC();
	}

	FCCCombatSeed CombatSeed;
	CombatSeed.SagaType = GetCMS()->FindSagaType(Episode, Stage, SubStage);
	CombatSeed.Units = Units;
	for (const FCCCombatSeedUnit& S : SubUnits)
	{
		if (S.UnitType == UnitTypeInvalid)
		{
			continue;
		}
		CombatSeed.SubUnits.Push(S);
	}
	CombatSeed.Seed.RandomSeed = 0;

	CombatSeed.Seed.ArtifactAvailable.Empty();
	for (int i = 0; i < SystemConst::Q6_MAX_TEMPLE_ARTIFACTS; ++i)
	{
		FSeedArtifact SeedArtifact;
		SeedArtifact.Available = ArtifactLevels.IsValidIndex(i);
		SeedArtifact.Level = SeedArtifact.Available ? ArtifactLevels[i] : 0;
		CombatSeed.Seed.ArtifactAvailable.Add(SeedArtifact);
	}

	CombatSeed.Seed.PetInfo.PetId = FPetId(1);
	CombatSeed.Seed.PetInfo.Type = PetType;
	CombatSeed.Seed.PetInfo.Skill1Level = PetSkillLevels.IsValidIndex(0) ? PetSkillLevels[0] : 0;
	CombatSeed.Seed.PetInfo.Skill2Level = PetSkillLevels.IsValidIndex(1) ? PetSkillLevels[1] : 0;
	CombatSeed.Seed.PetInfo.Skill3Level = PetSkillLevels.IsValidIndex(2) ? PetSkillLevels[2] : 0;

	// pawn - test code
	CombatSeed.CombatMultiSideInfo = CombatMultiSideInfo;

	if (!CombatMultiSideInfo.bIsCombatMultiSide)
	{
		// substitute lobbyd stageBegin
		const FCMSSagaRow& Row = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);
		if (Row.ContentType == EContentType::MultiSideBattle)
		{
			// rounding wave numbers
			const int32 WaveNum = (Row.GetWave().Num() + 1) / 2;

			CombatSeed.Seed.FirstWaveIndex = 0;
			CombatSeed.Seed.LastWaveIndex = WaveNum - 1;
			CombatSeed.Seed.TotalWaveNum = WaveNum;
			CombatSeed.Seed.AppearanceWave.Init(true, WaveNum);

			for (FCCCombatSeedUnit& SubUnit : CombatSeed.SubUnits)
			{
				SubUnit.CombatMultiSide = ECombatMultiSide::Sub;
			}

			CombatSeed.Units.Append(CombatSeed.SubUnits);
			CombatSeed.SubUnits.Empty();

			CombatSeed.CombatMultiSideInfo.OfflineEnemies.Empty();
			CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide = true;
		}
		else
		{
			CombatSeed.Seed.FirstWaveIndex = 0;
			CombatSeed.Seed.LastWaveIndex = Row.GetWave().Num() - 1;
			CombatSeed.Seed.TotalWaveNum = Row.GetWave().Num();
			CombatSeed.Seed.AppearanceWave.Init(true, Row.GetWave().Num());
		}

		for (const FCMSWaveRow* W : Row.GetWave())
		{
			FWaveMonster spawns;
			FUnitType Spawn01 = W->Spawns01.IsValidIndex(0) ? FUnitType(W->Spawns01[0]) : UnitTypeInvalid;
			spawns.SpawnUnitType.Push(Spawn01);
			FUnitType Spawn02 = W->Spawns02.IsValidIndex(0) ? FUnitType(W->Spawns02[0]) : UnitTypeInvalid;
			spawns.SpawnUnitType.Push(Spawn02);
			FUnitType Spawn03 = W->Spawns03.IsValidIndex(0) ? FUnitType(W->Spawns03[0]) : UnitTypeInvalid;
			spawns.SpawnUnitType.Push(Spawn03);

			CombatSeed.Seed.WaveMonsters.Push(spawns);
		}
	}
	else
	{
		CombatSeed.Seed.FirstWaveIndex = 0;
		CombatSeed.Seed.LastWaveIndex = CombatMultiSideInfo.TotalWaveNum - 1;
		CombatSeed.Seed.TotalWaveNum = CombatMultiSideInfo.TotalWaveNum;
		CombatSeed.Seed.AppearanceWave.Init(true, CombatMultiSideInfo.TotalWaveNum);

		CombatSeed.CombatMultiSideInfo.bIsOfflineMode = true;
	}

	return CombatSeed;
}

TArray<UCCEvent*> AQ6CombatGameMode::ParseLobbyCCEvents(const FString& Msg)
{
	return ChronicleRunner->ParseLobbyCCEvents(Msg);
}

static const int32 MaxChronicleProsecutorsCount = 10;

void AQ6JudgementGameMode::StartPlay()
{
	Super::StartPlay();

	Prosecutors.SetNum(MaxChronicleProsecutorsCount);
	for (int32 i = 0; i < MaxChronicleProsecutorsCount; ++i)
	{
		Prosecutors[i] = GetWorld()->SpawnActor<AChronicleProsecutor>();
	}
}

EQ6Judgement AQ6JudgementGameMode::JudgeChronicle(int32 InRequestId, const FString& QueryString, const FString& ChronicleJsonStr)
{
	AChronicleProsecutor** FreeProsecutor = Prosecutors.FindByPredicate([](const AChronicleProsecutor* InProsecutor) {
		return !(InProsecutor->IsInvestigating());
	});

	if (!FreeProsecutor)
	{
		Q6JsonLogNet(Error, "Prosecutor is not available. Hire more", Q6KV("CurrentProsecutorCount", MaxChronicleProsecutorsCount));
		return EQ6Judgement::InternalError;
	}

	return (*FreeProsecutor)->AcceptChronicle(InRequestId, QueryString, ChronicleJsonStr);
}