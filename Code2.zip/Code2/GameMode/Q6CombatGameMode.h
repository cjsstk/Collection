// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6GameMode.h"
#include "Q6GameState.h"
#include "Q6CombatGameMode.generated.h"

class ACombatCube;
class ACombatPresenter;
class UCombatGameResource;
class AChronicleProsecutor;
class AChronicleRunner;

struct FCCCombatSeed;
class UCCEvent;

UCLASS()
class Q6_API AQ6CombatGameMode : public AQ6GameModeBase
{
	GENERATED_BODY()
		
public:

	AQ6CombatGameMode(const FObjectInitializer& ObjectInitializer);

	virtual void StartPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;

	void SetGameDoubleSpeed(bool bInDoubleSpeed);
	void AddSpeed(int32 InSource, EQ6GameSpeed InSpeed);
	void RevertSpeed(int32 InSource);

	void StartCombatCube();
public:

	UFUNCTION(BlueprintCallable)
	UCombatGameResource* GetCombatGameResource() const { return CombatGameResource; }

	UFUNCTION(BlueprintCallable)
	FCCCombatSeed MakeCombatSeed(int32 Episode, int32 Stage, int32 SubStage, const TArray<FCCCombatSeedUnit>& Units, const TArray<FCCCombatSeedUnit>& SubUnits, const TArray<int32>& ArtifactLevels, const FPetType& PetType, const TArray<int32>& PetSkillLevels, const FCombatMultiSideInfo& CombatMultiSideInfo) const;

	TArray<UCCEvent*> ParseLobbyCCEvents(const FString& Msg);

private:
	void StartActInternal();
	void SetInternalGameSpeed();

#if !UE_BUILD_SHIPPING
	void RegisterCheatCommands();
	void UnRegisterCheatCommands();
	void ToggleDebugWidget();

	IConsoleObject* CheatObject;
#endif // !UE_BUILD_SHIPPING

public:
	UPROPERTY(BlueprintReadOnly)
	ACombatCube* CombatCube;

	UPROPERTY(BlueprintReadOnly)
	ACombatPresenter* Presenter;

private:
	UPROPERTY(Transient)
	UCombatGameResource* CombatGameResource;

	UPROPERTY(Transient)
	AChronicleRunner* ChronicleRunner;

	UPROPERTY(Transient)
	bool bDoubleSpeed;

	UPROPERTY(Transient)
	EQ6GameSpeed CurrentSpeed;

	UPROPERTY(Transient)
	TArray<int32> SpeedRequester;
};

UCLASS()
class Q6_API AQ6JudgementGameMode : public AQ6GameModeBase
{
	GENERATED_BODY()

public:
	virtual void StartPlay() override;

	EQ6Judgement JudgeChronicle(int32 InRequestId, const FString& QueryString, const FString& ChronicleJsonStr);

public:
	UPROPERTY(BlueprintReadOnly)
	TArray<AChronicleProsecutor*> Prosecutors;
};