// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6GameMode.h"
#include "Q6GameInstance.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6SoundPlayer.h"
#include "GameResource.h"

void AQ6GameModeBase::OnConstruction(const FTransform& Transform)
{
#if USE_PATCH
	GetGameModule()->LoadResource();
	UQ6GameInstance::Get()->InitializeSoundPlayer();
#endif

	Super::OnConstruction(Transform);
}

void AQ6LoginGameMode::StartPlay()
{
	Super::StartPlay();

	GetSoundPlayer().PlayMainBGM(TEXT("Login"));
	GetGameResource().BeginUIClassAsyncLoading();

	GetInitializedFirebaseAnalytics();
}

void AQ6LobbyGameMode::StartPlay()
{
	// Make sure level streaming is up to date before triggering NotifyMatchStarted
	GEngine->BlockTillLevelStreamingCompleted(GetWorld());
	GetGameResource().WaitUIClassAsyncLoadingComplete();

	Super::StartPlay();

	GetSoundPlayer().RegisterVoiceComponentToWorld();
	GetSoundPlayer().PlayMainBGM(TEXT("Lobby"));
}

void AQ6LobbyGameMode::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	GetSoundPlayer().UnRegisterVoiceComponent();

	Super::EndPlay(EndPlayReason);
}
