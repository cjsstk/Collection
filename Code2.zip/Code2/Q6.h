// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#define USE_PATCH 0

#include "Q6Minimal.h"
#include "Engine.h"
#include "GameFramework/PlayerController.h"

DECLARE_STATS_GROUP(TEXT("Q6"), STATGROUP_Q6, STATCAT_Advanced);

class UGameResource;
class UUIResource;
class UUIClassResource;
class USoundResource;
class UCMS;
class UQ6SoundPlayer;
class UCharacterVoiceHelper;
class UWorldUser;
class UHUDStore;
class UCombatGameResource;
class UQ6SaveGame;

class ABaseHUD;
class ACombatHUD;
class AQ6CombatGameMode;
class AQ6SummonGameMode;
class ACombatCube;
class ACombatPresenter;
class ACombatPlayerController;
class ALobbyHUD;
class ALobbyPlayerController;
class ASummonHUD;
class ALobbyTutorial;
class ACombatTutorial;
class ABaseTutorial;
/**
* Q6 Game Module
* Where everything starts to happen
*/

class FQ6GameModuleImpl : public FDefaultGameModuleImpl
{
public:
	FQ6GameModuleImpl();

	static FQ6GameModuleImpl* Get() { return Singleton; }

	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	void LoadResource();

	UGameResource& GetGameResource() const;
	UGameResource* GetGameResourcePtr() const;
	UCMS* GetCMS() const;
	bool IsCMSLoaded() const { return CMS != nullptr; }

	class FQ6Patch& GetPatch() const { check(Patch); return *Patch; }

private:
	UGameResource* GameResource;
	UCMS* CMS;

	static FQ6GameModuleImpl* Singleton;

	class FQ6Patch* Patch;
};


FQ6GameModuleImpl* GetGameModule();

APlayerController* GetLocalPlayerController(const UObject* Object);
ALobbyPlayerController* GetLobbyPlayerController(const UObject* Object);
ACombatPlayerController* GetCombatPlayerController(const UObject* Object);

ABaseHUD* GetBaseHUD(const UObject* Object);
/**
* Combat GameMode Functions
*/
ACombatHUD* GetCombatHUD(const UObject* Object);
ACombatHUD* GetCheckedCombatHUD(const UObject* Object);

AQ6CombatGameMode* GetCombatGameMode(const UObject* Object);
AQ6SummonGameMode* GetSummonGameMode(const UObject* Object);

ACombatCube* GetCheckedCombatCube(const UObject* Object);
ACombatPresenter* GetCheckedCombatPresenter(const UObject* Object);
UCombatGameResource* GetCombatGameResource(const UObject* Object);
UCombatGameResource& GetCheckedCombatGameResource(const UObject* Object);

/**
* Lobby GameMode Functions
*/
ALobbyHUD* GetLobbyHUD(const UObject* Object);
ALobbyHUD* GetCheckedLobbyHUD(const UObject* Object);

ALobbyTutorial* GetLobbyTutorial(const UObject* InObject);
ACombatTutorial* GetCombatTutorial(const UObject* InObject);
ABaseTutorial* GetBaseTutorial(const UObject* InObject);

UQ6SaveGame* GetQ6SaveGame();

/**
* Summon GameMode Functions
*/
ASummonHUD* GetSummonHUD(const UObject* Object);
ASummonHUD* GetCheckedSummonHUD(const UObject* Object);

/**
* Resource Functions
*/

UCMS* GetCMS();
UGameResource& GetGameResource();
UGameResource* GetGameResourcePtr();
UUIResource& GetUIResource();
UUIClassResource& GetUIClassResource();
USoundResource& GetGameSoundResource();

/**
* GameInstance Dependency Functions
*/
UQ6SoundPlayer& GetSoundPlayer();
UCharacterVoiceHelper* GetCharacterVoiceHelper();

const UWorldUser& GetUser();
UHUDStore& GetHUDStore();

/**
* Other Functions
*/
template<typename T>
static T* GetRandomElement(TArray<T*>& InArray)
{
	if (!InArray.Num())
	{
		return nullptr;
	}

	int32 RandomIndex = FMath::RandRange(0, InArray.Num() - 1);
	return InArray[RandomIndex];
}
