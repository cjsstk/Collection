// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "GameFramework/SaveGame.h"
#include "CMS_gen.h"
#include "Q6GameState.h"

#include "Q6SaveGame.generated.h"

struct FRewardStep;

enum class ELobbyTutorial : uint8;

USTRUCT()
struct FDialogueRecord
{
	GENERATED_USTRUCT_BODY()

	FDialogueRecord()
		: DialogueType(EDialogueType::None)
		, SagaType(SagaTypeInvalid)
		, DayOfWeek(EDayOfWeekType::Max)
		, TrainingCenterType(TrainingCenterTypeInvalid)
		, TrainingExpireTime(0)
		, EventContentType(EventContentTypeInvalid)
		, bPrologue(false)
	{}

	FDialogueRecord(
		EDialogueType InDialogueType,
		FSagaType InSagaType,
		EDayOfWeekType InDayOfWeek,
		FTrainingCenterType InTrainingCenterType,
		int32 InTrainingExpireTime,
		FEventContentType InEventContentType,
		bool bInPrologue
	)	: DialogueType(InDialogueType)
		, SagaType(InSagaType)
		, DayOfWeek(InDayOfWeek)
		, TrainingCenterType(InTrainingCenterType)
		, TrainingExpireTime(InTrainingExpireTime)
		, EventContentType(InEventContentType)
		, bPrologue(bInPrologue)
	{
	}

	void Reset()
	{
		DialogueType = EDialogueType::None;
		SagaType = SagaTypeInvalid;
		DayOfWeek = EDayOfWeekType::Max;
		TrainingCenterType = TrainingCenterTypeInvalid;
		TrainingExpireTime = 0;
		EventContentType = EventContentTypeInvalid;
		bPrologue = false;
	}

	bool IsDialogueContinue() const
	{
		return DialogueType != EDialogueType::None;
	}

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	EDialogueType DialogueType;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FSagaType SagaType;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	EDayOfWeekType DayOfWeek;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FTrainingCenterType TrainingCenterType;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	int32 TrainingExpireTime;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FEventContentType EventContentType;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	bool bPrologue;
};

USTRUCT()
struct FRewardRecord
{
	GENERATED_USTRUCT_BODY()

	FRewardRecord()
	{
		SagaType = SagaTypeInvalid;
		RewardSteps = TArray<FRewardStep>();
	}

	FRewardRecord(
		FSagaType InSagaType,
		const TArray<FRewardStep>& InRewardSteps,
		const TArray<FRewardInfo>& InRewardInfos,
		const TArray<FBondLevelUpReward>& InBondRewards)
		: SagaType(InSagaType)
		, RewardSteps(InRewardSteps)
		, RewardInfos(InRewardInfos)
		, BondRewards(InBondRewards)
	{}

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FSagaType SagaType;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	TArray<FRewardStep> RewardSteps;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	TArray<FRewardInfo> RewardInfos;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	TArray<FBondLevelUpReward> BondRewards;
};

UCLASS()
class Q6_API UQ6SaveGame : public USaveGame
{
	GENERATED_BODY()

public:
	UQ6SaveGame();

	void SetUserId(const FString& InUserId);

	bool IsDialogueAutoPlay() const { return bDialogueAutoPlay; }
	bool IsCombatSkillQuickUse() const { return bCombatSkillQuickUse; }
	bool IsCombatDoubleSpeed() const { return bCombatDoubleSpeed; }

	bool IsFirstBossStage(int32 SagaType) const;
	void AddUniqueBossStage(int32 SagaType);

	bool IsFirstDailyDungeonOnToday() const;
	void UpdateDailyDungeonDate();

	bool IsFirstUltimateSequenceOnToday(int32 ModelType, bool bEnemy);
	void UpdateUltimateSequenceDate(int32 ModelType, bool bEnemy);
	void ClearUltimateSequenceDates();

	const FDialogueRecord& GetDialogueRecord() const { return DialogueRecord; }
	void UpdateDialogueRecord(const FDialogueRecord& InDialogueRecord);
	void ClearDialogueRecord();

	FRaidId GetRaidId() const { return RaidId; }
	void UpdateRaidId(const FRaidId& InRaidId);

	void AddLobbyTutorialDone(ELobbyTutorial InDone);
	bool IsLobbyTutorialDone(ELobbyTutorial InTutorial) const;

	void SetSavedPartySlot(int32 InSlot);
	int32 GetSavedPartySlot() const { return SavedPartySlot; }

	const TArray<int32>& GetBanIndices() const;
	void UpdateBanIndices(const TArray<int32>& InBanIndices);
	void ClearBanIndices();

	void SaveMultisidePartyInfo(const FPartyInfo& InPartyInfo);
	void SaveMultisidePartyPet(FPetId InPetId);
	void ResetMultisidePartyInfo();

	void SetDialogueAutoPlay(bool bAutoPlay);
	void SetCombatSkillQuickUse(bool bQuickUse);
	void SetCombatDoubleSpeed(bool bDoubleSpeed);

	void SetLatestFriendBookFeed(const FFriendBookFeedId& InLatestFeedId);
	void SetReadFriendBookFeeds();
	const FFriendBookFeedId& GetLatestFriendBookFeed() { return LatestFriendBookFeedId; }
	const FFriendBookFeedId& GetReadFriendBookFeed() { return ReadFriendBookFeedId; }

	const FPartyInfo& GetMultisidePartyInfo() const { return MultisidePartyInfo; }

	void InitRewardRecord(const FRewardRecord& RewardRecord, bool bSave);
	bool HeapPopRewardStep(FRewardStep& RewardStep);
	const FRewardRecord& GetRewardRecord() const { return RewardRecord; }

private:
	void Save();

	UPROPERTY(VisibleAnywhere, Category = Basic)
	FString UserId;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FDateTime LastDailyDate;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	TArray<int32> BossStages;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FRaidId RaidId;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	int32 SavedPartySlot;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FPartyInfo MultisidePartyInfo;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FDialogueRecord DialogueRecord;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	TArray<int32> BanIndices;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FRewardRecord RewardRecord;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	TMap<int32, FDateTime> AllyUltimates;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	TMap<int32, FDateTime> EnemyUltimates;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FFriendBookFeedId LatestFriendBookFeedId;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	FFriendBookFeedId ReadFriendBookFeedId;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	bool bDialogueAutoPlay;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	bool bCombatSkillQuickUse;

	UPROPERTY(VisibleAnywhere, Category = "SaveData")
	bool bCombatDoubleSpeed;
};
