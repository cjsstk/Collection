// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Engine/SceneCapture2D.h"
#include "Engine/TextureRenderTarget2D.h"
#include "GameFramework/Actor.h"
#include "Q6Minimal.h"
#include "Q6Capture2D.generated.h"

DECLARE_MULTICAST_DELEGATE_OneParam(FCaptureVisibilityChange, UWorld*);
class USkeletalMeshComponent;
class UMaterialInterface;
class UTextureRenderTarget2D;
class UTextRenderComponent;
class UQ6DirectionalLightComponent;

UCLASS(ShowCategories = (Actor))
class Q6_API AQ6Capture2D : public ASceneCapture2D
{
	GENERATED_BODY()

	/** The main skeletal mesh associated with this Character (optional sub-object). */
	UPROPERTY(EditAnywhere, Category = SceneCapture)
	USkeletalMeshComponent* Mesh;

	UPROPERTY(EditAnywhere, Category = SceneCapture)
	UQ6DirectionalLightComponent* Light;

	UPROPERTY(EditAnywhere, Category = SceneCapture)
	UMaterialInterface* UIMasterMaterial;

	UPROPERTY(EditAnywhere, Category = SceneCapture)
	TEnumAsByte<enum ETextureRenderTargetFormat> RenderTargetFormat = RTF_RGBA16f;

	UPROPERTY(EditAnywhere, Category = SceneCapture)
	FIntPoint TextureSize = FIntPoint(256,256);

	UPROPERTY(Transient)
	UMaterialInstanceDynamic* MID;

	UPROPERTY(Transient)
	UTextureRenderTarget2D* RenderTarget;

#if WITH_EDITORONLY_DATA
	UPROPERTY(Transient)
	UTextRenderComponent* TextRender;
#endif
public:
	AQ6Capture2D(const FObjectInitializer& ObjectInitializer);

#if WITH_EDITOR
	virtual void PostLoad() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
#endif

	USkeletalMeshComponent* GetMesh() const { return Mesh; };
	UMaterialInterface* GetMID();
	UTextureRenderTarget2D* GetRenderTarget();
};