// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6Capture2D.h"
#include "Engine.h"
#include "Q6.h"
#include "Camera/CameraComponent.h"
#include "Components/SceneCaptureComponent2D.h"
#include "Components/Q6DirectionalLightComponent.h"

#define LOCTEXT_NAMESPACE "AQ6Capture2D"

AQ6Capture2D::AQ6Capture2D(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	Mesh = CreateOptionalDefaultSubobject<USkeletalMeshComponent>(TEXT("Capture Mesh"));
	Mesh->SetupAttachment(RootComponent);
	Mesh->SetEnableGravity(false);
	Mesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	Mesh->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPose;
	Mesh->bCastDynamicShadow = true;
	Mesh->SetMaterialParameterExistOnly(true);
	Mesh->LightingChannels.bChannel0 = 0;
	Mesh->LightingChannels.bChannel1 = 1;
	Mesh->LightingChannels.bChannel2 = 0;

	Light = CreateOptionalDefaultSubobject<UQ6DirectionalLightComponent>(TEXT("Q6DirectionalLight"));
	Light->SetupAttachment(RootComponent);
	Light->LightingChannels.bChannel0 = 0;
	Light->LightingChannels.bChannel1 = 1;
	Light->LightingChannels.bChannel2 = 0;

#if WITH_EDITORONLY_DATA
	if (!IsRunningCommandlet())
	{
		TextRender = ObjectInitializer.CreateEditorOnlyDefaultSubobject<UTextRenderComponent>(this, TEXT("TextComponent"));

		if (TextRender)
		{
			TextRender->SetupAttachment(RootComponent);
			TextRender->XScale = 5;
			TextRender->YScale = 5;
			TextRender->SetText(FText(LOCTEXT("Q6 Capture", "Q6 Capture")));
			TextRender->SetHiddenInGame(true);
		}
	}
#endif // WITH_EDITORONLY_DATA
}

UTextureRenderTarget2D* AQ6Capture2D::GetRenderTarget()
{
	if (!RenderTarget)
	{
		RenderTarget = NewObject<UTextureRenderTarget2D>();
		check(RenderTarget);
		RenderTarget->ClearColor = FLinearColor(0.0f, 0.0f, 0.0f, 0.0f);
		RenderTarget->AddressX = TA_Clamp;
		RenderTarget->AddressY = TA_Clamp;
		RenderTarget->bAutoGenerateMips = false;
		EPixelFormat PF = GetPixelFormatFromRenderTargetFormat(RenderTargetFormat.GetValue());
		RenderTarget->InitCustomFormat(TextureSize.X, TextureSize.Y, PF, false);
		GetCaptureComponent2D()->TextureTarget = RenderTarget;
	}

	return RenderTarget;
}

UMaterialInterface* AQ6Capture2D::GetMID()
{
	if (!MID && UIMasterMaterial)
	{
		MID = UMaterialInstanceDynamic::Create(UIMasterMaterial, GetTransientPackage());
		MID->SetTextureParameterValue(TEXT("RenderTarget"), GetRenderTarget());
	}

	return MID;
}

#if WITH_EDITOR
void AQ6Capture2D::PostLoad()
{
	Super::PostLoad();
}

void AQ6Capture2D::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	Super::PostEditChangeProperty(PropertyChangedEvent);

	if (!GetWorld())
	{
		// looks like changing default, not instance
		return;
	}
}

#endif // WITH_EDITOR

#undef LOCTEXT_NAMESPACE