﻿// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6GameInstance.h"

#include "AvatarManager.h"
#include "BagItemManager.h"
#include "BondManager.h"
#include "CharacterManager.h"
#include "CharacterVoiceHelper.h"
#include "CheckInManager.h"
#include "Chronicle/Chronicle.h"
#include "CMS_gen.h"
#include "CombatCube.h"
#include "CombatCube/CCEvent.h"
#include "CombatHUD.h"
#include "DialoguePlayer.h"
#include "Engine/World.h"
#include "ErrText.h"
#include "FriendManager.h"
#include "GameMode/Q6CombatGameMode.h"
#include "HAL/FileManager.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "JokerSetManager.h"
#include "Kismet/GameplayStatics.h"
#include "LobbyHUD.h"
#include "MoviePlayer.h"
#include "PartyManager.h"
#include "PetManager.h"
#include "PowerPlantManager.h"
#include "PyramidManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameUserSettings.h"
#include "Q6Log.h"
#include "Q6Timer.h"
#include "Q6Util.h"
#include "Q6SoundPlayer.h"
#include "RaidManager.h"
#include "RelicManager.h"
#include "SagaManager.h"
#include "SculptureManager.h"
#include "SummonManager.h"
#include "SpecialManager.h"
#include "ActRecordManager.h"
#include "CodexManager.h"
#include "WeeklyMissionManager.h"
#include "CharMissionManager.h"
#include "EventMissionManager.h"
#include "TempleManager.h"
#include "Tickable.h"
#include "TrainingCenterManager.h"
#include "Utils/LevelUtil.h"
#include "Utils/WidgetUtil.h"
#include "VacationManager.h"
#include "Widget/CombatWidgets.h"
#include "Widget/LoadingScreenWidget.h"
#include "DailyDungeonManager.h"
#include "Q6SaveGame.h"
#include "MailManager.h"
#include "ShopManager.h"
#include "LobbyTemplateManager.h"
#include "LobbySetManager.h"
#include "TitleManager.h"
#include "ContentFeatureOpenManager.h"
#include "HUDStore/EventManager.h"
#include "SmelterManager.h"
#include "AlchemylabManager.h"

#if !UE_BUILD_SHIPPING
static const FString DevModeConsoleName = TEXT("q6.devMode");
static const FString ShowTutorialConsoleName = TEXT("q6.showTutorial");
static const FString ShowMultiSideBattleRankScoreName = TEXT("q6.showMultiSideBattleRankScore");

TAutoConsoleVariable<int32> CVarQ6DevMode(
	*DevModeConsoleName,
	0,
	TEXT("0: off, 1: on"),
	ECVF_Default);

TAutoConsoleVariable<int32> CVarQ6ShowTutorial(
	*ShowTutorialConsoleName,
	1,
	TEXT("0: pass tutorials, 1: show tutorials"),
	ECVF_Default);

TAutoConsoleVariable<int32> CVarQ6ShowMultiSideBattleRankScore(
	*ShowMultiSideBattleRankScoreName,
	0,
	TEXT("0: hide, 1: show"),
	ECVF_Default);
#endif

class UPointWidget;
UQ6GameInstance* UQ6GameInstance::Singleton = nullptr;

class FQ6NetworkTick : FTickableGameObject
{
public:
	explicit FQ6NetworkTick(UQ6GameInstance* InGameInstance) :
		FTickableGameObject(),
		GameInstance(InGameInstance)
	{}

	virtual void Tick(float DeltaTime) override
	{
		if (GameInstance->HasClientNetwork())
		{
			FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
			ClientNetwork.Tick(DeltaTime);
			// obiwan todo GameInstance->GetSecureStore()->Tick(DeltaTime);

			static bool bFirstTick = true;

			if (bFirstTick)
			{
				UKismetSystemLibrary::ControlScreensaver(false);
				bFirstTick = false;
			}
		}

		if (GameInstance->HasServerNetwork())
		{
			FQ6ServerNetwork& ServerNetwork = GameInstance->GetServerNetwork();
			ServerNetwork.Tick(DeltaTime);
		}

		GameInstance->OnNetworkReady().ExecuteIfBound(GameInstance);
		GameInstance->OnNetworkReady().Unbind();
	}

	virtual bool IsTickable() const override
	{
		return true;
	}

	virtual bool IsTickableWhenPaused() const override
	{
		return true;
	}

	virtual bool IsTickableInEditor() const override
	{
		return false;
	}

	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FQ6NetworkTick, STATGROUP_Tickables);
	}

private:
	UQ6GameInstance * GameInstance;
};

class FQ6TimerTick : FTickableGameObject
{
public:
	explicit FQ6TimerTick(UQ6GameInstance* InGameInstance) :
		FTickableGameObject(),
		GameInstance(InGameInstance)
	{}

	virtual void Tick(float DeltaTime) override
	{
		if (GameInstance->HasQ6TimerManager())
		{
			FQ6TimerManager& Mgr = GameInstance->GetQ6TimerManager();
			Mgr.Tick(DeltaTime);
		}

		{
			FScopeLock ScopedLock(&OnTickOnetimeCriticalSection);
			OnTickOnetime.Broadcast();
			OnTickOnetime.Clear();
		}
	}

	virtual bool IsTickable() const override
	{
		return true;
	}

	virtual bool IsTickableWhenPaused() const override
	{
		return true;
	}

	virtual bool IsTickableInEditor() const override
	{
		return false;
	}

	virtual TStatId GetStatId() const override
	{
		RETURN_QUICK_DECLARE_CYCLE_STAT(FQ6TimerTick, STATGROUP_Tickables);
	}

	template <typename DelegateType>
	FDelegateHandle AddOnTickOnetime(const DelegateType& InNewDelegate)
	{
		FScopeLock ScopedLock(&OnTickOnetimeCriticalSection);
		return OnTickOnetime.Add(InNewDelegate);
	}

private:
	UQ6GameInstance* GameInstance;

	// One-time broadcaster (thread safe)
	// use to make 'Game-Thread call' from other threads
	FOnQ6TimerTick OnTickOnetime;
	FCriticalSection OnTickOnetimeCriticalSection;
};

UQ6GameInstance::UQ6GameInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bActivated(true)
	, bLogin(false)
	, bEnteredLobby(false)
	, bForeground(true)
	, bPSOCacheLoading(false)
	, noAuthCC(false)
	, CurrentContent(EGameContent::None)
	, ClientNetwork(nullptr)
	, ServerNetwork(nullptr)
	, NetworkTick(nullptr)
	, Q6TimerManager(nullptr)
	, Q6TimerTick(nullptr)
	, bFirstLoading(true)
	, bFirstShowLobby(true)
	, ZoneAttribute(EZoneAttribute::Ground)
	, LastWattUpdateTime(0.0)
{
	OnGoingCCStateStr.Empty();
}

void UQ6GameInstance::Init()
{
	Super::Init();

	UQ6GameInstance::Singleton = this;

	FModuleManager::LoadModuleChecked<class FSslModule>("SSL");

	HUDStore = nullptr;
	SoundPlayer = nullptr;
	ClientNetwork = nullptr;
	ServerNetwork = nullptr;
	NetworkTick = nullptr;

	bFirstLoading = true;
	bFirstShowLobby = true;

	bLogin = false;
	bEnteredLobby = false;

	CurrentContent = EGameContent::None;
	CancelReserveTutorialOnInit();
#if !UE_BUILD_SHIPPING
	Cheater.Init(this);
#endif

	HUDStore = NewObject<UHUDStore>();

	FCoreUObjectDelegates::PreLoadMap.AddUObject(this, &UQ6GameInstance::BeginLoadingScreen);
	FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UQ6GameInstance::EndLoadingScreen);

	FCoreDelegates::ApplicationWillDeactivateDelegate.AddUObject(this, &UQ6GameInstance::OnDeactivate);
	FCoreDelegates::ApplicationHasReactivatedDelegate.AddUObject(this, &UQ6GameInstance::OnReactivate);
	FCoreDelegates::ApplicationWillEnterBackgroundDelegate.AddUObject(this, &UQ6GameInstance::OnEnterBackground);
	FCoreDelegates::ApplicationHasEnteredForegroundDelegate.AddUObject(this, &UQ6GameInstance::OnEnterForeground);

	FShaderPipelineCache::GetPrecompilationCompleteDelegate().AddUObject(this, &UQ6GameInstance::OnShaderPipelineCachePrecompilationComplete);
}

FQ6TimerManager& UQ6GameInstance::GetQ6TimerManager() const
{
	check(Q6TimerManager);
	return *Q6TimerManager;
}

void UQ6GameInstance::Shutdown()
{
	Super::Shutdown();

	UQ6GameInstance::Singleton = nullptr;
#if !UE_BUILD_SHIPPING
	Cheater.Shutdown();
#endif

	if (NetworkTick)
	{
		delete NetworkTick;
		NetworkTick = nullptr;
	}

	if (ClientNetwork)
	{
		delete ClientNetwork;
		ClientNetwork = nullptr;
	}

	if (ServerNetwork)
	{
		ServerNetwork->Stop();
		delete ServerNetwork;
		ServerNetwork = nullptr;
	}

	if (Q6TimerTick)
	{
		delete Q6TimerTick;
		Q6TimerTick = nullptr;
	}

	if (Q6TimerManager)
	{
		delete Q6TimerManager;
		Q6TimerManager = nullptr;
	}

	if (SoundPlayer)
	{
		SoundPlayer->Shutdown();
		SoundPlayer = nullptr;
	}

	if (HUDStore)
	{
		HUDStore->Shutdown();
		HUDStore = nullptr;
	}
}

void UQ6GameInstance::StartGameInstance()
{
	InitializeQ6TimerManager();
	InitializeUserSettings();

#if !USE_PATCH
	InitializeSoundPlayer();
#endif

	Super::StartGameInstance();

	InitNetwork();
	InitHUDStore();
}

#if WITH_EDITOR
FGameInstancePIEResult UQ6GameInstance::StartPlayInEditorGameInstance(ULocalPlayer* LocalPlayer, const FGameInstancePIEParameters& Params)
{
	InitializeQ6TimerManager();
	InitializeUserSettings();
	InitializeSoundPlayer();

	FGameInstancePIEResult Result = Super::StartPlayInEditorGameInstance(LocalPlayer, Params);

	InitNetwork();
	InitHUDStore();

	return Result;
}
#endif

void UQ6GameInstance::InitializeUserSettings()
{
	UQ6GameUserSettings::Get()->InitSettings();
}

void UQ6GameInstance::InitializeQ6TimerManager()
{
	Q6TimerManager = new FQ6TimerManager(this);

	ensure(Q6TimerTick == nullptr);
	Q6TimerTick = new FQ6TimerTick(this);

}

void UQ6GameInstance::BeginLoadingScreen(const FString& Map)
{
	if (IsRunningDedicatedServer())
	{
		return;
	}

	APlayerController* LocalPlayerController = GetLocalPlayerController(this);
	if (LocalPlayerController)
	{
		ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(LocalPlayerController->Player);
		if (LocalPlayer)
		{
			if (LocalPlayer->ViewportClient)
			{
				LocalPlayer->ViewportClient->SetIgnoreInput(true);
			}
		}
	}

	if (bFirstLoading)
	{
		bFirstLoading = false;
		return;
	}

	UGameResource* InGameResource = GetGameResourcePtr();

	if (!InGameResource)
	{
		// Look like game resource is not ready yet.
		// This can happen if this is Patch client and loading Patch Map now.
		// We don't need loading screen in that case, actually we don't have loading screen widget yet!
		return;
	}

	//// TEST: seems like loading screen crashes a lot...  and makes automation to stop by crash
	//if (FAutomationTestFramework::GetInstance().GetCurrentTest())
	//{
	//	return;
	//}

	Q6JsonLogZagal(Warning, "BeginLoadingScreen");

	bPSOCacheLoading = false;

	UUIResource& UIResource = InGameResource->GetUIResource();
	LoadingScreenUMGWidget = ::CreateWidget<ULoadingScreenWidget>(this, UIResource.LoadingScreenUMGWidget.LoadSynchronous());
	LoadingScreenUMGWidget->SetTipText(InGameResource->GetRandomLoadingScreenGameTipText());

	FLoadingScreenAttributes LoadingScreen;
	LoadingScreen.bAutoCompleteWhenLoadingCompletes = !bPSOCacheLoading; // -V547
	LoadingScreen.bWaitForManualStop = bPSOCacheLoading; // -V547
	LoadingScreen.bMoviesAreSkippable = false;
	LoadingScreen.WidgetLoadingScreen = LoadingScreenUMGWidget->TakeWidget();

	GetMoviePlayer()->SetupLoadingScreen(LoadingScreen);
}

void UQ6GameInstance::EndLoadingScreen(UWorld* LoadedWorld)
{
	Q6JsonLogZagal(Warning, "EndLoadingScreen");

	APlayerController* LocalPlayerController = GetLocalPlayerController(this);
	if (LocalPlayerController)
	{
		ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(LocalPlayerController->Player);
		if (LocalPlayer)
		{
			if (LocalPlayer->ViewportClient)
			{
				LocalPlayer->ViewportClient->SetIgnoreInput(false);
			}
		}
	}

	TSharedPtr<GenericApplication> PlatformApplication = FSlateApplication::Get().GetPlatformApplication();
	if (PlatformApplication.IsValid())
	{
		PlatformApplication->CleanDeferedInputs();
	}

	LoadingScreenUMGWidget = nullptr;
}

void UQ6GameInstance::OnDeactivate()
{
	bActivated = false;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(this);
	if (Q6BaseHUD)
	{
		Q6BaseHUD->OnDeactivate();
	}

//#if PLATFORM_IOS
//	if (GameUtilLibrary)
//	{
//		GameUtilLibrary->RestoreOriginalScreenBrightness();
//	}
//#endif
}

void UQ6GameInstance::OnReactivate()
{
	bActivated = true;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(this);
	if (Q6BaseHUD)
	{
		Q6BaseHUD->OnReactivate();
	}

//#if PLATFORM_IOS
//	if (GameUtilLibrary)
//	{
//		GameUtilLibrary->RestoreUserScreenBrightness();
//	}
//#endif
}

void UQ6GameInstance::OnEnterForeground()
{
	// WARN: this could be not in Game Thread

	bForeground = true;

	if (!ensure(Q6TimerTick))
	{
		return;
	}

	// Lets route to GameThread

	TWeakObjectPtr<UQ6GameInstance> GameInstancePtr(this);

	Q6TimerTick->AddOnTickOnetime(FOnQ6TimerTick::FDelegate::CreateLambda([GameInstancePtr] {
		if (!GameInstancePtr.IsValid())
		{
			return;
		}

		ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstancePtr.Get());
		if (Q6BaseHUD)
		{
			Q6BaseHUD->OnEnterForeground();
		}
	}));

//#if PLATFORM_IOS
//	if (GameUtilLibrary)
//	{
//		GameUtilLibrary->RestoreUserScreenBrightness();
//	}
//#endif
}

void UQ6GameInstance::OnEnterBackground()
{
	// WARN: this could be not in Game Thread

	bForeground = false;

	ABaseHUD* Q6BaseHUD = GetBaseHUD(this);
	if (Q6BaseHUD)
	{
		Q6BaseHUD->OnEnterBackground();
	}

//#if PLATFORM_IOS
//	if (GameUtilLibrary)
//	{
//		GameUtilLibrary->RestoreOriginalScreenBrightness();
//	}
//#endif
}

void UQ6GameInstance::InitNetwork()
{
	Q6JsonLogNet(Display, "Initialize Network");
#if UE_SERVER
	ServerNetwork = new FQ6ServerNetwork(this);
#else
	ClientNetwork = new FQ6ClientNetwork(this);
#endif
	ensure(NetworkTick == nullptr);
	NetworkTick = new FQ6NetworkTick(this);
	Q6JsonLogNet(Display, "Initialize Network.. done!");

	if (noAuthCC)
	{
		GetClientNetwork().Connect();
	}
}

void UQ6GameInstance::SetLogin(bool bInLogin)
{
	if (bLogin == bInLogin)
	{
		return;
	}

	bLogin = bInLogin;

	if (!bLogin)
	{
		bEnteredLobby = false;
	}

	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	if (GameInstance)
	{
		Q6SetUserNameToFirebaseCrashlytics(GetUser().GetAccountName());
	}
}

static TAutoConsoleVariable<float> CVarQ6ContentsReadyInterval(
	TEXT("q6.ContentsReadyInterval"),
	20.0f,
	TEXT("web socket retry interval for connecting dedid in seconds\n"),
	ECVF_Default);

void UQ6GameInstance::ReqNextContent()
{
	if (CurrentContent != EGameContent::Max)
	{
		ReqContent(EGameContent(uint8(CurrentContent) + 1));
	}
}

void UQ6GameInstance::ReqContent(EGameContent NextContent)
{
	CurrentContent = NextContent;

	switch (CurrentContent)
	{
		case EGameContent::Currency:
			GetHUDStore().GetWorldUser().ReqCurrencyLoad(); return;
		case EGameContent::Character:
			GetHUDStore().GetCharacterManager().ReqList(); return;
		case EGameContent::BagItem:
			GetHUDStore().GetBagItemManager().ReqList(); return;
		case EGameContent::Relic:
			GetHUDStore().GetRelicManager().ReqList(); return;
		case EGameContent::Sculpture:
			GetHUDStore().GetSculptureManager().ReqList(); return;
		case EGameContent::ActRecord:
			GetHUDStore().GetActRecordManager().ReqList(); return;
		case EGameContent::CodexChar:
			GetHUDStore().GetCodexManager().ReqListChar(); return;
		case EGameContent::CodexSculpture:
			GetHUDStore().GetCodexManager().ReqListSculpture(); return;
		case EGameContent::CodexRelic:
			GetHUDStore().GetCodexManager().ReqListRelic(); return;
		case EGameContent::WeeklyMission:
			GetHUDStore().GetWeeklyMissionManager().ReqLoad(); return;
		case EGameContent::CharMission:
			GetHUDStore().GetCharMissionManager().ReqList(); return;
		case EGameContent::EventMission:
			GetHUDStore().GetEventMissionManager().ReqList(); return;
		case EGameContent::Bond:
			GetHUDStore().GetBondManager().ReqLoad(); return;
		case EGameContent::Friend:
			GetHUDStore().GetFriendManager().ReqFriendList(); return;
		case EGameContent::FriendCooltime:
			GetHUDStore().GetFriendManager().ReqFriendCooltimeList(); return;
		case EGameContent::JokerSet:
			GetHUDStore().GetJokerManager().ReqJokerSetList(); return;
		case EGameContent::Party:
			GetHUDStore().GetPartyManager().ReqPartyList(); return;
		case EGameContent::Saga:
			GetHUDStore().GetSagaManager().ReqSagaHistory(); return;
		case EGameContent::Special:
			GetHUDStore().GetSpecialManager().ReqSpecialHistory(); return;
		case EGameContent::TrainingCenter:
			GetHUDStore().GetTrainingCenterManager().ReqTrainingCenterHistory(); return;
		case EGameContent::Daily:
			GetHUDStore().GetDailyDungeonManager().ReqDailyList(); return;
		case EGameContent::Pyramid:
			GetHUDStore().GetPyramidManager().ReqLoad(); return;
		case EGameContent::Temple:
			GetHUDStore().GetTempleManager().ReqLoad(); return;
		case EGameContent::PowerPlant:
			GetHUDStore().GetPowerPlantManager().ReqLoad(); return;
		case EGameContent::Pet:
			GetHUDStore().GetPetManager().ReqLoad(); return;
		case EGameContent::Vacation:
			GetHUDStore().GetVacationManager().ReqLoad(); return;
		case EGameContent::Smelter:
			GetHUDStore().GetSmelterManager().ReqLoad(); return;
		case EGameContent::Alchemylab:
			GetHUDStore().GetAlchemylabManager().ReqLoad(); return;
		case EGameContent::Raid:
			GetHUDStore().GetRaidManager().ReqList(); return;
		case EGameContent::Mail:
			GetHUDStore().GetMailManager().ReqList(); return;
		case EGameContent::Attendance:
			GetHUDStore().GetCheckInManager().ReqList(); return;
		case EGameContent::Shop:
			GetHUDStore().GetShopManager().ReqList(); return;
		case EGameContent::LobbyTemplate:
			GetHUDStore().GetLobbyTemplateManager().ReqList(); return;
		case EGameContent::LobbySet:
			GetHUDStore().GetLobbySetManager().ReqLobbySetLoad(); return;
		case EGameContent::Title:
			GetHUDStore().GetTitleManager().ReqList(); return;
		case EGameContent::ContentFeatureOpen:
			GetHUDStore().GetContentFeatureOpenManager().ReqList(); return;
		case EGameContent::Summon:
			GetHUDStore().GetSummonManager().ReqLoad(); return;
		case EGameContent::Event:
			GetHUDStore().GetEventManager().ReqEventContentList(); return;
		case EGameContent::Avatar:
			GetHUDStore().GetAvatarManager().ReqLoad(); return;
		default:
			ReqEnterLobbyFinal(); return;
	}
}

FSagaType UQ6GameInstance::FinalizeEnterLobby()
{
	FSagaType NotFinishedSagaType;
	bool bRestorableOnClient = LoadOngoingChronicleFile(&NotFinishedSagaType);

	if (!IsRestorableOnServer())
	{
		if (bRestorableOnClient)
		{
			RemoveOngoingChronicleFile();
		}

		return SagaTypeInvalid;
	}

	if (!bRestorableOnClient)
	{
		return SagaTypeInvalid;
	}

	return NotFinishedSagaType;
}

void UQ6GameInstance::ReqEnterLobbyFinal()
{
	FRaidId RaidId(FRaidId::InvalidValue());
	EContentType ContentType = EContentType::None;
	FSagaType SagaType = FinalizeEnterLobby();

	if (SagaType != SagaTypeInvalid)
	{
		ContentType = GetCMS()->GetSagaRowOrDummy(SagaType).ContentType;
	}

	if (ContentType == EContentType::Raid)
	{
		if (SaveGameInstance)
		{
			RaidId = SaveGameInstance->GetRaidId();
		}
	}
	else
	{
		if (SaveGameInstance)
		{
			SaveGameInstance->UpdateRaidId(FRaidId::InvalidValue());
		}
	}

	GetClientNetwork().ReqEnterLobbyFinal(SagaType, RaidId);
}

void UQ6GameInstance::ContentsReady()
{
	if (ContentsTimerHandle.IsValid())
	{
		GetTimerManager().ClearTimer(ContentsTimerHandle);
	}
}

void UQ6GameInstance::SetRaidId(const FRaidId& InRaidId)
{
	if (SaveGameInstance)
	{
		SaveGameInstance->UpdateRaidId(InRaidId);
	}
}

void UQ6GameInstance::SetSaga(const FSagaType& SagaType)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	CombatSeed.SagaType = SagaType;
	CombatSeed.Content = SagaRow.ContentType;
}

void UQ6GameInstance::SetCombatSeedPartyId(int32 PartyId)
{
	CombatSeed.PartyId = PartyId;
}

void UQ6GameInstance::SetCombatSeedBanIndices(const TArray<int32>& BanIndices)
{
	CombatSeed.BanIndices = BanIndices;
}

void UQ6GameInstance::SetSystemJoker(const FCharacterType& SystemJoker)
{
	JokerInfo.JokerType = EJokerType::SystemJoker;
	JokerInfo.SystemJoker = SystemJoker;
}

void UQ6GameInstance::SetFriendJoker(const FFriendInfo& FriendInfo, EJokerSlotType JokerSlot)
{
	JokerInfo.JokerType = EJokerType::FriendJoker;
	JokerInfo.FriendId = FriendInfo.FriendId;
	JokerInfo.CandidateUserId = FriendInfo.TargetUserId;
	JokerInfo.Slot = JokerSlot;
}

void UQ6GameInstance::SetRandomJoker(const FCharacterType& RandomJoker)
{
	JokerInfo.JokerType = EJokerType::RandomJoker;
	JokerInfo.SystemJoker = RandomJoker;
}

void UQ6GameInstance::SetOwnedJoker(const FPartySlot& JokerSlot)
{
	JokerInfo.JokerType = EJokerType::OwnedJoker;
	JokerInfo.OwnedSlot = JokerSlot;
}

void UQ6GameInstance::ClearJoker()
{
	JokerInfo.JokerType = (EJokerType)EJokerTypeMax;
}

const bool UQ6GameInstance::IsRestorableOnClient()
{
	FSagaType NotFinishedSagaType;
	return LoadOngoingChronicleFile(&NotFinishedSagaType);
}

void UQ6GameInstance::SetCombatSeedUnits(const TArray<FCCCombatSeedUnit>& Units, const TArray<FCCCombatSeedUnit>& SubUnits)
{
	CombatSeed.Units.Reset();
	CombatSeed.Units = Units;

	CombatSeed.SubUnits.Reset();
	CombatSeed.SubUnits = SubUnits;
}

void UQ6GameInstance::LoadSaveGame(const FString& UserId)
{
	SaveGameInstance = Cast<UQ6SaveGame>(UGameplayStatics::LoadGameFromSlot(UserId, 0));
	if (!SaveGameInstance)
	{
		SaveGameInstance = Cast<UQ6SaveGame>(UGameplayStatics::CreateSaveGameObject(UQ6SaveGame::StaticClass()));
		SaveGameInstance->SetUserId(UserId);
	}
}

void UQ6GameInstance::RequestBeginStage()
{
	if (!IsLogin())
	{
		Q6JsonLogNet(Error, "RequestBeginStage not logged in");
		return;
	}

	const UPartyManager& PartyMgr = GetHUDStore().GetPartyManager();
	if (CombatSeed.Content == EContentType::Saga)
	{
#if !UE_BUILD_SHIPPING
		if (IsDevMode() || PartyMgr.CanJokerEdit())
		{
			GetHUDStore().GetSagaManager().ReqDevStageBegin();
			return;
		}
#endif
		GetHUDStore().GetSagaManager().ReqStageBegin();
	}
	else if (CombatSeed.Content == EContentType::Special)
	{
#if !UE_BUILD_SHIPPING
		if (IsDevMode() || PartyMgr.CanJokerEdit())
		{
			GetHUDStore().GetSpecialManager().ReqDevStageBegin();
			return;
		}
#endif

		GetHUDStore().GetSpecialManager().ReqStageBegin();
	}
	else if (CombatSeed.Content == EContentType::DailyDungeon)
	{
#if !UE_BUILD_SHIPPING
		if (IsDevMode() || PartyMgr.CanJokerEdit())
		{
			GetHUDStore().GetDailyDungeonManager().ReqDevStageBegin();
			return;
		}
#endif
		GetHUDStore().GetDailyDungeonManager().ReqStageBegin();
	}
	else if (CombatSeed.Content == EContentType::TrainingCenter)
	{
#if !UE_BUILD_SHIPPING
		if (IsDevMode() || PartyMgr.CanJokerEdit())
		{
			GetHUDStore().GetTrainingCenterManager().ReqDevStageBegin();
			return;
		}
#endif
		GetHUDStore().GetTrainingCenterManager().ReqStageBegin();
	}
	else if (CombatSeed.Content == EContentType::Raid)
	{
#if !UE_BUILD_SHIPPING
		if (IsDevMode() || PartyMgr.CanJokerEdit())
		{
			GetHUDStore().GetRaidManager().ReqDevEnter();
		}
#endif
		GetHUDStore().GetRaidManager().ReqEnter();
	}
	else if (CombatSeed.Content == EContentType::RaidFinal)
	{
#if !UE_BUILD_SHIPPING
		if (IsDevMode() || PartyMgr.CanJokerEdit())
		{
			GetHUDStore().GetRaidManager().ReqDevRaidFinalStageBegin();
		}
#endif
		GetHUDStore().GetRaidManager().ReqRaidFinalStageBegin();
	}
	else if (CombatSeed.Content == EContentType::Event)
	{
#if !UE_BUILD_SHIPPING
		if (IsDevMode() || PartyMgr.CanJokerEdit())
		{
			GetHUDStore().GetEventManager().ReqDevEventContentValentineDayStageBegin();
		}
#endif
		GetHUDStore().GetEventManager().ReqEventContentValentineDayStageBegin();
	}
	else if (CombatSeed.Content == EContentType::MultiSideBattle)
	{
		GetHUDStore().GetEventManager().ReqEventContentMultiSideBattleStageBegin();
	}
}


void UQ6GameInstance::OnSagaStageBegin(const FL2CSagaStageBeginResp& Resp)
{
	ACTION_DISPATCH_SagaStageBeginResp(Resp);

	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::RequestEndStage(const UCCEndGameEvent* Event, const FCombatMissionInfo& CombatMissionInfo)
{
	AQ6CombatGameMode* InCombatGameMode = GetCombatGameMode(this);
	UCCCombatCubeStore* CombatCubeStore = nullptr;
	if (InCombatGameMode && InCombatGameMode->CombatCube)
	{
		CombatCubeStore = InCombatGameMode->CombatCube->GetStore();
	}

	if (!CombatCubeStore)
	{
		return;
	}

	FString ChronicleJson = CombatCubeStore->GetChronicleJson();

	if (CombatSeed.Content == EContentType::Saga)
	{
		GetHUDStore().GetSagaManager().ReqStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::Special)
	{
		GetHUDStore().GetSpecialManager().ReqStageEnd(Event, ChronicleJson);
	}
	else if (CombatSeed.Content == EContentType::DailyDungeon)
	{
		GetHUDStore().GetDailyDungeonManager().ReqStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::TrainingCenter)
	{
		GetHUDStore().GetTrainingCenterManager().ReqStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::Raid)
	{
		GetHUDStore().GetRaidManager().ReqStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::RaidFinal)
	{
		GetHUDStore().GetRaidManager().ReqRaidFinalStageEnd(Event, ChronicleJson);
	}
	else if (CombatSeed.Content == EContentType::Event)
	{
		GetHUDStore().GetEventManager().ReqEventContentValentineDayStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::MultiSideBattle)
	{
		const int32 FinalRankScore = CombatCubeStore->GetState().CombatMultiSideState.FinalRankScore;
		GetHUDStore().GetEventManager().ReqEventContentMultiSideBattleStageEnd(Event, ChronicleJson, CombatMissionInfo, FinalRankScore);
	}
}

void UQ6GameInstance::RequestQuitStage()
{
	AQ6CombatGameMode* InCombatGameMode = GetCombatGameMode(this);
	UCCCombatCubeStore* CombatCubeStore = nullptr;
	if (InCombatGameMode && InCombatGameMode->CombatCube)
	{
		CombatCubeStore = InCombatGameMode->CombatCube->GetStore();
	}

	if (!CombatCubeStore)
	{
		return;
	}

	FString ChronicleJson = CombatCubeStore->GetChronicleJson();

	// Tempcode.
	// Below codes gonna be incorporated in UQ6GameInstance::RequestEndStage by sending FCCEndGameAction
	UCCEndGameEvent* Event = NewObject<UCCEndGameEvent>();
	Event->Result = ECCResult::Lost;
	Event->EndReason = ECCEndReason::Eliminated;
	Event->ContentType = this->CombatSeed.Content;
	Event->TurnPhase = ECCTurnPhase::Prepare;
	// Dummy value
	Event->FinalTurnCount = 1;
	Event->GemWipeoutContinueCount = CombatCubeStore->GetState().GemWipeoutContinueCount;
	Event->BossHpRatio = 0;
	for (const FSeedArtifact& A : CombatCubeStore->GetState().CombatSeed.Seed.ArtifactAvailable)
	{
		Event->ArtifactAvailable.Push(A.Available);
	}

	FCombatMissionInfo CombatMissionInfo;

	if (CombatSeed.Content == EContentType::Saga)
	{
		GetHUDStore().GetSagaManager().ReqStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::Special)
	{
		GetHUDStore().GetSpecialManager().ReqStageEnd(Event, ChronicleJson);
	}
	else if (CombatSeed.Content == EContentType::DailyDungeon)
	{
		GetHUDStore().GetDailyDungeonManager().ReqStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::TrainingCenter)
	{
		GetHUDStore().GetTrainingCenterManager().ReqStageEnd(Event, ChronicleJson, CombatMissionInfo);
	}
	else if (CombatSeed.Content == EContentType::Raid)
	{
		CombatCubeStore->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::None));
	}
	else if (CombatSeed.Content == EContentType::RaidFinal)
	{
		GetHUDStore().GetRaidManager().ReqRaidFinalStageEnd(Event, ChronicleJson);
	}
}

void UQ6GameInstance::OnSagaStageEnd(const FL2CSagaStageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_SagaStageEndResp(Resp);
	}
	else
	{
		ACTION_DISPATCH_UpdateMission(Resp.Mission);
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);
		ACTION_DISPATCH_UpdateCurrency(Resp.CurrencyInfo);

		ACTION_DISPATCH_WeeklyMissionToast();
	}

	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::OnSpecialStageBegin(const FL2CSpecialStageBeginResp& Resp)
{
	ACTION_DISPATCH_SpecialStageBeginResp(Resp);

	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::RequestSagaStoryStage(FSagaType SagaType)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	switch (SagaRow.ContentType)
	{
		case EContentType::Saga:
		{
#if !UE_BUILD_SHIPPING
			if (IsDevMode())
			{
				GetHUDStore().GetSagaManager().ReqDevStoryStageClear(SagaRow.CmsType());
				break;
			}
#endif
			GetHUDStore().GetSagaManager().ReqStoryStageClear(SagaRow.CmsType());
			break;
		}
		case EContentType::Special:
			GetHUDStore().GetSpecialManager().ReqStoryStageClear(SagaRow.CmsType(), SagaRow.Episode, SagaRow.Stage);
			break;
		default:
			Q6JsonLogRoze(Warning, "UStageEntryWidget::ReqStoryStageClear - Current DialogueType does not have a StoryStage",
				Q6KV("ContentType", static_cast<int>(SagaRow.ContentType)));
			break;
	}
}

void UQ6GameInstance::StartSagaLevel(const FCombatSeed& Seed)
{
	CombatSeed.Seed = Seed;

	ULevelUtil::LoadSagaLevel(GetWorld(), CombatSeed.SagaType);
}

void UQ6GameInstance::OnShaderPipelineCachePrecompilationComplete(uint32 Count, double Seconds, const FShaderPipelineCache::FShaderCachePrecompileContext& ShaderCachePrecompileContext)
{
	Q6JsonLogZagal(Warning, "OnShaderPipelineCachePrecompilationComplete");

//#if USE_PATCH && PLATFORM_ANDROID
//	if (bPSOCacheLoading && !IsVulkanMobilePlatform(GMaxRHIShaderPlatform))
//	{
//		GetMoviePlayer()->StopMovie();
//	}
//#endif
}

void UQ6GameInstance::OnSpecialStageEnd(const FL2CSpecialStageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_SpecialStageEndResp(Resp);
	}
	else
	{
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);
		ACTION_DISPATCH_UpdateCurrency(Resp.CurrencyInfo);
	}
	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::OnDailyStageBegin(const FL2CDailyStageBeginResp& Resp)
{
	ACTION_DISPATCH_DailyStageBeginResp(Resp);

	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::OnBeginRaid(const FL2CRaidEnterNof& Nof)
{
	ACTION_DISPATCH_RaidEnterNof(Nof);

	StartSagaLevel(Nof.CombatSeed);
}

void UQ6GameInstance::OnDailyStageEnd(const FL2CDailyStageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_DailyStageEndResp(Resp);
	}
	else
	{
		ACTION_DISPATCH_UpdateMission(Resp.Mission);
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);
		ACTION_DISPATCH_UpdateCurrency(Resp.CurrencyInfo);

		ACTION_DISPATCH_WeeklyMissionToast();
	}
	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::OnTrainingCenterStageBegin(const FL2CTrainingCenterStageBeginResp& Resp)
{
	ACTION_DISPATCH_TrainingCenterStageBeginResp(Resp);

	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::OnTrainingCenterStageEnd(const FL2CTrainingCenterStageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_TrainingCenterStageEndResp(Resp);
	}
	else
	{
		ACTION_DISPATCH_UpdateMission(Resp.Mission);
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);

		ACTION_DISPATCH_WeeklyMissionToast();
	}
	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::OnRaidFinalStageBegin(const FL2CRaidFinalStageBeginResp& Resp)
{
	ACTION_DISPATCH_RaidFinalStageBeginResp(Resp);

	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::OnRaidFinalStageEnd(const FL2CRaidFinalStageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_RaidFinalStageEndResp(Resp);
	}
	else
	{
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);
		ACTION_DISPATCH_UpdateCurrency(Resp.CurrencyInfo);
	}
	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::OnEventContentCollabo01StageBegin(const FL2CEventContentCollabo01StageBeginResp& Resp)
{
	ACTION_DISPATCH_EventContentCollabo01StageBeginResp(Resp);

	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::OnEventContentCollabo01StageEnd(const FL2CEventContentCollabo01StageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_EventContentCollabo01StageEndResp(Resp);
	}
	else
	{
		ACTION_DISPATCH_UpdateMission(Resp.Mission);
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);
		ACTION_DISPATCH_UpdateCurrency(Resp.CurrencyInfo);

		ACTION_DISPATCH_WeeklyMissionToast();
	}

	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::OnEventContentValentineDayStageBegin(const FL2CEventContentValentineDayStageBeginResp& Resp)
{
	ACTION_DISPATCH_EventContentValentineDayStageBeginResp(Resp);

	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::OnEventContentValentineDayStageEnd(const FL2CEventContentValentineDayStageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_EventContentValentineDayStageEndResp(Resp);
	}
	else
	{
		ACTION_DISPATCH_UpdateMission(Resp.Mission);
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);
		ACTION_DISPATCH_UpdateCurrency(Resp.CurrencyInfo);

		ACTION_DISPATCH_WeeklyMissionToast();
	}

	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::OnEventContentMultiSideBattleStageBegin(const FL2CEventContentMultiSideBattleStageBeginResp& Resp)
{
	StartSagaLevel(Resp.CombatSeed);
}

void UQ6GameInstance::OnEventContentMultiSideBattleStageEnd(const FL2CEventContentMultiSideBattleStageEndResp& Resp)
{
	if (Resp.Ok)
	{
		ACTION_DISPATCH_EventContentMultiSideBattleStageEndResp(Resp);

		GetHUDStore().GetEventManager().ReqEventContentMultisideBattleRankLoad(Resp.EventContentInfo.Type);
	}
	else
	{
		ACTION_DISPATCH_UpdateMission(Resp.Mission);
		ACTION_DISPATCH_UpdateCharMission(Resp.CharMission);
		ACTION_DISPATCH_UpdateCurrency(Resp.CurrencyInfo);

		ACTION_DISPATCH_WeeklyMissionToast();
	}

	RemoveOngoingChronicleFile();
}

void UQ6GameInstance::HandleEnteredLobby(const FL2CAuthEnterLobbyResp& Resp)
{
	ABaseHUD* Q6BaseHUD = GetBaseHUD(this);
	check(Q6BaseHUD);

	// have local push?
	// ClearAllLocalNotification();

	SetRestorableOnServer(Resp.RestorableFlag);

	Q6BaseHUD->OnNetworkEnteredLobby(Resp);

	Q6JsonLogNet(Verbose, "OnEnterLobby",
		Q6KV("UserId", Resp.UserInfo.UserId),
		Q6KV("Level", Resp.UserInfo.Level),
		Q6KV("Xp", Resp.UserInfo.Xp));

	ACTION_DISPATCH_AuthEnterLobbyResp(Resp);

	FTimerDelegate TimerCallback;
	TimerCallback.BindLambda([=]
	{
		Q6JsonLogHekel(Warning, "Contents ready timeout, q6.ContentsReadyInterval",
			Q6KV("sec", CVarQ6ContentsReadyInterval.GetValueOnGameThread()));
		ContentsReady();
	});

	GetTimerManager().SetTimer(ContentsTimerHandle, TimerCallback,
		CVarQ6ContentsReadyInterval.GetValueOnGameThread(), false);

	// sync the server time
	LastWattUpdateTime = FPlatformTime::Seconds() - Resp.WattInfo.DiffTime;

	CurrentContent = EGameContent::None;
	ReqNextContent();
}

void UQ6GameInstance::HandleEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp)
{
	bEnteredLobby = true;

	OnGoingCCStateStr.Empty();
	OnGoingCCStateStr = Resp.CcStateStr;

	ContentsReady();

	ABaseHUD* Q6BaseHUD = GetBaseHUD(this);
	check(Q6BaseHUD);
	Q6BaseHUD->OnNetworkEnteredLobbyFinal(Resp);
}

EQ6Judgement UQ6GameInstance::JudgeChronicle(int32 InRequestId, const FString& QueryString, const FString& ChronicleJSonStr)
{
	AQ6JudgementGameMode* JudgementGameMode = Cast<AQ6JudgementGameMode>(GetWorld()->GetAuthGameMode());
	if (!JudgementGameMode)
	{
		Q6JsonLogNet(Error, "Have to JudgementGameMode");
		return EQ6Judgement::InternalError;
	}

	return JudgementGameMode->JudgeChronicle(InRequestId, QueryString, ChronicleJSonStr);
}

void UQ6GameInstance::CompleteJudgeChronicle(int32 InRequestId, EQ6Judgement InJudgement)
{
	JudgementDelegate.ExecuteIfBound(InRequestId, InJudgement);
}

FString UQ6GameInstance::GetOngoingChronicleFilePath()
{
	if (IsLogin())
	{
		const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
		return FPaths::ProjectSavedDir() / "Chronicles" / WorldUser.GetUserCode() + "_Ongoing.json";
	}
	else
	{
		return FPaths::ProjectSavedDir() / "Chronicles/OfflineUser_Ongoing.json";
	}
}

const FString UQ6GameInstance::GetDialoguePlayingFilePath()
{
	if (IsLogin())
	{
		const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
		return FPaths::ProjectSavedDir() / "DialogueRecords" / WorldUser.GetUserCode() + "_Record.dat";
	}
	else
	{
		return FPaths::ProjectSavedDir() / "DialogueRecords/OfflineUser_Record.json";
	}
}

void UQ6GameInstance::RemoveOngoingChronicleFile()
{
	FString RemoveFilePath = GetOngoingChronicleFilePath();
	IFileManager::Get().Delete(*RemoveFilePath, false, true, true);
	OngoingChronicle.Empty();

	OnGoingCCStateStr.Empty();
}

void UQ6GameInstance::SaveOngoingChronicleFile(FString InJSonString)
{
	FString OutputFilePath = GetOngoingChronicleFilePath();
	if (!FFileHelper::SaveStringToFile(InJSonString, *OutputFilePath))
	{
		Q6JsonLogBro(Error, "Failed to save output file", Q6KV("OutputFilePath", *OutputFilePath));
	}
	OngoingChronicle = InJSonString;
}

bool UQ6GameInstance::LoadOngoingChronicleFile(FSagaType* OutSagaType)
{
	FString ReadFilePath = GetOngoingChronicleFilePath();
	FString InJsonStr;
	if (!FFileHelper::LoadFileToString(InJsonStr, *ReadFilePath))
	{
		return false;
	}

	OngoingChronicle = InJsonStr;
	UChronicleLoader* ChronicleLoader = NewObject<UChronicleLoader>(this);
	FSagaType UnFinishedSagaType = ChronicleLoader->GetSagaTypeFromChronicle(OngoingChronicle);
	(*OutSagaType) = UnFinishedSagaType;
	return UnFinishedSagaType != SagaTypeInvalid;
}

void UQ6GameInstance::InitializeSoundPlayer()
{
#if !UE_SERVER
	if (SoundPlayer)
	{
		return;
	}

	if (!GetGameResourcePtr())
	{
		return;
	}

	SoundPlayer = NewObject<UQ6SoundPlayer>(this);
	SoundPlayer->Initialize();

	UQ6GameUserSettings::Get()->ApplySoundSettings();

	CharacterVoiceHelper = NewObject<UCharacterVoiceHelper>(this);
#endif
}

void UQ6GameInstance::InitHUDStore()
{
	HUDStore->Initialize(this);
	HUDStore->InitializeNetworkNotify();
}

void UQ6GameInstance::ResetHUDStore()
{
	if (HUDStore)
	{
		HUDStore->Shutdown();
	}

	InitHUDStore();
	GEngine->ForceGarbageCollection();
}

void UQ6GameInstance::SetReserveTutorialOnInit(ELobbyTutorial InTutorial, int32 InStep)
{
	ReservedTutorialOnInit = InTutorial;
	ReservedTutorialStepOnInit = InStep;
}

void UQ6GameInstance::CancelReserveTutorialOnInit()
{
	ReservedTutorialOnInit = ELobbyTutorial::None;
	ReservedTutorialStepOnInit = 0;
}

ELobbyTutorial UQ6GameInstance::GetReservedTutorialOnInit() const
{
	return ReservedTutorialOnInit;
}

int32 UQ6GameInstance::GetReservedTutorialStepOnInit() const
{
	return ReservedTutorialStepOnInit;
}

bool UQ6GameInstance::ShowUltimateSequence(int32 ModelType, bool bEnemy)
{
	// 0 : on
	// 1 : once a day

	int32 ShowUltimate = UQ6GameUserSettings::Get()->GetGameSettingData().ShowUltimate;
	if (ShowUltimate == 0)
	{
		return true;
	}

	if (SaveGameInstance && SaveGameInstance->IsFirstUltimateSequenceOnToday(ModelType, bEnemy))
	{
		SaveGameInstance->UpdateUltimateSequenceDate(ModelType, bEnemy);
		return true;
	}

	return false;
}

void UQ6GameInstance::ClearShowUltimateSequenceDates()
{
	if (SaveGameInstance)
	{
		SaveGameInstance->ClearUltimateSequenceDates();
	}
}

FDialogueType UQ6GameInstance::LoadPlayingDialogueType()
{
	const FString JsonStr = LoadDialoguePlayingFile();
	if (!JsonStr.IsNumeric())
	{
		return DialogueTypeInvalid;
	}

	return FDialogueType(FCString::Atoi(*JsonStr));
}

void UQ6GameInstance::InitDialogueRecord(const FDialogueRecord& DialogueRecord, FDialogueType StartDialogueType)
{
	SaveGameInstance->UpdateDialogueRecord(DialogueRecord);

	UpdateDialogueRecord(StartDialogueType);
}

void UQ6GameInstance::UpdateDialogueRecord(FDialogueType DialogueType)
{
	SaveDialgouePlayingFile(DialogueType);
}

void UQ6GameInstance::ClearDialogueRecord()
{
	SaveGameInstance->ClearDialogueRecord();

	RemoveDialoguePlayingFile();
}

const FDialogueRecord& UQ6GameInstance::GetDialogueRecord() const
{
	return SaveGameInstance->GetDialogueRecord();
}

bool UQ6GameInstance::IsDialogueExpired(const FDialogueRecord& DialogueRecord) const
{
	switch (DialogueRecord.DialogueType)
	{
		case EDialogueType::Saga:
		case EDialogueType::Special:
			return false;	// No have expire time
		case EDialogueType::Daily:
			return IsDialogueDailyExpired();
		case EDialogueType::Training:
			return IsDialogueTrainingExpired(DialogueRecord.TrainingExpireTime);
		case EDialogueType::Raid:
			return IsDialogueRaidExpired(DialogueRecord.SagaType);
		case EDialogueType::Event:
		case EDialogueType::MultiSide:
			return IsDialogueEventExpired(DialogueRecord.EventContentType);
	}

	Q6JsonLogRoze(Error, "UHUDStore::IsDialogueExpired - Invalid dialogue Type", Q6KV("EDialogueType", (int32)DialogueRecord.DialogueType));
	return true;
}

bool UQ6GameInstance::IsDialogueDailyExpired() const
{
	return SaveGameInstance->IsFirstDailyDungeonOnToday();
}

bool UQ6GameInstance::IsDialogueTrainingExpired(int32 ExpireTime) const
{
	return (GetHUDStore().GetTrainingCenterManager().GetHistory().ExpireTime != ExpireTime);
}

bool UQ6GameInstance::IsDialogueRaidExpired(FSagaType SagaType) const
{
	const UCMS* CMS = GetCMS();

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType == EContentType::RaidFinal)
	{
		// Raid final no have expire time
		return false;
	}

	if (SagaRow.ContentType != EContentType::Raid)
	{
		// Doesn't match content type
		return true;
	}

	const FRaidType RaidType = HUDStore->GetRaidManager().GetOpenRaidType();
	if (RaidType == RaidTypeInvalid)
	{
		return true;
	}

	const FCMSRaidRow& RaidRow = CMS->GetRaidRowOrDummy(RaidType);
	return RaidRow.GetSaga().CmsType() != SagaType;
}

bool UQ6GameInstance::IsDialogueEventExpired(FEventContentType EventContentType) const
{
	const UCMS* CMS = GetCMS();

	const FCMSEventContentRow& ContentRow = CMS->GetEventContentRowOrDummy(FEventContentType(EventContentType));
	const FEventScheduleInfo* ScheduleInfo = HUDStore->GetEventManager().GetEventSchedule(ContentRow.EventSchedule);
	if (!ScheduleInfo)
	{
		return true;
	}

	bool bInfinity = CMS->IsInfinityEventScheduleFormat(*ScheduleInfo);
	if (bInfinity)
	{
		return false;
	}

	return ScheduleInfo->EndDate < FDateTime::UtcNow().ToUnixTimestamp();
}

void UQ6GameInstance::InitRewardRecord(const FRewardRecord& InRewardRecord, bool bSave)
{
	SaveGameInstance->InitRewardRecord(InRewardRecord, bSave);
}

bool UQ6GameInstance::HasRewardStep() const
{
	const FRewardRecord& RewardRecord = SaveGameInstance->GetRewardRecord();
	return RewardRecord.RewardSteps.Num() > 0;
}

bool UQ6GameInstance::HeapPopRewardStep(FRewardStep& RewardStep)
{
	return SaveGameInstance->HeapPopRewardStep(RewardStep);
}

FSagaType UQ6GameInstance::GetRewardSagaType() const
{
	return SaveGameInstance->GetRewardRecord().SagaType;
}

const TArray<FRewardInfo>& UQ6GameInstance::GetRewardInfos() const
{
	return SaveGameInstance->GetRewardRecord().RewardInfos;
}

bool UQ6GameInstance::GetRewardInfo(int32 RewardIndex, FRewardInfo& Out) const
{
	const TArray<FRewardInfo>& RewardInfos = GetRewardInfos();
	if (RewardInfos.IsValidIndex(RewardIndex))
	{
		Out = RewardInfos[RewardIndex];
		return true;
	}

	Q6JsonLogRoze(Warning, "Invalid RewardIndex", Q6KV("RewardIndex", RewardIndex));

	Out = FRewardInfo();
	return false;
}

int32 UQ6GameInstance::GetReceiveAccumEventPoint() const
{
	const TArray<FRewardInfo>& RewardInfos = GetRewardInfos();

	int32 AccumPoint = 0;
	for (const FRewardInfo& RewardInfo : RewardInfos)
	{
		for (const FItemData& ItemData : RewardInfo.ItemList)
		{
			// ItemData.Type = 1 (= Point1, AccumPoint)
			if (ItemData.Category == ELootCategory::EventPoint && ItemData.Type == 1)
			{
				AccumPoint += ItemData.Count;
			}
		}
	}

	return AccumPoint;
}

const TArray<FBondLevelUpReward>& UQ6GameInstance::GetBondRewards() const
{
	return SaveGameInstance->GetRewardRecord().BondRewards;
}

void UQ6GameInstance::UpdateBanIndices(const TArray<int32>& BanIndices)
{
	SaveGameInstance->UpdateBanIndices(BanIndices);
}

void UQ6GameInstance::ClearBanIndices()
{
	SaveGameInstance->ClearBanIndices();
}

const TArray<int32>& UQ6GameInstance::GetBanIndices() const
{
	return SaveGameInstance->GetBanIndices();
}

FString UQ6GameInstance::LoadDialoguePlayingFile()
{
	const FString FilePath = GetDialoguePlayingFilePath();

	FString InJsonStr;
	if (!FFileHelper::LoadFileToString(InJsonStr, *FilePath))
	{
		return FString();
	}

	return InJsonStr;
}

void UQ6GameInstance::SaveDialgouePlayingFile(FDialogueType DialogueType)
{
	const FString FilePath = GetDialoguePlayingFilePath();

	FString DialogueTypeStr = FString::FromInt(DialogueType.x);
	if (!FFileHelper::SaveStringToFile(DialogueTypeStr, *FilePath))
	{
		Q6JsonLogRoze(Error, "UQ6GameInstance::SaveDialgouePlayingFile - File save failed", Q6KV("FilePath", *FilePath));
	}
}

void UQ6GameInstance::RemoveDialoguePlayingFile()
{
	const FString FilePath = GetDialoguePlayingFilePath();
	IFileManager::Get().Delete(*FilePath, false, true, true);
}

#if !UE_BUILD_SHIPPING
void UQ6GameInstance::SetDevMode(bool bInDevMode)
{
	APlayerController* PC = GetLocalPlayerController(this);
	if (PC)
	{
		FString DevMode = FString::Printf(TEXT("%s %d"), *DevModeConsoleName, bInDevMode ? 1 : 0);
		FString ShowTutorial = FString::Printf(TEXT("%s %d"), *ShowTutorialConsoleName, bInDevMode ? 0 : 1);
		FString ShowMultiSideBattleRankScore = FString::Printf(TEXT("%s %d"), *ShowMultiSideBattleRankScoreName, bInDevMode ? 1 : 0);
		PC->ConsoleCommand(DevMode);
		PC->ConsoleCommand(ShowTutorial);
		PC->ConsoleCommand(ShowMultiSideBattleRankScore);
	}
}

const bool UQ6GameInstance::IsTutorialSkipMode() const
{
	return !CVarQ6ShowTutorial.GetValueOnGameThread();
}

const bool UQ6GameInstance::IsShowMultiSideBattleRankScore() const
{
	return CVarQ6ShowMultiSideBattleRankScore.GetValueOnGameThread() > 0;
}

const bool UQ6GameInstance::IsDevMode() const
{
	return CVarQ6DevMode.GetValueOnGameThread() > 0;
}
#endif

void UQ6GameInstance::ReqNoAuthCC()
{
	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(this);
	if (!CombatGameMode)
	{
		return;
	}
	CombatGameMode->StartCombatCube();
}
