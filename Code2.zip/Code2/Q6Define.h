#pragma once

#include "CoreMinimal.h"

inline int32 EnumCount(const TCHAR* EnumName)
{
	UEnum* Enum = FindObject<UEnum>(ANY_PACKAGE, EnumName);
	if (Enum)
	{
		return Enum->NumEnums();
	}

	return -1;
}

#define ENUM_COUNT(Enum) EnumCount(TEXT(#Enum))

const int32 MAX_COMMON_COMBAT_TEXT_POOL_SIZE = 25;
const int32 MIN_HEALTHBAR_GAUGE_COUNT = 1;
const int32 MAX_HEALTHBAR_GAUGE_COUNT = 10;
const int32 INVALID_WAITDOWN = -1;
const int32 MAX_ULTIMATE_SKILL_COOLDOWN = 7;
const int32 CENTER_SLOT = 2;
const float MAX_PROGRESS_TASK_TICK_TIME = 3.f;
const int32 MAX_STAR = 10;
const int32 MAX_EQUIP_STAR = 5;
const int32 ENEMY_TURN_SKILL_FRIENDLY_TARGET_INDEX = 0;
const int32 ENEMY_TURN_SKILL_HOSTILE_TARGET_INDEX = 1;
const int32 MAX_CHARACTER_MOON = 11;
const int32 MAX_RAID_TURN_SKILL_USED = 3;
const int32 MAX_RAID_SUPPORT_SKILL_USED = 2;
const int32 MAX_RAID_SKILL_USED = MAX_RAID_TURN_SKILL_USED + MAX_RAID_SUPPORT_SKILL_USED;
const int32 MAX_WEEKLY_MISSION = 9;
const int32 MAX_WEEKLY_BINGO = 8;
const int32 MAX_ARTIFACT_COUNT = 3;
const int32 MAX_AKA_BADGE_COUNT = 10;

#include "Q6Struct.h"
