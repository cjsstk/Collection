// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "BaseWidget.h"

#include "GameResource.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "HSAction.h"
#include "HUDStore.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Base"), STAT_OnHSEventByBase, STATGROUP_HSTORE);

UBaseWidget::UBaseWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

UWidget* UBaseWidget::FindChildWidgetFromName(const FName& Name)
{
	return FindChildWidgetFromNameInternal(this, Name);
}

UWidget* UBaseWidget::FindChildWidgetFromNameInternal(UUserWidget* InUserWidget, const FName& Name)
{
	if (!InUserWidget->WidgetTree)
	{
		return nullptr;
	}

	UWidget* FoundWidget = InUserWidget->GetWidgetFromName(Name);
	if (FoundWidget)
	{
		return FoundWidget;
	}

	TArray<UWidget*> AllWidgets;
	InUserWidget->WidgetTree->GetAllWidgets(AllWidgets);
	for (UWidget* EachWidget : AllWidgets)
	{
		UUserWidget* EachUserWidget = Cast<UUserWidget>(EachWidget);
		if (!EachUserWidget)
		{
			continue;
		}

		FoundWidget = FindChildWidgetFromNameInternal(EachUserWidget, Name);
		if (FoundWidget)
		{
			return FoundWidget;
		}
	}

	return nullptr;
}

///////////////////////////////////////////////////////////////////////////////////////////
// UHSReceiverBaseWidget
UHSBaseWidget::UHSBaseWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bSubscribed(false)
{
}

void UHSBaseWidget::NativeDestruct()
{
	UnsubscribeToStore();

	Super::NativeDestruct();
}

void UHSBaseWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByBase);
	Q6JsonLog(Warning, "OnHSEvent should be overriden", Q6KV("Widget", *GetName()), Q6KV("Action", (int32)Action->GetActionType()));
}

void UHSBaseWidget::SubscribeToStore(EHSType StoreType)
{
	bSubscribed = true;
	GetHUDStore().Subscribe(StoreType, this);
}

void UHSBaseWidget::UnsubscribeToStore()
{
	if (!bSubscribed)
	{
		return;
	}

	GetHUDStore().Unsubscribe(this);
	bSubscribed = false;
}
