// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatHUDWidget.h"

#include "CMSTable.h"
#include "CombatCube.h"
#include "CombatCubeUtil.h"
#include "CombatDetailWidgets.h"
#include "CombatHUD.h"
#include "CombatPresenter.h"
#include "CombatWidgets.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "HUD/BaseHUD.h"
#include "LevelUtil.h"
#include "PartyManager.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6GameInstance.h"
#include "Q6GameState.h"
#include "Q6GameUserSettings.h"
#include "Q6SaveGame.h"
#include "SagaManager.h"
#include "SkillWidgets.h"
#include "SystemConst_gen.h"
#include "TempleManager.h"
#include "Tutorial/CombatTutorial.h"
#include "Unit.h"
#include "WidgetUtil.h"

static TAutoConsoleVariable<int32> CVarQ6TutorialDoubleSpeed(
	TEXT("q6.Tutorial.DoubleSpeed"),
	8,
	TEXT("double speed enable saga type(usage: q6.Tutorial.DoubleSpeed <sagaType>)"),
	ECVF_Default);

extern TAutoConsoleVariable<int32> CVarQ6UseLobbyCombat;

UCombatHUDWidget::UCombatHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, AttackOrder(0)
	, SelectedAllyUnitId(CCUnitIdInvalid)
	, SelectedEnemyUnitId(CCUnitIdInvalid)
	, SelectedTurnSkillIndex(INDEX_NONE)
	, bSkillQuickUse(false)
	, bShowProvokedEnemyBar(false)
{
}

void UCombatHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widget Animations

	TurnStartAnim = GetWidgetAnimationFromName(this, "AnimHUDTurnStart");
	TurnEndAnim = GetWidgetAnimationFromName(this, "AnimHUDTurnEnd");
	TurnSkillHideAnim = GetWidgetAnimationFromName(this, "AnimHUDTurnSkillHide");
	TurnSkillShowAnim = GetWidgetAnimationFromName(this, "AnimHUDTurnSkillShow");
	WaveStartAnim = GetWidgetAnimationFromName(this, "AnimHUDWaveStart");
	WaveEndAnim = GetWidgetAnimationFromName(this, "AnimHUDWaveEnd");
	InDangerStartAnim = GetWidgetAnimationFromName(this, "AnimHUDInDangerStart");
	UltSkillStartAnim = GetWidgetAnimationFromName(this, "AnimHUDUltStart");
	UltSkillIllustAnim = GetWidgetAnimationFromName(this, "AnimHUDUltIllust");
	UltSkillEndAnim = GetWidgetAnimationFromName(this, "AnimHUDUltEnd");
	HUDStateNormalAnim = GetWidgetAnimationFromName(this, "AnimHUDStateNormal");
	HUDStateRaidAnim = GetWidgetAnimationFromName(this, "AnimHUDStateRaid");

	// Widgets

	WaveTurnInfoWidget = CastChecked<UWaveTurnInfoWidget>(GetWidgetFromName("WaveTurnInfo"));

	WaveWidget = CastChecked<UCombatWaveWidget>(GetWidgetFromName("CombatWave"));

	TurnPhaseWidget = CastChecked<UCombatTurnPhaseWidget>(GetWidgetFromName("TurnPhase"));
	TurnPhaseWidget->OnTurnPhaseAnimFinishedDelegate.BindUObject(this, &UCombatHUDWidget::OnStartTurnPhaseAnimFinished);

	AttackButtonWidget = CastChecked<UCombatAttackButtonWidget>(GetWidgetFromName("AttackBtn"));
	AttackButtonWidget->OnAttackButtonClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnAttackButtonClicked);

	SkillCastingNameWidget = CastChecked<UCombatSkillCastingNameWidget>(GetWidgetFromName("SkillCastingName"));

	SkillFailedWidget = CastChecked<UCombatSkillFailedWidget>(GetWidgetFromName("SkillFailed"));
	SkillFailedWidget->OnSkillFaildAnimFinishedDelegate.BindUObject(this, &UCombatHUDWidget::OnSkillFaildAnimFinished);

	TotalDamageWidget = CastChecked<UCombatTotalDamageWidget>(GetWidgetFromName("TotalDamage"));

	ChainEffectWidget = CastChecked<UCombatChainEffectWidget>(GetWidgetFromName("ChainEff"));

	BonusRewardMarkListWidget = CastChecked<UBonusRewardMarkListWidget>(GetWidgetFromName("RewardMarkList"));

	ACombatTutorial* InTutorial = GetCombatTutorial(this);

	SkillQuickUseCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("QuickSkill"));
	SkillQuickUseCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UCombatHUDWidget::OnSkillQuickUseClicked);
	if (InTutorial->IsSkillQuickUseEnable())
	{
		UQ6SaveGame* SaveGame = GetQ6SaveGame();
		if (SaveGame)
		{
			bSkillQuickUse = SaveGame->IsCombatSkillQuickUse();
		}
		SkillQuickUseCheckBox->SetIsChecked(bSkillQuickUse);
	}
	else
	{
		SkillQuickUseCheckBox->SetIsChecked(false);
		bSkillQuickUse = false;
		SkillQuickUseCheckBox->SetVisibility(ESlateVisibility::Collapsed);
	}

	DoubleSpeedCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("DoubleSpeed"));
	DoubleSpeedCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UCombatHUDWidget::OnDoubleSpeedChecked);
	if (InTutorial->IsDoubleSpeedEnable())
	{
		UQ6SaveGame* SaveGame = GetQ6SaveGame();
		if (SaveGame)
		{
			SetCombatDoubleSpeedInternal(true, SaveGame->IsCombatDoubleSpeed());
		}
	}
	else
	{
		SetCombatDoubleSpeedInternal(true, false);
	}

	PetButtonWidget = CastChecked<UCombatPetButtonWidget>(GetWidgetFromName("PetSkill"));
	PetButtonWidget->OnOpenButtonClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnPetButtonClicked);

	ArtifactButton = CastChecked<UButton>(GetWidgetFromName("ArtifactSkill"));
	ArtifactButton->OnClicked.AddUniqueDynamic(this, &UCombatHUDWidget::OnArtifactButtonClicked);

	RaidAssistTurnWidget = CastChecked<URaidAssistTurnWidget>(GetWidgetFromName("RaidAssistTurn"));
	RaidAssistTurnWidget->OnRaidAssistStartAnimFinished.BindUObject(this, &UCombatHUDWidget::OnRaidAssistStartAnimFinished);

	RaidTotalBarWidget = CastChecked<URaidTotalBarWidget>(GetWidgetFromName("RaidTotalBar"));
	RaidRankingWidget = CastChecked<URaidRankingWidget>(GetWidgetFromName("RaidRanking"));
	CombatTimeWidget = CastChecked<UCombatTimeWidget>(GetWidgetFromName("CombatTimeWidgetBP"));

	RaidEmoticonWidget = CastChecked<URaidEmoticonWidget>(GetWidgetFromName("RaidEmoticon"));

	PauseButton = CastChecked<UButton>(GetWidgetFromName("BtnPause"));
	PauseButton->OnClicked.AddUniqueDynamic(this, &UCombatHUDWidget::OnPauseButtonClicked);

	CombatDetailButton = CastChecked<UButton>(GetWidgetFromName("BtnCombatDetail"));
	CombatDetailButton->OnClicked.AddUniqueDynamic(this, &UCombatHUDWidget::OnCombatDetailButtonClicked);

	CombatMenuWidget = CastChecked<UCombatMenuWidget>(GetWidgetFromName("CombatMenu"));

	BackTurnButtonWidget = CastChecked<UBackTurnButtonWidget>(GetWidgetFromName("BackTurn"));
	BackTurnButtonWidget->OnBackButtonClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnBackTurnButtonClicked);

	// Fill arrays

	FString WidgetNameStr;

	UCombatAllyBarWidget* AllyBar = nullptr;
	for (int32 n = 1; n <= CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT; ++n)
	{
		WidgetNameStr = FString::Printf(TEXT("CharacterBar%d"), n);
		AllyBar = CastChecked<UCombatAllyBarWidget>(GetWidgetFromName(*WidgetNameStr));
		AllyBar->SetAllyBarIndex(n);
		AllyBar->OnBarClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnAllyBarClicked, n);
		AllyBar->OnBarLongClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnUnitBarLongClicked);
		AllyBar->OnSpawnAnimFinishedDelegate.BindUObject(this, &UCombatHUDWidget::OnSpawnAnimFinished);
		AllyBar->OnSkillSelectedDelegate.BindUObject(this, &UCombatHUDWidget::OnAttackSkillClicked);
		AllyBar->OnSkillStartAnimFinishedDelegate.BindUObject(this, &UCombatHUDWidget::OnSkillStartAnimFinished);
		AllyBar->SetVisibility(ESlateVisibility::Hidden);
		AllyBars.AddUnique(AllyBar);
	}

	UCombatEnemyBarWidget* EnemyBar = nullptr;
	for (int32 n = 1; n <= CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT; ++n)
	{
		WidgetNameStr = FString::Printf(TEXT("MonsterBar%d"), n);
		EnemyBar = CastChecked<UCombatEnemyBarWidget>(GetWidgetFromName(*WidgetNameStr));
		EnemyBar->OnBarClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnEnemyBarClicked);
		EnemyBar->OnBarLongClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnUnitBarLongClicked);
		EnemyBar->OnSpawnAnimFinishedDelegate.BindUObject(this, &UCombatHUDWidget::OnSpawnAnimFinished);
		EnemyBars.AddUnique(EnemyBar);
	}

	UCombatTurnSkillWidget* TurnSkillWidget = nullptr;
	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		WidgetNameStr = FString::Printf(TEXT("TurnSkill%d"), i + 1);
		TurnSkillWidget = CastChecked<UCombatTurnSkillWidget>(GetWidgetFromName(*WidgetNameStr));
		TurnSkillWidget->SetIndex(i);
		TurnSkillWidget->SetQuickUse(bSkillQuickUse);
		TurnSkillWidget->OnTurnSkillClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnTurnSkillClicked);
		TurnSkillWidget->OnTurnSkillUseClickedDelegate.BindUObject(this, &UCombatHUDWidget::OnTurnSkillUseClicked);
		TurnSkillWidget->OnTurnSkillBlockedDelegate.BindUObject(this, &UCombatHUDWidget::OnTurnSkillBlocked);
		TurnSkillWidgets.AddUnique(TurnSkillWidget);
	}
}

void UCombatHUDWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	if (Presenter->GetCombatSeed().CombatMultiSideInfo.bIsCombatMultiSide && bIgnoreAnimationFinishedEvent)
	{
		return;
	}

	if (Animation == WaveEndAnim)
	{
		PlayWaveStartAnimations();
	}
	else if (Animation == InDangerStartAnim)
	{
		OnEnemyUltimateReadyAnimFinishedDelegate.ExecuteIfBound();
	}
}

void UCombatHUDWidget::OnUltimateSkillSequenceStarted()
{
	PlayAnimation(UltSkillStartAnim);
}

void UCombatHUDWidget::OnUltimateSkillIllustAnimStarted()
{
	PlayAnimation(UltSkillIllustAnim);
}

void UCombatHUDWidget::OnUltimateSkillSequenceFinished()
{
	StopAnimation(UltSkillStartAnim);
	PlayAnimation(UltSkillEndAnim);
}

UCombatUnitBarWidget* UCombatHUDWidget::GetUnitBar(FCCUnitId UnitId) const
{
	if (UnitId == CCUnitIdInvalid)
	{
		return nullptr;
	}

	UCombatUnitBarWidget* FoundBar = GetAllyBar(UnitId);
	if (FoundBar)
	{
		return FoundBar;
	}

	FoundBar = GetEnemyBar(UnitId);
	if (FoundBar)
	{
		return FoundBar;
	}

	return nullptr;
}

UCombatAllyBarWidget* UCombatHUDWidget::GetAllyBar(FCCUnitId UnitId) const
{
	if (UnitId == CCUnitIdInvalid)
	{
		return nullptr;
	}

	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		if (AllyBar->GetUnitId() == UnitId)
		{
			return AllyBar;
		}
	}

	return nullptr;
}

UCombatEnemyBarWidget* UCombatHUDWidget::GetEnemyBar(FCCUnitId UnitId) const
{
	if (UnitId == CCUnitIdInvalid)
	{
		return nullptr;
	}

	for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
	{
		if (EnemyBar->GetUnitId() == UnitId)
		{
			return EnemyBar;
		}
	}

	return nullptr;
}

void UCombatHUDWidget::PlayWaveStartAnimations()
{
	PlayAnimation(WaveStartAnim);

	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		AllyBar->OnStartWave();
	}
}

void UCombatHUDWidget::DeselectSelectedTurnUnit()
{
	UCombatAllyBarWidget* SelectedAllyBar = GetAllyBar(SelectedAllyUnitId);
	if (SelectedAllyBar)
	{
		SelectedAllyBar->SetSelectedBar(false);
	}

	SelectedAllyUnitId = CCUnitIdInvalid;
}

void UCombatHUDWidget::DeselectSelectedTurnSkill()
{
	if (!TurnSkillWidgets.IsValidIndex(SelectedTurnSkillIndex))
	{
		return;
	}

	TurnSkillWidgets[SelectedTurnSkillIndex]->SetSelected(false);
	SelectedTurnSkillIndex = INDEX_NONE;
}

void UCombatHUDWidget::SetTurnSkills(FCCUnitId InUnitId)
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);

	AUnit* Unit = Presenter->FindUnit(InUnitId);
	if (!Unit)
	{
		Q6JsonLogSunny(Warning, "UCombatHUDWidget::SetCharacterTurnSkills - invalid unit", Q6KV("UnitId", InUnitId));
		return;
	}

	const UCMS* CMS = GetCMS();
	check(CMS);

	for (int32 i = 0; i < TurnSkillWidgets.Num(); ++i)
	{
		TurnSkillWidgets[i]->SetTurnSkill(InUnitId);
	}
	DeselectSelectedTurnSkill();
	UpdateProvokeTargetEnemyBars(InUnitId);

	Presenter->PickTurnPrepareUnit(InUnitId);
}

void UCombatHUDWidget::RefreshAllyTurnSkills()
{
	for (UCombatTurnSkillWidget* TurnSkillWidget : TurnSkillWidgets)
	{
		TurnSkillWidget->UpdateTurnSkillState();
	}

	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		AllyBar->UpdateTurnSkillStates();
	}
}

void UCombatHUDWidget::RefreshEnemyUltimateSkills(FCCUnitId InUnitId)
{
	for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
	{
		if (EnemyBar->GetUnitId() == InUnitId)
		{
			EnemyBar->UpdateUltimateSkill();
		}
	}
}

void UCombatHUDWidget::WarningPatternUltimate(const UCCSelectedPatternUltimate* Event)
{
	UCombatEnemyBarWidget* EnemyBar = GetEnemyBar(Event->UnitId);
	const AUnit* EnemyUnit = GetCheckedCombatPresenter(this)->FindUnit(Event->UnitId);
	if (EnemyBar && EnemyUnit)
	{
		EnemyBar->PlayUltimateAlertAnim(true);
	}
}

void UCombatHUDWidget::SelectTarget(FCCUnitId InUnitId)
{
	UCombatEnemyBarWidget* OldSelectedEnemyBar = GetEnemyBar(SelectedEnemyUnitId);
	if (OldSelectedEnemyBar)
	{
		OldSelectedEnemyBar->SetSelectedBar(false);
	}

	SelectedEnemyUnitId = InUnitId;

	UCombatEnemyBarWidget* NewSelectedEnemyBar = GetEnemyBar(SelectedEnemyUnitId);
	if (NewSelectedEnemyBar)
	{
		NewSelectedEnemyBar->SetSelectedBar(true);
	}

	UpdateAlliesNatureRelation();
}

void UCombatHUDWidget::RefreshArtifactButton()
{
	bool bHasAnyArtifact = GetHUDStore().GetTempleManager().HasOpenedArtifactCanUseInBattle();
	ArtifactButton->SetVisibility(bHasAnyArtifact ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}

void UCombatHUDWidget::SetAllyTurnSkillPhaseSelectable(bool bInSelectable)
{
	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		AllyBar->SetTurnSkillPhaseSelectable(bInSelectable);
	}
}

void UCombatHUDWidget::DisableAllyNatureRelations()
{
	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		AllyBar->DisableNatureRealtion();
	}
}

FCCUnitId UCombatHUDWidget::GetFirstAliveAllyUnitId() const
{
	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		if (!AllyBar->IsDead())
		{
			return AllyBar->GetUnitId();
		}
	}

	return CCUnitIdInvalid;
}

bool UCombatHUDWidget::IsBonusWave(const int32 WaveIndex) const
{
	// for test
	if (GetCheckedCombatPresenter(this)->GetCombatSeed().CombatMultiSideInfo.bIsCombatMultiSide)
	{
		return false;
	}

	const FSagaType SagaType = GetCheckedCombatPresenter(this)->GetCombatSeed().SagaType;
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(SagaType, WaveIndex);
	if (!WaveRow)
	{
		Q6JsonLogPawn(Warning, "WaveRow index error", Q6KV("SagaType", SagaType), Q6KV("WaveIndex", WaveIndex));
		return false;
	}

	return WaveRow->AppearanceRatio < 1000;
}

void UCombatHUDWidget::PickFirstAliveAlly()
{
	FCCUnitId FirstAliveAllyUnitId = GetFirstAliveAllyUnitId();
	UCombatAllyBarWidget* FirstAliveAllyBar = GetAllyBar(FirstAliveAllyUnitId);
	OnAllyBarClicked(FirstAliveAllyUnitId, FirstAliveAllyBar ? FirstAliveAllyBar->GetAllyBarIndex() : 0);
}

void UCombatHUDWidget::ResetTotalDamage()
{
	TotalDamageWidget->ResetDamage();
}

void UCombatHUDWidget::OnSpawnAnimFinished()
{
	OnSpawnAnimFinishedDelegate.ExecuteIfBound();
}

void UCombatHUDWidget::OnAllyBarClicked(FCCUnitId InUnitId, int32 InAllyBarIndex)
{
	FString TutorialParams = FString::Printf(TEXT("AllyBar_%d"), InAllyBarIndex);
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialParams);

	AUnit* NewSelectedUnit = GetCheckedCombatPresenter(this)->FindUnit(InUnitId);
	if (!NewSelectedUnit || NewSelectedUnit->IsDead())
	{
		return;
	}

	UCombatAllyBarWidget* OldAllyBar = GetAllyBar(SelectedAllyUnitId);
	if (OldAllyBar)
	{
		OldAllyBar->SetSelectedBar(false);
	}

	UCombatAllyBarWidget* NewAllyBar = GetAllyBar(InUnitId);
	if (NewAllyBar)
	{
		NewAllyBar->SetSelectedBar(true);
	}

	SelectedAllyUnitId = InUnitId;

	if (!CVarQ6UseLobbyCombat.GetValueOnGameThread())
	{
		SetTurnSkills(SelectedAllyUnitId);
	}
}

void UCombatHUDWidget::OnEnemyBarClicked(FCCUnitId InUnitId)
{
	if (!IsAllyAttackFinished())
	{
		AUnit* EnemyUnit = GetCheckedCombatPresenter(this)->FindUnit(InUnitId);
		if (EnemyUnit)
		{
			GetCheckedCombatCube(this)->SelectTarget(InUnitId);
		}
	}
}

void UCombatHUDWidget::OnUnitBarLongClicked(FCCUnitId InUnitId)
{
	if (!GetCombatTutorial(this)->IsUnitBarLongTouchEnable())
	{
		return;
	}

	UCombatUnitBarWidget* InCombatUnitBarWidget = GetUnitBar(InUnitId);
	if (InCombatUnitBarWidget)
	{
		FString TutorialStr = FString::Printf(TEXT("BarLongClicked_%s"), *(InCombatUnitBarWidget->GetName()));
		TUTORIAL_MONITORING_BUTTON_CLICK(TutorialStr);

		OpenCombatDetailPopup(InUnitId);
	}
}

void UCombatHUDWidget::OnCombatDetailButtonClicked()
{
	if (!GetCombatTutorial(this)->IsUnitBarLongTouchEnable())
	{
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedTextOrKey("Combat", "PlayMoreToEnableCombatDetailButton"));
		return;
	}

	FCCUnitId FirstAliveAllyUnitId = GetFirstAliveAllyUnitId();
	OpenCombatDetailPopup(FirstAliveAllyUnitId);
}

void UCombatHUDWidget::OpenCombatDetailPopup(FCCUnitId InUnitId)
{
	UCombatDetailPopupWidget* CombatDetailPopup = CastChecked<UCombatDetailPopupWidget>(
		GetCheckedCombatHUD(this)->OpenPopup(CombatDetailPopupWidgetClass));
	if (CombatDetailPopup)
	{
		CombatDetailPopup->Init(InUnitId);
	}
}

void UCombatHUDWidget::OnSkillQuickUseClicked(bool bInChecked)
{
	if (!GetCombatTutorial(this)->IsSkillQuickUseEnable())
	{
		SkillQuickUseCheckBox->SetIsChecked(false);
		bSkillQuickUse = false;
		return;
	}

	TUTORIAL_MONITORING_BUTTON_CLICK("SkillQuickUseClicked");

	bSkillQuickUse = bInChecked;
	UQ6SaveGame* SaveGame = GetQ6SaveGame();
	if (SaveGame)
	{
		SaveGame->SetCombatSkillQuickUse(bInChecked);
	}

	for (int32 i = 0; i < TurnSkillWidgets.Num(); ++i)
	{
		TurnSkillWidgets[i]->UpdateQuickSkillState(bSkillQuickUse);
	}
	DeselectSelectedTurnSkill();
}

void UCombatHUDWidget::OnDoubleSpeedChecked(bool bInChecked)
{
	SetCombatDoubleSpeedInternal(false, bInChecked);
}

void UCombatHUDWidget::SetCombatDoubleSpeedInternal(bool bInit, bool bDoubleSpeed)
{
	FSagaType InEnableDoubleSpeedSagaType(CVarQ6TutorialDoubleSpeed.GetValueOnGameThread());
	const FCMSSagaRow& InSagaRow = GetCMS()->GetSagaRowOrDummy(InEnableDoubleSpeedSagaType);
	if (!GetHUDStore().GetSagaManager().IsStageCleared(InSagaRow.Episode, InSagaRow.Stage, InSagaRow.SubStage))
	{
		if (!bInit)
		{
			GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedTextOrKey("Combat", "PlayMoreToEnableDoubleSpeed"));
		}
		DoubleSpeedCheckBox->SetIsChecked(false);
		return;
	}

	TUTORIAL_MONITORING_BUTTON_CLICK("DoubleSpeedClicked");

	DoubleSpeedCheckBox->SetIsChecked(bDoubleSpeed);
	UQ6SaveGame* SaveGame = GetQ6SaveGame();
	if (SaveGame)
	{
		SaveGame->SetCombatDoubleSpeed(bDoubleSpeed);
	}

	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(this);
	if (CombatGameMode)
	{
		CombatGameMode->SetGameDoubleSpeed(bDoubleSpeed);
	}
}

void UCombatHUDWidget::OnTurnSkillClicked(int32 InIndex)
{
	TUTORIAL_MONITORING_BUTTON_CLICK("TurnSkill");

	if (InIndex == SelectedTurnSkillIndex)
	{
		DeselectSelectedTurnSkill();
		return;
	}

	DeselectSelectedTurnSkill();
	if (TurnSkillWidgets.IsValidIndex(InIndex))
	{
		TurnSkillWidgets[InIndex]->SetSelected(true);
		SelectedTurnSkillIndex = InIndex;
	}
}

void UCombatHUDWidget::OnTurnSkillUseClicked(FCCSkillId InSkillId)
{
	TUTORIAL_MONITORING_BUTTON_CLICK("TurnSkillUse");

	SetAllyTurnSkillPhaseSelectable(false);
	GetCheckedCombatCube(this)->UseSkill(SelectedAllyUnitId, InSkillId, GetCheckedCombatPresenter(this)->GetTurnCount());
}

void UCombatHUDWidget::OnTurnSkillBlocked()
{
	UCombatAllyBarWidget* AllyBar = GetAllyBar(SelectedAllyUnitId);
	if (AllyBar)
	{
		AllyBar->PlaySkillBlockedAnimation(ESkillCategory::TurnBegin);
	}
}

void UCombatHUDWidget::OnPetButtonClicked()
{
	UCombatWonderSkillUsePopupWidget* PetSkillUsePopup = CastChecked<UCombatWonderSkillUsePopupWidget>(
		GetCheckedCombatHUD(this)->OpenPopup(WonderSkillUsePopupWidgetClass));

	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	const TArray<FSkillState>& PetSkills = Presenter->GetAllyMaster().Pets;
	PetSkillUsePopup->SetPetSkills(Presenter->GetPetType(), PetSkills, GetFirstAliveAllyUnitId());
}

void UCombatHUDWidget::OnArtifactButtonClicked()
{
	UCombatWonderSkillUsePopupWidget* ArtifactUsePopup = CastChecked<UCombatWonderSkillUsePopupWidget>(
		GetCheckedCombatHUD(this)->OpenPopup(WonderSkillUsePopupWidgetClass));

	const TArray<FSkillState>& ArtifactSkills = GetCheckedCombatPresenter(this)->GetAllyMaster().Artifacts;
	ArtifactUsePopup->SetArtifactSkills(ArtifactSkills, SelectedAllyUnitId);
}

void UCombatHUDWidget::OnAttackButtonClicked()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("Attack");
	ProceedToSteadyPhase();
	ClearProvokeTargetEnemyBars();
}

void UCombatHUDWidget::OnAttackSkillClicked(FCCUnitId InUnitId, FCCSkillId InSkillId)
{
	TUTORIAL_MONITORING_BUTTON_CLICK("AttackSkill");

	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());

	if (TurnPhase != ECPTurnPhase::Steady && TurnPhase != ECPTurnPhase::Attack)
	{
		return;
	}

	AUnit* UseSkillUnit = Presenter->FindUnit(InUnitId);
	if (!UseSkillUnit || UseSkillUnit->IsDead())
	{
		return;
	}

	UCombatAllyBarWidget* SkillUsedAllyBar = GetAllyBar(InUnitId);
	if (!SkillUsedAllyBar)
	{
		return;
	}

	if (TurnPhase == ECPTurnPhase::Steady)
	{
		GetCheckedCombatCube(this)->ProceedToNextTurn();
	}

	SkillUsedAllyBar->SetAttackOrder(AttackOrder, Presenter->GetSurvivorsCount(UseSkillUnit->GetOverrideFaction()));

	if (CVarQ6UseLobbyCombat.GetValueOnGameThread())
	{
		GetCheckedCombatCube(this)->TurnAction(InUnitId, InSkillId, GetCheckedCombatPresenter(this)->GetTurnCount());
	}
	else
	{
		GetCheckedCombatCube(this)->UseSkill(InUnitId, InSkillId, GetCheckedCombatPresenter(this)->GetTurnCount());
	}

	++AttackOrder;
}

void UCombatHUDWidget::OnSkillStartAnimFinished()
{
	OnSkillStartAnimFinishedDelegate.ExecuteIfBound();
}

void UCombatHUDWidget::OnReportError(const UCCReportErrorEvent* Event)
{
	Q6JsonLogSunny(Warning, "UCombatHUDWidget::OnReportError - ", Q6KV("ErrorCode", Event->Code));
}

const FCMSSagaRow& UCombatHUDWidget::GetCombatSeedSagaRow() const
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCCCombatSeed& CombatSeed = GetCheckedCombatPresenter(this)->GetCombatSeed();
	return CMS->GetSagaRowOrDummy(CombatSeed.SagaType);
}

void UCombatHUDWidget::OnStartGame(const UCCStartGameEvent* Event)
{
	check(Event);

	const FCMSSagaRow& SagaRow = GetCombatSeedSagaRow();
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	WaveTurnInfoWidget->SetTotalWave(Presenter->GetTotalWaveNum());
	SetStageInfo(Presenter, SagaRow);

	const FCCUnitState& MasterState = Event->MasterStates[(int32)ECCFaction::Ally];
	TArray<FSkillState> SkillStates;
	UCombatCubeStateUtil::ConvertCCSkillStateToSkillState(MasterState.GetSkillStates(ESkillCategory::Pet), &SkillStates);
	PetButtonWidget->Init(Presenter->GetPetType(), SkillStates);
}

void UCombatHUDWidget::OnStartWave(const UCCStartWaveEvent* Event)
{
	const bool bIsBonusWave = IsBonusWave(Event->WaveIndex);
	WaveTurnInfoWidget->SetCurrentWave(Event->WaveCount);
	WaveTurnInfoWidget->SetWaveVisibility(!bIsBonusWave);
	WaveTurnInfoWidget->SetBonusWaveVisibility(bIsBonusWave);

	const FCMSSagaRow& SagaRow = GetCombatSeedSagaRow();
	WaveWidget->PlayWaveAnimation(Event->WaveCount, SagaRow.DescName, bIsBonusWave);

	for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
	{
		EnemyBar->SetVisibility(ESlateVisibility::Collapsed);
	}

	RaidTotalBarWidget->SetVisibility(ESlateVisibility::Collapsed);

	ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	if (!CombatPresenter->GetCombatSeed().CombatMultiSideInfo.bIsCombatMultiSide)
	{
		if (Event->WaveCount == 1 && !bIsBonusWave)
		{
			PlayWaveStartAnimations();
		}
	}
	else
	{
		PlayWaveStartAnimations();
		SetCombatMultiSideWaveInfo();
	}

	DeselectSelectedTurnUnit();
	DisableAllyNatureRelations();
}

void UCombatHUDWidget::OnTakeTurn(const UCCTakeTurnEvent* Event)
{

}

void UCombatHUDWidget::OnStartTurn(const UCCStartTurnEvent* Event)
{
	PetButtonWidget->UpdateSkillStates();

	if (AllyBars.Num())
	{
		SelectedAllyUnitId = AllyBars[0]->GetUnitId();
	}

	const ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	const int32 TurnCount = CombatPresenter->GetTurnCountForWidget();
	TurnPhaseWidget->PlayTurnAnimation(TurnCount);

	EContentType ContentType = CombatPresenter->GetCombatSeed().Content;
	if (ContentType == EContentType::Raid
			&& Event->TurnCount == CombatCubeConst::Q6_FIRST_TURN)
	{
		RaidTotalBarWidget->InitRaidTotalHealthBar();
		RaidTotalBarWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		BonusRewardMarkListWidget->PlayRewardMarkListAnimation(EBonusRewardMarkAnimType::Show, MAX_BONUS_REWARD_MARK);
		BonusRewardMarkListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	if (ContentType == EContentType::DailyDungeon
		&& CombatPresenter->IsLastWave() && !BonusRewardMarkListWidget->IsVisible())
	{
		BonusRewardMarkListWidget->PlayRewardMarkListAnimation(EBonusRewardMarkAnimType::Show, MAX_BONUS_REWARD_MARK);
		BonusRewardMarkListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	const FCMSSagaRow& SagaRow = GetCombatSeedSagaRow();
	if (SagaRow.LimitTurn)
	{
		int32 LeftTurn = SagaRow.LimitTurn - TurnCount;

		WaveTurnInfoWidget->SetTurnLeft(LeftTurn);
	}
	else
	{
		WaveTurnInfoWidget->SetTurnCount(TurnCount);

	}
}

void UCombatHUDWidget::OnStartPhaseSettingsInternal(ECPTurnPhase InPhase)
{
	WidgetAnimWaitingCount = 0;	// Forced reset for safety

	switch (InPhase)
	{
		case ECPTurnPhase::Steady:
		case ECPTurnPhase::OppAttack:
			TurnPhaseWidget->PlayPhaseAnimation(InPhase);
			PetButtonWidget->SetPhase(InPhase);
			break;
		default:
			OnStartTurnPhaseAnimFinished();
			break;
	}

	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		AllyBar->SetPhase(InPhase);
	}

	for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
	{
		EnemyBar->SetPhase(InPhase);
	}
}

void UCombatHUDWidget::OnStartPhase(const UCCStartPhaseEvent* Event)
{
	ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);

	if (Event->Phase == ECCTurnPhase::TurnSkill
		&& CombatPresenter->GetCombatSeed().Content == EContentType::Raid
		&& CombatPresenter->GetTurnCount() > CombatCubeConst::Q6_FIRST_TURN)
	{
		return;
	}

	OnStartCPPhase(CombatPresenter->CCPhaseToCPPhase(Event->Phase));
}

bool UCombatHUDWidget::IsAllyAttackFinished() const
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	return Presenter->GetSurvivorsCount(ECCFaction::Ally) < AttackOrder;
}

void UCombatHUDWidget::SetupUnitBarOnSpawn(const FUnitState& UnitState, ESpawnReason InSpawnReason)
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	int32 SlotIndex = UnitState.Slot - 1;

	if (UnitState.Faction == ECCFaction::Ally)
	{
		if (!AllyBars.IsValidIndex(SlotIndex))
		{
			Q6JsonLogObiwan(Warning, "OnSpawnUnit Ally wrong SlotIdx",
				Q6KV("UnitId", UnitState.UnitId),
				Q6KV("UnitType", UnitState.UnitType),
				Q6KV("Slot", UnitState.Slot));
			return;
		}

		AllyBars[SlotIndex]->InitBar(UnitState, InSpawnReason);
		AUnit* InSpawnUnit = Presenter->FindUnit(UnitState.UnitId);
		if (InSpawnUnit && InSpawnUnit->IsDead())
		{
			// without animation
			AllyBars[SlotIndex]->SetDead(true, true);
		}
		else
		{
			AllyBars[SlotIndex]->SetOverKill(0, UnitState.OverKill);
			AllyBars[SlotIndex]->SetPhase(Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase()));
			AllyBars[SlotIndex]->SetBuffs(UnitState.Buffs, UnitState.PointVaryUnitAttributes, CCBuffIdInvalid);
		}
		AllyBars[SlotIndex]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		if (!EnemyBars.IsValidIndex(SlotIndex))
		{
			Q6JsonLogObiwan(Warning, "OnSpawnUnit Enemy wrong SlotIdx",
				Q6KV("UnitId", UnitState.UnitId),
				Q6KV("UnitType", UnitState.UnitType),
				Q6KV("Slot", UnitState.Slot));
			return;
		}

		EnemyBars[SlotIndex]->SetProvokedState(EProvokedState::Default);

		if (InSpawnReason == ESpawnReason::ChangeCombatMultiSide)
		{
			AUnit* InSpawnUnit = Presenter->FindUnit(UnitState.UnitId);
			if (InSpawnUnit && InSpawnUnit->IsDead())
			{
				EnemyBars[SlotIndex]->SetVisibility(ESlateVisibility::Hidden);
				return;
			}
		}

		EnemyBars[SlotIndex]->InitBar(UnitState, InSpawnReason);
		EnemyBars[SlotIndex]->SetBuffs(UnitState.Buffs, UnitState.PointVaryUnitAttributes, CCBuffIdInvalid);
		EnemyBars[SlotIndex]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const AUnit* EnemyUnit = GetCheckedCombatPresenter(this)->FindUnit(UnitState.UnitId);
		if (EnemyUnit && EnemyUnit->HasUltimateSkills())
		{
			int32 FirstWaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
			int32 CommonWaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;

			const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(UnitState.Ultimates[0].SkillType);
			if (SkillRow.IsInvalid())
			{
				Q6JsonLogGunny(Warning, "UCombatHUDWidget::SetupUnitBarOnSpawn - SkillRow does not exist.",
					Q6KV("SkillType", UnitState.Ultimates[0].SkillType));
				return;
			}

			for (auto Iter : SkillRow.GetSkillEffect())
			{
				if (Iter->EffectCategory == EEffectCategory::FirstWaitTime)
				{
					FirstWaitTime = Iter->Param1;
				}
				else if (Iter->EffectCategory == EEffectCategory::WaitTime)
				{
					CommonWaitTime = Iter->Param1;
				}
			}

			int32 InitialWaitDown = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
			if (FirstWaitTime != CombatCubeConst::Q6_BASE_SKILL_WAITDOWN)
			{
				InitialWaitDown = FirstWaitTime;
			}
			else
			{
				InitialWaitDown = CommonWaitTime;
			}

			EnemyBars[SlotIndex]->SetInitialWaitdown(
				UnitState.Ultimates[0].UsingCount == 0 ? InitialWaitDown : CommonWaitTime);
			EnemyBars[SlotIndex]->SetSkillWaitdown(UnitState.Ultimates[0].WaitDown);
		}
		else
		{
			EnemyBars[SlotIndex]->SetInitialWaitdown(0);
		}
	}
}

void UCombatHUDWidget::SetStageInfo(const ACombatPresenter* CombatPresenter, const FCMSSagaRow& InSagaRow)
{
	int32 TurnCount = CombatPresenter->GetTurnCountForWidget();
	if (InSagaRow.LimitTurn)
	{
		WaveTurnInfoWidget->SetTurnLeftVisibility(true);

		int32 LeftTurn = InSagaRow.LimitTurn - TurnCount;
		WaveTurnInfoWidget->SetTurnLeft(LeftTurn);
	}
	else
	{
		WaveTurnInfoWidget->SetTurnLeftVisibility(false);
		WaveTurnInfoWidget->SetTurnCount(TurnCount);
	}

	if (InSagaRow.LimitTime != 0)
	{
		CombatTimeWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const int64 AccumPlaySecs = FDateTime::UtcNow().ToUnixTimestamp() - GetCheckedCombatPresenter(this)->GetStartBattleEpoch();
		CombatTimeWidget->SetRemainTime(InSagaRow.LimitTime * 60 - AccumPlaySecs);

		CombatTimeWidget->StartTimer();
	}

	switch (InSagaRow.ContentType)
	{
		case EContentType::Raid:
			SetRaidStageInfo();
			break;
		case EContentType::RaidFinal:
			SetRaidFinalStageInfo();
			break;
		default:
			PlayAnimation(HUDStateNormalAnim);
	}
}

void UCombatHUDWidget::SetRaidStageInfo()
{
	RaidEmoticonWidget->SetInfo();
	PlayAnimation(HUDStateRaidAnim);
}

void UCombatHUDWidget::SetRaidFinalStageInfo()
{
	SetPauseButtonEnable(false);
	PlayAnimation(HUDStateNormalAnim);
}

void UCombatHUDWidget::SetRaidMyDamage()
{
	int32 Damage(0);
	TArray<AUnit*> Units = GetCheckedCombatPresenter(this)->FindUnitsByFaction(
		ECCFaction::Enemy);
	for (const AUnit* Unit : Units)
	{
		if (!Unit)
		{
			continue;
		}

		const FUnitState& UnitState = Unit->GetUnitState();
		Damage += UnitState.MaxHealth - UnitState.Health;
		if (Damage < 0)
		{
			Q6JsonLogGenie(Warning, "raid damage overflow", Q6KV("Damage", Damage));
		}
	}

	RaidRankingWidget->SetMyDamage(Damage);
}

void UCombatHUDWidget::SetPauseButtonEnable(bool bInEnable)
{
	PauseButton->SetIsEnabled(bInEnable);
}

void UCombatHUDWidget::AllBlockedForcePhaseChange()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());
	if (TurnPhase != ECPTurnPhase::Steady)
	{
		return;
	}

	bool AllBlocked = true;
	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		const AUnit* Unit = Presenter->FindUnit(AllyBar->GetUnitId());
		if (!Unit)
		{
			continue;
		}

		if (Unit->HasCCBuffEffect(ECrowdControl::Silence) == false
			&& Unit->HasCCBuffEffect(ECrowdControl::Stun) == false)
		{
			AllBlocked = false;
		}
	}

	if (AllBlocked)
	{
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedTextOrKey("Combat", "AlliesStun"));
		GetCheckedCombatCube(this)->ProceedToNextTurn();
	}
}

void UCombatHUDWidget::ClearProvokeTargetEnemyBars()
{
	for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
	{
		EnemyBar->SetProvokedState(EProvokedState::Default);
	}

	GetCheckedCombatPresenter(this)->RestoreSelectTarget();

	bShowProvokedEnemyBar = false;
}

void UCombatHUDWidget::UpdateProvokeTargetEnemyBars(const FCCUnitId InUnitId)
{
	// how to optimize get provoke target unit id - current implementation is check buffs every times.
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	AUnit* Unit = Presenter->FindUnit(InUnitId);
	if (!Unit)
	{
		return;
	}

	if (Unit->GetOverrideFaction() == ECCFaction::Enemy)
	{
		return;
	}

	const FCCUnitId ProvokeTargetUnitId = Unit->GetProvokeTargetUnitId();
	if (ProvokeTargetUnitId != CCUnitIdInvalid)
	{
		for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
		{
			if (EnemyBar->GetUnitId() == ProvokeTargetUnitId)
			{
				EnemyBar->SetProvokedState(EProvokedState::Provoked);
			}
			else
			{
				EnemyBar->SetProvokedState(EProvokedState::NonProvoked);
			}
		}

		// select provoke target forcely
		GetCheckedCombatPresenter(this)->SelectProvokedTarget(ProvokeTargetUnitId);

		bShowProvokedEnemyBar = true;
	}
	else
	{
		ClearProvokeTargetEnemyBars();
	}
}

void UCombatHUDWidget::SetCombatMultiSideWaveInfo()
{
	ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	const int32 WaveIndex = CombatPresenter->GetCombatMultiSideWaveRowIndex();
	const FSagaType SagaType = CombatPresenter->GetCombatSeed().SagaType;
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(SagaType, WaveIndex);
	if (!WaveRow)
	{
		Q6JsonLogPawn(Warning, "CombatMultiSide WaveRow index error", Q6KV("SagaType", SagaType), Q6KV("WaveIndex", WaveIndex));
		return;
	}

	const bool bIsMainParty = CombatPresenter->GetCurrentCombatMultiSide() == ECombatMultiSide::Main;
	WaveWidget->SetZoneName(WaveRow->ZoneName);
	WaveWidget->PlayPartyAnimation(bIsMainParty);
}

void UCombatHUDWidget::OnRaidAssistStartAnimFinished()
{
	OnRaidAssistStartAnimFinishedDelegate.ExecuteIfBound();
}

void UCombatHUDWidget::OnSkillFaildAnimFinished()
{
	OnSkillFailedAnimFinishedDelegate.ExecuteIfBound();
}

void UCombatHUDWidget::OnStartCPPhase(ECPTurnPhase CPPhase)
{
	if (CPPhase == ECPTurnPhase::TurnSkill)
	{
		GetCheckedCombatPresenter(this)->ChangeToTurnSkillPhase();
		// After ChangeToTurnSkillPhase function, You can get correct CPPhase.
		GetCombatTutorial(this)->InitTutorial();

		TArray<FCCUnitId> UltimateReadyEnemyUnitIds = GetCheckedCombatPresenter(this)->FindUltimateReadyEnemyIds();
		OnStartTurnSkillPhase(UltimateReadyEnemyUnitIds);
	}
	else if (CPPhase == ECPTurnPhase::Steady)
	{
		GetCheckedCombatPresenter(this)->ChangeToSteadyPhase();
		// After ChangeToSteadyPhase function, You can get correct CPPhase.
		GetCombatTutorial(this)->InitTutorial();

		AttackButtonWidget->SetAttackButtonEnabled(false);
		SetPauseButtonEnable(false);
		SetAllyTurnSkillPhaseSelectable(false);
		DeselectSelectedTurnUnit();

		PlayAnimation(TurnEndAnim);

		BackTurnButtonWidget->SetOn(true);

		AllBlockedForcePhaseChange();
	}
	else if (CPPhase == ECPTurnPhase::Attack)
	{
		BackTurnButtonWidget->SetOn(false);
	}
	else if (CPPhase == ECPTurnPhase::OppAttack)
	{
		DisableAllyNatureRelations();
	}
	else if (CPPhase == ECPTurnPhase::ChangeCombatMultiSide)
	{
		// Total Damage animaion is not finished when change combat multi side, so stop animation forcely
		TotalDamageWidget->StopAllAnimations();

		// clear versa in widget
		for (UCombatAllyBarWidget* AllyBar : AllyBars)
		{
			AllyBar->SetVersa(false);
		}

		bIgnoreAnimationFinishedEvent = true;
	}
	else if (CPPhase == ECPTurnPhase::Prepare)
	{
		// this variable will be true in combat multi side only
		bIgnoreAnimationFinishedEvent = false;
	}

	OnStartPhaseSettingsInternal(CPPhase);
}

void UCombatHUDWidget::OnBackTurnButtonClicked()
{
	ACombatTutorial* InTutorial = GetCombatTutorial(this);
	if (!InTutorial->IsBackToTurnPhaseEnable())
	{
		return;
	}

	BackFromSteadyPhase();
}

void UCombatHUDWidget::ProceedToSteadyPhase()
{
	GetCheckedCombatCube(this)->GetStore()->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this](FCCUnitId ReqUnitId, FCombatState RepState) {
		if (RepState.CurrentPhase == (int32)ECCTurnPhase::TurnSkill)
		{
			OnStartCPPhase(ECPTurnPhase::Steady);
		}
		else
		{
			ensure(0);
		}
	}));
}

void UCombatHUDWidget::BackFromSteadyPhase()
{
	GetCheckedCombatCube(this)->GetStore()->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this](FCCUnitId ReqUnitId, FCombatState RepState) {
		if (RepState.CurrentPhase == (int32)ECCTurnPhase::TurnSkill)
		{
			OnStartCPPhase(ECPTurnPhase::TurnSkill);
			PetButtonWidget->SetPhase(ECPTurnPhase::TurnSkill);
		}
		else
		{
			ensure(0);
		}
	}));
}

void UCombatHUDWidget::OnPauseButtonClicked()
{
	if (!GetCombatTutorial(this)->IsPauseButtonEnable())
	{
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedTextOrKey("Combat", "PlayMoreToEnablePauseButton"));
		return;
	}

	CombatMenuWidget->OpenWidget();
}

void UCombatHUDWidget::OnSpawnUnit(const UCCSpawnUnitEvent* Event)
{
	FUnitState UnitState;
	UCombatCubeStateUtil::ConvertCCUnitStateToUnitState(Event->UnitState, &UnitState);

	SetupUnitBarOnSpawn(UnitState, Event->SpawnReason);
}

void UCombatHUDWidget::OnDespawnUnit(const UCCDespawnUnitEvent* Event)
{
}

void UCombatHUDWidget::OnFinishWave()
{
	ECCTurnPhase TurnPhase = GetCheckedCombatPresenter(this)->GetTurnPhase();
	if (TurnPhase == ECCTurnPhase::TurnSkill)
	{
		PlayAnimation(TurnEndAnim);
		AttackButtonWidget->SetAttackButtonEnabled(false);
		SetPauseButtonEnable(false);
		BackTurnButtonWidget->SetOn(false);
	}

	PlayAnimation(WaveEndAnim);
}

void UCombatHUDWidget::OnAllyWipeout(const UCCAllyWipeoutEvent* Event)
{
}

void UCombatHUDWidget::OnEndGame(const UCCEndGameEvent* Event)
{
}

void UCombatHUDWidget::OnSkillUsed(const UCCSkillUsedEvent* Event)
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	if (Presenter->IsMaster(Event->UnitId))
	{
		if (Event->SkillCategory == ESkillCategory::Pet)
		{
			PetButtonWidget->SetSkillEnabled(false);
		}

		return;
	}

	AUnit* SourceUnit = Presenter->FindUnit(Event->UnitId);
	if (!SourceUnit)
	{
		return;
	}

	if (SourceUnit->GetOverrideFaction() != ECCFaction::Ally)
	{
		return;
	}

	if (Event->SkillCategory == ESkillCategory::RaidTurnBegin)
	{
		return;
	}

	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());
	if (TurnPhase == ECPTurnPhase::TurnSkill && Event->SkillCategory == ESkillCategory::TurnBegin)
	{
		PlayAnimation(TurnSkillHideAnim);
	}
	else if (TurnPhase == ECPTurnPhase::Attack || TurnPhase == ECPTurnPhase::Steady)
	{
		PetButtonWidget->SetSkillEnabled(false);

		if (Event->SkillCategory == ESkillCategory::Normal)
		{
			UCombatAllyBarWidget* SkillUsedAllyBar = GetAllyBar(Event->UnitId);
			if (SkillUsedAllyBar)
			{
				SkillUsedAllyBar->SetMatchedSkillChordNote(Event->ChordNote);
			}
		}
	}
}

void UCombatHUDWidget::OnSkillFailed(const UCCSkillFailedEvent* Event)
{
	SkillFailedWidget->SetSkillFailed(Event->SkillType, Event->FailedInfo);

	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());
	if (TurnPhase == ECPTurnPhase::TurnSkill)
	{
		SetAllyTurnSkillPhaseSelectable(true);
	}
	else if (TurnPhase == ECPTurnPhase::Attack)
	{
		if (!IsAllyAttackFinished())
		{
			PetButtonWidget->SetSkillEnabled(true);
		}
	}
}

void UCombatHUDWidget::OnSkillStart(const UCCSkillUsedEvent* Event)
{
	if (Event->SkillCategory == ESkillCategory::Versa)
	{
		return;
	}
	else if (Event->SkillCategory != ESkillCategory::Double)
	{
		ResetTotalDamage();
	}

	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());
	if (TurnPhase == ECPTurnPhase::Attack)
	{
		PetButtonWidget->SetSkillEnabled(false);
	}

	FCCUnitId EffectUnitId = CCUnitIdInvalid;
	if (Event->SkillCategory == ESkillCategory::Chain
		|| Event->SkillCategory == ESkillCategory::Artifact
		|| Event->SkillCategory == ESkillCategory::Pet)
	{
		EffectUnitId = Event->TargetUnitId;
	}
	else
	{
		EffectUnitId = Event->UnitId;
	}

	AUnit* EffectUnit = GetCheckedCombatPresenter(this)->FindUnit(EffectUnitId);
	if (!EffectUnit)
	{
		Q6JsonLogSunny(Warning, "UCombatHUDWidget::OnSkillStart - Invalid Unit", Q6KV("UnitId", EffectUnitId));
		return;
	}

	UCombatUnitBarWidget* EffectUnitBar = GetUnitBar(EffectUnitId);
	if (!EffectUnitBar)
	{
		Q6JsonLogSunny(Warning, "UCombatHUDWidget::OnSkillStart - Invalid Unit Bar", Q6KV("UnitId", EffectUnitId));
		return;
	}

	TArray<FBuffEffectState> ProvokeEffects;
	EffectUnit->GatherCCBuffEffects(ProvokeEffects, ECrowdControl::Provoke);
	if (ProvokeEffects.Num())
	{
		EffectUnitBar->AddBuffNotification(ProvokeEffects[0], true);
	}

	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(Event->SkillType);
	switch (Event->SkillCategory)
	{
		case ESkillCategory::TurnBegin:
			{
				SkillCastingNameWidget->SetSkill(SkillRow.DescName, EffectUnit->GetOverrideFaction());
				SkillCastingNameWidget->SetSkillEnabled(true);
			}
			break;
		case ESkillCategory::Chain:
			{
				for (UCombatAllyBarWidget* AllyBar : AllyBars)
				{
					AllyBar->PlayChainEffect();
				}

				if (!ChainEffectWidget->IsPlaying())
				{
					ChainEffectWidget->PlayChainEffect(SkillRow.SkillNote, SkillRow.Desc);
				}
			}
			break;
		case ESkillCategory::Double:
			{
				for (UCombatAllyBarWidget* AllyBar : AllyBars)
				{
					AllyBar->PlayDoubleSkillEffect(AllyBar->GetUnitId() == Event->UnitId);
				}

				if (!ChainEffectWidget->IsPlaying())
				{
					ChainEffectWidget->PlayStraightChainEffect(SkillRow.Desc);
				}
			}
			// fall through
		case ESkillCategory::Normal:
		case ESkillCategory::Ultimate:
			{
				UCombatAllyBarWidget* EffectAllyBar = Cast<UCombatAllyBarWidget>(EffectUnitBar);
				if (EffectAllyBar)
				{
					EffectAllyBar->OnSkillStart();
				}
			}

			if (EffectUnit->GetOverrideFaction() == ECCFaction::Ally)
			{
				UpdateProvokeTargetEnemyBars(Event->UnitId);
			}
			break;
		default:
			break;
	}
}

void UCombatHUDWidget::OnSkillEnd(FCCUnitId InUnitId, ESkillCategory SkillCategory, bool bInPattern)
{
	switch (SkillCategory)
	{
		case ESkillCategory::TurnBegin:
			SkillCastingNameWidget->SetSkillEnabled(false);
			break;
		case ESkillCategory::Double:
		case ESkillCategory::Normal:
		case ESkillCategory::Ultimate:
			{
				UCombatAllyBarWidget* AllyBar = GetAllyBar(InUnitId);
				if (AllyBar)
				{
					AllyBar->OnSkillEnd();
				}

				AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(InUnitId);
				if (!Unit)
				{
					Q6JsonLogPawn(Warning, "UCombatHUDWidget::OnSkillEnd - Invalid Unit", Q6KV("UnitId", InUnitId));
					return;
				}

				if (Unit->GetOverrideFaction() == ECCFaction::Ally)
				{
					ClearProvokeTargetEnemyBars();
				}
			}
			break;
		default:
			break;
	}

	UCombatEnemyBarWidget* EnemyBar = GetEnemyBar(InUnitId);
	if (EnemyBar && SkillCategory == ESkillCategory::Ultimate)
	{
		const AUnit* EnemyUnit = GetCheckedCombatPresenter(this)->FindUnit(InUnitId);
		if (EnemyUnit)
		{
			if (!bInPattern)
			{
				int32 DummySkillWaitdown = INVALID_WAITDOWN;
				int32 InitialWaitdown = 0;
				EnemyUnit->GetNextUltimateSkillWaitdown(DummySkillWaitdown, &InitialWaitdown);
				EnemyBar->SetInitialWaitdown(InitialWaitdown);
				EnemyBar->SetSkillWaitdown(InitialWaitdown);
			}
			else
			{
				EnemyBar->PlayUltimateAlertAnim(false);
			}
		}
	}
}

void UCombatHUDWidget::OnSkillDrivenEffectEnd()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());

	if (TurnPhase == ECPTurnPhase::TurnSkill)
	{
		RefreshAllyTurnSkills();
		PlayAnimation(TurnSkillShowAnim);
		SetAllyTurnSkillPhaseSelectable(true);
	}
	else if (TurnPhase == ECPTurnPhase::Attack)
	{
		if (!IsAllyAttackFinished())
		{
			PetButtonWidget->SetSkillEnabled(true);
		}
	}
}

void UCombatHUDWidget::OnHealthChanged(const UCCUnitHealthChangedEvent* Event)
{
	UCombatUnitBarWidget* UnitBar = GetUnitBar(Event->UnitId);
	if (!UnitBar)
	{
		Q6JsonLogSunny(Warning, "Invalid UnitBar OnHealthChanged", Q6KV("UnitId", Event->UnitId));
		return;
	}

	UnitBar->UpdateHealth(Event->Reason);
}

void UCombatHUDWidget::OnHit(const UUnitHit* HitPerUnit, bool bDamage, bool bShieldDamage, bool bPassOverTotal)
{
	FCCUnitId TargetUnitId = HitPerUnit->TargetUnitId;
	UCombatUnitBarWidget* UnitBar = GetUnitBar(TargetUnitId);
	if (!UnitBar)
	{
		Q6JsonLogObiwan(Warning, "Invalid UnitBar OnHit", Q6KV("UnitId", TargetUnitId));
		return;
	}

	EHealthChangeReason Reason = HitPerUnit->Reason;
	if (Reason == EHealthChangeReason::Damage)
	{
		if (bShieldDamage)
		{
			UnitBar->SetShieldDamage(HitPerUnit->ShieldDamage, HitPerUnit->ExtraShieldDamage, HitPerUnit->bShieldWeakPoint);

			if (bDamage)
			{
				UnitBar->UpdateHealth(Reason, HitPerUnit->HitIndex, HitPerUnit->HitMax);
			}
		}
		else
		{
			UnitBar->UpdateHealth(Reason, HitPerUnit->HitIndex, HitPerUnit->HitMax);
		}

		TotalDamageWidget->SetDamage(HitPerUnit, bPassOverTotal);

		const FCCCombatSeed& CombatSeed = GetCheckedCombatPresenter(this)->GetCombatSeed();
		if (CombatSeed.Content == EContentType::Raid)
		{
			SetRaidMyDamage();
		}
	}
	else
	{
		UnitBar->UpdateHealth(Reason, HitPerUnit->HitIndex, HitPerUnit->HitMax);
	}
}

void UCombatHUDWidget::OnUAChanged(const UCCUnitUAChangedEvent* Event)
{
	UCombatUnitBarWidget* UnitBar = GetUnitBar(Event->UnitId);
	if (!UnitBar)
	{
		Q6JsonLogObiwan(Warning, "Invalid UnitBar OnUAChanged", Q6KV("UnitId", Event->UnitId));
		return;
	}

	UCombatAllyBarWidget* AllyBar = Cast<UCombatAllyBarWidget>(UnitBar);
	if (AllyBar)
	{
		AllyBar->AddUA(Event->AddedUA);
	}
}

void UCombatHUDWidget::OnSAChanged(const UCCUnitSAChangedEvent* Event)
{
	UCombatUnitBarWidget* UnitBar = GetUnitBar(Event->UnitId);
	if (!UnitBar)
	{
		Q6JsonLogObiwan(Warning, "Invalid UnitBar OnSAChanged", Q6KV("UnitId", Event->UnitId));
		return;
	}

	UCombatAllyBarWidget* AllyBar = Cast<UCombatAllyBarWidget>(UnitBar);
	if (AllyBar)
	{
		AllyBar->AddSA(Event->AddedSA);
	}
}

void UCombatHUDWidget::OnSetSkillCooldown(const UCCSetSkillTimeEvent* Event)
{
	PetButtonWidget->UpdateSkillStates();
}

void UCombatHUDWidget::OnSetCheatSkillCooldown(const UCCSetCheatSkillCooldownEvent* Event)
{
	PetButtonWidget->UpdateSkillStates();

	RefreshAllyTurnSkills();
}

void UCombatHUDWidget::OnCreateBuff(const UCCCreateBuffEvent* Event, bool bSkipNoti)
{
	UCombatUnitBarWidget* UnitBar = GetUnitBar(Event->TargetUnitId);
	if (!UnitBar)
	{
		Q6JsonLogSunny(Warning, "UCombatHUDWidget::OnCreateBuff invalid UnitBar", Q6KV("TargetUnitId", Event->TargetUnitId));
		return;
	}

	if (Event->Shield)
	{
		UnitBar->SetShieldState(true);
	}

	UCombatAllyBarWidget* AllyBar = Cast<UCombatAllyBarWidget>(UnitBar);
	if (Event->BornCategory == ESkillCategory::Versa)
	{
		if (AllyBar)
		{
			AllyBar->SetVersa(true);
		}
		return;
	}

	const UCMS* CMS = GetCMS();
	const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(Event->BuffType, EBuffEffectCategory::ModifyCrowdControl);
	for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
	{
		if (!bSkipNoti)
		{
			const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(Event->BuffType));
			UnitBar->AddBuffNotification(FBuffEffectState(FBuffEffectType(BuffEffectRow->Type), BuffRow.Lock), true);
		}

		if (AllyBar)
		{
			const FCMSCrowdControlRow& CCRow = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
			if (CCRow.CrowdControl == ECrowdControl::Versa)
			{
				AllyBar->SetVersa(true);
			}
		}
	}

	const FUnitState& UnitState = GetCheckedCombatPresenter(this)->FindUnit(Event->TargetUnitId)->GetUnitState();
	UnitBar->SetBuffs(UnitState.Buffs, UnitState.PointVaryUnitAttributes, Event->BuffId);

	for (const FBuffState& Buff : UnitState.Buffs)
	{
		if (CMS->GetChangeNatureTypeFromBuff(FBuffType(Buff.BuffType)) != ENatureType::None)
		{
			UnitBar->ChangeNature(UnitState.NatureType);
		}
	}

	if (!Event->IsNew)
	{
		UnitBar->SetBuffsMultiple();
	}
}

void UCombatHUDWidget::OnRemoveBuff(const UCCRemoveBuffEvent* Event, const FBuffType& BuffType)
{
	const int32 NumOfUnitIds = Event->UnitIds.Num();
	for (int32 i = 0; i < NumOfUnitIds; ++i)
	{
		const FCCUnitId UnitId = Event->UnitIds[i];
		UCombatUnitBarWidget* UnitBar = GetUnitBar(UnitId);
		if (!UnitBar)
		{
			Q6JsonLogSunny(Warning, "UCombatHUDWidget::OnRemoveBuff invalid UnitBar", Q6KV("UnitId", UnitId));
			return;
		}

		const UCMS* CMS = GetCMS();
		const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(BuffType, EBuffEffectCategory::ModifyCrowdControl);

		AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
		if (CMS->GetChangeNatureTypeFromBuff(BuffType) != ENatureType::None)
		{
			if (Unit)
			{
				UnitBar->ChangeNature(Unit->GetNature());
			}
		}

		if (Event->Reason == ERemoveBuffReason::Shield)
		{
			UnitBar->SetShieldState(false);
		}
		else
		{
			for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
			{
				const FCMSCrowdControlRow& CCRow = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
				if (CCRow.CrowdControl == ECrowdControl::Shield)
				{
					UnitBar->SetShieldState(false);
					break;
				}
			}
		}

		UCombatAllyBarWidget* AllyBar = Cast<UCombatAllyBarWidget>(UnitBar);
		if (AllyBar)
		{
			if (Unit && !Unit->HasCCBuffEffect(ECrowdControl::Versa))
			{
				if (Event->IsVersa)
				{
					AllyBar->SetVersa(false);
					return;
				}

				for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
				{
					const FCMSCrowdControlRow& CCRow = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
					if (CCRow.CrowdControl == ECrowdControl::Versa)
					{
						AllyBar->SetVersa(false);
						break;
					}
				}
			}
		}

		if (Unit && Unit->GetOverrideFaction() == ECCFaction::Ally)
		{
			for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
			{
				const FCMSCrowdControlRow& CCRow = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
				if (CCRow.CrowdControl == ECrowdControl::Provoke)
				{
					ClearProvokeTargetEnemyBars();
					break;
				}
			}
		}

		UnitBar->RemoveBuff(Event->BuffIds[i].X, Event->Reason);
	}
}

void UCombatHUDWidget::ClearPointVaryUnitAttributes(FCCUnitId InUnitId)
{
	UCombatUnitBarWidget* UnitBar = GetUnitBar(InUnitId);
	if (!UnitBar)
	{
		Q6JsonLogSunny(Warning, "UCombatHUDWidget::ClearPointVaryUnitAttributes invalid UnitBar", Q6KV("UnitId", InUnitId));
		return;
	}

	const FUnitState& UnitState = GetCheckedCombatPresenter(this)->FindUnit(InUnitId)->GetUnitState();
	UnitBar->SetBuffs(UnitState.Buffs, UnitState.PointVaryUnitAttributes, CCBuffIdInvalid);
}

void UCombatHUDWidget::OnDead(FCCUnitId UnitId)
{
	UCombatUnitBarWidget* UnitBar = GetUnitBar(UnitId);
	if (!UnitBar)
	{
		Q6JsonLogSunny(Warning, "UCombatHUDWidget::OnDead invalid UnitBar", Q6KV("UnitId", UnitId));
		return;
	}
	UnitBar->SetDead(true);
}

void UCombatHUDWidget::OnEnemyUltimateReady(const AUnit* EnemyUnit)
{
	PlayAnimation(InDangerStartAnim);

	if (!EnemyUnit || !EnemyUnit->HasUltimateSkills())
	{
		return;
	}

	int32 NextSkillWaitdown = INVALID_WAITDOWN;
	EnemyUnit->GetNextUltimateSkillWaitdown(NextSkillWaitdown);

	UCombatEnemyBarWidget* EnemyBar = GetEnemyBar(EnemyUnit->GetUnitId());
	if (EnemyBar)
	{
		EnemyBar->SetSkillWaitdown(NextSkillWaitdown);
	}
}

void UCombatHUDWidget::RefreshMonsterTarget()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	if (Presenter->TargetMonsterIfCurrentIsDead())
	{
		// OnSelectTarget will handle.
		return;
	}

	Presenter->SetDecalVisible(true);

	UCombatEnemyBarWidget* TargetEnemyBar = GetEnemyBar(SelectedEnemyUnitId);
	if (!TargetEnemyBar)
	{
		return;
	}

	TargetEnemyBar->SetSelectedBar(true);

	UpdateAlliesNatureRelation();
}

void UCombatHUDWidget::UpdateAlliesNatureRelation()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	AUnit* EnemyUnit = Presenter->FindUnit(SelectedEnemyUnitId);
	if (EnemyUnit)
	{
		for (UCombatAllyBarWidget* AllyBar : AllyBars)
		{
			const AUnit* Unit = Presenter->FindUnit(AllyBar->GetUnitId());
			if (!Unit)
			{
				continue;
			}

			AllyBar->SetNatureRelation(Unit->GetOverrideFaction(), Unit->GetNature(), EnemyUnit->GetNature());
		}
	}
	else
	{
		DisableAllyNatureRelations();
	}
}

void UCombatHUDWidget::OnStartTurnSkillPhase(const TArray<FCCUnitId>& SkipCooldownEnemyIds)
{
	PlayAnimation(TurnStartAnim);
	AttackButtonWidget->SetAttackButtonEnabled(true);
	SetPauseButtonEnable(true);
	BackTurnButtonWidget->SetOn(false);

	ResetAttackOrder();

	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);

	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		AllyBar->SetPhase(Presenter->CCPhaseToCPPhase(ECCTurnPhase::TurnSkill));
		AllyBar->UpdateTurnSkillStates();
	}

	PickFirstAliveAlly();
	SetAllyTurnSkillPhaseSelectable(true);

	RefreshMonsterTarget();
	RefreshArtifactButton();

	int32 NextSkillWaitdown = INVALID_WAITDOWN;
	for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
	{
		EnemyBar->SetPhase(Presenter->CCPhaseToCPPhase(ECCTurnPhase::TurnSkill));

		const FCCUnitId EnemyUnitId = EnemyBar->GetUnitId();
		const AUnit* EnemyUnit = Presenter->FindUnit(EnemyUnitId);

		if (!EnemyUnit || !EnemyUnit->HasUltimateSkills())
		{
			continue;
		}

		if (SkipCooldownEnemyIds.Contains(EnemyUnitId))
		{
			continue;
		}

		EnemyUnit->GetNextUltimateSkillWaitdown(NextSkillWaitdown);
		EnemyBar->SetSkillWaitdown(NextSkillWaitdown);
	}

	EContentType ContentType = Presenter->GetCombatSeed().Content;
	if (ContentType == EContentType::Raid)
	{
		RaidTotalBarWidget->SetRaidTotalHealthLastHit();
		RaidRankingWidget->SetRealTimeRankInfo();
	}

	int32 BonusRewardNum = Presenter->GetBossRewardNumber();
	if (BonusRewardNum > 0)
	{
		BonusRewardMarkListWidget->PlayRewardMarkListAnimation(EBonusRewardMarkAnimType::Checked, BonusRewardNum);
	}
}

void UCombatHUDWidget::OnStartTurnPhaseAnimFinished()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());

	for (UCombatAllyBarWidget* AllyBar : AllyBars)
	{
		AllyBar->SetBuffNoticeList(TurnPhase);
	}
	for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
	{
		EnemyBar->SetBuffNoticeList(TurnPhase);
	}

	OnStartTurnPhaseAnimFinishedDelegate.ExecuteIfBound();
}

void UCombatHUDWidget::OnSelectTarget(const FCCUnitId UnitId)
{
	TUTORIAL_MONITORING_BUTTON_CLICK("TargetChanged");

	SelectTarget(UnitId);
}

void UCombatHUDWidget::OnOverKillChanged(const UCCUnitOverKillChangedEvent* Event)
{
	UCombatAllyBarWidget* AllyBar = GetAllyBar(Event->UnitId);
	if (!AllyBar)
	{
		return;
	}

	AllyBar->AddOverKill(Event->AddedOverKill);
}

void UCombatHUDWidget::AddOverKill(FCCUnitId InUnitId, int32 InValue)
{
	UCombatAllyBarWidget* AllyBar = GetAllyBar(InUnitId);
	if (!AllyBar)
	{
		return;
	}

	AllyBar->AddOverKill(InValue);
}

void UCombatHUDWidget::OnPhasePass(FCCUnitId UnitId)
{
	UCombatAllyBarWidget* AllyBar = GetAllyBar(UnitId);
	if (!AllyBar)
	{
		Q6JsonLogSunny(Warning, "UCombatHUDWidget::OnPhasePass invalid AllyBar", Q6KV("UnitId", UnitId));
		return;
	}

	AllyBar->SetAttackPassed();
}

void UCombatHUDWidget::OnRaidTurnSkillEffect(const UCCRaidTurnSkillEffectEvent* Event)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(Event->SkillType);
	RaidAssistTurnWidget->SetInfo(FText::FromString(Event->UserName)
		, SkillRow.DescName
		, Event->CharacterType
		, Event->SkillType);
}

void UCombatHUDWidget::SynchronizeCCState(const FCCCombatCubeState& InState)
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	const FCMSSagaRow& SagaRow = GetCombatSeedSagaRow();

	// 1. Stage Initialize
	{
		SetStageInfo(Presenter, SagaRow);

		WaveTurnInfoWidget->SetCurrentWave(InState.TurnState.WaveCount);
		WaveTurnInfoWidget->SetTotalWave(InState.CombatSeed.Seed.TotalWaveNum);
	}

	// 2. Wave Initialize
	{
		// if this anim not call then main canvas was collapsed.
		PlayAnimation(WaveStartAnim);

		int32 InEnemyNumSlots = InState.TurnState.GetWaveNumSlots();
		for (int32 i = 0; i < EnemyBars.Num(); ++i)
		{
			bool bValidEnemyBar = 1 < InEnemyNumSlots && i < InEnemyNumSlots;
			EnemyBars[i]->SetVisibility(bValidEnemyBar ? ESlateVisibility::Hidden : ESlateVisibility::Collapsed);
		}

		const bool bIsBonusWave = IsBonusWave(InState.TurnState.CurrentWaveIndex);
		WaveWidget->PlayWaveAnimation(InState.TurnState.WaveCount, SagaRow.DescName, bIsBonusWave);
		WaveTurnInfoWidget->SetWaveVisibility(!bIsBonusWave);
		WaveTurnInfoWidget->SetBonusWaveVisibility(bIsBonusWave);

		if (InState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
		{
			SetCombatMultiSideWaveInfo();
		}
	}

	// 3. Turn Initialize
	{
		PlayAnimation(TurnStartAnim);
		TurnPhaseWidget->PlayTurnAnimation(Presenter->GetTurnCountForWidget());
	}

	// 4. Phase Initialize
	{
		WidgetAnimWaitingCount = 0;	// Forced reset for safety
		ResetAttackOrder();

		ECombatMultiSide CurrentCombatMultiSide = InState.TurnState.CurrentCombatMultiSide;
		int32 CurrentWaveIndex = InState.TurnState.CurrentWaveIndex;

		UCombatHUDWidget* InCombatHUDWidget = this;
		Presenter->ForEachUnit([InCombatHUDWidget](AUnit& InUnit) {
			if (InUnit.GetOverrideFaction() == ECCFaction::Enemy && InUnit.IsDead())
			{
				return;
			}

			InCombatHUDWidget->SetupUnitBarOnSpawn(InUnit.GetUnitState(), ESpawnReason::Init);
		});

		EContentType ContentType = Presenter->GetCombatSeed().Content;
		if (ContentType == EContentType::Raid)
		{
			RaidTotalBarWidget->InitRaidTotalHealthBar();
			RaidTotalBarWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

			BonusRewardMarkListWidget->PlayRewardMarkListAnimation(EBonusRewardMarkAnimType::Show, MAX_BONUS_REWARD_MARK);
			BonusRewardMarkListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
		else if (ContentType == EContentType::DailyDungeon)
		{
			if (Presenter->IsLastWave())
			{
				BonusRewardMarkListWidget->PlayRewardMarkListAnimation(EBonusRewardMarkAnimType::Show, MAX_BONUS_REWARD_MARK);
				BonusRewardMarkListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			}
		}

		int32 BonusRewardNum = Presenter->GetBossRewardNumber();
		if (BonusRewardNum > 0)
		{
			BonusRewardMarkListWidget->PlayRewardMarkListAnimation(EBonusRewardMarkAnimType::Checked, BonusRewardNum);
		}

		AttackButtonWidget->SetAttackButtonEnabled(true);
		SetPauseButtonEnable(true);
		BackTurnButtonWidget->SetOn(false);

		for (UCombatAllyBarWidget* AllyBar : AllyBars)
		{
			AllyBar->SynchronizeCCState(InState.TurnState.CurrentPhase);
		}

		for (UCombatEnemyBarWidget* EnemyBar : EnemyBars)
		{
			EnemyBar->SynchronizeCCState(InState.TurnState.CurrentPhase);
		}

		for (int32 i = 0; i < AllyBars.Num(); ++i)
		{
			if (AllyBars.IsValidIndex(i) &&
				!AllyBars[i]->IsDead())
			{
				AllyBars[i]->SetSelectedBar(true);
				SelectedAllyUnitId = AllyBars[i]->GetUnitId();
				SetTurnSkills(SelectedAllyUnitId);
				PlayAnimation(TurnSkillShowAnim);
				SetAllyTurnSkillPhaseSelectable(true);
				break;
			}
		}

		RefreshAllyTurnSkills();
		RefreshArtifactButton();

		const FCCUnitState& MasterState = InState.UnitsState.Masters[(int32)ECCFaction::Ally];
		TArray<FSkillState> SkillStates;
		UCombatCubeStateUtil::ConvertCCSkillStateToSkillState(MasterState.GetSkillStates(ESkillCategory::Pet), &SkillStates);
		PetButtonWidget->Init(Presenter->GetPetType(), SkillStates);

		SelectedEnemyUnitId = InState.TurnState.PlayerTargetUnitId;
	}
}

void UCombatHUDWidget::PostSynchronizeCCState()
{
	RefreshMonsterTarget();
}

UWaveTurnInfoWidget::UWaveTurnInfoWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UWaveTurnInfoWidget::NativeConstruct()
{
	Super::NativeConstruct();

	WaveBorder = CastChecked<UBorder>(GetWidgetFromName("Wave"));
	BonusWaveBorder = CastChecked<UBorder>(GetWidgetFromName("BonusWave"));
	TurnBorder = CastChecked<UBorder>(GetWidgetFromName("Turn"));
	TurnLeftBorder = CastChecked<UBorder>(GetWidgetFromName("TurnLeft"));

	CurrentWaveText = CastChecked<UTextBlock>(GetWidgetFromName("TextCurrentWave"));
	TotalWaveText = CastChecked<UTextBlock>(GetWidgetFromName("TextTotalWave"));
	TurnCountText = CastChecked<UTextBlock>(GetWidgetFromName("TextTurnCount"));
	TurnLeftText = CastChecked<UTextBlock>(GetWidgetFromName("TextTurnLeft"));
}

void UWaveTurnInfoWidget::SetTotalWave(int32 InTotalWave)
{
	TotalWaveText->SetText(
		FText::Format(Q6Util::GetLocalizedText("Combat", "MaxText"), FText::AsNumber(InTotalWave)));
}

void UWaveTurnInfoWidget::SetCurrentWave(int32 InCurrentWave)
{
	CurrentWaveText->SetText(FText::AsNumber(InCurrentWave));
}

void UWaveTurnInfoWidget::SetTurnCount(int32 InTurnCount)
{
	TurnCountText->SetText(FText::AsNumber(InTurnCount));
}

void UWaveTurnInfoWidget::SetTurnLeft(int32 InTurnLeft)
{
	if (InTurnLeft == 1)
	{
		TurnLeftText->SetColorAndOpacity(GetUIResource().GetLackColor());
	}
	else
	{
		TurnLeftText->SetColorAndOpacity(GetUIResource().GetEnoughColor());
	}

	TurnLeftText->SetText(FText::AsNumber(InTurnLeft));
}

void UWaveTurnInfoWidget::SetWaveVisibility(bool bVisible)
{
	WaveBorder->SetVisibility(bVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UWaveTurnInfoWidget::SetBonusWaveVisibility(bool bVisible)
{
	BonusWaveBorder->SetVisibility(bVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UWaveTurnInfoWidget::SetTurnLeftVisibility(bool bVisible)
{
	TurnBorder->SetVisibility(!bVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	TurnLeftBorder->SetVisibility(bVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}
