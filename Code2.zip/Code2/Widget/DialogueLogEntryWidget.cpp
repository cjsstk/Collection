// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "DialogueLogEntryWidget.h"
#include "GameResource.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Components/RichTextBlock.h"
#include "Components/WidgetSwitcher.h"
#include "WidgetUtil.h"
#include "Q6SoundPlayer.h"

UDialogueLogEntryWidget::UDialogueLogEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UDialogueLogEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	Talker1OpenAnim = GetWidgetAnimationFromName(this, "AnimTalker1OpeningLine");
	Talker1ContinueAnim = GetWidgetAnimationFromName(this, "AnimTalker1Continue");
	Talker2OpenAnim = GetWidgetAnimationFromName(this, "AnimTalker2OpeningLine");
	Talker2ContinueAnim = GetWidgetAnimationFromName(this, "AnimTalker2Continue");

	SpeakerName = CastChecked<UTextBlock>(GetWidgetFromName("Speaker"));

	NormalLog = CastChecked<URichTextBlock>(GetWidgetFromName("LogNormal"));
	MonologueLog = CastChecked<URichTextBlock>(GetWidgetFromName("LogMonologue"));
	UserAnswerLog = CastChecked<UTextBlock>(GetWidgetFromName("LogUserAnswer"));

	ChatStageName = CastChecked<UTextBlock>(GetWidgetFromName("StageName"));
	ChatSpeakerName = CastChecked<UTextBlock>(GetWidgetFromName("ChrName"));
	ChatSpeakerImage = CastChecked<UImage>(GetWidgetFromName("ImgCharacter"));
	ChatSpeakBubble = CastChecked<UBorder>(GetWidgetFromName("NormalBubble"));
	ChatSpeakLogBg = CastChecked<UImage>(GetWidgetFromName("LogBgNormal"));
	ChatSpeakText = CastChecked<URichTextBlock>(GetWidgetFromName("TxtChatSpeak"));

	ChatMonologueLogBg = CastChecked<UImage>(GetWidgetFromName("LogBgMonologue"));
	ChatMonologueText = CastChecked<URichTextBlock>(GetWidgetFromName("TxtChatMonologue"));

	DialogueSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("DialogueLines"));

	VoiceButton = CastChecked<UButton>(GetWidgetFromName("Voice"));
	VoiceButton->OnClicked.AddUniqueDynamic(this, &UDialogueLogEntryWidget::OnVoiceButtonClicked);

	VoiceMonologueButton = CastChecked<UButton>(GetWidgetFromName("VoiceMonologue"));
	VoiceMonologueButton->OnClicked.AddUniqueDynamic(this, &UDialogueLogEntryWidget::OnVoiceButtonClicked);

	ChatVoiceButton = CastChecked<UButton>(GetWidgetFromName("ChatVoice"));
	ChatVoiceButton->OnClicked.AddUniqueDynamic(this, &UDialogueLogEntryWidget::OnVoiceButtonClicked);
}

void UDialogueLogEntryWidget::SetTalkLog(EDialogueType InDialogueType, const FText& InName, const FText& InText, const FName& InVoiceName)
{
	DialogueType = InDialogueType;
	VoiceName = InVoiceName;

	ESlateVisibility VoiceVisibility = ESlateVisibility::Collapsed;
	if (!VoiceName.IsNone())
	{
		if (GetSoundPlayer().HasDialogueVoice(DialogueType, VoiceName))
		{
			VoiceVisibility = ESlateVisibility::Visible;
		}
	}

	if (!InName.IsEmpty())
	{
		SwitchWidgets(ELogType::Normal);

		SpeakerName->SetText(InName);
		NormalLog->SetText(InText);
		VoiceButton->SetVisibility(VoiceVisibility);
	}
	else
	{
		SwitchWidgets(ELogType::Monologue);

		MonologueLog->SetText(InText);
		VoiceMonologueButton->SetVisibility(VoiceVisibility);
	}
}

void UDialogueLogEntryWidget::SetChoiceLog(const FText& InText)
{
	SwitchWidgets(ELogType::UserAnswer);

	UserAnswerLog->SetText(InText);
}

void UDialogueLogEntryWidget::SetChatStyle(int32 ChatModel, bool bLeft, bool bContinue)
{
	if (bLeft)
	{
		bool bDummySpeaker = true;

		if (ChatModel > 0)
		{
			const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(ChatModel);
			const TSoftObjectPtr<UTexture2D>& IconTexture = AssetRow.GetDefaultIconTexture();
			if (!IconTexture.IsNull())
			{
				ChatSpeakerImage->SetBrushFromSoftTextureWhenLoadingFinished(IconTexture);
				bDummySpeaker = false;
			}
		}

		if (bDummySpeaker && !DummySpeakerIcon.IsNull())
		{
			ChatSpeakerImage->SetBrushFromTexture(DummySpeakerIcon.LoadSynchronous());
		}

		ChatSpeakText->SetDefaultTextStyle(ChatLeftStyle);

		if (bContinue)
		{
			ChatSpeakBubble->SetBrush(ChatContinueBubble);
			PlayAnimation(Talker1ContinueAnim);
		}
		else
		{
			ChatSpeakBubble->SetBrush(ChatOpenBubble);
			PlayAnimation(Talker1OpenAnim);
		}
	}
	else
	{
		ChatSpeakText->SetDefaultTextStyle(ChatRightStyle);

		if (bContinue)
		{
			ChatSpeakBubble->SetBrush(ChatContinueBubble);
			PlayAnimation(Talker2ContinueAnim);
		}
		else
		{
			ChatSpeakBubble->SetBrush(ChatOpenBubble);
			PlayAnimation(Talker2OpenAnim);
		}
	}
}

void UDialogueLogEntryWidget::SetChatTalk(const FText& InName, const FText& InText)
{
	if (!InName.IsEmpty())
	{
		SwitchWidgets(ELogType::ChatSpeak);

		ChatSpeakerName->SetText(InName);
		ChatSpeakLogBg->SetVisibility(ESlateVisibility::Collapsed);
		ChatSpeakText->SetText(InText);
	}
	else
	{
		SetChatSystem(InText);
	}
}

void UDialogueLogEntryWidget::SetChatSystem(const FText& InText)
{
	SwitchWidgets(ELogType::ChatMonologue);

	ChatMonologueLogBg->SetVisibility(ESlateVisibility::Collapsed);
	ChatMonologueText->SetText(InText);
}

void UDialogueLogEntryWidget::SetChatLog(EDialogueType InDialogueType, const FText& InName, const FText& InText, const FName& InVoiceName)
{
	DialogueType = InDialogueType;
	VoiceName = InVoiceName;

	if (!InName.IsEmpty())
	{
		SwitchWidgets(ELogType::ChatSpeak);

		ChatSpeakerName->SetText(InName);
		ChatSpeakLogBg->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		ChatSpeakText->SetText(InText);

		if (!VoiceName.IsNone())
		{
			if (GetSoundPlayer().HasDialogueVoice(DialogueType, VoiceName))
			{
				ChatVoiceButton->SetVisibility(ESlateVisibility::Visible);
			}
		}
	}
	else
	{
		SetChatSystemLog(InText);
	}
}

void UDialogueLogEntryWidget::SetChatSystemLog(const FText& InText)
{
	SwitchWidgets(ELogType::ChatMonologue);

	ChatMonologueLogBg->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	ChatMonologueText->SetText(InText);
}

void UDialogueLogEntryWidget::SetChatTitleLog(const FText& InAreaName)
{
	SwitchWidgets(ELogType::ChatLogTitle);

	ChatStageName->SetText(InAreaName);
}

void UDialogueLogEntryWidget::SetChatEndLog()
{
	SwitchWidgets(ELogType::ChatLogEnd);
}

void UDialogueLogEntryWidget::SwitchWidgets(ELogType InLogType)
{
	DialogueSwitcher->SetActiveWidgetIndex((int32)InLogType);
}

void UDialogueLogEntryWidget::OnVoiceButtonClicked()
{
	GetSoundPlayer().PlayDialogueVoice(DialogueType, VoiceName);
}
