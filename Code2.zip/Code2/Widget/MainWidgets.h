// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CombatCube/Q6GameState.h"

#include "LobbyHUDWidget.h"
#include "MainWidgets.generated.h"

class UPageSwipeWidget;

UENUM(BlueprintType)
enum class EMainWidgetContentType : uint8
{
	Raid,
	TrainingCenter,
	DailyDungeon,
};

/**
 * Main Lobby HUD Widget
 */
UCLASS()
class Q6_API UMainWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UMainWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void OnLeaveMenu() override;
	virtual void RefreshMenu() override;

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	UFUNCTION(BlueprintImplementableEvent)
	void SetMainWidgetContentState(EMainWidgetContentType Type, bool bLocked);

	UFUNCTION(BlueprintImplementableEvent)
	void SetShow(bool bInShow);

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Main; }

private:
	void SetNewMarks();
	void SetContentState();

	UFUNCTION()
	void OnClearButtonClicked();

	UFUNCTION()
	void OnLobbySettingButtonClicked();

	UFUNCTION()
	void OnSpecialStageButtonClicked();

	UFUNCTION()
	void OnSagaButtonClicked();

	UFUNCTION()
	void OnDailyDungeonButtonClicked();

	UFUNCTION()
	void OnTrainingCenterButtonClicked();

	UFUNCTION()
	void OnRaidButtonClicked();

	UFUNCTION()
	void OnSetEventWidget(UWidget* Widget, int32 PageNum);

	UPROPERTY()
	UTextBlock* EpisodeText;

	UPROPERTY()
	UImage* EpisodePreviewImage;

	UPROPERTY()
	UImage* SagaNewMarkImage;

	UPROPERTY()
	UImage* SpecialNewMarkImage;

	UPROPERTY()
	UImage* RaidNewMarkImage;

	UPROPERTY()
	UImage* TrainingCenterNewMarkImage;

	UPROPERTY()
	UBorder* RegularRaidMarkBorder;

	UPROPERTY()
	UPageSwipeWidget* EventSwipeWidget;

	TMap<int32, FEventContentType> EventPageMap;
	bool bWaitRefresh;
};
