// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "DialogueWidget.h"

#include "GameResource.h"
#include "Q6GameUserSettings.h"
#include "LobbyHUD.h"
#include "Q6.h"
#include "WidgetUtil.h"
#include "CommonWidgets.h"
#include "DialogueLogEntryWidget.h"
#include "DialogueSkipWidget.h"
#include "DialogueSelectWidget.h"
#include "Q6SaveGame.h"
#include "Q6SoundPlayer.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Dialogue"), STAT_OnHSEventByDialogue, STATGROUP_HSTORE);

static const int32 NUM_DIALOGUE_CHOICES = 3;

double UDialogueWidget::FastForwardSeconds = 0.8f;

TAutoConsoleVariable<float> CVarFastForwardNextDuration(
	TEXT("q6.FastForwardNextDuration"),
	0.6,
	TEXT("FastForward duration for show next"),
	ECVF_Cheat);

UDialogueWidget::UDialogueWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, NormalLogPadding(10.0f)
{
	TextingDelay = 0.06f;
	NormalEndDelay = 0.5f;
	AutoEndDelay = 1.0f;
	NoBubbleAutoEndDelay = 3.0f;

	BubbleState = EBubbleState::None;

	TextTick = EBubbleTextTick::None;
	TextTickTime = 0.0f;
	TextBubbleCandidates = 0;

	SoundTick = EBubbleSoundTick::None;
	SoundTickTime = 0.0f;

	FastForwardDeltaSeconds = 0.0f;

	ChatState = EChatState::None;
	LeftChatModel = 0;
	RightChatModel = 0;

	PreSoundType = 0;
	PostSoundType = 0;

	bAutoPlay = false;
	bFastForwarding = false;

	bHoldAutoPlay = false;
	bShowChoice = false;
	bBanChoice = false;
	bEnableNextClick = true;
	bDialogueEnd = false;
}

void UDialogueWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UQ6SaveGame* SaveGame = GetQ6SaveGame();
	if (SaveGame)
	{
		bAutoPlay = SaveGame->IsDialogueAutoPlay();
	}

	// Widget Animations

	NormalModeAnim = GetWidgetAnimationFromName(this, "AnimStateNormal");
	ChatModeAnim = GetWidgetAnimationFromName(this, "AnimStateChatMode");
	InitVisibilityAnim = GetWidgetAnimationFromName(this, "AnimInitVisibility");
	DialogueStartAnim = GetWidgetAnimationFromName(this, "AnimDialogueStart");
	DialogueEndAnim = GetWidgetAnimationFromName(this, "AnimDialogueEnd");
	DialogueAlphaEndAnim = GetWidgetAnimationFromName(this, "AnimDialogueAlphaEnd");
	SelectStartAnim = GetWidgetAnimationFromName(this, "AnimSelectStart");
	SelectEndAnim = GetWidgetAnimationFromName(this, "AnimSelectEnd");
	ClearBubbleAnim = GetWidgetAnimationFromName(this, "AnimClearBubble");
	ResetBubbleAnim = GetWidgetAnimationFromName(this, "AnimResetBubble");
	ShowAreaStartAnim = GetWidgetAnimationFromName(this, "AnimShowAreaStart");
	ShowAreaEndAnim = GetWidgetAnimationFromName(this, "AnimShowAreaEnd");
	ShowUIAnim = GetWidgetAnimationFromName(this, "AnimShowUI");
	HideUIAnim = GetWidgetAnimationFromName(this, "AnimHideUI");
	ShowLogAnim = GetWidgetAnimationFromName(this, "AnimShowLog");
	StateMonologueAnim = GetWidgetAnimationFromName(this, "AnimStateMonologue");
	StateTalkAnim = GetWidgetAnimationFromName(this, "AnimStateTalk");
	StateSystemAnim = GetWidgetAnimationFromName(this, "AnimStateSystem");
	StateThinkAnim = GetWidgetAnimationFromName(this, "AnimStateThink");
	StateQuestAnim = GetWidgetAnimationFromName(this, "AnimStateQuest");
	StateBlackAnim = GetWidgetAnimationFromName(this, "AnimStateBlack");

	DeferredFireTextAnims.Reserve(4);
	DeferredFireTextAnims.Add(ClearBubbleAnim);
	DeferredFireTextAnims.Add(StateMonologueAnim);
	DeferredFireTextAnims.Add(StateTalkAnim);
	DeferredFireTextAnims.Add(StateThinkAnim);

	// Dialogue Panel Widgets

	DialogueBottom = CastChecked<UCanvasPanel>(GetWidgetFromName("DialogueBottom"));
	SystemPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("SystemPanel"));
	ScreenNextButton = CastChecked<UButton>(GetWidgetFromName("ButtonScreenNext"));
	ShowSpeedImage = CastChecked<UImage>(GetWidgetFromName("ShowSpeed"));
	SpeakerBox = CastChecked<UHorizontalBox>(GetWidgetFromName("SpeakerGroup"));
	SpeakerText = CastChecked<UTextBlock>(GetWidgetFromName("TextSpeaker"));
	DialogueText = CastChecked<URichTextBlock>(GetWidgetFromName("RichTextDialogue"));
	SystemText = CastChecked<URichTextBlock>(GetWidgetFromName("TextSystemMessage"));
	StoryLogBack = CastChecked<UBackgroundBlur>(GetWidgetFromName("StoryLog"));
	PressMarkImage = CastChecked<UImage>(GetWidgetFromName("PressMark"));
	AreaNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextAreaName"));
	AreaBorder = CastChecked<UBorder>(GetWidgetFromName("BorderArea"));
	HideUIButton = CastChecked<UButton>(GetWidgetFromName("ButtonHideUI"));
	ShowUIButton = CastChecked<UButton>(GetWidgetFromName("ButtonShowUI"));
	LogButton = CastChecked<UButton>(GetWidgetFromName("ButtonLog"));
	LogCloseButton = CastChecked<UButton>(GetWidgetFromName("ButtonTouchBack"));
	AutoToggleCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("ToggleAuto"));
	LogList = CastChecked<UVerticalList>(GetWidgetFromName("LogLines"));

	AreaTitleText = CastChecked<UTextBlock>(GetWidgetFromName("TitleText"));
	ChatList = CastChecked<UVerticalList>(GetWidgetFromName("ChattingList"));

	ScreenNextButton->OnPressed.AddUniqueDynamic(this, &UDialogueWidget::OnNextButtonPressed);
	ScreenNextButton->OnReleased.AddUniqueDynamic(this, &UDialogueWidget::OnNextButtonReleased);
	ScreenNextButton->OnClicked.AddUniqueDynamic(this, &UDialogueWidget::OnNextButtonClicked);
	HideUIButton->OnClicked.AddUniqueDynamic(this, &UDialogueWidget::OnHideUIButtonClicked);
	ShowUIButton->OnClicked.AddUniqueDynamic(this, &UDialogueWidget::OnShowUIButtonClicked);
	LogButton->OnClicked.AddUniqueDynamic(this, &UDialogueWidget::OnLogButtonClicked);
	AutoToggleCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UDialogueWidget::OnAutoToggleChecked);
	AutoToggleCheckBox->SetCheckedState(bAutoPlay ? ECheckBoxState::Checked : ECheckBoxState::Unchecked);

	LogCloseButton->OnClicked.AddUniqueDynamic(this, &UDialogueWidget::OnLogCloseButtonClicked);
	LogList->TouchButtonDelegate.BindUObject(this, &UDialogueWidget::OnLogCloseButtonClicked);

	// Select Choices Widgets

	ChoiceWidgets.SetNumZeroed(NUM_DIALOGUE_CHOICES);

	for (int32 i = 0; i < NUM_DIALOGUE_CHOICES; ++i)
	{
		FString NameStr = FString::Printf(TEXT("ChoiceWidget%d"), i + 1);
		UDialogueSelectWidget* Widget = CastChecked<UDialogueSelectWidget>(GetWidgetFromName(FName(*NameStr)));
		Widget->OnSelected.BindUObject(this, &UDialogueWidget::OnChoiceSelected);
		Widget->OnSelectEnd.BindUObject(this, &UDialogueWidget::OnChoiceSelectEnd);

		ChoiceWidgets[i] = Widget;
	}

	SkipWidget = CreateWidget<UDialogueSkipWidget>(GetOwningPlayer(), DialogueSkipClass);
	check(SkipWidget);

	SkipWidget->AddToViewport(ZORDER_DIALOGUE_SKIP);
	SkipWidget->SetVisibility(ESlateVisibility::Collapsed);
	SkipWidget->SkipDelegate.BindUObject(this, &UDialogueWidget::OnSkipClicked);
	SkipWidget->BottomSkipDelegate.BindUObject(this, &UDialogueWidget::OnBottomSkipClicked);
}

void UDialogueWidget::NativeDestruct()
{
	SkipWidget->RemoveFromViewport();
	SkipWidget = nullptr;

	Super::NativeDestruct();
}

void UDialogueWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (bFastForwarding)
	{
		const float CurrentTime = GetWorld()->GetTimeSeconds();
		const float PastTime = CurrentTime - FastForwardDeltaSeconds;
		const float Duration = CVarFastForwardNextDuration.GetValueOnGameThread();

		if (PastTime > Duration)
		{
			FastForwardDeltaSeconds = CurrentTime - (PastTime - Duration);
			FireShowNextDialogueDelegate();
		}
	}
	else
	{
		BubbleTextTick();
		BubbleSoundTick();

		if (NextButtonPressedTime.IsSet())
		{
			const float CurrentTime = GetWorld()->GetTimeSeconds();
			const float PastTime = CurrentTime - NextButtonPressedTime.GetValue();
			if (PastTime >= UDialogueWidget::FastForwardSeconds)
			{
				StartFastForward();
			}
		}
	}
}

void UDialogueWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
}

void UDialogueWidget::StartFastForward()
{
	bFastForwarding = true;
	FastForwardDeltaSeconds = GetWorld()->GetTimeSeconds();

	SetPressMarkVisibility(false);

	ShowSpeedImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	GetCheckedLobbyHUD(this)->StopBlackout();

	StopAnimation(ShowAreaStartAnim);
	StopAnimation(ShowAreaEndAnim);

	AreaBorder->SetVisibility(ESlateVisibility::Collapsed);

	StopBubbleSound();

	if (!JumpToEndDeferredFireTextAnims())
	{
		if (IsNormalMode())
		{
			GetTextBlock()->SetMaxFlowLineBreakCandidates(-1);
		}

		SetBubbleTextTick(EBubbleTextTick::None);
	}
}

void UDialogueWidget::StopFastForward()
{
	NextButtonPressedTime.Reset();

	if (bFastForwarding)
	{
		bFastForwarding = false;
		ShowSpeedImage->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UDialogueWidget::ShowSkipWidget(bool bShow)
{
	if (!IsSkipEnabled())
	{
		return;
	}

	if (SkipWidget)
	{
		SkipWidget->ShowSkip(bShow);
	}
}

void UDialogueWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == DialogueEndAnim || Animation == DialogueAlphaEndAnim)
	{
		DialogueEndAnimFinishedDelegate.ExecuteIfBound();
	}

	if (IsNormalMode())
	{
		if (Animation == ClearBubbleAnim)
		{
			PlayAnimation(ResetBubbleAnim);
		}

		for (const UWidgetAnimation* Anim : DeferredFireTextAnims)
		{
			if (Anim == Animation)
			{
				FireBubbleText();
				break;
			}
		}
	}
}

void UDialogueWidget::ProcessAreaName(const FText& AreaName)
{
	if (IsChatMode())
	{
		if (!AreaName.EqualTo(AreaTitleText->GetText()))
		{
			AreaTitleText->SetText(AreaName);

			AddChatTitleLog(AreaName);
			AddChatEndLog();
		}
	}
	else
	{
		if (!bFastForwarding)
		{
			if (!AreaName.IsEmpty())
			{
				AreaNameText->SetText(AreaName);
				PlayAnimation(ShowAreaStartAnim);
			}
			else
			{
				if (AreaBorder->IsVisible() && !IsAnimationPlaying(ShowAreaEndAnim))
				{
					PlayAnimation(ShowAreaEndAnim);
				}
			}
		}
	}
}

UDialogueWidget::EBubbleState UDialogueWidget::GetBubbleState(bool bNoName) const
{
	if (!BubbleFullText.IsEmpty())
	{
		switch (BubbleUIType)
		{
			case EBubbleUIType::Default:
				if (bNoName)
				{
					return EBubbleState::Monologue;
				}
				else
				{
					return EBubbleState::Talk;
				}
				break;
			case EBubbleUIType::System:
				return EBubbleState::System;
			case EBubbleUIType::Think:
				return EBubbleState::Think;
			case EBubbleUIType::Quest:
				return EBubbleState::Quest;
			case EBubbleUIType::Black:
				return EBubbleState::Black;
		}
	}

	return EBubbleState::None;
}

bool UDialogueWidget::IsNeedSpeakerState(EBubbleState State) const
{
	switch (State)
	{
		case EBubbleState::Monologue:
		case EBubbleState::Talk:
		case EBubbleState::Think:
			return true;
	}

	return false;
}

bool UDialogueWidget::ChangeDialogueMode(int32 Mode, const FText& AreaName)
{
	EDialogueMode NewMode = EDialogueMode(Mode);
	if (NewMode == EDialogueMode::None || NewMode == DialogueMode)
	{
		return false;
	}

	if (NewMode == EDialogueMode::Normal)
	{
		PlayAnimation(NormalModeAnim);

		ClearTextBlock();
	}
	else if (NewMode == EDialogueMode::Chat)
	{
		PlayAnimation(ChatModeAnim);

		AreaTitleText->SetText(AreaName);
		ChatList->ClearAll();

		AddChatTitleLog(AreaName);
		AddChatEndLog();
	}
	else
	{
		Q6JsonLogZagal(Warning, "Unknown DialogueMode", Q6KV("Mode", Mode));
		return false;
	}

	DialogueMode = NewMode;
	return true;
}

void UDialogueWidget::ShowDialogueText(const FCMSDialogueRow& InRow)
{
	BubbleFullText = InRow.Bubble;
	SpeakerName = InRow.SpeakerName;
	BubbleUIType = EBubbleUIType(InRow.BubbleUIType);

	if (IsChatMode())
	{
		ShowTextChat(InRow.Speaker1ModelType, InRow.Speaker2ModelType);
	}
	else
	{
		ShowTextNormal();
	}
}

void UDialogueWidget::ShowTextChat(int32 LeftModel, int32 RightModel)
{
	UpdateChatState(LeftModel, RightModel);
	FireBubbleText();
}

void UDialogueWidget::ShowTextNormal()
{
	bool bDeferredFireText = false;

	EBubbleState PrevBubbleState = BubbleState;
	BubbleState = GetBubbleState(SpeakerName.IsEmpty());

	if (BubbleState == EBubbleState::None)
	{
		ClearTextBlock();
	}
	else if (PrevBubbleState != BubbleState)
	{
		switch (BubbleState)
		{
			case EBubbleState::Monologue:
				PlayAnimation(StateMonologueAnim);
				break;
			case EBubbleState::Talk:
				PlayAnimation(StateTalkAnim);
				break;
			case EBubbleState::System:
				PlayAnimation(StateSystemAnim);
				break;
			case EBubbleState::Think:
				PlayAnimation(StateThinkAnim);
				break;
			case EBubbleState::Quest:
				PlayAnimation(StateQuestAnim);
				break;
			case EBubbleState::Black:
				PlayAnimation(StateBlackAnim);
				break;
		}

		ClearTextBlock();
		bDeferredFireText = !IsNoBubbleTextState();
	}
	else
	{
		if (IsNeedSpeakerState(BubbleState))
		{
			if (SpeakerName.EqualTo(SpeakerText->GetText()))
			{
				PlayAnimation(ClearBubbleAnim);
				bDeferredFireText = true;
			}
		}
	}

	if (IsNeedSpeakerState(BubbleState))
	{
		if (!SpeakerName.EqualTo(SpeakerText->GetText()))
		{
			SpeakerText->SetText(SpeakerName);
			SpeakerBox->SetVisibility(SpeakerName.IsEmpty() ?
				ESlateVisibility::Hidden : ESlateVisibility::SelfHitTestInvisible);
		}
	}

	if (!bDeferredFireText)
	{
		FireBubbleText();
	}
}

bool UDialogueWidget::IsNoBubbleTextState() const
{
	switch (BubbleState)
	{
		case EBubbleState::System:
		case EBubbleState::Quest:
		case EBubbleState::Black:
			return true;
	}

	return false;
}

void UDialogueWidget::FireBubbleText()
{
	if (IsChatMode())
	{
		FireChatBubble();
	}
	else
	{
		FireNormalBubble();
	}

	AddTextLog();

	if (!bFastForwarding)
	{
		PlayBubbleSound(EBubbleSoundTick::Pre);
		ShowBubble();

		if (IsNoBubbleTextState())
		{
			BreakBubble();
		}
	}
}

void UDialogueWidget::FireNormalBubble()
{
	int32 MaxCandidates = bFastForwarding ? -1 : 0;

	GetTextBlock()->SetText(BubbleFullText);
	GetTextBlock()->SetMaxFlowLineBreakCandidates(MaxCandidates);
	GetTextBlock()->ForceLayoutPrepass();

	SetPressMarkVisibility(false);
}

void UDialogueWidget::FireChatBubble()
{
	UDialogueLogEntryWidget* NewChat = Cast<UDialogueLogEntryWidget>(ChatList->AddNewChild());
	if (!NewChat)
	{
		return;
	}

	if (ChatState == EChatState::System)
	{
		NewChat->SetChatSystem(BubbleFullText);
	}
	else
	{
		SetChatEntryStyle(NewChat);

		NewChat->SetChatTalk(SpeakerName, BubbleFullText);
	}

	ChatList->ScrollToEnd();
}

void UDialogueWidget::ClearTextBlock()
{
	URichTextBlock* TextBlock = GetTextBlock();
	
	TextBlock->SetText(FText::GetEmpty());
	TextBlock->SetMaxFlowLineBreakCandidates(0);
	TextBlock->ForceLayoutPrepass();
}

void UDialogueWidget::UpdateChatState(int32 LeftModel, int32 RightModel)
{
	if (SpeakerName.IsEmpty() || BubbleUIType != EBubbleUIType::Default)
	{
		ChatState = EChatState::System;
		LeftChatModel = 0;
		RightChatModel = 0;
		return;
	}

	if (LeftModel > 0)
	{
		if (LeftChatModel != LeftModel)
		{
			ChatState = EChatState::LeftBegin;
			LeftChatModel = LeftModel;
			RightChatModel = 0;
		}
		else
		{
			ChatState = EChatState::LeftContinue;
		}
	}
	else if (RightModel > 0)
	{
		if (RightChatModel != RightModel)
		{
			ChatState = EChatState::RightBegin;
			LeftChatModel = 0;
			RightChatModel = RightModel;
		}
		else
		{
			ChatState = EChatState::RightContinue;
		}
	}
	else
	{
		ChatState = EChatState::None;
		LeftChatModel = 0;
		RightChatModel = 0;

		Q6JsonLogZagal(Warning, "Invalid Chat State");
	}
}

void UDialogueWidget::SetChatEntryStyle(UDialogueLogEntryWidget* Entry)
{
	switch (ChatState)
	{
		case EChatState::LeftBegin:
			Entry->SetChatStyle(LeftChatModel, true, false);
			break;
		case EChatState::LeftContinue:
			Entry->SetChatStyle(0, true, true);
			break;
		case EChatState::RightBegin:
			Entry->SetChatStyle(0, false, false);
			break;
		case EChatState::RightContinue:
			Entry->SetChatStyle(0, false, true);
			break;
	}
}

bool UDialogueWidget::IsAutoPlaying() const
{
	return (bAutoPlay && !bHoldAutoPlay);
}

bool UDialogueWidget::IsBubbleShowing() const
{
	return (TextTick != EBubbleTextTick::None);
}

bool UDialogueWidget::IsSoundPlaying() const
{
	return (SoundTick != EBubbleSoundTick::None);
}

bool UDialogueWidget::IsSkipEnabled() const
{
	return (DialogueType != EDialogueType::Vacation);
}

void UDialogueWidget::ShowBubble()
{
	SetBubbleTextTick(EBubbleTextTick::Bubble);
	TextBubbleCandidates = 0;
}

void UDialogueWidget::BreakBubble()
{
	if (TextTick == EBubbleTextTick::Bubble)
	{
		if (IsNormalMode())
		{
			GetTextBlock()->SetMaxFlowLineBreakCandidates(-1);
		}

		if (IsAutoPlaying())
		{
			SetBubbleTextTick(EBubbleTextTick::AutoWaitSound);
		}
		else
		{
			SetBubbleTextTick(EBubbleTextTick::EndWait);
		}
	}
	else if (TextTick == EBubbleTextTick::AutoWaitSound)
	{
		SetBubbleTextTick(EBubbleTextTick::EndWait);
	}
}

void UDialogueWidget::SetBubbleTextTick(EBubbleTextTick InTick)
{
	TextTick = InTick;
	TextTickTime = GetWorld()->GetTimeSeconds();
}

namespace
{
	const float SpeedMultiply[] = { 0.4f, 0.7f, 1.0f, 1.3f, 1.6f };
}

float UDialogueWidget::GetScaledTextingDelay() const
{
	auto TextSpeedIndex = UQ6GameUserSettings::Get() ? FMath::RoundToInt(UQ6GameUserSettings::Get()->GetGameSettingData().TextSpeed * 4) : 2;
	TextSpeedIndex = FMath::Clamp(TextSpeedIndex, 0, 4);
	return TextingDelay / SpeedMultiply[TextSpeedIndex];
}

float UDialogueWidget::GetScaledTextEndDelay() const
{
	auto TextSpeedIndex = UQ6GameUserSettings::Get() ? FMath::RoundToInt(UQ6GameUserSettings::Get()->GetGameSettingData().AutoTextSpeed * 4) : 2;
	TextSpeedIndex = FMath::Clamp(TextSpeedIndex, 0, 4);
	return GetTextEndDelay() / SpeedMultiply[TextSpeedIndex];
}

void UDialogueWidget::BubbleTextTick()
{
	if (TextTick == EBubbleTextTick::None)
	{
		return;
	}

	if (TextTick == EBubbleTextTick::Bubble)
	{
		bool bMoveNext = false;

		if (IsChatMode())
		{
			bMoveNext = true;
		}
		else
		{
			URichTextBlock* TextBlock = GetTextBlock();
			int32 MaxCandidates = TextBlock->GetTotalLineBreakCandidateCount();

			if (TextBubbleCandidates < MaxCandidates)
			{
				float TimeSeconds = GetWorld()->GetTimeSeconds();

				const float ScaledTextingDelay = GetScaledTextingDelay();
				if (TextTickTime + ScaledTextingDelay <= TimeSeconds)
				{
					++TextBubbleCandidates;
					TextTickTime += ScaledTextingDelay;

					TextBlock->SetMaxFlowLineBreakCandidates(TextBubbleCandidates);
				}
			}

			bMoveNext = (TextBubbleCandidates >= MaxCandidates);
		}

		if (bMoveNext)
		{
			if (IsAutoPlaying())
			{
				SetBubbleTextTick(EBubbleTextTick::AutoWaitSound);
			}
			else
			{
				SetBubbleTextTick(EBubbleTextTick::EndWait);
			}
		}
	}
	else if (TextTick == EBubbleTextTick::AutoWaitSound)
	{
		if (!IsSoundPlaying())
		{
			SetBubbleTextTick(EBubbleTextTick::EndWait);
		}
	}
	else if (TextTick == EBubbleTextTick::EndWait)
	{
		float EndTimeSeconds = TextTickTime + GetScaledTextEndDelay();
		float TimeSeconds = GetWorld()->GetTimeSeconds();

		if (EndTimeSeconds <= TimeSeconds)
		{
			SetBubbleTextTick(EBubbleTextTick::None);

			if (IsAutoPlaying())
			{
				FireShowNextDialogueDelegate();
			}
			else
			{
				SetPressMarkVisibility(true);
			}
		}
	}
}

void UDialogueWidget::ShowChoices(const FCMSDialogueRow& InRow, const TArray<FText>& Choices, bool bInBanChoice)
{
	for (int32 i = 0; i < NUM_DIALOGUE_CHOICES; ++i)
	{
		UDialogueSelectWidget* Widget = ChoiceWidgets[i];

		if (Choices.IsValidIndex(i))
		{
			Widget->SetChoice(i, Choices[i], DialogueMode);
		}
		else
		{
			Widget->SetVisibility(ESlateVisibility::Collapsed);
		}
	}

	SpeakerName = InRow.SpeakerName;
	BubbleUIType = EBubbleUIType(InRow.BubbleUIType);

	bHoldAutoPlay = true;
	bShowChoice = true;
	bBanChoice = bInBanChoice;

	if (IsChatMode())
	{
		UpdateChatState(InRow.Speaker1ModelType, InRow.Speaker2ModelType);
	}

	PlayAnimation(SelectStartAnim);
	SetPressMarkVisibility(false);

	StopFastForward();
}

void UDialogueWidget::SetSoundData(const FName& InVoiceName, const FCMSDialogueRow& InRow)
{
	VoiceName = InVoiceName;
	PreSoundType = InRow.PreSoundType;
	PostSoundType = InRow.PostSoundType;
}

void UDialogueWidget::EnableNextClick(bool bEnable)
{
	bEnableNextClick = bEnable;

	SetPressMarkVisibility(bEnableNextClick);
}

void UDialogueWidget::InitWidget(EDialogueType InDialogueType, const FText& InSummary)
{
	BubbleFullText = FText::GetEmpty();
	SpeakerName = FText::GetEmpty();

	DialogueType = InDialogueType;
	DialogueMode = EDialogueMode::Normal;
	SummaryText = InSummary;

	SpeakerText->SetText(FText::GetEmpty());
	DialogueText->SetText(FText::GetEmpty());
	SystemText->SetText(FText::GetEmpty());

	AreaBorder->SetVisibility(ESlateVisibility::Collapsed);

	BubbleState = EBubbleState::None;

	TextTick = EBubbleTextTick::None;
	TextTickTime = 0.0f;
	TextBubbleCandidates = 0;

	SoundTick = EBubbleSoundTick::None;
	SoundTickTime = 0.0f;

	ChatState = EChatState::None;
	LeftChatModel = 0;
	RightChatModel = 0;

	VoiceName = NAME_None;
	PreSoundType = 0;
	PostSoundType = 0;

	bHoldAutoPlay = false;
	bShowChoice = false;
	bBanChoice = false;
	bDialogueEnd = false;

	EnableNextClick(true);
	SetPressMarkVisibility(false);

	PlayAnimation(InitVisibilityAnim);
	StopAnimation(InitVisibilityAnim);

	LogList->ClearAll();
	ChatList->ClearAll();
}

void UDialogueWidget::ShowTopOnly()
{
	DialogueBottom->SetVisibility(ESlateVisibility::Collapsed);
	SystemPanel->SetVisibility(ESlateVisibility::Collapsed);
	BubbleState = EBubbleState::None;

	SetPressMarkVisibility(false);
}

void UDialogueWidget::HideForStorySequence(bool bHide)
{
	if (bHide)
	{
		SetVisibility(ESlateVisibility::Hidden);
		SkipWidget->ShowBottomSkip(true);
	}
	else
	{
		SetVisibility(ESlateVisibility::Visible);
		SkipWidget->ShowBottomSkip(false);
	}
}

void UDialogueWidget::OnDialogueStart()
{
	PlayAnimation(DialogueStartAnim);
	ShowSkipWidget(true);
}

void UDialogueWidget::OnDialogueEnd(bool bAlpha)
{
	if (bDialogueEnd)
	{
		return;
	}

	EnableNextClick(false);

	bHoldAutoPlay = false;
	bShowChoice = false;
	bBanChoice = false;
	bDialogueEnd = true;

	if (bAlpha)
	{
		PlayAnimation(DialogueAlphaEndAnim);
	}
	else
	{
		PlayAnimation(DialogueEndAnim);
	}

	StopFastForward();
}

void UDialogueWidget::OnDialogueEndHiding()
{
	ShowSkipWidget(false);
}

void UDialogueWidget::BubbleSoundTick()
{
	if (!IsSoundPlaying())
	{
		return;
	}

	float CurrentTime = GetWorld()->GetTimeSeconds();
	if (SoundTickTime < CurrentTime)
	{
		switch (SoundTick)
		{
			case EBubbleSoundTick::Pre:
				PlayBubbleSound(EBubbleSoundTick::Voice);
				break;
			case EBubbleSoundTick::Voice:
				PlayBubbleSound(EBubbleSoundTick::Post);
				break;
			case EBubbleSoundTick::Post:
			default:
				SoundTick = EBubbleSoundTick::None;
				SoundTickTime = 0.0f;
				break;
		}
	}
}

void UDialogueWidget::PlayBubbleSound(EBubbleSoundTick BeginTick)
{
	SoundTickTime = GetWorld()->GetTimeSeconds();

	switch (BeginTick)
	{
		case EBubbleSoundTick::Pre:
			if (PreSoundType > 0)
			{
				SoundTickTime += GetSoundPlayer().PlayDialogueSound(PreSoundType);
				SoundTick = EBubbleSoundTick::Pre;
				break;
			}
		case EBubbleSoundTick::Voice:
			if (GetSoundPlayer().HasDialogueVoice(DialogueType, VoiceName))
			{
				SoundTickTime += GetSoundPlayer().PlayDialogueVoice(DialogueType, VoiceName);
				SoundTick = EBubbleSoundTick::Voice;
				break;
			}
		case EBubbleSoundTick::Post:
			if (PostSoundType > 0)
			{
				SoundTickTime += GetSoundPlayer().PlayDialogueSound(PostSoundType);
				SoundTick = EBubbleSoundTick::Post;
				break;
			}
		default:
			SoundTick = EBubbleSoundTick::None;
			SoundTickTime = 0.0f;
			break;
	}
}

void UDialogueWidget::StopBubbleSound()
{
	if (IsSoundPlaying())
	{
		GetSoundPlayer().StopDialogueVoice();

		SoundTick = EBubbleSoundTick::None;
		SoundTickTime = 0.0f;
	}
}

URichTextBlock* UDialogueWidget::GetTextBlock()
{
	switch (BubbleUIType)
	{
		case EBubbleUIType::System:
		case EBubbleUIType::Quest:
			return SystemText;
	}

	return DialogueText;
}

float UDialogueWidget::GetTextEndDelay() const
{
	if (bAutoPlay)
	{
		if (IsNoBubbleTextState())
		{
			return NoBubbleAutoEndDelay;
		}
		else
		{
			return AutoEndDelay;
		}
	}

	return NormalEndDelay;
}

void UDialogueWidget::FireShowNextDialogueDelegate(bool bBreakable)
{
	if (GetCheckedLobbyHUD(this)->IsWorkingBlackout() || bShowChoice)
	{
		return;
	}

	if (!JumpToEndDeferredFireTextAnims())
	{
		if (IsBubbleShowing())
		{
			if (bBreakable)
			{
				BreakBubble();
			}
		}
		else
		{
			StopBubbleSound();

			ShowNextDialogueDelegate.ExecuteIfBound();
		}
	}
}

void UDialogueWidget::SetPressMarkVisibility(bool bVisible)
{
	if (bVisible)
	{
		if (!bAutoPlay && !IsBubbleShowing() && bEnableNextClick)
		{
			PressMarkImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
	}
	else
	{
		PressMarkImage->SetVisibility(ESlateVisibility::Collapsed);
	}
}

bool UDialogueWidget::JumpToEndDeferredFireTextAnims()
{
	bool bAnyAnimPlaying = false;

	for (UWidgetAnimation* Anim : DeferredFireTextAnims)
	{
		if (IsAnimationPlaying(Anim))
		{
			float EndTime = Anim->GetEndTime();
			PlayAnimationTimeRange(Anim, EndTime, EndTime);
			bAnyAnimPlaying = true;
		}
	}

	return bAnyAnimPlaying;
}

void UDialogueWidget::OnNextButtonPressed()
{
	NextButtonPressedTime = GetWorld()->GetTimeSeconds();
}

void UDialogueWidget::OnNextButtonReleased()
{
	StopFastForward();
}

void UDialogueWidget::OnNextButtonClicked()
{
	if (bEnableNextClick)
	{
		FireShowNextDialogueDelegate();
	}
}

void UDialogueWidget::OnChoiceSelected(int32 Index)
{
	for (UDialogueSelectWidget* Widget : ChoiceWidgets)
	{
		Widget->PlaySelection(Index);
	}
}

void UDialogueWidget::OnChoiceSelectEnd(int32 Index)
{
	if (ChoiceWidgets.IsValidIndex(Index))
	{
		BubbleFullText = ChoiceWidgets[Index]->GetText();
	}

	if (IsChatMode())
	{
		FireChatBubble();
	}

	AddChoiceLog();
	BanChoiceDelegate.ExecuteIfBound(Index, bBanChoice);

	PlayAnimation(SelectEndAnim);

	bHoldAutoPlay = false;
	bShowChoice = false;

	FireShowNextDialogueDelegate();
}

void UDialogueWidget::OnSkipClicked()
{
	if (bDialogueEnd)
	{
		return;
	}

	static const FText TitleText = Q6Util::GetLocalizedText("Lobby", "DialogueSkipTitle");

	UConfirmPopupWidget* SkipConfirmPopup = GetCheckedLobbyHUD(this)->OpenConfirmPopup(TitleText, SummaryText);
	SkipConfirmPopup->OnDismissButtonClickedDelegate.BindUObject(this, &UDialogueWidget::OnSkipConfirmDismiss);
	SkipConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UDialogueWidget::OnSkipConfirmed);

	bHoldAutoPlay = true;
}

void UDialogueWidget::OnSkipConfirmed(EConfirmPopupFlag InFlag)
{
	bHoldAutoPlay = false;

	if (InFlag == EConfirmPopupFlag::Yes)
	{
		SkipConfirmedDelegate.ExecuteIfBound();
	}
	else
	{
		if (IsAutoPlaying())
		{
			FireShowNextDialogueDelegate();
		}
	}
}

void UDialogueWidget::OnSkipConfirmDismiss()
{
	bHoldAutoPlay = false;

	if (IsAutoPlaying())
	{
		FireShowNextDialogueDelegate();
	}
}

void UDialogueWidget::OnBottomSkipClicked()
{
	BottomSkipDelegate.ExecuteIfBound();
}

void UDialogueWidget::OnLogButtonClicked()
{
	LogList->ScrollToEnd();

	bHoldAutoPlay = true;
	PlayAnimation(ShowLogAnim);

	ShowSkipWidget(false);
}

void UDialogueWidget::OnLogCloseButtonClicked()
{
	StopBubbleSound();

	StoryLogBack->SetVisibility(ESlateVisibility::Collapsed);
	ShowSkipWidget(true);

	bHoldAutoPlay = false;

	if (IsAutoPlaying())
	{
		FireShowNextDialogueDelegate();
	}
}

void UDialogueWidget::OnHideUIButtonClicked()
{
	bHoldAutoPlay = true;
	PlayAnimation(HideUIAnim);

	ShowSkipWidget(false);
}

void UDialogueWidget::OnShowUIButtonClicked()
{
	ShowSkipWidget(true);

	PlayAnimation(ShowUIAnim);
	bHoldAutoPlay = false;

	if (IsAutoPlaying())
	{
		FireShowNextDialogueDelegate();
	}
}

void UDialogueWidget::OnAutoToggleChecked(bool bChecked)
{
	bAutoPlay = bChecked;

	UQ6SaveGame* SaveGame = GetQ6SaveGame();
	if (SaveGame)
	{
		SaveGame->SetDialogueAutoPlay(bAutoPlay);
	}

	if (bAutoPlay)
	{
		SetPressMarkVisibility(false);
		FireShowNextDialogueDelegate(false);
	}
}

void UDialogueWidget::AddTextLog()
{
	if (IsChatMode())
	{
		UDialogueLogEntryWidget* NewLog = Cast<UDialogueLogEntryWidget>(LogList->GetLastChild());
		if (NewLog)
		{
			if (ChatState == EChatState::System)
			{
				NewLog->SetChatSystemLog(BubbleFullText);
			}
			else
			{
				SetChatEntryStyle(NewLog);

				FName ChatVoiceName;
				if (LeftChatModel > 0)
				{
					ChatVoiceName = VoiceName;
				}

				NewLog->SetChatLog(DialogueType, SpeakerName, BubbleFullText, ChatVoiceName);
			}
		}

		AddChatEndLog();
	}
	else
	{
		UDialogueLogEntryWidget* NewLog = Cast<UDialogueLogEntryWidget>(LogList->AddNewChild(NormalLogPadding));
		if (NewLog)
		{
			NewLog->SetTalkLog(DialogueType, SpeakerName, BubbleFullText, VoiceName);
		}
	}
}

void UDialogueWidget::AddChoiceLog()
{
	if (IsChatMode())
	{
		UDialogueLogEntryWidget* NewLog = Cast<UDialogueLogEntryWidget>(LogList->GetLastChild());
		if (NewLog)
		{
			SetChatEntryStyle(NewLog);
			NewLog->SetChatLog(DialogueType, SpeakerName, BubbleFullText, NAME_None);
		}

		AddChatEndLog();
	}
	else
	{
		UDialogueLogEntryWidget* NewLog = Cast<UDialogueLogEntryWidget>(LogList->AddNewChild(NormalLogPadding));
		if (NewLog)
		{
			NewLog->SetChoiceLog(BubbleFullText);
		}
	}
}

void UDialogueWidget::AddChatTitleLog(const FText& AreaName)
{
	UDialogueLogEntryWidget* NewLog = Cast<UDialogueLogEntryWidget>(LogList->AddNewChild());
	if (NewLog)
	{
		NewLog->SetChatTitleLog(AreaName);
	}
}

void UDialogueWidget::AddChatEndLog()
{
	UDialogueLogEntryWidget* NewLog = Cast<UDialogueLogEntryWidget>(LogList->AddNewChild());
	if (NewLog)
	{
		NewLog->SetChatEndLog();
	}
}
