// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6UiDefine.h"
#include "UMG.h"

#include "MediaPlayerWidget.generated.h"


class UMediaPlayer;
class UFileMediaSource;

/*
* UMediaPlayerWidget
*/

DECLARE_MULTICAST_DELEGATE(FMediaPlayFinished);

UCLASS()
class Q6_API UMediaPlayerWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UMediaPlayerWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	bool OpenSource(UFileMediaSource* MediaSource, FSimpleDelegate InFinishedCallback);

	UFUNCTION(BlueprintImplementableEvent)
	void OnMediaOpenedInitialize();

	UFUNCTION(BlueprintCallable)
	void CloseMediaPlayer();

	UFUNCTION(BlueprintCallable)
	UMediaPlayer* GetMediaPlayer() const;

	FMediaPlayFinished& GetMediaPlayFinished() { return OnMediaPlayFinished; };
private:
	UFUNCTION()
	void OnMediaFinished();

	UFUNCTION()
	void OnMediaOpened(FString OpenedUrl);

	UPROPERTY(EditAnywhere, Category = Movie, meta = (AllowPrivateAccess = "true"))
	UMediaPlayer* MediaPlayer;

	FMediaPlayFinished OnMediaPlayFinished;
};