// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "PopupWidgets.h"

#include "BagItemManager.h"
#include "BaseHUD.h"
#include "BondManager.h"
#include "CharacterManager.h"
#include "CharacterWidgets.h"
#include "CMSTable.h"
#include "CombatHUD.h"
#include "CombatPresenter.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "ItemWidgets.h"
#include "JokerSetManager.h"
#include "LevelUtil.h"
#include "LobbyHUD.h"
#include "LobbyObj_gen.h"
#include "MailManager.h"
#include "MailWidgets.h"
#include "PartyManager.h"
#include "PartyWidgets.h"
#include "PetManager.h"
#include "PointWidgets.h"
#include "PowerPlantManager.h"
#include "PyramidManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "Q6UIDefine.h"
#include "RaidManager.h"
#include "RelicManager.h"
#include "Components/RichTextBlock.h"
#include "SculptureManager.h"
#include "ShopManager.h"
#include "SummonManager.h"
#include "SystemConst_gen.h"
#include "TempleManager.h"
#include "UpgradeWidgets.h"
#include "WonderWidgets.h"
#include "ShopWidgets.h"
#include "SystemConstHelper.h"
#include "Q6CombatGameMode.h"
#include "Q6SaveGame.h"

UPopupBaseWidget::UPopupBaseWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bUsingDismissButton(true)
	, PopupKind(EPopupKind::Info)
	, PopupCloseTime(0.f)
	, ElapsedTime(0.f)
	, PopupOrder(0)
	, bAutoClose(false)
	, bOpened(false)
{}

bool UPopupBaseWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	DismissButton = Cast<UButton>(FindChildWidgetFromName("Dismiss"));
	ensure(DismissButton);

	return true;
}

void UPopupBaseWidget::NativeConstruct()
{
	Super::NativeConstruct();

	check(DismissButton);
	DismissButton->OnClicked.AddUniqueDynamic(this, &UPopupBaseWidget::OnDismissButtonClicked);

	OpenAnim = GetNullableWidgetAnimationFromName(this, "AnimOpen");
	CloseAnim = GetNullableWidgetAnimationFromName(this, "AnimClose");

	DismissButton->SetVisibility(ESlateVisibility::Visible);
}

void UPopupBaseWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (!bAutoClose)
	{
		return;
	}

	if (ElapsedTime < PopupCloseTime)
	{
		ElapsedTime += InDeltaTime;
		return;
	}

	ClosePopup();
}

void UPopupBaseWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == CloseAnim)
	{
		RemoveFromParent();
	}
}

void UPopupBaseWidget::OpenPopup(int32 InPopupOrder)
{
	if (InPopupOrder == PopupOrderInvalid)
	{
		Q6JsonLogRoze(Error, "UPopupWidget::OpenPopup - Invalid popup order");
		return;
	}

	PopupOrder = InPopupOrder;
	bOpened = true;

	AddToViewport(ZORDER_POPUP + PopupOrder);
	PlayAnimation(OpenAnim);
}

void UPopupBaseWidget::SetCancelable(bool bInCancelable)
{
	bUsingDismissButton = bInCancelable;
}

void UPopupBaseWidget::SetAutoCloseTime(float InTime)
{
	bAutoClose = true;
	PopupCloseTime = InTime;
}

void UPopupBaseWidget::ClosePopup()
{
	bool bWasOpened = bOpened;
	PopupOrder = PopupOrderInvalid;
	bOpened = false;
	ElapsedTime = 0.f;

	if (CloseAnim)
	{
		// Not immediately removed in viewport.
		PlayAnimation(CloseAnim);
	}
	else
	{
		RemoveFromParent();
	}

	if (bWasOpened)
	{
		OnPopupClosedDelegateForHUD.ExecuteIfBound();
		OnPopupClosedDelegate.ExecuteIfBound();
	}
}

bool UPopupBaseWidget::IsOpened()
{
	return bOpened;
}

int32 UPopupBaseWidget::GetOrder()
{
	if (IsOpened())
	{
		return PopupOrder;
	}

	return PopupOrderInvalid;
}

void UPopupBaseWidget::OnDismissButtonClicked()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("PopupBase_Dismiss");

	OnDismissButtonClickedDelegate.ExecuteIfBound();

	if (!bUsingDismissButton)
	{
		return;
	}

	if (OnBack())
	{
		ClosePopup();
	}
}

////////////////////////////////////////////////////////////////////////////////
// UPopupWidget

UPopupWidget::UPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{}

bool UPopupWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	TitleText = Cast<URichTextBlock>(FindChildWidgetFromName("Title"));
	BottomNamedSlot = Cast<UNamedSlot>(FindChildWidgetFromName("BottomSlot"));

	return true;
}

void UPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetTitle(PopupTitle);
}

void UPopupWidget::SetTitle(const FText& Title)
{
	if (TitleText)
	{
		TitleText->SetText(Title);
	}
}

void UPopupWidget::SetBottomVisible(bool bVisible)
{
	if (BottomNamedSlot)
	{
		BottomNamedSlot->SetVisibility(bVisible ?
			ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}


////////////////////////////////////////////////////////////////////////////////
// UConfirmPopupWidget

UConfirmPopupWidget::UConfirmPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bNoGoBackOnConfirmed(false)
{

}

bool UConfirmPopupWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	ContentText = Cast<URichTextBlock>(FindChildWidgetFromName("Content"));

	YesButton = Cast<UButton>(FindChildWidgetFromName("Yes"));
	NoButton = Cast<UButton>(FindChildWidgetFromName("No"));

	YesText = Cast<UTextBlock>(FindChildWidgetFromName("Label1"));
	NoText = Cast<UTextBlock>(FindChildWidgetFromName("Label2"));

	return true;
}

void UConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (YesButton)
	{
		YesButton->OnClicked.AddUniqueDynamic(this, &UConfirmPopupWidget::OnYesButtonClicked);
	}

	if (NoButton)
	{
		NoButton->OnClicked.AddUniqueDynamic(this, &UConfirmPopupWidget::OnNoButtonClicked);
	}
}

void UConfirmPopupWidget::SetContent(const FText& Content)
{
	if (ContentText)
	{
		ContentText->SetText(Content);
	}
}

void UConfirmPopupWidget::SetContentVisibility(ESlateVisibility InVisibility)
{
	if (ContentText)
	{
		ContentText->SetVisibility(InVisibility);
	}
}

void UConfirmPopupWidget::SetConfirmFlags(uint32 Flags)
{
	if (YesButton)
	{
		YesButton->SetVisibility(((Flags & EConfirmPopupFlag::Yes) != 0) ?
			ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}

	if (NoButton)
	{
		NoButton->SetVisibility(((Flags & EConfirmPopupFlag::No) != 0) ?
			ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}
}

void UConfirmPopupWidget::SetYesNoText(const FText& InYesText, const FText& InNoText)
{
	if (YesText)
	{
		YesText->SetText(InYesText);
	}
	if (NoText)
	{
		NoText->SetText(InNoText);
	}
}

void UConfirmPopupWidget::SetYesButtonEnabled(bool bInEnabled)
{
	if (YesButton)
	{
		YesButton->SetIsEnabled(bInEnabled);
	}
}

void UConfirmPopupWidget::SetYesButtonVisibility(ESlateVisibility InVisibility)
{
	if (YesButton)
	{
		YesButton->SetVisibility(InVisibility);
	}
}

void UConfirmPopupWidget::SetNoGoBackOnConfirm()
{
	bNoGoBackOnConfirmed = true;
}

void UConfirmPopupWidget::OnYesButtonClicked()
{
	OnConfirmButtonClicked(EConfirmPopupFlag::Yes);
}

void UConfirmPopupWidget::OnNoButtonClicked()
{
	OnConfirmButtonClicked(EConfirmPopupFlag::No);
}

void UConfirmPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	if (!bNoGoBackOnConfirmed)
	{
		ABaseHUD* BaseHUD = GetBaseHUD(this);
		check(BaseHUD);

		BaseHUD->GotoBack();
	}

	OnConfirmPopupDelegate.ExecuteIfBound(Option);
}

////////////////////////////////////////////////////////////////////////////////
// UPlayNotifyPopupWidget
UPlayNotifyPopupWidget::UPlayNotifyPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

bool UPlayNotifyPopupWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	StageNameText = Cast<UTextBlock>(FindChildWidgetFromName("StageName"));
	ensure(StageNameText);

	ContentText = Cast<UTextBlock>(FindChildWidgetFromName("Content"));
	ensure(ContentText);

	CancelButton = Cast<UButton>(FindChildWidgetFromName("Cancel"));
	ensure(CancelButton);

	StartButton = Cast<UButton>(FindChildWidgetFromName("Start"));
	ensure(StartButton);

	return true;
}

void UPlayNotifyPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CancelButton->OnClicked.AddUniqueDynamic(this, &UPlayNotifyPopupWidget::OnCancelButtonClicked);
	StartButton->OnClicked.AddUniqueDynamic(this, &UPlayNotifyPopupWidget::OnStartButtonClicked);
}

void UPlayNotifyPopupWidget::SetStageName(const FText& InStageName)
{
	StageNameText->SetText(InStageName);
}

void UPlayNotifyPopupWidget::SetContent(const FText& InContent)
{
	ContentText->SetText(InContent);
}

void UPlayNotifyPopupWidget::OnCancelButtonClicked()
{
	ClosePopup();

	OnPopupDelegate.ExecuteIfBound(EConfirmPopupFlag::No);
}

void UPlayNotifyPopupWidget::OnStartButtonClicked()
{
	ClosePopup();

	OnPopupDelegate.ExecuteIfBound(EConfirmPopupFlag::Yes);
}

void UCurrencyUsePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	AlertText = CastChecked<URichTextBlock>(GetWidgetFromName("Alert"));
	OwnedCurrencyWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedCurrency"));
	RequiredCurrencyWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredCurrency"));

	OwnedFreeGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedFreeGem"));
	OwnedFreeGemWidget->SetPointType(ECurrencyType::FreeGem, EPointWidgetOption::NONE);

	OwnedPaidGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPaidGem"));
	OwnedPaidGemWidget->SetPointType(ECurrencyType::PaidGem, EPointWidgetOption::NONE);

	RequiredFreeGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredFreeGem"));
	RequiredFreeGemWidget->SetPointType(ECurrencyType::FreeGem, EPointWidgetOption::LessEqual);

	RequiredPaidGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredPaidGem"));
	RequiredPaidGemWidget->SetPointType(ECurrencyType::PaidGem, EPointWidgetOption::LessEqual);

	ConfirmText = CastChecked<UTextBlock>(GetWidgetFromName("Confirm"));

	// Animations

	CurrencyAnim = GetWidgetAnimationFromName(this, "AnimCurrency");
	GemAnim = GetWidgetAnimationFromName(this, "AnimGem");
	CurrencyAndGemAnim = GetWidgetAnimationFromName(this, "AnimCurrencyAndGem");
}

void UCurrencyUsePopupWidget::SetPurchaseInfo(FBoxProductType BoxProductType)
{
	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(BoxProductType);
	const FSummonAssetRow& SummonAssetRow = GetGameResource().GetSummonAssetRow(BoxProductRow.EventId);

	FString TitleParamStr = (BoxProductRow.GroupCount <= 1) ? "PurchaseSummon1" : "PurchaseSummon10";
	SetTitle(Q6Util::GetLocalizedText("Popup", TitleParamStr));
	SetContent(SummonAssetRow.ConsumeDescription);
	SetConfirmFlags(EConfirmPopupFlag::Yes | EConfirmPopupFlag::No);

	// Set point and currency

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	if (BoxProductRow.PointType == ESummonPointType::AnyGem
		|| (BoxProductRow.PointType == ESummonPointType::PaidGem))
	{
		int64 MyFreeGem = WorldUser.GetFreeGem();
		int64 MyPaidGem = WorldUser.GetPaidGem();

		OwnedFreeGemWidget->SetCurPoint(MyFreeGem);
		OwnedPaidGemWidget->SetCurPoint(MyPaidGem);

		int64 MyTicketCount = WorldUser.GetSummonTicket();
		int64 RequiredTicketCount = 0;
		if (BoxProductRow.SummonType == ESummonType::Basic
			|| BoxProductRow.SummonType == ESummonType::Event)
		{
			RequiredTicketCount = FMath::Min((BoxProductRow.PointCount / SystemConst::Q6_SUMMON_POINTS_PER_TICKET), WorldUser.GetSummonTicket());

			OwnedCurrencyWidget->SetPointType(EPointType::SummonTicket, EPointWidgetOption::NONE);
			OwnedCurrencyWidget->SetCurPoint(MyTicketCount);

			RequiredCurrencyWidget->SetPointType(EPointType::SummonTicket, EPointWidgetOption::LessEqual);
			RequiredCurrencyWidget->SetPoint(RequiredTicketCount, WorldUser.GetSummonTicket());

			PlayAnimation(CurrencyAndGemAnim);
		}
		else
		{
			PlayAnimation(GemAnim);
		}

		int64 RequiredFreeGem = (BoxProductRow.PointType == ESummonPointType::AnyGem) ?
			FMath::Max(FMath::Min(MyFreeGem, (int64) BoxProductRow.PointCount - (RequiredTicketCount * SystemConst::Q6_SUMMON_POINTS_PER_TICKET)), (int64) 0) : 0;
		int64 RequiredPaidGem = (BoxProductRow.PointCount - RequiredFreeGem - (RequiredTicketCount * SystemConst::Q6_SUMMON_POINTS_PER_TICKET));
		RequiredFreeGemWidget->SetPoint(RequiredFreeGem, MyFreeGem);
		RequiredPaidGemWidget->SetPoint(RequiredPaidGem, MyPaidGem);

		bEnoughCurrency = (MyTicketCount >= RequiredTicketCount) && (MyFreeGem >= RequiredFreeGem) && (MyPaidGem >= RequiredPaidGem);

		FString KeyStr = bEnoughCurrency ? "Ok" : "GotoShop";
		ConfirmText->SetText(Q6Util::GetLocalizedText("Common", KeyStr));
	}
	else
	{
		int32 MyPoint = WorldUser.GetPoint(BoxProductRow.PointType);
		OwnedCurrencyWidget->SetPointType(BoxProductRow.PointType, EPointWidgetOption::NONE);
		OwnedCurrencyWidget->SetCurPoint(MyPoint);

		RequiredCurrencyWidget->SetPointType(BoxProductRow.PointType, EPointWidgetOption::LessEqual);
		RequiredCurrencyWidget->SetPoint(BoxProductRow.PointCount, MyPoint);

		bEnoughCurrency = (MyPoint >= BoxProductRow.PointCount);

		ConfirmText->SetText(Q6Util::GetLocalizedText("Common", "Ok"));

		PlayAnimation(CurrencyAnim);
	}

	if (bEnoughCurrency)
	{
		AlertText->SetVisibility(ESlateVisibility::Collapsed);
		SetYesButtonEnabled(true);
	}
	else
	{
		AlertText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		bool bYesEnabled = (BoxProductRow.PointType == ESummonPointType::PaidGem) || (BoxProductRow.PointType == ESummonPointType::AnyGem);
		SetYesButtonEnabled(bYesEnabled);
	}
}

void UCurrencyUsePopupWidget::SetRebirth()
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "UseGemPlayPopupTitle"));
	SetContent(Q6Util::GetLocalizedText("Lobby", "SummonInfoOnlyGem"));

	int32 InResurrectionCount = GetHUDStore().GetUserRecordManager().GetResurrectionCount();
	GetCheckedCombatCube(this)->GetStore()->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InResurrectionCount](FCCUnitId ReqUnitId, FCombatState RepState) {
		UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
		check(GameInstance);
		int32 MyFreeGem = GameInstance->GetCombatSeed().Seed.FreeGem;
		int32 MyPaidGem = GameInstance->GetCombatSeed().Seed.PaidGem;
		int32 Cost = RepState.GemWipeoutContinueCount * SystemConst::Q6_REBIRTH_GEM_COST;
		int32 OnetimeCost = SystemConst::Q6_REBIRTH_GEM_COST;
		if (InResurrectionCount == 0)
		{
			if (RepState.GemWipeoutContinueCount == 0)
			{
				// First Blood
				Cost = 0;
				OnetimeCost = 0;
			}
			else
			{
				Cost = (RepState.GemWipeoutContinueCount - 1) * SystemConst::Q6_REBIRTH_GEM_COST;
			}
		}

		int32 Remainder = MyFreeGem - Cost;
		if (Remainder >= 0)
		{
			MyFreeGem = Remainder;
		}
		else
		{
			MyFreeGem = 0;
			MyPaidGem = MyPaidGem + Remainder;
		}

		OwnedFreeGemWidget->SetCurPoint(MyFreeGem);
		OwnedPaidGemWidget->SetCurPoint(MyPaidGem);

		int32 RequiredFreeGem = FMath::Min(MyFreeGem, OnetimeCost);
		int32 RequiredPaidGem = FMath::Max(OnetimeCost - RequiredFreeGem, 0);
		RequiredFreeGemWidget->SetPoint(RequiredFreeGem, MyFreeGem);
		RequiredPaidGemWidget->SetPoint(RequiredPaidGem, MyPaidGem);

		bEnoughCurrency = (MyFreeGem >= RequiredFreeGem) && (MyPaidGem >= RequiredPaidGem);

		PlayAnimation(GemAnim);
	}));
}

void UCurrencyUsePopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	Super::OnConfirmButtonClicked(Option);

	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	if (!bEnoughCurrency)
	{
		if (ABaseHUD* BaseHUD = GetBaseHUD(this))
		{
			BaseHUD->OpenGemShopPurchasePopup();
		}
	}
	else
	{
		OnCurrencyUsedDelegate.ExecuteIfBound();
	}
}

UItemListPopupWidget::UItemListPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

bool UItemListPopupWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	ItemListWidget = Cast<UDynamicListWidget>(GetWidgetFromName("ItemList"));
	MyGoldText = Cast<UTextBlock>(GetWidgetFromName("MyGold"));
	GoldCostText = Cast<UTextBlock>(GetWidgetFromName("GoldCost"));
	YesLabelText = Cast<UTextBlock>(GetWidgetFromName("YesLabel"));
	ResultTierWidget = Cast<UUpgradeResultTierWidget>(GetWidgetFromName("ResultTier"));

	CurrentLevelText = Cast<UTextBlock>(GetWidgetFromName("CurrentLevel"));
	TargetLevelText = Cast<UTextBlock>(GetWidgetFromName("TargetLevel"));
	NameText = Cast<UTextBlock>(GetWidgetFromName("Name"));

	UpgradeAnims.Reset();
	UpgradeAnims.Add(GetWidgetAnimationFromName(this, "AnimDefault"));
	UpgradeAnims.Add(GetWidgetAnimationFromName(this, "AnimTierUp"));
	UpgradeAnims.Add(GetWidgetAnimationFromName(this, "AnimLevelUp"));

	return true;
}

void UItemListPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	check(ItemListWidget);
	check(MyGoldText);
	check(GoldCostText);
	check(YesLabelText);
	check(ResultTierWidget);

	check(CurrentLevelText);
	check(TargetLevelText);
	check(NameText);
}

void UItemListPopupWidget::SetItems(EUpgradeCategory ItemCategory, const TArray<int64>& MaterialIds, bool bVisibleUltLevel)
{
	switch (ItemCategory)
	{
		case EUpgradeCategory::Character:
			SetCharacters(MaterialIds, bVisibleUltLevel);
			break;
		case EUpgradeCategory::Relic:
			SetRelics(MaterialIds);
			break;
		case EUpgradeCategory::Sculpture:
			SetSculptures(MaterialIds);
			break;
	}
}

void UItemListPopupWidget::SetCharacters(const TArray<int64>& ItemIds, bool bVisibleUltLevel)
{
	ItemListWidget->ClearList();

	const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();
	for (const int64& CharacterId : ItemIds)
	{
		const FCharacter* Character = CharMgr.Find(FCharacterId(CharacterId));
		if (!Character)
		{
			continue;
		}

		UItemCardWidget* CharacterCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCardWidget->SetCharacter(Character->GetInfo());

		if (bVisibleUltLevel)
		{
			CharacterCardWidget->SetUltSkillLevel(Character->GetInfo().UltimateSkillLevel);
		}
	}
}

void UItemListPopupWidget::SetRelics(const TArray<int64>& ItemIds)
{
	ItemListWidget->ClearList();

	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	for (const int64& RelicId : ItemIds)
	{
		const FRelic* Relic = RelicMgr.Find(FRelicId(RelicId));
		if (!Relic)
		{
			continue;
		}

		UItemCardWidget* CharacterCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCardWidget->SetRelic(Relic->Info);
	}
}

void UItemListPopupWidget::SetSculptures(const TArray<int64>& ItemIds)
{
	ItemListWidget->ClearList();

	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	for (const int64& SculptureId : ItemIds)
	{
		const FSculpture* Sculpture = SculptureMgr.Find(FSculptureId(SculptureId));
		if (!Sculpture)
		{
			continue;
		}

		UItemCardWidget* CharacterCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCardWidget->SetSculpture(Sculpture->Info);
	}
}

void UItemListPopupWidget::SetYesButtonName(const FText& YesButtonName)
{
	YesLabelText->SetText(YesButtonName);
}

void UItemListPopupWidget::SetCost(int32 MyAmount, int32 Cost)
{
	MyGoldText->SetText(FText::FromString(FString::FormatAsNumber(MyAmount)));
	GoldCostText->SetText(FText::FromString(FString::FormatAsNumber(Cost)));
}

void UItemListPopupWidget::SetTierUpResult(int32 CurrentTier, int32 TargetTier)
{
	ResultTierWidget->SetTier(CurrentTier, TargetTier);
}

void UItemListPopupWidget::SetUltUpResult(FCharacterType CharacterType, int32 CurrentLevel, int32 TargetLevel)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetCharacterUltimateSkillRow(CharacterType);
	NameText->SetText(SkillRow.DescName);

	CurrentLevelText->SetText(FText::AsNumber(CurrentLevel));
	TargetLevelText->SetText(FText::AsNumber(TargetLevel));
}

void UItemListPopupWidget::PlayUpgradeAnimation(EUpgradeAnimType AnimType)
{
	if (UpgradeAnims.IsValidIndex((int32)AnimType))
	{
		PlayAnimation(UpgradeAnims[(int32)AnimType]);
		return;
	}
}

UItemMaxLevelUpConfirmPopupWidget::UItemMaxLevelUpConfirmPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

bool UItemMaxLevelUpConfirmPopupWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	return true;
}

void UItemMaxLevelUpConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BeforeLevelWidget = CastChecked<UItemLevelWidget>(GetWidgetFromName("BeforeLevel"));
	AfterLevelWidget = CastChecked<UItemLevelWidget>(GetWidgetFromName("AfterLevel"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));
	OwnedAmountText = CastChecked<UTextBlock>(GetWidgetFromName("OwnedAmount"));
	RequiredAmountText = CastChecked<UTextBlock>(GetWidgetFromName("RequiredAmount"));
	UpgradeText = CastChecked<UTextBlock>(GetWidgetFromName("Upgrade"));
}

void UItemMaxLevelUpConfirmPopupWidget::SetCharacter(const FCharacterId& CharacterId, EUpgradeCharacterCategory UpCategory)
{
	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!Character)
	{
		return;
	}

	SetTitle(GetCharacterUpgradeConfirmText(UpCategory));
	UpgradeText->SetText(GetUIResource().GetUpgradeCharacterName(UpCategory));

	const FCharacterInfo& CharacterInfo = Character->GetInfo();
	BeforeLevelWidget->SetCharacter(CharacterInfo.Level, CharacterInfo.Star, CharacterInfo.Moon);

	const UCMS* CMS = GetCMS();
	if (UpCategory == EUpgradeCharacterCategory::Evolute)
	{
		int32 UpgradeMoon = SystemConstHelper::GetUpgradeTargetMoon(CharacterInfo.Grade, CharacterInfo.Moon);
		int32 UpgradeStar = SystemConstHelper::GetCharacterStarByMoon(CharacterInfo.Grade, UpgradeMoon);

		AfterLevelWidget->SetCharacter(CharacterInfo.Level, UpgradeStar, UpgradeMoon);
		SetCharacterEvolute(UpgradeMoon, CharacterInfo.Grade);
	}
	else
	{
		AfterLevelWidget->SetCharacter(CharacterInfo.Level, CharacterInfo.Star + 1, CharacterInfo.Moon);

		const FCMSPromoteCostRow& CostRow = CMS->GetCharacterUpStarCostRowOrDummy(UpCategory, CharacterInfo);
		SetItemPromote(CostRow);
	}
}

void UItemMaxLevelUpConfirmPopupWidget::SetRelic(const FRelicId& RelicId)
{
	const FRelic* Relic = GetHUDStore().GetRelicManager().Find(RelicId);
	if (!Relic)
	{
		return;
	}

	SetTitle(Q6Util::GetLocalizedText("Lobby", "PromoteConfirm"));
	UpgradeText->SetText(Q6Util::GetLocalizedText("Common", "Promote"));

	const FRelicInfo& RelicInfo = Relic->Info;
	const FCMSPromoteCostRow& CostRow = GetCMS()->GetEquipPromoteCostRowOrDummy(EPromoteCategory::Relic, RelicInfo.Star + 1);
	BeforeLevelWidget->SetEquip(RelicInfo.Level, RelicInfo.Star);
	AfterLevelWidget->SetEquip(RelicInfo.Level, RelicInfo.Star + 1);

	SetItemPromote(CostRow);
}

void UItemMaxLevelUpConfirmPopupWidget::SetSculpture(const FSculptureId& SculptureId)
{
	const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(SculptureId);
	if (!Sculpture)
	{
		return;
	}

	SetTitle(Q6Util::GetLocalizedText("Lobby", "PromoteConfirm"));
	UpgradeText->SetText(Q6Util::GetLocalizedText("Common", "Promote"));

	const FSculptureInfo& SculptureInfo = Sculpture->Info;
	const FCMSPromoteCostRow& CostRow = GetCMS()->GetEquipPromoteCostRowOrDummy(EPromoteCategory::Sculpture, SculptureInfo.Star + 1);

	BeforeLevelWidget->SetEquip(SculptureInfo.Level, SculptureInfo.Star);
	AfterLevelWidget->SetEquip(SculptureInfo.Level, SculptureInfo.Star + 1);

	SetItemPromote(CostRow);
}

void UItemMaxLevelUpConfirmPopupWidget::SetItemPromote(const FCMSPromoteCostRow& CostRow)
{
	// Set level

	AfterLevelWidget->PlayPromoteAnim();

	// Set materials

	MaterialsWidget->SetMaterials(CostRow.GetBagItem(), CostRow.ItemCount);

	// Set gold cost

	OwnedAmountText->SetText(FText::FromString(FString::FormatAsNumber(GetHUDStore().GetWorldUser().GetGold())));
	RequiredAmountText->SetText(FText::FromString(FString::FormatAsNumber(CostRow.Gold)));
}

void UItemMaxLevelUpConfirmPopupWidget::SetCharacterEvolute(int32 TargetMoon, EItemGrade ItemGrade)
{
	// Set level

	AfterLevelWidget->PlayPromoteAnim();

	// Set materials
	const UCMS* CMS = GetCMS();
	const FCMSBagItemRow& ItemRow = CMS->GetBagItemRowOrDummy(FBagItemType(SystemConst::Q6_CHARACTER_EVOLUTION_MATERIAL));
	MaterialsWidget->SetMaterial(ItemRow, CharacterEvoluteMaterialCount);

	// Set gold cost

	OwnedAmountText->SetText(FText::FromString(FString::FormatAsNumber(GetHUDStore().GetWorldUser().GetGold())));
	RequiredAmountText->SetText(FText::FromString(FString::FormatAsNumber(SystemConstHelper::GetCharacterEvoluteCost(TargetMoon, ItemGrade))));
}

const FText& UItemMaxLevelUpConfirmPopupWidget::GetCharacterUpgradeConfirmText(EUpgradeCharacterCategory UpCategory) const
{
	if (CharacterUpgradeConfirmTexts.IsValidIndex((int32)UpCategory))
	{
		return CharacterUpgradeConfirmTexts[(int32)UpCategory];
	}

	return FText::GetEmpty();
}

UItemRewardPopupWidget::UItemRewardPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UItemRewardPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
	DescriptionText = CastChecked<URichTextBlock>(GetWidgetFromName("Description"));
}

void UItemRewardPopupWidget::SetReward(FSagaType SagaType, bool bVisibleCount, bool bAllowDuplicated)
{
	SetReward(EventContentTypeInvalid, SagaType, bVisibleCount, bAllowDuplicated);
}

void UItemRewardPopupWidget::SetReward(const TArray<FRewardInfo>& RewardInfos)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "RewardCompleteTitle"));

	DescriptionText->SetVisibility(ESlateVisibility::Collapsed);

	ItemListWidget->ClearList();
	for (const FRewardInfo& RewardInfo : RewardInfos)
	{
		for (const FCurrency& Currency : RewardInfo.CurrencyList)
		{
			UItemWidget* CurrencyWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			CurrencyWidget->SetRewardType(GetRewardType(RewardInfo.Type));
			CurrencyWidget->SetCurrency(Currency.Type, Currency.Count);
		}

		for (const FItemData& ItemData : RewardInfo.ItemList)
		{
			UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetRewardType(GetRewardType(RewardInfo.Type));
			ItemWidget->SetItem(ItemData);
		}
	}
}

void UItemRewardPopupWidget::SetReward(FEventContentType EventContentType, FSagaType SagaType, bool bVisibleCount, bool bAllowDuplicated)
{
	SetTitle(Q6Util::GetLocalizedText("Lobby", "LootItemTitle"));

	DescriptionText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	const TArray<const FCMSLootGroupRow*> LootGroupRows = SagaRow.GetLootGroup();

	// check to duplicate loot item
	TArray<FSimpleLootData> AddedLootDatas;

	ItemListWidget->ClearList();
	for (const FCMSLootGroupRow* RootGroupRow : LootGroupRows)
	{
		check(RootGroupRow);

		for (const int32& LootId : RootGroupRow->LootIds)
		{
			const FCMSLootDataRow& LootDataRow = GetCMS()->GetLootDataOrDummy(LootId);

			bool bAddItemWidget = true;
			if (!bAllowDuplicated)
			{
				const ELootCategory LootCategory = LootDataRow.LootCategory;
				const int32 LootValue = LootDataRow.Value;
				const FSimpleLootData* Found = AddedLootDatas.FindByPredicate([&LootCategory, &LootValue](const FSimpleLootData& LootData)
				{
					return LootData.LootCategory == LootCategory && LootData.Value == LootValue;
				});

				if (Found == nullptr)
				{
					AddedLootDatas.Add(FSimpleLootData(LootCategory, LootValue));
					bAddItemWidget = true;
				}
				else
				{
					bAddItemWidget = false;
				}
			}

			if (bAddItemWidget)
			{
				UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());

				if (LootDataRow.LootCategory == ELootCategory::EventPoint && EventContentType != EventContentTypeInvalid)
				{
					ItemWidget->SetEventPoint(EventContentType, LootDataRow.Value, LootDataRow.Count);
				}
				else
				{
					ItemWidget->SetLoot(LootId, RootGroupRow->LootCount);
				}

				ItemWidget->SetVisibleCount(bVisibleCount);
			}
		}
	}
}

void USkillUpgradeConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SkillName"));
	CurrentLevelText = CastChecked<UTextBlock>(GetWidgetFromName("CurrentLevel"));
	ResultLevelText = CastChecked<UTextBlock>(GetWidgetFromName("ResultLevel"));

	CurrentGoldText = CastChecked<UTextBlock>(GetWidgetFromName("OwnedAmount"));
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	CurrentGoldText->SetText(FText::AsNumber(WorldUser.GetGold()));

	RequiredGoldText = CastChecked<UTextBlock>(GetWidgetFromName("RequiredAmount"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));
}

void USkillUpgradeConfirmPopupWidget::SetTurnSkill(const FCharacterId& SelectedCharacterId, int32 SelectedSkillIndex)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "TurnSkillUpgradeTitle"));

	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();

	const FCMSSkillRow* SelectedTurnSkillRow = CharacterManager.GetCharacterTurnSkillRow(SelectedCharacterId, SelectedSkillIndex);
	if (!SelectedTurnSkillRow)
	{
		Q6JsonLogGunny(Warning, "Get SelectedTurnSkill fail");
		return;
	}

	TArray<int32> TurnSkillLevels;
	CharacterManager.GetCharacterTurnSkillLevels(SelectedCharacterId, TurnSkillLevels);

	if (!TurnSkillLevels.IsValidIndex(SelectedSkillIndex))
	{
		Q6JsonLogGunny(Warning, "TurnSkillLevels index fail ", Q6KV("SelectedSkillIndex", SelectedSkillIndex));
		return;
	}

	const int32 SelectedTurnSkillLevel = TurnSkillLevels[SelectedSkillIndex];
	const int32 RequireGold = CharacterManager.GetGoldForTurnSkillUpgrade(SelectedCharacterId, SelectedSkillIndex);
	const FCMSSkillUpgradeCostRow& CostRow = GetCMS()->GetSkillUpgradeCostRowOrDummy(*SelectedTurnSkillRow, SelectedTurnSkillLevel + 1);
	SetSkill(CostRow.GetBagItem()
		, CostRow.BagItemCount
		, RequireGold
		, SelectedTurnSkillLevel
		, SelectedTurnSkillRow->DescName);
}

void USkillUpgradeConfirmPopupWidget::SetPetSkill(const FPetId& PetId, int32 SkillIndex)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "PetSkillUpConfirm"));

	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().Find(PetId);
	if (!PetInfo)
	{
		Q6JsonLogRoze(Error, "UTurnSkillUpConfirmPopupWidget::SetPetSkill - Not found pet by index", Q6KV("Index", SkillIndex));
		return;
	}

	TArray<int32> SkillLevels;
	SkillLevels.Add(PetInfo->Skill1Level);
	SkillLevels.Add(PetInfo->Skill2Level);
	SkillLevels.Add(PetInfo->Skill3Level);
	check(SkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const UCMS* CMS = GetCMS();
	check(CMS);

	const TArray<const FCMSSkillRow*> SkillRows = CMS->GetPetRowOrDummy(PetInfo->Type).GetSkills();
	check(SkillRows.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const FCMSSkillRow* SkillRow = SkillRows[SkillIndex];
	check(SkillRow);

	int32 SkillLevel = SkillLevels[SkillIndex];
	const FCMSSkillUpgradeCostRow& CostRow = CMS->GetSkillUpgradeCostRowOrDummy(*SkillRow, SkillLevel + 1);
	SetSkill(CostRow.GetBagItem()
		, CostRow.BagItemCount
		, CostRow.Gold
		, SkillLevel
		, SkillRow->DescName);
}

void USkillUpgradeConfirmPopupWidget::SetArtifactSkill(int32 ArtifactIndex)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ArtifactUpgradeConfirm"));

	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSkillRow& ArtifactSkillRow = CMS->GetArtifactSkillRowOrDummy(ArtifactIndex);
	const FArtifact* Artifact = GetHUDStore().GetTempleManager().GetArtifact(ArtifactIndex);
	if (!Artifact)
	{
		Q6JsonLogRoze(Error, "USkillUpgradeConfirmPopupWidget::SetArtifactSkill - Not found artifact", Q6KV("ArtifactIndex", ArtifactIndex));
		return;
	}

	const FCMSSkillUpgradeCostRow& CostRow = CMS->GetSkillUpgradeCostRowOrDummy(ArtifactSkillRow, Artifact->Level + 1);
	SetSkill(CostRow.GetBagItem()
		, CostRow.BagItemCount
		, CostRow.Gold
		, Artifact->Level
		, ArtifactSkillRow.DescName);
}

void USkillUpgradeConfirmPopupWidget::SetSkill(const TArray<const FCMSBagItemRow*>& BagItems
	, const TArray<int32>& BagItemCount
	, const int32 RequireGold
	, const int32 SkillLevel
	, const FText& DescName)
{
	MaterialsWidget->SetMaterials(BagItems, BagItemCount);
	SkillNameText->SetText(DescName);
	CurrentLevelText->SetText(FText::AsNumber(SkillLevel));
	ResultLevelText->SetText(FText::AsNumber(SkillLevel + 1));
	RequiredGoldText->SetText(FText::AsNumber(RequireGold));
}

void UPartyEditCancleConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BeforeMemberListWidget = CastChecked<UPartyMemberListWidget>(GetWidgetFromName("BeforeParty"));
	AfterMemberListWidget = CastChecked<UPartyMemberListWidget>(GetWidgetFromName("AfterParty"));

	PartyNumberText = CastChecked<UTextBlock>(GetWidgetFromName("PartyNumber"));
	MenuText = CastChecked<UTextBlock>(GetWidgetFromName("TextMenu"));
	PartyNumberBox = CastChecked<UHorizontalBox>(GetWidgetFromName("PartyNum"));
}

void UPartyEditCancleConfirmPopupWidget::SetParty(const FPartyInfo& PartyInfo, const FPartySlot& JokerSlot)
{
	PartyNumberBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	PartyNumberText->SetText(FText::AsNumber(PartyInfo.PartyId));
	MenuText->SetText(Q6Util::GetLocalizedText("Lobby", "Party"));

	const UPartyManager& PartyMgr = GetHUDStore().GetPartyManager();
	const FPartyInfo& OrgPartyInfo = PartyMgr.GetPartyInfo(PartyInfo.PartyId);
	const FPartySlot& OrgJokerSlot = PartyMgr.GetOwnedJokerSlot();
	BeforeMemberListWidget->InitParty(OrgPartyInfo, OrgJokerSlot);
	AfterMemberListWidget->InitParty(PartyInfo, JokerSlot);
}

void UPartyEditCancleConfirmPopupWidget::SetMultisideParty(const FPartyInfo& PartyInfo)
{
	PartyNumberBox->SetVisibility(ESlateVisibility::Collapsed);

	UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
	BeforeMemberListWidget->InitMultisideParty(SaveGame->GetMultisidePartyInfo());

	AfterMemberListWidget->InitMultisideParty(PartyInfo);
}

void UPartyEditCancleConfirmPopupWidget::SetJokerSet(const FJokerSet& JokerSet)
{
	PartyNumberBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	PartyNumberText->SetText(FText::AsNumber(JokerSet.Id));
	MenuText->SetText(Q6Util::GetLocalizedText("Lobby", "Joker"));

	BeforeMemberListWidget->InitJokerSet(GetHUDStore().GetJokerManager().GetJokerSet(JokerSet.Id));

	AfterMemberListWidget->InitJokerSet(JokerSet);
}

void UPartyResetConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterResetCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("Character"));
	SculptureResetCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("Sculpture"));
	RelicResetCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("Relic"));
}

void UPartyResetConfirmPopupWidget::InitResetOptions()
{
	SetTitle(Q6Util::GetLocalizedText("Lobby", "PartyReset"));

	CharacterResetCheckBox->SetIsChecked(false);
	SculptureResetCheckBox->SetIsChecked(false);
	RelicResetCheckBox->SetIsChecked(false);
}

void UPartyResetConfirmPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Flag)
{
	if (Flag == EConfirmPopupFlag::Yes)
	{
		bool CharacterReset = CharacterResetCheckBox->GetCheckedState() == ECheckBoxState::Checked;
		bool SculptureReset = SculptureResetCheckBox->GetCheckedState() == ECheckBoxState::Checked;
		bool RelicReset = RelicResetCheckBox->GetCheckedState() == ECheckBoxState::Checked;

		OnPartyResetDelegate.ExecuteIfBound(CharacterReset, SculptureReset, RelicReset);
	}

	Super::OnConfirmButtonClicked(Flag);
}

void UFriendshipCollectPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	const auto& CollectInfo = GetUser().GetFriendshipCollectInfo();

	SetContent(FText::Format(Q6Util::GetLocalizedText("Popup", "FriendShipCollectContent"),
		CollectInfo.GainedFriendshipPoint));

	const auto& CharMgr = GetHUDStore().GetCharacterManager();
	const FCharacter* Character = CharMgr.Find(CollectInfo.MostPopularCharacterId);
	if (Character)
	{
		auto CharacterWidget = CastChecked<UItemCardWidget>(GetWidgetFromName("Character"));
		CharacterWidget->SetCharacter(Character->GetInfo());
		CharacterWidget->SetLocked(false);
		CharacterWidget->OnItemClickedDelegate.BindUObject(this, &UFriendshipCollectPopupWidget::OnItemCardClicked);
	}

	SetTitle(Q6Util::GetLocalizedText("Popup", "FriendShipCollectTitle"));
	SetConfirmFlags(EConfirmPopupFlag::Yes);
}

void UFriendshipCollectPopupWidget::OnItemCardClicked(UItemCardWidget* ItemCard)
{
	ItemCard->OpenItemDetail();
}


void UBoostConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CurrentDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("CurrentDays"));
	ResultDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("ResultDays"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));
	OwnedAmountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("OwnedAmount"));
	RequireAmountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RequireAmount"));
	UsableText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Usable"));
	RemainDaysInfoText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RemainDaysInfo"));
	ResultTimeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("ResultTime"));
	CurrentTimeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("CurrentTime"));
	CurrentDaysBox = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxCurrentDays"));
	ResultDaysBox = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxResultDays"));
}

void UBoostConfirmPopupWidget::SetPortal(EPortalType PortalType)
{
	SlotNum = (int32)PortalType;

	SetTitle(Q6Util::GetLocalizedText("Popup", "BuildBoostConfirmTitle"));

	CurrentTimeText->SetText(FText::GetEmpty());
	ResultTimeText->SetText(FText::GetEmpty());
	CurrentDaysBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	RemainDaysInfoText->SetText(Q6Util::GetLocalizedText("Lobby", "BuildTimeLeft"));

	const UPyramidManager& PyramidMgr = GetHUDStore().GetPyramidManager();
	int32 RemainDays = PyramidMgr.GetBuildTimeLeftDays(PortalType);

	CurrentDaysText->SetText(FText::AsNumber(RemainDays));

	if ((RemainDays - 1) <= 0)
	{
		ResultDaysBox->SetVisibility(ESlateVisibility::Collapsed);
		UsableText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderConnectionReady"));
	}
	else
	{
		ResultDaysBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		UsableText->SetText(FText::GetEmpty());
		ResultDaysText->SetText(FText::AsNumber(RemainDays - 1));
	}

	const UCMS* CMS = GetCMS();
	int32 DailyBoostCount = SystemConstHelper::GetDailyBoostCount(PortalType);
	int32 RemainBoostCount = SystemConstHelper::GetMaxBoostCount(PortalType) - PyramidMgr.GetTotalBoostUsed(PortalType);
	SetContent(FText::Format(Q6Util::GetLocalizedText("Popup", "BuildBoostConfirm"), FText::AsNumber(DailyBoostCount), FText::AsNumber(RemainBoostCount)));

	int32 PyramidLevel = PyramidMgr.GetLevel();
	int32 MaterialReduceCount = SystemConstHelper::GetPortalBoostMaterialReduceCount(PyramidLevel);

	if (const FCMSWonderCostRow* CostRow = CMS->GetPortalBoostCost(PortalType))
	{
		MaterialsWidget->SetMaterials(CostRow->GetBagItem(), CostRow->ItemCount, MaterialReduceCount);

		int32 GoldReduceCost = SystemConstHelper::GetPortalBoostGoldReduceCost(PyramidLevel);
		RequireAmountText->SetText(FText::AsNumber(FMath::Max(CostRow->Gold - GoldReduceCost, 0)));
	}

	OwnedAmountText->SetText(FText::AsNumber(GetHUDStore().GetWorldUser().GetGold()));

	OnConfirmPopupDelegate.BindUObject(this, &UBoostConfirmPopupWidget::OnPortalBuildBoostUse);
}

void UBoostConfirmPopupWidget::SetArtifact(int32 ArtifactIdx, int32 ArtifactLevel)
{
	SlotNum = ArtifactIdx + 1;

	SetTitle(Q6Util::GetLocalizedText("Popup", "CoolTimeBoostConfirmTitle"));
	SetContent(Q6Util::GetLocalizedText("Popup", "CoolTimeBoostConfirm"));

	CurrentDaysBox->SetVisibility(ESlateVisibility::Collapsed);
	ResultDaysBox->SetVisibility(ESlateVisibility::Collapsed);

	RemainDaysInfoText->SetText(Q6Util::GetLocalizedText("Popup", "ArtifactCoolTimeLeft"));

	int32 RemainSeconds = GetHUDStore().GetTempleManager().GetArtifactRemainSeconds(ArtifactIdx);
	CurrentTimeText->SetText(Q6Util::GetRemainTimeText(RemainSeconds));

	if ((RemainSeconds - SecondsPerDay) <= 0)
	{
		ResultTimeText->SetText(FText::GetEmpty());
		UsableText->SetText(Q6Util::GetLocalizedText("Lobby", "Usable"));
	}
	else
	{
		UsableText->SetText(FText::GetEmpty());
		ResultTimeText->SetText(Q6Util::GetRemainTimeText(RemainSeconds - SecondsPerDay));
	}

	const FCMSSkillRow& SkillRow = GetCMS()->GetArtifactSkillRowOrDummy(ArtifactIdx);
	const FCMSSkillUpgradeCostRow& CostRow = GetCMS()->GetSkillUpgradeCostRowOrDummy(SkillRow, ArtifactLevel);
	MaterialsWidget->SetMaterials(CostRow.GetBagItem(), CostRow.BagItemCount);

	RequireAmountText->SetText(FText::AsNumber(CostRow.Gold));
	OwnedAmountText->SetText(FText::AsNumber(GetHUDStore().GetWorldUser().GetGold()));

	OnConfirmPopupDelegate.BindUObject(this, &UBoostConfirmPopupWidget::OnArtifactBoostUse);
}

void UBoostConfirmPopupWidget::OnPortalBuildBoostUse(EConfirmPopupFlag Option)
{
	if (Option == EConfirmPopupFlag::Yes)
	{
		GetHUDStore().GetPyramidManager().ReqPortalBoostUse((EPortalType)SlotNum);
	}
}

void UBoostConfirmPopupWidget::OnArtifactBoostUse(EConfirmPopupFlag Option)
{
	if (Option == EConfirmPopupFlag::Yes)
	{
		GetHUDStore().GetTempleManager().ReqArtifactBoost(SlotNum - 1);
	}
}


void UItemSelectPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
}

void UItemSelectPopupWidget::SetPortal(EPortalType PortalType, bool bInConnect)
{
	bSelectedClose = bInConnect;

	FString PortalNameStr = FString::Printf(TEXT("Portal%s"), *ENUM_TO_STRING(EPortalType, PortalType));

	if (bSelectedClose)
	{
		SetTitle(Q6Util::GetLocalizedText("Popup", *(PortalNameStr + "SelectTitle")));
		SetConfirmFlags(EConfirmPopupFlag::No);
		SetBottomVisible(false);
	}
	else
	{
		SetTitle(Q6Util::GetLocalizedText("Popup", *(PortalNameStr + "ConfirmTitle")));
		SetConfirmFlags(0);	// Hide all confirm buttons
		SetBottomVisible(true);
	}

	SetContent(Q6Util::GetLocalizedText("Popup", *(PortalNameStr + "Confirm")));

	if (PortalType == EPortalType::Character)
	{
		SetPortalCharacterList();
	}
	else if (PortalType == EPortalType::Relic)
	{
		SetPortalRelicList();
	}
	else if (PortalType == EPortalType::Sculpture)
	{
		SetPortalSculptureList();
	}
}

void UItemSelectPopupWidget::SetVacation()
{
	bSelectedClose = true;

	SetTitle(Q6Util::GetLocalizedText("Popup", "VacationSelectTitle"));
	SetContent(Q6Util::GetLocalizedText("Popup", "VacationContent"));
	SetConfirmFlags(EConfirmPopupFlag::No);
	SetBottomVisible(false);

	ItemListWidget->ClearList();

	TMap<FCharacterType, const FCharacterInfo*> Characters = GetHUDStore().GetCharacterManager().GetVacationCharacters();
	for (auto& Elem : Characters)
	{
		const FCharacterInfo* CharacterInfo = Elem.Value;
		check(CharacterInfo);

		USimpleItemCardWidget* ItemWidget = CastChecked<USimpleItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetVacationCharacter(*CharacterInfo);
		ItemWidget->OnItemCardClickedDelegate.BindUObject(this, &UItemSelectPopupWidget::OnItemSelected);
	}
}

void UItemSelectPopupWidget::SetPortalCharacterList()
{
	ItemListWidget->ClearList();

	TMap<FCharacterType, const FCharacterInfo*> Characters = GetHUDStore().GetCharacterManager().GetPortalConnectCharacters();
	for (auto& Elem : Characters)
	{
		const FCharacterInfo* CharacterInfo = Elem.Value;
		check(CharacterInfo);

		USimpleItemCardWidget* ItemWidget = CastChecked<USimpleItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetPortalCharacter(*CharacterInfo);
		ItemWidget->OnItemCardClickedDelegate.BindUObject(this, &UItemSelectPopupWidget::OnItemSelected);
	}
}

void UItemSelectPopupWidget::SetPortalRelicList()
{
	ItemListWidget->ClearList();

	TMap<FRelicType, const FRelicInfo*> Relics = GetHUDStore().GetRelicManager().GetPortalConnectRelics();
	for (auto& Elem : Relics)
	{
		const FRelicInfo* RelicInfo = Elem.Value;
		check(RelicInfo);

		USimpleItemCardWidget* ItemWidget = CastChecked<USimpleItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetPortalRelic(*RelicInfo);
		ItemWidget->OnItemCardClickedDelegate.BindUObject(this, &UItemSelectPopupWidget::OnItemSelected);
	}
}

void UItemSelectPopupWidget::SetPortalSculptureList()
{
	ItemListWidget->ClearList();

	const UHUDStore& HUDStore = GetHUDStore();
	TMap<FSculptureType, const FSculptureInfo*> Sculptures = HUDStore.GetSculptureManager().GetPortalConnectSculptures();
	for (auto& Elem : Sculptures)
	{
		const FSculptureInfo* SculptureInfo = Elem.Value;
		check(SculptureInfo);

		USimpleItemCardWidget* ItemWidget = CastChecked<USimpleItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetPortalSculpture(*SculptureInfo);
		ItemWidget->OnItemCardClickedDelegate.BindUObject(this, &UItemSelectPopupWidget::OnItemSelected);
	}
}

void UItemSelectPopupWidget::OnItemSelected(int64 ItemId)
{
	OnItemSelectedDelegate.ExecuteIfBound(ItemId);

	if (bSelectedClose)
	{
		ClosePopup();
	}
}

void UPortalConnectConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemWidget = CastChecked<UItemCardWidget>(GetWidgetFromName("ItemCard"));
	LeadDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("LeadDays"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));

	SetTitle(Q6Util::GetLocalizedText("Popup", "PortalConnectConfirmTitle"));
}

void UPortalConnectConfirmPopupWidget::SetConnectItem(EPortalType PortalType, int64 ConnectedId)
{
	const UCMS* CMS = GetCMS();

	int32 LeadDays = SystemConstHelper::GetPortalConnectingDays(PortalType);
	LeadDaysText->SetText(FText::AsNumber(LeadDays));

	if (PortalType == EPortalType::Character)
	{
		if (const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(FCharacterId(ConnectedId)))
		{
			ItemWidget->SetDefaultCharacter(Character->GetInfo().Type);

			const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(Character->GetInfo().Type);
			NameText->SetText(UnitRow.DescName);
		}
	}
	else if (PortalType == EPortalType::Relic)
	{
		if (const FRelic* Relic = GetHUDStore().GetRelicManager().Find(FRelicId(ConnectedId)))
		{
			ItemWidget->SetDefaultRelic(Relic->Info.Type);

			const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(Relic->Info.Type);
			NameText->SetText(RelicRow.DescName);
		}
	}
	else if (PortalType == EPortalType::Sculpture)
	{
		if (const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(FSculptureId(ConnectedId)))
		{
			ItemWidget->SetDefaultSculpture(Sculpture->Info.Type);

			const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(Sculpture->Info.Type);
			NameText->SetText(SculptureRow.DescName);
		}
	}
}

void UPortalConnectedResultPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	EquipImage = CastChecked<UImage>(GetWidgetFromName("Equip"));
	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	OpenNameText = CastChecked<UTextBlock>(GetWidgetFromName("OpenName"));
	InfoText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Info"));

	UButton* StageButton = CastChecked<UButton>(GetWidgetFromName("Stage"));
	StageButton->OnClicked.AddUniqueDynamic(this, &UPortalConnectedResultPopupWidget::OnStageButtonClicked);

	// Animations

	ResultAnim = GetWidgetAnimationFromName(this, "AnimResult");
}

void UPortalConnectedResultPopupWidget::SetResult(const FSpecialRecord& SpecialRecord)
{
	SpecialCategory = (ESpecialCategory)SpecialRecord.ConditionType;

	const UCMS* CMS = GetCMS();
	TArray<const FCMSSagaRow*> SagaRows = CMS->GetStageRows(EContentType::Special, SpecialRecord.Episode);

	CharacterImage->SetVisibility(ESlateVisibility::Collapsed);
	EquipImage->SetVisibility(ESlateVisibility::Collapsed);

	const FCMSSagaRow* SagaRow = nullptr;
	if (SagaRows.IsValidIndex(0))
	{
		SagaRow = SagaRows[0];
	}

	if (!SagaRow)
	{
		Q6JsonLogRoze(Error, "UPortalConnectedResultPopupWidget::SetResult - Invalid special stage");
		return;
	}

	FText ItemNameText;
	TSoftObjectPtr<UTexture2D> ItemTexture;
	UImage* IconImage = nullptr;
	if (SpecialRecord.ConditionType == ESpecialCategory::CharacterPortal)
	{
		FCharacterType CharacterType = FCharacterType(SpecialRecord.ConditionId);
		const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterType);
		ItemNameText = UnitRow.DescName;

		const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
		ItemTexture = CharacterAssetRow.BodyTexture;

		IconImage = CharacterImage;
	}
	else if (SpecialRecord.ConditionType == ESpecialCategory::RelicPortal)
	{
		const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(FRelicType(SpecialRecord.ConditionId));
		ItemNameText = RelicRow.DescName;

		const FEquipAssetRow& RelicAssetRow = GetGameResource().GetRelicAssetRow(FRelicType(SpecialRecord.ConditionId));
		ItemTexture = RelicAssetRow.IllustTexture;

		IconImage = EquipImage;
	}
	else if (SpecialRecord.ConditionType == ESpecialCategory::SculpturePortal)
	{
		const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(FSculptureType(SpecialRecord.ConditionId));
		ItemNameText = SculptureRow.DescName;

		const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(FSculptureType(SpecialRecord.ConditionId));
		ItemTexture = SculptureAssetRow.IllustTexture;

		IconImage = EquipImage;
	}

	OpenNameText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "OpenSpecialStage"), SagaRow->DescName));
	InfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "ConnectedInfo"), ItemNameText));

	if (IconImage)
	{
		IconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		IconImage->SetBrushFromSoftTextureWhenLoadingFinished(ItemTexture);
	}

	PlayAnimation(ResultAnim);
}

void UPortalConnectedResultPopupWidget::OnStageButtonClicked()
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Special);

	FSpecialUIState UIState;
	UIState.MenuType = ESpecialStageMenuType::StageList;
	UIState.Category = ESpecialCategory::Wonder;
	UIState.SpecialType = SpecialTypeInvalid;	// Use for character episode only
	UIState.Wonder = EWonderCategory::Pyramid;

	ACTION_DISPATCH_SpecialOpen(UIState);

	ClosePopup();
}


void UWonderUpgradeConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UpgradeEffectWidget = CastChecked<UWonderUpgradeLevelEffectWidget>(GetWidgetFromName("UpgradeEffect"));
	TimeLeftText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TimeLeft"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));
	OwnedAmountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("OwnedAmount"));
	RequiredAmountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RequiredAmount"));
	ProduceWidget = CastChecked<UWonderProduceWidget>(GetWidgetFromName("Produce"));
}

void UWonderUpgradeConfirmPopupWidget::SetWonder(EWonderCategory Category, int32 CurrentLevel)
{
	const UCMS* CMS = GetCMS();
	FString WonderNameStr = ENUM_TO_STRING(EWonderCategory, Category);

	SetTitle(Q6Util::GetLocalizedText("Popup", *(WonderNameStr + TEXT("UpgradeConfirm"))));
	SetContent(Q6Util::GetLocalizedText("Popup", *WonderNameStr));

	const FCMSWonderRow* WonderRow = CMS->GetWonderRow(Category, CurrentLevel + 1);
	if (!WonderRow)
	{
		Q6JsonLogRoze(Error, "UWonderUpgradePopupWidget::SetWonder - Invalid wonder row", Q6KV("Wonder", *WonderNameStr));
		return;
	}

	UpgradeEffectWidget->SetWonder(Category, CurrentLevel);
	ProduceWidget->SetWonder(Category, CurrentLevel, CurrentLevel + 1);

	FText TimeLeft = Q6Util::GetShortTimeText(WonderRow->UpgradeTime * 60);
	TimeLeftText->SetText(TimeLeft);

	const FCMSBagItemRow& MaterialItemRow = CMS->GetBagItemRowOrDummy(FBagItemType(SystemConst::Q6_WONDER_UPGRADE_MATERIAL));
	MaterialsWidget->SetMaterial(MaterialItemRow, WonderRow->UpgradeMaterialCount);

	RequiredAmountText->SetText(FText::AsNumber(WonderRow->UpgradeGoldCost));

	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedAmountText->SetText(FText::AsNumber(OwnedGold));

	bool bEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(FBagItemType(SystemConst::Q6_WONDER_UPGRADE_MATERIAL), WonderRow->UpgradeMaterialCount);
	bool bEnoughGold = OwnedGold >= WonderRow->UpgradeGoldCost;

	RequiredAmountText->SetColorAndOpacity(bEnoughGold ? FLinearColor::White : GetUIResource().GetLackColor());
	SetYesButtonEnabled(bEnoughGold && bEnoughMaterials);
}

void UWonderUpgradeResultPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	WonderNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("WonderName"));
	UpgradeEffectWidget = CastChecked<UWonderUpgradeLevelEffectWidget>(GetWidgetFromName("UpgradeEffect"));
	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	ProduceWidget = CastChecked<UWonderProduceWidget>(GetWidgetFromName("Produce"));

	UpgradeAnim = GetWidgetAnimationFromName(this, "AnimUpgrade");

	OnPopupClosedDelegate.BindUObject(this, &UWonderUpgradeResultPopupWidget::OnResultPopupClosed);
}

void UWonderUpgradeResultPopupWidget::SetWonder(EWonderCategory InCategory, int32 ResultLevel)
{
	Category = InCategory;

	WonderNameText->SetText(Q6Util::GetLocalizedText("Lobby", *(TEXT("Wonder") + ENUM_TO_STRING(EWonderCategory, Category))));
	UpgradeEffectWidget->SetWonder(Category, ResultLevel - 1);
	ProduceWidget->SetWonder(Category, ResultLevel - 1, ResultLevel);

	const FSlateBrush& WonderBrush = GetUIResource().GetWonderBG(Category);
	BGImage->SetBrush(WonderBrush);

	PlayAnimation(UpgradeAnim);
}

void UWonderUpgradeResultPopupWidget::OnResultPopupClosed()
{
	if (Category == EWonderCategory::Vacation)
	{
		GetCheckedLobbyHUD(this)->ProcessReward();
	}
}

void UBondRewardInfoPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	CurrentBondText = CastChecked<UTextBlock>(GetWidgetFromName("CurrentBond"));
	YesButton = CastChecked<UButton>(GetWidgetFromName("Yes"));
	YesButton->OnClicked.AddUniqueDynamic(this, &UBondRewardInfoPopupWidget::OnYesButtonClicked);

	BondRewardListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("BondReward"));
}

void UBondRewardInfoPopupWidget::SetInfo(FCharacterType CharacterType)
{
	BondRewardListWidget->ClearList();

	int32 CurrentBondLevel = 1;
	const UBondManager& BondManager = GetHUDStore().GetBondManager();
	const FCharacterBond* CharacterBond = BondManager.Find(CharacterType);

	if (CharacterBond)
	{
		CurrentBondLevel = CharacterBond->Level;
	}

	CurrentBondText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Common", "Temperature"), FText::AsNumber(BondTemperaturePerLevel * CurrentBondLevel)));

	const UCMS* CMS = GetCMS();
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterType);
	if (CharacterRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UBondRewardInfoPopupWidget::SetInfo - CharacterRow does not exist.",
			Q6KV("CharacterType", CharacterType));
		return;
	}

	const FCMSUnitRow& UnitRow = CharacterRow.GetUnit();
	if (UnitRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UBondRewardInfoPopupWidget::SetInfo - UnitRoes do not exist.");
		return;
	}

	NameText->SetText(UnitRow.FullName);

	// Reward starts at Lv.2
	for (int32 i = 2; i <= MaxBondLevel; ++i)
	{
		const FCMSBondRewardRow* BondRewardRow = CMS->GetBondRewardRow(CharacterType, i);
		if (!BondRewardRow)
		{
			Q6JsonLogGunny(Warning, "UBondRewardInfoPopupWidget::SetInfo - BondRewardRow does not exist.",
				Q6KV("CharacterType", CharacterType), Q6KV("BondLevel", i));
			continue;
		}

		UBondRewardInfoListWidget* ListWidget = CastChecked<UBondRewardInfoListWidget>(BondRewardListWidget->AddChildAtLastIndex());
		ListWidget->SetInfo(i, BondRewardRow);
	}
}

void UBondRewardInfoPopupWidget::OnYesButtonClicked()
{
	ClosePopup();
}

URaidJoinPopupWidget::URaidJoinPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer),
	bEnoughWatt(false),
	bVisible(true)
{

}

bool URaidJoinPopupWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	return true;
}

void URaidJoinPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IntroAnim = GetWidgetAnimationFromName(this, "AnimIntro");

	JoinButton = CastChecked<UButton>(GetWidgetFromName("Join"));
	JoinButton->OnClicked.AddUniqueDynamic(this, &URaidJoinPopupWidget::OnYesButtonClicked);

	PointWidget = CastChecked<UPointWidget>(GetWidgetFromName("Point"));
	PointWidget->SetPointType(EPointType::Watt, EPointWidgetOption::LessEqual);

	RaidNameText = CastChecked<UTextBlock>(GetWidgetFromName("RaidName"));

	OnDismissButtonClickedDelegate.BindUObject(this, &URaidJoinPopupWidget::OnDismiss);
}

void URaidJoinPopupWidget::OnDismiss()
{
	ACTION_DISPATCH_MuteRaidJoinPopup();
}

void URaidJoinPopupWidget::SetInfo(const FCMSSagaRow& SagaRow, ERaidCategory InRaidCategory)
{
	PlayAnimation(IntroAnim);

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	int32 CurWatt = WorldUser.GetWatt();

	PointWidget->SetPoint(SagaRow.WattConsume, CurWatt);
	bEnoughWatt = SagaRow.WattConsume <= CurWatt;
	RaidNameText->SetText(SagaRow.DescName);

	RaidCategory = InRaidCategory;
	SetRaidJoinPopupWidgetState(RaidCategory);
}

void URaidJoinPopupWidget::JumpToRaid()
{
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	switch (RaidCategory)
	{
		case ERaidCategory::GeneralRaid:
		{
			FRaidType OpenRaidType = RaidManager.GetOpenRaidType();
			if (OpenRaidType == RaidTypeInvalid)
			{
				return;
			}

			RaidManager.ReqPrepare();
		}
		break;
	}

	ABaseHUD* BaseHUD = GetBaseHUD(this);
	if (BaseHUD)
	{
		BaseHUD->CloseAllPopups();
	}

	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(this))
	{
		LobbyHUD->SetHUDType(EHUDWidgetType::Raid);
	}
	else
	{
		ACTION_DISPATCH_MenuChange(EHUDWidgetType::Raid, true);
		ULevelUtil::LoadLobbyLevel(GetWorld());
	}
}

void URaidJoinPopupWidget::OnYesButtonClicked()
{
	ABaseHUD* BaseHUD = GetBaseHUD(this);
	if (!BaseHUD)
	{
		ClosePopup();
		return;
	}

	if (!bEnoughWatt)
	{
		BaseHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "NotEnoughWattRaid"));
		ClosePopup();
		return;
	}

	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	if (RaidManager.IsRaidListFull())
	{
		BaseHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "RaidFinalBattleListFull"));
		ClosePopup();
		return;
	}

	if (BaseHUD->GetHUDType() == EHUDType::Combat)
	{
		UConfirmPopupWidget* ConfirmPopup = GetBaseHUD(this)->OpenConfirmPopup(
			Q6Util::GetLocalizedText("Popup", "RaidPopupTitle"),
			Q6Util::GetLocalizedText("Popup", "RaidPopupContent"));

		ConfirmPopup->SetYesNoText(
			Q6Util::GetLocalizedText("Popup", "Attend"),
			Q6Util::GetLocalizedText("Popup", "Cancel"));

		ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &URaidJoinPopupWidget::OnEnterRaidButtonClicked);
	}
	else
	{
		JumpToRaid();
	}

	ClosePopup();
}

void URaidJoinPopupWidget::OnEnterRaidButtonClicked(EConfirmPopupFlag InPopupFlag)
{
	if (InPopupFlag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	UQ6GameInstance::Get(this)->RequestQuitStage();

	JumpToRaid();
}

void UCheatCommandHelpPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CommandListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("CommandList"));
	HistoryListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("History"));

	CommandInputBox = CastChecked<UEditableTextBox>(GetWidgetFromName("CommandInput"));
	CommandInputBox->OnTextCommitted.AddUniqueDynamic(this, &UCheatCommandHelpPopupWidget::OnCommandCommitted);

	MenuButtonBox = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("BoxMenuButton"));
	MenuButtonBox->OnToggleButtonClickedDelegate.BindUObject(this, &UCheatCommandHelpPopupWidget::OnChangedMenu);

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("SwitcherMenu"));

#if !UE_BUILD_SHIPPING
	UQ6Button* ExecuteButton = CastChecked<UQ6Button>(GetWidgetFromName("Execute"));
	ExecuteButton->OnClickedDelegate.BindUObject(this, &UCheatCommandHelpPopupWidget::OnExecuteButtonClicked);

	UQ6Button* ClearButton = CastChecked<UQ6Button>(GetWidgetFromName("Clear"));
	ClearButton->OnClickedDelegate.BindUObject(this, &UCheatCommandHelpPopupWidget::OnClearButtonClicked);
#endif
}

#if !UE_BUILD_SHIPPING
void UCheatCommandHelpPopupWidget::SetHelp(const TArray<IConsoleObject*>& ConsoleObjects, const TArray<FString>& CommandHistory)
{
	SetCommandList(ConsoleObjects);
	SetCommandHistory(CommandHistory);

	MenuButtonBox->SetSelectedIndex(0);
}

void UCheatCommandHelpPopupWidget::SetCommandList(const TArray<IConsoleObject*>& ConsoleObjects)
{
	CommandInputBox->SetText(FText::GetEmpty());
	CommandListWidget->ClearList();

	FString HelpStr;
	for (int32 i = 0; i < ConsoleObjects.Num(); ++i)
	{
		const IConsoleObject* ConsoleObject = ConsoleObjects[i];
		if (!ConsoleObject)
		{
			continue;
		}

		HelpStr = FString::Printf(TEXT("[Shorcut %d]\r\n : %s"), i, ConsoleObject->GetHelp());
		UToggleButtonWidget* CheatButton = AddCheatButtonAtLast(CommandListWidget, HelpStr);
		CheatButton->OnToggleButtonClickedDelegate.BindUObject(this, &UCheatCommandHelpPopupWidget::OnSelectedCommand, ConsoleObject->GetHelp());
	}
}

void UCheatCommandHelpPopupWidget::SetCommandHistory(const TArray<FString>& CommandHistory)
{
	HistoryListWidget->ClearList();

	for (int32 i = CommandHistory.Num() - 1; i >= 0; --i)
	{
		const FString& ConsoleCommand = CommandHistory[i];

		UToggleButtonWidget* CheatButton = AddCheatButtonAtLast(HistoryListWidget, ConsoleCommand);
		CheatButton->OnToggleButtonClickedDelegate.BindUObject(this, &UCheatCommandHelpPopupWidget::OnSelectedHistory, ConsoleCommand);
	}
}

UToggleButtonWidget* UCheatCommandHelpPopupWidget::AddCheatButtonAtLast(UDynamicListWidget* ListWidget, const FString& DisplayStr)
{
	UToggleButtonWidget* CheatButton = CastChecked<UToggleButtonWidget>(ListWidget->AddChildAtLastIndex());
	CheatButton->SetButtonName(FText::FromString(DisplayStr));

	UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(CheatButton->Slot);
	GridSlot->SetHorizontalAlignment(HAlign_Fill);

	return CheatButton;
}

void UCheatCommandHelpPopupWidget::ExecuteCheatCommand(const FString& ExecuteCommand)
{
	if (ExecuteCommand.Equals(TEXT("h")))
	{
		return;
	}

	ABasePlayerController* BasePC = Cast<ABasePlayerController>(GetWorld()->GetFirstPlayerController());
	if (!BasePC)
	{
		Q6JsonLogRoze(Error, "UCheatCommandHelpPopupWidget::ExecuteCheatCommand - Can't execute cheat command", Q6KV("Command", *ExecuteCommand));
		return;
	}

	FString CommandStr = TEXT("Command execute complete!!\r\n");
	CommandStr.Append(BasePC->ConsoleCommand(ExecuteCommand));
	if (ABaseHUD* BaseHUD = GetBaseHUD(this))
	{
		BaseHUD->ShowNotification(ENotificationType::Short, FText::FromString(CommandStr));
	}

	AddCommandHistory(ExecuteCommand);
}

void UCheatCommandHelpPopupWidget::AddCommandHistory(const FString& NewCommand)
{
	if (HistoryListWidget->GetChildrenCount() < MAX_COMMAND_HISTORY_COUNT)
	{
		AddCheatButtonAtLast(HistoryListWidget, FString());
	}

	// Shift indexes without last index

	for (int32 i = HistoryListWidget->GetChildrenCount() - 2; i >= 0; --i)
	{
		UToggleButtonWidget* CheatButton = CastChecked<UToggleButtonWidget>(HistoryListWidget->FindChildAt(i));
		UToggleButtonWidget* ShiftButton = CastChecked<UToggleButtonWidget>(HistoryListWidget->FindChildAt(i + 1));

		const FText& CheatButtonName = CheatButton->GetButtonName();
		ShiftButton->SetButtonName(CheatButton->GetButtonName());
		ShiftButton->OnToggleButtonClickedDelegate.BindUObject(this, &UCheatCommandHelpPopupWidget::OnSelectedHistory, CheatButtonName.ToString());
	}

	// Set new first index cheat button and text
	UToggleButtonWidget* NewHistoryButton = CastChecked<UToggleButtonWidget>(HistoryListWidget->FindChildAt(0));
	NewHistoryButton->SetButtonName(FText::FromString(NewCommand));
	NewHistoryButton->OnToggleButtonClickedDelegate.BindUObject(this, &UCheatCommandHelpPopupWidget::OnSelectedHistory, NewCommand);
}

#endif

void UCheatCommandHelpPopupWidget::OnCommandCommitted(const FText& Text, ETextCommit::Type CommitMethod)
{
#if !UE_BUILD_SHIPPING
	if (CommitMethod != ETextCommit::Type::OnEnter)
	{
		return;
	}

	ExecuteCheatCommand(Text.ToString());

#endif
}

void UCheatCommandHelpPopupWidget::OnChangedMenu(int32 SelectedIndex)
{
#if !UE_BUILD_SHIPPING
	MenuSwitcher->SetActiveWidgetIndex(SelectedIndex);
#endif
}

#if !UE_BUILD_SHIPPING
void UCheatCommandHelpPopupWidget::OnSelectedCommand(const TCHAR* Command)
{
	FString CommandStr = FString(Command);
	FString LeftStr, RightStr;
	CommandStr.Split(FString(TEXT(" ")), &LeftStr, &RightStr);

	if (LeftStr.IsEmpty())
	{
		LeftStr = CommandStr;
	}

	LeftStr.AppendChar(' ');
	CommandInputBox->SetText(FText::FromString(LeftStr));
	CommandInputBox->SetKeyboardFocus();
}

void UCheatCommandHelpPopupWidget::OnExecuteButtonClicked()
{
	OnCommandCommitted(CommandInputBox->GetText(), ETextCommit::Type::OnEnter);
}

void UCheatCommandHelpPopupWidget::OnClearButtonClicked()
{
	CommandInputBox->SetText(FText::GetEmpty());
}

void UCheatCommandHelpPopupWidget::OnSelectedHistory(FString ExecuteString)
{
	CommandInputBox->SetText(FText::FromString(ExecuteString));
}

#endif

UItemReceivedPopupWidget::UItemReceivedPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UItemReceivedPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
}

bool UItemReceivedPopupWidget::IsStackableItemData(const FItemData& InItemData) const
{
	if (InItemData.Category == ELootCategory::SculptureCard ||
		InItemData.Category == ELootCategory::RelicCard ||
		InItemData.Category == ELootCategory::LobbyTemplate)
	{
		return false;
	}

	if (InItemData.Category == ELootCategory::CharacterCard)
	{
		const FCMSCharacterRow& InCharacterRow = GetCMS()->GetCharacterRowOrDummy(FCharacterType(InItemData.Type));
		return InCharacterRow.XpExclusive;
	}

	return true;
}

void UItemReceivedPopupWidget::SetItem(const TArray<FItemData>& ItemData)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ItemReceivedTitle"));

	ItemListWidget->ClearList();

	for (const FItemData& Item : ItemData)
	{
		UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetItem(Item);
	}
}

void UItemReceivedPopupWidget::SetBuyItem(FShopType InShopType, int32 InCount)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ItemReceivedTitle"));

	const FCMSShopRow& ShopRow = GetCMS()->GetShopRowOrDummy(InShopType);
	FItemData GetItemData;
	GetItemData.Category = ShopRow.ItemCategory;
	GetItemData.Type = ShopRow.ItemId;
	GetItemData.Count = ShopRow.Count * InCount;

	ItemListWidget->ClearList();

	// Unstackable item should be displayed separately
	if (!IsStackableItemData(GetItemData))
	{
		for (int i = 0; i < ShopRow.Count; ++i)
		{
			UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetItem(GetItemData);
		}
	}
	else
	{
		UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetItem(GetItemData);
	}
}

void UItemReceivedPopupWidget::SetMissionReceivedItem(const FCMSLootDataRow& InLootDataRow)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ItemReceivedTitle"));

	ItemListWidget->ClearList();

	UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
	ItemWidget->SetRewardType(ERewardType::None);
	ItemWidget->SetLoot(InLootDataRow.LootId, InLootDataRow.Count);
}

void UItemReceivedPopupWidget::SetAlchemyLabReceivedItem(const int32 ProductType, const int32 Count)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ItemReceivedTitle"));

	const FCMSAlchemyLabRow& AlchemyLabRow = GetCMS()->GetAlchemyLabRowOrDummy(
		FAlchemyLabType(ProductType));
	if (AlchemyLabRow.IsInvalid())
	{
		return;
	}

	ItemListWidget->ClearList();

	switch (AlchemyLabRow.ProductCategory)
	{
		case EAlchemyProductCategory::Lumicube:
		{
			UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetCurrency(ECurrencyType::Lumicube, Count);
		}
		break;
		case EAlchemyProductCategory::Relic:
		{
			const FCMSRelicRow& Product = GetCMS()->GetRelicRowOrDummy(
				FRelicType(AlchemyLabRow.ProductValue));
			if (Product.IsInvalid())
			{
				return;
			}

			UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetRelic(Product.CmsType(), Count);
		}
		break;
		case EAlchemyProductCategory::Sculpture:
		{
			const FCMSSculptureRow& Product = GetCMS()->GetSculptureRowOrDummy(
				FSculptureType(AlchemyLabRow.ProductValue));
			if (Product.IsInvalid())
			{
				return;
			}

			UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetSculpture(Product.CmsType(), Count);
		}
		break;
	}
}

UWithdrawPopupWidget::UWithdrawPopupWidget(const FObjectInitializer& ObjectInitializer)
: Super(ObjectInitializer)
{

}

void UWithdrawPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetTitle(Q6Util::GetLocalizedText("Popup", "WithdrawPopupTitle"));

	// Widgets
	ItemDropListWidget = CastChecked<UItemDropListWidget>(GetWidgetFromName("ItemDropList"));
	ContentText = CastChecked<UTextBlock>(GetWidgetFromName("Content"));
	NoItemText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextNoItem"));

	WithdrawButton = CastChecked<UButton>(GetWidgetFromName("Withdraw"));
	WithdrawButton->OnClicked.AddUniqueDynamic(this, &UWithdrawPopupWidget::OnWithdrawButtonClicked);
	CancelButton = CastChecked<UButton>(GetWidgetFromName("Cancel"));
	CancelButton->OnClicked.AddUniqueDynamic(this, &UWithdrawPopupWidget::OnCancelButtonClicked);

	ItemDropListWidget->SetItemDropInfo();

	NoItemText->SetVisibility(GetCheckedCombatHUD(this)->HasItemDrop() ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);
}

void UWithdrawPopupWidget::SetContentType(EContentType InContentType)
{
	if (InContentType == EContentType::MultiSideBattle)
	{
		ContentText->SetText(Q6Util::GetLocalizedText("Popup", "WithdrawPopupMultisideContent"));
	}
	else
	{
		ContentText->SetText(Q6Util::GetLocalizedText("Popup", "WithdrawPopupContent"));
	}
}

void UWithdrawPopupWidget::OnWithdrawButtonClicked()
{
	GetCheckedCombatCube(this)->Withdraw();
	ClosePopup();
}

void UWithdrawPopupWidget::OnCancelButtonClicked()
{
	ClosePopup();
}
