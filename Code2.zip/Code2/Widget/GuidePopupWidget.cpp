#include "GuidePopupWidget.h"

#include "AchievementsPageWidgets.h"
#include "BondManager.h"
#include "CharacterManager.h"
#include "CharMissionManager.h"
#include "ItemWidgets.h"
#include "LevelUtil.h"
#include "PetManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "SpecialManager.h"
#include "SystemConst_gen.h"
#include "TempleManager.h"
#include "TutorialWidget.h"
#include "VacationManager.h"
#include "WidgetUtil.h"
#include "CharacterManager.h"

UGuideBase::~UGuideBase()
{
}

void UGuideBase::GuideSpecialWonder(const ESpecialCategory SpecialCategory, const EWonderCategory WonderCategory)
{
	const USpecialManager& SpecialManager = GetHUDStore().GetSpecialManager();
	bool bOpenedStage = SpecialManager.HasOpenedStage(SpecialCategory);
	if (!bOpenedStage)
	{
		return;
	}

	bool bOpenedWonderStage = SpecialManager.HasOpenedWonderStage(WonderCategory);
	if (!bOpenedWonderStage)
	{
		return;
	}

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Special);
	ACTION_DISPATCH_SpecialEpisodeList(SpecialCategory);
	ACTION_DISPATCH_SpecialWonderStageList(WonderCategory);
}

void UGuideBase::GuideSpecialBoss()
{
	bool bOpenedStage = GetHUDStore().GetSpecialManager().HasOpenedStage(ESpecialCategory::Saga);
	if (!bOpenedStage)
	{
		return;
	}

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Special);
	ACTION_DISPATCH_SpecialSagaStageList();
}

void UGuideBase::GuideWonder(const EWonderCategory WonderCategory)
{
	FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(WonderCategory);
	if (!WonderInfo.bOpened)
	{
		return;
	}

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Wonder);
	ACTION_DISPATCH_WonderMenu(WonderCategory, WonderInfo.Level);
}

UGuidePopupWidget::UGuidePopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UGuidePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CaptureWidget = CastChecked<UTutorialCaptureWidget>(GetWidgetFromName("Talker"));
	CaptureWidget->OnGuideBtnClickedDelegate.BindUObject(this, &UGuidePopupWidget::OnGuideButtonClicked);
}

void UGuidePopupWidget::ShowGuidePopupWidget(const FRewardStep& InRewardStep)
{
	if (!IsInViewport())
	{
		AddToViewport(ZORDER_POPUP);
	}

	RewardStep = InRewardStep;

	CaptureWidget->SetGuideInfo(RewardStep);
}

void UGuidePopupWidget::OnGuideButtonClicked(bool bMove)
{
	ULevelUtil::SetCurrentCaptureActor(GetWorld(), false, "Capture.Tutorial");

	if (bMove)
	{
		GuideContent();
	}
	else
	{
		ShowNextReward();
	}

	RemoveFromParent();
}

void UGuidePopupWidget::ShowNextReward()
{
	GetCheckedLobbyHUD(this)->ProcessReward(false);
}

void UGuidePopupWidget::GuideContent()
{
	UGameResource& GameResource = GetGameResource();
	const FGuideActionAssetRow* GuideActionAssetRow = GameResource.GetGuideActionAssetRow(
		RewardStep.ContentFeatureOpenType);
	if (!GuideActionAssetRow)
	{
		return;
	}

	const FCMSContentFeatureOpenRow& FeatureOpenRow = GetCMS()->GetContentFeatureOpenRowOrDummy(
		FContentFeatureOpenType(RewardStep.ContentFeatureOpenType));
	if (FeatureOpenRow.IsInvalid())
	{
		return;
	}

	if (!GuideActionAssetRow->BindClass.Get())
	{
		GuideActionAssetRow->BindClass.LoadSynchronous();
	}

	UGuideBase* GuideBase = NewObject<UGuideBase>(this, GuideActionAssetRow->BindClass.Get());
	if (GuideBase)
	{
		GuideBase->DoAction(FeatureOpenRow);
	}
}

void UGuideSepcialWonder::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	const FCMSSpecialRow& SpecialRow = GetCMS()->GetSpecialRowOrDummy(FSpecialType(Row.OpenValue));
	if (SpecialRow.IsInvalid())
	{
		return;
	}

	switch (Row.ConditionType)
	{
		case EFeatureOpenConditionType::VacationLevelUp:
		{
			const int32 VacationLevel = GetHUDStore().GetVacationManager().GetLevel();
			if (VacationLevel < Row.ConditionValue)
			{
				return;
			}
		}
		break;
	}

	EWonderCategory WonderCategory(EWonderCategory::Main);
	switch (SpecialRow.ConditionType)
	{
		case ESpecialCategory::Temple:
		case ESpecialCategory::Vacation:
		case ESpecialCategory::Pet:
		case ESpecialCategory::PetSecondSkill:
		case ESpecialCategory::PetThirdSkill:
		case ESpecialCategory::Smelter:
		case ESpecialCategory::AlchemyLab:
		{
			WonderCategory = GetWonderCategory(SpecialRow.ConditionType);
		}
		break;
		case ESpecialCategory::Wonder:
		{
			WonderCategory = static_cast<EWonderCategory>(SpecialRow.ConditionId);
		}
		break;
	}

	if (WonderCategory == EWonderCategory::Main)
	{
		return;
	}

	GuideSpecialWonder(ESpecialCategory::Wonder, WonderCategory);
}

void UGuideSepcialBoss::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	const FCMSSpecialRow& SpecialRow = GetCMS()->GetSpecialRowOrDummy(FSpecialType(Row.OpenValue));
	if (SpecialRow.IsInvalid())
	{
		return;
	}

	bool bOpenedBossStage = GetHUDStore().GetSpecialManager().HasOpenedBossStage(
		SpecialRow.Episode);
	if (!bOpenedBossStage)
	{
		return;
	}

	GuideSpecialBoss();
}

void UGuideSepcialCharacter::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	bool bOpenedStage = GetHUDStore().GetSpecialManager().HasOpenedStage(ESpecialCategory::Character);
	if (!bOpenedStage)
	{
		return;
	}

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Special);
	ACTION_DISPATCH_SpecialEpisodeList(ESpecialCategory::Character);
}

void UGuideWeeklyMission::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Mission);
}

void UGuideCharMission::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	FCharacterType TargetCharacterType(1);

	UHUDStore& HUDStore = GetHUDStore();
	const UCharacterManager& CharacterManager = HUDStore.GetCharacterManager();
	FCharacterId CharacterId = CharacterManager.GetFirstCharacterIdByCharacterType(TargetCharacterType);
	if (CharacterId == FCharacterId::InvalidValue())
	{
		return;
	}

	const FCharacter* Character = CharacterManager.Find(CharacterId);
	if (!Character)
	{
		return;
	}

	const FCharacterBond& CharacterBond = HUDStore.GetBondManager().GetCharacterBond(TargetCharacterType);

	FItemIconInfo ItemIconInfo;
	ConvertCharacterToItemInfo(EAttributeCategory::Character, Character->GetInfo(), CharacterBond, &ItemIconInfo);

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Collection);

	UItemDetailWidget* ItemDetailWidget = GetBaseHUD(this)->OpenItemDetailPopup(ItemIconInfo);
	check(ItemDetailWidget);

	UAchievementsPageWidget* AchievementsPageWidget = GetLobbyHUD(this)->OpenAchievementsPagePopup();
	AchievementsPageWidget->InitAchievementsPage(FCharacterType(ItemIconInfo.Type));
}

void UGuideDailyDungeon::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	GetCheckedLobbyHUD(this)->OpenDailyDungeon();
}

void UGuideShopSell::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Shop);
	ACTION_DISPATCH_ShopMenuChange(EShopMenu::Sell, true);
}

void UGuideTrainingCenter::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::TrainingCenter);
}

void UGuideWonder::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	EWonderCategory TargetWonderCategory = GetWonderCategory(Row.OpenType);
	if (TargetWonderCategory == EWonderCategory::Main)
	{
		return;
	}

	GuideWonder(TargetWonderCategory);
}

void UGuideWonderArtifact::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	const FArtifact* Artifact = GetHUDStore().GetTempleManager().GetArtifact(Row.OpenValue - 1);
	if (!Artifact)
	{
		return;
	}

	GuideWonder(EWonderCategory::Temple);
}

void UGuideWonderPet::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	FPetType TargetPetType(Row.OpenValue);

	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().GetPet(TargetPetType);
	if (!PetInfo)
	{
		return;
	}

	GuideWonder(EWonderCategory::PetPark);
}

void UGuideWonderPetSkill::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	FPetType TargetPetType(Row.OpenValue);

	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().GetPet(TargetPetType);
	if (!PetInfo)
	{
		return;
	}

	switch (Row.OpenType)
	{
		case EFeatureOpenType::PetSecondSkill:
		{
			if (PetInfo->Skill2Level == 0)
			{
				return;
			}
		}
		break;
		case EFeatureOpenType::PetThirdSkill:
		{
			if (PetInfo->Skill3Level == 0)
			{
				return;
			}
		}
		break;
	}

	GuideWonder(EWonderCategory::PetPark);
}

void UGuideWonderVacation::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	const int32 VacationLevel = GetHUDStore().GetVacationManager().GetLevel();
	if (VacationLevel < Row.OpenValue)
	{
		return;
	}

	GuideWonder(EWonderCategory::Vacation);
}

void UGuideSubPartySlot::DoAction(const FCMSContentFeatureOpenRow& Row)
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Party);
}
