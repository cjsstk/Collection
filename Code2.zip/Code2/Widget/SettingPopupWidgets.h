#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "Q6GameUserSettings.h"

#include "SettingPopupWidgets.generated.h"
class UToggleButtonWidget;
class UProgressBarControlWidget;

UCLASS()
class Q6_API USettingPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	USettingPopupWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetView();

private:

	// Widgets

	UFUNCTION()
	void OnResetClicked();

	UFUNCTION()
	void OnSubmitClicked();

	UFUNCTION()
	void OnCategoryChanged(int32 ChangedIndex);

	// Setting View

	void OnGraphicQualityChanged(int32 ChangedIndex);
	void OnAntiAliasingQualityChanged(int32 ChangedIndex);
	void OnOutlineQualityChanged(int32 ChangedIndex);
	void OnFrameRateChanged(int32 ChangedIndex);

	void OnShowUltimateChanged(int32 ChangedIndex);

	void OnBGMSliderChanged(float Value);
	void OnUISliderChanged(float Value);
	void OnEffectSliderChanged(float Value);
	void OnVoiceSliderChanged(float Value);
	void OnTextSpeedChanged(float Value);
	void OnAutoTextSpeedChanged(float Value);

	// Notice View

	void ReceiveNoticeToggle();

	void ReloadQualityView();
	void ReloadNoticeView();
	void SaveSetting();
	void ApplySetting();

	UPROPERTY()
	UToggleButtonBoxWidget* CategoryButton;

	UPROPERTY()
	UButton* ResetButton;

	UPROPERTY()
	UButton* SubmitButton;

	UPROPERTY()
	UWidgetSwitcher* WidgetSwitcher;

	// setting
	UPROPERTY()
	UToggleButtonBoxWidget* GraphicQualityButton;

	UPROPERTY()
	UToggleButtonBoxWidget* AntiAliasingQualityButton;

	UPROPERTY()
	UToggleButtonBoxWidget* OutlineQualityButton;

	UPROPERTY()
	UToggleButtonBoxWidget* FrameRateButton;

	UPROPERTY()
	UToggleButtonBoxWidget* ShowUltimateButton;

	//sound
	UPROPERTY()
	UProgressBarControlWidget* BGMWidget;

	UPROPERTY()
	UProgressBarControlWidget* SoundEffectWidget;

	UPROPERTY()
	UProgressBarControlWidget* UIWidget;

	UPROPERTY()
	UProgressBarControlWidget* VoiceWidget;

	UPROPERTY()
	UProgressBarControlWidget* TextSpeed;

	UPROPERTY()
	UProgressBarControlWidget* AutoTextSpeed;

	// notice
	UPROPERTY()
	UToggleButtonWidget* ReceiveNoticeButton;

	ESettingMenu SettingMenu;
	FGameSettingData GameSettingData;
	FGameNoticeData GameNoticeData;

	bool bOnReload;
};
