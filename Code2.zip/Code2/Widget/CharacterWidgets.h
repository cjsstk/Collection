// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"

#include "PopupWidgets.h"
#include "CMSType_gen.h"
#include "LobbyObj_gen.h"

#include "CharacterWidgets.generated.h"

class UItemLevelWidget;
class UStarBarWidget;

struct FCMSSkillRow;

enum class EUnitAttribute : uint8;

UCLASS()
class Q6_API USkillIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USkillIconWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetSkill(const FSlateBrush& SkillIcon, int32 Level = 0);

private:
	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UTextBlock* LevelText;
};


UCLASS()
class Q6_API UTurnSkillIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UTurnSkillIconWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetSkill(const FSlateBrush& SkillIcon, int32 InSkillLevel = 0);
	void SetSelected(bool bSelected);
	void SetLocked(bool bInLocked);
	void SetNewMarkVisibility(ESlateVisibility InVisibility);

	bool IsLocked() const { return bLocked; }

	FSimpleDelegate OnSelectButtonClickedDelegate;

private:
	UPROPERTY(Transient)
	UWidgetAnimation* SelectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UnselectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* OpenedAnim;

	UPROPERTY()
	UButton* SelectButton;

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UTextBlock* SkillLevelText;

	UPROPERTY()
	UTextBlock* SkillLevelLabel;

	UPROPERTY()
	UImage* NewMarkImage;

	UFUNCTION()
	void OnSelectButtonClicked();

	bool bLocked;
};

UCLASS()
class Q6_API UItemLabelWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemLabelWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCharacter(const FText& Name, EItemGrade Grade, ENatureType NatureType, int32 Star, int32 Moon);
	void SetEquip(const FText& Name, EItemGrade Grade, int32 Star, int32 Tier);

private:
	void SetItem(const FText& Name, EItemGrade Grade, int32 Star, int32 Moon = 0);

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UStarBarWidget* StarBarWidget;

	UPROPERTY()
	UImage* OptionImage;

	UPROPERTY()
	UTextBlock* NameText;
};

UCLASS()
class Q6_API UCharacterLabelWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCharacterLabelWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCharacter(const FCMSCharacterRow& CharacterRow);

private:
	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* NatureImage;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* NickNameText;
};

UCLASS()
class Q6_API UStatWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UStatWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetEmpty();
	void SetStat(EUnitAttribute Attr, int64 Value);
	void SetStat(EUnitAttribute Attr, int64 Value, int64 ResultValue);

private:
	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* ValueText;

	UPROPERTY()
	UTextBlock* ResultValueText;

	UPROPERTY()
	UHorizontalBox* ResultBox;
};

UCLASS()
class Q6_API UUpgradeStatWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UUpgradeStatWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCharacter(const FCharacterInfo& CharacterInfo, int32 GainXp = 0);
	void SetCharacterResult(const FCharacterInfo& CharacterInfo, int32 GainXp = 0);

	void SetRelic(const FRelicInfo& RelicInfo, int32 GainX, int32 AddedTier);
	void SetRelicResult(const FRelicInfo& RelicInfo, int32 GainXp, int32 AddedTier);

	void SetSculpture(const FSculptureInfo& SculptureInfo, int32 GainXp, int32 AddedTier);
	void SetSculptureResult(const FSculptureInfo& SculptureInfo, int32 GainXp, int32 AddedTier);

	void SetCharacterPromote(const FCharacterInfo& CharacterInfo);
	void SetRelicPromote(const FRelicInfo& RelicInfo);
	void SetSculpturePromote(const FSculptureInfo& SculptureInfo);

	void SetCharacterEvolute(const FCharacterInfo& CharacterInfo);

	void PlayLevelUpAnimation(bool bLevelUp);
	void SetVisibleStar(bool bInVisible);

private:
	void SetCharacter(FCharacterType CharacterType, EItemGrade ItemGrade, int32 Star, int32 Moon, int32 CurXp, int32 GainXp = 0);
	void SetRelic(FRelicType RelicType, EItemGrade ItemGrade, int32 Star, int32 CurXp, int32 CurTier, int32 GainXp,int32 AddedTier);
	void SetSculpture(FSculptureType SculptureType, EItemGrade ItemGrade, int32 Star, int32 CurXp, int32 CurTier, int32 GainXp, int32 AddedTier);

	void SetAddXp(int32 CurXp, int32 ReqXp, int32 AccXp, int32 UpReqXp, int32 UpAccXp, int32 GainXp, bool bLevelUp);
	void SetResultXp(int32 ResultXp, int32 ReqXp, int32 AccXp, bool bLevelUp);

	void SetCharacterStat(FCharacterType CharacterType, int32 Moon, int32 OldLevel, int32 NewLevel);
	void SetRelicStat(FRelicType RelicType, int32 OldLevel, int32 NewLevel, int32 OldTier, int32 NewTier);
	void SetSculptureStat(FSculptureType SculptureType, int32 OldLevel, int32 NewLevel, int32 OldTier, int32 NewTier);

	UPROPERTY()
	UItemLevelWidget* LevelWidget;

	UPROPERTY()
	UProgressBar* XPBar;

	UPROPERTY()
	UProgressBar* ResultXPBar;

	UPROPERTY()
	UTextBlock* RemainXPText;

	UPROPERTY()
	UTextBlock* GainXPText;

	UPROPERTY()
	UStatWidget* HpStatWidget;

	UPROPERTY()
	UStatWidget* AtkStatWidget;

	UPROPERTY()
	UStatWidget* DefStatWidget;

	UPROPERTY()
	UWidget* GainXPBox;

};

UCLASS()
class Q6_API UUpgradeResultStatWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UUpgradeResultStatWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCharacterPromote(const FCharacterInfo& CharacterInfo);
	void SetCharacterEvolute(const FCharacterInfo& CharacterInfo);
	void SetRelicPromote(const FRelicInfo& RelicInfo);
	void SetSculpturePromote(const FSculptureInfo& SculptureInfo);

private:
	UPROPERTY()
	UUpgradeStatWidget* OldStatWidget;

	UPROPERTY()
	UUpgradeStatWidget* NewStatWidget;
};

//////////////////////////////////////////////////////////////////////////
// BondWidgets
//////////////////////////////////////////////////////////////////////////

UCLASS()
class Q6_API UBondRewardWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetInfo(ELootCategory LootCategory, int32 Param);

private:
	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	URichTextBlock* RewardText;
};

UCLASS()
class Q6_API UBondRewardInfoListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetInfo(int32 BondLevel, const FCMSBondRewardRow* BondReward);

private:
	UPROPERTY()
	UTextBlock* BondText;

	UPROPERTY()
	TArray<UBondRewardWidget*> BondRewardWidgets;
};
