// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "PatchHUDWidget.h"

#include "BuildPatchState.h"
#include "HUD/BaseHUD.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "Utils/LevelUtil.h"

using namespace BuildPatchServices;

UPatchHUDWidget::UPatchHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bFinished(false)
	, bLoadGame(false)
	, bErrorState(false)
{
}

void UPatchHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StartPatchButton = CastChecked<UButton>(GetWidgetFromName("StartPatch"));
	StartPatchButton->OnClicked.AddUniqueDynamic(this, &UPatchHUDWidget::OnStartPatchButtonClicked);
	StartPatchButton->SetIsEnabled(false);

	PatchMsgTextBlock = CastChecked<UTextBlock>(GetWidgetFromName("PatchMsg"));
	PercentProgressBar = CastChecked<UProgressBar>(GetWidgetFromName("PatchProgress"));
	PercentTextBlock = CastChecked<UTextBlock>(GetWidgetFromName("PatchPercent"));
}

FText UPatchHUDWidget::GetPatchErrorMessage(EPatchSystemError InPatchSystemError)
{
	switch (InPatchSystemError)
	{
		case EPatchSystemError::FailedToDownloadDLCURL:
			return Q6Util::GetLocalizedTextOrKey("Service", "PatchFailedToDownloadDLCURL");
		case EPatchSystemError::ErrorToDownloadManifest:
			return Q6Util::GetLocalizedTextOrKey("Service", "PatchErrorToDownloadManifest");
		case EPatchSystemError::FailedToDownloadManifest:
			return Q6Util::GetLocalizedTextOrKey("Service", "PatchFailedToDownloadManifest");
		case EPatchSystemError::FailedToInit:
			return Q6Util::GetLocalizedTextOrKey("Service", "PatchFailedToInit");
		case EPatchSystemError::FailedToLoadManifest:
			return Q6Util::GetLocalizedTextOrKey("Service", "FailedToLoadManifest");
		default:
			return FText::GetEmpty();
	}
}

static FText GetPatchStateMessage(EPatchSystemState InPatchState, EBuildPatchState InBuildPatchState)
{
	switch (InPatchState)
	{
		case EPatchSystemState::Idle:
			return Q6Util::GetLocalizedTextOrKey("Patch", "Idle");
		case EPatchSystemState::DownloadDLCURL:
			return Q6Util::GetLocalizedTextOrKey("Patch", "DownloadDLCURL");
		case EPatchSystemState::DownloadingManifest:
			return Q6Util::GetLocalizedTextOrKey("Patch", "DownloadingManifest");
		case EPatchSystemState::ManifestDownloaded:
			return Q6Util::GetLocalizedTextOrKey("Patch", "ManifestDownloaded");
		case EPatchSystemState::Downloading:
		{
			switch (InBuildPatchState)
			{
			case EBuildPatchState::Queued: // The patch process is waiting for other installs
				return Q6Util::GetLocalizedTextOrKey("Patch", "Queued");
			case EBuildPatchState::Initializing: // The patch process is initializing
				return Q6Util::GetLocalizedTextOrKey("Patch", "Initializing");
			case EBuildPatchState::Resuming: // The patch process is enumerating existing staged data
				return Q6Util::GetLocalizedTextOrKey("Patch", "Resuming");
			case EBuildPatchState::Downloading: // The patch process is downloading patch data
				return Q6Util::GetLocalizedTextOrKey("Patch", "Downloading");
			case EBuildPatchState::Installing: // The patch process is installing files
				return Q6Util::GetLocalizedTextOrKey("Patch", "Installing");
			case EBuildPatchState::MovingToInstall: // The patch process is moving staged files to the install
				return Q6Util::GetLocalizedTextOrKey("Patch", "MovingToInstall");
			case EBuildPatchState::SettingAttributes: // The patch process is setting up attributes on the build
				return Q6Util::GetLocalizedTextOrKey("Patch", "SettingAttributes");
			case EBuildPatchState::BuildVerification: // The patch process is verifying the build
				return Q6Util::GetLocalizedTextOrKey("Patch", "BuildVerification");
			case EBuildPatchState::CleanUp: // The patch process is cleaning temp files
				return Q6Util::GetLocalizedTextOrKey("Patch", "CleanUp");
			case EBuildPatchState::PrerequisitesInstall: // The patch process is installing prerequisites
				return Q6Util::GetLocalizedTextOrKey("Patch", "PrerequisitesInstall");
			case EBuildPatchState::Completed: // A state to catch the UI when progress is 100% but UI still being displayed
				return Q6Util::GetLocalizedTextOrKey("Patch", "Complete");
			case EBuildPatchState::Paused: // The process has been set paused
				return Q6Util::GetLocalizedTextOrKey("Patch", "Paused");
			default:
				return Q6Util::GetLocalizedTextOrKey("Patch", "Downloading");
			}
		}
		case EPatchSystemState::LoadPSOCache:
			return Q6Util::GetLocalizedTextOrKey("Patch", "LoadPSOCache");
		default:
			return Q6Util::GetLocalizedTextOrKey("Patch", "Complete");
	}
}

void UPatchHUDWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	FQ6Patch& InQ6Patch = GetGameModule()->GetPatch();
	if (InQ6Patch.GetError() != EPatchSystemError::None)
	{
		if (!bErrorState)
		{
			bErrorState = true;
			GetBaseHUD(this)->OnFatal(GetPatchErrorMessage(InQ6Patch.GetError()));
		}
		return;
	}

	if (!bFinished)
	{
		if (InQ6Patch.GetPatchState() == EPatchSystemState::Downloading &&
			InQ6Patch.GetBuildInstallerPatchState() == EBuildPatchState::Downloading)
		{
			PercentTextBlock->SetText(FText::Format(FText::FromString("{0}% ({1} / {2})"),
				FText::AsNumber((int32)(InQ6Patch.GetProgress() * 100)),
				Q6Util::GetFormattedBytesText(InQ6Patch.GetTotalSizeDownloaded()),
				Q6Util::GetFormattedBytesText(InQ6Patch.GetTotalSizeToDownload())));
		}
		else
		{
			PercentTextBlock->SetText(FText::GetEmpty());
		}
		PercentProgressBar->SetPercent(InQ6Patch.GetProgress());
		PatchMsgTextBlock->SetText(GetPatchStateMessage(InQ6Patch.GetPatchState(), InQ6Patch.GetBuildInstallerPatchState()));
	}

	if (!bFinished && GetGameModule()->GetPatch().IsFinished())
	{
		bFinished = true;
		StartPatchButton->SetIsEnabled(true);
		PercentTextBlock->SetText(FText::Format(FText::FromString("100% ({0} downloaded)"), Q6Util::GetFormattedBytesText(InQ6Patch.GetTotalSizeDownloaded())));
		PercentProgressBar->SetPercent(1.f);
		PatchMsgTextBlock->SetText(GetPatchStateMessage(EPatchSystemState::Completed, EBuildPatchState::NUM_PROGRESS_STATES));
	}
}

void UPatchHUDWidget::OnStartPatchButtonClicked()
{
	if (bLoadGame)
	{
		return;
	}

	bLoadGame = true;

	GetGameModule()->LoadResource();
	UQ6GameInstance::Get()->InitializeSoundPlayer();

	GetGameModule()->GetPatch().LoadShaderCodeLibraryFromPluginAfterMountPak();

	ULevelUtil::LoadLoginLevel(GetWorld());
}