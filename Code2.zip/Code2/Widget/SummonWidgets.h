// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMSTable.h"
#include "LobbyHUDWidget.h"
#include "PopupWidgets.h"
#include "Q6.h"

#include "SummonWidgets.generated.h"

class UCharacterLabelWidget;
class UItemCardWidget;
class UHSEvent;
class UPageSwipeWidget;
class UPointWidget;
class USummonPickupWidget;

UCLASS()
class USummonButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonButtonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetFree(bool FreeFlag) { bIsFree = FreeFlag; }
	void SetBoxProduct(const FCMSBoxProductRow& BoxProductRow);

private:
	UFUNCTION()
	void OnPurchaseButtonClicked();

	void OnSummonPurchase();

	UPROPERTY()
	UTextBlock* SummonText;

	UPROPERTY()
	UTextBlock* CountText;

	UPROPERTY()
	UBorder* FreeTextBorder;

	UPROPERTY()
	UBorder* BonusBorder;

	UPROPERTY()
	USummonPointWidget* SummonPointWidget;

	UPROPERTY()
	UImage* NewMarkImage;

	FBoxProductType BoxProductType;

	bool bIsFree;
};

UCLASS()
class USummonPageWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonPageWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetSummonPage(int32 PageKey);

private:
	void OpenSelectPickupPopup();
	void OpenPickupConfirmPopup(FBoxProductType BoxProductType, int32 ItemType);

	void OnPickupItemSelected(int32 ItemType);

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	USummonButtonWidget* SingleButtonWidget;

	UPROPERTY()
	USummonButtonWidget* BundleButtonWidget;

	UPROPERTY()
	UTextBlock* PeriodText;

	UPROPERTY()
	UTextBlock* ConsumeDescriptionText;

	UPROPERTY()
	USummonPickupWidget* PickupWidget;

	UPROPERTY()
	USummonPointWidget* SummonPointWidget;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<USummonSelectPickupPopupWidget> SelectPickupPopupClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<USummonPickupConfirmPopupWidget> PickupConfirmPopupClass;

	FBoxProductType BoxProductType;
};


UCLASS()
class USummonResultWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonResultWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetSummonResult();

	FSimpleDelegate OnBackDelegate;

private:
	void SetCharacterResult(int32 Index, const FCharacterInfo* Info, bool IsOnce);
	void SetSculptureResult(int32 Index, const FSculptureInfo* Info, bool IsOnce);
	void SetRelicResult(int32 Index, const FRelicInfo* Info, bool IsOnce);

	void ClearResult();
	void ShowDiskRewardNotification();

	UFUNCTION()
	void OnBackButtonClicked();

	UFUNCTION()
	void OnSummonRepeatButtonClicked();

	void OnSummonPurchaseRepeat();

	// Widgets
	UPROPERTY()
	UItemCardWidget* SingleItemWidget;

	UPROPERTY()
	TArray<UItemCardWidget*> ItemWidgets;

	UPROPERTY()
	UButton* BackButton;

	UPROPERTY()
	UButton* SummonRepeatButton;

	UPROPERTY()
	UBorder* MileageBorder;

	UPROPERTY()
	UTextBlock* DeltaMileageText;

	UPROPERTY()
	UTextBlock* OwnedMileageText;

	UPROPERTY()
	UBorder* CurrencyBorder;

	UPROPERTY()
	USummonPointWidget* OwnedPointWidget;

	UPROPERTY()
	USummonPointWidget* ConsumePointWidget;

	UPROPERTY()
	UTextBlock* SummonCountText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* SingleSummonAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BundleSummonAnim;

	FBoxProductType BoxProductType;
};


UCLASS()
class USummonWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	USummonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Summon; }

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

	void RefreshSummonPage(int32 FocusPage);

	void OnSummonPageSet(UWidget* ViewWidget, int32 PageNum);
	void OnSummonPageChanged(int32 NewPage);
	void OnResultMenuBack();

	// Widget Class
	UPROPERTY(EditDefaultsOnly, Category = "SummonResult")
	TSoftClassPtr<USummonResultWidget> ResultWidgetClass;

	// Widgets.

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	UPageSwipeWidget* SummonSwipeWidget;

	UPROPERTY()
	USummonResultWidget* ResultWidget;

	UPROPERTY()
	bool bCanRepeatSummon;
};

UCLASS()
class USummonPickupWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonPickupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetMileage(FBoxProductType BoxProductType);

	FSimpleDelegate OnPickupButtonClickedDelegate;

private:
	UFUNCTION()
	void OnPickupButtonClicked();

	UPROPERTY()
	UTextBlock* MileageAmountText;

	UPROPERTY(Transient)
	UWidgetAnimation* MaxMileageLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NormalAnim;
};

UCLASS()
class USummonPickupCharacterWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonPickupCharacterWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCharacter(const FCharacterType& CharacterType, bool bInEnabled);

	FSimpleDelegate OnPickupButtonClickedDelegate;

private:
	UFUNCTION()
	void OnPickupButtonClicked();

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UButton* PickupButton;

	UPROPERTY()
	UCharacterLabelWidget* CharacterLabelWidget;
};

UCLASS()
class USummonSelectPickupPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	USummonSelectPickupPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetPickupList(FBoxProductType BoxProductType);

	FIntParamDelegate OnPickupSelectedDelegate;

private:
	void SetCharacterList(const TArray<int32>& CharacterTypes, bool bPickupEnabled);

	void OnSelectedPickupItem(int32 ItemType);

	UPROPERTY()
	UDynamicListWidget* PickupListWidget;

	UPROPERTY()
	UTextBlock* PeriodText;
};

UCLASS()
class USummonPickupConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	USummonPickupConfirmPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCharacter(FCharacterType SelectedCharacterType, const FCMSBoxProductRow& BoxProductRow);

private:
	void OnPickupConfirmButtonClicked(EConfirmPopupFlag ConfirmFlag, FBoxProductType BoxProductType, int32 ItemType);

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UCharacterLabelWidget* CharacterLabelWidget;

	UPROPERTY()
	UTextBlock* OwnedMileageText;

	UPROPERTY()
	UTextBlock* RequiredMileageText;
};

UCLASS()
class USummonPointWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonPointWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetConsumePoint(const FCMSBoxProductRow& BoxProductRow);
	void SetOwnedPoint(ESummonType SummonType, ESummonPointType PointType);

private:
	UPROPERTY()
	UPointWidget* TicketWidget;

	UPROPERTY()
	UPointWidget* PointWidget;
};
