// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatReadyWidgets.h"

#include "AccountWidgets.h"
#include "CharacterWidgets.h"
#include "CommonWidgets.h"
#include "FriendManager.h"
#include "FriendWidgets.h"
#include "GameResource.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "ItemWidgets.h"
#include "JokerSetManager.h"
#include "LobbyHUD.h"
#include "PartyManager.h"
#include "PartyWidgets.h"
#include "Q6.h"
#include "Q6Define.h"
#include "Q6GameInstance.h"
#include "Q6LobbyState.h"
#include "RaidManager.h"
#include "SkillWidgetUtil.h"
#include "StageWidgets.h"
#include "SortingWidgets.h"
#include "SystemConst_gen.h"
#include "WidgetUtil.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent JokerSelect"), STAT_OnHSEventByJokerSelect, STATGROUP_HSTORE);

UJokerEntryWidget::UJokerEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, JokerSlotIndex(static_cast<int32>(EJokerSlotType::All))
{

}

void UJokerEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterWidget = CastChecked<UItemCardWidget>(GetWidgetFromName("Character"));
	SculptureIconWidget = CastChecked<UEquipIconWidget>(GetWidgetFromName("Sculpture"));
	RelicIconWidget = CastChecked<UEquipIconWidget>(GetWidgetFromName("Relic"));

	UltimateSkillWidget = CastChecked<USkillIconWidget>(GetWidgetFromName("UltimateSkill"));
	SupportSkillWidget = CastChecked<USkillIconWidget>(GetWidgetFromName("SupportSkill"));

	FString WidgetName;
	for (int32 n = 1; n <= CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++n)
	{
		WidgetName = FString::Printf(TEXT("TurnSkill%d"), n);
		TurnSkillWidgets.AddUnique(CastChecked<UTurnSkillIconWidget>(GetWidgetFromName(*WidgetName)));
	}

	JokerTypeText = CastChecked<UTextBlock>(GetWidgetFromName("JokerType"));
	FriendshipImage = CastChecked<UImage>(GetWidgetFromName("IconFriendshipPoint"));
	IconBadgeImage = CastChecked<UImage>(GetWidgetFromName("IconBadge"));
	AkaBorder = CastChecked<UBorder>(GetWidgetFromName("AkaBox"));
	AkaText = CastChecked<URichTextBlock>(GetWidgetFromName("Aka"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	FriendNameText = CastChecked<UTextBlock>(GetWidgetFromName("FriendName"));
	ReasonText = CastChecked<UTextBlock>(GetWidgetFromName("Reason"));
	AvatarWidget = CastChecked<UAvatarIconWidget>(GetWidgetFromName("Avatar"));

	auto LastLoginLabel = CastChecked<UTextBlock>(GetWidgetFromName("TextLastLogin"));
	LastLoginLabel->SetText(Q6Util::GetLocalizedText("Common", "LastLogin"));

	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	LastLoginText = CastChecked<UTextBlock>(GetWidgetFromName("LastLogin"));
	FriendshipPointText = CastChecked<UTextBlock>(GetWidgetFromName("FriendshipPoint"));

	JokerSetButton = CastChecked<UButton>(GetWidgetFromName("JokerSet"));
	JokerSetButton->OnClicked.AddUniqueDynamic(this, &UJokerEntryWidget::OnJokerSetButtonClicked);

	DeclineButton = CastChecked<UButton>(GetWidgetFromName("Decline"));
	DeclineButton->OnClicked.AddUniqueDynamic(this, &UJokerEntryWidget::OnFriendDeclineButtonClicked);
	DeclineButtonText = CastChecked<UTextBlock>(GetWidgetFromName("TextDecline"));

	AcceptButton = CastChecked<UButton>(GetWidgetFromName("Accept"));
	AcceptButton->OnClicked.AddUniqueDynamic(this, &UJokerEntryWidget::OnFriendAcceptButtonClicked);
	AcceptButtonText = CastChecked<UTextBlock>(GetWidgetFromName("TextAccept"));

	SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.Clear();
}

void UJokerEntryWidget::SetSystemJoker(const FCMSCharacterRow* JokerCharacterRow, int32 InJokerLevel)
{
	check(JokerCharacterRow);

	SetJokerInfo(JokerCharacterRow, InJokerLevel);

	SelectButton->OnClicked.AddUniqueDynamic(this, &UJokerEntryWidget::OnSystemJokerSelected);

	const UCMS* CMS = GetCMS();
	const FCMSUnitRow* JokerUnitRow = &CMS->GetUnitRowOrDummy(JokerCharacterRow->CmsType());

	AkaBorder->SetVisibility(ESlateVisibility::Collapsed);
	JokerTypeText->SetText(Q6Util::GetLocalizedText("Common", "NPC"));
	FriendshipPointText->SetText(FText::FromString(FString::Printf(TEXT("+%d"), SystemConst::Q6_SYSTEM_JOKER_FRIENDSHIP_POINT)));
	NameText->SetText(JokerUnitRow->DescName);

	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(JokerUnitRow->Model);

	const FCMSSystemJokerRow& SystemJokerRow = CMS->GetSystemJokerRowOrDummy(FSystemJokerType(JokerUnitRow->Type));
	int32 SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	if (SystemJokerRow.IsInvalid())
	{
		Q6JsonLog(Warning, "can not found SystemJoker.", Q6KV("Type", JokerUnitRow->Type));
	}
	else
	{
		JokerInfo.UltimateSkillLevel = SystemJokerRow.UltimateSkillLevel;
		JokerInfo.TurnSkill1Level = SystemJokerRow.TurnSkillLevels.IsValidIndex(0) ? SystemJokerRow.TurnSkillLevels[0] : CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL;
		JokerInfo.TurnSkill2Level = SystemJokerRow.TurnSkillLevels.IsValidIndex(1) ? SystemJokerRow.TurnSkillLevels[1] : CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL;
		JokerInfo.TurnSkill3Level = SystemJokerRow.TurnSkillLevels.IsValidIndex(2) ? SystemJokerRow.TurnSkillLevels[2] : CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL;
		SupportSkillLevel = SystemJokerRow.SupportSkillLevel;
	}

	SetUnitSkillToWidget(SkillAssetRow, JokerInfo, SupportSkillLevel, UltimateSkillWidget, SupportSkillWidget, &TurnSkillWidgets);
	SetJokerInfoUi(&JokerInfo, nullptr, nullptr, nullptr, false);

	SetJokerType(EJokerCategory::NPC);
	SetMenu(false);
}

void UJokerEntryWidget::SetFriendJoker(const FFriendInfo& InFriendInfo, int32 InJokerSlotIndex, bool bFriend)
{
	FriendInfo = InFriendInfo;
	JokerSlotIndex = InJokerSlotIndex;

	SelectButton->OnClicked.AddUniqueDynamic(this, &UJokerEntryWidget::OnFriendJokerSelected);

	AkaBorder->SetVisibility(ESlateVisibility::Collapsed);
	JokerTypeText->SetText(Q6Util::GetLocalizedText("Common", "Joker"));
	FriendNameText->SetText(FText::FromString(InFriendInfo.Name));
	LevelText->SetText(FText::AsNumber(FriendInfo.Level));
	LastLoginText->SetText(Q6Util::GetHappendTime(FriendInfo.LastLogin));
	FriendshipPointText->SetText(FText::FromString(FString::Printf(TEXT("+%d"), bFriend ? SystemConst::Q6_FRIEND_JOKER_FRIENDSHIP_POINT : SystemConst::Q6_GUEST_JOKER_FRIENDSHIP_POINT)));

	const FFriendJokerSet& JokerSet = FriendInfo.JokerSet;
	check(JokerSet.Slots.Num() == EJokerSlotTypeMax);
	check(IsValidEJokerSlotType(JokerSlotIndex));
	const FFriendJokerSlot& Joker = JokerSet.Slots[JokerSlotIndex];

	JokerInfo = Joker.CharacterInfo;
	bool bValidJoker = !Joker.CharacterInfo.CharacterId.IsInvalid();
	if (bValidJoker)
	{
		const UCMS* CMS = GetCMS();
		const FCMSUnitRow* JokerUnitRow = &CMS->GetUnitRowOrDummy(JokerInfo.Type);

		NameText->SetText(JokerUnitRow->DescName);
		const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(JokerUnitRow->Model);
		SetUnitSkillToWidget(SkillAssetRow, JokerInfo, Joker.CharacterBond.SupportSkillLevel, UltimateSkillWidget, SupportSkillWidget, &TurnSkillWidgets);
		SetJokerInfoUi(&Joker.CharacterInfo, &Joker.CharacterBond, &Joker.SculptureInfo, &Joker.RelicInfo, bFriend);

		SetJokerSelectType(EJokerSelectType::Enabled);
	}
	else
	{
		SetJokerInfoUi(nullptr, nullptr, nullptr, nullptr, false);

		SetJokerSelectType(EJokerSelectType::NoSetDisabled);
	}

	SetJokerType(bFriend ? EJokerCategory::Friendly : EJokerCategory::User);
	SetMenu(false);
}

void UJokerEntryWidget::SetRandomJoker(const FCMSCharacterRow* JokerCharacterRow, int32 InJokerLevel)
{
	check(JokerCharacterRow);
	SetJokerInfo(JokerCharacterRow, InJokerLevel);

	CharacterWidget->SetVisibility(ESlateVisibility::Collapsed);
	SculptureIconWidget->SetVisibility(ESlateVisibility::Collapsed);
	RelicIconWidget->SetVisibility(ESlateVisibility::Collapsed);
	AkaBorder->SetVisibility(ESlateVisibility::Collapsed);

	SelectButton->OnClicked.AddUniqueDynamic(this, &UJokerEntryWidget::OnRandomJokerSelected);

	SetJokerSelectType(EJokerSelectType::RandomJokerEnabled);
	SetJokerType(EJokerCategory::NPC);
	SetMenu(false);
}

void UJokerEntryWidget::SetFriend(const FFriendInfo& InFriendInfo)
{
	FriendInfo = InFriendInfo;

	const FAvatarInfo& AvatarInfo = FriendInfo.Avatar;
	AvatarWidget->SetCharacter(AvatarInfo.CharacterType, AvatarInfo.CharacterIllustType);
	AvatarWidget->SetFrame(AvatarInfo.FrameType);
	AvatarWidget->SetEffect(AvatarInfo.EffectType);

	FriendNameText->SetText(FText::FromString(FriendInfo.Name));
	LevelText->SetText(FText::AsNumber(FriendInfo.Level));
	LastLoginText->SetText(Q6Util::GetHappendTime(FriendInfo.LastLogin));

	const UCMS* CMS = GetCMS();
	const FCMSUserTitleRow& UserTitleRow = CMS->GetUserTitleRowOrDummy(InFriendInfo.TitleId);
	if (UserTitleRow.IsInvalid())
	{
		AkaBorder->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		AkaBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		AkaText->SetText(UserTitleRow.DescName);
	}

	const FAkaAssetRow* AkaAssetRow = GetGameResource().GetAkaAssetRowByPoint(InFriendInfo.TitleScore);
	if (ensure(AkaAssetRow))
	{
		IconBadgeImage->SetBrush(AkaAssetRow->Icon);
	}

	const auto& UIState = GetHUDStore().GetUIStateManager().GetFriendUIState();
	switch (UIState.FriendCategory)
	{
		case EFriendCategory::FriendConnected:
			DeclineButton->SetVisibility(ESlateVisibility::Visible);
			DeclineButtonText->SetText(Q6Util::GetLocalizedText("Common", "Remove"));
			AcceptButton->SetVisibility(ESlateVisibility::Collapsed);
			break;
		case EFriendCategory::FriendReceiving:
			DeclineButton->SetVisibility(ESlateVisibility::Visible);
			DeclineButtonText->SetText(Q6Util::GetLocalizedText("Common", "Decline"));
			AcceptButton->SetVisibility(ESlateVisibility::Visible);
			AcceptButtonText->SetText(Q6Util::GetLocalizedText("Common", "Accept"));
			break;
		case EFriendCategory::FriendSearching:
			DeclineButton->SetVisibility(ESlateVisibility::Collapsed);
			AcceptButton->SetVisibility(ESlateVisibility::Visible);
			AcceptButtonText->SetText(Q6Util::GetLocalizedText("Common", "Request"));
			break;
		default:
			break;
	}

	SetJokerType(UIState.FriendCategory == EFriendCategory::FriendConnected ? EJokerCategory::Friendly : EJokerCategory::User);
	SetMenu(true);
}

void UJokerEntryWidget::SetLocked(bool bIsLocked, const FText& LockedReason)
{
	if (bIsLocked)
	{
		ReasonText->SetText(LockedReason);
		SetJokerSelectType(EJokerSelectType::NPCDisabled);
	}
	else
	{
		SetJokerSelectType(EJokerSelectType::Enabled);
	}
}

void UJokerEntryWidget::SetNewMark(bool bNewly)
{
	CharacterWidget->SetNewMark(bNewly);
	AvatarWidget->SetNewMark(bNewly);
}

void UJokerEntryWidget::SetJokerInfoUi(const FCharacterInfo* CharacterInfo, const FCharacterBond* CharacterBond, const FSculptureInfo* SculptureInfo, const FRelicInfo* RelicInfo, bool bFriendJoker)
{
	CharacterWidget->SetVisibility(ESlateVisibility::Collapsed);
	SculptureIconWidget->SetVisibility(ESlateVisibility::Collapsed);
	RelicIconWidget->SetVisibility(ESlateVisibility::Collapsed);

	if (CharacterInfo)
	{
		if (CharacterBond)
		{
			// Friend joker or recommend joker

			CharacterWidget->SetUserJoker(*CharacterInfo, *CharacterBond, bFriendJoker);
		}
		else
		{
			// System joker or random joker

			CharacterWidget->SetSystemJoker(*CharacterInfo);
		}

		CharacterWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	if (SculptureInfo)
	{
		SculptureIconWidget->SetSculpture(*SculptureInfo);
		SculptureIconWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	if (RelicInfo)
	{
		RelicIconWidget->SetRelic(*RelicInfo);
		RelicIconWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void UJokerEntryWidget::SetJokerInfo(const FCMSCharacterRow* JokerCharacterRow, int32 InJokerLevel)
{
	JokerInfo.CharacterId = FCharacterId::InvalidValue();
	JokerInfo.Type = JokerCharacterRow->CmsType(); // Unit Type == Character Type at Joker.
	JokerInfo.Level = FCharacterXpType(InJokerLevel);
	JokerInfo.Grade = JokerCharacterRow->Grade;
	JokerInfo.Star = JokerCharacterRow->StartStar;
	JokerInfo.Used = false;
	JokerInfo.Locked = false;
	JokerInfo.Newly = false;

	JokerInfo.UltimateSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	JokerInfo.TurnSkill1Level = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	JokerInfo.TurnSkill2Level = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	JokerInfo.TurnSkill3Level = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
}

void UJokerEntryWidget::OnSystemJokerSelected()
{
	ACTION_DISPATCH_SystemJoker(JokerInfo);
	OnJokerSelectedDelegate.ExecuteIfBound();
}

void UJokerEntryWidget::OnFriendJokerSelected()
{
	ACTION_DISPATCH_FriendJoker(FriendInfo, EJokerSlotType(JokerSlotIndex));
	OnJokerSelectedDelegate.ExecuteIfBound();
}

void UJokerEntryWidget::OnRandomJokerSelected()
{
	ACTION_DISPATCH_RandomJoker(JokerInfo);
	OnJokerSelectedDelegate.ExecuteIfBound();
}

void UJokerEntryWidget::OnJokerSetButtonClicked()
{
	OnJokerSetButtonDelegate.ExecuteIfBound(FriendInfo);
}

void UJokerEntryWidget::OnFriendDeclineButtonClicked()
{
	OnFriendButtonDelegate.ExecuteIfBound(FriendInfo, false);
}

void UJokerEntryWidget::OnFriendAcceptButtonClicked()
{
	OnFriendButtonDelegate.ExecuteIfBound(FriendInfo, true);
}

UJokerSelectWidget::UJokerSelectWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, JokerSlotIndex((int32)EJokerSlotType::All)
{

}

void UJokerSelectWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("Menu"));
	JokerSetViewWidget = CastChecked<UJokerSetViewWidget>(GetWidgetFromName("JokerSetView"));

	NatureTabWidget = CastChecked<UNatureTabWidget>(GetWidgetFromName("NatureTab"));
	NatureTabWidget->SetSelectedIndex(JokerSlotIndex);
	NatureTabWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UJokerSelectWidget::OnNatureTabChanged);

	JokerListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("JokerList"));
	SortingWidget = CastChecked<USortingWidget>(GetWidgetFromName("Sorting"));

	RefreshButton = CastChecked<UButton>(GetWidgetFromName("Refresh"));
	RefreshButton->OnClicked.AddUniqueDynamic(this, &UJokerSelectWidget::OnRefreshButtonClicked);
}

void UJokerSelectWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Friend);
	SubscribeToStore(EHSType::Party);
	SubscribeToStore(EHSType::Ui);

	bIsClosedPopup = false;

	GetHUDStore().GetFriendManager().ReqFriendCandidates();
}

void UJokerSelectWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByJokerSelect);

	switch (InAction->GetActionType())
	{
		case EHSActionType::JokerSetView:
		case EHSActionType::FriendCandidatesResp:
		case EHSActionType::SortingChange:
			RefreshMenu();
			break;
	}
}

void UJokerSelectWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FJokerSelectUIState* UIState = GetUIState()->CastToJokerSelectUIState();
	check(UIState);

	SagaType = UIState->SagaType;
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	MenuSwitcher->SetActiveWidgetIndex((int32)UIState->FriendMenu);
	if (UIState->FriendMenu == EFriendMenu::MainView)
	{
		JokerListWidget->ClearList();

		bool bIsTrainingCenter = SagaRow.ContentType == EContentType::TrainingCenter;
		SetSubWidgetsEnable(!bIsTrainingCenter);

		if (bIsTrainingCenter)
		{
			const UCMS* CMS = GetCMS();
			FTrainingCenterType TrainingCenterType = CMS->GetTrainingCenterType(SagaType);
			const FCMSTrainingCenterRow& TrainingCenterRow = CMS->GetTrainingCenterRowOrDummy(TrainingCenterType);

			if (TrainingCenterRow.RandomJoker)
			{
				SetRandomJoker(SagaRow);
				return;
			}
		}

		for (auto JokerCatogory : SagaRow.JokerCategorys)
		{
			if (JokerCatogory == EJokerCategory::NPC)
			{
				AddSystemJokers();
			}
			else if (JokerCatogory == EJokerCategory::Friendly)
			{
				AddFriendJokers();
			}
			else if (JokerCatogory == EJokerCategory::User)
			{
				AddRecommendJokers();
			}
		}

		SortingWidget->SetSorting(ESortMenu::JokerSelect, ESortCategory::Friend);
	}
}

bool UJokerSelectWidget::OnBack()
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType != EContentType::Raid)
	{
		return true;
	}

	const FRegularRaidState& RegularRaidState = GetHUDStore().GetRaidManager().GetRegularRaidState();
	if (RegularRaidState.RespReady && !bIsClosedPopup)
	{
		UConfirmPopupWidget* ConfirmPopupWidget = GetCheckedLobbyHUD(this)->OpenConfirmPopup(
			Q6Util::GetLocalizedText("Popup", "RegularRaidExitTitle")
			, Q6Util::GetLocalizedText("Popup", "RegularRaidExit"));
		ConfirmPopupWidget->OnConfirmPopupDelegate.BindUObject(this, &UJokerSelectWidget::OnPopupButtonClicked);
		return false;
	}

	return true;
}

void UJokerSelectWidget::AddSystemJokers()
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	TArray<FText> BanLines;
	BanLines.Reserve(3);
	BanLines.Add(SagaRow.BanLines1);
	BanLines.Add(SagaRow.BanLines2);
	BanLines.Add(SagaRow.BanLines3);

	const TArray<int32>& BanIndices = UQ6GameInstance::Get(this)->GetBanIndices();
	const TArray<const FCMSCharacterRow*>& JokerCharacterRows = SagaRow.GetJoker();
	for (int32 i = 0; i < JokerCharacterRows.Num(); ++i)
	{
		const FCMSCharacterRow* JokerRow = JokerCharacterRows[i];

		UJokerEntryWidget* JokerEntryWidget = CastChecked<UJokerEntryWidget>(JokerListWidget->FindOrAddChild(i));
		JokerEntryWidget->SetSystemJoker(JokerRow, SagaRow.JokerLevel);
		JokerEntryWidget->SetLocked(false);
		JokerEntryWidget->OnJokerSelectedDelegate.BindUObject(this, &UJokerSelectWidget::OnJokerSelected);

		UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(JokerEntryWidget->Slot);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);

		for (int32 Index : BanIndices)
		{
			check(Index < SagaRow.BanUnits.Num());
			check(Index < BanLines.Num());

			if (SagaRow.BanUnits[Index] == JokerRow->Type)
			{
				JokerEntryWidget->SetLocked(true, BanLines[Index]);
			}
		}
	}
}

void UJokerSelectWidget::AddFriendJokers()
{
	const auto& FriendMgr = GetHUDStore().GetFriendManager();

	auto ConnectedFriends = FriendMgr.GetConnectedFriends();
	FSortOrdering::Sort(ESortMenu::JokerSelect, ConnectedFriends, JokerSlotIndex);

	int32 Added = 0;
	for (const FFriendInfo* IterFriendInfo : ConnectedFriends)
	{
		if (Added >= 10)
		{
			break;
		}

		const FDateTime& ExpireDate = Q6Util::UtcTimestampToLocalDateTime(IterFriendInfo->LastLogin)
			+ FTimespan(SystemConst::Q6_FRIEND_JOKER_LAST_LOGIN_DAYS, 0, 0, 0);
		bool bLongTimeNoSee = ExpireDate < FDateTime::Now();
#if !UE_BUILD_SHIPPING
		if (UQ6GameInstance::Get()->IsDevMode())
		{
			bLongTimeNoSee = false;
		}
#endif

		if (bLongTimeNoSee)
		{
			continue;
		}

		int32 CooltimeUtc = FriendMgr.GetCooltime(IterFriendInfo->TargetUserId);
		if (CooltimeUtc > 0)
		{
#if !UE_BUILD_SHIPPING
			int32 DevCooltime = FriendMgr.GetDevCooltime();
			int32 Cooltime = DevCooltime >= 0 ? DevCooltime : SystemConst::Q6_FRIEND_JOKER_COOLTIME;
#else
			int32 Cooltime = SystemConst::Q6_FRIEND_JOKER_COOLTIME;
#endif

			FDateTime ExpireCooltimeDate = Q6Util::UtcTimestampToLocalDateTime(CooltimeUtc) +
				FTimespan(0, 0, Cooltime, 0);
			bool bCooltime = ExpireCooltimeDate > FDateTime::Now();
			if (bCooltime)
			{
				continue;
			}
		}

		UJokerEntryWidget* JokerEntryWidget = CastChecked<UJokerEntryWidget>(JokerListWidget->AddChildAtLastIndex());
		JokerEntryWidget->SetFriendJoker(*IterFriendInfo, JokerSlotIndex, true);
		JokerEntryWidget->OnJokerSetButtonDelegate.BindUObject(this, &UJokerSelectWidget::OnJokerSetButtonClicked);
		JokerEntryWidget->OnJokerSelectedDelegate.BindUObject(this, &UJokerSelectWidget::OnJokerSelected);

		UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(JokerEntryWidget->Slot);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);

		Added = Added + 1;
	}
}

void UJokerSelectWidget::AddRecommendJokers()
{
	const auto& FriendMgr = GetHUDStore().GetFriendManager();

	auto Candidates = FriendMgr.GetCandidates();
	FSortOrdering::Sort(ESortMenu::JokerSelect, Candidates, JokerSlotIndex);

	for (const FFriendInfo* IterFriendInfo : Candidates)
	{
		int32 CooltimeUtc = FriendMgr.GetCooltime(IterFriendInfo->TargetUserId);
		if (CooltimeUtc > 0)
		{
			FDateTime ExpireCooltimeDate = Q6Util::UtcTimestampToLocalDateTime(CooltimeUtc) +
				FTimespan(0, 0, SystemConst::Q6_FRIEND_JOKER_COOLTIME, 0);
			bool bCooltime = ExpireCooltimeDate > FDateTime::Now();
			if (bCooltime)
			{
				continue;
			}
		}

		UJokerEntryWidget* JokerEntryWidget = CastChecked<UJokerEntryWidget>(JokerListWidget->AddChildAtLastIndex());
		JokerEntryWidget->SetFriendJoker(*IterFriendInfo, JokerSlotIndex, false);
		JokerEntryWidget->OnJokerSetButtonDelegate.BindUObject(this, &UJokerSelectWidget::OnJokerSetButtonClicked);
		JokerEntryWidget->OnJokerSelectedDelegate.BindUObject(this, &UJokerSelectWidget::OnJokerSelected);

		UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(JokerEntryWidget->Slot);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);
	}
}

void UJokerSelectWidget::SetRandomJoker(const FCMSSagaRow& SagaRow)
{
	const TArray<const FCMSCharacterRow*> CharacterRows = SagaRow.GetJoker();
	int32 RandomIndex = FMath::RandRange(0, CharacterRows.Num() - 1);

	UJokerEntryWidget* JokerEntryWidget = CastChecked<UJokerEntryWidget>(JokerListWidget->AddChildAtLastIndex());
	JokerEntryWidget->SetRandomJoker(CharacterRows[RandomIndex], SagaRow.JokerLevel);
	JokerEntryWidget->OnJokerSetButtonDelegate.BindUObject(this, &UJokerSelectWidget::OnJokerSetButtonClicked);
	JokerEntryWidget->OnJokerSelectedDelegate.BindUObject(this, &UJokerSelectWidget::OnJokerSelected);

	UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(JokerEntryWidget->Slot);
	GridSlot->SetHorizontalAlignment(HAlign_Fill);
}

void UJokerSelectWidget::SetSubWidgetsEnable(bool bInIsEnabled)
{
	NatureTabWidget->SetIsEnabled(bInIsEnabled);
	RefreshButton->SetVisibility(bInIsEnabled ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	SortingWidget->SetVisibility(bInIsEnabled ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}

void UJokerSelectWidget::OnNatureTabChanged(int32 NewIndex)
{
	if (NewIndex != JokerSlotIndex)
	{
		JokerSlotIndex = NewIndex;
		RefreshMenu();
	}
}

void UJokerSelectWidget::OnJokerSetButtonClicked(const FFriendInfo& InFriendInfo)
{
	ACTION_DISPATCH_JokerSetView();

	JokerSetViewWidget->SetFriendInfo(InFriendInfo);
	FriendInfo = InFriendInfo;

	auto PartyIconWidgets = JokerSetViewWidget->GetJokerSetWidget()->GetPartyIconWidgets();
	for (auto i = 0; i < FriendInfo.JokerSet.Slots.Num(); ++i)
	{
		UPartyIconWidget* PartyIconWidget = PartyIconWidgets[i];
		const FFriendJokerSlot& JokerSlot = FriendInfo.JokerSet.Slots[i];
		if (!JokerSlot.CharacterInfo.CharacterId.IsInvalid())
		{
			PartyIconWidget->OnPartyIconSelectedDelegate.BindUObject(this, &UJokerSelectWidget::OnFriendJokerSelected, i);
		}
		else
		{
			PartyIconWidget->OnPartyIconSelectedDelegate.Unbind();
		}
	}
}

void UJokerSelectWidget::OnFriendJokerSelected(UPartyEquipIconWidget* EquipIconWidget, int SlotIdx)
{
	ACTION_DISPATCH_FriendJokerFromPopup(FriendInfo, EJokerSlotType(SlotIdx));

	OnJokerSelected();
}

void UJokerSelectWidget::OnRefreshButtonClicked()
{
	const auto& FriendMgr = GetHUDStore().GetFriendManager();
	FriendMgr.ReqFriendCandidates();
}

void UJokerSelectWidget::OnPopupButtonClicked(EConfirmPopupFlag Flag)
{
	if (Flag == EConfirmPopupFlag::Yes)
	{
		bIsClosedPopup = true;
		GetLobbyHUD(this)->GotoBack();
	}
}

void UJokerSelectWidget::OnJokerSelected()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("JokerSelected");
	GetCheckedLobbyHUD(this)->ChangeHUDType(EHUDWidgetType::Party);
	ACTION_DISPATCH_PartyMain(SagaType);
}
