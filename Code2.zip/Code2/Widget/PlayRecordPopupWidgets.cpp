#include "PlayRecordPopupWidgets.h"

#include "CommonWidgets.h"
#include "Q6.h"
#include "CMSTable.h"
#include "UserRecordManager.h"

UPlayRecordListWidget::UPlayRecordListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UPlayRecordListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RecordTitleTextBlock = CastChecked<UQ6TextBlock>(GetWidgetFromName("RecordTitle"));
	RecordValueRichTextBlock = CastChecked<URichTextBlock>(GetWidgetFromName("Record"));
}

void UPlayRecordListWidget::SetPlayRecordListInfo(const int32 Value
	, const FCMSUserRecordRow& RecordRow)
{
	SetRecordTitleTextBlock(RecordRow.DescName);

	FText DescText;
	switch (RecordRow.DescType)
	{
		case EUserRecordDescType::None:
		{
			DescText = FText::AsNumber(Value);
		}
		break;
		case EUserRecordDescType::Date:
		{
			FDateTime DateTime = FDateTime::FromUnixTimestamp(Value);

			FNumberFormattingOptions FormattingOption = FNumberFormattingOptions{};
			FormattingOption.SetUseGrouping(false);

			DescText = FText::Format(
				Q6Util::GetLocalizedText("Popup", "PlayRecordPopupDate")
				, FText::AsNumber(DateTime.GetYear(), &FormattingOption)
				, Q6Util::AttachZeroToFront(DateTime.GetMonth())
				, Q6Util::AttachZeroToFront(DateTime.GetDay()));
		}
		break;
		case EUserRecordDescType::EpisodeAndStage:
		{
			const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(FSagaType(Value));
			if (SagaRow.IsInvalid())
			{
				break;
			}

			FText StageText;
			if (SagaRow.SubStage == 0)
			{
				StageText = FText::AsNumber(SagaRow.Stage);
			}
			else
			{
				StageText = FText::Format(FTextFormat::FromString("{0}-{1}")
					, FText::AsNumber(SagaRow.Stage)
					, FText::AsNumber(SagaRow.SubStage));
			}

			DescText = FText::Format(
				Q6Util::GetLocalizedText("Common", ENUM_TO_STRING(EUserRecordDescType, RecordRow.DescType))
				, FText::AsNumber(SagaRow.Episode)
				, StageText);
		}
		break;
		default:
		{
			int32 RecordValue(Value);
			if (RecordRow.Limit != 0)
			{
				RecordValue = FMath::Clamp(Value, 0, RecordRow.Limit);
			}

			DescText = FText::Format(
				Q6Util::GetLocalizedText("Common", ENUM_TO_STRING(EUserRecordDescType, RecordRow.DescType))
				, FText::AsNumber(RecordValue));
		}
	}

	if (RecordRow.DescIcon == EUserRecordDescIcon::None)
	{
		SetRecordTextBlock(DescText);
	}
	else
	{
		FText IconTagText = FText::Format(Q6Util::GetLocalizedText("Common", "Icon")
			, FText::FromString(ENUM_TO_STRING(EUserRecordDescIcon, RecordRow.DescIcon)));

		SetRecordTextBlock(FText::Format(FTextFormat::FromString("{0} {1}"), IconTagText, DescText));
	}
}

void UPlayRecordListWidget::SetRecordTitleTextBlock(const FText& InText)
{
	RecordTitleTextBlock->SetText(InText);
}

void UPlayRecordListWidget::SetRecordTextBlock(const FText& InText)
{
	RecordValueRichTextBlock->SetText(InText);
}

UPlayRecordPopupWidget::UPlayRecordPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, RecordCategory(EUserRecordCategory::Normal)
{

}

void UPlayRecordPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();
	
	RecordToggleButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("RecordToggle"));
	RecordToggleButton->OnToggleButtonClickedDelegate.BindUObject(this
		, &UPlayRecordPopupWidget::OnRecordToggleChanged);

	RecordListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("RecordList"));

	SubscribeToStore(EHSType::UserRecord);
}

void UPlayRecordPopupWidget::InitPlayRecordPopup()
{
	RecordCategory = EUserRecordCategory::Normal;
	RecordToggleButton->SetSelectedIndex(static_cast<int32>(RecordCategory));

	SetTitle(Q6Util::GetLocalizedText("Popup", "PlayRecordPopupTitle"));
}

void UPlayRecordPopupWidget::OnRecordToggleChanged(int32 Index)
{
	RecordCategory = static_cast<EUserRecordCategory>(Index);
	SetRecordList(RecordCategory);
}

void UPlayRecordPopupWidget::SetRecordList(const EUserRecordCategory InCategory)
{
	RecordListWidget->ClearList();

	const UUserRecordManager& UserRecordManager = GetHUDStore().GetUserRecordManager();
	const TMap<FUserRecordType, FUserRecordInfo>& Records = UserRecordManager.GetRecords();
	const TMap<FUserRecordType, const FCMSUserRecordRow*>& RecordRows = UserRecordManager.GetRecordRows();

	for (const TPair<FUserRecordType, const FCMSUserRecordRow*>& RecordRow : RecordRows)
	{
		if (!RecordRow.Value)
		{
			continue;
		}

		if (RecordRow.Value->Category != InCategory)
		{
			continue;
		}

		UPlayRecordListWidget* PlayRecordListWidget = CastChecked<UPlayRecordListWidget>(
			RecordListWidget->AddChildAtLastIndex());

		const FUserRecordInfo* RecordInfo = Records.Find(RecordRow.Value->CmsType());
		if (RecordInfo)
		{
			PlayRecordListWidget->SetPlayRecordListInfo(RecordInfo->Val, *RecordRow.Value);
		}
		else
		{
			PlayRecordListWidget->SetPlayRecordListInfo(0, *RecordRow.Value);
		}
	}
}
