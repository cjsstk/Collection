// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "SwipeWidgets.h"

#include "Components/DynamicEntryBox.h"
#include "Widgets/Layout/SSCrollBox.h"
#include "Utils/WidgetUtil.h"

UPageIndicatorIconWidget::UPageIndicatorIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPageIndicatorIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EnabledImage = CastChecked<UImage>(GetWidgetFromName("On"));
}

void UPageIndicatorIconWidget::SetFocused(bool bIsFocused)
{
	EnabledImage->SetVisibility(bIsFocused ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

FReply SSwipeScrollBox::OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	return FReply::Unhandled();
}

bool USwipeScrollBox::IsScrolling() const
{
	if (MyScrollBox.IsValid())
	{
		return MyScrollBox->IsScrolling();
	}

	return false;
}

TSharedRef<SWidget> USwipeScrollBox::RebuildWidget()
{
	MyScrollBox = SNew(SSwipeScrollBox)
		.Style(&WidgetStyle)
		.ScrollBarStyle(&WidgetBarStyle)
		.Orientation(Orientation)
		.ConsumeMouseWheel(ConsumeMouseWheel)
		.NavigationDestination(NavigationDestination)
		.NavigationScrollPadding(NavigationScrollPadding)
		.NavigationDestination(NavigationDestination)
		.OnUserScrolled(BIND_UOBJECT_DELEGATE(FOnUserScrolled, SlateHandleUserScrolled));

	for (UPanelSlot* PanelSlot : Slots)
	{
		if (UScrollBoxSlot* TypedSlot = Cast<UScrollBoxSlot>(PanelSlot))
		{
			TypedSlot->Parent = this;
			TypedSlot->BuildSlot(MyScrollBox.ToSharedRef());
		}
	}

	return 	MyScrollBox.ToSharedRef();
}

UBasePageSwipeWidget::UBasePageSwipeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bIndicatorVisible(true)
	, ChildSlotPadding(FMargin(70.f, 0.f, 70.f, 0.f))
	, PageCount(0)
	, SwipingDirection(EDirection::None)
	, FocusedSlot(INDEX_NONE)
	, SwipeDetectDistance(100.f)
	, SwipeDetectSpeed(1.f)
	, bTouched(false)
	, bSwipeEnabled(true)
{
}

void UBasePageSwipeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FocusingPage = 1;
	FocusedSlot = 1;
	ViewPageCount = 0;

	IndicatorSlot = CastChecked<UNamedSlot>(GetWidgetFromName("SlotIndicator"));
	IndicatorBox = Cast<UDynamicEntryBox>(GetWidgetFromName("DefaultIndicator"));
	if (!IndicatorBox)
	{
		IndicatorBox = CastChecked<UDynamicEntryBox>(FindChildWidgetFromName("Indicator"));
	}

	PageScrollBox = CastChecked<USwipeScrollBox>(GetWidgetFromName("PageScroll"));
	PageGridPanel = CastChecked<UUniformGridPanel>(GetWidgetFromName("PageGrid"));

	NextButton = CastChecked<UButton>(GetWidgetFromName("Next"));
	NextButton->OnClicked.AddUniqueDynamic(this, &UBasePageSwipeWidget::OnNextButtonClicked);
	PrevButton = CastChecked<UButton>(GetWidgetFromName("Prev"));
	PrevButton->OnClicked.AddUniqueDynamic(this, &UBasePageSwipeWidget::OnPrevButtonClicked);

	SetIndicatorVisible(bIndicatorVisible);
	SetChildSlotPadding(ChildSlotPadding);
}

void UBasePageSwipeWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (SwipingDirection != EDirection::None)
	{
		if (!PageScrollBox->IsScrolling())
		{
			OnSwipeFinished();
			SwipingDirection = EDirection::None;
		}
	}

	SwipeInertial.UpdateScrollVelocity(InDeltaTime);
}

void UBasePageSwipeWidget::InitPages(int32 InFocusingPage)
{
	SwipingDirection = EDirection::None;
	FocusingPage = InFocusingPage;

	SetViewPageCount(PageCount);

	IndicatorBox->Reset(true);
	for (uint32 i = 0; i < PageCount; ++i)
	{
		IndicatorBox->CreateEntry();
	}
}

void UBasePageSwipeWidget::SetFocusPage(int32 InFocusingPage, bool AnimateScroll)
{
	check(InFocusingPage > 0);

	int32 OldPage = FocusingPage;
	FocusingPage = InFocusingPage;

	const TArray<UUserWidget*>& PageIndicators = IndicatorBox->GetAllEntries();
	for (int32 i = 0; i < PageIndicators.Num(); ++i)
	{
		UPageIndicatorIconWidget* PageIndicatorWidget = CastChecked<UPageIndicatorIconWidget>(PageIndicators[i]);
		PageIndicatorWidget->SetFocused(i + 1 == FocusingPage);
	}

	FocusedSlot = GetFocusedSlot(SwipingDirection);
	if (ViewWidgets.IsValidIndex(FocusedSlot))
	{
		PageScrollBox->ScrollWidgetIntoView(ViewWidgets[FocusedSlot], AnimateScroll, EDescendantScrollDestination::Center);
	}

	OnFocusedPageDelegate.ExecuteIfBound(FocusingPage);
}

void UBasePageSwipeWidget::SetIndicatorVisible(bool bInVisible)
{
	bIndicatorVisible = bInVisible;

	IndicatorBox->SetVisibility(bIndicatorVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UBasePageSwipeWidget::SetChildSlotPadding(const FMargin& InPadding)
{
	ChildSlotPadding = InPadding;

	PageGridPanel->SetSlotPadding(ChildSlotPadding);
}

void UBasePageSwipeWidget::OnSwipe(EDirection Direction)
{
	if (SwipingDirection != EDirection::None)
	{
		// While scrolling, skip swipe input
		return;
	}

	SwipingDirection = Direction;

	if (Direction == EDirection::Right)
	{
		ChangeFocusPage(true);
	}
	else if (Direction == EDirection::Left)
	{
		ChangeFocusPage(false);
	}
	else
	{
		// Return to focused page center view
		FocusedSlot = GetFocusedSlot(Direction);
		if (ViewWidgets.IsValidIndex(FocusedSlot))
		{
			PageScrollBox->ScrollWidgetIntoView(ViewWidgets[FocusedSlot], true, EDescendantScrollDestination::Center);
		}
	}
}

void UBasePageSwipeWidget::SetViewPageCount(uint32 InPageCount)
{
	ViewPageCount = InPageCount <= 1 ? InPageCount : 3;
	ViewWidgets.SetNum(ViewPageCount);

	SetSwipeEnabled(PageCount > 1);
}

void UBasePageSwipeWidget::ChangeFocusPage(bool bIncreaseDirection)
{
	int32 NextPageNum = IncFocusPage(bIncreaseDirection);
	SetFocusPage(NextPageNum);
}

int32 UBasePageSwipeWidget::IncFocusPage(bool bIncreaseDirection)
{
	int32 NextValue = bIncreaseDirection ? FocusingPage + 1 : FocusingPage - 1;

	if (NextValue == 0)
	{
		return PageCount;
	}
	else if (NextValue > static_cast<int32>(PageCount))
	{
		return NextValue - PageCount;
	}
	else
	{
		return NextValue;
	}
}

bool UBasePageSwipeWidget::SwipeEnded()
{
	if (bTouched)
	{
		bTouched = false;

		float NewScrollOffset = PageScrollBox->GetScrollOffset();
		float ScrollDelta = (NewScrollOffset - StartedPosX);
		float CurrentVelocity = SwipeInertial.GetScrollVelocity();

		if ((FMath::Abs(ScrollDelta) > SwipeDetectDistance)
			|| (FMath::Abs(CurrentVelocity) > SwipeDetectSpeed))
		{
			OnSwipe(ScrollDelta > 0.f ? EDirection::Right : EDirection::Left);
			return true;
		}

		// For return to center focusing
		OnSwipe(EDirection::None);
		return true;
	}

	return false;
}

FReply UBasePageSwipeWidget::SwipeMoved(const FPointerEvent& InGestureEvent)
{
	float DeltaScrollOffset = InGestureEvent.GetScreenSpacePosition().X - InGestureEvent.GetLastScreenSpacePosition().X;
	SwipeInertial.AddScrollSample(DeltaScrollOffset * SwipeDetectSpeed * 0.005f, GetWorld()->GetRealTimeSeconds());

	if (!bTouched)
	{
		return FReply::Unhandled();
	}

	float OldScrollOffset = PageScrollBox->GetScrollOffset();
	PageScrollBox->SetScrollOffset(OldScrollOffset - DeltaScrollOffset);

	return FReply::Handled();
}

void UBasePageSwipeWidget::SetOrderedPageList(const TArray<int32>& InOrderedPageList)
{
	int InCurrentPageCount = OrderedPageList.Num();

	OrderedPageList.Reset();
	OrderedPageList.Reserve(InCurrentPageCount);

	if (InCurrentPageCount == 1)
	{
		OrderedPageList.Add(InOrderedPageList[0]);
	}
	else
	{
		for (int i = 0; i < InOrderedPageList.Num(); ++i)
		{
			OrderedPageList.Insert(InOrderedPageList[i], i);
		}
	}
}

bool UBasePageSwipeWidget::GetPageListFromOrderedList(uint32 FocusedPage, TArray<uint32>& SlotList)
{
	if (OrderedPageList.Num() == 0)
	{
		return false;
	}

	if (PageCount == 1)
	{
		SlotList.Add(OrderedPageList[0]);
		return true;
	}
	else
	{
		check(FocusedPage > 0);
		uint32 ZeroBasedFocusedPage = FocusedPage - 1;
		SlotList.Add(ZeroBasedFocusedPage > 0 ? OrderedPageList[ZeroBasedFocusedPage - 1] : OrderedPageList[PageCount - 1]);
		SlotList.Add(OrderedPageList[ZeroBasedFocusedPage]);
		SlotList.Add(ZeroBasedFocusedPage + 1 < PageCount ? OrderedPageList[ZeroBasedFocusedPage + 1] : OrderedPageList[0]);
	}

	return true;
}

void UBasePageSwipeWidget::GetPageList(uint32 FocusedPage, TArray<uint32>& SlotList)
{
	SlotList.Empty();
	SlotList.Reserve(ViewPageCount);

	if (GetPageListFromOrderedList(FocusedPage, SlotList))
	{
		return;
	}

	if (PageCount == 1)
	{
		SlotList.Add(1);
	}
	else
	{
		// FocusedPage start from 1 whereas internal slot index start from 0
		SlotList.Add(FocusedPage > 1 ? FocusedPage - 1 : PageCount);
		SlotList.Add(FocusedPage);
		SlotList.Add(FocusedPage + 1 <= PageCount ? FocusedPage + 1 : 1);
	}
}

uint32 UBasePageSwipeWidget::GetFocusedSlot(EDirection Direction)
{
	if (ViewPageCount == 1)
	{
		return 0;
	}

	if (Direction == EDirection::Right)
	{
		return 2;
	}
	else if (Direction == EDirection::Left)
	{
		return 0;
	}
	else
	{
		return 1;
	}
}

UWidget* UBasePageSwipeWidget::GetFocusedWidget()
{
	if (ViewWidgets.IsValidIndex(FocusedSlot))
	{
		return ViewWidgets[FocusedSlot];
	}

	return nullptr;
}

void UBasePageSwipeWidget::OnNextButtonClicked()
{
	OnSwipe(EDirection::Right);
}

void UBasePageSwipeWidget::OnPrevButtonClicked()
{
	OnSwipe(EDirection::Left);
}

void UBasePageSwipeWidget::SetSwipeEnabled(bool bInEnabled)
{
	bSwipeEnabled = bInEnabled;

	NextButton->SetVisibility(bInEnabled ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	PrevButton->SetVisibility(bInEnabled ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}

void UBasePageSwipeWidget::OnSwipeFinished()
{
	SwipingDirection = EDirection::None;
}

FReply UBasePageSwipeWidget::NativeOnMouseMove(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	return SwipeMoved(InGestureEvent);
}

FReply UBasePageSwipeWidget::NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	return SwipeMoved(InGestureEvent);
}

FReply UBasePageSwipeWidget::NativeOnMouseButtonUp(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	SwipeEnded();

	return FReply::Unhandled();
}

FReply UBasePageSwipeWidget::NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	SwipeEnded();

	return FReply::Unhandled();
}

void UBasePageSwipeWidget::NativeOnMouseLeave(const FPointerEvent& InMouseEvent)
{
	SwipeEnded();
}

FReply UBasePageSwipeWidget::NativeOnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	if (!bSwipeEnabled)
	{
		return FReply::Unhandled();
	}

	if (SwipingDirection != EDirection::None)
	{
		return FReply::Unhandled();
	}

	bTouched = true;
	StartedPosX = PageScrollBox->GetScrollOffset();

	SwipeInertial.ClearScrollVelocity();

	return FReply::Unhandled();
}

UPageSwipeWidget::UPageSwipeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPageSwipeWidget::InitPages(int32 InFocusingPage)
{
	Super::InitPages(InFocusingPage);

	ViewWidgets.SetNum(ViewPageCount);
	PageGridPanel->ClearChildren();
	for (uint32 i = 0; i < ViewPageCount; ++i)
	{
		UWidget* PageWidget = nullptr;
		if (ViewWidgets[i])
		{
			PageWidget = ViewWidgets[i];
		}
		else
		{
			PageWidget = NewObject<UWidget>(this, PageWidgetClass.LoadSynchronous());
			check(PageWidget);

			ViewWidgets[i] = PageWidget;
		}

		UUniformGridSlot* GridSlot = PageGridPanel->AddChildToUniformGrid(PageWidget);
		check(GridSlot);

		GridSlot->SetColumn(i);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);
		GridSlot->SetVerticalAlignment(VAlign_Fill);
	}

	TArray<uint32> NextPageList;
	GetPageList(FocusingPage, NextPageList);
	for (int32 i = 0; i < (int32)ViewPageCount; ++i)
	{
		OnSetPageDelegate.ExecuteIfBound(ViewWidgets[i], NextPageList[i]);
	}

	SetFocusPage(FocusingPage, false);
}

void UPageSwipeWidget::SetPageCount(uint32 InPageCount, int32 InFocusingPage)
{
	PageCount = InPageCount;

	InitPages(InFocusingPage);
}

void UPageSwipeWidget::SetPageCount(const TArray<int32>& InOrderedPageList, int32 InFocusingPage)
{
	PageCount = InOrderedPageList.Num();

	SetOrderedPageList(InOrderedPageList);
	InitPages(InFocusingPage);
}

void UPageSwipeWidget::ArrangeViewWidgets()
{
	if ((SwipingDirection == EDirection::None) || (ViewPageCount == 1))
	{
		return;
	}

	TArray<uint32> NextPageList;
	GetPageList(FocusingPage, NextPageList);

	if (SwipingDirection == EDirection::Right)
	{
		// First page move to last page

		UWidget* ViewWidget = ViewWidgets[0];
		ViewWidgets.RemoveAt(0, 1, false);
		ViewWidgets.Add(ViewWidget);

		OnSetPageDelegate.ExecuteIfBound(ViewWidget, NextPageList.Last());
	}
	else
	{
		// Last page move to first page

		UWidget* ViewWidget = ViewWidgets.Pop(false);
		ViewWidgets.Insert(ViewWidget, 0);

		OnSetPageDelegate.ExecuteIfBound(ViewWidget, NextPageList[0]);
	}

	for (int32 i = 0; i < (int32)ViewPageCount; ++i)
	{
		UUniformGridSlot* ViewWidgetSlot = Cast<UUniformGridSlot>(ViewWidgets[i]->Slot);
		ViewWidgetSlot->SetColumn(i);
	}

	FocusedSlot = GetFocusedSlot(EDirection::None);
	PageScrollBox->ScrollWidgetIntoView(ViewWidgets[FocusedSlot], false, EDescendantScrollDestination::Center);
}

void UPageSwipeWidget::OnSwipeFinished()
{
	ArrangeViewWidgets();

	Super::OnSwipeFinished();
}

UVarietyPageSwipeWidget::UVarietyPageSwipeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UVarietyPageSwipeWidget::InitPages(int32 InFocusingPage)
{
	PageCount = PageWidgetClasses.Num();

	Super::InitPages(InFocusingPage);

	TArray<uint32> NextPageList;
	GetPageList(FocusingPage, NextPageList);

	PageGridPanel->ClearChildren();
	for (uint32 i = 0; i < ViewPageCount; ++i)
	{
		UWidget* ViewWidget = FindOrAddPageWidget(PageWidgetClasses[NextPageList[i] - 1]);
		ViewWidgets[i] = ViewWidget;

		UUniformGridSlot* GridSlot = PageGridPanel->AddChildToUniformGrid(ViewWidget);
		check(GridSlot);

		GridSlot->SetColumn(i);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);
		GridSlot->SetVerticalAlignment(VAlign_Fill);
	}

	for (int32 i = 0; i < (int32)ViewPageCount; ++i)
	{
		OnSetPageDelegate.ExecuteIfBound(ViewWidgets[i], NextPageList[i]);
	}

	SetFocusPage(FocusingPage, false);
}

UWidget* UPageSwipeWidget::GetPage(int32 PageNumber)
{
	if (PageCount == 1)
	{
		check(PageNumber == 1);
		return ViewWidgets[0];
	}
	else
	{
		TArray<uint32> CurPageList;
		GetPageList(FocusingPage, CurPageList);

		int32 PageIndex = CurPageList.Find(PageNumber);
		if (!ensure(PageIndex != INDEX_NONE))
		{
			return nullptr;
		}

		return ViewWidgets[PageIndex];
	}
}

void UVarietyPageSwipeWidget::ArrangeViewWidgets()
{
	if ((SwipingDirection == EDirection::None) || (ViewPageCount == 1))
	{
		return;
	}

	TArray<uint32> NextPageList;
	GetPageList(FocusingPage, NextPageList);

	check(ViewWidgets.Num() > 0);
	if (SwipingDirection == EDirection::Right)
	{
		// Remove old first page
		UWidget* OldFirstWidget = ViewWidgets[0];
		ViewWidgets.RemoveAt(0, 1, false);
		OldFirstWidget->RemoveFromParent();

		// Add new last page
		UWidget* NewLastWidget = FindOrAddPageWidget(PageWidgetClasses[NextPageList.Last() - 1]);
		ViewWidgets.Add(NewLastWidget);
		PageGridPanel->AddChildToUniformGrid(NewLastWidget);

		OnSetPageDelegate.ExecuteIfBound(NewLastWidget, NextPageList.Last());
	}
	else
	{
		// Remove old last page
		UWidget* OldLastWidget = ViewWidgets.Pop(false);
		OldLastWidget->RemoveFromParent();

		// Add new first page
		UWidget* NewFirstWidget = FindOrAddPageWidget(PageWidgetClasses[NextPageList[0] - 1]);
		ViewWidgets.Insert(NewFirstWidget, 0);
		PageGridPanel->AddChildToUniformGrid(NewFirstWidget);

		OnSetPageDelegate.ExecuteIfBound(NewFirstWidget, NextPageList[0]);
	}

	// Replace widget slots
	for (uint32 i = 0; i < ViewPageCount; ++i)
	{
		UWidget* ViewWidget = ViewWidgets[i];

		UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(ViewWidget->Slot);
		check(GridSlot);

		GridSlot->SetColumn(i);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);
		GridSlot->SetVerticalAlignment(VAlign_Fill);
	}

	FocusedSlot = GetFocusedSlot(EDirection::None);
	if (ViewWidgets.IsValidIndex(FocusedSlot))
	{
		PageScrollBox->ScrollWidgetIntoView(ViewWidgets[FocusedSlot], false, EDescendantScrollDestination::Center);
	}
}

void UVarietyPageSwipeWidget::OnSwipeFinished()
{
	ArrangeViewWidgets();

	Super::OnSwipeFinished();
}

UWidget* UVarietyPageSwipeWidget::FindOrAddPageWidget(TAssetSubclassOf<UWidget> PageWidgetClass)
{
	UWidget* FoundPageWidget = nullptr;
	for (UWidget* PageWidget : PageWidgets)
	{
		if (PageWidgetClass.IsNull())
		{
			continue;
		}

		if (!PageWidgetClass.Get())
		{
			PageWidgetClass.LoadSynchronous();
		}

		if (PageWidget->GetClass() != PageWidgetClass.Get())
		{
			continue;
		}

		if (!PageWidget->Slot)
		{
			// Not used widget
			FoundPageWidget = PageWidget;
		}
	}

	if (!FoundPageWidget)
	{
		// Not found usable page widget

		if (!PageWidgetClass.Get())
		{
			PageWidgetClass.LoadSynchronous();
		}

		// Create new page widget

		FoundPageWidget = NewObject<UWidget>(this, PageWidgetClass.Get());
		PageWidgets.Add(FoundPageWidget);
	}

	return FoundPageWidget;
}

UWidget* UVarietyPageSwipeWidget::GetPage(int32 PageNumber)
{
	TArray<uint32> PageList;
	GetPageList(FocusingPage, PageList);

	for (int32 i = 0; i < (int32)ViewPageCount; ++i)
	{
		if ((int32)PageList[i] == PageNumber)
		{
			return ViewWidgets[i];
		}
	}

	return nullptr;
}

void UVarietyPageSwipeWidget::SetPageWidgetClasses(const TArray<TAssetSubclassOf<UWidget>>& WidgetClasses, int32 InFocusingPage)
{
	PageWidgetClasses = WidgetClasses;

	InitPages(InFocusingPage);
}
