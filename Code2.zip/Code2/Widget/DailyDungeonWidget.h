#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "StageWidgets.h"
#include "DailyDungeonWidget.generated.h"

class UQ6Button;
class UQ6TextBlock;
class UPageSwipeWidget;

UCLASS()
class UDailyDungeonMenuWidget : public UUserWidget
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;

	FSimpleDelegate OnMenuClickedDelegate;

	void SetDailyDungeonMenu(EDailyDungeonCategory InDungeonCategory, EDayOfWeekType InCurrentShowDay, int32 Stage);

public:
	UFUNCTION(BlueprintImplementableEvent)
	void SetDailyDungeonInfoText(EDailyDungeonCategory InDungeonCategory);

private:
	void SetNewMark(bool bInVisible);

	UFUNCTION()
	void OnMenuButtonClicked();

	UPROPERTY()
	UImage* RewardImage;

	UPROPERTY()
	UQ6Button* MenuButton;

	UPROPERTY()
	UImage* NewMarkImage;
};

UCLASS()
class UDailyDungeonInfoWidget : public UUserWidget
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;
	void SetInfo(EDayOfWeekType InDayType);

private:
	UPROPERTY()
	UImage* DailyCharacterImage;

	UPROPERTY()
	UQ6TextBlock* ExplanationText;

	UPROPERTY()
	UTextBlock* SpeakerText;
};

UCLASS()
class UDailyDungeonPageWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetDefaultPage(EDayOfWeekType InDayOfWeekType);
	void SetRewardPage(EDailyDungeonCategory InDungeonCategory, EDayOfWeekType InCurrentShowDay);

private:
	UFUNCTION()
	void SetPage(EDayOfWeekType InDayOfWeekType);

	UFUNCTION()
	void SetInitialReward(EDayOfWeekType InDayOfWeekType);

	UPROPERTY()
	UWidgetAnimation* DailyDungeonRewardAnim;

	UPROPERTY()
	UWidgetAnimation* DailyDungeonSetPageAnim;

	UPROPERTY()
	UWidgetAnimation* DailyDungeonLockAnim;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> XpBGTexture;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> GoldBGTexture;

	UPROPERTY()
	UImage* DailyImage;

	UPROPERTY()
	UQ6TextBlock* DayText;

	UPROPERTY()
	UQ6TextBlock* DayDescText;

	UPROPERTY()
	UImage* DailyCharacterImage;

	UPROPERTY()
	UImage* RewardImage;

	UPROPERTY()
	UItemWidget* InitialRewardWidget;
};

UCLASS()
class UDailyDungeonWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::DailyDungeon; }

private:

	bool IsPlayed(int32 StageList, int32 Stage);
	bool IsLockedStage(int32 StageList, int32 Stage);
	EStageState GetStageState(
		EDailyDungeonCategory InDungeonCategory, 
		const FDailyDungeonRecord& InDailyDungeonList, 
		const FCMSDailyDungeonRow* InDungeonRow
	);

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	UFUNCTION()
	void OnDailyDungeonMenuClicked(EDailyDungeonCategory InDungeonCategory);

	UFUNCTION()
	void SetDailyDungeonMenu();

	UFUNCTION()
	void SetDailyDungeonInfo();

	UFUNCTION()
	void SetDailyDungeonStage(EDailyDungeonCategory InDungeonCategory);

	UFUNCTION()
	void OnDailyPageChanged(int32 NewPage);

	UFUNCTION()
	void OnSetDailyDungeonPage(UWidget* ViewWidget, int32 PageNum);

	UPROPERTY()
	UPageSwipeWidget* SwipeWidget;

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	UDailyDungeonMenuWidget* PromoteMenuWidget;

	UPROPERTY()
	UDailyDungeonMenuWidget* XpMenuWidget;

	UPROPERTY()
	UDailyDungeonMenuWidget* GoldMenuWidget;

	UPROPERTY()
	UDailyDungeonInfoWidget* InfoWidget;

	UPROPERTY()
	UDynamicListWidget* StageListWidget;

	UPROPERTY()
	EDayOfWeekType CurrentShowDay;
};