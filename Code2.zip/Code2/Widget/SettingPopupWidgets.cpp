#include "SettingPopupWidgets.h"
#include "CommonWidgets.h"
#include "Q6GameInstance.h"

USettingPopupWidget::USettingPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bOnReload(false)
{
}

void USettingPopupWidget::OnCategoryChanged(int32 ChangedIndex)
{
	SettingMenu = (ESettingMenu)ChangedIndex;
	WidgetSwitcher->SetActiveWidgetIndex(ChangedIndex);
}

void USettingPopupWidget::OnResetClicked()
{
	if (SettingMenu == ESettingMenu::QualityView)
	{
		GameSettingData = FGameSettingData();
		ReloadQualityView();
	}
	else // ESettingMenu::NoticeView
	{
		GameNoticeData = FGameNoticeData();
		ReloadNoticeView();
	}

	ApplySetting();
}

void USettingPopupWidget::OnSubmitClicked()
{
	if (ALobbyHUD* LobbyHUD = GetLobbyHUD(this))
	{
		LobbyHUD->RefreshNaviBar();
	}

	SaveSetting();
	ClosePopup();
}

void USettingPopupWidget::SaveSetting()
{
	if (UQ6GameUserSettings* UserSettings = UQ6GameUserSettings::Get())
	{
		if (UserSettings->GetGameSettingData().ShowUltimate != GameSettingData.ShowUltimate)
		{
			UQ6GameInstance::Get()->ClearShowUltimateSequenceDates();
		}

		UserSettings->SetGameData(GameSettingData, GameNoticeData);
	}
}

void USettingPopupWidget::ApplySetting()
{
	if (bOnReload)
	{
		return;
	}

	if (UQ6GameUserSettings* UserSettings = UQ6GameUserSettings::Get())
	{
		UserSettings->ApplyGameData(GameSettingData, GameNoticeData);
	}
}

void USettingPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CategoryButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CategoryOptions"));

	SettingMenu = ESettingMenu::QualityView;
	CategoryButton->SetSelectedIndex((int32)SettingMenu);
	CategoryButton->OnToggleButtonClickedDelegate.BindUObject(this, &USettingPopupWidget::OnCategoryChanged);

	WidgetSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("OptionSwitcher"));

	SubmitButton = CastChecked<UButton>(GetWidgetFromName("Submit"));
	SubmitButton->OnClicked.AddUniqueDynamic(this, &USettingPopupWidget::OnSubmitClicked);

	ResetButton = CastChecked<UButton>(GetWidgetFromName("Reset"));
	ResetButton->OnClicked.AddUniqueDynamic(this, &USettingPopupWidget::OnResetClicked);

	// Setting View
	GraphicQualityButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("GraphicQuality"));
	AntiAliasingQualityButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("AntiAliasingQuality"));
	OutlineQualityButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("OutlineQuality"));
	FrameRateButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("FrameRate"));

	// Ultimate
	ShowUltimateButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("SkipUltimate"));

	// Volumes
	BGMWidget = CastChecked<UProgressBarControlWidget>(GetWidgetFromName("BGM"));
	UIWidget = CastChecked<UProgressBarControlWidget>(GetWidgetFromName("UI"));
	SoundEffectWidget = CastChecked<UProgressBarControlWidget>(GetWidgetFromName("SoundEffect"));
	VoiceWidget = CastChecked<UProgressBarControlWidget>(GetWidgetFromName("Voice"));

	// TextSpeeds
	TextSpeed = CastChecked<UProgressBarControlWidget>(GetWidgetFromName("TextSpeed"));
	AutoTextSpeed = CastChecked<UProgressBarControlWidget>(GetWidgetFromName("AutoTextSpeed"));

	// Notice View
	ReceiveNoticeButton = CastChecked<UToggleButtonWidget>(GetWidgetFromName("ReceiveNotice"));

	// Setting View
	GraphicQualityButton->OnToggleButtonClickedDelegate.BindUObject(this, &USettingPopupWidget::OnGraphicQualityChanged);
	AntiAliasingQualityButton->OnToggleButtonClickedDelegate.BindUObject(this, &USettingPopupWidget::OnAntiAliasingQualityChanged);
	OutlineQualityButton->OnToggleButtonClickedDelegate.BindUObject(this, &USettingPopupWidget::OnOutlineQualityChanged);
	FrameRateButton->OnToggleButtonClickedDelegate.BindUObject(this, &USettingPopupWidget::OnFrameRateChanged);

	// Ultimate
	ShowUltimateButton->OnToggleButtonClickedDelegate.BindUObject(this, &USettingPopupWidget::OnShowUltimateChanged);

	// Volumes
	BGMWidget->OnProgressBarDelegate.BindUObject(this, &USettingPopupWidget::OnBGMSliderChanged);
	UIWidget->OnProgressBarDelegate.BindUObject(this, &USettingPopupWidget::OnUISliderChanged);
	SoundEffectWidget->OnProgressBarDelegate.BindUObject(this, &USettingPopupWidget::OnEffectSliderChanged);
	VoiceWidget->OnProgressBarDelegate.BindUObject(this, &USettingPopupWidget::OnVoiceSliderChanged);

	// TextSpeeds
	TextSpeed->OnProgressBarDelegate.BindUObject(this, &USettingPopupWidget::OnTextSpeedChanged);
	AutoTextSpeed->OnProgressBarDelegate.BindUObject(this, &USettingPopupWidget::OnAutoTextSpeedChanged);

	// Bind Notice View
	ReceiveNoticeButton->OnToggleButtonClickedDelegate.BindUObject(this, &USettingPopupWidget::ReceiveNoticeToggle);
}

void USettingPopupWidget::SetView()
{
	GameSettingData = UQ6GameUserSettings::Get()->GetGameSettingData();
	GameNoticeData = UQ6GameUserSettings::Get()->GetGameNoticeData();

	ReloadQualityView();
	ReloadNoticeView();
}

void USettingPopupWidget::ReloadQualityView()
{
	bOnReload = true;

	// Setting View
	GraphicQualityButton->SetSelectedIndex(GameSettingData.GraphicQuality);
	AntiAliasingQualityButton->SetSelectedIndex(GameSettingData.MSAAQuality);
	OutlineQualityButton->SetSelectedIndex(GameSettingData.OutlineQuality);
	FrameRateButton->SetSelectedIndex(GameSettingData.FrameRate);

	// Ultimate
	ShowUltimateButton->SetSelectedIndex(GameSettingData.ShowUltimate);

	// Volumes
	BGMWidget->OnValueChangedBP(GameSettingData.BGMVolume);
	UIWidget->OnValueChangedBP(GameSettingData.UIVolume);
	SoundEffectWidget->OnValueChangedBP(GameSettingData.EffectVolume);
	VoiceWidget->OnValueChangedBP(GameSettingData.VoiceVolume);
	
	// TextSpeeds
	TextSpeed->OnValueChangedBP(GameSettingData.TextSpeed);
	AutoTextSpeed->OnValueChangedBP(GameSettingData.AutoTextSpeed);

	bOnReload = false;
}

void USettingPopupWidget::ReloadNoticeView()
{
	bOnReload = true;

	ReceiveNoticeButton->SetCheckedBP(GameNoticeData.ReceiveNotice);

	bOnReload = false;
}

void USettingPopupWidget::OnGraphicQualityChanged(int32 ChangedIndex)
{
	GameSettingData.GraphicQuality = ChangedIndex;
	ApplySetting();
}

void USettingPopupWidget::OnAntiAliasingQualityChanged(int32 ChangedIndex)
{
	GameSettingData.MSAAQuality = ChangedIndex;
	ApplySetting();
}

void USettingPopupWidget::OnOutlineQualityChanged(int32 ChangedIndex)
{
	GameSettingData.OutlineQuality = ChangedIndex;
	ApplySetting();
}

void USettingPopupWidget::OnFrameRateChanged(int32 ChangedIndex)
{
	GameSettingData.FrameRate = ChangedIndex;
	ApplySetting();
}

void USettingPopupWidget::OnShowUltimateChanged(int32 ChangedIndex)
{
	GameSettingData.ShowUltimate = ChangedIndex;
	ApplySetting();
}

void USettingPopupWidget::ReceiveNoticeToggle()
{
	GameNoticeData.ReceiveNotice = ReceiveNoticeButton->GetChecked();
	ApplySetting();
}

void USettingPopupWidget::OnBGMSliderChanged(float Value)
{
	GameSettingData.BGMVolume = Value;
	ApplySetting();
}

void USettingPopupWidget::OnUISliderChanged(float Value)
{
	GameSettingData.UIVolume = Value;
	ApplySetting();
}

void USettingPopupWidget::OnEffectSliderChanged(float Value)
{
	GameSettingData.EffectVolume = Value;
	ApplySetting();
}

void USettingPopupWidget::OnVoiceSliderChanged(float Value)
{
	GameSettingData.VoiceVolume = Value;
	ApplySetting();
}

void USettingPopupWidget::OnTextSpeedChanged(float Value)
{
	GameSettingData.TextSpeed = Value;
	ApplySetting();
}

void USettingPopupWidget::OnAutoTextSpeedChanged(float Value)
{
	GameSettingData.AutoTextSpeed = Value;
	ApplySetting();
}
