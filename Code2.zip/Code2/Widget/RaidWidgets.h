#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

#include "RaidWidgets.generated.h"

class UItemWidget;
class UPointWidget;
class URaidStageWidget;

struct FSagaType;

DECLARE_DELEGATE_OneParam(FRaidStageClickedDelegate, FRaidId);

UCLASS()
class Q6_API URaidStageWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	URaidStageWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetInfo(const FRaidId& InRaidId
		, const FCMSSagaRow& SagaRow
		, const ERaidStageState InState
		, const ERaidCategory InRaidCategory
		, int64 InCurPoint
		, int64 InMaxPoint);

	UFUNCTION(BlueprintImplementableEvent)
	void SetRaidStageWidgetState(ERaidCategory InRaidCategory);

	FRaidStageClickedDelegate RaidStageClickedDelegate;

private:
	void SetRaidName(const FText& Text);

	void PlayRaidStageWidgetAnimation(const ERaidStageState InState);

	void SetWattPoint(int64 InCurPoint, int64 InMaxPoint);

	void SetBGImage(const FSagaType& InSagaType);

	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> RaidStageAnims;

	UPROPERTY()
	UTextBlock* RaidNameText;

	UPROPERTY()
	UTextBlock* RaidTimerText;

	UPROPERTY()
	UPointWidget* WattWidget;

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UImage* TagImage;

	FRaidId RaidId;
};


UCLASS()
class Q6_API URaidWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	URaidWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Raid; }

private:
	void SetInfo();

	void SetJoinableRaid();
	void SetJoinableRegularRaid();
	void SetOpenedRaid();

	void SetRewardItemInfo();

	void SetFinalStageList();

	void SetRegularRaidInfoText();

	void PlayRaidWidgetAnimation();

	void SetGetImageVisible(bool bInVisible);

	void SetInitialRewardItemVisible(bool bInVisible);

	void ReqPrepare();

	void ChangeJokerSelectHUDWidget(const FRaidType RaidType);

	UFUNCTION()
	void OnJoinableButtonClicked(FRaidId InRaidId);

	UFUNCTION()
	void OnFinalStageButtonClicked(FRaidId InRaidId);

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> RaidAnims;

	UPROPERTY()
	UDynamicListWidget* StageListWidget;

	UPROPERTY()
	URaidStageWidget* SelectedRaidJoinable;

	UPROPERTY()
	UItemWidget* InitialReward;

	UPROPERTY()
	UTextBlock* CurListCountText;

	UPROPERTY()
	UTextBlock* MaxListCountText;

	UPROPERTY()
	UTextBlock* RegularInfoText;

	UPROPERTY()
	UImage* GetImage;

	FRaidType OpenRaidType;
	FRaidId OpenRaidId;

	FRaidType RegularRaidType;
	int32 RegularRaidScheduleId;
	bool RegularRaidRegisterd;
	bool RegularRaidMatched;
	bool WaitForReqReady;
	bool RegularRaidRespReady;
};
