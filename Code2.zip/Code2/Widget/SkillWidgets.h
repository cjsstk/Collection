
// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "HUD/BaseHUD.h"
#include "PopupWidgets.h"
#include "SkillWidgets.generated.h"

DECLARE_DELEGATE_FourParams(FWonderSkillDelegate, FCCSkillId, int32, FCCUnitId, ESkillCategory)
DECLARE_DELEGATE_TwoParams(FArtifactSkillDelegate, int32, FCCUnitId)

class AUnit;

class UCombatPetSkillIconWidget;
class UCombatTurnSkillStateWidget;
class URichTextBlock;

struct FUltimateSkillSequenceAssetRow;
struct FSkillState;

UCLASS()
class Q6_API UUltimateIllustWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UUltimateIllustWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void PlaySkillAnimation(const FUltimateSkillSequenceAssetRow& SkillSequenceAssetRow);

private:
	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UImage* UnitImage;

	UPROPERTY()
	UImage* ShadowImage;

	UPROPERTY(Transient)
	UWidgetAnimation* IllustAnim;
};


///////////////////////////////////////////////////////////////////////////////////////////
// USkillAnimationWidget

UCLASS()
class Q6_API USkillAnimationWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	USkillAnimationWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	virtual void PlaySkillAnimation(int32 SkillType, const FUltimateSkillSequenceAssetRow& SkillAssetRow);
	virtual void StopSkillAnimation();

	void PlayCardAnimation(bool bSnapshop);
	void PlaySnapshotAnimation();

	FSimpleDelegate SkillAnimFinishedDelegate;

protected:
	UPROPERTY()
	UTextBlock* SkillNameText;

private:
	UPROPERTY(Transient)
	UWidgetAnimation* StartSkillAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CardStartAnim;	// Nullable

	UPROPERTY(Transient)
	UWidgetAnimation* SnapshotAnim;
};


///////////////////////////////////////////////////////////////////////////////////////////
// UCommonSkillAnimationWidget

UCLASS()
class Q6_API UCommonSkillAnimationWidget : public USkillAnimationWidget
{
	GENERATED_BODY()

public:

	UCommonSkillAnimationWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	virtual void PlaySkillAnimation(int32 SkillType, const FUltimateSkillSequenceAssetRow& SkillSequenceAssetRow) override;
	virtual void StopSkillAnimation() override;

	void PlayNatureAnimation(ENatureType NatureType);

private:
	UPROPERTY()
	UUltimateIllustWidget* IllustWidget;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> NatureAnims;

	UPROPERTY(EditDefaultsOnly)
	TArray<FLinearColor> FontOutlineColors;
};


///////////////////////////////////////////////////////////////////////////////////////////
// USupportSkillAnimationWidget

UCLASS()
class Q6_API USupportSkillAnimationWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USupportSkillAnimationWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void PlayHelpSkillAnimation(int32 ModelType, int32 SkillType, int32 SupporterBonus);

	FSimpleDelegate AnimationFinishedDelegate;

private:
	UPROPERTY()
	UTextBlock* SkillNameText;

	UPROPERTY()
	UTextBlock* SkillEffectText;

	UPROPERTY()
	UImage* SkillPortraitImage;

	UPROPERTY()
	UImage* BonusIcon;

	UPROPERTY(Transient)
	UWidgetAnimation* HelpAnim;
};


///////////////////////////////////////////////////////////////////////////////////////////
// UArtifactAnimationWidget

UCLASS()
class Q6_API UArtifactAnimationWidget : public USkillAnimationWidget
{
	GENERATED_BODY()

public:
	UArtifactAnimationWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void PlayArtifactAnimation(int32 InSkillType, FCCUnitId InTargetUnitId);

	FArtifactSkillDelegate ArtifactAnimFinishedDelegate;

private:
	UFUNCTION()
	void OnSkillAnimFinished();

	UPROPERTY()
	UImage* FreyaImage;

	UPROPERTY()
	UTextBlock* SkillCategory;

	int32 SkillType;
	FCCUnitId TargetUnitId;
};

///////////////////////////////////////////////////////////////////////////////////////////
// CombatPetButtonWidget

UCLASS()
class Q6_API UCombatPetButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void Init(FPetType InPetType, const TArray<FSkillState>& InSkillStates);
	void UpdateSkillStates();

	bool HasValidPet() { return (PetType != PetTypeInvalid); }

	void SetPhase(ECPTurnPhase InPhase);
	void SetSkillEnabled(bool bInEnabled);

	void PlayStartAnimation() { PlayAnimation(StartAnim); }
	void PlayEndAnimation() { PlayAnimation(EndAnim); }

	FSimpleDelegate OnOpenButtonClickedDelegate;

private:
	UFUNCTION()
	void OnOpenButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* NormalAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DisabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EndAnim;

	UPROPERTY()
	UCombatTurnSkillStateWidget* SkillStateWidget;

	FPetType PetType;
};


///////////////////////////////////////////////////////////////////////////////////////////
// CombatWonderSkillButtonWidget

UCLASS()
class Q6_API UCombatWonderSkillButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPetSkill(FPetType PetType, const FSkillState& SkillState);
	void SetArtifactSkill(const FSkillState& SkillState);

	void SetTarget(FCCUnitId InTargetId);

	FWonderSkillDelegate OnWonderSkillSelectedDelegate;

private:
	void SetSkillInternal(const FSkillState& SkillState);

	void ShowReasonNotification();

	UFUNCTION()
	void OnSelectButtonClicked();

private:
	UPROPERTY(Transient)
	UWidgetAnimation* EnabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DisabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* PetStateAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ArtifactStateAnim;

	UPROPERTY()
	UImage* ArtifactSkillIconImage;

	UPROPERTY()
	UTextBlock* ArtifactSkillCooldownText;

	UPROPERTY()
	UImage* PetSkillIconImage;

	UPROPERTY()
	UTextBlock* PetSkillCooldownText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	URichTextBlock* SkillInfoText;

	UPROPERTY()
	URichTextBlock* CooltimeText;

	enum class EWonderSkillState : uint8
	{
		Locked,
		Disabled,
		Enabled,
	};

	FCCSkillId SkillId;
	int32 SkillType;
	ESkillCategory SkillCategory;
	EWonderSkillState State;

	FCCUnitId TargetUnitId;
};


///////////////////////////////////////////////////////////////////////////////////////////
// CombatWonderSkillUsePopupWidget

UCLASS()
class Q6_API UCombatWonderSkillUsePopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPetSkills(FPetType PetType, const TArray<FSkillState>& PetSkills, FCCUnitId InTargetUnitId);
	void SetArtifactSkills(const TArray<FSkillState>& ArtifactSkills, FCCUnitId InTargetUnitId);

private:
	UFUNCTION()
	void OnSelectButtonClicked(FCCSkillId SkillId, int32 SkillType, FCCUnitId TargetUnitId, ESkillCategory SkillCategory);

private:
	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	TArray<UCombatWonderSkillButtonWidget*> WonderSkillWidgets;
};

///////////////////////////////////////////////////////////////////////////////////////////
// UltimateSkipWidget

UCLASS()
class Q6_API UUltimateSkipWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	FSimpleDelegate OnSkipDelegate;

private:
	UFUNCTION()
	void OnSkipButtonClicked();
};


///////////////////////////////////////////////////////////////////////////////////////////
// UAttackABCCardWidget

UCLASS()
class Q6_API USkillNoteCardWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacter(int32 ModelType, ESkillNote SkillNote);

private:
	UPROPERTY()
	UBorder* AttackCardBorder;

	UPROPERTY()
	UImage* FrameImage;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> NoteBrushes;
};
