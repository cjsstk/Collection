#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

#include "PlayRecordPopupWidgets.generated.h"

struct FUserRecordInfo;
struct FCMSUserRecordRow;

class UQ6TextBlock;
class URichTextBlock;
class UDynamicListWidget;
class UToggleButtonBoxWidget;

UCLASS()
class Q6_API UPlayRecordListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPlayRecordListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetPlayRecordListInfo(const int32 Value
		, const FCMSUserRecordRow& RecordRow);

private:
	void SetRecordTitleTextBlock(const FText& InText);
	void SetRecordTextBlock(const FText& InText);

	UPROPERTY()
	UQ6TextBlock* RecordTitleTextBlock;

	UPROPERTY()
	URichTextBlock* RecordValueRichTextBlock;
};

UCLASS()
class Q6_API UPlayRecordPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UPlayRecordPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void InitPlayRecordPopup();

private:
	void OnRecordToggleChanged(int32 Index);

	void SetRecordList(const EUserRecordCategory InCategory);

	UPROPERTY()
	UToggleButtonBoxWidget* RecordToggleButton;

	UPROPERTY()
	UDynamicListWidget* RecordListWidget;

	EUserRecordCategory RecordCategory;
};
