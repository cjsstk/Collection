#include "AchievementsPageWidgets.h"

#include "CharacterManager.h"
#include "CharMissionManager.h"
#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "SkillWidgets.h"

const int32 PUZZLE_PIECE_OFFSET_Y = -200;

DECLARE_CYCLE_STAT(TEXT("OnHSEvent AchievementsPage"), STAT_OnHSEventByAchievementsPage, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent AchievementsPuzzle"), STAT_OnHSEventByAchievementsPuzzle, STATGROUP_HSTORE);

UAchievementsListWidget::UAchievementsListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UAchievementsListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AchievementsListAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimListNormal"));
	AchievementsListAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimListActive"));
	AchievementsListAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimListComplete"));
	check(AchievementsListAnims.Num() == static_cast<int32>(EAchievementsListAnimType::Max));

	UButton* GetRewardButton = CastChecked<UButton>(GetWidgetFromName("GetReward"));
	GetRewardButton->OnClicked.AddUniqueDynamic(this
		, &UAchievementsListWidget::OnGetRewardButtonClicked);

	AchieveGaugeWidget = CastChecked<UMissionGaugeWidget>(GetWidgetFromName("AchieveGauge"));
	AchieveItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
}

void UAchievementsListWidget::SetInfo(const int32 InMissionIng, const int32 InMaxValue
	, const int32 InRewardUtc, const int32 InCharMissionType)
{
	const int32 MissionIng = FMath::Clamp(InMissionIng, 0, InMaxValue);

	const FCMSCharMissionRow& CharMissionRow = GetCMS()->GetCharMissionRowOrDummy(
		FCharMissionType(InCharMissionType));

	AchieveGaugeWidget->SetInfo(CharMissionRow.Desc
		, MissionIng
		, MissionIng
		, InMaxValue
		, MissionIng < InMaxValue);

	SetAchievementsItem(CharMissionRow);

	if (MissionIng < InMaxValue)
	{
		AchieveItemWidget->SetChecked(false);
		PlayAchievementsListAnimation(EAchievementsListAnimType::Normal);
	}
	else if (MissionIng == InMaxValue)
	{
		if (InRewardUtc == 0)
		{
			AchieveItemWidget->SetChecked(false);
			PlayAchievementsListAnimation(EAchievementsListAnimType::Active);
		}
		else
		{
			AchieveItemWidget->SetChecked(true);
			PlayAchievementsListAnimation(EAchievementsListAnimType::Complete);
		}
	}
}

void UAchievementsListWidget::PlayAchievementsListAnimation(EAchievementsListAnimType Type)
{
	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (AchievementsListAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(AchievementsListAnims[AnimIndex]);
	}
}

void UAchievementsListWidget::SetAchievementsItem(const FCMSCharMissionRow& CharMissionRow)
{
	const FCMSLootGroupRow& LootGroupRow = CharMissionRow.GetLootGroup();
	const FCMSLootDataRow& LootDataRow = GetCMS()->GetFirstLootDataOrDummyFromLootGroups(LootGroupRow);

	AchieveItemWidget->SetRewardType(ERewardType::None);
	AchieveItemWidget->SetLoot(LootDataRow.LootId, LootDataRow.Count);
}

void UAchievementsListWidget::OnGetRewardButtonClicked()
{
	OnGetRewardButtonClickedDelegate.ExecuteIfBound();
}

UPuzzlePieceWidget::UPuzzlePieceWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bMovable(false)
{

}

void UPuzzlePieceWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PuzzlePieceAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimHighlightLoop"));
	PuzzlePieceAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimLastPiece"));
	PuzzlePieceAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMoveRight"));
	PuzzlePieceAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMoveLeft"));
	PuzzlePieceAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMoveUp"));
	PuzzlePieceAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMoveDown"));
	PuzzlePieceAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimGetPiece"));
	check(PuzzlePieceAnims.Num() == static_cast<int32>(EPuzzlePieceAnimType::Max));

	PuzzlePieceSizeBox = CastChecked<USizeBox>(GetWidgetFromName("PuzzleSizebox"));

	PuzzlePieceImageSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("ImageSwitcher"));

	UButton* PuzzlePieceButton = CastChecked<UButton>(GetWidgetFromName("BtnMove"));
	PuzzlePieceButton->OnClicked.AddUniqueDynamic(this
		, &UPuzzlePieceWidget::OnPuzzlePieceButtonClicked);

	ImgIllustImage = CastChecked<UImage>(GetWidgetFromName("ImgIllust"));
}

void UPuzzlePieceWidget::NativeDestruct()
{
	const int32 ChildIndex = static_cast<int32>(
		EAchievementsPuzzleImageType::UlimateSkillAnimationWidgetImage);

	UWidget* ChildWidget = PuzzlePieceImageSwitcher->GetWidgetAtIndex(ChildIndex);
	if (ChildWidget)
	{
		PuzzlePieceImageSwitcher->RemoveChildAt(ChildIndex);
	}

	Super::NativeDestruct();
}

float UPuzzlePieceWidget::GetPuzzlePieceSize()
{
	check(PuzzlePieceSizeBox->WidthOverride == PuzzlePieceSizeBox->HeightOverride);

	return PuzzlePieceSizeBox->WidthOverride;
}

void UPuzzlePieceWidget::SetImageSwitcherPosition(float InX, float InY)
{
	float Size = GetPuzzlePieceSize();

	InX *= Size;
	InY *= Size;

	UCanvasPanelSlot* SwitcherSlot = Cast<UCanvasPanelSlot>(PuzzlePieceImageSwitcher->Slot);
	if (ensure(SwitcherSlot))
	{
		FVector2D Position(0, PUZZLE_PIECE_OFFSET_Y);
		Position.X -= InX;
		Position.Y -= InY;

		SwitcherSlot->SetPosition(Position);
	}
}

void UPuzzlePieceWidget::SetInfo(const FCharacterType InCharacterType, bool bAlreadyReceived)
{
	const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(InCharacterType);

	if (CharacterRow.Grade == EItemGrade::SSR
		|| CharacterRow.Grade == EItemGrade::SR)
	{
		if (!FindOrCreateCharacterUltimateIlustWidget(InCharacterType))
		{
			SetCharacterIllustBGTexture(InCharacterType, CharacterRow.Grade);
		}
	}
	else
	{
		SetCharacterIllustBGTexture(InCharacterType, CharacterRow.Grade);
	}

	if (!bAlreadyReceived)
	{
		PlayPuzzlePieceAnimation(EPuzzlePieceAnimType::GetPiece);
	}
}

void UPuzzlePieceWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	int32 HighlightLoopAnimIndex = static_cast<int32>(EPuzzlePieceAnimType::HighlightLoop);
	int32 GetPieceAnimIndex = static_cast<int32>(EPuzzlePieceAnimType::GetPiece);
	if (Animation == PuzzlePieceAnims[HighlightLoopAnimIndex]
		|| Animation == PuzzlePieceAnims[GetPieceAnimIndex])
	{
		return;
	}

	OnPuzzlePieceAnimFinishedDelegate.ExecuteIfBound();
}

bool UPuzzlePieceWidget::FindOrCreateCharacterUltimateIlustWidget(const FCharacterType& InCharacterType)
{
	const int32 ChildIndex = static_cast<int32>(
		EAchievementsPuzzleImageType::UlimateSkillAnimationWidgetImage);

	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(InCharacterType);
	if (UnitRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "SetCharacterUltimateIlustWidget - FCMSUnitRow does not exist."
			, Q6KV("FCharacterType", InCharacterType));
		return false;
	}

	const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRow = GetGameResource()
		.GetModelUltimateSkillSequenceAssetRow(UnitRow.Model);
	if (UltimateSkillSequenceAssetRow.WidgetAnimationClass.IsNull())
	{
		Q6JsonLogGenie(Display, "SetCharacterUltimateIlustWidget - WidgetAnimationClass does not exist."
			, Q6KV("UnitRow.Model", UnitRow.Model));
		return false;
	}

	if (!UltimateSkillSequenceAssetRow.WidgetAnimationClass.Get())
	{
		UltimateSkillSequenceAssetRow.WidgetAnimationClass.LoadSynchronous();
	}

	USkillAnimationWidget* UltmateSkillAnimationWidget = CreateWidget<USkillAnimationWidget>(
		GetOwningPlayer(), UltimateSkillSequenceAssetRow.WidgetAnimationClass.Get());

	if (!UltmateSkillAnimationWidget)
	{
		return false;
	}

	UWidget* ChildWidget = PuzzlePieceImageSwitcher->GetWidgetAtIndex(ChildIndex);
	if (ChildWidget)
	{
		PuzzlePieceImageSwitcher->ReplaceChildAt(ChildIndex, UltmateSkillAnimationWidget);
	}
	else
	{
		PuzzlePieceImageSwitcher->AddChild(UltmateSkillAnimationWidget);
	}

	PuzzlePieceImageSwitcher->SetActiveWidget(UltmateSkillAnimationWidget);

	UltmateSkillAnimationWidget->PlaySnapshotAnimation();

	return true;
}

void UPuzzlePieceWidget::SetCharacterIllustBGTexture(const FCharacterType& InCharacterType, const EItemGrade InGrade)
{
	UGameResource& GameResource = GetGameResource();
	const FCharacterAssetRow& CharacterAssetRow = GameResource.GetCharacterAssetRow(InCharacterType);

	if (InGrade == EItemGrade::SSR || InGrade == EItemGrade::SR)
	{
		ImgIllustImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIllustBGTexture());
	}
	else
	{
		ImgIllustImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);
	}

	PuzzlePieceImageSwitcher->SetActiveWidgetIndex(
		static_cast<int32>(EAchievementsPuzzleImageType::GeneralPuzzleImage));
}

void UPuzzlePieceWidget::PlayPuzzlePieceAnimation(EPuzzlePieceAnimType Type)
{
	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (PuzzlePieceAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(PuzzlePieceAnims[AnimIndex]);
	}
}

void UPuzzlePieceWidget::OnPuzzlePieceButtonClicked()
{
	if (bMovable)
	{
		OnPuzzlePieceButtonClickedDelegate.ExecuteIfBound();
	}
}

UPuzzleBoxWidget::UPuzzleBoxWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PuzzleSlotStates.Reserve(MAX_CHAR_MISSION_PUZZLE_PIECE);
	ResetPuzzleSlotState();
}

void UPuzzleBoxWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	for (int32 PieceIndex = 0; PieceIndex < MAX_CHAR_MISSION_PUZZLE_PIECE; ++PieceIndex)
	{
		WidgetName = FString::Printf(TEXT("Piece%d"), PieceIndex);

		UPuzzlePieceWidget* PuzzlePieceWidget = CastChecked<UPuzzlePieceWidget>(
			GetWidgetFromName(*WidgetName));

		PuzzlePieceWidget->OnPuzzlePieceButtonClickedDelegate.BindUObject(this
			, &UPuzzleBoxWidget::OnPuzzlePieceButtonClicked, PieceIndex);

		PuzzlePieceWidget->OnPuzzlePieceAnimFinishedDelegate.BindUObject(this
			, &UPuzzleBoxWidget::OnPuzzlePieceAnimFinishedClicked, PieceIndex);

		PuzzlePieces.AddUnique(PuzzlePieceWidget);
	}
}

void UPuzzleBoxWidget::ResetPuzzleSlotState()
{
	PuzzleSlotStates.Reset();
	for (int PieceIndex = 0; PieceIndex < MAX_CHAR_MISSION_PUZZLE_PIECE; ++PieceIndex)
	{
		PuzzleSlotStates.Add(EPuzzleSlotState::Max);
	}
}

void UPuzzleBoxWidget::SetPuzzlePieceInfo(const FCharacterType CharacterType, const int32 Index
	, const int32 ShuffleIndex, EPuzzleSlotState Type, bool bAleadyReceived)
{
	if (!PuzzlePieces.IsValidIndex(Index))
	{
		return;
	}

	if (PuzzleSlotStates.IsValidIndex(Index)
		&& PuzzleSlotStates[Index] == Type)
	{
		return;
	}

	PuzzlePieces[Index]->StopAllAnimations();

	PuzzlePieces[Index]->SetInfo(CharacterType, bAleadyReceived);

	PuzzlePieces[Index]->SetImageSwitcherPosition(
		(ShuffleIndex % MAX_CHAR_MISSION_PUZZLE_BOARD_SIZE) - 1
		, ShuffleIndex / MAX_CHAR_MISSION_PUZZLE_BOARD_SIZE);

	PuzzlePieces[Index]->SetPuzzleSlotState(Type);

	PuzzleSlotStates[Index] = Type;
}

void UPuzzleBoxWidget::SetMovableState(const int32 Index, bool bMovable)
{
	if (!PuzzlePieces.IsValidIndex(Index))
	{
		return;
	}

	PuzzlePieces[Index]->StopAllAnimations();
	PuzzlePieces[Index]->SetMovable(bMovable);
	PuzzlePieces[Index]->SetPuzzleSlotMovableState(
		bMovable ? EPuzzleSlotMovableState::Movable : EPuzzleSlotMovableState::Immovable);
}

void UPuzzleBoxWidget::OnPuzzlePieceButtonClicked(int32 Index)
{
	OnPuzzlePieceButtonClickedDelegate.ExecuteIfBound(Index);
}

void UPuzzleBoxWidget::OnPuzzlePieceAnimFinishedClicked(int32 Index)
{
	OnPuzzlePieceAnimFinishedDelegate.ExecuteIfBound(Index);
}

void UPuzzleBoxWidget::SetAchievementsPageInfo(const FCharacterType InCharacterType, const TArray<int32>& ShuffleNumbers
	, const int32 BefoCollectedPiece, const int32 CurrCollectedPiece, bool bPuzzleCompleted)
{
	int32 Index(0);
	if (BefoCollectedPiece == INDEX_NONE)
	{
		for (Index = BefoCollectedPiece + 1; Index < CurrCollectedPiece; ++Index)
		{
			SetPuzzlePieceInfo(InCharacterType, Index, ShuffleNumbers[Index], EPuzzleSlotState::ImageSlot, true);
		}
	}
	else
	{
		for (; Index < BefoCollectedPiece; ++Index)
		{
			SetPuzzlePieceInfo(InCharacterType, Index, ShuffleNumbers[Index], EPuzzleSlotState::ImageSlot, true);
		}
		for (Index = BefoCollectedPiece; Index < CurrCollectedPiece; ++Index)
		{
			SetPuzzlePieceInfo(InCharacterType, Index, ShuffleNumbers[Index], EPuzzleSlotState::ImageSlot, false);
		}
	}

	for (Index = CurrCollectedPiece; Index < MAX_CHAR_MISSION; ++Index)
	{
		SetPuzzlePieceInfo(InCharacterType, Index, ShuffleNumbers[Index], EPuzzleSlotState::LockSlot, false);
	}

	if (bPuzzleCompleted)
	{
		SetPuzzlePieceInfo(InCharacterType, MAX_CHAR_MISSION, MAX_CHAR_MISSION
			, EPuzzleSlotState::ImageSlot, true);
	}
	else
	{
		SetPuzzlePieceInfo(InCharacterType, MAX_CHAR_MISSION, MAX_CHAR_MISSION
			, EPuzzleSlotState::LockSlot, false);
	}
}

void UPuzzleBoxWidget::SetAchievementsPuzzleInfo(const FCharacterType InCharacterType
	, const TArray<int32>& ShuffleNumbers)
{
	int32 BlankIndex = 0;

	for (int32 Index = 0; Index < MAX_CHAR_MISSION_PUZZLE_PIECE; ++Index)
	{
		SetMovableState(Index, false);

		check(ShuffleNumbers.IsValidIndex(Index));
		if (ShuffleNumbers[Index] == INDEX_NONE)
		{
			BlankIndex = Index;
			SetPuzzlePieceInfo(InCharacterType, Index, ShuffleNumbers[Index], EPuzzleSlotState::LockSlot, true);
		}
		else
		{
			SetPuzzlePieceInfo(InCharacterType, Index, ShuffleNumbers[Index], EPuzzleSlotState::ImageSlot, true);
		}
	}

	int32 RowMin = (BlankIndex / MAX_MISSION_BINGO_BOARD_SIZE) * MAX_MISSION_BINGO_BOARD_SIZE;
	int32 RowMax = RowMin + MAX_MISSION_BINGO_BOARD_SIZE;

	if (RowMin <= BlankIndex - 1 && BlankIndex - 1 < RowMax)
	{
		SetMovableState(BlankIndex - 1, true);
	}
	if (RowMin <= BlankIndex + 1 && BlankIndex + 1 < RowMax)
	{
		SetMovableState(BlankIndex + 1, true);
	}
	if (0 <= BlankIndex - MAX_MISSION_BINGO_BOARD_SIZE
		&& BlankIndex - MAX_MISSION_BINGO_BOARD_SIZE < MAX_CHAR_MISSION_PUZZLE_PIECE)
	{
		SetMovableState(BlankIndex - MAX_MISSION_BINGO_BOARD_SIZE, true);
	}
	if (0 <= BlankIndex + MAX_MISSION_BINGO_BOARD_SIZE
		&& BlankIndex + MAX_MISSION_BINGO_BOARD_SIZE < MAX_CHAR_MISSION_PUZZLE_PIECE)
	{
		SetMovableState(BlankIndex + MAX_MISSION_BINGO_BOARD_SIZE, true);
	}
}

void UPuzzleBoxWidget::PlayPuzzlePieceAnimation(const int32 Index, EPuzzlePieceAnimType Type)
{
	if (!PuzzlePieces.IsValidIndex(Index))
	{
		return;
	}

	PuzzlePieces[Index]->StopAllAnimations();
	PuzzlePieces[Index]->PlayPuzzlePieceAnimation(Type);
}

UAchievementsPageWidget::UAchievementsPageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CharType(CharacterTypeInvalid)
	, CollectedPieceCount(INDEX_NONE)
	, GetRewardButtonIndex(INDEX_NONE)
	, bPuzzleCompleted(false)
{
	AchievementInfos.Reserve(MAX_CHAR_MISSION);
	PuzzleShuffleNumbers.Reserve(MAX_CHAR_MISSION);
}

void UAchievementsPageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AchievementsPageAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimListNormal"));
	AchievementsPageAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimListPuzzleActiveLoop"));
	AchievementsPageAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimListPuzzleComplete"));
	check(AchievementsPageAnims.Num() == static_cast<int32>(EAchievementsPageAnimType::Max));

	MasterpieceNameText = CastChecked<UTextBlock>(GetWidgetFromName("MasterpieceName"));
	CollectedPiecesText = CastChecked<UTextBlock>(GetWidgetFromName("CollectedPieces"));

	StartPuzzleButton = CastChecked<UQ6Button>(GetWidgetFromName("StartPuzzle"));
	StartPuzzleButton->OnClickedDelegate.BindUObject(
		this, &UAchievementsPageWidget::OnStartPuzzleButtonClicked);

	BoxPuzzleWidget = CastChecked<UPuzzleBoxWidget>(GetWidgetFromName("BoxPuzzle"));

	AchievementListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("AchievementList"));

	SubscribeToStore(EHSType::CharMission);
}

void UAchievementsPageWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByAchievementsPage);

	switch (Action->GetActionType())
	{
		case EHSActionType::CharMissionRewardResp:
		{
			OpenReceivedRewardItemPopup();
		}
		break;
		case EHSActionType::DevCharMissionSetResp:
		{
			SetInfo();
		}
		break;
	}
}

void UAchievementsPageWidget::InitAchievementsPage(const FCharacterType& InCharType)
{
	CharType = InCharType;
	CollectedPieceCount = 0;

	SetPuzzleShuffleNumbers();

	SetInfo();
}

void UAchievementsPageWidget::SetInfo()
{

	SetAchievementsData();
	SetAchievementsList();

	SetCollectedPiecesText();
	SetMasterPieceNameText();
	SetAchievementsPageAnimation();
}

void UAchievementsPageWidget::OpenReceivedRewardItemPopup()
{
	for (const FAchievementInfo& AchievementInfo : AchievementInfos)
	{
		if (AchievementInfo.Index != GetRewardButtonIndex)
		{
			continue;
		}

		const UCMS* CMS = GetCMS();
		check(CMS);

		const FCMSCharMissionRow& CharMissionRow = CMS->GetCharMissionRowOrDummy(
			FCharMissionType(AchievementInfo.CharMissionType));
		if (CharMissionRow.IsInvalid())
		{
			Q6JsonLogGenie(Warning, "OpenReceivedRewardItemPopup - FCMSCharMissionRow does not exist."
				, Q6KV("CharMissionType", AchievementInfo.CharMissionType));
			break;
		}

		const FCMSLootGroupRow& LootGroupRow = CharMissionRow.GetLootGroup();
		const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRow);

		UItemReceivedPopupWidget* ItemReceivedPopup = GetLobbyHUD(this)->OpenItemReceivedPopup();
		ItemReceivedPopup->SetMissionReceivedItem(LootDataRow);
		ItemReceivedPopup->OnPopupClosedDelegate.BindUObject(this
			, &UAchievementsPageWidget::OnItemReceivedPopupClosed);

		break;
	}
}

void UAchievementsPageWidget::PlayAchievementsPageAnimation(EAchievementsPageAnimType Type, bool bLoop)
{
	StopAllAnimations();

	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (AchievementsPageAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(AchievementsPageAnims[AnimIndex], 0.0f, bLoop ? 0 : 1);
	}
}

void UAchievementsPageWidget::SetPuzzleShuffleNumbers()
{
	UHUDStore& HUDStore = GetHUDStore();

	bPuzzleCompleted = false;
	FCharMissionId CharMissionId;
	const FCharMissionInfo* CharMissionInfo = HUDStore.GetCharMissionManager().GetCharMissionByCharacterType(CharType);
	if (CharMissionInfo)
	{
		CharMissionId = CharMissionInfo->CharMissionId;

		if (CharMissionInfo->RUtc.IsValidIndex(MAX_CHAR_MISSION))
		{
			if (CharMissionInfo->RUtc[MAX_CHAR_MISSION] > 0)
			{
				bPuzzleCompleted = true;
			}
		}
	}

	PuzzleShuffleNumbers.Reset();
	if (bPuzzleCompleted)
	{
		for (int32 Index = 0; Index < MAX_CHAR_MISSION; ++Index)
		{
			PuzzleShuffleNumbers.Add(Index);
		}

		return;
	}

	const int32 Seed = (CharType % MAX_CHAR_MISSION)
		+ (CharMissionId % MAX_CHAR_MISSION)
		+ 2;

	TArray<int32> Numbers;
	for (int32 Index = 0; Index < MAX_CHAR_MISSION; ++Index)
	{
		Numbers.Add(Index);
	}

	int32 Advance = 0;
	while (Numbers.Num() > 0)
	{
		for (int32 Index = 0; Index < Seed; ++Index)
		{
			++Advance;
			if (Advance >= Numbers.Num())
			{
				Advance = 0;
			}
		}

		PuzzleShuffleNumbers.Add(Numbers[Advance]);
		Numbers.RemoveAt(Advance);
	}

	TArray<TPair<int32, int32>> Inversions;

	for (int32 Index1 = 0; Index1 < MAX_CHAR_MISSION; ++Index1)
	{
		for (int32 Index2 = Index1 + 1; Index2 < MAX_CHAR_MISSION; ++Index2)
		{
			if (PuzzleShuffleNumbers[Index1] > PuzzleShuffleNumbers[Index2])
			{
				Inversions.Emplace(Index1, Index2);
			}
		}
	}

	if (Inversions.Num() % 2 != 0)
	{
		TPair<int,int> LastData = Inversions.Last();
		PuzzleShuffleNumbers.Swap(LastData.Key, LastData.Value);
	}
}

void UAchievementsPageWidget::SetAchievementsData()
{
	int32 RewardCount = 0;
	AchievementInfos.Reset();

	const UHUDStore& HUDStore = GetHUDStore();
	const UCharMissionManager& CharMissionManager = HUDStore.GetCharMissionManager();
	const FCharMissionInfo* FoundCharMissionInfo = CharMissionManager.GetCharMissionByCharacterType(CharType);
	const FCMSCharMissionSetRow* CharMissionSetRow = GetCMS()->GetCharMissionSetRowByCharType(CharType);
	if (!CharMissionSetRow)
	{
		SetBoxPuzzleInfo(CharType, 0, 0);
		Q6JsonLogGenie(Warning, "SetAchievementList - FCMSCharMissionSetRow does not exist."
			, Q6KV("CharacterType", CharType));
		return;
	}

	const TArray<const FCMSCharMissionRow*>& CharMissionRows = CharMissionSetRow->GetMission();
	for (int32 Index = 0; Index < MAX_CHAR_MISSION; ++Index)
	{
		FAchievementInfo AchievementInfo;
		AchievementInfo.Index = Index;
		AchievementInfo.MaxValue = CharMissionManager.GetMaxValue(CharMissionRows[Index]->CmsType());
		AchievementInfo.CharMissionType = CharMissionRows[Index]->Type;

		if (FoundCharMissionInfo)
		{
			AchievementInfo.MissionIng = FoundCharMissionInfo->MIng[Index];
			AchievementInfo.RewardUtc = FoundCharMissionInfo->RUtc[Index];
		}

		if (AchievementInfo.RewardUtc > 0)
		{
			++RewardCount;
		}

		AchievementInfos.Emplace(AchievementInfo);
	}

	AchievementInfos.StableSort([](const FAchievementInfo& Info1, const FAchievementInfo& Info2)
	{
		if (Info1.RewardUtc == Info2.RewardUtc)
		{
			return (Info1.MissionIng / Info1.MaxValue) > (Info2.MissionIng / Info2.MaxValue);
		}
		else
		{
			return Info1.RewardUtc < Info2.RewardUtc;
		}
	});

	SetBoxPuzzleInfo(CharType, CollectedPieceCount, RewardCount);
	CollectedPieceCount = RewardCount;
}

void UAchievementsPageWidget::SetAchievementsList()
{
	AchievementListWidget->ClearList();
	for(const FAchievementInfo& AchievementInfo : AchievementInfos)
	{
		UAchievementsListWidget* AchievementsListWidget = CastChecked<UAchievementsListWidget>(
			AchievementListWidget->AddChildAtLastIndex());

		AchievementsListWidget->SetInfo(AchievementInfo.MissionIng
			, AchievementInfo.MaxValue
			, AchievementInfo.RewardUtc
			, AchievementInfo.CharMissionType);

		AchievementsListWidget->OnGetRewardButtonClickedDelegate.BindUObject(this,
			&UAchievementsPageWidget::OnGetRewardButtonClicked, AchievementInfo.Index);
	}
}

void UAchievementsPageWidget::SetBoxPuzzleInfo(const FCharacterType InCharacterType
	, const int32 BefoCollectedPiece, const int32 CurrCollectedPiece)
{
	BoxPuzzleWidget->ResetPuzzleSlotState();
	BoxPuzzleWidget->SetAchievementsPageInfo(InCharacterType, PuzzleShuffleNumbers
		, BefoCollectedPiece, CurrCollectedPiece, bPuzzleCompleted);
}

void UAchievementsPageWidget::SetCollectedPiecesText()
{
	CollectedPiecesText->SetText(FText::AsNumber(CollectedPieceCount));
}

void UAchievementsPageWidget::SetMasterPieceNameText()
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharType);
	if (UnitRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "SetMasterPieceNameText - UnitRow does not exist."
			, Q6KV("FCharacterType", CharType));
		return;
	}

	const FCMSSkillRow& SkillRow = CMS->GetCharacterUltimateSkillRow(UnitRow);
	if (SkillRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "SetMasterPieceNameText - UltimateSkillRow does not exist."
			, Q6KV("FCharacterType", CharType));
		return;
	}

	MasterpieceNameText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "MasterpieceNameShow")
		, SkillRow.DescName));
}

void UAchievementsPageWidget::SetAchievementsPageAnimation()
{
	if (CollectedPieceCount == MAX_CHAR_MISSION)
	{
		bool bPuzzleComplateRewardReceived = false;
		const FCharMissionInfo* CharMissionInfo = GetHUDStore().GetCharMissionManager().GetCharMissionByCharacterType(CharType);
		if (CharMissionInfo)
		{
			if (CharMissionInfo->RUtc.IsValidIndex(MAX_CHAR_MISSION))
			{
				if (CharMissionInfo->RUtc[MAX_CHAR_MISSION] > 0)
				{
					bPuzzleComplateRewardReceived = true;
				}
			}
		}

		if (bPuzzleComplateRewardReceived)
		{
			PlayAchievementsPageAnimation(EAchievementsPageAnimType::PuzzleComplete);
		}
		else
		{
			StartPuzzleButton->SetIsEnabled(true);
			PlayAchievementsPageAnimation(EAchievementsPageAnimType::PuzzleActiveLoop, true);
		}
	}
	else
	{
		StartPuzzleButton->SetIsEnabled(false);
		PlayAchievementsPageAnimation(EAchievementsPageAnimType::Normal);
	}
}

void UAchievementsPageWidget::OnGetRewardButtonClicked(int32 Index)
{
	GetRewardButtonIndex = Index;
	GetHUDStore().GetCharMissionManager().ReqReward(CharType, Index);
}

void UAchievementsPageWidget::OnItemReceivedPopupClosed()
{
	SetInfo();
}

void UAchievementsPageWidget::OnStartPuzzleButtonClicked()
{
	UAchievementsPuzzleWidget* AchievementPuzzleWidget = GetLobbyHUD(this)->OpenAchievementPuzzlePopup();
	check(AchievementPuzzleWidget);

	AchievementPuzzleWidget->SetInfo(CharType, PuzzleShuffleNumbers);
	AchievementPuzzleWidget->OnPopupClosedDelegate.BindUObject(this
		, &UAchievementsPageWidget::OnAchievementsPuzzlePopupClosed);
}

void UAchievementsPageWidget::OnAchievementsPuzzlePopupClosed()
{
	SetPuzzleShuffleNumbers();
	SetInfo();
}

UAchievementsPuzzleWidget::UAchievementsPuzzleWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, BlankPuzzleIndex(MAX_CHAR_MISSION)
	, CharType(CharacterTypeInvalid)
	, bPuzzleComplete(false)
{
	ShuffleNumbers.Reserve(MAX_CHAR_MISSION_PUZZLE_PIECE);
}

void UAchievementsPuzzleWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AchievementsPuzzleAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimPuzzleEnabled"));
	AchievementsPuzzleAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimPuzzleDisabled"));
	AchievementsPuzzleAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimPuzzleClear"));
	check(AchievementsPuzzleAnims.Num() == static_cast<int32>(EAchievementsPuzzleAnimType::Max));

	BgImageWidgetSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("BgSwitcher"));

	ImgIllustImage = CastChecked<UImage>(GetWidgetFromName("ImgIllust"));

	BoxPuzzleWidget = CastChecked<UPuzzleBoxWidget>(GetWidgetFromName("BoxPuzzle"));
	BoxPuzzleWidget->OnPuzzlePieceButtonClickedDelegate.BindUObject(this
		, &UAchievementsPuzzleWidget::OnPuzzlePieceButtonClicked);
	BoxPuzzleWidget->OnPuzzlePieceAnimFinishedDelegate.BindUObject(this
		, &UAchievementsPuzzleWidget::OnPuzzlePieceAnimFinished);

	UButton* OKButton = CastChecked<UButton>(GetWidgetFromName("BtnOk"));
	OKButton->OnClicked.AddUniqueDynamic(this
		, &UAchievementsPuzzleWidget::OnOkButtonClicked);

	SubscribeToStore(EHSType::CharMission);
}

void UAchievementsPuzzleWidget::NativeDestruct()
{
	const int32 ChildIndex = static_cast<int32>(
		EAchievementsPuzzleImageType::UlimateSkillAnimationWidgetImage);

	UWidget* ChildWidget = BgImageWidgetSwitcher->GetWidgetAtIndex(ChildIndex);
	if (ChildWidget)
	{
		BgImageWidgetSwitcher->RemoveChildAt(ChildIndex);
	}

	Super::NativeDestruct();
}

void UAchievementsPuzzleWidget::SetInfo(const FCharacterType& InCharType
	, const TArray<int32>& InShuffleNumbers)
{
	CharType = InCharType;

	ShuffleNumbers = InShuffleNumbers;
	ShuffleNumbers.Add(INDEX_NONE);
	BlankPuzzleIndex = ShuffleNumbers.Num() - 1;

	SetBoxPuzzleInfo();
	SetPuzzleImage();

	PlayAchievementsPuzzleAnimation(EAchievementsPuzzleAnimType::PuzzleEnabled);
}

void UAchievementsPuzzleWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByAchievementsPuzzle);

	switch (Action->GetActionType())
	{
		case EHSActionType::CharMissionRewardResp:
		{
			OpenReceivedRewardItemPopup();
		}
		break;
	}
}

void UAchievementsPuzzleWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	int32 PuzzleClearIndex = static_cast<int32>(EAchievementsPuzzleAnimType::PuzzleClear);
	if (Animation == AchievementsPuzzleAnims[PuzzleClearIndex])
	{
		GetHUDStore().GetCharMissionManager().ReqReward(CharType, MAX_CHAR_MISSION);
	}
}

void UAchievementsPuzzleWidget::OpenReceivedRewardItemPopup()
{
	const UHUDStore& HUDStore = GetHUDStore();
	const FCharMissionInfo* CharMissionInfo = HUDStore.GetCharMissionManager().GetCharMissionByCharacterType(CharType);
	if (!CharMissionInfo->RUtc.IsValidIndex(MAX_CHAR_MISSION))
	{
		return;
	}

	if (CharMissionInfo->RUtc[MAX_CHAR_MISSION] == 0)
	{
		return;
	}

	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSCharMissionSetRow* CharMissionSetRow = CMS->GetCharMissionSetRowByCharType(CharType);
	if (!CharMissionSetRow)
	{
		Q6JsonLogGenie(Warning, "SetAchievementList - FCMSCharMissionSetRow does not exist."
			, Q6KV("CharType", CharType));
		return;
	}

	const FCMSLootGroupRow& LootGroupRow = CharMissionSetRow->GetLootGroup();
	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRow);

	UItemReceivedPopupWidget* ItemReceivedPopup = GetLobbyHUD(this)->OpenItemReceivedPopup();
	ItemReceivedPopup->SetMissionReceivedItem(LootDataRow);
	ItemReceivedPopup->OnPopupClosedDelegate.BindUObject(this
		, &UAchievementsPuzzleWidget::OnItemReceivedPopupClosed);
}

void UAchievementsPuzzleWidget::PlayAchievementsPuzzleAnimation(EAchievementsPuzzleAnimType Type)
{
	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (AchievementsPuzzleAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(AchievementsPuzzleAnims[AnimIndex]);
	}
}

void UAchievementsPuzzleWidget::SetBoxPuzzleInfo()
{
	BoxPuzzleWidget->ResetPuzzleSlotState();
	BoxPuzzleWidget->SetAchievementsPuzzleInfo(CharType, ShuffleNumbers);
}

void UAchievementsPuzzleWidget::SetPuzzleImage()
{
	const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(CharType);

	if (CharacterRow.Grade == EItemGrade::SSR
		|| CharacterRow.Grade == EItemGrade::SR)
	{
		if (!FindOrCreateCharacterUltimateIlustWidget(CharType))
		{
			SetCharacterIllustBGTexture(CharType, CharacterRow.Grade);
		}
	}
	else
	{
		SetCharacterIllustBGTexture(CharType, CharacterRow.Grade);
	}
}

bool UAchievementsPuzzleWidget::FindOrCreateCharacterUltimateIlustWidget(const FCharacterType& Type)
{
	const int32 ChildIndex = static_cast<int32>(
		EAchievementsPuzzleImageType::UlimateSkillAnimationWidgetImage);

	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(Type);
	if (UnitRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "SetCharacterUltimateIlustWidget - FCMSUnitRow does not exist."
			, Q6KV("FCharacterType", Type));
		return false;
	}

	const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRow = GetGameResource()
		.GetModelUltimateSkillSequenceAssetRow(UnitRow.Model);
	if (UltimateSkillSequenceAssetRow.WidgetAnimationClass.IsNull())
	{
		Q6JsonLogGenie(Display, "SetCharacterUltimateIlustWidget - WidgetAnimationClass does not exist."
			, Q6KV("UnitRow.Model", UnitRow.Model));
		return false;
	}

	if (!UltimateSkillSequenceAssetRow.WidgetAnimationClass.Get())
	{
		UltimateSkillSequenceAssetRow.WidgetAnimationClass.LoadSynchronous();
	}

	USkillAnimationWidget* UltmateSkillAnimationWidget = CreateWidget<USkillAnimationWidget>(
		GetOwningPlayer(), UltimateSkillSequenceAssetRow.WidgetAnimationClass.Get());

	if (!UltmateSkillAnimationWidget)
	{
		return false;
	}

	UWidget* ChildWidget = BgImageWidgetSwitcher->GetWidgetAtIndex(ChildIndex);
	if (ChildWidget)
	{
		BgImageWidgetSwitcher->ReplaceChildAt(ChildIndex, UltmateSkillAnimationWidget);
	}
	else
	{
		BgImageWidgetSwitcher->AddChild(UltmateSkillAnimationWidget);
	}

	BgImageWidgetSwitcher->SetActiveWidget(UltmateSkillAnimationWidget);

	UltmateSkillAnimationWidget->PlaySnapshotAnimation();

	return true;
}

void UAchievementsPuzzleWidget::SetCharacterIllustBGTexture(const FCharacterType& Type, const EItemGrade InGrade)
{
	UGameResource& GameResource = GetGameResource();
	const FCharacterAssetRow& CharacterAssetRow = GameResource.GetCharacterAssetRow(Type);

	if (InGrade == EItemGrade::SSR || InGrade == EItemGrade::SR)
	{
		ImgIllustImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIllustBGTexture());
	}
	else
	{
		ImgIllustImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);
	}

	BgImageWidgetSwitcher->SetActiveWidgetIndex(
		static_cast<int32>(EAchievementsPuzzleImageType::GeneralPuzzleImage));
}

bool UAchievementsPuzzleWidget::IsPuzzleComplete()
{
	for (int32 Index = 0; Index < MAX_CHAR_MISSION; ++Index)
	{
		check(ShuffleNumbers.IsValidIndex(Index));
		if (ShuffleNumbers[Index] != Index)
		{
			return false;
		}
	}

	bPuzzleComplete = true;
	return true;
}

void UAchievementsPuzzleWidget::OnPuzzlePieceButtonClicked(int32 Index)
{
	int32 SelectedRowIndex = Index / MAX_MISSION_BINGO_BOARD_SIZE;
	int32 SelectedColIndex = Index % MAX_MISSION_BINGO_BOARD_SIZE;

	int32 BlankRowIndex = BlankPuzzleIndex / MAX_MISSION_BINGO_BOARD_SIZE;
	int32 BlankColIndex = BlankPuzzleIndex % MAX_MISSION_BINGO_BOARD_SIZE;

	if (BlankRowIndex - SelectedRowIndex == 1)
	{
		BoxPuzzleWidget->PlayPuzzlePieceAnimation(Index, EPuzzlePieceAnimType::MoveDown);
	}
	else if (BlankRowIndex - SelectedRowIndex == -1)
	{
		BoxPuzzleWidget->PlayPuzzlePieceAnimation(Index, EPuzzlePieceAnimType::MoveUp);
	}
	else if (BlankColIndex - SelectedColIndex == 1)
	{
		BoxPuzzleWidget->PlayPuzzlePieceAnimation(Index, EPuzzlePieceAnimType::MoveRight);
	}
	else if (BlankColIndex - SelectedColIndex == -1)
	{
		BoxPuzzleWidget->PlayPuzzlePieceAnimation(Index, EPuzzlePieceAnimType::MoveLeft);
	}
	else
	{
		ensure(0);
	}
}

void UAchievementsPuzzleWidget::OnPuzzlePieceAnimFinished(int32 Index)
{
	if (bPuzzleComplete)
	{
		PlayAchievementsPuzzleAnimation(EAchievementsPuzzleAnimType::PuzzleClear);
		return;
	}

	check(ShuffleNumbers.IsValidIndex(Index));
	check(ShuffleNumbers.IsValidIndex(BlankPuzzleIndex));

	int32 ValueTemp = ShuffleNumbers[Index];
	ShuffleNumbers[Index] = ShuffleNumbers[BlankPuzzleIndex];
	ShuffleNumbers[BlankPuzzleIndex] = ValueTemp;

	if (IsPuzzleComplete())
	{
		check(ShuffleNumbers.IsValidIndex(MAX_CHAR_MISSION));
		ShuffleNumbers[MAX_CHAR_MISSION] = MAX_CHAR_MISSION;

		BoxPuzzleWidget->SetAchievementsPuzzleInfo(CharType, ShuffleNumbers);
		BoxPuzzleWidget->PlayPuzzlePieceAnimation(MAX_CHAR_MISSION, EPuzzlePieceAnimType::LastPiece);
	}
	else
	{
		BoxPuzzleWidget->SetAchievementsPuzzleInfo(CharType, ShuffleNumbers);
		BlankPuzzleIndex = Index;
	}
}

void UAchievementsPuzzleWidget::OnItemReceivedPopupClosed()
{
	PlayAchievementsPuzzleAnimation(EAchievementsPuzzleAnimType::PuzzleDisabled);
}

void UAchievementsPuzzleWidget::OnOkButtonClicked()
{
	ClosePopup();
}
