#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "UMG.h"

#include "GuidePopupWidget.generated.h"

class UTutorialCaptureWidget;

UCLASS()
class Q6_API UGuideBase : public UObject
{
	GENERATED_BODY()

public:
	virtual ~UGuideBase();

	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) { check(0); };

protected:
	void GuideSpecialWonder(const ESpecialCategory SpecialCategory, const EWonderCategory WonderCategory);
	void GuideSpecialBoss();
	void GuideWonder(const EWonderCategory WonderCategory);
};

UCLASS()
class Q6_API UGuidePopupWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UGuidePopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void ShowGuidePopupWidget(const FRewardStep& InRewardStep);

private:
	void OnGuideButtonClicked(bool bMove);

	void ShowNextReward();

	void GuideContent();

	UPROPERTY()
	UTutorialCaptureWidget* CaptureWidget;

	FRewardStep RewardStep;
};

UCLASS()
class Q6_API UGuideSepcialWonder : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideSepcialBoss : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideSepcialCharacter : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideWeeklyMission : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideCharMission : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideDailyDungeon : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideShopSell : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideTrainingCenter : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideWonder : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideWonderArtifact : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideWonderPet : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideWonderPetSkill : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideWonderVacation : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};

UCLASS()
class Q6_API UGuideSubPartySlot : public UGuideBase
{
	GENERATED_BODY()

public:
	virtual void DoAction(const FCMSContentFeatureOpenRow& Row) override;
};
