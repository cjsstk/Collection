// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "SkillWidgets.h"

#include "CombatCube.h"
#include "CombatHUD.h"
#include "CombatWidgets.h"
#include "CombatPresenter.h"
#include "GameResource.h"
#include "PetManager.h"
#include "Q6.h"
#include "Q6Enum.h"
#include "Q6GameInstance.h"
#include "Components/RichTextBlock.h"
#include "SystemConst_gen.h"
#include "Unit.h"
#include "WidgetUtil.h"

UUltimateIllustWidget::UUltimateIllustWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UUltimateIllustWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	UnitImage = CastChecked<UImage>(GetWidgetFromName("Unit"));
	ShadowImage = CastChecked<UImage>(GetWidgetFromName("Shadow"));

	IllustAnim = GetWidgetAnimationFromName(this, "AnimIllust");
	check(IllustAnim);
}

void UUltimateIllustWidget::PlaySkillAnimation(const FUltimateSkillSequenceAssetRow& SkillSequenceAssetRow)
{
	UGameResource& GameResource = GetGameResource();

	BGImage->SetVisibility(ESlateVisibility::Collapsed);
	UnitImage->SetVisibility(ESlateVisibility::Collapsed);
	ShadowImage->SetVisibility(ESlateVisibility::Collapsed);

	if (!SkillSequenceAssetRow.UnitTexture.IsNull())
	{
		UnitImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		ShadowImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		UnitImage->SetBrushFromSoftTextureWhenLoadingFinished(SkillSequenceAssetRow.UnitTexture);
		ShadowImage->SetBrushFromSoftTextureWhenLoadingFinished(SkillSequenceAssetRow.UnitTexture);

		if (!SkillSequenceAssetRow.BGTexture.IsNull())
		{
			BGImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			BGImage->SetBrushFromSoftTextureWhenLoadingFinished(SkillSequenceAssetRow.BGTexture);
		}
	}

	PlayAnimation(IllustAnim);
}

///////////////////////////////////////////////////////////////////////////////////////////
// UCommonSkillAnimationWidget

UCommonSkillAnimationWidget::UCommonSkillAnimationWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UCommonSkillAnimationWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IllustWidget = CastChecked<UUltimateIllustWidget>(GetWidgetFromName("UltimateIllust"));

	NatureAnims.Reset();
	NatureAnims.Add(GetWidgetAnimationFromName(this, "AnimColorFire"));
	NatureAnims.Add(GetWidgetAnimationFromName(this, "AnimColorWater"));
	NatureAnims.Add(GetWidgetAnimationFromName(this, "AnimColorWind"));
	NatureAnims.Add(GetWidgetAnimationFromName(this, "AnimColorLight"));
	NatureAnims.Add(GetWidgetAnimationFromName(this, "AnimColorDark"));
}

void UCommonSkillAnimationWidget::PlaySkillAnimation(int32 SkillType, const FUltimateSkillSequenceAssetRow& SkillSequenceAssetRow)
{
	Super::PlaySkillAnimation(SkillType, SkillSequenceAssetRow);

	IllustWidget->PlaySkillAnimation(SkillSequenceAssetRow);

	for (const FName& AnimationName : SkillSequenceAssetRow.OptionalWidgetAnimationNames)
	{
		UWidgetAnimation* WidgetAnimation = GetWidgetAnimationFromName(this, AnimationName);
		if (!ensure(WidgetAnimation))
		{
			Q6JsonLogRoze(Warning, "UCommonSkillAnimationWidget::PlaySkillAnimation - Not found animation",
				Q6KV("SkillType", SkillType), Q6KV("AnimationName", AnimationName.ToString()));
			continue;
		}

		if (NatureAnims.Contains(WidgetAnimation))
		{
			Q6JsonLogRoze(Warning, "Nature animation is not optional", Q6KV("AnimationName", AnimationName.ToString()));
			continue;
		}

		PlayAnimation(WidgetAnimation);
	}
}

void UCommonSkillAnimationWidget::StopSkillAnimation()
{
	Super::StopSkillAnimation();

	IllustWidget->StopAllAnimations();
}

void UCommonSkillAnimationWidget::PlayNatureAnimation(ENatureType NatureType)
{
	if (!IsInViewport())
	{
		Q6JsonLogRoze(Error, "Call PlaySkillAnimation() function first");
		return;
	}

	if (NatureAnims.IsValidIndex((int32)NatureType)
		&& FontOutlineColors.IsValidIndex((int32)NatureType))
	{
		FSlateFontInfo& FontInfo = SkillNameText->Font;
		FontInfo.OutlineSettings.OutlineColor = FontOutlineColors[(int32)NatureType];
		SkillNameText->SetFont(FontInfo);

		PlayAnimation(NatureAnims[(int32)NatureType]);
	}
	else
	{
		Q6JsonLogRoze(Warning, "Not found nature animation or font color", Q6KV("NatureType", (int32)NatureType));
	}
}


///////////////////////////////////////////////////////////////////////////////////////////
// USkillAnimationWidget

USkillAnimationWidget::USkillAnimationWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void USkillAnimationWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SkillName"));
	StartSkillAnim = GetWidgetAnimationFromName(this, "AnimSkillStart");
	check(StartSkillAnim);

	SnapshotAnim = GetNullableWidgetAnimationFromName(this, "AnimSnapshot");
}

void USkillAnimationWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == StartSkillAnim)
	{
		SkillAnimFinishedDelegate.ExecuteIfBound();
		RemoveFromParent();
		return;
	}

	if (Animation == CardStartAnim)
	{
		UWidgetAnimation* CardLoopAnim = GetWidgetAnimationFromName(this, "AnimCardLoop");
		PlayAnimation(CardLoopAnim, 0.f, 0);
		return;
	}
}

void USkillAnimationWidget::PlaySkillAnimation(int32 SkillType, const FUltimateSkillSequenceAssetRow& SkillAssetRow)
{
	ensure(SkillType != SkillTypeInvalid.x);

	AddToViewport(ZORDER_SKILL_ANIMATION);

	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillType);
	SkillNameText->SetText(SkillRow.DescName);

	PlayAnimation(StartSkillAnim);
}

void USkillAnimationWidget::PlayCardAnimation(bool bSnapshop)
{
	FName AnimName = bSnapshop ? "AnimSnapshot" : "AnimCardStart";

	UWidgetAnimation* CardAnimation = GetWidgetAnimationFromName(this, AnimName);
	PlayAnimation(CardAnimation);
}

void USkillAnimationWidget::PlaySnapshotAnimation()
{
	if (SnapshotAnim)
	{
		PlayAnimation(SnapshotAnim);
	}
}

void USkillAnimationWidget::StopSkillAnimation()
{
	StopAllAnimations();
}

///////////////////////////////////////////////////////////////////////////////////////////
// USupportSkillAnimationWidget

USupportSkillAnimationWidget::USupportSkillAnimationWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void USupportSkillAnimationWidget::NativeConstruct()
{
	Super::NativeConstruct();

	HelpAnim = GetWidgetAnimationFromName(this, "HelpAppear");
	check(HelpAnim);

	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SkillName"));
	SkillEffectText = CastChecked<UTextBlock>(GetWidgetFromName("SkillEffect"));
	SkillPortraitImage = CastChecked<UImage>(GetWidgetFromName("Portrait"));
	BonusIcon = CastChecked<UImage>(GetWidgetFromName("Bonus"));
}

void USupportSkillAnimationWidget::PlayHelpSkillAnimation(int32 ModelType, int32 SkillType, int32 SupporterBonus)
{
	AddToViewport(ZORDER_SKILL_ANIMATION);

	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(ModelType);
	SkillPortraitImage->SetBrushFromSoftTextureWhenLoadingFinished(SkillAssetRow.SupportPortraitTexture);

	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillType);
	SkillNameText->SetText(SkillRow.DescName);

	const TArray<const FCMSSkillEffectRow*>& SkillEffects = SkillRow.GetSkillEffect();
	if (ensure(SkillEffects.Num() > 0))
	{
		SkillEffectText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		SkillEffectText->SetText(SkillEffects[0]->Desc);
	}
	else
	{
		SkillEffectText->SetVisibility(ESlateVisibility::Collapsed);
	}

	// Set Bonus

	if (SupporterBonus > 0)
	{
		BonusIcon->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		BonusIcon->SetVisibility(ESlateVisibility::Collapsed);
	}

	PlayAnimation(HelpAnim);

}

void USupportSkillAnimationWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	RemoveFromParent();

	AnimationFinishedDelegate.ExecuteIfBound();
}

UArtifactAnimationWidget::UArtifactAnimationWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UArtifactAnimationWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FreyaImage = CastChecked<UImage>(GetWidgetFromName("Freya"));
	SkillCategory = CastChecked<UTextBlock>(GetWidgetFromName("SkillCategory"));
}

void UArtifactAnimationWidget::PlayArtifactAnimation(int32 InSkillType, FCCUnitId InTargetUnitId)
{
	SkillType = InSkillType;
	TargetUnitId = InTargetUnitId;

	SkillAnimFinishedDelegate.BindUObject(this, &UArtifactAnimationWidget::OnSkillAnimFinished);

	static FUltimateSkillSequenceAssetRow DummyAssetRow;
	Super::PlaySkillAnimation(SkillType, DummyAssetRow);

	int32 ArtifactIndex = GetCMS()->GetArtifactIndex(SkillType);
	if (ArtifactIndex != INDEX_NONE)
	{
		const FArtifactIcon& Icon = GetUIResource().GetArtifactIcon(ArtifactIndex);
		FreyaImage->SetBrushFromSoftTextureWhenLoadingFinished(Icon.AnimationTexture);

		SkillCategory->SetText(Q6Util::GetLocalizedText("Combat", "FreyaArtifact"));
	}
	else if (SkillType == SystemConst::Q6_GEM_REBIRTH_SKILL_ID)
	{
		FreyaImage->SetBrushFromSoftTextureWhenLoadingFinished(GetUIResource().GetGemRebirthTexture());

		SkillCategory->SetText(Q6Util::GetLocalizedText("Combat", "FreyaOffering"));
	}
	else
	{
		Q6JsonLogZagal(Error, "PlayArtifactAnimation - Unknown SkillType", Q6KV("SkillType", SkillType));
	}
}

void UArtifactAnimationWidget::OnSkillAnimFinished()
{
	ArtifactAnimFinishedDelegate.ExecuteIfBound(SkillType, TargetUnitId);
}

///////////////////////////////////////////////////////////////////////////////////////////
// CombatPetButtonWidget

void UCombatPetButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NormalAnim = GetWidgetAnimationFromName(this, "AnimPetNormal");
	DisabledAnim = GetWidgetAnimationFromName(this, "AnimPetDisabled");
	StartAnim = GetWidgetAnimationFromName(this, "AnimPetStart");
	EndAnim = GetWidgetAnimationFromName(this, "AnimPetEnd");

	SkillStateWidget = CastChecked<UCombatTurnSkillStateWidget>(GetWidgetFromName("SkillState"));

	UButton* OpenButton = CastChecked<UButton>(GetWidgetFromName("Open"));
	OpenButton->OnClicked.AddUniqueDynamic(this, &UCombatPetButtonWidget::OnOpenButtonClicked);
}

void UCombatPetButtonWidget::Init(FPetType InPetType, const TArray<FSkillState>& InSkillStates)
{
	PetType = InPetType;

	SkillStateWidget->InitPet(PetType, InSkillStates);
}

void UCombatPetButtonWidget::UpdateSkillStates()
{
	const FMasterState& Master = GetCheckedCombatPresenter(this)->GetAllyMaster();
	SkillStateWidget->SetSkillStates(Master.Pets);
}

void UCombatPetButtonWidget::SetPhase(ECPTurnPhase InPhase)
{
	if (!HasValidPet())
	{
		return;
	}

	switch (InPhase)
	{
		case ECPTurnPhase::Steady:
			PlayStartAnimation();
			// fall-through
		case ECPTurnPhase::Attack:
			SetSkillEnabled(true);
			SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			break;
		case ECPTurnPhase::OppAttack:
			PlayEndAnimation();
			break;
		default:
			SetVisibility(ESlateVisibility::Collapsed);
			break;
	}
}

void UCombatPetButtonWidget::SetSkillEnabled(bool bInEnabled)
{
	PlayAnimation(bInEnabled ? NormalAnim : DisabledAnim);
}

void UCombatPetButtonWidget::OnOpenButtonClicked()
{
	OnOpenButtonClickedDelegate.ExecuteIfBound();
}

///////////////////////////////////////////////////////////////////////////////////////////
// CombatWonderSkillButtonWidget

void UCombatWonderSkillButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UCombatWonderSkillButtonWidget::OnSelectButtonClicked);

	ArtifactSkillIconImage = CastChecked<UImage>(GetWidgetFromName("ArtifactSkillIcon"));
	ArtifactSkillCooldownText = CastChecked<UTextBlock>(GetWidgetFromName("TextArtifactSkillCooldown"));

	PetSkillIconImage = CastChecked<UImage>(GetWidgetFromName("PetSkillIcon"));
	PetSkillCooldownText = CastChecked<UTextBlock>(GetWidgetFromName("TextPetSkillCooldown"));

	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("TextSkillLevel"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("TextSkillName"));
	SkillInfoText = CastChecked<URichTextBlock>(GetWidgetFromName("TextSkillInfo"));
	CooltimeText = CastChecked<URichTextBlock>(GetWidgetFromName("TextCooltime"));

	EnabledAnim = GetWidgetAnimationFromName(this, "AnimEnabled");
	DisabledAnim = GetWidgetAnimationFromName(this, "AnimDisabled");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimLocked");
	PetStateAnim = GetWidgetAnimationFromName(this, "AnimStatePet");
	ArtifactStateAnim = GetWidgetAnimationFromName(this, "AnimStateArtifact");

	SkillId = CCSkillIdInvalid;
	SkillType = 0;
	SkillCategory = ESkillCategory::Artifact;
	State = EWonderSkillState::Enabled;
	TargetUnitId = CCUnitIdInvalid;
}

void UCombatWonderSkillButtonWidget::SetPetSkill(FPetType PetType, const FSkillState& SkillState)
{
	SkillCategory = ESkillCategory::Pet;

	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetType);
	int32 PetSkillIndex = GetCheckedCombatPresenter(this)->GetPetSkillIndex(SkillState.SkillId);
	if (PetAssetRow.SkillIcons.IsValidIndex(PetSkillIndex))
	{
		PetSkillIconImage->SetBrush(PetAssetRow.SkillIcons[PetSkillIndex]);
	}

	PetSkillCooldownText->SetText(FText::AsNumber(SkillState.Cooldown));
	CooltimeText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "PetSkillCooltime"), SkillState.CoolTime));

	PlayAnimation(PetStateAnim);
	SetSkillInternal(SkillState);
}

void UCombatWonderSkillButtonWidget::SetArtifactSkill(const FSkillState& SkillState)
{
	SkillCategory = ESkillCategory::Artifact;

	int32 ArtifactIndex = GetCMS()->GetArtifactIndex(SkillState.SkillType);
	const FArtifactIcon& Icon = GetUIResource().GetArtifactIcon(ArtifactIndex);
	ArtifactSkillIconImage->SetBrush(Icon.CombatBrush);

	CooltimeText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "ReuseTimeLeft"), SkillState.CoolTime));

	PlayAnimation(ArtifactStateAnim);
	SetSkillInternal(SkillState);
}

void UCombatWonderSkillButtonWidget::SetSkillInternal(const FSkillState& SkillState)
{
	SkillId = SkillState.SkillId;
	SkillType = SkillState.SkillType;

	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillType);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), SkillState.Level));
	NameText->SetText(SkillRow.DescName);
	SkillInfoText->SetText(BuildToolTipDesc(SkillRow.Type, SkillState.Level, SkillRow.SkillCategory));

	if (SkillState.Level <= 0)
	{
		PlayAnimation(LockedAnim);
		State = EWonderSkillState::Locked;
	}
	else if (SkillState.Cooldown)
	{
		PlayAnimation(DisabledAnim);
		State = EWonderSkillState::Disabled;
	}
	else
	{
		PlayAnimation(EnabledAnim);
		State = EWonderSkillState::Enabled;
	}
}

void UCombatWonderSkillButtonWidget::ShowReasonNotification()
{
	if (State == EWonderSkillState::Disabled)
	{
		GetCheckedCombatHUD(this)->ShowNotification(
			ENotificationType::Short,
			Q6Util::GetLocalizedText("Combat", "NotUseRequireCooltimeReset"));
		return;
	}

	// is locked

	if (SkillCategory == ESkillCategory::Artifact)
	{
		if (SkillType == TempleConst::Q6_ARTIFACT3_SKILL_ID)
		{
			GetCheckedCombatHUD(this)->ShowNotification(
				ENotificationType::Short,
				Q6Util::GetLocalizedText("Combat", "NotUseRequireFreyaOpen"));
		}
		else
		{
			const FCMSSagaRow* SagaRow = GetCMS()->GetArtifactOpenConditionSagaRow(FSkillType(SkillType));
			if (!SagaRow)
			{
				return;
			}

			GetCheckedCombatHUD(this)->ShowNotification(
				ENotificationType::Short,
				FText::Format(Q6Util::GetLocalizedText("Lobby", "LackTempleNotAcquire"),
					SagaRow->DescName));
		}

		return;
	}
	else if (SkillCategory == ESkillCategory::Pet)
	{
		const FCMSSagaRow* SagaRow = GetCMS()->GetPetSkillOpenConditionSagaRow(FSkillType(SkillType));
		if (!SagaRow)
		{
			return;
		}

		GetCheckedCombatHUD(this)->ShowNotification(
			ENotificationType::Short,
			FText::Format(Q6Util::GetLocalizedText("Lobby", "LackPetParkNotAcquire"),
				SagaRow->DescName));
		return;
	}

	Q6JsonLogRoze(Error, "UCombatWonderSkillButtonWidget::ShowReasonNotification - invalid skill category", Q6KV("SkillCategory", (int32)SkillCategory));
	return;
}

void UCombatWonderSkillButtonWidget::SetTarget(FCCUnitId InTargetId)
{
	TargetUnitId = InTargetId;
}

void UCombatWonderSkillButtonWidget::OnSelectButtonClicked()
{
	if (State != EWonderSkillState::Enabled)
	{
		ShowReasonNotification();
		return;
	}

	OnWonderSkillSelectedDelegate.ExecuteIfBound(SkillId, SkillType, TargetUnitId, SkillCategory);
}

///////////////////////////////////////////////////////////////////////////////////////////
// CombatWonderSkillUsePopupWidget

void UCombatWonderSkillUsePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextTitle"));

	WonderSkillWidgets.Reset();
	FString WidgetName;
	UCombatWonderSkillButtonWidget* WonderSkillButtonWidget;
	for (int32 n = 1; n <= 3; ++n)
	{
		WidgetName = FString::Printf(TEXT("WonderSkill%d"), n);
		WonderSkillButtonWidget = CastChecked<UCombatWonderSkillButtonWidget>(GetWidgetFromName(*WidgetName));
		WonderSkillButtonWidget->OnWonderSkillSelectedDelegate.BindUObject(this, &UCombatWonderSkillUsePopupWidget::OnSelectButtonClicked);
		WonderSkillWidgets.Add(WonderSkillButtonWidget);
	}

	UButton* CancelButton = CastChecked<UButton>(GetWidgetFromName("Cancel"));
	CancelButton->OnClicked.AddUniqueDynamic(this, &UCombatWonderSkillUsePopupWidget::ClosePopup);

	SubscribeToStore(EHSType::Temple);
}

void UCombatWonderSkillUsePopupWidget::SetPetSkills(FPetType PetType, const TArray<FSkillState>& PetSkills, FCCUnitId InTargetUnitId)
{
	TitleText->SetText(Q6Util::GetLocalizedText("Combat", "SelectPetSkillToUse"));

	for (int32 i = 0; i < WonderSkillWidgets.Num(); ++i)
	{
		if (!PetSkills.IsValidIndex(i))
		{
			WonderSkillWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		WonderSkillWidgets[i]->SetPetSkill(PetType, PetSkills[i]);
		WonderSkillWidgets[i]->SetTarget(InTargetUnitId);
		WonderSkillWidgets[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void UCombatWonderSkillUsePopupWidget::SetArtifactSkills(const TArray<FSkillState>& ArtifactSkills, FCCUnitId InTargetUnitId)
{
	TitleText->SetText(Q6Util::GetLocalizedText("Combat", "SelectArtifactToUse"));

	for (int32 i = 0; i < WonderSkillWidgets.Num(); ++i)
	{
		if (!ArtifactSkills.IsValidIndex(i) || i == CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX)
		{
			WonderSkillWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		WonderSkillWidgets[i]->SetArtifactSkill(ArtifactSkills[i]);
		WonderSkillWidgets[i]->SetTarget(InTargetUnitId);
		WonderSkillWidgets[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void UCombatWonderSkillUsePopupWidget::OnSelectButtonClicked(FCCSkillId SkillId, int32 SkillType, FCCUnitId TargetUnitId, ESkillCategory SkillCategory)
{
	switch (SkillCategory)
	{
		case ESkillCategory::Artifact:
			GetCheckedCombatHUD(this)->PlayArtifactAnimation(SkillType, TargetUnitId);
			break;
		case ESkillCategory::Pet:
			{
				ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
				ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());
				if (TurnPhase == ECPTurnPhase::Steady)
				{
					GetCheckedCombatCube(this)->ProceedToNextTurn();
				}
				GetCheckedCombatCube(this)->UsePet(TargetUnitId, SkillId);
			}
			break;
		default:
			break;
	}

	ClosePopup();
}

///////////////////////////////////////////////////////////////////////////////////////////
// UltimateSkipWidget

void UUltimateSkipWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* SkipButton = CastChecked<UButton>(GetWidgetFromName("BtnSkip"));
	SkipButton->OnClicked.AddUniqueDynamic(this, &UUltimateSkipWidget::OnSkipButtonClicked);
}

void UUltimateSkipWidget::OnSkipButtonClicked()
{
	OnSkipDelegate.ExecuteIfBound();
}

///////////////////////////////////////////////////////////////////////////////////////////
// SkillNoteCardWidget

void USkillNoteCardWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AttackCardBorder = CastChecked<UBorder>(GetWidgetFromName("AttackCard"));
	FrameImage = CastChecked<UImage>(GetWidgetFromName("AttackCardFrame"));
}

void USkillNoteCardWidget::SetCharacter(int32 ModelType, ESkillNote SkillNote)
{
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(ModelType);
	AttackCardBorder->SetBrushFromTexture(CharacterAssetRow.CombatIconTexture.LoadSynchronous());

	if (NoteBrushes.IsValidIndex((int32)SkillNote))
	{
		FrameImage->SetBrush(NoteBrushes[(int32)SkillNote]);
	}
}
