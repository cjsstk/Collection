// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CharacterWidgets.h"

#include "Animation/WidgetAnimation.h"

#include "CMSTable.h"
#include "CharacterDetailWidgets.h"
#include "CharacterManager.h"
#include "CommonWidgets.h"
#include "Formula.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "Q6.h"
#include "Q6Define.h"
#include "Q6GameInstance.h"
#include "Q6UIDefine.h"
#include "SkillWidgetUtil.h"
#include "SystemConstHelper.h"

USkillIconWidget::USkillIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void USkillIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
}

void USkillIconWidget::SetSkill(const FSlateBrush& SkillIcon, int32 Level)
{
	IconImage->SetBrush(SkillIcon);
	LevelText->SetText(FText::AsNumber(Level));
}

UTurnSkillIconWidget::UTurnSkillIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UTurnSkillIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	SkillLevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	SkillLevelLabel = CastChecked<UTextBlock>(GetWidgetFromName("LevelLabel"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UTurnSkillIconWidget::OnSelectButtonClicked);

	SelectAnim = GetWidgetAnimationFromName(this, "AnimSelect");
	check(SelectAnim);
	UnselectAnim = GetWidgetAnimationFromName(this, "AnimUnselect");
	check(UnselectAnim);
	LockedAnim = GetWidgetAnimationFromName(this, "AnimLocked");
	check(LockedAnim);
	OpenedAnim = GetWidgetAnimationFromName(this, "AnimOpened");
	check(OpenedAnim);
}

void UTurnSkillIconWidget::SetSkill(const FSlateBrush& SkillIcon, int32 InSkillLevel /*= 0*/)
{
	SkillLevelText->SetText(FText::AsNumber(InSkillLevel));

	if (InSkillLevel > 0)
	{
		SkillLevelLabel->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		SkillLevelText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		SetLocked(false);
	}
	else
	{
		SkillLevelLabel->SetVisibility(ESlateVisibility::Collapsed);
		SkillLevelText->SetVisibility(ESlateVisibility::Collapsed);
		SetLocked(true);
	}

	IconImage->SetBrush(SkillIcon);
}

void UTurnSkillIconWidget::SetSelected(bool bSelected)
{
	PlayAnimation(bSelected ? SelectAnim : UnselectAnim);
}

void UTurnSkillIconWidget::SetLocked(bool bInLocked)
{
	bLocked = bInLocked;
	PlayAnimation(bLocked ? LockedAnim : OpenedAnim);
}

void UTurnSkillIconWidget::SetNewMarkVisibility(ESlateVisibility InVisibility)
{
	NewMarkImage->SetVisibility(InVisibility);
}

void UTurnSkillIconWidget::OnSelectButtonClicked()
{
	OnSelectButtonClickedDelegate.ExecuteIfBound();
}


UItemLabelWidget::UItemLabelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


void UItemLabelWidget::NativeConstruct()
{
	Super::NativeConstruct();

	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	StarBarWidget = CastChecked<UStarBarWidget>(GetWidgetFromName("StarBar"));
	OptionImage = CastChecked<UImage>(GetWidgetFromName("Option"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
};

void UItemLabelWidget::SetCharacter(const FText& Name, EItemGrade Grade, ENatureType NatureType, int32 Star, int32 Moon)
{
	SetItem(Name, Grade, Star, Moon);

	OptionImage->SetBrush(GetUIResource().GetNatureTypeIcon(NatureType));
}

void UItemLabelWidget::SetEquip(const FText& Name, EItemGrade Grade, int32 Star, int32 Tier)
{
	SetItem(Name, Grade, Star);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(Tier);
	OptionImage->SetBrush(TierBrush);
}

void UItemLabelWidget::SetItem(const FText& Name, EItemGrade Grade, int32 Star, int32 Moon)
{
	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	StarBarWidget->SetMoonStars(Moon, Star);
	NameText->SetText(Name);
}

UCharacterLabelWidget::UCharacterLabelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UCharacterLabelWidget::NativeConstruct()
{
	Super::NativeConstruct();

	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	NatureImage = CastChecked<UImage>(GetWidgetFromName("Nature"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	NickNameText = CastChecked<UTextBlock>(GetWidgetFromName("NickName"));
}

void UCharacterLabelWidget::SetCharacter(const FCMSCharacterRow& CharacterRow)
{
	const UUIResource& UIResource = GetUIResource();
	const UCMS* CMS = GetCMS();

	const FItemGrade& ItemGrade = UIResource.GetItemGrade(CharacterRow.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	ENatureType NatureType = CMS->GetNatureType(CharacterRow.CmsType());
	const FSlateBrush& NatureBrush = UIResource.GetNatureTypeIcon(NatureType);
	NatureImage->SetBrush(NatureBrush);

	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterRow.CmsType());
	NameText->SetText(UnitRow.DescName);
	NickNameText->SetText(FText::GetEmpty());	// Not implemented yet
}

UStatWidget::UStatWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


void UStatWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	ValueText = CastChecked<UTextBlock>(GetWidgetFromName("Value"));
	ResultValueText = CastChecked<UTextBlock>(GetWidgetFromName("ResultValue"));
	ResultBox = CastChecked<UHorizontalBox>(GetWidgetFromName("Result"));
}

void UStatWidget::SetEmpty()
{
	SetVisibility(ESlateVisibility::Collapsed);
}

void UStatWidget::SetStat(EUnitAttribute Attr, int64 Value)
{
	SetStat(Attr, Value, Value);	// result value not different
}

void UStatWidget::SetStat(EUnitAttribute Attr, int64 Value, int64 ResultValue)
{
	if ((Value == 0) && (ResultValue == 0))
	{
		// No have value
		SetEmpty();
		return;
	}

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	const FCMSUnitAttributeRow& AttrRow = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType((int32)Attr + 1));
	NameText->SetText(AttrRow.Desc);

	ValueText->SetText(FText::FromString(FString::FormatAsNumber(Value)));

	if (Value != ResultValue)
	{
		ResultValueText->SetText(FText::FromString(FString::FormatAsNumber(ResultValue)));
		ResultBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		ResultBox->SetVisibility(ESlateVisibility::Collapsed);
	}
}


UUpgradeStatWidget::UUpgradeStatWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}


void UUpgradeStatWidget::NativeConstruct()
{
	Super::NativeConstruct();

	LevelWidget = CastChecked<UItemLevelWidget>(GetWidgetFromName("ItemLevel"));
	XPBar = CastChecked<UProgressBar>(GetWidgetFromName("XP"));
	ResultXPBar = CastChecked<UProgressBar>(GetWidgetFromName("ResultXP"));
	RemainXPText = CastChecked<UTextBlock>(GetWidgetFromName("RemainXP"));
	GainXPText = CastChecked<UTextBlock>(GetWidgetFromName("GainXP"));

	HpStatWidget = CastChecked<UStatWidget>(GetWidgetFromName("HpStat"));
	AtkStatWidget = CastChecked<UStatWidget>(GetWidgetFromName("AtkStat"));
	DefStatWidget = CastChecked<UStatWidget>(GetWidgetFromName("DefStat"));

	GainXPBox = CastChecked<UWidget>(GetWidgetFromName("GainXPBox"));
}

void UUpgradeStatWidget::SetCharacter(const FCharacterInfo& CharacterInfo, int32 GainXp)
{
	SetCharacter(CharacterInfo.Type, CharacterInfo.Grade, CharacterInfo.Star, CharacterInfo.Moon, CharacterInfo.Xp, GainXp);

	GainXPBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UUpgradeStatWidget::SetCharacterPromote(const FCharacterInfo& CharacterInfo)
{
	UCMS* CMS = GetCMS();
	const FCMSCharacterXpRow& XpRow = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(CharacterInfo.Level));

	SetCharacter(CharacterInfo.Type, CharacterInfo.Grade, CharacterInfo.Star + 1, CharacterInfo.Moon, CharacterInfo.Xp);
	LevelWidget->PlayPromoteAnim();

	GainXPBox->SetVisibility(ESlateVisibility::Collapsed);
}

void UUpgradeStatWidget::SetRelicPromote(const FRelicInfo& RelicInfo)
{
	UCMS* CMS = GetCMS();
	const FCMSItemXpRow& XpRow = CMS->GetItemXpRowOrDummy(FItemXpType(RelicInfo.Level));

	SetRelic(RelicInfo.Type, RelicInfo.Grade, RelicInfo.Star + 1, RelicInfo.Xp, RelicInfo.Tier, 0,  0);
	LevelWidget->PlayPromoteAnim();

	GainXPBox->SetVisibility(ESlateVisibility::Collapsed);
}

void UUpgradeStatWidget::SetSculpturePromote(const FSculptureInfo& SculptureInfo)
{
	UCMS* CMS = GetCMS();
	const FCMSItemXpRow& XpRow = CMS->GetItemXpRowOrDummy(FItemXpType(SculptureInfo.Level));

	SetSculpture(SculptureInfo.Type, SculptureInfo.Grade, SculptureInfo.Star + 1, SculptureInfo.Xp, SculptureInfo.Tier, 0, 0);
	LevelWidget->PlayPromoteAnim();
}

void UUpgradeStatWidget::SetCharacterEvolute(const FCharacterInfo& CharacterInfo)
{
	UCMS* CMS = GetCMS();
	const FCMSCharacterXpRow& XpRow = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(CharacterInfo.Level));

	int32 UpgradeMoon = SystemConstHelper::GetUpgradeTargetMoon(CharacterInfo.Grade, CharacterInfo.Moon);
	int32 UpgradeStar = SystemConstHelper::GetCharacterStarByMoon(CharacterInfo.Grade, UpgradeMoon);
	SetCharacter(CharacterInfo.Type, CharacterInfo.Grade, UpgradeStar, UpgradeMoon, CharacterInfo.Xp);
	LevelWidget->PlayPromoteAnim();

	GainXPBox->SetVisibility(ESlateVisibility::Collapsed);
}

void UUpgradeStatWidget::PlayLevelUpAnimation(bool bLevelUp)
{
	LevelWidget->PlayLevelUpAnimation(bLevelUp);
}

void UUpgradeStatWidget::SetVisibleStar(bool bInVisible)
{
	LevelWidget->SetVisibleStar(bInVisible);
}

void UUpgradeStatWidget::SetCharacter(FCharacterType CharacterType, EItemGrade ItemGrade, int32 Star, int32 Moon, int32 CurXp, int32 GainXp)
{
	UCMS* CMS = GetCMS();

	int32 Level = CMS->GetCharacterLevelFromXP(CurXp);
	int32 MaxLevel = SystemConstHelper::GetCharacterMaxLevel(Star, Moon);
	int32 UpgradedLevel = FMath::Min(CMS->GetCharacterLevelFromXP(CurXp + GainXp), MaxLevel);
	LevelWidget->SetCharacter(UpgradedLevel, Star, Moon);

	const FCMSCharacterXpRow& XpRow = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(FMath::Min(Level + 1, MaxLevel)));
	const FCMSCharacterXpRow& UpgradedXpRow = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(FMath::Min(UpgradedLevel + 1, MaxLevel)));
	SetAddXp(CurXp, XpRow.Req, XpRow.Acc, UpgradedXpRow.Req, UpgradedXpRow.Acc, GainXp, (Level < UpgradedLevel));

	SetCharacterStat(CharacterType, Moon, Level, UpgradedLevel);
}

void UUpgradeStatWidget::SetCharacterResult(const FCharacterInfo& CharacterInfo, int32 GainXp)
{
	UCMS* CMS = GetCMS();

	int32 Level = CMS->GetCharacterLevelFromXP(CharacterInfo.Xp);
	int32 MaxLevel = SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon);
	int32 UpgradedLevel = FMath::Min(CMS->GetCharacterLevelFromXP(CharacterInfo.Xp + GainXp), MaxLevel);
	LevelWidget->SetCharacter(UpgradedLevel, CharacterInfo.Star, CharacterInfo.Moon);

	const FCMSCharacterXpRow& UpgradedXpRow = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(FMath::Min(UpgradedLevel + 1, MaxLevel)));
	SetResultXp(CharacterInfo.Xp + GainXp, UpgradedXpRow.Req, UpgradedXpRow.Acc, (UpgradedLevel > Level));

	SetCharacterStat(CharacterInfo.Type, CharacterInfo.Moon, Level, UpgradedLevel);

	GainXPBox->SetVisibility(ESlateVisibility::Collapsed);
}

void UUpgradeStatWidget::SetRelic(const FRelicInfo& RelicInfo, int32 GainXp, int32 AddedTier)
{
	SetRelic(RelicInfo.Type, RelicInfo.Grade, RelicInfo.Star, RelicInfo.Xp, RelicInfo.Tier, GainXp, AddedTier);

	GainXPBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UUpgradeStatWidget::SetRelic(FRelicType RelicType, EItemGrade ItemGrade, int32 Star, int32 CurXp, int32 CurTier, int32 GainXp, int32 AddedTier)
{
	UCMS* CMS = GetCMS();

	int32 Level = CMS->GetEquipLevelFromXP(CurXp);
	int32 MaxLevel = SystemConstHelper::GetEquipMaxLevel(Star);
	int32 UpgradedLevel = FMath::Min(CMS->GetEquipLevelFromXP(CurXp + GainXp), MaxLevel);
	LevelWidget->SetEquip(UpgradedLevel, Star);

	const FCMSItemXpRow& XpRow = CMS->GetItemXpRowOrDummy(FItemXpType(FMath::Min(Level + 1, MaxLevel)));
	const FCMSItemXpRow& UpgradedXpRow = CMS->GetItemXpRowOrDummy(FItemXpType(FMath::Min(UpgradedLevel + 1, MaxLevel)));
	SetAddXp(CurXp, XpRow.Req, XpRow.Acc, UpgradedXpRow.Req, UpgradedXpRow.Acc, GainXp, (Level < UpgradedLevel));

	SetRelicStat(RelicType, Level, UpgradedLevel, CurTier, FMath::Min(CurTier + AddedTier, CombatCubeConst::Q6_MAX_TIER));
}

void UUpgradeStatWidget::SetRelicResult(const FRelicInfo& RelicInfo, int32 GainXp, int32 AddedTier)
{
	UCMS* CMS = GetCMS();

	int32 Level = CMS->GetEquipLevelFromXP(RelicInfo.Xp);
	int32 MaxLevel = SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star);
	int32 UpgradedLevel = FMath::Min(CMS->GetEquipLevelFromXP(RelicInfo.Xp + GainXp), MaxLevel);
	LevelWidget->SetEquip(UpgradedLevel, RelicInfo.Star);

	const FCMSItemXpRow& UpgradedXpRow = CMS->GetItemXpRowOrDummy(FItemXpType(FMath::Min(UpgradedLevel + 1, MaxLevel)));
	SetResultXp(RelicInfo.Xp + GainXp, UpgradedXpRow.Req, UpgradedXpRow.Acc, (UpgradedLevel > Level));

	SetRelicStat(RelicInfo.Type, Level, UpgradedLevel, RelicInfo.Tier, FMath::Min(RelicInfo.Tier + AddedTier, CombatCubeConst::Q6_MAX_TIER));

	GainXPBox->SetVisibility(ESlateVisibility::Collapsed);
}

void UUpgradeStatWidget::SetSculpture(const FSculptureInfo& SculptureInfo, int32 GainXp, int32 AddedTier)
{
	SetSculpture(SculptureInfo.Type, SculptureInfo.Grade, SculptureInfo.Star, SculptureInfo.Xp, SculptureInfo.Tier, GainXp, AddedTier);

	GainXPBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UUpgradeStatWidget::SetSculpture(FSculptureType SculptureType, EItemGrade ItemGrade, int32 Star, int32 CurXp, int32 CurTier, int32 GainXp, int32 AddedTier)
{
	UCMS* CMS = GetCMS();

	int32 Level = CMS->GetEquipLevelFromXP(CurXp);
	int32 MaxLevel = SystemConstHelper::GetEquipMaxLevel(Star);
	int32 UpgradedLevel = FMath::Min(CMS->GetEquipLevelFromXP(CurXp + GainXp), MaxLevel);
	LevelWidget->SetEquip(UpgradedLevel, Star);

	const FCMSItemXpRow& XpRow = CMS->GetItemXpRowOrDummy(FItemXpType(FMath::Min(Level + 1, MaxLevel)));
	const FCMSItemXpRow& UpgradedXpRow = CMS->GetItemXpRowOrDummy(FItemXpType(FMath::Min(UpgradedLevel + 1, MaxLevel)));
	SetAddXp(CurXp, XpRow.Req, XpRow.Acc, UpgradedXpRow.Req, UpgradedXpRow.Acc, GainXp, (Level < UpgradedLevel));

	SetSculptureStat(SculptureType, Level, UpgradedLevel, CurTier, FMath::Min(CurTier + AddedTier, CombatCubeConst::Q6_MAX_TIER));
}

void UUpgradeStatWidget::SetSculptureResult(const FSculptureInfo& SculptureInfo, int32 GainXp, int32 AddedTier)
{
	UCMS* CMS = GetCMS();

	int32 Level = CMS->GetEquipLevelFromXP(SculptureInfo.Xp);
	int32 MaxLevel = SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star);
	int32 UpgradedLevel = FMath::Min(CMS->GetEquipLevelFromXP(SculptureInfo.Xp + GainXp), MaxLevel);
	LevelWidget->SetEquip(UpgradedLevel, SculptureInfo.Star);

	const FCMSItemXpRow& UpgradedXpRow = CMS->GetItemXpRowOrDummy(FItemXpType(FMath::Min(UpgradedLevel + 1, MaxLevel)));
	SetResultXp(SculptureInfo.Xp + GainXp, UpgradedXpRow.Req, UpgradedXpRow.Acc, (UpgradedLevel > Level));

	SetSculptureStat(SculptureInfo.Type, Level, UpgradedLevel, SculptureInfo.Tier, FMath::Min(SculptureInfo.Tier + AddedTier, CombatCubeConst::Q6_MAX_TIER));

	GainXPBox->SetVisibility(ESlateVisibility::Collapsed);
}

void UUpgradeStatWidget::SetAddXp(int32 CurXp, int32 ReqXp, int32 AccXp, int32 UpReqXp, int32 UpAccXp, int32 GainXp, bool bLevelUp)
{
	if (!bLevelUp && (CurXp < UpAccXp))
	{
		float XpRatio = (float)(ReqXp - (AccXp - CurXp)) / ReqXp;
		XPBar->SetPercent(XpRatio);
	}
	else
	{
		XPBar->SetPercent(0.0f);
	}

	int32 RemainXp = FMath::Max(UpAccXp - (CurXp + GainXp), 0);
	GainXPText->SetText(FText::FromString(FString::FormatAsNumber(GainXp)));
	RemainXPText->SetText(FText::FromString(FString::FormatAsNumber(RemainXp)));

	if (GainXp > 0)
	{
		float ResultXpRatio = (float)(UpReqXp - RemainXp) / UpReqXp;
		ResultXPBar->SetPercent(ResultXpRatio);
	}
	else
	{
		ResultXPBar->SetPercent(0.0f);
	}

	PlayLevelUpAnimation(bLevelUp);
}

void UUpgradeStatWidget::SetResultXp(int32 ResultXp, int32 ReqXp, int32 AccXp, bool bLevelUp)
{
	PlayLevelUpAnimation(bLevelUp);

	if (AccXp <= ResultXp)
	{
		XPBar->SetPercent(0.0f);
		RemainXPText->SetText(FText::FromString(FString::FormatAsNumber(0)));
	}
	else
	{
		int32 RemainXp = FMath::Max(AccXp - ResultXp, 0);
		float XpRatio = (float)(ReqXp - RemainXp) / ReqXp;
		XPBar->SetPercent(XpRatio);
		RemainXPText->SetText(FText::FromString(FString::FormatAsNumber(RemainXp)));
	}

	ResultXPBar->SetPercent(0.0f);
}

void UUpgradeStatWidget::SetRelicStat(FRelicType RelicType, int32 OldLevel, int32 NewLevel, int32 OldTier, int32 NewTier)
{
	UCMS* CMS = GetCMS();

	const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(RelicType);

	int64 Hp, Atk, Def;
	Attribute::GetRelicAttribute(CMS, RelicType,
		OldLevel, OldTier, RelicRow.Grade, Hp, Atk, Def);

	int64 ResultHp, ResultAtk, ResultDef;
	Attribute::GetRelicAttribute(CMS, RelicType,
		NewLevel, NewTier, RelicRow.Grade, ResultHp, ResultAtk, ResultDef);

	HpStatWidget->SetStat(EUnitAttribute::MaxHealth, Hp, ResultHp);
	AtkStatWidget->SetStat(EUnitAttribute::Atk, Atk, ResultAtk);
	DefStatWidget->SetStat(EUnitAttribute::Def, Def, ResultDef);
}

void UUpgradeStatWidget::SetCharacterStat(FCharacterType CharacterType, int32 Moon, int32 OldLevel, int32 NewLevel)
{
	UCMS* CMS = GetCMS();

	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterType);
	const FUnitType& UnitType = CMS->GetUnitType(CharacterType);

	int64 Hp, Atk, Def;
	Attribute::GetUnitAttribute(CMS, EAttributeCategory::Character, UnitType,
		OldLevel, CharacterRow.Grade, nullptr, Hp, Atk, Def);

	int64 ResultHp, ResultAtk, ResultDef;
	Attribute::GetUnitAttribute(CMS, EAttributeCategory::Character, UnitType,
		NewLevel, CharacterRow.Grade, nullptr, ResultHp, ResultAtk, ResultDef);

	HpStatWidget->SetStat(EUnitAttribute::MaxHealth, Hp, ResultHp);
	AtkStatWidget->SetStat(EUnitAttribute::Atk, Atk, ResultAtk);
	DefStatWidget->SetStat(EUnitAttribute::Def, Def, ResultDef);
}

void UUpgradeStatWidget::SetSculptureStat(FSculptureType SculptureType, int32 OldLevel, int32 NewLevel, int32 OldTier, int32 NewTier)
{
	UCMS* CMS = GetCMS();

	const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(SculptureType);

	int64 Hp, Atk, Def;
	Attribute::GetSculptureAttribute(CMS, SculptureType,
		OldLevel, OldTier, SculptureRow.Grade, Hp, Atk, Def);

	int64 ResultHp, ResultAtk, ResultDef;
	Attribute::GetSculptureAttribute(CMS, SculptureType,
		NewLevel, NewTier, SculptureRow.Grade, ResultHp, ResultAtk, ResultDef);

	HpStatWidget->SetStat(EUnitAttribute::MaxHealth, Hp, ResultHp);
	AtkStatWidget->SetStat(EUnitAttribute::Atk, Atk, ResultAtk);
	DefStatWidget->SetStat(EUnitAttribute::Def, Def, ResultDef);
}

UUpgradeResultStatWidget::UUpgradeResultStatWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UUpgradeResultStatWidget::NativeConstruct()
{
	Super::NativeConstruct();

	OldStatWidget = CastChecked<UUpgradeStatWidget>(GetWidgetFromName("OldStat"));
	NewStatWidget = CastChecked<UUpgradeStatWidget>(GetWidgetFromName("NewStat"));
}

void UUpgradeResultStatWidget::SetCharacterPromote(const FCharacterInfo& CharacterInfo)
{
	OldStatWidget->SetCharacterResult(CharacterInfo);
	NewStatWidget->SetCharacterPromote(CharacterInfo);
}

void UUpgradeResultStatWidget::SetCharacterEvolute(const FCharacterInfo& CharacterInfo)
{
	OldStatWidget->SetCharacterResult(CharacterInfo);
	NewStatWidget->SetCharacterEvolute(CharacterInfo);
}

void UUpgradeResultStatWidget::SetRelicPromote(const FRelicInfo& RelicInfo)
{
	OldStatWidget->SetRelicResult(RelicInfo, 0, 0);
	NewStatWidget->SetRelicPromote(RelicInfo);
}

void UUpgradeResultStatWidget::SetSculpturePromote(const FSculptureInfo& SculptureInfo)
{
	OldStatWidget->SetSculptureResult(SculptureInfo, 0, 0);
	NewStatWidget->SetSculpturePromote(SculptureInfo);
}

//////////////////////////////////////////////////////////////////////////
// BondWidgets
//////////////////////////////////////////////////////////////////////////

FText GetCharUnlockElemText(const FCMSCharUnlockElemRow& Row)
{
	if (Row.Category == ECharUnlockElemCategory::Profile)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "BondProfile"),
			Q6Util::GetCharacterProfileText((EProfileCategory)Row.Param1));
	}
	else if (Row.Category == ECharUnlockElemCategory::Voice)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "BondVoice"), Row.Desc);
	}
	else if (Row.Category == ECharUnlockElemCategory::Story)
	{
		return FText::Format(Q6Util::GetLocalizedText("Common", "BondStory"), Row.Desc);
	}

	Q6JsonLogRoze(Error, "GetCharUnlockElemText - proceed not here");
	return FText::GetEmpty();
}

void UBondRewardWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	RewardText = CastChecked<URichTextBlock>(GetWidgetFromName("Reward"));
}

void UBondRewardWidget::SetInfo(ELootCategory LootCategory, int32 Param)
{
	const FSlateBrush& LootIcon = GetUIResource().GetLootCategoryIcon(LootCategory);
	IconImage->SetBrush(LootIcon);

	switch (LootCategory)
	{
		case ELootCategory::PaidGem:
		case ELootCategory::FreeGem:
		case ELootCategory::Gold:
		case ELootCategory::SmallBattery:
		case ELootCategory::MediumBattery:
		case ELootCategory::LargeBattery:
			RewardText->SetText(FText::Format(
			Q6Util::GetLocalizedText("Common", "MultiplyText"), FText::AsNumber(Param)));
			break;
		case ELootCategory::RelicCard:
		{
			const UCMS* CMS = GetCMS();
			const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(FRelicType(Param));
			if (RelicRow.IsInvalid())
			{
				Q6JsonLogGunny(Warning, "UBondRewardWidget::SetInfo - RelicRow does not exist.", Q6KV("RelicType", Param));
				return;
			}

			RewardText->SetText(RelicRow.DescName);
			break;
		}
		case ELootCategory::CharUnlockElem:
		{
			const FCMSCharUnlockElemRow& Row = GetCMS()->GetCharUnlockElemRowOrDummy(FCharUnlockElemType(Param));
			FText CharUnlockElemRewardText = GetCharUnlockElemText(Row);
			RewardText->SetText(CharUnlockElemRewardText);
			break;
		}
		case ELootCategory::Special:
		{
			const FCMSSpecialRow& SpecialRow = GetCMS()->GetSpecialRowOrDummy(FSpecialType(Param));
			RewardText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "BondStageOpen"), SpecialRow.Desc));
			break;
		}
		default:
			Q6JsonLogRoze(Error, "UBondRewardWidget::SetInfo - proceed not here");
			break;
	}

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UBondRewardInfoListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BondText = CastChecked<UTextBlock>(GetWidgetFromName("Bond"));
	BondRewardWidgets.Reset();
	BondRewardWidgets.Add(CastChecked<UBondRewardWidget>(GetWidgetFromName("Reward0")));
	BondRewardWidgets.Add(CastChecked<UBondRewardWidget>(GetWidgetFromName("Reward1")));
}

void UBondRewardInfoListWidget::SetInfo(int32 BondLevel, const FCMSBondRewardRow* BondReward)
{
	int32 BondTemp = BondLevel * BondTemperaturePerLevel;

	BondText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Common", "Temperature"), FText::AsNumber(BondTemp)));

	if (BondReward->Reward1 != ELootCategory::None)
	{
		BondRewardWidgets[0]->SetInfo(
			BondReward->Reward1,
			BondReward->Int1);
	}
	else
	{
		BondRewardWidgets[0]->SetVisibility(ESlateVisibility::Collapsed);
	}

	if (BondReward->Reward2 != ELootCategory::None)
	{
		BondRewardWidgets[1]->SetInfo(
			BondReward->Reward2,
			BondReward->Int2);
	}
	else
	{
		BondRewardWidgets[1]->SetVisibility(ESlateVisibility::Collapsed);
	}
}
