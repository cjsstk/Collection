#include "EpisodeWidgets.h"
#include "CommonWidgets.h"
#include "LobbyHUD.h"
#include "NewMarkManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6UIDefine.h"
#include "SagaManager.h"
#include "Tutorial/LobbyTutorial.h"
#include "Q6ScrollBox.h"

UEpisodeIconWidget::UEpisodeIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Episode(0)
	, State(EEpisodeState::Clear)
{
}

void UEpisodeIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconSelectAnim = GetWidgetAnimationFromName(this, "AnimIconSelect");
	IconUnSelectAnim = GetWidgetAnimationFromName(this, "AnimIconUnselect");

	ClearAnim = GetWidgetAnimationFromName(this, "AnimIconClear");
	InProgressAnim = GetWidgetAnimationFromName(this, "AnimIconInProgress");
	ComingSoonAnim = GetWidgetAnimationFromName(this, "AnimComingSoon");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimIconLocked");

	SelectButton = CastChecked<UButton>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UEpisodeIconWidget::OnSelectButtonClicked);

	EpisodeIconImage = CastChecked<UImage>(GetWidgetFromName("ImgEpisodeIcon"));
	EpisodeNumText = CastChecked<UTextBlock>(GetWidgetFromName("Num"));
	TagImage = CastChecked<UImage>(GetWidgetFromName("ImgTag"));
}

void UEpisodeIconWidget::Init(int32 InEpisode, EEpisodeState InState)
{
	Episode = InEpisode;
	State = InState;

	const FEpisodeAssetRow& AssetRow = GetGameResource().GetEpisodeAssetRow(Episode);
	EpisodeIconImage->SetBrush(AssetRow.EpisodeIcon);
	EpisodeNumText->SetText(FText::AsNumber(Episode));

	ENewMarkType NewMarkType = GetHUDStore().GetNewMarkManager().GetSagaEpisodeType(Episode);
	SetTagImage(NewMarkType);

	switch (State)
	{
		case EEpisodeState::Progress:
			PlayAnimation(InProgressAnim);
			break;
		case EEpisodeState::Locked:
			PlayAnimation(LockedAnim);
			break;
		case EEpisodeState::Clear:
		default:
			PlayAnimation(ClearAnim);
			break;
	}
}

void UEpisodeIconWidget::SetTagImage(ENewMarkType NewMarkType)
{
	if (NewMarkType == ENewMarkType::None)
	{
		TagImage->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	TagImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	if (NewMarkType == ENewMarkType::New)
	{
		TagImage->SetBrush(NewTagBrush);
	}
	else if (NewMarkType == ENewMarkType::Clear)
	{
		TagImage->SetBrush(ClearTagBrush);
	}
}

void UEpisodeIconWidget::OnSelected(bool bSelected)
{
	if (bSelected)
	{
		PlayAnimation(IconSelectAnim);
	}
	else
	{
		PlayAnimation(IconUnSelectAnim);
	}
}

void UEpisodeIconWidget::OnSelectButtonClicked()
{
	FString TutorialStr = FString::Printf(TEXT("EpisodeIcon_%d"), Episode);
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialStr);
	ClickedDelegate.ExecuteIfBound(this);
}

UEpisodePartWidget::UEpisodePartWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UEpisodePartWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EpisodeList = CastChecked<UHorizontalBox>(GetWidgetFromName("EpisodeList"));
	EpisodeList->ClearChildren();

	PartBorder = CastChecked<UBorder>(GetWidgetFromName("PartBorder"));
	PartText = CastChecked<UTextBlock>(GetWidgetFromName("TextPart"));
}

void UEpisodePartWidget::Init(int32 InPart)
{
	PartBorder->SetBrushColor(GetGameResource().GetUIResource().GetEpisodePartColor(InPart));

	if (InPart == 0)
	{
		PartText->SetText(Q6Util::GetLocalizedText("Common", "EpisodePartHead"));
	}
	else
	{
		PartText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "EpisodePart"), InPart));
	}
}

UEpisodeIconWidget* UEpisodePartWidget::FindOrAddIconWidget(int32 IconIdx, const FMargin& InPadding)
{
	UEpisodeIconWidget* IconWidget = Cast<UEpisodeIconWidget>(EpisodeList->GetChildAt(IconIdx));
	if (IconWidget)
	{
		return IconWidget;
	}

	// Create new Icon
	IconWidget = CreateWidget<UEpisodeIconWidget>(GetOwningPlayer(), EpisodeIconClass);
	check(IconWidget);

	UHorizontalBoxSlot* BoxSlot = EpisodeList->AddChildToHorizontalBox(IconWidget);
	check(BoxSlot);

	BoxSlot->SetPadding(InPadding);
	BoxSlot->SetVerticalAlignment(VAlign_Fill);
	BoxSlot->SetHorizontalAlignment(HAlign_Fill);

	return IconWidget;
}

UEpisodeListWidget::UEpisodeListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, LastSlotPadding(0.0f)
{
}

void UEpisodeListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetOpenAnim = GetWidgetAnimationFromName(this, "AnimSetOpen");
	SetLockAnim = GetWidgetAnimationFromName(this, "AnimSetLock");
	ComingSoonAnim = GetWidgetAnimationFromName(this, "AnimComingSoon");
	SetClearAnim = GetWidgetAnimationFromName(this, "AnimSetClear");
	SetSelectedAnim = GetWidgetAnimationFromName(this, "AnimSetSelected");

	EpisodePartList = CastChecked<UHorizontalBox>(GetWidgetFromName("EpisodePartList"));
	EpisodePartList->ClearChildren();

	EpisodeBorder = CastChecked<UBorder>(GetWidgetFromName("BorderEpisode"));
	PartText = CastChecked<UTextBlock>(GetWidgetFromName("TextPart"));

	EpisodeStoryText = CastChecked<UTextBlock>(GetWidgetFromName("TextEpisodeStory"));
	EpisodeNumText = CastChecked<UTextBlock>(GetWidgetFromName("TextEpisodeNum"));
	EpisodeTitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextEpisodeTitle"));
	ShouldClearText = CastChecked<UTextBlock>(GetWidgetFromName("ShouldClear"));

	ScrollBox = CastChecked<UQ6SnapScrollBox>(GetWidgetFromName("EpisodeScroll"));
	SelectBoxImage = CastChecked<UImage>(GetWidgetFromName("SelectBox"));

	ScrollBox->OnDescendantScrolled.BindUObject(this, &UEpisodeListWidget::OnDescendantScrolled);
	ScrollBox->OnSnapTrackingFired.BindUObject(this, &UEpisodeListWidget::OnSnapTrackingFired);

	SelectedIcon = nullptr;
	ScrollTargetIcon = nullptr;
}

FVector2D _GetAbsoluteCenter(const FGeometry Geom)
{
	return Geom.GetAbsolutePosition() + Geom.GetAbsoluteSize() / 2;
}

void UEpisodeListWidget::ScrollToSnap()
{
	TSharedPtr<SWidget> BoxImage = SelectBoxImage->GetCachedWidget();
	if (!BoxImage.IsValid())
	{
		return;
	}

	FVector2D BoxCenter = _GetAbsoluteCenter(BoxImage->GetCachedGeometry());

	float SnapLength = FLT_MAX;
	UEpisodeIconWidget* SnapWidget = nullptr;

	for (UEpisodeIconWidget* IconWidget : IconWidgets)
	{
		TSharedPtr<SWidget> Widget = IconWidget->GetCachedWidget();
		if (!Widget.IsValid())
		{
			continue;
		}

		FVector2D WidgetCenter = _GetAbsoluteCenter(Widget->GetCachedGeometry());

		float Length = FMath::Abs(BoxCenter.X - WidgetCenter.X);
		if (Length < SnapLength)
		{
			SnapLength = Length;
			SnapWidget = IconWidget;
		}
	}

	ScrollToIcon(SnapWidget);
}

void UEpisodeListWidget::ScrollToIcon(UEpisodeIconWidget* IconWidget)
{
	if (IconWidget)
	{
		ScrollBox->ScrollToDescendant(IconWidget);

		ScrollTargetIcon = IconWidget;
	}
}

void UEpisodeListWidget::InitEpisodeList()
{
	UCMS* InCMS = GetCMS();
	TArray<int32> Episodes = InCMS->GetEpisodes(EContentType::Saga);
	int32 PlayingEpisode = GetHUDStore().GetSagaManager().GetPlayingEpisode();

	Episodes.RemoveAll([InCMS](int32 InEpisode) {
		return !InCMS->IsSagaEpisodePresent(InEpisode);
	});

	int32 Part = -1;
	int32 IconIndex = 0;
	UEpisodePartWidget* PartWidget = nullptr;

	int32 NumIconWidgets = Episodes.Num();// +1;
	IconWidgets.Reserve(NumIconWidgets);

	for (int32 i = 0; i < NumIconWidgets; ++i)
	{
		int32 Episode = 0;
		FMargin IconPadding;

		if (Episodes.IsValidIndex(i))
		{
			Episode = Episodes[i];
			IconPadding.Right = 0.0f;
		}
		else
		{
			Episode = Episodes.Last() + 1;
			IconPadding.Right = LastSlotPadding;
		}

		int32 EpisodePart = GetGameResource().GetEpisodeAssetRow(Episode).Part;
		if (!PartWidget || Part != EpisodePart)
		{
			Part = EpisodePart;
			PartWidget = FindOrAddPartWidget(Part);
			PartWidget->Init(Part);
			IconIndex = 0;
		}

		EEpisodeState State = GetEpisodeState(Episode, PlayingEpisode);
		UEpisodeIconWidget* IconWidget = PartWidget->FindOrAddIconWidget(IconIndex++, IconPadding);
		IconWidget->Init(Episode, State);
		IconWidget->ClickedDelegate.BindUObject(this, &UEpisodeListWidget::OnIconClicked);

		if (PlayingEpisode == Episode)
		{
			ScrollToIcon(IconWidget);
		}

		IconWidgets.Add(IconWidget);
	}

	ScrollBox->FreezeScroll(GetLobbyTutorial(this)->IsInLobbyTutorial());
}

void UEpisodeListWidget::OnSnapTrackingFired()
{
	ScrollToSnap();
}

void UEpisodeListWidget::OnDescendantScrolled()
{
	if (ScrollTargetIcon)
	{
		OnIconSelected(ScrollTargetIcon);
		ScrollTargetIcon = nullptr;
	}
}

void UEpisodeListWidget::OnIconClicked(UEpisodeIconWidget* NewSelectIcon)
{
	if (SelectedIcon == NewSelectIcon)
	{
		if (NewSelectIcon->GetState() == EEpisodeState::Clear ||
			NewSelectIcon->GetState() == EEpisodeState::Progress)
		{
			OnEpisodeSelected(NewSelectIcon->GetEpisode());
			return;
		}
	}

	ScrollToIcon(NewSelectIcon);
}

void UEpisodeListWidget::OnIconSelected(UEpisodeIconWidget* NewSelectIcon)
{
	if (SelectedIcon)
	{
		SelectedIcon->OnSelected(false);
	}

	SelectedIcon = NewSelectIcon;
	SelectedIcon->OnSelected(true);

	int32 Episode = SelectedIcon->GetEpisode();
	const FEpisodeAssetRow& EpisodeRow = GetGameResource().GetEpisodeAssetRow(Episode);

	FLinearColor PartColor = GetGameResource().GetUIResource().GetEpisodePartColor(EpisodeRow.Part);
	EpisodeBorder->SetBrushColor(PartColor);
	PartText->SetColorAndOpacity(PartColor);

	if (EpisodeRow.Part == 0)
	{
		PartText->SetText(Q6Util::GetLocalizedText("Common", "EpisodePartHead"));
	}
	else
	{
		PartText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "EpisodePart"), EpisodeRow.Part));
	}

	EpisodeStoryText->SetText(EpisodeRow.Desc);
	EpisodeNumText->SetText(FText::AsNumber(Episode));
	EpisodeTitleText->SetText(EpisodeRow.Title);
	ShouldClearText->SetText(GetCMS()->GetSagaEpisodeOpenScheduleDesc(Episode));

	switch (SelectedIcon->GetState())
	{
		case EEpisodeState::Progress:
			PlayAnimation(SetOpenAnim);
			break;
		case EEpisodeState::Locked:
			PlayAnimation(SetLockAnim);
			break;
		case EEpisodeState::Clear:
		default:
			PlayAnimation(SetClearAnim);
			break;
	}

	PlayAnimation(SetSelectedAnim);

	EpisodeSelectedDelegate.ExecuteIfBound(Episode);
}

void UEpisodeListWidget::OnEpisodeSelected(int32 Episode)
{
	ACTION_DISPATCH_SagaStageList(Episode);

	bool bAutoPrologue = false;

	const FSagaType LastSagaType = GetHUDStore().GetSagaManager().GetLastSagaType();
	if (LastSagaType != SagaTypeInvalid)
	{
		bAutoPrologue = (GetCMS()->GetSagaRowOrDummy(LastSagaType).Episode < Episode);
	}
	else
	{
		bAutoPrologue = (Episode == 0);
	}

	if (bAutoPrologue)
	{
		TArray<const FCMSSagaRow*> Stages = GetCMS()->GetStageRows(EContentType::Saga, Episode);

		if (Stages.Num() > 0)
		{
			const FCMSSagaRow* FirstStage = Stages[0];

			if (FirstStage->StageType == EStageType::Normal ||
				FirstStage->StageType == EStageType::Prologue)
			{
				GetCheckedLobbyHUD(this)->PlaySagaWithStoryClear(FirstStage->CmsType(), true, false);
			}
		}
	}
}

UEpisodePartWidget* UEpisodeListWidget::FindOrAddPartWidget(int32 Index)
{
	UEpisodePartWidget* PartWidget = Cast<UEpisodePartWidget>(EpisodePartList->GetChildAt(Index));
	if (PartWidget)
	{
		return PartWidget;
	}

	PartWidget = CreateWidget<UEpisodePartWidget>(GetOwningPlayer(), EpisodePartClass);
	check(PartWidget);

	UHorizontalBoxSlot* BoxSlot = EpisodePartList->AddChildToHorizontalBox(PartWidget);
	check(BoxSlot);

	BoxSlot->SetVerticalAlignment(VAlign_Fill);
	BoxSlot->SetHorizontalAlignment(HAlign_Fill);

	return PartWidget;
}
