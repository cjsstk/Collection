// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "VacationWidgets.h"

#include "BagItemManager.h"
#include "CharacterManager.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6Account.h"
#include "SystemConstHelper.h"
#include "UIStateManager.h"
#include "VacationManager.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Vacation"), STAT_OnHSEventByVacation, STATGROUP_HSTORE);


//////////////////////////////////////////////////////////////////////////
// Vacation Spot Widget
//////////////////////////////////////////////////////////////////////////
void UVacationSpotWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	RemainDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RemainDays"));
	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UVacationSpotWidget::OnSelectButtonClicked);

	// Animations

	SelectedAnim = GetWidgetAnimationFromName(this, "AnimSelected");
	DeselectedAnim = GetWidgetAnimationFromName(this, "AnimDeselected");
	VacationEndLoopAnim = GetWidgetAnimationFromName(this, "AnimVacationEndLoop");
	VacationStartAnim = GetWidgetAnimationFromName(this, "AnimVacationStart");
	VacationNowAnim = GetWidgetAnimationFromName(this, "AnimVacationNow");
	VacationReadyAnim = GetWidgetAnimationFromName(this, "AnimVacationReady");
}

void UVacationSpotWidget::SetSpot(const FVacationSpot& VacationSpot)
{
	const FCMSVacationSpotRow& VacationSpotRow = GetCMS()->GetVacationSpotRowOrDummy(VacationSpot.VacationSpotType);
	NameText->SetText(VacationSpotRow.DescName);

	const FVacationSpotAssetRow& VacationSpotAssetRow = GetGameResource().GetVacationSpotAssetRow(VacationSpot.VacationSpotType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(VacationSpotAssetRow.IconTexture);

	StopAllAnimations();

	if (VacationSpot.CharacterType == CharacterTypeInvalid)
	{
		PlayAnimation(VacationReadyAnim);
	}
	else
	{
		const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(VacationSpot.CharacterType);
		CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());

		int32 RemainDays = GetHUDStore().GetVacationManager().GetRemainDays(VacationSpot.VacationSpotType);
		if (RemainDays > 0)
		{
			RemainDaysText->SetText(FText::AsNumber(RemainDays));
			PlayAnimation(VacationNowAnim);
		}
		else
		{
			PlayAnimation(VacationEndLoopAnim, 0.0f, 0);
		}
	}

	const ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetWonderVacationVisibility(VacationSpot);
	NewMarkImage->SetVisibility(NewMarkVisibility);
}

void UVacationSpotWidget::SetSelected(bool bInSelected)
{
	PlayAnimation(bInSelected ? SelectedAnim : DeselectedAnim);
}

void UVacationSpotWidget::PlayStartAnimation()
{
	StopAllAnimations();

	PlayAnimation(VacationStartAnim);
}

void UVacationSpotWidget::OnSelectButtonClicked()
{
	OnSpotClickedDelegate.ExecuteIfBound();
}

void UVacationSpotEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	GainBondText = CastChecked<UTextBlock>(GetWidgetFromName("GainBond"));
	VacationDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("VacationDays"));
	OpenLevelText = CastChecked<UTextBlock>(GetWidgetFromName("OpenLevel"));

	UButton* ShortcutButton = CastChecked<UButton>(GetWidgetFromName("Shortcut"));
	ShortcutButton->OnClicked.AddUniqueDynamic(this, &UVacationSpotEntryWidget::OnShortcutButtonClicked);

	StateAnims.Reset();
	StateAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimLocked"));
	StateAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimOpenable"));
	StateAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimOpened"));
}

void UVacationSpotEntryWidget::SetSpot(const FCMSVacationSpotRow& SpotRow)
{
	NameText->SetText(SpotRow.DescName);

	const FVacationSpotAssetRow& VacationSpotAssetRow = GetGameResource().GetVacationSpotAssetRow(SpotRow.CmsType());
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(VacationSpotAssetRow.IconTexture);

	GainBondText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "PlusText"), FText::AsNumber(SpotRow.Bond)));
	VacationDaysText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "VacationCount"), FText::AsNumber(SpotRow.VacationDays)));
	OpenLevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "OpenableVacation"), FText::AsNumber(SpotRow.UnlockLevel)));

	EVacationState VacationState = GetHUDStore().GetVacationManager().GetSpotState(SpotRow.CmsType());
	if (StateAnims.IsValidIndex((int32)VacationState))
	{
		PlayAnimation(StateAnims[(int32)VacationState]);
	}
}

void UVacationSpotEntryWidget::OnShortcutButtonClicked()
{
	OnShortcutClickedDelegate.ExecuteIfBound();

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Special);

	FSpecialUIState UIState;
	UIState.Category = ESpecialCategory::Wonder;
	UIState.MenuType = ESpecialStageMenuType::StageList;
	UIState.Wonder = EWonderCategory::Vacation;
	ACTION_DISPATCH_SpecialOpen(UIState);
}


//////////////////////////////////////////////////////////////////////////
// Vacation Widget
//////////////////////////////////////////////////////////////////////////
void UVacationWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	UVacationSpotWidget* SpotWidget;

	SpotWidgets.Reset();

	SpotWidget = CastChecked<UVacationSpotWidget>(GetWidgetFromName("Vacation1"));
	SpotWidget->OnSpotClickedDelegate.BindUObject(this, &UVacationWidget::OnSelectedSpot, 0);
	SpotWidgets.Add(SpotWidget);

	SpotWidget = CastChecked<UVacationSpotWidget>(GetWidgetFromName("Vacation2"));
	SpotWidget->OnSpotClickedDelegate.BindUObject(this, &UVacationWidget::OnSelectedSpot, 1);
	SpotWidgets.Add(SpotWidget);

	SpotWidget = CastChecked<UVacationSpotWidget>(GetWidgetFromName("Vacation3"));
	SpotWidget->OnSpotClickedDelegate.BindUObject(this, &UVacationWidget::OnSelectedSpot, 2);
	SpotWidgets.Add(SpotWidget);

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	SpotNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("SpotName"));
	BaseBondText = CastChecked<UQ6TextBlock>(GetWidgetFromName("BaseBond"));
	BonusBorder = CastChecked<UBorder>(GetWidgetFromName("BorderBonus"));
	LevelBonusBondText = CastChecked<UQ6TextBlock>(GetWidgetFromName("LevelBonusBond"));
	VacationTimeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("VacationTime"));
	VacationDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("VacationDays"));
	CharacterNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("CharacterName"));

	MaterialsPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("PanelMaterials"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));

	RequireGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequireGold"));
	RequireGoldWidget->SetPointType(ECurrencyType::Gold, EPointWidgetOption::LessEqual);

	OwnedGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedGold"));
	OwnedGoldWidget->SetPointType(ECurrencyType::Gold, EPointWidgetOption::NONE);

	CharacterNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("CharacterName"));
	InfoText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextInfo"));
	VacationText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextVacation"));
	OwnedSpotCountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("OwnedSpotCount"));

	VacationButton = CastChecked<UButton>(GetWidgetFromName("Vacation"));
	VacationButton->OnClicked.AddUniqueDynamic(this, &UVacationWidget::OnVacationButtonClicked);

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UVacationWidget::OnSelectButtonClicked);

	UQ6Button* SpotListingButton = CastChecked<UQ6Button>(GetWidgetFromName("SpotListing"));
	SpotListingButton->OnClickedDelegate.BindUObject(this, &UVacationWidget::OnSpotListingButtonClicked);

	// Animations

	CharacterSelectedAnim = GetWidgetAnimationFromName(this, "AnimCharacterSelected");
	VacationReadyAnim = GetWidgetAnimationFromName(this, "AnimVacationReady");
	VacationNowAnim = GetWidgetAnimationFromName(this, "AnimVacationNow");
	VacationEndLoopAnim = GetWidgetAnimationFromName(this, "AnimVacationEndLoop");
}

void UVacationWidget::OnMenuEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByVacation);

	if (InAction->GetActionType() == EHSActionType::VacationStartResp)
	{
		auto Action = ACTION_PARSE_VacationStartResp(InAction);
		const FL2CVacationStartResp& Res = Action->GetVal();

		if (SpotWidgets.IsValidIndex(Res.SpotIndex))
		{
			SpotWidgets[Res.SpotIndex]->SetSpot(Res.VacationSpot);
			SpotWidgets[Res.SpotIndex]->PlayStartAnimation();
			SetVacationDetail(SelectedIndex);
			return;
		}
	}

	if (InAction->GetActionType() == EHSActionType::DevAddCurrencyResp
		|| InAction->GetActionType() == EHSActionType::DevBondAddResp)
	{
		SetWonder();
		return;
	}
}

void UVacationWidget::SetWonder()
{
	const FWonderUIState& UIState = GetHUDStore().GetUIStateManager().GetWonderUIState();
	int32 SelectedSlotIndex = UIState.SelectedSlot - 1;

	RefreshUI();
	SelectVacationSpot(SelectedSlotIndex);
}

void UVacationWidget::RefreshUI()
{
	const UVacationManager& VacationMgr = GetHUDStore().GetVacationManager();
	const FVacationInfo& Vacation = VacationMgr.GetVacation();
	
	int32 OwnedSpotCount = VacationMgr.GetOpenedSpotTypes().Num();
	OwnedSpotCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "OwnedVacationSpots"), FText::AsNumber(OwnedSpotCount)));

	for (int32 i = 0; i < Vacation.Spots.Num(); ++i)
	{
		if (SpotWidgets.IsValidIndex(i) && Vacation.Spots.IsValidIndex(i))
		{
			SpotWidgets[i]->SetSpot(Vacation.Spots[i]);
		}
	}

	SetVacationDetail(SelectedIndex);
}

void UVacationWidget::SetVacationReady(FVacationSpotType SpotType)
{
	CharacterNameText->SetText(FText::GetEmpty());
	CharacterImage->SetVisibility(ESlateVisibility::Collapsed);
	InfoText->SetText(FText::GetEmpty());

	VacationTimeText->SetText(Q6Util::GetLocalizedText("Lobby", "VacationTime"));
	VacationText->SetText(Q6Util::GetLocalizedText("Lobby", "VacationStart"));
	VacationButton->SetIsEnabled(false);

	const FCMSVacationSpotRow& VacationSpotRow = GetCMS()->GetVacationSpotRowOrDummy(SpotType);
	VacationDaysText->SetText(FText::AsNumber(VacationSpotRow.VacationDays));

	const FCMSWonderCostRow* VacationCost = GetCMS()->GetVacationCost(SpotType);
	if (!VacationCost)
	{
		Q6JsonLogRoze(Error, "UVacationWidget::OnSelectedCharacter - Invalid vacation cost", Q6KV("VacationSpotType", SpotType));
		return;
	}

	bEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(VacationCost->GetBagItem(), VacationCost->ItemCount);
	if (VacationCost->GetBagItem().Num() > 0)
	{
		MaterialsPanel->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		MaterialsWidget->SetMaterials(VacationCost->GetBagItem(), VacationCost->ItemCount);
	}
	else
	{
		MaterialsPanel->SetVisibility(ESlateVisibility::Collapsed);
	}

	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	bEnoughMaterials &= (OwnedGold >= VacationCost->Gold);

	OwnedGoldWidget->SetCurPoint(OwnedGold);
	RequireGoldWidget->SetPoint(VacationCost->Gold, OwnedGold);

	PlayAnimation(VacationReadyAnim);
}

void UVacationWidget::SetVacationNow(const FVacationSpot& Spot, int32 RemainDays)
{
	VacationTimeText->SetText(Q6Util::GetLocalizedText("Lobby", "VacationTimeLeft"));
	VacationDaysText->SetText(FText::AsNumber(RemainDays));

	InfoText->SetText(Q6Util::GetLocalizedText("Lobby", "OnVacation"));

	SetCharacter(Spot.CharacterType);

	PlayAnimation(VacationNowAnim);
}

void UVacationWidget::SetVacationEnded(const FVacationSpot& Spot)
{
	bEndVacation = true;

	VacationText->SetText(Q6Util::GetLocalizedText("Lobby", "VacationFeedback"));
	InfoText->SetText(Q6Util::GetLocalizedText("Lobby", "EndVacation"));
	VacationButton->SetIsEnabled(true);

	SetCharacter(Spot.CharacterType);

	PlayAnimation(VacationEndLoopAnim, 0.f, 0);
}

void UVacationWidget::SetCharacter(FCharacterType CharacterType)
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(CharacterType);
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	CharacterImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);

	CharacterNameText->SetText(UnitRow.DescName);
}

void UVacationWidget::SetVacationDetail(int32 InSelectedIdx)
{
	SelectedIndex = InSelectedIdx;
	SelectedCharacterId = FCharacterId::InvalidValue();
	bEndVacation = false;
	bEnoughMaterials = false;

	const UVacationManager& VacationMgr = GetHUDStore().GetVacationManager();
	const FVacationInfo& Vacation = VacationMgr.GetVacation();
	const FVacationSpot* Spot = VacationMgr.GetVacationSpot(SelectedIndex);
	if (!Spot)
	{
		Q6JsonLogRoze(Error, "UVacationWidget::OnSelectedSpot - Invalid spot", Q6KV("Slot", SelectedIndex + 1));
		return;
	}

	const FCMSVacationSpotRow& SpotRow = GetCMS()->GetVacationSpotRowOrDummy(Spot->VacationSpotType);
	SpotNameText->SetText(SpotRow.DescName);

	FText PlusText = Q6Util::GetLocalizedText("Common", "PlusText");
	BaseBondText->SetText(FText::Format(PlusText, FText::AsNumber(SpotRow.Bond)));

	int32 LevelBonus = SystemConstHelper::GetVacationLevelBonusBond(VacationMgr.GetLevel());
	LevelBonusBondText->SetText(FText::Format(PlusText, FText::AsNumber(LevelBonus)));
	BonusBorder->SetVisibility(LevelBonus > 0 ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	const FVacationSpotAssetRow& SpotAssetRow = GetGameResource().GetVacationSpotAssetRow(Spot->VacationSpotType);
	BGImage->SetBrushFromSoftTextureWhenLoadingFinished(SpotAssetRow.IllustTexture);

	StopAllAnimations();

	if (Spot->CharacterType == CharacterTypeInvalid)
	{
		SetVacationReady(Spot->VacationSpotType);
	}
	else
	{
		int32 RemainDays = VacationMgr.GetRemainDays(Spot->VacationSpotType);
		if (RemainDays > 0)
		{
			SetVacationNow(*Spot, RemainDays);
		}
		else
		{
			SetVacationEnded(*Spot);
		}
	}
}

void UVacationWidget::SelectVacationSpot(int32 InSelectedIndex)
{
	for (int32 i = 0; i < SpotWidgets.Num(); ++i)
	{
		SpotWidgets[i]->SetSelected(i == SelectedIndex);
	}
}

void UVacationWidget::OnVacationButtonClicked()
{
	if (bEndVacation)
	{
		GetHUDStore().GetVacationManager().ReqEnd(SelectedIndex);
	}
	else
	{
		UVacationStartConfirmPopupWidget* ConfirmPopup = CastChecked<UVacationStartConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(VacationStartConfirmPopupClass));
		ConfirmPopup->SetVacation(SelectedCharacterId, SelectedIndex);
	}
}

void UVacationWidget::OnSelectButtonClicked()
{
	UItemSelectPopupWidget* ItemSelectPopup = GetCheckedLobbyHUD(this)->OpenVacationCharacterListPopup();
	check(ItemSelectPopup);

	ItemSelectPopup->OnItemSelectedDelegate.BindUObject(this, &UVacationWidget::OnSelectedCharacter);
}

void UVacationWidget::OnSpotListingButtonClicked()
{
	int32 VacationLevel = GetHUDStore().GetVacationManager().GetLevel();

	UVacationSpotListPopupWidget* SpotListPopup = CastChecked<UVacationSpotListPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(VacationSpotListPopupWidgetClass));
	SpotListPopup->SetSpots(VacationLevel);
}

void UVacationWidget::OnSelectedSpot(int32 SpotIdx)
{
	ACTION_DISPATCH_WonderSlotSelect(SpotIdx + 1);

	for (int32 i = 0; i < SpotWidgets.Num(); ++i)
	{
		SpotWidgets[i]->SetSelected(i == SpotIdx);
	}

	SetVacationDetail(SpotIdx);
}

void UVacationWidget::OnSelectedCharacter(int64 ItemId)
{
	SelectedCharacterId = FCharacterId(ItemId);

	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(FCharacterId(ItemId));
	if (!Character)
	{
		Q6JsonLogRoze(Error, "UVacationWidget::OnSelectedCharacter - Invalid character", Q6KV("CharacterId", ItemId));
		return;
	}

	FCharacterType CharacterType = Character->GetInfo().Type;
	SetCharacter(CharacterType);

	VacationButton->SetIsEnabled(bEnoughMaterials);

	PlayAnimation(CharacterSelectedAnim);
}


void UVacationStartConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterCardWidget = CastChecked<USimpleItemCardWidget>(GetWidgetFromName("CharacterCard"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	BaseBondText = CastChecked<UQ6TextBlock>(GetWidgetFromName("BaseBond"));
	LevelBonusBondText = CastChecked<UQ6TextBlock>(GetWidgetFromName("LevelBonusBond"));
	BonusBorder = CastChecked<UBorder>(GetWidgetFromName("BorderBonus"));
	VacationDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("VacationDays"));

	MaterialsBox = CastChecked<UVerticalBox>(GetWidgetFromName("BoxMaterials"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));

	OwnedGoldText = CastChecked<UQ6TextBlock>(GetWidgetFromName("OwnedGold"));
	RequireGoldText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RequireGold"));
}

void UVacationStartConfirmPopupWidget::SetVacation(FCharacterId InCharacterId, int32 InSpotIndex)
{
	CharacterId = InCharacterId;
	SpotIndex = InSpotIndex;

	SetTitle(Q6Util::GetLocalizedText("Popup", "VacationConfirmTitle"));

	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!Character)
	{
		Q6JsonLogRoze(Error, "UVacationStartConfirmPopupWidget::SetVacation - Invalid character", Q6KV("CharacterId", CharacterId.S));
		return;
	}

	CharacterCardWidget->SetVacationCharacter(Character->GetInfo());

	const UCMS* CMS = GetCMS();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(Character->GetInfo().Type);
	NameText->SetText(UnitRow.DescName);

	const FVacationInfo& Vacation = GetHUDStore().GetVacationManager().GetVacation();
	if (!Vacation.Spots.IsValidIndex(SpotIndex))
	{
		Q6JsonLogRoze(Error, "UVacationStartConfirmPopupWidget::SetVacation - Invalid spot", Q6KV("SpotIndex", SpotIndex));
		return;
	}

	FText BondFormatText = Q6Util::GetLocalizedText("Common", "PlusText");
	const FVacationSpot& Spot = Vacation.Spots[SpotIndex];
	const FCMSVacationSpotRow& SpotRow = CMS->GetVacationSpotRowOrDummy(Spot.VacationSpotType);
	BaseBondText->SetText(FText::Format(BondFormatText, FText::AsNumber(SpotRow.Bond)));

	int32 LevelBonusBond = SystemConstHelper::GetVacationLevelBonusBond(Vacation.Level);
	BonusBorder->SetVisibility(LevelBonusBond > 0 ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	LevelBonusBondText->SetText(FText::Format(BondFormatText, FText::AsNumber(LevelBonusBond)));

	VacationDaysText->SetText(FText::AsNumber(SpotRow.VacationDays));

	const FCMSWonderCostRow* CostRow = CMS->GetVacationCost(Spot.VacationSpotType);
	if (!CostRow)
	{
		Q6JsonLogRoze(Error, "UVacationStartConfirmPopupWidget::SetVacation - Invalid cost", Q6KV("SpotType", Spot.VacationSpotType.x));
		return;
	}

	if (CostRow->GetBagItem().Num() > 0)
	{
		MaterialsBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		MaterialsWidget->SetMaterials(CostRow->GetBagItem(), CostRow->ItemCount);
	}
	else
	{
		MaterialsBox->SetVisibility(ESlateVisibility::Collapsed);
	}

	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedGoldText->SetText(FText::AsNumber(OwnedGold));
	RequireGoldText->SetText(FText::AsNumber(CostRow->Gold));
}

void UVacationStartConfirmPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	Super::OnConfirmButtonClicked(Option);

	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetHUDStore().GetVacationManager().ReqStart(SpotIndex, CharacterId);
}

void UVacationResultWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BondBar = CastChecked<UProgressBar>(GetWidgetFromName("BarBond"));
	TitleBorder = CastChecked<UBorder>(GetWidgetFromName("BorderTitle"));
	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextTitle"));
	TemperatureText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Temperature"));
	GainBondText = CastChecked<UTextBlock>(GetWidgetFromName("GainBond"));
	BondLevelUpImage = CastChecked<UImage>(GetWidgetFromName("BondUp"));

	UButton* CloseButton = CastChecked<UButton>(GetWidgetFromName("Close"));
	CloseButton->OnClicked.AddUniqueDynamic(this, &UVacationResultWidget::OnCloseButtonClicked);

	VacationResultAnim = GetWidgetAnimationFromName(this, "AnimVacationResult");
}

void UVacationResultWidget::SetResult(const FVacationResult& InResult)
{
	EUpgradeResultType ResultType = InResult.ResultType;
	const FCharacterBond& CurBond = InResult.Bond;
	const FCharacterBond& OldBond = InResult.OldBond;

	const UCMS* CMS = GetCMS();
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CurBond.CharacterType);

	EBondCategory BondCategory = (EBondCategory)CharacterRow.BondCategory;
	int32 StartXp = CMS->GetStartBondXpByLevel(BondCategory, CurBond.Level.x);
	int32 Xp = CurBond.Xp - StartXp;
	int32 NextLevel = FMath::Min(CurBond.Level.x + 1, MaxBondLevel);
	int32 RequireBondXp = CMS->GetBondXpByLevel(BondCategory, NextLevel);

	BondBar->SetPercent((float)Xp / RequireBondXp);

	TemperatureText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Temperature"), FText::AsNumber(CurBond.Level.x * BondTemperaturePerLevel)));

	if (ResultType == EUpgradeResultType::Fail)
	{
		TitleBorder->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		TitleBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		TitleText->SetText(Q6Util::GetUpgradeResultText(ResultType));
	}

	int32 GainBondXp = CurBond.Xp - OldBond.Xp;
	GainBondText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "PlusText"), FText::AsNumber(GainBondXp)));

	if (InResult.IsBondLevelUp())
	{
		BondLevelUpImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		BondLevelUpImage->SetVisibility(ESlateVisibility::Collapsed);
	}

	PlayAnimation(VacationResultAnim);
}

void UVacationResultWidget::OnCloseButtonClicked()
{
	OnClosedDelegate.ExecuteIfBound();
}

void UVacationSpotListPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	VacationListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("VacationList"));
}

void UVacationSpotListPopupWidget::SetSpots(int32 VacationLevel)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "VacationListTitle"));

	VacationListWidget->ClearList();

	TArray<const FCMSVacationSpotRow*> SpotRows;
	GetCMS()->GetVacationSpot()->GetAllRows(TEXT("SetSpots"), SpotRows);
	for (const FCMSVacationSpotRow* SpotRow : SpotRows)
	{
		check(SpotRow);

		UVacationSpotEntryWidget* EntryWidget = CastChecked<UVacationSpotEntryWidget>(VacationListWidget->AddChildAtLastIndex());
		EntryWidget->OnShortcutClickedDelegate.BindUObject(this, &UVacationSpotListPopupWidget::ClosePopup);

		EntryWidget->SetSpot(*SpotRow);
	}
}
