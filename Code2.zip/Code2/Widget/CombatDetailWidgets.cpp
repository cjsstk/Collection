#include "CombatDetailWidgets.h"

#include "CombatGameResource.h"
#include "CombatHUD.h"
#include "CombatPresenter.h"
#include "CombatWidgets.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6GameState.h"
#include "Components/RichTextBlock.h"
#include "WidgetUtil.h"

//////////////////////////////////////////////////////////////////////////
// UCombatDetailStatWidget

void UCombatDetailStatWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UTextBlock* NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	NameText->SetText(Name);

	ValueText = CastChecked<UTextBlock>(GetWidgetFromName("Value"));
	ConditionalValueText = CastChecked<UTextBlock>(GetWidgetFromName("Condition"));
}

void UCombatDetailStatWidget::SetValues(int32 InConstValue, int32 InVaryValue)
{
	ValueText->SetText(FText::AsNumber(InConstValue));

	if (InVaryValue == 0)
	{
		ConditionalValueText->SetText(FText::GetEmpty());
	}
	else
	{
		const FBuffIcon& DefaultBuffIcon = GetCombatGameResource(this)->GetUnitAttributeBuffIcon(UnitAttributeTypeInvalid, InVaryValue);
		ConditionalValueText->SetColorAndOpacity(DefaultBuffIcon.BuffColor);

		FText VaryValueText = InVaryValue < 0 ? FText::AsNumber(InVaryValue) : FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText"), FText::AsNumber(InVaryValue));
		FString BracketValueString = FString::Printf(TEXT("(%s)"), *VaryValueText.ToString());
		ConditionalValueText->SetText(FText::FromString(BracketValueString));
	}
}

//////////////////////////////////////////////////////////////////////////
// UCombatDetailConditionStateWidget

void UCombatDetailConditionStateWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BuffIconWidget = CastChecked<UBuffIconWidget>(GetWidgetFromName("BuffIcon"));
	EffectText = Cast<URichTextBlock>(GetWidgetFromName("Effect"));
	HitCountText = Cast<URichTextBlock>(GetWidgetFromName("HitCount"));
	TurnCountText = Cast<URichTextBlock>(GetWidgetFromName("TurnCount"));
}

void UCombatDetailConditionStateWidget::SetMomentCondition(EMoment Moment, FSkillType MomentSkillType, const FBuffState& BuffState)
{
	const UCMS* CMS = GetCMS();
	const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffState.BuffType));
	BuffIconWidget->SetMoment(Moment, MomentSkillType, BuffRow.Lock, BuffState.BuffId.X, BuffState.Multiple);

	EffectText->SetText(BuildToolTipDesc(MomentSkillType, BuffState.BuffLevel, BuffState.BornCategory));

	SetConditionInternal(BuffState.HitCount, BuffRow.Infinity, BuffState.Duration);
}

void UCombatDetailConditionStateWidget::SetUnitAttributeCondition(const FCMSBuffEffectRow* BuffEffectRow, const FBuffState& BuffState)
{
	const UCMS* CMS = GetCMS();
	const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffState.BuffType));

	const FCMSUnitAttributeRow& Row = CMS->GetUnitAttributeRowOrDummy(FUnitAttributeType(BuffEffectRow->Param1));
	BuffIconWidget->SetUnitAttributeBuff(Row.CmsType(), BuffEffectRow->Param2, BuffRow.Lock, BuffState.BuffId.X, BuffState.Multiple);

	FText BuffEffectDescToolTip = BuildToolTipBuffEffectDesc(BuffEffectRow->CmsType(), BuffState.BuffLevel, BuffState.BornCategory);
	EffectText->SetText(BuffEffectDescToolTip);

	SetConditionInternal(BuffState.HitCount, BuffRow.Infinity, BuffState.Duration);
}

void UCombatDetailConditionStateWidget::SetCrowdControlCondition(const FCMSCrowdControlRow& CrowdControlRow, const FCMSBuffEffectRow* BuffEffectRow, const FBuffState& BuffState)
{
	const UCMS* CMS = GetCMS();
	const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffState.BuffType));

	BuffIconWidget->SetCrowdControl(CrowdControlRow.CmsType(), BuffRow.Lock, BuffState.BuffId.X, BuffState.Multiple);

	FText BuffEffectDescToolTip = BuildToolTipBuffEffectDesc(BuffEffectRow->CmsType(), BuffState.BuffLevel, BuffState.BornCategory);
	EffectText->SetText(BuffEffectDescToolTip);

	SetConditionInternal(BuffState.HitCount, BuffRow.Infinity, BuffState.Duration);
}

void UCombatDetailConditionStateWidget::SetConditionInternal(int32 HitCount, bool bInfinity, int32 Duration)
{
	if (HitCount > 0)
	{
		FText BuffHitText = Q6Util::GetLocalizedText("Combat", "BuffHit");
		BuffHitText = FText::Format(BuffHitText, FText::AsNumber(HitCount));
		HitCountText->SetText(BuffHitText);
	}
	else
	{
		HitCountText->SetText(FText::GetEmpty());
	}

	if (bInfinity)
	{
		FText BuffInfinityText = Q6Util::GetLocalizedText("Combat", "BuffTurnLoop");
		TurnCountText->SetText(BuffInfinityText);
	}
	else
	{
		FText BuffTurnText = Q6Util::GetLocalizedText("Combat", "BuffTurn");
		BuffTurnText = FText::Format(BuffTurnText, FText::AsNumber(Duration));
		TurnCountText->SetText(BuffTurnText);
	}
}

void UCombatDetailConditionStateWidget::SetPointVaryUnitAttributeCondition(const FPointVaryUnitAttributeState& InAttributeState)
{
	BuffIconWidget->SetUnitAttributeBuff(InAttributeState.UnitAttributeType, InAttributeState.Value);

	FString PointVaryTextKey = FString::Printf(TEXT("PointVary%s"), *ENUM_TO_STRING(EPointVaryState, EPointVaryState::Convert));
	FText PointVaryText = Q6Util::GetLocalizedText("Combat", PointVaryTextKey);

	EPointVaryConvertType PointVaryConvertType;
	
	const UCMS* CMS = GetCMS();
	const FCMSUnitAttributeRow& UnitAttributeRow = CMS->GetUnitAttributeRowOrDummy(InAttributeState.UnitAttributeType);
	CMS->GetPointVaryConvertTypeFromUnitAttribute(UnitAttributeRow.UnitAttribute, PointVaryConvertType);

	FString TypeKeyString = GetCheckedCombatHUD(this)->GetConvertTypeKeyString(PointVaryConvertType);
	FText PointTypeText = Q6Util::GetLocalizedTextOrKey("Combat", TypeKeyString);

	FText ValueText = GetCheckedCombatHUD(this)->GetConvertValueText(PointVaryConvertType, InAttributeState.Value);
	PointVaryText = FText::Format(PointVaryText, PointTypeText, ValueText);
	EffectText->SetText(PointVaryText);

	HitCountText->SetText(FText::GetEmpty());

	FText BuffTurnText = Q6Util::GetLocalizedText("Combat", "BuffTurn");
	BuffTurnText = FText::Format(BuffTurnText, FText::AsNumber(1));
	TurnCountText->SetText(BuffTurnText);
}

void UCombatDetailConditionStateWidget::SetMomentSkill(const FCMSBuffRow& BuffRow, FSkillType MomentSkillType)
{
	BuffIconWidget->SetMoment(BuffRow.FollowMoment, MomentSkillType, BuffRow.Lock);

	// PassiveSkill -> MaxSkillLevel, ESkillCategory::Equipment in CCAction
	EffectText->SetText(BuildToolTipDesc(MomentSkillType, CombatCubeConst::Q6_MAX_SKILL_LEVEL, ESkillCategory::Equipment));

	SetConditionInternal(BuffRow.HitCount, BuffRow.Infinity, BuffRow.Duration);
}

void UCombatDetailConditionStateWidget::SetBuffEffect(const FCMSBuffRow& BuffRow, const FCMSBuffEffectRow& BuffEffectRow)
{
	if (BuffEffectRow.BuffEffectCategory == EBuffEffectCategory::ModifyUnitAttribute)
	{
		const FCMSUnitAttributeRow& Row = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType(BuffEffectRow.Param1));
		BuffIconWidget->SetUnitAttributeBuff(Row.CmsType(), BuffEffectRow.Param2, BuffRow.Lock);
	}
	else if (BuffEffectRow.BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
	{
		const FCMSCrowdControlRow& CrowdControlRow = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow.Param1));
		BuffIconWidget->SetCrowdControl(CrowdControlRow.CmsType(), BuffRow.Lock);
	}

	// Matched to CCAction buff create parameter
	FText BuffEffectDescToolTip = BuildToolTipBuffEffectDesc(BuffEffectRow.CmsType(), CombatCubeConst::Q6_MAX_SKILL_LEVEL, ESkillCategory::Equipment);
	EffectText->SetText(BuffEffectDescToolTip);

	SetConditionInternal(BuffRow.HitCount, BuffRow.Infinity, BuffRow.Duration);
}


//////////////////////////////////////////////////////////////////////////
// UCombatDetailConditionWidget

void UCombatDetailConditionWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UWidgetSwitcher* Switcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("FactionSwitcher"));
	Switcher->SetActiveWidgetIndex((uint8)Faction);

	ConditionListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ConditionList"));
}

void UCombatDetailConditionWidget::SetMonsterInfo(int32 MonsterSlot, int32 MonsterNumSlots, FText Name)
{
	FText PositionText;
	switch (MonsterSlot)
	{
		case 1:
			PositionText = Q6Util::GetLocalizedText("Combat", "PositionLeft");
			break;
		case 2:
			PositionText = MonsterNumSlots == 2 ? Q6Util::GetLocalizedText("Combat", "PositionRight") :
				Q6Util::GetLocalizedText("Combat", "PositionCenter");
			break;
		case 3:
			PositionText = Q6Util::GetLocalizedText("Combat", "PositionRight");
			break;
		default:
			PositionText = FText::GetEmpty();
			break;
	}
	UTextBlock* MonsterPositionText = CastChecked<UTextBlock>(GetWidgetFromName("MonsterPosition"));
	MonsterPositionText->SetText(PositionText);

	UTextBlock* MonsterNameText = CastChecked<UTextBlock>(GetWidgetFromName("MonsterName"));
	MonsterNameText->SetText(Name);
}

void UCombatDetailConditionWidget::SetConditions(const TArray<FBuffState>& BuffStates, const TArray<FPointVaryUnitAttributeState>& UnitAttributes)
{
	ConditionListWidget->ClearList();

	UCMS* CMS = GetCMS();
	if (!CMS)
	{
		return;
	}

	TArray<FBuffState> BuffConditions = BuffStates;

	BuffConditions.Sort([CMS](const FBuffState& ConditionA, const FBuffState& ConditionB)
	{
		const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(ConditionA.BuffType));
		if (BuffRow.Infinity)
		{
			return true;
		}

		return (ConditionA.Duration < ConditionB.Duration);
	});

	int32 Index = 0;
	for (const FBuffState& Condition : BuffConditions)
	{
		UCombatDetailConditionStateWidget* ElementWidget = nullptr;

		const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(Condition.BuffType));
		if (BuffRow.FollowMoment != EMoment::None
			&& BuffRow.FollowMoment != EMoment::AtFirstSpawn
			&& BuffRow.FollowMoment != EMoment::AtSpawn)
		{
			const TArray<const FCMSSkillRow*> FollowMomentSkills = BuffRow.GetFollowMomentSkill();
			for (const FCMSSkillRow* FollowMomentSkill : FollowMomentSkills)
			{
				FSkillType MomentSkillType = FollowMomentSkill->CmsType();
				if (MomentSkillType == SkillTypeInvalid)
				{
					continue;
				}

				ElementWidget = CastChecked<UCombatDetailConditionStateWidget>(ConditionListWidget->FindOrAddChild(Index));
				ElementWidget->SetMomentCondition(BuffRow.FollowMoment, MomentSkillType, Condition);
				++Index;
			}
		}

		const TArray<const FCMSBuffEffectRow*>& BuffEffectRows = BuffRow.GetBuffEffect();
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			check(BuffEffectRow);

			if (BuffEffectRow->BuffEffectCategory == EBuffEffectCategory::ModifyUnitAttribute)
			{
				ElementWidget = CastChecked<UCombatDetailConditionStateWidget>(ConditionListWidget->FindOrAddChild(Index));
				ElementWidget->SetUnitAttributeCondition(BuffEffectRow, Condition);
				++Index;
			}
			else if (BuffEffectRow->BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
			{
				const FCMSCrowdControlRow& Row = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
				if (Row.CrowdControl == ECrowdControl::Versa)
				{
					continue;
				}

				ElementWidget = CastChecked<UCombatDetailConditionStateWidget>(ConditionListWidget->FindOrAddChild(Index));
				ElementWidget->SetCrowdControlCondition(Row, BuffEffectRow, Condition);
				++Index;
			}
			else
			{
				Q6JsonLogSunny(Error, "UCombatDetailConditionStateWidget::SetBuff - Not found buff effect category", Q6KV("EBuffEffectCategory", (int32)BuffEffectRow->BuffEffectCategory));
			}
		}
	}

	for (const FPointVaryUnitAttributeState& UnitAttribute : UnitAttributes)
	{
		UCombatDetailConditionStateWidget* ElementWidget = nullptr;

		ElementWidget = CastChecked<UCombatDetailConditionStateWidget>(ConditionListWidget->FindOrAddChild(Index));
		ElementWidget->SetPointVaryUnitAttributeCondition(UnitAttribute);
		++Index;
	}
}

//////////////////////////////////////////////////////////////////////////
// UCombatDetailPopupWidget

void UCombatDetailPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetCharacterAnim = GetWidgetAnimationFromName(this, "AnimSetCharacter");
	SetMonsterAnim = GetWidgetAnimationFromName(this, "AnimSetMonster");
	SkillEnabledAnim = GetWidgetAnimationFromName(this, "AnimSkillEnabled");
	SkillDisabledAnim = GetWidgetAnimationFromName(this, "AnimSkillDisabled");

	CharacterSelectBox = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CharacterSelect"));
	CharacterSelectBox->OnToggleButtonClickedDelegate.BindUObject(this, &UCombatDetailPopupWidget::OnCharacterSelected);

	UButton* CharacterButton = CastChecked<UButton>(GetWidgetFromName("Character"));
	CharacterButton->OnClicked.AddUniqueDynamic(this, &UCombatDetailPopupWidget::OnCharacterButtonClicked);

	UButton* MonsterButton = CastChecked<UButton>(GetWidgetFromName("Monster"));
	MonsterButton->OnClicked.AddUniqueDynamic(this, &UCombatDetailPopupWidget::OnMonsterButtonClicked);

	UButton* YesButton = CastChecked<UButton>(GetWidgetFromName("Yes"));
	YesButton->OnClicked.AddUniqueDynamic(this, &UCombatDetailPopupWidget::ClosePopup);

	// character panel
	CharacterNameText = CastChecked<UTextBlock>(GetWidgetFromName("CharacterName"));
	JokerImage = CastChecked<UImage>(GetWidgetFromName("TagJoker"));

	UltSkillLevelText = CastChecked<UTextBlock>(GetWidgetFromName("UltLevel"));
	UltSkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("UltName"));
	UltSkillDescText = CastChecked<URichTextBlock>(GetWidgetFromName("UltDesc"));
	UltSkillIcon = CastChecked<UImage>(GetWidgetFromName("UltIcon"));
	SupportSkillLevelText = CastChecked<UTextBlock>(GetWidgetFromName("SupportLevel"));
	SupportSkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SupportName"));
	SupportSkillDescText = CastChecked<URichTextBlock>(GetWidgetFromName("SupportDesc"));
	SupportSkillIcon = CastChecked<UImage>(GetWidgetFromName("SupportIcon"));

	HPStatWidget = CastChecked<UCombatDetailStatWidget>(GetWidgetFromName("HP"));
	ATKStatWidget = CastChecked<UCombatDetailStatWidget>(GetWidgetFromName("ATK"));
	DEFStatWidget = CastChecked<UCombatDetailStatWidget>(GetWidgetFromName("DEF"));

	SculptureNameText = CastChecked<UTextBlock>(GetWidgetFromName("SculptureName"));
	SculptureDescText = CastChecked<URichTextBlock>(GetWidgetFromName("SculptureEffects"));
	RelicNameText = CastChecked<UTextBlock>(GetWidgetFromName("RelicName"));
	RelicDescText = CastChecked<URichTextBlock>(GetWidgetFromName("RelicEffects"));

	CharacterConditionWidget = CastChecked<UCombatDetailConditionWidget>(GetWidgetFromName("CharacterCondition"));

	// monster panel
	FString WidgetNameStr;
	UCombatDetailConditionWidget* MonsterConditionWidget;
	for (int32 n = 1; n <= CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT; ++n)
	{
		WidgetNameStr = FString::Printf(TEXT("Monster%d"), n);
		MonsterConditionWidget = CastChecked<UCombatDetailConditionWidget>(GetWidgetFromName(*WidgetNameStr));
		MonsterConditionWidget->SetVisibility(ESlateVisibility::Collapsed);
		MonsterConditionWidgets.AddUnique(MonsterConditionWidget);
	}
}

static void _ValidateUnitStates(TArray<FCCUnitState>& InOutUnitStates, int32 InMaxCount)
{
	TArray<FCCUnitState> ValidUnitStates;
	for (int32 i = 0; i < InMaxCount; ++i)
	{
		FCCUnitId CachedUnitId = CCUnitIdInvalid;
		for (const FCCUnitState& UnitState : InOutUnitStates)
		{
			bool bCurSlotUnit = UnitState.Slot - 1 == i;
			if (!bCurSlotUnit)
			{
				continue;
			}

			if (ValidUnitStates.IsValidIndex(i))
			{
				bool bLaterUnit = CachedUnitId.X < UnitState.UnitId.X;
				if (bLaterUnit)
				{
					ValidUnitStates[i] = UnitState;
				}
			}
			else
			{
				ValidUnitStates.Add(UnitState);
			}
		}
	}

	InOutUnitStates = ValidUnitStates;
	return;
}

void UCombatDetailPopupWidget::Init(FCCUnitId InUnitId)
{
	AllyUnits.Empty();
	EnemyUnits.Empty();

	AllyUnits = GetCheckedCombatPresenter(this)->FindAliveUnitPerSlotByFaction(ECCFaction::Ally);
	EnemyUnits = GetCheckedCombatPresenter(this)->FindAliveUnitPerSlotByFaction(ECCFaction::Enemy);

	SetMonstersInfo();

	TArray<FText> CharacterNames;
	TArray<TSoftObjectPtr<UTexture2D>> CharacterIcons;
	for (const AUnit* Unit : AllyUnits)
	{
		if (!Unit)
		{
			continue;
		}

		const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(Unit->GetUnitType());
		const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(UnitRow.Model);

		CharacterNames.Add(UnitRow.DescName);
		CharacterIcons.Add(CharacterAssetRow.CombatIconTexture);
	}
	CharacterSelectBox->SetToggleButtonBox(CharacterNames, CharacterIcons);

	int32 SelectedCharacterIndex = INDEX_NONE;
	for (const AUnit* Unit : AllyUnits)
	{
		if (!Unit)
		{
			continue;
		}

		ensure(Unit->GetUnitId() != CCUnitIdInvalid);

		CharacterSelectBox->SetButtonEnabled(Unit->GetSlot() - 1, !Unit->IsDead());

		if (Unit->GetUnitId() == InUnitId)
		{
			if (Unit->IsDead())
			{
				SelectedCharacterIndex = GetFirstAliveCharacterIndex();
			}
			else
			{
				SelectedCharacterIndex = Unit->GetSlot() - 1;
			}
		}
	}

	if (SelectedCharacterIndex != INDEX_NONE)
	{
		CharacterSelectBox->SetSelectedIndex(SelectedCharacterIndex);
		PlayAnimation(SetCharacterAnim);
		return;
	}

	PlayAnimation(SetMonsterAnim);
}

void UCombatDetailPopupWidget::SetMonstersInfo()
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	const int32 WaveEnemyNumSlots = GetCheckedCombatPresenter(this)->GetWaveEnemyNumSlots();

	for (const AUnit* Unit : EnemyUnits)
	{
		if (!Unit)
		{
			continue;
		}

		ensure(Unit->GetUnitId() != CCUnitIdInvalid);

		if (Unit->IsDead())
		{
			continue;
		}

		int32 Index = Unit->GetSlot() - 1;
		if (!MonsterConditionWidgets.IsValidIndex(Index))
		{
			continue;
		}

		const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(Unit->GetUnitType());
		MonsterConditionWidgets[Index]->SetMonsterInfo(Unit->GetSlot(), WaveEnemyNumSlots, UnitRow.DescName);

		const FUnitState& UnitState = Unit->GetUnitState();
		MonsterConditionWidgets[Index]->SetConditions(UnitState.Buffs, UnitState.PointVaryUnitAttributes);
		MonsterConditionWidgets[Index]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

static int32 _GetTotalVary(int64 InConst, int64 InVary, int64 InVaryper)
{
	int64 Total = ((InConst + InVary) * (1000 + InVaryper)) / 1000;
	return Total - InConst;
}

void UCombatDetailPopupWidget::SetCharacterInfo(int32 InIndex)
{
	if (!AllyUnits.IsValidIndex(InIndex))
	{
		return; 
	}

	const AUnit* Unit = AllyUnits[InIndex];
	if (!Unit)
	{
		Q6JsonLogPawn(Warning, "Unit is nullptr", Q6KV("Index", InIndex));
		return;
	}
	const FUnitState& State = Unit->GetUnitState();

	const UCMS* CMS = GetCMS();
	check(CMS);

	// name
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(FUnitType(State.UnitType));
	CharacterNameText->SetText(UnitRow.DescName);

	// joker
	switch (State.Category)
	{
		case EAttributeCategory::SystemJoker:
		case EAttributeCategory::FriendJoker:
		case EAttributeCategory::RecommendJoker:
			JokerImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			break;
		default:
			JokerImage->SetVisibility(ESlateVisibility::Collapsed);
			break;
	}

	// skills
	SetCharacterSkillInfo(State);
	PlayAnimation(State.Category == EAttributeCategory::RecommendJoker ? SkillDisabledAnim : SkillEnabledAnim);

	// stats
	HPStatWidget->SetValues(State.MaxHealth, 0);

	ATKStatWidget->SetValues(State.UnitAttributes.Attack,
		_GetTotalVary(State.UnitAttributes.Attack, State.UnitAttributes.AttackVary, State.UnitAttributes.AttackVaryPercent));
	DEFStatWidget->SetValues(State.UnitAttributes.Defense,
		_GetTotalVary(State.UnitAttributes.Defense, State.UnitAttributes.DefenseVary, State.UnitAttributes.DefenseVaryPercent));

	// equips
	if (State.Sculpture.Type == SculptureTypeInvalid)
	{
		SculptureNameText->SetVisibility(ESlateVisibility::Collapsed);
		SculptureDescText->SetText(Q6Util::GetLocalizedText("Combat", "ItemEmpty"));
	}
	else
	{
		const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(State.Sculpture.Type);
		SculptureNameText->SetText(SculptureRow.DescName);
		SculptureNameText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		if (!SculptureRow.GetBuff().Num())
		{
			SculptureDescText->SetText(Q6Util::GetLocalizedText("Combat", "ItemNoEffect"));
		}
		else
		{
			FString EffectsStr = GetEquipEffectsStr(State.Sculpture.Tier, SculptureRow.GetBuff());
			SculptureDescText->SetText(FText::FromString(EffectsStr));
		}
	}

	if (State.Relic.Type == RelicTypeInvalid)
	{
		RelicNameText->SetVisibility(ESlateVisibility::Collapsed);
		RelicDescText->SetText(Q6Util::GetLocalizedText("Combat", "ItemEmpty"));
	}
	else
	{
		const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(State.Relic.Type);
		RelicNameText->SetText(RelicRow.DescName);
		RelicNameText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		if (!RelicRow.GetBuff().Num())
		{
			RelicDescText->SetText(Q6Util::GetLocalizedText("Combat", "ItemNoEffect"));
		}
		else
		{
			FString EffectsStr = GetEquipEffectsStr(State.Relic.Tier, RelicRow.GetBuff());
			RelicDescText->SetText(FText::FromString(EffectsStr));
		}
	}

	// buffs
	CharacterConditionWidget->SetConditions(State.Buffs, State.PointVaryUnitAttributes);
}

void UCombatDetailPopupWidget::SetCharacterSkillInfo(const FUnitState& State)
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	FText LevelText = Q6Util::GetLocalizedText("Common", "Level");

	int32 ModelType = CMS->GetModelTypeFromUnitType(State.UnitType);
	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(ModelType);

	// ult skill
	if (State.Ultimates.IsValidIndex(0))
	{
		const FSkillState& UltSkillState = State.Ultimates[0];

		FText UltLevelText = FText::Format(LevelText, FText::AsNumber(UltSkillState.Level));
		UltSkillLevelText->SetText(UltLevelText);

		const FCMSSkillRow& UltSkillRow = CMS->GetSkillRowOrDummy(UltSkillState.SkillType);
		UltSkillNameText->SetText(UltSkillRow.DescName);
		UltSkillDescText->SetText(BuildToolTipDesc(UltSkillState.SkillType, UltSkillState.Level, ESkillCategory::Ultimate));

		UltSkillIcon->SetBrush(SkillAssetRow.UltimateIcon);
	}

	// support skill
	if (State.Supports.IsValidIndex(0))
	{
		const FSkillState& SupportSkillState = State.Supports[0];

		FText SupportLevelText = FText::Format(LevelText, FText::AsNumber(SupportSkillState.Level));
		SupportSkillLevelText->SetText(SupportLevelText);

		const FCMSSkillRow& SupportSkillRow = CMS->GetSkillRowOrDummy(SupportSkillState.SkillType);
		SupportSkillNameText->SetText(SupportSkillRow.DescName);
		SupportSkillDescText->SetText(BuildToolTipDesc(SupportSkillState.SkillType, SupportSkillState.Level, ESkillCategory::Support));
	}

	SupportSkillIcon->SetBrush(SkillAssetRow.SupportIcon);
}

int32 UCombatDetailPopupWidget::GetFirstAliveCharacterIndex() const
{
	for (int32 i = 0; i < AllyUnits.Num(); ++i)
	{
		const AUnit* Unit = AllyUnits[i];
		if (!Unit)
		{
			continue;
		}

		if (Unit->IsDead())
		{
			continue;
		}

		return i;
	}

	return INDEX_NONE;
}

void UCombatDetailPopupWidget::OnCharacterSelected(int32 InIndex)
{
	SetCharacterInfo(InIndex);
}

void UCombatDetailPopupWidget::OnCharacterButtonClicked()
{
	int32 FirstAliveCharacterIndex = GetFirstAliveCharacterIndex();
	if (FirstAliveCharacterIndex == INDEX_NONE)
	{
		OnMonsterButtonClicked();
	}
	else
	{
		CharacterSelectBox->SetSelectedIndex(FirstAliveCharacterIndex);
		PlayAnimation(SetCharacterAnim);
	}
}

void UCombatDetailPopupWidget::OnMonsterButtonClicked()
{
	PlayAnimation(SetMonsterAnim);
}
