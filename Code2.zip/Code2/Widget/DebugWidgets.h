// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "UMG.h"
#include "Q6GameState.h"
#include "DebugWidgets.generated.h"

class ACombatCube;
class UTextBlock;

UCLASS()
class Q6_API UDebugCombatWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UDebugCombatWidget(const FObjectInitializer& ObjectInitializer);

	void NativeConstruct() override;

	void OnTargetSelected();

	void SetCombatPresenterStateText(FText DebugText);

	UFUNCTION(BlueprintCallable)
	void ToggleNoDamage();

	UFUNCTION(BlueprintCallable)
	void ToggleImmune();

	UFUNCTION(BlueprintImplementableEvent)
	void SetNoDamageState(int32 FlagValue);

	UFUNCTION(BlueprintImplementableEvent)
	void SetImmuneState(int32 FlagValue);

	UFUNCTION(BlueprintImplementableEvent)
	void SetTargetInfo(FCCUnitState InUnitState, FCMSUnitRow UnitRow);

	void SaveTargetInfoFromServer(const FCCUnitState& InUnitState) { TargetInfoFromServer = InUnitState; }

protected:
	UFUNCTION(BlueprintCallable)
	void CheatTargetUnitAttribute(EUnitAttribute InUnitAttribute, bool bCheat, int32 InValue);

	UFUNCTION(BlueprintCallable)
	void CheatUA(int32 InUA);

	UFUNCTION(BlueprintCallable)
	void CheatSA(int32 InSA);

	UFUNCTION(BlueprintCallable)
	void CheatHealth(int32 InHealth);

	UFUNCTION(BlueprintCallable)
	void CheatOverKill(int32 InOverKill);

	UFUNCTION(BlueprintCallable)
	void CheatBuff(int32 InBuffType, bool bInUltimate, int32 InDuration);

	UFUNCTION(BlueprintCallable)
	void CheatReplaceUnit(int32 InUnitType);

	UFUNCTION(BlueprintCallable)
	void ResetCooldown(int32 InSkillId);

	UFUNCTION(BlueprintCallable)
	void KillAllEnemies();

	UFUNCTION(BlueprintCallable)
	int32 GetTargetUnitAttribute(EUnitAttribute InUnitAttribute);

	UFUNCTION(BlueprintCallable)
	FText GetSkillName(int32 SkillType);

private:
	UFUNCTION()
	void OnKillClicked();

	UFUNCTION()
	void OnRebirthClicked();

	UFUNCTION()
	void OnSelectAlly1();

	UFUNCTION()
	void OnSelectAlly2();

	UFUNCTION()
	void OnSelectAlly3();

	void SelectAlly(int32 SlotNum);

	ACombatCube* GetCombatCube();

	UPROPERTY()
	UTextBlock* CombatPresenterText;

	UPROPERTY()
	FCCUnitState TargetInfoFromServer;
};
