// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatTextWidget.h"

#include "CCEvent.h"
#include "CombatHUD.h"
#include "CombatPresenter.h"
#include "Unit.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6Define.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "WidgetUtil.h"

void UCombatDamageTextWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DamageText = CastChecked<UTextBlock>(GetWidgetFromName("TextDamage"));
	DodgeText = CastChecked<UTextBlock>(GetWidgetFromName("TextDodge"));
	HealText = CastChecked<UTextBlock>(GetWidgetFromName("TextHeal"));

	ExtraDamageBox = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxExtraDamage"));
	ExtraDamageText = CastChecked<UTextBlock>(GetWidgetFromName("TextExtraDamage"));

	NormalTextAnim = GetWidgetAnimationFromName(this, "AnimNormalHit");
	CriticalTextAnim = GetWidgetAnimationFromName(this, "AnimCriticalHit");
	DodgeTextAnim = GetWidgetAnimationFromName(this, "AnimDodgeHit");
	ShieldAnim = GetWidgetAnimationFromName(this, "AnimShield");
	HealTextAnim = GetWidgetAnimationFromName(this, "AnimHeal");
	HealBlockAnim = GetWidgetAnimationFromName(this, "AnimHealBlock");

	NatureRelationStrongAnim = GetWidgetAnimationFromName(this, "AnimStrong");
	NatureRelationWeakAnim = GetWidgetAnimationFromName(this, "AnimWeak");
}

bool UCombatDamageTextWidget::InitCombatText(FCCUnitId TargetUnitId, ENatureRelationType NatureRelationType, int32 BaseValue, int32 ExtraValue, EHealthChangeReason Reason, bool bDodged, bool bCritical, bool bShield, bool bMultiple, bool bAddRandomOffset)
{
	if (TargetUnitId == CCUnitIdInvalid)
	{
		return false;
	}

	FVector Offset = DefaultOffset;
	if (bMultiple)
	{
		Offset += MultipleDamageAdditionalOffset;
	}

	FVector2D ViewportPosition;
	if (!GetCheckedCombatHUD(this)->GetViewportPosition(TargetUnitId, NAME_None, Offset, ReservedSize, ViewportPosition))
	{
		return false;
	}

	if (bAddRandomOffset)
	{
		float RandomOffsetX = FMath::RandRange(RandomOffsetMin.X, RandomOffsetMax.X);
		float RandomOffsetY = FMath::RandRange(RandomOffsetMin.Y, RandomOffsetMax.Y);
		ViewportPosition += FVector2D(RandomOffsetX, RandomOffsetY);
	}

	SetPositionInViewport(ViewportPosition);

	switch (Reason)
	{
		case EHealthChangeReason::Damage:
			{
				SetDamageTextAnim(BaseValue, ExtraValue, bDodged, bCritical);
				SetNatureRelationAnim(NatureRelationType, bDodged, bShield);
			}
			break;
		case EHealthChangeReason::Heal:
		case EHealthChangeReason::Sucking:
			{
				SetHealTextAnim(BaseValue);
			}
			break;
		case EHealthChangeReason::HealBlock:
			{
				SetHealBlockAnim();
			}
			break;
		default:
			Q6JsonLogSunny(Warning, "UCombatTextDamageWidget::InitCombatText - Invalid HealthChange Reason", Q6KV("Reason", (uint8)Reason));
			return false;
	}

	return true;
}

void UCombatDamageTextWidget::SetHealTextAnim(int32 InHeal)
{
	HealText->SetText(FText::AsNumber(FMath::Abs(InHeal)));

	CurrentTextAnim = HealTextAnim;
	CurrentNatureAnim = nullptr;
}

void UCombatDamageTextWidget::SetDamageTextAnim(int32 InBaseDamage, int32 InExtraDamage, bool bInDodged, bool bInCritical)
{
	if (bInDodged)
	{
		DodgeText->SetText(FText::AsNumber(FMath::Abs(InBaseDamage)));
	}
	else
	{
		DamageText->SetText(FText::AsNumber(FMath::Abs(InBaseDamage)));

		int32 ExtraDamageValue = FMath::Abs(InExtraDamage);
		if (ExtraDamageValue > 0)
		{
			ExtraDamageText->SetText(FText::AsNumber(ExtraDamageValue));
			ExtraDamageBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
		else
		{
			ExtraDamageBox->SetVisibility(ESlateVisibility::Collapsed);
		}
	}

	if (bInDodged)
	{
		CurrentTextAnim = DodgeTextAnim;
	}
	else if (bInCritical)
	{
		CurrentTextAnim = CriticalTextAnim;
	}
	else
	{
		CurrentTextAnim = NormalTextAnim;
	}
}

void UCombatDamageTextWidget::SetNatureRelationAnim(ENatureRelationType NatureRelationType, bool bInDodged, bool bInShield)
{
	CurrentNatureAnim = nullptr;

	if (bInDodged)
	{
		return;
	}

	if (bInShield)
	{
		CurrentNatureAnim = ShieldAnim;
		return;
	}

	if (NatureRelationType == ENatureRelationType::Strong)
	{
		CurrentNatureAnim = NatureRelationStrongAnim;
	}
	else if (NatureRelationType == ENatureRelationType::Weak)
	{
		CurrentNatureAnim = NatureRelationWeakAnim;
	}
}

void UCombatDamageTextWidget::SetHealBlockAnim()
{
	CurrentTextAnim = HealBlockAnim;
	CurrentNatureAnim = nullptr;
}

void UCombatDamageTextWidget::StartCombatTextAnimation()
{
	PlayAnimation(CurrentTextAnim);
	PlayAnimation(CurrentNatureAnim);
}

void UCombatDamageTextWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	RemoveFromParent();

	CombatTextAnimationFinished.ExecuteIfBound();
}
