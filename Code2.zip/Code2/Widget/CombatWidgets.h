// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"

#include "BaseWidget.h"
#include "PointWidgets.h"
#include "WidgetUtil.h"
#include "Unit.h"
#include "CMSTable.h"
#include "LobbyHUDWidget.h"
#include "Q6Timer.h"

#include "CombatWidgets.generated.h"

class UCombatWonderSkillButtonWidget;
class UQ6Button;

DECLARE_DELEGATE_TwoParams(FTurnSkillIconClickedDelegate, const FSkillState& /*SkillState*/, int32 /*Cooldown*/);

UENUM(BlueprintType)
enum class ESkillNoteMatchState : uint8
{
	Normal,
	Matched,
	Mismatched,
	Max,
};

UENUM()
enum class ESkillGaugeType : uint8
{
	Ultimate,
	Support,
};

UENUM()
enum class EBuffNoticeType : uint8
{
	AddBuff,
	RemoveBuff,
	RemoveBuffFailed,
	ImmuneBuff,
};

UENUM()
enum class ERaidRankingTextType : uint8
{
	MyDamage,
	UserName1st,
	UserDamage1st,
	UserName2nd,
	UserDamage2nd,
	UserName3rd,
	UserDamage3rd,
	Max,
};

UENUM()
enum class ERaidEmoticonAnimType : uint8
{
	ButtonEnable,
	ButtonDisable,
	EmoticonStart,
	EmoticonEnd,
	Max,
};

UENUM()
enum class ERaidEmoticonButtonAnimType : uint8
{
	ElementNormal,
	ElementSelect,
	ElementOut,
	Max
};

UENUM()
enum class EInitialRewardEventEndType : uint8
{
	Normal,
	Special,
	ItemCard,
	Max
};

UENUM(BlueprintType)
enum class EProvokedState : uint8
{
	Default,
	Provoked,
	NonProvoked
};

USTRUCT()
struct FBuffNotice
{
	GENERATED_BODY()

	FBuffNotice()
		: NoticeType(EBuffNoticeType::AddBuff)
		, bInfinity(false), Duration(0), bLocked(false), HitCount(0)
		, EffectType(BuffEffectTypeInvalid), BuffLevel(0), BornCategory((ESkillCategory)ESkillCategoryMax)
		, FollowMoment(EMoment::None), FollowMomentSkillType(SkillTypeInvalid)
		, RemoveFailedReason(ERemoveBuffFailedReason::NoBuff)
		, ApplyTag(EApplyTag::None)
	{}
	explicit FBuffNotice(EBuffNoticeType InNoticeType, bool bInInfinity, int32 InDuration, bool bInLocked, int32 InHitCount, FBuffEffectType InEffectType, int32 InBuffLevel, ESkillCategory InBornCategory)
		: NoticeType(InNoticeType)
		, bInfinity(bInInfinity), Duration(InDuration), bLocked(bInLocked), HitCount(InHitCount)
		, EffectType(InEffectType), BuffLevel(InBuffLevel), BornCategory(InBornCategory)
		, FollowMoment(EMoment::None), FollowMomentSkillType(SkillTypeInvalid)
		, RemoveFailedReason(ERemoveBuffFailedReason::NoBuff)
		, ApplyTag(EApplyTag::None)
	{}
	explicit FBuffNotice(EBuffNoticeType InNoticeType, bool bInInfinity, int32 InDuration, bool bInLocked, int32 InHitCount, EMoment InMoment, FSkillType InSkillType, int32 InBuffLevel, ESkillCategory InBornCategory)
		: NoticeType(InNoticeType)
		, bInfinity(bInInfinity), Duration(InDuration), bLocked(bInLocked), HitCount(InHitCount)
		, EffectType(BuffEffectTypeInvalid), BuffLevel(InBuffLevel), BornCategory(InBornCategory)
		, FollowMoment(InMoment), FollowMomentSkillType(InSkillType)
		, RemoveFailedReason(ERemoveBuffFailedReason::NoBuff)
		, ApplyTag(EApplyTag::None)
	{}
	explicit FBuffNotice(ERemoveBuffFailedReason InRemoveFailedReason, EApplyTag NoApplyTag)
		: NoticeType(EBuffNoticeType::RemoveBuffFailed)
		, bInfinity(false), Duration(0), bLocked(false), HitCount(0)
		, EffectType(BuffEffectTypeInvalid), BuffLevel(0), BornCategory((ESkillCategory)ESkillCategoryMax)
		, FollowMoment(EMoment::None), FollowMomentSkillType(SkillTypeInvalid)
		, RemoveFailedReason(InRemoveFailedReason)
		, ApplyTag(NoApplyTag)
	{}
	explicit FBuffNotice(EApplyTag ImmuneTag)
		: NoticeType(EBuffNoticeType::ImmuneBuff)
		, bInfinity(false), Duration(0), bLocked(false), HitCount(0)
		, EffectType(BuffEffectTypeInvalid), BuffLevel(0), BornCategory((ESkillCategory)ESkillCategoryMax)
		, FollowMoment(EMoment::None), FollowMomentSkillType(SkillTypeInvalid)
		, RemoveFailedReason(ERemoveBuffFailedReason::NoBuff)
		, ApplyTag(ImmuneTag)
	{}

	bool IsMomentSkillNotice() const { return FollowMoment != EMoment::None; }

	EBuffNoticeType NoticeType;
	bool bInfinity;
	int32 Duration;
	bool bLocked;
	int32 HitCount;

	FBuffEffectType EffectType;
	int32 BuffLevel;
	ESkillCategory BornCategory;

	EMoment FollowMoment;
	FSkillType FollowMomentSkillType;

	ERemoveBuffFailedReason RemoveFailedReason;
	EApplyTag ApplyTag;
};

USTRUCT()
struct FPointNotice
{
	GENERATED_BODY()

	FPointNotice() : PointVaryState(EPointVaryState::Consume), TypeKeyString(FString()), ValueText(FText::GetEmpty()), bUnitAttribute(false) {}
	explicit FPointNotice(EPointVaryState InPointVaryState, const FString& InTypeKeyStr, const FText& InValueText, bool bInUnitAttribute)
		: PointVaryState(InPointVaryState), TypeKeyString(InTypeKeyStr), ValueText(InValueText), bUnitAttribute(bInUnitAttribute) {}

	EPointVaryState PointVaryState;
	FString TypeKeyString;
	FText ValueText;
	bool bUnitAttribute;
};

USTRUCT()
struct FSetSkillTimeNotice
{
	GENERATED_BODY()

	FSetSkillTimeNotice() {}
	explicit FSetSkillTimeNotice(ESetSkillTimeType InSetSkillTimeType, int32 InValue)
		: SetSkillTimeType(InSetSkillTimeType), Value(InValue) {}

	ESetSkillTimeType SetSkillTimeType;
	int32 Value;
};

class UHealthBarWidget;
class UShieldBarWidget;
class UCombatNatureGaugeWidget;
class ACombatPresenter;
class UHSEvent;
class UItemWidget;
class UItemCardWidget;
class UCombatOverKillWidget;
class URichTextBlock;
class UQ6RichTextBlock;
class USimpleItemCardWidget;
class UBondRewardWidget;
class UDynamicListWidget;
class URaidStageWidget;
class UTurnSkillIconWidget;
class UItemDropListWidget;

struct FL2CError;
struct FStageReward;
struct FBuffIcon;

static const int32 BUFF_NOTI_COUNT_MAX = 4;
static const int32 UNIT_NOTI_COUNT_MAX = 4;
static const int32 UNIT_APPLY_EFFECT_LABEL_COUNT_MAX = 3;

enum class ERemoveBuffReason : uint8;
enum class ESkillCategory : uint8;

UCLASS()
class Q6_API UBuffIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UBuffIconWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	const int32 GetBuffId() const { return BuffId; }

	void SetLocked(bool bInLocked);
	void SetMultipleText(int32 InMultiple);
	void SetBuffIcon(const FBuffIcon& InBuffIcon, bool bInLocked = false, int32 InBuffId = CCBuffIdInvalid.X, int32 InMultiple = 0, bool bNew = false, EMoment InMoment = EMoment::None);

	void SetCrowdControl(FCrowdControlType Type, bool bInLocked = false, int32 InBuffId = CCBuffIdInvalid.X, int32 InMultiple = 0, bool bNew = false, EMoment InMoment = EMoment::None);
	void SetMoment(EMoment Moment, FSkillType MomentSkillType, bool bInLocked = false, int32 InBuffId = CCBuffIdInvalid.X, int32 InMultiple = 0, bool bNew = false);
	void SetUnitAttributeBuff(FUnitAttributeType Type, int32 Value, bool bInLocked = false, int32 InBuffId = CCBuffIdInvalid.X, int32 InMultiple = 0, bool bNew = false, EMoment InMoment = EMoment::None);
	void SetBuffRemoval();
	void SetPointVary(EPointVaryState PointVaryState);

	void RemoveBuff(ERemoveBuffReason Reason);
	void ClearBuff();

private:
	UPROPERTY(Transient)
	UWidgetAnimation* DefaultBuffAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AddBuffAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RemovedBuffAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ExpiredBuffAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ClearBuffAnim;

	UPROPERTY()
	UImage* BuffIcon;

	UPROPERTY()
	UTextBlock* MultipleText;

	UPROPERTY()
	UImage* LockedImage;

	UPROPERTY()
	UImage* MomentIcon;

	int32 BuffId;
	bool bLocked;
};

UCLASS()
class Q6_API UBuffIconListWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UBuffIconListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetEmpty();
	void SetBuffs(const TArray<FBuffState>& Buffs, const TArray<FPointVaryUnitAttributeState>& PointVaryUnitAttributes, const FCCBuffId& NewBuffId);
	void RemoveBuff(int32 BuffId, ERemoveBuffReason Reason);
	void SetBuffMultiple(const FBuffState& BuffState);

private:
	static const int32 MAX_BUFF_COUNT = 9;

	UPROPERTY()
	TArray<UBuffIconWidget*> BuffIcons;
};

UCLASS()
class Q6_API UCombatBarBuffNoticeWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatBarBuffNoticeWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetEmpty();
	void PlayBuffNoticeAnimation(const FBuffEffectState& BuffEffectState, bool bCreation);

	FSimpleDelegate OnNotiAnimFinishedDelegate;

private:
	UPROPERTY(Transient)
	UWidgetAnimation* BuffCreationAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BuffExecutionAnim;

	UPROPERTY()
	UBuffIconWidget* BuffIconWidget;

	UPROPERTY()
	UBorder* BuffColorBorder;

	UPROPERTY()
	URichTextBlock* BuffText;
};

UCLASS()
class Q6_API UCombatBarBuffNoticeListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatBarBuffNoticeListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetEmptyNotices();
	void SetBuffs(const TArray<FBuffEffectState>& InBuffEffectStates, bool bInCreation);
	void AddBuff(const FBuffEffectState& InBuffEffectState, bool bInCreation);

	FBoolParamDelegate OnNotificationFinishedDelegate;

private:
	void PlayBuffNotice();

	void OnBuffNotiAnimFinished();

	UPROPERTY()
	TArray<UCombatBarBuffNoticeWidget*> NoticeWidgets;

	UPROPERTY(EditInstanceOnly)
	float ExecutionIntervalTime;

	UPROPERTY(EditInstanceOnly)
	float CreationIntervalTime;

	FTimerHandle IntervalTimerHandle;

	TArray<FBuffEffectState> BuffEffectStates;
	int32 NoticeIndex;
	bool bCreation;
};

UCLASS()
class Q6_API UCombatUnitPositionWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatUnitPositionWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	virtual void SetEmpty();

	bool IsPlayingAnim() const { return bIsPlayingAnim; }

	FSimpleDelegate OnPlayAnimFinishedDelegate;

protected:
	UPROPERTY(Transient)
	UWidgetAnimation* PlayAnim;

	bool bIsPlayingAnim;
};

UCLASS()
class Q6_API UCombatUnitPositionListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatUnitPositionListWidget(const FObjectInitializer& ObjectInitializer);

	bool SetPosition(FCCUnitId InUnitId, bool bFullView);

protected:
	virtual void SetEmptyNotices() { EntryIndex = 0; }
	virtual void OnEntryPlayAnimFinished();

protected:
	FCCUnitId UnitId;
	int32 EntryIndex;

private:
	UPROPERTY(EditDefaultsOnly, Category = "Spawn Position Offset")
	FVector DefaultOffset;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Position Offset")
	FVector CenterSlotOffset;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Position Offset")
	FVector MultiLayerOffset;

	UPROPERTY(EditDefaultsOnly, Category = "Screen Offset")
	FVector2D ReservedSize;
};

UCLASS()
class Q6_API UCombatUnitNoticeBaseWidget : public UCombatUnitPositionWidget
{
	GENERATED_BODY()

public:
	UCombatUnitNoticeBaseWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

protected:
	UPROPERTY()
	URichTextBlock* EffectText;

	UPROPERTY()
	UBuffIconWidget* BuffIconWidget;

	UPROPERTY()
	UBorder* BackColorBorder;
};

UCLASS()
class Q6_API UCombatUnitNoticeListBaseWidget : public UCombatUnitPositionListWidget
{
	GENERATED_BODY()

public:
	UCombatUnitNoticeListBaseWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeDestruct() override;

	FUnitIdParamDelegate OnNotificationFinishedDelegate;

protected:
	virtual void OnEntryPlayAnimFinished() override;

protected:
	UPROPERTY(EditDefaultsOnly)
	float IntervalTime;
	FTimerHandle IntervalTimerHandle;
};

UCLASS()
class Q6_API UCombatUnitNoticeWidget : public UCombatUnitNoticeBaseWidget
{
	GENERATED_BODY()

public:
	UCombatUnitNoticeWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void PlayBuffNoticeAnimation(const FBuffNotice& BuffNotice);
	void PlayPointNoticeAnimation(const FPointNotice& PointNotice);
	void PlaySetSkillTimeAnimation(const FSetSkillTimeNotice& InSetSkillTimeNotice);
	void PlayImmediateKillNoticeAnimation();

private:
	bool SetBuffEffect(FBuffEffectType BuffEffectType, bool bInfinity, int32 Duration, bool bLocked, int32 HitCount, int32 BuffLevel, ESkillCategory BornCategory);
	bool SetBuffEffectRemoval(FBuffEffectType BuffEffectType, int32 BuffLevel, ESkillCategory BornCategory);

	bool SetBuffMomentSkill(EMoment Moment, FSkillType MomentSkillType, bool bInfinity, int32 Duration, bool bLocked, int32 HitCount, int32 BuffLevel, ESkillCategory BornCategory);
	bool SetBuffMomentSkillRemoval(FSkillType MomentSkillType, int32 BuffLevel, ESkillCategory BornCategory);

	bool SetBuffRemovalFailed(ERemoveBuffFailedReason RemoveFailedReason, EApplyTag NoApplyTag);
	bool SetBuffImmune(EApplyTag ImmuneTag);

	bool SetPointSkillEffect(const FPointNotice& PointNotice);
	bool SetSkillTimeEffect(const FSetSkillTimeNotice& InSkillTimeNotice);
	bool SetImmediateKillSkillEffect();

	UPROPERTY()
	URichTextBlock* HitCountText;

	UPROPERTY()
	URichTextBlock* TurnCountText;
};

UCLASS()
class Q6_API UCombatUnitNoticeListWidget : public UCombatUnitNoticeListBaseWidget
{
	GENERATED_BODY()

public:
	UCombatUnitNoticeListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetBuffNotices(EBuffNoticeType BuffNoticeType, const FBuffType& BuffType, int32 BuffLevel, ESkillCategory BornCategory);
	void SetBuffRemovalFailedNotice(ERemoveBuffFailedReason Reason, EApplyTag NoApplyTag);
	void SetBuffImmuneNotice(EApplyTag ImmuneTag);
	void SetPointNotice(EPointVaryState PointVaryState, const FString& TypeKeyStr, const FText& ValueText, bool bUnitAttribute);
	void SetSkillTimeNotice(ESetSkillTimeType SetSkillTimeType, int32 Value);

	bool PlayImmediateKillNotice();

private:
	void SetEmptyNotices() override;
	void SetNoticeInternal();

	bool PlayBuffNotice();
	bool PlayPointNotice();
	bool PlaySkillTimeNotice();
	void PlayNotices();

	void OnEntryPlayAnimFinished() override;

	UPROPERTY()
	TArray<UCombatUnitNoticeWidget*> NoticeWidgets;

	TArray<FBuffNotice> BuffNotices;
	TArray<FPointNotice> PointNotices;
	TArray<FSetSkillTimeNotice> SetSkillTimeNotices;
};

UCLASS()
class Q6_API UCombatUnitStateNoticeWidget : public UCombatUnitNoticeBaseWidget
{
	GENERATED_BODY()

public:
	UCombatUnitStateNoticeWidget(const FObjectInitializer& ObjectInitializer);

	void PlayBuffNoticeAnimation(const FBuffEffectState& BuffEffectState);
};

UCLASS()
class Q6_API UCombatUnitStateNoticeListWidget : public UCombatUnitNoticeListBaseWidget
{
	GENERATED_BODY()

public:
	UCombatUnitStateNoticeListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void AddBuffNotice(const FBuffEffectState& BuffEffectState);

	FUnitIdParamDelegate OnNotificationStartDelegate;

private:
	void SetEmptyNotices() override;
	void PlayBuffNotice();
	void OnEntryPlayAnimFinished() override;

	UPROPERTY()
	TArray<UCombatUnitStateNoticeWidget*> NoticeWidgets;

	TArray<FBuffEffectState> BuffEffectStates;
};

UCLASS()
class Q6_API UCombatUnitApplyEffectLabelWidget : public UCombatUnitPositionWidget
{
	GENERATED_BODY()

public:
	UCombatUnitApplyEffectLabelWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	virtual void SetEmpty() override;

	bool IsSameMomentLabel(EMoment InMoment) const;
	void PlayMomentLabel(EMoment InMoment);

private:
	UPROPERTY()
	UTextBlock* EffectText;

	EMoment Moment;
};

UCLASS()
class Q6_API UCombatUnitApplyEffectLabelListWidget : public UCombatUnitPositionListWidget
{
	GENERATED_BODY()

public:
	UCombatUnitApplyEffectLabelListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void AddMomentLabel(EMoment InMoment);

private:
	void SetEmptyNotices() override;
	void OnEntryPlayAnimFinished() override;

	UPROPERTY()
	TArray<UCombatUnitApplyEffectLabelWidget*> LabelWidgets;
};

UCLASS()
class Q6_API UCombatAttackButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatAttackButtonWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetAttackButtonEnabled(bool bInEnabled);

	FSimpleDelegate OnAttackButtonClickedDelegate;
private:
	UFUNCTION()
	void OnAttackButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* TurnStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TurnEndAnim;
};

UCLASS()
class Q6_API UCombatSkillCastingNameWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatSkillCastingNameWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetSkill(const FText& InSkillName, ECCFaction InFaction);
	void SetSkillEnabled(bool bInEnabled);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* SkillIntroAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillOutroAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AllyPositionAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EnemyPositionAnim;

	UPROPERTY()
	UTextBlock* SkillNameText;
};

UCLASS()
class Q6_API UCombatSkillFailedWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatSkillFailedWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetSkillFailed(int32 SkillTypeX, const FApplyTagFailedInfo& FailedInfo);
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	FSimpleDelegate OnSkillFaildAnimFinishedDelegate;

private:
	UPROPERTY(Transient)
	UWidgetAnimation* SkillFailedStartAnim;

	UPROPERTY()
	UTextBlock* SkillFailedText;
};

UCLASS()
class Q6_API UCombatPointWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatPointWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetPointEnabled(bool bInEnabled);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* BubbleOnAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BubbleOffAnim;
};

UCLASS()
class Q6_API UCombatPointListWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UCombatPointListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetCooldown(int32 InCooldown);
	void SetMaxCooldown(int32 InMaxCooldown);

	int32 GetMaxCooldown() const;

private:
	UPROPERTY()
	TArray<UCombatPointWidget*> PointWidgets;

	UPROPERTY()
	int32 MaxCooldown;
};

UCLASS()
class Q6_API UCombatNatureRelationWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatNatureRelationWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetNatureRelation(ECCFaction SourceFaction, ENatureType SourceType, ENatureType TargetType);
	void DisableNatureRelation();

private:
	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> RelationAnims;

	UPROPERTY(Transient)
	UWidgetAnimation* DisabledAnim;

	UPROPERTY()
	UImage* RelationIconImage;
};

UCLASS()
class Q6_API UCombatNameBarWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatNameBarWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void InitBar(const FUnitState& UnitState);
	void SetHealthState(int32 InNewHealth, EHealthChangeReason Reason, int32 InHitIndex, int32 InHitMax, bool bAlly);

	void InitShieldBar(int32 InShield, int32 InMaxShield);
	void SetShieldState(bool bActivate);
	void SetShieldDamage(int32 InShieldDamage, int32 InExtraShieldDamage, bool bInShieldWeakPoint);
	void ChangeNature(ENatureType InNatureType);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* NatureChangeAnim;

	UPROPERTY()
	UImage* NatureIconImage;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UHealthBarWidget* HPBarWidget;

	UPROPERTY()
	UShieldBarWidget* ShieldBarWidget;
};

/**
* CombatTurnSkillStateWidget (TurnSkillStateWidgetBP)
*/
UCLASS()
class Q6_API UCombatTurnSkillStateWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatTurnSkillStateWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct();

	void Init(int32 UnitTypeX, const TArray<FSkillState>& TurnSkillStates);
	void InitPet(FPetType PetType, const TArray<FSkillState>& PetSkillStates);

	void SetSkillStates(const TArray<FSkillState>& SkillStates);
	void SetForbidden();

private:
	UPROPERTY()
	TArray<UImage*> SkillStateIcons;
};

/**
* CombatSkillNoteWidget (SkillNoteWidgetBP)
*/
UCLASS()
class Q6_API UCombatSkillNoteWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatSkillNoteWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetSkillNote(ESkillNote InSkillNote);

	UFUNCTION(BlueprintImplementableEvent)
	void SetSkillNoteMatchState(ESkillNoteMatchState InSkillNoteMatchState);

private:
	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> AceBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> BreakBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> CloserBrushes;

	UPROPERTY()
	UImage* NormalImage;

	UPROPERTY()
	UImage* MatchedImage;

	UPROPERTY()
	UImage* MismatchedImage;
};

/**
* CombatAttackStateIconWidget (AttackStateIconWidgetBP)
*/
UCLASS()
class Q6_API UCombatAttackStateIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatAttackStateIconWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetAttacking(bool bInAttacking);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* AttackingAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AttackingLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* WaitingAnim;
};

/**
* CombatAllyUltimateSkillWidget (UltBtnWidgetBP)
*/
UCLASS()
class Q6_API UCombatAllyUltimateSkillWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatAllyUltimateSkillWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void Init(FUnitType UnitType, int32 SkillTypeX);

	void SetForbidden(bool bInForbidden) { bForbidden = bInForbidden; }
	void SetClickable(bool bInClickable);
	void SetEnabled(bool bInEnabled);

	void OnSkillStart();
	void OnSkillEnd();

	FSimpleDelegate OnUltimateSkillClickedDelegate;
	FSimpleDelegate OnUltimateSkillLongClickedDelegate;
	FSimpleDelegate OnUltimateSkillStartAnimFinishedDelegate;

private:
	UFUNCTION()
	void OnSelectButtonClicked();

	UFUNCTION()
	void OnSelectButtonLongClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* LoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ClickedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ForbiddenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ForbiddenOffAnim;

	UPROPERTY()
	UImage* UltimateSkillImage;

	UPROPERTY()
	UTextBlock* UltimateSkillNameText;

	UPROPERTY()
	UQ6Button* SelectButton;

	bool bForbidden;
	bool bEnabled;
};

UCLASS()
class Q6_API UCombatAllyPortraitWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatAllyPortraitWidget(const FObjectInitializer& ObjectInitializer);

protected:
	void Init(int32 UnitTypeX, ECCTurnPhase TurnPhase);

	UPROPERTY()
	UImage* PortraitImage;
};

/**
* CombatAllyTurnSkillPortraitWidget (CharacterTurnSkillWidgetBP)
*/
UCLASS()
class Q6_API UCombatAllyTurnSkillPortraitWidget : public UCombatAllyPortraitWidget
{
	GENERATED_BODY()

public:
	UCombatAllyTurnSkillPortraitWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void Init(int32 UnitTypeX);

	void SetSelected(bool bInSelected);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* SelectedInAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SelectedLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SelectedOutAnim;
};

/**
* CombatAllyAttackPortraitWidget (CharacterAttackWidgetBP)
*/
UCLASS()
class Q6_API UCombatAllyAttackPortraitWidget : public UCombatAllyPortraitWidget
{
	GENERATED_BODY()

public:
	UCombatAllyAttackPortraitWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void Init(const FUnitState& UnitState);

	void SetForbidden(bool bInNormalSkillBlocked, bool bInUltimateSkillBlocked);
	void SetUltimateSkillEnabled(bool bInEnabled);

	void SetAttackPassed();
	void SetAttackOrder(int32 AttackOrder);
	void SetSkillNote(ESkillNote SkillNote);
	void SetSkillNoteMatched(bool bInMatched);

	void PlayChainEffect();
	void PlayDoubleSkillEffect(bool bIsOwner);

	void OnAttackStart(bool bUltimateEnabled);
	void OnSkillClicked(ESkillCategory InSkillCategory);
	void OnSkillStart();
	void OnSkillEnd();

	FSimpleDelegate OnUltimateSkillClickedDelegate;
	FSimpleDelegate OnUltimateSkillLongClickedDelegate;
	FSimpleDelegate OnUltimateSkillStartAnimFinishedDelegate;

private:
	void OnUltimateSkillClicked();
	void OnUltimateSkillLongClicked();
	void OnUltimateSkillStartAnimFinished();

	UPROPERTY(Transient)
	UWidgetAnimation* AttackStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* PassedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ClickedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NormalClickedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UltimateClickedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AttackEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillNoteMatchedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ChainEffectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DoubleAttackGiveAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DoubleAttackStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ForbiddenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ForbiddenOffAnim;

	UPROPERTY()
	UImage* AttackOrderImage;

	UPROPERTY()
	UCombatSkillNoteWidget* SkillNoteWidget;

	UPROPERTY()
	UImage* SkillNoteMatchedImage;

	UPROPERTY()
	UCombatAttackStateIconWidget* AttackStateIconWidget;

	UPROPERTY()
	UCombatAllyUltimateSkillWidget* UltimateSkillWidget;

	bool bIsDoubleSkillOwner;

	ESkillCategory SelectedSkillCategory;
};

/**
* CombatSkillGaugeFillWidget (SkillGaugeFillWidgetBP)
*/
UCLASS()
class Q6_API UCombatSkillGaugeFillWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatSkillGaugeFillWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetBrushes(const FSlateBrush& CapBrush, const FSlateBrush& FillBrush);

	void SetFullBarWidth(float InWidth) { FullBarWidth = InWidth; }
	void SetPercent(float InPercent);

	float Percent;

private:
	UPROPERTY()
	USizeBox* BarSizeBox;

	UPROPERTY()
	UImage* BarCapLImage;

	UPROPERTY()
	UImage* BarFillImage;

	UPROPERTY()
	UImage* BarCapRImage;

	float FullBarWidth;
};

/**
* CombatSkillGaugeWidget (SkillGaugeWidgetBP)
*/
UCLASS()
class Q6_API UCombatSkillGaugeWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatSkillGaugeWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	bool IsSkillOn() const { return bSkillOn; }

	void Init(EAttributeCategory InRatio, int32 InValue, int32 InMaxValue);
	void SetSkillGauge(int32 OldValue, int32 NewValue);

	UPROPERTY(EditInstanceOnly)
	ESkillGaugeType SkillGaugeType;

	UPROPERTY(EditInstanceOnly)
	float AnimationTime;

	UPROPERTY(EditInstanceOnly)
	FSlateBrush SkillGaugeBarBgBrush;

	UPROPERTY(EditInstanceOnly)
	FSlateBrush SkillOnBgBrush;

	UPROPERTY(EditInstanceOnly)
	FSlateBrush SkillOnBrush;

	UPROPERTY(EditInstanceOnly)
	TArray<FSlateBrush> SkillGaugeBarCapBrushes;

	UPROPERTY(EditInstanceOnly)
	TArray<FSlateBrush> SkillGaugeBarFillBrushes;

private:
	UFUNCTION()
	void OnProgressStart(bool bGain);

	UFUNCTION()
	void OnProgressUpdate(float TargetSectionPercent, int32 TargetSection);

	UFUNCTION()
	void OnProgressEnd(float TargetSectionPercent, int32 TargetSection, bool bActivationChanged, bool bMax);
	void OnProgressEndInternal(bool bActivationChanged, bool bMax);
	void OnSerialProgressQueueEmpty(bool bActivationChanged, bool bMax);

	UPROPERTY(Transient)
	UWidgetAnimation* UAAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SAAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* FillEffectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillActivateAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillDeactivateAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EnableAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DisableAnim;

	UPROPERTY()
	UImage* SkillOnImage;

	UPROPERTY()
	UTextBlock* PercentText;

	UPROPERTY()
	USizeBox* SkillGaugeBarSizeBox;

	UPROPERTY()
	UImage* MaxImage;

	UPROPERTY()
	TArray<UCombatSkillGaugeFillWidget*> SkillGaugeFillBars;

	UPROPERTY()
	TArray<FSkillGaugeProgressUpdateTask> SerialProgressQueue;

	int32 MaxValue;
	bool bSkillOn;

	static const int32 MAX_SKILL_GAUGE_IN_SECTION = 100;
	static const int32 MAX_SKILL_GAUGE_SECTION_COUNT = 3;
};

/**
* CombatSkillGaugeGainWidget (SkillGuageGainWidgetBP)
*/
UCLASS()
class Q6_API UCombatSkillGaugeGainWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatSkillGaugeGainWidget(const FObjectInitializer& ObjectInitializer);

	UFUNCTION(BlueprintImplementableEvent)
	void PlayGaugeGain(int32 AttackOrder, int32 PlayerCount);
};

UCLASS(Abstract)
class Q6_API UCombatUnitBarWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatUnitBarWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	virtual void InitBar(const FUnitState& UnitState, ESpawnReason Reason);
	virtual void SetSelectedBar(bool bSelected) {}
	virtual void SetPhase(ECPTurnPhase TurnPhase) {}

	void UpdateHealth(EHealthChangeReason Reason, int32 HitIndex = 0, int32 HitMax = 1);
	void SetShieldState(bool bActivate);
	void SetShieldDamage(int32 InShieldDamage, int32 InExtraShieldDamage, bool bInShieldWeakPoint);
	void SetDead(bool bInDead, bool bInWithoutAnimation = false);

	bool IsInitialized() const { return UnitId != CCUnitIdInvalid; }
	FCCUnitId GetUnitId() { return UnitId; }
	bool IsDead() { return bDead; }

	void SetBuffNoticeList(ECPTurnPhase Phase);

	void SetBuffs(const TArray<FBuffState>& Buffs, const TArray<FPointVaryUnitAttributeState>& PointVaryUnitSttributeStates, const FCCBuffId& NewBuffId);
	void SetBuffsMultiple();
	void ChangeNature(ENatureType InNatureType);

	void RemoveBuff(int32 BuffId, ERemoveBuffReason Reason);

	void AddBuffNotification(const FBuffEffectState& BuffEffectState, bool bInCreation);

	FUnitIdParamDelegate OnBarClickedDelegate;
	FUnitIdParamDelegate OnBarLongClickedDelegate;
	FSimpleDelegate OnSpawnAnimFinishedDelegate;
	FSimpleDelegate OnBuffExecutionNotiFinishedDelegate;

protected:
	void OnBuffNotiFinished(bool bCreation);

	UFUNCTION()
	void OnSelectButtonClicked() { OnBarClickedDelegate.ExecuteIfBound(UnitId); }

	UFUNCTION()
	void OnSelectButtonLongClicked() { OnBarLongClickedDelegate.ExecuteIfBound(UnitId); }

	UPROPERTY(Transient)
	UWidgetAnimation* DeadAnim;

protected:
	UPROPERTY()
	UCombatNameBarWidget* NameBarWidget;
	
	UPROPERTY()
	UCombatBarBuffNoticeListWidget* BuffNoticeListWidget;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId UnitId;

	UPROPERTY(BlueprintReadWrite)
	bool bDead;

private:
	UPROPERTY()
	UBuffIconListWidget* BuffIconListWidget;
};

DECLARE_DELEGATE_TwoParams(FSkillSelectedDelegate, FCCUnitId, FCCSkillId)

/**
* CombatAllyBarWidget (CombatCharacterBarWidgetBP)
*/
UCLASS()
class Q6_API UCombatAllyBarWidget : public UCombatUnitBarWidget
{
	GENERATED_BODY()

public:
	UCombatAllyBarWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	virtual void InitBar(const FUnitState& UnitState, ESpawnReason Reason) override;
	virtual void SetSelectedBar(bool bSelected) override;
	virtual void SetPhase(ECPTurnPhase TurnPhase) override;

	void SynchronizeCCState(ECCTurnPhase InPhase);

	int32 GetAllyBarIndex() const { return AllyBarIndex; }
	void SetAllyBarIndex(int32 InIndex) { AllyBarIndex = InIndex; }
	void SetJoker(EAttributeCategory Ratio);
	void SetTurnSkillPhaseSelectable(bool bInSelectable);

	void SetNatureRelation(ECCFaction SourceFaction, ENatureType SourceType, ENatureType TargetType);
	void DisableNatureRealtion();

	void UpdateTurnSkillStates();
	void UpdateUltimateSkillState();

	void SetUA(int32 OldUA, int32 NewUA);
	void AddUA(int32 AddedUA);
	void SetSA(int32 OldSA, int32 NewSA);
	void AddSA(int32 AddedSA);
	void SetOverKill(int32 OldOK, int32 NewOK);
	void AddOverKill(int32 AddedOK);
	void SetVersa(bool bInEnabled);

	void SetAttackPassed();
	void SetAttackOrder(int32 Order, int32 Survivors);
	void SetMatchedSkillChordNote(EApplyTag ChordNote);

	void PlayChainEffect();
	void PlayDoubleSkillEffect(bool bIsOwner);
	void PlaySkillBlockedAnimation(ESkillCategory SkillCategory);

	void OnStartWave();
	void OnSkillStart();
	void OnSkillEnd();

	FSkillSelectedDelegate OnSkillSelectedDelegate;
	FSimpleDelegate OnSkillStartAnimFinishedDelegate;

private:
	void UpdateSkillNote();
	void UpdateSkillBlocked();

	UFUNCTION()
	void OnNormalSkillClicked();

	UFUNCTION()
	void OnUltimateSkillClicked();

	UFUNCTION()
	void OnUltimateSkillStartAnimFinished();

	UPROPERTY(Transient)
	UWidgetAnimation* AliveAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TurnStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TurnEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AttackStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AttackEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DefenseStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DefenseEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ForbiddenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ForbiddenOffAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VersaStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VersaEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SummonAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RebirthAnim;

	UPROPERTY()
	UQ6Button* DetailButton;

	UPROPERTY()
	UQ6Button* TurnSelectButton;

	UPROPERTY()
	UQ6Button* AttackSelectButton;

	UPROPERTY()
	UCombatAllyTurnSkillPortraitWidget* TurnSkillPortraitWidget;

	UPROPERTY()
	UCombatAllyAttackPortraitWidget* AttackPortraitWidget;

	UPROPERTY()
	UCombatSkillGaugeWidget* UAGaugeWidget;

	UPROPERTY()
	UCombatSkillGaugeWidget* SAGaugeWidget;

	UPROPERTY()
	UCombatSkillGaugeGainWidget* SkillGaugeGainWidget;

	UPROPERTY()
	UImage* JokerImage;

	UPROPERTY()
	UCombatNatureRelationWidget* NatureRelationWidget;

	UPROPERTY()
	UCombatOverKillWidget* OverKillWidget;

	UPROPERTY()
	UBorder* VersaStateBorder;

	UPROPERTY()
	UCombatTurnSkillStateWidget* TurnSkillStateWidget;

	FCCSkillId NormalSkillId;
	FCCSkillId UltimateSkillId;

	int32 CurUA;
	int32 CurSA;
	int32 CurOK;

	bool bVersaEnabled;
	bool bSkillUsed;
	bool bNormalSkillBlocked;
	bool bUltimateSkillBlocked;
	bool bSkipDefenseEnd;
	bool bSkipUpdateUltimateState;

	int32 AllyBarIndex;
};

/**
* CombatEnemyBarWidget (CombatMonsterBarWidgetBP)
*/
UCLASS()
class Q6_API UCombatEnemyBarWidget : public UCombatUnitBarWidget
{
	GENERATED_BODY()

public:
	UCombatEnemyBarWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation);

	virtual void InitBar(const FUnitState& UnitState, ESpawnReason Reason) override;
	virtual void SetSelectedBar(bool bSelected) override;
	virtual void SetPhase(ECPTurnPhase TurnPhase) override;
	
	void UpdateUltimateSkill();
	void SynchronizeCCState(ECCTurnPhase InPhase);

	void SetSkillWaitdown(int32 Waitdown, bool bSkipDangerAnim = false);
	void SetInitialWaitdown(int32 InInitialWaitdown);

	// pattern ultimate only
	void PlayUltimateAlertAnim(bool bStart);

	int32 GetMaxSkillWaitdown() const { return SkillCooldownPointListWidget->GetMaxCooldown(); }

	UFUNCTION(BlueprintImplementableEvent, Category = "CombatEnemyBar")
	void SetProvokedState(EProvokedState InProvokedState);

private:
	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* UltimateAlertStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UltimateAlertStopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CheckedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CheckedLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UnCheckedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BossAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* MonsterAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RaidBossAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RebirthAnim;

	// Widgets

	UPROPERTY()
	UImage* BarBgImage;

	UPROPERTY()
	UCombatPointListWidget* SkillCooldownPointListWidget;

    UPROPERTY()
	UTextBlock* NickNameText;

	bool bDanger;
};

UCLASS()
class Q6_API UCombatTurnSkillWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatTurnSkillWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetIndex(int32 InIndex) { Index = InIndex; }
	void SetQuickUse(bool bInQuickUse) { bQuickUse = bInQuickUse; }

	void SetTurnSkill(const FCCUnitId& InUnitId);
	void UpdateTurnSkillState();
	void UpdateQuickSkillState(bool bInQuickUse);

	void SetSelected(bool bInSelected);

	FIntParamDelegate OnTurnSkillClickedDelegate;
	FSkillIdParamDelegate OnTurnSkillUseClickedDelegate;
	FSimpleDelegate OnTurnSkillBlockedDelegate;

private:
	UFUNCTION()
	void OnSkillUseCheckBoxChecked(bool bChecked);

	UFUNCTION()
	void OnSkillUseButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* DefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UseNormalAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UseQuickAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UsedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ForbiddenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DetailOffAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DetailOnAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY()
	UImage* TitleSkillImage;

	UPROPERTY()
	UImage* SkillImage;

	UPROPERTY()
	UTextBlock* SkillLevelText;

	UPROPERTY()
	UTextBlock* SkillNameText;

	UPROPERTY()
	URichTextBlock* SkillDescText;

	UPROPERTY()
	UTextBlock* SkillCoolTimeText;

	UPROPERTY()
	UImage* CoolTimeLeftInfiniteImage;

	UPROPERTY()
	UTextBlock* CoolTimeLeftText;

	UPROPERTY()
	UCheckBox* SkillUseCheckBox;

	UPROPERTY()
	UButton* SkillUseButton;

	int32 Index;
	FCCUnitId UnitId;
	FCCSkillId SkillId;

	bool bForbidden;
	bool bLocked;
	bool bUsed;
	bool bQuickUse;
};

UCLASS()
class Q6_API UCombatTotalDamageWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatTotalDamageWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetDamage(const UUnitHit* HitPerUnit, bool bPassOver);
	void ResetDamage() { TotalBaseDamage = 0; TotalExtraDamage = 0; }

private:
	UPROPERTY(Transient)
	UWidgetAnimation* StartDamageAnim;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> ColorAnims;

	UPROPERTY(Transient)
	UWidgetAnimation* CriticalAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShieldAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AllyPositionAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EnemyPositionAnim;

	UPROPERTY()
	UTextBlock* DamageText;

	UPROPERTY()
	UHorizontalBox* ExtraDamageBox;

	UPROPERTY()
	UTextBlock* ExtraDamageText;

	int32 TotalBaseDamage;
	int32 TotalExtraDamage;
};

UCLASS()
class Q6_API UCombatSkillBlockingWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatSkillBlockingWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetBlockEnabled(bool bBlockEnabled);

	FSimpleDelegate OnBlockButtonClickDelegate;

private:
	UFUNCTION()
	void OnBlockButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* BlockOnAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BlockOffAnim;
};

UCLASS()
class Q6_API UCombatOverKillWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatOverKillWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void Init();
	void SetOverKill(int32 OldOK, int32 NewOK);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* GetAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UseAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DisAnim;

	UPROPERTY()
	UHorizontalBox* OverKillBox;

	UPROPERTY()
	UTextBlock* CountText;
};

UCLASS()
class Q6_API UCombatChainEffectWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatChainEffectWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	bool IsPlaying() const { return GetVisibility() == ESlateVisibility::SelfHitTestInvisible; }

	void PlayChainEffect(ESkillNote InSkillNote, const FText& InSkillDesc);
	void PlayStraightChainEffect(const FText& InSkillDesc);

private:
	void PlayChainEffectInternal(const FText& InSkillDesc);

	UPROPERTY(Transient)
	UWidgetAnimation* ChainEffectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AChainAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BChainAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CChainAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SChainAnim;

	UPROPERTY()
	UTextBlock* EffectText;
};

UCLASS()
class Q6_API UCombatWaveWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatWaveWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	UFUNCTION(BlueprintImplementableEvent)
	void PlayWaveAnimation(int32 Wave, const FText& Desc, bool bIsBonusWave);

	void PlayPartyAnimation(bool bIsMainParty);
	void SetZoneName(const FText& ZoneName);

private:
	UPROPERTY()
	UCombatWavePartyTypeWidget* PartyTypeWidget;

	UPROPERTY()
	UBorder* ZoneNameGroupBorder;

	UPROPERTY()
	UTextBlock* ZoneNameText;
};

UCLASS()
class Q6_API UCombatWavePartyTypeWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatWavePartyTypeWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void PlayPartyAnimation(bool bIsMainParty);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* MainPartyAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SubPartyAnim;
};

USTRUCT(BlueprintType)
struct FTurnPhaseWidgetState
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	TAssetPtr<UMaterialInstanceConstant> EffectMI;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor BGColor;

	UPROPERTY(EditDefaultsOnly)
	FVector2D RenderScale;

	UPROPERTY(EditDefaultsOnly)
	FText Text;

	UPROPERTY(EditDefaultsOnly)
	bool bShort;
};

/**
* CombatTurnPhaseWidget (ChangeTurnWidgetBP)
*/
UCLASS()
class Q6_API UCombatTurnPhaseWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatTurnPhaseWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void PlayTurnAnimation(int32 TurnCount);
	void PlayPhaseAnimation(ECPTurnPhase TurnPhase);

	FSimpleDelegate OnTurnPhaseAnimFinishedDelegate;

private:
	void PlayTurnPhaseAnimation(const FTurnPhaseWidgetState& TurnPhaseState);

	UPROPERTY(EditDefaultsOnly)
	FTurnPhaseWidgetState StartTurnState;

	UPROPERTY(EditDefaultsOnly)
	FTurnPhaseWidgetState AttackPhaseState;

	UPROPERTY(EditDefaultsOnly)
	FTurnPhaseWidgetState OppAttackPhaseState;

	UPROPERTY(Transient)
	UWidgetAnimation* ShowAndOffAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShowAndOffShortAnim;

	UPROPERTY()
	UImage* EffLeftImage;

	UPROPERTY()
	UImage* EffRightImage;

	UPROPERTY()
	UTextBlock* TurnPhaseText;

	UPROPERTY()
	UImage* BGImage;
};

//////////////////////////////////////////////////////////////////////////
// RaidUserRankingEntryWidgetBP
//////////////////////////////////////////////////////////////////////////

UCLASS()
class Q6_API URaidUserRankingEntryWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	URaidUserRankingEntryWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetInfo(int32 InRank, const FText& InUserName, int32 InScore, bool bIsMine);

private:
	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> RankAnims;

	UPROPERTY(Transient)
	UWidgetAnimation* SetOtherAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* MyColorAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* OtherColorAnim;

	UPROPERTY()
	UImage* IconRankImage;

	UPROPERTY()
	UTextBlock* RankNumText;

	UPROPERTY()
	UTextBlock* UserNameText;

	UPROPERTY()
	UTextBlock* ScoreText;
};

UCLASS()
class Q6_API UCombatResultWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	UCombatResultWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetResult(EContentType InContentType, const ECCResult& InResult);
	void SetFailedResult(EContentType InContentType, ECCEndReason InEndResaon, ECCResult InResult);
	void SetRaidResult(const FL2CRaidStageEndResp& Resp);
	void SetRaidFinalResult(const FL2CRaidFinalStageEndResp& Resp);
	void SetReward();
	void SetRaidReward();
	void SetBond();

	// Event
	void SetEventReward(const FEventContentInfo& InEventContentInfo);

	void PlayRewardAnimation();
	void PlayRaidResultAnim(bool bInRaidFinal);

	FSimpleDelegate OnWinAnimFinishedDelegate;
	FSimpleDelegate OnCloseWidgetDelegate;

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void OnCloseWidget();
	void SetUserInfo();
	void SetRewardItems(const TArray<FItemData>& InRewardItemList, const TArray<FCurrency>& InCurrencyList, ERewardType InRewardType, FEventContentType InEventContentType = EventContentTypeInvalid);

	UFUNCTION()
	void OnTouchScreenClicked();

	UFUNCTION()
	void OnExitButtonClicked();

	UFUNCTION()
	void OnUserRankButtonClicked();

	UFUNCTION()
	void OnBackUserRankButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* WinAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RewardAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RaidRankingAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RaidRewardAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* FailedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BattleEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* GotoRankingListAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BackRankingListAnim;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	UDynamicListWidget* RankingListWidget;

	UPROPERTY()
	UTextBlock* StageNumberText;

	UPROPERTY()
	UTextBlock* StageText;

	UPROPERTY()
	UTextBlock* UserNameText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UTextBlock* TitleRankingText;

	UPROPERTY()
	UTextBlock* RankingText;

	UPROPERTY()
	UTextBlock* DamageScoreText;

	UPROPERTY()
	UTextBlock* ClearBonusText;

	UPROPERTY()
	UTextBlock* ClearBonusInfoText;

	UPROPERTY()
	UTextBlock* TurnBonusText;

	UPROPERTY()
	UTextBlock* TurnBonusInfoText;

	UPROPERTY()
	UTextBlock* SurviveBonusText;

	UPROPERTY()
	UTextBlock* SurviveBonusInfoText;

	UPROPERTY()
	UTextBlock* TotalScoreText;

	UPROPERTY()
	UTextBlock* InfoText;

	UPROPERTY()
	UTextBlock* PointGetText;

	UPROPERTY()
	UTextBlock* PointBonusGetText;

	UPROPERTY()
	UTextBlock* PointTotalText;

	UPROPERTY()
	USizeBox* LevelUpBox;

	UPROPERTY()
	UTextBlock* ExpText;

	UPROPERTY()
	UProgressBar* XpGauge;

	UPROPERTY()
	TArray<USimpleItemCardWidget*> BondWidgets;

	UPROPERTY()
	UBorder* EventPointPanelBorder;

	UPROPERTY()
	UImage* PointIconBigImage;

	UPROPERTY()
	UHorizontalBox* BonusPointBox;

	ECCResult Result;
	int32 PlayerRank;

	bool bBattleEndAnimFinished;
	EContentType ContentType;
};

UCLASS()
class Q6_API UInitialRewardEventWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UInitialRewardEventWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::InitialRewardEvent; }

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void SetRewardInfo(int32 RewardIndex);
	void SetRewardItem(const FRewardInfo& RewardInfo);
	void SetRewardText(EContentType ContentType, ESagaRewardType RewardType);
	void SetDefaultRewardText(const FCMSSagaRow& SagaRow);
	void SetSpecialRewardText(const FCMSSpecialRow& SpecialRow);

	void SetFoundRaidRewardInfo();
	void SetWonderOpen(const FContentFeatureOpenType& OpenType);
	void SetWonderReward(const FContentFeatureOpenType& OpenType);

	// About Special
	void SetSpecialOpenInfo(const FItemData& InItemData);
	void SetSpecialClearCardInfo(const FItemData& InItemData);

	void ShowNextReward();

	UFUNCTION()
	void OnTouchScreenClicked();

	UFUNCTION()
	void OnJoinButtonClicked();

	UFUNCTION()
	void OnCancelButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* StartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BgLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RewardStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RewardEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RaidStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* RaidEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SpecialStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SpecialEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ItemCardStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ItemCardEndAnim;

	UPROPERTY()
	UTurnSkillIconWidget* TurnSKillIconWidget;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UItemCardWidget* ItemCardWidget;

	UPROPERTY()
	UTextBlock* ContentText;

	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	UTextBlock* WonderNameText;

	UPROPERTY()
	UQ6RichTextBlock* InfoText;

	UPROPERTY()
	UButton* JoinButton;

	UPROPERTY()
	UButton* CancelButton;

	UPROPERTY()
	UImage* TagImage;

	UPROPERTY()
	UImage* StageIconImage;

	UPROPERTY()
	UImage* ContentBGImage;

	UPROPERTY()
	URaidStageWidget* RaidStageWidget;

	EInitialRewardEventEndType EventEndType;
	FSagaType SagaType;
	FSagaType RaidSagaType;

	bool bReqRaidOpen;
};

UCLASS()
class Q6_API UFriendRequestPopupWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void SetFriendInfo(const FFriendInfo& FriendInfo, EJokerSlotType JokerSlot);
	FSimpleDelegate OnPopupClosedDelegate;

private:
	FText GetErrorText(const FL2CError& L2CError);
	void OnJokerSetButtonClicked(const FFriendInfo& FriendInfo);

	UFUNCTION()
	void ClosePopup();

	UFUNCTION()
	void FriendRequest();

	UPROPERTY()
	UButton* CancelButton;

	UPROPERTY()
	UButton* RequestButton;
};

UCLASS()
class Q6_API URaidAssistTurnWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetInfo(const FText& InUserName
	, const FText& InSkillName
	, FCharacterType InCharacterType
	, int32 InSkillType);

	FSimpleDelegate OnRaidAssistStartAnimFinished;

private:
	void PlayRaidAssistStartAnimation();
	void SetUserNameText(const FText& InUserName);
	void SetSkillNameText(const FText& InSkillName);
	void SetCharacterPortrait(FCharacterType CharacterType);
	void SetRaidTurnSkillIcon(const FCMSUnitRow& UnitRow, int32 SkillType);

	UPROPERTY(Transient)
	UWidgetAnimation* RaidAssistStartAnim;

	UPROPERTY()
	UTextBlock* UserNameText;

	UPROPERTY()
	UTextBlock* SkillNameText;

	UPROPERTY()
	UImage* CharacterPortrait;

	UPROPERTY()
	UImage* SkillIconImage;
};

UCLASS()
class Q6_API UCombatTimeWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatTimeWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetRemainTime(const int64 InRemainTime);

	void StartTimer();

private:
	void SetRemainTime();


	UPROPERTY()
	UTextBlock* MinutesText;

	UPROPERTY()
	UTextBlock* SecondsText;

	UPROPERTY()
	UBorder* Border;

	FNumberFormattingOptions NumberFormattingOptions;
	FQ6TimerHandle CombatTimerHandle;
	int64 RemainTime;
};

UCLASS()
class Q6_API UBonusRewardMarkWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UBonusRewardMarkWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void PlayRewardMarkAnimation(EBonusRewardMarkAnimType Type);

private:
	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> MarkCheckedAnims;

	EBonusRewardMarkAnimType CurrAnimType;
};

UCLASS()
class Q6_API UBonusRewardMarkListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UBonusRewardMarkListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void InitRewardMarkList(int32 EndRewardMarkNum);
	void PlayRewardMarkListAnimation(EBonusRewardMarkAnimType Type, int32 EndRewardMarkNum);

private:
	UPROPERTY()
	TArray<UBonusRewardMarkWidget*> RewardMarks;
};

UCLASS()
class Q6_API URaidTotalBarWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	URaidTotalBarWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void InitRaidTotalHealthBar();

	void SetRaidTotalHealthHit(const int32 InNewHealth);
	void SetRaidTotalHealthLastHit();

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	UPROPERTY()
	UHealthBarWidget* HPBarWidget;

	int32 MaxTotalBarHealth;
	int32 CurTotalBarHealth;

	EHealthBarAction HealthBarAction;
};

UCLASS()
class Q6_API URaidRankingWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	URaidRankingWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetMyDamage(const int32 InDamage);
	void SetRealTimeRankInfo();

private:
	UFUNCTION()
	void OnUserListButtonClicked();

	UPROPERTY()
	TArray<UTextBlock*> RaidRankingTexts;
};

UCLASS()
class Q6_API URaidUserCharacterWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	URaidUserCharacterWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void SetRaidUserCharacterInfo(const FCharHealth& Info);

private:
	void PlayRaidUserCharacterAnimation(ERaidUserCharacterAnimType Type);

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> RaidUserCharacterAnims;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* JokerImage;

	UPROPERTY()
	UHealthBarWidget* HPBarWidget;
};

UCLASS()
class Q6_API URaidUserListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	URaidUserListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetRaidUserListInfo(const int32 Rank, const ERaidUserState State
		, const int32 TurnCount, const FText& UserName
		, const int32 Score, const bool bIsMyInfo
		, const TArray<FCharHealth>& CharacterInfos);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* StateMineAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateOtherAnim;

	UPROPERTY()
	URichTextBlock* RankRichText;

	UPROPERTY()
	URichTextBlock* GameStateRichText;

	UPROPERTY()
	UTextBlock* UserNameText;

	UPROPERTY()
	UTextBlock* ScoreText;

	UPROPERTY()
	UImage* TrophyImage;

	UPROPERTY()
	UDynamicListWidget* CharacterListWidget;
};

UCLASS()
class Q6_API URaidUserPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	URaidUserPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetRaidUserInfo();
	void StartTimer();

private:
	UFUNCTION()
	void OnDismiss();

	UPROPERTY()
	URaidUserListWidget* RaidUserMeWidget;

	UPROPERTY()
	UDynamicListWidget* RaidUserListWidget;

	FQ6TimerHandle RaidUserPopupTimerHandle;
};

UCLASS()
class Q6_API URaidEmoticonWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	URaidEmoticonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetInfo();

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

	UFUNCTION()
	void SetRemainTime(const int32 InRemainTimeSecs);

	UFUNCTION()
	void OnEmoticonButtonClicked();

	UFUNCTION()
	void OnEmoticonCloseButtonClicked();

	void PlayRaidEmoticonAnimation(ERaidEmoticonAnimType InType);
	void OnRaidEmoticonButtonClicked(const int32 InIndex);
	void ShowEmoticon(const int32 InEmoticon, const FString& InUserName);
	void EmoticonTimer();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> RaidEmoticonAnims;

	UPROPERTY()
	UTextBlock* SecondText;

	UPROPERTY()
	UDynamicListWidget* EmoticonListWidget;

	UPROPERTY()
	TArray<URaidEmoticonButtonWidget*> EmoticonButtons;

	UPROPERTY()
	TArray<URaidEmoticonShowWidget*> Emoticons;

	int32 CurSelectedEmoticonIndex;
	int32 RemainTimeSecs;
	int32 EmoticonIndex;
	FQ6TimerHandle IntervalTimerHandle;
};

UCLASS()
class Q6_API URaidEmoticonShowWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	URaidEmoticonShowWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetInfo();
	void ShowEmoticon(const int32 InIndex, const FString& InUserName);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* EmoticonShowAnim;

	UPROPERTY()
	UTextBlock* UserNameText;

	UPROPERTY()
	UImage* EmoticonImage;

	FVector2D EmoticonOriginPos;
};

UCLASS()
class Q6_API URaidEmoticonButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	URaidEmoticonButtonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetInfo(int32 InIndex);
	void PlayRaidEmoticonButtonAnimation(ERaidEmoticonButtonAnimType InType);

	FIntParamDelegate RaidEmoticonButtonClickedDelegate;

private:
	UFUNCTION()
	void OnElementButtonClicked();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> RaidEmoticonButtonAnims;

	UPROPERTY()
	UImage* EmoticonImage;

	int32 RaidEmoticonButtonIndex;
};

UCLASS()
class Q6_API UBondUpResultWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UBondUpResultWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	virtual void RefreshMenu() override;

	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::BondUpResult; }

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void SetInfos();
	void SetInfo(const FBondLevelUpReward& InBondReward);
	void SetReward(const TArray<FBondReward>& Rewards);
	void ShowNextReward();

	UFUNCTION()
	void AddBondLevel();

	UFUNCTION()
	void OnTouchScreenClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* StartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BondUpAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BondRewardAnim;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* NatureImage;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* NickNameText;

	UPROPERTY()
	UTextBlock* TemperatureText;

	UPROPERTY()
	USizeBox* SupportBox;

	UPROPERTY()
	UTextBlock* CurrentSupportLevelText;

	UPROPERTY()
	UTextBlock* ResultSupportLevelText;

	UPROPERTY()
	UImage* IconSupportSkillImage;

	UPROPERTY()
	TArray<UItemWidget*> ItemWidgets;

	UPROPERTY()
	TArray<UBondRewardWidget*> BondRewards;

	const FBondLevelUpReward* BondReward;

	int32 NumOfLvUpCharacters;
	int32 CurrentCharacterIndex;
	int32 CurrentBondTemperature;

	bool bTempUp;

	float TempUpStartTime;
	float ElapsedTime;
};

UCLASS()
class Q6_API UCombatWipeoutWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetWipeout();

private:
	UFUNCTION()
	void OnArtifactButtonClicked(FCCSkillId SkillId, int32 SkillType, FCCUnitId TargetUnitId, ESkillCategory SkillCategory);

	UFUNCTION()
	void OnUseGemButtonClicked();

	UFUNCTION()
	void OnWithdrawButtonClicked();

	void OnGemShopPurchase(EConfirmPopupFlag Option);
	void OnArtifactRebirth(EConfirmPopupFlag Option);
	void OnGemRebirth();

	UPROPERTY()
	UItemDropListWidget* ItemDropListWidget;

	UPROPERTY()
	UCombatWonderSkillButtonWidget* ArtifactButtonWidget;

	UPROPERTY()
	UPointWidget* OwnedGemWidget;

	UPROPERTY()
	UPointWidget* RequiredGemWidget;

	UPROPERTY()
	UButton* UseGemButton;

	int32 WipeoutCount;
};

UCLASS()
class Q6_API UBackTurnButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UBackTurnButtonWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetOn(bool bOn);

	FSimpleDelegate OnBackButtonClickedDelegate;
private:
	UFUNCTION()
	void OnBackButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* AnimOn;

	UPROPERTY(Transient)
	UWidgetAnimation* AnimOff;
};

UCLASS()
class Q6_API UCombatMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCombatMenuWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void OpenWidget();

private:
	void OnWithdrawButtonClicked();
	void OnResumeButtonClicked();
	void OnSettingButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* OpenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CloseAnim;

	UPROPERTY()
	UImage* MascotImage;

	UPROPERTY()
	UQ6TextBlock* MascotText;

	UPROPERTY()
	UItemDropListWidget* ItemDropListWidget;

	UPROPERTY()
	UQ6TextBlock* NoItemText;

	UPROPERTY()
	UQ6Button* WithdrawButton;

	UPROPERTY()
	UQ6Button* ResumeButton;

	UPROPERTY()
	UQ6Button* SettingButton;
};
