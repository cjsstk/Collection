// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "LobbyHUDWidget.h"
#include "StageWidgets.h"
#include "EventWidgets.generated.h"

class UPointWidget;
class UEventRewardPopupWidget;
class UDynamicListWidget;
class URewardItemWidget;
class UEventShopWidget;
class UUniformGridPanel;
class UAvatarIconWidget;

static const int32 MAX_EVENT_CURRENCY_TYPE = 4;

USTRUCT()
struct FEventStageInfo
{
	GENERATED_BODY()

	FEventStageInfo() :
		EventStageType(0),
		SagaType(SagaTypeInvalid),
		StageState(EStageState::New),
		StartDate(0),
		ClearCount(0),
		ReplayLimit(0)
	{}

	FEventStageInfo(
		int32 InEventStageType,
		FSagaType InSagaType, 
		EStageState InStageState,
		int64 InStartDate,
		int32 InClearCount,
		int32 InReplayLimit) :
		EventStageType(InEventStageType),
		SagaType(InSagaType),
		StageState(InStageState),
		StartDate(InStartDate),
		ClearCount(InClearCount),
		ReplayLimit(InReplayLimit)
	{}

	int32 EventStageType;
	FSagaType SagaType;
	EStageState StageState;
	int64 StartDate;

	int32 ClearCount;
	int32 ReplayLimit;
};

/**
 * EventPageWidgetBP
 */
UCLASS()
class Q6_API UEventPageWidget : public UUserWidget
{
	GENERATED_BODY()
	
public:
	UEventPageWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void SetPage(FEventContentType InEventContentType);

	UFUNCTION(BlueprintImplementableEvent)
	void SetEventPageWidgetContentState(bool bLocked);

private:
	UFUNCTION()
	void OnEventButtonClicked();

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UTextBlock* EventPeriodText;

	FEventContentType EventContentType;
};

/**
 * EventMainWidgetBP
 */
UCLASS()
class Q6_API UEventMainWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UEventMainWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void OnLeaveMenu() override;
	virtual void RefreshMenu() override;

	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;
	virtual bool OnBack() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Event; }

private:
	UFUNCTION()
	void OnEventShopButtonClicked();

	UFUNCTION()
	void OnEventStageButtonClicekd();

	UFUNCTION()
	void OnRewardInfoButtonClicekd();

	void OpenEventShopWidget();

	// Main Info
	void SetEventInfo();
	void SetPeriod();
	void SetOwnedItem();

	// Stage
	void SetEventStage();

	// ValentineDay
	bool IsStageConditionOK(const FCMSEventContentValentineDayRow* ValentineDayRow, const TArray<FEventContentCategoryInfo>& PlayedStages) const;
	void AddValentineStageInfo(
		const TArray<FEventContentCategoryInfo>& PlayedStages,
		const FEventScheduleInfo* ScheduleInfo,
		const FCMSEventContentValentineDayRow* ValentineDayRow,
		int32 NumberOfDays,
		TArray<FEventStageInfo>& OutValentineStageInfos);

	// Multiside
	bool AddMultisidePlayedStage(const TArray<FEventContentCategoryInfo>& PlayedStages, const FCMSEventContentMultiSideBattleStageRow* Iter, int64 StartDate, TArray<FEventStageInfo>& OutPlayedStagesInfo, TArray<FEventStageInfo>& OutRepeatableStagesInfo);
	bool AddMultisideLockedPeriodStage(const TArray<FEventContentCategoryInfo>& PlayedStages, const FCMSEventContentMultiSideBattleStageRow* Iter, int32 NumberOfDays, int64 StartDate, TArray<FEventStageInfo>& OutLockedPeriodStagesInfo);
	bool AddMultisidePlayableStage(const TArray<FEventContentCategoryInfo>& PlayedStages, const FCMSEventContentMultiSideBattleStageRow* Iter, int64 StartDate, TArray<FEventStageInfo>& OutPlayableStagesInfo);
	bool AddMultisideLockedConditionStage(const FCMSEventContentMultiSideBattleStageRow* Iter, int32 NumberOfDays, int64 StartDate, TArray<FEventStageInfo>& OutLockedConditionStagesInfo);
	
private:
	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UEventShopWidget> EventShopWidgetClass;

	UPROPERTY(Transient)
	UWidgetAnimation* MainStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StageSelectStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateEventAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateMultiBattleAnim;

	UPROPERTY()
	UEventShopWidget* EventShopWidget;

	UPROPERTY()
	UImage* EventBgImage;

	UPROPERTY()
	UImage* EventLogoImage;

	UPROPERTY()
	UImage* EventPointIconImage;

	UPROPERTY()
	TArray<UPointWidget*> EventCurrencyWidgets;

	UPROPERTY()
	UTextBlock* EventDetailText;

	UPROPERTY()
	UTextBlock* EventPointText;

	UPROPERTY()
	UTextBlock* PeriodText;

	UPROPERTY()
	UTextBlock* ShopOpenPeriodText;

	UPROPERTY()
	UTextBlock* BonusDetailText;

	UPROPERTY()
	UBorder* StageListGroupWidget;

	UPROPERTY()
	UBorder* MultiBattleDetailGroupBorder;

	UPROPERTY()
	UBorder* MultiBattleWattBorder;

	UPROPERTY()
	UTextBlock* OwnMultiBattleWattText;

	UPROPERTY()
	UTextBlock* MaxMultiBattleWattText;

	UPROPERTY()
	UDynamicListWidget* StageListWidget;

	UPROPERTY()
	UUniformGridPanel* EventStageGroupWidget;

	UPROPERTY()
	UImage* EventStageButtonImage;

	UPROPERTY()
	UImage* EventShopButtonImage;

	UPROPERTY()
	UEventRankWidget* EventRankWidget;

	UPROPERTY()
	USizeBox* ChallengeGroupSizeBox;

	UPROPERTY()
	UStageEntryWidget* ChallengeStageWidget;

	FEventContentType EventContentType;
};

/**
 * EventRewardPopupWidgetBP
 */
UCLASS()
class Q6_API UEventRewardPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UEventRewardPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction);

	void SetRewardInfos(FEventContentType InEventContentType);
	void SetRankRewardInfos(FEventContentType InEventContentType);

	void SetRankInfos(FEventContentType InEventContentType);

	// Combat
	void SetCombatRewardInfos(FEventContentType InEventContentType, int32 InReceivedPoint);

private:
	UPROPERTY()
	UDynamicListWidget* EventRewardListWidget;

	UPROPERTY()
	UDynamicListWidget* EventRankRewardListWidget;

	UPROPERTY()
	UDynamicListWidget* EventRankListWidget;
};

/**
 * EventRewardListWidgetBP
 */
UCLASS()
class Q6_API UEventRewardListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UEventRewardListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	
	void SetRewardInfo(const FCMSEventContentAccumPointRewardRow* InEventContentAccumPointRewardRow, int32 InCurrentPoint);
	void SetCombatRewardInfo(const FCMSEventContentAccumPointRewardRow* InEventContentAccumPointRewardRow, int32 InCurrentPoint, ERewardState RewardState);

private:
	void SetPoint(FEventContentType InEventContentType, int32 InAccumPoint);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* StateNotYetAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateNowGetAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateGottenAnim;

	UPROPERTY()
	UImage* EventPointIconImage;

	UPROPERTY()
	UTextBlock* PointTermText;

	UPROPERTY()
	URewardItemWidget* RewardItemWidget;
};

/**
 * EventShopWidgetBP
 */
UCLASS()
class Q6_API UEventShopWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	UEventShopWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void SetEventShop(FEventContentType InEventContentType);

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

	void SetPoints();

private:
	UPROPERTY(Transient)
	UWidgetAnimation* EventShopStartAnim;

	UPROPERTY()
	TArray<UPointWidget*> EventCurrencyWidgets;

	UPROPERTY()
	UDynamicListWidget* GeneralShopListWidget;

	UPROPERTY()
	UImage* EventBgImage;

	UPROPERTY()
	UImage* BGShopImage;

	UPROPERTY()
	UTextBlock* ShopOpenPeriodText;

	FEventContentType EventContentType;
};

/**
 * EventRankWidgetBP
 */
UCLASS()
class Q6_API UEventRankWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UEventRankWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetRank(FEventContentType InEventContentType);

private:
	UFUNCTION()
	void OnEventRankListClicked();

	UFUNCTION()
	void OnRankRewardClicked();

private:
	UPROPERTY(Transient)
	UWidgetAnimation* StateRewardNormalAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateRewardActLoopAnim;

	UPROPERTY()
	UTextBlock* RankGroupText;

	UPROPERTY()
	UTextBlock* MyRankText;

	UPROPERTY()
	UImage* TrophyImage;

	FEventContentType EventContentType;
};

UENUM()
enum class EEventRankState
{
	Normal,
	Get,
	Gotten,
	Activate,
	Deactivate
};

/**
 * EventRankRewardListWidgetBP
 */
UCLASS()
class Q6_API UEventRankRewardListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UEventRankRewardListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetRewardInfo(const FCMSEventContentMultiSideBattleRewardRow* RewardRow, const TArray<const FCMSUserTitleRow*>& MultiSideBattleRankerUserTitleRows);
	void SetExpiredRewardInfo(const FCMSEventContentMultiSideBattleRewardRow* RewardRow, const TArray<const FCMSUserTitleRow*>& MultiSideBattleRankerUserTitleRows, bool bActive, bool bReceived);

private:
	UFUNCTION()
	void OnRewardGetClicked();

	void SetRewardInfoInternal(const FCMSEventContentMultiSideBattleRewardRow* RewardRow, const TArray<const FCMSUserTitleRow*>& MultiSideBattleRankerUserTitleRows);

	void PlayStateAnim(EEventRankState InEventRankState);
	void SetItemList(const FCMSEventContentMultiSideBattleRewardRow* RewardRow);

private:
	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> StateAnimations;

	UPROPERTY()
	UDynamicListWidget* RankRewardItemListWidget;

	UPROPERTY()
	UTextBlock* RankTermText;

	UPROPERTY()
	UTextBlock* AkaGetText;

	FEventContentType EventContentType;
	static const int32 MAX_NUM_OF_REWARD_ITEM = 3;
};

/**
 * EventRankListWidgetBP
 */
UCLASS()
class Q6_API UEventRankListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UEventRankListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void SetInfo(FEventContentType InEventContentType, const FEventContentMultiSideBattleSimpleInfo& InSimpleInfo);

private:
	void SetAvatar(const FAvatarInfo& AvatarInfo);

private:
	UPROPERTY()
	UBorder* AkaNameBorder;

	UPROPERTY()
	UTextBlock* AkaNameText;

	UPROPERTY()
	UTextBlock* UserNameText;

	UPROPERTY()
	UTextBlock* UserRankCountText;

	UPROPERTY()
	UTextBlock* AccountLevelText;

	UPROPERTY()
	UPointWidget* EventCurrencyWidget;

	UPROPERTY()
	UImage* ReputationBadgeImage;

	UPROPERTY()
	UImage* TrophyImage;

	UPROPERTY()
	UAvatarIconWidget* AvatarWidget;
};
