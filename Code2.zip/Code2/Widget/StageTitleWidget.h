#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "UMG.h"

#include "StageTitleWidget.generated.h"

class UUMGSequencePlayer;

struct FCMSSagaRow;

UCLASS()
class UStageTitleWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UStageTitleWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetStageTitle(const FCMSSagaRow& SagaRow);
	void SetTextBorderColor(const FLinearColor& Color);

	FSimpleDelegate OnTitleEnd;

	void Start();

private:
	UPROPERTY()
	UWidgetAnimation* StageNameStartAnim;

	UPROPERTY()
	UWidgetAnimation* StageNameEndAnim;

	UPROPERTY()
	UTextBlock* StageNameText;

	UPROPERTY()
	UTextBlock* StageNumText;
};
