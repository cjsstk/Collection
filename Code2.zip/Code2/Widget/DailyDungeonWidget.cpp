#include "DailyDungeonWidget.h"
#include "CharacterManager.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "LobbyPlayerController.h"
#include "NewMarkManager.h"
#include "DailyDungeonManager.h"
#include "SWipeWidgets.h"
#include "Q6.h"
#include "WidgetUtil.h"
#include "Q6SaveGame.h"
#include "Q6GameInstance.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent DailyDungeon"), STAT_OnHSEventByDailyDungeon, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Daily Dungeon Menu Widget
//////////////////////////////////////////////////////////////////////////
void UDailyDungeonMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RewardImage = CastChecked<UImage>(GetWidgetFromName("RewardItem"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	MenuButton = CastChecked<UQ6Button>(GetWidgetFromName("Menu"));
	MenuButton->OnClicked.AddUniqueDynamic(this, &UDailyDungeonMenuWidget::OnMenuButtonClicked);
}

void UDailyDungeonMenuWidget::SetDailyDungeonMenu(EDailyDungeonCategory InDungeonCategory, EDayOfWeekType InCurrentShowDay, int32 Stage)
{
	const FDailyDungeonAssetRow& DailyDungeonAssetRow = GetGameResource().GetDailyDungeonAssetRow(InCurrentShowDay);

	switch (InDungeonCategory)
	{
		case EDailyDungeonCategory::Promote:
			RewardImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.PromoteTexture);
			break;
		case EDailyDungeonCategory::Xp:
			RewardImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.XpTexture);
			break;
		case EDailyDungeonCategory::Gold:
			RewardImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.GoldTexture);
			break;
	}

	bool bNewMarkVisible = GetHUDStore().GetNewMarkManager().GetDailyDungeonVisible(InCurrentShowDay, InDungeonCategory, Stage);
	SetNewMark(bNewMarkVisible);
	SetDailyDungeonInfoText(InDungeonCategory);
}

void UDailyDungeonMenuWidget::SetNewMark(bool bInVisible)
{
	NewMarkImage->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UDailyDungeonMenuWidget::OnMenuButtonClicked()
{
	OnMenuClickedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////
// Daily Dungeon Info Widget
//////////////////////////////////////////////////////////////////////////
void UDailyDungeonInfoWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DailyCharacterImage = CastChecked<UImage>(GetWidgetFromName("DailyCharacter"));
	ExplanationText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Explanation"));
	SpeakerText = CastChecked<UTextBlock>(GetWidgetFromName("TextSpeaker"));
}

void UDailyDungeonInfoWidget::SetInfo(EDayOfWeekType InDayType)
{
	const FDailyDungeonAssetRow& DailyDungeonAssetRow = GetGameResource().GetDailyDungeonAssetRow(InDayType);

	DailyCharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.IllustTexture);
	ExplanationText->SetText(DailyDungeonAssetRow.Explanation);
	SpeakerText->SetText(DailyDungeonAssetRow.CharacterName);
}

//////////////////////////////////////////////////////////////////////////
// Daily Dungeon Page Widget
//////////////////////////////////////////////////////////////////////////
void UDailyDungeonPageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DailyDungeonRewardAnim = GetWidgetAnimationFromName(this, "AnimDailyDungeonReward");
	check(DailyDungeonRewardAnim);
	DailyDungeonSetPageAnim = GetWidgetAnimationFromName(this, "AnimDailyDungeonSetPage");
	check(DailyDungeonSetPageAnim);
	DailyDungeonLockAnim = GetWidgetAnimationFromName(this, "AnimDailyDungeonLock");
	check(DailyDungeonLockAnim);

	DailyImage = CastChecked<UImage>(GetWidgetFromName("DailyThumb"));
	DayText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Week"));
	DayDescText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Title"));
	DailyCharacterImage = CastChecked<UImage>(GetWidgetFromName("DailyCharacter"));
	RewardImage = CastChecked<UImage>(GetWidgetFromName("RewardItem"));
	InitialRewardWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
}

void UDailyDungeonPageWidget::SetDefaultPage(EDayOfWeekType InDayOfWeekType)
{
	SetPage(InDayOfWeekType);
}

void UDailyDungeonPageWidget::SetRewardPage(EDailyDungeonCategory InDungeonCategory, EDayOfWeekType InCurrentShowDay)
{
	switch (InDungeonCategory)
	{
		case EDailyDungeonCategory::Promote:
		{
			const FDailyDungeonAssetRow& DailyDungeonAssetRow = GetGameResource().GetDailyDungeonAssetRow(InCurrentShowDay);
			RewardImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.PromoteTexture);
			break;
		}
		case EDailyDungeonCategory::Xp:
		{
			const FDailyDungeonAssetRow& DailyDungeonAssetRow = GetGameResource().GetDailyDungeonAssetRow(InCurrentShowDay);
			DailyImage->SetBrushFromSoftTextureWhenLoadingFinished(XpBGTexture);
			RewardImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.XpTexture);
			break;
		}
		case EDailyDungeonCategory::Gold:
		{
			const FDailyDungeonAssetRow& DailyDungeonAssetRow = GetGameResource().GetDailyDungeonAssetRow(InCurrentShowDay);
			DailyImage->SetBrushFromSoftTextureWhenLoadingFinished(GoldBGTexture);
			RewardImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.GoldTexture);
			break;
		}
		default:
			break;
	}

	PlayAnimation(DailyDungeonRewardAnim);
}

void UDailyDungeonPageWidget::SetPage(EDayOfWeekType InDayOfWeekType)
{
	const FDailyDungeonAssetRow& DailyDungeonAssetRow = GetGameResource().GetDailyDungeonAssetRow(InDayOfWeekType);

	DailyImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.BGTexture);
	DailyCharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(DailyDungeonAssetRow.IllustTexture);

	DayText->SetColorAndOpacity(DailyDungeonAssetRow.DayColor);
	DayText->SetText(DailyDungeonAssetRow.Name);
	DayDescText->SetText(DailyDungeonAssetRow.Description);

	const UDailyDungeonManager& DailyMgr = GetHUDStore().GetDailyDungeonManager();
	EDayOfWeekType TodayOfWeekType = DailyMgr.GetDayOfWeekType();
	SetInitialReward(InDayOfWeekType);

	bool bEnabledDungeon = (InDayOfWeekType == TodayOfWeekType);
	bool bIsFirstRewardOfToday = bEnabledDungeon && DailyMgr.IsFirstRewardOfToday();
	InitialRewardWidget->SetChecked(bIsFirstRewardOfToday);

#if !UE_BUILD_SHIPPING
	if (UQ6GameInstance::Get(this)->IsDevMode())
	{
		bEnabledDungeon = true;
	}
#endif
	PlayAnimation(bEnabledDungeon ? DailyDungeonSetPageAnim : DailyDungeonLockAnim);
}

void UDailyDungeonPageWidget::SetInitialReward(EDayOfWeekType InDayOfWeekType)
{
	const UCMS* CMS = GetCMS();
	const FCMSDailyFirstClearRewardRow& ClearRewardRow = CMS->GetDailyFirstClearRewardRowByDayOfWeek(InDayOfWeekType);
	const FCMSLootDataRow& LootRow = CMS->GetFirstLootDataOrDummyFromLootGroups(ClearRewardRow.GetLootGroup());

	InitialRewardWidget->SetRewardType(ERewardType::First);
	InitialRewardWidget->SetLoot(LootRow.LootId, LootRow.Count);
}

//////////////////////////////////////////////////////////////////////////
// Daily Dungeon Widget
//////////////////////////////////////////////////////////////////////////
void UDailyDungeonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EDayOfWeekType DungeonToday = GetHUDStore().GetDailyDungeonManager().GetDayOfWeekType();
	CurrentShowDay = DungeonToday;

	SwipeWidget = CastChecked<UPageSwipeWidget>(GetWidgetFromName("Swipe"));
	SwipeWidget->OnSetPageDelegate.BindUObject(this, &UDailyDungeonWidget::OnSetDailyDungeonPage);
	SwipeWidget->OnFocusedPageDelegate.BindUObject(this, &UDailyDungeonWidget::OnDailyPageChanged);
	SwipeWidget->SetPageCount(MAX_DAY_COUNT, (int32)CurrentShowDay + 1);

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("Menu"));

	PromoteMenuWidget = CastChecked<UDailyDungeonMenuWidget>(GetWidgetFromName("Promote"));
	PromoteMenuWidget->OnMenuClickedDelegate.BindUObject(this, &UDailyDungeonWidget::OnDailyDungeonMenuClicked, EDailyDungeonCategory::Promote);

	XpMenuWidget = CastChecked<UDailyDungeonMenuWidget>(GetWidgetFromName("XP"));
	XpMenuWidget->OnMenuClickedDelegate.BindUObject(this, &UDailyDungeonWidget::OnDailyDungeonMenuClicked, EDailyDungeonCategory::Xp);

	GoldMenuWidget = CastChecked<UDailyDungeonMenuWidget>(GetWidgetFromName("Gold"));
	GoldMenuWidget->OnMenuClickedDelegate.BindUObject(this, &UDailyDungeonWidget::OnDailyDungeonMenuClicked, EDailyDungeonCategory::Gold);

	StageListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("StageList"));
	InfoWidget = CastChecked<UDailyDungeonInfoWidget>(GetWidgetFromName("Info"));
}

void UDailyDungeonWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::DailyDungeon);
}

void UDailyDungeonWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FDailyDungeonUIState* UIState = GetUIState()->CastToDailyDungeonUIState();
	if (!UIState)
	{
		return;
	}

	const EDailyDungeonMenuType MenuType = UIState->MenuType;
	const EDailyDungeonCategory DungeonCategory = UIState->DungeonCategory;

	SwipeWidget->SetSwipeEnabled(MenuType != EDailyDungeonMenuType::StageList);

	MenuSwitcher->SetActiveWidgetIndex((int32)MenuType);

	switch (MenuType)
	{
		case EDailyDungeonMenuType::Main:
			SetDailyDungeonMenu();
			break;
		case EDailyDungeonMenuType::Info:
			SetDailyDungeonInfo();
			break;
		case EDailyDungeonMenuType::StageList:
			SetDailyDungeonStage(DungeonCategory);
			break;
	}
}

bool UDailyDungeonWidget::IsPlayed(int32 StageList, int32 Stage)
{
	return (StageList & (1 << Stage)) != 0;
}

bool UDailyDungeonWidget::IsLockedStage(int32 StageList, int32 Stage)
{
	int32 PrevStage = Stage - 1;
	if (PrevStage < 0)
	{
		return false;
	}

	return !IsPlayed(StageList, PrevStage);
}

EStageState UDailyDungeonWidget::GetStageState(EDailyDungeonCategory InDungeonCategory, const FDailyDungeonRecord& InDailyDungeonList, const FCMSDailyDungeonRow* InDungeonRow)
{
	const FCMSSagaRow& SagaRow = InDungeonRow->GetSaga();
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UDailyDungeonWidget::GetStageState - No SagaRow");
		check(false);
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	bool bValidLevel = WorldUser.GetLevel().x >= InDungeonRow->MinLevel && WorldUser.GetLevel().x <= InDungeonRow->MaxLevel;
#if !UE_BUILD_SHIPPING
	if (UQ6GameInstance::Get(this)->IsDevMode())
	{
		bValidLevel = true;
	}
#endif

	if (!bValidLevel)
	{
		return EStageState::LockedByCondition;
	}

	int32 Stage = FMath::Abs(SagaRow.Stage - 1);	// Making 0-based for bit operation
	bool bIsPlayed = true;
	switch (InDungeonCategory)
	{
		case EDailyDungeonCategory::Promote:
			if (IsLockedStage(InDailyDungeonList.Promote, Stage))
			{
				return EStageState::LockedByStage;
			}

			bIsPlayed = IsPlayed(InDailyDungeonList.Promote, Stage);
			break;
		case EDailyDungeonCategory::Xp:
			if (IsLockedStage(InDailyDungeonList.Xp, Stage))
			{
				return EStageState::LockedByStage;
			}

			bIsPlayed = IsPlayed(InDailyDungeonList.Xp, Stage);
			break;
		case EDailyDungeonCategory::Gold:
			if (IsLockedStage(InDailyDungeonList.Gold, Stage))
			{
				return EStageState::LockedByStage;
			}

			bIsPlayed = IsPlayed(InDailyDungeonList.Gold, Stage);
			break;
	}

	return bIsPlayed ? EStageState::Normal : EStageState::New;
}

void UDailyDungeonWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByDailyDungeon);

	switch (Action->GetActionType())
	{
		case EHSActionType::DailyDungeonStageList:
		case EHSActionType::DailyDungeonPageChange:
		case EHSActionType::DailyListResp:
		case EHSActionType::DevWattConsumeResp:
		case EHSActionType::DevWattRechargeResp:
		case EHSActionType::WattRechargeResp:
			RefreshMenu();
			break;
		case EHSActionType::ContentsResetTime:
			GetHUDStore().GetDailyDungeonManager().ReqDailyList(false);
			break;
	}
}

void UDailyDungeonWidget::OnDailyDungeonMenuClicked(EDailyDungeonCategory InDungeonCategory)
{
	ACTION_DISPATCH_DailyDungeonStageList(InDungeonCategory);
}

void UDailyDungeonWidget::SetDailyDungeonMenu()
{
	UDailyDungeonPageWidget * PageWidget = CastChecked<UDailyDungeonPageWidget>(SwipeWidget->GetFocusedWidget());
	if (!PageWidget)
	{
		Q6JsonLogRoze(Error, "UDailyDungeonWidget::OnDailyPageChanged - Not found page");
		return;
	}

	PageWidget->SetDefaultPage(CurrentShowDay); // EDayOfWeekType is 0-base

	const FDailyDungeonRecord& History = GetHUDStore().GetDailyDungeonManager().GetHistory(CurrentShowDay);
	PromoteMenuWidget->SetDailyDungeonMenu(EDailyDungeonCategory::Promote, CurrentShowDay, History.Promote);
	XpMenuWidget->SetDailyDungeonMenu(EDailyDungeonCategory::Xp, CurrentShowDay, History.Xp);
	GoldMenuWidget->SetDailyDungeonMenu(EDailyDungeonCategory::Gold, CurrentShowDay, History.Gold);
}

void UDailyDungeonWidget::SetDailyDungeonInfo()
{
	InfoWidget->SetInfo(CurrentShowDay);
}

void UDailyDungeonWidget::SetDailyDungeonStage(EDailyDungeonCategory InDungeonCategory)
{
	UWidget* FocusedSwipeWidget = SwipeWidget->GetFocusedWidget();
	if (FocusedSwipeWidget == nullptr)
	{
		return;
	}

	UDailyDungeonPageWidget* PageWidget = CastChecked<UDailyDungeonPageWidget>(FocusedSwipeWidget);
	check((int32)CurrentShowDay >= 0);

	PageWidget->SetRewardPage(InDungeonCategory, CurrentShowDay);

	StageListWidget->ClearList();

	const UCMS* CMS = GetCMS();
	check(CMS);

	const TArray<const FCMSDailyDungeonRow*> DungeonRows = CMS->GetDailyDungeonValidRows(CurrentShowDay);
	if (!DungeonRows.IsValidIndex(0))
	{
		Q6JsonLogGunny(Warning, "UDailyDungeonWidget::SetDailyDungeonStage - No Dungeon rows!");
		return;
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	const FDailyDungeonRecord& DailyDungeonClearList = GetHUDStore().GetDailyDungeonManager().GetHistory(CurrentShowDay);

	bool bShowUnlockedStage = false;
	for (const FCMSDailyDungeonRow* DungeonRow : DungeonRows)
	{
		if (bShowUnlockedStage)	// show one LockedStage
		{
			break;
		}

		UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
		EStageState StageState = GetStageState(InDungeonCategory, DailyDungeonClearList, DungeonRow);
		if (StageState == EStageState::LockedByStage)
		{
			bShowUnlockedStage = true;
		}

		EntryWidget->SetDailyEntryWidget(DungeonRow, StageState);
	}
}

void UDailyDungeonWidget::OnDailyPageChanged(int32 NewPage)
{
	EDayOfWeekType NewShowDay = (EDayOfWeekType)(NewPage - 1);	// EDayOfWeekType is 0-base
	if (CurrentShowDay != NewShowDay)
	{
		CurrentShowDay = NewShowDay;

		EDayOfWeekType DungeonToday = GetHUDStore().GetDailyDungeonManager().GetDayOfWeekType();
		bool bEnalbedDailyDungeon = CurrentShowDay == DungeonToday;
#if !UE_BUILD_SHIPPING
		if (UQ6GameInstance::Get(this)->IsDevMode())
		{
			bEnalbedDailyDungeon = true;
		}
#endif
		ACTION_DISPATCH_DailyDungeonPageChange(bEnalbedDailyDungeon ?
			EDailyDungeonMenuType::Main : EDailyDungeonMenuType::Info);
	}
}

void UDailyDungeonWidget::OnSetDailyDungeonPage(UWidget* ViewWidget, int32 PageNum)
{
	UDailyDungeonPageWidget* PageWidget = CastChecked<UDailyDungeonPageWidget>(ViewWidget);
	PageWidget->SetDefaultPage((EDayOfWeekType)(PageNum - 1)); // EDayOfWeekType is 0-base
}
