// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "Q6ScrollBox.h"
#include "Widgets/Layout/SScrollBox.h"
#include "Framework/Layout/InertialScrollManager.h"

SQ6SnapScrollBox::SQ6SnapScrollBox()
{
	DescendantScrollThresHold = 0.001f;
	DescendantScroll = EDescendantScroll::No;
	bDoSnapTracking = false;
}

void SQ6SnapScrollBox::Construct(const FArguments& InArgs)
{
	SScrollBox::Construct(SScrollBox::FArguments()
		.Style(InArgs._Style)
		.ScrollBarStyle(InArgs._ScrollBarStyle)
		.Orientation(InArgs._Orientation)
		.NavigationDestination(InArgs._NavigationDestination)
		.NavigationScrollPadding(InArgs._NavigationScrollPadding)
		.ConsumeMouseWheel(InArgs._ConsumeMouseWheel)
		.OnUserScrolled(InArgs._OnUserScrolled));

	DescendantScrollThresHold = InArgs._DescendantScrollThresHold;
	SnapVelocity = InArgs._SnapVelocity;
	OnDescendantScrolled = InArgs._OnDescendantScrolled;
	OnSnapTrackingFired = InArgs._OnSnapTrackingFired;
}

void SQ6SnapScrollBox::ScrollToDescendant(const TSharedPtr<SWidget>& WidgetToFind, float InPadding)
{
	EndInertialScrolling();
	ScrollDescendantIntoView(WidgetToFind, true, EDescendantScrollDestination::TopOrLeft, InPadding);
	DescendantScroll = EDescendantScroll::Scrolling;
}

void SQ6SnapScrollBox::Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime)
{
	SScrollBox::Tick(AllottedGeometry, InCurrentTime, InDeltaTime);

	if (DescendantScroll == EDescendantScroll::Scrolling)
	{
		float Offset = GetRemainScrollOffset(AllottedGeometry);
		if (Offset <= DescendantScrollThresHold)
		{
			OnDescendantScrolled.ExecuteIfBound();
			DescendantScroll = EDescendantScroll::Fired;
		}
	}
	else if (DescendantScroll == EDescendantScroll::Fired)
	{
		if (!IsScrolling())
		{
			DescendantScroll = EDescendantScroll::No;
		}
	}
	else
	{
		SnapTracking();
	}
}

FReply SQ6SnapScrollBox::OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent)
{
	FReply Reply = SScrollBox::OnMouseWheel(MyGeometry, MouseEvent);
	if (Reply.IsEventHandled())
	{
		EndInertialScrolling();
	}

	return Reply;
}

FReply SQ6SnapScrollBox::OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent)
{
	FReply Reply = SScrollBox::OnTouchEnded(MyGeometry, InTouchEvent);
	if (Reply.IsEventHandled())
	{
		bDoSnapTracking = true;
	}

	return Reply;
}

void SQ6SnapScrollBox::SnapTracking()
{
	if (!bDoSnapTracking)
	{
		return;
	}

	if (DescendantScroll != EDescendantScroll::No)
	{
		return;
	}

	if (!bIsScrollingActiveTimerRegistered)
	{
		return;
	}

	float Velocity = FMath::Abs(InertialScrollManager.GetScrollVelocity());
	if (SnapVelocity < Velocity)
	{
		return;
	}

	OnSnapTrackingFired.ExecuteIfBound();
	bDoSnapTracking = false;
}

void UQ6SnapScrollBox::ScrollToDescendant(UWidget* WidgetToFind)
{
	TSharedPtr<SWidget> SlateWidgetToFind;
	if (WidgetToFind)
	{
		SlateWidgetToFind = WidgetToFind->GetCachedWidget();
	}

	TSharedPtr<SQ6SnapScrollBox> SnapScrollBox = GetSnapScrollBox();
	if (SnapScrollBox.IsValid())
	{
		SnapScrollBox->ScrollToDescendant(SlateWidgetToFind, ScrollPadding);
	}
}

TSharedRef<SWidget> UQ6SnapScrollBox::RebuildWidget()
{
	MyScrollBox = SNew(SQ6SnapScrollBox)
		.Style(&WidgetStyle)
		.ScrollBarStyle(&WidgetBarStyle)
		.Orientation(Orientation)
		.ConsumeMouseWheel(ConsumeMouseWheel)
		.NavigationDestination(NavigationDestination)
		.NavigationScrollPadding(NavigationScrollPadding)
		.DescendantScrollThresHold(ScrollThresHold)
		.SnapVelocity(SnapVelocity)
		.OnUserScrolled(BIND_UOBJECT_DELEGATE(FOnUserScrolled, SlateHandleUserScrolled))
		.OnDescendantScrolled(BIND_UOBJECT_DELEGATE(FOnDescendantScrolled, SlateHandleDescendantScrolled))
		.OnSnapTrackingFired(BIND_UOBJECT_DELEGATE(FOnSnapTrackingFired, SlateHandleSnapTrackingFired));

	for (UPanelSlot* PanelSlot : Slots)
	{
		if (UScrollBoxSlot* TypedSlot = Cast<UScrollBoxSlot>(PanelSlot))
		{
			TypedSlot->Parent = this;
			TypedSlot->BuildSlot(MyScrollBox.ToSharedRef());
		}
	}

	return MyScrollBox.ToSharedRef();
}

TSharedPtr<SQ6SnapScrollBox> UQ6SnapScrollBox::GetSnapScrollBox() const
{
	return StaticCastSharedPtr<SQ6SnapScrollBox>(MyScrollBox);
}

void UQ6SnapScrollBox::SlateHandleDescendantScrolled()
{
	OnDescendantScrolled.ExecuteIfBound();
}

void UQ6SnapScrollBox::SlateHandleSnapTrackingFired()
{
	OnSnapTrackingFired.ExecuteIfBound();
}
