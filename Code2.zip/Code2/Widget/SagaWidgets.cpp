#include "SagaWidgets.h"
#include "HSAction.h"
#include "Q6.h"
#include "CMS/CMSTable.h"
#include "HUDStore.h"
#include "SagaManager.h"
#include "EpisodeWidgets.h"
#include "LobbyHUD.h"
#include "StageWidgets.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Saga"), STAT_OnHSEventBySaga, STATGROUP_HSTORE);

EEpisodeState GetEpisodeState(int32 Episode, int32 PlayingEpisode)
{
	if (Episode < PlayingEpisode)
	{
		return EEpisodeState::Clear;
	}

	if (Episode == PlayingEpisode)
	{
		return EEpisodeState::Progress;
	}

	return EEpisodeState::Locked;
}

USagaWidget::USagaWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void USagaWidget::NativeConstruct()
{
	Super::NativeConstruct();

	WidgetSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("SagaSwitcher"));
	EpisodeListWidget = CastChecked<UEpisodeListWidget>(GetWidgetFromName("SagaEpisode"));
	EpisodeListWidget->EpisodeSelectedDelegate.BindUObject(this, &USagaWidget::OnSelectedIcon);
	StageListWidget = CastChecked<UStageListWidget>(GetWidgetFromName("SagaStage"));

	EpisodeBgImage = CastChecked<UImage>(GetWidgetFromName("ImgEpisodeBg"));
	EpisodeChrImage = CastChecked<UImage>(GetWidgetFromName("ImgEpisodeChr"));

	ClearAnim = GetWidgetAnimationFromName(this, "AnimClear");
	InProgressAnim = GetWidgetAnimationFromName(this, "AnimInProgress");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimLocked");
	ComingSoonAnim = GetWidgetAnimationFromName(this, "AnimComingSoon");
}

void USagaWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::WorldUser);
}

void USagaWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FSagaUIState* UIState = GetUIState()->CastToSagaUIState();
	check(UIState);

	OnSelectedIcon(UIState->Episode);

	if (UIState->SagaTab == ESagaTab::Stage)
	{
		WidgetSwitcher->SetActiveWidgetIndex((int32)ESagaTab::Stage);
		StageListWidget->InitStageList(UIState->Episode);
	}
	else
	{
		WidgetSwitcher->SetActiveWidgetIndex((int32)ESagaTab::Episode);
		EpisodeListWidget->InitEpisodeList();
	}
}

void USagaWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventBySaga);

	RefreshMenu();
}

void USagaWidget::OnSelectedIcon(int32 InEpisode)
{
	const FEpisodeAssetRow& EpisodeRow = GetGameResource().GetEpisodeAssetRow(InEpisode);
	EpisodeBgImage->SetBrush(EpisodeRow.Background);
	EpisodeChrImage->SetBrush(EpisodeRow.Character);

	int32 PlayingEpisode = GetHUDStore().GetSagaManager().GetPlayingEpisode();

	switch (GetEpisodeState(InEpisode, PlayingEpisode))
	{
		case EEpisodeState::Progress:
			PlayAnimation(InProgressAnim);
			break;
		case EEpisodeState::Locked:
			PlayAnimation(LockedAnim);
			break;
		case EEpisodeState::Clear:
		default:
			PlayAnimation(ClearAnim);
			break;
	}
}
