// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6UiDefine.h"
#include "UMG.h"

#include "DialogueSelectWidget.generated.h"

class UButton;
class UTextBlock;

UCLASS()
class Q6_API UDialogueSelectWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UDialogueSelectWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetChoice(int32 Index, const FText& InText, EDialogueMode Mode);
	void PlaySelection(int32 Index);

	const FText& GetText() const;

	FIntParamDelegate OnSelected;
	FIntParamDelegate OnSelectEnd;

private:
	UFUNCTION()
	void OnChoiceButtonClicked();

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush NormalBg;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SelectedBg;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush ChatNormalBg;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush ChatSelectedBg;

	UPROPERTY(Transient)
	UWidgetAnimation* ButtonStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ButtonEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ButtonSelectedAnim;

	UPROPERTY()
	UImage* NormalBgImage;

	UPROPERTY()
	UImage* SelectedBgImage;

	UPROPERTY()
	UButton* ChoiceButton;

	UPROPERTY()
	UTextBlock* ChoiceText;

	int32 ChoiceIndex;
};
