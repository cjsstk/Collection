// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "PartyWidgets.h"

#include "BondManager.h"
#include "CharacterManager.h"
#include "CharacterWidgets.h"
#include "CombatCubeUtil.h"
#include "CommonWidgets.h"
#include "ContentFeatureOpenManager.h"
#include "GameResource.h"
#include "HSAction.h"
#include "ItemWidgets.h"
#include "JokerSetManager.h"
#include "LobbyHUD.h"
#include "NavigationBarWidgets.h"
#include "HUDStore.h"
#include "PartyManager.h"
#include "PetManager.h"
#include "PetWidgets.h"
#include "PointWidgets.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "RaidManager.h"
#include "RelicManager.h"
#include "SculptureManager.h"
#include "SortingWidgets.h"
#include "SwipeWidgets.h"
#include "TempleManager.h"
#include "HSAction.h"
#include "Formula.h"
#include "UIStateManager.h"
#include "LevelUtil.h"
#include "HUDStore/EventManager.h"


DECLARE_CYCLE_STAT(TEXT("OnHSEvent Party"), STAT_OnHSEventByParty, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent PartyPetSelectPopup"), STAT_OnHSEventByPartyPetSelectPopup, STATGROUP_HSTORE);

URegularRaidMatchTimerWidget::URegularRaidMatchTimerWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, RemainSeconds(0)
{
}

void URegularRaidMatchTimerWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RegularRaidTimerText = CastChecked<UTextBlock>(GetWidgetFromName("TextRegularRaidTimer"));
}

void URegularRaidMatchTimerWidget::NativeDestruct()
{
	FTimerManager& TimerManager = GetWorld()->GetTimerManager();
	TimerManager.ClearTimer(TimeHandle);

	Super::NativeDestruct();
}

void URegularRaidMatchTimerWidget::SetRegularRaidMatchTimerInfo(const int32 InRemainSeconds)
{
	RemainSeconds = InRemainSeconds;

	FTimerManager& TimerManager = GetWorld()->GetTimerManager();
	TimerManager.ClearTimer(TimeHandle);

	TimerManager.SetTimer(TimeHandle, this
		, &URegularRaidMatchTimerWidget::SetRegularRaidMatchTimer, 1.0f, true, 0.0f);
}

void URegularRaidMatchTimerWidget::SetRegularRaidMatchTimer()
{
	if (RemainSeconds < 0)
	{
		FTimerManager& TimerManager = GetWorld()->GetTimerManager();
		TimerManager.ClearTimer(TimeHandle);

		return;
	}

	RegularRaidTimerText->SetText(FText::AsNumber(RemainSeconds--));
}

UPartyEquipIconWidget::UPartyEquipIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPartyEquipIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UPartyEquipIconWidget::OnSelectButtonClicked);
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UPartyEquipIconWidget::OpenEquipDetail);

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));

	// Animations

	NormalAnim = GetWidgetAnimationFromName(this, "AnimDefaultEquipped");
	check(NormalAnim);

	EmptyAnim = GetWidgetAnimationFromName(this, "AnimDefaultEmptyEdit");
	check(EmptyAnim);

	DisabledAnim = GetWidgetAnimationFromName(this, "AnimDefaultEmptyNotEdit");
	check(DisabledAnim);

	EquippedAnim = GetWidgetAnimationFromName(this, "AnimPlayEquip");
	check(EquippedAnim);

	UnequippedAnim = GetWidgetAnimationFromName(this, "AnimPlayUnequip");
	check(UnequippedAnim);

	SelectAnims.Reset();
	SelectAnims.Add(GetWidgetAnimationFromName(this, "AnimItemNormal"));
	SelectAnims.Add(GetWidgetAnimationFromName(this, "AnimItemChecked"));
	SelectAnims.Add(GetWidgetAnimationFromName(this, "AnimItemSelectShow"));
	SelectAnims.Add(GetWidgetAnimationFromName(this, "AnimItemChanged"));
	SelectAnims.Add(GetWidgetAnimationFromName(this, "AnimItemDisabled"));
	check(SelectAnims.Num() == (int32)EIconSelectType::Max);
}

void UPartyEquipIconWidget::SetEmpty(bool bInEnabled)
{
	ItemInfo = FItemIconInfo();

	PlayAnimation(bInEnabled ? EmptyAnim : DisabledAnim);
}

void UPartyEquipIconWidget::SetRelic(const FRelicInfo& RelicInfo)
{
	if (RelicInfo.Type == RelicTypeInvalid)
	{
		SetEmpty(bSelectEnabled);
		return;
	}

	ConvertRelicToItemInfo(RelicInfo, &ItemInfo);

	const FEquipAssetRow& EquipAssetRow = GetGameResource().GetRelicAssetRow(RelicInfo.Type);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(EquipAssetRow.IconTexture);

	PlayAnimation(NormalAnim);
}

void UPartyEquipIconWidget::SetSculpture(const FSculptureInfo& SculptureInfo)
{
	if (SculptureInfo.Type == RelicTypeInvalid)
	{
		SetEmpty(bSelectEnabled);
		return;
	}

	ConvertSculptureToItemInfo(SculptureInfo, &ItemInfo);

	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(SculptureInfo.Type);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(SculptureAssetRow.IconTexture);

	PlayAnimation(NormalAnim);
}

void UPartyEquipIconWidget::SetSelected(EIconSelectType SelectType)
{
	bSelectEnabled = (SelectType == EIconSelectType::Disabled) ? false : true;

	if (SelectAnims.IsValidIndex((int32)SelectType))
	{
		PlayAnimation(SelectAnims[(int32)SelectType]);
	}
}

void UPartyEquipIconWidget::PlayEquipAnimation(bool bInEquipped)
{
	PlayAnimation(bInEquipped ? EquippedAnim : UnequippedAnim);
}

void UPartyEquipIconWidget::OpenEquipDetail()
{
	if (ItemInfo.IsValid())
	{
		if (ABaseHUD* HUD = GetBaseHUD(this))
		{
			HUD->OpenItemDetailPopup(ItemInfo);
		}
	}
}

void UPartyEquipIconWidget::OnSelectButtonClicked()
{
	OnEquipIconClickedDelegate.ExecuteIfBound(this);
}


UPartyIconWidget::UPartyIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bSystemJoker(false)
	, bSelectEnabled(true)
	, bViewOnly(false)
	, WidgetType(EPartyWidgetType::Party)
	, JokerSlot(EJokerSlotType::All)
	, SwapSlot(EJokerSlotType::All)
{
}

void UPartyIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Animations

	SetEditEnabled(ViewType == EPartyIconViewType::Edit);

	CharacterAddAnim = GetWidgetAnimationFromName(this, "AnimPlayEquip");
	check(CharacterAddAnim);

	CharacterRemoveAnim = GetWidgetAnimationFromName(this, "AnimPlayUnequip");
	check(CharacterRemoveAnim);

	HighlightAnims.Reset();
	HighlightAnims.Add(GetWidgetAnimationFromName(this, "AnimEnabledCharacter"));
	HighlightAnims.Add(GetWidgetAnimationFromName(this, "AnimEnabledSculpture"));
	HighlightAnims.Add(GetWidgetAnimationFromName(this, "AnimEnabledRelic"));

	// Widgets

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	NatureImage = CastChecked<UImage>(GetWidgetFromName("Nature"));
	NatureBgImage = CastChecked<UImage>(GetWidgetFromName("JokerNatureBg"));
	LevelText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("Level"));
	TotalHealthText = CastChecked<UTextBlock>(GetWidgetFromName("Health"));
	TotalAtkText = CastChecked<UTextBlock>(GetWidgetFromName("Atk"));
	TotalDefText = CastChecked<UTextBlock>(GetWidgetFromName("Def"));
	OpenLevelText = CastChecked<UTextBlock>(GetWidgetFromName("OpenLevel"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UPartyIconWidget::OnSelectButtonClicked);
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UPartyIconWidget::OpenCharacterDetail, (UPartyEquipIconWidget*)nullptr);
	OnPartyIconSelectedDelegate.BindUObject(this, &UPartyIconWidget::OpenCharacterDetail);

	SculptureIconWidget = CastChecked<UPartyEquipIconWidget>(GetWidgetFromName("Sculpture"));
	SculptureIconWidget->OnEquipIconClickedDelegate.BindUObject(this, &UPartyIconWidget::OnSculptureIconClicked);

	RelicIconWidget = CastChecked<UPartyEquipIconWidget>(GetWidgetFromName("Relic"));
	RelicIconWidget->OnEquipIconClickedDelegate.BindUObject(this, &UPartyIconWidget::OnRelicIconClicked);
}

void UPartyIconWidget::ResetPartyIcon(EPartyWidgetType InWidgetType, int32 InSlotIdx, bool bInViewOnly, bool bInIsOpenedByMultiside)
{
	WidgetType = InWidgetType;
	bViewOnly = bInViewOnly;

	SetMenu(WidgetType);

	if (bInIsOpenedByMultiside)
	{
		bSystemJoker = false;
	}
	else if (GetHUDStore().GetPartyManager().GetJokerType() == EJokerType::OwnedJoker)
	{
		bSystemJoker = false;
	}
	else
	{
		if (WidgetType == EPartyWidgetType::JokerSet)
		{
			bSystemJoker = false;
			check(IsValidEJokerSlotType(InSlotIdx));
			JokerSlot = EJokerSlotType(InSlotIdx);
			NatureBgImage->SetBrush(GetUIResource().GetJokerSlotIcon(JokerSlot));
		}
		else
		{
			bSystemJoker = (InSlotIdx == PARTY_JOKER_SLOT_INDEX);
		}
	}

	SetCharacterEmpty();
}

void UPartyIconWidget::SetItem(EPartyIconItemType InItemType, int64 InItemId)
{
	if (InItemType == EPartyIconItemType::Character)
	{
		SetCharacterById(FCharacterId(InItemId));
	}
	else if (InItemType == EPartyIconItemType::Sculpture)
	{
		SetSculptureById(FSculptureId(InItemId));
	}
	else if (InItemType == EPartyIconItemType::Relic)
	{
		SetRelicById(FRelicId(InItemId));
	}
}

void UPartyIconWidget::SetFriendJokerSlot(const FFriendJokerSlot& InJokerSlot)
{
	SetCharacter(InJokerSlot.CharacterInfo, InJokerSlot.CharacterBond);
	SetSculpture(InJokerSlot.SculptureInfo);
	SetRelic(InJokerSlot.RelicInfo);
}

void UPartyIconWidget::SetPartySlot(const FPartySlot& PartySlot)
{
	if (!PartySlot.CharacterId.IsInvalid())
	{
		SetCharacterById(PartySlot.CharacterId);
		SetSculptureById(PartySlot.SculptureId);
		SetRelicById(PartySlot.RelicId);
	}
}

void UPartyIconWidget::SetPartyJoker(const FJokerSlot& InJokerSlot)
{
	if (!InJokerSlot.CharacterId.IsInvalid())
	{
		SetCharacterById(InJokerSlot.CharacterId);
		SetSculptureById(InJokerSlot.SculptureId);
		SetRelicById(InJokerSlot.RelicId);
	}
}

void UPartyIconWidget::SetCharacterEmpty()
{
	ItemInfo = FItemIconInfo();
	SwapSlot = EJokerSlotType::All;

	SetSelected(EPartyIconItemType::Character, EIconSelectType::Deselected);
	if (WidgetType == EPartyWidgetType::JokerSet)
	{
		SetEditType(bViewOnly ? EPartyIconType::Disable : EPartyIconType::Empty);
		SculptureIconWidget->SetEmpty(!bViewOnly);
		RelicIconWidget->SetEmpty(!bViewOnly);
	}
	else
	{
		SetEditType(bSystemJoker ? EPartyIconType::EmptyJoker : EPartyIconType::Empty);
		SculptureIconWidget->SetEmpty(!bSystemJoker);
		RelicIconWidget->SetEmpty(!bSystemJoker);
	}

	SetTotalAttributes();
}

void UPartyIconWidget::SetCharacterRandom()
{
	ItemInfo = FItemIconInfo();
	SwapSlot = EJokerSlotType::All;

	SetSelected(EPartyIconItemType::Character, EIconSelectType::Deselected);
	SetEditType(EPartyIconType::RandomJoker);
	const FSlateBrush& RandomNatureBrush = GetUIResource().GetNatureTypeIcon(ENatureType::Random);
	NatureImage->SetBrush(RandomNatureBrush);
}

void UPartyIconWidget::SetSculptureEmpty()
{
	SculptureIconWidget->SetEmpty(!bSystemJoker);

	SetTotalAttributes();
}

void UPartyIconWidget::SetRelicEmpty()
{
	RelicIconWidget->SetEmpty(!bSystemJoker);

	SetTotalAttributes();
}

void UPartyIconWidget::SetSelected(EPartyIconItemType ItemType, EIconSelectType SelectType)
{
	if (ItemType != EPartyIconItemType::Character)
	{
		GetEquipIconWidget(ItemType)->SetSelected(SelectType);
		return;
	}

	bSelectEnabled = (SelectType == EIconSelectType::Disabled) ? false : true;

	SetCharacterSelected(SelectType);
}

void UPartyIconWidget::SetHighlight(EPartyIconItemType ItemType)
{
	if (HighlightAnims.IsValidIndex((int32)ItemType))
	{
		PlayAnimation(HighlightAnims[(int32)ItemType]);
	}
}

void UPartyIconWidget::PlayEquipAnimation(EPartyIconItemType ItemType, bool bInEquipped)
{
	if (ItemType == EPartyIconItemType::Character)
	{
		PlayAnimation(bInEquipped ? CharacterAddAnim : CharacterRemoveAnim);
		return;
	}

	UPartyEquipIconWidget* EquipIconWidget = GetEquipIconWidget(ItemType);
	if (EquipIconWidget)
	{
		EquipIconWidget->PlayEquipAnimation(bInEquipped);
	}
}

void UPartyIconWidget::SetCharacter(const FCharacterInfo& InCharacterInfo, const FCharacterBond& InCharacterBond)
{
	if (InCharacterInfo.CharacterId.IsInvalid())
	{
		if (!bSystemJoker)
		{
			SetCharacterEmpty();
			return;
		}

		EJokerType JokerType = GetHUDStore().GetPartyManager().GetJokerType();
		if (JokerType == EJokerType::RandomJoker)
		{
			SetCharacterRandom();
			return;
		}
	}

	if (InCharacterInfo.Type == CharacterTypeInvalid)
	{
		SetCharacterEmpty();
		return;
	}

	EAttributeCategory AttributeType = bSystemJoker ? EAttributeCategory::SystemJoker : EAttributeCategory::Character;
	ConvertCharacterToItemInfo(AttributeType, InCharacterInfo, InCharacterBond, &ItemInfo);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(InCharacterInfo.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(InCharacterInfo.Level)));

	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(InCharacterInfo.Type);
	if (JokerSlot == EJokerSlotType::All)
	{
		SwapSlot = UCMS::ToJokerSlotType(UnitRow.NatureType);
	}

	const FSlateBrush& NatureBrush = GetUIResource().GetNatureTypeIcon(UnitRow.NatureType);
	NatureImage->SetBrush(NatureBrush);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(InCharacterInfo.Type);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetLongIconTexture(InCharacterInfo.Illust));

	SetTotalAttributes();

	SetEditType(bSystemJoker ? EPartyIconType::Joker : EPartyIconType::Normal);
}

void UPartyIconWidget::SetCharacterLockedSlotInfo(const int32 SlotIdx)
{
	const FCMSContentFeatureOpenRow* ContentFeatureOpenRow = GetCMS()->GetContentFeatureOpenRowBySubPartySlotIndex(
		SlotIdx);
	if (!ContentFeatureOpenRow)
	{
		Q6JsonLogGenie(Error, "invalid content feature open row", Q6KV("SlotIndex"
			, SlotIdx));
		return;
	}

	if (ContentFeatureOpenRow->OpenValue == 0)
	{
		OpenLevelText->SetText(Q6Util::GetLocalizedText("Common", "ComingSoon"));
	}
	else
	{
		const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(
			FSagaType(ContentFeatureOpenRow->ConditionValue));
		if (SagaRow.IsInvalid())
		{
			Q6JsonLogGenie(Error, "invalid saga type", Q6KV("Type"
				, ContentFeatureOpenRow->ConditionValue));
			return;
		}

		OpenLevelText->SetText(FText::Format(
			Q6Util::GetLocalizedText("Lobby", "ContentLockedStage")
			, FText::AsNumber(SagaRow.Episode)
			, FText::AsNumber(SagaRow.Stage)));
	}

	SetEditType(EPartyIconType::Lock);
}

void UPartyIconWidget::SetCharacterById(const FCharacterId& InCharacterId)
{
	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(InCharacterId);
	if (Character)
	{
		const FCharacterBond& CharacterBond = GetHUDStore().GetBondManager().GetCharacterBond(Character->GetInfo().Type);
		SetCharacter(Character->GetInfo(), CharacterBond);
	}
	else
	{
		SetCharacterEmpty();
	}
}

void UPartyIconWidget::SetSculpture(const FSculptureInfo& SculptureInfo)
{
	SculptureIconWidget->SetSculpture(SculptureInfo);
	SetTotalAttributes();
}

void UPartyIconWidget::SetSculptureById(const FSculptureId& InSculptureId)
{
	const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(InSculptureId);
	if (Sculpture)
	{
		SetSculpture(Sculpture->Info);
	}
	else
	{
		SculptureIconWidget->SetEmpty(true);
		SetTotalAttributes();
	}
}

void UPartyIconWidget::SetRelic(const FRelicInfo& RelicInfo)
{
	RelicIconWidget->SetRelic(RelicInfo);
	SetTotalAttributes();
}

void UPartyIconWidget::SetRelicById(const FRelicId& InRelicId)
{
	const FRelic* Relic = GetHUDStore().GetRelicManager().Find(InRelicId);
	if (Relic)
	{
		SetRelic(Relic->Info);
	}
	else
	{
		RelicIconWidget->SetEmpty(true);
		SetTotalAttributes();
	}
}

void UPartyIconWidget::SetTotalAttributes()
{
	int64 TotalHealth = 0, TotalAtk = 0, TotalDef = 0;
	int64 Health = 0, Atk = 0, Def = 0;

	// Add character attributes

	if (ItemInfo.Type != ITEM_INVALID)
	{
		EAttributeCategory RatioType = EAttributeCategory::Character;
		if (bSystemJoker)
		{
			const UPartyManager& PartyMgr = GetHUDStore().GetPartyManager();
			if (PartyMgr.GetJokerType() == EJokerType::SystemJoker)
			{
				RatioType = EAttributeCategory::SystemJoker;
			}
		}

		Attribute::GetUnitAttribute(GetCMS(), RatioType,
			GetCMS()->GetUnitType(FCharacterType(ItemInfo.Type)), ItemInfo.Level, ItemInfo.Grade, nullptr,
			Health, Atk, Def);

		TotalHealth += Health;
		TotalAtk += Atk;
		TotalDef += Def;
	}

	// Add Relic attributes

	const FItemIconInfo& RelicItemInfo = GetRelicIconWidget()->GetItemInfo();
	if (RelicItemInfo.Type != ITEM_INVALID)
	{
		Attribute::GetRelicAttribute(GetCMS(), FRelicType(RelicItemInfo.Type),
			RelicItemInfo.Level, RelicItemInfo.Tier, RelicItemInfo.Grade, Health, Atk, Def);

		TotalHealth += Health;
		TotalAtk += Atk;
		TotalDef += Def;
	}

	// Add Sculpture attributes

	const FItemIconInfo& SculptureItemInfo = GetSculptureIconWidget()->GetItemInfo();
	if (SculptureItemInfo.Type != ITEM_INVALID)
	{
		Attribute::GetSculptureAttribute(GetCMS(), FSculptureType(SculptureItemInfo.Type),
			SculptureItemInfo.Level, SculptureItemInfo.Tier, SculptureItemInfo.Grade, Health, Atk, Def);

		TotalHealth += Health;
		TotalAtk += Atk;
		TotalDef += Def;
	}

	TotalHealthText->SetText(FText::AsNumber(TotalHealth));
	TotalAtkText->SetText(FText::AsNumber(TotalAtk));
	TotalDefText->SetText(FText::AsNumber(TotalDef));
}

UPartyEquipIconWidget* UPartyIconWidget::GetEquipIconWidget(EPartyIconItemType ItemType) const
{
	return (ItemType == EPartyIconItemType::Relic) ? RelicIconWidget : SculptureIconWidget;
}

int64 UPartyIconWidget::GetItemId(EPartyIconItemType InItemType) const
{
	switch (InItemType)
	{
		case EPartyIconItemType::Character: return GetCharacterId().S;
		case EPartyIconItemType::Sculpture: return GetSculptureId().S;
		case EPartyIconItemType::Relic:	 return GetRelicId().S;
		default: return 0;
	}
}

const FItemIconInfo& UPartyIconWidget::GetItemInfo(EPartyIconItemType InItemType) const
{
	switch (InItemType)
	{
		case EPartyIconItemType::Character: return GetCharacterInfo();
		case EPartyIconItemType::Sculpture: return GetSculptureInfo();
		case EPartyIconItemType::Relic:	 return GetRelicInfo();
		default:
			const static FItemIconInfo DummyItemInfo;
			return DummyItemInfo;
	}
}

bool UPartyIconWidget::IsSelectEnabled(EPartyIconItemType InItemType)  const
{
	if (InItemType == EPartyIconItemType::Character)
	{
		return bSelectEnabled;
	}

	UPartyEquipIconWidget* EquipIconWidget = GetEquipIconWidget(InItemType);
	if (EquipIconWidget)
	{
		return EquipIconWidget->IsSelectEnabled();
	}

	return false;
}

void UPartyIconWidget::OpenCharacterDetail(UPartyEquipIconWidget* EquipIconWidget)
{
	if (GetLobbyTutorial(this) && !GetLobbyTutorial(this)->CanWatchItemDetail())
	{
		return;
	}

	if (EquipIconWidget)
	{
		EquipIconWidget->OpenEquipDetail();
		return;
	}

	if (ItemInfo.IsValid())
	{
		if (ABaseHUD* HUD = GetBaseHUD(this))
		{
			HUD->OpenItemDetailPopup(ItemInfo);
		}
	}
}

void UPartyIconWidget::OnSculptureIconClicked(UPartyEquipIconWidget* InSculptureIconWidget)
{
	if (bViewOnly)
	{
		OnPartyIconSelectedDelegate.ExecuteIfBound(InSculptureIconWidget);
		return;
	}

	OnSculptureIconClickedDelegate.ExecuteIfBound(this);
}

void UPartyIconWidget::OnRelicIconClicked(UPartyEquipIconWidget* InRelicIconWidget)
{
	if (bViewOnly)
	{
		OnPartyIconSelectedDelegate.ExecuteIfBound(InRelicIconWidget);
		return;
	}

	OnRelicIconClickedDelegate.ExecuteIfBound(this);
}

void UPartyIconWidget::OnSelectButtonClicked()
{
	if (bViewOnly)
	{
		OnPartyIconSelectedDelegate.ExecuteIfBound(nullptr);
		return;
	}

	OnCharacterIconClickedDelegate.ExecuteIfBound(this);
}

UPartySelectWidget::UPartySelectWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPartySelectWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PartySwipeWidget = CastChecked<UPageSwipeWidget>(GetWidgetFromName("PartySwipe"));

	PartyMenuAnim = GetWidgetAnimationFromName(this, "AnimMenuParty");
	JokerMenuAnim = GetWidgetAnimationFromName(this, "AnimMenuJoker");
	PartySwipeWidget->OnFocusedPageDelegate.Unbind();
}

void UPartySelectWidget::SetParty(int32 InSelectPartyId)
{
	PageNumber = InSelectPartyId;

	PartySwipeWidget->OnSetPageDelegate.BindUObject(this, &UPartySelectWidget::OnPartyPageSet);
	PartySwipeWidget->OnFocusedPageDelegate.BindUObject(this, &UPartySelectWidget::OnPartyPageChanged);
	PartySwipeWidget->SetPageCount(MAX_PARTY_COUNT, PageNumber);
	PlayAnimation(PartyMenuAnim);
}

void UPartySelectWidget::SetMultisideParty()
{
	PageNumber = 0;

	PartySwipeWidget->OnSetPageDelegate.BindUObject(this, &UPartySelectWidget::OnMultisidePartyPageSet);
	PartySwipeWidget->SetPageCount(1, 1);
	PlayAnimation(PartyMenuAnim);
}

void UPartySelectWidget::SetJokerSet(int32 InJokerSetId)
{
	PageNumber = InJokerSetId;

	PartySwipeWidget->OnSetPageDelegate.BindUObject(this, &UPartySelectWidget::OnJokerSetPageSet);
	PartySwipeWidget->OnFocusedPageDelegate.BindUObject(this, &UPartySelectWidget::OnJokerSetPageChanged);
	PartySwipeWidget->SetPageCount(MAX_JOKERSET_COUNT, PageNumber);

	PlayAnimation(JokerMenuAnim);
}

void UPartySelectWidget::SetPartyMembers(UPartyPageWidget* PartyPageWidget, const FPartyInfo& InPartyInfo)
{
	const UHUDStore& HUDStore = GetHUDStore();
	const UCharacterManager& CharacterMgr = HUDStore.GetCharacterManager();
	const URelicManager& RelicMgr = HUDStore.GetRelicManager();
	const USculptureManager& SculptureMgr = HUDStore.GetSculptureManager();
	const UContentFeatureOpenManager& ContentFeatureOpenMgr = HUDStore.GetContentFeatureOpenManager();

	// Set MainParty
	for (int i = 0; i < InPartyInfo.Main.Num(); ++i)
	{
		const FPartySlot& PartySlot = InPartyInfo.Main[i];
		if (PartySlot.CharacterId.IsInvalid())
		{
			continue;
		}

		AddPartyMember(PartyPageWidget, PartySlot, i, true);
	}

	// Set SubParty
	for (int i = 0; i < InPartyInfo.Sub.Num(); ++i)
	{
		int32 SlotIndex = i + SubPartySlotOffset;
		bool bOpened = ContentFeatureOpenMgr.CheckContentOpenedBySubPartySlotIndex(SlotIndex);
		if (!bOpened)
		{
			PartyPageWidget->AddCharacterLockedSlotInfoAt(SlotIndex);
			continue;
		}

		const FPartySlot& PartySlot = InPartyInfo.Sub[i];
		if (PartySlot.CharacterId.IsInvalid())
		{
			continue;
		}

		AddPartyMember(PartyPageWidget, PartySlot, i, false);
	}
}

void UPartySelectWidget::SetMultisidePartyMembers(UPartyPageWidget* PartyPageWidget, const FPartyInfo& InPartyInfo)
{
	UQ6SaveGame* SaveGame = UQ6GameInstance::Get()->GetSaveGame();
	FPartyInfo NewMultisidePartyInfo = SaveGame->GetMultisidePartyInfo();

	// Set MainParty
	for (int i = 0; i < InPartyInfo.Main.Num(); ++i)
	{
		const FPartySlot& PartySlot = InPartyInfo.Main[i];
		if (PartySlot.CharacterId.IsInvalid())
		{
			continue;
		}

		AddMultisidePartyMember(PartyPageWidget, NewMultisidePartyInfo, PartySlot, i, true);
	}

	// Set SubParty
	for (int i = 0; i < InPartyInfo.Sub.Num(); ++i)
	{
		const FPartySlot& PartySlot = InPartyInfo.Sub[i];
		if (PartySlot.CharacterId.IsInvalid())
		{
			continue;
		}

		AddMultisidePartyMember(PartyPageWidget, NewMultisidePartyInfo, PartySlot, i, false);
	}

	SaveGame->SaveMultisidePartyInfo(NewMultisidePartyInfo);
}

void UPartySelectWidget::SetJokerSetMembers(UPartyPageWidget* PartyPageWidget, const FJokerSet& InJokerSet)
{
	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();

	const auto& JokerSlots = InJokerSet.Slots;

	for (int32 i = 0; i < JokerSlots.Num(); ++i)
	{
		const auto& JokerSlot = JokerSlots[i];
		if (JokerSlot.CharacterId.IsInvalid())
		{
			continue;
		}

		const FCharacter* Character = CharacterMgr.Find(JokerSlot.CharacterId);
		if (Character)
		{
			const FCharacterBond& CharacterBond = GetHUDStore().GetBondManager().GetCharacterBond(Character->GetInfo().Type);
			PartyPageWidget->AddCharacterInfoAt(Character->GetInfo(), CharacterBond, i);
		}

		const FRelic* Relic = RelicMgr.Find(JokerSlot.RelicId);
		if (Relic)
		{
			PartyPageWidget->AddRelicInfoAt(Relic->Info, i);
		}

		const FSculpture* Sculpture = SculptureMgr.Find(JokerSlot.SculptureId);
		if (Sculpture)
		{
			PartyPageWidget->AddSculptureInfoAt(Sculpture->Info, i);
		}
	}
}

void UPartySelectWidget::AddPartyMember(UPartyPageWidget* PartyPageWidget, const FPartySlot& InPartySlot, int32 SlotIndex, bool bMain)
{
	const UHUDStore& HUDStore = GetHUDStore();
	if(!bMain)
	{
		SlotIndex += SubPartySlotOffset;
	}

	const FCharacter* Character = HUDStore.GetCharacterManager().Find(InPartySlot.CharacterId);
	if (Character)
	{
		const FCharacterBond& CharacterBond = HUDStore.GetBondManager().GetCharacterBond(Character->GetInfo().Type);
		PartyPageWidget->AddCharacterInfoAt(Character->GetInfo(), CharacterBond, SlotIndex);
	}

	const FRelic* Relic = HUDStore.GetRelicManager().Find(InPartySlot.RelicId);
	if (Relic)
	{
		PartyPageWidget->AddRelicInfoAt(Relic->Info, SlotIndex);
	}

	const FSculpture* Sculpture = HUDStore.GetSculptureManager().Find(InPartySlot.SculptureId);
	if (Sculpture)
	{
		PartyPageWidget->AddSculptureInfoAt(Sculpture->Info, SlotIndex);
	}
}

void UPartySelectWidget::AddMultisidePartyMember(UPartyPageWidget* PartyPageWidget, FPartyInfo& NewMultisidePartyInfo, const FPartySlot& InPartySlot, int32 SlotIndex, bool bMain)
{
	const UHUDStore& HUDStore = GetHUDStore();
	int32 PartyPageSlotIndex = bMain ? SlotIndex : SlotIndex + SubPartySlotOffset;

	const FCharacter* Character = HUDStore.GetCharacterManager().Find(InPartySlot.CharacterId);
	if (Character)
	{
		const FCharacterBond& CharacterBond = HUDStore.GetBondManager().GetCharacterBond(Character->GetInfo().Type);
		PartyPageWidget->AddCharacterInfoAt(Character->GetInfo(), CharacterBond, PartyPageSlotIndex);
	}
	else if (!InPartySlot.CharacterId.IsInvalid())
	{
		if (bMain)
		{
			check(NewMultisidePartyInfo.Main.IsValidIndex(SlotIndex));
			NewMultisidePartyInfo.Main[SlotIndex].CharacterId = FCharacterId::InvalidValue();
		}
		else
		{
			check(NewMultisidePartyInfo.Sub.IsValidIndex(SlotIndex));
			NewMultisidePartyInfo.Sub[SlotIndex].CharacterId = FCharacterId::InvalidValue();
		}
	}

	const FRelic* Relic = HUDStore.GetRelicManager().Find(InPartySlot.RelicId);
	if (Relic)
	{
		PartyPageWidget->AddRelicInfoAt(Relic->Info, PartyPageSlotIndex);
	}
	else if (!InPartySlot.RelicId.IsInvalid())
	{
		if (bMain)
		{
			check(NewMultisidePartyInfo.Main.IsValidIndex(SlotIndex));
			NewMultisidePartyInfo.Main[SlotIndex].RelicId = FRelicId::InvalidValue();
		}
		else
		{
			check(NewMultisidePartyInfo.Sub.IsValidIndex(SlotIndex));
			NewMultisidePartyInfo.Sub[SlotIndex].RelicId = FRelicId::InvalidValue();
		}
	}

	const FSculpture* Sculpture = HUDStore.GetSculptureManager().Find(InPartySlot.SculptureId);
	if (Sculpture)
	{
		PartyPageWidget->AddSculptureInfoAt(Sculpture->Info, PartyPageSlotIndex);
	}
	else if (!InPartySlot.SculptureId.IsInvalid())
	{
		if (bMain)
		{
			check(NewMultisidePartyInfo.Main.IsValidIndex(SlotIndex));
			NewMultisidePartyInfo.Main[SlotIndex].SculptureId = FSculptureId::InvalidValue();
		}
		else
		{
			check(NewMultisidePartyInfo.Sub.IsValidIndex(SlotIndex));
			NewMultisidePartyInfo.Sub[SlotIndex].SculptureId = FSculptureId::InvalidValue();
		}
	}
}

void UPartySelectWidget::OnPartyPageSet(UWidget* ViewWidget, int32 InPartyId)
{
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	const UPartyManager& PartyMgr = GetHUDStore().GetPartyManager();
	const FPartyInfo& PartyInfo = PartyMgr.GetPartyInfo(InPartyId);

	UPartyPageWidget* PartyPageWidget = CastChecked<UPartyPageWidget>(ViewWidget);
	PartyPageWidget->ResetPage(UIState.WidgetType, false, false);
	PartyPageWidget->SetPet(PartyInfo.PetId);

	// Set party members

	SetPartyMembers(PartyPageWidget, PartyInfo);

	// Set party Joker

	EJokerType JokerType = PartyMgr.GetJokerType();
	switch (JokerType)
	{
	case EJokerType::SystemJoker:
		PartyPageWidget->AddCharacterInfoAt(PartyMgr.GetSystemJokerInfo(), MakeDefaultCharacterBond(GetCMS(), PartyMgr.GetSystemJokerInfo().Type), PARTY_JOKER_SLOT_INDEX);
		break;
	case EJokerType::FriendJoker:
		PartyPageWidget->AddFriendJokerSlotAt(PartyMgr.GetFriendJokerSlot(), PARTY_JOKER_SLOT_INDEX);
		break;
	case EJokerType::RandomJoker:
		PartyPageWidget->AddCharacterInfoAt(PartyMgr.GetRandomJokerInfo(), MakeDefaultCharacterBond(GetCMS(), PartyMgr.GetSystemJokerInfo().Type), PARTY_JOKER_SLOT_INDEX);
		break;
	case EJokerType::OwnedJoker:
		PartyPageWidget->AddOwnedJokerSlotAt(PartyMgr.GetOwnedJokerSlot(), PARTY_JOKER_SLOT_INDEX);
		break;
	}
}

void UPartySelectWidget::OnMultisidePartyPageSet(UWidget* ViewWidget, int32 InPartyId /* == dummy */)
{
	UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
	const FPartyInfo& SavedPartyInfo = SaveGame->GetMultisidePartyInfo();

	UPartyPageWidget* PartyPageWidget = CastChecked<UPartyPageWidget>(ViewWidget);
	PartyPageWidget->ResetPage(EPartyWidgetType::Party, false, true);

	const UPetManager& PetManager = GetHUDStore().GetPetManager();

	FPetId PetId = SavedPartyInfo.PetId;
	if (PetId == FPetId::InvalidValue())
	{
		// Has any pet?
		const FPetInfo* PetInfo = PetManager.GetPetInfoByIndex(0);
		if (PetInfo)
		{
			PetId = PetInfo->PetId;
			SaveGame->SaveMultisidePartyPet(PetId);
		}
	}
	else
	{
		const FPetInfo* PetInfo = PetManager.Find(PetId);
		if (!PetInfo)
		{
			PetId = FPetId::InvalidValue();
			SaveGame->SaveMultisidePartyPet(PetId);
		}
	}

	PartyPageWidget->SetPet(PetId);
	SetMultisidePartyMembers(PartyPageWidget, SavedPartyInfo);
}

void UPartySelectWidget::OnPartyPageChanged(int32 NewPage)
{
	ACTION_DISPATCH_PartyChange(NewPage);
}

void UPartySelectWidget::OnJokerSetPageSet(UWidget* ViewWidget, int32 InJokerSetId)
{
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	ensure(UIState.WidgetType == EPartyWidgetType::JokerSet);

	auto PartyPageWidget = CastChecked<UPartyPageWidget>(ViewWidget);
	PartyPageWidget->ResetPage(EPartyWidgetType::JokerSet, false, false);

	const auto& JokerMgr = GetHUDStore().GetJokerManager();
	const auto& JokerSet = JokerMgr.GetJokerSet(InJokerSetId);
	SetJokerSetMembers(PartyPageWidget, JokerSet);
}

void UPartySelectWidget::OnJokerSetPageChanged(int32 NewPage)
{
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	ensure(UIState.WidgetType == EPartyWidgetType::JokerSet);

	ACTION_DISPATCH_JokerSetChange(NewPage);

	OnJokerSetChangeDelegate.ExecuteIfBound(NewPage);
}

UPartyMemberListWidget::UPartyMemberListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPartyMemberListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	static_assert(EJokerSlotTypeMax == MAX_JOKER_SLOT, "EJokerSlotTypeMax");
	static_assert(EJokerSlotTypeMax == MAX_PARTY_MEMBER, "EJokerSlotTypeMax");
	for (int32 n = 1; n <= EJokerSlotTypeMax; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Icon%d"), n);
		UPartyIconWidget* PartyIconWidget = CastChecked<UPartyIconWidget>(GetWidgetFromName(*WidgetName));
		PartyIconWidget->OnCharacterIconClickedDelegate.BindUObject(this, &UPartyMemberListWidget::OnCharacterClicked);
		PartyIconWidget->OnSculptureIconClickedDelegate.BindUObject(this, &UPartyMemberListWidget::OnSculptureClicked);
		PartyIconWidget->OnRelicIconClickedDelegate.BindUObject(this, &UPartyMemberListWidget::OnRelicClicked);
		PartyIconWidgets.AddUnique(PartyIconWidget);
	}
}

void UPartyMemberListWidget::InitParty(const FPartyInfo& PartyInfo, const FPartySlot& OwnedJokerSlot)
{
	ResetPartyIcons(EPartyWidgetType::Party);

	UHUDStore& HUDStore = GetHUDStore();
	const UPartyManager& PartyMgr = HUDStore.GetPartyManager();
	const UContentFeatureOpenManager& ContentFeatureOpenMgr = HUDStore.GetContentFeatureOpenManager();

	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		if (i < MAX_MAIN_PARTY_MEMBER)
		{
			check(PartyInfo.Main.IsValidIndex(i));
			PartyIconWidgets[i]->SetPartySlot(PartyInfo.Main[i]);
		}
		else if (i == PARTY_JOKER_SLOT_INDEX)
		{
			// Set Joker
			EJokerType JokerType = PartyMgr.GetJokerType();
			switch (JokerType)
			{
				case EJokerType::SystemJoker:
					PartyIconWidgets[i]->SetCharacter(PartyMgr.GetSystemJokerInfo(), MakeDefaultCharacterBond(GetCMS(), PartyMgr.GetSystemJokerInfo().Type));
					break;
				case EJokerType::FriendJoker:
					PartyIconWidgets[i]->SetFriendJokerSlot(PartyMgr.GetFriendJokerSlot());
					break;
				case EJokerType::OwnedJoker:
					PartyIconWidgets[i]->SetPartySlot(OwnedJokerSlot);
					break;
			}
		}
		else
		{
			bool bOpened = ContentFeatureOpenMgr.CheckContentOpenedBySubPartySlotIndex(i);
			if (!bOpened)
			{
				PartyIconWidgets[i]->SetCharacterLockedSlotInfo(i);
			}
			else
			{
				check(PartyInfo.Sub.IsValidIndex(i % 3));
				PartyIconWidgets[i]->SetPartySlot(PartyInfo.Sub[i % 3]);
			}
		}
	}

	PlayAnimation(GetWidgetAnimationFromName(this, "AnimMenuParty"));
}

void UPartyMemberListWidget::InitMultisideParty(const FPartyInfo& PartyInfo)
{
	ResetPartyIcons(EPartyWidgetType::Party, true);

	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		if (i < NUM_OF_PARTY_MEMBER)
		{
			if (!PartyInfo.Main.IsValidIndex(i))
			{
				continue;
			}

			PartyIconWidgets[i]->SetPartySlot(PartyInfo.Main[i]);
		}
		else
		{
			if (!PartyInfo.Sub.IsValidIndex(i % 3))
			{
				continue;
			}

			PartyIconWidgets[i]->SetPartySlot(PartyInfo.Sub[i % 3]);
		}
	}

	PlayAnimation(GetWidgetAnimationFromName(this, "AnimMenuParty"));
}

void UPartyMemberListWidget::InitJokerSet(const FJokerSet& JokerSet)
{
	ResetPartyIcons(EPartyWidgetType::JokerSet);

	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		check(JokerSet.Slots.IsValidIndex(i));
		PartyIconWidgets[i]->SetPartyJoker(JokerSet.Slots[i]);
	}

	PlayAnimation(GetWidgetAnimationFromName(this, "AnimMenuJoker"));
}

bool UPartyMemberListWidget::HasEqualCharacterType(const FCharacterId& CharacterId) const
{
	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	FCharacterType CharacterType = CharacterTypeInvalid;
	if (const FCharacter* Character = CharacterMgr.Find(CharacterId))
	{
		CharacterType = Character->GetInfo().Type;
	}

	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		if (i == PARTY_JOKER_SLOT_INDEX)
		{
			continue;
		}

		UPartyIconWidget* PartyIcon = PartyIconWidgets[i];
		const FCharacter* Character = CharacterMgr.Find(PartyIcon->GetCharacterId());
		if (!Character)
		{
			continue;
		}

		if (Character->GetInfo().Type != CharacterType)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool UPartyMemberListWidget::HasEqualSculptureType(const FSculptureId& SculptureId) const
{
	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	FSculptureType SculptureType = SculptureTypeInvalid;
	if (const FSculpture* Sculpture = SculptureMgr.Find(SculptureId))
	{
		SculptureType = Sculpture->GetInfo().Type;
	}

	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		if (i == PARTY_JOKER_SLOT_INDEX)
		{
			continue;
		}

		UPartyIconWidget* PartyIcon = PartyIconWidgets[i];
		const FSculpture* Sculpture = SculptureMgr.Find(PartyIcon->GetSculptureId());
		if (!Sculpture)
		{
			continue;
		}

		if (Sculpture->GetInfo().Type != SculptureType)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool UPartyMemberListWidget::HasEqualRelicType(const FRelicId& RelicId) const
{
	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	FRelicType RelicType = RelicTypeInvalid;
	if (const FRelic* Relic = RelicMgr.Find(RelicId))
	{
		RelicType = Relic->GetInfo().Type;
	}

	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		if (i == PARTY_JOKER_SLOT_INDEX)
		{
			continue;
		}

		UPartyIconWidget* PartyIcon = PartyIconWidgets[i];
		const FRelic* Relic = RelicMgr.Find(PartyIcon->GetRelicId());
		if (!Relic)
		{
			continue;
		}

		if (Relic->GetInfo().Type != RelicType)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool UPartyMemberListWidget::IsCharacterInParty(const FCharacterId& CharacterId) const
{
	for (UPartyIconWidget* PartyIcon : PartyIconWidgets)
	{
		if (PartyIcon->GetCharacterId() != CharacterId)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool UPartyMemberListWidget::IsSculptureInParty(const FSculptureId& SculptureId) const
{
	for (UPartyIconWidget* PartyIcon : PartyIconWidgets)
	{
		if (PartyIcon->GetSculptureId() != SculptureId)
		{
			continue;
		}

		return true;
	}

	return false;
}

bool UPartyMemberListWidget::IsRelicInParty(const FRelicId& RelicId) const
{
	for (UPartyIconWidget* PartyIcon : PartyIconWidgets)
	{
		if (PartyIcon->GetRelicId() != RelicId)
		{
			continue;
		}

		return true;
	}

	return false;
}

TArray<const FCharacter*> UPartyMemberListWidget::GetPartyCharacters(bool bJoker) const
{
	TArray<const FCharacter*> SortedList;
	for (const UPartyIconWidget* PartyIcon : PartyIconWidgets)
	{
		FCharacterId CharacterId = PartyIcon->GetCharacterId();
		if (CharacterId.IsInvalid())
		{
			continue;
		}

		const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
		if (!Character)
		{
			continue;
		}

		SortedList.AddUnique(Character);
	}

	ESortMenu SortMenu = bJoker ? ESortMenu::JokerEdit : ESortMenu::PartyEdit;
	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, ESortCategory::OwnedCharacter);
	FSortOrdering::Sort(SortingOption, SortedList);

	return SortedList;
}

TArray<const FRelic*> UPartyMemberListWidget::GetPartyRelics(bool bJoker) const
{
	TArray<const FRelic*> SortedList;
	for (const UPartyIconWidget* PartyIcon : PartyIconWidgets)
	{
		FRelicId RelicId = PartyIcon->GetRelicId();
		if (RelicId.IsInvalid())
		{
			continue;
		}

		const FRelic* Relic = GetHUDStore().GetRelicManager().Find(RelicId);
		if (!Relic)
		{
			continue;
		}

		SortedList.AddUnique(Relic);
	}

	ESortMenu SortMenu = bJoker ? ESortMenu::JokerEdit : ESortMenu::PartyEdit;
	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, ESortCategory::OwnedRelic);
	FSortOrdering::Sort(SortingOption, SortedList);

	return SortedList;
}


TArray<const FSculpture*> UPartyMemberListWidget::GetPartySculptures(bool bJoker) const
{
	TArray<const FSculpture*> SortedList;
	for (const UPartyIconWidget* PartyIcon : PartyIconWidgets)
	{
		FSculptureId SculptureId = PartyIcon->GetSculptureId();
		if (SculptureId.IsInvalid())
		{
			continue;
		}

		const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(SculptureId);
		if (!Sculpture)
		{
			continue;
		}

		SortedList.AddUnique(Sculpture);
	}

	ESortMenu SortMenu = bJoker ? ESortMenu::JokerEdit : ESortMenu::PartyEdit;
	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, ESortCategory::OwnedSculpture);
	FSortOrdering::Sort(SortingOption, SortedList);

	return SortedList;
}

void UPartyMemberListWidget::ResetPartyIcons(EPartyWidgetType InWidgetType, bool bIsMultiside)
{
	WidgetType = InWidgetType;
	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		PartyIconWidgets[i]->ResetPartyIcon(InWidgetType, i, false, bIsMultiside);
	}
}

void UPartyMemberListWidget::OnCharacterClicked(UPartyIconWidget* PartyIconWidget)
{
	OnCharacterIconClickedDelegate.ExecuteIfBound(PartyIconWidget);
}

void UPartyMemberListWidget::OnSculptureClicked(UPartyIconWidget* PartyIconWidget)
{
	OnSculptureIconClickedDelegate.ExecuteIfBound(PartyIconWidget);
}

void UPartyMemberListWidget::OnRelicClicked(UPartyIconWidget* PartyIconWidget)
{
	OnRelicIconClickedDelegate.ExecuteIfBound(PartyIconWidget);
}

FCharacterId UPartyMemberListWidget::GetCharacterId(int32 SlotIdx) const
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		return PartyIconWidgets[SlotIdx]->GetCharacterId();
	}

	return FCharacterId::InvalidValue();
}

FSculptureId UPartyMemberListWidget::GetSculptureId(int32 SlotIdx) const
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		return PartyIconWidgets[SlotIdx]->GetSculptureId();
	}

	return FSculptureId::InvalidValue();
}

FRelicId UPartyMemberListWidget::GetRelicId(int32 SlotIdx) const
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		return PartyIconWidgets[SlotIdx]->GetRelicId();
	}

	return FRelicId::InvalidValue();
}

UPartyIconWidget* UPartyMemberListWidget::GetPartyIconBySlotIdx(int32 SlotIdx) const
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		return PartyIconWidgets[SlotIdx];
	}

	return nullptr;
}

int32 UPartyMemberListWidget::GetPartyIconIndex(const UPartyIconWidget* IconWidget) const
{
	if (!IconWidget)
	{
		return INDEX_NONE;
	}

	return PartyIconWidgets.IndexOfByKey(IconWidget);
}

void UPartyMemberListWidget::OnSelectItem(EPartyIconItemType ItemType, int64 SelectedItemId, int32 SelectedItemType, int32 SelecedSlotIdx /*= -1*/)
{
	const FPartyUIState& CurState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	if (CurState.WidgetType == EPartyWidgetType::JokerSet)
	{
		OnSelectItemForJokerSet(ItemType, SelectedItemId, SelectedItemType, SelecedSlotIdx);
		return;
	}

	bool bCheckEqualType = false;
	if (ItemType == EPartyIconItemType::Character)
	{
		bCheckEqualType = HasEqualCharacterType(FCharacterId(SelectedItemId)) && !IsCharacterInParty(FCharacterId(SelectedItemId));
	}
	else if (ItemType == EPartyIconItemType::Sculpture)
	{
		bCheckEqualType = HasEqualSculptureType(FSculptureId(SelectedItemId)) && !IsSculptureInParty(FSculptureId(SelectedItemId));
	}
	else if (ItemType == EPartyIconItemType::Relic)
	{
		bCheckEqualType = HasEqualRelicType(FRelicId(SelectedItemId)) && !IsRelicInParty(FRelicId(SelectedItemId));
	}

	for (UPartyIconWidget* PartyIconWidget : PartyIconWidgets)
	{
		if (PartyIconWidget->IsSystemJoker())
		{
			continue;
		}

		if (ItemType == EPartyIconItemType::Character)
		{
			if (SelectedItemId == FCharacterId::InvalidValue())
			{
				PartyIconWidget->SetSelected(ItemType, EIconSelectType::Selectable);
				continue;
			}

			FCharacterId CharacterId = PartyIconWidget->GetCharacterId();
			if (CharacterId == FCharacterId(SelectedItemId))
			{
				PartyIconWidget->SetSelected(ItemType, EIconSelectType::Highlight);
				continue;
			}

			if (!bCheckEqualType)
			{
				PartyIconWidget->SetSelected(ItemType, EIconSelectType::Selectable);
				continue;
			}

			if (PartyIconWidget->GetCharacterType() == FCharacterType(SelectedItemType))
			{
				PartyIconWidget->SetSelected(ItemType, EIconSelectType::Selectable);
				continue;
			}

			PartyIconWidget->SetSelected(ItemType, EIconSelectType::Disabled);
		}
		else
		{
			UPartyEquipIconWidget* EquipIconWidget = PartyIconWidget->GetEquipIconWidget(ItemType);

			if (PartyIconWidget->GetCharacterId().IsInvalid())
			{
				EquipIconWidget->SetSelected(EIconSelectType::Disabled);
				continue;
			}

			if (EquipIconWidget->GetItemId() == 0)	// empty slot
			{
				if (!bCheckEqualType)
				{
					EquipIconWidget->SetSelected(EIconSelectType::Selectable);
					continue;
				}
			}
			else
			{
				if (EquipIconWidget->GetItemId() == SelectedItemId)
				{
					EquipIconWidget->SetSelected(EIconSelectType::Highlight);
					continue;
				}

				if (!bCheckEqualType)
				{
					EquipIconWidget->SetSelected(EIconSelectType::Selectable);
					continue;
				}

				if (EquipIconWidget->GetItemInfo().Type == SelectedItemType)
				{
					PartyIconWidget->SetSelected(ItemType, EIconSelectType::Selectable);
					continue;
				}
			}

			EquipIconWidget->SetSelected(EIconSelectType::Disabled);
		}
	}
}

void UPartyMemberListWidget::OnSelectItemForJokerSet(EPartyIconItemType ItemType, int64 SelectedItemId, int32 SelectedItemType, int32 SelectedSlotIdx)
{
	if (ItemType == EPartyIconItemType::Character)
	{
		UPartyIconWidget* AllSlotIconWidget = PartyIconWidgets[static_cast<int32>(EJokerSlotType::All)];
		check(AllSlotIconWidget);

		if (SelectedItemId == ITEM_INVALID && SelectedSlotIdx == -1)
		{
			for (UPartyIconWidget* PartyIconWidget : PartyIconWidgets)
			{
				PartyIconWidget->SetSelected(ItemType, EIconSelectType::Selectable);
			}
		}
		else if (SelectedItemId == ITEM_INVALID)
		{
			check(PartyIconWidgets.IsValidIndex(SelectedSlotIdx));
			UPartyIconWidget* SelectedIconWidget = PartyIconWidgets[SelectedSlotIdx];
			check(SelectedIconWidget);
			EJokerSlotType SelectedSlot = SelectedIconWidget->GetJokerSlotType();

			for (UPartyIconWidget* CurrIconWidget : PartyIconWidgets)
			{
				EIconSelectType IconSelectType = EIconSelectType::Disabled;

				EJokerSlotType CurrSlot = CurrIconWidget->GetJokerSlotType();

				if (CurrSlot == SelectedSlot)
				{
					IconSelectType = EIconSelectType::Highlight;
				}
				else if (SelectedSlot == EJokerSlotType::All)
				{
					if (AllSlotIconWidget->IsSwapable(CurrSlot))
					{
						IconSelectType = EIconSelectType::Selectable;
					}
				}
				else if (CurrSlot == EJokerSlotType::All)
				{
					if (AllSlotIconWidget->IsSwapable(SelectedSlot))
					{
						IconSelectType = EIconSelectType::Selectable;
					}
				}
				else if (SelectedIconWidget->IsEmpty() && CurrIconWidget->IsEmpty())
				{
					IconSelectType = EIconSelectType::Selectable;
				}
				CurrIconWidget->SetSelected(ItemType, IconSelectType);
			}
		}
		else
		{
			FCharacterId SelectedCharId = FCharacterId(SelectedItemId);
			check(!SelectedCharId.IsInvalid());
			const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();
			const FCharacter* SelectedCharacter = CharMgr.Find(SelectedCharId);
			check(SelectedCharacter);
			FCharacterType SelectedCharType = SelectedCharacter->GetInfo().Type;
			check(SelectedCharType != CharacterTypeInvalid);
			EJokerSlotType SelectedCharSlot = GetCMS()->GetJokerSlotType(SelectedCharType);
			check(SelectedCharSlot != EJokerSlotType::All);
			UPartyIconWidget* IconWidgetForSelectedChar = PartyIconWidgets[static_cast<int32>(SelectedCharSlot)];
			check(IconWidgetForSelectedChar);

			for (UPartyIconWidget* CurrIconWidget : PartyIconWidgets)
			{
				EIconSelectType IconSelectType = EIconSelectType::Disabled;

				EJokerSlotType CurrSlot = CurrIconWidget->GetJokerSlotType();

				// curr == ALL-slot
				// can swap if selected slot has the selected and is SWAP-slot
				// can set if SWAP-slot has different type
				if (CurrSlot == EJokerSlotType::All)
				{
					if (IconWidgetForSelectedChar->GetCharacterType() != SelectedCharType)
					{
						IconSelectType = EIconSelectType::Selectable;
					}
					else if (IconWidgetForSelectedChar->GetCharacterId() == SelectedCharId && AllSlotIconWidget->IsSwapable(SelectedCharSlot))
					{
						IconSelectType = EIconSelectType::Selectable;
					}
				}
				// with ALL-slot
				// can swap if ALL-slot has the selected
				// can set if ALL-slot has different type
				else if (CurrSlot == SelectedCharSlot)
				{
					if (AllSlotIconWidget->GetCharacterType() != SelectedCharType)
					{
						IconSelectType = EIconSelectType::Selectable;
					}
					else if (AllSlotIconWidget->GetCharacterId() == SelectedCharId && AllSlotIconWidget->IsSwapable(SelectedCharSlot))
					{
						IconSelectType = EIconSelectType::Selectable;
					}
				}

				CurrIconWidget->SetSelected(ItemType, IconSelectType);
			}
		}
	}
	else
	{
		bool bCheckEqualType = false;
		if (ItemType == EPartyIconItemType::Sculpture)
		{
			bCheckEqualType = HasEqualSculptureType(FSculptureId(SelectedItemId)) && !IsSculptureInParty(FSculptureId(SelectedItemId));
		}
		else if (ItemType == EPartyIconItemType::Relic)
		{
			bCheckEqualType = HasEqualRelicType(FRelicId(SelectedItemId)) && !IsRelicInParty(FRelicId(SelectedItemId));
		}

		for (UPartyIconWidget* CurrIconWidget : PartyIconWidgets)
		{
			UPartyEquipIconWidget* EquipIconWidget = CurrIconWidget->GetEquipIconWidget(ItemType);

			if (CurrIconWidget->GetCharacterId().IsInvalid())
			{
				EquipIconWidget->SetSelected(EIconSelectType::Disabled);
				continue;
			}

			if (EquipIconWidget->GetItemId() == 0)	// empty slot
			{
				if (!bCheckEqualType)
				{
					EquipIconWidget->SetSelected(EIconSelectType::Selectable);
					continue;
				}
			}
			else
			{
				if (EquipIconWidget->GetItemId() == SelectedItemId)
				{
					EquipIconWidget->SetSelected(EIconSelectType::Highlight);
					continue;
				}

				if (!bCheckEqualType)
				{
					EquipIconWidget->SetSelected(EIconSelectType::Selectable);
					continue;
				}

				if (EquipIconWidget->GetItemInfo().Type == SelectedItemType)
				{
					CurrIconWidget->SetSelected(ItemType, EIconSelectType::Selectable);
					continue;
				}
			}

			EquipIconWidget->SetSelected(EIconSelectType::Disabled);
		}
	}
}

void UPartyMemberListWidget::DeselectAll()
{
	for (UPartyIconWidget* PartyIconWidget : PartyIconWidgets)
	{
		if (PartyIconWidget->IsSystemJoker())
		{
			continue;
		}

		PartyIconWidget->SetSelected(EPartyIconItemType::Character, EIconSelectType::Deselected);
		PartyIconWidget->SetSelected(EPartyIconItemType::Sculpture, EIconSelectType::Deselected);
		PartyIconWidget->SetSelected(EPartyIconItemType::Relic, EIconSelectType::Deselected);
	}
}

void UPartyMemberListWidget::SetHighlight(EPartyIconItemType ItemType)
{
	for (UPartyIconWidget* PartyIconWidget : PartyIconWidgets)
	{
		if (PartyIconWidget->IsSystemJoker())
		{
			continue;
		}

		PartyIconWidget->SetHighlight(ItemType);
	}
}

UPartyEditWidget::UPartyEditWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, PartyId(0)
	, ItemType(EPartyIconItemType::Max)
	, SelectedPartyIconWidget(nullptr)
	, SelectedItemCardWidget(nullptr)
	, bPartySelectReset(true)
	, bIsMultiside(false)
{
}

void UPartyEditWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterDetailAnim = GetWidgetAnimationFromName(this, "AnimTabCharacter");
	check(CharacterDetailAnim);

	EquipDetailAnim = GetWidgetAnimationFromName(this, "AnimTabEquip");
	check(EquipDetailAnim);

	PartyEditAnim = GetWidgetAnimationFromName(this, "AnimMenuParty");
	check(PartyEditAnim);

	JokerEditAnim = GetWidgetAnimationFromName(this, "AnimMenuJoker");
	check(JokerEditAnim);

	TabEquipAnim = GetWidgetAnimationFromName(this, "AnimTabEquip");
	check(TabEquipAnim);

	TabCharacterAnim = GetWidgetAnimationFromName(this, "AnimTabCharacter");
	check(TabCharacterAnim);

	PartyNumberBox = CastChecked<UHorizontalBox>(GetWidgetFromName("PartyNum"));
	PartyNumberText = CastChecked<UTextBlock>(GetWidgetFromName("PartyNumber"));
	JokerSetNumberText = CastChecked<UTextBlock>(GetWidgetFromName("JokerNumber"));
	MemberListWidget = CastChecked<UPartyMemberListWidget>(GetWidgetFromName("MemberList"));
	MemberListWidget->OnCharacterIconClickedDelegate.BindUObject(this, &UPartyEditWidget::OnPartyIconClicked, EPartyIconItemType::Character);
	MemberListWidget->OnSculptureIconClickedDelegate.BindUObject(this, &UPartyEditWidget::OnPartyIconClicked, EPartyIconItemType::Sculpture);
	MemberListWidget->OnRelicIconClickedDelegate.BindUObject(this, &UPartyEditWidget::OnPartyIconClicked, EPartyIconItemType::Relic);

	ItemCategoryWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("ItemCategory"));
	ItemCategoryWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UPartyEditWidget::OnItemCategoryChanged);

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	EffectsText = CastChecked<URichTextBlock>(GetWidgetFromName("Effects"));
	TopSpacer = CastChecked<USpacer>(GetWidgetFromName("SpacerTop"));

	StatHpWidget = CastChecked<UStatWidget>(GetWidgetFromName("StatHp"));
	StatAtkWidget = CastChecked<UStatWidget>(GetWidgetFromName("StatAtk"));
	StatDefWidget = CastChecked<UStatWidget>(GetWidgetFromName("StatDef"));

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));

	PartyResetButton = CastChecked<UButton>(GetWidgetFromName("PartyReset"));
	PartyResetButton->OnClicked.AddUniqueDynamic(this, &UPartyEditWidget::OnPartyResetButtonClicked);

	SortingWidget = CastChecked<USortingWidget>(GetWidgetFromName("Sorting"));
}

void UPartyEditWidget::SetParty(int32 InPartyId, EPartyIconItemType InItemType, int64 InSlotIdx)
{
	PartyId = InPartyId;
	ItemType = InItemType;
	bIsMultiside = false;

	SelectedItemCardWidget = nullptr;
	SelectedPartyIconWidget = nullptr;

	PartyNumberBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	PartyNumberText->SetText(FText::AsNumber(PartyId));

	const UPartyManager& PartyMgr = GetHUDStore().GetPartyManager();
	MemberListWidget->InitParty(PartyMgr.GetPartyInfo(PartyId), PartyMgr.GetOwnedJokerSlot());
	MemberListWidget->DeselectAll();

	if (InSlotIdx > INDEX_NONE)
	{
		// Set selected item

		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(InSlotIdx);
		if (PartyIconWidget)
		{
			OnPartyIconClicked(PartyIconWidget, InItemType);
		}
	}
	else
	{
		RefreshItemList(true);
	}

	PlayAnimation(PartyEditAnim);
}

void UPartyEditWidget::SetMultisideParty(EPartyIconItemType InItemType, int32 SelectedSlotIdx)
{
	PartyId = 0;
	ItemType = InItemType;
	bIsMultiside = true;

	SelectedItemCardWidget = nullptr;
	SelectedPartyIconWidget = nullptr;

	PartyNumberBox->SetVisibility(ESlateVisibility::Collapsed);
	PartyNumberText->SetText(FText::AsNumber(PartyId));

	const UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
	MemberListWidget->InitMultisideParty(SaveGame->GetMultisidePartyInfo());
	MemberListWidget->DeselectAll();

	if (SelectedSlotIdx > INDEX_NONE)
	{
		// Set selected item

		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(SelectedSlotIdx);
		if (PartyIconWidget)
		{
			OnPartyIconClicked(PartyIconWidget, InItemType);
		}
	}
	else
	{
		RefreshItemList(true);
	}

	PlayAnimation(PartyEditAnim);
}

void UPartyEditWidget::SetJokerSet(int32 InJokerSetId, EPartyIconItemType InItemType, int64 InSlotIdx)
{
	JokerSetId = InJokerSetId;
	ItemType = InItemType;

	SelectedItemCardWidget = nullptr;
	SelectedPartyIconWidget = nullptr;

	JokerSetNumberText->SetText(FText::AsNumber(JokerSetId));
	const auto& JokerMgr = GetHUDStore().GetJokerManager();
	MemberListWidget->InitJokerSet(JokerMgr.GetJokerSet(JokerSetId));
	MemberListWidget->DeselectAll();

	if (InSlotIdx > INDEX_NONE)
	{
		// Set selected item

		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(InSlotIdx);
		if (PartyIconWidget)
		{
			OnPartyIconClicked(PartyIconWidget, InItemType);
		}
	}
	else
	{
		RefreshItemList(true);
	}

	PlayAnimation(JokerEditAnim);
}

void UPartyEditWidget::SetTopSpacer(bool bInVisible)
{
	TopSpacer->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UPartyEditWidget::SetEmptyInfo()
{
	NameText->SetText(FText::GetEmpty());
	EffectsText->SetText(FText::GetEmpty());

	StatHpWidget->SetEmpty();
	StatAtkWidget->SetEmpty();
	StatDefWidget->SetEmpty();

	PlayAnimation(ItemType == EPartyIconItemType::Character ? TabCharacterAnim : TabEquipAnim);
}

void UPartyEditWidget::SetItemInfo(const FItemIconInfo& ItemInfo)
{
	if (!ItemInfo.IsValid())
	{
		SetEmptyInfo();
		return;
	}

	UCMS* CMS = GetCMS();

	int64 Health = 0, Atk = 0, Def = 0;

	if (ItemType == EPartyIconItemType::Character)
	{
		SetCharacterItem(ItemInfo, CMS, Health, Atk, Def);
	}
	else if (ItemType == EPartyIconItemType::Sculpture)
	{
		SetSculptureItem(ItemInfo, CMS, Health, Atk, Def);
	}
	else if (ItemType == EPartyIconItemType::Relic)
	{
		SetRelicItem(ItemInfo, CMS, Health, Atk, Def);
	}

	StatHpWidget->SetStat(EUnitAttribute::MaxHealth, Health);
	StatAtkWidget->SetStat(EUnitAttribute::Atk, Atk);
	StatDefWidget->SetStat(EUnitAttribute::Def, Def);
}

void UPartyEditWidget::SetCharacterItem(const FItemIconInfo &ItemInfo, UCMS* CMS, int64& Health, int64& Atk, int64& Def)
{
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(FCharacterType(ItemInfo.Type));
	NameText->SetText(UnitRow.DescName);

	Attribute::GetUnitAttribute(CMS, EAttributeCategory::Character, UnitRow.CmsType(),
		ItemInfo.Level, ItemInfo.Grade, nullptr, Health, Atk, Def);

	PlayAnimation(TabCharacterAnim);
}

void UPartyEditWidget::SetSculptureItem(const FItemIconInfo &ItemInfo, UCMS* CMS, int64& Health, int64& Atk, int64& Def)
{
	const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(FSculptureType(ItemInfo.Type));
	NameText->SetText(SculptureRow.DescName);

	FString EffectsStr = GetEquipEffectsStr(ItemInfo.Tier, SculptureRow.GetBuff());
	EffectsText->SetText(FText::FromString(EffectsStr));

	Attribute::GetSculptureAttribute(CMS, SculptureRow.CmsType(),
		ItemInfo.Level, ItemInfo.Tier, ItemInfo.Grade, Health, Atk, Def);

	PlayAnimation(TabEquipAnim);
}

void UPartyEditWidget::SetRelicItem(const FItemIconInfo &ItemInfo, UCMS* CMS, int64& Health, int64& Atk, int64& Def)
{
	const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(FRelicType(ItemInfo.Type));
	NameText->SetText(RelicRow.DescName);

	FString EffectsStr = GetEquipEffectsStr(ItemInfo.Tier, RelicRow.GetBuff());
	EffectsText->SetText(FText::FromString(EffectsStr));

	Attribute::GetRelicAttribute(CMS, RelicRow.CmsType(),
		ItemInfo.Level, ItemInfo.Tier, ItemInfo.Grade, Health, Atk, Def);

	PlayAnimation(TabEquipAnim);
}

void UPartyEditWidget::SetCharacterList()
{
	ItemListWidget->ClearList();
	AddItemRemovalCard();

	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();

	FCharacterId SelectedCharacterId = SelectedPartyIconWidget ? SelectedPartyIconWidget->GetCharacterId() : FCharacterId::InvalidValue();
	TArray<FCharacterId> PartyCharacterIds = GetPartyCharacterIds();
	TArray<FCharacterType> PartyCharacterTypes = CharacterMgr.GetCharacterTypes(PartyCharacterIds);

	TArray<const FCharacter*> Characters = CharacterMgr.GetCharacters(ESortMenu::PartyEdit, ESortCategory::OwnedCharacter);
	CharacterMgr.SortByPicked(Characters, PartyCharacterIds);

	for (const FCharacter* Character : Characters)
	{
		const FCharacterInfo& CharacterInfo = Character->GetInfo();

		UItemCardWidget* CharacterCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCardWidget->SetCharacter(CharacterInfo);

		bool bSelectable = true;
		if (!SelectedPartyIconWidget)
		{
			CharacterCardWidget->OnItemClickedDelegate.BindUObject(this, &UPartyEditWidget::OnItemCardClicked);
		}
		else
		{
			bSelectable = (CharacterInfo.CharacterId == SelectedCharacterId)
				|| CharacterMgr.IsEqualCharacterType(CharacterInfo.CharacterId, SelectedCharacterId)
				|| PartyCharacterIds.Contains(CharacterInfo.CharacterId)
				|| !PartyCharacterTypes.Contains(CharacterInfo.Type);

#if !UE_BUILD_SHIPPING
			if (CanJokerEditSlot())
			{
				bSelectable = true;
			}
#endif
			CharacterCardWidget->OnItemClickedDelegate.BindUObject(
				this,
				bSelectable ? &UPartyEditWidget::OnItemCardClicked : &UPartyEditWidget::OpenOverlappedToastMessage);
		}

		CharacterCardWidget->SetSelectable(true, !bSelectable);
		CharacterCardWidget->SetUsed(MemberListWidget->IsCharacterInParty(CharacterInfo.CharacterId));
		CharacterCardWidget->SetHighlight(CharacterInfo.CharacterId == SelectedCharacterId);
	}

	SortingWidget->SetSorting(ESortMenu::PartyEdit, ESortCategory::OwnedCharacter);
}

void UPartyEditWidget::SetCharacterListForJokerSet()
{
	EJokerSlotType SelectedSlot = EJokerSlotType::All;
	FCharacterId SelectedCharacterId;
	FCharacterType SelectedCharacterType;

	FCharacterId AllSlotCharacterId = GetAllSlotCharacterId();
	FCharacterType AllSlotCharacterType = GetAllSlotCharacterType();

	EJokerSlotType SwapSlot = EJokerSlotType::All;
	FCharacterId SwapSlotCharacterId;

	TArray<FCharacterType> JokerSetCharacterTypes;
	TArray<FCharacterId> JokerSetCharacterIds = GetJokerSetCharacterIds();

	if (SelectedPartyIconWidget)
	{
		SelectedSlot = SelectedPartyIconWidget->GetJokerSlotType();
		SelectedCharacterId = SelectedPartyIconWidget->GetCharacterId();
		SelectedCharacterType = SelectedPartyIconWidget->GetCharacterType();
		JokerSetCharacterTypes = GetJokerSetCharacterTypes();
		if (!AllSlotCharacterId.IsInvalid())
		{
			SwapSlot = AllSlotIconWidget()->GetSwapSlotType();
			check(SwapSlot != EJokerSlotType::All);
			UPartyIconWidget* SwapSlotIconWidget = MemberListWidget->GetPartyIconBySlotIdx(static_cast<int32>(SwapSlot));
			check(SwapSlotIconWidget);
			SwapSlotCharacterId = SwapSlotIconWidget->GetCharacterId();
		}
	}

	ItemListWidget->ClearList();
	AddItemRemovalCard();

	auto CMS = GetCMS();
	const auto& CharacterMgr = GetHUDStore().GetCharacterManager();
	TArray<const FCharacter*> Characters = CharacterMgr.GetCharacters(ESortMenu::JokerEdit, ESortCategory::OwnedCharacter);
	CharacterMgr.SortByPicked(Characters, JokerSetCharacterIds);
	for (const FCharacter* Character : Characters)
	{
		const FCharacterInfo& CharacterInfo = Character->GetInfo();
		auto NatureType = CMS->GetNatureType(CharacterInfo.Type);
		auto JokerSlot = UCMS::ToJokerSlotType(NatureType);
		auto CharacterCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCardWidget->SetCharacter(CharacterInfo);
		CharacterCardWidget->OnItemClickedDelegate.BindUObject(this, &UPartyEditWidget::OnItemCardClicked);

		bool bSelectable = false;
		if (SelectedPartyIconWidget == nullptr || CharacterInfo.CharacterId == SelectedCharacterId || CharacterInfo.Type == SelectedCharacterType)
		{
			bSelectable = true;
		}
		else if (SelectedSlot == EJokerSlotType::All)
		{
			bSelectable = CharacterInfo.CharacterId == SwapSlotCharacterId
				|| CharacterInfo.Type == AllSlotCharacterType
				|| (AllSlotCharacterId.IsInvalid() && JokerSetCharacterIds.Contains(CharacterInfo.CharacterId))
				|| !JokerSetCharacterTypes.Contains(CharacterInfo.Type);
		}
		else if (JokerSlot == SelectedSlot)
		{
			bSelectable = CharacterInfo.CharacterId == AllSlotCharacterId || CharacterInfo.Type != AllSlotCharacterType;
		}
		CharacterCardWidget->SetSelectable(bSelectable);
		CharacterCardWidget->SetUsed(MemberListWidget->IsCharacterInParty(CharacterInfo.CharacterId));
		CharacterCardWidget->SetHighlight(CharacterInfo.CharacterId == SelectedCharacterId);
	}

	SortingWidget->SetSorting(ESortMenu::JokerEdit, ESortCategory::OwnedCharacter);
}

void UPartyEditWidget::SetSculptureList(ESortMenu SortMenu)
{
	ItemListWidget->ClearList();
	AddItemRemovalCard();

	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	TArray<FSculptureId> PartySculptureIds = (SortMenu == ESortMenu::PartyEdit) ? GetPartySculptureIds() : GetJokerSetSculptureIds();
	TArray<FSculptureType> PartySculptureTypes = SculptureMgr.GetSculptureTypes(PartySculptureIds);
	TArray<const FSculpture*> Sculptures = SculptureMgr.GetSculptures(SortMenu, ESortCategory::OwnedSculpture);
	SculptureMgr.SortByPicked(Sculptures, PartySculptureIds);

	FSculptureId SelectedSculptureId = SelectedPartyIconWidget ? SelectedPartyIconWidget->GetSculptureId() : FSculptureId::InvalidValue();
	for (const FSculpture* Sculpture : Sculptures)
	{
		const FSculptureInfo& SculptureInfo = Sculpture->GetInfo();
		UItemCardWidget* EquipCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		EquipCardWidget->SetSculpture(SculptureInfo);

		bool bSelectable = true;
		if (!SelectedPartyIconWidget)
		{
			EquipCardWidget->OnItemClickedDelegate.BindUObject(this, &UPartyEditWidget::OnItemCardClicked);
		}
		else
		{
			bSelectable = (SculptureInfo.SculptureId == SelectedSculptureId)
				|| SculptureMgr.IsEqualSculptureType(SculptureInfo.SculptureId, SelectedSculptureId)
				|| PartySculptureIds.Contains(SculptureInfo.SculptureId)
				|| !PartySculptureTypes.Contains(SculptureInfo.Type);

#if !UE_BUILD_SHIPPING
			if (CanJokerEditSlot())
			{
				bSelectable = true;
			}
#endif

			EquipCardWidget->OnItemClickedDelegate.BindUObject(
				this, 
				bSelectable ? &UPartyEditWidget::OnItemCardClicked : &UPartyEditWidget::OpenOverlappedToastMessage);
		}

		EquipCardWidget->SetSelectable(true, !bSelectable);
		EquipCardWidget->SetUsed(MemberListWidget->IsSculptureInParty(SculptureInfo.SculptureId));
		EquipCardWidget->SetHighlight(SculptureInfo.SculptureId == SelectedSculptureId);
	}

	SortingWidget->SetSorting(SortMenu, ESortCategory::OwnedSculpture);
}

void UPartyEditWidget::SetRelicList(ESortMenu SortMenu)
{
	ItemListWidget->ClearList();
	AddItemRemovalCard();

	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	TArray<FRelicId> PartyRelicIds = (SortMenu == ESortMenu::PartyEdit) ? GetPartyRelicIds() : GetJokerSetRelicIds();
	TArray<FRelicType> PartyRelicTypes = RelicMgr.GetRelicTypes(PartyRelicIds);
	TArray<const FRelic*> Relics = RelicMgr.GetRelics(SortMenu, ESortCategory::OwnedRelic);
	RelicMgr.SortByPicked(Relics, PartyRelicIds);

	FRelicId SelectedRelicId = SelectedPartyIconWidget ? SelectedPartyIconWidget->GetRelicId() : FRelicId::InvalidValue();
	for (const FRelic* Relic : Relics)
	{
		const FRelicInfo& RelicInfo = Relic->Info;
		UItemCardWidget* EquipCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		EquipCardWidget->SetRelic(RelicInfo);
		EquipCardWidget->OnItemClickedDelegate.BindUObject(this, &UPartyEditWidget::OnItemCardClicked);

		bool bSelectable = true;
		if (!SelectedPartyIconWidget)
		{
			EquipCardWidget->OnItemClickedDelegate.BindUObject(this, &UPartyEditWidget::OnItemCardClicked);
		}
		else
		{
			bSelectable = (RelicInfo.RelicId == SelectedRelicId)
				|| RelicMgr.IsEqualRelicType(RelicInfo.RelicId, SelectedRelicId)
				|| PartyRelicIds.Contains(RelicInfo.RelicId)
				|| !PartyRelicTypes.Contains(RelicInfo.Type);

#if !UE_BUILD_SHIPPING
			if (CanJokerEditSlot())
			{
				bSelectable = true;
			}
#endif

			EquipCardWidget->OnItemClickedDelegate.BindUObject(
				this,
				bSelectable ? &UPartyEditWidget::OnItemCardClicked : &UPartyEditWidget::OpenOverlappedToastMessage);
		}

		EquipCardWidget->SetSelectable(true, !bSelectable);
		EquipCardWidget->SetUsed(MemberListWidget->IsRelicInParty(RelicInfo.RelicId));
		EquipCardWidget->SetHighlight(RelicInfo.RelicId == SelectedRelicId);
	}

	SortingWidget->SetSorting(SortMenu, ESortCategory::OwnedRelic);
}

void UPartyEditWidget::AddItemRemovalCard()
{
	UItemCardWidget* RemovalCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
	RemovalCardWidget->SetRemoval();
	RemovalCardWidget->SetSelectable(true);
	RemovalCardWidget->SetUsed(false);
	RemovalCardWidget->SetHighlight(false);
	RemovalCardWidget->OnItemClickedDelegate.BindUObject(this, &UPartyEditWidget::OnItemCardClicked);
}

void UPartyEditWidget::RefreshItemList(bool bInPartySelectReset)
{
	bPartySelectReset = bInPartySelectReset;

	ItemCategoryWidget->SetSelectedIndex((int32)ItemType);
}

bool UPartyEditWidget::SetChangedPartyMember(UPartyIconWidget* NewClickedPartyIconWidget, EPartyIconItemType NewItemType)
{
	if (NewItemType != ItemType)
	{
		SelectedItemCardWidget = nullptr;
		return false;
	}

	if (SelectedItemCardWidget)
	{
		int64 EquippedItemId = SelectedItemCardWidget->GetItemId();
		if (EquippedItemId == NewClickedPartyIconWidget->GetItemId(NewItemType))
		{
			SelectedItemCardWidget = nullptr;
			return false;
		}

		SelectedPartyIconWidget = FindPartyIcon(NewItemType, SelectedItemCardWidget->GetItemId());
		if (!SelectedPartyIconWidget)
		{
			// Add character in party slot

			NewClickedPartyIconWidget->SetItem(NewItemType, EquippedItemId);
			NewClickedPartyIconWidget->PlayEquipAnimation(NewItemType, EquippedItemId != ITEM_INVALID);

			SelectedItemCardWidget = nullptr;
			SelectedPartyIconWidget = nullptr;

			return true;
		}
	}

	if (NewClickedPartyIconWidget == SelectedPartyIconWidget)
	{
		// No change in slot

		SelectedItemCardWidget = nullptr;
		SelectedPartyIconWidget = nullptr;

		return true;
	}

	if (SelectedPartyIconWidget)
	{
		if ((NewClickedPartyIconWidget->GetItemId(NewItemType) == ITEM_INVALID)
			&& (SelectedPartyIconWidget->GetItemId(NewItemType) == ITEM_INVALID))
		{
			return false;
		}

		// Swap character in party slot

		if (NewItemType == EPartyIconItemType::Character)
		{
			// Swap sculpture too

			bool bEmptyPartySlot = SelectedPartyIconWidget->GetCharacterId() == ITEM_INVALID;

			FSculptureId SelectedSculptureId = bEmptyPartySlot ? FSculptureId::InvalidValue() : SelectedPartyIconWidget->GetSculptureId();
			FSculptureId NewClickedSculptureId = NewClickedPartyIconWidget->GetSculptureId();

			SelectedPartyIconWidget->SetSculptureById(NewClickedSculptureId);
			SelectedPartyIconWidget->PlayEquipAnimation(NewItemType, !NewClickedSculptureId.IsInvalid());

			NewClickedPartyIconWidget->SetSculptureById(SelectedSculptureId);
			NewClickedPartyIconWidget->PlayEquipAnimation(NewItemType, !SelectedSculptureId.IsInvalid());

			// Swap relic too

			FRelicId SelectedRelicId = bEmptyPartySlot ? FRelicId::InvalidValue() : SelectedPartyIconWidget->GetRelicId();
			FRelicId NewClickedRelicId = NewClickedPartyIconWidget->GetRelicId();

			SelectedPartyIconWidget->SetRelicById(NewClickedRelicId);
			SelectedPartyIconWidget->PlayEquipAnimation(NewItemType, !NewClickedRelicId.IsInvalid());

			NewClickedPartyIconWidget->SetRelicById(SelectedRelicId);
			NewClickedPartyIconWidget->PlayEquipAnimation(NewItemType, !SelectedRelicId.IsInvalid());
		}

		int64 SelectedItemId = SelectedPartyIconWidget->GetItemId(NewItemType);
		int64 NewClickedItemId = NewClickedPartyIconWidget->GetItemId(NewItemType);

		NewClickedPartyIconWidget->SetItem(NewItemType, SelectedItemId);
		NewClickedPartyIconWidget->PlayEquipAnimation(NewItemType, SelectedItemId > 0);

		SelectedPartyIconWidget->SetItem(NewItemType, NewClickedItemId);
		SelectedPartyIconWidget->PlayEquipAnimation(NewItemType, NewClickedItemId > 0);

		SelectedItemCardWidget = nullptr;
		SelectedPartyIconWidget = nullptr;

		return true;
	}

	return false;
}

FPartyInfo UPartyEditWidget::GetPartyInfo(int32 InPartyId) const
{
	FPartyInfo PartyInfo;
	PartyInfo.PartyId = InPartyId;
	PartyInfo.PetId = GetHUDStore().GetPartyManager().GetPartyInfo(InPartyId).PetId;

	for (int32 i = 0; i < MAX_PARTY_MEMBER; ++i)
	{
		// InPartyId == 0 is MultisideBattle(No joker)
		if (i == PARTY_JOKER_SLOT_INDEX && InPartyId != 0)
		{
			continue;
		}

		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(i);
		if (!PartyIconWidget)
		{
			continue;
		}

		FPartySlot PartySlot;
		PartySlot.CharacterId = PartyIconWidget->GetCharacterId();
		PartySlot.RelicId = PartyIconWidget->GetRelicId();
		PartySlot.SculptureId = PartyIconWidget->GetSculptureId();

		if (i < MAX_MAIN_PARTY_MEMBER)
		{
			PartyInfo.Main.Add(PartySlot);
		}
		else
		{
			PartyInfo.Sub.Add(PartySlot);
		}
	}

	return PartyInfo;
}

FPartySlot UPartyEditWidget::GetJokerSlot() const
{
	FPartySlot JokerSlot;

	UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(PARTY_JOKER_SLOT_INDEX);
	if (!PartyIconWidget)
	{
		return JokerSlot;
	}

	JokerSlot.CharacterId = PartyIconWidget->GetCharacterId();
	JokerSlot.RelicId = PartyIconWidget->GetRelicId();
	JokerSlot.SculptureId = PartyIconWidget->GetSculptureId();
	return JokerSlot;
}

FPartyInfo UPartyEditWidget::GetMultisidePartyInfo() const
{
	FPartyInfo PartyInfo;
	// PartyId == 0 means that, this info was saved by Multiside
	PartyInfo.PartyId = 0;
	PartyInfo.PetId = FPetId::InvalidValue();

	for (int32 i = 0; i < MAX_PARTY_MEMBER; ++i)
	{
		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(i);
		if (!PartyIconWidget)
		{
			continue;
		}

		FPartySlot PartySlot;
		PartySlot.CharacterId = PartyIconWidget->GetCharacterId();
		PartySlot.RelicId = PartyIconWidget->GetRelicId();
		PartySlot.SculptureId = PartyIconWidget->GetSculptureId();

		if (i < NUM_OF_PARTY_MEMBER)
		{
			PartyInfo.Main.Add(PartySlot);
		}
		else
		{
			PartyInfo.Sub.Add(PartySlot);
		}
	}

	return PartyInfo;
}

FJokerSetEx UPartyEditWidget::GetJokerSet(int32 InJokerSetId) const
{
	FJokerSetEx JokerSetEx;
	JokerSetEx.Id = InJokerSetId;

	for (int32 i = 0; i < MAX_JOKER_SLOT; ++i)
	{
		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(i);
		if (!PartyIconWidget)
		{
			continue;
		}

		FJokerSlot JokerSlot;
		JokerSlot.CharacterId = PartyIconWidget->GetCharacterId();
		JokerSlot.RelicId = PartyIconWidget->GetRelicId();
		JokerSlot.SculptureId = PartyIconWidget->GetSculptureId();
		JokerSetEx.Slots.Add(JokerSlot);
		JokerSetEx.Types.Add(PartyIconWidget->GetCharacterType());
	}

	return JokerSetEx;
}

TArray<FCharacterId> UPartyEditWidget::GetPartyCharacterIds() const
{
	TArray<FCharacterId> CharacterIds;
	const auto PartyInfo = GetPartyInfo(PartyId);
	for (const FPartySlot& PartySlot : PartyInfo.Main)
	{
		if (!PartySlot.CharacterId.IsInvalid())
		{
			CharacterIds.Add(PartySlot.CharacterId);
		}
	}
	for (const FPartySlot& PartySlot : PartyInfo.Sub)
	{
		if (!PartySlot.CharacterId.IsInvalid())
		{
			CharacterIds.Add(PartySlot.CharacterId);
		}
	}
	return CharacterIds;
}

TArray<FCharacterId> UPartyEditWidget::GetJokerSetCharacterIds() const
{
	TArray<FCharacterId> CharacterIds;
	const auto JokerSet = GetJokerSet(JokerSetId);
	for (const auto& JokerSlot : JokerSet.Slots)
	{
		if (!JokerSlot.CharacterId.IsInvalid())
		{
			CharacterIds.Add(JokerSlot.CharacterId);
		}
	}
	return CharacterIds;
}

TArray<FRelicId> UPartyEditWidget::GetPartyRelicIds() const
{
	TArray<FRelicId> RelicIds;
	const auto PartyInfo = GetPartyInfo(PartyId);
	for (const FPartySlot& PartySlot : PartyInfo.Main)
	{
		if (!PartySlot.RelicId.IsInvalid())
		{
			RelicIds.Add(PartySlot.RelicId);
		}
	}
	for (const FPartySlot& PartySlot : PartyInfo.Sub)
	{
		if (!PartySlot.RelicId.IsInvalid())
		{
			RelicIds.Add(PartySlot.RelicId);
		}
	}
	return RelicIds;
}

TArray<FRelicId> UPartyEditWidget::GetJokerSetRelicIds() const
{
	TArray<FRelicId> RelicIds;
	const auto JokerSet = GetJokerSet(JokerSetId);
	for (const auto& JokerSlot : JokerSet.Slots)
	{
		if (!JokerSlot.RelicId.IsInvalid())
		{
			RelicIds.Add(JokerSlot.RelicId);
		}
	}
	return RelicIds;
}

TArray<FSculptureId> UPartyEditWidget::GetPartySculptureIds() const
{
	TArray<FSculptureId> SculptureIds;
	const auto PartyInfo = GetPartyInfo(PartyId);
	for (const FPartySlot& PartySlot : PartyInfo.Main)
	{
		if (!PartySlot.SculptureId.IsInvalid())
		{
			SculptureIds.Add(PartySlot.SculptureId);
		}
	}
	for (const FPartySlot& PartySlot : PartyInfo.Sub)
	{
		if (!PartySlot.SculptureId.IsInvalid())
		{
			SculptureIds.Add(PartySlot.SculptureId);
		}
	}
	return SculptureIds;
}

TArray<FSculptureId> UPartyEditWidget::GetJokerSetSculptureIds() const
{
	TArray<FSculptureId> SculptureIds;
	const auto JokerSet = GetJokerSet(JokerSetId);
	for (const auto& JokerSlot : JokerSet.Slots)
	{
		if (!JokerSlot.SculptureId.IsInvalid())
		{
			SculptureIds.Add(JokerSlot.SculptureId);
		}
	}
	return SculptureIds;
}

TArray<FCharacterType> UPartyEditWidget::GetJokerSetCharacterTypes() const
{
	TArray<FCharacterType> CharacterTypes;
	const auto JokerSet = GetJokerSet(JokerSetId);
	for (const auto& Type : JokerSet.Types)
	{
		if (Type != CharacterTypeInvalid)
		{
			CharacterTypes.Add(Type);
		}
	}
	return CharacterTypes;
}

FCharacterId UPartyEditWidget::GetAllSlotCharacterId() const
{
	return AllSlotIconWidget()->GetCharacterId();
}

FCharacterType UPartyEditWidget::GetAllSlotCharacterType() const
{
	return AllSlotIconWidget()->GetCharacterType();
}

bool UPartyEditWidget::IsAllSlotSwapable(EJokerSlotType InJokerSlot) const
{
	return AllSlotIconWidget()->IsSwapable(InJokerSlot);
}

#if !UE_BUILD_SHIPPING
bool UPartyEditWidget::CanJokerEditSlot() const
{
	bool bCanDuplicate = GetHUDStore().GetPartyManager().CanJokerEdit();
	bool bSelectedJokerSlot = (MemberListWidget->GetPartyIconIndex(SelectedPartyIconWidget) == PARTY_JOKER_SLOT_INDEX);
	return (bCanDuplicate && bSelectedJokerSlot);
}
#endif

void UPartyEditWidget::OnItemCardClicked(UItemCardWidget* ItemCardWidget)
{
	TUTORIAL_MONITORING_BUTTON_CLICK("ItemCard");
	if (SelectedItemCardWidget == ItemCardWidget)
	{
		SelectedItemCardWidget = nullptr;
		RefreshItemList(true);
		return;
	}

	SelectedItemCardWidget = ItemCardWidget;

	bool bChangingFinished = false;
	if (SelectedPartyIconWidget)
	{
		if (ItemCardWidget->GetItemId() == SelectedPartyIconWidget->GetItemId(ItemType))
		{
			// Changed check icon

			SelectedPartyIconWidget = nullptr;
		}
		else
		{
			// Changed character in party slot

			bChangingFinished = SetChangedPartyMember(SelectedPartyIconWidget, ItemType);
		}
	}

	RefreshItemList(bChangingFinished);

	if (!bChangingFinished)
	{
		const FItemIconInfo& ItemInfo = ItemCardWidget->GetItemInfo();
		int64 SelectedItemId = ItemInfo.Id;
		int32 SelectedItemType = ItemInfo.Type;

		MemberListWidget->OnSelectItem(ItemType, SelectedItemId, SelectedItemType);
		SetItemInfo(ItemInfo);
	}

	if (SelectedItemCardWidget)
	{
		SelectedItemCardWidget->SetSelected(true);
	}
}

void UPartyEditWidget::OpenOverlappedToastMessage(UItemCardWidget* InDummyCardWidget)
{
	FText OverlappedText;
	switch (ItemType)
	{
		case EPartyIconItemType::Character:
			OverlappedText = Q6Util::GetLocalizedText("Lobby", "CharacterOverlapped");
			break;
		case EPartyIconItemType::Sculpture:
			OverlappedText = Q6Util::GetLocalizedText("Lobby", "SculptureOverlapped");
			break;
		case EPartyIconItemType::Relic:
			OverlappedText = Q6Util::GetLocalizedText("Lobby", "RelicOverlapped");
			break;
		case EPartyIconItemType::Max:
		default:
			Q6JsonLogGunny(
				Warning,
				"UPartyEditWidget::OpenOverlappedToastMessage - PartyIconItemType does not exist.",
				Q6KV("PartyIconItemType", static_cast<int>(ItemType)));
			return;
	}

	GetBaseHUD(this)->ShowNotification(ENotificationType::Short, OverlappedText);
}

void UPartyEditWidget::OnPartyIconClicked(UPartyIconWidget* ClickedPartyIconWidget, EPartyIconItemType InItemType)
{
	FString TutorialStr = FString::Printf(TEXT("PartyEditIcon_%s"), *ENUM_TO_STRING(EPartyIconItemType, ItemType));
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialStr);

	if (ClickedPartyIconWidget->IsSystemJoker())
	{
		// Not to do anything
		return;
	}

	if (!ClickedPartyIconWidget->IsSelectEnabled(InItemType))
	{
		OpenOverlappedToastMessage();
		return;
	}

	// Refresh UI

	bool bChangingFinished = SetChangedPartyMember(ClickedPartyIconWidget, InItemType);

	ItemType = InItemType;
	SelectedPartyIconWidget = bChangingFinished ? nullptr : ClickedPartyIconWidget;
	RefreshItemList(bChangingFinished);

	if (!bChangingFinished)
	{
		MemberListWidget->OnSelectItem(ItemType, ITEM_INVALID, ITEM_TYPE_INVALID, (int32)ClickedPartyIconWidget->GetJokerSlotType());
		ClickedPartyIconWidget->SetSelected(ItemType, EIconSelectType::Selected);

		const FItemIconInfo& ItemInfo = ClickedPartyIconWidget->GetItemInfo(ItemType);
		SetItemInfo(ItemInfo);
	}
}

void UPartyEditWidget::OnItemCategoryChanged(int32 NewIndex)
{
	ItemType = EPartyIconItemType(NewIndex);

	FString TutorialStr = FString::Printf(TEXT("PartyEditItemCategory_%s"), *ENUM_TO_STRING(EPartyIconItemType, ItemType));
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialStr);

	if (bPartySelectReset)
	{
		SetEmptyInfo();

		SelectedPartyIconWidget = nullptr;
		SelectedItemCardWidget = nullptr;
	}

	MemberListWidget->DeselectAll();
	MemberListWidget->SetHighlight(ItemType);

	const FPartyUIState& CurState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	ESortMenu SortMenu = (CurState.WidgetType == EPartyWidgetType::JokerSet) ? ESortMenu::JokerEdit : ESortMenu::PartyEdit;
	switch (ItemType)
	{
		case EPartyIconItemType::Character:
			if (SortMenu == ESortMenu::JokerEdit)
			{
				SetCharacterListForJokerSet();
			}
			else
			{
				SetCharacterList();
			}
			break;

		case EPartyIconItemType::Sculpture:
			SetSculptureList(SortMenu);
			break;

		case EPartyIconItemType::Relic:
			SetRelicList(SortMenu);
			break;
	}

	bPartySelectReset = true;
}


void UPartyEditWidget::OnPartyResetButtonClicked()
{
	UPartyResetConfirmPopupWidget* PartyResetPopup = CastChecked<UPartyResetConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(PartyResetPopupClass));
	check(PartyResetPopup);

	PartyResetPopup->InitResetOptions();
	PartyResetPopup->OnPartyResetDelegate.BindUObject(this, &UPartyEditWidget::OnPartyReset);
}

void UPartyEditWidget::OnPartyReset(bool CharacterReset, bool SculptureReset, bool RelicReset)
{
	const UContentFeatureOpenManager& ContentOpenMgr = GetHUDStore().GetContentFeatureOpenManager();
	for (int32 i = 0; i < MAX_PARTY_MEMBER; ++i)
	{
		if (!bIsMultiside)
		{
			if (i == PARTY_JOKER_SLOT_INDEX)
			{
#if !UE_BUILD_SHIPPING
				if (!GetHUDStore().GetPartyManager().CanJokerEdit())
				{
					continue;
				}
#else
				continue;
#endif
			}

			bool bOpened = ContentOpenMgr.CheckContentOpenedBySubPartySlotIndex(i);
			if (!bOpened)
			{
				continue;
			}
		}

		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(i);
		check(PartyIconWidget);

		if (CharacterReset)
		{
			PartyIconWidget->SetCharacterEmpty();	// Also reset sculpture and relic
			PartyIconWidget->PlayEquipAnimation(EPartyIconItemType::Character, false);
			continue;
		}

		if (SculptureReset)
		{
			PartyIconWidget->SetSculptureEmpty();
			PartyIconWidget->PlayEquipAnimation(EPartyIconItemType::Sculpture, false);
		}

		if (RelicReset)
		{
			PartyIconWidget->SetRelicEmpty();
			PartyIconWidget->PlayEquipAnimation(EPartyIconItemType::Relic, false);
		}
	}

	RefreshItemList(true);
}

UItemCardWidget* UPartyEditWidget::FindItemCard(int64 ItemId) const
{
	for (int32 i = 0; i < ItemListWidget->GetChildrenCount(); ++i)
	{
		UItemCardWidget* CharacterCardWidget = Cast<UItemCardWidget>(ItemListWidget->FindChildAt(i));
		if (!CharacterCardWidget)
		{
			continue;
		}

		if (CharacterCardWidget->GetItemId() != ItemId)
		{
			continue;
		}

		return CharacterCardWidget;
	}

	return nullptr;
}

UPartyIconWidget* UPartyEditWidget::FindPartyIcon(EPartyIconItemType InItemType, int64 InItemId) const
{
	for (int32 i = 0; i < EJokerSlotTypeMax; ++i)
	{
		UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(i);
		if (!PartyIconWidget)
		{
			continue;
		}

		// Find by equipment id

		int64 ItemId = PartyIconWidget->GetItemId(InItemType);
		if ((ItemId == 0) || (ItemId != InItemId))
		{
			continue;
		}

		return PartyIconWidget;
	}

	return nullptr;
}

UPartyIconWidget* UPartyEditWidget::AllSlotIconWidget() const
{
	UPartyIconWidget* PartyIconWidget = MemberListWidget->GetPartyIconBySlotIdx(static_cast<int32>(EJokerSlotType::All));
	check(PartyIconWidget);
	return PartyIconWidget;
}

bool UPartyEditWidget::IsChangedInitPartyInfo(const FPartyInfo& EditingPartyInfo, const FPartySlot& OwnedJokerSlot) const
{
	const UPartyManager& PartyMgr = GetHUDStore().GetPartyManager();
	const FPartyInfo& OrgPartyInfo = PartyMgr.GetPartyInfo(PartyId);

	// Check the main member
	check(EditingPartyInfo.Main.Num() == MAX_MAIN_PARTY_MEMBER);
	check(OrgPartyInfo.Main.Num() == MAX_MAIN_PARTY_MEMBER);
	for (int idx = 0; idx < MAX_MAIN_PARTY_MEMBER; ++idx)
	{
		const auto& Editing = EditingPartyInfo.Main[idx];
		const auto& Org = OrgPartyInfo.Main[idx];
		if (Editing.CharacterId != Org.CharacterId ||
			Editing.SculptureId != Org.SculptureId ||
			Editing.RelicId != Org.RelicId)
		{
			return true;
		}
	}

	// Check the sub member
	check(EditingPartyInfo.Sub.Num() == MAX_SUB_PARTY_MEMBER);
	check(OrgPartyInfo.Sub.Num() == MAX_SUB_PARTY_MEMBER);
	for (int idx = 0; idx < MAX_SUB_PARTY_MEMBER; ++idx)
	{
		const auto& Editing = EditingPartyInfo.Sub[idx];
		const auto& Org = OrgPartyInfo.Sub[idx];
		if (Editing.CharacterId != Org.CharacterId ||
			Editing.SculptureId != Org.SculptureId ||
			Editing.RelicId != Org.RelicId)
		{
			return true;
		}
	}

	if (PartyMgr.GetJokerType() == EJokerType::OwnedJoker)
	{
		const FPartySlot& OrgOwnedJokerSlot = PartyMgr.GetOwnedJokerSlot();

		if (OwnedJokerSlot.CharacterId != OrgOwnedJokerSlot.CharacterId ||
			OwnedJokerSlot.SculptureId != OrgOwnedJokerSlot.SculptureId ||
			OwnedJokerSlot.RelicId != OrgOwnedJokerSlot.RelicId)
		{
			return true;
		}
	}

	//Not Changed

	return false;
}

bool UPartyEditWidget::IsChangedInitMultisidePartyInfo(const FPartyInfo& EditingPartyInfo) const
{
	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	check(GameInstance);
	UQ6SaveGame* SaveGame = GameInstance->GetSaveGame();
	const FPartyInfo& PartyInfo = SaveGame->GetMultisidePartyInfo();

	// main
	for (int i = 0; i < NUM_OF_PARTY_MEMBER; ++i)
	{
		check(PartyInfo.Main.IsValidIndex(i));
		const FPartySlot& Org = PartyInfo.Main[i];

		check(EditingPartyInfo.Main.IsValidIndex(i));
		const FPartySlot& Editing = EditingPartyInfo.Main[i];

		if (Editing.CharacterId != Org.CharacterId ||
			Editing.SculptureId != Org.SculptureId ||
			Editing.RelicId != Org.RelicId)
		{
			return true;
		}
	}

	// sub
	for (int i = 0; i < NUM_OF_PARTY_MEMBER; ++i)
	{
		check(PartyInfo.Sub.IsValidIndex(i));
		const FPartySlot& Org = PartyInfo.Sub[i];

		check(EditingPartyInfo.Sub.IsValidIndex(i));
		const FPartySlot& Editing = EditingPartyInfo.Sub[i];

		if (Editing.CharacterId != Org.CharacterId ||
			Editing.SculptureId != Org.SculptureId ||
			Editing.RelicId != Org.RelicId)
		{
			return true;
		}
	}

	return false;
}

bool UPartyEditWidget::IsChangedInitJokerSet(const FJokerSet& EditingJokerSet) const
{
	const auto& OrgJokerSet = GetHUDStore().GetJokerManager().GetJokerSet(JokerSetId);

	check(EditingJokerSet.Slots.Num() == MAX_JOKER_SLOT);
	check(OrgJokerSet.Slots.Num() == MAX_JOKER_SLOT);

	for (int idx = 0; idx < MAX_JOKER_SLOT; ++idx)
	{
		const auto& Editing = EditingJokerSet.Slots[idx];
		const auto& Org = OrgJokerSet.Slots[idx];
		if (Editing.CharacterId != Org.CharacterId ||
			Editing.SculptureId != Org.SculptureId ||
			Editing.RelicId != Org.RelicId)
		{
			return true;
		}
	}

	return false;
}

UPartyWidget::UPartyWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPartyWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PartyMenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("PartyMenu"));
	PartySelectWidget = CastChecked<UPartySelectWidget>(GetWidgetFromName("PartySelect"));
	PartySelectWidget->OnJokerSetChangeDelegate.BindUObject(this, &UPartyWidget::OnJokerSetChanged);

	PartyEditButton = CastChecked<UButton>(GetWidgetFromName("ButtonPartyEdit"));
	PartyEditButton->OnClicked.AddUniqueDynamic(this, &UPartyWidget::OnPartyEditButtonClicked);

	PartySaveButton = CastChecked<UButton>(GetWidgetFromName("ButtonSave"));
	PartySaveButton->OnClicked.AddUniqueDynamic(this, &UPartyWidget::OnSaveButtonClicked);

	JokerUsedBorder = CastChecked<UBorder>(GetWidgetFromName("JokerUsed"));
	JokerUseButton = CastChecked<UButton>(GetWidgetFromName("JokerUse"));
	JokerUseButton->OnClicked.AddUniqueDynamic(this, &UPartyWidget::OnJokerUseButtonClicked);

	JokerEditButton = CastChecked<UButton>(GetWidgetFromName("JokerEdit"));
	JokerEditButton->OnClicked.AddUniqueDynamic(this, &UPartyWidget::OnJokerEditButtonClicked);

	CombatStartButton = CastChecked<UPointButtonWidget>(GetWidgetFromName("CombatStart"));
	CombatStartButton->OnPointButtonClickedDelegate.BindUObject(this, &UPartyWidget::OnCombatStartButtonClicked);
	CombatStartButton->SetName(Q6Util::GetLocalizedText("Lobby", "CombatStart"));
	// Watt-Consume: "Required/Having", !VisibleMax, <=: White, Others: Red
	CombatStartButton->SetPointType(EPointType::Watt, EPointWidgetOption::LessEqual);

	BottomMenuBox = CastChecked<USizeBox>(GetWidgetFromName("BottomMenu"));
	BottomJokerBox = CastChecked<USizeBox>(GetWidgetFromName("BottomJoker"));

	BottomSpacer = CastChecked<USpacer>(GetWidgetFromName("BottomSpacer"));

	CollectionButtonWidget = CastChecked<UQuickMenuButtonWidget>(GetWidgetFromName("Collection"));
	CollectionButtonWidget->OnMenuButtonClickedDelegate.BindUObject(this, &UPartyWidget::OnCollectionButtonClicked);

	JokerSetttingButtonWidget = CastChecked<UQuickMenuButtonWidget>(GetWidgetFromName("JokerSetting"));
	JokerSetttingButtonWidget->OnMenuButtonClickedDelegate.BindUObject(this, &UPartyWidget::OnJokerSettingButtonClicked);

	ShowUserIDCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("ToggleUserID"));
	ShowUserIDCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UPartyWidget::SetShowUserId);
	ShowUserIDCheckBox->SetCheckedState(ECheckBoxState::Unchecked);
	InitShowUserId();

	UserIdBorder = CastChecked<UBorder>(GetWidgetFromName("UserIDBox"));
	UserIDText = CastChecked<UTextBlock>(GetWidgetFromName("TextUserID"));
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	UserIDText->SetText(FText::FromString(WorldUser.GetUserDisplayCode()));

	PartyMenuAnim = GetWidgetAnimationFromName(this, "AnimMenuParty");
	JokerMenuAnim = GetWidgetAnimationFromName(this, "AnimMenuJoker");
}

void UPartyWidget::NativeDestruct()
{
	if (RegularRaidMatchTimerWidget && RegularRaidMatchTimerWidget->IsInViewport())
	{
		RegularRaidMatchTimerWidget->RemoveFromParent();
	}

	Super::NativeDestruct();
}

void UPartyWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Party);
	SubscribeToStore(EHSType::JokerSet);
	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::Character);
	SubscribeToStore(EHSType::Relic);
	SubscribeToStore(EHSType::Sculpture);
	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::ContentFeatureOpen);
	SubscribeToStore(EHSType::Raid);

	RefreshWatt();
}

bool UPartyWidget::OnBack()
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType == EContentType::Raid)
	{
		const FRegularRaidState& RegularRaidState = GetHUDStore().GetRaidManager().GetRegularRaidState();
		if (RegularRaidState.RespReady
			&& RegularRaidMatchTimerWidget
			&& RegularRaidMatchTimerWidget->IsInViewport())
		{
			return false;
		}
	}

	const FPartyUIState& CurState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	if (CurState.bIsEdit && !bIsClosedPopup)
	{
		UPartyEditWidget* PartyEditWidget = FindOrCreatePartyEditWidget();
		if (CurState.WidgetType == EPartyWidgetType::JokerSet)
		{
			const FJokerSetEx EditingJokerSet = PartyEditWidget->GetJokerSet(CurState.PageNum);
			if (PartyEditWidget->IsChangedInitJokerSet(EditingJokerSet))
			{
				auto EditCancelPopup = CastChecked<UPartyEditCancleConfirmPopupWidget>(
					GetCheckedLobbyHUD(this)->OpenPopup(PartyEditCancelConfirmPopupClass));
				EditCancelPopup->SetJokerSet(EditingJokerSet);
				EditCancelPopup->OnConfirmPopupDelegate.BindUObject(this, &UPartyWidget::OnPopupButtonClicked);
				return false;
			}
		}
		else
		{
			if (SagaRow.ContentType == EContentType::MultiSideBattle)
			{
				const FPartyInfo EditingPartyInfo = PartyEditWidget->GetMultisidePartyInfo();
				if (PartyEditWidget->IsChangedInitMultisidePartyInfo(EditingPartyInfo))
				{
					UPartyEditCancleConfirmPopupWidget* EditCancelPopup = CastChecked<UPartyEditCancleConfirmPopupWidget>(
						GetCheckedLobbyHUD(this)->OpenPopup(PartyEditCancelConfirmPopupClass));
					EditCancelPopup->SetMultisideParty(EditingPartyInfo);
					EditCancelPopup->OnConfirmPopupDelegate.BindUObject(this, &UPartyWidget::OnPopupButtonClicked);
					return false;
				}
			}
			else
			{
				const UPartyManager& PartyMgr = GetHUDStore().GetPartyManager();
				const FPartyInfo EditingPartyInfo = PartyEditWidget->GetPartyInfo(CurState.PageNum);
				const FPartySlot EditingJokerSlot = PartyEditWidget->GetJokerSlot();
				if (PartyEditWidget->IsChangedInitPartyInfo(EditingPartyInfo, EditingJokerSlot))
				{
					UPartyEditCancleConfirmPopupWidget* EditCancelPopup = CastChecked<UPartyEditCancleConfirmPopupWidget>(
						GetCheckedLobbyHUD(this)->OpenPopup(PartyEditCancelConfirmPopupClass));
					EditCancelPopup->SetParty(EditingPartyInfo, EditingJokerSlot);
					EditCancelPopup->OnConfirmPopupDelegate.BindUObject(this, &UPartyWidget::OnPopupButtonClicked);
					return false;
				}
			}
		}
	}

	return true;
}

void UPartyWidget::RefreshMenu()
{
	Super::RefreshMenu();

	if (RegularRaidMatchTimerWidget && RegularRaidMatchTimerWidget->IsInViewport())
	{
		return;
	}

	const FPartyUIState* UIState = GetUIState()->CastToPartyUIState();
	check(UIState);

	SagaType = UIState->SagaType;
	WidgetType = UIState->WidgetType;

	UPartyEditWidget* PartyEditWidget = FindOrCreatePartyEditWidget();
	PartyEditWidget->SetTopSpacer(WidgetType == EPartyWidgetType::CombatReady);

	if (WidgetType == EPartyWidgetType::JokerSet)
	{
		TUTORIAL_MONITORING_BUTTON_CLICK("EnterJokerSetMenu");
		if (UIState->bIsEdit)
		{
			SetJokerSetEdit(UIState->PageNum, UIState->ItemType, UIState->SelectedSlotIdx);
		}
		else
		{
			SetJokerSetList();
		}
	}
	else
	{
		if (UIState->bIsEdit)
		{
			const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
			if (SagaRow.ContentType == EContentType::MultiSideBattle)
			{
				SetMultisidePartyEdit(UIState->ItemType, UIState->SelectedSlotIdx);
			}
			else
			{
				SetPartyEdit(UIState->PageNum, UIState->ItemType, UIState->SelectedSlotIdx);
			}
		}
		else
		{
			SetPartyList();
		}
	}
}

void UPartyWidget::SetPartyList()
{
	USizeBox* CombatStartBox = CastChecked<USizeBox>(CombatStartButton->GetParent());
	bool bIsMultisideBattle = false;

	if (SagaType != SagaTypeInvalid)
	{
		const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

		CombatStartBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		CollectionButtonWidget->SetVisibility(ESlateVisibility::Collapsed);
		JokerSetttingButtonWidget->SetVisibility(ESlateVisibility::Collapsed);
		bIsMultisideBattle = SagaRow.ContentType == EContentType::MultiSideBattle;

		if (bIsMultisideBattle)
		{
			const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
			SetEventWattPoint(UIState.EventContentType, SagaRow.WattConsume);
		}
		else
		{
			CombatStartButton->SetPoint(SagaRow.WattConsume, GetUser().GetWatt());
		}
	}
	else
	{
		CombatStartBox->SetVisibility(ESlateVisibility::Collapsed);
		CollectionButtonWidget->SetVisibility(ESlateVisibility::Visible);
		JokerSetttingButtonWidget->SetVisibility(ESlateVisibility::Visible);
	}

	PartyMenuSwitcher->SetActiveWidget(PartySelectWidget);
	BottomMenuBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	if (bIsMultisideBattle)
	{
		PartySelectWidget->SetMultisideParty();
	}
	else
	{
		const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
		PartySelectWidget->SetParty(UIState.PageNum);
	}

	BottomSpacer->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	PartySaveButton->SetVisibility(ESlateVisibility::Collapsed);
	PartyEditButton->SetVisibility(ESlateVisibility::Visible);

	ShowUserIDCheckBox->SetVisibility(ESlateVisibility::Collapsed);
	UserIdBorder->SetVisibility(ESlateVisibility::Collapsed);

	PlayAnimation(PartyMenuAnim);
}

void UPartyWidget::SetPartyEdit(int32 PartyId, EPartyIconItemType InItemType, int32 SelectedSlotIdx)
{
	USizeBox* CombatStartBox = CastChecked<USizeBox>(CombatStartButton->GetParent());
	CombatStartBox->SetVisibility(ESlateVisibility::Collapsed);
	CollectionButtonWidget->SetVisibility(ESlateVisibility::Collapsed);
	JokerSetttingButtonWidget->SetVisibility(ESlateVisibility::Collapsed);

	UPartyEditWidget* PartyEditWidget = FindOrCreatePartyEditWidget();
	PartyMenuSwitcher->SetActiveWidget(PartyEditWidget);
	BottomMenuBox->SetVisibility(ESlateVisibility::Collapsed);

	PartyEditWidget->SetParty(PartyId, InItemType, SelectedSlotIdx);
	BottomSpacer->SetVisibility(ESlateVisibility::Collapsed);

	PartySaveButton->SetVisibility(ESlateVisibility::Visible);
	PartyEditButton->SetVisibility(ESlateVisibility::Collapsed);

	bIsClosedPopup = false;
}

void UPartyWidget::SetMultisidePartyEdit(EPartyIconItemType ItemType, int32 SelectedSlotIdx)
{
	USizeBox* CombatStartBox = CastChecked<USizeBox>(CombatStartButton->GetParent());
	CombatStartBox->SetVisibility(ESlateVisibility::Collapsed);
	CollectionButtonWidget->SetVisibility(ESlateVisibility::Collapsed);
	JokerSetttingButtonWidget->SetVisibility(ESlateVisibility::Collapsed);

	UPartyEditWidget* PartyEditWidget = FindOrCreatePartyEditWidget();
	PartyMenuSwitcher->SetActiveWidget(PartyEditWidget);
	BottomMenuBox->SetVisibility(ESlateVisibility::Collapsed);

	PartyEditWidget->SetMultisideParty(ItemType, SelectedSlotIdx);
	BottomSpacer->SetVisibility(ESlateVisibility::Collapsed);

	PartySaveButton->SetVisibility(ESlateVisibility::Visible);
	PartyEditButton->SetVisibility(ESlateVisibility::Collapsed);

	bIsClosedPopup = false;
}

void UPartyWidget::SetJokerSetList()
{
	PartyMenuSwitcher->SetActiveWidget(PartySelectWidget);
	BottomMenuBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	BottomJokerBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	BottomSpacer->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	JokerEditButton->SetVisibility(ESlateVisibility::Visible);
	PartySaveButton->SetVisibility(ESlateVisibility::Collapsed);

	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	PartySelectWidget->SetJokerSet(UIState.PageNum);
	OnJokerSetChanged(UIState.PageNum);

	ShowUserIDCheckBox->SetVisibility(ESlateVisibility::Visible);
	UserIdBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	PlayAnimation(JokerMenuAnim);
}

void UPartyWidget::SetJokerSetEdit(int32 JokerSetId, EPartyIconItemType InItemType, int32 SelectedSlotIdx)
{
	UPartyEditWidget* PartyEditWidget = FindOrCreatePartyEditWidget();
	PartyMenuSwitcher->SetActiveWidget(PartyEditWidget);

	PartyEditWidget->SetJokerSet(JokerSetId, InItemType, SelectedSlotIdx);
	JokerUsedBorder->SetVisibility(ESlateVisibility::Collapsed);
	JokerUseButton->SetVisibility(ESlateVisibility::Collapsed);

	BottomMenuBox->SetVisibility(ESlateVisibility::Collapsed);
	BottomSpacer->SetVisibility(ESlateVisibility::Collapsed);
	BottomJokerBox->SetVisibility(ESlateVisibility::Collapsed);
	JokerEditButton->SetVisibility(ESlateVisibility::Collapsed);
	PartySaveButton->SetVisibility(ESlateVisibility::Visible);

	ShowUserIDCheckBox->SetVisibility(ESlateVisibility::Collapsed);
	UserIdBorder->SetVisibility(ESlateVisibility::Collapsed);

	bIsClosedPopup = false;
}

EHUDWidgetType UPartyWidget::GetHUDWidgetType() const
{
	if (WidgetType == EPartyWidgetType::Party)
	{
		return EHUDWidgetType::Party;
	}

	if (WidgetType == EPartyWidgetType::JokerSet)
	{
		return EHUDWidgetType::Joker;
	}

	Q6JsonLogRoze(Error, "UPartyWidget::GetHUDWidgetType - Where are you in there?");
	return EHUDWidgetType::Invalid;
}

void UPartyWidget::RefreshWatt()
{
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(UIState.SagaType);
	if (SagaRow.ContentType == EContentType::MultiSideBattle)
	{
		SetEventWattPoint(UIState.EventContentType, SagaRow.WattConsume);
	}
	else
	{
		CombatStartButton->SetMyPoint(GetHUDStore().GetWorldUser().GetWatt());
	}
}

void UPartyWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByParty);

	switch (InAction->GetActionType())
	{
		case EHSActionType::PartySaveResp:
		case EHSActionType::MultisidePetSave:
		case EHSActionType::MultisidePartySave:
			GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "PartySaved"));
			RefreshMenu();
			break;
		case EHSActionType::JokerSetSaveResp:
			GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "JokerSaved"));
			RefreshMenu();
			break;
		case EHSActionType::WattInfo:
		{
			const FPartyUIState* UIState = GetUIState()->CastToPartyUIState();
			if (UIState)
			{
				RefreshWatt();
				RefreshMenu();
			}
		}
		break;
		case EHSActionType::PartyEventContentType:
			RefreshWatt();
			RefreshMenu();
			break;
		case EHSActionType::PartyChange:
		case EHSActionType::JokerSetChange:
			GetCheckedLobbyHUD(this)->RefreshNaviBar();
			break;
		case EHSActionType::SortingChange:
			FindOrCreatePartyEditWidget()->RefreshItemList(true);
			break;
		case EHSActionType::PartyEdit:
		case EHSActionType::PartyMain:
		case EHSActionType::JokerSetEdit:
		case EHSActionType::JokerSetMain:
		case EHSActionType::DevContentFeatureOpenResp:
		case EHSActionType::CharacterSetIllustResp:
			RefreshMenu();
			break;
		case EHSActionType::JokerSetUseResp:
		{
			const auto& Action = ACTION_PARSE_JokerSetUseResp(InAction);
			const FL2CJokerSetUseResp& Resp = Action->GetVal();

			OnJokerSetChanged(Resp.SelectedId);
			break;
		}
		case EHSActionType::RegularRaidMatchedNoti:
		{
			if (RegularRaidMatchTimerWidget && RegularRaidMatchTimerWidget->IsInViewport())
			{
				OnCombatStartButtonClicked();
			}
		}
		break;
		case EHSActionType::PartyPetEdit:
		default:
			break;
	}
}

void UPartyWidget::OnPartyEditButtonClicked()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("ButtonPartyEdit");
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	if (UIState.bIsEdit)
	{
		Q6JsonLogRoze(Warning, "UPartyWidget::OnPartyEditButtonClicked - Not in party list menu");
		return;
	}

	// Change to edit ui
	ACTION_DISPATCH_PartyEdit(EPartyIconItemType::Character, INDEX_NONE);
}

void UPartyWidget::OnSaveButtonClicked()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("PartyButtonSave");
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	if (!UIState.bIsEdit)
	{
		Q6JsonLogRoze(Warning, "UPartyWidget::OnSaveButtonClicked - Not in party edit menu");
		return;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType == EContentType::MultiSideBattle)
	{
		UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
		SaveGame->SaveMultisidePartyInfo(FindOrCreatePartyEditWidget()->GetMultisidePartyInfo());
		ACTION_DISPATCH_MultisidePartySave();
		return;
	}

	if (UIState.WidgetType == EPartyWidgetType::JokerSet)
	{
		// Joker set save
		auto JokerSet = FindOrCreatePartyEditWidget()->GetJokerSet(UIState.PageNum);
		GetHUDStore().GetJokerManager().ReqJokerSetSave(JokerSet);
	}
	else
	{
		FPartyInfo PartyInfo = FindOrCreatePartyEditWidget()->GetPartyInfo(UIState.PageNum);
		FPartySlot JokerSlot = FindOrCreatePartyEditWidget()->GetJokerSlot();
		GetHUDStore().GetPartyManager().ReqPartySave(PartyInfo, JokerSlot);
	}

	UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
	SaveGame->SetSavedPartySlot(UIState.PageNum);
}

void UPartyWidget::OnCollectionButtonClicked()
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Collection);
}

void UPartyWidget::OnJokerSettingButtonClicked()
{
	const auto& JokerMgr = GetHUDStore().GetJokerManager();
	ACTION_DISPATCH_JokerSetMain(JokerMgr.GetSelectedId());
}

void UPartyWidget::OnJokerUseButtonClicked()
{
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	check(UIState.WidgetType == EPartyWidgetType::JokerSet);
	check(!UIState.bIsEdit);
	GetHUDStore().GetJokerManager().ReqJokerSetUse(UIState.PageNum);
}

void UPartyWidget::OnJokerEditButtonClicked()
{
	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	check(UIState.WidgetType == EPartyWidgetType::JokerSet);

	if (UIState.bIsEdit)
	{
		Q6JsonLogRoze(Warning, "UPartyWidget::OnJokerEditButtonClicked - Not in joker list menu");
		return;
	}

	// Change to edit ui
	ACTION_DISPATCH_JokerSetEdit(EPartyIconItemType::Character, INDEX_NONE);
}

void UPartyWidget::OnCombatStartButtonClicked()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("CombatStart");
	if (!CombatStartButton->IsEnoughPoint())
	{
		GetCheckedLobbyHUD(this)->OpenConfirmPopup(FText::GetEmpty(), Q6Util::GetLocalizedText("Lobby", "NotEnoughWatt"));
		return;
	}

	const UHUDStore& HUDStore = GetHUDStore();

	const FPartyUIState& UIState = HUDStore.GetUIStateManager().GetPartyUIState();
	if (!HUDStore.GetPartyManager().IsValidParty(UIState.PageNum))
	{
		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "NotEnoughPartyMember"));
		return;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType == EContentType::Raid)
	{
		const URaidManager& RaidMgr = HUDStore.GetRaidManager();
		const FRaidType OpenRaidType = RaidMgr.GetOpenRaidType();
		const FRaidId OpenRaidId = RaidMgr.GetOpenRaidId();

		if (OpenRaidType == RaidTypeInvalid
			|| OpenRaidId == FRaidId::InvalidValue())
		{
			const FRegularRaidState& RegularRaidState = RaidMgr.GetRegularRaidState();

			if (RegularRaidState.RespReady)
			{
				OpenRaidExpiredConfirmPopup();
				return;
			}

			if (RegularRaidState.RaidType != RaidTypeInvalid)
			{
				OpenRegularRaidMatchTimerWidget();
				return;
			}

			OpenRaidExpiredConfirmPopup();
			return;
		}
	}

	FPartyInfo PartyInfo = FPartyInfo();
	TArray<FCCCombatSeedUnit> Units;
	const UPartyManager& PartyMgr = HUDStore.GetPartyManager();
	bool bIsMultiside = SagaRow.ContentType == EContentType::MultiSideBattle;

	if (bIsMultiside)
	{
		UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
		PartyInfo = SaveGame->GetMultisidePartyInfo();

		if (PartyInfo.Main.Num() != NUM_OF_PARTY_MEMBER || PartyInfo.Sub.Num() != NUM_OF_PARTY_MEMBER)
		{
			GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short
				, Q6Util::GetLocalizedText("Lobby", "MultisidePartyNotFull"));
			return;
		}

		for (const FPartySlot& PartySlot : PartyInfo.Main)
		{
			if (PartySlot.CharacterId.IsInvalid())
			{
				GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short
					, Q6Util::GetLocalizedText("Lobby", "MultisidePartyNotFull"));
				return;
			}
		}

		for (const FPartySlot& PartySlot : PartyInfo.Sub)
		{
			if (PartySlot.CharacterId.IsInvalid())
			{
				GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short
					, Q6Util::GetLocalizedText("Lobby", "MultisidePartyNotFull"));
				return;
			}
		}
	}
	else
	{
		PartyInfo = PartyMgr.GetPartyInfo(UIState.PageNum);
	}

	for (const FPartySlot& PartySlot : PartyInfo.Main)
	{
		AddPartyCharacterUnit(PartySlot, Units);
	}

	if (!bIsMultiside)
	{
		UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
		SaveGame->SetSavedPartySlot(PartyInfo.PartyId);

		// Add Joker Unit
		if (ensure(Units.Num() < 3))
		{
			EJokerType JokerType = PartyMgr.GetJokerType();

			switch (JokerType)
			{
				case EJokerType::SystemJoker:
				{
					const FCharacterInfo& SystemJokerInfo = PartyMgr.GetSystemJokerInfo();
					AddSystemJokerUnit(SystemJokerInfo, Units);
					break;
				}
				case EJokerType::FriendJoker:
				{
					const FFriendJokerSlot& FriendJokerSlot = PartyMgr.GetFriendJokerSlot();
					const FFriendInfo& FriendJokerInfo = PartyMgr.GetFriendJokerInfo();
					bool bRecommedFriend = FriendJokerInfo.FriendId.IsInvalid();
					AddFriendJokerUnit(FriendJokerSlot, bRecommedFriend, Units);
					break;
				}
				case EJokerType::RandomJoker:
				{
					const FCharacterInfo& RandomJokerInfo = PartyMgr.GetRandomJokerInfo();
					AddSystemJokerUnit(RandomJokerInfo, Units);
					break;
				}
				case EJokerType::OwnedJoker:
				{
					const FPartySlot& OwnedJokerSlot = PartyMgr.GetOwnedJokerSlot();
					AddPartyCharacterUnit(OwnedJokerSlot, Units);
					break;
				}
			}
		}
		UQ6GameInstance::Get(this)->SetCombatSeedBanIndices(SaveGame->GetBanIndices());
	}

	TArray<FCCCombatSeedUnit> SubUnits;
	for (const FPartySlot& PartySlot : PartyInfo.Sub)
	{
		AddPartyCharacterUnit(PartySlot, SubUnits);
	}

	UQ6GameInstance::Get(this)->SetSaga(SagaType);
	UQ6GameInstance::Get(this)->SetCombatSeedPartyId(UIState.PageNum);
	UQ6GameInstance::Get(this)->SetCombatSeedUnits(Units, SubUnits);
	UQ6GameInstance::Get(this)->RequestBeginStage();

	if (bIsMultiside)
	{
		ACTION_DISPATCH_MenuBack();
		return;
	}

	ACTION_DISPATCH_MenuDoubleBack();
}

void UPartyWidget::AddPartyCharacterUnit(const FPartySlot &PartySlot, TArray<FCCCombatSeedUnit> &Units) const
{
	if (PartySlot.CharacterId.IsInvalid())
	{
		return;
	}

	auto& CharacterMgr = GetHUDStore().GetCharacterManager();
	const FCharacter* Character = CharacterMgr.Find(PartySlot.CharacterId);
	if (!Character)
	{
		return;
	}

	const FSculptureInfo* SculptureInfo = nullptr;
	if (!PartySlot.SculptureId.IsInvalid())
	{
		auto& SculptureMgr = GetHUDStore().GetSculptureManager();
		auto Sculpture = SculptureMgr.Find(PartySlot.SculptureId);
		if (Sculpture)
		{
			SculptureInfo = &Sculpture->Info;
		}
	}

	const FRelicInfo* RelicInfo = nullptr;
	if (!PartySlot.RelicId.IsInvalid())
	{
		auto& RelicMgr = GetHUDStore().GetRelicManager();
		auto Relic = RelicMgr.Find(PartySlot.RelicId);
		if (Relic)
		{
			RelicInfo = &Relic->Info;
		}
	}

	const FCharacterBond& CharacterBond = GetHUDStore().GetBondManager().GetCharacterBond(Character->GetInfo().Type);
	AddCharacterUnit(Character->GetInfo(), SculptureInfo, RelicInfo, CharacterBond.SupportSkillLevel, EAttributeCategory::Character, Units);
}

void UPartyWidget::AddSystemJokerUnit(const FCharacterInfo& JokerInfo, TArray<FCCCombatSeedUnit>& Units) const
{
	const FCMSSystemJokerRow& R = GetCMS()->GetSystemJokerRowOrDummy(FSystemJokerType(JokerInfo.Type));
	int32 SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	if (!R.IsInvalid())
	{
		SupportSkillLevel = R.SupportSkillLevel;
	}
	else
	{
		Q6JsonLog(Warning, "can not found SystemJoker.", Q6KV("Type", JokerInfo.Type));
	}

	AddCharacterUnit(JokerInfo, nullptr, nullptr, SupportSkillLevel, EAttributeCategory::SystemJoker, Units);
}

void UPartyWidget::AddFriendJokerUnit(const FFriendJokerSlot& FriendJokerSlot, bool bRecommendJoker, TArray<FCCCombatSeedUnit>& Units) const
{
	const FCharacterInfo& CharacterInfo = FriendJokerSlot.CharacterInfo;
	check(!CharacterInfo.CharacterId.IsInvalid());

	const FSculptureInfo* SculptureInfo = nullptr;
	if (!FriendJokerSlot.SculptureInfo.SculptureId.IsInvalid())
	{
		SculptureInfo = &FriendJokerSlot.SculptureInfo;
	}

	const FRelicInfo* RelicInfo = nullptr;
	if (!FriendJokerSlot.RelicInfo.RelicId.IsInvalid())
	{
		RelicInfo = &FriendJokerSlot.RelicInfo;
	}

	EAttributeCategory Ratio = bRecommendJoker ? EAttributeCategory::RecommendJoker : EAttributeCategory::FriendJoker;
	AddCharacterUnit(CharacterInfo, SculptureInfo, RelicInfo, FriendJokerSlot.CharacterBond.SupportSkillLevel, Ratio, Units);
}

void UPartyWidget::AddCharacterUnit(const FCharacterInfo& CharacterInfo, const FSculptureInfo* SculptureInfo,
	const FRelicInfo* RelicInfo, int32 SupportSkillLevel, EAttributeCategory InAttributeRatioType, TArray<FCCCombatSeedUnit>& Units) const
{
	int32 NewIndex = Units.AddDefaulted();
	UCombatCubeStateUtil::ConvertCharacterInfoToCombatSeedUnit(CharacterInfo, SculptureInfo, RelicInfo, SupportSkillLevel, InAttributeRatioType, &Units[NewIndex]);
}

UPartyEditWidget* UPartyWidget::FindOrCreatePartyEditWidget()
{
	UPartyEditWidget* PartyEditWidget = Cast<UPartyEditWidget>(PartyMenuSwitcher->GetWidgetAtIndex(1));	// party edit menu index
	if (!PartyEditWidget)
	{
		PartyEditWidget = CreateWidget<UPartyEditWidget>(GetOwningPlayer(), PartyEditWidgetClass.LoadSynchronous());
		PartyMenuSwitcher->AddChild(PartyEditWidget);
	}

	check(PartyEditWidget);
	return PartyEditWidget;
}

void UPartyWidget::OnPopupButtonClicked(EConfirmPopupFlag Flag)
{
	if (Flag == EConfirmPopupFlag::Yes)
	{
		bIsClosedPopup = true;
		GetLobbyHUD(this)->GotoBack();
	}
}

void UPartyWidget::OnJokerSetChanged(int32 JokerSetId)
{
	const auto& JokerMgr = GetHUDStore().GetJokerManager();
	const auto& JokerSet = JokerMgr.GetJokerSet(JokerSetId);
	const auto& SelectedId = JokerMgr.GetSelectedId();
	JokerUseButton->SetVisibility(JokerSetId == SelectedId ? ESlateVisibility::Collapsed : ESlateVisibility::Visible);
	JokerUsedBorder->SetVisibility(JokerSetId == SelectedId ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UPartyWidget::SetEventWattPoint(const FEventContentType InEventContentType, const int32 InWattConsume)
{
	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(InEventContentType);
	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FEventContentInfo* EventContentInfo = EventManager.GetEvent(InEventContentType);
	if (EventContentInfo)
	{
		CombatStartButton->SetEventWattType(EventContentRow.Category, EPointWidgetOption::LessEqual);
		CombatStartButton->SetPoint(InWattConsume, EventContentInfo->WattInfo.Watt);
	}
}

void UPartyWidget::OpenRegularRaidMatchTimerWidget()
{
	if (!RegularRaidMatchTimerWidget)
	{
		RegularRaidMatchTimerWidget = CreateWidget<URegularRaidMatchTimerWidget>(
			GetOwningPlayer(), RegularRaidMatchTimerWidgetClass.LoadSynchronous());
	}

	check(RegularRaidMatchTimerWidget);

	if (!RegularRaidMatchTimerWidget->IsInViewport())
	{
		RegularRaidMatchTimerWidget->AddToViewport(ZORDER_POPUP);
	}

	const FRegularRaidState& RegularRaidState = GetHUDStore().GetRaidManager().GetRegularRaidState();
	const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(
		RegularRaidState.ScheduleId);
	if (!ScheduleInfo)
	{
		Q6JsonLogGenie(Warning, "ScheduleInfo Does Not Exist.",
			Q6KV("EventScheduleId", RegularRaidState.ScheduleId));
		return;
	}

	FDateTime EndDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate2);
	const FTimespan& Timespan = EndDate - FDateTime::Now();

	RegularRaidMatchTimerWidget->SetRegularRaidMatchTimerInfo(
		static_cast<int32>(Timespan.GetTotalSeconds()));
}

void UPartyWidget::OpenRaidExpiredConfirmPopup()
{
	UConfirmPopupWidget* ConfirmPopup = GetCheckedLobbyHUD(this)->OpenConfirmPopup(
		Q6Util::GetLocalizedText("Popup", "NoticeTitle")
		, Q6Util::GetLocalizedText("Popup", "RaidExpiredDesc"));
	check(ConfirmPopup);

	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
	ConfirmPopup->OnPopupClosedDelegate.BindLambda([this]()
	{
		GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Raid);
	});
}

UPartyPageWidget::UPartyPageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPartyPageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PetSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("PetIconSwitcher"));
	PetImage = CastChecked<UImage>(GetWidgetFromName("IconPet"));

	UQ6Button* PetButton = CastChecked<UQ6Button>(GetWidgetFromName("Pet"));
	PetButton->OnClickedDelegate.BindUObject(this, &UPartyPageWidget::OnPetButtonClicked);

	static_assert(EJokerSlotTypeMax == MAX_JOKER_SLOT, "EJokerSlotTypeMax");
	static_assert(EJokerSlotTypeMax == MAX_PARTY_MEMBER, "EJokerSlotTypeMax");
	for (int32 n = 1; n <= EJokerSlotTypeMax; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Icon%d"), n);
		UPartyIconWidget* PartyIconWidget = CastChecked<UPartyIconWidget>(GetWidgetFromName(*WidgetName));
		PartyIconWidget->OnCharacterIconClickedDelegate.BindUObject(this, &UPartyPageWidget::OnPartyIconClicked, EPartyIconItemType::Character, (n - 1));
		PartyIconWidget->OnSculptureIconClickedDelegate.BindUObject(this, &UPartyPageWidget::OnPartyIconClicked, EPartyIconItemType::Sculpture, (n - 1));
		PartyIconWidget->OnRelicIconClickedDelegate.BindUObject(this, &UPartyPageWidget::OnPartyIconClicked, EPartyIconItemType::Relic, (n - 1));
		PartyIconWidgets.AddUnique(PartyIconWidget);
	}
}

void UPartyPageWidget::AddCharacterInfoAt(const FCharacterInfo& CharacterInfo, const FCharacterBond& CharacterBond, int32 SlotIdx)
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		PartyIconWidgets[SlotIdx]->SetCharacter(CharacterInfo, CharacterBond);
	}
}

void UPartyPageWidget::AddCharacterLockedSlotInfoAt(const int32 SlotIdx)
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		PartyIconWidgets[SlotIdx]->SetCharacterLockedSlotInfo(SlotIdx);
	}
}

void UPartyPageWidget::AddSculptureInfoAt(const FSculptureInfo& SculptureInfo, int32 SlotIdx)
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		PartyIconWidgets[SlotIdx]->SetSculpture(SculptureInfo);
	}
}

void UPartyPageWidget::AddRelicInfoAt(const FRelicInfo& RelicInfo, int32 SlotIdx)
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		PartyIconWidgets[SlotIdx]->SetRelic(RelicInfo);
	}
}

void UPartyPageWidget::AddFriendJokerSlotAt(const FFriendJokerSlot& JokerSlot, int32 SlotIdx)
{
	if (!JokerSlot.CharacterInfo.CharacterId.IsInvalid())
	{
		check(PartyIconWidgets.IsValidIndex(SlotIdx));
		UPartyIconWidget* PartyIconWidget = PartyIconWidgets[SlotIdx];

		PartyIconWidget->SetCharacter(JokerSlot.CharacterInfo, JokerSlot.CharacterBond);

		if (!JokerSlot.RelicInfo.RelicId.IsInvalid())
		{
			PartyIconWidget->SetRelic(JokerSlot.RelicInfo);
		}

		if (!JokerSlot.SculptureInfo.SculptureId.IsInvalid())
		{
			AddSculptureInfoAt(JokerSlot.SculptureInfo, SlotIdx);
			PartyIconWidget->SetSculpture(JokerSlot.SculptureInfo);
		}
	}
}

void UPartyPageWidget::AddOwnedJokerSlotAt(const FPartySlot& JokerSlot, int32 SlotIdx)
{
	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(JokerSlot.CharacterId);
	if (!Character)
	{
		return;
	}

	const FCharacterInfo& CharacterInfo = Character->GetInfo();
	FCharacterBond Bond = GetHUDStore().GetBondManager().GetCharacterBond(CharacterInfo.Type);
	check(PartyIconWidgets.IsValidIndex(SlotIdx));

	UPartyIconWidget* PartyIconWidget = PartyIconWidgets[SlotIdx];
	PartyIconWidget->SetCharacter(CharacterInfo, Bond);

	if (const FRelic* Relic = GetHUDStore().GetRelicManager().Find(JokerSlot.RelicId))
	{
		PartyIconWidget->SetRelic(Relic->GetInfo());
	}

	if (const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(JokerSlot.SculptureId))
	{
		PartyIconWidget->SetSculpture(Sculpture->GetInfo());
	}
}

void UPartyPageWidget::SetFriendJoker(const FFriendJokerSet& JokerSet)
{
	ResetPage(EPartyWidgetType::JokerSet, true, false);

	for (int32 SlotIdx = 0; SlotIdx < EJokerSlotTypeMax; ++SlotIdx)
	{
		AddFriendJokerSlotAt(JokerSet.Slots[SlotIdx], SlotIdx);
	}
}

void UPartyPageWidget::SetPet(const FPetId& InPetId)
{
	PetId = InPetId;

	if (PetId.IsInvalid())
	{
		PetSwitcher->SetActiveWidgetIndex(0);	// Show disabled image
	}
	else
	{
		PetSwitcher->SetActiveWidgetIndex(1);	// Show pet image

		if (const FPetInfo* PetInfo = GetHUDStore().GetPetManager().Find(PetId))
		{
			const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetInfo->Type);
			PetImage->SetBrushFromSoftTextureWhenLoadingFinished(PetAssetRow.IconTexture);
		}
	}
}

void UPartyPageWidget::RemoveCharacterAt(int32 SlotIdx)
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		PartyIconWidgets[SlotIdx]->SetCharacterEmpty();
	}
}

void UPartyPageWidget::RemoveSculptureAt(int32 SlotIdx)
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		PartyIconWidgets[SlotIdx]->SetSculptureEmpty();
	}
}

void UPartyPageWidget::RemoveRelicAt(int32 SlotIdx)
{
	if (PartyIconWidgets.IsValidIndex(SlotIdx))
	{
		PartyIconWidgets[SlotIdx]->SetRelicEmpty();
	}
}

void UPartyPageWidget::ResetPage(EPartyWidgetType InWidgetType, bool bInViewOnly, bool bInIsMultiside)
{
	bIsOpenedByMultiside = bInIsMultiside;
	SetMenuType(InWidgetType);

	for (int32 i = 0; i < PartyIconWidgets.Num(); ++i)
	{
		PartyIconWidgets[i]->ResetPartyIcon(InWidgetType, i, bInViewOnly, bInIsMultiside);
	}
}

bool UPartyPageWidget::ReturnToJokerSelectMenu(int32 SlotIndex)
{
	if (SlotIndex == PARTY_JOKER_SLOT_INDEX)
	{
		const FLobbyUIState* CurrentUIState = GetHUDStore().GetUIStateManager().GetUIState();
		check(CurrentUIState);

		const FPartyUIState* PartyUIState = CurrentUIState->CastToPartyUIState();
		if (PartyUIState && PartyUIState->WidgetType == EPartyWidgetType::CombatReady)
		{
			GetLobbyHUD(this)->GotoBack();
		}

		return true;
	}

	return false;
}

void UPartyPageWidget::OnPartyIconClicked(UPartyIconWidget* PartyIcon, EPartyIconItemType ItemType, int32 SlotIdx)
{
	FString TutorialStr = FString::Printf(TEXT("PartyPageIcon_%d_%s"), SlotIdx, *ENUM_TO_STRING(EPartyIconItemType, ItemType));
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialStr);
	if (PartyIcon->IsSystemJoker() && ReturnToJokerSelectMenu(SlotIdx))
	{
		return;
	}

	const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
	if (UIState.WidgetType == EPartyWidgetType::JokerSet)
	{
		ACTION_DISPATCH_JokerSetEdit(ItemType, SlotIdx);
	}
	else
	{
		ACTION_DISPATCH_PartyEdit(ItemType, SlotIdx);
	}
}

void UPartyPageWidget::OnPetButtonClicked()
{
	if (PetId.IsInvalid())
	{
		GetBaseHUD(this)->ShowNotOpenedYetNotification(EWonderCategory::PetPark);
		return;
	}

	UPartyPetSelectPopupWidget* PetSelectPopup = CastChecked<UPartyPetSelectPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(PetSelectPopupWidgetClass));
	PetSelectPopup->OnPopupClosedDelegate.BindUObject(this, &UPartyPageWidget::OnPetSelectPopupClosed);
	PetSelectPopup->SetPetList(PetId, bIsOpenedByMultiside);

	ACTION_DISPATCH_PartyPetEdit();
}

void UPartyPageWidget::OnPetSelectPopupClosed()
{
	ACTION_DISPATCH_MenuBack();
}

void UPartyPetDetailPageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UsedSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("SwitcherUsed"));
	UQ6Button* UseButton = CastChecked<UQ6Button>(GetWidgetFromName("Use"));
	UseButton->OnClicked.AddUniqueDynamic(this, &UPartyPetDetailPageWidget::OnUseButtonClicked);

	IconWidget = CastChecked<UPetIconWidget>(GetWidgetFromName("Icon"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));

	SkillDescWidgets.Reset();
	for (int32 n = 1; n <= CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Skill%d"), n);
		UTurnSkillDescWidget* SkillDescWidget = CastChecked<UTurnSkillDescWidget>(GetWidgetFromName(*WidgetName));
		SkillDescWidgets.Add(SkillDescWidget);
	}
}

void UPartyPetDetailPageWidget::SetPet(const FPetInfo& PetInfo, bool bUsed, bool bInIsMultiside)
{
	PetId = PetInfo.PetId;
	bIsOpendByMultiside = bInIsMultiside;

	UsedSwitcher->SetActiveWidgetIndex(bUsed ? 1 : 0);	// Convert bool to int (Not sure, true always 1)

	IconWidget->SetPet(PetInfo.Type);

	const FCMSPetRow& PetRow = GetCMS()->GetPetRowOrDummy(PetInfo.Type);
	check(PetRow.GetSkills().Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	NameText->SetText(PetRow.Name);

	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetInfo.Type);
	check(PetAssetRow.SkillIcons.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	TArray<int32> SkillLevels;
	SkillLevels.Add(PetInfo.Skill1Level);
	SkillLevels.Add(PetInfo.Skill2Level);
	SkillLevels.Add(PetInfo.Skill3Level);
	check(SkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		SkillDescWidgets[i]->SetSkillRow(PetAssetRow.SkillIcons[i], *PetRow.GetSkills()[i], SkillLevels[i]);
	}
}

void UPartyPetDetailPageWidget::OnUseButtonClicked()
{
	if (bIsOpendByMultiside)
	{
		UQ6SaveGame* SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
		SaveGame->SaveMultisidePartyPet(PetId);
		ACTION_DISPATCH_MultisidePetSave(PetId);
	}
	else
	{
		const FPartyUIState& UIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
		GetHUDStore().GetPartyManager().ReqPartyPetSave(UIState.PageNum, PetId);
	}
}

void UPartyPetSelectPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PetSwipeWidget = CastChecked<UPageSwipeWidget>(GetWidgetFromName("PetSwipe"));
	//PetSwipeWidget->OnSetPageDelegate.BindUObject(this, &UPartyPetSelectPopupWidget::OnPetDetailPageSet);
	PetSwipeWidget->OnFocusedPageDelegate.BindUObject(this, &UPartyPetSelectPopupWidget::OnPetDetailPageFocused);
	SubscribeToStore(EHSType::Party);
	SubscribeToStore(EHSType::Ui);

	ULevelUtil::SetCurrentCaptureActor(GetWorld(), true, "Capture.Pet");
}

void UPartyPetSelectPopupWidget::NativeDestruct()
{
	ULevelUtil::SetCurrentCaptureActor(GetWorld(), false, "Capture.Pet");

	Super::NativeDestruct();
}

void UPartyPetSelectPopupWidget::SetPetList(FPetId InSelectedPetId, bool bInIsMultiside)
{
	bIsOpendByMultiside = bInIsMultiside;
	SelectedPetId = InSelectedPetId;

	const UPetManager& PetMgr = GetHUDStore().GetPetManager();
	int32 PetIndex = PetMgr.GetIndexByPetId(SelectedPetId);
	int32 PetNum = PetMgr.GetPetNum();
	PetSwipeWidget->SetPageCount(PetNum, PetIndex + 1);
}

void UPartyPetSelectPopupWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByPartyPetSelectPopup);

	if (InAction->GetActionType() == EHSActionType::PartySaveResp)
	{
		auto Action = ACTION_PARSE_PartySaveResp(InAction);
		const FPartyInfo& Party = Action->GetVal().PartyInfo;
		SetPetList(Party.PetId, bIsOpendByMultiside);
		return;
	}
	else if (InAction->GetActionType() == EHSActionType::MultisidePetSave)
	{
		auto Action = ACTION_PARSE_MultisidePetSave(InAction);
		SetPetList(Action->GetVal(), true);
		return;
	}
}

void UPartyPetSelectPopupWidget::OnPetDetailPageSet(UWidget* ViewWidget, int32 PageNum)
{
	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().GetPetInfoByIndex(PageNum - 1);
	if (!PetInfo)
	{
		Q6JsonLogRoze(Error, "UPartyPetSelectPopupWidget::OnPetDetailPageSet - Not found pet", Q6KV("Index", PageNum - 1));
		return;
	}

	UPartyPetDetailPageWidget* PageWidget = CastChecked<UPartyPetDetailPageWidget>(ViewWidget);
	PageWidget->SetPet(*PetInfo, (SelectedPetId == PetInfo->PetId), bIsOpendByMultiside);
}

void UPartyPetSelectPopupWidget::OnPetDetailPageFocused(int32 PageNum)
{
	OnPetDetailPageSet(PetSwipeWidget->GetFocusedWidget(), PageNum);
}
