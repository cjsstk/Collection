// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "LobbyHUDWidget.h"
#include "LobbyHUD.h"
#include "Q6.h"

ULobbyHUDWidget::ULobbyHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void ULobbyHUDWidget::OnLeaveMenu()
{
	UnsubscribeToStore();
}

void ULobbyHUDWidget::RefreshMenu()
{
	GetLobbyHUD(this)->RefreshNaviBar();
}
