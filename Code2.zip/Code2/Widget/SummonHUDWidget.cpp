// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "SummonHUDWidget.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "ItemWidgets.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6Util.h"
#include "WidgetUtil.h"

USummonHUDWidget::USummonHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SummonInfoWidget = CastChecked<USummonInfoWidget>(GetWidgetFromName("SummonInfo"));

	NextButton = CastChecked<UButton>(GetWidgetFromName("ButtonNext"));
	SkipButton = CastChecked<UButton>(GetWidgetFromName("ButtonSkip"));
	HUDButton = CastChecked<USummonHUDButton>(GetWidgetFromName("SummonHUDBtn"));
	NoticeText = CastChecked<UTextBlock>(GetWidgetFromName("TextFakeNotice01"));

	HUDButtonPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("HUDBtnPanel"));

	NextButton->OnClicked.AddUniqueDynamic(this, &USummonHUDWidget::OnNextClicked);
	SkipButton->OnClicked.AddUniqueDynamic(this, &USummonHUDWidget::OnSkipClicked);
	HUDButton->SwipeDelegate.BindUObject(this, &USummonHUDWidget::OnInteractionFired);

	InteractionStartAnim = GetWidgetAnimationFromName(this, "AnimInteractionStart");
	InteractionLoopAnim = GetWidgetAnimationFromName(this, "AnimInteractionLoop");
	InteractionEndAnim = GetWidgetAnimationFromName(this, "AnimInteractionEnd");
}

void USummonHUDWidget::InterationReady()
{
	PlayAnimation(InteractionStartAnim);

	NoticeText->SetText(Q6Util::GetLocalizedText("Lobby", "PleaseSendAuthorization"));
	HUDButton->InteractionReady();
}

void USummonHUDWidget::SetSummonInfo(const FSummonInfo& Info, const FSimpleDelegate& EndDelegate)
{
	if (!SummonInfoWidget->IsVisible())
	{
		SummonInfoWidget->SetVisibility(ESlateVisibility::Visible);
		SummonInfoWidget->SetSummonInfo(Info, EndDelegate);
	}
}

void USummonHUDWidget::MoveToNextSummonInfo()
{
	if (SummonInfoWidget->IsVisible())
	{
		SummonInfoWidget->MoveToNext();
	}
}

void USummonHUDWidget::HideSummonInfo()
{
	if (SummonInfoWidget->IsVisible())
	{
		SummonInfoWidget->HideSummonInfo();
	}
}

void USummonHUDWidget::ShowSkipButton(bool bShow)
{
	if (bShow)
	{
		SkipButton->SetVisibility(ESlateVisibility::Visible);
	}
	else
	{
		SkipButton->SetVisibility(ESlateVisibility::Hidden);
	}
}

void USummonHUDWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == InteractionStartAnim)
	{
		if (!bStoppingAllAnimations)
		{
			PlayAnimation(InteractionLoopAnim, 0.0f, 0);
		}

		HUDButton->EnableSwipe(true);
	}
}

void USummonHUDWidget::OnNextClicked()
{
	MoveToNextDelegate.ExecuteIfBound();
}

void USummonHUDWidget::OnSkipClicked()
{
	StopAllAnimations();
	ShowSkipButton(false);

	HUDButtonPanel->SetVisibility(ESlateVisibility::Collapsed);
	NextButton->SetVisibility(ESlateVisibility::Visible);

	SkipDelegate.ExecuteIfBound();
}

void USummonHUDWidget::OnInteractionFired()
{
	StopAllAnimations();
	PlayAnimation(InteractionEndAnim);

	NoticeText->SetText(Q6Util::GetLocalizedText("Lobby", "SendingConfirmedAuthorization"));
	HUDButton->InteractionStart();

	InteractionDelegate.ExecuteIfBound();
}

UFirstSummonWidget::UFirstSummonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UFirstSummonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FirstTitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextFirstTitle"));

	FirstItemStartAnim = GetWidgetAnimationFromName(this, "AnimFirstItemStart");
	FirstMasterPieceAnim = GetWidgetAnimationFromName(this, "AnimFirstMasterpiece");
	FirstRelicAnim = GetWidgetAnimationFromName(this, "AnimFirstRelic");
	FirstCharacterAnim = GetWidgetAnimationFromName(this, "AnimFirstCharacter");
}

void UFirstSummonWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (bStoppingAllAnimations)
	{
		return;
	}

	if (Animation == FirstItemStartAnim)
	{
		OnFirstSummonEndDelegate.ExecuteIfBound();
	}
}

void UFirstSummonWidget::StartAnimation(ELootCategory Category)
{
	StopAllAnimations();

	switch (Category)
	{
		case ELootCategory::CharacterCard:
			FirstTitleText->SetText(Q6Util::GetLocalizedText("Lobby", "FirstCharacter"));
			PlayAnimation(FirstItemStartAnim);
			PlayAnimation(FirstCharacterAnim);
			break;
		case ELootCategory::SculptureCard:
			FirstTitleText->SetText(Q6Util::GetLocalizedText("Lobby", "FirstMasterpiece"));
			PlayAnimation(FirstItemStartAnim);
			PlayAnimation(FirstMasterPieceAnim);
			break;
		case ELootCategory::RelicCard:
			FirstTitleText->SetText(Q6Util::GetLocalizedText("Lobby", "FirstRelic"));
			PlayAnimation(FirstItemStartAnim);
			PlayAnimation(FirstRelicAnim);
			break;
		default:
			Q6JsonLogZagal(Warning, "Wrong Summon Item Category", Q6KV("Category", ENUM_TO_STRING(ELootCategory, Category)));
			OnFirstSummonEndDelegate.ExecuteIfBound();
			break;
	}
}

bool UFirstSummonWidget::IsFirstShowOver() const
{
	return (!IsVisible() || !IsPlayingAnimation());
}

USummonInfoWidget::USummonInfoWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, UIState(EUIState::None)
{
}

void USummonInfoWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FirstSummonWidget = CastChecked<UFirstSummonWidget>(GetWidgetFromName("FirstSummon"));
	FirstSummonWidget->OnFirstSummonEndDelegate.BindUObject(this, &USummonInfoWidget::OnFirstSummonEnd);

	ItemBigCardWidget = CastChecked<UItemBigCardWidget>(GetWidgetFromName("ItemBigCard"));

	TypeNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TypeName"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("TextLevel"));
	StarBarWidget = CastChecked<UStarBarWidget>(GetWidgetFromName("ShearedStar"));

	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	GradeBgImage = CastChecked<UImage>(GetWidgetFromName("GradeBg"));
	NatureTypeImage = CastChecked<UImage>(GetWidgetFromName("NatureType"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("TextName"));
	NickNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextNickName"));

	InfoStartAnim = GetWidgetAnimationFromName(this, "AnimInfoStart");
	InfoEndAnim = GetWidgetAnimationFromName(this, "AnimInfoEnd");
	ItemShowAnim = GetWidgetAnimationFromName(this, "AnimItemShow");
	ItemShowNAnim = GetWidgetAnimationFromName(this, "AnimItemShowN");
	ItemShowRAnim = GetWidgetAnimationFromName(this, "AnimItemShowR");
	ItemShowSRAnim = GetWidgetAnimationFromName(this, "AnimItemShowSR");
	ItemShowSSRAnim = GetWidgetAnimationFromName(this, "AnimItemShowSSR");
	StateItemAnim = GetWidgetAnimationFromName(this, "AnimStateItem");
	StateCharacterAnim = GetWidgetAnimationFromName(this, "AnimStateCharacter");
}

void USummonInfoWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (bStoppingAllAnimations)
	{
		return;
	}

	if (Animation == ItemShowAnim)
	{
		SetUIState(EUIState::InfoStart);
	}
	else if (Animation == InfoStartAnim)
	{
		if (SummonInfo.bFirst)
		{
			SetUIState(EUIState::FirstShow);
		}
		else
		{
			SetUIState(EUIState::CanBeEnd);
		}
	}
	else if (Animation == InfoEndAnim)
	{
		InfoEndDelegate.ExecuteIfBound();
	}
}

void USummonInfoWidget::OnFirstSummonEnd()
{
	SetUIState(EUIState::CanBeEnd);
}

void USummonInfoWidget::SetSummonInfo(const FSummonInfo& Info, const FSimpleDelegate& EndDelegate)
{
	SummonInfo = Info;
	InfoEndDelegate = EndDelegate;
	UIState = EUIState::None;

	if (SummonInfo.IsCharacter())
	{
		SetUIState(EUIState::InfoStart);
		PlayAnimation(StateCharacterAnim);

		TypeNameText->SetText(Q6Util::GetLocalizedText("Lobby", "Character"));
	}
	else
	{
		SetUIState(EUIState::ItemShow);
		PlayAnimation(StateItemAnim);

		switch (SummonInfo.ItemGrade)
		{
			case EItemGrade::N:
				PlayAnimation(ItemShowNAnim);
				break;
			case EItemGrade::R:
				PlayAnimation(ItemShowRAnim);
				break;
			case EItemGrade::SR:
				PlayAnimation(ItemShowSRAnim);
				break;
			case EItemGrade::SSR:
				PlayAnimation(ItemShowSSRAnim);
				break;
		}

		if (SummonInfo.Category == ELootCategory::SculptureCard)
		{
			TypeNameText->SetText(Q6Util::GetLocalizedText("Lobby", "Masterpiece"));
		}
		else
		{
			TypeNameText->SetText(Q6Util::GetLocalizedText("Lobby", "Relic"));
		}
	}

	ItemBigCardWidget->SetSummonResult(SummonInfo);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(SummonInfo.Level)));
	StarBarWidget->SetMoonStars(SummonInfo.Moon, SummonInfo.Star);

	const FSlateBrush& GradeBrush = GetUIResource().GetSummonInfoGrade(SummonInfo.ItemGrade);
	GradeImage->SetBrush(GradeBrush);

	const FSlateBrush& GradeBgBrush = GetUIResource().GetSummonInfoGradeBg(SummonInfo.ItemGrade);
	GradeBgImage->SetBrush(GradeBgBrush);

	if (SummonInfo.IsCharacter())
	{
		const FSlateBrush& NatureBrush = GetUIResource().GetNatureTypeIcon(SummonInfo.NatureType);
		NatureTypeImage->SetBrush(NatureBrush);
	}
	else
	{
		const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(SummonInfo.Tier);
		NatureTypeImage->SetBrush(TierBrush);
	}

	NameText->SetText(SummonInfo.Name);
	if (SummonInfo.NickName.IsEmptyOrWhitespace())
	{
		NickNameText->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		NickNameText->SetText(SummonInfo.NickName);
		NickNameText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void USummonInfoWidget::HideSummonInfo()
{
	FirstSummonWidget->StopAllAnimations();

	StopAllAnimations();
	SetVisibility(ESlateVisibility::Collapsed);

	UIState = EUIState::None;
}

void USummonInfoWidget::MoveToNext()
{
	Q6JsonLogZagal(Warning, "MoveToNext", Q6KV("From", (int32)UIState));

	switch (UIState)
	{
		case EUIState::ItemShow:
			if (!SummonInfo.bFirst)
			{
				SetUIState(EUIState::InfoStart);
			}
			break;
		case EUIState::FirstShow:
			if (FirstSummonWidget->IsFirstShowOver())
			{
				SetUIState(EUIState::CanBeEnd);
			}
			break;
		case EUIState::CanBeEnd:
			SetUIState(EUIState::InfoEnd);
			break;
	}

	Q6JsonLogZagal(Warning, "MoveToNext", Q6KV("To", (int32)UIState));
}

void USummonInfoWidget::SetUIState(EUIState State)
{
	if ((uint8)UIState >= (uint8)State)
	{
		Q6JsonLogZagal(Warning, "Invalid State",
			Q6KV("From", (int32)UIState),
			Q6KV("To", (int32)State));
		return;
	}

	StopAllAnimations();

	UIState = State;

	switch (UIState)
	{
		case EUIState::ItemShow:
			PlayAnimation(ItemShowAnim);
			break;
		case EUIState::InfoStart:
			PlayAnimation(InfoStartAnim);
			break;
		case EUIState::FirstShow:
			FirstSummonWidget->StartAnimation(SummonInfo.Category);
			break;
		case EUIState::InfoEnd:
			PlayAnimation(InfoEndAnim);
			break;
	}
}

USummonHUDButton::USummonHUDButton(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	SwipeLength = 100.0f;
}

void USummonHUDButton::NativeConstruct()
{
	Super::NativeConstruct();

	InteractionStartAnim = GetWidgetAnimationFromName(this, "AnimInteractionBtnStart");
	InteractionResetAnim = GetWidgetAnimationFromName(this, "AnimInteractionBtnReset");

	SetColorBlueAnim = GetWidgetAnimationFromName(this, "AnimSetColorBlue");
	SetColorGreenAnim = GetWidgetAnimationFromName(this, "AnimSetColorGreen");
	SetColorOrangeAnim = GetWidgetAnimationFromName(this, "AnimSetColorOrange");

	bTouched = false;
	bSwpieEnabled = false;
}

FReply USummonHUDButton::NativeOnTouchStarted(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	if (!bTouched)
	{
		TouchBeginPos = InGestureEvent.GetScreenSpacePosition();
		bTouched = true;

		return FReply::Handled().CaptureMouse(GetCachedWidget()->AsShared());
	}

	return FReply::Unhandled();
}

FReply USummonHUDButton::NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	if (bTouched)
	{
		return FReply::Handled();
	}

	return FReply::Unhandled();
}

FReply USummonHUDButton::NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	if (bTouched)
	{
		if (bSwpieEnabled)
		{
			float OffsetY = (InGestureEvent.GetScreenSpacePosition() - TouchBeginPos).Y;
			if (FMath::Abs(OffsetY) > SwipeLength)
			{
				if (OffsetY < 0.0f)	// from bottom to top
				{
					SwipeDelegate.ExecuteIfBound();
				}
			}
		}

		bTouched = false;

		return FReply::Handled().ReleaseMouseCapture();
	}

	return FReply::Unhandled();
}

void USummonHUDButton::EnableSwipe(bool bEnable)
{
	bSwpieEnabled = bEnable;
}

void USummonHUDButton::InteractionReady()
{
	PlayAnimation(InteractionResetAnim);
	EnableSwipe(false);
}

void USummonHUDButton::InteractionStart()
{
	StopAllAnimations();

	PlayAnimation(InteractionStartAnim);
	EnableSwipe(false);

	int32 Index = FMath::RandHelper(3);

	switch (Index)
	{
		case 0:
			PlayAnimation(SetColorBlueAnim);
			break;
		case 1:
			PlayAnimation(SetColorGreenAnim);
			break;
		case 2:
			PlayAnimation(SetColorOrangeAnim);
			break;
	}
}
