// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "WonderWidgets.h"

#include "TempleWidgets.generated.h"

class UMaterialBoxWidget;
class UPointWidget;
class UQ6RichTextBlock;
class UQ6TextBlock;
class USkillUpInfoWidget;

UCLASS()
class Q6_API UArtifactIconWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetArtifact(const FArtifact& Artifact, int32 ArtifactIndex);
	void SetSelected(bool bInSelected);

	void PlayBoostUsedAnim() { PlayAnimation(BoostUsedAnim); }

	FSimpleDelegate OnArtifactSelectedDelegate;

private:
	UFUNCTION()
	void OnArtifactSelected();

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UQ6TextBlock* RemainDaysText;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* LevelText;

	UPROPERTY()
	UImage* NewMarkImage;

	UPROPERTY(Transient)
	UWidgetAnimation* SelectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DeselectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NotUsedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CooldownAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BoostUsedAnim;
};


UCLASS()
class Q6_API UArtifactUpgradeResultPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetArtifact(int32 ArtifactIndex);

private:
	// Widgets

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	USkillUpInfoWidget* CurrentSkillWidget;

	UPROPERTY()
	USkillUpInfoWidget* ResultSkillWidget;
};


UCLASS()
class Q6_API UTempleWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) override;

	virtual void SetWonder() override;
	virtual void RefreshUI() override;

private:
	void PlayBoostAnimation();

	void SelectArtifact(int32 NewSelectedIdx);
	void SetArtifactDetail();

	void SetSkillInfo(int32 CurrentLevel, bool bShowUpgrade);
	void SetArtifactCost(int32 ArtifactLevel);
	void SetArtifactCooldown(const FArtifact& Artifact);
	void SetArtifactUpgrade(const FArtifact& Artifact, int32 TempleLevel);

	UFUNCTION()
	void OnActionButtonClicked();

	void OnArtifactUpgrade(EConfirmPopupFlag Option);

	// Widgets

	UPROPERTY()
	TArray<UArtifactIconWidget*> ArtifactIcons;

	UPROPERTY()
	UQ6TextBlock* SkillNameText;

	UPROPERTY()
	USkillUpInfoWidget* CurrentSkillWidget;

	UPROPERTY()
	USkillUpInfoWidget* ResultSkillWidget;

	UPROPERTY()
	UQ6RichTextBlock* LevelInfoText;

	UPROPERTY()
	UQ6TextBlock* SkillInfoText;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UPointWidget* RequireGoldWidget;

	UPROPERTY()
	UPointWidget* OwnedGoldWidget;

	UPROPERTY()
	UButton* ActionButton;

	UPROPERTY()
	UQ6TextBlock* ActionText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* IntroAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ArtifactUpgradeAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LowLevelAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillNotUsedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillBoostAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillCooldownAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NotAcquireAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UBoostConfirmPopupWidget> BoostConfirmPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UArtifactUpgradeResultPopupWidget> ResultPopupWidgetClass;

	int32 SelectedIndex;
};
