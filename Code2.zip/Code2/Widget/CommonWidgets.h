// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Framework/Styling/ButtonWidgetStyle.h"
#include "Components/TextBlock.h"
#include "Components/RichTextBlock.h"
#include "Components/DynamicEntryBox.h"
#include "Components/RichTextBlockImageDecorator.h"
#include "UMG.h"
#include "BaseWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "CommonWidgets.generated.h"

///////////////////////////////////////////////////////////////////////////////////////////
// Enums
enum class EHUDWidgetType : uint8;
enum class ETopBarType : uint8;

UENUM()
enum class EScrollOrientation : uint8
{
	Horizontal,
	Vertical
};

/**
 * Please use only AddDynamic() function, when bind to OnClicked.
 * Do not use AddUniqueDynamic() function.
 */
UCLASS()
class Q6_API UQ6Button : public UButton
{
	GENERATED_BODY()

public:
	UQ6Button(const FObjectInitializer& ObjectInitializer);

	virtual void OnWidgetRebuilt() override;
	virtual void SetIsEnabled(bool bInIsEnabled) override;

	FSimpleDelegate OnClickedDelegate;	// Use for delegate param
	FSimpleDelegate OnLongClickedDelegate;

private:
	UFUNCTION()
	void OnButtonClicked();

	UFUNCTION()
	void OnButtonPressed();

	UFUNCTION()
	void OnButtonReleased();

	void OnButtonEnableTime();

	UPROPERTY(EditDefaultsOnly)
	float LongClickTimeSec;

	/** Sets the enabled, when clicked after a few seconds
	 *
	 * 0 is not disable on clicked.
	 * Negative number(-1) is waiting only delegate event.
	 */
	UPROPERTY(EditAnywhere, Category = "Button")
	float EnabledTime;

	FTimerHandle ButtonEnableTimerHandle;
	double PressedTimeSec;
};


UCLASS()
class Q6_API UQ6TextBlock : public UTextBlock
{
	GENERATED_BODY()

public:

	UQ6TextBlock();

#if WITH_EDITOR
	virtual void OnCreationFromPalette() override;
#endif
};


UCLASS()
class Q6_API UQ6RichTextBlock : public URichTextBlock
{
	GENERATED_BODY()

public:
	UQ6RichTextBlock(const FObjectInitializer& ObjectInitializer);

#if WITH_EDITOR
	virtual void OnCreationFromPalette() override;
#endif
};

UCLASS(Blueprintable, BlueprintType)
class Q6_API UQ6RichTextBlockImageDecorator : public URichTextBlockImageDecorator
{
	GENERATED_BODY()
};


UCLASS()
class Q6_API UBlackoutWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UBlackoutWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void ShowBlackout(EBlackoutType InBlackoutType);
	void HideBlackout();
	void StopBlackout();

	bool IsShowing() const { return bShowing; }
	bool IsWorking() const { return bWorking; }

	FBoolParamDelegate OnBlackoutShowingDelegate;
	FBoolParamDelegate OnBlackoutFinishedDelegate;

private:
	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> ShowAnims;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> HideAnims;

	EBlackoutType BlackoutType;
	bool bShowing;
	bool bWorking;
};

UCLASS()
class Q6_API UNotificationWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UNotificationWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void ShowNotification(ENotificationType InNotiType, const FText& Text);
	void ShowNotifications(ENotificationType InNotiType, const TArray<FText>& Texts);
	void HideNotification();

private:
	void ClearNotifications();

	void ShowNotificationInternal();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> ShowAnims;

	UPROPERTY()
	URichTextBlock* NotifyText;

	// Fields

	ENotificationType NotiType;
	TArray<FText> NotifyTexts;
	int32 NotiIndex;
};

UCLASS()
class Q6_API UMissionGaugeWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UMissionGaugeWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetInfo(const FText& Detail, const int32 Past
		, const int32 Curr, const int32 Max, const bool bPage);

private:
	void SetMissionDetailText(const FText& Detail);
	void SetMissionCount(const int32 Curr, const int32 Max);
	void SetProgress(const int32 Past, const int32 Curr, const int32 Max);
	void PlayMissionGaugeAnim(EMissionGaugeType Type);

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> MissionGaugeAnims;

	UPROPERTY()
	UTextBlock* MissionDetailText;

	UPROPERTY()
	UTextBlock* MissionCountText;

	UPROPERTY()
	UProgressBar* CurrentProgressBar;

	UPROPERTY()
	UProgressBar* PastProgressBar;
};

UCLASS()
class Q6_API UMissionToastWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UMissionToastWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void ShowMissionToast(const FWeeklyMissionToastInfo& InWeeklyMission);

private:
	void PlayMissionToast(const FWeeklyMissionToastInfo& InWeeklyMission);

	void PlayMissionToastAnim(EMissionToastType Type);

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> MissionToastAnims;

	UPROPERTY()
	UMissionGaugeWidget* MissionGaugeWidget;

	UPROPERTY()
	UImage* IconImage;
};

UCLASS()
class Q6_API UDynamicListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UDynamicListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	UWidget* FindOrAddChild(int32 Index);
	UWidget* FindChildAt(int32 Index);
	UWidget* AddChildAtLastIndex();

	bool RemoveChildAt(int32 Index);

	int32 GetChildrenCount() { return ElementsPanel->GetChildrenCount(); }

	void ScrollToStart();
	void ScrollToEnd();
	void FocusAtIndex(int32 Index);

	void ClearList();	// Keep child. Just hide in list (Not re-create)

	FSimpleDelegate OnScrolledAtStart;
	FSimpleDelegate OnScrolledAtEnd;

protected:
	UPROPERTY(EditInstanceOnly)
	TAssetSubclassOf<UWidget> ElementWidgetClass;

	UPROPERTY(EditInstanceOnly)
	EScrollOrientation ScrollOrientation;

	UPROPERTY(EditInstanceOnly, meta = (UIMin = "1"))
	uint8 ElementsPerLine;

	UPROPERTY(EditInstanceOnly)
	FMargin PanelPadding;

	UPROPERTY(EditInstanceOnly)
	FMargin ChildSlotPadding;

	UPROPERTY(EditInstanceOnly)
	TEnumAsByte<EHorizontalAlignment> PanelHorizontalAlignment;

private:
	void SetElementSlot(UWidget* ElementWidget, int32 Index);

	UFUNCTION()
	void OnUserScrolled(float InCurrentOffset);

	UPROPERTY()
	UUniformGridPanel* ElementsPanel;

	UPROPERTY()
	TArray<UWidget*> ElementWidgets;

	UPROPERTY()
	UScrollBox* ScrollBox;

	int32 LastIndex;

	UPROPERTY()
	int32 StandStillScrollCount;

	UPROPERTY()
	float OldScrollOffset;

	UPROPERTY()
	bool bBlockScrollEvent;
};

UCLASS()
class Q6_API UItemDropListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemDropListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetItemDropInfo();

private:
	UPROPERTY()
	UDynamicListWidget* ItemListWidget;
};

UCLASS()
class Q6_API UToggleButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UToggleButtonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetButtonName(const FText& InButtonName);
	void SetChecked(bool bInChecked);
	void SetNewMarkVisibility(ESlateVisibility InVisibility);

	bool GetChecked() const;
	FText GetButtonName() const { return NameText->GetText(); }

	FSimpleDelegate OnToggleButtonClickedDelegate;

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable)
	void SetCheckedBP(bool bInIsChecked);

protected:
	UFUNCTION(BlueprintCallable)
	void OnToggleButtonClicked(bool bInChecked);

private:
	UPROPERTY()
	UCheckBox* ToggleButton;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UImage* NewMarkImage;	// Nullable
};

UCLASS()
class Q6_API UIconToggleButtonWidget : public UToggleButtonWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetIcon(const FSlateBrush& IconBrush);
	void SetIcon(const TSoftObjectPtr<UTexture2D>& IconTexture);

private:
	UPROPERTY()
	UImage* IconImage;
};

/**
 * UToggleButtonBoxWidget use likes radio button group
 */
UCLASS()
class Q6_API UToggleButtonBoxWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UToggleButtonBoxWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;

	void InitToggleButtons();

	void InitSelectedIndex(int32 ButtonIndex);

	// bDelegateToggle execute OnToggleButtonClickedDelegate
	void SetSelectedIndex(int32 ButtonIndex);
	void SetSelectedIndexNoDelegate(int32 ButtonIndex);

	int32 GetSelectedIndex() { return SelectedIndex; }
	const TArray<UUserWidget*>& GetToggleButtons() const;

	void SetToggleButtonBoxInternal(const TArray<FText>& InButtonNames);
	void SetToggleButtonBox(const TArray<FText>& InButtonNames, const TArray<ESlateVisibility>& InNewMarkVisibilities);
	void SetToggleButtonBox(const TArray<FText>& InButtonNames, const TArray<TSoftObjectPtr<UTexture2D>>& InIconTextures);
	void SetButtonEnabled(int32 ButtonIndex, bool bInEnabled);
	void SetToggleButtonNewMark(int32 ButtonIndex, bool bNewly);
	void SetToggleButtonNewMark(int32 ButtonIndex, ESlateVisibility InVisibility);

	FIntParamDelegate OnToggleButtonClickedDelegate;	// Execute when clicked toggle button. SelectedIndex changed or not.
	FIntParamDelegate OnToggleButtonChangedDelegate;	// Execute when SelectedIndex changed only. by SetSelectedIndex()

private:

	void SetSelectedIndexInternal(int32 ButtonIndex);

protected:
	UFUNCTION(BlueprintImplementableEvent)
	UUserWidget* CreateButtonWidget(TSubclassOf<UToggleButtonWidget> InToggleButtonWidgetClass);

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Toggle Button Widget")
	TSubclassOf<UToggleButtonWidget> ToggleButtonWidgetClass;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Toggle Button Widget")
	TEnumAsByte<EHorizontalAlignment> ButtonHorizontalAlignment;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Toggle Button Widget")
	TEnumAsByte<EVerticalAlignment> ButtonVerticalAlignment;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Toggle Button Widget")
	FVector2D ButtonSpacing;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Toggle Button Widget")
	FSlateChildSize ButtonSizeRule;

private:
	UPROPERTY(EditInstanceOnly)
	TArray<FText> ButtonNames;

	UPROPERTY(EditInstanceOnly)
	TArray<FSlateBrush> ButtonIconBrushes;

	UPROPERTY()
	UQ6DynamicEntryBox* ToggleButtonBox;

	int32 SelectedIndex;
};

/**
* UNetworkProgressWidget
*/
UCLASS()
class Q6_API UNetworkProgressWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UNetworkProgressWidget(const FObjectInitializer& ObjectInitializer);
	void NativeConstruct() override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = Q6)
	UTextBlock* StatusText;

	void Show(FText Message);
	void Hide();
};

UCLASS()
class Q6_API UNatureButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UNatureButtonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void SetStyle(const FCheckBoxStyle& InStyle);
	void SetChecked(bool bInChecked);

	FSimpleDelegate OnToggleButtonClickedDelegate;

private:
	UFUNCTION()
	void OnToggleButtonClicked(bool bInChecked);

	UPROPERTY(Transient)
	UWidgetAnimation* CheckedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UncheckedAnim;

	UPROPERTY(EditInstanceOnly)
	FCheckBoxStyle ButtonStyle;

	UPROPERTY()
	UCheckBox* ToggleCheckBox;
};

UCLASS()
class Q6_API UNatureTabWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UNatureTabWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	FIntParamDelegate OnToggleButtonClickedDelegate;

	void SetSelectedIndex(int32 NewIndex);
	int32 GetSelectedIndex() { return SelectedIndex; }

private:
	static const char* GetWidgetNameFromIdx(int32 Idx);

	UPROPERTY()
	TArray<UNatureButtonWidget*> NatureButtonWidgets;

	int32 SelectedIndex;
};

UCLASS()
class Q6_API UQ6DynamicEntryBox : public UDynamicEntryBox
{
	GENERATED_BODY()

public:
	UQ6DynamicEntryBox(const FObjectInitializer& ObjectInitializer);

	UFUNCTION(BlueprintCallable, Category = DynamicEntryBox)
	void SetEntryHorizontalAlignment(EHorizontalAlignment InEntryHorizontalAlignment);

	UFUNCTION(BlueprintCallable, Category = DynamicEntryBox)
	void SetEntryValticalAlignment(EVerticalAlignment InEntryVerticalAlignment);

	UFUNCTION(BlueprintCallable, Category = DynamicEntryBox)
	void SetEntrySizeRule(FSlateChildSize InEntrySizeRule);
};

/**
* ProgressBarControlWidget
*/
UCLASS()
class Q6_API UProgressBarControlWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UProgressBarControlWidget(const FObjectInitializer& ObjectInitializer);
	void NativeConstruct() override;

	UFUNCTION(BlueprintImplementableEvent)
	void OnValueChangedBP(float Value);

	UFUNCTION(BlueprintCallable)
	void OnProgressBarChangedBP(float Value);

	FFloatParamDelegate OnProgressBarDelegate;
};

/**
 * ClearUIWidget
 */
UCLASS()
class Q6_API UClearUIWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UClearUIWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void ShowClearUIWidget(bool bDimmed);
	void ToggleBackButtonVisibility();

private:
	UFUNCTION()
	void OnBackButtonClicked();

	UPROPERTY()
	UImage* DimmedImage;
	
	UPROPERTY()
	UButton* BackButton;
};

UCLASS()
class Q6_API UVerticalList : public UUserWidget
{
	GENERATED_BODY()

public:
	UVerticalList(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void ScrollToStart();
	void ScrollToEnd();
	void ClearAll();

	UWidget* AddNewChild();
	UWidget* AddNewChild(const FMargin& InPadding);

	bool RemoveChildAt(int32 Index);
	bool RemoveLast();

	int32 GetChildrenCount() const;
	UWidget* GetChildAt(int32 Index) const;
	UWidget* GetLastChild() const;

	FSimpleDelegate TouchButtonDelegate;

protected:
	UPROPERTY(EditInstanceOnly)
	TAssetSubclassOf<UWidget> ItemWidgetClass;

	UPROPERTY(EditInstanceOnly)
	FMargin ItemPadding;

private:
	UFUNCTION()
	void OnTouchButtonClicked();

	UPROPERTY()
	UVerticalBox* VerticalBox;

	UPROPERTY()
	UScrollBox* ScrollBox;
};
