// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CheckInWidgets.h"

#include "CMSTable.h"
#include "CheckInManager.h"
#include "GameResource.h"
#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "HUDStore/EventManager.h"
#include "SystemConst_gen.h"

//////////////////////////////////////////////////////////////////////////
// Check In Today Widget
//////////////////////////////////////////////////////////////////////////
void UCheckInTodayWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RotationItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("RotationItem"));
	AnniversaryItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("AnniversaryItem"));

	OnlyRotationRewardAnim = GetWidgetAnimationFromName(this, "AnimOnlyRotationReward");
	OnlyAnniversaryRewardAnim = GetWidgetAnimationFromName(this, "AnimOnlyAnniversaryReward");
	AllRewardAnim = GetWidgetAnimationFromName(this, "AnimAllReward");
	ReceiveRewardAnim = GetWidgetAnimationFromName(this, "AnimReceiveReward");
}

void UCheckInTodayWidget::SetReward(ECheckInType CheckInType, const FCMSLootDataRow& LootRow)
{
	UItemWidget* ItemWidget = (CheckInType == ECheckInType::Rotation) ? RotationItemWidget : AnniversaryItemWidget;
	ItemWidget->SetLoot(LootRow.LootId, LootRow.Count);
}

void UCheckInTodayWidget::PlayRewardAnimation(bool bRotationReward, bool bAnniversaryReward)
{
	PlayAnimation(ReceiveRewardAnim);

	if (bRotationReward && bAnniversaryReward)
	{
		PlayAnimation(AllRewardAnim);
		return;
	}

	PlayAnimation(bAnniversaryReward ? OnlyAnniversaryRewardAnim : OnlyRotationRewardAnim);
}


//////////////////////////////////////////////////////////////////////////
// Check In Base Widget
//////////////////////////////////////////////////////////////////////////
void UCheckInBaseWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PageNameText = CastChecked<UTextBlock>(GetWidgetFromName("PageName"));
	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	CommentText = CastChecked<UTextBlock>(GetWidgetFromName("Comment"));
	CheckInTodayWidget = CastChecked<UCheckInTodayWidget>(GetWidgetFromName("CheckInToday"));
	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
}

void UCheckInBaseWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation != CloseAnim)
	{
		return;
	}

	FCheckInBoardType NextBoardType = GetHUDStore().GetCheckInManager().GetNextCheckInBoardType(BoardType);
	if (NextBoardType == CheckInBoardTypeInvalid)
	{
		// If end of check-in, show friendship collect
		ACTION_DISPATCH_CheckInClear();
		ACTION_DISPATCH_FriendshipCollect();
	}
	else
	{
		const FCheckInAssetRow& CheckInAssetRow = GetGameResource().GetCheckInAssetRow(NextBoardType);
		if (CheckInAssetRow.BoardWidgetClass.Get() == GetClass())
		{
			PlayAnimation(OpenAnim);
			SetBoard(NextBoardType, CheckInAssetRow);
			return;
		}

		GetCheckedLobbyHUD(this)->OpenCheckInPopup(NextBoardType, CheckInAssetRow);
	}

	Super::OnAnimationFinished_Implementation(Animation);
}

void UCheckInBaseWidget::SetBoard(FCheckInBoardType InBoardType, const FCheckInAssetRow& CheckInAssetRow)
{
	BoardType = InBoardType;

	const FCMSCheckInBoardRow& BoardRow = GetCMS()->GetCheckInBoardRowOrDummy(BoardType);
	PageNameText->SetText(BoardRow.Name);

	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CheckInAssetRow.CharacterTexture);

	if (CheckInAssetRow.BGTexture.IsNull())
	{
		BGImage->SetBrushFromSoftTextureWhenLoadingFinished(DefaultBGTexture);
	}
	else
	{
		BGImage->SetBrushFromSoftTextureWhenLoadingFinished(CheckInAssetRow.BGTexture);
	}
}

//////////////////////////////////////////////////////////////////////////
// Check In Widget
//////////////////////////////////////////////////////////////////////////
void UCheckInWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AnniversaryDayCountText = CastChecked<UTextBlock>(GetWidgetFromName("AnniversaryDayCount"));
	RemainAnniversaryDaysText = CastChecked<UTextBlock>(GetWidgetFromName("RemainAnniversaryDays"));

	AnniversaryItemWidget = CastChecked<URewardItemWidget>(GetWidgetFromName("AnniversaryItem"));
	AnniversaryItemWidget->SetCheckInType(ECheckInType::Anniversary, false);

	DailyRewardItemWidgets.Reset();
	for (int32 n = 1; ; ++n) {
		FString WidgetName = FString::Printf(TEXT("CheckInItem%d"), n);
		URewardItemWidget* ItemWidget = Cast<URewardItemWidget>(GetWidgetFromName(*WidgetName));

		if (!ItemWidget)
		{
			break;
		}

		ItemWidget->SetCheckInType(ECheckInType::Rotation, true);
		DailyRewardItemWidgets.Add(ItemWidget);
	}

	RotationRewardOnlyAnim = GetWidgetAnimationFromName(this, "AnimRotationRewardOnly");
	AnniversaryRewardAnim = GetWidgetAnimationFromName(this, "AnimAnniversaryReward");
}

void UCheckInWidget::SetBoard(FCheckInBoardType InBoardType, const FCheckInAssetRow& CheckInAssetRow)
{
	Super::SetBoard(InBoardType, CheckInAssetRow);

	const FCMSCheckInBoardRow& BoardRow = GetCMS()->GetCheckInBoardRowOrDummy(InBoardType);
	TArray<const FCMSCheckInRewardRow*> RotationRewardRows = GetCMS()->GetCheckInRewards(BoardRow.RotationRewardId);
	if (DailyRewardItemWidgets.Num() < RotationRewardRows.Num())
	{
		Q6JsonLogRoze(Warning, "UCheckInWidget::SetBoard - Can't show all rotation check-in rewards", Q6KV("BoardType", InBoardType.x));
	}

	const FCheckInInfo* CheckInInfo = GetHUDStore().GetCheckInManager().GetCheckInInfo(InBoardType);
	if (!CheckInInfo)
	{
		Q6JsonLogRoze(Warning, "UCheckInWidget::SetBoard - Not found check-in info", Q6KV("BoardType", InBoardType.x));
		return;
	}

	int32 RotationDay = GetCMS()->GetRotationCheckInDay(InBoardType);
	for (int32 i = 0; i < DailyRewardItemWidgets.Num(); ++i)
	{
		if (!RotationRewardRows.IsValidIndex(i))
		{
			DailyRewardItemWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		DailyRewardItemWidgets[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		const FCMSCheckInRewardRow* RewardRow = RotationRewardRows[i];
		if (!RewardRow)
		{
			Q6JsonLogRoze(Error, "UCheckInWidget::SetBoard - Not found reward", Q6KV("BoardType", InBoardType.x));
			continue;
		}

		const FCMSLootDataRow& LootRow = GetCMS()->GetFirstLootDataOrDummyFromLootGroups(RewardRow->GetLootGroup());
		int32 RewardDay = (CheckInInfo->DayCount % RotationDay == 0) ? RotationDay : CheckInInfo->DayCount % RotationDay;
		DailyRewardItemWidgets[i]->SetCheckInItem(LootRow, RewardDay, RewardRow->RewardDay);

		if (RewardDay == RewardRow->RewardDay)
		{
			// Today rotation reward
			CheckInTodayWidget->SetReward(ECheckInType::Rotation, LootRow);
		}
	}

	int32 AnniversaryRewardDay = 0;
	int32 RotationResetDay = (RotationDay == 0 || CheckInInfo->DayCount % RotationDay == 0) ? CheckInInfo->DayCount : CheckInInfo->DayCount + RotationDay - (CheckInInfo->DayCount % RotationDay);
	TArray<const FCMSCheckInRewardRow*> AnniversaryRewardRows = GetCMS()->GetCheckInRewards(BoardRow.AnniversaryRewardId);
	for (const FCMSCheckInRewardRow* RewardRow : AnniversaryRewardRows)
	{
		if (RewardRow->RewardDay > RotationResetDay)
		{
			continue;
		}

		const FCMSLootDataRow& LootRow = GetCMS()->GetFirstLootDataOrDummyFromLootGroups(RewardRow->GetLootGroup());
		if (CheckInInfo->DayCount == RewardRow->RewardDay)
		{
			CheckInTodayWidget->SetReward(ECheckInType::Anniversary, LootRow);
		}

		AnniversaryItemWidget->SetCheckInItem(LootRow, CheckInInfo->DayCount, RewardRow->RewardDay);

		AnniversaryRewardDay = RewardRow->RewardDay;
	}

	CheckInTodayWidget->PlayRewardAnimation(true, CheckInInfo->DayCount == AnniversaryRewardDay);

	if (AnniversaryRewardDay > 0)
	{
		AnniversaryDayCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "DailyCount"), FText::AsNumber(AnniversaryRewardDay)));

		if (AnniversaryRewardDay == CheckInInfo->DayCount)
		{
			RemainAnniversaryDaysText->SetText(Q6Util::GetLocalizedText("Lobby", "DDayToday"));
			CommentText->SetText(CheckInAssetRow.AnniversaryRewardComment);
		}
		else if (AnniversaryRewardDay < CheckInInfo->DayCount)
		{
			RemainAnniversaryDaysText->SetText(Q6Util::GetLocalizedText("Lobby", "RewardReceived"));
			CommentText->SetText(CheckInAssetRow.RotationRewardComment);
		}
		else
		{
			RemainAnniversaryDaysText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "DDayCount"), FText::AsNumber(AnniversaryRewardDay - CheckInInfo->DayCount)));
			CommentText->SetText(CheckInAssetRow.RotationRewardComment);
		}

		PlayAnimation(AnniversaryRewardAnim);
	}
	else
	{
		CommentText->SetText(CheckInAssetRow.RotationRewardComment);
		PlayAnimation(RotationRewardOnlyAnim);
	}

	if (BoardRow.Category == ECheckInCategory::Basic)
	{
		ACTION_DISPATCH_WeeklyMissionToast();
	}
}


//////////////////////////////////////////////////////////////////////////
// Check In Anniversary Widget
//////////////////////////////////////////////////////////////////////////
void UCheckInAnniversaryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EventLogoImage = CastChecked<UImage>(GetWidgetFromName("EventLogo"));
	PeriodText = CastChecked<UTextBlock>(GetWidgetFromName("Period"));
	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
}

void UCheckInAnniversaryWidget::SetBoard(FCheckInBoardType InBoardType, const FCheckInAssetRow& CheckInAssetRow)
{
	Super::SetBoard(InBoardType, CheckInAssetRow);

	// Set event logo

	if (CheckInAssetRow.LogoTexture.IsNull())
	{
		EventLogoImage->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		EventLogoImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		EventLogoImage->SetBrushFromSoftTextureWhenLoadingFinished(CheckInAssetRow.LogoTexture);
	}

	// Set period

	const FCheckInInfo* CheckInInfo = GetHUDStore().GetCheckInManager().GetCheckInInfo(InBoardType);
	if (!CheckInInfo)
	{
		Q6JsonLogRoze(Error, "UCheckInAnniversaryWidget::SetBoard - Not opened check-in board", Q6KV("BoardType", InBoardType));
		return;
	}

	const FCMSCheckInBoardRow& BoardRow = GetCMS()->GetCheckInBoardRowOrDummy(InBoardType);
	const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(BoardRow.EventId);
	if (!ScheduleInfo)
	{
		Q6JsonLogRoze(Error, "UCheckInAnniversaryWidget::SetBoard - Invalid event", Q6KV("EventId", BoardRow.EventId));
		return;
	}

	if (!UCMS::IsInfinityEventScheduleFormat(*ScheduleInfo))
	{
		FText Period = FText::Format(Q6Util::GetLocalizedText("Lobby", "EventCheckInPeriod"),
			Q6Util::GetLocalDateTimeText(ScheduleInfo->StartDate), Q6Util::GetLocalDateTimeText(ScheduleInfo->EndDate));
		PeriodText->SetText(Period);
	}
	else
	{
		if (BoardRow.Category == ECheckInCategory::Basic || BoardRow.Category == ECheckInCategory::Event)
		{
			PeriodText->SetText(FText::GetEmpty());
		}
		else
		{
			int32 OpeningDays = BoardRow.Category == ECheckInCategory::Newbie ? SystemConst::Q6_CHECK_IN_BOARD_NEWBIE_DAYS : SystemConst::Q6_CHECK_IN_BOARD_COME_BACK_DAYS;
			int32 RemainDays = Q6Util::GetRemainDays(CheckInInfo->OpenTime + (OpeningDays * SecondsPerDay));
			PeriodText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "CheckInPeriod"), FText::AsNumber(RemainDays)));
		}
	}

	// Set reward items

	ItemListWidget->ClearList();

	bool bRewardDay = false;
	TArray<const FCMSCheckInRewardRow*> CheckInRows = GetCMS()->GetCheckInRewards(BoardRow.AnniversaryRewardId);
	for (const FCMSCheckInRewardRow* Row : CheckInRows)
	{
		check(Row);

		URewardItemWidget* ItemWidget = CastChecked<URewardItemWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetCheckInType(ECheckInType::Anniversary, true);

		const FCMSLootDataRow& LootDataRow = GetCMS()->GetFirstLootDataOrDummyFromLootGroups(Row->GetLootGroup());
		ItemWidget->SetCheckInItem(LootDataRow, CheckInInfo->DayCount, Row->RewardDay);

		if (CheckInInfo->DayCount == Row->RewardDay)
		{
			bRewardDay = true;
			CheckInTodayWidget->SetReward(ECheckInType::Anniversary, LootDataRow);
		}
	}

	if (bRewardDay)
	{
		CheckInTodayWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		CheckInTodayWidget->PlayRewardAnimation(false, true);
	}
	else
	{
		CheckInTodayWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	// Set comment

	CommentText->SetText(CheckInAssetRow.AnniversaryRewardComment);
}
