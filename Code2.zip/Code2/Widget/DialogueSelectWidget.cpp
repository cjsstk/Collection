// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "DialogueSelectWidget.h"

#include "Q6.h"
#include "Q6Log.h"
#include "PopupWidgets.h"
#include "WidgetUtil.h"

UDialogueSelectWidget::UDialogueSelectWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ChoiceIndex(INDEX_NONE)
{
}

void UDialogueSelectWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ButtonStartAnim = GetWidgetAnimationFromName(this, "AnimButtonStart");
	ButtonEndAnim = GetWidgetAnimationFromName(this, "AnimButtonEnd");
	ButtonSelectedAnim = GetWidgetAnimationFromName(this, "AnimButtonSelected");

	NormalBgImage = CastChecked<UImage>(GetWidgetFromName("BgNormal"));
	SelectedBgImage = CastChecked<UImage>(GetWidgetFromName("BgSelected"));

	ChoiceButton = CastChecked<UButton>(GetWidgetFromName("ButtonChoice"));
	ChoiceButton->OnClicked.AddUniqueDynamic(this, &UDialogueSelectWidget::OnChoiceButtonClicked);

	ChoiceText = CastChecked<UTextBlock>(GetWidgetFromName("TextChoice"));
}

void UDialogueSelectWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == ButtonSelectedAnim)
	{
		OnSelectEnd.ExecuteIfBound(ChoiceIndex);
	}
}

void UDialogueSelectWidget::OnChoiceButtonClicked()
{
	OnSelected.ExecuteIfBound(ChoiceIndex);
}

void UDialogueSelectWidget::SetChoice(int32 Index, const FText& InText, EDialogueMode Mode)
{
	ChoiceIndex = Index;
	ChoiceText->SetText(InText);

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	PlayAnimation(ButtonStartAnim);

	if (Mode == EDialogueMode::Normal)
	{
		NormalBgImage->SetBrush(NormalBg);
		SelectedBgImage->SetBrush(SelectedBg);
	}
	else if (Mode == EDialogueMode::Chat)
	{
		NormalBgImage->SetBrush(ChatNormalBg);
		SelectedBgImage->SetBrush(ChatSelectedBg);
	}
}

void UDialogueSelectWidget::PlaySelection(int32 Index)
{
	if (!IsVisible())
	{
		return;
	}

	if (ChoiceIndex == Index)
	{
		PlayAnimation(ButtonSelectedAnim);
	}
	else
	{
		PlayAnimation(ButtonEndAnim);
	}

	SetVisibility(ESlateVisibility::HitTestInvisible);
}

const FText& UDialogueSelectWidget::GetText() const
{
	return ChoiceText->Text;
}
