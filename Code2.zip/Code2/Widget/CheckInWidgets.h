// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"

#include "CheckInWidgets.generated.h"

enum class ECheckInType : uint8;

class URewardItemWidget;

UCLASS()
class Q6_API UCheckInTodayWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetReward(ECheckInType CheckInType, const FCMSLootDataRow& LootRow);

	void PlayRewardAnimation(bool bRotationReward, bool bAnniversaryReward);

private:
	UPROPERTY()
	UItemWidget* RotationItemWidget;

	UPROPERTY()
	UItemWidget* AnniversaryItemWidget;

	UPROPERTY(Transient)
	UWidgetAnimation* OnlyRotationRewardAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* OnlyAnniversaryRewardAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AllRewardAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ReceiveRewardAnim;
};

UCLASS()
class Q6_API UCheckInBaseWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	virtual void SetBoard(FCheckInBoardType InBoardType, const FCheckInAssetRow& CheckInAssetRow);

protected:
	UPROPERTY()
	UTextBlock* CommentText;

	UPROPERTY()
	UCheckInTodayWidget* CheckInTodayWidget;

private:
	UPROPERTY()
	UTextBlock* PageNameText;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> DefaultBGTexture;

	FCheckInBoardType BoardType;
};


UCLASS()
class Q6_API UCheckInWidget : public UCheckInBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void SetBoard(FCheckInBoardType InBoardType, const FCheckInAssetRow& CheckInAssetRow) override;

private:
	UPROPERTY()
	UTextBlock* AnniversaryDayCountText;

	UPROPERTY()
	UTextBlock* RemainAnniversaryDaysText;

	UPROPERTY()
	TArray<URewardItemWidget*> DailyRewardItemWidgets;

	UPROPERTY()
	URewardItemWidget* AnniversaryItemWidget;

	UPROPERTY(Transient)
	UWidgetAnimation* RotationRewardOnlyAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AnniversaryRewardAnim;
};

UCLASS()
class Q6_API UCheckInAnniversaryWidget : public UCheckInBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void SetBoard(FCheckInBoardType InBoardType, const FCheckInAssetRow& CheckInAssetRow) override;

private:
	static const int32 SecondsPerDay = 86400;

	UPROPERTY()
	UImage* EventLogoImage;

	UPROPERTY()
	UTextBlock* PeriodText;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;
};
