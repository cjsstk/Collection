#include "MigriumRefineryWidgets.h"

#include "BagItemManager.h"
#include "ItemWidgets.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "PopupWidgets.h"
#include "SmelterManager.h"
#include "Q6.h"
#include "Q6Account.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent MigriumRefinery"), STAT_OnHSEventByMigriumRefinery, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Migrium Refinery Widget
//////////////////////////////////////////////////////////////////////////
UMigriumRefineryWidget::UMigriumRefineryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bButtonLock(false)
	, RefiningCount(0)
	, ReceiveProductCount(0)
	, EndProgressValue(0)
	, CurrProgressValue(0)
	, TotalRemainSeconds(0)
{

}

void UMigriumRefineryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	Point1Text = CastChecked<UTextBlock>(GetWidgetFromName("Point1"));
	TotalTimerText = CastChecked<UTextBlock>(GetWidgetFromName("TotalTimer"));
	AmountText = CastChecked<UTextBlock>(GetWidgetFromName("TextAmount"));
	MaxText = CastChecked<UTextBlock>(GetWidgetFromName("TextMax"));
	RefiningCountText = CastChecked<UTextBlock>(GetWidgetFromName("RefiningCount"));

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));

	PlusButton = CastChecked<UButton>(GetWidgetFromName("BtnPlus"));
	PlusButton->OnClicked.AddUniqueDynamic(this, &UMigriumRefineryWidget::OnPlusButtonClicked);

	MinusButton = CastChecked<UButton>(GetWidgetFromName("BtnMinus"));
	MinusButton->OnClicked.AddUniqueDynamic(this, &UMigriumRefineryWidget::OnMinusButtonClicked);

	MinButton = CastChecked<UButton>(GetWidgetFromName("BtnMin"));
	MinButton->OnClicked.AddUniqueDynamic(this, &UMigriumRefineryWidget::OnMinButtonClicked);

	MaxButton = CastChecked<UButton>(GetWidgetFromName("BtnMax"));
	MaxButton->OnClicked.AddUniqueDynamic(this, &UMigriumRefineryWidget::OnMaxButtonClicked);

	UButton* GetButton = CastChecked<UButton>(GetWidgetFromName("BtnGet"));
	GetButton->OnClicked.AddUniqueDynamic(this, &UMigriumRefineryWidget::OnGetButtonClicked);

	RefineryTimerBorder = CastChecked<UBorder>(GetWidgetFromName("RefineryTimerBox"));

	StockNewMarkImage = CastChecked<UImage>(GetWidgetFromName("StockNewMark"));
}

void UMigriumRefineryWidget::NativeDestruct()
{
	FTimerManager& TimerManager = GetWorld()->GetTimerManager();
	TimerManager.ClearTimer(TimeHandle);

	Super::NativeDestruct();
}

void UMigriumRefineryWidget::SetWonder()
{
	Reset();
}

void UMigriumRefineryWidget::RefreshUI()
{
	Reset();
}

void UMigriumRefineryWidget::OnMenuEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByMigriumRefinery);

	switch (InAction->GetActionType())
	{
		case EHSActionType::SmelterDecStockResp:
		case EHSActionType::SmelterIncStockResp:
		{
			Reset();
			bButtonLock = false;
		}
		break;
		case EHSActionType::SmelterProduceResp:
		case EHSActionType::SmelterUpgradeCompleteResp:
		{
			Reset();
		}
		break;
		case EHSActionType::SmelterReceiveResp:
		{
			const USmelterManager& SmelterManager = GetHUDStore().GetSmelterManager();
			const FSmelterInfo& SmelterInfo = SmelterManager.GetSmelterInfo();

			const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterInfo.Level);
			if (!SmelterRow)
			{
				Q6JsonLogGenie(Warning, "No Exist FCMSSmelterRow", Q6KV("SmelterLevel", SmelterInfo.Level));
				break;
			}

			const FCMSBagItemRow& BagItem = SmelterRow->GetBagItem();
			if (BagItem.IsInvalid())
			{
				Q6JsonLogGenie(Warning, "No Exist FCMSBagItemRow", Q6KV("SmelterLevel", SmelterInfo.Level));
				break;
			}

			FItemData Item;
			Item.Category = ELootCategory::BagItem;
			Item.Type = BagItem.Type;
			Item.Count = SmelterRow->MigriumValue * ReceiveProductCount;

			UItemReceivedPopupWidget* ItemReceivedPopup = GetLobbyHUD(this)->OpenItemReceivedPopup();
			ItemReceivedPopup->SetItem(TArray<FItemData>(&Item, 1));
			ItemReceivedPopup->OnPopupClosedDelegate.BindUObject(this
				, &UMigriumRefineryWidget::OnItemReceivedPopupClosed);
		}
		break;
	}
}

void UMigriumRefineryWidget::Reset()
{
	const USmelterManager& SmelterManager = GetHUDStore().GetSmelterManager();
	const FSmelterInfo& SmelterInfo = SmelterManager.GetSmelterInfo();


	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterInfo.Level);
	if (!SmelterRow)
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSSmelterRow", Q6KV("SmelterLevel", SmelterInfo.Level));
		return;
	}

	RefiningCount = SmelterInfo.Stock;
	EndProgressValue = 0;

	SetMigriumOre(SmelterInfo);
	SetRefiningCountText(FText::AsNumber(RefiningCount));
	SetAmountText(FText::AsNumber(SmelterInfo.Product));
	SetMaxText(FText::AsNumber(SmelterRow->ProductStock));

	SetMigriumRefineryPorgressBar(0.0f);

	const EIncomeState ProductionState = SmelterManager.GetProductionState();
	switch (ProductionState)
	{
		case EIncomeState::NotStored:
		case EIncomeState::MaxStored:
		{
			MigriumRefineryState(EMigriumRefineryState::Empty);
		}
		break;
		case EIncomeState::Stored:
		{
			SetRemainTime(SmelterInfo);
			MigriumRefineryState(EMigriumRefineryState::InProgress);
		}
		break;
	}

	SetItemInfo(SmelterInfo);

	bool bCanStock = GetHUDStore().CheckMigriumStockCost();
	MinusButton->SetIsEnabled(RefiningCount != 0);
	PlusButton->SetIsEnabled(bCanStock
		&& (SmelterInfo.Product + SmelterInfo.Stock < SmelterRow->ProductStock));

	MinButton->SetIsEnabled(RefiningCount > 1);
	MaxButton->SetIsEnabled(bCanStock
		&& RefiningCount < MAX_SMELTER_STOCK
		&& SmelterRow->ProductStock - SmelterInfo.Product - RefiningCount > 0);

	bool bTimeBorderVisible = SmelterInfo.Stock > 0
		&& (SmelterInfo.Product < SmelterRow->ProductStock);

	RefineryTimerBorder->SetVisibility(bTimeBorderVisible ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	MigriumRefineryResultItemState(SmelterInfo.Product > 0
		, SmelterInfo.Product == SmelterRow->ProductStock);

	SetNewMark(SmelterInfo);
}

void UMigriumRefineryWidget::SetMigriumOre(const FSmelterInfo& SmelterInfo)
{
	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterInfo.Level);
	if (!SmelterRow)
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSSmelterRow", Q6KV("SmelterLevel", SmelterInfo.Level));
		return;
	}

	const int32 BagItemCount = GetHUDStore().GetBagItemManager().GetBagItemCount(
		FBagItemType(SmelterRow->Material));

	Point1Text->SetText(FText::AsNumber(BagItemCount));
}

void UMigriumRefineryWidget::SetAmountText(const FText& Text)
{
	AmountText->SetText(Text);
}

void UMigriumRefineryWidget::SetMaxText(const FText& Text)
{
	MaxText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "MaxCount")
		, Text));
}

void UMigriumRefineryWidget::SetRefiningCountText(const FText& Text)
{
	RefiningCountText->SetText(Text);
}

void UMigriumRefineryWidget::SetRemainTime(const FSmelterInfo& SmelterInfo)
{
	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterInfo.Level);
	if (!SmelterRow)
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSSmelterRow", Q6KV("SmelterLevel", SmelterInfo.Level));
		return;
	}

	CurrProgressValue = FDateTime::UtcNow().ToUnixTimestamp() - SmelterInfo.StockTimeSec;
	EndProgressValue = SmelterRow->ProductTime * 60;

	TotalRemainSeconds = SmelterInfo.StockTimeSec
		+ (SmelterRow->ProductTime * 60 * SmelterInfo.Stock)
		- FDateTime::UtcNow().ToUnixTimestamp();

	FTimerManager& TimerManager = GetWorld()->GetTimerManager();
	TimerManager.ClearTimer(TimeHandle);

	TimerManager.SetTimer(TimeHandle, this
		, &UMigriumRefineryWidget::SetMigriumRefineryTimer, 1.0f, true, 0.0f);
}

void UMigriumRefineryWidget::SetMigriumRefineryTimer()
{
	if (EndProgressValue == 0)
	{
		FTimerManager& TimerManager = GetWorld()->GetTimerManager();
		TimerManager.ClearTimer(TimeHandle);

		return;
	}

	TotalTimerText->SetText(Q6Util::GetRemainTimeText(TotalRemainSeconds));
	--TotalRemainSeconds;

	SetMigriumRefineryPorgressBar((float)CurrProgressValue / EndProgressValue);
	++CurrProgressValue;
}

void UMigriumRefineryWidget::SetItemInfo(const FSmelterInfo& SmelterInfo)
{
	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterInfo.Level);
	if (!SmelterRow)
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSSmelterRow", Q6KV("SmelterLevel", SmelterInfo.Level));
		return;
	}

	const FCMSBagItemRow& BagItemRow = SmelterRow->GetBagItem();
	if (BagItemRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSBagItemRow", Q6KV("SmelterLevel", SmelterInfo.Level));
		return;
	}

	ItemWidget->SetBagItem(FBagItemType(BagItemRow.CmsType()), SmelterRow->MigriumValue);
}

void UMigriumRefineryWidget::SetNewMark(const FSmelterInfo& Info)
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	
	ESlateVisibility StockNewMarkVisibility = NewMarkMgr.GetWonderMigriumStockVisibility(Info);
	StockNewMarkImage->SetVisibility(StockNewMarkVisibility);
}

void UMigriumRefineryWidget::OnPlusButtonClicked()
{
	if (!GetHUDStore().CheckMigriumStockCost())
	{
		return;
	}

	if (RefiningCount >= MAX_SMELTER_STOCK)
	{
		RefiningCount = MAX_SMELTER_STOCK;
		return;
	}

	bButtonLock = true;
	GetHUDStore().GetSmelterManager().ReqIncStock();
}

void UMigriumRefineryWidget::OnMinusButtonClicked()
{
	if (RefiningCount <= 0)
	{
		RefiningCount = 0;
		return;
	}

	if (RefiningCount == 1)
	{
		UConfirmPopupWidget* ConfirmPopupWidget = GetCheckedLobbyHUD(this)->OpenConfirmPopup(
			Q6Util::GetLocalizedText("Popup", "RefineryCancleTitle")
			, Q6Util::GetLocalizedText("Popup", "RefineryCancleContent")
		);
		ConfirmPopupWidget->OnConfirmPopupDelegate.BindLambda([](EConfirmPopupFlag Flag)
		{
			if (Flag == EConfirmPopupFlag::Yes)
			{
				GetHUDStore().GetSmelterManager().ReqDecStock();
			}
		});

		return;
	}

	bButtonLock = true;
	GetHUDStore().GetSmelterManager().ReqDecStock();
}

void UMigriumRefineryWidget::OnMinButtonClicked()
{
	if (RefiningCount <= 1)
	{
		return;
	}

	bButtonLock = true;
	GetHUDStore().GetSmelterManager().ReqDecStock(RefiningCount - 1);
}

void UMigriumRefineryWidget::OnMaxButtonClicked()
{
	if (RefiningCount >= MAX_SMELTER_STOCK)
	{
		RefiningCount = MAX_SMELTER_STOCK;
		return;
	}

	const USmelterManager& SmelterManager = GetHUDStore().GetSmelterManager();
	const FSmelterInfo& SmelterInfo = SmelterManager.GetSmelterInfo();

	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterInfo.Level);
	if (!SmelterRow)
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSSmelterRow", Q6KV("SmelterLevel", SmelterInfo.Level));
		return;
	}

	int32 Count = SmelterRow->ProductStock - SmelterInfo.Product - SmelterInfo.Stock;
	if (Count <= 0)
	{
		return;
	}

	Count = FMath::Clamp(Count, 1, MAX_SMELTER_STOCK - SmelterInfo.Product - SmelterInfo.Stock);

	const int32 BagItemCount = GetHUDStore().GetBagItemManager().GetBagItemCount(
		FBagItemType(SmelterRow->Material));

	Count = FMath::Clamp(Count, 1, BagItemCount);

	bButtonLock = true;
	GetHUDStore().GetSmelterManager().ReqIncStock(Count);
}

void UMigriumRefineryWidget::OnGetButtonClicked()
{
	const USmelterManager& SmelterManager = GetHUDStore().GetSmelterManager();
	ReceiveProductCount = SmelterManager.GetSmelterInfo().Product;
	if (ReceiveProductCount <= 0)
	{
		return;
	}

	SmelterManager.ReqReceive();
}

void UMigriumRefineryWidget::OnItemReceivedPopupClosed()
{
	Reset();
}
