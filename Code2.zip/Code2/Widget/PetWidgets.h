// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "WonderWidgets.h"

#include "PetWidgets.generated.h"

class UQ6TextBlock;
class UPageSwipeWidget;
class UTurnSkillIconWidget;
class USkillUpInfoWidget;
class UQ6RichTextBlock;
class UMaterialBoxWidget;
class UPointWidget;

enum class EPetSkillState : uint8
{
	Normal = 0,
	Locked = 1,
	LowLevel = 2,
	MaxLevel = 3,
	Invalid = 4,
};

UCLASS()
class Q6_API UPetIconWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	
	void SetPet(FPetType Type);

private:
	UPROPERTY()
	UImage* IconImage;
};


UCLASS()
class Q6_API UPetSkillUpgradeResultPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPetSkill(FPetId PetId, int32 SkillIndex);

private:
	UPROPERTY()
	UQ6TextBlock* PetNameText;

	UPROPERTY()
	UQ6TextBlock* SkillNameText;

	UPROPERTY()
	UTurnSkillIconWidget* SkillIcon;

	UPROPERTY()
	USkillUpInfoWidget* CurrentSkillWidget;

	UPROPERTY()
	USkillUpInfoWidget* ResultSkillWidget;

	UPROPERTY()
	UPetIconWidget* PetIconWidget;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradeAnim;
};


UCLASS()
class Q6_API UPetParkWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) override;

	virtual void SetWonder() override;
	virtual void RefreshUI() override;

private:
	void SetSkillIcons(const FPetInfo& PetInfo, int32 SelectedIndex);

	void SetSkillState(EPetSkillState SkillState);
	void SetSkillInfo(const FCMSSkillRow& SkillRow, int32 SkillLevel, bool bUpgrade);
	void SetSkillDetail(const FCMSSkillRow& SkillRow, int32 SkillLevel);

	UFUNCTION()
	void OnUpgradeButtonClicked();

	UFUNCTION()
	void OnPetSkillUpgrade(EConfirmPopupFlag Option);

	void OnPetPageChanged(int32 NewPage);

	void OnSelectedSkill(int32 SkillIndex);

	// Widgets

	UPROPERTY()
	UQ6TextBlock* PetNameText;

	UPROPERTY()
	UPageSwipeWidget* PetSwipeWidget;

	UPROPERTY()
	UQ6TextBlock* SkillNameText;

	UPROPERTY()
	TArray<UTurnSkillIconWidget*> SkillIcons;

	UPROPERTY()
	USkillUpInfoWidget* CurrentSkillWidget;

	UPROPERTY()
	USkillUpInfoWidget* ResultSkillWidget;

	UPROPERTY()
	UQ6RichTextBlock* InfoText;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UPointWidget* RequireGoldWidget;

	UPROPERTY()
	UPointWidget* OwnedGoldWidget;

	UPROPERTY()
	UButton* UpgradeButton;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* IntroAnim;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> DetailAnims;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPetSkillUpgradeResultPopupWidget> ResultPopupWidgetClass;

	FPetId PetId;
	int32 SelectedSkillIdx;
};
