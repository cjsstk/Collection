// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "AccountWidgets.h"

#include "AvatarManager.h"
#include "CodexManager.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HAL/PlatformApplicationMisc.h"
#include "LevelUtil.h"
#include "LobbyHUD.h"
#include "PointWidgets.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "SystemConst_gen.h"
#include "TitleManager.h"
#include "UserRecordManager.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Account"), STAT_OnHSEventByAccount, STATGROUP_HSTORE);

UGetAkaConfirmPopupWidget::UGetAkaConfirmPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UGetAkaConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AkaText = CastChecked<UTextBlock>(GetWidgetFromName("Aka"));
	ContentText = CastChecked<URichTextBlock>(GetWidgetFromName("Content"));
	GetReputationBadgeText = CastChecked<URichTextBlock>(GetWidgetFromName("GetReputationBadge"));

	UButton* YesButton = CastChecked<UButton>(GetWidgetFromName("Yes"));
	YesButton->OnClicked.AddUniqueDynamic(this, &UGetAkaConfirmPopupWidget::OnYesButtonClicked);

	OnDismissButtonClickedDelegate.BindUObject(this, &UGetAkaConfirmPopupWidget::OnDismiss);
}

void UGetAkaConfirmPopupWidget::InitGetAkaConfirmPopup(const FUserTitleType& Type)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "GetAkaConfirmTitle"));

	const UCMS* CMS = GetCMS();
	const FCMSUserTitleRow& UserTitleRow = CMS->GetUserTitleRowOrDummy(Type);
	if (UserTitleRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist UserTitleType", Q6KV("type", Type));
		return;
	}

	SetAkaText(UserTitleRow.DescName);
	SetContentText(FText::AsNumber(UserTitleRow.Point));

	const TArray<FUserTitleType>& Titles = GetHUDStore().GetTitleManager().GetTitles();
	const FUserTitleType& LastTitle = Titles.Last();

	const FCMSUserTitleRow& LastUserTitleRow = CMS->GetUserTitleRowOrDummy(LastTitle);
	if (LastUserTitleRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist UserTitleType", Q6KV("type", Type));
		return;
	}

	const int32 CurrUserTitleScore = GetUser().GetTitleScore();
	const int32 BefoUserTitleScore = CurrUserTitleScore - LastUserTitleRow.Point;

	const FAkaAssetRow* AkaAssetRow = GetGameResource().GetAkaAssetRowByPoint(
		BefoUserTitleScore, CurrUserTitleScore);
	if (AkaAssetRow)
	{
		GetReputationBadgeText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		SetReputationBadgeText(AkaAssetRow->BadgeName);
	}
	else
	{
		GetReputationBadgeText->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UGetAkaConfirmPopupWidget::SetAkaText(const FText& Text)
{
	AkaText->SetText(Text);
}

void UGetAkaConfirmPopupWidget::SetContentText(const FText& Text)
{
	ContentText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Popup", "GetAkaConfirmContent"), Text));
}

void UGetAkaConfirmPopupWidget::SetReputationBadgeText(const FText& Text)
{
	GetReputationBadgeText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Popup", "GetAkaReputationBadge"), Text));
}

void UGetAkaConfirmPopupWidget::OnDismiss()
{
	GetCheckedLobbyHUD(this)->ProcessReward(false);
}

void UGetAkaConfirmPopupWidget::OnYesButtonClicked()
{
	GetCheckedLobbyHUD(this)->ProcessReward(false);

	ClosePopup();
}

UReputationGradeWidget::UReputationGradeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UReputationGradeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetCurrentAnim = GetWidgetAnimationFromName(this, "AnimSetCurrent");
	SetOrderAnim = GetWidgetAnimationFromName(this, "AnimSetOrder");

	IconBadgeImage = CastChecked<UImage>(GetWidgetFromName("IconBadge"));

	ReputationGradeText = CastChecked<UTextBlock>(GetWidgetFromName("ReputationGrade"));
	ReputationPointText = CastChecked<UTextBlock>(GetWidgetFromName("ReputationPoint"));
}

void UReputationGradeWidget::InitReputationGrade(const int32 Index)
{
	const FAkaAssetRow* AkaAssetRowByIndex = GetGameResource().GetAkaAssetRowByIndex(Index);
	if (ensure(AkaAssetRowByIndex))
	{
		SetReputationPointText(FText::AsNumber(AkaAssetRowByIndex->Point));
		SetReputationGradeText(AkaAssetRowByIndex->BadgeName);
		SetBadgeIcon(AkaAssetRowByIndex->Icon);
	}

	const int32 UserTitleScore = GetUser().GetTitleScore();
	const FAkaAssetRow* AkaAssetRowByPoint = GetGameResource().GetAkaAssetRowByPoint(UserTitleScore);

	if (AkaAssetRowByPoint == AkaAssetRowByIndex)
	{
		PlayAnimation(SetCurrentAnim);
	}
	else
	{
		PlayAnimation(SetOrderAnim);
	}
}

void UReputationGradeWidget::SetReputationGradeText(const FText& Text)
{
	ReputationGradeText->SetText(Text);
}

void UReputationGradeWidget::SetReputationPointText(const FText& Text)
{
	ReputationPointText->SetText(Text);
}

void UReputationGradeWidget::SetBadgeIcon(const FSlateBrush& Icon)
{
	IconBadgeImage->SetBrush(Icon);
}

UReputationPointInfoPopupWidget::UReputationPointInfoPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UReputationPointInfoPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	OwnedReputationPointText = CastChecked<URichTextBlock>(GetWidgetFromName("OwnedReputationPoint"));

	ReputationGradeText = CastChecked<UTextBlock>(GetWidgetFromName("ReputationGrade"));

	IconBadgeImage = CastChecked<UImage>(GetWidgetFromName("IconBadge"));

	FString GradeWidgetName;
	for (int32 Index = 0; Index < MAX_AKA_BADGE_COUNT; ++Index)
	{
		GradeWidgetName = FString::Printf(TEXT("Grade%d"), Index);

		UReputationGradeWidget* GradeWidget = CastChecked<UReputationGradeWidget>(
			GetWidgetFromName(*GradeWidgetName));
		GradeWidget->InitReputationGrade(Index);
	}
}

void UReputationPointInfoPopupWidget::InitReputationPointInfo()
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ReputationPointInfoTitle"));

	const int32 UserTitleScore = GetUser().GetTitleScore();
	const FAkaAssetRow* AkaAssetRow = GetGameResource().GetAkaAssetRowByPoint(UserTitleScore);
	if (ensure(AkaAssetRow))
	{
		SetReputationPointText(FText::AsNumber(UserTitleScore));
		SetReputationGradeText(AkaAssetRow->BadgeName);
		SetBadgeIcon(AkaAssetRow->Icon);
	}
}

void UReputationPointInfoPopupWidget::SetReputationPointText(const FText& Text)
{
	OwnedReputationPointText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "OwnedReputationPoint"), Text));
}

void UReputationPointInfoPopupWidget::SetReputationGradeText(const FText& Text)
{
	ReputationGradeText->SetText(Text);
}

void UReputationPointInfoPopupWidget::SetBadgeIcon(const FSlateBrush& Icon)
{
	IconBadgeImage->SetBrush(Icon);
}

UAkaListEntryWidget::UAkaListEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UAkaListEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AkaListAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimSetInUse"));
	AkaListAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimSetSelectable"));
	AkaListAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimSetLocked"));
	check(AkaListAnims.Num() == static_cast<uint8>(EAkaListAnimType::Max));

	AkaText = CastChecked<URichTextBlock>(GetWidgetFromName("Aka"));
	NotYetText = CastChecked<URichTextBlock>(GetWidgetFromName("NotYet"));
	AddReputationText = CastChecked<URichTextBlock>(GetWidgetFromName("AddReputation"));

	SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UAkaListEntryWidget::OnSelectButtonClicked);
}

void UAkaListEntryWidget::SetAkaListInfo(const FCMSUserTitleRow* Row, bool bSelectable, bool bUsed)
{
	if (Row)
	{
		SetAkaText(Row->DescName);
	}
	else
	{
		SetAkaText(Q6Util::GetLocalizedText("Lobby", "AkaNotUsed"));
	}

	if (bUsed)
	{
		PlayAkaListEntryAnimation(EAkaListAnimType::InUse);
	}
	else if (bSelectable)
	{
		PlayAkaListEntryAnimation(EAkaListAnimType::Selectable);
	}
	else
	{
		if (Row)
		{
			NotYetText->SetText(Row->Desc);
			AddReputationText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Lobby", "GetReputationPoint"), FText::AsNumber(Row->Point)));
		}

		PlayAkaListEntryAnimation(EAkaListAnimType::Locked);
	}
}

void UAkaListEntryWidget::SetAkaText(const FText& Text)
{
	AkaText->SetText(Text);
}

void UAkaListEntryWidget::SetNotYetRichText(const FText& Text)
{
	NotYetText->SetText(Text);
}

void UAkaListEntryWidget::SetAddReputationRichText(const FText& Text)
{
	AddReputationText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "GetReputationPoint"), Text));
}

void UAkaListEntryWidget::PlayAkaListEntryAnimation(const EAkaListAnimType Type)
{
	const uint8 Index = static_cast<uint8>(Type);
	if (AkaListAnims.IsValidIndex(Index))
	{
		PlayAnimation(AkaListAnims[Index]);
	}
}

void UAkaListEntryWidget::OnSelectButtonClicked()
{
	OnSelectButtonClickedDelegate.ExecuteIfBound();
}

UChangeAkaPopupWidget::UChangeAkaPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurrSelectedType(UserTitleTypeInvalid)
	, CurrSelectedWidget(nullptr)
{

}

void UChangeAkaPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* ReputationPointButton = CastChecked<UButton>(GetWidgetFromName("BtnReputationPoint"));
	ReputationPointButton->OnClicked.AddUniqueDynamic(this, &UChangeAkaPopupWidget::OnReputationPointButtonClicked);

	AkaListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("AkaList"));

	AkaText = CastChecked<URichTextBlock>(GetWidgetFromName("Aka"));
	OwnedReputationPointText = CastChecked<URichTextBlock>(GetWidgetFromName("OwnedReputationPoint"));

	ReputationGradeText = CastChecked<UTextBlock>(GetWidgetFromName("ReputationGrade"));

	BadgeIconImage = CastChecked<UImage>(GetWidgetFromName("IconBadge"));

	CategoryToggleButtonBox = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CategoryButtons"));
	CategoryToggleButtonBox->OnToggleButtonClickedDelegate.BindUObject(
		this, &UChangeAkaPopupWidget::OnAkaCategoryChanged);
}

void UChangeAkaPopupWidget::InitAka()
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ChangeAkaTitle"));

	const FUserTitleType& UserTitleType = GetUser().GetTitleType();
	SetAkaText(UserTitleType);
	CurrSelectedType = UserTitleType;

	ResetAkaInfo(EUserTitleCategory::Saga);
	CategoryToggleButtonBox->SetSelectedIndex(static_cast<int32>(EUserTitleCategory::Saga));
}

void UChangeAkaPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	if (Option == EConfirmPopupFlag::Yes)
	{
		GetHUDStore().GetTitleManager().Change(CurrSelectedType);
	}

	ClosePopup();
}

void UChangeAkaPopupWidget::ResetAkaInfo(const EUserTitleCategory Category)
{
	const UCMS* CMS = GetCMS();

	const UTitleManager& TitleManager = GetHUDStore().GetTitleManager();
	const TArray<FUserTitleType>& Titles = TitleManager.GetTitles();
	TSet<const FCMSUserTitleRow*> OwnedListInCategory;
	for (const FUserTitleType& Type : Titles)
	{
		const FCMSUserTitleRow& TitleRow = CMS->GetUserTitleRowOrDummy(Type);
		if (TitleRow.IsInvalid())
		{
			continue;
		}

		if (TitleRow.Category != Category)
		{
			continue;
		}

		OwnedListInCategory.Emplace(&TitleRow);
	}

	CurrSelectedWidget = nullptr;
	CurrSelectedType = UserTitleTypeInvalid;

	const TArray<const FCMSUserTitleRow*> AllListInCategory = CMS->GetUserTitleRowsByCategory(Category);
	SetAkaList(OwnedListInCategory, AllListInCategory);

	const int32 UserTitleScore = GetUser().GetTitleScore();
	SetReputationPointText(FText::AsNumber(UserTitleScore));

	const FAkaAssetRow* AkaAssetRow = GetGameResource().GetAkaAssetRowByPoint(UserTitleScore);
	if (ensure(AkaAssetRow))
	{
		SetReputationGradeText(AkaAssetRow->BadgeName);
		SetBadgeIcon(AkaAssetRow->Icon);
	}
}

void UChangeAkaPopupWidget::SetAkaList(const TSet<const FCMSUserTitleRow*> OwnedList,
	const TArray<const FCMSUserTitleRow*> AllList)
{
	AkaListWidget->ClearList();

	const FUserTitleType& UserTitleType = GetUser().GetTitleType();

	if (UserTitleType == UserTitleTypeInvalid)
	{
		UAkaListEntryWidget* NotUsedAkaListEntryWidget = CastChecked<UAkaListEntryWidget>(
			AkaListWidget->AddChildAtLastIndex());
		NotUsedAkaListEntryWidget->OnSelectButtonClickedDelegate.BindUObject(
			this, &UChangeAkaPopupWidget::OnAkaListSelected, UserTitleTypeInvalid, NotUsedAkaListEntryWidget);

		NotUsedAkaListEntryWidget->SetAkaListInfo(nullptr, true, true);

		CurrSelectedType = UserTitleTypeInvalid;
		CurrSelectedWidget = NotUsedAkaListEntryWidget;
	}

	TArray<const FCMSUserTitleRow*> LockedList;
	for (const FCMSUserTitleRow* Row : AllList)
	{
		bool bSelectable = OwnedList.Find(Row);
		if (!bSelectable)
		{
			LockedList.Emplace(Row);
			continue;
		}

		const FUserTitleType TitleType = Row->CmsType();
		UAkaListEntryWidget* AkaListEntryWidget = CastChecked<UAkaListEntryWidget>(
			AkaListWidget->AddChildAtLastIndex());

		AkaListEntryWidget->OnSelectButtonClickedDelegate.BindUObject(
			this, &UChangeAkaPopupWidget::OnAkaListSelected, TitleType, AkaListEntryWidget);

		bool bUsed = UserTitleType == TitleType;
		AkaListEntryWidget->SetAkaListInfo(Row, bSelectable, bUsed);
		if (bUsed)
		{
			CurrSelectedType = UserTitleType;
			CurrSelectedWidget = AkaListEntryWidget;
		}
	}

	for (const FCMSUserTitleRow* Row : LockedList)
	{
		const FUserTitleType TitleType = Row->CmsType();
		UAkaListEntryWidget* AkaListEntryWidget = CastChecked<UAkaListEntryWidget>(
			AkaListWidget->AddChildAtLastIndex());

		AkaListEntryWidget->OnSelectButtonClickedDelegate.BindUObject(
			this, &UChangeAkaPopupWidget::OnAkaListSelected, TitleType, AkaListEntryWidget);

		AkaListEntryWidget->SetAkaListInfo(Row, false, false);
	}

	SetYesButtonEnabled(CurrSelectedType != UserTitleType
		&& CurrSelectedType != UserTitleTypeInvalid);
}

void UChangeAkaPopupWidget::SetAkaText(const FUserTitleType& UserTitleType)
{
	if (UserTitleType == UserTitleTypeInvalid)
	{
		AkaText->SetText(Q6Util::GetLocalizedText("Lobby", "AkaUnused"));
	}
	else
	{
		const FCMSUserTitleRow& UserTitleRow = GetCMS()->GetUserTitleRowOrDummy(UserTitleType);
		AkaText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "AkaUsed"), UserTitleRow.DescName));
	}
}

void UChangeAkaPopupWidget::SetReputationPointText(const FText& Text)
{
	OwnedReputationPointText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "OwnedReputationPoint"), Text));
}

void UChangeAkaPopupWidget::SetReputationGradeText(const FText& Text)
{
	ReputationGradeText->SetText(Text);
}

void UChangeAkaPopupWidget::SetBadgeIcon(const FSlateBrush& Icon)
{
	BadgeIconImage->SetBrush(Icon);
}

void UChangeAkaPopupWidget::OnReputationPointButtonClicked()
{
	UReputationPointInfoPopupWidget* ReputationPointInfoPopup = CastChecked<UReputationPointInfoPopupWidget>(
		GetCheckedLobbyHUD(this)->OpenPopup(ReputationPointInfoPopupClass));
	ReputationPointInfoPopup->InitReputationPointInfo();
}

void UChangeAkaPopupWidget::OnAkaCategoryChanged(int32 Index)
{
	ResetAkaInfo(static_cast<EUserTitleCategory>(Index));
}

void UChangeAkaPopupWidget::OnAkaListSelected(FUserTitleType Type, UAkaListEntryWidget* SelectedWidget)
{
	if (CurrSelectedWidget)
	{
		CurrSelectedWidget->PlayAkaListEntryAnimation(EAkaListAnimType::Selectable);
	}
	if (SelectedWidget)
	{
		SelectedWidget->PlayAkaListEntryAnimation(EAkaListAnimType::InUse);
	}

	CurrSelectedWidget = SelectedWidget;
	CurrSelectedType = Type;

	SetYesButtonEnabled(CurrSelectedType != GetUser().GetTitleType()
		&& CurrSelectedType != UserTitleTypeInvalid);
}

void UChangeNicknamePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NicknameTextBox = CastChecked<UEditableTextBox>(GetWidgetFromName("Nickname"));
	NicknameTextBox->OnTextCommitted.AddUniqueDynamic(this, &UChangeNicknamePopupWidget::OnNicknameCommitted);
	NicknameTextBox->OnTextChanged.AddUniqueDynamic(this, &UChangeNicknamePopupWidget::OnNicknameChanged);
}

void UChangeNicknamePopupWidget::InitNickname(const FString& UserName)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "NickNameChangeTitle"));

	NicknameTextBox->SetText(FText::GetEmpty());
	NicknameTextBox->SetHintText(FText::FromString(UserName));

	SetYesButtonEnabled(false);
}

void UChangeNicknamePopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	if (Option != EConfirmPopupFlag::Yes)
	{
		Super::OnConfirmButtonClicked(Option);
		return;
	}

	if (!ValidateNickName())
	{
		return;
	}

	FString NewName = NicknameTextBox->GetText().ToString();
	GetHUDStore().GetWorldUser().ReqRename(NewName);

	// don't close wait for response
}

void UChangeNicknamePopupWidget::OnNicknameCommitted(const FText& InText, ETextCommit::Type CommitMethod)
{
	OnNicknameChanged(InText);
}

void UChangeNicknamePopupWidget::OnNicknameChanged(const FText& InText)
{
	// length check

	bool bValidNicknameLength = IsValidNicknameLength(InText);

	// current name check

	const FText Nickname = NicknameTextBox->GetText();
	const FString& CurrentName = GetHUDStore().GetWorldUser().GetNickname();
	bool bChangedName = !CurrentName.Equals(Nickname.ToString());

	// set enabled

	SetYesButtonEnabled(bValidNicknameLength && bChangedName);
}

bool UChangeNicknamePopupWidget::IsValidNicknameLength(const FText& InText)
{
	if (InText.ToString().Len() < SystemConst::Q6_MIN_NICKNAME_LENGTH
		|| InText.ToString().Len() > SystemConst::Q6_MAX_NICKNAME_LENGTH)
	{
		return false;
	}

	return true;
}

bool UChangeNicknamePopupWidget::ValidateNickName()
{
	const FText Nickname = NicknameTextBox->GetText();

	// length check

	if (!IsValidNicknameLength(Nickname))
	{
		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "BannedWordLengthNotify"));
		return false;
	}

	// special character check

	if (!Q6Util::IsValidCultureText(Nickname))
	{
		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "BannedWordsNotify"));
		return false;
	}

	return true;
}

void UPointConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PointAWidget = CastChecked<UPointWidget>(GetWidgetFromName("PointA"));
	PointBWidget = CastChecked<UPointWidget>(GetWidgetFromName("PointB"));
}

void UPointConfirmPopupWidget::SetGem(int32 FreeGemAmount, int32 PaidGemAmount)
{
	PointAWidget->SetPointType(ECurrencyType::FreeGem, EPointWidgetOption::NONE);
	PointAWidget->SetCurPoint(FreeGemAmount);

	PointBWidget->SetPointType(EPointType::PaidGem, EPointWidgetOption::NONE);
	PointBWidget->SetCurPoint(PaidGemAmount);
}

///////////////////////////////////////////////////////////////////////////////////////////
// Avatar
void UAvatarItemWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemImage = CastChecked<UImage>(GetWidgetFromName("Item"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UAvatarItemWidget::OnItemClicked);
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UAvatarItemWidget::OnItemLongClicked);

	SelectAnim = GetWidgetAnimationFromName(this, "AnimSelect");
	NormalAnim = GetWidgetAnimationFromName(this, "AnimNormal");
}

void UAvatarItemWidget::SetEmpty()
{
	ItemImage->SetVisibility(ESlateVisibility::Collapsed);
}

void UAvatarItemWidget::SetCharacter(const FCharacterType CharacterType, int32 Illust)
{
	const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	ItemImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.GetIconTexture(Illust));
	ItemImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	PlayAnimation(NormalAnim);
}

void UAvatarItemWidget::SetFrame(const FAvatarFrameType FrameType)
{
	Category = EAvatarCategory::Frame;
	Type = FrameType.x;

	const FAvatarFrameAssetRow* AssetRow = GetGameResource().GetAvatarFrameAssetRow(FrameType);
	if (!AssetRow)
	{
		SetEmpty();
		Q6JsonLogRoze(Error, "UAvatarItemWidget::AvatarFrame - not found avatar frame", Q6KV("FrameType", FrameType));
		return;
	}

	ItemImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow->FrameTexture);
	ItemImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UAvatarItemWidget::SetEffect(const FAvatarEffectType EffectType)
{
	Category = EAvatarCategory::Effect;
	Type = EffectType.x;

	const FAvatarEffectAssetRow* AssetRow = GetGameResource().GetAvatarEffectAssetRow(EffectType);
	if (!AssetRow)
	{
		SetEmpty();
		Q6JsonLogRoze(Error, "UAvatarItemWidget::AvatarEffect - not found avatar effect", Q6KV("EffectType", EffectType));
		return;
	}

	ItemImage->SetBrushFromSoftMaterial(AssetRow->EffectMaterial);
	ItemImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UAvatarItemWidget::SetChecked(const bool InChecked)
{
	PlayAnimation(InChecked ? SelectAnim : NormalAnim);
}

void UAvatarItemWidget::OnItemClicked()
{
	OnItemClickedDelegate.ExecuteIfBound();
}

void UAvatarItemWidget::OnItemLongClicked()
{
	if (Category == EAvatarCategory::Frame)
	{
		GetCheckedLobbyHUD(this)->OpenItemTooltipPopup(FAvatarFrameType(Type));
	}
	else if (Category == EAvatarCategory::Effect)
	{
		GetCheckedLobbyHUD(this)->OpenItemTooltipPopup(FAvatarEffectType(Type));
	}
}

void UAvatarIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	FrameImage = CastChecked<UImage>(GetWidgetFromName("Frame"));
	EffectImage = CastChecked<UImage>(GetWidgetFromName("Effect"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("New"));
}

void UAvatarIconWidget::SetCharacter(const FCharacterType CharacterType, const int32 IllustIndex)
{
	const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.GetIconTexture(IllustIndex));
}

void UAvatarIconWidget::SetFrame(const FAvatarFrameType FrameType)
{
	if (FrameType == AvatarFrameTypeInvalid)
	{
		FrameImage->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	const FAvatarFrameAssetRow* AssetRow = GetGameResource().GetAvatarFrameAssetRow(FrameType);
	if (!AssetRow)
	{
		FrameImage->SetVisibility(ESlateVisibility::Collapsed);
		Q6JsonLogRoze(Error, "UAvatarIconWidget::SetFrame - not found avatar frame", Q6KV("FrameType", FrameType));
		return;
	}

	FrameImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	FrameImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow->FrameTexture);
}

void UAvatarIconWidget::SetEffect(const FAvatarEffectType EffectType)
{
	if (EffectType == AvatarEffectTypeInvalid)
	{
		EffectImage->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	const FAvatarEffectAssetRow* AssetRow = GetGameResource().GetAvatarEffectAssetRow(EffectType);
	if (!AssetRow)
	{
		EffectImage->SetVisibility(ESlateVisibility::Collapsed);
		Q6JsonLogRoze(Error, "UAvatarIconWidget::AvatarEffect - not found avatar effect", Q6KV("EffectType", EffectType));
		return;
	}

	EffectImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	EffectImage->SetBrushFromSoftMaterialWhenLoadingFinished(AssetRow->EffectMaterial);
}

void UAvatarIconWidget::SetNewMark(bool bNewly)
{
	NewMarkImage->SetVisibility(bNewly ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UChangeAvatarPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AvatarIconWidget = CastChecked<UAvatarIconWidget>(GetWidgetFromName("AvatarIcon"));
	ItemCategoryWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("ItemCategory"));
	ItemCategoryWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UChangeAvatarPopupWidget::OnItemCategoryChanged);

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
}

void UChangeAvatarPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	Super::OnConfirmButtonClicked(Option);

	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetHUDStore().GetAvatarManager().ReqSave(ChangedAvatar);
}

void UChangeAvatarPopupWidget::InitAvatar()
{
	const FAvatarInfo& AvatarInfo = GetHUDStore().GetAvatarManager().GetAvatarInfo();
	ChangedAvatar = AvatarInfo;

	AvatarIconWidget->SetCharacter(AvatarInfo.CharacterType, AvatarInfo.CharacterIllustType);
	AvatarIconWidget->SetFrame(AvatarInfo.FrameType);
	AvatarIconWidget->SetEffect(AvatarInfo.EffectType);

	ItemCategoryWidget->SetSelectedIndex((int32)EAvatarCategory::Character);	// Default selected
}

void UChangeAvatarPopupWidget::OnItemCategoryChanged(const int32 InSelectedIndex)
{
	CurrentCategory = (EAvatarCategory)InSelectedIndex;

	if (CurrentCategory == EAvatarCategory::Character)
	{
		SetCharacterList();
	}
	else if (CurrentCategory == EAvatarCategory::Frame)
	{
		SetFrameList();
	}
	else if (CurrentCategory == EAvatarCategory::Effect)
	{
		SetEffectList();
	}
}

void UChangeAvatarPopupWidget::SetCharacterList()
{
	SelectedItemWidget = nullptr;

	const TMap<FCharacterType, FCodexCharInfo>& CodexChars = GetHUDStore().GetCodexManager().GetCodexChars();

	ItemListWidget->ClearList();
	for (const auto& Elem : CodexChars)
	{
		const FCodexCharInfo& Info = Elem.Value;
		for (int32 i = 0; i <= Info.OpenedIllust; ++i)
		{
			UAvatarItemWidget* ItemWidget = CastChecked<UAvatarItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetCharacter(Info.Type, i);
			if (Info.Type == ChangedAvatar.CharacterType
				&& i == ChangedAvatar.CharacterIllustType)
			{
				SelectedItemWidget = ItemWidget;
				ItemWidget->SetChecked(true);
			}
			else
			{
				ItemWidget->SetChecked(false);
			}

			ItemWidget->OnItemClickedDelegate.BindUObject(this, &UChangeAvatarPopupWidget::OnCharacterSelected, ItemWidget, Info.Type, i);
		}
	}
}

void UChangeAvatarPopupWidget::SetFrameList()
{
	SelectedItemWidget = nullptr;

	const TMap<FAvatarFrameType, FAvatarFrame>& AvatarFrames = GetHUDStore().GetAvatarManager().GetAvatarFrames();

	ItemListWidget->ClearList();

	// Add frame removal

	UAvatarItemWidget* RemovalItemWidget = AddRemovalItem(ChangedAvatar.FrameType);
	RemovalItemWidget->OnItemClickedDelegate.BindUObject(this, &UChangeAvatarPopupWidget::OnFrameSelected, RemovalItemWidget, AvatarFrameTypeInvalid);

	// Add frame list

	for (const auto& Elem : AvatarFrames)
	{
		const FAvatarFrameType FrameType = Elem.Key;
		UAvatarItemWidget* ItemWidget = CastChecked<UAvatarItemWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetFrame(FrameType);
		if (FrameType == ChangedAvatar.FrameType)
		{
			SelectedItemWidget = ItemWidget;
			ItemWidget->SetChecked(true);
		}
		else
		{
			ItemWidget->SetChecked(false);
		}

		ItemWidget->OnItemClickedDelegate.BindUObject(this, &UChangeAvatarPopupWidget::OnFrameSelected, ItemWidget, FrameType);
	}
}

void UChangeAvatarPopupWidget::SetEffectList()
{
	SelectedItemWidget = nullptr;

	const TMap<FAvatarEffectType, FAvatarEffect>& AvatarEffects = GetHUDStore().GetAvatarManager().GetAvatarEffects();

	ItemListWidget->ClearList();

	// Add effect removal

	UAvatarItemWidget* RemovalItemWidget = AddRemovalItem(ChangedAvatar.EffectType);
	RemovalItemWidget->OnItemClickedDelegate.BindUObject(this, &UChangeAvatarPopupWidget::OnEffectSelected, RemovalItemWidget, AvatarEffectTypeInvalid);

	// Add effect list

	for (const auto& Elem : AvatarEffects)
	{
		const FAvatarEffectType EffectType = Elem.Key;
		UAvatarItemWidget* ItemWidget = CastChecked<UAvatarItemWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemWidget->SetEffect(EffectType);
		if (EffectType == ChangedAvatar.EffectType)
		{
			SelectedItemWidget = ItemWidget;
			ItemWidget->SetChecked(true);
		}
		else
		{
			ItemWidget->SetChecked(false);
		}

		ItemWidget->OnItemClickedDelegate.BindUObject(this, &UChangeAvatarPopupWidget::OnEffectSelected, ItemWidget, EffectType);
	}
}

UAvatarItemWidget* UChangeAvatarPopupWidget::AddRemovalItem(int32 CurrentType)
{
	UAvatarItemWidget* RemovalItemWidget = CastChecked<UAvatarItemWidget>(ItemListWidget->AddChildAtLastIndex());
	RemovalItemWidget->SetEmpty();
	if (CurrentType == ITEM_TYPE_INVALID)
	{
		SelectedItemWidget = RemovalItemWidget;
		RemovalItemWidget->SetChecked(true);
	}
	else
	{
		RemovalItemWidget->SetChecked(false);
	}

	return RemovalItemWidget;
}

void UChangeAvatarPopupWidget::OnCharacterSelected(UAvatarItemWidget* ItemWidget, FCharacterType InCharacterType, int32 InIllustIndex)
{
	OnItemSelected(ItemWidget);

	ChangedAvatar.CharacterType = InCharacterType;
	ChangedAvatar.CharacterIllustType = InIllustIndex;
	AvatarIconWidget->SetCharacter(InCharacterType, InIllustIndex);
}

void UChangeAvatarPopupWidget::OnFrameSelected(UAvatarItemWidget* ItemWidget, FAvatarFrameType InFrameType)
{
	OnItemSelected(ItemWidget);

	ChangedAvatar.FrameType = InFrameType;
	AvatarIconWidget->SetFrame(InFrameType);
}

void UChangeAvatarPopupWidget::OnEffectSelected(UAvatarItemWidget* ItemWidget, FAvatarEffectType InEffectType)
{
	OnItemSelected(ItemWidget);

	ChangedAvatar.EffectType = InEffectType;
	AvatarIconWidget->SetEffect(InEffectType);
}

void UChangeAvatarPopupWidget::OnItemSelected(UAvatarItemWidget* ItemWidget)
{
	if (SelectedItemWidget)
	{
		SelectedItemWidget->SetChecked(false);
	}

	ItemWidget->SetChecked(true);
	SelectedItemWidget = ItemWidget;
}

///////////////////////////////////////////////////////////////////////////////////////////
// Account
UAccountWidget::UAccountWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UAccountWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconBadgeImage = CastChecked<UImage>(GetWidgetFromName("IconBadge"));
	CheckInDaysText = CastChecked<URichTextBlock>(GetWidgetFromName("CheckInDays"));
	AkaText = CastChecked<URichTextBlock>(GetWidgetFromName("Aka"));
	NicknameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Nickname"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	XpText = CastChecked<UTextBlock>(GetWidgetFromName("Xp"));
	XpBar = CastChecked<UProgressBar>(GetWidgetFromName("BarXp"));
	PlayerIDText = CastChecked<UTextBlock>(GetWidgetFromName("PlayerID"));
	AvatarWidget = CastChecked<UAvatarIconWidget>(GetWidgetFromName("Avatar"));

	PointWidgets.Reset();
	UPointNameWidget* PointWidget = CastChecked<UPointNameWidget>(GetWidgetFromName("Gem"));
	PointWidget->OnSelectedDelegate.BindUObject(this, &UAccountWidget::OpenGemConfirmPopup);
	PointWidgets.Add(PointWidget);

	PointWidgets.Add(CastChecked<UPointNameWidget>(GetWidgetFromName("Gold")));
	PointWidgets.Add(CastChecked<UPointNameWidget>(GetWidgetFromName("SummonTicket")));
	PointWidgets.Add(CastChecked<UPointNameWidget>(GetWidgetFromName("Sculpture")));
	PointWidgets.Add(CastChecked<UPointNameWidget>(GetWidgetFromName("Relic")));
	PointWidgets.Add(CastChecked<UPointNameWidget>(GetWidgetFromName("Friendship")));

	UQ6Button* PlayRecordButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnPlayRecord"));
	PlayRecordButton->OnClickedDelegate.BindUObject(this, &UAccountWidget::OnPlayRecordButtonClicked);

	UQ6Button* ChangeCharacterButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnChangeCharacter"));
	ChangeCharacterButton->OnClickedDelegate.BindUObject(this, &UAccountWidget::OnChangeCharacterButtonClicked);

	UQ6Button* ChangeAkaButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnChangeAka"));
	ChangeAkaButton->OnClickedDelegate.BindUObject(this, &UAccountWidget::OnChangeAkaButtonClicked);

	UQ6Button* ChangeNickNameButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnChangeNickName"));
	ChangeNickNameButton->OnClickedDelegate.BindUObject(this, &UAccountWidget::OnChangeNicknameButtonClicked);

	UQ6Button* CopyButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnCopy"));
	CopyButton->OnClickedDelegate.BindUObject(this, &UAccountWidget::OnCopyButtonClicked);

	UQ6Button* LogoutButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnLogout"));
	LogoutButton->OnClickedDelegate.BindUObject(this, &UAccountWidget::OnLogoutButtonClicked);
}

void UAccountWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	if (InAction->GetActionType() == EHSActionType::UserRecordListResp)
	{
		SetTotalLoginDays();
	}
	else if (InAction->GetActionType() == EHSActionType::UserRenameResp)
	{
		if (ChangeNicknamePopup)
		{
			ChangeNicknamePopup->ClosePopup();
		}

		auto Action = ACTION_PARSE_UserRenameResp(InAction);
		auto& Res = Action->GetVal();

		SetNickname(Res.UserName);
		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "NickNameChangedNotify"));
	}
	else if (InAction->GetActionType() == EHSActionType::TitleChangeResp)
	{
		SetTitleInfo();
	}
	else if (InAction->GetActionType() == EHSActionType::AvatarSaveResp)
	{
		const auto& Action = ACTION_PARSE_AvatarSaveResp(InAction);
		const auto& Res = Action->GetVal();

		SetAvatar(Res.AvatarInfo);
	}
}

void UAccountWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::UserRecord);
	SubscribeToStore(EHSType::Title);
	SubscribeToStore(EHSType::Avatar);

	const FString& UserCode = GetHUDStore().GetWorldUser().GetUserCode();
	PlayerIDText->SetText(FText::FromString(UserCode));

	GetHUDStore().GetUserRecordManager().ReqList();
}

void UAccountWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	NicknameText->SetText(FText::FromString(WorldUser.GetNickname()));
	LevelText->SetText(FText::AsNumber(WorldUser.GetLevel()));

	int32 StartXp = WorldUser.GetStartXp();
	int32 EndXp = WorldUser.GetEndXp();

	int32 NeedXp = EndXp - StartXp;
	int32 ChargedXp = EndXp - WorldUser.GetXp();

	XpText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Xp"), FText::AsNumber(ChargedXp), FText::AsNumber(NeedXp)));
	XpBar->SetPercent(WorldUser.GetXpRatio());

	TArray<EPointType> PointTypes = { EPointType::AnyGem, EPointType::Gold, EPointType::SummonTicket,
	EPointType::Sculpture, EPointType::Relic, EPointType::Friendship };
	check(PointWidgets.Num() == PointTypes.Num());

	for (int32 i = 0; i < PointWidgets.Num(); ++i)
	{
		PointWidgets[i]->SetPointType(PointTypes[i], EPointWidgetOption::NONE);
		PointWidgets[i]->SetCurPoint(WorldUser.GetPoint(PointTypes[i]));
		PointWidgets[i]->SetPointName(PointTypes[i]);
	}

	SetTitleInfo();

	const FAvatarInfo& AvatarInfo = GetHUDStore().GetAvatarManager().GetAvatarInfo();
	SetAvatar(AvatarInfo);
}

void UAccountWidget::SetNickname(const FString& NickName)
{
	NicknameText->SetText(FText::FromString(NickName));
}

void UAccountWidget::SetTitleInfo()
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	const FUserTitleType& UserTitleType = WorldUser.GetTitleType();
	const FCMSUserTitleRow& UserTitleRow = GetCMS()->GetUserTitleRowOrDummy(UserTitleType);
	if (UserTitleRow.IsInvalid())
	{
		SetAkaText(FText::GetEmpty());
	}
	else
	{
		SetAkaText(UserTitleRow.DescName);
	}

	const int32 UserTitleScore = GetUser().GetTitleScore();
	const FAkaAssetRow* AkaAssetRowByIndex = GetGameResource().GetAkaAssetRowByPoint(UserTitleScore);
	if (ensure(AkaAssetRowByIndex))
	{
		SetBadgeIcon(AkaAssetRowByIndex->Icon);
	}
}

void UAccountWidget::SetAkaText(const FText& Text)
{
	if (Text.IsEmpty())
	{
		AkaText->SetText(Q6Util::GetLocalizedText("Lobby", "AkaUnused"));
	}
	else
	{
		AkaText->SetText(FText::Format(
			Q6Util::GetLocalizedText("Lobby", "AkaUsed"), Text));
	}
}

void UAccountWidget::SetBadgeIcon(const FSlateBrush& Icon)
{
	IconBadgeImage->SetBrush(Icon);
}

void UAccountWidget::SetTotalLoginDays()
{
	const FUserRecordInfo* RecordInfo = GetHUDStore().GetUserRecordManager().Find(TotalCheckInDaysUserRecordType);
	if (!RecordInfo)
	{
		Q6JsonLogRoze(Error, "UAccountWidget::SetTotalLoginDays - Invalid total login days user record type",
			Q6KV("UserRecordType", TotalCheckInDaysUserRecordType.x));
		return;
	}

	CheckInDaysText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Days"), FText::AsNumber(RecordInfo->Val)));
}

void UAccountWidget::SetAvatar(const FAvatarInfo& AvatarInfo)
{
	AvatarWidget->SetCharacter(AvatarInfo.CharacterType, AvatarInfo.CharacterIllustType);
	AvatarWidget->SetFrame(AvatarInfo.FrameType);
	AvatarWidget->SetEffect(AvatarInfo.EffectType);
}

void UAccountWidget::OpenChangeNicknamePopup()
{
	ChangeNicknamePopup = CastChecked<UChangeNicknamePopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(ChangeNicknamePopupClass));

	const FString& UserName = GetHUDStore().GetWorldUser().GetNickname();
	ChangeNicknamePopup->InitNickname(UserName);
}

void UAccountWidget::OpenChangeAkaPopup()
{
	UChangeAkaPopupWidget* ChangeAkaPopup = CastChecked<UChangeAkaPopupWidget>(
		GetCheckedLobbyHUD(this)->OpenPopup(ChangeAkaPopupClass));
	ChangeAkaPopup->InitAka();
}

void UAccountWidget::OpenChangeAvatarPopup()
{
	UChangeAvatarPopupWidget* ChangeAvatarPopup = CastChecked<UChangeAvatarPopupWidget>(
		GetCheckedLobbyHUD(this)->OpenPopup(ChangeAvatarPopupClass));
	ChangeAvatarPopup->InitAvatar();
}

void UAccountWidget::OpenGemConfirmPopup()
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	UPointConfirmPopupWidget* ConfirmPopup = CastChecked<UPointConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(PointConfirmPopupClass));
	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
	ConfirmPopup->SetGem(WorldUser.GetFreeGem(), WorldUser.GetPaidGem());
}

void UAccountWidget::OnPlayRecordButtonClicked()
{
	GetCheckedLobbyHUD(this)->OpenPlayRecordPopup();
}

void UAccountWidget::OnChangeCharacterButtonClicked()
{
	OpenChangeAvatarPopup();
}

void UAccountWidget::OnChangeAkaButtonClicked()
{
	OpenChangeAkaPopup();
}

void UAccountWidget::OnChangeNicknameButtonClicked()
{
	OpenChangeNicknamePopup();
}

void UAccountWidget::OnCopyButtonClicked()
{
	const FString& UserCode = GetHUDStore().GetWorldUser().GetUserCode();
	FPlatformApplicationMisc::ClipboardCopy(*UserCode);

	GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "CopyNotify"));
}

void UAccountWidget::OnLogoutButtonClicked()
{
	FText TitleText = Q6Util::GetLocalizedText("Popup", "LogoutConfirmTitle");
	FText ContentText = Q6Util::GetLocalizedText("Popup", "LogoutConfirmContent");

	UConfirmPopupWidget* ConfirmPopup = GetCheckedLobbyHUD(this)->OpenConfirmPopup(TitleText, ContentText);
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UAccountWidget::OnLogoutConfirmed);
}

void UAccountWidget::OnLogoutConfirmed(EConfirmPopupFlag Flag)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	UQ6GameInstance* GameInstance = CastChecked<UQ6GameInstance>(GetGameInstance());
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.BackToLoginLevel();
}
