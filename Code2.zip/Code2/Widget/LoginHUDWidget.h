// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseWidget.h"
#include "Network/Q6ClientNetwork.h"
#include "LoginHUDWidget.generated.h"

/**
 *
 */
UCLASS()
class Q6_API ULoginHUDWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	ULoginHUDWidget(const FObjectInitializer& ObjectInitializer);

	void NativeConstruct() override;

	void SetDefaultVisibility();

private:
	static const FString DefaultPassword;

	UFUNCTION()
	void OnClearButtonClicked();

	UFUNCTION()
	void OnSubmitClicked();

	UPROPERTY()
	UEditableTextBox* IDTextBox;

	UPROPERTY()
	UEditableTextBox* PWTextBox;

	UPROPERTY()
	UButton* SubmitButton;
};
