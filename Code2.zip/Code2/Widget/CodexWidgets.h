#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

#include "CodexWidgets.generated.h"

class UItemBigCardWidget;
class UToggleButtonBoxWidget;

UCLASS()
class Q6_API UCodexWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UCodexWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnEnterMenu() override;
	virtual void OnLeaveMenu() override;
	virtual void RefreshMenu() override;
	virtual bool OnBack() override;

protected:
	UFUNCTION(BlueprintNativeEvent)
	void SetEquipFullView(bool bInFullView);
	void SetEquipFullView_Implementation(bool bInFullView);

private:

	UFUNCTION()
	void OnUIClear();

	UFUNCTION()
	void OnEquipCardClicked();

	void OnCategoryChanged(int32 InChangedIndex);

	void RefreshList(ECodexCategory CodexCategory);

	void SelectDefaultItem();
	void SelectItem(int32 InSelectedIndex);
	void SetNewMarks();

	void SetCharacterList();
	void SetSculptureList();
	void SetRelicList();

	UCodexCharacterIconWidget* FindOrAddCharacterIcon(int32 SlotIndex);
	UCodexEquipIconWidget* FindOrAddEquipIcon(int32 SlotIndex);

	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

	// Widgets

	UPROPERTY()
	UGridPanel* ItemListPanel;

	UPROPERTY()
	UToggleButtonBoxWidget* CategoryBox;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* NatureImage;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UItemBigCardWidget* EquipCardWidget;

	UPROPERTY()
	UScrollBox* ItemScrollBox;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCodexCharacterIconWidget> CharacterIconClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCodexEquipIconWidget> EquipIconClass;

	UPROPERTY()
	TArray<UCodexCharacterIconWidget*> CharacterIconWidgets;

	UPROPERTY()
	TArray<UCodexEquipIconWidget*> EquipIconWidgets;

	ECodexCategory CurCodexCategory;
	UCodexIconWidget* SelectedIconWidget;
};

UCLASS()
class UCodexIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetNewMarkVisible(bool bInNew);

	UFUNCTION(BlueprintImplementableEvent)
	void SetOwned(bool bInOwned);

	UFUNCTION(BlueprintImplementableEvent)
	void SetSelected(bool bInSelected);

	const FItemIconInfo& GetItemInfo() { return ItemIconInfo; }

	FSimpleDelegate OnIconClickedDelegate;

protected:
	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* NewImage;

	FItemIconInfo ItemIconInfo;
};

UCLASS()
class Q6_API UCodexCharacterIconWidget : public UCodexIconWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacterInfo(const FCMSCharacterRow& InCharacterRow);

private:
	void SetCharacterItemInfo(const FCMSCharacterRow& InCharacterRow);

	UPROPERTY()
	UImage* NatureImage;
};

UCLASS()
class Q6_API UCodexEquipIconWidget : public UCodexIconWidget
{
	GENERATED_BODY()

public:
	void SetSculptureInfo(const FCMSSculptureRow& InSculptureRow);
	void SetRelicInfo(const FCMSRelicRow& InRelicRow);

private:
	void SetSculptureItemInfo(const FCMSSculptureRow& InSculptureRow);
	void SetRelicItemInfo(const FCMSRelicRow& InRelicRow);
};
