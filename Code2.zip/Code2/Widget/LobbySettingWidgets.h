// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CombatCube/Q6GameState.h"
#include "Widget/LobbyHUDWidget.h"
#include "LobbyObj_gen.h"
#include "LobbySettingWidgets.generated.h"

class UDynamicListWidget;

DECLARE_DELEGATE_TwoParams(FLobbyTemplateSettingDelegate, FLobbyTemplateId, FLobbyTemplateType);
DECLARE_DELEGATE_ThreeParams(FCharacterSettingDelegate, FCharacterId, int32, int32);

UCLASS()
class Q6_API ULobbyCharacterIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	ULobbyCharacterIconWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetIndex(int32 InIndex) { Index = InIndex; }

	void SetEmpty();

	void SetCharacter(UItemCardWidget* InWidget, bool bSwapping = false);
	void SetCharacter(const FCharacterId InCharacterId, bool bSwapping = false);
	void SetCharacter(const FCharacterType InCharacterType);

	void SetSelected(bool bInSelected) const;

	UItemCardWidget* GetCharacterCardWidget() const { return CharacterCardWidget; }

	FIntParamDelegate OnSlotClickedDelegate;

private:
	UFUNCTION()
	void OnSlotClicked();

private:
	UPROPERTY()
	UImage* CharIconImage;

	UPROPERTY()
	UCanvasPanel* SelectedPanel;

	UPROPERTY(Transient)
	UItemCardWidget* CharacterCardWidget;

	int32 Index;
	FCharacterId CharacterId;
};

UCLASS()
class Q6_API ULobbyTemplateIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	ULobbyTemplateIconWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	FLobbyTemplateId GetTemplateId() const { return TemplateId; }
	FLobbyTemplateType GetTemplateType() const { return TemplateType; }
	void SetTemplate(FLobbyTemplateId InTemplateId, FLobbyTemplateType InTemplateType);

	void SetSelected(bool bInSelected) const;

	FLobbyTemplateSettingDelegate OnTemplateClickedDelegate;

private:
	UFUNCTION()
	void OnTemplateClicked();

private:
	UPROPERTY()
	UImage* TemplateIconImage;

	UPROPERTY()
	UImage* SwipeableImage;

	UPROPERTY()
	TArray<UImage*> SlotImages;

	UPROPERTY()
	UImage* SelectedImage;

	UPROPERTY()
	UCanvasPanel* DisabledPanel;

	FLobbyTemplateId TemplateId;
	FLobbyTemplateType TemplateType;
};

UCLASS()
class Q6_API ULobbySettingEditTemplateWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	ULobbySettingEditTemplateWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void InitTemplateList(FLobbyTemplateId InTemplateId);
	void SetSelectedTemplate(FLobbyTemplateId InTemplateId, FLobbyTemplateType InTemplateType);

	FLobbyTemplateSettingDelegate OnTemplateChangedDelegate;
	FSimpleDelegate OnClearCharacterDelegate;

private:
	void InitTemplateCharacterList();

	UFUNCTION()
	void OnNextButtonClicked();

private:
	UPROPERTY(Transient)
	UWidgetAnimation* TemplateOwnedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TemplateNotOwnedAnim;

	UPROPERTY()
	UTextBlock* TemplateNameText;

	UPROPERTY()
	UTextBlock* TemplateDescText;

	UPROPERTY()
	UTextBlock* TemplateOriginDescText;

	UPROPERTY()
	UHorizontalBox* TemplateAnyCharacterBox;

	UPROPERTY()
	UDynamicListWidget* TemplateCharacterListWidget;

	UPROPERTY()
	UDynamicListWidget* TemplateListWidget;

	FLobbyTemplateId SelectedTemplateId;
	FLobbyTemplateType SelectedTemplateType;
};

UCLASS()
class Q6_API ULobbySettingEditCharacterWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	ULobbySettingEditCharacterWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void Init(const FLobbySetInfo& InLobbySetInfo, int32 InSelectedSlotIndex);

	FIntParamDelegate OnCharacterSlotClickedDelegate;
	FCharacterSettingDelegate OnCharacterSettingDelegate;
	FSimpleDelegate OnApplyLobbySettingDelegate;

private:
	void InitCharacterSlots(const FLobbySetInfo& InLobbySetInfo, int32 InSelectedSlotIndex);
	void InitCharacterList(const FLobbySetInfo& InLobbySetInfo);

	void InitTemplateSlotExclusiveInfo(FLobbyTemplateId InTemplateId);
	void InitOwnedCharacters();
	void InitNotOwnedCharacters();

	bool IsTemplatePlaceable(FCharacterType CharacterType) const;
	bool IsTemplateSlotPlaceable(int32 SlotIndex, FCharacterType CharacterType) const;

	void AddCharacterRemovalCard();
	void AddCharacterCards(const TArray<FCharacterId>& InCharacterIds, bool bIncluded);

	void SetNewSelectedCharacterCardWidget(UItemCardWidget* InWidget);

	void OnCharacterSlotClicked(int32 SlotIndex);
	void OnCharacterRemovalCardClicked(UItemCardWidget* InWidget);
	void OnCharacterCardClicked(UItemCardWidget* InWidget);

	UFUNCTION()
	void OnApplyButtonClicked();

private:
	UPROPERTY()
	UTextBlock* TemplateNameText;

	UPROPERTY()
	TArray<ULobbyCharacterIconWidget*> SlotWidgets;

	UPROPERTY()
	UDynamicListWidget* CharacterListWidget;

	UPROPERTY(Transient)
	UItemCardWidget* SelectedCharacterCardWidget;

	TArray<TArray<int32>> TemplateSlotExclusiveCharacterTypes;
	TArray<FCharacterInfo> TemplateIncludedCharacterInfos;
	TArray<FCharacterInfo> TemplateExcludedCharacterInfos;

	int32 SelectedSlotIndex;
	int32 SlotCount;
};

UCLASS()
class Q6_API ULobbySetListEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	ULobbySetListEntryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	int32 GetLobbySetId() const { return LobbySetId; }

	void SetIndex(int32 InIndex) { Index = InIndex; }
	void SetLobbySetInfo(const FLobbySetInfo& InInfo);
	void SetInUse(bool bInInUse);
	void SetSelected(bool bInSelected);

	FIntParamDelegate OnLobbySetSelectedDelegate;

private:
	UFUNCTION()
	void OnLobbySetSelected();

private:
	UPROPERTY(Transient)
	UWidgetAnimation* SelectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DeselectedAnim;
	
	UPROPERTY()
	UTextBlock* LobbySetIdText;

	UPROPERTY()
	UTextBlock* TemplateNameText;

	UPROPERTY()
	UBorder* InUseBox;

	UPROPERTY()
	ULobbyTemplateIconWidget* TemplateIconWidget;

	UPROPERTY()
	TArray<ULobbyCharacterIconWidget*> CharacterSlotWidgets;

	int32 Index;
	int32 LobbySetId;
};

UCLASS()
class Q6_API ULobbySetListPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	ULobbySetListPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetLobbySetList();

	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Flag) override;

private:
	void OnLobbySetSelected(int32 InLobbySetIndex);

	UPROPERTY()
	TArray<ULobbySetListEntryWidget*> LobbySetSlotWidgets;

	int32 SelectedLobbySetIndex;
};

/**
 * Lobby Setting HUD Widget
 */
UCLASS()
class Q6_API ULobbySettingWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()
	
public:
	ULobbySettingWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::LobbySetting; }

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void LoadLobbySetting();
	void SaveLobbySetting();

	void SetLobbySetState(int32 InLobbySetId, const FText& InName);
	void SetLobbySetEditting();

	void SetLobbySettingMenu(ELobbySettingEditType InLobbySettingEditType);
	void SetLobbySettingMain();

	UFUNCTION()
	void OnClearButtonClicked();

	UFUNCTION()
	void OnLobbySetListButtonClicked();

	UFUNCTION()
	void OnEditTemplateButtonClicked();
	void OnCharacterSlotClicked(int32 InSlotIndex);

	void OnTemplateChanged(FLobbyTemplateId InTemplateId, FLobbyTemplateType InTemplateType);

	void OnClearCharacterSetting();
	void OnCharacterSetting(FCharacterId InCharacterId, int32 InSlotIndex, int32 InSlotCount);

	void OnEditCharacterSlotClicked(int32 InSlotIndex);

private:
	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<ULobbySetListPopupWidget> LobbySetListPopupWidgetClass;

	UPROPERTY()
	UButton* LobbySetListButton;

	UPROPERTY()
	UTextBlock* LobbySetIdText;

	UPROPERTY()
	UTextBlock* LobbySetStateText;

	UPROPERTY()
	UImage* LobbySetEditImage;

	UPROPERTY()
	TArray<ULobbyCharacterIconWidget*> SlotWidgets;

	UPROPERTY()
	UWidgetSwitcher* EditSwitcher;

	UPROPERTY()
	UCanvasPanel* MainPanel;

	UPROPERTY()
	ULobbySettingEditTemplateWidget* EditTemplateWidget;

	UPROPERTY()
	ULobbySettingEditCharacterWidget* EditCharacterWidget;

	FLobbySetInfo CurLobbySetInfo;
	bool bResetTemplate;
	bool bResetCharacters;

	int32 SelectedCharacterSlotIndex;
};
