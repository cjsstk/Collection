// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"

#include "PopupWidgets.h"
#include "Unit.h"
#include "CombatDetailWidgets.generated.h"

class UQ6Button;
class URichTextBlock;
class UToggleButtonBoxWidget;
class UBuffIconWidget;

UCLASS()
class Q6_API UCombatDetailStatWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	void SetValues(int32 InConstValue, int32 InVaryValue);

private:
	UPROPERTY(EditInstanceOnly)
	FText Name;

	UPROPERTY()
	UTextBlock* ValueText;

	UPROPERTY()
	UTextBlock* ConditionalValueText;
};

UCLASS()
class Q6_API UCombatDetailConditionStateWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	// For combat

	void SetMomentCondition(EMoment Moment, FSkillType MomentSkillType, const FBuffState& BuffState);
	void SetUnitAttributeCondition(const FCMSBuffEffectRow* BuffEffectRow, const FBuffState& BuffState);
	void SetCrowdControlCondition(const FCMSCrowdControlRow& CrowdControlRow, const FCMSBuffEffectRow* BuffEffectRow, const FBuffState& BuffState);
	void SetPointVaryUnitAttributeCondition(const FPointVaryUnitAttributeState& InAttributeState);

	// For lobby

	void SetMomentSkill(const FCMSBuffRow& BuffRow, FSkillType MomentSkillType);
	void SetBuffEffect(const FCMSBuffRow& BuffRow, const FCMSBuffEffectRow& BuffEffectRow);

private:
	void SetConditionInternal(int32 HitCount, bool bInfinity, int32 Duration);

	UPROPERTY()
	UBuffIconWidget* BuffIconWidget;

	UPROPERTY()
	URichTextBlock* EffectText;

	UPROPERTY()
	URichTextBlock* HitCountText;

	UPROPERTY()
	URichTextBlock* TurnCountText;
};

UCLASS()
class Q6_API UCombatDetailConditionWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	void SetMonsterInfo(int32 MonsterSlot, int32 MonsterNumSlots, FText Name);
	void SetConditions(const TArray<FBuffState>& BuffStates, const TArray<FPointVaryUnitAttributeState>& UnitAttributes);

private:
	UPROPERTY(EditInstanceOnly)
	ECCFaction Faction;

	UPROPERTY()
	UDynamicListWidget* ConditionListWidget;
};

UCLASS()
class Q6_API UCombatDetailPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void Init(FCCUnitId InUnitId);

private:
	void SetMonstersInfo();

	void SetCharacterInfo(int32 InIndex);
	void SetCharacterSkillInfo(const FUnitState& State);

	int32 GetFirstAliveCharacterIndex() const;

	void OnCharacterSelected(int32 InIndex);

	UFUNCTION()
	void OnCharacterButtonClicked();

	UFUNCTION()
	void OnMonsterButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* SetCharacterAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetMonsterAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillEnabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillDisabledAnim;

	UPROPERTY()
	UToggleButtonBoxWidget* CharacterSelectBox;

	// character panel
	UPROPERTY()
	UTextBlock* CharacterNameText;

	UPROPERTY()
	UImage* JokerImage;

	UPROPERTY()
	UTextBlock* UltSkillLevelText;

	UPROPERTY()
	UTextBlock* UltSkillNameText;

	UPROPERTY()
	URichTextBlock* UltSkillDescText;

	UPROPERTY()
	UImage* UltSkillIcon;

	UPROPERTY()
	UTextBlock* SupportSkillLevelText;

	UPROPERTY()
	UTextBlock* SupportSkillNameText;

	UPROPERTY()
	URichTextBlock* SupportSkillDescText;

	UPROPERTY()
	UImage* SupportSkillIcon;

	UPROPERTY()
	UCombatDetailStatWidget* HPStatWidget;

	UPROPERTY()
	UCombatDetailStatWidget* ATKStatWidget;

	UPROPERTY()
	UCombatDetailStatWidget* DEFStatWidget;

	UPROPERTY()
	UTextBlock* SculptureNameText;

	UPROPERTY()
	URichTextBlock* SculptureDescText;

	UPROPERTY()
	UTextBlock* RelicNameText;

	UPROPERTY()
	URichTextBlock* RelicDescText;

	UPROPERTY()
	UCombatDetailConditionWidget* CharacterConditionWidget;

	// monster panel
	UPROPERTY()
	TArray<UCombatDetailConditionWidget*> MonsterConditionWidgets;

	TArray<AUnit*> AllyUnits;
	TArray<AUnit*> EnemyUnits;
};
