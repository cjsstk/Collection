// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "BaseWidget.h"
#include "SagaWidgets.h"
#include "EpisodeWidgets.generated.h"

class UQ6SnapScrollBox;

enum class ESagaTab : uint8;

UCLASS()
class UEpisodeIconWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UEpisodeIconWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void Init(int32 InEpisode, EEpisodeState InState);
	void OnSelected(bool bSelected);

	int32 GetEpisode() const { return Episode; }
	EEpisodeState GetState() const { return State; }

	FEpisodeIconDelegate ClickedDelegate;

private:
	void SetTagImage(ENewMarkType NewMarkType);

	UFUNCTION()
	void OnSelectButtonClicked();

	// Widget Animations

	UPROPERTY(Transient)
	UWidgetAnimation* IconSelectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* IconUnSelectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ClearAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* InProgressAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ComingSoonAnim;

	UPROPERTY()
	UButton* SelectButton;

	UPROPERTY()
	UImage* EpisodeIconImage;

	UPROPERTY()
	UTextBlock* EpisodeNumText;

	UPROPERTY()
	UImage* TagImage;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush NewTagBrush;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush ClearTagBrush;

	int32 Episode;
	EEpisodeState State;
};

UCLASS()
class UEpisodePartWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UEpisodePartWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void Init(int32 InPart);

	UEpisodeIconWidget* FindOrAddIconWidget(int32 IconIdx, const FMargin& InPadding);

private:

	// Widget classes.
	UPROPERTY(EditInstanceOnly, Category = "Episode")
	TSubclassOf<UEpisodeIconWidget> EpisodeIconClass;

	// Widgets.
	UPROPERTY()
	UHorizontalBox* EpisodeList;

	UPROPERTY()
	UBorder* PartBorder;

	UPROPERTY()
	UTextBlock* PartText;
};

UCLASS()
class UEpisodeListWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UEpisodeListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void InitEpisodeList();

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Q6")
	float LastSlotPadding;

	FIntParamDelegate EpisodeSelectedDelegate;

public:
	UFUNCTION()
	void OnIconClicked(UEpisodeIconWidget* NewSelectIcon);

	UFUNCTION()
	void OnSnapTrackingFired();

	UFUNCTION()
	void OnDescendantScrolled();

private:
	UEpisodePartWidget* FindOrAddPartWidget(int32 Index);

 	void ScrollToSnap();
	void ScrollToIcon(UEpisodeIconWidget* IconWidget);

	void OnIconSelected(UEpisodeIconWidget* NewSelectIcon);
	void OnEpisodeSelected(int32 Episode);

	UPROPERTY(Transient)
	UWidgetAnimation* SetOpenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetLockAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ComingSoonAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetClearAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetSelectedAnim;

	// Widget classes.
	UPROPERTY(EditInstanceOnly, Category = "Episode")
	TSubclassOf<UEpisodePartWidget> EpisodePartClass;

	// Widgets.
	UPROPERTY()
	UHorizontalBox* EpisodePartList;

	UPROPERTY()
	UBorder* EpisodeBorder;

	UPROPERTY()
	UTextBlock* PartText;

	UPROPERTY()
	UTextBlock* EpisodeStoryText;

	UPROPERTY()
	UTextBlock* EpisodeNumText;

	UPROPERTY()
	UTextBlock* EpisodeTitleText;

	UPROPERTY()
	UTextBlock* ShouldClearText;

	UPROPERTY()
	UQ6SnapScrollBox* ScrollBox;

	UPROPERTY()
	UImage* SelectBoxImage;

	UPROPERTY(Transient)
	TArray<UEpisodeIconWidget*> IconWidgets;

	UPROPERTY(Transient)
	UEpisodeIconWidget* SelectedIcon;

	UPROPERTY(Transient)
	UEpisodeIconWidget* ScrollTargetIcon;
};
