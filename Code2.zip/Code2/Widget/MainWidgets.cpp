// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "MainWidgets.h"
#include "CheckInManager.h"
#include "CharacterManager.h"
#include "ContentFeatureOpenManager.h"
#include "LevelUtil.h"
#include "LobbyHUD.h"
#include "LobbyPlayerController.h"
#include "Misc/StringFormatter.h"
#include "Q6.h"
#include "Q6SaveGame.h"
#include "Q6GameInstance.h"
#include "Q6UIDefine.h"
#include "RaidManager.h"
#include "WidgetUtil.h"
#include "SagaManager.h"
#include "SwipeWidgets.h"
#include "SystemConst_gen.h"
#include "EventWidgets.h"
#include "HUDStore/EventManager.h"
#include "DailyDungeonManager.h"
#include "NewMarkManager.h"
#include "TrainingCenterManager.h"
#include "Tutorial/LobbyTutorial.h"
#include "CMSTable.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Main"), STAT_OnHSEventByMain, STATGROUP_HSTORE);

// Gunny tempcode
static const int32 NUM_OF_EVENT_PAGE = 5;

UMainWidget::UMainWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bWaitRefresh(false)
{
}

void UMainWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* ClearButton = CastChecked<UButton>(GetWidgetFromName("Clear"));
	ClearButton->OnClicked.AddUniqueDynamic(this, &UMainWidget::OnClearButtonClicked);

	UButton* LobbySettingButton = Cast<UButton>(GetWidgetFromName("LobbySetting"));
	LobbySettingButton->OnClicked.AddUniqueDynamic(this, &UMainWidget::OnLobbySettingButtonClicked);

	UButton* SpecialStageButton = CastChecked<UButton>(GetWidgetFromName("SpecialStage"));
	SpecialStageButton->OnClicked.AddUniqueDynamic(this, &UMainWidget::OnSpecialStageButtonClicked);

	UButton* SagaButton = CastChecked<UButton>(GetWidgetFromName("Saga"));
	SagaButton->OnClicked.AddUniqueDynamic(this, &UMainWidget::OnSagaButtonClicked);

	UButton* DailyDungeonButton = CastChecked<UButton>(GetWidgetFromName("DailyDungeon"));
	DailyDungeonButton->OnClicked.AddUniqueDynamic(this, &UMainWidget::OnDailyDungeonButtonClicked);

	UButton* TrainingCenterButton = CastChecked<UButton>(GetWidgetFromName("TrainingCenter"));
	TrainingCenterButton->OnClicked.AddUniqueDynamic(this, &UMainWidget::OnTrainingCenterButtonClicked);

	UButton* RaidButton = CastChecked<UButton>(GetWidgetFromName("Raid"));
	RaidButton->OnClicked.AddUniqueDynamic(this, &UMainWidget::OnRaidButtonClicked);

	EpisodeText = CastChecked<UTextBlock>(GetWidgetFromName("Episode"));
	EpisodePreviewImage = CastChecked<UImage>(GetWidgetFromName("EpisodePreview"));

	SagaNewMarkImage = CastChecked<UImage>(GetWidgetFromName("SagaNewMark"));
	SpecialNewMarkImage = CastChecked<UImage>(GetWidgetFromName("SpecialNewMark"));
	RaidNewMarkImage = CastChecked<UImage>(GetWidgetFromName("RaidNewMark"));
	TrainingCenterNewMarkImage = CastChecked<UImage>(GetWidgetFromName("TrainingCenterNewMark"));

	RegularRaidMarkBorder = CastChecked<UBorder>(GetWidgetFromName("RegularMark"));

	EventSwipeWidget = CastChecked<UPageSwipeWidget>(GetWidgetFromName("EventSwipe"));
	EventSwipeWidget->OnSetPageDelegate.BindUObject(this, &UMainWidget::OnSetEventWidget);

	const TMap<FEventContentType, FEventContentInfo>& Events = GetHUDStore().GetEventManager().GetEvents();
	int32 PageIndex = 1;
	for (const auto& Iter : Events)
	{
		EventPageMap.Add(PageIndex, Iter.Key);
		PageIndex++;
	}
	EventSwipeWidget->SetPageCount(Events.Num(), 1);
}

void UMainWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::CheckIn);
	SubscribeToStore(EHSType::DailyDungeon);
	SubscribeToStore(EHSType::TrainingCenter);
	SubscribeToStore(EHSType::NewMark);
	SubscribeToStore(EHSType::Raid);
	SubscribeToStore(EHSType::ContentFeatureOpen);

	const int32 PlayingEpisode = GetHUDStore().GetSagaManager().GetPlayingEpisode();
	const FEpisodeAssetRow& EpisodeAssetRow = GetGameResource().GetEpisodeAssetRow(PlayingEpisode);
	EpisodePreviewImage->SetBrush(EpisodeAssetRow.PreviewIcon);

	FString EpisodeStr = Q6Util::GetLocalizedText("Lobby", "Episode").ToString();
	EpisodeStr += FString::Printf(TEXT(" %d"), PlayingEpisode);
	EpisodeText->SetText(FText::FromString(EpisodeStr));

	ALobbyTutorial* InLobbyTutorial = GetLobbyTutorial(this);
	if (!InLobbyTutorial || InLobbyTutorial->IsCheckInOpened())
	{
		GetHUDStore().GetCheckInManager().ReqRewardReceive();
	}

	ACTION_DISPATCH_UpdateRaidWhenEnterMenu();
}

void UMainWidget::OnLeaveMenu()
{
	GetCheckedLobbyHUD(this)->StopMainWidgetsAnimations();

	Super::OnLeaveMenu();
}

void UMainWidget::RefreshMenu()
{
	Super::RefreshMenu();

	SetNewMarks();
	SetContentState();
}

void UMainWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByMain);

	switch (Action->GetActionType())
	{
		case EHSActionType::FriendshipCollectResp:
		{
			GetCheckedLobbyHUD(this)->OpenFriendshipCollectPopup();
		}
		break;
		case EHSActionType::CheckInRewardReceiveResp:
		case EHSActionType::DevCheckInLoadResp:
		{
			const UCheckInManager& CheckInMgr = GetHUDStore().GetCheckInManager();
			if (CheckInMgr.HasNewCheckInBoard())
			{
				FCheckInBoardType FirstBoardType = CheckInMgr.GetFirstBoardPage();
				const FCheckInAssetRow& CheckInAssetRow = GetGameResource().GetCheckInAssetRow(FirstBoardType);
				GetCheckedLobbyHUD(this)->OpenCheckInPopup(FirstBoardType, CheckInAssetRow);
			}
			else
			{
				ACTION_DISPATCH_FriendshipCollect();
			}
		}
		break;
		case EHSActionType::ContentsResetTime:
		case EHSActionType::RaidCanEnterNof:
		case EHSActionType::RaidFullNof:
		case EHSActionType::RaidKickTimeoutNof:
		{
			SetNewMarks();
		}
		break;
		case EHSActionType::DailyListResp:
		{
			if (bWaitRefresh)
			{
				bWaitRefresh = false;
				GetCheckedLobbyHUD(this)->OpenDailyDungeon();
			}
		}
		break;
		case EHSActionType::TrainingCenterLoadResp:
		{
			if (bWaitRefresh)
			{
				bWaitRefresh = false;
				GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::TrainingCenter);
			}
		}
		break;
		case EHSActionType::DevContentFeatureOpenResp:
		case EHSActionType::DevStageClearResp:
		{
			SetContentState();
		}
		break;
		case EHSActionType::UpdateRaidWhenEnterMenu:
		{
			const FRaidType RegularRaidType = GetHUDStore().GetRaidManager().GetRegularRaidType();
			if (RegularRaidType != RaidTypeInvalid)
			{
				RegularRaidMarkBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			}
			else
			{
				RegularRaidMarkBorder->SetVisibility(ESlateVisibility::Collapsed);
			}
		}
		break;
	}
}

void UMainWidget::SetNewMarks()
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();

	ENewMarkType SagaNewMarkType = NewMarkMgr.GetMainSagaType();
	SetNewMark(SagaNewMarkImage, SagaNewMarkType);

	ESlateVisibility TrainingCenterNewMarkVisibility = NewMarkMgr.GetMainTrainingCenterVisibility();
	TrainingCenterNewMarkImage->SetVisibility(TrainingCenterNewMarkVisibility);

	ESlateVisibility SpecialNewMarkVisibility = NewMarkMgr.GetMainSpecialVisibility();
	SpecialNewMarkImage->SetVisibility(SpecialNewMarkVisibility);

	ESlateVisibility RaidNewMarkVisibility = NewMarkMgr.GetMainRaidVisibility();
	RaidNewMarkImage->SetVisibility(RaidNewMarkVisibility);
}

void UMainWidget::SetContentState()
{
	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();

	SetMainWidgetContentState(EMainWidgetContentType::TrainingCenter
		, !ContentFeatureOpenManager.IsOpenContentFeature(EFeatureOpenType::TrainingCenter));

	SetMainWidgetContentState(EMainWidgetContentType::DailyDungeon
		, !ContentFeatureOpenManager.IsOpenContentFeature(EFeatureOpenType::DailyDungeon));

	FSagaType LastSagaType = GetHUDStore().GetSagaManager().GetLastSagaType();
	SetMainWidgetContentState(EMainWidgetContentType::Raid
		, LastSagaType < SystemConst::Q6_RAID_CERTIFICATE_SAGA);
}

void UMainWidget::OnClearButtonClicked()
{
	GetCheckedLobbyHUD(this)->SetClearUI(true);
}

void UMainWidget::OnLobbySettingButtonClicked()
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::LobbySetting);
}

void UMainWidget::OnSpecialStageButtonClicked()
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Special);
}

void UMainWidget::OnSagaButtonClicked()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("Saga");
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Saga);
}

void UMainWidget::OnDailyDungeonButtonClicked()
{
	EFeatureOpenType FeatureOpenType(EFeatureOpenType::DailyDungeon);

	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();
	bool bEnable = ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType);
	if (!bEnable)
	{
		GetBaseHUD(this)->ShowNotOpenedYetNotification(FeatureOpenType);
		return;
	}

	const UDailyDungeonManager& DailyMgr = GetHUDStore().GetDailyDungeonManager();
	int32 ExpireTime = DailyMgr.GetHistory(DailyMgr.GetDayOfWeekType()).ExpireTime;
	if (ExpireTime <= FDateTime::UtcNow().ToUnixTimestamp())
	{
		bWaitRefresh = true;
		DailyMgr.ReqDailyList(false);
	}
	else
	{
		GetCheckedLobbyHUD(this)->OpenDailyDungeon();
	}
}

void UMainWidget::OnTrainingCenterButtonClicked()
{
	EFeatureOpenType FeatureOpenType(EFeatureOpenType::TrainingCenter);

	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();
	bool bEnable = ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType);
	if (!bEnable)
	{
		GetBaseHUD(this)->ShowNotOpenedYetNotification(FeatureOpenType);
		return;
	}

	const UTrainingCenterManager& TrainingCenterMgr = GetHUDStore().GetTrainingCenterManager();
	if (TrainingCenterMgr.IsHistoryExpired())
	{
		bWaitRefresh = true;
		TrainingCenterMgr.ReqTrainingCenterHistory(false);
	}
	else
	{
		GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::TrainingCenter);
	}
}

void UMainWidget::OnRaidButtonClicked()
{
	const FSagaType LastSagaType = GetHUDStore().GetSagaManager().GetLastSagaType();
	if (LastSagaType < SystemConst::Q6_RAID_CERTIFICATE_SAGA)
	{
		GetBaseHUD(this)->ShowNotOpenedYetNotification(FSagaType(SystemConst::Q6_RAID_CERTIFICATE_SAGA));
		return;
	}

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Raid);
}

void UMainWidget::OnSetEventWidget(UWidget* Widget, int32 PageNum)
{
	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FEventContentType* EventContentType = EventPageMap.Find(PageNum);
	if (!EventContentType)
	{
		Q6JsonLogGunny(Warning, "UMainWidget::OnSetEventWidget - EventContenType does not exist.");
		return;
	}

	const FEventContentInfo* EventContentInfo = EventManager.GetEvent(*EventContentType);
	if (!EventContentInfo)
	{
		Q6JsonLogGunny(Warning, "UMainWidget::OnSetEventWidget - EventContentInfo does not exist.");
		return;
	}

	UEventPageWidget* EventPageWidget = CastChecked<UEventPageWidget>(Widget);
	EventPageWidget->SetPage(EventContentInfo->Type);
}
