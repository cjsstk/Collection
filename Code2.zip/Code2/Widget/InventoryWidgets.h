// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "LobbyHUDWidget.h"
#include "Q6LobbyState.h"
#include "Q6Define.h"
#include "InventoryWidgets.generated.h"

class UItemDetailWidget;
class UDynamicListWidget;
class UItemCardWidget;
class UItemSelectActionWidget;
class USortingWidget;
class UToggleButtonBoxWidget;
class UQ6Button;
class UQuickMenuButtonWidget;

struct FLobbyUIState;

UCLASS()
class Q6_API UInventoryWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UInventoryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual bool OnBack() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const;

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

	void SetInventory(EInventoryCategory InCategory, EInventoryType InvenType);

	void SetCollection();
	void SetStorageBox();

	void SetChararcterList(ESortMenu SortMenu, bool bStashed);
	void SetRelicList(ESortMenu SortMenu, bool bStashed);
	void SetSculptureList(ESortMenu SortMenu, bool bStashed);

	void SetSelectableCard(UItemCardWidget* ItemCard);

	void SetInventoryCount(ESortMenu SortMenu, int32 SourceCount, int32 TargetCount);
	void SetSelectedCount();

	void OnSelectedItemCard(UItemCardWidget* ItemCard);
	void OnCategoryChanged(int32 NewIndex);
	void OnActionModeChanged();

	void OnEditButtonClicked();
	void OnOkButtonClicked();
	void OnQuickMenuButtonClicked();

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	UToggleButtonBoxWidget* CategoryButtonsWidget;

	UPROPERTY()
	USortingWidget* SortingWidget;

	UPROPERTY()
	UQ6TextBlock* TargetTitleText;

	UPROPERTY()
	UQ6TextBlock* SourceTitleText;

	UPROPERTY()
	URichTextBlock* TargetCountText;

	UPROPERTY()
	URichTextBlock* SourceCountText;

	UPROPERTY()
	URichTextBlock* SelectedCountText;

	UPROPERTY()
	UTextBlock* EditText;

	UPROPERTY()
	UQ6Button* OkButton;

	UPROPERTY()
	UQuickMenuButtonWidget* QuickMenuButtonWidget;

	UPROPERTY()
	UItemSelectActionWidget* SelectActionWidget;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* StartListAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SwitchEditAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SwitchListAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush CollectionIconBrush;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush StorageBoxIconBrush;

	UPROPERTY(EditDefaultsOnly)
	int32 MaxSelectableCount;

	TArray<UItemCardWidget*> SelectedCardWidgets;
	EInventoryCategory Category;
	EInventoryEdit EditType;
	EInventoryType InventoryType;

	int32 SelectableCount;
};

UCLASS()
class Q6_API UUpgradeInventoryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UUpgradeInventoryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetSelectedCategoryBoxIndex(int32 UpgradeMenuIndex);
	void SetCategoryBoxType(EUpgradeCategory Category);

private:
	void SetCharacterList(EUpgradeCharacterCategory UpCategory);
	void SetRelicList(EUpgradeEquipCategory UpCategory);
	void SetSculptureList(EUpgradeEquipCategory UpCategory);
	void SetSkillList(EUpgradeSkillCategory UpgradeSkillCategory);

	const FText& GetCharacterUpgradedMaxText(EUpgradeCharacterCategory UpCategory) const;
	const FText& GetCharacterUpgradeEnabledText(EUpgradeCharacterCategory UpCategory) const;
	const FText& GetCharacterUpgradeDisabledText(EUpgradeCharacterCategory UpCategory) const;

	void OnItemSelected(UItemCardWidget* ItemCard);

	void OnUpgradeCategoryChanged(int32 ChangedIndex);

	UPROPERTY(EditDefaultsOnly, Category = "Upgrade")
	TArray<FText> CharacterUpgradedMaxTexts;

	UPROPERTY(EditDefaultsOnly, Category = "Upgrade")
	TArray<FText> CharacterUpgradeEnabledTexts;

	UPROPERTY(EditDefaultsOnly, Category = "Upgrade")
	TArray<FText> CharacterUpgradeDisabledTexts;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	USortingWidget* SortingWidget;

	UPROPERTY()
	UToggleButtonBoxWidget* CategoryBoxWidget;
};
