// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "SpecialWidgets.h"

#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HUD/BaseHUD.h"
#include "HUDStore/CharacterManager.h"
#include "HUDStore/SagaManager.h"
#include "HUDStore/BondManager.h"
#include "HUDStore/NewMarkManager.h"
#include "HUDStore/SpecialManager.h"
#include "HUDStore/CharMissionManager.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "LobbyPlayerController.h"
#include "StageWidgets.h"
#include "Q6.h"
#include "Q6Log.h"
#include "WidgetUtil.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Special"), STAT_OnHSEventBySpecial, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Special Stage Menu Widget
//////////////////////////////////////////////////////////////////////////
void USpecialMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Animations

	MenuAnims.Reset();
	MenuAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimCharacter"));
	MenuAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBoss"));
	MenuAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimWonder"));

	// Widgets

	MenuButton = CastChecked<UQ6Button>(GetWidgetFromName("Menu"));
	MenuButton->OnClicked.AddUniqueDynamic(this, &USpecialMenuWidget::OnMenuButtonClicked);

	TagImage = CastChecked<UImage>(GetWidgetFromName("Tag"));
}

void USpecialMenuWidget::SetSpecialStageMenu(ESpecialCategory InCategory)
{
	Category = InCategory;

	if (MenuAnims.IsValidIndex(((int32) Category) - 1))
	{
		PlayAnimation(MenuAnims[((int32)Category) - 1]);	// 1-base to 0-base
	}

	ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetSpecialCategoryVisibility(Category);
	TagImage->SetVisibility(NewMarkVisibility);

	switch (Category)
	{
		case ESpecialCategory::Saga:
		case ESpecialCategory::Wonder:
		{
			SetSpecialMenuWidgetContentState(
				!GetHUDStore().GetSpecialManager().HasOpenedStage(Category));
		}
		break;
	}
}

void USpecialMenuWidget::OnMenuButtonClicked()
{
	switch (Category)
	{
		case ESpecialCategory::Saga:
		case ESpecialCategory::Wonder:
		{
			bool bHasOpenedStage = GetHUDStore().GetSpecialManager().HasOpenedStage(Category);
			if (!bHasOpenedStage)
			{
				GetBaseHUD(this)->ShowNotOpenedYetNotification(Category);
				return;
			}
		}
		break;
	}

	OnMenuClickedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////
// Special Stage Entry Widget
//////////////////////////////////////////////////////////////////////////
void USpecialEpisodeEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &USpecialEpisodeEntryWidget::OnSelectButtonClicked);

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	TagImage = CastChecked<UImage>(GetWidgetFromName("Tag"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
}

void USpecialEpisodeEntryWidget::SetCharacterEpisode(const FCMSSpecialRow& SpecialRow)
{
	FCharacterType CharacterType = FCharacterType(SpecialRow.ConditionId);

	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(CharacterType);
	NameText->SetText(UnitRow.DescName);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());

	ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetSpecialCharacterVisibility(CharacterType);
	TagImage->SetVisibility(NewMarkVisibility);
}

void USpecialEpisodeEntryWidget::SetWonderEpisode(EWonderCategory WonderCategory)
{
	FString WonderStr = FString::Printf(TEXT("Wonder%s"), *ENUM_TO_STRING(EWonderCategory, WonderCategory));
	NameText->SetText(Q6Util::GetLocalizedText("Lobby", *WonderStr));

	const FSlateBrush& WonderBrush = GetUIResource().GetWonderIcon(WonderCategory);
	IconImage->SetBrush(WonderBrush);

	ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetSpecialWonderCategoryVisibility(WonderCategory);
	TagImage->SetVisibility(NewMarkVisibility);
}

void USpecialEpisodeEntryWidget::OnSelectButtonClicked()
{
	OnEpisodeSelectedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////
// Special Stage List Widget
//////////////////////////////////////////////////////////////////////////
void USpecialStageListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Animations

	CharacterBannerAnim = GetWidgetAnimationFromName(this, "AnimCharacterBanner");
	check(CharacterBannerAnim);

	SagaBannerAnim = GetWidgetAnimationFromName(this, "AnimSagaBanner");
	check(SagaBannerAnim);

	WonderBannerAnim = GetWidgetAnimationFromName(this, "AnimWonderBanner");
	check(WonderBannerAnim);

	// Widgets

	EpisodeReward = CastChecked<UItemWidget>(GetWidgetFromName("EpisodeClearReward"));
	EpisodeReward->SetVisibility(ESlateVisibility::Collapsed);
	BannerImage = CastChecked<UImage>(GetWidgetFromName("Banner"));
	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("Title"));
	DescriptionText = CastChecked<UTextBlock>(GetWidgetFromName("Description"));
	StageListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("StageList"));
}

void USpecialStageListWidget::SetSpecialStage(ESpecialCategory Category)
{
	const FSpecialUIState& UIState = GetHUDStore().GetUIStateManager().GetSpecialStageUIState();

	EpisodeReward->SetVisibility(ESlateVisibility::Collapsed);

	switch (Category)
	{
	case ESpecialCategory::Character:
		SetCharacterStage(UIState.SpecialType);
		break;
	case ESpecialCategory::Saga:
		SetBossStage();
		break;
	case ESpecialCategory::Wonder:
		SetWonderStage(UIState.Wonder);
		break;
	}
}

void USpecialStageListWidget::SetBossStage()
{
	const UCMS* CMS = GetCMS();

	// Set banner image
	BannerImage->SetBrush(SpecialEpisodeBannerBrush);
	BannerImage->SetBrushSize(SpecialEpisodeBannerBrush.GetImageSize());
	PlayAnimation(SagaBannerAnim);

	// Set banner text

	TitleText->SetText(Q6Util::GetLocalizedText(TEXT("Lobby"), "SpecialBoss"));
	DescriptionText->SetText(Q6Util::GetLocalizedText(TEXT("Lobby"), "SpecialBossDescription"));

	// Set list

	StageListWidget->ClearList();

	TArray<FSpecialRecord> History = GetHUDStore().GetSpecialManager().GetFilteredHistory(ESpecialCategory::Saga);
	for (int32 i = History.Num() - 1; i >= 0; --i)
	{
		// Set stage entry
		FSpecialRecord& SpecialRecord = History[i];

		const FCMSSpecialRow* SpecialRow = GetCMS()->GetSpecialRow(ESpecialCategory::Saga, SpecialRecord.Episode);
		check(SpecialRow);

		AddToStageList(SpecialRecord.Stages, SpecialRow->Episode, SpecialRow->ReplayLimit, ESpecialCategory::Saga);
	}
}

void USpecialStageListWidget::SetCharacterStage(const FSpecialType& SpecialType)
{
	const UCMS* CMS = GetCMS();
	const FCMSSpecialRow& SpecialRow = CMS->GetSpecialRowOrDummy(SpecialType);

	FCharacterType CharacterType = FCharacterType(SpecialRow.ConditionId);
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterType);
	const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);

	// Episode clear

	const FCMSLootDataRow& LootDataRow = CMS->GetEpisodeClearRewardByEpisode(SpecialRow.Episode);
	if (!LootDataRow.IsInvalid())
	{
		EpisodeReward->SetRewardType(ERewardType::EpisodeClearReward);
		EpisodeReward->SetLoot(LootDataRow.LootId, LootDataRow.Count);
		EpisodeReward->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		EpisodeReward->SetChecked(GetHUDStore().GetSpecialManager().IsClearedSpecial(SpecialType));
	}

	// Set banner image

	BannerImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.BodyTexture);
	PlayAnimation(CharacterBannerAnim);

	// Set banner text

	TitleText->SetText(UnitRow.DescName);
	DescriptionText->SetText(SpecialRow.Desc);

	// Set stage list

	TArray<FSpecialStage> SpecialStages = GetHUDStore().GetSpecialManager().GetSpecialStages(SpecialRow.Episode);
	StageListWidget->ClearList();
	AddToStageList(SpecialStages, SpecialRow.Episode, SpecialRow.ReplayLimit, ESpecialCategory::Character);
}

void USpecialStageListWidget::SetWonderStage(EWonderCategory WonderCategory)
{
	FString TutorialParams = FString::Printf(TEXT("OnSpecialWonder%sEnter"), *ENUM_TO_STRING(EWonderCategory, WonderCategory));
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialParams);

	const UCMS* CMS = GetCMS();

	// Set banner image

	const FSlateBrush& WonderBrush = GetUIResource().GetWonderBG(WonderCategory);
	BannerImage->SetBrush(WonderBrush);
	PlayAnimation(WonderBannerAnim);

	// Set banner text

	FString WonderStr = ENUM_TO_STRING(EWonderCategory, WonderCategory);
	TitleText->SetText(Q6Util::GetLocalizedText("Lobby", *(TEXT("Wonder") + WonderStr)));

	FString WonderInfoStr = FString::Printf(TEXT("SpecialStage%sInfo"), *WonderStr);
	DescriptionText->SetText(Q6Util::GetLocalizedText("Lobby", *WonderInfoStr));

	// Set stage list

	TArray<FSpecialRecord> SpecialHistory = GetHUDStore().GetSpecialManager().GetWonderHistory(WonderCategory);
	StageListWidget->ClearList();

	TArray<FWonderStageInfo> WonderStageInfos;
	for (FSpecialRecord& SpecialRecord : SpecialHistory)
	{
		if (const FCMSSpecialRow* SpecialRow = CMS->GetSpecialRow(SpecialRecord.ConditionType, SpecialRecord.Episode))
		{
			AddToWonderStageInfos(
				SpecialRecord.Stages,
				SpecialRow->Episode,
				SpecialRow->ReplayLimit,
				SpecialRow->ConditionType,
				WonderStageInfos);
		}
	}

	WonderStageInfos.Sort([](const FWonderStageInfo& L, const FWonderStageInfo& R)
		{
			if (L.StageState == R.StageState)
			{
				return L.SagaType > R.SagaType;
			}
			else
			{
				return static_cast<int>(L.StageState) < static_cast<int>(R.StageState);
			}
		}
	);

	for (const FWonderStageInfo& Iter : WonderStageInfos)
	{
		AddToWonderStageList(Iter);
	}
}

void USpecialStageListWidget::AddToWonderStageInfos(
	TArray<FSpecialStage>& SpecialStages,
	int32 Episode,
	int32 ReplayLimit,
	ESpecialCategory SpecialCategory,
	TArray<FWonderStageInfo>& OutWonderStageInfos)
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	int32 StageNum = CMS->GetNumStageRows(EContentType::Special, Episode);
	if (SpecialStages.Num() < StageNum)
	{
		// Open Next stage
		FSpecialStage FirstStage;
		FirstStage.Stage = SpecialStages.Num() + 1;
		FirstStage.ClearCount = 0;

		SpecialStages.Add(FirstStage);
	}

	for (int32 i = SpecialStages.Num() - 1; i >= 0; --i)
	{
		FSagaType SagaType = CMS->FindSagaType(Episode, SpecialStages[i].Stage, 0);
		EStageState StageState = GetStageState(SpecialStages[i], ReplayLimit, GetHUDStore().IsSpecialStageOpened(SagaType));
		OutWonderStageInfos.Add(
			FWonderStageInfo(SagaType, SpecialCategory, StageState, SpecialStages[i].ClearCount, ReplayLimit));
	}
}

void USpecialStageListWidget::AddToWonderStageList(const FWonderStageInfo& InSpecialStageInfo)
{
	UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
	EntryWidget->SetSpecialEntryWidget(InSpecialStageInfo.SagaType, InSpecialStageInfo.StageState, InSpecialStageInfo.SpecialCategory);
	EntryWidget->SetHasLinkedStage(false);
	EntryWidget->SetClearCountVisible(true);
	EntryWidget->SetClearCount(InSpecialStageInfo.ClearCount, InSpecialStageInfo.ReplayLimit);
}

void USpecialStageListWidget::AddToStageList(TArray<FSpecialStage>& SpecialStages, int32 Episode, int32 ReplayLimit, ESpecialCategory SpecialCategory)
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	int32 StageNum = CMS->GetNumStageRows(EContentType::Special, Episode);
	if (SpecialStages.Num() < StageNum)
	{
		// Open Next stage

		FSpecialStage FirstStage;
		FirstStage.Stage = SpecialStages.Num() + 1;
		FirstStage.ClearCount = 0;

		SpecialStages.Add(FirstStage);
	}

	for (int32 i = SpecialStages.Num() - 1; i >= 0; --i)
	{
		FSagaType SagaType = CMS->FindSagaType(Episode, SpecialStages[i].Stage, 0);
		EStageState StageState = GetStageState(SpecialStages[i], ReplayLimit, GetHUDStore().IsSpecialStageOpened(SagaType));

		UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
		EntryWidget->SetSpecialEntryWidget(SagaType, StageState, SpecialCategory);
		EntryWidget->SetHasLinkedStage(i > 0);
		EntryWidget->SetClearCountVisible(true);
		EntryWidget->SetClearCount(SpecialStages[i].ClearCount, ReplayLimit);
	}
}

EStageState USpecialStageListWidget::GetStageState(const FSpecialStage& SpecialStage, int32 ReplayLimit, bool bOpen)
{
	if (!bOpen)
	{
		return EStageState::LockedByStage;
	}

	if (SpecialStage.ClearCount == 0)
	{
		return EStageState::New;
	}

	if (ReplayLimit == 0)
	{
		return EStageState::Normal;
	}

	if (SpecialStage.ClearCount >= ReplayLimit)
	{
		return EStageState::Clear;
	}

	return EStageState::Normal;
}


//////////////////////////////////////////////////////////////////////////
// Special Stage Widget
//////////////////////////////////////////////////////////////////////////
void USpecialWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("Menu"));

	MenuWidgets.Reset();
	USpecialMenuWidget* MenuWidget;
	MenuWidget = CastChecked<USpecialMenuWidget>(GetWidgetFromName("Character"));
	MenuWidget->OnMenuClickedDelegate.BindUObject(this, &USpecialWidget::OnSpecialMenuClicked, ESpecialCategory::Character);
	MenuWidgets.AddUnique(MenuWidget);

	MenuWidget = CastChecked<USpecialMenuWidget>(GetWidgetFromName("Boss"));
	MenuWidget->OnMenuClickedDelegate.BindUObject(this, &USpecialWidget::OnSpecialMenuClicked, ESpecialCategory::Saga);
	MenuWidgets.AddUnique(MenuWidget);

	MenuWidget = CastChecked<USpecialMenuWidget>(GetWidgetFromName("Wonder"));
	MenuWidget->OnMenuClickedDelegate.BindUObject(this, &USpecialWidget::OnSpecialMenuClicked, ESpecialCategory::Wonder);
	MenuWidgets.AddUnique(MenuWidget);

	EpisodeListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("EpisodeList"));
	StageListWidget = CastChecked<USpecialStageListWidget>(GetWidgetFromName("StageList"));
}

void USpecialWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::WorldUser);
}

void USpecialWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FSpecialUIState* UIState = GetUIState()->CastToSpecialUIState();
	check(UIState);

	MenuSwitcher->SetActiveWidgetIndex((int32)UIState->MenuType);

	switch (UIState->MenuType)
	{
		case ESpecialStageMenuType::Main:
			SetSpecialMenu();
			break;

		case ESpecialStageMenuType::EpisodeList:
			SetEpisode(UIState->Category);
			break;

		case ESpecialStageMenuType::StageList:
			StageListWidget->SetSpecialStage(UIState->Category);
			break;
	}
}

void USpecialWidget::SetSpecialMenu()
{
	for (int32 i = 0; i < MenuWidgets.Num(); ++i)
	{
		MenuWidgets[i]->SetSpecialStageMenu(ESpecialCategory(i + 1));	// SpecialCategory is 1-base
	}
}

void USpecialWidget::SetEpisode(ESpecialCategory Category)
{
	switch (Category)
	{
		case ESpecialCategory::Character:
			SetCharacterEpisodeList();
			break;
		case ESpecialCategory::Wonder:
			SetWonderEpisodeList();
			break;
	}
}

void USpecialWidget::SetCharacterEpisodeList()
{
	EpisodeListWidget->ClearList();

	UCMS* CMS = GetCMS();
	const TArray<FSpecialRecord>& SpecialRecords = GetHUDStore().GetSpecialManager().GetHistory();

	for (const FSpecialRecord& SpecialRecord : SpecialRecords)
	{
		const FCMSSpecialRow* SpecialRow = CMS->GetSpecialRow(ESpecialCategory::Character, SpecialRecord.Episode);
		if (!SpecialRow)
		{
			continue;
		}

		USpecialEpisodeEntryWidget* EpisodeEntryWidget = CastChecked<USpecialEpisodeEntryWidget>(EpisodeListWidget->AddChildAtLastIndex());
		EpisodeEntryWidget->SetIsEnabled(true);
		EpisodeEntryWidget->SetCharacterEpisode(*SpecialRow);
		EpisodeEntryWidget->OnEpisodeSelectedDelegate.BindUObject(this, &USpecialWidget::OnCharacterEpisodeSelected, SpecialRow->CmsType());
	}
}

void USpecialWidget::SetWonderEpisodeList()
{
	EpisodeListWidget->ClearList();

	TArray<EWonderCategory> Categories = GetGameResource().GetSpecialWonderStageLineup();
	if(Categories.Num() + 1 != EWonderCategoryMax)
	{
		Q6JsonLogGenie(Warning, "Fill Out SpecialWonderStageLineupAsset"
			, Q6KV("Size", Categories.Num()));
	}

	const USpecialManager& SpecialMgr = GetHUDStore().GetSpecialManager();
	for (const EWonderCategory Category : Categories)
	{
		USpecialEpisodeEntryWidget* EpisodeEntryWidget = CastChecked<USpecialEpisodeEntryWidget>(EpisodeListWidget->AddChildAtLastIndex());
		EpisodeEntryWidget->SetIsEnabled(SpecialMgr.HasOpenedWonderStage(Category));
		EpisodeEntryWidget->SetWonderEpisode(Category);
		EpisodeEntryWidget->OnEpisodeSelectedDelegate.BindUObject(this, &USpecialWidget::OnWonderEpisodeSelected, Category);
	}
}

void USpecialWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventBySpecial);

	switch (Action->GetActionType())
	{
		case EHSActionType::SpecialOpen:
		case EHSActionType::SpecialEpisodeList:
		case EHSActionType::SpecialCharacterStageList:
		case EHSActionType::SpecialSagaStageList:
		case EHSActionType::SpecialWonderStageList:
			RefreshMenu();
			break;
	}
}

void USpecialWidget::OnSpecialMenuClicked(ESpecialCategory Category)
{
	switch (Category)
	{
		case ESpecialCategory::Character:
		case ESpecialCategory::Wonder:
			ACTION_DISPATCH_SpecialEpisodeList(Category);
			break;

		case ESpecialCategory::Saga:
			ACTION_DISPATCH_SpecialSagaStageList();
			break;
		//Roze-TODO: Event stage
	}
}

void USpecialWidget::OnCharacterEpisodeSelected(FSpecialType SpecialType)
{
	ACTION_DISPATCH_SpecialCharacterStageList(SpecialType);
}

void USpecialWidget::OnWonderEpisodeSelected(EWonderCategory WonderCategory)
{
	ACTION_DISPATCH_SpecialWonderStageList(WonderCategory);
}
