// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "PopupWidgets.h"
#include "WonderWidgets.h"

#include "PowerPlantWidgets.generated.h"

class UPointWidget;
class UQ6TextBlock;

UCLASS()
class Q6_API UWattStoreConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetWattStore(int32 InStoreCount);

private:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option) override;

	UPROPERTY()
	UPointWidget* OwnedWattWidget;

	UPROPERTY()
	UPointWidget* OwnedGoldWidget;

	UPROPERTY()
	UPointWidget* RequiredWattWidget;

	UPROPERTY()
	UPointWidget* RequiredGoldWidget;

	UPROPERTY()
	UQ6TextBlock* StoreWattText;

	int32 StoreCount;
};

UCLASS()
class Q6_API UPowerPlantWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) override;
	virtual void SetWonder() override;
	virtual void RefreshUI() override;

private:
	void RefreshStoreWater(const FPowerPlantInfo& PowerPlant, const FCMSPowerPlantRow& PowerPlantRow);
	void PlayStoreAnimation();

	UFUNCTION()
	void OnPlusButtonClicked();

	UFUNCTION()
	void OnMinusButtonClicked();

	UFUNCTION()
	void OnStoreButtonClicked();

	UPROPERTY()
	UProgressBar* ResultBar;

	UPROPERTY()
	UProgressBar* StoredBar;

	UPROPERTY()
	UQ6TextBlock* StoredWaterText;

	UPROPERTY()
	UQ6TextBlock* MaxWaterText;

	UPROPERTY()
	UBorder* StoreBorder;

	UPROPERTY()
	UQ6TextBlock* ResultWaterText;

	UPROPERTY()
	UButton* PlusButton;

	UPROPERTY()
	UButton* MinusButton;

	UPROPERTY()
	UQ6TextBlock* StoreWattText;

	UPROPERTY()
	UQ6TextBlock* InfoText;

	UPROPERTY()
	UPointWidget* OwnedWattWidget;

	UPROPERTY()
	UPointWidget* OwnedGoldWidget;

	UPROPERTY()
	UPointWidget* RequiredWattWidget;

	UPROPERTY()
	UPointWidget* RequiredGoldWidget;

	UPROPERTY()
	UButton* StoreButton;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UWattStoreConfirmPopupWidget> WattStoreConfirmPopupClass;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor StorableColor;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor StoredColor;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor StoredMaxColor;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor LackColor;

	UPROPERTY(EditDefaultsOnly)
	float TopOffsetFromResultBar;

	int32 StoreCount;
};
