// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "LobbyHUDWidget.h"
#include "UMG.h"

#include "AccountWidgets.generated.h"

class UDynamicListWidget;
class UPointNameWidget;
class UToggleButtonBoxWidget;
class UQ6Button;

///////////////////////////////////////////////////////////////////////////////////////////
// Aka

UCLASS()
class Q6_API UGetAkaConfirmPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UGetAkaConfirmPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void InitGetAkaConfirmPopup(const FUserTitleType& Type);

private:
	void SetAkaText(const FText& Text);
	void SetContentText(const FText& Text);
	void SetReputationBadgeText(const FText& Text);

	UFUNCTION()
	void OnDismiss();

	UFUNCTION()
	void OnYesButtonClicked();

	UPROPERTY()
	UTextBlock* AkaText;

	UPROPERTY()
	URichTextBlock* ContentText;

	UPROPERTY()
	URichTextBlock* GetReputationBadgeText;
};

UCLASS()
class Q6_API UReputationGradeWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UReputationGradeWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void InitReputationGrade(const int32 Index);

private:
	void SetReputationGradeText(const FText& Text);
	void SetReputationPointText(const FText& Text);

	void SetBadgeIcon(const FSlateBrush& Icon);

	UPROPERTY(Transient)
	UWidgetAnimation* SetCurrentAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetOrderAnim;

	UPROPERTY()
	UImage* IconBadgeImage;

	UPROPERTY()
	UTextBlock* ReputationGradeText;

	UPROPERTY()
	UTextBlock* ReputationPointText;
};

UCLASS()
class Q6_API UReputationPointInfoPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UReputationPointInfoPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void InitReputationPointInfo();

private:
	void SetReputationPointText(const FText& Text);
	void SetReputationGradeText(const FText& Text);

	void SetBadgeIcon(const FSlateBrush& Icon);

	UPROPERTY()
	URichTextBlock* OwnedReputationPointText;

	UPROPERTY()
	UTextBlock* ReputationGradeText;

	UPROPERTY()
	UImage* IconBadgeImage;
};

UCLASS()
class Q6_API UAkaListEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UAkaListEntryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetAkaListInfo(const FCMSUserTitleRow* Row, bool bSelectable, bool bUsed);
	void PlayAkaListEntryAnimation(const EAkaListAnimType Type);

	FSimpleDelegate OnSelectButtonClickedDelegate;

private:
	void SetAkaText(const FText& AkaText);
	void SetNotYetRichText(const FText& NotYetText);
	void SetAddReputationRichText(const FText& AddReputationText);

	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> AkaListAnims;

	UPROPERTY()
	URichTextBlock* AkaText;

	UPROPERTY()
	URichTextBlock* NotYetText;

	UPROPERTY()
	URichTextBlock* AddReputationText;

	UPROPERTY()
	UButton* SelectButton;
};

UCLASS()
class Q6_API UChangeAkaPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	UChangeAkaPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void InitAka();

protected:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option);

private:
	void ResetAkaInfo(const EUserTitleCategory Category);

	void SetAkaList(const TSet<const FCMSUserTitleRow*> OwnedList,
					const TArray<const FCMSUserTitleRow*> AllList);

	void SetAkaText(const FUserTitleType& UserTitleType);
	void SetReputationPointText(const FText& Text);
	void SetReputationGradeText(const FText& Text);
	void SetBadgeIcon(const FSlateBrush& Icon);

	UFUNCTION()
	void OnReputationPointButtonClicked();

	UFUNCTION()
	void OnAkaCategoryChanged(int32 Index);

	UFUNCTION()
	void OnAkaListSelected(FUserTitleType Type, UAkaListEntryWidget* SelectedWidget);

	UPROPERTY()
	UDynamicListWidget* AkaListWidget;

	UPROPERTY()
	URichTextBlock* AkaText;

	UPROPERTY()
	URichTextBlock* OwnedReputationPointText;

	UPROPERTY()
	UTextBlock* ReputationGradeText;

	UPROPERTY()
	UImage* BadgeIconImage;

	UPROPERTY()
	UToggleButtonBoxWidget* CategoryToggleButtonBox;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UReputationPointInfoPopupWidget> ReputationPointInfoPopupClass;

	FUserTitleType CurrSelectedType;
	UAkaListEntryWidget* CurrSelectedWidget;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Nickname

UCLASS()
class Q6_API UChangeNicknamePopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void InitNickname(const FString& UserName);

protected:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option) override;

private:
	UFUNCTION()
	void OnNicknameCommitted(const FText& InText, ETextCommit::Type CommitMethod);

	UFUNCTION()
	void OnNicknameChanged(const FText& InText);

	bool IsValidNicknameLength(const FText& InText);
	bool ValidateNickName();

	UPROPERTY()
	UEditableTextBox* NicknameTextBox;
};

UCLASS()
class Q6_API UPointConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetGem(int32 FreeGemAmount, int32 PaidGemAmount);

private:
	UPROPERTY()
	UPointWidget* PointAWidget;

	UPROPERTY()
	UPointWidget* PointBWidget;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Avatar

UCLASS()
class Q6_API UAvatarItemWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetEmpty();

	void SetCharacter(const FCharacterType CharacterType, int32 Illust);
	void SetFrame(const FAvatarFrameType FrameType);
	void SetEffect(const FAvatarEffectType EffectType);

	void SetChecked(const bool InChecked);

	FSimpleDelegate OnItemClickedDelegate;

private:
	void OnItemClicked();
	void OnItemLongClicked();

	UPROPERTY()
	UImage* ItemImage;

	UPROPERTY(Transient)
	UWidgetAnimation* SelectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NormalAnim;

	EAvatarCategory Category;
	int32 Type;
};

UCLASS()
class Q6_API UAvatarIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacter(const FCharacterType CharacterType, const int32 IllustIndex);
	void SetFrame(const FAvatarFrameType FrameType);
	void SetEffect(const FAvatarEffectType EffectType);
	void SetNewMark(bool bNewly);

private:
	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* FrameImage;

	UPROPERTY()
	UImage* EffectImage;

	UPROPERTY()
	UImage* NewMarkImage;
};

UCLASS()
class Q6_API UChangeAvatarPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option) override;

	void InitAvatar();

private:
	void OnItemCategoryChanged(const int32 InSelectedIndex);

	void SetCharacterList();
	void SetFrameList();
	void SetEffectList();

	UAvatarItemWidget* AddRemovalItem(int32 CurrentType);

	void OnCharacterSelected(UAvatarItemWidget* ItemWidget, FCharacterType InCharacterType, int32 InIllustIndex);
	void OnFrameSelected(UAvatarItemWidget* ItemWidget, FAvatarFrameType InFrameType);
	void OnEffectSelected(UAvatarItemWidget* ItemWidget, FAvatarEffectType InEffectType);

	void OnItemSelected(UAvatarItemWidget* ItemWidget);

	UPROPERTY()
	UAvatarIconWidget* AvatarIconWidget;

	UPROPERTY()
	UToggleButtonBoxWidget* ItemCategoryWidget;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UAvatarItemWidget* SelectedItemWidget;
	EAvatarCategory CurrentCategory;
	FAvatarInfo ChangedAvatar;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Account

UCLASS()
class Q6_API UAccountWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UAccountWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Account; }

private:
	const FUserRecordType TotalCheckInDaysUserRecordType = FUserRecordType(2);

	void OnPlayRecordButtonClicked();
	void OnChangeCharacterButtonClicked();
	void OnChangeAkaButtonClicked();
	void OnChangeNicknameButtonClicked();
	void OnCopyButtonClicked();
	void OnLogoutButtonClicked();
	
	void OnLogoutConfirmed(EConfirmPopupFlag Flag);

	void SetNickname(const FString& NickName);
	void SetTitleInfo();
	void SetAkaText(const FText& Text);
	void SetBadgeIcon(const FSlateBrush& Icon);
	void SetTotalLoginDays();
	void SetAvatar(const FAvatarInfo& AvatarInfo);

	void OpenChangeNicknamePopup();
	void OpenChangeAkaPopup();
	void OpenChangeAvatarPopup();
	void OpenGemConfirmPopup();

	UPROPERTY()
	UImage* IconBadgeImage;

	UPROPERTY()
	URichTextBlock* CheckInDaysText;

	UPROPERTY()
	URichTextBlock* AkaText;

	UPROPERTY()
	UQ6TextBlock* NicknameText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UTextBlock* XpText;

	UPROPERTY()
	UProgressBar* XpBar;

	UPROPERTY()
	UTextBlock* PlayerIDText;

	UPROPERTY()
	UAvatarIconWidget* AvatarWidget;

	UPROPERTY()
	TArray<UPointNameWidget*> PointWidgets;

	UPROPERTY()
	UChangeNicknamePopupWidget* ChangeNicknamePopup;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UChangeNicknamePopupWidget> ChangeNicknamePopupClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UChangeAkaPopupWidget> ChangeAkaPopupClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPointConfirmPopupWidget> PointConfirmPopupClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UChangeAvatarPopupWidget> ChangeAvatarPopupClass;
};
