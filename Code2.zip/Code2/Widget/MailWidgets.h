// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseWidget.h"
#include "CommonWidgets.h"
#include "LobbyMsg_gen.h"
#include "LobbyObj_gen.h"
#include "PopupWidgets.h"

#include "MailWidgets.generated.h"

//////////////////////////////////////////////////////////////////////////
// MailListEntryWidgetBP
//////////////////////////////////////////////////////////////////////////

class UItemWidget;
class UQ6TextBlock;
class UMailRewardWidget;

UENUM(BlueprintType)
enum class EMailEntryType : uint8
{
	Default,
	CheckBox,
	Log,
	Received,
	Selected
};

UENUM()
enum class EMailTabType : uint8
{
	Default = 0,
	Service = 1,
	Log = 2
};

UENUM(BlueprintType)
enum class EMailListPopupType : uint8
{
	AllReceive,
	SelectReceive,
	Log
};

UCLASS()
class Q6_API UMailListEntryWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UMailListEntryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetMail(const FMailInfo& InMailInfo);
	void SetMailLog(const FMailReceiveLog& InMailLog, int32 ReceiveUtc);
	void SetReceivedMail(const FMailInfo& InMailInfo);

	void SetReceiveButtonMode(bool bEnable) { bSelectButtonMode = bEnable; }

	void Uncheck();

	const FMailId& GetMailId() { return MailId; }
	bool IsChecked() { return bChecked; }

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void SetEntryType(EMailEntryType InMailEntryType);

private:
	void SetItem(const FItemData& InItemData);

	UFUNCTION()
	void OnReceiveButtonClicked();

	UFUNCTION()
	void OnToggleButtonClicked(bool bInIsChecked);

	UPROPERTY()
	UButton* ReceiveButton;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UCheckBox* SelectBox;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* DateText;

	UPROPERTY()
	UQ6TextBlock* RewardTypeText;

	FMailId MailId;
	bool bChecked;
	bool bSelectButtonMode;
};

//////////////////////////////////////////////////////////////////////////
// MailRewardWidgetBP (Toast message)
//////////////////////////////////////////////////////////////////////////
UCLASS()
class Q6_API UMailRewardWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UMailRewardWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetRewardInfo(const FMailInfo& MailInfo);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* ShowAnim;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* RewardTypeText;
};

UCLASS()
class Q6_API UMailListPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UMailListPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void Refresh(int32 InIndex = 0);

	// About Tab Menu
	void SetMails(bool bService = false);
	void SetMailLogs();

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void SetMailListPopupType(EMailListPopupType InMailListPopupType);

private:
	int32 GetCheckedMailNum();

	void SetReceivedCount(int32 InNumOfSelect);
	void UncheckAllMail();

	void SetNewMarks();

	void OnMailReceive(bool bSelectedMail);

	void OnTabSelected(int32 InIndex);

	UPROPERTY()
	UTextBlock* SelectedCountText;

	UPROPERTY()
	UQ6TextBlock* ReceivedNumText;

	UPROPERTY()
	UQ6TextBlock* NotReceiveText;

	UPROPERTY()
	UQ6Button* ReceiveAllButton;

	UPROPERTY()
	UToggleButtonBoxWidget* ToggleButtonBoxWidget;

	UPROPERTY()
	UDynamicListWidget* MailListWidget;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UMailRewardWidget> MailRewardWidgetClass;

	UPROPERTY(Transient)
	UMailRewardWidget* MailRewardWidget;

	bool bReceiveButtonClicked;
};

UCLASS()
class Q6_API UMailReceivedPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UMailReceivedPopupWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetMailLists(const TArray<FMailInfo> RewardInfos);

private:
	UPROPERTY()
	UDynamicListWidget* MailListWidget;
};
