// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "CharacterDetailWidgets.h"
#include "CharacterVoiceHelper.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "LobbyPlayerController.h"
#include "MenuUnit.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "Q6SoundPlayer.h"
#include "Q6Util.h"


//////////////////////////////////////////////////////////////////////////////////
// UCharacterProfileListEntryWidget

void UCharacterProfileListEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UnlockedAnim = GetWidgetAnimationFromName(this, "AnimProfileUnlocked");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimProfileLocked");

	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextTitle"));
	ContentText = CastChecked<URichTextBlock>(GetWidgetFromName("TextContent"));
}

void UCharacterProfileListEntryWidget::SetProfile(EProfileCategory InCategory, const FText& InContent, bool bInUnlocked)
{
	TitleText->SetText(Q6Util::GetCharacterProfileText(InCategory));

	ContentText->SetText(InContent);

	if (bInUnlocked)
	{
		ContentText->SetDefaultTextStyle(UnlockedStyle);
		PlayAnimation(UnlockedAnim);
	}
	else
	{
		ContentText->SetDefaultTextStyle(LockedStyle);
		PlayAnimation(LockedAnim);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCharacterStoryListEntryWidget

void UCharacterStoryListEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();
	
	UnlockedAnim = GetWidgetAnimationFromName(this, "AnimStoryUnlocked");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimStoryLocked");

	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextTitle"));
	ContentText = CastChecked<URichTextBlock>(GetWidgetFromName("TextContent"));
}

void UCharacterStoryListEntryWidget::SetStory(const FText& InTitle, const FText& InContent, bool bInUnlocked)
{
	TitleText->SetText(InTitle);
	ContentText->SetText(InContent);

	if (bInUnlocked)
	{
		ContentText->SetDefaultTextStyle(UnlockedStyle);
		PlayAnimation(UnlockedAnim);
	}
	else
	{
		ContentText->SetDefaultTextStyle(LockedStyle);
		PlayAnimation(LockedAnim);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCharacterProfileWidget

void UCharacterProfileWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MenuBoxWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("BtnMenuToggle"));
	MenuBoxWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UCharacterProfileWidget::OnMenuChanged);

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("MenuChange"));
	ProfileListWidget = CastChecked<UVerticalList>(GetWidgetFromName("ProfileList"));
	StoryListWidget = CastChecked<UVerticalList>(GetWidgetFromName("StoryList"));
}

static void _SortElems(TArray<const FCMSCharUnlockElemRow*>& InElems)
{
	InElems.Sort([](const FCMSCharUnlockElemRow& ElemA, const FCMSCharUnlockElemRow& ElemB)
	{
		return (ElemA.Param1 < ElemB.Param1);
	});
}

void UCharacterProfileWidget::SetCharacter(FCharacterType InCharacterType, FText& OutCharacterEtcDesc)
{
	ProfileListWidget->ClearAll();
	StoryListWidget->ClearAll();

	TArray<const FCMSCharUnlockElemRow*> ProfileElems, StoryElems;

	const FCMSCharUnlockElemSetRow* CharUnlockElemSetRow = GetCMS()->GetCharUnlockElemSetRowByCharType(InCharacterType);
	if (CharUnlockElemSetRow)
	{
		const TArray<const FCMSCharUnlockElemRow*>& UnlockElems = CharUnlockElemSetRow->GetUnlockElem();
		for (const FCMSCharUnlockElemRow* UnlockElem : UnlockElems)
		{
			if (!UnlockElem)
			{
				continue;
			}

			if (UnlockElem->Category == ECharUnlockElemCategory::Profile)
			{
				ProfileElems.Add(UnlockElem);
			}
			else if (UnlockElem->Category == ECharUnlockElemCategory::Story)
			{
				StoryElems.Add(UnlockElem);
			}
		}
	}

	_SortElems(ProfileElems);
	for (const FCMSCharUnlockElemRow* Elem : ProfileElems)
	{
		// sunny-to-separate-data-from-unlock-elem-later
		EProfileCategory Category = (EProfileCategory)Elem->Param1;
		if (Category == EProfileCategory::Etc)
		{
			OutCharacterEtcDesc = Elem->Desc;
		}
		else
		{
			AddProfileElem(InCharacterType, Elem);
		}
	}

	_SortElems(StoryElems);
	for (const FCMSCharUnlockElemRow* Elem : StoryElems)
	{
		AddStoryElem(InCharacterType, Elem);
	}

	MenuBoxWidget->SetSelectedIndex(0);
}

void UCharacterProfileWidget::AddProfileElem(FCharacterType InCharacterType, const FCMSCharUnlockElemRow* InElem)
{
	UCharacterProfileListEntryWidget* ProfileWidget = CastChecked<UCharacterProfileListEntryWidget>(ProfileListWidget->AddNewChild());

	EProfileCategory Category = (EProfileCategory)InElem->Param1;
	bool bUnlocked = GetHUDStore().IsUnlockedCharUnlockElem(InCharacterType, InElem);
	const FText& Desc = bUnlocked ? InElem->Desc : InElem->UnlockCondDesc;

	ProfileWidget->SetProfile(Category, Desc, bUnlocked);
}

void UCharacterProfileWidget::AddStoryElem(FCharacterType InCharacterType, const FCMSCharUnlockElemRow* InElem)
{
	UCharacterStoryListEntryWidget* StoryWidget = CastChecked<UCharacterStoryListEntryWidget>(StoryListWidget->AddNewChild());

	const FText& StoryTitle = InElem->Desc;

	bool bUnlocked = GetHUDStore().IsUnlockedCharUnlockElem(InCharacterType, InElem);
	if (bUnlocked)
	{
		FString StoryStringKey = FString::Printf(TEXT("%d-%d"), InCharacterType, InElem->Param1);
		const FText& StoryContent = Q6Util::GetLocalizedText("CharacterStory", StoryStringKey);
		StoryWidget->SetStory(StoryTitle, StoryContent, bUnlocked);
	}
	else
	{
		const FText& StoryContent = InElem->UnlockCondDesc;
		StoryWidget->SetStory(StoryTitle, StoryContent, bUnlocked);
	}
}

void UCharacterProfileWidget::OnMenuChanged(int32 InIndex)
{
	MenuSwitcher->SetActiveWidgetIndex(InIndex);
}

//////////////////////////////////////////////////////////////////////////////////
// UCharacterVoiceListEntryWidget

UCharacterVoiceListEntryWidget::UCharacterVoiceListEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCharacterVoiceListEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UnlockedAnim = GetWidgetAnimationFromName(this, "AnimVoiceUnlocked");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimVoiceLocked");

	SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UCharacterVoiceListEntryWidget::OnVoiceSelected);

	VoiceInfoText = CastChecked<URichTextBlock>(GetWidgetFromName("TextVoiceInfo"));
}

void UCharacterVoiceListEntryWidget::SetVoiceInfo(const FText& InDesc, bool bInUnlocked)
{
	VoiceInfoText->SetText(InDesc);

	if (bInUnlocked)
	{
		VoiceInfoText->SetDefaultTextStyle(UnlockedStyle);
		SelectButton->SetVisibility(ESlateVisibility::Visible);
		PlayAnimation(UnlockedAnim);
	}
	else
	{
		VoiceInfoText->SetDefaultTextStyle(LockedStyle);
		SelectButton->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		PlayAnimation(LockedAnim);
	}
}

void UCharacterVoiceListEntryWidget::OnVoiceSelected()
{
	OnVoiceSelectedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////////////
// UCharacterVoiceListEntryGroupWidget

void UCharacterVoiceListEntryGroupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextTitle"));
	VoiceListBox = CastChecked<UVerticalBox>(GetWidgetFromName("VoiceList"));
}

void UCharacterVoiceListEntryGroupWidget::InitVoiceGroup(const FText& InText)
{
	TitleText->SetText(InText);
	VoiceListBox->ClearChildren();
}

UCharacterVoiceListEntryWidget* UCharacterVoiceListEntryGroupWidget::AddVoiceElem(const FText& InDesc, bool bInUnlocked)
{
	UCharacterVoiceListEntryWidget* VoiceWidget = NewObject<UCharacterVoiceListEntryWidget>(this, VoiceEntryWidgetClass.LoadSynchronous());
	
	UVerticalBoxSlot* ChildSlot = VoiceListBox->AddChildToVerticalBox(VoiceWidget);
	ChildSlot->SetPadding(VoiceEntryPadding);

	VoiceWidget->SetVoiceInfo(InDesc, bInUnlocked);
	return VoiceWidget;
}

//////////////////////////////////////////////////////////////////////////////////
// UCharacterVoiceListWidget

UCharacterVoiceListWidget::UCharacterVoiceListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Title(FText())
{
}

void UCharacterVoiceListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DefaultAnim = GetWidgetAnimationFromName(this, "AnimDefault");
	OpenListAnim = GetWidgetAnimationFromName(this, "AnimOpenList");
	CloseListAnim = GetWidgetAnimationFromName(this, "AnimCloseList");

	SelectButton = CastChecked<UButton>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UCharacterVoiceListWidget::OnVoiceListSelected);

	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("TextTitle"));
	TitleText->SetText(Title);

	VoiceListWidget = CastChecked<UVerticalList>(GetWidgetFromName("VoiceList"));
}

static FText _GetSkillNameText(FCharacterType InCharacterType, ECharacterVoiceCategory InVoiceCategory)
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(InCharacterType);

	const FCMSSkillRow* SkillRow = nullptr;
	switch (InVoiceCategory)
	{
		case ECharacterVoiceCategory::TurnSkill1:
			if (UnitRow.GetTurnSkills().IsValidIndex(0))
			{
				SkillRow = UnitRow.GetTurnSkills()[0];
			}
			break;
		case ECharacterVoiceCategory::TurnSkill2:
			if (UnitRow.GetTurnSkills().IsValidIndex(1))
			{
				SkillRow = UnitRow.GetTurnSkills()[1];
			}
			break;
		case ECharacterVoiceCategory::TurnSkill3:
			if (UnitRow.GetTurnSkills().IsValidIndex(2))
			{
				SkillRow = UnitRow.GetTurnSkills()[2];
			}
			break;
		case ECharacterVoiceCategory::UltimateSkill:
			if (UnitRow.GetUltimateSkills().Num())
			{
				SkillRow = UnitRow.GetUltimateSkills()[0];
			}
			break;
		default:
			break;
	}

	if (!SkillRow)
	{
		return FText::GetEmpty();
	}

	return SkillRow->DescName;
}

static FText _GetVoiceGroupTitle(FCharacterType InCharacterType, ECharacterVoiceCategory InVoiceCategory)
{
	switch (InVoiceCategory)
	{
		case ECharacterVoiceCategory::TurnSkill1:
		{
			FText SkillNameText = _GetSkillNameText(InCharacterType, InVoiceCategory);
			FString TitleString = FString::Printf(TEXT("%s1 : %s"), *Q6Util::GetLocalizedText("Lobby", "ProfileVoiceSkill").ToString(), *SkillNameText.ToString());
			return FText::FromString(TitleString);
		}
		case ECharacterVoiceCategory::TurnSkill2:
		{
			FText SkillNameText = _GetSkillNameText(InCharacterType, InVoiceCategory);
			FString TitleString = FString::Printf(TEXT("%s2 : %s"), *Q6Util::GetLocalizedText("Lobby", "ProfileVoiceSkill").ToString(), *SkillNameText.ToString());
			return FText::FromString(TitleString);
		}
		case ECharacterVoiceCategory::TurnSkill3:
		{
			FText SkillNameText = _GetSkillNameText(InCharacterType, InVoiceCategory);
			FString TitleString = FString::Printf(TEXT("%s3 : %s"), *Q6Util::GetLocalizedText("Lobby", "ProfileVoiceSkill").ToString(), *SkillNameText.ToString());
			return FText::FromString(TitleString);
		}
		case ECharacterVoiceCategory::NormalSkill:
			return FText::GetEmpty();
		case ECharacterVoiceCategory::AceSkill:
			return FText::FromString("Ace");
		case ECharacterVoiceCategory::BreakSkill:
			return FText::FromString("Break");
		case ECharacterVoiceCategory::CloserSkill:
			return FText::FromString("Closer");
		case ECharacterVoiceCategory::DoubleSkill:
			return FText::FromString("Double");
		case ECharacterVoiceCategory::UltimateSkill:
		{
			FText SkillNameText = _GetSkillNameText(InCharacterType, InVoiceCategory);
			return FText::FromString(FString::Printf(TEXT("%s : %s"), *Q6Util::GetLocalizedText("Lobby", "ProfileVoiceUltimate").ToString(), *SkillNameText.ToString()));
		}
		default:
		{
			FString EtcTitleTextKey = FString::Printf(TEXT("ProfileVoiceEtc%s"), *ENUM_TO_STRING(ECharacterVoiceCategory, InVoiceCategory));
			return Q6Util::GetLocalizedText("Lobby", EtcTitleTextKey);
		}
	}
}

void UCharacterVoiceListWidget::AddVoiceEntryGroup(UCharacterVoiceWidget* InVoiceWidget, FCharacterType InCharacterType, const FCharacterVoiceInfo& InCharacterVoiceInfo, TArray<const FCMSCharUnlockElemRow *>& InElems)
{
	UCharacterVoiceListEntryGroupWidget* VoiceListEntryGroupWidget = CastChecked<UCharacterVoiceListEntryGroupWidget>(VoiceListWidget->AddNewChild());

	FText VoiceGroupTitle = _GetVoiceGroupTitle(InCharacterType, InCharacterVoiceInfo.Category);
	VoiceListEntryGroupWidget->InitVoiceGroup(VoiceGroupTitle);

	for (const FVoiceInfo& VoiceInfo : InCharacterVoiceInfo.VoiceInfos)
	{
		for (const FCMSCharUnlockElemRow* Elem : InElems)
		{
			if (Elem->Param1 == VoiceInfo.VoiceId)
			{
				bool bUnlocked = GetHUDStore().IsUnlockedCharUnlockElem(InCharacterType, Elem);
				FText DescText = bUnlocked ? Elem->Desc : Elem->UnlockCondDesc;
				UCharacterVoiceListEntryWidget* VoiceListEntryWidget = VoiceListEntryGroupWidget->AddVoiceElem(DescText, bUnlocked);
				if (VoiceListEntryWidget)
				{
					VoiceListEntryWidget->OnVoiceSelectedDelegate.BindUObject(InVoiceWidget, &UCharacterVoiceWidget::OnVoiceSelected,
						InCharacterVoiceInfo.Category, VoiceInfo.Sound);
				}

				InElems.Remove(Elem);
				break;
			}
		}
	}
}

void UCharacterVoiceListWidget::InitVoiceList()
{
	VoiceListWidget->ClearAll();
	PlayAnimation(DefaultAnim);
}

void UCharacterVoiceListWidget::SetSelected(bool bInSelected)
{
	if (bInSelected)
	{
		VoiceListWidget->ScrollToStart();
		PlayAnimation(OpenListAnim);
	}
	else
	{
		PlayAnimation(CloseListAnim);
	}
}

void UCharacterVoiceListWidget::OnVoiceListSelected()
{
	OnVoiceListSelectedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////////////
// UCharacterVoiceWidget

UCharacterVoiceWidget::UCharacterVoiceWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SelectedVoiceListIndex(INDEX_NONE)
{
}

void UCharacterVoiceWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ShowVoiceListAnim = GetWidgetAnimationFromName(this, "AnimShowVoiceList");
	HideVoiceListAnim = GetWidgetAnimationFromName(this, "AnimHideVoiceList");

	CharacterNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextChrName"));
	SoundPlayingImage = CastChecked<UImage>(GetWidgetFromName("ImgSound"));

	VoiceListWidgets.Empty();
	UVerticalBox* VoiceListsBox = CastChecked<UVerticalBox>(GetWidgetFromName("VoiceLists"));
	for (int32 i = 0; i < VoiceListsBox->GetChildrenCount(); ++i)
	{
		UCharacterVoiceListWidget* VoiceListWidget = Cast<UCharacterVoiceListWidget>(VoiceListsBox->GetChildAt(i));
		if (VoiceListWidget)
		{
			VoiceListWidget->OnVoiceListSelectedDelegate.BindUObject(this, &UCharacterVoiceWidget::OnVoiceListSelected, i);
			VoiceListWidgets.Add(VoiceListWidget);
		}
	}
}

void UCharacterVoiceWidget::NativeDestruct()
{
	VoiceListWidgets.Reset();

	Super::NativeDestruct();
}

void UCharacterVoiceWidget::GetVoiceElems(FCharacterType InCharacterType, TArray<const FCMSCharUnlockElemRow*>& InOutElems) const
{
	InOutElems.Empty();

	const FCMSCharUnlockElemSetRow* CharUnlockElemSetRow = GetCMS()->GetCharUnlockElemSetRowByCharType(InCharacterType);
	if (CharUnlockElemSetRow)
	{
		const TArray<const FCMSCharUnlockElemRow*>& UnlockElems = CharUnlockElemSetRow->GetUnlockElem();
		for (const FCMSCharUnlockElemRow* UnlockElem : UnlockElems)
		{
			if (!UnlockElem)
			{
				continue;
			}

			if (UnlockElem->Category == ECharUnlockElemCategory::Voice)
			{
				InOutElems.Add(UnlockElem);
			}
		}
	}
}

static int32 _GetVoiceListWidgetIndex(ECharacterVoiceCategory InVoiceCategory)
{
	switch (InVoiceCategory)
	{
		case ECharacterVoiceCategory::TurnSkill1:
		case ECharacterVoiceCategory::TurnSkill2:
		case ECharacterVoiceCategory::TurnSkill3:
			return 0;
		case ECharacterVoiceCategory::NormalSkill:
		case ECharacterVoiceCategory::AceSkill:
		case ECharacterVoiceCategory::BreakSkill:
		case ECharacterVoiceCategory::CloserSkill:
		case ECharacterVoiceCategory::DoubleSkill:
			return 1;
		case ECharacterVoiceCategory::UltimateSkill:
			return 2;
		default:
			return 3;
	}
}

void UCharacterVoiceWidget::SetCharacter(FCharacterType InCharacterType)
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(InCharacterType);
	CharacterNameText->SetText(UnitRow.FullName);

	SoundPlayingImage->SetVisibility(ESlateVisibility::Collapsed);

	for (UCharacterVoiceListWidget* VoiceListWidget : VoiceListWidgets)
	{
		VoiceListWidget->InitVoiceList();
	}
	SelectedVoiceListIndex = INDEX_NONE;
	
	TArray<const FCMSCharUnlockElemRow*> VoiceElems;
	GetVoiceElems(InCharacterType, VoiceElems);

	const FCharacterVoiceAssetRow* CharacterVoiceAssetRow = GetGameSoundResource().GetCharacterVoiceAssetRow(InCharacterType);
	if (CharacterVoiceAssetRow)
	{
		for (const FCharacterVoiceInfo& CharacterVoiceInfo : CharacterVoiceAssetRow->CharacterVoiceInfos)
		{
			int32 VoiceListWidgetIndex = _GetVoiceListWidgetIndex(CharacterVoiceInfo.Category);
			if (VoiceListWidgets.IsValidIndex(VoiceListWidgetIndex))
			{
				UCharacterVoiceListWidget* VoiceListWidget = VoiceListWidgets[VoiceListWidgetIndex];
				VoiceListWidget->AddVoiceEntryGroup(this, InCharacterType, CharacterVoiceInfo, VoiceElems);
			}
		}
	}

	ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (LobbyPC)
	{
		LobbyPC->OnPreviewFinishedDelegate.BindUObject(this, &UCharacterVoiceWidget::OnVoicePreviewAnimFinished);
	}

	GetSoundPlayer().OnCharacterVoicePlayDelegate.Unbind();
	GetSoundPlayer().OnCharacterVoicePlayDelegate.BindUObject(this, &UCharacterVoiceWidget::OnVoiceSoundPlay);

	GetSoundPlayer().GetVoiceFinishedDelegate().Clear();
	GetSoundPlayer().GetVoiceFinishedDelegate().AddDynamic(this, &UCharacterVoiceWidget::OnVoiceSoundFinished);

	PlayAnimation(ShowVoiceListAnim);
}

void UCharacterVoiceWidget::OnVoiceListSelected(int32 InVoiceListIndex)
{
	if (VoiceListWidgets.IsValidIndex(SelectedVoiceListIndex))
	{
		VoiceListWidgets[SelectedVoiceListIndex]->SetSelected(false);
	}

	if (InVoiceListIndex != SelectedVoiceListIndex && VoiceListWidgets.IsValidIndex(InVoiceListIndex))
	{
		VoiceListWidgets[InVoiceListIndex]->SetSelected(true);
		SelectedVoiceListIndex = InVoiceListIndex;
	}
	else
	{
		SelectedVoiceListIndex = INDEX_NONE;
	}
}

void UCharacterVoiceWidget::OnVoiceSelected(ECharacterVoiceCategory VoiceCategory, TSoftObjectPtr<USoundBase> VoiceSound)
{
	ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (!LobbyPC)
	{
		return;
	}

	AMenuUnit* LobbyUnit = LobbyPC->GetLobbyUnit();
	if (!LobbyUnit || !LobbyUnit->IsLoaded())
	{
		return;
	}

	LobbyPC->SetLobbyUnitFullView(true);
	LobbyPC->PlayPreview(VoiceCategory, VoiceSound);

	PlayAnimation(HideVoiceListAnim);
}

void UCharacterVoiceWidget::OnVoicePreviewAnimFinished()
{
	ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (!LobbyPC)
	{
		return;
	}

	LobbyPC->SetLobbyUnitFullView(false);

	PlayAnimation(ShowVoiceListAnim);
}

void UCharacterVoiceWidget::OnVoiceSoundPlay()
{
	SoundPlayingImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UCharacterVoiceWidget::OnVoiceSoundFinished()
{
	SoundPlayingImage->SetVisibility(ESlateVisibility::Collapsed);

	ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (!LobbyPC || !LobbyPC->IsPlayingPreview())
	{
		OnVoicePreviewAnimFinished();
	}
}
