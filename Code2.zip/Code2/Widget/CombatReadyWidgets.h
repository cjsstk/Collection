// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6.h"

#include "CMS_gen.h"
#include "LobbyObj_gen.h"
#include "LobbyHUDWidget.h"

#include "CombatReadyWidgets.generated.h"

class UAvatarIconWidget;
class USortingWidget;
class UDynamicListWidget;
class UEquipIconWidget;
class UItemCardWidget;
class UJokerSetViewWidget;
class UNatureTabWidget;
class UPartyEquipIconWidget;
class UPartyIconWidget;
class UPartyWidget;
class USkillIconWidget;
class UStageEnemyNaturesWidget;
class UTurnSkillIconWidget;
class UQ6Button;

UENUM(BlueprintType)
enum class EJokerSelectType : uint8
{
	Enabled = 0,
	NPCDisabled,
	NoSetDisabled,
	RandomJokerEnabled,
};

UCLASS()
class Q6_API UJokerEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UJokerEntryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetSystemJoker(const FCMSCharacterRow* JokerCharacterRow, int32 JockerLevel);
	void SetFriendJoker(const FFriendInfo& InFriendInfo, int32 InJokerSlotIndex, bool bFriend);
	void SetRandomJoker(const FCMSCharacterRow* JokerCharacterRow, int32 InJokerLevel);
	void SetFriend(const FFriendInfo& InFriendInfo);
	void SetLocked(bool bIsLocked, const FText& LockedReason = FText::GetEmpty());
	void SetNewMark(bool bNewly);

	FFriendButtonDelegate OnFriendButtonDelegate;
	FFriendRequestDelegate OnJokerSetButtonDelegate;
	FSimpleDelegate OnJokerSelectedDelegate;

protected:
	UFUNCTION(BlueprintImplementableEvent, Category = "Joker Entry Widget")
	void SetJokerSelectType(EJokerSelectType SelectType);

	UFUNCTION(BlueprintImplementableEvent, Category = "Joker Entry Widget")
	void SetMenu(bool bFriend);

	UFUNCTION(BlueprintImplementableEvent, Category = "Joker Entry Widget")
	void SetJokerType(EJokerCategory JokerCategory);

private:
	void SetJokerInfoUi(const FCharacterInfo* CharacterInfo, const FCharacterBond* CharacterBond, const FSculptureInfo* SculptureInfo, const FRelicInfo* RelicInfo, bool bFriendJoker);
	void SetJokerInfo(const FCMSCharacterRow* JokerCharacterRow, int32 InJokerLevel);

	UFUNCTION()
	void OnSystemJokerSelected();

	UFUNCTION()
	void OnFriendJokerSelected();

	UFUNCTION()
	void OnRandomJokerSelected();

	UFUNCTION()
	void OnJokerSetButtonClicked();

	UFUNCTION()
	void OnFriendDeclineButtonClicked();

	UFUNCTION()
	void OnFriendAcceptButtonClicked();

	// Widgets

	UPROPERTY()
	UItemCardWidget* CharacterWidget;

	UPROPERTY()
	UEquipIconWidget* SculptureIconWidget;

	UPROPERTY()
	UEquipIconWidget* RelicIconWidget;

	UPROPERTY()
	USkillIconWidget* UltimateSkillWidget;

	UPROPERTY()
	USkillIconWidget* SupportSkillWidget;

	UPROPERTY()
	TArray<UTurnSkillIconWidget*> TurnSkillWidgets;

	UPROPERTY()
	UImage* FriendshipImage;

	UPROPERTY()
	UImage* IconBadgeImage;

	UPROPERTY()
	UBorder* AkaBorder;

	UPROPERTY()
	URichTextBlock* AkaText;

	UPROPERTY()
	UTextBlock* JokerTypeText;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* FriendNameText;

	UPROPERTY()
	UTextBlock* ReasonText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UTextBlock* LastLoginText;

	UPROPERTY()
	UTextBlock* FriendshipPointText;

	UPROPERTY()
	UButton* JokerSetButton;

	UPROPERTY()
	UButton* DeclineButton;

	UPROPERTY()
	UTextBlock* DeclineButtonText;

	UPROPERTY()
	UButton* AcceptButton;

	UPROPERTY()
	UTextBlock* AcceptButtonText;

	UPROPERTY()
	UQ6Button* SelectButton;

	UPROPERTY()
	UAvatarIconWidget* AvatarWidget;

	// Fields

	FCharacterInfo JokerInfo;
	FFriendInfo FriendInfo;
	int32 JokerSlotIndex;
};


UCLASS()
class Q6_API UJokerSelectWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UJokerSelectWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void RefreshMenu() override;
	virtual bool OnBack() override;
	virtual void OnEnterMenu() override;

protected:
	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

private:
	void AddSystemJokers();
	void AddFriendJokers();
	void AddRecommendJokers();

	void SetRandomJoker(const FCMSSagaRow& SagaRow);

	void SetSubWidgetsEnable(bool bInIsEnabled);
	void OnNatureTabChanged(int32 NewIndex);
	void OnJokerSetButtonClicked(const FFriendInfo& InFriendInfo);
	void OnFriendJokerSelected(UPartyEquipIconWidget* EquipIconWidget, int SlotIdx);

	UFUNCTION()
	void OnRefreshButtonClicked();

	UFUNCTION()
	void OnPopupButtonClicked(EConfirmPopupFlag Flag);

	void OnJokerSelected();

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	UButton* RefreshButton;

	UPROPERTY()
	UJokerSetViewWidget* JokerSetViewWidget;

	UPROPERTY()
	UNatureTabWidget* NatureTabWidget;

	UPROPERTY()
	UDynamicListWidget* JokerListWidget;

	UPROPERTY()
	USortingWidget* SortingWidget;

	int32 JokerSlotIndex;
	FSagaType SagaType;
	FFriendInfo FriendInfo;
	bool bIsClosedPopup;
};
