// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "LoginHUDWidget.h"
#include "Q6GameInstance.h"
#include "Q6GameUserSettings.h"
#include "Q6Log.h"
#include "Utils/LevelUtil.h"
#include "Utils/Q6Util.h"

const FString ULoginHUDWidget::DefaultPassword = TEXT("passwd\042\047");

ULoginHUDWidget::ULoginHUDWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void ULoginHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IDTextBox = CastChecked<UEditableTextBox>(GetWidgetFromName("ID"));
	IDTextBox->SetText(FText::FromString(UQ6GameUserSettings::Get()->GetIdString()));

	PWTextBox = CastChecked<UEditableTextBox>(GetWidgetFromName("PW"));
	FString Password = UQ6GameUserSettings::Get()->GetMD5Password();
	if (!Password.IsEmpty())
	{
		Password = DefaultPassword;
	}
	PWTextBox->SetText(FText::FromString(Password));

	SubmitButton = CastChecked<UButton>(GetWidgetFromName("Submit"));
	SubmitButton->OnClicked.AddUniqueDynamic(this, &ULoginHUDWidget::OnSubmitClicked);

	UButton* ClearButton = CastChecked<UButton>(GetWidgetFromName("Clear"));
	ClearButton->OnClicked.AddUniqueDynamic(this, &ULoginHUDWidget::OnClearButtonClicked);

	UTextBlock* VersionTextBlock = CastChecked<UTextBlock>(GetWidgetFromName("Version"));
	VersionTextBlock->SetText(Q6Util::GetVersionText(true, true, true));

	UWidgetAnimation* LoginLoopAnim = GetWidgetAnimationFromName(this, "AnimLoginLoop");
	PlayAnimation(LoginLoopAnim, 0.f, 0);

	UWidgetAnimation* LoginStartAnim = GetWidgetAnimationFromName(this, "AnimLoginStart");
	PlayAnimation(LoginStartAnim);
}

void ULoginHUDWidget::OnSubmitClicked()
{
	FText IDText = IDTextBox->GetText();
	FText PWText = PWTextBox->GetText();
	if (IDText.IsEmpty() || PWText.IsEmpty())
	{
		return;
	}

	FString SavedID = IDText.ToString();
	FString MD5Password = UQ6GameUserSettings::Get()->GetMD5Password();
	UQ6GameUserSettings::Get()->SetIdString(SavedID);
	if (PWText.ToString() != DefaultPassword)
	{
		MD5Password = FMD5::HashAnsiString(*PWText.ToString());
		UQ6GameUserSettings::Get()->SetMD5Password(MD5Password);
	}

	UQ6GameInstance::Get(this)->LoadSaveGame(SavedID);

	SubmitButton->SetIsEnabled(false);
	UQ6GameInstance::Get(this)->GetClientNetwork().CreateSession(SavedID, MD5Password);
}

void ULoginHUDWidget::OnClearButtonClicked()
{
	IDTextBox->SetText(FText::GetEmpty());
	PWTextBox->SetText(FText::GetEmpty());
}

void ULoginHUDWidget::SetDefaultVisibility()
{
	SubmitButton->SetIsEnabled(true);
}
