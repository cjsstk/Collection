// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "CharacterIntroductionWidget.h"
#include "GameResource.h"
#include "LobbyPlayerController.h"
#include "Q6Util.h"

UCharacterIntroductionWidget::UCharacterIntroductionWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, DefaultPlayEndDelay(0.5f)
	, AutoPlayPlayEndDelay(0.5f)
	, FastForwardPlayEndDelay(0.f)
	, PlayEndDelay(0.f)
	, bAutoPlayEnd(false)
	, bPlayingEnd(false)
{
}

void UCharacterIntroductionWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StartAnim = GetWidgetAnimationFromName(this, "AnimStart");
	EndAnim = GetWidgetAnimationFromName(this, "AnimEnd");

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("TextName"));
	NickNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextNickName"));
	CastingVoiceText = CastChecked<UTextBlock>(GetWidgetFromName("TextCV"));
}

void UCharacterIntroductionWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == StartAnim)
	{
		if (bAutoPlayEnd)
		{
			PlayEnd();
		}
	}
	else if (Animation == EndAnim)
	{
		bPlayingEnd = false;

		SetVisibility(ESlateVisibility::Collapsed);
		OnCharacterIntroductionEndDelegate.ExecuteIfBound();
	}
}

bool UCharacterIntroductionWidget::SetInfo(FCharacterIntroductionInfo* InInfo)
{
	if (!InInfo)
	{
		return false;
	}

	NameText->SetText(InInfo->CharacterName);
	
	if (InInfo->NickName.IsEmpty())
	{
		SetEnableNickName(false);
	}
	else
	{
		NickNameText->SetText(InInfo->NickName);
		SetEnableNickName(true);
	}

	if (InInfo->CastingVoice.IsEmpty())
	{
		CastingVoiceText->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		FText CVText = FText::Format(Q6Util::GetLocalizedText("Lobby", "CharacterVoiceName"), InInfo->CastingVoice);
		CastingVoiceText->SetText(CVText);
		CastingVoiceText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	SetColor(InInfo->Color);
	SetOffset(InInfo->Offset);

	return true;
}

void UCharacterIntroductionWidget::PlayStart(bool bInAutoPlaying, bool bInFastForwarding)
{
	if (bInAutoPlaying)
	{
		bAutoPlayEnd = true;
		PlayEndDelay = AutoPlayPlayEndDelay;
	}
	else if (bInFastForwarding)
	{
		bAutoPlayEnd = true;
		PlayEndDelay = FastForwardPlayEndDelay;
	}
	else
	{
		PlayEndDelay = DefaultPlayEndDelay;
	}

	bPlayingEnd = false;

	StopAllAnimations();
	PlayAnimation(StartAnim);
}

void UCharacterIntroductionWidget::PlayEnd()
{
	bAutoPlayEnd = false;
	bPlayingEnd = true;

	PlayEndWithDelay(PlayEndDelay);
}

void UCharacterIntroductionWidget::PlayEndInternal()
{
	StopAllAnimations();
	PlayAnimation(EndAnim);
}
