// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "LobbyHUDWidget.h"
#include "BaseWidget.h"
#include "GameResource.h"
#include "SagaWidgets.generated.h"

class UEpisodeListWidget;
class UStageListWidget;
class UEpisodeIconWidget;
class UStageEntryWidget;

DECLARE_DELEGATE_OneParam(FEpisodeIconDelegate, UEpisodeIconWidget*)
DECLARE_DELEGATE_OneParam(FStageListDelegate, int32)

UENUM()
enum class EEpisodeState : uint8
{
	Clear,
	Progress,
	Locked
};

EEpisodeState GetEpisodeState(int32 Episode, int32 PlayingEpisode);

UCLASS()
class USagaWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	USagaWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

	void OnSelectedIcon(int32 InEpisode);

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Saga; }

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

private:
	UPROPERTY()
	UWidgetSwitcher* WidgetSwitcher;

	UPROPERTY()
	UEpisodeListWidget* EpisodeListWidget;

	UPROPERTY()
	UStageListWidget* StageListWidget;

	UPROPERTY()
	UImage* EpisodeBgImage;

	UPROPERTY()
	UImage* EpisodeChrImage;

	UPROPERTY(Transient)
	UWidgetAnimation* ClearAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* InProgressAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ComingSoonAnim;
};
