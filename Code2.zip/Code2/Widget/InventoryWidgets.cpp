// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "InventoryWidgets.h"

#include "CharacterManager.h"
#include "CharacterWidgets.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "ItemWidgets.h"
#include "JokerSetManager.h"
#include "LobbyHUD.h"
#include "NavigationBarWidgets.h"
#include "NewMarkManager.h"
#include "PartyManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6LobbyState.h"
#include "RelicManager.h"
#include "SculptureManager.h"
#include "SortingWidgets.h"
#include "SystemConstHelper.h"
#include "UIStateManager.h"
#include "WidgetUtil.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Inventory"), STAT_OnHSEventByInventory, STATGROUP_HSTORE);

ESortMenu GetSortMenu(EInventoryCategory Category)
{
	switch (Category)
	{
		case EInventoryCategory::Collection: return ESortMenu::Collection;
		case EInventoryCategory::StorageBox: return ESortMenu::StorageBox;
	}

	Q6JsonLogRoze(Error, "GetSortMenu - invalid inventory category");
	return ESortMenu::Max;
}

void GetInventoryMaxCount(ESortMenu SortMenu, int32& SourceCountMax, int32& TargetCountMax)
{
	if (SortMenu == ESortMenu::Collection)
	{
		SourceCountMax = SystemConst::Q6_COLLECTION_SIZE;
		TargetCountMax = SystemConst::Q6_STORAGE_BOX_SIZE;
		return;
	}

	if (SortMenu == ESortMenu::StorageBox)
	{
		SourceCountMax = SystemConst::Q6_STORAGE_BOX_SIZE;
		TargetCountMax = SystemConst::Q6_COLLECTION_SIZE;
		return;
	}

	Q6JsonLogRoze(Error, "GetInventoryMaxCount - invalid sort menu");
}

UInventoryWidget::UInventoryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, MaxSelectableCount(100)
{

}

void UInventoryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CategoryButtonsWidget = CastChecked <UToggleButtonBoxWidget>(GetWidgetFromName("CategoryButtons"));
	CategoryButtonsWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UInventoryWidget::OnCategoryChanged);

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
	SortingWidget = CastChecked<USortingWidget>(GetWidgetFromName("Sorting"));

	TargetTitleText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TargetTitle"));
	SourceTitleText = CastChecked<UQ6TextBlock>(GetWidgetFromName("SourceTitle"));

	TargetCountText = CastChecked<URichTextBlock>(GetWidgetFromName("TargetCount"));
	SourceCountText = CastChecked<URichTextBlock>(GetWidgetFromName("SourceCount"));
	SelectedCountText = CastChecked<URichTextBlock>(GetWidgetFromName("SelectNum"));

	EditText = CastChecked<UTextBlock>(GetWidgetFromName("TextEdit"));

	OkButton = CastChecked<UQ6Button>(GetWidgetFromName("Ok"));
	OkButton->OnClickedDelegate.BindUObject(this, &UInventoryWidget::OnOkButtonClicked);

	UQ6Button* EditButton = CastChecked<UQ6Button>(GetWidgetFromName("Edit"));
	EditButton->OnClickedDelegate.BindUObject(this, &UInventoryWidget::OnEditButtonClicked);

	QuickMenuButtonWidget = CastChecked<UQuickMenuButtonWidget>(GetWidgetFromName("QuickMenu"));
	QuickMenuButtonWidget->OnMenuButtonClickedDelegate.BindUObject(this, &UInventoryWidget::OnQuickMenuButtonClicked);

	SelectActionWidget = CastChecked<UItemSelectActionWidget>(GetWidgetFromName("SelectAction"));
	SelectActionWidget->InitActionMode(false, true, true);
	SelectActionWidget->OnActionModeChangedDelegate.BindUObject(this, &UInventoryWidget::OnActionModeChanged);

	// Animations

	StartListAnim = GetWidgetAnimationFromName(this, "AnimStartList");
	SwitchEditAnim = GetWidgetAnimationFromName(this, "AnimSwitchEdit");
	SwitchListAnim = GetWidgetAnimationFromName(this, "AnimSwitchList");
}

void UInventoryWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::Character);
	SubscribeToStore(EHSType::Sculpture);
	SubscribeToStore(EHSType::Relic);
	SubscribeToStore(EHSType::CharMission);

	CategoryButtonsWidget->SetSelectedIndex((int32)EInventoryType::Character);
	PlayAnimation(StartListAnim);
}

bool UInventoryWidget::OnBack()
{
	GetLobbyHUD(this)->RefreshNaviBar();
	PlayAnimation(SwitchListAnim);

	return true;
}

void UInventoryWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FInventoryUIState* UIState = GetUIState()->CastToInventoryUIState();
	check(UIState);

	EditType = UIState->EditType;

	SetInventory(UIState->Category, UIState->InventoryType);
}

EHUDWidgetType UInventoryWidget::GetHUDWidgetType() const
{
	if (Category == EInventoryCategory::Collection)
	{
		return EHUDWidgetType::Collection;
	}

	if (Category == EInventoryCategory::StorageBox)
	{
		return EHUDWidgetType::StorageBox;
	}

	Q6JsonLogRoze(Error, "UInventoryWidget::GetHUDWidgetType - Where are you in there?");
	return EHUDWidgetType::Invalid;
}

void UInventoryWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByInventory);

	if (InAction->GetActionType() == EHSActionType::CharacterLoadResp
		|| InAction->GetActionType() == EHSActionType::RelicLoadResp
		|| InAction->GetActionType() == EHSActionType::SculptureLoadResp)
	{
		// Preset ui. Not to do anything here
		return;
	}

	if (InAction->GetActionType() == EHSActionType::CharacterClearNewResp
		|| InAction->GetActionType() == EHSActionType::RelicClearNewResp
		|| InAction->GetActionType() == EHSActionType::SculptureClearNewResp)
	{
		SetCollection();
		return;
	}

	if (InAction->GetActionType() == EHSActionType::InventoryOpen)
	{
		CategoryButtonsWidget->SetSelectedIndex((int32)EInventoryType::Character);
		PlayAnimation(StartListAnim);
	}
	else if (InAction->GetActionType() == EHSActionType::InventoryEdit)
	{
		PlayAnimation(SwitchEditAnim);
	}
	else if (InAction->GetActionType() == EHSActionType::CharacterSetStashResp
		|| InAction->GetActionType() == EHSActionType::RelicSetStashResp
		|| InAction->GetActionType() == EHSActionType::SculptureSetStashResp)
	{
		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", Category == EInventoryCategory::Collection ? "MoveToStorageBoxNotify" : "MoveToCollectionNotify"));
		PlayAnimation(SwitchListAnim);
	}
	
	RefreshMenu();
}

void UInventoryWidget::SetInventory(EInventoryCategory InCategory, EInventoryType InvenType)
{
	Category = InCategory;
	InventoryType = InvenType;

	SelectedCardWidgets.Empty();
	SetSelectedCount();

	bool bStashed = Category == EInventoryCategory::StorageBox;
	if (bStashed)
	{
		SetStorageBox();
	}
	else
	{
		SetCollection();
	}

	ESortMenu SortMenu = GetSortMenu(Category);
	switch (InvenType)
	{
		case EInventoryType::Character:
			SetChararcterList(SortMenu, bStashed);
			break;

		case EInventoryType::Sculpture:
			SetSculptureList(SortMenu, bStashed);
			break;

		case EInventoryType::Relic:
			SetRelicList(SortMenu, bStashed);
			break;

		default:
			ensure(0);
			break;
	}
}

void UInventoryWidget::SetCollection()
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	for (int32 i = 0; i < (int32)EInventoryType::Max; ++i)
	{
		bool bNewly = NewMarkMgr.GetCollectionCategoryType((EInventoryType)i) != ENewMarkType::None;
		CategoryButtonsWidget->SetToggleButtonNewMark(i, bNewly);
	}

	SourceTitleText->SetText(Q6Util::GetLocalizedText("Lobby", "Collection"));

	FText StorageBoxTitle = Q6Util::GetLocalizedText("Lobby", "StorageBox");
	TargetTitleText->SetText(StorageBoxTitle);
	QuickMenuButtonWidget->SetMenuName(StorageBoxTitle);
	QuickMenuButtonWidget->SetIcon(StorageBoxIconBrush);

	EditText->SetText(Q6Util::GetLocalizedText("Lobby", "Stash"));
}

void UInventoryWidget::SetStorageBox()
{
	for (int32 i = 0; i < (int32)EInventoryType::Max; ++i)
	{
		CategoryButtonsWidget->SetToggleButtonNewMark(i, false);
	}

	SourceTitleText->SetText(Q6Util::GetLocalizedText("Lobby", "StorageBox"));

	FText CollectionTitle = Q6Util::GetLocalizedText("Lobby", "Collection");
	TargetTitleText->SetText(CollectionTitle);
	QuickMenuButtonWidget->SetMenuName(CollectionTitle);
	QuickMenuButtonWidget->SetIcon(CollectionIconBrush);

	EditText->SetText(Q6Util::GetLocalizedText("Lobby", "PullOut"));
}

void UInventoryWidget::SetChararcterList(ESortMenu SortMenu, bool bStashed)
{
	SortingWidget->SetSorting(SortMenu, ESortCategory::OwnedCharacterWithExp);

	ItemListWidget->ClearList();

	TArray<FCharacterId> ClearNewCharacterIds;
	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	TArray<FCharacterId> UsedCharacterIds = GetHUDStore().GetUsedCharacterIds();
	TArray<const FCharacter*> Characters = CharacterMgr.GetCharacters(SortMenu, ESortCategory::OwnedCharacterWithExp, bStashed);

	for (const FCharacter* Character : Characters)
	{
		const FCharacterInfo& CharacterInfo = Character->GetInfo();
		bool bUsed = UsedCharacterIds.Contains(CharacterInfo.CharacterId);

		UItemCardWidget* CharacterCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCard->SetCharacter(CharacterInfo);
		CharacterCard->SetChecked(false);
		CharacterCard->SetUsed(bUsed);

		if (CharacterInfo.Newly > 0)
		{
			CharacterCard->SetNewMark(true);
			ClearNewCharacterIds.AddUnique(CharacterInfo.CharacterId);
		}
		else
		{
			CharacterCard->SetNewMark(false);
		}

		ESlateVisibility CharMissionNewMarkVisibility = NewMarkMgr.GetCharacterMissionsVisibility(CharacterInfo.Type);
		CharacterCard->SetCharMissionNewMarkVisibility(bStashed ? ESlateVisibility::Collapsed : CharMissionNewMarkVisibility);

		CharacterCard->OnItemClickedDelegate.BindUObject(this, &UInventoryWidget::OnSelectedItemCard);
		CharacterCard->OnItemLockedDelegate.BindUObject(this, &UInventoryWidget::SetSelectableCard);

		SetSelectableCard(CharacterCard);
	}

	int32 TotalCount = CharacterMgr.GetAllCharacterNum();
	int32 SourceCount = CharacterMgr.GetStashedCharacterNum(bStashed);
	SetInventoryCount(SortMenu, SourceCount, TotalCount - SourceCount);

	if (!bStashed && ClearNewCharacterIds.Num())
	{
		CharacterMgr.ReqClearNew(ClearNewCharacterIds);
	}
}

void UInventoryWidget::SetSculptureList(ESortMenu SortMenu, bool bStashed)
{
	SortingWidget->SetSorting(SortMenu, ESortCategory::OwnedSculptureWithExp);

	ItemListWidget->ClearList();

	TArray<FSculptureId> ClearNewSculptureIds;
	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	TArray<FSculptureId> UsedSculptureIds = GetHUDStore().GetUsedSculptureIds();
	TArray<const FSculpture*> Sculptures = SculptureMgr.GetSculptures(SortMenu, ESortCategory::OwnedSculptureWithExp, bStashed);

	for (const FSculpture* Sculpture : Sculptures)
	{
		const FSculptureInfo& SculptureInfo = Sculpture->GetInfo();
		bool bUsed = UsedSculptureIds.Contains(SculptureInfo.SculptureId);

		UItemCardWidget* SculptureCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		SculptureCard->SetSculpture(SculptureInfo);
		SculptureCard->SetChecked(false);
		SculptureCard->SetUsed(bUsed);

		if (SculptureInfo.Newly > 0)
		{
			SculptureCard->SetNewMark(true);
			ClearNewSculptureIds.AddUnique(SculptureInfo.SculptureId);
		}
		else
		{
			SculptureCard->SetNewMark(false);
		}

		SculptureCard->SetCharMissionNewMarkVisibility(ESlateVisibility::Collapsed);
		SculptureCard->OnItemClickedDelegate.BindUObject(this, &UInventoryWidget::OnSelectedItemCard);
		SculptureCard->OnItemLockedDelegate.BindUObject(this, &UInventoryWidget::SetSelectableCard);

		SetSelectableCard(SculptureCard);
	}

	int32 TotalCount = SculptureMgr.GetAllSculptureNum();
	int32 SourceCount = SculptureMgr.GetStashedSculptureNum(bStashed);
	SetInventoryCount(SortMenu, SourceCount, TotalCount - SourceCount);

	if (!bStashed && ClearNewSculptureIds.Num())
	{
		SculptureMgr.ReqClearNew(ClearNewSculptureIds);
	}
}

void UInventoryWidget::SetRelicList(ESortMenu SortMenu, bool bStashed)
{
	SortingWidget->SetSorting(SortMenu, ESortCategory::OwnedRelicWithExp);

	ItemListWidget->ClearList();

	TArray<FRelicId> ClearNewRelicIds;
	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	TArray<FRelicId> UsedRelicIds = GetHUDStore().GetUsedRelicIds();
	TArray<const FRelic*> Relics = RelicMgr.GetRelics(SortMenu, ESortCategory::OwnedRelicWithExp, bStashed);

	for (const FRelic* Relic : Relics)
	{
		const FRelicInfo& RelicInfo = Relic->GetInfo();
		bool bUsed = UsedRelicIds.Contains(RelicInfo.RelicId);

		UItemCardWidget* RelicCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		RelicCard->SetRelic(RelicInfo);
		RelicCard->SetChecked(false);
		RelicCard->SetUsed(bUsed);
		
		if (RelicInfo.Newly > 0)
		{
			RelicCard->SetNewMark(true);
			ClearNewRelicIds.AddUnique(RelicInfo.RelicId);
		}
		else
		{
			RelicCard->SetNewMark(false);
		}

		RelicCard->SetCharMissionNewMarkVisibility(ESlateVisibility::Collapsed);
		RelicCard->OnItemClickedDelegate.BindUObject(this, &UInventoryWidget::OnSelectedItemCard);
		RelicCard->OnItemLockedDelegate.BindUObject(this, &UInventoryWidget::SetSelectableCard);

		SetSelectableCard(RelicCard);
	}

	int32 TotalCount = RelicMgr.GetAllRelicNum();
	int32 SourceCount = RelicMgr.GetStashedRelicNum(bStashed);
	SetInventoryCount(SortMenu, SourceCount, TotalCount - SourceCount);

	if (!bStashed && ClearNewRelicIds.Num())
	{
		RelicMgr.ReqClearNew(ClearNewRelicIds);
	}
}

void UInventoryWidget::SetSelectableCard(UItemCardWidget* ItemCard)
{
	if (EditType == EInventoryEdit::None || SelectActionWidget->GetSelectedActionType() == EItemActionType::Lock)
	{
		ItemCard->SetSelectable(true);
		return;
	}
	else
	{
		const FItemIconInfo& ItemInfo = ItemCard->GetItemInfo();

		if (ItemInfo.AttributeType == EAttributeCategory::Character)
		{
			if (SystemConstHelper::IsWeed(FCharacterType(ItemInfo.Type)))
			{
				ItemCard->SetSelectable(false);
				ItemCard->SetReasonText(Q6Util::GetLocalizedText("Common", "SelectDisable"), EItemSelectableReasonType::NotAvailable);
				return;
			}
		}

		if (ItemInfo.bUsed)
		{
			ItemCard->SetSelectable(false);
			ItemCard->SetReasonText(Q6Util::GetLocalizedText("Common", "UsedMember"), EItemSelectableReasonType::NotAvailable);
		}
		else
		{
			ItemCard->SetSelectable(true);
		}
	}
}

void UInventoryWidget::SetInventoryCount(ESortMenu SortMenu, int32 SourceCount, int32 TargetCount)
{
	int32 SourceCountMax, TargetCountMax;
	GetInventoryMaxCount(SortMenu, SourceCountMax, TargetCountMax);

	FText TargetNumCountTextFormat = Q6Util::GetLocalizedText("Lobby", "NumCount");
	TargetCountText->SetText(FText::Format(TargetNumCountTextFormat, FText::AsNumber(TargetCount), FText::AsNumber(TargetCountMax)));

	SourceCountText->SetText(
		FText::Format(((SourceCount > SourceCountMax) ? Q6Util::GetLocalizedText("Lobby", "OverNumCount") : TargetNumCountTextFormat),
		FText::AsNumber(SourceCount), FText::AsNumber(SourceCountMax)));

	SelectableCount = FMath::Min(TargetCountMax - TargetCount, MaxSelectableCount);
}

void UInventoryWidget::SetSelectedCount()
{
	for (int32 i = 0; i < SelectedCardWidgets.Num(); ++i)
	{
		SelectedCardWidgets[i]->SetNumber(i + 1);
	}

	SelectedCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "NumCount"), SelectedCardWidgets.Num(), SelectableCount));
	OkButton->SetIsEnabled(SelectedCardWidgets.Num() > 0);
}

void UInventoryWidget::OnSelectedItemCard(UItemCardWidget* ItemCard)
{
	if (EditType == EInventoryEdit::None)
	{
		EItemActionType ActionType = SelectActionWidget->GetSelectedActionType();
		if (ActionType == EItemActionType::Detail)
		{
			ItemCard->OpenItemDetail();
		}
		else if (ActionType == EItemActionType::Lock)
		{
			ItemCard->SetToggleLocked();

			const FItemIconInfo& ItemInfo = ItemCard->GetItemInfo();
			GetHUDStore().ReqSetLock(ItemInfo.AttributeType, ItemInfo.Id, ItemInfo.bLocked);
		}

		return;
	}

	int64 ItemId = ItemCard->GetItemId();
	if (SelectedCardWidgets.Contains(ItemCard))
	{
		ItemCard->SetChecked(false);
		SelectedCardWidgets.Remove(ItemCard);
	}
	else
	{
		if (SelectedCardWidgets.Num() >= SelectableCount)
		{
			GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "MaxCountSelected"));
			return;
		}

		ItemCard->SetChecked(true);
		SelectedCardWidgets.AddUnique(ItemCard);
	}

	SetSelectedCount();
}

void UInventoryWidget::OnCategoryChanged(int32 NewIndex)
{
	SelectActionWidget->SelectDefaultActionMode();

	ACTION_DISPATCH_InventoryChange((EInventoryType)NewIndex);
}

void UInventoryWidget::OnActionModeChanged()
{
	SetInventory(Category, InventoryType);
}

void UInventoryWidget::OnEditButtonClicked()
{
	SelectActionWidget->SelectDefaultActionMode();

	if (SelectableCount == 0)
	{
		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", EditType == EInventoryEdit::Stash ? "StorageBoxMax" : "CollectionMax"));
		return;
	}

	ACTION_DISPATCH_InventoryEdit(Category == EInventoryCategory::Collection ? EInventoryEdit::Stash : EInventoryEdit::PullOut);
}

void UInventoryWidget::OnOkButtonClicked()
{
	TArray<int64> Ids;
	for (const UItemCardWidget* CardWidget : SelectedCardWidgets)
	{
		Ids.AddUnique(CardWidget->GetItemId());
	}

	bool bStashed = EditType == EInventoryEdit::Stash;
	GetHUDStore().ReqSetStash(InventoryType, bStashed, Ids);
}

void UInventoryWidget::OnQuickMenuButtonClicked()
{
	SelectActionWidget->SelectDefaultActionMode();

	if (Category == EInventoryCategory::Collection)
	{
		ACTION_DISPATCH_InventoryOpen(EInventoryCategory::StorageBox);
	}
	else if (Category == EInventoryCategory::StorageBox)
	{
		ACTION_DISPATCH_InventoryOpen(EInventoryCategory::Collection);
	}
}

UUpgradeInventoryWidget::UUpgradeInventoryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UUpgradeInventoryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
	CategoryBoxWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CategoryBox"));
	CategoryBoxWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UUpgradeInventoryWidget::OnUpgradeCategoryChanged);

	SortingWidget = CastChecked<USortingWidget>(GetWidgetFromName("Sorting"));
 }

void UUpgradeInventoryWidget::SetSelectedCategoryBoxIndex(int32 UpgradeMenuIndex)
{
	CategoryBoxWidget->SetSelectedIndex(UpgradeMenuIndex);
}

void UUpgradeInventoryWidget::SetCategoryBoxType(EUpgradeCategory Category)
{
	const UUIResource& UIResource = GetUIResource();
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	switch (Category)
	{
		case EUpgradeCategory::Character:
			CategoryBoxWidget->SetToggleButtonBox(UIResource.GetUpgradeCharacterNames(), NewMarkMgr.GetUpgradeCharacterVisibilities());
			break;
		case EUpgradeCategory::Relic:
			CategoryBoxWidget->SetToggleButtonBox(UIResource.GetUpgradeEquipmentNames(), NewMarkMgr.GetUpgradeRelicVisibilities());
			break;

		case EUpgradeCategory::Sculpture:
			CategoryBoxWidget->SetToggleButtonBox(UIResource.GetUpgradeEquipmentNames(), NewMarkMgr.GetUpgradeSculptureVisibilities());
			break;

		case EUpgradeCategory::Skill:
			CategoryBoxWidget->SetToggleButtonBox(UIResource.GetUpgradeSkillNames(), NewMarkMgr.GetUpgradeSkillVisibilities());
			break;
	}
}

void UUpgradeInventoryWidget::SetCharacterList(EUpgradeCharacterCategory UpCategory)
{
	SortingWidget->SetSorting(ESortMenu::UpgradeTarget, ESortCategory::OwnedCharacterWithExp);

	ItemListWidget->ClearList();

	TArray<const FCharacter*> Characters = GetHUDStore().GetCharacterManager().GetCharacters(ESortMenu::UpgradeTarget, ESortCategory::OwnedCharacterWithExp);
	TArray<FCharacterId> UsedCharacterIds = GetHUDStore().GetUsedCharacterIds();

	const UCMS* CMS = GetCMS();
	for (const FCharacter* Character : Characters)
	{
		const FCharacterInfo& CharacterInfo = Character->GetInfo();
		UItemCardWidget* CharacterCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCard->SetCharacter(CharacterInfo);
		CharacterCard->SetSelectable(true);
		CharacterCard->OnItemClickedDelegate.BindUObject(this, &UUpgradeInventoryWidget::OnItemSelected);

		const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterInfo.Type);
		if ((SystemConstHelper::IsWeed(CharacterInfo) && UpCategory != EUpgradeCharacterCategory::LevelUp)
			|| CharacterRow.XpExclusive)
		{
			const FText Reason = GetCharacterUpgradeDisabledText(UpCategory);
			CharacterCard->SetSelectable(false);
			CharacterCard->SetReasonText(Reason, EItemSelectableReasonType::Inactivated);
			continue;
		}

		if (UpCategory == EUpgradeCharacterCategory::LevelUp)
		{
			if (CharacterInfo.Level >= SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon))
			{
				const FText Reason = GetCharacterUpgradedMaxText(UpCategory);
				CharacterCard->SetSelectable(false);
				CharacterCard->SetReasonText(Reason);
			}
			else
			{
				CharacterCard->SetSelectable(true);
			}
		}
		else if (UpCategory == EUpgradeCharacterCategory::Evolute)
		{
			if (CharacterInfo.Level >= SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon))
			{
				if (CharacterInfo.Moon >= MAX_CHARACTER_MOON)
				{
					const FText& Reason = GetCharacterUpgradedMaxText(UpCategory);
					CharacterCard->SetSelectable(false);
					CharacterCard->SetReasonText(Reason);
				}
				else
				{
					if (CharacterInfo.Star >= SystemConstHelper::GetCharacterMaxPromoteStar(UpCategory, CharacterInfo.Grade))
					{
						if (CanCharacterEvolute(CMS, CharacterInfo.Moon, CharacterInfo.Grade))
						{
							const FText& Reason = GetCharacterUpgradeEnabledText(UpCategory);
							CharacterCard->SetSelectable(true);
							CharacterCard->SetReasonText(Reason);
						}
						else
						{
							CharacterCard->SetSelectable(true);
						}
					}
					else
					{
						CharacterCard->SetSelectable(false);
					}
				}
			}
			else
			{
				CharacterCard->SetSelectable(false);
			}
		}
		else
		{
			if (UpCategory == EUpgradeCharacterCategory::Unbind)
			{
				if (CharacterInfo.Star >= SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Unbind, CharacterInfo.Grade))
				{
					const FText& Reason = GetCharacterUpgradedMaxText(UpCategory);
					CharacterCard->SetSelectable(false);
					CharacterCard->SetReasonText(Reason);
				}
				else
				{
					// Unbind is available at Level 50 (= Five Star Max Level)
					if (CharacterInfo.Level < CharacterFormulaConst::Q6_FIVE_STAR_MAX_LV)
					{
						CharacterCard->SetSelectable(false);
						continue;
					}

					if (CharacterInfo.Level == SystemConstHelper::GetCharacterMaxLevelByStar(CharacterInfo.Star))
					{
						CharacterCard->SetSelectable(true);

						const FCMSPromoteCostRow& PromoteCostRow = CMS->GetCharacterUnbindCostRowOrDummy(CharacterInfo);
						if (CanCharacterMaxLevelUp(PromoteCostRow))
						{
							const FText& Reason = GetCharacterUpgradeEnabledText(UpCategory);
							CharacterCard->SetReasonText(Reason);
						}
					}
					else
					{
						CharacterCard->SetSelectable(false);
					}
				}
			}
			else
			{
				if (CharacterInfo.Star >= SystemConstHelper::GetCharacterMaxPromoteStar(UpCategory, CharacterInfo.Grade))
				{
					const FText& Reason = GetCharacterUpgradedMaxText(UpCategory);
					CharacterCard->SetSelectable(false);
					CharacterCard->SetReasonText(Reason);
				}
				else
				{
					if (CharacterInfo.Level >= SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon))
					{
						// Check the materials

						const FCMSPromoteCostRow& PromoteCostRow = CMS->GetCharacterUpStarCostRowOrDummy(UpCategory, CharacterInfo);
						if (CanCharacterMaxLevelUp(PromoteCostRow))
						{
							const FText& Reason = GetCharacterUpgradeEnabledText(UpCategory);
							CharacterCard->SetSelectable(true);
							CharacterCard->SetReasonText(Reason);
						}
						else
						{
							if ((PromoteCostRow.Gold == 0) || (PromoteCostRow.GetBagItem().Num() <= 0))
							{
								CharacterCard->SetSelectable(false);
								CharacterCard->SetReasonText(GetCharacterUpgradeDisabledText(UpCategory));
							}
							else
							{
								CharacterCard->SetSelectable(true);
							}
						}
					}
					else
					{
						CharacterCard->SetSelectable(false);
					}
				}
			}
		}

		if (CharacterCard->IsReasonEmpty() && UsedCharacterIds.Contains(CharacterInfo.CharacterId))
		{
			CharacterCard->SetReasonText(Q6Util::GetLocalizedText("Common", "UsedMember"), EItemSelectableReasonType::NotAvailable);
		}
	}
}

void UUpgradeInventoryWidget::SetRelicList(EUpgradeEquipCategory UpCategory)
{
	SortingWidget->SetSorting(ESortMenu::UpgradeTarget, ESortCategory::OwnedRelicWithExp);

	ItemListWidget->ClearList();

	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	TArray<const FRelic*> Relics = RelicMgr.GetRelics(ESortMenu::UpgradeTarget, ESortCategory::OwnedRelicWithExp);
	TArray<FRelicId> UsedRelicId = GetHUDStore().GetUsedRelicIds();

	const UCMS* CMS = GetCMS();
	for (const FRelic* Relic : Relics)
	{
		const FRelicInfo& RelicInfo = Relic->Info;
		UItemCardWidget* ItemCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemCard->SetRelic(RelicInfo);
		ItemCard->SetSelectable(true);
		ItemCard->OnItemClickedDelegate.BindUObject(this, &UUpgradeInventoryWidget::OnItemSelected);

		const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(RelicInfo.Type);
		if (RelicRow.XpExclusive)
		{
			const FText Reason = Q6Util::GetLocalizedText("Common",
				(UpCategory == EUpgradeEquipCategory::Promote ? "PromoteDisable" : "UpgradeDisable"));
			ItemCard->SetSelectable(false);
			ItemCard->SetReasonText(Reason, EItemSelectableReasonType::Inactivated);
			continue;
		}

		if (UpCategory == EUpgradeEquipCategory::LevelUp)
		{
			if (RelicInfo.Level >= SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star))
			{
				const FText Reason = Q6Util::GetLocalizedText("Common", "MaxLevel");
				ItemCard->SetSelectable(false);
				ItemCard->SetReasonText(Reason);
			}
			else
			{
				ItemCard->SetSelectable(true);
			}
		}
		else if (UpCategory == EUpgradeEquipCategory::Promote)
		{
			if (RelicInfo.Star >= MAX_EQUIP_STAR)
			{
				const FText Reason = Q6Util::GetLocalizedText("Common", "PromotedToMax");
				ItemCard->SetSelectable(false);
				ItemCard->SetReasonText(Reason);
			}
			else
			{
				if (RelicInfo.Level >= SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star))
				{
					// Check the materials

					if (CanRelicPromote(CMS, RelicInfo.Star))
					{
						const FText Reason = Q6Util::GetLocalizedText("Common", "Promotable");
						ItemCard->SetSelectable(true);
						ItemCard->SetReasonText(Reason);
					}
					else
					{
						ItemCard->SetSelectable(true);
					}
				}
				else
				{
					ItemCard->SetSelectable(false);
				}
			}
		}
		else if (UpCategory == EUpgradeEquipCategory::TierUp)
		{
			if (RelicInfo.Tier >= CombatCubeConst::Q6_MAX_TIER)
			{
				const FText Reason = Q6Util::GetLocalizedText("Common", "EvolutionToMax");
				ItemCard->SetSelectable(false);
				ItemCard->SetReasonText(Reason);
			}
			else
			{
				int32 TargetTier = FMath::Min(RelicInfo.Tier + RelicMgr.GetLeastUpTier(RelicInfo.RelicId), CombatCubeConst::Q6_MAX_TIER);
				if (CanTierUpgrade(RelicInfo.Tier, TargetTier))
				{
					const FText Reason = Q6Util::GetLocalizedText("Common", "Upgradable");
					ItemCard->SetSelectable(true);
					ItemCard->SetReasonText(Reason);
				}
				else
				{
					ItemCard->SetSelectable(true);
				}
			}
		}

		if (ItemCard->IsReasonEmpty() && UsedRelicId.Contains(RelicInfo.RelicId))
		{
			ItemCard->SetReasonText(Q6Util::GetLocalizedText("Common", "UsedMember"), EItemSelectableReasonType::NotAvailable);
		}
	}
}

void UUpgradeInventoryWidget::SetSculptureList(EUpgradeEquipCategory UpCategory)
{
	SortingWidget->SetSorting(ESortMenu::UpgradeTarget, ESortCategory::OwnedSculptureWithExp);

	ItemListWidget->ClearList();

	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	TArray<const FSculpture*> Sculptures = SculptureMgr.GetSculptures(ESortMenu::UpgradeTarget, ESortCategory::OwnedSculptureWithExp);
	TArray<FSculptureId> UsedSculptureIds = GetHUDStore().GetUsedSculptureIds();

	const UCMS* CMS = GetCMS();
	for (const FSculpture* Sculpture : Sculptures)
	{
		const FSculptureInfo& SculptureInfo = Sculpture->Info;
		UItemCardWidget* ItemCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		ItemCard->SetSculpture(SculptureInfo);
		ItemCard->SetSelectable(true);
		ItemCard->OnItemClickedDelegate.BindUObject(this, &UUpgradeInventoryWidget::OnItemSelected);

		const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(SculptureInfo.Type);
		if (SculptureRow.XpExclusive)
		{
			const FText Reason = Q6Util::GetLocalizedText("Common",
				(UpCategory == EUpgradeEquipCategory::Promote ? "PromoteDisable" : "UpgradeDisable"));
			ItemCard->SetSelectable(false);
			ItemCard->SetReasonText(Reason, EItemSelectableReasonType::Inactivated);
			continue;
		}

		if (UpCategory == EUpgradeEquipCategory::LevelUp)
		{
			if (SculptureInfo.Level >= SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star))
			{
				const FText Reason = Q6Util::GetLocalizedText("Common", "MaxLevel");
				ItemCard->SetSelectable(false);
				ItemCard->SetReasonText(Reason);
			}
			else
			{
				ItemCard->SetSelectable(true);
			}
		}
		else if (UpCategory == EUpgradeEquipCategory::Promote)
		{
			if (SculptureInfo.Star >= MAX_EQUIP_STAR)
			{
				const FText Reason = Q6Util::GetLocalizedText("Common", "PromotedToMax");
				ItemCard->SetSelectable(false);
				ItemCard->SetReasonText(Reason);
			}
			else
			{
				if (SculptureInfo.Level >= SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star))
				{
					// Check the materials

					if (CanSculpturePromote(CMS, SculptureInfo.Star))
					{
						const FText Reason = Q6Util::GetLocalizedText("Common", "Promotable");
						ItemCard->SetSelectable(true);
						ItemCard->SetReasonText(Reason);
					}
					else
					{
						ItemCard->SetSelectable(true);
					}
				}
				else
				{
					ItemCard->SetSelectable(false);
				}
			}
		}
		else if (UpCategory == EUpgradeEquipCategory::TierUp)
		{
			if (SculptureInfo.Tier >= CombatCubeConst::Q6_MAX_TIER)
			{
				const FText Reason = Q6Util::GetLocalizedText("Common", "EvolutionToMax");
				ItemCard->SetSelectable(false);
				ItemCard->SetReasonText(Reason);
			}
			else
			{
				int32 TargetTier = FMath::Min(SculptureInfo.Tier + SculptureMgr.GetLeastUpTier(SculptureInfo.SculptureId), CombatCubeConst::Q6_MAX_TIER);
				if (CanTierUpgrade(SculptureInfo.Tier, TargetTier))
				{
					const FText Reason = Q6Util::GetLocalizedText("Common", "EvolutionEnabled");
					ItemCard->SetSelectable(true);
					ItemCard->SetReasonText(Reason);
				}
				else
				{
					ItemCard->SetSelectable(true);
				}
			}
		}

		if (ItemCard->IsReasonEmpty() && UsedSculptureIds.Contains(SculptureInfo.SculptureId))
		{
			ItemCard->SetReasonText(Q6Util::GetLocalizedText("Common", "UsedMember"), EItemSelectableReasonType::NotAvailable);
		}
	}
}

void UUpgradeInventoryWidget::SetSkillList(EUpgradeSkillCategory UpgradeSkillCategory)
{
	SortingWidget->SetSorting(ESortMenu::UpgradeTarget, ESortCategory::OwnedCharacterWithExp);

	// Based on Character.
	ItemListWidget->ClearList();

	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	TArray<const FCharacter*> Characters = CharacterMgr.GetCharacters(ESortMenu::UpgradeTarget, ESortCategory::OwnedCharacterWithExp);
	TArray<FCharacterId> UsedCharacterIds = GetHUDStore().GetUsedCharacterIds();

	const UCMS* CMS = GetCMS();
	const FText ReasonMax = Q6Util::GetLocalizedText("Common", "MaxLevel");
	const FText ReasonUpgradable = Q6Util::GetLocalizedText("Common", "Upgradable");

	for (const FCharacter* Character : Characters)
	{
		const FCharacterInfo& CharacterInfo = Character->GetInfo();

		UItemCardWidget* CharacterCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
		CharacterCard->SetCharacter(CharacterInfo);
		CharacterCard->OnItemClickedDelegate.BindUObject(this, &UUpgradeInventoryWidget::OnItemSelected);

		const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterInfo.Type);
		if (CharacterRow.XpExclusive)
		{
			CharacterCard->SetSelectable(false);
			CharacterCard->SetReasonText(Q6Util::GetLocalizedText("Common", "UpgradeDisable"), EItemSelectableReasonType::Inactivated);
			continue;
		}

		if (UpgradeSkillCategory == EUpgradeSkillCategory::TurnBegin)
		{
			bool bAllMaxLevels = CharacterInfo.TurnSkill1Level == CombatCubeConst::Q6_MAX_SKILL_LEVEL
				&& CharacterInfo.TurnSkill2Level == CombatCubeConst::Q6_MAX_SKILL_LEVEL
				&& CharacterInfo.TurnSkill3Level == CombatCubeConst::Q6_MAX_SKILL_LEVEL;

			if (bAllMaxLevels)
			{
				CharacterCard->SetSelectable(false);
				CharacterCard->SetReasonText(ReasonMax);
				continue;
			}

			if (CanTurnSkillUpgrade(CMS, CharacterInfo.CharacterId))
			{
				CharacterCard->SetSelectable(true);
				CharacterCard->SetReasonText(ReasonUpgradable);
				continue;
			}

			CharacterCard->SetSelectable(true);
		}
		else if (UpgradeSkillCategory == EUpgradeSkillCategory::Ultimate)
		{
			if (SystemConstHelper::IsWeed(CharacterInfo))
			{
				CharacterCard->SetSelectable(false);
				CharacterCard->SetReasonText(Q6Util::GetLocalizedText("Common", "SelectDisable"), EItemSelectableReasonType::NotAvailable);
				continue;
			}

			CharacterCard->SetUltSkillLevel(CharacterInfo.UltimateSkillLevel);

			bool bUltimateSkillMax = CharacterInfo.UltimateSkillLevel == CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL;
			if (bUltimateSkillMax)
			{
				CharacterCard->SetSelectable(false);
				CharacterCard->SetReasonText(ReasonMax);
				continue;
			}

			int32 TargetLevel = FMath::Min(CharacterInfo.UltimateSkillLevel + CharacterMgr.GetLeastUpUltimateSkillLevel(CharacterInfo.CharacterId), CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);
			if (CanUltimateSkillUpgrade(CMS, CharacterInfo.UltimateSkillLevel, TargetLevel))
			{
				CharacterCard->SetSelectable(true);
				CharacterCard->SetReasonText(ReasonUpgradable);
				continue;
			}

			CharacterCard->SetSelectable(true);
		}

		if (UsedCharacterIds.Contains(CharacterInfo.CharacterId))
		{
			CharacterCard->SetReasonText(Q6Util::GetLocalizedText("Common", "UsedMember"), EItemSelectableReasonType::NotAvailable);
		}
	}
}

const FText& UUpgradeInventoryWidget::GetCharacterUpgradedMaxText(EUpgradeCharacterCategory UpCategory) const
{
	if (CharacterUpgradedMaxTexts.IsValidIndex((int32)UpCategory))
	{
		return CharacterUpgradedMaxTexts[(int32)UpCategory];
	}

	return FText::GetEmpty();
}

const FText& UUpgradeInventoryWidget::GetCharacterUpgradeEnabledText(EUpgradeCharacterCategory UpCategory) const
{
	if (CharacterUpgradeEnabledTexts.IsValidIndex((int32)UpCategory))
	{
		return CharacterUpgradeEnabledTexts[(int32)UpCategory];
	}

	return FText::GetEmpty();
}

const FText& UUpgradeInventoryWidget::GetCharacterUpgradeDisabledText(EUpgradeCharacterCategory UpCategory) const
{
	if (CharacterUpgradeDisabledTexts.IsValidIndex((int32)UpCategory))
	{
		return CharacterUpgradeDisabledTexts[(int32)UpCategory];
	}

	return FText::GetEmpty();
}

void UUpgradeInventoryWidget::OnItemSelected(UItemCardWidget* ItemCard)
{
	TUTORIAL_MONITORING_BUTTON_CLICK("UpgradeInventoryItemCard");
	ACTION_DISPATCH_UpgradeItem(ItemCard->GetItemId());
}

void UUpgradeInventoryWidget::OnUpgradeCategoryChanged(int32 ChangedIndex)
{
	ACTION_DISPATCH_UpgradeCategory(ChangedIndex);

	const FUpgradeUIState& UIState = GetHUDStore().GetUIStateManager().GetUpgradeUIState();

	if (UIState.Category == EUpgradeCategory::Character)
	{
		SetCharacterList(EUpgradeCharacterCategory(ChangedIndex));
	}
	else if (UIState.Category == EUpgradeCategory::Relic)
	{
		SetRelicList(EUpgradeEquipCategory(ChangedIndex));
	}
	else if (UIState.Category == EUpgradeCategory::Sculpture)
	{
		SetSculptureList(EUpgradeEquipCategory(ChangedIndex));
	}
	else if (UIState.Category == EUpgradeCategory::Skill)
	{
		EUpgradeSkillCategory UpgradeSkillCategory = EUpgradeSkillCategory(ChangedIndex);
		SetSkillList(UpgradeSkillCategory);
	}
	// RefreshMenu is not being called. ( Need Refactoring )

	GetCheckedLobbyHUD(this)->RefreshNaviBar();
}
