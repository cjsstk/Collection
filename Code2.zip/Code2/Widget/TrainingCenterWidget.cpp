#include "TrainingCenterWidget.h"

#include "TrainingCenterManager.h"
#include "GameResource.h"
#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "StageWidgets.h"
#include "CMSTable.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6UIDefine.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent TrainingCenter"), STAT_OnHSEventByTrainingCenter, STATGROUP_HSTORE);

void UTrainingStepWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StepText = CastChecked<UTextBlock>(GetWidgetFromName("Step"));
	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
}

void UTrainingStepWidget::SetInfo(const FTrainingCenterType& TrainingCenterType)
{
	const FCMSLootDataRow& ClearReward = GetCMS()->GetTrainingCenterClearReward(TrainingCenterType);
	if (ClearReward.IsInvalid())
	{
		Q6JsonLogBro(Warning, "TrainingCenter Clear Reward Invalid", Q6KV("TrainingCenterType", TrainingCenterType));
	}
	else
	{
		ItemWidget->SetLoot(ClearReward.LootId, ClearReward.Count);
	}

	ItemWidget->SetRewardType(ERewardType::Promote);
	StepText->SetText(FText::AsNumber(TrainingCenterType.x));

	SetInfoIntenal(GetHUDStore().GetTrainingCenterManager().GetTrainingStepState(TrainingCenterType));
}

//////////////////////////////////////////////////////////////////////////
// UTrainingCenterWidget
//////////////////////////////////////////////////////////////////////////

void UTrainingCenterWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetJokerAnim = GetWidgetAnimationFromName(this, "AnimSetJoker");
	check(SetJokerAnim);
	SetRandomAnim = GetWidgetAnimationFromName(this, "AnimSetRandom");
	check(SetRandomAnim);
	DefaultPlayAnim = GetWidgetAnimationFromName(this, "AnimDefaultPlay");
	check(DefaultPlayAnim);
	DefaultClearAnim = GetWidgetAnimationFromName(this, "AnimDefaultClear");
	check(DefaultClearAnim);
	LastPlayAnim = GetWidgetAnimationFromName(this, "AnimLastPlay");
	check(LastPlayAnim);
	LastClearAnim = GetWidgetAnimationFromName(this, "AnimLastClear");
	check(LastClearAnim);

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	PeriodText = CastChecked<UTextBlock>(GetWidgetFromName("Period"));
	StageListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("StageList"));

	PrevButton = CastChecked<UQ6Button>(GetWidgetFromName("Prev"));
	NextButton = CastChecked<UQ6Button>(GetWidgetFromName("Next"));

	FString StepWidgetNameStr;
	Steps.SetNum(MAX_PLAYABLE_STEP_COUNT);
	for (int32 i = 0; i < MAX_PLAYABLE_STEP_COUNT; ++i)
	{
		StepWidgetNameStr = FString::Printf(TEXT("Step%d"), i);
		UTrainingStepWidget* StepWidget = CastChecked<UTrainingStepWidget>(GetWidgetFromName(*StepWidgetNameStr));
		if (!StepWidget)
		{
			Q6JsonLogBro(Warning, "TrainingStep Widget is not enough", Q6KV("CurrentIndex", i), Q6KV("NeedCount", MAX_PLAYABLE_STEP_COUNT));
		}

		Steps[i] = StepWidget;
	}

#if !UE_BUILD_SHIPPING
	const UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	if (GameInstance && GameInstance->IsDevMode())
	{
		PrevButton->SetVisibility(ESlateVisibility::Visible);
		NextButton->SetVisibility(ESlateVisibility::Visible);

		PrevButton->OnClickedDelegate.BindUObject(this, &UTrainingCenterWidget::OnStepChangeButtonClicked, false);
		NextButton->OnClickedDelegate.BindUObject(this, &UTrainingCenterWidget::OnStepChangeButtonClicked, true);
	}
	else
	{
		PrevButton->SetVisibility(ESlateVisibility::Collapsed);
		NextButton->SetVisibility(ESlateVisibility::Collapsed);
	}
#else
	PrevButton->SetVisibility(ESlateVisibility::Collapsed);
	NextButton->SetVisibility(ESlateVisibility::Collapsed);
#endif
}

void UTrainingCenterWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::NewMark);
	SubscribeToStore(EHSType::TrainingCenter);
}

void UTrainingCenterWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FTrainingCenterUIState* UIState = GetUIState()->CastToTrainingCenterUIState();
	check(UIState);

	InitInfo();
}

void UTrainingCenterWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByTrainingCenter);

	if (Action->GetActionType() == EHSActionType::ContentsResetTime)
	{
		const UTrainingCenterManager& TrainingCenterMgr = GetHUDStore().GetTrainingCenterManager();
		if (TrainingCenterMgr.IsHistoryExpired())
		{
			TrainingCenterMgr.ReqTrainingCenterHistory(false);
		}

		return;
	}

	RefreshMenu();
}

void UTrainingCenterWidget::InitInfo()
{
	const UTrainingCenterManager& TrainingCenterManager = GetHUDStore().GetTrainingCenterManager();
	const FTrainingCenterRecord& History = TrainingCenterManager.GetHistory();

	FTimespan Duration = FTimespan(LENGTH_OF_WEEK, 0, 0, 0);
	FTimespan ADay = FTimespan(1, 0, 0, 0);

	FDateTime ExpDate = Q6Util::UtcTimestampToLocalDateTime(History.ExpireTime);
	FDateTime EndDate = ExpDate - ADay;
	FDateTime StartDate = ExpDate - Duration;

	FText Period = Q6Util::GetLocalDatePeriodText(StartDate, EndDate);
	PeriodText->SetText(Period);

	SetInfo(History.Type);
}

void UTrainingCenterWidget::SetInfo(const FTrainingCenterType InType)
{
	CurrentType = InType;

	SetSteps();
	SetTitle();
	SetPortrait();
	SetStageList();

#if !UE_BUILD_SHIPPING
	SetStepChangeButtonEnables();
#endif
}

void UTrainingCenterWidget::SetStageList()
{
	StageListWidget->ClearList();

	const UCMS* CMS = GetCMS();
	const FCMSTrainingCenterRow& TrainingCenterRow = CMS->GetTrainingCenterRowOrDummy(CurrentType);

	if (TrainingCenterRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UTrainingCenterWidget::SetStageList - TrainingCenterRow does not exist. ");
		return;
	}

	const FCMSSagaRow& SagaRow = TrainingCenterRow.GetStartSaga();

	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UTrainingCenterWidget::SetStageList - SagaRow do not exist. ");
		return;
	}

	const FTrainingCenterRecord& TrainingCenterRecord = GetHUDStore().GetTrainingCenterManager().GetHistory();
	const FSagaType LastClearedSagaType = CurrentType == TrainingCenterRecord.Type ? TrainingCenterRecord.SagaType : SagaTypeInvalid;

	bool bStartStageOnly = LastClearedSagaType == SagaTypeInvalid;
#if !UE_BUILD_SHIPPING
	if (UQ6GameInstance::Get()->IsDevMode())
	{
		bStartStageOnly = false;
	}
#endif

	if (bStartStageOnly)
	{
		AddStageList(SagaRow.CmsType(), EStageState::New, false);
		return;
	}

	int32 LastClearedStage = LastClearedSagaType == SagaTypeInvalid ? 0 : CMS->GetSagaRowOrDummy(LastClearedSagaType).Stage;
	TArray<const FCMSSagaRow*> Stages = CMS->GetStageRows(EContentType::TrainingCenter, SagaRow.Episode);
	for (int32 i = Stages.Num() - 1; i >= 0; --i)
	{
		const FCMSSagaRow* ItorSagaRow = Stages[i];

		bool bNotOpenedStage = (ItorSagaRow->Stage > (LastClearedStage + 1));
#if !UE_BUILD_SHIPPING
		if (UQ6GameInstance::Get()->IsDevMode())
		{
			bNotOpenedStage = false;
		}
#endif

		if (bNotOpenedStage)
		{
			continue;
		}

		EStageState StageState = (ItorSagaRow->Stage <= LastClearedStage) ? EStageState::Clear : EStageState::New;
		AddStageList(ItorSagaRow->CmsType(), StageState, i > 0);
	}
}

void UTrainingCenterWidget::AddStageList(FSagaType InSagaType, EStageState InState, bool bHasLinkedStage)
{
	const UCMS* CMS = GetCMS();
	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(InSagaType);

	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UTrainingCenterWidget::AddStageList - SagaRow does not exist. ");
		return;
	}

	UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());

	EntryWidget->SetTrainingEntryWidget(CurrentType, InSagaType, InState);
	EntryWidget->SetClearCountVisible(false);
	EntryWidget->SetHasLinkedStage(bHasLinkedStage);
}

void UTrainingCenterWidget::SetPortrait()
{
	const UCMS* CMS = GetCMS();
	const FCMSTrainingCenterRow& TrainingCenterRow = CMS->GetTrainingCenterRowOrDummy(CurrentType);
	if (TrainingCenterRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UTrainingCenterWidget::SetPortrait - TrainingCenterRow does not exist. ", Q6KV("TrainingCenterType", CurrentType));
		return;
	}

	if (TrainingCenterRow.RandomJoker)
	{
		PlayAnimation(SetRandomAnim);
		return;
	}

	PlayAnimation(SetJokerAnim);

	UGameResource& GameResource = GetGameResource();
	FCharacterType CharacterType = GetCMS()->GetTrainingCenterJokerType(CurrentType);
	if (CharacterType == CharacterTypeInvalid)
	{
		Q6JsonLogGunny(Warning, "UTrainingCenterWidget::SetPortrait - TrainingCenterRow does not have joker. ", Q6KV("TrainingCenterType", CurrentType));
		return;
	}

	const FCharacterAssetRow& CharacterAssetRow = GameResource.GetCharacterAssetRow(CharacterType);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);
}

void UTrainingCenterWidget::SetSteps()
{
	const UTrainingCenterManager& TCManager = GetHUDStore().GetTrainingCenterManager();
	const FTrainingCenterRecord Records = TCManager.GetHistory();
	if (!Steps.IsValidIndex(0))
	{
		Q6JsonLogBro(Warning, "TrainingCenter Steps Widget not exists");
		return;
	}

	const UCMS* InCMS = GetCMS();
	const FCMSTrainingCenterRow& BeginTCRow = InCMS->GetTrainingCenterRowOrDummy(Records.BeginTrainingCenterType);
	FTrainingCenterType CurrentTCType = Records.BeginTrainingCenterType;
	for (int32 i = 0; i < Steps.Num(); ++i)
	{
		if (CurrentTCType == TrainingCenterTypeInvalid ||
			!(InCMS->IsPlayableStepInTrainingCenter(BeginTCRow, CurrentTCType)))
		{
			if (Steps.IsValidIndex(i))
			{
				Steps[i]->SetVisibility(ESlateVisibility::Collapsed);
			}
			continue;
		}

		if (Steps.IsValidIndex(i))
		{
			Steps[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			Steps[i]->SetInfo(CurrentTCType);
		}
		CurrentTCType = InCMS->GetNextTrainingCenter(CurrentTCType);
	}
}

void UTrainingCenterWidget::SetTitle()
{
	bool bIsCleared = GetHUDStore().GetTrainingCenterManager().IsCleared();
	bool bIsLastStep = GetHUDStore().GetTrainingCenterManager().IsLastStep(CurrentType);

	if (bIsLastStep)
	{
		if (!bIsCleared)
		{
			PlayAnimation(LastPlayAnim);
			return;
		}

		PlayAnimation(LastClearAnim);
		return;
	}

	if (bIsCleared)
	{
		PlayAnimation(DefaultClearAnim);
		return;
	}

	PlayAnimation(DefaultPlayAnim);
}

#if !UE_BUILD_SHIPPING
void UTrainingCenterWidget::SetStepChangeButtonEnables()
{
	PrevButton->SetIsEnabled(CurrentType.x > 1);
	NextButton->SetIsEnabled(GetCMS()->HasNextStepInTrainingCenter(CurrentType));
}

void UTrainingCenterWidget::OnStepChangeButtonClicked(bool bNext)
{
	const UCMS* CMS = GetCMS();

	int32 ChangedStep = bNext ? CurrentType.x + 1 : CurrentType.x - 1;
	SetInfo(FTrainingCenterType(ChangedStep));
}
#endif
