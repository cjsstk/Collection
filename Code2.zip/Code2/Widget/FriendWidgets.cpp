// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "FriendWidgets.h"
#include "AccountWidgets.h"
#include "CharacterManager.h"
#include "CMSType_gen.h"
#include "CombatReadyWidgets.h"
#include "CommonWidgets.h"
#include "ErrCode_gen.h"
#include "Formula.h"
#include "FriendBook.h"
#include "FriendManager.h"
#include "GameResource.h"
#include "HAL/PlatformApplicationMisc.h"
#include "LobbyHUD.h"
#include "NewMarkManager.h"
#include "PartyWidgets.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "SortingWidgets.h"
#include "SystemConst_gen.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Friend"), STAT_OnHSEventByFriend, STATGROUP_HSTORE);

UJokerSetViewWidget::UJokerSetViewWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UJokerSetViewWidget::NativeConstruct()
{
	AkaText = CastChecked<URichTextBlock>(GetWidgetFromName("Aka"));
	FriendNameText = CastChecked<UTextBlock>(GetWidgetFromName("FriendName"));
	JokerSetWidget = CastChecked<UPartyPageWidget>(GetWidgetFromName("JokerSet"));
}

void UJokerSetViewWidget::SetFriendInfo(const FFriendInfo& FriendInfo)
{
	const FCMSUserTitleRow& UserTitleRow = GetCMS()->GetUserTitleRowOrDummy(FriendInfo.TitleId);
	if (!UserTitleRow.IsInvalid())
	{
		AkaText->SetText(UserTitleRow.DescName);
	}
	FriendNameText->SetText(FText::FromString(FriendInfo.Name));
	JokerSetWidget->SetFriendJoker(FriendInfo.JokerSet);
}

UFriendFeedEntryWidget::UFriendFeedEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CachedFeedId(FFriendBookFeedId::InvalidValue())
{
}

void UFriendFeedEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	TextFeedRichText = CastChecked<URichTextBlock>(GetWidgetFromName("FeedContent"));
	AvatarWidget = CastChecked<UAvatarIconWidget>(GetWidgetFromName("Avatar"));
	LoginText = CastChecked<UTextBlock>(GetWidgetFromName("Login"));
	IconFeedTypeImage = CastChecked<UImage>(GetWidgetFromName("IconFeedType"));

	// Caution!! Below widgets can be replaced by other widgets, because these are under namedslot.
	// dont add check and guard null check.
	ReactionCountText = Cast<UTextBlock>(GetWidgetFromName("ReactionCount"));
	LinkNameText = Cast<UTextBlock>(GetWidgetFromName("LinkName"));
	QuickLinkButton = Cast<UButton>(GetWidgetFromName("QuickLink"));
	if (QuickLinkButton)
	{
		QuickLinkButton->OnClicked.AddUniqueDynamic(this, &UFriendFeedEntryWidget::OnQuickLinkButtonClicked);
	}
	AddReactionButton = Cast<UButton>(GetWidgetFromName("AddReaction"));
	if (AddReactionButton)
	{
		AddReactionButton->OnClicked.AddUniqueDynamic(this, &UFriendFeedEntryWidget::OnAddReactionClicked);
	}
	FriendReactionsWidget = Cast<UReactionTagWidget>(GetWidgetFromName("FriendReactions"));
}

void UFriendFeedEntryWidget::OnAddReactionClicked()
{
	OnReactionButtonDelegate.ExecuteIfBound(CachedFeedId);
	GetHUDStore().GetFriendBook().ReqFeed(CachedFeedId);
}

void UFriendFeedEntryWidget::OnQuickLinkButtonClicked()
{
	const FFriendBookDetailedFeed* InFeed = GetHUDStore().GetFriendBook().GetFeed(CachedFeedId);
	const FUserId& MyUserId = GetHUDStore().GetWorldUser().GetId();
	if (!InFeed)
	{
		return;
	}

	if (MyUserId == InFeed->UserId)
	{
		GetLobbyHUD(this)->ChangeHUDType(EHUDWidgetType::Joker);
	}
	else
	{
		const FFriendInfoEx* FriendInfo = GetHUDStore().GetFriendManager().GetFriendInfo(InFeed->UserId);
		OnQuickLinkButtonDelegate.ExecuteIfBound(*FriendInfo);
	}
}

static FText FormatReactionCount(bool bHasMyReaction, uint32 InTotalReactionCount)
{
	if (InTotalReactionCount == 0)
	{
		return Q6Util::GetLocalizedTextOrKey("Lobby", "ReactionNone");
	}

	if (bHasMyReaction)
	{
		if (InTotalReactionCount == 1)
		{
			return Q6Util::GetLocalizedTextOrKey("Lobby", "ReactionOnlyMe");
		}
		else
		{
			FFormatNamedArguments Args;
			Args.Add(TEXT("0"), FText::AsNumber(InTotalReactionCount - 1)); // except me
			return FText::Format(Q6Util::GetLocalizedTextOrKey("Lobby", "ReactionOrdersAndMe"), Args);
		}
	}
	else
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), FText::AsNumber(InTotalReactionCount));
		return FText::Format(Q6Util::GetLocalizedTextOrKey("Lobby", "ReactionOrders"), Args);
	}
}

void UFriendFeedEntryWidget::SetFeedInfo(const FFriendBookDetailedFeed& InFeedInfo)
{
	CachedFeedId = InFeedInfo.Id;
	NameText->SetText(GetHUDStore().GetFriendBook().GetUserName(InFeedInfo.UserId));
	FText LinkText;
	TextFeedRichText->SetText(GetHUDStore().GetFriendBook().FormatMessage(InFeedInfo, &LinkText, &LinkItemIconInfo));
	const FAvatarInfo& AvatarInfo = GetHUDStore().GetFriendBook().GetAvatarInfo(InFeedInfo.UserId);
	AvatarWidget->SetCharacter(AvatarInfo.CharacterType, AvatarInfo.CharacterIllustType);
	AvatarWidget->SetFrame(AvatarInfo.FrameType);
	AvatarWidget->SetEffect(AvatarInfo.EffectType);
	bool bHideLink = true;
	if (LinkNameText && !LinkText.IsEmpty())
	{
		FFormatNamedArguments Args;
		Args.Add(TEXT("0"), LinkText);
		LinkNameText->SetText(FText::Format(Q6Util::GetLocalizedTextOrKey("Lobby", "FeedLinkName"), Args));
		bHideLink = false;
	}

	if (QuickLinkButton)
	{
		QuickLinkButton->SetVisibility(bHideLink ? ESlateVisibility::Collapsed : ESlateVisibility::Visible);
	}

	TArray<uint32> ReactionCounts;
	ReactionCounts.SetNumZeroed(EFriendBookReactionTypeMax);
	FUserId InMyUserId = GetHUDStore().GetWorldUser().GetId();
	bool bHasMyReaction = false;
	uint32 TotalReactionCount = 0;
	for (const auto& itReaction : InFeedInfo.Reactions)
	{
		int32 InReactionIndex = (int32)itReaction.Type;
		if (itReaction.UserId == InMyUserId)
		{
			bHasMyReaction = true;
		}

		if (ReactionCounts.IsValidIndex(InReactionIndex))
		{
			++(ReactionCounts[InReactionIndex]);
			++TotalReactionCount;
		}
	}

	if (FriendReactionsWidget)
	{
		FriendReactionsWidget->SetReactions(ReactionCounts);
	}
	if (ReactionCountText)
	{
		ReactionCountText->SetText(FormatReactionCount(bHasMyReaction, TotalReactionCount));
	}
	LoginText->SetText(Q6Util::GetHappendTime(InFeedInfo.CreateTimeSec, true));
	const FCMSFriendBookFeedRow& InFeedRow = GetCMS()->GetFriendBookFeedRowOrDummy(InFeedInfo.Type);
	IconFeedTypeImage->SetBrush(GetUIResource().GetFriendBookFeedIcon(InFeedRow.Category));
}

void UFriendFeedEntryWidget::UpdateFeedInfo(const FFriendBookDetailedFeed& InFeedInfo)
{
	// TODO: only update reactions.
	SetFeedInfo(InFeedInfo);
}

UReactionButtonWidget::UReactionButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bHasMyReaction(false)
	, CachedFeedId(FFriendBookFeedId::InvalidValue())
{}

void UReactionButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("Select"));
	CountText = CastChecked<UTextBlock>(GetWidgetFromName("Count"));

	SelectCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UReactionButtonWidget::OnReacitonCheckStateChanged);
}

void UReactionButtonWidget::OnReacitonCheckStateChanged(bool bInChecked)
{
	if (HasMyReaction())
	{
		GetHUDStore().GetFriendBook().ReqRemoveReaction(CachedFeedId);
	}
	else
	{
		GetHUDStore().GetFriendBook().ReqAddReaction(CachedFeedId, ReactionType);
	}
}

void UReactionButtonWidget::SetButtonInfo(FFriendBookFeedId InFeedId, EFriendBookReactionType InReactionType, int32 InCount, bool bInHasMyReaction)
{
	CachedFeedId = InFeedId;
	CountText->SetText(FText::AsNumber(InCount));
	bHasMyReaction = bInHasMyReaction;
	ReactionType = InReactionType;

	SelectCheckBox->SetCheckedState(bHasMyReaction ? ECheckBoxState::Checked : ECheckBoxState::Unchecked);
}

UFriendUserReactionEntryWidget::UFriendUserReactionEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UFriendUserReactionEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	AvatarWidget = CastChecked<UAvatarIconWidget>(GetWidgetFromName("Avatar"));
	LoginText = CastChecked<UTextBlock>(GetWidgetFromName("Login"));
	ReactionTagWidget = Cast<UReactionTagWidget>(GetWidgetFromName("ReactionTag"));
}

void UFriendUserReactionEntryWidget::SetInfo(const FFriendBookReaction& InReaction)
{
	NameText->SetText(GetHUDStore().GetFriendBook().GetUserName(InReaction.UserId));
	const FAvatarInfo& AvatarInfo = GetHUDStore().GetFriendBook().GetAvatarInfo(InReaction.UserId);
	AvatarWidget->SetCharacter(AvatarInfo.CharacterType, AvatarInfo.CharacterIllustType);
	AvatarWidget->SetFrame(AvatarInfo.FrameType);
	AvatarWidget->SetEffect(AvatarInfo.EffectType);

	LoginText->SetText(Q6Util::GetHappendTime(InReaction.CreateTimeSec, true));

	TArray<uint32> InReactionCounts;
	InReactionCounts.SetNumZeroed(EFriendBookReactionTypeMax);
	InReactionCounts[(int32)InReaction.Type] = 1;
	ReactionTagWidget->SetReactions(InReactionCounts);
}

UFriendReactionPageWidget::UFriendReactionPageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UFriendReactionPageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FriendFeedWidget = CastChecked<UFriendFeedEntryWidget>(GetWidgetFromName("FriendFeed"));
	UserReactionListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("UserReactionList"));
	OkButton = CastChecked<UButton>(GetWidgetFromName("Ok"));
	OkButton->OnClicked.AddUniqueDynamic(this, &UFriendReactionPageWidget::OnSaveOkClicked);
	FString ReactionWidgetName;
	ReactionWidgets.SetNum(EFriendBookReactionTypeMax);
	for (int32 i = 0; i < EFriendBookReactionTypeMax; ++i)
	{
		ReactionWidgetName = FString::Printf(TEXT("Reaction%d"), i);
		ReactionWidgets[i] = CastChecked<UReactionButtonWidget>(GetWidgetFromName(*ReactionWidgetName));
	}
}

void UFriendReactionPageWidget::SetFeedInfo(const FFriendBookDetailedFeed& InFeedInfo)
{
	FriendFeedWidget->SetFeedInfo(InFeedInfo);
	CachedFeedId = InFeedInfo.Id;

	TArray<uint32> ReactionCounts;
	TArray<bool> bHasMyReaction;
	ReactionCounts.SetNumZeroed(EFriendBookReactionTypeMax);
	bHasMyReaction.SetNumZeroed(EFriendBookReactionTypeMax);
	FUserId InMyUserId = GetHUDStore().GetWorldUser().GetId();

	UserReactionListWidget->ClearList();

	for (const auto& itReaction : InFeedInfo.Reactions)
	{
		int32 InReactionIndex = (int32)itReaction.Type;
		if (itReaction.UserId == InMyUserId)
		{
			bHasMyReaction[InReactionIndex] = true;
		}

		if (ReactionCounts.IsValidIndex(InReactionIndex))
		{
			++(ReactionCounts[InReactionIndex]);
		}

		UFriendUserReactionEntryWidget* EntryWidget = CastChecked<UFriendUserReactionEntryWidget>(UserReactionListWidget->AddChildAtLastIndex());
		EntryWidget->SetInfo(itReaction);
		UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(EntryWidget->Slot);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);
	}

	for (uint8 i = 0; i < EFriendBookReactionTypeMax; ++i)
	{
		ReactionWidgets[i]->SetButtonInfo(CachedFeedId, (EFriendBookReactionType)i, ReactionCounts[i], bHasMyReaction[i]);
	}
}

void UFriendReactionPageWidget::OnSaveOkClicked()
{
	this->SetVisibility(ESlateVisibility::Collapsed);
	OkClicked.ExecuteIfBound();
}

// class UJokerSetViewPopupWidget

UJokerSetViewPopupWidget::UJokerSetViewPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UJokerSetViewPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	JokerSetViewWidget = CastChecked<UJokerSetViewWidget>(GetWidgetFromName("JokerSetView"));
}

void UJokerSetViewPopupWidget::SetFriendInfo(const FFriendInfo& FriendInfo)
{
	JokerSetViewWidget->SetFriendInfo(FriendInfo);
}

UReactionTagWidget::UReactionTagWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UReactionTagWidget::NativeConstruct()
{
	Super::NativeConstruct();


	IconImages.SetNum(EFriendBookReactionTypeMax);
	FString ImageName;
	for (int32 i = 0; i < EFriendBookReactionTypeMax; ++i)
	{
		ImageName = FString::Printf(TEXT("Icon%d"), i);
		IconImages[i] = CastChecked<UImage>(GetWidgetFromName(*ImageName));
		IconImages[i]->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UReactionTagWidget::SetReactions(const TArray<uint32>& InReactionCounts)
{
	for (int32 i = 0; i < EFriendBookReactionTypeMax; ++i)
	{
		if (IconImages.IsValidIndex(i) &&
			InReactionCounts.IsValidIndex(i))
		{
			IconImages[i]->SetVisibility(InReactionCounts[i] > 0 ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
		}
	}
}

// class UFriendWidget

UFriendWidget::UFriendWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	FriendBookFeedWatching = FFriendBookFeedId::InvalidValue();
}

void UFriendWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("Menu"));
	JokerSetViewWidget = CastChecked<UJokerSetViewWidget>(GetWidgetFromName("JokerSetView"));

	FriendListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("FriendList"));
	FriendFeedListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("FriendFeedList"));
	FriendFeedListWidget->OnScrolledAtStart.BindUObject(this, &UFriendWidget::OnScrolledStandStillAtStart);
	FriendFeedListWidget->OnScrolledAtEnd.BindUObject(this, &UFriendWidget::OnScrolledStandStillAtEnd);
	FriendFeedFilterButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("FilterTab"));
	FriendFeedFilterButton->OnToggleButtonClickedDelegate.BindUObject(this, &UFriendWidget::OnFriendFeedFilterChanged);

	CategoryButton = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CategoryBox"));
	CategoryButton->OnToggleButtonClickedDelegate.BindUObject(this, &UFriendWidget::OnCategoryChanged);
	CategorySwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("ListSwitcher"));

	SearchInput = CastChecked<UEditableTextBox>(GetWidgetFromName("UserId"));
	SearchInput->OnTextCommitted.AddUniqueDynamic(this, &UFriendWidget::OnSearchInputCommitted);
	SearchInput->OnTextChanged.AddUniqueDynamic(this, &UFriendWidget::OnSearchInputChanged);

	SearchButton = CastChecked<UButton>(GetWidgetFromName("Search"));
	SearchButton->OnClicked.AddUniqueDynamic(this, &UFriendWidget::OnSearchButtonClicked);

	ResultSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("ResultSwitch"));

	MyUserIdText = CastChecked<UTextBlock>(GetWidgetFromName("MyUserId"));
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	MyUserIdText->SetText(FText::FromString(WorldUser.GetUserDisplayCode()));

	IdCopyButton = CastChecked<UButton>(GetWidgetFromName("IdCopy"));
	IdCopyButton->OnClicked.AddUniqueDynamic(this, &UFriendWidget::OnIdCopyButtonClicked);

	SearchResultWidget = CastChecked<UJokerEntryWidget>(GetWidgetFromName("JokerEntryWidgetBP"));
	SearchResultWidget->OnFriendButtonDelegate.BindUObject(this, &UFriendWidget::OnFriendButtonClicked);
	SearchResultWidget->OnJokerSetButtonDelegate.BindUObject(this, &UFriendWidget::OnJokerSetButtonClicked);

	CountTypeText = CastChecked<UTextBlock>(GetWidgetFromName("CountType"));
	CurFriendText = CastChecked<UTextBlock>(GetWidgetFromName("CurFriend"));
	MaxFriendText = CastChecked<UTextBlock>(GetWidgetFromName("MaxFriend"));

	SortingWidget = CastChecked<USortingWidget>(GetWidgetFromName("Sorting"));

	SetSearchButtonEnabled(IsValidUserCode(SearchInput->GetText()));
}

void UFriendWidget::OnScrolledStandStillAtStart()
{
	GetHUDStore().GetFriendBook().ReqTimeline(FFriendBookFeedId::InvalidValue());
}

void UFriendWidget::OnScrolledStandStillAtEnd()
{
	GetHUDStore().GetFriendBook().ReqTimeline(GetHUDStore().GetFriendBook().GetTailFeedId());
}

void UFriendWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Friend);
	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::FriendBook);

	GetHUDStore().GetFriendManager().ReqFriendList();
}

void UFriendWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FFriendUIState* UIState = GetUIState()->CastToFriendUIState();
	check(UIState);

	MenuSwitcher->SetActiveWidgetIndex((int32)UIState->FriendMenu);
}

void UFriendWidget::Refresh()
{
	RefreshFriendBookNewMark();

	const FFriendUIState& UIState = GetHUDStore().GetUIStateManager().GetFriendUIState();
	if (UIState.FriendMenu == EFriendMenu::MainView)
	{
		bool bNewly = GetHUDStore().GetNewMarkManager().GetFriendReceivingType() != ENewMarkType::None;
		CategoryButton->SetToggleButtonNewMark((int32)EFriendCategory::FriendReceiving, bNewly);

		switch (UIState.FriendCategory)
		{
			case EFriendCategory::FriendConnected:
				RefreshConnected();
				break;
			case EFriendCategory::FriendReceiving:
				RefreshReceiving();
				break;
			case EFriendCategory::FriendSearching:
				SearchInput->SetText(FText::GetEmpty());
				CategorySwitcher->SetActiveWidgetIndex((int32)EFriendTab::FriendSearch);
				ResultSwitcher->SetActiveWidgetIndex((int32)ESearchResultTab::Default);
				break;
			case EFriendCategory::FriendBookFeed:
				FriendFeedFilterButton->SetToggleButtonNewMark((int32)UIState.FriendBookFilter, false);
				FriendFeedFilterButton->SetSelectedIndexNoDelegate((int32)UIState.FriendBookFilter);
				RequestFriendBookTimeline();
			break;

		}

		SortingWidget->SetSorting(ESortMenu::FriendList, ESortCategory::Friend);
	}
}

void UFriendWidget::RefreshFriendBookNewMark()
{
	const FFriendUIState& UIState = GetHUDStore().GetUIStateManager().GetFriendUIState();
	if (UIState.FriendMenu == EFriendMenu::MainView)
	{
		bool bNewly = GetHUDStore().GetNewMarkManager().GetFriendBookType() != ENewMarkType::None && UIState.FriendCategory != EFriendCategory::FriendBookFeed;
		CategoryButton->SetToggleButtonNewMark((int32)EFriendCategory::FriendBookFeed, bNewly);
	}
}

void UFriendWidget::RefreshFriendBookTimeline()
{
	ACTION_DISPATCH_FriendBookReadTimeline();

	const FFriendUIState* UIState = GetUIState()->CastToFriendUIState();
	check(UIState);

	const UFriendBook& FriendBook = GetHUDStore().GetFriendBook();
	FriendFeedListWidget->ClearList();
	FeedWidgets.Empty();

	TArray<const FFriendBookDetailedFeed*> InFeeds = FriendBook.GetFeeds(UIState->FriendBookFilter == EFriendBookFilter::Mine);
	InFeeds.Sort([](const FFriendBookDetailedFeed& FeedL, const FFriendBookDetailedFeed& FeedR) {
		return FeedL.CreateTimeSec > FeedR.CreateTimeSec;
	});

	for (int32 i = 0; i < InFeeds.Num(); ++i)
	{
		UFriendFeedEntryWidget* FriendFeedEntryWidget = CastChecked<UFriendFeedEntryWidget>(FriendFeedListWidget->AddChildAtLastIndex());
		FriendFeedEntryWidget->SetFeedInfo(*(InFeeds[i]));
		FriendFeedEntryWidget->OnQuickLinkButtonDelegate.BindUObject(this, &UFriendWidget::OnJokerSetButtonClicked);
		FriendFeedEntryWidget->OnReactionButtonDelegate.BindUObject(this, &UFriendWidget::OnFriendFeedReactionButtonClicked);
		UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(FriendFeedEntryWidget->Slot);
		GridSlot->SetHorizontalAlignment(HAlign_Fill);
		FeedWidgets.Add(InFeeds[i]->Id, FriendFeedEntryWidget);

		// every timeline feeds request detail information.
		FriendBook.ReqFeed(InFeeds[i]->Id);
	}
}

void UFriendWidget::RefreshFeed(const FFriendBookFeedId InRefreshFeedId)
{
	const UFriendBook& FriendBook = GetHUDStore().GetFriendBook();

	const FFriendBookDetailedFeed* InFeedInfo = FriendBook.GetFeed(InRefreshFeedId);
	if (!InFeedInfo)
	{
		return;
	}

	UFriendFeedEntryWidget** EntryWidgetPtr = FeedWidgets.Find(InRefreshFeedId);
	if (!EntryWidgetPtr)
	{
		RefreshFriendBookTimeline();
		EntryWidgetPtr = FeedWidgets.Find(InRefreshFeedId);
		if (!EntryWidgetPtr)
		{
			return;
		}
	}

	(*EntryWidgetPtr)->UpdateFeedInfo(*InFeedInfo);

	if (FriendBookFeedWatching != InRefreshFeedId)
	{
		return;
	}

	if (!FriendReactionPageWidget)
	{
		FriendReactionPageWidget = CreateWidget<UFriendReactionPageWidget>(GetOwningPlayer(), FriendReactionPageWidgetClass);
		FriendReactionPageWidget->AddToViewport(ZORDER_POPUP);
		FriendReactionPageWidget->OkClicked.BindUObject(this, &UFriendWidget::OnFriendReactionPageClosed);
	}

	FriendReactionPageWidget->SetFeedInfo(*InFeedInfo);
	FriendReactionPageWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UFriendWidget::OnFriendReactionPageClosed()
{
	FriendBookFeedWatching = FFriendBookFeedId::InvalidValue();
}

void UFriendWidget::RefreshConnected()
{
	CategorySwitcher->SetActiveWidgetIndex((int32)EFriendTab::FriendList);
	const auto& FriendMgr = GetHUDStore().GetFriendManager();
	const auto& WorldUser = GetHUDStore().GetWorldUser();
	AddList(FriendMgr.GetConnectedFriends(), "FriendCount", WorldUser.GetMaxFriendCount(), false);
}

void UFriendWidget::RefreshReceiving()
{
	CategoryButton->SetToggleButtonNewMark((int32)EFriendCategory::FriendReceiving, false);

	const UFriendManager& FriendMgr = GetHUDStore().GetFriendManager();
	CategorySwitcher->SetActiveWidgetIndex((int32)EFriendTab::FriendList);

	AddList(FriendMgr.GetReceivingFriends(), "FriendPendingCount", SystemConst::Q6_FRIEND_RECEIVING_LIMIT, true);
}

void UFriendWidget::RequestFriendBookTimeline()
{
	CategorySwitcher->SetActiveWidgetIndex((int32)EFriendTab::FriendBookFeed);

	GetHUDStore().GetFriendBook().ReqTimeline(FFriendBookFeedId::InvalidValue());
}

void UFriendWidget::RefreshSearchResult(TSharedPtr<FHSAction> Action)
{
	const FL2CFriendSearchResp& Res = ACTION_PARSE_FriendSearchResp(Action)->GetVal();
	ResultSwitcher->SetActiveWidgetIndex((int32)ESearchResultTab::UserResult);
	SearchResultWidget->SetFriend(Res.FriendInfo);
}

void UFriendWidget::RefreshErrorResult(TSharedPtr<FHSAction> Action)
{
	const FL2CError& Error = ACTION_PARSE_FriendErrorResp(Action)->GetVal();
	const auto LobbyHUD = GetCheckedLobbyHUD(this);
	switch (Error.ErrorCode)
	{
		case Q6_ERROR_INVALID_USER_CODE:
			ResultSwitcher->SetActiveWidgetIndex((int32)ESearchResultTab::UserNone);
			break;
		case Q6_ERROR_FRIEND_ALREADY_FRIEND:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendNotifyOverlap"));
			break;
		case Q6_ERROR_FRIEND_ALREADY_REQUESTED:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendNotifyPending"));
			break;
		case Q6_ERROR_FRIEND_LIST_FULL:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendNotifyMyFull"));
			break;
		case Q6_ERROR_FRIEND_TARGET_LIST_FULL:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendNotifyUserFull"));
			break;
		case Q6_ERROR_FRIEND_SELF:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendNotifySelf"));
			break;
		case Q6_ERROR_FRIEND_TARGET_REQUESTED:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendNotifyReceiving"));
			break;
		case Q6_ERROR_FRIENDS_NOT_LOADED:
		case Q6_ERROR_FRIEND_NO_CANDIDATE:
		case Q6_ERROR_FRIEND_NOT_RECEIVING:
		case Q6_ERROR_FRIEND_NOT_CONNECTED:
			LobbyHUD->ShowNotification(ENotificationType::Short, FText::FromString(LobbyHUD->MakeErrorText(FErrTextType(Error.ErrorCode), Error.Extra)));
			break;
		default:
			break;
	}
}

void UFriendWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByFriend);

	const auto LobbyHUD = GetCheckedLobbyHUD(this);

	switch (Action->GetActionType())
	{
		case EHSActionType::FriendLoadResp:
			CategoryButton->SetSelectedIndex((int32)EFriendCategory::FriendConnected);
			Refresh();
			break;
		case EHSActionType::FriendErrorResp:
			RefreshErrorResult(Action);
			break;
		case EHSActionType::FriendSearchResp:
			RefreshSearchResult(Action);
			break;
		case EHSActionType::FriendRequestResp:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendRequestNotify"));
			Refresh();
			break;
		case EHSActionType::FriendDeclineResp:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendDeclineNotify"));
			Refresh();
			break;
		case EHSActionType::FriendAcceptResp:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendAcceptNotify"));
			Refresh();
			break;
		case EHSActionType::FriendRemoveResp:
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "FriendRemoveNotify"));
			Refresh();
			break;
		case EHSActionType::FriendCategoryChange:
		case EHSActionType::FriendJokerSetView:
			RefreshMenu();
			break;
		case EHSActionType::FriendReorder:
		case EHSActionType::SortingChange:
		case EHSActionType::FriendNotifyAccept:
		case EHSActionType::FriendNotifyRemove:
		case EHSActionType::FriendNotifyJokerSetChange:
		case EHSActionType::FriendNotifyRequest:
		case EHSActionType::FriendNotifyNicknameChanged:
			Refresh();
			break;
		case EHSActionType::FriendBookReadTimeline:
			RefreshFriendBookNewMark();
			break;
		case EHSActionType::FriendBookNewFeedsFromFile:
		{
			auto DerivedAction = ACTION_PARSE_FriendBookNewFeedFromFile(Action);
			const FFriendBookFeedId& Res = DerivedAction->GetVal();
			RefreshOrRequestOnFeedChanged(Res);
			break;
		}
		case EHSActionType::FriendBookPosted:
		{
			auto DerivedAction = ACTION_PARSE_FriendBookPosted(Action);
			const FL2CFriendBookNotiPosted& Res = DerivedAction->GetVal();
			RefreshOrRequestOnFeedChanged(Res.FeedId);
			break;
		}
		case EHSActionType::FriendBookReacted:
		{
			auto DerivedAction = ACTION_PARSE_FriendBookReacted(Action);
			const FL2CFriendBookNotiReacted& Res = DerivedAction->GetVal();
			RefreshOrRequestOnFeedChanged(Res.FeedId);
			break;
		}
		case EHSActionType::FriendBookReactionRemoved:
		{
			auto DerivedAction = ACTION_PARSE_FriendBookReactionRemoved(Action);
			const FL2CFriendBookNotiReactionRemoved& Res = DerivedAction->GetVal();
			RefreshOrRequestOnFeedChanged(Res.FeedId);
			break;
		}
		case EHSActionType::FriendBookGetTimeline:
		case EHSActionType::FriendBookFilterChange:
			RefreshFriendBookTimeline();
			break;
		case EHSActionType::FriendBookGetFeed:
		{
			auto DerivedAction = ACTION_PARSE_FriendBookGetFeed(Action);
			const FL2CFriendBookGetFeedResp& Res = DerivedAction->GetVal();
			RefreshFeed(Res.Feed.Id);
			break;
		}
		case EHSActionType::FriendBookAddReaction:
		{
			auto DerivedAction = ACTION_PARSE_FriendBookAddReaction(Action);
			const FC2LFriendBookAddReaction& Res = DerivedAction->GetVal();
			RefreshFeed(Res.FeedId);
			break;
		}
		case EHSActionType::FriendBookRemoveReaction:
		{
			auto DerivedAction = ACTION_PARSE_FriendBookRemoveReaction(Action);
			const FC2LFriendBookRemoveReaction& Res = DerivedAction->GetVal();
			RefreshFeed(Res.FeedId);
			break;
		}
		default:
			break;
	}
}

void UFriendWidget::RefreshOrRequestOnFeedChanged(const FFriendBookFeedId InFriendBookFeedId)
{
	const auto& UIState = GetHUDStore().GetUIStateManager().GetFriendUIState();
	if (UIState.FriendCategory == EFriendCategory::FriendBookFeed)
	{
		GetHUDStore().GetFriendBook().ReqFeed(InFriendBookFeedId);
	}
	else
	{
		Refresh();
	}
}

void UFriendWidget::AddList(TArray<const FFriendInfoEx*>&& FriendList, const FString& CountType, int32 MaxFriendCount, bool bReceiving)
{
	FSortOrdering::Sort(ESortMenu::FriendList, FriendList, INDEX_NONE);

	const UFriendManager& FriendMgr = GetHUDStore().GetFriendManager();

	FriendListWidget->ClearList();

	bool bHasAnyNewly = false;
	for (const auto FriendInfo : FriendList)
	{
		bool bNewly = false;
		if (bReceiving)
		{
			bNewly = !FriendMgr.IsConfirmedReceiving(FriendInfo->FriendId);
		}

		bHasAnyNewly |= bNewly;
		AddToList(*FriendInfo, bNewly);
	}

	if (bHasAnyNewly)
	{
		FriendMgr.ReqFriendConfirm();
	}

	CountTypeText->SetText(Q6Util::GetLocalizedText("Common", CountType));
	CurFriendText->SetText(FText::AsNumber(FriendListWidget->GetChildrenCount()));
	MaxFriendText->SetText(FText::AsNumber(MaxFriendCount));
}

void UFriendWidget::AddToList(const FFriendInfo& FriendInfo, bool bNewly)
{
	UJokerEntryWidget* JokerEntryWidget = CastChecked<UJokerEntryWidget>(FriendListWidget->AddChildAtLastIndex());
	JokerEntryWidget->OnFriendButtonDelegate.BindUObject(this, &UFriendWidget::OnFriendButtonClicked);
	JokerEntryWidget->OnJokerSetButtonDelegate.BindUObject(this, &UFriendWidget::OnJokerSetButtonClicked);
	JokerEntryWidget->SetFriend(FriendInfo);
	JokerEntryWidget->SetNewMark(bNewly);

	UUniformGridSlot* GridSlot = CastChecked<UUniformGridSlot>(JokerEntryWidget->Slot);
	GridSlot->SetHorizontalAlignment(HAlign_Fill);
}

void UFriendWidget::OnJokerSetButtonClicked(const FFriendInfo& FriendInfo)
{
	ACTION_DISPATCH_FriendJokerSetView();
	JokerSetViewWidget->SetFriendInfo(FriendInfo);
}

void UFriendWidget::OnFriendFeedReactionButtonClicked(const FFriendBookFeedId& InFeedId)
{
	FriendBookFeedWatching = InFeedId;
}

void UFriendWidget::OnFriendButtonClicked(const FFriendInfo& FriendInfo, bool bAccept)
{
	const auto& FriendMgr = GetHUDStore().GetFriendManager();
	const auto& UIState = GetHUDStore().GetUIStateManager().GetFriendUIState();
	switch (UIState.FriendCategory)
	{
		case EFriendCategory::FriendConnected:
			check(!bAccept);
			FriendInfoDelegate.BindUObject(&FriendMgr, &UFriendManager::ReqFriendRemove);
			DelegateOnConfirm("FriendRemoveTitle", "FriendRemoveContent", FriendInfo);
			break;
		case EFriendCategory::FriendReceiving:
			if (bAccept)
			{
				FriendInfoDelegate.BindUObject(&FriendMgr, &UFriendManager::ReqFriendAccept);
				DelegateOnConfirm("FriendAcceptTitle", "FriendAcceptContent", FriendInfo);
			}
			else
			{
				FriendInfoDelegate.BindUObject(&FriendMgr, &UFriendManager::ReqFriendDecline);
				DelegateOnConfirm("FriendDeclineTitle", "FriendDeclineContent", FriendInfo);
			}
			break;
		case EFriendCategory::FriendSearching:
			check(bAccept);
			FriendInfoDelegate.BindUObject(&FriendMgr, &UFriendManager::ReqFriendRequest);
			DelegateOnConfirm("FriendRequestTitle", "FriendRequestContent", FriendInfo);
			break;
		default:
			break;
	}
}

void UFriendWidget::OnCategoryChanged(int32 ChangedIndex)
{
	ACTION_DISPATCH_FriendCategoryChange(EFriendCategory(ChangedIndex));

	Refresh();
}

void UFriendWidget::OnFriendFeedFilterChanged(int32 InChangedIndex)
{
	ACTION_DISPATCH_FriendBookFilterChange(EFriendBookFilter(InChangedIndex));

	Refresh();
}

void UFriendWidget::DelegateOnConfirm(const FString& TitleKey, const FString& ContentKey, const FFriendInfo& FriendInfo) const
{
	const auto& Title = Q6Util::GetLocalizedText("Popup", TitleKey);
	const auto& Content = FText::Format(Q6Util::GetLocalizedText("Popup", ContentKey), FText::FromString(FriendInfo.Name));
	UConfirmPopupWidget* ConfirmPopup = GetCheckedLobbyHUD(this)->OpenConfirmPopup(Title, Content);
	ConfirmPopup->OnConfirmPopupDelegate.BindLambda([this, &FriendInfo](EConfirmPopupFlag ConfirmFlag)
	{
		if (ConfirmFlag == EConfirmPopupFlag::Yes)
		{
			FriendInfoDelegate.ExecuteIfBound(FriendInfo);
		}
	});
}

void UFriendWidget::SetSearchButtonEnabled(bool bEnabled)
{
	check(SearchButton);
	SearchButton->SetIsEnabled(bEnabled);
}

bool UFriendWidget::IsValidUserCode(const FText& Text)
{
	return !Text.IsEmpty() &&
		Text.IsNumeric() &&
		Text.ToString().Len() == SystemConst::Q6_USER_CODE_LENGTH;
}

void UFriendWidget::OnSearchInputChanged(const FText& Text)
{
	SetSearchButtonEnabled(IsValidUserCode(Text));
}

void UFriendWidget::OnSearchInputCommitted(const FText& Text, ETextCommit::Type CommitMethod)
{
	OnSearchInputChanged(Text);
}

void UFriendWidget::OnSearchButtonClicked()
{
	const auto& FriendMgr = GetHUDStore().GetFriendManager();

	check(!SearchInput->GetText().ToString().IsEmpty());
	FriendMgr.ReqFriendSearch(SearchInput->GetText().ToString());
}

void UFriendWidget::OnIdCopyButtonClicked()
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	FPlatformApplicationMisc::ClipboardCopy(*WorldUser.GetUserCode());
	GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "CopyNotify"));
}