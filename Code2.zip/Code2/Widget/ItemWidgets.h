// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"
#include "LobbyObj_gen.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "PopupWidgets.h"

#include "ItemWidgets.generated.h"

class USkillNoteCardWidget;
class UCombatDetailConditionStateWidget;
class UItemBigCardWidget;
class UDynamicListWidget;
class UItemCardWidget;
class UNamedSlot;
class URichTextBlock;
class UQ6Button;
class UStatWidget;
class USkillIconWidget;
class UVarietyPageSwipeWidget;
class UTurnSkillDescWidget;
class UTurnSkillIconWidget;
class UBondRewardWidget;
class UQ6RichTextBlock;
class URichTextBlock;
class UCharacterVoiceWidget;

enum class EDropBoxType : uint8;

DECLARE_DELEGATE_OneParam(FItemCardClickedDelegate, UItemCardWidget*);

enum class ECheckInType : uint8
{
	Rotation,
	Anniversary,
};

enum class EItemStatusAnimType : uint8
{
	Character,
	Equip,
	CodexCharacter,
	Max,
};

enum class EItemActionType : uint8
{
	Select = 0,
	Detail,
	Lock,

	Max,
};

enum class EItemSelectableReasonType : uint8
{
	Default = 0,
	NotAvailable,
	Activated,
	Inactivated,
	NotIncluded,
};

UENUM(BlueprintType)
enum class EItemSelectType : uint8
{
	Deselect = 0,
	Highlight,
	Selected,
	Checked,
};

UENUM(BlueprintType)
enum class EItemDetailMode : uint8
{
	Info = 0,
	CharacterUnit = 1,
};

UENUM(BlueprintType)
enum class EDetailItemType : uint8
{
	NormalCharacter = 0,
	SpecialCharacter,
	ExpCard,
	Relic,
	Sculpture,
	UltimateSculpture,

	Max,
};


UENUM(BlueprintType)
enum class EItemCategory : uint8
{
	None = 0,
	Point,
	EventPoint,
	BagItem,
	Character,
	Sculpture,
	Relic,
	AvatarEffect,
	AvatarFrame
};

UCLASS()
class Q6_API UStarBarWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UStarBarWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetMoonStars(int32 MoonCount, int32 StarCount);

private:
	void SetStars(int32 StarCount);
	void SetMoon(int32 MoonCount);

	UPROPERTY()
	TArray<UImage*> StarIcons;

	UPROPERTY()
	UImage* MoonIcon;
};

UCLASS()
class Q6_API UItemTooltipWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetItem(FBagItemType ItemType);
	void SetPoint(EPointType PointType);
	void SetEventPoint(FEventContentType EventContentType, int32 PointIndex);
	void SetAvatarEffect(FAvatarEffectType AvatarEffectType);
	void SetAvatarFrame(FAvatarFrameType AvatarFrameType);

private:
	void SetEmpty();

	UPROPERTY()
	UQ6TextBlock* ItemIdText;

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* CategoryText;

	UPROPERTY()
	UTextBlock* OwnedText;

	UPROPERTY()
	UTextBlock* AmountText;

	UPROPERTY()
	UTextBlock* ItemInfoText;

	UPROPERTY()
	UTextBlock* LootInfoText;
};

UCLASS()
class Q6_API UItemWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetLoot(int32 LootId, int32 Count = 1);
	void SetItem(const FItemData& ItemData);

	void SetChecked(bool CheckedFlag);
	void SetRewardType(ERewardType RewardType);

	void SetBagItem(const FBagItemType& BagItemType, int32 Count = 1);
	void SetCharacter(const FCharacterType& CharacterType, int32 InCount = 1);
	void SetRelic(const FRelicType& RelicType, int32 InCount = 1);
	void SetSculpture(const FSculptureType& SculptureType, int32 InCount = 1);
	void SetLobbyTemplate(const FLobbyTemplateType& LobbyTemplateType);
	void SetCurrency(ECurrencyType CurrencyType, int32 Count = 1);
	void SetAvatarEffect(FAvatarEffectType AvatarEffectType);
	void SetAvatarFrame(FAvatarFrameType AvatarFrameType);
	void SetPoint(EPointType PointType, int32 Count = 1);
	void SetMenu();
	void SetArtifact(int32 ArtifactIndex);
	void SetPet(FPetType PetType);
	void SetPetSkill(const FCMSLootDataRow& LootDataRow);
	void SetVacationSpot();
	void SetSpecial(FSpecialType SpecialType);
	void SetDropBox(int32 DropBoxSet, EDropBoxType DropBoxType, int32 Count);
	void SetEventPoint(FEventContentType InEventContentType, int32 InType, int32 InCount = 1);

	void SetVisibleCount(bool bInVisible);
	void SetNewMark(bool bInVisible);

	void OpenItemDetail();

	FSimpleDelegate OnItemClicked;

private:
	void SetItemId(int32 ItemType);

	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UBorder* CheckedBorder;

	UPROPERTY()
	UBorder* OwnedBorder;

	UPROPERTY()
	UBorder* RewardTypeBorder;

	UPROPERTY()
	UTextBlock* CountText;

	UPROPERTY()
	UTextBlock* RewardText;

	UPROPERTY()
	UTextBlock* ItemIdText;

	UPROPERTY()
	UImage* NewMarkImage;

	UPROPERTY(EditDefaultsOnly, Category = "TypeFrameColor")
	TArray<FLinearColor> RewardFrameColors;

	EItemCategory Category;
	int32 Type;
	FEventContentType EventContentType;

	const FLinearColor& GetRewardFrameColor(ERewardType RewardType);
};


UCLASS()
class Q6_API UItemMaterialWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemMaterialWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetMaterial(FBagItemType ItemType, int32 RequiredAmount);

private:
	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UTextBlock* RequiredAmountText;
};


UCLASS()
class Q6_API UMaterialBoxWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UMaterialBoxWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetMaterials(const TArray<const FCMSBagItemRow*>& MaterialItemRows, const TArray<int32>& MaterialCount, int32 ReduceCount = 0);
	void SetMaterial(const FCMSBagItemRow& MaterialItemRow, int32 MaterialCount);

private:
	static const int32 MaxMaterialCount = 3;

	UPROPERTY()
	TArray<UItemMaterialWidget*> MaterialWidgets;
};

UCLASS()
class Q6_API UEquipIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UEquipIconWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetEmpty();
	void SetRelic(const FRelicInfo& RelicInfo);
	void SetSculpture(const FSculptureInfo& SculptureInfo);

private:
	void OpenEquipDetail();

	UPROPERTY()
	UImage* IconImage;

	FItemIconInfo EquipInfo;
};

UCLASS()
class Q6_API UItemCardWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemCardWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void OpenItemDetail();

	void SetEmpty();
	void SetRemoval();

	void SetForSummon(bool bNew, EItemGrade Grade);
	void SetForLobbySetting(bool bTemplateIncluded, bool bOwned);

	void SetSelectType(EItemSelectType InSelectType);

	void SetSelected(bool bInSelected);
	void SetHighlight(bool bInHighlight);
	void SetChecked(bool bInChecked);
	void SetNumber(int32 InNumber);

	// seperated its outlook and selectable function
	void SetSelectable(bool bInSelectable, bool bInDimmed = false);

	void SetReasonText(const FText& Reason, EItemSelectableReasonType ReasonType = EItemSelectableReasonType::Default);

	void SetToggleLocked();
	void SetLocked(bool bLocked);
	void SetUsed(bool bInUsed);
	void SetNewMark(bool bNewly);
	void SetCharMissionNewMarkVisibility(ESlateVisibility InVisibility);

	void SetUltSkillLevel(int32 SkillLevel);

	void SetCharacter(const FCharacterInfo& InCharacterInfo);	// Owned character
	void SetSystemJoker(const FCharacterInfo& InCharacterInfo);
	void SetUserJoker(const FCharacterInfo& InCharacterInfo, const FCharacterBond& InCharacterBond, bool bFriendJoker);

	void SetSculpture(const FSculptureInfo& InSculptureInfo);
	void SetRelic(const FRelicInfo& InRelicInfo);

	void SetDefaultCharacter(FCharacterType CharacterType);
	void SetDefaultRelic(FRelicType RelicType);
	void SetDefaultSculpture(FSculptureType SculptureType);
	
	EItemSelectType GetSelectedType() const { return SelectType; }

	FCharacterId GetCharacterId() const;
	FSculptureId GetScuptureId() const;
	FRelicId GetRelicId() const;

	int64 GetItemId() const { return ItemInfo.Id; }
	const FItemIconInfo& GetItemInfo() const { return ItemInfo; }
	bool IsReasonEmpty() const { return ReasonText->GetText().IsEmpty(); }

	FItemCardClickedDelegate OnItemClickedDelegate;
	FItemCardClickedDelegate OnItemLockedDelegate;

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void SetSelectEnabled(bool bInEnabled);

	UFUNCTION(BlueprintImplementableEvent)
	void SetTagVisible(bool bInVisible);

	UFUNCTION(BlueprintImplementableEvent)
	void SetCharacterCard();

	UFUNCTION(BlueprintImplementableEvent)
	void SetEquipCard();

	UFUNCTION(BlueprintImplementableEvent)
	void SetRemovalCard();

	UFUNCTION(BlueprintImplementableEvent)
	void SetCardSelect(EItemSelectType InSelectType);

private:
	void SetCharacterInternal(const FCharacterInfo& InCharacterInfo, const FCharacterBond& InCharacterBond, EAttributeCategory AttributeType);

	void SetTags(bool bUsed, bool bLocked);
	void SetItem(int32 ItemType, EItemGrade Grade, int32 Star, int32 Moon = 0);

	UFUNCTION()
	void OnSelectButtonClicked();
	void OnItemLockChanged();

	UPROPERTY(EditAnywhere)
	FSlateBrush EmptyIcon;

	UPROPERTY(EditAnywhere)
	bool bSelectable;

	UPROPERTY(EditDefaultsOnly)
	TArray<FLinearColor> ReasonColors;

	UPROPERTY(EditDefaultsOnly)
	TArray<FLinearColor> ReasonDisabledBgColors;

	UPROPERTY()
	UImage* CharIconImage;

	UPROPERTY()
	UImage* EquipIconImage;

	UPROPERTY()
	UImage* LockedImage;

	UPROPERTY()
	UImage* NewImage;

	UPROPERTY()
	UImage* CharMissionNewImage;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* SummonNewImage;

	UPROPERTY()
	UImage* SummonGradeImage;

	UPROPERTY()
	UQ6RichTextBlock* LevelText;

	UPROPERTY()
	UStarBarWidget* StarBarWidget;

	UPROPERTY()
	UImage* FrameImage;

	UPROPERTY()
	UTextBlock* ItemIdText;

	UPROPERTY()
	UImage* DisabledImage;

	UPROPERTY()
	UTextBlock* ReasonText;

	UPROPERTY()
	UTextBlock* CheckedNumberText;

	UPROPERTY()
	UImage* OptionImage;

	UPROPERTY()
	UQ6Button* SelectButton;

	UPROPERTY()
	UTextBlock* UltSkillLevelText;

	// Fields

	FItemIconInfo ItemInfo;
	EItemSelectType SelectType;
};


UCLASS()
class Q6_API UItemLevelWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemLevelWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCharacter(int32 Level, int32 Star, int32 Moon);
	void SetEquip(int32 Level, int32 Star);

	void SetVisibleStar(bool bInVisible);

	void PlayDefaultAnim() { PlayAnimation(DefaultAnim); }
	void PlayPromoteAnim() { PlayAnimation(PromoteAnim); }
	void PlayLevelUpAnimation(bool bLevelUp) { PlayAnimation(bLevelUp ? LevelUpAnim : DefaultAnim); }

private:
	UPROPERTY(Transient)
	UWidgetAnimation* DefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LevelUpAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* PromoteAnim;

	UPROPERTY()
	UStarBarWidget* StarBarWidget;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UTextBlock* MaxLevelText;
};


UCLASS()
class Q6_API UItemStatusWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemStatusWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetItem(const FItemIconInfo& ItemInfo);

private:
	void SetCharacter(EAttributeCategory AttributeType, FCharacterType InCharacterType, EItemGrade Grade, int32 Level, int32 Xp, int32 Star, int32 Moon);
	void SetRelic(FRelicType RelicType, EItemGrade Grade, int32 Level, int32 Xp, int32 Star, int32 Tier);
	void SetSculpture(FSculptureType SculptureType, EItemGrade Grade, int32 Level, int32 Xp, int32 Star, int32 Tier);

	void SetXp(int32 Level, int32 MaxLevel, int32 RemainXp, int32 ReqXp);
	void SetBond(FCharacterType InCharacterType);
	void SetBond(int32 Temperature, int32 NextLevel, float XpRatio, int32 LeftXp);

	void PlayItemStatusAnimation(const EItemStatusAnimType InAnimType);

	UFUNCTION()
	void OnBondInfoButtonClicked();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> ItemStatusAnims;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UTextBlock* MaxLevelText;

	UPROPERTY()
	UProgressBar* XpBar;

	UPROPERTY()
	UTextBlock* RemainXpText;

	UPROPERTY()
	UQ6TextBlock* BondTemperature;

	UPROPERTY()
	UQ6Button* BondInfoButton;

	UPROPERTY()
	UProgressBar* BondBar;

	UPROPERTY()
	UTextBlock* RemainBondText;

	UPROPERTY()
	UStatWidget* HpStat;

	UPROPERTY()
	UStatWidget* AtkStat;

	UPROPERTY()
	UStatWidget* DefStat;

	UPROPERTY()
	URichTextBlock* EffectsText;

	FCharacterType CharacterType;
};


UCLASS()
class Q6_API UTurnSkillDescWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UTurnSkillDescWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void SetSkill(const FSlateBrush& TurnSkillIcon, int32 InSkillType, int32 Level);
	void SetSkillRow(const FSlateBrush& TurnSkillIcon, const FCMSSkillRow& SkillRow, int32 Level);

private:
	UPROPERTY()
	UTurnSkillIconWidget* SkillIconWidget;

	UPROPERTY()
	UTextBlock* SkillNameText;

	UPROPERTY()
	URichTextBlock* SkillDescText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UQ6TextBlock* CooldownText;

	UPROPERTY()
	UVerticalBox* SkillInfoBox;
};


UCLASS()
class Q6_API UTurnSkillDetailWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetTurnSkills(FUnitType UnitType, int32 TurnSkill1Level, int32 TurnSkill2Level, int32 TurnSkill3Level);

private:
	UPROPERTY()
	TArray<UTurnSkillDescWidget*> TurnSkillDescWidgets;
};

UCLASS()
class Q6_API UAttackSkillDetailWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetSkills(const FCMSUnitRow& UnitRow, int32 UltLevel, int32 SupportLevel);

private:

	// Ultimate skill

	UPROPERTY()
	UTextBlock* UltLevelText;

	UPROPERTY()
	UTextBlock* UltNameText;

	UPROPERTY()
	URichTextBlock* UltDescText;

	UPROPERTY()
	USkillIconWidget* UltIconWidget;

	// Support skill

	UPROPERTY()
	UTextBlock* SupportLevelText;

	UPROPERTY()
	UTextBlock* SupportNameText;

	UPROPERTY()
	URichTextBlock* SupportDescText;

	UPROPERTY()
	USkillIconWidget* SupportIconWidget;
};

UCLASS()
class Q6_API UItemDescWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetItem(const FItemIconInfo& ItemInfo);

private:
	void SetRelic(FRelicType RelicType);
	void SetSculpture(FSculptureType SculptureType);
	void SetCharacter(FCharacterType CharacterType);

	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	URichTextBlock* ContentText;
};

UCLASS()
class Q6_API UItemDetailWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual bool OnBack() override;
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action);

	void SetItem(const FItemIconInfo& InItemInfo);

	FSimpleDelegate OnLockedDelegate;

protected:
	UFUNCTION(BlueprintNativeEvent)
	void InitItemDetail(EDetailItemType InItemType);
	void InitItemDetail_Implementation(EDetailItemType InItemType);

	UFUNCTION(BlueprintImplementableEvent)
	void InitIllustMode(bool bInFinalIllust);

	UFUNCTION(BlueprintImplementableEvent)
	void SetIllustChangeButtonEnabled(bool bInEnabled);

	UFUNCTION(BlueprintImplementableEvent)
	void SetItemDetialWidgetAchievementsState(bool bLocked);

	UFUNCTION(BlueprintNativeEvent)
	void SetFullView(EItemDetailMode InDetailMode, EDetailItemType InItemType, bool bInFullView);
	void SetFullView_Implementation(EItemDetailMode InDetailMode, EDetailItemType InItemType, bool bInFullView);

	UFUNCTION(BlueprintNativeEvent)
	void SetDetailMode(EItemDetailMode InDetailMode, bool bInBack = false);
	void SetDetailMode_Implementation(EItemDetailMode InDetailMode, bool bInBack = false);

private:
	static const int32 MaxSubQuickButtonCount = 3;

	void SetCharacter();
	void SetRelic();
	void SetSculpture();
	void SetExpCard();
	void SetUltimateSculpture();

	void SetCharacterIllust(bool bInFinalIllust);

	void SetQuickMenuVisible(bool bInVisible);
	void SetQuickButtons();

	void SetAchievementsButtonState();
	bool HasAchivementsCharacter();

	void SetLobbyUnit(FCharacterType CharacterType);

	bool IsNonCharacterDetail();

	void OnDetailSwipeSetPage(UWidget* ViewWidget, int32 PageNum);
	void OnDetailSwipeFocusedPage(int32 FocusingPage);

	void OnMainQuickButtonClicked(EUpgradeCharacterCategory Category);
	void OnSubQuickButtonClicked(int32 Index);

	UFUNCTION()
	void OnUpgradeButtonClicked();

	UFUNCTION()
	void OnLockChecked(bool bInChecked);

	UFUNCTION()
	void OnIllustChangeButtonClicked();

	UFUNCTION()
	void OnClearButtonClicked();

	UFUNCTION()
	void OnQuickMenuButtonClicked();

	UFUNCTION()
	void OnAchievementsButtonClicked();

	UFUNCTION()
	void OnUnitViewButtonClicked();

	UFUNCTION()
	void OnCopyItemIdButtonClicked();

	// Widgets

	UPROPERTY()
	UItemBigCardWidget* IllustCardWidget;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UStarBarWidget* StarBarWidget;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* OptionImage;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* NickNameText;

	UPROPERTY()
	UQ6Button* UpgradeButton;

	UPROPERTY()
	UImage* UpgradeNewMarkImage;

	UPROPERTY()
	UCheckBox* LockButton;

	UPROPERTY()
	UQ6Button* IllustChangeButton;

	UPROPERTY()
	UQ6Button* AchievementsButton;

	UPROPERTY()
	UImage* AchievementsNewMarkImage;

	UPROPERTY()
	UButton* UnitViewButton;

	UPROPERTY()
	UCharacterVoiceWidget* CharacterVoiceWidget;

	UPROPERTY()
	UVarietyPageSwipeWidget* DetailSwipeWidget;

	UPROPERTY()
	UBorder* CharacterDesignerBox;

	UPROPERTY()
	UBorder* IllustratorBox;

	UPROPERTY()
	UBorder* CastingVoiceBox;

	UPROPERTY()
	UBorder* CastingActorBox;

	UPROPERTY()
	UTextBlock* CharacterDesignerNameText;

	UPROPERTY()
	UTextBlock* IllustratorNameText;

	UPROPERTY()
	UTextBlock* CastingVoiceNameText;

	UPROPERTY()
	UTextBlock* CastingActorNameText;

	UPROPERTY()
	UBorder* BubbleBox;

	UPROPERTY()
	UTextBlock* BubbleText;

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UButton* QuickMenuButton;

	UPROPERTY()
	TArray<UQ6Button*> MainQuickButtons;

	UPROPERTY()
	TArray<UImage*> MainQuickNewMarkImages;

	UPROPERTY()
	TArray<UQ6Button*> SubQuickButtons;

	UPROPERTY()
	TArray<UTextBlock*> SubQuickTexts;

	UPROPERTY()
	TArray<UImage*> SubQuickNewMarkImages;

	UPROPERTY()
	UTextBlock* ItemIdText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* ShowArtistAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HideArtistAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShowBubbleAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HideBubbleAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ToNormalArtAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ToFinalArtAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TArray<TAssetSubclassOf<UWidget>> CharacterDetailWidgetClasses;

	UPROPERTY(EditDefaultsOnly)
	TArray<TAssetSubclassOf<UWidget>> EquipDetailWidgetClasses;

	UPROPERTY(EditDefaultsOnly)
	TArray<TAssetSubclassOf<UWidget>> ExpCardDetailWidgetClasses;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> DefaultBGTexture;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> DefaultIllustTexture;

	FItemIconInfo ItemInfo;
	EItemDetailMode DetailMode;
	EDetailItemType DetailType;

	bool bFullView;
	bool bQuickMenuVisible;
	bool bCanIllustChange;

	int32 CurDetailSwipePage;
	int32 ShowArtistDetailSwipePage;
};

UCLASS()
class Q6_API USimpleItemCardWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPortalCharacter(const FCharacterInfo& CharacterInfo);
	void SetPortalRelic(const FRelicInfo& RelicInfo);
	void SetPortalSculpture(const FSculptureInfo& SculptureInfo);
	void SetBondCharacter(const FBondHistory& BondHistory);
	void SetVacationCharacter(const FCharacterInfo& CharacterInfo);

	FInt64ParamDelegate OnItemCardClickedDelegate;

private:
	static const int32 EquipMaxStar = 5;

	void SetCharacter(const FCharacterInfo& CharacterInfo, EBondCategory BondCategory, int32 BondXp, int32 BondLevel);
	void SetItemEnabled(bool bInEnabled);
	void SetItemType(int32 ItemType);

	UFUNCTION()
	void OnSelectButtonClicked();

	// Widgets

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* EquipImage;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UStarBarWidget* StarBarWidget;

	UPROPERTY()
	UImage* TierImage;

	UPROPERTY()
	UQ6RichTextBlock* LevelText;

	UPROPERTY()
	UQ6TextBlock* ReasonText;

	UPROPERTY()
	UProgressBar* BondBar;

	UPROPERTY()
	UQ6TextBlock* TemperatureText;

	UPROPERTY()
	UTextBlock* GetBondPointText;

	UPROPERTY()
	UImage* BondUpImage;

	UPROPERTY()
	UImage* FrameImage;

	UPROPERTY()
	UTextBlock* ItemTypeText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* DisabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EnabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CharacterSetAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EquipSetAnim;

	// Fields

	int64 ItemId;
};

UCLASS()
class Q6_API UItemBigCardWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemBigCardWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetSummonResult(const FSummonInfo& Info);
	void SetItemDetail(const FItemIconInfo& ItemInfo);

	void SetCharacter(const FCharacterType CharacterType);
	void SetRelic(const FRelicType RelicType);
	void SetSculpture(const FSculptureType& SculptureType);

	UFUNCTION(BlueprintImplementableEvent)
	void SetFrameVisible(bool bVisible);

	UFUNCTION(BlueprintImplementableEvent)
	void SetItemEnabled(bool bInEnabled);

	FSimpleDelegate OnActionButtonClickedDelegate;

private:
	void SetFrame(EDetailItemType DetailType);

	UFUNCTION()
	void OnActionButtonClicked();

	UPROPERTY()
	UNamedSlot* UltimateWidgetSlot;

	UPROPERTY()
	UImage* PictureImage;

	UPROPERTY()
	UImage* FrameImage;

	UPROPERTY(Transient)
	UWidgetAnimation* DecoLoopAnim;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> FrameBrushes;
};

UCLASS()
class Q6_API URewardItemWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetItem(const FItemData& InItemData);
	void SetEventPoint(const FItemData& InItemData, FEventContentType InEventContentType);

	void SetCheckInItem(const FCMSLootDataRow& LootDataRow, int32 CurrentRewardDay = 0, int32 RewardDayCount = 0);
	void SetCheckInType(ECheckInType CheckInType, bool bDayCount);
	void SetEventRewardItem(const FItemData& InItemData, int32 InCurrentPoint, int32 InAccumPoint);

private:
	UPROPERTY()
	UBorder* DayCountBorder;

	UPROPERTY()
	UTextBlock* DayCountText;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY(Transient)
	UWidgetAnimation* RotationRewardAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AnniversaryRewardAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* AlreadyAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NowAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* YetAnim;
};


UCLASS()
class Q6_API UItemSelectActionWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void InitActionMode(bool bSelect, bool bDetail, bool bLock);
	void SetSelectedCount(int32 Count, int32 MaxCount);
	void SetSelectedCount(int32 Count);

	void SelectDefaultActionMode();

	EItemActionType GetSelectedActionType() const { return ActionType; }

	FSimpleDelegate OnActionModeChangedDelegate;

private:
	void OnActionModeChanged(int32 ActionModeIndex);

	UPROPERTY()
	UBorder* SelectedBorder;

	UPROPERTY()
	URichTextBlock* SelectedCountText;

	UPROPERTY()
	UToggleButtonBoxWidget* ActionBoxWidget;

	EItemActionType ActionType;
};


UCLASS()
class Q6_API UTraitsDetailWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacter(FCharacterType CharacterType);

private:
	static const int32 MaxNormalSkillCount = 5;

	UPROPERTY()
	TArray<USkillNoteCardWidget*> SkillNoteCardWidgets;

	UPROPERTY()
	UDynamicListWidget* PassiveBuffListWidget;

	UPROPERTY()
	UTextBlock* AceBonusText;

	UPROPERTY()
	UTextBlock* BreakBonusText;

	UPROPERTY()
	UTextBlock* CloserBonusText;
};
