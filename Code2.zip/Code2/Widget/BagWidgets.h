// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"
#include "LobbyHUDWidget.h"

#include "BagWidgets.generated.h"

struct FBagItemType;
enum class EPointType : uint8;

class UItemWidget;

/**
 * UBagItemEntryWidget
 */
UCLASS()
class Q6_API UBagItemEntryWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPoint(EPointType PointType, int32 Amount);
	void SetBagItem(FBagItemType BagItemType, int32 Amount);
	void SetEventPoint(FEventContentType EventContentType, int32 PointIndex, int32 Amount);

private:
	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* TimeLeftText;

	UPROPERTY()
	UTextBlock* OwnedAmountText;

};

/**
 * UBagWidget
 */
UCLASS()
class Q6_API UBagWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UBagWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;

protected:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Bag; }

private:
	void SetItemList();

	UPROPERTY()
	UDynamicListWidget* BagItemListWidget;
};
