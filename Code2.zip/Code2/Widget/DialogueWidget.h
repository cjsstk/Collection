// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Define.h"
#include "Q6Enum.h"
#include "Q6UiDefine.h"
#include "LobbyHUDWidget.h"
#include "PopupWidgets.h"

#include "DialogueWidget.generated.h"

class UConfirmPopupWidget;
class UDialogueLogEntryWidget;
class UVerticalList;
class UQ6Button;
class UDialogueSelectWidget;
class UDialogueSkipWidget;

struct FCMSDialogueRow;

/**
 * Dialogue Widget
 */
UCLASS()
class Q6_API UDialogueWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

private:
	enum class EBubbleUIType : uint8
	{
		Default,
		System,
		Think,
		Quest,
		Black,
	};

	enum class EBubbleState : uint8
	{
		None,
		Monologue,
		Talk,
		System,
		Think,
		Quest,
		Black,
	};

	enum class EBubbleSoundTick : uint8
	{
		None,
		Pre,
		Voice,
		Post,
	};

	enum class EBubbleTextTick : uint8
	{
		None,
		Bubble,
		AutoWaitSound,
		EndWait,
	};

	enum class EChatState : uint8
	{
		None,
		LeftBegin,
		LeftContinue,
		RightBegin,
		RightContinue,
		System,
	};

public:
	UDialogueWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	virtual void OnEnterMenu() override;

	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void InitWidget(EDialogueType InDialogueType, const FText& InSummary);

	bool ChangeDialogueMode(int32 Mode, const FText& AreaName);
	void ShowDialogueText(const FCMSDialogueRow& InRow);
	void ShowChoices(const FCMSDialogueRow& InRow, const TArray<FText>& Choices, bool bInBanChoice);

	void ProcessAreaName(const FText& AreaName);

	void SetSoundData(const FName& InVoiceName, const FCMSDialogueRow& InRow);
	void EnableNextClick(bool bEnable);

	void ShowTopOnly();
	void HideForStorySequence(bool bHide);

	void OnDialogueStart();
	void OnDialogueEnd(bool bAlpha);

	bool IsChatMode() const { return (DialogueMode == EDialogueMode::Chat); }
	bool IsNormalMode() const { return (DialogueMode == EDialogueMode::Normal); }

	bool IsAutoPlaying() const;
	bool IsFastForwarding() const { return bFastForwarding; }
	bool IsNoBubbleTextState() const;

	FSimpleDelegate DialogueTitleAnimFinishedDelegate;
	FSimpleDelegate DialogueEndAnimFinishedDelegate;

	FSimpleDelegate ShowNextDialogueDelegate;

	FBanChoiceParamDelegate BanChoiceDelegate;
	FSimpleDelegate SkipConfirmedDelegate;
	FSimpleDelegate BottomSkipDelegate;

	static double FastForwardSeconds;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Dialogue; }

private:
	float GetScaledTextingDelay() const;
	float GetScaledTextEndDelay() const;

	void ShowTextNormal();
	void ShowTextChat(int32 LeftModel, int32 RightModel);

	void FireBubbleText();
	void FireNormalBubble();
	void FireChatBubble();
	void ClearTextBlock();

	bool IsBubbleShowing() const;
	bool IsSoundPlaying() const;
	bool IsSkipEnabled() const;

	void ShowBubble();
	void BreakBubble();
	void BubbleTextTick();
	void SetBubbleTextTick(EBubbleTextTick InTick);

	URichTextBlock* GetTextBlock();
	float GetTextEndDelay() const;

	void BubbleSoundTick();
	void PlayBubbleSound(EBubbleSoundTick BeginTick);
	void StopBubbleSound();

	void AddTextLog();
	void AddChoiceLog();

	void AddChatTitleLog(const FText& AreaName);
	void AddChatEndLog();

	void FireShowNextDialogueDelegate(bool bBreakable = true);
	void SetPressMarkVisibility(bool bVisible);

	bool JumpToEndDeferredFireTextAnims();

	void StartFastForward();
	void StopFastForward();

	void ShowSkipWidget(bool bShow);

	EBubbleState GetBubbleState(bool bNoName) const;
	bool IsNeedSpeakerState(EBubbleState State) const;

	void UpdateChatState(int32 LeftModel, int32 RightModel);
	void SetChatEntryStyle(UDialogueLogEntryWidget* Entry);

	UFUNCTION(BlueprintCallable)
	void OnDialogueEndHiding();

	UFUNCTION()
	void OnNextButtonPressed();

	UFUNCTION()
	void OnNextButtonReleased();

	UFUNCTION()
	void OnNextButtonClicked();

	UFUNCTION()
	void OnChoiceSelected(int32 Index);

	UFUNCTION()
	void OnChoiceSelectEnd(int32 Index);

	UFUNCTION()
	void OnSkipClicked();

	UFUNCTION()
	void OnBottomSkipClicked();

	UFUNCTION()
	void OnSkipConfirmed(EConfirmPopupFlag InFlag);

	UFUNCTION()
	void OnSkipConfirmDismiss();

	UFUNCTION()
	void OnLogButtonClicked();

	UFUNCTION()
	void OnLogCloseButtonClicked();

	UFUNCTION()
	void OnHideUIButtonClicked();

	UFUNCTION()
	void OnShowUIButtonClicked();

	UFUNCTION()
	void OnAutoToggleChecked(bool bChecked);

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<UDialogueSkipWidget> DialogueSkipClass;

	UPROPERTY(EditDefaultsOnly)
	FMargin NormalLogPadding;

	UPROPERTY(EditDefaultsOnly)
	float TextingDelay;

	UPROPERTY(EditDefaultsOnly)
	float NormalEndDelay;

	UPROPERTY(EditDefaultsOnly)
	float AutoEndDelay;

	UPROPERTY(EditDefaultsOnly)
	float NoBubbleAutoEndDelay;

	// Widget Animations

	UPROPERTY(Transient)
	UWidgetAnimation* NormalModeAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ChatModeAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* InitVisibilityAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DialogueStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DialogueEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DialogueAlphaEndAnim;
	
	UPROPERTY(Transient)
	UWidgetAnimation* SelectStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SelectEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ClearBubbleAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ResetBubbleAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShowAreaStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShowAreaEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShowUIAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HideUIAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShowLogAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateMonologueAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateTalkAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateSystemAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateThinkAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateQuestAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* StateBlackAnim;

	// Dialogue Panel Widgets

	UPROPERTY()
	UCanvasPanel* DialogueBottom;

	UPROPERTY()
	UCanvasPanel* SystemPanel;

	UPROPERTY()
	UButton* ScreenNextButton;

	UPROPERTY()
	UImage* ShowSpeedImage;

	UPROPERTY()
	UHorizontalBox* SpeakerBox;

	UPROPERTY()
	UBorder* SpeakerBorder;

	UPROPERTY()
	UTextBlock* SpeakerText;

	UPROPERTY()
	URichTextBlock* DialogueText;

	UPROPERTY()
	URichTextBlock* SystemText;

	UPROPERTY()
	UBackgroundBlur* StoryLogBack;

	UPROPERTY()
	UImage* PressMarkImage;

	UPROPERTY()
	UTextBlock* AreaNameText;

	UPROPERTY()
	UBorder* AreaBorder;

	UPROPERTY()
	UButton* HideUIButton;

	UPROPERTY()
	UButton* ShowUIButton;

	UPROPERTY()
	UButton* LogButton;

	UPROPERTY()
	UButton* LogCloseButton;

	UPROPERTY()
	UCheckBox* AutoToggleCheckBox;

	UPROPERTY()
	TArray<UDialogueSelectWidget*> ChoiceWidgets;
	
	UPROPERTY()
	UVerticalList* LogList;

	UPROPERTY()
	UDialogueSkipWidget* SkipWidget;

	UPROPERTY()
	TArray<UWidgetAnimation*> DeferredFireTextAnims;

	// Chat Mode

	UPROPERTY()
	UTextBlock* AreaTitleText;

	UPROPERTY()
	UVerticalList* ChatList;

	// Variables

	FText BubbleFullText;
	FText SpeakerName;

	EBubbleUIType BubbleUIType;
	EBubbleState BubbleState;

	EBubbleTextTick TextTick;
	float TextTickTime;
	int32 TextBubbleCandidates;

	EBubbleSoundTick SoundTick;
	float SoundTickTime;

	EDialogueType DialogueType;
	EDialogueMode DialogueMode;
	FText SummaryText;

	TOptional<float> NextButtonPressedTime;
	float FastForwardDeltaSeconds;

	EChatState ChatState;
	int32 LeftChatModel;
	int32 RightChatModel;

	FName VoiceName;
	int32 PreSoundType;
	int32 PostSoundType;

	bool bAutoPlay;
	bool bFastForwarding;

	bool bHoldAutoPlay;
	bool bShowChoice;
	bool bBanChoice;
	bool bEnableNextClick;
	bool bDialogueEnd;
};
