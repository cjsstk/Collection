#include "CodexWidgets.h"

#include "CommonWidgets.h"
#include "CodexManager.h"
#include "GameResource.h"
#include "ItemWidgets.h"
#include "LobbyPlayerController.h"
#include "NewMarkManager.h"
#include "SortingWidgets.h"
#include "Q6.h"
#include "SystemConst_gen.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Codex"), STAT_OnHSEventByCodex, STATGROUP_HSTORE);

UCodexWidget::UCodexWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurCodexCategory(ECodexCategory::None)
	, SelectedIconWidget(nullptr)
{
}

void UCodexWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CategoryBox = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("Category"));
	CategoryBox->OnToggleButtonClickedDelegate.BindUObject(this, &UCodexWidget::OnCategoryChanged);

	ItemScrollBox = CastChecked<UScrollBox>(GetWidgetFromName("ItemScroll"));
	ItemListPanel = CastChecked<UGridPanel>(GetWidgetFromName("ItemList"));
	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	NatureImage = CastChecked<UImage>(GetWidgetFromName("Nature"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	EquipCardWidget = CastChecked<UItemBigCardWidget>(GetWidgetFromName("EquipCard"));
	EquipCardWidget->OnActionButtonClickedDelegate.BindUObject(this, &UCodexWidget::OnEquipCardClicked);
}

void UCodexWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Codex);
	SubscribeToStore(EHSType::Ui);

	CurCodexCategory = ECodexCategory::None;
	CategoryBox->SetSelectedIndex(static_cast<int32>(ECodexCategory::CodexCharacter));
}

void UCodexWidget::OnLeaveMenu()
{
	Super::OnLeaveMenu();

	ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (LobbyPC)
	{
		LobbyPC->RestoreLobbyCameraFocalRegion();
		LobbyPC->OnInputPreciseTouchedDelegate.Unbind();
	}
}

void UCodexWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FCodexUIState* UIState = GetUIState()->CastToCodexUIState();
	check(UIState);

	if (UIState->CodexCategory != ECodexCategory::None)
	{
		RefreshList(UIState->CodexCategory);
	}
}

bool UCodexWidget::OnBack()
{
	if (CurCodexCategory == ECodexCategory::CodexCharacter)
	{
		ALobbyHUD* LobbyHUD = GetCheckedLobbyHUD(this);
		ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(GetLocalPlayerController(this));

		if (LobbyHUD->IsUICleared())
		{
			LobbyHUD->SetClearUI(false);
		}
		else
		{
			if (LobbyPC)
			{
				LobbyPC->OnInputPreciseTouchedDelegate.Unbind();
			}
		}

		return false;
	}

	const FCodexUIState& CodexUIState = GetHUDStore().GetUIStateManager().GetCodexUIState();
	if (CodexUIState.bEquipFullView)
	{
		ACTION_DISPATCH_CodexEquipFullView(false);
		return false;
	}

	return true;
}

void UCodexWidget::RefreshList(ECodexCategory CodexCategory)
{
	CurCodexCategory = CodexCategory;
	SelectedIconWidget = nullptr;
	SetEquipFullView(false);

	SetNewMarks();

	ItemScrollBox->ScrollToStart();

	switch (CodexCategory)
	{
		case ECodexCategory::CodexCharacter:
			SetCharacterList();
			break;
		case ECodexCategory::CodexSculpture:
			SetSculptureList();
			break;
		case ECodexCategory::CodexRelic:
			SetRelicList();
			break;
		default:
			check(false);
	}
}

void UCodexWidget::SelectDefaultItem()
{
	SelectItem(0);
}

void UCodexWidget::SelectItem(int32 InSelectedIndex)
{
	if (SelectedIconWidget)
	{
		SelectedIconWidget->SetSelected(false);
	}

	UCodexIconWidget* IconWidget = CastChecked<UCodexIconWidget>(ItemListPanel->GetChildAt(InSelectedIndex));
	SelectedIconWidget = IconWidget;

	SelectedIconWidget->SetSelected(true);
	const FItemIconInfo& ItemInfo = SelectedIconWidget->GetItemInfo();

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(ItemInfo.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);


	if (CurCodexCategory == ECodexCategory::CodexCharacter)
	{
		EquipCardWidget->SetVisibility(ESlateVisibility::Collapsed);
		NatureImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(FCharacterType(ItemInfo.Type));
		NameText->SetText(CharacterRow.GetUnit().DescName);

		const FSlateBrush& NatureBrush = GetUIResource().GetNatureTypeIcon(CharacterRow.GetUnit().NatureType);
		NatureImage->SetBrush(NatureBrush);

		ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(GetLocalPlayerController(this));
		if (LobbyPC)
		{
			LobbyPC->SetLobbyUnit(CharacterRow.CmsType(), false);
		}
	}
	else
	{
		NatureImage->SetVisibility(ESlateVisibility::Collapsed);

		EquipCardWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		EquipCardWidget->SetItemDetail(ItemInfo);

		const UCodexManager& CodexMgr = GetHUDStore().GetCodexManager();
		if (CurCodexCategory == ECodexCategory::CodexSculpture)
		{
			const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(FSculptureType(ItemInfo.Type));
			NameText->SetText(SculptureRow.DescName);

			bool bOwned = CodexMgr.FindSculpture(SculptureRow.CmsType());
			EquipCardWidget->SetItemEnabled(bOwned);
		}
		else if (CurCodexCategory == ECodexCategory::CodexRelic)
		{
			const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(FRelicType(ItemInfo.Type));
			NameText->SetText(RelicRow.DescName);

			bool bOwned = CodexMgr.FindRelic(RelicRow.CmsType());
			EquipCardWidget->SetItemEnabled(bOwned);
		}
	}
}

void UCodexWidget::SetNewMarks()
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	for (int32 i = 0; i < (int32)ECodexCategory::None; ++i)
	{
		bool bNewly = NewMarkMgr.GetCodexCategoryVisible((ECodexCategory)i);
		CategoryBox->SetToggleButtonNewMark(i, bNewly);
	}
}

void UCodexWidget::SetEquipFullView_Implementation(bool bInFullView)
{
	EquipCardWidget->SetFrameVisible(!bInFullView);
}

void UCodexWidget::OnUIClear()
{
	if (CurCodexCategory != ECodexCategory::CodexCharacter)
	{
		return;
	}

	ALobbyHUD* LobbyHUD = GetCheckedLobbyHUD(this);
	if (LobbyHUD->IsUICleared())
	{
		return;
	}

	LobbyHUD->SetClearUI(true);
}

void UCodexWidget::OnEquipCardClicked()
{
	const FCodexUIState& UIState = GetHUDStore().GetUIStateManager().GetCodexUIState();
	ACTION_DISPATCH_CodexEquipFullView(!UIState.bEquipFullView);
}

void UCodexWidget::OnCategoryChanged(int32 InChangedIndex)
{
	ECodexCategory CodexCategory = static_cast<ECodexCategory>(InChangedIndex);
	ACTION_DISPATCH_CodexCategoryChange(CodexCategory);
}

void UCodexWidget::SetCharacterList()
{
	ItemListPanel->ClearChildren();

	const UCodexManager& CodexManager = GetHUDStore().GetCodexManager();
	TArray<const FCMSCharacterRow*> CharRows = CodexManager.GetCodexCharacterRows();

	TArray<FCodexCharId> ClearNewIds;
	for (int32 i = 0; i < CharRows.Num(); ++i)
	{
		const FCMSCharacterRow* CharRow = CharRows[i];
		if (!CharRow)
		{
			Q6JsonLogRoze(Error, "UCodexWidget::SetCharacterList - Invalid codex character row");
			continue;
		}

		UCodexCharacterIconWidget* IconWidget = FindOrAddCharacterIcon(i);
		check(IconWidget);

		UGridSlot* IconSlot = ItemListPanel->AddChildToGrid(IconWidget);
		check(IconSlot);

		// Set slot

		IconSlot->SetLayer(CharRows.Num() - i);
		IconSlot->SetColumn(i);

		// Set info

		IconWidget->SetCharacterInfo(*CharRow);
		IconWidget->SetSelected(false);
		IconWidget->OnIconClickedDelegate.BindUObject(this, &UCodexWidget::SelectItem, i);

		const FCodexCharInfo* Info = CodexManager.FindChar(CharRow->CmsType());
		if (Info)
		{
			IconWidget->SetNewMarkVisible(Info->Newly);
			IconWidget->SetOwned(true);

			if (Info->Newly)
			{
				ClearNewIds.AddUnique(Info->CodexCharId);
			}
		}
		else
		{
			IconWidget->SetNewMarkVisible(false);
			IconWidget->SetOwned(false);
		}
	}

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (LobbyPC)
	{
		LobbyPC->OnInputPreciseTouchedDelegate.BindUObject(this, &UCodexWidget::OnUIClear);
	}

	SelectDefaultItem();

	if (ClearNewIds.Num())
	{
		CodexManager.ReqClearNewCharacterAll(ClearNewIds);
	}
}

void UCodexWidget::SetSculptureList()
{
	ItemListPanel->ClearChildren();

	const UCodexManager& CodexManager = GetHUDStore().GetCodexManager();
	TArray<const FCMSSculptureRow*> SculptureRows = CodexManager.GetCodexSculptureRows();

	TArray<FCodexSculptureId> ClearNewIds;
	for (int32 i = 0; i < SculptureRows.Num(); ++i)
	{
		const FCMSSculptureRow* SculptureRow = SculptureRows[i];
		if (!SculptureRow)
		{
			Q6JsonLogRoze(Error, "UCodexWidget::SetSculptureList - Invalid codex sculpture row");
			continue;
		}

		UCodexEquipIconWidget* IconWidget = FindOrAddEquipIcon(i);
		check(IconWidget);

		UGridSlot* IconSlot = ItemListPanel->AddChildToGrid(IconWidget);
		check(IconSlot);

		// Set slot

		IconSlot->SetLayer(SculptureRows.Num() - i);
		IconSlot->SetColumn(i);

		// Set info

		IconWidget->SetSculptureInfo(*SculptureRow);
		IconWidget->SetSelected(false);
		IconWidget->OnIconClickedDelegate.BindUObject(this, &UCodexWidget::SelectItem, i);

		const FCodexSculptureInfo* Info = CodexManager.FindSculpture(SculptureRow->CmsType());
		if (Info)
		{
			IconWidget->SetNewMarkVisible(Info->Newly);
			IconWidget->SetOwned(true);

			if (Info->Newly)
			{
				ClearNewIds.AddUnique(Info->CodexSculptureId);
			}
		}
		else
		{
			IconWidget->SetNewMarkVisible(false);
			IconWidget->SetOwned(false);
		}
	}

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (LobbyPC)
	{
		LobbyPC->SetLobbyUnit(CharacterTypeInvalid, false);
	}

	SelectDefaultItem();

	if (ClearNewIds.Num())
	{
		CodexManager.ReqClearNewSculptureAll(ClearNewIds);
	}
}

void UCodexWidget::SetRelicList()
{
	ItemListPanel->ClearChildren();

	const UCodexManager& CodexManager = GetHUDStore().GetCodexManager();
	TArray<const FCMSRelicRow*> RelicRows = CodexManager.GetCodexRelicRows();

	TArray<FCodexRelicId> ClearNewIds;
	for (int32 i = 0; i < RelicRows.Num(); ++i)
	{
		const FCMSRelicRow* RelicRow = RelicRows[i];
		if (!RelicRow)
		{
			Q6JsonLogRoze(Error, "UCodexWidget::SetRelicList - Invalid codex relic row");
			continue;
		}

		UCodexEquipIconWidget* IconWidget = FindOrAddEquipIcon(i);
		check(IconWidget);

		UGridSlot* IconSlot = ItemListPanel->AddChildToGrid(IconWidget);
		check(IconSlot);

		// Set slot

		IconSlot->SetLayer(RelicRows.Num() - i);
		IconSlot->SetColumn(i);

		// Set info

		IconWidget->SetRelicInfo(*RelicRow);
		IconWidget->SetSelected(false);
		IconWidget->OnIconClickedDelegate.BindUObject(this, &UCodexWidget::SelectItem, i);

		const FCodexRelicInfo* Info = CodexManager.FindRelic(RelicRow->CmsType());
		if (Info)
		{
			IconWidget->SetNewMarkVisible(Info->Newly);
			IconWidget->SetOwned(true);

			if (Info->Newly)
			{
				ClearNewIds.AddUnique(Info->CodexRelicId);
			}
		}
		else
		{
			IconWidget->SetNewMarkVisible(false);
			IconWidget->SetOwned(false);
		}
	}

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (LobbyPC)
	{
		LobbyPC->SetLobbyUnit(CharacterTypeInvalid, false);
	}

	SelectDefaultItem();

	if (ClearNewIds.Num())
	{
		CodexManager.ReqClearNewRelicAll(ClearNewIds);
	}
}

UCodexCharacterIconWidget* UCodexWidget::FindOrAddCharacterIcon(int32 SlotIndex)
{
	if (SlotIndex < CharacterIconWidgets.Num())
	{
		return CharacterIconWidgets[SlotIndex];
	}

	UCodexCharacterIconWidget* NewIconWidget = CreateWidget<UCodexCharacterIconWidget>(GetOwningPlayer(), CharacterIconClass.LoadSynchronous());
	check(NewIconWidget);

	CharacterIconWidgets.Add(NewIconWidget);

	return NewIconWidget;
}

UCodexEquipIconWidget* UCodexWidget::FindOrAddEquipIcon(int32 SlotIndex)
{
	if (SlotIndex < EquipIconWidgets.Num())
	{
		return EquipIconWidgets[SlotIndex];
	}

	UCodexEquipIconWidget* NewIconWidget = CreateWidget<UCodexEquipIconWidget>(GetOwningPlayer(), EquipIconClass.LoadSynchronous());
	check(NewIconWidget);

	EquipIconWidgets.Add(NewIconWidget);

	return NewIconWidget;
}

void UCodexWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByCodex);

	switch (InAction->GetActionType())
	{
		case EHSActionType::CodexClearNewAllResp:
			SetNewMarks();
			break;
		case EHSActionType::CodexEquipFullView:
		{
			const auto& Action = ACTION_PARSE_CodexEquipFullView(InAction);
			const bool& bEquipFullView = Action->GetVal();
			GetCheckedLobbyHUD(this)->RefreshNaviBar();
			SetEquipFullView(bEquipFullView);
			break;
		}

		case EHSActionType::CodexCategoryChange:
		case EHSActionType::CodexListCharResp:
		case EHSActionType::DevCharacterNewResp:
		case EHSActionType::DevRelicNewResp:
		case EHSActionType::DevSculptureNewResp:
			RefreshMenu();
			break;
	}
}

void UCodexIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	NewImage = CastChecked<UImage>(GetWidgetFromName("New"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UCodexEquipIconWidget::OnSelectButtonClicked);
}

void UCodexIconWidget::SetNewMarkVisible(bool bInNew)
{
	if (bInNew)
	{
		NewImage->SetVisibility(ESlateVisibility::HitTestInvisible);
	}
	else
	{
		NewImage->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCodexIconWidget::OnSelectButtonClicked()
{
	OnIconClickedDelegate.ExecuteIfBound();
}

void UCodexCharacterIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NatureImage = CastChecked<UImage>(GetWidgetFromName("Nature"));
}

void UCodexCharacterIconWidget::SetCharacterInfo(const FCMSCharacterRow& InCharacterRow)
{
	NewImage->SetVisibility(ESlateVisibility::Collapsed);

	UUIResource& UIResource = GetUIResource();
	const FItemGrade& ItemGrade = UIResource.GetItemGrade(InCharacterRow.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	const FSlateBrush& NatureBrush = UIResource.GetNatureTypeIcon(InCharacterRow.GetUnit().NatureType);
	NatureImage->SetBrush(NatureBrush);

	UGameResource& GameResource = GetGameResource();
	const FCharacterAssetRow& CharacterAssetRow = GameResource.GetCharacterAssetRow(InCharacterRow.CmsType());
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultLongIconTexture());

	SetCharacterItemInfo(InCharacterRow);
}

void UCodexCharacterIconWidget::SetCharacterItemInfo(const FCMSCharacterRow& InCharacterRow)
{
	const UCMS* CMS = GetCMS();
	if (!ensure(CMS))
	{
		return;
	}

	const FCMSCharacterXpRow& CharacterXpRow = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(CharacterFormulaConst::Q6_ELEVEN_MOON_MAX_LV));

	ItemIconInfo.Id = ITEM_INVALID;
	ItemIconInfo.AttributeType = EAttributeCategory::Character;
	ItemIconInfo.Type = InCharacterRow.Type;
	ItemIconInfo.Grade = InCharacterRow.Grade;
	ItemIconInfo.Star = MAX_STAR;
	ItemIconInfo.Moon = MAX_CHARACTER_MOON;
	ItemIconInfo.Tier = CombatCubeConst::Q6_MAX_TIER;
	ItemIconInfo.Level = CharacterFormulaConst::Q6_ELEVEN_MOON_MAX_LV;
	ItemIconInfo.Xp = CharacterXpRow.Acc;
	ItemIconInfo.BondXp = 0;

	ItemIconInfo.SetSkillLevels(CombatCubeConst::Q6_MAX_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL
		, CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL);
}

void UCodexEquipIconWidget::SetSculptureInfo(const FCMSSculptureRow& InSculptureRow)
{
	NewImage->SetVisibility(ESlateVisibility::Collapsed);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(InSculptureRow.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	UGameResource& GameResource = GetGameResource();
	const FSculptureAssetRow& SculptureAssetRow = GameResource.GetSculptureAssetRow(InSculptureRow.CmsType());
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(SculptureAssetRow.IconTexture);

	SetSculptureItemInfo(InSculptureRow);
}

void UCodexEquipIconWidget::SetRelicInfo(const FCMSRelicRow& InRelicRow)
{
	NewImage->SetVisibility(ESlateVisibility::Collapsed);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(InRelicRow.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	UGameResource& GameResource = GetGameResource();
	const FEquipAssetRow& EquipAssetRow = GameResource.GetRelicAssetRow(InRelicRow.CmsType());
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(EquipAssetRow.IconTexture);

	SetRelicItemInfo(InRelicRow);
}

void UCodexEquipIconWidget::SetSculptureItemInfo(const FCMSSculptureRow& InSculptureRow)
{
	const UCMS* CMS = GetCMS();
	if (!ensure(CMS))
	{
		return;
	}

	const FCMSItemXpRow& ItemXpRow = CMS->GetItemXpRowOrDummy(FItemXpType(CharacterFormulaConst::Q6_FIVE_STAR_MAX_LV));

	ItemIconInfo.Id = ITEM_INVALID;
	ItemIconInfo.AttributeType = EAttributeCategory::Sculpture;
	ItemIconInfo.Type = InSculptureRow.Type;
	ItemIconInfo.Grade = InSculptureRow.Grade;
	ItemIconInfo.Star = MAX_EQUIP_STAR;
	ItemIconInfo.Moon = 0;
	ItemIconInfo.Tier = CombatCubeConst::Q6_MAX_TIER;
	ItemIconInfo.Level = CharacterFormulaConst::Q6_FIVE_STAR_MAX_LV;
	ItemIconInfo.Xp = ItemXpRow.Acc;
	ItemIconInfo.BondXp = 0;

	ItemIconInfo.SetSkillLevels(0, 0, 0, 0, 0);
}

void UCodexEquipIconWidget::SetRelicItemInfo(const FCMSRelicRow& InRelicRow)
{
	const UCMS* CMS = GetCMS();
	if (!ensure(CMS))
	{
		return;
	}

	const FCMSItemXpRow& ItemXpRow = CMS->GetItemXpRowOrDummy(FItemXpType(CharacterFormulaConst::Q6_FIVE_STAR_MAX_LV));

	ItemIconInfo.Id = ITEM_INVALID;
	ItemIconInfo.AttributeType = EAttributeCategory::Relic;
	ItemIconInfo.Type = InRelicRow.Type;
	ItemIconInfo.Grade = InRelicRow.Grade;
	ItemIconInfo.Star = MAX_EQUIP_STAR;
	ItemIconInfo.Moon = 0;
	ItemIconInfo.Tier = CombatCubeConst::Q6_MAX_TIER;
	ItemIconInfo.Level = CharacterFormulaConst::Q6_FIVE_STAR_MAX_LV;
	ItemIconInfo.Xp = ItemXpRow.Acc;
	ItemIconInfo.BondXp = 0;

	ItemIconInfo.SetSkillLevels(0, 0, 0, 0, 0);
}
