// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6UiDefine.h"
#include "UMG.h"

#include "DialogueSkipWidget.generated.h"

class UButton;

UCLASS()
class Q6_API UDialogueSkipWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UDialogueSkipWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void ShowSkip(bool bShow);
	void ShowBottomSkip(bool bShow);

	FSimpleDelegate SkipDelegate;
	FSimpleDelegate BottomSkipDelegate;

private:
	UFUNCTION()
	void OnSkipClicked();

	UFUNCTION()
	void OnBottomSkipClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* SkipStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkipEndAnim;

	UPROPERTY()
	UButton* SkipButton;

	UPROPERTY()
	UButton* BottomSkipButton;
};
