// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "MailWidgets.h"

#include "CMSTable.h"
#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "LobbyHUD.h"
#include "MailManager.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6Util.h"
#include "WidgetUtil.h"
#include "NewMarkManager.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent MailSelect"), STAT_OnHSEventByMailSelect, STATGROUP_HSTORE);

static void SetMailNameText(UQ6TextBlock* NameText, const FItemData& ItemData)
{
	check(NameText);

	switch (ItemData.Category)
	{
		case ELootCategory::BagItem:
		{
			const FCMSBagItemRow& ItemRow = GetCMS()->GetBagItemRowOrDummy(FBagItemType(ItemData.Type));
			NameText->SetText(ItemRow.DescName);
			break;
		}
		case ELootCategory::CharacterCard:
		{
			const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(ItemData.Type));
			NameText->SetText(UnitRow.DescName);
			break;
		}
		case ELootCategory::SculptureCard:
		{
			const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(FSculptureType(ItemData.Type));
			NameText->SetText(SculptureRow.DescName);
			break;
		}
		case ELootCategory::RelicCard:
		{
			const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(FRelicType(ItemData.Type));
			NameText->SetText(RelicRow.DescName);
			break;
		}
		case ELootCategory::LobbyTemplate:
		{
			const FCMSLobbyTemplateRow& LobbyTemplateRow = GetCMS()->GetLobbyTemplateRowOrDummy(FLobbyTemplateType(ItemData.Type));
			NameText->SetText(LobbyTemplateRow.Name);
			break;
		}
		// Currency
		case ELootCategory::Gold:
		case ELootCategory::FreeGem:
		case ELootCategory::PaidGem:		// Fall through
		{
			NameText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "NumOfCurrency"),
				Q6Util::GetCurrencyText(GetCurrencyType(ItemData.Category)), FText::AsNumber(ItemData.Count)));
			break;
		}
		case ELootCategory::SummonTicket:
		case ELootCategory::SculpturePoint:
		case ELootCategory::RelicPoint:
		case ELootCategory::FriendshipPoint:
		case ELootCategory::SmallBattery:
		case ELootCategory::MediumBattery:
		case ELootCategory::LargeBattery:
		case ELootCategory::Lumicube:
		case ELootCategory::CharacterDisk:
		case ELootCategory::SculptureDisk:
		case ELootCategory::RelicDisk:		// Fall through
		{
			NameText->SetText(Q6Util::GetCurrencyText(GetCurrencyType(ItemData.Category)));
			break;
		}
		case ELootCategory::AvatarEffect:
		{
			NameText->SetText(Q6Util::GetLocalizedText("Lobby", "AvatarEffect"));
			break;
		}
		case ELootCategory::AvatarFrame:
		{
			NameText->SetText(Q6Util::GetLocalizedText("Lobby", "AvatarFrame"));
			break;
		}
		default:
		{
			Q6JsonLogRoze(
				Warning,
				"UMailListEntryWidget::SetItem - wrong lootcategory.",
				Q6KV("ELootCategory", static_cast<int>(ItemData.Category))
			);
			break;
		}
	}
}

void SetMailRewardText(UQ6TextBlock* RewardTypeText, EMailRewardType RewardType, ELootCategory LootCategory, int32 ReasonType)
{
	check(RewardTypeText);

	if (RewardType == EMailRewardType::SummonDisk)
	{
		const UCMS* CMS = GetCMS();

		FText SummonDiskRewardText = Q6Util::GetLocalizedText("Lobby", "SummonDiskReward");
		if (LootCategory == ELootCategory::CharacterDisk)
		{
			const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(FCharacterType(ReasonType));
			RewardTypeText->SetText(FText::Format(SummonDiskRewardText, CharacterRow.GetUnit().DescName));
		}
		else if (LootCategory == ELootCategory::RelicDisk)
		{
			const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(FRelicType(ReasonType));
			RewardTypeText->SetText(FText::Format(SummonDiskRewardText, RelicRow.DescName));
		}
		else if (LootCategory == ELootCategory::SculptureDisk)
		{
			const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(FSculptureType(ReasonType));
			RewardTypeText->SetText(FText::Format(SummonDiskRewardText, SculptureRow.DescName));
		}
		else
		{
			Q6JsonLogRoze(Warning, "GetMailRewardText - Invalid loot category", Q6KV("MailRewardType", (int32)RewardType));
			RewardTypeText->SetText(FText::GetEmpty());
		}

		return;
	}

	switch (RewardType)
	{
		case EMailRewardType::CheckIn:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "CheckInReward"));
			break;
		case EMailRewardType::BuyShop:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "PurchasedItem"));
			break;
		case EMailRewardType::GM:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "ServiceReward"));
			break;
		case EMailRewardType::Push:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "PushReward"));
			break;
		case EMailRewardType::Quest:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "QuestReward"));
			break;
		case EMailRewardType::WattRefund:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "WattRefund"));
			break;
		case EMailRewardType::WeeklyMission:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "WeeklyMissionReward"));
			break;
		case EMailRewardType::CharMission:
			RewardTypeText->SetText(Q6Util::GetLocalizedText("Lobby", "CharacterAchievement"));
			break;
		default:
			Q6JsonLogRoze(Warning, "GetMailRewardText - RewardType is wrong.", Q6KV("RewardType", static_cast<int>(RewardType)));
			RewardTypeText->SetText(FText::GetEmpty());
			break;
	}
}

UMailListEntryWidget::UMailListEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, MailId(FMailId::INVALID_VALUE)
	, bChecked(false)
	, bSelectButtonMode(false)
{

}

void UMailListEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ReceiveButton = CastChecked<UButton>(GetWidgetFromName("Receive"));
	ReceiveButton->OnClicked.AddUniqueDynamic(this, &UMailListEntryWidget::OnReceiveButtonClicked);

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));

	SelectBox = CastChecked<UCheckBox>(GetWidgetFromName("Select"));
	SelectBox->OnCheckStateChanged.AddUniqueDynamic(this, &UMailListEntryWidget::OnToggleButtonClicked);

	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	DateText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Date"));
	RewardTypeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RewardType"));
}

void UMailListEntryWidget::OnReceiveButtonClicked()
{
	if (bSelectButtonMode)
	{
		bChecked = !bChecked;
		SelectBox->SetIsChecked(bChecked);

		SetEntryType(bChecked ? EMailEntryType::Selected : EMailEntryType::Default);
		ACTION_DISPATCH_MailSelect();
		return;
	}

	TArray<FMailId> ReceiveMailIds;
	const UMailManager& MailManager = GetHUDStore().GetMailManager();
	ReceiveMailIds.Add(MailId);

	if (GetCheckedLobbyHUD(this)->CheckMaxItemNum(ReceiveMailIds))
	{
		return;
	}

	MailManager.ReqReceive(ReceiveMailIds);
}

void UMailListEntryWidget::OnToggleButtonClicked(bool bInIsChecked)
{
	SetEntryType(bInIsChecked ? EMailEntryType::Selected : EMailEntryType::Default);
	bChecked = bInIsChecked;
	ACTION_DISPATCH_MailSelect();
}

void UMailListEntryWidget::SetItem(const FItemData& InItemData)
{
	SetMailNameText(NameText, InItemData);

	ItemWidget->SetItem(InItemData);
}

void UMailListEntryWidget::SetMail(const FMailInfo& InMailInfo)
{
	SetEntryType(EMailEntryType::CheckBox);

	MailId = InMailInfo.MailId;

	if (InMailInfo.ExpireUtc != 0)
	{
		const FDateTime& ExpDate = Q6Util::UtcTimestampToLocalDateTime(InMailInfo.ExpireUtc);
		const FTimespan& ElapsedTime = ExpDate - FDateTime::Now();

		DateText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "TimeLeft"),
			Q6Util::GetRemainTimeText(ElapsedTime.GetTotalSeconds())));
	}
	else
	{
		DateText->SetText(Q6Util::GetLocalizedText("Common", "TimeIndefinitely"));
	}
	
	SetMailRewardText(RewardTypeText, InMailInfo.RewardType, InMailInfo.RewardItem.Category, InMailInfo.ReasonType);
	SetItem(InMailInfo.RewardItem);
}

void UMailListEntryWidget::SetMailLog(const FMailReceiveLog& InMailLog, int32 ReceiveUtc)
{
	SetEntryType(EMailEntryType::Log);

	MailId = InMailLog.MailId;

	DateText->SetText(Q6Util::GetHappendTime(ReceiveUtc));
	SetMailRewardText(RewardTypeText, InMailLog.RewardType, InMailLog.RewardItem.Category, InMailLog.ReasonType);
	SetItem(InMailLog.RewardItem);
}

void UMailListEntryWidget::SetReceivedMail(const FMailInfo& InMailInfo)
{
	SetEntryType(EMailEntryType::Received);

	DateText->SetVisibility(ESlateVisibility::Collapsed);
	SetMailRewardText(RewardTypeText, InMailInfo.RewardType, InMailInfo.RewardItem.Category, InMailInfo.ReasonType);
	SetItem(InMailInfo.RewardItem);
}

void UMailListEntryWidget::Uncheck()
{
	SetEntryType(EMailEntryType::Default);

	SelectBox->SetIsChecked(false);
	bChecked = false;
}

UMailRewardWidget::UMailRewardWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UMailRewardWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ShowAnim = GetWidgetAnimationFromName(this, "AnimShow");

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));

	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	RewardTypeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RewardType"));
}

void UMailRewardWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == ShowAnim)
	{
		RemoveFromParent();
	}
}

void UMailRewardWidget::SetRewardInfo(const FMailInfo& MailInfo)
{
	PlayAnimation(ShowAnim);

	ItemWidget->SetItem(MailInfo.RewardItem);
	SetMailNameText(NameText, MailInfo.RewardItem);
	SetMailRewardText(RewardTypeText, MailInfo.RewardType, MailInfo.RewardItem.Category, MailInfo.ReasonType);
}

UMailListPopupWidget::UMailListPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bReceiveButtonClicked(false)
{

}

void UMailListPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectedCountText = CastChecked<UTextBlock>(GetWidgetFromName("SelectedCount"));
	ReceivedNumText = CastChecked<UQ6TextBlock>(GetWidgetFromName("ReceivedNum"));
	NotReceiveText = CastChecked<UQ6TextBlock>(GetWidgetFromName("NotReceive"));

	UButton* CloseButton = CastChecked<UButton>(GetWidgetFromName("Close"));
	CloseButton->OnClicked.AddUniqueDynamic(this, &UPopupBaseWidget::ClosePopup);

	UQ6Button* ReceiveSelectedButton = CastChecked<UQ6Button>(GetWidgetFromName("ReceiveSelected"));
	ReceiveSelectedButton->OnClickedDelegate.BindUObject(this, &UMailListPopupWidget::OnMailReceive, true);

	ReceiveAllButton = CastChecked<UQ6Button>(GetWidgetFromName("ReceiveAll"));
	ReceiveAllButton->OnClickedDelegate.BindUObject(this, &UMailListPopupWidget::OnMailReceive, false);

	ToggleButtonBoxWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CategoryBox"));
	ToggleButtonBoxWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UMailListPopupWidget::OnTabSelected);

	MailListWidget = Cast<UDynamicListWidget>(GetWidgetFromName("MailList"));

	SubscribeToStore(EHSType::Mail);
	SubscribeToStore(EHSType::Ui);
}

void UMailListPopupWidget::Refresh(int32 InIndex /* = 0 */)
{
	UncheckAllMail();

	SetTitle(Q6Util::GetLocalizedText("Popup", TEXT("PostConfirmTitle")));
	ToggleButtonBoxWidget->SetSelectedIndex(InIndex);

	SetNewMarks();
}

void UMailListPopupWidget::OnTabSelected(int32 InIndex)
{
	UncheckAllMail();
	SetMailListPopupType(EMailListPopupType::AllReceive);

	EMailTabType MailTabType = EMailTabType(InIndex);
	switch (MailTabType)
	{
		case EMailTabType::Default:
			SetMails();
			break;
		case EMailTabType::Service:
			SetMails(true);
			break;
		case EMailTabType::Log:
			SetMailLogs();
			break;
		default:
			break;
	}

	int32 MailCount = MailListWidget->GetChildrenCount();
	ReceivedNumText->SetText(FText::AsNumber(MailCount));
}

void UMailListPopupWidget::SetMails(bool bService /* = false */)
{
	MailListWidget->ClearList();

	const UMailManager& MailManager = GetHUDStore().GetMailManager();
	const auto& MailInfos = MailManager.GetMailInfos();
	bool bIsEmpty = true;

	for (const auto& Iter : MailInfos)
	{
		const FMailInfo& MailInfo = Iter.Value;
		EMailType MailType = bService ? EMailType::Management : EMailType::Normal;

		if (MailInfo.Type == MailType)
		{
			UMailListEntryWidget* MailEntryWidget = CastChecked<UMailListEntryWidget>(MailListWidget->AddChildAtLastIndex());
			MailEntryWidget->SetMail(MailInfo);
			bIsEmpty = false;
		}
	}

	ReceiveAllButton->SetIsEnabled(!bIsEmpty);
	NotReceiveText->SetVisibility(bIsEmpty ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UMailListPopupWidget::SetMailLogs()
{
	SetMailListPopupType(EMailListPopupType::Log);

	MailListWidget->ClearList();

	const UMailManager& MailManager = GetHUDStore().GetMailManager();
	const auto& MailLogs = MailManager.GetMailReceiveLogs();

	NotReceiveText->SetVisibility(MailLogs.Num() == 0 ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	for (auto& Node : MailLogs)
	{
		UMailListEntryWidget* MailEntryWidget = CastChecked<UMailListEntryWidget>(MailListWidget->AddChildAtLastIndex());
		MailEntryWidget->SetMailLog(Node, Node.ReceiveUtc);
	}
}

void UMailListPopupWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByMailSelect);

	switch (Action->GetActionType())
	{
		case EHSActionType::MailSelect:
		{
			int32 NumOfCheckedMail = GetCheckedMailNum();
			bool bHasCheckedMail = NumOfCheckedMail != 0;

			if (bHasCheckedMail)
			{
				SetReceivedCount(NumOfCheckedMail);
			}

			for (int i = 0; i < MailListWidget->GetChildrenCount(); ++i)
			{
				UMailListEntryWidget* MailListEntryWidget = CastChecked<UMailListEntryWidget>(MailListWidget->FindChildAt(i));
				MailListEntryWidget->SetReceiveButtonMode(bHasCheckedMail);
			}

			SetMailListPopupType(bHasCheckedMail ? EMailListPopupType::SelectReceive : EMailListPopupType::AllReceive);
			break;
		}
		case EHSActionType::MailReceiveResp:
		{
			Refresh(ToggleButtonBoxWidget->GetSelectedIndex());

			const UMailManager& MailManager = GetHUDStore().GetMailManager();
			const TArray<FMailInfo> ReceivedMailInfos = MailManager.GetMailReceiveInfos();

			if (bReceiveButtonClicked)
			{
				GetCheckedLobbyHUD(this)->OpenMailReceivedPopupWidget(ReceivedMailInfos);
				bReceiveButtonClicked = false;
			}
			else
			{
				// Single item received by MailListEntryWidget clicked

				check(ReceivedMailInfos.Num() == 1);

				const FMailInfo& MailInfo = ReceivedMailInfos[0];

				if (!MailRewardWidget)
				{
					MailRewardWidget = CreateWidget<UMailRewardWidget>(GetLocalPlayerController(this), MailRewardWidgetClass.LoadSynchronous());
				}

				if (!MailRewardWidget->IsInViewport())
				{
					MailRewardWidget->AddToViewport(ZORDER_POPUP);
				}

				MailRewardWidget->SetRewardInfo(MailInfo);
			}
			break;
		}
		case EHSActionType::MailRefreshListResp:
		{
			Refresh(ToggleButtonBoxWidget->GetSelectedIndex());
			break;
		}
		default:
		{
			break;
		}
	}
}

void UMailListPopupWidget::OnMailReceive(bool bSelectedMail)
{
	bReceiveButtonClicked = true;

	TArray<FMailId> ReceiveMailIds;
	for (int i = 0; i < MailListWidget->GetChildrenCount(); ++i)
	{
		UMailListEntryWidget* MailListEntryWidget = CastChecked<UMailListEntryWidget>(MailListWidget->FindChildAt(i));
		if (MailListEntryWidget->IsChecked() || !bSelectedMail)
		{
			ReceiveMailIds.Add(MailListEntryWidget->GetMailId());
		}
	}

	if (GetCheckedLobbyHUD(this)->CheckMaxItemNum(ReceiveMailIds))
	{
		return;
	}

	const UMailManager& MailManager = GetHUDStore().GetMailManager();
	MailManager.ReqReceive(ReceiveMailIds);

	if (bSelectedMail)
	{
		UncheckAllMail();
		SetMailListPopupType(EMailListPopupType::AllReceive);
	}
}

int32 UMailListPopupWidget::GetCheckedMailNum()
{
	int32 NumOfCheckedMail = 0;

	for (int i = 0; i < MailListWidget->GetChildrenCount(); ++i)
	{
		UMailListEntryWidget* MailEntryWidget = CastChecked<UMailListEntryWidget>(MailListWidget->FindChildAt(i));
		if (MailEntryWidget->IsChecked())
		{
			NumOfCheckedMail++;
		}
	}

	return NumOfCheckedMail;
}

void UMailListPopupWidget::SetReceivedCount(int32 InNumOfSelect)
{
	SelectedCountText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "MailReceiveSelected"), FText::AsNumber(InNumOfSelect)));
}

void UMailListPopupWidget::UncheckAllMail()
{
	for (int i = 0; i < MailListWidget->GetChildrenCount(); ++i)
	{
		UMailListEntryWidget* MailEntryWidget = CastChecked<UMailListEntryWidget>(MailListWidget->FindChildAt(i));
		MailEntryWidget->SetReceiveButtonMode(false);
		MailEntryWidget->Uncheck();
	}
}

void UMailListPopupWidget::SetNewMarks()
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	const TArray<UUserWidget*>& ToggleButtons = ToggleButtonBoxWidget->GetToggleButtons();
	for (int32 i = 0; i < ToggleButtons.Num(); ++i)
	{
		ESlateVisibility SlateVisibility = ESlateVisibility::Collapsed;
		switch (i)
		{
			case 0:
				SlateVisibility = NewMarkMgr.GetNewMailVisibilityByMailType(EMailType::Normal);
				break;
			case 1:
				SlateVisibility = NewMarkMgr.GetNewMailVisibilityByMailType(EMailType::Management);
				break;
		}

		ToggleButtonBoxWidget->SetToggleButtonNewMark(i, SlateVisibility);
	}
}

UMailReceivedPopupWidget::UMailReceivedPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UMailReceivedPopupWidget::NativeConstruct()
{
	MailListWidget = Cast<UDynamicListWidget>(GetWidgetFromName("MailList"));

	UButton* YesButton = CastChecked<UButton>(GetWidgetFromName("Yes"));
	YesButton->OnClicked.AddUniqueDynamic(this, &UPopupBaseWidget::ClosePopup);
}

void UMailReceivedPopupWidget::SetMailLists(const TArray<FMailInfo> RewardInfos)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "PostReceivedTitle"));

	MailListWidget->ClearList();

	const UMailManager& MailManager = GetHUDStore().GetMailManager();

	for (const FMailInfo& RewardInfo : RewardInfos)
	{
		UMailListEntryWidget* MailEntryWidget = CastChecked<UMailListEntryWidget>(MailListWidget->AddChildAtLastIndex());
		MailEntryWidget->SetReceivedMail(RewardInfo);
	}
}
