// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "PointWidgets.h"

#include "BaseHUD.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "ItemWidgets.h"
#include "PowerPlantManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6Util.h"
#include "SystemConst_gen.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UPointWidget

UPointWidget::UPointWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, PointType(EPointType::Gold)
	, PointWidgetOption(EPointWidgetOption::IncludeEqual)
	, CurPoint(-1)
	, MaxPoint(-1)
{
}

void UPointWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	PointAmountText = CastChecked<UTextBlock>(GetWidgetFromName("PointAmount"));
	PointMaxText = CastChecked<UTextBlock>(GetWidgetFromName("PointMax"));
}

void UPointWidget::SetPointType(EPointType InPointType, EPointWidgetOption InPointWidgetOption)
{
	SetType(InPointType, InPointWidgetOption);

	const FPointIcon& PointIcon = GetUIResource().GetPointIcon(PointType);
	IconImage->SetBrush(PointIcon.SmallBrush);
}

void UPointWidget::SetPointType(ESummonPointType InPointType, EPointWidgetOption InPointWidgetOption)
{
	SetPointType(GetPointType(InPointType), InPointWidgetOption);
}

void UPointWidget::SetPointType(ECurrencyType InPointType, EPointWidgetOption InPointWidgetOption)
{
	SetPointType(GetPointType(InPointType), InPointWidgetOption);
}

void UPointWidget::SetEventPointType(FEventContentType InEventContentType, int32 InPointIndex, EPointWidgetOption InPointWidgetOption)
{
	SetType(EPointType::Event, InPointWidgetOption);

	const FEventListAssetRow* Row = GetGameResource().GetEventListAssetRow(InEventContentType);
	if (!Row->PointIcon.IsValidIndex(InPointIndex))
	{
		Q6JsonLogGunny(Warning, "UPointWidget::SetEventPointType - CurrencyIcon deos not exist.",
			Q6KV("EventContentType", InEventContentType),
			Q6KV("InPointIndex", InPointIndex));
	}

	IconImage->SetBrush(Row->PointIcon[InPointIndex]);
}

void UPointWidget::SetEventWattType(EEventContentCategory InEventContentCategory, EPointWidgetOption InPointWidgetOption)
{
	SetType(EPointType::Event, InPointWidgetOption);

	const FEventContentCategoryAssetRow* Row = GetGameResource().GetEventContentCategoryAssetRow(InEventContentCategory);
	if (Row->bUseWattIcon)
	{
		IconImage->SetBrush(Row->WattIcon);
	}
}

void UPointWidget::SetPoint(int64 InCurPoint, int64 InMaxPoint)
{
	bool bChanged = false;
	if (CurPoint != InCurPoint)
	{
		bChanged = true;
		CurPoint = InCurPoint;
		PointAmountText->SetText(FText::AsNumber(InCurPoint));
	}

	if (MaxPoint != InMaxPoint)
	{
		bChanged = true;
		MaxPoint = InMaxPoint;
		if (IsVisibleMaxPoint())
		{
			PointMaxText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Lobby", "PointAmount"),
				FText::GetEmpty(), FText::AsNumber(InMaxPoint)));
		}
	}

	if (bChanged)
	{
		SetPointColor();
	}
}

void UPointWidget::SetPointColor()
{
	if ((IsCompLessThan() && CurPoint < MaxPoint) ||
		(!IsCompLessThan() && CurPoint > MaxPoint) ||
		(IsIncludeEqual() && CurPoint == MaxPoint))
	{
		PointAmountText->SetColorAndOpacity(FLinearColor::White);
	}
	else
	{
		PointAmountText->SetColorAndOpacity(IsChangeColor() ? GetUIResource().GetEnoughColor() : GetUIResource().GetLackColor());
	}
}

void UPointWidget::SetCurPoint(int64 InCurPoint)
{
	SetPoint(InCurPoint, MaxPoint);
}

void UPointWidget::SetMaxPoint(int64 InMaxPoint)
{
	SetPoint(CurPoint, InMaxPoint);
}

void UPointWidget::SetType(EPointType InPointType, EPointWidgetOption InPointWidgetOption)
{
	PointType = InPointType;
	PointWidgetOption = InPointWidgetOption;

	if (!IsVisibleMaxPoint())
	{
		PointMaxText->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		PointMaxText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// UPointNameWidget
void UPointNameWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PointNameText = CastChecked<UTextBlock>(GetWidgetFromName("PointName"));

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UPointNameWidget::OnSelectButtonClicked);
}

void UPointNameWidget::SetPointName(EPointType InPointType)
{
	PointNameText->SetText(Q6Util::GetPointText(InPointType));
}

void UPointNameWidget::OnSelectButtonClicked()
{
	OnSelectedDelegate.ExecuteIfBound();
}

///////////////////////////////////////////////////////////////////////////////////////////
// UPointButtonWidget

UPointButtonWidget::UPointButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPointButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PointWidget = CastChecked<UPointWidget>(GetWidgetFromName("Point"));
	LabelText = CastChecked<UTextBlock>(GetWidgetFromName("Label"));

	ActionButton = CastChecked<UButton>(GetWidgetFromName("Action"));
	ActionButton->OnClicked.AddUniqueDynamic(this, &UPointButtonWidget::OnActionButtonClicked);
}

void UPointButtonWidget::SetMyPoint(int64 InMyPoint)
{
	PointWidget->SetMaxPoint(InMyPoint);
	GetUIResource().SetButtonStyle(ActionButton, (InMyPoint >= PointWidget->GetCurPoint()));
}

void UPointButtonWidget::SetPoint(int64 InNeedPoint, int64 InMyPoint)
{
	PointWidget->SetPoint(InNeedPoint, InMyPoint);
	GetUIResource().SetButtonStyle(ActionButton, (InMyPoint >= InNeedPoint));
}

void UPointButtonWidget::SetName(const FText& ButtonName)
{
	LabelText->SetText(ButtonName);
}

void UPointButtonWidget::SetPointType(EPointType PointType, EPointWidgetOption InPointWidgetOption)
{
	PointWidget->SetPointType(PointType, InPointWidgetOption);
}

void UPointButtonWidget::SetEventWattType(EEventContentCategory InEventContentCategory, EPointWidgetOption InPointWidgetOption)
{
	PointWidget->SetEventWattType(InEventContentCategory, InPointWidgetOption);
}

int64 UPointButtonWidget::GetMyPoint() const
{
	return PointWidget->GetMaxPoint();
}

int64 UPointButtonWidget::GetNeedPoint() const
{
	return PointWidget->GetCurPoint();
}

bool UPointButtonWidget::IsEnoughPoint()
{
	return (GetMyPoint() >= GetNeedPoint());
}

void UPointButtonWidget::OnActionButtonClicked()
{
	OnPointButtonClickedDelegate.ExecuteIfBound();
}

///////////////////////////////////////////////////////////////////////////////////////////
// UPointPlusWidget

UPointPlusWidget::UPointPlusWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UPointPlusWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PointWidget = CastChecked<UPointWidget>(GetWidgetFromName("PointWidgetBP"));
	PlusButton = CastChecked<UButton>(GetWidgetFromName("BtnPlus"));
	PlusButton->OnClicked.AddUniqueDynamic(this, &UPointPlusWidget::OnPlusButtonClicked);
}

void UPointPlusWidget::SetCurPoint(int64 InCurPoint)
{
	PointWidget->SetCurPoint(InCurPoint);
}

void UPointPlusWidget::SetPoint(int64 InCurPoint, int64 InMaxPoint)
{
	PointWidget->SetPoint(InCurPoint, InMaxPoint);
}

void UPointPlusWidget::SetPointType(EPointType InPointType, EPointWidgetOption InPointWidgetOption)
{
	PointWidget->SetPointType(InPointType, InPointWidgetOption);
}

void UPointPlusWidget::OnPlusButtonClicked()
{
	OnPointButtonClickedDelegate.ExecuteIfBound();
}


void UWattRechargePointWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DisabledImage = CastChecked<UImage>(GetWidgetFromName("Disabled"));
	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	OwnedCountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("OwnedCount"));
	InfoText = CastChecked<URichTextBlock>(GetWidgetFromName("Info"));

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UWattRechargePointWidget::OnSelectButtonClicked);
}

void UWattRechargePointWidget::SetPoint(EWattRechargePointType RechargePointType)
{
	NameText->SetText(Q6Util::GetLocalizedText("Common", *ENUM_TO_STRING(EWattRechargePointType, RechargePointType)));

	EPointType PointType = ConvertToPointType(RechargePointType);
	ItemWidget->SetPoint(PointType);
	ItemWidget->SetVisibleCount(false);

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	if (RechargePointType == EWattRechargePointType::Gem)
	{
		int32 RechargeAmount = WorldUser.GetMaxWatt() * SystemConst::Q6_WATT_PER_GEM * 0.01f;
		SetRechargeInfo(RechargePointType, WorldUser.GetTotalGem(), RechargeAmount, SystemConst::Q6_WATT_PER_GEM, SystemConst::Q6_WATT_REGEN_GEM_AMOUNT);
	}
	else if (RechargePointType == EWattRechargePointType::StoredWater)
	{
		int32 StoredWater = GetHUDStore().GetPowerPlantManager().GetPowerPlant().StoredWater;
		SetRechargeInfo(RechargePointType, StoredWater, SystemConst::Q6_WATT_PER_STORE_COUNT);
	}
	else
	{
		// Battery
		if (RechargePointType == EWattRechargePointType::SmallBattery)
		{
			int32 BatteryCount = WorldUser.GetBattery(EBatteryType::Small);
			SetRechargeInfo(RechargePointType, BatteryCount, SystemConst::Q6_WATT_PER_SMALL_BATTERY);
		}
		else if (RechargePointType == EWattRechargePointType::MediumBattery)
		{
			int32 BatteryCount = WorldUser.GetBattery(EBatteryType::Medium);
			int32 RechargeAmount = WorldUser.GetMaxWatt() * SystemConst::Q6_WATT_PER_MEDIUM_BATTERY * 0.01f;
			SetRechargeInfo(RechargePointType, BatteryCount, RechargeAmount, SystemConst::Q6_WATT_PER_MEDIUM_BATTERY);
		}
		else if (RechargePointType == EWattRechargePointType::LargeBattery)
		{
			int32 BatteryCount = WorldUser.GetBattery(EBatteryType::Large);
			int32 RechargeAmount = WorldUser.GetMaxWatt() * SystemConst::Q6_WATT_PER_LARGE_BATTERY * 0.01f;
			SetRechargeInfo(RechargePointType, BatteryCount, RechargeAmount, SystemConst::Q6_WATT_PER_LARGE_BATTERY);
		}
	}
}

void UWattRechargePointWidget::SetRechargeInfo(EWattRechargePointType RechargePointType, int32 OwnedCount, int32 RechargeAmount, int32 RechargePercent, int32 RequireCount)
{
	DisabledImage->SetVisibility(OwnedCount < RequireCount ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);	// Visible for touch blocking
	OwnedCountText->SetText(FText::AsNumber(OwnedCount));

	if (RechargePointType == EWattRechargePointType::StoredWater)
	{
		InfoText->SetText(Q6Util::GetLocalizedText("Common", "WattRechargeStoredWater"));
		return;
	}

	if (RechargePointType == EWattRechargePointType::Gem)
	{
		InfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "WattRechargePercent"), SystemConst::Q6_WATT_REGEN_GEM_AMOUNT, RechargePercent, RechargeAmount));
		return;
	}

	if (RechargePercent > 0)
	{
		InfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "WattRechargePercent"), 1, RechargePercent, RechargeAmount));
	}
	else
	{
		InfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "WattRecharge"), RechargeAmount));
	}
}

EPointType UWattRechargePointWidget::ConvertToPointType(EWattRechargePointType RechargePointType) const
{
	switch (RechargePointType)
	{
		case EWattRechargePointType::Gem:			return EPointType::AnyGem;
		case EWattRechargePointType::StoredWater:	return EPointType::StoredWater;
		case EWattRechargePointType::SmallBattery:	return EPointType::SmallBattery;
		case EWattRechargePointType::MediumBattery:	return EPointType::MediumBattery;
		case EWattRechargePointType::LargeBattery:	return EPointType::LargeBattery;
	}

	return EPointType::None;
}

void UWattRechargePointWidget::OnSelectButtonClicked()
{
	OnPointSelectedDelegate.ExecuteIfBound();
}


void UWattRechargePointSelectPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetTitle(Q6Util::GetLocalizedText("Popup", "WattRechargeConfirmTitle"));

	for (int32 n = 1; n <= (int32)EWattRechargePointType::Max; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Point%d"), n);
		UWattRechargePointWidget* PointWidget = CastChecked<UWattRechargePointWidget>(GetWidgetFromName(*WidgetName));
		PointWidget->OnPointSelectedDelegate.BindUObject(this, &UWattRechargePointSelectPopupWidget::OnRechargePointSelected, (EWattRechargePointType)(n - 1));
		PointWidgets.Add(PointWidget);
	}

	OwnedWattWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedWatt"));
	OwnedWattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::LessColorVisible);

	UButton* CancelButton = CastChecked<UButton>(GetWidgetFromName("Cancel"));
	CancelButton->OnClicked.AddUniqueDynamic(this, &UWattRechargePointSelectPopupWidget::ClosePopup);
}

void UWattRechargePointSelectPopupWidget::SetPointList()
{
	for (int32 i = 0; i < (int32)EWattRechargePointType::Max; ++i)
	{
		PointWidgets[i]->SetPoint((EWattRechargePointType)i);
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	OwnedWattWidget->SetPoint(WorldUser.GetWatt(), WorldUser.GetMaxWatt());
}

void UWattRechargePointSelectPopupWidget::OnRechargePointSelected(EWattRechargePointType PointType)
{
	ABaseHUD* BaseHUD = GetBaseHUD(this);
	check(BaseHUD);

	if (GetHUDStore().GetWorldUser().IsMaxWatt())
	{
		BaseHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "WattMaxNotify"));
		return;
	}

	UWattRechargeConfirmPopupWidget* ConfirmPopup = CastChecked<UWattRechargeConfirmPopupWidget>(BaseHUD->OpenPopup(WattRechargeConfirmPopupClass));
	ConfirmPopup->SetRechargePoint(PointType);
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UWattRechargePointSelectPopupWidget::OnWattRechargeConfirmed);
}

void UWattRechargePointSelectPopupWidget::OnWattRechargeConfirmed(EConfirmPopupFlag Flag)
{
	if (Flag == EConfirmPopupFlag::Yes)
	{
		ClosePopup();
	}
}

void UWattRechargeConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RechargePointWidget = CastChecked<UWattRechargePointWidget>(GetWidgetFromName("Point"));
	RechargeCountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RechargeCount"));

	CurWattWidget = CastChecked<UPointWidget>(GetWidgetFromName("CurWatt"));
	CurWattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::LessColorVisible);

	ResultWattWidget = CastChecked<UPointWidget>(GetWidgetFromName("ResultWatt"));
	ResultWattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::LessColorVisible);

	PlusButton = CastChecked<UButton>(GetWidgetFromName("Plus"));
	PlusButton->OnClicked.AddUniqueDynamic(this, &UWattRechargeConfirmPopupWidget::OnPlusButtonClicked);

	MinusButton = CastChecked<UButton>(GetWidgetFromName("Minus"));
	MinusButton->OnClicked.AddUniqueDynamic(this, &UWattRechargeConfirmPopupWidget::OnMinusButtonClicked);
}

void UWattRechargeConfirmPopupWidget::SetRechargePoint(EWattRechargePointType InPointType)
{
	RechargeCount = 1;	// Default recharge count
	PointType = InPointType;

	if (PointType == EWattRechargePointType::Gem)
	{
		MaxCount = GetHUDStore().GetWorldUser().GetTotalGem();
	}
	else if (PointType == EWattRechargePointType::StoredWater)
	{
		int32 StoredWater = GetHUDStore().GetPowerPlantManager().GetPowerPlant().StoredWater;
		MaxCount = StoredWater / GetRechargeWattPerCount(PointType);
	}
	else
	{
		// Use battery

		EBatteryType BatteryType = ConvertRechargePointToBattery(PointType);
		int32 BatteryCount = GetHUDStore().GetWorldUser().GetBattery(BatteryType);

		MaxCount = BatteryCount;
	}

	RechargePointWidget->SetPoint(PointType);
	RefreshWatt();
}

void UWattRechargeConfirmPopupWidget::RefreshWatt()
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	int32 CurWatt = WorldUser.GetWatt();
	int32 MaxWatt = WorldUser.GetMaxWatt();
	int32 ResultWatt = CurWatt + (RechargeCount * GetRechargeWattPerCount(PointType));
	if ((CurWatt >= MaxWatt) || (MaxCount <= 0))
	{
		PlusButton->SetIsEnabled(false);
		MinusButton->SetIsEnabled(false);

		SetYesButtonEnabled(false);
	}
	else
	{
		PlusButton->SetIsEnabled((RechargeCount < MaxCount) && (ResultWatt < MaxWatt));
		MinusButton->SetIsEnabled(RechargeCount > 1);

		SetYesButtonEnabled(true);
	}

	int32 ConsumePerRechargeCount = 1;
	if (PointType == EWattRechargePointType::StoredWater)
	{
		ConsumePerRechargeCount = SystemConst::Q6_WATT_PER_STORE_COUNT;
	}
	else if (PointType == EWattRechargePointType::Gem)
	{
		ConsumePerRechargeCount = SystemConst::Q6_WATT_REGEN_GEM_AMOUNT;
	}

	RechargeCountText->SetText(FText::AsNumber(RechargeCount * ConsumePerRechargeCount));

	CurWattWidget->SetPoint(CurWatt, MaxWatt);
	ResultWattWidget->SetPoint(ResultWatt, MaxWatt);
}

EBatteryType UWattRechargeConfirmPopupWidget::ConvertRechargePointToBattery(EWattRechargePointType InPointType) const
{
	switch (InPointType)
	{
		case EWattRechargePointType::SmallBattery:  return EBatteryType::Small;
		case EWattRechargePointType::MediumBattery: return EBatteryType::Medium;
		case EWattRechargePointType::LargeBattery:  return EBatteryType::Large;
		default: return EBatteryType::None;
	}
}

int32 UWattRechargeConfirmPopupWidget::GetRechargeWattPerCount(EWattRechargePointType InPointType)
{
	int32 MaxWatt = GetHUDStore().GetWorldUser().GetMaxWatt();

	switch (InPointType)
	{
		case EWattRechargePointType::StoredWater:
			return SystemConst::Q6_WATT_PER_STORE_COUNT;
		case EWattRechargePointType::SmallBattery:
			return SystemConst::Q6_WATT_PER_SMALL_BATTERY;
		case EWattRechargePointType::MediumBattery:
			return (float)MaxWatt * SystemConst::Q6_WATT_PER_MEDIUM_BATTERY * 0.01f;
		case EWattRechargePointType::Gem:
		case EWattRechargePointType::LargeBattery:
			return (float)MaxWatt * SystemConst::Q6_WATT_PER_LARGE_BATTERY * 0.01f;
		default:
			return 0;
	}
}

void UWattRechargeConfirmPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Flag)
{
	Super::OnConfirmButtonClicked(Flag);

	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	if (PointType == EWattRechargePointType::StoredWater)
	{
		GetHUDStore().GetPowerPlantManager().ReqRecharge(RechargeCount);
		return;
	}

	EBatteryType BatteryType = ConvertRechargePointToBattery(PointType);
	GetHUDStore().GetWorldUser().ReqWattRecharge(BatteryType, RechargeCount);
}

void UWattRechargeConfirmPopupWidget::OnPlusButtonClicked()
{
	++RechargeCount;

	RefreshWatt();
}

void UWattRechargeConfirmPopupWidget::OnMinusButtonClicked()
{
	--RechargeCount;

	RefreshWatt();
}