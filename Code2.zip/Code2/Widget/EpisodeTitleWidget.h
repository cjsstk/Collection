#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "UMG.h"

#include "EpisodeTitleWidget.generated.h"

class UUMGSequencePlayer;

UCLASS()
class UEpisodeTitleWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UEpisodeTitleWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetEpisodeTitle(const FText& Title);
	void SetEpisodeTitle(int32 Episode);

	FSimpleDelegate OnTitleEnd;

	void Start();

private:
	UPROPERTY()
	UWidgetAnimation* EpisodeStartAnim;

	UPROPERTY()
	UWidgetAnimation* EpisodeEndAnim;

	UPROPERTY()
	UTextBlock* EpisodeNameText;

	UPROPERTY()
	UTextBlock* EpisodeNumText;
};
