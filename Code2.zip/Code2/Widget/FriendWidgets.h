// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "LobbyHUDWidget.h"
#include "Q6UIDefine.h"
#include "FriendManager.h"

#include "FriendWidgets.generated.h"

class UDynamicListWidget;
class UJokerEntryWidget;
class UNatureTabWidget;
class UPartyPageWidget;
class UPopupBaseWidget;
class UToggleButtonBoxWidget;
class UToggleButtonWidget;
class USortingWidget;
class UAvatarIconWidget;

struct FFriendBookDetailedFeed;

UCLASS()
class Q6_API UJokerSetViewWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UJokerSetViewWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetFriendInfo(const FFriendInfo& FriendInfo);
	const UPartyPageWidget* GetJokerSetWidget() const
	{
		check(JokerSetWidget);
		return JokerSetWidget;
	}

private:
	UPROPERTY()
	URichTextBlock* AkaText;

	UPROPERTY()
	UTextBlock* FriendNameText;

	UPROPERTY()
	UPartyPageWidget* JokerSetWidget;
};

UCLASS()
class Q6_API UJokerSetViewPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	UJokerSetViewPopupWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetFriendInfo(const FFriendInfo& FriendInfo);

private:
	UPROPERTY()
	UJokerSetViewWidget* JokerSetViewWidget;
};

UCLASS()
class Q6_API UReactionTagWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UReactionTagWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	void SetReactions(const TArray<uint32>& InReactionCounts);

private:

	UPROPERTY()
	TArray<UImage*> IconImages;
};

DECLARE_DELEGATE_OneParam(FFriendReactionClickedDelegate, const FFriendBookFeedId&);

UCLASS()
class Q6_API UFriendFeedEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UFriendFeedEntryWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetFeedInfo(const FFriendBookDetailedFeed& InFeedInfo);
	void UpdateFeedInfo(const FFriendBookDetailedFeed& InFeedInfo);

	FFriendRequestDelegate OnQuickLinkButtonDelegate;
	FFriendReactionClickedDelegate OnReactionButtonDelegate;

private:

	UFUNCTION()
	void OnAddReactionClicked();

	UFUNCTION()
	void OnQuickLinkButtonClicked();

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	URichTextBlock* TextFeedRichText;

	UPROPERTY()
	UAvatarIconWidget* AvatarWidget;

	UPROPERTY()
	UTextBlock* LinkNameText;

	UPROPERTY()
	UTextBlock* LoginText;

	UPROPERTY()
	UImage* IconFeedTypeImage;

	UPROPERTY()
	UButton* QuickLinkButton;

	UPROPERTY()
	UTextBlock* ReactionCountText;

	UPROPERTY()
	UButton* AddReactionButton;

	UPROPERTY()
	UReactionTagWidget* FriendReactionsWidget;

	UPROPERTY()
	FFriendBookFeedId CachedFeedId;

	UPROPERTY()
	FItemIconInfo LinkItemIconInfo;
};

UCLASS()
class Q6_API UReactionButtonWidget : public UUserWidget
{
	GENERATED_BODY()
public:

	UReactionButtonWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	bool HasMyReaction() const { return bHasMyReaction; }
	void SetButtonInfo(FFriendBookFeedId InFeedId, EFriendBookReactionType InReactionType, int32 InCount, bool bInHasMyReaction);

	UPROPERTY()
	UCheckBox* SelectCheckBox;

private:

	UFUNCTION()
	void OnReacitonCheckStateChanged(bool bInChecked);

	UPROPERTY()
	UTextBlock* CountText;

	UPROPERTY()
	bool bHasMyReaction;

	UPROPERTY()
	EFriendBookReactionType ReactionType;

	UPROPERTY()
	FFriendBookFeedId CachedFeedId;

};

UCLASS()
class Q6_API UFriendUserReactionEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UFriendUserReactionEntryWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetInfo(const FFriendBookReaction& InReaction);

private:

	UPROPERTY()
	UAvatarIconWidget* AvatarWidget;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UReactionTagWidget* ReactionTagWidget;

	UPROPERTY()
	UTextBlock* LoginText;
};

UCLASS()
class Q6_API UFriendReactionPageWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UFriendReactionPageWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetFeedInfo(const FFriendBookDetailedFeed& InFeedInfo);

	FSimpleDelegate OkClicked;

private:

	UFUNCTION()
	void OnSaveOkClicked();

	UPROPERTY()
	UFriendFeedEntryWidget* FriendFeedWidget;

	UPROPERTY()
	UDynamicListWidget* UserReactionListWidget;

	UPROPERTY()
	UButton* OkButton;

	UPROPERTY()
	FFriendBookFeedId CachedFeedId;

	UPROPERTY()
	TArray<UReactionButtonWidget*> ReactionWidgets;
};

UCLASS()
class Q6_API UFriendWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UFriendWidget(const FObjectInitializer& ObjectInitializer);

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Friend; }

	UPROPERTY(EditDefaultsOnly, Category = "FriendBook Feed")
	TSubclassOf<UFriendReactionPageWidget> FriendReactionPageWidgetClass;

public:
	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

private:
	static const int32 RecevingIndex = 1;

	void Refresh();
	void RefreshFriendBookNewMark();
	void RefreshConnected();
	void RefreshReceiving();
	void RequestFriendBookTimeline();
	void RefreshFriendBookTimeline();
	void RefreshFeed(const FFriendBookFeedId InRefreshFeedId);
	void RefreshSearchResult(TSharedPtr<FHSAction> Action);
	void RefreshErrorResult(TSharedPtr<FHSAction> Action);
	void RefreshOrRequestOnFeedChanged(const FFriendBookFeedId InFriendBookFeedId);

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void AddList(TArray<const FFriendInfoEx*>&& FriendList, const FString& CountType, int32 MaxFriendCount, bool bReceiving);
	void AddToList(const FFriendInfo& FriendInfo, bool bNewly = false);

	void OnJokerSetButtonClicked(const FFriendInfo& FriendInfo);
	void OnFriendReactionPageClosed();
	void OnFriendFeedReactionButtonClicked(const FFriendBookFeedId& InFeedId);
	void OnFriendButtonClicked(const FFriendInfo& FriendInfo, bool bAccept);
	void OnCategoryChanged(int32 ChangedIndex);
	void OnFriendFeedFilterChanged(int32 InChangedIndex);
	void SetSearchButtonEnabled(bool bEnabled = true);
	bool IsValidUserCode(const FText& Text);

	void OnScrolledStandStillAtStart();
	void OnScrolledStandStillAtEnd();

	FFriendRequestDelegate FriendInfoDelegate;
	void DelegateOnConfirm(const FString& TitleKey, const FString& ContentKey, const FFriendInfo& FriendInfo) const;

	UFUNCTION()
	void OnSearchInputChanged(const FText& Text);
	UFUNCTION()
	void OnSearchInputCommitted(const FText& Text, ETextCommit::Type CommitMethod);
	UFUNCTION()
	void OnSearchButtonClicked();
	UFUNCTION()
	void OnIdCopyButtonClicked();

private:
	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	UJokerSetViewWidget* JokerSetViewWidget;

	UPROPERTY()
	UDynamicListWidget* FriendListWidget;

	UPROPERTY()
	UDynamicListWidget* FriendFeedListWidget;

	UPROPERTY()
	UWidgetSwitcher* CategorySwitcher;

	UPROPERTY()
	UWidgetSwitcher* ResultSwitcher;

	UPROPERTY()
	UToggleButtonBoxWidget* CategoryButton;

	UPROPERTY()
	UToggleButtonBoxWidget* FriendFeedFilterButton;

	UPROPERTY()
	UEditableTextBox* SearchInput;

	UPROPERTY()
	UButton* SearchButton;

	UPROPERTY()
	UTextBlock* MyUserIdText;

	UPROPERTY()
	UButton* IdCopyButton;

	UPROPERTY()
	UJokerEntryWidget* SearchResultWidget;

	UPROPERTY()
	UTextBlock* CountTypeText;

	UPROPERTY()
	UTextBlock* CurFriendText;

	UPROPERTY()
	UTextBlock* MaxFriendText;

	UPROPERTY()
	USortingWidget* SortingWidget;

	// FriendFeedListWidget keeps all pointers
	UPROPERTY()
	TMap<FFriendBookFeedId, UFriendFeedEntryWidget*> FeedWidgets;

	UPROPERTY()
	UFriendReactionPageWidget* FriendReactionPageWidget;

	UPROPERTY()
	FFriendBookFeedId FriendBookFeedWatching;
};
