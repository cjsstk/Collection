// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"
#include "Q6UIDefine.h"

#include "CharacterDetailWidgets.generated.h"

enum class ECharacterVoiceCategory : uint8;
struct FCharacterType;
struct FCharacterVoiceInfo;
struct FCMSCharUnlockElemRow;
class UQ6Button;
class URichTextBlock;
class UToggleButtonBoxWidget;
class UVerticalList;

UCLASS()
class Q6_API UCharacterProfileListEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetProfile(EProfileCategory InCategory, const FText& InContent, bool bInUnlocked);

private:
	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle UnlockedStyle;

	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle LockedStyle;

	UPROPERTY(Transient)
	UWidgetAnimation* UnlockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	URichTextBlock* ContentText;
};

UCLASS()
class Q6_API UCharacterStoryListEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetStory(const FText& InTitle, const FText& InContent, bool bInUnlocked);

private:
	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle UnlockedStyle;

	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle LockedStyle;

	UPROPERTY(Transient)
	UWidgetAnimation* UnlockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	URichTextBlock* ContentText;
};

UCLASS()
class Q6_API UCharacterProfileWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacter(FCharacterType InCharacterType, FText& OutCharacterEtcDesc);

private:
	void AddProfileElem(FCharacterType InCharacterType, const FCMSCharUnlockElemRow* InElem);
	void AddStoryElem(FCharacterType InCharacterType, const FCMSCharUnlockElemRow* InElem);

	void OnMenuChanged(int32 InIndex);

	UPROPERTY()
	UToggleButtonBoxWidget* MenuBoxWidget;

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	UVerticalList* ProfileListWidget;

	UPROPERTY()
	UVerticalList* StoryListWidget;
};

UCLASS()
class Q6_API UCharacterVoiceListEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCharacterVoiceListEntryWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetVoiceInfo(const FText& InDesc, bool bInUnlocked);

	FSimpleDelegate OnVoiceSelectedDelegate;

private:
	UFUNCTION()
	void OnVoiceSelected();

	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle UnlockedStyle;

	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle LockedStyle;

	UPROPERTY(Transient)
	UWidgetAnimation* UnlockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY()
	UQ6Button* SelectButton;

	UPROPERTY()
	URichTextBlock* VoiceInfoText;
};

UCLASS()
class Q6_API UCharacterVoiceListEntryGroupWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void InitVoiceGroup(const FText& InText);
	UCharacterVoiceListEntryWidget* AddVoiceElem(const FText& InDesc, bool bInUnlocked);

protected:
	UPROPERTY(EditInstanceOnly)
	TAssetSubclassOf<UWidget> VoiceEntryWidgetClass;

	UPROPERTY(EditInstanceOnly)
	FMargin VoiceEntryPadding;

private:
	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	UVerticalBox* VoiceListBox;
};

UCLASS()
class Q6_API UCharacterVoiceListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCharacterVoiceListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void InitVoiceList();
	void AddVoiceEntryGroup(UCharacterVoiceWidget* InVoiceWidget, FCharacterType InCharacterType, const FCharacterVoiceInfo& InCharacterVoiceInfo, TArray<const FCMSCharUnlockElemRow*>& InElems);

	void SetSelected(bool bInSelected);

	FSimpleDelegate OnVoiceListSelectedDelegate;

private:
	UFUNCTION()
	void OnVoiceListSelected();

	UPROPERTY(Transient)
	UWidgetAnimation* DefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* OpenListAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CloseListAnim;

	UPROPERTY(EditInstanceOnly)
	FText Title;

	UPROPERTY()
	UButton* SelectButton;

	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	UVerticalList* VoiceListWidget;
};

UCLASS()
class Q6_API UCharacterVoiceWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCharacterVoiceWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetCharacter(FCharacterType InCharacterType);

	UFUNCTION()
	void OnVoiceSelected(ECharacterVoiceCategory VoiceCategory, TSoftObjectPtr<USoundBase> VoiceSound);

private:
	void GetVoiceElems(FCharacterType InCharacterType, TArray<const FCMSCharUnlockElemRow*>& InOutElems) const;
	void OnVoiceListSelected(int32 InVoiceListIndex);

	UFUNCTION()
	void OnVoicePreviewAnimFinished();

	UFUNCTION()
	void OnVoiceSoundPlay();

	UFUNCTION()
	void OnVoiceSoundFinished();

	UPROPERTY(Transient)
	UWidgetAnimation* ShowVoiceListAnim;
	
	UPROPERTY(Transient)
	UWidgetAnimation* HideVoiceListAnim;

	UPROPERTY()
	UTextBlock* CharacterNameText;

	UPROPERTY()
	UImage* SoundPlayingImage;

	UPROPERTY()
	TArray<UCharacterVoiceListWidget*> VoiceListWidgets;

	int32 SelectedVoiceListIndex;
};
