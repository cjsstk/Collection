// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "UMG.h"
#include "Widgets/SCompoundWidget.h"
#include "LoadingScreenWidget.generated.h"

UCLASS()
class Q6_API ULoadingScreenWidget : public UUserWidget
{
	GENERATED_BODY()
public:
	ULoadingScreenWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void AddToScreen(ULocalPlayer* LocalPlayer, int32 ZOrder) override;

	void SetTipText(FText TipText);

protected:

	UPROPERTY()
	FText LoadingTooltip;
};