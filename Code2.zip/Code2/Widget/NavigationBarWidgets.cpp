// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "NavigationBarWidgets.h"

#include "HUD/BaseHUD.h"
#include "CommonWidgets.h"
#include "ContentFeatureOpenManager.h"
#include "GameResource.h"
#include "HUDStore/EventManager.h"
#include "HUDStore/Q6Account.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "Q6GameInstance.h"
#include "StageWidgets.h"
#include "SystemConst_gen.h"
#include "TitleManager.h"
#include "RaidManager.h"
#include "Q6SaveGame.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent NavigationBar"), STAT_OnHSEventByNavigationBar, STATGROUP_HSTORE);

UMenuButtonBaseWidget::UMenuButtonBaseWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UMenuButtonBaseWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MenuNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextMenuName"));
	NewMarkImage = Cast<UImage>(GetWidgetFromName("NewMark"));	// Nullable

	InitMenuButton();
}

void UMenuButtonBaseWidget::SetMenuName(const FText& InMenuName)
{
	MenuName = InMenuName;

	MenuNameText->SetText(MenuName);
}

void UMenuButtonBaseWidget::SetNewMarkVisible(bool bInVisible)
{
	if (NewMarkImage)
	{
		NewMarkImage->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void UMenuButtonBaseWidget::InitMenuButton()
{
	MenuNameText->SetText(MenuName);
}

void UMenuButtonBaseWidget::OnMenuButtonClicked()
{
	OnMenuButtonClickedDelegate.ExecuteIfBound();
}


void UMenuButtonWidget::NativeConstruct()
{
	CheckedAnim = GetWidgetAnimationFromName(this, "AnimChecked");
	check(CheckedAnim);

	UncheckedAnim = GetWidgetAnimationFromName(this, "AnimUnchecked");
	check(UncheckedAnim);

	MenuButton = CastChecked<UCheckBox>(GetWidgetFromName("Menu"));
	MenuButton->OnCheckStateChanged.AddUniqueDynamic(this, &UMenuButtonWidget::OnMenuButtonStateChanged);

	CheckedIconImage = CastChecked<UImage>(GetWidgetFromName("CheckedIcon"));
	UncheckedIconImage = CastChecked<UImage>(GetWidgetFromName("UncheckedIcon"));

	Super::NativeConstruct();
}

void UMenuButtonWidget::InitMenuButton()
{
	Super::InitMenuButton();

	MenuButton->WidgetStyle = MenuButtonStyle;
	SetChecked(MenuButton->IsChecked());

	CheckedIconImage->SetBrush(CheckedBrush);
	UncheckedIconImage->SetBrush(UncheckedBrush);
}

void UMenuButtonWidget::SetChecked(bool bInChecked)
{
	MenuButton->SetIsChecked(bInChecked);

	if (bInChecked)
	{
		PlayAnimation(CheckedAnim);
	}
	else
	{
		PlayAnimation(UncheckedAnim);
	}
}

void UMenuButtonWidget::SetCheckedBrush(const FSlateBrush& InCheckedBrush)
{
	CheckedBrush = InCheckedBrush;

	CheckedIconImage->SetBrush(CheckedBrush);
}

void UMenuButtonWidget::OnMenuButtonStateChanged(bool bChecked)
{
	OnMenuButtonClicked();
}


void UQuickMenuButtonWidget::NativeConstruct()
{
	UQ6Button* MenuButton = CastChecked<UQ6Button>(GetWidgetFromName("ButtonMenu"));
	MenuButton->OnClickedDelegate.BindUObject(this, &UQuickMenuButtonWidget::OnMenuButtonClicked);

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));

	Super::NativeConstruct();
}

void UQuickMenuButtonWidget::SetIcon(const FSlateBrush& InIconBrush)
{
	IconBrush = InIconBrush;

	IconImage->SetBrush(IconBrush);
}

void UQuickMenuButtonWidget::InitMenuButton()
{
	Super::InitMenuButton();

	IconImage->SetBrush(IconBrush);
}


///////////////////////////////////////////////////////////////////////////////////////////
// UNavigationBarWidget

UNavigationBarWidget::UNavigationBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, WattRegenElapsedTime(0.0f)
{
}

void UNavigationBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	//////////////////////////////////////////////////////////////////////////
	// Top area
	//////////////////////////////////////////////////////////////////////////

	// Level
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	XpGauge = CastChecked<UProgressBar>(GetWidgetFromName("XPProgress"));

	// Title
	TitleIconImage = CastChecked<UImage>(GetWidgetFromName("TitleIcon"));
	IconBadgeImage = CastChecked<UImage>(GetWidgetFromName("IconBadge"));
	TitleText = CastChecked<URichTextBlock>(GetWidgetFromName("PageTitle"));
	TitleBorder = CastChecked<UBorder>(GetWidgetFromName("BorderTitle"));
	ReputationBadgeSizeBox = CastChecked<USizeBox>(GetWidgetFromName("ReputationBadge"));

	// Points

	GoldText = CastChecked<UTextBlock>(GetWidgetFromName("Gold"));
	GemText = CastChecked<UTextBlock>(GetWidgetFromName("Gem"));
	WattText = CastChecked<UTextBlock>(GetWidgetFromName("Watt"));
	WattOfMaxText = CastChecked<UTextBlock>(GetWidgetFromName("WattOfMax"));

	UButton* GemPurchaseButton = CastChecked<UButton>(GetWidgetFromName("GemPurchase"));
	GemPurchaseButton->OnClicked.AddUniqueDynamic(this, &UNavigationBarWidget::OnGemPurchaseButtonClicked);

	WattRechargeButton = CastChecked<UButton>(GetWidgetFromName("WattRecharge"));
	WattRechargeButton->OnClicked.AddUniqueDynamic(this, &UNavigationBarWidget::OnWattRechargeButtonClicked);

	UButton* MailButton = CastChecked<UButton>(GetWidgetFromName("Mail"));
	MailButton->OnClicked.AddUniqueDynamic(this, &UNavigationBarWidget::OnMailButtonClicked);

	WattIconImage = CastChecked<UImage>(GetWidgetFromName("Icon_Watt"));
	NewMailIconImage = CastChecked<UImage>(GetWidgetFromName("NewMailIcon"));

	// Watt Timer
	WattTimerText = CastChecked<UTextBlock>(GetWidgetFromName("WattTimer"));
	WattTimerText->SetText(FText::GetEmpty());

	//////////////////////////////////////////////////////////////////////////
	// Bottom area
	//////////////////////////////////////////////////////////////////////////

	SubMenuBorder = CastChecked<UBorder>(GetWidgetFromName("SubMenu"));

	SubMenuToggleButton = CastChecked<UMenuButtonWidget>(GetWidgetFromName("SubMenuToggle"));
	SubMenuToggleButton->OnMenuButtonClickedDelegate.BindUObject(this, &UNavigationBarWidget::OnSubMenuToggleButtonClicked);

	BackButton = CastChecked<UButton>(GetWidgetFromName("Back"));
	BackButton->OnClicked.AddUniqueDynamic(this, &UNavigationBarWidget::OnBackButtonClicked);

	BackButtonBox = CastChecked<USizeBox>(BackButton->GetParent());
	ReadyTimerBox = CastChecked<USizeBox>(GetWidgetFromName("ReadyTimerBox"));

	// Menu Buttons
	FString WidgetName;
	for (int32 MainMenuNum = 1; MainMenuNum <= MainMenuNumber; ++MainMenuNum)
	{
		WidgetName = FString::Printf(TEXT("Menu%d"), MainMenuNum);

		UMenuButtonWidget* MenuButtonWidget = CastChecked<UMenuButtonWidget>(GetWidgetFromName(*WidgetName));
		MenuButtonWidget->OnMenuButtonClickedDelegate.BindUObject(this, &UNavigationBarWidget::OnMenuChanged, EHUDWidgetType(MainMenuNum - 1));
		MainMenuButtonWidgets.AddUnique(MenuButtonWidget);
	}

	// Sub Buttons
	for (int32 SubMenuNum = MainMenuNumber + 1; SubMenuNum <= SubMenuNumber; ++SubMenuNum)
	{
		WidgetName = FString::Printf(TEXT("Menu%d"), SubMenuNum);

		UQuickMenuButtonWidget* MenuButton = CastChecked<UQuickMenuButtonWidget>(GetWidgetFromName(*WidgetName));
		MenuButton->OnMenuButtonClickedDelegate.BindUObject(this, &UNavigationBarWidget::OnMenuChanged, EHUDWidgetType(SubMenuNum - 1));
		SubMenuButtonWidgets.AddUnique(MenuButton);
	}

	SubMenuBorder = CastChecked<UBorder>(GetWidgetFromName("SubMenu"));

	UButton* SubMenuCloseButton = CastChecked<UButton>(GetWidgetFromName("Dismiss"));
	SubMenuCloseButton->OnClicked.AddUniqueDynamic(this, &UNavigationBarWidget::OnSubMenuCloseButtonClicked);

	StageText = CastChecked<UTextBlock>(GetWidgetFromName("TextStage"));
	StageNumText = CastChecked<UTextBlock>(GetWidgetFromName("TextStageNumber"));
	StageNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextStageName"));
	RecommendLevelText = CastChecked<UTextBlock>(GetWidgetFromName("TextRecommendLevel"));
	ReadyTimerText = CastChecked<UTextBlock>(GetWidgetFromName("ReadyTimer"));
	StageNaturesWidget = CastChecked<UStageEnemyNaturesWidget>(GetWidgetFromName("StageNatures"));

	UButton* TitleSelectButton = CastChecked<UButton>(GetWidgetFromName("TitleSelect"));
	TitleSelectButton->OnClicked.AddUniqueDynamic(this, &UNavigationBarWidget::OnTitleSelectButtonClicked);

	// Animations

	TopBarAnims.Reset();
	TopBarAnims.Add(GetWidgetAnimationFromName(this, "AnimTopNone"));
	TopBarAnims.Add(GetWidgetAnimationFromName(this, "AnimTopDefault"));
	TopBarAnims.Add(GetWidgetAnimationFromName(this, "AnimTopStageInfo"));

	BottomNoneAnim = GetWidgetAnimationFromName(this, "AnimBottomNone");
	BottomDefaultAnim = GetWidgetAnimationFromName(this, "AnimBottomDefault");

	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::Pyramid);
	SubscribeToStore(EHSType::Pet);
	SubscribeToStore(EHSType::Temple);
	SubscribeToStore(EHSType::Vacation);
	SubscribeToStore(EHSType::WeeklyMission);
	SubscribeToStore(EHSType::Character);
	SubscribeToStore(EHSType::Relic);
	SubscribeToStore(EHSType::Sculpture);
	SubscribeToStore(EHSType::Friend);
	SubscribeToStore(EHSType::Shop);
	SubscribeToStore(EHSType::NewMark);
	SubscribeToStore(EHSType::FriendBook);

	Refresh();
}

void UNavigationBarWidget::NativeDestruct()
{
	if (ReadyTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().ClearTimer(ReadyTimerHandle);
	}

	Super::NativeDestruct();
}

void UNavigationBarWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	UQ6GameInstance* Q6GameInstance = UQ6GameInstance::Get(this);
	const double CurrentTime = FPlatformTime::Seconds();

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	int32 Watt = WorldUser.GetWatt();
	int32 MaxWatt = WorldUser.GetMaxWatt();
	if (Watt >= MaxWatt)
	{
		if (WattRegenElapsedTime > 0)
		{
			const bool bWattRemainTimeVisible = false;
			RefreshWattRemainTime(bWattRemainTimeVisible);
			WattRegenElapsedTime = 0.0f;
		}

		Q6GameInstance->SetLastWattUpdateTime(CurrentTime);
		return;
	}

	WattRegenElapsedTime = CurrentTime - Q6GameInstance->GetLastWattUpdateTime();

	// correct watt & watt regen time by the client side time
	if (WattRegenElapsedTime >= SystemConst::Q6_WATT_REGEN_PERIOD_IN_SEC)
	{
		const int32 AdditionalWatt = WattRegenElapsedTime / SystemConst::Q6_WATT_REGEN_PERIOD_IN_SEC;
		const float RemainTime = WattRegenElapsedTime - AdditionalWatt * SystemConst::Q6_WATT_REGEN_PERIOD_IN_SEC;

		int32 NewWatt = FMath::Clamp(Watt + AdditionalWatt * SystemConst::Q6_WATT_REGEN_AMOUNT, 0, MaxWatt);
		const FWattDiffInfo WattInfo = { NewWatt, (int32)RemainTime };
		ACTION_DISPATCH_WattInfo(WattInfo);

		Q6GameInstance->SetLastWattUpdateTime(CurrentTime - RemainTime);
	}
	else
	{
		RefreshWattRemainTime();
	}
}

bool IsMultiside(FSagaType SagaType)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	return SagaRow.ContentType == EContentType::MultiSideBattle;
}

void UNavigationBarWidget::SetTopBarType(ETopBarType TopBarType)
{
	if (!TopBarAnims.IsValidIndex((int32)TopBarType))
	{
		Q6JsonLogRoze(Error, "UNavigationBarWidget::SetTopBarType - Not found top bar type");
		return;
	}

	PlayAnimation(TopBarAnims[(int32)TopBarType]);

	if (TopBarType == ETopBarType::CombatReady)
	{
		const FJokerSelectUIState& UIState = GetHUDStore().GetUIStateManager().GetJokerSelectUIState();
		if (UIState.SagaType != SagaTypeInvalid)
		{
			SetCombatReady(UIState.SagaType);
		}
		else
		{
			// multiside skips jokerSelect. so, should run SetCombatReady()
			const FPartyUIState& PartyUIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
			FSagaType SagaType = PartyUIState.SagaType;

			if (SagaType != SagaTypeInvalid && IsMultiside(SagaType))
			{
				SetCombatReady(SagaType);
			}
		}
	}
}

void UNavigationBarWidget::SetBottomBarVisible(bool bInVisible)
{
	PlayAnimation(bInVisible ? BottomDefaultAnim : BottomNoneAnim);
}

void UNavigationBarWidget::SetBackButtonVisible(bool bInVisible)
{
	BackButton->SetVisibility(bInVisible ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}

void UNavigationBarWidget::SetReadyTimerVisible(bool bInVisible)
{
	if (ReadyTimerHandle.IsValid())
	{
		ReadyTimerBox->SetVisibility(
			bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
	else
	{
		ReadyTimerBox->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UNavigationBarWidget::Refresh()
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	LevelText->SetText(FText::AsNumber(WorldUser.GetLevel()));
	XpGauge->SetPercent(WorldUser.GetXpRatio());
	GemText->SetText(FText::AsNumber(WorldUser.GetTotalGem()));
	GoldText->SetText(FText::AsNumber(WorldUser.GetGold()));

	const bool bWattRemainTimeVisible = WorldUser.GetWatt() < WorldUser.GetMaxWatt();
	RefreshWattRemainTime(bWattRemainTimeVisible);
	RefreshWattText();
	SetNewMarks();
	SetContentState();
}

void UNavigationBarWidget::RefreshWattRemainTime(bool bInVisible)
{
	const int32 WattRemainTime = SystemConst::Q6_WATT_REGEN_PERIOD_IN_SEC - FMath::TruncToInt(WattRegenElapsedTime);
	if (WattRemainTime > 0 && bInVisible)
	{
		int32 Minutes = WattRemainTime / 60;
		int32 Seconds = WattRemainTime % 60;
		WattTimerText->SetText(FText::FromString(FString::Printf(TEXT("%d:%02d"), Minutes, Seconds)));
	}
	else
	{
		WattTimerText->SetText(FText::GetEmpty());
	}
}

void UNavigationBarWidget::OnSubMenuToggleButtonClicked()
{
	if (SubMenuBorder->IsVisible())
	{
		// If already opened, close sub menu

		EHUDWidgetType CurHUDWidgetType = GetCheckedLobbyHUD(this)->GetCurrentHUDWidgetType();
		RefreshMenuButtons(CurHUDWidgetType);
		return;
	}

	OpenSubMenu();
}

void UNavigationBarWidget::OpenSubMenu()
{
	for (int32 i = 0; i < MainMenuButtonWidgets.Num(); ++i)
	{
		MainMenuButtonWidgets[i]->SetChecked(false);
	}

	SubMenuToggleButton->SetCheckedBrush(SubMenuCloseIconBrush);
	SubMenuToggleButton->SetChecked(true);

	BackButtonBox->SetVisibility(ESlateVisibility::Collapsed);
	SubMenuBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UNavigationBarWidget::RefreshMenuButtons(EHUDWidgetType HUDWidgetType)
{
	int32 MenuIndex = (int32)HUDWidgetType;
	for (int32 i = 0; i < MainMenuButtonWidgets.Num(); ++i)
	{
		MainMenuButtonWidgets[i]->SetChecked(i == MenuIndex);
	}

	bool bSubMenu = ((MenuIndex >= MainMenuNumber) && (MenuIndex < SubMenuNumber));
	SubMenuToggleButton->SetCheckedBrush(SubMenuOpenIconBrush);
	SubMenuToggleButton->SetChecked(bSubMenu);

	BackButtonBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	SubMenuBorder->SetVisibility(ESlateVisibility::Collapsed);
}

void UNavigationBarWidget::RefreshWattText()
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	WattText->SetText(FText::AsNumber(WorldUser.GetWatt()));
	WattOfMaxText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PointAmount"), FText::GetEmpty(), WorldUser.GetMaxWatt()));

	bool bOvercharge = WorldUser.GetWatt() >= WorldUser.GetMaxWatt();
	WattText->SetColorAndOpacity(bOvercharge ? MaxWattTextColor : FLinearColor::Black);
}

void UNavigationBarWidget::SetWattType(ETopBarType TopBarType)
{
	bool bSetEventWatt = false;
	if (TopBarType == ETopBarType::CombatReady)
	{
		EHUDWidgetType CurHUDWidgetType = GetCheckedLobbyHUD(this)->GetCurrentHUDWidgetType();
		if (CurHUDWidgetType == EHUDWidgetType::Party)
		{
			const FPartyUIState& PartyUIState = GetHUDStore().GetUIStateManager().GetPartyUIState();
			FSagaType SagaType = PartyUIState.SagaType;

			if (SagaType != SagaTypeInvalid && IsMultiside(SagaType))
			{
				WattTimerText->SetVisibility(ESlateVisibility::Collapsed);
				WattRechargeButton->SetVisibility(ESlateVisibility::Collapsed);

				if (PartyUIState.EventContentType != EventContentTypeInvalid)
				{
					const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(PartyUIState.EventContentType);
					const FEventContentCategoryAssetRow* Row = GetGameResource().GetEventContentCategoryAssetRow(EventContentRow.Category);
					if (Row->bUseWattIcon)
					{
						WattIconImage->SetBrush(Row->WattIcon);

						int32 CurrentWatt = 0;
						const UEventManager& EventManager = GetHUDStore().GetEventManager();
						const FEventContentInfo* EventContentInfo = EventManager.GetEvent(PartyUIState.EventContentType);
						if (EventContentInfo)
						{
							CurrentWatt = EventContentInfo->WattInfo.Watt;
						}

						WattText->SetText(FText::AsNumber(CurrentWatt));
						WattOfMaxText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PointAmount"), FText::GetEmpty(), SystemConst::Q6_EVENT_CONTENT_WATT_MAX));

						WattText->SetColorAndOpacity(FLinearColor::Black);

						bSetEventWatt = true;
					}
				}

				if (!bSetEventWatt)
				{
					Q6JsonLogPawn(Warning, "Event Watt Icon is invalid", Q6KV("EventContentType", (int32)PartyUIState.EventContentType));
				}
			}
		}
	}

	if (!bSetEventWatt)
	{
		WattTimerText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		WattRechargeButton->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const FPointIcon& WattIcon = GetUIResource().GetPointIcon(EPointType::Watt);
		WattIconImage->SetBrush(WattIcon.SmallBrush);

		RefreshWattText();
	}
}

void UNavigationBarWidget::SetNewMarks()
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();

	bool bSubMenuOpenButtonNewMarkVisible = false;
	for (int32 i = 0; i < MainMenuButtonWidgets.Num(); ++i)
	{
		ENewMarkType NewMarkType = NewMarkMgr.GetNaviBarType((EHUDWidgetType)i);
		MainMenuButtonWidgets[i]->SetNewMarkVisible(NewMarkType != ENewMarkType::None);
	}

	for (int32 i = 0; i < SubMenuButtonWidgets.Num(); ++i)
	{
		EHUDWidgetType SubMenuWidgetType = (EHUDWidgetType)(i + MainMenuNumber);
		ENewMarkType NewMarkType = NewMarkMgr.GetNaviBarType(SubMenuWidgetType);	// Add sub menu offset
		SubMenuButtonWidgets[i]->SetNewMarkVisible(NewMarkType != ENewMarkType::None);

		bSubMenuOpenButtonNewMarkVisible |= (NewMarkType == ENewMarkType::Dot);	// Considered red dot mark only
	}

	SubMenuToggleButton->SetNewMarkVisible(bSubMenuOpenButtonNewMarkVisible);

	NewMailIconImage->SetVisibility(NewMarkMgr.GetNewMailVisibility());
}

void UNavigationBarWidget::SetContentState()
{
	EWonderCategory Category(EWonderCategory::MigriumRefinery);
	const FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);

	int32 WonderMainMenuIndex = static_cast<int32>(EHUDWidgetType::Wonder);
	if (MainMenuButtonWidgets.IsValidIndex(WonderMainMenuIndex))
	{
		MainMenuButtonWidgets[WonderMainMenuIndex]->SetMenuButtonBaseContentState(!WonderInfo.bOpened);
	}

	EFeatureOpenType FeatureOpenType(EFeatureOpenType::WeeklyMisson);
	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();

	int32 WeeklyMissionSubMenuIndex = static_cast<int32>(EHUDWidgetType::Mission) - MainMenuNumber;
	if (SubMenuButtonWidgets.IsValidIndex(WeeklyMissionSubMenuIndex))
	{
		SubMenuButtonWidgets[WeeklyMissionSubMenuIndex]->SetMenuButtonBaseContentState(
			!ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType));
	}
}

void UNavigationBarWidget::SetTitleInfo(EHUDWidgetType HUDWidgetType, const FNaviBarState& State)
{
	if (HUDWidgetType == EHUDWidgetType::Main)
	{
		TitleIconImage->SetVisibility(ESlateVisibility::Collapsed);
		ReputationBadgeSizeBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
		const FUserTitleType& UserTitleType = WorldUser.GetTitleType();
		if (UserTitleType == UserTitleTypeInvalid)
		{
			TitleText->SetText(State.TitleText);
		}
		else
		{
			const FCMSUserTitleRow& UserTitleRow = GetCMS()->GetUserTitleRowOrDummy(UserTitleType);

			TitleText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Lobby", "TitleHomeAka")
				, FText::FromString(WorldUser.GetNickname())
				, UserTitleRow.DescName));
		}

		const int32 UserTitleScore = GetUser().GetTitleScore();
		const FAkaAssetRow* AkaAssetRow = GetGameResource().GetAkaAssetRowByPoint(UserTitleScore);
		if (ensure(AkaAssetRow))
		{
			IconBadgeImage->SetBrush(AkaAssetRow->Icon);
		}
	}
	else
	{
		TitleText->SetText(State.TitleText);
		TitleIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		ReputationBadgeSizeBox->SetVisibility(ESlateVisibility::Collapsed);
	}

	SetTitleVisible(!State.TitleText.IsEmpty());
}

bool UNavigationBarWidget::CheckContentOpen(const EHUDWidgetType HUDWidgetType)
{
	switch (HUDWidgetType)
	{
		case EHUDWidgetType::Mission:
		{
			EFeatureOpenType FeatureOpenType(EFeatureOpenType::WeeklyMisson);

			const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();
			bool bEnable = ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType);
			if (!bEnable)
			{
				GetBaseHUD(this)->ShowNotOpenedYetNotification(FeatureOpenType);
				return false;
			}
		}
		break;
		case EHUDWidgetType::Wonder:
		{
			EWonderCategory Category(EWonderCategory::MigriumRefinery);

			const FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
			if (!WonderInfo.bOpened)
			{
				int32 WonderMainMenuIndex = static_cast<int32>(EHUDWidgetType::Wonder);
				if (MainMenuButtonWidgets.IsValidIndex(WonderMainMenuIndex))
				{
					MainMenuButtonWidgets[WonderMainMenuIndex]->SetChecked(false);
				}

				GetCheckedLobbyHUD(this)->ShowNotOpenedYetNotification(Category);
				return false;
			}
		}
		break;
	}

	return true;
}

void UNavigationBarWidget::SetCombatReady(FSagaType InSagaType)
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(InSagaType);
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (SagaRow.ContentType == EContentType::Raid)
	{
		StageText->SetText(Q6Util::GetLocalizedText("Combat", "Raid"));
		StageNumText->SetText(FText());

		if (!ReadyTimerHandle.IsValid())
		{
			GetWorld()->GetTimerManager().SetTimer(ReadyTimerHandle
				, this
				, &UNavigationBarWidget::SetReadyTimer
				, 1.0f
				, true
				, 0.0f);

			SetReadyTimerVisible(true);
		}
	}
	else
	{
		StageText->SetText(Q6Util::GetLocalizedText("Lobby", "Stage"));
		StageNumText->SetText(MakeStageNumberText(SagaRow));
	}

	StageNameText->SetText(SagaRow.DescName);
	RecommendLevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), SagaRow.RecommendLevel));
	StageNaturesWidget->SetStage(SagaRow);
}

void UNavigationBarWidget::SetReadyTimer()
{
	int32 PrepareTime = static_cast<int32>(GetHUDStore().GetRaidManager().GetPrepareTime());
	if (PrepareTime <= 0)
	{
		if (ReadyTimerHandle.IsValid())
		{
			GetWorld()->GetTimerManager().ClearTimer(ReadyTimerHandle);
		}

		SetReadyTimerVisible(false);
		return;
	}

	int32 Minutes = PrepareTime / 60;
	int32 Seconds = PrepareTime % 60;

	ReadyTimerText->SetText(FText::FromString(
		FString::Printf(TEXT("%d%d:%d%d"), Minutes/10, Minutes%10, Seconds/10, Seconds%10)));
}

void UNavigationBarWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByNavigationBar);
	EHSActionType InHSActionType = InAction->GetActionType();

	if (InHSActionType == EHSActionType::WattRechargeResp)
	{
		auto Action = ACTION_PARSE_WattRechargeResp(InAction);
		const FL2CWattRechargeResp& Resp = Action->GetVal();

		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short,
			FText::Format(Q6Util::GetLocalizedText("Popup", "WattChargeNotify"), Resp.DeltaWatt));
	}
	else if (InHSActionType == EHSActionType::PowerPlantRechargeResp)
	{
		auto Action = ACTION_PARSE_PowerPlantRechargeResp(InAction);
		const FL2CPowerPlantRechargeResp& Resp = Action->GetVal();

		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short,
			FText::Format(Q6Util::GetLocalizedText("Popup", "WattChargeNotify"), Resp.DeltaWatt));
	}
	else if (InHSActionType == EHSActionType::FriendBookPosted)
	{
		auto Action = ACTION_PARSE_FriendBookPosted(InAction);
		const FL2CFriendBookNotiPosted& Resp = Action->GetVal();

		GetQ6SaveGame()->SetLatestFriendBookFeed(Resp.FeedId);
	}
	else if (InHSActionType == EHSActionType::FriendBookGetTimeline)
	{
		UQ6SaveGame* InSaveGame = GetQ6SaveGame();
		FFriendBookFeedId CurLatestFeedId = InSaveGame->GetLatestFriendBookFeed();
		auto Action = ACTION_PARSE_FriendBookGetTimeline(InAction);
		const FL2CFriendBookGetTimelineResp& Resp = Action->GetVal();
		for (auto& itFeed : Resp.Feeds)
		{
			if (itFeed.Id > CurLatestFeedId)
			{
				CurLatestFeedId = itFeed.Id;
			}
		}

		if (InSaveGame->GetLatestFriendBookFeed() != CurLatestFeedId)
		{
			InSaveGame->SetLatestFriendBookFeed(CurLatestFeedId);
			const FFriendBookFeedId& InReadFeedId = InSaveGame->GetReadFriendBookFeed();
			ACTION_DISPATCH_FriendBookNewFeedsFromFile(CurLatestFeedId, InReadFeedId);
		}
	}
	else if (InHSActionType == EHSActionType::FriendBookReadTimeline)
	{
		GetQ6SaveGame()->SetReadFriendBookFeeds();
	}
	Refresh();
}

void UNavigationBarWidget::OnGemPurchaseButtonClicked()
{
	GetBaseHUD(this)->OpenGemShopPurchasePopup();
}

void UNavigationBarWidget::OnWattRechargeButtonClicked()
{
	GetCheckedLobbyHUD(this)->OpenWattRechargePopup();
}

void UNavigationBarWidget::OnMailButtonClicked()
{
	GetCheckedLobbyHUD(this)->OpenMailListPopup();
}

void UNavigationBarWidget::OnBackButtonClicked()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("Navigate_Back");
	GetCheckedLobbyHUD(this)->GotoBack();
}

void UNavigationBarWidget::OnSubMenuButtonClicked(int32 InValue)
{
	OnMenuChanged(EHUDWidgetType(InValue));
}

void UNavigationBarWidget::OnSubMenuCloseButtonClicked()
{
	EHUDWidgetType CurHUDWidgetType = GetCheckedLobbyHUD(this)->GetCurrentHUDWidgetType();
	RefreshMenuButtons(CurHUDWidgetType);
}

void UNavigationBarWidget::OnMenuChanged(EHUDWidgetType HUDWidgetType)
{
	if (!CheckContentOpen(HUDWidgetType))
	{
		return;
	}

	ALobbyHUD* LobbyHUD = GetCheckedLobbyHUD(this);
	EHUDWidgetType CurHUDWidgetType = LobbyHUD->GetCurrentHUDWidgetType();

	FString NaviButtonString = FString::Printf(TEXT("Navigate_%s"), *ENUM_TO_STRING(EHUDWidgetType, HUDWidgetType));
	TUTORIAL_MONITORING_BUTTON_CLICK(NaviButtonString);
	RefreshMenuButtons(HUDWidgetType);

	switch (HUDWidgetType)
	{
		case EHUDWidgetType::Setting:
			LobbyHUD->OpenSettingPopup();
			break;
		default:
			if (LobbyHUD->GetCurrentHUDWidgetType() == HUDWidgetType)
			{
				LobbyHUD->ReEnterHUD();
			}
			else
			{
				LobbyHUD->SetHUDType(HUDWidgetType);
			}
			break;
	}
}

void UNavigationBarWidget::OnTitleSelectButtonClicked()
{
	EHUDWidgetType CurHUDWidgetType = GetCheckedLobbyHUD(this)->GetCurrentHUDWidgetType();
	if (CurHUDWidgetType == EHUDWidgetType::Main)
	{
		OnMenuChanged(EHUDWidgetType::Account);
	}
}

void UNavigationBarWidget::SetNaviBar(EHUDWidgetType HUDWidgetType, const FNaviBarState& State)
{
	SetTitleInfo(HUDWidgetType, State);

	SetTopBarType(State.TopBarType);
	SetBottomBarVisible(State.bBottomBarVisible);
	SetBackButtonVisible(State.bBackVisible);
	SetReadyTimerVisible(State.bBackVisible);
	SetWattType(State.TopBarType);

	SetNewMarks();
	SetContentState();
}

void UNavigationBarWidget::SetTitleVisible(bool bInVisible)
{
	TitleBorder->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}
