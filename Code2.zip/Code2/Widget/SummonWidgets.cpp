// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "SummonWidgets.h"

#include "CharacterWidgets.h"
#include "CommonWidgets.h"
#include "HUDStore/EventManager.h"
#include "GameResource.h"
#include "HUD/BaseHUD.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "LobbyObj_gen.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "Q6.h"
#include "Q6ClientNetwork.h"
#include "Q6GameInstance.h"
#include "SummonManager.h"
#include "SwipeWidgets.h"
#include "SystemConst_gen.h"
#include "Tutorial/LobbyTutorial.h"
#include "HSAction.h"
#include "Q6SummonGameMode.h"
#include "UIClassResource.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Summon"), STAT_OnHSEventBySummon, STATGROUP_HSTORE);

static bool CanRepeatSummon(const UObject* InObject)
{
	ALobbyTutorial* LobbyTutorial = GetLobbyTutorial(InObject);
	if (!LobbyTutorial)
	{
		// if summon again in summon map, always enable repeat summon.
		return true;
	}

	return LobbyTutorial->IsCheckInOpened();
}

USummonButtonWidget::USummonButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bIsFree(false)
{
}

void USummonButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* PurchaseButton = CastChecked<UButton>(GetWidgetFromName("Purchase"));
	PurchaseButton->OnClicked.AddUniqueDynamic(this, &USummonButtonWidget::OnPurchaseButtonClicked);

	SummonText = CastChecked<UTextBlock>(GetWidgetFromName("Summon"));
	CountText = CastChecked<UTextBlock>(GetWidgetFromName("Count"));
	FreeTextBorder = CastChecked<UBorder>(GetWidgetFromName("Free"));
	BonusBorder = CastChecked<UBorder>(GetWidgetFromName("Bonus"));
	SummonPointWidget = CastChecked<USummonPointWidget>(GetWidgetFromName("SummonPoint"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	bIsFree = false;
}

void USummonButtonWidget::SetBoxProduct(const FCMSBoxProductRow& BoxProductRow)
{
	BoxProductType = BoxProductRow.CmsType();

	// Set texts
	if (BoxProductRow.GroupCount == 1)
	{
		// Single summon

		SummonText->SetText(Q6Util::GetLocalizedText("Lobby", "SummonBtn1Title"));
		CountText->SetText(Q6Util::GetLocalizedText("Lobby", "SummonBtn1SubTitle"));
	}
	else
	{
		// Bundle summon

		SummonText->SetText(Q6Util::GetLocalizedText("Lobby", "SummonBtn10Title"));
		CountText->SetText(Q6Util::GetLocalizedText("Lobby", "SummonBtn10SubTitle"));
	}

	if (bIsFree)
	{
		NewMarkImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		FreeTextBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		SummonPointWidget->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		NewMarkImage->SetVisibility(ESlateVisibility::Collapsed);
		FreeTextBorder->SetVisibility(ESlateVisibility::Collapsed);
		SummonPointWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		SummonPointWidget->SetConsumePoint(BoxProductRow);
	}

	BonusBorder->SetVisibility(BoxProductRow.GetBonusBox().Num() > 0 ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

ECurrencyCheckType GetCurrencyCheckType(ESummonType SummonType)
{
	switch (SummonType)
	{
		case ESummonType::Basic:
		case ESummonType::Event:
			return ECurrencyCheckType::AllSummon;

		case ESummonType::Friendship:
		case ESummonType::Relic:
			return ECurrencyCheckType::RelicSummon;
		
		case ESummonType::Sculpture:
			return ECurrencyCheckType::SculptureSummon;
	}

	Q6JsonLogRoze(Warning, "GetCurrencyCheckType - Not found currency check type", Q6KV("SummonType", (int32)SummonType));
	return ECurrencyCheckType::None;
}

void USummonButtonWidget::OnPurchaseButtonClicked()
{
	ALobbyHUD* LobbyHUD = GetCheckedLobbyHUD(this);
	if (LobbyHUD->GetOpenedPopup(GetUIClassResource().CurrencyUsePopupWidgetClass))
	{
		return;
	}

	TUTORIAL_MONITORING_BUTTON_CLICK("Purchase");
	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(BoxProductType);
	ECurrencyCheckType CurrencyCheckType = GetCurrencyCheckType(BoxProductRow.SummonType);
	if (LobbyHUD->CheckMaxItemNum(CurrencyCheckType, true))
	{
		return;
	}

	if (BoxProductRow.NeedPickupMileage > 0)
	{
		int32 Mileage = GetHUDStore().GetSummonManager().GetMileage(BoxProductRow.EventId);
		if (Mileage >= BoxProductRow.NeedPickupMileage)
		{
			LobbyHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "SummonMaxMileage"));
			return;
		}
	}

	bool bCanRepeatSummon = CanRepeatSummon(this);

	if (bIsFree)
	{
		GetHUDStore().GetSummonManager().ReqBoxPurchase(BoxProductType, bCanRepeatSummon);
	}
	else
	{
		UCurrencyUsePopupWidget* CurrencyUsePopup = LobbyHUD->OpenCurrencyUsePopup();
		CurrencyUsePopup->SetPurchaseInfo(BoxProductType);
		CurrencyUsePopup->OnCurrencyUsedDelegate.BindUObject(this, &USummonButtonWidget::OnSummonPurchase);
	}
}

void USummonButtonWidget::OnSummonPurchase()
{
	bool bCanRepeatSummon = CanRepeatSummon(this);
	GetHUDStore().GetSummonManager().ReqBoxPurchase(BoxProductType, bCanRepeatSummon);
}

USummonResultWidget::USummonResultWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonResultWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SingleItemWidget = CastChecked<UItemCardWidget>(GetWidgetFromName("Item"));

	FString WidgetName;
	for (int32 n = 1; n <= SystemConst::Q6_SUMMON_BUNDLE_ITEM_COUNT; ++n)
	{
		WidgetName = FString::Printf(TEXT("Item%d"), n);
		ItemWidgets.AddUnique(CastChecked<UItemCardWidget>(GetWidgetFromName(*WidgetName)));
	}

	BackButton = CastChecked<UButton>(GetWidgetFromName("Dismiss"));
	BackButton->OnClicked.AddUniqueDynamic(this, &USummonResultWidget::OnBackButtonClicked);

	SummonRepeatButton = CastChecked<UButton>(GetWidgetFromName("SummonRepeat"));
	SummonRepeatButton->OnClicked.AddUniqueDynamic(this, &USummonResultWidget::OnSummonRepeatButtonClicked);

	MileageBorder = CastChecked<UBorder>(GetWidgetFromName("BorderMileage"));
	DeltaMileageText = CastChecked<UTextBlock>(GetWidgetFromName("DeltaMileage"));
	OwnedMileageText = CastChecked<UTextBlock>(GetWidgetFromName("OwnedMileage"));

	CurrencyBorder = CastChecked<UBorder>(GetWidgetFromName("CurrencyOwned"));
	OwnedPointWidget = CastChecked<USummonPointWidget>(GetWidgetFromName("OwnedPoint"));
	ConsumePointWidget = CastChecked<USummonPointWidget>(GetWidgetFromName("ConsumePoint"));

	SummonCountText = CastChecked<UTextBlock>(GetWidgetFromName("SummonCount"));

	// Animations

	SingleSummonAnim = GetWidgetAnimationFromName(this, "AnimSingleSummon");
	check(SingleSummonAnim);

	BundleSummonAnim = GetWidgetAnimationFromName(this, "AnimBundleSummon");
	check(BundleSummonAnim);
}

void USummonResultWidget::OnBackButtonClicked()
{
	OnBackDelegate.ExecuteIfBound();
}

void USummonResultWidget::OnSummonRepeatButtonClicked()
{
	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(BoxProductType);
	ECurrencyCheckType CurrencyCheckType = GetCurrencyCheckType(BoxProductRow.SummonType);
	ABaseHUD* BaseHUD = GetBaseHUD(this);
	check(BaseHUD);

	if (BaseHUD->CheckMaxItemNum(CurrencyCheckType, true))
	{
		return;
	}

	if (BoxProductRow.NeedPickupMileage > 0)
	{
		int32 Mileage = GetHUDStore().GetSummonManager().GetMileage(BoxProductRow.EventId);
		if (Mileage >= BoxProductRow.NeedPickupMileage)
		{
			BaseHUD->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "SummonMaxMileage"));
			return;
		}
	}

	UCurrencyUsePopupWidget* CurrencyUsePopup = BaseHUD->OpenCurrencyUsePopup();
	CurrencyUsePopup->SetPurchaseInfo(BoxProductType);
	CurrencyUsePopup->OnCurrencyUsedDelegate.BindUObject(this, &USummonResultWidget::OnSummonPurchaseRepeat);
}

void USummonResultWidget::OnSummonPurchaseRepeat()
{
	bool bCanRepeatSummon = CanRepeatSummon(this);
	GetHUDStore().GetSummonManager().ReqBoxPurchase(BoxProductType, bCanRepeatSummon);
}

void USummonResultWidget::ClearResult()
{
	SingleItemWidget->SetEmpty();

	for (UItemCardWidget* ItemCardWidget : ItemWidgets)
	{
		ItemCardWidget->SetEmpty();
	}
}

void USummonResultWidget::ShowDiskRewardNotification()
{
	ABaseHUD* BaseHUD = GetBaseHUD(this);
	check(BaseHUD);

	TArray<FText> SummonTexts;
	const TArray<FSummonDiskReward>& DiskRewards = GetHUDStore().GetSummonManager().GetSummonDiskRewards();
	for (const FSummonDiskReward& Reward : DiskRewards)
	{
		if (Reward.CurrencyType == ECurrencyType::CharacterDisk)
		{
			const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(FCharacterType(Reward.ItemType));
			SummonTexts.Add(FText::Format(Q6Util::GetLocalizedText("Common", "SummonCharacterDiskReward"), CharacterRow.GetUnit().DescName, Reward.SummonCount));
		}
		else if (Reward.CurrencyType == ECurrencyType::SculptureDisk)
		{
			const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(FSculptureType(Reward.ItemType));
			SummonTexts.Add(FText::Format(Q6Util::GetLocalizedText("Common", "SummonSculptureDiskReward"), SculptureRow.DescName, Reward.SummonCount));
		}
		else if (Reward.CurrencyType == ECurrencyType::RelicDisk)
		{
			const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(FRelicType(Reward.ItemType));
			SummonTexts.Add(FText::Format(Q6Util::GetLocalizedText("Common", "SummonRelicDiskReward"), RelicRow.DescName, Reward.SummonCount));
		}
	}

	BaseHUD->ShowNotification(ENotificationType::Short, SummonTexts);
}

void USummonResultWidget::SetCharacterResult(int32 Index, const FCharacterInfo* Info, bool IsOnce)
{
	UItemCardWidget* Widget = IsOnce ? SingleItemWidget : ItemWidgets[Index];
	check(Widget);

	if (Info)
	{
		Widget->SetCharacter(*Info);
		Widget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		Widget->SetForSummon(false, Info->Grade);
	}
	else
	{
		Widget->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void USummonResultWidget::SetSculptureResult(int32 Index, const FSculptureInfo* Info, bool IsOnce)
{
	UItemCardWidget* Widget = IsOnce ? SingleItemWidget : ItemWidgets[Index];
	check(Widget);

	if (Info)
	{
		Widget->SetSculpture(*Info);
		Widget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		Widget->SetForSummon(false, Info->Grade);
	}
	else
	{
		Widget->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void USummonResultWidget::SetRelicResult(int32 Index, const FRelicInfo* Info, bool IsOnce)
{
	UItemCardWidget* Widget = IsOnce ? SingleItemWidget : ItemWidgets[Index];
	check(Widget);

	if (Info)
	{
		Widget->SetRelic(*Info);
		Widget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		Widget->SetForSummon(false, Info->Grade);
	}
	else
	{
		Widget->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void USummonResultWidget::SetSummonResult()
{
	const FSummonResult& Result = GetHUDStore().GetSummonManager().GetSummonResult();
	BoxProductType = Result.BoxProductType;

	ensure(Result.Categories.Num() <= ItemWidgets.Num());

	if (Result.Categories.Num() <= 0)
	{
		Q6JsonLogRoze(Warning, "USummonResultWidget::SetSummonResult - Didn't get any summon item");
		return;
	}

	ClearResult();

	bool IsOnce = Result.Categories.Num() == SystemConst::Q6_SUMMON_SINGLE_ITEM_COUNT;

	for (int32 i = 0, ci = 0, si = 0, ri = 0; i < Result.Categories.Num(); ++i)
	{
		switch (Result.Categories[i])
		{
		case ELootCategory::CharacterCard:
			{
				auto Info = (ci < Result.Characters.Num()) ? &(Result.Characters[ci++]) : nullptr;
				SetCharacterResult(i, Info, IsOnce);
			}
			break;
		case ELootCategory::SculptureCard:
			{
				auto Info = (si < Result.Sculptures.Num()) ? &(Result.Sculptures[si++]) : nullptr;
				SetSculptureResult(i, Info, IsOnce);
			}
			break;
		case ELootCategory::RelicCard:
			{
				auto Info = (ri < Result.Relics.Num()) ? &(Result.Relics[ri++]) : nullptr;
				SetRelicResult(i, Info, IsOnce);
			}
			break;
		default:
			break;
		}
	}

	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(Result.BoxProductType);
	MileageBorder->SetVisibility(BoxProductRow.NeedPickupMileage > 0 ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	int32 Mileage = GetHUDStore().GetSummonManager().GetMileage(BoxProductRow.EventId);
	OwnedMileageText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PointCount"), FText::AsNumber(Mileage)));

	if (Result.bPickup)
	{
		SummonRepeatButton->SetVisibility(ESlateVisibility::Collapsed);
		CurrencyBorder->SetVisibility(ESlateVisibility::Collapsed);

		DeltaMileageText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "SubPointCount"), FText::AsNumber(BoxProductRow.NeedPickupMileage)));
		DeltaMileageText->SetColorAndOpacity(GetUIResource().GetLackColor());
	}
	else
	{
		SummonRepeatButton->SetVisibility(Result.bCanRepeatSummon ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);

		CurrencyBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		FString DeltaMileageStr = FString::Printf(TEXT("(+%d)"), BoxProductRow.NeedPickupMileage);
		DeltaMileageText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "AddPointCount"), FText::AsNumber(BoxProductRow.GainPickupMileage)));
		DeltaMileageText->SetColorAndOpacity(GetUIResource().GetEnoughColor());

		OwnedPointWidget->SetOwnedPoint(BoxProductRow.SummonType, BoxProductRow.PointType);
		ConsumePointWidget->SetConsumePoint(BoxProductRow);

		SummonCountText->SetText(Q6Util::GetLocalizedText("Lobby", BoxProductRow.GroupCount > 1 ? "SummonBtn10SubTitle" : "SummonBtn1SubTitle"));
	}

	ShowDiskRewardNotification();

	PlayAnimation(IsOnce ? SingleSummonAnim : BundleSummonAnim);
}

USummonPageWidget::USummonPageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonPageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	SingleButtonWidget = CastChecked<USummonButtonWidget>(GetWidgetFromName("SingleButton"));
	BundleButtonWidget = CastChecked<USummonButtonWidget>(GetWidgetFromName("BundleButton"));
	PeriodText = CastChecked<UTextBlock>(GetWidgetFromName("Period"));
	ConsumeDescriptionText = CastChecked<UTextBlock>(GetWidgetFromName("ConsumeDescription"));
	SummonPointWidget = CastChecked<USummonPointWidget>(GetWidgetFromName("SummonPoint"));

	PickupWidget = CastChecked<USummonPickupWidget>(GetWidgetFromName("Pickup"));
	PickupWidget->OnPickupButtonClickedDelegate.BindUObject(this, &USummonPageWidget::OpenSelectPickupPopup);
}

void USummonPageWidget::SetSummonPage(int32 PageKey)
{
	TArray<const FCMSBoxProductRow*> BoxProductArray;
	if (!GetCMS()->GetBoxProductRows(PageKey, BoxProductArray))
	{
		Q6JsonLogRoze(Error, "USummonPageWidget::SetSummonPage - Can't find any box product", Q6KV("PageKey", PageKey));
		return;
	}

	// Set purchase buttons

	SingleButtonWidget->SetVisibility(ESlateVisibility::Collapsed);
	BundleButtonWidget->SetVisibility(ESlateVisibility::Collapsed);

	ESummonPointType PointType = ESummonPointType::AnyGem;
	ESummonType SummonType = ESummonType::Basic;
	int32 EventId = 0;

	const UEventManager& EventMgr = GetHUDStore().GetEventManager();
	for (auto& elem : BoxProductArray)
	{
		if (!EventMgr.GetEventSchedule(elem->EventId))
		{
			continue;
		}

		PointType = elem->PointType;
		SummonType = elem->SummonType;
		EventId = elem->EventId;
		BoxProductType = elem->CmsType();

		const FBoxProductType boxId = elem->CmsType();
		bool bFreeChance = GetHUDStore().GetSummonManager().IsSummonFree(boxId);
		bool bTutorial = GetHUDStore().GetWorldUser().IsTutorialSummon(boxId);
		if (elem->GroupCount > SystemConst::Q6_SUMMON_SINGLE_ITEM_COUNT)
		{
			BundleButtonWidget->SetFree(bFreeChance);
			BundleButtonWidget->SetBoxProduct(*elem);
			BundleButtonWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
		else
		{
			SingleButtonWidget->SetFree(bFreeChance || bTutorial);
			SingleButtonWidget->SetBoxProduct(*elem);
			SingleButtonWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
	}
	check(EventId > 0);

	SummonPointWidget->SetOwnedPoint(SummonType, PointType);

	// Set page info

	const FEventScheduleInfo* EventSchedule = GetHUDStore().GetEventManager().GetEventSchedule(EventId);
	if (!EventSchedule)
	{
		Q6JsonLogRoze(Error, "USummonPageWidget::SetSummonPage - Invalid event", Q6KV("EventId", EventId));
		return;
	}

	if (SummonType == ESummonType::Event && !UCMS::IsInfinityEventScheduleFormat(*EventSchedule))
	{
		FText Period = FText::Format(Q6Util::GetLocalizedText("Lobby", "SummonPeriod"),
			Q6Util::GetLocalDateTimeText(EventSchedule->StartDate), Q6Util::GetLocalDateTimeText(EventSchedule->EndDate));
		PeriodText->SetText(Period);
	}
	else
	{
		PeriodText->SetText(FText::GetEmpty());
	}

	const FSummonAssetRow& SummonAssetRow = GetGameResource().GetSummonAssetRow(EventId);
	ConsumeDescriptionText->SetText(SummonAssetRow.ConsumeDescription);
	BGImage->SetBrushFromSoftTextureWhenLoadingFinished(SummonAssetRow.BGTexture);

	PickupWidget->SetMileage(BoxProductType);
}

void USummonPageWidget::OpenSelectPickupPopup()
{
	USummonSelectPickupPopupWidget* SelectPickupPopup = CastChecked<USummonSelectPickupPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(SelectPickupPopupClass));
	check(SelectPickupPopup);

	SelectPickupPopup->SetPickupList(BoxProductType);
	SelectPickupPopup->OnPickupSelectedDelegate.BindUObject(this, &USummonPageWidget::OnPickupItemSelected);
}

void USummonPageWidget::OpenPickupConfirmPopup(FBoxProductType InBoxProductType, int32 ItemType)
{
	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(InBoxProductType);
	if (BoxProductRow.PickupCategory == ELootCategory::CharacterCard)
	{
		USummonPickupConfirmPopupWidget* PickupConfirmPopup = CastChecked<USummonPickupConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(PickupConfirmPopupClass));
		PickupConfirmPopup->SetCharacter(FCharacterType(ItemType), BoxProductRow);
	}
}

void USummonPageWidget::OnPickupItemSelected(int32 ItemType)
{
	OpenPickupConfirmPopup(BoxProductType, ItemType);
}


USummonWidget::USummonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("Menu"));

	SummonSwipeWidget = CastChecked<UPageSwipeWidget>(GetWidgetFromName("SummonSwipe"));
	SummonSwipeWidget->OnSetPageDelegate.BindUObject(this, &USummonWidget::OnSummonPageSet);
	SummonSwipeWidget->OnFocusedPageDelegate.BindUObject(this, &USummonWidget::OnSummonPageChanged);

	ResultWidget = CastChecked<USummonResultWidget>(GetWidgetFromName("Result"));
	ResultWidget->OnBackDelegate.BindUObject(this, &USummonWidget::OnResultMenuBack);
}

void USummonWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Summon);
	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::NewMark);
	SubscribeToStore(EHSType::Mail);

	const FSummonUIState* UIState = GetUIState()->CastToSummonUIState();
	check(UIState);

	if (UIState->Sequence == ESummonSequence::WaitSchedule)
	{
		GetHUDStore().GetSummonManager().ReqBoxSchedule();
	}
}

void USummonWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FSummonUIState* UIState = GetUIState()->CastToSummonUIState();
	check(UIState);

	int32 WidgetIndex = (int32)UIState->Sequence;
	MenuSwitcher->SetActiveWidgetIndex(WidgetIndex);

	if (UIState->Sequence == ESummonSequence::Main)
	{
		ELobbyTutorial InLobbyTutorialStep = GetLobbyTutorial(this)->GetCurrentTutorialStep();
		if (InLobbyTutorialStep == ELobbyTutorial::CharacterSummon)
		{
			int32 PageIndex = GetHUDStore().GetSummonManager().GetPageIndex(CHARACTER_SUMMON_PAGE_KEY);
			RefreshSummonPage(PageIndex + 1);
		}
		else if (InLobbyTutorialStep == ELobbyTutorial::SculptureSummon)
		{
			int32 PageIndex = GetHUDStore().GetSummonManager().GetPageIndex(SCULPTURE_SUMMON_PAGE_KEY);
			RefreshSummonPage(PageIndex + 1);
		}
		else if (InLobbyTutorialStep == ELobbyTutorial::RelicSummon)
		{
			int32 PageIndex = GetHUDStore().GetSummonManager().GetPageIndex(RELIC_SUMMON_PAGE_KEY);
			RefreshSummonPage(PageIndex + 1);
		}
		else
		{
			RefreshSummonPage(UIState->FocusPage);
		}
	}
}

void USummonWidget::OnSummonPageSet(UWidget* ViewWidget, int32 PageNum)
{
	USummonPageWidget* SummonPageWidget = CastChecked<USummonPageWidget>(ViewWidget);
	check(PageNum > 0);
	SummonPageWidget->SetSummonPage(PageNum);
}

void USummonWidget::RefreshSummonPage(int32 FocusPage)
{
	auto& OrderedPageList = GetHUDStore().GetSummonManager().GetOrderedPageList();

	SummonSwipeWidget->SetPageCount(OrderedPageList, FocusPage);
}

void USummonWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventBySummon);

	switch(InAction->GetActionType())
	{
		case EHSActionType::SummonBoxScheduleResp:
		case EHSActionType::DevAddCurrencyResp:
		case EHSActionType::DevSummonMileageSetResp:
		case EHSActionType::MailReceiveResp:
			RefreshMenu();
			break;
		case EHSActionType::SummonFriendShip:
			ResultWidget->SetSummonResult();
			RefreshMenu();
			break;
		case EHSActionType::ContentsResetTime:
			GetHUDStore().GetSummonManager().ReqBoxSchedule();
			break;
	}
}

void USummonWidget::OnSummonPageChanged(int32 NewPage)
{
	ACTION_DISPATCH_SummonPageChange(NewPage);
}

void USummonWidget::OnResultMenuBack()
{
	ACTION_DISPATCH_MenuBack();
	RefreshMenu();
}

USummonPickupWidget::USummonPickupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonPickupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MileageAmountText = CastChecked<UTextBlock>(GetWidgetFromName("MileageAmount"));

	UButton* PickupButton = CastChecked<UButton>(GetWidgetFromName("Pickup"));
	PickupButton->OnClicked.AddUniqueDynamic(this, &USummonPickupWidget::OnPickupButtonClicked);

	MaxMileageLoopAnim = GetWidgetAnimationFromName(this, "AnimMaxMileageLoop");
	NormalAnim = GetWidgetAnimationFromName(this, "AnimNormal");
};

void USummonPickupWidget::SetMileage(FBoxProductType BoxProductType)
{
	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(BoxProductType);
	if (BoxProductRow.NeedPickupMileage > 0)
	{
		SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		int32 Mileage = GetHUDStore().GetSummonManager().GetMileage(BoxProductRow.EventId);

		MileageAmountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PointCount"), FText::AsNumber(Mileage)));

		if (Mileage >= BoxProductRow.NeedPickupMileage)
		{
			StopAnimation(NormalAnim);
			PlayAnimation(MaxMileageLoopAnim, 0.f, 0);
		}
		else
		{
			StopAnimation(MaxMileageLoopAnim);
			PlayAnimation(NormalAnim);
		}
	}
	else
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
}

void USummonPickupWidget::OnPickupButtonClicked()
{
	OnPickupButtonClickedDelegate.ExecuteIfBound();
}

USummonPickupCharacterWidget::USummonPickupCharacterWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonPickupCharacterWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	CharacterLabelWidget = CastChecked<UCharacterLabelWidget>(GetWidgetFromName("CharacterLabel"));

	PickupButton = CastChecked<UButton>(GetWidgetFromName("Pickup"));
	PickupButton->OnClicked.AddUniqueDynamic(this, &USummonPickupCharacterWidget::OnPickupButtonClicked);
}

void USummonPickupCharacterWidget::SetCharacter(const FCharacterType& CharacterType, bool bInEnabled)
{
	const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(CharacterType);
	const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(CharacterRow.CmsType());
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.GetDefaultLongIconTexture());

	CharacterLabelWidget->SetCharacter(CharacterRow);
	PickupButton->SetIsEnabled(bInEnabled);
}

void USummonPickupCharacterWidget::OnPickupButtonClicked()
{
	OnPickupButtonClickedDelegate.ExecuteIfBound();
}

USummonSelectPickupPopupWidget::USummonSelectPickupPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonSelectPickupPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PickupListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("PickupList"));
	PeriodText = CastChecked<UTextBlock>(GetWidgetFromName("Period"));
}

void USummonSelectPickupPopupWidget::SetPickupList(FBoxProductType BoxProductType)
{
	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(BoxProductType);

	SetTitle(Q6Util::GetLocalizedText("Popup", "ExchangeCharacterListTitle"));
	SetContent(FText::Format(Q6Util::GetLocalizedText("Popup", "ExchangeCharacterListContent"), FText::AsNumber(BoxProductRow.NeedPickupMileage)));
	SetConfirmFlags(EConfirmPopupFlag::No);

	const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(BoxProductRow.EventId);
	if (!ScheduleInfo)
	{
		Q6JsonLogRoze(Warning, "USummonSelectPickupPopupWidget::SetPickupList - Not found event schedule", Q6KV("EventId", BoxProductRow.EventId));
		return;
	}

	if (!UCMS::IsInfinityEventScheduleFormat(*ScheduleInfo))
	{
		PeriodText->SetText(FText::GetEmpty());
	}
	else
	{
		FText Period = FText::Format(Q6Util::GetLocalizedText("Lobby", "ExchangePeriod"),
			Q6Util::GetLocalDateTimeText(ScheduleInfo->StartDate), Q6Util::GetLocalDateTimeText(ScheduleInfo->EndDate));
		PeriodText->SetText(Period);
	}

	int32 Mileage = GetHUDStore().GetSummonManager().GetMileage(BoxProductRow.EventId);
	SetCharacterList(BoxProductRow.PickupValues, Mileage >= BoxProductRow.NeedPickupMileage);
}

void USummonSelectPickupPopupWidget::SetCharacterList(const TArray<int32>& CharacterTypes, bool bPickupEnabled)
{
	PickupListWidget->ClearList();

	for (const int32& CharacterType : CharacterTypes)
	{
		USummonPickupCharacterWidget* CharacterWidget = CastChecked<USummonPickupCharacterWidget>(PickupListWidget->AddChildAtLastIndex());
		CharacterWidget->SetCharacter(FCharacterType(CharacterType), bPickupEnabled);
		CharacterWidget->OnPickupButtonClickedDelegate.BindUObject(this, &USummonSelectPickupPopupWidget::OnSelectedPickupItem, CharacterType);
	}
}

void USummonSelectPickupPopupWidget::OnSelectedPickupItem(int32 ItemType)
{
	OnPickupSelectedDelegate.ExecuteIfBound(ItemType);

	ClosePopup();
}

USummonPickupConfirmPopupWidget::USummonPickupConfirmPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonPickupConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	CharacterLabelWidget = CastChecked<UCharacterLabelWidget>(GetWidgetFromName("CharacterLabel"));
	OwnedMileageText = CastChecked<UTextBlock>(GetWidgetFromName("OwnedMileage"));
	RequiredMileageText = CastChecked<UTextBlock>(GetWidgetFromName("RequiredMileage"));
}

void USummonPickupConfirmPopupWidget::SetCharacter(FCharacterType SelectedCharacterType, const FCMSBoxProductRow& BoxProductRow)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "ExchangeCharacterConfirmTitle"));
	SetContent(FText::Format(Q6Util::GetLocalizedText("Popup", "ExchangeCharacterConfirmContent"), FText::AsNumber(BoxProductRow.NeedPickupMileage)));

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(SelectedCharacterType);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.CombatPortraitTexture);

	const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(SelectedCharacterType);
	CharacterLabelWidget->SetCharacter(CharacterRow);

	int32 Mileage = GetHUDStore().GetSummonManager().GetMileage(BoxProductRow.EventId);
	OwnedMileageText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PointCount"), FText::AsNumber(Mileage)));
	RequiredMileageText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PointCount"), FText::AsNumber(BoxProductRow.NeedPickupMileage)));

	OnConfirmPopupDelegate.BindUObject(this, &USummonPickupConfirmPopupWidget::OnPickupConfirmButtonClicked, BoxProductRow.CmsType(), SelectedCharacterType.x);
}

void USummonPickupConfirmPopupWidget::OnPickupConfirmButtonClicked(EConfirmPopupFlag ConfirmFlag, FBoxProductType BoxProductType, int32 ItemType)
{
	if (ConfirmFlag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	const FCMSBoxProductRow& BoxProductRow = GetCMS()->GetBoxProductRowOrDummy(BoxProductType);
	ECurrencyCheckType CurrencyCheckType = GetCurrencyCheckType(BoxProductRow.SummonType);
	if (GetCheckedLobbyHUD(this)->CheckMaxItemNum(CurrencyCheckType, true))
	{
		return;
	}

	bool bCanRepeatSummon = CanRepeatSummon(this);
	GetHUDStore().GetSummonManager().ReqPickup(BoxProductType, ItemType, bCanRepeatSummon);
}

USummonPointWidget::USummonPointWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void USummonPointWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TicketWidget = CastChecked<UPointWidget>(GetWidgetFromName("Ticket"));
	PointWidget = CastChecked<UPointWidget>(GetWidgetFromName("Point"));
};

void USummonPointWidget::SetConsumePoint(const FCMSBoxProductRow& BoxProductRow)
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	int32 RequiredTicket = FMath::Min((BoxProductRow.PointCount / SystemConst::Q6_SUMMON_POINTS_PER_TICKET), WorldUser.GetSummonTicket());
	int32 OwnedPoint = GetHUDStore().GetWorldUser().GetPoint(BoxProductRow.PointType);
	if (BoxProductRow.SummonType == ESummonType::Basic
		|| BoxProductRow.SummonType == ESummonType::Event)
	{
		// ticket
		TicketWidget->SetPointType(EPointType::SummonTicket, EPointWidgetOption::LessEqual);
		TicketWidget->SetPoint(RequiredTicket, WorldUser.GetSummonTicket());
		TicketWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		// point
		PointWidget->SetPointType(BoxProductRow.PointType, EPointWidgetOption::LessEqual);
		PointWidget->SetPoint(BoxProductRow.PointCount - (RequiredTicket * SystemConst::Q6_SUMMON_POINTS_PER_TICKET), OwnedPoint);
		PointWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		// ticket
		TicketWidget->SetVisibility(ESlateVisibility::Collapsed);
		// point
		PointWidget->SetPointType(BoxProductRow.PointType, EPointWidgetOption::LessEqual);
		PointWidget->SetPoint(BoxProductRow.PointCount, OwnedPoint);
		PointWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void USummonPointWidget::SetOwnedPoint(ESummonType SummonType, ESummonPointType PointType)
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	if (SummonType == ESummonType::Basic || SummonType == ESummonType::Event)
	{
		TicketWidget->SetPointType(EPointType::SummonTicket, EPointWidgetOption::NONE);
		TicketWidget->SetCurPoint(WorldUser.GetSummonTicket());
		TicketWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		TicketWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	PointWidget->SetPointType(PointType, EPointWidgetOption::NONE);
	PointWidget->SetCurPoint(GetHUDStore().GetWorldUser().GetPoint(PointType));
}
