// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "CharacterIntroductionWidget.generated.h"

struct FCharacterIntroductionInfo;

/**
 * Character Introduction Widget
 */
UCLASS()
class Q6_API UCharacterIntroductionWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UCharacterIntroductionWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;
	
	bool SetInfo(FCharacterIntroductionInfo* InInfo);

	UFUNCTION(BlueprintImplementableEvent)
	void SetEnableNickName(bool bInEnable);

	UFUNCTION(BlueprintImplementableEvent)
	void SetColor(const FLinearColor& InColor);

	UFUNCTION(BlueprintImplementableEvent)
	void SetOffset(const FVector2D& InOffset);

	void PlayStart(bool bInAutoPlaying, bool bInFastForwarding);
	void PlayEnd();

	UFUNCTION(BlueprintImplementableEvent)
	void PlayEndWithDelay(float InDelay);

	bool IsPlayingEnd() const { return bPlayingEnd; }

	FSimpleDelegate OnCharacterIntroductionEndDelegate;

private:
	UFUNCTION(BlueprintCallable)
	void PlayEndInternal();

	UPROPERTY(EditDefaultsOnly)
	float DefaultPlayEndDelay;

	UPROPERTY(EditDefaultsOnly)
	float AutoPlayPlayEndDelay;

	UPROPERTY(EditDefaultsOnly)
	float FastForwardPlayEndDelay;

	UPROPERTY(Transient)
	UWidgetAnimation* StartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EndAnim;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* NickNameText;

	UPROPERTY()
	UTextBlock* CastingVoiceText;

	float PlayEndDelay;
	bool bAutoPlayEnd;
	bool bPlayingEnd;
};
