// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "WonderWidgets.h"

#include "AlchemylabManager.h"
#include "AlchemyLabWidgets.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "MigriumRefineryWidgets.h"
#include "NewMarkManager.h"
#include "PetManager.h"
#include "PetWidgets.h"
#include "PowerPlantManager.h"
#include "PowerPlantWidgets.h"
#include "PyramidManager.h"
#include "PyramidWidgets.h"
#include "SmelterManager.h"
#include "TempleManager.h"
#include "TempleWidgets.h"
#include "GameResource.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6UIDefine.h"
#include "SystemConstHelper.h"
#include "VacationManager.h"
#include "VacationWidgets.h"
#include "LevelUtil.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Wonder"), STAT_OnHSEventByWonder, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Wonder Upgrade Widget
//////////////////////////////////////////////////////////////////////////
void UWonderUpgradeWidget::NativeConstruct()
{

	Super::NativeConstruct();

	CurLevelText = CastChecked<UQ6TextBlock>(GetWidgetFromName("CurLevel"));
	TargetLevelText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TargetLevel"));
	TimeLeftText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TimeLeft"));
	TimeLeftBar = CastChecked<UProgressBar>(GetWidgetFromName("BarTimeLeft"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	UpgradeButton = CastChecked<UQ6Button>(GetWidgetFromName("Upgrade"));
	UpgradeButton->OnClicked.AddUniqueDynamic(this, &UWonderUpgradeWidget::OnUpgradeButtonClicked);

	UQ6Button* CompleteButton = CastChecked<UQ6Button>(GetWidgetFromName("Complete"));
	CompleteButton->OnClicked.AddUniqueDynamic(this, &UWonderUpgradeWidget::OnCompleteButtonClicked);

	// Animations

	UpgradingAnim = GetWidgetAnimationFromName(this, "AnimUpgradingLoop");
	UpgradeCompleteAnim = GetWidgetAnimationFromName(this, "AnimUpgradeCompleteLoop");
	UpgradeStartAnim = GetWidgetAnimationFromName(this, "AnimUpgradeDefault");
}

void UWonderUpgradeWidget::NativeDestruct()
{
	Super::NativeDestruct();

	GetWorld()->GetTimerManager().ClearTimer(UpgradeTimerHandle);
}

void UWonderUpgradeWidget::InitUpgrade(const FWonderInfo& WonderInfo)
{
	Category = WonderInfo.Category;

	if (WonderInfo.Level >= WonderMaxLevel)
	{
		return;
	}

	// Set state

	FText LevelFormat = Q6Util::GetLocalizedText("Common", "Level");

	CurLevelText->SetText(FText::Format(LevelFormat, FText::AsNumber(WonderInfo.Level)));
	TargetLevelText->SetText(FText::Format(LevelFormat, FText::AsNumber(WonderInfo.Level + 1)));

	const FCMSWonderRow* WonderRow = GetCMS()->GetWonderRow(Category, WonderInfo.Level + 1);
	check(WonderRow);

	RequiredLevel = WonderRow->UserLevel;
	bool bEnoughUserLevel = GetHUDStore().GetWorldUser().GetLevel() >= WonderRow->UserLevel;
	GetUIResource().SetButtonStyle(UpgradeButton, bEnoughUserLevel);

	SetUpgradeState(WonderInfo.WonderState);

	// Set time left

	GetWorld()->GetTimerManager().ClearTimer(UpgradeTimerHandle);

	LeadTimeSec = WonderInfo.UpgradeLeadTimeSec;
	RemainTimeSec = WonderInfo.UpgradeRemainTimeSec;
	if (RemainTimeSec <= 0)
	{
		return;
	}

	GetWorld()->GetTimerManager().SetTimer(UpgradeTimerHandle, this, &UWonderUpgradeWidget::RefreshTimeLeft, 1.0f, true, 1.0f);
	RefreshTimeLeft();
}

void UWonderUpgradeWidget::SetNewMarkVisibility(ESlateVisibility NewMarkVisibility)
{
	NewMarkImage->SetVisibility(NewMarkVisibility);
}

void UWonderUpgradeWidget::SetUpgradeState(EWonderUpgradeState UpgradeState)
{
	// Reset timer

	GetWorld()->GetTimerManager().ClearTimer(UpgradeTimerHandle);

	// Set state

	StopAllAnimations();

	switch (UpgradeState)
	{
		case EWonderUpgradeState::Normal:
		case EWonderUpgradeState::Locked:
			PlayAnimation(UpgradeStartAnim);
			break;

		case EWonderUpgradeState::Upgrading:
			PlayAnimation(UpgradingAnim, 0.0f, 0);
			break;

		case EWonderUpgradeState::Upgraded:
			PlayAnimation(UpgradeCompleteAnim, 0.0f, 0);
			break;
	}
}

void UWonderUpgradeWidget::RefreshTimeLeft()
{
	--RemainTimeSec;

	if (RemainTimeSec <= 0)
	{
		SetUpgradeState(EWonderUpgradeState::Upgraded);
		return;
	}

	TimeLeftText->SetText(Q6Util::GetShortTimeText(RemainTimeSec));

	float RemainTimeRatio = (LeadTimeSec == 0) ? 0.0f : (float)(LeadTimeSec - RemainTimeSec) / LeadTimeSec;
	TimeLeftBar->SetPercent(RemainTimeRatio);
}

void UWonderUpgradeWidget::OnUpgradeButtonClicked()
{
	if (RequiredLevel > GetHUDStore().GetWorldUser().GetLevel())
	{
		GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short,
			FText::Format(Q6Util::GetLocalizedText("Lobby", "WonderUpgradeNotEnoughLevel"), FText::AsNumber(RequiredLevel)));
		return;
	}

	FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);

	UWonderUpgradeConfirmPopupWidget* UpgradeConfirmPopup = CastChecked<UWonderUpgradeConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(WonderUpgradeConfirmPopupClass));
	UpgradeConfirmPopup->SetWonder(Category, WonderInfo.Level);
	UpgradeConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UWonderUpgradeWidget::OnWonderUpgrade);
}

void UWonderUpgradeWidget::OnCompleteButtonClicked()
{
	GetHUDStore().ReqWonderUpgradeComplete(Category);
}

void UWonderUpgradeWidget::OnWonderUpgrade(EConfirmPopupFlag Flag)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetHUDStore().ReqWonderUpgrade(Category);
}

//////////////////////////////////////////////////////////////////////////
// Wonder Produce Widget
//////////////////////////////////////////////////////////////////////////
void UWonderProduceWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ProducePointImage = CastChecked<UImage>(GetWidgetFromName("ProducePoint"));
	MaxPointImage = CastChecked<UImage>(GetWidgetFromName("MaxPoint"));
	BeforeProduceText = CastChecked<UQ6TextBlock>(GetWidgetFromName("BeforeProduce"));
	AfterProduceText = CastChecked<UQ6TextBlock>(GetWidgetFromName("AfterProduce"));
	BeforeMaxProduceText = CastChecked<UQ6TextBlock>(GetWidgetFromName("BeforeMaxProduce"));
	AfterMaxProduceText = CastChecked<UQ6TextBlock>(GetWidgetFromName("AfterMaxProduce"));
}

void UWonderProduceWidget::SetWonder(EWonderCategory Category, int32 BeforeLevel, int32 AfterLevel)
{
	const UCMS* CMS = GetCMS();
	const FCMSWonderProductRow* BeforeProductRow = CMS->GetWonderProductRow(Category, BeforeLevel);
	const FCMSWonderProductRow* AfterProductRow = CMS->GetWonderProductRow(Category, AfterLevel);
	if (BeforeProductRow && AfterProductRow)
	{
		SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const FPointIcon& PointIcon = GetUIResource().GetPointIcon(BeforeProductRow->CurrencyType);
		ProducePointImage->SetBrush(PointIcon.SmallBrush);
		MaxPointImage->SetBrush(PointIcon.SmallBrush);

		BeforeProduceText->SetText(FText::AsNumber(BeforeProductRow->ProduceAmount));
		AfterProduceText->SetText(FText::AsNumber(AfterProductRow->ProduceAmount));

		BeforeMaxProduceText->SetText(FText::AsNumber(BeforeProductRow->MaxStorageAmount));
		AfterMaxProduceText->SetText(FText::AsNumber(AfterProductRow->MaxStorageAmount));
	}
	else
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
}

//////////////////////////////////////////////////////////////////////////
// Wonder Income Point Widget
//////////////////////////////////////////////////////////////////////////
void UWonderIncomePointWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	PointText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Point"));
	
	PointAnim = GetWidgetAnimationFromName(this, "AnimPoint");
	PointHighlightLoopAnim = GetWidgetAnimationFromName(this, "AnimPointHighlightLoop");
}

void UWonderIncomePointWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == PointAnim)
	{
		StopAnimation(PointHighlightLoopAnim);
	}
}

void UWonderIncomePointWidget::PlayIncomeAnimation(ECurrencyType CurrencyType, int32 Amount)
{
	const FPointIcon& PointIcon = GetUIResource().GetPointIcon(GetPointType(CurrencyType));
	IconImage->SetBrush(PointIcon.SmallBrush);

	PointText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "AddCurrency"), FText::AsNumber(Amount)));

	PlayAnimation(PointAnim);
	PlayAnimation(PointHighlightLoopAnim, 0.f, 0);
}

//////////////////////////////////////////////////////////////////////////
// Wonder Harvest Widget
//////////////////////////////////////////////////////////////////////////
void UWonderHarvestWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));

	HarvestButton = CastChecked<UQ6Button>(GetWidgetFromName("Harvest"));
	HarvestButton->OnClickedDelegate.BindUObject(this, &UWonderHarvestWidget::OnHarvestButtonClicked);

	StoredAmountBar = CastChecked<UProgressBar>(GetWidgetFromName("BarStoredAmount"));
	ProduceAmountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("ProduceAmount"));
	StoredAmountText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("StoredAmount"));
	RemainTimeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RemainTime"));
	MaxText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Max"));
	IncomePointWidget = CastChecked<UWonderIncomePointWidget>(GetWidgetFromName("Income"));

	NoMaxAnim = GetWidgetAnimationFromName(this, "AnimNoMax");
	MaxLoopAnim = GetWidgetAnimationFromName(this, "AnimMaxLoop");
}

void UWonderHarvestWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	RemainTimeSec = FMath::Max(RemainTimeSec - (int32)InDeltaTime, 0);
	RemainTimeText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "RemainTimeToMax"), Q6Util::GetShortTimeText(RemainTimeSec)));

	if (RefreshTriggerTimeSec >= 0 && RemainTimeSec <= RefreshTriggerTimeSec)
	{
		RefreshIncome();
	}
}

void UWonderHarvestWidget::SetIncome(const FCMSWonderProductRow& ProductRow, const FWonderInfo& WonderInfo)
{
	Category = ProductRow.Category;
	RemainTimeSec = WonderInfo.RemainMaxIncomeTimeSec;

	const FPointIcon& PointIcon = GetUIResource().GetPointIcon(ProductRow.CurrencyType);
	IconImage->SetBrush(PointIcon.SmallBrush);

	FString ProduceAmountStr = Q6Util::GetLocalizedText("Lobby", "ProduceAmountPerHour").ToString();
	ProduceAmountStr.Append(FString::Printf(TEXT(" %d"), ProductRow.ProduceAmount));
	ProduceAmountText->SetText(FText::FromString(ProduceAmountStr));

	if (WonderInfo.IncomeAmount >= ProductRow.MaxStorageAmount)
	{
		RefreshTriggerTimeSec = -1;	// Not used trigger time

		MaxText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		RemainTimeText->SetVisibility(ESlateVisibility::Collapsed);

		StoredAmountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "HighlightNumCount"),
			FText::AsNumber(WonderInfo.IncomeAmount), FText::AsNumber(ProductRow.MaxStorageAmount)));
		HarvestButton->SetStyle(MaxButtonStyle);
		HarvestButton->SetIsEnabled(true);

		StoredAmountBar->SetPercent(1.0f);
		StoredAmountBar->SetFillColorAndOpacity(MaxBarColor);

		StopAnimation(NoMaxAnim);
		PlayAnimation(MaxLoopAnim, 0.f, 0);
	}
	else
	{
		RefreshTriggerTimeSec = RemainTimeSec - RemainTimeSec % (SystemConst::Q6_WONDER_PRODUCE_CURRENCY_TIME * 3600);

		MaxText->SetVisibility(ESlateVisibility::Collapsed);
		RemainTimeText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		RemainTimeText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "RemainTimeToMax"), Q6Util::GetShortTimeText(WonderInfo.RemainMaxIncomeTimeSec)));
		StoredAmountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "NumCount"),
			FText::AsNumber(WonderInfo.IncomeAmount), FText::AsNumber(ProductRow.MaxStorageAmount)));

		HarvestButton->SetStyle(StoredButtonStyle);

		StoredAmountBar->SetFillColorAndOpacity(StoredBarColor);

		if (WonderInfo.IncomeAmount > 0)
		{
			HarvestButton->SetIsEnabled(true);
			StoredAmountBar->SetPercent((float)WonderInfo.IncomeAmount / ProductRow.MaxStorageAmount);
		}
		else
		{
			// No have income

			HarvestButton->SetIsEnabled(false);
			StoredAmountBar->SetPercent(0.0f);
		}

		StopAnimation(MaxLoopAnim);
		PlayAnimation(NoMaxAnim);
	}
}

void UWonderHarvestWidget::RefreshIncome()
{
	FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
	const FCMSWonderProductRow* ProductRow = GetCMS()->GetWonderProductRow(WonderInfo.Category, WonderInfo.Level);
	if (ProductRow)
	{
		SetIncome(*ProductRow, WonderInfo);
	}
}

void UWonderHarvestWidget::PlayIncomeAnimation(ECurrencyType CurrencyType, int32 IncomeAmount)
{
	IncomePointWidget->PlayIncomeAnimation(CurrencyType, IncomeAmount);
}

void UWonderHarvestWidget::OnHarvestButtonClicked()
{
	GetHUDStore().ReqWonderHarvest(Category);
}

//////////////////////////////////////////////////////////////////////////
// Wonder Top Bar Widget
//////////////////////////////////////////////////////////////////////////
void UWonderTopBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	LevelEffect1Box = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxLevelEffect1"));
	LevelEffect2Box = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxLevelEffect2"));
	LevelEffect1Text = CastChecked<UQ6TextBlock>(GetWidgetFromName("LevelEffect1"));
	LevelEffect2Text = CastChecked<UQ6TextBlock>(GetWidgetFromName("LevelEffect2"));
	MaxLevelText = CastChecked<UQ6TextBlock>(GetWidgetFromName("MaxLevel"));
	HarvestWidget = CastChecked<UWonderHarvestWidget>(GetWidgetFromName("Harvest"));
	UpgradeWidget = CastChecked<UWonderUpgradeWidget>(GetWidgetFromName("Upgrade"));
}

void UWonderTopBarWidget::SetWonder(EWonderCategory InCategory)
{
	Category = InCategory;

	const FWonderUIState& WonderUIState = GetHUDStore().GetUIStateManager().GetWonderUIState();
	if (WonderUIState.Category == EWonderCategory::Main)
	{
		SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
	if (WonderInfo.Level < WonderMaxLevel)
	{
		MaxLevelText->SetVisibility(ESlateVisibility::Collapsed);
		UpgradeWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		UpgradeWidget->InitUpgrade(WonderInfo);
	}
	else
	{
		MaxLevelText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		UpgradeWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	// No effects less than level 1
	LevelEffect1Box->SetVisibility(ESlateVisibility::Collapsed);
	LevelEffect2Box->SetVisibility(ESlateVisibility::Collapsed);

	HarvestWidget->SetVisibility(ESlateVisibility::Collapsed);

	SetEffectDesc();

	const FSlateBrush& WonderBrush = GetUIResource().GetWonderBG(Category);
	BGImage->SetBrush(WonderBrush);

	const FCMSWonderProductRow* ProductRow = GetCMS()->GetWonderProductRow(Category, WonderInfo.Level);
	if (ProductRow)
	{
		HarvestWidget->SetIncome(*ProductRow, WonderInfo);
	}

	ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetWonderUpgradeVisibility(WonderInfo);
	UpgradeWidget->SetNewMarkVisibility(NewMarkVisibility);
}

void UWonderTopBarWidget::RefreshWonder()
{
	SetWonder(Category);
}

void UWonderTopBarWidget::SetEffectDesc()
{
	switch (Category)
	{
		case EWonderCategory::Pyramid:			SetPyramidEffectDesc();			break;
		case EWonderCategory::Powerplant:		SetPowerplantEffectDesc();		break;
		case EWonderCategory::Vacation:			SetVacationEffectDesc();		break;
		case EWonderCategory::PetPark:			SetPetParkEffectDesc();			break;
		case EWonderCategory::Temple:			SetTempleEffectDesc();			break;
		case EWonderCategory::AlchemyLab:		SetAlchemyLabEffectDesc();		break;
		case EWonderCategory::MigriumRefinery:		SetMigriumRefineryEffectDesc();		break;
	}
}

void UWonderTopBarWidget::SetPyramidEffectDesc()
{
	FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
	int32 ReduceCount = SystemConstHelper::GetPortalBoostMaterialReduceCount(WonderInfo.Level);
	if (ReduceCount > 0)
	{
		LevelEffect1Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		LevelEffect1Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PortalBoostMaterialReduceCount"), FText::AsNumber(ReduceCount)));
	}
}

void UWonderTopBarWidget::SetPowerplantEffectDesc()
{
	const FPowerPlantInfo& PowerPlant = GetHUDStore().GetPowerPlantManager().GetPowerPlant();
	const FCMSPowerPlantRow& CurLevelRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(PowerPlant.Level));
	LevelEffect1Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelEffect1Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "WaterStorage"), FText::AsNumber(CurLevelRow.Storage)));

	const FCMSPowerPlantRow& BaseLevelRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(1));
	int32 CostSale = BaseLevelRow.Cost - CurLevelRow.Cost;
	if (CostSale > 0)
	{
		LevelEffect2Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		LevelEffect2Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "StoreCostReduceAmount"), FText::AsNumber(CostSale)));
	}
}

void UWonderTopBarWidget::SetVacationEffectDesc()
{
	int32 Level = GetHUDStore().GetVacationManager().GetLevel();
	int32 LevelBondBonus = SystemConstHelper::GetVacationLevelBonusBond(Level);
	if (LevelBondBonus > 0)
	{
		LevelEffect1Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		LevelEffect1Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "LevelBonusBond"), FText::AsNumber(LevelBondBonus)));
	}
}

void UWonderTopBarWidget::SetPetParkEffectDesc()
{
	int32 MaxPetSkillLevel = GetHUDStore().GetPetManager().GetPetPark().Level;

	HarvestWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	LevelEffect1Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelEffect1Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PetSkillMaxLevel"), FText::AsNumber(MaxPetSkillLevel)));
}

void UWonderTopBarWidget::SetTempleEffectDesc()
{
	int32 MaxArtifactSkillLevel = GetHUDStore().GetTempleManager().GetTempleInfo().Level;

	HarvestWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	LevelEffect1Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelEffect1Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "ArtifactMaxLevel"), FText::AsNumber(MaxArtifactSkillLevel)));
}

void UWonderTopBarWidget::SetAlchemyLabEffectDesc()
{
	int32 AlchemyLabLevel = GetHUDStore().GetAlchemylabManager().GetAlchemylabInfo().Level;

	const FAlchemyLabAssetRow* AlchemyLabAssetRow = GetGameResource().GetAlchemyLabAssetRowByLevel(
		AlchemyLabLevel);
	if (AlchemyLabAssetRow)
	{
		if (!AlchemyLabAssetRow->EffectDesc1.IsEmpty())
		{
			LevelEffect1Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			LevelEffect1Text->SetText(FText::Format(AlchemyLabAssetRow->EffectDesc1
				, FText::AsNumber(AlchemyLabLevel)));
		}

		if (!AlchemyLabAssetRow->EffectDesc2.IsEmpty())
		{
			LevelEffect2Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			LevelEffect2Text->SetText(AlchemyLabAssetRow->EffectDesc2);
		}
	}
}

void UWonderTopBarWidget::SetMigriumRefineryEffectDesc()
{
	int32 SmelterLevel = GetHUDStore().GetSmelterManager().GetSmelterInfo().Level;

	const FCMSSmelterRow* SmelterRow = GetCMS()->GetSmelterRowByLevel(SmelterLevel);
	if (SmelterRow)
	{
		LevelEffect1Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		LevelEffect1Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "MigriumRefineryProductionTime")
			, FText::AsNumber(SmelterRow->ProductTime / 60)
			, FText::AsNumber(SmelterRow->ProductTime % 60)
		));

		LevelEffect2Box->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		LevelEffect2Text->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "MigriumRefineryStorage")
			, FText::AsNumber(SmelterRow->ProductStock)));
	}
}

void UWonderTopBarWidget::PlayIncomeAnimation(ECurrencyType CurrencyType, int32 IncomeAmount)
{
	HarvestWidget->PlayIncomeAnimation(CurrencyType, IncomeAmount);
}

//////////////////////////////////////////////////////////////////////////
// Wonder Icon Widget
//////////////////////////////////////////////////////////////////////////
void UWonderIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));

	UpgradeWidget = CastChecked<UWonderUpgradeWidget>(GetWidgetFromName("Upgrade"));
	HarvestIconImage = CastChecked<UImage>(GetWidgetFromName("HarvestIcon"));
	IncomeWidget = CastChecked<UWonderIncomePointWidget>(GetWidgetFromName("Income"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	// Animations

	DefaultAnim = GetWidgetAnimationFromName(this, "AnimDefault");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimLock");
	UpgradeCompleteAnim = GetWidgetAnimationFromName(this, "AnimUpgradeLoop");
	UpgradingAnim = GetWidgetAnimationFromName(this, "AnimUpgrading");
	PointIncomeMaxLoopAnim = GetWidgetAnimationFromName(this, "AnimPointIncomeMaxLoop");
	PointIncomeAnim = GetWidgetAnimationFromName(this, "AnimPointIncome");

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UWonderIconWidget::OnIconClicked);

	HarvestButton = CastChecked<UQ6Button>(GetWidgetFromName("Harvest"));
	HarvestButton->OnClickedDelegate.BindUObject(this, &UWonderIconWidget::OnHarvestButtonClicked);

	GetWorld()->GetTimerManager().ClearTimer(WonderIncomeTimeHandle);
}

void UWonderIconWidget::NativeDestruct()
{
	Super::NativeDestruct();

	GetWorld()->GetTimerManager().ClearTimer(WonderIncomeTimeHandle);
}

void UWonderIconWidget::SetWonder(const FWonderInfo& WonderInfo)
{
	StopAllAnimations();

	Category = WonderInfo.Category;
	GetWorld()->GetTimerManager().ClearTimer(WonderIncomeTimeHandle);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(WonderInfo.Level)));

	if (WonderIcons.IsValidIndex((int32)WonderInfo.Category))
	{
		IconImage->SetBrush(WonderIcons[(int32)WonderInfo.Category].Brush);
		NameText->SetText(WonderIcons[(int32)WonderInfo.Category].Name);
	}

	UpgradeWidget->InitUpgrade(WonderInfo);

	EIncomeState IncomeState = EIncomeState::Invalid;
	if (const FCMSWonderProductRow* ProductRow = GetCMS()->GetWonderProductRow(WonderInfo.Category, WonderInfo.Level))
	{
		const FPointIcon& PointIcon = GetUIResource().GetPointIcon(GetPointType(ProductRow->CurrencyType));
		HarvestIconImage->SetBrush(PointIcon.SmallBrush);

		bool bStored = WonderInfo.IncomeAmount > 0;
		if (bStored)
		{
			if (WonderInfo.IncomeAmount >= ProductRow->MaxStorageAmount)
			{
				IncomeState = EIncomeState::MaxStored;
			}
			else
			{
				IncomeState = EIncomeState::Stored;

				// Set max income refresh timer
				GetWorld()->GetTimerManager().SetTimer(WonderIncomeTimeHandle, this, &UWonderIconWidget::RefreshWonder, (float)WonderInfo.RemainMaxIncomeTimeSec, false);
			}
		}
		else
		{
			// Set first income timer

			IncomeState = EIncomeState::NotStored;

			int32 ProduceCount = (int32)ProductRow->MaxStorageAmount / ProductRow->ProduceAmount;
			int32 MaxProducedHour = ProduceCount * SystemConst::Q6_WONDER_PRODUCE_CURRENCY_TIME;
			int32 FirstProducedRemainTime = (MaxProducedHour - SystemConst::Q6_WONDER_PRODUCE_CURRENCY_TIME) * 3600;

			// Set first income refresh timer
			GetWorld()->GetTimerManager().SetTimer(WonderIncomeTimeHandle, this, &UWonderIconWidget::RefreshWonder, FirstProducedRemainTime, false);
		}
	}

	SetWonderState(WonderInfo.WonderState);
	SetIncomeState(IncomeState);
	SetNewMark(WonderInfo);
}

void UWonderIconWidget::SetWonderState(EWonderUpgradeState WonderState)
{
	switch (WonderState)
	{
		case EWonderUpgradeState::Normal: PlayAnimation(DefaultAnim); break;
		case EWonderUpgradeState::Locked: PlayAnimation(LockedAnim); break;
		case EWonderUpgradeState::Upgrading: PlayAnimation(UpgradingAnim); break;
		case EWonderUpgradeState::Upgraded: PlayAnimation(UpgradeCompleteAnim, 0.0f, 0); break;
		default: ensure(0); PlayAnimation(DefaultAnim); break;
	}
}

void UWonderIconWidget::SetIncomeState(EIncomeState IncomeState)
{
	IncomeWidget->SetVisibility(ESlateVisibility::Collapsed);

	if (IncomeState == EIncomeState::Stored)
	{
		HarvestButton->SetVisibility(ESlateVisibility::Visible);

		PlayAnimation(PointIncomeAnim);
	}
	else if (IncomeState == EIncomeState::MaxStored)
	{
		HarvestButton->SetVisibility(ESlateVisibility::Visible);

		PlayAnimation(PointIncomeMaxLoopAnim, 0.f, 0);
	}
	else
	{
		HarvestButton->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UWonderIconWidget::SetNewMark(const FWonderInfo& WonderInfo)
{

	ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetWonderMainVisibility(WonderInfo);
	NewMarkImage->SetVisibility(NewMarkVisibility);
}

void UWonderIconWidget::RefreshWonder()
{
	FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
	SetWonder(WonderInfo);
}

void UWonderIconWidget::PlayIncomeAnimation(ECurrencyType CurrencyType, int32 IncomeAmount)
{
	RefreshWonder();

	IncomeWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	IncomeWidget->PlayIncomeAnimation(CurrencyType, IncomeAmount);
}

void UWonderIconWidget::OnIconClicked()
{
	OnIconSelectedDelegate.ExecuteIfBound();
}

void UWonderIconWidget::OnHarvestButtonClicked()
{
	GetHUDStore().ReqWonderHarvest(Category);
}


//////////////////////////////////////////////////////////////////////////
// Wonder Widget
//////////////////////////////////////////////////////////////////////////
UWonderWidget::UWonderWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UWonderWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TopBarWidget = CastChecked<UWonderTopBarWidget>(GetWidgetFromName("TopBar"));
	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("WonderMenu"));
	PyramidWidget = CastChecked<UPyramidWidget>(GetWidgetFromName("PyramidMenu"));
	PowerPlantWidget = CastChecked<UPowerPlantWidget>(GetWidgetFromName("PowerPlantMenu"));
	PetParkWidget = CastChecked<UPetParkWidget>(GetWidgetFromName("PetParkMenu"));
	TempleWidget = CastChecked<UTempleWidget>(GetWidgetFromName("TempleMenu"));
	MigriumRefineryWidget = CastChecked<UMigriumRefineryWidget>(GetWidgetFromName("MigriumRefineryMenu"));
	AlchemyLabWidget = CastChecked<UAlchemyLabWidget>(GetWidgetFromName("AlchemyLabMenu"));

	UWonderIconWidget* WonderIcon;
	WonderIcons.Reset();
	for (int32 n = 1; n < EWonderCategoryMax; ++n)
	{
		EWonderCategory Category = (EWonderCategory)n;

		WonderIcon = Cast<UWonderIconWidget>(GetWidgetFromName(*ENUM_TO_STRING(EWonderCategory, Category)));
		if (WonderIcon)
		{
			WonderIcon->OnIconSelectedDelegate.BindUObject(this, &UWonderWidget::OnWonderIconSelected, Category);
			WonderIcons.Add(WonderIcon);
		}
	}
}

void UWonderWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Pyramid);
	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::BagItem);
	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::Character);
	SubscribeToStore(EHSType::Relic);
	SubscribeToStore(EHSType::Sculpture);
	SubscribeToStore(EHSType::PowerPlant);
	SubscribeToStore(EHSType::Vacation);
	SubscribeToStore(EHSType::Pet);
	SubscribeToStore(EHSType::Temple);
	SubscribeToStore(EHSType::Alchemylab);
	SubscribeToStore(EHSType::Smelter);
	SubscribeToStore(EHSType::NewMark);
}

void UWonderWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FWonderUIState* UIState = GetUIState()->CastToWonderUIState();
	check(UIState);

	SetWonderMenu(UIState->Category);
}

void UWonderWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByWonder);

	if ((InAction->GetActionType() == EHSActionType::ContentsResetTime)
		|| (InAction->GetActionType() == EHSActionType::PyramidUpgradeCompleteResp)
		|| (InAction->GetActionType() == EHSActionType::DevPyramidUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::PowerPlantUpgradeCompleteResp)
		|| (InAction->GetActionType() == EHSActionType::VacationUpgradeCompleteResp)
		|| (InAction->GetActionType() == EHSActionType::PetParkUpgradeCompleteResp)
		|| (InAction->GetActionType() == EHSActionType::TempleUpgradeCompleteResp)
		|| (InAction->GetActionType() == EHSActionType::AlchemylabUpgradeCompleteResp)
		|| (InAction->GetActionType() == EHSActionType::SmelterUpgradeCompleteResp)
		)
	{
		GetCheckedLobbyHUD(this)->RefreshNaviBar();

		int32 IncomeAmount = 0;
		if (InAction->GetActionType() == EHSActionType::PetParkUpgradeCompleteResp)
		{
			const auto Action = ACTION_PARSE_PetParkUpgradeCompleteResp(InAction);
			const auto Resp = Action->GetVal();

			IncomeAmount = Resp.DeltaIncomeGold;
		}
		else if (InAction->GetActionType() == EHSActionType::TempleUpgradeCompleteResp)
		{
			const auto Action = ACTION_PARSE_TempleUpgradeCompleteResp(InAction);
			const auto Resp = Action->GetVal();

			IncomeAmount = Resp.DeltaIncomePoint;
		}

		const FWonderUIState* UIState = GetUIState()->CastToWonderUIState();
		check(UIState);

		EWonderCategory Category = (UIState->Category == EWonderCategory::Main) ? (EWonderCategory)UIState->SelectedSlot : UIState->Category;
		const FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
		UWonderUpgradeResultPopupWidget* ResultPopup = CastChecked<UWonderUpgradeResultPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(WonderUpgradeResultPopupClass));
		ResultPopup->SetWonder(WonderInfo.Category, WonderInfo.Level);
		ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UWonderWidget::PlayIncomeAnimation, WonderInfo.Category, WonderInfo.Level, IncomeAmount);

		SetWonderMenuRefresh(Category);
		return;
	}

	if (InAction->GetActionType() == EHSActionType::TempleHarvestResp)
	{
		const auto Action = ACTION_PARSE_TempleHarvestResp(InAction);
		const auto Resp = Action->GetVal();

		const FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(EWonderCategory::Temple);
		SetWonderMenuRefresh(EWonderCategory::Temple);
		PlayIncomeAnimation(WonderInfo.Category, WonderInfo.Level, Resp.DeltaIncomePoint);
		return;
	}
	
	if (InAction->GetActionType() == EHSActionType::PetParkHarvestResp)
	{
		const auto Action = ACTION_PARSE_PetParkHarvestResp(InAction);
		const auto Resp = Action->GetVal();

		const FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(EWonderCategory::PetPark);
		SetWonderMenuRefresh(EWonderCategory::PetPark);
		PlayIncomeAnimation(WonderInfo.Category, WonderInfo.Level, Resp.DeltaIncomeGold);
		return;
	}

	if ((InAction->GetActionType() == EHSActionType::PyramidUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::DevPyramidOpenResp)
		|| (InAction->GetActionType() == EHSActionType::PowerPlantUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::DevPowerPlantOpenResp)
		|| (InAction->GetActionType() == EHSActionType::VacationUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::DevVacationOpenResp)
		|| (InAction->GetActionType() == EHSActionType::PetParkUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::DevPetParkOpenResp)
		|| (InAction->GetActionType() == EHSActionType::TempleUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::DevTempleOpenResp)
		|| (InAction->GetActionType() == EHSActionType::DevTempleProduceResp)
		|| (InAction->GetActionType() == EHSActionType::DevPetParkProduceResp)
		|| (InAction->GetActionType() == EHSActionType::DevAlchemylabOpenResp)
		|| (InAction->GetActionType() == EHSActionType::AlchemylabUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::DevSmelterOpenResp)
		|| (InAction->GetActionType() == EHSActionType::SmelterUpgradeResp)
		)
	{
		const FWonderUIState* UIState = GetUIState()->CastToWonderUIState();
		check(UIState);

		SetWonderMenuRefresh(UIState->Category);
		return;
	}

	if (InAction->GetActionType() == EHSActionType::WonderMenu)
	{
		GetCheckedLobbyHUD(this)->RefreshNaviBar();

		auto Action = ACTION_PARSE_WonderMenu(InAction);
		SetWonderMenu(Action->GetVal());
		return;
	}

	UWonderMenuWidget* WonderMenu = Cast<UWonderMenuWidget>(MenuSwitcher->GetActiveWidget());
	if (WonderMenu)
	{
		WonderMenu->OnMenuEvent(InAction);
	}
}

void UWonderWidget::SetWonderMenu(EWonderCategory Category)
{
	FString TutorialParams = FString::Printf(TEXT("OnWonder%sEnter"), *ENUM_TO_STRING(EWonderCategory, Category));
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialParams);
	ULevelUtil::SetCurrentCaptureActor(GetWorld(), Category == EWonderCategory::PetPark, "Capture.Pet");
	MenuSwitcher->SetActiveWidgetIndex((int32)Category);
	SetWonderIcon(Category);
	TopBarWidget->SetWonder(Category);
	if (UWonderMenuWidget* WonderMenu = Cast<UWonderMenuWidget>(MenuSwitcher->GetWidgetAtIndex((int32)Category)))
	{
		WonderMenu->SetWonder();
	}
}

void UWonderWidget::SetWonderMenuRefresh(EWonderCategory Category)
{
	TopBarWidget->SetWonder(Category);

	SetWonderIcon(Category);
	if (UWonderMenuWidget* WonderMenu = Cast<UWonderMenuWidget>(MenuSwitcher->GetWidgetAtIndex((int32)Category)))
	{
		WonderMenu->RefreshUI();
	}
}

void UWonderWidget::SetWonderIcon(EWonderCategory Category)
{
	if (Category == EWonderCategory::Main)
	{
		for (int32 n = 1; n < EWonderCategoryMax; ++n)
		{
			SetWonderIcon((EWonderCategory)n);
		}

		return;
	}

	FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
	UWonderIconWidget* WonderIcon = GetWonderIcon(Category);
	if (WonderIcon)
	{
		WonderIcon->SetWonder(WonderInfo);
	}
}

UWonderIconWidget* UWonderWidget::GetWonderIcon(EWonderCategory Category)
{
	if (WonderIcons.IsValidIndex((int32)Category - 1))
	{
		return WonderIcons[(int32)Category - 1];
	}

	return nullptr;
}

void UWonderWidget::OnWonderIconSelected(EWonderCategory Category)
{
	const FWonderInfo WonderInfo = GetHUDStore().GetWonderInfo(Category);
	if (!WonderInfo.bOpened)
	{
		GetCheckedLobbyHUD(this)->ShowNotOpenedYetNotification(Category);
		return;
	}

	ACTION_DISPATCH_WonderMenu(Category, WonderInfo.Level);
	return;
}

void UWonderWidget::PlayIncomeAnimation(EWonderCategory Category, int32 Level, int32 IncomeAmount)
{
	if (IncomeAmount <= 0)
	{
		return;
	}

	const FCMSWonderProductRow* ProductRow = GetCMS()->GetWonderProductRow(Category, Level);
	if (!ProductRow)
	{
		Q6JsonLogRoze(Error, "dget::OnIncomeReceived - Invalid wonder");
		return;
	}

	if (MenuSwitcher->GetActiveWidgetIndex() == (int32)EWonderCategory::Main)
	{
		UWonderIconWidget* WonderIcon = GetWonderIcon(Category);
		if (WonderIcon)
		{
			WonderIcon->PlayIncomeAnimation(ProductRow->CurrencyType, IncomeAmount);
		}
	}
	else
	{
		TopBarWidget->PlayIncomeAnimation(ProductRow->CurrencyType, IncomeAmount);
	}
}

void UWonderLevelEffectWidget::NativeConstruct()
{
	Super::NativeConstruct();

	LevelText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Level"));
	LevelEffect1Box = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxLevelEffect1"));
	LevelEffect2Box = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxLevelEffect2"));

	LevelEffec1Text = CastChecked<UQ6TextBlock>(GetWidgetFromName("LevelEffect1"));
	LevelEffec2Text = CastChecked<UQ6TextBlock>(GetWidgetFromName("LevelEffect2"));

	DefaultAnim = GetWidgetAnimationFromName(this, "AnimDefault");
	UpgradeAnim = GetWidgetAnimationFromName(this, "AnimUpgrade");
}

void UWonderLevelEffectWidget::SetLevelEffect(int32 Level, const FText& Effect1, const FText& Effect2, bool bUpgrade)
{
	LevelText->SetText(FText::AsNumber(Level));

	LevelEffect1Box->SetVisibility(Effect1.IsEmpty() ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);
	LevelEffect2Box->SetVisibility(Effect2.IsEmpty() ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);

	LevelEffec1Text->SetText(Effect1);
	LevelEffec2Text->SetText(Effect2);

	PlayAnimation(bUpgrade ? UpgradeAnim : DefaultAnim);
}

void UWonderUpgradeLevelEffectWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CurrentEffectWidget = CastChecked<UWonderLevelEffectWidget>(GetWidgetFromName("Current"));
	ResultEffectWidget = CastChecked<UWonderLevelEffectWidget>(GetWidgetFromName("Result"));
}

void UWonderUpgradeLevelEffectWidget::SetWonder(EWonderCategory Category, int32 CurrentLevel)
{
	switch (Category)
	{
		case EWonderCategory::Pyramid:		SetPyramid(CurrentLevel);		return;
		case EWonderCategory::Powerplant:	SetPowerPlant(CurrentLevel);		return;
		case EWonderCategory::Vacation:		SetVacation(CurrentLevel);		return;
		case EWonderCategory::PetPark:		SetPetPark(CurrentLevel);		return;
		case EWonderCategory::Temple:		SetTemple(CurrentLevel);		return;
		case EWonderCategory::AlchemyLab:	SetAlchemyLab(CurrentLevel);		return;
		case EWonderCategory::MigriumRefinery:	SetMigriumRefinery(CurrentLevel);	return;
	}

	Q6JsonLogRoze(Error, "UWonderUpgradeLevelEffectWidget::SetWonder - Invalid wonder category");
}

void UWonderUpgradeLevelEffectWidget::SetTemple(int32 CurrentLevel)
{
	FText FormatText = Q6Util::GetLocalizedText("Lobby", "ArtifactMaxLevel");

	CurrentEffectWidget->SetLevelEffect(CurrentLevel, FText::Format(FormatText, FText::AsNumber(CurrentLevel)), FText::GetEmpty(), false);
	ResultEffectWidget->SetLevelEffect(CurrentLevel + 1, FText::Format(FormatText, FText::AsNumber(CurrentLevel + 1)), FText::GetEmpty(), true);
}

void UWonderUpgradeLevelEffectWidget::SetAlchemyLab(int32 CurrentLevel)
{
	const FAlchemyLabAssetRow* AlchemyLabAssetRow = GetGameResource().GetAlchemyLabAssetRowByLevel(
		CurrentLevel);
	if (AlchemyLabAssetRow)
	{
		CurrentEffectWidget->SetLevelEffect(CurrentLevel
			, FText::Format(AlchemyLabAssetRow->EffectDesc1, FText::AsNumber(CurrentLevel))
			, AlchemyLabAssetRow->EffectDesc2
			, false);

		ResultEffectWidget->SetLevelEffect(CurrentLevel + 1
			, FText::Format(AlchemyLabAssetRow->EffectDesc1, FText::AsNumber(CurrentLevel + 1))
			, AlchemyLabAssetRow->EffectDesc2
			, true);
	}
}

void UWonderUpgradeLevelEffectWidget::SetMigriumRefinery(int32 CurrentLevel)
{
	const FCMSSmelterRow* CurrentSmelterRow = GetCMS()->GetSmelterRowByLevel(CurrentLevel);
	if (CurrentSmelterRow)
	{
		CurrentEffectWidget->SetLevelEffect(CurrentLevel
			, FText::Format(Q6Util::GetLocalizedText("Lobby", "MigriumRefineryProductionTime")
				, FText::AsNumber(CurrentSmelterRow->ProductTime / 60)
				, FText::AsNumber(CurrentSmelterRow->ProductTime % 60))
			, FText::Format(Q6Util::GetLocalizedText("Lobby", "MigriumRefineryStorage")
				, FText::AsNumber(CurrentSmelterRow->ProductStock))
			, false);
	}

	const FCMSSmelterRow* NextSmelterRow = GetCMS()->GetSmelterRowByLevel(CurrentLevel + 1);
	if (NextSmelterRow)
	{
		ResultEffectWidget->SetLevelEffect(CurrentLevel + 1
			, FText::Format(Q6Util::GetLocalizedText("Lobby", "MigriumRefineryProductionTime")
				, FText::AsNumber(NextSmelterRow->ProductTime / 60)
				, FText::AsNumber(NextSmelterRow->ProductTime % 60))
			, FText::Format(Q6Util::GetLocalizedText("Lobby", "MigriumRefineryStorage")
				, FText::AsNumber(NextSmelterRow->ProductStock))
			, true);
	}
}

void UWonderUpgradeLevelEffectWidget::SetPetPark(int32 CurrentLevel)
{
	FText FormatText = Q6Util::GetLocalizedText("Lobby", "PetSkillMaxLevel");

	CurrentEffectWidget->SetLevelEffect(CurrentLevel, FText::Format(FormatText, FText::AsNumber(CurrentLevel)), FText::GetEmpty(), false);
	ResultEffectWidget->SetLevelEffect(CurrentLevel + 1, FText::Format(FormatText, FText::AsNumber(CurrentLevel + 1)), FText::GetEmpty(), true);
}

void UWonderUpgradeLevelEffectWidget::SetPyramid(int32 CurrentLevel)
{
	FText FormatText = Q6Util::GetLocalizedText("Lobby", "PortalBoostMaterialReduceCount");

	int32 CurrentReduceCount = SystemConstHelper::GetPortalBoostMaterialReduceCount(CurrentLevel);
	int32 ResultReduceCont = SystemConstHelper::GetPortalBoostMaterialReduceCount(CurrentLevel + 1);

	CurrentEffectWidget->SetLevelEffect(CurrentLevel, FText::Format(FormatText, FText::AsNumber(CurrentReduceCount)), FText::GetEmpty(), false);
	ResultEffectWidget->SetLevelEffect(CurrentLevel + 1, FText::Format(FormatText, FText::AsNumber(ResultReduceCont)), FText::GetEmpty(), true);
}

void UWonderUpgradeLevelEffectWidget::SetPowerPlant(int32 CurrentLevel)
{
	FText StorageFormatText = Q6Util::GetLocalizedText("Lobby", "WaterStorage");
	FText CostSaleFormatText = Q6Util::GetLocalizedText("Lobby", "StoreCostReduceAmount");

	const FPowerPlantInfo& PowerPlant = GetHUDStore().GetPowerPlantManager().GetPowerPlant();
	const FCMSPowerPlantRow& BaseLevelRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(1));

	const FCMSPowerPlantRow& CurLevelRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(PowerPlant.Level));
	int32 CurCostSale = BaseLevelRow.Cost - CurLevelRow.Cost;
	CurrentEffectWidget->SetLevelEffect(CurrentLevel,
		FText::Format(StorageFormatText, FText::AsNumber(CurLevelRow.Storage)),
		FText::Format(CostSaleFormatText, FText::AsNumber(CurCostSale)), false);

	const FCMSPowerPlantRow& NextLevelRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(PowerPlant.Level + 1));
	int32 NextCostSale = BaseLevelRow.Cost - NextLevelRow.Cost;
	ResultEffectWidget->SetLevelEffect(CurrentLevel + 1,
		FText::Format(StorageFormatText, FText::AsNumber(NextLevelRow.Storage)),
		FText::Format(CostSaleFormatText, FText::AsNumber(NextCostSale)), true);
}

void UWonderUpgradeLevelEffectWidget::SetVacation(int32 CurrentLevel)
{
	FText LevelBonusFormatText = Q6Util::GetLocalizedText("Lobby", "LevelBonusBond");

	const UCMS* CMS = GetCMS();
	int32 LevelBonusBond = SystemConstHelper::GetVacationLevelBonusBond(CurrentLevel);
	int32 NextLevelBonusBond = SystemConstHelper::GetVacationLevelBonusBond(CurrentLevel + 1);

	CurrentEffectWidget->SetLevelEffect(CurrentLevel,
		FText::Format(LevelBonusFormatText, FText::AsNumber(LevelBonusBond)), FText::GetEmpty(), false);
	ResultEffectWidget->SetLevelEffect(CurrentLevel + 1,
		FText::Format(LevelBonusFormatText, FText::AsNumber(NextLevelBonusBond)), FText::GetEmpty(), true);
}
