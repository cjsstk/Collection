// Copyright (c) 2020 XLGames, Inc. All rights reserved.

#include "StoryWidgets.h"
#include "GameResource.h"

FText GetStoryCategoryText(EStoryMenuCategory InCategory)
{
	switch (InCategory)
	{
		case EStoryMenuCategory::DailyDungeon:
			return Q6Util::GetLocalizedText("Lobby", "StoryDailyDungeon");
		case EStoryMenuCategory::TrainingCenter:
			return Q6Util::GetLocalizedText("Lobby", "StoryTrainingCenter");
		case EStoryMenuCategory::Raid:
			return Q6Util::GetLocalizedText("Lobby", "StoryRaid");
		case EStoryMenuCategory::Event:
			return Q6Util::GetLocalizedText("Lobby", "StoryEvent");
		case EStoryMenuCategory::Movie:
			return Q6Util::GetLocalizedText("Lobby", "StoryMovie");
	}

	return FText::GetEmpty();
}

void UStoryEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetDefaultAnim = GetWidgetAnimationFromName(this, "AnimSetDefault");
	SetLockAnim = GetWidgetAnimationFromName(this, "AnimSetLock");

	StoryNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextStoryName"));
	StorySubNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextStorySubName"));

	UQ6Button* StartButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnStoryStart"));
	StartButton->OnClicked.AddUniqueDynamic(this, &UStoryEntryWidget::OnStartButtonClicked);
}

void UStoryEntryWidget::OnStartButtonClicked()
{

}

void UStoryEntryWidget::SetLock(bool bLock)
{
	if (bLock)
	{
		PlayAnimation(SetLockAnim);
	}
	else
	{
		PlayAnimation(SetDefaultAnim);
	}
}

void UStoryEntryWidget::SetTitle(const FText& Name, const FText& SubName)
{
	StoryNameText->SetText(Name);
	StorySubNameText->SetText(SubName);
}

//---------------------------------------------------------------------------------------------

void UStoryListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StoryBGImage = CastChecked<UImage>(GetWidgetFromName("StoryBG"));
	StoryTitleNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextStoryTitleName"));
	StoryListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("StoryList"));
}

void UStoryListWidget::SetStoryList(EStoryMenuCategory InCategory)
{
	StoryTitleNameText->SetText(GetStoryCategoryText(InCategory));
	StoryBGImage->SetBrush(GetUIResource().GetReplayStoryBG(InCategory));

	switch (InCategory)
	{
		case EStoryMenuCategory::DailyDungeon:
			SetDailyDungeonList();
			break;
		case EStoryMenuCategory::TrainingCenter:
			SetTrainingCenterList();
			break;
		case EStoryMenuCategory::Raid:
			SetRaidList();
			break;
		case EStoryMenuCategory::Event:
			SetEventList();
			break;
		case EStoryMenuCategory::Movie:
			SetMovieList();
			break;
	}
}

void UStoryListWidget::SetDailyDungeonList()
{

}

void UStoryListWidget::SetTrainingCenterList()
{

}

void UStoryListWidget::SetRaidList()
{

}

void UStoryListWidget::SetEventList()
{

}

void UStoryListWidget::SetMovieList()
{

}

//---------------------------------------------------------------------------------------------

void UStoryMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetUnlockAnim = GetWidgetAnimationFromName(this, "AnimSetUnlock");
	SetLockAnim = GetWidgetAnimationFromName(this, "AnimSetLock");

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	StoryTitleNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextStoryTitleName"));

	UQ6Button* MenuButton = CastChecked<UQ6Button>(GetWidgetFromName("Menu"));
	MenuButton->OnClicked.AddUniqueDynamic(this, &UStoryMenuWidget::OnMenuButtonClicked);
}

void UStoryMenuWidget::SetLock(bool bLock)
{
	if (bLock)
	{
		PlayAnimation(SetLockAnim);
	}
	else
	{
		PlayAnimation(SetUnlockAnim);
	}
}

void UStoryMenuWidget::SetCategory(EStoryMenuCategory InCategory)
{
	StoryTitleNameText->SetText(GetStoryCategoryText(InCategory));
	IconImage->SetBrush(GetUIResource().GetReplayStoryBanner(InCategory));
}

void UStoryMenuWidget::OnMenuButtonClicked()
{
	OnMenuClickedDelegate.ExecuteIfBound();
}

//---------------------------------------------------------------------------------------------

void UStoryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("WidgetSwitcher"));

	MenuWidgets.Reset();

	FName MenuName[] = { "DailyDungeon", "TrainingCenter", "Raid", "Event", "Movie" };

	for (int32 i = 0; i < (int32)EStoryMenuCategory::Max; i++)
	{
		UStoryMenuWidget* MenuWidget = CastChecked<UStoryMenuWidget>(GetWidgetFromName(MenuName[i]));
		MenuWidget->OnMenuClickedDelegate.BindUObject(this, &UStoryWidget::OnStoryMenuClicked, EStoryMenuCategory(i));
		MenuWidgets.AddUnique(MenuWidget);
	}

	StoryListWidget = CastChecked<UStoryListWidget>(GetWidgetFromName("StoryListWidgetBP"));
}

void UStoryWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
}

void UStoryWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FStoryUIState* UIState = GetUIState()->CastToStoryUIState();
	check(UIState);

	MenuSwitcher->SetActiveWidgetIndex((int32)UIState->MenuType);

	switch (UIState->MenuType)
	{
		case EStoryMenuType::Main:
			SetStoryMenu();
			break;
		case EStoryMenuType::StoryList:
			StoryListWidget->SetStoryList(UIState->Category);
			break;
	}
}

void UStoryWidget::SetStoryMenu()
{
	for (int32 i = 0; i < MenuWidgets.Num(); i++)
	{
		MenuWidgets[i]->SetCategory(EStoryMenuCategory(i));
	}
}

void UStoryWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	switch (Action->GetActionType())
	{
		case EHSActionType::StoryList:
			RefreshMenu();
			break;
	}
}

void UStoryWidget::OnStoryMenuClicked(EStoryMenuCategory Category)
{
	ACTION_DISPATCH_StoryList(Category);
}
