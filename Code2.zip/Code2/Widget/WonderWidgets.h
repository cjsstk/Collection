// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "LobbyHUDWidget.h"
#include "PopupWidgets.h"

#include "WonderWidgets.generated.h"

struct FWonderInfo;

class UPetParkWidget;
class UPowerPlantWidget;
class UPyramidWidget;
class UQ6Button;
class UQ6TextBlock;
class UQ6RichTextBlock;
class UTempleWidget;
class UVacationWidget;
class UAlchemyLabWidget;
class UMigriumRefineryWidget;

enum class EWonderUpgradeState : uint8;

USTRUCT(BlueprintType)
struct FWonderIcon
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush Brush;

	UPROPERTY(EditDefaultsOnly)
	FText Name;
};

UCLASS()
class Q6_API UWonderUpgradeWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void InitUpgrade(const FWonderInfo& WonderInfo);
	void SetNewMarkVisibility(ESlateVisibility NewMarkVisibility);

private:
	void SetUpgradeState(EWonderUpgradeState UpgradeState);
	void RefreshTimeLeft();

	UFUNCTION()
	void OnUpgradeButtonClicked();

	UFUNCTION()
	void OnCompleteButtonClicked();

	UFUNCTION()
	void OnWonderUpgrade(EConfirmPopupFlag Flag);

	// Widgets

	UPROPERTY()
	UQ6TextBlock* CurLevelText;

	UPROPERTY()
	UQ6TextBlock* TargetLevelText;

	UPROPERTY()
	UQ6TextBlock* TimeLeftText;

	UPROPERTY()
	UProgressBar* TimeLeftBar;

	UPROPERTY()
	UQ6Button* UpgradeButton;

	UPROPERTY()
	UImage* NewMarkImage;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradingAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradeCompleteAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradeStartAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UWonderUpgradeConfirmPopupWidget> WonderUpgradeConfirmPopupClass;

	FTimerHandle UpgradeTimerHandle;	//Roze-TODO: Refactoring
	EWonderCategory Category;
	int64 LeadTimeSec;
	int64 RemainTimeSec;

	int32 RequiredLevel;
};

UCLASS()
class Q6_API UWonderProduceWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetWonder(EWonderCategory Category, int32 BeforeLevel, int32 AfterLevel);

private:
	UPROPERTY()
	UImage* ProducePointImage;

	UPROPERTY()
	UImage* MaxPointImage;

	UPROPERTY()
	UQ6TextBlock* BeforeProduceText;

	UPROPERTY()
	UQ6TextBlock* AfterProduceText;

	UPROPERTY()
	UQ6TextBlock* BeforeMaxProduceText;

	UPROPERTY()
	UQ6TextBlock* AfterMaxProduceText;
};


UCLASS()
class Q6_API UWonderIncomePointWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void PlayIncomeAnimation(ECurrencyType CurrencyType, int32 Amount);

private:
	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UQ6TextBlock* PointText;

	UPROPERTY(Transient)
	UWidgetAnimation* PointAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* PointHighlightLoopAnim;
};

UCLASS()
class Q6_API UWonderHarvestWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	void SetIncome(const FCMSWonderProductRow& ProductRow, const FWonderInfo& WonderInfo);
	void PlayIncomeAnimation(ECurrencyType CurrencyType, int32 IncomeAmount);

private:
	void RefreshIncome();

	UFUNCTION()
	void OnHarvestButtonClicked();

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UQ6Button* HarvestButton;

	UPROPERTY()
	UProgressBar* StoredAmountBar;

	UPROPERTY()
	UQ6TextBlock* ProduceAmountText;

	UPROPERTY()
	UQ6RichTextBlock* StoredAmountText;

	UPROPERTY()
	UQ6TextBlock* RemainTimeText;

	UPROPERTY()
	UQ6TextBlock* MaxText;

	UPROPERTY()
	UWonderIncomePointWidget* IncomePointWidget;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* NoMaxAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* MaxLoopAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	FButtonStyle StoredButtonStyle;

	UPROPERTY(EditDefaultsOnly)
	FButtonStyle MaxButtonStyle;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor StoredBarColor;

	UPROPERTY(EditDefaultsOnly)
	FLinearColor MaxBarColor;

	EWonderCategory Category;
	int32 RemainTimeSec;
	int32 RefreshTriggerTimeSec;
};

UCLASS()
class Q6_API UWonderTopBarWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetWonder(EWonderCategory InCategory);
	void PlayIncomeAnimation(ECurrencyType CurrencyType, int32 IncomeAmount);

private:
	void RefreshWonder();

	void SetEffectDesc();

	void SetPyramidEffectDesc();
	void SetPowerplantEffectDesc();
	void SetVacationEffectDesc();
	void SetPetParkEffectDesc();
	void SetTempleEffectDesc();
	void SetAlchemyLabEffectDesc();
	void SetMigriumRefineryEffectDesc();

	// Widgets

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UHorizontalBox* LevelEffect1Box;

	UPROPERTY()
	UHorizontalBox* LevelEffect2Box;

	UPROPERTY()
	UQ6TextBlock* LevelEffect1Text;

	UPROPERTY()
	UQ6TextBlock* LevelEffect2Text;

	UPROPERTY()
	UWonderUpgradeWidget* UpgradeWidget;

	UPROPERTY()
	UQ6TextBlock* MaxLevelText;

	UPROPERTY()
	UWonderHarvestWidget* HarvestWidget;

	// Fields

	EWonderCategory Category;
};


UCLASS()
class Q6_API UWonderIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetWonder(const FWonderInfo& WonderInfo);
	void PlayIncomeAnimation(ECurrencyType CurrencyType, int32 IncomeAmount);

	FSimpleDelegate OnIconSelectedDelegate;

private:
	void SetWonderState(EWonderUpgradeState WonderState);
	void SetIncomeState(EIncomeState IncomeState);
	void SetNewMark(const FWonderInfo& WonderInfo);

	void RefreshWonder();

	UFUNCTION()
	void OnIconClicked();
	void OnHarvestButtonClicked();

	// Widgets

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UWonderUpgradeWidget* UpgradeWidget;

	UPROPERTY()
	UImage* HarvestIconImage;

	UPROPERTY()
	UWonderIncomePointWidget* IncomeWidget;

	UPROPERTY()
	UQ6Button* HarvestButton;

	UPROPERTY()
	UImage* NewMarkImage;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* DefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LockedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradingAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradeCompleteAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* PointIncomeMaxLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* PointIncomeAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TArray<FWonderIcon> WonderIcons;

	FTimerHandle WonderIncomeTimeHandle;
	EWonderCategory Category;
};


/**
 * Wonder Lobby HUD Widget
 */
UCLASS()
class Q6_API UWonderWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UWonderWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

	virtual void OnHSEvent(TSharedPtr<FHSAction> InAction) override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Wonder; }

private:
	void SetWonderMenu(EWonderCategory Category);
	void SetWonderMenuRefresh(EWonderCategory Category);
	void SetWonderIcon(EWonderCategory Category);

	UWonderIconWidget* GetWonderIcon(EWonderCategory Category);

	void OnWonderIconSelected(EWonderCategory Category);
	void PlayIncomeAnimation(EWonderCategory Category, int32 Level, int32 IncomeAmount);

	// Widgets

	UPROPERTY()
	UWonderTopBarWidget* TopBarWidget;

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	UPyramidWidget* PyramidWidget;

	UPROPERTY()
	UPowerPlantWidget* PowerPlantWidget;

	UPROPERTY()
	UVacationWidget* VacationWidget;

	UPROPERTY()
	UPetParkWidget* PetParkWidget;

	UPROPERTY()
	UTempleWidget* TempleWidget;

	UPROPERTY()
	UAlchemyLabWidget* AlchemyLabWidget;

	UPROPERTY()
	UMigriumRefineryWidget* MigriumRefineryWidget;

	UPROPERTY()
	TArray<UWonderIconWidget*> WonderIcons;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UWonderUpgradeResultPopupWidget> WonderUpgradeResultPopupClass;
};

UCLASS()
class Q6_API UWonderLevelEffectWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetLevelEffect(int32 Level, const FText& Effect1, const FText& Effect2, bool bUpgrade = false);

private:
	UPROPERTY()
	UQ6TextBlock* LevelText;

	UPROPERTY()
	UHorizontalBox* LevelEffect1Box;

	UPROPERTY()
	UHorizontalBox* LevelEffect2Box;

	UPROPERTY()
	UQ6TextBlock* LevelEffec1Text;

	UPROPERTY()
	UQ6TextBlock* LevelEffec2Text;

	UPROPERTY(Transient)
	UWidgetAnimation* DefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradeAnim;
};

UCLASS()
class Q6_API UWonderUpgradeLevelEffectWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetWonder(EWonderCategory Category, int32 CurrentLevel);

private:
	void SetPyramid(int32 CurrentLevel);
	void SetPowerPlant(int32 CurrentLevel);
	void SetVacation(int32 CurrentLevel);
	void SetPetPark(int32 CurrentLevel);
	void SetTemple(int32 CurrentLevel);
	void SetAlchemyLab(int32 CurrentLevel);
	void SetMigriumRefinery(int32 CurrentLevel);

	UPROPERTY()
	UWonderLevelEffectWidget* CurrentEffectWidget;

	UPROPERTY()
	UWonderLevelEffectWidget* ResultEffectWidget;
};

UCLASS()
class Q6_API UWonderMenuWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) {}

	virtual void SetWonder() {}
	virtual void RefreshUI() {}
};
