// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"
#include "HUDStoreInterface.h"
#include "BaseWidget.generated.h"

struct FHSAction;

DECLARE_DELEGATE(FOnNoParamDelegate);

/**
* Base Widget
*/
UCLASS(BlueprintType, Blueprintable)
class Q6_API UBaseWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UBaseWidget(const FObjectInitializer& ObjectInitializer);

protected:
	UWidget* FindChildWidgetFromName(const FName& Name);

private:
	UWidget* FindChildWidgetFromNameInternal(UUserWidget* InUserWidget, const FName& Name);
};

///////////////////////////////////////////////////////////////////////////////////////////
// UHSReceiverBaseWidget

UCLASS()
class Q6_API UHSBaseWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UHSBaseWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeDestruct() override;

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action);

	bool IsReceivedHSEvent() const { return bReceivedHSEvent; }
	void SetReceivedHSEvent(bool bInReceiveHSEvent) { bReceivedHSEvent = bInReceiveHSEvent; }

protected:
	void SubscribeToStore(EHSType StoreType);
	void UnsubscribeToStore();

private:
	bool bSubscribed;
	bool bReceivedHSEvent;
};
