// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "ItemWidgets.h"

#include "AchievementsPageWidgets.h"
#include "BagItemManager.h"
#include "BaseHUD.h"
#include "BondManager.h"
#include "CharacterManager.h"
#include "CharacterDetailWidgets.h"
#include "CharacterWidgets.h"
#include "CharMissionManager.h"
#include "CMSTable.h"
#include "CodexManager.h"
#include "CombatDetailWidgets.h"
#include "CommonWidgets.h"
#include "ContentFeatureOpenManager.h"
#include "Formula.h"
#include "HAL/PlatformApplicationMisc.h"
#include "GameResource.h"
#include "LobbyHUD.h"
#include "LobbyPlayerController.h"
#include "MenuUnit.h"
#include "NewMarkManager.h"
#include "PetManager.h"
#include "PyramidManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Q6GameMode.h"
#include "Q6SoundPlayer.h"
#include "RelicManager.h"
#include "SculptureManager.h"
#include "SkillWidgets.h"
#include "SummonHUDWidget.h"
#include "SystemConstHelper.h"
#include "SwipeWidgets.h"
#include "VacationManager.h"
#include "WidgetUtil.h"
#include "DropBox.h"
#include "HUDStore/EventManager.h"
#include "SystemConst_gen.h"

#if !UE_BUILD_SHIPPING
TAutoConsoleVariable<int32> CVarQ6ShowInventoryItemId(
	TEXT("q6.showInventoryItemId"),
	0,
	TEXT("0: hide item id, 1: show item id"),
	ECVF_Default);

ESlateVisibility GetItemIdVisiblility()
{
	if (CVarQ6ShowInventoryItemId.GetValueOnGameThread())
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	if (GameInstance && GameInstance->IsDevMode())
	{
		return ESlateVisibility::SelfHitTestInvisible;
	}

	return ESlateVisibility::Collapsed;
}
#endif

UStarBarWidget::UStarBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UStarBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	StarIcons.Reset();
	for (int32 n = 1; n <= MAX_STAR; ++n)
	{
		WidgetName = FString::Printf(TEXT("Star%d"), n);
		StarIcons.Add(CastChecked<UImage>(GetWidgetFromName(*WidgetName)));
	}

	MoonIcon = CastChecked<UImage>(GetWidgetFromName("Moon"));
}

void UStarBarWidget::SetStars(int32 StarCount)
{
	for (int32 i = 0; i < StarIcons.Num(); ++i)
	{
		StarIcons[i]->SetVisibility((i < StarCount) ?
			ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void UStarBarWidget::SetMoon(int32 MoonCount)
{
	MoonIcon->SetBrush(GetUIResource().GetMoonIcon(MoonCount));
}

void UStarBarWidget::SetMoonStars(int32 MoonCount, int32 StarCount)
{
	SetStars(StarCount);
	SetMoon(MoonCount);
}

void UItemTooltipWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemIdText = CastChecked<UQ6TextBlock>(GetWidgetFromName("ItemId"));
	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	CategoryText = CastChecked<UTextBlock>(GetWidgetFromName("Category"));
	OwnedText = CastChecked<UTextBlock>(GetWidgetFromName("Owned"));
	AmountText = CastChecked<UTextBlock>(GetWidgetFromName("Amount"));
	ItemInfoText = CastChecked<UTextBlock>(GetWidgetFromName("ItemInfo"));
	LootInfoText = CastChecked<UTextBlock>(GetWidgetFromName("LootInfo"));

#if !UE_BUILD_SHIPPING
	ItemIdText->SetVisibility(GetItemIdVisiblility());
#else
	ItemIdText->SetVisibility(ESlateVisibility::Collapsed);
#endif
}

static FText GetBagItemCategoryText(EBagItemCategory ItemCategory)
{
	FString ItemCategoryTextKey = FString::Printf(TEXT("ItemCategory%s"), *ENUM_TO_STRING(EBagItemCategory, ItemCategory));
	return Q6Util::GetLocalizedText("Common", ItemCategoryTextKey);
}

static FText GetPointCategoryText(EPointType PointType)
{
	switch (PointType)
	{
		case EPointType::Lumicube:
		case EPointType::CharacterDisk:
		case EPointType::SculptureDisk:
		case EPointType::RelicDisk:
			return Q6Util::GetLocalizedText("Common", "PointTypeExchange");
		case EPointType::SmallBattery:
		case EPointType::MediumBattery:
		case EPointType::LargeBattery:
			return Q6Util::GetLocalizedText("Common", "PointTypeBattery");
		case EPointType::SummonTicket:
			return Q6Util::GetLocalizedText("Common", "PointTypeSummon");
	}

	return Q6Util::GetLocalizedText("Common", "PointTypeCurrency");
}

void UItemTooltipWidget::SetItem(FBagItemType ItemType)
{
#if !UE_BUILD_SHIPPING
	if (ItemType != BagItemTypeInvalid)
	{
		FText IdStr = FText::FromString(FString::Printf(TEXT("Id: %d"), ItemType));
		ItemIdText->SetText(IdStr);
	}
	else
	{
		ItemIdText->SetText(FText::GetEmpty());
	}
#endif

	UGameResource& GameResource = GetGameResource();
	const FBagItemAssetRow& AssetRow = GameResource.GetBagItemAssetRow(ItemType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.ItemTexture);

	const FCMSBagItemRow& BagItemRow = GetCMS()->GetBagItemRowOrDummy(ItemType);
	NameText->SetText(BagItemRow.DescName);
	CategoryText->SetText(GetBagItemCategoryText(BagItemRow.Category));
	ItemInfoText->SetText(BagItemRow.Desc);
	LootInfoText->SetText(BagItemRow.LootDesc);

	const int32 Amount = GetHUDStore().GetBagItemManager().GetBagItemCount(ItemType);
	AmountText->SetText(FText::AsNumber(Amount));
	OwnedText->SetText(Q6Util::GetLocalizedText("Lobby", "Owned"));
}

void UItemTooltipWidget::SetPoint(EPointType PointType)
{
#if !UE_BUILD_SHIPPING
	ItemIdText->SetText(FText::GetEmpty());
#endif

	const FCMSCurrencyPointRow* Row = GetCMS()->GetCurrencyPointRow(PointType);
	if (!Row)
	{
		SetEmpty();
		return;
	}

	const FPointIcon& PointIcon = GetUIResource().GetPointIcon(PointType);
	IconImage->SetBrush(PointIcon.BigBrush);

	NameText->SetText(Row->DescName);
	CategoryText->SetText(GetPointCategoryText(PointType));
	ItemInfoText->SetText(Row->Desc);
	LootInfoText->SetText(Row->LootDesc);

	const int32 Amount = GetHUDStore().GetWorldUser().GetPoint(PointType);
	AmountText->SetText(FText::AsNumber(Amount));
	OwnedText->SetText(Q6Util::GetLocalizedText("Lobby", "Owned"));
}

void UItemTooltipWidget::SetEventPoint(FEventContentType EventContentType, int32 PointIndex)
{
#if !UE_BUILD_SHIPPING
	ItemIdText->SetText(FText::GetEmpty());
#endif

	const UCMS* CMS = GetCMS();
	const FCMSCurrencyPointRow* Row = CMS->GetEventCurrencyPointRow(EventContentType, PointIndex);
	if (!Row)
	{
		SetEmpty();
		return;
	}

	const FEventListAssetRow* AssetRow = GetGameResource().GetEventListAssetRow(EventContentType.x);
	if (!AssetRow)
	{
		Q6JsonLogGunny(Warning, "UItemTooltipWidget::SetEventPoint - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType.x));

		return;
	}

	if (!AssetRow->PointItem.IsValidIndex(PointIndex))
	{
		Q6JsonLogGunny(Warning, "UItemTooltipWidget::SetEventPoint - CombatPointIcons does not exist.",
			Q6KV("EventContentType", EventContentType.x),
			Q6KV("PointIndex", PointIndex));

		return;
	}
	IconImage->SetBrush(AssetRow->PointItem[PointIndex]);

	NameText->SetText(Row->DescName);
	CategoryText->SetText(GetPointCategoryText(EPointType::Event));
	ItemInfoText->SetText(Row->Desc);
	LootInfoText->SetText(Row->LootDesc);

	TArray<int32> Amounts = GetHUDStore().GetEventManager().GetEventPoint(EventContentType);
	AmountText->SetText(FText::AsNumber(Amounts[PointIndex]));
	OwnedText->SetText(Q6Util::GetLocalizedText("Lobby", "Owned"));
}

void UItemTooltipWidget::SetAvatarEffect(FAvatarEffectType AvatarEffectType)
{
#if !UE_BUILD_SHIPPING
	ItemIdText->SetText(FText::GetEmpty());
#endif

	const FCMSAvatarEffectRow& Row = GetCMS()->GetAvatarEffectRowOrDummy(AvatarEffectType);
	if (Row.IsInvalid())
	{
		SetEmpty();
		return;
	}

	const FAvatarEffectAssetRow* AssetRow = GetGameResource().GetAvatarEffectAssetRow(AvatarEffectType);
	if (!AssetRow)
	{
		Q6JsonLogGunny(Warning, "UItemTooltipWidget::SetAvatarEffect - AvatarEffectAssetRow does not exist.",
			Q6KV("AvatarEffectType", AvatarEffectType.x));

		return;
	}

	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow->IconTexture);
	NameText->SetText(Row.DescName);
	CategoryText->SetText(Q6Util::GetLocalizedText("Lobby", "AvatarEffect"));
	ItemInfoText->SetText(Row.Desc);
	AmountText->SetText(FText::GetEmpty());
	OwnedText->SetText(FText::GetEmpty());
	LootInfoText->SetText(Row.LootDesc);
}

void UItemTooltipWidget::SetAvatarFrame(FAvatarFrameType AvatarFrameType)
{
#if !UE_BUILD_SHIPPING
	ItemIdText->SetText(FText::GetEmpty());
#endif

	const FCMSAvatarFrameRow& Row = GetCMS()->GetAvatarFrameRowOrDummy(AvatarFrameType);
	if (Row.IsInvalid())
	{
		SetEmpty();
		return;
	}

	const FAvatarFrameAssetRow* AssetRow = GetGameResource().GetAvatarFrameAssetRow(AvatarFrameType);
	if (!AssetRow)
	{
		Q6JsonLogGunny(Warning, "UItemTooltipWidget::SetAvatarFrame - AvatarFrameAssetRow does not exist.",
			Q6KV("AvatarFrameType", AvatarFrameType.x));

		return;
	}

	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow->IconTexture);
	NameText->SetText(Row.DescName);
	CategoryText->SetText(Q6Util::GetLocalizedText("Lobby", "AvatarFrame"));
	ItemInfoText->SetText(Row.Desc);
	AmountText->SetText(FText::GetEmpty());
	OwnedText->SetText(FText::GetEmpty());
	LootInfoText->SetText(Row.LootDesc);
}

void UItemTooltipWidget::SetEmpty()
{
	IconImage->SetBrush(GetUIResource().GetDummyIcon());
	NameText->SetText(FText::GetEmpty());
	CategoryText->SetText(FText::GetEmpty());
	ItemInfoText->SetText(FText::GetEmpty());
	LootInfoText->SetText(FText::GetEmpty());
	AmountText->SetText(FText::GetEmpty());
	OwnedText->SetText(FText::GetEmpty());
}

UItemWidget::UItemWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UItemWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	CheckedBorder = CastChecked<UBorder>(GetWidgetFromName("Checked"));
	OwnedBorder = CastChecked<UBorder>(GetWidgetFromName("Owned"));
	RewardTypeBorder = CastChecked<UBorder>(GetWidgetFromName("RewardType"));
	CountText = CastChecked<UTextBlock>(GetWidgetFromName("Amount"));
	RewardText = CastChecked<UTextBlock>(GetWidgetFromName("Reward"));
	ItemIdText = CastChecked<UTextBlock>(GetWidgetFromName("ItemId"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UItemWidget::OnSelectButtonClicked);
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UItemWidget::OpenItemDetail);

	SetRewardType(ERewardType::None);

#if !UE_BUILD_SHIPPING
	ItemIdText->SetVisibility(GetItemIdVisiblility());
#else
	ItemIdText->SetVisibility(ESlateVisibility::Collapsed);
#endif
}

void UItemWidget::SetRewardType(ERewardType RewardType)
{
	RewardTypeBorder->SetVisibility(RewardType == ERewardType::None ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);
	const FLinearColor& FrameColor = GetRewardFrameColor(RewardType);
	RewardTypeBorder->SetBrushColor(FrameColor);

	switch (RewardType)
	{
		case ERewardType::First:
			RewardText->SetText(Q6Util::GetLocalizedText("Common", "FirstReward"));
			break;
		case ERewardType::Ranking:
			RewardText->SetText(Q6Util::GetLocalizedText("Common", "RankingReward"));
			break;
		case ERewardType::Goal:
			RewardText->SetText(Q6Util::GetLocalizedText("Common", "GoalReward"));
			break;
		case ERewardType::Found:
			RewardText->SetText(Q6Util::GetLocalizedText("Common", "FoundReward"));
			break;
		case ERewardType::Join:
			RewardText->SetText(Q6Util::GetLocalizedText("Common", "JoinReward"));
			break;
		case ERewardType::Promote:
			RewardText->SetText(Q6Util::GetLocalizedText("Common", "PromoteReward"));
			break;
		case ERewardType::EpisodeClearReward:
			RewardText->SetText(Q6Util::GetLocalizedText("Combat", "EpisodeClearReward"));
			break;
		case ERewardType::Bonus:
			RewardText->SetText(Q6Util::GetLocalizedText("Combat", "Bonus"));
			break;
		default:
			break;
	}
}

void UItemWidget::SetBagItem(const FBagItemType& BagItemType, int32 Count /*= 1*/)
{
	Category = EItemCategory::BagItem;
	Type = BagItemType.x;

	SetItemId(BagItemType.x);

	const FBagItemAssetRow& BagItemAssetRow = GetGameResource().GetBagItemAssetRow(BagItemType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(BagItemAssetRow.ItemTexture);
	CountText->SetText(FText::AsNumber(Count));
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	SetVisibleCount(true);
}

void UItemWidget::SetLoot(int32 LootId, int32 Count /*= 1*/)
{
	const UCMS* CMS = GetCMS();
	const FCMSLootDataRow& LootDataRow = CMS->GetLootDataOrDummy(LootId);

	ECurrencyType CurrencyType = GetCurrencyType(LootDataRow.LootCategory);
	if (CurrencyType != ECurrencyType::None)
	{
		SetCurrency(CurrencyType, Count);
		return;
	}

	switch (LootDataRow.LootCategory)
	{
		case ELootCategory::BagItem:
			if (LootDataRow.Value == 0)
			{
				Q6JsonLogRoze(Error, "Not found bag item", Q6KV("LootData", LootDataRow.Type));
				return;
			}

			SetBagItem(FBagItemType(LootDataRow.Value), Count);
			break;
		case ELootCategory::CharacterCard:
			if (LootDataRow.Value == 0)
			{
				Q6JsonLogRoze(Error, "Not found unit", Q6KV("LootData", LootDataRow.Type));
				return;
			}
			SetCharacter(FCharacterType(LootDataRow.Value));
			break;
		case ELootCategory::RelicCard:
			if (LootDataRow.Value == 0)
			{
				Q6JsonLogRoze(Error, "Not found relic", Q6KV("ItemDataType", LootDataRow.Type));
				return;
			}
			SetRelic(FRelicType(LootDataRow.Value));
			break;
		case ELootCategory::SculptureCard:
			if (LootDataRow.Value == 0)
			{
				Q6JsonLogRoze(Error, "Not found sculpture", Q6KV("ItemDataType", LootDataRow.Type));
				return;
			}
			SetSculpture(FSculptureType(LootDataRow.Value));
			break;
		case ELootCategory::Wonder:
			SetMenu();
			break;
		case ELootCategory::Special:
			SetSpecial(FSpecialType(LootDataRow.Value));
			break;
		case ELootCategory::Artifact:
			SetArtifact(LootDataRow.Value - 1);	// 1-base to 0-base
			break;
		case ELootCategory::Pet:
			SetPet(FPetType(LootDataRow.Value));
			break;
		case ELootCategory::PetSecondSkill:
		case ELootCategory::PetThirdSkill:	// Fall Through
			SetPetSkill(LootDataRow);
			break;
		case ELootCategory::VacationSpot:
			SetVacationSpot();
			break;

	}
}

void UItemWidget::SetItem(const FItemData& ItemData)
{
	switch (ItemData.Category)
	{
		case ELootCategory::None:
			Q6JsonLogGunny(Warning, "UItemWidget::SetItem - ELootCategory is None.");
			break;
		case ELootCategory::BagItem:
			SetBagItem(FBagItemType(ItemData.Type), ItemData.Count);
			break;
		case ELootCategory::CharacterCard:
			SetCharacter(FCharacterType(ItemData.Type), ItemData.Count);
			break;
		case ELootCategory::SculptureCard:
			SetSculpture(FSculptureType(ItemData.Type), ItemData.Count);
			break;
		case ELootCategory::RelicCard:
			SetRelic(FRelicType(ItemData.Type), ItemData.Count);
			break;
		case ELootCategory::LobbyTemplate:
			SetLobbyTemplate(FLobbyTemplateType(ItemData.Type));
			break;
		case ELootCategory::Gold:
		case ELootCategory::FreeGem:
		case ELootCategory::PaidGem:
		case ELootCategory::SummonTicket:
		case ELootCategory::SculpturePoint:
		case ELootCategory::RelicPoint:
		case ELootCategory::FriendshipPoint:
		case ELootCategory::SmallBattery:
		case ELootCategory::MediumBattery:
		case ELootCategory::LargeBattery:
		case ELootCategory::Lumicube:		
		case ELootCategory::CharacterDisk:
		case ELootCategory::SculptureDisk:
		case ELootCategory::RelicDisk:		// Fall through
			SetCurrency(GetCurrencyType(ItemData.Category), ItemData.Count);
			break;
		case ELootCategory::AvatarEffect:
			SetAvatarEffect(FAvatarEffectType(ItemData.Type));
			break;
		case ELootCategory::AvatarFrame:
			SetAvatarFrame(FAvatarFrameType(ItemData.Type));
			break;
		default:
			break;
	}
}

void UItemWidget::SetChecked(bool CheckedFlag)
{
	CheckedBorder->SetVisibility(CheckedFlag ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UItemWidget::SetCharacter(const FCharacterType& CharacterType, int32 InCount)
{
	Category = EItemCategory::Character;
	Type = CharacterType.x;

	SetItemId(CharacterType.x);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	const FCMSCharacterRow& InCharacterRow = GetCMS()->GetCharacterRowOrDummy(CharacterType);
	if (InCharacterRow.XpExclusive)
	{
		CountText->SetText(FText::AsNumber(InCount));
		SetVisibleCount(true);
	}
	else
	{
		SetVisibleCount(false);
	}
}

void UItemWidget::SetRelic(const FRelicType& RelicType, int32 InCount)
{
	Category = EItemCategory::Relic;
	Type = RelicType.x;

	SetItemId(RelicType.x);

	const FEquipAssetRow& RelicAssetRow = GetGameResource().GetRelicAssetRow(RelicType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(RelicAssetRow.IconTexture);
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	if (InCount == 1)
	{
		SetVisibleCount(false);
	}
	else
	{
		CountText->SetText(FText::AsNumber(InCount));
		SetVisibleCount(true);
	}

#if !UE_BUILD_SHIPPING
	FText idStr = FText::FromString(FString::Printf(TEXT("Id: %d"), RelicType));
	ItemIdText->SetText(idStr);
#endif
}

void UItemWidget::SetSculpture(const FSculptureType& SculptureType, int InCount)
{
	Category = EItemCategory::Sculpture;
	Type = SculptureType.x;

	SetItemId(SculptureType.x);

	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(SculptureType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(SculptureAssetRow.IconTexture);
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	if (InCount == 1)
	{
		SetVisibleCount(false);
	}
	else
	{
		CountText->SetText(FText::AsNumber(InCount));
		SetVisibleCount(true);
	}

#if !UE_BUILD_SHIPPING
	FText idStr = FText::FromString(FString::Printf(TEXT("Id: %d"), SculptureType));
	ItemIdText->SetText(idStr);
#endif
}

void UItemWidget::SetLobbyTemplate(const FLobbyTemplateType& LobbyTemplateType)
{
	Category = EItemCategory::None;	// no tooltip
	Type = LobbyTemplateType.x;

	SetItemId(LobbyTemplateType.x);

	const FLobbyTemplateAssetRow& LobbyTemplateAssetRow = GetGameResource().GetLobbyTemplateAssetRow(LobbyTemplateType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(LobbyTemplateAssetRow.IconTexture);
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	SetVisibleCount(false);
#if !UE_BUILD_SHIPPING
	FText idStr = FText::FromString(FString::Printf(TEXT("Id: %d"), LobbyTemplateType));
	ItemIdText->SetText(idStr);
#endif
}

void UItemWidget::SetCurrency(ECurrencyType CurrencyType, int32 Count /*= 1*/)
{
	SetPoint(GetPointType(CurrencyType), Count);
}

void UItemWidget::SetAvatarEffect(FAvatarEffectType AvatarEffectType)
{
	Category = EItemCategory::AvatarEffect;
	Type = AvatarEffectType.x;
	SetItemId(AvatarEffectType.x);

	const FAvatarEffectAssetRow* Row = GetGameResource().GetAvatarEffectAssetRow(AvatarEffectType);
	if (!Row)
	{
		Q6JsonLogGunny(Warning, "UItemWidget::SetAvatarEffect - AvatarEffectAssetRow does nost exist.",
			Q6KV("AvatarEffectType", AvatarEffectType));
		return;
	}

	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(Row->IconTexture);
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	SetVisibleCount(false);

#if !UE_BUILD_SHIPPING
	FText idStr = FText::FromString(FString::Printf(TEXT("Id: %d"), AvatarEffectType));
	ItemIdText->SetText(idStr);
#endif
}

void UItemWidget::SetAvatarFrame(FAvatarFrameType AvatarFrameType)
{
	Category = EItemCategory::AvatarFrame;
	Type = AvatarFrameType.x;
	SetItemId(AvatarFrameType.x);

	const FAvatarFrameAssetRow* Row = GetGameResource().GetAvatarFrameAssetRow(AvatarFrameType);
	if (!Row)
	{
		Q6JsonLogGunny(Warning, "UItemWidget::SetAvatarFrame - AvatarFrameAssetRow does nost exist.",
			Q6KV("AvatarEffectType", AvatarFrameType));
		return;
	}

	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(Row->IconTexture);
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	SetVisibleCount(false);

#if !UE_BUILD_SHIPPING
	FText idStr = FText::FromString(FString::Printf(TEXT("Id: %d"), AvatarFrameType));
	ItemIdText->SetText(idStr);
#endif
}

void UItemWidget::SetPoint(EPointType PointType, int32 Count /*= 1*/)
{
	Category = EItemCategory::Point;
	Type = (int32)PointType;

	SetItemId(ITEM_TYPE_INVALID);

	const FPointIcon& Icon = GetUIResource().GetPointIcon(PointType);
	IconImage->SetBrush(Icon.BigBrush);
	CountText->SetText(FText::AsNumber(Count));
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	SetVisibleCount(true);
}

void UItemWidget::SetMenu()
{
	Category = EItemCategory::None;	// no tooltip
	Type = ITEM_TYPE_INVALID;

	SetItemId(ITEM_TYPE_INVALID);

	const FItemIcon& ItemIcon = GetUIResource().GetMenuOpenIcon();
	IconImage->SetBrush(ItemIcon.SmallBrush);
	SetVisibleCount(false);

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UItemWidget::SetArtifact(int32 ArtifactIndex)
{
	Category = EItemCategory::None;	// no tooltip
	Type = ArtifactIndex + 1;

	SetItemId(ArtifactIndex + 1);

	const FArtifactIcon& ArtifactIcon = GetUIResource().GetArtifactIcon(ArtifactIndex);
	IconImage->SetBrush(ArtifactIcon.MiniBrush);
	SetVisibleCount(false);

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UItemWidget::SetPet(FPetType PetType)
{
	Category = EItemCategory::None;	// no tooltip
	Type = PetType.x;

	SetItemId(PetType.x);

	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetType);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(PetAssetRow.IconTexture);
	SetVisibleCount(false);

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UItemWidget::SetPetSkill(const FCMSLootDataRow& LootDataRow)
{
	FPetType PetType = FPetType(LootDataRow.Value);

	Category = EItemCategory::None;	// no tooltip
	Type = PetType.x;

	int32 SkillIndex = INDEX_NONE;
	const FCMSPetRow& PetRow = GetCMS()->GetPetRowOrDummy(PetType);
	const TArray<const FCMSSpecialRow*>& SpecialRows = PetRow.GetSkillSpecials();
	for (int32 i = 0; i < SpecialRows.Num(); ++i)
	{
		const FCMSSpecialRow* SpecialRow = SpecialRows[i];
		check(SpecialRow);

		const TArray<const FCMSSagaRow*> SagaRows = GetCMS()->GetStageRows(EContentType::Special, SpecialRow->Episode);
		for (const FCMSSagaRow* SagaRow : SagaRows)
		{
			check(SagaRow);

			const FCMSLootDataRow& FoundLootDataRow = GetCMS()->GetFirstLootDataOrDummyFromLootGroups(SagaRow->GetInitialLootGroup());
			if (FoundLootDataRow.Type == LootDataRow.Type)
			{
				SkillIndex = i;
				break;
			}
		}
	}

	// Found next open skill

	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetType);
	if (PetAssetRow.SkillIcons.IsValidIndex(SkillIndex))
	{
		IconImage->SetBrush(PetAssetRow.SkillIcons[SkillIndex]);
	}
	else
	{
		Q6JsonLogRoze(Error, "UItemWidget::SetPetSkill - Not found skill icon", Q6KV("PetType", PetType), Q6KV("SkillIndex", SkillIndex));
	}

	const TArray<const FCMSSkillRow*>& SkillRows = PetRow.GetSkills();
	if (SkillRows.IsValidIndex(SkillIndex))
	{
		SetItemId(SkillRows[SkillIndex]->Type);
	}

	SetVisibleCount(false);
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UItemWidget::SetVacationSpot()
{
	Category = EItemCategory::None;	// no tooltip
	Type = ITEM_TYPE_INVALID;

	SetItemId(ITEM_TYPE_INVALID);

	IconImage->SetBrush(GetUIResource().GetSpecialStageIcon(ESpecialCategory::Vacation));
	SetVisibleCount(false);

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UItemWidget::SetSpecial(FSpecialType SpecialType)
{
	Category = EItemCategory::None;	// no tooltip
	Type = ITEM_TYPE_INVALID;

	SetItemId(SpecialType.x);

	const UCMS* CMS = GetCMS();
	const FCMSSpecialRow& SpecialRow = CMS->GetSpecialRowOrDummy(SpecialType);
	IconImage->SetBrush(GetUIResource().GetSpecialStageIcon(SpecialRow.ConditionType));

	SetVisibleCount(false);
}

void UItemWidget::SetDropBox(int32 DropBoxSet, EDropBoxType DropBoxType, int32 Count)
{
	Category = EItemCategory::None;	// no tooltip
	Type = ITEM_TYPE_INVALID;

	SetItemId(DropBoxSet);

	const FDropBoxTable& DropBoxTable = GetGameResource().GetDropBoxTableAssetRow(DropBoxSet);

	switch (DropBoxType)
	{
		case EDropBoxType::NRBox:
			IconImage->SetBrush(DropBoxTable.NRBoxIcon);
			break;

		case EDropBoxType::SRBox:
			IconImage->SetBrush(DropBoxTable.SRBoxIcon);
			break;

		case EDropBoxType::SSRBox:
			IconImage->SetBrush(DropBoxTable.SSRBoxIcon);
			break;

		case EDropBoxType::RandomSpawnBox:
			IconImage->SetBrush(DropBoxTable.RandomSpawnBoxIcon);
			break;

		default:
			IconImage->SetBrush(DropBoxTable.NRBoxIcon);
			break;
	}

	CountText->SetText(FText::AsNumber(Count));

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	SetVisibleCount(true);
}

void UItemWidget::SetEventPoint(FEventContentType InEventContentType, int32 InType, int32 InCount)
{
	EventContentType = InEventContentType;
	const FEventListAssetRow* AssetRow = GetGameResource().GetEventListAssetRow(EventContentType.x);
	if (!AssetRow)
	{
		Q6JsonLogGunny(Warning, "UItemWidget::SetEventPoint - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType.x));

		return;
	}

	Category = EItemCategory::EventPoint;

	const UCMS* CMS = GetCMS();
	const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(EventContentType);

	Type = InType;
	SetItemId(InType);

	if (!AssetRow->PointItem.IsValidIndex(InType))
	{
		Q6JsonLogGunny(Warning, "UItemWidget::SetEventPoint - CombatPointIcons does not exist.",
			Q6KV("InEventContentType", InEventContentType.x),
			Q6KV("InType", InType));

		return;
	}
	IconImage->SetBrush(AssetRow->PointItem[InType]);
	CountText->SetText(FText::AsNumber(InCount));
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	SetVisibleCount(true);
}

void UItemWidget::SetVisibleCount(bool bInVisible)
{
	OwnedBorder->SetVisibility(bInVisible ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UItemWidget::SetNewMark(bool bInVisible)
{
	NewMarkImage->SetVisibility(bInVisible ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UItemWidget::SetItemId(int32 ItemType)
{
#if !UE_BUILD_SHIPPING
	if (ItemType != ITEM_TYPE_INVALID)
	{
		FText IdStr = FText::FromString(FString::Printf(TEXT("Id: %d"), ItemType));
		ItemIdText->SetText(IdStr);
	}
	else
	{
		ItemIdText->SetText(FText::GetEmpty());
	}
#endif
}

void UItemWidget::OpenItemDetail()
{
	if (Category == EItemCategory::None || Type == ITEM_INVALID)
	{
		return;
	}

	ABaseHUD* HUD = GetBaseHUD(this);
	if (!HUD)
	{
		return;
	}

	if (GetLobbyTutorial(this) && !GetLobbyTutorial(this)->CanWatchItemDetail())
	{
		return;
	}

	if (Category == EItemCategory::Point)
	{
		HUD->OpenItemTooltipPopup((EPointType)Type);
	}
	else if (Category == EItemCategory::EventPoint)
	{
		HUD->OpenItemTooltipPopup(EventContentType, Type);
	}
	else if (Category == EItemCategory::BagItem)
	{
		HUD->OpenItemTooltipPopup(FBagItemType(Type));
	}
	else if (Category == EItemCategory::Character)
	{
		const FCMSCharacterRow& Row = GetCMS()->GetCharacterRowOrDummy(FCharacterType(Type));
		FItemIconInfo ItemInfo;
		MakeDefaultCharacterItemInfo(Row, &ItemInfo);
		HUD->OpenItemDetailPopup(ItemInfo);
	}
	else if (Category == EItemCategory::Sculpture)
	{
		const FCMSSculptureRow& Row = GetCMS()->GetSculptureRowOrDummy(FSculptureType(Type));
		FItemIconInfo ItemInfo;
		MakeDefaultSculptureItemInfo(Row, &ItemInfo);
		HUD->OpenItemDetailPopup(ItemInfo);
	}
	else if (Category == EItemCategory::Relic)
	{
		const FCMSRelicRow& Row = GetCMS()->GetRelicRowOrDummy(FRelicType(Type));
		FItemIconInfo ItemInfo;
		MakeDefaultRelicItemInfo(Row, &ItemInfo);
		HUD->OpenItemDetailPopup(ItemInfo);
	}
	else if (Category == EItemCategory::AvatarEffect)
	{
		HUD->OpenItemTooltipPopup(FAvatarEffectType(Type));
	}
	else if (Category == EItemCategory::AvatarFrame)
	{
		HUD->OpenItemTooltipPopup(FAvatarFrameType(Type));
	}
	else
	{
		Q6JsonLogRoze(Error, "UItemWidget::OpenItemDetail - Not implemented category", Q6KV("Category", (int32)Category));
	}
}

void UItemWidget::OnSelectButtonClicked()
{
	OnItemClicked.ExecuteIfBound();
}

const FLinearColor& UItemWidget::GetRewardFrameColor(ERewardType RewardType)
{
	if (!RewardFrameColors.IsValidIndex((int32)RewardType))
	{
		Q6JsonLogRoze(Warning, "UItemWidget::GetRewardFrameColor - invalid reward type ", Q6KV("RewardType", (int32)RewardType));
		return FLinearColor::Transparent;
	}

	return RewardFrameColors[(int32)RewardType];	// 0-base enum
}

UItemMaterialWidget::UItemMaterialWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UItemMaterialWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
	RequiredAmountText = CastChecked<UTextBlock>(GetWidgetFromName("RequiredAmount"));
}

void UItemMaterialWidget::SetMaterial(FBagItemType ItemType, int32 RequiredAmount)
{
	int32 OwnedAmount = GetHUDStore().GetBagItemManager().GetBagItemCount(ItemType);

	ItemWidget->SetBagItem(ItemType, OwnedAmount);

	RequiredAmountText->SetText(FText::AsNumber(RequiredAmount));
	RequiredAmountText->SetColorAndOpacity(RequiredAmount > OwnedAmount ? GetUIResource().GetLackColor() : FLinearColor::White);
}

UMaterialBoxWidget::UMaterialBoxWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UMaterialBoxWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	for (int32 n = 1; n <= MaxMaterialCount; ++n)
	{
		WidgetName = FString::Printf(TEXT("Material%d"), n);
		MaterialWidgets.AddUnique(CastChecked<UItemMaterialWidget>(GetWidgetFromName(*WidgetName)));
	}
}

void UMaterialBoxWidget::SetMaterials(const TArray<const FCMSBagItemRow*>& MaterialItemRows, const TArray<int32>& MaterialCount, int32 ReduceCount)
{
	check(MaterialItemRows.Num() <= MaterialCount.Num());
	ensure(MaterialItemRows.Num() <= MaterialWidgets.Num());

	for (int32 i = 0; i < MaterialWidgets.Num(); ++i)
	{
		if (MaterialItemRows.IsValidIndex(i) && MaterialItemRows[i])
		{
			MaterialWidgets[i]->SetMaterial(FBagItemType(MaterialItemRows[i]->Type), FMath::Max(MaterialCount[i] - ReduceCount, 0));
			MaterialWidgets[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
		else
		{
			MaterialWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}

void UMaterialBoxWidget::SetMaterial(const FCMSBagItemRow& MaterialItemRow, int32 MaterialCount)
{
	if (MaterialWidgets.IsValidIndex(0))
	{
		MaterialWidgets[0]->SetMaterial(FBagItemType(MaterialItemRow.Type), MaterialCount);
		MaterialWidgets[0]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	for (int32 i = 1; i < MaterialWidgets.Num(); ++i)
	{
		MaterialWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
	}
}

UEquipIconWidget::UEquipIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UEquipIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UEquipIconWidget::OpenEquipDetail);
}

void UEquipIconWidget::SetEmpty()
{
	EquipInfo = FItemIconInfo();
	IconImage->SetVisibility(ESlateVisibility::Collapsed);
}

void UEquipIconWidget::SetRelic(const FRelicInfo& RelicInfo)
{
	if (RelicInfo.Type == RelicTypeInvalid)
	{
		SetEmpty();
		return;
	}

	ConvertRelicToItemInfo(RelicInfo, &EquipInfo);

	const FEquipAssetRow& RelicAssetRow = GetGameResource().GetRelicAssetRow(RelicInfo.Type);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(RelicAssetRow.IconTexture);
	IconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UEquipIconWidget::SetSculpture(const FSculptureInfo& SculptureInfo)
{
	if (SculptureInfo.Type == SculptureTypeInvalid)
	{
		SetEmpty();
		return;
	}

	ConvertSculptureToItemInfo(SculptureInfo, &EquipInfo);

	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(SculptureInfo.Type);
	IconImage->SetBrushFromSoftTextureWhenLoadingFinished(SculptureAssetRow.IconTexture);
	IconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UEquipIconWidget::OpenEquipDetail()
{
	if (EquipInfo.IsValid())
	{
		if (ABaseHUD* HUD = GetBaseHUD(this))
		{
			HUD->OpenItemDetailPopup(EquipInfo);
		}
	}
}

UItemCardWidget::UItemCardWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bSelectable(true)
	, SelectType(EItemSelectType::Deselect)
{

}

void UItemCardWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharIconImage = CastChecked<UImage>(GetWidgetFromName("CharIcon"));
	EquipIconImage = CastChecked<UImage>(GetWidgetFromName("EquipIcon"));
	LockedImage = CastChecked<UImage>(GetWidgetFromName("Locked"));
	NewImage = CastChecked<UImage>(GetWidgetFromName("New"));
	CharMissionNewImage = CastChecked<UImage>(GetWidgetFromName("CharMissionNew"));
	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	SummonNewImage = CastChecked<UImage>(GetWidgetFromName("SummonNew"));
	SummonGradeImage = CastChecked<UImage>(GetWidgetFromName("SummonGrade"));
	LevelText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("Level"));
	StarBarWidget = CastChecked<UStarBarWidget>(GetWidgetFromName("StarBar"));
	FrameImage = CastChecked<UImage>(GetWidgetFromName("Frame"));
	ItemIdText = CastChecked<UTextBlock>(GetWidgetFromName("ItemId"));
	DisabledImage = CastChecked<UImage>(GetWidgetFromName("Disabled"));
	ReasonText = CastChecked<UTextBlock>(GetWidgetFromName("Reason"));
	CheckedNumberText = CastChecked<UTextBlock>(GetWidgetFromName("CheckedNumber"));
	OptionImage = CastChecked<UImage>(GetWidgetFromName("Option"));
	UltSkillLevelText = CastChecked<UTextBlock>(GetWidgetFromName("UltSkillLevel"));

	SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UItemCardWidget::OnSelectButtonClicked);
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UItemCardWidget::OpenItemDetail);

#if !UE_BUILD_SHIPPING
	ItemIdText->SetVisibility(GetItemIdVisiblility());
#else
	ItemIdText->SetVisibility(ESlateVisibility::Collapsed);
#endif
}

void UItemCardWidget::SetEmpty()
{
	ItemInfo = FItemIconInfo();

	CharIconImage->SetBrush(EmptyIcon);
	EquipIconImage->SetBrush(EmptyIcon);

	UltSkillLevelText->SetText(FText::GetEmpty());
	ReasonText->SetText(FText::GetEmpty());
}

void UItemCardWidget::SetRemoval()
{
	ItemInfo = FItemIconInfo();

	UltSkillLevelText->SetText(FText::GetEmpty());

	SetRemovalCard();
}

void UItemCardWidget::SetForSummon(bool bNew, EItemGrade Grade)
{
	if (bNew)
	{
		SummonNewImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		SummonNewImage->SetVisibility(ESlateVisibility::Collapsed);
	}

	SummonGradeImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	SummonGradeImage->SetBrush(GetGameResource().GetUIResource().GetSummonCardFrame(Grade));
}

void UItemCardWidget::SetForLobbySetting(bool bTemplateIncluded, bool bOwned)
{
	LevelText->SetVisibility(ESlateVisibility::Collapsed);
	StarBarWidget->SetVisibility(ESlateVisibility::Collapsed);

	if (bTemplateIncluded)
	{
		if (!bOwned)
		{
			SetReasonText(Q6Util::GetLocalizedText("Lobby", "NotOwned"), EItemSelectableReasonType::NotAvailable);
		}
	}
	else
	{
		SetReasonText(Q6Util::GetLocalizedText("Lobby", "NotTemplateIncluded"), EItemSelectableReasonType::NotIncluded);
	}
}

void UItemCardWidget::SetSelectType(EItemSelectType InSelectType)
{
	SelectType = InSelectType;

	SetCardSelect(SelectType);
}

void UItemCardWidget::SetSelected(bool bInSelected)
{
	SetSelectType(bInSelected ? EItemSelectType::Selected : EItemSelectType::Deselect);
}

void UItemCardWidget::SetHighlight(bool bInHighlight)
{
	SetSelectType(bInHighlight ? EItemSelectType::Highlight : EItemSelectType::Deselect);
}

void UItemCardWidget::SetChecked(bool bInChecked)
{
	SetSelectType(bInChecked ? EItemSelectType::Checked : EItemSelectType::Deselect);
}

void UItemCardWidget::SetNumber(int32 InNumber)
{
	CheckedNumberText->SetText(FText::AsNumber(InNumber));
}

void UItemCardWidget::SetSelectable(bool bInSelectable, bool bInDimmed)
{
	bSelectable = bInSelectable;

	bool bIsVisible = bInSelectable;
	if (bInSelectable)
	{
		if (bInDimmed)
		{
			bIsVisible = false;
		}
	}

	SetSelectEnabled(bIsVisible);
}

void UItemCardWidget::SetReasonText(const FText& Reason, EItemSelectableReasonType ReasonType /* = EItemSelectableReasonType::Default */)
{
	ReasonText->SetText(Reason);

	int32 ReasonColorIndex = (int32)ReasonType;
	if (ReasonDisabledBgColors.IsValidIndex(ReasonColorIndex))
	{
		DisabledImage->SetColorAndOpacity(ReasonDisabledBgColors[ReasonColorIndex]);
	}

	if (ReasonType == EItemSelectableReasonType::Default)
	{
		ReasonColorIndex = (int32)(bSelectable ? EItemSelectableReasonType::Activated : EItemSelectableReasonType::Inactivated);
	}
	if (ReasonColors.IsValidIndex(ReasonColorIndex))
	{
		ReasonText->SetColorAndOpacity(ReasonColors[ReasonColorIndex]);
	}
}

void UItemCardWidget::SetUsed(bool bInUsed)
{
	ItemInfo.bUsed = bInUsed;

	SetTagVisible(bInUsed);
}

void UItemCardWidget::SetNewMark(bool bNewly)
{
	NewImage->SetVisibility(bNewly ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UItemCardWidget::SetCharMissionNewMarkVisibility(ESlateVisibility InVisibility)
{
	CharMissionNewImage->SetVisibility(InVisibility);
}

void UItemCardWidget::SetUltSkillLevel(int32 SkillLevel)
{
	UltSkillLevelText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Common", "UltimateSkillLevel"), FText::AsNumber(SkillLevel)));
}

void UItemCardWidget::OnSelectButtonClicked()
{
	if (!bSelectable)
	{
		return;
	}

	OnItemClickedDelegate.ExecuteIfBound(this);
}

void UItemCardWidget::OnItemLockChanged()
{
	SetToggleLocked();

	OnItemLockedDelegate.ExecuteIfBound(this);
}

void UItemCardWidget::SetCharacterInternal(const FCharacterInfo& InCharacterInfo, const FCharacterBond& InCharacterBond, EAttributeCategory AttributeType)
{
	SetEmpty();

	ConvertCharacterToItemInfo(AttributeType, InCharacterInfo, InCharacterBond, &ItemInfo);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(ItemInfo.Level)));

	SetItem(InCharacterInfo.Type, InCharacterInfo.Grade, InCharacterInfo.Star, InCharacterInfo.Moon);
	SetTags(InCharacterInfo.Used, InCharacterInfo.Locked);

	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(InCharacterInfo.Type);
	GetUIResource().SetNatureTypeIcon(OptionImage, UnitRow.NatureType, true);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(InCharacterInfo.Type);
	CharIconImage->SetBrushFromTexture(CharacterAssetRow.GetIconTexture(InCharacterInfo.Illust).LoadSynchronous());

	SetCharacterCard();
}

void UItemCardWidget::SetCharacter(const FCharacterInfo& InCharacterInfo)
{
	const FCharacterBond& CharacterBond = GetHUDStore().GetBondManager().GetCharacterBond(InCharacterInfo.Type);
	SetCharacterInternal(InCharacterInfo, CharacterBond, EAttributeCategory::Character);
}

void UItemCardWidget::SetSystemJoker(const FCharacterInfo& InCharacterInfo)
{
	FCharacterBond CharacterBond = MakeDefaultCharacterBond(GetCMS(), InCharacterInfo.Type);
	SetCharacterInternal(InCharacterInfo, CharacterBond, EAttributeCategory::SystemJoker);
}

void UItemCardWidget::SetUserJoker(const FCharacterInfo& InCharacterInfo, const FCharacterBond& InCharacterBond, bool bFriendJoker)
{
	EAttributeCategory AttributeType = bFriendJoker ? EAttributeCategory::FriendJoker : EAttributeCategory::RecommendJoker;
	SetCharacterInternal(InCharacterInfo, InCharacterBond, AttributeType);
}

void UItemCardWidget::SetSculpture(const FSculptureInfo& InSculptureInfo)
{
	SetEmpty();

	ConvertSculptureToItemInfo(InSculptureInfo, &ItemInfo);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(ItemInfo.Level)));

	SetItem(InSculptureInfo.Type, InSculptureInfo.Grade, InSculptureInfo.Star);
	SetTags(false, InSculptureInfo.Locked);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(InSculptureInfo.Tier);
	OptionImage->SetBrush(TierBrush);

	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(InSculptureInfo.Type);
	EquipIconImage->SetBrushFromTexture(SculptureAssetRow.IconTexture.LoadSynchronous());

	SetEquipCard();
}

void UItemCardWidget::SetRelic(const FRelicInfo& InRelicInfo)
{
	SetEmpty();

	ConvertRelicToItemInfo(InRelicInfo, &ItemInfo);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(ItemInfo.Level)));

	SetItem(InRelicInfo.Type, InRelicInfo.Grade, InRelicInfo.Star);
	SetTags(false, InRelicInfo.Locked);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(InRelicInfo.Tier);
	OptionImage->SetBrush(TierBrush);

	const FEquipAssetRow& EquipAssetRow = GetGameResource().GetRelicAssetRow(InRelicInfo.Type);
	EquipIconImage->SetBrushFromTexture(EquipAssetRow.IconTexture.LoadSynchronous());

	SetEquipCard();
}

void UItemCardWidget::SetDefaultCharacter(FCharacterType CharacterType)
{
	SetEmpty();

	const UCMS* CMS = GetCMS();
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterType);
	MakeDefaultCharacterItemInfo(CharacterRow, &ItemInfo);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(ItemInfo.Level)));

	SetItem(ItemInfo.Type, ItemInfo.Grade, ItemInfo.Star, ItemInfo.Moon);

	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterType);
	GetUIResource().SetNatureTypeIcon(OptionImage, UnitRow.NatureType, true);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	CharIconImage->SetBrushFromTexture(CharacterAssetRow.GetDefaultIconTexture().LoadSynchronous());

	SetCharacterCard();
}

void UItemCardWidget::SetDefaultRelic(FRelicType RelicType)
{
	SetEmpty();

	const UCMS* CMS = GetCMS();
	const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(RelicType);
	MakeDefaultRelicItemInfo(RelicRow, &ItemInfo);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(ItemInfo.Level)));

	SetItem(ItemInfo.Type, ItemInfo.Grade, ItemInfo.Star);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(ItemInfo.Tier);
	OptionImage->SetBrush(TierBrush);

	const FEquipAssetRow& EquipAssetRow = GetGameResource().GetRelicAssetRow(RelicType);
	EquipIconImage->SetBrushFromTexture(EquipAssetRow.IconTexture.LoadSynchronous());

	SetEquipCard();
}

void UItemCardWidget::SetDefaultSculpture(FSculptureType SculptureType)
{
	SetEmpty();

	const UCMS* CMS = GetCMS();
	const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(SculptureType);
	MakeDefaultSculptureItemInfo(SculptureRow, &ItemInfo);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(ItemInfo.Level)));

	SetItem(ItemInfo.Type, ItemInfo.Grade, ItemInfo.Star);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(ItemInfo.Tier);
	OptionImage->SetBrush(TierBrush);

	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(SculptureType);
	EquipIconImage->SetBrushFromTexture(SculptureAssetRow.IconTexture.LoadSynchronous());

	SetEquipCard();
}

void UItemCardWidget::SetToggleLocked()
{
	SetLocked(!ItemInfo.bLocked);
}

void UItemCardWidget::SetLocked(bool bInLocked)
{
	ItemInfo.bLocked = bInLocked;

	LockedImage->SetVisibility(bInLocked ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UItemCardWidget::SetTags(bool bUsed, bool bLocked)
{
	SetUsed(bUsed);
	SetLocked(bLocked);
}

void UItemCardWidget::SetItem(int32 ItemType, EItemGrade Grade, int32 Star, int32 Moon)
{
#if !UE_BUILD_SHIPPING
	if (ItemType != ITEM_TYPE_INVALID)
	{
		FText IdStr = FText::FromString(FString::Printf(TEXT("Id: %d"), ItemType));
		ItemIdText->SetText(IdStr);
	}
	else
	{
		ItemIdText->SetText(FText::GetEmpty());
	}
#endif

	StarBarWidget->SetMoonStars(Moon, Star);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(Grade);
	FrameImage->SetBrush(ItemGrade.FrameBrush);
	GradeImage->SetBrush(ItemGrade.TextBrush);
}

void UItemCardWidget::OpenItemDetail()
{
	if (GetLobbyTutorial(this) && !GetLobbyTutorial(this)->CanWatchItemDetail())
	{
		return;
	}
	if (ItemInfo.Type != ITEM_INVALID)
	{
		if (ABaseHUD* HUD = GetBaseHUD(this))
		{
			UItemDetailWidget* ItemDetailPopup = HUD->OpenItemDetailPopup(ItemInfo);
			check(ItemDetailPopup);

			ItemDetailPopup->OnLockedDelegate.BindUObject(this, &UItemCardWidget::OnItemLockChanged);

			SetNewMark(false);
		}
	}
}

FCharacterId UItemCardWidget::GetCharacterId() const
{
	if ((ItemInfo.AttributeType != EAttributeCategory::Character)
		&& (ItemInfo.AttributeType != EAttributeCategory::SystemJoker)
		&& (ItemInfo.AttributeType != EAttributeCategory::RecommendJoker)
		&& (ItemInfo.AttributeType != EAttributeCategory::FriendJoker))
	{
		return FCharacterId::InvalidValue();
	}

	return FCharacterId(ItemInfo.Id);
}

FSculptureId UItemCardWidget::GetScuptureId() const
{
	if (ItemInfo.AttributeType != EAttributeCategory::Sculpture)
	{
		return FSculptureId::InvalidValue();
	}

	return FSculptureId(ItemInfo.Id);
}

FRelicId UItemCardWidget::GetRelicId() const
{
	if (ItemInfo.AttributeType != EAttributeCategory::Relic)
	{
		return FRelicId::InvalidValue();
	}

	return FRelicId(ItemInfo.Id);
}

UItemLevelWidget::UItemLevelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UItemLevelWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DefaultAnim = GetWidgetAnimationFromName(this, "AnimDefault");
	check(DefaultAnim);

	LevelUpAnim = GetWidgetAnimationFromName(this, "AnimLevelUp");
	check(LevelUpAnim);

	PromoteAnim = GetWidgetAnimationFromName(this, "AnimPromote");
	check(PromoteAnim);

	StarBarWidget = CastChecked<UStarBarWidget>(GetWidgetFromName("StarBar"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	MaxLevelText = CastChecked<UTextBlock>(GetWidgetFromName("MaxLevel"));
}

void UItemLevelWidget::SetCharacter(int32 Level, int32 Star, int32 Moon)
{
	StarBarWidget->SetMoonStars(Moon, Star);

	LevelText->SetText(FText::AsNumber(Level));
	MaxLevelText->SetText(FText::AsNumber(SystemConstHelper::GetCharacterMaxLevel(Star, Moon)));

	PlayAnimation(DefaultAnim);
}

void UItemLevelWidget::SetEquip(int32 Level, int32 Star)
{
	StarBarWidget->SetMoonStars(0, Star);

	LevelText->SetText(FText::AsNumber(Level));
	MaxLevelText->SetText(FText::AsNumber(SystemConstHelper::GetEquipMaxLevel(Star)));

	PlayAnimation(DefaultAnim);
}

void UItemLevelWidget::SetVisibleStar(bool bInVisible)
{
	StarBarWidget->SetVisibility(bInVisible ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

UItemStatusWidget::UItemStatusWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer),
	CharacterType(CharacterTypeInvalid)
{

}

void UItemStatusWidget::NativeConstruct()
{
	Super::NativeConstruct();

	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	MaxLevelText = CastChecked<UTextBlock>(GetWidgetFromName("MaxLevel"));
	XpBar = CastChecked<UProgressBar>(GetWidgetFromName("Xp"));
	RemainXpText = CastChecked<UTextBlock>(GetWidgetFromName("RemainXp"));
	BondTemperature = CastChecked<UQ6TextBlock>(GetWidgetFromName("Temperature"));
	BondBar = CastChecked<UProgressBar>(GetWidgetFromName("BarBond"));
	RemainBondText = CastChecked<UTextBlock>(GetWidgetFromName("RemainBond"));

	HpStat = CastChecked<UStatWidget>(GetWidgetFromName("Hp"));
	AtkStat = CastChecked<UStatWidget>(GetWidgetFromName("Atk"));
	DefStat = CastChecked<UStatWidget>(GetWidgetFromName("Def"));

	EffectsText = CastChecked<URichTextBlock>(GetWidgetFromName("Effects"));

	BondInfoButton = CastChecked<UQ6Button>(GetWidgetFromName("BondInfo"));
	BondInfoButton->OnClicked.AddUniqueDynamic(this, &UItemStatusWidget::OnBondInfoButtonClicked);

	ItemStatusAnims.Reset();
	ItemStatusAnims.Add(GetWidgetAnimationFromName(this, "AnimSetCharacter"));
	ItemStatusAnims.Add(GetWidgetAnimationFromName(this, "AnimSetEquip"));
	ItemStatusAnims.Add(GetWidgetAnimationFromName(this, "AnimSetCodexCharacter"));
	check(ItemStatusAnims.Num() == static_cast<int32>(EItemStatusAnimType::Max));
}

void UItemStatusWidget::SetItem(const FItemIconInfo& ItemInfo)
{
	bool bIsCharacter = false;

	switch (ItemInfo.AttributeType)
	{
		case EAttributeCategory::Relic:
			SetRelic(FRelicType(ItemInfo.Type), ItemInfo.Grade, ItemInfo.Level, ItemInfo.Xp, ItemInfo.Star, ItemInfo.Tier);
			break;
		case EAttributeCategory::Sculpture:
			SetSculpture(FSculptureType(ItemInfo.Type), ItemInfo.Grade, ItemInfo.Level, ItemInfo.Xp, ItemInfo.Star, ItemInfo.Tier);
			break;
		case EAttributeCategory::SystemJoker:
		case EAttributeCategory::Character:
		case EAttributeCategory::RecommendJoker:
		case EAttributeCategory::FriendJoker:
			bIsCharacter = true;
			SetCharacter(ItemInfo.AttributeType, FCharacterType(ItemInfo.Type), ItemInfo.Grade, ItemInfo.Level, ItemInfo.Xp, ItemInfo.Star, ItemInfo.Moon);
			break;
		default:
			Q6JsonLogRoze(Error, "UItemStatusWidget::SetItem - invalid item");
			break;
	}

	if (bIsCharacter)
	{
		ALobbyHUD* LobbyHUD = GetLobbyHUD(this);
		if (LobbyHUD && LobbyHUD->GetCurrentHUDWidgetType() == EHUDWidgetType::Codex)
		{
			PlayItemStatusAnimation(EItemStatusAnimType::CodexCharacter);
		}
		else
		{
			PlayItemStatusAnimation(EItemStatusAnimType::Character);
		}
	}
	else
	{
		PlayItemStatusAnimation(EItemStatusAnimType::Equip);
	}
}

void UItemStatusWidget::SetCharacter(EAttributeCategory AttributeType, FCharacterType InCharacterType, EItemGrade Grade, int32 Level, int32 Xp, int32 Star, int32 Moon)
{
	UCMS* CMS = GetCMS();
	int32 MaxLevel = SystemConstHelper::GetCharacterMaxLevel(Star, Moon);
	int32 NextLevel = FMath::Min(Level + 1, MaxLevel);

	const FCMSCharacterXpRow& XpRow = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(NextLevel));
	SetXp(Level, MaxLevel, XpRow.Acc - Xp, XpRow.Req);
	SetBond(InCharacterType);

	int64 Health, Atk, Def;
	Attribute::GetUnitAttribute(CMS, AttributeType, CMS->GetUnitType(InCharacterType), Level, Grade, nullptr, Health, Atk, Def);

	HpStat->SetStat(EUnitAttribute::MaxHealth, Health);
	AtkStat->SetStat(EUnitAttribute::Atk, Atk);
	DefStat->SetStat(EUnitAttribute::Def, Def);
}

void UItemStatusWidget::SetRelic(FRelicType RelicType, EItemGrade Grade, int32 Level, int32 Xp, int32 Star, int32 Tier)
{
	UCMS* CMS = GetCMS();
	int32 MaxLevel = SystemConstHelper::GetEquipMaxLevel(Star);
	int32 NextLevel = FMath::Min(Level + 1, MaxLevel);

	const FCMSItemXpRow& XpRow = CMS->GetItemXpRowOrDummy(FItemXpType(NextLevel));
	SetXp(Level, MaxLevel, XpRow.Acc - Xp, XpRow.Req);

	int64 Health, Atk, Def;
	Attribute::GetRelicAttribute(CMS, RelicType, Level, Tier, Grade, Health, Atk, Def);

	HpStat->SetStat(EUnitAttribute::MaxHealth, Health);
	AtkStat->SetStat(EUnitAttribute::Atk, Atk);
	DefStat->SetStat(EUnitAttribute::Def, Def);

	const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(RelicType);
	FString EffectsStr = GetEquipEffectsStr(Tier, RelicRow.GetBuff());
	EffectsText->SetText(FText::FromString(EffectsStr));
}

void UItemStatusWidget::SetSculpture(FSculptureType SculptureType, EItemGrade Grade, int32 Level, int32 Xp, int32 Star, int32 Tier)
{
	UCMS* CMS = GetCMS();
	int32 MaxLevel = SystemConstHelper::GetEquipMaxLevel(Star);
	int32 NextLevel = FMath::Min(Level + 1, MaxLevel);

	const FCMSItemXpRow& XpRow = CMS->GetItemXpRowOrDummy(FItemXpType(NextLevel));
	SetXp(Level, MaxLevel, XpRow.Acc - Xp, XpRow.Req);

	int64 Health, Atk, Def;
	Attribute::GetSculptureAttribute(CMS, SculptureType, Level, Tier, Grade, Health, Atk, Def);

	HpStat->SetStat(EUnitAttribute::MaxHealth, Health);
	AtkStat->SetStat(EUnitAttribute::Atk, Atk);
	DefStat->SetStat(EUnitAttribute::Def, Def);

	const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(SculptureType);
	FString EffectsStr = GetEquipEffectsStr(Tier, SculptureRow.GetBuff());
	EffectsText->SetText(FText::FromString(EffectsStr));
}

void UItemStatusWidget::SetXp(int32 Level, int32 MaxLevel, int32 RemainXp, int32 ReqXp)
{
	LevelText->SetText(FText::AsNumber(Level));
	MaxLevelText->SetText(FText::AsNumber(MaxLevel));

	float XpPercent = (float)(ReqXp - RemainXp) / ReqXp;
	XpBar->SetPercent(XpPercent);

	RemainXpText->SetText(FText::AsNumber(RemainXp));
}

void UItemStatusWidget::SetBond(FCharacterType InCharacterType)
{
	CharacterType = InCharacterType;

	const UCMS* CMS = GetCMS();
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(InCharacterType);

	if (CharacterRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UItemStatusWidget::SetBond - CharacterRow does not exist.",
			Q6KV("CharacterType", InCharacterType));
		return;
	}

	EBondCategory BondCategory = EBondCategory(CharacterRow.BondCategory);
	const FCharacterBond& Bond = GetHUDStore().GetBondManager().GetCharacterBond(CharacterType);

	int32 Temperature = Bond.Level * BondTemperaturePerLevel;
	int32 BondXp = Bond.Xp - CMS->GetStartBondXpByLevel(BondCategory, Bond.Level);
	int32 NextLevel = FMath::Min(Bond.Level + 1, MaxBondLevel);
	int32 RequireBondXp = CMS->GetBondXpByLevel(BondCategory, NextLevel);
	float XpRatio = (float)BondXp / RequireBondXp;
	float LeftXp = RequireBondXp - BondXp;

	SetBond(Temperature, NextLevel, XpRatio, LeftXp);
}

void UItemStatusWidget::SetBond(int32 Temperature, int32 NextLevel, float XpRatio, int32 LeftXp)
{
	BondTemperature->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Temperature"), FText::AsNumber(Temperature)));

	if (NextLevel == MaxBondLevel)
	{
		float MaxPersent = 1.f;
		BondBar->SetPercent(MaxPersent);
		RemainBondText->SetText(FText::AsNumber(0));
		return;
	}

	BondBar->SetPercent(XpRatio);
	RemainBondText->SetText(FText::AsNumber(LeftXp));
}

void UItemStatusWidget::PlayItemStatusAnimation(const EItemStatusAnimType InAnimType)
{
	const int32 AnimIndex = static_cast<int32>(InAnimType);
	if (ItemStatusAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(ItemStatusAnims[AnimIndex]);
	}
}

void UItemStatusWidget::OnBondInfoButtonClicked()
{
	GetBaseHUD(this)->OpenBondRewardInfoPopup(CharacterType);
}

UTurnSkillDescWidget::UTurnSkillDescWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UTurnSkillDescWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkillIconWidget = CastChecked<UTurnSkillIconWidget>(GetWidgetFromName("SkillIcon"));
	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SKillName"));
	SkillDescText = CastChecked<URichTextBlock>(GetWidgetFromName("SkillDesc"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	CooldownText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Cooldown"));
	SkillInfoBox = CastChecked<UVerticalBox>(GetWidgetFromName("BoxSkillInfo"));
}

void UTurnSkillDescWidget::SetSkill(const FSlateBrush& TurnSkillIcon, int32 InSkillType, int32 Level)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(InSkillType);
	SetSkillRow(TurnSkillIcon, SkillRow, Level);
}

void UTurnSkillDescWidget::SetSkillRow(const FSlateBrush& TurnSkillIcon, const FCMSSkillRow& SkillRow, int32 Level)
{
	SkillIconWidget->SetSkill(TurnSkillIcon);

	bool bLocked = Level <= 0;
	SkillIconWidget->SetLocked(bLocked);

	Level = bLocked ? 1 : Level;

	SkillInfoBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	SkillNameText->SetText(SkillRow.DescName);
	SkillDescText->SetText(BuildToolTipDesc(SkillRow.CmsType(), Level, ESkillCategory::TurnBegin));
	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(Level)));

	int32 Cooldown = GetCMS()->GetCooltimeByLevel(SkillRow.CmsType(), Level);
	CooldownText->SetText(FText::AsNumber(Cooldown));
}

void UTurnSkillDetailWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TurnSkillDescWidgets.Reset();
	TurnSkillDescWidgets.Add(CastChecked<UTurnSkillDescWidget>(GetWidgetFromName("TurnSkill1")));
	TurnSkillDescWidgets.Add(CastChecked<UTurnSkillDescWidget>(GetWidgetFromName("TurnSkill2")));
	TurnSkillDescWidgets.Add(CastChecked<UTurnSkillDescWidget>(GetWidgetFromName("TurnSkill3")));
	check(TurnSkillDescWidgets.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
}

void UTurnSkillDetailWidget::SetTurnSkills(FUnitType UnitType, int32 TurnSkill1Level, int32 TurnSkill2Level, int32 TurnSkill3Level)
{
	const UCMS* CMS = GetCMS();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(UnitType);
	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(UnitRow.Model);
	const TArray<const FCMSSkillRow*>& TurnSkillRows = UnitRow.GetTurnSkills();

	TArray<int32> TurnSkillLevels;
	TurnSkillLevels.Add(TurnSkill1Level);
	TurnSkillLevels.Add(TurnSkill2Level);
	TurnSkillLevels.Add(TurnSkill3Level);
	check(TurnSkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		if (!TurnSkillRows.IsValidIndex(i))
		{
			TurnSkillDescWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		const FCMSSkillRow* SkillRow = TurnSkillRows[i];
		if (!SkillRow)
		{
			Q6JsonLogRoze(Error, "UTurnSkillDetailWidget::SetTurnSkills - Invalid turn skill", Q6KV("UnitType", UnitType.x));
		}

		TurnSkillDescWidgets[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		if (SkillAssetRow.TurnSkillIcons.IsValidIndex(i))
		{
			TurnSkillDescWidgets[i]->SetSkillRow(SkillAssetRow.TurnSkillIcons[i], *SkillRow, TurnSkillLevels[i]);
		}
		else
		{
			TurnSkillDescWidgets[i]->SetSkillRow(GetGameResource().GetUIResource().GetDummyIcon(), *SkillRow, TurnSkillLevels[i]);
		}
	}
}

void UAttackSkillDetailWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UltLevelText = CastChecked<UTextBlock>(GetWidgetFromName("UltLevel"));
	UltNameText = CastChecked<UTextBlock>(GetWidgetFromName("UltName"));
	UltDescText = CastChecked<URichTextBlock>(GetWidgetFromName("UltDesc"));
	UltIconWidget = CastChecked<USkillIconWidget>(GetWidgetFromName("UltIcon"));

	SupportLevelText = CastChecked<UTextBlock>(GetWidgetFromName("SupportLevel"));
	SupportNameText = CastChecked<UTextBlock>(GetWidgetFromName("SupportName"));
	SupportDescText = CastChecked<URichTextBlock>(GetWidgetFromName("SupportDesc"));
	SupportIconWidget = CastChecked<USkillIconWidget>(GetWidgetFromName("SupportIcon"));
}

void UAttackSkillDetailWidget::SetSkills(const FCMSUnitRow& UnitRow, int32 UltLevel, int32 SupportLevel)
{
	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(UnitRow.Model);

	const FCMSSkillRow& UltSkillRow = GetCMS()->GetCharacterUltimateSkillRow(UnitRow);
	UltLevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(UltLevel)));
	UltNameText->SetText(UltSkillRow.DescName);
	UltDescText->SetText(BuildToolTipDesc(UltSkillRow.CmsType(), UltLevel, ESkillCategory::Ultimate));
	UltIconWidget->SetSkill(SkillAssetRow.UltimateIcon, UltLevel);

	const FCMSSkillRow& SupportSkillRow = GetCMS()->GetCharacterSupportSkillRow(UnitRow);
	SupportLevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(SupportLevel)));
	SupportNameText->SetText(SupportSkillRow.DescName);
	SupportDescText->SetText(BuildToolTipDesc(SupportSkillRow.CmsType(), SupportLevel, ESkillCategory::Support));
	SupportIconWidget->SetSkill(SkillAssetRow.SupportIcon, SupportLevel);
}

void UItemDescWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("Title"));
	ContentText = CastChecked<URichTextBlock>(GetWidgetFromName("Description"));
}

void UItemDescWidget::SetItem(const FItemIconInfo& ItemInfo)
{
	TitleText->SetText(Q6Util::GetLocalizedText("Lobby", "EquipmentStory"));

	switch (ItemInfo.AttributeType)
	{
		case EAttributeCategory::Relic:
			SetRelic(FRelicType(ItemInfo.Type));
			break;

		case EAttributeCategory::Sculpture:
			SetSculpture(FSculptureType(ItemInfo.Type));
			break;

		case EAttributeCategory::Character:
			SetCharacter(FCharacterType(ItemInfo.Type));
			break;

		default:
			ensure(0);
			break;
	}
}

void UItemDescWidget::SetRelic(FRelicType RelicType)
{
	const FText& StoryContent = Q6Util::GetLocalizedText("RelicStory", FString::FromInt(RelicType));
	ContentText->SetText(StoryContent);
}

void UItemDescWidget::SetSculpture(FSculptureType SculptureType)
{
	const FText& StoryContent = Q6Util::GetLocalizedText("SculptureStory", FString::FromInt(SculptureType));
	ContentText->SetText(StoryContent);
}

void UItemDescWidget::SetCharacter(FCharacterType CharacterType)
{
	const FText& StoryContent = Q6Util::GetLocalizedText("ExpCardStory", FString::FromInt(CharacterType));
	ContentText->SetText(StoryContent);
}

void UItemDetailWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	StarBarWidget = CastChecked<UStarBarWidget>(GetWidgetFromName("StarBar"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	OptionImage = CastChecked<UImage>(GetWidgetFromName("Option"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	NickNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextNickName"));
	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	IllustCardWidget = CastChecked<UItemBigCardWidget>(GetWidgetFromName("IllustCard"));
	UpgradeNewMarkImage = CastChecked<UImage>(GetWidgetFromName("UpgradeNewMark"));
	AchievementsNewMarkImage = CastChecked<UImage>(GetWidgetFromName("AchievementsNewMark"));
	ItemIdText = CastChecked<UTextBlock>(GetWidgetFromName("ItemId"));

	UpgradeButton = CastChecked<UQ6Button>(GetWidgetFromName("Upgrade"));
	UpgradeButton->OnClicked.AddUniqueDynamic(this, &UItemDetailWidget::OnUpgradeButtonClicked);

	LockButton = CastChecked<UCheckBox>(GetWidgetFromName("Lock"));
	LockButton->OnCheckStateChanged.AddUniqueDynamic(this, &UItemDetailWidget::OnLockChecked);

	IllustChangeButton = CastChecked<UQ6Button>(GetWidgetFromName("IllustChange"));
	IllustChangeButton->OnClicked.AddUniqueDynamic(this, &UItemDetailWidget::OnIllustChangeButtonClicked);

	AchievementsButton = CastChecked<UQ6Button>(GetWidgetFromName("Achievements"));
	AchievementsButton->OnClicked.AddUniqueDynamic(this, &UItemDetailWidget::OnAchievementsButtonClicked);

	UnitViewButton = CastChecked<UButton>(GetWidgetFromName("3D"));
	UnitViewButton->OnClicked.AddUniqueDynamic(this, &UItemDetailWidget::OnUnitViewButtonClicked);

	CharacterVoiceWidget = CastChecked<UCharacterVoiceWidget>(GetWidgetFromName("CharacterVoice"));

	UButton* ClearButton = CastChecked<UButton>(GetWidgetFromName("Clear"));
	ClearButton->OnClicked.AddUniqueDynamic(this, &UItemDetailWidget::OnClearButtonClicked);

	DetailSwipeWidget = CastChecked<UVarietyPageSwipeWidget>(GetWidgetFromName("DetailSwipe"));
	DetailSwipeWidget->OnSetPageDelegate.BindUObject(this, &UItemDetailWidget::OnDetailSwipeSetPage);
	DetailSwipeWidget->OnFocusedPageDelegate.BindUObject(this, &UItemDetailWidget::OnDetailSwipeFocusedPage);

	CharacterDesignerBox = CastChecked<UBorder>(GetWidgetFromName("BoxCharacterDesign"));
	IllustratorBox = CastChecked<UBorder>(GetWidgetFromName("BoxIllust"));
	CastingVoiceBox = CastChecked<UBorder>(GetWidgetFromName("BoxCastingVoice"));
	CastingActorBox = CastChecked<UBorder>(GetWidgetFromName("BoxCastingActor"));
	CharacterDesignerNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextCharacterDesign"));
	IllustratorNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextIllust"));
	CastingVoiceNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextCastingVoice"));
	CastingActorNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextCastingActor"));

	BubbleBox = CastChecked<UBorder>(GetWidgetFromName("Bubble"));
	BubbleText = CastChecked<UTextBlock>(GetWidgetFromName("TextBubble"));

	QuickMenuButton = CastChecked<UButton>(GetWidgetFromName("QuickMenu"));
	QuickMenuButton->OnClicked.AddUniqueDynamic(this, &UItemDetailWidget::OnQuickMenuButtonClicked);

	MainQuickButtons.Reset();
	MainQuickNewMarkImages.Reset();
	for (int32 i = 0; i < (int32)EUpgradeCharacterCategory::Max; ++i)
	{
		FString WidgetName = FString::Printf(TEXT("MainQuick%d"), i + 1);
		UQ6Button* QuickButton = CastChecked<UQ6Button>(GetWidgetFromName(*WidgetName));
		QuickButton->OnClickedDelegate.BindUObject(this, &UItemDetailWidget::OnMainQuickButtonClicked, (EUpgradeCharacterCategory)i);
		MainQuickButtons.Add(QuickButton);

		FString ImageName = FString::Printf(TEXT("MainQuickNewMark%d"), i + 1);
		MainQuickNewMarkImages.Add(CastChecked<UImage>(GetWidgetFromName(*ImageName)));
	}

	SubQuickButtons.Reset();
	SubQuickNewMarkImages.Reset();
	for (int32 i = 0; i < MaxSubQuickButtonCount; ++i)
	{
		FString ButtonName = FString::Printf(TEXT("SubQuick%d"), i + 1);
		UQ6Button* QuickButton = CastChecked<UQ6Button>(GetWidgetFromName(*ButtonName));
		QuickButton->OnClickedDelegate.BindUObject(this, &UItemDetailWidget::OnSubQuickButtonClicked, i);
		SubQuickButtons.Add(QuickButton);

		FString TextName = FString::Printf(TEXT("TextSubQuick%d"), i + 1);
		UTextBlock* QuickText = CastChecked<UTextBlock>(GetWidgetFromName(*TextName));
		SubQuickTexts.Add(QuickText);

		FString ImageName = FString::Printf(TEXT("SubQuickNewMark%d"), i + 1);
		SubQuickNewMarkImages.Add(CastChecked<UImage>(GetWidgetFromName(*ImageName)));
	}

#if !UE_BUILD_SHIPPING
	UButton* CopyItemIdButton = CastChecked<UButton>(GetWidgetFromName("CopyItemId"));
	CopyItemIdButton->OnClicked.AddUniqueDynamic(this, &UItemDetailWidget::OnCopyItemIdButtonClicked);

	ItemIdText->SetVisibility(GetItemIdVisiblility());

#else
	ItemIdText->SetVisibility(ESlateVisibility::Collapsed);
#endif

	// Animations

	ShowArtistAnim = GetWidgetAnimationFromName(this, "AnimShowArtist");
	HideArtistAnim = GetWidgetAnimationFromName(this, "AnimHideArtist");
	ShowBubbleAnim = GetWidgetAnimationFromName(this, "AnimShowBubble");
	HideBubbleAnim = GetWidgetAnimationFromName(this, "AnimHideBubble");
	ToNormalArtAnim = GetWidgetAnimationFromName(this, "AnimToNormalArt");
	ToFinalArtAnim = GetWidgetAnimationFromName(this, "AnimToFinalArt");

	SubscribeToStore(EHSType::CharMission);
}

bool UItemDetailWidget::OnBack()
{
	if (bFullView)
	{
		SetFullView(DetailMode, DetailType, false);
		return false;
	}

	if (DetailMode == EItemDetailMode::CharacterUnit)
	{
		ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
		if (LobbyPC && LobbyPC->IsPlayingPreview())
		{
			LobbyPC->StopPreview();
			return false;
		}

		SetDetailMode(EItemDetailMode::Info, true);
		if (LobbyPC)
		{
			LobbyPC->OnPreviewFinishedDelegate.Unbind();
			LobbyPC->OnInputPreciseTouchedDelegate.Unbind();
		}

		GetSoundPlayer().StopCharacterVoice();
		GetSoundPlayer().ClearCharacterVoiceDelegates();
		return false;
	}

	SetLobbyUnit(CharacterTypeInvalid);
	return true;
}

void UItemDetailWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	switch (Action->GetActionType())
	{
		case EHSActionType::CharMissionRewardResp:
		case EHSActionType::DevCharMissionSetResp:
			SetAchievementsButtonState();
			break;
	}
}

void UItemDetailWidget::SetItem(const FItemIconInfo& InItemInfo)
{
	ItemInfo = InItemInfo;

#if !UE_BUILD_SHIPPING
	FText IdStr = FText::FromString(FString::Printf(TEXT("UID : %lld"), InItemInfo.Id));
	ItemIdText->SetText(IdStr);
#endif

	if (ItemInfo.Type == ITEM_INVALID)
	{
		Q6JsonLogRoze(Error, "UItemDetailWidget::SetItem - Invalid item info");
		return;
	}

	CurDetailSwipePage = 1;
	DetailType = GetItemFrameType(ItemInfo);
	LockButton->SetIsChecked(ItemInfo.bLocked);

	switch (DetailType)
	{
		case EDetailItemType::NormalCharacter:
		case EDetailItemType::SpecialCharacter:
			SetCharacter();
			break;
		case EDetailItemType::Relic:
			SetRelic();
			break;
		case EDetailItemType::Sculpture:
			SetSculpture();
			break;
		case EDetailItemType::ExpCard:
			SetExpCard();
			break;
		case EDetailItemType::UltimateSculpture:
			SetUltimateSculpture();
			break;
	}

	ShowArtistDetailSwipePage = DetailSwipeWidget->GetPageCount();

	SetAchievementsButtonState();

	if (bQuickMenuVisible)
	{
		SetQuickButtons();
	}

	SetQuickMenuVisible(false);
	InitItemDetail(DetailType);
	SetDetailMode(EItemDetailMode::Info);

	// clear new
	GetHUDStore().ReqClearNewIfNotCleared(ItemInfo);
}

void UItemDetailWidget::InitItemDetail_Implementation(EDetailItemType InItemType)
{
	if (InItemType == EDetailItemType::NormalCharacter || InItemType == EDetailItemType::SpecialCharacter)
	{
		AQ6LobbyGameMode* LobbyGameMode = Cast<AQ6LobbyGameMode>(UGameplayStatics::GetGameMode(GetWorld()));
		if (LobbyGameMode)
		{
			UnitViewButton->SetVisibility(ESlateVisibility::Visible);
			return;
		}
	}

	UnitViewButton->SetVisibility(ESlateVisibility::Collapsed);
}

void UItemDetailWidget::SetFullView_Implementation(EItemDetailMode InDetailMode, EDetailItemType InItemType, bool bInFullView)
{
	if (DetailMode == EItemDetailMode::CharacterUnit)
	{
		ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
		if (LobbyPC)
		{
			LobbyPC->SetLobbyUnitFullView(bInFullView);
		}
	}
	else if (IsNonCharacterDetail())
	{
		IllustCardWidget->SetFrameVisible(!bInFullView);
	}

	bFullView = bInFullView;
}

void UItemDetailWidget::SetCharacter()
{
	const UCMS* CMS = GetCMS();
	FCharacterType CharacterType(ItemInfo.Type);
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterType);

	NameText->SetText(UnitRow.FullName);
	if (UnitRow.NickName.IsEmptyOrWhitespace())
	{
		NickNameText->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		NickNameText->SetText(UnitRow.NickName);
		NickNameText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	LevelText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(ItemInfo.Level)));

	StarBarWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	StarBarWidget->SetMoonStars(ItemInfo.Moon, ItemInfo.Star);

	UUIResource& UIResource = GetUIResource();
	const FItemGrade& ItemGrade = UIResource.GetItemGrade(ItemInfo.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	const FSlateBrush& NatureBrush = UIResource.GetNatureTypeIcon(UnitRow.NatureType);
	OptionImage->SetBrush(NatureBrush);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	if (CharacterAssetRow.CharacterDesigner.IsEmpty())
	{
		CharacterDesignerBox->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		CharacterDesignerNameText->SetText(CharacterAssetRow.CharacterDesigner);
		CharacterDesignerBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	if (CharacterAssetRow.CastingVoice.IsEmpty())
	{
		CastingVoiceBox->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		CastingVoiceNameText->SetText(CharacterAssetRow.CastingVoice);
		CastingVoiceBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	if (CharacterAssetRow.CastingActor.IsEmpty())
	{
		CastingActorBox->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		CastingActorNameText->SetText(CharacterAssetRow.CastingActor);
		CastingActorBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	EHUDWidgetType HUDWidgetType = EHUDWidgetType::Invalid;
	ALobbyHUD* LobbyHUD = GetLobbyHUD(this);
	if (LobbyHUD)
	{
		HUDWidgetType = LobbyHUD->GetCurrentHUDWidgetType();
	}

	bool bHasIllust = ItemInfo.Grade >= EItemGrade::SR;
	if (HUDWidgetType == EHUDWidgetType::Codex)
	{
		const FCodexCharInfo* CodexChar = GetHUDStore().GetCodexManager().FindChar(CharacterType);
		bCanIllustChange = bHasIllust && (CodexChar ? CodexChar->OpenedIllust : false);
		IllustChangeButton->SetVisibility(bHasIllust ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}
	else
	{
		bool bIllustOpened = ItemInfo.Star >= SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Unbind, ItemInfo.Grade);
		const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(FCharacterId(ItemInfo.Id));
		if (Character)
		{
			// Owned character
			bQuickMenuVisible = !Character->IsStashed();
			bCanIllustChange = bIllustOpened && bHasIllust;
			IllustChangeButton->SetVisibility(bHasIllust ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
			LockButton->SetVisibility(ESlateVisibility::Visible);
		}
		else
		{
			bQuickMenuVisible = false;
			bCanIllustChange = false;
			IllustChangeButton->SetVisibility(ESlateVisibility::Collapsed);
			LockButton->SetVisibility(ESlateVisibility::Collapsed);
		}
	}

	SetIllustChangeButtonEnabled(bCanIllustChange);
	SetCharacterIllust(ItemInfo.bFinalArt);

	ShowArtistDetailSwipePage = CharacterDetailWidgetClasses.Num();
	DetailSwipeWidget->SetPageWidgetClasses(CharacterDetailWidgetClasses, CurDetailSwipePage);

	InitIllustMode(ItemInfo.bFinalArt);
}

void UItemDetailWidget::SetRelic()
{
	const UCMS* CMS = GetCMS();
	const FEquipAssetRow& RelicAssetRow = GetGameResource().GetRelicAssetRow(FRelicType(ItemInfo.Type));
	if (RelicAssetRow.Illustrator.IsEmpty())
	{
		IllustratorBox->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		IllustratorNameText->SetText(RelicAssetRow.Illustrator);
		IllustratorBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	LevelText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(ItemInfo.Level)));

	StarBarWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	StarBarWidget->SetMoonStars(0, ItemInfo.Star);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(ItemInfo.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(ItemInfo.Tier);
	OptionImage->SetBrush(TierBrush);

	const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(FRelicType(ItemInfo.Type));
	NameText->SetText(RelicRow.DescName);
	NickNameText->SetVisibility(ESlateVisibility::Collapsed);

	ShowArtistDetailSwipePage = EquipDetailWidgetClasses.Num();
	DetailSwipeWidget->SetPageWidgetClasses(EquipDetailWidgetClasses, CurDetailSwipePage);
	IllustCardWidget->SetItemDetail(ItemInfo);
	IllustChangeButton->SetVisibility(ESlateVisibility::Collapsed);

	const FRelic* Relic = GetHUDStore().GetRelicManager().Find(FRelicId(ItemInfo.Id));
	if (Relic)
	{
		bQuickMenuVisible = !Relic->IsStashed();
		LockButton->SetVisibility(ESlateVisibility::Visible);
	}
	else
	{
		bQuickMenuVisible = false;
		LockButton->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UItemDetailWidget::SetSculpture()
{
	const UCMS* CMS = GetCMS();
	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(FSculptureType(ItemInfo.Type));
	if (SculptureAssetRow.Illustrator.IsEmpty())
	{
		IllustratorBox->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		IllustratorNameText->SetText(SculptureAssetRow.Illustrator);
		IllustratorBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	LevelText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(ItemInfo.Level)));

	StarBarWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	StarBarWidget->SetMoonStars(0, ItemInfo.Star);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(ItemInfo.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(ItemInfo.Tier);
	OptionImage->SetBrush(TierBrush);

	const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(FSculptureType(ItemInfo.Type));
	NameText->SetText(SculptureRow.DescName);
	NickNameText->SetVisibility(ESlateVisibility::Collapsed);

	ShowArtistDetailSwipePage = EquipDetailWidgetClasses.Num();
	DetailSwipeWidget->SetPageWidgetClasses(EquipDetailWidgetClasses, CurDetailSwipePage);

	IllustCardWidget->SetItemDetail(ItemInfo);

	IllustChangeButton->SetVisibility(ESlateVisibility::Collapsed);

	const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(FSculptureId(ItemInfo.Id));
	if (Sculpture)
	{
		bQuickMenuVisible = !Sculpture->IsStashed();
		LockButton->SetVisibility(ESlateVisibility::Visible);
	}
	else
	{
		bQuickMenuVisible = false;
		LockButton->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UItemDetailWidget::SetExpCard()
{
	UUIResource& UIResource = GetUIResource();

	bool bOwned = false;
	FText Illustrator = FText::GetEmpty();
	if (ItemInfo.AttributeType == EAttributeCategory::Character)
	{
		bOwned = GetHUDStore().GetCharacterManager().IsMyCharacter(FCharacterId(ItemInfo.Id));

		FCharacterType CharacterType(ItemInfo.Type);
		const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
		Illustrator = AssetRow.GetDefaultIllustrator();

		const FCMSUnitRow& Row = GetCMS()->GetUnitRowOrDummy(CharacterType);
		NameText->SetText(Row.DescName);

		const FSlateBrush& NatureBrush = UIResource.GetNatureTypeIcon(Row.NatureType);
		OptionImage->SetBrush(NatureBrush);
		OptionImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Sculpture)
	{
		bOwned = (GetHUDStore().GetSculptureManager().Find(FSculptureId(ItemInfo.Id)) != nullptr);

		FSculptureType SculptureType(ItemInfo.Type);
		const FSculptureAssetRow& AssetRow = GetGameResource().GetSculptureAssetRow(SculptureType);
		Illustrator = AssetRow.Illustrator;

		const FCMSSculptureRow& Row = GetCMS()->GetSculptureRowOrDummy(SculptureType);
		NameText->SetText(Row.DescName);

		OptionImage->SetVisibility(ESlateVisibility::Collapsed);
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Relic)
	{
		bOwned = (GetHUDStore().GetRelicManager().Find(FRelicId(ItemInfo.Id)) != nullptr);

		FRelicType RelicType(ItemInfo.Type);
		const FEquipAssetRow& AssetRow = GetGameResource().GetRelicAssetRow(RelicType);
		Illustrator = AssetRow.Illustrator;

		const FCMSRelicRow& Row = GetCMS()->GetRelicRowOrDummy(RelicType);
		NameText->SetText(Row.DescName);

		OptionImage->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		Q6JsonLogRoze(Warning, "UItemDetailWidget::SetExpCard - Who are you?", Q6KV("EAttributeCategory", ENUM_TO_STRING(EAttributeCategory, ItemInfo.AttributeType)));
	}

	if (Illustrator.IsEmpty())
	{
		IllustratorBox->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		IllustratorNameText->SetText(Illustrator);
		IllustratorBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	LockButton->SetVisibility(bOwned ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	NickNameText->SetVisibility(ESlateVisibility::Collapsed);
	LevelText->SetVisibility(ESlateVisibility::Collapsed);
	StarBarWidget->SetVisibility(ESlateVisibility::Collapsed);
	IllustChangeButton->SetVisibility(ESlateVisibility::Collapsed);

	const FItemGrade& ItemGrade = UIResource.GetItemGrade(ItemInfo.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	ShowArtistDetailSwipePage = ExpCardDetailWidgetClasses.Num();
	DetailSwipeWidget->SetPageWidgetClasses(ExpCardDetailWidgetClasses, CurDetailSwipePage);

	IllustCardWidget->SetItemDetail(ItemInfo);

	bQuickMenuVisible = false;
}

void UItemDetailWidget::SetUltimateSculpture()
{
	SetSculpture();

	IllustCardWidget->SetItemDetail(ItemInfo);
}

bool UItemDetailWidget::HasAchivementsCharacter()
{
	if (ItemInfo.AttributeType != EAttributeCategory::Character)
	{
		// Not a character
		return false;
	}

	if (!GetHUDStore().GetCharacterManager().IsMyCharacter(FCharacterId(ItemInfo.Id)))
	{
		// Not owned
		return false;
	}

	if (DetailType != EDetailItemType::NormalCharacter &&
		DetailType != EDetailItemType::SpecialCharacter)
	{
		// No have mission category
		return false;
	}

	ASummonHUD* SummonHUD = GetSummonHUD(this);
	if (SummonHUD)
	{
		return false;
	}

	return true;
}

void UItemDetailWidget::SetAchievementsButtonState()
{
	if (!HasAchivementsCharacter())
	{
		AchievementsButton->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	FCharacterType CharType(ItemInfo.Type);
	ESlateVisibility AchivementsNewMarkVisibility = GetHUDStore().GetNewMarkManager().GetCharacterMissionsVisibility(CharType);
	AchievementsNewMarkImage->SetVisibility(AchivementsNewMarkVisibility);
	AchievementsButton->SetVisibility(ESlateVisibility::Visible);

	EFeatureOpenType FeatureOpenType(EFeatureOpenType::CharacterMisson);
	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();
	SetItemDetialWidgetAchievementsState(
		!ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType));
}

void UItemDetailWidget::SetQuickMenuVisible(bool bInVisible)
{
	QuickMenuButton->SetVisibility(bInVisible ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}

void UItemDetailWidget::SetQuickButtons()
{
	const UCMS* CMS = GetCMS();
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();

	// Set main quick menu buttons

	bool bAnyUpgradeNewly = false;
	bool bNonCharacter = IsNonCharacterDetail();
	int32 MainQuickEnabledIndex = INDEX_NONE;
	if (!bNonCharacter)
	{
		bool bCanMaxUp = ItemInfo.Level >= SystemConstHelper::GetCharacterMaxLevel(ItemInfo.Star, ItemInfo.Moon);
		if (bCanMaxUp && !SystemConstHelper::IsWeed(FCharacterType(ItemInfo.Type)))
		{
			bool bOwned = GetHUDStore().GetCharacterManager().IsMyCharacter(FCharacterId(ItemInfo.Id));
			if (!bOwned)
			{
				return;
			}

			if (ItemInfo.Star < SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Promote, ItemInfo.Grade))
			{
				MainQuickEnabledIndex = (int32)EUpgradeCharacterCategory::Promote;
			}
			else if (ItemInfo.Star < SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Unbind, ItemInfo.Grade))
			{
				MainQuickEnabledIndex = (int32)EUpgradeCharacterCategory::Unbind;
			}
			else if (ItemInfo.Moon < MAX_CHARACTER_MOON)
			{
				MainQuickEnabledIndex = (int32)EUpgradeCharacterCategory::Evolute;
			}
		}
		else
		{
			MainQuickEnabledIndex = (int32)EUpgradeCharacterCategory::LevelUp;
		}

		TArray<ESlateVisibility> MainQuickNewMarkVisibilities = NewMarkMgr.GetUpgradeCharacterDetailVisibilities(FCharacterId(ItemInfo.Id));
		check(MainQuickNewMarkVisibilities.Num() == (int32)EUpgradeCharacterCategory::Max);

		for (int32 i = 0; i < (int32)EUpgradeCharacterCategory::Max; ++i)
		{
			MainQuickButtons[i]->SetVisibility(ESlateVisibility::Visible);
			MainQuickButtons[i]->SetIsEnabled(MainQuickEnabledIndex == i);
			MainQuickNewMarkImages[i]->SetVisibility(MainQuickNewMarkVisibilities[i]);

			bAnyUpgradeNewly |= (MainQuickNewMarkVisibilities[i] == ESlateVisibility::SelfHitTestInvisible);
		}
	}
	else
	{
		for (int32 i = 0; i < (int32)EUpgradeCharacterCategory::Max; ++i)
		{
			MainQuickButtons[i]->SetVisibility(ESlateVisibility::Collapsed);
		}
	}

	// Set sub quick menu buttons

	TArray<bool> SubQuickButtonEnables;

	TArray<ESlateVisibility> SubQuickNewMarkVisibilities;
	if (bNonCharacter)
	{
		if (ItemInfo.AttributeType == EAttributeCategory::Sculpture)
		{
			SubQuickNewMarkVisibilities = NewMarkMgr.GetUpgradeSculptureDetailVisibilities(FSculptureId(ItemInfo.Id));
		}
		else if (ItemInfo.AttributeType == EAttributeCategory::Relic)
		{
			SubQuickNewMarkVisibilities = NewMarkMgr.GetUpgradeRelicDetailVisibilities(FRelicId(ItemInfo.Id));
		}

		// Set equipment upgrade quick menu enables

		SubQuickButtonEnables.SetNumZeroed((int32)EUpgradeEquipCategory::Max);
		if ((ItemInfo.Level >= SystemConstHelper::GetEquipMaxLevel(ItemInfo.Star)))
		{
			if (ItemInfo.Star < MAX_EQUIP_STAR)
			{
				SubQuickButtonEnables[(int32)EUpgradeEquipCategory::Promote] = true;
			}
		}
		else
		{
			SubQuickButtonEnables[(int32)EUpgradeEquipCategory::LevelUp] = true;
		}

		SubQuickButtonEnables[(int32)EUpgradeEquipCategory::TierUp] = (ItemInfo.Tier < CombatCubeConst::Q6_MAX_TIER);
	}
	else
	{
		SubQuickButtonEnables.SetNumZeroed((int32)EUpgradeSkillCategory::Max);
		SubQuickNewMarkVisibilities = { ESlateVisibility::Collapsed, ESlateVisibility::Collapsed };

		SubQuickButtonEnables[(int32)EUpgradeSkillCategory::TurnBegin]
			= (ItemInfo.TurnSkill1Level < CombatCubeConst::Q6_MAX_SKILL_LEVEL)
			|| (ItemInfo.TurnSkill2Level < CombatCubeConst::Q6_MAX_SKILL_LEVEL)
			|| ((ItemInfo.TurnSkill3Level < CombatCubeConst::Q6_MAX_SKILL_LEVEL));

		if (!SystemConstHelper::IsWeed(FCharacterType(ItemInfo.Type)))
		{
			SubQuickNewMarkVisibilities = NewMarkMgr.GetUpgradeSkillDetailVisibilities(FCharacterId(ItemInfo.Id));
			check(SubQuickNewMarkVisibilities.Num() == (int32)EUpgradeSkillCategory::Max);

			// Set character skill upgrade quick menu enables

			SubQuickButtonEnables[(int32)EUpgradeSkillCategory::Ultimate]
				= (ItemInfo.UltSkillLevel < CombatCubeConst::Q6_MAX_SKILL_LEVEL);
		}
	}

	check(SubQuickNewMarkVisibilities.Num() == SubQuickButtonEnables.Num());

	for (int32 i = 0; i < MaxSubQuickButtonCount; ++i)
	{
		// Set new mark

		if (SubQuickNewMarkVisibilities.IsValidIndex(i))
		{
			SubQuickNewMarkImages[i]->SetVisibility(SubQuickNewMarkVisibilities[i]);
			bAnyUpgradeNewly |= (SubQuickNewMarkVisibilities[i] == ESlateVisibility::SelfHitTestInvisible);
		}
		else
		{
			SubQuickNewMarkImages[i]->SetVisibility(ESlateVisibility::Collapsed);
		}

		// Set button enable

		SubQuickButtons[i]->SetIsEnabled(SubQuickButtonEnables.IsValidIndex(i) ? SubQuickButtonEnables[i] : false);

		// Set button visible

		if (bNonCharacter)
		{
			SubQuickButtons[i]->SetVisibility(ESlateVisibility::Visible);

			const FText& ButtonName = GetUIResource().GetUpgradeEquipmentName((EUpgradeEquipCategory)i);
			SubQuickTexts[i]->SetText(ButtonName);

			continue;
		}

		// Character skill upgrade menu

		const FText& ButtonName = GetUIResource().GetUpgradeSkillName((EUpgradeSkillCategory)i);
		SubQuickTexts[i]->SetText(ButtonName);

		SubQuickButtons[i]->SetVisibility((i < (int32)EUpgradeSkillCategory::Max) ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}

	UpgradeNewMarkImage->SetVisibility(bAnyUpgradeNewly ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UItemDetailWidget::SetLobbyUnit(FCharacterType CharacterType)
{
	ALobbyPlayerController* LobbyPC = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
	if (LobbyPC)
	{
		LobbyPC->SetLobbyUnit(CharacterType, true);
		LobbyPC->OnInputPreciseTouchedDelegate.BindUObject(this, &UItemDetailWidget::OnClearButtonClicked);
	}
}

bool UItemDetailWidget::IsNonCharacterDetail()
{
	switch (DetailType)
	{
		case EDetailItemType::ExpCard:
		case EDetailItemType::Sculpture:
		case EDetailItemType::Relic:
		case EDetailItemType::UltimateSculpture:
			return true;
	}

	return false;
}

void UItemDetailWidget::SetDetailMode_Implementation(EItemDetailMode InDetailMode, bool bInBack /* = false */)
{
	DetailMode = InDetailMode;

	ALobbyHUD* LobbyHUD = GetLobbyHUD(this);
	switch (DetailMode)
	{
		case EItemDetailMode::Info:
			{
				if (LobbyHUD)
				{
					LobbyHUD->SetWidgetsVisible(true);
					LobbyHUD->UpdateAppreciationActorVisibility(false);
				}

				if (LobbyHUD && bQuickMenuVisible)
				{
					UpgradeButton->SetVisibility(ESlateVisibility::Visible);
				}
				else
				{
					UpgradeButton->SetVisibility(ESlateVisibility::Collapsed);
				}
			}
			break;
		case EItemDetailMode::CharacterUnit:
			{
				FCharacterType CharacterType = FCharacterType(ItemInfo.Type);
				CharacterVoiceWidget->SetCharacter(CharacterType);

				if (!bInBack && LobbyHUD)
				{
					LobbyHUD->SetWidgetsVisible(false);
					SetVisibility(ESlateVisibility::SelfHitTestInvisible);

					LobbyHUD->UpdateAppreciationActorVisibility(true);
					SetLobbyUnit(FCharacterType(ItemInfo.Type));
				}
			}
			break;
	}

	SetFullView(DetailMode, DetailType, false);
}

void UItemDetailWidget::SetCharacterIllust(bool bFinalArt)
{
	FCharacterType CharacterType(ItemInfo.Type);
	UGameResource& GameResource = GetGameResource();
	const FCharacterAssetRow& CharacterAssetRow = GameResource.GetCharacterAssetRow(CharacterType);

	int32 IllustIndex = ItemInfo.bFinalArt ? 1 : 0;

	// Set illustrator

	const FText& Illustrator = CharacterAssetRow.GetIllustrator(IllustIndex);
	if (Illustrator.IsEmpty())
	{
		IllustratorBox->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		IllustratorNameText->SetText(Illustrator);
		IllustratorBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	if (ItemInfo.Grade < EItemGrade::SR)
	{
		// Set body texture

		if (CharacterAssetRow.BodyTexture.IsNull())
		{
			CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(DefaultIllustTexture);
		}
		else
		{
			CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);
		}
	}

	// Set illust BG

	const TSoftObjectPtr<UTexture2D>& IllustBGTexture = CharacterAssetRow.GetIllustBGTexture(IllustIndex);
	if (IllustBGTexture.IsNull())
	{
		BGImage->SetBrushFromSoftTextureWhenLoadingFinished(DefaultBGTexture);
	}
	else
	{
		BGImage->SetBrushFromSoftTextureWhenLoadingFinished(IllustBGTexture);
	}
}

void UItemDetailWidget::OnDetailSwipeSetPage(UWidget* ViewWidget, int32 PageNum)
{
	if (UItemStatusWidget* StatusWidget = Cast<UItemStatusWidget>(ViewWidget))
	{
		StatusWidget->SetItem(ItemInfo);
	}
	else if (UTurnSkillDetailWidget* TurnSkillWidget = Cast<UTurnSkillDetailWidget>(ViewWidget))
	{
		FUnitType UnitType = GetCMS()->GetUnitType(FCharacterType(ItemInfo.Type));
		TurnSkillWidget->SetTurnSkills(UnitType, ItemInfo.TurnSkill1Level, ItemInfo.TurnSkill2Level, ItemInfo.TurnSkill3Level);
	}
	else if (UAttackSkillDetailWidget* AttakSkillWidget = Cast<UAttackSkillDetailWidget>(ViewWidget))
	{
		FCharacterType CharacterType = FCharacterType(ItemInfo.Type);
		const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(CharacterType);
		AttakSkillWidget->SetSkills(UnitRow, ItemInfo.UltSkillLevel, ItemInfo.SupportSkillLevel);
	}
	else if (UTraitsDetailWidget* NoteSkillWidget = Cast<UTraitsDetailWidget>(ViewWidget))
	{
		FCharacterType CharacterType = FCharacterType(ItemInfo.Type);
		NoteSkillWidget->SetCharacter(CharacterType);
	}
	else if (UCharacterProfileWidget* CharacterProfileWidget = Cast<UCharacterProfileWidget>(ViewWidget))
	{
		FText CharacterBubbleText;
		FCharacterType CharacterType = FCharacterType(ItemInfo.Type);
		CharacterProfileWidget->SetCharacter(CharacterType, CharacterBubbleText);

		if (CharacterBubbleText.IsEmpty())
		{
			BubbleBox->SetVisibility(ESlateVisibility::Collapsed);
		}
		else
		{
			BubbleText->SetText(CharacterBubbleText);
			BubbleBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
	}
	else if (UItemDescWidget* ItemDescWidget = Cast<UItemDescWidget>(ViewWidget))
	{
		ItemDescWidget->SetItem(ItemInfo);
	}
}

void UItemDetailWidget::OnDetailSwipeFocusedPage(int32 FocusingPage)
{
	if (FocusingPage == ShowArtistDetailSwipePage)
	{
		PlayAnimation(ShowArtistAnim);
		if (!IsNonCharacterDetail())
		{
			PlayAnimation(ShowBubbleAnim);
		}
	}
	else if (CurDetailSwipePage == ShowArtistDetailSwipePage)
	{
		PlayAnimation(HideArtistAnim);
		if (!IsNonCharacterDetail())
		{
			PlayAnimation(HideBubbleAnim);
		}
	}

	CurDetailSwipePage = FocusingPage;
}

void UItemDetailWidget::OnMainQuickButtonClicked(EUpgradeCharacterCategory Category)
{
	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Upgrade);

	FUpgradeUIState NewUIState;
	NewUIState.UpgradeSequence = EUpgradeSequence::Upgrade;
	NewUIState.Category = EUpgradeCategory::Character;
	NewUIState.UpgradeMenuIndex = (int32)Category;
	NewUIState.ItemId = ItemInfo.Id;

	ACTION_DISPATCH_UpgradeMenu(NewUIState);

	ClosePopup();
}

void UItemDetailWidget::OnSubQuickButtonClicked(int32 Index)
{
	FUpgradeUIState NewUIState;
	NewUIState.UpgradeSequence = EUpgradeSequence::Upgrade;
	NewUIState.UpgradeMenuIndex = Index;
	NewUIState.ItemId = ItemInfo.Id;

	if (ItemInfo.AttributeType == EAttributeCategory::Relic)
	{
		NewUIState.Category = EUpgradeCategory::Relic;
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Sculpture)
	{
		NewUIState.Category = EUpgradeCategory::Sculpture;
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Character)
	{
		NewUIState.Category = EUpgradeCategory::Skill;
	}
	else
	{
		Q6JsonLogRoze(Error, "UItemDetailWidget::OnSubQuickButtonClicked - Is not my item",
			Q6KV("Category", (int32)ItemInfo.AttributeType), Q6KV("ItemId", ItemInfo.Id));
		return;
	}

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Upgrade);

	ACTION_DISPATCH_UpgradeMenu(NewUIState);

	ClosePopup();
}

void UItemDetailWidget::OnUpgradeButtonClicked()
{
	SetQuickMenuVisible(true);
}

void UItemDetailWidget::OnLockChecked(bool bInChecked)
{
	OnLockedDelegate.ExecuteIfBound();

	GetHUDStore().ReqSetLock(ItemInfo.AttributeType, ItemInfo.Id, bInChecked);
}

void UItemDetailWidget::OnIllustChangeButtonClicked()
{
	if (!bCanIllustChange)
	{
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Common", "NotEnoughStarForFinalUpgradeArt"));
		return;
	}

	ItemInfo.bFinalArt = !ItemInfo.bFinalArt;

	PlayAnimation(ItemInfo.bFinalArt ? ToFinalArtAnim : ToNormalArtAnim);
	SetCharacterIllust(ItemInfo.bFinalArt);

	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	if (CharacterMgr.IsMyCharacter(FCharacterId(ItemInfo.Id)))
	{
		CharacterMgr.ReqSetIllust(FCharacterId(ItemInfo.Id), ItemInfo.bFinalArt ? 1 : 0);
	}
}

void UItemDetailWidget::OnClearButtonClicked()
{
	SetFullView(DetailMode, DetailType, !bFullView);
}

void UItemDetailWidget::OnQuickMenuButtonClicked()
{
	SetQuickMenuVisible(false);
}

void UItemDetailWidget::OnAchievementsButtonClicked()
{
	EFeatureOpenType FeatureOpenType(EFeatureOpenType::CharacterMisson);

	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();
	bool bEnable = ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType);
	if (!bEnable)
	{
		GetBaseHUD(this)->ShowNotOpenedYetNotification(FeatureOpenType);
		return;
	}

	check(ItemInfo.AttributeType == EAttributeCategory::Character);

	UAchievementsPageWidget* AchievementsPageWidget = GetLobbyHUD(this)->OpenAchievementsPagePopup();
	AchievementsPageWidget->InitAchievementsPage(FCharacterType(ItemInfo.Type));
}

void UItemDetailWidget::OnUnitViewButtonClicked()
{
	SetDetailMode(EItemDetailMode::CharacterUnit, false);
}

void UItemDetailWidget::OnCopyItemIdButtonClicked()
{
#if !UE_BUILD_SHIPPING
	FPlatformApplicationMisc::ClipboardCopy(*FString::Printf(TEXT("%lld"), ItemInfo.Id));
	ABaseHUD* BaseHUD = GetBaseHUD(this);
	if (BaseHUD)
	{
		BaseHUD->ShowNotification(ENotificationType::Short, FText::FromName("UID Copy!!!"));
	}

#endif
}

void USimpleItemCardWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("CharIcon"));
	EquipImage = CastChecked<UImage>(GetWidgetFromName("EquipIcon"));
	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	StarBarWidget = CastChecked<UStarBarWidget>(GetWidgetFromName("StarBar"));
	TierImage = CastChecked<UImage>(GetWidgetFromName("Tier"));
	LevelText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("Level"));
	ReasonText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Reason"));
	BondBar = CastChecked<UProgressBar>(GetWidgetFromName("BarBond"));
	TemperatureText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Temperature"));
	GetBondPointText = CastChecked<UTextBlock>(GetWidgetFromName("GetBondPoint"));
	BondUpImage = CastChecked<UImage>(GetWidgetFromName("BondUp"));
	FrameImage = CastChecked<UImage>(GetWidgetFromName("Frame"));
	ItemTypeText = CastChecked<UTextBlock>(GetWidgetFromName("ItemType"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &USimpleItemCardWidget::OnSelectButtonClicked);

	// Animations

	EnabledAnim = GetWidgetAnimationFromName(this, "AnimEnabled");
	DisabledAnim = GetWidgetAnimationFromName(this, "AnimDisabled");
	CharacterSetAnim = GetWidgetAnimationFromName(this, "AnimSetCharacter");
	EquipSetAnim = GetWidgetAnimationFromName(this, "AnimSetEquip");

#if !UE_BUILD_SHIPPING
	ItemTypeText->SetVisibility(GetItemIdVisiblility());
#else
	ItemTypeText->SetVisibility(ESlateVisibility::Collapsed);
#endif
}

void USimpleItemCardWidget::SetPortalCharacter(const FCharacterInfo& CharacterInfo)
{
	ItemId = CharacterInfo.CharacterId;
	SetItemType(CharacterInfo.Type.x);

	const UCMS* CMS = GetCMS();

	// Set bond

	int32 BondXp = 0;
	int32 BondLevel = 1;
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterInfo.Type);
	const FCharacterBond* CharacterBond = GetHUDStore().GetBondManager().Find(CharacterInfo.Type);
	if (CharacterBond)
	{
		BondXp = CharacterBond->Xp;
		BondLevel = CharacterBond->Level;
	}

	SetCharacter(CharacterInfo, (EBondCategory)CharacterRow.BondCategory, BondXp, BondLevel);

	// Set button enabled

	int32 MaxBondXp = CMS->GetMaxBondXp((EBondCategory)CharacterRow.BondCategory);
	bool bMaxBondLevel = (BondLevel >= MaxBondLevel);
	bool bHasHistory = GetHUDStore().GetPyramidManager().GetCharacterPortal(CharacterInfo.Type);

	if (!bMaxBondLevel)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "LowBond"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetLackColor());
	}

	if (bHasHistory)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "ReconnectDisable"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetEnoughColor());
	}

	SetItemEnabled(bMaxBondLevel && !bHasHistory);
}

void USimpleItemCardWidget::SetPortalRelic(const FRelicInfo& RelicInfo)
{
	ItemId = RelicInfo.RelicId;
	SetItemType(RelicInfo.Type.x);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(RelicInfo.Level)));
	StarBarWidget->SetMoonStars(0, RelicInfo.Star);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(RelicInfo.Grade);
	FrameImage->SetBrush(ItemGrade.FrameBrush);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(RelicInfo.Tier);
	TierImage->SetBrush(TierBrush);

	const FEquipAssetRow& EquipAssetRow = GetGameResource().GetRelicAssetRow(RelicInfo.Type);
	EquipImage->SetBrushFromSoftTextureWhenLoadingFinished(EquipAssetRow.IconTexture);

	PlayAnimation(EquipSetAnim);

	// Set button enabled

	bool bMaxLevel = (RelicInfo.Level >= SystemConstHelper::GetEquipMaxLevel(EquipMaxStar));
	bool bHasHistory = GetHUDStore().GetPyramidManager().GetRelicPortal(RelicInfo.Type);

	if (!bMaxLevel)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "LowLevel"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetLackColor());
	}

	if (bHasHistory)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "ReconnectDisable"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetEnoughColor());
	}

	SetItemEnabled(bMaxLevel && !bHasHistory);
}

void USimpleItemCardWidget::SetPortalSculpture(const FSculptureInfo& SculptureInfo)
{
	ItemId = SculptureInfo.SculptureId;
	SetItemType(SculptureInfo.Type.x);

	LevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "CardLevel"), FText::AsNumber(SculptureInfo.Level)));
	StarBarWidget->SetMoonStars(0, SculptureInfo.Star);

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(SculptureInfo.Grade);
	FrameImage->SetBrush(ItemGrade.FrameBrush);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	const FSlateBrush& TierBrush = GetUIResource().GetTierIcon(SculptureInfo.Tier);
	TierImage->SetBrush(TierBrush);

	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(SculptureInfo.Type);
	EquipImage->SetBrushFromSoftTextureWhenLoadingFinished(SculptureAssetRow.IconTexture);

	PlayAnimation(EquipSetAnim);

	// Set button enabled

	bool bMaxLevel = (SculptureInfo.Level >= SystemConstHelper::GetEquipMaxLevel(EquipMaxStar));
	bool bHasHistory = GetHUDStore().GetPyramidManager().GetSculpturePortal(SculptureInfo.Type);

	if (!bMaxLevel)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "LowLevel"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetLackColor());
	}

	if (bHasHistory)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "ReconnectDisable"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetEnoughColor());
	}

	SetItemEnabled(bMaxLevel && !bHasHistory);
}

void USimpleItemCardWidget::SetBondCharacter(const FBondHistory& BondHistory)
{
	ItemId = ITEM_INVALID;
	SetItemType(BondHistory.CharacterType.x);

	PlayAnimation(CharacterSetAnim);

	const UCMS* CMS = GetCMS();
	const UBondManager& BondManager = GetHUDStore().GetBondManager();
	const FCharacterBond* CharacterBond = BondManager.Find(BondHistory.CharacterType);

	if (!CharacterBond)
	{
		Q6JsonLogGunny(Warning, "USimpleItemCardWidget::SetBondCharacter - CharacterBond does not exist.");
		return;
	}

	const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(BondHistory.CharacterType);

	if (CharacterRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "USimpleItemCardWidget::SetBondCharacter - CharacterRow does not exist.");
		return;
	}

	EBondCategory BondCategory = EBondCategory(CharacterRow.BondCategory);
	int32 StartXp = CMS->GetStartBondXpByLevel(BondCategory, CharacterBond->Level);
	int32 Xp = CharacterBond->Xp - StartXp;

	GetBondPointText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	GetBondPointText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "PlusText"), FText::AsNumber(BondHistory.GainedXp)));

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterRow.CmsType());

	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());
	BondUpImage->SetVisibility(BondHistory.bLevelUp ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	int32 NextLevel = CharacterBond->Level + 1;
	int32 RequireBondXp = CMS->GetBondXpByLevel(BondCategory, NextLevel);
	int32 Temperature = BondTemperaturePerLevel * CharacterBond->Level;
	float XpRatio = (float)Xp / RequireBondXp;

	TemperatureText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Temperature"), FText::AsNumber(Temperature)));
	BondBar->SetPercent(XpRatio);

	SetItemEnabled(true);
}

void USimpleItemCardWidget::SetVacationCharacter(const FCharacterInfo& CharacterInfo)
{
	ItemId = CharacterInfo.CharacterId;
	SetItemType(CharacterInfo.Type.x);

	const UCMS* CMS = GetCMS();

	// Set bond

	int32 BondXp = 0;
	int32 BondLevel = 1;
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterInfo.Type);
	const FCharacterBond* CharacterBond = GetHUDStore().GetBondManager().Find(CharacterInfo.Type);
	if (CharacterBond)
	{
		BondXp = CharacterBond->Xp;
		BondLevel = CharacterBond->Level;
	}

	SetCharacter(CharacterInfo, (EBondCategory)CharacterRow.BondCategory, BondXp, BondLevel);

	// Set button enabled

	int32 MaxBondXp = CMS->GetMaxBondXp((EBondCategory)CharacterRow.BondCategory);
	bool bMaxBondLevel = (BondLevel >= MaxBondLevel);
	bool bAnotherVacation = GetHUDStore().GetVacationManager().IsVacationNow(CharacterInfo.Type);

	if (bMaxBondLevel)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "MaxBond"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetLackColor());
	}

	if (bAnotherVacation)
	{
		ReasonText->SetText(Q6Util::GetLocalizedText("Lobby", "OnVacation"));
		ReasonText->SetColorAndOpacity(GetUIResource().GetEnoughColor());
	}

	SetItemEnabled(!bMaxBondLevel && !bAnotherVacation);
}

void USimpleItemCardWidget::SetCharacter(const FCharacterInfo& CharacterInfo, EBondCategory BondCategory, int32 BondXp, int32 BondLevel)
{
	const UCMS* CMS = GetCMS();
	int32 StartXp = CMS->GetStartBondXpByLevel(BondCategory, BondLevel);
	int32 Xp = BondXp - StartXp;
	int32 NextLevel = FMath::Min(BondLevel + 1, MaxBondLevel);
	int32 RequireBondXp = CMS->GetBondXpByLevel(BondCategory, NextLevel);

	BondBar->SetPercent((float) Xp / RequireBondXp);
	TemperatureText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Temperature"), FText::AsNumber(BondLevel * BondTemperaturePerLevel)));

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterInfo.Type);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());

	const FItemGrade& ItemGrade = GetUIResource().GetItemGrade(CharacterInfo.Grade);
	FrameImage->SetBrush(ItemGrade.FrameBrush);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	PlayAnimation(CharacterSetAnim);
}

void USimpleItemCardWidget::SetItemEnabled(bool bInEnabled)
{
	PlayAnimation(bInEnabled ? EnabledAnim : DisabledAnim);
}

void USimpleItemCardWidget::SetItemType(int32 ItemType)
{
#if !UE_BUILD_SHIPPING
	if (ItemType != ITEM_TYPE_INVALID)
	{
		FText TypeStr = FText::FromString(FString::Printf(TEXT("Id: %d"), ItemType));
		ItemTypeText->SetText(TypeStr);
	}
	else
	{
		ItemTypeText->SetText(FText::GetEmpty());
	}
#endif
}

void USimpleItemCardWidget::OnSelectButtonClicked()
{
	OnItemCardClickedDelegate.ExecuteIfBound(ItemId);
}


UItemBigCardWidget::UItemBigCardWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UItemBigCardWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UltimateWidgetSlot = CastChecked<UNamedSlot>(GetWidgetFromName("SlotUltimateWidget"));
	PictureImage = CastChecked<UImage>(GetWidgetFromName("Picture"));
	FrameImage = CastChecked<UImage>(GetWidgetFromName("CardFrame"));

	UButton* ActionButton = CastChecked<UButton>(GetWidgetFromName("Action"));
	ActionButton->OnClicked.AddUniqueDynamic(this, &UItemBigCardWidget::OnActionButtonClicked);

	DecoLoopAnim = GetWidgetAnimationFromName(this, "AnimDecoLoop");
	PlayAnimation(DecoLoopAnim, 0.f, 0);
}

void UItemBigCardWidget::NativeDestruct()
{
	Super::NativeDestruct();

	if (UltimateWidgetSlot->HasAnyChildren())
	{
		UltimateWidgetSlot->ClearChildren();
	}
}

void UItemBigCardWidget::SetSummonResult(const FSummonInfo& Info)
{
	if (Info.IsCharacter())
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		if (Info.Category == ELootCategory::RelicCard)
		{
			SetRelic(FRelicType(Info.Type));
		}
		else
		{
			SetSculpture(FSculptureType(Info.Type));
		}
	}

	SetFrameVisible(true);
}

void UItemBigCardWidget::SetItemDetail(const FItemIconInfo& ItemInfo)
{
	UGameResource& GameResource = GetGameResource();
	if (ItemInfo.AttributeType == EAttributeCategory::Character)
	{
		SetCharacter(FCharacterType(ItemInfo.Type));
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Relic)
	{
		SetRelic(FRelicType(ItemInfo.Type));
	}
	else if (ItemInfo.AttributeType == EAttributeCategory::Sculpture)
	{
		SetSculpture(FSculptureType(ItemInfo.Type));
	}
}

void UItemBigCardWidget::SetCharacter(const FCharacterType CharacterType)
{
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	PictureImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIllustBGTexture());

	SetFrame(GetItemFrameType(CharacterType));
}

void UItemBigCardWidget::SetRelic(const FRelicType RelicType)
{
	const FEquipAssetRow& RelicAssetRow = GetGameResource().GetRelicAssetRow(RelicType);
	PictureImage->SetBrushFromSoftTextureWhenLoadingFinished(RelicAssetRow.IllustTexture);

	SetFrame(GetItemFrameType(RelicType));
}

void UItemBigCardWidget::SetSculpture(const FSculptureType& SculptureType)
{
	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(SculptureType);
	if (!SculptureAssetRow.UltimateWidgetClass.IsNull())
	{
		USkillAnimationWidget* UltimateWidget = CreateWidget<USkillAnimationWidget>(GetOwningPlayer(), SculptureAssetRow.UltimateWidgetClass.LoadSynchronous());
		check(UltimateWidget);

		UltimateWidgetSlot->AddChild(UltimateWidget);
		UltimateWidget->PlayCardAnimation(true);
	}
	else
	{
		PictureImage->SetBrushFromSoftTextureWhenLoadingFinished(SculptureAssetRow.IllustTexture);
	}

	SetFrame(GetItemFrameType(SculptureType));
}

void UItemBigCardWidget::SetFrame(EDetailItemType FrameType)
{
	if (FrameBrushes.IsValidIndex((int32)FrameType))
	{
		FrameImage->SetBrush(FrameBrushes[(int32)FrameType]);
	}
}

void UItemBigCardWidget::OnActionButtonClicked()
{
	OnActionButtonClickedDelegate.ExecuteIfBound();
}

void URewardItemWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DayCountBorder = CastChecked<UBorder>(GetWidgetFromName("DayCount"));
	DayCountText = CastChecked<UTextBlock>(GetWidgetFromName("TextDayCount"));
	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));

	RotationRewardAnim = GetWidgetAnimationFromName(this, "AnimRotationReward");
	AnniversaryRewardAnim = GetWidgetAnimationFromName(this, "AnimAnniversaryReward");
	AlreadyAnim = GetWidgetAnimationFromName(this, "AnimAlready");
	NowAnim = GetWidgetAnimationFromName(this, "AnimNow");
	YetAnim = GetWidgetAnimationFromName(this, "AnimYet");
}

void URewardItemWidget::SetItem(const FItemData& InItemData)
{
	DayCountBorder->SetVisibility(ESlateVisibility::Collapsed);
	ItemWidget->SetItem(InItemData);
}

void URewardItemWidget::SetEventPoint(const FItemData& InItemData, FEventContentType InEventContentType)
{
	DayCountBorder->SetVisibility(ESlateVisibility::Collapsed);
	ItemWidget->SetEventPoint(InEventContentType, InItemData.Type, InItemData.Count);
}

void URewardItemWidget::SetCheckInItem(const FCMSLootDataRow& LootDataRow, int32 CurrentRewardDay, int32 RewardDayCount)
{
	DayCountBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	ItemWidget->SetLoot(LootDataRow.LootId, LootDataRow.Count);
	DayCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "DailyCount"), FText::AsNumber(RewardDayCount)));

	if (CurrentRewardDay > RewardDayCount)
	{
		PlayAnimation(AlreadyAnim);
		PlayAnimation(AnniversaryRewardAnim);
	}
	else if (CurrentRewardDay < RewardDayCount)
	{
		PlayAnimation(YetAnim);
	}
	else
	{
		PlayAnimation(NowAnim);
		PlayAnimation(AnniversaryRewardAnim);
	}
}

void URewardItemWidget::SetCheckInType(ECheckInType CheckInType, bool bDayCount)
{
	DayCountText->SetVisibility(bDayCount ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	PlayAnimation((CheckInType == ECheckInType::Rotation) ? RotationRewardAnim : AnniversaryRewardAnim);
}

void URewardItemWidget::SetEventRewardItem(const FItemData& InItemData, int32 InCurrentPoint, int32 InAccumPoint)
{
	if (InCurrentPoint < InAccumPoint)
	{
		PlayAnimation(YetAnim);
	}
	else if (InCurrentPoint == InAccumPoint)
	{
		PlayAnimation(NowAnim);
	}
	else
	{
		PlayAnimation(AlreadyAnim);
	}

	DayCountBorder->SetVisibility(ESlateVisibility::Collapsed);
	ItemWidget->SetItem(InItemData);
}

void UItemSelectActionWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectedBorder = CastChecked<UBorder>(GetWidgetFromName("BorderSelected"));
	SelectedCountText = CastChecked<URichTextBlock>(GetWidgetFromName("SelectedCount"));
	ActionBoxWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("ActionBox"));
	ActionBoxWidget->OnToggleButtonChangedDelegate.BindUObject(this, &UItemSelectActionWidget::OnActionModeChanged);
}

void UItemSelectActionWidget::InitActionMode(bool bSelect, bool bDetail, bool bLock)
{
	TArray<bool> ActionEnables;
	ActionEnables.Add(bSelect);
	ActionEnables.Add(bDetail);
	ActionEnables.Add(bLock);

	const TArray<UUserWidget*>& ActionTypeButtons = ActionBoxWidget->GetToggleButtons();
	check(ActionEnables.Num() == (int32)EItemActionType::Max);
	check(ActionTypeButtons.Num() == (int32)EItemActionType::Max);

	bool bSelectedDefault = false;
	for (int32 i = 0; i < (int32)EItemActionType::Max; ++i)
	{
		UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(ActionTypeButtons[i]);
		if (ActionEnables[i])
		{
			ToggleButton->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

			if (!bSelectedDefault)
			{
				ActionBoxWidget->InitSelectedIndex(i);
				bSelectedDefault = true;
			}
		}
		else
		{
			ToggleButton->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}

void UItemSelectActionWidget::SetSelectedCount(int32 Count, int32 MaxCount)
{
	SelectedCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "SelectNumCount"),
		FText::AsNumber(Count), FText::AsNumber(MaxCount)));
}

void UItemSelectActionWidget::SetSelectedCount(int32 Count)
{
	SelectedCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "NumCount"), FText::AsNumber(Count)));
}

void UItemSelectActionWidget::SelectDefaultActionMode()
{
	const TArray<UUserWidget*>& ActionTypeButtons = ActionBoxWidget->GetToggleButtons();
	for (int32 i = 0; i < (int32)EItemActionType::Max; ++i)
	{
		UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(ActionTypeButtons[i]);
		if (ToggleButton->IsVisible())
		{
			ActionBoxWidget->SetSelectedIndex(i);
			return;
		}
	}
}

void UItemSelectActionWidget::OnActionModeChanged(int32 ActionModeIndex)
{
	ActionType = (EItemActionType)ActionModeIndex;

	OnActionModeChangedDelegate.ExecuteIfBound();

	SelectedBorder->SetVisibility(ActionType == EItemActionType::Select ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UTraitsDetailWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkillNoteCardWidgets.Reset();
	for (int32 n = 1; n <= MaxNormalSkillCount; ++n)
	{
		FString WidgetNameStr = FString::Printf(TEXT("AttackABCCard%d"), n);
		USkillNoteCardWidget* AttackCardWidget = CastChecked<USkillNoteCardWidget>(GetWidgetFromName(*WidgetNameStr));
		SkillNoteCardWidgets.Add(AttackCardWidget);
	}

	PassiveBuffListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("PassiveBuffList"));
	AceBonusText = CastChecked<UTextBlock>(GetWidgetFromName("BonusPercentA"));
	BreakBonusText = CastChecked<UTextBlock>(GetWidgetFromName("BonusPercentB"));
	CloserBonusText = CastChecked<UTextBlock>(GetWidgetFromName("BonusPercentC"));
}

void UTraitsDetailWidget::SetCharacter(FCharacterType CharacterType)
{
	const UCMS* CMS = GetCMS();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterType);

	// Set skill note bonus

	AceBonusText->SetText(FText::FromString(FString::Printf(TEXT("+%d%%"), (int32)UnitRow.NoteAceBonus / 10)));
	BreakBonusText->SetText(FText::FromString(FString::Printf(TEXT("+%d%%"), (int32)UnitRow.NoteBreakBonus / 10)));
	CloserBonusText->SetText(FText::FromString(FString::Printf(TEXT("+%d%%"), (int32)UnitRow.NoteCloserBonus / 10)));

	// Set skill note cards

	const TArray<const FCMSSkillRow*>& NormalSkillRows = UnitRow.GetNormalSkills();
	check(NormalSkillRows.Num() <= MaxNormalSkillCount);

	for (int32 i = 0; i < MaxNormalSkillCount; ++i)
	{
		if (!NormalSkillRows.IsValidIndex(i))
		{
			SkillNoteCardWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		SkillNoteCardWidgets[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		SkillNoteCardWidgets[i]->SetCharacter(UnitRow.Model, NormalSkillRows[i]->SkillNote);
	}

	// Set passive buffs

	const TArray<const FCMSBuffRow*>& PassiveBuffs = UnitRow.GetPassiveBuffs();

	PassiveBuffListWidget->ClearList();
	for (int32 i = 0; i < PassiveBuffs.Num(); ++i)
	{
		const FCMSBuffRow& BuffRow = *PassiveBuffs[i];

		if (BuffRow.FollowMoment != EMoment::None)
		{
			const TArray<const FCMSSkillRow*> FollowMomentSkills = BuffRow.GetFollowMomentSkill();
			for (const FCMSSkillRow* FollowMomentSkill : FollowMomentSkills)
			{
				FSkillType MomentSkillType = FollowMomentSkill->CmsType();
				if (MomentSkillType == SkillTypeInvalid)
				{
					continue;
				}

				UCombatDetailConditionStateWidget* PassiveBuffWidget = CastChecked<UCombatDetailConditionStateWidget>(PassiveBuffListWidget->AddChildAtLastIndex());
				PassiveBuffWidget->SetMomentSkill(BuffRow, MomentSkillType);
			}
		}

		const TArray<const FCMSBuffEffectRow*>& BuffEffectRows = BuffRow.GetBuffEffect();
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			check(BuffEffectRow);

			UCombatDetailConditionStateWidget* PassiveBuffWidget = CastChecked<UCombatDetailConditionStateWidget>(PassiveBuffListWidget->AddChildAtLastIndex());
			PassiveBuffWidget->SetBuffEffect(BuffRow, *BuffEffectRow);
		}
	}
}
