// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseWidget.h"
#include "Network/Q6ClientNetwork.h"
#include "Patch/Q6Patch.h"
#include "PatchHUDWidget.generated.h"

/**
 *
 */
UCLASS()
class Q6_API UPatchHUDWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPatchHUDWidget(const FObjectInitializer& ObjectInitializer);

	void NativeConstruct() override;
	void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

private:

	UFUNCTION()
	void OnStartPatchButtonClicked();

	FText GetPatchErrorMessage(EPatchSystemError InPatchSystemError);

	UPROPERTY()
	UButton* StartPatchButton;

	UPROPERTY()
	bool bFinished;

	UPROPERTY()
	bool bLoadGame;

	UPROPERTY()
	bool bErrorState;

	UPROPERTY()
	UTextBlock* PatchMsgTextBlock;

	UPROPERTY()
	UTextBlock* PercentTextBlock;

	UPROPERTY()
	UProgressBar* PercentProgressBar;
};
