// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CharacterManager.h"
#include "Formula.h"
#include "FriendManager.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6UIDefine.h"
#include "RelicManager.h"
#include "SculptureManager.h"
#include "UIStateManager.h"

#include "SortingWidgets.generated.h"

class UToggleButtonWidget;

struct FOrderingBase
{
	explicit FOrderingBase(ESortDirection InSortDirection)
		: SortDirection(InSortDirection)
	{
	}
	virtual ~FOrderingBase() {}

	FORCEINLINE virtual bool operator()(const FFriendInfoEx& Lhs, const FFriendInfoEx& Rhs) const
	{
		return Compare(Lhs.FriendId, Rhs.FriendId);
	}

	FORCEINLINE virtual bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const
	{
		return Compare(Lhs.GetInfo().CharacterId, Rhs.GetInfo().CharacterId);
	}

	FORCEINLINE virtual bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const
	{
		return Compare(Lhs.Info.SculptureId, Rhs.Info.SculptureId);
	}

	FORCEINLINE virtual bool operator()(const FRelic& Lhs, const FRelic& Rhs) const
	{
		return Compare(Lhs.Info.RelicId, Rhs.Info.RelicId);
	}

	FORCEINLINE virtual bool operator()(const FCMSCharacterRow& Lhs, const FCMSCharacterRow& Rhs) const { return false; }
	FORCEINLINE virtual bool operator()(const FCMSRelicRow& Lhs, const FCMSRelicRow& Rhs) const { return false; }
	FORCEINLINE virtual bool operator()(const FCMSSculptureRow& Lhs, const FCMSSculptureRow& Rhs) const { return false; }

protected:
	FORCEINLINE bool IsAscending() const { return SortDirection == ESortDirection::Ascending; }

	template<typename T>
	FORCEINLINE bool Compare(const T& Lhs, const T& Rhs) const
	{
		return IsAscending() ? Lhs < Rhs : Rhs < Lhs;
	}

private:
	ESortDirection SortDirection;
};


struct FOrderingTypeBase : FOrderingBase
{
	explicit FOrderingTypeBase(ESortDirection InSortDirection)
		: FOrderingBase(InSortDirection)
	{
	}

	FORCEINLINE virtual bool operator()(const FCMSCharacterRow& Lhs, const FCMSCharacterRow& Rhs) const override
	{
		return Compare(Lhs.Type, Rhs.Type);
	}

	FORCEINLINE virtual bool operator()(const FCMSSculptureRow& Lhs, const FCMSSculptureRow& Rhs) const override
	{
		return Compare(Lhs.Type, Rhs.Type);
	}

	FORCEINLINE virtual bool operator()(const FCMSRelicRow& Lhs, const FCMSRelicRow& Rhs) const override
	{
		return Compare(Lhs.Type, Rhs.Type);
	}

	FORCEINLINE virtual bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if ((int32)Lhs.GetInfo().Type == (int32)Rhs.GetInfo().Type)
		{
			return FOrderingBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.GetInfo().Type, (int32)Rhs.GetInfo().Type);
	}

	FORCEINLINE virtual bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if ((int32)Lhs.Info.Type == (int32)Rhs.Info.Type)
		{
			return FOrderingBase::operator()(Lhs, Rhs);
		}

		return Compare(Lhs.Info.Type, Rhs.Info.Type);
	}

	FORCEINLINE virtual bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if ((int32)Lhs.Info.Type == (int32)Rhs.Info.Type)
		{
			return FOrderingBase::operator()(Lhs, Rhs);
		}

		return Compare(Lhs.Info.Type, Rhs.Info.Type);
	}
};

struct FOrderingGradeBase : FOrderingTypeBase
{
	explicit FOrderingGradeBase(ESortDirection InSortDirection)
		: FOrderingTypeBase(InSortDirection)
	{
	}

	FORCEINLINE virtual bool operator()(const FCMSCharacterRow& Lhs, const FCMSCharacterRow& Rhs) const override
	{
		if ((int32)Lhs.Grade == (int32)Rhs.Grade)
		{
			return FOrderingTypeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Grade, (int32)Rhs.Grade);
	}

	FORCEINLINE virtual bool operator()(const FCMSSculptureRow& Lhs, const FCMSSculptureRow& Rhs) const override
	{
		if ((int32)Lhs.Grade == (int32)Rhs.Grade)
		{
			return FOrderingTypeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Grade, (int32)Rhs.Grade);
	}

	FORCEINLINE virtual bool operator()(const FCMSRelicRow& Lhs, const FCMSRelicRow& Rhs) const override
	{
		if ((int32)Lhs.Grade == (int32)Rhs.Grade)
		{
			return FOrderingTypeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Grade, (int32)Rhs.Grade);
	}

	FORCEINLINE virtual bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if ((int32)Lhs.GetInfo().Grade == (int32)Rhs.GetInfo().Grade)
		{
			return FOrderingTypeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.GetInfo().Grade, (int32)Rhs.GetInfo().Grade);
	}

	FORCEINLINE virtual bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if ((int32)Lhs.Info.Grade == (int32)Rhs.Info.Grade)
		{
			return FOrderingTypeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Info.Grade, (int32)Rhs.Info.Grade);
	}

	FORCEINLINE virtual bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if ((int32)Lhs.Info.Grade == (int32)Rhs.Info.Grade)
		{
			return FOrderingTypeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Info.Grade, (int32)Rhs.Info.Grade);
	}
};

struct FOrderingNatureBase : FOrderingGradeBase
{
	explicit FOrderingNatureBase(ESortDirection InSortDirection)
		: FOrderingGradeBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FCMSCharacterRow& Lhs, const FCMSCharacterRow& Rhs) const override
	{
		int32 LhsNatureType = (int32)Lhs.GetUnit().NatureType;
		int32 RhsNatureType = (int32)Rhs.GetUnit().NatureType;

		if (LhsNatureType == RhsNatureType)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(LhsNatureType, RhsNatureType);
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		const FCMSUnitRow& LhsRow = GetCMS()->GetUnitRowOrDummy(Lhs.GetInfo().Type);
		const FCMSUnitRow& RhsRow = GetCMS()->GetUnitRowOrDummy(Rhs.GetInfo().Type);

		int32 LhsNatureType = (int32)LhsRow.NatureType;
		int32 RhsNatureType = (int32)RhsRow.NatureType;

		if (LhsNatureType == RhsNatureType)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(LhsNatureType, RhsNatureType);
	}
};

struct FOrderByGrade : FOrderingNatureBase
{
	explicit FOrderByGrade(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FCMSCharacterRow& Lhs, const FCMSCharacterRow& Rhs) const override
	{
		if ((int32)Lhs.Grade == (int32)Rhs.Grade)
		{
			return FOrderingNatureBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Grade, (int32)Rhs.Grade);
	}

	FORCEINLINE bool operator()(const FCMSSculptureRow& Lhs, const FCMSSculptureRow& Rhs) const override
	{
		if ((int32)Lhs.Grade == (int32)Rhs.Grade)
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Grade, (int32)Rhs.Grade);
	}

	FORCEINLINE bool operator()(const FCMSRelicRow& Lhs, const FCMSRelicRow& Rhs) const override
	{
		if ((int32)Lhs.Grade == (int32)Rhs.Grade)
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Grade, (int32)Rhs.Grade);
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if ((int32)Lhs.GetInfo().Grade == (int32)Rhs.GetInfo().Grade)
		{
			return FOrderingNatureBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.GetInfo().Grade, (int32)Rhs.GetInfo().Grade);
	}

	FORCEINLINE bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if ((int32)Lhs.Info.Grade == (int32)Rhs.Info.Grade)
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Info.Grade, (int32)Rhs.Info.Grade);
	}

	FORCEINLINE bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if ((int32)Lhs.Info.Grade == (int32)Rhs.Info.Grade)
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare((int32)Lhs.Info.Grade, (int32)Rhs.Info.Grade);
	}
};

struct FOrderByName : FOrderingNatureBase
{
	explicit FOrderByName(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FCMSCharacterRow& Lhs, const FCMSCharacterRow& Rhs) const override
	{
		FString LhsNameStr = Lhs.GetUnit().DescName.ToString();
		FString RhsNameStr = Rhs.GetUnit().DescName.ToString();

		if (LhsNameStr == RhsNameStr)
		{
			return FOrderingNatureBase::operator()(Lhs, Rhs);
		}

		return Compare(LhsNameStr, RhsNameStr);
	}

	FORCEINLINE bool operator()(const FCMSSculptureRow& Lhs, const FCMSSculptureRow& Rhs) const override
	{
		if (Lhs.DescName.ToString() == Rhs.DescName.ToString())
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare(Lhs.DescName.ToString(), Rhs.DescName.ToString());
	}

	FORCEINLINE bool operator()(const FCMSRelicRow& Lhs, const FCMSRelicRow& Rhs) const override
	{
		if (Lhs.DescName.ToString() == Rhs.DescName.ToString())
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare(Lhs.DescName.ToString(), Rhs.DescName.ToString());
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		const FCMSUnitRow& LhsRow = GetCMS()->GetUnitRowOrDummy(Lhs.GetInfo().Type);
		const FCMSUnitRow& RhsRow = GetCMS()->GetUnitRowOrDummy(Rhs.GetInfo().Type);

		if (LhsRow.DescName.ToString() == RhsRow.DescName.ToString())
		{
			return FOrderingNatureBase::operator()(Lhs, Rhs);
		}

		return Compare(LhsRow.DescName.ToString(), RhsRow.DescName.ToString());
	}

	FORCEINLINE bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		const FCMSSculptureRow& LhsRow = GetCMS()->GetSculptureRowOrDummy(Lhs.Info.Type);
		const FCMSSculptureRow& RhsRow = GetCMS()->GetSculptureRowOrDummy(Rhs.Info.Type);

		if (LhsRow.DescName.ToString() == RhsRow.DescName.ToString())
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare(LhsRow.DescName.ToString(), RhsRow.DescName.ToString());
	}

	FORCEINLINE bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		const FCMSRelicRow& LhsRow = GetCMS()->GetRelicRowOrDummy(Lhs.Info.Type);
		const FCMSRelicRow& RhsRow = GetCMS()->GetRelicRowOrDummy(Rhs.Info.Type);

		if (LhsRow.DescName.ToString() == RhsRow.DescName.ToString())
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return Compare(LhsRow.DescName.ToString(), RhsRow.DescName.ToString());
	}
};

struct FOrderByNature : FOrderingGradeBase
{
	explicit FOrderByNature(ESortDirection InSortDirection)
		: FOrderingGradeBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FCMSCharacterRow& Lhs, const FCMSCharacterRow& Rhs) const override
	{
		int32 LhsNatureType = (int32)Lhs.GetUnit().NatureType;
		int32 RhsNatureType = (int32)Rhs.GetUnit().NatureType;

		if (LhsNatureType == RhsNatureType)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(LhsNatureType, RhsNatureType);
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		const FCMSUnitRow& LhsRow = GetCMS()->GetUnitRowOrDummy(Lhs.GetInfo().Type);
		const FCMSUnitRow& RhsRow = GetCMS()->GetUnitRowOrDummy(Rhs.GetInfo().Type);

		if ((int32)LhsRow.NatureType == (int32)RhsRow.NatureType)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare((int32)LhsRow.NatureType, (int32)RhsRow.NatureType);
	}
};

struct FOrderByLevel : FOrderingNatureBase
{
	explicit FOrderByLevel(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
		, JokerSlotIndex(INDEX_NONE)
	{
	}

	explicit FOrderByLevel(ESortDirection InSortDirection, int32 InJokerSlotIndex)
		: FOrderingNatureBase(InSortDirection)
		, JokerSlotIndex(InJokerSlotIndex)
	{
	}

	FORCEINLINE bool operator()(const FFriendInfoEx& Lhs, const FFriendInfoEx& Rhs) const override
	{
		const auto& LhsInfo = Lhs.JokerSet.Slots[JokerSlotIndex].CharacterInfo;
		const auto& RhsInfo = Rhs.JokerSet.Slots[JokerSlotIndex].CharacterInfo;

		if (LhsInfo.Level == RhsInfo.Level)
		{
			return FOrderingBase::operator ()(Lhs, Rhs);
		}

		return Compare(LhsInfo.Level, RhsInfo.Level);
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if (Lhs.GetInfo().Level == Rhs.GetInfo().Level)
		{
			return FOrderingNatureBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.GetInfo().Level, Rhs.GetInfo().Level);
	}

	FORCEINLINE bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if (Lhs.Info.Level == Rhs.Info.Level)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Info.Level, Rhs.Info.Level);
	}

	FORCEINLINE bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if (Lhs.Info.Level == Rhs.Info.Level)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Info.Level, Rhs.Info.Level);
	}

private:
	int32 JokerSlotIndex;
};

struct FOrderByCreated : FOrderingNatureBase
{
	explicit FOrderByCreated(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if (Lhs.GetInfo().Created == Rhs.GetInfo().Created)
		{
			return FOrderingNatureBase::operator()(Lhs, Rhs);
		}

		return !Compare(Lhs.GetInfo().Created, Rhs.GetInfo().Created);
	}

	FORCEINLINE bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if (Lhs.Info.Created == Rhs.Info.Created)
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return !Compare(Lhs.Info.Created, Rhs.Info.Created);
	}

	FORCEINLINE bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if (Lhs.Info.Created == Rhs.Info.Created)
		{
			return FOrderingGradeBase::operator()(Lhs, Rhs);
		}

		return !Compare(Lhs.Info.Created, Rhs.Info.Created);
	}
};

struct FOrderByUltimateSkill : FOrderingNatureBase
{
	explicit FOrderByUltimateSkill(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		int32 LhsUltSkillLevel = Lhs.GetInfo().UltimateSkillLevel;
		int32 RhsUltSkillLevel = Rhs.GetInfo().UltimateSkillLevel;

		if (LhsUltSkillLevel == RhsUltSkillLevel)
		{
			return FOrderingNatureBase::operator()(Lhs, Rhs);
		}

		return Compare(LhsUltSkillLevel, RhsUltSkillLevel);
	}
};

struct FOrderByHp : FOrderingNatureBase
{
	explicit FOrderByHp(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FFriendInfoEx& Lhs, const FFriendInfoEx& Rhs) const override
	{
		if (Lhs.Hp == Rhs.Hp)
		{
			return FOrderingBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Hp, Rhs.Hp);
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if (Lhs.Hp == Rhs.Hp)
		{
			return FOrderingNatureBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Hp, Rhs.Hp);
	}

	FORCEINLINE bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if (Lhs.Hp == Rhs.Hp)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Hp, Rhs.Hp);
	}

	FORCEINLINE bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if (Lhs.Hp == Rhs.Hp)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Hp, Rhs.Hp);
	}
};

struct FOrderByAtk : FOrderingNatureBase
{
	explicit FOrderByAtk(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FFriendInfoEx& Lhs, const FFriendInfoEx& Rhs) const override
	{
		if (Lhs.Atk == Rhs.Atk)
		{
			return FOrderingBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Atk, Rhs.Atk);
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if (Lhs.Atk == Rhs.Atk)
		{
			return FOrderingNatureBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Atk, Rhs.Atk);
	}

	FORCEINLINE bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if (Lhs.Atk == Rhs.Atk)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Atk, Rhs.Atk);
	}

	FORCEINLINE bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if (Lhs.Atk == Rhs.Atk)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Atk, Rhs.Atk);
	}
};

struct FOrderByDef : FOrderingNatureBase
{
	explicit FOrderByDef(ESortDirection InSortDirection)
		: FOrderingNatureBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FFriendInfoEx& Lhs, const FFriendInfoEx& Rhs) const override
	{
		if (Lhs.Def == Rhs.Def)
		{
			return FOrderingBase::operator()(Lhs, Rhs);
		}

		return Compare(Lhs.Def, Rhs.Def);
	}

	FORCEINLINE bool operator()(const FCharacter& Lhs, const FCharacter& Rhs) const override
	{
		if (Lhs.Def == Rhs.Def)
		{
			return FOrderingNatureBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Def, Rhs.Def);
	}

	FORCEINLINE bool operator()(const FSculpture& Lhs, const FSculpture& Rhs) const override
	{
		if (Lhs.Def == Rhs.Def)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Def, Rhs.Def);
	}

	FORCEINLINE bool operator()(const FRelic& Lhs, const FRelic& Rhs) const override
	{
		if (Lhs.Def == Rhs.Def)
		{
			return FOrderingGradeBase::operator ()(Lhs, Rhs);
		}

		return Compare(Lhs.Def, Rhs.Def);
	}
};

struct FOrderByLastLogin : FOrderingBase
{
	explicit FOrderByLastLogin(ESortDirection InSortDirection)
		: FOrderingBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FFriendInfoEx& Lhs, const FFriendInfoEx& Rhs) const override
	{
		if (Lhs.LastLogin == Rhs.LastLogin)
		{
			return FOrderingBase::operator()(Lhs, Rhs);
		}

		return !Compare(Lhs.LastLogin, Rhs.LastLogin);
	}
};

struct FOrderByFriendLevel : FOrderingBase
{
	explicit FOrderByFriendLevel(ESortDirection InSortDirection)
		: FOrderingBase(InSortDirection)
	{
	}

	FORCEINLINE bool operator()(const FFriendInfoEx& Lhs, const FFriendInfoEx& Rhs) const override
	{
		if (Lhs.Level == Rhs.Level)
		{
			return FOrderingBase::operator()(Lhs, Rhs);
		}

		return Compare(Lhs.Level, Rhs.Level);
	}
};

struct FSortOrdering
{
	FORCEINLINE static void Sort(const FSortingOption& SortingOption, TArray<const FCMSCharacterRow*>& RowList)
	{
		RowList.Sort(*GetOrdering(SortingOption.OrderType, SortingOption.Direction, INDEX_NONE));
	}

	FORCEINLINE static void Sort(const FSortingOption& SortingOption, TArray<const FCMSRelicRow*>& RowList)
	{
		RowList.Sort(*GetOrdering(SortingOption.OrderType, SortingOption.Direction, INDEX_NONE));
	}

	FORCEINLINE static void Sort(const FSortingOption& SortingOption, TArray<const FCMSSculptureRow*>& RowList)
	{
		RowList.Sort(*GetOrdering(SortingOption.OrderType, SortingOption.Direction, INDEX_NONE));
	}

	FORCEINLINE static void Sort(ESortMenu SortMenu, TArray<const FFriendInfoEx*>& FriendList, int32 JokerSlotIndex)
	{
		const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, ESortCategory::Friend);
		if (SortingOption.IsAttributeOrderType())
		{
			SetTotalAttributes(FriendList, JokerSlotIndex);
		}

		FriendList.Sort(*GetOrdering(SortingOption.OrderType, SortingOption.Direction, JokerSlotIndex));
	}

	FORCEINLINE static void Sort(const FSortingOption& SortingOption, TArray<const FCharacter*>& CharacterList)
	{
		if (SortingOption.IsAttributeOrderType())
		{
			SetCharacterAttributes(CharacterList);
		}

		CharacterList.Sort(*GetOrdering(SortingOption.OrderType, SortingOption.Direction, INDEX_NONE));
	}

	FORCEINLINE static void Sort(const FSortingOption& SortingOption, TArray<const FSculpture*>& FSculptureList)
	{
		if (SortingOption.IsAttributeOrderType())
		{
			SetSculptureAttributes(FSculptureList);
		}

		FSculptureList.Sort(*GetOrdering(SortingOption.OrderType, SortingOption.Direction, INDEX_NONE));
	}

	FORCEINLINE static void Sort(const FSortingOption& SortingOption, TArray<const FRelic*>& RelicList)
	{
		if (SortingOption.IsAttributeOrderType())
		{
			SetRelicAttributes(RelicList);
		}

		RelicList.Sort(*GetOrdering(SortingOption.OrderType, SortingOption.Direction, INDEX_NONE));
	}

private:
	FORCEINLINE static TUniquePtr<FOrderingBase> GetOrdering(ESortOrderType OrderType, ESortDirection Direction, int32 JokerSlotIndex)
	{
		switch (OrderType)
		{
			case ESortOrderType::LastLogin: return MakeUnique<FOrderByLastLogin>(Direction);
			case ESortOrderType::FriendLevel: return MakeUnique<FOrderByFriendLevel>(Direction);
			case ESortOrderType::Level: return MakeUnique<FOrderByLevel>(Direction, JokerSlotIndex);
			case ESortOrderType::Hp: return MakeUnique<FOrderByHp>(Direction);
			case ESortOrderType::Atk: return MakeUnique<FOrderByAtk>(Direction);
			case ESortOrderType::Def: return MakeUnique<FOrderByDef>(Direction);
			case ESortOrderType::Grade: return MakeUnique<FOrderByGrade>(Direction);
			case ESortOrderType::Name: return MakeUnique<FOrderByName>(Direction);
			case ESortOrderType::Nature: return MakeUnique<FOrderByNature>(Direction);
			case ESortOrderType::Created: return MakeUnique<FOrderByCreated>(Direction);
			case ESortOrderType::UltimateSkill: return MakeUnique<FOrderByUltimateSkill>(Direction);
			case ESortOrderType::Type: return MakeUnique<FOrderingTypeBase>(Direction);
		}
		ensure(false);
		return MakeUnique<FOrderingBase>(Direction);
	}

	static void SetTotalAttributes(const TArray<const FFriendInfoEx*>& FriendList, int32 JokerSlotIndex);
	static void SetTotalAttributes(UCMS* CMS, const FFriendInfoEx& FriendInfo, int32 JokerSlotIndex);

	static void SetCharacterAttributes(const TArray<const FCharacter*>& CharacterList);
	static void SetSculptureAttributes(const TArray<const FSculpture*>& SculptureList);
	static void SetRelicAttributes(const TArray<const FRelic*>& RelicList);
};


UCLASS()
class Q6_API USortingWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetSorting(ESortMenu InSortMenu, ESortCategory Category);

private:
	static const int32 MaxFilterCount = 5;

	UFUNCTION()
	void OnSortingChangeButtonClicked();

	UFUNCTION()
	void OnOrderToggleButtonClicked(bool bInChecked);

	void SetSortOrderTypeText(ESortOrderType OrderType);
	void SetSortDirectionText(ESortOrderType OrderType, ESortDirection Direction);

	UPROPERTY()
	UHorizontalBox* FilterBox;

	UPROPERTY()
	TArray<UImage*> FilterIcons;

	UPROPERTY()
	UTextBlock* OrderTypeText;

	UPROPERTY()
	UTextBlock* DirectionText;

	UPROPERTY()
	UCheckBox* SortDirectionButton;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> TierDotIconBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> NatureDotIconBrushes;

	ESortMenu SortMenu;
	ESortCategory Category;
};

UCLASS()
class Q6_API USortingChangePopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	USortingChangePopupWidget(const FObjectInitializer& ObjectInitializer)
		: Super(ObjectInitializer)
	{
	}

	virtual void NativeConstruct() override;
	void SetSortingOption(ESortMenu InSortMenu, ESortCategory InCategory);

protected:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option);

private:
	UFUNCTION()
	void OnResetButtonClicked();

	void OnOrderButtonClicked(ESortOrderType OrderType, UToggleButtonWidget* ButtonWidget);
	void OnFilterButtonClicked(int32 OptionValue);
	void OnXpCardToggleButtonClicked();

	void RefreshSortingOption(const FSortingOption& NewSortingOption);

	UPROPERTY()
	UDynamicListWidget* OrderListWidget;

	UPROPERTY()
	UDynamicListWidget* FilterListWidget;

	UPROPERTY()
	UToggleButtonWidget* XpCardButtonWidget;

	UPROPERTY()
	UCanvasPanel* FilterPanel;

	UPROPERTY()
	UCanvasPanel* ExpCardPanel;

	UPROPERTY(EditDefaultsOnly)
	TArray<FCheckBoxStyle> NatureFilterStyles;

	UPROPERTY(EditDefaultsOnly)
	TArray<FCheckBoxStyle> TierFilterStyles;

	FSortingOption SortingOption;
};
