#include "StageWidgets.h"

#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "PointWidgets.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "SagaManager.h"
#include "HUDStore/SpecialManager.h"
#include "HUDStore/BondManager.h"
#include "HUDStore/CharacterManager.h"
#include "HUDStore/UserRecordManager.h"
#include "HUDStore/CharMissionManager.h"
#include "HUDStore/TrainingCenterManager.h"
#include "Tutorial/LobbyTutorial.h"
#include "Unit.h"
#include "Q6SaveGame.h"
#include "HUDStore/EventManager.h"

UStageEnemyNaturesWidget::UStageEnemyNaturesWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UStageEnemyNaturesWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BossBorder = CastChecked<UBorder>(GetWidgetFromName("Boss"));
	BossNatureIcon = CastChecked<UImage>(GetWidgetFromName("BossNature"));

	FString WidgetName;
	for (int32 n = 1; n <= MAX_NUM_OF_NATURE; ++n)
	{
		WidgetName = FString::Printf(TEXT("Nature%d"), n);
		NatureIcons.AddUnique(CastChecked<UImage>(GetWidgetFromName(*WidgetName)));
	}
}

void UStageEnemyNaturesWidget::SetStage(const FCMSSagaRow& SagaRow)
{
	BossBorder->SetVisibility(ESlateVisibility::Collapsed);
	for (UImage* NatureIcon : NatureIcons)
	{
		NatureIcon->SetVisibility(ESlateVisibility::Collapsed);
	}

	const TArray<const FCMSWaveRow*>& Waves = SagaRow.GetWave();
	for (const FCMSWaveRow* Wave : Waves)
	{
		TArray<FUnitType> UnitTypes;
		for (int T : Wave->Spawns01)
		{
			UnitTypes.AddUnique(FUnitType(T));
		}
		for (int T : Wave->Spawns02)
		{
			UnitTypes.AddUnique(FUnitType(T));
		}
		for (int T : Wave->Spawns03)
		{
			UnitTypes.AddUnique(FUnitType(T));
		}

		for (const FUnitType& UnitType : UnitTypes)
		{
			if (UnitType <= UnitTypeInvalid)
			{
				continue;
			}

			const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(UnitType);
			if (UnitRow.IsInvalid())
			{
				continue;
			}

			if (NatureIcons.IsValidIndex((int32)UnitRow.NatureType))
			{
				NatureIcons[(int32)UnitRow.NatureType]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			}

			if (IsBossMonsterCategory(UnitRow.AttributeCategory))
			{
				BossNatureIcon->SetBrush(GetUIResource().GetNatureTypeIcon(UnitRow.NatureType));
				BossBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			}
		}
	}
}

UStageEntryWidget::UStageEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UStageEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SlotWattBorder = CastChecked<UBorder>(GetWidgetFromName("Slot_Watt"));

	WattWidget = CastChecked<UPointWidget>(GetWidgetFromName("SagaWattWidget"));
	WattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::LessEqual);

	StageStartButton = CastChecked<UButton>(GetWidgetFromName("BtnStageStart"));
	StageStartButton->OnClicked.AddUniqueDynamic(this, &UStageEntryWidget::OnStageStartButtonClicked);

	PlayDialogueButton = CastChecked<UButton>(GetWidgetFromName("BtnPlayStory"));
	PlayDialogueButton->OnClicked.AddUniqueDynamic(this, &UStageEntryWidget::OnPlayDialogueButtonClicked);

	LinkedImage = CastChecked<UImage>(GetWidgetFromName("LinkedIcon"));
	StageNaturesWidget = CastChecked<UStageEnemyNaturesWidget>(GetWidgetFromName("StageNatures"));
	ClearedCountText = CastChecked<UTextBlock>(GetWidgetFromName("ClearedCount"));
	ReplayLimitText = CastChecked<UTextBlock>(GetWidgetFromName("ReplayLimit"));
	InfinityImage = CastChecked<UImage>(GetWidgetFromName("Infinity"));
	TagStageTypeImage = CastChecked<UImage>(GetWidgetFromName("TagStageType"));
	ClearCountBox = CastChecked<UHorizontalBox>(GetWidgetFromName("ClearCount"));
	ReplayBorder = CastChecked<UBorder>(GetWidgetFromName("Replay"));

	RewardButton = CastChecked<UButton>(GetWidgetFromName("Reward"));
	RewardButton->OnClicked.AddUniqueDynamic(this, &UStageEntryWidget::OnRewardButtonClicked);

	StageNumText = CastChecked<UTextBlock>(GetWidgetFromName("TextStageNum"));
	StageNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextStageName"));
	RecommendLevelText = CastChecked<UTextBlock>(GetWidgetFromName("RecommendLevel"));
	InitialRewardBox = CastChecked<USizeBox>(GetWidgetFromName("BoxInitialReward"));
	InitialRewardIconWidget = CastChecked<UItemWidget>(GetWidgetFromName("InitialRewardIcon"));

	StageNumBox = CastChecked<UVerticalBox>(GetWidgetFromName("BoxStageNum"));
	StageText = CastChecked<UTextBlock>(GetWidgetFromName("TextStage"));
	StageIconBox = CastChecked<UVerticalBox>(GetWidgetFromName("BoxStageIcon"));
	MenuText = CastChecked<UTextBlock>(GetWidgetFromName("TextMenu"));
	StageIconImage = CastChecked<UImage>(GetWidgetFromName("StageIcon"));
	OpenConditionText = CastChecked<UTextBlock>(GetWidgetFromName("OpenCondition"));

	TagNewImage = CastChecked<UImage>(GetWidgetFromName("ImgTagNew"));
	TagClearImage = CastChecked<UImage>(GetWidgetFromName("ImgTagClear"));
	LockCanvasPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("LockPanel"));
	UnlockConditionText = CastChecked<UTextBlock>(GetWidgetFromName("UnlockCondition"));

	SetPlayableAnim = GetWidgetAnimationFromName(this, "AnimSetPlayable");
	SetDisableAnim = GetWidgetAnimationFromName(this, "AnimSetDisabled");
}

void UStageEntryWidget::SetDefaultEntryWidget(FSagaType InSagaType, EStageState InState)
{
	UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(InSagaType);
	Init(InSagaType, InState, SagaRow);

	// Set LootItem
	const TArray<const FCMSLootGroupRow*>& LootGroupRows = SagaRow.GetInitialLootGroup();
	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRows);

	if (LootDataRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UStageEntryWidget::SetDefaultEntryWidget - LootDataRow does not exist. ");
		return;
	}

	StageNumBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	StageIconBox->SetVisibility(ESlateVisibility::Collapsed);
	StageText->SetText(Q6Util::GetLocalizedText("Lobby", "Stage"));
	StageNumText->SetText(MakeStageNumberText(SagaRow));

	InitialRewardIconWidget->SetRewardType(ERewardType::First);
	InitialRewardIconWidget->SetLoot(LootDataRow.LootId, LootDataRow.Count);
	InitialRewardIconWidget->SetChecked(InState == EStageState::Normal);
	InitialRewardBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UStageEntryWidget::SetDailyEntryWidget(const FCMSDailyDungeonRow* InDailyDungeonRow, EStageState InState)
{
	UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSagaRow& SagaRow = InDailyDungeonRow->GetSaga();
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Error, "UStageEntryWidget::SetDailyEntryWidget - SagaRow does not exist.");
		check(false);
	}
	Init(SagaRow.CmsType(), InState, SagaRow);

	StageNumBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	StageIconBox->SetVisibility(ESlateVisibility::Collapsed);
	StageText->SetText(Q6Util::GetLocalizedText("Lobby", "Stage"));
	StageNumText->SetText(MakeStageNumberText(SagaRow));

	const FCMSLootDataRow& InitialLootRow = CMS->GetFirstLootDataOrDummyFromLootGroups(SagaRow.GetInitialLootGroup());
	if (!InitialLootRow.IsInvalid())
	{
		InitialRewardIconWidget->SetRewardType(ERewardType::First);
		InitialRewardIconWidget->SetLoot(InitialLootRow.LootId, InitialLootRow.Count);
		InitialRewardIconWidget->SetChecked(InState == EStageState::Normal);
		InitialRewardBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	if (InState == EStageState::LockedByCondition)
	{
		SetUnlockRank(InDailyDungeonRow->MinLevel);
	}
	else if (InState == EStageState::LockedByStage)
	{
		OpenConditionText->SetText(Q6Util::GetLocalizedText("Lobby", "PlayablePrevStage"));
	}

	SetClearCount(0, 0);
}

void UStageEntryWidget::SetTrainingEntryWidget(FTrainingCenterType InTrainingCenterType, FSagaType InSagaType, EStageState InState)
{
	TraingCenterType = InTrainingCenterType;

	SetDefaultEntryWidget(InSagaType, InState);
}

void UStageEntryWidget::SetSpecialEntryWidget(FSagaType InSagaType, EStageState InState, ESpecialCategory InSpceialCategory)
{
	UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(InSagaType);
	Init(InSagaType, InState, SagaRow);
	if (InState == EStageState::LockedByStage)
	{
		SetSpecialLockedReasonText(InSagaType);
	}

	// Set LootItem
	const TArray<const FCMSLootGroupRow*>& LootGroupRows = SagaRow.GetInitialLootGroup();
	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRows);

	if (LootDataRow.IsInvalid())
	{
		Q6JsonLogRoze(Warning, "UStageEntryWidget::SetSpecialEntryWidget - LootDataRow does not exist. ");
		return;
	}

	if (InSpceialCategory == ESpecialCategory::Saga)
	{
		StageNumBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		StageIconBox->SetVisibility(ESlateVisibility::Collapsed);

		StageText->SetText(Q6Util::GetLocalizedText("Lobby", "Episode"));

		const FCMSSpecialRow* SpecialRow = CMS->GetSpecialRow(InSpceialCategory, SagaRow.Episode);
		const FCMSSagaRow& SpecialSagaRow = CMS->GetSagaRowOrDummy(FSagaType(SpecialRow->ConditionId));
		StageNumText->SetText(FText::AsNumber(SpecialSagaRow.Episode));
	}
	else if (InSpceialCategory == ESpecialCategory::Character)
	{
		StageNumBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		StageIconBox->SetVisibility(ESlateVisibility::Collapsed);

		StageText->SetText(Q6Util::GetLocalizedText("Lobby", "Stage"));
		StageNumText->SetText(MakeStageNumberText(SagaRow));
	}
	else
	{
		StageNumBox->SetVisibility(ESlateVisibility::Collapsed);
		StageIconBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		StageText->SetText(Q6Util::GetLocalizedText("Lobby", "StageWonder"));

		if (LootDataRow.LootCategory == ELootCategory::Wonder)
		{
			// wonder menu open stage

			const FItemIcon& ItemIcon = GetUIResource().GetMenuOpenIcon();
			StageIconImage->SetBrush(ItemIcon.BigBrush);
		}
		else
		{
			StageIconImage->SetBrush(GetUIResource().GetSpecialStageIcon(InSpceialCategory));
		}
	}

	InitialRewardIconWidget->SetRewardType(ERewardType::First);
	InitialRewardIconWidget->SetLoot(LootDataRow.LootId, LootDataRow.Count);
	InitialRewardIconWidget->SetChecked(InState == EStageState::Normal);
	InitialRewardBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void UStageEntryWidget::SetEventEntryWidget(FEventContentType InEventContentType, int32 InEventStageType, FSagaType InSagaType, EStageState InState, int64 InUnlockTime)
{
	EventContentType = InEventContentType;
	EventStageType = InEventStageType;

	SetDefaultEntryWidget(InSagaType, InState);

	if (InState == EStageState::LockedByCondition)
	{
		SetUnlockTime(InUnlockTime);
	}
}

void UStageEntryWidget::SetHasLinkedStage(bool bInHasNext)
{
	LinkedImage->SetVisibility(bInHasNext ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UStageEntryWidget::SetClearCount(int32 ClearedCount, int32 ReplayLimit)
{
	if (ReplayLimit <= 0)
	{
		InfinityImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		ClearCountBox->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	if (ReplayLimit == 1)
	{
		ClearCountBox->SetVisibility(ESlateVisibility::Collapsed);
		InfinityImage->SetVisibility(ESlateVisibility::Collapsed);
		ReplayBorder->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	ClearCountBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	InfinityImage->SetVisibility(ESlateVisibility::Collapsed);

	ClearedCountText->SetText(FText::AsNumber(ClearedCount));
	ReplayLimitText->SetText(FText::AsNumber(ReplayLimit));
}

void UStageEntryWidget::SetClearCountVisible(bool bInVisible)
{
	ReplayBorder->SetVisibility(bInVisible ?
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UStageEntryWidget::SetOpenConditionText(const TArray<const FCMSSagaRow*>& SagaRows)
{
	if (SagaRows.Num() <= 0)
	{
		OpenConditionText->SetText(FText::GetEmpty());
		return;
	}

	OpenConditionText->SetText(
		FText::Format(Q6Util::GetLocalizedText("Lobby", "StageLockInfo"), SagaRows[0]->DescName));
}

void UStageEntryWidget::SetStageState(EStageState InStageState)
{
	StageState = InStageState;

	bool bPlayable = false;
	switch (StageState)
	{
		case EStageState::New:
			UnlockConditionText->SetVisibility(ESlateVisibility::Collapsed);
			LockCanvasPanel->SetVisibility(ESlateVisibility::Collapsed);

			TagNewImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			TagClearImage->SetVisibility(ESlateVisibility::Collapsed);

			bPlayable = true;
			break;
		case EStageState::Normal:
			UnlockConditionText->SetVisibility(ESlateVisibility::Collapsed);
			LockCanvasPanel->SetVisibility(ESlateVisibility::Collapsed);

			TagNewImage->SetVisibility(ESlateVisibility::Collapsed);
			TagClearImage->SetVisibility(ESlateVisibility::Collapsed);

			bPlayable = true;
			break;
		case EStageState::LockedByCondition:
			UnlockConditionText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			LockCanvasPanel->SetVisibility(ESlateVisibility::Collapsed);

			TagNewImage->SetVisibility(ESlateVisibility::Collapsed);
			TagClearImage->SetVisibility(ESlateVisibility::Collapsed);
			break;
		case EStageState::LockedByStage:
			UnlockConditionText->SetVisibility(ESlateVisibility::Collapsed);
			LockCanvasPanel->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

			TagNewImage->SetVisibility(ESlateVisibility::Collapsed);
			TagClearImage->SetVisibility(ESlateVisibility::Collapsed);
			break;
		case EStageState::Clear:
			UnlockConditionText->SetVisibility(ESlateVisibility::Collapsed);
			LockCanvasPanel->SetVisibility(ESlateVisibility::Collapsed);

			TagNewImage->SetVisibility(ESlateVisibility::Collapsed);
			TagClearImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			break;
		default:
			Q6JsonLogGunny(Warning, "UStageEntryWidget::SetStageState - Wrong StageState", Q6KV("StageState", static_cast<int>(StageState)));
			return;
	}

	PlayAnimation(bPlayable ? SetPlayableAnim : SetDisableAnim);
}

bool UStageEntryWidget::IsSpecialBossStage(const FCMSSagaRow& SagaRow)
{
	if (SagaRow.ContentType != EContentType::Special)
	{
		return false;
	}

	ESpecialCategory Category = ESpecialCategory::None;
	Category = GetHUDStore().GetSpecialManager().GetSpecialCategory(SagaRow.Episode);

	return (Category == ESpecialCategory::Saga);
}

bool UStageEntryWidget::ShouldPlayDialogue(const FCMSSagaRow& SagaRow)
{
	bool bOk = false;

	switch (SagaRow.ContentType)
	{
		case EContentType::Saga:
		case EContentType::Event:
		case EContentType::MultiSideBattle:
			bOk = (SagaRow.StageType != EStageType::Battle);
			break;
		case EContentType::RaidFinal:
			bOk = !IsStoryLikeStageType(SagaRow.StageType);
			break;
		case EContentType::Special:
			if (SagaRow.StageType != EStageType::Battle)
			{
				const USpecialManager& SpecialManager = GetHUDStore().GetSpecialManager();
				ESpecialCategory Category = SpecialManager.GetSpecialCategory(SagaRow.Episode);
				if (Category == ESpecialCategory::Saga)
				{
					if (UQ6SaveGame* SaveGameInstance = UQ6GameInstance::Get(this)->GetSaveGame())
					{
						bOk = SaveGameInstance->IsFirstBossStage(SagaRow.Type);
					}
				}
				else
				{
					bOk = true;
				}
			}
			break;
		case EContentType::TrainingCenter:
			if (GetHUDStore().GetTrainingCenterManager().IsFirstSagaOnStep(SagaType))
			{
				bOk = !IsStoryLikeStageType(SagaRow.StageType);
			}
			break;
	}

	return bOk;
}

void UStageEntryWidget::SetUnlockRank(int32 InUnlockRank)
{
	UnlockConditionText->SetText(
		FText::Format(
			Q6Util::GetLocalizedText("Lobby", "PlayableAtRank"),
			FText::AsNumber(InUnlockRank))
	);
}

void UStageEntryWidget::SetUnlockTime(int64 InUnlockTime)
{
	UnlockConditionText->SetText(
		FText::Format(
			Q6Util::GetLocalizedText("Lobby", "PlayableAtPeriod"),
			Q6Util::GetLocalDateText(InUnlockTime)));
}

void UStageEntryWidget::SetSpecialLockedReasonText(FSagaType InSagaType)
{
	const UCMS* CMS = GetCMS();
	TArray<const FCMSSagaRow*> PrevSagaRows = CMS->GetPrevSpecialSagaRows(InSagaType);
	const UHUDStore& HUDStore = GetHUDStore();
	if (!HUDStore.GetSpecialManager().IsClearedPrevSpecials(PrevSagaRows))
	{
		SetOpenConditionText(PrevSagaRows);
		return;
	}

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(InSagaType);
	const TArray<const FCMSSagaPlayConditionRow*>& ConditionSagaRows = SagaRow.GetSagaPlayCondition();

	const UCharacterManager& CharacterManager = HUDStore.GetCharacterManager();
	const UBondManager& BondManager = HUDStore.GetBondManager();
	const UCharMissionManager& CharMissionManager = HUDStore.GetCharMissionManager();

	for (const FCMSSagaPlayConditionRow* Iter : ConditionSagaRows)
	{
		FCharacterType CharacterType = FCharacterType(Iter->ConditionId);

		switch (Iter->ConditionType)
		{
			case EPlayConditionType::CharacterLevel:
			{
				const FCharacter* Character = CharacterManager.GetHighestLevelCharacter(CharacterType);
				const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterType);

				if (!Character || (Character->GetInfo().Level < Iter->ConditionValue))
				{
					OpenConditionText->SetText(
						FText::Format(
							Q6Util::GetLocalizedText("Lobby", "StageLockLevel"), CharacterRow.GetUnit().DescName, Iter->ConditionValue));

					return;
				}

				break;
			}
			case EPlayConditionType::CharacterBondLevel:
			{
				const FCharacterBond* CharacterBond = BondManager.Find(CharacterType);
				const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterType);

				if (!CharacterBond || (CharacterBond->Level < Iter->ConditionValue))
				{
					OpenConditionText->SetText(
						FText::Format(
							Q6Util::GetLocalizedText("Lobby", "StageLockBondLevel"), CharacterRow.GetUnit().DescName, Iter->ConditionValue * 5));

					return;
				}

				break;
			}
			case EPlayConditionType::CharacterMissionSetClear:
			{
				const FCharMissionInfo* CharMissionInfo = CharMissionManager.GetCharMissionByCharacterType(CharacterType);
				const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterType);

				if (!CharMissionInfo)
				{
					OpenConditionText->SetText(
						FText::Format(
							Q6Util::GetLocalizedText("Lobby", "StageLockCharMission"), CharacterRow.GetUnit().DescName, Iter->ConditionValue));

					return;
				}

				int32 NumOfCleared = 0;
				for (int i = 0; i < MAX_CHAR_MISSION; ++i)
				{
					if (!CharMissionInfo->RUtc.IsValidIndex(i))
					{
						continue;
					}

					if (CharMissionInfo->RUtc[i] != 0)
					{
						NumOfCleared++;
					}
				}

				if (!(Iter->ConditionValue == NumOfCleared || NumOfCleared == MAX_CHAR_MISSION))
				{
					OpenConditionText->SetText(
						FText::Format(
							Q6Util::GetLocalizedText("Lobby", "StageLockCharMission"), CharacterRow.GetUnit().DescName, Iter->ConditionValue));

					return;
				}

				break;
			}
			case EPlayConditionType::UserRecord:
			{
				// TODO
				break;
			}
			default:
				break;
		}
	}

	OpenConditionText->SetText(FText::GetEmpty());
}

void UStageEntryWidget::OnStageStartButtonClicked()
{
	FString TutorialStr = FString::Printf(TEXT("SagaStageStart_%d"), SagaType.x);
	TUTORIAL_MONITORING_BUTTON_CLICK(TutorialStr);

	if (StageState == EStageState::Clear)
	{
#if !UE_BUILD_SHIPPING
		if (!UQ6GameInstance::Get(this)->IsDevMode())
		{
			return;
		}
#else
		return;
#endif
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType == EContentType::MultiSideBattle)
	{
		int32 CurrentWatt = 0;
		const UEventManager& EventManager = GetHUDStore().GetEventManager();
		const FEventContentInfo* EventContentInfo = EventManager.GetEvent(EventContentType);
		if (EventContentInfo)
		{
			CurrentWatt = EventContentInfo->WattInfo.Watt;
		}

  		if (CurrentWatt < WattWidget->GetCurPoint())
  		{
			GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "NotEnoughEventWatt"));
  			return;
  		}
	}
	else
	{
		int32 CurrentWatt = GetHUDStore().GetWorldUser().GetWatt();
		if (CurrentWatt < WattWidget->GetCurPoint())
		{
			GetCheckedLobbyHUD(this)->OpenWattRechargePopup();
			return;
		}
	}

	if (GetCheckedLobbyHUD(this)->CheckMaxItemNum(ECurrencyCheckType::Saga, true))
	{
		return;
	}

	UQ6GameInstance::Get(this)->ClearBanIndices();

	if (ShouldPlayDialogue(SagaRow))
	{
		if (IsStoryLikeStageType(SagaRow.StageType))
		{
			static const FText TitleText = Q6Util::GetLocalizedText("Lobby", "StagePlayTitle");
			static const FText ContentText = Q6Util::GetLocalizedText("Lobby", "InfoNotBattle");

			UPlayNotifyPopupWidget* Popup = GetBaseHUD(this)->OpenPlayNotifyPopup(TitleText, SagaRow.DescName, ContentText);
			Popup->OnPopupDelegate.BindUObject(this, &UStageEntryWidget::OnPlayNotifyPopupConfirm);
		}
		else
		{
			if (IsSpecialBossStage(SagaRow))
			{
				if (UQ6SaveGame* SaveGameInstance = UQ6GameInstance::Get(this)->GetSaveGame())
				{
					SaveGameInstance->AddUniqueBossStage(SagaRow.Type);
				}
			}

			OnPlayDialogue(SagaRow, false);
		}
	}
	else
	{
		if (EventContentType != EventContentTypeInvalid)
		{
			if (GetHUDStore().GetEventManager().IsExpired(EventContentType))
			{
				GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "PeriodExpiredToast"));
				return;
			}
		}

		if (SagaRow.ContentType == EContentType::MultiSideBattle)
		{
			ACTION_DISPATCH_PartyMain(SagaType);
			ACTION_DISPATCH_PartyEventContentType(EventContentType);
			GetCheckedLobbyHUD(this)->ChangeHUDType(EHUDWidgetType::Party, true);
		}
		else
		{
			ACTION_DISPATCH_JokerSelect(SagaType, true);
			GetCheckedLobbyHUD(this)->ChangeHUDType(EHUDWidgetType::JokerSelect, true);
		}
	}
}

void UStageEntryWidget::OnPlayDialogueButtonClicked()
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	OnPlayDialogue(SagaRow, true);
}

void UStageEntryWidget::OnPlayDialogue(const FCMSSagaRow& SagaRow, bool bReplay)
{
	ALobbyHUD* LobbyHUD = GetCheckedLobbyHUD(this);

	switch (SagaRow.ContentType)
	{
		case EContentType::TrainingCenter:
			LobbyHUD->PlayTraining(TraingCenterType, SagaType, true, bReplay);
			break;
		case EContentType::Event:
			LobbyHUD->PlayValentineDayEventWithStoryClear(FEventContentValentineDayType(EventStageType), true, bReplay);
			break;
		case EContentType::MultiSideBattle:
			LobbyHUD->PlayMultisideBattleWithStoryClear(FEventContentMultiSideBattleStageType(EventStageType), true, bReplay);
			break;
		default:
			LobbyHUD->PlaySagaWithStoryClear(SagaType, true, bReplay);
			break;
	}
}

void UStageEntryWidget::OnRewardButtonClicked()
{
	if (!GetLobbyTutorial(this)->CanWatchRewards())
	{
		return;
	}

	// hiding reward's count & deduplication reward items on stage entry widget
	const bool bVisibleCount = false;
	const bool bAllowDuplicated = false;
	const UCMS* CMS = GetCMS();
	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType == EContentType::Event || SagaRow.ContentType == EContentType::MultiSideBattle)
	{
		GetCheckedLobbyHUD(this)->OpenItemRewardPopup(EventContentType, SagaType, bVisibleCount, bAllowDuplicated);
	}
	else
	{
		GetCheckedLobbyHUD(this)->OpenItemRewardPopup(SagaType, bVisibleCount, bAllowDuplicated);
	}
}

void UStageEntryWidget::OnPlayNotifyPopupConfirm(EConfirmPopupFlag Flag)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	TUTORIAL_MONITORING_BUTTON_CLICK("StageStart_PlayDialogue");

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);

	OnPlayDialogue(SagaRow, false);
}

void UStageEntryWidget::Init(FSagaType InSagaType, EStageState InState, const FCMSSagaRow& SagaRow)
{
	SagaType = InSagaType;

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	if (SagaRow.ContentType == EContentType::MultiSideBattle)
	{
		const UCMS* CMS = GetCMS();
		const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(EventContentType);
		const UEventManager& EventManager = GetHUDStore().GetEventManager();
		const FEventContentInfo* EventContentInfo = EventManager.GetEvent(EventContentType);
		if (EventContentInfo)
		{
			WattWidget->SetEventWattType(EventContentRow.Category, EPointWidgetOption::LessEqual);
		}

		WattWidget->SetPoint(SagaRow.WattConsume, EventContentInfo->WattInfo.Watt);
	}
	else
	{
		WattWidget->SetPoint(SagaRow.WattConsume, WorldUser.GetWatt());
	}

	StageNaturesWidget->SetStage(SagaRow);

	if (SagaRow.StageType == EStageType::Normal)
	{
		TagStageTypeImage->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		EStageType StageIconType = SagaRow.StageType;
		if (IsStoryLikeStageType(StageIconType))
		{
			StageIconType = EStageType::Story;
		}

		TagStageTypeImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		TagStageTypeImage->SetBrush(GetUIResource().GetStageTypeBrush(StageIconType));
	}

	ESlateVisibility PlayDialogueVisibility = ESlateVisibility::Collapsed;

	if (SagaRow.ContentType == EContentType::Saga || SagaRow.ContentType == EContentType::Special)
	{
		if (InState == EStageState::Clear && SagaRow.StageType != EStageType::Battle)
		{
			if (GetCheckedLobbyHUD(this)->HasPlayableDialogue(SagaType))
			{
				PlayDialogueVisibility = ESlateVisibility::Visible;
			}
		}
	}

	PlayDialogueButton->SetVisibility(PlayDialogueVisibility);

	StageNameText->SetText(SagaRow.DescName);
	RecommendLevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(SagaRow.RecommendLevel)));

	// Set Initial reward item
	InitialRewardBox->SetVisibility(ESlateVisibility::Collapsed);

	SetStageState(InState);

	bool bShowLootItem = true;
	switch (InState)
	{
		case EStageState::New:
		case EStageState::Normal:	// fall through
		{
			const TArray<const FCMSLootGroupRow*>& LootRows = SagaRow.GetLootGroup();
			bShowLootItem = LootRows.Num() != 0;
			break;
		}
		case EStageState::LockedByStage:
		case EStageState::Clear:
		case EStageState::LockedByCondition:	// fall through
			bShowLootItem = false;
			break;
	}
	RewardButton->SetVisibility(bShowLootItem ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);

	if (SagaRow.WattConsume > 0)
	{
		SlotWattBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		SlotWattBorder->SetVisibility(ESlateVisibility::Collapsed);
	}
}

UStageListWidget::UStageListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UStageListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EpisodeReward = CastChecked<UItemWidget>(GetWidgetFromName("EpisodeClearReward"));
	EpisodeReward->SetVisibility(ESlateVisibility::Collapsed);

	GridPanel = CastChecked<UUniformGridPanel>(GetWidgetFromName("StageList"));
	GridPanel->ClearChildren();

	StageListScrollBox = CastChecked<UScrollBox>(GetWidgetFromName("StageListScroll"));

	CharacterIcon  = CastChecked<UImage>(GetWidgetFromName("Character"));
	CharacterStory = CastChecked<UTextBlock>(GetWidgetFromName("EpisodeCharacterStory"));
}

void UStageListWidget::InitStageList(int32 Episode)
{
	const FEpisodeAssetRow& EpisodeRow = GetGameResource().GetEpisodeAssetRow(Episode);
	CharacterIcon->SetBrush(EpisodeRow.CharacterIcon);
	CharacterStory->SetText(EpisodeRow.CharacterStory);

	GridPanel->ClearChildren();

	UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSLootDataRow LootDataRow = CMS->GetEpisodeClearRewardByEpisode(Episode);
	if (!LootDataRow.IsInvalid())
	{
		EpisodeReward->SetRewardType(ERewardType::EpisodeClearReward);
		EpisodeReward->SetLoot(LootDataRow.LootId, LootDataRow.Count);
		EpisodeReward->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		EpisodeReward->SetChecked(GetHUDStore().GetSagaManager().IsEpisodeCleared(Episode));
	}

	int32 LastEpisode = 0;
	const FSagaType LastSagaType = GetHUDStore().GetSagaManager().GetLastSagaType();
	if (LastSagaType != SagaTypeInvalid)
	{
		LastEpisode = CMS->GetSagaRowOrDummy(LastSagaType).Episode;
	}

	TArray<const FCMSSagaRow*> Stages = CMS->GetStageRows(EContentType::Saga, Episode);
	if (LastEpisode > Episode)
	{
		int32 EntryIndex = 0;

		for (int32 i = Stages.Num() - 1; i >= 0; --i)
		{
			const FCMSSagaRow* SagaRow = Stages[i];
			if (SagaRow->StageType == EStageType::Battle)
			{
#if !UE_BUILD_SHIPPING
				if (!UQ6GameInstance::Get(this)->IsDevMode())
				{
					continue;
				}
#else
				continue;
#endif
			}

			UStageEntryWidget* StageEntryWidget = FindOrAddStageEntry(EntryIndex++);
			StageEntryWidget->SetDefaultEntryWidget(SagaRow->CmsType(), EStageState::Clear);
			StageEntryWidget->SetClearCountVisible(false);
			StageEntryWidget->SetHasLinkedStage(i > 0);
		}
	}
	else
	{
		FSagaType NewStage = LastSagaType;

		for (const FCMSSagaRow* SagaRow : Stages)
		{
			if (SagaRow->CmsType() > LastSagaType)
			{
				NewStage = SagaRow->CmsType();
				break;
			}
		}

		int32 EntryIndex = 0;

		for (int32 i = Stages.Num() - 1; i >= 0; --i)
		{
			const FCMSSagaRow* SagaRow = Stages[i];

			FSagaType SagaType = SagaRow->CmsType();
			if (SagaType > NewStage)
			{
				continue;
			}

			EStageState StageState = (SagaType > LastSagaType) ? EStageState::New : EStageState::Clear;
			if (StageState == EStageState::Clear && SagaRow->StageType == EStageType::Battle)
			{
#if !UE_BUILD_SHIPPING
				if (!UQ6GameInstance::Get(this)->IsDevMode())
				{
					continue;
				}
#else
				continue;
#endif
			}

			UStageEntryWidget* StageEntryWidget = FindOrAddStageEntry(EntryIndex++);
			StageEntryWidget->SetDefaultEntryWidget(SagaType, StageState);
			StageEntryWidget->SetClearCountVisible(false);
			StageEntryWidget->SetHasLinkedStage(i > 0);
		}
	}

	StageListScrollBox->FreezeScroll(GetLobbyTutorial(this)->IsInLobbyTutorial());
}

UStageEntryWidget* UStageListWidget::FindOrAddStageEntry(int32 StageIdx)
{
	UStageEntryWidget* EntryWidget = Cast<UStageEntryWidget>(GridPanel->GetChildAt(StageIdx));
	if (EntryWidget)
	{
		return EntryWidget;
	}

	// Create new entry
	EntryWidget = CreateWidget<UStageEntryWidget>(GetOwningPlayer(), StageIconClass);
	check(EntryWidget);

	UUniformGridSlot* PanelSlot = GridPanel->AddChildToUniformGrid(EntryWidget);
	check(PanelSlot);

	PanelSlot->SetRow(StageIdx);
	PanelSlot->SetColumn(0);
	PanelSlot->SetVerticalAlignment(VAlign_Center);
	PanelSlot->SetHorizontalAlignment(HAlign_Center);

	return EntryWidget;
}
