#pragma once

#include "Q6Minimal.h"
#include "CMSType_gen.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6Enum.h"
#include "Q6UIDefine.h"
#include "TrainingCenterWidget.generated.h"

static const int32 MAX_PLAYABLE_STEP_COUNT = 5;

enum class EStageState : uint8;

class UItemWidget;
class UDynamicListWidget;
class UQ6Button;

UCLASS()
class UTrainingStepWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetInfo(const FTrainingCenterType& TrainingCenterType);

protected:

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6")
	void SetInfoIntenal(ETrainingStepState InStep);

private:

	UPROPERTY()
	UTextBlock* StepText;

	UPROPERTY()
	UItemWidget* ItemWidget;
};

UCLASS()
class UTrainingCenterWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()
public:
	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::TrainingCenter; }

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void InitInfo();
	void SetInfo(const FTrainingCenterType InType);
	void SetStageList();
	void AddStageList(FSagaType InSagaType, EStageState InState, bool bHasLinkedStage);

	void SetPortrait();
	void SetTitle();
	void SetSteps();

#if !UE_BUILD_SHIPPING
	void SetStepChangeButtonEnables();
	void OnStepChangeButtonClicked(bool bNext);
#endif

	UPROPERTY()
	UQ6Button* PrevButton;

	UPROPERTY()
	UQ6Button* NextButton;

	UPROPERTY(Transient)
	UWidgetAnimation* SetJokerAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetRandomAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DefaultPlayAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DefaultClearAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LastPlayAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* LastClearAnim;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UTextBlock* PeriodText;

	UPROPERTY()
	UDynamicListWidget* StageListWidget;

	UPROPERTY()
	TArray<UTrainingStepWidget*> Steps;

	FTrainingCenterType CurrentType;
};
