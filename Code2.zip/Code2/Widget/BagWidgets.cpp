// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "BagWidgets.h"

#include "CommonWidgets.h"
#include "GameResource.h"
#include "ItemWidgets.h"
#include "Q6.h"
#include "HUDStore/Q6Account.h"
#include "HUDStore/BagItemManager.h"
#include "HUDStore/EventManager.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Bag"), STAT_OnHSEventByBag, STATGROUP_HSTORE);

/**
 * UBagItemEntryWidget
 */
void UBagItemEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
	ItemWidget->OnItemClicked.BindUObject(ItemWidget, &UItemWidget::OpenItemDetail);

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	OwnedAmountText = CastChecked<UTextBlock>(GetWidgetFromName("OwnedAmount"));

	//Roze-TODO: Event item wasn't implemented yet
	TimeLeftText = CastChecked<UTextBlock>(GetWidgetFromName("TimeLeft"));
}

void UBagItemEntryWidget::SetPoint(EPointType PointType, int32 Amount)
{
	const FPointIcon& PointIcon = GetUIResource().GetPointIcon(PointType);
	ItemWidget->SetPoint(PointType);
	ItemWidget->SetVisibleCount(false);

	FText PointText = Q6Util::GetPointText(PointType);
	NameText->SetText(PointText);

	TimeLeftText->SetVisibility(ESlateVisibility::Collapsed);
	OwnedAmountText->SetText(FText::AsNumber(Amount));
}

void UBagItemEntryWidget::SetBagItem(FBagItemType BagItemType, int32 Amount)
{
	const FBagItemAssetRow& AssetRow = GetGameResource().GetBagItemAssetRow(BagItemType);
	ItemWidget->SetBagItem(BagItemType);
	ItemWidget->SetVisibleCount(false);

	const FCMSBagItemRow& BagItemRow = GetCMS()->GetBagItemRowOrDummy(BagItemType);
	NameText->SetText(BagItemRow.DescName);

	TimeLeftText->SetVisibility(ESlateVisibility::Collapsed);
	OwnedAmountText->SetText(FText::AsNumber(Amount));
}

void UBagItemEntryWidget::SetEventPoint(FEventContentType EventContentType, int32 PointIndex, int32 Amount)
{
	const UCMS* CMS = GetCMS();
	const FCMSCurrencyPointRow* CurrencyPointRow = CMS->GetEventCurrencyPointRow(EventContentType, PointIndex);
	if (!CurrencyPointRow)
	{
		Q6JsonLogRoze(Error, "UBagItemEntryWidget::SetEventPoint - Not found curreny point row",
			Q6KV("EventContentType", EventContentType), Q6KV("PointIndex", PointIndex));
		return;
	}

	NameText->SetText(CurrencyPointRow->DescName);

	const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(EventContentType);
	const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(EventContentRow.EventSchedule);
	if (!ScheduleInfo)
	{
		Q6JsonLogGunny(Warning, "UItemWidget::SetEventPoint - ScheduleInfo does not exist. ",
			Q6KV("EventScheduleId", EventContentRow.EventSchedule));
		return;
	}
	
	TimeLeftText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	TimeLeftText->SetText(Q6Util::GetRemainTimeText(Q6Util::GetRemainDetailTime(ScheduleInfo->EndDate).GetTotalSeconds()));
	OwnedAmountText->SetText(FText::AsNumber(Amount));
	ItemWidget->SetEventPoint(EventContentType, PointIndex);
	ItemWidget->SetVisibleCount(false);
}

/**
 * UBagWidget
 */
UBagWidget::UBagWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UBagWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BagItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("BagItemList"));
}

void UBagWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::BagItem);
	SubscribeToStore(EHSType::Ui);
	//Roze-TODO: No spec
//	SubscribeToStore(EHSType::NewMark);

	BagItemListWidget->ClearList();

	ACTION_DISPATCH_BagItemSort();
}

void UBagWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByBag);

	if (Action->GetActionType() != EHSActionType::BagItemSort)
	{
		return;
	}

	SetItemList();
}

void UBagWidget::SetItemList()
{
	BagItemListWidget->ClearList();
	const UHUDStore& HUDStore = GetHUDStore();

	// Add currency list

	const UWorldUser& WorldUser = HUDStore.GetWorldUser();

	TArray<EPointType> PointTypes = { EPointType::AnyGem, EPointType::Lumicube, EPointType::CharacterDisk, EPointType::SculptureDisk,
		EPointType::RelicDisk, EPointType::SummonTicket, EPointType::SmallBattery, EPointType::MediumBattery, EPointType::LargeBattery };
	for (int32 i = 0; i < PointTypes.Num(); ++i)
	{
		const int32 PointAmount = WorldUser.GetPoint(PointTypes[i]);
		if (PointAmount <= 0)
		{
			continue;
		}

		UBagItemEntryWidget* EntryWidget = CastChecked<UBagItemEntryWidget>(BagItemListWidget->AddChildAtLastIndex());
		EntryWidget->SetPoint(PointTypes[i], PointAmount);
	}

	// Add bag item list

	const UCMS* CMS = GetCMS();
	const TMap<int64, FBagItem>& BagItems = HUDStore.GetBagItemManager().GetBagItems();
	for (const auto& Elem : BagItems)
	{
		const FBagItemInfo& BagItemInfo = Elem.Value.GetInfo();

		UBagItemEntryWidget* EntryWidget = CastChecked<UBagItemEntryWidget>(BagItemListWidget->AddChildAtLastIndex());
		EntryWidget->SetBagItem(BagItemInfo.Type, BagItemInfo.StackSize);
	}

	// Add event point list
	const UEventManager& EventManager = HUDStore.GetEventManager();
	const TMap<FEventContentType, FEventContentInfo>& Events = EventManager.GetEvents();

	for (const auto& Iter : Events)
	{
		const TArray<int32> Points = EventManager.GetEventPoint(Iter.Key);

		// Points ( 1-based)
		for (int i = 1; i < Points.Num(); ++i)
		{
			if (Points[i] != 0)
			{
				UBagItemEntryWidget* EntryWidget = CastChecked<UBagItemEntryWidget>(BagItemListWidget->AddChildAtLastIndex());
				EntryWidget->SetEventPoint(Iter.Key, i, Points[i]);
			}
		}
	}
}
