// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"
#include "BaseWidget.h"
#include "PopupWidgets.h"
#include "CCEvent.h"
#include "Q6Define.h"
#include "CombatHUDWidget.generated.h"

class UBonusRewardMarkListWidget;
class ACombatPresenter;
class AUnit;
class UCombatWonderSkillUsePopupWidget;
class UCombatDetailPopupWidget;
class UCombatUnitBarWidget;
class UCombatAllyBarWidget;
class UCombatEnemyBarWidget;
class UCombatTurnSkillWidget;
class UCombatBuffNoticeWidget;
class UCombatPetButtonWidget;
class UCombatSkillCastingNameWidget;
class UCombatSkillFailedWidget;
class UCombatCharacterDetailWidget;
class UCombatResultWidget;
class UCombatWaveWidget;
class UCombatTurnPhaseWidget;
class UCombatAttackButtonWidget;
class UCombatTotalDamageWidget;
class UCombatChainEffectWidget;
class URaidAssistTurnWidget;
class URaidTotalBarWidget;
class URaidRankingWidget;
class UCombatTimeWidget;
class URaidEmoticonWidget;
class UCombatMenuWidget;
class UBackTurnButtonWidget;
class UWaveTurnInfoWidget;

struct FUnitState;

/**
* Combat HUD Widget
*/
UCLASS()
class Q6_API UCombatHUDWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UCombatHUDWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SynchronizeCCState(const FCCCombatCubeState& InState);
	void PostSynchronizeCCState();

	// Combat HUD Events
	void OnUltimateSkillSequenceStarted();
	void OnUltimateSkillIllustAnimStarted();
	void OnUltimateSkillSequenceFinished();

	// Combat Presenter Events
	void OnReportError(const UCCReportErrorEvent* Event);

	void OnStartGame(const UCCStartGameEvent* Event);
	void OnStartWave(const UCCStartWaveEvent* Event);
	void OnTakeTurn(const UCCTakeTurnEvent* Event);
	void OnStartTurn(const UCCStartTurnEvent* Event);
	void OnStartPhase(const UCCStartPhaseEvent* Event);
	void OnStartCPPhase(ECPTurnPhase CPPhase);
	void OnSpawnUnit(const UCCSpawnUnitEvent* Event);
	void OnDespawnUnit(const UCCDespawnUnitEvent* Event);
	void OnFinishWave();
	void OnAllyWipeout(const UCCAllyWipeoutEvent* Event);
	void OnEndGame(const UCCEndGameEvent* Event);

	void OnSkillUsed(const UCCSkillUsedEvent* Event);
	void OnSkillFailed(const UCCSkillFailedEvent* Event);
	void OnSkillStart(const UCCSkillUsedEvent* Event);
	void OnSkillEnd(FCCUnitId InUnitId, ESkillCategory SkillCategory, bool bInPattern);
	void OnSkillDrivenEffectEnd();

	void OnHealthChanged(const UCCUnitHealthChangedEvent* Event);
	void OnHit(const UUnitHit* HitPerUnit, bool bDamage, bool bShieldDamage, bool bPassOverTotal);
	void OnUAChanged(const UCCUnitUAChangedEvent* Event);
	void OnSAChanged(const UCCUnitSAChangedEvent* Event);
	void OnSetSkillCooldown(const UCCSetSkillTimeEvent* Event);
	void OnSetCheatSkillCooldown(const UCCSetCheatSkillCooldownEvent* Event);
	void OnCreateBuff(const UCCCreateBuffEvent* Event, bool bSkipNoti);

	void OnRemoveBuff(const UCCRemoveBuffEvent* Event, const FBuffType& BuffType);
	void OnDead(FCCUnitId UnitId);

	void OnEnemyUltimateReady(const AUnit* EnemyUnit);
	void OnStartTurnSkillPhase(const TArray<FCCUnitId>& SkipSetCooldownEnemyIds);

	void OnSelectTarget(const FCCUnitId UnitId);
	void OnOverKillChanged(const UCCUnitOverKillChangedEvent* Event);
	void OnPhasePass(FCCUnitId UnitId);

	void OnRaidTurnSkillEffect(const UCCRaidTurnSkillEffectEvent* Event);

	void ResetAttackOrder() { AttackOrder = 1; }
	bool IsAllyAttackFinished() const;

	void SetupUnitBarOnSpawn(const FUnitState& UnitState, ESpawnReason InSpawnReason);

	int32 GetSelectedTurnSkillIndex() const { return SelectedTurnSkillIndex; }
	void SetAllyTurnSkillPhaseSelectable(bool bInSelectable);
	void PickFirstAliveAlly();

	void ResetTotalDamage();
	void ClearPointVaryUnitAttributes(FCCUnitId InUnitId);
	void AddOverKill(FCCUnitId InUnitId, int32 InValue);

	void RefreshEnemyUltimateSkills(FCCUnitId InUnitId);
	void WarningPatternUltimate(const UCCSelectedPatternUltimate* Event);

	bool IsShowProvokedEnemyBar() const { return bShowProvokedEnemyBar; }
	void SelectTarget(FCCUnitId InUnitId);

	FSimpleDelegate OnSkillStartAnimFinishedDelegate;
	FSimpleDelegate OnSpawnAnimFinishedDelegate;
	FSimpleDelegate OnWidgetAnimFinishedDelegate;
	FSimpleDelegate OnStartTurnPhaseAnimFinishedDelegate;
	FSimpleDelegate OnEnemyUltimateReadyAnimFinishedDelegate;
	FSimpleDelegate OnRaidAssistStartAnimFinishedDelegate;
	FSimpleDelegate OnSkillFailedAnimFinishedDelegate;

	void OnAllyBarClicked(FCCUnitId InUnitId, int32 InAllyBarIndex);
	void OnEnemyBarClicked(FCCUnitId InUnitId);

private:
	UCombatUnitBarWidget* GetUnitBar(FCCUnitId UnitId) const;
	UCombatAllyBarWidget* GetAllyBar(FCCUnitId UnitId) const;
	UCombatEnemyBarWidget* GetEnemyBar(FCCUnitId UnitId) const;

	const FCMSSagaRow& GetCombatSeedSagaRow() const;
	void PlayWaveStartAnimations();

	void DeselectSelectedTurnUnit();
	void DeselectSelectedTurnSkill();
	void SetTurnSkills(FCCUnitId InUnitId);
	void RefreshAllyTurnSkills();
	void RefreshArtifactButton();

	void DisableAllyNatureRelations();

	FCCUnitId GetFirstAliveAllyUnitId() const;

	bool IsBonusWave(const int32 WaveIndex) const;

	void OnSpawnAnimFinished();

	void OnUnitBarLongClicked(FCCUnitId InUnitId);

	UFUNCTION()
	void OnCombatDetailButtonClicked();
	void OpenCombatDetailPopup(FCCUnitId InUnitId);

	UFUNCTION()
	void OnSkillQuickUseClicked(bool bInChecked);

	UFUNCTION()
	void OnDoubleSpeedChecked(bool bInChecked);
	void SetCombatDoubleSpeedInternal(bool bInit, bool bDoubleSpeed);

	void OnTurnSkillClicked(int32 InIndex);
	void OnTurnSkillUseClicked(FCCSkillId InSkillId);
	void OnTurnSkillBlocked();

	void OnPetButtonClicked();

	UFUNCTION()
	void OnArtifactButtonClicked();

	void OnAttackButtonClicked();
	void OnAttackSkillClicked(FCCUnitId InUnitId, FCCSkillId InSkillId);
	void OnSkillStartAnimFinished();

	void OnStartTurnPhaseAnimFinished();
	void OnStartPhaseSettingsInternal(ECPTurnPhase InPhase);

	void RefreshMonsterTarget();
	void UpdateAlliesNatureRelation();

	void OnRaidAssistStartAnimFinished();
	void OnSkillFaildAnimFinished();

	void OnBackTurnButtonClicked();
	void ProceedToSteadyPhase();
	void BackFromSteadyPhase();

	UFUNCTION()
	void OnPauseButtonClicked();

	void SetStageInfo(const ACombatPresenter* CombatPresenter, const FCMSSagaRow& InSagaRow);
	void SetRaidStageInfo();
	void SetRaidFinalStageInfo();
	void SetRaidMyDamage();

	void SetPauseButtonEnable(bool bInEnable);

	void AllBlockedForcePhaseChange();

	void ClearProvokeTargetEnemyBars();
	void UpdateProvokeTargetEnemyBars(const FCCUnitId InUnitId);

	void SetCombatMultiSideWaveInfo();

	// Widget Animations

	UPROPERTY(Transient)
	UWidgetAnimation* TurnStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TurnEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TurnSkillHideAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TurnSkillShowAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* WaveStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* WaveEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* InDangerStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UltSkillStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UltSkillIllustAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UltSkillEndAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HUDStateNormalAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HUDStateRaidAnim;

	// Widgets

	UPROPERTY()
	TArray<UCombatAllyBarWidget*> AllyBars;

	UPROPERTY()
	TArray<UCombatEnemyBarWidget*> EnemyBars;

	UPROPERTY()
	TArray<UCombatTurnSkillWidget*> TurnSkillWidgets;

	UPROPERTY()
	UCombatWaveWidget* WaveWidget;

	UPROPERTY()
	UCombatTurnPhaseWidget* TurnPhaseWidget;

	UPROPERTY()
	UCombatAttackButtonWidget* AttackButtonWidget;

	UPROPERTY()
	UCheckBox* SkillQuickUseCheckBox;

	UPROPERTY()
	UCheckBox* DoubleSpeedCheckBox;

	UPROPERTY()
	UCombatSkillCastingNameWidget* SkillCastingNameWidget;

	UPROPERTY()
	UCombatSkillFailedWidget* SkillFailedWidget;

	UPROPERTY()
	UCombatTotalDamageWidget* TotalDamageWidget;

	UPROPERTY()
	UCombatChainEffectWidget* ChainEffectWidget;

	UPROPERTY()
	URaidAssistTurnWidget* RaidAssistTurnWidget;

	UPROPERTY()
	URaidTotalBarWidget* RaidTotalBarWidget;

	UPROPERTY()
	URaidRankingWidget* RaidRankingWidget;

	UPROPERTY()
	UCombatTimeWidget* CombatTimeWidget;

	UPROPERTY()
	URaidEmoticonWidget* RaidEmoticonWidget;

	UPROPERTY()
	UCombatPetButtonWidget* PetButtonWidget;

	UPROPERTY()
	UButton* ArtifactButton;

	UPROPERTY()
	UButton* PauseButton;

	UPROPERTY()
	UButton* CombatDetailButton;

	UPROPERTY()
	UCombatMenuWidget* CombatMenuWidget;

	UPROPERTY()
	UBackTurnButtonWidget* BackTurnButtonWidget;

	UPROPERTY()
	UWaveTurnInfoWidget* WaveTurnInfoWidget;

	UPROPERTY()
	UBonusRewardMarkListWidget* BonusRewardMarkListWidget;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCombatWonderSkillUsePopupWidget> WonderSkillUsePopupWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCombatDetailPopupWidget> CombatDetailPopupWidgetClass;

	int32 AttackOrder;
	int32 WidgetAnimWaitingCount;

	FCCUnitId SelectedAllyUnitId;
	FCCUnitId SelectedEnemyUnitId;

	int32 SelectedTurnSkillIndex;

	bool bSkillQuickUse;
	bool bShowProvokedEnemyBar;

	bool bIgnoreAnimationFinishedEvent;	// for combat multi side
};

/*
* WaveTurnInfoWidgetBP
*/
UCLASS()
class Q6_API UWaveTurnInfoWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UWaveTurnInfoWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetTotalWave(int32 InTotalWave);
	void SetCurrentWave(int32 InCurrentWave);
	void SetTurnCount(int32 InTurnCount);
	void SetTurnLeft(int32 InTurnLeft);

	void SetWaveVisibility(bool bVisible);
	void SetBonusWaveVisibility(bool bVisible);
	void SetTurnLeftVisibility(bool bVisible);

private:
	UPROPERTY()
	UBorder* WaveBorder;

	UPROPERTY()
	UBorder* BonusWaveBorder;

	UPROPERTY()
	UBorder* TurnBorder;

	UPROPERTY()
	UBorder* TurnLeftBorder;

	UPROPERTY()
	UTextBlock* CurrentWaveText;

	UPROPERTY()
	UTextBlock* TotalWaveText;

	UPROPERTY()
	UTextBlock* TurnCountText;

	UPROPERTY()
	UTextBlock* TurnLeftText;
};
