// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "TempleWidgets.h"

#include "BagItemManager.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "ItemWidgets.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "PopupWidgets.h"
#include "Q6Account.h"
#include "Q6Define.h"
#include "SystemConstHelper.h"
#include "TempleManager.h"
#include "UpgradeWidgets.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Temple"), STAT_OnHSEventByTemple, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Artifact Icon Widget
//////////////////////////////////////////////////////////////////////////
void UArtifactIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	RemainDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RemainDays"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	LevelText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Level"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UArtifactIconWidget::OnArtifactSelected);

	SelectedAnim = GetWidgetAnimationFromName(this, "AnimSelected");
	DeselectedAnim = GetWidgetAnimationFromName(this, "AnimDeselected");

	NotUsedAnim = GetWidgetAnimationFromName(this, "AnimNotUsed");
	CooldownAnim = GetWidgetAnimationFromName(this, "AnimCooldown");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimLocked");
	BoostUsedAnim = GetWidgetAnimationFromName(this, "AnimBoostUsed");
}

void UArtifactIconWidget::SetArtifact(const FArtifact& Artifact, int32 ArtifactIndex)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetArtifactSkillRowOrDummy(ArtifactIndex);
	NameText->SetText(SkillRow.DescName);
	LevelText->SetText(FText::AsNumber(Artifact.Level));

	const FArtifactIcon& ArtifactIcon = GetUIResource().GetArtifactIcon(ArtifactIndex);
	IconImage->SetBrush(ArtifactIcon.Brush);
	BGImage->SetBrush(ArtifactIcon.BGBrush);

	const ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetWonderTempleArtifactVisibility(Artifact, ArtifactIndex);
	NewMarkImage->SetVisibility(NewMarkVisibility);

	if (Artifact.Level <= 0)
	{
		PlayAnimation(LockedAnim);
		return;
	}

	int32 RemainSeconds = GetHUDStore().GetTempleManager().GetArtifactRemainSeconds(ArtifactIndex);
	if (RemainSeconds > 0)
	{
		// Cooldown

		RemainDaysText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "TimeLeft"), Q6Util::GetRemainTimeText(RemainSeconds)));
		PlayAnimation(CooldownAnim);
	}
	else
	{
		// Not used artifact skill

		PlayAnimation(NotUsedAnim);
	}
}

void UArtifactIconWidget::SetSelected(bool bInSelected)
{
	PlayAnimation(bInSelected ? SelectedAnim : DeselectedAnim);
}

void UArtifactIconWidget::OnArtifactSelected()
{
	OnArtifactSelectedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////
// Artifact Upgrade Result Widget
//////////////////////////////////////////////////////////////////////////
void UArtifactUpgradeResultPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	CurrentSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("CurrentSkill"));
	ResultSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("ResultSkill"));

	UWidgetAnimation* UpgradeAnim = GetWidgetAnimationFromName(this, "AnimUpgrade");
	PlayAnimation(UpgradeAnim);
}

void UArtifactUpgradeResultPopupWidget::SetArtifact(int32 ArtifactIndex)
{
	const FArtifactIcon& ArtifactIcon = GetUIResource().GetArtifactIcon(ArtifactIndex);
	IconImage->SetBrush(ArtifactIcon.Brush);
	BGImage->SetBrush(ArtifactIcon.BGBrush);

	const FCMSSkillRow& SkillRow = GetCMS()->GetArtifactSkillRowOrDummy(ArtifactIndex);
	NameText->SetText(SkillRow.DescName);

	int32 Cooltime = SystemConstHelper::GetArtifactSkillCooltime(ArtifactIndex);
	if (const FArtifact* Artifact = GetHUDStore().GetTempleManager().GetArtifact(ArtifactIndex))
	{
		CurrentSkillWidget->SetArtifact(Artifact->Level - 1, BuildToolTipDesc(SkillRow.Type, Artifact->Level - 1, SkillRow.SkillCategory), Cooltime);
		CurrentSkillWidget->SetInfoColor(false, false);

		ResultSkillWidget->SetArtifact(Artifact->Level, BuildToolTipDesc(SkillRow.Type, Artifact->Level, SkillRow.SkillCategory), Cooltime);
		ResultSkillWidget->SetInfoColor(true, false);
	}
}

//////////////////////////////////////////////////////////////////////////
// Temple Widget
//////////////////////////////////////////////////////////////////////////
void UTempleWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	ArtifactIcons.Reset();
	for (int32 n = 1; n <= MAX_ARTIFACT_COUNT; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Artifact%d"), n);
		UArtifactIconWidget* IconWidget = CastChecked<UArtifactIconWidget>(GetWidgetFromName(*WidgetName));
		IconWidget->OnArtifactSelectedDelegate.BindUObject(this, &UTempleWidget::SelectArtifact, n - 1);
		ArtifactIcons.Add(IconWidget);
	}

	SkillNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("SkillName"));
	CurrentSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("CurrentSkill"));
	ResultSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("ResultSkill"));
	LevelInfoText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("LevelInfo"));
	SkillInfoText = CastChecked<UQ6TextBlock>(GetWidgetFromName("SkillInfo"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));
	RequireGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequireGold"));
	RequireGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);

	OwnedGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedGold"));
	OwnedGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	ActionButton = CastChecked<UButton>(GetWidgetFromName("Action"));
	ActionButton->OnClicked.AddUniqueDynamic(this, &UTempleWidget::OnActionButtonClicked);

	ActionText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextAction"));

	// Animations

	IntroAnim = GetWidgetAnimationFromName(this, "AnimIntro");
	ArtifactUpgradeAnim = GetWidgetAnimationFromName(this, "AnimUpgrade");
	LowLevelAnim = GetWidgetAnimationFromName(this, "AnimLowLevel");
	SkillNotUsedAnim = GetWidgetAnimationFromName(this, "AnimSkillNotUsed");
	SkillBoostAnim = GetWidgetAnimationFromName(this, "AnimSkillBoost");
	SkillCooldownAnim = GetWidgetAnimationFromName(this, "AnimSkillCooldown");
	NotAcquireAnim = GetWidgetAnimationFromName(this, "AnimNotAcquire");
}

void UTempleWidget::OnMenuEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByTemple);

	if (InAction->GetActionType() == EHSActionType::DevTempleArtifactsResetResp)
	{
		SetWonder();
		return;
	}

	if (InAction->GetActionType() == EHSActionType::TempleArtifactBoostResp)
	{
		RefreshUI();

		PlayBoostAnimation();
		return;
	}

	if ((InAction->GetActionType() == EHSActionType::DevTempleArtifactUpgradeResp)
		|| (InAction->GetActionType() == EHSActionType::TempleArtifactUpgradeResp))
	{
		RefreshUI();

		UArtifactUpgradeResultPopupWidget* ResultPopup = CastChecked<UArtifactUpgradeResultPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(ResultPopupWidgetClass));
		ResultPopup->SetArtifact(SelectedIndex);
		return;
	}
}

void UTempleWidget::SetWonder()
{
	RefreshUI();
	SelectArtifact(0);	// Default selected slot

	PlayAnimation(IntroAnim);
}

void UTempleWidget::RefreshUI()
{
	const TArray<ESlateVisibility> NewMarkVisibilities = GetHUDStore().GetNewMarkManager().GetWonderTempleVisibilities();
	check(NewMarkVisibilities.Num() == MAX_ARTIFACT_COUNT);

	for (int32 i = 0; i < MAX_ARTIFACT_COUNT; ++i)
	{
		const FArtifact* Artifact = GetHUDStore().GetTempleManager().GetArtifact(i);
		if (!Artifact)
		{
			Q6JsonLogRoze(Error, "UTempleWidget::RefreshUI - No have artifact", Q6KV("Index", i));
			return;
		}

		ArtifactIcons[i]->SetArtifact(*Artifact, i);
	}

	SetArtifactDetail();
}

void UTempleWidget::PlayBoostAnimation()
{
	if (ArtifactIcons.IsValidIndex(SelectedIndex))
	{
		ArtifactIcons[SelectedIndex]->PlayBoostUsedAnim();
	}
}

void UTempleWidget::SelectArtifact(int32 NewSelectedIdx)
{
	SelectedIndex = NewSelectedIdx;

	const TArray<ESlateVisibility> NewMarkVisibilities = GetHUDStore().GetNewMarkManager().GetWonderTempleVisibilities();
	check(NewMarkVisibilities.Num() == MAX_ARTIFACT_COUNT);

	for (int32 i = 0; i < MAX_ARTIFACT_COUNT; ++i)
	{
		ArtifactIcons[i]->SetSelected(i == SelectedIndex);
	}

	SetArtifactDetail();
}

void UTempleWidget::SetArtifactDetail()
{
	const FTempleInfo& TempleInfo = GetHUDStore().GetTempleManager().GetTempleInfo();
	if (!TempleInfo.Artifacts.IsValidIndex(SelectedIndex))
	{
		Q6JsonLogRoze(Error, "UTempleWidget::SetArtifactDetail - Invalid artifact index", Q6KV("ArtifactIndex", SelectedIndex));
		return;
	}

	const FArtifact& Artifact = TempleInfo.Artifacts[SelectedIndex];

	// Upgrade artifact

	if (Artifact.Level < CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		SetArtifactUpgrade(Artifact, TempleInfo.Level);
		return;
	}

	// Artifact Skill cooltime

	SetArtifactCooldown(Artifact);
}

void UTempleWidget::SetSkillInfo(int32 CurrentLevel, bool bShowUpgrade)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetArtifactSkillRowOrDummy(SelectedIndex);
	int32 Cooltime = SystemConstHelper::GetArtifactSkillCooltime(SelectedIndex);
	SkillNameText->SetText(SkillRow.DescName);

	// Current skill info

	CurrentLevel = FMath::Max(CurrentLevel, 1);
	CurrentSkillWidget->SetArtifact(CurrentLevel, BuildToolTipDesc(SkillRow.Type, CurrentLevel, SkillRow.SkillCategory), Cooltime);
	CurrentSkillWidget->SetInfoColor(false, false);

	if (bShowUpgrade)
	{
		// Upgrade result skill info

		ResultSkillWidget->SetArtifact(CurrentLevel + 1, BuildToolTipDesc(SkillRow.Type, CurrentLevel + 1, SkillRow.SkillCategory), Cooltime);
		ResultSkillWidget->SetInfoColor(true, false);
	}
}

void UTempleWidget::SetArtifactCost(int32 TargetLevel)
{
	const FCMSSkillRow& ArtifactSkillRow = GetCMS()->GetArtifactSkillRowOrDummy(SelectedIndex);
	const FCMSSkillUpgradeCostRow& CostRow = GetCMS()->GetSkillUpgradeCostRowOrDummy(ArtifactSkillRow, TargetLevel);
	MaterialsWidget->SetMaterials(CostRow.GetBagItem(), CostRow.BagItemCount);

	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedGoldWidget->SetCurPoint(OwnedGold);
	RequireGoldWidget->SetPoint(CostRow.Gold, OwnedGold);

	bool bEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(CostRow.GetBagItem(), CostRow.BagItemCount);
	ActionButton->SetIsEnabled((OwnedGold >= CostRow.Gold) && bEnoughMaterials);
}

void UTempleWidget::SetArtifactCooldown(const FArtifact& Artifact)
{
	LevelInfoText->SetText(Q6Util::GetLocalizedText("Lobby", "MaxTempleLevel"));
	ActionText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderBuildBoost"));

	SetSkillInfo(Artifact.Level, false);

	int32 RemainSeconds = GetHUDStore().GetTempleManager().GetArtifactRemainSeconds(SelectedIndex);
	if (RemainSeconds > 0)
	{
		static const int32 BoostCooltime = 86400;
		if (Q6Util::IsDailyResetTimePassed(Artifact.BoostedTime + BoostCooltime))
		{
			// Artifact boost use
			SetArtifactCost(Artifact.Level);

			PlayAnimation(SkillBoostAnim);
		}
		else
		{
			// Artifact skill cooltime

			SkillInfoText->SetText(Q6Util::GetLocalizedText("Lobby", "CooltimeInfo"));
			ActionButton->SetIsEnabled(false);

			PlayAnimation(SkillCooldownAnim);
		}
	}
	else
	{
		// Artifact skill not used
		SkillInfoText->SetText(Q6Util::GetLocalizedText("Lobby", "ArtifactUsable"));
		ActionButton->SetIsEnabled(false);

		PlayAnimation(SkillNotUsedAnim);
	}
}

void UTempleWidget::SetArtifactUpgrade(const FArtifact& Artifact, int32 TempleLevel)
{
	if (Artifact.Level <= 0)
	{
		const UCMS* CMS = GetCMS();
		const FCMSSkillRow& SkillRow = CMS->GetArtifactSkillRowOrDummy(SelectedIndex);
		const FCMSSagaRow* SagaRow = CMS->GetArtifactOpenConditionSagaRow(SkillRow.CmsType());
		if (!SagaRow)
		{
			return;
		}

		LevelInfoText->SetText(FText::Format(
			Q6Util::GetLocalizedText("Lobby", "LackTempleNotAcquire"), SagaRow->DescName));
		ActionButton->SetIsEnabled(false);

		SetSkillInfo(Artifact.Level, false);
		PlayAnimation(NotAcquireAnim);
	}
	else if (Artifact.Level >= TempleLevel)
	{
		LevelInfoText->SetText(FText::Format(
			Q6Util::GetLocalizedText("Lobby", "LackTempleLevel"), FText::AsNumber(TempleLevel + 1)));
		ActionButton->SetIsEnabled(false);

		SetSkillInfo(Artifact.Level, true);
		PlayAnimation(LowLevelAnim);
	}
	else
	{
		SetArtifactCost(Artifact.Level + 1);
		SetSkillInfo(Artifact.Level, true);
		PlayAnimation(ArtifactUpgradeAnim);
	}

	ActionText->SetText(Q6Util::GetLocalizedText("Common", "Upgrade"));
}

void UTempleWidget::OnActionButtonClicked()
{
	const FArtifact* Artifact = GetHUDStore().GetTempleManager().GetArtifact(SelectedIndex);
	if (!Artifact)
	{
		Q6JsonLogRoze(Error, "UTempleWidget::OnActionButtonClicked - Not found Artifact", Q6KV("Index", SelectedIndex));
		return;
	}

	if (Artifact->Level < CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		// Artifact upgrade

		USkillUpgradeConfirmPopupWidget* ConfirmPopup = GetCheckedLobbyHUD(this)->OpenSkillUpgradeConfirmPopup();
		check(ConfirmPopup);

		ConfirmPopup->SetArtifactSkill(SelectedIndex);
		ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UTempleWidget::OnArtifactUpgrade);
	}
	else
	{
		UBoostConfirmPopupWidget* ConfirmPopup = CastChecked<UBoostConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(BoostConfirmPopupWidgetClass));
		ConfirmPopup->SetArtifact(SelectedIndex, Artifact->Level);
	}
}

void UTempleWidget::OnArtifactUpgrade(EConfirmPopupFlag Option)
{
	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetHUDStore().GetTempleManager().ReqArtifactUpgrade(SelectedIndex);
}
