#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

#include "AchievementsPageWidgets.generated.h"

struct FCharacterId;
struct FCMSCharMissionRow;
struct FCharacter;

class UQ6Button;
class UMissionGaugeWidget;
class UItemWidget;
class UDynamicListWidget;

UENUM(BlueprintType)
enum class EPuzzleSlotState : uint8
{
	BlankSlot,
	ImageSlot,
	LockSlot,
	Max,
};

UENUM(BlueprintType)
enum class EPuzzleSlotMovableState : uint8
{
	Movable,
	Immovable,
	Max,
};

USTRUCT()
struct FAchievementInfo
{
	GENERATED_BODY()

		FAchievementInfo()
		: Index(INDEX_NONE)
		, MissionIng(0)
		, MaxValue(0)
		, RewardUtc(0)
		, CharMissionType(CharMissionTypeInvalid.x)
	{}

	UPROPERTY()
	int32 Index;

	UPROPERTY()
	int32 MissionIng;

	UPROPERTY()
	int32 MaxValue;

	UPROPERTY()
	int32 RewardUtc;

	UPROPERTY()
	int32 CharMissionType;
};

UCLASS()
class Q6_API UAchievementsListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UAchievementsListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetInfo(const int32 InMissionIng
		, const int32 InMaxValue
		, const int32 InRewardUtc
		, const int32 InCharMissionType);

	FSimpleDelegate OnGetRewardButtonClickedDelegate;

private:
	void PlayAchievementsListAnimation(EAchievementsListAnimType Type);

	void SetAchievementsItem(const FCMSCharMissionRow& CharMissionRow);

	UFUNCTION()
	void OnGetRewardButtonClicked();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> AchievementsListAnims;

	UPROPERTY()
	UMissionGaugeWidget* AchieveGaugeWidget;

	UPROPERTY()
	UItemWidget* AchieveItemWidget;
};

UCLASS()
class Q6_API UPuzzlePieceWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPuzzlePieceWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetImageSwitcherPosition(float InX, float InY);

	void SetInfo(const FCharacterType InCharacterType, bool bAlreadyReceived);

	void SetMovable(bool bInMovable) { bMovable = bInMovable; }

	void PlayPuzzlePieceAnimation(EPuzzlePieceAnimType Type);

	UFUNCTION(BlueprintImplementableEvent)
	void SetPuzzleSlotState(EPuzzleSlotState InPuzzleSlotState);

	UFUNCTION(BlueprintImplementableEvent)
	void SetPuzzleSlotMovableState(EPuzzleSlotMovableState InPuzzleSlotMovableState);

	FSimpleDelegate OnPuzzlePieceButtonClickedDelegate;
	FSimpleDelegate OnPuzzlePieceAnimFinishedDelegate;

private:
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	bool FindOrCreateCharacterUltimateIlustWidget(const FCharacterType& InCharacterType);
	void SetCharacterIllustBGTexture(const FCharacterType& InCharacterType, const EItemGrade InGrade);

	float GetPuzzlePieceSize();

	UFUNCTION()
	void OnPuzzlePieceButtonClicked();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> PuzzlePieceAnims;

	UPROPERTY()
	USizeBox* PuzzlePieceSizeBox;

	UPROPERTY()
	UWidgetSwitcher* PuzzlePieceImageSwitcher;

	UPROPERTY()
	UImage* ImgIllustImage;

	bool bMovable;
	EPuzzleSlotState PuzzleSlotState;
	FCharacterType CharacterType;
};

UCLASS()
class Q6_API UPuzzleBoxWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPuzzleBoxWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetAchievementsPageInfo(const FCharacterType InCharacterType
		, const TArray<int32>& ShuffleNumbers
		, const int32 BefoCollectedPiece
		, const int32 CurrCollectedPiece
		, bool bPuzzleCompleted);

	void SetAchievementsPuzzleInfo(const FCharacterType InCharacterType
		, const TArray<int32>& ShuffleNumbers);

	void PlayPuzzlePieceAnimation(const int32 Index, EPuzzlePieceAnimType Type);

	void ResetPuzzleSlotState();

	FIntParamDelegate OnPuzzlePieceButtonClickedDelegate;
	FIntParamDelegate OnPuzzlePieceAnimFinishedDelegate;

private:
	void SetPuzzlePieceInfo(const FCharacterType CharacterType
		, const int32 Index
		, const int32 ShuffleIndex
		, EPuzzleSlotState Type
		, bool bAleadyReceived);

	void SetMovableState(const int32 Index, bool bMovable);

	UFUNCTION()
	void OnPuzzlePieceButtonClicked(int32 Index);

	UFUNCTION()
	void OnPuzzlePieceAnimFinishedClicked(int32 Index);

	UPROPERTY()
	TArray<UPuzzlePieceWidget*> PuzzlePieces;

	TArray<EPuzzleSlotState> PuzzleSlotStates;
};

UCLASS()
class Q6_API UAchievementsPageWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UAchievementsPageWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action);

	void InitAchievementsPage(const FCharacterType& InCharType);
	void SetInfo();

private:
	void OpenReceivedRewardItemPopup();
	void PlayAchievementsPageAnimation(EAchievementsPageAnimType Type, bool bLoop = false);

	void SetPuzzleShuffleNumbers();
	void SetAchievementsData();
	void SetAchievementsList();
	void SetCollectedPiecesText();
	void SetMasterPieceNameText();
	void SetAchievementsPageAnimation();

	void SetBoxPuzzleInfo(const FCharacterType InCharacterType
		, const int32 BefoCollectedPiece
		, const int32 CurrCollectedPiece);

	UFUNCTION()
	void OnGetRewardButtonClicked(int32 Index);

	UFUNCTION()
	void OnItemReceivedPopupClosed();

	UFUNCTION()
	void OnStartPuzzleButtonClicked();

	UFUNCTION()
	void OnAchievementsPuzzlePopupClosed();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> AchievementsPageAnims;

	UPROPERTY()
	UTextBlock* MasterpieceNameText;

	UPROPERTY()
	UTextBlock* CollectedPiecesText;

	UPROPERTY()
	UQ6Button* StartPuzzleButton;

	UPROPERTY()
	UPuzzleBoxWidget* BoxPuzzleWidget;

	UPROPERTY()
	UDynamicListWidget* AchievementListWidget;

	TArray<FAchievementInfo> AchievementInfos;
	TArray<int32> PuzzleShuffleNumbers;
	FCharacterType CharType;
	int32 CollectedPieceCount;
	int32 GetRewardButtonIndex;
	bool bPuzzleCompleted;
};

UCLASS()
class Q6_API UAchievementsPuzzleWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UAchievementsPuzzleWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetInfo(const FCharacterType& InCharType
		, const TArray<int32>& InShuffleNumbers);

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action);

private:
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void OpenReceivedRewardItemPopup();

	void PlayAchievementsPuzzleAnimation(EAchievementsPuzzleAnimType Type);

	void SetBoxPuzzleInfo();

	void SetPuzzleImage();

	bool FindOrCreateCharacterUltimateIlustWidget(const FCharacterType& Type);
	void SetCharacterIllustBGTexture(const FCharacterType& Type, const EItemGrade InGrade);

	bool IsPuzzleComplete();

	UFUNCTION()
	void OnPuzzlePieceButtonClicked(int32 Index);

	UFUNCTION()
	void OnPuzzlePieceAnimFinished(int32 Index);

	UFUNCTION()
	void OnItemReceivedPopupClosed();

	UFUNCTION()
	void OnOkButtonClicked();

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> AchievementsPuzzleAnims;

	UPROPERTY()
	UWidgetSwitcher* BgImageWidgetSwitcher;

	UPROPERTY()
	UImage* ImgIllustImage;

	UPROPERTY()
	UPuzzleBoxWidget* BoxPuzzleWidget;

	TArray<int32> ShuffleNumbers;
	int32 BlankPuzzleIndex;
	FCharacterType CharType;
	bool bPuzzleComplete;
};
