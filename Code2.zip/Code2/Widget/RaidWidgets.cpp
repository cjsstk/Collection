#include "RaidWidgets.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HSAction.h"
#include "ItemWidgets.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "RaidManager.h"
#include "SystemConst_gen.h"
#include "Q6Log.h"
#include "WidgetUtil.h"
#include "HUDStore/EventManager.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Raid"), STAT_OnHSEventByRaid, STATGROUP_HSTORE);

URaidWidget::URaidWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, OpenRaidType(RaidTypeInvalid)
	, OpenRaidId(FRaidId::InvalidValue())
	, RegularRaidType(RaidTypeInvalid)
	, RegularRaidScheduleId(0)
	, RegularRaidRegisterd(false)
	, RegularRaidMatched(false)
	, WaitForReqReady(false)
	, RegularRaidRespReady(false)
{

}

void URaidWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RaidAnims.Reset();
	RaidAnims.Add(GetWidgetAnimationFromName(this, "AnimSetNone"));
	RaidAnims.Add(GetWidgetAnimationFromName(this, "AnimSetProgress"));
	RaidAnims.Add(GetWidgetAnimationFromName(this, "AnimSetEnd"));
	check(RaidAnims.Num() == static_cast<int32>(ERaidState::Max));

	StageListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("StageList"));

	SelectedRaidJoinable = CastChecked<URaidStageWidget>(GetWidgetFromName("RaidJoinable"));
	SelectedRaidJoinable->RaidStageClickedDelegate.BindUObject(this, &URaidWidget::OnJoinableButtonClicked);

	InitialReward = CastChecked<UItemWidget>(GetWidgetFromName("Item"));

	CurListCountText = CastChecked<UTextBlock>(GetWidgetFromName("CurList"));

	MaxListCountText = CastChecked<UTextBlock>(GetWidgetFromName("MaxList"));

	RegularInfoText = CastChecked<UTextBlock>(GetWidgetFromName("TextRagulrInfo"));

	GetImage = CastChecked<UImage>(GetWidgetFromName("Get"));
}

void URaidWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::Raid);
	SubscribeToStore(EHSType::WorldUser);

	ACTION_DISPATCH_UpdateRaidWhenEnterMenu();
}

void URaidWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FRaidUIState* UIState = GetUIState()->CastToRaidUIState();
	check(UIState);

	GetBaseHUD(this)->CloseRaidJoinPopup();

	SetInfo();
}

void URaidWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByRaid);

	switch (Action->GetActionType())
	{
		case EHSActionType::RaidCanEnterNof:
		{
			RefreshMenu();

			FRaidType FoundRaidType = GetHUDStore().GetRaidManager().GetFoundRaidType();
			if (FoundRaidType != RaidTypeInvalid)
			{
				ReqPrepare();
			}
		}
		break;
		case EHSActionType::UpdateRaidWhenEnterMenu:
		{
			SetGetImageVisible(GetHUDStore().GetRaidManager().IsTodayRaidClear());
			RefreshMenu();
		}
		break;
		default:
		{
			RefreshMenu();
		}
		break;
	}
}

void URaidWidget::SetInfo()
{
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	OpenRaidType = RaidManager.GetOpenRaidType();
	OpenRaidId = RaidManager.GetOpenRaidId();

	const FRegularRaidState& RegularRaidState = RaidManager.GetRegularRaidState();
	RegularRaidType = RegularRaidState.RaidType;
	RegularRaidScheduleId = RegularRaidState.ScheduleId;
	RegularRaidRegisterd = RegularRaidState.Registered;
	RegularRaidMatched = RegularRaidState.Matched;
	WaitForReqReady = RegularRaidState.WaitForReqReady;
	RegularRaidRespReady = RegularRaidState.RespReady;

	SetJoinableRaid();
	SetRewardItemInfo();
	SetFinalStageList();
	SetRegularRaidInfoText();

	PlayRaidWidgetAnimation();
}

void URaidWidget::SetJoinableRaid()
{
	if (OpenRaidType != RaidTypeInvalid
		&& OpenRaidId != FRaidId::InvalidValue()
		&& RegularRaidType == RaidTypeInvalid)
	{
		SetOpenedRaid();
	}
	else
	{
		SetJoinableRegularRaid();
	}
}

void URaidWidget::SetJoinableRegularRaid()
{
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RegularRaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	const FRegularRaidState& RegularRaidState = GetHUDStore().GetRaidManager().GetRegularRaidState();
	const FEventScheduleInfo* ScheduleInfo = GetHUDStore().GetEventManager().GetEventSchedule(
		RegularRaidState.ScheduleId);
	if (!ScheduleInfo)
	{
		Q6JsonLogGenie(Warning, "ScheduleInfo Does Not Exist.",
			Q6KV("EventScheduleId", RegularRaidState.ScheduleId));
		return;
	}

	FDateTime NowDate = FDateTime::Now();
	FDateTime EndDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate);
	FDateTime ReqReadyEndDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate2);

	if (NowDate > ReqReadyEndDate && !RegularRaidState.RespReady)
	{
		return;
	}

	ERaidStageState RaidStageState(ERaidStageState::Registrable);
	if (EndDate <= FDateTime::Now())
	{
		RaidStageState = ERaidStageState::Joinable;
	}
	else if (RegularRaidRegisterd)
	{
		RaidStageState = ERaidStageState::Resistration;
	}

	SelectedRaidJoinable->SetInfo(OpenRaidId
		, SagaRow
		, RaidStageState
		, ERaidCategory::RegularRaid
		, SagaRow.WattConsume
		, WorldUser.GetWatt());
}

void URaidWidget::SetOpenedRaid()
{
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(OpenRaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	SelectedRaidJoinable->SetInfo(OpenRaidId
		, SagaRow
		, ERaidStageState::Joinable
		, ERaidCategory::GeneralRaid
		, SagaRow.WattConsume
		, WorldUser.GetWatt());
}

void URaidWidget::SetRewardItemInfo()
{
	const UCMS* CMS = GetCMS();
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	FRaidType TodayRaidType = RaidManager.GetTodayRaidType();

	const FCMSRaidRow& RaidRow = CMS->GetRaidRowOrDummy(TodayRaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	const TArray<const FCMSLootGroupRow*> LootGroupRows = SagaRow.GetInitialLootGroup();
	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRows);
	if (LootDataRow.IsInvalid())
	{
		return;
	}

	InitialReward->SetRewardType(ERewardType::First);
	InitialReward->SetLoot(LootDataRow.LootId, LootDataRow.Count);

	SetInitialRewardItemVisible(true);
}

void URaidWidget::SetFinalStageList()
{
	StageListWidget->ClearList();

	const TMap<FRaidId, FRaidFinal>& RaidFinals = GetHUDStore().GetRaidManager().GetRaidFinals();
	for (const auto& RaidFinal : RaidFinals)
	{
		const FRaidFinalInfo& RaidFinalInfo = RaidFinal.Value.GetInfo();
		const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RaidFinalInfo.Type);
		if (RaidRow.IsInvalid())
		{
			Q6JsonLogGenie(Warning, "URaidManager::SetFinalStageList - RaidRow(SagaRow) does not exist."
				, Q6KV("Type", RaidFinalInfo.Type));
			continue;
		}

		const FCMSSagaRow& SagaRow = RaidRow.GetRaidFinal();
		if (SagaRow.IsInvalid())
		{
			Q6JsonLogPaul(Warning, "URaidManager::SetFinalStageList - RaidFinal(SagaRow) does not exist."
				, Q6KV("Type", RaidFinalInfo.Type));
			continue;
		}

		URaidStageWidget* StageWidget = CastChecked<URaidStageWidget>(StageListWidget->AddChildAtLastIndex());
		StageWidget->RaidStageClickedDelegate.BindUObject(this, &URaidWidget::OnFinalStageButtonClicked);

		StageWidget->SetInfo(RaidFinalInfo.RaidId
			, SagaRow
			, RaidFinal.Value.GetRaidEnded() ? ERaidStageState::Final : ERaidStageState::InProgress
			, RaidRow.RegularRaidScheduleIds.Num() > 0 ? ERaidCategory::RegularRaid : ERaidCategory::GeneralRaid
			, 0
			, 0);
	}

	CurListCountText->SetText(FText::AsNumber(StageListWidget->GetChildrenCount()));
	MaxListCountText->SetText(FText::AsNumber(SystemConst::Q6_MAX_RAID_RESULT));
}

void URaidWidget::SetRegularRaidInfoText()
{
	RegularInfoText->SetVisibility(ESlateVisibility::Collapsed);

	TArray<const FCMSRaidRow*> RaidRows = GetCMS()->GetRaidRows();
	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	for (const FCMSRaidRow* RaidRow : RaidRows)
	{
		if (!RaidRow)
		{
			continue;
		}

		for (const int32 ScheduleId : RaidRow->RegularRaidScheduleIds)
		{
			const FEventScheduleInfo* ScheduleInfo = EventManager.GetEventSchedule(
				ScheduleId);
			if (!ScheduleInfo)
			{
				continue;
			}

			FDateTime StartDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->StartDate);
			if (StartDate.GetDay() == FDateTime::Today().GetDay()
				&& StartDate.GetYear() == FDateTime::Today().GetYear())
			{
				RegularInfoText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
				RegularInfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "RaidRegularInfo")
					, FText::AsNumber(StartDate.GetHour())));

				return;
			}
		}
	}
}

void URaidWidget::PlayRaidWidgetAnimation()
{
	ERaidState RaidState(ERaidState::None);

	if (OpenRaidType != RaidTypeInvalid
		|| RegularRaidType != RaidTypeInvalid)
	{
		RaidState = ERaidState::Progress;
	}

	const int32 AnimIndex = static_cast<int32>(RaidState);
	if (ensure(RaidAnims.IsValidIndex(AnimIndex)))
	{
		PlayAnimation(RaidAnims[AnimIndex]);
	}
}

void URaidWidget::OnJoinableButtonClicked(FRaidId InRaidId)
{
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();

	if (OpenRaidType != RaidTypeInvalid
		&& OpenRaidId != FRaidId::InvalidValue()
		&& RegularRaidType == RaidTypeInvalid)
	{
		const TMap<FRaidId, FRaidFinal>& RaidFinals = RaidManager.GetRaidFinals();
		if (RaidFinals.Num() >= SystemConst::Q6_MAX_RAID_RESULT)
		{
			GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short
				, Q6Util::GetLocalizedText("Lobby", "RaidFinalBattleListFull"));

			return;
		}

		if (RaidManager.GetPrepareTime() > 0.f)
		{
			ChangeJokerSelectHUDWidget(OpenRaidType);
			return;
		}

		RaidManager.ReqPrepare();
	}
	else
	{
		if (WaitForReqReady && !RegularRaidRespReady)
		{
			FRegularRaidInfo RegularRaidInfo;
			RegularRaidInfo.RaidType = RegularRaidType;
			RegularRaidInfo.ScheduleId = RegularRaidScheduleId;

			RaidManager.ReqRegularRaidReady(RegularRaidInfo);

			ChangeJokerSelectHUDWidget(RegularRaidType);
			return;
		}

		if ((RegularRaidRespReady || RegularRaidMatched) && RegularRaidRegisterd)
		{
			ChangeJokerSelectHUDWidget(RegularRaidType);
			return;
		}

		const FRegularRaidState& RegularRaidState = RaidManager.GetRegularRaidState();
		if (RegularRaidType != RegularRaidState.RaidType)
		{
			return;
		}

		FRegularRaidInfo RegularRaidInfo;
		RegularRaidInfo.RaidType = RegularRaidState.RaidType;
		RegularRaidInfo.ScheduleId = RegularRaidState.ScheduleId;
		RaidManager.ReqRegularRaidRegister(RegularRaidInfo);
	}
}

void URaidWidget::OnFinalStageButtonClicked(FRaidId InRaidId)
{
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	const FRaidFinal* RaidFinal = RaidManager.Find(InRaidId);
	if (RaidFinal == nullptr)
	{
		return;
	}

	if (!RaidFinal->GetRaidEnded())
	{
		return;
	}

	const FRaidFinalInfo& RaidFinalInfo = RaidFinal->GetInfo();
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RaidFinalInfo.Type);
	if (RaidRow.IsInvalid())
	{
		return;
	}

	const FCMSSagaRow& SagaRow = RaidRow.GetRaidFinal();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (SagaRow.ContentType != EContentType::RaidFinal)
	{
		return;
	}

	ALobbyHUD* Lobby = GetCheckedLobbyHUD(this);
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	if (SagaRow.WattConsume > WorldUser.GetWatt())
	{
		Lobby->OpenWattRechargePopup();
		return;
	}

	ACTION_DISPATCH_SelectFinal(RaidFinalInfo.Type, RaidFinalInfo.RaidId);
	GetCheckedLobbyHUD(this)->PlaySagaWithStoryClear(SagaRow.CmsType(), true, false);
}

void URaidWidget::SetGetImageVisible(bool bInVisible)
{
	if (bInVisible)
	{
		GetImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		GetImage->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void URaidWidget::SetInitialRewardItemVisible(bool bInVisible)
{
	if (bInVisible)
	{
		InitialReward->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		InitialReward->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void URaidWidget::ReqPrepare()
{
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RaidManager.GetOpenRaidType());
	if (RaidRow.IsInvalid())
	{
		return;
	}

	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (SagaRow.ContentType != EContentType::Raid)
	{
		return;
	}

	ACTION_DISPATCH_MuteRaidJoinPopup();

	RaidManager.ReqPrepare();
}

void URaidWidget::ChangeJokerSelectHUDWidget(const FRaidType RaidType)
{
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(RaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (SagaRow.ContentType != EContentType::Raid)
	{
		return;
	}

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	if (SagaRow.WattConsume > WorldUser.GetWatt())
	{
		GetCheckedLobbyHUD(this)->OpenWattRechargePopup();
		return;
	}

	ACTION_DISPATCH_JokerSelect(SagaRow.CmsType(), true);
	GetCheckedLobbyHUD(this)->ChangeHUDType(EHUDWidgetType::JokerSelect, true);
}

URaidStageWidget::URaidStageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, RaidId(FRaidId::InvalidValue())
{
}

void URaidStageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RaidStageAnims.Reset();
	RaidStageAnims.Add(GetWidgetAnimationFromName(this, "AnimRaidFound"));
	RaidStageAnims.Add(GetWidgetAnimationFromName(this, "AnimRaidJoinable"));
	RaidStageAnims.Add(GetWidgetAnimationFromName(this, "AnimRaidFinal"));
	RaidStageAnims.Add(GetWidgetAnimationFromName(this, "AnimInProgress"));
	RaidStageAnims.Add(GetWidgetAnimationFromName(this, "AnimRaidRegistrable"));
	RaidStageAnims.Add(GetWidgetAnimationFromName(this, "AnimRaidRegistration"));
	check(RaidStageAnims.Num() == static_cast<int32>(ERaidStageState::Max));

	RaidNameText = CastChecked<UTextBlock>(GetWidgetFromName("RaidName"));
	RaidTimerText = CastChecked<UTextBlock>(GetWidgetFromName("TextRaidTimer"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &URaidStageWidget::OnSelectButtonClicked);

	WattWidget = CastChecked<UPointWidget>(GetWidgetFromName("Watt"));
	WattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::LessEqual);

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	TagImage = CastChecked<UImage>(GetWidgetFromName("Tag"));
}

void URaidStageWidget::NativeDestruct()
{
}

void URaidStageWidget::SetInfo(const FRaidId& InRaidId, const FCMSSagaRow& SagaRow
	, const ERaidStageState InState, const ERaidCategory InRaidCategory
	, int64 InCurPoint, int64 InMaxPoint)
{
	RaidId = InRaidId;

	UHUDStore& HUDStore = GetHUDStore();
	ESlateVisibility NewMarkVisibility = HUDStore.GetNewMarkManager().GetRaidVisibility(InState);
	TagImage->SetVisibility(NewMarkVisibility);

	SetBGImage(SagaRow.CmsType());
	SetRaidName(SagaRow.DescName);

	SetRaidStageWidgetState(InRaidCategory);

	if (InState == ERaidStageState::Registrable
		|| InState == ERaidStageState::Resistration)
	{
		const FRegularRaidState& RegularRaidState = HUDStore.GetRaidManager().GetRegularRaidState();
		const FEventScheduleInfo* ScheduleInfo = HUDStore.GetEventManager().GetEventSchedule(
			RegularRaidState.ScheduleId);
		if (!ScheduleInfo)
		{
			Q6JsonLogGenie(Warning, "ScheduleInfo Does Not Exist.",
				Q6KV("EventScheduleId", RegularRaidState.ScheduleId));
			return;
		}

		if (InState == ERaidStageState::Registrable)
		{
			FDateTime DateTime = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate);

			RaidTimerText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "RaidTimerRegistable")
				, FText::AsNumber(DateTime.GetHour())
				, Q6Util::AttachZeroToFront(DateTime.GetMinute())
			));
		}
		else
		{
			FDateTime DateTime = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate2);

			RaidTimerText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "RaidTimerRegistration")
				, FText::AsNumber(DateTime.GetHour())
				, Q6Util::AttachZeroToFront(DateTime.GetMinute())
				, Q6Util::AttachZeroToFront(DateTime.GetSecond())
			));
		}
	}

	SetWattPoint(InCurPoint, InMaxPoint);
	PlayRaidStageWidgetAnimation(InState);
}

void URaidStageWidget::SetRaidName(const FText& Text)
{
	RaidNameText->SetText(Text);
}

void URaidStageWidget::PlayRaidStageWidgetAnimation(const ERaidStageState InState)
{
	const int32 StateIndex = static_cast<int32>(InState);
	if (ensure(RaidStageAnims.IsValidIndex(StateIndex)))
	{
		PlayAnimation(RaidStageAnims[StateIndex]);
	}
}

void URaidStageWidget::OnSelectButtonClicked()
{
	RaidStageClickedDelegate.ExecuteIfBound(RaidId);
}

void URaidStageWidget::SetWattPoint(int64 InCurPoint, int64 InMaxPoint)
{
	check(WattWidget);
	WattWidget->SetPoint(InCurPoint, InMaxPoint);
}

void URaidStageWidget::SetBGImage(const FSagaType& InSagaType)
{
	UGameResource& GameResource = GetGameResource();
	const FRaidAssetRow& RaidAssetRow = GameResource.GetRaidAssetRow(InSagaType);
	BGImage->SetBrushFromSoftTextureWhenLoadingFinished(RaidAssetRow.BGTexture);
}
