#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "BaseWidget.h"
#include "SagaWidgets.h"
#include "StageWidgets.generated.h"

class UItemWidget;
class UPointWidget;

struct FCMSSagaRow;

UENUM(BlueprintType)
enum class EStageState : uint8
{
	New = 0,
	Normal,
	LockedByStage,
	LockedByCondition,
	Clear,
};

DECLARE_DELEGATE_OneParam(FStageClickedDelegate, FSagaType);

UCLASS()
class UStageEnemyNaturesWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UStageEnemyNaturesWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetStage(const FCMSSagaRow& SagaRow);

private:
	UPROPERTY()
	UBorder* BossBorder;

	UPROPERTY()
	UImage* BossNatureIcon;

	UPROPERTY()
	TArray<UImage*> NatureIcons;
};


UCLASS()
class UStageEntryWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UStageEntryWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetDefaultEntryWidget(FSagaType InSagaType, EStageState InState);
	void SetDailyEntryWidget(const FCMSDailyDungeonRow* InDailyDungeonRow, EStageState InState);
	void SetTrainingEntryWidget(FTrainingCenterType InTrainingCenterType, FSagaType InSagaType, EStageState InState);
	void SetSpecialEntryWidget(FSagaType InSagaType, EStageState InState, ESpecialCategory InSpceialCategory);
	void SetEventEntryWidget(FEventContentType InEventContentType, int32 InEventStageType, FSagaType InSagaType, EStageState InState, int64 InUnlockTime = 0);

	void SetHasLinkedStage(bool bInHasNext);
	void SetClearCount(int32 ClearedCount, int32 ReplayLimit);
	void SetClearCountVisible(bool bInVisible);
	void SetOpenConditionText(const TArray<const FCMSSagaRow*>& SagaRows);

	void SetStageState(EStageState InStageState);

	FStageClickedDelegate SelectedDelegate;

private:
	UFUNCTION()
	void OnPlayDialogueButtonClicked();

	UFUNCTION()
	void OnStageStartButtonClicked();

	UFUNCTION()
	void OnRewardButtonClicked();

	void OnPlayDialogue(const FCMSSagaRow& SagaRow, bool bReplay);
	void OnPlayNotifyPopupConfirm(EConfirmPopupFlag Flag);

	void Init(FSagaType InSagaType, EStageState InState, const FCMSSagaRow& SagaRow);

	bool IsSpecialBossStage(const FCMSSagaRow& SagaRow);
	bool ShouldPlayDialogue(const FCMSSagaRow& SagaRow);

	void SetUnlockRank(int32 InUnlockRank);
	void SetUnlockTime(int64 InUnlockTime);
	void SetSpecialLockedReasonText(FSagaType InSagaType);

	// Widgets

	UPROPERTY()
	UBorder* SlotWattBorder;

	UPROPERTY()
	UPointWidget* WattWidget;

	UPROPERTY()
	UButton* StageStartButton;

	UPROPERTY()
	UButton* PlayDialogueButton;

	UPROPERTY()
	UImage* LinkedImage;

	UPROPERTY()
	UStageEnemyNaturesWidget* StageNaturesWidget;

	UPROPERTY()
	UTextBlock* ClearedCountText;

	UPROPERTY()
	UTextBlock* ReplayLimitText;

	UPROPERTY()
	UImage* InfinityImage;

	UPROPERTY()
	UImage* TagStageTypeImage;

	UPROPERTY()
	UHorizontalBox* ClearCountBox;

	UPROPERTY()
	UBorder* ReplayBorder;

	UPROPERTY()
	UButton* RewardButton;

	UPROPERTY()
	UTextBlock* StageNumText;

	UPROPERTY()
	UTextBlock* StageNameText;

	UPROPERTY()
	UTextBlock* RecommendLevelText;

	UPROPERTY()
	USizeBox* InitialRewardBox;

	UPROPERTY()
	UItemWidget* InitialRewardIconWidget;

	UPROPERTY()
	UVerticalBox* StageNumBox;

	UPROPERTY()
	UTextBlock* StageText;

	UPROPERTY()
	UVerticalBox* StageIconBox;

	UPROPERTY()
	UTextBlock* MenuText;

	UPROPERTY()
	UImage* StageIconImage;

	UPROPERTY()
	UTextBlock* OpenConditionText;

	UPROPERTY()
	UImage* TagNewImage;

	UPROPERTY()
	UImage* TagClearImage;

	UPROPERTY()
	UCanvasPanel* LockCanvasPanel;

	UPROPERTY()
	UTextBlock* UnlockConditionText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* SetPlayableAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetDisableAnim;

	// Fields

	FSagaType SagaType;
	EStageState StageState;
	FTrainingCenterType TraingCenterType;
	FEventContentType EventContentType;
	int32 EventStageType;
};

UCLASS()
class UStageListWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UStageListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void InitStageList(int32 Episode);
	void InitEpisodeClearReward(int32 Episode);

private:
	UStageEntryWidget* FindOrAddStageEntry(int32 StageIdx);

private:
	// Widget classes.
	UPROPERTY(EditInstanceOnly, Category = "Stage")
	TSubclassOf<UStageEntryWidget> StageIconClass;

	// Widgets.
	UPROPERTY()
	UItemWidget* EpisodeReward;

	UPROPERTY()
	UUniformGridPanel* GridPanel;

	UPROPERTY()
	UImage* CharacterIcon;

	UPROPERTY()
	UScrollBox* StageListScrollBox;

	UPROPERTY()
	UTextBlock* CharacterStory;
};
