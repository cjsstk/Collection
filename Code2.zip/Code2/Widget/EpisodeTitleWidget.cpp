#include "EpisodeTitleWidget.h"
#include "Animation/UMGSequencePlayer.h"
#include "WidgetUtil.h"

UEpisodeTitleWidget::UEpisodeTitleWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UEpisodeTitleWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EpisodeNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextEpisodeName"));
	EpisodeNumText = CastChecked<UTextBlock>(GetWidgetFromName("TextEpisodeNum"));
	EpisodeStartAnim = GetWidgetAnimationFromName(this, "AnimEpisodeStart");
	EpisodeEndAnim = GetWidgetAnimationFromName(this, "AnimEpisodeEnd");
}

void UEpisodeTitleWidget::SetEpisodeTitle(const FText& Title)
{
	EpisodeNameText->SetText(Title);
	EpisodeNumText->SetVisibility(ESlateVisibility::Collapsed);
}

void UEpisodeTitleWidget::SetEpisodeTitle(int32 Episode)
{
	EpisodeNumText->SetText(FText::AsNumber(Episode));
}

void UEpisodeTitleWidget::Start()
{
	PlayAnimation(EpisodeStartAnim);
}

void UEpisodeTitleWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == EpisodeStartAnim)
	{
		PlayAnimation(EpisodeEndAnim);
	}
	else if (Animation == EpisodeEndAnim)
	{
		OnTitleEnd.ExecuteIfBound();
		SetVisibility(ESlateVisibility::Collapsed);
	}
}
