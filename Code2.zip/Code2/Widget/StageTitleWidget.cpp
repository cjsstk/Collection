#include "StageTitleWidget.h"
#include "Animation/UMGSequencePlayer.h"
#include "WidgetUtil.h"

UStageTitleWidget::UStageTitleWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UStageTitleWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StageNameText = Cast<UTextBlock>(GetWidgetFromName("TextStageName"));
	StageNumText = Cast<UTextBlock>(GetWidgetFromName("TextStageNum"));

	StageNameStartAnim = GetWidgetAnimationFromName(this, "AnimStageNameStart");
	StageNameEndAnim = GetWidgetAnimationFromName(this, "AnimStageNameEnd");
}

void UStageTitleWidget::SetStageTitle(const FCMSSagaRow& SagaRow)
{
	StageNameText->SetText(SagaRow.DescName);
	StageNumText->SetText(MakeStageNumberText(SagaRow));
}

void UStageTitleWidget::Start()
{
	PlayAnimation(StageNameStartAnim);
}

void UStageTitleWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == StageNameStartAnim)
	{
		PlayAnimation(StageNameEndAnim);
	}
	else if (Animation == StageNameEndAnim)
	{
		OnTitleEnd.ExecuteIfBound();
		SetVisibility(ESlateVisibility::Collapsed);
	}
}
