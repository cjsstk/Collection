// Copyright (c) 2020 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

#include "StoryWidgets.generated.h"

UCLASS()
class Q6_API UStoryEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetLock(bool bLock);
	void SetTitle(const FText& Name, const FText& SubName);

private:
	UFUNCTION()
	void OnStartButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* SetDefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetLockAnim;

	UPROPERTY()
	UTextBlock* StoryNameText;

	UPROPERTY()
	UTextBlock* StorySubNameText;
};

UCLASS()
class Q6_API UStoryListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetStoryList(EStoryMenuCategory InCategory);

private:
	void SetDailyDungeonList();
	void SetTrainingCenterList();
	void SetRaidList();
	void SetEventList();
	void SetMovieList();

	UPROPERTY()
	UImage* StoryBGImage;

	UPROPERTY()
	UTextBlock* StoryTitleNameText;

	UPROPERTY()
	UDynamicListWidget* StoryListWidget;
};

UCLASS()
class Q6_API UStoryMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetLock(bool bLock);
	void SetCategory(EStoryMenuCategory InCategory);

	FSimpleDelegate OnMenuClickedDelegate;

private:

	UFUNCTION()
	void OnMenuButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* SetUnlockAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SetLockAnim;

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UTextBlock* StoryTitleNameText;
};

UCLASS()
class Q6_API UStoryWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Story; }

private:
	void SetStoryMenu();

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void OnStoryMenuClicked(EStoryMenuCategory Category);

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	TArray<UStoryMenuWidget*> MenuWidgets;

	UPROPERTY()
	UStoryListWidget* StoryListWidget;
};
