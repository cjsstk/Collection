// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "PowerPlantWidgets.h"

#include "CMSTable.h"
#include "CommonWidgets.h"
#include "Q6Account.h"
#include "PointWidgets.h"
#include "PowerPlantManager.h"
#include "SystemConst_gen.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent PowerPlant"), STAT_OnHSEventByPowerPlant, STATGROUP_HSTORE);

void UWattStoreConfirmPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	OwnedWattWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedWatt"));
	OwnedWattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::NONE);

	OwnedGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedGold"));
	OwnedGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	RequiredWattWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredWatt"));
	RequiredWattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::NONE);

	RequiredGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredGold"));
	RequiredGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	StoreWattText = CastChecked<UQ6TextBlock>(GetWidgetFromName("StoreWatt"));
}

void UWattStoreConfirmPopupWidget::SetWattStore(int32 InStoreCount)
{
	StoreCount = InStoreCount;

	SetTitle(Q6Util::GetLocalizedText("Popup", "StoreWaterConfirmTitle"));

	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	OwnedGoldWidget->SetCurPoint(WorldUser.GetGold());
	OwnedWattWidget->SetCurPoint(WorldUser.GetWatt());

	int32 Level = GetHUDStore().GetPowerPlantManager().GetPowerPlant().Level;
	const FCMSPowerPlantRow& PowerPlantRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(Level));
	RequiredGoldWidget->SetCurPoint(PowerPlantRow.Cost * StoreCount);
	RequiredWattWidget->SetCurPoint(StoreCount * SystemConst::Q6_WATT_PER_STORE_COUNT);

	StoreWattText->SetText(FText::AsNumber(StoreCount * SystemConst::Q6_WATT_PER_STORE_COUNT));
}

void UWattStoreConfirmPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	Super::OnConfirmButtonClicked(Option);

	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetHUDStore().GetPowerPlantManager().ReqStore(StoreCount);
}

void UPowerPlantWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ResultBar = CastChecked<UProgressBar>(GetWidgetFromName("BarResult"));
	StoredBar = CastChecked<UProgressBar>(GetWidgetFromName("BarStored"));
	StoredWaterText = CastChecked<UQ6TextBlock>(GetWidgetFromName("StoredWater"));
	MaxWaterText = CastChecked<UQ6TextBlock>(GetWidgetFromName("MaxWater"));
	StoreBorder = CastChecked<UBorder>(GetWidgetFromName("BorderStore"));
	ResultWaterText = CastChecked<UQ6TextBlock>(GetWidgetFromName("ResultWater"));
	StoreWattText = CastChecked<UQ6TextBlock>(GetWidgetFromName("StoreWatt"));
	InfoText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Info"));

	OwnedWattWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedWatt"));
	OwnedWattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::NONE);

	OwnedGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedGold"));
	OwnedGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	RequiredWattWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredWatt"));
	RequiredWattWidget->SetPointType(EPointType::Watt, EPointWidgetOption::LessEqual);

	RequiredGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredGold"));
	RequiredGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);

	PlusButton = CastChecked<UButton>(GetWidgetFromName("Plus"));
	PlusButton->OnClicked.AddUniqueDynamic(this, &UPowerPlantWidget::OnPlusButtonClicked);

	MinusButton = CastChecked<UButton>(GetWidgetFromName("Minus"));
	MinusButton->OnClicked.AddUniqueDynamic(this, &UPowerPlantWidget::OnMinusButtonClicked);

	StoreButton = CastChecked<UButton>(GetWidgetFromName("Store"));
	StoreButton->OnClicked.AddUniqueDynamic(this, &UPowerPlantWidget::OnStoreButtonClicked);
}

void UPowerPlantWidget::OnMenuEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByPowerPlant);

	if (InAction->GetActionType() == EHSActionType::PowerPlantStoreResp)
	{
		SetWonder();

		//Roze-TODO
		//PlayStoreAnimation();
		return;
	}

	if (InAction->GetActionType() == EHSActionType::WattInfo)
	{
		auto Action = ACTION_PARSE_WattInfo(InAction);
		const FWattDiffInfo& WattDiff = Action->GetVal();
		RequiredWattWidget->SetMaxPoint(WattDiff.Watt);

		return;
	}
}

void UPowerPlantWidget::SetWonder()
{
	RefreshUI();
}

void UPowerPlantWidget::RefreshUI()
{
	const FPowerPlantInfo& PowerPlant = GetHUDStore().GetPowerPlantManager().GetPowerPlant();
	const FCMSPowerPlantRow& PowerPlantRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(PowerPlant.Level));
	if (PowerPlantRow.IsInvalid())
	{
		Q6JsonLogRoze(Error, "UPowerPlantWidget::SetWonder - Invalid power plant row");
		return;
	}

	StoreCount = (PowerPlant.StoredWater >= PowerPlantRow.Storage) ? 0 : 1;	// Set default store count

	StoredWaterText->SetText(FText::AsNumber(PowerPlant.StoredWater));

	MaxWaterText->SetText(FText::AsNumber(PowerPlantRow.Storage));
	MaxWaterText->SetColorAndOpacity((PowerPlant.StoredWater >= PowerPlantRow.Storage) ? StoredMaxColor : StorableColor);

	float StoredWaterRatio = (float)PowerPlant.StoredWater / PowerPlantRow.Storage;
	StoredBar->SetPercent(StoredWaterRatio);

	int32 OwnedWatt = GetHUDStore().GetWorldUser().GetWatt();
	int32 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedWattWidget->SetCurPoint(OwnedWatt);
	OwnedGoldWidget->SetCurPoint(OwnedGold);

	RequiredWattWidget->SetMaxPoint(OwnedWatt);
	RequiredGoldWidget->SetMaxPoint(OwnedGold);

	RefreshStoreWater(PowerPlant, PowerPlantRow);
}

void UPowerPlantWidget::RefreshStoreWater(const FPowerPlantInfo& PowerPlant, const FCMSPowerPlantRow& PowerPlantRow)
{
	int32 StoreWatt = StoreCount * SystemConst::Q6_WATT_PER_STORE_COUNT;
	int32 ResultWatt = PowerPlant.StoredWater + StoreWatt;

	// Set stored water

	float ResultWaterRatio = (float)ResultWatt / PowerPlantRow.Storage;
	ResultBar->SetPercent(ResultWaterRatio);

	UCanvasPanelSlot* PanelSlot = CastChecked<UCanvasPanelSlot>(ResultBar->Slot);
	float NewTransformY = (TopOffsetFromResultBar - PanelSlot->GetSize().Y) * ResultWaterRatio;
	StoreBorder->SetRenderTranslation(FVector2D(StoreBorder->RenderTransform.Translation.X, NewTransformY));

	ResultWaterText->SetText(FText::AsNumber(PowerPlant.StoredWater + StoreWatt));
	StoreWattText->SetText(FText::AsNumber(StoreWatt));

	// Set points

	int32 GoldCost = PowerPlantRow.Cost * StoreCount;
	RequiredGoldWidget->SetCurPoint(GoldCost);
	RequiredWattWidget->SetCurPoint(StoreWatt);

	// Set enable buttons

	int32 OwnedWatt = GetHUDStore().GetWorldUser().GetWatt();
	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	PlusButton->SetIsEnabled((StoreCount > 0) && (StoreWatt + SystemConst::Q6_WATT_PER_STORE_COUNT <= OwnedWatt) && (ResultWatt < PowerPlantRow.Storage));
	MinusButton->SetIsEnabled(StoreCount > 1);
	StoreButton->SetIsEnabled((OwnedWatt >= StoreWatt) && (OwnedGold >= GoldCost) && (StoreCount > 0));

	// Set info text
	if (StoreCount <= 0)
	{
		// Stored max

		InfoText->SetText(Q6Util::GetLocalizedText("Lobby", "StoredWaterMax"));
		InfoText->SetColorAndOpacity(StoredMaxColor);
		StoreBorder->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	StoreBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	ResultWaterText->SetColorAndOpacity(StoredColor);

	FString NotEnoughStr;
	if (OwnedWatt < StoreWatt)
	{
		NotEnoughStr = Q6Util::GetLocalizedText("Lobby", "NotEnoughWatt2").ToString();
		ResultWaterText->SetColorAndOpacity(LackColor);
	}

	if (OwnedGold < GoldCost)
	{
		if (!NotEnoughStr.IsEmpty())
		{
			NotEnoughStr.Append(", ");
		}

		NotEnoughStr.Append(Q6Util::GetLocalizedText("Lobby", "NotEnoughGold2").ToString());
	}

	if (!NotEnoughStr.IsEmpty())
	{
		InfoText->SetText(FText::FromString(NotEnoughStr));
		InfoText->SetColorAndOpacity(LackColor);
		return;
	}

	InfoText->SetText(Q6Util::GetLocalizedText("Lobby", "Storable"));
	InfoText->SetColorAndOpacity(StorableColor);
}

void UPowerPlantWidget::PlayStoreAnimation()
{
	//Roze-TODO
}

void UPowerPlantWidget::OnPlusButtonClicked()
{
	++StoreCount;

	const FPowerPlantInfo& PowerPlant = GetHUDStore().GetPowerPlantManager().GetPowerPlant();
	const FCMSPowerPlantRow& PowerPlantRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(PowerPlant.Level));

	RefreshStoreWater(PowerPlant, PowerPlantRow);
}

void UPowerPlantWidget::OnMinusButtonClicked()
{
	--StoreCount;

	const FPowerPlantInfo& PowerPlant = GetHUDStore().GetPowerPlantManager().GetPowerPlant();
	const FCMSPowerPlantRow& PowerPlantRow = GetCMS()->GetPowerPlantRowOrDummy(FPowerPlantType(PowerPlant.Level));

	RefreshStoreWater(PowerPlant, PowerPlantRow);
}

void UPowerPlantWidget::OnStoreButtonClicked()
{
	UWattStoreConfirmPopupWidget* WattStoreConfirmPopup = CastChecked<UWattStoreConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(WattStoreConfirmPopupClass));
	WattStoreConfirmPopup->SetWattStore(StoreCount);
}
