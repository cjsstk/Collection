// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatWidgets.h"

#include "BondManager.h"
#include "CharacterWidgets.h"
#include "CombatCube.h"
#include "CombatGameResource.h"
#include "CombatHUD.h"
#include "CombatPresenter.h"
#include "CombatReadyWidgets.h"
#include "CommonWidgets.h"
#include "DailyDungeonManager.h"
#include "ErrCode_gen.h"
#include "Formula.h"
#include "FriendManager.h"
#include "GameResource.h"
#include "HealthBarWidget.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "HUDStore/UserRecordManager.h"
#include "HUD/BaseHUD.h"
#include "ItemWidgets.h"
#include "LevelUtil.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6GameInstance.h"
#include "Q6GameState.h"
#include "RaidManager.h"
#include "RaidWidgets.h"
#include "RewardManager.h"
#include "Components/RichTextBlock.h"
#include "SagaManager.h"
#include "PetManager.h"
#include "SpecialManager.h"
#include "SkillWidgets.h"
#include "SystemConst_gen.h"
#include "TrainingCenterManager.h"
#include "Tutorial/CombatTutorial.h"
#include "WidgetUtil.h"
#include "LevelUtil.h"
#include "EventWidgets.h"
#include "HUDStore/EventManager.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent CombatResult"), STAT_OnHSEventByCombatResult, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent InitialRewardEvent"), STAT_OnHSEventByInitialRewardEvent, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent FriendRequestPopup"), STAT_OnHSEventByFriendRequestPopup, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent RaidTotalBar"), STAT_OnHSEventByRaidTotalBar, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent RaidEmoticon"), STAT_OnHSEventByRaidEmoticon, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent BondUpResult"), STAT_OnHSEventByBondUpResult, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////////////
// UBuffIconWidget

UBuffIconWidget::UBuffIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, BuffId(CCBuffIdInvalid.X)
	, bLocked(false)
{
}

void UBuffIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DefaultBuffAnim = GetWidgetAnimationFromName(this, "DefaultBuff");
	AddBuffAnim = GetWidgetAnimationFromName(this, "AppearBuff");
	RemovedBuffAnim = GetWidgetAnimationFromName(this, "RemoveBuff");
	ExpiredBuffAnim = GetWidgetAnimationFromName(this, "DisappearBuff");

	BuffIcon = CastChecked<UImage>(GetWidgetFromName("Buff"));
	MultipleText = CastChecked<UTextBlock>(GetWidgetFromName("Multiple"));
	LockedImage = CastChecked<UImage>(GetWidgetFromName("Locked"));
	MomentIcon = CastChecked<UImage>(GetWidgetFromName("Moment"));
}

void UBuffIconWidget::SetLocked(bool bInLocked)
{
	if (bLocked == bInLocked)
	{
		return;
	}

	bLocked = bInLocked;
	LockedImage->SetVisibility(bLocked ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UBuffIconWidget::SetMultipleText(int32 InMultiple)
{
	if (InMultiple > 1)
	{
		MultipleText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		MultipleText->SetText(FText::AsNumber(InMultiple));
	}
	else
	{
		MultipleText->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UBuffIconWidget::SetBuffIcon(const FBuffIcon& InBuffIcon, bool bInLocked /* = false */, int32 InBuffId /* = CCBuffIdInvalid.X */, int32 InMultiple /* = 0 */, bool bNew /* = false */, EMoment InMoment /* = EMoment::None */)
{
	BuffId = InBuffId;
	BuffIcon->SetBrush(InBuffIcon.Icon);

	SetLocked(bInLocked);
	SetMultipleText(InMultiple);

	StopAllAnimations();
	PlayAnimation(bNew ? AddBuffAnim : DefaultBuffAnim);

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	if (InMoment != EMoment::None)
	{
		MomentIcon->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		MomentIcon->SetBrush(GetCombatGameResource(this)->GetMomentIcon(InMoment).Icon);
	}
	else
	{
		MomentIcon->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UBuffIconWidget::SetCrowdControl(FCrowdControlType Type, bool bInLocked /* = false */, int32 InBuffId /* = CCBuffIdInvalid.X */, int32 InMultiple /* = 0 */, bool bNew /* = false */, EMoment InMoment /*= EMoment::None*/)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return;
	}

	SetBuffIcon(CombatGameResource->GetCrowdControlIcon(Type), bInLocked, InBuffId, InMultiple, bNew, InMoment);
}

void UBuffIconWidget::SetMoment(EMoment Moment, FSkillType MomentSkillType, bool bInLocked /* = false */, int32 InBuffId /* = CCBuffIdInvalid.X */, int32 InMultiple /* = 0 */, bool bNew /* = false */)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return;
	}

	const FCMSSkillRow& MomentSkillRow = GetCMS()->GetSkillRowOrDummy(MomentSkillType);
	for (const FCMSSkillEffectRow* Effect : MomentSkillRow.GetSkillEffect())
	{
		if (Effect && !Effect->IsInvalid())
		{
			// find the icon of follow moment skill (buff -> buffeffect / skill -> skilleffect)
			if (Effect->EffectCategory == EEffectCategory::Buff)
			{
				const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy((FBuffType)Effect->Param1);
				const TArray<const FCMSBuffEffectRow*>& BuffEffectRows = BuffRow.GetBuffEffect();
				for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
				{
					if (BuffEffectRow && !BuffEffectRow->IsInvalid())
					{
						if (BuffEffectRow->BuffEffectCategory == EBuffEffectCategory::ModifyUnitAttribute)
						{
							const FCMSUnitAttributeRow& Row = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType(BuffEffectRow->Param1));
							SetUnitAttributeBuff(Row.CmsType(), BuffEffectRow->Param2, bInLocked, InBuffId, InMultiple, bNew, Moment);
						}
						else if (BuffEffectRow->BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
						{
							const FCMSCrowdControlRow& CrowdControlRow = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
							SetCrowdControl(CrowdControlRow.CmsType(), bInLocked, InBuffId, InMultiple, bNew, Moment);
						}
						break;
					}
				}
			}
			else
			{
				SetBuffIcon(CombatGameResource->GetEffectCategoryIcon(Effect->EffectCategory, Effect->Param1), bInLocked, InBuffId, InMultiple, bNew, Moment);
			}
			break;
		}
	}
}

void UBuffIconWidget::SetUnitAttributeBuff(FUnitAttributeType Type, int32 Value, bool bInLocked /* = false */, int32 InBuffId /* = CCBuffIdInvalid.X */, int32 InMultiple /* = 0 */, bool bNew /* = false */, EMoment InMoment /*= EMoment::None*/)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return;
	}

	SetBuffIcon(CombatGameResource->GetUnitAttributeBuffIcon(Type, Value), bInLocked, InBuffId, InMultiple, bNew, InMoment);
}

void UBuffIconWidget::SetBuffRemoval()
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return;
	}

	SetBuffIcon(CombatGameResource->GetBuffRemovalIcon());
}

void UBuffIconWidget::SetPointVary(EPointVaryState PointVaryState)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return;
	}

	SetBuffIcon(CombatGameResource->GetPointVaryIcon(PointVaryState));
}

void UBuffIconWidget::RemoveBuff(ERemoveBuffReason Reason)
{
	BuffId = CCBuffIdInvalid.X;

	switch (Reason)
	{
		case ERemoveBuffReason::RemoveSkill:
			PlayAnimation(RemovedBuffAnim);
			break;
		case ERemoveBuffReason::TimeExpired:
			PlayAnimation(ExpiredBuffAnim);
			break;
		case ERemoveBuffReason::Overlap:
		default:
			ClearBuff();
			break;
	}
}

void UBuffIconWidget::ClearBuff()
{
	BuffId = CCBuffIdInvalid.X;
	SetVisibility(ESlateVisibility::Collapsed);
}

//////////////////////////////////////////////////////////////////////////////////
// UBuffIconListWidget

UBuffIconListWidget::UBuffIconListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UBuffIconListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	for (int32 n = 1; n <= MAX_BUFF_COUNT; ++n)
	{
		WidgetName = FString::Printf(TEXT("Buff%d"), n);
		BuffIcons.AddUnique(CastChecked<UBuffIconWidget>(GetWidgetFromName(*WidgetName)));
	}
}

void UBuffIconListWidget::SetEmpty()
{
	for (UBuffIconWidget* BuffIcon : BuffIcons)
	{
		BuffIcon->ClearBuff();
	}
}

void UBuffIconListWidget::SetBuffs(const TArray<FBuffState>& Buffs, const TArray<FPointVaryUnitAttributeState>& PointVaryUnitAttributes, const FCCBuffId& NewBuffId)
{
	if (Buffs.Num() <= 0)
	{
		SetEmpty();
		return;
	}

	int32 IconIndex = 0;
	for (const FBuffState& Buff : Buffs)
	{
		if (!BuffIcons.IsValidIndex(IconIndex))
		{
			break;
		}

		const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Buff.BuffType));
		bool bNew = Buff.BuffId == NewBuffId;

		if (BuffRow.FollowMoment != EMoment::None
			&& BuffRow.FollowMoment != EMoment::AtFirstSpawn
			&& BuffRow.FollowMoment != EMoment::AtSpawn)
		{
			const TArray<const FCMSSkillRow*> FollowMomentSkills = BuffRow.GetFollowMomentSkill();
			for (int32 i = 0; i < FollowMomentSkills.Num(); ++i)
			{
				if (!FollowMomentSkills[i]->IsInvalid())
				{
					BuffIcons[IconIndex]->SetMoment(BuffRow.FollowMoment, FollowMomentSkills[i]->CmsType(), BuffRow.Lock, Buff.BuffId.X, Buff.Multiple, bNew);
					++IconIndex;

					break;
				}
			}
		}

		const TArray<const FCMSBuffEffectRow*>& BuffEffectRows = BuffRow.GetBuffEffect();
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			if (!BuffIcons.IsValidIndex(IconIndex))
			{
				break;
			}

			check(BuffEffectRow);

			if (BuffEffectRow->BuffEffectCategory == EBuffEffectCategory::ModifyUnitAttribute)
			{
				const FCMSUnitAttributeRow& Row = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType(BuffEffectRow->Param1));
				BuffIcons[IconIndex]->SetUnitAttributeBuff(Row.CmsType(), BuffEffectRow->Param2, BuffRow.Lock, Buff.BuffId.X, Buff.Multiple, bNew);
				++IconIndex;
			}
			else if (BuffEffectRow->BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
			{
				const FCMSCrowdControlRow& Row = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
				if (Row.CrowdControl == ECrowdControl::Versa)
				{
					continue;
				}

				BuffIcons[IconIndex]->SetCrowdControl(Row.CmsType(), BuffRow.Lock, Buff.BuffId.X, Buff.Multiple, bNew);
				++IconIndex;
			}
			else
			{
				Q6JsonLogRoze(Error, "UBuffIconListWidget::SetBuffs - Not found buff effect category", Q6KV("EBuffEffectCategory", (int32)BuffEffectRow->BuffEffectCategory));
			}
		}
	}

	for (const FPointVaryUnitAttributeState& PointVaryUnitAttribute : PointVaryUnitAttributes)
	{
		if (!BuffIcons.IsValidIndex(IconIndex))
		{
			break;
		}

		BuffIcons[IconIndex]->SetUnitAttributeBuff(PointVaryUnitAttribute.UnitAttributeType, PointVaryUnitAttribute.Value, false, CCBuffIdInvalid.X, 0, true);
		++IconIndex;
		continue;
	}

	for (int32 ClearIconIndex = IconIndex; ClearIconIndex < BuffIcons.Num(); ++ClearIconIndex)
	{
		BuffIcons[ClearIconIndex]->ClearBuff();
	}
}

void UBuffIconListWidget::RemoveBuff(int32 BuffId, ERemoveBuffReason Reason)
{
	for (UBuffIconWidget* BuffIcon : BuffIcons)
	{
		if (BuffIcon->GetBuffId() == BuffId)
		{
			BuffIcon->RemoveBuff(Reason);
		}
	}
}

void UBuffIconListWidget::SetBuffMultiple(const FBuffState& BuffState)
{
	int32 NewMultiple = BuffState.Multiple;

	for (auto & BuffIcon : BuffIcons)
	{
		if ((FCCBuffId(BuffIcon->GetBuffId()) == BuffState.BuffId))
		{
			BuffIcon->SetMultipleText(NewMultiple);
			break;
		}
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatBarBuffNoticeWidget

UCombatBarBuffNoticeWidget::UCombatBarBuffNoticeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatBarBuffNoticeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BuffCreationAnim = GetWidgetAnimationFromName(this, "AnimBuffTaking");
	check(BuffCreationAnim);

	BuffExecutionAnim = GetWidgetAnimationFromName(this, "AnimBuffExecution");
	check(BuffExecutionAnim);

	BuffIconWidget = CastChecked<UBuffIconWidget>(GetWidgetFromName("BuffIcon"));
	BuffColorBorder = CastChecked<UBorder>(GetWidgetFromName("BuffBorder"));
	BuffText = CastChecked<URichTextBlock>(GetWidgetFromName("Buff"));
}

void UCombatBarBuffNoticeWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if ((Animation == BuffCreationAnim) || (Animation == BuffExecutionAnim))
	{
		OnNotiAnimFinishedDelegate.ExecuteIfBound();
	}
}

void UCombatBarBuffNoticeWidget::SetEmpty()
{
	StopAllAnimations();
	SetVisibility(ESlateVisibility::Collapsed);
}

void UCombatBarBuffNoticeWidget::PlayBuffNoticeAnimation(const FBuffEffectState& BuffEffectState, bool bCreation)
{
	const FCMSBuffEffectRow& BuffEffectRow = GetCMS()->GetBuffEffectRowOrDummy(BuffEffectState.EffectType);
	const FCMSCrowdControlRow& Row = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow.Param1));
	if (Row.IsInvalid())
	{
		Q6JsonLogSunny(Error, "UCombatBarBuffNoticeWidget::PlayBuffNoticeAnimation - invalid crowd control",
			Q6KV("BuffEffectType", BuffEffectState.EffectType.x),
			Q6KV("param1", BuffEffectRow.Param1));

		OnNotiAnimFinishedDelegate.ExecuteIfBound();
		return;
	}

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource)
	{
		const FBuffIcon& BuffIcon = CombatGameResource->GetCrowdControlIcon(Row.CmsType());
		BuffColorBorder->SetBrushColor(BuffIcon.BuffColor);
		BuffIconWidget->SetBuffIcon(BuffIcon, BuffEffectState.bLocked);
	}
	BuffText->SetText(BuildBuffEffectName(BuffEffectState.EffectType, true));

	PlayAnimation(bCreation ? BuffCreationAnim : BuffExecutionAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatBarBuffNoticeListWidget

UCombatBarBuffNoticeListWidget::UCombatBarBuffNoticeListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ExecutionIntervalTime(0.1f)
	, CreationIntervalTime(0.1f)
	, NoticeIndex(0)
	, bCreation(true)
{
}

void UCombatBarBuffNoticeListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	UCombatBarBuffNoticeWidget* NoticeWidget = nullptr;
	for (int32 n = 1; n <= BUFF_NOTI_COUNT_MAX; ++n)
	{
		WidgetName = FString::Printf(TEXT("Buff%d"), n);
		NoticeWidget = CastChecked<UCombatBarBuffNoticeWidget>(GetWidgetFromName(*WidgetName));
		NoticeWidget->OnNotiAnimFinishedDelegate.BindUObject(this, &UCombatBarBuffNoticeListWidget::OnBuffNotiAnimFinished);
		NoticeWidgets.AddUnique(NoticeWidget);
	}
}

void UCombatBarBuffNoticeListWidget::NativeDestruct()
{
	Super::NativeDestruct();

	GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
}

void UCombatBarBuffNoticeListWidget::OnBuffNotiAnimFinished()
{
	if (BuffEffectStates.Num() <= 0)
	{
		GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
		OnNotificationFinishedDelegate.ExecuteIfBound(bCreation);

		SetEmptyNotices(); // forced set empty for safety
	}
}

void UCombatBarBuffNoticeListWidget::SetEmptyNotices()
{
	NoticeIndex = 0;
	BuffEffectStates.Reset();

	for (UCombatBarBuffNoticeWidget* NoticeWidget : NoticeWidgets)
	{
		NoticeWidget->SetEmpty();
	}
}

void UCombatBarBuffNoticeListWidget::SetBuffs(const TArray<FBuffEffectState>& InBuffEffectStates, bool bInCreation)
{
	if (InBuffEffectStates.Num() <= 0)
	{
		return;
	}

	bCreation = bInCreation;

	SetEmptyNotices();
	for (const FBuffEffectState& BuffEffectState : InBuffEffectStates)
	{
		BuffEffectStates.Add(BuffEffectState);
	}

	GetWorld()->GetTimerManager().SetTimer(IntervalTimerHandle, this, &UCombatBarBuffNoticeListWidget::PlayBuffNotice,
		(bCreation ? CreationIntervalTime : ExecutionIntervalTime), true, 0.f);
}

void UCombatBarBuffNoticeListWidget::AddBuff(const FBuffEffectState& InBuffEffectState, bool bInCreation)
{
	if (InBuffEffectState.EffectType == BuffEffectTypeInvalid)
	{
		return;
	}

	bCreation = bInCreation;

	if (BuffEffectStates.Num() <= 0)
	{
		BuffEffectStates.Add(InBuffEffectState);

		GetWorld()->GetTimerManager().SetTimer(IntervalTimerHandle, this, &UCombatBarBuffNoticeListWidget::PlayBuffNotice,
			(bCreation ? CreationIntervalTime : ExecutionIntervalTime), true, 0.f);
		return;
	}

	BuffEffectStates.Add(InBuffEffectState);
}

void UCombatBarBuffNoticeListWidget::PlayBuffNotice()
{
	if (BuffEffectStates.Num() <= 0)
	{
		GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
		return;
	}

	FBuffEffectState BuffEffectState = BuffEffectStates[0];
	BuffEffectStates.RemoveAt(0);

	if (NoticeIndex == BUFF_NOTI_COUNT_MAX)
	{
		NoticeIndex = 0;
	}

	if (!NoticeWidgets.IsValidIndex(NoticeIndex))
	{
		Q6JsonLogSunny(Error, "UCombatBarBuffNoticeListWidget::PlayBuffNotice - invalid NoticeIndex",
			Q6KV("NoticeIndex", NoticeIndex));
		GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
		return;
	}

	NoticeWidgets[NoticeIndex++]->PlayBuffNoticeAnimation(BuffEffectState, bCreation);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitPositionWidget

UCombatUnitPositionWidget::UCombatUnitPositionWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bIsPlayingAnim(false)
{
}

void UCombatUnitPositionWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PlayAnim = GetWidgetAnimationFromName(this, "AnimPlay");
}

void UCombatUnitPositionWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == PlayAnim)
	{
		bIsPlayingAnim = false;
		OnPlayAnimFinishedDelegate.ExecuteIfBound();
	}
}

void UCombatUnitPositionWidget::SetEmpty()
{
	SetVisibility(ESlateVisibility::Collapsed);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitPositionListWidget

UCombatUnitPositionListWidget::UCombatUnitPositionListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, UnitId(CCUnitIdInvalid)
	, EntryIndex(0)
{
}

bool UCombatUnitPositionListWidget::SetPosition(FCCUnitId InUnitId, bool bFullView)
{
	UnitId = InUnitId;

	const ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	const AUnit* Unit = CombatPresenter->FindUnit(UnitId);
	if (!Unit)
	{
		return false;
	}

	FVector2D ViewportPosition;

	FVector SpawnPositionOffset = DefaultOffset;
	if (Unit->IsAttached())
	{
		SpawnPositionOffset += MultiLayerOffset;
	}
	else if (bFullView)
	{
		if (Unit->GetOverrideFaction() == ECCFaction::Enemy &&
			CombatPresenter->GetWaveEnemyNumSlots() == CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT &&
			Unit->GetUnitState().Slot == CENTER_SLOT)
		{
			SpawnPositionOffset += CenterSlotOffset;
		}
	}

	if (!GetCheckedCombatHUD(this)->GetViewportPosition(UnitId, UnitSocket::Center, SpawnPositionOffset, ReservedSize, ViewportPosition))
	{
		return false;
	}

	SetPositionInViewport(ViewportPosition);
	return true;
}

void UCombatUnitPositionListWidget::OnEntryPlayAnimFinished()
{
	// forced set empty for safety
	// keep it before delegate execute for next widget anim
	SetEmptyNotices();
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitNoticeBaseWidget

UCombatUnitNoticeBaseWidget::UCombatUnitNoticeBaseWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatUnitNoticeBaseWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EffectText = CastChecked<URichTextBlock>(GetWidgetFromName("Effect"));
	BuffIconWidget = CastChecked<UBuffIconWidget>(GetWidgetFromName("BuffIcon"));
	BackColorBorder = CastChecked<UBorder>(GetWidgetFromName("BackColor"));
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitNoticeListBaseWidget

UCombatUnitNoticeListBaseWidget::UCombatUnitNoticeListBaseWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, IntervalTime(0.1f)
{
}

void UCombatUnitNoticeListBaseWidget::NativeDestruct()
{
	Super::NativeDestruct();

	GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
}

void UCombatUnitNoticeListBaseWidget::OnEntryPlayAnimFinished()
{
	Super::OnEntryPlayAnimFinished();

	OnNotificationFinishedDelegate.ExecuteIfBound(UnitId);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitNoticeWidget

UCombatUnitNoticeWidget::UCombatUnitNoticeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatUnitNoticeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	HitCountText = CastChecked<URichTextBlock>(GetWidgetFromName("HitCount"));
	TurnCountText = CastChecked<URichTextBlock>(GetWidgetFromName("TurnCount"));
}

bool UCombatUnitNoticeWidget::SetBuffEffect(FBuffEffectType BuffEffectType, bool bInfinity, int32 Duration, bool bLocked, int32 HitCount, int32 BuffLevel, ESkillCategory BornCategory)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	const FCMSBuffEffectRow& BuffEffectRow = GetCMS()->GetBuffEffectRowOrDummy(BuffEffectType);
	if (BuffEffectRow.BuffEffectCategory == EBuffEffectCategory::ModifyUnitAttribute)
	{
		const FCMSUnitAttributeRow& Row = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType(BuffEffectRow.Param1));
		const FBuffIcon& BuffIcon = CombatGameResource->GetUnitAttributeBuffIcon(Row.CmsType(), BuffEffectRow.Param2);
		BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
		BuffIconWidget->SetBuffIcon(BuffIcon, bLocked);
	}
	else if (BuffEffectRow.BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
	{
		const FCMSCrowdControlRow& Row = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow.Param1));
		const FBuffIcon& BuffIcon = CombatGameResource->GetCrowdControlIcon(Row.CmsType());
		BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
		BuffIconWidget->SetBuffIcon(BuffIcon, bLocked);
	}
	else
	{
		return false;
	}

	EffectText->SetText(BuildToolTipBuffEffectDesc(BuffEffectType, BuffLevel, BornCategory, true));

	if (bInfinity)
	{
		FText BuffInfinityText = Q6Util::GetLocalizedText("Combat", "BuffTurnLoop");
		TurnCountText->SetText(BuffInfinityText);
	}
	else
	{
		FText BuffTurnText = Q6Util::GetLocalizedText("Combat", "BuffTurn");
		BuffTurnText = FText::Format(BuffTurnText, FText::AsNumber(Duration));
		TurnCountText->SetText(BuffTurnText);
	}

	if (HitCount > 0)
	{
		FText BuffHitText = Q6Util::GetLocalizedText("Combat", "BuffHit");
		BuffHitText = FText::Format(BuffHitText, FText::AsNumber(HitCount));
		HitCountText->SetText(BuffHitText);
	}
	else
	{
		HitCountText->SetText(FText::GetEmpty());
	}

	return true;
}

bool UCombatUnitNoticeWidget::SetBuffEffectRemoval(FBuffEffectType BuffEffectType, int32 BuffLevel, ESkillCategory BornCategory)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	const FBuffIcon& BuffIcon = CombatGameResource->GetBuffRemovalIcon();
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetBuffIcon(BuffIcon);

	const FCMSBuffEffectRow& BuffEffectRow = GetCMS()->GetBuffEffectRowOrDummy(BuffEffectType);
	FText BuffRemovalText = Q6Util::GetLocalizedText("Combat", "BuffRemoval");
	BuffRemovalText = FText::Format(BuffRemovalText, BuildToolTipBuffEffectDesc(BuffEffectType, BuffLevel, BornCategory, true));
	EffectText->SetText(BuffRemovalText);

	TurnCountText->SetText(FText::GetEmpty());
	HitCountText->SetText(FText::GetEmpty());

	return true;
}

bool UCombatUnitNoticeWidget::SetBuffMomentSkill(EMoment Moment, FSkillType MomentSkillType, bool bInfinity, int32 Duration, bool bLocked, int32 HitCount, int32 BuffLevel, ESkillCategory BornCategory)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	// back border color uses the moment icon's buff color
	const FBuffIcon& BuffIcon = CombatGameResource->GetMomentIcon(Moment);
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetMoment(Moment, MomentSkillType, bLocked);

	EffectText->SetText(BuildToolTipDesc(MomentSkillType, BuffLevel, BornCategory, true));

	if (bInfinity)
	{
		FText BuffInfinityText = Q6Util::GetLocalizedText("Combat", "BuffTurnLoop");
		TurnCountText->SetText(BuffInfinityText);
	}
	else
	{
		FText BuffTurnText = Q6Util::GetLocalizedText("Combat", "BuffTurn");
		BuffTurnText = FText::Format(BuffTurnText, FText::AsNumber(Duration));
		TurnCountText->SetText(BuffTurnText);
	}

	if (HitCount > 0)
	{
		FText BuffHitText = Q6Util::GetLocalizedText("Combat", "BuffHit");
		BuffHitText = FText::Format(BuffHitText, FText::AsNumber(HitCount));
		HitCountText->SetText(BuffHitText);
	}
	else
	{
		HitCountText->SetText(FText::GetEmpty());
	}

	return true;
}

bool UCombatUnitNoticeWidget::SetBuffMomentSkillRemoval(FSkillType MomentSkillType, int32 BuffLevel, ESkillCategory BornCategory)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	const FBuffIcon& BuffIcon = CombatGameResource->GetBuffRemovalIcon();
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetBuffIcon(BuffIcon);

	FText BuffRemovalText = Q6Util::GetLocalizedText("Combat", "BuffRemoval");
	BuffRemovalText = FText::Format(BuffRemovalText, BuildToolTipDesc(MomentSkillType, BuffLevel, BornCategory, true));
	EffectText->SetText(BuffRemovalText);

	TurnCountText->SetText(FText::GetEmpty());
	HitCountText->SetText(FText::GetEmpty());

	return true;
}

bool UCombatUnitNoticeWidget::SetBuffRemovalFailed(ERemoveBuffFailedReason RemoveFailedReason, EApplyTag NoApplyTag)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	const FBuffIcon& BuffIcon = CombatGameResource->GetBuffRemovalFailedIcon();
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetBuffIcon(BuffIcon);

	FText NoApplyTagText = GetCMS()->GetApplyTagDesc(NoApplyTag);
	FString RemoveFailedTextKey = FString::Printf(TEXT("RemoveBuffFailed%s"), *ENUM_TO_STRING(ERemoveBuffFailedReason, RemoveFailedReason));
	FText RemoveFailedText = Q6Util::GetLocalizedText("Combat", RemoveFailedTextKey);
	RemoveFailedText = FText::Format(RemoveFailedText, NoApplyTagText);
	EffectText->SetText(RemoveFailedText);

	TurnCountText->SetText(FText::GetEmpty());
	HitCountText->SetText(FText::GetEmpty());

	return true;
}

bool UCombatUnitNoticeWidget::SetBuffImmune(EApplyTag ImmuneTag)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	const FBuffIcon& BuffIcon = CombatGameResource->GetImmuneBuffIcon();
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetBuffIcon(BuffIcon);

	FText ImmuneTagText = GetCMS()->GetApplyTagDesc(ImmuneTag);
	FText ImmuneBuffText = Q6Util::GetLocalizedText("Combat", "ImmuneBuff");
	ImmuneBuffText = FText::Format(ImmuneBuffText, ImmuneTagText);
	EffectText->SetText(ImmuneBuffText);

	TurnCountText->SetText(FText::GetEmpty());
	HitCountText->SetText(FText::GetEmpty());

	return true;
}

void UCombatUnitNoticeWidget::PlayBuffNoticeAnimation(const FBuffNotice& BuffNotice)
{
	bool bValidNotice = false;
	switch (BuffNotice.NoticeType)
	{
		case EBuffNoticeType::AddBuff:
			{
				if (BuffNotice.IsMomentSkillNotice())
				{
					bValidNotice = SetBuffMomentSkill(BuffNotice.FollowMoment, BuffNotice.FollowMomentSkillType, BuffNotice.bInfinity, BuffNotice.Duration, BuffNotice.bLocked, BuffNotice.HitCount, BuffNotice.BuffLevel, BuffNotice.BornCategory);
				}
				else
				{
					bValidNotice = SetBuffEffect(BuffNotice.EffectType, BuffNotice.bInfinity, BuffNotice.Duration, BuffNotice.bLocked, BuffNotice.HitCount, BuffNotice.BuffLevel, BuffNotice.BornCategory);
				}
			}
			break;
		case EBuffNoticeType::RemoveBuff:
			{
				if (BuffNotice.IsMomentSkillNotice())
				{
					bValidNotice = SetBuffMomentSkillRemoval(BuffNotice.FollowMomentSkillType, BuffNotice.BuffLevel, BuffNotice.BornCategory);
				}
				else
				{
					bValidNotice = SetBuffEffectRemoval(BuffNotice.EffectType, BuffNotice.BuffLevel, BuffNotice.BornCategory);
				}
			}
			break;
		case EBuffNoticeType::RemoveBuffFailed:
			bValidNotice = SetBuffRemovalFailed(BuffNotice.RemoveFailedReason, BuffNotice.ApplyTag);
			break;
		case EBuffNoticeType::ImmuneBuff:
			bValidNotice = SetBuffImmune(BuffNotice.ApplyTag);
			break;
		default:
			break;
	}

	if (bValidNotice)
	{
		PlayAnimation(PlayAnim);
		bIsPlayingAnim = true;
	}
	else
	{
		OnPlayAnimFinishedDelegate.ExecuteIfBound();
		bIsPlayingAnim = false;
	}
}

bool UCombatUnitNoticeWidget::SetPointSkillEffect(const FPointNotice& PointNotice)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	const FBuffIcon& BuffIcon = CombatGameResource->GetPointVaryIcon(PointNotice.PointVaryState);
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetBuffIcon(BuffIcon);

	FString PointVaryTextKey = FString::Printf(TEXT("PointVary%s"), *ENUM_TO_STRING(EPointVaryState, PointNotice.PointVaryState));
	FText PointVaryText = Q6Util::GetLocalizedText("Combat", PointVaryTextKey);
	FText PointTypeText = Q6Util::GetLocalizedTextOrKey("Combat", PointNotice.TypeKeyString);
	PointVaryText = FText::Format(PointVaryText, PointTypeText, PointNotice.ValueText);
	EffectText->SetText(PointVaryText);

	if (PointNotice.bUnitAttribute)
	{
		FText BuffTurnText = Q6Util::GetLocalizedText("Combat", "BuffTurn");
		BuffTurnText = FText::Format(BuffTurnText, FText::AsNumber(1));
		TurnCountText->SetText(BuffTurnText);
	}
	else
	{
		TurnCountText->SetText(FText::GetEmpty());
	}
	HitCountText->SetText(FText::GetEmpty());

	return true;
}

void UCombatUnitNoticeWidget::PlayPointNoticeAnimation(const FPointNotice& PointNotice)
{
	if (SetPointSkillEffect(PointNotice))
	{
		PlayAnimation(PlayAnim);
		bIsPlayingAnim = true;
	}
	else
	{
		OnPlayAnimFinishedDelegate.ExecuteIfBound();
		bIsPlayingAnim = false;
	}
}

bool UCombatUnitNoticeWidget::SetSkillTimeEffect(const FSetSkillTimeNotice& InSkillTimeNotice)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	EPointVaryState PointVaryState;
	PointVaryState = InSkillTimeNotice.Value > 0 ? EPointVaryState::Consume : EPointVaryState::Convert;

	const FBuffIcon& BuffIcon = CombatGameResource->GetPointVaryIcon(PointVaryState);
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetBuffIcon(BuffIcon);

	FText PointTypeText = FText::GetEmpty();

	if (InSkillTimeNotice.SetSkillTimeType == ESetSkillTimeType::ChargeDown)
	{
		if (InSkillTimeNotice.Value >= 0)
		{
			PointTypeText = Q6Util::GetLocalizedText("Combat", "ChargedownUp");
		}
		else
		{
			PointTypeText = Q6Util::GetLocalizedText("Combat", "ChargedownDown");
		}
		
		EffectText->SetText(FText::Format(PointTypeText, FText::AsNumber(FMath::Abs(InSkillTimeNotice.Value))));
	}
	else if (InSkillTimeNotice.SetSkillTimeType == ESetSkillTimeType::Cooldown)
	{
		if (InSkillTimeNotice.Value >= 0)
		{
			PointTypeText = Q6Util::GetLocalizedText("Combat", "CooldownUp");
		}
		else
		{
			PointTypeText = Q6Util::GetLocalizedText("Combat", "CooldownDown");
		}

		EffectText->SetText(FText::Format(PointTypeText, FText::AsNumber(FMath::Abs(InSkillTimeNotice.Value))));
	}
	else
	{
		Q6JsonLogGunny(Warning, "UCombatUnitNoticeWidget::SetSkillTimeEffect - FSetSkillTimeNotice::SetSkillTimeType is invalid");
	}

	TurnCountText->SetText(FText::GetEmpty());
	HitCountText->SetText(FText::GetEmpty());

	return true;
}

void UCombatUnitNoticeWidget::PlaySetSkillTimeAnimation(const FSetSkillTimeNotice& InSetSkillTimeNotice)
{
	if (SetSkillTimeEffect(InSetSkillTimeNotice))
	{
		PlayAnimation(PlayAnim);
		bIsPlayingAnim = true;
	}
	else
	{
		OnPlayAnimFinishedDelegate.ExecuteIfBound();
		bIsPlayingAnim = false;
	}
}

bool UCombatUnitNoticeWidget::SetImmediateKillSkillEffect()
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return false;
	}

	const FBuffIcon& BuffIcon = CombatGameResource->GetImmediateKillIcon();
	BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
	BuffIconWidget->SetBuffIcon(BuffIcon);

	EffectText->SetText(Q6Util::GetLocalizedText("Combat", "ImmediateKill"));

	TurnCountText->SetText(FText::GetEmpty());
 	HitCountText->SetText(FText::GetEmpty());

	return true;
}

void UCombatUnitNoticeWidget::PlayImmediateKillNoticeAnimation()
{
	if (SetImmediateKillSkillEffect())
	{
		PlayAnimation(PlayAnim);
		bIsPlayingAnim = true;
	}
	else
	{
		OnPlayAnimFinishedDelegate.ExecuteIfBound();
		bIsPlayingAnim = false;
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitNoticeListWidget

UCombatUnitNoticeListWidget::UCombatUnitNoticeListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatUnitNoticeListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	UCombatUnitNoticeWidget* NoticeWidget = nullptr;
	for (int32 n = 1; n <= UNIT_NOTI_COUNT_MAX; ++n)
	{
		WidgetName = FString::Printf(TEXT("Notice%d"), n);
		NoticeWidget = CastChecked<UCombatUnitNoticeWidget>(GetWidgetFromName(*WidgetName));
		NoticeWidget->OnPlayAnimFinishedDelegate.BindUObject(this, &UCombatUnitNoticeListWidget::OnEntryPlayAnimFinished);
		NoticeWidgets.AddUnique(NoticeWidget);
	}
}

void UCombatUnitNoticeListWidget::OnEntryPlayAnimFinished()
{
	for (UCombatUnitNoticeWidget* NoticeWidget : NoticeWidgets)
	{
		if (NoticeWidget->IsPlayingAnim())
		{
			return;
		}
	}

	Super::OnEntryPlayAnimFinished();
}

void UCombatUnitNoticeListWidget::SetEmptyNotices()
{
	Super::SetEmptyNotices();

	BuffNotices.Reset();
	PointNotices.Reset();

	for (UCombatUnitNoticeWidget* NoticeWidget : NoticeWidgets)
	{
		NoticeWidget->SetEmpty();
	}
}

void UCombatUnitNoticeListWidget::SetBuffNotices(EBuffNoticeType BuffNoticeType, const FBuffType& BuffType, int32 BuffLevel, ESkillCategory BornCategory)
{
	const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy(BuffType);

	const TArray<const FCMSBuffEffectRow*> BuffEffectRows = BuffRow.GetBuffEffect();
	for (int32 i = 0; i < BuffEffectRows.Num(); ++i)
	{
		FBuffEffectType BuffEffectType = BuffEffectRows[i]->CmsType();
		if (BuffEffectType == BuffEffectTypeInvalid)
		{
			continue;
		}

		BuffNotices.Add(FBuffNotice(BuffNoticeType, BuffRow.Infinity, BuffRow.Duration, BuffRow.Lock, BuffRow.HitCount, BuffEffectType, BuffLevel, BornCategory));
	}

	if (BuffRow.FollowMoment != EMoment::None
		&& BuffRow.FollowMoment != EMoment::AtFirstSpawn
		&& BuffRow.FollowMoment != EMoment::AtSpawn)
	{
		const TArray<const FCMSSkillRow*> FollowMomentSkills = BuffRow.GetFollowMomentSkill();
		for (int32 i = 0; i < FollowMomentSkills.Num(); ++i)
		{
			FSkillType MomentSkillType = FollowMomentSkills[i]->CmsType();
			if (MomentSkillType == SkillTypeInvalid)
			{
				continue;
			}

			BuffNotices.Add(FBuffNotice(BuffNoticeType, BuffRow.Infinity, BuffRow.Duration, BuffRow.Lock, BuffRow.HitCount, BuffRow.FollowMoment, MomentSkillType, BuffLevel, BornCategory));
		}
	}

	if (!BuffNotices.Num())
	{
		OnEntryPlayAnimFinished();
		return;
	}

	SetNoticeInternal();
}

void UCombatUnitNoticeListWidget::SetBuffRemovalFailedNotice(ERemoveBuffFailedReason Reason, EApplyTag NoApplyTag)
{
	BuffNotices.Add(FBuffNotice(Reason, NoApplyTag));

	SetNoticeInternal();
}

void UCombatUnitNoticeListWidget::SetBuffImmuneNotice(EApplyTag ImmuneTag)
{
	BuffNotices.Add(FBuffNotice(ImmuneTag));

	SetNoticeInternal();
}

void UCombatUnitNoticeListWidget::SetPointNotice(EPointVaryState PointVaryState, const FString& TypeKeyStr, const FText& ValueText, bool bUnitAttribute)
{
	PointNotices.Add(FPointNotice(PointVaryState, TypeKeyStr, ValueText, bUnitAttribute));

	SetNoticeInternal();
}

void UCombatUnitNoticeListWidget::SetSkillTimeNotice(ESetSkillTimeType SetSkillTimeType, int32 Value)
{
	SetSkillTimeNotices.Add(FSetSkillTimeNotice(SetSkillTimeType, Value));

	SetNoticeInternal();
}

void UCombatUnitNoticeListWidget::SetNoticeInternal()
{
	if (!IntervalTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().SetTimer(IntervalTimerHandle, this, &UCombatUnitNoticeListWidget::PlayNotices,
			IntervalTime, true, 0.f);
	}
}

bool UCombatUnitNoticeListWidget::PlayBuffNotice()
{
	if (BuffNotices.Num() <= 0)
	{
		return false;
	}

	FBuffNotice BuffNotice = BuffNotices[0];
	BuffNotices.RemoveAt(0);

	if (EntryIndex == UNIT_NOTI_COUNT_MAX)
	{
		EntryIndex = 0;
	}

	if (!NoticeWidgets.IsValidIndex(EntryIndex))
	{
		Q6JsonLogSunny(Error, "UCombatUnitNoticeListWidget::PlayBuffNotice - EntryIndex is invalid",
			Q6KV("EntryIndex", EntryIndex));

		OnEntryPlayAnimFinished();
		return false;
	}

	NoticeWidgets[EntryIndex++]->PlayBuffNoticeAnimation(BuffNotice);

	return true;
}

bool UCombatUnitNoticeListWidget::PlayPointNotice()
{
	if (PointNotices.Num() <= 0)
	{
		return false;
	}

	FPointNotice PointNotice = PointNotices[0];
	PointNotices.RemoveAt(0);

	if (EntryIndex == UNIT_NOTI_COUNT_MAX)
	{
		EntryIndex = 0;
	}

	if (!NoticeWidgets.IsValidIndex(EntryIndex))
	{
		Q6JsonLogSunny(Error, "UCombatUnitNoticeListWidget::PlayPointNotice - EntryIndex is invalid",
			Q6KV("EntryIndex", EntryIndex));

		OnEntryPlayAnimFinished();
		return false;
	}

	NoticeWidgets[EntryIndex++]->PlayPointNoticeAnimation(PointNotice);

	return true;
}

bool UCombatUnitNoticeListWidget::PlaySkillTimeNotice()
{
	if (SetSkillTimeNotices.Num() <= 0)
	{
		return false;
	}

	FSetSkillTimeNotice SkillTimeNotice = SetSkillTimeNotices[0];
	SetSkillTimeNotices.RemoveAt(0);

	if (EntryIndex == UNIT_NOTI_COUNT_MAX)
	{
		EntryIndex = 0;
	}

	if (!NoticeWidgets.IsValidIndex(EntryIndex))
	{
		Q6JsonLogGunny(Error, "UCombatUnitNoticeListWidget::PlaySkillTimeNotice - EntryIndex is invalid",
			Q6KV("EntryIndex", EntryIndex));

		OnEntryPlayAnimFinished();
		return false;
	}

	if (SkillTimeNotice.SetSkillTimeType == ESetSkillTimeType::ChargeDown)
	{
		GetCheckedCombatHUD(this)->RefreshEnemyBarWidget(UnitId);
	}

	NoticeWidgets[EntryIndex++]->PlaySetSkillTimeAnimation(SkillTimeNotice);

	return true;
}

bool UCombatUnitNoticeListWidget::PlayImmediateKillNotice()
{
	if (EntryIndex == UNIT_NOTI_COUNT_MAX)
	{
		EntryIndex = 0;
	}

	if (!NoticeWidgets.IsValidIndex(EntryIndex))
	{
		Q6JsonLogSunny(Error, "UCombatUnitBuffNoticeListWidget::PlayImmediateKillNotice - EntryIndex is invalid",
			Q6KV("EntryIndex", EntryIndex));

		OnEntryPlayAnimFinished();
		return false;
	}

	NoticeWidgets[EntryIndex++]->PlayImmediateKillNoticeAnimation();

	return true;
}

void UCombatUnitNoticeListWidget::PlayNotices()
{
	if (PlayBuffNotice())
	{
		return;
	}

	if (PlayPointNotice())
	{
		return;
	}

	if (PlaySkillTimeNotice())
	{
		return;
	}

	GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitStateNoticeWidget

UCombatUnitStateNoticeWidget::UCombatUnitStateNoticeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatUnitStateNoticeWidget::PlayBuffNoticeAnimation(const FBuffEffectState& BuffEffectState)
{
	const FCMSBuffEffectRow& BuffEffectRow = GetCMS()->GetBuffEffectRowOrDummy(BuffEffectState.EffectType);
	const FCMSCrowdControlRow& Row = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow.Param1));
	if (Row.IsInvalid())
	{
		Q6JsonLogSunny(Error, "UCombatUnitStateNoticeWidget::PlayBuffNoticeAnimation - invalid crowd control",
			Q6KV("BuffEffectType", BuffEffectState.EffectType.x),
			Q6KV("param1", BuffEffectRow.Param1));

		OnPlayAnimFinishedDelegate.ExecuteIfBound();
		return;
	}

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource)
	{
		const FBuffIcon& BuffIcon = CombatGameResource->GetCrowdControlIcon(Row.CmsType());
		BackColorBorder->SetBrushColor(BuffIcon.BuffColor);
		BuffIconWidget->SetBuffIcon(BuffIcon, BuffEffectState.bLocked);
	}
	EffectText->SetText(BuildBuffEffectName(BuffEffectState.EffectType, true));

	PlayAnimation(PlayAnim);
	bIsPlayingAnim = true;
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitStateNoticeListWidget

UCombatUnitStateNoticeListWidget::UCombatUnitStateNoticeListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatUnitStateNoticeListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	UCombatUnitStateNoticeWidget* NoticeWidget = nullptr;
	for (int32 n = 1; n <= BUFF_NOTI_COUNT_MAX; ++n)
	{
		WidgetName = FString::Printf(TEXT("Notice%d"), n);
		NoticeWidget = CastChecked<UCombatUnitStateNoticeWidget>(GetWidgetFromName(*WidgetName));
		NoticeWidget->OnPlayAnimFinishedDelegate.BindUObject(this, &UCombatUnitStateNoticeListWidget::OnEntryPlayAnimFinished);
		NoticeWidgets.AddUnique(NoticeWidget);
	}
}

void UCombatUnitStateNoticeListWidget::OnEntryPlayAnimFinished()
{
	if (BuffEffectStates.Num() <= 0)
	{
		Super::OnEntryPlayAnimFinished();
	}
}

void UCombatUnitStateNoticeListWidget::SetEmptyNotices()
{
	Super::SetEmptyNotices();

	BuffEffectStates.Reset();

	for (UCombatUnitStateNoticeWidget* NoticeWidget : NoticeWidgets)
	{
		NoticeWidget->SetEmpty();
	}
}

void UCombatUnitStateNoticeListWidget::AddBuffNotice(const FBuffEffectState& BuffEffectState)
{
	if (BuffEffectState.EffectType == BuffEffectTypeInvalid)
	{
		return;
	}

	BuffEffectStates.Add(BuffEffectState);

	if (!IntervalTimerHandle.IsValid())
	{
		GetWorld()->GetTimerManager().SetTimer(IntervalTimerHandle, this, &UCombatUnitStateNoticeListWidget::PlayBuffNotice,
			IntervalTime, true, 0.f);
	}
}

void UCombatUnitStateNoticeListWidget::PlayBuffNotice()
{
	if (BuffEffectStates.Num() <= 0)
	{
		GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
		OnNotificationStartDelegate.ExecuteIfBound(UnitId);
		return;
	}

	FBuffEffectState BuffEffectState = BuffEffectStates[0];
	BuffEffectStates.RemoveAt(0);

	if (EntryIndex == BUFF_NOTI_COUNT_MAX)
	{
		EntryIndex = 0;
	}

	if (!NoticeWidgets.IsValidIndex(EntryIndex))
	{
		Q6JsonLogSunny(Error, "UCombatUnitStateNoticeListWidget::PlayBuffNotice - invalid EntryIndex",
			Q6KV("EntryIndex", EntryIndex));

		GetWorld()->GetTimerManager().ClearTimer(IntervalTimerHandle);
		OnEntryPlayAnimFinished();
		return;
	}

	NoticeWidgets[EntryIndex++]->PlayBuffNoticeAnimation(BuffEffectState);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitApplyEffectLabelWidget

UCombatUnitApplyEffectLabelWidget::UCombatUnitApplyEffectLabelWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Moment(EMoment::None)
{
}

void UCombatUnitApplyEffectLabelWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EffectText = CastChecked<UTextBlock>(GetWidgetFromName("Effect"));
}

void UCombatUnitApplyEffectLabelWidget::SetEmpty()
{
	Super::SetEmpty();

	Moment = EMoment::None;
}

bool UCombatUnitApplyEffectLabelWidget::IsSameMomentLabel(EMoment InMoment) const
{
	if (InMoment == EMoment::AtFirstSpawn && Moment == EMoment::AtSpawn)
	{
		return true;
	}
	if (InMoment == EMoment::AtSpawn && Moment == EMoment::AtFirstSpawn)
	{
		return true;
	}

	return InMoment == Moment;
}

void UCombatUnitApplyEffectLabelWidget::PlayMomentLabel(EMoment InMoment)
{
	Moment = InMoment;

	FText MomentEffectText = Q6Util::GetLocalizedText("Combat", "MomentEffect");
	FText MomentText = Q6Util::GetLocalizedText("Combat", ENUM_TO_STRING(EMoment, InMoment));
	MomentEffectText = FText::Format(MomentEffectText, MomentText);

	EffectText->SetText(MomentEffectText);

	StopAnimation(PlayAnim);
	PlayAnimation(PlayAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitApplyEffectLabelListWidget

UCombatUnitApplyEffectLabelListWidget::UCombatUnitApplyEffectLabelListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatUnitApplyEffectLabelListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	UCombatUnitApplyEffectLabelWidget* LabelWidget = nullptr;
	for (int32 n = 1; n <= UNIT_APPLY_EFFECT_LABEL_COUNT_MAX; ++n)
	{
		WidgetName = FString::Printf(TEXT("Label%d"), n);
		LabelWidget = CastChecked<UCombatUnitApplyEffectLabelWidget>(GetWidgetFromName(*WidgetName));
		LabelWidget->OnPlayAnimFinishedDelegate.BindUObject(this, &UCombatUnitApplyEffectLabelListWidget::OnEntryPlayAnimFinished);
		LabelWidgets.AddUnique(LabelWidget);
	}
}

void UCombatUnitApplyEffectLabelListWidget::SetEmptyNotices()
{
	Super::SetEmptyNotices();

	for (UCombatUnitApplyEffectLabelWidget* LabelWidget : LabelWidgets)
	{
		LabelWidget->SetEmpty();
	}
}

void UCombatUnitApplyEffectLabelListWidget::AddMomentLabel(EMoment InMoment)
{
	if (InMoment == EMoment::None)
	{
		return;
	}

	if (!LabelWidgets.IsValidIndex(EntryIndex))
	{
		Q6JsonLogSunny(Error, "UCombatUnitApplyEffectLabelListWidget::AddMomentLabel - invalid EntryIndex",
			Q6KV("EntryIndex", EntryIndex));

		OnEntryPlayAnimFinished();
		return;
	}

	for (int32 i = 0; i < EntryIndex; ++i)
	{
		if (LabelWidgets[i]->IsSameMomentLabel(InMoment))
		{
			return;
		}
	}

	LabelWidgets[EntryIndex++]->PlayMomentLabel(InMoment);
}

void UCombatUnitApplyEffectLabelListWidget::OnEntryPlayAnimFinished()
{
	for (UCombatUnitApplyEffectLabelWidget* LabelWidget : LabelWidgets)
	{
		if (LabelWidget->IsPlayingAnim())
		{
			return;
		}
	}

	Super::OnEntryPlayAnimFinished();
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatAttackButtonWidget

UCombatAttackButtonWidget::UCombatAttackButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatAttackButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TurnStartAnim = GetWidgetAnimationFromName(this, "AnimAttBtnTurnStart");
	TurnEndAnim = GetWidgetAnimationFromName(this, "AnimAttBtnTurnEnd");

	UButton* AttackButton = CastChecked<UButton>(GetWidgetFromName("AttackBtn"));
	AttackButton->OnClicked.AddUniqueDynamic(this, &UCombatAttackButtonWidget::OnAttackButtonClicked);
}

void UCombatAttackButtonWidget::SetAttackButtonEnabled(bool bInEnabled)
{
	StopAllAnimations();
	PlayAnimation(bInEnabled ? TurnStartAnim : TurnEndAnim);
}

void UCombatAttackButtonWidget::OnAttackButtonClicked()
{
	OnAttackButtonClickedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatSkillCastingNameWidget

UCombatSkillCastingNameWidget::UCombatSkillCastingNameWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatSkillCastingNameWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkillIntroAnim = GetWidgetAnimationFromName(this, "AnimSkillIntro");
	SkillOutroAnim = GetWidgetAnimationFromName(this, "AnimSkillOutro");
	AllyPositionAnim = GetWidgetAnimationFromName(this, "AnimAllyPosition");
	EnemyPositionAnim = GetWidgetAnimationFromName(this, "AnimEnemyPosition");

	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SkillName"));
}

void UCombatSkillCastingNameWidget::SetSkill(const FText& InSkillName, ECCFaction InFaction)
{
	SkillNameText->SetText(InSkillName);
	PlayAnimation(InFaction == ECCFaction::Ally ? AllyPositionAnim : EnemyPositionAnim);
}

void UCombatSkillCastingNameWidget::SetSkillEnabled(bool bInEnabled)
{
	PlayAnimation(bInEnabled ? SkillIntroAnim : SkillOutroAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatSkillFailedWidget

UCombatSkillFailedWidget::UCombatSkillFailedWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatSkillFailedWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkillFailedStartAnim = GetWidgetAnimationFromName(this, "AnimSkillFailedStart");

	SkillFailedText = CastChecked<UTextBlock>(GetWidgetFromName("TextSkillFailed"));
}

void UCombatSkillFailedWidget::SetSkillFailed(int32 SkillTypeX, const FApplyTagFailedInfo& FailedInfo)
{
	const UCMS* CMS = GetCMS();

	EApplyTag FailedTag = EApplyTag::None;
	if (FailedInfo.Reason == EApplyTagFailedReason::ApplyTagNotEquals)
	{
		FailedTag = FailedInfo.ReasonTag;
	}
	else
	{
		const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillTypeX);
		FailedTag = SkillRow.ApplyTagEquals.Num() ? SkillRow.ApplyTagEquals[0] : EApplyTag::None;
	}

	FText ReasonTagDescText = CMS->GetApplyTagDesc(FailedTag);
	FText MsgText = FText::GetEmpty();
	if (ReasonTagDescText.IsEmpty() || FailedInfo.Reason == EApplyTagFailedReason::None)
	{
		// default msg
		MsgText = Q6Util::GetLocalizedText("Combat", TEXT("SkillFailedDefault"));
	}
	else
	{
		FString SkillFailedTextKey = FString::Printf(TEXT("SkillFailed%s"), *ENUM_TO_STRING(EApplyTagFailedReason, FailedInfo.Reason));
		MsgText = Q6Util::GetLocalizedText("Combat", SkillFailedTextKey);
		MsgText = FText::Format(MsgText, ReasonTagDescText);
	}

	SkillFailedText->SetText(MsgText);
	PlayAnimation(SkillFailedStartAnim);
}

void UCombatSkillFailedWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == SkillFailedStartAnim)
	{
		OnSkillFaildAnimFinishedDelegate.ExecuteIfBound();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatPointWidget

UCombatPointWidget::UCombatPointWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatPointWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BubbleOnAnim = GetWidgetAnimationFromName(this, "AnimBubbleOn");
	BubbleOffAnim = GetWidgetAnimationFromName(this, "AnimBubbleOff");
}

void UCombatPointWidget::SetPointEnabled(bool bInEnabled)
{
	PlayAnimation(bInEnabled ? BubbleOnAnim : BubbleOffAnim);
}


//////////////////////////////////////////////////////////////////////////////////
// UCombatPointListWidget

UCombatPointListWidget::UCombatPointListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatPointListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FString WidgetName;
	UCombatPointWidget*  PointWidget = nullptr;

	for (int32 n = 1; n <= MAX_ULTIMATE_SKILL_COOLDOWN; ++n)
	{
		WidgetName = FString::Printf(TEXT("Point%d"), n);
		PointWidget = CastChecked<UCombatPointWidget>(GetWidgetFromName(*WidgetName));

		PointWidgets.AddUnique(PointWidget);
	}

	MaxCooldown = MAX_ULTIMATE_SKILL_COOLDOWN;
}

void UCombatPointListWidget::SetCooldown(int32 InCooldown)
{
	for (int32 i = 0; i < PointWidgets.Num(); ++i)
	{
		PointWidgets[i]->SetPointEnabled(i < InCooldown);
	}
}

void UCombatPointListWidget::SetMaxCooldown(int32 InMaxCooldown)
{
	MaxCooldown = InMaxCooldown;
	for (int32 i = 0; i < PointWidgets.Num(); ++i)
	{
		PointWidgets[i]->SetVisibility(i < MaxCooldown ?
			ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

int32 UCombatPointListWidget::GetMaxCooldown() const
{
	return MaxCooldown;
}


//////////////////////////////////////////////////////////////////////////////////
// UCombatNatureRelationWidget

UCombatNatureRelationWidget::UCombatNatureRelationWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatNatureRelationWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RelationAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimTargetS"));
	RelationAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimTargetN"));
	RelationAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimTargetW"));

	DisabledAnim = GetWidgetAnimationFromName(this, "AnimTargetNone");

	RelationIconImage = CastChecked<UImage>(GetWidgetFromName("RelationIcon"));
}

void UCombatNatureRelationWidget::SetNatureRelation(ECCFaction SourceFaction, ENatureType SourceType, ENatureType TargetType)
{
	const UQ6GameInstance* GameInstance = UQ6GameInstance::Get(this);
	const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();

	ENatureRelationType RelationType = Formula::GetNatureRelationType(GetCMS(), SourceFaction, SourceType, TargetType, CombatSeed.SagaType);
	const FNatureRelation& NatureRelation = GetUIResource().GetNatureRelation(RelationType);
	RelationIconImage->SetBrush(NatureRelation.RelationImage);

	if (RelationAnims.IsValidIndex((int32)RelationType))
	{
		PlayAnimation(RelationAnims[(int32)RelationType]);
	}
}

void UCombatNatureRelationWidget::DisableNatureRelation()
{
	PlayAnimation(DisabledAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatNameBarWidget

UCombatNameBarWidget::UCombatNameBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatNameBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NatureChangeAnim = GetWidgetAnimationFromName(this, "AnimNatureChange");
	NatureIconImage = CastChecked<UImage>(GetWidgetFromName("NatureIcon"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("TextLevel"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("TextName"));
	HPBarWidget = CastChecked<UHealthBarWidget>(GetWidgetFromName("HPBar"));
	ShieldBarWidget = CastChecked<UShieldBarWidget>(GetWidgetFromName("ShieldBar"));
}

void UCombatNameBarWidget::InitBar(const FUnitState& UnitState)
{
	GetUIResource().SetNatureTypeIcon(NatureIconImage, UnitState.NatureType, false);
	LevelText->SetText(FText::AsNumber(UnitState.Level));

	HPBarWidget->InitHealthBar(UnitState);

	if (UnitState.Shield)
	{
		ShieldBarWidget->InitShieldBar(HPBarWidget, UnitState.Shield, UnitState.MaxShield, false);
	}
	else
	{
		ShieldBarWidget->SetShieldState(HPBarWidget, false, false);
	}

	if (UnitState.UnitType == UnitTypeInvalid.x)
	{
		Q6JsonLogSunny(Warning, "UCombatNameBarWidget::Init - Invalid UnitType", Q6KV("UnitType", UnitState.UnitType));
		return;
	}

	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(FUnitType(UnitState.UnitType));
	NameText->SetText(UnitRow.DescName);
}

void UCombatNameBarWidget::SetHealthState(int32 InNewHealth, EHealthChangeReason Reason, int32 InHitIndex, int32 InHitMax, bool bAlly)
{
	HPBarWidget->SetHealthState(InNewHealth, Reason, InHitIndex, InHitMax, bAlly);
}

void UCombatNameBarWidget::InitShieldBar(int32 InShield, int32 InMaxShield)
{
	ShieldBarWidget->InitShieldBar(HPBarWidget, InShield, InMaxShield, true);
}

void UCombatNameBarWidget::SetShieldState(bool bActivate)
{
	ShieldBarWidget->SetShieldState(HPBarWidget, bActivate, true);
}

void UCombatNameBarWidget::SetShieldDamage(int32 InShieldDamage, int32 InExtraShieldDamage, bool bInShieldWeakPoint)
{
	ShieldBarWidget->SetShieldDamage(HPBarWidget, InShieldDamage, InExtraShieldDamage, bInShieldWeakPoint);
}

void UCombatNameBarWidget::ChangeNature(ENatureType InNatureType)
{
	PlayAnimation(NatureChangeAnim);
	GetUIResource().SetNatureTypeIcon(NatureIconImage, InNatureType, false);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatTurnSkillStateWidget (TurnSkillStateWidgetBP)

UCombatTurnSkillStateWidget::UCombatTurnSkillStateWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatTurnSkillStateWidget::NativeConstruct()
{
	Super::NativeConstruct();

	for (int32 n = 1; n <= CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Skill%d"), n);
		UImage* SkillStateIcon = CastChecked<UImage>(GetWidgetFromName(*WidgetName));
		SkillStateIcons.AddUnique(SkillStateIcon);
	}
}

void UCombatTurnSkillStateWidget::Init(int32 UnitTypeX, const TArray<FSkillState>& TurnSkillStates)
{
	int32 ModelType = GetCMS()->GetModelTypeFromUnitType(UnitTypeX);
	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(ModelType);

	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		if (!SkillStateIcons.IsValidIndex(i))
		{
			continue;
		}

		if (!SkillAssetRow.TurnSkillStateIcons.IsValidIndex(i))
		{
			continue;
		}

		if (!TurnSkillStates.IsValidIndex(i))
		{
			SkillStateIcons[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		SkillStateIcons[i]->SetBrush(SkillAssetRow.TurnSkillStateIcons[i]);
	}

	SetSkillStates(TurnSkillStates);
}

void UCombatTurnSkillStateWidget::InitPet(FPetType PetType, const TArray<FSkillState>& PetSkillStates)
{
	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetType);

	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		if (!SkillStateIcons.IsValidIndex(i))
		{
			continue;
		}

		if (!PetAssetRow.SkillStateIcons.IsValidIndex(i))
		{
			continue;
		}

		if (!PetSkillStates.IsValidIndex(i))
		{
			SkillStateIcons[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		SkillStateIcons[i]->SetBrush(PetAssetRow.SkillStateIcons[i]);
	}

	SetSkillStates(PetSkillStates);
}

void UCombatTurnSkillStateWidget::SetSkillStates(const TArray<FSkillState>& SkillStates)
{
	for (int32 i = 0; i < SkillStates.Num(); ++i)
	{
		if (!SkillStateIcons.IsValidIndex(i))
		{
			continue;
		}

		if (SkillStates[i].Level <= 0)
		{
			SkillStateIcons[i]->SetVisibility(ESlateVisibility::Collapsed);
			continue;
		}

		bool bSkillOn = SkillStates[i].Cooldown == 0;
		SkillStateIcons[i]->SetVisibility(bSkillOn ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void UCombatTurnSkillStateWidget::SetForbidden()
{
	for (UImage* SkillStateIcon : SkillStateIcons)
	{
		SkillStateIcon->SetVisibility(ESlateVisibility::Collapsed);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatSkillNoteWidget (SkillNoteWidgetBP)

UCombatSkillNoteWidget::UCombatSkillNoteWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatSkillNoteWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NormalImage = CastChecked<UImage>(GetWidgetFromName("Normal"));
	MatchedImage = CastChecked<UImage>(GetWidgetFromName("Matched"));
	MismatchedImage = CastChecked<UImage>(GetWidgetFromName("Mismatched"));
}

void UCombatSkillNoteWidget::SetSkillNote(ESkillNote InSkillNote)
{
	TArray<FSlateBrush> Brushes;
	switch (InSkillNote)
	{
		case ESkillNote::Ace:
			Brushes = AceBrushes;
			break;
		case ESkillNote::Break:
			Brushes = BreakBrushes;
			break;
		case ESkillNote::Closer:
			Brushes = CloserBrushes;
			break;
		default:
			Q6JsonLogSunny(Warning, "UCombatSkillNoteWidget::SetSkillNote - Invalid skill note", Q6KV("SkillNote", (int32)InSkillNote));
			SetSkillNoteMatchState(ESkillNoteMatchState::Max);
			return;
	}

	if (Brushes.Num() < (int32)ESkillNoteMatchState::Max)
	{
		Q6JsonLogSunny(Warning, "UCombatSkillNoteWidget::SetSkillNote - Invalid skill note brushes", Q6KV("SkillNote", (int32)InSkillNote));
		SetSkillNoteMatchState(ESkillNoteMatchState::Max);
		return;
	}

	NormalImage->SetBrush(Brushes[(int32)ESkillNoteMatchState::Normal]);
	MatchedImage->SetBrush(Brushes[(int32)ESkillNoteMatchState::Matched]);
	MismatchedImage->SetBrush(Brushes[(int32)ESkillNoteMatchState::Mismatched]);

	SetSkillNoteMatchState(ESkillNoteMatchState::Normal);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatAttackStateIconWidget

UCombatAttackStateIconWidget::UCombatAttackStateIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatAttackStateIconWidget::NativeConstruct()
{
	AttackingAnim = GetWidgetAnimationFromName(this, "AnimStateAttacking");
	AttackingLoopAnim = GetWidgetAnimationFromName(this, "AnimStateAttackingLoop");
	WaitingAnim = GetWidgetAnimationFromName(this, "AnimStateWaiting");
}

void UCombatAttackStateIconWidget::SetAttacking(bool bInAttacking)
{
	StopAllAnimations();

	if (bInAttacking)
	{
		PlayAnimation(AttackingAnim);
		PlayAnimation(AttackingLoopAnim, 0.0f, 0);
	}
	else
	{
		PlayAnimation(WaitingAnim);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatAllyUltimateSkillWidget

UCombatAllyUltimateSkillWidget::UCombatAllyUltimateSkillWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bForbidden(false)
	, bEnabled(false)
{
}

void UCombatAllyUltimateSkillWidget::NativeConstruct()
{
	Super::NativeConstruct();

	LoopAnim = GetWidgetAnimationFromName(this, "AnimUltLoop");
	ClickedAnim = GetWidgetAnimationFromName(this, "AnimUltClicked");
	SkillStartAnim = GetWidgetAnimationFromName(this, "AnimUltSkillStart");
	ForbiddenAnim = GetWidgetAnimationFromName(this, "AnimUltForbidden");
	ForbiddenOffAnim = GetWidgetAnimationFromName(this, "AnimUltForbiddenOff");

	UltimateSkillImage = CastChecked<UImage>(GetWidgetFromName("UltImage"));
	UltimateSkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextUltName"));

	SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UCombatAllyUltimateSkillWidget::OnSelectButtonClicked);
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UCombatAllyUltimateSkillWidget::OnSelectButtonLongClicked);
}

void UCombatAllyUltimateSkillWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == SkillStartAnim)
	{
		OnUltimateSkillStartAnimFinishedDelegate.ExecuteIfBound();
	}
}

void UCombatAllyUltimateSkillWidget::Init(FUnitType UnitType, int32 SkillTypeX)
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	int32 ModelType = CMS->GetModelTypeFromUnitType(UnitType);
	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(ModelType);
	UltimateSkillImage->SetBrush(SkillAssetRow.UltimateIcon);

	const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillTypeX);
	UltimateSkillNameText->SetText(SkillRow.DescName);

	bEnabled = false;
}

void UCombatAllyUltimateSkillWidget::SetClickable(bool bInClickable)
{
	SelectButton->SetVisibility(bInClickable ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}

void UCombatAllyUltimateSkillWidget::SetEnabled(bool bInEnabled)
{
	bEnabled = bInEnabled;

	SetClickable(bInEnabled && !bForbidden);

	if (bInEnabled)
	{
		SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		PlayAnimation(bForbidden ? ForbiddenAnim : ForbiddenOffAnim);
		PlayAnimation(LoopAnim, 0.0f, 0);
	}
	else
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCombatAllyUltimateSkillWidget::OnSelectButtonClicked()
{
	StopAnimation(LoopAnim);
	PlayAnimation(ClickedAnim);

	OnUltimateSkillClickedDelegate.ExecuteIfBound();
}

void UCombatAllyUltimateSkillWidget::OnSelectButtonLongClicked()
{
	OnUltimateSkillLongClickedDelegate.ExecuteIfBound();
}

void UCombatAllyUltimateSkillWidget::OnSkillStart()
{
	PlayAnimation(SkillStartAnim);
}

void UCombatAllyUltimateSkillWidget::OnSkillEnd()
{
	SetEnabled(false);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatAllyPortraitWidget

UCombatAllyPortraitWidget::UCombatAllyPortraitWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatAllyPortraitWidget::Init(int32 UnitType, ECCTurnPhase TurnPhase)
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(UnitType));
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(UnitRow.Model);

	const TSoftObjectPtr<UTexture2D>& CharacterTexture = (TurnPhase == ECCTurnPhase::Attack) ?
		CharacterAssetRow.CombatIconTexture : CharacterAssetRow.CombatPortraitTexture;
	PortraitImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterTexture);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatAllyTurnSkillPortraitWidget

UCombatAllyTurnSkillPortraitWidget::UCombatAllyTurnSkillPortraitWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatAllyTurnSkillPortraitWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectedInAnim = GetWidgetAnimationFromName(this, "AnimThumbSelectedIn");
	SelectedLoopAnim = GetWidgetAnimationFromName(this, "AnimThumbSelectedLoop");
	SelectedOutAnim = GetWidgetAnimationFromName(this, "AnimThumbSelectedOut");

	PortraitImage = CastChecked<UImage>(GetWidgetFromName("CharacterImageTurn"));
}

void UCombatAllyTurnSkillPortraitWidget::Init(int32 UnitTypeX)
{
	Super::Init(UnitTypeX, ECCTurnPhase::TurnSkill);
}

void UCombatAllyTurnSkillPortraitWidget::SetSelected(bool bInSelected)
{
	StopAllAnimations();

	if (bInSelected)
	{
		PlayAnimation(SelectedInAnim);
		PlayAnimation(SelectedLoopAnim, 0.0f, 0);
	}
	else
	{
		PlayAnimation(SelectedOutAnim);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatAllyAttackPortraitWidget

UCombatAllyAttackPortraitWidget::UCombatAllyAttackPortraitWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bIsDoubleSkillOwner(false)
	, SelectedSkillCategory(ESkillCategory::Normal)
{
}

void UCombatAllyAttackPortraitWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AttackStartAnim = GetWidgetAnimationFromName(this, "AnimThumbAttackStart");
	PassedAnim = GetWidgetAnimationFromName(this, "AnimThumbPassed");
	ClickedAnim = GetWidgetAnimationFromName(this, "AnimThumbClicked");
	NormalClickedAnim = GetWidgetAnimationFromName(this, "AnimThumbAttackClicked");
	UltimateClickedAnim = GetWidgetAnimationFromName(this, "AnimThumbUltClicked");
	AttackEndAnim = GetWidgetAnimationFromName(this, "AnimThumbAttackEnd");
	SkillNoteMatchedAnim = GetWidgetAnimationFromName(this, "AnimThumbABCMatched");
	ChainEffectAnim = GetWidgetAnimationFromName(this, "AnimThumbABCBonus");
	DoubleAttackGiveAnim = GetWidgetAnimationFromName(this, "AnimThumbDoubleAttackGive");
	DoubleAttackStartAnim = GetWidgetAnimationFromName(this, "AnimThumbDoubleAttackStart");
	ForbiddenAnim = GetWidgetAnimationFromName(this, "AnimThumbForbidden");
	ForbiddenOffAnim = GetWidgetAnimationFromName(this, "AnimThumbForbiddenOff");

	PortraitImage = CastChecked<UImage>(GetWidgetFromName("CharacterImageAttack"));

	AttackOrderImage = CastChecked<UImage>(GetWidgetFromName("AttackOrderPass"));

	SkillNoteWidget = CastChecked<UCombatSkillNoteWidget>(GetWidgetFromName("SkillNote"));
	SkillNoteMatchedImage = CastChecked<UImage>(GetWidgetFromName("SkillNoteMatched"));

	AttackStateIconWidget = CastChecked<UCombatAttackStateIconWidget>(GetWidgetFromName("AttackStateIcon"));

	UltimateSkillWidget = CastChecked<UCombatAllyUltimateSkillWidget>(GetWidgetFromName("UltBtn"));
	UltimateSkillWidget->OnUltimateSkillClickedDelegate.BindUObject(this, &UCombatAllyAttackPortraitWidget::OnUltimateSkillClicked);
	UltimateSkillWidget->OnUltimateSkillLongClickedDelegate.BindUObject(this, &UCombatAllyAttackPortraitWidget::OnUltimateSkillLongClicked);
	UltimateSkillWidget->OnUltimateSkillStartAnimFinishedDelegate.BindUObject(this, &UCombatAllyAttackPortraitWidget::OnUltimateSkillStartAnimFinished);
}

void UCombatAllyAttackPortraitWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (bIsDoubleSkillOwner && Animation == DoubleAttackGiveAnim)
	{
		PlayAnimation(DoubleAttackStartAnim);
		bIsDoubleSkillOwner = false;
	}
}

void UCombatAllyAttackPortraitWidget::Init(const FUnitState& UnitState)
{
	Super::Init(UnitState.UnitType, ECCTurnPhase::Attack);

	if (UnitState.Ultimates[0].SkillType == SkillTypeInvalid.x)
	{
		Q6JsonLogSunny(Warning, "UCombatAllyAttackPortraitWidget::Init - Invalid UltimateSkillType");
	}
	else
	{
		UltimateSkillWidget->Init(FUnitType(UnitState.UnitType), UnitState.Ultimates[0].SkillType);
	}
}

void UCombatAllyAttackPortraitWidget::SetForbidden(bool bInNormalSkillBlocked, bool bInUltimateSkillBlocked)
{
	UltimateSkillWidget->SetForbidden(bInUltimateSkillBlocked);
	PlayAnimation(bInNormalSkillBlocked ? ForbiddenAnim : ForbiddenOffAnim);
}

void UCombatAllyAttackPortraitWidget::SetUltimateSkillEnabled(bool bInEnabled)
{
	UltimateSkillWidget->SetEnabled(bInEnabled);
}

void UCombatAllyAttackPortraitWidget::SetAttackPassed()
{
	PlayAnimation(AttackEndAnim);
	PlayAnimation(PassedAnim);
}

void UCombatAllyAttackPortraitWidget::SetAttackOrder(int32 AttackOrder)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return;
	}

	CombatGameResource->SetAttackOrderImage(AttackOrderImage, AttackOrder);

	if (AttackOrder > 1)
	{
		AttackStateIconWidget->SetAttacking(false);
	}

	PlayAnimation(ClickedAnim);
	PlayAnimation(SelectedSkillCategory == ESkillCategory::Ultimate ? UltimateClickedAnim : NormalClickedAnim);
}

void UCombatAllyAttackPortraitWidget::SetSkillNote(ESkillNote SkillNote)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		return;
	}

	SkillNoteWidget->SetSkillNote(SkillNote);
	CombatGameResource->SetSkillNoteMatchedImage(SkillNoteMatchedImage, (int32)SkillNote);
}

void UCombatAllyAttackPortraitWidget::SetSkillNoteMatched(bool bInMatched)
{
	if (bInMatched)
	{
		SkillNoteWidget->SetSkillNoteMatchState(ESkillNoteMatchState::Matched);
		StopAnimation(ChainEffectAnim);
		PlayAnimation(SkillNoteMatchedAnim);
	}
	else
	{
		SkillNoteWidget->SetSkillNoteMatchState(ESkillNoteMatchState::Mismatched);
	}
}

void UCombatAllyAttackPortraitWidget::PlayChainEffect()
{
	PlayAnimation(ChainEffectAnim);
}

void UCombatAllyAttackPortraitWidget::PlayDoubleSkillEffect(bool bIsOwner)
{
	bIsDoubleSkillOwner = bIsOwner;
	PlayAnimation(DoubleAttackGiveAnim);
}

void UCombatAllyAttackPortraitWidget::OnAttackStart(bool bUltimateEnabled)
{
	SetUltimateSkillEnabled(bUltimateEnabled);
	PlayAnimation(AttackStartAnim);
}

void UCombatAllyAttackPortraitWidget::OnSkillClicked(ESkillCategory InSkillCategory)
{
	SelectedSkillCategory = InSkillCategory;

	UltimateSkillWidget->SetClickable(false);
}

void UCombatAllyAttackPortraitWidget::OnSkillStart()
{
	if (SelectedSkillCategory == ESkillCategory::Ultimate)
	{
		UltimateSkillWidget->OnSkillStart();
	}

	AttackStateIconWidget->SetAttacking(true);
}

void UCombatAllyAttackPortraitWidget::OnSkillEnd()
{
	PlayAnimation(AttackEndAnim);
	UltimateSkillWidget->OnSkillEnd();
}

void UCombatAllyAttackPortraitWidget::OnUltimateSkillClicked()
{
	OnUltimateSkillClickedDelegate.ExecuteIfBound();
}

void UCombatAllyAttackPortraitWidget::OnUltimateSkillLongClicked()
{
	OnUltimateSkillLongClickedDelegate.ExecuteIfBound();
}

void UCombatAllyAttackPortraitWidget::OnUltimateSkillStartAnimFinished()
{
	OnUltimateSkillStartAnimFinishedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatSkillGaugeFillWidget

UCombatSkillGaugeFillWidget::UCombatSkillGaugeFillWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Percent(0.f)
	, FullBarWidth(0.f)
{
}

void UCombatSkillGaugeFillWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BarSizeBox = CastChecked<USizeBox>(GetWidgetFromName("SkillBarFill"));
	BarCapLImage = CastChecked<UImage>(GetWidgetFromName("BarCapL"));
	BarFillImage = CastChecked<UImage>(GetWidgetFromName("BarFill"));
	BarCapRImage = CastChecked<UImage>(GetWidgetFromName("BarCapR"));
}

void UCombatSkillGaugeFillWidget::SetBrushes(const FSlateBrush& CapBrush, const FSlateBrush& FillBrush)
{
	BarCapLImage->SetBrush(CapBrush); //-V525
	BarCapRImage->SetBrush(CapBrush);
	BarFillImage->SetBrush(FillBrush);
}

void UCombatSkillGaugeFillWidget::SetPercent(float InPercent)
{
	if (InPercent <= 0.f)
	{
		SetVisibility(ESlateVisibility::Collapsed);
	}
	else if (Percent <= 0.f)
	{
		SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	Percent = InPercent;
	BarSizeBox->SetWidthOverride(FullBarWidth * Percent);
}


//////////////////////////////////////////////////////////////////////////////////
// UCombatSkillGaugeWidget

UCombatSkillGaugeWidget::UCombatSkillGaugeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, MaxValue(0)
	, bSkillOn(false)
{
}

void UCombatSkillGaugeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UAAnim = GetWidgetAnimationFromName(this, "AnimUA");
	SAAnim = GetWidgetAnimationFromName(this, "AnimSA");
	FillEffectAnim = GetWidgetAnimationFromName(this, "AnimFillEffect");
	SkillActivateAnim = GetWidgetAnimationFromName(this, "AnimActivate");
	SkillDeactivateAnim = GetWidgetAnimationFromName(this, "AnimDeactivate");
	EnableAnim = GetWidgetAnimationFromName(this, "AnimGaugeEnable");
	DisableAnim = GetWidgetAnimationFromName(this, "AnimGaugeDisable");

	SkillOnImage = CastChecked<UImage>(GetWidgetFromName("SkillOn"));
	SkillOnImage->SetBrush(SkillOnBrush);

	PercentText = CastChecked<UTextBlock>(GetWidgetFromName("TextPercent"));
	PercentText->SetText(FText::AsNumber(0));

	SkillGaugeBarSizeBox = CastChecked<USizeBox>(GetWidgetFromName("SkillGaugeBarSize"));

	MaxImage = CastChecked<UImage>(GetWidgetFromName("ImageMax"));

	FString WidgetName;
	for (int32 Section = 0; Section < MAX_SKILL_GAUGE_SECTION_COUNT; ++Section)
	{
		WidgetName = FString::Printf(TEXT("SkillGaugeFillLv%d"), Section + 1);
		UCombatSkillGaugeFillWidget* FillWidget = CastChecked<UCombatSkillGaugeFillWidget>(GetWidgetFromName(*WidgetName));
		FillWidget->SetBrushes(SkillGaugeBarCapBrushes[Section], SkillGaugeBarFillBrushes[Section]);
		FillWidget->SetFullBarWidth(SkillGaugeBarSizeBox->WidthOverride);
		FillWidget->SetPercent(0.f);
		SkillGaugeFillBars.AddUnique(FillWidget);
	}

	switch (SkillGaugeType)
	{
		case ESkillGaugeType::Ultimate:
			PlayAnimation(UAAnim);
			break;
		case ESkillGaugeType::Support:
			PlayAnimation(SAAnim);
			break;
		default:
			break;
	}
}

void UCombatSkillGaugeWidget::Init(EAttributeCategory InRatio, int32 InValue, int32 InMaxValue)
{
	if (InRatio == EAttributeCategory::RecommendJoker)
	{
		MaxImage->SetVisibility(ESlateVisibility::Collapsed);
		PlayAnimation(DisableAnim);
		return;
	}

	int32 EndSection = FMath::Clamp(InValue / MAX_SKILL_GAUGE_IN_SECTION, 0, MAX_SKILL_GAUGE_SECTION_COUNT);

	for (int32 Section = 0; Section < SkillGaugeFillBars.Num(); ++Section)
	{
		float TargetPercent = 0.0f;
		if (Section == EndSection)
		{
			if (InValue % MAX_SKILL_GAUGE_IN_SECTION)
			{
				TargetPercent = FMath::Clamp((float)InValue / MAX_SKILL_GAUGE_IN_SECTION + 0.005f, 0.f, 1.f);
			}
		}
		else if (Section < EndSection)
		{
			TargetPercent = 1.0f;
		}

		SkillGaugeFillBars[Section]->SetPercent(TargetPercent);
	}
	PercentText->SetText(FText::AsNumber(InValue));

	MaxValue = InMaxValue;
	MaxImage->SetVisibility(InValue >= MaxValue ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	bSkillOn = (InValue >= MAX_SKILL_GAUGE_IN_SECTION) ? true : false;
	SkillOnImage->SetVisibility(bSkillOn ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	PlayAnimation(EnableAnim);
}

void UCombatSkillGaugeWidget::SetSkillGauge(int32 OldValue, int32 NewValue)
{
	if (OldValue == NewValue)
	{
		return;
	}

	bool PreventOverlapUpdate = true;
	if (SerialProgressQueue.Num() <= 0)
	{
		PreventOverlapUpdate = false;
	}

	bool bMax = NewValue >= MaxValue;

	bool bSkillWasOn = bSkillOn;
	bSkillOn = (NewValue >= MAX_SKILL_GAUGE_IN_SECTION) ? true : false;
	bool bActivationChanged = bSkillWasOn != bSkillOn;

	bool bGain = (NewValue > OldValue) ? true : false;
	float Length = FMath::Clamp(AnimationTime, 0.f, MAX_PROGRESS_TASK_TICK_TIME);

	int32 BeginSection = OldValue / MAX_SKILL_GAUGE_IN_SECTION;
	int32 EndSection = NewValue / MAX_SKILL_GAUGE_IN_SECTION;

	if (BeginSection <= EndSection)
	{
		for (int32 Section = BeginSection; Section <= EndSection; ++Section)
		{
			if (!SkillGaugeFillBars.IsValidIndex(Section))
			{
				continue;
			}

			float TargetPercent = 0.0f;
			if (Section == EndSection)
			{
				if (NewValue % MAX_SKILL_GAUGE_IN_SECTION)
				{
					int32 CurValue = NewValue - (Section * MAX_SKILL_GAUGE_IN_SECTION);
					TargetPercent = FMath::Clamp((float)CurValue / MAX_SKILL_GAUGE_IN_SECTION + 0.005f, 0.f, 1.f);
				}
			}
			else
			{
				TargetPercent = 1.0f;
			}

			UCombatSkillGaugeFillWidget* Bar = SkillGaugeFillBars[Section];
			SerialProgressQueue.Push(
				FSkillGaugeProgressUpdateTask(Bar, Bar->Percent, TargetPercent, Length,
					FSimpleDelegate::CreateUObject(this, &UCombatSkillGaugeWidget::OnProgressStart, bGain),
					FSimpleDelegate::CreateUObject(this, &UCombatSkillGaugeWidget::OnProgressEnd, TargetPercent, Section, bActivationChanged, bMax),
					FFloatParamDelegate::CreateUObject(this, &UCombatSkillGaugeWidget::OnProgressUpdate, Section))
			);
		}
	}
	else
	{
		for (int32 Section = BeginSection; Section >= EndSection; --Section)
		{
			if (!SkillGaugeFillBars.IsValidIndex(Section))
			{
				continue;
			}

			float TargetPercent = 0.0f;
			if (Section == EndSection)
			{
				if (NewValue % MAX_SKILL_GAUGE_IN_SECTION)
				{
					int32 CurValue = NewValue - (Section * MAX_SKILL_GAUGE_IN_SECTION);
					TargetPercent = FMath::Clamp((float)CurValue / MAX_SKILL_GAUGE_IN_SECTION + 0.005f, 0.f, 1.f);
				}
			}

			UCombatSkillGaugeFillWidget* Bar = SkillGaugeFillBars[Section];
			SerialProgressQueue.Push(
				FSkillGaugeProgressUpdateTask(Bar, Bar->Percent, TargetPercent, Length,
					FSimpleDelegate::CreateUObject(this, &UCombatSkillGaugeWidget::OnProgressStart, bGain),
					FSimpleDelegate::CreateUObject(this, &UCombatSkillGaugeWidget::OnProgressEnd, TargetPercent, Section, bActivationChanged, bMax),
					FFloatParamDelegate::CreateUObject(this, &UCombatSkillGaugeWidget::OnProgressUpdate, Section))
			);
		}
	}

	if (!PreventOverlapUpdate)
	{
		OnProgressEndInternal(bActivationChanged, bMax);
	}
}

void UCombatSkillGaugeWidget::OnProgressStart(bool bGain)
{
	if (bGain)
	{
		PlayAnimation(FillEffectAnim);
	}
}

void UCombatSkillGaugeWidget::OnProgressUpdate(float TargetSectionPercent, int32 TargetSection)
{
	int32 Percent = (TargetSection + TargetSectionPercent) * MAX_SKILL_GAUGE_IN_SECTION;
	PercentText->SetText(FText::AsNumber(Percent));
}

void UCombatSkillGaugeWidget::OnProgressEnd(float TargetSectionPercent, int32 TargetSection, bool bActivationChanged, bool bMax)
{
	OnProgressUpdate(TargetSectionPercent, TargetSection);
	OnProgressEndInternal(bActivationChanged, bMax);
}

void UCombatSkillGaugeWidget::OnProgressEndInternal(bool bActivationChanged, bool bMax)
{
	if (SerialProgressQueue.Num() <= 0)
	{
		OnSerialProgressQueueEmpty(bActivationChanged, bMax);
		return;
	}

	FSkillGaugeProgressUpdateTask T = SerialProgressQueue[0];
	SerialProgressQueue.RemoveAt(0);

	if (SerialProgressQueue.Num() <= 0)
	{
		OnSerialProgressQueueEmpty(bActivationChanged, bMax);
	}

	ACombatHUD* CombatHUD = GetCombatHUD(this);
	if (CombatHUD)
	{
		CombatHUD->AddSkillGaugeProgressSerialTask(T);
	}
}

void UCombatSkillGaugeWidget::OnSerialProgressQueueEmpty(bool bActivationChanged, bool bMax)
{
	MaxImage->SetVisibility(bMax ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	if (bActivationChanged)
	{
		PlayAnimation(bSkillOn ? SkillActivateAnim : SkillDeactivateAnim);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatSkillGaugeGainWidget

UCombatSkillGaugeGainWidget::UCombatSkillGaugeGainWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatUnitBarWidget

UCombatUnitBarWidget::UCombatUnitBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, UnitId(CCUnitIdInvalid)
{
}

void UCombatUnitBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NameBarWidget = CastChecked<UCombatNameBarWidget>(GetWidgetFromName("NameBar"));

	BuffIconListWidget = CastChecked<UBuffIconListWidget>(GetWidgetFromName("BuffIconList"));
	BuffNoticeListWidget = CastChecked<UCombatBarBuffNoticeListWidget>(GetWidgetFromName("BuffNoticeList"));
	BuffNoticeListWidget->OnNotificationFinishedDelegate.BindUObject(this, &UCombatUnitBarWidget::OnBuffNotiFinished);
}

void UCombatUnitBarWidget::InitBar(const FUnitState& UnitState, ESpawnReason Reason)
{
	bDead = false;
	UnitId = UnitState.UnitId;

	NameBarWidget->InitBar(UnitState);

	BuffNoticeListWidget->SetEmptyNotices();
}

void UCombatUnitBarWidget::UpdateHealth(EHealthChangeReason Reason, int32 HitIndex /* = 0 */, int32 HitMax /* = 1 */)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	int32 Health = Unit->GetHealth();
	NameBarWidget->SetHealthState(Health, Reason, HitIndex, HitMax, (Unit->GetUnitState().Faction == ECCFaction::Ally));
}

void UCombatUnitBarWidget::SetShieldState(bool bActivate)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	if (bActivate)
	{
		NameBarWidget->InitShieldBar(Unit->GetShield(), Unit->GetMaxShield());
	}
	else
	{
		NameBarWidget->SetShieldState(bActivate);
	}
}

void UCombatUnitBarWidget::SetShieldDamage(int32 InShieldDamage, int32 InExtraShieldDamage, bool bInShieldWeakPoint)
{
	NameBarWidget->SetShieldDamage(InShieldDamage, InExtraShieldDamage, bInShieldWeakPoint);
}

void UCombatUnitBarWidget::SetDead(bool bInDead, bool bInWithoutAnimation)
{
	bDead = bInDead;

	if (bDead)
	{
		UnitId = CCUnitIdInvalid;

		SetSelectedBar(false);

		if (bInWithoutAnimation)
		{
			// start animation from almost end time
			const float EndTimeOffset = 0.1f;
			PlayAnimation(DeadAnim, DeadAnim->GetEndTime() - EndTimeOffset);
		}
		else
		{
			PlayAnimation(DeadAnim);
		}
	}
}

void UCombatUnitBarWidget::SetBuffNoticeList(ECPTurnPhase Phase)
{
	if (Phase == ECPTurnPhase::Prepare)
	{
		return;
	}

	AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	TArray<FBuffEffectState> Buffs;
	Unit->GatherCCBuffEffectsOnPhase(Buffs, Phase);
	BuffNoticeListWidget->SetBuffs(Buffs, false);
}

void UCombatUnitBarWidget::SetBuffs(const TArray<FBuffState>& Buffs, const TArray<FPointVaryUnitAttributeState>& PointVaryUnitSttributeStates, const FCCBuffId& NewBuffId)
{
	BuffIconListWidget->SetBuffs(Buffs, PointVaryUnitSttributeStates, NewBuffId);
}

void UCombatUnitBarWidget::SetBuffsMultiple()
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(GetUnitId());
	if (!Unit)
	{
		Q6JsonLogGunny(Warning, "UCombatUnitBarWidget::SetBuffsMultiple - Invalid Unit", Q6KV("UnitId", GetUnitId()));
		return;
	}
	const FUnitState& UnitState = Unit->GetUnitState();
	const TArray<FBuffState>& BuffStates = UnitState.Buffs;

	for (const FBuffState& BuffState : BuffStates)
	{
		BuffIconListWidget->SetBuffMultiple(BuffState);
	}
}

void UCombatUnitBarWidget::ChangeNature(ENatureType InNatureType)
{
	NameBarWidget->ChangeNature(InNatureType);
}

void UCombatUnitBarWidget::RemoveBuff(int32 BuffId, ERemoveBuffReason Reason)
{
	BuffIconListWidget->RemoveBuff(BuffId, Reason);
}

void UCombatUnitBarWidget::AddBuffNotification(const FBuffEffectState& BuffEffectState, bool bInCreation)
{
	BuffNoticeListWidget->AddBuff(BuffEffectState, bInCreation);
}

void UCombatUnitBarWidget::OnBuffNotiFinished(bool bCreation)
{
	if (!bCreation)
	{
		OnBuffExecutionNotiFinishedDelegate.ExecuteIfBound();
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatAllyBarWidget

UCombatAllyBarWidget::UCombatAllyBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, NormalSkillId(CCSkillIdInvalid)
	, UltimateSkillId(CCSkillIdInvalid)
	, CurUA(0)
	, CurSA(0)
	, CurOK(0)
	, bVersaEnabled(false)
	, bSkillUsed(false)
	, bNormalSkillBlocked(false)
	, bUltimateSkillBlocked(false)
	, bSkipDefenseEnd(false)
	, bSkipUpdateUltimateState(false)
	, AllyBarIndex(0)
{
}

void UCombatAllyBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AliveAnim = GetWidgetAnimationFromName(this, "AnimCharacterAlive");
	DeadAnim = GetWidgetAnimationFromName(this, "AnimCharacterDead");
	TurnStartAnim = GetWidgetAnimationFromName(this, "AnimCharacterTurnStart");
	TurnEndAnim = GetWidgetAnimationFromName(this, "AnimCharacterTurnEnd");
	AttackStartAnim = GetWidgetAnimationFromName(this, "AnimCharacterAttackStart");
	AttackEndAnim = GetWidgetAnimationFromName(this, "AnimCharacterAttackEnd");
	DefenseStartAnim = GetWidgetAnimationFromName(this, "AnimCharacterDefenseStart");
	DefenseEndAnim = GetWidgetAnimationFromName(this, "AnimCharacterDefenseEnd");
	ForbiddenAnim = GetWidgetAnimationFromName(this, "AnimCharacterForbidden");
	ForbiddenOffAnim = GetWidgetAnimationFromName(this, "AnimCharacterForbiddenOff");
	VersaStartAnim = GetWidgetAnimationFromName(this, "AnimCharacterVersaStart");
	VersaEndAnim = GetWidgetAnimationFromName(this, "AnimCharacterVersaEnd");
	SummonAnim = GetWidgetAnimationFromName(this, "AnimCharacterSummon");
	RebirthAnim = GetWidgetAnimationFromName(this, "AnimCharacterRebirth");

	DetailButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnDetail"));
	DetailButton->OnLongClickedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnSelectButtonLongClicked);

	TurnSelectButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnTurnSelect"));
	TurnSelectButton->OnClickedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnSelectButtonClicked);
	TurnSelectButton->OnLongClickedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnSelectButtonLongClicked);

	AttackSelectButton = CastChecked<UQ6Button>(GetWidgetFromName("BtnAttackSelect"));
	AttackSelectButton->OnClickedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnNormalSkillClicked);
	AttackSelectButton->OnLongClickedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnSelectButtonLongClicked);

	TurnSkillPortraitWidget = CastChecked<UCombatAllyTurnSkillPortraitWidget>(GetWidgetFromName("CharacterTurnSkill"));
	AttackPortraitWidget = CastChecked<UCombatAllyAttackPortraitWidget>(GetWidgetFromName("CharacterAttack"));
	AttackPortraitWidget->OnUltimateSkillClickedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnUltimateSkillClicked);
	AttackPortraitWidget->OnUltimateSkillLongClickedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnSelectButtonLongClicked);
	AttackPortraitWidget->OnUltimateSkillStartAnimFinishedDelegate.BindUObject(this, &UCombatAllyBarWidget::OnUltimateSkillStartAnimFinished);

	UAGaugeWidget = CastChecked<UCombatSkillGaugeWidget>(GetWidgetFromName("UAGauge"));
	SAGaugeWidget = CastChecked<UCombatSkillGaugeWidget>(GetWidgetFromName("SAGauge"));

	SkillGaugeGainWidget = CastChecked<UCombatSkillGaugeGainWidget>(GetWidgetFromName("SkillGaugeGain"));

	JokerImage = CastChecked<UImage>(GetWidgetFromName("Joker"));
	NatureRelationWidget = CastChecked<UCombatNatureRelationWidget>(GetWidgetFromName("NatureRelation"));
	OverKillWidget = CastChecked<UCombatOverKillWidget>(GetWidgetFromName("OverKill"));
	VersaStateBorder = CastChecked<UBorder>(GetWidgetFromName("StateVersa"));
	TurnSkillStateWidget = CastChecked<UCombatTurnSkillStateWidget>(GetWidgetFromName("TurnSkillState"));
}

void UCombatAllyBarWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == DefenseEndAnim)
	{
		PlayAnimation(TurnStartAnim);
	}
	else if (Animation == TurnEndAnim)
	{
		AttackPortraitWidget->SetForbidden(bNormalSkillBlocked, bUltimateSkillBlocked);
		AttackPortraitWidget->OnAttackStart(UAGaugeWidget->IsSkillOn());
		PlayAnimation(AttackStartAnim);
	}
	else if (Animation == AttackEndAnim)
	{
		PlayAnimation(DefenseStartAnim);
	}
	else if (Animation == SummonAnim || Animation == RebirthAnim)
	{
		OnSpawnAnimFinishedDelegate.ExecuteIfBound();
	}
}

void UCombatAllyBarWidget::InitBar(const FUnitState& UnitState, ESpawnReason Reason)
{
	Super::InitBar(UnitState, Reason);

	if (UnitState.UnitType == UnitTypeInvalid.x)
	{
		Q6JsonLogSunny(Warning, "UCombatAllyBarWidget::InitBar - Invalid UnitType");

		CurUA = 0;
		CurSA = 0;
		CurOK = 0;
	}
	else
	{
		TurnSkillPortraitWidget->Init(UnitState.UnitType);
		AttackPortraitWidget->Init(UnitState);

		TurnSkillStateWidget->Init(UnitState.UnitType, UnitState.TurnBegins);

		CurUA = UnitState.UA;
		CurSA = UnitState.SA;
		CurOK = 0;

		SetJoker(UnitState.Category);
	}

	UAGaugeWidget->Init(UnitState.Category, CurUA, UnitState.MaxUA);
	SAGaugeWidget->Init(UnitState.Category, CurSA, UnitState.MaxSA);
	OverKillWidget->Init();

	bVersaEnabled = false;

	if (UnitState.Health != 0)
	{
		PlayAnimation(AliveAnim);
	}
	switch (Reason)
	{
		case ESpawnReason::SubParty:
		case ESpawnReason::Summon:
			PlayAnimation(SummonAnim);
			break;
		case ESpawnReason::Rebirth:
		case ESpawnReason::WipeoutContinue:
		case ESpawnReason::RebirthSummon:
			PlayAnimation(RebirthAnim);
			break;
		default:
			OnSpawnAnimFinishedDelegate.ExecuteIfBound();
			break;
	}
}

void UCombatAllyBarWidget::SetSelectedBar(bool bSelected)
{
	TurnSkillPortraitWidget->SetSelected(bSelected);
	TurnSkillStateWidget->SetVisibility(bSelected ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);
}

void UCombatAllyBarWidget::SynchronizeCCState(ECCTurnPhase InPhase)
{
	UpdateSkillNote();

	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	const AUnit* Unit = Presenter->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	if (Unit->IsDead())
	{
		SetDead(true);
		return;
	}

	SetPhase(Presenter->CCPhaseToCPPhase(InPhase));

	const FUnitState& BarUnitState = Unit->GetUnitState();
	SetUA(0, BarUnitState.UA);
	SetSA(0, BarUnitState.SA);
	SetOverKill(0, BarUnitState.OverKill);
	SetVersa(Unit->HasVersaBuff());
}

void UCombatAllyBarWidget::SetJoker(EAttributeCategory Ratio)
{
	switch (Ratio)
	{
		case EAttributeCategory::SystemJoker:
		case EAttributeCategory::FriendJoker:
		case EAttributeCategory::RecommendJoker:
			JokerImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			break;
		default:
			JokerImage->SetVisibility(ESlateVisibility::Collapsed);
			break;
	}
}

void UCombatAllyBarWidget::SetTurnSkillPhaseSelectable(bool bInSelectable)
{
	TurnSelectButton->SetVisibility(bInSelectable ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
}

void UCombatAllyBarWidget::SetNatureRelation(ECCFaction SourceFaction, ENatureType SourceType, ENatureType TargetType)
{
	NatureRelationWidget->SetNatureRelation(SourceFaction, SourceType, TargetType);
}

void UCombatAllyBarWidget::DisableNatureRealtion()
{
	NatureRelationWidget->DisableNatureRelation();
}

void UCombatAllyBarWidget::SetPhase(ECPTurnPhase TurnPhase)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	if (bDead)
	{
		return;
	}

	switch (TurnPhase)
	{
		case ECPTurnPhase::Prepare:
			UpdateSkillNote();
			break;
		case ECPTurnPhase::TurnSkill:
			if (!bSkipDefenseEnd)
			{
				StopAnimation(AttackStartAnim);
				PlayAnimation(DefenseEndAnim);
			}
			bSkipDefenseEnd = false;
			TurnSkillStateWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			break;
		case ECPTurnPhase::Steady:
			UpdateSkillBlocked();
			AttackSelectButton->SetVisibility(ESlateVisibility::Visible);
			PlayAnimation(TurnEndAnim);
			break;
		case ECPTurnPhase::OppAttack:
			PlayAnimation(AttackEndAnim);
			break;
		default:
			break;
	}
}

void UCombatAllyBarWidget::UpdateTurnSkillStates()
{
	AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	const FCCBuffCoolTime& CCBuffCoolTime = Unit->GetCCBuffCoolTime();
	if (CCBuffCoolTime.bInfinity || CCBuffCoolTime.CCDuration > 0)
	{
		TurnSkillStateWidget->SetForbidden();
	}
	else
	{
		TurnSkillStateWidget->SetSkillStates(Unit->GetUnitState().TurnBegins);
	}
}

void UCombatAllyBarWidget::UpdateUltimateSkillState()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	ECPTurnPhase TurnPhase = Presenter->CCPhaseToCPPhase(Presenter->GetTurnPhase());
	if ((TurnPhase == ECPTurnPhase::Steady || TurnPhase == ECPTurnPhase::Attack) && !bSkillUsed && !bSkipUpdateUltimateState)
	{
		AttackPortraitWidget->SetUltimateSkillEnabled(UAGaugeWidget->IsSkillOn());
	}
}

void UCombatAllyBarWidget::SetUA(int32 OldUA, int32 NewUA)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	UAGaugeWidget->SetSkillGauge(OldUA, NewUA);
	CurUA = NewUA;

	UpdateUltimateSkillState();
}

void UCombatAllyBarWidget::AddUA(int32 AddedUA)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	UAGaugeWidget->SetSkillGauge(CurUA, CurUA + AddedUA);
	CurUA += AddedUA;

	UpdateUltimateSkillState();
}

void UCombatAllyBarWidget::SetSA(int32 OldSA, int32 NewSA)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	SAGaugeWidget->SetSkillGauge(OldSA, NewSA);
	CurSA = NewSA;
}

void UCombatAllyBarWidget::AddSA(int32 AddedSA)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	SAGaugeWidget->SetSkillGauge(CurSA, CurSA + AddedSA);
	CurSA += AddedSA;
}

void UCombatAllyBarWidget::SetOverKill(int32 OldOK, int32 NewOK)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	OverKillWidget->SetOverKill(OldOK, NewOK);
	CurOK = NewOK;
}

void UCombatAllyBarWidget::AddOverKill(int32 AddedOK)
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	OverKillWidget->SetOverKill(CurOK, CurOK + AddedOK);
	CurOK += AddedOK;
}

void UCombatAllyBarWidget::SetVersa(bool bInEnabled)
{
	if (bInEnabled == bVersaEnabled)
	{
		return;
	}

	bVersaEnabled = bInEnabled;
	PlayAnimation(bInEnabled ? VersaStartAnim : VersaEndAnim);
}

void UCombatAllyBarWidget::SetAttackPassed()
{
	AttackSelectButton->SetVisibility(ESlateVisibility::Collapsed);
	AttackPortraitWidget->SetAttackPassed();
}

void UCombatAllyBarWidget::SetAttackOrder(int32 Order, int32 Survivors)
{
	AttackSelectButton->SetVisibility(ESlateVisibility::Collapsed);
	AttackPortraitWidget->SetAttackOrder(Order);
	SkillGaugeGainWidget->PlayGaugeGain(Order, Survivors);
}

void UCombatAllyBarWidget::SetMatchedSkillChordNote(EApplyTag ChordNote)
{
	switch (ChordNote)
	{
		case EApplyTag::ChordAce:
		case EApplyTag::ChordBreak:
		case EApplyTag::ChordCloser:
			AttackPortraitWidget->SetSkillNoteMatched(true);
			break;
		default:
			AttackPortraitWidget->SetSkillNoteMatched(false);
			break;
	}
}

void UCombatAllyBarWidget::UpdateSkillNote()
{
	GetCheckedCombatCube(this)->GetStore()->ReqCCState(
		UnitId, FOnCCStateGot::CreateLambda([this](FCCUnitId ReqUnitId, FCombatState RepState) {
		if (RepState.NormalSkillIdByTurn)
		{
			NormalSkillId = FCCSkillId(RepState.NormalSkillIdByTurn);
			const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(RepState.NormalSkillTypeByTurn);
			AttackPortraitWidget->SetSkillNote(InSkillRow.SkillNote);
		}
		else
		{
			NormalSkillId = CCSkillIdInvalid;
			Q6JsonLogSunny(Warning, "UCombatAllyBarWidget::UpdateSkillNote - invalid normal skill state");

		}

		if (RepState.UltimateSkillIdByTurn)
		{
			UltimateSkillId = FCCSkillId(RepState.UltimateSkillIdByTurn);
		}
		else
		{
			UltimateSkillId = CCSkillIdInvalid;
			Q6JsonLogSunny(Warning, "UCombatAllyBarWidget::UpdateSkillNote - invalid ultimate skill state");
		}
	}));
}

void UCombatAllyBarWidget::PlayChainEffect()
{
	AttackPortraitWidget->PlayChainEffect();
}

void UCombatAllyBarWidget::PlayDoubleSkillEffect(bool bIsOwner)
{
	AttackPortraitWidget->PlayDoubleSkillEffect(bIsOwner);
}

void UCombatAllyBarWidget::UpdateSkillBlocked()
{
	AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		Q6JsonLogSunny(Warning, "UCombatAllyBarWidget::UpdateSkillBlocked - Invalid unit", Q6KV("UnitId", UnitId));
		return;
	}

	bNormalSkillBlocked = false;
	bUltimateSkillBlocked = false;
	if (Unit->HasCCBuffEffect(ECrowdControl::Silence))
	{
		bUltimateSkillBlocked = true;
	}
	if (Unit->HasCCBuffEffect(ECrowdControl::Stun))
	{
		bNormalSkillBlocked = true;
		bUltimateSkillBlocked = true;
	}
}

void UCombatAllyBarWidget::PlaySkillBlockedAnimation(ESkillCategory SkillCategory)
{
	AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		Q6JsonLogSunny(Warning, "UCombatAllyBarWidget::PlaySkillBlockedAnimation - invalid unit", Q6KV("UnitId", UnitId));
		return;
	}

	TArray<FBuffEffectState> BuffEffectStates;
	Unit->GatherCCBuffEffectsOnSkillUse(BuffEffectStates, SkillCategory);
	BuffNoticeListWidget->SetBuffs(BuffEffectStates, false);
}

void UCombatAllyBarWidget::OnStartWave()
{
	const AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	if (bDead)
	{
		return;
	}

	bSkipDefenseEnd = true;

	SetTurnSkillPhaseSelectable(false);
	PlayAnimation(TurnStartAnim);
}

void UCombatAllyBarWidget::OnSkillStart()
{
	bSkillUsed = true;

	AttackPortraitWidget->OnSkillStart();
}

void UCombatAllyBarWidget::OnSkillEnd()
{
	bSkillUsed = false;
	bSkipUpdateUltimateState = false;

	AttackPortraitWidget->OnSkillEnd();
}

void UCombatAllyBarWidget::OnNormalSkillClicked()
{
	bSkipUpdateUltimateState = true;

	if (bNormalSkillBlocked)
	{
		PlaySkillBlockedAnimation(ESkillCategory::Normal);
	}
	else
	{
		AttackPortraitWidget->OnSkillClicked(ESkillCategory::Normal);
		OnSkillSelectedDelegate.ExecuteIfBound(UnitId, NormalSkillId);
	}
}

void UCombatAllyBarWidget::OnUltimateSkillClicked()
{
	if (bUltimateSkillBlocked)
	{
		PlaySkillBlockedAnimation(ESkillCategory::Ultimate);
	}
	else
	{
		AttackPortraitWidget->OnSkillClicked(ESkillCategory::Ultimate);
		OnSkillSelectedDelegate.ExecuteIfBound(UnitId, UltimateSkillId);
	}
}

void UCombatAllyBarWidget::OnUltimateSkillStartAnimFinished()
{
	OnSkillStartAnimFinishedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatEnemyBarWidget

UCombatEnemyBarWidget::UCombatEnemyBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bDanger(false)
{
}

void UCombatEnemyBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UltimateAlertStartAnim = GetWidgetAnimationFromName(this, "AnimInDanger");
	UltimateAlertStopAnim = GetWidgetAnimationFromName(this, "AnimOutDanger");
	DeadAnim = GetWidgetAnimationFromName(this, "AnimDead");
	CheckedAnim = GetWidgetAnimationFromName(this, "AnimChecked");
	CheckedLoopAnim = GetWidgetAnimationFromName(this, "AnimCheckedLoop");
	UnCheckedAnim = GetWidgetAnimationFromName(this, "AnimUnChecked");
	BossAnim = GetWidgetAnimationFromName(this, "AnimPlayBoss");
	MonsterAnim = GetWidgetAnimationFromName(this, "AnimPlayMonster");
	RaidBossAnim = GetWidgetAnimationFromName(this, "AnimRaidBoss");
	RebirthAnim = GetWidgetAnimationFromName(this, "AnimMonsterRebirth");

	BarBgImage = CastChecked<UImage>(GetWidgetFromName("BarBg"));
	SkillCooldownPointListWidget = CastChecked<UCombatPointListWidget>(GetWidgetFromName("SkillCooldown"));

    NickNameText = CastChecked<UTextBlock>(GetWidgetFromName("NickName"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClickedDelegate.BindUObject(this, &UCombatEnemyBarWidget::OnSelectButtonClicked);
	SelectButton->OnLongClickedDelegate.BindUObject(this, &UCombatEnemyBarWidget::OnSelectButtonLongClicked);
}

void UCombatEnemyBarWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == RebirthAnim)
	{
		OnSpawnAnimFinishedDelegate.ExecuteIfBound();
	}
}

void UCombatEnemyBarWidget::InitBar(const FUnitState& UnitState, ESpawnReason Reason)
{
	Super::InitBar(UnitState, Reason);

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource)
	{
		CombatGameResource->SetUnitBarBgImage(BarBgImage, UnitState.Category);
	}

	if (UnitState.UnitType == UnitTypeInvalid.x)
	{
		Q6JsonLogSunny(Warning, "UCombatEnemyBarWidget::InitBar - Invalid UnitType", Q6KV("UnitType", UnitState.UnitType));
		return;
	}

	switch (UnitState.Category)
	{
		case EAttributeCategory::StaticMonster:
		case EAttributeCategory::MN_Weak:
		case EAttributeCategory::MN_Normal:
		case EAttributeCategory::MN_Strong:
		case EAttributeCategory::MN_Elite:
			PlayAnimation(MonsterAnim);
			break;
		case EAttributeCategory::MB_Little:
		case EAttributeCategory::MB_Weak:
		case EAttributeCategory::MB_Middle:
		case EAttributeCategory::MB_Strong:
		case EAttributeCategory::MB_Final:
			PlayAnimation(BossAnim);
			break;
		case EAttributeCategory::MB_Legend:
			PlayAnimation(RaidBossAnim);
			break;
		default:
			ensure(0);
	}

	switch (Reason)
	{
		case ESpawnReason::SubParty:
		case ESpawnReason::Summon:
		case ESpawnReason::Rebirth:
		case ESpawnReason::WipeoutContinue:
		case ESpawnReason::RebirthSummon:
			PlayAnimation(RebirthAnim);
			break;
		default:
			OnSpawnAnimFinishedDelegate.ExecuteIfBound();
			break;
	}

	PlayAnimation(UnCheckedAnim);

	FUnitType UnitType(UnitState.UnitType);
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(UnitType);
	if (UnitRow.IsInvalid() || UnitRow.NickName.IsEmptyOrWhitespace())
	{
		NickNameText->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		NickNameText->SetText(UnitRow.NickName);
		NickNameText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void UCombatEnemyBarWidget::SetSelectedBar(bool bSelected)
{
	if (bSelected)
	{
		StopAnimation(UnCheckedAnim);
		PlayAnimation(CheckedAnim);
		PlayAnimation(CheckedLoopAnim, 0.0f, 0);
	}
	else
	{
		StopAnimation(CheckedAnim);
		StopAnimation(CheckedLoopAnim);
		PlayAnimation(UnCheckedAnim);
	}
}

void UCombatEnemyBarWidget::SetPhase(ECPTurnPhase TurnPhase)
{
	if (TurnPhase == ECPTurnPhase::OppAttack)
	{
		SetSelectedBar(false);
	}
}

void UCombatEnemyBarWidget::UpdateUltimateSkill()
{
	AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	int32 NextCoolTime = 0;
	Unit->GetNextUltimateSkillWaitdown(NextCoolTime);
	SetSkillWaitdown(NextCoolTime, true);
}

void UCombatEnemyBarWidget::SynchronizeCCState(ECCTurnPhase InPhase)
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	SetPhase(Presenter->CCPhaseToCPPhase(InPhase));

	const AUnit* BarUnit = Presenter->FindUnit(UnitId);
	if (!BarUnit)
	{
		return;
	}

	int32 NextSkillWaitdown = INVALID_WAITDOWN;
	int32 InitialWaitdown = 0;
	BarUnit->GetNextUltimateSkillWaitdown(NextSkillWaitdown, &InitialWaitdown);
	SetInitialWaitdown(InitialWaitdown);
	SetSkillWaitdown(NextSkillWaitdown);
}

void UCombatEnemyBarWidget::SetSkillWaitdown(int32 Waitdown, bool bSkipDangerAnim)
{
	int32 MaxWaitdown = GetMaxSkillWaitdown();
	int32 ChargedWaitdown = FMath::Max(MaxWaitdown - Waitdown, 0);
	SkillCooldownPointListWidget->SetCooldown(FMath::Clamp(ChargedWaitdown, 0, MAX_ULTIMATE_SKILL_COOLDOWN));

	if (bDanger)
	{
		StopAnimation(UltimateAlertStartAnim);
		PlayAnimation(UltimateAlertStopAnim);
		bDanger = false;
	}

	if (Waitdown == 0 && !bSkipDangerAnim)
	{
		StopAnimation(UltimateAlertStopAnim);
		PlayAnimation(UltimateAlertStartAnim);
		bDanger = true;
	}
}

void UCombatEnemyBarWidget::SetInitialWaitdown(int32 InInitialWaitdown)
{
	int32 InitialWaitdown = FMath::Max(InInitialWaitdown - 1, 0);
	SkillCooldownPointListWidget->SetMaxCooldown(InitialWaitdown);
}

void UCombatEnemyBarWidget::PlayUltimateAlertAnim(bool bStart)
{
	PlayAnimation(bStart ? UltimateAlertStartAnim : UltimateAlertStopAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatTurnSkillWidget

UCombatTurnSkillWidget::UCombatTurnSkillWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Index(INDEX_NONE)
	, UnitId(CCUnitIdInvalid)
	, SkillId(CCSkillIdInvalid)
	, bForbidden(false)
	, bLocked(false)
	, bUsed(false)
{
}

void UCombatTurnSkillWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DefaultAnim = GetWidgetAnimationFromName(this, "AnimSkillDefault");
	UseNormalAnim = GetWidgetAnimationFromName(this, "AnimSkillUseNormal");
	UseQuickAnim = GetWidgetAnimationFromName(this, "AnimSkillUseQuick");
	UsedAnim = GetWidgetAnimationFromName(this, "AnimSkillUsed");
	ForbiddenAnim = GetWidgetAnimationFromName(this, "AnimSkillForbidden");
	DetailOffAnim = GetWidgetAnimationFromName(this, "AnimDetailOff");
	DetailOnAnim = GetWidgetAnimationFromName(this, "AnimDetailOn");
	LockedAnim = GetWidgetAnimationFromName(this, "AnimSkillLocked");

	TitleSkillImage = CastChecked<UImage>(GetWidgetFromName("ImageSkillSmall"));
	SkillImage = CastChecked<UImage>(GetWidgetFromName("ImageSkill"));
	SkillLevelText = CastChecked<UTextBlock>(GetWidgetFromName("TextSkillLevel"));
	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextSkillName"));
	SkillDescText = CastChecked<URichTextBlock>(GetWidgetFromName("TextSkillInfo"));
	SkillCoolTimeText = CastChecked<UTextBlock>(GetWidgetFromName("TextSkillCoolTime"));
	CoolTimeLeftInfiniteImage = CastChecked<UImage>(GetWidgetFromName("CoolTimeLeftInfinite"));
	CoolTimeLeftText = CastChecked<UTextBlock>(GetWidgetFromName("CoolTimeLeftNum"));

	SkillUseCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("SkillUseCheck"));
	SkillUseCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UCombatTurnSkillWidget::OnSkillUseCheckBoxChecked);

	SkillUseButton = CastChecked<UButton>(GetWidgetFromName("SkillUseBtn"));
	SkillUseButton->OnClicked.AddUniqueDynamic(this, &UCombatTurnSkillWidget::OnSkillUseButtonClicked);
}

void UCombatTurnSkillWidget::SetTurnSkill(const FCCUnitId& InUnitId)
{
	AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(InUnitId);
	if (!Unit)
	{
		return;
	}
	UnitId = InUnitId;

	const TArray<FSkillState>& TurnBegins = Unit->GetUnitState().TurnBegins;

	bLocked = !(TurnBegins.IsValidIndex(Index)) || TurnBegins[Index].Level == 0;
	if (bLocked)
	{
		PlayAnimation(LockedAnim);
		return;
	}

	const FSkillState& SkillState = TurnBegins[Index];
	int32 SkillType = SkillState.SkillType;
	if (SkillType == SkillTypeInvalid)
	{
		Q6JsonLogSunny(Warning, "UCombatTurnSkillWidget::SetTurnSkill - invalid turn skill");

		bLocked = true;
		PlayAnimation(LockedAnim);
		return;
	}
	SkillId = SkillState.SkillId;

	const UCMS* CMS = GetCMS();
	check(CMS);

	int32 ModelType = CMS->GetModelTypeFromUnitType(Unit->GetUnitState().UnitType);
	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(ModelType);
	if (SkillAssetRow.TurnSkillIcons.IsValidIndex(Index))
	{
		TitleSkillImage->SetBrush(SkillAssetRow.TurnSkillIcons[Index]);
		SkillImage->SetBrush(SkillAssetRow.TurnSkillIcons[Index]);
	}

	FText LevelFText = Q6Util::GetLocalizedText("Common", "Level");
	LevelFText = FText::Format(LevelFText, FText::AsNumber(SkillState.Level));
	SkillLevelText->SetText(LevelFText);

	const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillType);
	SkillNameText->SetText(SkillRow.DescName);
	SkillDescText->SetText(BuildToolTipDesc(SkillType, SkillState.Level, ESkillCategory::TurnBegin));

	UpdateTurnSkillState();
}

void UCombatTurnSkillWidget::UpdateTurnSkillState()
{
	if (bLocked)
	{
		return;
	}

	AUnit* Unit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
	if (!Unit)
	{
		return;
	}

	const FSkillState& SkillState = Unit->GetUnitState().TurnBegins[Index];

	int32 SkillCoolTime = SkillState.CoolTime;
	SkillCoolTimeText->SetText(FText::AsNumber(SkillCoolTime));

	bUsed = SkillState.Cooldown > 0;

	const FCCBuffCoolTime& CCBuffCoolTime = Unit->GetCCBuffCoolTime();

	if (CCBuffCoolTime.bInfinity)
	{
		bForbidden = true;
		CoolTimeLeftText->SetVisibility(ESlateVisibility::Collapsed);
		CoolTimeLeftInfiniteImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		PlayAnimation(ForbiddenAnim);
	}
	else
	{
		CoolTimeLeftInfiniteImage->SetVisibility(ESlateVisibility::Collapsed);

		if (CCBuffCoolTime.CCDuration > 0)
		{
			bForbidden = true;
			CoolTimeLeftText->SetText(FText::AsNumber(CCBuffCoolTime.CCDuration));
			CoolTimeLeftText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			PlayAnimation(ForbiddenAnim);
		}
		else
		{
			bForbidden = false;

			if (bUsed)
			{
				CoolTimeLeftText->SetText(FText::AsNumber(SkillState.Cooldown));
				CoolTimeLeftText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
				PlayAnimation(UsedAnim);
			}
			else
			{
				CoolTimeLeftText->SetVisibility(ESlateVisibility::Collapsed);
				PlayAnimation(bQuickUse ? UseQuickAnim : DefaultAnim);
			}
		}
	}
}

void UCombatTurnSkillWidget::UpdateQuickSkillState(bool bInQuickUse)
{
	SetQuickUse(bInQuickUse);

	if (bLocked || bForbidden || bUsed)
	{
		return;
	}

	PlayAnimation(bQuickUse ? UseQuickAnim : DefaultAnim);
}

void UCombatTurnSkillWidget::SetSelected(bool bInSelected)
{
	if (bInSelected)
	{
		SkillUseCheckBox->SetCheckedState(ECheckBoxState::Checked);

		StopAnimation(DetailOffAnim);
		PlayAnimation(DetailOnAnim);

		if (!bLocked && !bForbidden && !bUsed)
		{
			PlayAnimation(UseNormalAnim);
		}
	}
	else
	{
		SkillUseCheckBox->SetCheckedState(ECheckBoxState::Unchecked);

		StopAnimation(DetailOnAnim);
		PlayAnimation(DetailOffAnim);

		if (!bLocked && !bForbidden && !bUsed && !bQuickUse)
		{
			StopAnimation(UseNormalAnim);
			PlayAnimation(DefaultAnim);
		}
	}
}

void UCombatTurnSkillWidget::OnSkillUseCheckBoxChecked(bool bChecked)
{
	if (bQuickUse)
	{
		return;
	}

	OnTurnSkillClickedDelegate.ExecuteIfBound(Index);
}

void UCombatTurnSkillWidget::OnSkillUseButtonClicked()
{
	if (bForbidden)
	{
		OnTurnSkillBlockedDelegate.ExecuteIfBound();
	}
	else
	{
		OnTurnSkillUseClickedDelegate.ExecuteIfBound(SkillId);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatTotalDamageWidget

UCombatTotalDamageWidget::UCombatTotalDamageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatTotalDamageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StartDamageAnim = GetWidgetAnimationFromName(this, "AnimDamageStart");

	ColorAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimColorStrong"));
	ColorAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimColorNormal"));
	ColorAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimColorWeak"));

	CriticalAnim = GetWidgetAnimationFromName(this, "AnimColorCritical");
	ShieldAnim = GetWidgetAnimationFromName(this, "AnimColorShield");

	AllyPositionAnim = GetWidgetAnimationFromName(this, "AnimPositionAlly");
	EnemyPositionAnim = GetWidgetAnimationFromName(this, "AnimPositionEnemy");

	DamageText = CastChecked<UTextBlock>(GetWidgetFromName("TextDamage"));

	ExtraDamageBox = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxExtraDamage"));
	ExtraDamageText = CastChecked<UTextBlock>(GetWidgetFromName("TextExtraDamage"));
}

void UCombatTotalDamageWidget::SetDamage(const UUnitHit* HitPerUnit, bool bPassOver)
{
	int32 HitIndex = HitPerUnit->HitIndex;

	if (HitIndex == INDEX_NONE)
	{
		Q6JsonLogRoze(Warning, "UCombatTotalDamageWidget::SetDamage - Invalid Hit", Q6KV("HitIndex", HitIndex));
		return;
	}

	int32 BaseDamage = FMath::Abs(HitPerUnit->AddedBaseHealth);
	int32 ShieldDamage = FMath::Abs(HitPerUnit->ShieldDamage);
	TotalBaseDamage += BaseDamage + ShieldDamage;

	int32 ExtraDamage = FMath::Abs(HitPerUnit->AddedExtraHealth);
	int32 ExtraShieldDamage = FMath::Abs(HitPerUnit->ExtraShieldDamage);
	TotalExtraDamage += ExtraDamage + ExtraShieldDamage;

	if (!HitPerUnit->IsLastHit() || bPassOver)
	{
		return;
	}

	DamageText->SetText(FText::AsNumber(TotalBaseDamage));
	if (TotalExtraDamage > 0)
	{
		ExtraDamageText->SetText(FText::AsNumber(TotalExtraDamage));
		ExtraDamageBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		ExtraDamageBox->SetVisibility(ESlateVisibility::Collapsed);
	}

	// Set Position
	const AUnit* TargetUnit = GetCheckedCombatPresenter(this)->FindUnit(HitPerUnit->TargetUnitId);
	ECCFaction TargetUnitFaction = TargetUnit->GetOverrideFaction();
	PlayAnimation(TargetUnitFaction == ECCFaction::Ally ? EnemyPositionAnim : AllyPositionAnim);

	// Set Color
	if (HitPerUnit->bCritical)
	{
		PlayAnimation(CriticalAnim);
	}
	else if (BaseDamage)
	{
		int32 NatureRelationTypeIndex = (int32)HitPerUnit->NatureRelationType;

		if (!ColorAnims.IsValidIndex(NatureRelationTypeIndex))
		{
			Q6JsonLogGunny(Warning, "UCombatTotalDamageWidget::SetDamage - NatureRelationTypeIndex is not valid",
				Q6KV("NatureRelationTypeIndex", NatureRelationTypeIndex));
			return;
		}

		PlayAnimation(ColorAnims[NatureRelationTypeIndex]);
	}
	else
	{
		PlayAnimation(ShieldAnim);
	}

	// Start Total Damage
	PlayAnimation(StartDamageAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatSkillBlockingWidget

UCombatSkillBlockingWidget::UCombatSkillBlockingWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatSkillBlockingWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* BlockButton = CastChecked<UButton>(GetWidgetFromName("Block"));
	BlockButton->OnClicked.AddUniqueDynamic(this, &UCombatSkillBlockingWidget::OnBlockButtonClicked);

	BlockOnAnim = GetWidgetAnimationFromName(this, "AnimBlockOn");
	BlockOffAnim = GetWidgetAnimationFromName(this, "AnimBlockOff");
}

void UCombatSkillBlockingWidget::SetBlockEnabled(bool bBlockEnabled)
{
	PlayAnimation(bBlockEnabled ? BlockOnAnim : BlockOffAnim);
}

void UCombatSkillBlockingWidget::OnBlockButtonClicked()
{
	OnBlockButtonClickDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatOverKillWidget

UCombatOverKillWidget::UCombatOverKillWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatOverKillWidget::NativeConstruct()
{
	Super::NativeConstruct();

	GetAnim = GetWidgetAnimationFromName(this, "AnimOverkillGet");
	UseAnim = GetWidgetAnimationFromName(this, "AnimOverkillUse");
	DisAnim = GetWidgetAnimationFromName(this, "AnimOverkillDis");

	OverKillBox = CastChecked<UHorizontalBox>(GetWidgetFromName("Overkill"));
	CountText = CastChecked<UTextBlock>(GetWidgetFromName("TextOverkillCount"));
}

void UCombatOverKillWidget::Init()
{
	OverKillBox->SetVisibility(ESlateVisibility::Collapsed);
}

void UCombatOverKillWidget::SetOverKill(int32 OldOK, int32 NewOK)
{
	if (NewOK == OldOK)
	{
		return;
	}

	CountText->SetText(FText::AsNumber(NewOK));

	if (NewOK == 0)
	{
		PlayAnimation(UseAnim);
	}
	else if (NewOK > OldOK)
	{
		PlayAnimation(GetAnim);
	}
	else
	{
		PlayAnimation(DisAnim);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatChainEffectWidget

UCombatChainEffectWidget::UCombatChainEffectWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatChainEffectWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ChainEffectAnim = GetWidgetAnimationFromName(this, "AnimChainEffect");
	AChainAnim = GetWidgetAnimationFromName(this, "AnimChainStateA");
	BChainAnim = GetWidgetAnimationFromName(this, "AnimChainStateB");
	CChainAnim = GetWidgetAnimationFromName(this, "AnimChainStateC");
	SChainAnim = GetWidgetAnimationFromName(this, "AnimChainStateS");

	EffectText = CastChecked<UTextBlock>(GetWidgetFromName("Effect"));
}

void UCombatChainEffectWidget::PlayChainEffect(ESkillNote InSkillNote, const FText& InSkillDesc)
{
	switch (InSkillNote)
	{
		case ESkillNote::Ace:
			PlayAnimation(AChainAnim);
			break;
		case ESkillNote::Break:
			PlayAnimation(BChainAnim);
			break;
		case ESkillNote::Closer:
			PlayAnimation(CChainAnim);
			break;
		case ESkillNote::None:
		default:
			Q6JsonLogSunny(Warning, "UCombatChainEffectWidget::PlayChainEffect - Invalid Skill Note", Q6KV("SkillNote", (uint8)InSkillNote));
			return;
	}

	PlayChainEffectInternal(InSkillDesc);
}

void UCombatChainEffectWidget::PlayStraightChainEffect(const FText& InSkillDesc)
{
	PlayAnimation(SChainAnim);
	PlayChainEffectInternal(InSkillDesc);
}

void UCombatChainEffectWidget::PlayChainEffectInternal(const FText& InSkillDesc)
{
	EffectText->SetText(InSkillDesc);
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	PlayAnimation(ChainEffectAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatWaveWidget

UCombatWaveWidget::UCombatWaveWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatWaveWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PartyTypeWidget = CastChecked<UCombatWavePartyTypeWidget>(GetWidgetFromName("PartyType"));

	ZoneNameGroupBorder = CastChecked<UBorder>(GetWidgetFromName("ZoneNameGroup"));
	ZoneNameText = CastChecked<UTextBlock>(GetWidgetFromName("ZoneName"));

	if (GetCheckedCombatPresenter(this)->GetCombatSeed().CombatMultiSideInfo.bIsCombatMultiSide)
	{
		// PartyTypeWidget & ZoneName are used in combat multiside only
		PartyTypeWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		ZoneNameGroupBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		PartyTypeWidget->SetVisibility(ESlateVisibility::Collapsed);
		ZoneNameGroupBorder->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCombatWaveWidget::PlayPartyAnimation(bool bIsMainParty)
{
	if (PartyTypeWidget)
	{
		PartyTypeWidget->PlayPartyAnimation(bIsMainParty);
	}
}

void UCombatWaveWidget::SetZoneName(const FText& ZoneName)
{
	ZoneNameText->SetText(ZoneName);

	if (ZoneName.IsEmpty())
	{
		Q6JsonLogPawn(Warning, "ZoneName is empty");
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatWavePartyTypeWidget

UCombatWavePartyTypeWidget::UCombatWavePartyTypeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatWavePartyTypeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MainPartyAnim = GetWidgetAnimationFromName(this, "AnimMainParty");
	SubPartyAnim = GetWidgetAnimationFromName(this, "AnimSubParty");
}

void UCombatWavePartyTypeWidget::PlayPartyAnimation(bool bIsMainParty)
{
	if (bIsMainParty)
	{
		PlayAnimation(MainPartyAnim);
	}
	else
	{
		PlayAnimation(SubPartyAnim);
	}
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatTurnPhaseWidget

UCombatTurnPhaseWidget::UCombatTurnPhaseWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UCombatTurnPhaseWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ShowAndOffAnim = GetWidgetAnimationFromName(this, "ShowAndOff");
	ShowAndOffShortAnim = GetWidgetAnimationFromName(this, "ShowAndOffShort");

	EffLeftImage = CastChecked<UImage>(GetWidgetFromName("EffLeft"));
	EffRightImage = CastChecked<UImage>(GetWidgetFromName("EffRight"));
	TurnPhaseText = CastChecked<UTextBlock>(GetWidgetFromName("TurnPhase"));
	BGImage = CastChecked<UImage>(GetWidgetFromName("Background"));
}

void UCombatTurnPhaseWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	OnTurnPhaseAnimFinishedDelegate.ExecuteIfBound();
}

void UCombatTurnPhaseWidget::PlayTurnAnimation(int32 TurnCount)
{
	TurnPhaseText->SetText(FText::Format(StartTurnState.Text, FText::AsNumber(TurnCount)));
	PlayTurnPhaseAnimation(StartTurnState);
}

void UCombatTurnPhaseWidget::PlayPhaseAnimation(ECPTurnPhase TurnPhase)
{
	if (TurnPhase == ECPTurnPhase::Steady)
	{
		TurnPhaseText->SetText(AttackPhaseState.Text);
		PlayTurnPhaseAnimation(AttackPhaseState);
	}
	else if (TurnPhase == ECPTurnPhase::OppAttack)
	{
		TurnPhaseText->SetText(OppAttackPhaseState.Text);
		PlayTurnPhaseAnimation(OppAttackPhaseState);
	}
}

void UCombatTurnPhaseWidget::PlayTurnPhaseAnimation(const FTurnPhaseWidgetState& TurnPhaseState)
{
	EffLeftImage->SetBrushFromMaterial(TurnPhaseState.EffectMI.LoadSynchronous());
	EffRightImage->SetBrushFromMaterial(TurnPhaseState.EffectMI.LoadSynchronous());

	EffLeftImage->SetRenderScale(TurnPhaseState.RenderScale);
	EffRightImage->SetRenderScale(TurnPhaseState.RenderScale);

	BGImage->SetColorAndOpacity(TurnPhaseState.BGColor);

	if (TurnPhaseState.bShort)
	{
		PlayAnimation(ShowAndOffShortAnim);
	}
	else
	{
		PlayAnimation(ShowAndOffAnim);
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidUserRankingEntryWidget
//////////////////////////////////////////////////////////////////////////

URaidUserRankingEntryWidget::URaidUserRankingEntryWidget(const FObjectInitializer& ObjectInitializer)
	:Super(ObjectInitializer)
{

}

void URaidUserRankingEntryWidget::NativeConstruct()
{
	RankAnims.Empty();

	RankAnims.Add(GetWidgetAnimationFromName(this, "AnimSet1st"));
	RankAnims.Add(GetWidgetAnimationFromName(this, "AnimSet2nd"));
	RankAnims.Add(GetWidgetAnimationFromName(this, "AnimSet3rd"));
	SetOtherAnim = GetWidgetAnimationFromName(this, "AnimSetOther");
	MyColorAnim = GetWidgetAnimationFromName(this, "AnimMyColor");
	OtherColorAnim = GetWidgetAnimationFromName(this, "AnimOtherColor");

	IconRankImage = CastChecked<UImage>(GetWidgetFromName("IconRank"));

	RankNumText = CastChecked<UTextBlock>(GetWidgetFromName("RankNum"));
	UserNameText = CastChecked<UTextBlock>(GetWidgetFromName("UserName"));
	ScoreText = CastChecked<UTextBlock>(GetWidgetFromName("Score"));
}

void URaidUserRankingEntryWidget::SetInfo(int32 InRank, const FText& InUserName, int32 InScore, bool bIsMine)
{
	RankNumText->SetText(FText::AsNumber(InRank));
	UserNameText->SetText(InUserName);
	ScoreText->SetText(FText::AsNumber(InScore));

	if (!RankAnims.IsValidIndex(0))
	{
		Q6JsonLogGunny(Warning, "URaidUserRankingEntryWidget::SetInfo - RankAnims don't exist.");
		return;
	}

	PlayAnimation(InRank <= 3 ? RankAnims[FMath::Clamp(InRank - 1, 0, 2)] : SetOtherAnim);
	PlayAnimation(bIsMine ? MyColorAnim : OtherColorAnim);
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatResultWidget

UCombatResultWidget::UCombatResultWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, PlayerRank(0)
	, bBattleEndAnimFinished(true)
	, ContentType(EContentType::None)
{
}

void UCombatResultWidget::NativeConstruct()
{
	Super::NativeConstruct();

	WinAnim = GetWidgetAnimationFromName(this, "AnimWin");
	RewardAnim = GetWidgetAnimationFromName(this, "AnimReward");
	RaidRankingAnim = GetWidgetAnimationFromName(this, "AnimRaidRanking");
	RaidRewardAnim = GetWidgetAnimationFromName(this, "AnimRaidReward");
	FailedAnim = GetWidgetAnimationFromName(this, "AnimFailed");
	BattleEndAnim = GetWidgetAnimationFromName(this, "AnimBattleEnd");
	GotoRankingListAnim = GetWidgetAnimationFromName(this, "AnimGotoRankingList");
	BackRankingListAnim = GetWidgetAnimationFromName(this, "AnimBackRankingList");

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
	RankingListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("RankingList"));

	StageNumberText = CastChecked<UTextBlock>(GetWidgetFromName("StageNum"));
	StageText = CastChecked<UTextBlock>(GetWidgetFromName("Stage"));

	UserNameText = CastChecked<UTextBlock>(GetWidgetFromName("UserName"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("LevelNum"));
	LevelUpBox = CastChecked<USizeBox>(GetWidgetFromName("LvUP"));
	ExpText = CastChecked<UTextBlock>(GetWidgetFromName("Exp"));
	XpGauge = CastChecked<UProgressBar>(GetWidgetFromName("ExpBar"));

	TitleRankingText = CastChecked<UTextBlock>(GetWidgetFromName("TitleRanking"));
	RankingText = CastChecked<UTextBlock>(GetWidgetFromName("Ranking"));
	DamageScoreText = CastChecked<UTextBlock>(GetWidgetFromName("DamageScore"));
	ClearBonusText = CastChecked<UTextBlock>(GetWidgetFromName("ClearBonus"));
	ClearBonusInfoText = CastChecked<UTextBlock>(GetWidgetFromName("ClearBonusInfo"));
	TurnBonusText = CastChecked<UTextBlock>(GetWidgetFromName("TurnBonus"));
	TurnBonusInfoText = CastChecked<UTextBlock>(GetWidgetFromName("TurnBonusInfo"));
	SurviveBonusText = CastChecked<UTextBlock>(GetWidgetFromName("SurviveBonus"));
	SurviveBonusInfoText = CastChecked<UTextBlock>(GetWidgetFromName("SurviveBonusInfo"));
	TotalScoreText = CastChecked<UTextBlock>(GetWidgetFromName("TotalScore"));
	InfoText = CastChecked<UTextBlock>(GetWidgetFromName("TextInfo"));
	PointGetText = CastChecked<UTextBlock>(GetWidgetFromName("PointGet"));
	PointBonusGetText = CastChecked<UTextBlock>(GetWidgetFromName("PointBonusGet"));
	PointTotalText = CastChecked<UTextBlock>(GetWidgetFromName("PointTotal"));

	for (int32 n = 0; n < MAX_BOND_ICON_COUNT; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Slot%d"), n);
		USimpleItemCardWidget* CardWidget = CastChecked<USimpleItemCardWidget>(GetWidgetFromName(*WidgetName));
		BondWidgets.AddUnique(CardWidget);
	}

	EventPointPanelBorder = CastChecked<UBorder>(GetWidgetFromName("EventPointPanel"));
	PointIconBigImage = CastChecked<UImage>(GetWidgetFromName("PointIconBig"));
	BonusPointBox = CastChecked<UHorizontalBox>(GetWidgetFromName("BonusPointBox"));

	UButton* TouchScreen = CastChecked<UButton>(GetWidgetFromName("BtnTouchScreen"));
	TouchScreen->OnClicked.AddUniqueDynamic(this, &UCombatResultWidget::OnTouchScreenClicked);

	UButton* ExitButton = CastChecked<UButton>(GetWidgetFromName("Exit"));
	ExitButton->OnClicked.AddUniqueDynamic(this, &UCombatResultWidget::OnExitButtonClicked);

	UButton* UserRankButton = CastChecked<UButton>(GetWidgetFromName("UserRank"));
	UserRankButton->OnClicked.AddUniqueDynamic(this, &UCombatResultWidget::OnUserRankButtonClicked);

	UButton* BackUserRankButton = CastChecked<UButton>(GetWidgetFromName("BackUserRank"));
	BackUserRankButton->OnClicked.AddUniqueDynamic(this, &UCombatResultWidget::OnBackUserRankButtonClicked);

	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::Saga);
	SubscribeToStore(EHSType::Bond);
}

bool HasEventPointReward(FEventContentType InEventContentType, int32 InReceivedPoint)
{
	const UCMS* CMS = GetCMS();
	TArray<const FCMSEventContentAccumPointRewardRow*> EventRewards = CMS->GetEventContentAccumPointRewards(InEventContentType);

	TArray<int32> EventPoints = GetHUDStore().GetEventManager().GetEventPoint(InEventContentType);
	int32 TotalPoint = EventPoints[1];

	for (const FCMSEventContentAccumPointRewardRow* Iter : EventRewards)
	{
		int32 PrevPoint = TotalPoint - InReceivedPoint;
		int32 StandardPoint = Iter->AccumPoint;

		if (StandardPoint < PrevPoint)
		{
			continue;
		}
		else if (StandardPoint <= PrevPoint + InReceivedPoint)
		{
			return true;
		}
	}

	return false;
}

void UCombatResultWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == WinAnim)
	{
		OnWinAnimFinishedDelegate.ExecuteIfBound();
	}
	if (Animation == BattleEndAnim)
	{
		bBattleEndAnimFinished = true;
		if (ContentType == EContentType::Raid)
		{
			PlayRaidResultAnim(false);
		}
		else if (ContentType == EContentType::RaidFinal)
		{
			PlayRaidResultAnim(true);
		}
		else if (ContentType == EContentType::DailyDungeon)
		{
			PlayRewardAnimation();
		}
	}
	if (Animation == RewardAnim)
	{
		if (!(ContentType == EContentType::Event || ContentType == EContentType::MultiSideBattle))
		{
			return;
		}

		const UQ6GameInstance* GameInstance = UQ6GameInstance::Get(this);
		const FCCCombatSeed& CombatSeed = GameInstance->GetCombatSeed();
		const UCMS* CMS = GetCMS();
		check(CMS);

		const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(CombatSeed.SagaType);
		FEventContentType EventContentType = CMS->GetEventContentType(SagaRow.CmsType());

		int32 ReceivedPoint = 0;
		ReceivedPoint = GameInstance->GetReceiveAccumEventPoint();

		if (HasEventPointReward(EventContentType, ReceivedPoint))
		{
			UEventRewardPopupWidget* RewardPopup = GetBaseHUD(this)->OpenEventRewardPopupWidget();
			RewardPopup->SetCombatRewardInfos(EventContentType, ReceivedPoint);
		}
	}
}

void UCombatResultWidget::SetResult(EContentType InContentType, const ECCResult& InResult)
{
	ContentType = InContentType;
	Result = InResult;

	if (Result == ECCResult::Unknown)
	{
		SetVisibility(ESlateVisibility::Collapsed);
		Q6JsonLogRoze(Warning, "UCombatResultWidget::SetResult - Why did you call me?",
			Q6KV("Result", (int32) Result));
		return;
	}

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	const FCCCombatSeed& CombatSeed = UQ6GameInstance::Get(this)->GetCombatSeed();
	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(CombatSeed.SagaType);
	const FEpisodeAssetRow& EpisodeRow = GetGameResource().GetEpisodeAssetRow(SagaRow.Episode);

	StageNumberText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "StageNum"), FText::AsNumber(SagaRow.Stage)));
	StageText->SetText(SagaRow.DescName);

	if (Result == ECCResult::Win)
	{
		PlayAnimation(WinAnim);
	}
}

void UCombatResultWidget::SetFailedResult(EContentType InContentType, ECCEndReason InEndResaon, ECCResult InResult)
{
	ContentType = InContentType;
	Result = InResult;

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	FText ReasonText;
	switch (InEndResaon)
	{
		case ECCEndReason::TimeOver:
			ReasonText = Q6Util::GetLocalizedText("Combat", "BattleEndTime");
			break;
		case ECCEndReason::TurnOver:
			ReasonText = Q6Util::GetLocalizedText("Combat", "BattleEndTurn");
			break;
		case ECCEndReason::Eliminated:
			ReasonText = Q6Util::GetLocalizedText("Combat", "BattleEndDead");
			break;
	}
	InfoText->SetText(ReasonText);

	bool bIsRaid = URaidManager::IsRaidResult(ContentType);
	bBattleEndAnimFinished = !bIsRaid;
	if (bIsRaid)
	{
		PlayAnimation(BattleEndAnim);
	}
	else
	{
		if (ContentType == EContentType::DailyDungeon && InResult == ECCResult::Tied)
		{
			PlayAnimation(BattleEndAnim);
		}
		else
		{
			PlayAnimation(FailedAnim);
		}
	}
}

void UCombatResultWidget::SetRaidResult(const FL2CRaidStageEndResp& Resp)
{
	const UCMS* CMS = GetCMS();
	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(Resp.SagaType);
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "UCombatResultWidget::SetRaidResult - SagaType Doesn't exist.");
	}

	check(SagaRow.ContentType == EContentType::Raid);
	ContentType = SagaRow.ContentType;

	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	const FRaidFinal* RaidFinal = RaidManager.Find(RaidManager.GetClearedRaidId());
	if (!RaidFinal)
	{
		Q6JsonLogGenie(Warning, "UCombatResultWidget::SetRaidResult - RaidFinal data wasn't exist.");
		return;
	}

	const FRaidFinalInfo& RaidFinalInfo = RaidFinal->GetInfo();
	TitleRankingText->SetText(Q6Util::GetLocalizedText("Combat", "CurrentRanking"));
	PlayerRank = RaidFinalInfo.Ranking;
	RankingText->SetText(FText::AsNumber(RaidFinalInfo.Ranking));

	int32 TotalScore = RaidFinalInfo.Score;
	TotalScoreText->SetText(FText::AsNumber(TotalScore));

	SetBond();

	DamageScoreText->SetText(FText::AsNumber(RaidFinalInfo.Damage));

	if (RaidFinalInfo.Score == RaidFinalInfo.Damage)
	{
		const FText Point = FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText"), FText::AsNumber(0));
		const FText Reason = Q6Util::GetLocalizedText("Combat", "RaidBonusAppliedWhenClear");

		ClearBonusText->SetText(Point);
		ClearBonusInfoText->SetText(Reason);

		TurnBonusText->SetText(Point);
		TurnBonusInfoText->SetText(Reason);

		SurviveBonusText->SetText(Point);
		SurviveBonusInfoText->SetText(Reason);
	}
	else
	{
		const FCMSRaidRow& RaidRow = CMS->GetRaidRowOrDummy(RaidFinalInfo.Type);

		ClearBonusText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText")
		, FText::AsNumber(RaidRow.ClearBonus)));
		ClearBonusInfoText->SetText(Q6Util::GetLocalizedText("Combat", "RaidBossClear"));

		const int32 TurnBonus = Resp.LeftTurn * RaidRow.LeftTurnBonus;

		TurnBonusText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText")
			, FText::AsNumber(TurnBonus)));
		TurnBonusInfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "TurnBonusInfo")
			, FText::AsNumber(Resp.LeftTurn)
			, FText::AsNumber(RaidRow.LeftTurnBonus)));

		const int32 SurviveBonus = RaidFinalInfo.Score - RaidFinalInfo.Damage - RaidRow.ClearBonus - TurnBonus;
		const int32 SurviveCharCount = RaidManager.GetSurviveCharCount();

		SurviveBonusText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText")
			, FText::AsNumber(SurviveBonus)));
		SurviveBonusInfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "RaidSurviveBonusInfo")
			, FText::AsNumber(SurviveCharCount)
			, FText::AsNumber(SurviveCharCount == 0 ? 0 : SurviveBonus / SurviveCharCount)));
	}
}

void UCombatResultWidget::SetRaidFinalResult(const FL2CRaidFinalStageEndResp& Resp)
{
	const UCMS* CMS = GetCMS();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Resp.SagaType);
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "UCombatResultWidget::SetRaidFinalResult - SagaType Doesn't exist.");
		return;
	}

	check(SagaRow.ContentType == EContentType::RaidFinal);
	ContentType = SagaRow.ContentType;

	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	const FRaidFinal* RaidFinal = RaidManager.Find(RaidManager.GetClearedRaidId());
	if (!RaidFinal)
	{
		Q6JsonLogGenie(Warning, "UCombatResultWidget::SetRaidFinalResult - RaidFinal data wasn't exist.");
		return;
	}

	const FRaidFinalInfo& RaidFinalInfo = RaidFinal->GetInfo();
	TitleRankingText->SetText(Q6Util::GetLocalizedText("Combat", "FinalRanking"));
	PlayerRank = RaidFinalInfo.Ranking;
	RankingText->SetText(FText::AsNumber(RaidFinalInfo.Ranking));

	int32 TotalScore = RaidFinalInfo.Score;
	TotalScoreText->SetText(FText::AsNumber(TotalScore));

	SetBond();
	SetRaidReward();
}

void UCombatResultWidget::SetUserInfo()
{
	const UWorldUser& WorldUser = GetUser();
	UserNameText->SetText(FText::FromString(WorldUser.GetNickname()));
	LevelText->SetText(FText::AsNumber(WorldUser.GetLevel()));
	XpGauge->SetPercent(WorldUser.GetXpRatio());

	if (WorldUser.IsLevelUp())
	{
		LevelUpBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		LevelUpBox->SetVisibility(ESlateVisibility::Collapsed);
	}

	const FCCCombatSeed& CombatSeed = UQ6GameInstance::Get(this)->GetCombatSeed();
	const UCMS* CMS = GetCMS();
	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(CombatSeed.SagaType);
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UCombatResultWidget::SetUserInfo - SagaRow does not exist.", Q6KV("SagaType", CombatSeed.SagaType));
		return;
	}

	ExpText->SetText(FText::AsNumber(SagaRow.RewardXp));
}

ERewardType _GetRewardType(ESagaRewardType SagaRewardType)
{
	switch (SagaRewardType)
	{
		case ESagaRewardType::DamageBossHp:
			return ERewardType::Goal;
		case ESagaRewardType::WaveSpawnUnitKill:
			return ERewardType::Bonus;
	}

	return ERewardType::None;
}

void UCombatResultWidget::SetReward()
{
	ItemListWidget->ClearList();

	const TArray<FRewardInfo> RewardInfos = UQ6GameInstance::Get(this)->GetRewardInfos();
	for (const FRewardInfo& RewardInfo : RewardInfos)
	{
		// clear reward & random spawn reward
		if (RewardInfo.Type == ESagaRewardType::Clear
			|| RewardInfo.Type == ESagaRewardType::WaveSpawnUnitKill
			|| RewardInfo.Type == ESagaRewardType::DamageBossHp)
		{
			ERewardType RewardType = _GetRewardType(RewardInfo.Type);
			SetRewardItems(RewardInfo.ItemList, RewardInfo.CurrencyList, RewardType);
		}
	}

	SetBond();
}

void UCombatResultWidget::SetRaidReward()
{
	ItemListWidget->ClearList();

	const TArray<FRewardInfo>& RewardInfos = UQ6GameInstance::Get(this)->GetRewardInfos();
	FRewardInfo ClearedRewardInfo;
	for (const FRewardInfo& RewardInfo : RewardInfos)
	{
		if (RewardInfo.Type == ESagaRewardType::Clear)
		{
			ClearedRewardInfo = RewardInfo;
			break;
		}
	}

	for (const FCurrency& Currency : ClearedRewardInfo.CurrencyList)
	{
		UItemWidget* CurrencyWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
		CurrencyWidget->SetRewardType(ERewardType::None);
		CurrencyWidget->SetCurrency(Currency.Type, Currency.Count);
	}

	const UCMS* CMS = GetCMS();

	for (const FRewardInfo& RewardInfo : RewardInfos)
	{
		if (RewardInfo.Type == ESagaRewardType::Clear || RewardInfo.Type == ESagaRewardType::InitialClear)
		{
			continue;
		}

		ERewardType RewardType = GetRewardType(RewardInfo.Type);
		SetRewardItems(RewardInfo.ItemList, RewardInfo.CurrencyList, RewardType);
	}

	SetBond();
}

void UCombatResultWidget::SetBond()
{
	const UBondManager& BondManager = GetHUDStore().GetBondManager();
	const TMap<FCharacterType, FBondHistory>& BondHistory = BondManager.GetHistories();
	int32 Index = 0;

	for (const auto& Iter : BondHistory)
	{
		if (BondWidgets.IsValidIndex(Index))
		{
			BondWidgets[Index]->SetBondCharacter(Iter.Value);
		}

		++Index;
	}
	for (int32 i = BondHistory.Num(); i < BondWidgets.Num(); ++i)
	{
		BondWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UCombatResultWidget::SetEventReward(const FEventContentInfo& InEventContentInfo)
{
	ItemListWidget->ClearList();
	int32 AccumPoint = 0;

	const TArray<FRewardInfo>& RewardInfos = UQ6GameInstance::Get(this)->GetRewardInfos();
	for (const FRewardInfo& RewardInfo : RewardInfos)
	{
		// clear reward & random spawn reward
		if (RewardInfo.Type == ESagaRewardType::Clear || RewardInfo.Type == ESagaRewardType::WaveSpawnUnitKill)
		{
			for (const FItemData& ItemData : RewardInfo.ItemList)
			{
				if (ItemData.Category == ELootCategory::EventPoint && ItemData.Type == 1)
				{
					AccumPoint += ItemData.Count;
				}
			}

			SetRewardItems(RewardInfo.ItemList, RewardInfo.CurrencyList, ERewardType::None, InEventContentInfo.Type);
		}
	}

	SetBond();

	const UCMS* CMS = GetCMS();
	const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(InEventContentInfo.Type);
	EventPointPanelBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	if (EventContentRow.Category == EEventContentCategory::ValentineDay)
	{
		const FEventListAssetRow* AssetRow = GetGameResource().GetEventListAssetRow(InEventContentInfo.Type.x);
		if (!AssetRow)
		{
			Q6JsonLogGunny(Warning, "UCombatResultWidget::SetEventReward - EventListAssetRow does not exist.",
				Q6KV("EventContentType", InEventContentInfo.Type.x));

			return;
		}

		// Index 1 -> AccumPoint
		check(AssetRow->PointIcon.IsValidIndex(1));
		PointIconBigImage->SetBrush(AssetRow->PointIcon[1]);
		PointTotalText->SetText(FText::AsNumber(InEventContentInfo.Point1));
		PointGetText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText"), FText::AsNumber(AccumPoint)));

		// Gunny Todo
		//BonusPointBox;
		//PointBonusGetText;
	}
	else if (EventContentRow.Category == EEventContentCategory::MultiSideBattle)
	{
		const FEventListAssetRow* AssetRow = GetGameResource().GetEventListAssetRow(InEventContentInfo.Type.x);
		if (!AssetRow)
		{
			Q6JsonLogPawn(Warning, "UCombatResultWidget::SetEventReward - EventListAssetRow does not exist.", Q6KV("EventContentType", InEventContentInfo.Type.x));
			return;
		}

		const FCCCombatCubeState& CCState = GetCheckedCombatCube(this)->GetState();
		if (CCState.CombatMultiSideState.FinalBonusScore > 0)
		{
			BonusPointBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}

		// Point1 is rank score
		int32 TotalRankScore = CCState.CombatMultiSideState.FinalRankScore;
		const TArray<int32> EventPoints = GetHUDStore().GetEventManager().GetEventPoint(InEventContentInfo.Type);
		if (EventPoints.IsValidIndex(1))
		{
			TotalRankScore = EventPoints[1];
		}

		// Index 1 -> AccumPoint
		check(AssetRow->PointIcon.IsValidIndex(1));
		PointIconBigImage->SetBrush(AssetRow->PointIcon[1]);
		PointGetText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText"), FText::AsNumber(CCState.CombatMultiSideState.FinalRankScore)));
		PointBonusGetText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "PlusText"), FText::AsNumber(CCState.CombatMultiSideState.FinalBonusScore)));
		PointTotalText->SetText(FText::AsNumber(TotalRankScore));
	}
}

void UCombatResultWidget::SetRewardItems(const TArray<FItemData>& InRewardItemList, const TArray<FCurrency>& InCurrencyList, ERewardType InRewardType, FEventContentType InEventContentType)
{
	for (const FCurrency& Currency : InCurrencyList)
	{
		UItemWidget* CurrencyWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
		CurrencyWidget->SetRewardType(InRewardType);
		CurrencyWidget->SetCurrency(Currency.Type, Currency.Count);
	}

	// gather items
	TArray<FItemData> GatherItemDatas;
	for (const FItemData& ItemData : InRewardItemList)
	{
		FItemData* Found = GatherItemDatas.FindByPredicate([&ItemData](const FItemData& Item)
		{
			return Item.Category == ItemData.Category && Item.Type == ItemData.Type;
		});

		if (Found == nullptr)
		{
			FItemData NewItem;
			NewItem.Category = ItemData.Category;
			NewItem.Type = ItemData.Type;
			NewItem.Count = ItemData.Count;
			GatherItemDatas.Add(NewItem);
		}
		else
		{
			Found->Count += ItemData.Count;
		}
	}

	for (const FItemData& ItemData : GatherItemDatas)
	{
		if (ItemData.Category == ELootCategory::EventPoint)
		{
			UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetRewardType(InRewardType);
			ItemWidget->SetEventPoint(InEventContentType, ItemData.Type, ItemData.Count);
		}
		else
		{
			UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->AddChildAtLastIndex());
			ItemWidget->SetRewardType(InRewardType);
			ItemWidget->SetItem(ItemData);
		}
	}
}

void UCombatResultWidget::PlayRewardAnimation()
{
	PlayAnimation(RewardAnim);
}

void UCombatResultWidget::PlayRaidResultAnim(bool bInRaidFinal)
{
	ContentType = bInRaidFinal ? EContentType::RaidFinal : EContentType::Raid;

	if (!bBattleEndAnimFinished)
	{
		return;
	}

	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	PlayAnimation(bInRaidFinal ? RaidRewardAnim : RaidRankingAnim);
}

void UCombatResultWidget::OnCloseWidget()
{
	if (Result == ECCResult::Win && ContentType == EContentType::RaidFinal)
	{
		ACTION_DISPATCH_RaidClearData();
	}

	OnCloseWidgetDelegate.ExecuteIfBound();
	ULevelUtil::LoadLobbyLevel(GetWorld());
}

void UCombatResultWidget::OnTouchScreenClicked()
{
	const auto& FriendMgr = GetHUDStore().GetFriendManager();
	if (FriendMgr.IsRecommendedFriend())
	{
		auto FriendRequestPopup = GetCheckedCombatHUD(this)->OpenFriendRequestPopup();
		FriendRequestPopup->SetFriendInfo(FriendMgr.GetFriendCandidate(), FriendMgr.GetJokerSlotType());
		FriendRequestPopup->OnPopupClosedDelegate.BindUObject(this, &UCombatResultWidget::OnCloseWidget);
	}
	else
	{
		OnCloseWidget();
	}
}

void UCombatResultWidget::OnExitButtonClicked()
{
	OnCloseWidget();
}

void UCombatResultWidget::OnUserRankButtonClicked()
{
	PlayAnimation(GotoRankingListAnim);
	RankingListWidget->ClearList();

	// Gunny Tempcode
	const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
	const TArray<FRaidRankingInfo>& RaidRankingInfos = RaidManager.GetRaidRankingInfos();

	for (int32 i = 0; i < RaidRankingInfos.Num(); ++i)
	{
		URaidUserRankingEntryWidget* RankingEntryWidget = CastChecked<URaidUserRankingEntryWidget>(RankingListWidget->AddChildAtLastIndex());

		RankingEntryWidget->SetInfo(
			RaidRankingInfos[i].Ranking,
			FText::FromString(RaidRankingInfos[i].Name),
			RaidRankingInfos[i].Score,
			PlayerRank == RaidRankingInfos[i].Ranking);
	}
}

void UCombatResultWidget::OnBackUserRankButtonClicked()
{
	PlayAnimation(BackRankingListAnim);
}

void UCombatResultWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByCombatResult);

	SetUserInfo();

	switch (Action->GetActionType())
	{
		case EHSActionType::SagaStageEndResp:
		case EHSActionType::TrainingCenterStageEndResp:
		case EHSActionType::DailyStageEndResp:
		case EHSActionType::SpecialStageEndResp:
			SetReward();
			break;
		case EHSActionType::EventContentValentineDayStageEndResp:
		{
			auto InAction = ACTION_PARSE_EventContentValentineDayStageEndResp(Action);
			SetEventReward(InAction->GetVal().EventContentInfo);
			break;
		}
		case EHSActionType::EventContentMultiSideBattleStageEndResp:
		{
			auto InAction = ACTION_PARSE_EventContentMultiSideBattleStageEndResp(Action);
			SetEventReward(InAction->GetVal().EventContentInfo);
			break;
		}
		case EHSActionType::RaidFinalStageEndResp:
		{
			const auto& InAction = ACTION_PARSE_RaidFinalStageEndResp(Action);
			const auto& Resp = InAction->GetVal();
			SetRaidFinalResult(Resp);
			break;
		}
		case EHSActionType::RaidStageEndResp:
		{
			const auto& InAction = ACTION_PARSE_RaidStageEndResp(Action);
			const auto& Resp = InAction->GetVal();
			SetRaidResult(Resp);
			break;
		}
		default:
			break;
	}
}

//////////////////////////////////////////////////////////////////////////
// UInitialRewardEventWidget

UInitialRewardEventWidget::UInitialRewardEventWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, EventEndType(EInitialRewardEventEndType::Normal)
	, SagaType(SagaTypeInvalid)
	, RaidSagaType(SagaTypeInvalid)
	, bReqRaidOpen(false)
{
}

void UInitialRewardEventWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StartAnim = GetWidgetAnimationFromName(this, "AnimStart");
	BgLoopAnim = GetWidgetAnimationFromName(this, "AnimBgLoop");
	RewardStartAnim = GetWidgetAnimationFromName(this, "AnimRewardStart");
	RewardEndAnim = GetWidgetAnimationFromName(this, "AnimRewardEnd");
	RaidStartAnim = GetWidgetAnimationFromName(this, "AnimRaidStart");
	RaidEndAnim = GetWidgetAnimationFromName(this, "AnimRaidEnd");
	SpecialStartAnim = GetWidgetAnimationFromName(this, "AnimSpecialStart");
	SpecialEndAnim = GetWidgetAnimationFromName(this, "AnimSpecialEnd");
	ItemCardStartAnim = GetWidgetAnimationFromName(this, "AnimItemCardStart");
	ItemCardEndAnim = GetWidgetAnimationFromName(this, "AnimItemCardEnd");

	UButton* TouchScreen = CastChecked<UButton>(GetWidgetFromName("Dismiss"));
	TouchScreen->OnClicked.AddUniqueDynamic(this, &UInitialRewardEventWidget::OnTouchScreenClicked);

	JoinButton = CastChecked<UButton>(GetWidgetFromName("Join"));
	JoinButton->OnClicked.AddUniqueDynamic(this, &UInitialRewardEventWidget::OnJoinButtonClicked);
	CancelButton = CastChecked<UButton>(GetWidgetFromName("Cancel"));
	CancelButton->OnClicked.AddUniqueDynamic(this, &UInitialRewardEventWidget::OnCancelButtonClicked);

	TurnSKillIconWidget = CastChecked<UTurnSkillIconWidget>(GetWidgetFromName("Skill"));

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
	ItemCardWidget = CastChecked<UItemCardWidget>(GetWidgetFromName("ItemCard"));

	TitleText = CastChecked<UTextBlock>(GetWidgetFromName("Title"));
	ContentText = CastChecked<UTextBlock>(GetWidgetFromName("Content"));
	WonderNameText = CastChecked<UTextBlock>(GetWidgetFromName("WonderName"));
	InfoText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("Info"));

	TagImage = CastChecked<UImage>(GetWidgetFromName("Tag"));
	StageIconImage = CastChecked<UImage>(GetWidgetFromName("StageIcon"));
	ContentBGImage = CastChecked<UImage>(GetWidgetFromName("ContentBg"));

	RaidStageWidget = CastChecked<URaidStageWidget>(GetWidgetFromName("RaidStage"));
}

void UInitialRewardEventWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::Raid);

	PlayAnimation(StartAnim);
	PlayAnimation(BgLoopAnim, 0.0f, 0);
}

void UInitialRewardEventWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FInitialRewardEventUIState* UIState = GetUIState()->CastToInitialRewardEventUIState();
	check(UIState);

	SagaType = UIState->SagaType;

	switch (UIState->WidgetType)
	{
		case EInitialRewardWidgetType::RewardItem:
		case EInitialRewardWidgetType::VacationReward:
			SetRewardInfo(UIState->RewardIndex);
			break;
		case EInitialRewardWidgetType::FoundRaid:
			SetFoundRaidRewardInfo();
			break;
		case EInitialRewardWidgetType::WonderOpen:
			SetWonderOpen(UIState->OpenType);
			break;
		case EInitialRewardWidgetType::WonderReward:
			SetWonderReward(UIState->OpenType);
			break;
	}
}

void UInitialRewardEventWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == RewardEndAnim || Animation == SpecialEndAnim || Animation == ItemCardEndAnim)
	{
		ShowNextReward();
	}
	else if (Animation == RaidEndAnim)
	{
		const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
		if (bReqRaidOpen)
		{
			GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Raid);

			RaidManager.ReqOpen();
		}
		else
		{
			ACTION_DISPATCH_RaidClearFoundType();
			ShowNextReward();
		}
	}
}

void UInitialRewardEventWidget::SetRewardInfo(int32 RewardIndex)
{
	FRewardInfo RewardInfo;
	UQ6GameInstance::Get(this)->GetRewardInfo(RewardIndex, RewardInfo);

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.ContentType == EContentType::Special)
	{
		for (const FItemData& ItemData : RewardInfo.ItemList)
		{
			switch (ItemData.Category)
			{
				case ELootCategory::CharacterCard:
				case ELootCategory::SculptureCard:
				case ELootCategory::RelicCard:
					EventEndType = EInitialRewardEventEndType::ItemCard;
					SetSpecialClearCardInfo(ItemData);
					PlayAnimation(ItemCardStartAnim);
					return;
			}
		}
	}

	for (const FItemData& ItemData : RewardInfo.ItemList)
	{
		if (ItemData.Category == ELootCategory::Special)
		{
			EventEndType = EInitialRewardEventEndType::Special;
			SetSpecialOpenInfo(ItemData);
			PlayAnimation(SpecialStartAnim);
			return;
		}
	}

	EventEndType = EInitialRewardEventEndType::Normal;
	SetRewardItem(RewardInfo);
	SetRewardText(SagaRow.ContentType, RewardInfo.Type);
}

void UInitialRewardEventWidget::OnTouchScreenClicked()
{
	switch (EventEndType)
	{
		case EInitialRewardEventEndType::Normal:
			PlayAnimation(RewardEndAnim);
			break;
		case EInitialRewardEventEndType::Special:
			PlayAnimation(SpecialEndAnim);
			break;
		case EInitialRewardEventEndType::ItemCard:
			PlayAnimation(ItemCardEndAnim);
			break;
	}
}

void UInitialRewardEventWidget::ShowNextReward()
{
	GetBaseHUD(this)->ProcessReward();
}

void UInitialRewardEventWidget::OnJoinButtonClicked()
{
	const UCMS* CMS = GetCMS();

	FRaidType FoundRaidType = GetHUDStore().GetRaidManager().GetFoundRaidType();
	const FCMSRaidRow& RaidRow = CMS->GetRaidRowOrDummy(FoundRaidType);
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	if (RaidRow.GetSaga().WattConsume > WorldUser.GetWatt())
	{
		GetCheckedLobbyHUD(this)->OpenWattRechargePopup();
		return;
	}

	bReqRaidOpen = true;
	PlayAnimation(RaidEndAnim);
}

void UInitialRewardEventWidget::OnCancelButtonClicked()
{
	UConfirmPopupWidget* ConfirmPopupWidget = GetCheckedLobbyHUD(this)->OpenConfirmPopup(
		Q6Util::GetLocalizedText("Popup", "RaidFoundCancelTitle")
		, Q6Util::GetLocalizedText("Popup", "RaidFoundCancelContent")
	);
	ConfirmPopupWidget->OnConfirmPopupDelegate.BindLambda([this](EConfirmPopupFlag Flag)
	{
		if (Flag == EConfirmPopupFlag::Yes)
		{
			bReqRaidOpen = false;
			PlayAnimation(RaidEndAnim);
		}
	});
}

void UInitialRewardEventWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByInitialRewardEvent);

	RefreshMenu();
}

void UInitialRewardEventWidget::SetFoundRaidRewardInfo()
{
	FRaidType FoundRaidType = GetHUDStore().GetRaidManager().GetFoundRaidType();
	if (FoundRaidType == RaidTypeInvalid)
	{
		Q6JsonLogZagal(Warning, "SetFoundRaidRewardInfo - Invalid RaidType");
		return;
	}

	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(FoundRaidType);
	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogZagal(Warning, "SetFoundRaidRewardInfo - Invalid Raid SagaType", Q6KV("Raid", FoundRaidType));
		return;
	}

	ensure(RaidRow.RegularRaidScheduleIds.Num() == 0);

	int32 Watt = GetHUDStore().GetWorldUser().GetWatt();
	RaidStageWidget->SetInfo(FRaidId::InvalidValue()
		, SagaRow
		, ERaidStageState::Found
		, ERaidCategory::GeneralRaid
		, SagaRow.WattConsume
		, Watt);

	bReqRaidOpen = false;
	RaidSagaType = FSagaType(SagaRow.Type);

	// Set Raid Text
	TitleText->SetText(SagaRow.DescName);
	ContentText->SetText(Q6Util::GetLocalizedText("Combat", "RaidFound"));

	PlayAnimation(RaidStartAnim);
}

void UInitialRewardEventWidget::SetWonderOpen(const FContentFeatureOpenType& OpenType)
{
	const UCMS* CMS = GetCMS();
	const FCMSContentFeatureOpenRow& OpenRow = CMS->GetContentFeatureOpenRowOrDummy(OpenType);
	if (OpenRow.IsInvalid())
	{
		ShowNextReward();
		return;
	}

	EventEndType = EInitialRewardEventEndType::Special;
	TitleText->SetText(Q6Util::GetLocalizedText("Combat", "ClearSpecialStage"));

	const FSlateBrush& TagBrush = GetUIResource().GetInitialRewardSpecialTag(
		EInitialRewardSpecialTagType::Open);
	TagImage->SetBrush(TagBrush);

	EWonderCategory WonderCategory = GetWonderCategory(OpenRow.OpenType);
	if (WonderCategory == EWonderCategory::Main)
	{
		ShowNextReward();
		return;
	}

	ContentText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Combat", "EventMenuGained"),
		Q6Util::GetLocalizedText("Common", "Wonder")));

	InfoText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Common", "ClearInfoMenuGained"),
		Q6Util::GetLocalizedText("Common", "Wonder"),
		GetWonerNameText(WonderCategory)));

	ContentBGImage->SetBrush(GetUIResource().GetWonderBG(WonderCategory));
	WonderNameText->SetText(GetWonerNameText(WonderCategory));

	PlayAnimation(SpecialStartAnim);
}

void UInitialRewardEventWidget::SetWonderReward(const FContentFeatureOpenType& OpenType)
{
	const UCMS* CMS = GetCMS();
	const FCMSContentFeatureOpenRow& OpenRow = CMS->GetContentFeatureOpenRowOrDummy(OpenType);
	if (OpenRow.IsInvalid())
	{
		ShowNextReward();
		return;
	}

	EventEndType = EInitialRewardEventEndType::Special;
	TitleText->SetText(Q6Util::GetLocalizedText("Combat", "ClearSpecialStage"));

	EWonderCategory WonderCategory(EWonderCategory::Main);

	switch (OpenRow.OpenType)
	{
		case EFeatureOpenType::Artifact:
		{
			WonderCategory = EWonderCategory::Temple;

			int32 ArtifactIndex = FMath::Max(OpenRow.OpenValue - 1, 0);
			const FCMSSkillRow& ArtifactSkillRow = CMS->GetArtifactSkillRowOrDummy(ArtifactIndex);
			const FArtifactIcon& ArtifactIcon = GetUIResource().GetArtifactIcon(ArtifactIndex);

			StageIconImage->SetBrush(ArtifactIcon.MiniBrush);
			StageIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

			ContentText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Combat", "EventContentGained"),
				Q6Util::GetLocalizedText("Common", "Artifact")));

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoContentGained"),
				Q6Util::GetLocalizedText("Common", "Artifact"),
				ArtifactSkillRow.DescName));
		}
		break;
		case EFeatureOpenType::Pet:
		{
			WonderCategory = EWonderCategory::PetPark;

			FPetType PetType(OpenRow.OpenValue);

			const FCMSPetRow& PetRow = CMS->GetPetRowOrDummy(PetType);
			const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetType);
			StageIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			StageIconImage->SetBrushFromSoftTexture(PetAssetRow.IconTexture);

			ContentText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Combat", "EventContentGained"),
				Q6Util::GetLocalizedText("Common", "Pet")));

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoContentGained"),
				Q6Util::GetLocalizedText("Common", "Pet"),
				PetRow.Name));
		}
		break;
		case EFeatureOpenType::PetSecondSkill:
		case EFeatureOpenType::PetThirdSkill:
		{
			WonderCategory = EWonderCategory::PetPark;

			FPetType PetType(OpenRow.OpenValue);

			const FCMSPetRow& PetRow = CMS->GetPetRowOrDummy(PetType);
			if (PetRow.IsInvalid())
			{
				Q6JsonLogGenie(Warning, "SetWonderReward - PetRow doesn't exist."
					, Q6KV("PetType", OpenRow.OpenValue));
				return;
			}
			const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetType);
			StageIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			StageIconImage->SetBrushFromSoftTexture(PetAssetRow.IconTexture);

			const TArray<FSlateBrush>& SkillIcons = PetAssetRow.SkillIcons;

			int32 SkillIndex = (OpenRow.OpenType == EFeatureOpenType::PetSecondSkill) ? 1 : 2;
			if (!SkillIcons.IsValidIndex(SkillIndex))
			{
				Q6JsonLogGenie(Warning, "SetWonderReward - PetAssetRow.SkillIcons don't exist.");
				return;
			}
			TurnSKillIconWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			TurnSKillIconWidget->SetSkill(SkillIcons[SkillIndex]);
			TurnSKillIconWidget->SetLocked(false);

			const TArray<const FCMSSkillRow*>& PetSkillRows = PetRow.GetSkills();
			if (!PetSkillRows.IsValidIndex(SkillIndex))
			{
				Q6JsonLogGenie(Warning, "SetWonderReward - PetSkillRows[SkillIndex] does't exist."
					, Q6KV("SkillIndex", SkillIndex));
				return;
			}

			ContentText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Combat", "EventContentGained"),
				Q6Util::GetLocalizedText("Common", "PetSkill")));

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoPetSkillGained"),
				PetRow.Name,
				PetSkillRows[SkillIndex]->DescName));
		}
		break;
		case EFeatureOpenType::VacationSpot:
		{
			WonderCategory = EWonderCategory::Vacation;

			const FCMSVacationSpotRow& VactionRow = CMS->GetVacationSpotRowOrDummy(
				FVacationSpotType(OpenRow.OpenValue));

			ContentText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Combat", "EventMenuGained"),
				Q6Util::GetLocalizedText("Common", "VacationSpot")));

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoContentGained"),
				Q6Util::GetLocalizedText("Common", "VacationSpot"),
				VactionRow.DescName));
		}
		break;
	}

	if (WonderCategory == EWonderCategory::Main)
	{
		ShowNextReward();
		return;
	}

	ContentBGImage->SetBrush(GetUIResource().GetWonderBG(WonderCategory));
	WonderNameText->SetText(GetWonerNameText(WonderCategory));

	PlayAnimation(SpecialStartAnim);
}

void UInitialRewardEventWidget::SetRewardItem(const FRewardInfo& RewardInfo)
{
	StageIconImage->SetVisibility(ESlateVisibility::Collapsed);

	if (RewardInfo.CurrencyList.IsValidIndex(0))
	{
		ItemWidget->SetCurrency(
			RewardInfo.CurrencyList[0].Type,
			RewardInfo.CurrencyList[0].Count);
	}
	else if (RewardInfo.ItemList.IsValidIndex(0))
	{
		ItemWidget->SetItem(RewardInfo.ItemList[0]);
	}
	else
	{
		Q6JsonLogGunny(Warning, "UInitialRewardEventWidget::SetRewardItem - RewardInfo does not exist.");
	}

	PlayAnimation(RewardStartAnim);
}

void UInitialRewardEventWidget::SetRewardText(EContentType ContentType, ESagaRewardType RewardType)
{
	const UCMS* CMS = GetCMS();
	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);

	switch (ContentType)
	{
		case EContentType::DailyDungeon:
		{
			if (RewardType == ESagaRewardType::DailyFirstClear)
			{
				FText DailyDungeonText = Q6Util::GetLocalizedText("Combat", "ClearDailyDungeon");
				TitleText->SetText(DailyDungeonText);

				FText ContentsText = Q6Util::GetLocalizedText("Combat", "FirstClearReward");
				ContentText->SetText(ContentsText);
			}
			else
			{
				SetDefaultRewardText(SagaRow);
			}

			break;
		}
		case EContentType::TrainingCenter:
		{
			if (RewardType == ESagaRewardType::TrainingCenterPhaseClear)
			{
				const FTrainingCenterType CenterType = CMS->GetTrainingCenterType(SagaType);

				if (CenterType == TrainingCenterTypeInvalid)
				{
					Q6JsonLogGunny(Warning, "UInitialRewardEventWidget::SetRewardText - Cannot find that CenterType by SagaType"
						, Q6KV("SagaType", (int32)SagaType));

					return;
				}

				int32 StepNumber = (int32)CenterType;
				FText TextStageNumber = FText::AsNumber(StepNumber);
				FText ClearText = Q6Util::GetLocalizedText("Combat", "ClearTrainingCenter");
				ClearText = FText::Format(ClearText, TextStageNumber);
				TitleText->SetText(ClearText);

				FText ContentsText = Q6Util::GetLocalizedText("Combat", "StepClearReward");
				ContentText->SetText(ContentsText);
			}
			else
			{
				SetDefaultRewardText(SagaRow);
			}
			break;
		}
		case EContentType::Saga:
		{
			if (RewardType == ESagaRewardType::EpisodeClear)
			{
				FText TextEpisodeNumber = FText::AsNumber(SagaRow.Episode);
				FText ClearText = Q6Util::GetLocalizedText("Combat", "ClearEpisode");
				TitleText->SetText(FText::Format(ClearText, TextEpisodeNumber));

				FText ContentsText = Q6Util::GetLocalizedText("Combat", "EpisodeClearReward");
				ContentText->SetText(ContentsText);
			}
			else
			{
				SetDefaultRewardText(SagaRow);
			}
			break;
		}
		case EContentType::Special:
		{
			if (RewardType == ESagaRewardType::EpisodeClear)
			{
				const FCMSSpecialRow* SpecialRow = GetCMS()->GetSpecialRow(SagaRow.CmsType());
				if (!SpecialRow)
				{
					Q6JsonLogRoze(Error, "UInitialRewardEventWidget::SetRewardText - Not found special row", Q6KV("SagaType", SagaRow.Type));
					return;
				}

				SetSpecialRewardText(*SpecialRow);
			}
			else
			{
				SetDefaultRewardText(SagaRow);
			}
			break;
		}
		default:
		{
			SetDefaultRewardText(SagaRow);
			break;
		}
	}
}

void UInitialRewardEventWidget::SetDefaultRewardText(const FCMSSagaRow& SagaRow)
{
	FText ClearText = Q6Util::GetLocalizedText("Combat", "ClearStage");
	FText TextStageNumber = MakeStageNumberText(SagaRow);
	ClearText = FText::Format(ClearText, TextStageNumber);
	TitleText->SetText(ClearText);

	FText ContentsText = Q6Util::GetLocalizedText("Combat", "FirstClearReward");
	ContentText->SetText(ContentsText);
}

void UInitialRewardEventWidget::SetSpecialRewardText(const FCMSSpecialRow& SpecialRow)
{
	FText EpisodeNameText = SpecialRow.Desc;

	if (SpecialRow.ConditionType == ESpecialCategory::Character)
	{
		FText ClearText = Q6Util::GetLocalizedText("Combat", "ClearCharacterEpisode");
		TitleText->SetText(FText::Format(ClearText, EpisodeNameText));
	}
	else if (SpecialRow.ConditionType == ESpecialCategory::Saga)
	{
		FText ClearText = Q6Util::GetLocalizedText("Combat", "ClearBossEpisode");
		TitleText->SetText(FText::Format(ClearText, EpisodeNameText));
	}
	else
	{
		FText ClearText = Q6Util::GetLocalizedText("Combat", "ClearEpisode");
		TitleText->SetText(FText::Format(ClearText, EpisodeNameText));
	}

	FText RewardTypeText = Q6Util::GetLocalizedText("Combat", "EpisodeClearReward");
	ContentText->SetText(RewardTypeText);
}

void UInitialRewardEventWidget::SetSpecialOpenInfo(const FItemData& InItemData)
{
	TitleText->SetText(Q6Util::GetLocalizedText("Combat", "EventWondeEpisode"));

	const UUIResource& UIResource = GetUIResource();
	const FSlateBrush& TagBrush = UIResource.GetInitialRewardSpecialTag(EInitialRewardSpecialTagType::NewStage);
	TagImage->SetBrush(TagBrush);

	const UCMS* CMS = GetCMS();
	const FCMSSpecialRow& SpecialRow = CMS->GetSpecialRowOrDummy(FSpecialType(InItemData.Type));
	if (SpecialRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UInitialRewardEventWidget::SetSpecialContentInfo - SpecialRow does not exist.",
			Q6KV("SpecialType", InItemData.Type));
		return;
	}

	if (SpecialRow.ConditionType == ESpecialCategory::PetSecondSkill || SpecialRow.ConditionType == ESpecialCategory::PetThirdSkill)
	{
		TurnSKillIconWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	EWonderCategory WonderCategory(EWonderCategory::Main);

	switch (SpecialRow.ConditionType)
	{
		case ESpecialCategory::Temple:
		{
			WonderCategory = GetWonderCategory(SpecialRow.ConditionType);

			// ArtifactIndex is 0-based
			int32 ArtifactIndex = FMath::Max(SpecialRow.ConditionId - 1, 0);
			const FCMSSkillRow& ArtifactSkillRow = CMS->GetArtifactSkillRowOrDummy(ArtifactIndex);
			const FArtifactIcon& ArtifactIcon = UIResource.GetArtifactIcon(ArtifactIndex);
			StageIconImage->SetBrush(ArtifactIcon.MiniBrush);
			StageIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoContentOpen"),
				Q6Util::GetLocalizedText("Common", "Artifact"),
				ArtifactSkillRow.DescName));
			break;
		}
		case ESpecialCategory::Vacation:
		{
			WonderCategory = GetWonderCategory(SpecialRow.ConditionType);

			const FCMSVacationSpotRow& VacationRow = CMS->GetVacationSpotRowOrDummy(FVacationSpotType(SpecialRow.ConditionId));

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoContentOpen"),
				Q6Util::GetLocalizedText("Common", "VacationSpot"),
				VacationRow.DescName));
			break;
		}
		case ESpecialCategory::Pet:
		{
			WonderCategory = GetWonderCategory(SpecialRow.ConditionType);

			const FCMSPetRow& PetRow = CMS->GetPetRowOrDummy(FPetType(SpecialRow.ConditionId));
			const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(FPetType(SpecialRow.ConditionId));
			StageIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			StageIconImage->SetBrushFromSoftTexture(PetAssetRow.IconTexture);

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoContentOpen"),
				Q6Util::GetLocalizedText("Common", "Pet"),
				PetRow.Name));
			break;
		}
		case ESpecialCategory::PetSecondSkill:
		case ESpecialCategory::PetThirdSkill:
		{
			WonderCategory = GetWonderCategory(SpecialRow.ConditionType);

			const FCMSPetRow& PetRow = CMS->GetPetRowOrDummy(FPetType(SpecialRow.ConditionId));
			if (PetRow.IsInvalid())
			{
				Q6JsonLogGunny(Warning, "UInitialRewardEventWidget::SetSpecialOpenInfo - PetRow doesn't exist."
					, Q6KV("PetType", SpecialRow.ConditionId));
				return;
			}

			const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(FPetType(SpecialRow.ConditionId));
			StageIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			StageIconImage->SetBrushFromSoftTexture(PetAssetRow.IconTexture);

			const TArray<FSlateBrush>& SkillIcons = PetAssetRow.SkillIcons;

			int32 SkillIndex = (SpecialRow.ConditionType == ESpecialCategory::PetSecondSkill) ? 1 : 2;
			if (!SkillIcons.IsValidIndex(SkillIndex))
			{
				Q6JsonLogGunny(Warning, "UInitialRewardEventWidget::SetSpecialOpenInfo - PetAssetRow.SkillIcons don't exist.");
				return;
			}
			TurnSKillIconWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			TurnSKillIconWidget->SetSkill(SkillIcons[SkillIndex]);

			const TArray<const FCMSSkillRow*>& PetSkillRows = PetRow.GetSkills();
			if (!PetSkillRows.IsValidIndex(SkillIndex))
			{
				Q6JsonLogGunny(Warning, "UInitialRewardEventWidget::SetSpecialOpenInfo - PetSkillRows[SkillIndex] does't exist.", Q6KV("SkillIndex", SkillIndex));
				return;
			}

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoPetSkillOpen"),
				PetRow.Name,
				PetSkillRows[SkillIndex]->DescName));
			break;
		}
		case ESpecialCategory::Wonder:
		{
			WonderCategory = EWonderCategory(SpecialRow.ConditionId);

			InfoText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Common", "ClearInfoMenuOpen"),
				Q6Util::GetLocalizedText("Common", "Wonder"),
				GetWonerNameText(WonderCategory)));
			break;
		}
	}

	WonderNameText->SetText(GetWonerNameText(WonderCategory));
	ContentText->SetText(Q6Util::GetLocalizedText("Combat", "OpenSpecialStage"));
	ContentBGImage->SetBrush(UIResource.GetWonderBG(WonderCategory));
}

void UInitialRewardEventWidget::SetSpecialClearCardInfo(const FItemData& InItemData)
{
	TitleText->SetText(Q6Util::GetLocalizedText("Combat", "ClearSpecialStage"));
	FText ContentType;
	FText ContentName;

	const FSlateBrush& TagBrush = GetUIResource().GetInitialRewardSpecialTag(EInitialRewardSpecialTagType::Get);
	TagImage->SetBrush(TagBrush);

	StageIconImage->SetVisibility(ESlateVisibility::Collapsed);

	const UCMS* CMS = GetCMS();
	switch (InItemData.Category)
	{
		case ELootCategory::CharacterCard:
		{
			ItemCardWidget->SetDefaultCharacter(FCharacterType(InItemData.Type));

			const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(FCharacterType(InItemData.Type));
			ContentName = CharacterRow.GetUnit().DescName;
			ContentType = Q6Util::GetLocalizedText("Common", "Character");
			break;
		}
		case ELootCategory::SculptureCard:
		{
			ItemCardWidget->SetDefaultSculpture(FSculptureType(InItemData.Type));

			const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(FSculptureType(InItemData.Type));
			ContentName = SculptureRow.Desc;
			ContentType = Q6Util::GetLocalizedText("Common", "Sculpture");
			break;
		}
		case ELootCategory::RelicCard:
		{
			ItemCardWidget->SetDefaultRelic(FRelicType(InItemData.Type));

			const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(FRelicType(InItemData.Type));
			ContentName = RelicRow.Desc;
			ContentType = Q6Util::GetLocalizedText("Common", "Relic");
			break;
		}
	}

	ContentText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Common", "EventContentGained"), ContentType));

	InfoText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Common", "ClearInfoContentGained"),
		ContentType,
		ContentName));
}

void UFriendRequestPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	auto TitleText = CastChecked<UTextBlock>(GetWidgetFromName("Title"));
	TitleText->SetText(Q6Util::GetLocalizedText("Common", "FriendRequestTitle"));

	auto CountTypeText = CastChecked<UTextBlock>(GetWidgetFromName("CountType"));
	CountTypeText->SetText(Q6Util::GetLocalizedText("Common", "FriendCount"));

	auto NotRequestText = CastChecked<UTextBlock>(GetWidgetFromName("TextNotRequest"));
	NotRequestText->SetText(Q6Util::GetLocalizedText("Common", "FriendNotRequest"));

	auto RequestText = CastChecked<UTextBlock>(GetWidgetFromName("TextRequest"));
	RequestText->SetText(Q6Util::GetLocalizedText("Common", "FriendRequest"));

	CancelButton = CastChecked<UButton>(GetWidgetFromName("No"));
	CancelButton->OnClicked.AddUniqueDynamic(this, &UFriendRequestPopupWidget::ClosePopup);

	RequestButton = CastChecked<UButton>(GetWidgetFromName("Yes"));
	RequestButton->OnClicked.AddUniqueDynamic(this, &UFriendRequestPopupWidget::FriendRequest);

	SubscribeToStore(EHSType::Friend);
}

void UFriendRequestPopupWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByFriendRequestPopup);

	UConfirmPopupWidget* ConfirmPopup = GetCheckedCombatHUD(this)->OpenConfirmPopup(FText::GetEmpty(), FText::GetEmpty());
	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
	switch (Action->GetActionType())
	{
		case EHSActionType::FriendRequestResp:
			ConfirmPopup->SetContent(Q6Util::GetLocalizedText("Popup", "FriendRequestNotify"));
			break;
		case EHSActionType::FriendErrorResp:
			ConfirmPopup->SetContent(GetErrorText(ACTION_PARSE_FriendErrorResp(Action)->GetVal()));
			break;
	}
	ConfirmPopup->OnPopupClosedDelegate.BindUObject(this, &UFriendRequestPopupWidget::ClosePopup);
}

void UFriendRequestPopupWidget::SetFriendInfo(const FFriendInfo& FriendInfo, EJokerSlotType JokerSlot)
{
	const auto& WorldUser = GetHUDStore().GetWorldUser();
	const auto& FriendMgr = GetHUDStore().GetFriendManager();

	auto JokerEntryWidget = CastChecked<UJokerEntryWidget>(GetWidgetFromName("JokerEntryWidgetBP"));
	JokerEntryWidget->SetFriendJoker(FriendInfo, static_cast<int32>(JokerSlot), false);
	JokerEntryWidget->OnJokerSetButtonDelegate.BindUObject(this, &UFriendRequestPopupWidget::OnJokerSetButtonClicked);

	auto CurFriendText = CastChecked<UTextBlock>(GetWidgetFromName("CurFriend"));
	CurFriendText->SetText(FText::AsNumber(FriendMgr.GetFriendCount()));

	auto MaxFriendText = CastChecked<UTextBlock>(GetWidgetFromName("MaxFriend"));
	MaxFriendText->SetText(FText::AsNumber(WorldUser.GetMaxFriendCount()));
}

FText UFriendRequestPopupWidget::GetErrorText(const FL2CError& L2CError)
{
	switch (L2CError.ErrorCode)
	{
		case Q6_ERROR_FRIEND_ALREADY_FRIEND:
			return Q6Util::GetLocalizedText("Popup", "FriendNotifyOverlap");
		case Q6_ERROR_FRIEND_ALREADY_REQUESTED:
			return Q6Util::GetLocalizedText("Popup", "FriendNotifyPending");
		case Q6_ERROR_FRIEND_LIST_FULL:
			return Q6Util::GetLocalizedText("Popup", "FriendNotifyMyFull");
		case Q6_ERROR_FRIEND_TARGET_LIST_FULL:
			return Q6Util::GetLocalizedText("Popup", "FriendNotifyUserFull");
		case Q6_ERROR_FRIEND_TARGET_REQUESTED:
			return Q6Util::GetLocalizedText("Popup", "FriendNotifyReceiving");
		default:
			break;
	}

	return FText::FromString(GetBaseHUD(this)->MakeErrorText(FErrTextType(L2CError.ErrorCode), L2CError.Extra));
}

void UFriendRequestPopupWidget::OnJokerSetButtonClicked(const FFriendInfo& FriendInfo)
{
	const auto CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->OpenJokerSetViewPopup(FriendInfo);
}

void UFriendRequestPopupWidget::ClosePopup()
{
	RemoveFromParent();

	OnPopupClosedDelegate.ExecuteIfBound();
}

void UFriendRequestPopupWidget::FriendRequest()
{
	check(CancelButton);
	CancelButton->SetIsEnabled(false);
	check(RequestButton);
	RequestButton->SetIsEnabled(false);

	const auto& FriendMgr = GetHUDStore().GetFriendManager();
	FriendMgr.ReqFriendRequest(FriendMgr.GetFriendCandidate());
}

//////////////////////////////////////////////////////////////////////////
// URaidAssistTurnWidget

void URaidAssistTurnWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RaidAssistStartAnim = GetWidgetAnimationFromName(this, "AnimAssistStart");
	check(RaidAssistStartAnim);

	UserNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextUserName"));
	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextSkillName"));

	CharacterPortrait = CastChecked<UImage>(GetWidgetFromName("CharacterPortrait"));
	SkillIconImage = CastChecked<UImage>(GetWidgetFromName("SkillImage"));
}

void URaidAssistTurnWidget::NativeDestruct()
{
	Super::NativeDestruct();
}

void URaidAssistTurnWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == RaidAssistStartAnim)
	{
		OnRaidAssistStartAnimFinished.ExecuteIfBound();
	}
}

void URaidAssistTurnWidget::SetInfo(const FText& InUserName, const FText& InSkillName, FCharacterType InCharacterType, int32 InSkillType)
{
	SetUserNameText(InUserName);
	SetSkillNameText(InSkillName);
	SetCharacterPortrait(InCharacterType);

	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(InCharacterType);
	SetRaidTurnSkillIcon(UnitRow, InSkillType);

	PlayRaidAssistStartAnimation();
}

void URaidAssistTurnWidget::PlayRaidAssistStartAnimation()
{
	check(RaidAssistStartAnim);
	PlayAnimation(RaidAssistStartAnim);
}

void URaidAssistTurnWidget::SetUserNameText(const FText& InUserName)
{
	check(UserNameText);
	UserNameText->SetText(InUserName);
}

void URaidAssistTurnWidget::SetSkillNameText(const FText& InSkillName)
{
	check(SkillNameText);
	SkillNameText->SetText(InSkillName);
}

void URaidAssistTurnWidget::SetCharacterPortrait(FCharacterType CharacterType)
{
	check(CharacterPortrait);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	CharacterPortrait->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);
}

void URaidAssistTurnWidget::SetRaidTurnSkillIcon(const FCMSUnitRow& InUnitRow, int32 InSkillType)
{
	check(SkillIconImage);

	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(InUnitRow.Model);

	const TArray<const FCMSSkillRow*>& TurnSkills = InUnitRow.GetTurnSkills();
	int32 TurnSkillIndex = TurnSkills.IndexOfByPredicate([&InSkillType](const FCMSSkillRow* Elem)
	{
		return Elem->Type == InSkillType;
	});

	if (SkillAssetRow.TurnSkillIcons.IsValidIndex(TurnSkillIndex))
	{
		SkillIconImage->SetBrush(SkillAssetRow.TurnSkillIcons[TurnSkillIndex]);
	}
	else
	{
		SkillIconImage->SetBrush(GetGameResource().GetUIResource().GetDummyIcon());
	}
}

//////////////////////////////////////////////////////////////////////////
// CombatTimeWidgetBP

UCombatTimeWidget::UCombatTimeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, RemainTime(0)
{
	NumberFormattingOptions.SetMinimumIntegralDigits(MIN_RAID_TIME_DIGIT);
}

void UCombatTimeWidget::NativeConstruct()
{
	MinutesText = CastChecked<UTextBlock>(GetWidgetFromName("TextMinutes"));
	SecondsText = CastChecked<UTextBlock>(GetWidgetFromName("TextSeconds"));

	Border = CastChecked<UBorder>(GetWidgetFromName("Border"));
}

void UCombatTimeWidget::NativeDestruct()
{
	if (CombatTimerHandle.IsValid()
		&& UQ6GameInstance::Get(this)->HasQ6TimerManager())
	{
		UQ6GameInstance::Get(this)->GetQ6TimerManager().ClearTimer(CombatTimerHandle);
	}
}

void UCombatTimeWidget::SetRemainTime(const int64 InRemainTime)
{
	RemainTime = InRemainTime;
}

void UCombatTimeWidget::SetRemainTime()
{
	if (RemainTime < 60)
	{
		Border->SetContentColorAndOpacity(GetUIResource().GetLackColor());
	}

	int64 Minutes = RemainTime / 60;
	int64 Seconds = RemainTime % 60;

	MinutesText->SetText(FText::AsNumber(Minutes, &NumberFormattingOptions));
	SecondsText->SetText(FText::AsNumber(Seconds, &NumberFormattingOptions));

	if (RemainTime <= 0)
	{
		MinutesText->SetText(FText::AsNumber(0, &NumberFormattingOptions));
		SecondsText->SetText(FText::AsNumber(0, &NumberFormattingOptions));

		if (CombatTimerHandle.IsValid()
			&& UQ6GameInstance::Get(this)->HasQ6TimerManager())
		{
			UQ6GameInstance::Get(this)->GetQ6TimerManager().ClearTimer(CombatTimerHandle, true);
		}
	}

	RemainTime -= 1;
}

void UCombatTimeWidget::StartTimer()
{
	if (RemainTime < 60)
	{
		Border->SetContentColorAndOpacity(GetUIResource().GetLackColor());
	}
	else
	{
		Border->SetContentColorAndOpacity(FLinearColor::White);
	}

	if (RemainTime > 0
		&& UQ6GameInstance::Get(this)->HasQ6TimerManager())
	{
		FQ6TimerManager& Q6TimeManager = UQ6GameInstance::Get(this)->GetQ6TimerManager();
		Q6TimeManager.SetTimer(CombatTimerHandle
			, this
			, &UCombatTimeWidget::SetRemainTime
			, 1.0f
			, true
			, 0.0f);
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidRewardMarkWidget

UBonusRewardMarkWidget::UBonusRewardMarkWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurrAnimType(EBonusRewardMarkAnimType::Max)
{

}

void UBonusRewardMarkWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MarkCheckedAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMarkChecked"));
	MarkCheckedAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMarkShow"));
	check(MarkCheckedAnims.Num() == static_cast<uint8>(EBonusRewardMarkAnimType::Max));
}

void UBonusRewardMarkWidget::PlayRewardMarkAnimation(EBonusRewardMarkAnimType Type)
{
	if (CurrAnimType == Type)
	{
		return;
	}

	const int32 Index = static_cast<int32>(Type);
	if (MarkCheckedAnims.IsValidIndex(Index))
	{
		PlayAnimation(MarkCheckedAnims[Index]);
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidRewardMarkListWidget

UBonusRewardMarkListWidget::UBonusRewardMarkListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UBonusRewardMarkListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RewardMarks.Reset();
	FString WidgetName;
	for (int32 Index = 0; Index < MAX_BONUS_REWARD_MARK; ++Index)
	{
		WidgetName = FString::Printf(TEXT("RaidReward%d"), Index);

		UBonusRewardMarkWidget* Widget = CastChecked<UBonusRewardMarkWidget>(GetWidgetFromName(*WidgetName));
		RewardMarks.Add(Widget);
	}
}

void UBonusRewardMarkListWidget::PlayRewardMarkListAnimation(EBonusRewardMarkAnimType Type, int32 EndRewardMarkNum)
{
	for (int32 Index = 0; Index < EndRewardMarkNum; ++Index)
	{
		if (!RewardMarks.IsValidIndex(Index))
		{
			continue;
		}

		if (!RewardMarks[Index])
		{
			continue;
		}

		RewardMarks[Index]->PlayRewardMarkAnimation(Type);
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidTotalBarWidget

URaidTotalBarWidget::URaidTotalBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, MaxTotalBarHealth(0)
	, CurTotalBarHealth(0)
	, HealthBarAction(EHealthBarAction::None)
{
}

void URaidTotalBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	HPBarWidget = CastChecked<UHealthBarWidget>(GetWidgetFromName("HealthBarWidgetBP"));

	SubscribeToStore(EHSType::Raid);
}

void URaidTotalBarWidget::NativeDestruct()
{
	Super::NativeDestruct();
}

void URaidTotalBarWidget::InitRaidTotalHealthBar()
{
	FRaidType OpenedRaidType = GetHUDStore().GetRaidManager().GetOpenRaidType();
	const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(OpenedRaidType);
	if (RaidRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist raid type", Q6KV("type", OpenedRaidType));
	}

	check(RaidRow.TotalUser > 0);

	const FUnitState* CenterUnitState(nullptr);
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);
	TArray<AUnit*> Units = Presenter->FindUnitsByFaction(ECCFaction::Enemy);
	for (const AUnit* Unit : Units)
	{
		if (!Unit)
		{
			continue;
		}

		const FUnitState& UnitState = Unit->GetUnitState();
		if (UnitState.Faction == ECCFaction::Ally)
		{
			continue;
		}

		int32 Health = UnitState.MaxHealth * RaidRow.TotalUser;
		if (Health < 0)
		{
			Q6JsonLogGenie(Warning, "raid health overflow", Q6KV("health", Health));
		}

		MaxTotalBarHealth += Health;
		CurTotalBarHealth += Health;
		if (MaxTotalBarHealth < 0 || CurTotalBarHealth < 0)
		{
			Q6JsonLogGenie(Warning, "raid health overflow", Q6KV("health", MaxTotalBarHealth));
		}

		if (UnitState.Slot == CENTER_SLOT)
		{
			CenterUnitState = &UnitState;
		}
	}

	HealthBarAction = EHealthBarAction::FirstHit;

	if (ensure(CenterUnitState))
	{
		HPBarWidget->InitRaidTotalHealthBar(CenterUnitState->Category
			, CenterUnitState->UnitType, MaxTotalBarHealth);
	}
}

void URaidTotalBarWidget::SetRaidTotalHealthHit(const int32 InTotalDamage)
{
	CurTotalBarHealth = MaxTotalBarHealth - InTotalDamage;

	HPBarWidget->SetRaidTotalHealth(CurTotalBarHealth, HealthBarAction);
	HealthBarAction = EHealthBarAction::Hit;
}

void URaidTotalBarWidget::SetRaidTotalHealthLastHit()
{
	HPBarWidget->SetRaidTotalHealth(CurTotalBarHealth, EHealthBarAction::LastHit);
	HealthBarAction = EHealthBarAction::FirstHit;
}

void URaidTotalBarWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByRaidTotalBar);

	switch (Action->GetActionType())
	{
		case EHSActionType::RaidBossHealthNof:
		case EHSActionType::RaidSkillsNof:
		{
			SetRaidTotalHealthHit(GetHUDStore().GetRaidManager().GetTotalDamage());
		}
		break;
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidRankingWidget

URaidRankingWidget::URaidRankingWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void URaidRankingWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RaidRankingTexts.Reset();
	RaidRankingTexts.Add(CastChecked<UTextBlock>(GetWidgetFromName("TextMyDamage")));
	RaidRankingTexts.Add(CastChecked<UTextBlock>(GetWidgetFromName("TextUserName1st")));
	RaidRankingTexts.Add(CastChecked<UTextBlock>(GetWidgetFromName("TextUserDamage1st")));
	RaidRankingTexts.Add(CastChecked<UTextBlock>(GetWidgetFromName("TextUserName2nd")));
	RaidRankingTexts.Add(CastChecked<UTextBlock>(GetWidgetFromName("TextUserDamage2nd")));
	RaidRankingTexts.Add(CastChecked<UTextBlock>(GetWidgetFromName("TextUserName3rd")));
	RaidRankingTexts.Add(CastChecked<UTextBlock>(GetWidgetFromName("TextUserDamage3rd")));
	check(RaidRankingTexts.Num() == static_cast<int32>(ERaidRankingTextType::Max));

	UButton* UserListButton = CastChecked<UButton>(GetWidgetFromName("UserListBtn"));
	UserListButton->OnClicked.AddUniqueDynamic(this, &URaidRankingWidget::OnUserListButtonClicked);
}

void URaidRankingWidget::NativeDestruct()
{
	Super::NativeDestruct();
}

void URaidRankingWidget::SetMyDamage(const int32 InDamage)
{
	RaidRankingTexts[static_cast<int32>(ERaidRankingTextType::MyDamage)]->SetText(FText::AsNumber(InDamage));
}

void URaidRankingWidget::SetRealTimeRankInfo()
{
	const TArray<FRaidRankInfo>& RankInfos = GetHUDStore().GetRaidManager().GetRaidRealTimeRankInfos();

	if (RankInfos.IsValidIndex(0))
	{
		RaidRankingTexts[static_cast<int32>(ERaidRankingTextType::UserName1st)]->SetText(
			FText::FromString(RankInfos[0].RankerName));
		RaidRankingTexts[static_cast<int32>(ERaidRankingTextType::UserDamage1st)]->SetText(
			FText::AsNumber(RankInfos[0].Score));
	}

	if (RankInfos.IsValidIndex(1))
	{
		RaidRankingTexts[static_cast<int32>(ERaidRankingTextType::UserName2nd)]->SetText(
			FText::FromString(RankInfos[1].RankerName));
		RaidRankingTexts[static_cast<int32>(ERaidRankingTextType::UserDamage2nd)]->SetText(
			FText::AsNumber(RankInfos[1].Score));
	}

	if (RankInfos.IsValidIndex(2))
	{
		RaidRankingTexts[static_cast<int32>(ERaidRankingTextType::UserName3rd)]->SetText(
			FText::FromString(RankInfos[2].RankerName));
		RaidRankingTexts[static_cast<int32>(ERaidRankingTextType::UserDamage3rd)]->SetText(
			FText::AsNumber(RankInfos[2].Score));
	}
}

void URaidRankingWidget::OnUserListButtonClicked()
{
	URaidUserPopupWidget* RaidUserPopupWidget = GetCheckedCombatHUD(this)->OpenRaidUserPopup();
	RaidUserPopupWidget->StartTimer();
}

//////////////////////////////////////////////////////////////////////////
// URaidUserCharacterWidget

URaidUserCharacterWidget::URaidUserCharacterWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void URaidUserCharacterWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RaidUserCharacterAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimStatePlaying"));
	RaidUserCharacterAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimStateDead"));
	RaidUserCharacterAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimStateWaiting"));
	check(RaidUserCharacterAnims.Num() == static_cast<uint8>(ERaidUserCharacterAnimType::Max));

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	JokerImage = CastChecked<UImage>(GetWidgetFromName("Joker"));
	HPBarWidget = CastChecked<UHealthBarWidget>(GetWidgetFromName("HP"));
}

void URaidUserCharacterWidget::SetRaidUserCharacterInfo(const FCharHealth& Info)
{
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(Info.CharType);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());

	JokerImage->SetVisibility(
		Info.Joker ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	int32 MaxHealth = FMath::Max(Info.MaxHealth, Info.Health);
	if (MaxHealth > 0)
	{
		HPBarWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		HPBarWidget->SetOtherUserCharacterHealthBar(Info.Health, MaxHealth);
	}
	else
	{
		HPBarWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	if (Info.Health == 0 && Info.MaxHealth > 0)
	{
		PlayRaidUserCharacterAnimation(ERaidUserCharacterAnimType::Dead);
	}
	else
	{
		if (Info.MaxHealth != 0)
		{
			PlayRaidUserCharacterAnimation(ERaidUserCharacterAnimType::Playing);
		}
		else
		{
			PlayRaidUserCharacterAnimation(ERaidUserCharacterAnimType::Waiting);
		}
	}
}

void URaidUserCharacterWidget::PlayRaidUserCharacterAnimation(ERaidUserCharacterAnimType Type)
{
	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (RaidUserCharacterAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(RaidUserCharacterAnims[AnimIndex]);
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidUserListWidget

URaidUserListWidget::URaidUserListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void URaidUserListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StateMineAnim = GetWidgetAnimationFromName(this, "AnimStateMine");
	StateOtherAnim = GetWidgetAnimationFromName(this, "AnimStateOther");

	RankRichText = CastChecked<URichTextBlock>(GetWidgetFromName("Rank"));
	GameStateRichText = CastChecked<URichTextBlock>(GetWidgetFromName("GameState"));
	UserNameText = CastChecked<UTextBlock>(GetWidgetFromName("UserName"));
	ScoreText = CastChecked<UTextBlock>(GetWidgetFromName("Score"));
	TrophyImage = CastChecked<UImage>(GetWidgetFromName("Trophy"));

	CharacterListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("CharacterList"));
}

void URaidUserListWidget::SetRaidUserListInfo(const int32 Rank, const ERaidUserState State
	, const int32 TurnCount, const FText& UserName
	, const int32 Score, const bool bIsMyInfo
	, const TArray<FCharHealth>& CharacterInfos)
{
	RankRichText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Combat", "UserRanking"), FText::AsNumber(Rank)));

	switch (State)
	{
		case ERaidUserState::OnGoing:
		{
			GameStateRichText->SetText(FText::Format(
				Q6Util::GetLocalizedText("Combat", "GameStateTurn"), FText::AsNumber(TurnCount)));
		}
		break;
		case ERaidUserState::End:
		{
			GameStateRichText->SetText(Q6Util::GetLocalizedText("Combat", "GameStateEnd"));
		}
		break;
		default: check(false);
	}

	UserNameText->SetText(UserName);
	ScoreText->SetText(FText::AsNumber(Score));

	const FSlateBrush* TrophySlateBrush = GetUIResource().GetRaidUserRankTrophy(Rank - 1);
	if (TrophySlateBrush)
	{
		TrophyImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		TrophyImage->SetBrush(*TrophySlateBrush);
	}
	else
	{
		TrophyImage->SetVisibility(ESlateVisibility::Collapsed);
	}

	CharacterListWidget->ClearList();
	for (const FCharHealth& Info : CharacterInfos)
	{
		URaidUserCharacterWidget* Widget = CastChecked<URaidUserCharacterWidget>(
			CharacterListWidget->AddChildAtLastIndex());

		Widget->SetRaidUserCharacterInfo(Info);
	}

	if (bIsMyInfo)
	{
		PlayAnimation(StateMineAnim);
	}
	else
	{
		PlayAnimation(StateOtherAnim);
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidUserPopupWidget

URaidUserPopupWidget::URaidUserPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void URaidUserPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RaidUserMeWidget = CastChecked<URaidUserListWidget>(GetWidgetFromName("RaidUserMe"));

	RaidUserListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("UserList"));

	OnDismissButtonClickedDelegate.BindUObject(this, &URaidUserPopupWidget::OnDismiss);
}

void URaidUserPopupWidget::OnDismiss()
{
	if (RaidUserPopupTimerHandle.IsValid()
		&& UQ6GameInstance::Get(this)->HasQ6TimerManager())
	{
		UQ6GameInstance::Get(this)->GetQ6TimerManager().ClearTimer(RaidUserPopupTimerHandle);
	}
}

void URaidUserPopupWidget::SetRaidUserInfo()
{
	const TArray<FRaidParticipateUserInfo> RaidUserInfos = GetHUDStore().GetRaidManager().GetRaidUserInfos();

	SetTitle(FText::Format(Q6Util::GetLocalizedText("Popup", "RaidUserListPopupTitle")
		, FText::AsNumber(RaidUserInfos.Num())));

	RaidUserListWidget->ClearList();
	int32 Rank(0);
	for (const FRaidParticipateUserInfo& UserInfo : RaidUserInfos)
	{
		if (GetUser().GetId() == UserInfo.UserId)
		{
			RaidUserMeWidget->SetRaidUserListInfo(
				++Rank
				, UserInfo.End ? ERaidUserState::End : ERaidUserState::OnGoing
				, UserInfo.TurnCount
				, FText::FromString(UserInfo.UserName)
				, UserInfo.Score
				, true
				, UserInfo.Healths);
		}
		else
		{
			URaidUserListWidget* Widget = CastChecked<URaidUserListWidget>(
				RaidUserListWidget->AddChildAtLastIndex());

			Widget->SetRaidUserListInfo(
				++Rank
				, UserInfo.End ? ERaidUserState::End : ERaidUserState::OnGoing
				, UserInfo.TurnCount
				, FText::FromString(UserInfo.UserName)
				, UserInfo.Score
				, false
				, UserInfo.Healths);
		}
	}
}

void URaidUserPopupWidget::StartTimer()
{
	if (UQ6GameInstance::Get(this)->HasQ6TimerManager())
	{
		FQ6TimerManager& Q6TimeManager = UQ6GameInstance::Get(this)->GetQ6TimerManager();
		Q6TimeManager.SetTimer(RaidUserPopupTimerHandle
			, this
			, &URaidUserPopupWidget::SetRaidUserInfo
			, 5.0f
			, true
			, 0.0f);
	}
}

//////////////////////////////////////////////////////////////////////////
// URaidEmoticonWidget

URaidEmoticonWidget::URaidEmoticonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurSelectedEmoticonIndex(INDEX_NONE)
	, RemainTimeSecs(0)
	, EmoticonIndex(0)
{

}

void URaidEmoticonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	RaidEmoticonAnims.Reset();
	RaidEmoticonAnims.Add(GetWidgetAnimationFromName(this, "AnimButtonEnabled"));
	RaidEmoticonAnims.Add(GetWidgetAnimationFromName(this, "AnimButtonDisabled"));
	RaidEmoticonAnims.Add(GetWidgetAnimationFromName(this, "AnimEmoticonStart"));
	RaidEmoticonAnims.Add(GetWidgetAnimationFromName(this, "AnimEmoticonEnd"));
	check(RaidEmoticonAnims.Num() == static_cast<int32>(ERaidEmoticonAnimType::Max));

	UButton* EmoticonButton = CastChecked<UButton>(GetWidgetFromName("BtnEmoticon"));
	EmoticonButton->OnClicked.AddUniqueDynamic(this, &URaidEmoticonWidget::OnEmoticonButtonClicked);

	UButton* CloseButton = CastChecked<UButton>(GetWidgetFromName("BtnClose"));
	CloseButton->OnClicked.AddUniqueDynamic(this, &URaidEmoticonWidget::OnEmoticonCloseButtonClicked);

	SecondText = CastChecked<UTextBlock>(GetWidgetFromName("TextSecond"));

	EmoticonListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("EmoticonList"));

	Emoticons.Reset();
	FString EmoticonNameStr;
	for (int32 Index = 0; Index < MAX_RAID_EMOTICON_COUNT; ++Index)
	{
		EmoticonNameStr = FString::Printf(TEXT("Emoticon%02d"), Index);
		URaidEmoticonShowWidget* EmoticonShowWidget = CastChecked<URaidEmoticonShowWidget>(
			GetWidgetFromName(*EmoticonNameStr));
		EmoticonShowWidget->SetInfo();
		Emoticons.Add(EmoticonShowWidget);
	}

	SubscribeToStore(EHSType::Raid);
}

void URaidEmoticonWidget::NativeDestruct()
{
	if (IntervalTimerHandle.IsValid()
		&& UQ6GameInstance::Get(this)->HasQ6TimerManager())
	{
		UQ6GameInstance::Get(this)->GetQ6TimerManager().ClearTimer(IntervalTimerHandle);
	}

	Super::NativeDestruct();
}

void URaidEmoticonWidget::SetInfo()
{
	EmoticonListWidget->ClearList();
	EmoticonButtons.Reset();
	const int32 RaidEmoticonImagesNum = GetUIResource().GetRaidEmoticonImagesNum();
	for (int32 Index = 0; Index < RaidEmoticonImagesNum; ++Index)
	{
		URaidEmoticonButtonWidget* Widget = CastChecked<URaidEmoticonButtonWidget>(EmoticonListWidget->AddChildAtLastIndex());
		Widget->SetInfo(Index);
		Widget->RaidEmoticonButtonClickedDelegate.BindUObject(this, &URaidEmoticonWidget::OnRaidEmoticonButtonClicked);

		EmoticonButtons.Add(Widget);
	}

	PlayRaidEmoticonAnimation(ERaidEmoticonAnimType::ButtonEnable);
}

void URaidEmoticonWidget::PlayRaidEmoticonAnimation(ERaidEmoticonAnimType InType)
{
	uint8 AnimationIndex = static_cast<uint8>(InType);
	if (RaidEmoticonAnims.IsValidIndex(AnimationIndex))
	{
		PlayAnimation(RaidEmoticonAnims[AnimationIndex]);
	}
}

void URaidEmoticonWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByRaidEmoticon);

	switch (InAction->GetActionType())
	{
		case EHSActionType::RaidEmoticonNof:
		{
			const auto& Action = ACTION_PARSE_RaidEmoticonNof(InAction);
			const auto& Res = Action->GetVal();

			ShowEmoticon(Res.Emoticon, Res.UserName);
		}
		break;
	}
}

void URaidEmoticonWidget::SetRemainTime(const int32 InRemainTimeSecs)
{
	SecondText->SetText(FText::AsNumber(InRemainTimeSecs));
}

void URaidEmoticonWidget::OnEmoticonButtonClicked()
{
	if (RemainTimeSecs)
	{
		return;
	}

	PlayRaidEmoticonAnimation(ERaidEmoticonAnimType::EmoticonStart);

	for (auto Elem : EmoticonButtons)
	{
		if (Elem)
		{
			Elem->PlayRaidEmoticonButtonAnimation(ERaidEmoticonButtonAnimType::ElementNormal);
		}
	}

	CurSelectedEmoticonIndex = INDEX_NONE;
}

void URaidEmoticonWidget::OnEmoticonCloseButtonClicked()
{
	PlayRaidEmoticonAnimation(ERaidEmoticonAnimType::EmoticonEnd);
}

void URaidEmoticonWidget::OnRaidEmoticonButtonClicked(const int32 InIndex)
{
	if (CurSelectedEmoticonIndex == InIndex && RemainTimeSecs == 0)
	{
		GetHUDStore().GetRaidManager().ReqUseEmoticon(CurSelectedEmoticonIndex);

		PlayRaidEmoticonAnimation(ERaidEmoticonAnimType::ButtonDisable);
		PlayRaidEmoticonAnimation(ERaidEmoticonAnimType::EmoticonEnd);

		RemainTimeSecs = RAID_EMOTICON_INTERVAL_TIME;

		if (UQ6GameInstance::Get(this)->HasQ6TimerManager())
		{
			FQ6TimerManager& Q6TimeManager = UQ6GameInstance::Get(this)->GetQ6TimerManager();
			Q6TimeManager.ClearTimer(IntervalTimerHandle);
			Q6TimeManager.SetTimer(IntervalTimerHandle
				, this
				, &URaidEmoticonWidget::EmoticonTimer
				, 1.1f
				, true
				, 0.0f);
		}
	}
	else
	{
		if (CurSelectedEmoticonIndex == INDEX_NONE)
		{
			for (auto Elem : EmoticonButtons)
			{
				if (Elem)
				{
					Elem->PlayRaidEmoticonButtonAnimation(ERaidEmoticonButtonAnimType::ElementOut);
				}
			}
		}
		else
		{
			if (EmoticonButtons.IsValidIndex(CurSelectedEmoticonIndex))
			{
				URaidEmoticonButtonWidget* Widget = EmoticonButtons[CurSelectedEmoticonIndex];
				if (Widget)
				{
					Widget->PlayRaidEmoticonButtonAnimation(ERaidEmoticonButtonAnimType::ElementOut);
				}
			}
		}

		CurSelectedEmoticonIndex = InIndex;

		if (EmoticonButtons.IsValidIndex(CurSelectedEmoticonIndex))
		{
			URaidEmoticonButtonWidget* Widget = EmoticonButtons[CurSelectedEmoticonIndex];
			if (Widget)
			{
				Widget->PlayRaidEmoticonButtonAnimation(ERaidEmoticonButtonAnimType::ElementSelect);
			}
		}
	}
}

void URaidEmoticonWidget::ShowEmoticon(const int32 InEmoticon, const FString& InUserName)
{
	if (Emoticons.IsValidIndex(EmoticonIndex))
	{
		Emoticons[EmoticonIndex]->ShowEmoticon(InEmoticon, InUserName);
	}

	++EmoticonIndex;
	EmoticonIndex %= MAX_RAID_EMOTICON_COUNT;
}

void URaidEmoticonWidget::EmoticonTimer()
{
	if (RemainTimeSecs < 0)
	{
		RemainTimeSecs = 0;

		if (IntervalTimerHandle.IsValid()
			&& UQ6GameInstance::Get(this)->HasQ6TimerManager())
		{
			UQ6GameInstance::Get(this)->GetQ6TimerManager().ClearTimer(IntervalTimerHandle, true);
		}

		PlayRaidEmoticonAnimation(ERaidEmoticonAnimType::ButtonEnable);
		return;
	}

	SetRemainTime(RemainTimeSecs--);
}

//////////////////////////////////////////////////////////////////////////
// URaidEmoticonShowWidget

URaidEmoticonShowWidget::URaidEmoticonShowWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void URaidEmoticonShowWidget::NativeConstruct()
{
	EmoticonShowAnim = GetWidgetAnimationFromName(this, "EmoticonShow");
	check(EmoticonShowAnim);

	UserNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextUserName"));
	EmoticonImage = CastChecked<UImage>(GetWidgetFromName("EmoticonImage"));
}

void URaidEmoticonShowWidget::SetInfo()
{
	UCanvasPanelSlot* CanvasPanelSlot = CastChecked<UCanvasPanelSlot>(this->Slot);
	EmoticonOriginPos = CanvasPanelSlot->GetPosition();
}

void URaidEmoticonShowWidget::ShowEmoticon(const int32 InIndex, const FString& InUserName)
{
	UCanvasPanelSlot* CanvasPanelSlot = CastChecked<UCanvasPanelSlot>(this->Slot);

	int32 OffsetX = FMath::RandRange(-100, 100);
	int32 OffsetY = FMath::RandRange(-100, 100);

	CanvasPanelSlot->SetPosition(FVector2D(EmoticonOriginPos.X + OffsetX
		, EmoticonOriginPos.Y + OffsetY));

	UserNameText->SetText(FText::FromString(InUserName));

	const FSlateBrush& EmoticonBrush = GetUIResource().GetRaidEmoticon(InIndex);
	EmoticonImage->SetBrush(EmoticonBrush);

	PlayAnimation(EmoticonShowAnim);
}

//////////////////////////////////////////////////////////////////////////
// URaidEmoticonButtonWidget

URaidEmoticonButtonWidget::URaidEmoticonButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, RaidEmoticonButtonIndex(INDEX_NONE)
{

}

void URaidEmoticonButtonWidget::NativeConstruct()
{
	RaidEmoticonButtonAnims.Reset();
	RaidEmoticonButtonAnims.Add(GetWidgetAnimationFromName(this, "AnimElementNormal"));
	RaidEmoticonButtonAnims.Add(GetWidgetAnimationFromName(this, "AnimElementSelect"));
	RaidEmoticonButtonAnims.Add(GetWidgetAnimationFromName(this, "AnimElementOut"));
	check(RaidEmoticonButtonAnims.Num() == static_cast<int32>(ERaidEmoticonButtonAnimType::Max));

	EmoticonImage = CastChecked<UImage>(GetWidgetFromName("EmoticonImage"));

	UButton* ElementButton = CastChecked<UButton>(GetWidgetFromName("ButtonElement"));
	ElementButton->OnClicked.AddUniqueDynamic(this, &URaidEmoticonButtonWidget::OnElementButtonClicked);
}

void URaidEmoticonButtonWidget::SetInfo(int32 InIndex)
{
	RaidEmoticonButtonIndex = InIndex;

	const FSlateBrush& RaidEmoticon = GetUIResource().GetRaidEmoticon(RaidEmoticonButtonIndex);
	EmoticonImage->SetBrush(RaidEmoticon);
}

void URaidEmoticonButtonWidget::PlayRaidEmoticonButtonAnimation(ERaidEmoticonButtonAnimType InType)
{
	StopAllAnimations();

	int32 AnimationIndex = static_cast<int32>(InType);
	if (RaidEmoticonButtonAnims.IsValidIndex(AnimationIndex))
	{
		PlayAnimation(RaidEmoticonButtonAnims[AnimationIndex]);
	}
}

void URaidEmoticonButtonWidget::OnElementButtonClicked()
{
	RaidEmoticonButtonClickedDelegate.ExecuteIfBound(RaidEmoticonButtonIndex);
}

//////////////////////////////////////////////////////////////////////////
// UBondUpResultWidget

UBondUpResultWidget::UBondUpResultWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer),
	BondReward(nullptr),
	NumOfLvUpCharacters(0),
	CurrentCharacterIndex(0),
	CurrentBondTemperature(0),
	bTempUp(false),
	TempUpStartTime(0.f),
	ElapsedTime(0.f)
{
}

void UBondUpResultWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StartAnim = GetWidgetAnimationFromName(this, "AnimStart");
	check(StartAnim);
	BondUpAnim = GetWidgetAnimationFromName(this, "AnimBondUp");
	check(BondUpAnim);
	BondRewardAnim = GetWidgetAnimationFromName(this, "AnimBondReward");
	check(BondRewardAnim);

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	GradeImage = CastChecked<UImage>(GetWidgetFromName("Grade"));
	NatureImage = CastChecked<UImage>(GetWidgetFromName("Nature"));

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	NickNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextNickName"));
	TemperatureText = CastChecked<UTextBlock>(GetWidgetFromName("ResultBond"));

	UButton* TouchScreen = CastChecked<UButton>(GetWidgetFromName("Dismiss"));
	TouchScreen->OnClicked.AddUniqueDynamic(this, &UBondUpResultWidget::OnTouchScreenClicked);

	SupportBox = CastChecked<USizeBox>(GetWidgetFromName("Support"));
	CurrentSupportLevelText = CastChecked<UTextBlock>(GetWidgetFromName("CurrentSupportLevel"));
	ResultSupportLevelText = CastChecked<UTextBlock>(GetWidgetFromName("ResultSupportLevel"));
	IconSupportSkillImage = CastChecked<UImage>(GetWidgetFromName("IconSupportSkill"));

	for (int32 n = 0; n < MAX_BOND_UP_REWARD_ICON; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("Item%d"), n);
		UItemWidget* ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName(*WidgetName));
		ItemWidgets.AddUnique(ItemWidget);
	}

	for (int32 n = 0; n < MAX_BOND_REWARD; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("BondReward%d"), n);
		UBondRewardWidget* BondWidget = CastChecked<UBondRewardWidget>(GetWidgetFromName(*WidgetName));
		BondRewards.AddUnique(BondWidget);
	}
}

void UBondUpResultWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FBondUpResultUIState* UIState = GetUIState()->CastToBondUpResultUIState();
	check(UIState);

	SetInfos();
}

void UBondUpResultWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (!bTempUp)
	{
		return;
	}

	if (TempUpStartTime < ElapsedTime)
	{
		AddBondLevel();
		ElapsedTime = 0.f;
	}

	ElapsedTime += InDeltaTime;
}

void UBondUpResultWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (Animation == StartAnim)
	{
		int32 LevelDiff = BondReward->NewLevel - BondReward->OldLevel;
		TempUpStartTime = BondUpAnim->GetEndTime() / (LevelDiff * BondTemperaturePerLevel);

		bTempUp = true;
		PlayAnimation(BondUpAnim);
	}
	else if (Animation == BondUpAnim)
	{
		PlayAnimation(BondRewardAnim);
	}
}

void UBondUpResultWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByBondUpResult);

	RefreshMenu();
}

void UBondUpResultWidget::SetInfos()
{
	const TArray<FBondLevelUpReward>& Rewards = UQ6GameInstance::Get(this)->GetBondRewards();
	NumOfLvUpCharacters = Rewards.Num();

	if (NumOfLvUpCharacters == 0)
	{
		Q6JsonLogGunny(Warning, "UBondUpResultWidget::SetInfos - BondRewards do not exist. and how could you enter in..? ");
		return;
	}

	SetInfo(Rewards[CurrentCharacterIndex]);
}

void UBondUpResultWidget::SetInfo(const FBondLevelUpReward& InBondReward)
{
	BondReward = &InBondReward;
	PlayAnimation(StartAnim);

	const UCMS* CMS = GetCMS();
	const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(InBondReward.CharacterType);
	if (CharacterRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UBondUpResultWidget::SetInfo - CharacterRow does not exist.",
			Q6KV("CharacterType", InBondReward.CharacterType));
		return;
	}

	const FUnitType UnitType = CMS->GetUnitType(InBondReward.CharacterType);
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(UnitType);
	if (UnitRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UBondUpResultWidget::SetInfo - UnitRow does not exist.",
			Q6KV("UnitType", UnitType));
		return;
	}

	UGameResource& GameResource = GetGameResource();
	const FCharacterAssetRow& CharacterAssetRow = GameResource.GetCharacterAssetRow(InBondReward.CharacterType);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);

	UUIResource& UIResource = GetUIResource();
	const FItemGrade& ItemGrade = UIResource.GetItemGrade(CharacterRow.Grade);
	GradeImage->SetBrush(ItemGrade.TextBrush);

	const FSlateBrush& NatureIcon = UIResource.GetNatureTypeIcon(UnitRow.NatureType);
	NatureImage->SetBrush(NatureIcon);

	NameText->SetText(UnitRow.FullName);
	if (UnitRow.NickName.IsEmptyOrWhitespace())
	{
		NickNameText->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		NickNameText->SetText(UnitRow.NickName);
		NickNameText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}

	CurrentBondTemperature = (InBondReward.OldLevel) * BondTemperaturePerLevel;
	TemperatureText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Temperature"),
		FText::AsNumber(CurrentBondTemperature)));

	// Support Skill

	int32 OldSupportSkillLevel
		= FMath::Clamp(InBondReward.OldLevel, CombatCubeConst::Q6_MIN_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL);
	int32 NewSupportSkillLevel
		= FMath::Clamp(BondReward->NewLevel.x, CombatCubeConst::Q6_MIN_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL);
	if (OldSupportSkillLevel < NewSupportSkillLevel)
	{
		SupportBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		CurrentSupportLevelText->SetText(FText::AsNumber(OldSupportSkillLevel));
		ResultSupportLevelText->SetText(FText::AsNumber(NewSupportSkillLevel));

		const FSkillAssetRow& SkillAssetRow = GameResource.GetSkillAssetRow(UnitRow.Model);
		IconSupportSkillImage->SetBrush(SkillAssetRow.SupportIcon);
	}
	else
	{
		SupportBox->SetVisibility(ESlateVisibility::Collapsed);
	}

	SetReward(InBondReward.Rewards);
}

void UBondUpResultWidget::SetReward(const TArray<FBondReward>& Rewards)
{
	// Set bond rewards

	int32 ItemIndex = 0;
	int32 CharUnlockElemIndex = 0;

	for (const FBondReward& Reward : Rewards)
	{
		switch (Reward.Type)
		{
			case ELootCategory::FreeGem:
				ItemWidgets[ItemIndex++]->SetCurrency(ECurrencyType::FreeGem, Reward.Param);
				break;
			case ELootCategory::Gold:
				ItemWidgets[ItemIndex++]->SetCurrency(ECurrencyType::Gold, Reward.Param);
				break;
			case ELootCategory::RelicCard:
				ItemWidgets[ItemIndex++]->SetRelic(FRelicType(Reward.Param));
				break;
			case ELootCategory::SmallBattery:
				ItemWidgets[ItemIndex++]->SetPoint(EPointType::SmallBattery, Reward.Param);
				break;
			case ELootCategory::MediumBattery:
				ItemWidgets[ItemIndex++]->SetPoint(EPointType::MediumBattery, Reward.Param);
				break;
			case ELootCategory::LargeBattery:
				ItemWidgets[ItemIndex++]->SetPoint(EPointType::LargeBattery, Reward.Param);
				break;
			case ELootCategory::CharUnlockElem:
			case ELootCategory::Special:
				BondRewards[CharUnlockElemIndex++]->SetInfo(Reward.Type, Reward.Param);
				break;
			default:
				break;
		}
	}

	for (int32 i = ItemIndex; i < ItemWidgets.Num(); ++i)
	{
		ItemWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
	}

	for (int32 i = CharUnlockElemIndex; i < BondRewards.Num(); ++i)
	{
		BondRewards[i]->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UBondUpResultWidget::ShowNextReward()
{
	GetBaseHUD(this)->ProcessReward();
}

void UBondUpResultWidget::AddBondLevel()
{
	++CurrentBondTemperature;
	TemperatureText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Temperature"),
		FText::AsNumber(CurrentBondTemperature)));

	bTempUp = (BondReward->NewLevel * BondTemperaturePerLevel) != CurrentBondTemperature;
}

void UBondUpResultWidget::OnTouchScreenClicked()
{
	if (CurrentCharacterIndex == NumOfLvUpCharacters - 1)
	{
		ShowNextReward();
		return;
	}

	++CurrentCharacterIndex;

	const TArray<FBondLevelUpReward>& Rewards = UQ6GameInstance::Get(this)->GetBondRewards();

	SetInfo(Rewards[CurrentCharacterIndex]);
}

//////////////////////////////////////////////////////////////////////////
// UWipeoutPopupWidget

void UCombatWipeoutWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemDropListWidget = CastChecked<UItemDropListWidget>(GetWidgetFromName("ItemDropList"));

	ArtifactButtonWidget = CastChecked<UCombatWonderSkillButtonWidget>(GetWidgetFromName("Artifact"));
	ArtifactButtonWidget->OnWonderSkillSelectedDelegate.BindUObject(this, &UCombatWipeoutWidget::OnArtifactButtonClicked);

	OwnedGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedGem"));
	OwnedGemWidget->SetPointType(EPointType::AnyGem, EPointWidgetOption::NONE);

	RequiredGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequiredGem"));
	RequiredGemWidget->SetPointType(EPointType::AnyGem, EPointWidgetOption::LessEqual);

	UseGemButton = CastChecked<UButton>(GetWidgetFromName("ButtonUseGem"));
	UseGemButton->OnClicked.AddUniqueDynamic(this, &UCombatWipeoutWidget::OnUseGemButtonClicked);

	UButton* WithdrawButton = CastChecked<UButton>(GetWidgetFromName("ButtonWithdraw"));
	WithdrawButton->OnClicked.AddUniqueDynamic(this, &UCombatWipeoutWidget::OnWithdrawButtonClicked);

	WipeoutCount = 0;
}

void UCombatWipeoutWidget::SetWipeout()
{
	ItemDropListWidget->SetItemDropInfo();

	// Set artifact

	const TArray<FSkillState>& Artifacts = GetCheckedCombatPresenter(this)->GetAllyMaster().Artifacts;
	for (int32 i = 0; i < Artifacts.Num(); ++i)
	{
		if (Artifacts[i].SkillType == TempleConst::Q6_ARTIFACT3_SKILL_ID)
		{
			ArtifactButtonWidget->SetArtifactSkill(Artifacts[i]);
			break;
		}
	}

	int32 InResurrectionCount = GetHUDStore().GetUserRecordManager().GetResurrectionCount();
	if (InResurrectionCount == 0 && WipeoutCount == 0)
	{
		TUTORIAL_MONITORING_BUTTON_CLICK("AlliesWipeoutFirst");
	}

	++WipeoutCount;
	// Set currency
	GetCheckedCombatCube(this)->GetStore()->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InResurrectionCount](FCCUnitId ReqUnitId, FCombatState RepState) {
		UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
		check(GameInstance);
		int32 GemCount = GameInstance->GetCombatSeed().Seed.FreeGem + GameInstance->GetCombatSeed().Seed.PaidGem;
		int32 InGemWipeoutContinueCount = RepState.GemWipeoutContinueCount;
		bool bFirstBlood = false;
		if (InResurrectionCount == 0)
		{
			if (InGemWipeoutContinueCount == 0)
			{
				bFirstBlood = true;
			}

			InGemWipeoutContinueCount = FMath::Max(0, InGemWipeoutContinueCount - 1);
		}
		GemCount -= InGemWipeoutContinueCount * SystemConst::Q6_REBIRTH_GEM_COST;

		OwnedGemWidget->SetCurPoint(GemCount);
		RequiredGemWidget->SetPoint(bFirstBlood ? 0 : SystemConst::Q6_REBIRTH_GEM_COST, GemCount);

		UTextBlock* GemText = CastChecked<UTextBlock>(GetWidgetFromName("TextUseGem"));
		if (GemText)
		{
			GemText->SetText(Q6Util::GetLocalizedText("Combat", "UseGemToResurrection"));
		}
	}));
}

void UCombatWipeoutWidget::OnArtifactButtonClicked(FCCSkillId SkillId, int32 SkillType, FCCUnitId TargetUnitId, ESkillCategory SkillCategory)
{
	UConfirmPopupWidget* ConfirmPopup = GetCheckedCombatHUD(this)->OpenConfirmPopup(
		Q6Util::GetLocalizedText("Popup", "UseSwordPopupTitle"), Q6Util::GetLocalizedText("Popup", "UseSwordPopupContent"));
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UCombatWipeoutWidget::OnArtifactRebirth);
}

void UCombatWipeoutWidget::OnUseGemButtonClicked()
{
	int32 GemCount = GetHUDStore().GetWorldUser().GetTotalGem();
	int32 InResurrectionCount = GetHUDStore().GetUserRecordManager().GetResurrectionCount();
	bool bFirstBlood = InResurrectionCount == 0 && WipeoutCount == 1;
	int32 RequiredGemCost = bFirstBlood ? 0 : SystemConst::Q6_REBIRTH_GEM_COST;

	if (GemCount < RequiredGemCost)
	{
		UConfirmPopupWidget* ConfirmPopup = GetCheckedCombatHUD(this)->OpenConfirmPopup(
			Q6Util::GetLocalizedText("Popup", "UseGemPlayLackTitle"), Q6Util::GetLocalizedText("Popup", "UseGemPlayLack"));
		ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UCombatWipeoutWidget::OnGemShopPurchase);
	}
	else
	{
		TUTORIAL_MONITORING_BUTTON_CLICK("CombatWipeoutUseGemButton");
		UCurrencyUsePopupWidget* CurrencyUsePopup = GetCheckedCombatHUD(this)->OpenCurrencyUsePopup();
		check(CurrencyUsePopup);

		CurrencyUsePopup->SetRebirth();
		CurrencyUsePopup->OnCurrencyUsedDelegate.BindUObject(this, &UCombatWipeoutWidget::OnGemRebirth);
	}
}

void UCombatWipeoutWidget::OnWithdrawButtonClicked()
{
	const FCCCombatSeed& CombatSeed = GetCheckedCombatPresenter(this)->GetCombatSeed();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);

	GetCheckedCombatHUD(this)->OpenWithdrawPopup(SagaRow.ContentType);
}

void UCombatWipeoutWidget::OnGemShopPurchase(EConfirmPopupFlag Option)
{
	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetCombatHUD(this)->OpenGemShopPurchasePopup();
}

void UCombatWipeoutWidget::OnArtifactRebirth(EConfirmPopupFlag Option)
{
	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetCheckedCombatHUD(this)->PlayArtifactAnimation(TempleConst::Q6_ARTIFACT3_SKILL_ID, CCUnitIdInvalid);

	RemoveFromParent();
}

void UCombatWipeoutWidget::OnGemRebirth()
{
	TUTORIAL_MONITORING_BUTTON_CLICK("CombatWipeoutGemRebirth");
	GetCheckedCombatHUD(this)->PlayArtifactAnimation(SystemConst::Q6_GEM_REBIRTH_SKILL_ID, CCUnitIdInvalid);

	RemoveFromParent();
}

//////////////////////////////////////////////////////////////////////////////////
// UBackTurnButtonWidget

UBackTurnButtonWidget::UBackTurnButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UBackTurnButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AnimOn = GetWidgetAnimationFromName(this, "AnimBackTurnOn");
	AnimOff = GetWidgetAnimationFromName(this, "AnimBackTurnOff");

	UButton* BackButton = CastChecked<UButton>(GetWidgetFromName("BackTurnBtn"));
	BackButton->OnClicked.AddUniqueDynamic(this, &UBackTurnButtonWidget::OnBackButtonClicked);
}

void UBackTurnButtonWidget::SetOn(bool bOn)
{
	if (!GetCombatTutorial(this)->IsBackToTurnPhaseEnable())
	{
		this->SetVisibility(ESlateVisibility::Collapsed);
		return;
	}

	if (bOn)
	{
		PlayAnimation(AnimOn);
	}
	else
	{
		PlayAnimation(AnimOff);
	}
}

void UBackTurnButtonWidget::OnBackButtonClicked()
{
	OnBackButtonClickedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////////////
// UCombatMenuWidget

UCombatMenuWidget::UCombatMenuWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UCombatMenuWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Animations
	OpenAnim = GetWidgetAnimationFromName(this, "AnimMenuOpen");
	check(OpenAnim);

	CloseAnim = GetWidgetAnimationFromName(this, "AnimMenuClose");
	check(CloseAnim);

	// Widgets
	MascotImage = CastChecked<UImage>(GetWidgetFromName("ImgMascot"));
	MascotText = CastChecked<UQ6TextBlock>(GetWidgetFromName("MascotSpeak"));

	ItemDropListWidget = CastChecked<UItemDropListWidget>(GetWidgetFromName("ItemDropList"));
	NoItemText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextNoItem"));

	WithdrawButton = CastChecked<UQ6Button>(GetWidgetFromName("Withdraw"));
	WithdrawButton->OnClickedDelegate.BindUObject(this, &UCombatMenuWidget::OnWithdrawButtonClicked);
	ResumeButton = CastChecked<UQ6Button>(GetWidgetFromName("Resume"));
	ResumeButton->OnClickedDelegate.BindUObject(this, &UCombatMenuWidget::OnResumeButtonClicked);
	SettingButton = CastChecked<UQ6Button>(GetWidgetFromName("Setting"));
	SettingButton->OnClickedDelegate.BindUObject(this, &UCombatMenuWidget::OnSettingButtonClicked);
}

void UCombatMenuWidget::OpenWidget()
{
	// random pick a mascot asset
	const TArray<FMascotAsset>& MascotAssets = GetUIResource().GetMascotAssets();
	int32 RandomIndex = FMath::RandRange(0, MascotAssets.Num() - 1);
	MascotImage->SetBrush(MascotAssets[RandomIndex].Brush);
	MascotText->SetText(MascotAssets[RandomIndex].Speak);

	PlayAnimation(OpenAnim);

	ItemDropListWidget->SetItemDropInfo();

	NoItemText->SetVisibility(GetCheckedCombatHUD(this)->HasItemDrop() ? ESlateVisibility::Collapsed : ESlateVisibility::SelfHitTestInvisible);
}

void UCombatMenuWidget::OnWithdrawButtonClicked()
{
	const FCCCombatSeed& CombatSeed = GetCheckedCombatPresenter(this)->GetCombatSeed();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);

	GetCheckedCombatHUD(this)->OpenWithdrawPopup(SagaRow.ContentType);
}

void UCombatMenuWidget::OnResumeButtonClicked()
{
	PlayAnimation(CloseAnim);
}

void UCombatMenuWidget::OnSettingButtonClicked()
{
	ABaseHUD* BaseHUD = GetBaseHUD(this);
	if (BaseHUD)
	{
		BaseHUD->OpenSettingPopup();
	}
}
