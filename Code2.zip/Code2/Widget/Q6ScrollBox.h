// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"
#include "Q6ScrollBox.generated.h"

DECLARE_DELEGATE(FOnDescendantScrolled)
DECLARE_DELEGATE(FOnSnapTrackingFired)

class Q6_API SQ6SnapScrollBox : public SScrollBox
{
public:
	SLATE_BEGIN_ARGS(SQ6SnapScrollBox)
		: _Style(&FCoreStyle::Get().GetWidgetStyle<FScrollBoxStyle>("ScrollBox"))
		, _ScrollBarStyle(&FCoreStyle::Get().GetWidgetStyle<FScrollBarStyle>("ScrollBar"))
		, _Orientation(Orient_Vertical)
		, _NavigationDestination(EDescendantScrollDestination::IntoView)
		, _NavigationScrollPadding(0.0f)
		, _ConsumeMouseWheel(EConsumeMouseWheel::WhenScrollingPossible)
		, _DescendantScrollThresHold(0.001f)
		, _SnapVelocity(0.0f)
		, _OnUserScrolled()
		, _OnDescendantScrolled()
		, _OnSnapTrackingFired()
		{
		}

		SLATE_STYLE_ARGUMENT(FScrollBoxStyle, Style) //-V1004
		SLATE_STYLE_ARGUMENT(FScrollBarStyle, ScrollBarStyle) //-V1004
		SLATE_ARGUMENT(EOrientation, Orientation)
		SLATE_ARGUMENT(EDescendantScrollDestination, NavigationDestination)
		SLATE_ARGUMENT(float, NavigationScrollPadding)
		SLATE_ARGUMENT(EConsumeMouseWheel, ConsumeMouseWheel)
		SLATE_ARGUMENT(float, DescendantScrollThresHold)
		SLATE_ARGUMENT(float, SnapVelocity)
		SLATE_EVENT(FOnUserScrolled, OnUserScrolled)
		SLATE_EVENT(FOnDescendantScrolled, OnDescendantScrolled)
		SLATE_EVENT(FOnSnapTrackingFired, OnSnapTrackingFired)
	SLATE_END_ARGS()

public:
	SQ6SnapScrollBox();

	void Construct(const FArguments& InArgs);
	void ScrollToDescendant(const TSharedPtr<SWidget>& WidgetToFind, float Padding);

	// SWidget interface
	virtual void Tick(const FGeometry& AllottedGeometry, const double InCurrentTime, const float InDeltaTime) override;
	virtual FReply OnMouseWheel(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply OnTouchEnded(const FGeometry& MyGeometry, const FPointerEvent& InTouchEvent) override;
	// End of SWidget interface

private:
	void SnapTracking();

private:
	enum class EDescendantScroll : uint8
	{
		No,
		Scrolling,
		Fired,
	};

	float DescendantScrollThresHold;
	EDescendantScroll DescendantScroll;

	float SnapVelocity;
	bool bDoSnapTracking;

	FOnDescendantScrolled OnDescendantScrolled;
	FOnSnapTrackingFired OnSnapTrackingFired;
};

UCLASS()
class Q6_API UQ6SnapScrollBox : public UScrollBox
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Q6")
	float ScrollPadding;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Q6")
	float ScrollThresHold;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Q6")
	float SnapVelocity;

	FOnDescendantScrolled OnDescendantScrolled;
	FOnSnapTrackingFired OnSnapTrackingFired;

public:
	void ScrollToDescendant(UWidget* WidgetToFind);

protected:
	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	//~ End UWidget Interface

	TSharedPtr<SQ6SnapScrollBox> GetSnapScrollBox() const;

	void SlateHandleDescendantScrolled();
	void SlateHandleSnapTrackingFired();
};
