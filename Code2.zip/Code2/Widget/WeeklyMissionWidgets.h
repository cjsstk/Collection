#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

#include "WeeklyMissionWidgets.generated.h"

class UQ6Button;
class UBorder;
class UPointWidget;
class UItemWidget;
class UTextBlock;
class UProgressBar;
class UItemWidget;
class UMissionGaugeWidget;

UCLASS()
class Q6_API UMissionBonusButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UMissionBonusButtonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetInfo(const int32 InIndex
		, const int32 WeekNum
		, bool bEnable
		, const int32 BingoUTC);

	FSimpleDelegate OnMissionBonusButtonClickedDelegate;

private:
	void SetItem(const int32 InWeekNum, const int32 InIndex);

	UFUNCTION()
	void OnMissionBonusButtonClicked();

	void PlayMissionBonusButtonAnim(EMissionBonusButtonAnimType Type);

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> MissionBonusButtonAnims;

	UPROPERTY()
	UItemWidget* ItemWidget;
};

UCLASS()
class Q6_API UMissionButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UMissionButtonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetInfo(const FMissionType& InType
		, const FText& InText
		, const int32 Curr
		, const int32 Max
		, const int32 RewardUTC
		, bool bEnterMenu
		, bool bIsRequestMissionItemIndex);

	bool SetBingo(const int32 Row
		, const int32 Col
		, const FMissionInfo& MissionInfo);

	void PlayShuffleAnimation();
	void PlayMissionButtonAnim(EMissionButtonAnimType Type);

	void SetCheckedState(ECheckBoxState InState);
	ECheckBoxState GetCheckedState() { return DescCheckBox->GetCheckedState(); }

	FSimpleDelegate OnMissionToggleClickedDelegate;
	FSimpleDelegate OnMissionShuffleAnimFinished;
	FSimpleDelegate OnMissionCompleteStartAnimFinished;

private:
	void SetMissionTitleText(const FMissionType& InType, const FText& InText);
	void SetMissionProgressBar(const int32 curr, const int32 Max);
	void SetItem(const FMissionType& InType);

	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	UFUNCTION()
	void OnDescToggleClicked(bool bInChecked);

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> MissionButtonAnims;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UTextBlock* MissionTitleText;

	UPROPERTY()
	UProgressBar* MissionProgressBar;

	UPROPERTY()
	UCheckBox* DescCheckBox;

	EMissionButtonAnimType ReservedAnimAfterShuffle;
};

UCLASS()
class Q6_API UWeeklyMissionWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UWeeklyMissionWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void OnItemReceivedPopupClosed();

	void ResetInfo(bool bEnterMenu);

	void PlayWeeklyMissionAnim(EWeeklyMissionAnimType Type);

	void OpenReceivedBingoItemPopup();
	void OpenReceivedRewardItemPopup();

	void SetRequiredCurrency(const int64 InRequireGold);
	void SetFreeBorder(bool bFree);
	void SetRequireGold(const int64 InRequireGold);
	void SetMissionDesc(const int32 Index);
	void SetRemainTimeInfo();

	void PlayShuffleAnimation();
	void PlayMissionButtonBingoAnimation(const int32 MissionBonusIndex);

	int64 GetShuffleRequireGold(const int32 ResetCount);

	bool CheckMission(const int32 Index);
	bool CheckMissionBonus(const int32 MissionBonusIndex);
	bool CheckShuffle();

	void CheckBingoAndBingoStartAnimationPlay(const int32 MissionButtonIndex);

	UFUNCTION()
	void OnMissionBonusButtonClicked(int32 Index);

	UFUNCTION()
	void OnMissionToggleBtnClicked(int32 Index);

	UFUNCTION()
	void OnShuffleButtonClicked();

	UFUNCTION()
	void OnMissionShuffleAnimFinished();

	UFUNCTION()
	void OnMissionCompleteStartAnimFinished(int32 Index);

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> WeeklyMissionAnims;

	UPROPERTY()
	UQ6Button* ShuffleButton;

	UPROPERTY()
	UBorder* RequiredCurrencyBorder;

	UPROPERTY()
	UBorder* FreeBorder;

	UPROPERTY()
	UPointWidget* ConsumeGoldPointWidget;

	UPROPERTY()
	TArray<UMissionButtonWidget*> MissionButtonWidgets;

	UPROPERTY()
	UMissionGaugeWidget* DescMissionGaugeWidget;

	UPROPERTY()
	UItemWidget* DescItemWidget;

	UPROPERTY()
	UTextBlock* TimeInfoText;

	UPROPERTY()
	UImage* ShuffleButtonImage;

	UPROPERTY()
	UImage* NewMarkImage;

	UPROPERTY()
	TArray<UMissionBonusButtonWidget*> MissionBonusButtonWidgets;

	TArray<TArray<EMissionBingoBoardState>> BingoBoard;

	int32 SelectedMissionButtonIndex;
	int32 RequestMissionItemIndex;
	int32 RequestBingoItemIndex;
};
