#pragma once

#include "PopupWidgets.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "WonderWidgets.h"

#include "MigriumRefineryWidgets.generated.h"

UENUM(BlueprintType)
enum class EMigriumRefineryState : uint8
{
	Empty,
	InProgress,
};

UCLASS()
class Q6_API UMigriumRefineryWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	UMigriumRefineryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	virtual void SetWonder() override;
	virtual void RefreshUI() override;

	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) override;

	UFUNCTION(BlueprintImplementableEvent)
	void MigriumRefineryState(EMigriumRefineryState State);

	UFUNCTION(BlueprintImplementableEvent)
	void MigriumRefineryResultItemState(bool bProduct, bool bMax);

	UFUNCTION(BlueprintImplementableEvent)
	void SetMigriumRefineryPorgressBar(float Value);

private:
	void Reset();

	void SetMigriumOre(const FSmelterInfo& SmelterInfo);
	void SetAmountText(const FText& Text);
	void SetMaxText(const FText& Text);
	void SetRefiningCountText(const FText& Text);

	void SetRemainTime(const FSmelterInfo& SmelterInfo);
	void SetMigriumRefineryTimer();

	void SetItemInfo(const FSmelterInfo& SmelterInfo);

	void SetNewMark(const FSmelterInfo& Info);

	UFUNCTION()
	void OnPlusButtonClicked();

	UFUNCTION()
	void OnMinusButtonClicked();

	UFUNCTION()
	void OnMinButtonClicked();

	UFUNCTION()
	void OnMaxButtonClicked();

	UFUNCTION()
	void OnGetButtonClicked();

	UFUNCTION()
	void OnItemReceivedPopupClosed();

	UPROPERTY()
	UTextBlock* Point1Text;

	UPROPERTY()
	UTextBlock* TotalTimerText;

	UPROPERTY()
	UTextBlock* AmountText;

	UPROPERTY()
	UTextBlock* MaxText;

	UPROPERTY()
	UTextBlock* RefiningCountText;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UButton* PlusButton;

	UPROPERTY()
	UButton* MinusButton;

	UPROPERTY()
	UButton* MinButton;

	UPROPERTY()
	UButton* MaxButton;

	UPROPERTY()
	UBorder* RefineryTimerBorder;

	UPROPERTY()
	UImage* StockNewMarkImage;

	bool bButtonLock;

	int32 RefiningCount;
	int32 ReceiveProductCount;

	int64 EndProgressValue;
	int64 CurrProgressValue;
	int64 TotalRemainSeconds;

	FTimerHandle TimeHandle;
};
