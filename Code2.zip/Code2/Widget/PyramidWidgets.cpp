// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "PyramidWidgets.h"

#include "BagItemManager.h"
#include "CMSTable.h"
#include "CharacterManager.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "LobbyMsg_gen.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "PyramidManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "RelicManager.h"
#include "SculptureManager.h"
#include "SystemConstHelper.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Pyramid"), STAT_OnHSEventByPyramid, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Portal Widget
//////////////////////////////////////////////////////////////////////////
void UPortalWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	StateText = CastChecked<UQ6TextBlock>(GetWidgetFromName("State"));
	RemainDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RemainDays"));
	ItemWidget = CastChecked<UItemCardWidget>(GetWidgetFromName("Item"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UPortalWidget::OnSelectButtonClicked);

	// Animations

	BuildingAnim = GetWidgetAnimationFromName(this, "AnimDefault");
	SelectedAnim = GetWidgetAnimationFromName(this, "AnimSelected");
	DeselectedAnim = GetWidgetAnimationFromName(this, "AnimUnselected");
	BuildBoostAnim = GetWidgetAnimationFromName(this, "AnimBuildBoost");
	BuiltLoopAnim = GetWidgetAnimationFromName(this, "AnimBuiltLoop");
	ConnectingAnim = GetWidgetAnimationFromName(this, "AnimConnecting");
	ConnectedLoopAnim = GetWidgetAnimationFromName(this, "AnimConnectedLoop");
}

void UPortalWidget::SetPortal(EPortalType InPortalType, int64 InConnectedType)
{
	ConnectedType = InConnectedType;

	FString NameStr = FString::Printf(TEXT("Portal%s"), *ENUM_TO_STRING(EPortalType, InPortalType));
	NameText->SetText(Q6Util::GetLocalizedText("Lobby", *NameStr));

	if (ConnectedType == 0)
	{
		int32 BuildingRemainDays = GetHUDStore().GetPyramidManager().GetBuildTimeLeftDays(InPortalType);
		if (BuildingRemainDays > 0)
		{
			// Building
			PortalState = EPortalState::Building;

			StateText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderBuilding"));
			RemainDaysText->SetText(FText::AsNumber(BuildingRemainDays));
		}
		else
		{
			// Built
			PortalState = EPortalState::Built;

			StateText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderBuilt"));
			RemainDaysText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderConnectionReady"));
		}
	}
	else
	{
		SetItem(InPortalType, ConnectedType);

		int32 ConnectingRemainDays = GetHUDStore().GetPyramidManager().GetConnectTimeLeftDays(InPortalType);
		if (ConnectingRemainDays > 0)
		{
			// Connecting

			PortalState = EPortalState::Connecting;

			StateText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderConnecting"));
			RemainDaysText->SetText(FText::AsNumber(ConnectingRemainDays));
		}
		else
		{
			// Connected

			PortalState = EPortalState::Connected;

			StateText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderConnected"));
			RemainDaysText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderWarpReady"));
		}
	}

	const FSlateBrush& PortalBrush = GetPortalBrush(InPortalType, PortalState);
	BGImage->SetBrush(PortalBrush);

	SetPortalState(PortalState);
	SetNewMark(InPortalType);
}

void UPortalWidget::SetSelected(bool bInSelected)
{
	PlayAnimation(bInSelected ? SelectedAnim : DeselectedAnim);
}

void UPortalWidget::SetPortalState(EPortalState InPortalState)
{
	PortalState = InPortalState;

	StopAllAnimations();

	switch (PortalState)
	{
		case EPortalState::Building:	 PlayAnimation(BuildingAnim);				break;
		case EPortalState::Built:		 PlayAnimation(BuiltLoopAnim, 0.f, 0);		break;
		case EPortalState::Connecting:	 PlayAnimation(ConnectingAnim);				break;
		case EPortalState::Connected:	 PlayAnimation(ConnectedLoopAnim, 0.f, 0);	break;
	}
}

void UPortalWidget::SetItem(EPortalType PortalType, int64 InConnectedType)
{
	const UHUDStore& HUDStore = GetHUDStore();
	if (PortalType == EPortalType::Character)
	{
		ItemWidget->SetDefaultCharacter(FCharacterType(InConnectedType));
	}
	else if (PortalType == EPortalType::Relic)
	{
		ItemWidget->SetDefaultRelic(FRelicType(InConnectedType));
	}
	else if (PortalType == EPortalType::Sculpture)
	{
		ItemWidget->SetDefaultSculpture(FSculptureType(InConnectedType));
	}
	else
	{
		Q6JsonLogRoze(Warning, "UPortalWidget::SetItem - Invalid connected type");
	}
}

void UPortalWidget::SetNewMark(EPortalType PortalType)
{
	ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetWonderPyramidPortalVisibility(PortalType);
	NewMarkImage->SetVisibility(NewMarkVisibility);
}

const FSlateBrush& UPortalWidget::GetPortalBrush(EPortalType InPortalType, EPortalState InPortalState)
{
	int32 BrushIndex = (int32)InPortalState;

	if (InPortalType == EPortalType::Character)
	{
		if (CharacterPortalBrushes.IsValidIndex(BrushIndex))
		{
			return CharacterPortalBrushes[BrushIndex];
		}
	}
	else if (InPortalType == EPortalType::Relic)
	{
		if (RelicPortalBrushes.IsValidIndex(BrushIndex))
		{
			return RelicPortalBrushes[BrushIndex];
		}
	}
	else if (InPortalType == EPortalType::Sculpture)
	{
		if (SculpturePortalBrushes.IsValidIndex(BrushIndex))
		{
			return SculpturePortalBrushes[BrushIndex];
		}
	}

	static FSlateBrush DummyBrush;
	return DummyBrush;
}

void UPortalWidget::OnSelectButtonClicked()
{
	OnPortalSelectedDelegate.ExecuteIfBound(ConnectedType);
}


//////////////////////////////////////////////////////////////////////////
// Portal Info Widget
//////////////////////////////////////////////////////////////////////////
void UPortalInfoWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PortalImage = CastChecked<UImage>(GetWidgetFromName("Portal"));
	EquipImage = CastChecked<UImage>(GetWidgetFromName("Equip"));
	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextName"));
	LeadDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("LeadDays"));
	PortalTitleText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextPortalTitle"));
	PortalInfoText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextPortalInfo"));
	SelectText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextSelect"));
	ConnectText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextConnect"));
	RemainDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextRemainDays"));

	UQ6Button* SelectButton = CastChecked<UQ6Button>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UPortalInfoWidget::OnSelectButtonClicked);

	UButton* PortalButton = CastChecked<UButton>(GetWidgetFromName("ButtonPortal"));
	PortalButton->OnClicked.AddUniqueDynamic(this, &UPortalInfoWidget::OnPortalButtonClicked);

	// Animations

	BuiltLoopAnim = GetWidgetAnimationFromName(this, "AnimBuiltLoop");
	ConnectAnim = GetWidgetAnimationFromName(this, "AnimConnect");
	ConnectingAnim = GetWidgetAnimationFromName(this, "AnimConnecting");
	ConnectedLoopAnim = GetWidgetAnimationFromName(this, "AnimConnectedLoop");
}

void UPortalInfoWidget::SetPortal(EPortalType InPortalType, int64 InConnectedType)
{
	PortalType = InPortalType;
	ConnectedType = InConnectedType;
	SelectedItemId = ITEM_INVALID;

	StopAllAnimations();

	CharacterImage->SetVisibility(ESlateVisibility::Collapsed);
	EquipImage->SetVisibility(ESlateVisibility::Collapsed);

	if (PortalBuiltBrushes.IsValidIndex((int32)PortalType))
	{
		PortalImage->SetBrush(PortalBuiltBrushes[(int32)PortalType]);
	}

	FString ItemStr = ENUM_TO_STRING(EPortalType, PortalType);
	PortalTitleText->SetText(Q6Util::GetLocalizedText("Lobby", *FString::Printf(TEXT("Portal%s"), *ItemStr)));

	if (ConnectedType == ITEM_INVALID)
	{
		SelectText->SetText(Q6Util::GetLocalizedText("Lobby", *FString::Printf(TEXT("Select%s"), *ItemStr)));
		PortalInfoText->SetText(Q6Util::GetLocalizedText("Lobby", *FString::Printf(TEXT("PortalBuilt%s"), *ItemStr)));
		ConnectText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderConnect"));

		PlayAnimation(BuiltLoopAnim, 0.0f, 0);
	}
	else
	{
		SetItemNameAndTexture();

		int32 ConnectRemainDays = GetHUDStore().GetPyramidManager().GetConnectTimeLeftDays(PortalType);
		if (ConnectRemainDays > 0)
		{
			RemainDaysText->SetText(FText::AsNumber(ConnectRemainDays));
			PortalInfoText->SetText(Q6Util::GetLocalizedText("Lobby", *FString::Printf(TEXT("PortalConnecting%s"), *ItemStr)));

			PlayAnimation(ConnectingAnim);
		}
		else
		{
			ConnectText->SetText(Q6Util::GetLocalizedText("Lobby", "WonderWarp"));
			PortalInfoText->SetText(Q6Util::GetLocalizedText("Lobby", *FString::Printf(TEXT("PortalWarp%s"), *ItemStr)));
			PortalImage->SetBrush(ConnectedBrush);

			PlayAnimation(ConnectedLoopAnim, 0.0f, 0);
		}
	}
}

void UPortalInfoWidget::SetItemNameAndTexture()
{
	UImage* ItemImage = nullptr;
	FText ItemName;
	TSoftObjectPtr<UTexture2D> ItemTexture;

	const UCMS* CMS = GetCMS();

	if (PortalType == EPortalType::Character)
	{
		FCharacterType CharacterType = FCharacterType(ConnectedType);
		const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterType);
		ItemName = UnitRow.DescName;

		const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
		ItemTexture = CharacterAssetRow.BodyTexture;

		ItemImage = CharacterImage;
	}
	else if (PortalType == EPortalType::Relic)
	{
		const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(FRelicType(ConnectedType));
		ItemName = RelicRow.DescName;

		const FEquipAssetRow& RelicAssetRow = GetGameResource().GetRelicAssetRow(FRelicType(ConnectedType));
		ItemTexture = RelicAssetRow.IllustTexture;

		ItemImage = EquipImage;
	}
	else if (PortalType == EPortalType::Sculpture)
	{
		const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(FSculptureType(ConnectedType));
		ItemName = SculptureRow.DescName;

		const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(FSculptureType(ConnectedType));
		ItemTexture = SculptureAssetRow.IllustTexture;

		ItemImage = EquipImage;
	}

	NameText->SetText(ItemName);
	if (ItemImage)
	{
		ItemImage->SetBrushFromSoftTextureWhenLoadingFinished(ItemTexture);
		ItemImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void UPortalInfoWidget::OnSelectButtonClicked()
{
	UItemSelectPopupWidget* PortalConnectPopup = GetCheckedLobbyHUD(this)->OpenPortalConnectItemListPopup(PortalType, true);
	PortalConnectPopup->OnItemSelectedDelegate.BindUObject(this, &UPortalInfoWidget::OnItemSelected);
}

void UPortalInfoWidget::OnPortalButtonClicked()
{
	if (SelectedItemId == ITEM_INVALID)
	{
		// Portal warp

		GetHUDStore().GetPyramidManager().ReqPortalWarp(PortalType, ConnectedType);
	}
	else
	{
		// Portal connect

		UPortalConnectConfirmPopupWidget* ConfirmPopup = CastChecked<UPortalConnectConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(PortalConnectConfirmPopupClass));
		ConfirmPopup->SetConnectItem(PortalType, SelectedItemId);
		ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UPortalInfoWidget::OnPortalConnect);
	}
}

void UPortalInfoWidget::OnItemSelected(int64 InSelectedItemId)
{
	SelectedItemId = InSelectedItemId;
	StopAllAnimations();

	if (PortalType == EPortalType::Character)
	{
		if (const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(FCharacterId(SelectedItemId)))
		{
			ConnectedType = Character->GetInfo().Type;
		}
	}
	else if (PortalType == EPortalType::Relic)
	{
		if (const FRelic* Relic = GetHUDStore().GetRelicManager().Find(FRelicId(SelectedItemId)))
		{
			ConnectedType = Relic->Info.Type;
		}
	}
	else if (PortalType == EPortalType::Sculpture)
	{
		if (const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(FSculptureId(SelectedItemId)))
		{
			ConnectedType = Sculpture->Info.Type;
		}
	}

	int32 ConnectingLeadDays = SystemConstHelper::GetPortalConnectingDays(PortalType);
	LeadDaysText->SetText(FText::AsNumber(ConnectingLeadDays));

	SetItemNameAndTexture();
	PlayAnimation(ConnectAnim);
}

void UPortalInfoWidget::OnPortalConnect(EConfirmPopupFlag Flag)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetHUDStore().GetPyramidManager().ReqPortalConnect(PortalType, FAnyId(SelectedItemId));
}


//////////////////////////////////////////////////////////////////////////
// Portal Build Boost Widget
//////////////////////////////////////////////////////////////////////////
void UPortalBuildBoostWidget::NativeConstruct()
{
	Super::NativeConstruct();

	NameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Name"));
	PortalInfoText = CastChecked<UQ6TextBlock>(GetWidgetFromName("PortalInfo"));
	ItemListText = CastChecked<UQ6TextBlock>(GetWidgetFromName("TextItemList"));
	RemainDaysText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RemainDays"));
	BoostRemainCountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("BoostRemainCount"));

	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));

	OwnedPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPoint"));
	OwnedPointWidget->SetPointType(ECurrencyType::Gold, EPointWidgetOption::NONE);

	RequirePointWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequirePoint"));
	RequirePointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::CompLessThan);

	BoostButton = CastChecked<UButton>(GetWidgetFromName("Boost"));
	BoostButton->OnClicked.AddUniqueDynamic(this, &UPortalBuildBoostWidget::OnBoostButtonClicked);

	UButton* ItemListButton = CastChecked<UButton>(GetWidgetFromName("ItemList"));
	ItemListButton->OnClicked.AddUniqueDynamic(this, &UPortalBuildBoostWidget::OnItemListButtonClicked);

	// Animations

	DefaultAnim = GetWidgetAnimationFromName(this, "AnimDefault");
	DailyBuildBoostUsedAnim = GetWidgetAnimationFromName(this, "AnimBuildBoostUsed");
	BuildBoostMaxAnim = GetWidgetAnimationFromName(this, "AnimBuildBoostMax");
}

void UPortalBuildBoostWidget::SetBuildBoost(EPortalType InPortalType)
{
	PortalType = InPortalType;

	FString NameStr = FString::Printf(TEXT("Portal%s"), *ENUM_TO_STRING(EPortalType, PortalType));
	NameText->SetText(Q6Util::GetLocalizedText("Lobby", *NameStr));

	FString PortalInfoStr = NameStr.Append(TEXT("Info"));
	PortalInfoText->SetText(Q6Util::GetLocalizedText("Lobby", *PortalInfoStr));

	FString ItemListStr = FString::Printf(TEXT("%sConfirm"), *ENUM_TO_STRING(EPortalType, PortalType));
	ItemListText->SetText(Q6Util::GetLocalizedText("Lobby", *ItemListStr));

	const UCMS* CMS = GetCMS();
	const UPyramidManager& PyramidMgr = GetHUDStore().GetPyramidManager();
	int32 RemainDays, TotalRemainBoostCount, DailyRemainBoostCount;

	RemainDays = PyramidMgr.GetBuildTimeLeftDays(PortalType);
	RemainDaysText->SetText(FText::AsNumber(RemainDays));

	TotalRemainBoostCount = FMath::Max(SystemConstHelper::GetMaxBoostCount(PortalType) - PyramidMgr.GetTotalBoostUsed(PortalType), 0);
	DailyRemainBoostCount = FMath::Max(SystemConstHelper::GetDailyBoostCount(PortalType) - PyramidMgr.GetDailyBoostUsed(PortalType), 0);

	BoostRemainCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "NCount"), FText::AsNumber(TotalRemainBoostCount)));

	if ((TotalRemainBoostCount > 0) && (DailyRemainBoostCount > 0))
	{
		// Set for using build boost

		if (const FCMSWonderCostRow* CostRow = CMS->GetPortalBoostCost(PortalType))
		{
			int32 PyramidLevel = PyramidMgr.GetLevel();
			int32 MaterialReduceCount = SystemConstHelper::GetPortalBoostMaterialReduceCount(PyramidLevel);

			MaterialsWidget->SetMaterials(CostRow->GetBagItem(), CostRow->ItemCount, MaterialReduceCount);

			int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
			OwnedPointWidget->SetCurPoint(OwnedGold);

			int32 RequireGold = FMath::Max(CostRow->Gold - SystemConstHelper::GetPortalBoostGoldReduceCost(PyramidLevel), 0);
			RequirePointWidget->SetPoint(RequireGold, OwnedGold);

			bool bIsEnoughMaterial = GetHUDStore().GetBagItemManager().HasEnoughBagItem(CostRow->GetBagItem(), CostRow->ItemCount);
			BoostButton->SetIsEnabled((OwnedGold >= RequireGold) && bIsEnoughMaterial);
		}
	}

	PlayBuildBoostAnimation(TotalRemainBoostCount, DailyRemainBoostCount);
}

void UPortalBuildBoostWidget::PlayBuildBoostAnimation(int32 TotalRemainBoostCount, int32 DailyRemainBoostCount)
{
	StopAllAnimations();

	if (TotalRemainBoostCount <= 0)
	{
		PlayAnimation(BuildBoostMaxAnim);
		return;
	}

	if (DailyRemainBoostCount <= 0)
	{
		PlayAnimation(DailyBuildBoostUsedAnim);
		return;
	}

	PlayAnimation(DefaultAnim);
}

void UPortalBuildBoostWidget::OnBoostButtonClicked()
{
	UBoostConfirmPopupWidget* BuildBoostConfirmPopup = CastChecked<UBoostConfirmPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(BuildBoostConfirmPopupClass));
	BuildBoostConfirmPopup->SetPortal(PortalType);
}

void UPortalBuildBoostWidget::OnItemListButtonClicked()
{
	GetCheckedLobbyHUD(this)->OpenPortalConnectItemListPopup(PortalType, false);
}

//////////////////////////////////////////////////////////////////////////
// Pyramid Widget
//////////////////////////////////////////////////////////////////////////
void UPyramidWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UPortalWidget* PortalWidget;
	PortalWidgets.Reset();
	for (int32 n = 1; n < EPortalTypeMax; ++n)
	{
		PortalWidget = CastChecked<UPortalWidget>(GetWidgetFromName(*ENUM_TO_STRING(EPortalType, n)));
		PortalWidget->OnPortalSelectedDelegate.BindUObject(this, &UPyramidWidget::OnPortalSelected, (EPortalType)n);
		PortalWidgets.Add(PortalWidget);
	}

	PortalMenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("PortalMenu"));

	BoostWidget = CastChecked<UPortalBuildBoostWidget>(GetWidgetFromName("Boost"));
	InfoWidget = CastChecked<UPortalInfoWidget>(GetWidgetFromName("Info"));
}

void UPyramidWidget::SetWonder()
{
	SelectedPortalIndex = GetHUDStore().GetUIStateManager().GetWonderUIState().SelectedSlot - 1;

	const UPyramidManager& PyramidMgr = GetHUDStore().GetPyramidManager();
	const FPyramidInfo& PyramidInfo = PyramidMgr.GetPyramid();
	for (int32 n = 1; n < EPortalTypeMax; ++n)
	{
		EPortalType PortalType = EPortalType(n);
		int32 ConnectedType = PyramidMgr.GetPortalConnectedType(PortalType);
		SetPortal(PortalType, ConnectedType);

		if (SelectedPortalIndex == (n - 1))
		{
			OnPortalSelected(ConnectedType, PortalType);
		}
	}
}

void UPyramidWidget::RefreshUI()
{
	for (int32 n = 1; n < EPortalTypeMax; ++n)
	{
		EPortalType PortalType = EPortalType(n);
		int32 ConnectedType = GetHUDStore().GetPyramidManager().GetPortalConnectedType(PortalType);
		SetPortal(PortalType, ConnectedType);

		if ((n - 1) == SelectedPortalIndex)
		{
			SetSelectedPortalDetail(PortalType, ConnectedType);
		}
	}
}

void UPyramidWidget::OnMenuEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByPyramid);

	if (InAction->GetActionType() == EHSActionType::PyramidPortalWarpResp)
	{
		auto Action = ACTION_PARSE_PyramidPortalWarpResp(InAction);
		const FL2CPyramidPortalWarpResp& Resp = Action->GetVal();

		UPortalConnectedResultPopupWidget* ResultPopup = CastChecked<UPortalConnectedResultPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(PortalConnectedResultPopupClass));
		ResultPopup->SetResult(Resp.SpecialRecord);

		SetWonder();
		return;
	}

	if ((InAction->GetActionType() == EHSActionType::PyramidPortalBoostUseResp)
		|| (InAction->GetActionType() == EHSActionType::DevPyramidPortalBoostUseResp))
	{
		SetPortalBoostUse((EPortalType)(SelectedPortalIndex + 1));
		return;
	}

	if ((InAction->GetActionType() == EHSActionType::PyramidPortalConnectResp)
		|| (InAction->GetActionType() == EHSActionType::DevPyramidPortalClearResp))
	{
		SetWonder();
		return;
	}
}

void UPyramidWidget::SetPortalBoostUse(EPortalType PortalType)
{
	UPortalWidget* PortalWidget = GetCheckedPortalWidget(PortalType);
	PortalWidget->SetPortal(PortalType, 0);
	PortalWidget->PlayBoostAnimation();

	OnPortalSelected(0, PortalType);
}

void UPyramidWidget::SetPortal(EPortalType PortalType, int32 ConnectedType)
{
	UPortalWidget* PortalWidget = GetCheckedPortalWidget(PortalType);
	PortalWidget->SetPortal(PortalType, ConnectedType);
}

void UPyramidWidget::SelectPortal(int32 InSelectedIdx)
{
	for (UPortalWidget* PortalWidget : PortalWidgets)
	{
		PortalWidget->SetSelected(PortalWidgets.IndexOfByKey(PortalWidget) == InSelectedIdx);
	}
}

void UPyramidWidget::SetSelectedPortalDetail(EPortalType PortalType, int64 ConnectedType)
{
	int32 BuildingDays = GetHUDStore().GetPyramidManager().GetBuildTimeLeftDays(PortalType);
	if ((BuildingDays <= 0) || (ConnectedType > 0))
	{
		PortalMenuSwitcher->SetActiveWidget(InfoWidget);
		InfoWidget->SetPortal(PortalType, ConnectedType);
	}
	else
	{
		PortalMenuSwitcher->SetActiveWidget(BoostWidget);
		BoostWidget->SetBuildBoost(PortalType);
	}
}

UPortalWidget* UPyramidWidget::GetCheckedPortalWidget(EPortalType PortalType)
{
	if (PortalWidgets.IsValidIndex((int32)PortalType - 1))
	{
		return PortalWidgets[(int32)PortalType - 1];
	}

	check(false);
	return nullptr;
}

void UPyramidWidget::OnPortalSelected(int64 ConnectedType, EPortalType PortalType)
{
	ACTION_DISPATCH_WonderSlotSelect((int32)PortalType);

	SelectedPortalIndex = (int32)PortalType - 1;

	for (int32 i = 0; i < PortalWidgets.Num(); ++i)
	{
		PortalWidgets[i]->SetSelected(i == SelectedPortalIndex);
	}

	SetSelectedPortalDetail(PortalType, ConnectedType);
}
