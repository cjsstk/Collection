// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "SortingWidgets.h"

#include "CommonWidgets.h"
#include "GameResource.h"
#include "LobbyHUD.h"
#include "UIStateManager.h"

FText GetSortOrderTypeText(ESortOrderType OrderType)
{
	const char* Key = "";
	switch (OrderType)
	{
		case ESortOrderType::LastLogin: Key = "LastLogin"; break;
		case ESortOrderType::FriendLevel: Key = "FriendLevel"; break;
		case ESortOrderType::Level: Key = "Lv"; break;
		case ESortOrderType::Hp: Key = "HP"; break;
		case ESortOrderType::Atk: Key = "ATK"; break;
		case ESortOrderType::Def: Key = "DEF"; break;
		case ESortOrderType::Nature: Key = "Nature"; break;
		case ESortOrderType::UltimateSkill: Key = "UltimateSkill"; break;
		case ESortOrderType::Grade: Key = "Grade"; break;
		case ESortOrderType::Name: Key = "Name"; break;
		case ESortOrderType::Created: Key = "Created"; break;
		default: check(false);
	}

	return Q6Util::GetLocalizedText("Popup", Key);
}

void FSortOrdering::SetTotalAttributes(const TArray<const FFriendInfoEx*>& FriendList, int32 JokerSlotIndex)
{
	UCMS* CMS = GetCMS();
	for (const FFriendInfoEx* FriendInfo : FriendList)
	{
		SetTotalAttributes(CMS, *FriendInfo, JokerSlotIndex);
	}
}

void FSortOrdering::SetTotalAttributes(UCMS* CMS, const FFriendInfoEx& FriendInfo, int32 JokerSlotIndex)
{
	const FFriendJokerSlot& JokerSlot = FriendInfo.JokerSet.Slots[JokerSlotIndex];

	int32& TotalHp = FriendInfo.Hp;
	int32& TotalAtk = FriendInfo.Atk;
	int32& TotalDef = FriendInfo.Def;

	TotalHp = TotalAtk = TotalDef = 0;

	const FCharacterInfo& JokerInfo = JokerSlot.CharacterInfo;
	if (JokerInfo.Type != CharacterTypeInvalid)
	{
		{
			int64 Hp = 0, Atk = 0, Def = 0;
			Attribute::GetUnitAttribute(CMS, EAttributeCategory::Character, CMS->GetUnitType(JokerInfo.Type),
				JokerInfo.Level, JokerInfo.Grade, nullptr, Hp, Atk, Def);

			TotalHp += Hp;
			TotalAtk += Atk;
			TotalDef += Def;
		}

		const FRelicInfo& JokerRelicInfo = JokerSlot.RelicInfo;
		if (JokerRelicInfo.Type != RelicTypeInvalid)
		{
			int64 Hp = 0, Atk = 0, Def = 0;
			Attribute::GetRelicAttribute(CMS, JokerRelicInfo.Type,
				JokerRelicInfo.Level, JokerRelicInfo.Tier, JokerRelicInfo.Grade, Hp, Atk, Def);
			TotalHp += Hp;
			TotalAtk += Atk;
			TotalDef += Def;
		}

		const FSculptureInfo& JokerSculptureInfo = JokerSlot.SculptureInfo;
		if (JokerSculptureInfo.Type != SculptureTypeInvalid)
		{
			int64 Hp = 0, Atk = 0, Def = 0;
			Attribute::GetSculptureAttribute(CMS, JokerSculptureInfo.Type,
				JokerSculptureInfo.Level, JokerSculptureInfo.Tier, JokerSculptureInfo.Grade, Hp, Atk, Def);
			TotalHp += Hp;
			TotalAtk += Atk;
			TotalDef += Def;
		}
	}
}

void FSortOrdering::SetCharacterAttributes(const TArray<const FCharacter*>& CharacterList)
{
	UCMS* CMS = GetCMS();
	for (const FCharacter* Character : CharacterList)
	{
		check(Character);

		const FCharacterInfo& Info = Character->GetInfo();
		Attribute::GetCharacterAttribute(CMS, Info, Character->Hp, Character->Atk, Character->Def);
	}
}

void FSortOrdering::SetSculptureAttributes(const TArray<const FSculpture*>& SculptureList)
{
	UCMS* CMS = GetCMS();
	for (const FSculpture* Sculpture : SculptureList)
	{
		check(Sculpture);

		const FSculptureInfo& Info = Sculpture->Info;
		Attribute::GetSculptureAttribute(CMS, Info.Type, Info.Level, Info.Tier, Info.Grade, Sculpture->Hp, Sculpture->Atk, Sculpture->Def);
	}
}

void FSortOrdering::SetRelicAttributes(const TArray<const FRelic*>& RelicList)
{
	UCMS* CMS = GetCMS();
	for (const FRelic* Relic : RelicList)
	{
		check(Relic);

		const FRelicInfo& Info = Relic->Info;
		Attribute::GetRelicAttribute(CMS, Info.Type, Info.Level, Info.Tier, Info.Grade, Relic->Hp, Relic->Atk, Relic->Def);
	}
}

// class USortingOrderButtonWidget
void USortingWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Filter

	FilterBox = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxFilter"));

	FilterIcons.Reset();
	for (int32 n = 1; n <= MaxFilterCount; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("FilterIcon%d"), n);
		UImage* FilterIcon = CastChecked<UImage>(GetWidgetFromName(*WidgetName));
		FilterIcons.AddUnique(FilterIcon);
	}

	// Sort

	OrderTypeText = CastChecked<UTextBlock>(GetWidgetFromName("TextOrderType"));

	UButton* SortingOrderButton = CastChecked<UButton>(GetWidgetFromName("SortingOrder"));
	SortingOrderButton->OnClicked.AddUniqueDynamic(this, &USortingWidget::OnSortingChangeButtonClicked);

	// Order

	DirectionText = CastChecked<UTextBlock>(GetWidgetFromName("OrderName"));
	SortDirectionButton = CastChecked<UCheckBox>(GetWidgetFromName("OrderToggle"));
	SortDirectionButton->OnCheckStateChanged.AddUniqueDynamic(this, &USortingWidget::OnOrderToggleButtonClicked);
}

void USortingWidget::SetSorting(ESortMenu InSortMenu, ESortCategory InCategory)
{
	SortMenu = InSortMenu;
	Category = InCategory;

	const FSortingOption& SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, Category);
	const FSortingGroup& SortingGroup = GetUIResource().GetSortingGroup(SortingOption.Category);

	// Set filters

	if (SortingGroup.FilterType != ESortFilterType::Invalid)
	{
		FilterBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const TArray<FSlateBrush>& IconBrushes = SortingGroup.FilterType == ESortFilterType::Nature ? NatureDotIconBrushes : TierDotIconBrushes;
		for (int32 i = 0; i < FilterIcons.Num(); ++i)
		{
			int32 OptionValue = SortingGroup.FilterType == ESortFilterType::Nature ? i : i + 1;
			if (SortingOption.FilterOptions.Contains(OptionValue))
			{
				FilterIcons[i]->SetBrush(IconBrushes[i]);
				FilterIcons[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			}
			else
			{
				FilterIcons[i]->SetVisibility(ESlateVisibility::Collapsed);
			}
		}
	}
	else
	{
		FilterBox->SetVisibility(ESlateVisibility::Collapsed);
	}

	SortDirectionButton->SetIsChecked((int32)SortingOption.Direction != 0);
	SetSortOrderTypeText(SortingOption.OrderType);
	SetSortDirectionText(SortingOption.OrderType, SortingOption.Direction);
}

void USortingWidget::SetSortOrderTypeText(ESortOrderType OrderType)
{
	FText Text = GetSortOrderTypeText(OrderType);
	OrderTypeText->SetText(Text);
}

void USortingWidget::SetSortDirectionText(ESortOrderType OrderType, ESortDirection Direction)
{
	if (OrderType == ESortOrderType::LastLogin || OrderType == ESortOrderType::Created)
	{
		DirectionText->SetText(Q6Util::GetLocalizedText("Lobby", Direction == ESortDirection::Ascending ? "OrderNew" : "OrderOldest"));
	}
	else
	{
		DirectionText->SetText(Q6Util::GetLocalizedText("Lobby", Direction == ESortDirection::Ascending ? "OrderAscending" : "OrderDescending"));
	}
}

void USortingWidget::OnSortingChangeButtonClicked()
{
	GetCheckedLobbyHUD(this)->OpenSortingChangePopup(SortMenu, Category);
}

void USortingWidget::OnOrderToggleButtonClicked(bool bInChecked)
{
	FSortingOption SortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(SortMenu, Category);
	SortingOption.Direction = SortingOption.Direction == ESortDirection::Ascending ? ESortDirection::Descending : ESortDirection::Ascending;
	
	ACTION_DISPATCH_SortingChange(SortingOption);
}

// class USortingOrderPopupWidget

void USortingChangePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* ResetButton = CastChecked<UButton>(GetWidgetFromName("Reset"));
	ResetButton->OnClicked.AddUniqueDynamic(this, &USortingChangePopupWidget::OnResetButtonClicked);

	OrderListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("OrderList"));
	FilterListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("FilterList"));

	XpCardButtonWidget = CastChecked<UToggleButtonWidget>(GetWidgetFromName("XpCardToggle"));

	FilterPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("PanelFilter"));
	ExpCardPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("PanelExpCard"));
}

void USortingChangePopupWidget::SetSortingOption(ESortMenu InSortMenu, ESortCategory InCategory)
{
	const FSortingOption& NewSortingOption = GetHUDStore().GetUIStateManager().GetSortingOption(InSortMenu, InCategory);

	RefreshSortingOption(NewSortingOption);
}

void USortingChangePopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	if (Option == EConfirmPopupFlag::Yes)
	{
		if (GetHUDStore().GetUIStateManager().IsChangedSortingOption(SortingOption))
		{
			ACTION_DISPATCH_SortingChange(SortingOption);
		}
	}

	Super::OnConfirmButtonClicked(Option);
}

void USortingChangePopupWidget::OnResetButtonClicked()
{
	const FSortingOption& DefaultSortingOption = GetUIResource().GetDefaultSortingSelectedOption(SortingOption.SortMenu, SortingOption.Category);
	ACTION_DISPATCH_SortingChange(DefaultSortingOption);

	RefreshSortingOption(DefaultSortingOption);
}

void USortingChangePopupWidget::OnOrderButtonClicked(ESortOrderType OrderType, UToggleButtonWidget* ButtonWidget)
{
	SortingOption.OrderType = OrderType;

	// Toggle order type

	for (int32 i = 0; i < OrderListWidget->GetChildrenCount(); ++i)
	{
		UToggleButtonWidget* FoundButtonWidget = CastChecked<UToggleButtonWidget>(OrderListWidget->FindChildAt(i));
		FoundButtonWidget->SetChecked(FoundButtonWidget == ButtonWidget);
	}
}

void USortingChangePopupWidget::OnFilterButtonClicked(int32 OptionValue)
{
	const FSortingGroup& SortingGroup = GetUIResource().GetSortingGroup(SortingOption.Category);
	if (SortingOption.FilterOptions.Contains(OptionValue))
	{
		SortingOption.FilterOptions.Remove(OptionValue);
		return;
	}

	SortingOption.FilterOptions.AddUnique(OptionValue);
}

void USortingChangePopupWidget::OnXpCardToggleButtonClicked()
{
	SortingOption.bXpCardFilter = !SortingOption.bXpCardFilter;
}

void USortingChangePopupWidget::RefreshSortingOption(const FSortingOption& NewSortingOption)
{
	SortingOption = NewSortingOption;

	SetTitle(Q6Util::GetLocalizedText("Popup", "SortingTitle"));

	XpCardButtonWidget->SetChecked(NewSortingOption.bXpCardFilter);

	// Set order options

	const FSortingGroup& SortingGroup = GetUIResource().GetSortingGroup(SortingOption.Category);
	OrderListWidget->ClearList();

	for (const ESortOrderType& OrderType : SortingGroup.OrderTypes)
	{
		UToggleButtonWidget* ButtonWidget = CastChecked<UToggleButtonWidget>(OrderListWidget->AddChildAtLastIndex());
		ButtonWidget->SetButtonName(GetSortOrderTypeText(OrderType));
		ButtonWidget->SetChecked(NewSortingOption.OrderType == OrderType);
		ButtonWidget->OnToggleButtonClickedDelegate.BindUObject(this, &USortingChangePopupWidget::OnOrderButtonClicked, OrderType, ButtonWidget);
	}

	// Set filter options

	if (SortingGroup.FilterType != ESortFilterType::Invalid)
	{
		FilterPanel->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const TArray<FCheckBoxStyle>& FilterStyles = SortingGroup.FilterType == ESortFilterType::Nature ? NatureFilterStyles : TierFilterStyles;

		FilterListWidget->ClearList();
		for (int32 i = 0; i < FilterStyles.Num(); ++i)
		{
			int32 OptionValue = SortingGroup.FilterType == ESortFilterType::Nature ? i : i + 1;

			UNatureButtonWidget* ButtonWidget = CastChecked<UNatureButtonWidget>(FilterListWidget->AddChildAtLastIndex());
			ButtonWidget->SetStyle(FilterStyles[i]);
			ButtonWidget->SetChecked(SortingOption.FilterOptions.Contains(OptionValue));
			ButtonWidget->OnToggleButtonClickedDelegate.BindUObject(this, &USortingChangePopupWidget::OnFilterButtonClicked, OptionValue);
		}
	}
	else
	{
		FilterPanel->SetVisibility(ESlateVisibility::Collapsed);
	}

	if (SortingGroup.bXpCardFilter)
	{
		ExpCardPanel->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		XpCardButtonWidget->SetChecked(NewSortingOption.bXpCardFilter);
		XpCardButtonWidget->OnToggleButtonClickedDelegate.BindUObject(this, &USortingChangePopupWidget::OnXpCardToggleButtonClicked);
	}
	else
	{
		ExpCardPanel->SetVisibility(ESlateVisibility::Collapsed);
	}
}
