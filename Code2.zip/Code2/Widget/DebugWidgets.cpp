// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "DebugWidgets.h"
#include "Q6.h"
#include "CombatCube.h"
#include "Q6CombatGameMode.h"

UDebugCombatWidget::UDebugCombatWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{}

void UDebugCombatWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* KillButton = CastChecked<UButton>(GetWidgetFromName("Kill"));
	if (KillButton)
	{
		KillButton->OnClicked.AddUniqueDynamic(this, &UDebugCombatWidget::OnKillClicked);
	}

	UButton* RebirthButton = CastChecked<UButton>(GetWidgetFromName("Rebirth"));
	if (RebirthButton)
	{
		RebirthButton->OnClicked.AddUniqueDynamic(this, &UDebugCombatWidget::OnRebirthClicked);
	}

	CombatPresenterText = CastChecked<UTextBlock>(GetWidgetFromName("CombatPresenter"));

	UButton* Select1Button = Cast<UButton>(GetWidgetFromName("Select1"));
	if (Select1Button)
	{
		Select1Button->OnClicked.AddUniqueDynamic(this, &UDebugCombatWidget::OnSelectAlly1);
	}

	UButton* Select2Button = Cast<UButton>(GetWidgetFromName("Select2"));
	if (Select2Button)
	{
		Select2Button->OnClicked.AddUniqueDynamic(this, &UDebugCombatWidget::OnSelectAlly2);
	}

	UButton* Select3Button = Cast<UButton>(GetWidgetFromName("Select3"));
	if (Select3Button)
	{
		Select3Button->OnClicked.AddUniqueDynamic(this, &UDebugCombatWidget::OnSelectAlly3);
	}

	ACombatCube* CombatCube = GetCombatCube();
	if (CombatCube)
	{
		CombatCube->GetStore()->ReqCCState(
			CCUnitIdInvalid, FOnCCStateGot::CreateLambda(
				[this](FCCUnitId ReqUnitId, FCombatState RepState) {

			if (!RepState.GameFlags.IsValidIndex((int32)EGameFlags::NoDamage)
				|| !RepState.GameFlags.IsValidIndex((int32)EGameFlags::Immune))
			{
				SetNoDamageState(0);
				SetImmuneState(0);
				return;
			}

			SetNoDamageState(RepState.GameFlags[(int32)EGameFlags::NoDamage]);
			SetImmuneState(RepState.GameFlags[(int32)EGameFlags::Immune]);
		}));
	}
}

ACombatCube* UDebugCombatWidget::GetCombatCube()
{
	const AQ6CombatGameMode* CombatGameMode = Cast<AQ6CombatGameMode>(GetWorld()->GetAuthGameMode());
	return CombatGameMode ? CombatGameMode->CombatCube : nullptr;
}

void UDebugCombatWidget::OnKillClicked()
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->KillTargetUnit();
}

void UDebugCombatWidget::OnRebirthClicked()
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->RebirthTargetUnit();
}

void UDebugCombatWidget::OnTargetSelected()
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->GetTargetCCUnitState(this);
}

void UDebugCombatWidget::SetCombatPresenterStateText(FText DebugText)
{
	CombatPresenterText->SetText(DebugText);
}

void UDebugCombatWidget::CheatTargetUnitAttribute(EUnitAttribute InUnitAttribute, bool bCheat, int32 InValue)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	if (bCheat)
	{
		CombatCube->SetTargetUnitAttributeCheatValue(InUnitAttribute, InValue);
	}
	else
	{
		CombatCube->RevertTargetUnitAttributeCheatValue(InUnitAttribute);
	}
}

void UDebugCombatWidget::CheatUA(int32 InUA)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->CheatUA(InUA);
}

void UDebugCombatWidget::CheatSA(int32 InSA)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->CheatSA(InSA);
}

void UDebugCombatWidget::CheatHealth(int32 InHealth)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->CheatHealth(InHealth);
}

void UDebugCombatWidget::CheatOverKill(int32 InOverKill)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->CheatOverKill(InOverKill);
}

void UDebugCombatWidget::CheatBuff(int32 InBuffType, bool bInUltimate, int32 InDuration)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->CheatBuff(InBuffType, bInUltimate, InDuration);
}

void UDebugCombatWidget::ResetCooldown(int32 InSkillId)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->CheatResetCooldown(InSkillId);
}

void UDebugCombatWidget::CheatReplaceUnit(int32 InUnitType)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->CheatReplaceUnit(InUnitType);
}

void UDebugCombatWidget::ToggleNoDamage()
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->ToggleNoDamage(this);
}

void UDebugCombatWidget::ToggleImmune()
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->ToggleImmune(this);
}

void UDebugCombatWidget::KillAllEnemies()
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->KillAllEnemies();
}

int32 UDebugCombatWidget::GetTargetUnitAttribute(EUnitAttribute InUnitAttribute)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return 0;
	}

	return TargetInfoFromServer.GetAttributeValue(InUnitAttribute);
}

FText UDebugCombatWidget::GetSkillName(int32 SkillType)
{
	const UCMS* CMS = GetCMS();
	const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillType);

	if (SkillRow.IsInvalid())
	{
		return FText();
	}

	return SkillRow.DescName;
}

void UDebugCombatWidget::SelectAlly(int32 SlotNum)
{
	ACombatCube* CombatCube = GetCombatCube();
	if (!CombatCube)
	{
		return;
	}

	CombatCube->GetStore()->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda(
			[this, SlotNum, CombatCube](FCCUnitId ReqUnitId, FCombatState RepState) {
		TArray<int32> Allies = RepState.AllyIds;
		if (!Allies.IsValidIndex(SlotNum - 1)) {
			return;
		}

		CombatCube->SelectTarget(FCCUnitId(Allies[SlotNum - 1]));
	}));
}

void UDebugCombatWidget::OnSelectAlly1()
{
	SelectAlly(1);
}

void UDebugCombatWidget::OnSelectAlly2()
{
	SelectAlly(2);
}

void UDebugCombatWidget::OnSelectAlly3()
{
	SelectAlly(3);
}