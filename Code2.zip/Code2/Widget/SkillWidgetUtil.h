// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CharacterWidgets.h"
#include "CMS_gen.h"
#include "Q6Log.h"

static FORCEINLINE void SetUnitSkillToWidget(const FSkillAssetRow& SkillAssetRow, const FCharacterInfo& CharacterInfo, int32 SupportSkillLevel, USkillIconWidget* UltimateWidget, USkillIconWidget* SupportWidget, TArray<UTurnSkillIconWidget*>* TurnWidgets)
{
	if (UltimateWidget)
	{
		UltimateWidget->SetSkill(SkillAssetRow.UltimateIcon, CharacterInfo.UltimateSkillLevel);
	}

	if (SupportWidget)
	{
		SupportWidget->SetSkill(SkillAssetRow.SupportIcon, SupportSkillLevel);
	}

	if (TurnWidgets)
	{
		TArray<int32> TurnSkillLevels;
		TurnSkillLevels.Add(CharacterInfo.TurnSkill1Level);
		TurnSkillLevels.Add(CharacterInfo.TurnSkill2Level);
		TurnSkillLevels.Add(CharacterInfo.TurnSkill3Level);

		for (int32 i = 0; i < SkillAssetRow.TurnSkillIcons.Num(); ++i)
		{
			if ((*TurnWidgets).IsValidIndex(i))
			{
				UTurnSkillIconWidget* TurnSkillIconWidget = (*TurnWidgets)[i];
				check(TurnSkillIconWidget);

				TurnSkillIconWidget->SetSkill(SkillAssetRow.TurnSkillIcons[i], TurnSkillLevels[i]);
			}
			else
			{
				Q6JsonLogRoze(Warning, "[Ask to @tansan] Turnskill too many", Q6KV("CharacterType", CharacterInfo.Type), Q6KV("TurnSkillIndex", i));
			}
		}
	}
}
