// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMSType_gen.h"
#include "LobbyHUDWidget.h"
#include "LobbyObj_gen.h"
#include "Q6LobbyState.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "PopupWidgets.h"
#include "UMG.h"

#include "PartyWidgets.generated.h"

class UItemDetailWidget;
class UDynamicListWidget;
class UItemCardWidget;
class UItemCardWidget;
class UPageSwipeWidget;
class UPartyEquipIconWidget;
class UPartyIconWidget;
class UPartyPageWidget;
class UPartyPetSelectPopupWidget;
class UPetIconWidget;
class UPointButtonWidget;
class UQ6Button;
class UQ6RichTextBlock;
class UQuickMenuButtonWidget;
class USortingWidget;
class UStatWidget;
class UPageSwipeWidget;
class UToggleButtonBoxWidget;
class UTurnSkillDescWidget;

struct FCharacter;
struct FRelic;
struct FSculpture; 

struct FCCCombatSeedUnit;
struct FCharacterInfo;
struct FItemIconInfo;

struct FJokerSetEx : FJokerSet
{
	TArray<FCharacterType> Types;
};

DECLARE_DELEGATE_OneParam(FPartyIconClickedDelegate, UPartyIconWidget*);
DECLARE_DELEGATE_OneParam(FPartyEquipIconSelectedDelegate, UPartyEquipIconWidget*);

UCLASS()
class Q6_API URegularRaidMatchTimerWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	URegularRaidMatchTimerWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetRegularRaidMatchTimerInfo(const int32 InRemainSeconds);

private:
	void SetRegularRaidMatchTimer();

	UPROPERTY()
	UTextBlock* RegularRaidTimerText;

	FTimerHandle TimeHandle;
	int32 RemainSeconds;
};

UCLASS()
class Q6_API UPartyEquipIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UPartyEquipIconWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetEmpty(bool bInEnabled);
	void SetRelic(const FRelicInfo& RelicInfo);
	void SetSculpture(const FSculptureInfo& SculptureInfo);

	void SetSelected(EIconSelectType SelectType);
	void PlayEquipAnimation(bool bInEquipped);

	const int64& GetItemId() const { return ItemInfo.Id; }
	EAttributeCategory GetAttributeType() const { return ItemInfo.AttributeType; }
	bool IsSelectEnabled() const { return bSelectEnabled; }

	const FItemIconInfo& GetItemInfo() const { return ItemInfo; }

	FPartyEquipIconSelectedDelegate OnEquipIconClickedDelegate;
	void OpenEquipDetail();

private:
	UFUNCTION()
	void OnSelectButtonClicked();

	// Widgets

	UPROPERTY()
	UImage* IconImage;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* NormalAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EmptyAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DisabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EquippedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UnequippedAnim;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> SelectAnims;

	FItemIconInfo ItemInfo;
	bool bSelectEnabled;
};


UCLASS()
class Q6_API UPartyIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UPartyIconWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void ResetPartyIcon(EPartyWidgetType InWidgetType, int32 InSlotIdx, bool bInViewOnly, bool bInIsOpenedByMultiside);
	void SetItem(EPartyIconItemType InItemType, int64 InItemId);
	void SetFriendJokerSlot(const FFriendJokerSlot& InJokerSlot);

	void SetPartySlot(const FPartySlot& PartySlot);
	void SetPartyJoker(const FJokerSlot& InJokerSlot);

	void SetCharacter(const FCharacterInfo& InCharacterInfo, const FCharacterBond& CharacterBond);
	void SetCharacterLockedSlotInfo(const int32 SlotIdx);
	void SetCharacterById(const FCharacterId& InCharacterId);

	void SetSculpture(const FSculptureInfo& SculptureInfo);
	void SetSculptureById(const FSculptureId& InSculptureId);

	void SetRelic(const FRelicInfo& RelicInfo);
	void SetRelicById(const FRelicId& InRelicId);

	void SetCharacterEmpty();
	void SetCharacterRandom();
	void SetSculptureEmpty();
	void SetRelicEmpty();

	void SetSelected(EPartyIconItemType ItemType, EIconSelectType SelectType);

	void SetHighlight(EPartyIconItemType ItemType);

	void PlayEquipAnimation(EPartyIconItemType ItemType, bool bInEquipped);

	UPartyEquipIconWidget* GetSculptureIconWidget() const { return SculptureIconWidget; }
	UPartyEquipIconWidget* GetRelicIconWidget() const { return RelicIconWidget; }
	UPartyEquipIconWidget* GetEquipIconWidget(EPartyIconItemType ItemType) const;

	bool IsEmpty() const { return GetCharacterId().IsInvalid(); }
	FCharacterId GetCharacterId() const { return FCharacterId(ItemInfo.Id); }
	FCharacterType GetCharacterType() const { return FCharacterType(ItemInfo.Type); }
	FSculptureId GetSculptureId() const { return FSculptureId(SculptureIconWidget->GetItemId()); }
	FRelicId GetRelicId() const { return FRelicId(RelicIconWidget->GetItemId()); }
	int64 GetItemId(EPartyIconItemType InItemType) const;
	EJokerSlotType GetJokerSlotType() const { return JokerSlot; }
	EJokerSlotType GetSwapSlotType() const { return SwapSlot; }
	bool IsSwapable(EJokerSlotType InJokerSlot) const { return IsEmpty() || SwapSlot == InJokerSlot; }

	const FItemIconInfo& GetCharacterInfo() const { return ItemInfo; }
	const FItemIconInfo& GetSculptureInfo() const { return SculptureIconWidget->GetItemInfo(); }
	const FItemIconInfo& GetRelicInfo() const { return RelicIconWidget->GetItemInfo(); }
	const FItemIconInfo& GetItemInfo(EPartyIconItemType InItemType) const;

	bool IsSystemJoker() const { return bSystemJoker; }
	bool IsSelectEnabled(EPartyIconItemType InItemType) const;

	FPartyIconClickedDelegate OnCharacterIconClickedDelegate;
	FPartyIconClickedDelegate OnSculptureIconClickedDelegate;
	FPartyIconClickedDelegate OnRelicIconClickedDelegate;
	FPartyEquipIconSelectedDelegate OnPartyIconSelectedDelegate;

protected:
	UFUNCTION(BlueprintImplementableEvent)
	void SetEditEnabled(bool bCanEdit);

	UFUNCTION(BlueprintImplementableEvent)
	void SetCharacterSelected(EIconSelectType SelectType);

	UFUNCTION(BlueprintImplementableEvent)
	void SetEditType(EPartyIconType PartyIconType);

	UFUNCTION(BlueprintImplementableEvent)
	void SetMenu(EPartyWidgetType InWidgetType);

private:

	void SetTotalAttributes();
	void OpenCharacterDetail(UPartyEquipIconWidget* EquipIconWidget = nullptr);

	void OnSculptureIconClicked(UPartyEquipIconWidget* InSculptureIconWidget);
	void OnRelicIconClicked(UPartyEquipIconWidget* InRelicIconWidget);

	UFUNCTION()
	void OnSelectButtonClicked();

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* CharacterAddAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CharacterRemoveAnim;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> HighlightAnims;

	// Widgets

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* NatureImage;

	UPROPERTY()
	UImage* NatureBgImage;

	UPROPERTY()
	UQ6RichTextBlock* LevelText;

	UPROPERTY()
	UTextBlock*	TotalHealthText;

	UPROPERTY()
	UTextBlock*	TotalAtkText;

	UPROPERTY()
	UTextBlock*	TotalDefText;

	UPROPERTY()
	UTextBlock* OpenLevelText;

	UPROPERTY()
	UPartyEquipIconWidget* SculptureIconWidget;

	UPROPERTY()
	UPartyEquipIconWidget* RelicIconWidget;

	// Fields

	UPROPERTY(EditInstanceOnly)
	EPartyIconViewType ViewType;

	UPROPERTY(EditInstanceOnly)
	bool bSystemJoker;

	FItemIconInfo ItemInfo;
	bool bSelectEnabled;
	bool bViewOnly;

	EPartyWidgetType WidgetType;
	EJokerSlotType JokerSlot;
	EJokerSlotType SwapSlot;
};


UCLASS()
class Q6_API UPartySelectWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	UPartySelectWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetParty(int32 InSelectPartyId);
	void SetMultisideParty();
	void SetJokerSet(int32 InJokerSetId);

	int32ParamDelegate OnJokerSetChangeDelegate;

private:
	static const int32 SubPartySlotOffset = 3;

	void SetPartyMembers(UPartyPageWidget* PartyPageWidget, const FPartyInfo& InPartyInfo);
	void SetMultisidePartyMembers(UPartyPageWidget* PartyPageWidget, const FPartyInfo& InPartyInfo);
	void SetJokerSetMembers(UPartyPageWidget* PartyPageWidget, const FJokerSet& InJokerSet);

	void AddPartyMember(UPartyPageWidget* PartyPageWidget, const FPartySlot& InPartySlot, int32 SlotIndex, bool bMain);
	void AddMultisidePartyMember(UPartyPageWidget* PartyPageWidget, FPartyInfo& NewMultisidePartyInfo, const FPartySlot& InPartySlot, int32 SlotIndex, bool bMain);

	void OnPartyPageSet(UWidget* Widget, int32 InPartyId);
	void OnMultisidePartyPageSet(UWidget* ViewWidget, int32 InPartyId /* == dummy */);
	void OnPartyPageChanged(int32 NewPage);
	void OnJokerSetPageSet(UWidget* ViewWidget, int32 InJokerSetId);
	void OnJokerSetPageChanged(int32 NewPage);

	// Widgets

	UPROPERTY()
	UPageSwipeWidget* PartySwipeWidget;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* PartyMenuAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* JokerMenuAnim;

	int32 PageNumber;
};


UCLASS()
class Q6_API UPartyMemberListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPartyMemberListWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void InitParty(const FPartyInfo& PartyInfo, const FPartySlot& OwnedJokerSlot);
	void InitMultisideParty(const FPartyInfo& PartyInfo);
	void InitJokerSet(const FJokerSet& JokerSet);

	void OnSelectItem(EPartyIconItemType ItemType, int64 SelectedItemId, int32 SelectedItemType, int32 SelecedSlotIdx = -1);
	void DeselectAll();

	void SetHighlight(EPartyIconItemType ItemType);

	FCharacterId GetCharacterId(int32 SlotIdx) const;
	FSculptureId GetSculptureId(int32 SlotIdx) const;
	FRelicId GetRelicId(int32 SlotIdx) const;

	UPartyIconWidget* GetPartyIconBySlotIdx(int32 SlotIdx) const;
	int32 GetPartyIconIndex(const UPartyIconWidget* IconWidget) const;
	bool HasEqualCharacterType(const FCharacterId& CharacterId) const;
	bool HasEqualSculptureType(const FSculptureId& SculptureId) const;
	bool HasEqualRelicType(const FRelicId& RelicId) const;
	bool IsCharacterInParty(const FCharacterId& CharacterId) const;
	bool IsSculptureInParty(const FSculptureId& SculptureId) const;
	bool IsRelicInParty(const FRelicId& RelicId) const;

	TArray<const FCharacter*> GetPartyCharacters(bool bJoker) const;
	TArray<const FRelic*> GetPartyRelics(bool bJoker) const;
	TArray<const FSculpture*> GetPartySculptures(bool bJoker) const;

	FPartyIconClickedDelegate OnCharacterIconClickedDelegate;
	FPartyIconClickedDelegate OnSculptureIconClickedDelegate;
	FPartyIconClickedDelegate OnRelicIconClickedDelegate;

private:
	void OnSelectItemForJokerSet(EPartyIconItemType ItemType, int64 SelectedItemId, int32 SelectedItemType, int32 SelectedSlotIdx);
	void ResetPartyIcons(EPartyWidgetType InWidgetType, bool bIsMultiside = false);
	void OnCharacterClicked(UPartyIconWidget* PartyIconWidget);
	void OnSculptureClicked(UPartyIconWidget* PartyIconWidget);
	void OnRelicClicked(UPartyIconWidget* PartyIconWidget);

	UPROPERTY()
	TArray<UPartyIconWidget*> PartyIconWidgets;

	EPartyWidgetType WidgetType;
};

UCLASS()
class Q6_API UPartyEditWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPartyEditWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetParty(int32 InPartyId, EPartyIconItemType InItemType, int64 InSlotIdx);
	void SetMultisideParty(EPartyIconItemType InItemType, int32 SelectedSlotIdx);
	void SetJokerSet(int32 InJokerSetId, EPartyIconItemType InItemType, int64 InSlotIdx);
	void SetTopSpacer(bool bInVisible);

	FPartyInfo GetPartyInfo(int32 InPartyId) const;
	FPartySlot GetJokerSlot() const;

	FPartyInfo GetMultisidePartyInfo() const;
	FJokerSetEx GetJokerSet(int32 InJokerSetId) const;
	bool IsChangedInitPartyInfo(const FPartyInfo& EditingPartyInfo, const FPartySlot& OwnedJokerSlot) const;
	bool IsChangedInitMultisidePartyInfo(const FPartyInfo& EditingPartyInfo) const;
	bool IsChangedInitJokerSet(const FJokerSet& EditingJokerSet) const;

	void RefreshItemList(bool bInPartySelectReset);

private:
	bool SetChangedPartyMember(UPartyIconWidget* NewClickedPartyIconWidget, EPartyIconItemType NewItemType);

	void SetEmptyInfo();
	void SetItemInfo(const FItemIconInfo& ItemInfo);
	void SetCharacterItem(const FItemIconInfo &ItemInfo, UCMS* CMS, int64& Health, int64& Atk, int64& Def);
	void SetSculptureItem(const FItemIconInfo &ItemInfo, UCMS* CMS, int64& Health, int64& Atk, int64& Def);
	void SetRelicItem(const FItemIconInfo &ItemInfo, UCMS* CMS, int64& Health, int64& Atk, int64& Def);

	void SetCharacterList();
	void SetCharacterListForJokerSet();
	void SetSculptureList(ESortMenu SortMenu);
	void SetRelicList(ESortMenu SortMenu);

	void AddItemRemovalCard();

	TArray<FCharacterId> GetPartyCharacterIds() const;
	TArray<FCharacterId> GetJokerSetCharacterIds() const;

	TArray<FRelicId> GetPartyRelicIds() const;
	TArray<FRelicId> GetJokerSetRelicIds() const;

	TArray<FSculptureId> GetPartySculptureIds() const;
	TArray<FSculptureId> GetJokerSetSculptureIds() const;

	TArray<FCharacterType> GetJokerSetCharacterTypes() const;

	FCharacterId GetAllSlotCharacterId() const;
	FCharacterType GetAllSlotCharacterType() const;
	bool IsAllSlotSwapable(EJokerSlotType InJokerSlot) const;

#if !UE_BUILD_SHIPPING
	bool CanJokerEditSlot() const;
#endif

	void OnItemCardClicked(UItemCardWidget* ItemCardWidget);
	void OpenOverlappedToastMessage(UItemCardWidget* InDummyCardWidget = nullptr);
	void OnPartyIconClicked(UPartyIconWidget* ClickedPartyIconWidget, EPartyIconItemType InItemType);

	void OnItemCategoryChanged(int32 NewIndex);

	UFUNCTION()
	void OnPartyResetButtonClicked();
	void OnPartyReset(bool CharacterReset, bool SculptureReset, bool RelicReset);

	UItemCardWidget* FindItemCard(int64 ItemId) const;
	UPartyIconWidget* FindPartyIcon(EPartyIconItemType InItemType, int64 InItemId) const;
	UPartyIconWidget* AllSlotIconWidget() const;

	// Classes

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPartyResetConfirmPopupWidget> PartyResetPopupClass;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* CharacterDetailAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EquipDetailAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* PartyEditAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* JokerEditAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TabEquipAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TabCharacterAnim;

	// Widgets

	UPROPERTY()
	UHorizontalBox* PartyNumberBox;

	UPROPERTY()
	UTextBlock* PartyNumberText;

	UPROPERTY()
	UTextBlock* JokerSetNumberText;

	UPROPERTY()
	UPartyMemberListWidget* MemberListWidget;

	UPROPERTY()
	UToggleButtonBoxWidget* ItemCategoryWidget;

	UPROPERTY()
	UStatWidget* StatHpWidget;

	UPROPERTY()
	UStatWidget* StatAtkWidget;

	UPROPERTY()
	UStatWidget* StatDefWidget;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	URichTextBlock* EffectsText;

	UPROPERTY()
	UButton* PartyResetButton;

	UPROPERTY()
	USpacer* TopSpacer;

	UPROPERTY()
	USortingWidget* SortingWidget;

	int32 PartyId;
	EPartyIconItemType ItemType;

	int32 JokerSetId;

	UPartyIconWidget* SelectedPartyIconWidget;
	UItemCardWidget* SelectedItemCardWidget;

	bool bPartySelectReset;
	bool bIsMultiside;
};


UCLASS()
class Q6_API UPartyWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UPartyWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	virtual void OnEnterMenu() override;
	virtual bool OnBack() override;
	virtual void RefreshMenu() override;

	void SetPartyList();
	void SetPartyEdit(int32 PartyId, EPartyIconItemType ItemType, int32 SelectedSlotIdx);
	void SetMultisidePartyEdit(EPartyIconItemType ItemType, int32 SelectedSlotIdx);

	void SetJokerSetList();
	void SetJokerSetEdit(int32 JokerSetId, EPartyIconItemType InItemType, int32 SelectedSlotIdx);

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const;

	UFUNCTION(BlueprintImplementableEvent)
	void InitShowUserId();

	UFUNCTION(BlueprintImplementableEvent)
	void SetShowUserId(bool bInShow);

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void AddPartyCharacterUnit(const FPartySlot& PartySlot, TArray<FCCCombatSeedUnit>& Units) const;
	void AddSystemJokerUnit(const FCharacterInfo& JokerInfo, TArray<FCCCombatSeedUnit>& Units) const;
	void AddFriendJokerUnit(const FFriendJokerSlot& FriendJokerSlot, bool bRecommendJoker, TArray<FCCCombatSeedUnit>& Units) const;
	void AddCharacterUnit(const FCharacterInfo& CharacterInfo, const FSculptureInfo* SculptureInfo,
		const FRelicInfo* RelicInfo, int32 SupportSkillLevel, EAttributeCategory InAttributeRatioType, TArray<FCCCombatSeedUnit>& Units) const;

	UPartyEditWidget* FindOrCreatePartyEditWidget();

	UFUNCTION()
	void RefreshWatt();

	UFUNCTION()
	void OnPartyEditButtonClicked();

	UFUNCTION()
	void OnSaveButtonClicked();

	UFUNCTION()
	void OnCombatStartButtonClicked();

	UFUNCTION()
	void OnCollectionButtonClicked();

	UFUNCTION()
	void OnJokerSettingButtonClicked();

	UFUNCTION()
	void OnJokerUseButtonClicked();

	UFUNCTION()
	void OnJokerEditButtonClicked();

	void OnPopupButtonClicked(EConfirmPopupFlag Flag);
	void OnJokerSetChanged(int32 JokerSetId);

	void SetEventWattPoint(const FEventContentType InEventContentType, const int32 InWattConsume);
	void OpenRegularRaidMatchTimerWidget();
	void OpenRaidExpiredConfirmPopup();

	// Widgets

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPartyEditCancleConfirmPopupWidget> PartyEditCancelConfirmPopupClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<URegularRaidMatchTimerWidget> RegularRaidMatchTimerWidgetClass;

	UPROPERTY()
	UWidgetSwitcher* PartyMenuSwitcher;

	UPROPERTY()
	UPartySelectWidget* PartySelectWidget;

	UPROPERTY()
	URegularRaidMatchTimerWidget*  RegularRaidMatchTimerWidget;

	UPROPERTY()
	UBorder* JokerUsedBorder;

	UPROPERTY()
	UButton* PartyEditButton;

	UPROPERTY()
	UButton* PartySaveButton;

	UPROPERTY()
	UButton* JokerUseButton;

	UPROPERTY()
	UButton* JokerEditButton;

	UPROPERTY()
	UPointButtonWidget* CombatStartButton;

	UPROPERTY()
	USizeBox* BottomMenuBox;

	UPROPERTY()
	USizeBox* BottomJokerBox;

	UPROPERTY()
	USpacer* BottomSpacer;

	UPROPERTY()
	UQuickMenuButtonWidget* CollectionButtonWidget;

	UPROPERTY()
	UQuickMenuButtonWidget* JokerSetttingButtonWidget;

	UPROPERTY()
	UCheckBox* ShowUserIDCheckBox;

	UPROPERTY()
	UBorder* UserIdBorder;

	UPROPERTY()
	UTextBlock* UserIDText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* PartyMenuAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* JokerMenuAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPartyEditWidget> PartyEditWidgetClass;

	UPROPERTY()
	FSagaType SagaType;

	UPROPERTY()
	bool bIsClosedPopup;

	UPROPERTY()
	EPartyWidgetType WidgetType;
};

UCLASS()
class Q6_API UPartyPageWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPartyPageWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void ResetPage(EPartyWidgetType InWidgetType, bool bInViewOnly, bool bInIsMultiside);
	void AddCharacterInfoAt(const FCharacterInfo& CharacterInfo, const FCharacterBond& CharacterBond, int32 SlotIdx);
	void AddCharacterLockedSlotInfoAt(const int32 SlotIdx);
	void AddFriendJokerSlotAt(const FFriendJokerSlot& JokerSlot, int32 SlotIdx);
	void AddOwnedJokerSlotAt(const FPartySlot& PartySlot, int32 SlotIdx);
	void SetFriendJoker(const FFriendJokerSet& JokerSet);
	void SetPet(const FPetId& InPetId);

	void AddSculptureInfoAt(const FSculptureInfo& SculptureInfo, int32 SlotIdx);
	void AddRelicInfoAt(const FRelicInfo& RelicInfo, int32 SlotIdx);

	void RemoveCharacterAt(int32 SlotIdx);
	void RemoveSculptureAt(int32 SlotIdx);
	void RemoveRelicAt(int32 SlotIdx);

	FIntParamDelegate OnCharacterSelectedDelegate;
	FIntParamDelegate OnSculptureSelectedDelegate;
	FIntParamDelegate OnRelicSelectedDelegate;

	const TArray<UPartyIconWidget*>& GetPartyIconWidgets() const { return PartyIconWidgets; }
protected:
	UFUNCTION(BlueprintImplementableEvent)
	void SetMenuType(EPartyWidgetType InWidgetType);

private:
	bool ReturnToJokerSelectMenu(int32 SlotIdx);

	void OnPartyIconClicked(UPartyIconWidget* PartyIcon, EPartyIconItemType ItemType, int32 SlotIdx);
	void OnPetButtonClicked();
	void OnPetSelectPopupClosed();

	UPROPERTY()
	TArray<UPartyIconWidget*> PartyIconWidgets;

	UPROPERTY()
	UWidgetSwitcher* PetSwitcher;

	UPROPERTY()
	UImage* PetImage;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPartyPetSelectPopupWidget> PetSelectPopupWidgetClass;

	bool bIsOpenedByMultiside;
	FPetId PetId;
};


UCLASS()
class Q6_API UPartyPetDetailPageWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPet(const FPetInfo& PetInfo, bool bUsed, bool bInIsMultiside);

private:
	UFUNCTION()
	void OnUseButtonClicked();

	UPROPERTY()
	UWidgetSwitcher* UsedSwitcher;

	UPROPERTY()
	UPetIconWidget* IconWidget;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	TArray<UTurnSkillDescWidget*> SkillDescWidgets;

	bool bIsOpendByMultiside;
	FPetId PetId;
};


UCLASS()
class Q6_API UPartyPetSelectPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	void SetPetList(FPetId InSelectedPetId, bool bInIsMultiside);

protected:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

private:
	void OnPetDetailPageSet(UWidget* ViewWidget, int32 PageNum);
	void OnPetDetailPageFocused(int32 PageNum);

	UPROPERTY()
	UPageSwipeWidget* PetSwipeWidget;

	bool bIsOpendByMultiside;
	FPetId SelectedPetId;
};
