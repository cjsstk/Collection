// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseWidget.h"
#include "Q6Define.h"
#include "Q6SummonGameMode.h"

#include "SummonHUDWidget.generated.h"

class UStarBarWidget;
class USummonInfoWidget;
class USummonHUDButton;
class UQ6TextBlock;
class UTextBlock;
class UImage;
class UWidgetAnimation;
class UItemBigCardWidget;

struct FSummonInfo;

UCLASS()
class Q6_API USummonHUDWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	USummonHUDWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void InterationReady();
	void SetSummonInfo(const FSummonInfo& Info, const FSimpleDelegate& EndDelegate);
	void MoveToNextSummonInfo();
	void HideSummonInfo();
	void ShowSkipButton(bool bShow);

	FSimpleDelegate MoveToNextDelegate;
	FSimpleDelegate SkipDelegate;
	FSimpleDelegate InteractionDelegate;

private:
	UFUNCTION()
	void OnNextClicked();

	UFUNCTION()
	void OnSkipClicked();

	UFUNCTION()
	void OnInteractionFired();

	UPROPERTY()
	USummonInfoWidget* SummonInfoWidget;

	UPROPERTY()
	UButton* NextButton;

	UPROPERTY()
	UButton* SkipButton;

	UPROPERTY()
	UCanvasPanel* HUDButtonPanel;

	UPROPERTY()
	USummonHUDButton* HUDButton;

	UPROPERTY()
	UTextBlock* NoticeText;

	UPROPERTY()
	UWidgetAnimation* InteractionStartAnim;

	UPROPERTY()
	UWidgetAnimation* InteractionLoopAnim;

	UPROPERTY()
	UWidgetAnimation* InteractionEndAnim;
};

UCLASS()
class Q6_API UFirstSummonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UFirstSummonWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void StartAnimation(ELootCategory Category);
	bool IsFirstShowOver() const;

	FSimpleDelegate OnFirstSummonEndDelegate;

private:
	UPROPERTY()
	UTextBlock* FirstTitleText;

	UPROPERTY()
	UWidgetAnimation* FirstItemStartAnim;

	UPROPERTY()
	UWidgetAnimation* FirstMasterPieceAnim;

	UPROPERTY()
	UWidgetAnimation* FirstRelicAnim;

	UPROPERTY()
	UWidgetAnimation* FirstCharacterAnim;
};

UCLASS()
class Q6_API USummonInfoWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonInfoWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void SetSummonInfo(const FSummonInfo& Info, const FSimpleDelegate& EndDelegate);
	void HideSummonInfo();
	void MoveToNext();

private:
	enum class EUIState : uint8
	{
		None,
		ItemShow,
		InfoStart,
		FirstShow,
		CanBeEnd,
		InfoEnd,
	};
	
	void SetUIState(EUIState State);

	UFUNCTION()
	void OnFirstSummonEnd();

	UPROPERTY()
	UFirstSummonWidget* FirstSummonWidget;

	UPROPERTY()
	UItemBigCardWidget* ItemBigCardWidget;

	UPROPERTY()
	UQ6TextBlock* TypeNameText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UStarBarWidget* StarBarWidget;

	UPROPERTY()
	UImage* GradeImage;

	UPROPERTY()
	UImage* GradeBgImage;

	UPROPERTY()
	UImage* NatureTypeImage;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* NickNameText;

	UPROPERTY()
	UWidgetAnimation* InfoStartAnim;

	UPROPERTY()
	UWidgetAnimation* InfoEndAnim;

	UPROPERTY()
	UWidgetAnimation* ItemShowAnim;

	UPROPERTY()
	UWidgetAnimation* ItemShowNAnim;

	UPROPERTY()
	UWidgetAnimation* ItemShowRAnim;

	UPROPERTY()
	UWidgetAnimation* ItemShowSRAnim;

	UPROPERTY()
	UWidgetAnimation* ItemShowSSRAnim;

	UPROPERTY()
	UWidgetAnimation* StateItemAnim;

	UPROPERTY()
	UWidgetAnimation* StateCharacterAnim;

	FSummonInfo SummonInfo;
	FSimpleDelegate InfoEndDelegate;
	EUIState UIState;
};

UCLASS()
class Q6_API USummonHUDButton : public UUserWidget
{
	GENERATED_BODY()

public:
	USummonHUDButton(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	virtual FReply NativeOnTouchStarted(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;
	virtual FReply NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;
	virtual FReply NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;

	void EnableSwipe(bool bEnable);
	void InteractionReady();
	void InteractionStart();

	FSimpleDelegate SwipeDelegate;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Q6")
	float SwipeLength;

private:

	UPROPERTY()
	UWidgetAnimation* InteractionStartAnim;

	UPROPERTY()
	UWidgetAnimation* InteractionResetAnim;

	UPROPERTY()
	UWidgetAnimation* SetColorBlueAnim;

	UPROPERTY()
	UWidgetAnimation* SetColorGreenAnim;

	UPROPERTY()
	UWidgetAnimation* SetColorOrangeAnim;

	FVector2D TouchBeginPos;
	bool bTouched;
	bool bSwpieEnabled;
};
