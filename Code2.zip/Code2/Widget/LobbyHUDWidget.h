// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once
#include "UMG.h"
#include "BaseWidget.h"
#include "HUDStore.h"
#include "Q6.h"
#include "Q6UIDefine.h"
#include "UIStateManager.h"
#include "LobbyHUD.h"
#include "LobbyHUDWidget.generated.h"

/**
 * 
 */
UCLASS()
class Q6_API ULobbyHUDWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	ULobbyHUDWidget(const FObjectInitializer& ObjectInitializer);

	virtual void OnEnterMenu() {}
	virtual void OnLeaveMenu();
	virtual bool OnBack() { return true; }

	virtual void RefreshMenu();

protected:
	const FLobbyUIState* GetUIState() const { return GetHUDStore().GetUIStateManager().GetUIState(); }

	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Invalid; }
};
