// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "UMG.h"
#include "BaseWidget.h"
#include "Q6LobbyState.h"

#include "NavigationBarWidgets.generated.h"

class URichTextBlock;
class UPointPlusWidget;
class UStageEnemyNaturesWidget;
class UQuickMenuButtonWidget;

UCLASS()
class Q6_API UMenuButtonBaseWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UMenuButtonBaseWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetMenuName(const FText& InMenuName);
	void SetNewMarkVisible(bool bInVisible);

	UFUNCTION(BlueprintImplementableEvent)
	void SetMenuButtonBaseContentState(bool bLocked);

	FSimpleDelegate OnMenuButtonClickedDelegate;

protected:
	virtual void InitMenuButton();

	UFUNCTION()
	void OnMenuButtonClicked();

private:
	UPROPERTY()
	UTextBlock* MenuNameText;

	UPROPERTY()
	UImage* NewMarkImage;	// Nullable

	// Fields

	UPROPERTY(EditInstanceOnly)
	FText MenuName;
};

UCLASS()
class Q6_API UMenuButtonWidget : public UMenuButtonBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetChecked(bool bInChecked);
	void SetCheckedBrush(const FSlateBrush& InCheckedBrush);

protected:
	virtual void InitMenuButton() override;

private:
	// Events
	UFUNCTION()
	void OnMenuButtonStateChanged(bool bChecked);

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* CheckedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UncheckedAnim;

	// Widgets

	UPROPERTY()
	UCheckBox* MenuButton;

	UPROPERTY()
	UImage* CheckedIconImage;

	UPROPERTY()
	UImage* UncheckedIconImage;

	// Fields

	UPROPERTY(EditInstanceOnly)
	FCheckBoxStyle MenuButtonStyle;

	UPROPERTY(EditInstanceOnly)
	FSlateBrush CheckedBrush;

	UPROPERTY(EditInstanceOnly)
	FSlateBrush UncheckedBrush;
};

UCLASS()
class Q6_API UQuickMenuButtonWidget : public UMenuButtonBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetIcon(const FSlateBrush& InIconBrush);

protected:
	virtual void InitMenuButton() override;

private:
	// Widgets
	UPROPERTY()
	UImage* IconImage;

	// Fields

	UPROPERTY(EditInstanceOnly)
	FSlateBrush IconBrush;
};

UCLASS()
class Q6_API UNavigationBarWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	UNavigationBarWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	void SetTopBarType(ETopBarType TopBarType);
	void SetBottomBarVisible(bool bInVisible);
	void SetNaviBar(EHUDWidgetType HUDWidgetType, const FNaviBarState& State);
	void SetTitleVisible(bool bInVisible);
	void SetBackButtonVisible(bool bInVisible);
	void SetReadyTimerVisible(bool bInVisible);
	void SetCombatReady(FSagaType InSagaType);
	void SetReadyTimer();

	void RefreshMenuButtons(EHUDWidgetType HUDWidgetType);

	UFUNCTION(BlueprintImplementableEvent)
	void SetShow(bool bInShow);

private:
	static const int32 MainMenuNumber = 5;
	static const int32 SubMenuNumber = 16;

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	UFUNCTION()
	void OnSubMenuToggleButtonClicked();

	void OpenSubMenu();

	void Refresh();
	void RefreshWattRemainTime(bool bInVisible = true);
	void RefreshWattText();

	void SetWattType(ETopBarType TopBarType);
	void SetNewMarks();
	void SetContentState();
	void SetTitleInfo(EHUDWidgetType HUDWidgetType, const FNaviBarState& State);
	bool CheckContentOpen(const EHUDWidgetType HUDWidgetType);

	UFUNCTION()
	void OnBackButtonClicked();

	UFUNCTION()
	void OnGemPurchaseButtonClicked();

	UFUNCTION()
	void OnWattRechargeButtonClicked();

	UFUNCTION()
	void OnMailButtonClicked();

	UFUNCTION()
	void OnSubMenuButtonClicked(int32 InValue);

	UFUNCTION()
	void OnSubMenuCloseButtonClicked();

	UFUNCTION()
	void OnMenuChanged(EHUDWidgetType HUDWidgetType);

	UFUNCTION()
	void OnTitleSelectButtonClicked();

	// Bottom bar widgets

	UPROPERTY()
	UButton* BackButton;

	UPROPERTY()
	USizeBox* BackButtonBox;

	UPROPERTY()
	TArray<UMenuButtonWidget*> MainMenuButtonWidgets;

	UPROPERTY()
	TArray<UQuickMenuButtonWidget*> SubMenuButtonWidgets;

	UPROPERTY()
	UBorder* SubMenuBorder;

	// Top bar widgets

	UPROPERTY()
	UImage* TitleIconImage;

	UPROPERTY()
	UImage* IconBadgeImage;

	UPROPERTY()
	URichTextBlock* TitleText;

	UPROPERTY()
	UBorder* TitleBorder;

	UPROPERTY()
	USizeBox* ReputationBadgeSizeBox;

	UPROPERTY()
	USizeBox* ReadyTimerBox;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UProgressBar* XpGauge;

	UPROPERTY()
	UTextBlock* GemText;

	UPROPERTY()
	UTextBlock* GoldText;

	UPROPERTY()
	UTextBlock* WattText;

	UPROPERTY()
	UTextBlock* WattOfMaxText;

	UPROPERTY()
	UTextBlock* WattTimerText;

	UPROPERTY()
	UButton* WattRechargeButton;

	UPROPERTY()
	UImage* WattIconImage;

	UPROPERTY()
	UImage* NewMailIconImage;

	UPROPERTY()
	UMenuButtonWidget* SubMenuToggleButton;

	// For combat ready only widgets

	UPROPERTY()
	UTextBlock* StageText;

	UPROPERTY()
	UTextBlock* StageNumText;

	UPROPERTY()
	UTextBlock* StageNameText;

	UPROPERTY()
	UTextBlock* RecommendLevelText;

	UPROPERTY()
	UTextBlock* ReadyTimerText;

	UPROPERTY()
	UStageEnemyNaturesWidget* StageNaturesWidget;

	// Animations

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> TopBarAnims;	// Index match to ETopBarType

	UPROPERTY(Transient)
	UWidgetAnimation* BottomNoneAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BottomDefaultAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	FLinearColor MaxWattTextColor;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SubMenuOpenIconBrush;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SubMenuCloseIconBrush;

	FTimerHandle ReadyTimerHandle;

	float WattRegenElapsedTime;
};
