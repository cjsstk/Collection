#pragma once

#include "PopupWidgets.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "WonderWidgets.h"

#include "AlchemyLabWidgets.generated.h"

class UPointWidget;
class UItemWidget;

UENUM(BlueprintType)
enum class EAlchemyLabState : uint8
{
	Empty,
	InProgress,
	Complete,
};

UENUM(BlueprintType)
enum class EResearchListState : uint8
{
	Opened,
	Locked,
};

UENUM(BlueprintType)
enum class EResearchListSelectState : uint8
{
	None,
	Selected,
};

UENUM(BlueprintType)
enum class EResearchListViewState : uint8
{
	None,
	InProgress,
};

UCLASS()
class Q6_API UResearchListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UResearchListWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetResearchList(const FCMSAlchemyLabRow* Row
		, const EAlchemyLabItemListPopupType Type);

	UFUNCTION(BlueprintImplementableEvent)
	void ResearchListState(EResearchListState State);

	UFUNCTION(BlueprintImplementableEvent)
	void ResearchListSelectState(EResearchListSelectState State);

	UFUNCTION(BlueprintImplementableEvent)
	void ResearchListViewState(EResearchListViewState State);

	FSimpleDelegate OnSelectButtonClickedDelegate;

private:
	void SetRelic(const int32 ProductValue);
	void SetSculpture(const int32 ProductValue);
	void SetLumicube();

	void SetItemNameText(const FText& Text);
	void SetProductionTime(const int32 Minutes);
	void SetOpenInfoText(const FText& Text);

	void SetMigrium(const int32 Count);
	void SetGold(const int32 Gold);

	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UTextBlock* ItemNameText;

	UPROPERTY()
	UTextBlock* TimeText;

	UPROPERTY()
	UTextBlock* OpenInfoText;

	UPROPERTY()
	UBorder* IngTextBorder;

	UPROPERTY()
	UPointWidget* MigriumPointWidget;

	UPROPERTY()
	UPointWidget* GoldPointWidget;
};

UCLASS()
class Q6_API UAlchemyLabItemListPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	UAlchemyLabItemListPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetAlchemyLabItemList(const EAlchemyLabItemListPopupType Type);
	EAlchemyLabItemListPopupType GetPopupType() const { return PopupType; }

	FIntParamDelegate OnSelectButtonClickedDelegate;

private:
	void SetSelectType();
	void SetViewType();

	UFUNCTION()
	void OnAlchemyLabTypeSelected(const int32 Type, UResearchListWidget* SelectedWidget);

	UPROPERTY()
	UDynamicListWidget* ResearchListWidget;

	UResearchListWidget* CurrSelectedListWidget;
	EAlchemyLabItemListPopupType PopupType;
};

UCLASS()
class Q6_API UAlchemyLabWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	UAlchemyLabWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	virtual void SetWonder() override;
	virtual void RefreshUI() override;

	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) override;

	UFUNCTION(BlueprintImplementableEvent)
	void ResearchState(EAlchemyLabState State);

	UFUNCTION(BlueprintImplementableEvent)
	void ResearchResultItemState(bool bProduct, bool bMax);

	UFUNCTION(BlueprintImplementableEvent)
	void SetResearchPorgressBar(float Value);

private:
	void Reset();

	void SetMigrium();
	void SetGold();
	void SetResearchCountText(const FText& Text);
	void SetAmountText(const FText& Text);
	void SetMaxText(const FText& Text);
	void SetRequireTimeText(const FText& Text);
	void SetRemainTime(const FAlchemylabInfo& AlchemylabInfo);
	void SetAlchemyLabTimer();

	void SetItemInfo(const int32 ProductType);

	void SetRelic(const FCMSAlchemyLabRow& AlchemyLabRow);
	void SetSculpture(const FCMSAlchemyLabRow& AlchemyLabRow);
	void SetLumicube(const FCMSAlchemyLabRow& AlchemyLabRow);

	void SetRequireMigriumPoint(const int32 Count);
	void SetRequireGoldPoint(const int32 Gold);

	void SetNewMark(const FAlchemylabInfo& Info);

	UFUNCTION()
	void OnPlusButtonClicked();

	UFUNCTION()
	void OnMinusButtonClicked();

	UFUNCTION()
	void OnGetButtonClicked();

	UFUNCTION()
	void OnResearchListButtonClicked();

	UFUNCTION()
	void OnSelectButtonClicked(int32 Type, UAlchemyLabItemListPopupWidget* Widget);

	UFUNCTION()
	void OnAlchemyLabItemListPopupButtonClicked(EConfirmPopupFlag Option
		, UAlchemyLabItemListPopupWidget* Widget);

	UFUNCTION()
	void OnItemReceivedPopupClosed();

	UPROPERTY()
	UPointWidget* MigriumPointWidget;
	
	UPROPERTY()
	UPointWidget* GoldPointWidget;

	UPROPERTY()
	UButton* PlusButton;

	UPROPERTY()
	UButton* MinusButton;

	UPROPERTY()
	UTextBlock* ResearchCountText;

	UPROPERTY()
	UTextBlock* TotalTimerText;

	UPROPERTY()
	UTextBlock* AmountText;

	UPROPERTY()
	UTextBlock* MaxText;

	UPROPERTY()
	UTextBlock* RequireTimeText;

	UPROPERTY()
	UItemWidget* SelectItemWidget;

	UPROPERTY()
	UItemWidget* ProductItemWidget;

	UPROPERTY()
	UPointWidget* RequireMigriumPointWidget;

	UPROPERTY()
	UPointWidget* RequireGoldPointWidget;

	UPROPERTY()
	UImage* StockNewMarkImage;

	UPROPERTY()
	UImage* ProduceNewMarkImage;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UAlchemyLabItemListPopupWidget> ItemListPopupClass;

	bool bButtonLock;

	int32 MakeType;
	int32 ResearchCount;
	int32 ReceiveProductCount;

	int64 EndProgressValue;
	int64 CurrProgressValue;
	int64 TotalRemainSeconds;

	FTimerHandle TimeHandle;
};
