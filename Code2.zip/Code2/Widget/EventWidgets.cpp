// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "EventWidgets.h"

#include "LobbyHUD.h"
#include "CMSTable.h"
#include "Q6.h"
#include "PopupWidgets.h"
#include "PointWidgets.h"
#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "ShopWidgets.h"
#include "GameResource.h"
#include "UIStateManager.h"
#include "HUDStore/EventManager.h"
#include "AvatarManager.h"
#include "ShopManager.h"
#include "AccountWidgets.h"
#include "StageWidgets.h"
#include "SystemConst_gen.h"
#include "SagaManager.h"
#include "Q6Account.h"


DECLARE_CYCLE_STAT(TEXT("OnHSEvent Event"), STAT_OnHSEventByEvent, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent EventShop"), STAT_OnHSEventByEventShop, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent EventRewardPopup"), STAT_OnHSEventByEventRewardPopup, STATGROUP_HSTORE);

bool IsExpiredEvent(FEventContentType InEventContentType)
{
	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(InEventContentType);
	if (EventContentRow.IsInvalid())
	{
		Q6JsonLogGunny(Error, "IsExpiredEvent() - EventContentRow does not exist."
			, Q6KV("EventContentType", InEventContentType));
		return false;
	}

	const FEventScheduleInfo* EventSchedule = GetHUDStore().GetEventManager().GetEventSchedule(EventContentRow.EventSchedule);
	if (!EventSchedule)
	{
		Q6JsonLogGunny(Error, "IsExpiredEvent() - EventSchedule does not exist."
			, Q6KV("EventScheduleId", EventContentRow.EventSchedule));
		return false;
	}

	return Q6Util::GetRemainDetailTime(EventSchedule->CustomDate2) == 0;
}

bool IsChallengeStage(FSagaType SagaType)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	return SagaRow.StageType == EStageType::Story || SagaRow.StageType == EStageType::Normal;
}

//////////////////////////////////////////////////////////////////////////
// UEventPageWidget
//////////////////////////////////////////////////////////////////////////
UEventPageWidget::UEventPageWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UEventPageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* Button = CastChecked<UButton>(GetWidgetFromName("EventBtn"));
	Button->OnClicked.AddUniqueDynamic(this, &UEventPageWidget::OnEventButtonClicked);

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	EventPeriodText = CastChecked<UTextBlock>(GetWidgetFromName("EventPeriodLeft"));
}

void UEventPageWidget::SetPage(FEventContentType InEventContentType)
{
	EventContentType = InEventContentType;

	const FCMSEventContentRow& EventRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	const UEventManager& EventManager = GetHUDStore().GetEventManager();

	const FEventScheduleInfo* ScheduleInfo = EventManager.GetEventSchedule(EventRow.EventSchedule);
	if (!ScheduleInfo)
	{
		Q6JsonLogGunny(Warning, "UEventPageWidget::SetPage - ScheduleInfo does not exist.",
			Q6KV("EventScheduleId", EventRow.EventSchedule));
		return;
	}

	const FEventListAssetRow* Row = GetGameResource().GetEventListAssetRow(EventContentType);
	if (!Row)
	{
		Q6JsonLogGunny(Warning, "UEventPageWidget::SetPage - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType));
		return;
	}

	BGImage->SetBrush(Row->EventBanner);

	bool bLocked = false;
	const TArray<const FCMSSagaRow*>& ConditionRows = EventRow.GetConditionSaga();
	if (ConditionRows.Num() != 0)
	{
		check(ConditionRows.IsValidIndex(0));
		bLocked = !GetHUDStore().GetSagaManager().IsStageCleared(ConditionRows[0]->Episode, ConditionRows[0]->Stage, ConditionRows[0]->SubStage);
	}

	FDateTime StageStartDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate);
	FDateTime StageEndDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate2);
	bool bStageStart = StageStartDate < FDateTime::Now();
	const FTimespan& TimeDiff = bStageStart ? StageEndDate - FDateTime::Now() : StageStartDate - FDateTime::Now();

	if (bStageStart && TimeDiff <= 0)
	{
		SetEventPageWidgetContentState(bLocked);
		EventPeriodText->SetText(Q6Util::GetLocalizedText("Lobby", "EventPeriodEnd"));
		return;
	}

	int32 TempDays = TimeDiff.GetDays();
	int32 TempHours = TimeDiff.GetHours();

	EventPeriodText->SetText(
		FText::Format(
			bStageStart ? Q6Util::GetLocalizedText("Lobby", "EventEndPeriod") : Q6Util::GetLocalizedText("Lobby", "EventStartPeriod"),
			FText::AsNumber(TimeDiff.GetDays()),
			FText::AsNumber(TimeDiff.GetHours())));

	SetEventPageWidgetContentState(bLocked);
}

void UEventPageWidget::OnEventButtonClicked()
{
	const FCMSEventContentRow& EventRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	const TArray<const FCMSSagaRow*>& ConditionRows = EventRow.GetConditionSaga();
	if (ConditionRows.Num() != 0)
	{
		check(ConditionRows.IsValidIndex(0));
		bool bIsOpen = GetHUDStore().GetSagaManager().IsStageCleared(ConditionRows[0]->Episode, ConditionRows[0]->Stage, ConditionRows[0]->SubStage);
		if (!bIsOpen)
		{
			GetBaseHUD(this)->ShowNotOpenedYetNotification(ConditionRows[0]->CmsType());
			return;
		}
	}

	GetCheckedLobbyHUD(this)->SetHUDType(EHUDWidgetType::Event);

	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	if (EventContentRow.Category == EEventContentCategory::MultiSideBattle)
	{
		GetHUDStore().GetEventManager().ReqEventContentMultisideBattleRankLoad(EventContentType);
	}

	ACTION_DISPATCH_EventMenuChange(EEventMenu::Main, EventContentType);
}

//////////////////////////////////////////////////////////////////////////
// UEventMainWidget
//////////////////////////////////////////////////////////////////////////
UEventMainWidget::UEventMainWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UEventMainWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MainStartAnim = GetWidgetAnimationFromName(this, "AnimMainStart");
	StageSelectStartAnim = GetWidgetAnimationFromName(this, "AnimStageSelectStart");
	StateEventAnim = GetWidgetAnimationFromName(this, "AnimStateEvent");
	StateMultiBattleAnim = GetWidgetAnimationFromName(this, "AnimStateMultiBattle");

	EventBgImage = CastChecked<UImage>(GetWidgetFromName("EventBg"));
	EventLogoImage = CastChecked<UImage>(GetWidgetFromName("EventLogo"));
	EventPointIconImage = CastChecked<UImage>(GetWidgetFromName("EventPointIcon"));

	FString WidgetName;
	EventCurrencyWidgets.Empty();
	for (int i = 1; i <= MAX_EVENT_CURRENCY_TYPE; ++i)
	{
		WidgetName = FString::Printf(TEXT("EventCurrency0%d"), i);
		EventCurrencyWidgets.Add(CastChecked<UPointWidget>(GetWidgetFromName(*WidgetName)));
	}

	UButton* EventStageButton = CastChecked<UButton>(GetWidgetFromName("EventStage"));
	EventStageButton->OnClicked.AddUniqueDynamic(this, &UEventMainWidget::OnEventStageButtonClicekd);
	UButton*  EventShopButton = CastChecked<UButton>(GetWidgetFromName("EventShop"));
	EventShopButton->OnClicked.AddUniqueDynamic(this, &UEventMainWidget::OnEventShopButtonClicked);
	EventStageGroupWidget = CastChecked<UUniformGridPanel>(GetWidgetFromName("EventStageGroup"));

	EventStageButtonImage = CastChecked<UImage>(GetWidgetFromName("EventStageImg"));
	EventShopButtonImage = CastChecked<UImage>(GetWidgetFromName("EventShopImg"));

	UButton* RewardInfoButton = CastChecked<UButton>(GetWidgetFromName("RewardInfo"));
	RewardInfoButton->OnClicked.AddUniqueDynamic(this, &UEventMainWidget::OnRewardInfoButtonClicekd);

	EventDetailText = CastChecked<UTextBlock>(GetWidgetFromName("EventDetail"));
	EventPointText = CastChecked<UTextBlock>(GetWidgetFromName("EventPoint"));
	PeriodText = CastChecked<UTextBlock>(GetWidgetFromName("Period"));
	ShopOpenPeriodText = CastChecked<UTextBlock>(GetWidgetFromName("ShopOpenPeriod"));
	BonusDetailText = CastChecked<UTextBlock>(GetWidgetFromName("BonusDetail"));

	StageListGroupWidget = CastChecked<UBorder>(GetWidgetFromName("StageListGroup"));
	MultiBattleDetailGroupBorder = CastChecked<UBorder>(GetWidgetFromName("MultiBattleDetailGroup"));

	MultiBattleWattBorder = CastChecked<UBorder>(GetWidgetFromName("MultiBattleWatt"));
	OwnMultiBattleWattText = CastChecked<UTextBlock>(GetWidgetFromName("OwnMultiBattleWatt"));
	MaxMultiBattleWattText = CastChecked<UTextBlock>(GetWidgetFromName("MaxMultiBattleWatt"));

	StageListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("StageList"));

	EventRankWidget = CastChecked<UEventRankWidget>(GetWidgetFromName("EventRank"));
	ChallengeGroupSizeBox = CastChecked<USizeBox>(GetWidgetFromName("ChallengeGroup"));
	ChallengeStageWidget = CastChecked<UStageEntryWidget>(GetWidgetFromName("ChallengeStage"));
}

void UEventMainWidget::OnEnterMenu()
{
	Super::OnEnterMenu();
	SubscribeToStore(EHSType::Event);
	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::WorldUser);
}

void UEventMainWidget::OnLeaveMenu()
{
	if (EventShopWidget && EventShopWidget->IsInViewport())
	{
		EventShopWidget->RemoveFromViewport();
	}

	Super::OnLeaveMenu();
}

void UEventMainWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FEventUIState* UIState = GetUIState()->CastToEventUIState();
	check(UIState);

	EventContentType = UIState->EventContentType;
	SetEventInfo();

	const FCMSEventContentRow& ContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	switch (UIState->EventMenu)
	{
		case EEventMenu::Main:
			PlayAnimation(MainStartAnim);

			if (ContentRow.Category == EEventContentCategory::MultiSideBattle)
			{
				TUTORIAL_MONITORING_BUTTON_CLICK("MultiSideBattleEnter");
				PlayAnimation(StateMultiBattleAnim);
			}
			else
			{
				PlayAnimation(StateEventAnim);
			}
			break;
		case EEventMenu::Shop:
			OpenEventShopWidget();
			break;
		case EEventMenu::Stage:
			PlayAnimation(StageSelectStartAnim);
			SetEventStage();
			break;
	}
}

void UEventMainWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByEvent);

	switch (InAction->GetActionType())
	{
		case EHSActionType::EventMenuChange:
		case EHSActionType::EventContentMultiSideBattleRankLoadResp:
		case EHSActionType::DevWattConsumeResp:
		case EHSActionType::DevWattRechargeResp:
		case EHSActionType::WattRechargeResp:
			RefreshMenu();
			break;
	}
}

bool UEventMainWidget::OnBack()
{
	if (EventShopWidget && EventShopWidget->IsInViewport())
	{
		EventShopWidget->RemoveFromViewport();
	}

	PlayAnimation(MainStartAnim);
	return true;
}

void UEventMainWidget::OnEventShopButtonClicked()
{
	ACTION_DISPATCH_EventMenuChange(EEventMenu::Shop, EventContentType);
}

void UEventMainWidget::OnEventStageButtonClicekd()
{
	if (IsExpiredEvent(EventContentType))
	{
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "PeriodExpiredToast"));
		return;
	}

	ACTION_DISPATCH_EventMenuChange(EEventMenu::Stage, EventContentType);
}

void UEventMainWidget::OnRewardInfoButtonClicekd()
{
	UEventRewardPopupWidget* EventRewardPopupWidget = GetBaseHUD(this)->OpenEventRewardPopupWidget();
	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	if (EventContentRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::OnRewardInfoButtonClicekd - EventContentRow does not exist.",
			Q6KV("EventContentType", EventContentType));
		return;
	}

	EventRewardPopupWidget->SetRewardInfos(EventContentType);
}

void UEventMainWidget::OpenEventShopWidget()
{
	if (!EventShopWidget)
	{
		EventShopWidget = CreateWidget<UEventShopWidget>(GetOwningPlayer(), EventShopWidgetClass.LoadSynchronous());
	}

	check(EventShopWidget);

	if (!EventShopWidget->IsInViewport())
	{
		EventShopWidget->AddToViewport(ZORDER_EVENT_SHOP_WIDGET);
	}

	EventShopWidget->SetEventShop(EventContentType);
}

void UEventMainWidget::SetEventInfo()
{
	const FEventListAssetRow* Row = GetGameResource().GetEventListAssetRow(EventContentType);
	if (!Row)
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::SetEventInfo - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType));

		return;
	}
	EventBgImage->SetBrush(Row->EventBackground);
	EventLogoImage->SetBrush(Row->Logo);
	EventStageButtonImage->SetBrush(Row->StageImg);
	EventShopButtonImage->SetBrush(Row->ShopImg);

	const FCMSEventContentRow& ContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);

	if (ContentRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::SetEventInfo - EventContentRow does not exist.", Q6KV("EventContentType", EventContentType));
		return;
	}

	switch (ContentRow.Category)
	{
		case EEventContentCategory::Collabo01:
			break;
		case EEventContentCategory::ValentineDay:
			MultiBattleDetailGroupBorder->SetVisibility(ESlateVisibility::Collapsed);
			MultiBattleWattBorder->SetVisibility(ESlateVisibility::Collapsed);
			EventRankWidget->SetVisibility(ESlateVisibility::Collapsed);
			EventDetailText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

			EventDetailText->SetText(Q6Util::GetLocalizedText("Event", "ValentineDetail"));
			break;
		case EEventContentCategory::MultiSideBattle:
		{
			MultiBattleDetailGroupBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			MultiBattleWattBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			EventRankWidget->SetVisibility(ESlateVisibility::Visible);
			EventDetailText->SetVisibility(ESlateVisibility::Collapsed);

			const UCMS* CMS = GetCMS();
			const FCMSEventContentMultiSideBattleRow* MultisideRow = CMS->GetEventContentMultiSideBattleRow(EventContentType);
			if (!MultisideRow)
			{
				Q6JsonLogGunny(Warning, "UEventMainWidget::SetEventInfo - MultisideRow does not exist.", Q6KV("EventContentType", EventContentType));
				return;
			}
			const FEventContentInfo* EventInfo = GetHUDStore().GetEventManager().GetEvent(EventContentType);
			if (!EventInfo)
			{
				Q6JsonLogPawn(Warning, "UEventMainWidget::SetEventInfo() - EventInfo does not exist.", Q6KV("EventContentType", EventContentType));
				return;
			}
			EventRankWidget->SetRank(EventContentType);
			BonusDetailText->SetText(CMS->GetMultiSideBattleRankBonusDesc(MultisideRow->RankBonus));

			OwnMultiBattleWattText->SetText(FText::AsNumber(EventInfo->WattInfo.Watt));
			MaxMultiBattleWattText->SetText(FText::AsNumber(SystemConst::Q6_EVENT_CONTENT_WATT_MAX));
			break;
		}
		default:
			break;
	}

	SetPeriod();
	SetOwnedItem();
}

void UEventMainWidget::SetPeriod()
{
	const UCMS* CMS = GetCMS();
	const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(EventContentType);
	if (EventContentRow.IsInvalid())
	{
		Q6JsonLogGunny(
			Warning,
			"UEventMainWidget::SetPeriod - EventContentRow does not exist.",
			Q6KV("EventContentType", EventContentType));
		return;
	}

	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FEventScheduleInfo* ScheduleInfo = EventManager.GetEventSchedule(EventContentRow.EventSchedule);
	if (!ScheduleInfo)
	{
		Q6JsonLogGunny(
			Warning,
			"UEventMainWidget::SetPeriod - ScheduleInfo does not exist.",
			Q6KV("EventScheduleType", EventContentRow.EventSchedule));
		return;
	}

	PeriodText->SetText(
		FText::Format(Q6Util::GetLocalizedText("Lobby", "EventCheckInPeriod"),
			Q6Util::GetLocalDateText(ScheduleInfo->CustomDate),
			Q6Util::GetLocalDateText(ScheduleInfo->CustomDate2)));

	ShopOpenPeriodText->SetText(
		FText::Format(Q6Util::GetLocalizedText("Lobby", "ShopOpenPeriod"),
			Q6Util::GetLocalDateText(ScheduleInfo->CustomDate),
			Q6Util::GetLocalDateText(ScheduleInfo->EndDate)));

	const FDateTime& EndDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->EndDate);
	bool bDeadLinePassed = FDateTime::Now() > EndDate;
	EventStageGroupWidget->SetIsEnabled(!bDeadLinePassed);
	PeriodText->SetColorAndOpacity(
		bDeadLinePassed ? GetUIResource().GetLackColor() : GetUIResource().GetNormalColor());
}

void UEventMainWidget::SetOwnedItem()
{
	const FEventListAssetRow* Row = GetGameResource().GetEventListAssetRow(EventContentType);
	if (!Row)
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::SetOwnedItem - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType));

		return;
	}

	check(Row->PointIcon.IsValidIndex(1));
	EventPointIconImage->SetBrush(Row->PointIcon[1]);

	TArray<int32> EventPoints = GetHUDStore().GetEventManager().GetEventPoint(EventContentType);
	if (!EventPoints.IsValidIndex(1))
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::SetOwnedItem - EventPoint[1] (accumulated point) does not exist.");
		return;
	}

	EventPointText->SetText(FText::AsNumber(EventPoints[1]));

	const UCMS* CMS = GetCMS();
	const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(EventContentType);

	if (EventContentRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::SetOwnedItem - EventContentRow does not exist.",
			Q6KV("EventType", EventContentType));
		return;
	}

	int32 EventIconIndex = 0;
	int32 EventCurrencyIndex = EventContentRow.CurrencyStartIndex;

	for (UPointWidget* EventCurrencyWidget : EventCurrencyWidgets)
	{
		EventCurrencyWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		EventCurrencyWidget->SetEventPointType(EventContentType, EventCurrencyIndex, EPointWidgetOption::NONE);
		if (!EventPoints.IsValidIndex(EventCurrencyIndex))
		{
			Q6JsonLogGunny(Warning, "UEventMainWidget::SetOwnedItem - EventPoint does not exist.", Q6KV("EventCurrencyIndex", EventCurrencyIndex));
			return;
		}
		EventCurrencyWidget->SetCurPoint(EventPoints[EventCurrencyIndex]);
		EventCurrencyIndex++;
		EventIconIndex++;

		if (EventCurrencyIndex > EventContentRow.CurrencyEndIndex)
		{
			break;
		}
	}

	// Collapse left things
	for (int i = EventIconIndex; i < EventCurrencyWidgets.Num(); ++i)
	{
		EventCurrencyWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
	}
}

bool HasStageType(const TArray<FEventStageInfo> InStages, int32 InEventStageType)
{
	for (const FEventStageInfo& Iter : InStages)
	{
		if (Iter.EventStageType == InEventStageType)
		{
			return true;
		}
	}

	return false;
}

void UEventMainWidget::SetEventStage()
{
	const FEventListAssetRow* AssetRow = GetGameResource().GetEventListAssetRow(EventContentType);
	if (!AssetRow)
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::SetEventStage - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType));

		return;
	}

	StageListGroupWidget->SetBrush(AssetRow->StageBackground);

	StageListWidget->ClearList();

	const UCMS* CMS = GetCMS();
	const FCMSEventContentRow& ContentRow = CMS->GetEventContentRowOrDummy(EventContentType);

	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FEventScheduleInfo* ScheduleInfo = EventManager.GetEventSchedule(ContentRow.EventSchedule);
	if (!ScheduleInfo)
	{
		Q6JsonLogGunny(Warning, "UEventMainWidget::SetEventStage - ScheduleInfo does not exist.",
			Q6KV("ScheduleId", ContentRow.EventSchedule));

		return;
	}

	const FDateTime& EventStartDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate);
	const FTimespan& EventTimeSpan = FDateTime::Now() - EventStartDate;

	int32 NumberOfDays = INVALID_DAY;
	if (EventTimeSpan >= 0)
	{
		NumberOfDays = EventTimeSpan.GetDays();
	}

	switch (ContentRow.Category)
	{
		case EEventContentCategory::Collabo01:
			break;
		case EEventContentCategory::ValentineDay:
		{
			ChallengeGroupSizeBox->SetVisibility(ESlateVisibility::Collapsed);

			TArray<const FCMSEventContentValentineDayRow*> ValentineRows;
			UCMSBase::GetEventContentValentineDay()->GetAllRows(TEXT("GetEventContentValentineDay"), ValentineRows);

			TArray<FEventStageInfo> ValentineStageInfos;
			TArray<FEventContentCategoryInfo> PlayedStages = EventManager.GetPlayedStages(EventContentType);
			for (const FCMSEventContentValentineDayRow* Iter : ValentineRows)
			{
				AddValentineStageInfo(PlayedStages, ScheduleInfo, Iter, NumberOfDays, ValentineStageInfos);
			}

			ValentineStageInfos.Sort([](const FEventStageInfo& L, const FEventStageInfo& R)
				{
					if (L.StageState == R.StageState)
					{
						return L.SagaType > R.SagaType;
					}
					else
					{
						return static_cast<int>(L.StageState) < static_cast<int>(R.StageState);
					}
				}
			);

			for (const FEventStageInfo& Iter : ValentineStageInfos)
			{
				UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
				if (Iter.StageState == EStageState::LockedByStage)
				{
					const FCMSEventContentValentineDayRow& ValentineDayRow = CMS->GetEventContentValentineDayRowOrDummy(FEventContentValentineDayType(Iter.EventStageType));
					EntryWidget->SetOpenConditionText(ValentineDayRow.GetConditionSaga());
				}
				EntryWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
				EntryWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
			}

			break;
		}
		case EEventContentCategory::MultiSideBattle:
		{
			ChallengeGroupSizeBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

			// 1. played stages
			TArray<FEventStageInfo> PlayedStagesInfo;
			// 2. playable stages(repeatable)
			TArray<FEventStageInfo> RepeatableStagesInfo;
			// 3. locked(period) stages
			TArray<FEventStageInfo> LockedPeriodStagesInfo;
			// 4. playable stages(new)
			TArray<FEventStageInfo> PlayableStagesInfo;
			// 5. locked(condition) stages
			TArray<FEventStageInfo> LockedConditionStagesInfo;

			TArray<FEventContentCategoryInfo> PlayedStages = EventManager.GetPlayedStages(EventContentType);
			TArray<const FCMSEventContentMultiSideBattleStageRow*> MultisideStasgeRows = GetCMS()->GetEventContentMultisideBattleStageRows(EventContentType);

			for (const FCMSEventContentMultiSideBattleStageRow* Iter : MultisideStasgeRows)
			{
				const FDateTime& StageStartDate = Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate + (Iter->NumberOfDays - 1) * 24 * 60 * 60);
				int64 StageStartDateUnix = StageStartDate.ToUnixTimestamp();

				if (AddMultisidePlayedStage(PlayedStages, Iter, StageStartDateUnix, PlayedStagesInfo, RepeatableStagesInfo))
				{
					continue;
				}

				if (AddMultisideLockedPeriodStage(PlayedStages, Iter, NumberOfDays, StageStartDateUnix, LockedPeriodStagesInfo))
				{
					continue;
				}

				if (AddMultisidePlayableStage(PlayedStages, Iter, StageStartDateUnix, PlayableStagesInfo))
				{
					continue;
				}

				if (AddMultisideLockedConditionStage(Iter, NumberOfDays, StageStartDateUnix, LockedConditionStagesInfo))
				{
					continue;
				}
			}

			// create widget
			bool bSetChallenge = false;
			for (const FEventStageInfo& Iter : PlayableStagesInfo)
			{
				if (IsChallengeStage(Iter.SagaType) && !bSetChallenge)
				{
					ChallengeStageWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
					ChallengeStageWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
					bSetChallenge = true;
					continue;
				}

				UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
				EntryWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
				EntryWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
			}
			for (const FEventStageInfo& Iter : RepeatableStagesInfo)
			{
				UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
				EntryWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
				EntryWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
			}
			for (const FEventStageInfo& Iter : LockedPeriodStagesInfo)
			{
				if (IsChallengeStage(Iter.SagaType) && !bSetChallenge)
				{
					ChallengeStageWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
					ChallengeStageWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
					bSetChallenge = true;
					continue;
				}

				UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
				EntryWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
				EntryWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
			}
			for (const FEventStageInfo& Iter : LockedConditionStagesInfo)
			{
				UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
				EntryWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);

				const FCMSEventContentMultiSideBattleStageRow& MultisideBattleStageRow = CMS->GetEventContentMultiSideBattleStageRowOrDummy(FEventContentMultiSideBattleStageType(Iter.EventStageType));
				EntryWidget->SetOpenConditionText(MultisideBattleStageRow.GetConditionSaga());

				EntryWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
			}
			for (const FEventStageInfo& Iter : PlayedStagesInfo)
			{
				if (IsChallengeStage(Iter.SagaType))
				{
					if (!bSetChallenge)
					{
						ChallengeStageWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
						ChallengeStageWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
						bSetChallenge = true;
					}
					
					continue;
				}

				UStageEntryWidget* EntryWidget = CastChecked<UStageEntryWidget>(StageListWidget->AddChildAtLastIndex());
				EntryWidget->SetEventEntryWidget(EventContentType, Iter.EventStageType, Iter.SagaType, Iter.StageState, Iter.StartDate);
				EntryWidget->SetClearCount(Iter.ClearCount, Iter.ReplayLimit);
			}

			break;
		}
	}
}

bool UEventMainWidget::IsStageConditionOK(const FCMSEventContentValentineDayRow* ValentineDayRow, const TArray<FEventContentCategoryInfo>& PlayedStages) const
{
	const TArray<const FCMSSagaRow*>& ConditionSagas = ValentineDayRow->GetConditionSaga();
	int32 SatisfyNum = 0;

	for (const FEventContentCategoryInfo& PlayedStage : PlayedStages)
	{
		const FCMSEventContentValentineDayRow& PlayedStageRow =
			GetCMS()->GetEventContentValentineDayRowOrDummy(FEventContentValentineDayType(PlayedStage.EventContentCategoryType));

		for (const FCMSSagaRow* ConditionSaga : ConditionSagas)
		{
			if (PlayedStageRow.GetSaga().CmsType() == ConditionSaga->CmsType())
			{
				SatisfyNum++;
			}
		}
	}

	return  SatisfyNum == ConditionSagas.Num();
}

void UEventMainWidget::AddValentineStageInfo(
	const TArray<FEventContentCategoryInfo>& PlayedStages,
	const FEventScheduleInfo* ScheduleInfo,
	const FCMSEventContentValentineDayRow* ValentineDayRow,
	int32 NumberOfDays,
	TArray<FEventStageInfo>& OutValentineStageInfos)
{
	const FDateTime& StageStartDate = 
		Q6Util::UtcTimestampToLocalDateTime(ScheduleInfo->CustomDate + (ValentineDayRow->NumberOfDays - 1) * 24 * 60 * 60);
	int64 StartDate = StageStartDate.ToUnixTimestamp();

	for (const FEventContentCategoryInfo& PlayedIter : PlayedStages)
	{
		if (ValentineDayRow->CmsType() != FEventContentValentineDayType(PlayedIter.EventContentCategoryType))
		{
			continue;
		}

		if (ValentineDayRow->ReplayLimit && PlayedIter.ClearCount >= ValentineDayRow->ReplayLimit)
		{
			OutValentineStageInfos.Add(FEventStageInfo(
				ValentineDayRow->CmsType().x,
				ValentineDayRow->GetSaga().CmsType(),
				EStageState::Clear,
				StartDate,
				PlayedIter.ClearCount,
				ValentineDayRow->ReplayLimit)
			);

			return;
		}
		else
		{
			OutValentineStageInfos.Add(FEventStageInfo(
				ValentineDayRow->CmsType().x,
				ValentineDayRow->GetSaga().CmsType(),
				EStageState::Normal,
				StartDate,
				PlayedIter.ClearCount,
				ValentineDayRow->ReplayLimit)
			);

			return;
		}
	}

	// NumberOfDays : 0-based
	int32 IterNumberOfDays = ValentineDayRow->NumberOfDays - 1;
	if (NumberOfDays < IterNumberOfDays)
	{
		if (IsStageConditionOK(ValentineDayRow, PlayedStages))
		{
			OutValentineStageInfos.Add(
				FEventStageInfo(
					ValentineDayRow->CmsType().x,
					ValentineDayRow->GetSaga().CmsType(),
					EStageState::LockedByCondition,
					StartDate,
					0,
					ValentineDayRow->ReplayLimit)
			);
		}
	}
	else
	{
		OutValentineStageInfos.Add(
			FEventStageInfo(
				ValentineDayRow->CmsType().x,
				ValentineDayRow->GetSaga().CmsType(),
				IsStageConditionOK(ValentineDayRow, PlayedStages) ? EStageState::New : EStageState::LockedByStage,
				StartDate,
				0,
				ValentineDayRow->ReplayLimit)
		);
	}
}

bool UEventMainWidget::AddMultisidePlayedStage(const TArray<FEventContentCategoryInfo>& PlayedStages, const FCMSEventContentMultiSideBattleStageRow* Iter, int64 StartDate, TArray<FEventStageInfo>& OutPlayedStagesInfo, TArray<FEventStageInfo>& OutRepeatableStagesInfo)
{
	const UCMS* CMS = GetCMS();
	for (const FEventContentCategoryInfo& PlayedIter : PlayedStages)
	{
		if (Iter->CmsType() != FEventContentMultiSideBattleStageType(PlayedIter.EventContentCategoryType))
		{
			continue;
		}

		const FCMSSagaRow& SagaRow = Iter->GetSaga();
		bool bIsRepeatable = SagaRow.StageType == EStageType::Battle;
		if (bIsRepeatable)
		{
			OutRepeatableStagesInfo.Add(FEventStageInfo(
				Iter->CmsType().x,
				SagaRow.CmsType(),
				EStageState::Normal,
				StartDate,
				PlayedIter.ClearCount,
				1)
			);
		}
		else
		{
			OutPlayedStagesInfo.Add(FEventStageInfo(
				Iter->CmsType().x,
				SagaRow.CmsType(),
				EStageState::Clear,
				StartDate,
				PlayedIter.ClearCount,
				0)
			);
		}

		return true;
	}

	return false;
}

bool UEventMainWidget::AddMultisideLockedPeriodStage(const TArray<FEventContentCategoryInfo>& PlayedStages, const FCMSEventContentMultiSideBattleStageRow* Iter, int32 NumberOfDays, int64 StartDate, TArray<FEventStageInfo>& OutLockedPeriodStagesInfo)
{
	// NumberOfDays : 0-based
	int32 IterNumberOfDays = Iter->NumberOfDays - 1;

	if (NumberOfDays < IterNumberOfDays)
	{
		const UCMS* CMS = GetCMS();

		const TArray<const FCMSSagaRow*>& ConditionSagas = Iter->GetConditionSaga();
		int32 SatisfyNum = 0;

		for (const FEventContentCategoryInfo& PlayedStage : PlayedStages)
		{
			const FCMSEventContentMultiSideBattleStageRow& MultisideStageRow =
				CMS->GetEventContentMultiSideBattleStageRowOrDummy(FEventContentMultiSideBattleStageType(PlayedStage.EventContentCategoryType));

			for (const FCMSSagaRow* ConditionSaga : ConditionSagas)
			{
				if (MultisideStageRow.GetSaga().CmsType() == ConditionSaga->CmsType())
				{
					SatisfyNum++;
				}
			}
		}

		const FCMSSagaRow& SagaRow = Iter->GetSaga();
		if (SatisfyNum == ConditionSagas.Num())
		{
			OutLockedPeriodStagesInfo.Add(FEventStageInfo(
				Iter->CmsType().x,
				Iter->GetSaga().CmsType(),
				EStageState::LockedByCondition,
				StartDate,
				0,
				SagaRow.StageType == EStageType::Battle ? 0 : 1)
			);

			return true;
		}
	}

	return false;
}

bool UEventMainWidget::AddMultisidePlayableStage(const TArray<FEventContentCategoryInfo>& PlayedStages, const FCMSEventContentMultiSideBattleStageRow* Iter, int64 StartDate, TArray<FEventStageInfo>& OutPlayableStagesInfo)
{
	const UCMS* CMS = GetCMS();
	const TArray<const FCMSSagaRow*>& ConditionSagas = Iter->GetConditionSaga();
	int32 SatisfyNum = 0;

	for (const FEventContentCategoryInfo& PlayedStage : PlayedStages)
	{
		const FCMSEventContentMultiSideBattleStageRow& ValentineDayRow =
			CMS->GetEventContentMultiSideBattleStageRowOrDummy(FEventContentMultiSideBattleStageType(PlayedStage.EventContentCategoryType));

		for (const FCMSSagaRow* ConditionSaga : ConditionSagas)
		{
			if (ValentineDayRow.GetSaga().CmsType() == ConditionSaga->CmsType())
			{
				SatisfyNum++;
			}
		}
	}

	const FCMSSagaRow& SagaRow = Iter->GetSaga();
	if (SatisfyNum == ConditionSagas.Num())
	{
		OutPlayableStagesInfo.Add(FEventStageInfo(
			Iter->CmsType().x,
			Iter->GetSaga().CmsType(),
			EStageState::New,
			StartDate,
			0,
			SagaRow.StageType == EStageType::Battle ? 0 : 1)
		);

		return true;
	}

	return false;
}

bool UEventMainWidget::AddMultisideLockedConditionStage(const FCMSEventContentMultiSideBattleStageRow* Iter, int32 NumberOfDays, int64 StartDate, TArray<FEventStageInfo>& OutLockedConditionStagesInfo)
{
	const FCMSSagaRow& SagaRow = Iter->GetSaga();
	if (SagaRow.StageType != EStageType::Battle)
	{
		return false;
	}

	// NumberOfDays : 0-based
	int32 IterNumberOfDays = Iter->NumberOfDays - 1;

	if (NumberOfDays >= IterNumberOfDays)
	{
		OutLockedConditionStagesInfo.Add(FEventStageInfo(
			Iter->CmsType().x,
			Iter->GetSaga().CmsType(),
			EStageState::LockedByStage,
			StartDate,
			0,
			SagaRow.StageType == EStageType::Battle ? 0 : 1)
		);

		return true;
	}

	return false;
}

//////////////////////////////////////////////////////////////////////////
// UEventRewardPopupWidget
//////////////////////////////////////////////////////////////////////////
UEventRewardPopupWidget::UEventRewardPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UEventRewardPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EventRewardListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("EventRewardList"));
	EventRankRewardListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("EventRankRewardList"));
	EventRankListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("EventRankList"));

	SubscribeToStore(EHSType::Event);
}

void UEventRewardPopupWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByEventRewardPopup);

	if (InAction->GetActionType() == EHSActionType::EventContentMultisideBattleReceiveRankRewardResp)
	{
		auto Action = ACTION_PARSE_EventContentMultisideBattleReceiveRankRewardResp(InAction);
		auto& Resp = Action->GetVal();

		if (Resp.Title != UserTitleTypeInvalid)
		{
			// show get aka confirm popup after closing item reward popup
			GetLobbyHUD(this)->OpenGetAkaConfirmPopup(Resp.Title);
		}

		const TArray<FRewardInfo>& RewardInfos = Resp.RewardInfos;
		GetLobbyHUD(this)->OpenItemRewardPopup(RewardInfos);

		ClosePopup();
	}
}

void UEventRewardPopupWidget::SetRewardInfos(FEventContentType InEventContentType)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "EventRewardInfoTitle"));

	EventRewardListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	EventRankRewardListWidget->SetVisibility(ESlateVisibility::Collapsed);
	EventRankListWidget->SetVisibility(ESlateVisibility::Collapsed);

	const UCMS* CMS = GetCMS();
	TArray<const FCMSEventContentAccumPointRewardRow*> EventRewards = CMS->GetEventContentAccumPointRewards(InEventContentType);
	const FEventContentInfo* EventInfo = GetHUDStore().GetEventManager().GetEvent(InEventContentType);
	if (!EventInfo)
	{
		Q6JsonLogGunny(Warning, "UEventRewardPopupWidget::SetRewardInfos - EventInfo does not exist.",
			Q6KV("EventContentType", InEventContentType));

		return;
	}

	EventRewardListWidget->ClearList();
	for (const FCMSEventContentAccumPointRewardRow* Iter : EventRewards)
	{
		UEventRewardListWidget* Element = CastChecked<UEventRewardListWidget>(EventRewardListWidget->AddChildAtLastIndex());
		Element->SetRewardInfo(Iter, EventInfo->Point1);
	}
}

void UEventRewardPopupWidget::SetRankRewardInfos(FEventContentType InEventContentType)
{
	EventRewardListWidget->SetVisibility(ESlateVisibility::Collapsed);
	EventRankRewardListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	EventRankListWidget->SetVisibility(ESlateVisibility::Collapsed);

	bool bIsExpired = IsExpiredEvent(InEventContentType);
	SetTitle(Q6Util::GetLocalizedText("Popup", bIsExpired ? "EventRankRewardGetTitle" : "EventRankRewardInfoTitle"));

	const UCMS* CMS = GetCMS();
	TArray<const FCMSEventContentMultiSideBattleRewardRow*> RewardRows = CMS->GetMultisideBattleRewards(InEventContentType);
	const FEventContentInfo* EventInfo = GetHUDStore().GetEventManager().GetEvent(InEventContentType);
	if (!EventInfo)
	{
		Q6JsonLogGunny(Warning, "UEventRewardPopupWidget::SetRankRewardInfos - EventInfo does not exist.",
			Q6KV("EventContentType", InEventContentType));

		return;
	}

	const FEventContentMultiSideBattleInfo& MultisideBattleInfo = EventInfo->MultiSideBattleInfo;
	EventRankRewardListWidget->ClearList();

	// check only multi side battle ranker user titles
	TArray<const FCMSUserTitleRow*> MultiSideBattleRankerUserTitleRows = CMS->GetUserTitleRowByMissionCategory(EUserTitleMissionCategory::MultiSideBattleRanker);
	if (bIsExpired)
	{
		for (const FCMSEventContentMultiSideBattleRewardRow* Iter : RewardRows)
		{
			UEventRankRewardListWidget* Element = CastChecked<UEventRankRewardListWidget>(EventRankRewardListWidget->AddChildAtLastIndex());
			bool bActivate =
				// score == 0 means that you did not participate
				(MultisideBattleInfo.Score != 0) &&
				// n only
				((Iter->RankBegin == MultisideBattleInfo.Rank && MultisideBattleInfo.Rank == Iter->RankEnd) ||
				// n to n + 1
				(Iter->RankBegin <= MultisideBattleInfo.Rank && MultisideBattleInfo.Rank <= Iter->RankEnd) ||
				// non rank
				(Iter->RankBegin <= MultisideBattleInfo.Rank && Iter->RankEnd == -1));

			Element->SetExpiredRewardInfo(Iter, MultiSideBattleRankerUserTitleRows, bActivate, MultisideBattleInfo.Received);
		}
	}
	else
	{
		for (const FCMSEventContentMultiSideBattleRewardRow* Iter : RewardRows)
		{
			UEventRankRewardListWidget* Element = CastChecked<UEventRankRewardListWidget>(EventRankRewardListWidget->AddChildAtLastIndex());
			Element->SetRewardInfo(Iter, MultiSideBattleRankerUserTitleRows);
		}
	}
}

void UEventRewardPopupWidget::SetRankInfos(FEventContentType InEventContentType)
{
	EventRewardListWidget->SetVisibility(ESlateVisibility::Collapsed);
	EventRankRewardListWidget->SetVisibility(ESlateVisibility::Collapsed);
	EventRankListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FEventContentInfo* EventInfo = EventManager.GetEvent(InEventContentType);
	if (!EventInfo)
	{
		Q6JsonLogGunny(Warning, "UEventRewardPopupWidget::SetRankInfos - EventInfo does not exist.",
			Q6KV("EventContentType", InEventContentType));
		return;
	}

	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(InEventContentType);
	const FEventContentMultiSideBattleInfo& MultisideBattleInfo = EventInfo->MultiSideBattleInfo;

	SetTitle(FText::Format(
		Q6Util::GetLocalizedText("Popup", "EventRankTitle"), 
		EventContentRow.Desc,
		FText::AsNumber(MultisideBattleInfo.RankGroupIndex + 1))); // GroupIndex 1-based

	EventRankListWidget->ClearList();
	for (const FEventContentMultiSideBattleSimpleInfo& Iter : MultisideBattleInfo.TopRankInfos)
	{
		if (Iter.Score == 0)
		{
			continue;
		}

		UEventRankListWidget* Element = CastChecked<UEventRankListWidget>(EventRankListWidget->AddChildAtLastIndex());
		Element->SetInfo(InEventContentType, Iter);
	}
}

void UEventRewardPopupWidget::SetCombatRewardInfos(FEventContentType InEventContentType, int32 InReceivedPoint)
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "EventRewardGetTitle"));

	EventRewardListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	EventRankRewardListWidget->SetVisibility(ESlateVisibility::Collapsed);
	EventRankListWidget->SetVisibility(ESlateVisibility::Collapsed);

	const UCMS* CMS = GetCMS();
	TArray<const FCMSEventContentAccumPointRewardRow*> EventRewards = CMS->GetEventContentAccumPointRewards(InEventContentType);

	TArray<int32> EventPoints = GetHUDStore().GetEventManager().GetEventPoint(InEventContentType);
	int32 TotalPoint = EventPoints[1];

	int32 ReceivedIndex = 0;
	EventRewardListWidget->ClearList();
	int32 PrevPoint = TotalPoint - InReceivedPoint;

	for (int32 i = 0; i < EventRewards.Num(); ++i)
	{
		UEventRewardListWidget* Element = CastChecked<UEventRewardListWidget>(EventRewardListWidget->AddChildAtLastIndex());

		int32 StandardPoint = EventRewards[i]->AccumPoint;
		ERewardState RewardState = ERewardState::None;

		if (StandardPoint < PrevPoint)
		{
			RewardState = ERewardState::Already;
		}
		else if (StandardPoint <= PrevPoint + InReceivedPoint)
		{
			ReceivedIndex = i;
			RewardState = ERewardState::NowGet;
		}
		else
		{
			RewardState = ERewardState::NotYet;
		}

		Element->SetCombatRewardInfo(EventRewards[i], TotalPoint, RewardState);
	}

	EventRewardListWidget->FocusAtIndex(ReceivedIndex);
}

//////////////////////////////////////////////////////////////////////////
// UEventRewardListWidget
//////////////////////////////////////////////////////////////////////////
UEventRewardListWidget::UEventRewardListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UEventRewardListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StateNotYetAnim = GetWidgetAnimationFromName(this, "AnimStateNotYet");
	StateNowGetAnim = GetWidgetAnimationFromName(this, "AnimStateNowGet");
	StateGottenAnim = GetWidgetAnimationFromName(this, "AnimStateGotten");

	EventPointIconImage = CastChecked<UImage>(GetWidgetFromName("EventPointIcon"));
	PointTermText = CastChecked<UTextBlock>(GetWidgetFromName("PointTerm"));

	RewardItemWidget = CastChecked<URewardItemWidget>(GetWidgetFromName("RewardItem"));
}

void UEventRewardListWidget::SetRewardInfo(const FCMSEventContentAccumPointRewardRow* InEventContentAccumPointRewardRow, int32 InCurrentPoint)
{
	if (InEventContentAccumPointRewardRow->AccumPoint <= InCurrentPoint)
	{
		PlayAnimation(StateGottenAnim);
	}
	else
	{
		PlayAnimation(StateNotYetAnim);
	}

	FItemData ItemData;
	ItemData.Category = InEventContentAccumPointRewardRow->LootCategory;
	ItemData.Count = InEventContentAccumPointRewardRow->Count;
	ItemData.Type = InEventContentAccumPointRewardRow->Value;
	if (ItemData.Category == ELootCategory::EventPoint)
	{
		RewardItemWidget->SetEventPoint(ItemData, InEventContentAccumPointRewardRow->GetEventContent().CmsType());
	}
	else
	{
		RewardItemWidget->SetEventRewardItem(ItemData, InCurrentPoint, InEventContentAccumPointRewardRow->AccumPoint);
	}

	SetPoint(InEventContentAccumPointRewardRow->GetEventContent().CmsType(), InEventContentAccumPointRewardRow->AccumPoint);
}

void UEventRewardListWidget::SetCombatRewardInfo(const FCMSEventContentAccumPointRewardRow* InEventContentAccumPointRewardRow, int32 InCurrentPoint, ERewardState RewardState)
{
	switch (RewardState)
	{
		case ERewardState::Already:
			PlayAnimation(StateGottenAnim);
			break;
		case ERewardState::NowGet:
			PlayAnimation(StateNowGetAnim);
			break;
		case ERewardState::NotYet:
			PlayAnimation(StateNotYetAnim);
			break;
		default:
			break;
	}

	FItemData ItemData;
	ItemData.Category = InEventContentAccumPointRewardRow->LootCategory;
	ItemData.Count = InEventContentAccumPointRewardRow->Count;
	ItemData.Type = InEventContentAccumPointRewardRow->Value;
	if (ItemData.Category == ELootCategory::EventPoint)
	{
		RewardItemWidget->SetEventPoint(ItemData, InEventContentAccumPointRewardRow->GetEventContent().CmsType());
	}
	else
	{
		RewardItemWidget->SetEventRewardItem(ItemData, InCurrentPoint, InEventContentAccumPointRewardRow->AccumPoint);
	}

	SetPoint(InEventContentAccumPointRewardRow->GetEventContent().CmsType(), InEventContentAccumPointRewardRow->AccumPoint);
}

void UEventRewardListWidget::SetPoint(FEventContentType InEventContentType, int32 InAccumPoint)
{
	const FEventListAssetRow* AssetRow = GetGameResource().GetEventListAssetRow(InEventContentType.x);
	if (!AssetRow)
	{
		Q6JsonLogGunny(Warning, "UEventRewardListWidget::SetPoint - EventListAssetRow does not exist.",
			Q6KV("EventContentType", InEventContentType));
		return;
	}

	check(AssetRow->PointIcon.IsValidIndex(1));
	EventPointIconImage->SetBrush(AssetRow->PointIcon[1]);
	PointTermText->SetText(
		FText::Format(Q6Util::GetLocalizedText("Popup", "PointAbove"), FText::AsNumber(InAccumPoint)));
}

//////////////////////////////////////////////////////////////////////////
// UEventShopWidget
//////////////////////////////////////////////////////////////////////////
UEventShopWidget::UEventShopWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UEventShopWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EventShopStartAnim = GetWidgetAnimationFromName(this, "AnimEventShopStart");

	FString WidgetName;
	EventCurrencyWidgets.Empty();
	for (int i = 1; i <= MAX_EVENT_CURRENCY_TYPE; ++i)
	{
		WidgetName = FString::Printf(TEXT("EventCurrency0%d"), i);
		EventCurrencyWidgets.Add(CastChecked<UPointWidget>(GetWidgetFromName(*WidgetName)));
	}

	GeneralShopListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("GeneralShopList"));

	EventBgImage = CastChecked<UImage>(GetWidgetFromName("EventBg"));
	BGShopImage = CastChecked<UImage>(GetWidgetFromName("BGShop"));

	ShopOpenPeriodText = CastChecked<UTextBlock>(GetWidgetFromName("ShopOpenPeriod"));

	SubscribeToStore(EHSType::Ui);
}

void UEventShopWidget::SetEventShop(FEventContentType InEventContentType)
{
	EventContentType = InEventContentType;
	PlayAnimation(EventShopStartAnim);

	const UCMS* CMS = GetCMS();
	const FCMSEventContentRow& EventContentRow = CMS->GetEventContentRowOrDummy(EventContentType);
	if (EventContentRow.IsInvalid())
	{
		Q6JsonLogGunny(
			Warning,
			"UEventShopWidget::SetEventShop - EventContentRow does not exist.",
			Q6KV("EventContentType", EventContentType));
		return;
	}

	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FEventScheduleInfo* ScheduleInfo = EventManager.GetEventSchedule(EventContentRow.EventSchedule);
	if (!ScheduleInfo)
	{
		Q6JsonLogGunny(
			Warning,
			"UEventShopWidget::SetEventShop - ScheduleInfo does not exist.",
			Q6KV("EventScheduleType", EventContentRow.EventSchedule));
		return;
	}

	ShopOpenPeriodText->SetText(
		FText::Format(Q6Util::GetLocalizedText("Lobby", "ShopOpenPeriod"),
			Q6Util::GetLocalDateText(ScheduleInfo->StartDate),
			Q6Util::GetLocalDateText(ScheduleInfo->EndDate)));

	GeneralShopListWidget->ClearList();
	TArray<const FCMSShopRow*> EventShopRows = CMS->GetEventShop(EventContentType);
	const UShopManager& ShopManager = GetHUDStore().GetShopManager();

	for (const FCMSShopRow* Iter : EventShopRows)
	{
		int32 LeftDays = INVALID_DAY;
		const FEventScheduleInfo* EventSchedule = EventManager.GetEventSchedule(Iter->EventScheduleId);
		if (EventSchedule)
		{
			if (!UCMS::IsInfinityEventScheduleFormat(*EventSchedule))
			{
				FDateTime StartDate = Q6Util::UtcTimestampToLocalDateTime(EventSchedule->StartDate);
				if (FDateTime::Now() < StartDate)
				{
					continue;
				}

				FDateTime EndDate = Q6Util::UtcTimestampToLocalDateTime(EventSchedule->EndDate);

				FTimespan LeftTimeSpan = EndDate - FDateTime::Now();
				if (LeftTimeSpan < 0)
				{
					continue;
				}

				LeftDays = LeftTimeSpan.GetTotalDays();
			}
		}

		UShopEntryWidget* ShopEntryWidget = CastChecked<UShopEntryWidget>(GeneralShopListWidget->AddChildAtLastIndex());
		ShopEntryWidget->SetNameAndInfo(Iter->Name, Iter->Desc);

		FItemData GetItemData;
		GetItemData.Category = Iter->ItemCategory;
		GetItemData.Type = Iter->ItemId;
		GetItemData.Count = Iter->Count;
		ShopEntryWidget->SetShopType(Iter->CmsType());
		ShopEntryWidget->SetItem(GetItemData);

		FItemData CostItemData;
		CostItemData.Category = Iter->CostItemCategory;
		CostItemData.Count = Iter->CostCount;
		if (Iter->CostItemCategory == ELootCategory::EventPoint)
		{
			CostItemData.Type = Iter->CostItemId;
			ShopEntryWidget->SetEventPointCost(EventContentType, CostItemData);
		}
		else
		{
			CostItemData.Type = Iter->CostItemId;
			ShopEntryWidget->SetCost(CostItemData);
		}

		int32 LeftCount = ShopManager.GetStocks(EShopBuyType::None, Iter->CmsType());
		if (Iter->IsMonthlyReset)
		{
			FDateTime Today = FDateTime::Now();
			LeftDays = FDateTime::DaysInMonth(Today.GetYear(), Today.GetMonth()) - Today.GetDay();
		}
		ShopEntryWidget->SetLeftDayAndCount(LeftDays, LeftCount);
	}

	const FEventListAssetRow* AssetRow = GetGameResource().GetEventListAssetRow(EventContentType);
	if (!AssetRow)
	{
		Q6JsonLogGunny(Warning, "UEventShopWidget::SetEventShop - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType));

		return;
	}

	EventBgImage->SetBrush(AssetRow->EventBackground);
	BGShopImage->SetBrush(AssetRow->StageBackground);

	SetPoints();
}

void UEventShopWidget::OnHSEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByEventShop);

	if (InAction->GetActionType() == EHSActionType::ShopBuyItemResp)
	{
		SetEventShop(EventContentType);
	}
}

void UEventShopWidget::SetPoints()
{
	const FEventListAssetRow* Row = GetGameResource().GetEventListAssetRow(EventContentType);
	if (!Row)
	{
		Q6JsonLogGunny(Warning, "UEventShopWidget::SetPoints - EventListAssetRow does not exist.",
			Q6KV("EventContentType", EventContentType));

		return;
	}

	TArray<int32> EventPoints = GetHUDStore().GetEventManager().GetEventPoint(EventContentType);
	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	if (EventContentRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UEventShopWidget::SetPoints - EventContentRow does not exist.",
			Q6KV("EventType", EventContentType));
		return;
	}

	int32 EventIconIndex = 0;
	int32 EventCurrencyIndex = EventContentRow.CurrencyStartIndex;

	for (UPointWidget* EventCurrencyWidget : EventCurrencyWidgets)
	{
		EventCurrencyWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		EventCurrencyWidget->SetEventPointType(EventContentType, EventCurrencyIndex, EPointWidgetOption::NONE);
		if (!EventPoints.IsValidIndex(EventCurrencyIndex))
		{
			Q6JsonLogGunny(Warning, "UEventShopWidget::SetPoints - EventPoint does not exist.", Q6KV("EventCurrencyIndex", EventCurrencyIndex));
			return;
		}
		EventCurrencyWidget->SetCurPoint(EventPoints[EventCurrencyIndex]);

		EventCurrencyIndex++;
		EventIconIndex++;

		if (EventCurrencyIndex > EventContentRow.CurrencyEndIndex)
		{
			break;
		}
	}

	// Collapse left things
	for (int i = EventIconIndex; i < EventCurrencyWidgets.Num(); ++i)
	{
		EventCurrencyWidgets[i]->SetVisibility(ESlateVisibility::Collapsed);
	}
}

//////////////////////////////////////////////////////////////////////////
// UEventRankWidget
//////////////////////////////////////////////////////////////////////////
UEventRankWidget::UEventRankWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UEventRankWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StateRewardNormalAnim = GetWidgetAnimationFromName(this, "AnimStateRewardNormal");
	StateRewardActLoopAnim = GetWidgetAnimationFromName(this, "AnimStateRewardActLoop");

	RankGroupText = CastChecked<UTextBlock>(GetWidgetFromName("RankGroup"));
	MyRankText = CastChecked<UTextBlock>(GetWidgetFromName("MyRank"));

	TrophyImage = CastChecked<UImage>(GetWidgetFromName("Trophy"));

	UButton* RankListButton = CastChecked<UButton>(GetWidgetFromName("RankList"));
	RankListButton->OnClicked.AddUniqueDynamic(this, &UEventRankWidget::OnEventRankListClicked);

	UButton* RankRewardButton = CastChecked<UButton>(GetWidgetFromName("RankReward"));
	RankRewardButton->OnClicked.AddUniqueDynamic(this, &UEventRankWidget::OnRankRewardClicked);
}

void UEventRankWidget::SetRank(FEventContentType InEventContentType)
{
	EventContentType = InEventContentType;

	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FEventContentInfo* EventContentInfo = EventManager.GetEvent(EventContentType);
	const FEventContentMultiSideBattleInfo& MultisideBattleInfo = EventContentInfo->MultiSideBattleInfo;

	MyRankText->SetText(
		FText::Format(Q6Util::GetLocalizedText("Common", "RankCount"),
			MultisideBattleInfo.Score == 0 ? FText::FromString("-") : FText::AsNumber(MultisideBattleInfo.Rank)));

	// GroupIndex 1-based
	RankGroupText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "RankGroup"), FText::AsNumber(MultisideBattleInfo.RankGroupIndex + 1)));

	// set rank trophy of 1st ~ 3rd
	const FSlateBrush* TrophySlateBrush = GetUIResource().GetEventUserRankTrophy(MultisideBattleInfo.Rank - 1);
	if (TrophySlateBrush && MultisideBattleInfo.Score > 0)
	{
		TrophyImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		TrophyImage->SetBrush(*TrophySlateBrush);
	}
	else
	{
		TrophyImage->SetVisibility(ESlateVisibility::Collapsed);
	}

	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	const FEventScheduleInfo* ScheduleInfo = EventManager.GetEventSchedule(EventContentRow.EventSchedule);
	if (!ScheduleInfo)
	{
		Q6JsonLogGunny(Warning, "UEventRankWidget::SetRank - ScheduleInfo doese not exist.");
		return;
	}

	if (Q6Util::GetRemainDetailTime(ScheduleInfo->CustomDate2) == 0)
	{
		PlayAnimation(StateRewardActLoopAnim, 0.f, 0);
	}
	else
	{
		StopAnimation(StateRewardActLoopAnim);
		PlayAnimation(StateRewardNormalAnim);
	}
}

void UEventRankWidget::OnEventRankListClicked()
{
	const UEventManager& EventManager = GetHUDStore().GetEventManager();
	const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
	const FEventScheduleInfo* ScheduleInfo = EventManager.GetEventSchedule(EventContentRow.EventSchedule);
	if (!ScheduleInfo)
	{
		Q6JsonLogGunny(Warning, "UEventRankWidget::OnEventRankListClicked - ScheduleInfo doese not exist.");
		return;
	}

	if (Q6Util::GetRemainDetailTime(ScheduleInfo->CustomDate) != 0)
	{
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Event", "OpenWhenMultisideStart"));
	}
	else
	{
		UEventRewardPopupWidget* EventRewardPopupWidget = GetBaseHUD(this)->OpenEventRewardPopupWidget();
		EventRewardPopupWidget->SetRankInfos(EventContentType);
	}
}

void UEventRankWidget::OnRankRewardClicked()
{
	UEventRewardPopupWidget* EventRewardPopupWidget = GetBaseHUD(this)->OpenEventRewardPopupWidget();
	EventRewardPopupWidget->SetRankRewardInfos(EventContentType);
}

//////////////////////////////////////////////////////////////////////////
// UEventRankRewardListWidget
//////////////////////////////////////////////////////////////////////////
UEventRankRewardListWidget::UEventRankRewardListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UEventRankRewardListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StateAnimations.Empty();
	StateAnimations.Add(GetWidgetAnimationFromName(this, "AnimStateNormal"));
	StateAnimations.Add(GetWidgetAnimationFromName(this, "AnimStateGet"));
	StateAnimations.Add(GetWidgetAnimationFromName(this, "AnimStateGotten"));
	StateAnimations.Add(GetWidgetAnimationFromName(this, "AnimStateActivate"));
	StateAnimations.Add(GetWidgetAnimationFromName(this, "AnimStateDeactivate"));

	RankRewardItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("RankRewardItemList"));

	RankTermText = CastChecked<UTextBlock>(GetWidgetFromName("RankTerm"));
	AkaGetText = CastChecked<UTextBlock>(GetWidgetFromName("AkaGet"));

	UButton* RewardGetButton = CastChecked<UButton>(GetWidgetFromName("RewardGet"));
	RewardGetButton->OnClicked.AddUniqueDynamic(this, &UEventRankRewardListWidget::OnRewardGetClicked);
}

void UEventRankRewardListWidget::SetRewardInfo(const FCMSEventContentMultiSideBattleRewardRow* RewardRow, const TArray<const FCMSUserTitleRow*>& MultiSideBattleRankerUserTitleRows)
{
	PlayStateAnim(EEventRankState::Normal);
	SetRewardInfoInternal(RewardRow, MultiSideBattleRankerUserTitleRows);
}

void UEventRankRewardListWidget::SetExpiredRewardInfo(const FCMSEventContentMultiSideBattleRewardRow* RewardRow, const TArray<const FCMSUserTitleRow*>& MultiSideBattleRankerUserTitleRows, bool bActive, bool bReceived)
{
	if (bActive)
	{
		if (bReceived)
		{
			PlayStateAnim(EEventRankState::Get);
		}
		else
		{
			PlayStateAnim(EEventRankState::Activate);
		}
	}
	else
	{
		PlayStateAnim(EEventRankState::Deactivate);
	}

	SetRewardInfoInternal(RewardRow, MultiSideBattleRankerUserTitleRows);
}

void UEventRankRewardListWidget::OnRewardGetClicked()
{
	GetHUDStore().GetEventManager().ReqEventContentMultiSideBattleReceiveRankReward(EventContentType);
}

void UEventRankRewardListWidget::SetRewardInfoInternal(const FCMSEventContentMultiSideBattleRewardRow* RewardRow, const TArray<const FCMSUserTitleRow*>& MultiSideBattleRankerUserTitleRows)
{
	EventContentType = RewardRow->GetEventContent().CmsType();

	if (RewardRow->RankEnd == -1)
	{
		RankTermText->SetText(Q6Util::GetLocalizedText("Popup", "EventRankTermExtra"));
	}
	else if (RewardRow->RankBegin == RewardRow->RankEnd)
	{
		RankTermText->SetText(FText::Format(
			Q6Util::GetLocalizedText("Popup", "EventRankTermSolo"),
			FText::AsNumber(RewardRow->RankBegin)));
	}
	else
	{
		RankTermText->SetText(FText::Format(
			Q6Util::GetLocalizedText("Popup", "EventRankTermRange"),
			FText::AsNumber(RewardRow->RankBegin),
			FText::AsNumber(RewardRow->RankEnd)));
	}

	AkaGetText->SetVisibility(ESlateVisibility::Collapsed);
	for (const FCMSUserTitleRow* UserTitleRow : MultiSideBattleRankerUserTitleRows)
	{
		if (UserTitleRow && UserTitleRow->MissionValue == RewardRow->Type)
		{
			AkaGetText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			AkaGetText->SetText(FText::Format(Q6Util::GetLocalizedText("Popup", "AkaGet"), UserTitleRow->DescName));
			break;
		}
	}

	SetItemList(RewardRow);
}

void UEventRankRewardListWidget::PlayStateAnim(EEventRankState InEventRankState)
{
	int32 RankStateIndex = static_cast<int32>(InEventRankState);
	if (!StateAnimations.IsValidIndex(RankStateIndex))
	{
		Q6JsonLogGunny(Warning, "UEventRankRewardListWidget::PlayStateAnim - WidgetAnimation does not exist.",
			Q6KV("RankStateIndex", RankStateIndex));

		return;
	}

	PlayAnimation(StateAnimations[RankStateIndex]);
}

void UEventRankRewardListWidget::SetItemList(const FCMSEventContentMultiSideBattleRewardRow* RewardRow)
{
	const UCMS* CMS = GetCMS();
	const TArray<const FCMSLootGroupRow *>& LootGroups = RewardRow->GetLootGroup();

	RankRewardItemListWidget->ClearList();
	for (const FCMSLootGroupRow* LootGroup : LootGroups)
	{
		const TArray<int32>& LootIds = LootGroup->LootIds;
		for (int32 LootId : LootIds)
		{
			const FCMSLootDataRow& LootData = CMS->GetLootDataOrDummy(LootId);
			if (LootData.IsInvalid())
			{
				Q6JsonLogGunny(Warning, "UEventRankRewardListWidget::SetRewardInfo - LootData isn't valid.", Q6KV("LootId", LootId));
				continue;
			}

			URewardItemWidget* Element = CastChecked<URewardItemWidget>(RankRewardItemListWidget->AddChildAtLastIndex());

			FItemData ItemData;
			ItemData.Category = LootData.LootCategory;
			ItemData.Type = LootData.Value;
			ItemData.Count = LootData.Count;

			if (ItemData.Category == ELootCategory::EventPoint)
			{
				Element->SetEventPoint(ItemData, RewardRow->GetEventContent().CmsType());
			}
			else
			{
				Element->SetItem(ItemData);
			}
		}
	}
}

//////////////////////////////////////////////////////////////////////////
// UEventRankListWidget
//////////////////////////////////////////////////////////////////////////
UEventRankListWidget::UEventRankListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UEventRankListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	AkaNameBorder = CastChecked<UBorder>(GetWidgetFromName("AkaBorder"));
	AkaNameText = CastChecked<UTextBlock>(GetWidgetFromName("AkaName"));
	UserNameText = CastChecked<UTextBlock>(GetWidgetFromName("UserName"));
	UserRankCountText = CastChecked<UTextBlock>(GetWidgetFromName("UserRankCount"));
	AccountLevelText = CastChecked<UTextBlock>(GetWidgetFromName("AccountLevel"));

	EventCurrencyWidget = CastChecked<UPointWidget>(GetWidgetFromName("EventCurrency"));
	ReputationBadgeImage = CastChecked<UImage>(GetWidgetFromName("ReputationBadge"));
	TrophyImage = CastChecked<UImage>(GetWidgetFromName("Trophy"));

	AvatarWidget = CastChecked<UAvatarIconWidget>(GetWidgetFromName("Avatar"));
}

void UEventRankListWidget::SetInfo(FEventContentType InEventContentType, const FEventContentMultiSideBattleSimpleInfo& InSimpleInfo)
{
	UserRankCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "RankCount"), FText::AsNumber(InSimpleInfo.Rank)));

	// set rank trophy of 1st ~ 3rd
	const FSlateBrush* TrophySlateBrush = GetUIResource().GetEventUserRankTrophy(InSimpleInfo.Rank - 1);
	if (TrophySlateBrush)
	{
	 	TrophyImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	 	TrophyImage->SetBrush(*TrophySlateBrush);
	}
	else
	{
	 	TrophyImage->SetVisibility(ESlateVisibility::Collapsed);
	}

	// PointIndex 1 means AccumPoint
	EventCurrencyWidget->SetEventPointType(InEventContentType, 1, EPointWidgetOption::NONE);
	EventCurrencyWidget->SetCurPoint(InSimpleInfo.Score);
	UserNameText->SetText(FText::FromString(InSimpleInfo.Nickname));

	if (InSimpleInfo.Title == UserTitleTypeInvalid)
	{
		AkaNameBorder->SetVisibility(ESlateVisibility::Collapsed);
		AkaNameText->SetText(FText::GetEmpty());
	}
	else
	{
		AkaNameBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const UCMS* CMS = GetCMS();
		const FCMSUserTitleRow& TitleRow = CMS->GetUserTitleRowOrDummy(InSimpleInfo.Title);
		AkaNameText->SetText(TitleRow.DescName);
	}

	AccountLevelText->SetText(FText::AsNumber(InSimpleInfo.Level));

	const FAkaAssetRow* AkaAssetRow = GetGameResource().GetAkaAssetRowByPoint(InSimpleInfo.TitleScore);
	if (!AkaAssetRow)
	{
		Q6JsonLogGunny(Warning, "UEventRankListWidget::SetInfo - AkaAsset does not exist.", Q6KV("TitleScore", InSimpleInfo.TitleScore));

		return;
	}
	ReputationBadgeImage->SetBrush(AkaAssetRow->Icon);

	if (GetHUDStore().GetWorldUser().GetId() == InSimpleInfo.UserId)
	{
		SetAvatar(GetHUDStore().GetAvatarManager().GetAvatarInfo());
	}
	else
	{
		SetAvatar(InSimpleInfo.Avatar);
	}
}

void UEventRankListWidget::SetAvatar(const FAvatarInfo& AvatarInfo)
{
	if (AvatarInfo.CharacterType == CharacterTypeInvalid)
	{
		// default is Weed
		AvatarWidget->SetCharacter(FCharacterType(SystemConst::Q6_WEED_CHARACTER_ID), AvatarInfo.CharacterIllustType);
	}
	else
	{
		AvatarWidget->SetCharacter(AvatarInfo.CharacterType, AvatarInfo.CharacterIllustType);
	}
	AvatarWidget->SetFrame(AvatarInfo.FrameType);
	AvatarWidget->SetEffect(AvatarInfo.EffectType);
}
