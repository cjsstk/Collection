// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "UpgradeWidgets.h"

#include "BagItemManager.h"
#include "CharacterManager.h"
#include "CharacterWidgets.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HSAction.h"
#include "HUDStore.h"
#include "InventoryWidgets.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6UIDefine.h"
#include "RelicManager.h"
#include "SculptureManager.h"
#include "SortingWidgets.h"
#include "SystemConstHelper.h"
#include "UIStateManager.h"
#include "WidgetUtil.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Upgrade"), STAT_OnHSEventByUpgrade, STATGROUP_HSTORE);

void UUpgradeResultTextWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ResultText = CastChecked<UTextBlock>(GetWidgetFromName("TextResult"));

	SuccessStartAnim = GetWidgetAnimationFromName(this, "AnimSuccessStart");
}

void UUpgradeResultTextWidget::SetResult_Implementation(EUpgradeResultType InResultType)
{
	ResultText->SetText(Q6Util::GetUpgradeResultText(InResultType));

	if (InResultType != EUpgradeResultType::Fail)
	{
		PlayAnimation(SuccessStartAnim);
	}
}

void UUpgradeXpBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	XpBar = CastChecked<UProgressBar>(GetWidgetFromName("XP"));
	ResultXpBar = CastChecked<UProgressBar>(GetWidgetFromName("ResultXP"));

	GainXpText = CastChecked<UQ6TextBlock>(GetWidgetFromName("GainXP"));
	RemainXpText = CastChecked<UQ6TextBlock>(GetWidgetFromName("RemainXP"));
}

void UUpgradeXpBarWidget::SetResultXp(int32 InGainXp, int32 InRemainXp, int32 InMaxXp)
{
	ResultXpBar->SetPercent(0.0f); // no-set

	float XpRatio = (float)(InMaxXp - InRemainXp) / InMaxXp;
	XpBar->SetPercent(XpRatio);

	GainXpText->SetText(FText::FromString(FString::FormatAsNumber(InGainXp)));
	RemainXpText->SetText(FText::FromString(FString::FormatAsNumber(InRemainXp)));
}

void UResultGainSkillWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkillIconImage = CastChecked<UImage>(GetWidgetFromName("SkillIcon"));
	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SkillName"));
	TitleBorder = CastChecked<UBorder>(GetWidgetFromName("Title"));

	GainSkillStartAnim = GetWidgetAnimationFromName(this, "AnimGainSkillStart");
}

void UResultGainSkillWidget::SetTurnSkill(FCharacterType Type, int32 SkillIndex)
{
	const UCMS* CMS = GetCMS();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(Type);
	const FCMSSkillRow* TurnSkillRow = CMS->GetCharacterTurnSkillRow(UnitRow, SkillIndex);
	if (!TurnSkillRow)
	{
		Q6JsonLogRoze(Error, "UResultGainSkillWidget::SetTurnSkill - Not found turn skill");
		return;
	}

	SkillNameText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "PromoteSkillGained"), TurnSkillRow->DescName));

	const FSkillAssetRow& AssetRow = GetGameResource().GetSkillAssetRow(UnitRow.Model);
	const FSlateBrush& IconBrush = AssetRow.GetTurnSkillIcon(SkillIndex);
	SkillIconImage->SetBrush(IconBrush);

	PlayAnimation(GainSkillStartAnim);
}

void UResultGainSkillWidget::SetTitleVisible(bool bInVisible)
{
	TitleBorder->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UResultLevelUpWidget::NativeConstruct()
{
	Super::NativeConstruct();

	LevelUpBox = CastChecked<UVerticalBox>(GetWidgetFromName("LevelUp"));
	LevelWidget = CastChecked<UItemLevelWidget>(GetWidgetFromName("Level"));

	HpStatWidget = CastChecked<UStatWidget>(GetWidgetFromName("HpStat"));
	AtkStatWidget = CastChecked<UStatWidget>(GetWidgetFromName("AtkStat"));
	DefStatWidget = CastChecked<UStatWidget>(GetWidgetFromName("DefStat"));

	XpBarWidget = CastChecked<UUpgradeXpBarWidget>(GetWidgetFromName("XpBar"));
	ResultTextWidget = CastChecked<UUpgradeResultTextWidget>(GetWidgetFromName("Result"));

	LevelUpStartAnim = GetWidgetAnimationFromName(this, "AnimLevelUpStart");
}


void UResultLevelUpWidget::SetCharacterAddXpResult(const FCharacterInfo& Info, int32 OldLevel,
	int32 GainXp,
	EUpgradeResultType UpgradeResult)
{
	// Set level and star

	LevelWidget->SetCharacter(Info.Level, Info.Star, Info.Moon);
	LevelWidget->PlayLevelUpAnimation(Info.Level > OldLevel);

	// Set stats

	UCMS* CMS = GetCMS();
	const FUnitType UnitType = CMS->GetUnitType(Info.Type);

	int64 OldHp, OldAtk, OldDef;
	Attribute::GetUnitAttribute(CMS, EAttributeCategory::Character, UnitType, OldLevel, Info.Grade, nullptr, OldHp, OldAtk, OldDef);

	int64 NewHp, NewAtk, NewDef;
	Attribute::GetCharacterAttribute(CMS, Info, NewHp, NewAtk, NewDef);

	HpStatWidget->SetStat(EUnitAttribute::MaxHealth, OldHp, NewHp);
	AtkStatWidget->SetStat(EUnitAttribute::Atk, OldAtk, NewAtk);
	DefStatWidget->SetStat(EUnitAttribute::Def, OldDef, NewDef);

	// Set xp

	int32 TargetLevel = FMath::Min(Info.Level + 1, SystemConstHelper::GetCharacterMaxLevel(Info.Star, Info.Moon));
	const FCMSCharacterXpRow& Row = CMS->GetCharacterXpRowOrDummy(FCharacterXpType(TargetLevel));
	XpBarWidget->SetResultXp(GainXp, Row.Acc - Info.Xp, Row.Req);

	// Set result type

	ResultTextWidget->SetResult(UpgradeResult);

	PlayAnimation(LevelUpStartAnim);
}

void UResultLevelUpWidget::SetRelicAddXpResult(const FRelicInfo& Info, int32 OldLevel,
	int32 GainXp, EUpgradeResultType UpgradeResult)
{
	// Set level and star

	LevelWidget->SetEquip(Info.Level, Info.Star);
	LevelWidget->PlayLevelUpAnimation(Info.Level > OldLevel);

	// Set stats

	UCMS* CMS = GetCMS();

	int64 OldHp, OldAtk, OldDef;
	Attribute::GetRelicAttribute(CMS, Info.Type, OldLevel, Info.Tier, Info.Grade, OldHp, OldAtk, OldDef);

	int64 NewHp, NewAtk, NewDef;
	Attribute::GetRelicAttribute(CMS, Info.Type, Info.Level, Info.Tier, Info.Grade, NewHp, NewAtk, NewDef);

	HpStatWidget->SetStat(EUnitAttribute::MaxHealth, OldHp, NewHp);
	AtkStatWidget->SetStat(EUnitAttribute::Atk, OldAtk, NewAtk);
	DefStatWidget->SetStat(EUnitAttribute::Def, OldDef, NewDef);

	// Set xp

	int32 TargetLevel = FMath::Min(Info.Level + 1, SystemConstHelper::GetEquipMaxLevel(Info.Star));
	const FCMSItemXpRow& Row = CMS->GetItemXpRowOrDummy(FItemXpType(TargetLevel));
	XpBarWidget->SetResultXp(GainXp, Row.Acc - Info.Xp, Row.Req);

	// Set result type

	ResultTextWidget->SetResult(UpgradeResult);

	PlayAnimation(LevelUpStartAnim);
}

void UResultLevelUpWidget::SetSculptureAddXpResult(const FSculptureInfo& Info, int32 OldLevel,
	int32 GainXp, EUpgradeResultType UpgradeResult)
{
	// Set level and star

	LevelWidget->SetEquip(Info.Level, Info.Star);
	LevelWidget->PlayLevelUpAnimation(Info.Level > OldLevel);

	// Set stats

	UCMS* CMS = GetCMS();

	int64 OldHp, OldAtk, OldDef;
	Attribute::GetSculptureAttribute(CMS, Info.Type, OldLevel, Info.Tier, Info.Grade, OldHp, OldAtk, OldDef);

	int64 NewHp, NewAtk, NewDef;
	Attribute::GetSculptureAttribute(CMS, Info.Type, Info.Level, Info.Tier, Info.Grade, NewHp, NewAtk, NewDef);

	HpStatWidget->SetStat(EUnitAttribute::MaxHealth, OldHp, NewHp);
	AtkStatWidget->SetStat(EUnitAttribute::Atk, OldAtk, NewAtk);
	DefStatWidget->SetStat(EUnitAttribute::Def, OldDef, NewDef);

	// Set xp

	int32 TargetLevel = FMath::Min(Info.Level + 1, SystemConstHelper::GetEquipMaxLevel(Info.Star));
	const FCMSItemXpRow& Row = CMS->GetItemXpRowOrDummy(FItemXpType(TargetLevel));
	XpBarWidget->SetResultXp(GainXp, Row.Acc - Info.Xp, Row.Req);

	// Set result type

	ResultTextWidget->SetResult(UpgradeResult);

	PlayAnimation(LevelUpStartAnim);
}

void UResultLevelUpWidget::SetResultVisibles(bool bLevelUpVisible, bool bResultTextVisible)
{
	LevelUpBox->SetVisibility(bLevelUpVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	ResultTextWidget->SetVisibility(bResultTextVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void UResultSkillTierInfoWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UltIconImage = CastChecked<UImage>(GetWidgetFromName("UltIcon"));
	TurnSkillIconImage = CastChecked<UImage>(GetWidgetFromName("TurnSkillIcon"));
	TierIconImage = CastChecked<UImage>(GetWidgetFromName("TierIcon"));
	SkillLevelText = CastChecked<UTextBlock>(GetWidgetFromName("SkillLevel"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	CooltimeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Cooltime"));
	DescText = CastChecked<URichTextBlock>(GetWidgetFromName("Desc"));
}

void UResultSkillTierInfoWidget::SetUltSkill(const FCMSSkillRow& SkillRow, const FSkillAssetRow& AssetRow, int32 Level)
{
	UltIconImage->SetBrush(AssetRow.UltimateIcon);
	SkillLevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(Level)));
	NameText->SetText(SkillRow.DescName);
	DescText->SetText(BuildToolTipDesc(SkillRow.Type, Level, ESkillCategory::Ultimate));

	SetSkillState(ESkillTierUpCategory::Ultimate);
}

void UResultSkillTierInfoWidget::SetTurnSkill(const FCMSSkillRow& SkillRow, const FSlateBrush& SkillIconBrush, int32 Level)
{
	TurnSkillIconImage->SetBrush(SkillIconBrush);
	SkillLevelText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Level"), FText::AsNumber(Level)));
	NameText->SetText(SkillRow.DescName);
	DescText->SetText(BuildToolTipDesc(SkillRow.Type, Level, ESkillCategory::TurnBegin));

	int32 Cooltime = GetCMS()->GetCooltimeByLevel(SkillRow.Type, Level);
	CooltimeText->SetText(FText::AsNumber(Cooltime));

	SetSkillState(ESkillTierUpCategory::TurnSkill);
}

void UResultSkillTierInfoWidget::SetEquipEffect(int32 Tier, const TArray<const FCMSBuffRow*>& Buffs)
{
	TierIconImage->SetBrush(GetUIResource().GetTierIcon(Tier));
	NameText->SetText(Q6Util::GetLocalizedText("Lobby", "EquipmentEffect"));
	DescText->SetText(FText::FromString(GetEquipEffectsStr(Tier, Buffs)));

	SetSkillState(ESkillTierUpCategory::Tier);
}

void UResultSkillTierUpWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BeforeInfoWidget = CastChecked<UResultSkillTierInfoWidget>(GetWidgetFromName("BeforeInfo"));
	AfterInfoWidget = CastChecked<UResultSkillTierInfoWidget>(GetWidgetFromName("AfterInfo"));
	TitleImage = CastChecked<UImage>(GetWidgetFromName("Title"));
	SubTitleText = CastChecked<UTextBlock>(GetWidgetFromName("SubTitle"));
	
	SkillTierUpStartAnim = GetWidgetAnimationFromName(this, "AnimSkillTierUpStart");
}

FText GetSubTitle(ESkillTierUpCategory Category)
{
	switch (Category)
	{
		case ESkillTierUpCategory::TurnSkill:
			return Q6Util::GetLocalizedText("Lobby", "SkillLevelUpSub");
		case ESkillTierUpCategory::Ultimate:
			return Q6Util::GetLocalizedText("Lobby", "UltimateLevelUpSub");
		case ESkillTierUpCategory::Tier:
			return Q6Util::GetLocalizedText("Lobby", "TierUpSub");
	}

	Q6JsonLogRoze(Warning, "GetSubTitle - Invalid category", Q6KV("Category", (int32)Category));
	return FText::GetEmpty();
}

void UResultSkillTierUpWidget::SetUltSkill(FCharacterType CharacterType, int32 OldLevel, int32 NewLevel)
{
	const UCMS* CMS = GetCMS();

	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterType);
	const FCMSSkillRow& SkillRow = CMS->GetCharacterUltimateSkillRow(UnitRow);
	const FSkillAssetRow& AssetRow = GetGameResource().GetSkillAssetRow(UnitRow.Model);

	BeforeInfoWidget->SetUltSkill(SkillRow, AssetRow, OldLevel);
	AfterInfoWidget->SetUltSkill(SkillRow, AssetRow, NewLevel);

	SetTitle(ESkillTierUpCategory::Ultimate);
}

void UResultSkillTierUpWidget::ChangeUltSkill(FCharacterType OldCharacterType, int32 OldLevel, FCharacterType NewCharacterType, int32 NewLevel)
{
	const UCMS* CMS = GetCMS();

	const FCMSUnitRow& BeforeUnitRow = CMS->GetUnitRowOrDummy(OldCharacterType);
	const FCMSSkillRow& BeforeSkillRow = CMS->GetCharacterUltimateSkillRow(BeforeUnitRow);
	const FSkillAssetRow& BeforeAssetRow = GetGameResource().GetSkillAssetRow(BeforeUnitRow.Model);
	BeforeInfoWidget->SetUltSkill(BeforeSkillRow, BeforeAssetRow, OldLevel);

	const FCMSUnitRow& AfterUnitRow = CMS->GetUnitRowOrDummy(NewCharacterType);
	const FCMSSkillRow& AfterSkillRow = CMS->GetCharacterUltimateSkillRow(AfterUnitRow);
	const FSkillAssetRow& AfterAssetRow = GetGameResource().GetSkillAssetRow(AfterUnitRow.Model);
	AfterInfoWidget->SetUltSkill(AfterSkillRow, AfterAssetRow, NewLevel);

	SetTitle(ESkillTierUpCategory::Ultimate);
}

void UResultSkillTierUpWidget::SetTurnSkill(const FCMSSkillRow& SkillRow, int32 ModelType, int32 Index, int32 Level)
{
	const FSkillAssetRow& AssetRow = GetGameResource().GetSkillAssetRow(ModelType);
	const FSlateBrush& SkillIconBrush = AssetRow.GetTurnSkillIcon(Index);
	BeforeInfoWidget->SetTurnSkill(SkillRow, SkillIconBrush, Level - 1);
	AfterInfoWidget->SetTurnSkill(SkillRow, SkillIconBrush, Level);

	SetTitle(ESkillTierUpCategory::TurnSkill);
}

void UResultSkillTierUpWidget::SetRelic(FRelicType RelicType, int32 OldTier, int32 NewTier)
{
	const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(RelicType);
	BeforeInfoWidget->SetEquipEffect(OldTier, RelicRow.GetBuff());
	AfterInfoWidget->SetEquipEffect(NewTier, RelicRow.GetBuff());

	SetTitle(ESkillTierUpCategory::Tier);
}

void UResultSkillTierUpWidget::SetSculpture(FSculptureType SculptureType, int32 OldTier, int32 NewTier)
{
	const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(SculptureType);
	BeforeInfoWidget->SetEquipEffect(OldTier, SculptureRow.GetBuff());
	AfterInfoWidget->SetEquipEffect(NewTier, SculptureRow.GetBuff());

	SetTitle(ESkillTierUpCategory::Tier);
}

void UResultSkillTierUpWidget::SetTitle(ESkillTierUpCategory Category)
{
	int32 TitleIndex = (int32)Category;
	if (TitleBrushes.IsValidIndex(TitleIndex))
	{
		TitleImage->SetBrush(TitleBrushes[TitleIndex]);
	}

	FText SubTitle = GetSubTitle(Category);
	SubTitleText->SetText(SubTitle);

	PlayAnimation(SkillTierUpStartAnim);
}

void UResultMaxUpWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BeforeWidget = CastChecked<UItemLevelWidget>(GetWidgetFromName("BeforeLevel"));
	AfterWidget = CastChecked<UItemLevelWidget>(GetWidgetFromName("AfterLevel"));
	TitleImage = CastChecked<UImage>(GetWidgetFromName("Title"));

	MaxUpStartAnim = GetWidgetAnimationFromName(this, "AnimMaxUpStart");
}

void UResultMaxUpWidget::SetCharacter(EMaxUpCategory Category, const FCharacterInfo& Info)
{
	int32 OldStar = Info.Star;
	int32 OldMoon = Info.Moon;
	if (Info.Moon > 0)
	{
		--OldMoon;
	}
	else
	{
		--OldStar;
	}

	BeforeWidget->SetCharacter(Info.Level, OldStar, OldMoon);
	AfterWidget->SetCharacter(Info.Level, Info.Star, Info.Moon);

	SetMaxUp(Category);
}

void UResultMaxUpWidget::SetEquip(int32 Level, int32 OldStar, int32 NewStar)
{
	BeforeWidget->SetEquip(Level, OldStar);
	AfterWidget->SetEquip(Level, NewStar);

	SetMaxUp(EMaxUpCategory::Promote);
}

void UResultMaxUpWidget::SetMaxUp(EMaxUpCategory Category)
{
	if (TitleBrushes.IsValidIndex((int32)Category))
	{
		TitleImage->SetBrush(TitleBrushes[(int32)Category]);
	}

	BeforeWidget->PlayDefaultAnim();
	AfterWidget->PlayPromoteAnim();

	PlayAnimation(MaxUpStartAnim);
}

UItemLevelUpWidget::UItemLevelUpWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	MaterialMaxCount = 20;

	ItemCategory = EUpgradeCategory::Max;
	MaterialItemWidgets.Reset();
	TargetItemId = 0;
	UpgradeCost = 0;
	bCanAddMaterial = true;
	bSkillUp = false;
	bWaitRefresh = true;
}

void UItemLevelUpWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	EquipCardWidget = CastChecked<UItemBigCardWidget>(GetWidgetFromName("Equip"));
	ItemLabelWidget = CastChecked<UItemLabelWidget>(GetWidgetFromName("ItemLabel"));

	ItemStatWidget = CastChecked<UUpgradeStatWidget>(GetWidgetFromName("ItemStat"));
	ItemStatWidget->SetVisibleStar(false);

	OwnedPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPoint"));
	OwnedPointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);
	RequirePointWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequirePoint"));
	RequirePointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);
	UpgradeText = CastChecked<UTextBlock>(GetWidgetFromName("UpgradeName"));
	UpgradeButton = CastChecked<UButton>(GetWidgetFromName("Upgrade"));
	MaterialItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("MaterialCharacterList"));

	TierUpText = CastChecked<UTextBlock>(GetWidgetFromName("TierUp"));
	ResultTierUpWidget = CastChecked<UUpgradeResultTierWidget>(GetWidgetFromName("ResultTier"));
	ResultSkillUpWidget = CastChecked<UUpgradeResultSkillWidget>(GetWidgetFromName("ResultSkill"));

	SkillNameText = CastChecked<UTextBlock>(GetWidgetFromName("SkillName"));
	UltIconWidget = CastChecked<USkillIconWidget>(GetWidgetFromName("UltIcon"));
	ResultUltUpWidget = CastChecked<UUpgradeResultSkillWidget>(GetWidgetFromName("ResultUlt"));

	SortingWidget = CastChecked<USortingWidget>(GetWidgetFromName("Sorting"));
	SelectActionWidget = CastChecked<UItemSelectActionWidget>(GetWidgetFromName("SelectAction"));
	SelectActionWidget->InitActionMode(true, false, true);
	SelectActionWidget->OnActionModeChangedDelegate.BindUObject(this, &UItemLevelUpWidget::RefreshUI);

	CharacterUpgradeAnim = GetWidgetAnimationFromName(this, "AnimCharacterUpgrade");
	check(CharacterUpgradeAnim);

	EquipUpgradeAnim = GetWidgetAnimationFromName(this, "AnimEquipUpgrade");
	check(EquipUpgradeAnim);

	TierUpgradeAnim = GetWidgetAnimationFromName(this, "AnimTierUpgrade");
	check(TierUpgradeAnim);

	UltimateUpgradeAnim = GetWidgetAnimationFromName(this, "AnimUltimateUpgrade");
	check(UltimateUpgradeAnim);
}

void UItemLevelUpWidget::SetItemLevelUp(EUpgradeCategory Category, int64 InItemId, bool bInit)
{
	ResetUI();

	ItemCategory = Category;
	TargetItemId = InItemId;
	bSkillUp = false;

	// Set selected material count

	FText MaterialCountFormatText = Q6Util::GetLocalizedText("Lobby", "PointAmount");
	SelectActionWidget->SetSelectedCount(0, MaterialMaxCount);

	// Set upgrade button text

	UpgradeText->SetText(Q6Util::GetLocalizedText("Common", "Upgrade"));
	UpgradeButton->OnClicked.Clear();
	UpgradeButton->OnClicked.AddUniqueDynamic(this, &UItemLevelUpWidget::OnAddXpUpgradeButtonClicked);

	switch (ItemCategory)
	{
		case EUpgradeCategory::Character:
			SetCharacterLevelUp(FCharacterId(TargetItemId));
			break;
		case EUpgradeCategory::Relic:
			SetRelicLevelUp(FRelicId(TargetItemId));
			break;
		case EUpgradeCategory::Sculpture:
			SetSculptureLevelUp(FSculptureId(TargetItemId));
			break;
		default:
			break;
	}

	if (bInit)
	{
		SelectActionWidget->SelectDefaultActionMode();
		PlayAnimation(ItemCategory == EUpgradeCategory::Character ? CharacterUpgradeAnim : EquipUpgradeAnim);
	}

	bWaitRefresh = false;
}

void UItemLevelUpWidget::SetEquipTierUp(EUpgradeCategory Category, int64 InItemId, bool bInit)
{
	ResetUI();

	ItemCategory = Category;
	TargetItemId = InItemId;
	bSkillUp = true;

	// Set selected material count

	SelectActionWidget->SetSelectedCount(0);

	UpgradeText->SetText(Q6Util::GetLocalizedText("Common", "TierUpgrade"));
	UpgradeButton->OnClicked.AddUniqueDynamic(this, &UItemLevelUpWidget::OnTierUpgradeButtonClicked);

	switch (ItemCategory)
	{
		case EUpgradeCategory::Relic:
			SetRelicTierUp(FRelicId(TargetItemId));
			break;
		case EUpgradeCategory::Sculpture:
			SetSculptureTierUp(FSculptureId(TargetItemId));
			break;
		default:
			break;
	}

	if (bInit)
	{
		SelectActionWidget->SelectDefaultActionMode();
		PlayAnimation(TierUpgradeAnim);
	}

	bWaitRefresh = false;
}

void UItemLevelUpWidget::SetUltimateUp(const FCharacterId& CharacterId, bool bInit)
{
	ResetUI();

	ItemCategory = EUpgradeCategory::Character;
	TargetItemId = CharacterId.S;
	bSkillUp = true;

	SelectActionWidget->SetSelectedCount(0);

	UpgradeText->SetText(Q6Util::GetLocalizedText("Common", "Upgrade"));
	UpgradeButton->OnClicked.AddUniqueDynamic(this, &UItemLevelUpWidget::OnUltimateUpgradeButtonClicked);

	const FCharacter* TargetCharacter = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!TargetCharacter)
	{
		return;
	}

	// Set character

	const UCMS* CMS = GetCMS();
	const FCharacterInfo& CharacterInfo = TargetCharacter->GetInfo();
	ItemStatWidget->SetCharacter(CharacterInfo);

	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterInfo.Type);
	ItemLabelWidget->SetCharacter(UnitRow.DescName, CharacterInfo.Grade, UnitRow.NatureType, CharacterInfo.Star, CharacterInfo.Moon);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterInfo.Type);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);

	// Set ultimate skill
	const FSkillAssetRow& SillAssetRow = GetGameResource().GetSkillAssetRow(UnitRow.Model);
	const FCMSSkillRow& SkillRow = CMS->GetCharacterUltimateSkillRow(CharacterInfo.Type);
	SkillNameText->SetText(SkillRow.DescName);
	UltIconWidget->SetSkill(SillAssetRow.UltimateIcon, CharacterInfo.UltimateSkillLevel);
	ResultUltUpWidget->SetUltimateSkill(SkillRow, CharacterInfo.UltimateSkillLevel, CharacterInfo.UltimateSkillLevel);

	// Set materials
	MaterialItemListWidget->ClearList();
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();
	TArray<const FCharacter*> MaterialCharacters = CharacterManager.GetCharacters(ESortMenu::UpgradeMaterial, ESortCategory::OwnedCharacter);
	TArray<FCharacterId> UsedCharacterIds = GetHUDStore().GetUsedCharacterIds();

	for (const FCharacter* Character : MaterialCharacters)
	{
		check(Character);

		const FCharacterInfo& MaterialCharacterInfo = Character->GetInfo();
		if (MaterialCharacterInfo.Type != CharacterInfo.Type)
		{
			continue;
		}

		if (MaterialCharacterInfo.CharacterId == CharacterInfo.CharacterId)
		{
			continue;
		}

		UItemCardWidget* CardWidget = CastChecked<UItemCardWidget>(MaterialItemListWidget->AddChildAtLastIndex());
		CardWidget->SetCharacter(MaterialCharacterInfo);
		CardWidget->SetChecked(false);
		CardWidget->SetUsed(UsedCharacterIds.Contains(MaterialCharacterInfo.CharacterId));
		CardWidget->SetUltSkillLevel(MaterialCharacterInfo.UltimateSkillLevel);
		CardWidget->OnItemClickedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemCardClicked);
		CardWidget->OnItemLockedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemLockButtonClicked);

		if (SystemConstHelper::IsWeed(MaterialCharacterInfo))
		{
			CardWidget->SetSelectable(false);
			CardWidget->SetReasonText(Q6Util::GetLocalizedText("Common", "SelectDisable"), EItemSelectableReasonType::NotAvailable);
		}
		else
		{
			SetSelectableCard(CardWidget);
		}
	}

	SortingWidget->SetSorting(ESortMenu::UpgradeMaterial, ESortCategory::OwnedCharacter);

	if (bInit)
	{
		SelectActionWidget->SelectDefaultActionMode();
		PlayAnimation(UltimateUpgradeAnim);
	}

	bWaitRefresh = false;
}

void UItemLevelUpWidget::ResetUI()
{
	ItemCategory = EUpgradeCategory::Max;
	MaterialItemWidgets.Reset();
	TargetItemId = 0;
	UpgradeCost = 0;
	bCanAddMaterial = true;
	bSkillUp = false;
	bWaitRefresh = true;

	// init Gold, White Color(need 2nd param 1)

	OwnedPointWidget->SetCurPoint(GetHUDStore().GetWorldUser().GetGold());
	RequirePointWidget->SetPoint(0, 1);

	UpgradeButton->SetIsEnabled(false);
	UpgradeButton->OnClicked.Clear();
}

void UItemLevelUpWidget::RefreshUI()
{
	if (!bSkillUp)
	{
		SetItemLevelUp(ItemCategory, TargetItemId, false);
		return;
	}

	if (ItemCategory == EUpgradeCategory::Character)
	{
		SetUltimateUp(FCharacterId(TargetItemId), false);
	}
	else
	{
		SetEquipTierUp(ItemCategory, TargetItemId, false);
	}
}

void UItemLevelUpWidget::SetCharacterLevelUp(const FCharacterId& CharacterId)
{
	const FCharacter* TargetCharacter = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!TargetCharacter)
	{
		return;
	}

	const FCharacterInfo& CharacterInfo = TargetCharacter->GetInfo();
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(CharacterInfo.Type);
	ItemLabelWidget->SetCharacter(UnitRow.DescName, CharacterInfo.Grade, UnitRow.NatureType, CharacterInfo.Star, CharacterInfo.Moon);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterInfo.Type);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);

	ItemStatWidget->SetCharacter(CharacterInfo);

	// Set materials
	MaterialItemListWidget->ClearList();
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();
	TArray<const FCharacter*> MaterialCharacters = CharacterManager.GetCharacters(ESortMenu::UpgradeMaterial, ESortCategory::OwnedCharacterWithExp);
	TArray<FCharacterId> UsedCharacterIds = GetHUDStore().GetUsedCharacterIds();

	for (const FCharacter* Character : MaterialCharacters)
	{
		check(Character);

		const FCharacterInfo& MaterialCharacterInfo = Character->GetInfo();
		if (MaterialCharacterInfo.CharacterId == CharacterInfo.CharacterId)
		{
			continue;
		}

		UItemCardWidget* CardWidget = CastChecked<UItemCardWidget>(MaterialItemListWidget->AddChildAtLastIndex());
		CardWidget->SetCharacter(MaterialCharacterInfo);
		CardWidget->SetChecked(false);
		CardWidget->SetUsed(UsedCharacterIds.Contains(MaterialCharacterInfo.CharacterId));
		CardWidget->OnItemClickedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemCardClicked);
		CardWidget->OnItemLockedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemLockButtonClicked);

		if (SystemConstHelper::IsWeed(MaterialCharacterInfo))
		{
			CardWidget->SetSelectable(false);
			CardWidget->SetReasonText(Q6Util::GetLocalizedText("Common", "SelectDisable"), EItemSelectableReasonType::NotAvailable);
		}
		else
		{
			SetSelectableCard(CardWidget, CharacterInfo.Type.x);
		}
	}

	SortingWidget->SetSorting(ESortMenu::UpgradeMaterial, ESortCategory::OwnedCharacterWithExp);
}

void UItemLevelUpWidget::SetRelicLevelUp(const FRelicId& RelicId)
{
	const FRelic* TargetRelic = GetHUDStore().GetRelicManager().Find(RelicId);
	if (!TargetRelic)
	{
		return;
	}

	const FRelicInfo& RelicInfo = TargetRelic->Info;
	SetRelic(RelicInfo);

	// Set materials

	MaterialItemListWidget->ClearList();
	const URelicManager& RelicManager = GetHUDStore().GetRelicManager();
	TArray<const FRelic*> MaterialRelics = RelicManager.GetRelics(ESortMenu::UpgradeMaterial, ESortCategory::OwnedRelicWithExp);
	TArray<FRelicId> UsedRelicId = GetHUDStore().GetUsedRelicIds();

	for (const FRelic* Relic : MaterialRelics)
	{
		check(Relic);

		const FRelicInfo& MaterialRelicInfo = Relic->Info;
		if (MaterialRelicInfo.RelicId == RelicInfo.RelicId)
		{
			continue;
		}

		UItemCardWidget* CardWidget = CastChecked<UItemCardWidget>(MaterialItemListWidget->AddChildAtLastIndex());
		CardWidget->SetRelic(MaterialRelicInfo);
		CardWidget->SetChecked(false);
		CardWidget->SetUsed(UsedRelicId.Contains(MaterialRelicInfo.RelicId));
		CardWidget->OnItemClickedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemCardClicked);
		CardWidget->OnItemLockedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemLockButtonClicked);

		SetSelectableCard(CardWidget, RelicInfo.Type.x);
	}

	SortingWidget->SetSorting(ESortMenu::UpgradeMaterial, ESortCategory::OwnedRelicWithExp);
}

void UItemLevelUpWidget::SetSculptureLevelUp(const FSculptureId& SculptureId)
{
	const FSculpture* TargetSculpture = GetHUDStore().GetSculptureManager().Find(SculptureId);
	if (!TargetSculpture)
	{
		return;
	}

	const FSculptureInfo& SculptureInfo = TargetSculpture->Info;
	SetSculpture(SculptureInfo);

	// Set materials

	MaterialItemListWidget->ClearList();

	const USculptureManager& SculptureManager = GetHUDStore().GetSculptureManager();
	TArray<const FSculpture*> MaterialSculptures = SculptureManager.GetSculptures(ESortMenu::UpgradeMaterial, ESortCategory::OwnedSculptureWithExp);
	TArray<FSculptureId> UsedSculptureIds = GetHUDStore().GetUsedSculptureIds();

	for (const FSculpture* Sculpture : MaterialSculptures)
	{
		check(Sculpture);

		const FSculptureInfo& MaterialSculptureInfo = Sculpture->Info;
		if (MaterialSculptureInfo.SculptureId == SculptureInfo.SculptureId)
		{
			continue;
		}

		UItemCardWidget* CardWidget = CastChecked<UItemCardWidget>(MaterialItemListWidget->AddChildAtLastIndex());
		CardWidget->SetSculpture(MaterialSculptureInfo);
		CardWidget->SetChecked(false);
		CardWidget->SetUsed(UsedSculptureIds.Contains(MaterialSculptureInfo.SculptureId));
		CardWidget->OnItemClickedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemCardClicked);
		CardWidget->OnItemLockedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemLockButtonClicked);

		SetSelectableCard(CardWidget, SculptureInfo.Type.x);
	}

	SortingWidget->SetSorting(ESortMenu::UpgradeMaterial, ESortCategory::OwnedSculptureWithExp);
}

void UItemLevelUpWidget::SetRelicTierUp(const FRelicId& RelicId)
{
	const FRelic* TargetRelic = GetHUDStore().GetRelicManager().Find(RelicId);
	if (!TargetRelic)
	{
		return;
	}

	const FRelicInfo& RelicInfo = TargetRelic->Info;
	SetRelic(RelicInfo);
	SetTierUpResult(EUpgradeCategory::Relic, RelicInfo.Type.x, RelicInfo.Tier);

	// Set materials

	MaterialItemListWidget->ClearList();
	const URelicManager& RelicManager = GetHUDStore().GetRelicManager();
	TArray<const FRelic*> MaterialRelics = RelicManager.GetRelics(ESortMenu::UpgradeMaterial, ESortCategory::OwnedRelic);
	TArray<FRelicId> UsedRelicId = GetHUDStore().GetUsedRelicIds();

	for (const FRelic* Relic : MaterialRelics)
	{
		check(Relic);

		const FRelicInfo& MaterialRelicInfo = Relic->Info;
		if (MaterialRelicInfo.Type != RelicInfo.Type)
		{
			continue;
		}

		if (MaterialRelicInfo.RelicId == RelicInfo.RelicId)
		{
			continue;
		}

		UItemCardWidget* CardWidget = CastChecked<UItemCardWidget>(MaterialItemListWidget->AddChildAtLastIndex());
		CardWidget->SetRelic(MaterialRelicInfo);
		CardWidget->SetChecked(false);
		CardWidget->SetUsed(UsedRelicId.Contains(MaterialRelicInfo.RelicId));
		CardWidget->OnItemClickedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemCardClicked);
		CardWidget->OnItemLockedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemLockButtonClicked);

		SetSelectableCard(CardWidget);
	}

	SortingWidget->SetSorting(ESortMenu::UpgradeMaterial, ESortCategory::OwnedRelic);
}

void UItemLevelUpWidget::SetSculptureTierUp(const FSculptureId& SculptureId)
{
	const FSculpture* TargetSculpture = GetHUDStore().GetSculptureManager().Find(SculptureId);
	if (!TargetSculpture)
	{
		return;
	}

	const FSculptureInfo& SculptureInfo = TargetSculpture->Info;
	SetSculpture(SculptureInfo);
	SetTierUpResult(EUpgradeCategory::Sculpture, SculptureInfo.Type.x, SculptureInfo.Tier);

	// Set materials

	MaterialItemListWidget->ClearList();
	const USculptureManager& SculptureManager = GetHUDStore().GetSculptureManager();
	TArray<const FSculpture*> MaterialSculptures = SculptureManager.GetSculptures(ESortMenu::UpgradeMaterial, ESortCategory::OwnedSculpture);
	TArray<FSculptureId> UsedSculptureIds = GetHUDStore().GetUsedSculptureIds();

	for (const FSculpture* Sculpture : MaterialSculptures)
	{
		check(Sculpture);

		const FSculptureInfo& MaterialSculptureInfo = Sculpture->Info;
		if (MaterialSculptureInfo.Type != SculptureInfo.Type)
		{
			continue;
		}

		if (MaterialSculptureInfo.SculptureId == SculptureInfo.SculptureId)
		{
			continue;
		}

		UItemCardWidget* CardWidget = CastChecked<UItemCardWidget>(MaterialItemListWidget->AddChildAtLastIndex());
		CardWidget->SetSculpture(MaterialSculptureInfo);
		CardWidget->SetChecked(false);
		CardWidget->SetUsed(UsedSculptureIds.Contains(MaterialSculptureInfo.SculptureId));
		CardWidget->OnItemClickedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemCardClicked);
		CardWidget->OnItemLockedDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemLockButtonClicked);

		SetSelectableCard(CardWidget);
	}

	SortingWidget->SetSorting(ESortMenu::UpgradeMaterial, ESortCategory::OwnedSculpture);

	PlayAnimation(TierUpgradeAnim);
}

void UItemLevelUpWidget::SetRelic(const FRelicInfo& RelicInfo)
{
	const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(RelicInfo.Type);
	ItemLabelWidget->SetEquip(RelicRow.DescName, RelicInfo.Grade, RelicInfo.Star, RelicInfo.Tier);
	EquipCardWidget->SetRelic(RelicInfo.Type);
	ItemStatWidget->SetRelic(RelicInfo, 0, 0);
}

void UItemLevelUpWidget::SetSculpture(const FSculptureInfo& SculptureInfo)
{
	const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(SculptureInfo.Type);
	ItemLabelWidget->SetEquip(SculptureRow.DescName, SculptureInfo.Grade, SculptureInfo.Star, SculptureInfo.Tier);
	EquipCardWidget->SetSculpture(SculptureInfo.Type);
	ItemStatWidget->SetSculpture(SculptureInfo, 0, 0);
}

void UItemLevelUpWidget::SetSelectedItemCard(UItemCardWidget* ClickedItemWidget, int32 TargetItemType)
{
	if (SelectActionWidget->GetSelectedActionType() == EItemActionType::Lock)
	{
		ClickedItemWidget->SetToggleLocked();

		const FItemIconInfo& ItemInfo = ClickedItemWidget->GetItemInfo();
		GetHUDStore().ReqSetLock(ItemInfo.AttributeType, ItemInfo.Id, ItemInfo.bLocked);
		return;
	}

	if (MaterialItemWidgets.Contains(ClickedItemWidget))
	{
		// Deselect material character

		ClickedItemWidget->SetChecked(false);
		MaterialItemWidgets.Remove(ClickedItemWidget);
	}
	else
	{
		// Select material character

		if (MaterialItemWidgets.Num() == MaterialMaxCount)
		{
			GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "MaxCountSelected"));
			return;
		}

		if (!bCanAddMaterial)
		{
			GetCheckedLobbyHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "IsAlreadyMaxLevel"));
			return;
		}

		ClickedItemWidget->SetChecked(true);
		MaterialItemWidgets.AddUnique(ClickedItemWidget);
	}

	if (!bSkillUp)
	{
		SelectActionWidget->SetSelectedCount(MaterialItemWidgets.Num(), MaterialMaxCount);
	}
	else
	{
		SelectActionWidget->SetSelectedCount(MaterialItemWidgets.Num());
	}

	SetSelectableCard(ClickedItemWidget);
}

void UItemLevelUpWidget::SetSelectableCard(UItemCardWidget* ItemCard, int32 TargetItemType)
{
	if (SelectActionWidget->GetSelectedActionType() == EItemActionType::Lock)
	{
		ItemCard->SetSelectable(true);
		return;
	}

	const FItemIconInfo& ItemInfo = ItemCard->GetItemInfo();

	FText Reason = FText::GetEmpty();
	if (ItemInfo.bLocked)
	{
		Reason = Q6Util::GetLocalizedText("Common", "Locked");
	}

	if (ItemInfo.bUsed)
	{
		Reason = Q6Util::GetLocalizedText("Common", "UsedMember");
	}

	if (ItemInfo.Type == TargetItemType)
	{
		switch (ItemInfo.AttributeType) {
			case EAttributeCategory::Character:
				Reason = Q6Util::GetLocalizedText("Common", "EqualTypeCharacter");
				break;

			case EAttributeCategory::Relic:
				Reason = Q6Util::GetLocalizedText("Common", "EqualTypeRelic");
				break;
			
			case EAttributeCategory::Sculpture:
				Reason = Q6Util::GetLocalizedText("Common", "EqualTypeSculpture");
				break;
		}
	}

	ItemCard->SetSelectable(Reason.IsEmpty());
	ItemCard->SetReasonText(Reason, EItemSelectableReasonType::NotAvailable);
}

TArray<int64> UItemLevelUpWidget::GatherMaterialItemIds()
{
	TArray<int64> ItemIds;
	for (UItemCardWidget* ItemWidget : MaterialItemWidgets)
	{
		check(ItemWidget);
		ItemIds.AddUnique(ItemWidget->GetItemId());
	}

	return ItemIds;
}

void UItemLevelUpWidget::OnAddXpUpgradeButtonClicked()
{
	// Open confirm pop-up
	TUTORIAL_MONITORING_BUTTON_CLICK("AddXpUpgrade");
	UItemListPopupWidget* ItemListPopup = GetCheckedLobbyHUD(this)->OpenItemListPopup(ItemCategory, GatherMaterialItemIds());
	check(ItemListPopup);

	const FText Title = Q6Util::GetLocalizedText("Lobby", "UpgradeReally");
	FString ContentStr = Q6Util::GetLocalizedText("Lobby", "ConsumeMaterial").ToString();
	if (HasPreciousItem(GetCMS(), ItemCategory, GatherMaterialItemIds()))
	{
		const FText Content = Q6Util::GetLocalizedText("Lobby", "HasPreciousItem");
		ContentStr.Append(TEXT("\r\n"));
		ContentStr.Append(Content.ToString());
	}

	ItemListPopup->SetTitle(Title);
	ItemListPopup->SetContent(FText::FromString(ContentStr));
	ItemListPopup->SetYesButtonName(Q6Util::GetLocalizedText("Common", "Upgrade"));
	ItemListPopup->SetCost(GetHUDStore().GetWorldUser().GetGold(), UpgradeCost);
	ItemListPopup->PlayUpgradeAnimation(EUpgradeAnimType::Default);
	ItemListPopup->OnConfirmPopupDelegate.BindUObject(this, &UItemLevelUpWidget::OnItemLevelUp);
}

void UItemLevelUpWidget::OnTierUpgradeButtonClicked()
{
	// Open confirm pop-up

	int32 BaseTier = 0;
	if (ItemCategory == EUpgradeCategory::Relic)
	{
		const FRelic* Relic = GetHUDStore().GetRelicManager().Find(FRelicId(TargetItemId));
		if (Relic)
		{
			BaseTier = Relic->Info.Tier;
		}
	}
	else if (ItemCategory == EUpgradeCategory::Sculpture)
	{
		const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(FSculptureId(TargetItemId));
		if (Sculpture)
		{
			BaseTier = Sculpture->Info.Tier;
		}
	}

	UItemListPopupWidget* ItemListPopup = GetCheckedLobbyHUD(this)->OpenItemListPopup(ItemCategory, GatherMaterialItemIds());
	check(ItemListPopup);

	const FText Title = Q6Util::GetLocalizedText("Lobby", "TierUpgradeReally");
	FString ContentStr = Q6Util::GetLocalizedText("Lobby", "ConsumeMaterial").ToString();
	if (HasHighTierEquip(GetCMS(), ItemCategory, BaseTier, GatherMaterialItemIds()))
	{
		const FText Content = Q6Util::GetLocalizedText("Lobby", "HasHighTierEquip");
		ContentStr.Append(TEXT("\r\n"));
		ContentStr.Append(Content.ToString());
	}

	ItemListPopup->SetTitle(Title);
	ItemListPopup->SetContent(FText::FromString(ContentStr));
	ItemListPopup->SetYesButtonName(Q6Util::GetLocalizedText("Common", "TierUpgrade"));
	ItemListPopup->SetTierUpResult(BaseTier, GetTargetTier(ItemCategory, BaseTier));
	ItemListPopup->SetCost(GetHUDStore().GetWorldUser().GetGold(), UpgradeCost);
	ItemListPopup->PlayUpgradeAnimation(EUpgradeAnimType::TierUp);
	ItemListPopup->OnConfirmPopupDelegate.BindUObject(this, &UItemLevelUpWidget::OnEquipTierUp);
}

void UItemLevelUpWidget::OnUltimateUpgradeButtonClicked()
{
	// Open confirm pop-up

	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(FCharacterId(TargetItemId));
	if (!Character)
	{
		Q6JsonLogRoze(Error, "UItemLevelUpWidget::OnUltimateUpgradeButtonClicked - Not found character", Q6KV("CharacterId", TargetItemId));
		return;
	}

	const FCharacterInfo& CharacterInfo = Character->GetInfo();
	int32 BaseLevel = CharacterInfo.UltimateSkillLevel;

	UItemListPopupWidget* ItemListPopup = GetCheckedLobbyHUD(this)->OpenItemListPopup(EUpgradeCategory::Character, GatherMaterialItemIds(), true);
	check(ItemListPopup);

	const FText Title = Q6Util::GetLocalizedText("Lobby", "UltimateUpgradeConfirm");
	FString ContentStr = Q6Util::GetLocalizedText("Lobby", "ConsumeMaterial").ToString();
	if (HasHighUltLevel(GetCMS(), BaseLevel, GatherMaterialItemIds()))
	{
		const FText Content = Q6Util::GetLocalizedText("Lobby", "HasHighUltimateLevel");
		ContentStr.Append(TEXT("\r\n"));
		ContentStr.Append(Content.ToString());
	}

	ItemListPopup->SetTitle(Title);
	ItemListPopup->SetContent(FText::FromString(ContentStr));
	ItemListPopup->SetYesButtonName(Q6Util::GetLocalizedText("Common", "Upgrade"));
	ItemListPopup->SetUltUpResult(CharacterInfo.Type, BaseLevel, GetTargetUltLevel(BaseLevel));
	ItemListPopup->SetCost(GetHUDStore().GetWorldUser().GetGold(), UpgradeCost);
	ItemListPopup->PlayUpgradeAnimation(EUpgradeAnimType::LevelUp);
	ItemListPopup->OnConfirmPopupDelegate.BindUObject(this, &UItemLevelUpWidget::OnUltLevelUp);
}

void UItemLevelUpWidget::OnItemLevelUp(EConfirmPopupFlag Flag)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	FString UpgradeRequestString = FString::Printf(TEXT("UpgradeRequest_%s"), *ENUM_TO_STRING(EUpgradeCategory, ItemCategory));
	TUTORIAL_MONITORING_BUTTON_CLICK(UpgradeRequestString);

	// Clear ui
	GetCheckedLobbyHUD(this)->CloseAllPopups();

	const TArray<int64> MaterialIds = GatherMaterialItemIds();
	if (ItemCategory == EUpgradeCategory::Character)
	{
		GetHUDStore().GetCharacterManager().ReqAddXp(FCharacterId(TargetItemId), MaterialIds);
	}
	else if (ItemCategory == EUpgradeCategory::Relic)
	{
		GetHUDStore().GetRelicManager().ReqAddXp(FRelicId(TargetItemId), MaterialIds);
	}
	else if (ItemCategory == EUpgradeCategory::Sculpture)
	{
		GetHUDStore().GetSculptureManager().ReqAddXp(FSculptureId(TargetItemId), MaterialIds);
	}
}

void UItemLevelUpWidget::OnEquipTierUp(EConfirmPopupFlag Flag)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	// Clear ui
	GetCheckedLobbyHUD(this)->CloseAllPopups();

	const TArray<int64> MaterialIds = GatherMaterialItemIds();
	if (ItemCategory == EUpgradeCategory::Relic)
	{
		GetHUDStore().GetRelicManager().ReqTierUp(FRelicId(TargetItemId), MaterialIds);
	}
	else if (ItemCategory == EUpgradeCategory::Sculpture)
	{
		GetHUDStore().GetSculptureManager().ReqTierUp(FSculptureId(TargetItemId), MaterialIds);
	}
}

void UItemLevelUpWidget::OnUltLevelUp(EConfirmPopupFlag Flag)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	// Clear ui
	GetCheckedLobbyHUD(this)->CloseAllPopups();

	const TArray<int64> MaterialIds = GatherMaterialItemIds();
	GetHUDStore().GetCharacterManager().ReqUpgradeUltimateSkillLevel(FCharacterId(TargetItemId), MaterialIds);
}

void UItemLevelUpWidget::OnItemCardClicked(UItemCardWidget* ClickedItemWidget)
{
	if (bWaitRefresh)
	{
		Q6JsonLogRoze(Warning, "UItemLevelUpWidget::OnItemCardClicked - Ui refreshing now");
		return;
	}

	switch (ItemCategory)
	{
		case EUpgradeCategory::Character: OnCharacterMaterialCardClicked(ClickedItemWidget); return;
		case EUpgradeCategory::Sculpture: OnSculptureMaterialCardClicked(ClickedItemWidget); return;
		case EUpgradeCategory::Relic:	  OnRelicMaterialCardClicked(ClickedItemWidget); return;
	}
}

void UItemLevelUpWidget::OnCharacterMaterialCardClicked(UItemCardWidget* ClickedItemWidget)
{
	TUTORIAL_MONITORING_BUTTON_CLICK("CharacterMaterialItemCard");
	const FCharacter* TargetChar = GetHUDStore().GetCharacterManager().Find(FCharacterId(TargetItemId));
	if (!TargetChar)
	{
		Q6JsonLogRoze(Warning, "UItemLevelUpWidget::OnRelicMaterialCardClicked - Not found character", Q6KV("CharacterId", TargetItemId));
		return;
	}

	const FCharacterInfo& CharacterInfo = TargetChar->GetInfo();
	SetSelectedItemCard(ClickedItemWidget, CharacterInfo.Type.x);
	SetCharacterGainXP();

	if (bSkillUp)
	{
		SetUltimateUpResult(CharacterInfo);
		SetUltimateSkillUpCost(CharacterInfo.UltimateSkillLevel);
	}
	else
	{
		SetCharacterAddXpCost(CharacterInfo);
	}
}

void UItemLevelUpWidget::OnRelicMaterialCardClicked(UItemCardWidget* ClickedItemWidget)
{
	const FRelic* TargetRelic = GetHUDStore().GetRelicManager().Find(FRelicId(TargetItemId));
	if (!TargetRelic)
	{
		Q6JsonLogRoze(Warning, "UItemLevelUpWidget::OnRelicMaterialCardClicked - Not found relic", Q6KV("RelicId", TargetItemId));
		return;
	}

	const FRelicInfo& RelicInfo = TargetRelic->GetInfo();
	SetSelectedItemCard(ClickedItemWidget, RelicInfo.Type.x);
	SetRelicGainXp();

	if (bSkillUp)
	{
		SetTierUpResult(EUpgradeCategory::Relic, RelicInfo.Type, RelicInfo.Tier);
		SetRelicTierUpCost(RelicInfo.Tier);
	}
	else
	{
		SetRelicAddXpCost(RelicInfo);
	}
}

void UItemLevelUpWidget::OnSculptureMaterialCardClicked(UItemCardWidget* ClickedItemWidget)
{
	const FSculpture* TargetSculpture = GetHUDStore().GetSculptureManager().Find(FSculptureId(TargetItemId));
	if (!TargetSculpture)
	{
		Q6JsonLogRoze(Warning, "UItemLevelUpWidget::OnSculptureMaterialCardClicked - Not found sculpture", Q6KV("SculptureId", TargetItemId));
		return;
	}

	const FSculptureInfo& SculptureInfo = TargetSculpture->GetInfo();
	SetSelectedItemCard(ClickedItemWidget, SculptureInfo.Type.x);
	SetSculptureGainXp();

	if (bSkillUp)
	{
		SetTierUpResult(EUpgradeCategory::Sculpture, SculptureInfo.Type, SculptureInfo.Tier);
		SetSculptureTierUpCost(SculptureInfo.Tier);
	}
	else
	{
		SetSculptureAddXpCost(SculptureInfo);
	}
}

void UItemLevelUpWidget::OnItemLockButtonClicked(UItemCardWidget* ChangeLockedCardWidget)
{
	SetSelectableCard(ChangeLockedCardWidget);

	bool bSelectMode = SelectActionWidget->GetSelectedActionType() == EItemActionType::Select;
	bool bCheckedCard = MaterialItemWidgets.Contains(ChangeLockedCardWidget);
	bool bLocked = ChangeLockedCardWidget->GetItemInfo().bLocked;

	if (bSelectMode && bCheckedCard && bLocked)
	{
		// Remove material card

		OnItemCardClicked(ChangeLockedCardWidget);
	}
}

void UItemLevelUpWidget::SetCharacterGainXP()
{
	int32 TotalGainXP = 0;

	auto& CharMgr = GetHUDStore().GetCharacterManager();
	UCMS* CMS = GetCMS();

	const FCharacter* UpgradeCharacter = CharMgr.Find(FCharacterId(TargetItemId));
	if (!UpgradeCharacter)
	{
		return;
	}

	const FCharacterInfo& UpgradeCharacterInfo = UpgradeCharacter->GetInfo();
	ENatureType UpgradeNatrueType = CMS->GetUnitRowOrDummy(UpgradeCharacterInfo.Type).NatureType;
	for (UItemCardWidget* ItemWidget : MaterialItemWidgets)
	{
		const FCharacter* Character = CharMgr.Find(FCharacterId(ItemWidget->GetItemId()));
		if (!Character)
		{
			continue;
		}

		const FCharacterInfo& CharacterInfo = Character->GetInfo();
		if (UpgradeCharacterInfo.Level >= SystemConstHelper::GetCharacterMaxLevel(UpgradeCharacterInfo.Star, UpgradeCharacterInfo.Moon))
		{
			continue;
		}

		const FCMSCharacterRow& CharacterRow = CMS->GetCharacterRowOrDummy(CharacterInfo.Type);
		const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterInfo.Type);

		int32 BaseXP = SystemConstHelper::GetCharacterBaseXP(CharacterRow.XpExclusive);
		int32 MultiplierXp = SystemConstHelper::GetCharacterMultiplierGradeXP(CharacterInfo.Grade, CharacterRow.XpExclusive);
		int32 GainXP = (BaseXP * MultiplierXp) + (CharacterInfo.Xp * CharacterFormulaConst::Q6_POSSESSION_EXP_RATIO / 100);
		float BonusRatio = (UpgradeNatrueType == UnitRow.NatureType || UnitRow.NatureType == ENatureType::All) ? CMS->GetCharacterNatureTypeBonusRatio() : 0.0f;
		TotalGainXP += (GainXP + (GainXP * BonusRatio));
	}

	ItemStatWidget->SetCharacter(UpgradeCharacterInfo, TotalGainXP);

	int32 UpgradeLevel = CMS->GetCharacterLevelFromXP(UpgradeCharacterInfo.Xp + TotalGainXP);
	bCanAddMaterial = (UpgradeLevel < SystemConstHelper::GetCharacterMaxLevel(UpgradeCharacterInfo.Star, UpgradeCharacterInfo.Moon));
}

void UItemLevelUpWidget::SetRelicGainXp()
{
	int32 TotalGainXP = 0;

	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	UCMS* CMS = GetCMS();

	const FRelic* UpgradeRelic = RelicMgr.Find(FRelicId(TargetItemId));
	if (!UpgradeRelic)
	{
		return;
	}

	int32 AddTier = 0;
	for (UItemCardWidget* ItemWidget : MaterialItemWidgets)
	{
		const FRelic* Relic = RelicMgr.Find(FRelicId(ItemWidget->GetItemId()));
		if (!Relic)
		{
			continue;
		}

		const FRelicInfo& RelicInfo = Relic->Info;
		if (bSkillUp)
		{
			AddTier += RelicInfo.Tier;
		}

		if (UpgradeRelic->Info.Level >= SystemConstHelper::GetEquipMaxLevel(UpgradeRelic->Info.Star))
		{
			continue;
		}

		const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(RelicInfo.Type);
		int32 BaseXP = RelicRow.XpExclusive ? SystemConstHelper::GetEquipExclusiveBaseXP() : SystemConstHelper::GetEquipBaseXP();
		int32 MultiplierXp = RelicRow.XpExclusive
			? SystemConstHelper::GetEquipMultiplierExclusiveGradeXP(RelicInfo.Grade)
			: SystemConstHelper::GetEquipMultiplierGradeXP(RelicInfo.Grade);
		TotalGainXP += (BaseXP * MultiplierXp) + (RelicInfo.Xp * EquipFormulaConst::Q6_EQUIP_POSSESSION_EXP_RATIO / 100);
	}

	ItemStatWidget->SetRelic(UpgradeRelic->Info, TotalGainXP, AddTier);

	int32 UpgradeLevel = CMS->GetEquipLevelFromXP(UpgradeRelic->Info.Xp + TotalGainXP);
	bCanAddMaterial = (UpgradeLevel < SystemConstHelper::GetEquipMaxLevel(UpgradeRelic->Info.Star));
}

void UItemLevelUpWidget::SetSculptureGainXp()
{
	int32 TotalGainXP = 0;

	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	UCMS* CMS = GetCMS();

	const FSculpture* UpgradeSculpture = SculptureMgr.Find(FSculptureId(TargetItemId));
	if (!UpgradeSculpture)
	{
		return;
	}

	int32 AddTier = 0;
	for (UItemCardWidget* ItemWidget : MaterialItemWidgets)
	{
		const FSculpture* Sculpture = SculptureMgr.Find(FSculptureId(ItemWidget->GetItemId()));
		if (!Sculpture)
		{
			continue;
		}

		const FSculptureInfo& SculptureInfo = Sculpture->Info;
		if (bSkillUp)
		{
			AddTier += SculptureInfo.Tier;
		}

		if (UpgradeSculpture->Info.Level >= SystemConstHelper::GetEquipMaxLevel(UpgradeSculpture->Info.Star))
		{
			continue;
		}

		const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(SculptureInfo.Type);
		int32 BaseXP = SculptureRow.XpExclusive
			? SystemConstHelper::GetEquipExclusiveBaseXP()
			: SystemConstHelper::GetEquipBaseXP();
		int32 MultiplierXp = SculptureRow.XpExclusive
			? SystemConstHelper::GetEquipMultiplierExclusiveGradeXP(SculptureInfo.Grade)
			: SystemConstHelper::GetEquipMultiplierGradeXP(SculptureInfo.Grade);
		TotalGainXP += (BaseXP * MultiplierXp) + (SculptureInfo.Xp * EquipFormulaConst::Q6_EQUIP_POSSESSION_EXP_RATIO / 100);
	}

	ItemStatWidget->SetSculpture(UpgradeSculpture->Info, TotalGainXP, AddTier);

	int32 UpgradeLevel = CMS->GetEquipLevelFromXP(UpgradeSculpture->Info.Xp + TotalGainXP);
	bCanAddMaterial = (UpgradeLevel < SystemConstHelper::GetEquipMaxLevel(UpgradeSculpture->Info.Star));
}

void UItemLevelUpWidget::SetGoldCost()
{
	int64 UserGold = GetHUDStore().GetWorldUser().GetGold();
	RequirePointWidget->SetPoint(UpgradeCost, UserGold);

	bool bNotEnoughGold = (UpgradeCost > UserGold);
	UpgradeButton->SetIsEnabled(!bNotEnoughGold && (MaterialItemWidgets.Num() > 0));
}

void UItemLevelUpWidget::SetCharacterAddXpCost(const FCharacterInfo& TargetInfo)
{
	UpgradeCost = 0;

	const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();
	int32 UpgradeOnceCost = SystemConstHelper::GetCharacterAddXpCost(TargetInfo.Grade, TargetInfo.Level);

	for (int32 i = 0; i < MaterialItemWidgets.Num(); ++i)
	{
		UItemCardWidget* ItemWidget = MaterialItemWidgets[i];
		const FCharacter* Character = CharMgr.Find(FCharacterId(ItemWidget->GetItemId()));
		if (!Character)
		{
			continue;
		}

		ItemWidget->SetNumber(i + 1);
		UpgradeCost += UpgradeOnceCost;
	}

	SetGoldCost();
}

void UItemLevelUpWidget::SetRelicAddXpCost(const FRelicInfo& TargetInfo)
{
	UpgradeCost = 0;

	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	int32 UpgradeOnceCost = SystemConstHelper::GetEquipAddXpCost(TargetInfo.Grade, TargetInfo.Level);

	for (int32 i = 0; i < MaterialItemWidgets.Num(); ++i)
	{
		UItemCardWidget* ItemWidget = MaterialItemWidgets[i];
		const FRelic* Relic = RelicMgr.Find(FRelicId(ItemWidget->GetItemId()));
		if (!Relic)
		{
			continue;
		}

		ItemWidget->SetNumber(i + 1);
		UpgradeCost += UpgradeOnceCost;
	}

	SetGoldCost();
}

void UItemLevelUpWidget::SetSculptureAddXpCost(const FSculptureInfo& TargetInfo)
{
	UpgradeCost = 0;

	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	int32 UpgradeOnceCost = SystemConstHelper::GetEquipAddXpCost(TargetInfo.Grade, TargetInfo.Level);

	for (int32 i = 0; i < MaterialItemWidgets.Num(); ++i)
	{
		UItemCardWidget* ItemWidget = MaterialItemWidgets[i];
		const FSculpture* Sculpture = SculptureMgr.Find(FSculptureId(ItemWidget->GetItemId()));
		if (!Sculpture)
		{
			continue;
		}

		ItemWidget->SetNumber(i + 1);
		UpgradeCost += UpgradeOnceCost;
	}

	SetGoldCost();
}

void UItemLevelUpWidget::SetUltimateSkillUpCost(int32 CurrentLevel)
{
	const UCharacterManager& CharMgr = GetHUDStore().GetCharacterManager();
	UCMS* CMS = GetCMS();
	int32 TargetLevel = CurrentLevel;
	for (int32 i = 0; i < MaterialItemWidgets.Num(); ++i)
	{
		UItemCardWidget* ItemWidget = MaterialItemWidgets[i];
		const FCharacter* Character = CharMgr.Find(FCharacterId(ItemWidget->GetItemId()));
		if (!Character)
		{
			continue;
		}

		ItemWidget->SetNumber(i + 1);
		TargetLevel += Character->GetInfo().UltimateSkillLevel;
	}

	TargetLevel = FMath::Min(TargetLevel, CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);
	bCanAddMaterial = (TargetLevel < CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);
	UpgradeCost = SystemConstHelper::GetCharacterUltimateUpCost(CurrentLevel, TargetLevel);

	SetGoldCost();
}

void UItemLevelUpWidget::SetRelicTierUpCost(int32 CurrentTier)
{
	const URelicManager& RelicMgr = GetHUDStore().GetRelicManager();
	UCMS* CMS = GetCMS();
	int32 TargetTier = CurrentTier;
	for (int32 i = 0; i < MaterialItemWidgets.Num(); ++i)
	{
		UItemCardWidget* ItemWidget = MaterialItemWidgets[i];
		const FRelic* Relic = RelicMgr.Find(FRelicId(ItemWidget->GetItemId()));
		if (!Relic)
		{
			continue;
		}

		ItemWidget->SetNumber(i + 1);
		TargetTier += Relic->Info.Tier;
	}

	TargetTier = FMath::Min(TargetTier, CombatCubeConst::Q6_MAX_TIER);
	bCanAddMaterial = (TargetTier < CombatCubeConst::Q6_MAX_TIER);
	UpgradeCost = SystemConstHelper::GetEquipTierUpCost(CurrentTier, TargetTier);
	SetGoldCost();
}

void UItemLevelUpWidget::SetSculptureTierUpCost(int32 CurrentTier)
{
	UpgradeCost = 0;

	const USculptureManager& SculptureMgr = GetHUDStore().GetSculptureManager();
	UCMS* CMS = GetCMS();
	int32 TargetTier = CurrentTier;
	for (int32 i = 0; i < MaterialItemWidgets.Num(); ++i)
	{
		UItemCardWidget* ItemWidget = MaterialItemWidgets[i];
		const FSculpture* Sculpture = SculptureMgr.Find(FSculptureId(ItemWidget->GetItemId()));
		if (!Sculpture)
		{
			continue;
		}

		ItemWidget->SetNumber(i + 1);
		TargetTier += Sculpture->Info.Tier;
	}

	TargetTier = FMath::Min(TargetTier, CombatCubeConst::Q6_MAX_TIER);
	bCanAddMaterial = (TargetTier < CombatCubeConst::Q6_MAX_TIER);
	UpgradeCost = SystemConstHelper::GetEquipTierUpCost(CurrentTier, TargetTier);
	SetGoldCost();
}

void UItemLevelUpWidget::SetTierUpResult(EUpgradeCategory Category, int32 EquipType, int32 CurrentTier)
{
	int32 TargetTier = GetTargetTier(Category, CurrentTier);

	TierUpText->SetVisibility((CurrentTier == TargetTier) ?
		ESlateVisibility::Hidden : ESlateVisibility::SelfHitTestInvisible);	// Always fill layout
	ResultTierUpWidget->SetTier(CurrentTier, TargetTier);

	if (Category == EUpgradeCategory::Relic)
	{
		ResultSkillUpWidget->SetRelicSkill(FRelicType(EquipType), CurrentTier, TargetTier);
	}
	else if (Category == EUpgradeCategory::Sculpture)
	{
		ResultSkillUpWidget->SetSculptureSKill(FSculptureType(EquipType), CurrentTier, TargetTier);
	}
}

void UItemLevelUpWidget::SetUltimateUpResult(const FCharacterInfo& CharacterInfo)
{
	int32 TargetLevel = GetTargetUltLevel(CharacterInfo.UltimateSkillLevel);
	const FCMSSkillRow& SkillRow = GetCMS()->GetCharacterUltimateSkillRow(CharacterInfo.Type);

	ResultUltUpWidget->SetUltimateSkill(SkillRow, CharacterInfo.UltimateSkillLevel, TargetLevel);
}

int32 UItemLevelUpWidget::GetTargetTier(EUpgradeCategory Category, int32 CurrentTier)
{
	int32 TargetTier = CurrentTier;
	for (const UItemCardWidget* ItemCardWidget : MaterialItemWidgets)
	{
		check(ItemCardWidget);

		int64 ItemId = ItemCardWidget->GetItemId();
		int32 AddTier = 0;
		if (Category == EUpgradeCategory::Relic)
		{
			const FRelic* Relic = GetHUDStore().GetRelicManager().Find(FRelicId(ItemId));
			if (Relic)
			{
				AddTier = Relic->Info.Tier;
			}
		}
		else if (Category == EUpgradeCategory::Sculpture)
		{
			const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(FSculptureId(ItemId));
			if (Sculpture)
			{
				AddTier = Sculpture->Info.Tier;
			}
		}

		TargetTier += AddTier;
	}

	return FMath::Min(TargetTier, CombatCubeConst::Q6_MAX_TIER);
}

int32 UItemLevelUpWidget::GetTargetUltLevel(int32 CurrentLevel)
{
	int32 TargetLevel = CurrentLevel;
	for (const UItemCardWidget* ItemCardWidget : MaterialItemWidgets)
	{
		check(ItemCardWidget);

		int64 ItemId = ItemCardWidget->GetItemId();
		int32 AddLevel = 0;
		const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(FCharacterId(ItemId));
		if (Character)
		{
			AddLevel = Character->GetInfo().UltimateSkillLevel;
		}

		TargetLevel += AddLevel;
	}

	return FMath::Min(TargetLevel, CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);
}

UItemMaxLevelUpWidget::UItemMaxLevelUpWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UItemMaxLevelUpWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemLabelWidget = CastChecked<UItemLabelWidget>(GetWidgetFromName("ItemLabel"));
	UpgradeResultStatWidget = CastChecked<UUpgradeResultStatWidget>(GetWidgetFromName("UpgradeStat"));
	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	EquipCardWidget = CastChecked<UItemBigCardWidget>(GetWidgetFromName("Equip"));
	CurrentMaxLevelText = CastChecked<UTextBlock>(GetWidgetFromName("CurrentMaxLevel"));
	NewMaxLevelText = CastChecked<UTextBlock>(GetWidgetFromName("NewMaxLevel"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));

	OwnedPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPoint"));
	OwnedPointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	RequirePointWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequirePoint"));
	RequirePointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);

	UpgradeCategoryText = CastChecked<UTextBlock>(GetWidgetFromName("UpgradeCategory"));
	UpgradeButton = CastChecked<UButton>(GetWidgetFromName("Upgrade"));
	UpgradeButton->OnClicked.AddUniqueDynamic(this, &UItemMaxLevelUpWidget::OnUpgradeButtonClicked);
}

void UItemMaxLevelUpWidget::SetItemPromote(EUpgradeCategory Category, int64 ItemId)
{
	switch (Category)
	{
		case EUpgradeCategory::Character:
			SetCharacter(FCharacterId(ItemId));
			break;
		case EUpgradeCategory::Relic:
			SetRelic(FRelicId(ItemId));
			break;
		case EUpgradeCategory::Sculpture:
			SetSculpture(FSculptureId(ItemId));
			break;
		default:
			ensure(0);
			break;
	}
}

void UItemMaxLevelUpWidget::SetCharacterEvolute(const FCharacterId& CharacterId)
{
	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!Character)
	{
		return;
	}

	CharacterImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	EquipCardWidget->SetVisibility(ESlateVisibility::Collapsed);

	const UCMS* CMS = GetCMS();
	const FCharacterInfo& CharacterInfo = Character->GetInfo();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterInfo.Type);
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterInfo.Type);

	ItemLabelWidget->SetCharacter(UnitRow.DescName, CharacterInfo.Grade, UnitRow.NatureType, CharacterInfo.Star, CharacterInfo.Moon);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);

	int32 UpgradeMoon = SystemConstHelper::GetUpgradeTargetMoon(CharacterInfo.Grade, CharacterInfo.Moon);
	FText LevelText = Q6Util::GetLocalizedText("Common", "Level");
	CurrentMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon))));
	NewMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, UpgradeMoon))));
	UpgradeResultStatWidget->SetCharacterEvolute(CharacterInfo);

	// Set evolute cost

	const FUpgradeUIState& UIState = GetHUDStore().GetUIStateManager().GetUpgradeUIState();
	EUpgradeCharacterCategory UpCategory = EUpgradeCharacterCategory(UIState.UpgradeMenuIndex);
	const FCMSBagItemRow& MaterialItemRow = CMS->GetBagItemRowOrDummy(FBagItemType(SystemConst::Q6_CHARACTER_EVOLUTION_MATERIAL));
	MaterialsWidget->SetMaterial(MaterialItemRow, CharacterEvoluteMaterialCount);

	// Set GoldText,Color
	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedPointWidget->SetCurPoint(OwnedGold);

	int64 GoldCost = SystemConstHelper::GetCharacterEvoluteCost(UpgradeMoon, CharacterInfo.Grade);
	RequirePointWidget->SetPoint(GoldCost, GetHUDStore().GetWorldUser().GetGold());
	UpgradeCategoryText->SetText(GetUIResource().GetUpgradeCharacterName(UpCategory));

	bool bEnoughCost = GetHUDStore().GetWorldUser().HasEnoughGold(GoldCost);
	bool bEnoughMaterial = GetHUDStore().GetBagItemManager().HasEnoughBagItem(MaterialItemRow.CmsType(), CharacterEvoluteMaterialCount);
	UpgradeButton->SetIsEnabled(bEnoughCost && bEnoughMaterial);
}

void UItemMaxLevelUpWidget::SetCharacter(const FCharacterId& CharacterId)
{
	const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
	if (!Character)
	{
		return;
	}

	CharacterImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	EquipCardWidget->SetVisibility(ESlateVisibility::Collapsed);

	const UCMS* CMS = GetCMS();
	const FCharacterInfo& CharacterInfo = Character->GetInfo();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(CharacterInfo.Type);
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterInfo.Type);

	ItemLabelWidget->SetCharacter(UnitRow.DescName, CharacterInfo.Grade, UnitRow.NatureType, CharacterInfo.Star, CharacterInfo.Moon);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);

	FText LevelText = Q6Util::GetLocalizedText("Common", "Level");
	CurrentMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon))));
	NewMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star + 1, CharacterInfo.Moon))));
	UpgradeResultStatWidget->SetCharacterPromote(CharacterInfo);

	// Set promote cost

	const FUpgradeUIState& UIState = GetHUDStore().GetUIStateManager().GetUpgradeUIState();
	EUpgradeCharacterCategory UpCategory = EUpgradeCharacterCategory(UIState.UpgradeMenuIndex);
	const FCMSPromoteCostRow& PromoteCostRow = CMS->GetCharacterUpStarCostRowOrDummy(UpCategory, CharacterInfo);
	MaterialsWidget->SetMaterials(PromoteCostRow.GetBagItem(), PromoteCostRow.ItemCount);

	// Set GoldText,Color
	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedPointWidget->SetCurPoint(OwnedGold);
	RequirePointWidget->SetPoint(PromoteCostRow.Gold, OwnedGold);

	UpgradeCategoryText->SetText(GetUIResource().GetUpgradeCharacterName(UpCategory));
	UpgradeButton->SetIsEnabled(CanItemPromote(PromoteCostRow));
}

void UItemMaxLevelUpWidget::SetRelic(const FRelicId& RelicId)
{
	const FRelic* Relic = GetHUDStore().GetRelicManager().Find(RelicId);
	if (!Relic)
	{
		return;
	}

	EquipCardWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	CharacterImage->SetVisibility(ESlateVisibility::Collapsed);

	const UCMS* CMS = GetCMS();
	const FRelicInfo& RelicInfo = Relic->Info;
	const FCMSRelicRow& RelicRow = CMS->GetRelicRowOrDummy(RelicInfo.Type);
	const FEquipAssetRow& RelicAssetRow = GetGameResource().GetRelicAssetRow(RelicInfo.Type);
	ItemLabelWidget->SetEquip(RelicRow.DescName, RelicInfo.Grade, RelicInfo.Star, RelicInfo.Tier);
	EquipCardWidget->SetRelic(RelicInfo.Type);

	FText LevelText = Q6Util::GetLocalizedText("Common", "Level");
	CurrentMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star))));
	NewMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star + 1))));
	UpgradeResultStatWidget->SetRelicPromote(RelicInfo);

	// Set promote cost

	const FCMSPromoteCostRow& PromoteCostRow = CMS->GetEquipPromoteCostRowOrDummy(EPromoteCategory::Relic, RelicInfo.Star + 1);
	MaterialsWidget->SetMaterials(PromoteCostRow.GetBagItem(), PromoteCostRow.ItemCount);

	// Set GoldText,Color
	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedPointWidget->SetCurPoint(OwnedGold);
	RequirePointWidget->SetPoint(PromoteCostRow.Gold, OwnedGold);

	UpgradeCategoryText->SetText(Q6Util::GetLocalizedText("Common", "Promote"));
	UpgradeButton->SetIsEnabled(CanItemPromote(PromoteCostRow));
}

void UItemMaxLevelUpWidget::SetSculpture(const FSculptureId& SculptrueId)
{
	const FSculpture* Sculpture = GetHUDStore().GetSculptureManager().Find(SculptrueId);
	if (!Sculpture)
	{
		return;
	}

	EquipCardWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	CharacterImage->SetVisibility(ESlateVisibility::Collapsed);

	const UCMS* CMS = GetCMS();
	const FSculptureInfo& SculptureInfo = Sculpture->Info;
	const FCMSSculptureRow& SculptureRow = CMS->GetSculptureRowOrDummy(SculptureInfo.Type);
	const FSculptureAssetRow& SculptureAssetRow = GetGameResource().GetSculptureAssetRow(SculptureInfo.Type);
	ItemLabelWidget->SetEquip(SculptureRow.DescName, SculptureInfo.Grade, SculptureInfo.Star, SculptureInfo.Tier);
	EquipCardWidget->SetSculpture(SculptureInfo.Type);

	FText LevelText = Q6Util::GetLocalizedText("Common", "Level");
	CurrentMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star))));
	NewMaxLevelText->SetText(FText::Format(LevelText, FText::AsNumber(SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star + 1))));
	UpgradeResultStatWidget->SetSculpturePromote(SculptureInfo);

	// Set promote cost

	const FCMSPromoteCostRow& PromoteCostRow = CMS->GetEquipPromoteCostRowOrDummy(EPromoteCategory::Sculpture, SculptureInfo.Star + 1);
	MaterialsWidget->SetMaterials(PromoteCostRow.GetBagItem(), PromoteCostRow.ItemCount);

	// Set GoldText,Color
	int64 OwnedGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedPointWidget->SetCurPoint(OwnedGold);
	RequirePointWidget->SetPoint(PromoteCostRow.Gold, OwnedGold);

	UpgradeCategoryText->SetText(Q6Util::GetLocalizedText("Common", "Promote"));
	UpgradeButton->SetIsEnabled(CanItemPromote(PromoteCostRow));
}

void UItemMaxLevelUpWidget::OnUpgradeButtonClicked()
{
	const FUpgradeUIState& UIState = GetHUDStore().GetUIStateManager().GetUpgradeUIState();
	UItemMaxLevelUpConfirmPopupWidget* PromoteConfirmPopup = GetCheckedLobbyHUD(this)->OpenPromoteConfirmPopup();
	if (!PromoteConfirmPopup)
	{
		return;
	}

	if (UIState.Category == EUpgradeCategory::Character)
	{
		PromoteConfirmPopup->SetCharacter(FCharacterId(UIState.ItemId), EUpgradeCharacterCategory(UIState.UpgradeMenuIndex));
		PromoteConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UItemMaxLevelUpWidget::OnCharacterMaxLevelUpConfirmed, EUpgradeCharacterCategory(UIState.UpgradeMenuIndex), FCharacterId(UIState.ItemId));
	}
	else if(UIState.Category == EUpgradeCategory::Relic)
	{
		PromoteConfirmPopup->SetRelic(FRelicId(UIState.ItemId));
		PromoteConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UItemMaxLevelUpWidget::OnRelicPromoteConfirmed, FRelicId(UIState.ItemId));
	}
	else if (UIState.Category == EUpgradeCategory::Sculpture)
	{
		PromoteConfirmPopup->SetSculpture(FSculptureId(UIState.ItemId));
		PromoteConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UItemMaxLevelUpWidget::OnSculpturePromoteConfirmed, FSculptureId(UIState.ItemId));
	}
	else
	{
		Q6JsonLogRoze(Warning, "UItemPromoteWidget::OnPromoteButtonClicked - What are you doing here?", Q6KV("UpgradELootCategory", (int32) UIState.Category));
	}
}

void UItemMaxLevelUpWidget::OnCharacterMaxLevelUpConfirmed(EConfirmPopupFlag Flag, EUpgradeCharacterCategory UpCategory, FCharacterId CharacterId)
{
	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetCheckedLobbyHUD(this)->CloseAllPopups();

	const FUpgradeUIState& UIState = GetHUDStore().GetUIStateManager().GetUpgradeUIState();
	if (UIState.UpgradeMenuIndex == (int32)EUpgradeCharacterCategory::Promote)
	{
		GetHUDStore().GetCharacterManager().ReqPromote(CharacterId);
	}
	else if (UIState.UpgradeMenuIndex == (int32)EUpgradeCharacterCategory::Unbind)
	{
		GetHUDStore().GetCharacterManager().ReqUnbind(CharacterId);
	}
	else if (UIState.UpgradeMenuIndex == (int32)EUpgradeCharacterCategory::Evolute)
	{
		GetHUDStore().GetCharacterManager().ReqEvolute(CharacterId);
	}
}

void UItemMaxLevelUpWidget::OnRelicPromoteConfirmed(EConfirmPopupFlag Flag, FRelicId RelicId)
{
	if (Flag == EConfirmPopupFlag::Yes)
	{
		GetCheckedLobbyHUD(this)->CloseAllPopups();

		GetHUDStore().GetRelicManager().ReqPromote(RelicId);
	}
}

void UItemMaxLevelUpWidget::OnSculpturePromoteConfirmed(EConfirmPopupFlag Flag, FSculptureId SculptureId)
{
	if (Flag == EConfirmPopupFlag::Yes)
	{
		GetCheckedLobbyHUD(this)->CloseAllPopups();

		GetHUDStore().GetSculptureManager().ReqPromote(SculptureId);
	}
}

void UGainFinalArtWidget::NativeConstruct()
{
	Super::NativeConstruct();

	FinalArtImage = CastChecked<UImage>(GetWidgetFromName("FinalArt"));

	GainFinalArtAnim = GetWidgetAnimationFromName(this, "AnimGainFinalArt");
};

void UGainFinalArtWidget::SetCharacter(FCharacterType CharacterType)
{
	const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	FinalArtImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.GetFinalArtTexture());

	PlayAnimation(GainFinalArtAnim);
}

UTurnSkillUpWidget::UTurnSkillUpWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SelectedSkillIndex(0)
{

}

void UTurnSkillUpWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("CharacterInfo"));
	CharacterLabelWidget = CastChecked<UItemLabelWidget>(GetWidgetFromName("CharacterLabel"));
	SkillName = CastChecked<UQ6TextBlock>(GetWidgetFromName("SkillName"));

	TurnSkillIconWidgets.SetNum(CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
	TurnSkillIconWidgets[0] = CastChecked<UTurnSkillIconWidget>(GetWidgetFromName("SKillIcon_0"));
	TurnSkillIconWidgets[0]->OnSelectButtonClickedDelegate.BindUObject(this, &UTurnSkillUpWidget::OnSelectUpgradeSkill, 0);
	TurnSkillIconWidgets[1] = CastChecked<UTurnSkillIconWidget>(GetWidgetFromName("SKillIcon_1"));
	TurnSkillIconWidgets[1]->OnSelectButtonClickedDelegate.BindUObject(this, &UTurnSkillUpWidget::OnSelectUpgradeSkill, 1);
	TurnSkillIconWidgets[2] = CastChecked<UTurnSkillIconWidget>(GetWidgetFromName("SKillIcon_2"));
	TurnSkillIconWidgets[2]->OnSelectButtonClickedDelegate.BindUObject(this, &UTurnSkillUpWidget::OnSelectUpgradeSkill, 2);

	CurrentSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("CurrentSkill"));
	ResultSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("ResultSkill"));

	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));

	OwnedPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPoint"));
	OwnedPointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	RequirePointWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequirePoint"));
	RequirePointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);

	SkillInfoDefaultAnim = GetWidgetAnimationFromName(this, "SkillInfoDefault");
	check(SkillInfoDefaultAnim);
	SkillInfoLowLevelAnim = GetWidgetAnimationFromName(this, "SkillInfoLowLevel");
	check(SkillInfoLowLevelAnim);
	SkillInfoMaxLevelAnim = GetWidgetAnimationFromName(this, "SkillInfoMaxLevel");
	check(SkillInfoMaxLevelAnim);
	SkillInfoNotAcquireAnim = GetWidgetAnimationFromName(this, "SkillInfoNotAcquire");
	check(SkillInfoNotAcquireAnim);

	PromoteButton = CastChecked<UButton>(GetWidgetFromName("Promote"));
	PromoteButton->OnClicked.AddUniqueDynamic(this, &UTurnSkillUpWidget::OnPromoteButtonClicked);

	NotifyContentText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("NotiyContent"));

	SelectedSkillIndex = 0;
}

void UTurnSkillUpWidget::SetTurnSkill(const FCharacterId& InCharacterId)
{
	SelectedCharacterId = InCharacterId;
	const UCMS* CMS = GetCMS();
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();

	const FCharacter* Character = CharacterManager.Find(SelectedCharacterId);
	if (!Character)
	{
		return;
	}

	const FCharacterInfo& CharacterInfo = Character->GetInfo();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(Character->GetInfo().Type);

	CharacterLabelWidget->SetCharacter(UnitRow.DescName, Character->GetInfo().Grade, UnitRow.NatureType, CharacterInfo.Star, CharacterInfo.Moon);

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(Character->GetInfo().Type);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.BodyTexture);

	const FSkillAssetRow& SkillAssetRow = GetGameResource().GetSkillAssetRow(UnitRow.Model);
	const TArray<const FCMSSkillRow*>& UnitTurnSkills = UnitRow.GetTurnSkills();
	TArray<int32> TurnSkillLevels;
	CharacterManager.GetCharacterTurnSkillLevels(SelectedCharacterId, TurnSkillLevels);

	for (int TurnSkillIndex = 0; TurnSkillIndex < TurnSkillIconWidgets.Num(); ++TurnSkillIndex)
	{
		if (!UnitTurnSkills.IsValidIndex(TurnSkillIndex))
		{
			Q6JsonLogGunny(Error, "UnitTurnSkills has no that index ", Q6KV("UnitTurnSkillsIndex", TurnSkillIndex));
			return;
		}

		if (TurnSkillIndex < SkillAssetRow.TurnSkillIcons.Num())
		{
			TurnSkillIconWidgets[TurnSkillIndex]->SetSkill(SkillAssetRow.TurnSkillIcons[TurnSkillIndex], TurnSkillLevels[TurnSkillIndex]);
		}

		ESlateVisibility NewMarkVisibility = NewMarkMgr.GetUpgradeTurnSkillVisibility(SelectedCharacterId, TurnSkillIndex);
		TurnSkillIconWidgets[TurnSkillIndex]->SetNewMarkVisibility(NewMarkVisibility);
		TurnSkillIconWidgets[TurnSkillIndex]->SetLocked(TurnSkillLevels[TurnSkillIndex] == 0);
	}

	if (Character->GetInfo().TurnSkill1Level == CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		if (Character->GetInfo().TurnSkill2Level == CombatCubeConst::Q6_MAX_SKILL_LEVEL)
		{
			OnSelectUpgradeSkill(2);
			return;
		}
		OnSelectUpgradeSkill(1);
		return;
	}
	OnSelectUpgradeSkill(0);
}

void UTurnSkillUpWidget::OnPromoteButtonClicked()
{
	USkillUpgradeConfirmPopupWidget* ConfirmPopup = GetCheckedLobbyHUD(this)->OpenSkillUpgradeConfirmPopup();
	check(ConfirmPopup);

	ConfirmPopup->SetTurnSkill(SelectedCharacterId, SelectedSkillIndex);
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UTurnSkillUpWidget::OnTurnSkillUpgrade);
}

void UTurnSkillUpWidget::OnSelectUpgradeSkill(int32 InSkillIndex)
{
	SelectedSkillIndex = InSkillIndex;

	SetSkillIconWidget();
	SetSkillInfoWidget();
}

void UTurnSkillUpWidget::SetSkillIconWidget()
{
	for (int i = 0; i < CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++i)
	{
		TurnSkillIconWidgets[i]->SetSelected(false);
	}
	if (!TurnSkillIconWidgets.IsValidIndex(SelectedSkillIndex))
	{
		Q6JsonLogGunny(Warning, "SkillIconWidgets index fail", Q6KV("SelectedSkillIndex", SelectedSkillIndex));
		return;
	}
	TurnSkillIconWidgets[SelectedSkillIndex]->SetSelected(true);
}

void UTurnSkillUpWidget::OnTurnSkillUpgrade(EConfirmPopupFlag Option)
{
	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	if (!bEnoughCost)
	{
		Q6JsonLogRoze(Warning, "UTurnSkillUpWidget::OnTurnSkillUpgrade - Not enough cost");
		return;
	}

	GetHUDStore().GetCharacterManager().ReqUpgradeTurnSkillLevel(SelectedCharacterId, SelectedSkillIndex);
}

void UTurnSkillUpWidget::SetSkillInfoWidget()
{
	const UCMS* CMS = GetCMS();
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();

	const FCharacter* SelectedCharacter = CharacterManager.Find(SelectedCharacterId);
	if (!SelectedCharacter)
	{
		Q6JsonLogGunny(Warning, "UTurnSkillUpWidget::SetSkillInfoWidget - Character does not exist."
			, Q6KV("CharacterId", SelectedCharacterId));
		return;
	}

	const FCharacterInfo& CharacterInfo = SelectedCharacter->GetInfo();

	TArray<int32> TurnSkillLevels;
	CharacterManager.GetCharacterTurnSkillLevels(SelectedCharacterId, TurnSkillLevels);

	if (!TurnSkillLevels.IsValidIndex(SelectedSkillIndex))
	{
		Q6JsonLogGunny(Warning, "UTurnSkillUpWidget::SetSkillInfoWidget - TurnSkillLevels index is not valid.", Q6KV("SelectedSkillIndex", SelectedSkillIndex));
		return;
	}
	int32 SelectedTurnSkillLevel = TurnSkillLevels[SelectedSkillIndex] == 0 ? 1 : TurnSkillLevels[SelectedSkillIndex];

	/* Show Skill info */
	const FCMSSkillRow* SkillRow = CharacterManager.GetCharacterTurnSkillRow(SelectedCharacterId, SelectedSkillIndex);
	if (!SkillRow)
	{
		Q6JsonLogGunny(Warning, "UTurnSkillUpWidget::SetSkillInfoWidget - SkillRow does not exist.");
		return;
	}

	SkillName->SetText(CMS->GetSkillRowOrDummy(SkillRow->Type).DescName);

	const int32 CurrentSkillCooldown = CMS->GetCooltimeByLevel(SkillRow->Type, SelectedTurnSkillLevel);
	CurrentSkillWidget->SetSkill(SelectedTurnSkillLevel, BuildToolTipDesc(SkillRow->CmsType(), SelectedTurnSkillLevel, ESkillCategory::TurnBegin), CurrentSkillCooldown);
	CurrentSkillWidget->SetInfoColor(false, false);

	if (SelectedTurnSkillLevel == CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		PlayAnimation(SkillInfoMaxLevelAnim);
		return;
	}

	/* Character's star */
	if (!TurnSkillIconWidgets.IsValidIndex(SelectedSkillIndex))
	{
		Q6JsonLogGunny(Warning, "SkillIconWidgets index fail", Q6KV("SelectedSkillIndex", SelectedSkillIndex));
		return;
	}

	if (TurnSkillIconWidgets[SelectedSkillIndex]->IsLocked())
	{
		SetNotOpenedText(CharacterInfo.Type);
		return;
	}

	const int32 NextTurnSkillLevel = SelectedTurnSkillLevel + 1;
	const int32 ResultSkillCooldown = CMS->GetCooltimeByLevel(SkillRow->Type, NextTurnSkillLevel);
	ResultSkillWidget->SetSkill(NextTurnSkillLevel, BuildToolTipDesc(SkillRow->CmsType(), NextTurnSkillLevel, ESkillCategory::TurnBegin), ResultSkillCooldown);
	ResultSkillWidget->SetInfoColor(true, ResultSkillCooldown < CurrentSkillCooldown);

	/* Character's level */
	int32 RequiredCharacterLevel = SystemConstHelper::GetTurnSkillUpgradeCharacterLevel(NextTurnSkillLevel);
	if (CharacterInfo.Level < RequiredCharacterLevel)
	{
		FText NotifyText = Q6Util::GetLocalizedText("Lobby", "LackCharacterLevel");

		NotifyText = FText::Format(NotifyText, FText::AsNumber(RequiredCharacterLevel));
		NotifyContentText->SetText(NotifyText);

		PlayAnimation(SkillInfoLowLevelAnim);
		return;
	}

	SetGoldAndMaterialsWidget();
}

void UTurnSkillUpWidget::SetGoldAndMaterialsWidget()
{
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();

	// check required materials
	const FCMSSkillUpgradeCostRow* SelectedSkillUpgradeCostRow = CharacterManager.GetTurnSkillUpgradeCostRow(SelectedCharacterId, SelectedSkillIndex);
	if (!SelectedSkillUpgradeCostRow)
	{
		return;
	}

	const TArray<const FCMSBagItemRow*>& BagItems = SelectedSkillUpgradeCostRow->GetBagItem();
	const TArray<int32>& NumberOfItems = SelectedSkillUpgradeCostRow->BagItemCount;
	bool bEnoughMaterials = CharacterManager.HasEnoughMaterialsForTurnSkillUpgrade(SelectedCharacterId, SelectedSkillIndex);
	MaterialsWidget->SetMaterials(BagItems, NumberOfItems);

	// check required gold
	bool bEnoughGold = CharacterManager.HasEnoughGoldForTurnSkillUpgrade(SelectedCharacterId, SelectedSkillIndex);
	const int32 RequireGold = CharacterManager.GetGoldForTurnSkillUpgrade(SelectedCharacterId, SelectedSkillIndex);
	const int32 CurrentGold = GetHUDStore().GetWorldUser().GetGold();
	OwnedPointWidget->SetCurPoint(CurrentGold);
	RequirePointWidget->SetPoint(RequireGold, CurrentGold);

	// set flag
	bEnoughCost = bEnoughGold && bEnoughMaterials;
	PromoteButton->SetIsEnabled(bEnoughCost);

	PlayAnimation(SkillInfoDefaultAnim);
}

void UTurnSkillUpWidget::SetNotOpenedText(FCharacterType InCharacterType)
{
	PlayAnimation(SkillInfoNotAcquireAnim);

	if (SystemConstHelper::IsWeed(InCharacterType))
	{
		const FCMSWeedGrowRow* Row = GetCMS()->GetTurnSkillOpenWeedGrowRow(SelectedSkillIndex);
		if (!Row)
		{
			return;
		}

		NotifyContentText->SetText(Q6Util::GetNotOpenedYetText(Row->Episode, Row->Stage, Row->SubStage));
		return;
	}

	const int32 SelectedSkillNumber = SelectedSkillIndex + 1;
	int32 UnlockStar = 0;
	FText NotifyText = Q6Util::GetLocalizedText("Lobby", "LackCharacterStar");

	for (int Star = 0; Star < MAX_STAR; ++Star)
	{
		const int32 NumberOfTurnSkill = SystemConstHelper::GetCharacterTurnSkillCount(Star);

		if (NumberOfTurnSkill == SelectedSkillNumber)
		{
			UnlockStar = Star;
			break;
		}
	}

	NotifyText = FText::Format(NotifyText, FText::AsNumber(UnlockStar));
	NotifyContentText->SetText(NotifyText);
}

USkillUpInfoWidget::USkillUpInfoWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bDayCooltime = false;
}

void USkillUpInfoWidget::NativeConstruct()
{
	Super::NativeConstruct();

	LabelText = CastChecked<UTextBlock>(GetWidgetFromName("Label"));
	LevelText = CastChecked<UTextBlock>(GetWidgetFromName("Level"));
	CooldownText = CastChecked<UTextBlock>(GetWidgetFromName("Cooldown"));
	DescriptionText = CastChecked<URichTextBlock>(GetWidgetFromName("Description"));
	CooltimeText = CastChecked<UQ6TextBlock>(GetWidgetFromName("Cooltime"));

	LevelSkillLevelDefaultAnim = GetWidgetAnimationFromName(this, "AnimSkillLevelDefault");
	SkillLevelUpAnim = GetWidgetAnimationFromName(this, "AnimSkillLevelUp");
	CooldownDefaultAnim = GetWidgetAnimationFromName(this, "AnimCooldownDefault");
	NoCooldownAnim = GetWidgetAnimationFromName(this, "AnimNoCooldown");
	CooldownReduceAnim = GetWidgetAnimationFromName(this, "AnimCooldownReduce");

	ReuseTimeAnim = GetNullableWidgetAnimationFromName(this, "AnimReuseTimeDefault");
	TierUpAnim = GetNullableWidgetAnimationFromName(this, "AnimTierUp");
}

void USkillUpInfoWidget::SetSkillInfo(int32 SkillLevel, const FText& SkillInfo, int32 SkillCooldown)
{
	LabelText->SetText(Q6Util::GetLocalizedText("Common", "Lv"));
	LevelText->SetText(FText::AsNumber(SkillLevel));
	DescriptionText->SetText(SkillInfo);
	CooldownText->SetText(FText::AsNumber(SkillCooldown));
}

void USkillUpInfoWidget::SetSkill(int32 SkillLevel, const FText& SkillInfo, int32 SkillCooldown)
{
	CooltimeText->SetText(Q6Util::GetLocalizedText("Combat", "SkillCooltime"));
	SetSkillInfo(SkillLevel, SkillInfo, SkillCooldown);

	if (SkillCooldown <= 0)
	{
		PlayAnimation(NoCooldownAnim);
	}
}

void USkillUpInfoWidget::SetArtifact(int32 SkillLevel, const FText& SkillInfo, int32 ReuseTime)
{
	CooltimeText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "ReuseTimeLeft"), ReuseTime));
	SetSkillInfo(SkillLevel, SkillInfo, ReuseTime);

	PlayAnimation(ReuseTimeAnim);
}

void USkillUpInfoWidget::SetEquipEffecs(int32 Tier, const TArray<const FCMSBuffRow*>& Buffs)
{
	LabelText->SetText(Q6Util::GetLocalizedText("Lobby", "EquipmentEffect"));

	FString EffectsStr = GetEquipEffectsStr(Tier, Buffs);
	DescriptionText->SetText(FText::FromString(EffectsStr));

	PlayAnimation(TierUpAnim);
}

void USkillUpInfoWidget::SetInfoColor(bool bLevelUp, bool bCooldownReduce)
{
	SetLevelUp(bLevelUp);
	PlayAnimation(bCooldownReduce ? CooldownReduceAnim : CooldownDefaultAnim);
}

void USkillUpInfoWidget::SetLevelUp(bool bLevelUp)
{
	PlayAnimation(bLevelUp ? SkillLevelUpAnim : LevelSkillLevelDefaultAnim);
}


UUpgradeResultSkillWidget::UUpgradeResultSkillWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UUpgradeResultSkillWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CurrentSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("CurrentSkill"));
	ResultSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("ResultSkill"));

	NoneSkillBox = CastChecked<USizeBox>(GetWidgetFromName("NoneSkill"));
	NoneInfoText = CastChecked<UTextBlock>(GetWidgetFromName("NoneInfo"));
}

void UUpgradeResultSkillWidget::SetRelicSkill(FRelicType RelicType, int32 CurrentTier, int32 ResultTier)
{
	const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(RelicType);
	CurrentSkillWidget->SetEquipEffecs(CurrentTier, RelicRow.GetBuff());

	SetResultVisibility(CurrentTier == ResultTier);
	if (CurrentTier == ResultTier)
	{
		 NoneInfoText->SetText(Q6Util::GetLocalizedText("Lobby", "LevelUpTierInfo"));
	}
	else
	{
		ResultSkillWidget->SetEquipEffecs(ResultTier, RelicRow.GetBuff());
	}
}

void UUpgradeResultSkillWidget::SetSculptureSKill(FSculptureType SculptureType, int32 CurrentTier, int32 ResultTier)
{
	const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(SculptureType);
	CurrentSkillWidget->SetEquipEffecs(CurrentTier, SculptureRow.GetBuff());

	SetResultVisibility(CurrentTier == ResultTier);
	if (CurrentTier == ResultTier)
	{
		NoneInfoText->SetText(Q6Util::GetLocalizedText("Lobby", "LevelUpTierInfo"));
	}
	else
	{
		ResultSkillWidget->SetEquipEffecs(ResultTier, SculptureRow.GetBuff());
	}
}

void UUpgradeResultSkillWidget::SetTurnSkill(const FCMSSkillRow& SkillRow, int32 CurrentLevel, int32 ResultLevel)
{
	const UCMS* CMS = GetCMS();
	const int32 OldSkillCooldown = CMS->GetCooltimeByLevel(SkillRow.CmsType(), CurrentLevel);

	CurrentSkillWidget->SetSkill(CurrentLevel, BuildToolTipDesc(SkillRow.CmsType(), CurrentLevel, ESkillCategory::TurnBegin), OldSkillCooldown);
	CurrentSkillWidget->SetInfoColor(false, false);

	const int32 NewSkillCooldown = CMS->GetCooltimeByLevel(SkillRow.CmsType(), ResultLevel);
	ResultSkillWidget->SetSkill(ResultLevel, BuildToolTipDesc(SkillRow.CmsType(), ResultLevel, ESkillCategory::TurnBegin), NewSkillCooldown);
	ResultSkillWidget->SetInfoColor(true, NewSkillCooldown < OldSkillCooldown);

	SetResultVisibility(CurrentLevel == ResultLevel);
}

void UUpgradeResultSkillWidget::SetUltimateSkill(const FCMSSkillRow& SkillRow, int32 CurrentLevel, int32 ResultLevel)
{
	CurrentSkillWidget->SetSkill(CurrentLevel, BuildToolTipDesc(SkillRow.CmsType(), CurrentLevel, ESkillCategory::Ultimate));
	CurrentSkillWidget->SetLevelUp(false);

	SetResultVisibility(CurrentLevel == ResultLevel);
	if (CurrentLevel == ResultLevel)
	{
		NoneInfoText->SetText(Q6Util::GetLocalizedText("Lobby", "LevelUpUltInfo"));
	}
	else
	{
		ResultSkillWidget->SetSkill(ResultLevel, BuildToolTipDesc(SkillRow.CmsType(), ResultLevel, ESkillCategory::Ultimate));
		ResultSkillWidget->SetLevelUp(ResultLevel > CurrentLevel);
	}
}

void UUpgradeResultSkillWidget::SetResultVisibility(bool bNoUpgrade)
{
	if (bNoUpgrade)
	{
		NoneSkillBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		ResultSkillWidget->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		NoneSkillBox->SetVisibility(ESlateVisibility::Collapsed);
		ResultSkillWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

UUpgradeResultTierWidget::UUpgradeResultTierWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UUpgradeResultTierWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CurTierIcon = CastChecked<UImage>(GetWidgetFromName("CurrentTier"));
	ResultTierImage = CastChecked<UImage>(GetWidgetFromName("ResultTier"));
	NoneTierImage = CastChecked<UImage>(GetWidgetFromName("NoneTier"));
}

void UUpgradeResultTierWidget::SetTier(int32 CurTier, int32 ResultTier)
{
	const FSlateBrush& CurTierBrush = GetUIResource().GetTierIcon(CurTier);
	CurTierIcon->SetBrush(CurTierBrush);

	if (CurTier < ResultTier)
	{
		ResultTierImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		NoneTierImage->SetVisibility(ESlateVisibility::Collapsed);

		const FSlateBrush& ResultTierBrush = GetUIResource().GetTierIcon(ResultTier);
		ResultTierImage->SetBrush(ResultTierBrush);
	}
	else
	{
		ResultTierImage->SetVisibility(ESlateVisibility::Collapsed);
		NoneTierImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}


UUpgradeWidget::UUpgradeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UUpgradeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	BGImage = CastChecked<UImage>(GetWidgetFromName("BG"));
	CharacterImage = CastChecked<UImage>(GetWidgetFromName("MainCharacter"));
	UpgradeMenuSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("UpgradeMenu"));
	InventoryWidget = CastChecked<UUpgradeInventoryWidget>(GetWidgetFromName("Inventory"));

	UpgradeCategorySwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("UpgradeCategory"));
	ItemLevelUpWidget = CastChecked<UItemLevelUpWidget>(GetWidgetFromName("ItemLevelUp"));
	ItemMaxLevelUpWidget = CastChecked<UItemMaxLevelUpWidget>(GetWidgetFromName("ItemMaxLevelUp"));
	TurnSkillUpWidget = CastChecked<UTurnSkillUpWidget>(GetWidgetFromName("TurnSkillUp"));

	UQ6Button* Button;
	Button = CastChecked<UQ6Button>(GetWidgetFromName("Character"));
	Button->OnClickedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeButtonClicked, EUpgradeCategory::Character);

	Button = CastChecked<UQ6Button>(GetWidgetFromName("Skill"));
	Button->OnClickedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeButtonClicked, EUpgradeCategory::Skill);

	Button = CastChecked<UQ6Button>(GetWidgetFromName("Sculpture"));
	Button->OnClickedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeButtonClicked, EUpgradeCategory::Sculpture);

	Button = CastChecked<UQ6Button>(GetWidgetFromName("Relic"));
	Button->OnClickedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeButtonClicked, EUpgradeCategory::Relic);

	NewMarkImages.Reset();
	NewMarkImages.Add(CastChecked<UImage>(GetWidgetFromName("CharacterNewMark")));
	NewMarkImages.Add(CastChecked<UImage>(GetWidgetFromName("SkillNewMark")));
	NewMarkImages.Add(CastChecked<UImage>(GetWidgetFromName("SculptureNewMark")));
	NewMarkImages.Add(CastChecked<UImage>(GetWidgetFromName("RelicNewMark")));
	check(NewMarkImages.Num() == (int32)EUpgradeCategory::Max);
}

void UUpgradeWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::Character);
	SubscribeToStore(EHSType::BagItem);
	SubscribeToStore(EHSType::Relic);
	SubscribeToStore(EHSType::Sculpture);
}

bool UUpgradeWidget::OnBack()
{
	return true;
}

void UUpgradeWidget::OnUpgradeButtonClicked(EUpgradeCategory Category)
{
	FString UpgradeButtonString = FString::Printf(TEXT("UpgradeButton_%s"), *ENUM_TO_STRING(EUpgradeCategory, Category));
	TUTORIAL_MONITORING_BUTTON_CLICK(UpgradeButtonString);
	ACTION_DISPATCH_UpgradeInventory(Category);
}

void UUpgradeWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FUpgradeUIState* UIState = GetUIState()->CastToUpgradeUIState();
	check(UIState);

	UpgradeMenuSwitcher->SetActiveWidgetIndex((int32)UIState->UpgradeSequence);

	if (MenuBGs.IsValidIndex(UIState->UpgradeMenuIndex))
	{
		BGImage->SetBrush(MenuBGs[UIState->UpgradeMenuIndex]);
	}

	switch (UIState->UpgradeSequence)
	{
		case EUpgradeSequence::Main:
			SetUpgradeMenu(UIState->ItemId);
			break;

		case EUpgradeSequence::Inventory:
			InventoryWidget->SetCategoryBoxType(UIState->Category);
			InventoryWidget->SetSelectedCategoryBoxIndex(UIState->UpgradeMenuIndex);
			break;

		case EUpgradeSequence::Upgrade:
			SetUpgradeMenu(UIState->Category, UIState->UpgradeMenuIndex, UIState->ItemId);
			break;
	}
}

void UUpgradeWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByUpgrade);

	const UCMS* CMS = GetCMS();

	switch (Action->GetActionType())
	{
		case EHSActionType::CharacterAddXpResp:
			{
				auto DerivedAction = ACTION_PARSE_CharacterAddXpResp(Action);
				const FL2CCharacterAddXpResp& Res = DerivedAction->GetVal();
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					bool bMenuBack = (Res.Info.Level >= SystemConstHelper::GetCharacterMaxLevel(Res.Info.Star, Res.Info.Moon));
					ResultPopup->SetCharacterAddXpResult(
						Res.Info, Res.Old, Res.Xp, EUpgradeResultType(Res.Grade));
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, bMenuBack);
				}
			}
			break;

		case EHSActionType::RelicAddXpResp:
			{
				auto DerivedAction = ACTION_PARSE_RelicAddXpResp(Action);
				const FL2CRelicAddXpResp& Res = DerivedAction->GetVal();
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					bool bMenuBack = (Res.Info.Level >= SystemConstHelper::GetEquipMaxLevel(Res.Info.Star));
					ResultPopup->SetRelicAddXpResult(
						Res.Info, Res.Old, Res.Xp, EUpgradeResultType(Res.Grade));
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, bMenuBack);
				}
			}
			break;

		case EHSActionType::SculptureAddXpResp:
			{
				auto DerivedAction = ACTION_PARSE_SculptureAddXpResp(Action);
				const FL2CSculptureAddXpResp& Res = DerivedAction->GetVal();
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					bool bMenuBack = (Res.Info.Level >= SystemConstHelper::GetEquipMaxLevel(Res.Info.Star));
					ResultPopup->SetSculptureAddXpResult(
						Res.Info, Res.Old, Res.Xp, EUpgradeResultType(Res.Grade));
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, bMenuBack);
				}
			}
			break;

		case EHSActionType::RelicPromoteResp:
			{
				auto DerivedAction = ACTION_PARSE_RelicPromoteResp(Action);
				const FL2CRelicPromoteResp& Res = DerivedAction->GetVal();

				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					ResultPopup->SetRelicPromoteResult(Res.Info);
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, true);
				}
			}
			break;

		case EHSActionType::SculpturePromoteResp:
			{
				auto DerivedAction = ACTION_PARSE_SculpturePromoteResp(Action);
				const FL2CSculpturePromoteResp& Res = DerivedAction->GetVal();

				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					ResultPopup->SetSculpturePromoteResult(Res.Info);
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, true);
				}
			}
			break;

		case EHSActionType::RelicTierUpResp:
			{
				auto DerivedAction = ACTION_PARSE_RelicTierUpResp(Action);
				const FL2CRelicTierUpgradeResp& Res = DerivedAction->GetVal();
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					bool bMenuBack = (Res.Info.Tier >= CombatCubeConst::Q6_MAX_TIER);
					ResultPopup->SetRelicTierUpResult(Res.Info, Res.Old, Res.Xp);
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, bMenuBack);
				}
			}
			break;

		case EHSActionType::SculptureTierUpResp:
			{
				auto DerivedAction = ACTION_PARSE_SculptureTierUpResp(Action);
				const FL2CSculptureTierUpgradeResp& Res = DerivedAction->GetVal();
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					bool bMenuBack = (Res.Info.Tier >= CombatCubeConst::Q6_MAX_TIER);
					ResultPopup->SetSculptureTierUpResult(Res.Info, Res.Old, Res.Xp);
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, bMenuBack);
				}
			}
			break;

		case EHSActionType::CharacterUltimateSkillLevelResp:
			{
				auto DerivedAction = ACTION_PARSE_CharacterUltimateSkillLevelResp(Action);
				const FL2CCharacterUpgradeUltimateSkillLevelResp& Res = DerivedAction->GetVal();
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					bool bMenuBack = (Res.Info.UltimateSkillLevel >= CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);
					ResultPopup->SetUltSkillUpResult(Res.Info, Res.Old, Res.Xp);
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, bMenuBack);
				}
			}
			break;

		case EHSActionType::CharacterPromoteResp:
		case EHSActionType::CharacterUnbindResp:
		case EHSActionType::CharacterEvoluteResp:
			{
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					const FUpgradeUIState* UIState = GetUIState()->CastToUpgradeUIState();
					check(UIState);

					FCharacterId CharacterId = FCharacterId(UIState->ItemId);
					const FCharacter* Character = GetHUDStore().GetCharacterManager().Find(CharacterId);
					if (!Character)
					{
						Q6JsonLogRoze(Error, "UUpgradeWidget::OnHSEvent - Not found character", Q6KV("CharacterId", CharacterId.S));
						return;
					}

					const FCharacterInfo& Info = Character->GetInfo();
					ResultPopup->SetCharacterMaxLevelUpResult(EUpgradeCharacterCategory(UIState->UpgradeMenuIndex), Info);
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, true);
				}
			}
			break;

		case EHSActionType::CharacterTurnSkillLevelResp:
			{
				const auto DerivedAction = ACTION_PARSE_CharacterTurnSkillLevelResp(Action);
				const FL2CCharacterUpgradeTurnSkillLevelResp& Res = DerivedAction->GetVal();
				UUpgradeResultWidget* ResultPopup = GetCheckedLobbyHUD(this)->OpenUpgradeResultPopup();
				if (ResultPopup)
				{
					bool bMenuBack = (Res.Info.TurnSkill1Level >= CombatCubeConst::Q6_MAX_SKILL_LEVEL)
						&& (Res.Info.TurnSkill2Level >= CombatCubeConst::Q6_MAX_SKILL_LEVEL)
						&& (Res.Info.TurnSkill3Level >= CombatCubeConst::Q6_MAX_SKILL_LEVEL);
					ResultPopup->SetTurnSkillLevelUpResult(Res.Info, Res.Old);
					ResultPopup->OnPopupClosedDelegate.BindUObject(this, &UUpgradeWidget::OnUpgradeResultPopupClosed, bMenuBack);
				}
			}
			break;

		case EHSActionType::CharacterLoadResp:
		case EHSActionType::RelicLoadResp:
		case EHSActionType::SculptureLoadResp:
			// Preset ui. Not to do anything here
			break;
		case EHSActionType::UpgradeMenu:
		case EHSActionType::UpgradeInventory:
		case EHSActionType::UpgradeCategory:
		case EHSActionType::UpgradeItem:
		case EHSActionType::SortingChange:
		case EHSActionType::CharacterSetIllustResp:
			RefreshMenu();
			break;
		default:
			Q6JsonLogZagal(Error, "UUpgradeWidget::OnHSEvent", Q6KV("Type", (int32)Action->GetActionType()));
			break;
	}
}

void UUpgradeWidget::SetUpgradeMenu(int64 InItemId)
{
	//Roze-TODO: Set character in upgrade main

	SetNewMarks();
}

void UUpgradeWidget::SetUpgradeMenu(EUpgradeCategory Category, int32 MenuIndex, int64 ItemId)
{
	switch (Category)
	{
		case EUpgradeCategory::Character:
			SetCharacterMenu(EUpgradeCharacterCategory(MenuIndex), ItemId);
			break;

		case EUpgradeCategory::Relic:
		case EUpgradeCategory::Sculpture:
			SetEquipMenu(Category, EUpgradeEquipCategory(MenuIndex), ItemId);
			break;

		case EUpgradeCategory::Skill:
			SetSkillMenu(EUpgradeSkillCategory(MenuIndex), ItemId);
			break;
	}
}

void UUpgradeWidget::SetSkillMenu(EUpgradeSkillCategory InUpCategory, int64 ItemId)
{
	FString UpgradeSkillString = FString::Printf(TEXT("UpgradeSkillCategory_%s"), *ENUM_TO_STRING(EUpgradeSkillCategory, InUpCategory));
	TUTORIAL_MONITORING_BUTTON_CLICK(UpgradeSkillString);

	switch (InUpCategory)
	{
		case EUpgradeSkillCategory::TurnBegin:
			TurnSkillUpWidget->SetTurnSkill(FCharacterId(ItemId));
			UpgradeCategorySwitcher->SetActiveWidget(TurnSkillUpWidget);
			break;
		case EUpgradeSkillCategory::Ultimate:
			ItemLevelUpWidget->SetUltimateUp(FCharacterId(ItemId));
			UpgradeCategorySwitcher->SetActiveWidget(ItemLevelUpWidget);
			break;
	}
}

void UUpgradeWidget::SetCharacterMenu(EUpgradeCharacterCategory InUpCategory, int64 ItemId)
{
	FString UpgradeCharacterString = FString::Printf(TEXT("UpgradeCharacterCategory_%s"), *ENUM_TO_STRING(EUpgradeCharacterCategory, InUpCategory));
	TUTORIAL_MONITORING_BUTTON_CLICK(UpgradeCharacterString);
	switch (InUpCategory)
	{
		case EUpgradeCharacterCategory::LevelUp:
			ItemLevelUpWidget->SetItemLevelUp(EUpgradeCategory::Character, ItemId);
			UpgradeCategorySwitcher->SetActiveWidget(ItemLevelUpWidget);
			break;

		case EUpgradeCharacterCategory::Promote:
		case EUpgradeCharacterCategory::Unbind:
			ItemMaxLevelUpWidget->SetItemPromote(EUpgradeCategory::Character, ItemId);
			UpgradeCategorySwitcher->SetActiveWidget(ItemMaxLevelUpWidget);
			break;
		case EUpgradeCharacterCategory::Evolute:
			ItemMaxLevelUpWidget->SetCharacterEvolute(FCharacterId(ItemId));
			UpgradeCategorySwitcher->SetActiveWidget(ItemMaxLevelUpWidget);
			break;
	}
}

void UUpgradeWidget::SetEquipMenu(EUpgradeCategory ItemCategory, EUpgradeEquipCategory InUpCategory, int64 ItemId)
{
	FString UpgradeEquipmentString = FString::Printf(TEXT("UpgradeEquipmentCategory_%s"), *ENUM_TO_STRING(EUpgradeEquipCategory, InUpCategory));
	TUTORIAL_MONITORING_BUTTON_CLICK(UpgradeEquipmentString);
	switch (InUpCategory)
	{
		case EUpgradeEquipCategory::LevelUp:
			ItemLevelUpWidget->SetItemLevelUp(ItemCategory, ItemId);
			UpgradeCategorySwitcher->SetActiveWidget(ItemLevelUpWidget);
			break;

		case EUpgradeEquipCategory::Promote:
			ItemMaxLevelUpWidget->SetItemPromote(ItemCategory, ItemId);
			UpgradeCategorySwitcher->SetActiveWidget(ItemMaxLevelUpWidget);
			break;

		case EUpgradeEquipCategory::TierUp:
			ItemLevelUpWidget->SetEquipTierUp(ItemCategory, ItemId);
			UpgradeCategorySwitcher->SetActiveWidget(ItemLevelUpWidget);
			break;
	}
}

void UUpgradeWidget::SetNewMarks()
{
	TArray<ESlateVisibility> NewMarkVisibilities = GetHUDStore().GetNewMarkManager().GetUpgradeVisibilities();
	check(NewMarkVisibilities.Num() == (int32)EUpgradeCategory::Max);
	for (int32 i = 0; i < (int32)EUpgradeCategory::Max; ++i)
	{
		NewMarkImages[i]->SetVisibility(NewMarkVisibilities[i]);
	}
}

void UUpgradeWidget::OnUpgradeResultPopupClosed(bool bMenuBack)
{
	if (bMenuBack)
	{
		GetCheckedLobbyHUD(this)->GotoBack();
		return;
	}

	RefreshMenu();
}

void UUpgradeResultWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharacterImage = CastChecked<UImage>(GetWidgetFromName("Character"));
	EquipCardWidget = CastChecked<UItemBigCardWidget>(GetWidgetFromName("EquipCard"));
	MaxUpWidget = CastChecked<UResultMaxUpWidget>(GetWidgetFromName("MaxUp"));
	GainSkillWidget = CastChecked<UResultGainSkillWidget>(GetWidgetFromName("GainSkill"));
	LevelUpWidget = CastChecked<UResultLevelUpWidget>(GetWidgetFromName("LevelUp"));
	SkillTierUpWidget = CastChecked<UResultSkillTierUpWidget>(GetWidgetFromName("SkillTierUp"));
	TouchCloseBox = CastChecked<UVerticalBox>(GetWidgetFromName("TouchClose"));

	UpgradeStartAnim = GetWidgetAnimationFromName(this, "AnimUpgradeStart");

	SetCancelable(true);
	OnDismissButtonClickedDelegate.Unbind();
}

void UUpgradeResultWidget::SetCharacterAddXpResult(const FCharacterInfo& NewInfo, const FCharacterInfo& OldInfo,
	int32 GainXp,
	EUpgradeResultType UpgradeResult)
{
	LevelUpWidget->SetCharacterAddXpResult(NewInfo, OldInfo.Level, GainXp, UpgradeResult);

	if (NewInfo.UltimateSkillLevel > OldInfo.UltimateSkillLevel)
	{
		LevelUpWidget->SetResultVisibles(false, false);
		SetResultVisibles(false, false, true, true);
	}
	else
	{
		LevelUpWidget->SetResultVisibles(NewInfo.Level > OldInfo.Level, true);
		SetResultVisibles(false, false, true, false);
	}

	SetCharacter(NewInfo.Type);
}

void UUpgradeResultWidget::SetRelicAddXpResult(const FRelicInfo& NewInfo, const FRelicInfo& OldInfo,
	int32 GainXp, EUpgradeResultType UpgradeResult)
{
	MaxUpWidget->SetVisibility(ESlateVisibility::Collapsed);
	GainSkillWidget->SetVisibility(ESlateVisibility::Collapsed);

	LevelUpWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelUpWidget->SetRelicAddXpResult(NewInfo, OldInfo.Level, GainXp, UpgradeResult);

	if (NewInfo.Tier > OldInfo.Tier)
	{
		LevelUpWidget->SetResultVisibles(false, false);
		SetResultVisibles(false, false, true, true);
	}
	else
	{
		LevelUpWidget->SetResultVisibles(NewInfo.Level > OldInfo.Level, true);
		SetResultVisibles(false, false, true, false);
	}

	SetRelic(NewInfo.Type);
}

void UUpgradeResultWidget::SetSculptureAddXpResult(const FSculptureInfo& NewInfo, const FSculptureInfo& OldInfo,
	int32 GainXp, EUpgradeResultType UpgradeResult)
{
	MaxUpWidget->SetVisibility(ESlateVisibility::Collapsed);
	GainSkillWidget->SetVisibility(ESlateVisibility::Collapsed);

	LevelUpWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LevelUpWidget->SetSculptureAddXpResult(NewInfo, OldInfo.Level, GainXp, UpgradeResult);

	if (NewInfo.Tier > OldInfo.Tier)
	{
		LevelUpWidget->SetResultVisibles(false, false);
		SetResultVisibles(false, false, true, true);
	}
	else
	{
		LevelUpWidget->SetResultVisibles(NewInfo.Level > OldInfo.Level, true);
		SetResultVisibles(false, false, true, false);
	}

	SetSculpture(NewInfo.Type);
}

void UUpgradeResultWidget::SetUltSkillUpResult(
	const FCharacterInfo& NewInfo,
	const FCharacterInfo& OldInfo,
	int32 GainXp)
{
	SkillTierUpWidget->SetUltSkill(NewInfo.Type, OldInfo.UltimateSkillLevel, NewInfo.UltimateSkillLevel);

	SetCharacterAddXpResult(NewInfo, OldInfo, GainXp);
}

void UUpgradeResultWidget::SetRelicTierUpResult(
	const FRelicInfo& NewInfo,
	const FRelicInfo& OldInfo,
	int32 GainXp)
{
	SkillTierUpWidget->SetRelic(NewInfo.Type, OldInfo.Tier, NewInfo.Tier);

	SetRelicAddXpResult(NewInfo, OldInfo, GainXp);
}

void UUpgradeResultWidget::SetSculptureTierUpResult(
	const FSculptureInfo& NewInfo,
	const FSculptureInfo& OldInfo,
	int32 GainXp)
{
	SkillTierUpWidget->SetSculpture(NewInfo.Type, OldInfo.Tier, NewInfo.Tier);

	SetSculptureAddXpResult(NewInfo, OldInfo, GainXp);
}

void UUpgradeResultWidget::SetTurnSkillLevelUpResult(const FCharacterInfo& NewInfo, const FCharacterInfo& OldInfo)
{
	const UCMS* CMS = GetCMS();
	const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(NewInfo.Type);

	int32 TurnSkillIndex = GetUpgradedTurnSkillIndex(NewInfo, OldInfo);
	int32 SkillLevel = GetTurnSkillLevel(NewInfo, TurnSkillIndex);

	if (SkillLevel <= 0)
	{
		Q6JsonLogRoze(Error, "UUpgradeResultWidget::SetTurnSkillLevelUpResult - Not opened turn skill",
			Q6KV("CharacterType", NewInfo.Type.x), Q6KV("TurnSkillIndex", TurnSkillIndex));
		return;
	}

	const FCMSSkillRow* SkillRow = CMS->GetCharacterTurnSkillRow(UnitRow, TurnSkillIndex);
	if (!SkillRow)
	{
		Q6JsonLogRoze(Error, "UUpgradeResultWidget::SetTurnSkillLevelUpResult - Not found turn skill");
		return;
	}

	SkillTierUpWidget->SetTurnSkill(*SkillRow, UnitRow.Model, TurnSkillIndex, SkillLevel);

	SetResultVisibles(false, false, false, true);
	SetCharacter(NewInfo.Type);
}

void UUpgradeResultWidget::SetCharacterMaxLevelUpResult(EUpgradeCharacterCategory UpCategory, const FCharacterInfo& Info)
{
	bool bGainSkill = !SystemConstHelper::IsWeed(Info.Type) && SystemConstHelper::IsGainedTurnSkill(Info.Star);
	if (bGainSkill)
	{
		int32 OpenedSkillIndex = SystemConstHelper::GetCharacterTurnSkillCount(Info.Star) - 1;
		GainSkillWidget->SetTurnSkill(Info.Type, OpenedSkillIndex);
		GainSkillWidget->SetTitleVisible(false);
	}

	MaxUpWidget->SetCharacter((EMaxUpCategory)((int32)UpCategory - 1), Info);
	SetResultVisibles(true, bGainSkill, false, false);
	SetCharacter(Info.Type);

	int32 LastUnbindStar = SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Unbind, Info.Grade);
	bool bGainFinalArt = Info.Star == LastUnbindStar && Info.Moon == 0 && Info.Grade >= EItemGrade::SR;
	if (bGainFinalArt)
	{
		SetCancelable(false);
		OnDismissButtonClickedDelegate.BindUObject(this, &UUpgradeResultWidget::OpenGainFinalArtPopup, Info.Type);
	}
}

void UUpgradeResultWidget::SetRelicPromoteResult(const FRelicInfo& Info)
{
	MaxUpWidget->SetEquip(Info.Level, Info.Star - 1, Info.Star);

	SetResultVisibles(true, false, false, false);
	SetRelic(Info.Type);
}

void UUpgradeResultWidget::SetSculpturePromoteResult(const FSculptureInfo& Info)
{
	MaxUpWidget->SetEquip(Info.Level, Info.Star - 1, Info.Star);

	SetResultVisibles(true, false, false, false);
	SetSculpture(Info.Type);
}

void UUpgradeResultWidget::SetWeedGrowResult(FWeedGrowType WeedGrowType, const FCharacterInfo& WeedInfo)
{
	const FCMSWeedGrowRow& WeedRow = GetCMS()->GetWeedGrowRowOrDummy(WeedGrowType);
	if (WeedRow.IsInvalid())
	{
		return;
	}

	switch (WeedRow.Category)
	{
		case EWeedGrowCategory::TurnSkillOpen:
			OnWeedTurnSkillOpen(WeedInfo, WeedRow.TurnSkillIndex);
			break;
		case EWeedGrowCategory::CharacterLevelUp:
			OnWeedUpgrade(WeedInfo);
			break;
		case EWeedGrowCategory::UltimateSkillLevelUp:
			OnWeedUltimateSkillLevelUp(WeedInfo, WeedGrowType);
			break;
		case EWeedGrowCategory::ChangeUltimateSkill:
			OnWeedUltimateSkillChange(WeedInfo, WeedGrowType);
			break;
	}
}

void UUpgradeResultWidget::SetResultVisibles(bool bMaxUp, bool bGainSkill, bool bLevelUp, bool bSkillTierUp)
{
	MaxUpWidget->SetVisibility(bMaxUp ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	GainSkillWidget->SetVisibility(bGainSkill ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	LevelUpWidget->SetVisibility(bLevelUp ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	SkillTierUpWidget->SetVisibility(bSkillTierUp ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	PlayAnimation(UpgradeStartAnim);
}

void UUpgradeResultWidget::SetCharacter(FCharacterType CharacterType)
{
	CharacterImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	EquipCardWidget->SetVisibility(ESlateVisibility::Collapsed);

	const FCharacterAssetRow& AssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
	CharacterImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.BodyTexture);
}

void UUpgradeResultWidget::SetSculpture(FSculptureType SculptureType)
{
	CharacterImage->SetVisibility(ESlateVisibility::Collapsed);
	EquipCardWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	EquipCardWidget->SetSculpture(SculptureType);
}

void UUpgradeResultWidget::SetRelic(FRelicType RelicType)
{
	CharacterImage->SetVisibility(ESlateVisibility::Collapsed);
	EquipCardWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	EquipCardWidget->SetRelic(RelicType);
}

void UUpgradeResultWidget::OpenGainFinalArtPopup(FCharacterType CharacterType)
{
	MaxUpWidget->SetVisibility(ESlateVisibility::Collapsed);
	TouchCloseBox->SetVisibility(ESlateVisibility::Collapsed);

	UGainFinalArtWidget* GainFinalArtWidget = CastChecked<UGainFinalArtWidget>(GetCheckedLobbyHUD(this)->OpenPopup(GainFinalArtWidgetClass));
	GainFinalArtWidget->SetCharacter(CharacterType);
	GainFinalArtWidget->OnPopupClosedDelegate.BindUObject(this, &UUpgradeResultWidget::ClosePopup);
}

void UUpgradeResultWidget::OnWeedTurnSkillOpen(const FCharacterInfo& Info, int32 TurnSkillIndex)
{
	GainSkillWidget->SetTurnSkill(Info.Type, TurnSkillIndex);
	GainSkillWidget->SetTitleVisible(true);

	SetResultVisibles(false, true, false, false);
	SetCharacter(Info.Type);
}

void UUpgradeResultWidget::OnWeedUpgrade(const FCharacterInfo& Info)
{
	const UCMS* CMS = GetCMS();

	EUpgradeCharacterCategory Category = EUpgradeCharacterCategory::Evolute;

	if (Info.Star < SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Promote, Info.Grade))
	{
		Category = EUpgradeCharacterCategory::Promote;
	}
	else if (Info.Star < SystemConstHelper::GetCharacterMaxPromoteStar(EUpgradeCharacterCategory::Unbind, Info.Grade))
	{
		Category = EUpgradeCharacterCategory::Unbind;
	}

	SetCharacterMaxLevelUpResult(Category, Info);
}

void UUpgradeResultWidget::OnWeedUltimateSkillLevelUp(const FCharacterInfo& Info, FWeedGrowType WeedGrowType)
{
	int32 OldSkillLevel = 1;
	const FCMSWeedGrowRow* OldRow = GetCMS()->GetPreWeedGrowRow(WeedGrowType);
	if (OldRow)
	{
		OldSkillLevel = OldRow->UltimateSkillLevel;
	}

	SkillTierUpWidget->SetUltSkill(Info.Type, OldSkillLevel, Info.UltimateSkillLevel);

	SetResultVisibles(false, false, false, true);
	SetCharacter(Info.Type);
}

void UUpgradeResultWidget::OnWeedUltimateSkillChange(const FCharacterInfo& Info, FWeedGrowType WeedGrowType)
{
	int32 OldSkillLevel = 1;
	const FCMSWeedGrowRow* OldRow = GetCMS()->GetPreWeedGrowRow(WeedGrowType);
	if (OldRow)
	{
		OldSkillLevel = OldRow->UltimateSkillLevel;
	}

	SkillTierUpWidget->ChangeUltSkill(
		FCharacterType(SystemConst::Q6_WEED_CHARACTER_ID),
		OldSkillLevel,
		Info.Type,
		Info.UltimateSkillLevel);

	SetResultVisibles(false, false, false, true);
	SetCharacter(Info.Type);
}
