#include "HealthBarWidget.h"
#include "CombatHUD.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "Q6.h"
#include "Q6Util.h"
#include "RaidManager.h"
#include "Unit.h"
#include "Blueprint/WidgetLayoutLibrary.h"

static EHealthBarAction _GetHealthBarAction(EHealthChangeReason Reason, int32 HitIndex, int32 HitMax)
{
	switch (Reason)
	{
		case EHealthChangeReason::Heal:
		case EHealthChangeReason::Sucking:
			return EHealthBarAction::Recover;
		case EHealthChangeReason::HealBlock:
			return EHealthBarAction::HealBlock;
		case EHealthChangeReason::Damage:
			{
				if (HitMax == 1)
				{
					return EHealthBarAction::SingleHit;
				}

				if (HitIndex == 0)
				{
					return EHealthBarAction::FirstHit;
				}
				else if (HitIndex == HitMax - 1)
				{
					return EHealthBarAction::LastHit;
				}
				else
				{
					return EHealthBarAction::Hit;
				}
			}
		default:
			break;
	}

	return EHealthBarAction::None;
}

UHealthBarWidget::UHealthBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, StartPercent(1.f)
	, CurPercent(1.f)
	, GaugeDivisor(1)
	, MaxGaugeCount(MIN_HEALTHBAR_GAUGE_COUNT)
{
}

void UHealthBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ImmediateProgress = CastChecked<UProgressBar>(GetWidgetFromName("Progress"));
	UpdateProgress = CastChecked<UProgressBar>(GetWidgetFromName("ProgressDamaged"));
	GaugeCountText = CastChecked<UQ6TextBlock>(GetWidgetFromName("GaugeCount"));
	HPText = CastChecked<UTextBlock>(GetWidgetFromName("TextHP"));
	ShieldText = CastChecked<UTextBlock>(GetWidgetFromName("TextShieldHP"));
}

void UHealthBarWidget::InitHealthBar(const FUnitState& InUnitState)
{
	bool bBoss = IsBossMonsterCategory(InUnitState.Category);
	InitHealthBar(InUnitState.Health, InUnitState.MaxHealth, InUnitState.UnitType, InUnitState.Faction, bBoss);
}

void UHealthBarWidget::InitRaidTotalHealthBar(const EAttributeCategory InCategory
	, const int32 InUnitType, const int32 InTotalHealth)
{
	bool bBoss = IsBossMonsterCategory(InCategory);
	InitHealthBar(InTotalHealth, InTotalHealth, InUnitType, ECCFaction::Enemy, bBoss);
}

static int32 _GetGaugeCount(int32 InHealth, int32 InDivisor, int32 InMaxCount)
{
	if (InDivisor == 0)
	{
		return MIN_HEALTHBAR_GAUGE_COUNT;
	}

	return FMath::Clamp((InHealth - 1) / InDivisor + 1, 1, InMaxCount);
}

static int32 _GetGaugeIndex(int32 InGaugeCount)
{
	int32 GaugeIndex = (InGaugeCount % MAX_HEALTHBAR_GAUGE_COUNT) - 1;
	if (GaugeIndex < 0)
	{
		GaugeIndex += MAX_HEALTHBAR_GAUGE_COUNT;
	}

	return GaugeIndex;
}

void UHealthBarWidget::InitHealthBar(int32 InHealth, int32 InMaxHealth, int32 InUnitType, ECCFaction InFaction, bool bBoss)
{
	HPText->SetText(FText::AsNumber(InHealth));

	if (bBoss)
	{
		UGameResource& GameResource = GetGameResource();
		const FBossSettingAssetRow& BossSettingAssetRow = GameResource.GetBossSettingAssetRow(InUnitType);
		MaxGaugeCount = FMath::Max(MIN_HEALTHBAR_GAUGE_COUNT, BossSettingAssetRow.GaugeCount);
		GaugeCountText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		GaugeCountText->SetVisibility(ESlateVisibility::Collapsed);
	}

	GaugeDivisor = FMath::Max(1, InMaxHealth / MaxGaugeCount);

	int32 GaugeCount = _GetGaugeCount(InHealth, GaugeDivisor, MaxGaugeCount);
	GaugeCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "GaugeCount"), FText::AsNumber(GaugeCount)));

	int32 GaugeIndex = _GetGaugeIndex(GaugeCount);
	OnHealthBarGaugeChange(GaugeIndex, GaugeCount, InFaction == ECCFaction::Ally);

	StartPercent = CurPercent = GetCurrentHealthRatio(InHealth);
	ImmediateProgress->SetPercent(CurPercent);
	UpdateProgress->SetPercent(CurPercent);
}

void UHealthBarWidget::SetHealthState(int32 InNewHealth, EHealthChangeReason Reason, int32 InHitIndex, int32 InHitMax, bool bAlly)
{
	HPText->SetText(FText::AsNumber(InNewHealth));

	int32 GaugeCount = _GetGaugeCount(InNewHealth, GaugeDivisor, MaxGaugeCount);
	GaugeCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "GaugeCount"), FText::AsNumber(GaugeCount)));

	int32 GaugeIndex = _GetGaugeIndex(GaugeCount);
	OnHealthBarGaugeChange(GaugeIndex, GaugeCount, bAlly);

	float NewPercent = GetCurrentHealthRatio(InNewHealth);

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->AddProgressTask(ImmediateProgress, NewPercent, 0.f);
	CombatHUD->AddProgressTask(UpdateProgress, NewPercent, AnimationTime);

	EHealthBarAction HealthBarAction = _GetHealthBarAction(Reason, InHitIndex, InHitMax);
	if (HealthBarAction == EHealthBarAction::FirstHit || HealthBarAction == EHealthBarAction::SingleHit)
	{
		StartPercent = CurPercent;
	}

	OnHealthBarState(StartPercent, NewPercent, HealthBarAction);
	CurPercent = NewPercent;
}

void UHealthBarWidget::SetRaidTotalHealth(int32 InNewHealth, EHealthBarAction InBarAction)
{
	HPText->SetText(FText::AsNumber(InNewHealth));

	int32 GaugeCount = _GetGaugeCount(InNewHealth, GaugeDivisor, MaxGaugeCount);
	GaugeCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Combat", "GaugeCount"), FText::AsNumber(GaugeCount)));

	int32 GaugeIndex = _GetGaugeIndex(GaugeCount);
	OnHealthBarGaugeChange(GaugeIndex, GaugeCount, false);

	float NewPercent = GetCurrentHealthRatio(InNewHealth);

	ACombatHUD* CombatHUD = GetCheckedCombatHUD(this);
	CombatHUD->AddProgressTask(ImmediateProgress, NewPercent, 0.f);
	CombatHUD->AddProgressTask(UpdateProgress, NewPercent, AnimationTime);

	OnHealthBarState(StartPercent, NewPercent, InBarAction);
	CurPercent = NewPercent;
}

void UHealthBarWidget::SetOtherUserCharacterHealthBar(const int32 InHealth, const int32 InMaxHealth)
{
	check(InMaxHealth > 0);

	HPText->SetText(FText::AsNumber(InHealth));
	GaugeCountText->SetVisibility(ESlateVisibility::Collapsed);

	float Percent = (float)InHealth / (float)InMaxHealth;
	ImmediateProgress->SetPercent(Percent);
	UpdateProgress->SetPercent(Percent);
}

float UHealthBarWidget::GetCurrentHealthRatio(int32 InNewHealth) const
{
	int32 HealthMod = InNewHealth % GaugeDivisor;
	if (HealthMod != 0)
	{
		return (float)HealthMod / GaugeDivisor;
	}
	else
	{
		return InNewHealth == 0 ? 0.f : 1.f;
	}
}

void UHealthBarWidget::SetShield(int32 InNewShield)
{
	ShieldText->SetText(FText::FromString(FString::Printf(TEXT("[%d]"), InNewShield)));

	if (InNewShield > 0)
	{
		ShieldText->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		ShieldText->SetVisibility(ESlateVisibility::Collapsed);
	}
}

UShieldBarWidget::UShieldBarWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Shield(0)
	, MaxShield(0)
{
}

void UShieldBarWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ShieldDamageAnim = GetWidgetAnimationFromName(this, "AnimShieldCut");
	ShieldWeakPointDamageAnim = GetWidgetAnimationFromName(this, "AnimShieldCutHuge");
	ShieldOnAnim = GetWidgetAnimationFromName(this, "AnimShieldOn");
	ShieldOffAnim = GetWidgetAnimationFromName(this, "AnimShieldOff");

	ProgressBar = CastChecked<UProgressBar>(GetWidgetFromName("Progress"));
	CutSlider = CastChecked<USlider>(GetWidgetFromName("SliderCutThumb"));
}

void UShieldBarWidget::InitShieldBar(UHealthBarWidget* InHealthBarWidget, int32 InShield, int32 InMaxShield, bool bAnimate)
{
	Shield = InShield;
	MaxShield = InMaxShield;

	InHealthBarWidget->SetShield(Shield);

	float ProgressPercent = (float)Shield / MaxShield;
	ProgressBar->SetPercent(ProgressPercent);
	CutSlider->SetValue(ProgressPercent);

	SetShieldState(InHealthBarWidget, true, bAnimate);
}

void UShieldBarWidget::SetShieldState(UHealthBarWidget* InHealthBarWidget, bool bActivate, bool bAnimate)
{
	if (bActivate)
	{
		if (bAnimate)
		{
			PlayAnimation(ShieldOnAnim);
		}
		else
		{
			SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		}
	}
	else
	{
		if (bAnimate)
		{
			PlayAnimation(ShieldOffAnim);
		}
		else
		{
			SetVisibility(ESlateVisibility::Collapsed);
		}

		InHealthBarWidget->SetShield(0);
	}
}

void UShieldBarWidget::SetShieldDamage(UHealthBarWidget* InHealthBarWidget, int32 InDamage, int32 InExtraDamage, bool bInWeakPoint)
{
	if (!MaxShield)
	{
		return;
	}

	Shield += InDamage + InExtraDamage;

	InHealthBarWidget->SetShield(Shield);

	float ProgressPercent = (float)Shield / MaxShield;
	ProgressBar->SetPercent(ProgressPercent);
	CutSlider->SetValue(ProgressPercent);

	if (bInWeakPoint)
	{
		PlayAnimation(ShieldWeakPointDamageAnim);
	}
	else
	{
		PlayAnimation(ShieldDamageAnim);
	}
}