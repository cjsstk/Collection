#include "WeeklyMissionWidgets.h"

#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "SystemConst_gen.h"
#include "WeeklyMissionManager.h"
#include "WidgetUtil.h"

UWeeklyMissionWidget::UWeeklyMissionWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SelectedMissionButtonIndex(INDEX_NONE)
	, RequestMissionItemIndex(INDEX_NONE)
	, RequestBingoItemIndex(INDEX_NONE)
{
	for (int32 RowIndex = 0; RowIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++RowIndex)
	{
		TArray<EMissionBingoBoardState> RowArr;
		for (int32 ColIndex = 0; ColIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++ColIndex)
		{
			RowArr.Add(EMissionBingoBoardState::Normal);
		}
		BingoBoard.Emplace(RowArr);
	}
}

void UWeeklyMissionWidget::NativeConstruct()
{
	Super::NativeConstruct();

	WeeklyMissionAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMissionStart"));
	WeeklyMissionAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMissionStateSelected"));
	WeeklyMissionAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMissionStateNone"));
	WeeklyMissionAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimMissionStateShuffle"));
	check(WeeklyMissionAnims.Num() == static_cast<int32>(EWeeklyMissionAnimType::Max));

	ShuffleButton = CastChecked<UQ6Button>(GetWidgetFromName("Shuffle"));
	ShuffleButton->OnClickedDelegate.BindUObject(this, &UWeeklyMissionWidget::OnShuffleButtonClicked);

	RequiredCurrencyBorder = CastChecked<UBorder>(GetWidgetFromName("RequiredCurrency"));
	FreeBorder = CastChecked<UBorder>(GetWidgetFromName("Free"));

	ConsumeGoldPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("ConsumeGold"));
	ConsumeGoldPointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);

	DescMissionGaugeWidget = CastChecked<UMissionGaugeWidget>(GetWidgetFromName("MissionGauge"));
	DescItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("SelectedItem"));

	TimeInfoText = CastChecked<UTextBlock>(GetWidgetFromName("TimeInfo"));

	ShuffleButtonImage = CastChecked<UImage>(GetWidgetFromName("ShuffleBtnImg"));
	NewMarkImage = CastChecked<UImage>(GetWidgetFromName("NewMark"));

	FString WidgetName;
	for (int32 MissionButtonNum = 1; MissionButtonNum <= MAX_WEEKLY_MISSION; ++MissionButtonNum)
	{
		WidgetName = FString::Printf(TEXT("MissionBtn%02d"), MissionButtonNum);

		UMissionButtonWidget* MissionButtonWidget = CastChecked<UMissionButtonWidget>(
			GetWidgetFromName(*WidgetName));
		MissionButtonWidget->OnMissionToggleClickedDelegate.BindUObject(
			this, &UWeeklyMissionWidget::OnMissionToggleBtnClicked, MissionButtonNum - 1);
		MissionButtonWidget->OnMissionShuffleAnimFinished.BindUObject(
			this, &UWeeklyMissionWidget::OnMissionShuffleAnimFinished);
		MissionButtonWidget->OnMissionCompleteStartAnimFinished.BindUObject(
			this, &UWeeklyMissionWidget::OnMissionCompleteStartAnimFinished, MissionButtonNum - 1);

		MissionButtonWidgets.AddUnique(MissionButtonWidget);
	}

	for (int32 MissionBonusButtonNum = 1; MissionBonusButtonNum <= MAX_WEEKLY_BINGO; ++MissionBonusButtonNum)
	{
		WidgetName = FString::Printf(TEXT("MissionBonusBtn%02d"), MissionBonusButtonNum);
		UMissionBonusButtonWidget* MissionBonusButtonWidget = CastChecked<UMissionBonusButtonWidget>(
			GetWidgetFromName(*WidgetName));
		MissionBonusButtonWidget->OnMissionBonusButtonClickedDelegate.BindUObject(
			this, &UWeeklyMissionWidget::OnMissionBonusButtonClicked, MissionBonusButtonNum - 1);

		MissionBonusButtonWidgets.AddUnique(MissionBonusButtonWidget);
	}
}

void UWeeklyMissionWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::WorldUser);
	SubscribeToStore(EHSType::WeeklyMission);

	for (UMissionButtonWidget* MissionButtonWidget : MissionButtonWidgets)
	{
		if (MissionButtonWidget)
		{
			MissionButtonWidget->SetCheckedState(ECheckBoxState::Unchecked);
		}
	}

	ResetInfo(true);

	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::Start);
	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::StateNone);

	const UWeeklyMissionManager& MissionMgr = GetHUDStore().GetWeeklyMissionManager();
	const FMissionInfo& Missioninfo = MissionMgr.GetMissioninfo();

	ESlateVisibility NewMarkVisibility = GetHUDStore().GetNewMarkManager().GetWeeklyMissionConfirmVisibility(Missioninfo);
	NewMarkImage->SetVisibility(NewMarkVisibility);

	if (MissionMgr.IsExpiredWeeklyMission() || !Missioninfo.Confirmed)
	{
		MissionMgr.ReqConfirm();
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "NewWeeklyMission"));
	}
}

void UWeeklyMissionWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FWeeklyMissionUIState* UIState = GetUIState()->CastToWeeklyMissionUIState();
	check(UIState);

	ResetInfo(false);
}

void UWeeklyMissionWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	EHSActionType ActionType = Action->GetActionType();
	switch (ActionType)
	{
		case EHSActionType::WeeklyMissionRewardResp:
			OpenReceivedRewardItemPopup();
			break;

		case EHSActionType::WeeklyMissionBingoResp:
			OpenReceivedBingoItemPopup();
			break;

		case EHSActionType::ContentsResetTime:
		{
			const UWeeklyMissionManager& MissionMgr = GetHUDStore().GetWeeklyMissionManager();
			if (MissionMgr.IsExpiredWeeklyMission())
			{
				NewMarkImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

				MissionMgr.ReqConfirm();
				GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "NewWeeklyMission"));
			}
			break;
		}

		case EHSActionType::WeeklyMissionShuffleResp:
		case EHSActionType::DevAddCurrencyResp:
		case EHSActionType::WeeklyMissionLoadResp:
			RefreshMenu();
			break;
	}
}

void UWeeklyMissionWidget::OnItemReceivedPopupClosed()
{
	ResetInfo(false);
}

void UWeeklyMissionWidget::ResetInfo(bool bEnterMenu)
{
	const UWeeklyMissionManager& MissionManager = GetHUDStore().GetWeeklyMissionManager();
	const FMissionInfo& MissionInfo = MissionManager.GetMissioninfo();

	const UCMS* CMS = GetCMS();
	check(CMS);

	for (int32 MissionIndex = 0; MissionIndex < MAX_WEEKLY_MISSION; ++MissionIndex)
	{
		check(MissionInfo.M.IsValidIndex(MissionIndex));
		check(MissionInfo.MIng.IsValidIndex(MissionIndex));
		check(MissionInfo.RUtc.IsValidIndex(MissionIndex));

		const int32 Row = MissionIndex / MAX_MISSION_BINGO_BOARD_SIZE;
		const int32 Col = MissionIndex % MAX_MISSION_BINGO_BOARD_SIZE;

		check(BingoBoard.IsValidIndex(Row));
		check(BingoBoard[Row].IsValidIndex(Col));

		if (BingoBoard[Row][Col] == EMissionBingoBoardState::Complete)
		{
			ShuffleButtonImage->SetIsEnabled(false);
			continue;
		}

		const FMissionType& Type = MissionInfo.M[MissionIndex];
		const FCMSMissionRow& MissionRow = CMS->GetMissionRowOrDummy(Type);

		const int32 CurrValue = MissionInfo.MIng[MissionIndex];
		const int32 MaxValue = MissionManager.GetMaxValue(Type);
		const int32 RewardUTC = MissionInfo.RUtc[MissionIndex];

		if (RewardUTC > 0)
		{
			BingoBoard[Row][Col] = EMissionBingoBoardState::Complete;
			ShuffleButtonImage->SetIsEnabled(false);
		}
		else if (CurrValue >= MaxValue)
		{
			BingoBoard[Row][Col] = EMissionBingoBoardState::Activate;
		}
		else
		{
			BingoBoard[Row][Col] = EMissionBingoBoardState::Normal;
		}

		if (!MissionButtonWidgets[MissionIndex]->SetBingo(Row, Col, MissionInfo))
		{
			MissionButtonWidgets[MissionIndex]->SetInfo(Type
				, MissionRow.Desc
				, CurrValue
				, MaxValue
				, RewardUTC
				, bEnterMenu
				, RequestMissionItemIndex == MissionIndex);
		}
	}

	for (int32 MissionBonusIndex = 0; MissionBonusIndex < MAX_WEEKLY_BINGO; ++MissionBonusIndex)
	{
		check(MissionInfo.BUtc.IsValidIndex(MissionBonusIndex));

		const int32 BingoUTC = MissionInfo.BUtc[MissionBonusIndex];

		bool bEnable = false;
		if (BingoUTC == 0)
		{
			bEnable = CheckMissionBonus(MissionBonusIndex);
		}

		if (bEnable && bEnterMenu)
		{
			PlayMissionButtonBingoAnimation(MissionBonusIndex);
		}

		check(MissionBonusButtonWidgets.IsValidIndex(MissionBonusIndex));
		MissionBonusButtonWidgets[MissionBonusIndex]->SetInfo(MissionBonusIndex
			, MissionInfo.WeekNum
			, bEnable
			, BingoUTC
		);
	}

	SetRequireGold(GetShuffleRequireGold(MissionInfo.ResetCount));
	SetRemainTimeInfo();
	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::Start);

	RequestMissionItemIndex = INDEX_NONE;
	RequestBingoItemIndex = INDEX_NONE;
}

void UWeeklyMissionWidget::PlayWeeklyMissionAnim(EWeeklyMissionAnimType Type)
{
	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (WeeklyMissionAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(WeeklyMissionAnims[AnimIndex]);
	}
}

void UWeeklyMissionWidget::OpenReceivedBingoItemPopup()
{
	if (RequestBingoItemIndex == INDEX_NONE)
	{
		return;
	}

	const FMissionInfo& MissionInfo = GetHUDStore().GetWeeklyMissionManager().GetMissioninfo();
	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSMissionSetRow* MissionSetRow = CMS->GetMissionSetRowByWeekNum(MissionInfo.WeekNum);
	if (!MissionSetRow)
	{
		return;
	}

	const TArray<const FCMSLootGroupRow*>& LootGroupRows = MissionSetRow->GetLootGroup();
	if (!LootGroupRows.IsValidIndex(RequestBingoItemIndex))
	{
		Q6JsonLogGenie(Error, "no exist missionSet LootGroupRow", Q6KV("weekNum", MissionInfo.WeekNum));
		return;
	}

	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(
		*LootGroupRows[RequestBingoItemIndex]);

	UItemReceivedPopupWidget* ItemReceivedPopup = GetLobbyHUD(this)->OpenItemReceivedPopup();
	ItemReceivedPopup->SetMissionReceivedItem(LootDataRow);
	ItemReceivedPopup->OnPopupClosedDelegate.BindUObject(this
		, &UWeeklyMissionWidget::OnItemReceivedPopupClosed);
}

void UWeeklyMissionWidget::OpenReceivedRewardItemPopup()
{
	if (RequestMissionItemIndex == INDEX_NONE)
	{
		return;
	}


	const FMissionInfo& MissionInfo = GetHUDStore().GetWeeklyMissionManager().GetMissioninfo();
	const UCMS* CMS = GetCMS();
	check(CMS);

	if (!MissionInfo.M.IsValidIndex(RequestMissionItemIndex))
	{
		return;
	}

	const FMissionType& MissionType = MissionInfo.M[RequestMissionItemIndex];
	const FCMSMissionRow& MissionRow = CMS->GetMissionRowOrDummy(MissionType);
	const FCMSLootGroupRow& LootGroupRow = MissionRow.GetLootGroup();
	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRow);

	UItemReceivedPopupWidget* ItemReceivedPopup = GetLobbyHUD(this)->OpenItemReceivedPopup();
	ItemReceivedPopup->SetMissionReceivedItem(LootDataRow);
	ItemReceivedPopup->OnPopupClosedDelegate.BindUObject(this
		, &UWeeklyMissionWidget::OnItemReceivedPopupClosed);
}

void UWeeklyMissionWidget::SetRequiredCurrency(const int64 InRequireGold)
{
	if (InRequireGold <= 0)
	{
		RequiredCurrencyBorder->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		RequiredCurrencyBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

		const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
		ConsumeGoldPointWidget->SetPoint(InRequireGold, WorldUser.GetGold());
		ConsumeGoldPointWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

void UWeeklyMissionWidget::SetFreeBorder(bool bFree)
{
	if (bFree)
	{
		FreeBorder->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		FreeBorder->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UWeeklyMissionWidget::SetRequireGold(const int64 InRequireGold)
{
	SetFreeBorder(InRequireGold == 0);
	SetRequiredCurrency(InRequireGold);
}

void UWeeklyMissionWidget::SetMissionDesc(const int32 Index)
{
	const UWeeklyMissionManager& WeeklyMissionManager = GetHUDStore().GetWeeklyMissionManager();
	const FMissionInfo& Missioninfo = WeeklyMissionManager.GetMissioninfo();

	const UCMS* CMS = GetCMS();
	check(CMS);

	check(Missioninfo.M.IsValidIndex(Index));
	const FMissionType& Type = Missioninfo.M[Index];
	const FCMSMissionRow& MissionRow = CMS->GetMissionRowOrDummy(Type);
	if (MissionRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist mission type", Q6KV("type", Type));
		return;
	}

	check(Missioninfo.MIng.IsValidIndex(Index));
	const int32 MaxValue = WeeklyMissionManager.GetMaxValue(Type);
	const int32 Value = FMath::Clamp(Missioninfo.MIng[Index], 0, MaxValue);

	DescMissionGaugeWidget->SetInfo(MissionRow.Desc
		, Value
		, Value
		, MaxValue
		, Value < MaxValue);

	const FCMSLootGroupRow& LootGroupRow = MissionRow.GetLootGroup();
	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRow);

	DescItemWidget->SetRewardType(ERewardType::None);
	DescItemWidget->SetLoot(LootDataRow.LootId, LootDataRow.Count);

	if (Value < MaxValue)
	{
		DescItemWidget->SetChecked(false);
	}
	else if(Value == MaxValue)
	{
		DescItemWidget->SetChecked(true);
	}

	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::Start);
	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::StateSelected);
}

void UWeeklyMissionWidget::SetRemainTimeInfo()
{
	EDayOfWeekType DayOfWeekType = GetTodayOfWeek();
	int32 RemainDay = static_cast<int32>(EDayOfWeekType::Sat) - static_cast<int32>(DayOfWeekType);
	int32 RemainHour = 24 - FDateTime::Now().GetHour();

	FText TimeText = FText::Format(Q6Util::GetLocalizedText("Lobby", "MissionPeriod")
		, RemainDay, RemainHour);

	TimeInfoText->SetText(TimeText);
}

void UWeeklyMissionWidget::PlayShuffleAnimation()
{
	for (UMissionButtonWidget* MissionButtonWidget : MissionButtonWidgets)
	{
		check(MissionButtonWidget);

		MissionButtonWidget->PlayShuffleAnimation();
	}
}

void UWeeklyMissionWidget::PlayMissionButtonBingoAnimation(const int32 MissionBonusIndex)
{
	if (MissionBonusIndex < MAX_MISSION_BINGO_BOARD_SIZE)
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = MissionBonusIndex;
			const int32 Col = BingoCheckIndex;

			const int32 MissionButtonIndex = Row * MAX_MISSION_BINGO_BOARD_SIZE + Col;
			if (MissionButtonWidgets.IsValidIndex(MissionButtonIndex))
			{
				MissionButtonWidgets[MissionButtonIndex]->PlayMissionButtonAnim(EMissionButtonAnimType::Bingo);
			}
		}
	}
	else if (MissionBonusIndex == MAX_MISSION_BINGO_BOARD_SIZE)
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = BingoCheckIndex;
			const int32 Col = BingoCheckIndex;

			const int32 MissionButtonIndex = Row * MAX_MISSION_BINGO_BOARD_SIZE + Col;
			if (MissionButtonWidgets.IsValidIndex(MissionButtonIndex))
			{
				MissionButtonWidgets[MissionButtonIndex]->PlayMissionButtonAnim(EMissionButtonAnimType::Bingo);
			}
		}
	}
	else if (MissionBonusIndex < MAX_WEEKLY_BINGO - 1)
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = BingoCheckIndex;
			const int32 Col = MAX_WEEKLY_BINGO - MissionBonusIndex - 2;

			const int32 MissionButtonIndex = Row * MAX_MISSION_BINGO_BOARD_SIZE + Col;
			if (MissionButtonWidgets.IsValidIndex(MissionButtonIndex))
			{
				MissionButtonWidgets[MissionButtonIndex]->PlayMissionButtonAnim(EMissionButtonAnimType::Bingo);
			}
		}
	}
	else
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = BingoCheckIndex;
			const int32 Col = MAX_MISSION_BINGO_BOARD_SIZE - BingoCheckIndex - 1;

			const int32 MissionButtonIndex = Row * MAX_MISSION_BINGO_BOARD_SIZE + Col;
			if (MissionButtonWidgets.IsValidIndex(MissionButtonIndex))
			{
				MissionButtonWidgets[MissionButtonIndex]->PlayMissionButtonAnim(EMissionButtonAnimType::Bingo);
			}
		}
	}
}

int64 UWeeklyMissionWidget::GetShuffleRequireGold(const int32 ResetCount)
{
	if (ResetCount == 0)
	{
		return 0;
	}
	else if (ResetCount >= SystemConst::Q6_MAX_MISSION_SHUFFLE_GOLD_START_COUNT)
	{
		return  static_cast<int64>(SystemConst::Q6_MAX_MISSION_SHUFFLE_GOLD);
	}

	const FCMSMissionSuffleCostRow& MissionSuffleCostRow = GetCMS()->GetMissionSuffleCostRowOrDummy(
		FMissionSuffleCostType(ResetCount));
	if (MissionSuffleCostRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist mission shuffle cost type", Q6KV("type", ResetCount));
		return static_cast<int64>(SystemConst::Q6_MAX_MISSION_SHUFFLE_GOLD);
	}

	return static_cast<int64>(MissionSuffleCostRow.Gold);
}

bool UWeeklyMissionWidget::CheckMissionBonus(const int32 MissionBonusIndex)
{
	const FMissionInfo& MissionInfo = GetHUDStore().GetWeeklyMissionManager().GetMissioninfo();
	check(MissionInfo.BUtc.IsValidIndex(MissionBonusIndex));
	if (MissionInfo.BUtc[MissionBonusIndex] > 0)
	{
		return false;
	}

	if (MissionBonusIndex < MAX_MISSION_BINGO_BOARD_SIZE)
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = MissionBonusIndex;
			const int32 Col = BingoCheckIndex;

			check(BingoBoard.IsValidIndex(Row));
			check(BingoBoard[Row].IsValidIndex(Col));

			if (BingoBoard[Row][Col] != EMissionBingoBoardState::Complete)
			{
				return false;
			}
		}
	}
	else if (MissionBonusIndex == MAX_MISSION_BINGO_BOARD_SIZE)
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = BingoCheckIndex;
			const int32 Col = BingoCheckIndex;

			check(BingoBoard.IsValidIndex(Row));
			check(BingoBoard[Row].IsValidIndex(Col));

			if (BingoBoard[Row][Col] != EMissionBingoBoardState::Complete)
			{
				return false;
			}
		}
	}
	else if(MissionBonusIndex < MAX_WEEKLY_BINGO - 1)
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = BingoCheckIndex;
			const int32 Col = MAX_WEEKLY_BINGO - MissionBonusIndex - 2;

			check(BingoBoard.IsValidIndex(Row));
			check(BingoBoard[Row].IsValidIndex(Col));

			if (BingoBoard[Row][Col] != EMissionBingoBoardState::Complete)
			{
				return false;
			}
		}
	}
	else
	{
		for (int32 BingoCheckIndex = 0; BingoCheckIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++BingoCheckIndex)
		{
			const int32 Row = BingoCheckIndex;
			const int32 Col = MAX_MISSION_BINGO_BOARD_SIZE - BingoCheckIndex - 1;

			check(BingoBoard.IsValidIndex(Row));
			check(BingoBoard[Row].IsValidIndex(Col));

			if (BingoBoard[Row][Col] != EMissionBingoBoardState::Complete)
			{
				return false;
			}
		}
	}

	return true;
}

bool UWeeklyMissionWidget::CheckShuffle()
{
	const UHUDStore& HUDStore = GetHUDStore();
	const FMissionInfo& MissionInfo = HUDStore.GetWeeklyMissionManager().GetMissioninfo();
	for (const int32 RewardUTC : MissionInfo.RUtc)
	{
		if (RewardUTC > 0)
		{
			GetLobbyHUD(this)->ShowNotification(ENotificationType::Short
				, Q6Util::GetLocalizedText("Lobby", "NoSuffleAlreadyReceived"));


			return false;
		}
	}

	const UWorldUser& WorldUser = HUDStore.GetWorldUser();
	if (WorldUser.GetGold() < GetShuffleRequireGold(MissionInfo.ResetCount))
	{
		GetLobbyHUD(this)->ShowNotification(ENotificationType::Short
			, Q6Util::GetLocalizedText("Lobby", "NotEnoughGold"));

		return false;
	}

	return true;
}

void UWeeklyMissionWidget::CheckBingoAndBingoStartAnimationPlay(const int32 MissionButtonIndex)
{
	TArray<int32> ChangeBingoStartAnims;

	const int32 Row = MissionButtonIndex / MAX_MISSION_BINGO_BOARD_SIZE;
	const int32 Col = MissionButtonIndex % MAX_MISSION_BINGO_BOARD_SIZE;

	TArray<int32> BingoIndies;
	BingoIndies.Reserve(MAX_MISSION_BINGO_BOARD_SIZE);

	for (int32 ColIndex = 0; ColIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++ColIndex)
	{
		check(BingoBoard.IsValidIndex(Row));
		check(BingoBoard[Row].IsValidIndex(ColIndex));

		if (BingoBoard[Row][ColIndex] != EMissionBingoBoardState::Complete)
		{
			BingoIndies.Reset();
			break;
		}

		BingoIndies.Add(Row * MAX_MISSION_BINGO_BOARD_SIZE + ColIndex);
	}

	ChangeBingoStartAnims.Append(BingoIndies);

	for (int32 RowIndex = 0; RowIndex < MAX_MISSION_BINGO_BOARD_SIZE; ++RowIndex)
	{
		check(BingoBoard.IsValidIndex(RowIndex));
		check(BingoBoard[RowIndex].IsValidIndex(Col));

		if (BingoBoard[RowIndex][Col] != EMissionBingoBoardState::Complete)
		{
			BingoIndies.Reset();
			break;
		}

		BingoIndies.Add(RowIndex * MAX_MISSION_BINGO_BOARD_SIZE + Col);
	}

	ChangeBingoStartAnims.Append(BingoIndies);

	if (Row == Col)
	{
		for (int32 Index = 0; Index < MAX_MISSION_BINGO_BOARD_SIZE; ++Index)
		{
			check(BingoBoard.IsValidIndex(Index));
			check(BingoBoard[Index].IsValidIndex(Index));

			if (BingoBoard[Index][Index] != EMissionBingoBoardState::Complete)
			{
				BingoIndies.Reset();
				break;
			}

			BingoIndies.Add(Index * MAX_MISSION_BINGO_BOARD_SIZE + Index);
		}

		ChangeBingoStartAnims.Append(BingoIndies);
	}

	if (Row + Col == MAX_MISSION_BINGO_BOARD_SIZE - 1)
	{
		for (int32 Index = 0; Index < MAX_MISSION_BINGO_BOARD_SIZE; ++Index)
		{
			check(BingoBoard.IsValidIndex(Index));
			check(BingoBoard[Index].IsValidIndex(MAX_MISSION_BINGO_BOARD_SIZE - Index - 1));

			if (BingoBoard[Index][MAX_MISSION_BINGO_BOARD_SIZE - Index - 1] != EMissionBingoBoardState::Complete)
			{
				BingoIndies.Reset();
				break;
			}

			BingoIndies.Add(Index * MAX_MISSION_BINGO_BOARD_SIZE + (MAX_MISSION_BINGO_BOARD_SIZE - Index - 1));
		}

		ChangeBingoStartAnims.Append(BingoIndies);
	}

	for (const int32 ChangeBingoStartAnimIndex : ChangeBingoStartAnims)
	{
		if (!MissionButtonWidgets.IsValidIndex(ChangeBingoStartAnimIndex))
		{
			continue;
		}

		MissionButtonWidgets[ChangeBingoStartAnimIndex]->PlayMissionButtonAnim(EMissionButtonAnimType::BingoStart);
	}
}

void UWeeklyMissionWidget::OnMissionBonusButtonClicked(int32 Index)
{
	if (!CheckMissionBonus(Index))
	{
		return;
	}

	RequestBingoItemIndex = Index;

	GetHUDStore().GetWeeklyMissionManager().ReqBingo(Index);
}

void UWeeklyMissionWidget::OnMissionToggleBtnClicked(int32 Index)
{
	if (SelectedMissionButtonIndex == Index
		&& MissionButtonWidgets.IsValidIndex(Index))
	{
		ECheckBoxState CheckBoxState = MissionButtonWidgets[Index]->GetCheckedState();
		if (CheckBoxState == ECheckBoxState::Checked)
		{
			SetMissionDesc(Index);
		}
		else if(CheckBoxState == ECheckBoxState::Unchecked)
		{
			PlayWeeklyMissionAnim(EWeeklyMissionAnimType::Start);
			PlayWeeklyMissionAnim(EWeeklyMissionAnimType::StateNone);

			return;
		}
	}

	if (SelectedMissionButtonIndex != Index
		&& MissionButtonWidgets.IsValidIndex(SelectedMissionButtonIndex))
	{
		MissionButtonWidgets[SelectedMissionButtonIndex]->SetCheckedState(ECheckBoxState::Unchecked);
	}

	SelectedMissionButtonIndex = Index;
	SetMissionDesc(Index);

	if (!CheckMission(Index))
	{
		return;
	}

	RequestMissionItemIndex = Index;

	GetHUDStore().GetWeeklyMissionManager().ReqReward(Index);
}

void UWeeklyMissionWidget::OnShuffleButtonClicked()
{
	if (!CheckShuffle())
	{
		return;
	}

	ShuffleButton->SetIsEnabled(false);
	ShuffleButtonImage->SetIsEnabled(false);
	PlayShuffleAnimation();

	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::Start);
	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::StateShuffle);

	GetHUDStore().GetWeeklyMissionManager().ReqShuffle();
}

void UWeeklyMissionWidget::OnMissionShuffleAnimFinished()
{
	ShuffleButton->SetIsEnabled(true);
	ShuffleButtonImage->SetIsEnabled(true);

	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::Start);
	PlayWeeklyMissionAnim(EWeeklyMissionAnimType::StateNone);
}

void UWeeklyMissionWidget::OnMissionCompleteStartAnimFinished(int32 MissionButtonIndex)
{
	CheckBingoAndBingoStartAnimationPlay(MissionButtonIndex);
}

bool UWeeklyMissionWidget::CheckMission(const int32 Index)
{
	const UWeeklyMissionManager& WeeklyMissionManager = GetHUDStore().GetWeeklyMissionManager();
	const FMissionInfo& MissionInfo = WeeklyMissionManager.GetMissioninfo();

	check(MissionInfo.RUtc.IsValidIndex(Index));
	if (MissionInfo.RUtc[Index] > 0)
	{
		return false;
	}

	check(MissionInfo.M.IsValidIndex(Index));
	const FMissionType& Type = MissionInfo.M[Index];
	const FCMSMissionRow& MissionRow = GetCMS()->GetMissionRowOrDummy(Type);
	if (MissionRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist mission type", Q6KV("type", Type));
		return false;
	}

	const int32 MaxValue = WeeklyMissionManager.GetMaxValue(Type);
	check(MissionInfo.MIng.IsValidIndex(Index));
	if (MissionInfo.MIng[Index] < MaxValue)
	{
		return false;
	}

	return true;
}

UMissionButtonWidget::UMissionButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ReservedAnimAfterShuffle(EMissionButtonAnimType::Max)
{

}

void UMissionButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MissionButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBtnNormal"));
	MissionButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBtnActivate"));
	MissionButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBtnCompleteStart"));
	MissionButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBtnBingoStart"));
	MissionButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBtnShuffle"));
	MissionButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBtnComplete"));
	MissionButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimBtnBingo"));
	check(MissionButtonAnims.Num() == static_cast<int32>(EMissionButtonAnimType::Max));

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));

	MissionTitleText = CastChecked<UTextBlock>(GetWidgetFromName("MissionTitle"));

	MissionProgressBar = CastChecked<UProgressBar>(GetWidgetFromName("MissionProgress"));

	DescCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("CheckBtn"));
	DescCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UMissionButtonWidget::OnDescToggleClicked);
}

void UMissionButtonWidget::SetInfo(const FMissionType& InType, const FText& InText
	, const int32 Curr, const int32 Max, const int32 RewardUTC, bool bEnterMenu, bool bIsRequestMissionItemIndex)
{
	SetMissionTitleText(InType, InText);
	SetMissionProgressBar(Curr, Max);
	SetItem(InType);

	if (RewardUTC > 0)
	{
		ItemWidget->SetChecked(true);
		if (bIsRequestMissionItemIndex)
		{
			PlayMissionButtonAnim(EMissionButtonAnimType::CompleteStart);
		}
		else
		{
			PlayMissionButtonAnim(EMissionButtonAnimType::Complete);
		}
	}
	else if (Curr < Max)
	{
		ItemWidget->SetChecked(false);

		if (bEnterMenu)
		{
			PlayMissionButtonAnim(EMissionButtonAnimType::Normal);
		}
		else
		{
			ReservedAnimAfterShuffle = EMissionButtonAnimType::Normal;
		}
	}
	else
	{
		ItemWidget->SetChecked(false);

		if (bEnterMenu)
		{
			PlayMissionButtonAnim(EMissionButtonAnimType::Activate);
		}
		else
		{
			ReservedAnimAfterShuffle = EMissionButtonAnimType::Activate;
		}
	}
}

bool UMissionButtonWidget::SetBingo(const int32 Row, const int32 Col
	, const FMissionInfo& MissionInfo)
{
	bool bBingo = false;
	if (MissionInfo.BUtc.IsValidIndex(Row)
		&& MissionInfo.BUtc[Row] > 0)
	{
		bBingo = true;
	}
	else if (MissionInfo.BUtc.IsValidIndex(MAX_WEEKLY_BINGO - Col - 2)
		&& MissionInfo.BUtc[MAX_WEEKLY_BINGO - Col - 2] > 0)
	{
		bBingo = true;
	}
	else if (Row == Col
		&& MissionInfo.BUtc.IsValidIndex(MAX_MISSION_BINGO_BOARD_SIZE)
		&& MissionInfo.BUtc[MAX_MISSION_BINGO_BOARD_SIZE] > 0)
	{
		bBingo = true;
	}
	else if (MAX_MISSION_BINGO_BOARD_SIZE - Row - 1 == Col
		&& MissionInfo.BUtc.IsValidIndex(MAX_WEEKLY_BINGO - 1)
		&& MissionInfo.BUtc[MAX_WEEKLY_BINGO - 1] > 0)
	{
		bBingo = true;
	}

	if (bBingo)
	{
		PlayMissionButtonAnim(EMissionButtonAnimType::Bingo);
	}
	
	return bBingo;
}

void UMissionButtonWidget::PlayShuffleAnimation()
{
	ItemWidget->SetChecked(false);
	PlayMissionButtonAnim(EMissionButtonAnimType::Normal);
	PlayMissionButtonAnim(EMissionButtonAnimType::Shuffle);
}

void UMissionButtonWidget::SetCheckedState(ECheckBoxState InState)
{
	DescCheckBox->SetCheckedState(InState);
}

void UMissionButtonWidget::PlayMissionButtonAnim(EMissionButtonAnimType Type)
{
	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (MissionButtonAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(MissionButtonAnims[AnimIndex]);
	}
}

void UMissionButtonWidget::SetMissionTitleText(const FMissionType& InType, const FText& InText)
{
	int32 MaxValue = GetHUDStore().GetWeeklyMissionManager().GetMaxValue(InType);
	if (MaxValue == INDEX_NONE)
	{
		return;
	}

	FString EntireStr(InText.ToString());
	FString NumberStr(FString::FromInt(MaxValue));

	int32 RemoveStartIndex = EntireStr.Find(NumberStr);
	if (RemoveStartIndex == INDEX_NONE)
	{
		return;
	}

	int32 RemoveEndIndex = FMath::Clamp(RemoveStartIndex + NumberStr.Len() + 1, 0, EntireStr.Len() - 1);
	if (RemoveEndIndex == EntireStr.Len() - 1)
	{
		RemoveStartIndex = FMath::Clamp(RemoveStartIndex - 1, 0, EntireStr.Len() - 1);
	}

	EntireStr.RemoveAt(RemoveStartIndex, RemoveEndIndex - RemoveStartIndex + 1);
	MissionTitleText->SetText(FText::FromString(EntireStr));
}

void UMissionButtonWidget::SetMissionProgressBar(const int32 curr, const int32 Max)
{
	const float Percent = FMath::Clamp(static_cast<float>(curr) / Max, 0.0f, 1.0f);
	MissionProgressBar->SetPercent(Percent);
}

void UMissionButtonWidget::SetItem(const FMissionType& InType)
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSMissionRow& MissionRow = CMS->GetMissionRowOrDummy(InType);
	const FCMSLootGroupRow& LootGroupRow = MissionRow.GetLootGroup();
	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(LootGroupRow);

	ItemWidget->SetRewardType(ERewardType::None);
	ItemWidget->SetLoot(LootDataRow.LootId, LootDataRow.Count);
}

void UMissionButtonWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	const uint8 ShuffleAnimIndex = static_cast<uint8>(EMissionButtonAnimType::Shuffle);
	if (MissionButtonAnims.IsValidIndex(ShuffleAnimIndex)
		&& Animation == MissionButtonAnims[ShuffleAnimIndex])
	{
		OnMissionShuffleAnimFinished.ExecuteIfBound();
		if (ReservedAnimAfterShuffle != EMissionButtonAnimType::Max)
		{
			PlayMissionButtonAnim(ReservedAnimAfterShuffle);
		}
	}

	const uint8 CompleteStartAnimIndex = static_cast<uint8>(EMissionButtonAnimType::CompleteStart);
	if (MissionButtonAnims.IsValidIndex(CompleteStartAnimIndex)
		&& Animation == MissionButtonAnims[CompleteStartAnimIndex])
	{
		OnMissionCompleteStartAnimFinished.ExecuteIfBound();
	}
}

void UMissionButtonWidget::OnDescToggleClicked(bool bInChecked)
{
	OnMissionToggleClickedDelegate.ExecuteIfBound();
}

UMissionBonusButtonWidget::UMissionBonusButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UMissionBonusButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MissionBonusButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimSideNormal"));
	MissionBonusButtonAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimSideActivate"));
	check(MissionBonusButtonAnims.Num() == static_cast<int32>(EMissionBonusButtonAnimType::Max));

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
	ItemWidget->OnItemClicked.BindUObject(this, &UMissionBonusButtonWidget::OnMissionBonusButtonClicked);
}

void UMissionBonusButtonWidget::SetInfo(const int32 InIndex, const int32 WeekNum
	, bool bEnable, const int32 BingoUTC)
{
	SetItem(WeekNum, InIndex);

	if (bEnable)
	{
		ItemWidget->SetChecked(false);
		PlayMissionBonusButtonAnim(EMissionBonusButtonAnimType::Activate);
	}
	else
	{
		ItemWidget->SetChecked(BingoUTC > 0);
		PlayMissionBonusButtonAnim(EMissionBonusButtonAnimType::Normal);
	}
}

void UMissionBonusButtonWidget::SetItem(const int32 InWeekNum, const int32 InIndex)
{
	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSMissionSetRow* MissionSetRow = CMS->GetMissionSetRowByWeekNum(InWeekNum);
	if (!MissionSetRow)
	{
		return;
	}

	const TArray<const FCMSLootGroupRow*>& LootGroupRows = MissionSetRow->GetLootGroup();
	if (!LootGroupRows.IsValidIndex(InIndex))
	{
		Q6JsonLogGenie(Error, "no exist missionSet LootGroupRow", Q6KV("weekNum", InWeekNum));
		return;
	}

	const FCMSLootDataRow& LootDataRow = CMS->GetFirstLootDataOrDummyFromLootGroups(
		*LootGroupRows[InIndex]);

	ItemWidget->SetRewardType(ERewardType::None);
	ItemWidget->SetLoot(LootDataRow.LootId, LootDataRow.Count);
}

void UMissionBonusButtonWidget::OnMissionBonusButtonClicked()
{
	OnMissionBonusButtonClickedDelegate.ExecuteIfBound();
}

void UMissionBonusButtonWidget::PlayMissionBonusButtonAnim(EMissionBonusButtonAnimType Type)
{
	const uint8 AnimIndex = static_cast<uint8>(Type);
	if (MissionBonusButtonAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(MissionBonusButtonAnims[AnimIndex]);
	}
}
