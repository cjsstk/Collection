// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "DialogueSkipWidget.h"

#include "Q6.h"
#include "Q6Log.h"
#include "PopupWidgets.h"
#include "WidgetUtil.h"

UDialogueSkipWidget::UDialogueSkipWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UDialogueSkipWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SkipStartAnim = GetWidgetAnimationFromName(this, "AnimSkipStart");
	SkipEndAnim = GetWidgetAnimationFromName(this, "AnimSkipEnd");

	SkipButton = CastChecked<UButton>(GetWidgetFromName("ButtonSkip"));
	SkipButton->OnClicked.AddUniqueDynamic(this, &UDialogueSkipWidget::OnSkipClicked);

	BottomSkipButton = CastChecked<UButton>(GetWidgetFromName("BottomSkip"));
	BottomSkipButton->OnClicked.AddUniqueDynamic(this, &UDialogueSkipWidget::OnBottomSkipClicked);
}

void UDialogueSkipWidget::ShowSkip(bool bShow)
{
	if (bShow)
	{
		PlayAnimation(SkipStartAnim);
	}
	else
	{
		PlayAnimation(SkipEndAnim);
	}
}

void UDialogueSkipWidget::ShowBottomSkip(bool bShow)
{
	if (bShow)
	{
		SkipButton->SetVisibility(ESlateVisibility::Collapsed);
		BottomSkipButton->SetVisibility(ESlateVisibility::Visible);
	}
	else
	{
		SkipButton->SetVisibility(ESlateVisibility::Visible);
		BottomSkipButton->SetVisibility(ESlateVisibility::Collapsed);
	}
}

void UDialogueSkipWidget::OnSkipClicked()
{
	SkipDelegate.ExecuteIfBound();
}

void UDialogueSkipWidget::OnBottomSkipClicked()
{
	BottomSkipDelegate.ExecuteIfBound();
}
