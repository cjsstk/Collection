// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "BaseWidget.h"
#include "CombatPresenter.h"
#include "CombatTextWidget.generated.h"

class AUnit;
struct FCCUnitId;
enum class ENatureRelationType : uint8;
enum class EHealthChangeReason : uint8;

UCLASS()
class Q6_API UCombatDamageTextWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	bool InitCombatText(FCCUnitId TargetUnitId, ENatureRelationType NatureRelationType, int32 BaseValue, int32 ExtraValue, EHealthChangeReason Reason, bool bDodged, bool bCritical, bool bShield, bool bMultiple, bool bAddRandomOffset);

	void StartCombatTextAnimation();

	FSimpleDelegate CombatTextAnimationFinished;

private:
	void SetHealTextAnim(int32 InHeal);
	void SetDamageTextAnim(int32 InBaseDamage, int32 InExtraDamage, bool bInDodged, bool bInCritical);
	void SetNatureRelationAnim(ENatureRelationType NatureRelationType, bool bInDodged, bool bInShield);
	void SetHealBlockAnim();

	// Widgets

	UPROPERTY()
	UTextBlock* DamageText;

	UPROPERTY()
	UTextBlock* DodgeText;

	UPROPERTY()
	UTextBlock* HealText;

	UPROPERTY()
	UHorizontalBox* ExtraDamageBox;

	UPROPERTY()
	UTextBlock* ExtraDamageText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* NormalTextAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CriticalTextAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DodgeTextAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HealTextAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NatureRelationStrongAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NatureRelationWeakAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShieldAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* HealBlockAnim;

	// Fields

	UPROPERTY(Transient)
	UWidgetAnimation* CurrentTextAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CurrentNatureAnim;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Position Offset")
	FVector DefaultOffset;

	UPROPERTY(EditDefaultsOnly, Category = "Spawn Position Offset")
	FVector MultipleDamageAdditionalOffset;

	UPROPERTY(EditDefaultsOnly, Category = "Screen Offset")
	FVector2D ReservedSize;

	UPROPERTY(EditDefaultsOnly, Category = "Screen Offset")
	FVector2D RandomOffsetMin;

	UPROPERTY(EditDefaultsOnly, Category = "Screen Offset")
	FVector2D RandomOffsetMax;
};
