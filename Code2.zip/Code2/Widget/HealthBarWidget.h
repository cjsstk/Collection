#pragma once

#include "UMG.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "Unit.h"
#include "HealthBarWidget.generated.h"

DECLARE_DELEGATE_OneParam(FGaugeChangeDelegate, int32);

class UQ6TextBlock;
struct FUnitState;

UCLASS()
class Q6_API UHealthBarWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UHealthBarWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void InitHealthBar(const FUnitState& InUnitState);
	void InitRaidTotalHealthBar(const EAttributeCategory InCategory
		, const int32 InUnitType, const int32 InTotalHealth);

	void SetHealthState(int32 InNewHealth, EHealthChangeReason Reason, int32 InHitIndex, int32 InHitMax, bool bAlly);
	void SetRaidTotalHealth(int32 InNewHealth, EHealthBarAction InBarAction);

	void SetOtherUserCharacterHealthBar(const int32 InHealth, const int32 InMaxHealth);

	void SetShield(int32 InNewShield);

protected:
	UFUNCTION(BlueprintImplementableEvent, Category = "HealthBar")
	void OnHealthBarState(float InStartPercent, float InCurPercent, EHealthBarAction HealthBarAction);

	UFUNCTION(BlueprintImplementableEvent, Category = "HealthBar")
	void OnHealthBarGaugeChange(int32 InGaugeIndex, int32 InGaugeCount, bool bAlly);

	UPROPERTY(EditDefaultsOnly, Category = "HealthBar")
	float AnimationTime;

private:
	void InitHealthBar(int32 InHealth, int32 InMaxHealth, int32 InUnitType, ECCFaction InFaction, bool bBoss);

	float GetCurrentHealthRatio(int32 InNewHealth) const;

	// BindWidget From BP
	UPROPERTY()
	UProgressBar* ImmediateProgress;

	UPROPERTY()
	UProgressBar* UpdateProgress;

	UPROPERTY()
	UQ6TextBlock* GaugeCountText;

	UPROPERTY()
	UTextBlock* HPText;

	UPROPERTY()
	UTextBlock* ShieldText;

	float StartPercent;
	float CurPercent;
	int32 GaugeDivisor;
	int32 MaxGaugeCount;
};

UCLASS()
class Q6_API UShieldBarWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UShieldBarWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void InitShieldBar(UHealthBarWidget* InHealthBarWidget, int32 InShield, int32 InMaxShield, bool bAnimate);
	void SetShieldState(UHealthBarWidget* InHealthBarWidget, bool bActivate, bool bAnimate);
	void SetShieldDamage(UHealthBarWidget* InHealthBarWidget, int32 InDamage, int32 InExtraDamage, bool bInWeakPoint);

private:
	UPROPERTY(Transient)
	UWidgetAnimation* ShieldDamageAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShieldWeakPointDamageAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShieldOnAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ShieldOffAnim;

	UPROPERTY()
	UProgressBar* ProgressBar;

	UPROPERTY()
	USlider* CutSlider;

	int32 Shield;
	int32 MaxShield;
};
