// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6UiDefine.h"
#include "UMG.h"
#include "DialogueLogEntryWidget.generated.h"

class UTextBlock;
class URichTextBlock;

UCLASS()
class Q6_API UDialogueLogEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UDialogueLogEntryWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetTalkLog(EDialogueType InDialogueType, const FText& InName, const FText& InText, const FName& InVoiceName);
	void SetChoiceLog(const FText& InText);

	void SetChatStyle(int32 ChatModel, bool bLeft, bool bContinue);

	void SetChatTalk(const FText& InName, const FText& InText);
	void SetChatSystem(const FText& InText);

	void SetChatTitleLog(const FText& InAreaName);
	void SetChatLog(EDialogueType InDialogueType, const FText& InName, const FText& InText, const FName& InVoiceName);
	void SetChatSystemLog(const FText& InText);
	void SetChatEndLog();

private:
	enum class ELogType : uint8
	{
		Normal,
		Monologue,
		UserAnswer,
		ChatLogTitle,
		ChatSpeak,
		ChatMonologue,
		ChatLogEnd,
	};

	void SwitchWidgets(ELogType InLogType);

	UFUNCTION()
	void OnVoiceButtonClicked();

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush ChatOpenBubble;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush ChatContinueBubble;

	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle ChatLeftStyle;

	UPROPERTY(EditDefaultsOnly)
	FTextBlockStyle ChatRightStyle;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<UTexture2D> DummySpeakerIcon;

	// Widget Animations

	UPROPERTY(Transient)
	UWidgetAnimation* Talker1OpenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* Talker1ContinueAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* Talker2OpenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* Talker2ContinueAnim;

	// Widgets

	UPROPERTY()
	UTextBlock* SpeakerName;

	UPROPERTY()
	URichTextBlock* NormalLog;

	UPROPERTY()
	URichTextBlock* MonologueLog;

	UPROPERTY()
	UTextBlock* UserAnswerLog;

	UPROPERTY()
	UTextBlock* ChatStageName;

	UPROPERTY()
	UTextBlock* ChatSpeakerName;

	UPROPERTY()
	UImage* ChatSpeakerImage;

	UPROPERTY()
	UBorder* ChatSpeakBubble;

	UPROPERTY()
	UImage* ChatSpeakLogBg;

	UPROPERTY()
	URichTextBlock* ChatSpeakText;

	UPROPERTY()
	URichTextBlock* ChatMonologueText;

	UPROPERTY()
	UImage* ChatMonologueLogBg;

	UPROPERTY()
	UWidgetSwitcher* DialogueSwitcher;

	UPROPERTY()
	UButton* VoiceButton;

	UPROPERTY()
	UButton* VoiceMonologueButton;

	UPROPERTY()
	UButton* ChatVoiceButton;

	EDialogueType DialogueType;
	FName VoiceName;
};
