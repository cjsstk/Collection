// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "PetWidgets.h"

#include "BagItemManager.h"
#include "CharacterWidgets.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "NewMarkManager.h"
#include "PetManager.h"
#include "PointWidgets.h"
#include "Q6Account.h"
#include "SwipeWidgets.h"
#include "UpgradeWidgets.h"
#include "LevelUtil.h"
#include "Q6Capture2D.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent PartyPetSelectPopup"), STAT_OnHSEventByPetPark, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Pet Icon Widget
//////////////////////////////////////////////////////////////////////////
void UPetIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
}

void UPetIconWidget::SetPet(FPetType PetType)
{
	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetType);
	//GetGameResource().AsyncLoadImageTexture(IconImage, PetAssetRow.IllustTexture);
	static const FName Tag(TEXT("Capture.Pet"));
	if (AQ6Capture2D* CaptureActor = ULevelUtil::FindCaptureActor(GetWorld(), Tag))
	{
		ULevelUtil::BindMeshModel(GetWorld(), CaptureActor, PetAssetRow.ModelType);
		CaptureActor->GetMesh()->SetRelativeTransform(PetAssetRow.MeshTransform);
		if (CaptureActor->GetMID())
		{
			IconImage->SetBrushFromMaterial(CaptureActor->GetMID());
		}
		else
		{
			IconImage->SetBrushResourceObject(CaptureActor->GetRenderTarget());
		}
	}
}


//////////////////////////////////////////////////////////////////////////
// Pet Skill Upgrade Result Widget
//////////////////////////////////////////////////////////////////////////
void UPetSkillUpgradeResultPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PetNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("PetName"));
	SkillNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("SkillName"));
	SkillIcon = CastChecked<UTurnSkillIconWidget>(GetWidgetFromName("SkillIcon"));
	CurrentSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("CurrentSkill"));
	ResultSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("ResultSkill"));
	PetIconWidget = CastChecked<UPetIconWidget>(GetWidgetFromName("PetIcon"));

	UpgradeAnim = GetWidgetAnimationFromName(this, "AnimUpgrade");
}

void UPetSkillUpgradeResultPopupWidget::SetPetSkill(FPetId PetId, int32 SkillIndex)
{
	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().Find(PetId);
	if (!PetInfo)
	{
		Q6JsonLogRoze(Error, "UPetSkillUpgradeResultPopupWidget::SetPetSkill - Invalid pet id", Q6KV("Id", PetId.S));
		return;
	}

	// Set skills

	TArray<int32> SkillLevels;
	SkillLevels.Add(PetInfo->Skill1Level);
	SkillLevels.Add(PetInfo->Skill2Level);
	SkillLevels.Add(PetInfo->Skill3Level);
	check(SkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const FCMSPetRow& PetRow = GetCMS()->GetPetRowOrDummy(PetInfo->Type);
	PetNameText->SetText(PetRow.Name);

	int32 SkillLevel = SkillLevels[SkillIndex];
	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetInfo->Type);
	PetIconWidget->SetPet(PetInfo->Type);

	if (PetAssetRow.SkillIcons.IsValidIndex(SkillIndex))
	{
		SkillIcon->SetSkill(PetAssetRow.SkillIcons[SkillIndex], SkillLevel);
		SkillIcon->SetLocked(false);
	}

	const TArray<const FCMSSkillRow*> SkillRows = GetCMS()->GetPetRowOrDummy(PetInfo->Type).GetSkills();
	check(SkillRows.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const FCMSSkillRow* SkillRow = SkillRows[SkillIndex];
	check(SkillRow);

	SkillNameText->SetText(SkillRow->DescName);

	int32 PrevLevel = SkillLevel - 1;
	int32 PrevCooldown = GetCMS()->GetCooltimeByLevel(SkillRow->Type, PrevLevel);
	CurrentSkillWidget->SetSkill(PrevLevel, BuildToolTipDesc(SkillRow->Type, PrevLevel, SkillRow->SkillCategory), PrevCooldown);
	CurrentSkillWidget->SetInfoColor(false, false);

	int32 ResultCooldown = GetCMS()->GetCooltimeByLevel(SkillRow->Type, SkillLevel);
	ResultSkillWidget->SetSkill(SkillLevel, BuildToolTipDesc(SkillRow->Type, SkillLevel, SkillRow->SkillCategory), ResultCooldown);
	ResultSkillWidget->SetInfoColor(true, (ResultCooldown < PrevCooldown));

	PlayAnimation(UpgradeAnim);
}


//////////////////////////////////////////////////////////////////////////
// Pet Park Widget
//////////////////////////////////////////////////////////////////////////
void UPetParkWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Widgets

	PetNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("PetName"));
	PetSwipeWidget = CastChecked<UPageSwipeWidget>(GetWidgetFromName("PetSwipe"));
	SkillNameText = CastChecked<UQ6TextBlock>(GetWidgetFromName("SkillName"));

	SkillIcons.Reset();
	for (int32 n = 1; n <= CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT; ++n)
	{
		FString WidgetName = FString::Printf(TEXT("SkillIcon%d"), n);
		UTurnSkillIconWidget* SkillIcon = CastChecked<UTurnSkillIconWidget>(GetWidgetFromName(*WidgetName));
		SkillIcons.Add(SkillIcon);
		SkillIcon->OnSelectButtonClickedDelegate.BindUObject(this, &UPetParkWidget::OnSelectedSkill, n - 1);
	}

	CurrentSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("CurrentSkill"));
	ResultSkillWidget = CastChecked<USkillUpInfoWidget>(GetWidgetFromName("ResultSkill"));

	InfoText = CastChecked<UQ6RichTextBlock>(GetWidgetFromName("Info"));
	MaterialsWidget = CastChecked<UMaterialBoxWidget>(GetWidgetFromName("Materials"));

	RequireGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequireGold"));
	RequireGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);

	OwnedGoldWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedGold"));
	OwnedGoldWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	UpgradeButton = CastChecked<UButton>(GetWidgetFromName("Upgrade"));
	UpgradeButton->OnClicked.AddUniqueDynamic(this, &UPetParkWidget::OnUpgradeButtonClicked);

	// Animations

	IntroAnim = GetWidgetAnimationFromName(this, "AnimIntro");

	DetailAnims.Reset();
	DetailAnims.Add(GetWidgetAnimationFromName(this, "AnimDefault"));
	DetailAnims.Add(GetWidgetAnimationFromName(this, "AnimNotAcquire"));
	DetailAnims.Add(GetWidgetAnimationFromName(this, "AnimLowLevel"));
	DetailAnims.Add(GetWidgetAnimationFromName(this, "AnimMaxLevel"));
}

void UPetParkWidget::OnMenuEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByPetPark);

	if (InAction->GetActionType() == EHSActionType::DevPetNewResp)
	{
		SetWonder();
		return;
	}

	if (InAction->GetActionType() == EHSActionType::PetSkillUpgradeResp
		|| InAction->GetActionType() == EHSActionType::DevPetSkillUpgradeResp)
	{
		RefreshUI();

		UPetSkillUpgradeResultPopupWidget* ResultPopup = CastChecked<UPetSkillUpgradeResultPopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(ResultPopupWidgetClass));
		ResultPopup->SetPetSkill(PetId, SelectedSkillIdx);
		return;
	}
}

void UPetParkWidget::SetWonder()
{
	int32 PetCount = GetHUDStore().GetPetManager().GetPetNum();

	if (PetCount <= 0)
	{
		Q6JsonLogRoze(Error, "UPetParkWidget::SetWonder - No have any pet");
		return;
	}

	PetSwipeWidget->SetPageCount(PetCount, 1);
	PetSwipeWidget->OnFocusedPageDelegate.BindUObject(this, &UPetParkWidget::OnPetPageChanged);

	OnPetPageChanged(1);
	OnSelectedSkill(0);	// Default skill select

	PlayAnimation(IntroAnim);
}

void UPetParkWidget::RefreshUI()
{
	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().Find(PetId);
	if (!PetInfo)
	{
		Q6JsonLogRoze(Error, "UPetParkWidget::RefreshUI - Not found pet", Q6KV("PetId", PetId));
		return;
	}

	SetSkillIcons(*PetInfo, SelectedSkillIdx);

	TArray<int32> SkillLevels;
	SkillLevels.Add(PetInfo->Skill1Level);
	SkillLevels.Add(PetInfo->Skill2Level);
	SkillLevels.Add(PetInfo->Skill3Level);
	check(SkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const TArray<const FCMSSkillRow*>& SkillRows = GetCMS()->GetPetRowOrDummy(PetInfo->Type).GetSkills();
	check(SkillRows.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
	SetSkillDetail(*SkillRows[SelectedSkillIdx], SkillLevels[SelectedSkillIdx]);
}

void UPetParkWidget::SetSkillIcons(const FPetInfo& PetInfo, int32 SelectedIndex)
{
	// Set skills
	TArray<int32> SkillLevels;
	SkillLevels.Add(PetInfo.Skill1Level);
	SkillLevels.Add(PetInfo.Skill2Level);
	SkillLevels.Add(PetInfo.Skill3Level);
	check(SkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	TArray<ESlateVisibility> NewMarkVisibilities = GetHUDStore().GetNewMarkManager().GetWonderPetSkillUpgradeVisibility(PetInfo);
	check(NewMarkVisibilities.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(PetInfo.Type);
	for (int32 i = 0; i < SkillIcons.Num(); ++i)
	{
		if (PetAssetRow.SkillIcons.IsValidIndex(i))
		{
			SkillIcons[i]->SetSkill(PetAssetRow.SkillIcons[i], SkillLevels[i]);
			SkillIcons[i]->SetLocked(SkillLevels[i] <= 0);
			SkillIcons[i]->SetNewMarkVisibility(NewMarkVisibilities[i]);
		}
	}

	OnSelectedSkill(SelectedIndex);
}

void UPetParkWidget::SetSkillState(EPetSkillState SkillState)
{
	if (DetailAnims.IsValidIndex((int32)SkillState))
	{
		PlayAnimation(DetailAnims[(int32)SkillState]);
	}
}

void UPetParkWidget::SetSkillInfo(const FCMSSkillRow& SkillRow, int32 SkillLevel, bool bUpgrade)
{
	SkillLevel = FMath::Max(SkillLevel, 1);
	int32 CurrentCooldown = GetCMS()->GetCooltimeByLevel(SkillRow.Type, SkillLevel);
	CurrentSkillWidget->SetSkill(SkillLevel, BuildToolTipDesc(SkillRow.Type, SkillLevel, SkillRow.SkillCategory), CurrentCooldown);
	CurrentSkillWidget->SetInfoColor(false, false);

	if (bUpgrade)
	{
		int32 NextTurnSkillLevel = FMath::Min(SkillLevel + 1, CombatCubeConst::Q6_MAX_SKILL_LEVEL);
		int32 ResultCooldown = GetCMS()->GetCooltimeByLevel(SkillRow.Type, NextTurnSkillLevel);
		ResultSkillWidget->SetSkill(NextTurnSkillLevel, BuildToolTipDesc(SkillRow.Type, NextTurnSkillLevel, SkillRow.SkillCategory), ResultCooldown);
		ResultSkillWidget->SetInfoColor((SkillLevel < NextTurnSkillLevel), (ResultCooldown < CurrentCooldown));
	}
}

void UPetParkWidget::SetSkillDetail(const FCMSSkillRow& SkillRow, int32 SkillLevel)
{
	SkillNameText->SetText(SkillRow.DescName);

	EPetSkillState SkillState = EPetSkillState::Invalid;
	if (SkillLevel <= 0)
	{
		SkillState = EPetSkillState::Locked;

		SetSkillInfo(SkillRow, SkillLevel, false);

		if (const FCMSSagaRow* SagaRow = GetCMS()->GetPetSkillOpenConditionSagaRow(SkillRow.CmsType()))
		{
			InfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "LackPetParkNotAcquire"),
				SagaRow->DescName));
		}
	}
	else if (SkillLevel >= CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		SkillState = EPetSkillState::MaxLevel;

		SetSkillInfo(SkillRow, SkillLevel, false);
		InfoText->SetText(Q6Util::GetLocalizedText("Lobby", "PetParkMaxLevel"));
	}
	else if (SkillLevel >= GetHUDStore().GetPetManager().GetPetPark().Level)
	{
		SkillState = EPetSkillState::LowLevel;

		SetSkillInfo(SkillRow, SkillLevel, true);
		InfoText->SetText(FText::Format(Q6Util::GetLocalizedText("Lobby", "LackPetParkLevel"), FText::AsNumber(SkillLevel + 1)));
	}
	else
	{
		SkillState = EPetSkillState::Normal;

		SetSkillInfo(SkillRow, SkillLevel, true);

		// Set materials and cost

		const FCMSSkillUpgradeCostRow& CostRow = GetCMS()->GetSkillUpgradeCostRowOrDummy(SkillRow, SkillLevel + 1);
		const TArray<const FCMSBagItemRow*>& CostBagItems = CostRow.GetBagItem();
		const int32 RequireGold = CostRow.Gold;
		const int32 CurrentGold = GetHUDStore().GetWorldUser().GetGold();

		MaterialsWidget->SetMaterials(CostBagItems, CostRow.BagItemCount);

		OwnedGoldWidget->SetCurPoint(CurrentGold);
		RequireGoldWidget->SetPoint(RequireGold, CurrentGold);

		bool bEnoughMaterials = GetHUDStore().GetBagItemManager().HasEnoughBagItem(CostBagItems, CostRow.BagItemCount);
		UpgradeButton->SetIsEnabled(bEnoughMaterials && (CurrentGold >= RequireGold));
	}

	SetSkillState(SkillState);
}

void UPetParkWidget::OnUpgradeButtonClicked()
{
	USkillUpgradeConfirmPopupWidget* ConfirmPopup = GetCheckedLobbyHUD(this)->OpenSkillUpgradeConfirmPopup();
	check(ConfirmPopup);

	ConfirmPopup->SetPetSkill(PetId, SelectedSkillIdx);
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &UPetParkWidget::OnPetSkillUpgrade);
}

void UPetParkWidget::OnPetSkillUpgrade(EConfirmPopupFlag Option)
{
	if (Option != EConfirmPopupFlag::Yes)
	{
		return;
	}

	GetHUDStore().GetPetManager().ReqPetSkillUpgrade(PetId, SelectedSkillIdx);
}

void UPetParkWidget::OnPetPageChanged(int32 NewPage)
{
	PetId = FPetId::InvalidValue();
	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().GetPetInfoByIndex(NewPage - 1);
	if (!PetInfo)
	{
		Q6JsonLogRoze(Error, "UPetParkWidget::OnPetPageChanged - Not found pet by index", Q6KV("Index", NewPage - 1));
		return;
	}

	PetId = PetInfo->PetId;

	const FCMSPetRow& PetRow = GetCMS()->GetPetRowOrDummy(PetInfo->Type);
	PetNameText->SetText(PetRow.Name);

	SetSkillIcons(*PetInfo, 0);	// Default selected slot index

	UPetIconWidget* PetIcon = CastChecked<UPetIconWidget>(PetSwipeWidget->GetFocusedWidget());

	if (PetIcon)
	{
		PetIcon->SetPet(PetInfo->Type);
	}
}

void UPetParkWidget::OnSelectedSkill(int32 SkillIndex)
{
	SelectedSkillIdx = SkillIndex;

	for (int32 i = 0; i < SkillIcons.Num(); ++i)
	{
		SkillIcons[i]->SetSelected(i == SkillIndex);
	}

	const FPetInfo* PetInfo = GetHUDStore().GetPetManager().Find(PetId);
	if (!PetInfo)
	{
		Q6JsonLogRoze(Error, "UPetParkWidget::OnSelectedSkill - Not found pet by index", Q6KV("Index", SkillIndex));
		return;
	}

	TArray<int32> SkillLevels;
	SkillLevels.Add(PetInfo->Skill1Level);
	SkillLevels.Add(PetInfo->Skill2Level);
	SkillLevels.Add(PetInfo->Skill3Level);
	check(SkillLevels.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	const TArray<const FCMSSkillRow*> SkillRows = GetCMS()->GetPetRowOrDummy(PetInfo->Type).GetSkills();
	check(SkillRows.Num() == CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

	SetSkillDetail(*SkillRows[SelectedSkillIdx], SkillLevels[SelectedSkillIdx]);
}
