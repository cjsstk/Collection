// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "LobbyHUDWidget.h"
#include "PopupWidgets.h"
#include "Q6LobbyState.h"

#include "UpgradeWidgets.generated.h"

class UItemLabelWidget;
class UDynamicListWidget;
class UHSEvent;
class UItemBigCardWidget;
class UItemCardWidget;
class UItemLevelWidget;
class UItemListPopupWidget;
class UItemSelectActionWidget;
class UMaterialBoxWidget;
class UPopupBaseWidget;
class UUpgradeStatWidget;
class UUpgradeInventoryWidget;
class UUpgradeResultStatWidget;
class UPointWidget;
class UTurnSkillIconWidget;
class USkillIconWidget;
class USkillUpInfoWidget;
class USortingWidget;
class UStatWidget;
class UUltimateSkillIconWidget;
class UUpgradeResultTierWidget;
class UUpgradeResultSkillWidget;
class UQ6TextBlock;

UENUM(BlueprintType)
enum class ESkillTierUpCategory : uint8
{
	TurnSkill = 0,
	Ultimate,
	Tier,
};

UENUM(BlueprintType)
enum class EMaxUpCategory : uint8
{
	Promote = 0,
	Unbind,
	Evolute,
};

UCLASS()
class Q6_API UUpgradeResultTextWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	UFUNCTION(BlueprintNativeEvent, Category = "UI")
	void SetResult(EUpgradeResultType InResultType);
	void SetResult_Implementation(EUpgradeResultType InResultType);

private:
	UPROPERTY()
	UTextBlock* ResultText;

	UPROPERTY(Transient)
	UWidgetAnimation* SuccessStartAnim;
};

UCLASS()
class Q6_API UUpgradeXpBarWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetResultXp(int32 InGainXp, int32 InRemainXp, int32 InMaxXp);
	//Roze-TODO:SetAddXp (Not-used-yet)

private:
	UPROPERTY()
	UProgressBar* XpBar;

	UPROPERTY()
	UProgressBar* ResultXpBar;

	UPROPERTY()
	UQ6TextBlock* GainXpText;

	UPROPERTY()
	UQ6TextBlock* RemainXpText;
};

UCLASS()
class Q6_API UResultGainSkillWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetTurnSkill(FCharacterType Type, int32 SkillIndex);
	void SetTitleVisible(bool bInVisible);

private:
	UPROPERTY()
	UImage* SkillIconImage;

	UPROPERTY()
	UTextBlock* SkillNameText;

	UPROPERTY()
	UBorder* TitleBorder;

	UPROPERTY(Transient)
	UWidgetAnimation* GainSkillStartAnim;
};

UCLASS()
class Q6_API UResultLevelUpWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacterAddXpResult(
		const FCharacterInfo& Info,
		int32 OldLevel,
		int32 GainXp,
		EUpgradeResultType UpgradeResult);
	void SetRelicAddXpResult(
		const FRelicInfo& Info,
		int32 OldLevel,
		int32 GainXp,
		EUpgradeResultType UpgradeResult);
	void SetSculptureAddXpResult(
		const FSculptureInfo& Info,
		int32 OldLevel,
		int32 GainXp,
		EUpgradeResultType UpgradeResult);

	void SetResultVisibles(bool bLevelUpVisible, bool bResultTextVisible);

private:
	UPROPERTY()
	UVerticalBox* LevelUpBox;

	UPROPERTY()
	UItemLevelWidget* LevelWidget;

	UPROPERTY()
	UStatWidget* HpStatWidget;

	UPROPERTY()
	UStatWidget* AtkStatWidget;

	UPROPERTY()
	UStatWidget* DefStatWidget;

	UPROPERTY()
	UUpgradeXpBarWidget* XpBarWidget;

	UPROPERTY()
	UUpgradeResultTextWidget* ResultTextWidget;

	UPROPERTY(Transient)
	UWidgetAnimation* LevelUpStartAnim;
};

UCLASS()
class Q6_API UResultSkillTierInfoWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetUltSkill(const FCMSSkillRow& SkillRow, const FSkillAssetRow& AssetRow, int32 Level);
	void SetTurnSkill(const FCMSSkillRow& SkillRow, const FSlateBrush& SkillIconBrush, int32 Level);
	void SetEquipEffect(int32 Tier, const TArray<const FCMSBuffRow*>& Buffs);

protected:
	UFUNCTION(BlueprintImplementableEvent, Category = "UI")
	void SetSkillState(ESkillTierUpCategory Category);

	UPROPERTY(EditInstanceOnly, BlueprintReadOnly, Category = "UI")
	bool bLevelUp;

private:
	UPROPERTY()
	UImage* UltIconImage;

	UPROPERTY()
	UImage* TurnSkillIconImage;

	UPROPERTY()
	UImage* TierIconImage;

	UPROPERTY()
	UTextBlock* SkillLevelText;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* CooltimeText;

	UPROPERTY()
	URichTextBlock* DescText;
};

UCLASS()
class Q6_API UResultSkillTierUpWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetUltSkill(FCharacterType CharacterType, int32 OldLevel, int32 NewLevel);
	void ChangeUltSkill(FCharacterType OldCharacterType, int32 OldLevel, FCharacterType NewCharacterType, int32 NewLevel);
	void SetTurnSkill(const FCMSSkillRow& SkillRow, int32 ModelType, int32 Index, int32 Level);
	void SetRelic(FRelicType RelicType, int32 OldTier, int32 NewTier);
	void SetSculpture(FSculptureType SculptureType, int32 OldTier, int32 NewTier);

private:
	void SetTitle(ESkillTierUpCategory Category);

	UPROPERTY()
	UResultSkillTierInfoWidget* BeforeInfoWidget;

	UPROPERTY()
	UResultSkillTierInfoWidget* AfterInfoWidget;

	UPROPERTY()
	UImage* TitleImage;

	UPROPERTY()
	UTextBlock* SubTitleText;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillTierUpStartAnim;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> TitleBrushes;
};

UCLASS()
class Q6_API UResultMaxUpWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacter(EMaxUpCategory Category, const FCharacterInfo& Info);
	void SetEquip(int32 Level, int32 OldStar, int32 NewStar);

private:
	void SetMaxUp(EMaxUpCategory Category);

	UPROPERTY()
	UItemLevelWidget* BeforeWidget;

	UPROPERTY()
	UItemLevelWidget* AfterWidget;

	UPROPERTY()
	UImage* TitleImage;

	UPROPERTY(Transient)
	UWidgetAnimation* MaxUpStartAnim;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> TitleBrushes;
};

UCLASS()
class Q6_API UItemLevelUpWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemLevelUpWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetItemLevelUp(EUpgradeCategory Category, int64 InItemId, bool bInit = true);
	void SetEquipTierUp(EUpgradeCategory Category, int64 InItemId, bool bInit = true);
	void SetUltimateUp(const FCharacterId& CharacterId, bool bInit = true);

private:
	void ResetUI();
	void RefreshUI();

	void SetCharacterLevelUp(const FCharacterId& CharacterId);
	void SetRelicLevelUp(const FRelicId& RelicId);
	void SetSculptureLevelUp(const FSculptureId& SculptureId);

	void SetRelicTierUp(const FRelicId& RelicId);
	void SetSculptureTierUp(const FSculptureId& SculptureId);

	void SetRelic(const FRelicInfo& RelicInfo);
	void SetSculpture(const FSculptureInfo& SculptureInfo);

	void SetSelectedItemCard(UItemCardWidget* ClickedItemWidget, int32 TargetItemType);
	void SetSelectableCard(UItemCardWidget* ItemCard, int32 TargetItemType = 0);

	void SetCharacterGainXP();
	void SetRelicGainXp();
	void SetSculptureGainXp();

	void SetGoldCost();
	void SetCharacterAddXpCost(const FCharacterInfo& TargetInfo);
	void SetRelicAddXpCost(const FRelicInfo& TargetInfo);
	void SetSculptureAddXpCost(const FSculptureInfo& TargetInfo);

	void SetUltimateSkillUpCost(int32 CurrentLevel);
	void SetRelicTierUpCost(int32 CurrentTier);
	void SetSculptureTierUpCost(int32 CurrentTier);

	void SetTierUpResult(EUpgradeCategory Category, int32 EquipType, int32 CurrentTier);
	void SetUltimateUpResult(const FCharacterInfo& CharacterInfo);

	TArray<int64> GatherMaterialItemIds();
	int32 GetTargetTier(EUpgradeCategory Category, int32 CurrentTier);
	int32 GetTargetUltLevel(int32 CurrentLevel);

	UFUNCTION()
	void OnAddXpUpgradeButtonClicked();

	UFUNCTION()
	void OnTierUpgradeButtonClicked();

	UFUNCTION()
	void OnUltimateUpgradeButtonClicked();

	void OnItemCardClicked(UItemCardWidget* ClickedItemWidget);
	void OnCharacterMaterialCardClicked(UItemCardWidget* ClickedItemWidget);
	void OnRelicMaterialCardClicked(UItemCardWidget* ClickedItemWidget);
	void OnSculptureMaterialCardClicked(UItemCardWidget* ClickedItemWidget);

	void OnItemLockButtonClicked(UItemCardWidget* ChangeLockedCardWidget);

	void OnItemLevelUp(EConfirmPopupFlag Flag);
	void OnEquipTierUp(EConfirmPopupFlag Flag);
	void OnUltLevelUp(EConfirmPopupFlag Flag);

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UItemBigCardWidget* EquipCardWidget;

	UPROPERTY()
	UItemLabelWidget* ItemLabelWidget;

	UPROPERTY()
	UUpgradeStatWidget* ItemStatWidget;

	UPROPERTY()
	UPointWidget* OwnedPointWidget;

	UPROPERTY()
	UPointWidget* RequirePointWidget;

	UPROPERTY()
	UTextBlock* UpgradeText;

	UPROPERTY()
	UButton* UpgradeButton;

	UPROPERTY()
	UDynamicListWidget* MaterialItemListWidget;

	UPROPERTY()
	UTextBlock* TierUpText;

	UPROPERTY()
	UUpgradeResultTierWidget* ResultTierUpWidget;

	UPROPERTY()
	UUpgradeResultSkillWidget* ResultSkillUpWidget;

	UPROPERTY()
	UTextBlock* SkillNameText;

	UPROPERTY()
	USkillIconWidget* UltIconWidget;

	UPROPERTY()
	UUpgradeResultSkillWidget* ResultUltUpWidget;

	UPROPERTY()
	USortingWidget* SortingWidget;

	UPROPERTY()
	UItemSelectActionWidget* SelectActionWidget;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* CharacterUpgradeAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* EquipUpgradeAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TierUpgradeAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* UltimateUpgradeAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	uint32 MaterialMaxCount;

	EUpgradeCategory ItemCategory;
	TArray<UItemCardWidget*> MaterialItemWidgets;
	int64 TargetItemId;
	int64 UpgradeCost;
	bool bCanAddMaterial;
	bool bSkillUp;

	bool bWaitRefresh;
};

UCLASS()
class Q6_API UItemMaxLevelUpWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UItemMaxLevelUpWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetItemPromote(EUpgradeCategory Category, int64 ItemId);
	void SetCharacterEvolute(const FCharacterId& CharacterId);

private:
	void SetCharacter(const FCharacterId& CharacterId);
	void SetRelic(const FRelicId& RelicId);
	void SetSculpture(const FSculptureId& SculptrueId);

	UFUNCTION()
	void OnUpgradeButtonClicked();

	void OnCharacterMaxLevelUpConfirmed(EConfirmPopupFlag Flag, EUpgradeCharacterCategory UpCategory, FCharacterId CharacterId);
	void OnRelicPromoteConfirmed(EConfirmPopupFlag Flag, FRelicId RelicId);
	void OnSculpturePromoteConfirmed(EConfirmPopupFlag Flag, FSculptureId SculptureId);

	UPROPERTY()
	UItemLabelWidget* ItemLabelWidget;

	UPROPERTY()
	UUpgradeResultStatWidget* UpgradeResultStatWidget;

	UPROPERTY()
	UPointWidget* OwnedPointWidget;

	UPROPERTY()
	UPointWidget* RequirePointWidget;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UItemBigCardWidget* EquipCardWidget;

	UPROPERTY()
	UTextBlock* CurrentMaxLevelText;

	UPROPERTY()
	UTextBlock* NewMaxLevelText;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UTextBlock* UpgradeCategoryText;

	UPROPERTY()
	UButton* UpgradeButton;
};

UCLASS()
class Q6_API UGainFinalArtWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacter(FCharacterType CharacterType);

private:
	UPROPERTY()
	UImage* FinalArtImage;

	UPROPERTY(Transient)
	UWidgetAnimation* GainFinalArtAnim;
};

UCLASS()
class Q6_API UTurnSkillUpWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UTurnSkillUpWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	UFUNCTION()
	void SetTurnSkill(const FCharacterId& InCharacterId);

	UFUNCTION()
	void OnPromoteButtonClicked();

	UFUNCTION()
	void OnSelectUpgradeSkill(int32 InSkillIndex);

private:
	void SetSkillInfoWidget();
	void SetGoldAndMaterialsWidget();

	void SetNotOpenedText(FCharacterType InCharacterType);

	UFUNCTION()
	void SetSkillIconWidget();

	UFUNCTION()
	void OnTurnSkillUpgrade(EConfirmPopupFlag Option);

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UItemLabelWidget* CharacterLabelWidget;

	UPROPERTY()
	UTextBlock* SkillName;

	UPROPERTY()
	TArray<UTurnSkillIconWidget*> TurnSkillIconWidgets;

	UPROPERTY()
	USkillUpInfoWidget* CurrentSkillWidget;

	UPROPERTY()
	USkillUpInfoWidget* ResultSkillWidget;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UPointWidget* OwnedPointWidget;

	UPROPERTY()
	UPointWidget* RequirePointWidget;

	UPROPERTY()
	UButton* PromoteButton;

	UPROPERTY()
	UWidgetAnimation* SkillInfoDefaultAnim;

	UPROPERTY()
	UWidgetAnimation* SkillInfoLowLevelAnim;

	UPROPERTY()
	UWidgetAnimation* SkillInfoMaxLevelAnim;

	UPROPERTY()
	UWidgetAnimation* SkillInfoNotAcquireAnim;

	UPROPERTY()
	URichTextBlock* NotifyContentText;

	// Fields

	FCharacterId SelectedCharacterId;
	int32 SelectedSkillIndex;
	bool bEnoughCost;
};

UCLASS()
class Q6_API USkillUpInfoWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	USkillUpInfoWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	void SetSkill(int32 SkillLevel, const FText& SkillInfo, int32 SkillCooldown = 0);
	void SetArtifact(int32 SkillLevel, const FText& SkillInfo, int32 ReuseTime);
	void SetEquipEffecs(int32 Tier, const TArray<const FCMSBuffRow*>& Buffs);

	// Change color (White to Green)
	void SetInfoColor(bool bLevelUp, bool bCooldownReduce);
	void SetLevelUp(bool bLevelUp);

private:
	void SetSkillInfo(int32 Level, const FText& Info, int32 SkillCooldown);

	UPROPERTY()
	UTextBlock* LabelText;

	UPROPERTY()
	UTextBlock* LevelText;

	UPROPERTY()
	UQ6TextBlock* CooltimeText;

	UPROPERTY()
	UTextBlock* CooldownText;

	UPROPERTY()
	URichTextBlock* DescriptionText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* LevelSkillLevelDefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SkillLevelUpAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CooldownDefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* NoCooldownAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CooldownReduceAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ReuseTimeAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* TierUpAnim;

	// Fields

	UPROPERTY(EditInstanceOnly)
	bool bDayCooltime;
};

UCLASS()
class Q6_API UUpgradeResultSkillWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UUpgradeResultSkillWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetRelicSkill(FRelicType RelicType, int32 CurrentTier, int32 ResultTier);
	void SetSculptureSKill(FSculptureType SculptureType, int32 CurrentTier, int32 ResultTier);
	void SetTurnSkill(const FCMSSkillRow& SkillRow, int32 CurrentLevel, int32 ResultLevel);
	void SetUltimateSkill(const FCMSSkillRow& SkillRow, int32 CurrentLevel, int32 ResultLevel);

private:
	void SetResultVisibility(bool bNoUpgrade);

	UPROPERTY()
	USkillUpInfoWidget* CurrentSkillWidget;

	UPROPERTY()
	USkillUpInfoWidget* ResultSkillWidget;

	UPROPERTY()
	USizeBox* NoneSkillBox;

	UPROPERTY()
	UTextBlock* NoneInfoText;
};

UCLASS()
class Q6_API UUpgradeResultTierWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UUpgradeResultTierWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetTier(int32 CurTier, int32 ResultTier);

private:
	UPROPERTY()
	UImage* CurTierIcon;

	UPROPERTY()
	UImage* ResultTierImage;

	UPROPERTY()
	UImage* NoneTierImage;
};

UCLASS()
class Q6_API UUpgradeWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UUpgradeWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual bool OnBack() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Upgrade; }

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void SetUpgradeMenu(int64 InItemId);
	void SetUpgradeMenu(EUpgradeCategory Category, int32 MenuIndex,int64 ItemId);

	void SetSkillMenu(EUpgradeSkillCategory InUpCategory, int64 ItemId);
	void SetCharacterMenu(EUpgradeCharacterCategory InUpCategory, int64 ItemId);
	void SetEquipMenu(EUpgradeCategory ItemCategory, EUpgradeEquipCategory InUpCategory, int64 ItemId);

	void SetNewMarks();

	void OnUpgradeResultPopupClosed(bool bMenuBack);
	void OnUpgradeButtonClicked(EUpgradeCategory Category);

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> MenuBGs;

	UPROPERTY()
	UWidgetSwitcher* UpgradeMenuSwitcher;

	UPROPERTY()
	UUpgradeInventoryWidget* InventoryWidget;

	UPROPERTY()
	UItemLevelUpWidget* ItemLevelUpWidget;

	UPROPERTY()
	UItemMaxLevelUpWidget* ItemMaxLevelUpWidget;

	UPROPERTY()
	UTurnSkillUpWidget* TurnSkillUpWidget;

	UPROPERTY()
	UWidgetSwitcher* UpgradeCategorySwitcher;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	TArray<UImage*> NewMarkImages;
};

UCLASS()
class Q6_API UUpgradeResultWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacterAddXpResult(
		const FCharacterInfo& NewInfo,
		const FCharacterInfo& OldInfo,
		int32 GainXp,
		EUpgradeResultType UpgradeResult = EUpgradeResultType::Fail);
	void SetRelicAddXpResult(
		const FRelicInfo& NewInfo,
		const FRelicInfo& OldInfo,
		int32 GainXp,
		EUpgradeResultType UpgradeResult = EUpgradeResultType::Fail);
	void SetSculptureAddXpResult(
		const FSculptureInfo& NewInfo,
		const FSculptureInfo& OldInfo,
		int32 GainXp,
		EUpgradeResultType UpgradeResult = EUpgradeResultType::Fail);

	void SetUltSkillUpResult(
		const FCharacterInfo& NewInfo,
		const FCharacterInfo& OldInfo,
		int32 GainXp);
	void SetRelicTierUpResult(
		const FRelicInfo& NewInfo,
		const FRelicInfo& OldInfo,
		int32 GainXp);
	void SetSculptureTierUpResult(
		const FSculptureInfo& NewInfo,
		const FSculptureInfo& OldInfo,
		int32 GainXp);

	void SetTurnSkillLevelUpResult(const FCharacterInfo& NewInfo, const FCharacterInfo& OldInfo);
	void SetCharacterMaxLevelUpResult(EUpgradeCharacterCategory UpCategory, const FCharacterInfo& Info);
	void SetRelicPromoteResult(const FRelicInfo& Info);
	void SetSculpturePromoteResult(const FSculptureInfo& Info);

	void SetWeedGrowResult(FWeedGrowType WeedGrowType, const FCharacterInfo& WeedInfo);

private:
	void SetResultVisibles(bool bMaxUp, bool bGainSkill, bool bLevelUp, bool bSkillTierUp);

	void SetCharacter(FCharacterType CharacterType);
	void SetSculpture(FSculptureType SculptureType);
	void SetRelic(FRelicType RelicType);

	void OpenGainFinalArtPopup(FCharacterType CharacterType);

	void OnWeedTurnSkillOpen(const FCharacterInfo& Info, int32 TurnSkillIndex);
	void OnWeedUpgrade(const FCharacterInfo& Info);
	void OnWeedUltimateSkillLevelUp(const FCharacterInfo& Info, FWeedGrowType WeedGrowType);
	void OnWeedUltimateSkillChange(const FCharacterInfo& Info, FWeedGrowType WeedGrowType);

	UPROPERTY()
	UImage* CharacterImage;

 	UPROPERTY()
	UItemBigCardWidget* EquipCardWidget;

	UPROPERTY()
	UResultMaxUpWidget* MaxUpWidget;

	UPROPERTY()
	UResultGainSkillWidget* GainSkillWidget;

	UPROPERTY()
	UResultLevelUpWidget* LevelUpWidget;

	UPROPERTY()
	UResultSkillTierUpWidget* SkillTierUpWidget;

	UPROPERTY()
	UVerticalBox* TouchCloseBox;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradeStartAnim;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UGainFinalArtWidget> GainFinalArtWidgetClass;
};
