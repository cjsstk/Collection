// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "ShopWidgets.h"

#include "BaseHUD.h"
#include "CMSTable.h"
#include "CommonWidgets.h"
#include "ContentFeatureOpenManager.h"
#include "GameResource.h"
#include "HSAction.h"
#include "HUDStore/BagItemManager.h"
#include "ItemWidgets.h"
#include "PointWidgets.h"
#include "LobbyHUD.h"
#include "NewMarkManager.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "ShopManager.h"
#include "SortingWidgets.h"
#include "SystemConstHelper.h"
#include "UIClassResource.h"
#include "Q6Log.h"
#include "Q6Util.h"
#include "HUDStore/EventManager.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent Shop"), STAT_OnHSEventByShop, STATGROUP_HSTORE);
DECLARE_CYCLE_STAT(TEXT("OnHSEvent SellShop"), STAT_OnHSEventBySellShop, STATGROUP_HSTORE);

static int32 SecondInDay = 86400;

UENUM()
enum class EShopSwitcherCategory : uint8
{
	Shop,
	Gem,
	None
};

UENUM()
enum class EDiskCategory : uint8
{
	Character,
	Sculpture,
	Relic,
	None
};

EShopCategory ConvertShopMenuToShopCategory(EShopMenu InShopMenu)
{
	switch (InShopMenu)
	{
		case EShopMenu::Lumicube:
			return EShopCategory::Lumicube;
		case EShopMenu::DiskCharacter:
		case EShopMenu::DiskSculpture:
		case EShopMenu::DiskRelic:	// fall through
			return EShopCategory::DiskExchange;
		case EShopMenu::Sell:
		case EShopMenu::Gem:
		case EShopMenu::None:
		default:	// fall through
			Q6JsonLogGunny(Warning, "ConvertShopMenuToShopCategory - How could you enter in..?"
				, Q6KV("InShopMenu", static_cast<int>(InShopMenu)));
			return EShopCategory::Lumicube;
	}
}

ELootCategory ConvertShopMenuToCostCategory(EShopMenu InShopMenu)
{
	switch (InShopMenu)
	{
		case EShopMenu::Lumicube:
			return ELootCategory::Lumicube;
		case EShopMenu::DiskCharacter:
			return ELootCategory::CharacterDisk;
		case EShopMenu::DiskSculpture:
			return ELootCategory::SculptureDisk;
		case EShopMenu::DiskRelic:
			return ELootCategory::RelicDisk;
	}

	Q6JsonLogRoze(Warning, "ConvertShopMenuToCostCategory - Invalid shop menu", Q6KV("ShopMenu", (int32)InShopMenu));
	return ELootCategory::None;
}

bool IsDiskItem(EShopMenu InShopMenu, ELootCategory InLootCategory)
{
	switch (InShopMenu)
	{
		case EShopMenu::DiskCharacter:
			if (InLootCategory == ELootCategory::CharacterCard)
			{
				return true;
			}
			break;
		case EShopMenu::DiskSculpture:
			if (InLootCategory == ELootCategory::SculptureCard)
			{
				return true;
			}
			break;
		case EShopMenu::DiskRelic:
			if (InLootCategory == ELootCategory::RelicCard)
			{
				return true;
			}
			break;
		case EShopMenu::Lumicube:
		case EShopMenu::Gem:
		case EShopMenu::Sell:
		case EShopMenu::None:
		default: // fall through
			break;
	}

	return false;
}

/*
* ShopWidgetBp
*/

UShopWidget::UShopWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UShopWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IntroAnim = GetWidgetAnimationFromName(this, "AnimIntro");
	SelectContentAnim = GetWidgetAnimationFromName(this, "AnimSelectContent");
	BackShopAnim = GetWidgetAnimationFromName(this, "AnimBackShop");

	UButton* LumicubeShopButton = CastChecked<UButton>(GetWidgetFromName("LumicubeShop"));
	LumicubeShopButton->OnClicked.AddUniqueDynamic(this, &UShopWidget::OnLumicubeShopButtonClicked);

	UButton* DiskExchangeShopButton = CastChecked<UButton>(GetWidgetFromName("DiskExchangeShop"));
	DiskExchangeShopButton->OnClicked.AddUniqueDynamic(this, &UShopWidget::OnDiskShopButtonClicked);

	UButton* GemShopButton = CastChecked<UButton>(GetWidgetFromName("GemShop"));
	GemShopButton->OnClicked.AddUniqueDynamic(this, &UShopWidget::OnGemShopButtonClicked);

	UButton* SellShopButton = CastChecked<UButton>(GetWidgetFromName("SellShop"));
	SellShopButton->OnClicked.AddUniqueDynamic(this, &UShopWidget::OnSellButtonClicked);

	ShopSwitcherWidget = CastChecked<UWidgetSwitcher>(GetWidgetFromName("ShopSwitcher"));
	GeneralShopListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("GeneralShopList"));
	GemShopListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("GemShopList"));
	DiskCategoryButtonWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CategoryButtons"));

	ShopBg = CastChecked<UImage>(GetWidgetFromName("ImgShopBg"));

	PointWidget = CastChecked<UPointWidget>(GetWidgetFromName("Point"));
	FreeGemPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("FreeGem"));
	PaidGemPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("PaidGem"));

	LumicubeShopNewMarkImage = CastChecked<UImage>(GetWidgetFromName("LumicubeShopNewMark"));
	DiskShopNewMarkImage = CastChecked<UImage>(GetWidgetFromName("DiskShopNewMark"));
}

void UShopWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::Shop);
	SubscribeToStore(EHSType::NewMark);
	SubscribeToStore(EHSType::Event);
	SubscribeToStore(EHSType::ContentFeatureOpen);

	if (GetHUDStore().GetEventManager().IsEventScheduleChanged())
	{
		GetHUDStore().GetShopManager().ReqList(false);
	}

	PlayAnimation(IntroAnim);
}

void UShopWidget::OnLeaveMenu()
{
	Super::OnLeaveMenu();
	CloseSellShopWidget();
}

void UShopWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FShopUIState* UIState = GetUIState()->CastToShopUIState();
	check(UIState);

	SetShop(UIState->ShopMenu, UIState->bPlayAnim);
}

bool UShopWidget::OnBack()
{
	CloseSellShopWidget();
	return true;
}

void UShopWidget::OnLumicubeShopButtonClicked()
{
	ACTION_DISPATCH_ShopMenuChange(EShopMenu::Lumicube, true);
}

void UShopWidget::OnDiskShopButtonClicked()
{
	// for preventing, calling dispatch twice
	DiskCategoryButtonWidget->OnToggleButtonClickedDelegate.Unbind();
	DiskCategoryButtonWidget->SetSelectedIndex(static_cast<int>(EShopMenu::DiskCharacter));
	DiskCategoryButtonWidget->OnToggleButtonClickedDelegate.BindUObject(this, &UShopWidget::OnDiskCategoryChanged);

	ACTION_DISPATCH_ShopMenuChange(EShopMenu::DiskCharacter, true);
}

void UShopWidget::OnGemShopButtonClicked()
{
	ACTION_DISPATCH_ShopMenuChange(EShopMenu::Gem, true);
}

void UShopWidget::OnSellButtonClicked()
{
	EFeatureOpenType FeatureOpenType(EFeatureOpenType::ShopSell);

	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();
	bool bEnable = ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType);
	if (!bEnable)
	{
		GetBaseHUD(this)->ShowNotOpenedYetNotification(FeatureOpenType);
		return;
	}

	ACTION_DISPATCH_ShopMenuChange(EShopMenu::Sell, true);
}

void UShopWidget::OnDiskCategoryChanged(int32 InIndex)
{
	if (InIndex > static_cast<int>(EShopMenu::DiskRelic))
	{
		Q6JsonLogGunny(Warning, "UShopWidget::OnDiskCategoryChanged - over DiskCategory index", Q6KV("InIndex", InIndex));
		return;
	}

	EShopMenu DiskShopMenu = EShopMenu(InIndex);
	SetShop(DiskShopMenu, false);
	ACTION_DISPATCH_ShopMenuChange(DiskShopMenu, false);
}

void UShopWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByShop);

	if (Action->GetActionType() == EHSActionType::NewMarkNotifyMail)
	{
		// No handle in this widget
		return;
	}

	if (Action->GetActionType() == EHSActionType::ContentsResetTime)
	{
		const UShopManager& ShopMgr = GetHUDStore().GetShopManager();
		int32 MonthOfDay = FDateTime::UtcNow().GetDay();
		if (MonthOfDay == 1)	// Monthly reset day
		{
			ShopMgr.ReqList(false);
			GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "NewShop"));
		}
		else
		{
			ShopMgr.ReqSaleSchedule();
		}

		return;
	}

	RefreshMenu();
}

void UShopWidget::SetShop(EShopMenu InShopMenu, bool bPlayAnim)
{
	SetPoint(InShopMenu);
	SetNewMarks(InShopMenu);

	bool bDiskCategoryVisible = false;

	switch (InShopMenu)
	{
		case EShopMenu::DiskCharacter:
		case EShopMenu::DiskSculpture:
		case EShopMenu::DiskRelic:
			bDiskCategoryVisible = true;	// fall through
		case EShopMenu::Lumicube:
			SetShopList(InShopMenu); 

			if (bPlayAnim)
			{
				PlayAnimation(SelectContentAnim);
			}

			SetWidgetSwitcher(EShopSwitcherCategory::Shop);
			ShopBg->SetBrush(GetUIResource().GetShopBG(InShopMenu));
			break;
		case EShopMenu::Sell:
			SetSellShopList();
			break;
		case EShopMenu::Gem:
			SetGemShopList();
			PlayAnimation(SelectContentAnim);
			SetWidgetSwitcher(EShopSwitcherCategory::Gem);
			break;
		case EShopMenu::None:
			// Don't do anything
			break;
		default:
			break;
	}

	DiskCategoryButtonWidget->SetVisibility(bDiskCategoryVisible ? 
		ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	EFeatureOpenType FeatureOpenType(EFeatureOpenType::ShopSell);

	const UContentFeatureOpenManager& ContentFeatureOpenManager = GetHUDStore().GetContentFeatureOpenManager();
	SetSellShopLockState(!ContentFeatureOpenManager.IsOpenContentFeature(FeatureOpenType));
}

void UShopWidget::SetPoint(EShopMenu InShopMenu)
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	switch (InShopMenu)
	{
		case EShopMenu::DiskCharacter:
			PointWidget->SetPointType(ECurrencyType::CharacterDisk, EPointWidgetOption::NONE);
			PointWidget->SetCurPoint(WorldUser.GetOwnedCurrency(ECurrencyType::CharacterDisk));
			break;
		case EShopMenu::DiskSculpture:
			PointWidget->SetPointType(ECurrencyType::SculptureDisk, EPointWidgetOption::NONE);
			PointWidget->SetCurPoint(WorldUser.GetOwnedCurrency(ECurrencyType::SculptureDisk));
			break;
		case EShopMenu::DiskRelic:
			PointWidget->SetPointType(ECurrencyType::RelicDisk, EPointWidgetOption::NONE);
			PointWidget->SetCurPoint(WorldUser.GetOwnedCurrency(ECurrencyType::RelicDisk));
			break;
		case EShopMenu::Lumicube:
			PointWidget->SetPointType(ECurrencyType::Lumicube, EPointWidgetOption::NONE);
			PointWidget->SetCurPoint(WorldUser.GetOwnedCurrency(ECurrencyType::Lumicube));
			break;
		case EShopMenu::Gem:
			FreeGemPointWidget->SetPointType(ECurrencyType::FreeGem, EPointWidgetOption::NONE);
			FreeGemPointWidget->SetCurPoint(WorldUser.GetOwnedCurrency(ECurrencyType::FreeGem));

			PaidGemPointWidget->SetPointType(ECurrencyType::PaidGem, EPointWidgetOption::NONE);
			PaidGemPointWidget->SetCurPoint(WorldUser.GetOwnedCurrency(ECurrencyType::PaidGem));
			break;
		case EShopMenu::Sell:
		case EShopMenu::None:	// fall through
			break;
	}
}

void UShopWidget::SetWidgetSwitcher(EShopSwitcherCategory InShopSwitcherCategory)
{
	int32 CategoryIndex = static_cast<int>(InShopSwitcherCategory);

	UWidget* ActiveWidget = ShopSwitcherWidget->GetWidgetAtIndex(CategoryIndex);
	if (!ActiveWidget)
	{
		Q6JsonLogGunny(Warning, "UShopWidget::SetWidgetSwitcher - ShopSwitcherWidget doesn't have a widget at that index",
			Q6KV("SwicherCategory", CategoryIndex));
		return;
	}

	ShopSwitcherWidget->SetActiveWidget(ActiveWidget);
}

void UShopWidget::SetNewMarks(EShopMenu InShopMenu)
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	
	// Set shop enter buttons

	bool bLumicubeShopNewMark = NewMarkMgr.GetLumicubeShopVisible();
	LumicubeShopNewMarkImage->SetVisibility(bLumicubeShopNewMark ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	bool bDiskShopNewMark = NewMarkMgr.GetDiskShopVisible();
	DiskShopNewMarkImage->SetVisibility(bDiskShopNewMark ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	// Set shop category buttons

	TArray<ELootCategory> CostCategories;
	CostCategories.Add(ELootCategory::CharacterDisk);
	CostCategories.Add(ELootCategory::SculptureDisk);
	CostCategories.Add(ELootCategory::RelicDisk);
	check(DiskCategoryButtonWidget->GetToggleButtons().Num() == CostCategories.Num());

	int32 SelectedIndex = DiskCategoryButtonWidget->GetSelectedIndex();
	for (int32 i = 0; i < CostCategories.Num(); ++i)
	{
		bool bNewMarkVisible = NewMarkMgr.GetShopCategoryVisible(EShopCategory::DiskExchange, CostCategories[i]);
		DiskCategoryButtonWidget->SetToggleButtonNewMark(i , ((i != SelectedIndex) && bNewMarkVisible));
	}
}

void UShopWidget::SetShopList(EShopMenu InShopMenu)
{
	GeneralShopListWidget->ClearList();

	const UShopManager& ShopManager = GetHUDStore().GetShopManager();
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	const UEventManager& EventMgr = GetHUDStore().GetEventManager();

	EShopCategory ShopCategory = ConvertShopMenuToShopCategory(InShopMenu);

	bool bHasNew = false;
	TArray<const FCMSShopRow*> ShopRows = GetCMS()->GetShopRowsByShopCategory(ShopCategory);
	for (const FCMSShopRow* ShopRow : ShopRows)
	{
		if (ShopCategory == EShopCategory::DiskExchange)
		{
			if (!IsDiskItem(InShopMenu, ShopRow->ItemCategory))
			{
				continue;
			}
		}

		int32 LeftDays = INVALID_DAY;
		const FEventScheduleInfo* EventSchedule = EventMgr.GetEventSchedule(ShopRow->EventScheduleId);
		if (EventSchedule && !UCMS::IsInfinityEventScheduleFormat(*EventSchedule))
		{
			FDateTime StartDate = Q6Util::UtcTimestampToLocalDateTime(EventSchedule->StartDate);
			if (FDateTime::Now() < StartDate)
			{
				continue;
			}

			FDateTime EndDate = Q6Util::UtcTimestampToLocalDateTime(EventSchedule->EndDate);
			FTimespan LeftTimeSpan = EndDate - FDateTime::Now();
			LeftDays = LeftTimeSpan.GetTotalDays();
		}
		else
		{
			if (ShopRow->IsMonthlyReset)
			{
				FDateTime Today = FDateTime::Now();
				LeftDays = FDateTime::DaysInMonth(Today.GetYear(), Today.GetMonth()) - Today.GetDay();
			}
		}

		UShopEntryWidget* ShopEntryWidget = CastChecked<UShopEntryWidget>(GeneralShopListWidget->AddChildAtLastIndex());
		ShopEntryWidget->SetNameAndInfo(ShopRow->Name, ShopRow->Desc);

		FItemData GetItemData;
		GetItemData.Category = ShopRow->ItemCategory;
		GetItemData.Type = ShopRow->ItemId;
		GetItemData.Count = ShopRow->Count;
		ShopEntryWidget->SetShopType(ShopRow->CmsType());
		ShopEntryWidget->SetItem(GetItemData);

		FItemData CostItemData;
		CostItemData.Category = ShopRow->CostItemCategory;
		CostItemData.Type = ShopRow->CostItemId;
		CostItemData.Count = ShopRow->CostCount;
		ShopEntryWidget->SetCost(CostItemData);

		const FShopClearNewInfo* ClearNewInfo = ShopManager.GetShopClearNewInfo(ShopCategory, ShopRow->CostItemCategory);
		bool bNewMarkVisible = NewMarkMgr.GetShopItemVisible(*ShopRow, EventSchedule, ClearNewInfo);
		bHasNew |= bNewMarkVisible;

		ShopEntryWidget->SetNewMark(bNewMarkVisible);

		int32 LeftCount = ShopManager.GetStocks(EShopBuyType::None, ShopRow->CmsType());
		ShopEntryWidget->SetLeftDayAndCount(LeftDays, LeftCount);
	}

	if (bHasNew)
	{
		ELootCategory CostCategory = ConvertShopMenuToCostCategory(InShopMenu);
		ShopManager.ReqClearNew(ShopCategory, CostCategory);
	}
}

void UShopWidget::SetGemShopList()
{
	GemShopListWidget->ClearList();

	// Gunny Tempcode
	// GemList does not developed
	UShopGemItemWidget* ShopGemItemWidget = CastChecked<UShopGemItemWidget>(GemShopListWidget->AddChildAtLastIndex());
	ShopGemItemWidget->SetGem(10, 2, 32000);
}

void UShopWidget::SetSellShopList()
{
	OpenOrCreateSellShopWidget();
	SellShopWidget->InitSellShop();
}

void UShopWidget::CloseSellShopWidget()
{
	if (SellShopWidget && SellShopWidget->IsInViewport())
	{
		SellShopWidget->RemoveFromViewport();
		return;
	}

	PlayAnimation(BackShopAnim);
}

void UShopWidget::OpenOrCreateSellShopWidget()
{
	if (!SellShopWidget)
	{
		SellShopWidget = CreateWidget<USellShopWidget>(GetOwningPlayer(), SellShopWidgetClass.LoadSynchronous());
	}

	check(SellShopWidget);

	if (!SellShopWidget->IsInViewport())
	{
		SellShopWidget->AddToViewport(ZORDER_SELL_SHOP_WIDGET);
	}
}

/*
* ShopEntryWidgetBP
*/

UShopEntryWidget::UShopEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bSelectEnabled(true)
	, ShopType(ShopTypeInvalid)
	, ItemData(FItemData())
	, CostItemData(FItemData())
	, LeftDay(0)
	, LeftCount(0)
{

}

void UShopEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	EnabledAnim = GetWidgetAnimationFromName(this, "AnimEnabled");
	DisabledAnim= GetWidgetAnimationFromName(this, "AnimDisabled");

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
	PointWidget = CastChecked<UPointWidget>(GetWidgetFromName("Point"));

	ItemNameText = CastChecked<UTextBlock>(GetWidgetFromName("ItemName"));
	ItemInfoText = CastChecked<UTextBlock>(GetWidgetFromName("ItemInfo"));
	DaysText = CastChecked<UTextBlock>(GetWidgetFromName("Days"));
	StocksText = CastChecked<UTextBlock>(GetWidgetFromName("Stocks"));

	SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UShopEntryWidget::OnSelectButtonClicked);
}

void UShopEntryWidget::SetNameAndInfo(const FText& InName, const FText& InInfo)
{
	ItemNameText->SetText(InName);
	ItemInfoText->SetText(InInfo);
}

void UShopEntryWidget::SetItem(const FItemData& InItemData)
{
	ItemData = InItemData;

	ItemWidget->SetItem(InItemData);
}

void UShopEntryWidget::SetCost(const FItemData& InItemData)
{
	CostItemData = InItemData;

	PointWidget->SetPointType(GetCurrencyType(InItemData.Category), EPointWidgetOption::NONE);
	PointWidget->SetCurPoint(InItemData.Count);
}

void UShopEntryWidget::SetEventPointCost(FEventContentType InEventContentType, const FItemData& InItemData)
{
	EventContentType = InEventContentType;
	CostItemData = InItemData;

	PointWidget->SetEventPointType(InEventContentType, InItemData.Type, EPointWidgetOption::NONE);
	PointWidget->SetCurPoint(InItemData.Count);
}

void UShopEntryWidget::SetLeftDayAndCount(int32 InLeftDay, int32 InLeftCount)
{
	LeftDay = InLeftDay;
	LeftCount = InLeftCount;

	PlayAnimation(InLeftCount != 0 ? EnabledAnim : DisabledAnim);

	if (LeftDay == INVALID_DAY)
	{
		DaysText->SetText(Q6Util::GetLocalizedText("Common", "Unlimited"));
	}
	else
	{
		FDateTime Today = FDateTime::Now();
		FTimespan LeftTime = FTimespan(23, 59, 59) - FTimespan(Today.GetHour(), Today.GetMinute(), Today.GetSecond());

		int64 DaysToSeconds = LeftDay * SecondInDay + LeftTime.GetTotalSeconds();

		DaysText->SetText(Q6Util::GetRemainTimeText(DaysToSeconds));
	}

	StocksText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "NumberCount"), FText::AsNumber(LeftCount)));
}

void UShopEntryWidget::SetNewMark(bool bInVisibile)
{
	ItemWidget->SetNewMark(bInVisibile);
}

void UShopEntryWidget::Duplicate(const UShopEntryWidget* InEntryWidget)
{
	SetNameAndInfo(InEntryWidget->ItemNameText->GetText(), InEntryWidget->ItemInfoText->GetText());
	SetShopType(InEntryWidget->ShopType);
	SetItem(InEntryWidget->ItemData);

	if (InEntryWidget->CostItemData.Category == ELootCategory::EventPoint)
	{
		SetEventPointCost(InEntryWidget->EventContentType, InEntryWidget->CostItemData);
	}
	else
	{
		SetCost(InEntryWidget->CostItemData);
	}
	SetLeftDayAndCount(InEntryWidget->LeftDay, InEntryWidget->LeftCount);
}

void UShopEntryWidget::OnSelectButtonClicked()
{
	if (!bSelectEnabled)
	{
		return;
	}

	UGeneralShopPurchasePopupWidget* PurchasePopup = CastChecked<UGeneralShopPurchasePopupWidget>(GetCheckedLobbyHUD(this)->OpenPopup(GetUIClassResource().GeneralShopPurchasePopupWidgetClass));
	PurchasePopup->SetShopEntryWidget(this);
	PurchasePopup->SetTitle(Q6Util::GetLocalizedText("Popup", "GeneralShopPurchaseTitle"));
}

/*
* ShopGemItemWidgetBP
*/

UShopGemItemWidget::UShopGemItemWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UShopGemItemWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UShopGemItemWidget::OnSelectButtonClicked);

	TotalGemCountText = CastChecked<UTextBlock>(GetWidgetFromName("TotalGemCount"));
	DefaultGemCountText = CastChecked<UTextBlock>(GetWidgetFromName("DefaultGemCount"));
	BonusGemCountText = CastChecked<UTextBlock>(GetWidgetFromName("BonusGemCount"));
	PriceText = CastChecked<UTextBlock>(GetWidgetFromName("Price"));
	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
}

void UShopGemItemWidget::SetGem(int32 InTotalGem, int32 InBonusGem, int32 InPrice)
{
	// Gunny Tempcode
	IconImage->SetBrush(GetUIResource().GetGemAmountIcon(EGemAmount::FullBox));

	TotalGemCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Gems"), FText::AsNumber(InTotalGem)));
	DefaultGemCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Gems"), FText::AsNumber(InTotalGem - InBonusGem)));
	BonusGemCountText->SetText(FText::Format(Q6Util::GetLocalizedText("Common", "Gems"), FText::AsNumber(InBonusGem)));

	PriceText->SetText(FText::AsNumber(InPrice));
}

void UShopGemItemWidget::OnSelectButtonClicked()
{
	// Gunny Todo
	// Open Payment window
	GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Common", "NotImplementedYet"));
}

USellShopWidget::USellShopWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SellShopCategory(EInventoryType::Character)
	, NumOfCard(0)
{

}

void USellShopWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CategoryButtonWidget = CastChecked<UToggleButtonBoxWidget>(GetWidgetFromName("CategoryButtons"));
	CategoryButtonWidget->OnToggleButtonChangedDelegate.BindUObject(this, &USellShopWidget::OnSellShopCategoryChanged);

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
	SortingWidget = CastChecked<USortingWidget>(GetWidgetFromName("Sorting"));

	SelectLockSwitcherWidget = CastChecked<UItemSelectActionWidget>(GetWidgetFromName("SelectLockSwitcher"));
	SelectLockSwitcherWidget->InitActionMode(true, false, true);
	SelectLockSwitcherWidget->OnActionModeChangedDelegate.BindUObject(this, &USellShopWidget::OnActionModeChanged);

	SellPoint1Widget = CastChecked<UPointWidget>(GetWidgetFromName("SellPoint1"));
	SellPoint1Widget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	SellPoint2Widget = CastChecked<UPointWidget>(GetWidgetFromName("SellPoint2"));
	SellPoint2Widget->SetPointType(EPointType::Lumicube, EPointWidgetOption::NONE);

	SellButton = CastChecked<UButton>(GetWidgetFromName("Sell"));
	SellButton->SetIsEnabled(false);
	SellButton->OnClicked.AddUniqueDynamic(this, &USellShopWidget::OnSellButtonClicked);

	AllRemoveButton = CastChecked<UButton>(GetWidgetFromName("AllRemove"));
	AllRemoveButton->SetIsEnabled(false);
	AllRemoveButton->OnClicked.AddUniqueDynamic(this, &USellShopWidget::OnAllRemoveButtonClicked);

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::Character);
}

void USellShopWidget::InitSellShop()
{
	CategoryButtonWidget->SetSelectedIndex(static_cast<int>(EInventoryType::Character));
}

void USellShopWidget::SetList(EInventoryType InSellShopCategory)
{
	SellShopCategory = InSellShopCategory;
	SellButton->SetIsEnabled(false);
	AllRemoveButton->SetIsEnabled(false);
	SellPoint1Widget->SetCurPoint(0);
	SellPoint2Widget->SetCurPoint(0);

	ItemListWidget->ClearList();

	const UHUDStore& HUDStore = GetHUDStore();
	if (SellShopCategory == EInventoryType::Character)
	{
		TArray<const FCharacter*> Characters = HUDStore.GetCharacterManager().GetCharacters(ESortMenu::Collection, ESortCategory::OwnedCharacterWithExp, false);
		TArray<FCharacterId> UsedCharacterIds = HUDStore.GetUsedCharacterIds();

		for (const FCharacter* Character : Characters)
		{
			UItemCardWidget* CharacterCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
			CharacterCard->SetCharacter(Character->GetInfo());
			CharacterCard->SetChecked(false);
			CharacterCard->SetUsed(UsedCharacterIds.Contains(Character->GetInfo().CharacterId));
			CharacterCard->OnItemClickedDelegate.BindUObject(this, &USellShopWidget::OnSelectedItemCard);

			SetSelectableCard(CharacterCard);
		}

		SortingWidget->SetSorting(ESortMenu::Collection, ESortCategory::OwnedCharacterWithExp);
		NumOfCard = Characters.Num();
	}
	else if (SellShopCategory == EInventoryType::Sculpture)
	{
		TArray<const FSculpture*> Sculptures = HUDStore.GetSculptureManager().GetSculptures(ESortMenu::Collection, ESortCategory::OwnedSculptureWithExp, false);
		TArray<FSculptureId> UsedSculptureIds = HUDStore.GetUsedSculptureIds();

		for (const FSculpture* Sculpture : Sculptures)
		{
			UItemCardWidget* SculptureCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
			SculptureCard->SetSculpture(Sculpture->GetInfo());
			SculptureCard->SetChecked(false);
			SculptureCard->SetUsed(UsedSculptureIds.Contains(Sculpture->GetInfo().SculptureId));
			SculptureCard->OnItemClickedDelegate.BindUObject(this, &USellShopWidget::OnSelectedItemCard);

			SetSelectableCard(SculptureCard);
		}

		SortingWidget->SetSorting(ESortMenu::Collection, ESortCategory::OwnedSculptureWithExp);
		NumOfCard = Sculptures.Num();
	}
	else if (SellShopCategory == EInventoryType::Relic)
	{
		TArray<const FRelic*> Relics = HUDStore.GetRelicManager().GetRelics(ESortMenu::Collection, ESortCategory::OwnedRelicWithExp, false);
		TArray<FRelicId> UsedRelicIds = HUDStore.GetUsedRelicIds();

		for (const FRelic* Relic : Relics)
		{
			UItemCardWidget* RelicCard = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
			RelicCard->SetRelic(Relic->GetInfo());
			RelicCard->SetChecked(false);
			RelicCard->SetUsed(UsedRelicIds.Contains(Relic->GetInfo().RelicId));
			RelicCard->OnItemClickedDelegate.BindUObject(this, &USellShopWidget::OnSelectedItemCard);

			SetSelectableCard(RelicCard);
		}

		SortingWidget->SetSorting(ESortMenu::Collection, ESortCategory::OwnedRelicWithExp);
		NumOfCard = Relics.Num();
	}

	SelectedItemCardWidget.Empty();
	SelectLockSwitcherWidget->SetSelectedCount(0, NumOfCard);
}

void USellShopWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventBySellShop);

	if (Action->GetActionType() == EHSActionType::ShopSellItemResp)
	{
		GetBaseHUD(this)->ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Popup", "SellShopConfirmNotify"));
		UnselectItemCards();
	}

	if ((Action->GetActionType() == EHSActionType::ShopSellItemResp) ||
		(Action->GetActionType() == EHSActionType::ShopMenuChange))
	{
		SetList(SellShopCategory);
	}
}

void USellShopWidget::OnSelectedItemCard(UItemCardWidget* InItemCard)
{
	const FItemIconInfo& ItemInfo = InItemCard->GetItemInfo();

	if (SelectLockSwitcherWidget->GetSelectedActionType() == EItemActionType::Lock)
	{
		InItemCard->SetToggleLocked();

		GetHUDStore().ReqSetLock(ItemInfo.AttributeType, ItemInfo.Id, ItemInfo.bLocked);
		return;
	}

	if (ItemInfo.bLocked)
	{
		return;
	}

	InItemCard->SetSelected(InItemCard->GetSelectedType() == EItemSelectType::Deselect ? true : false);

	if (InItemCard->GetSelectedType() == EItemSelectType::Deselect)
	{
		SelectedItemCardWidget.Remove(InItemCard);
	}
	else if (InItemCard->GetSelectedType() == EItemSelectType::Selected)
	{
		SelectedItemCardWidget.Add(InItemCard);
	}

	int32 TotalGold = 0;
	int32 TotalLumicube = 0;
	for (const UItemCardWidget* Iter : SelectedItemCardWidget)
	{
		TotalGold += CalculateGold(Iter);
		TotalLumicube += CalculateLumicube(Iter);
	}

	SelectLockSwitcherWidget->SetSelectedCount(SelectedItemCardWidget.Num(), NumOfCard);

	SellPoint1Widget->SetCurPoint(TotalGold);
	SellPoint2Widget->SetCurPoint(TotalLumicube);

	SellButton->SetIsEnabled(SelectedItemCardWidget.Num() != 0);
	AllRemoveButton->SetIsEnabled(SelectedItemCardWidget.Num() != 0);
}

void USellShopWidget::SetSelectableCard(UItemCardWidget* ItemCard)
{
	if (SelectLockSwitcherWidget->GetSelectedActionType() == EItemActionType::Lock)
	{
		ItemCard->SetSelectable(true);
		return;
	}
	else
	{
		const FItemIconInfo& ItemInfo = ItemCard->GetItemInfo();

		if (SystemConstHelper::IsWeed(FCharacterType(ItemInfo.Type)))
		{
			ItemCard->SetSelectable(false);
			ItemCard->SetReasonText(Q6Util::GetLocalizedText("Common", "SelectDisable"), EItemSelectableReasonType::NotAvailable);
		}
		else if (ItemInfo.bLocked)
		{
			ItemCard->SetSelectable(false);
			ItemCard->SetReasonText(Q6Util::GetLocalizedText("Common", "Locked"), EItemSelectableReasonType::NotAvailable);
		}
		else if(ItemInfo.bUsed)
		{
			ItemCard->SetSelectable(false);
			ItemCard->SetReasonText(Q6Util::GetLocalizedText("Common", "UsedMember"), EItemSelectableReasonType::NotAvailable);
		}
		else
		{
			ItemCard->SetSelectable(true);
		}
	}
}

void USellShopWidget::OnActionModeChanged()
{
	UnselectItemCards();
	SetList(SellShopCategory);
}

void USellShopWidget::OnSellShopCategoryChanged(int32 Index)
{
	if (Index >= static_cast<int>(EInventoryType::Max))
	{
		Q6JsonLogGunny(Error, "USellShopWidget::OnSellShopTypeChanged - Wrong index", Q6KV("Index", Index));
		return;
	}

	SetList(EInventoryType(Index));
}

int32 USellShopWidget::CalculateGold(const UItemCardWidget* InItemCardWidget) const
{
	int32 TotalGold = 0;

	const FItemIconInfo& ItemIconInfo = InItemCardWidget->GetItemInfo();
	if (ItemIconInfo.AttributeType == EAttributeCategory::Character)
	{
		const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(FCharacterType(ItemIconInfo.Type));
		if (CharacterRow.IsInvalid())
		{
			Q6JsonLogGunny(
				Warning,
				"USellShopWidget::CalculateGold - CharacterRow does not exist.",
				Q6KV("CharacterType", ItemIconInfo.Type));
			return 0;
		}

		if (CharacterRow.XpExclusive)
		{
			TotalGold = SystemConstHelper::GetSellCharacterExpGoldByGrade(ItemIconInfo.Grade);
		}
		else
		{
			const int32 SellCharacterGoldConst = SystemConstHelper::GetSellCharacterGoldByGrade(ItemIconInfo.Grade);
			float SellCharacterLevelRatio = CharacterFormulaConst::Q6_SELL_CHARACTER_LEVEL_RATIO * 0.01f;

			TotalGold =
				(SellCharacterGoldConst * ItemIconInfo.UltSkillLevel) +
				(ItemIconInfo.Level * SellCharacterLevelRatio * SellCharacterGoldConst);
		}
	}
	else if (ItemIconInfo.AttributeType == EAttributeCategory::Sculpture)
	{
		const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(FSculptureType(ItemIconInfo.Type));
		if (SculptureRow.IsInvalid())
		{
			Q6JsonLogGunny(
				Warning,
				"USellShopWidget::CalculateGold - SculptureRow does not exist.",
				Q6KV("SculptureType", ItemIconInfo.Type));
			return 0;
		}

		if (SculptureRow.XpExclusive)
		{
			TotalGold = SystemConstHelper::GetSellSculptureExpGoldByGrade(ItemIconInfo.Grade);
		}
		else
		{
			const int32 SellScupltureGoldConst = SystemConstHelper::GetSellSculptureGoldByGrade(ItemIconInfo.Grade);
			float SellSculptureLevelRatio = EquipFormulaConst::Q6_SELL_SCULPTURE_LEVEL_RATIO * 0.01f;

			TotalGold = (SellScupltureGoldConst * ItemIconInfo.Tier) +
				(ItemIconInfo.Level * SellSculptureLevelRatio * SellScupltureGoldConst);
		}
	}
	else if (ItemIconInfo.AttributeType == EAttributeCategory::Relic)
	{
		const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(FRelicType(ItemIconInfo.Type));
		if (RelicRow.IsInvalid())
		{
			Q6JsonLogGunny(
				Warning,
				"USellShopWidget::CalculateGold - RelicRow does not exist.",
				Q6KV("RelicType", ItemIconInfo.Type));
			return 0;
		}

		if (RelicRow.XpExclusive)
		{
			TotalGold = SystemConstHelper::GetSellRelicExpGoldByGrade(ItemIconInfo.Grade);
		}
		else
		{
			const int32 SellRelicGoldConst = SystemConstHelper::GetSellRelicGoldByGrade(ItemIconInfo.Grade);
			float SellRelicLevelRatio = EquipFormulaConst::Q6_SELL_RELIC_LEVEL_RATIO * 0.01f;

			TotalGold = (SellRelicGoldConst * ItemIconInfo.Tier) +
				(ItemIconInfo.Level * SellRelicLevelRatio * SellRelicGoldConst);
		}
	}

	return TotalGold;
}

int32 USellShopWidget::CalculateLumicube(const UItemCardWidget* InItemCardWidget) const
{
	int32 TotalLumicube = 0;

	const FItemIconInfo& ItemIconInfo = InItemCardWidget->GetItemInfo();
	if (ItemIconInfo.AttributeType == EAttributeCategory::Character)
	{
		const FCMSCharacterRow& CharacterRow = GetCMS()->GetCharacterRowOrDummy(FCharacterType(ItemIconInfo.Type));
		if (CharacterRow.IsInvalid())
		{
			Q6JsonLogGunny(
				Warning,
				"USellShopWidget::CalculateLumicube - CharacterRow does not exist.",
				Q6KV("CharacterType", ItemIconInfo.Type));
			return 0;
		}

		if (CharacterRow.XpExclusive)
		{
			TotalLumicube = SystemConstHelper::GetSellCharacterExpLumicubeByGrade(ItemIconInfo.Grade);
		}
		else
		{
			TotalLumicube = SystemConstHelper::GetSellCharacterLumicubeByGrade(ItemIconInfo.Grade) * ItemIconInfo.UltSkillLevel;
		}
	}
	else if (ItemIconInfo.AttributeType == EAttributeCategory::Sculpture)
	{
		const FCMSSculptureRow& SculptureRow = GetCMS()->GetSculptureRowOrDummy(FSculptureType(ItemIconInfo.Type));
		if (SculptureRow.IsInvalid())
		{
			Q6JsonLogGunny(
				Warning,
				"USellShopWidget::CalculateLumicube - SculptureRow does not exist.",
				Q6KV("SculptureType", ItemIconInfo.Type));
			return 0;
		}

		if (SculptureRow.XpExclusive)
		{
			TotalLumicube = SystemConstHelper::GetSellSculptureExpLumicubeByGrade(ItemIconInfo.Grade);
		}
		else
		{
			TotalLumicube = SystemConstHelper::GetSellSculptureLumicubeByGrade(ItemIconInfo.Grade) * ItemIconInfo.Tier;
		}
	}
	else if (ItemIconInfo.AttributeType == EAttributeCategory::Relic)
	{
		const FCMSRelicRow& RelicRow = GetCMS()->GetRelicRowOrDummy(FRelicType(ItemIconInfo.Type));
		if (RelicRow.IsInvalid())
		{
			Q6JsonLogGunny(
				Warning,
				"USellShopWidget::CalculateLumicube - RelicRow does not exist.",
				Q6KV("CharacterType", ItemIconInfo.Type));
			return 0;
		}

		if (RelicRow.XpExclusive)
		{
			TotalLumicube = SystemConstHelper::GetSellRelicExpLumicubeByGrade(ItemIconInfo.Grade);
		}
		else
		{
			TotalLumicube = SystemConstHelper::GetSellRelicLumicubeByGrade(ItemIconInfo.Grade) * ItemIconInfo.Tier;
		}
	}

	return TotalLumicube;
}

void USellShopWidget::UnselectItemCards()
{
	for (UItemCardWidget* Iter : SelectedItemCardWidget)
	{
		Iter->SetSelected(false);
	}

	SelectedItemCardWidget.Empty();
	SelectLockSwitcherWidget->SetSelectedCount(0, NumOfCard);
	SellPoint1Widget->SetCurPoint(0);
	SellPoint2Widget->SetCurPoint(0);
}

void USellShopWidget::OnSellButtonClicked()
{
	USellShopPurchasePopupWidget* SellShopPurchasePopupWidget = GetCheckedLobbyHUD(this)->OpenSellShopPurchasePopupWidget();

	SellShopPurchasePopupWidget->SetList(ItemListWidget, SellShopCategory);
	SellShopPurchasePopupWidget->SetGoldAndLumicube(SellPoint1Widget->GetCurPoint(), SellPoint2Widget->GetCurPoint());
}

void USellShopWidget::OnAllRemoveButtonClicked()
{
	UnselectItemCards();
	SellButton->SetIsEnabled(false);
	AllRemoveButton->SetIsEnabled(false);
}

/*
* SellShopPurchasePopupWidgetBP
*/

USellShopPurchasePopupWidget::USellShopPurchasePopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SellShopCategory(ELootCategory::None)
{

}

void USellShopPurchasePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SetTitle(Q6Util::GetLocalizedText("Popup","SellShopPurchaseTitle"));
	SetYesButtonEnabled(true);

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
	SellPoint1Widget = CastChecked<UPointWidget>(GetWidgetFromName("SellPoint1"));
	SellPoint1Widget->SetPointType(ECurrencyType::Gold, EPointWidgetOption::NONE);

	SellPoint2Widget = CastChecked<UPointWidget>(GetWidgetFromName("SellPoint2"));
	SellPoint2Widget->SetPointType(ECurrencyType::Lumicube, EPointWidgetOption::NONE);
}

ELootCategory ConvertInventoryTypeToLootCategory(EInventoryType InventoryType)
{
	switch (InventoryType)
	{
		case EInventoryType::Character:
			return ELootCategory::CharacterCard;
		case EInventoryType::Sculpture:
			return ELootCategory::SculptureCard;
		case EInventoryType::Relic:
			return ELootCategory::RelicCard;
		default:
			Q6JsonLogGunny(Warning, "ConvertInventoryTypeToLootCategory - InventoryType is invalid");
			return ELootCategory::None;
	}
}

void USellShopPurchasePopupWidget::SetList(UDynamicListWidget* InItemList, EInventoryType InSellShopCategory)
{
	ItemListWidget->ClearList();
	SellShopCategory = ConvertInventoryTypeToLootCategory(InSellShopCategory);

	for (int i = 0; i < InItemList->GetChildrenCount(); ++i)
	{
		UItemCardWidget* ItemCardWidget = CastChecked<UItemCardWidget>(InItemList->FindChildAt(i));
		if (ItemCardWidget->GetSelectedType() != EItemSelectType::Selected)
		{
			continue;
		}

		const UHUDStore& HUDStore = GetHUDStore();
		const FItemIconInfo& ItemIconInfo = ItemCardWidget->GetItemInfo();
		if (ItemIconInfo.AttributeType == EAttributeCategory::Character)
		{
			const FCharacter* Character = HUDStore.GetCharacterManager().Find(FCharacterId(ItemIconInfo.Id));
			if (!Character)
			{
				Q6JsonLogGunny(
					Warning,
					"USellShopPurchasePopupWidget::SetList - CharacterId does not exist.",
					Q6KV("CharacterId", ItemIconInfo.Id));
				continue;
			}

			const FCharacterInfo& CharacterInfo = Character->GetInfo();

			if ((CharacterInfo.Grade >= EItemGrade::SR) ||
				CharacterInfo.Level == SystemConstHelper::GetCharacterMaxLevel(CharacterInfo.Star, CharacterInfo.Moon))
			{
				SetContentVisibility(ESlateVisibility::SelfHitTestInvisible);
			}
			else
			{
				SetContentVisibility(ESlateVisibility::Collapsed);
			}

			UItemCardWidget* NewItemCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
			NewItemCardWidget->SetCharacter(CharacterInfo);
			NewItemCardWidget->SetChecked(false);
		}
		else if (ItemIconInfo.AttributeType == EAttributeCategory::Sculpture)
		{
			const FSculpture* Sculpture = HUDStore.GetSculptureManager().Find(FSculptureId(ItemIconInfo.Id));
			if (!Sculpture)
			{
				Q6JsonLogGunny(
					Warning,
					"USellShopPurchasePopupWidget::SetList - SculptureId does not exist.",
					Q6KV("SculptureId", ItemIconInfo.Id));
				continue;
			}

			const FSculptureInfo& SculptureInfo = Sculpture->GetInfo();
			if ((SculptureInfo.Grade >= EItemGrade::SR) ||
				SculptureInfo.Level == SystemConstHelper::GetEquipMaxLevel(SculptureInfo.Star))
			{
				SetContentVisibility(ESlateVisibility::SelfHitTestInvisible);
			}
			else
			{
				SetContentVisibility(ESlateVisibility::Collapsed);
			}

			UItemCardWidget* NewItemCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
			NewItemCardWidget->SetSculpture(SculptureInfo);
			NewItemCardWidget->SetChecked(false);
		}
		else if (ItemIconInfo.AttributeType == EAttributeCategory::Relic)
		{
			const FRelic* Relic = HUDStore.GetRelicManager().Find(FRelicId(ItemIconInfo.Id));
			if (!Relic)
			{
				Q6JsonLogGunny(
					Warning,
					"USellShopPurchasePopupWidget::SetList - RelicId does not exist.",
					Q6KV("RelicId", ItemIconInfo.Id));
				continue;
			}

			const FRelicInfo& RelicInfo = Relic->GetInfo();
			if ((RelicInfo.Grade >= EItemGrade::SR) ||
				RelicInfo.Level == SystemConstHelper::GetEquipMaxLevel(RelicInfo.Star))
			{
				SetContentVisibility(ESlateVisibility::SelfHitTestInvisible);
			}
			else
			{
				SetContentVisibility(ESlateVisibility::Collapsed);
			}

			UItemCardWidget* NewItemCardWidget = CastChecked<UItemCardWidget>(ItemListWidget->AddChildAtLastIndex());
			NewItemCardWidget->SetRelic(RelicInfo);
			NewItemCardWidget->SetChecked(false);
		}
	}
}

void USellShopPurchasePopupWidget::SetGoldAndLumicube(int32 InGold, int32 InLumicube)
{
	SellPoint1Widget->SetCurPoint(InGold);
	SellPoint2Widget->SetCurPoint(InLumicube);
}

void USellShopPurchasePopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	if (Option == EConfirmPopupFlag::Yes)
	{
		const UShopManager& ShopManager = GetHUDStore().GetShopManager();

		TArray<int64> BuyItemList;
		for (int i = 0; i < ItemListWidget->GetChildrenCount(); ++i)
		{
			const UItemCardWidget* ItemCard = CastChecked<UItemCardWidget>(ItemListWidget->FindChildAt(i));
			const FItemIconInfo& ItemIconInfo = ItemCard->GetItemInfo();
			BuyItemList.Add(ItemCard->GetItemId());
		}

		ShopManager.ReqSellItem(SellShopCategory, BuyItemList);
	}

	ClosePopup();
}

UGeneralShopPurchasePopupWidget::UGeneralShopPurchasePopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, PurchaseAmount(1)
{

}

void UGeneralShopPurchasePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	PlusButton = CastChecked<UButton>(GetWidgetFromName("Plus"));
	PlusButton->OnClicked.AddUniqueDynamic(this, &UGeneralShopPurchasePopupWidget::OnPlusButtonClicked);

	MinusButton = CastChecked<UButton>(GetWidgetFromName("Minus"));
	MinusButton->OnClicked.AddUniqueDynamic(this, &UGeneralShopPurchasePopupWidget::OnMinusButtonClicked);

	ShopEntryWidget = CastChecked<UShopEntryWidget>(GetWidgetFromName("ShopItem"));
	OwnedPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPoint"));
	RequirePointWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequirePoint"));
	StocksText = CastChecked<UTextBlock>(GetWidgetFromName("Stocks"));
}

void UGeneralShopPurchasePopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Option)
{
	if (Option == EConfirmPopupFlag::Yes)
	{
		const UShopManager& ShopManager = GetHUDStore().GetShopManager();
		ShopManager.ReqBuyItem(ShopEntryWidget->GetShopType(), PurchaseAmount);
	}

	// init purchase amount, when popup widget closed
	PurchaseAmount = 1;

	ClosePopup();
}

void UGeneralShopPurchasePopupWidget::RefreshCost()
{
	FShopType ShopType = ShopEntryWidget->GetShopType();

	const UHUDStore& HUDStore = GetHUDStore();
	const UShopManager& ShopManager = HUDStore.GetShopManager();

	int32 LeftCount = ShopManager.GetStocks(EShopBuyType::None, ShopType);

	const FItemData& CostItemData = ShopEntryWidget->GetCostItemData();
	const UWorldUser& WorldUser = HUDStore.GetWorldUser();

	ECurrencyType CurrencyType = GetCurrencyType(CostItemData.Category);

	int32 OwnedPoint = 0;
	if (CurrencyType != ECurrencyType::None)
	{
		OwnedPoint = WorldUser.GetOwnedCurrency(CurrencyType);
	}
	else
	{
		if (CostItemData.Category == ELootCategory::BagItem)
		{
			const UBagItemManager& BagItemManager = GetHUDStore().GetBagItemManager();
			OwnedPoint = BagItemManager.GetBagItemCount(FBagItemType(CostItemData.Type));
		}
		else if (CostItemData.Category == ELootCategory::EventPoint)
		{
			const UEventManager& EventManager = GetHUDStore().GetEventManager();
			TArray<int32> EventPoints = EventManager.GetEventPoint(ShopEntryWidget->GetEventContentType());

			for (int i = 1; i < EventPoints.Num(); ++i)
			{
				if (CostItemData.Type == i)
				{
					OwnedPoint = EventPoints[i];
				}
			}
		}
		else
		{
			Q6JsonLogGunny(
				Warning,
				"UGeneralShopPurchasePopupWidget::RefreshCost - CostItemData is not Currency(or BagItem).",
				Q6KV("CostItemData.Category", static_cast<int32>(CostItemData.Category)));
		}
	}

	bool bHasEnoughCurrentAmount = (OwnedPoint >= CostItemData.Count * PurchaseAmount)
		&& (LeftCount >= PurchaseAmount);

	bool bHasEnoughNextAmount = (OwnedPoint >= CostItemData.Count * (PurchaseAmount + 1))
		&& (LeftCount >= (PurchaseAmount + 1));

	SetYesButtonEnabled(bHasEnoughCurrentAmount);

	StocksText->SetText(FText::AsNumber(PurchaseAmount));
	PlusButton->SetIsEnabled(bHasEnoughNextAmount);
	MinusButton->SetIsEnabled(PurchaseAmount > 1);

	if (CostItemData.Category == ELootCategory::EventPoint)
	{
		OwnedPointWidget->SetEventPointType(ShopEntryWidget->GetEventContentType(), CostItemData.Type, EPointWidgetOption::NONE);
		RequirePointWidget->SetEventPointType(ShopEntryWidget->GetEventContentType(), CostItemData.Type, EPointWidgetOption::LessEqual);
	}
	else
	{
		OwnedPointWidget->SetPointType(CurrencyType, EPointWidgetOption::NONE);
		RequirePointWidget->SetPointType(CurrencyType, EPointWidgetOption::LessEqual);
	}
	OwnedPointWidget->SetCurPoint(OwnedPoint);
	RequirePointWidget->SetPoint(CostItemData.Count * PurchaseAmount, OwnedPoint);
}

void UGeneralShopPurchasePopupWidget::SetShopEntryWidget(const UShopEntryWidget* InShopEntryWidget)
{
	ShopEntryWidget->Duplicate(InShopEntryWidget);

	RefreshCost();
}

void UGeneralShopPurchasePopupWidget::OnPlusButtonClicked()
{
	PurchaseAmount++;
	RefreshCost();
}

void UGeneralShopPurchasePopupWidget::OnMinusButtonClicked()
{
	PurchaseAmount--;
	RefreshCost();
}

UGemShopPurchasePopupWidget::UGemShopPurchasePopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UGemShopPurchasePopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	OwnedFreeGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedFreeGem"));
	OwnedPaidGemWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPaidGem"));
	GemShopListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("GemShopList"));

	UButton* CancelButton = CastChecked<UButton>(GetWidgetFromName("Cancel"));
	CancelButton->OnClicked.AddUniqueDynamic(this, &UGemShopPurchasePopupWidget::OnCancelButtonClicked);
}

void UGemShopPurchasePopupWidget::SetInfo()
{
	SetTitle(Q6Util::GetLocalizedText("Popup", "GemShopPurchaseTitle"));
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	OwnedFreeGemWidget->SetPointType(EPointType::FreeGem, EPointWidgetOption::NONE);
	OwnedFreeGemWidget->SetCurPoint(WorldUser.GetFreeGem());
	OwnedPaidGemWidget->SetPointType(EPointType::PaidGem, EPointWidgetOption::NONE);
	OwnedPaidGemWidget->SetCurPoint(WorldUser.GetPaidGem());

	GemShopListWidget->ClearList();

	// Gunny Tempcode
	// GemList does not developed
	UShopGemItemWidget* ShopGemItemWidget = CastChecked<UShopGemItemWidget>(GemShopListWidget->AddChildAtLastIndex());
	ShopGemItemWidget->SetGem(10, 2, 32000);
}

void UGemShopPurchasePopupWidget::OnCancelButtonClicked()
{
	ClosePopup();
}

