// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "GameResource.h"
#include "Tutorial/LobbyTutorial.h"
#include "UMG.h"

#include "TutorialWidget.generated.h"

class URichTextBlock;

/**
 * Tutorial Widget
 */
UCLASS()
class Q6_API UTutorialWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	void InitTutorialWidget(bool bShowHall);

	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime);

	virtual FReply NativeOnFocusReceived(const FGeometry& InGeometry, const FFocusEvent& InFocusEvent) override;

	virtual FReply NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual FReply NativeOnPreviewMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual FReply NativeOnMouseButtonUp(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual FReply NativeOnMouseMove(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;

	virtual FReply NativeOnTouchGesture(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;
	virtual FReply NativeOnTouchStarted(const FGeometry& InGeokmetry, const FPointerEvent& InGestureEvent) override;
	virtual FReply NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;
	virtual FReply NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;

	UFUNCTION(BlueprintCallable, Category = "Q6")
	void ShowHole(FString HoleName);

	UFUNCTION(BlueprintCallable, Category = "Q6")
	void BlockScreen();

private:

	void InitTutorialWidgetInternal(UWidget* HoleWidget, bool bShowHall);
	void SetDeferredHoleInternal(const FString& InHoleName);

	UFUNCTION()
	void OnDimmingButtonClicked();

	void CountTouch();

	void SetProtection(bool bInProtect);

	UPROPERTY()
	UButton* DimmingButtons[4];

	UPROPERTY()
	int32 TouchCount;

	UPROPERTY()
	int32 DeferredHoleTickCount;

	UPROPERTY()
	FString DeferredHoleName;
};

const static int32 MAX_TUTORIAL_STEP = 100;

/**
* Tutorial Entry Widget
*/
UCLASS()
class Q6_API UTutorialEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	virtual void NativeConstruct() override;

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial Util")
	void Start();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial Util")
	void OnPaused();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial Util")
	void OnEnded();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial Util")
	void OnResumed();

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	void Proceed();

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	void ReserveLobbyTutorialOnInit(ELobbyTutorial InTutorialStep, int32 InStep);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	void EndCurrentTutorial();

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	void JumpToStep(int32 InStep);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	FTutorialGuideAssetRow GetTutorialGuideAsset(FString KeyString) const;
};

/**
* TutorialsWidget that has many TutorialWidgets
*/
UCLASS()
class Q6_API UTutorialsWidget : public UUserWidget
{
	GENERATED_BODY()

public:

	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	void ProceedStep(FString InSource);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	void SetStep(int32 InStep);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial Util")
	void PauseStep();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial Util")
	bool BlockProceedStepOrNot(int32 InStep, FName InSource);

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial Util")
	bool CanResumeTutorial(int32 InStep, FName InSource);

	FSimpleDelegate& GetEndTutorialsDelegate();

private:

	FSimpleDelegate EndTutorialsDelegate;

	void EndTutorials();
	void RefreshUIByStep(int32 InNewStep);

	UPROPERTY()
	TArray<UTutorialEntryWidget*> Entries;

	UPROPERTY()
	int32 MaxStep;

	UPROPERTY()
	int32 CurrentStep;

	UPROPERTY()
	bool bPaused;
};

/**
* TutorialsWidget that has many TutorialWidgets
*/

UCLASS()
class Q6_API UTutorialCaptureWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	UFUNCTION(BlueprintCallable, Category = "Q6")
	void BindCapture(int32 InTutorialDialogue);

	UFUNCTION(BlueprintCallable, Category = "Q6")
	void BindGuideCapture(int32 InGuideDialogue);

	UFUNCTION(BlueprintCallable, Category = "Q6")
	void BindBreakdownCapture(FText InSpeaker, FText InBubble, int32 InCaptureModelType);

	UFUNCTION(BlueprintCallable, Category = "Q6")
	void OnCaptureVisibleStateChangedBP(bool bVisible);

	void SetGuideInfo(const FRewardStep& RewardStep);

	FBoolParamDelegate OnGuideBtnClickedDelegate;

private:
	UFUNCTION()
	void OnYesButtonClicked();

	UFUNCTION()
	void OnNoButtonClicked();

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	class UTextBlock* NameText;

	UPROPERTY()
	class URichTextBlock* DialogueText;

	int32 TutorialDialogue;
	bool VisibleState:1;
	bool Icon3DMode:1;
};