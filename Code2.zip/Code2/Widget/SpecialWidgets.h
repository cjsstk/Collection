// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

#include "SpecialWidgets.generated.h"

enum class EStageState : uint8;

class UDynamicListWidget;
class UQ6Button;

USTRUCT()
struct FWonderStageInfo
{
	GENERATED_BODY()

	FWonderStageInfo() : 
		SagaType(SagaTypeInvalid),
		SpecialCategory(ESpecialCategory::None),
		ClearCount(0),
		ReplayLimit(0)
	{}

	FWonderStageInfo(
		FSagaType InSagaType,
		ESpecialCategory InSpecialCategory,
		EStageState InStageState,
		int32 InClearCount,
		int32 InReplayLimit) :
		SagaType(InSagaType),
		SpecialCategory(InSpecialCategory),
		StageState(InStageState),
		ClearCount(InClearCount),
		ReplayLimit(InReplayLimit)
	{}

	FSagaType SagaType;
	ESpecialCategory SpecialCategory;
	EStageState StageState;
	int32 ClearCount;
	int32 ReplayLimit;
};

UCLASS()
class Q6_API USpecialMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetSpecialStageMenu(ESpecialCategory InCategory);

	UFUNCTION(BlueprintImplementableEvent)
	void SetSpecialMenuWidgetContentState(bool bLocked);

	FSimpleDelegate OnMenuClickedDelegate;

private:
	// Events

	UFUNCTION()
	void OnMenuButtonClicked();

	// Animations

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> MenuAnims;

	// Widgets
	UPROPERTY()
	UQ6Button* MenuButton;

	UPROPERTY()
	UImage* TagImage;

	ESpecialCategory Category;
};

UCLASS()
class Q6_API USpecialEpisodeEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetCharacterEpisode(const FCMSSpecialRow& SpecialRow);
	void SetWonderEpisode(EWonderCategory WonderCategory);

	FSimpleDelegate OnEpisodeSelectedDelegate;

private:
	// Events
	UFUNCTION()
	void OnSelectButtonClicked();

	// Widgets

	UPROPERTY()
	UButton* SelectButton;

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UImage* TagImage;

	UPROPERTY()
	UTextBlock* NameText;
};

UCLASS()
class Q6_API USpecialStageListWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetSpecialStage(ESpecialCategory Category);

private:
	EStageState GetStageState(const FSpecialStage& SpecialStage, int32 ReplayLimit, bool bOpen);
	bool IsSpecialStageOpened(FSagaType InSagaType) const;

	void SetBossStage();
	void SetCharacterStage(const FSpecialType& SpecialType);
	void SetWonderStage(EWonderCategory WonderCategory);

	void AddToWonderStageInfos(
		TArray<FSpecialStage>& SpecialStages,
		int32 Episode,
		int32 ReplayLimit,
		ESpecialCategory SpecialCategory,
		TArray<FWonderStageInfo>& OutWonderStageInfos);
	void AddToWonderStageList(const FWonderStageInfo& InSpecialStageInfo);

	void AddToStageList(TArray<FSpecialStage>& SpecialStages, int32 Episode, int32 ReplayLimit, ESpecialCategory SpecialCategory);

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* CharacterBannerAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SagaBannerAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* WonderBannerAnim;

	// Widgets

	UPROPERTY()
	UItemWidget* EpisodeReward;

	UPROPERTY()
	UImage* BannerImage;

	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	UTextBlock* DescriptionText;

	UPROPERTY()
	UDynamicListWidget* StageListWidget;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush SpecialEpisodeBannerBrush;
};

UCLASS()
class Q6_API USpecialWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void RefreshMenu() override;

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Special; }

private:
	void SetSpecialMenu();
	void SetEpisode(ESpecialCategory Category);
	void SetCharacterEpisodeList();
	void SetWonderEpisodeList();

	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	UFUNCTION()
	void OnSpecialMenuClicked(ESpecialCategory Category);

	void OnCharacterEpisodeSelected(FSpecialType SpecialType);
	void OnWonderEpisodeSelected(EWonderCategory WonderCategory);

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	TArray<USpecialMenuWidget*> MenuWidgets;

	UPROPERTY()
	UDynamicListWidget* EpisodeListWidget;

	UPROPERTY()
	USpecialStageListWidget* StageListWidget;
};
