// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseWidget.h"
#include "Q6Define.h"
#include "UMG.h"
#include "SwipeWidgets.generated.h"

class UDynamicEntryBox;
class SScrollBox;

enum class EDirection : uint8
{
	None,
	Left,
	Right
};

DECLARE_DELEGATE_TwoParams(FOnSetPageDelegate, UWidget* /*ViewWidget*/, int32 /*PageNum*/)

UCLASS()
class Q6_API UPageIndicatorIconWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPageIndicatorIconWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetFocused(bool bIsFocused);

private:
	UPROPERTY()
	UImage* EnabledImage;
};


/**
 * SSwipeScrollBox use only in USwipeScrollBox
 */
class Q6_API SSwipeScrollBox : public SScrollBox
{
public:
	virtual FReply OnMouseMove(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
};

/**
 * USwipeScrollBox use only in UPageSwipeWidget
 */
UCLASS()
class Q6_API USwipeScrollBox : public UScrollBox
{
	GENERATED_BODY()

public:
	bool IsScrolling() const;

protected:
	//~ Begin UWidget Interface
	virtual TSharedRef<SWidget> RebuildWidget() override;
	//~ End UWidget Interface
};


UCLASS()
class Q6_API UBasePageSwipeWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UBasePageSwipeWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime);
	virtual FReply NativeOnPreviewMouseButtonDown(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) override;
	virtual FReply NativeOnMouseMove(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;
	virtual FReply NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;
	virtual void NativeOnMouseLeave(const FPointerEvent& InMouseEvent) override;
	virtual FReply NativeOnMouseButtonUp(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent) override;
	virtual FReply NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent) override;

	virtual void InitPages(int32 InFocusingPage);
	virtual UWidget* GetPage(int32 PageNumber) { return nullptr; }

	void SetSwipeEnabled(bool bInEnabled);
	void SetFocusPage(int32 InFocusingPage, bool AnimateScroll = true);
	void SetIndicatorVisible(bool bInVisible);
	void SetChildSlotPadding(const FMargin& InPadding);

	int32 GetPageCount() { return (int32)PageCount; }
	UWidget* GetFocusedWidget();

	void OnSwipe(EDirection Direction);

	FOnSetPageDelegate OnSetPageDelegate;
	FIntParamDelegate OnFocusedPageDelegate;

protected:
	virtual void ArrangeViewWidgets() {}
	virtual void OnSwipeFinished();

	void SetOrderedPageList(const TArray<int32>& InOrderedPageList);
	bool GetPageListFromOrderedList(uint32 FocusedPage, TArray<uint32>& SlotList);
	void GetPageList(uint32 FocusedPage, TArray<uint32>& SlotList);
	uint32 GetFocusedSlot(EDirection Direction);

	UPROPERTY()
	UUniformGridPanel* PageGridPanel;

	UPROPERTY()
	TArray<UWidget*> ViewWidgets;

	UPROPERTY()
	USwipeScrollBox* PageScrollBox;

	UPROPERTY()
	UDynamicEntryBox* IndicatorBox;

	// Fields

	UPROPERTY(EditInstanceOnly)
	bool bIndicatorVisible;

	UPROPERTY(EditInstanceOnly)
	FMargin ChildSlotPadding;

	UPROPERTY()
	uint32 ViewPageCount;

	UPROPERTY()
	uint32 PageCount;

	UPROPERTY()
	int32 FocusingPage;

	EDirection SwipingDirection;

	uint32 FocusedSlot;

	TArray<uint32> OrderedPageList;

private:
	void SetViewPageCount(uint32 InPageCount);

	void ChangeFocusPage(bool bIncreaseDirection);
	int32 IncFocusPage(bool bIncreaseDirection);

	bool SwipeEnded();
	FReply SwipeMoved(const FPointerEvent& InGestureEvent);

	UFUNCTION()
	void OnNextButtonClicked();

	UFUNCTION()
	void OnPrevButtonClicked();

	UPROPERTY(EditAnywhere)
	float SwipeDetectDistance;

	UPROPERTY(EditDefaultsOnly)
	float SwipeDetectSpeed;

	UPROPERTY()
	UNamedSlot* IndicatorSlot;

	UPROPERTY()
	UButton* NextButton;

	UPROPERTY()
	UButton* PrevButton;

	FInertialScrollManager SwipeInertial;

	float StartedPosX;
	bool bTouched;
	bool bSwipeEnabled;
};


UCLASS()
class Q6_API UPageSwipeWidget : public UBasePageSwipeWidget
{
	GENERATED_BODY()

public:
	UPageSwipeWidget(const FObjectInitializer& ObjectInitializer);

	virtual void InitPages(int32 InFocusingPage) override;
	virtual UWidget* GetPage(int32 PageNumber) override;

	void SetPageCount(uint32 InPageCount, int32 InFocusingPage);
	void SetPageCount(const TArray<int32>& InOrderedPageList, int32 InFocusingPage);

protected:
	virtual void ArrangeViewWidgets() override;
	virtual void OnSwipeFinished() override;

	UPROPERTY(EditInstanceOnly)
	TAssetSubclassOf<UWidget> PageWidgetClass;
};


UCLASS()
class Q6_API UVarietyPageSwipeWidget : public UBasePageSwipeWidget
{
	GENERATED_BODY()

public:
	UVarietyPageSwipeWidget(const FObjectInitializer& ObjectInitializer);

	virtual void InitPages(int32 InFocusingPage) override;
	virtual UWidget* GetPage(int32 PageNumber) override;

	void SetPageWidgetClasses(const TArray<TAssetSubclassOf<UWidget>>& WidgetClasses, int32 InFocusingPage);

protected:
	virtual void ArrangeViewWidgets() override;
	virtual void OnSwipeFinished() override;

	UPROPERTY(EditInstanceOnly)
	TArray<TAssetSubclassOf<UWidget>> PageWidgetClasses;

private:
	UWidget* FindOrAddPageWidget(TAssetSubclassOf<UWidget> PageWidgetClass);

	UPROPERTY()
	TArray<UWidget*> PageWidgets;
};
