// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "LoadingScreenWidget.h"
#include "Q6.h"
#include "Engine/UserInterfaceSettings.h"
#include "Slate/SlateBrushAsset.h"
#include "Slate/SlateGameResources.h"
#include "Blueprint/WidgetBlueprintLibrary.h"
#include "Widgets/Layout/SDPIScaler.h"

ULoadingScreenWidget::ULoadingScreenWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{}

void ULoadingScreenWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UTextBlock* TooltipTextBlock = CastChecked<UTextBlock>(GetWidgetFromName("LoadingTooltip"));
	if (TooltipTextBlock)
	{
		TooltipTextBlock->SetText(LoadingTooltip);
	}
}

void ULoadingScreenWidget::AddToScreen(ULocalPlayer* LocalPlayer, int32 ZOrder)
{
	Super::AddToScreen(LocalPlayer, ZOrder);
}

void ULoadingScreenWidget::SetTipText(FText TipText)
{
	LoadingTooltip = TipText;
}
