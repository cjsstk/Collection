// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "MediaPlayerWidget.h"

#include "Q6.h"
#include "Q6Log.h"
#include "PopupWidgets.h"
#include "WidgetUtil.h"
#include "MediaPlayer.h"
#include "FileMediaSource.h"

UMediaPlayerWidget::UMediaPlayerWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UMediaPlayerWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

UMediaPlayer* UMediaPlayerWidget::GetMediaPlayer() const
{
	return MediaPlayer;
}

bool UMediaPlayerWidget::OpenSource(UFileMediaSource* MediaSource, FSimpleDelegate InFinishedCallback)
{
	if (!GetMediaPlayer())
	{
		return false;
	}

	OnMediaPlayFinished.Clear();

	if (InFinishedCallback.IsBound())
	{
		OnMediaPlayFinished.Add(InFinishedCallback);
	}

	GetMediaPlayer()->OnMediaOpened.Clear();
	GetMediaPlayer()->OnMediaOpened.AddUniqueDynamic(this, &UMediaPlayerWidget::OnMediaOpened);

	GetMediaPlayer()->OnEndReached.Clear();
	GetMediaPlayer()->OnEndReached.AddUniqueDynamic(this, &UMediaPlayerWidget::OnMediaFinished);

	FMediaPlayerOptions PlayerOption;
	PlayerOption.Loop = EMediaPlayerOptionBooleanOverride::Disabled;
	PlayerOption.PlayOnOpen = EMediaPlayerOptionBooleanOverride::Disabled;

	if (!GetMediaPlayer()->OpenSourceWithOptions(MediaSource, PlayerOption))
	{
		OnMediaPlayFinished.Clear();
		GetMediaPlayer()->OnMediaOpened.Clear();
		GetMediaPlayer()->OnEndReached.Clear();
		return false;
	}

	RemoveFromParent();
	AddToViewport(ZORDER_MEDIA_PLAYER);
	return true;
}

void UMediaPlayerWidget::OnMediaFinished()
{
	OnMediaPlayFinished.Broadcast();
	OnMediaPlayFinished.Clear();


	GetMediaPlayer()->OnMediaOpened.Clear();
	GetMediaPlayer()->OnEndReached.Clear();
	RemoveFromParent();
}

void UMediaPlayerWidget::OnMediaOpened(FString OpenedUrl)
{
	OnMediaOpenedInitialize();

	GetMediaPlayer()->Rewind();
	GetMediaPlayer()->Play();
}

void UMediaPlayerWidget::CloseMediaPlayer()
{
	if (!GetMediaPlayer())
	{
		return;
	}

	GetMediaPlayer()->Close();
	OnMediaFinished();
}