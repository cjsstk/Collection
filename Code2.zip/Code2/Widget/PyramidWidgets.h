// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "PopupWidgets.h"
#include "Q6Define.h"
#include "WonderWidgets.h"

#include "PyramidWidgets.generated.h"

class UItemCardWidget;
class UMaterialBoxWidget;
class UPointWidget;
class UBoostConfirmPopupWidget;
class UItemSelectPopupWidget;
class UPortalConnectConfirmPopupWidget;
class UQ6TextBlock;

enum class EPortalType : uint8;

enum class EPortalState : uint8
{
	Building = 0,
	Built = 1,
	Connecting = 2,
	Connected = 3,
};

UCLASS()
class Q6_API UPortalWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPortal(EPortalType InPortalType, int64 InConnectedType);
	void SetSelected(bool bInSelected);

	void PlayBoostAnimation() { PlayAnimation(BuildBoostAnim); }

	FInt64ParamDelegate OnPortalSelectedDelegate;

private:
	void SetPortalState(EPortalState PortalState);
	void SetItem(EPortalType PortalType, int64 InConnectedType);
	void SetNewMark(EPortalType PortalType);

	const FSlateBrush& GetPortalBrush(EPortalType InPortalType, EPortalState InPortalState);

	UFUNCTION()
	void OnSelectButtonClicked();

	// Widgets

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* StateText;

	UPROPERTY()
	UQ6TextBlock* RemainDaysText;

	UPROPERTY()
	UItemCardWidget* ItemWidget;

	UPROPERTY()
	UImage* NewMarkImage;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* BuildingAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SelectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DeselectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BuildBoostAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BuiltLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ConnectingAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ConnectedLoopAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> CharacterPortalBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> RelicPortalBrushes;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> SculpturePortalBrushes;

	EPortalState PortalState;
	int64 ConnectedType;
};


UCLASS()
class Q6_API UPortalInfoWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void NativeConstruct();

	void SetPortal(EPortalType InPortalType, int64 InConnectedType);

private:
	void SetItemNameAndTexture();

	void OnItemSelected(int64 InSelectedItemId);

	UFUNCTION()
	void OnSelectButtonClicked();

	UFUNCTION()
	void OnPortalButtonClicked();

	UFUNCTION()
	void OnPortalConnect(EConfirmPopupFlag Flag);

	// Widgets
	UPROPERTY()
	UImage* PortalImage;

	UPROPERTY()
	UImage* EquipImage;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* LeadDaysText;

	UPROPERTY()
	UQ6TextBlock * PortalTitleText;

	UPROPERTY()
	UQ6TextBlock* PortalInfoText;

	UPROPERTY()
	UQ6TextBlock* SelectText;

	UPROPERTY()
	UQ6TextBlock* ConnectText;

	UPROPERTY()
	UQ6TextBlock* RemainDaysText;

	// Animations
	
	UPROPERTY(Transient)
	UWidgetAnimation* BuiltLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ConnectAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ConnectingAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* ConnectedLoopAnim;

	// Fields
	
	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPortalConnectConfirmPopupWidget> PortalConnectConfirmPopupClass;

	UPROPERTY(EditDefaultsOnly)
	TArray<FSlateBrush> PortalBuiltBrushes;

	UPROPERTY(EditDefaultsOnly)
	FSlateBrush ConnectedBrush;

	EPortalType PortalType;
	int64 ConnectedType;
	int64 SelectedItemId;
};


UCLASS()
class Q6_API UPortalBuildBoostWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	void NativeConstruct();

	void SetBuildBoost(EPortalType InPortalType);

private:
	void PlayBuildBoostAnimation(int32 TotalRemainBoostCount, int32 DailyRemainBoostCount);

	UFUNCTION()
	void OnBoostButtonClicked();

	UFUNCTION()
	void OnItemListButtonClicked();

	// Widgets

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* PortalInfoText;

	UPROPERTY()
	UQ6TextBlock* ItemListText;

	UPROPERTY()
	UQ6TextBlock* RemainDaysText;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UPointWidget* OwnedPointWidget;

	UPROPERTY()
	UPointWidget* RequirePointWidget;

	UPROPERTY()
	UQ6TextBlock* BoostRemainCountText;

	UPROPERTY()
	UButton* BoostButton;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* DefaultAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DailyBuildBoostUsedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BuildBoostMaxAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UBoostConfirmPopupWidget> BuildBoostConfirmPopupClass;

	EPortalType PortalType;
};


UCLASS()
class Q6_API UPyramidWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void SetWonder() override;
	virtual void RefreshUI() override;

	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) override;

private:
	void SetPortalBoostUse(EPortalType PortalType);

	void SetPortal(EPortalType PortalType, int32 ConnectedType);
	void SelectPortal(int32 InSelectedIdx);

	void SetSelectedPortalDetail(EPortalType PortalType, int64 ConnectedType);

	UPortalWidget* GetCheckedPortalWidget(EPortalType PortalType);

	void OnPortalSelected(int64 ConnectedType, EPortalType PortalType);

	// Widgets

	UPROPERTY()
	TArray<UPortalWidget*> PortalWidgets;

	UPROPERTY()
	UWidgetSwitcher* PortalMenuSwitcher;

	UPROPERTY()
	UPortalBuildBoostWidget* BoostWidget;

	UPROPERTY()
	UPortalInfoWidget* InfoWidget;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UPortalConnectedResultPopupWidget> PortalConnectedResultPopupClass;

	int32 SelectedPortalIndex;
};
