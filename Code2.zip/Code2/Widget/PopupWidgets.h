// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseWidget.h"
#include "Q6Define.h"
#include "UMG.h"
#include "WidgetUtil.h"
#include "CMSType_gen.h"
#include "LobbyObj_gen.h"
#include "PopupWidgets.generated.h"

static const int32 PopupOrderInvalid = -1;
static const float RaidJoinPopupCloseTime = 60.f;

class UDynamicListWidget;
class UItemCardWidget;
class UItemLevelWidget;
class UItemWidget;
class UMaterialBoxWidget;
class UPartyMemberListWidget;
class UPointWidget;
class UToggleButtonWidget;
class UQ6TextBlock;
class URichTextBlock;
class UUpgradeResultTierWidget;
class UWonderUpgradeLevelEffectWidget;
class USummonHUD;
class UToggleButtonBoxWidget;
class UWonderProduceWidget;
class UItemDropListWidget;

struct FCharacterInfo;
struct FItemData;
struct FRelicId;

enum class EUpgradeCharacterCategory : uint8;
enum class EPortalType : uint8;

USTRUCT()
struct FSimpleLootData
{
	GENERATED_USTRUCT_BODY()

	FSimpleLootData() : LootCategory(ELootCategory::None), Value(0) {}
	FSimpleLootData(ELootCategory InLootCategory, int32 InValue) : LootCategory(InLootCategory), Value(InValue) {}

	UPROPERTY()
	ELootCategory LootCategory;

	UPROPERTY()
	int32 Value;
};

UENUM()
enum EConfirmPopupFlag
{
	Yes = 1 << 0,
	No = 1 << 1
};

DECLARE_DELEGATE_OneParam(FConfirmPopupDelegate, EConfirmPopupFlag /*Option*/);
DECLARE_DELEGATE_ThreeParams(FPartyResetDelegate, bool /*Character*/, bool /*Sculpture*/, bool /*Relic*/);

UENUM()
enum class EUpgradeAnimType : uint8
{
	Default = 0,
	TierUp = 1,
	LevelUp = 2
};

UENUM()
enum class EPopupKind : uint8
{
	Info = 0,
	Maintenance,
	Error,
	NetError,
	Fatal
};

UCLASS()
class Q6_API UPopupBaseWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	UPopupBaseWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;
	virtual void OnAnimationFinished_Implementation(const UWidgetAnimation* Animation) override;

	void OpenPopup(int32 InPopupOrder);

	virtual void SetCancelable(bool bInCancelable);

	void SetAutoCloseTime(float InTime);
	void SetPopupKind(EPopupKind InKind) { PopupKind = InKind; }

	EPopupKind GetKind() const { return PopupKind; }

	virtual bool OnBack() { return true; }

	UFUNCTION()
	void ClosePopup();

	bool IsOpened();
	int32 GetOrder();

	FSimpleDelegate OnDismissButtonClickedDelegate;		// Execute when popup closed or not (don't care close)
	FSimpleDelegate OnPopupClosedDelegate;	// Execute when popup closed only

	// don't bind this delegate at other place, only for BaseHUD.
	FSimpleDelegate OnPopupClosedDelegateForHUD;
protected:
	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* OpenAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CloseAnim;

private:
	UFUNCTION()
	void OnDismissButtonClicked();

	// Widgets

	UPROPERTY()
	UButton* DismissButton;

	// Fields

	UPROPERTY(EditInstanceOnly)
	bool bUsingDismissButton;

	UPROPERTY()
	EPopupKind PopupKind;

	float PopupCloseTime;
	float ElapsedTime;

	int32 PopupOrder;
	bool bAutoClose;
	bool bOpened;
};

UCLASS()
class Q6_API UPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	UPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;

	void SetTitle(const FText& Title);
	void SetBottomVisible(bool bVisible);

protected:
	UPROPERTY()
	UNamedSlot* BottomNamedSlot;

	UPROPERTY()
	URichTextBlock* TitleText;

	UPROPERTY(EditInstanceOnly)
	FText PopupTitle;
};

UCLASS()
class Q6_API UConfirmPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UConfirmPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;

	void SetContent(const FText& Content);
	void SetContentVisibility(ESlateVisibility InVisibility);

	void SetConfirmFlags(uint32 Flags);
	void SetYesNoText(const FText& InYesText, const FText& InNoText);

	void SetYesButtonEnabled(bool bInEnabled);
	void SetYesButtonVisibility(ESlateVisibility InVisibility);

	void SetNoGoBackOnConfirm();

	FConfirmPopupDelegate OnConfirmPopupDelegate;

protected:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option);

private:
	UFUNCTION()
	void OnYesButtonClicked();

	UFUNCTION()
	void OnNoButtonClicked();

	UPROPERTY()
	URichTextBlock* ContentText;

	UPROPERTY()
	UButton* YesButton;

	UPROPERTY()
	UButton* NoButton;

	UPROPERTY()
	UTextBlock* YesText;

	UPROPERTY()
	UTextBlock* NoText;

	UPROPERTY()
	bool bNoGoBackOnConfirmed;
};

UCLASS()
class Q6_API UPlayNotifyPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UPlayNotifyPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;

	void SetStageName(const FText& InStageName);
	void SetContent(const FText& InContent);

	FConfirmPopupDelegate OnPopupDelegate;

private:
	UFUNCTION()
	void OnCancelButtonClicked();

	UFUNCTION()
	void OnStartButtonClicked();

	UPROPERTY()
	UTextBlock* StageNameText;

	UPROPERTY()
	UTextBlock* ContentText;

	UPROPERTY()
	UButton* CancelButton;

	UPROPERTY()
	UButton* StartButton;
};


UCLASS()
class Q6_API UCurrencyUsePopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPurchaseInfo(FBoxProductType BoxProductType);
	void SetRebirth();

	FSimpleDelegate OnCurrencyUsedDelegate;

protected:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option) override;

private:
	//Widgets

	UPROPERTY()
	URichTextBlock* AlertText;

	UPROPERTY()
	UPointWidget* OwnedCurrencyWidget;

	UPROPERTY()
	UPointWidget* OwnedFreeGemWidget;

	UPROPERTY()
	UPointWidget* OwnedPaidGemWidget;

	UPROPERTY()
	UPointWidget* RequiredCurrencyWidget;

	UPROPERTY()
	UPointWidget* RequiredFreeGemWidget;

	UPROPERTY()
	UPointWidget* RequiredPaidGemWidget;

	UPROPERTY()
	UTextBlock* ConfirmText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* CurrencyAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* GemAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* CurrencyAndGemAnim;

	bool bEnoughCurrency;
};

UCLASS()
class Q6_API UItemListPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	UItemListPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;

	void SetYesButtonName(const FText& YesButtonName);
	void SetCost(int32 MyAmount, int32 Cost);
	void SetItems(EUpgradeCategory ItemCategory, const TArray<int64>& MaterialIds, bool bVisibleUltLevel);

	void SetTierUpResult(int32 CurrentTier, int32 TargetTier);
	void SetUltUpResult(FCharacterType CharacterType, int32 CurrentLevel, int32 TargetLevel);

	void PlayUpgradeAnimation(EUpgradeAnimType AnimType);

private:
	void SetCharacters(const TArray<int64>& ItemIds, bool bVisibleUltLevel);
	void SetRelics(const TArray<int64>& ItemIds);
	void SetSculptures(const TArray<int64>& ItemIds);

	UPROPERTY()
	UUpgradeResultTierWidget* ResultTierWidget;

	UPROPERTY()
	UTextBlock* CurrentLevelText;

	UPROPERTY()
	UTextBlock* TargetLevelText;

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	UTextBlock* MyGoldText;

	UPROPERTY()
	UTextBlock* GoldCostText;

	UPROPERTY()
	UTextBlock* YesLabelText;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> UpgradeAnims;
};

UCLASS()
class Q6_API UItemMaxLevelUpConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	UItemMaxLevelUpConfirmPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;

	void SetCharacter(const FCharacterId& CharacterId, EUpgradeCharacterCategory UpCategory);
	void SetRelic(const FRelicId& RelicId);
	void SetSculpture(const FSculptureId& SculptureId);

private:
	void SetItemPromote(const FCMSPromoteCostRow& CostRow);
	void SetCharacterEvolute(int32 TargetMoon, EItemGrade ItemGrade);
	const FText& GetCharacterUpgradeConfirmText(EUpgradeCharacterCategory UpCategory) const;

	UPROPERTY(EditDefaultsOnly)
	TArray<FText> CharacterUpgradeConfirmTexts;

	UPROPERTY()
	UItemLevelWidget* BeforeLevelWidget;

	UPROPERTY()
	UItemLevelWidget* AfterLevelWidget;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UTextBlock* OwnedAmountText;

	UPROPERTY()
	UTextBlock* RequiredAmountText;

	UPROPERTY()
	UTextBlock* UpgradeText;
};


UCLASS()
class Q6_API UItemRewardPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UItemRewardPopupWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetReward(FSagaType SagaType, bool bVisibleCount, bool bAllowDuplicated);
	void SetReward(const TArray<FRewardInfo>& RewardInfos);
	void SetReward(FEventContentType EventContentType, FSagaType SagaType, bool bVisibleCount, bool bAllowDuplicated);

private:
	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	URichTextBlock* DescriptionText;
};

UCLASS()
class Q6_API USkillUpgradeConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetTurnSkill(const FCharacterId& SelectedCharacterId, int32 SelectedSkillIndex);
	void SetPetSkill(const FPetId& PetId, int32 SkillIndex);
	void SetArtifactSkill(int32 ArtifactIndex);

private:
	void SetSkill(const TArray<const FCMSBagItemRow*>& BagItems
		, const TArray<int32>& BagItemCount
		, const int32 RequireGold
		, const int32 SkillLevel
		, const FText& DescName);

	UPROPERTY()
	UTextBlock* SkillNameText;

	UPROPERTY()
	UTextBlock* CurrentLevelText;

	UPROPERTY()
	UTextBlock* CurrentGoldText;

	UPROPERTY()
	UTextBlock* ResultLevelText;

	UPROPERTY()
	UTextBlock* RequiredGoldText;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;
};

UCLASS()
class Q6_API UPartyEditCancleConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetParty(const FPartyInfo& PartyInfo, const FPartySlot& PartySlot);
	void SetMultisideParty(const FPartyInfo& PartyInfo);
	void SetJokerSet(const FJokerSet& JokerSet);

private:
	UPROPERTY()
	UPartyMemberListWidget* BeforeMemberListWidget;

	UPROPERTY()
	UPartyMemberListWidget* AfterMemberListWidget;

	UPROPERTY()
	UTextBlock* PartyNumberText;

	UPROPERTY()
	UTextBlock* MenuText;

	UPROPERTY()
	UHorizontalBox* PartyNumberBox;
};

UCLASS()
class Q6_API UPartyResetConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void InitResetOptions();

	FPartyResetDelegate OnPartyResetDelegate;

private:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Flag) override;

	UPROPERTY()
	UCheckBox* CharacterResetCheckBox;

	UPROPERTY()
	UCheckBox* SculptureResetCheckBox;

	UPROPERTY()
	UCheckBox* RelicResetCheckBox;
};

UCLASS()
class Q6_API UFriendshipCollectPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

private:
	void OnItemCardClicked(UItemCardWidget* ItemCard);
};

UCLASS()
class Q6_API UBoostConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPortal(EPortalType PortalType);
	void SetArtifact(int32 ArtifactIdx, int32 ArtifactLevel);

private:
	static const int32 SecondsPerDay = 86400;

	void OnPortalBuildBoostUse(EConfirmPopupFlag Option);
	void OnArtifactBoostUse(EConfirmPopupFlag Option);

	UPROPERTY()
	UQ6TextBlock* CurrentDaysText;

	UPROPERTY()
	UQ6TextBlock* ResultDaysText;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UQ6TextBlock* OwnedAmountText;

	UPROPERTY()
	UQ6TextBlock* RequireAmountText;

	UPROPERTY()
	UQ6TextBlock* UsableText;

	UPROPERTY()
	UQ6TextBlock* RemainDaysInfoText;

	UPROPERTY()
	UQ6TextBlock* CurrentTimeText;

	UPROPERTY()
	UQ6TextBlock* ResultTimeText;

	UPROPERTY()
	UHorizontalBox* CurrentDaysBox;

	UPROPERTY()
	UHorizontalBox* ResultDaysBox;

	int32 SlotNum;
};

UCLASS()
class Q6_API UItemSelectPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPortal(EPortalType PortalType, bool bInConnect);
	void SetVacation();

	FInt64ParamDelegate OnItemSelectedDelegate;

private:
	void SetPortalCharacterList();
	void SetPortalRelicList();
	void SetPortalSculptureList();

	void OnItemSelected(int64 ItemId);

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	bool bSelectedClose;
};

UCLASS()
class Q6_API UPortalConnectConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetConnectItem(EPortalType PortalType, int64 ConnectedId);

private:
	UPROPERTY()
	UItemCardWidget* ItemWidget;

	UPROPERTY()
	UQ6TextBlock* LeadDaysText;

	UPROPERTY()
	UQ6TextBlock* NameText;
};

UCLASS()
class Q6_API UPortalConnectedResultPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetResult(const FSpecialRecord& SpecialRecord);

private:
	UFUNCTION()
	void OnStageButtonClicked();

	// Widgets

	UPROPERTY()
	UImage* EquipImage;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UTextBlock* OpenNameText;

	UPROPERTY()
	UQ6TextBlock* InfoText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* ResultAnim;

	// Fields

	ESpecialCategory SpecialCategory;
};


UCLASS()
class Q6_API UWonderUpgradeConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetWonder(EWonderCategory Category, int32 CurrentLevel);

private:
	UPROPERTY()
	UWonderUpgradeLevelEffectWidget* UpgradeEffectWidget;

	UPROPERTY()
	UQ6TextBlock* TimeLeftText;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UQ6TextBlock* OwnedAmountText;

	UPROPERTY()
	UQ6TextBlock* RequiredAmountText;

	UPROPERTY()
	UWonderProduceWidget* ProduceWidget;
};

UCLASS()
class Q6_API UWonderUpgradeResultPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetWonder(EWonderCategory InCategory, int32 ResultLevel);

private:
	void OnResultPopupClosed();

	UPROPERTY()
	UQ6TextBlock* WonderNameText;

	UPROPERTY()
	UWonderUpgradeLevelEffectWidget* UpgradeEffectWidget;

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UWonderProduceWidget* ProduceWidget;

	UPROPERTY(Transient)
	UWidgetAnimation* UpgradeAnim;

	EWonderCategory Category;
};

UCLASS()
class Q6_API UBondRewardInfoPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetInfo(FCharacterType CharacterType);

private:
	UFUNCTION()
	void OnYesButtonClicked();

	UPROPERTY()
	UTextBlock* NameText;

	UPROPERTY()
	UTextBlock* CurrentBondText;

	UPROPERTY()
	UButton* YesButton;

	UPROPERTY()
	UDynamicListWidget* BondRewardListWidget;
};

UCLASS()
class Q6_API URaidJoinPopupWidget : public UPopupBaseWidget
{
	GENERATED_BODY()

public:
	URaidJoinPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual bool Initialize() override;
	virtual void NativeConstruct() override;

	void SetInfo(const FCMSSagaRow& SagaRow, ERaidCategory InRaidCategory);

	UFUNCTION(BlueprintImplementableEvent)
	void SetRaidJoinPopupWidgetState(ERaidCategory InRaidCategory);

private:
	void JumpToRaid();

	UFUNCTION()
	void OnDismiss();

	UFUNCTION()
	void OnYesButtonClicked();

	UFUNCTION()
	void OnEnterRaidButtonClicked(EConfirmPopupFlag InPopupFlag);

	UPROPERTY(Transient)
	UWidgetAnimation* IntroAnim;

	UPROPERTY()
	UTextBlock* RaidNameText;

	UPROPERTY()
	UButton* JoinButton;

	UPROPERTY()
	UPointWidget* PointWidget;

	bool bEnoughWatt;
	bool bVisible;

	ERaidCategory RaidCategory;
};

UCLASS()
class Q6_API UCheatCommandHelpPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
#if !UE_BUILD_SHIPPING
	void SetHelp(const TArray<IConsoleObject*>& ConsoleObjects, const TArray<FString>& CommandHistory);
#endif

private:
	UFUNCTION()
	void OnCommandCommitted(const FText& Text, ETextCommit::Type CommitMethod);

	UFUNCTION()
	void OnChangedMenu(int32 SelectedIndex);

#if !UE_BUILD_SHIPPING
	void SetCommandList(const TArray<IConsoleObject*>& ConsoleObjects);
	void SetCommandHistory(const TArray<FString>& CommandHistory);

	UToggleButtonWidget* AddCheatButtonAtLast(UDynamicListWidget* ListWidget, const FString& DisplayStr);
	void ExecuteCheatCommand(const FString& ExecuteCommand);
	void AddCommandHistory(const FString& NewCommand);

	void OnSelectedCommand(const TCHAR* Command);
	void OnExecuteButtonClicked();
	void OnClearButtonClicked();

	void OnSelectedHistory(FString ExecuteString);

#endif

	UPROPERTY()
	UDynamicListWidget* CommandListWidget;

	UPROPERTY()
	UEditableTextBox* CommandInputBox;

	UPROPERTY()
	UToggleButtonBoxWidget* MenuButtonBox;

	UPROPERTY()
	UWidgetSwitcher* MenuSwitcher;

	UPROPERTY()
	UDynamicListWidget* HistoryListWidget;
};

/*
* ItemReceivedPopupWidgetBP
*/
UCLASS()
class Q6_API UItemReceivedPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UItemReceivedPopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetItem(const TArray<FItemData>& ItemData);

	void SetBuyItem(FShopType InShopType, int32 InCount);
	void SetMissionReceivedItem(const FCMSLootDataRow& InLootDataRow);
	void SetAlchemyLabReceivedItem(const int32 ProductType, const int32 Count);

private:

	bool IsStackableItemData(const FItemData& InItemData) const;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;
};

/*
* WithdrawPopupWidgetBP
*/
UCLASS()
class Q6_API UWithdrawPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UWithdrawPopupWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetContentType(EContentType InContentType);

private:
	UFUNCTION()
	void OnWithdrawButtonClicked();

	UFUNCTION()
	void OnCancelButtonClicked();

	UPROPERTY()
	UItemDropListWidget* ItemDropListWidget;

	UPROPERTY()
	UTextBlock* ContentText;

	UPROPERTY()
	UQ6TextBlock* NoItemText;

	UPROPERTY()
	UButton* WithdrawButton;

	UPROPERTY()
	UButton* CancelButton;

	EContentType ContentType;
};
