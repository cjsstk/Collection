// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "LobbySettingWidgets.h"

#include "CharacterManager.h"
#include "CMSTable.h"
#include "CodexManager.h"
#include "CommonWidgets.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "ItemWidgets.h"
#include "LobbyHUD.h"
#include "LobbyPlayerController.h"
#include "LobbySetManager.h"
#include "LobbyTemplateManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "SystemConst_gen.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent LobbySetting"), STAT_OnHSEventByLobbySetting, STATGROUP_HSTORE);


//////////////////////////////////////////////////////////////////////////////////
// ULobbyCharacterIconWidget

ULobbyCharacterIconWidget::ULobbyCharacterIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Index(INDEX_NONE)
{
}

void ULobbyCharacterIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CharIconImage = CastChecked<UImage>(GetWidgetFromName("ImgChar"));

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &ULobbyCharacterIconWidget::OnSlotClicked);

	SelectedPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("PanelSelected"));
}

void ULobbyCharacterIconWidget::SetEmpty()
{
	CharacterId = FCharacterId::InvalidValue();
	CharIconImage->SetVisibility(ESlateVisibility::Collapsed);

	if (CharacterCardWidget)
	{
		CharacterCardWidget->SetHighlight(false);
		CharacterCardWidget->SetUsed(false);
		CharacterCardWidget = nullptr;
	}
}

void ULobbyCharacterIconWidget::SetCharacter(UItemCardWidget* InWidget, bool bSwapping /* = false */)
{
	if (!InWidget)
	{
		SetEmpty();
		return;
	}

	if (bSwapping && CharacterCardWidget)
	{
		CharacterCardWidget->SetHighlight(false);
	}
	else
	{
		SetEmpty();
	}
	CharacterCardWidget = InWidget;

	SetCharacter(InWidget->GetCharacterId());
}

void ULobbyCharacterIconWidget::SetCharacter(const FCharacterId InCharacterId, bool bSwapping /* = false */)
{
	const UCharacterManager& CharacterMgr = GetHUDStore().GetCharacterManager();
	const FCharacter* Character = CharacterMgr.Find(InCharacterId);
	if (!Character)
	{
		SetEmpty();
		return;
	}

	CharacterId = InCharacterId;

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(Character->GetInfo().Type);
	CharIconImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());
	CharIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);

	if (!bSwapping && CharacterCardWidget)
	{
		CharacterCardWidget->SetUsed(true);
	}
}

void ULobbyCharacterIconWidget::SetCharacter(const FCharacterType InCharacterType)
{
	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(InCharacterType);
	CharIconImage->SetBrushFromSoftTextureWhenLoadingFinished(CharacterAssetRow.GetDefaultIconTexture());
	CharIconImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
}

void ULobbyCharacterIconWidget::SetSelected(bool bInSelected) const
{
	SelectedPanel->SetVisibility(bInSelected ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	if (CharacterCardWidget)
	{
		CharacterCardWidget->SetHighlight(bInSelected);
	}
}

void ULobbyCharacterIconWidget::OnSlotClicked()
{
	OnSlotClickedDelegate.ExecuteIfBound(Index);
}


//////////////////////////////////////////////////////////////////////////////////
// ULobbyTemplateIconWidget

ULobbyTemplateIconWidget::ULobbyTemplateIconWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, TemplateId(FLobbyTemplateId())
	, TemplateType(LobbyTemplateTypeInvalid)
{
}

void ULobbyTemplateIconWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TemplateIconImage = CastChecked<UImage>(GetWidgetFromName("ImgIcon"));
	SwipeableImage = CastChecked<UImage>(GetWidgetFromName("ImgSwipeable"));

	for (int32 i = 0; i < MAX_LOBBY_TEMPLATE_CHAR_SLOT_COUNT; ++i)
	{
		FString SlotName = FString::Printf(TEXT("ImgSlot%d"), i);
		UImage* SlotImage = CastChecked<UImage>(GetWidgetFromName(*SlotName));
		SlotImages.AddUnique(SlotImage);
	}

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &ULobbyTemplateIconWidget::OnTemplateClicked);

	SelectedImage = CastChecked<UImage>(GetWidgetFromName("ImgSelected"));
	DisabledPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("PanelDisabled"));
}

void ULobbyTemplateIconWidget::SetTemplate(FLobbyTemplateId InTemplateId, FLobbyTemplateType InTemplateType)
{
	TemplateId = InTemplateId;
	TemplateType = InTemplateType;

	DisabledPanel->SetVisibility(TemplateId.IsInvalid() ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	const FLobbyTemplateAssetRow& AssetRow = GetGameResource().GetLobbyTemplateAssetRow(TemplateType);

	if (!AssetRow.TemplateIconTexture.IsNull())
	{
		TemplateIconImage->SetBrushFromSoftTextureWhenLoadingFinished(AssetRow.TemplateIconTexture);
	}

	SwipeableImage->SetVisibility(AssetRow.bSwipeable ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);

	for (int32 i = 0; i < SlotImages.Num(); ++i)
	{
		SlotImages[i]->SetVisibility(i < AssetRow.SlotInfos.Num() ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void ULobbyTemplateIconWidget::SetSelected(bool bInSelected) const
{
	SelectedImage->SetVisibility(bInSelected ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void ULobbyTemplateIconWidget::OnTemplateClicked()
{
	OnTemplateClickedDelegate.ExecuteIfBound(TemplateId, TemplateType);
}


//////////////////////////////////////////////////////////////////////////////////
// ULobbySettingEditTemplateWidget

ULobbySettingEditTemplateWidget::ULobbySettingEditTemplateWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SelectedTemplateId(FLobbyTemplateId::InvalidValue())
	, SelectedTemplateType(LobbyTemplateTypeInvalid)
{
}

void ULobbySettingEditTemplateWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TemplateOwnedAnim = GetWidgetAnimationFromName(this, "AnimTemplateOwned");
	TemplateNotOwnedAnim = GetWidgetAnimationFromName(this, "AnimTemplateNotOwned");

	TemplateNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextTemplateName"));
	TemplateDescText = CastChecked<UTextBlock>(GetWidgetFromName("TextTemplateDesc"));
	TemplateOriginDescText = CastChecked<UTextBlock>(GetWidgetFromName("TextTemplateOriginDesc"));

	TemplateAnyCharacterBox = CastChecked<UHorizontalBox>(GetWidgetFromName("BoxTemplateAnyCharacter"));
	TemplateCharacterListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("TemplateCharacterList"));
	TemplateListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("TemplateList"));

	UButton* NextButton = CastChecked<UButton>(GetWidgetFromName("BtnNext"));
	NextButton->OnClicked.AddUniqueDynamic(this, &ULobbySettingEditTemplateWidget::OnNextButtonClicked);
}

void ULobbySettingEditTemplateWidget::InitTemplateList(FLobbyTemplateId InTemplateId)
{
	TemplateListWidget->ClearList();

	const TMap<FLobbyTemplateId, FLobbyTemplate>& LobbyTemplates = GetHUDStore().GetLobbyTemplateManager().GetLobbyTemplates();
	for (const auto& Elem : LobbyTemplates)
	{
		ULobbyTemplateIconWidget* TemplateIconWidget = CastChecked<ULobbyTemplateIconWidget>(TemplateListWidget->AddChildAtLastIndex());
		TemplateIconWidget->SetTemplate(Elem.Key, Elem.Value.GetInfo().Type);
		TemplateIconWidget->SetSelected(false);
		TemplateIconWidget->OnTemplateClickedDelegate.BindUObject(this, &ULobbySettingEditTemplateWidget::SetSelectedTemplate);
	}

	const UDataTable* CMSTable = GetCMS()->GetLobbyTemplate();
	if (!CMSTable)
	{
		return;
	}

	TArray<FCMSLobbyTemplateRow*> CMSRowArray;
	CMSTable->GetAllRows(TEXT("InitTemplateList"), CMSRowArray);

	for (FCMSLobbyTemplateRow* CMSRow : CMSRowArray)
	{
		if (GetHUDStore().GetLobbyTemplateManager().HasLobbyTemplate(CMSRow->CmsType()))
		{
			continue;
		}

		ULobbyTemplateIconWidget* TemplateIconWidget = CastChecked<ULobbyTemplateIconWidget>(TemplateListWidget->AddChildAtLastIndex());
		TemplateIconWidget->SetTemplate(FLobbyTemplateId::InvalidValue(), CMSRow->CmsType());
		TemplateIconWidget->SetSelected(false);
		TemplateIconWidget->OnTemplateClickedDelegate.BindUObject(this, &ULobbySettingEditTemplateWidget::SetSelectedTemplate);
	}

	if (InTemplateId.IsInvalid())
	{
		ULobbyTemplateIconWidget* FirstTemplateIconWidget = CastChecked<ULobbyTemplateIconWidget>(TemplateListWidget->FindChildAt(0));
		SetSelectedTemplate(FirstTemplateIconWidget->GetTemplateId(), FirstTemplateIconWidget->GetTemplateType());
	}
	else
	{
		const FLobbyTemplateInfo& LobbyTemplateInfo = GetHUDStore().GetLobbyTemplateManager().GetLobbyTemplateInfo(InTemplateId);
		SetSelectedTemplate(InTemplateId, LobbyTemplateInfo.Type);
	}
}

void ULobbySettingEditTemplateWidget::SetSelectedTemplate(FLobbyTemplateId InTemplateId, FLobbyTemplateType InTemplateType)
{
	SelectedTemplateId = InTemplateId;
	SelectedTemplateType = InTemplateType;

	const FCMSLobbyTemplateRow& CMSRow = GetCMS()->GetLobbyTemplateRowOrDummy(SelectedTemplateType);
	if (!CMSRow.Name.IsEmpty())
	{
		TemplateNameText->SetText(CMSRow.Name);
	}
	if (!CMSRow.Desc.IsEmpty())
	{
		TemplateDescText->SetText(CMSRow.Desc);
	}
	if (!CMSRow.OriginDesc.IsEmpty())
	{
		TemplateOriginDescText->SetText(CMSRow.OriginDesc);
	}

	InitTemplateCharacterList();

	for (int32 i = 0; i < TemplateListWidget->GetChildrenCount(); ++i)
	{
		ULobbyTemplateIconWidget* TemplateIconWidget = CastChecked<ULobbyTemplateIconWidget>(TemplateListWidget->FindChildAt(i));
		if (!TemplateIconWidget)
		{
			continue;
		}
		
		bool bSelected = SelectedTemplateId.IsInvalid() ?
			TemplateIconWidget->GetTemplateType() == SelectedTemplateType : TemplateIconWidget->GetTemplateId() == SelectedTemplateId;
		TemplateIconWidget->SetSelected(bSelected);
	}

	PlayAnimation(SelectedTemplateId.IsInvalid() ? TemplateNotOwnedAnim : TemplateOwnedAnim);

	OnTemplateChangedDelegate.ExecuteIfBound(SelectedTemplateId, SelectedTemplateType);
}

void ULobbySettingEditTemplateWidget::InitTemplateCharacterList()
{
	const FLobbyTemplateAssetRow& AssetRow = GetGameResource().GetLobbyTemplateAssetRow(SelectedTemplateType);

	bool bAnyCharacterPossible = false;
	TArray<int32> ExclusiveCharacterTypes;
	for (const FLobbyTemplateCharacterSlotInfo& SlotInfo : AssetRow.SlotInfos)
	{
		if (!SlotInfo.ExclusiveInfos.Num())
		{
			// sunny-to-check-template-with-both-exclusive-and-nonexclusive-slots-case
			bAnyCharacterPossible = true;
			break;
		}

		for (const FLobbyExclusiveCharacterInfo& ExclusiveInfo : SlotInfo.ExclusiveInfos)
		{
			ExclusiveCharacterTypes.AddUnique(ExclusiveInfo.ExclusiveCharacterType);
		}
	}

	TemplateCharacterListWidget->ClearList();

	if (bAnyCharacterPossible)
	{
		TemplateAnyCharacterBox->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
	else
	{
		TemplateAnyCharacterBox->SetVisibility(ESlateVisibility::Collapsed);

		for (int32 ExclusiveCharacterType : ExclusiveCharacterTypes)
		{
			ULobbyCharacterIconWidget* CharacterIconWidget = CastChecked<ULobbyCharacterIconWidget>(TemplateCharacterListWidget->AddChildAtLastIndex());
			CharacterIconWidget->SetCharacter(FCharacterType(ExclusiveCharacterType));
		}
	}
}

void ULobbySettingEditTemplateWidget::OnNextButtonClicked()
{
	if (SelectedTemplateId.IsInvalid())
	{
		// sunny-to-check-spec
		return;
	}

	OnClearCharacterDelegate.ExecuteIfBound();

	ACTION_DISPATCH_LobbySettingEditChange(ELobbySettingEditType::EditCharacter);
}


//////////////////////////////////////////////////////////////////////////////////
// ULobbySettingEditCharacterWidget

ULobbySettingEditCharacterWidget::ULobbySettingEditCharacterWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SelectedSlotIndex(INDEX_NONE)
	, SlotCount(INDEX_NONE)
{
}

void ULobbySettingEditCharacterWidget::NativeConstruct()
{
	Super::NativeConstruct();

	TemplateNameText = CastChecked<UTextBlock>(GetWidgetFromName("TextTemplateName"));

	for (int32 i = 0; i < MAX_LOBBY_TEMPLATE_CHAR_SLOT_COUNT; ++i)
	{
		FString SlotName = FString::Printf(TEXT("CharSlot%d"), i);
		ULobbyCharacterIconWidget* SlotWidget = CastChecked<ULobbyCharacterIconWidget>(GetWidgetFromName(*SlotName));
		SlotWidget->SetIndex(i);
		SlotWidget->OnSlotClickedDelegate.BindUObject(this, &ULobbySettingEditCharacterWidget::OnCharacterSlotClicked);
		SlotWidgets.AddUnique(SlotWidget);
	}

	CharacterListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("CharacterList"));

	UButton* ApplyButton = CastChecked<UButton>(GetWidgetFromName("BtnApply"));
	ApplyButton->OnClicked.AddUniqueDynamic(this, &ULobbySettingEditCharacterWidget::OnApplyButtonClicked);
}

void ULobbySettingEditCharacterWidget::Init(const FLobbySetInfo& InLobbySetInfo, int32 InSelectedSlotIndex)
{
	InitCharacterSlots(InLobbySetInfo, InSelectedSlotIndex);
	InitCharacterList(InLobbySetInfo);
}

void ULobbySettingEditCharacterWidget::InitCharacterSlots(const FLobbySetInfo& InLobbySetInfo, int32 InSelectedSlotIndex)
{
	SelectedSlotIndex = InSelectedSlotIndex;

	const FLobbyTemplateInfo& LobbyTemplateInfo = GetHUDStore().GetLobbyTemplateManager().GetLobbyTemplateInfo(InLobbySetInfo.LobbyTemplateId);
	const FCMSLobbyTemplateRow& CMSRow = GetCMS()->GetLobbyTemplateRowOrDummy(LobbyTemplateInfo.Type);
	const FLobbyTemplateAssetRow& AssetRow = GetGameResource().GetLobbyTemplateAssetRow(CMSRow.CmsType());

	ensure(CMSRow.SlotCount == AssetRow.SlotInfos.Num());
	SlotCount = CMSRow.SlotCount;

	if (!CMSRow.Name.IsEmpty())
	{
		TemplateNameText->SetText(CMSRow.Name);
	}

	for (int32 i = 0; i < SlotWidgets.Num(); ++i)
	{
		SlotWidgets[i]->SetEmpty();
		SlotWidgets[i]->SetSelected(i == SelectedSlotIndex);
		SlotWidgets[i]->SetVisibility(i < SlotCount ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}
}

static bool _HasCharacterType(FCharacterType CharacterType, TArray<FCharacterInfo>& CharacterInfos)
{
	for (const FCharacterInfo& CharacterInfo : CharacterInfos)
	{
		if (CharacterInfo.Type == CharacterType)
		{
			return true;
		}
	}

	return false;
}

void ULobbySettingEditCharacterWidget::InitCharacterList(const FLobbySetInfo& InLobbySetInfo)
{
	InitTemplateSlotExclusiveInfo(InLobbySetInfo.LobbyTemplateId);

	TemplateIncludedCharacterInfos.Empty();
	TemplateExcludedCharacterInfos.Empty();
	InitOwnedCharacters();
	InitNotOwnedCharacters();

	CharacterListWidget->ClearList();
	AddCharacterRemovalCard();
	AddCharacterCards(InLobbySetInfo.CharacterIds, true);
	AddCharacterCards(InLobbySetInfo.CharacterIds, false);
}

void ULobbySettingEditCharacterWidget::InitTemplateSlotExclusiveInfo(FLobbyTemplateId InTemplateId)
{
	TemplateSlotExclusiveCharacterTypes.Empty();

	const FLobbyTemplateInfo& TemplateInfo = GetHUDStore().GetLobbyTemplateManager().GetLobbyTemplateInfo(InTemplateId);
	const FLobbyTemplateAssetRow& AssetRow = GetGameResource().GetLobbyTemplateAssetRow(TemplateInfo.Type);

	for (int32 SlotIndex = 0; SlotIndex < AssetRow.SlotInfos.Num(); ++SlotIndex)
	{
		for (const FLobbyExclusiveCharacterInfo& ExclusiveCharacterInfo : AssetRow.SlotInfos[SlotIndex].ExclusiveInfos)
		{
			if (TemplateSlotExclusiveCharacterTypes.IsValidIndex(SlotIndex))
			{
				TemplateSlotExclusiveCharacterTypes[SlotIndex].AddUnique(ExclusiveCharacterInfo.ExclusiveCharacterType);
			}
			else
			{
				TArray<int32> CharacterTypeArray = { ExclusiveCharacterInfo.ExclusiveCharacterType };
				TemplateSlotExclusiveCharacterTypes.EmplaceAt(SlotIndex, CharacterTypeArray);
			}
		}
	}
}

void ULobbySettingEditCharacterWidget::InitOwnedCharacters()
{
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();

	TArray<const FCharacter*> OwnedCharacters = CharacterManager.GetCharacters(ESortMenu::Collection, ESortCategory::OwnedCharacter);
	for (const FCharacter* OwnedCharacter : OwnedCharacters)
	{
		if (!OwnedCharacter)
		{
			continue;
		}

		FCharacterType CharacterType = OwnedCharacter->GetInfo().Type;
		TArray<FCharacterInfo>& CharacterInfos = IsTemplatePlaceable(CharacterType) ? TemplateIncludedCharacterInfos : TemplateExcludedCharacterInfos;

		if (_HasCharacterType(CharacterType, CharacterInfos))
		{
			continue;
		}
		
		CharacterInfos.Add(OwnedCharacter->GetInfo());
	}
}

void ULobbySettingEditCharacterWidget::InitNotOwnedCharacters()
{
	const UCharacterManager& CharacterManager = GetHUDStore().GetCharacterManager();
	const UCodexManager& CodexManager = GetHUDStore().GetCodexManager();
	const TArray<const FCMSCharacterRow*>& CodexCharacterRows = CodexManager.GetCodexCharacterRows();

	for (const FCMSCharacterRow* CharacterRow : CodexCharacterRows)
	{
		if (!CharacterRow)
		{
			continue;
		}

		FCharacterType CharacterType = FCharacterType(CharacterRow->Type);
		if (CharacterManager.HasCharacter(CharacterType))
		{
			continue;
		}

		TArray<FCharacterInfo>& CharacterInfos = IsTemplatePlaceable(CharacterType) ? TemplateIncludedCharacterInfos : TemplateExcludedCharacterInfos;

		if (_HasCharacterType(CharacterType, CharacterInfos))
		{
			continue;
		}

		FCharacterInfo& NotOwnedCharacterInfo = CharacterInfos.AddZeroed_GetRef();
		NotOwnedCharacterInfo.CharacterId = FCharacterId::InvalidValue();
		NotOwnedCharacterInfo.Type = CharacterType;
		NotOwnedCharacterInfo.Grade = CharacterRow->Grade;
		NotOwnedCharacterInfo.Locked = false;
	}
}

bool ULobbySettingEditCharacterWidget::IsTemplatePlaceable(FCharacterType CharacterType) const
{
	if (!TemplateSlotExclusiveCharacterTypes.Num())
	{
		return true;
	}

	for (int32 i = 0; i < TemplateSlotExclusiveCharacterTypes.Num(); ++i)
	{
		if (IsTemplateSlotPlaceable(i, CharacterType))
		{
			return true;
		}
	}

	return false;
}

bool ULobbySettingEditCharacterWidget::IsTemplateSlotPlaceable(int32 SlotIndex, FCharacterType CharacterType) const
{
	if (!TemplateSlotExclusiveCharacterTypes[SlotIndex].Num())
	{
		return true;
	}

	for (int32 ExclusiveCharacterType : TemplateSlotExclusiveCharacterTypes[SlotIndex])
	{
		if (ExclusiveCharacterType == CharacterType)
		{
			return true;
		}
	}

	return false;
}

void ULobbySettingEditCharacterWidget::AddCharacterRemovalCard()
{
	UItemCardWidget* RemovalCardWidget = CastChecked<UItemCardWidget>(CharacterListWidget->AddChildAtLastIndex());
	RemovalCardWidget->SetRemoval();
	RemovalCardWidget->SetSelectable(true);
	RemovalCardWidget->SetUsed(false);
	RemovalCardWidget->SetHighlight(false);
	RemovalCardWidget->OnItemClickedDelegate.BindUObject(this, &ULobbySettingEditCharacterWidget::OnCharacterRemovalCardClicked);
}

void ULobbySettingEditCharacterWidget::AddCharacterCards(const TArray<FCharacterId>& InCharacterIds, bool bIncluded)
{
	TArray<FCharacterInfo>& CharacterInfos = bIncluded ? TemplateIncludedCharacterInfos : TemplateExcludedCharacterInfos;

	for (const FCharacterInfo& CharacterInfo : CharacterInfos)
	{
		bool bOwned = !CharacterInfo.CharacterId.IsInvalid();

		UItemCardWidget* CharacterCardWidget = CastChecked<UItemCardWidget>(CharacterListWidget->AddChildAtLastIndex());
		CharacterCardWidget->OnItemClickedDelegate.BindUObject(this, &ULobbySettingEditCharacterWidget::OnCharacterCardClicked);

		CharacterCardWidget->SetCharacter(CharacterInfo);
		CharacterCardWidget->SetUsed(false);
		CharacterCardWidget->SetHighlight(false);
		CharacterCardWidget->SetSelectable(bIncluded && bOwned);
		CharacterCardWidget->SetForLobbySetting(bIncluded, bOwned);

		if (bIncluded && bOwned)
		{
			int32 FoundIndex = InCharacterIds.Find(CharacterInfo.CharacterId);
			if (FoundIndex != INDEX_NONE)
			{
				if (SlotWidgets.IsValidIndex(FoundIndex))
				{
					SlotWidgets[FoundIndex]->SetCharacter(CharacterCardWidget);
				}
			}
		}
	}
}

void ULobbySettingEditCharacterWidget::SetNewSelectedCharacterCardWidget(UItemCardWidget* InWidget)
{
	if (InWidget == SelectedCharacterCardWidget)
	{
		return;
	}

	if (SelectedCharacterCardWidget)
	{
		SelectedCharacterCardWidget->SetSelected(false);
	}

	SelectedCharacterCardWidget = InWidget;
	if (SelectedCharacterCardWidget)
	{
		SelectedCharacterCardWidget->SetSelected(true);
	}
}

void ULobbySettingEditCharacterWidget::OnCharacterSlotClicked(int32 SlotIndex)
{
	if (SlotIndex == SelectedSlotIndex)
	{
		return;
	}

	if (SlotWidgets.IsValidIndex(SelectedSlotIndex))
	{
		SlotWidgets[SelectedSlotIndex]->SetSelected(false);
		SelectedCharacterCardWidget = nullptr;
	}

	if (!SlotWidgets.IsValidIndex(SlotIndex))
	{
		return;
	}

	SelectedSlotIndex = SlotIndex;
	SlotWidgets[SelectedSlotIndex]->SetSelected(true);
	OnCharacterSlotClickedDelegate.ExecuteIfBound(SelectedSlotIndex);
}

void ULobbySettingEditCharacterWidget::OnCharacterRemovalCardClicked(UItemCardWidget* InWidget)
{
	SlotWidgets[SelectedSlotIndex]->SetEmpty();
	SetNewSelectedCharacterCardWidget(nullptr);

	OnCharacterSettingDelegate.ExecuteIfBound(FCharacterId::InvalidValue(), SelectedSlotIndex, SlotCount);
}

void ULobbySettingEditCharacterWidget::OnCharacterCardClicked(UItemCardWidget* InWidget)
{
	if (!InWidget)
	{
		return;
	}

	if (!SlotWidgets.IsValidIndex(SelectedSlotIndex))
	{
		return;
	}

	UItemCardWidget* SelectedSlotCharacterCardWidget = SlotWidgets[SelectedSlotIndex]->GetCharacterCardWidget();
	if (SelectedSlotCharacterCardWidget == InWidget)
	{
		return;
	}

	bool bSwap = false;
	for (ULobbyCharacterIconWidget* SlotWidget : SlotWidgets)
	{
		if (SlotWidget->GetCharacterCardWidget() == InWidget)
		{
			bSwap = true;
			SlotWidget->SetCharacter(SelectedSlotCharacterCardWidget, bSwap);
			break;
		}
	}
	SlotWidgets[SelectedSlotIndex]->SetCharacter(InWidget, bSwap);

	SetNewSelectedCharacterCardWidget(InWidget);
	
	OnCharacterSettingDelegate.ExecuteIfBound(InWidget->GetCharacterId(), SelectedSlotIndex, SlotCount);
}

void ULobbySettingEditCharacterWidget::OnApplyButtonClicked()
{
	OnApplyLobbySettingDelegate.ExecuteIfBound();
}


//////////////////////////////////////////////////////////////////////////////////
// ULobbySetListEntryWidget

ULobbySetListEntryWidget::ULobbySetListEntryWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, Index(INDEX_NONE)
	, LobbySetId(0)
{
}

void ULobbySetListEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectedAnim = GetWidgetAnimationFromName(this, "AnimSelected");
	DeselectedAnim = GetWidgetAnimationFromName(this, "AnimDeselected");

	LobbySetIdText = CastChecked<UTextBlock>(GetWidgetFromName("TxtLobbySetId"));
	TemplateNameText = CastChecked<UTextBlock>(GetWidgetFromName("TxtTemplateName"));
	InUseBox = CastChecked<UBorder>(GetWidgetFromName("BoxInUse"));

	TemplateIconWidget = CastChecked<ULobbyTemplateIconWidget>(GetWidgetFromName("LobbyTemplateIcon"));

	for (int32 i = 0; i < MAX_LOBBY_TEMPLATE_CHAR_SLOT_COUNT; ++i)
	{
		FString SlotName = FString::Printf(TEXT("CharSlot%d"), i);
		ULobbyCharacterIconWidget* SlotWidget = CastChecked<ULobbyCharacterIconWidget>(GetWidgetFromName(*SlotName));
		SlotWidget->SetIndex(i);
		CharacterSlotWidgets.AddUnique(SlotWidget);
	}

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("BtnSelect"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &ULobbySetListEntryWidget::OnLobbySetSelected);
}

void ULobbySetListEntryWidget::SetLobbySetInfo(const FLobbySetInfo& InInfo)
{
	LobbySetId = InInfo.LobbySetId;
	LobbySetIdText->SetText(FText::AsNumber(LobbySetId));

	const FLobbyTemplateInfo& LobbyTemplateInfo = GetHUDStore().GetLobbyTemplateManager().GetLobbyTemplateInfo(InInfo.LobbyTemplateId);
	const FCMSLobbyTemplateRow& CMSRow = GetCMS()->GetLobbyTemplateRowOrDummy(LobbyTemplateInfo.Type);
	TemplateNameText->SetText(CMSRow.Name);

	TemplateIconWidget->SetTemplate(LobbyTemplateInfo.LobbyTemplateId, LobbyTemplateInfo.Type);

	for (int32 i = 0; i < CharacterSlotWidgets.Num(); ++i)
	{
		if (InInfo.CharacterIds.IsValidIndex(i))
		{
			CharacterSlotWidgets[i]->SetCharacter(InInfo.CharacterIds[i]);
		}
		else
		{
			CharacterSlotWidgets[i]->SetEmpty();
		}

		CharacterSlotWidgets[i]->SetVisibility(i < CMSRow.SlotCount ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void ULobbySetListEntryWidget::SetInUse(bool bInInUse)
{
	InUseBox->SetVisibility(bInInUse ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void ULobbySetListEntryWidget::SetSelected(bool bInSelected)
{
	if (bInSelected)
	{
		PlayAnimation(SelectedAnim);
	}
	else
	{
		PlayAnimation(DeselectedAnim);
	}
}

void ULobbySetListEntryWidget::OnLobbySetSelected()
{
	OnLobbySetSelectedDelegate.ExecuteIfBound(Index);
}


//////////////////////////////////////////////////////////////////////////////////
// ULobbySetListPopupWidget

ULobbySetListPopupWidget::ULobbySetListPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, SelectedLobbySetIndex(INDEX_NONE)
{
}

void ULobbySetListPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	for (int32 i = 0; i < MAX_LOBBY_SET_INFO_COUNT; ++i)
	{
		FString SlotName = FString::Printf(TEXT("LobbySetSlot%d"), i);
		ULobbySetListEntryWidget* SlotWidget = CastChecked<ULobbySetListEntryWidget>(GetWidgetFromName(*SlotName));
		SlotWidget->SetIndex(i);
		SlotWidget->OnLobbySetSelectedDelegate.BindUObject(this, &ULobbySetListPopupWidget::OnLobbySetSelected);
		LobbySetSlotWidgets.AddUnique(SlotWidget);
	}
}

void ULobbySetListPopupWidget::SetLobbySetList()
{
	const ULobbySetManager& LobbySetManager = GetHUDStore().GetLobbySetManager();

	int32 SelectedLobbySetId = LobbySetManager.GetSelectedLobbySetId();
	const TArray<FLobbySetInfo>& LobbySetInfoList = LobbySetManager.GetLobbySetInfoList();

	// valid info
	for (const FLobbySetInfo& LobbySetInfo : LobbySetInfoList)
	{
		int32 SlotIndex = LobbySetInfo.LobbySetId - 1;
		if (!LobbySetSlotWidgets.IsValidIndex(SlotIndex))
		{
			continue;
		}

		LobbySetSlotWidgets[SlotIndex]->SetLobbySetInfo(LobbySetInfo);

		if (LobbySetInfo.LobbySetId == SelectedLobbySetId)
		{
			SelectedLobbySetIndex = SlotIndex;
			LobbySetSlotWidgets[SlotIndex]->SetInUse(true);
			LobbySetSlotWidgets[SlotIndex]->SetSelected(true);
		}
		else
		{
			LobbySetSlotWidgets[SlotIndex]->SetInUse(false);
			LobbySetSlotWidgets[SlotIndex]->SetSelected(false);
		}
	}

	if (LobbySetInfoList.Num() == MAX_LOBBY_SET_INFO_COUNT)
	{
		return;
	}

	// invalid info
	for (int32 i = 0; i < LobbySetSlotWidgets.Num(); ++i)
	{
		int32 LobbySetId = i + 1;
		if (LobbySetManager.IsValidLobbySet(i + 1))
		{
			continue;
		}

		FLobbySetInfo DummyLobbySetInfo = LobbySetManager.GetDummyLobbySetInfo(LobbySetId);
		LobbySetSlotWidgets[i]->SetLobbySetInfo(DummyLobbySetInfo);
		LobbySetSlotWidgets[i]->SetInUse(false);
		LobbySetSlotWidgets[i]->SetSelected(false);
	}
}

void ULobbySetListPopupWidget::OnLobbySetSelected(int32 InLobbySetIndex)
{
	if (InLobbySetIndex == SelectedLobbySetIndex)
	{
		return;
	}

	if (LobbySetSlotWidgets.IsValidIndex(SelectedLobbySetIndex))
	{
		LobbySetSlotWidgets[SelectedLobbySetIndex]->SetSelected(false);
	}

	if (LobbySetSlotWidgets.IsValidIndex(InLobbySetIndex))
	{
		SelectedLobbySetIndex = InLobbySetIndex;
		LobbySetSlotWidgets[SelectedLobbySetIndex]->SetSelected(true);
	}
}

void ULobbySetListPopupWidget::OnConfirmButtonClicked(EConfirmPopupFlag Flag)
{
	Super::OnConfirmButtonClicked(Flag);

	if (Flag != EConfirmPopupFlag::Yes)
	{
		return;
	}

	if (LobbySetSlotWidgets.IsValidIndex(SelectedLobbySetIndex))
	{
		int32 SelectedLobbySetId = LobbySetSlotWidgets[SelectedLobbySetIndex]->GetLobbySetId();
		GetHUDStore().GetLobbySetManager().SelectLobbySetToUse(SelectedLobbySetId);

		ALobbyPlayerController* PlayerController = Cast<ALobbyPlayerController>(GetLocalPlayerController(this));
		if (PlayerController)
		{
			PlayerController->PlayerCameraManager->StartCameraFade(1.0f, 0.0f, 0.5f, FLinearColor::Black);
		}
	}
}


//////////////////////////////////////////////////////////////////////////////////
// ULobbySettingWidget

ULobbySettingWidget::ULobbySettingWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurLobbySetInfo()
	, bResetTemplate(false)
	, bResetCharacters(false)
	, SelectedCharacterSlotIndex(0)
{
}

void ULobbySettingWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* ClearButton = CastChecked<UButton>(GetWidgetFromName("BtnClear"));
	ClearButton->OnClicked.AddUniqueDynamic(this, &ULobbySettingWidget::OnClearButtonClicked);

	LobbySetListButton = CastChecked<UButton>(GetWidgetFromName("BtnLobbySetList"));
	LobbySetListButton->OnClicked.AddUniqueDynamic(this, &ULobbySettingWidget::OnLobbySetListButtonClicked);

	LobbySetIdText = CastChecked<UTextBlock>(GetWidgetFromName("TextLobbySetId"));
	LobbySetStateText = CastChecked<UTextBlock>(GetWidgetFromName("TextLobbySetState"));
	LobbySetEditImage = CastChecked<UImage>(GetWidgetFromName("ImgLobbySetEdit"));

	MainPanel = CastChecked<UCanvasPanel>(GetWidgetFromName("PanelMain"));

	for (int32 i = 0; i < MAX_LOBBY_TEMPLATE_CHAR_SLOT_COUNT; ++i)
	{
		FString SlotName = FString::Printf(TEXT("CharSlot%d"), i);
		ULobbyCharacterIconWidget* SlotWidget = CastChecked<ULobbyCharacterIconWidget>(GetWidgetFromName(*SlotName));
		SlotWidget->SetIndex(i);
		SlotWidget->OnSlotClickedDelegate.BindUObject(this, &ULobbySettingWidget::OnCharacterSlotClicked);
		SlotWidgets.AddUnique(SlotWidget);
	}

	EditSwitcher = CastChecked<UWidgetSwitcher>(GetWidgetFromName("Switcher"));

	EditTemplateWidget = CastChecked<ULobbySettingEditTemplateWidget>(GetWidgetFromName("EditTemplate"));
	EditTemplateWidget->OnTemplateChangedDelegate.BindUObject(this, &ULobbySettingWidget::OnTemplateChanged);
	EditTemplateWidget->OnClearCharacterDelegate.BindUObject(this, &ULobbySettingWidget::OnClearCharacterSetting);

	EditCharacterWidget = CastChecked<ULobbySettingEditCharacterWidget>(GetWidgetFromName("EditCharacter"));
	EditCharacterWidget->OnCharacterSlotClickedDelegate.BindUObject(this, &ULobbySettingWidget::OnEditCharacterSlotClicked);
	EditCharacterWidget->OnCharacterSettingDelegate.BindUObject(this, &ULobbySettingWidget::OnCharacterSetting);
	EditCharacterWidget->OnApplyLobbySettingDelegate.BindUObject(this, &ULobbySettingWidget::SaveLobbySetting);

	UButton* EditButton = CastChecked<UButton>(GetWidgetFromName("BtnEdit"));
	EditButton->OnClicked.AddUniqueDynamic(this, &ULobbySettingWidget::OnEditTemplateButtonClicked);
}

void ULobbySettingWidget::OnEnterMenu()
{
	Super::OnEnterMenu();

	SubscribeToStore(EHSType::Ui);
	SubscribeToStore(EHSType::LobbySet);

	LoadLobbySetting();
}

void ULobbySettingWidget::RefreshMenu()
{
	Super::RefreshMenu();

	const FLobbySettingUIState* UIState = GetUIState()->CastToLobbySettingUIState();
	check(UIState);

	SetLobbySettingMenu(UIState->EditType);
}

void ULobbySettingWidget::LoadLobbySetting()
{
	CurLobbySetInfo = GetHUDStore().GetLobbySetManager().GetSelectedLobbySetInfo();
}

void ULobbySettingWidget::SaveLobbySetting()
{
	ALobbyPlayerController* PlayerController = GetLobbyPlayerController(this);
	if (PlayerController)
	{
		PlayerController->ClearLobbyCharactersIntermediateState();
	}

	GetHUDStore().GetLobbySetManager().ReqLobbySetSave(CurLobbySetInfo);
}

void ULobbySettingWidget::SetLobbySetState(int32 InLobbySetId, const FText& InName)
{
	LobbySetIdText->SetText(FText::AsNumber(InLobbySetId));
	LobbySetStateText->SetText(InName);
	LobbySetEditImage->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	LobbySetListButton->SetVisibility(ESlateVisibility::Visible);
}

void ULobbySettingWidget::SetLobbySetEditting()
{
	LobbySetStateText->SetText(Q6Util::GetLocalizedText("Lobby", "LobbySetEditting"));
	LobbySetEditImage->SetVisibility(ESlateVisibility::Collapsed);
	LobbySetListButton->SetVisibility(ESlateVisibility::Collapsed);
}

void ULobbySettingWidget::SetLobbySettingMenu(ELobbySettingEditType InLobbySettingEditType)
{
	switch (InLobbySettingEditType)
	{
		case ELobbySettingEditType::EditTemplate:
			{
				SetLobbySetEditting();
				EditTemplateWidget->InitTemplateList(CurLobbySetInfo.LobbyTemplateId);
				EditSwitcher->SetActiveWidget(EditTemplateWidget);
			}
			break;
		case ELobbySettingEditType::EditCharacter:
			{
				SetLobbySetEditting();
				EditCharacterWidget->Init(CurLobbySetInfo, SelectedCharacterSlotIndex);
				EditSwitcher->SetActiveWidget(EditCharacterWidget);
			}
			break;
		default:
			{
				SetLobbySettingMain();
				EditSwitcher->SetActiveWidget(MainPanel);
			}
			break;
	}
}

void ULobbySettingWidget::SetLobbySettingMain()
{
	const FLobbySetInfo& SavedLobbySetInfo = GetHUDStore().GetLobbySetManager().GetSelectedLobbySetInfo();
	bResetTemplate = CurLobbySetInfo.LobbyTemplateId != SavedLobbySetInfo.LobbyTemplateId;
	bResetCharacters |= CurLobbySetInfo.LobbySetId != SavedLobbySetInfo.LobbySetId;

	if (bResetTemplate || bResetCharacters)
	{
		LoadLobbySetting();
	}

	const FLobbyTemplateInfo& CurLobbyTemplateInfo = GetHUDStore().GetLobbyTemplateManager().GetLobbyTemplateInfo(CurLobbySetInfo.LobbyTemplateId);
	const FCMSLobbyTemplateRow& CMSRow = GetCMS()->GetLobbyTemplateRowOrDummy(CurLobbyTemplateInfo.Type);
	const FLobbyTemplateAssetRow& AssetRow = GetGameResource().GetLobbyTemplateAssetRow(CurLobbyTemplateInfo.Type);
	ensure(CMSRow.SlotCount == AssetRow.SlotInfos.Num());

	SetLobbySetState(CurLobbySetInfo.LobbySetId, CMSRow.Name);

	for (int32 i = 0; i < SlotWidgets.Num(); ++i)
	{
		if (CurLobbySetInfo.CharacterIds.IsValidIndex(i))
		{
			SlotWidgets[i]->SetCharacter(CurLobbySetInfo.CharacterIds[i]);
		}
		else
		{
			SlotWidgets[i]->SetEmpty();
		}

		SlotWidgets[i]->SetVisibility(i < CMSRow.SlotCount ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}

	if (bResetTemplate)
	{
		EditTemplateWidget->SetSelectedTemplate(CurLobbySetInfo.LobbyTemplateId, CurLobbyTemplateInfo.Type);
	}

	ALobbyPlayerController* PlayerController = GetLobbyPlayerController(this);
	if (PlayerController)
	{
		if (bResetCharacters)
		{
			PlayerController->SetLobbyCharacters(CurLobbySetInfo.CharacterIds);
		}
		PlayerController->SetLobbyCharactersVisible(true);
		PlayerController->SetLobbyTemplateVisible(true);
	}
}

void ULobbySettingWidget::OnClearButtonClicked()
{
	bool bDimmedClear = CurLobbySetInfo.LobbyTemplateId.IsInvalid();
	GetCheckedLobbyHUD(this)->SetClearUI(true, true, bDimmedClear);
}

void ULobbySettingWidget::OnLobbySetListButtonClicked()
{
	ULobbySetListPopupWidget* LobbySetListPopup = CastChecked<ULobbySetListPopupWidget>(
		GetCheckedLobbyHUD(this)->OpenPopup(LobbySetListPopupWidgetClass));
	if (LobbySetListPopup)
	{
		LobbySetListPopup->SetLobbySetList();
	}
}

void ULobbySettingWidget::OnEditTemplateButtonClicked()
{
	ALobbyPlayerController* PlayerController = GetLobbyPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SetLobbyCharactersVisible(false);
	}

 	ACTION_DISPATCH_LobbySettingEditChange(ELobbySettingEditType::EditTemplate);
}

void ULobbySettingWidget::OnCharacterSlotClicked(int32 SlotIndex)
{
	SelectedCharacterSlotIndex = SlotIndex;

	ACTION_DISPATCH_LobbySettingEditChange(ELobbySettingEditType::EditCharacter);
}

void ULobbySettingWidget::OnTemplateChanged(FLobbyTemplateId InTemplateId, FLobbyTemplateType InTemplateType)
{
	ALobbyPlayerController* PlayerController = GetLobbyPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SetLobbyTemplate(InTemplateType);
	}

	CurLobbySetInfo.LobbyTemplateId = InTemplateId;
	bResetCharacters = true;
}

void ULobbySettingWidget::OnClearCharacterSetting()
{
	for (FCharacterId& CharacterId : CurLobbySetInfo.CharacterIds)
	{
		CharacterId = FCharacterId::InvalidValue();
	}

	bResetCharacters = true;
	SelectedCharacterSlotIndex = 0;

	ALobbyPlayerController* PlayerController = GetLobbyPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SetLobbyCharacters(CurLobbySetInfo.CharacterIds);
		PlayerController->SetLobbyCharactersVisible(true);
	}
}

void ULobbySettingWidget::OnCharacterSetting(FCharacterId InCharacterId, int32 InSlotIndex, int32 InSlotCount)
{
	bResetCharacters = true;

	int32 PrevSlotIndex = INDEX_NONE;
	if (!InCharacterId.IsInvalid())
	{
		CurLobbySetInfo.CharacterIds.Find(InCharacterId, PrevSlotIndex);
		PrevSlotIndex = PrevSlotIndex < InSlotCount ? PrevSlotIndex : INDEX_NONE;
	}

	FCharacterId PrevCharacterId = FCharacterId::InvalidValue();
	if (CurLobbySetInfo.CharacterIds.IsValidIndex(InSlotIndex))
	{
		if (InSlotIndex < InSlotCount)
		{
			PrevCharacterId = CurLobbySetInfo.CharacterIds[InSlotIndex];
			CurLobbySetInfo.CharacterIds[InSlotIndex] = InCharacterId;
		}
		else
		{
			CurLobbySetInfo.CharacterIds[InSlotIndex] = FCharacterId::InvalidValue();
		}
	}

	if (CurLobbySetInfo.CharacterIds.IsValidIndex(PrevSlotIndex))
	{
		CurLobbySetInfo.CharacterIds[PrevSlotIndex] = PrevCharacterId;
	}

	ALobbyPlayerController* PlayerController = GetLobbyPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SetLobbyCharacters(CurLobbySetInfo.CharacterIds);
		PlayerController->PlayLobbyCharacterWelcomeAnimation(InSlotIndex);
	}
}

void ULobbySettingWidget::OnEditCharacterSlotClicked(int32 InSlotIndex)
{
	ALobbyPlayerController* PlayerController = GetLobbyPlayerController(this);
	if (PlayerController)
	{
		PlayerController->SetLobbyTemplateCameraFocus(InSlotIndex);
	}
}

void ULobbySettingWidget::OnHSEvent(TSharedPtr<FHSAction> Action)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByLobbySetting);

	EHSActionType ActionType = Action->GetActionType();
	switch (ActionType)
	{
		case EHSActionType::LobbySetUseResp:
		case EHSActionType::LobbySetSaveResp:
			ACTION_DISPATCH_LobbySettingEditChange(ELobbySettingEditType::None);
			break;
		case EHSActionType::LobbySettingEditChange:
		case EHSActionType::DevLobbyTemplateNewResp:
		case EHSActionType::DevCharacterNewResp:
			RefreshMenu();
			break;
		default:
			break;
	}
}
