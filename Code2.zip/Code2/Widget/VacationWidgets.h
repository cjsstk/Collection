// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "LobbyMsg_gen.h"
#include "PopupWidgets.h"
#include "Q6Define.h"
#include "WonderWidgets.h"

#include "VacationWidgets.generated.h"

class UMaterialBoxWidget;
class UPointWidget;
class UQ6Button;
class UQ6TextBlock;
class USimpleItemCardWidget;
class UVacationResultWidget;
class UVacationStartConfirmPopupWidget;


struct FVacationResult
{
	FVacationResult() : ResultType(EUpgradeResultType::Fail) {}

	FVacationSpotType SpotType;
	FCharacterType CharacterType;
	EUpgradeResultType ResultType;

	FCharacterBond Bond;
	FCharacterBond OldBond;

	bool IsBondLevelUp() const { return (Bond.Level.x > OldBond.Level.x); }
};

UCLASS()
class Q6_API UVacationSpotWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetSpot(const FVacationSpot& VacationSpot);
	void SetSelected(bool bInSelected);
	void PlayStartAnimation();

	FSimpleDelegate OnSpotClickedDelegate;

private:
	UFUNCTION()
	void OnSelectButtonClicked();

	// Widgets

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* RemainDaysText;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UImage* NewMarkImage;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* SelectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DeselectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationEndLoopAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationStartAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationNowAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationReadyAnim;
};

UCLASS()
class Q6_API UVacationSpotEntryWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetSpot(const FCMSVacationSpotRow& SpotRow);

	FSimpleDelegate OnShortcutClickedDelegate;

private:
	UFUNCTION()
	void OnShortcutButtonClicked();

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UTextBlock* GainBondText;

	UPROPERTY()
	UQ6TextBlock* VacationDaysText;

	UPROPERTY()
	UTextBlock* OpenLevelText;

	UPROPERTY(Transient)
	TArray<UWidgetAnimation*> StateAnims;
};

UCLASS()
class Q6_API UVacationWidget : public UWonderMenuWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	virtual void SetWonder() override;
	virtual void RefreshUI() override;

	virtual void OnMenuEvent(TSharedPtr<FHSAction> InAction) override;

private:
	void SetVacationReady(FVacationSpotType SpotType);
	void SetVacationNow(const FVacationSpot& Spot, int32 RemainDays);
	void SetVacationEnded(const FVacationSpot& Spot);

	void SetCharacter(FCharacterType CharacterType);
	void SetVacationDetail(int32 InSelectedIdx);

	void SelectVacationSpot(int32 InSelectedIndex);

	UFUNCTION()
	void OnVacationButtonClicked();

	UFUNCTION()
	void OnSelectButtonClicked();

	UFUNCTION()
	void OnSpotListingButtonClicked();

	void OnSelectedSpot(int32 SpotIdx);
	void OnSelectedCharacter(int64 ItemId);

	// Widgets

	UPROPERTY()
	TArray<UVacationSpotWidget*> SpotWidgets;

	UPROPERTY()
	UImage* BGImage;

	UPROPERTY()
	UImage* CharacterImage;

	UPROPERTY()
	UQ6TextBlock* SpotNameText;

	UPROPERTY()
	UQ6TextBlock* BaseBondText;

	UPROPERTY()
	UBorder* BonusBorder;

	UPROPERTY()
	UQ6TextBlock* LevelBonusBondText;

	UPROPERTY()
	UQ6TextBlock* VacationTimeText;

	UPROPERTY()
	UQ6TextBlock* VacationDaysText;

	UPROPERTY()
	UQ6TextBlock* CharacterNameText;

	UPROPERTY()
	UCanvasPanel* MaterialsPanel;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UPointWidget* RequireGoldWidget;

	UPROPERTY()
	UPointWidget* OwnedGoldWidget;

	UPROPERTY()
	UQ6TextBlock* InfoText;

	UPROPERTY()
	UButton* VacationButton;

	UPROPERTY()
	UQ6TextBlock* VacationText;

	UPROPERTY()
	UQ6TextBlock* OwnedSpotCountText;

	// Animations

	UPROPERTY(Transient)
	UWidgetAnimation* CharacterSelectedAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationReadyAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationNowAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationEndLoopAnim;

	// Fields

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UVacationStartConfirmPopupWidget> VacationStartConfirmPopupClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UVacationResultWidget> VacationResultWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UVacationSpotListPopupWidget> VacationSpotListPopupWidgetClass;

	FCharacterId SelectedCharacterId;
	int32 SelectedIndex;
	bool bEndVacation;
	bool bEnoughMaterials;
};

UCLASS()
class Q6_API UVacationStartConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	
	void SetVacation(FCharacterId InCharacterId, int32 InSpotIndex);

	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option) override;

private:
	UPROPERTY()
	USimpleItemCardWidget* CharacterCardWidget;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* BaseBondText;

	UPROPERTY()
	UQ6TextBlock* LevelBonusBondText;

	UPROPERTY()
	UBorder* BonusBorder;

	UPROPERTY()
	UQ6TextBlock* VacationDaysText;

	UPROPERTY()
	UVerticalBox* MaterialsBox;

	UPROPERTY()
	UMaterialBoxWidget* MaterialsWidget;

	UPROPERTY()
	UQ6TextBlock* OwnedGoldText;

	UPROPERTY()
	UQ6TextBlock* RequireGoldText;

	int32 SpotIndex;
	FCharacterId CharacterId;
};

UCLASS()
class Q6_API UVacationResultWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetResult(const FVacationResult& InResult);

	FSimpleDelegate OnClosedDelegate;

private:
	UFUNCTION()
	void OnCloseButtonClicked();

	UPROPERTY()
	UProgressBar* BondBar;

	UPROPERTY()
	UBorder* TitleBorder;

	UPROPERTY()
	UTextBlock* TitleText;

	UPROPERTY()
	UQ6TextBlock* TemperatureText;

	UPROPERTY()
	UTextBlock* GainBondText;

	UPROPERTY()
	UImage* BondLevelUpImage;

	UPROPERTY(Transient)
	UWidgetAnimation* VacationResultAnim;
};

UCLASS()
class Q6_API UVacationSpotListPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetSpots(int32 VacationLevel);

private:
	UPROPERTY()
	UDynamicListWidget* VacationListWidget;
};
