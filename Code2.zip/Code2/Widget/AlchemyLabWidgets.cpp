#include "AlchemyLabWidgets.h"

#include "AlchemylabManager.h"
#include "BagItemManager.h"
#include "CommonWidgets.h"
#include "ItemWidgets.h"
#include "NewMarkManager.h"
#include "PointWidgets.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6Account.h"

DECLARE_CYCLE_STAT(TEXT("OnHSEvent AlchemyLab"), STAT_OnHSEventByAlchemyLab, STATGROUP_HSTORE);

//////////////////////////////////////////////////////////////////////////
// Research List Widget
//////////////////////////////////////////////////////////////////////////

UResearchListWidget::UResearchListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UResearchListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	UButton* SelectButton = CastChecked<UButton>(GetWidgetFromName("Select"));
	SelectButton->OnClicked.AddUniqueDynamic(this, &UResearchListWidget::OnSelectButtonClicked);

	ItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("Item"));
	ItemNameText = CastChecked<UTextBlock>(GetWidgetFromName("ItemName"));
	TimeText = CastChecked<UTextBlock>(GetWidgetFromName("Time"));
	OpenInfoText = CastChecked<UTextBlock>(GetWidgetFromName("OpenInfo"));

	IngTextBorder = CastChecked<UBorder>(GetWidgetFromName("InProgress"));

	MigriumPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("Point1"));
	MigriumPointWidget->SetPointType(EPointType::Migrium, EPointWidgetOption::LessEqual);

	GoldPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("Point2"));
	GoldPointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);
}

void UResearchListWidget::SetResearchList(const FCMSAlchemyLabRow* Row
	, const EAlchemyLabItemListPopupType Type)
{
	if (!Row)
	{
		return;
	}

	switch (Row->ProductCategory)
	{
		case EAlchemyProductCategory::Relic:		SetRelic(Row->ProductValue);		break;
		case EAlchemyProductCategory::Sculpture:	SetSculpture(Row->ProductValue);	break;
		case EAlchemyProductCategory::Lumicube:		SetLumicube();				break;
		default:
			check(false);
	}

	SetProductionTime(Row->ProductTime);
	SetMigrium(Row->MaterialValue);
	SetGold(Row->CostGold);
	SetOpenInfoText(FText::AsNumber(Row->Level));

	const FAlchemylabInfo& AlchemylabInfo = GetHUDStore().GetAlchemylabManager().GetAlchemylabInfo();
	if (Row->Level <= AlchemylabInfo.Level)
	{
		ResearchListState(EResearchListState::Opened);
	}
	else
	{
		ResearchListState(EResearchListState::Locked);
	}

	if (Type == EAlchemyLabItemListPopupType::Select)
	{
		IngTextBorder->SetVisibility(ESlateVisibility::Collapsed);
		ResearchListSelectState(EResearchListSelectState::None);
	}
	else
	{
		if (Row->Type == AlchemylabInfo.ProductType)
		{
			ResearchListViewState(EResearchListViewState::InProgress);
		}
		else
		{
			ResearchListViewState(EResearchListViewState::None);
		}
	}
}

void UResearchListWidget::SetRelic(const int32 ProductValue)
{
	const FCMSRelicRow& Product = GetCMS()->GetRelicRowOrDummy(FRelicType(ProductValue));
	if (Product.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSRelicRow", Q6KV("FRelicType", ProductValue));
		return;
	}

	SetItemNameText(Product.DescName);
	ItemWidget->SetRelic(Product.CmsType());
}

void UResearchListWidget::SetSculpture(const int32 ProductValue)
{
	const FCMSSculptureRow& Product = GetCMS()->GetSculptureRowOrDummy(FSculptureType(ProductValue));
	if (Product.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSSculptureRow", Q6KV("FSculptureType", ProductValue));
		return;
	}

	SetItemNameText(Product.DescName);
	ItemWidget->SetSculpture(Product.CmsType());
}

void UResearchListWidget::SetLumicube()
{
	SetItemNameText(Q6Util::GetLocalizedText("Common", "Lumicube"));

	ItemWidget->SetCurrency(ECurrencyType::Lumicube);
}

void UResearchListWidget::SetItemNameText(const FText& Text)
{
	ItemNameText->SetText(Text);
}

void UResearchListWidget::SetProductionTime(const int32 Minutes)
{
	TimeText->SetText(Q6Util::GetProductionTimeText(0, 0, Minutes, 0));
}

void UResearchListWidget::SetOpenInfoText(const FText& Text)
{
	OpenInfoText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "ResearchListLocked")
		, Text));
}

void UResearchListWidget::SetMigrium(const int32 Count)
{
	const FCMSAlchemyLabRow& AlchemyLabRow = GetCMS()->GetAlchemyLabRowOrDummy(FAlchemyLabType(1));
	if (AlchemyLabRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSAlchemyLabRow", Q6KV("FAlchemyLabType", 1));
		return;
	}

	const FCMSBagItemRow& BagItemRow = AlchemyLabRow.GetBagItem();
	if (BagItemRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist BagItemRow", Q6KV("FAlchemyLabType", 1));
		return;
	}

	const int32 BagItemCount = GetHUDStore().GetBagItemManager().GetBagItemCount(BagItemRow.CmsType());

	MigriumPointWidget->SetPoint(Count, BagItemCount);
}

void UResearchListWidget::SetGold(const int32 Gold)
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	GoldPointWidget->SetPoint(Gold, WorldUser.GetGold());
}

void UResearchListWidget::OnSelectButtonClicked()
{
	OnSelectButtonClickedDelegate.ExecuteIfBound();
}

//////////////////////////////////////////////////////////////////////////
// Alchemy Lab Item List Popup Widget
//////////////////////////////////////////////////////////////////////////

UAlchemyLabItemListPopupWidget::UAlchemyLabItemListPopupWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurrSelectedListWidget(nullptr)
	, PopupType(EAlchemyLabItemListPopupType::None)
{

}

void UAlchemyLabItemListPopupWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ResearchListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
}

void UAlchemyLabItemListPopupWidget::SetAlchemyLabItemList(const EAlchemyLabItemListPopupType Type)
{
	CurrSelectedListWidget = nullptr;
	PopupType = Type;

	ResearchListWidget->ClearList();
	TArray<const FCMSAlchemyLabRow*> AllList = GetCMS()->GetAlchemyLabRows();
	for (const FCMSAlchemyLabRow* Row : AllList)
	{
		if (!Row)
		{
			continue;
		}

		UResearchListWidget* ElemWidget = CastChecked<UResearchListWidget>(
			ResearchListWidget->AddChildAtLastIndex());

		ElemWidget->SetResearchList(Row, Type);
		ElemWidget->OnSelectButtonClickedDelegate.BindUObject(this
			, &UAlchemyLabItemListPopupWidget::OnAlchemyLabTypeSelected, Row->Type, ElemWidget);
	}

	switch (PopupType)
	{
		case EAlchemyLabItemListPopupType::Select:	SetSelectType();	break;
		case EAlchemyLabItemListPopupType::View:	SetViewType();		break;
		default:
			check(false);
	}
}

void UAlchemyLabItemListPopupWidget::SetSelectType()
{
	SetContent(Q6Util::GetLocalizedText("Popup", "ResearchListSelectContent"));

	SetYesButtonVisibility(ESlateVisibility::Visible);
	SetYesButtonEnabled(false);
}

void UAlchemyLabItemListPopupWidget::SetViewType()
{
	SetContent(Q6Util::GetLocalizedText("Popup", "ResearchListViewContent"));

	SetYesButtonVisibility(ESlateVisibility::Collapsed);
}

void UAlchemyLabItemListPopupWidget::OnAlchemyLabTypeSelected(const int32 Type
	, UResearchListWidget* SelectedWidget)
{
	if(CurrSelectedListWidget)
	{
		CurrSelectedListWidget->ResearchListSelectState(EResearchListSelectState::None);
	}

	CurrSelectedListWidget = SelectedWidget;

	if (CurrSelectedListWidget)
	{
		CurrSelectedListWidget->ResearchListSelectState(EResearchListSelectState::Selected);
	}

	OnSelectButtonClickedDelegate.ExecuteIfBound(Type);
}

//////////////////////////////////////////////////////////////////////////
// Alchemy Lab Widget
//////////////////////////////////////////////////////////////////////////
UAlchemyLabWidget::UAlchemyLabWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bButtonLock(false)
	, ResearchCount(0)
	, ReceiveProductCount(0)
	, EndProgressValue(0)
	, CurrProgressValue(0)
	, TotalRemainSeconds(0)
{

}

void UAlchemyLabWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MigriumPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPoint1"));
	MigriumPointWidget->SetPointType(EPointType::Migrium, EPointWidgetOption::NONE);

	GoldPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("OwnedPoint2"));
	GoldPointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::NONE);

	PlusButton = CastChecked<UButton>(GetWidgetFromName("BtnPlus"));
	PlusButton->OnClicked.AddUniqueDynamic(this, &UAlchemyLabWidget::OnPlusButtonClicked);

	MinusButton = CastChecked<UButton>(GetWidgetFromName("BtnMinus"));
	MinusButton->OnClicked.AddUniqueDynamic(this, &UAlchemyLabWidget::OnMinusButtonClicked);

	UButton* GetButton = CastChecked<UButton>(GetWidgetFromName("BtnGet"));
	GetButton->OnClicked.AddUniqueDynamic(this, &UAlchemyLabWidget::OnGetButtonClicked);

	UButton* ResearchListButton = CastChecked<UButton>(GetWidgetFromName("BtnResearchList"));
	ResearchListButton->OnClicked.AddUniqueDynamic(this, &UAlchemyLabWidget::OnResearchListButtonClicked);

	ResearchCountText = CastChecked<UTextBlock>(GetWidgetFromName("ResearchCount"));
	TotalTimerText = CastChecked<UTextBlock>(GetWidgetFromName("TotalTimer"));
	AmountText = CastChecked<UTextBlock>(GetWidgetFromName("TextAmount"));
	MaxText = CastChecked<UTextBlock>(GetWidgetFromName("TextMax"));
	RequireTimeText = CastChecked<UTextBlock>(GetWidgetFromName("Time"));

	SelectItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("SelectItem"));
	ProductItemWidget = CastChecked<UItemWidget>(GetWidgetFromName("ProductItem"));

	RequireMigriumPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequirePoint1"));
	RequireMigriumPointWidget->SetPointType(EPointType::Migrium, EPointWidgetOption::LessEqual);

	RequireGoldPointWidget = CastChecked<UPointWidget>(GetWidgetFromName("RequirePoint2"));
	RequireGoldPointWidget->SetPointType(EPointType::Gold, EPointWidgetOption::LessEqual);

	ProduceNewMarkImage = CastChecked<UImage>(GetWidgetFromName("ProduceNewMark"));
}

void UAlchemyLabWidget::NativeDestruct()
{
	FTimerManager& TimerManager = GetWorld()->GetTimerManager();
	TimerManager.ClearTimer(TimeHandle);

	Super::NativeDestruct();
}

void UAlchemyLabWidget::OnMenuEvent(TSharedPtr<FHSAction> InAction)
{
	SCOPE_CYCLE_COUNTER(STAT_OnHSEventByAlchemyLab);

	switch (InAction->GetActionType())
	{
		case EHSActionType::AlchemylabDecStockResp:
		case EHSActionType::AlchemylabIncStockResp:
		{
			Reset();
			bButtonLock = false;
		}
		break;
		case EHSActionType::AlchemylabProduceResp:
		case EHSActionType::AlchemylabUpgradeCompleteResp:
		case EHSActionType::AlchemylabUpgradeResp:
		{
			Reset();
		}
		break;
		case EHSActionType::AlchemylabReceiveResp:
		{
			UItemReceivedPopupWidget* ItemReceivedPopup = GetLobbyHUD(this)->OpenItemReceivedPopup();
			ItemReceivedPopup->SetAlchemyLabReceivedItem(MakeType, ReceiveProductCount);
			ItemReceivedPopup->OnPopupClosedDelegate.BindUObject(this
				, &UAlchemyLabWidget::OnItemReceivedPopupClosed);
		}
		break;
	}
}

void UAlchemyLabWidget::SetMigrium()
{
	const FCMSAlchemyLabRow& AlchemyLabRow = GetCMS()->GetAlchemyLabRowOrDummy(FAlchemyLabType(1));
	if (AlchemyLabRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSAlchemyLabRow", Q6KV("FAlchemyLabType", 1));
		return;
	}

	const FCMSBagItemRow& BagItemRow = AlchemyLabRow.GetBagItem();
	if (BagItemRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSBagItemRow", Q6KV("FAlchemyLabType", 1));
		return;
	}

	const int32 BagItemCount = GetHUDStore().GetBagItemManager().GetBagItemCount(BagItemRow.CmsType());

	MigriumPointWidget->SetCurPoint(BagItemCount);
}

void UAlchemyLabWidget::SetGold()
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	GoldPointWidget->SetCurPoint(WorldUser.GetGold());
}

void UAlchemyLabWidget::SetResearchCountText(const FText& Text)
{
	ResearchCountText->SetText(Text);
}

void UAlchemyLabWidget::SetAmountText(const FText& Text)
{
	AmountText->SetText(Text);
}

void UAlchemyLabWidget::SetMaxText(const FText& Text)
{
	MaxText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "MaxCount")
		, Text));
}

void UAlchemyLabWidget::SetRequireTimeText(const FText& Text)
{
	RequireTimeText->SetText(Text);
}

void UAlchemyLabWidget::SetRemainTime(const FAlchemylabInfo& AlchemylabInfo)
{
	const FCMSAlchemyLabRow& AlchemyLabRow = GetCMS()->GetAlchemyLabRowOrDummy(
		FAlchemyLabType(AlchemylabInfo.ProductType));
	if (AlchemyLabRow.IsInvalid())
	{
		return;
	}

	CurrProgressValue = FDateTime::UtcNow().ToUnixTimestamp() - AlchemylabInfo.StockTimeSec;
	EndProgressValue = AlchemyLabRow.ProductTime * 60;

	TotalRemainSeconds = AlchemylabInfo.StockTimeSec
		+ (AlchemyLabRow.ProductTime * 60 * AlchemylabInfo.Stock)
		- FDateTime::UtcNow().ToUnixTimestamp();

	FTimerManager& TimerManager = GetWorld()->GetTimerManager();
	TimerManager.ClearTimer(TimeHandle);

	TimerManager.SetTimer(TimeHandle, this, &UAlchemyLabWidget::SetAlchemyLabTimer, 1.0f, true, 0.0f);
}

void UAlchemyLabWidget::SetAlchemyLabTimer()
{
	if (EndProgressValue == 0)
	{
		FTimerManager& TimerManager = GetWorld()->GetTimerManager();
		TimerManager.ClearTimer(TimeHandle);

		return;
	}

	TotalTimerText->SetText(Q6Util::GetRemainTimeText(TotalRemainSeconds));
	--TotalRemainSeconds;

	SetResearchPorgressBar((float)CurrProgressValue / EndProgressValue);
	++CurrProgressValue;
}

void UAlchemyLabWidget::SetItemInfo(const int32 ProductType)
{
	const FCMSAlchemyLabRow& AlchemyLabRow = GetCMS()->GetAlchemyLabRowOrDummy(FAlchemyLabType(ProductType));
	if (AlchemyLabRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSAlchemyLabRow", Q6KV("FAlchemyLabType", ProductType));
		return;
	}

	switch(AlchemyLabRow.ProductCategory)
	{
		case EAlchemyProductCategory::Relic:		SetRelic(AlchemyLabRow);	break;
		case EAlchemyProductCategory::Sculpture:	SetSculpture(AlchemyLabRow);	break;
		case EAlchemyProductCategory::Lumicube:		SetLumicube(AlchemyLabRow);	break;
		default:
			check(false);
	}

	SetRequireMigriumPoint(AlchemyLabRow.MaterialValue);
	SetRequireGoldPoint(AlchemyLabRow.CostGold);

	SetRequireTimeText(Q6Util::GetProductionTimeText(0, 0, AlchemyLabRow.ProductTime, 0));
}

void UAlchemyLabWidget::SetRelic(const FCMSAlchemyLabRow& AlchemyLabRow)
{
	const FCMSRelicRow& Product = GetCMS()->GetRelicRowOrDummy(
		FRelicType(AlchemyLabRow.ProductValue));
	if (Product.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSRelicRow", Q6KV("FRelicType", AlchemyLabRow.ProductValue));
		return;
	}

	const FRelicType RelicType = Product.CmsType();
	SelectItemWidget->SetRelic(RelicType);

	const int32 ProductCount = GetHUDStore().GetAlchemylabManager().GetAlchemylabInfo().Product;
	ProductItemWidget->SetRelic(RelicType, ProductCount);
}

void UAlchemyLabWidget::SetSculpture(const FCMSAlchemyLabRow& AlchemyLabRow)
{
	const FCMSSculptureRow& Product = GetCMS()->GetSculptureRowOrDummy(
		FSculptureType(AlchemyLabRow.ProductValue));
	if (Product.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSSculptureRow", Q6KV("FSculptureType", AlchemyLabRow.ProductValue));
		return;
	}

	const FSculptureType SculptureType = Product.CmsType();
	SelectItemWidget->SetSculpture(SculptureType);

	const int32 ProductCount = GetHUDStore().GetAlchemylabManager().GetAlchemylabInfo().Product;
	ProductItemWidget->SetSculpture(SculptureType, ProductCount);
}

void UAlchemyLabWidget::SetLumicube(const FCMSAlchemyLabRow& AlchemyLabRow)
{
	SelectItemWidget->SetCurrency(ECurrencyType::Lumicube);

	const int32 ProductCount = GetHUDStore().GetAlchemylabManager().GetAlchemylabInfo().Product;
	ProductItemWidget->SetCurrency(ECurrencyType::Lumicube, ProductCount);
}

void UAlchemyLabWidget::SetRequireMigriumPoint(const int32 Count)
{
	const FCMSAlchemyLabRow& AlchemyLabRow = GetCMS()->GetAlchemyLabRowOrDummy(FAlchemyLabType(1));
	if (AlchemyLabRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSAlchemyLabRow", Q6KV("FAlchemyLabType", 1));
		return;
	}

	const FCMSBagItemRow& BagItemRow = AlchemyLabRow.GetBagItem();
	if (BagItemRow.IsInvalid())
	{
		Q6JsonLogGenie(Warning, "No Exist FCMSBagItemRow", Q6KV("FAlchemyLabType", 1));
		return;
	}

	const int32 BagItemCount = GetHUDStore().GetBagItemManager().GetBagItemCount(BagItemRow.CmsType());

	RequireMigriumPointWidget->SetPoint(Count, BagItemCount);
}

void UAlchemyLabWidget::SetRequireGoldPoint(const int32 Gold)
{
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();
	RequireGoldPointWidget->SetPoint(Gold, WorldUser.GetGold());
}

void UAlchemyLabWidget::SetNewMark(const FAlchemylabInfo& Info)
{
	const UNewMarkManager& NewMarkMgr = GetHUDStore().GetNewMarkManager();
	ESlateVisibility ProduceVisibility = NewMarkMgr.GetWonderAlchemyLabProductVisibility(Info, true);
	ProduceNewMarkImage->SetVisibility(ProduceVisibility);
}

void UAlchemyLabWidget::OnPlusButtonClicked()
{
	if (MakeType == 0)
	{
		return;
	}

	if (!GetHUDStore().CheckAlchemyLabStockCost(FAlchemyLabType(MakeType)))
	{
		return;
	}

	if (ResearchCount >= MAX_ALCHEMY_LAB_STOCK)
	{
		ResearchCount = MAX_ALCHEMY_LAB_STOCK;
		return;
	}

	bButtonLock = true;
	GetHUDStore().GetAlchemylabManager().ReqIncStock(FAlchemyLabType(MakeType));
}

void UAlchemyLabWidget::OnMinusButtonClicked()
{
	if (MakeType == 0)
	{
		return;
	}

	if (ResearchCount <= 0)
	{
		ResearchCount = 0;
		return;
	}

	if (ResearchCount == 1)
	{
		UConfirmPopupWidget* ConfirmPopupWidget = GetCheckedLobbyHUD(this)->OpenConfirmPopup(
			Q6Util::GetLocalizedText("Popup", "ResearchCancleTitle")
			, Q6Util::GetLocalizedText("Popup", "ResearchCancleContent")
		);
		ConfirmPopupWidget->OnConfirmPopupDelegate.BindLambda([](EConfirmPopupFlag Flag)
		{
			if (Flag == EConfirmPopupFlag::Yes)
			{
				GetHUDStore().GetAlchemylabManager().ReqDecStock();
			}
		});

		return;
	}

	bButtonLock = true;
	GetHUDStore().GetAlchemylabManager().ReqDecStock();
}

void UAlchemyLabWidget::OnGetButtonClicked()
{
	const UAlchemylabManager& AlchemylabManager = GetHUDStore().GetAlchemylabManager();
	ReceiveProductCount = AlchemylabManager.GetAlchemylabInfo().Product;

	if (GetCheckedLobbyHUD(this)->CheckMaxItemNum(ECurrencyCheckType::AlchemyLab, true))
	{
		return;
	}

	GetHUDStore().GetAlchemylabManager().ReqReceive();
}

void UAlchemyLabWidget::OnResearchListButtonClicked()
{
	const UAlchemylabManager& AlchemylabManager = GetHUDStore().GetAlchemylabManager();

	const EIncomeState ProductionState = AlchemylabManager.GetProductionState();
	if (ProductionState == EIncomeState::MaxStored)
	{
		return;
	}

	UAlchemyLabItemListPopupWidget* ItemListPopup = CastChecked<UAlchemyLabItemListPopupWidget>(
		GetCheckedLobbyHUD(this)->OpenPopup(ItemListPopupClass));
	ItemListPopup->OnSelectButtonClickedDelegate.BindUObject(this
		, &UAlchemyLabWidget::OnSelectButtonClicked, ItemListPopup);
	ItemListPopup->OnConfirmPopupDelegate.BindUObject(this
		, &UAlchemyLabWidget::OnAlchemyLabItemListPopupButtonClicked, ItemListPopup);

	switch (ProductionState)
	{
		case EIncomeState::NotStored:
		{
			ItemListPopup->SetAlchemyLabItemList(EAlchemyLabItemListPopupType::Select);
		}
		break;
		case EIncomeState::Stored:
		{
			ItemListPopup->SetAlchemyLabItemList(EAlchemyLabItemListPopupType::View);
		}
		break;
		default:
			check(false);
	}
}

void UAlchemyLabWidget::OnSelectButtonClicked(int32 Type, UAlchemyLabItemListPopupWidget* Widget)
{
	if (!GetHUDStore().CheckAlchemyLabStockCost(FAlchemyLabType(Type)))
	{
		if (Widget)
		{
			Widget->SetYesButtonEnabled(false);
		}
		return;
	}

	if (Widget)
	{
		Widget->SetYesButtonEnabled(true);
	}

	MakeType = Type;
}

void UAlchemyLabWidget::OnAlchemyLabItemListPopupButtonClicked(EConfirmPopupFlag Option
	, UAlchemyLabItemListPopupWidget* Widget)
{
	if (Option == EConfirmPopupFlag::No)
	{
		if (Widget)
		{
			if (Widget->GetPopupType() == EAlchemyLabItemListPopupType::Select)
			{
				MakeType = 0;
			}
		}

		return;
	}

	GetHUDStore().GetAlchemylabManager().ReqIncStock(FAlchemyLabType(MakeType));
}

void UAlchemyLabWidget::OnItemReceivedPopupClosed()
{
	Reset();
}

void UAlchemyLabWidget::SetWonder()
{
	Reset();
}

void UAlchemyLabWidget::Reset()
{
	const UAlchemylabManager& AlchemylabManager = GetHUDStore().GetAlchemylabManager();
	const FAlchemylabInfo& AlchemylabInfo = AlchemylabManager.GetAlchemylabInfo();

	ResearchCount = AlchemylabInfo.Stock;
	MakeType = AlchemylabInfo.ProductType;
	EndProgressValue = 0;

	SetMigrium();
	SetGold();
	SetResearchCountText(FText::AsNumber(ResearchCount));
	SetAmountText(FText::AsNumber(AlchemylabInfo.Product));
	SetMaxText(FText::AsNumber(AlchemylabInfo.Level));

	SetResearchPorgressBar(0.0f);

	const EIncomeState ProductionState = AlchemylabManager.GetProductionState();
	switch (ProductionState)
	{
		case EIncomeState::NotStored:
		{
			ResearchState(EAlchemyLabState::Empty);
		}
		break;
		case EIncomeState::Stored:
		{
			SetRemainTime(AlchemylabInfo);
			ResearchState(EAlchemyLabState::InProgress);
		}
		break;
		case EIncomeState::MaxStored:
		{
			ResearchState(EAlchemyLabState::Complete);
		}
		break;
		default:
			check(false);
	}

	SetItemInfo(MakeType);

	bool bCanStock = GetHUDStore().CheckAlchemyLabStockCost(FAlchemyLabType(MakeType));
	MinusButton->SetIsEnabled(ResearchCount != 0);
	PlusButton->SetIsEnabled(bCanStock
		&& (AlchemylabInfo.Product + AlchemylabInfo.Stock < AlchemylabInfo.Level)
		&& ProductionState != EIncomeState::MaxStored);

	ResearchResultItemState(AlchemylabInfo.Product > 0
		, ProductionState == EIncomeState::MaxStored);

	SetNewMark(AlchemylabInfo);
}

void UAlchemyLabWidget::RefreshUI()
{
	Reset();
}
