// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMS_gen.h"
#include "PopupWidgets.h"
#include "Q6UIDefine.h"
#include "UMG.h"

#include "PointWidgets.generated.h"

enum class EPointType : uint8;
enum class EPointWidgetOption : uint8;

UENUM()
enum class EWattRechargePointType : uint8
{
	SmallBattery = 0,
	MediumBattery,
	LargeBattery,
	StoredWater,
	Gem,
	Max,
};

class UItemWidget;
class UQ6TextBlock;
class URichTextBlock;
class UWattRechargeConfirmPopupWidget;

UCLASS()
class Q6_API UPointWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPointWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	int64 GetCurPoint() const { return CurPoint; }
	int64 GetMaxPoint() const { return MaxPoint; }

	void SetPointType(EPointType InPointType, EPointWidgetOption InPointWidgetOption);
	void SetPointType(ESummonPointType InPointType, EPointWidgetOption InPointWidgetOption);
	void SetPointType(ECurrencyType InPointType, EPointWidgetOption InPointWidgetOption);
	void SetEventPointType(FEventContentType InEventContentType, int32 InPointIndex, EPointWidgetOption InPointWidgetOption);
	void SetEventWattType(EEventContentCategory InEventContentCategory, EPointWidgetOption InPointWidgetOption);

	void SetPoint(int64 InCurPoint, int64 InMaxPoint);
	void SetCurPoint(int64 InCurPoint);
	void SetMaxPoint(int64 InMaxPoint);
	void SetPointColor();
private:
	bool IsCompLessThan() const { return static_cast<uint8>(PointWidgetOption) & static_cast<uint8>(EPointWidgetOption::CompLessThan); }
	bool IsIncludeEqual() const { return static_cast<uint8>(PointWidgetOption) & static_cast<uint8>(EPointWidgetOption::IncludeEqual); }
	bool IsChangeColor() const { return static_cast<uint8>(PointWidgetOption) & static_cast<uint8>(EPointWidgetOption::ChangeColor); }
	bool IsVisibleMaxPoint() const { return static_cast<uint8>(PointWidgetOption) & static_cast<uint8>(EPointWidgetOption::VisibleMaxPoint); }

	void SetType(EPointType InPointType, EPointWidgetOption InPointWidgetOption);

	UPROPERTY(EditInstanceOnly)
	EPointType PointType;

	UPROPERTY()
	UImage* IconImage;

	UPROPERTY()
	UTextBlock* PointAmountText;

	UPROPERTY()
	UTextBlock* PointMaxText;

	EPointWidgetOption PointWidgetOption;
	int64 CurPoint;
	int64 MaxPoint;
};

UCLASS()
class Q6_API UPointNameWidget : public UPointWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPointName(EPointType InPointType);

	FSimpleDelegate OnSelectedDelegate;
private:
	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY()
	UTextBlock* PointNameText;
};


UCLASS()
class Q6_API UPointButtonWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPointButtonWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetMyPoint(int64 InMyPoint);
	void SetPoint(int64 InNeedAmount, int64 InMyAmount);
	void SetName(const FText& ButtonName);
	void SetPointType(EPointType PointType, EPointWidgetOption InPointWidgetOption);
	void SetEventWattType(EEventContentCategory InEventContentCategory, EPointWidgetOption InPointWidgetOption);

	int64 GetMyPoint() const;
	int64 GetNeedPoint() const;
	bool IsEnoughPoint();

	FSimpleDelegate OnPointButtonClickedDelegate;

private:
	UFUNCTION()
	void OnActionButtonClicked();

	UPROPERTY()
	UButton* ActionButton;

	UPROPERTY()
	UTextBlock* LabelText;

	UPROPERTY()
	UPointWidget* PointWidget;
};


UCLASS()
class Q6_API UPointPlusWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UPointPlusWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetCurPoint(int64 InCurPoint);
	void SetPoint(int64 InCurPoint, int64 InMaxPoint);
	void SetPointType(EPointType InPointType, EPointWidgetOption InPointWidgetOption);

	FSimpleDelegate OnPointButtonClickedDelegate;

private:
	UFUNCTION()
	void OnPlusButtonClicked();

	UPROPERTY()
	UButton* PlusButton;

	UPROPERTY()
	UPointWidget* PointWidget;

	int64 CurAmount;
	int64 TotAmount;
};



UCLASS()
class Q6_API UWattRechargePointWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPoint(EWattRechargePointType RechargePointType);

	FSimpleDelegate OnPointSelectedDelegate;

private:
	void SetRechargeInfo(EWattRechargePointType RechargePointType, int32 OwnedCount, int32 RechargeAmount, int32 RechargePercent = 0, int32 RequreCount = 1);
	EPointType ConvertToPointType(EWattRechargePointType RechargePointType) const;

	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY()
	UImage* DisabledImage;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UQ6TextBlock* NameText;

	UPROPERTY()
	UQ6TextBlock* OwnedCountText;

	UPROPERTY()
	URichTextBlock* InfoText;
};

UCLASS()
class Q6_API UWattRechargePointSelectPopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetPointList();

private:
	void OnRechargePointSelected(EWattRechargePointType PointType);
	void OnWattRechargeConfirmed(EConfirmPopupFlag Flag);

	UPROPERTY()
	TArray<UWattRechargePointWidget*> PointWidgets;

	UPROPERTY()
	UPointWidget* OwnedWattWidget;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UWattRechargeConfirmPopupWidget> WattRechargeConfirmPopupClass;
};

UCLASS()
class Q6_API UWattRechargeConfirmPopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	void SetRechargePoint(EWattRechargePointType InPointType);

	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Flag) override;

private:
	void RefreshWatt();
	EBatteryType ConvertRechargePointToBattery(EWattRechargePointType InPointType) const;
	int32 GetRechargeWattPerCount(EWattRechargePointType InPointType);

	UFUNCTION()
	void OnPlusButtonClicked();

	UFUNCTION()
	void OnMinusButtonClicked();

	UPROPERTY()
	UWattRechargePointWidget* RechargePointWidget;

	UPROPERTY()
	UPointWidget* CurWattWidget;

	UPROPERTY()
	UPointWidget* ResultWattWidget;

	UPROPERTY()
	UQ6TextBlock* RechargeCountText;

	UPROPERTY()
	UButton* PlusButton;

	UPROPERTY()
	UButton* MinusButton;

	EWattRechargePointType PointType;
	int32 RechargeCount;
	int32 MaxCount;
};
