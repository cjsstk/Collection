// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "TutorialWidget.h"

#include "HUD/BaseHUD.h"
#include "LevelUtil.h"
#include "Q6.h"
#include "Q6Capture2D.h"
#include "Utils/Q6Util.h"
#include "Utils/WidgetUtil.h"
#include "Components/RichTextBlock.h"

#if !UE_BUILD_SHIPPING
static TAutoConsoleVariable<int32> CVarQ6TutorialHoleDefferingCount(
	TEXT("q6.tutorialHoleDeferringCount"),
	2,
	TEXT("Tutorial Widget Hole Show after this console variable ticks"),
	ECVF_Cheat);
#else
static const int32 TUTORIAL_HOLE_DEFERRING_COUNT = 2;
#endif

void UTutorialWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DimmingButtons[0] = Cast<UButton>(GetWidgetFromName("DimmingButton0"));
	DimmingButtons[1] = Cast<UButton>(GetWidgetFromName("DimmingButton1"));
	DimmingButtons[2] = Cast<UButton>(GetWidgetFromName("DimmingButton2"));
	DimmingButtons[3] = Cast<UButton>(GetWidgetFromName("DimmingButton3"));
	ensure(DimmingButtons[0]);
	ensure(DimmingButtons[1]);
	ensure(DimmingButtons[2]);
	ensure(DimmingButtons[3]);
	for (int32 i = 0; i < 4; ++i)
	{
		DimmingButtons[i]->OnClicked.AddUniqueDynamic(this, &UTutorialWidget::OnDimmingButtonClicked);
	}

	UWidget* HoleWidget = GetWidgetFromName("Hole");
	if (HoleWidget)
	{
		HoleWidget->SetVisibility(ESlateVisibility::HitTestInvisible);
	}

	TouchCount = 0;
	DeferredHoleTickCount = -1;
}

void UTutorialWidget::OnDimmingButtonClicked()
{
	CountTouch();
}

FReply UTutorialWidget::NativeOnFocusReceived(const FGeometry& InGeometry, const FFocusEvent& InFocusEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnPreviewMouseButtonDown(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnMouseButtonUp(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnMouseMove(const FGeometry& InGeometry, const FPointerEvent& InMouseEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnTouchGesture(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnTouchStarted(const FGeometry& InGeokmetry, const FPointerEvent& InGestureEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnTouchMoved(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	return FReply::Unhandled();
}

FReply UTutorialWidget::NativeOnTouchEnded(const FGeometry& InGeometry, const FPointerEvent& InGestureEvent)
{
	return FReply::Unhandled();
}

void UTutorialWidget::ShowHole(FString HoleName)
{
	Q6JsonLogBro(Verbose, "TutorialWidget Show Hole", Q6KV("HoleName", *HoleName));
	SetDeferredHoleInternal(HoleName);
}

void UTutorialWidget::SetDeferredHoleInternal(const FString& InHoleName)
{
	// !!CAUTION
	// Visibility Changed and SafeZone size is 0.
	// after 1 tick - SafeZone Size calculated, but geometry still 0.
	// after 2 tick - TutorialWidget can get the right size of Hole Widget.
	// this is why I postpone hole widget's showing timing.
	DeferredHoleTickCount = 0;
	DeferredHoleName = InHoleName;
	BlockScreen();
}

void UTutorialWidget::BlockScreen()
{
	Q6JsonLogBro(Verbose, "TutorialWidget Block Screen");
	InitTutorialWidgetInternal(nullptr, false);
}

void UTutorialWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	if (DeferredHoleTickCount >= 0)
	{
		++DeferredHoleTickCount;

#if !UE_BUILD_SHIPPING
		if (DeferredHoleTickCount >= CVarQ6TutorialHoleDefferingCount.GetValueOnAnyThread())
#else
		if (DeferredHoleTickCount >= TUTORIAL_HOLE_DEFERRING_COUNT)
#endif
		{
			DeferredHoleTickCount = -1;
			UWidget* HoleWidget = GetWidgetFromName(*DeferredHoleName);
			InitTutorialWidgetInternal(HoleWidget, true);
		}
	}
}

void UTutorialWidget::InitTutorialWidget(bool bShowHall)
{
	if (bShowHall)
	{
		SetDeferredHoleInternal("Hole");
	}
	else
	{
		BlockScreen();
	}
}

void UTutorialWidget::InitTutorialWidgetInternal(UWidget* HoleWidget, bool bShowHall)
{
	ABaseTutorial* InBaseTutorial = GetBaseTutorial(this);
	if (InBaseTutorial)
	{
		SetProtection(InBaseTutorial->IsProtected());
	}

	UCanvasPanelSlot* Slot0 = Cast<UCanvasPanelSlot>(DimmingButtons[0]->Slot);
	UCanvasPanelSlot* Slot1 = Cast<UCanvasPanelSlot>(DimmingButtons[1]->Slot);
	UCanvasPanelSlot* Slot2 = Cast<UCanvasPanelSlot>(DimmingButtons[2]->Slot);
	UCanvasPanelSlot* Slot3 = Cast<UCanvasPanelSlot>(DimmingButtons[3]->Slot);
	TouchCount = 0;

	if (!bShowHall)
	{
		// block screen.
		Slot0->SetSize(FVector2D(0, 100));
		Slot1->SetSize(FVector2D(0, 0));
		Slot2->SetSize(FVector2D(0, 0));
		Slot3->SetPosition(FVector2D(0, 100));
		Q6JsonLogBro(Verbose, "TutorialWidget Screen Blocked");
		return;
	}

	if (!HoleWidget)
	{
		Q6JsonLogBro(Warning, "TutorialWidget HoleWidget Not Found");
		return;
	}

	UCanvasPanelSlot* HoleSlot = Cast<UCanvasPanelSlot>(HoleWidget->Slot);

	FGeometry Geom;
	if (!FindWidgetGeometry(HoleWidget, &Geom))
	{
		Q6JsonLogBro(Warning, "TutorialWidget HoleWidget Geometry Not Found");
		return;
	}

	FVector2D HolePosition = Geom.Position;
	FVector2D HoleSize = Geom.Size;

	Slot0->SetSize(FVector2D(0, HolePosition.Y));

	Slot1->SetPosition(FVector2D(0, HolePosition.Y));
	Slot1->SetSize(FVector2D(HolePosition.X, HoleSize.Y));

	Slot2->SetPosition(FVector2D(HolePosition.X + HoleSize.X, HolePosition.Y));
	Slot2->SetSize(FVector2D(0, HoleSize.Y));

	Slot3->SetPosition(FVector2D(0, HolePosition.Y + HoleSize.Y));
	UE_LOG(Q6, Verbose, TEXT("Tutorial Hole Created Size(%3.1f,%3.1f), Position(%3.1f,%3.1f)"), HoleSize.X, HoleSize.Y, HolePosition.X, HolePosition.Y);
}

void UTutorialWidget::CountTouch()
{
	TouchCount++;
#if !UE_BUILD_SHIPPING
	if (TouchCount > 20)
	{
		SetProtection(false);

		ABaseTutorial* InBaseTutorial = GetBaseTutorial(this);
		if (InBaseTutorial)
		{
			InBaseTutorial->SetProtectionMode(false);
		}

		ABaseHUD* BaseHUD = Cast<ABaseHUD>(GetLocalPlayerController(this)->GetHUD());
		if (BaseHUD)
		{
			BaseHUD->OnAlert(FText::FromString(FString("Open Sesame!")));
		}
	}
#endif
}

void UTutorialWidget::SetProtection(bool bInProtect)
{
	for (int32 i = 0; i < 4; ++i)
	{
		DimmingButtons[i]->SetVisibility(bInProtect ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	}
}

void UTutorialEntryWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

void UTutorialEntryWidget::Proceed()
{
	ABaseTutorial* InBaseTutorial = GetBaseTutorial(this);
	if (InBaseTutorial)
	{
		InBaseTutorial->Proceed("TutorialEntry");
	}
}

void UTutorialEntryWidget::ReserveLobbyTutorialOnInit(ELobbyTutorial InTutorialStep, int32 InStep)
{
	ALobbyTutorial* InLobbyTutorial = GetLobbyTutorial(this);
	if (!InLobbyTutorial)
	{
		return;
	}

	InLobbyTutorial->ReserveTutorialOnInit(InTutorialStep, InStep);
}

void UTutorialEntryWidget::EndCurrentTutorial()
{
	ABaseTutorial* InBaseTutorial = GetBaseTutorial(this);
	if (InBaseTutorial)
	{
		InBaseTutorial->EndCurrentTutorial();
	}
}

void UTutorialEntryWidget::JumpToStep(int32 InStep)
{
	ABaseTutorial* InBaseTutorial = GetBaseTutorial(this);
	if (InBaseTutorial)
	{
		InBaseTutorial->SetStep(InStep);
	}
}

FTutorialGuideAssetRow UTutorialEntryWidget::GetTutorialGuideAsset(FString KeyString) const
{
	return GetGameResource().GetTutorialGuideAssetRow(KeyString);
}

void UTutorialsWidget::NativeConstruct()
{
	Super::NativeConstruct();

	Entries.Empty();
	MaxStep = 0;
	bPaused = false;
	CurrentStep = 0; // 0 means no tutorials are currently showing.
	// Entries is 1-base.
	Entries.Add(nullptr);
	for (int i = 1; i < MAX_TUTORIAL_STEP; ++i)
	{
		FString WidgetName = FString::Printf(TEXT("Step%d"), i);
		UTutorialEntryWidget* TutorialWidget = Cast<UTutorialEntryWidget>(GetWidgetFromName(FName(*WidgetName)));
		if (!TutorialWidget)
		{
			break;
		}

		TutorialWidget->SetVisibility(ESlateVisibility::Collapsed);
		Entries.Add(TutorialWidget);
		MaxStep = i;
	}
}

void UTutorialsWidget::NativeDestruct()
{
	Super::NativeDestruct();
}

void UTutorialsWidget::SetStep(int32 InStep)
{
	if (InStep > MaxStep)
	{
		EndTutorials();
		return;
	}

	RefreshUIByStep(InStep);
}

void UTutorialsWidget::PauseStep()
{
	bPaused = true;
	for (int32 i = 1; i <= MaxStep; ++i)
	{
		if (Entries.IsValidIndex(i))
		{
			Entries[i]->SetVisibility(ESlateVisibility::Collapsed);
			if (i == CurrentStep)
			{
				Entries[i]->OnPaused();
			}
		}
	}
}

void UTutorialsWidget::ProceedStep(FString InSource)
{
	if (bPaused)
	{
		if (this->GetClass()->IsFunctionImplementedInScript(FName("CanResumeTutorial")))
		{
			if (!CanResumeTutorial(CurrentStep, FName(*InSource)))
			{
				return;
			}
		}

		bPaused = false;
		RefreshUIByStep(CurrentStep);
		return;
	}

	if (BlockProceedStepOrNot(CurrentStep, FName(*InSource)))
	{
		return;
	}

	if (CurrentStep >= MaxStep)
	{
		EndTutorials();
		return;
	}

	RefreshUIByStep(CurrentStep + 1);
}

void UTutorialsWidget::EndTutorials()
{
	EndTutorialsDelegate.ExecuteIfBound();
}

FSimpleDelegate& UTutorialsWidget::GetEndTutorialsDelegate()
{
	return EndTutorialsDelegate;
}

void UTutorialsWidget::RefreshUIByStep(int32 InNewStep)
{
	bool bStepChanged = (InNewStep != CurrentStep);
	int32 OldStep = CurrentStep;
	CurrentStep = InNewStep;
	for (int32 i = 1; i <= MaxStep; ++i)
	{
		if (!Entries.IsValidIndex(i))
		{
			return;
		}

		if (i == CurrentStep)
		{
			Entries[i]->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
			if (bStepChanged)
			{
				Entries[i]->Start();
			}
			else
			{
				Entries[i]->OnResumed();
			}
		}
		else
		{
			Entries[i]->SetVisibility(ESlateVisibility::Collapsed);
			if (i == OldStep && bStepChanged)
			{
				Entries[OldStep]->OnEnded();
			}
		}
	}
}

void UTutorialCaptureWidget::NativeConstruct()
{
	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));
	DialogueText = CastChecked<URichTextBlock>(GetWidgetFromName("Dialogue"));

	UButton* YesButton = CastChecked<UButton>(GetWidgetFromName("Yes"));
	YesButton->OnClicked.AddUniqueDynamic(this
		, &UTutorialCaptureWidget::OnYesButtonClicked);

	UButton* NoButton = CastChecked<UButton>(GetWidgetFromName("No"));
	NoButton->OnClicked.AddUniqueDynamic(this
		, &UTutorialCaptureWidget::OnNoButtonClicked);

	VisibleState = Icon3DMode = false;
	TutorialDialogue = -1;
}

void UTutorialCaptureWidget::BindCapture(int32 InTutorialDialogue)
{
	TutorialDialogue = InTutorialDialogue;
	const FTutorialDialogueAssetRow& TutorialDialogueAssetRow = GetGameResource().GetTutorialDialogueAssetRow(TutorialDialogue);

	NameText->SetText(TutorialDialogueAssetRow.Name);
	DialogueText->SetText(TutorialDialogueAssetRow.Dialogue);

	Icon3DMode = TutorialDialogueAssetRow.IconTexture.IsNull();

	if (!Icon3DMode)
	{
		IconImage->SetBrushFromSoftTextureWhenLoadingFinished(TutorialDialogueAssetRow.IconTexture);
	}
	else
	{
		if (AQ6Capture2D* CaptureActor = GetGameResource().SpawnOrGetTutorialDialogueCapture(GetWorld()))
		{
			const FCaptureAssetRow& CaptureAssetRow = GetGameResource().GetCaptureAssetRow(TutorialDialogueAssetRow.CaptureAssetType);
			ULevelUtil::BindMeshModel(GetWorld(), CaptureActor, CaptureAssetRow.ModelType);
			CaptureActor->GetMesh()->SetRelativeTransform(CaptureAssetRow.MeshTransform);
			CaptureActor->GetMesh()->PlayAnimation(CaptureAssetRow.Motion.LoadSynchronous(), true);
			if (CaptureActor->GetMID())
			{
				IconImage->SetBrushFromMaterial(CaptureActor->GetMID());
			}
			else
			{
				IconImage->SetBrushResourceObject(CaptureActor->GetRenderTarget());
			}
		}
	}

	OnCaptureVisibleStateChangedBP(Icon3DMode);
}

void UTutorialCaptureWidget::BindGuideCapture(int32 InGuideDialogue)
{
	const FGuideDialogueAssetRow* GuideDialogueAssetRow = GetGameResource().GetGuideDialogueAssetRow(InGuideDialogue);
	if (!GuideDialogueAssetRow)
	{
		return;
	}

	// I don't know why the captureModelType was originally 0.
	BindBreakdownCapture(Q6Util::GetLocalizedText("Tutorial", "GuideAnnouncerName"), GuideDialogueAssetRow->Dialogue, 0);
}

void UTutorialCaptureWidget::BindBreakdownCapture(FText InSpeaker, FText InBubble, int32 InCaptureModelType)
{
	NameText->SetText(InSpeaker);
	DialogueText->SetText(InBubble);

	if (AQ6Capture2D* CaptureActor = GetGameResource().SpawnOrGetTutorialDialogueCapture(GetWorld()))
	{
		const FCaptureAssetRow& CaptureAssetRow = GetGameResource().GetCaptureAssetRow(InCaptureModelType);
		ULevelUtil::BindMeshModel(GetWorld(), CaptureActor, CaptureAssetRow.ModelType);
		CaptureActor->GetMesh()->SetRelativeTransform(CaptureAssetRow.MeshTransform);
		CaptureActor->GetMesh()->PlayAnimation(CaptureAssetRow.Motion.LoadSynchronous(), true);
		if (CaptureActor->GetMID())
		{
			IconImage->SetBrushFromMaterial(CaptureActor->GetMID());
		}
		else
		{
			IconImage->SetBrushResourceObject(CaptureActor->GetRenderTarget());
		}
	}

	ULevelUtil::SetCurrentCaptureActor(GetWorld(), true, "Capture.Tutorial");
}

void UTutorialCaptureWidget::OnCaptureVisibleStateChangedBP(bool bVisible)
{
	if (TutorialDialogue == -1 || !Icon3DMode)
	{
		return;
	}

	ULevelUtil::SetCurrentCaptureActor(GetWorld(), bVisible & Icon3DMode, "Capture.Tutorial");
}

void UTutorialCaptureWidget::SetGuideInfo(const FRewardStep& RewardStep)
{
	BindGuideCapture(static_cast<int32>(RewardStep.ContentFeatureOpenType));
}

void UTutorialCaptureWidget::OnYesButtonClicked()
{
	OnGuideBtnClickedDelegate.ExecuteIfBound(true);
}

void UTutorialCaptureWidget::OnNoButtonClicked()
{
	OnGuideBtnClickedDelegate.ExecuteIfBound(false);
}
