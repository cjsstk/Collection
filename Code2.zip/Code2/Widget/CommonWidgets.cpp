// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CommonWidgets.h"

#include "BaseWidget.h"
#include "CMS/CMSTable.h"
#include "GameResource.h"
#include "CombatHUD.h"
#include "LobbyHUD.h"
#include "LobbyHUDWidget.h"
#include "Components/SafeZone.h"
#include "StageWidgets.h"
#include "PointWidgets.h"
#include "ItemWidgets.h"
#include "Q6.h"
#include "Q6LobbyState.h"
#include "Q6UIDefine.h"
#include "Q6Account.h"
#include "Q6GameInstance.h"
#include "Framework/Text/RichTextLayoutMarshaller.h"
#include "Widgets/SInvalidationPanel.h"
#include "WidgetUtil.h"
#include "HUDStore.h"
#include "HSAction.h"
#include "CombatPresenter.h"

///////////////////////////////////////////////////////////////////////////////////////////
// UQ6Button

UQ6Button::UQ6Button(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	EnabledTime = 0.0f;
	LongClickTimeSec = 0.5;
}

void UQ6Button::OnWidgetRebuilt()
{
	Super::OnWidgetRebuilt();

	OnClicked.AddUniqueDynamic(this, &UQ6Button::OnButtonClicked);
	OnPressed.AddUniqueDynamic(this, &UQ6Button::OnButtonPressed);
	OnReleased.AddUniqueDynamic(this, &UQ6Button::OnButtonReleased);
}

void UQ6Button::SetIsEnabled(bool bInIsEnabled)
{
	Super::SetIsEnabled(bInIsEnabled);

	GetWorld()->GetTimerManager().ClearTimer(ButtonEnableTimerHandle);
}

void UQ6Button::OnButtonClicked()
{
	OnClickedDelegate.ExecuteIfBound();

	if (!FMath::IsNearlyZero(EnabledTime))
	{
		SetIsEnabled(false);
	}

	if (EnabledTime <= 0.0f)
	{
		// If disabled, wait for manual without limit
		return;
	}

	GetWorld()->GetTimerManager().SetTimer(ButtonEnableTimerHandle, this, &UQ6Button::OnButtonEnableTime, EnabledTime, false);
}

void UQ6Button::OnButtonPressed()
{
	PressedTimeSec = FPlatformTime::Seconds();
}

void UQ6Button::OnButtonReleased()
{
	if (!IsHovered())
	{
		return;
	}

	if (FPlatformTime::Seconds() - PressedTimeSec > LongClickTimeSec)
	{
		OnLongClickedDelegate.ExecuteIfBound();
	}
}

void UQ6Button::OnButtonEnableTime()
{
	SetIsEnabled(true);
}

///////////////////////////////////////////////////////////////////////////////////////////
// UQ6TextBlock

UQ6TextBlock::UQ6TextBlock()
{
	if (!IsRunningDedicatedServer())
	{
		static ConstructorHelpers::FObjectFinder<UFont> NotoSansFontObj(TEXT("/Game/Fonts/GameFont"));
		Font = FSlateFontInfo(NotoSansFontObj.Object, 30, FName("Bold"));
	}
}

#if WITH_EDITOR

void UQ6TextBlock::OnCreationFromPalette()
{
	Text = FText::AsCultureInvariant(Text);
}

#endif

///////////////////////////////////////////////////////////////////////////////////////////
// UQ6RichTextBlock

UQ6RichTextBlock::UQ6RichTextBlock(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	if (!IsRunningDedicatedServer())
	{
		static ConstructorHelpers::FObjectFinder<UFont> NotoSansFontObj(TEXT("/Game/Fonts/GameFont"));
		DefaultTextStyle.Font = FSlateFontInfo(NotoSansFontObj.Object, 30, FName("Bold"));
	}
}

#if WITH_EDITOR

void UQ6RichTextBlock::OnCreationFromPalette()
{
	Text = FText::AsCultureInvariant(Text);
}

#endif

///////////////////////////////////////////////////////////////////////////////////////////
// UBlackoutWidget

UBlackoutWidget::UBlackoutWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, BlackoutType(EBlackoutType::None)
	, bShowing(false)
	, bWorking(false)
{

}

void UBlackoutWidget::NativeConstruct()
{
	Super::NativeConstruct();

	int32 NumAnims = (int32)EBlackoutType::Max;

	ShowAnims.SetNum(NumAnims);
	ShowAnims[0] = nullptr;
	ShowAnims[1] = GetWidgetAnimationFromName(this, "AnimOpacityFillOn");
	ShowAnims[2] = GetWidgetAnimationFromName(this, "AnimSlideFillOn");
	ShowAnims[3] = GetWidgetAnimationFromName(this, "AnimSlideOutLeft");
	ShowAnims[4] = GetWidgetAnimationFromName(this, "AnimSlideOutRight");
	ShowAnims[5] = GetWidgetAnimationFromName(this, "AnimBlinkAndOpen");
	ShowAnims[6] = GetWidgetAnimationFromName(this, "AnimBlinkAndClose");
	ShowAnims[7] = GetWidgetAnimationFromName(this, "AnimLogin");
	ShowAnims[8] = GetWidgetAnimationFromName(this, "AnimLogout");
	ShowAnims[9] = GetWidgetAnimationFromName(this, "AnimRoundFillOn");
	ShowAnims[10] = GetWidgetAnimationFromName(this, "AnimChatModeOn");
	ShowAnims[11] = GetWidgetAnimationFromName(this, "AnimOpacityFillWhiteOn");
	ShowAnims[12] = GetWidgetAnimationFromName(this, "AnimSlideFillWhiteOn");
	ShowAnims[13] = nullptr;
	ShowAnims[14] = nullptr;
	ShowAnims[15] = GetWidgetAnimationFromName(this, "AnimBlinkAndOpenWhite");
	ShowAnims[16] = GetWidgetAnimationFromName(this, "AnimBlinkAndCloseWhite");

	HideAnims.SetNum(NumAnims);
	HideAnims[0] = nullptr;
	HideAnims[1] = GetWidgetAnimationFromName(this, "AnimOpacityFillOff");
	HideAnims[2] = GetWidgetAnimationFromName(this, "AnimSlideFillOff");
	HideAnims[3] = nullptr;
	HideAnims[4] = nullptr;
	HideAnims[5] = nullptr;
	HideAnims[6] = GetWidgetAnimationFromName(this, "AnimOpacityFillOff");
	HideAnims[7] = nullptr;
	HideAnims[8] = nullptr;
	HideAnims[9] = GetWidgetAnimationFromName(this, "AnimRoundFillOff");
	HideAnims[10] = nullptr;
	HideAnims[11] = GetWidgetAnimationFromName(this, "AnimOpacityFillWhiteOff");
	HideAnims[12] = GetWidgetAnimationFromName(this, "AnimSlideFillWhiteOff");
	HideAnims[13] = nullptr;
	HideAnims[14] = nullptr;
	HideAnims[15] = nullptr;
	HideAnims[16] = GetWidgetAnimationFromName(this, "AnimOpacityFillWhiteOff");
}

void UBlackoutWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (IsShowing())
	{
		if (OnBlackoutShowingDelegate.IsBound())
		{
			OnBlackoutShowingDelegate.Execute(true);
		}
		else
		{
			HideBlackout();
		}
	}
	else
	{
		OnBlackoutFinishedDelegate.ExecuteIfBound(true);
		bWorking = false;
	}
}

void UBlackoutWidget::ShowBlackout(EBlackoutType InBlackoutType)
{
	BlackoutType = InBlackoutType;
	bShowing = true;
	bWorking = true;

	if (!IsInViewport())
	{
		AddToViewport(ZORDER_BLACKOUT);
	}

	PlayAnimation(ShowAnims[(int32)BlackoutType]);
}

void UBlackoutWidget::HideBlackout()
{
	bShowing = false;

	if (HideAnims[(int32)BlackoutType])
	{
		PlayAnimation(HideAnims[(int32)BlackoutType]);
	}
	else
	{
		OnAnimationFinished_Implementation(nullptr);
	}
}

void UBlackoutWidget::StopBlackout()
{
	if (!IsWorking())
	{
		return;
	}

	int32 AnimIndex = (int32)BlackoutType;

	if (IsShowing())
	{
		StopAnimation(ShowAnims[AnimIndex]);
	}

	StopAnimation(HideAnims[AnimIndex]);
	RemoveFromViewport();
}

///////////////////////////////////////////////////////////////////////////////////////////
// UNotificationWidget

UNotificationWidget::UNotificationWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UNotificationWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ShowAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimShowShort"));
	ShowAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimShowLong"));
	ShowAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimShowLoop"));
	check(ShowAnims.Num() == (int32)ENotificationType::Max);

	NotifyText = CastChecked<URichTextBlock>(GetWidgetFromName("Notify"));
}

void UNotificationWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	if (NotiIndex >= NotifyTexts.Num())
	{
		if (Animation != ShowAnims[(uint8)ENotificationType::Loop])
		{
			HideNotification();
			return;
		}

		NotiIndex = 0;
	}

	ShowNotificationInternal();
}

void UNotificationWidget::ShowNotification(ENotificationType InNotiType, const FText& Text)
{
	ClearNotifications();

	NotiType = InNotiType;
	NotifyTexts.Add(Text);

	ShowNotificationInternal();
}

void UNotificationWidget::ShowNotifications(ENotificationType InNotiType, const TArray<FText>& Texts)
{
	ClearNotifications();

	NotiType = InNotiType;
	NotifyTexts = Texts;

	if (NotifyTexts.Num() > 0)
	{
		ShowNotificationInternal();
	}
}

void UNotificationWidget::HideNotification()
{
	RemoveFromParent();
}

void UNotificationWidget::ClearNotifications()
{
	NotiIndex = 0;
	NotifyTexts.Reset();
}

void UNotificationWidget::ShowNotificationInternal()
{
	if (!IsInViewport())
	{
		AddToViewport(ZORDER_NOTIFICATION);
	}

	if (ShowAnims.IsValidIndex((int32)NotiType) && NotifyTexts.IsValidIndex(NotiIndex))
	{
		PlayAnimation(ShowAnims[(int32)NotiType]);
		NotifyText->SetText(NotifyTexts[NotiIndex++]);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// UMissionGaugeWidget

UMissionGaugeWidget::UMissionGaugeWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UMissionGaugeWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MissionDetailText = CastChecked<UTextBlock>(GetWidgetFromName("MissionDetail"));
	MissionCountText = CastChecked<UTextBlock>(GetWidgetFromName("MissionCount"));

	CurrentProgressBar = CastChecked<UProgressBar>(GetWidgetFromName("CurrentProgress"));
	PastProgressBar = CastChecked<UProgressBar>(GetWidgetFromName("PastProgress"));

	MissionGaugeAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimStateFull"));
	MissionGaugeAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimStateToast"));
	MissionGaugeAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimStatePage"));
	check(MissionGaugeAnims.Num() == static_cast<int32>(EMissionGaugeType::Max));
}

void UMissionGaugeWidget::SetInfo(const FText& Detail, const int32 Past
	, const int32 Curr, const int32 Max, const bool bPage)
{
	SetMissionDetailText(Detail);
	SetMissionCount(Curr, Max);
	SetProgress(Past, Curr, Max);

	if (bPage)
	{
		PlayMissionGaugeAnim(EMissionGaugeType::Page);
	}
	else
	{
		if (Curr == Max)
		{
			PlayMissionGaugeAnim(EMissionGaugeType::Full);
		}
		else
		{
			PlayMissionGaugeAnim(EMissionGaugeType::Toast);
		}
	}
}

void UMissionGaugeWidget::SetMissionDetailText(const FText& Detail)
{
	MissionDetailText->SetText(Detail);
}

void UMissionGaugeWidget::SetMissionCount(const int32 Curr, const int32 Max)
{
	MissionCountText->SetText(FText::Format(
		Q6Util::GetLocalizedText("Lobby", "MissionCount")
		, FText::AsNumber(Curr)
		, FText::AsNumber(Max)));
}

void UMissionGaugeWidget::SetProgress(const int32 Past, const int32 Curr, const int32 Max)
{
	check(Max > 0);

	float PastPersent = FMath::Clamp(static_cast<float>(Past) / Max, 0.0f, 1.0f);
	float CurrPersent = FMath::Clamp(static_cast<float>(Curr) / Max, 0.0f, 1.0f);

	PastProgressBar->SetPercent(PastPersent);
	CurrentProgressBar->SetPercent(CurrPersent);
}

void UMissionGaugeWidget::PlayMissionGaugeAnim(EMissionGaugeType Type)
{
	int32 AnimIndex = static_cast<int32>(Type);
	if (MissionGaugeAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(MissionGaugeAnims[AnimIndex]);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// UMissionToastWidget

UMissionToastWidget::UMissionToastWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{

}

void UMissionToastWidget::NativeConstruct()
{
	Super::NativeConstruct();

	MissionToastAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimToastStart"));
	MissionToastAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimToastStateNormal"));
	MissionToastAnims.AddUnique(GetWidgetAnimationFromName(this, "AnimToastStateFull"));
	check(MissionToastAnims.Num() == static_cast<int32>(EMissionToastType::Max));

	MissionGaugeWidget = CastChecked<UMissionGaugeWidget>(GetWidgetFromName("MissionGauge"));

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
}

void UMissionToastWidget::OnAnimationFinished_Implementation(const UWidgetAnimation* Animation)
{
	const int32 AnimIndex = static_cast<int32>(EMissionToastType::Start);
	if (MissionToastAnims.IsValidIndex(AnimIndex)
		&& MissionToastAnims[AnimIndex] == Animation)
	{
		RemoveFromParent();
	}
}

void UMissionToastWidget::ShowMissionToast(const FWeeklyMissionToastInfo& InWeeklyMission)
{
	if (!IsInViewport())
	{
		AddToViewport(ZORDER_MISSION_TOAST);
	}

	PlayMissionToast(InWeeklyMission);
}

void UMissionToastWidget::PlayMissionToast(const FWeeklyMissionToastInfo& InWeeklyMission)
{
	const FCMSMissionRow& MissionRow = GetCMS()->GetMissionRowOrDummy(InWeeklyMission.Type);
	if (MissionRow.IsInvalid())
	{
		Q6JsonLogGenie(Error, "no exist mission type", Q6KV("type", InWeeklyMission.Type));
		return;
	}

	const FSlateBrush& MissionIcon = GetUIResource().GetMissionToastIcon(
		EMissionToastIconType::WeeklyMission);
	IconImage->SetBrush(MissionIcon);

	MissionGaugeWidget->SetInfo(MissionRow.Desc
		, InWeeklyMission.BeforeValue
		, InWeeklyMission.CurrValue
		, InWeeklyMission.MaxValue
		, false);

	PlayMissionToastAnim(EMissionToastType::Start);
	if (InWeeklyMission.BeforeValue == InWeeklyMission.CurrValue)
	{
		PlayMissionToastAnim(EMissionToastType::Full);
	}
	else
	{
		PlayMissionToastAnim(EMissionToastType::Normal);
	}
}

void UMissionToastWidget::PlayMissionToastAnim(EMissionToastType Type)
{
	const int32 AnimIndex = static_cast<int32>(Type);
	if (MissionToastAnims.IsValidIndex(AnimIndex))
	{
		PlayAnimation(MissionToastAnims[AnimIndex]);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// UDynamicListWidget

UDynamicListWidget::UDynamicListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ScrollOrientation(EScrollOrientation::Vertical)
	, ElementsPerLine(1)
	, PanelPadding(0.0f, 20.0f, 0.0f, 60.0f)
	, ChildSlotPadding(10.0f)
	, PanelHorizontalAlignment(HAlign_Left)
	, LastIndex(INDEX_NONE)
	, StandStillScrollCount(0)
	, bBlockScrollEvent(false)
{

}

void UDynamicListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	check(ElementsPerLine > 0);

	ScrollBox = CastChecked<UScrollBox>(GetWidgetFromName("Scroll"));
	ScrollBox->SetOrientation((EOrientation)ScrollOrientation);
	ScrollBox->OnUserScrolled.AddDynamic(this, &UDynamicListWidget::OnUserScrolled);

	ElementsPanel = CastChecked<UUniformGridPanel>(GetWidgetFromName("Elements"));
	UButtonSlot* PanelSlot = CastChecked<UButtonSlot>(ElementsPanel->Slot);
	PanelSlot->SetPadding(PanelPadding);
	PanelSlot->SetHorizontalAlignment(PanelHorizontalAlignment);
	ElementsPanel->SetSlotPadding(ChildSlotPadding);
	ElementsPanel->ClearChildren();
}

void UDynamicListWidget::NativeDestruct()
{
	ScrollBox->OnUserScrolled.Clear();
	Super::NativeDestruct();
}

void UDynamicListWidget::OnUserScrolled(float InCurrentOffset)
{
	if (FMath::IsNearlyEqual(OldScrollOffset, InCurrentOffset, KINDA_SMALL_NUMBER))
	{
		OldScrollOffset = InCurrentOffset;
		++StandStillScrollCount;

		if (StandStillScrollCount > 5)
		{
			if (!bBlockScrollEvent)
			{
				if (FMath::IsNearlyZero(OldScrollOffset))
				{
					OnScrolledAtStart.ExecuteIfBound();
				}
				else
				{
					OnScrolledAtEnd.ExecuteIfBound();
				}
				bBlockScrollEvent = true;
			}
			StandStillScrollCount = 0;
		}
		return;
	}

	bBlockScrollEvent = false;

	OldScrollOffset = InCurrentOffset;
	StandStillScrollCount = 0;
}

void UDynamicListWidget::ScrollToStart()
{
	ScrollBox->ScrollToStart();
}

void UDynamicListWidget::ScrollToEnd()
{
	ScrollBox->ScrollToEnd();
}

void UDynamicListWidget::FocusAtIndex(int32 Index)
{
	UWidget* ChildWidget = FindChildAt(Index);
	if (!ChildWidget)
	{
		Q6JsonLogGunny(Warning, "UDynamicListWidget::FocusAtIndex - ChildWidget does not exist.",
			Q6KV("Index", Index));
		return;
	}

	ScrollBox->ScrollWidgetIntoView(ChildWidget);
}

void UDynamicListWidget::ClearList()
{
	LastIndex = INDEX_NONE;
	ElementsPanel->ClearChildren();
}

UWidget* UDynamicListWidget::FindChildAt(int32 Index)
{
	if (ElementWidgets.IsValidIndex(Index))
	{
		return ElementWidgets[Index];
	}

	return nullptr;
}

UWidget* UDynamicListWidget::FindOrAddChild(int32 Index)
{
	UWidget* Widget = FindChildAt(Index);
	if (!Widget)
	{
		Widget = NewObject<UWidget>(this, ElementWidgetClass.LoadSynchronous());
		ElementWidgets.Add(Widget);
	}

	int32 ElementIndex = ElementsPanel->GetChildIndex(Widget);
	if (ElementIndex != INDEX_NONE)
	{
		return Widget;
	}

	++LastIndex;
	SetElementSlot(Widget, LastIndex);

	return Widget;
}

UWidget* UDynamicListWidget::AddChildAtLastIndex()
{
	return FindOrAddChild(LastIndex + 1);
}

bool UDynamicListWidget::RemoveChildAt(int32 RemoveIndex)
{
	if (!ElementsPanel->RemoveChildAt(RemoveIndex))
	{
		return false;
	}

	UWidget* ElementWidget = nullptr;
	for (int32 i = RemoveIndex + 1; i < ElementWidgets.Num(); ++i)
	{
		ElementWidget = ElementWidgets[i];
		SetElementSlot(ElementWidget, i - 1);	// Shift left
	}

	--LastIndex;

	return true;
}

void UDynamicListWidget::SetElementSlot(UWidget* ElementWidget, int32 Index)
{
	int32 ColumnIndex = INDEX_NONE;
	int32 RowIndex = INDEX_NONE;
	if (ScrollOrientation == EScrollOrientation::Vertical)
	{
		ColumnIndex = (Index % ElementsPerLine);
		RowIndex = (Index / ElementsPerLine);
	}
	else if (ScrollOrientation == EScrollOrientation::Horizontal)
	{
		ColumnIndex = (Index / ElementsPerLine);
		RowIndex = (Index % ElementsPerLine);
	}

	UUniformGridSlot* ElementSlot = ElementsPanel->AddChildToUniformGrid(ElementWidget);
	check(ElementSlot);

	ElementSlot->SetColumn(ColumnIndex);
	ElementSlot->SetRow(RowIndex);
}

UItemDropListWidget::UItemDropListWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UItemDropListWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ItemListWidget = CastChecked<UDynamicListWidget>(GetWidgetFromName("ItemList"));
}

void UItemDropListWidget::SetItemDropInfo()
{
	GetCheckedCombatHUD(this)->SetItemDropInfo();

	if (!GetCheckedCombatHUD(this)->HasItemDrop())
	{
		ItemListWidget->SetVisibility(ESlateVisibility::Collapsed);
	}
	else
	{
		const TArray<FDropBox>& DropBoxes = GetCheckedCombatHUD(this)->GetDropBoxes();
		const TArray<FDropCurrency>& DropCurrencies = GetCheckedCombatHUD(this)->GetDropCurrencies();

		const FCCCombatSeed& CombatSeed = GetCheckedCombatPresenter(this)->GetCombatSeed();
		const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(CombatSeed.SagaType);

		int32 DropBoxIndex = 0;

		ItemListWidget->ClearList();

		if (DropBoxes.Num() > 0)
		{
			for (const FDropBox& DropBox : DropBoxes)
			{
				UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->FindOrAddChild(DropBoxIndex++));
				ItemWidget->SetDropBox(SagaRow.DropBoxSet, DropBox.Grade, DropBox.Count);
			}
		}

		if (DropCurrencies.Num() > 0)
		{
			for (const FDropCurrency& DropCurreny : DropCurrencies)
			{
				UItemWidget* ItemWidget = CastChecked<UItemWidget>(ItemListWidget->FindOrAddChild(DropBoxIndex++));
				ItemWidget->SetCurrency(DropCurreny.Type, DropCurreny.Count);
			}
		}

		ItemListWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	}
}

UToggleButtonWidget::UToggleButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UToggleButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	ToggleButton = CastChecked<UCheckBox>(GetWidgetFromName("Toggle"));
	ToggleButton->OnCheckStateChanged.AddUniqueDynamic(this, &UToggleButtonWidget::OnToggleButtonClicked);

	NameText = CastChecked<UTextBlock>(GetWidgetFromName("Name"));

	NewMarkImage = Cast<UImage>(GetWidgetFromName("NewMark"));	// Nullable
}

void UToggleButtonWidget::SetButtonName(const FText& InButtonName)
{
	NameText->SetText(InButtonName);
}

void UToggleButtonWidget::SetChecked(bool bInChecked)
{
	ToggleButton->SetIsChecked(bInChecked);

	SetCheckedBP(bInChecked);
}

void UToggleButtonWidget::SetNewMarkVisibility(ESlateVisibility InVisibility)
{
	if (NewMarkImage)
	{
		NewMarkImage->SetVisibility(InVisibility);
	}
}

bool UToggleButtonWidget::GetChecked() const
{
	return ToggleButton->IsChecked();
}

void UToggleButtonWidget::OnToggleButtonClicked(bool bInChecked)
{
	OnToggleButtonClickedDelegate.ExecuteIfBound();
}

void UToggleButtonWidget::SetCheckedBP_Implementation(bool bInIsChecked)
{
	ToggleButton->SetIsChecked(bInIsChecked);
}

void UIconToggleButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	IconImage = CastChecked<UImage>(GetWidgetFromName("Icon"));
}

void UIconToggleButtonWidget::SetIcon(const FSlateBrush& IconBrush)
{
	IconImage->SetBrush(IconBrush);
}

void UIconToggleButtonWidget::SetIcon(const TSoftObjectPtr<UTexture2D>& IconTexture)
{
	IconImage->SetBrushFromTexture(IconTexture.LoadSynchronous());
}

UToggleButtonBoxWidget::UToggleButtonBoxWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ButtonSpacing(FVector2D(10.f, 10.f))
{
}

bool UToggleButtonBoxWidget::Initialize()
{
	if (!Super::Initialize())
	{
		return false;
	}

	ToggleButtonBox = Cast<UQ6DynamicEntryBox>(GetWidgetFromName("ToggleButtons"));

#if WITH_EDITORONLY_DATA
	if (ToggleButtonBox)
	{
		ToggleButtonBox->NumDesignerPreviewEntries = ButtonNames.Num();
	}
#endif

	return true;
}

void UToggleButtonBoxWidget::NativeConstruct()
{
	Super::NativeConstruct();

	check(ToggleButtonBox);

	InitToggleButtons();
}

void UToggleButtonBoxWidget::InitToggleButtons()
{
	SelectedIndex = INDEX_NONE;

	ToggleButtonBox->Reset(true);
	ToggleButtonBox->SetEntryHorizontalAlignment(ButtonHorizontalAlignment);
	ToggleButtonBox->SetEntryValticalAlignment(ButtonVerticalAlignment);
	ToggleButtonBox->SetEntrySizeRule(ButtonSizeRule);
	ToggleButtonBox->SetEntrySpacing(ButtonSpacing);

	for (int32 i = 0; i < ButtonNames.Num(); ++i)
	{
		const FText& ButtonName = ButtonNames[i];

		 UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(CreateButtonWidget(ToggleButtonWidgetClass));
		 if (UIconToggleButtonWidget* IconToggleButton = Cast<UIconToggleButtonWidget>(ToggleButton))
		 {
			 if (ButtonIconBrushes.IsValidIndex(i))
			 {
				 IconToggleButton->SetIcon(ButtonIconBrushes[i]);
			 }
		 }

		 ToggleButton->SetButtonName(ButtonName);
		 ToggleButton->SetChecked(false);
		 ToggleButton->OnToggleButtonClickedDelegate.BindUObject(this, &UToggleButtonBoxWidget::SetSelectedIndex, i);
	}
}

void UToggleButtonBoxWidget::SetSelectedIndexInternal(int32 ButtonIndex)
{
	const TArray<UUserWidget*>& ToggleButtons = ToggleButtonBox->GetAllEntries();

	for (int32 i = 0; i < ToggleButtons.Num(); ++i)
	{
		UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(ToggleButtons[i]);

		if (i == SelectedIndex)
		{
			ToggleButton->SetChecked(false);
		}

		if (i == ButtonIndex)
		{
			ToggleButton->SetChecked(true);
		}
	}

	SelectedIndex = ButtonIndex;
}

void UToggleButtonBoxWidget::InitSelectedIndex(int32 ButtonIndex)
{
	SetSelectedIndexInternal(ButtonIndex);

	OnToggleButtonChangedDelegate.ExecuteIfBound(SelectedIndex);
	OnToggleButtonClickedDelegate.ExecuteIfBound(SelectedIndex);
}

void UToggleButtonBoxWidget::SetSelectedIndex(int32 ButtonIndex)
{
	bool bChanged = SelectedIndex != ButtonIndex;
	SetSelectedIndexInternal(ButtonIndex);

	if (bChanged)
	{
		OnToggleButtonChangedDelegate.ExecuteIfBound(SelectedIndex);
	}

	OnToggleButtonClickedDelegate.ExecuteIfBound(SelectedIndex);
}

void UToggleButtonBoxWidget::SetSelectedIndexNoDelegate(int32 ButtonIndex)
{
	SetSelectedIndexInternal(ButtonIndex);
}

const TArray<UUserWidget*>& UToggleButtonBoxWidget::GetToggleButtons() const
{ 
	return ToggleButtonBox->GetAllEntries();
}

void UToggleButtonBoxWidget::SetToggleButtonBoxInternal(const TArray<FText>& InButtonNames)
{
	SelectedIndex = INDEX_NONE;
	ButtonNames = InButtonNames;

	ToggleButtonBox->Reset(true);
	for (int i = 0; i < InButtonNames.Num(); ++i)
	{
		const FText& ButtonName = InButtonNames[i];

		UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(CreateButtonWidget(ToggleButtonWidgetClass));
		ToggleButton->SetButtonName(ButtonName);
		ToggleButton->SetChecked(false);
		ToggleButton->SetIsEnabled(true);
		ToggleButton->OnToggleButtonClickedDelegate.BindUObject(this, &UToggleButtonBoxWidget::SetSelectedIndex, i);
	}
}

void UToggleButtonBoxWidget::SetToggleButtonBox(const TArray<FText>& InButtonNames, const TArray<ESlateVisibility>& InNewMarkVisibilities)
{
	check(InButtonNames.Num() == InNewMarkVisibilities.Num());

	SetToggleButtonBoxInternal(InButtonNames);

	const TArray<UUserWidget*>& ToggleButtons = ToggleButtonBox->GetAllEntries();
	for (int i = 0; i < ToggleButtons.Num(); ++i)
	{
		UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(ToggleButtons[i]);
		ToggleButton->SetNewMarkVisibility(InNewMarkVisibilities[i]);
	}
}

void UToggleButtonBoxWidget::SetToggleButtonBox(const TArray<FText>& InButtonNames, const TArray<TSoftObjectPtr<UTexture2D>>& InIconTextures)
{
	check(InButtonNames.Num() == InIconTextures.Num());

	SetToggleButtonBoxInternal(InButtonNames);

	const TArray<UUserWidget*>& ToggleButtons = ToggleButtonBox->GetAllEntries();
	for (int i = 0; i < ToggleButtons.Num(); ++i)
	{
		UIconToggleButtonWidget* IconToggleButton = CastChecked<UIconToggleButtonWidget>(ToggleButtons[i]);
		IconToggleButton->SetIcon(InIconTextures[i]);
	}
}

void UToggleButtonBoxWidget::SetButtonEnabled(int32 ButtonIndex, bool bInEnabled)
{
	TArray<UUserWidget*> ChildWidgets = ToggleButtonBox->GetAllEntries();
	if (ChildWidgets.IsValidIndex(ButtonIndex))
	{
		ChildWidgets[ButtonIndex]->SetIsEnabled(bInEnabled);
	}
}

void UToggleButtonBoxWidget::SetToggleButtonNewMark(int32 ButtonIndex, bool bNewly)
{
	TArray<UUserWidget*> ChildWidgets = ToggleButtonBox->GetAllEntries();
	if (ChildWidgets.IsValidIndex(ButtonIndex))
	{
		UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(ChildWidgets[ButtonIndex]);
		ToggleButton->SetNewMarkVisibility(bNewly ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void UToggleButtonBoxWidget::SetToggleButtonNewMark(int32 ButtonIndex, ESlateVisibility InVisibility)
{
	TArray<UUserWidget*> ChildWidgets = ToggleButtonBox->GetAllEntries();
	if (ChildWidgets.IsValidIndex(ButtonIndex))
	{
		UToggleButtonWidget* ToggleButton = CastChecked<UToggleButtonWidget>(ChildWidgets[ButtonIndex]);
		ToggleButton->SetNewMarkVisibility(InVisibility);
	}
}

UNetworkProgressWidget::UNetworkProgressWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UNetworkProgressWidget::NativeConstruct()
{
	Super::NativeConstruct();

	StatusText = Cast<UTextBlock>(GetWidgetFromName("Status"));
	ensure(StatusText);
}

void UNetworkProgressWidget::Show(FText Message)
{
	SetVisibility(ESlateVisibility::SelfHitTestInvisible);
	StatusText->SetText(Message);
}

void UNetworkProgressWidget::Hide()
{
	SetVisibility(ESlateVisibility::Collapsed);
}

UNatureButtonWidget::UNatureButtonWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UNatureButtonWidget::NativeConstruct()
{
	Super::NativeConstruct();

	CheckedAnim = GetWidgetAnimationFromName(this, "AnimChecked");
	check(CheckedAnim);

	UncheckedAnim = GetWidgetAnimationFromName(this, "AnimUnchecked");
	check(UncheckedAnim);

	ToggleCheckBox = CastChecked<UCheckBox>(GetWidgetFromName("Toggle"));
	SetStyle(ButtonStyle);

	ToggleCheckBox->OnCheckStateChanged.AddUniqueDynamic(this, &UNatureButtonWidget::OnToggleButtonClicked);
}

void UNatureButtonWidget::SetStyle(const FCheckBoxStyle& InStyle)
{
	ButtonStyle = InStyle;
	ToggleCheckBox->WidgetStyle = ButtonStyle;
}

void UNatureButtonWidget::SetChecked(bool bInChecked)
{
	ToggleCheckBox->SetIsChecked(bInChecked);

	if (bInChecked)
	{
		PlayAnimation(CheckedAnim, 0.0f, 0);
	}
	else
	{
		StopAnimation(CheckedAnim);
		PlayAnimation(UncheckedAnim);
	}
}

void UNatureButtonWidget::OnToggleButtonClicked(bool bInChecked)
{
	OnToggleButtonClickedDelegate.ExecuteIfBound();
}

UNatureTabWidget::UNatureTabWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

const char* UNatureTabWidget::GetWidgetNameFromIdx(int32 Idx)
{
	switch (static_cast<EJokerSlotType>(Idx))
	{
		case EJokerSlotType::All: return "All";
		case EJokerSlotType::Fire: return "Fire";
		case EJokerSlotType::Water: return "Water";
		case EJokerSlotType::Wind: return "Wind";
		case EJokerSlotType::Light: return "Light";
		case EJokerSlotType::Dark: return "Dark";
	}
	check(false);
	return "";
}

void UNatureTabWidget::NativeConstruct()
{
	Super::NativeConstruct();

	SelectedIndex = static_cast<int32>(EJokerSlotType::All);

	NatureButtonWidgets.SetNum(EJokerSlotTypeMax);
	for (int i = 0; i < EJokerSlotTypeMax; ++i)
	{
		auto ToggleButton = CastChecked<UNatureButtonWidget>(GetWidgetFromName(GetWidgetNameFromIdx(i)));
		ToggleButton->SetChecked(i == SelectedIndex);
		ToggleButton->OnToggleButtonClickedDelegate.BindUObject(this, &UNatureTabWidget::SetSelectedIndex, i);
		NatureButtonWidgets[i] = ToggleButton;
	}
}

void UNatureTabWidget::SetSelectedIndex(int32 NewIndex)
{
	if (NewIndex != SelectedIndex)
	{
		NatureButtonWidgets[SelectedIndex]->SetChecked(false);
		SelectedIndex = NewIndex;
		OnToggleButtonClickedDelegate.ExecuteIfBound(SelectedIndex);
	}
	NatureButtonWidgets[SelectedIndex]->SetChecked(true);
}


UQ6DynamicEntryBox::UQ6DynamicEntryBox(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UQ6DynamicEntryBox::SetEntryHorizontalAlignment(EHorizontalAlignment InEntryHorizontalAlignment)
{
	EntryHorizontalAlignment = InEntryHorizontalAlignment;
}

void UQ6DynamicEntryBox::SetEntryValticalAlignment(EVerticalAlignment InEntryVerticalAlignment)
{
	EntryVerticalAlignment = InEntryVerticalAlignment;
}

void UQ6DynamicEntryBox::SetEntrySizeRule(FSlateChildSize InEntrySizeRule)
{
	EntrySizeRule = InEntrySizeRule;
}

UProgressBarControlWidget::UProgressBarControlWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UProgressBarControlWidget::NativeConstruct()
{
	Super::NativeConstruct();
}

void UProgressBarControlWidget::OnProgressBarChangedBP(float Value)
{
	OnProgressBarDelegate.ExecuteIfBound(Value);
}

UClearUIWidget::UClearUIWidget(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UClearUIWidget::NativeConstruct()
{
	Super::NativeConstruct();

	DimmedImage = CastChecked<UImage>(GetWidgetFromName("ImgDimmed"));

	BackButton = CastChecked<UButton>(GetWidgetFromName("BtnBack"));
	BackButton->OnClicked.AddUniqueDynamic(this, &UClearUIWidget::OnBackButtonClicked);
}

void UClearUIWidget::ShowClearUIWidget(bool bDimmed)
{
	if (!IsInViewport())
	{
		AddToViewport(ZORDER_CLEAR_UI);
	}

	DimmedImage->SetVisibility(bDimmed ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	BackButton->SetVisibility(ESlateVisibility::Visible);
}

void UClearUIWidget::ToggleBackButtonVisibility()
{
	bool bVisible = BackButton->IsVisible();
	BackButton->SetVisibility(bVisible ? ESlateVisibility::Collapsed : ESlateVisibility::Visible);
}

void UClearUIWidget::OnBackButtonClicked()
{
	APlayerController* PlayerController = GetLocalPlayerController(this);
	if (PlayerController)
	{
		ABaseHUD* BaseHUD = Cast<ABaseHUD>(PlayerController->GetHUD());
		if (BaseHUD)
		{
			BaseHUD->SetClearUI(false);
		}
	}
}

UVerticalList::UVerticalList(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, ItemPadding(0.0f)
{
}

void UVerticalList::NativeConstruct()
{
	Super::NativeConstruct();

	VerticalBox = CastChecked<UVerticalBox>(GetWidgetFromName("Items"));

	ScrollBox = CastChecked<UScrollBox>(GetWidgetFromName("Scroll"));
	ScrollBox->SetOrientation(EOrientation::Orient_Vertical);

	UButton* TouchButton = CastChecked<UButton>(GetWidgetFromName("ButtonTouch"));
	TouchButton->OnClicked.AddUniqueDynamic(this, &UVerticalList::OnTouchButtonClicked);
}

void UVerticalList::ScrollToStart()
{
	ScrollBox->ScrollToStart();
}

void UVerticalList::ScrollToEnd()
{
	ScrollBox->ScrollToEnd();
}

void UVerticalList::ClearAll()
{
	VerticalBox->ClearChildren();
}

UWidget* UVerticalList::AddNewChild()
{
	return AddNewChild(ItemPadding);
}

UWidget* UVerticalList::AddNewChild(const FMargin& InPadding)
{
	UWidget* Widget = NewObject<UWidget>(this, ItemWidgetClass.LoadSynchronous());

	UVerticalBoxSlot* ChildSlot = VerticalBox->AddChildToVerticalBox(Widget);
	ChildSlot->SetPadding(InPadding);

	return Widget;
}

bool UVerticalList::RemoveChildAt(int32 Index)
{
	return VerticalBox->RemoveChildAt(Index);
}

bool UVerticalList::RemoveLast()
{
	int32 Index = GetChildrenCount() - 1;
	return RemoveChildAt(Index);
}

int32 UVerticalList::GetChildrenCount() const
{
	return VerticalBox->GetChildrenCount();
}

UWidget* UVerticalList::GetChildAt(int32 Index) const
{
	return VerticalBox->GetChildAt(Index);
}

UWidget* UVerticalList::GetLastChild() const
{
	int32 Index = GetChildrenCount() - 1;
	return GetChildAt(Index);
}

void UVerticalList::OnTouchButtonClicked()
{
	TouchButtonDelegate.ExecuteIfBound();
}
