// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "LobbyHUDWidget.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "PopupWidgets.h"

#include "ShopWidgets.generated.h"

enum class EShopSwitcherCategory : uint8;
class UDynamicListWidget;
class UPointWidget;
class USortingWidget;
class UItemSelectActionWidget;
class USellShopWidget;

/*
* ShopWidgetBp
*/
UCLASS()
class Q6_API UShopWidget : public ULobbyHUDWidget
{
	GENERATED_BODY()

public:
	UShopWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	virtual void OnEnterMenu() override;
	virtual void OnLeaveMenu() override;
	virtual void RefreshMenu() override;

	virtual bool OnBack() override;

	UFUNCTION(BlueprintImplementableEvent)
	void SetSellShopLockState(bool bLocked);

protected:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Shop; }

private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void SetShop(EShopMenu InShopMenu, bool bPlayAnim = true);
	void SetPoint(EShopMenu InShopMenu);
	void SetWidgetSwitcher(EShopSwitcherCategory InShopSwitcherCategory);
	void SetNewMarks(EShopMenu InShopMenu);

	void SetShopList(EShopMenu InShopMenu);
	void SetGemShopList();
	void SetSellShopList();

	void CloseSellShopWidget();

	void OpenOrCreateSellShopWidget();

	UFUNCTION()
	void OnLumicubeShopButtonClicked();

	UFUNCTION()
	void OnDiskShopButtonClicked();

	UFUNCTION()
	void OnGemShopButtonClicked();

	UFUNCTION()
	void OnSellButtonClicked();

	UFUNCTION()
	void OnDiskCategoryChanged(int32 InIndex);

	UPROPERTY(Transient)
	UWidgetAnimation* IntroAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* SelectContentAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* BackShopAnim;

	UPROPERTY()
	UWidgetSwitcher* ShopSwitcherWidget;

	UPROPERTY()
	UDynamicListWidget* GeneralShopListWidget;

	UPROPERTY()
	UDynamicListWidget* GemShopListWidget;

	UPROPERTY()
	UToggleButtonBoxWidget* DiskCategoryButtonWidget;

	UPROPERTY()
	USellShopWidget* SellShopWidget;

	UPROPERTY()
	UImage* ShopBg;

	UPROPERTY()
	UPointWidget* PointWidget;

	UPROPERTY()
	UPointWidget* FreeGemPointWidget;

	UPROPERTY()
	UPointWidget* PaidGemPointWidget;

	UPROPERTY()
	UImage* LumicubeShopNewMarkImage;

	UPROPERTY()
	UImage* DiskShopNewMarkImage;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<USellShopWidget> SellShopWidgetClass;
};

/*
* ShopEntryWidgetBP
*/
UCLASS()
class Q6_API UShopEntryWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UShopEntryWidget(const FObjectInitializer& ObjectInitializer);

public:
	virtual void NativeConstruct() override;

	void SetNameAndInfo(const FText& InName, const FText& InInfo);
	void SetShopType(FShopType InShopType) { ShopType = InShopType; }
	void SetItem(const FItemData& InItemData);
	void SetCost(const FItemData& InItemData);
	void SetEventPointCost(FEventContentType InEventContentType, const FItemData& InItemData);
	void SetLeftDayAndCount(int32 InLeftDay, int32 InLeftCount);
	void SetNewMark(bool bInVisibile);

	FShopType GetShopType() { return ShopType; }
	const FItemData& GetCostItemData() { return CostItemData; }
	FEventContentType GetEventContentType() const { return EventContentType; }

	void Duplicate(const UShopEntryWidget* InEntryWidget);

protected:
	UPROPERTY(EditInstanceOnly)
	bool bSelectEnabled;

private:
	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY(Transient)
	UWidgetAnimation* EnabledAnim;

	UPROPERTY(Transient)
	UWidgetAnimation* DisabledAnim;

	UPROPERTY()
	UItemWidget* ItemWidget;

	UPROPERTY()
	UPointWidget* PointWidget;

	UPROPERTY()
	UTextBlock* ItemNameText;

	UPROPERTY()
	UTextBlock* ItemInfoText;

	UPROPERTY()
	UTextBlock* DaysText;

	UPROPERTY()
	UTextBlock* StocksText;

	UPROPERTY()
	UButton* SelectButton;

	FEventContentType EventContentType;
	FShopType ShopType;
	FItemData ItemData;
	FItemData CostItemData;
	int32 LeftDay;
	int32 LeftCount;
};

/*
* ShopGemItemWidgetBP
*/
UCLASS()
class Q6_API UShopGemItemWidget : public UBaseWidget
{
	GENERATED_BODY()

public:
	UShopGemItemWidget(const FObjectInitializer& ObjectInitializer);

public:
	virtual void NativeConstruct() override;

	void SetGem(int32 InTotalGem, int32 InBonusGem, int32 InPrice);

private:
	UFUNCTION()
	void OnSelectButtonClicked();

	UPROPERTY()
	UButton* SelectButton;

	UPROPERTY()
	UTextBlock* TotalGemCountText;

	UPROPERTY()
	UTextBlock* DefaultGemCountText;

	UPROPERTY()
	UTextBlock* BonusGemCountText;

	UPROPERTY()
	UTextBlock* PriceText;

	UPROPERTY()
	UImage* IconImage;
};

/*
* SetllShopWidgetBP
*/

UCLASS()
class Q6_API USellShopWidget : public UHSBaseWidget
{
	GENERATED_BODY()

public:
	USellShopWidget(const FObjectInitializer& ObjectInitializer);

protected:

public:
	virtual void NativeConstruct() override;

	void InitSellShop();
	
private:
	virtual void OnHSEvent(TSharedPtr<FHSAction> Action) override;

	void SetList(EInventoryType SellShopCategory);
	void SetSelectableCard(UItemCardWidget* ItemCard);
	void UnselectItemCards();

	void OnActionModeChanged();
	void OnSelectedItemCard(UItemCardWidget* InItemCard);

	void OnSellShopCategoryChanged(int32 Index);

	int32 CalculateGold(const UItemCardWidget* InItemCardWidget) const;
	int32 CalculateLumicube(const UItemCardWidget* InItemCardWidget) const;

private:
	UFUNCTION()
	void OnSellButtonClicked();

	UFUNCTION()
	void OnAllRemoveButtonClicked();

	UPROPERTY()
	UToggleButtonBoxWidget* CategoryButtonWidget;

	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	USortingWidget* SortingWidget;

	UPROPERTY()
	UItemSelectActionWidget* SelectLockSwitcherWidget;

	UPROPERTY()
	UPointWidget* SellPoint1Widget;

	UPROPERTY()
	UPointWidget* SellPoint2Widget;

	UPROPERTY()
	UButton* SellButton;

	UPROPERTY()
	UButton* AllRemoveButton;

	UPROPERTY()
	TArray<UItemCardWidget*> SelectedItemCardWidget;

	EInventoryType SellShopCategory;
	int32 NumOfCard;
};

UCLASS()
class Q6_API USellShopPurchasePopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	USellShopPurchasePopupWidget(const FObjectInitializer& ObjectInitializer);
	virtual void NativeConstruct() override;

	void SetList(UDynamicListWidget* InItemList, EInventoryType SellShopCategory);
	void SetGoldAndLumicube(int32 InGold, int32 InLumicube);

protected:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option) override;

private:
	UPROPERTY()
	UDynamicListWidget* ItemListWidget;

	UPROPERTY()
	UPointWidget* SellPoint1Widget;

	UPROPERTY()
	UPointWidget* SellPoint2Widget;

	ELootCategory SellShopCategory;
};

/*
* GeneralShopPurchasePopupWidgetBP
*/
UCLASS()
class Q6_API UGeneralShopPurchasePopupWidget : public UConfirmPopupWidget
{
	GENERATED_BODY()

public:
	UGeneralShopPurchasePopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetShopEntryWidget(const UShopEntryWidget* InShopEntryWidget);

protected:
	virtual void OnConfirmButtonClicked(EConfirmPopupFlag Option) override;

private:
	void RefreshCost();

private:
	UFUNCTION()
		void OnPlusButtonClicked();

	UFUNCTION()
		void OnMinusButtonClicked();

	UPROPERTY()
		UButton* PlusButton;

	UPROPERTY()
		UButton* MinusButton;

	UPROPERTY()
		UShopEntryWidget* ShopEntryWidget;

	UPROPERTY()
		UPointWidget* OwnedPointWidget;

	UPROPERTY()
		UPointWidget* RequirePointWidget;

	UPROPERTY()
		UTextBlock* StocksText;

	int32 PurchaseAmount;
};

/*
* GemShopPurchasePopupWidgetBP
*/
UCLASS()
class Q6_API UGemShopPurchasePopupWidget : public UPopupWidget
{
	GENERATED_BODY()

public:
	UGemShopPurchasePopupWidget(const FObjectInitializer& ObjectInitializer);

	virtual void NativeConstruct() override;

	void SetInfo();

private:
	UFUNCTION()
		void OnCancelButtonClicked();

	UPROPERTY()
		UPointWidget* OwnedFreeGemWidget;

	UPROPERTY()
		UPointWidget* OwnedPaidGemWidget;

	UPROPERTY()
		UDynamicListWidget* GemShopListWidget;
};
