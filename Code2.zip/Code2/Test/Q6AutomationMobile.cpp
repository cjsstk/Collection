#include "Q6AutomationCommon.h"

#if !UE_BUILD_SHIPPING

#include "Tests/AutomationCommon.h"
#include "Misc/AutomationTest.h"
#include "AutomationHelper.h"
#include "CombatPresenter.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6Define.h"


#if PLATFORM_ANDROID
#include "Android/AndroidPlatformMisc.h"
#endif

// Map Change
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FPopulatePSOCache, "Q6.PopulatePSOCache", EAutomationTestFlags::ClientContext | EAutomationTestFlags::EditorContext | EAutomationTestFlags::PerfFilter)

bool FPopulatePSOCache::RunTest(const FString& Parameters)
{
#if PLATFORM_ANDROID
	ADD_LATENT_AUTOMATION_COMMAND(FEngineWaitLatentCommand(30.f)); // delay for warm up.
#endif
	//ADD_LATENT_AUTOMATION_COMMAND(FExecConsoleCommand(TEXT("slomo 3")));

	AQ6CombatGameMode* CombatGameMode = Q6Automation::GetCombatCubeGameMode();
	if (!CombatGameMode || !CombatGameMode->Presenter)
	{
		return false;
	}

	CombatGameMode->Presenter->GetAutomationHelper()->Start();
	int32 NotSpawnedUnitCount = CombatGameMode->Presenter->GetAutomationHelper()->GetUnspawnedUnitCount();
	NotSpawnedUnitCount = (NotSpawnedUnitCount / CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT + 1) * 2 + 2;

	ADD_LATENT_AUTOMATION_COMMAND(FSetGameDevFlagNoDamage());
	for (int32 i = 0; i < NotSpawnedUnitCount; ++i)
	{
		ADD_LATENT_AUTOMATION_COMMAND(FReplaceUnitsCommand());
		ADD_LATENT_AUTOMATION_COMMAND(FSetGameDevCheatAlliesUASA());
		ADD_LATENT_AUTOMATION_COMMAND(FUseTurnSkillCommand());
		ADD_LATENT_AUTOMATION_COMMAND(FSkipTurnSkillCommand());
		ADD_LATENT_AUTOMATION_COMMAND(FUseSkillCommand());
	}

	ADD_LATENT_AUTOMATION_COMMAND(FEngineWaitLatentCommand(30.f)); // delay for finishing skill effects.
	ADD_LATENT_AUTOMATION_COMMAND(FExecConsoleCommand(TEXT("r.ShaderPipelineCache.Save")));
	ADD_LATENT_AUTOMATION_COMMAND(FEngineWaitLatentCommand(5.f)); // delay for saving PSO Caches.

	return true;
}

#endif // UE_BUILD_SHIPPING
