#include "Q6AutomationCommon.h"

#if !UE_BUILD_SHIPPING

#include "AssetRegistryModule.h"
#include "Tests/AutomationCommon.h"
#include "AutomationHelper.h"
#include "CombatPresenter.h"
#include "HttpModule.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "Misc/Base64.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6CombatGameMode.h"

#if WITH_EDITOR
#include "Editor.h"
#endif

const int32 ALLIES_COOLDOWN = -1;

namespace AutomationCommon
{
	/** These save a PNG and get sent over the network */
	static void SaveWindowAsScreenshot(TSharedRef<SWindow> Window, const FString& FileName)
	{
		FScreenshotRequest::RequestScreenshot(FileName, true, false);
		GScreenshotResolutionX = 0;
		GScreenshotResolutionY = 0;
	}
}

UWorld* Q6Automation::GetWorld()
{
#if WITH_EDITOR
	if (GEditor)
	{
		return GEditor->PlayWorld;
	}
#endif

	return GEngine->GetWorldContexts()[0].World();
}

AQ6CombatGameMode* Q6Automation::GetCombatCubeGameMode()
{
	UWorld* AutomationWorld = Q6Automation::GetWorld();
	if (!AutomationWorld)
	{
		return nullptr;
	}

	AGameModeBase* GameMode = AutomationWorld->GetAuthGameMode();
	if (!GameMode)
	{
		return nullptr;
	}

	return Cast<AQ6CombatGameMode>(GameMode);
}

bool Q6Automation::CaptureScreenShot(const FString& FilePath, bool bFullScreen)
{
	GLog->Logf(TEXT("Capturing Screenshot"));
	GLog->Logf(TEXT("Capturing Screenshot Time : %f"), FPlatformTime::Seconds());

	UWorld* World = Q6Automation::GetWorld();
	if (!World)
	{
		return true;
	}

	//Find the main editor window
	TArray<TSharedRef<SWindow> > AllWindows;
	FSlateApplication::Get().GetAllVisibleWindowsOrdered(AllWindows);
	if( AllWindows.Num() == 0 )
	{
		GLog->Logf(TEXT("ERROR: Could not find the main editor window."));
		return false;
	}
	WindowScreenshotParameters WindowParameters;
	WindowParameters.CurrentWindow = AllWindows.Last();//AllWindows[0];

	//Disable Eye Adaptation
	static IConsoleVariable* CVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.EyeAdaptationQuality"));
	CVar->Set(0);

	WindowParameters.ScreenshotName = FilePath;

	//AutomationCommon::GetScreenshotPath(TestName, WindowParameters.ScreenshotName, false);

	//Take the screen shot
	AutomationCommon::SaveWindowAsScreenshot(WindowParameters.CurrentWindow.ToSharedRef(), WindowParameters.ScreenshotName);

	return true;
}

void Q6Automation::FindAllPackageFiles(TArray<FString>& OutPackages)
{
#if UE_BUILD_SHIPPING
	FString Key = TEXT("Paths");
#else
	// decide which paths to use by commandline parameter
	// Used only for testing wrangled content -- not for ship!
	FString PathSet(TEXT("Normal"));
	FParse::Value(FCommandLine::Get(), TEXT("PATHS="), PathSet);

	FString Key = (PathSet == TEXT("Cutdown")) ? TEXT("CutdownPaths") : TEXT("Paths");
#endif

	TArray<FString> Paths;
	GConfig->GetArray( TEXT("Core.System"), *Key, Paths, GEngineIni );

	// If doing a 'Play on XXX' from the editor, add the auto-save directory to the package search path, so streamed sub-levels can be found
	if ( !GIsEditor && FParse::Param(FCommandLine::Get(), TEXT("PIEVIACONSOLE")) )
	{
		FString AutoSave;
		GConfig->GetString( TEXT("/Script/UnrealEd.EditorEngine"), TEXT("AutoSaveDir"), AutoSave, GEngineIni );
		if (AutoSave.Len())
		{
			Paths.AddUnique(AutoSave);
		}
	}

	for (int32 PathIndex = 0; PathIndex < Paths.Num(); PathIndex++)
	{
		FPackageName::FindPackagesInDirectory(OutPackages, *Paths[PathIndex]);
	}
}

void Q6Automation::FindAllMapPackages(TArray <FString>& OutPackageNames)
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(FName("AssetRegistry"));

	// Search all assets ...

	TArray<FString> Paths;
	Paths.Add(FString(TEXT("/Game/Maps/")));
	AssetRegistryModule.Get().ScanPathsSynchronous(Paths);

	// Search all assets ... done!

	TArray<FAssetData> AssetDataArray;
	AssetRegistryModule.Get().GetAssetsByPath(FName(TEXT("/Game/Maps/")), AssetDataArray, true);

	for (const FAssetData& AssetData : AssetDataArray)
	{
		if (AssetData.GetClass() != UWorld::StaticClass())
		{
			continue;
		}
		OutPackageNames.Add(AssetData.PackageName.ToString());
	}
}

bool FCaptureScreenCommnad::Update()
{
	static int32 TickCounter = 0;

	++TickCounter;

	if (TickCounter == 1)
	{
		Q6Automation::CaptureScreenShot(FilePath, true);
	}
	else
	{
		if (TickCounter > 5)
		{
			TickCounter = 0;
			return true;
		}
	}

	return false;
}

TMap<uint32, TSharedRef<IHttpRequest>> GHttpRequests;
uint32 GNextHttpRequestId = 0;

//static bool bUploadingFile = false;

static void UploadFileRequestCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
{
	//ensure(bUploadingFile);

	if (!HttpResponse.IsValid())
	{
		GLog->Logf(TEXT("Upload File Failed. Verb : %s"), *HttpRequest.Get()->GetVerb());
	}
	else
	{
		GLog->Logf(TEXT("Upload File Result : %s"), *HttpResponse->GetContentAsString());
	}


	//bUploadingFile = false;

	for (auto& It : GHttpRequests)
	{
		if (&It.Value.Get() == HttpRequest.Get())
		{
			GLog->Logf(TEXT("Upload File Result Id : %u"), It.Key);
			GHttpRequests.Remove(It.Key);
			break;
		}
	}
}

// Source : https://forums.unrealengine.com/showthread.php?54775-sharing-pictures-between-clients-at-runtime
uint32 Q6Automation::UploadFile(const FString& LocalFilePath, const FString& RemoteFolder, const FString& RemoteFileName)
{
	++GNextHttpRequestId;

	GLog->Logf(TEXT("Uploading File : %s, Id(%u)"), *LocalFilePath, GNextHttpRequestId);

	//FHttpModule::Get().SetHttpDelayTime(180.0f);

	// the data
	const FString FileName = FPaths::IsRelative(LocalFilePath) ? FPaths::RootDir() + LocalFilePath : LocalFilePath;

	TArray<uint8> UpFileRawData;
	FFileHelper::LoadFileToArray(UpFileRawData, *FileName);

	if (UpFileRawData.Num() == 0)
	{
		GLog->Logf(TEXT("Uploading file is empty : %s, Id(%u)"), *LocalFilePath, GNextHttpRequestId);
	}

	FString ImageBase64 = FBase64::Encode(UpFileRawData);

	// prepare json data
	FString JsonString;
	TSharedRef<TJsonWriter<TCHAR>> JsonWriter = TJsonWriterFactory<TCHAR>::Create(&JsonString);
	JsonWriter->WriteObjectStart();
	JsonWriter->WriteValue("fileName", RemoteFileName);
	JsonWriter->WriteValue("saveFolder", RemoteFolder);
	JsonWriter->WriteValue("fileData", ImageBase64);
	JsonWriter->WriteObjectEnd();
	JsonWriter->Close();

	// the json request
	TSharedRef<IHttpRequest> SendJsonRequest = (&FHttpModule::Get())->CreateRequest();
	SendJsonRequest->OnProcessRequestComplete().BindStatic(&UploadFileRequestCompleted);
	SendJsonRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	SendJsonRequest->SetURL(TEXT("https://noserverforuploadingfile"));
	SendJsonRequest->SetVerb("POST");
	SendJsonRequest->SetContentAsString(JsonString);
	SendJsonRequest->ProcessRequest();

	GHttpRequests.Add(GNextHttpRequestId, SendJsonRequest);

	return GNextHttpRequestId;
}

bool Q6Automation::IsUploadFileFinished(uint32 Id)
{
	if (GHttpRequests.Find(Id))
	{
		return false;
	}

	return true;
}

int32 Q6Automation::GetUploadFileCount()
{
	return GHttpRequests.Num();
}

bool FUploadFileCommand::Update()
{
	GLog->Logf(TEXT("FUploadFileCommand. File: %s, RemoteFile: %s"), *Param.LocalFilePath, *Param.RemoteFileName);

	if (Param.bBlocking)
	{
		if (Param.RequestedId != 0)
		{
			if (!Q6Automation::IsUploadFileFinished(Param.RequestedId))
			{
				return false;
			}

			Param.RequestedId = 0;

			return true;
		}
	}

	Param.RequestedId = Q6Automation::UploadFile(Param.LocalFilePath, Param.RemoteFolder, Param.RemoteFileName);

	GLog->Logf(TEXT("FUploadFileCommand. Requested Id : %u"), Param.RequestedId);

	return !Param.bBlocking;
}

bool FFlushUploadFileCommand::Update()
{
	GLog->Logf(TEXT("FFlushUploadFileCommand. Count: %d"), Q6Automation::GetUploadFileCount());

	if (Q6Automation::GetUploadFileCount() > 0)
	{
		return false;
	}

	return true;
}

static void HttpRequestCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
{
	GLog->Logf(TEXT("Http Request Result : %s"), 
		HttpResponse.IsValid() ? *HttpResponse->GetContentAsString() : TEXT("NULL"));

	for (auto& It : GHttpRequests)
	{
		if (&It.Value.Get() == HttpRequest.Get())
		{
			GLog->Logf(TEXT("Http Request Result Id : %u"), It.Key);
			GHttpRequests.Remove(It.Key);
			break;
		}
	}
}

void Q6Automation::HttpRequest(const FString& URL, const FString& JsonContentString)
{
	++GNextHttpRequestId;

	TSharedRef<IHttpRequest> Request = (&FHttpModule::Get())->CreateRequest();
	Request->OnProcessRequestComplete().BindStatic(&HttpRequestCompleted);
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	Request->SetURL(URL);
	Request->SetVerb("POST");
	Request->SetContentAsString(JsonContentString);
	Request->ProcessRequest();

	GHttpRequests.Add(GNextHttpRequestId, Request);
}

bool FHttpRequestCommand::Update()
{
	static uint32 RequestedId = 0;

	if (RequestedId != 0)
	{
		if (!Q6Automation::IsUploadFileFinished(RequestedId))
		{
			return false;
		}

		RequestedId = 0;

		return true;
	}

	GLog->Logf(TEXT("FHttpRequestCommand. url: %s"), *Param.URL);

	++GNextHttpRequestId;

	TSharedRef<IHttpRequest> Request = (&FHttpModule::Get())->CreateRequest();
	Request->OnProcessRequestComplete().BindStatic(&HttpRequestCompleted);
	Request->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	Request->SetURL(Param.URL);
	Request->SetVerb("POST");
	Request->SetContentAsString(Param.JsonString);
	Request->ProcessRequest();

	RequestedId = GNextHttpRequestId;

	GHttpRequests.Add(GNextHttpRequestId, Request);

	return false;
}

bool FFlushHttpRequestCommand::Update()
{
	GLog->Logf(TEXT("FFlushHttpRequestCommand. Count: %d"), GHttpRequests.Num());

	if (GHttpRequests.Num() > 0)
	{
		return false;
	}

	return true;
}

bool FLoadMapCommand::Update()
{
	static bool bWaitting = false;

	UWorld* World = Q6Automation::GetWorld();
	if (!Param.LevelName.ToString().Contains(World->GetFName().ToString()) || World->GetAuthGameMode()->OptionsString != Param.Options)
	{
		if (!bWaitting)
		{
			UGameplayStatics::OpenLevel(World, Param.LevelName, true, Param.Options);
			bWaitting = true;
		}
		else
		{
			const double Age = FPlatformTime::Seconds() - StartTime;
			if (Age > 30)
			{
				// been waited too long, maybe we failed to change level. abort.
				bWaitting = false;
				return true;
			}
		}

		return false;
	}

	bWaitting = false;

	return true;
}

bool FSetGameDevFlagNoDamage::Update()
{
	AQ6CombatGameMode* CombatGameMode = Q6Automation::GetCombatCubeGameMode();
	if (CombatGameMode)
	{
		CombatGameMode->CombatCube->ToggleNoDamage(nullptr);
		Q6_AUTO_LOG(Display, "FSetGameDevFlagNoDamage done.");
	}

	return true;
}

bool FSetGameDevCheatAlliesUASA::Update()
{
	AQ6CombatGameMode* CombatGameMode = Q6Automation::GetCombatCubeGameMode();
	if (CombatGameMode)
	{
		CombatGameMode->CombatCube->CheatFillAlliesUASA();
		CombatGameMode->CombatCube->CheatResetCooldown(ALLIES_COOLDOWN);
		Q6_AUTO_LOG(Display, "FSetGameDevCheatAlliesUASA done.");
	}

	return true;
}

bool FUseSkillCommand::Update()
{
	AQ6CombatGameMode* CombatGameMode = Q6Automation::GetCombatCubeGameMode();
	if (!CombatGameMode)
	{
		return true;
	}

	if (CombatGameMode->Presenter->GetTurnPhase() != ECCTurnPhase::Attack)
	{
		return false;
	}

	CombatGameMode->Presenter->GetAutomationHelper()->UseSkill();
	Q6_AUTO_LOG(Display, "FUseSkillCommand done.");

	return true;
}

bool FUseTurnSkillCommand::Update()
{
	AQ6CombatGameMode* CombatGameMode = Q6Automation::GetCombatCubeGameMode();
	if (!CombatGameMode)
	{
		return true;
	}

	if (CombatGameMode->Presenter->GetTurnPhase() != ECCTurnPhase::TurnSkill)
	{
		return false;
	}

	CombatGameMode->Presenter->GetAutomationHelper()->UseTurnSkill();
	Q6_AUTO_LOG(Display, "FUseTurnSkillCommand done.");

	return true;
}

bool FReplaceUnitsCommand::Update()
{
	AQ6CombatGameMode* CombatGameMode = Q6Automation::GetCombatCubeGameMode();
	if (!CombatGameMode)
	{
		return true;
	}

	if (CombatGameMode->Presenter->GetTurnPhase() != ECCTurnPhase::TurnSkill)
	{
		return false;
	}

	CombatGameMode->Presenter->GetAutomationHelper()->ReplaceUnits();

	Q6_AUTO_LOG(Display, "FReplaceUnitsCommand done.");

	return true;
}

bool FSkipTurnSkillCommand::Update()
{
	AQ6CombatGameMode* CombatGameMode = Q6Automation::GetCombatCubeGameMode();
	if (!CombatGameMode)
	{
		return true;
	}

	if (CombatGameMode->Presenter->GetTurnPhase() != ECCTurnPhase::TurnSkill)
	{
		return false;
	}

	CombatGameMode->CombatCube->ProceedToNextTurn();

	Q6_AUTO_LOG(Display, "FSkipTurnSkillCommand done.");

	return true;
}

bool FWaitForCombatStateCommand::Update()
{
	return false;
}

bool FWaitForActCombatFinishedCommand::Update()
{
	//ACombatGameState* CombatGameState = GetCombatGameState(Q6Automation::GetWorld());

	//if (!CombatGameState)
	//{
	//	return true;
	//}

	//if (CombatGameState->GetCombatGameModeState() == ECombatGameModeState::Finished)
	//{
	//	return true;
	//}

	return false;
}

bool FChangeRenderFlagCommand::Update()
{
	UWorld* World = Q6Automation::GetWorld();
	if (!World)
	{
		return true;
	}

	APlayerController* PlayerController= UGameplayStatics::GetPlayerController(World, 0);
	if (!PlayerController)
	{
		return true;
	}

	PlayerController->ConsoleCommand(Params.bParticles ? TEXT("showflag.particles 1") : TEXT("showflag.particles 0"));
	PlayerController->ConsoleCommand(Params.bSkeletalMeshes ? TEXT("showflag.skeletalmeshes 1") : TEXT("showflag.skeletalmeshes 0"));
	PlayerController->ConsoleCommand(Params.bStaticMeshes ? TEXT("showflag.staticmeshes 1") : TEXT("showflag.staticmeshes 0"));
	//PlayerController->ConsoleCommand(Params.bUI ? TEXT("q6.ui 1") : TEXT("q6.ui 0"));
	PlayerController->ConsoleCommand(Params.bDynamicShadow ? TEXT("showflag.dynamicshadows 1") : TEXT("showflag.dynamicshadows 0"));

	return true;
}

bool FExecConsoleCommand::Update()
{
	UWorld* World = Q6Automation::GetWorld();
	if (!World)
	{
		return false;
	}

	APlayerController* PlayerController = UGameplayStatics::GetPlayerController(World, 0);
	if (!PlayerController)
	{
		return false;
	}

	PlayerController->ConsoleCommand(CommandString);
	Q6_AUTO_LOG(Display, "FExecConsoleCommand %s done.", *CommandString);

	return true;
}

#endif // UE_BUILD_SHIPPING
