#include "Q6Minimal.h"

#if !UE_BUILD_SHIPPING

#include "Tests/AutomationCommon.h"
#include "Misc/AutomationTest.h"
#include "AutomationHelper.h"
#include "CombatPresenter.h"
#include "Q6.h"
#include "Q6AutomationCommon.h"
#include "Q6CombatGameMode.h"
#include "Q6Define.h"


#if PLATFORM_ANDROID
#include "Android/AndroidPlatformMisc.h"
#endif

// Map Change
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FValidateCMS, "Q6.ValidateCMS", EAutomationTestFlags::ClientContext | EAutomationTestFlags::EditorContext | EAutomationTestFlags::PerfFilter)

bool FValidateCMS::RunTest(const FString& Parameters)
{
	UCMS* CMS = GetCMS();

	FCMSParam Param;
	Param.CMS = CMS;

	ADD_LATENT_AUTOMATION_COMMAND(FValidateSkill(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateFormulaConst(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FCharacterToUnitType(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateBuffEffect(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateSkillEffect(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateVersa(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateUnit(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateWave(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateABC(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateApplyTag(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidatePet(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateMonster(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateAttributeDifficulty(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateSaga(Param));
	ADD_LATENT_AUTOMATION_COMMAND(FValidateDifficultyNatureBonus(Param));

	return true;
}

bool FValidateSkill::Update()
{
	const UDataTable* SkillTable = Param.CMS->GetSkill();
	if (!SkillTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillTable is null."));
		return true;
	}

	TArray<FCMSSkillRow*> Skills;
	SkillTable->GetAllRows("FValidateSkill", Skills);
	if (Skills.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillTable is empty."));
	}

	for (auto S : Skills)
	{
		const TArray<const FCMSSkillEffectRow*>& Effects = S->GetSkillEffect();
		if (Effects.Num() <= 0)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Skill(%d) has no effects."), S->CmsType());
		}

		int32 FirstWaitTimeEffect = 0;
		int32 CommonWaitTimeEffect = 0;
		for (auto E : Effects)
		{
			if (Param.CMS->GetSkillEffectRowOrDummy(E->CmsType()).IsInvalid())
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Skill(%d) has invalid effects(%d)."), S->CmsType(), E->CmsType());
			}
			if (E->EffectCategory == EEffectCategory::Damage
				|| E->EffectCategory == EEffectCategory::HPDMGper
				|| E->EffectCategory == EEffectCategory::SkillDMGper)
			{
				if (S->Target != ETargetType::HostileAll
					&& E->Target == ETargetType::HostileAll)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Splash Damage Skill(%d) target should be HostileAll that has a HostileAll effects(%d)."), S->CmsType(), E->CmsType());
				}
				else if (S->Target != ETargetType::FriendlyAll
					&& E->Target == ETargetType::FriendlyAll)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Splash Damage Skill(%d) target should be FriendlyAll that has a FriendlyAll effects(%d)."), S->CmsType(), E->CmsType());
				}
			}

			if (E->EffectCategory == EEffectCategory::FirstWaitTime)
			{
				++FirstWaitTimeEffect;
			}
			if (E->EffectCategory == EEffectCategory::WaitTime)
			{
				++CommonWaitTimeEffect;
			}
		}

		if (FirstWaitTimeEffect > 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Skill(%d) have duplicated FirstWaitTime skill effect."), S->CmsType());
		}
		if (CommonWaitTimeEffect > 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Skill(%d) have duplicated WaitTime skill effect."), S->CmsType());
		}
		if (FirstWaitTimeEffect > 0 && CommonWaitTimeEffect <= 0)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Skill(%d) need a WaitTime skill effect."), S->CmsType());
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateSkill done."));
	return true;
}

bool FValidateFormulaConst::Update()
{
	const UDataTable* FormulaConstTable = Param.CMS->GetFormulaConst();
	if (!FormulaConstTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable is null."));
		return true;
	}

	TArray<FCMSFormulaConstRow*> Consts;
	FormulaConstTable->GetAllRows("FValidateFormulaConst", Consts);
	if (Consts.Num() <= 0 || Consts.Num() != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("wrong FormulaConstTable row count(%d)."), Consts.Num());
	}

	int32 NatureCount = (int32)ENatureType::Dark - (int32)ENatureType::Fire + 1;
	for (auto C : Consts)
	{
		if (C->AddUAAtOrder.Num() != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConst type(%d) AddUAAtOrder length(%d) should be (%d)."),
				C->CmsType(), C->AddUAAtOrder.Num(), CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
		}
		if (C->AddSAAtOrder.Num() != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConst type(%d) AddSAAtOrder length(%d) should be (%d)."),
				C->CmsType(), C->AddSAAtOrder.Num(), CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
		}
		if (C->OrderCalculation.Num() != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConst type(%d) OrderCalculation length(%d) should be (%d)."),
				C->CmsType(), C->OrderCalculation.Num(), CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateFormulaConst done."));
	return true;
}

bool FCharacterToUnitType::Update()
{
	const UDataTable* CharacterDataTable = Param.CMS->GetCharacter();
	if (!CharacterDataTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("CharacterDataTable is null."));
		return true;
	}

	TArray<FCMSCharacterRow*> OutRowArray;
	CharacterDataTable->GetAllRows("FCharacterToUnitType", OutRowArray);

	for (auto Row : OutRowArray)
	{
		if (Row->GetUnit().IsInvalid())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Character(%d) has no Unit."), Row->Type);
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FCharacterToUnitType done."));
	return true;
}

bool FValidateBuffEffect::Update()
{
	const UDataTable* BuffEffectTable = (Cast<UCMSBase>(Param.CMS))->GetBuffEffect();
	if (!BuffEffectTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffectTable is null."));
		return true;
	}

	TArray<FCMSBuffEffectRow*> Effects;
	BuffEffectTable->GetAllRows("FValidateBuffEffect", Effects);
	if (Effects.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffectTable is empty."));
	}

	for (auto E : Effects)
	{
		if (E->BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
		{
			const FCMSCrowdControlRow& CrowdControlRow = Param.CMS->GetCrowdControlRowOrDummy(FCrowdControlType(E->Param1));
			if (CrowdControlRow.IsInvalid())
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) wrong ModifyCrowdControl Param1(%d)."), E->CmsType(), E->Param1);
			}

			if (E->Param2 < 0 || E->Param2Min < 0 || E->Param3 < 0 || E->Param3Min < 0)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) Params should be positive. Param1(%d) Param2(%d) Param2Min(%d) Param3(%d) Param3Min(%d)."),
					E->CmsType(), E->Param1, E->Param2, E->Param2Min, E->Param3, E->Param3Min);
			}

			if (E->Param2 < E->Param2Min)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) Params2(%d) should be more than Param2Min(%d)."),
					E->CmsType(), E->Param2, E->Param2Min);
			}

			if (E->Param3 < E->Param3Min)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) Params3(%d) should be more than Param3Min(%d)."),
					E->CmsType(), E->Param3, E->Param3Min);
			}
		}
		else if (E->BuffEffectCategory == EBuffEffectCategory::ModifyUnitAttribute)
		{
			const FCMSUnitAttributeRow& UnitAttributeRow = Param.CMS->GetUnitAttributeRowOrDummy(FUnitAttributeType(E->Param1));
			if (UnitAttributeRow.IsInvalid())
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) wrong ModifyUnitAttribute Param1(%d)."), E->CmsType(), E->Param1);
			}

			if (E->Param2 > 0)
			{
				if (E->Param2 < E->Param2Min)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) Params2(%d) should be more than Param2Min(%d)."),
						E->CmsType(), E->Param2, E->Param2Min);
				}
			}
			else
			{
				if (E->Param2Min < E->Param2)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) Params2Min(%d) should be more than Param2(%d)."),
						E->CmsType(), E->Param2Min, E->Param2);
				}
			}

			if (E->Param3 > 0)
			{
				if (E->Param3 < E->Param3Min)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) Params3(%d) should be more than Param3Min(%d)."),
						E->CmsType(), E->Param3, E->Param3Min);
				}
			}
			else
			{
				if (E->Param3Min < E->Param3)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) Params3Min(%d) should be more than Param3(%d)."),
						E->CmsType(), E->Param3Min, E->Param3);
				}
			}

			if (UnitAttributeRow.UnitAttribute == EUnitAttribute::Immune)
			{
				const FCMSApplyTagRow& Row = Param.CMS->GetApplyTagRowOrDummy(FApplyTagType(E->Param2));
				if (Row.CompareType != EApplyTagCompare::Keyword)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect Immune(%d) Param2 should be a 'Keyword' ApplyTag."),
						E->CmsType(), E->Param2);
				}
			}
		}
		else
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("BuffEffect(%d) unknown category(%d)."), E->CmsType(), (int32)E->BuffEffectCategory);
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateBuffEffect done."));
	return true;
}

bool FValidateSkillEffect::Update()
{
	const UDataTable* SkillEffectTable = (Cast<UCMSBase>(Param.CMS))->GetSkillEffect();
	if (!SkillEffectTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffectTable is null."));
		return true;
	}

	TArray<FCMSSkillEffectRow*> Effects;
	SkillEffectTable->GetAllRows("FValidateSkillEffect", Effects);
	if (Effects.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffectTable is empty."));
	}

	for (auto E : Effects)
	{
		if (E->Param1 > 0)
		{
			if (E->Param1 < E->Param1Min)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d) Params1(%d) should be more than Param1Min(%d)."),
					E->CmsType(), E->Param1, E->Param1Min);
			}
		}
		else
		{
			if (E->Param1Min < E->Param1)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d) Params1Min(%d) should be more than Param1(%d)."),
					E->CmsType(), E->Param1Min, E->Param1);
			}
		}

		if (E->EffectCategory == EEffectCategory::Buff)
		{
			const FCMSBuffRow& Row = Param.CMS->GetBuffRowOrDummy(FBuffType(E->Param1));
			if (Row.IsInvalid())
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d) has no exist Buff(%d)."), E->CmsType(), E->Param1);
			}

			if (Row.FollowMoment != EMoment::None)
			{
				if (Row.GetFollowMomentSkill().Num() <= 0)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("buff(%d) follow moment(%d) has no skill."), E->Param1, (int32)Row.FollowMoment);
				}
				else
				{
					for (auto S : Row.GetFollowMomentSkill())
					{
						if (S->SkillCategory != ESkillCategory::Moment)
						{
							GLog->Logf(ELogVerbosity::Error, TEXT("buff(%d) follow moment skill(%d) should be Moment SkillCategory."), E->Param1, S->CmsType());
						}
					}
				}
			}
			else
			{
				if (Row.GetFollowMomentSkill().Num() > 0)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("buff(%d) None follow moment should be no moment skill."), E->Param1);
				}
			}
		}
		else if (E->EffectCategory == EEffectCategory::RemoveBuff)
		{
			if (!IsValidEBuffRemovalCategory(E->EffectSubCategory))
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d)::RemoveBuff EffectSubCategory(%d) should be EBuffRemovalCategory"), E->CmsType(), E->Param1);
			}

			if (E->EffectSubCategory == (int32)EBuffRemovalCategory::RemoveBuffApplyTag)
			{
				const FCMSApplyTagRow& Row = Param.CMS->GetApplyTagRowOrDummy(FApplyTagType(E->Param1));
				if (Row.IsInvalid())
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect::RemoveBuff::RemoveBuffApplyTag (%d) Param1(%d) should be ApplyTag ID."), E->CmsType(), E->Param1);
				}
			}
		}
		else if (E->EffectCategory == EEffectCategory::Summon)
		{
			if (E->Param1 != E->Param1Min)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d)::Summon Param1(%d) Param1Min(%d) should be equal."), E->CmsType(), E->Param1, E->Param1Min);
			}
			else
			{
				const FCMSUnitRow& Unit = Param.CMS->GetUnitRowOrDummy(FUnitType(E->Param1));
				if (Unit.IsInvalid())
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d)::Summon Unit(%d) no exist."), E->CmsType(), E->Param1);
				}
			}
		}
		else if (E->EffectCategory == EEffectCategory::Rebirth)
		{
			if (E->Param1 <= 0
				|| E->Param1Min <= 0)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d)::Summon Param1(%d) Param1Min(%d) should be > 0."), E->CmsType(), E->Param1, E->Param1Min);
			}
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateSkillEffect done."));
	return true;
}

bool FValidateVersa::Update()
{
	const UDataTable* FormulaConstTable = Param.CMS->GetFormulaConst();
	if (!FormulaConstTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable is null."));
		return true;
	}

	TArray<FCMSFormulaConstRow*> Consts;
	FormulaConstTable->GetAllRows("FValidateVersa", Consts);
	if (Consts.Num() != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("wrong FormulaConstTable row count(%d)."), Consts.Num());
	}

	for (int i = 0; i < Consts.Num(); ++i)
	{
		auto C = Consts[i];

		const FCMSBuffRow& VersaBuffRow = Param.CMS->GetBuffRowOrDummy(FBuffType(C->VersaBuffId));
		if (VersaBuffRow.IsInvalid())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("VersaBuff invalid Buff type(%d)."), VersaBuffRow.CmsType());
		}
		if (VersaBuffRow.ApplyTag != EApplyTag::None)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("VersaBuff(%d) ApplyTag(%d) should be 'None'."),
				VersaBuffRow.CmsType(), (int32)VersaBuffRow.ApplyTag);
		}
		if (VersaBuffRow.Duration != 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("VersaBuff(%d) Duration(%d) should be 1."),
				VersaBuffRow.CmsType(), VersaBuffRow.Duration);
		}
		if (VersaBuffRow.BuffOverlap != EBuffOverlap::Overwrite)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("VersaBuff(%d) BuffOverlap(%d) should be 'Overwrite'."),
				VersaBuffRow.CmsType(), (int32)VersaBuffRow.BuffOverlap);
		}

		const TArray<const FCMSBuffEffectRow*>& VersaEffectRows = VersaBuffRow.GetBuffEffect();
		if (VersaEffectRows.Num() != 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("VersaBuff(%d) effect count(%d) should be 1."), VersaBuffRow.CmsType(), VersaEffectRows.Num());
		}
		else
		{
			const FCMSCrowdControlRow& CrowdControlRow = Param.CMS->GetCrowdControlRowOrDummy(FCrowdControlType(VersaEffectRows[0]->Param1));

			if (VersaEffectRows[0]->BuffEffectCategory != EBuffEffectCategory::ModifyCrowdControl
				|| CrowdControlRow.CrowdControl != ECrowdControl::Versa
				|| CrowdControlRow.ApplyTag != EApplyTag::Versa)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("VersaBuff(%d) effect(%d) something wrong category(%d) param1 CrowdControl(%d) ApplyTag(%d)."),
					VersaBuffRow.CmsType(), VersaEffectRows[0]->CmsType(), (int32)VersaEffectRows[0]->BuffEffectCategory,
					(int32)CrowdControlRow.CrowdControl, (int32)CrowdControlRow.ApplyTag);
			}
		}

		if (C->VersaSkillIds.Num() != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConst type(%d) VersaSkillIds length(%d) should be (%d)."),
				C->CmsType(), C->VersaSkillIds.Num(), CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
		}

		for (auto S : C->VersaSkillIds)
		{
			const FCMSSkillRow& VersaSkillRow = Param.CMS->GetSkillRowOrDummy(S);
			if (VersaSkillRow.IsInvalid())
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkillIds invalid Skill type(%d)."), VersaSkillRow.CmsType());
			}
			if (VersaSkillRow.SkillCategory != ESkillCategory::Versa)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkill(%d) SkillCategory(%d) should be 'Versa'."),
					VersaSkillRow.CmsType(), (int32)VersaSkillRow.SkillCategory);
			}
			if (VersaSkillRow.Target != ETargetType::Self)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkill(%d) Target(%d) should be 'Self'."),
					VersaSkillRow.CmsType(), (int32)VersaSkillRow.Target);
			}
			if (VersaSkillRow.ApplyTagTarget != EApplyTagTarget::Target)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkill(%d) ApplyTagTarget(%d) should be 'Target'."),
					VersaSkillRow.CmsType(), (int32)VersaSkillRow.ApplyTagTarget);
			}

			const TArray<const FCMSSkillEffectRow*>& VersaSkillEffectRows = VersaSkillRow.GetSkillEffect();
			if (VersaSkillEffectRows.Num() <= 0)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkill(%d) has no effects."), VersaSkillRow.CmsType());
			}
			for (auto E : VersaSkillEffectRows)
			{
				if (E->IsInvalid())
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkill(%d) has invalid Effect type(%d)."), VersaSkillRow.CmsType(), E->CmsType());
				}
				if (E->Target != ETargetType::Self)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkillEffect(%d) Target(%d) should be 'Self'."),
						E->CmsType(), (int32)E->Target);
				}
				if (E->ApplyTagTarget != EApplyTagTarget::Target)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkillEffect(%d) ApplyTagTarget(%d) should be 'Target'."),
						E->CmsType(), (int32)E->ApplyTagTarget);
				}

				if (E->EffectCategory == EEffectCategory::Buff)
				{
					const FCMSBuffRow& BuffRow = Param.CMS->GetBuffRowOrDummy(FBuffType(E->Param1));
					if (BuffRow.IsInvalid())
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkillEffect Buff(%d) invalid type."), BuffRow.CmsType());
					}
					if (BuffRow.Duration != 1)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkillEffect Buff(%d) Duration(%d) should be 1."),
							BuffRow.CmsType(), BuffRow.Duration);
					}
					if (BuffRow.BuffOverlap != EBuffOverlap::Overwrite)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkillEffect Buff(%d) should be 'Overwrite'."),
							BuffRow.CmsType(), (int32)BuffRow.BuffOverlap);
					}
					if (BuffRow.ApplyTagTarget != EApplyTagTarget::Target)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("VersaSkillEffect Buff(%d) ApplyTagTarget should be 'Target'."),
							BuffRow.CmsType(), (int32)BuffRow.ApplyTagTarget);
					}
				}
			}
		}
	}

	const UDataTable* BuffTable = (Cast<UCMSBase>(Param.CMS))->GetBuff();
	if (!BuffTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("BuffTable is null."));
		return true;
	}

	TArray<FCMSBuffRow*> Buffs;
	BuffTable->GetAllRows("FValidateVersa", Buffs);
	if (Buffs.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("BuffTable is empty."));
	}

	for (auto B : Buffs)
	{
		for (auto E : B->GetBuffEffect())
		{
			if (E->BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
			{
				const FCMSCrowdControlRow& CrowdControlRow = Param.CMS->GetCrowdControlRowOrDummy(FCrowdControlType(E->Param1));
				if (CrowdControlRow.CrowdControl == ECrowdControl::PriorityVersa)
				{
					if (B->Duration < 2)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("PriorityVersa Buff(%d) Duration should be more than 2."), B->CmsType());
					}
					if (B->BuffOverlap != EBuffOverlap::Overwrite)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("PriorityVersa Buff(%d) BuffOverlap should be 'Overwrite'."), B->CmsType());
					}
				}
			}
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateVersa done."));
	return true;
}

bool FValidateUnit::Update()
{
	const UDataTable* UnitTable = (Cast<UCMSBase>(Param.CMS))->GetUnit();
	if (!UnitTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("UnitTable is null."));
		return true;
	}

	TArray<FCMSUnitRow*> Units;
	UnitTable->GetAllRows("FValidateUnit", Units);
	if (Units.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("UnitTable is empty."));
	}

	const UDataTable* CharacterTable = Param.CMS->GetCharacter();
	if (!CharacterTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("CharacterTable is null."));
		return true;
	}

	TArray<FCMSCharacterRow*> Characters;
	CharacterTable->GetAllRows("FValidateUnit", Characters);

	const UDataTable* MonsterTable = Param.CMS->GetMonster();
	if (!MonsterTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("MonsterTable is null."));
		return true;
	}

	TArray<FCMSMonsterRow*> Monsters;
	MonsterTable->GetAllRows("FValidateUnit", Monsters);

	const UDataTable* WaveTable = Param.CMS->GetWave();
	if (!WaveTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("WaveTable is null."));
		return true;
	}

	TArray<FCMSWaveRow*> Waves;
	WaveTable->GetAllRows("FValidateUnit", Waves);
	if (Waves.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("WaveTable is empty."));
	}

	const UDataTable* SagaTable = Param.CMS->GetSaga();
	if (!SagaTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is null."));
		return true;
	}

	TArray<FCMSSagaRow*> Sagas;
	SagaTable->GetAllRows("FValidateUnit", Sagas);
	if (Sagas.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is empty."));
	}

	for (auto U : Units)
	{
		bool IsCharacter = false;
		for (auto C : Characters)
		{
			if (C->Type == U->Type && C->XpExclusive == false)
			{
				IsCharacter = true;
				break;
			}
		}

		bool IsSystemJoker = false;
		for (auto S : Sagas)
		{
			for (auto J : S->GetJoker())
			{
				if (J->Type == U->Type)
				{
					IsSystemJoker = true;
					break;
				}
			}
			if (IsSystemJoker)
			{
				break;
			}
		}

		if (IsSystemJoker && !IsCharacter)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) System Joker should be 'Character'."), U->CmsType());
		}

		bool IsWaveMonster = false;
		for (auto W : Waves)
		{
			if (W->Spawns01.Find(U->Type) != INDEX_NONE
				|| W->Spawns02.Find(U->Type) != INDEX_NONE
				|| W->Spawns03.Find(U->Type) != INDEX_NONE)
			{
				IsWaveMonster = true;

				if (IsCharacter)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Wave(%d) Monster should not be 'Character'."), U->CmsType(), W->CmsType());
				}
				else if (IsSystemJoker)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Wave(%d) Monster should not be 'SystemJoker'."), U->CmsType(), W->CmsType());
				}
				break;
			}
		}

		bool IsMonster = false;
		for (auto M : Monsters)
		{
			if (M->Type == U->Type)
			{
				IsMonster = true;

				if (IsCharacter)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Monster(%d) should not be 'Character'."), M->CmsType());
				}
				else if (IsSystemJoker)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Monster(%d) should not be 'SystemJoker'."), M->CmsType());
				}
				break;
			}
		}

		if (IsMonster || IsWaveMonster)
		{
			if ((U->AttributeCategory < EAttributeCategory::MN_Weak
				|| U->AttributeCategory > EAttributeCategory::MB_Legend)
				&& U->AttributeCategory != EAttributeCategory::StaticMonster)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Attribute Category should be 'Monster series'."), U->CmsType());
			}
		}

		if (IsSystemJoker)
		{
			if (U->AttributeCategory != EAttributeCategory::SystemJoker)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Attribute Category should be 'SystemJoker'."), U->CmsType());
			}
		}

		if (IsCharacter)
		{
			if (U->AttributeCategory != EAttributeCategory::Character
				&& U->AttributeCategory != EAttributeCategory::SystemJoker)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Attribute Category should be 'Character'."), U->CmsType());
			}
		}

		bool NormalAceNote = false;
		bool NormalBreakNote = false;
		bool NormalCloserNote = false;
		for (auto S : U->GetNormalSkills())
		{
			if (S->SkillCategory != ESkillCategory::Normal)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Skill(%d) Category should be 'Normal'."), U->CmsType(), S->CmsType());
			}
			else
			{
				if (S->SkillNote == ESkillNote::None)
				{
					if (IsCharacter || IsSystemJoker)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Normal Skill(%d) should have SkillNote."), U->CmsType(), S->CmsType());
					}
				}
				else
				{
					switch (S->SkillNote)
					{
					case ESkillNote::Ace:
						NormalAceNote = true;
						break;
					case ESkillNote::Break:
						NormalBreakNote = true;
						break;
					case ESkillNote::Closer:
						NormalCloserNote = true;
						break;
					default:
						break;
					}

					if (IsMonster || IsWaveMonster)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Normal Skill(%d) should not have SkillNote."), U->CmsType(), S->CmsType());
					}
				}
			}

			for (auto E : S->GetSkillEffect())
			{
				if (E->EffectCategory == EEffectCategory::FirstWaitTime
					|| E->EffectCategory == EEffectCategory::WaitTime)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) can not have WaitTime Normal Skill(%d)."), U->CmsType(), S->CmsType());
					break;
				}
			}
		}
		if (IsCharacter || IsSystemJoker)
		{
			if (!NormalAceNote)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) should not have Ace normal skill."), U->CmsType());
			}
			if (!NormalBreakNote)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) should not have Break normal skill."), U->CmsType());
			}
			if (!NormalCloserNote)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) should not have Closer normal skill."), U->CmsType());
			}
		}

		for (auto S : U->GetTurnSkills())
		{
			if (S->SkillCategory != ESkillCategory::TurnBegin)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Skill(%d) Category should be 'TurnBegin'."), U->CmsType(), S->CmsType());
			}

			if (IsMonster || IsWaveMonster)
			{
				bool bPatternSkill = false;
				const FCMSMonsterRow& M = Param.CMS->GetMonsterRowOrDummy(FMonsterType(U->Type));
				if (!M.IsInvalid())
				{
					for (auto P : M.GetPatterns())
					{
						if (P->GetSkill().Type == S->Type)
						{
							bPatternSkill = true;
							break;
						}
					}
				}

				for (auto E : S->GetSkillEffect())
				{
					if (E->EffectCategory == EEffectCategory::CoolTime && bPatternSkill == false)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("Monster Unit(%d) can not have CoolTime Turn Skill(%d)."), U->CmsType(), S->CmsType());
						break;
					}
				}
			}
		}

		for (auto S : U->GetSupportSkills())
		{
			if (S->SkillCategory != ESkillCategory::Support)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Skill(%d) Category should be 'Support'."), U->CmsType(), S->CmsType());
			}
			else
			{
				if (IsMonster || IsWaveMonster)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) should not have support Skill(%d)."), U->CmsType(), S->CmsType());
				}
			}

			for (auto E : S->GetSkillEffect())
			{
				if (E->EffectCategory == EEffectCategory::FirstWaitTime
					|| E->EffectCategory == EEffectCategory::WaitTime)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) can not have WaitTime support Skill(%d)."), U->CmsType(), S->CmsType());
					break;
				}
			}
		}

		for (auto S : U->GetUltimateSkills())
		{
			if (S->SkillCategory != ESkillCategory::Ultimate)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Skill(%d) Category should be 'Ultimate'."), U->CmsType(), S->CmsType());
			}

			if (IsMonster || IsWaveMonster)
			{
				for (auto E : S->GetSkillEffect())
				{
					if (E->EffectCategory == EEffectCategory::CoolTime)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("Monster Unit(%d) can not have cooltime Ultimate Skill(%d)."), U->CmsType(), S->CmsType());
						break;
					}
				}
			}
		}

		for (auto S : U->GetDoubleSkill())
		{
			if (S->SkillCategory != ESkillCategory::Double)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) Skill(%d) Category should be 'Double'."), U->CmsType(), S->CmsType());
			}
			else
			{
				if (IsMonster || IsWaveMonster)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) should not have double Skill(%d)."), U->CmsType(), S->CmsType());
				}

				if (S->Target != ETargetType::HostileSingle)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) double Skill(%d) target should be 'HostileSingle'."), U->CmsType(), S->CmsType());
				}

				for (const FCMSSkillEffectRow* Row : S->GetSkillEffect())
				{
					if (Row->Target != ETargetType::HostileSingle)
					{
						GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) double Skill(%d) effect(%d) target should be 'HostileSingle'."), U->CmsType(), S->CmsType(), Row->CmsType());
					}
				}
			}

			for (auto E : S->GetSkillEffect())
			{
				if (E->EffectCategory == EEffectCategory::FirstWaitTime
					|| E->EffectCategory == EEffectCategory::WaitTime)
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Unit(%d) can not have WaitTime double Skill(%d)."), U->CmsType(), S->CmsType());
					break;
				}
			}
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateUnit done."));
	return true;
}

bool FValidateWave::Update()
{
	const UDataTable* WaveTable = Param.CMS->GetWave();
	if (!WaveTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("WaveTable is null."));
		return true;
	}

	TArray<FCMSWaveRow*> Waves;
	WaveTable->GetAllRows("FValidateWave", Waves);
	if (Waves.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("WaveTable is empty."));
	}

	for (auto W : Waves)
	{
		int32 MainMonster = 0;
		int32 SubMonster = 0;

		for (int32 T : W->Spawns01)
		{
			if (T != UnitTypeInvalid)
			{
				const FCMSUnitRow& Unit = Param.CMS->GetUnitRowOrDummy(FUnitType(T));
				if (Unit.IsInvalid())
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) Spawns01(%d) invalid unit."), W->CmsType(), Unit.CmsType());
				}
				else
				{
					if (Unit.MonsterParts == EMonsterParts::Main)
					{
						++MainMonster;
					}
					else if (Unit.MonsterParts == EMonsterParts::Sub)
					{
						++SubMonster;
					}
				}
			}
		}

		if (W->Spawns01.Num() != W->Spawns01Ratio.Num())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) Spawns01, Spawns01Ratio are not matched"), W->CmsType());
		}

		for (int32 T : W->Spawns02)
		{
			if (T != UnitTypeInvalid)
			{
				const FCMSUnitRow& Unit = Param.CMS->GetUnitRowOrDummy(FUnitType(T));
				if (Unit.IsInvalid())
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) Spawn02(%d) invalid unit."), W->CmsType(), Unit.CmsType());
				}
				else
				{
					if (Unit.MonsterParts == EMonsterParts::Main)
					{
						++MainMonster;
					}
					else if (Unit.MonsterParts == EMonsterParts::Sub)
					{
						++SubMonster;
					}
				}
			}
		}

		if (W->Spawns02.Num() != W->Spawns02Ratio.Num())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) Spawns02, Spawns02Ratio are not matched"), W->CmsType());
		}

		for (int32 T : W->Spawns03)
		{
			if (T != UnitTypeInvalid)
			{
				const FCMSUnitRow& Unit = Param.CMS->GetUnitRowOrDummy(FUnitType(T));
				if (Unit.IsInvalid())
				{
					GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) Spawn03(%d) invalid unit."), W->CmsType(), Unit.CmsType());
				}
				else
				{
					if (Unit.MonsterParts == EMonsterParts::Main)
					{
						++MainMonster;
					}
					else if (Unit.MonsterParts == EMonsterParts::Sub)
					{
						++SubMonster;
					}
				}
			}
		}

		if (W->Spawns03.Num() != W->Spawns03Ratio.Num())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) Spawns03, Spawns03Ratio are not matched"), W->CmsType());
		}

		if (MainMonster > 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) has too many main monsters(%d)"), W->CmsType(), MainMonster);
		}
		if (MainMonster < 1 && SubMonster > 0)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) has no main monster but sub monsters(%d)"), W->CmsType(), SubMonster);
		}
		if (MainMonster > 0 && SubMonster < 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Wave(%d) has main monster but no sub monsters"), W->CmsType());
		}
	}


	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateWave done."));
	return true;
}

bool FValidateABC::Update()
{
	const UDataTable* SkillTable = Param.CMS->GetSkill();
	if (!SkillTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillTable is null."));
		return true;
	}

	TArray<FCMSSkillRow*> Skills;
	SkillTable->GetAllRows("FValidateABC", Skills);
	if (Skills.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillTable is empty."));
	}

	for (auto S : Skills)
	{
		if (S->SkillCategory != ESkillCategory::Normal
			&& S->SkillCategory != ESkillCategory::Chain)
		{
			if (S->SkillNote != ESkillNote::None)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Skill(%d) Category(%d) note should be 'None'."), S->CmsType(), (int32)S->SkillCategory);
			}
		}
	}

	const UDataTable* FormulaConstTable = Param.CMS->GetFormulaConst();
	if (!FormulaConstTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable is null."));
		return true;
	}

	TArray<FCMSFormulaConstRow*> Consts;
	FormulaConstTable->GetAllRows("FValidateABC", Consts);
	if (Consts.Num() <= 0 || Consts.Num() != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("wrong FormulaConstTable row count(%d)."), Consts.Num());
	}

	for (auto C : Consts)
	{
		const FCMSSkillRow& ChainAceSkillRow = Param.CMS->GetSkillRowOrDummy(C->ChainAceSkillId);
		if (ChainAceSkillRow.IsInvalid())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainAceSkillId invalid skill type(%d)."), C->ChainAceSkillId);
		}
		else
		{
			if (ChainAceSkillRow.SkillCategory != ESkillCategory::Chain)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainAceSkillId(%d) category(%d) should be 'Chain'."), C->ChainAceSkillId, (int32)ChainAceSkillRow.SkillCategory);
			}
			if (ChainAceSkillRow.SkillNote != ESkillNote::Ace)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainAceSkillId(%d) note(%d) should be 'Ace'."), C->ChainAceSkillId, (int32)ChainAceSkillRow.SkillCategory);
			}
			if (ChainAceSkillRow.ApplyTagTarget != EApplyTagTarget::Target)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainAceSkillId(%d) ApplyTagTarget(%d) should be 'Target'."), C->ChainAceSkillId, (int32)ChainAceSkillRow.ApplyTagTarget);
			}
		}

		const FCMSSkillRow& ChainBreakSkillRow = Param.CMS->GetSkillRowOrDummy(C->ChainBreakSkillId);
		if (ChainBreakSkillRow.IsInvalid())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainBreakSkillId invalid skill type(%d)."), C->ChainBreakSkillId);
		}
		else
		{
			if (ChainBreakSkillRow.SkillCategory != ESkillCategory::Chain)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainBreakSkillId(%d) category(%d) should be 'Chain'."), C->ChainBreakSkillId, (int32)ChainBreakSkillRow.SkillCategory);
			}
			if (ChainBreakSkillRow.SkillNote != ESkillNote::Break)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainBreakSkillId(%d) note(%d) should be 'Break'."), C->ChainBreakSkillId, (int32)ChainBreakSkillRow.SkillNote);
			}
			if (ChainBreakSkillRow.ApplyTagTarget != EApplyTagTarget::Target)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainBreakSkillId(%d) ApplyTagTarget(%d) should be 'Target'."), C->ChainBreakSkillId, (int32)ChainBreakSkillRow.ApplyTagTarget);
			}
		}

		const FCMSSkillRow& ChainCloserSkillRow = Param.CMS->GetSkillRowOrDummy(C->ChainCloserSkillId);
		if (ChainCloserSkillRow.IsInvalid())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainCloserSkillId invalid skill type(%d)."), C->ChainCloserSkillId);
		}
		else
		{
			if (ChainCloserSkillRow.SkillCategory != ESkillCategory::Chain)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainCloserSkillId(%d) category(%d) should be 'Chain'."), C->ChainCloserSkillId, (int32)ChainCloserSkillRow.SkillCategory);
			}
			if (ChainCloserSkillRow.SkillNote != ESkillNote::Closer)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainAceSkillId(%d) note(%d) should be 'Ace'."), C->ChainCloserSkillId, (int32)ChainCloserSkillRow.SkillNote);
			}
			if (ChainCloserSkillRow.ApplyTagTarget != EApplyTagTarget::Target)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("FormulaConstTable::ChainAceSkillId(%d) ApplyTagTarget(%d) should be 'Target'."), C->ChainCloserSkillId, (int32)ChainCloserSkillRow.ApplyTagTarget);
			}
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateABC done."));
	return true;
}

bool FValidateApplyTag::Update()
{
	const UDataTable* SkillTable = Param.CMS->GetSkill();
	if (!SkillTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillTable is null."));
		return true;
	}

	TArray<FCMSSkillRow*> Skills;
	SkillTable->GetAllRows("FValidateApplyTag", Skills);
	if (Skills.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillTable is empty."));
	}

	const UDataTable* SkillEffectTable = (Cast<UCMSBase>(Param.CMS))->GetSkillEffect();
	if (!SkillEffectTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffectTable is null."));
		return true;
	}

	TArray<FCMSSkillEffectRow*> Effects;
	SkillEffectTable->GetAllRows("FValidateApplyTag", Effects);
	if (Effects.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffectTable is empty."));
	}

	const UDataTable* BuffTable = (Cast<UCMSBase>(Param.CMS))->GetBuff();
	if (!BuffTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("BuffTable is null."));
		return true;
	}

	TArray<FCMSBuffRow*> Buffs;
	BuffTable->GetAllRows("FValidateApplyTag", Buffs);
	if (Buffs.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("BuffTable is empty."));
	}

	for (auto S : Skills)
	{
		int32 ChanceApplyTagCount = 0;
		for (auto T : S->ApplyTagEquals)
		{
			if (T >= EApplyTag::Chance5 && T <= EApplyTag::Chance95)
			{
				++ChanceApplyTagCount;
			}
		}
		for (auto T : S->ApplyTagNotEquals)
		{
			if (T >= EApplyTag::Chance5 && T <= EApplyTag::Chance95)
			{
				++ChanceApplyTagCount;
			}
		}

		if (ChanceApplyTagCount > 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Skill(%d) should have a ChanceXX applytag"), S->CmsType());
		}
	}

	for (auto E : Effects)
	{
		int32 ChanceApplyTagCount = 0;
		for (auto T : E->ApplyTagEquals)
		{
			if (T >= EApplyTag::Chance5 && T <= EApplyTag::Chance95)
			{
				++ChanceApplyTagCount;
			}
		}
		for (auto T : E->ApplyTagNotEquals)
		{
			if (T >= EApplyTag::Chance5 && T <= EApplyTag::Chance95)
			{
				++ChanceApplyTagCount;
			}
		}

		if (ChanceApplyTagCount > 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("SkillEffect(%d) should have a ChanceXX applytag"), E->CmsType());
		}
	}

	for (auto B : Buffs)
	{
		int32 ChanceApplyTagCount = 0;
		for (auto T : B->ApplyTagEquals)
		{
			if (T >= EApplyTag::Chance5 && T <= EApplyTag::Chance95)
			{
				++ChanceApplyTagCount;
			}
		}
		for (auto T : B->ApplyTagNotEquals)
		{
			if (T >= EApplyTag::Chance5 && T <= EApplyTag::Chance95)
			{
				++ChanceApplyTagCount;
			}
		}

		if (ChanceApplyTagCount > 1)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Buff(%d) should have a ChanceXX applytag"), B->CmsType());
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateApplyTag done."));
	return true;
}

bool FValidatePet::Update()
{
	const UDataTable* PetTable = Param.CMS->GetPet();
	if (!PetTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("PetTable is null."));
		return true;
	}

	TArray<FCMSPetRow*> Pets;
	PetTable->GetAllRows("FValidatePet", Pets);
	if (Pets.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("PetTable is empty."));
	}

	for (auto P : Pets)
	{
		for (auto S : P->GetSkills())
		{
			if (S->SkillCategory != ESkillCategory::Pet)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Pet(%d) skill(%d) should be 'Pet' SkillCategory."), P->CmsType(), S->CmsType());
			}
			if (S->ApplyTagTarget != EApplyTagTarget::Target)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Pet(%d) skill(%d) ApplyTagTarget should be 'Target'."), P->CmsType(), S->CmsType());
			}
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidatePet done."));
	return true;
}

bool FValidateMonster::Update()
{
	const UDataTable* MonsterTable = Param.CMS->GetMonster();
	if (!MonsterTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("MonsterTable is null."));
		return true;
	}

	TArray<FCMSMonsterRow*> Monsters;
	MonsterTable->GetAllRows("FValidateMonster", Monsters);
	if (Monsters.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("MonsterTable is empty."));
	}

	for (auto M : Monsters)
	{
		const FCMSUnitRow& UnitRow = M->GetUnit();
		if (UnitRow.IsInvalid())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Monster(%d) Unit is invalid."), M->Type);
		}
		else if (UnitRow.Type != M->Type)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Monster(%d) ID should be equal with Unit ID."), M->Type);
		}

		int32 Accum = 0;
		for (auto C : M->TurnSkillGroup)
		{
			Accum += C;
		}

		int32 patternTurnSkillCount = 0;
		for (auto P : M->GetPatterns())
		{
			if (P->GetSkill().SkillCategory == ESkillCategory::TurnBegin)
			{
				++patternTurnSkillCount;
			}
		}

		if (Accum > 0 && Accum != UnitRow.GetTurnSkills().Num() - patternTurnSkillCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Monster(%d) TurnSkillGroup Accum Count(%d) should be equal Unit(%d) Turn Skill Count(%d). Total(%d), Pattern(%d)"),
				M->Type, Accum, UnitRow.Type, UnitRow.GetTurnSkills().Num() - patternTurnSkillCount, UnitRow.GetTurnSkills().Num(), patternTurnSkillCount);
		}

		TArray<const FCMSSkillRow*> UnitSkills = UnitRow.GetTurnSkills();
		UnitSkills.Append(UnitRow.GetNormalSkills());
		UnitSkills.Append(UnitRow.GetUltimateSkills());
		for (auto P : M->GetPatterns())
		{
			bool Found = false;
			for (auto S : UnitSkills)
			{
				if (S->Type == P->GetSkill().Type)
				{
					Found = true;
					break;
				}
			}

			if (!Found)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Monster(%d) has not Pattern(%d) Skill(%d)."),
					M->Type, P->Type, P->GetSkill().Type);
			}

			if (P->LiveTurnCount.Num() != 3) // less, equal, greater condition.
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("Monster(%d) Pattern(%d) LiveTurnCount num should be 3."),
					M->Type, P->Type);
			}
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateMonster done."));
	return true;
}

bool FValidateAttributeDifficulty::Update()
{
	const UDataTable* SagaTable = Param.CMS->GetSaga();
	if (!SagaTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is null."));
		return true;
	}

	TArray<FCMSSagaRow*> Sagas;
	SagaTable->GetAllRows("FValidateAttributeDifficulty", Sagas);
	if (Sagas.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is empty."));
	}

	const UDataTable* DifficultyTable = Param.CMS->GetAttributeDifficulty();
	if (!DifficultyTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("DifficultyTable is null."));
		return true;
	}

	TArray<FCMSAttributeDifficultyRow*> Difficulties;
	DifficultyTable->GetAllRows("FValidateAttributeDifficulty", Difficulties);
	if (Difficulties.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("DifficultyTable is empty."));
	}

	for (auto D : Difficulties)
	{
		if (D->GetAdditionalPoint().IsInvalid())
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("AttributeDifficulty(%d) should have an AdditionalPoint."), D->CmsType());
		}
	}

	for (auto S : Sagas)
	{
		bool FoundDifficulty = false;
		for (auto D : Difficulties)
		{
			if (S->Difficulty == D->Difficulty)
			{
				FoundDifficulty = true;
				break;
			}
		}

		if (!FoundDifficulty)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Saga(%d) Difficulty(%d) is not exist at AttributeDifficulty sheet."),
				S->CmsType(), S->Difficulty);
		}
	}

	static_assert(static_cast<int32>(EAttributeCategory::None) == 0, "static condition.");
	static_assert(static_cast<int32>(EAttributeCategory::MB_Legend) == 17, "static condition.");
	for (int i = (int32)EAttributeCategory::None; i <= (int32)EAttributeCategory::MB_Legend; ++i)
	{
		EAttributeCategory Category = (EAttributeCategory)i;

		bool FoundDefault = false;
		for (auto D : Difficulties)
		{
			if (D->Difficulty != CombatCubeConst::Q6_DEFAULT_DIFFICULTY)
			{
				continue;
			}

			if (Category == D->AttributeCategory)
			{
				FoundDefault = true;
				break;
			}
		}

		if (!FoundDefault)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("AttributeCategory(%d) should have default difficulty(1) at AttributeDifficulty sheet."), i);
		}
	}

	static_assert(static_cast<int32>(EAttributeCategory::MN_Weak) == 8, "static condition.");
	static_assert(static_cast<int32>(EAttributeCategory::MB_Legend) == 17, "static condition.");
	int DifficultySegment = 0;
	for (auto Diffi : Difficulties)
	{
		if (Diffi->Difficulty == DifficultySegment)
		{
			continue;
		}

		DifficultySegment = Diffi->Difficulty;

		bool Found = false;
		for (int i = (int32)EAttributeCategory::MN_Weak; i <= (int32)EAttributeCategory::MB_Legend; ++i)
		{
			for (auto D : Difficulties)
			{
				if (D->Difficulty == DifficultySegment)
				{
					Found = true;
					break;
				}
			}

			if (!Found)
			{
				GLog->Logf(ELogVerbosity::Error, TEXT("AttributeCategory(%d) difficulty(%d) is not exist at AttributeDifficulty sheet."), i, DifficultySegment);
			}
		}
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateAttributeDifficulty done."));
	return true;
}

bool FValidateSaga::Update()
{
	const UDataTable* SagaTable = Param.CMS->GetSaga();
	if (!SagaTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is null."));
		return true;
	}

	TArray<FCMSSagaRow*> Sagas;
	SagaTable->GetAllRows("FValidateSaga", Sagas);
	if (Sagas.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is empty."));
	}

	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateSaga done."));
	return true;
}

bool FValidateDifficultyNatureBonus::Update()
{
	const UDataTable* SagaTable = Param.CMS->GetSaga();
	if (!SagaTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is null."));
		return true;
	}

	TArray<FCMSSagaRow*> Sagas;
	SagaTable->GetAllRows("FValidateDifficultyNatureBonus", Sagas);
	if (Sagas.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("SagaTable is empty."));
	}

	const UDataTable* DifficultyTable = ((UCMSBase*)(Param.CMS))->GetDifficultyNatureBonus();
	if (!DifficultyTable)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("DifficultyTable is null."));
		return true;
	}

	TArray<FCMSDifficultyNatureBonusRow*> Difficulties;
	DifficultyTable->GetAllRows("FValidateAttributeDifficulty", Difficulties);
	if (Difficulties.Num() <= 0)
	{
		GLog->Logf(ELogVerbosity::Error, TEXT("DifficultyTable is empty."));
	}

	for (auto D : Difficulties)
	{
		int32 NatureCount = (int32)ENatureType::Dark - (int32)ENatureType::Fire + 1;
		if (D->AllyNatureFireBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::AllyNatureFireBonus count(%d)."), D->AllyNatureFireBonus.Num());
		}
		if (D->AllyNatureWaterBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::AllyNatureWaterBonus count(%d)."), D->AllyNatureWaterBonus.Num());
		}
		if (D->AllyNatureWindBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::AllyNatureWindBonus count(%d)."), D->AllyNatureWindBonus.Num());
		}
		if (D->AllyNatureLightBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::AllyNatureLightBonus count(%d)."), D->AllyNatureLightBonus.Num());
		}
		if (D->AllyNatureDarkBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::AllyNatureDarkBonus count(%d)."), D->AllyNatureDarkBonus.Num());
		}

		if (D->EnemyNatureFireBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::EnemyNatureFireBonus count(%d)."), D->EnemyNatureFireBonus.Num());
		}
		if (D->EnemyNatureWaterBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::EnemyNatureWaterBonus count(%d)."), D->EnemyNatureWaterBonus.Num());
		}
		if (D->EnemyNatureWindBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::EnemyNatureWindBonus count(%d)."), D->EnemyNatureWindBonus.Num());
		}
		if (D->EnemyNatureLightBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::EnemyNatureLightBonus count(%d)."), D->EnemyNatureLightBonus.Num());
		}
		if (D->EnemyNatureDarkBonus.Num() != NatureCount)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("wrong DifficultyNatureBonusTable::EnemyNatureDarkBonus count(%d)."), D->EnemyNatureDarkBonus.Num());
		}
	}

	for (auto S : Sagas)
	{
		bool FoundDifficulty = false;
		for (auto D : Difficulties)
		{
			if (S->Difficulty == D->Difficulty)
			{
				FoundDifficulty = true;
				break;
			}
		}

		if (!FoundDifficulty)
		{
			GLog->Logf(ELogVerbosity::Error, TEXT("Saga(%d) Difficulty(%d) is not exist at DifficultyNatureBonus sheet."),
				S->CmsType(), S->Difficulty);
		}
	}
	
	GLog->Logf(ELogVerbosity::Display, TEXT("FValidateAttributeDifficulty done."));
	return true;
}

#endif // UE_BUILD_SHIPPING
