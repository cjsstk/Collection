// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "AutomationHelper.h"

#include "CombatPresenter.h"
#include "GameResource.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6Define.h"
#include "Q6Log.h"
#include "Unit.h"

UAutomationHelper::UAutomationHelper(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bStarted(false)
{
}

int32 UAutomationHelper::PopUnspawnedUnitType()
{
	if (UnspawnedUnitTypes.Num() <= 0)
	{
		return UnitTypeInvalid.x;
	}

	int32 PoppedUnitType = UnspawnedUnitTypes.Pop(true);
	return PoppedUnitType;
}

void UAutomationHelper::GatherAllUnitTypes(const TArray<FCCCombatSeedUnit>& InCombatSeedUnits)
{
#if !UE_BUILD_SHIPPING
	UCMS* InCMS = GetCMS();
	const UDataTable* CharacterDataTable = InCMS->GetCharacter();
	TArray<FCMSCharacterRow *> OutRowArray;
	CharacterDataTable->GetAllRows("Automation", OutRowArray);
	UnspawnedUnitTypes.Reset(0);
	TSet<int32> AddedModels;
	for (int i = 0; i < InCombatSeedUnits.Num(); ++i)
	{
		AddedModels.Add(InCMS->GetModelTypeFromUnitType(InCombatSeedUnits[i].UnitType));
	}

	for (auto& CurRow : OutRowArray)
	{
		if (CurRow->XpExclusive)
		{
			continue;
		}
		const FCMSUnitRow& CharUnit = CurRow->GetUnit();
		if (CharUnit.IsInvalid())
		{
			continue;
		}

		int32 CurCharUnitType = CharUnit.Type;
		if (InCombatSeedUnits.FindByPredicate([CurCharUnitType](const FCCCombatSeedUnit& SeedUnit) {
			return SeedUnit.UnitType == CurCharUnitType;
		}))
		{
			continue;
		}

		int32 UnitModelType = InCMS->GetModelTypeFromUnitType(CurCharUnitType);
		const FUnitModelAssetRow* ModelAsset = GetGameResource().GetUnitModelAssetRowPtr(UnitModelType);
		if (!ModelAsset)
		{
			// empty model unit does not need to populate.
			continue;
		}

		if (AddedModels.Contains(UnitModelType))
		{
			Q6_AUTO_LOG(Display, "Already added model. unique model per skeletal mesh UnitModelType: %d", UnitModelType);
			continue;
		}

		AddedModels.Add(UnitModelType);
		UnspawnedUnitTypes.Add(CurCharUnitType);
	}
#endif
}

void UAutomationHelper::ReplaceUnits()
{
#if !UE_BUILD_SHIPPING
	AQ6CombatGameMode* GameMode = GetCombatGameMode(this);
	ACombatCube* CombatCube = GameMode ? GameMode->CombatCube : nullptr;
	if (!CombatCube)
	{
		Q6_AUTO_LOG(Error, "Error Status while replace units");
		return;
	}

	TArray<int32, TInlineAllocator<CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT>> ReplacedUnitIds;
	for (auto& InUsedSkill : CacheUsedSkillMap)
	{
		const FCacheUsedSkill& InCacheUsedSkill = InUsedSkill.Value;
		if (InCacheUsedSkill.bNormalSkillUsed &&
			InCacheUsedSkill.bUltimateSkillUsed &&
			InCacheUsedSkill.bTurnSkillUsed)
		{
			FUnitType PoppedUnitType(PopUnspawnedUnitType());
			if (PoppedUnitType == UnitTypeInvalid)
			{
				continue;
			}

			CombatCube->CheatReplaceUnit(InCacheUsedSkill.UnitId, PoppedUnitType, ESpawnReason::Automation);
			ReplacedUnitIds.Add(InCacheUsedSkill.UnitId.X);
			Q6_AUTO_LOG(Display, "Replace Unit From %d To %d", InCacheUsedSkill.UnitType, PoppedUnitType.x);
		}
	}
	for (int32 i = 0; i < ReplacedUnitIds.Num(); ++i)
	{
		CacheUsedSkillMap.Remove(ReplacedUnitIds[i]);
	}
#endif
}

void UAutomationHelper::OnSpawnUnit(const FCCUnitState& InUnitState)
{
#if !UE_BUILD_SHIPPING
	if (!InUnitState.IsAlly())
	{
		return;
	}

	if (CacheUsedSkillMap.Find(InUnitState.UnitId.X))
	{
		// already added
		return;
	}

	FCacheUsedSkill& AddedCacheUsedSkill = CacheUsedSkillMap.Add(InUnitState.UnitId.X);
	AddedCacheUsedSkill.UnitType = InUnitState.UnitType.x;
	AddedCacheUsedSkill.bNormalSkillUsed = false;
	AddedCacheUsedSkill.bUltimateSkillUsed = false;
	AddedCacheUsedSkill.bTurnSkillUsed = false;
	AddedCacheUsedSkill.UnitId = InUnitState.UnitId;
#endif
}

void UAutomationHelper::UseSkill()
{
#if !UE_BUILD_SHIPPING
	for (auto& InUsedSkill : CacheUsedSkillMap)
	{
		FCacheUsedSkill& InCacheUsedSkill = InUsedSkill.Value;
		if (!InCacheUsedSkill.bUltimateSkillUsed)
		{
			UseSkillBySkillCategory(InCacheUsedSkill.UnitId, ESkillCategory::Ultimate);
			InCacheUsedSkill.bUltimateSkillUsed = true;
			continue;
		}

		InCacheUsedSkill.bNormalSkillUsed = true;
		UseSkillBySkillCategory(InCacheUsedSkill.UnitId, ESkillCategory::Normal);
	}
#endif
}

void UAutomationHelper::UseTurnSkill()
{
#if !UE_BUILD_SHIPPING
	for (auto& InUsedSkill : CacheUsedSkillMap)
	{
		FCacheUsedSkill& InCacheUsedSkill = InUsedSkill.Value;
		if (InCacheUsedSkill.bTurnSkillUsed)
		{
			continue;
		}

		UseSkillBySkillCategory(InCacheUsedSkill.UnitId, ESkillCategory::TurnBegin);
		InCacheUsedSkill.bTurnSkillUsed = true;
	}
#endif
}

void UAutomationHelper::UseSkillBySkillCategory(FCCUnitId InUnitId, ESkillCategory InSkillCategory)
{
#if !UE_BUILD_SHIPPING
	AQ6CombatGameMode* GameMode = GetCombatGameMode(this);
	ACombatCube* CombatCube = GameMode ? GameMode->CombatCube : nullptr;
	ACombatPresenter* InCombatPresenter = GameMode ? GameMode->Presenter : nullptr;
	if (!InCombatPresenter || !CombatCube)
	{
		Q6_AUTO_LOG(Error, "Error Status while using skill");
		return;
	}

	const AUnit* FoundUnit = InCombatPresenter->FindUnit(InUnitId);
	if (!FoundUnit)
	{
		Q6_AUTO_LOG(Error, "unit not found while using skill");
		return;
	}

	const FUnitState& FoundUnitState = FoundUnit->GetUnitState();
	if (InSkillCategory == ESkillCategory::Ultimate)
	{
		if (FoundUnitState.Ultimates.IsValidIndex(0))
		{
			const FUltimateSkillSequenceAssetRow& InAssetRow = FoundUnit->GetUltimateSkillSequenceAssetRow(FoundUnitState.Ultimates[0].SkillType);
			if (!InAssetRow.SkillSequence.IsNull())
			{
				Q6_AUTO_LOG(Display, "Unit(%d) use ultimate skill", FoundUnitState.UnitType);
				CombatCube->UseSkill(InUnitId, FoundUnitState.Ultimates[0].SkillId, 0);
				return;
			}
			else
			{
				Q6_AUTO_LOG(Warning, "Unit(%d) have no ultimate sequence for skill(%d)", FoundUnitState.UnitType, FoundUnitState.Ultimates[0].SkillType);
			}
		}
		else
		{
			Q6_AUTO_LOG(Error, "Unit(%d) have no ultimate skill", FoundUnitState.UnitType);
		}
	}
	else if (InSkillCategory == ESkillCategory::TurnBegin)
	{
		if (FoundUnitState.TurnBegins.IsValidIndex(0))
		{
			Q6_AUTO_LOG(Display, "Unit(%d) use turn skill", FoundUnitState.UnitType);
			CombatCube->UseSkill(InUnitId, FoundUnitState.TurnBegins[0].SkillId, 0);
		}
		else
		{
			Q6_AUTO_LOG(Error, "Unit(%d) have no turn skill", FoundUnitState.UnitType);
		}
		return;
	}

	if (!FoundUnitState.Normals.IsValidIndex(0))
	{
		Q6_AUTO_LOG(Error, "Unit(%d) have no normal skill", FoundUnitState.UnitType);
		return;
	}

	Q6_AUTO_LOG(Display, "Unit(%d) use normal skill", FoundUnitState.UnitType);
	CombatCube->UseSkill(InUnitId, FoundUnitState.Normals[0].SkillId, 0);
#endif
}