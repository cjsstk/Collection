#include "Q6Minimal.h"

#if WITH_EDITOR && !UE_BUILD_SHIPPING

#include "AssetRegistryModule.h"
#include "Tests/AutomationCommon.h"
#include "Tests/AutomationEditorCommon.h"
#include "Editor.h"
#include "EngineGlobals.h"
#include "FileHelpers.h"
#include "Kismet2/KismetEditorUtilities.h"
#include "MovieSceneSequence.h"
#include "Q6.h"
#include "Q6AutomationCommon.h"
#include "Q6Log.h"
#include "RHI.h"
#include "Stats/StatsData.h"

#if STATS

/////////////////////////////////////////////////////////////////////////////////////
// Static Variables

struct StatJsonData
{
	FName Name;
	FString Value;
};

static FDelegateHandle SaveStatsDelegateHandle;
static FString SaveStatFilePath;
static TArray<StatJsonData> SaveJsonData;
static bool bDumpStateFinished = false;

/////////////////////////////////////////////////////////////////////////////////////
// Q6Automation

namespace Q6Automation
{
	/**
	* Predicate to sort stats into reverse order of definition, which historically is how people specified a preferred order.
	* Redefine here using namespace to avoid modifying original engine code
	*/
	struct FGroupSort
	{
		FORCEINLINE bool operator()(FStatMessage const& A, FStatMessage const& B) const
		{
			FName GroupA = A.NameAndInfo.GetGroupName();
			FName GroupB = B.NameAndInfo.GetGroupName();
			// first sort by group
			if (GroupA == GroupB)
			{
				// cycle stats come first
				if (A.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle) && !B.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle))
				{
					return true;
				}
				if (!A.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle) && B.NameAndInfo.GetFlag(EStatMetaFlags::IsCycle))
				{
					return false;
				}
				// then memory
				if (A.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory) && !B.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory))
				{
					return true;
				}
				if (!A.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory) && B.NameAndInfo.GetFlag(EStatMetaFlags::IsMemory))
				{
					return false;
				}
				// otherwise, reverse order of definition
				return A.NameAndInfo.GetRawName().GetComparisonIndex() > B.NameAndInfo.GetRawName().GetComparisonIndex();
			}
			if (GroupA == NAME_None)
			{
				return false;
			}
			if (GroupB == NAME_None)
			{
				return true;
			}
			return GroupA.GetComparisonIndex() > GroupB.GetComparisonIndex();
		}
	};

	/**
	* Whether the testing framework should allow content to be tested or not.  Intended to block developer directories.
	* @param Path - Full path to the content in question
	* @return - Whether this content should have tests performed on it
	* Refined here using namespace to avoid modifying original engine code
	*/
	static bool ShouldTestContent(const FString& Path) 
	{
		static TArray<FString> TestLevelFolders;
		if (TestLevelFolders.Num() == 0)
		{
			GConfig->GetArray(TEXT("/Script/Engine.AutomationTestSettings"), TEXT("TestLevelFolders"), TestLevelFolders, GEngineIni);
		}

		bool bMatchingDirectory = false;
		for (const FString& Folder : TestLevelFolders)
		{
			const FString PatternToCheck = FString::Printf(TEXT("/%s/"), *Folder);
			if (Path.Contains(*PatternToCheck))
			{
				bMatchingDirectory = true;
			}
		}
		return bMatchingDirectory;
	}

	/**
	* Runs over all the assets looking for ones that can be used by this test
	*
	* @param Class					The UClass of assets to load for the test
	* @param OutBeautifiedNames		[Filled by method] The beautified filenames of the assets to use in the test
	* @param OutTestCommands		[Filled by method] The asset name in a form suitable for passing as a param to the test
	* @param bIgnoreLoaded			If true, ignore any already loaded assets
	* Redefine here using namespace since this is private of engine plug-in
	*/
	static void CollectTestsByClass(UClass * Class, TArray< FString >& OutBeautifiedNames, TArray< FString >& OutTestCommands, bool bIgnoreLoaded)
	{
		FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
		TArray<FAssetData> ObjectList;
		AssetRegistryModule.Get().GetAssetsByClass(Class->GetFName(), ObjectList, true);

		for (auto ObjIter = ObjectList.CreateConstIterator(); ObjIter; ++ObjIter)
		{
			const FAssetData& Asset = *ObjIter;
			FString Filename = Asset.ObjectPath.ToString();
			//convert to full paths
			Filename = FPackageName::LongPackageNameToFilename(Filename);
			if (Q6Automation::ShouldTestContent(Filename))
			{
				// optionally discount already loaded assets
				if (!bIgnoreLoaded || !Asset.IsAssetLoaded())
				{
					FString BeautifiedFilename = Asset.AssetName.ToString();
					OutBeautifiedNames.Add(BeautifiedFilename);
					OutTestCommands.Add(Asset.ObjectPath.ToString());
				}
			}
		}
	}

	/**
	* Simulates the user pressing the blueprint's compile button (will load the
	* blueprint first if it isn't already).
	*
	* @param  BlueprintAssetPath	The asset object path that you wish to compile.
	* @return False if we failed to load the blueprint, true otherwise
	* Redefine here using namespace since this is private of engine plug-in
	*/
	static bool CompileBlueprint(const FString& BlueprintAssetPath)
	{
		UBlueprint* BlueprintObj = Cast<UBlueprint>(StaticLoadObject(UBlueprint::StaticClass(), NULL, *BlueprintAssetPath));
		if (!BlueprintObj || !BlueprintObj->ParentClass)
		{
			Q6JsonLog(Error, "CompileBlueprint: Failed to compile invalid blueprint, or blueprint parent no longer exists.");
			return false;
		}

		UPackage* const BlueprintPackage = BlueprintObj->GetOutermost();
		// compiling the blueprint will inherently dirty the package, but if there 
		// weren't any changes to save before, there shouldn't be after
		bool const bStartedWithUnsavedChanges = (BlueprintPackage != nullptr) ? BlueprintPackage->IsDirty() : true;

		FKismetEditorUtilities::CompileBlueprint(BlueprintObj, EBlueprintCompileOptions::SkipGarbageCollection);

		if (BlueprintPackage != nullptr)
		{
			BlueprintPackage->SetDirtyFlag(bStartedWithUnsavedChanges);
		}

		return true;
	}

	static bool SaveTestSequence(const FString& SequenceAssetPath)
	{
		UMovieSceneSequence* SeqObj = Cast<UMovieSceneSequence>(StaticLoadObject(UMovieSceneSequence::StaticClass(), NULL, *SequenceAssetPath));
		if (!SeqObj)
		{
			return false;
		}

		UPackage* const BlueprintPackage = SeqObj->GetOutermost();

		UPackage::Save(BlueprintPackage, SeqObj, EObjectFlags::RF_NoFlags, *SequenceAssetPath);

		return true;
	}

	static bool CheckNormalSkillSequenceTrackName(const FString& SequenceAssetPath)
	{
		ULevelSequence* SeqObj = Cast<ULevelSequence>(StaticLoadObject(ULevelSequence::StaticClass(), NULL, *SequenceAssetPath));
		if (!SeqObj)
		{
			return true;
		}

		UMovieScene* MovieScene = SeqObj->GetMovieScene();
		if (!MovieScene)
		{
			return true;
		}

		static const FString TrackName(TEXT("Ally1"));
		bool bFoundTrack = false;
		for (int32 i = 0; i < MovieScene->GetPossessableCount(); ++i)
		{
			FMovieScenePossessable& Possessable = MovieScene->GetPossessable(i);
			if (Possessable.GetName() == TrackName)
			{
				if (bFoundTrack)
				{
					Q6JsonLog(Error, "Sequence has more than one Ally1 track");
					return false;
				}
				bFoundTrack = true;
			}
		}

		return true;
	}

	static void GetAllStats_StatsThread(TArray<FStatMessage>* OutStats)
	{
		FStatsThreadState& StatsData = FStatsThreadState::GetLocalState();
		TArray<FStatMessage>& Stats = *OutStats;
		for (auto It = StatsData.ShortNameToLongName.CreateConstIterator(); It; ++It)
		{
			Stats.Add(It.Value());
		}
		Stats.Sort(Q6Automation::FGroupSort());
	}

	static void GetAllStats(TArray<FStatMessage>& OutStats, ENamedThreads::Type ThreadType)
	{
		FStatsThreadState& Stats = FStatsThreadState::GetLocalState();
		int64 Latest = Stats.GetLatestValidFrame();
		check(Latest > 0);
		TArray<FStatMessage> const& Data = Stats.GetCondensedHistory(Latest);

		OutStats.Append(Data);
	}

	static void DumpStats(int64 Frame)
	{
		ensure(!bDumpStateFinished);

		SaveJsonData.Empty();

		TArray<FName> StatNames;
		StatNames.Add(TEXT("DrawPrimitive calls"));
		StatNames.Add(TEXT("Triangles drawn"));
		StatNames.Add(TEXT("Mesh draw calls"));
		StatNames.Add(TEXT("Static list draw calls"));
		StatNames.Add(TEXT("Translucency mesh drawing"));
		StatNames.Add(TEXT("Proj Shadow drawing"));

		TArray<FName> StatDisplayNames;
		StatDisplayNames.Add(TEXT("DP"));
		StatDisplayNames.Add(TEXT("Tri."));
		StatDisplayNames.Add(TEXT("Mesh DP"));
		StatDisplayNames.Add(TEXT("Static Mesh DP"));
		StatDisplayNames.Add(TEXT("Blending Mesh DP"));
		StatDisplayNames.Add(TEXT("Shadow"));

		ensure(StatDisplayNames.Num() == StatNames.Num());

		const FString FileName = FPaths::IsRelative(SaveStatFilePath) ? FPaths::RootDir() + SaveStatFilePath : SaveStatFilePath;

		FOutputDeviceFile LogFile(*FileName, true);

		TArray<FStatMessage> Stats;
		GetAllStats(Stats, ENamedThreads::GameThread);

		TArray<FName> StatGroups;
		StatGroups.Add(TEXT("STATGROUP_RHI"));
		StatGroups.Add(TEXT("STATGROUP_SceneRendering"));

		for (const FName& StatGroup : StatGroups)
		{
			LogFile.Log(TEXT("----------------------------------------------"));
			LogFile.Log(*StatGroup.ToString());
			LogFile.Log(TEXT("----------------------------------------------"));

			for (int32 Index = 0; Index < Stats.Num(); Index++)
			{
				FStatMessage const& Meta = Stats[Index];
				FName CurrentGroupName = Meta.NameAndInfo.GetGroupName();
				if (CurrentGroupName == StatGroup)
				{
					LogFile.Logf(TEXT("%s"), *FStatsUtils::DebugPrint(Meta));
				}

				for (int i = 0; i < StatNames.Num(); ++i)
				{
					const FName& JsonName = StatNames[i];
					if (Meta.NameAndInfo.GetDescription() == JsonName.ToString())
					{
						FString ValueString = FString::Printf(TEXT("%lld"), Meta.GetValue_int64());

						if (Meta.NameAndInfo.GetFlag(EStatMetaFlags::IsPackedCCAndDuration))
						{
							ValueString = FString::Printf(TEXT("%lld"), FromPackedCallCountDuration_CallCount(Meta.GetValue_int64()));
						}

						SaveJsonData.Add({ StatDisplayNames[i], ValueString });
					}
				}
			}
			LogFile.Log(TEXT(""));
		}

		LogFile.Flush();
		LogFile.TearDown();

		FString JsonString;
		TSharedRef<TJsonWriter<TCHAR>> JsonWriter = TJsonWriterFactory<TCHAR>::Create(&JsonString);
		JsonWriter->WriteObjectStart();
		for (const auto& JsonData : SaveJsonData)
		{
			JsonWriter->WriteValue(JsonData.Name.ToString(), JsonData.Value);
		}

		JsonWriter->WriteObjectEnd();
		JsonWriter->Close();

		FFileHelper::SaveStringToFile(JsonString, *(FileName + TEXT(".json")));

		FStatsThreadState::GetLocalState().NewFrameDelegate.Remove(SaveStatsDelegateHandle);
		SaveStatsDelegateHandle = FDelegateHandle();

		bDumpStateFinished = true;
	}
}

#endif

/////////////////////////////////////////////////////////////////////////////////////
// Test Declaration

IMPLEMENT_COMPLEX_AUTOMATION_TEST(FCombatScenePerformanceTest, "Q6.CombatScenePerformance", EAutomationTestFlags::ClientContext | EAutomationTestFlags::ProductFilter)
IMPLEMENT_COMPLEX_AUTOMATION_TEST(FQ6SaveMaps, "Q6.SaveMaps", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
IMPLEMENT_COMPLEX_AUTOMATION_TEST(FQ6CompileBlueprintsTest, "Q6.CompileBlueprints", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
IMPLEMENT_COMPLEX_AUTOMATION_TEST(FQ6CompileAnimBlueprintsTest, "Q6.CompileAnimBlueprints", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
IMPLEMENT_COMPLEX_AUTOMATION_TEST(FQ6CompileMovieSceneSequenceTest, "Q6.CompileMovieSceneSequence", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)
IMPLEMENT_COMPLEX_AUTOMATION_TEST(FQ6CheckNormalSkillSequenceTrackNameTest, "Q6.CheckNormalSkillSequenceTrackName", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter)

/////////////////////////////////////////////////////////////////////////////////////
// FSaveRenderStatCommand

DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FSaveRenderStatCommand, FString, SaveFilePath);

bool FSaveRenderStatCommand::Update()
{
	static bool bRequested = false;

	if (bRequested)
	{
		if (bDumpStateFinished)
		{
			bDumpStateFinished = false;
			bRequested = false;

			return true;
		}
		else
		{
			return false;
		}
	}

	UWorld* World = Q6Automation::GetWorld();
	if (!World)
	{
		return true;
	}

	if (SaveStatsDelegateHandle != FDelegateHandle())
	{
		// Previous save command is not processed yet. wait..
		return false;
	}

	IncrementalPurgeGarbage(false);

#if STATS
	SaveStatFilePath = SaveFilePath;

	// Wait for frame end
	SaveStatsDelegateHandle = FStatsThreadState::GetLocalState().NewFrameDelegate.AddStatic(&Q6Automation::DumpStats);
#endif

	bRequested = true;

	return false;
}

/////////////////////////////////////////////////////////////////////////////////////
// FPlayStageCommand

DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FPlayStageCommand, FString, MapName);

bool FPlayStageCommand::Update()
{
	// TODO: APIs for auto play are required
	// TODO: Call FSaveRenderStatCommand 
	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// FCombatScenePerformanceTest

void FCombatScenePerformanceTest::GetTests(TArray<FString>& OutBeautifiedNames, TArray <FString>& OutTestCommands) const
{
	TArray<FString> FileList;
	FEditorFileUtils::FindAllPackageFiles(FileList);

	// Iterate over all files, adding the ones with the map extension..
	for (int32 FileIndex = 0; FileIndex < FileList.Num(); FileIndex++)
	{
		const FString& Filename = FileList[FileIndex];

		// Disregard filenames that don't have the map extension if we're in MAPSONLY mode.
		if (FPaths::GetExtension(Filename, true) == FPackageName::GetMapPackageExtension())
		{
			if (Q6Automation::ShouldTestContent(Filename))
			{
				OutBeautifiedNames.Add(FPaths::GetBaseFilename(Filename));
				OutTestCommands.Add(Filename);
			}
		}
	}
}

bool FCombatScenePerformanceTest::RunTest(const FString& Parameters)
{
	FString MapName = Parameters;
	double MapLoadStartTime = 0;

	ADD_LATENT_AUTOMATION_COMMAND(FEditorLoadMap(MapName));
	ADD_LATENT_AUTOMATION_COMMAND(FWaitLatentCommand(2.0f));

	// Enable Stat collection
	StatsMasterEnableAdd();

	ADD_LATENT_AUTOMATION_COMMAND(FPlayStageCommand(MapName));

	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// FQ6SaveMaps

/**
* Requests a enumeration of all maps to be loaded
*/
void FQ6SaveMaps::GetTests(TArray<FString>& OutBeautifiedNames, TArray <FString>& OutTestCommands) const
{
	TArray<FString> FileList;
	FEditorFileUtils::FindAllPackageFiles(FileList);

	// Iterate over all files, adding the ones with the map extension..
	for (int32 FileIndex = 0; FileIndex < FileList.Num(); FileIndex++)
	{
		const FString& Filename = FileList[FileIndex];

		// Disregard filenames that don't have the map extension if we're in MAPSONLY mode.
		if (FPaths::GetExtension(Filename, true) == FPackageName::GetMapPackageExtension())
		{
			if (Q6Automation::ShouldTestContent(Filename))
			{
				if (!Filename.Contains(TEXT("/Engine/")) && !Filename.Contains(TEXT("/Dev/")))
				{
					OutBeautifiedNames.Add(FPaths::GetBaseFilename(Filename));
					OutTestCommands.Add(Filename);
				}
			}
		}
	}
}


/**
* Execute the load and save of each map
*
* @param Parameters - Should specify which map name to load
* @return	TRUE if the test was successful, FALSE otherwise
*/
bool FQ6SaveMaps::RunTest(const FString& Parameters)
{
	FString MapName = Parameters;

	UWorld* World = Q6Automation::GetWorld();
	if (!World)
	{
		return true;
	}

	ADD_LATENT_AUTOMATION_COMMAND(FEditorLoadMap(MapName));
	ADD_LATENT_AUTOMATION_COMMAND(FSaveLevelCommand(MapName));

	return true;
}

/////////////////////////////////////////////////////////////////////////////////////
// FQ6CompileBlueprintsTest

/** Requests a enumeration of all blueprints to be loaded */
void FQ6CompileBlueprintsTest::GetTests(TArray<FString>& OutBeautifiedNames, TArray <FString>& OutTestCommands) const
{
	Q6Automation::CollectTestsByClass(UBlueprint::StaticClass(), OutBeautifiedNames, OutTestCommands, /*bool bIgnoreLoaded =*/false);
}


bool FQ6CompileBlueprintsTest::RunTest(const FString& Parameters)
{
	Q6JsonLog(Verbose, "FQ6CompileBlueprintsTest", Q6KV("Beginning compile test for: ", *Parameters));
	return Q6Automation::CompileBlueprint(Parameters);
}

/////////////////////////////////////////////////////////////////////////////////////
// FQ6CompileAnimBlueprintsTest

/** Requests a enumeration of all blueprints to be loaded */
void FQ6CompileAnimBlueprintsTest::GetTests(TArray<FString>& OutBeautifiedNames, TArray <FString>& OutTestCommands) const
{
	Q6Automation::CollectTestsByClass(UAnimBlueprint::StaticClass(), OutBeautifiedNames, OutTestCommands, /*bool bIgnoreLoaded =*/false);
}

bool FQ6CompileAnimBlueprintsTest::RunTest(const FString& Parameters)
{
	return Q6Automation::CompileBlueprint(Parameters);
}

/////////////////////////////////////////////////////////////////////////////////////
// FQ6CompileMovieSceneSequenceTest

/** Requests a enumeration of all movie scene sequences to be loaded */
void FQ6CompileMovieSceneSequenceTest::GetTests(TArray<FString>& OutBeautifiedNames, TArray <FString>& OutTestCommands) const
{
	Q6Automation::CollectTestsByClass(UMovieSceneSequence::StaticClass(), OutBeautifiedNames, OutTestCommands, /*bool bIgnoreLoaded =*/false);
}

bool FQ6CompileMovieSceneSequenceTest::RunTest(const FString& Parameters)
{
	return Q6Automation::SaveTestSequence(Parameters);
}

/////////////////////////////////////////////////////////////////////////////////////
// FQ6CheckNormalSkillSequenceTrackNameTest

/** Requests a enumeration of all normal skill sequences to be loaded */
void FQ6CheckNormalSkillSequenceTrackNameTest::GetTests(TArray<FString>& OutBeautifiedNames, TArray <FString>& OutTestCommands) const
{
	FAssetRegistryModule& AssetRegistryModule = FModuleManager::LoadModuleChecked<FAssetRegistryModule>(TEXT("AssetRegistry"));
	TArray<FAssetData> ObjectList;
	AssetRegistryModule.Get().GetAssetsByClass(ULevelSequence::StaticClass()->GetFName(), ObjectList, true);

	for (auto ObjIter = ObjectList.CreateConstIterator(); ObjIter; ++ObjIter)
	{
		const FAssetData& Asset = *ObjIter;
		FString Filename = Asset.ObjectPath.ToString();
		Filename = FPackageName::LongPackageNameToFilename(Filename);
		if (Q6Automation::ShouldTestContent(Filename))
		{
			FString BeautifiedFilename = Asset.AssetName.ToString();
			if (BeautifiedFilename.Contains(TEXT("NS_")))
			{
				OutBeautifiedNames.Add(BeautifiedFilename);
				OutTestCommands.Add(Asset.ObjectPath.ToString());
			}
		}
	}
}

bool FQ6CheckNormalSkillSequenceTrackNameTest::RunTest(const FString& Parameters)
{
	return Q6Automation::CheckNormalSkillSequenceTrackName(Parameters);
}

#endif // WITH_EDITOR && !UE_BUILD_SHIPPING
