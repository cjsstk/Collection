#pragma once

#include "Q6Minimal.h"

#if !UE_BUILD_SHIPPING

#include "Misc/AutomationTest.h"

class AQ6CombatGameMode;
class UCMS;

namespace Q6Automation
{

UWorld* GetWorld();
AQ6CombatGameMode* GetCombatCubeGameMode();

bool CaptureScreenShot(const FString& FilePath, bool bFullScreen);
uint32 UploadFile(const FString& LocalFilePath, const FString& RemoteFolder, const FString& RemoteFileName);
int32 GetUploadFileCount();
bool IsUploadFileFinished(uint32 Id);
void HttpRequest(const FString& URL, const FString& JsonContentString);
void FindAllPackageFiles(TArray<FString>& OutPackages);
void FindAllMapPackages(TArray<FString>& OutPackageNames);

} // Q6Automation copied from Q3Automation (looks useful, but we dont need php things) 

DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FCaptureScreenCommnad, FString, FilePath);

struct FUploadFileCommandParam
{
	FString LocalFilePath;
	FString RemoteFolder;
	FString RemoteFileName;
	bool bBlocking;

	uint32 RequestedId;

	FUploadFileCommandParam(FString InLocalFilePath, FString InRemoteFolder, FString InRemoteFileName, bool InbBlocking) :
		LocalFilePath(InLocalFilePath), RemoteFolder(InRemoteFolder), RemoteFileName(InRemoteFileName), bBlocking(InbBlocking)
	{
		RequestedId = 0;
	}
};

struct FHttpRequestCommandParam
{
	FString URL;
	FString JsonString;
};

struct FChangeRenderFlagCommandParams
{
	bool bParticles;
	bool bSkeletalMeshes;
	bool bStaticMeshes;
	bool bUI;
	bool bDynamicShadow;
};

struct FLoadMapCommandParams
{
	FName LevelName;
	FString Options;
};

struct FCMSParam
{
	UCMS* CMS;
};

DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FUploadFileCommand, FUploadFileCommandParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND(FFlushUploadFileCommand);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FHttpRequestCommand, FHttpRequestCommandParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND(FFlushHttpRequestCommand);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FLoadMapCommand, FLoadMapCommandParams, Param);
DEFINE_LATENT_AUTOMATION_COMMAND(FSetGameDevFlagNoDamage);
DEFINE_LATENT_AUTOMATION_COMMAND(FSetGameDevCheatAlliesUASA);
DEFINE_LATENT_AUTOMATION_COMMAND(FSkipTurnSkillCommand);
DEFINE_LATENT_AUTOMATION_COMMAND(FUseSkillCommand);
DEFINE_LATENT_AUTOMATION_COMMAND(FUseTurnSkillCommand);
DEFINE_LATENT_AUTOMATION_COMMAND(FReplaceUnitsCommand);
DEFINE_LATENT_AUTOMATION_COMMAND(FWaitForCombatStateCommand);
DEFINE_LATENT_AUTOMATION_COMMAND(FWaitForActCombatFinishedCommand);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FChangeRenderFlagCommand, FChangeRenderFlagCommandParams, Params);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FExecConsoleCommand, FString, CommandString);

// CMS validation
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateSkill, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateFormulaConst, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FCharacterToUnitType, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateBuffEffect, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateSkillEffect, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateVersa, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateUnit, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateWave, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateABC, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateApplyTag, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidatePet, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateMonster, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateAttributeDifficulty, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateSaga, FCMSParam, Param);
DEFINE_LATENT_AUTOMATION_COMMAND_ONE_PARAMETER(FValidateDifficultyNatureBonus, FCMSParam, Param);

#endif // UE_BUILD_SHIPPING