// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "CCTypes.h"
#include "CCEvent.h"
#include "CombatCube.h"
#include "Q6Define.h"
#include "Q6GameState.h"
#include "AutomationHelper.generated.h"

class ACombatPresenter;

USTRUCT()
struct FCacheUsedSkill
{
	GENERATED_BODY()

	UPROPERTY()
	FCCUnitId UnitId;

	UPROPERTY()
	int32 UnitType;

	UPROPERTY()
	bool bNormalSkillUsed;

	UPROPERTY()
	bool bUltimateSkillUsed;

	UPROPERTY()
	bool bTurnSkillUsed;
};

// Automation related Test functions
// CAUTION: automations use this functions. don't use other places
UCLASS()
class Q6_API UAutomationHelper : public UObject
{
	GENERATED_BODY()

public:

	UAutomationHelper(const FObjectInitializer& ObjectInitializer);

	int32 GetUnspawnedUnitCount() const { return UnspawnedUnitTypes.Num(); }
	int32 PopUnspawnedUnitType();
	void UseSkillBySkillCategory(FCCUnitId InUnitId, ESkillCategory InSkillCategory);
	void GatherAllUnitTypes(const TArray<FCCCombatSeedUnit>& InCombatSeedUnits);
	void UseSkill();
	void UseTurnSkill();
	void ReplaceUnits();
	void OnSpawnUnit(const FCCUnitState& InUnitState);
	void Start() { bStarted = true; }
	bool IsStarted() const { return bStarted; }

private:
	// Dont use at game logic, Only in Automation.
	UPROPERTY(Transient)
	TMap<int32, FCacheUsedSkill> CacheUsedSkillMap;

	UPROPERTY(Transient)
	TArray<int32> UnspawnedUnitTypes;

	UPROPERTY()
	bool bStarted;
};