// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Engine/GameInstance.h"

#if !UE_BUILD_SHIPPING
#include "Cheater.h"
#endif
#include "CMS/CMSTable.h"
#include "HUDStore.h"
#include "Network/Q6ClientNetwork.h"
#include "Network/Q6ServerNetwork.h"
#include "Q6Account.h"
#include "Q6Define.h"
#include "Q6GameState.h"
#include "Q6LobbyState.h"
#include "ShaderPipelineCache.h"
#include "Tutorial/LobbyTutorial.h"
#include "Widget/PopupWidgets.h"

#include "Q6GameInstance.generated.h"

class UCCEndGameEvent;
class FQ6NetworkTick;
class SLoadingScreenWidget;
class ULoadingScreenWidget;
class UQ6SoundPlayer;
class UCharacterVoiceHelper;
class UQ6SaveGame;

struct FCCCombatSeed;
struct FDialogueRecord;
struct FJokerInfo;
struct FResError;
struct FRewardRecord;
struct FQ6TimerManager;
class FQ6TimerTick;

DECLARE_DELEGATE_OneParam(FQ6NetworkReadyDelegate, UQ6GameInstance*);
DECLARE_MULTICAST_DELEGATE(FOnQ6TimerTick);

enum class EGameContent : uint8
{
	None,
	// currency
	Currency,
	// character
	Character,
	// equip
	BagItem,
	Relic,
	Sculpture,
	// others(sorted)
	ActRecord,
	CodexChar,
	CodexSculpture,
	CodexRelic,
	WeeklyMission,
	CharMission,
	EventMission,
	Bond,
	Friend,
	FriendCooltime,
	JokerSet,
	Party,
	Saga,
	Special,
	TrainingCenter,
	Daily,
	Pyramid,
	Temple,
	PowerPlant,
	Pet,
	Vacation,
	Smelter,
	Alchemylab,
	Raid,
	Mail,
	Attendance,
	Shop,
	LobbyTemplate,
	LobbySet,
	Title,
	ContentFeatureOpen,
	Summon,
	Event,
	Avatar,
	Max,
};

// complete chronicle's judgement.
DECLARE_DELEGATE_TwoParams(FQ6CompleteJudgementDelegate, int32, EQ6Judgement);

/**
 * Q6 Game Instance
 */
UCLASS()
class Q6_API UQ6GameInstance : public UGameInstance
{
	GENERATED_BODY()

public:
	UQ6GameInstance(const FObjectInitializer& ObjectInitializer);

	virtual void Init() override;
	virtual void Shutdown() override;
	virtual void StartGameInstance() override;

#if WITH_EDITOR
	virtual FGameInstancePIEResult StartPlayInEditorGameInstance(ULocalPlayer* LocalPlayer, const FGameInstancePIEParameters& Params);
#endif

	/**
	* Level loading screen
	*/
	void BeginLoadingScreen(const FString& Map);
	void EndLoadingScreen(UWorld* LoadedWorld);
	/**
	 * Process activation
	 */
	void OnDeactivate();
	void OnReactivate();
	void OnEnterBackground();
	void OnEnterForeground();

	void InitializeSoundPlayer();

	static UQ6GameInstance* Get(UObject* Object = nullptr) { return Singleton; }

	void SetRaidId(const FRaidId& InRaidId);

	UFUNCTION(BlueprintCallable)
	void InitCombatSeed(const FCCCombatSeed& InCombatSeed) { CombatSeed = InCombatSeed; }
	void SetSaga(const FSagaType& SagaType);
	void SetCombatSeedPartyId(int32 PartyId);
	void SetCombatSeedBanIndices(const TArray<int32>& BanIndices);
	void SetCombatSeedUnits(const TArray<FCCCombatSeedUnit>& Units, const TArray<FCCCombatSeedUnit>& SubUnits);
	void SetSystemJoker(const FCharacterType& SystemJoker);
	void SetFriendJoker(const FFriendInfo& FriendInfo, EJokerSlotType JokerSlot);
	void SetRandomJoker(const FCharacterType& RandomJoker);
	void SetOwnedJoker(const FPartySlot& JokerSlot);

	void ClearJoker();
	void ResetHUDStore();

	UFUNCTION(BlueprintCallable)
	const FCCCombatSeed& GetCombatSeed() const { return CombatSeed; }
	void SetRestorableOnServer(const bool flag) { bRestorableOnServer = flag; }
	const bool IsRestorableOnServer() const { return bRestorableOnServer;  }
	const bool IsRestorableOnClient();

	const FJokerInfo& GetJokerInfo() const { return JokerInfo; }

	UQ6SoundPlayer& GetSoundPlayer() const { check(SoundPlayer); return *SoundPlayer; }
	bool IsSoundPlayerInitialized() const { return (SoundPlayer != nullptr); }

	UCharacterVoiceHelper* GetCharacterVoiceHelper() const { return CharacterVoiceHelper; }

	UHUDStore& GetHUDStore() const { check(HUDStore); return *HUDStore; }
	bool IsHUDStoreInitialized() const { return HUDStore && HUDStore->IsInitialized(); }

	FQ6NetworkReadyDelegate& OnNetworkReady() { return NetworkReadyDelegate; }
	FQ6ClientNetwork& GetClientNetwork() { ensure(ClientNetwork); return *ClientNetwork; }
	FQ6ServerNetwork& GetServerNetwork() { ensure(ServerNetwork); return *ServerNetwork; }
	bool HasClientNetwork() const { return (ClientNetwork != nullptr); }
	bool HasServerNetwork() const { return (ServerNetwork != nullptr); }
	FQ6CompleteJudgementDelegate& GetJudgementDelegate() { return JudgementDelegate; }

	void LoadSaveGame(const FString& UserId);
	UQ6SaveGame* GetSaveGame() const { return SaveGameInstance; }

	void SetLogin(bool bInLogin);

	void HandleEnteredLobby(const FL2CAuthEnterLobbyResp& Resp);
	void HandleEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp);

	void ContentsReady();
	void ReqNextContent();
	void ReqContent(EGameContent NextContent);

	// combat
	void OnSagaStageBegin(const FL2CSagaStageBeginResp& Resp);
	void OnSagaStageEnd(const FL2CSagaStageEndResp& Resp);
	void OnSpecialStageBegin(const FL2CSpecialStageBeginResp& Resp);
	void OnSpecialStageEnd(const FL2CSpecialStageEndResp& Resp);
	void OnDailyStageBegin(const FL2CDailyStageBeginResp& Resp);
	void OnDailyStageEnd(const FL2CDailyStageEndResp& Resp);
	void OnTrainingCenterStageBegin(const FL2CTrainingCenterStageBeginResp& Resp);
	void OnTrainingCenterStageEnd(const FL2CTrainingCenterStageEndResp& Resp);
	void OnBeginRaid(const FL2CRaidEnterNof& Nof);
	void OnRaidFinalStageBegin(const FL2CRaidFinalStageBeginResp& Resp);
	void OnRaidFinalStageEnd(const FL2CRaidFinalStageEndResp& Resp);
	void OnEventContentCollabo01StageBegin(const FL2CEventContentCollabo01StageBeginResp& Resp);
	void OnEventContentCollabo01StageEnd(const FL2CEventContentCollabo01StageEndResp& Resp);
	void OnEventContentValentineDayStageBegin(const FL2CEventContentValentineDayStageBeginResp& Resp);
	void OnEventContentValentineDayStageEnd(const FL2CEventContentValentineDayStageEndResp& Resp);
	void OnEventContentMultiSideBattleStageBegin(const FL2CEventContentMultiSideBattleStageBeginResp& Resp);
	void OnEventContentMultiSideBattleStageEnd(const FL2CEventContentMultiSideBattleStageEndResp& Resp);

	bool IsActivated() const { return bActivated; }
	bool IsLogin() const { return bLogin; }
	bool IsEnteredLobby() const { return bEnteredLobby; }
	bool IsForeground() const { return bForeground; }

	bool IsFirstShowLobby() const { return bFirstShowLobby; }
	void SetFirstShowLobby(bool bInFirstShow) { bFirstShowLobby = bInFirstShow; }

	bool HasQ6TimerManager() const { return (Q6TimerManager != nullptr); }

	FQ6TimerManager& GetQ6TimerManager() const;

	void RequestBeginStage();
	void RequestEndStage(const UCCEndGameEvent* Event, const FCombatMissionInfo& CombatMissionInfo);
	void RequestQuitStage();
	void RequestSagaStoryStage(FSagaType SagaType);

	// Chronicle
	EQ6Judgement JudgeChronicle(int32 InRequestId, const FString& QueryString, const FString& ChronicleJSonStr);
	void CompleteJudgeChronicle(int32 InRequestId, EQ6Judgement InJudgement);
	bool LoadOngoingChronicleFile(FSagaType* OutSagaType);
	void SaveOngoingChronicleFile(FString InJSonString);
	FString GetOngoingChronicle() const { return OngoingChronicle; }
	void RemoveOngoingChronicleFile();
	EZoneAttribute GetZoneAttribute() const {return ZoneAttribute;};
	void SetZoneAttribute(EZoneAttribute InAttribute) { ZoneAttribute = InAttribute; };

	// Tutorial
	void SetReserveTutorialOnInit(ELobbyTutorial InTutorial, int32 InStep);
	void CancelReserveTutorialOnInit();
	ELobbyTutorial GetReservedTutorialOnInit() const;
	int32 GetReservedTutorialStepOnInit() const;

	bool ShowUltimateSequence(int32 ModelType, bool bEnemy);
	void ClearShowUltimateSequenceDates();

	// Dialogue
	FDialogueType LoadPlayingDialogueType();
	void InitDialogueRecord(const FDialogueRecord& DialogueRecord, FDialogueType StartDialogueType);
	void UpdateDialogueRecord(FDialogueType DialogueType);
	void ClearDialogueRecord();
	const FDialogueRecord& GetDialogueRecord() const;
	bool IsDialogueExpired(const FDialogueRecord& DialogueRecord) const;

	// Reward
	void InitRewardRecord(const FRewardRecord& InRewardRecord, bool bSave = true);
	bool HasRewardStep() const;
	bool HeapPopRewardStep(FRewardStep& RewardStep);
	FSagaType GetRewardSagaType() const;
	const TArray<FRewardInfo>& GetRewardInfos() const;
	bool GetRewardInfo(int32 RewardIndex, FRewardInfo& Out) const;
	int32 GetReceiveAccumEventPoint() const;
	const TArray<FBondLevelUpReward>& GetBondRewards() const;

	// SystemJoker
	void UpdateBanIndices(const TArray<int32>& BanIndices);
	void ClearBanIndices();
	const TArray<int32>& GetBanIndices() const;

#if !UE_BUILD_SHIPPING
	void SetDevMode(bool bInDevMode);
	const bool IsDevMode() const;
	const bool IsTutorialSkipMode() const;
	const bool IsShowMultiSideBattleRankScore() const;
#endif

	// obiwan would be shipping
	void SetNoAuthCC() { noAuthCC = true; }
	bool GetNoAuthCC() { return noAuthCC; }
	void ReqNoAuthCC();
	//////

	const FString& GetOnGoingCCState() { return OnGoingCCStateStr;  }
	const void ClearOnGoingCCState() { OnGoingCCStateStr.Empty(); }

	const double GetLastWattUpdateTime() const { return LastWattUpdateTime; }
	void SetLastWattUpdateTime(const double InLastWattUpdateTime) { LastWattUpdateTime = InLastWattUpdateTime; }

private:
	static UQ6GameInstance* Singleton;

	void InitNetwork();
	void InitHUDStore();

	void InitializeUserSettings();
	void InitializeQ6TimerManager();
	void StartSagaLevel(const FCombatSeed& Seed);
	FString GetOngoingChronicleFilePath();
	const FString GetDialoguePlayingFilePath();
	FSagaType FinalizeEnterLobby();

	void ReqEnterLobbyFinal();

	FString LoadDialoguePlayingFile();
	void SaveDialgouePlayingFile(FDialogueType DialogueType);
	void RemoveDialoguePlayingFile();

	bool IsDialogueDailyExpired() const;
	bool IsDialogueTrainingExpired(int32 ExpireTime) const;
	bool IsDialogueRaidExpired(FSagaType SagaType) const;
	bool IsDialogueEventExpired(FEventContentType EventContentType) const;

	void OnShaderPipelineCachePrecompilationComplete(uint32 Count, double Seconds, const FShaderPipelineCache::FShaderCachePrecompileContext& ShaderCachePrecompileContext);

	UPROPERTY(Transient)
	FString OngoingChronicle;

	bool bRestorableOnServer;
	FCCCombatSeed CombatSeed;
	FJokerInfo JokerInfo;

	UPROPERTY(Transient)
	UHUDStore* HUDStore;

	UPROPERTY(Transient)
	UQ6SoundPlayer* SoundPlayer;

	UPROPERTY(Transient)
	UCharacterVoiceHelper* CharacterVoiceHelper;

	UPROPERTY(Transient)
	UQ6SaveGame* SaveGameInstance;

	UPROPERTY(Transient)
	ELobbyTutorial ReservedTutorialOnInit;

	UPROPERTY(Transient)
	int32 ReservedTutorialStepOnInit;

	bool bActivated;
	bool bLogin;
	bool bEnteredLobby;
	bool bForeground;
	bool bPSOCacheLoading;
	bool noAuthCC;
	FString OnGoingCCStateStr;

	EGameContent CurrentContent;

	FQ6NetworkReadyDelegate NetworkReadyDelegate;
	FQ6ClientNetwork* ClientNetwork;
	FQ6ServerNetwork* ServerNetwork;
	FQ6NetworkTick* NetworkTick;
	FQ6TimerManager* Q6TimerManager;
	FQ6TimerTick* Q6TimerTick;

	FQ6CompleteJudgementDelegate JudgementDelegate;

#if !UE_BUILD_SHIPPING
	FCheater Cheater;
#endif

	UPROPERTY()
	ULoadingScreenWidget* LoadingScreenUMGWidget;

	UMaterialInterface* LoadingThrobberMaterial;
	UTexture2D* LoadingBackgroundTexture;
	UTexture2D* LoadingShadowTexture;
	bool bFirstLoading;

	bool bFirstShowLobby;
	FTimerHandle ContentsTimerHandle;
	EZoneAttribute ZoneAttribute;

	double LastWattUpdateTime;
};
