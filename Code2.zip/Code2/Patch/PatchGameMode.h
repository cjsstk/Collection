// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "GameMode/Q6GameMode.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IHttpResponse.h"
#include "PatchGameMode.generated.h"

/**
 * Patch Menu of Q36
 */
UCLASS()
class Q6_API APatchGameMode : public AGameModeBase
{
	GENERATED_BODY()

public:
	virtual void StartPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
};
