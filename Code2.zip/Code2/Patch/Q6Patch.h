// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"

#include "BuildPatchState.h"
#include "Interfaces/IHttpRequest.h"
#include "Interfaces/IBuildManifest.h"
#include "Interfaces/IBuildInstaller.h"
#include "ShaderPipelineCache.h"

enum class EPatchSystemState
{
	Idle,
	DownloadDLCURL,
	DownloadingManifest,
	ManifestDownloaded,
	Downloading,
	LoadPSOCache,
	Completed
};

enum class EPatchSystemError
{
	None,
	FailedToInit,
	FailedToDownloadDLCURL,
	FailedToDownloadManifest,
	ErrorToDownloadManifest,
	FailedToLoadManifest,
};

class FQ6Patch : public FTickableGameObject
{
public:

	FQ6Patch();

	// Begin FTickableGameObject
	virtual bool IsTickableWhenPaused() const override
	{
		return true;
	}
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override
	{
		return true;
	}
	virtual TStatId GetStatId() const;
	// End FTickableGameObject

	void InitPatchSystem();

	void Download();

	float GetProgress() const;
	FText GetProgressText() const;
	int64 GetTotalSizeToDownload() const;
	int64 GetTotalSizeDownloaded() const;
	double GetDownloadSpeed() const;
	bool IsFinished() const;
	void LoadShaderCodeLibraryFromPluginAfterMountPak();

	EPatchSystemError GetError() const { return LastError; }
	EPatchSystemState GetPatchState() const { return State; }
	BuildPatchServices::EBuildPatchState GetBuildInstallerPatchState() const { return BuildInstallerPatchState; }

private:
	void DownloadDLCURL();
	void OnRequestDownloadDLCCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded);
	void DownloadManifest();
	void OnRequestManifestCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded);
	void PrepareDownload();
	//void OnDownloadContentCompleted(bool bSuccess, IBuildManifestRef DownloadedManifest);
	void OnDownloadContentCompleted(const IBuildInstallerRef& Installer);
	void MountAllDownloadedPaks();
	void OnPakMounted(const TCHAR* InPakName);
	void OnPrecompilationBegin(uint32 Count, const FShaderPipelineCache::FShaderCachePrecompileContext& ShaderCachePrecompileContext);
	void OnPreCompilationCompleted(uint32 Count, double Seconds, const FShaderPipelineCache::FShaderCachePrecompileContext& ShaderCachePrecompileContext);

	void ByPassOnNoPatchServer();
	void RequestLoadPSOCache();

	/**
	 * Manifest URL
	 * Loaded from Game.ini
	 */
	FString DLCURL;
	FString ManifestURL;

	FString CloudURL;

	FString InstallDir;
	FString StageDir;

	/**
	 * Build patch service
	 * To create manifest instance from downloaded file
	 */
	class IBuildPatchServicesModule* BPSModule;

	IBuildInstallerPtr BuildInstaller;

	IBuildManifestPtr DownloadedManifest;
	IBuildManifestPtr OldManifest;

	EPatchSystemState State;
	EPatchSystemError LastError;

	BuildPatchServices::EBuildPatchState BuildInstallerPatchState;

	uint32 TotalPreCompileTasks;
};