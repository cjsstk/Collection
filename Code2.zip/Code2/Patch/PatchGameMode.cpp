// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "PatchGameMode.h"

#include "HttpModule.h"
#include "GenericPlatform/GenericPlatformChunkInstall.h"
#include "Q6.h"
#include "Q6Patch.h"
#include "VersionNumber.h"


void APatchGameMode::StartPlay()
{
	Super::StartPlay();

	GetGameModule()->GetPatch().InitPatchSystem();
}

void APatchGameMode::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}