// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "Q6Patch.h"

#include "Http.h"
#include "Interfaces/IHttpBase.h"
#include "Interfaces/IBuildPatchServicesModule.h"
#include "Interfaces/IHttpResponse.h"
#include "Interfaces/IPluginManager.h"
#include "IPlatformFilePak.h"
#include "JsonObjectConverter.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "ShaderCodeLibrary.h"
#include "RHI.h"
#include "RHIDefinitions.h"

static IBuildPatchServicesModule* GetBuildPatchServices()
{
	static IBuildPatchServicesModule* BuildPatchServices = nullptr;
	if (BuildPatchServices == nullptr)
	{
		BuildPatchServices = &FModuleManager::LoadModuleChecked<IBuildPatchServicesModule>(TEXT("BuildPatchServices"));
	}
	return BuildPatchServices;
}

FQ6Patch::FQ6Patch()
{
	DLCURL.Empty();
	ManifestURL.Empty();
	CloudURL.Empty();
	InstallDir.Empty();
	StageDir.Empty();

	BPSModule = GetBuildPatchServices();

	BuildInstaller.Reset();
	DownloadedManifest.Reset();
	OldManifest.Reset();
	State = EPatchSystemState::Idle;
	LastError = EPatchSystemError::None;
	BuildInstallerPatchState = BuildPatchServices::EBuildPatchState::NUM_PROGRESS_STATES;

	TotalPreCompileTasks = 0;
}

void FQ6Patch::InitPatchSystem()
{
	bool bSucceed = GConfig->GetString(TEXT("Q6Patch"), TEXT("DLCURL"), DLCURL, GGameIni);
	if (!bSucceed)
	{
		Q6JsonLogBro(Error, "Failed to init Q6 Patch system. cannot get Patch Location Server URL");
		LastError = EPatchSystemError::FailedToInit;
		return;
	}

	bSucceed = GConfig->GetString(TEXT("Q6Patch"), TEXT("CloudURL"), CloudURL, GGameIni);
	if (!bSucceed)
	{
		Q6JsonLogBro(Error, "Failed to init Q6 Patch system. no cloud url found");
		LastError = EPatchSystemError::FailedToInit;
		return;
	}

	DLCURL = TEXT("http://") + DLCURL;
	CloudURL = TEXT("http://") + CloudURL;
	FString RootDir = TEXT("");
#if PLATFORM_IOS
	RootDir = FString([NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0]) + TEXT("/");
#else
	RootDir = FPaths::ProjectPersistentDownloadDir();
#endif
	StageDir = FPaths::Combine(RootDir, TEXT("Patch"), TEXT("Staged"));
	InstallDir = FPaths::Combine(RootDir);

	Q6JsonLogBro(Verbose, "Q6Patch system initiated",
		Q6KV("DLC URL", DLCURL),
		Q6KV("Cloud URL", CloudURL));


	FCoreDelegates::PakFileMountedCallback.AddRaw(this, &FQ6Patch::OnPakMounted);
	FShaderPipelineCache::GetPrecompilationBeginDelegate().AddRaw(this, &FQ6Patch::OnPrecompilationBegin);
	FShaderPipelineCache::GetPrecompilationCompleteDelegate().AddRaw(this, &FQ6Patch::OnPreCompilationCompleted);

	DownloadDLCURL();
}

void FQ6Patch::Download()
{
	ensure(State == EPatchSystemState::Downloading);

	if (BuildInstaller->IsPaused())
	{
		BuildInstaller->TogglePauseInstall();
	}
}

float FQ6Patch::GetProgress() const
{
	if (!BuildInstaller.IsValid())
	{
		return 0;
	}

	if (State == EPatchSystemState::LoadPSOCache)
	{
		float CacheProgress = 0.0f;

		if (TotalPreCompileTasks > 0)
		{
			uint32 RemainTasks = FMath::Min(FShaderPipelineCache::NumPrecompilesRemaining(), TotalPreCompileTasks);
			uint32 CompletedTasks = TotalPreCompileTasks - RemainTasks;

			CacheProgress = (float)CompletedTasks / (float)TotalPreCompileTasks;
		}

		return CacheProgress;
	}

	return BuildInstaller->GetUpdateProgress();
}

FText FQ6Patch::GetProgressText() const
{
	return FText::GetEmpty();
}

int64 FQ6Patch::GetTotalSizeToDownload() const
{
	if (!BuildInstaller.IsValid())
	{
		return 0;
	}

	return BuildInstaller->GetTotalDownloadRequired();
}

int64 FQ6Patch::GetTotalSizeDownloaded() const
{
	if (!BuildInstaller.IsValid())
	{
		return 0;
	}

	return BuildInstaller->GetTotalDownloaded();
}

double FQ6Patch::GetDownloadSpeed() const
{
	if (!BuildInstaller.IsValid())
	{
		return 0;
	}

	return BuildInstaller->GetDownloadSpeed();
}

bool FQ6Patch::IsFinished() const
{
	return (State == EPatchSystemState::Completed);
}

void FQ6Patch::DownloadDLCURL()
{
	State = EPatchSystemState::DownloadDLCURL;

	TSharedRef<IHttpRequest> SendJsonRequest = (&FHttpModule::Get())->CreateRequest();
	SendJsonRequest->OnProcessRequestComplete().BindRaw(this, &FQ6Patch::OnRequestDownloadDLCCompleted);
	SendJsonRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	SendJsonRequest->SetURL(DLCURL);
	SendJsonRequest->SetVerb("GET");
	SendJsonRequest->ProcessRequest();
}

void FQ6Patch::OnRequestDownloadDLCCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
{
	if (!bSucceeded || !HttpResponse.IsValid())
	{
		LastError = EPatchSystemError::FailedToDownloadDLCURL;
		Q6JsonLogBro(Error, "Failed to download DLC URL", Q6KV("URL", HttpRequest->GetURL()));
		return;
	}

	if (!EHttpResponseCodes::IsOk(HttpResponse->GetResponseCode()))
	{
		LastError = EPatchSystemError::FailedToDownloadDLCURL;
		Q6JsonLogBro(Error, "Error response to download DLC URL",
			Q6KV("URL", HttpRequest->GetURL()),
			Q6KV("ResponseCode", HttpResponse->GetResponseCode()),
			Q6KV("Response", HttpResponse->GetContentAsString()));
		return;
	}

	FString ResponseStr = HttpResponse->GetContentAsString();
	TSharedPtr<FJsonObject> JSONDLCObject;
	TSharedRef<TJsonReader<TCHAR>>Reader = TJsonReaderFactory<TCHAR>::Create(ResponseStr);
	if (!FJsonSerializer::Deserialize(Reader, JSONDLCObject))
	{
		LastError = EPatchSystemError::FailedToDownloadDLCURL;

		Q6JsonLogBro(Error, "Error to deserialize download DLC URL JSon",
			Q6KV("URL", HttpRequest->GetURL()),
			Q6KV("ResponseCode", HttpResponse->GetResponseCode()),
			Q6KV("Response", HttpResponse->GetContentAsString()));
		return;
	}

	if (!JSONDLCObject.IsValid())
	{
		LastError = EPatchSystemError::FailedToDownloadDLCURL;

		Q6JsonLogBro(Error, "deserialized DLC URL is invalid Json",
			Q6KV("URL", HttpRequest->GetURL()),
			Q6KV("ResponseCode", HttpResponse->GetResponseCode()),
			Q6KV("Response", HttpResponse->GetContentAsString()));
		return;
	}

	// Get the values map
	TMap<FString, TSharedPtr<FJsonValue>>& JsonValueMap = JSONDLCObject->Values;
	TSharedPtr< FJsonValue > JsonAppNameString = JsonValueMap.FindRef(TEXT("manifest"));
	if (!JsonAppNameString.IsValid()) {
		LastError = EPatchSystemError::FailedToDownloadDLCURL;

		Q6JsonLogBro(Error, "cannot get manifest json value",
			Q6KV("URL", HttpRequest->GetURL()),
			Q6KV("ResponseCode", HttpResponse->GetResponseCode()),
			Q6KV("Response", HttpResponse->GetContentAsString()));
		return;
	}

	ManifestURL = JsonAppNameString->AsString();

	Q6JsonLogBro(Verbose, "Q6Patch. DLC URL downloaded.");
	DownloadManifest();
}

void FQ6Patch::DownloadManifest()
{
	ensure(State == EPatchSystemState::DownloadDLCURL);

	State = EPatchSystemState::DownloadingManifest;

	TSharedRef<IHttpRequest> SendJsonRequest = (&FHttpModule::Get())->CreateRequest();
	SendJsonRequest->OnProcessRequestComplete().BindRaw(this, &FQ6Patch::OnRequestManifestCompleted);
	SendJsonRequest->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
	SendJsonRequest->SetURL(ManifestURL);
	SendJsonRequest->SetVerb("GET");
	SendJsonRequest->ProcessRequest();
}

void FQ6Patch::ByPassOnNoPatchServer()
{
#if !UE_BUILD_SHIPPING
	LastError = EPatchSystemError::None;
	State = EPatchSystemState::Completed;
	MountAllDownloadedPaks();
#endif
}

void FQ6Patch::OnRequestManifestCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
{
	if (!bSucceeded || !HttpResponse.IsValid())
	{
		LastError = EPatchSystemError::FailedToDownloadManifest;

		Q6JsonLogBro(Error, "Failed to download patch manifest", Q6KV("URL", HttpRequest->GetURL()));

		return;
	}

	if (!EHttpResponseCodes::IsOk(HttpResponse->GetResponseCode()))
	{
		LastError = EPatchSystemError::ErrorToDownloadManifest;

		Q6JsonLogBro(Error, "Error response to download patch manifest",
			Q6KV("URL", HttpRequest->GetURL()),
			Q6KV("ResponseCode", HttpResponse->GetResponseCode()),
			Q6KV("Response", HttpResponse->GetContentAsString()));

		return;
	}

	DownloadedManifest = BPSModule->MakeManifestFromData(HttpResponse->GetContent());
	if (!DownloadedManifest.IsValid())
	{
		LastError = EPatchSystemError::FailedToLoadManifest;

		Q6JsonLogBro(Error, "Failed to load manifest", Q6KV("URL", HttpRequest->GetURL()));

		return;
	}

	Q6JsonLogBro(Verbose, "Q6Patch. manifest downloaded");

	State = EPatchSystemState::ManifestDownloaded;

	FString DonwloadedManifestFileName = FPaths::Combine(InstallDir, TEXT("Patches"), TEXT("DownloadedManifest.manifest"));
	OldManifest = BPSModule->LoadManifestFromFile(DonwloadedManifestFileName);
	if (OldManifest.IsValid())
	{
		Q6JsonLogBro(Verbose, "Old Manifest Version", Q6KV("Version", *(OldManifest->GetVersionString())));
	}
	else
	{
		Q6JsonLogBro(Verbose, "Old Manifest not exists. New installation");
	}

	if (DownloadedManifest.IsValid())
	{
		Q6JsonLogBro(Verbose, "Downloaded Manifest Version", Q6KV("Version", *(DownloadedManifest->GetVersionString())));
	}
	else
	{
		Q6JsonLogBro(Error, "Failed to load downloaded manifest", Q6KV("URL", HttpRequest->GetURL()));
		return;
	}

	PrepareDownload();
}

void FQ6Patch::PrepareDownload()
{
	ensure(State == EPatchSystemState::ManifestDownloaded);

	Q6JsonLogBro(Display, "Q6Patch PrepareDownload", Q6KV("StageDir", StageDir), Q6KV("InstallDir", InstallDir));

	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();

	if (!PlatformFile.DirectoryExists(*StageDir))
	{
		PlatformFile.CreateDirectoryTree(*StageDir);
	}

	if (!PlatformFile.DirectoryExists(*InstallDir))
	{
		PlatformFile.CreateDirectoryTree(*InstallDir);
	}

	TArray<BuildPatchServices::FInstallerAction> InstallerActions;
	InstallerActions.Add(BuildPatchServices::FInstallerAction::MakeInstallOrUpdate(OldManifest, DownloadedManifest.ToSharedRef(), TSet<FString>()));

	BuildPatchServices::FBuildInstallerConfiguration Configuration(MoveTemp(InstallerActions));
	Configuration.StagingDirectory = StageDir;
	Configuration.CloudDirectories = { CloudURL };
	Configuration.InstallDirectory = InstallDir;

	BuildInstaller = BPSModule->CreateBuildInstaller(Configuration, FBuildPatchInstallerDelegate::CreateRaw(this, &FQ6Patch::OnDownloadContentCompleted));
	BuildInstaller->StartInstallation();

	State = EPatchSystemState::Downloading;
}

void FQ6Patch::OnDownloadContentCompleted(const IBuildInstallerRef& Installer)
{
	if (!Installer->CompletedSuccessfully())
	{
		EBuildPatchInstallError ErrorCode = EBuildPatchInstallError::NumInstallErrors;
		FText ErrorText = FText::GetEmpty();

		if (BuildInstaller.IsValid())
		{
			ErrorText = BuildInstaller->GetErrorText();
			ErrorCode = BuildInstaller->GetErrorType();
		}

		Q6JsonLogBro(Error, "Installation Failed.", Q6KV("ErrorCode", (int32)ErrorCode), Q6KV("ErrorText", *ErrorText.ToString()));
		return;
	}


	// TODO: I think engine can handle multiple manifests. But, we still using single manifest method.
	// Neeed to improve (reference MobilePatchingLibrary.cpp)
	IBuildPatchServicesModule* BuildPatchServices = GetBuildPatchServices();
	FString ManifestFullFilename = FPaths::Combine(InstallDir, TEXT("Patches"), TEXT("DownloadedManifest.manifest"));

	if (!BuildPatchServices->SaveManifestToFile(ManifestFullFilename, DownloadedManifest.ToSharedRef()))
	{
		Q6JsonLogBro(Error, "Failed to save manifest to disk", Q6KV("Path", *ManifestFullFilename));
	}

	Q6JsonLogBro(Verbose, "Q6Patch. download completed");

	MountAllDownloadedPaks();

	RequestLoadPSOCache();
}

void FQ6Patch::RequestLoadPSOCache()
{
#if PLATFORM_ANDROID && USE_ANDROID_FILE
	State = EPatchSystemState::LoadPSOCache;

	if (IsVulkanMobilePlatform(GMaxRHIShaderPlatform))
	{
		State = EPatchSystemState::Completed;
		return;
	}

	FShaderPipelineCache::SetBatchMode(FShaderPipelineCache::BatchMode::Background);
	FShaderPipelineCache::ResumeBatching();
	FShaderPipelineCache::ClosePipelineFileCache();

	const FString DownloadContentPakName("DownloadContent");
	if (!FShaderPipelineCache::OpenPipelineFileCache(DownloadContentPakName, GMaxRHIShaderPlatform))
	{
		State = EPatchSystemState::Completed;
		return;
	}
#else
	State = EPatchSystemState::Completed;
#endif
}

void FQ6Patch::MountAllDownloadedPaks()
{
	class FPakSearchVisitor : public IPlatformFile::FDirectoryVisitor
	{
	public:
		FPakSearchVisitor(TArray<FString>& InFoundPakFiles) : FoundPakFiles(InFoundPakFiles) {}
		virtual bool Visit(const TCHAR* FilenameOrDirectory, bool bIsDirectory)
		{
			if (bIsDirectory == false)
			{
				FString Filename(FilenameOrDirectory);
				if (FPaths::GetExtension(Filename) == TEXT("pak"))
				{
					FoundPakFiles.Add(Filename);
					// Add Filename to Manifest
					IFileManager::Get().SetTimeStamp(*Filename, FDateTime::UtcNow());
				}
			}
			return true;
		}
	private:
		TArray<FString>& FoundPakFiles;
	};
	TArray<FString> FoundPaks;
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	FPakSearchVisitor PakSearchVisitor(FoundPaks);
	PlatformFile.IterateDirectoryRecursively(*InstallDir, PakSearchVisitor);

	Q6JsonLogBro(Warning, "Found Pak count", Q6KV("Count", FoundPaks.Num()));
	for (const auto& PakPath : FoundPaks)
	{
		Q6JsonLogBro(Warning, "Found Pak Path", Q6KV("Path", *PakPath));
		FPakPlatformFile* PakPlatformFile = static_cast<FPakPlatformFile*>(FPlatformFileManager::Get().FindPlatformFile(TEXT("PakFile")));
		if (!PakPlatformFile->Mount(*PakPath, 1))
		{
			Q6JsonLogBro(Error, "Pak Mount Failed", Q6KV("Path", *PakPath));
		}
	}
}

void FQ6Patch::OnPakMounted(const TCHAR* InPakName)
{
	FString NewPakName(InPakName);
	Q6JsonLogBro(Display, "New Pak Mounted", Q6KV("PakName", *NewPakName));
	LoadShaderCodeLibraryFromPluginAfterMountPak();
}

void FQ6Patch::OnPrecompilationBegin(uint32 Count, const FShaderPipelineCache::FShaderCachePrecompileContext& ShaderCachePrecompileContext)
{
	Q6JsonLogBro(Verbose, "Q6Patch. PSO Cache loading Begin", Q6KV("Count", (int32)Count));

	TotalPreCompileTasks = Count;
}

void FQ6Patch::OnPreCompilationCompleted(uint32 Count, double Seconds, const FShaderPipelineCache::FShaderCachePrecompileContext& ShaderCachePrecompileContext)
{
	Q6JsonLogBro(Verbose, "Q6Patch. PSO Cache loading completed", Q6KV("Count", (int32)Count));

	State = EPatchSystemState::Completed;
}

// for debugging on the device wether file exists or not.
//static void BrowseDirectory(const TCHAR* InDirectory)
//{
//	Q6JsonLogBro(Verbose, "LogMetal: Search Directory =======", Q6KV("Directory", InDirectory));
//	TArray<FString> Files3;
//	IFileManager::Get().FindFilesRecursive(Files3, InDirectory, TEXT("*"), true, true);
//	for (const FString& FileEachName : Files3)
//	{
//		Q6JsonLogBro(Verbose, "LogMetal: File:", Q6KV("FileName", FileEachName));
//	}
//}

void FQ6Patch::LoadShaderCodeLibraryFromPluginAfterMountPak()
{
	TArray<TSharedRef<IPlugin>> InPlugins = IPluginManager::Get().GetEnabledPluginsWithContent();
	for (const TSharedRef<IPlugin>& PluginRef : InPlugins)
	{
		const IPlugin& InPlugin = PluginRef.Get();
		if (InPlugin.CanContainContent() && InPlugin.IsEnabled())
		{
			Q6JsonLogBro(Verbose, "LogMetal: Plugin Shader Code Load", Q6KV("Name", InPlugin.GetName()), Q6KV("BaseDir", InPlugin.GetBaseDir()), Q6KV("ContentDir", InPlugin.GetContentDir()));
			FShaderCodeLibrary::OpenLibrary(InPlugin.GetName(), InPlugin.GetBaseDir());
			FShaderCodeLibrary::OpenLibrary(InPlugin.GetName(), InPlugin.GetContentDir());
		}
	}
}

void FQ6Patch::Tick(float DeltaTime)
{
	if (LastError != EPatchSystemError::None || State == EPatchSystemState::Completed)
	{
		return;
	}

	switch (State)
	{
	case EPatchSystemState::Idle:
	case EPatchSystemState::DownloadDLCURL:
	case EPatchSystemState::DownloadingManifest:
	case EPatchSystemState::ManifestDownloaded:
	case EPatchSystemState::Downloading:
	case EPatchSystemState::LoadPSOCache:
		break;

	default:
		ensure(0);
	}

	if (BuildInstaller.IsValid())
	{
		BuildInstallerPatchState = BuildInstaller.Get()->GetState();
	}
}

TStatId FQ6Patch::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(FQ6Patch, STATGROUP_Tickables);
}
