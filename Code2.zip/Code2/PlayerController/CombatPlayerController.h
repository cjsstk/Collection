// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Q6Define.h"
#include "BasePlayerController.h"
#include "CombatPlayerController.generated.h"

class ACombatLevelSequenceActor;
class ACombatLocator;
class APetUnit;
class AResultLocator;
class AUnit;

class UCameraAnim;
class UCameraAnimInst;
class UCombatCameraComponent;
class UCombatLevelSeqeucnePlayer;
class UCPNormalSkillInstance;
class UCPPetSkillInstance;
class UCPUltimateSkillInstance;
class UMovieSceneSequencePlayer;

struct FUnitState;

enum class ECCFaction : uint8;
enum class ECombatCamera : uint8;

UENUM()
enum class ECombatCameraBlendType : uint8
{
	NoBlend,
	NormalBlend,
	LongBlend,
};

UENUM()
enum class ESequencePlayPositon : uint8
{
	Target,
	Owner,
};

/**
 * Combat Player Controller
 */
UCLASS()
class Q6_API ACombatPlayerController : public ABasePlayerController
{
	GENERATED_BODY()

public:
	ACombatPlayerController(const FObjectInitializer& ObjectInitializer);

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual bool InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad) override;
	virtual bool InputTouch(uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation, float Force, FDateTime DeviceTimestamp, uint32 TouchpadIndex) override;

	ECombatCamera GetCombatCameraType() const { return CombatCameraType; }
	bool IsCombatCameraBlending() const { return CombatCameraWaitingTime > 0; }
	void SetCombatCameraWaitingTime(float InTime) { CombatCameraWaitingTime = InTime; }
	void BindCombatCamera(ACombatLocator* InCombatLocator, int32 InWave);
	bool ChangeToWaveCamera(ECombatCameraBlendType InBlendType = ECombatCameraBlendType::NoBlend, bool bInPlayCameraAnim = false);
	bool ChangeToPrepareCamera(bool bInPlayCameraAnim = true);
	bool ChangeToAllyCamera(int32 Slot, bool bInPlayCameraAnim = true);
	bool ChangeToEnemyCamera(int32 Slot, int32 InWaveEnemyNumSlots, bool bInWaveEnemyDeafultPosition, ECombatCameraBlendType InBlendType = ECombatCameraBlendType::NoBlend, bool bInPlayCameraAnim = true);
	bool ChangeToFactionAllCamera(ECCFaction Faction, ECombatCameraBlendType InBlendType = ECombatCameraBlendType::NoBlend, bool bInPlayCameraAnim = true);

	void SaveCurrentCamera();
	void RestoreSavedCamera(ECombatCameraBlendType InBlendType);

	void SetSequenceCameraFollow(bool bInFollow) { bSequenceCameraFollowing = bInFollow; }
	bool IsPlayingSequence() const;
	void JumpToEndFrame();
	bool HasWaveSequence(int32 Episode, int32 Stage, int32 Wave, bool IsIntro);
	float GetWaveSequenceLength();

	void PlayWaveSequence(int32 Episode, int32 Stage, int32 Wave, bool IsIntro);
	void PlayResultSequence(AUnit* ResultUnit);
	void PlayBoneDragonOutroSequence();
	void PlayPetSkillSequence(UCPPetSkillInstance* SkillInstance, APetUnit* OwnerPetUnit, int32 SkillIndex);
	void PlayUltimateSkillSequence(UCPUltimateSkillInstance* SkillInstance, TSoftObjectPtr<ULevelSequence> SkillSequence, AUnit* OwnerUnit, TArray<AActor*>& SkillAllyActors, TArray<AActor*>& SkillEnemyActors, const TArray<AActor*>& SkillExcludedUnitActors);
	void PlayNormalSkillSequence(UCPNormalSkillInstance* SkillInstance, AUnit* OwnerUnit, TArray<AActor*>& SkillAllyActors, TArray<AActor*>& SkillEnemyActors, const TArray<AActor*>& SkillExcludedUnitActors, const FTransform& InSequenceTransform);

	void StopResultSequence();

	// Sequencer event driven skill widget animation
	virtual bool PlaySkillAnimation() override;

	// Sequencer event driven actor visibility control
	UFUNCTION(BlueprintCallable)
	void HideSequenceIncludedNonOwnerUnits();
	UFUNCTION(BlueprintCallable)
	void ShowSequenceIncludedNonOwnerUnits();
	UFUNCTION(BlueprintCallable)
	void HideSequenceExcludedActors();
	UFUNCTION(BlueprintCallable)
	void ShowSequenceExcludedActors();

	// Sequencer event driven actor visual control
	UFUNCTION(BlueprintCallable)
	void SetEnemyActorsAnimPaused(bool bInPause);
	UFUNCTION(BlueprintCallable)
	void SetEnemyActorsSubMaterialEffect(const FSubMaterialEffectParams& InParams);
	UFUNCTION(BlueprintCallable)
	void ClearEnemyActorsSubMaterialEffect();

	FBoolParamDelegate CameraWaitingFinishedDelegate;
	FSimpleDelegate SequenceFinishedDelegate;
	FSimpleDelegate SequencePausedDelegate;

private:
	/**
	* Set target actor
	* @param Actor					actor that has camera component
	* @param CameraComponent		if null, Actor should have only 1 camera component in it
	* @param BlendTime				give blend time in transition
	*/
	void SetCombatViewTarget(AActor* Actor, UCombatCameraComponent* CameraComponent, float BlendTime = 1.0f);

	void SetResultViewTarget(AActor* Actor, UCombatCameraComponent* CameraComponent);
	void BindResultCamera();

	void BindSequenceActors(const TArray<AActor*>& InActors, bool bIsAlly);
	void BindSequenceActorsWithExclusionOnFail(TArray<AActor*>& InOutIncludedActors, TArray<AActor*>& InOutExcludedActors, bool bIsAlly);
	void BindSequenceActorsWithTag(TArray<AActor*>& InOutActors, const FName& Tag);

	void PlayCameraAnimation();

	void AttachBindedActorsToSequenceActor();
	void RestoreSequenceHiddenActors();

	ULevelSequence* GetWaveLevelSequence(int32 Episode, int32 Stage, int32 Wave, bool IsIntro);

	UFUNCTION()
	void OnSequenceStopped();

	UFUNCTION()
	void OnNormalSequenceStopped();

	UFUNCTION()
	void OnUltimateSkillSequenceStopped();

	UFUNCTION()
	void OnPetSkillSequenceStopped();

	UFUNCTION()
	void OnResultSequenceFinished();

	/**
	* Combat Camera stuff
	*/
	UPROPERTY(Transient)
	ACombatLocator* CombatLocator;

	UPROPERTY(Transient)
	AResultLocator* ResultLocator;

	UPROPERTY(Transient)
	AActor* InstanceCameraOwnerActor;

	UPROPERTY(Transient)
	UCombatCameraComponent* InstanceCombatCameraComponent;

	UPROPERTY(Transient)
	UCombatCameraComponent* SavedInstanceCombatCameraComponent;

	UPROPERTY(Transient)
	AUnit* SequenceOwnerUnit;

	UPROPERTY(Transient)
	TArray<AActor*> SequenceBindedActors;

	UPROPERTY(Transient)
	TArray<AActor*> SequenceEnemyUnitActors;

	UPROPERTY(Transient)
	TArray<AActor*> SequenceIncludedNonOwnerUnitActors;

	UPROPERTY(Transient)
	TArray<AActor*> SequenceExcludedUnitActors;

	UPROPERTY(Transient)
	TArray<AActor*> SequenceHiddenActors;

	UPROPERTY(Transient)
	TArray<ACameraActor*> CachedCameras;

	ECombatCamera CombatCameraType;
	ECombatCamera SavedCombatCameraType;
	float CombatCameraWaitingTime;
	bool bCombatCameraRestoring;

	bool bCombatCameraBound;
	int32 CombatCameraWave;

	bool bPlayCameraAnim;
	bool bSavedPlayCameraAnim;
	bool bWasPlayingCameraAnim;

	bool bSequenceCameraFollowing;

	bool bCachedCameraIndex;
	AActor* GetCachedCameraActor(UCombatCameraComponent* CameraComponent);
};
