// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "UMG.h"
#include "LevelSequencePlayer.h"
#include "GameFramework/PlayerController.h"
#include "BasePlayerController.generated.h"

class UMovieScene;
class ULevelSequence;

UCLASS(BlueprintType, Blueprintable)
class Q6_API UTouchEffectWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Touch Effect")
	void OnTouchEffect();

	void OnTouchEvent(const FPointerEvent& MouseEvent);
};

/**
* APlayerControllerTouchEffect
*/
UCLASS()
class Q6_API APlayerControllerTouchEffect : public APlayerController
{
	GENERATED_BODY()

public:
	APlayerControllerTouchEffect(const FObjectInitializer& ObjectInitializer);

public:
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

public:
	void OnTouchEvent(const FPointerEvent& MouseEvent);

	UPROPERTY(EditDefaultsOnly, Category = "Q6 Touch Effect")
	TSoftClassPtr<UTouchEffectWidget> TouchEffectWidgetClass;

	UPROPERTY()
	TArray<UTouchEffectWidget*> TouchEffectWidgets;

	int WidgetIndex;

private:
	TSharedPtr<class FQ6TouchEffectInputProcessor> InputProcessor;
};

/**
* Base Player Controller
*/
UCLASS()
class Q6_API ABasePlayerController : public APlayerControllerTouchEffect
{
	GENERATED_BODY()

public:
	ABasePlayerController(const FObjectInitializer& ObjectInitializer);

	UFUNCTION()
	void StopSequencePlayer() const;
	UFUNCTION()
	void PauseSequencePlayer() const;
	UFUNCTION()
	void ResumeSequencePlayer() const;

	// Sequencer event driven skill widget animation
	UFUNCTION(BlueprintCallable)
	virtual bool PlaySkillAnimation() { return false; };
	UFUNCTION(BlueprintCallable)
	virtual void PlaySkillAnimationWithPause();

protected:
	virtual void SetupInputComponent();

	bool GetSequenceBindingIDInternal(UMovieScene* InMovieScene, const FString& InObjectName, FMovieSceneSequenceID CurSequenceID, TArray<FMovieSceneSequenceID>& InOutSequenceIDs, TArray<FMovieSceneObjectBindingID>& InOutBindingIDs);
	TArray<FMovieSceneObjectBindingID> GetSequenceBindingIDs(ULevelSequence* InSequence, const FString& InObjectName);

	void DestroySequenceActor();

private:
	void OnBackAction();

protected:
	UPROPERTY(Transient)
	ULevelSequence* LevelSequence;

	UPROPERTY(Transient)
	ULevelSequencePlayer* LevelSequencePlayer;

	UPROPERTY(Transient)
	ALevelSequenceActor* LevelSequenceActor;
};
