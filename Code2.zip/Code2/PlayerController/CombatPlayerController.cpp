// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatPlayerController.h"

#include "CombatCameraComponent.h"
#include "CombatCube/CombatCube.h"
#include "CombatGameResource.h"
#include "CombatHUD.h"
#include "CombatLevelSequencePlayer.h"
#include "CombatLocator.h"
#include "Components/Q6DirectionalLightComponent.h"
#include "CPInstances.h"
#include "Engine.h"
#include "Engine/Q6DirectionalLight.h"
#include "LevelSequenceActor.h"
#include "LevelUtil.h"
#include "PetUnit.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6Define.h"
#include "Q6Log.h"
#include "Unit.h"
#include "UnitBase.h"
#define Q6_USE_OLD_CAMERA_LOGIC 0

DECLARE_CYCLE_STAT(TEXT("Combat Player Controller Tick"), STAT_CombatPlayerControllerTick, STATGROUP_Q6);

TAutoConsoleVariable<float> CVarWaveCameraBlendTime(
	TEXT("q6.WaveCameraBlendTime"),
	0.25f,
	TEXT(""),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarAllyCameraBlendTime(
	TEXT("q6.AllyCameraBlendTime"),
	0.5f,
	TEXT(""),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarAllyAllCameraBlendTime(
	TEXT("q6.AllyAllCameraBlendTime"),
	0.25f,
	TEXT(""),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarAllyAllCameraBlendTimeLong(
	TEXT("q6.AllyAllCameraBlendTimeLong"),
	1.0f,
	TEXT(""),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarEnemyCameraBlendTime(
	TEXT("q6.EnemyCameraBlendTime"),
	0.25f,
	TEXT(""),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarEnemyAllCameraBlendTime(
	TEXT("q6.EnemyAllCameraBlendTime"),
	0.25f,
	TEXT(""),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarCameraWaitingTimeRatio(
	TEXT("q6.CameraWaitingTimeRatio"),
	0.6f,
	TEXT("multiplied to camera blend time when using explicit waiting time"),
	ECVF_Cheat);

ACombatPlayerController::ACombatPlayerController(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CombatLocator(nullptr)
	, ResultLocator(nullptr)
	, InstanceCameraOwnerActor(nullptr)
	, InstanceCombatCameraComponent(nullptr)
	, SavedInstanceCombatCameraComponent(nullptr)
	, SequenceOwnerUnit(nullptr)
	, CombatCameraType(ECombatCamera::Wave)
	, SavedCombatCameraType(ECombatCamera::Wave)
	, CombatCameraWaitingTime(0.f)
	, bCombatCameraRestoring(false)
	, bCombatCameraBound(false)
	, CombatCameraWave(0)
	, bPlayCameraAnim(true)
	, bSavedPlayCameraAnim(false)
	, bWasPlayingCameraAnim(false)
	, bSequenceCameraFollowing(false)
	, bCachedCameraIndex(false)
{
	bAutoManageActiveCameraTarget = false;
	bShouldPerformFullTickWhenPaused = true;
	CachedCameras.Reset(2);
}

void ACombatPlayerController::BeginPlay()
{
	Super::BeginPlay();
}

void ACombatPlayerController::Tick(float DeltaSeconds)
{
	SCOPE_CYCLE_COUNTER(STAT_CombatPlayerControllerTick);

	Super::Tick(DeltaSeconds);

	if (CombatCameraWaitingTime > 0)
	{
		CombatCameraWaitingTime -= DeltaSeconds;
		if (CombatCameraWaitingTime <= 0)
		{
			// update to remained blendTime due to pending
			if (PlayerCameraManager->PendingViewTarget.Target && PlayerCameraManager->BlendTimeToGo > 0)
			{
				CombatCameraWaitingTime = PlayerCameraManager->BlendTimeToGo;
			}
			else
			{
				if (bPlayCameraAnim)
				{
					PlayCameraAnimation();
				}
				else
				{
					bWasPlayingCameraAnim = false;
					PlayerCameraManager->StopAllCameraAnims();
				}

				CameraWaitingFinishedDelegate.ExecuteIfBound(bCombatCameraRestoring);
				bCombatCameraRestoring = false;
			}
		}
	}

	if (bSequenceCameraFollowing)
	{
		if (SequenceOwnerUnit && LevelSequenceActor)
		{
			FVector Location = SequenceOwnerUnit->GetActorLocation();
			if (CombatLocator)
			{
				Location.Z = CombatLocator->GetBottomLocationZ();
			}
			LevelSequenceActor->SetActorLocation(Location);
		}
	}
}

bool ACombatPlayerController::InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad)
{
#if !UE_BUILD_SHIPPING
	TSharedPtr<SWidget> FocusedWidget = FSlateApplication::Get().GetKeyboardFocusedWidget();
	SWidget* Widget = FocusedWidget.Get();
	if (Widget && Widget->GetType().IsEqual(TEXT("SEditableText")))
	{
		return true;
	}

	const AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(this);
	ACombatCube* CombatCube = CombatGameMode ? CombatGameMode->CombatCube : nullptr;
	if (CombatCube && EventType == IE_Released)
	{
		// Cheat keys for developers

		if (Key == EKeys::K)
		{
			CombatCube->KillAllEnemies();
			return true;
		}
		else if (Key == EKeys::L)
		{
			CombatCube->WinGame();
			return true;
		}
		else if (Key == EKeys::Zero)
		{
			GetCheckedCombatHUD(this)->ToggleDebugWidget();
			return true;
		}
		else if (Key == EKeys::Two)
		{
			GetCheckedCombatHUD(this)->ToggleNoDamage();
			return true;
		}
		else if (Key == EKeys::Four)
		{
			GetCheckedCombatHUD(this)->ToggleImmune();
			return true;
		}
	}
#endif

	return Super::InputKey(Key, EventType, AmountDepressed, bGamepad);
}

bool ACombatPlayerController::InputTouch(uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation, float Force, FDateTime DeviceTimestamp, uint32 TouchpadIndex)
{
	Super::InputTouch(Handle, Type, TouchLocation, Force, DeviceTimestamp, TouchpadIndex);

	if (Type == ETouchType::Began && !GetCheckedCombatHUD(this)->IsShowProvokedEnemyBar())
	{
		FHitResult HitResult;
		GetHitResultUnderCursor(ECC_Pawn, true, HitResult);

		if (HitResult.bBlockingHit)
		{
			AUnit* Unit = Cast<AUnit>(HitResult.GetActor());
			if (Unit && Unit->GetOverrideFaction() != ECCFaction::Ally)
			{
				const AQ6CombatGameMode* CombatGameMode = Cast<AQ6CombatGameMode>(GetWorld()->GetAuthGameMode());
				if (CombatGameMode && CombatGameMode->CombatCube)
				{
					CombatGameMode->CombatCube->SelectTarget(Unit->GetUnitId());
				}
			}
		}
	}

	return true;
}

void ACombatPlayerController::SaveCurrentCamera()
{
	bSavedPlayCameraAnim = bPlayCameraAnim;
	SavedCombatCameraType = CombatCameraType;
	SavedInstanceCombatCameraComponent = InstanceCombatCameraComponent;
}

static float _GetCombatCameraBlendTime(ECombatCamera InCameraType, ECombatCameraBlendType InBlendType)
{
	if (InBlendType == ECombatCameraBlendType::NoBlend)
	{
		return 0.f;
	}

	if (InCameraType == ECombatCamera::AllyAll)
	{
		switch (InBlendType)
		{
			case ECombatCameraBlendType::NormalBlend:
				return CVarAllyAllCameraBlendTime.GetValueOnGameThread();
			case ECombatCameraBlendType::LongBlend:
				return CVarAllyAllCameraBlendTimeLong.GetValueOnGameThread();
			default:
				break;
		}
	}
	else
	{
		switch (InCameraType)
		{
			case ECombatCamera::Wave:
				return CVarWaveCameraBlendTime.GetValueOnGameThread();
			case ECombatCamera::Ally1:
			case ECombatCamera::Ally2:
			case ECombatCamera::Ally3:
				return CVarAllyCameraBlendTime.GetValueOnGameThread();
			case ECombatCamera::EnemyAll:
				return CVarEnemyAllCameraBlendTime.GetValueOnGameThread();
			case ECombatCamera::Enemy1:
			case ECombatCamera::Enemy2:
			case ECombatCamera::Enemy3:
			case ECombatCamera::Enemy4:
			case ECombatCamera::Enemy5:
				return CVarEnemyCameraBlendTime.GetValueOnGameThread();
			default:
				break;
		}
	}

	return 0.f;
}

void ACombatPlayerController::RestoreSavedCamera(ECombatCameraBlendType InBlendType)
{
	if (!bCombatCameraBound || !CombatLocator || !SavedInstanceCombatCameraComponent)
	{
		return;
	}

	bPlayCameraAnim = bSavedPlayCameraAnim;
	CombatCameraType = SavedCombatCameraType;
	float BlendTime = _GetCombatCameraBlendTime(SavedCombatCameraType, InBlendType);
	bCombatCameraRestoring = BlendTime > 0.f;
	SetCombatViewTarget(CombatLocator, SavedInstanceCombatCameraComponent, BlendTime);
}

AActor* ACombatPlayerController::GetCachedCameraActor(UCombatCameraComponent* CameraComponent)
{
	check(CameraComponent);
#if Q6_USE_OLD_CAMERA_LOGIC
	return CameraComponent->SpawnCloneCameraActor();
#else

	bCachedCameraIndex = !bCachedCameraIndex;
	
	if (!CachedCameras.Num() || CachedCameras[0] == nullptr || CachedCameras[1] == nullptr)
	{
		FActorSpawnParameters SpawnParam;
		SpawnParam.Name = MakeUniqueObjectName(CameraComponent->GetWorld(), ACameraActor::StaticClass(), *FString::Printf(TEXT("TempCamera_%s"), *CameraComponent->GetName()));
		SpawnParam.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

		CachedCameras.Add(CameraComponent->GetWorld()->SpawnActor<ACameraActor>(SpawnParam));
		SpawnParam.Name = MakeUniqueObjectName(CameraComponent->GetWorld(), ACameraActor::StaticClass(), *FString::Printf(TEXT("TempCamera_%s"), *CameraComponent->GetName()));
		CachedCameras.Add(CameraComponent->GetWorld()->SpawnActor<ACameraActor>(SpawnParam));
	}

	auto CurrentCamera = CachedCameras[bCachedCameraIndex];
	CurrentCamera->SetActorTransform(CameraComponent->GetComponentTransform());
	if (auto CameraActor = Cast<ACameraActor>(CurrentCamera))
	{
		auto CurrentCameraComponent = CameraActor->GetCameraComponent();
		check(CurrentCameraComponent);
		CameraComponent->CopyCameraParamsTo(CurrentCameraComponent);
		return CameraActor;
	}
	return nullptr;
#endif
}
void ACombatPlayerController::SetCombatViewTarget(AActor* Actor, UCombatCameraComponent* CameraComponent, float BlendTime /* = 1.0f */)
{
	PlayerCameraManager->StopAllCameraAnims(true);

	if (InstanceCombatCameraComponent)
	{
		InstanceCombatCameraComponent->HideCulledActorInGame(false);
	}

	InstanceCameraOwnerActor = nullptr;
	InstanceCombatCameraComponent = nullptr;

	AActor* NewViewTarget = nullptr;

	if (CameraComponent)
	{
		InstanceCameraOwnerActor = Actor;
		InstanceCombatCameraComponent = CameraComponent;
		NewViewTarget = GetCachedCameraActor(CameraComponent);
	}
	else if (Actor)
	{
		TInlineComponentArray<UCameraComponent*> CameraComponentList;
		Actor->GetComponents(CameraComponentList);

		if (CameraComponentList.Num() == 1)
		{
			UCombatCameraComponent* CombatCameraComponent = Cast<UCombatCameraComponent>(CameraComponentList[0]);
			if (CombatCameraComponent)
			{
				InstanceCameraOwnerActor = Actor;
				InstanceCombatCameraComponent = CombatCameraComponent;
			}

			NewViewTarget = Actor;
		}
		else
		{
			Q6JsonLogSunny(Warning, "SetCombatViewTarget failed. Camera Component is not unique.", Q6KV("Actor", *Actor->GetName()));
		}
	}
	else
	{
		Q6JsonLogSunny(Warning, "SetCombatViewTarget failed. No camera actor nor component.");
	}

	FViewTargetTransitionParams TransitionParams;
	TransitionParams.BlendTime = BlendTime;
	TransitionParams.bLockOutgoing = bWasPlayingCameraAnim;

	const UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource)
	{
		TransitionParams.BlendFunction = CombatGameResource->GetCameraBlendFunction();
		TransitionParams.CurveFloat = CombatGameResource->GetCameraBlendCurve();
	}

	SetViewTarget(NewViewTarget, TransitionParams);
	CombatCameraWaitingTime = BlendTime;

	if (BlendTime <= 0)
	{
		if (bPlayCameraAnim)
		{
			PlayCameraAnimation();
		}
		else
		{
			bWasPlayingCameraAnim = false;
			PlayerCameraManager->StopAllCameraAnims();
		}
	}
}

void ACombatPlayerController::BindCombatCamera(ACombatLocator* InCombatLocator, int32 InWave)
{
	CombatLocator = InCombatLocator;

	ChangeToWaveCamera();

	bCombatCameraBound = true;
	CombatCameraWave = InWave;
}

bool ACombatPlayerController::ChangeToWaveCamera(ECombatCameraBlendType InBlendType /* = ECombatCameraBlendType::NoBlend */, bool bInPlayCameraAnim /* = false */)
{
	bPlayCameraAnim = bInPlayCameraAnim;

	if (!CombatLocator)
	{
		return false;
	}

	CombatCameraType = ECombatCamera::Wave;
	UCombatCameraComponent* TargetCameraComponent = CombatLocator->GetCamera(CombatCameraType);
	if (InstanceCombatCameraComponent == TargetCameraComponent)
	{
		if (bPlayCameraAnim && !bWasPlayingCameraAnim)
		{
			PlayCameraAnimation();
		}
		return false;
	}

	float BlendTime = InBlendType == ECombatCameraBlendType::NoBlend ? 0.f : CVarWaveCameraBlendTime.GetValueOnGameThread();
	SetCombatViewTarget(CombatLocator, TargetCameraComponent, BlendTime);

	return BlendTime > 0.f;
}

bool ACombatPlayerController::ChangeToPrepareCamera(bool bInPlayCameraAnim /* = true */)
{
	bPlayCameraAnim = bInPlayCameraAnim;

	if (!bCombatCameraBound || !CombatLocator)
	{
		return false;
	}

	CombatCameraType = ECombatCamera::Prepare;
	UCombatCameraComponent* TargetCameraComponent = CombatLocator->GetCamera(CombatCameraType);
	if (InstanceCombatCameraComponent == TargetCameraComponent)
	{
		if (bPlayCameraAnim && !bWasPlayingCameraAnim)
		{
			PlayCameraAnimation();
		}
		return false;
	}

	float BlendTime = 0.f;
	SetCombatViewTarget(CombatLocator, TargetCameraComponent, BlendTime);

	return BlendTime > 0;
}

bool ACombatPlayerController::ChangeToAllyCamera(int32 Slot, bool bInPlayCameraAnim /* = true */)
{
	bPlayCameraAnim = bInPlayCameraAnim;

	if (!bCombatCameraBound || !CombatLocator)
	{
		return false;
	}

	switch (Slot)
	{
	case 1:
		CombatCameraType = ECombatCamera::Ally1;
		break;
	case 2:
		CombatCameraType = ECombatCamera::Ally2;
		break;
	case 3:
		CombatCameraType = ECombatCamera::Ally3;
		break;
	default:
		return false;
	}

	UCombatCameraComponent* TargetCameraComponent = CombatLocator->GetCamera(CombatCameraType);
	if (InstanceCombatCameraComponent == TargetCameraComponent)
	{
		if (bPlayCameraAnim && !bWasPlayingCameraAnim)
		{
			PlayCameraAnimation();
		}
		return false;
	}

	float BlendTime = CVarAllyCameraBlendTime.GetValueOnGameThread();
	SetCombatViewTarget(CombatLocator, TargetCameraComponent, BlendTime);

	return BlendTime > 0;
}

bool ACombatPlayerController::ChangeToEnemyCamera(int32 Slot, int32 InWaveEnemyNumSlots, bool bInWaveEnemyDeafultPosition, ECombatCameraBlendType InBlendType /* = ECombatCameraBlendType::NoBlend */, bool bInPlayCameraAnim /* = true */)
{
	bPlayCameraAnim = bInPlayCameraAnim;

	if (!bCombatCameraBound || !CombatLocator)
	{
		return false;
	}

	int32 ConvertedSlot = ULevelUtil::ConvertSlot3to5(Slot, InWaveEnemyNumSlots, bInWaveEnemyDeafultPosition);

	switch (ConvertedSlot)
	{
	case 1:
		CombatCameraType = ECombatCamera::Enemy1;
		break;
	case 2:
		CombatCameraType = ECombatCamera::Enemy2;
		break;
	case 3:
		CombatCameraType = ECombatCamera::Enemy3;
		break;
	case 4:
		CombatCameraType = ECombatCamera::Enemy4;
		break;
	case 5:
		CombatCameraType = ECombatCamera::Enemy5;
		break;
	default:
		Q6JsonLogZagal(Warning, "Wrong Slot for Camera", Q6KV("Slot", Slot), Q6KV("NumSlots", InWaveEnemyNumSlots), Q6KV("ForceDeafult", bInWaveEnemyDeafultPosition));
		return false;
	}

	UCombatCameraComponent* TargetCameraComponent = CombatLocator->GetCamera(CombatCameraType);
	if (InstanceCombatCameraComponent == TargetCameraComponent)
	{
		if (bPlayCameraAnim && !bWasPlayingCameraAnim)
		{
			PlayCameraAnimation();
		}
		return false;
	}

	float BlendTime = InBlendType == ECombatCameraBlendType::NoBlend ? 0.f : CVarEnemyCameraBlendTime.GetValueOnGameThread();
	SetCombatViewTarget(CombatLocator, TargetCameraComponent, BlendTime);

	return BlendTime > 0.f;
}

bool ACombatPlayerController::ChangeToFactionAllCamera(ECCFaction Faction, ECombatCameraBlendType InBlendType /* = ECombatCameraBlendType::NoBlend */, bool bInPlayCameraAnim /* = true */)
{
	bPlayCameraAnim = bInPlayCameraAnim;

	if (!bCombatCameraBound || !CombatLocator)
	{
		return false;
	}

	float BlendTime = 0.f;

	switch (Faction)
	{
		case ECCFaction::Ally:
			CombatCameraType = ECombatCamera::AllyAll;
			BlendTime = InBlendType == ECombatCameraBlendType::LongBlend ? CVarAllyAllCameraBlendTimeLong.GetValueOnGameThread()
				: InBlendType == ECombatCameraBlendType::NoBlend ? 0.f : CVarAllyAllCameraBlendTime.GetValueOnGameThread();
			break;
		case ECCFaction::Enemy:
			CombatCameraType = ECombatCamera::EnemyAll;
			BlendTime = InBlendType == ECombatCameraBlendType::NoBlend ? 0.f : CVarEnemyAllCameraBlendTime.GetValueOnGameThread();
			break;
		default:
			return false;
	}

	UCombatCameraComponent* TargetCameraComponent = CombatLocator->GetCamera(CombatCameraType);
	if (InstanceCombatCameraComponent == TargetCameraComponent)
	{
		if (bPlayCameraAnim && !bWasPlayingCameraAnim)
		{
			PlayCameraAnimation();
		}
		return false;
	}

	SetCombatViewTarget(CombatLocator, TargetCameraComponent, BlendTime);

	return BlendTime > 0.0f;
}

void ACombatPlayerController::SetResultViewTarget(AActor* Actor, UCombatCameraComponent* CameraComponent)
{
	if (InstanceCombatCameraComponent)
	{
		InstanceCombatCameraComponent->HideCulledActorInGame(false);
	}

	InstanceCameraOwnerActor = nullptr;
	InstanceCombatCameraComponent = nullptr;

	AActor* NewViewTarget = nullptr;

	if (CameraComponent)
	{
		InstanceCameraOwnerActor = Actor;
		InstanceCombatCameraComponent = CameraComponent;
		NewViewTarget = GetCachedCameraActor(CameraComponent);
	}
	else if (Actor)
	{
		TInlineComponentArray<UCameraComponent*> CameraComponentList;
		Actor->GetComponents(CameraComponentList);

		if (CameraComponentList.Num() == 1)
		{
			UCombatCameraComponent* CombatCameraComponent = Cast<UCombatCameraComponent>(CameraComponentList[0]);
			if (CombatCameraComponent)
			{
				InstanceCameraOwnerActor = Actor;
				InstanceCombatCameraComponent = CombatCameraComponent;
			}

			NewViewTarget = Actor;
		}
		else
		{
			Q6JsonLogSunny(Warning, "SetCombatViewTarget failed. Camera Component is not unique.", Q6KV("Actor", *Actor->GetName()));
		}
	}
	else
	{
		Q6JsonLogSunny(Warning, "SetResultViewTarget failed. No camera actor nor component.");
	}

	CombatCameraType = ECombatCamera::Result;
	FViewTargetTransitionParams TransitionParams;
	SetViewTarget(NewViewTarget, TransitionParams);
}

void ACombatPlayerController::BindResultCamera()
{
	Q6JsonLogSunny(Display, "CombatPlayerController : BindResultCamera.");

	if (!GetWorld())
	{
		return;
	}

	if (ResultLocator)
	{
		Q6JsonLogSunny(Display, "CombatPlayerController : BindResultCamera to Result Locator");

		SetResultViewTarget(ResultLocator, ResultLocator->GetResultCamera());
	}
	else
	{
		Q6JsonLogSunny(Warning, "BindResultCamera failed. no camera nor locator", Q6KV("World", *GetWorld()->GetName()));
	}
}

bool ACombatPlayerController::IsPlayingSequence() const
{
	return LevelSequencePlayer && LevelSequencePlayer->IsPlaying();
}

void ACombatPlayerController::JumpToEndFrame()
{
	if (LevelSequencePlayer && LevelSequencePlayer->IsPlaying())
	{
		FFrameTime EndTime = LevelSequencePlayer->GetEndTime().Time;
		FFrameTime JumpFrame(EndTime.FrameNumber - 1, 0.99999994f);

		LevelSequencePlayer->JumpToFrame(JumpFrame);
	}
}

void ACombatPlayerController::BindSequenceActors(const TArray<AActor*>& InActors, bool bIsAlly)
{
	if (!LevelSequence || !LevelSequenceActor)
	{
		return;
	}

	for (int32 Index = 0; Index < InActors.Num(); ++Index)
	{
		FString TrackString = bIsAlly ? FString::Printf(TEXT("Ally%d"), Index + 1) : FString::Printf(TEXT("Enemy%d"), Index + 1);

		TArray<FMovieSceneObjectBindingID> BindingIDs = GetSequenceBindingIDs(LevelSequence, TrackString);
		for (FMovieSceneObjectBindingID BindingID : BindingIDs)
		{
			TArray<AActor*> CurActorArray = { InActors[Index] };
			LevelSequenceActor->SetBinding(BindingID, CurActorArray);
		}
	}
}

void ACombatPlayerController::BindSequenceActorsWithExclusionOnFail(TArray<AActor*>& InOutIncludedActors, TArray<AActor*>& InOutExcludedActors, bool bIsAlly)
{
	if (!LevelSequence || !LevelSequenceActor)
	{
		return;
	}

	for (int32 Index = 0; Index < InOutIncludedActors.Num(); ++Index)
	{
		FString TrackString = bIsAlly ? FString::Printf(TEXT("Ally%d"), Index + 1) : FString::Printf(TEXT("Enemy%d"), Index + 1);

		TArray<FMovieSceneObjectBindingID> BindingIDs = GetSequenceBindingIDs(LevelSequence, TrackString);
		if (!BindingIDs.Num())
		{
			InOutExcludedActors.Add(InOutIncludedActors[Index]);
			InOutIncludedActors.RemoveAt(Index);
			--Index;
			continue;
		}

		for (FMovieSceneObjectBindingID BindingID : BindingIDs)
		{
			TArray<AActor*> CurActorArray = { InOutIncludedActors[Index] };
			LevelSequenceActor->SetBinding(BindingID, CurActorArray);
		}
	}
}

void ACombatPlayerController::BindSequenceActorsWithTag(TArray<AActor*>& InOutActors, const FName& Tag)
{
	if (!LevelSequence || !LevelSequenceActor)
	{
		return;
	}

	static const FName CommonTag(TEXT("Sequencer.Common"));
	for (TActorIterator<AActor> It(GetWorld(), AActor::StaticClass()); It; ++It)
	{
		AActor* Actor = *It;
		if (Actor && !Actor->IsHidden() && (Actor->ActorHasTag(CommonTag) || Actor->ActorHasTag(Tag)))
		{
			TArray<FMovieSceneObjectBindingID> BindingIDs = GetSequenceBindingIDs(LevelSequence, Actor->GetFName().GetPlainNameString());
			for (FMovieSceneObjectBindingID BindingID : BindingIDs)
			{
				LevelSequenceActor->AddBinding(BindingID, Actor);
				InOutActors.Add(Actor);
			}
		}
	}
}

void ACombatPlayerController::PlayCameraAnimation()
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		Q6JsonLogGunny(Warning, "ACombatPlayerController::PlayCameraAnimation - CombatGameResource does not exist");
		return;
	}

	UCameraAnim* CameraAnim = CombatGameResource->GetCameraAnimation(CombatCameraType);
	if (!CameraAnim)
	{
		return;
	}

	bool bLoop = false;
	switch (CombatCameraType)
	{
		case ECombatCamera::AllyAll:
		case ECombatCamera::Prepare:
		case ECombatCamera::Result:
			bLoop = true;
			break;
		default:
			break;
	}

	PlayerCameraManager->PlayCameraAnim(
		CameraAnim,
		1.f,
		1.f,
		CombatGameResource->GetCameraAnimBlendInTime(),
		0.f,
		bLoop,
		false,
		0.f,
		ECameraAnimPlaySpace::CameraLocal,
		FRotator::ZeroRotator
	);

	bWasPlayingCameraAnim = true;
}

void ACombatPlayerController::AttachBindedActorsToSequenceActor()
{
	FAttachmentTransformRules AttachmentRules(EAttachmentRule::KeepRelative, false);
	for (AActor* BindedActor : SequenceBindedActors)
	{
		AActor* AttachParentActor = BindedActor->GetAttachParentActor();
		if (AttachParentActor)
		{
			continue;
		}

		BindedActor->AttachToActor(LevelSequenceActor, AttachmentRules);
	}
}

bool ACombatPlayerController::HasWaveSequence(int32 Episode, int32 Stage, int32 Wave, bool IsIntro)
{
	ULevelSequence* WaveLevelSequence = GetWaveLevelSequence(Episode, Stage, Wave, IsIntro);

	if (!WaveLevelSequence)
	{
		return false;
	}

	return true;
}

float ACombatPlayerController::GetWaveSequenceLength()
{
	if (LevelSequencePlayer && LevelSequencePlayer->IsPlaying())
	{
		return LevelSequencePlayer->GetDuration().AsSeconds();
	}

	return 0.0f;
}

void ACombatPlayerController::PlayWaveSequence(int32 Episode, int32 Stage, int32 Wave, bool IsIntro)
{
	LevelSequence = GetWaveLevelSequence(Episode, Stage, Wave, IsIntro);

	if (!LevelSequence)
	{
		OnSequenceStopped();
		return;
	}

	// discard previous sequence
	StopSequencePlayer();

	// create sequence player
	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.LoopCount.Value = 0;
	SequenceSettings.bHideHud = true;

	ACombatLevelSequenceActor* CombatLevelSequenceActor;
	UCombatLevelSequencePlayer* CombatLevelSequencePlayer = UCombatLevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, CombatLevelSequenceActor);
	if (!CombatLevelSequencePlayer)
	{
		OnSequenceStopped();
		return;
	}
	CombatLevelSequencePlayer->SetLevelSequenceActor(CombatLevelSequenceActor);
	CombatLevelSequencePlayer->OnStop.AddUniqueDynamic(this, &ACombatPlayerController::OnSequenceStopped);
	LevelSequenceActor = CombatLevelSequenceActor;
	LevelSequencePlayer = CombatLevelSequencePlayer;

	LevelSequencePlayer->Play();
}

void ACombatPlayerController::PlayResultSequence(AUnit* ResultUnit)
{
	// discard camera animation
	PlayerCameraManager->StopAllCameraAnims(true);

	ResultLocator = ULevelUtil::FindResultLocator(GetWorld());
	if (ResultLocator)
	{
		BindResultCamera();

		FTransform ResultUnitTransform = ResultLocator->GetActorTransform();
		FVector ResultUnitLocation = FVector(ResultUnitTransform.GetLocation().X, ResultUnitTransform.GetLocation().Y, ResultUnit->GetActorLocation().Z);
		ResultUnitTransform.SetLocation(ResultUnitLocation);
		ResultUnit->SetActorTransform(ResultUnitTransform);
	}

	const FResultSequenceAssetRow& ResultSequenceAssetRow = GetGameResource().GetResultSequenceAssetRow(ResultUnit->GetModelType());
	LevelSequence = ResultSequenceAssetRow.ResultSequence.Get();
	if (!LevelSequence)
	{
		StopResultSequence();
		return;
	}

	// discard previous sequence
	StopSequencePlayer();

	// create sequence player
	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.bPauseAtEnd = true;
	SequenceSettings.LoopCount.Value = 0;

	ACombatLevelSequenceActor* CombatLevelSequenceActor;
	UCombatLevelSequencePlayer* CombatLevelSequencePlayer = UCombatLevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, CombatLevelSequenceActor);
	if (!CombatLevelSequencePlayer)
	{
		StopResultSequence();
		return;
	}
	CombatLevelSequencePlayer->SetLevelSequenceActor(CombatLevelSequenceActor);
	CombatLevelSequencePlayer->OnFinished.AddUniqueDynamic(this, &ACombatPlayerController::OnResultSequenceFinished);
	LevelSequenceActor = CombatLevelSequenceActor;
	LevelSequencePlayer = CombatLevelSequencePlayer;

	// location and rotation of sequence
	ResultUnit->UpdateRotationToEnd();

	FVector Location = ResultUnit->GetActorLocation();
	if (CombatLocator)
	{
		Location.Z = CombatLocator->GetBottomLocationZ();
	}
	FRotator Rotation = ResultUnit->GetActorRotation();
	LevelSequenceActor->SetActorLocationAndRotation(Location, Rotation);

	// binding
	SequenceBindedActors.Empty();

	SequenceBindedActors.AddUnique(ResultUnit);
	BindSequenceActors(SequenceBindedActors, true);

	TArray<AActor*> TaggedActors;
	BindSequenceActorsWithTag(TaggedActors, FName(TEXT("Sequencer.NormalSkill")));
	SequenceBindedActors.Append(TaggedActors);

	AttachBindedActorsToSequenceActor();

	// set unit anim mode
	ResultUnit->SetSequenceAnimMode(true);

	// hide other units
	SequenceExcludedUnitActors.Empty();
	TArray<AActor*> AllUnitActors;
	UGameplayStatics::GetAllActorsOfClass(this, AUnitBase::StaticClass(), AllUnitActors);
	for (AActor* UnitActor : AllUnitActors)
	{
		if (UnitActor == ResultUnit)
		{
			// if the result unit is dead, the result unit is disabled & applied materials to dead effect
			if (ResultUnit->IsDead())
			{
				ResultUnit->EnableUnit();
				ResultUnit->ClearMaterialEffect();
			}

			continue;
		}

		if (UnitActor->IsHidden())
		{
			continue;
		}

		UnitActor->SetActorHiddenInGame(true);
		SequenceExcludedUnitActors.Add(UnitActor);
	}

	// play
	LevelSequencePlayer->Play();
}

void ACombatPlayerController::PlayBoneDragonOutroSequence()
{
	// discard camera animation
	PlayerCameraManager->StopAllCameraAnims(true);

	LevelSequence = GetGameResource().BoneDragonOutroSequence.LoadSynchronous();
	if (!LevelSequence)
	{
		OnSequenceStopped();
		return;
	}

	// discard previous sequence
	StopSequencePlayer();

	// create sequence player
	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.bPauseAtEnd = true;
	SequenceSettings.LoopCount.Value = 0;

	ACombatLevelSequenceActor* CombatLevelSequenceActor;
	UCombatLevelSequencePlayer* CombatLevelSequencePlayer = UCombatLevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, CombatLevelSequenceActor);
	if (!CombatLevelSequencePlayer)
	{
		OnSequenceStopped();
		return;
	}
	CombatLevelSequencePlayer->SetLevelSequenceActor(CombatLevelSequenceActor);
	CombatLevelSequencePlayer->OnFinished.AddUniqueDynamic(this, &ACombatPlayerController::OnResultSequenceFinished);
	LevelSequenceActor = CombatLevelSequenceActor;
	LevelSequencePlayer = CombatLevelSequencePlayer;

	SequenceBindedActors.Empty();
	SequenceExcludedUnitActors.Empty();

	TArray<AActor*> AllUnitActors;
	UGameplayStatics::GetAllActorsOfClass(this, AUnitBase::StaticClass(), AllUnitActors);

	for (AActor* UnitActor : AllUnitActors)
	{
		UnitActor->SetActorHiddenInGame(true);
		SequenceExcludedUnitActors.Add(UnitActor);
	}

	// play
	LevelSequencePlayer->Play();
}

void ACombatPlayerController::PlayPetSkillSequence(UCPPetSkillInstance* SkillInstance, APetUnit* OwnerPetUnit, int32 SkillIndex)
{
	// discard camera animation
	PlayerCameraManager->StopAllCameraAnims(true);

	// discard previous sequence
	StopSequencePlayer();

	// skill instance delegate
	SequenceFinishedDelegate.BindUObject(SkillInstance, &UCPPetSkillInstance::OnSequenceFinished);

	if (!OwnerPetUnit)
	{
		OnPetSkillSequenceStopped();
		return;
	}

	LevelSequence = OwnerPetUnit->GetSkillSequence(SkillIndex);
	if (!LevelSequence)
	{
		OnPetSkillSequenceStopped();
		return;
	}

	// create sequence player
	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.LoopCount.Value = 0;
	SequenceSettings.bHideHud = false;

	ACombatLevelSequenceActor* CombatLevelSequenceActor;
	UCombatLevelSequencePlayer* CombatLevelSequencePlayer = UCombatLevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, CombatLevelSequenceActor);
	if (!CombatLevelSequencePlayer)
	{
		OnPetSkillSequenceStopped();
		return;
	}
	CombatLevelSequencePlayer->SetLevelSequenceActor(Cast<ACombatLevelSequenceActor>(CombatLevelSequenceActor));
	CombatLevelSequencePlayer->OnStop.AddUniqueDynamic(this, &ACombatPlayerController::OnPetSkillSequenceStopped);
	LevelSequenceActor = CombatLevelSequenceActor;
	LevelSequencePlayer = CombatLevelSequencePlayer;

	// location and rotation of sequence
	FVector Location = OwnerPetUnit->GetActorLocation();
	if (CombatLocator)
	{
		Location.Z = CombatLocator->GetBottomLocationZ();
	}
	FRotator Rotation = OwnerPetUnit->GetActorRotation();

	LevelSequenceActor->SetActorLocationAndRotation(Location, Rotation);

	// binding
	SequenceBindedActors.Empty();

	SequenceBindedActors.AddUnique(OwnerPetUnit);
	BindSequenceActors(SequenceBindedActors, true);

	AttachBindedActorsToSequenceActor();

	// set pet unit anim mode
	OwnerPetUnit->SetSequenceAnimMode(true);

	// play
	LevelSequencePlayer->Play();
}

void ACombatPlayerController::PlayUltimateSkillSequence(UCPUltimateSkillInstance* SkillInstance, TSoftObjectPtr<ULevelSequence> SkillSequence, AUnit* OwnerUnit, TArray<AActor*>& SkillAllyActors, TArray<AActor*>& SkillEnemyActors, const TArray<AActor*>& SkillExcludedUnitActors)
{
	// discard camera animation
	PlayerCameraManager->StopAllCameraAnims(true);

	// discard previous sequence
	StopSequencePlayer();

	// skill instance delegate
	SequenceFinishedDelegate.BindUObject(SkillInstance, &UCPUltimateSkillInstance::OnSequenceFinished);

	LevelSequence = SkillSequence.Get();
	if (!LevelSequence)
	{
		OnUltimateSkillSequenceStopped();
		return;
	}

	// create sequence player
	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.LoopCount.Value = 0;
	SequenceSettings.bHideHud = true;

	ACombatLevelSequenceActor* CombatLevelSequenceActor;
	UCombatLevelSequencePlayer* CombatLevelSequencePlayer = UCombatLevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, CombatLevelSequenceActor);
	if (!CombatLevelSequencePlayer)
	{
		OnUltimateSkillSequenceStopped();
		return;
	}
	CombatLevelSequencePlayer->SetLevelSequenceActor(Cast<ACombatLevelSequenceActor>(CombatLevelSequenceActor));
	CombatLevelSequencePlayer->OnStop.AddUniqueDynamic(this, &ACombatPlayerController::OnUltimateSkillSequenceStopped);
	LevelSequenceActor = CombatLevelSequenceActor;
	LevelSequencePlayer = CombatLevelSequencePlayer;

	SequenceOwnerUnit = OwnerUnit;

	// location and rotation of sequence
	OwnerUnit->UpdateRotationToEnd();

	FVector Location = OwnerUnit->GetActorLocation();
	if (CombatLocator)
	{
		Location.Z = CombatLocator->GetBottomLocationZ();
	}
	FRotator Rotation = OwnerUnit->GetActorRotation();

	if (SkillEnemyActors.Num())
	{
		const AUnit* SkillTargetUnit = Cast<AUnit>(SkillEnemyActors[0]);
		ensure(SkillTargetUnit);

		if (SkillTargetUnit && SkillTargetUnit != OwnerUnit)
		{
			FVector TargetLocation = SkillTargetUnit->GetActorLocation();
			if (CombatLocator)
			{
				TargetLocation.Z = CombatLocator->GetBottomLocationZ();
			}

			FVector Dir = TargetLocation - Location;
			Rotation = Dir.Rotation();
		}
	}

	LevelSequenceActor->SetActorLocationAndRotation(Location, Rotation);

	// binding
	SequenceExcludedUnitActors = SkillExcludedUnitActors;
	SequenceBindedActors.Empty();

	BindSequenceActorsWithExclusionOnFail(SkillAllyActors, SequenceExcludedUnitActors, true);
	SequenceBindedActors.Append(SkillAllyActors);
	BindSequenceActorsWithExclusionOnFail(SkillEnemyActors, SequenceExcludedUnitActors, false);
	SequenceBindedActors.Append(SkillEnemyActors);

	TArray<AActor*> TaggedActors;
	BindSequenceActorsWithTag(TaggedActors, FName(TEXT("Sequencer.UltimateSkill")));
	SequenceBindedActors.Append(TaggedActors);

	AttachBindedActorsToSequenceActor();

	// set ally units anim mode
	for (AActor* SkillAllyActor : SkillAllyActors)
	{
		AUnit* SkillAllyUnit = Cast<AUnit>(SkillAllyActor);
		if (SkillAllyUnit)
		{
			SkillAllyUnit->SetSequenceAnimMode(true);
		}
	}

	// save enemy units
	SequenceEnemyUnitActors = SkillEnemyActors;

	// save included non owner units
	SequenceIncludedNonOwnerUnitActors.Empty();
	SequenceIncludedNonOwnerUnitActors.Append(SkillAllyActors);
	SequenceIncludedNonOwnerUnitActors.Append(SkillEnemyActors);
	SequenceIncludedNonOwnerUnitActors.Remove(OwnerUnit);

	// hide other units
	for (AActor* Actor : SequenceExcludedUnitActors)
	{
		Actor->SetActorHiddenInGame(true);
	}

	// play
	LevelSequenceActor->PendingTickFrames = 1;
	LevelSequencePlayer->Play();
}

void ACombatPlayerController::PlayNormalSkillSequence(UCPNormalSkillInstance* SkillInstance, AUnit* OwnerUnit, TArray<AActor*>& SkillAllyActors, TArray<AActor*>& SkillEnemyActors, const TArray<AActor*>& SkillExcludedUnitActors, const FTransform& InSequenceTransform)
{
	// discard camera animation
	PlayerCameraManager->StopAllCameraAnims(true);

	// discard previous sequence
	StopSequencePlayer();

	// skill instance delegate
	SequenceFinishedDelegate.BindUObject(SkillInstance, &UCPNormalSkillInstance::OnSequenceFinished);

	const FNormalSkillSequenceAssetRow& SkillSequenceRow = SkillInstance->GetSkillCategory() == ESkillCategory::Double ?
		GetGameResource().GetDoubleSkillSequenceAssetRow(OwnerUnit->GetModelType()) :
		GetGameResource().GetNormalSkillSequenceAssetRow(OwnerUnit->GetModelType(), OwnerUnit->GetSkillNote());
	LevelSequence = SkillSequenceRow.CameraSequence.Get();
	if (!LevelSequence)
	{
		OnNormalSequenceStopped();
		return;
	}

	// create sequence player
	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.LoopCount.Value = 0;

	ACombatLevelSequenceActor* CombatLevelSequenceActor;
	UCombatLevelSequencePlayer* CombatLevelSequencePlayer = UCombatLevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, CombatLevelSequenceActor);
	if (!CombatLevelSequencePlayer)
	{
		OnNormalSequenceStopped();
		return;
	}
	CombatLevelSequencePlayer->SetLevelSequenceActor(CombatLevelSequenceActor);
	CombatLevelSequencePlayer->OnStop.AddUniqueDynamic(this, &ACombatPlayerController::OnNormalSequenceStopped);
	LevelSequenceActor = CombatLevelSequenceActor;
	LevelSequencePlayer = CombatLevelSequencePlayer;

	SequenceOwnerUnit = OwnerUnit;

	// location and rotation of sequence
	OwnerUnit->UpdateRotationToEnd();

	FTransform SequenceActorTransform;
	if (SkillSequenceRow.SequencePlayPosition == ESequencePlayPositon::Owner)
	{
		SequenceActorTransform = OwnerUnit->GetActorTransform();
	}
	else
	{
		SequenceActorTransform = InSequenceTransform;
	}

	FVector Location = SequenceActorTransform.GetLocation();
	if (CombatLocator)
	{
		Location.Z = CombatLocator->GetBottomLocationZ();
	}
	FRotator Rotation = SequenceActorTransform.Rotator();
	LevelSequenceActor->SetActorLocationAndRotation(Location, Rotation);

	// binding
	SequenceBindedActors.Empty();

	TArray<AActor*> TaggedActors;
	BindSequenceActorsWithTag(TaggedActors, FName(TEXT("Sequencer.NormalSkill")));
	SequenceBindedActors.Append(TaggedActors);

	AttachBindedActorsToSequenceActor();

	// need binding but not attached
	TArray<AActor*> OwnerUnitActorArray = { OwnerUnit };
	BindSequenceActors(OwnerUnitActorArray, true);
	SequenceBindedActors.Append(OwnerUnitActorArray);

	// save enemy units
	SequenceEnemyUnitActors = SkillEnemyActors;

	// save included non owner units
	SequenceIncludedNonOwnerUnitActors.Empty();
	SequenceIncludedNonOwnerUnitActors.Append(SkillAllyActors);
	SequenceIncludedNonOwnerUnitActors.Append(SkillEnemyActors);
	SequenceIncludedNonOwnerUnitActors.Remove(OwnerUnit);

	// hide other units
	SequenceExcludedUnitActors = SkillExcludedUnitActors;
	for (AActor* Actor : SequenceExcludedUnitActors)
	{
		Actor->SetActorHiddenInGame(true);
	}

	// play
	LevelSequenceActor->AdditionalDeltaSeconds += GetWorld()->GetDeltaSeconds();
	LevelSequencePlayer->Play();
}

bool ACombatPlayerController::PlaySkillAnimation()
{
	return GetCheckedCombatHUD(this)->PlaySkillAnimation();
}

void ACombatPlayerController::HideSequenceIncludedNonOwnerUnits()
{
	for (AActor* UnitActor : SequenceIncludedNonOwnerUnitActors)
	{
		UnitActor->SetActorHiddenInGame(true);
	}
}

void ACombatPlayerController::ShowSequenceIncludedNonOwnerUnits()
{
	for (AActor* UnitActor : SequenceIncludedNonOwnerUnitActors)
	{
		UnitActor->SetActorHiddenInGame(false);
	}
	SequenceIncludedNonOwnerUnitActors.Empty();
}

void ACombatPlayerController::HideSequenceExcludedActors()
{
	TSet<AActor*> Exceptions;
	Exceptions.Add(GetWorldSettings());
	Exceptions.Add(SequenceOwnerUnit);
	Exceptions.Append(SequenceIncludedNonOwnerUnitActors);
	Exceptions.Append(SequenceBindedActors);

	UCombatLevelSequencePlayer* CombatLevelSequencePlayer = Cast<UCombatLevelSequencePlayer>(LevelSequencePlayer);
	if (CombatLevelSequencePlayer)
	{
		Exceptions.Append(CombatLevelSequencePlayer->GetSequenceSpawnedActors());
	}

	TArray<AActor*> AllActors;
	UGameplayStatics::GetAllActorsOfClass(this, AActor::StaticClass(), AllActors);

	for (AActor* Actor : AllActors)
	{
		if (Exceptions.Find(Actor))
		{
			continue;
		}

		if (ASkyLight* SkyLight = Cast<ASkyLight>(Actor))
		{
			if (USkyLightComponent* Component = SkyLight->GetLightComponent())
			{
				Component->SetVisibility(false);
			}
		}
		else
		{
			if (Actor->IsHidden())
			{
				continue;
			}

			Actor->SetActorHiddenInGame(true);
		}

		SequenceHiddenActors.Add(Actor);
	}
}

void ACombatPlayerController::ShowSequenceExcludedActors()
{
	for (AActor* HiddenActor : SequenceHiddenActors)
	{
		if (!HiddenActor)
		{
			continue;
		}

		if (ASkyLight* SkyLight = Cast<ASkyLight>(HiddenActor))
		{
			if (USkyLightComponent* Component = SkyLight->GetLightComponent())
			{
				Component->SetVisibility(true);
			}
		}
		else
		{
			HiddenActor->SetActorHiddenInGame(false);
		}
	}

	SequenceHiddenActors.Empty();
}

void ACombatPlayerController::SetEnemyActorsAnimPaused(bool bInPause)
{
	for (AActor* UnitActor : SequenceEnemyUnitActors)
	{
		if (!UnitActor)
		{
			continue;
		}

		AUnit* Unit = Cast<AUnit>(UnitActor);
		if (Unit)
		{
			Unit->SetAnimPaused(bInPause);
		}
	}
}

void ACombatPlayerController::SetEnemyActorsSubMaterialEffect(const FSubMaterialEffectParams& InParams)
{
	for (AActor* UnitActor : SequenceEnemyUnitActors)
	{
		if (!UnitActor)
		{
			continue;
		}

		AUnit* Unit = Cast<AUnit>(UnitActor);
		if (Unit)
		{
			Unit->SetSubMaterialEffect(InParams);
		}
	}
}

void ACombatPlayerController::ClearEnemyActorsSubMaterialEffect()
{
	for (AActor* UnitActor : SequenceEnemyUnitActors)
	{
		if (!UnitActor)
		{
			continue;
		}

		AUnit* Unit = Cast<AUnit>(UnitActor);
		if (Unit)
		{
			Unit->ClearSubMaterialEffect();
		}
	}
}

void ACombatPlayerController::OnSequenceStopped()
{
	SequenceBindedActors.Empty();
	SequenceEnemyUnitActors.Empty();
	SequenceIncludedNonOwnerUnitActors.Empty();
	SequenceExcludedUnitActors.Empty();
	SequenceHiddenActors.Empty();
	DestroySequenceActor();

	SequenceOwnerUnit = nullptr;
	bSequenceCameraFollowing = false;

	SequenceFinishedDelegate.ExecuteIfBound();
	SequenceFinishedDelegate.Unbind();

	// restore camera animation
	if (bWasPlayingCameraAnim)
	{
		PlayCameraAnimation();
	}
}

void ACombatPlayerController::RestoreSequenceHiddenActors()
{
	// restore hidden units
	for (AActor* HiddenActor : SequenceExcludedUnitActors)
	{
		if (!HiddenActor)
		{
			continue;
		}

		HiddenActor->SetActorHiddenInGame(false);
	}

	// restore other hidden actors in case of event not triggered
	if (SequenceIncludedNonOwnerUnitActors.Num())
	{
		ShowSequenceIncludedNonOwnerUnits();
	}

	if (SequenceHiddenActors.Num())
	{
		ShowSequenceExcludedActors();
	}
}

ULevelSequence* ACombatPlayerController::GetWaveLevelSequence(int32 Episode, int32 Stage, int32 Wave, bool IsIntro)
{
	const FWaveSequenceAssetRow& WaveSequenceAssetRow = GetGameResource().GetWaveSequenceAssetRow(Episode, Stage, Wave);

	ULevelSequence* WaveLevelSequence = IsIntro
		? WaveSequenceAssetRow.IntroSequence.Get()
		: WaveSequenceAssetRow.OutroSequence.Get();

	return WaveLevelSequence;
}

void ACombatPlayerController::OnNormalSequenceStopped()
{
	// clear binding
	FDetachmentTransformRules DetachmentRules(EDetachmentRule::KeepRelative, false);
	for (AActor* BindedActor : SequenceBindedActors)
	{
		if (!BindedActor)
		{
			continue;
		}

		if (BindedActor->IsAttachedTo(LevelSequenceActor))
		{
			BindedActor->DetachFromActor(DetachmentRules);
		}
	}

	RestoreSequenceHiddenActors();
	OnSequenceStopped();
}

void ACombatPlayerController::OnUltimateSkillSequenceStopped()
{
	// clear binding
	FDetachmentTransformRules DetachmentRules(EDetachmentRule::KeepRelative, false);
	for (AActor* BindedActor : SequenceBindedActors)
	{
		if (!BindedActor)
		{
			continue;
		}

		if (BindedActor->IsAttachedTo(LevelSequenceActor))
		{
			BindedActor->DetachFromActor(DetachmentRules);
		}

		AUnit* Unit = Cast<AUnit>(BindedActor);
		if (Unit)
		{
			Unit->SetSequenceAnimMode(false);
		}
	}

	RestoreSequenceHiddenActors();
	OnSequenceStopped();
}

void ACombatPlayerController::OnPetSkillSequenceStopped()
{
	// clear binding
	FDetachmentTransformRules DetachmentRules(EDetachmentRule::KeepRelative, false);
	for (AActor* BindedActor : SequenceBindedActors)
	{
		if (!BindedActor)
		{
			continue;
		}

		if (BindedActor->IsAttachedTo(LevelSequenceActor))
		{
			BindedActor->DetachFromActor(DetachmentRules);
		}

		APetUnit* PetUnit = Cast<APetUnit>(BindedActor);
		if (PetUnit)
		{
			PetUnit->SetSequenceAnimMode(false);
		}
	}

	OnSequenceStopped();
}

void ACombatPlayerController::OnResultSequenceFinished()
{
	SequencePausedDelegate.ExecuteIfBound();

	for (AActor* BindedActor : SequenceBindedActors)
	{
		TArray<UActorComponent*> Components;
		BindedActor->GetComponents(UParticleSystemComponent::StaticClass(), Components);

		for (UActorComponent* Component : Components)
		{
			UParticleSystemComponent* Particle = Cast<UParticleSystemComponent>(Component);
			if (Particle)
			{
				Particle->CustomTimeDilation = 0.0f;
			}
		}
	}
}

void ACombatPlayerController::StopResultSequence()
{
	// clear binding
	FDetachmentTransformRules DetachmentRules(EDetachmentRule::KeepRelative, false);
	for (AActor* BindedActor : SequenceBindedActors)
	{
		if (!BindedActor)
		{
			continue;
		}

		if (BindedActor->IsAttachedTo(LevelSequenceActor))
		{
			BindedActor->DetachFromActor(DetachmentRules);
		}
	}

	OnSequenceStopped();
}
