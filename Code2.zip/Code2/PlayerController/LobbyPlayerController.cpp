// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "LobbyPlayerController.h"
#include "CodexManager.h"
#include "DialoguePlayer.h"
#include "Engine.h"
#include "Engine/Q6DirectionalLight.h"
#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"
#include "LobbyHUD.h"
#include "LobbyHUDWidget.h"
#include "LobbySetManager.h"
#include "LobbyTemplate.h"
#include "LobbyTemplateManager.h"
#include "MenuUnit.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "Q6SoundPlayer.h"
#include "Q6UIDefine.h"


static const float TOUCH_LOC_TOLERANCE = 5.0f;

ALobbyPlayerController::ALobbyPlayerController(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bIsPinching(false)
	, PreviousPinchScale(0.f)
	, PreviousTouchLocation(FVector2D::ZeroVector)
	, TouchEnteredLocation(FVector2D::ZeroVector)
	, LobbyUnit(nullptr)
	, LobbyCamera(nullptr)
	, LobbyTemplate(nullptr)
	, DialoguePlayer(nullptr)
	, TouchBeganObject(nullptr)
	, CodexBlackUnitCameraFocalRegion(250.f)
	, OriginalCameraFocalRegion(0.f)
	, bPlayingPreview(false)
{
}

void ALobbyPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	check(InputComponent);

	InputComponent->BindAction("pinch", IE_Pressed, this, &ALobbyPlayerController::PinchStart);
	InputComponent->BindAction("pinch", IE_Released, this, &ALobbyPlayerController::PinchEnd);
	InputComponent->BindAxis("pinch_axis", this, &ALobbyPlayerController::PinchAxis);
}

void ALobbyPlayerController::BeginPlay()
{
	Super::BeginPlay();

	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	if (GameInstance && !GameInstance->IsEnteredLobby())
	{
		InitOfflineLobby();
	}
}

void ALobbyPlayerController::PlayerTick(float DeltaTime)
{
	Super::PlayerTick(DeltaTime);

	InputScrollManager.UpdateScrollVelocity(DeltaTime);
}

void ALobbyPlayerController::OnPostLoadMap()
{
	// default camera and unit located
	LobbyCamera = nullptr;
	for (TActorIterator<ACameraActor> It(GetWorld(), ACameraActor::StaticClass()); It; ++It)
	{
		ACameraActor* CameraActor = *It;
		if (CameraActor->GetName().Equals("MainCamera", ESearchCase::IgnoreCase))
		{
			LobbyCamera = CameraActor;
			SetViewTarget(CameraActor);

			OriginalCameraFocalRegion = LobbyCamera->GetCameraComponent()->PostProcessSettings.DepthOfFieldFocalRegion;
			break;
		}
	}
	for (TActorIterator<AMenuUnit> It(GetWorld(), AMenuUnit::StaticClass()); It; ++It)
	{
		LobbyUnit = CastChecked<AMenuUnit>(*It);
		break;
	}
	if (LobbyCamera && LobbyUnit)
	{
		LobbyUnit->InitDefaultFocusing();
		LobbyCamera->GetCameraComponent()->AttachToComponent(LobbyUnit->GetSpringArm(), FAttachmentTransformRules::KeepRelativeTransform, USpringArmComponent::SocketName);
	}

	// lobby template
	for (TActorIterator<ALobbyTemplate> It(GetWorld(), ALobbyTemplate::StaticClass()); It; ++It)
	{
		LobbyTemplate = *It;
		break;
	}
	InitLobbyTemplate();

	// dialogue player
	InitDialoguePlayer();
}

void ALobbyPlayerController::PinchStart()
{
	bIsPinching = true;
	PreviousPinchScale = 0.f;
}

void ALobbyPlayerController::PinchEnd()
{
	bIsPinching = false;
}

void ALobbyPlayerController::PinchAxis(float PinchScale)
{
	if (!bIsPinching)
	{
		return;
	}

	if (FMath::IsNearlyEqual(PreviousPinchScale, PinchScale))
	{
		return;
	}

	float PinchZoomResult = FMath::Sign(PinchScale - PreviousPinchScale);
	UpdateCameraZoom(-PinchZoomResult);

	PreviousPinchScale = PinchScale;
}

static bool _IsUsingLobbyUnitView(ALobbyHUD* LobbyHUD)
{
	EHUDWidgetType CurrentHUDWidgetType = LobbyHUD->GetCurrentHUDWidgetType();
	return LobbyHUD->IsInAppreciation() || CurrentHUDWidgetType == EHUDWidgetType::Codex;
}

static bool _IsUsingLobbyTemplateView(ALobbyHUD* LobbyHUD)
{
	EHUDWidgetType CurrentHUDWidgetType = LobbyHUD->GetCurrentHUDWidgetType();
	return CurrentHUDWidgetType == EHUDWidgetType::Main || CurrentHUDWidgetType == EHUDWidgetType::LobbySetting;
}

void ALobbyPlayerController::SetTouchBeganCharacterObject(UObject* InObject)
{
	ALobbyHUD* LobbyHUD = Cast<ALobbyHUD>(GetHUD());
	if (LobbyHUD)
	{
		if (_IsUsingLobbyTemplateView(LobbyHUD))
		{
			ULobbyCharacterComponent* LobbyCharacterComp = Cast<ULobbyCharacterComponent>(InObject);
			if (LobbyCharacterComp)
			{
				TouchBeganObject = LobbyCharacterComp;
			}
		}
		else if (_IsUsingLobbyUnitView(LobbyHUD))
		{
			AMenuUnit* MenuUnit = Cast<AMenuUnit>(InObject);
			if (MenuUnit)
			{
				TouchBeganObject = MenuUnit;
			}
		}
	}
}

bool ALobbyPlayerController::InputTouch(uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation, float Force, FDateTime DeviceTimestamp, uint32 TouchpadIndex)
{
	bool bResult = Super::InputTouch(Handle, Type, TouchLocation, Force, DeviceTimestamp, TouchpadIndex);

	ALobbyHUD* LobbyHUD = Cast<ALobbyHUD>(GetHUD());
	if (LobbyHUD)
	{
		if (!_IsUsingLobbyUnitView(LobbyHUD) && !_IsUsingLobbyTemplateView(LobbyHUD))
		{
			return false;
		}
	}

	if (ETouchIndex::Type(Handle) != ETouchIndex::Touch1)
	{
		return false;
	}

	if (Type == ETouchType::Began)
	{
		PreviousTouchLocation = TouchLocation;
		TouchEnteredLocation = TouchLocation;

		// using ECC_GameTraceChannel1 as custom touch channel
		FHitResult HitResult;
		GetHitResultUnderCursor(ECC_GameTraceChannel1, true, HitResult);

		TouchBeganObject = nullptr;
		if (HitResult.GetComponent())
		{
			SetTouchBeganCharacterObject(HitResult.GetComponent()->GetOuter());
		}

		InputScrollManager.ClearScrollVelocity();
	}
	else if (Type == ETouchType::Moved)
	{
		if (!PreviousTouchLocation.IsZero())
		{
			InputDragged(TouchLocation - PreviousTouchLocation);
		}
		PreviousTouchLocation = TouchLocation;
	}
	else if (Type == ETouchType::Ended)
	{
		if (TouchLocation.Equals(TouchEnteredLocation, TOUCH_LOC_TOLERANCE))
		{
			if (TouchBeganObject)
			{
				ULobbyCharacterComponent* LobbyCharacterComp = Cast<ULobbyCharacterComponent>(TouchBeganObject);
				if (LobbyCharacterComp)
				{
					LobbyCharacterComp->OnTouched();
				}
				else
				{
					AMenuUnit* MenuUnit = Cast<AMenuUnit>(TouchBeganObject);
					if (MenuUnit)
					{
						MenuUnit->OnTouched();
					}
				}
			}
			else
			{
				ABaseHUD* BaseHUD = Cast<ABaseHUD>(MyHUD);
				if (BaseHUD)
				{
					BaseHUD->OnBackgroundTouched();
				}

				OnInputPreciseTouchedDelegate.ExecuteIfBound();
			}
		}

		PreviousTouchLocation = FVector2D::ZeroVector;
		TouchEnteredLocation = FVector2D::ZeroVector;
	}

	return bResult;
}

static float ScrollSensitivity = 5.f;
bool ALobbyPlayerController::InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad)
{
	bool bResult = Super::InputKey(Key, EventType, AmountDepressed, bGamepad);

	if (EventType == IE_Released)
	{
		if (Key == EKeys::MouseScrollUp)
		{
			UpdateCameraZoom(AmountDepressed * ScrollSensitivity * -1.0f);
		}
		else if (Key == EKeys::MouseScrollDown)
		{
			UpdateCameraZoom(AmountDepressed * ScrollSensitivity);
		}
	}

	return bResult;
}

bool ALobbyPlayerController::InputDragged(const FVector2D& DeltaLocation)
{
	const float Speed = 0.005f;

	float Delta = FMath::Abs(DeltaLocation.X) < FMath::Abs(DeltaLocation.Y) ? DeltaLocation.Y : DeltaLocation.X;
	InputScrollManager.AddScrollSample(Delta * Speed, GetWorld()->GetRealTimeSeconds());

	if (GetViewTarget() == LobbyCamera)
	{
		if (LobbyUnit)
		{
			LobbyUnit->InputDragged(DeltaLocation, InputScrollManager.GetScrollVelocity());
		}
	}
	else if (LobbyTemplate)
	{
		if (!PlayerCameraManager->BlendTimeToGo)
		{
			LobbyTemplate->InputDragged(DeltaLocation, InputScrollManager.GetScrollVelocity());
		}
	}

	return true;
}

static float PinchZoomSensitivity = 10.f;
static float PinchZoomThreshold = 0.2f;
void ALobbyPlayerController::UpdateCameraZoom(float Zoom)
{
	if (!LobbyUnit)
	{
		return;
	}

	if (LobbyUnit->IsBlack())
	{
		return;
	}

	if (!LobbyUnit->IsInFullView())
	{
		return;
	}

	if (FMath::Abs(Zoom) < PinchZoomThreshold)
	{
		return;
	}

	LobbyUnit->AddTargetArmLength(Zoom * PinchZoomSensitivity);
}

void ALobbyPlayerController::SetLobbyUnit(FCharacterType InCharacterType, bool bChangeView)
{
	if (!LobbyUnit)
	{
		return;
	}

	if (InCharacterType == CharacterTypeInvalid)
	{
		LobbyUnit->OnPreviewAnimEndDelegate.Unbind();
		LobbyUnit->DisableUnit();

		if (bChangeView)
		{
			SetLobbyTemplateVisible(true);
		}

		return;
	}

	bool bOwned = true;
	ALobbyHUD* LobbyHUD = Cast<ALobbyHUD>(GetHUD());
	EHUDWidgetType CurHUDWidgetType = LobbyHUD ? LobbyHUD->GetCurrentHUDWidgetType() : EHUDWidgetType::Invalid;
	if (LobbyHUD && CurHUDWidgetType == EHUDWidgetType::Codex)
	{
		SetCodexCameraFocalRegion(false);

		if (!GetHUDStore().GetCodexManager().FindChar(InCharacterType))
		{
			bOwned = false;
		}
	}

	LobbyUnit->InitCharacterUnit(InCharacterType, CurHUDWidgetType, bOwned);
	LobbyUnit->InitDefaultFocusing();

	LobbyUnit->EnableUnit();
	LobbyUnit->OnPreviewAnimEndDelegate.BindUObject(this, &ALobbyPlayerController::OnPreviewFinished);

	if (bChangeView)
	{
		SetLobbyTemplateVisible(false);
	}
}

void ALobbyPlayerController::SetLobbyUnitFullView(bool bInFullView)
{
	if (!LobbyUnit)
	{
		return;
	}

	LobbyUnit->SetFullView(bInFullView);
}

void ALobbyPlayerController::PlayPreview(ECharacterVoiceCategory VoiceCategory, TSoftObjectPtr<USoundBase> VoiceSound)
{
	bPlayingPreview = false;
	if (!LobbyUnit)
	{
		return;
	}

	LobbyUnit->SetPreviewVoice(VoiceSound);

	if (VoiceCategory == ECharacterVoiceCategory::UltimateSkill)
	{
		bPlayingPreview = PlayPreviewUltimateSkillSequence();
	}
	else if (VoiceCategory == ECharacterVoiceCategory::Victory)
	{
		bPlayingPreview = PlayPreviewResultSequence();
	}
	
	if (!bPlayingPreview)
	{
		bPlayingPreview = LobbyUnit->PlayPreviewAnimation(VoiceCategory);
	}
}

void ALobbyPlayerController::StopPreview()
{
	if (LevelSequencePlayer)
	{
		LevelSequencePlayer->Stop();
		GetCheckedLobbyHUD(this)->StopSkillAnimation();
	}
	else
	{
		LobbyUnit->StopPreviewAnimation();
	}
}

bool ALobbyPlayerController::PlaySkillAnimation()
{
	return GetCheckedLobbyHUD(this)->PlaySkillAnimation(LobbyUnit->GetUnitType());
}

void ALobbyPlayerController::BindSequenceActors(TArray<AActor*>& InOutActors, ULevelSequence* InLevelSequence, ALevelSequenceActor* InLevelSequenceActor)
{
	if (!InLevelSequence || !InLevelSequenceActor)
	{
		return;
	}

	FString TrackString = TEXT("Ally1");
	TArray<FMovieSceneObjectBindingID> BindingIDs = GetSequenceBindingIDs(InLevelSequence, TrackString);
	for (FMovieSceneObjectBindingID BindingID : BindingIDs)
	{
		InLevelSequenceActor->AddBinding(BindingID, LobbyUnit);
		InOutActors.Add(LobbyUnit);
	}

	static const FName CommonTag(TEXT("Sequencer.Common"));
	for (TActorIterator<AActor> It(GetWorld(), AActor::StaticClass()); It; ++It)
	{
		AActor* Actor = *It;
		if (Actor && !Actor->IsHidden() && Actor->ActorHasTag(CommonTag))
		{
			BindingIDs = GetSequenceBindingIDs(InLevelSequence, Actor->GetFName().GetPlainNameString());
			for (FMovieSceneObjectBindingID BindingID : BindingIDs)
			{
				InLevelSequenceActor->AddBinding(BindingID, Actor);
				InOutActors.Add(Actor);
			}
		}
	}
}

bool ALobbyPlayerController::PlayPreviewUltimateSkillSequence()
{
	const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRow = GetGameResource().GetModelUltimateSkillSequenceAssetRow(LobbyUnit->GetModelType(), false);

	if (UltimateSkillSequenceAssetRow.SkillSequence.IsNull())
	{
		return false;
	}

	LevelSequence = UltimateSkillSequenceAssetRow.SkillSequence.Get();
	if (!LevelSequence)
	{
		return false;
	}

	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.LoopCount.Value = 0;
	SequenceSettings.bHideHud = true;

	LevelSequencePlayer = ULevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, LevelSequenceActor);
	if (!LevelSequencePlayer)
	{
		return false;
	}
	LevelSequencePlayer->OnStop.AddUniqueDynamic(this, &ALobbyPlayerController::OnPreviewUltimateSkillSequenceStopped);
	
	// binding
	TArray<AActor*> SequenceBindedActors;
	BindSequenceActors(SequenceBindedActors, LevelSequence, LevelSequenceActor);

	// set lobby unit
	LobbyUnit->SetSequenceAnimMode(true);

	// hide other actors
	TArray<AActor*> AllActors;
	UGameplayStatics::GetAllActorsOfClass(this, AActor::StaticClass(), AllActors);
	for (AActor* Actor : AllActors)
	{
		if (SequenceBindedActors.Contains(Actor))
		{
			continue;
		}

		if (!Actor->Layers.FindByKey("Appreciation"))
		{
			continue;
		}

		Actor->SetActorHiddenInGame(true);
	}

	// play
	LevelSequenceActor->PendingTickFrames = 1;
	LevelSequencePlayer->Play();

	GetSoundPlayer().PlaySkillBGM(UltimateSkillSequenceAssetRow.SkillBGM);

	return true;
}

bool ALobbyPlayerController::PlayPreviewResultSequence()
{
	const FResultSequenceAssetRow& ResultSequenceAssetRow = GetGameResource().GetResultSequenceAssetRow(LobbyUnit->GetModelType());

	if (ResultSequenceAssetRow.ResultSequence.IsNull())
	{
		return false;
	}

	LevelSequence = ResultSequenceAssetRow.ResultSequence.Get();
	if (!LevelSequence)
	{
		return false;
	}

	FMovieSceneSequencePlaybackSettings SequenceSettings;
	SequenceSettings.LoopCount.Value = 0;
	SequenceSettings.bHideHud = true;

	LevelSequencePlayer = ULevelSequencePlayer::CreateLevelSequencePlayer(this, LevelSequence, SequenceSettings, LevelSequenceActor);
	if (!LevelSequencePlayer)
	{
		return false;
	}
	LevelSequencePlayer->OnStop.AddUniqueDynamic(this, &ALobbyPlayerController::OnPreviewSequenceStopped);

	// binding
	TArray<AActor*> SequenceBindedActors;
	BindSequenceActors(SequenceBindedActors, LevelSequence, LevelSequenceActor);

	// set lobby unit
	LobbyUnit->SetSequenceAnimMode(true);

	// play
	LevelSequenceActor->PendingTickFrames = 1;
	LevelSequencePlayer->Play();

	return true;
}

void ALobbyPlayerController::OnPreviewUltimateSkillSequenceStopped()
{
	GetSoundPlayer().StopSkillBGM();
	GetCheckedLobbyHUD(this)->StopSkillAnimation();
	GetCheckedLobbyHUD(this)->UpdateAppreciationActorVisibility(true);

	OnPreviewSequenceStopped();
}

void ALobbyPlayerController::OnPreviewSequenceStopped()
{
	LobbyUnit->SetSequenceAnimMode(false);
	DestroySequenceActor();

	OnPreviewFinished();
}

void ALobbyPlayerController::OnPreviewFinished()
{
	bPlayingPreview = false;
	OnPreviewFinishedDelegate.ExecuteIfBound();
}

void ALobbyPlayerController::InitDialoguePlayer()
{
	for (TActorIterator<ADialoguePlayer> It(GetWorld(), ADialoguePlayer::StaticClass()); It; ++It)
	{
		DialoguePlayer = *It;
		DialoguePlayer->Initialize();
		break;
	}
}

void ALobbyPlayerController::SetCodexCameraFocalRegion(bool bInBlackUnit)
{
	if (!LobbyCamera)
	{
		return;
	}

	float FocalRegion = bInBlackUnit ? CodexBlackUnitCameraFocalRegion : OriginalCameraFocalRegion;
	LobbyCamera->GetCameraComponent()->PostProcessSettings.DepthOfFieldFocalRegion = FocalRegion;
}

void ALobbyPlayerController::RestoreLobbyCameraFocalRegion()
{
	if (!LobbyCamera)
	{
		return;
	}

	LobbyCamera->GetCameraComponent()->PostProcessSettings.DepthOfFieldFocalRegion = OriginalCameraFocalRegion;
}

bool ALobbyPlayerController::IsWidgetShowingView() const
{
	if (!LobbyTemplate)
	{
		return true;
	}

	return LobbyTemplate->IsWidgetShowingView();
}

void ALobbyPlayerController::InitLobbyTemplate()
{
	const FLobbySetInfo& LobbySetInfo = GetHUDStore().GetLobbySetManager().GetSelectedLobbySetInfo();
	const FLobbyTemplateInfo& LobbyTemplateInfo = GetHUDStore().GetLobbyTemplateManager().GetLobbyTemplateInfo(LobbySetInfo.LobbyTemplateId);

	SetLobbyTemplate(LobbyTemplateInfo.Type);
	SetLobbyCharacters(LobbySetInfo.CharacterIds);
}

void ALobbyPlayerController::SetLobbyTemplate(FLobbyTemplateType InTemplateType)
{
	FLobbyTemplateType TemplateType = (InTemplateType == LobbyTemplateTypeInvalid) ?
		GetHUDStore().GetLobbyTemplateManager().GetDefaultLobbyTemplateType() : InTemplateType;

	const FLobbyTemplateAssetRow& Row = GetGameResource().GetLobbyTemplateAssetRow(TemplateType);
	if (Row.Template.IsNull())
	{
		Q6JsonLogSunny(Warning, "SetLobbyTemplate - No Template", Q6KV("TemplateType", TemplateType));
		return;
	}

	FActorSpawnParameters SpawnParam;
	SpawnParam.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	ALobbyTemplate* NewLobbyTemplate = GetWorld()->SpawnActor<ALobbyTemplate>(Row.Template.LoadSynchronous(), SpawnParam);
	if (!NewLobbyTemplate)
	{
		Q6JsonLogSunny(Warning, "SetLobbyTemplate - Failed to spawn", Q6KV("TemplateType", TemplateType));
		return;
	}

	FVector TemplateLocation = LobbyTemplate ? LobbyTemplate->GetActorLocation() : FVector::ZeroVector;
	NewLobbyTemplate->SetActorLocation(TemplateLocation);
	NewLobbyTemplate->InitTemplate(Row.SlotInfos);

	if (LobbyTemplate)
	{
		LobbyTemplate->Destroy();
	}
	LobbyTemplate = NewLobbyTemplate;

	SetLobbyTemplateVisible(true);
}

void ALobbyPlayerController::SetLobbyTemplateVisible(bool bVisible, bool bResetView /* = true */)
{
	if (!LobbyTemplate)
	{
		return;
	}

	LobbyTemplate->SetActorHiddenInGame(!bVisible);

	if (bVisible)
	{
		if (bResetView)
		{
			LobbyTemplate->ResetView();
		}
		LobbyTemplate->ResetCamera();
		LobbyTemplate->SetToViewTarget(this);
	}
	else
	{
		SetViewTarget(LobbyCamera);
	}
}

void ALobbyPlayerController::SetLobbyCharacters(const TArray<FCharacterId>& InCharacterIds)
{
	if (!LobbyTemplate)
	{
		return;
	}

	LobbyTemplate->SetCharacters(InCharacterIds);
}

void ALobbyPlayerController::SetLobbyCharactersVisible(bool bVisible)
{
	if (!LobbyTemplate)
	{
		return;
	}

	LobbyTemplate->SetCharactersVisible(bVisible);
}

void ALobbyPlayerController::PlayLobbyCharacterWelcomeAnimation(int32 InIndex /* = INDEX_NONE */)
{
	if (!LobbyTemplate)
	{
		return;
	}

	LobbyTemplate->PlayCharacterWelcomeAnimation(InIndex);
}

void ALobbyPlayerController::ClearLobbyCharactersIntermediateState()
{
	if (!LobbyTemplate)
	{
		return;
	}

	LobbyTemplate->ClearCharactersIntermediateState();
}

void ALobbyPlayerController::SetLobbyTemplateCameraFocus(int32 InSlotIndex)
{
	if (!LobbyTemplate)
	{
		return;
	}

	LobbyTemplate->RotateCameraTo(InSlotIndex);
}

void ALobbyPlayerController::InitOfflineLobby()
{
	for (TActorIterator<ALobbyTemplate> It(GetWorld(), ALobbyTemplate::StaticClass()); It; ++It)
	{
		LobbyTemplate = *It;
		break;
	}

	if (LobbyTemplate)
	{
		SetLobbyTemplateVisible(true);
		LobbyTemplate->InitTemplateCameras();
	}
}

void ALobbyPlayerController::PlayContinue(const FDialogueRecord& DialogueRecord, const FDialogueType PlayingDialogueType)
{
	if (DialoguePlayer)
	{
		DialoguePlayer->PlayContinue(DialogueRecord, PlayingDialogueType);
	}
}

void ALobbyPlayerController::PlaySaga(FSagaType InSagaType, bool bInPrologue, bool bInReplay)
{
	if (DialoguePlayer)
	{
		DialoguePlayer->PlaySaga(InSagaType, bInPrologue, bInReplay);
	}
}

void ALobbyPlayerController::PlayDaily(EDayOfWeekType InDayOfWeek, bool bInReplay)
{
	if (DialoguePlayer)
	{
		DialoguePlayer->PlayDaily(InDayOfWeek, bInReplay);
	}
}

void ALobbyPlayerController::PlayTraining(FTrainingCenterType InTraingType, FSagaType InSagaType, bool bInPrologue, bool bInReplay)
{
	if (DialoguePlayer)
	{
		DialoguePlayer->PlayTraining(InTraingType, InSagaType, bInPrologue, bInReplay);
	}
}

void ALobbyPlayerController::PlayVacation(const FVacationResult& InResult)
{
	if (DialoguePlayer)
	{
		DialoguePlayer->PlayVacation(InResult);
	}
}

void ALobbyPlayerController::PlayEvent(FEventContentType InEventContentType, FSagaType InSagaType, bool bInPrologue, bool bInReplay)
{
	if (DialoguePlayer)
	{
		DialoguePlayer->PlayEvent(InEventContentType, InSagaType, bInPrologue, bInReplay);
	}
}

bool ALobbyPlayerController::HasPlayableDialogue(FSagaType InSagaType)
{
	if (DialoguePlayer)
	{
		return DialoguePlayer->IsPlayableSaga(InSagaType);
	}

	return false;
}

void ALobbyPlayerController::GotoDialogue(int32 GotoId)
{
	if (DialoguePlayer)
	{
		DialoguePlayer->GotoDialogue(GotoId);
	}
}

void ALobbyPlayerController::OnShowLobby()
{
	if (!LobbyTemplate)
	{
		return;
	}

	ALobbyTutorial* LobbyTutorial = GetLobbyTutorial(this);
	if (LobbyTutorial && LobbyTutorial->IsInLobbyTutorial())
	{
		LobbyTemplate->InitView(false);
	}
	else
	{
		UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
		LobbyTemplate->InitView(GameInstance && GameInstance->IsFirstShowLobby());
	}

	SetLobbyTemplateVisible(true, false);
}

void ALobbyPlayerController::OnChangeHUDWidget(EHUDWidgetType HUDWidgetType)
{
	PlayerCameraManager->StartCameraFade(1.0f, 0.0f, 0.5f, FLinearColor::Black);

	if (LobbyTemplate)
	{
		switch (HUDWidgetType)
		{
			case EHUDWidgetType::Main:
				OnShowLobby();
				break;
			case EHUDWidgetType::LobbySetting:
				SetLobbyTemplateVisible(true);
				break;
			case EHUDWidgetType::Dialogue:
			case EHUDWidgetType::Summon:
			case EHUDWidgetType::Codex:
				SetLobbyTemplateVisible(false);
				break;
			default:
				break;
		}
	}
}

void ALobbyPlayerController::OnStoryStageClear()
{
	DialoguePlayer->OnStoryStageClear();
}
