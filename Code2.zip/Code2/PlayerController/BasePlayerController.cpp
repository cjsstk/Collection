// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "BasePlayerController.h"
#include "BaseHUD.h"
#include "Engine.h"
#include "Framework/Application/SlateApplication.h"
#include "Framework/Application/IInputProcessor.h"
#include "LevelSequenceActor.h"
#include "MenuUnit.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Sections/MovieSceneSubSection.h"
#include "Tracks/MovieSceneSubTrack.h"
#include "Tutorial/BaseTutorial.h"
#include "Unit.h"

#define TouchEffectWidgetCount 5

class FQ6TouchEffectInputProcessor : public IInputProcessor
{
public:
	FQ6TouchEffectInputProcessor(APlayerControllerTouchEffect* InOwner)
		: Owner(InOwner)
	{
	}

	void SetOwner(APlayerControllerTouchEffect* InOwner)
	{
		Owner = InOwner;
	}

	virtual ~FQ6TouchEffectInputProcessor() = default;

	virtual void Tick(const float DeltaTime, FSlateApplication& SlateApp, TSharedRef<ICursor> Cursor) override
	{
	}

	virtual bool HandleMouseButtonDownEvent(FSlateApplication& SlateApp, const FPointerEvent& MouseEvent)
	{
		if (!Owner || !MouseEvent.IsTouchEvent())
		{
			return false;
		}

		Owner->OnTouchEvent(MouseEvent);
		return false;
	}

private:
	APlayerControllerTouchEffect* Owner;
};

void UTouchEffectWidget::OnTouchEvent(const FPointerEvent& MouseEvent)
{
	if (UGameViewportClient* ViewportClient = GetWorld()->GetGameViewport())
	{
		const FGeometry& CachedGeometry = ViewportClient->GetGameViewportWidget()->GetCachedGeometry();
		FVector2D NewPosition = CachedGeometry.AbsoluteToLocal(MouseEvent.GetScreenSpacePosition());
		NewPosition.X *= CachedGeometry.Scale;
		NewPosition.Y *= CachedGeometry.Scale;

		SetPositionInViewport(NewPosition.IntPoint());
	}

	OnTouchEffect();
}

/**
* APlayerControllerTouchEffect
*/
APlayerControllerTouchEffect::APlayerControllerTouchEffect(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	TouchEffectWidgets.Reset(TouchEffectWidgetCount);

	WidgetIndex = 0;
}

void APlayerControllerTouchEffect::OnTouchEvent(const FPointerEvent& MouseEvent)
{
	if (TouchEffectWidgets[WidgetIndex])
	{
		TouchEffectWidgets[WidgetIndex++]->OnTouchEvent(MouseEvent);
		WidgetIndex %= TouchEffectWidgetCount;
	}

	ABaseHUD* BaseHUD = Cast<ABaseHUD>(MyHUD);
	if (BaseHUD)
	{
		BaseHUD->OnTouched();
	}
}

void APlayerControllerTouchEffect::BeginPlay()
{
	Super::BeginPlay();
	if (!TouchEffectWidgetClass.Get())
	{
		TouchEffectWidgetClass.LoadSynchronous();
	}

	if (TouchEffectWidgetClass.Get())
	{
		for (int i = 0; i < TouchEffectWidgetCount; ++i)
		{
			auto index = TouchEffectWidgets.Add(CreateWidget<UTouchEffectWidget>(this, TouchEffectWidgetClass.Get()));
			TouchEffectWidgets[index]->AddToViewport(ZORDER_TOUCH_EFFECT);
		}

		InputProcessor = MakeShared<FQ6TouchEffectInputProcessor>(this);

		if (InputProcessor)
		{
			FSlateApplication::Get().RegisterInputPreProcessor(InputProcessor, 0);
		}
	}
}

void APlayerControllerTouchEffect::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	if (InputProcessor)
	{
		FSlateApplication::Get().UnregisterInputPreProcessor(InputProcessor);
		InputProcessor = nullptr;
	}

	for (int i = 0; i < TouchEffectWidgetCount; ++i)
	{
		if (TouchEffectWidgets[i])
		{
			TouchEffectWidgets[i]->RemoveFromParent();
		}
	}

	TouchEffectWidgets.Empty();
	Super::EndPlay(EndPlayReason);
}


/**
* Base Player Controller
*/

ABasePlayerController::ABasePlayerController(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, LevelSequence(nullptr)
	, LevelSequencePlayer(nullptr)
	, LevelSequenceActor(nullptr)
{
}

void ABasePlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();
	check(InputComponent);

#if !PLATFORM_DESKTOP
	FSlateApplication::Get().SetDragTriggerDistance(15.0f);
#endif
	float TrigDistance = FSlateApplication::Get().GetDragTriggerDistance();
	Q6JsonLog(Display, "SetupInputComponent", Q6KV("DragTriggerDistance", TrigDistance));

	InputComponent->BindAction("back_action", IE_Released, this, &ABasePlayerController::OnBackAction);
}

void ABasePlayerController::OnBackAction()
{
	ABaseTutorial* BaseTutorial = GetBaseTutorial(this);
	if (BaseTutorial && BaseTutorial->IsInTutorial())
	{
		return;
	}

	ABaseHUD* BaseHUD = Cast<ABaseHUD>(MyHUD);
	if (BaseHUD)
	{
		BaseHUD->GotoBack();
	}
}

void ABasePlayerController::StopSequencePlayer() const
{
	if (LevelSequencePlayer)
	{
		LevelSequencePlayer->Stop();
	}
}

void ABasePlayerController::PauseSequencePlayer() const
{
	if (LevelSequencePlayer && LevelSequencePlayer->IsPlaying())
	{
		LevelSequencePlayer->Pause();
	}
}

void ABasePlayerController::ResumeSequencePlayer() const
{
	if (LevelSequencePlayer && LevelSequencePlayer->IsPaused())
	{
		LevelSequencePlayer->Play();
	}
}

void ABasePlayerController::PlaySkillAnimationWithPause()
{
	if (!PlaySkillAnimation())
	{
		return;
	}

	PauseSequencePlayer();
}

bool ABasePlayerController::GetSequenceBindingIDInternal(UMovieScene* InMovieScene, const FString& InObjectName, FMovieSceneSequenceID CurSequenceID, TArray<FMovieSceneSequenceID>& InOutSequenceIDs, TArray<FMovieSceneObjectBindingID>& InOutBindingIDs)
{
	FMovieScenePossessable* FoundPossessable = InMovieScene->FindPossessable([InObjectName](FMovieScenePossessable& Possessable)
	{
		return Possessable.GetName() == InObjectName;
	});

	if (FoundPossessable)
	{
		FMovieSceneSequenceID AccumulatedSequenceID = CurSequenceID;
		for (FMovieSceneSequenceID& SequenceID : InOutSequenceIDs)
		{
			if (SequenceID == MovieSceneSequenceID::Root)
			{
				continue;
			}
			AccumulatedSequenceID = AccumulatedSequenceID.AccumulateParentID(SequenceID);
		}

		FMovieSceneObjectBindingID BindingID(FoundPossessable->GetGuid(), AccumulatedSequenceID);
		if (BindingID.IsValid())
		{
			InOutBindingIDs.Add(BindingID);
		}

		return true;
	}
	else
	{
		InOutSequenceIDs.Add(CurSequenceID);
	}

	for (const UMovieSceneTrack* MasterTrack : InMovieScene->GetMasterTracks())
	{
		const UMovieSceneSubTrack* SubTrack = Cast<const UMovieSceneSubTrack>(MasterTrack);
		if (SubTrack)
		{
			for (UMovieSceneSection* Section : SubTrack->GetAllSections())
			{
				UMovieSceneSubSection* SubSection = Cast<UMovieSceneSubSection>(Section);
				UMovieSceneSequence* SubSequence = SubSection ? SubSection->GetSequence() : nullptr;
				if (SubSequence && SubSequence->GetMovieScene())
				{
					if (!GetSequenceBindingIDInternal(SubSequence->GetMovieScene(), InObjectName, SubSection->GetSequenceID(), InOutSequenceIDs, InOutBindingIDs))
					{
						InOutSequenceIDs.Remove(SubSection->GetSequenceID());
					}
				}
			}
		}
	}

	return false;
}

TArray<FMovieSceneObjectBindingID> ABasePlayerController::GetSequenceBindingIDs(ULevelSequence* InSequence, const FString& InObjectName)
{
	TArray<FMovieSceneObjectBindingID> BindingIDs;

	if (!InSequence || InObjectName.IsEmpty())
	{
		return BindingIDs;
	}

	UMovieScene* MovieScene = InSequence->GetMovieScene();
	if (!MovieScene)
	{
		return BindingIDs;
	}

	TArray<FMovieSceneSequenceID> SequenceIDs;
	GetSequenceBindingIDInternal(MovieScene, InObjectName, MovieSceneSequenceID::Root, SequenceIDs, BindingIDs);

	return BindingIDs;
}

void ABasePlayerController::DestroySequenceActor()
{
	if (LevelSequencePlayer)
	{
		LevelSequencePlayer->OnStop.Clear();
		LevelSequencePlayer = nullptr;
	}

	if (LevelSequenceActor)
	{
		LevelSequenceActor->Destroy();
		LevelSequenceActor = nullptr;
	}
}
