// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "PlayerController/BasePlayerController.h"
#include "CMS_gen.h"
#include "LobbyObj_gen.h"
#include "LobbyPlayerController.generated.h"

class AMenuUnit;
class ALobbyTemplate;
class ADialoguePlayer;

class ALevelSequenceActor;
class ULevelSequencePlayer;

struct FVacationResult;
struct FDialogueRecord;

enum class EHUDWidgetType : uint8;
enum class ECharacterVoiceCategory : uint8;

/**
 * Lobby Player Controller
 */
UCLASS()
class Q6_API ALobbyPlayerController : public ABasePlayerController
{
	GENERATED_BODY()

public:
	ALobbyPlayerController(const FObjectInitializer& ObjectInitializer);

	virtual void BeginPlay() override;
	virtual void PlayerTick(float DeltaTime) override;
	virtual bool InputTouch(uint32 Handle, ETouchType::Type Type, const FVector2D& TouchLocation, float Force, FDateTime DeviceTimestamp, uint32 TouchpadIndex) override;
	virtual bool InputKey(FKey Key, EInputEvent EventType, float AmountDepressed, bool bGamepad) override;

	virtual void PinchStart();
	virtual void PinchEnd();
	virtual void PinchAxis(float PinchScale);

	AMenuUnit* GetLobbyUnit() const { return LobbyUnit; }
	void SetLobbyUnit(FCharacterType InCharacterType, bool bChangeView);
	void SetLobbyUnitFullView(bool bInFullView);

	bool IsPlayingPreview() const { return bPlayingPreview; }
	void PlayPreview(ECharacterVoiceCategory VoiceCategory, TSoftObjectPtr<USoundBase> VoiceSound);
	void StopPreview();

	// Sequencer event driven skill widget animation
	virtual bool PlaySkillAnimation() override;

	void SetCodexCameraFocalRegion(bool bInBlackUnit);
	void RestoreLobbyCameraFocalRegion();

	bool IsWidgetShowingView() const;

	ALobbyTemplate* GetLobbyTemplate() const { return LobbyTemplate; }
	void SetLobbyTemplate(FLobbyTemplateType InTemplateType);
	void SetLobbyTemplateVisible(bool bVisible, bool bResetView = true);
	void SetLobbyCharacters(const TArray<FCharacterId>& InCharacterIds);
	void SetLobbyCharactersVisible(bool bVisible);
	void PlayLobbyCharacterWelcomeAnimation(int32 InIndex = INDEX_NONE);
	void ClearLobbyCharactersIntermediateState();
	void SetLobbyTemplateCameraFocus(int32 InSlotIndex);
	
	void PlaySaga(FSagaType InSagaType, bool bInPrologue, bool bInReplay);
	void PlayDaily(EDayOfWeekType InDayOfWeek, bool bInReplay);
	void PlayTraining(FTrainingCenterType InTraingType, FSagaType InSagaType, bool bInPrologue, bool bInReplay);
	void PlayVacation(const FVacationResult& InResult);
	void PlayEvent(FEventContentType InEventContentType, FSagaType InSagaType, bool bInPrologue, bool bInReplay);
	void PlayContinue(const FDialogueRecord& DialogueRecord, const FDialogueType PlayingDialogueType);
	bool HasPlayableDialogue(FSagaType InSagaType);

	void GotoDialogue(int32 DialogueId);

	void OnPostLoadMap();
	void OnChangeHUDWidget(EHUDWidgetType HUDWidgetType);
	void OnStoryStageClear();

	FSimpleDelegate OnPreviewFinishedDelegate;
	FSimpleDelegate OnInputPreciseTouchedDelegate;

protected:
	virtual void SetupInputComponent();

private:
	void SetTouchBeganCharacterObject(UObject* InObject);

	bool InputDragged(const FVector2D& DeltaLocation);
	void UpdateCameraZoom(float Zoom);

	void BindSequenceActors(TArray<AActor*>& InOutActors, ULevelSequence* InLevelSequence, ALevelSequenceActor* InLevelSequenceActor);
	bool PlayPreviewUltimateSkillSequence();
	bool PlayPreviewResultSequence();

	void InitDialoguePlayer();
	void InitLobbyTemplate();
	void InitOfflineLobby();

	void OnShowLobby();

	UFUNCTION()
	void OnPreviewUltimateSkillSequenceStopped();

	UFUNCTION()
	void OnPreviewSequenceStopped();

	UFUNCTION()
	void OnPreviewFinished();

	FInertialScrollManager InputScrollManager;

	bool bIsPinching;
	float PreviousPinchScale;

	FVector2D PreviousTouchLocation;
	FVector2D TouchEnteredLocation;

	UPROPERTY(Transient)
	AMenuUnit* LobbyUnit;

	UPROPERTY(Transient)
	ACameraActor* LobbyCamera;

	UPROPERTY(Transient)
	ALobbyTemplate* LobbyTemplate;

	UPROPERTY(Transient)
	ADialoguePlayer* DialoguePlayer;

	UPROPERTY(Transient)
	UObject* TouchBeganObject;

	UPROPERTY(EditDefaultsOnly)
	float CodexBlackUnitCameraFocalRegion;
	float OriginalCameraFocalRegion;

	bool bPlayingPreview;
};
