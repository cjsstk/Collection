#pragma once

#include "CMS_gen.h"
#include "CMSTable.h"
#include "Q6GameState.h"

struct FCharacter;

class Formula
{
public:
	static int64 CalcDamage(UCMS* CMS, ECCFaction SourceFaction, ENatureType SourceNatureType, ENatureType TargetNatureType, int64 OriginDamage, FSagaType SagaType);

	static int64 CalcExtraDamage(UCMS* CMS, int64 OriginDamage, int64 ExtraDMGper);

	static int64 CalcShieldDamage(UCMS* CMS, int64 OriginDamage, int32 AddShieldDMGper);

	static int64 CalcExtraShieldDamage(UCMS* CMS, int64 OriginDamage, int32 AddShieldDMGper, int64 ExtraDMGper);

	static int64 CalcAttackDamage(const FCCCombatCubeState& InOutState, UCMS* CMS, FCCUnitState& SourceUnit, int32 AliveUnitCount, const FCCSkillId& SkillId, int64 OriginDamage, bool bChordNote);

	static int64 CalcNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, bool IsHPDMG, FSagaType SagaType);

	static int64 CalcUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, bool IsHPDMG, FSagaType SagaType);

	static int64 CalcExtraNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AliveUnitCount, int32 ExtraDMGper, bool IsHPDMG);

	static int64 CalcExtraUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AliveUnitCount, int32 ExtraDMGper, bool IsHPDMG);

	static int64 CalcShieldNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, int32 AddShieldDMGper, bool IsHPDMG);

	static int64 CalcShieldUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, int32 AddShieldDMGper, bool IsHPDMG);

	static int64 CalcExtraShieldNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 ExtraDMGper, bool IsHPDMG);

	static int64 CalcExtraShieldUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 ExtraDMGper, bool IsHPDMG);

	static int64 CalcNormalBuffDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType);

	static int64 CalcRaidNormalBuffDamage(UCMS* CMS, const TArray<int32>& Attributes, ENatureType SourceNature,
		FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType);

	static int64 CalcUltimateBuffDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType);

	static int64 CalcBuffHeal(UCMS* CMS, FCCUnitState& SourceUnit, int32 TurnHeal, int32 TurnHealper, int32 AliveUnitCount);

	static int64 CalcRaidBuffHeal(UCMS* CMS, const TArray<int32>& Attributes, int32 TurnHeal, int32 TurnHealper, int32 AliveUnitCount);

	static int32 CalcTotalCri(FCCUnitState& OffenseUnit);

	static int64 CalcCriDamage(UCMS* CMS, FCCUnitState& OffenseUnit, int64 PreciseDamage, int32 AliveUnitCount, ESkillCategory Category);

	static int64 CalcBloodSucking(FCCUnitState& OffenseUnit, int64 PerciseDamage);

	static int32 CalcAddUA(UCMS* CMS, FCCUnitState& TargetUnit, int32 OriginAddUA, int32 SkillSequence, int32 AliveUnitCount, ESkillCategory BornCategory);

	static int32 CalcAttackUA(const FCCCombatCubeState& InOutState, UCMS* CMS, FCCUnitState& SourceUnit, int32 SkillSequence, int32 AliveUnitCount, const FCCSkillId& SkillId, bool bChordNote);

	static int32 CalcBeatenUA(UCMS* CMS, FCCUnitState& DefenseUnit, int64 PreciseDamage, int32 AliveUnitCount);

	static int32 CalcKillTargetUABonus(UCMS* CMS, FCCUnitState& SourceUnit, int32 OriginAddUA, int32 SkillSequence, int32 AliveUnitCount);

	static int32 CalcAddSA(UCMS* CMS, FCCUnitState& TargetUnit, int32 OriginAddSA, int32 SkillSequence, int32 AliveUnitCount, ESkillCategory BornCategory);

	static int32 CalcAttackSA(const FCCCombatCubeState& InOutState, UCMS* CMS, FCCUnitState& SourceUnit, int32 SkillSequence, int32 AliveUnitCount, const FCCSkillId& SkillId, bool bChordNote);

	static int32 CalcBeatenSA(UCMS* CMS, FCCUnitState& TargetUnit, int64 PreciseDamage, int64 DefenseUnitRemainHP, int32 AliveUnitCount);

	static int32 CalcKillTargetSABonus(UCMS* CMS, FCCUnitState& SourceUnit, int32 OriginAddUA, int32 SkillSequence, int32 AliveUnitCount);

	static int64 CalcSkillHeal(UCMS* CMS, FCCUnitState& SourceUnit, int32 SkillHealper, int32 AliveUnitCount);

	static int64 CalcRaidSkillHeal(UCMS* CMS, const TArray<int32>& Attributes, int32 SkillHealper, int32 AliveUnitCount);

	static int32 CalcOverKill(const FCCCombatCubeState& InOutState, UCMS* CMS,
		FCCUnitState& SourceUnit, int64 DefenseUnitRemainHealth, int64 Damage, int32 AliveUnitCount, const FCCSkillId& SkillId, bool bChordNote, ESkillCategory BornCategory);
	static int32 CalcOverKillNoDamage(UCMS* CMS, FCCUnitState& Unit, int32 InOverKill, ESkillCategory BornCategory);

	static int64 InterpolatedBySkillLevelOrTier(int32 InSkillLevelOrTier, int64 InMin, int64 InMax, ESkillCategory InCategory);

	static int64 InterpolatedByTier(int32 Tier, int64 InMin, int64 InMax);

	static ENatureRelationType GetNatureRelationType(UCMS* CMS, ECCFaction SourceFaction, ENatureType SourceNatureType, ENatureType TargetNatureType, FSagaType SagaType);

	static int64 GetShieldDMGper(UCMS* CMS, int32 ShieldWeakPoint, ESkillCategory Category, ESkillNote Note, int32 AliveUnitCount);

private:
	static int64 CalcTotalAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType);

	static int64 CalcExtraAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 ExtraDMGper);

	static int64 CalcShieldAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 SkillSequence, int32 AliveUnitCount);

	static int64 CalcExtraShieldAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 ExtraDMGper);

	static int64 CalcTotalDef(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 AliveUnitCount);

	static int32 GetNatureBonus(UCMS* CMS, ECCFaction SourceFaction, ENatureType SourceNatureType, ENatureType TargetNatureType, FSagaType SagaType);

	static int64 CalcTotalTurnAtk(UCMS* CMS, FCCUnitState& SourceUnit, FCCUnitState& TargetUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType);

	static int64 CalcRaidTotalTurnAtk(UCMS* CMS, const TArray<int32>& Attributes, ECCFaction SourceFaction, ENatureType SourceNature,
		FCCUnitState& TargetUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType);

	static int64 CalcBuffHeal(UCMS* CMS, int64 Atk, int64 AtkVary, int64 AtkVaryper, int64 HealVary, int64 HealVaryper,
		int32 TurnHeal, int32 TurnHealper, int32 AliveUnitCount);

	static int64 CalcNormalBuffDamage(int64 TotalTurnAtk, int64 TotalDef, int64 DamageVary, int64 DamageVaryper,
		int32 TurnAtkper);

	static int64 CalcSkillHeal(UCMS* CMS, int64 Atk, int64 AtkVary, int64 AtkVaryper, int64 HealVary, int64 HealVaryper,
		int32 SkillHealper, int32 AliveUnitCount);
};

class Attribute
{
public:
	static void GetCharacterAttribute(UCMS* CMS, const FCharacterInfo& CharacterInfo, int64& OutMaxHealth, int64& OutAtk, int64& OutDef);
	static void GetUnitAttribute(UCMS* CMS, EAttributeCategory InRatioType, FUnitType InUnitType, int32 InLevel, EItemGrade InGrade, const FCMSAdditionalPointRow* InAdditionalPoint,
		int64& OutMaxHealth, int64& OutAtk, int64& OutDef);
	static void GetRelicAttribute(UCMS* CMS, FRelicType InType, int32 InLevel, int32 InTier, EItemGrade InGrade, int64& OutMaxHealth, int64& OutAtk, int64& OutDef);
	static void GetSculptureAttribute(UCMS* CMS, FSculptureType InType, int32 InLevel, int32 InTier, EItemGrade InGrade, int64& OutMaxHealth, int64& OutAtk, int64& OutDef);
};
