// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CCTypes.h"
#include "Chronicle/Chronicle.h"
#include "CMS/CMSTable.h"
#include "Delegates/MulticastDelegateBase.h"
#include "Delegates/DelegateCombinations.h"
#include "GameFramework/Actor.h"
#include "Q6GameState.h"
#include "Utils/Random.h"
#include "JsonObjectConverter.h"
#include "CombatCube.generated.h"

struct FResError;
struct FL2CCombatCubeActionResp;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCombatCubeStateChanged, const FCCCombatCubeState&, State);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FOnCombatCubeEvent, const UCCEvent*, Event);
DECLARE_DELEGATE_TwoParams(FOnCCStateGot, FCCUnitId /*req unitid*/, FCombatState /* rep state */);

UENUM()
enum class ECombatCubeMode : uint8
{
	Normal,
	Verification
};

struct FActionContext
{
	FMT19937Uint32* MT19937;
	FOnCombatCubeEvent& OnEvent;
};

UCLASS(BlueprintType)
class UCCCombatCubeStore : public UObject
{
	GENERATED_BODY()

public:
	UCCCombatCubeStore(const FObjectInitializer& ObjectInitializer);
	virtual ~UCCCombatCubeStore();

	void SetRandomSeed(const FCCCombatSeed& CombatSeed);
	void InitChronicle(FSagaType InSagaType);
	void SaveDevChronicle();
	void SaveOngoingChronicle();
	void SetRaidInfoToChronicle(FRaidId InRaidId);
	void BindOnEvent();
	void SetMode(ECombatCubeMode InMode) { CombatCubeMode = InMode; }

	bool IsTickableMode() const;
	bool IsSavingChronicleMode() const;

	void Dispatch(const struct FCCAction& Action);

	const FCCCombatCubeState& GetState() const { return CombatCubeState; }
	const FString GetChronicleJson() const { return Chronicle.ToJson(); }
	const ECombatCubeMode GetMode() const { return CombatCubeMode; }

	UPROPERTY(BlueprintAssignable, Category = "Event")
	FOnCombatCubeStateChanged OnChanged;

	UPROPERTY(BlueprintAssignable, Category = "Event")
	FOnCombatCubeEvent OnEvent;

	void ReqCCState(const FCCUnitId& InSkillNoteUnitId, FOnCCStateGot ResponsCB);
	bool RestoreCCState(const FString& StateStr, FCCCombatCubeState& OutState);
private:

	UPROPERTY()
	FCCCombatCubeState CombatCubeState;

	UFUNCTION()
	void OnCombatCubeEvent(const UCCEvent* Event);

	FMT19937Uint32* MT19937;

	UPROPERTY()
	FChronicle Chronicle;

	UPROPERTY()
	ECombatCubeMode CombatCubeMode;

	void SendAction(const FCCAction& Action);
	void OnRecvEvent(const FResError* Error, const FL2CCombatCubeActionResp& Res);
};

/*
 * ACombatCube
 * Rule-based combat simulator.(actor. but it's not a big deal)
 */
class UDebugCombatWidget;

UCLASS()
class Q6_API ACombatCube : public AActor
{
	GENERATED_BODY()

public:
	ACombatCube(const FObjectInitializer& ObjectInitializer);

	void SetMode(ECombatCubeMode InMode);
	void SetRaidInfoToChronicle(FRaidId InRaidId);

	bool IsTickableMode() const;
	bool IsSavingChronicleMode() const;
	bool IsBossRewardWave(const FCCCombatCubeState& InCubeState) const;

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	UFUNCTION(BlueprintCallable)
	void SelectTarget(FCCUnitId UnitId);

	UFUNCTION(BlueprintCallable)
	void UseSkill(FCCUnitId UnitId, FCCSkillId SkillId, int32 TurnCount);

	void TurnAction(FCCUnitId UnitId, FCCSkillId SkillId, int32 TurnCount);

	UFUNCTION(BlueprintCallable)
	void UseArtifact(FCCUnitId UnitId, int32 Index);

	UFUNCTION(BlueprintCallable)
	void UseWipeoutContinue(int32 InResurrectionCount, bool bGemContinue);

	UFUNCTION(BlueprintCallable)
	void Withdraw();

	UFUNCTION(BlueprintCallable)
	void UsePet(FCCUnitId UnitId, FCCSkillId SkillId);

	UFUNCTION(BlueprintCallable)
	void ProceedToNextTurn();

	UFUNCTION(BlueprintCallable)
	void InitCombatCube(const FCCCombatSeed& Seed);

	UFUNCTION()
	void InitCombatMission(const TArray<FMissionType>& InCombatWeeklyMission
		, const TArray<FCCCharacterMissionInfo>& InCombatCharacterMission);

	UFUNCTION()
	void UseRaidTurnSkills();

	UFUNCTION()
	void AddRaidTurnSkills(const TArray<FCharSkill>& RaidTurnSkills, const TArray<FCharSkill>& RaidSupportSkills);

	UFUNCTION(BlueprintCallable)
	UCCCombatCubeStore* GetStore() const { return Store; }

	UFUNCTION(BlueprintCallable)
	const FCCCombatCubeState& GetState() const { return Store->GetState(); }

	UFUNCTION(BlueprintCallable)
	void SaveChronicle();

	UFUNCTION(BlueprintCallable)
	void SaveOngoingChronicle();

	UFUNCTION(BlueprintCallable)
	ECombatCubeMode GetMode() const;

	// Dev functions.
	void KillAllEnemies();
	void WinGame();
	void KillTargetUnit();
	void RebirthTargetUnit();
	void ToggleNoDamage(UDebugCombatWidget* DebugCombatWidget);
	void ToggleImmune(UDebugCombatWidget* DebugCombatWidget);
	void SetTargetUnitAttributeCheatValue(EUnitAttribute InUnitAttribute, int32 InValue);
	void RevertTargetUnitAttributeCheatValue(EUnitAttribute InUnitAttribute);
	void CheatFillAlliesUASA();
	void CheatUA(int32 InUA);
	void CheatFillUAForTutorial(FCCUnitId InTargetUnitId);
	void CheatFillSAForTutorial(FCCUnitId InTargetUnitId);
	void CheatSA(int32 InSA);
	void CheatHealth(int32 InHealth);
	void CheatOverKill(int32 InOverKill);
	void CheatBuff(int32 InBuffType, bool bInUltimate, int32 InDuration);
	void DespawnUnit(FCCUnitId InUnitId);
	void CheatReplaceUnit(FCCUnitId FromUnitId, FUnitType ToUnitType, ESpawnReason InReason);
	void CheatReplaceUnit(int32 InUnitType);
	void CheatResetCooldown(int32 InSkillId);
	void CheatFixSkillNote(int32 Slot, ESkillNote Note, int32 Index);
	void CheatShuffleSkillNote(int32 Slot);
	// Never use this function for CombatPresenter or Game UI, but only for dev.
	void GetTargetCCUnitState(UDebugCombatWidget* DebugCombatWidget);

	void UpdateFinishCondition(FCCCombatCubeState& CubeState) const;

private:
	void UpdatePhase(FCCCombatCubeState& CubeState);

	void MonsterUseTurnSkill(FCCCombatCubeState& CubeState, FCCUnitState* UnitState);
	void MonsterUseTurnSkillByPattern(FCCCombatCubeState& CubeState, FCCUnitState* UnitState);

	bool MonsterUltimate(FCCCombatCubeState& CubeState, FCCUnitState* UnitState);
	void MonsterNormal(FCCCombatCubeState& CubeState, FCCUnitState* UnitState);
	bool MonsterUltimateByPattern(FCCCombatCubeState& CubeState, FCCUnitState* UnitState);
	bool MonsterNormalByPattern(FCCCombatCubeState& CubeState, FCCUnitState* UnitState);

	void MonsterAttackPass(FCCUnitState* UnitState);

	UPROPERTY()
	UCCCombatCubeStore* Store;

	UPROPERTY()
	UCMS* CMS;
};
