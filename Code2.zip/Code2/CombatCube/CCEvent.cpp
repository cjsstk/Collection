#include "CCEvent.h"
#include "Q6Log.h"

void UCCUnitHealthChangedEvent::SetEvent(FCCUnitId InUnitId, FCCSkillId InSkillId, int64 InOldHealth, int64 InNewHealth, int64 InAddedHealth, EHealthChangeReason InReason)
{
	UnitId = InUnitId;
	SkillId = InSkillId;
	OldHealth = InOldHealth;
	NewHealth = InNewHealth;
	AddedHealth = InAddedHealth;
	Reason = InReason;
}

void UCCSkillEffectEvent::CreateDamageEventPerUnit(FCCUnitState& TargetUnit, int64 BaseDamage, int64 ExtraDamage, int64 ShieldDamage, int64 ExtraShieldDamage, bool bShieldWeakPoint,
	int32 OverKillPoint, EHealthChangeReason Reason, bool bNoDamage, bool bCritical /* = false */, bool bCCDefence /* = false */)
{
	if (bNoDamage)
	{
		Q6JsonLog(Warning, "cheat No Damage",
			Q6KV("base damage", BaseDamage), Q6KV("extra damage", ExtraDamage),
			Q6KV("shield damage", ShieldDamage), Q6KV("extra shield damage", ExtraShieldDamage));
		BaseDamage = 0;
		ExtraDamage = 0;
		ShieldDamage = 0;
		ExtraShieldDamage = 0;
	}
	if (bCCDefence)
	{
		Q6JsonLog(Display, "Dodge or Invincible No Damage",
			Q6KV("base damage", BaseDamage), Q6KV("extra damage", ExtraDamage),
			Q6KV("shield damage", ShieldDamage), Q6KV("extra shield damage", ExtraShieldDamage));
		BaseDamage = 0;
		ExtraDamage = 0;
		ShieldDamage = 0;
		ExtraShieldDamage = 0;
	}

	UCCSkillEffectHealthEvent* EffectDamageEvent = NewObject<UCCSkillEffectHealthEvent>();
	int64 NewHealth = FMath::Clamp(TargetUnit.Health - (BaseDamage + ExtraDamage), 0LL, TargetUnit.GetAttributeValue(EUnitAttribute::MaxHealth));
	EffectDamageEvent->SetEvent(TargetUnit.UnitId, TargetUnit.Health, NewHealth, -BaseDamage, -ExtraDamage, -ShieldDamage, -ExtraShieldDamage, bShieldWeakPoint,
		OverKillPoint, Reason, bCritical, bCCDefence);
	DamageEvents.Add(MoveTemp(EffectDamageEvent));

	TargetUnit.Health = NewHealth;
}

void UCCSkillEffectEvent::CreateHealEventPerUnit(const UCMS* CMS, FCCUnitState& TargetUnit, int64 Heal, EHealthChangeReason Reason)
{
	UCCSkillEffectHealthEvent* EffectHealEvent = NewObject<UCCSkillEffectHealthEvent>();

	int64 NewHealth = FMath::Clamp(TargetUnit.Health + Heal, 0LL, TargetUnit.GetAttributeValue(EUnitAttribute::MaxHealth));
	if (TargetUnit.GetCrowdControlState(CMS, ECrowdControl::HealBlock) > 0)
	{
		Q6JsonLog(Display, "heal block", Q6KV("unit", TargetUnit.UnitType));
		NewHealth = TargetUnit.Health;
		Reason = EHealthChangeReason::HealBlock;
	}

	EffectHealEvent->SetEvent(TargetUnit.UnitId, TargetUnit.Health, NewHealth, NewHealth - TargetUnit.Health, 0, 0, 0, false, 0, Reason);
	HealEvents.Add(MoveTemp(EffectHealEvent));

	TargetUnit.Health = NewHealth;
}

void UCCDamageBuffPerUnit::SetEvent(ENatureRelationType InNatureRelationType, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType,
	int64 InOldHealth, int64 InNewHealth, int64 InBaseDamage, int64 InShieldDamage, bool bInDodged)
{
	NatureRelationType = InNatureRelationType;
	TargetUnitId = InTargetUnitId;
	BuffType = InBuffType;
	BuffEffectType = InBuffEffectType;
	OldHealth = InOldHealth;
	NewHealth = InNewHealth;
	BaseDamage = InBaseDamage;
	ShieldDamage = InShieldDamage;
	bDodged = bInDodged;
}

void UCCDamageBuffEvent::AppendEvent(ENatureRelationType InNatureRelationType, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType,
	int32 InOldHealth, int32 InNewHealth, int32 InBaseDamage, int32 InShieldDamage, bool bInCCDefence)
{
	UCCDamageBuffPerUnit* Event = NewObject<UCCDamageBuffPerUnit>();
	Event->SetEvent(InNatureRelationType, InTargetUnitId, InBuffType, InBuffEffectType, InOldHealth, InNewHealth, InBaseDamage, InShieldDamage, bInCCDefence);

	Events.Add(Event);
}

void UCCHealBuffPerUnit::SetEvent(FCCUnitId InSourceUnitId, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType, int32 InOldHealth, int32 InNewHealth, int32 InHeal, EHealthChangeReason InReason)
{
	SourceUnitId = InSourceUnitId;
	TargetUnitId = InTargetUnitId;
	BuffType = InBuffType;
	BuffEffectType = InBuffEffectType;
	OldHealth = InOldHealth;
	NewHealth = InNewHealth;
	Heal = InHeal;
	Reason = InReason;
}

void UCCHealBuffEvent::AppendEvent(FCCUnitId InSourceUnitId, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType, int32 InOldHealth, int32 InNewHealth, int32 InHeal, EHealthChangeReason InReason)
{
	UCCHealBuffPerUnit* Event = NewObject<UCCHealBuffPerUnit>();
	Event->SetEvent(InSourceUnitId, InTargetUnitId, InBuffType, InBuffEffectType, InOldHealth, InNewHealth, InHeal, InReason);

	Events.Add(Event);
}

void UCCSkillEffectHealthEvent::SetEvent(FCCUnitId InUnitId, int64 InOldHealth, int64 InNewHealth, int64 InAddedBaseHealth, int64 InAddedExtraHealth, int64 InShieldDamage, int64 InExtraShieldDamage, bool bInShieldWeakPoint,
	int32 InAddedOverKill, EHealthChangeReason InReason, bool bInCritical, bool bInDodged)
{
	TargetUnitId = InUnitId;
	OldHealth = InOldHealth;
	NewHealth = InNewHealth;
	AddedBaseHealth = InAddedBaseHealth;
	AddedExtraHealth = InAddedExtraHealth;
	ShieldDamage = InShieldDamage;
	ExtraShieldDamage = InExtraShieldDamage;
	IsShieldWeakPoint = bInShieldWeakPoint;
	AddedOverKill = InAddedOverKill;
	Reason = InReason;
	IsCritical = bInCritical;
	IsDodged = bInDodged;
}
