#pragma once
#include "Q6GameState.h"
#include "CMS_gen.h"
#include "ccStruct_gen.h"
#include "CCAction.generated.h"

USTRUCT()
struct FCCInitCombatCubeAction : public FCCInitCombatCubeActionBase
{
	GENERATED_BODY()

	FCCInitCombatCubeAction() {}
	explicit FCCInitCombatCubeAction(const FCCCombatSeed& InSeed) { Seed = InSeed; }

	virtual ~FCCInitCombatCubeAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::InitCombatCube; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCInitCombatCubeAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCInitCombatCubeAction(Seed); }
};

USTRUCT()
struct FCCStartWaveAction : public FCCStartWaveActionBase
{
	GENERATED_BODY()

	FCCStartWaveAction() { WaveIndex = 0; }
	explicit FCCStartWaveAction(int32 InWave) { WaveIndex = InWave; }

	virtual ~FCCStartWaveAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::StartWave; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCStartWaveAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCStartWaveAction(WaveIndex); }
};

USTRUCT()
struct FCCPassPhaseAction : public FCCPassPhaseActionBase
{
	GENERATED_BODY()

	virtual ~FCCPassPhaseAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::PassPhase; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCPassPhaseAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCPassPhaseAction(); }
};

USTRUCT()
struct FCCSelectTargetAction : public FCCSelectTargetActionBase
{
	GENERATED_BODY()

	FCCSelectTargetAction() {}
	explicit FCCSelectTargetAction(FCCUnitId InTargetUnitId) { TargetUnitId = InTargetUnitId; }
	virtual ~FCCSelectTargetAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::SelectTarget; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCSelectTargetAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCSelectTargetAction(TargetUnitId); }
};

USTRUCT()
struct FCCUseSkillAction : public FCCUseSkillActionBase
{
	GENERATED_BODY()

	FCCUseSkillAction() { IsPlayerUseSkill = false; }
	explicit FCCUseSkillAction(FCCUnitId InUnitId, FCCSkillId InSkillId, bool bInPlayerUseSkill, int32 InTurnCount, EPreferTarget InPreferTarget, bool bInPattern) {
		UnitId = InUnitId;
		SkillId = InSkillId;
		IsPlayerUseSkill = bInPlayerUseSkill;
		TurnCount = InTurnCount;
		PreferTarget = InPreferTarget;
		IsPattern = bInPattern;
	}

	virtual ~FCCUseSkillAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::UseSkill; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCUseSkillAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCUseSkillAction(UnitId, SkillId, IsPlayerUseSkill, TurnCount, PreferTarget, IsPattern); }

	FCCUnitId GetPreferTargetId(const FCCCombatCubeState& InOutState, EPreferTarget PreferTarget) const;
};

USTRUCT()
struct FCCUseTurnAction: public FCCUseTurnActionBase
{
	GENERATED_BODY()

	FCCUseTurnAction() { IsPlayerUseSkill = false; }
	explicit FCCUseTurnAction(FCCUnitId InUnitId, FCCSkillId InSkillId, bool bInPlayerUseSkill, int32 InTurnCount, EPreferTarget InPreferTarget, bool bInPattern) {
		UnitId = InUnitId;
		SkillId = InSkillId;
		IsPlayerUseSkill = bInPlayerUseSkill;
		TurnCount = InTurnCount;
		PreferTarget = InPreferTarget;
		IsPattern = bInPattern;
	}

	virtual ~FCCUseTurnAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::UseTurnAction; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCUseTurnAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override {}
	virtual FCCAction* Clone() const override { return new FCCUseTurnAction(UnitId, SkillId, IsPlayerUseSkill, TurnCount, PreferTarget, IsPattern); }
};

USTRUCT()
struct FCCInitMissionAction : public FCCAction
{
	GENERATED_BODY()

	FCCInitMissionAction() {}
	explicit FCCInitMissionAction(const TArray<FMissionType>& InCombatWeeklyMission
		, const TArray<FCCCharacterMissionInfo>& InCombatCharacterMission)
		: CombatWeeklyMission(InCombatWeeklyMission)
		, CombatCharacterMission(InCombatCharacterMission)
	{}
	virtual ~FCCInitMissionAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::InitCombatWeeklyMission; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCInitMissionAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCInitMissionAction(); }

	UPROPERTY()
	TArray<FMissionType> CombatWeeklyMission;

	UPROPERTY()
	TArray<FCCCharacterMissionInfo> CombatCharacterMission;
};

USTRUCT()
struct FCCUseRaidTurnSkillAction : public FCCUseRaidTurnSkillBase
{
	GENERATED_BODY()

	FCCUseRaidTurnSkillAction() {}
	virtual ~FCCUseRaidTurnSkillAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::UseRaidTurnSkill; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCUseRaidTurnSkillAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCUseSkillAction(); }
};

USTRUCT()
struct FCCUseArtifactAction : public FCCUseArtifactActionBase
{
	GENERATED_BODY()

	FCCUseArtifactAction() { Index = 0; }
	explicit FCCUseArtifactAction(FCCUnitId InUnitId, int32 InIndex) {
		TargetUnitId = InUnitId;
		Index = InIndex;
	}

	virtual ~FCCUseArtifactAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::UseArtifact; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCUseArtifactAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCUseArtifactAction(TargetUnitId, Index); }
};

USTRUCT()
struct FCCWipeoutContinue : public FCCWipeoutContinueBase
{
	GENERATED_BODY()

	FCCWipeoutContinue() {
		IsGemContinue = false;
		ResurrectionCount = 0;
	}
	explicit FCCWipeoutContinue(int32 InResurrectionCount, bool InbGemRebirth) {
		IsGemContinue = InbGemRebirth;
		ResurrectionCount = InResurrectionCount;
	}

	virtual ~FCCWipeoutContinue() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::WipeoutContinue; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCWipeoutContinue::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCWipeoutContinue(ResurrectionCount, IsGemContinue); }

	FCCSkillState* GetSkill(FCCCombatCubeState& InOutState) const;
	int32 GetHealthPermil(FCCCombatCubeState& InOutState) const;
};

USTRUCT()
struct FCCUsePetAction : public FCCUsePetActionBase
{
	GENERATED_BODY()

	FCCUsePetAction() {}
	explicit FCCUsePetAction(FCCUnitId InUnitId, FCCSkillId InSkillId) {
		TargetUnitId = InUnitId;
		SkillId = InSkillId;
	}

	virtual ~FCCUsePetAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::UsePet; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCUsePetAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCUsePetAction(TargetUnitId, SkillId); }
};

USTRUCT()
struct FCCUnitRetreatAction : public FCCUnitRetreatActionBase
{
	GENERATED_BODY()

	FCCUnitRetreatAction() {}
	explicit FCCUnitRetreatAction(FCCUnitId InUnitId) {
		UnitId = InUnitId;
	}

	virtual ~FCCUnitRetreatAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::RetreatUnit; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCUnitRetreatAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCUnitRetreatAction(UnitId); }
};

USTRUCT()
struct FCCChangePhaseTo : public FCCChangePhaseToBase
{
	GENERATED_BODY()

	FCCChangePhaseTo() {
		ChangePhase = ECCTurnPhase::Prepare;
	}
	explicit FCCChangePhaseTo(ECCTurnPhase InChangePhase) {
		ChangePhase = InChangePhase;
	}
	virtual ~FCCChangePhaseTo() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::ChangePhaseTo; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCChangePhaseTo::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCChangePhaseTo(ChangePhase); }
};

USTRUCT()
struct FCCAllyWipeoutAction : public FCCAllyWipeoutActionBase
{
	GENERATED_BODY()

	FCCAllyWipeoutAction() {}
	virtual ~FCCAllyWipeoutAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::AllyWipeout; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCAllyWipeoutAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCAllyWipeoutAction(); }
};

USTRUCT()
struct FCCEndGameAction : public FCCEndGameActionBase
{
	GENERATED_BODY()

	FCCEndGameAction() {
		Result = ECCResult::Unknown;
		EndReason = ECCEndReason::None;
	}
	explicit FCCEndGameAction(ECCResult InResult, ECCEndReason InEndReason) {
		Result = InResult;
		EndReason = InEndReason;
	}
	virtual ~FCCEndGameAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::EndGame; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCEndGameAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCEndGameAction(Result, EndReason); }
};

USTRUCT()
struct FCCCheatSpawnSubUnitAction : public FCCCheatSpawnSubUnitActionBase
{
	GENERATED_BODY()

	FCCCheatSpawnSubUnitAction() {}
	explicit FCCCheatSpawnSubUnitAction(FCCSpawnUnitParam InSpawnUnit) {
		SpawnUnit = InSpawnUnit;
	}
	virtual ~FCCCheatSpawnSubUnitAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatSpawnSubUnit; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatSpawnSubUnitAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatSpawnSubUnitAction(SpawnUnit); }
};

USTRUCT()
struct FCCCheatCreateBuffAction : public FCCCheatCreateBuffActionBase
{
	GENERATED_BODY()

	FCCCheatCreateBuffAction() {
		BuffType = 0;
		IsUltimate = false;
		Duration = 0;
	}
	explicit FCCCheatCreateBuffAction(FCCUnitId InUnitId, FCCUnitId InTargetUnitId, int32 InBuffType, bool bInUltimate, int32 InDuration) {
		UnitId = InUnitId;
		TargetUnitId = InTargetUnitId;
		BuffType = InBuffType;
		IsUltimate = bInUltimate;
		Duration = InDuration;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatCreateBuff; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatCreateBuffAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatCreateBuffAction(UnitId, TargetUnitId, BuffType, IsUltimate, Duration); }
};

USTRUCT()
struct FCCCheatKillUnitAction : public FCCCheatKillUnitActionBase
{
	GENERATED_BODY()

	FCCCheatKillUnitAction() {}
	explicit FCCCheatKillUnitAction(FCCUnitId InUnitId) {
		UnitId = InUnitId;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatKillUnit; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatKillUnitAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatKillUnitAction(UnitId); }
};

USTRUCT()
struct FCCCheatRebirthUnitAction : public FCCCheatRebirthUnitActionBase
{
	GENERATED_BODY()

	FCCCheatRebirthUnitAction() {}
	explicit FCCCheatRebirthUnitAction(FCCUnitId InUnitId) {
		UnitId = InUnitId;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatRebirthUnit; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatRebirthUnitAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatRebirthUnitAction(UnitId); }
};

USTRUCT()
struct FCCCheatGameFlagAction : public FCCCheatGameFlagActionBase
{
	GENERATED_BODY()

	FCCCheatGameFlagAction() {
		GameFlag = EGameFlags::Max;
		FlagValue = 0;
	}
	explicit FCCCheatGameFlagAction(EGameFlags InGameFlag, int32 InValue) {
		GameFlag = InGameFlag;
		FlagValue = InValue;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatGameFlag; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatGameFlagAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatGameFlagAction(GameFlag, FlagValue); }
};

USTRUCT()
struct FCCCheatUnitAttributeAction : public FCCCheatUnitAttributeActionBase
{
	GENERATED_BODY()

	FCCCheatUnitAttributeAction() {
		UnitAttribute = EUnitAttribute::AtkVary;
		IsCheat = true;
		CheatValue = 0;
	}
	explicit FCCCheatUnitAttributeAction(FCCUnitId InUnitId, EUnitAttribute InAttribute, bool bInCheat, int32 InCheatValue) {
		UnitId = InUnitId;
		UnitAttribute = InAttribute;
		IsCheat = bInCheat;
		CheatValue = InCheatValue;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatUnitAttribute; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatUnitAttributeAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatUnitAttributeAction(UnitId, UnitAttribute, IsCheat, CheatValue); }
};

USTRUCT()
struct FCCCheatUAAction : public FCCCheatUAActionBase
{
	GENERATED_BODY()

	FCCCheatUAAction() { CheatUA = 0; }
	explicit FCCCheatUAAction(FCCUnitId InUnitId, int32 InUA) {
		UnitId = InUnitId;
		CheatUA = InUA;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatUA; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatUAAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatUAAction(UnitId, CheatUA); }
};

USTRUCT()
struct FCCCheatSAAction : public FCCCheatSAActionBase
{
	GENERATED_BODY()

	FCCCheatSAAction() {
		CheatSA = 0;
	}
	explicit FCCCheatSAAction(FCCUnitId InUnitId, int32 InSA) {
		UnitId = InUnitId;
		CheatSA = InSA;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatSA; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatSAAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatSAAction(UnitId, CheatSA); }
};

USTRUCT()
struct FCCCheatHealthAction : public FCCCheatHealthActionBase
{
	GENERATED_BODY()

	FCCCheatHealthAction() { CheatHealth = 0; }
	explicit FCCCheatHealthAction(FCCUnitId InUnitId, int32 InHealth) {
		UnitId = InUnitId;
		CheatHealth = InHealth;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatHealth; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatHealthAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatHealthAction(UnitId, CheatHealth); }
};

USTRUCT()
struct FCCCheatOverKillAction : public FCCCheatOverKillActionBase
{
	GENERATED_BODY()

	FCCCheatOverKillAction() { CheatOverKill = 0; }
	explicit FCCCheatOverKillAction(FCCUnitId InUnitId, int32 InOverKill) {
		UnitId = InUnitId;
		CheatOverKill = InOverKill;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatOverKill; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatOverKillAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatOverKillAction(UnitId, CheatOverKill); }
};

USTRUCT()
struct FCCCheatDespawnUnitAction : public FCCCheatDespawnUnitActionBase
{
	GENERATED_BODY()

	FCCCheatDespawnUnitAction() {}
	explicit FCCCheatDespawnUnitAction(FCCUnitId InUnitId) {
		UnitId = InUnitId;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatDespawnUnit; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatDespawnUnitAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatDespawnUnitAction(UnitId); }
};

USTRUCT()
struct FCCCheatCooldownAction : public FCCCheatCooldownActionBase
{
	GENERATED_BODY()

	FCCCheatCooldownAction() {}
	explicit FCCCheatCooldownAction(FCCUnitId InUnitId, int32 InSkillType) {
		UnitId = InUnitId;
		SkillType = InSkillType;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatCooldown; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatCooldownAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatCooldownAction(UnitId, SkillType); }
};

USTRUCT()
struct FCCCheatEndGameAction : public FCCCheatEndGameActionBase
{
	GENERATED_BODY()

	FCCCheatEndGameAction(ECCResult InResult) {
		Result = InResult;
	}
	explicit FCCCheatEndGameAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatEndGame; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatEndGameAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatEndGameAction(); }
};

USTRUCT()
struct FCCCheatFixSkillNoteAction : public FCCCheatFixSkillNoteActionBase
{
	GENERATED_BODY()

	FCCCheatFixSkillNoteAction() {}
	explicit FCCCheatFixSkillNoteAction(int32 InSlot, ESkillNote InNote, int32 InIndex) {
		Slot = InSlot;
		Note = InNote;
		Index = InIndex;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatFixSkillNote; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatFixSkillNoteAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatFixSkillNoteAction(Slot, Note, Index); }
};

USTRUCT()
struct FCCCheatSkillNoteShuffleAction : public FCCCheatSkillNoteShuffleActionBase
{
	GENERATED_BODY()

	FCCCheatSkillNoteShuffleAction() {}
	explicit FCCCheatSkillNoteShuffleAction(int32 InSlot) {
		Slot = InSlot;
	}

	virtual ECCActionType GetActionType() const override { return ECCActionType::CheatSkillNoteShuffle; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCCheatSkillNoteShuffleAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCCheatSkillNoteShuffleAction(Slot); }
};

USTRUCT()
struct FCCAddRaidTurnSkillAction : public FCCAction
{
	GENERATED_BODY()

	FCCAddRaidTurnSkillAction() {}

	explicit FCCAddRaidTurnSkillAction(const TArray<FCharSkill>& InRaidTurnSkills, const TArray<FCharSkill>& InRaidSupportSkills)
		: RaidTurnSkills(InRaidTurnSkills), RaidSupportSkills(InRaidSupportSkills) {}
	virtual ~FCCAddRaidTurnSkillAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::AddRaidTurnSkill; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCAddRaidTurnSkillAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCAddRaidTurnSkillAction(RaidTurnSkills, RaidSupportSkills); }

	UPROPERTY()
	TArray<FCharSkill> RaidTurnSkills;

	UPROPERTY()
	TArray<FCharSkill> RaidSupportSkills;
};

USTRUCT()
struct FCCChangeCombatMultiSideAction : public FCCAction
{
	GENERATED_BODY()

	FCCChangeCombatMultiSideAction() {}

	explicit FCCChangeCombatMultiSideAction(const ECombatMultiSide& InCurrentCombatSide, bool bInClearWave)
		: CurrentCombatSide(InCurrentCombatSide), bClearWave(bInClearWave) {}
	virtual ~FCCChangeCombatMultiSideAction() {}

	virtual ECCActionType GetActionType() const override { return ECCActionType::ChangeCombatMultiSide; }
	virtual UScriptStruct* GetScriptStruct() const override { return FCCChangeCombatMultiSideAction::StaticStruct(); }
	void DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const override;
	virtual FCCAction* Clone() const override { return new FCCChangeCombatMultiSideAction(CurrentCombatSide, bClearWave); }

	UPROPERTY()
	ECombatMultiSide CurrentCombatSide;

	UPROPERTY()
	bool bClearWave;
};
