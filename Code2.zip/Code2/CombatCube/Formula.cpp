#include "Formula.h"

#include "Q6Util.h"
#include "Q6Define.h"
#include "Q6Log.h"
#include "CharacterManager.h"
#include "FormulaRaw.h"

static const int32 DEFAULT_ORDER_BONUS_PER = 0;
static const int32 DEFAULT_ORDER_BONUS = 0;

int64 Formula::CalcDamage(UCMS* CMS, ECCFaction SourceFaction, ENatureType SourceNatureType, ENatureType TargetNatureType, int64 OriginDamage, FSagaType SagaType)
{
	return FormulaRaw::CalcDamage(GetNatureBonus(CMS, SourceFaction, SourceNatureType, TargetNatureType, SagaType), OriginDamage);
}

int64 Formula::CalcExtraDamage(UCMS* CMS, int64 OriginDamage, int64 ExtraDMGper)
{
	return FormulaRaw::CalcExtraDamage(OriginDamage, ExtraDMGper);
}

int64 Formula::CalcShieldDamage(UCMS* CMS, int64 OriginDamage, int32 AddShieldDMGper)
{
	return FormulaRaw::CalcShieldDamage(OriginDamage, AddShieldDMGper);
}

int64 Formula::CalcExtraShieldDamage(UCMS* CMS, int64 OriginDamage, int32 AddShieldDMGper, int64 ExtraDMGper)
{
	return FormulaRaw::CalcExtraShieldDamage(OriginDamage, ExtraDMGper, AddShieldDMGper);
}

int64 Formula::CalcAttackDamage(const FCCCombatCubeState& InOutState, UCMS* CMS, FCCUnitState& SourceUnit, int32 AliveUnitCount, const FCCSkillId& SkillId, int64 OriginDamage, bool bChordNote)
{
	const FCCSkillState* SkillState = SourceUnit.GetSkillState(SkillId);
	if (!SkillState)
	{
		Q6JsonLog(Warning, "calc attack damage can not find skill", Q6KV("UnitType", SourceUnit.UnitType));
		return 0;
	}

	const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillState->SkillType);
	if (SkillRow.IsInvalid())
	{
		Q6JsonLog(Warning, "calc attack damage can not find skill", Q6KV("UnitType", SourceUnit.UnitType), Q6KV("SkillType", SkillState->SkillType));
		return 0;
	}

	int ConstIndex = -1;
	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote)
	{
		if (SkillRow.SkillNote == ESkillNote::None)
		{
			ConstIndex = 0;
		}
		else if (SkillRow.SkillNote == ESkillNote::Ace)
		{
			ConstIndex = 1;
		}
		else if (SkillRow.SkillNote == ESkillNote::Break)
		{
			ConstIndex = 2;
		}
		else if (SkillRow.SkillNote == ESkillNote::Closer)
		{
			ConstIndex = 3;
		}
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Ultimate)
	{
		ConstIndex = 0;
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Double)
	{
		ConstIndex = 4;
	}
	else
	{
		ConstIndex = -1;
	}

	// [None, Ace, Break, Closer, Double]
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).AddDamageAtAttack.Num() == 5);
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).AddDamageAtChordAttack.Num() == 5);

	int32 CloserBonus = SourceUnit.GetAttributeValue(EUnitAttribute::NoteCloserBonus);
	int32 CloserBonusVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::NoteCloserBonusVaryper);

	return FormulaRaw::CalcAttackDamage(InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote, bChordNote,
		(int32)SkillRow.SkillNote, (int32)ESkillNote::Closer,
		ConstIndex, CMS->GetFormulaConstValues(AliveUnitCount).AddDamageAtAttack.Num(),
		CMS->GetFormulaConstValues(AliveUnitCount).AddDamageAtAttack.GetData(),
		CMS->GetFormulaConstValues(AliveUnitCount).AddDamageAtChordAttack.GetData(),
		OriginDamage, CloserBonus, CloserBonusVaryper);
}

int64 Formula::CalcNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, bool IsHPDMG, FSagaType SagaType)
{
	int64 TotalAtk = CalcTotalAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, SkillSequence, AliveUnitCount, SagaType);
	int64 TotalDef = CalcTotalDef(CMS, OffenseUnit, DefenseUnit, AliveUnitCount);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);

	return FormulaRaw::CalcNormalDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, TotalAtk, TotalDef, DamageVary, DamageVaryper);
}

int64 Formula::CalcUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, bool IsHPDMG, FSagaType SagaType)
{
	int64 TotalAtk = CalcTotalAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, SkillSequence, AliveUnitCount, SagaType);
	int64 TotalDef = CalcTotalDef(CMS, OffenseUnit, DefenseUnit, AliveUnitCount);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 UltimateVary = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);
	int64 UltimateVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVaryper);

	return FormulaRaw::CalcUltimateDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, TotalAtk, TotalDef, DamageVary, DamageVaryper, UltimateVary, UltimateVaryper);
}

int64 Formula::CalcExtraNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AliveUnitCount, int32 ExtraDMGper, bool IsHPDMG)
{
	int64 TotalAtk = CalcExtraAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, ExtraDMGper);
	int64 TotalDef = CalcTotalDef(CMS, OffenseUnit, DefenseUnit, AliveUnitCount);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);

	return FormulaRaw::CalcExtraNormalDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, ExtraDMGper, TotalAtk, TotalDef, DamageVary, DamageVaryper);
}

int64 Formula::CalcExtraUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AliveUnitCount, int32 ExtraDMGper, bool IsHPDMG)
{
	int64 TotalAtk = CalcExtraAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, ExtraDMGper);
	int64 TotalDef = CalcTotalDef(CMS, OffenseUnit, DefenseUnit, AliveUnitCount);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 UltimateVary = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);
	int64 UltimateVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVaryper);

	return FormulaRaw::CalcExtraUltimateDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, ExtraDMGper, TotalAtk, TotalDef, DamageVary, DamageVaryper, UltimateVary, UltimateVaryper);
}

int64 Formula::CalcShieldNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, int32 AddShieldDMGper, bool IsHPDMG)
{
	int64 TotalAtk = CalcShieldAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, AddShieldDMGper, SkillSequence, AliveUnitCount);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);

	return FormulaRaw::CalcShieldNormalDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, AddShieldDMGper, TotalAtk, DamageVary, DamageVaryper);
}

int64 Formula::CalcShieldUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, int32 AddShieldDMGper, bool IsHPDMG)
{
	int64 TotalAtk = CalcShieldAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, AddShieldDMGper, SkillSequence, AliveUnitCount);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 UltimateVary = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);
	int64 UltimateVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVaryper);

	return FormulaRaw::CalcShieldUltimateDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, AddShieldDMGper, TotalAtk, DamageVary, DamageVaryper, UltimateVary, UltimateVaryper);
}

int64 Formula::CalcExtraShieldNormalDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 ExtraDMGper, bool IsHPDMG)
{
	int64 TotalAtk = CalcExtraShieldAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, AddShieldDMGper, ExtraDMGper);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);

	return FormulaRaw::CalcExtraShieldNormalDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, AddShieldDMGper, ExtraDMGper, TotalAtk, DamageVary, DamageVaryper);
}

int64 Formula::CalcExtraShieldUltimateDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 ExtraDMGper,	bool IsHPDMG)
{
	int64 TotalAtk = CalcExtraShieldAtk(CMS, OffenseUnit, DefenseUnit, SkillDMGper, AddShieldDMGper, ExtraDMGper);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 UltimateVary = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);
	int64 UltimateVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVaryper);

	return FormulaRaw::CalcExtraShieldUltimateDamage(IsHPDMG, DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth),
		SkillDMGper, AddShieldDMGper, ExtraDMGper, TotalAtk, DamageVary, DamageVaryper, UltimateVary, UltimateVaryper);
}

int64 Formula::CalcNormalBuffDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType)
{
	int64 TotalTurnAtk = CalcTotalTurnAtk(CMS, OffenseUnit, DefenseUnit, TurnAtk, TurnAtkper, SkillSequence, AliveUnitCount, SagaType);
	int64 TotalDef = CalcTotalDef(CMS, OffenseUnit, DefenseUnit, AliveUnitCount);

	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);

	return CalcNormalBuffDamage(TotalTurnAtk, TotalDef, DamageVary, DamageVaryper, TurnAtkper);
}

int64 Formula::CalcRaidNormalBuffDamage(UCMS* CMS, const TArray<int32>& Attributes, ENatureType SourceNature,
	FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType)
{
	int64 TotalTurnAtk = CalcRaidTotalTurnAtk(CMS, Attributes, OffenseUnit.Faction, SourceNature, DefenseUnit, TurnAtk, TurnAtkper, SkillSequence, AliveUnitCount, SagaType);
	int64 TotalDef = CalcTotalDef(CMS, OffenseUnit, DefenseUnit, AliveUnitCount);

	int64 DamageVary = 0;
	int64 DamageVaryper = 0;

	int DamageVaryIndex = static_cast<int32>(EUnitAttribute::DamageVary);
	if (Attributes.IsValidIndex(DamageVaryIndex))
	{
		DamageVary = Attributes[DamageVaryIndex];
	}

	int DamageVaryperIndex = static_cast<int32>(EUnitAttribute::DamageVaryper);
	if (Attributes.IsValidIndex(DamageVaryperIndex))
	{
		DamageVaryper = Attributes[DamageVaryperIndex];
	}

	return CalcNormalBuffDamage(TotalTurnAtk, TotalDef, DamageVary, DamageVaryper, TurnAtkper);
}

int64 Formula::CalcNormalBuffDamage(int64 TotalTurnAtk, int64 TotalDef, int64 DamageVary, int64 DamageVaryper
	, int32 TurnAtkper)
{
	return FormulaRaw::CalcNormalBuffDamage(TotalTurnAtk, TotalDef, DamageVary, DamageVaryper, TurnAtkper);
}

int64 Formula::CalcUltimateBuffDamage(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType)
{
	int64 TotalTurnAtk = CalcTotalTurnAtk(CMS, OffenseUnit, DefenseUnit, TurnAtk, TurnAtkper, SkillSequence, AliveUnitCount, SagaType);
	int64 TotalDef = CalcTotalDef(CMS, OffenseUnit, DefenseUnit, AliveUnitCount);
	int64 DamageVary = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVary);
	int64 DamageVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::DamageVaryper);
	int64 UltimateVary = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVary);
	int64 UltimateVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::UltimateVaryper);

	return FormulaRaw::CalcUltimateBuffDamage(TotalTurnAtk, TurnAtkper, TotalDef, DamageVary, DamageVaryper, UltimateVary, UltimateVaryper);
}

int64 Formula::CalcBuffHeal(UCMS* CMS, FCCUnitState& SourceUnit, int32 TurnHeal, int32 TurnHealper, int32 AliveUnitCount)
{
	int64 Atk = SourceUnit.GetAttributeValue(EUnitAttribute::Atk);
	int64 AtkVary = SourceUnit.GetAttributeValue(EUnitAttribute::AtkVary);
	int64 AtkVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::AtkVaryper);
	int64 HealVary = SourceUnit.GetAttributeValue(EUnitAttribute::HealVary);
	int64 HealVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::HealVaryper);

	return CalcBuffHeal(CMS, Atk, AtkVary, AtkVaryper, HealVary, HealVaryper,
		TurnHeal, TurnHealper, AliveUnitCount);
}

int64 Formula::CalcRaidBuffHeal(UCMS* CMS, const TArray<int32>& Attributes, int32 TurnHeal, int32 TurnHealper, int32 AliveUnitCount)
{
	int64 Atk = 0;
	int64 AtkVary = 0;
	int64 AtkVaryper = 0;
	int64 HealVary = 0;
	int64 HealVaryper = 0;

	int32 AtkIndex = static_cast<int32>(EUnitAttribute::Atk);
	if (Attributes.IsValidIndex(AtkIndex))
	{
		Atk = Attributes[AtkIndex];
	}

	int32 AtkVaryIndex = static_cast<int32>(EUnitAttribute::AtkVary);
	if (Attributes.IsValidIndex(AtkVaryIndex))
	{
		AtkVary = Attributes[AtkVaryIndex];
	}

	int32 AtkVaryperIndex = static_cast<int32>(EUnitAttribute::AtkVaryper);
	if (Attributes.IsValidIndex(AtkVaryperIndex))
	{
		AtkVaryper = Attributes[AtkVaryperIndex];
	}

	int32 HealVaryIndex = static_cast<int32>(EUnitAttribute::HealVary);
	if (Attributes.IsValidIndex(HealVaryIndex))
	{
		HealVary = Attributes[HealVaryIndex];
	}

	int32 HealVaryperIndex = static_cast<int32>(EUnitAttribute::HealVaryper);
	if (Attributes.IsValidIndex(HealVaryperIndex))
	{
		HealVaryper = Attributes[HealVaryperIndex];
	}

	return CalcBuffHeal(CMS, Atk, AtkVary, AtkVaryper, HealVary, HealVaryper,
		TurnHeal, TurnHealper, AliveUnitCount);
}

int64 Formula::CalcBuffHeal(UCMS* CMS, int64 Atk, int64 AtkVary, int64 AtkVaryper, int64 HealVary, int64 HealVaryper,
	int32 TurnHeal, int32 TurnHealper, int32 AliveUnitCount)
{
	return FormulaRaw::CalcBuffHeal(Atk, AtkVary, AtkVaryper, HealVary, HealVaryper, TurnHeal, TurnHealper,
		CMS->GetFormulaConstValues(AliveUnitCount).HealConst);
}

int32 Formula::CalcTotalCri(FCCUnitState& OffenseUnit)
{
	int32 CriVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::CriVaryper);
	int32 Criper = OffenseUnit.GetAttributeValue(EUnitAttribute::Criper);

	return FormulaRaw::CalcTotalCri(Criper, CriVaryper, OffenseUnit.OverKill);
}

int64 Formula::CalcCriDamage(UCMS* CMS, FCCUnitState& OffenseUnit, int64 PreciseDamage, int32 AliveUnitCount, ESkillCategory Category)
{
	int32 CriDamVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::CriDamVaryper);

	return FormulaRaw::CalcCriDamage(CriDamVaryper, (int32)Category, (int32)ESkillCategory::Normal, (int32)ESkillCategory::Ultimate,
		CMS->GetFormulaConstValues(AliveUnitCount).NormalCriDamper,
		CMS->GetFormulaConstValues(AliveUnitCount).UltimateCriDamper, PreciseDamage);
}

int64 Formula::CalcBloodSucking(FCCUnitState& OffenseUnit, int64 PerciseDamage)
{
	return FormulaRaw::CalcBloodSucking(OffenseUnit.GetAttributeValue(EUnitAttribute::Bloodsuckingper), PerciseDamage);
}

int32 Formula::CalcAddUA(UCMS* CMS, FCCUnitState& TargetUnit, int32 OriginAddUA, int32 SkillSequence, int32 AliveUnitCount, ESkillCategory BornCategory)
{
	return FormulaRaw::CalcAddUA(OriginAddUA, TargetUnit.GetAttributeValue(EUnitAttribute::AddUAVaryper),
		(int32)BornCategory, (int32)ESkillCategory::TurnBegin, (int32)ESkillCategory::Equipment);
}

int32 Formula::CalcAttackUA(const FCCCombatCubeState& InOutState, UCMS* CMS, FCCUnitState& SourceUnit, int32 SkillSequence, int32 AliveUnitCount, const FCCSkillId& SkillId, bool bChordNote)
{
	const FCCSkillState* SkillState = SourceUnit.GetSkillState(SkillId);
	if (!SkillState)
	{
		Q6JsonLog(Warning, "calc attack UA can not find skill", Q6KV("UnitType", SourceUnit.UnitType));
		return 0;
	}

	const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillState->SkillType);
	if (SkillRow.IsInvalid())
	{
		Q6JsonLog(Warning, "calc attack UA can not find skill", Q6KV("UnitType", SourceUnit.UnitType), Q6KV("SkillType", SkillState->SkillType));
		return 0;
	}

	int ConstIndex = -1;
	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote)
	{
		if (SkillRow.SkillNote == ESkillNote::None)
		{
			ConstIndex = 0;
		}
		else if (SkillRow.SkillNote == ESkillNote::Ace)
		{
			ConstIndex = 1;
		}
		else if (SkillRow.SkillNote == ESkillNote::Break)
		{
			ConstIndex = 2;
		}
		else if (SkillRow.SkillNote == ESkillNote::Closer)
		{
			ConstIndex = 3;
		}
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Ultimate)
	{
		ConstIndex = 0;
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Double)
	{
		ConstIndex = 4;
	}
	else
	{
		ConstIndex = -1;
	}

	int32 AddUAAtOrder = DEFAULT_ORDER_BONUS_PER;
	if (SkillSequence > 0 && SkillRow.SkillCategory != ESkillCategory::Ultimate)
	{
		AddUAAtOrder = CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtOrder[SkillSequence - 1];
	}

	int32 AceBonus = SourceUnit.GetAttributeValue(EUnitAttribute::NoteAceBonus);
	int32 AceBonusVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::NoteAceBonusVaryper);
	int32 AddUAVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::AddUAVaryper);

	// [None, Ace, Break, Closer, Double]
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtAttack.Num() == 5);
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtChordAttack.Num() == 5);

	return FormulaRaw::CalcAttackUA(InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote, bChordNote,
		(int32)SkillRow.SkillNote, (int32)ESkillNote::Ace,
		ConstIndex, CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtAttack.Num(),
		CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtAttack.GetData(),
		CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtChordAttack.GetData(),
		AddUAAtOrder, AddUAVaryper, AceBonus, AceBonusVaryper);
}

int32 Formula::CalcBeatenUA(UCMS* CMS, FCCUnitState& DefenseUnit, int64 PreciseDamage, int32 AliveUnitCount)
{
	return FormulaRaw::CalcBeatenUA(PreciseDamage, CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtDamage,
		DefenseUnit.GetAttributeValue(EUnitAttribute::MaxHealth));
}

int32 Formula::CalcKillTargetUABonus(UCMS* CMS, FCCUnitState& SourceUnit, int32 OriginAddUA, int32 SkillSequence, int32 AliveUnitCount)
{
	return FormulaRaw::CalcKillTargetUABonus(CMS->GetFormulaConstValues(AliveUnitCount).AddUAAtKill,
		SourceUnit.GetAttributeValue(EUnitAttribute::AddUAVaryper));
}

int32 Formula::CalcAddSA(UCMS* CMS, FCCUnitState& TargetUnit, int32 OriginAddSA, int32 SkillSequence, int32 AliveUnitCount, ESkillCategory BornCategory)
{
	return FormulaRaw::CalcAddSA(OriginAddSA, TargetUnit.GetAttributeValue(EUnitAttribute::AddSAVaryper),
		(int32)BornCategory, (int32)ESkillCategory::TurnBegin, (int32)ESkillCategory::Equipment);
}

int32 Formula::CalcAttackSA(const FCCCombatCubeState& InOutState, UCMS* CMS, FCCUnitState& SourceUnit, int32 SkillSequence, int32 AliveUnitCount, const FCCSkillId& SkillId, bool bChordNote)
{
	const FCCSkillState* SkillState = SourceUnit.GetSkillState(SkillId);
	if (!SkillState)
	{
		Q6JsonLog(Warning, "calc attack SA can not find skill", Q6KV("UnitType", SourceUnit.UnitType));
		return 0;
	}

	const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillState->SkillType);
	if (SkillRow.IsInvalid())
	{
		Q6JsonLog(Warning, "calc attack SA can not find skill", Q6KV("UnitType", SourceUnit.UnitType), Q6KV("SkillType", SkillState->SkillType));
		return 0;
	}

	int ConstIndex = -1;
	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote)
	{
		if (SkillRow.SkillNote == ESkillNote::None)
		{
			ConstIndex = 0;
		}
		else if (SkillRow.SkillNote == ESkillNote::Ace)
		{
			ConstIndex = 1;
		}
		else if (SkillRow.SkillNote == ESkillNote::Break)
		{
			ConstIndex = 2;
		}
		else if (SkillRow.SkillNote == ESkillNote::Closer)
		{
			ConstIndex = 3;
		}
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Ultimate)
	{
		ConstIndex = 0;
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Double)
	{
		ConstIndex = 4;
	}
	else
	{
		ConstIndex = -1;
	}

	// [None, Ace, Break, Closer, Double]
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtAttack.Num() == 5);
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtChordAttack.Num() == 5);

	int32 BreakBonus = SourceUnit.GetAttributeValue(EUnitAttribute::NoteBreakBonus);
	int32 BreakBonusVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::NoteBreakBonusVaryper);

	int32 AddSAAtOrder = DEFAULT_ORDER_BONUS_PER;
	if (SkillSequence > 0 && SkillRow.SkillCategory != ESkillCategory::Ultimate)
	{
		AddSAAtOrder = CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtOrder[SkillSequence - 1];
	}

	int32 AddSAVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::AddSAVaryper);

	return FormulaRaw::CalcAttackSA(InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote, bChordNote,
		(int32)SkillRow.SkillNote, (int32)ESkillNote::Break, ConstIndex, CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtAttack.Num(),
		CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtAttack.GetData(),
		CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtChordAttack.GetData(),
		AddSAAtOrder, AddSAVaryper, BreakBonus, BreakBonusVaryper);

}

int32 Formula::CalcBeatenSA(UCMS* CMS, FCCUnitState& TargetUnit, int64 PreciseDamage, int64 DefenseUnitRemainHP, int32 AliveUnitCount)
{
	return FormulaRaw::CalcBeatenSA(PreciseDamage, DefenseUnitRemainHP,
		CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtDamage);
}

int32 Formula::CalcKillTargetSABonus(UCMS* CMS, FCCUnitState& SourceUnit, int32 OriginAddUA, int32 SkillSequence, int32 AliveUnitCount)
{
	return FormulaRaw::CalcKillTargetSABonus(CMS->GetFormulaConstValues(AliveUnitCount).AddSAAtKill,
		SourceUnit.GetAttributeValue(EUnitAttribute::AddSAVaryper));
}

int64 Formula::CalcSkillHeal(UCMS* CMS, FCCUnitState& SourceUnit, int32 SkillHealper, int32 AliveUnitCount)
{
	int64 Atk = SourceUnit.GetAttributeValue(EUnitAttribute::Atk);
	int64 AtkVary = SourceUnit.GetAttributeValue(EUnitAttribute::AtkVary);
	int64 AtkVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::AtkVaryper);
	int64 HealVary = SourceUnit.GetAttributeValue(EUnitAttribute::HealVary);
	int64 HealVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::HealVaryper);

	return CalcSkillHeal(CMS, Atk, AtkVary, AtkVaryper, HealVary, HealVaryper, SkillHealper, AliveUnitCount);
}

int64 Formula::CalcRaidSkillHeal(UCMS* CMS, const TArray<int32>& Attributes, int32 SkillHealper, int32 AliveUnitCount)
{
	int64 Atk = 0;
	int64 AtkVary = 0;
	int64 AtkVaryper = 0;
	int64 HealVary = 0;
	int64 HealVaryper = 0;

	int32 AtkIndex = static_cast<int32>(EUnitAttribute::Atk);
	if (Attributes.IsValidIndex(AtkIndex))
	{
		Atk = Attributes[AtkIndex];
	}

	int32 AtkVaryIndex = static_cast<int32>(EUnitAttribute::AtkVary);
	if (Attributes.IsValidIndex(AtkVaryIndex))
	{
		AtkVary = Attributes[AtkVaryIndex];
	}

	int32 AtkVaryperIndex = static_cast<int32>(EUnitAttribute::AtkVaryper);
	if (Attributes.IsValidIndex(AtkVaryperIndex))
	{
		AtkVaryper = Attributes[AtkVaryperIndex];
	}

	int32 HealVaryIndex = static_cast<int32>(EUnitAttribute::HealVary);
	if (Attributes.IsValidIndex(HealVaryIndex))
	{
		HealVary = Attributes[HealVaryIndex];
	}

	int32 HealVaryperIndex = static_cast<int32>(EUnitAttribute::HealVaryper);
	if (Attributes.IsValidIndex(HealVaryperIndex))
	{
		HealVaryper = Attributes[HealVaryperIndex];
	}

	return CalcSkillHeal(CMS, Atk, AtkVary, AtkVaryper, HealVary, HealVaryper, SkillHealper, AliveUnitCount);
}

int64 Formula::CalcSkillHeal(UCMS* CMS, int64 Atk, int64 AtkVary, int64 AtkVaryper, int64 HealVary, int64 HealVaryper,
	int32 SkillHealper, int32 AliveUnitCount)
{
	return FormulaRaw::CalcSkillHeal(Atk, AtkVary, AtkVaryper, HealVary, HealVaryper, SkillHealper,
		CMS->GetFormulaConstValues(AliveUnitCount).HealConst);
}

int32 Formula::CalcOverKill(const FCCCombatCubeState& InOutState, UCMS* CMS,
	FCCUnitState& SourceUnit, int64 DefenseUnitRemainHealth, int64 Damage, int32 AliveUnitCount, const FCCSkillId& SkillId, bool bChordNote, ESkillCategory BornCategory)
{
	if (!SourceUnit.CanGetOverkill())
	{
		return 0;
	}

	const FCCSkillState* SkillState = SourceUnit.GetSkillState(SkillId);
	if (!SkillState)
	{
		Q6JsonLog(Warning, "calc overkill can not find skill", Q6KV("UnitType", SourceUnit.UnitType));
		return 0;
	}

	const FCMSSkillRow& SkillRow = CMS->GetSkillRowOrDummy(SkillState->SkillType);
	if (SkillRow.IsInvalid())
	{
		Q6JsonLog(Warning, "calc overkill can not find skill", Q6KV("UnitType", SourceUnit.UnitType), Q6KV("SkillType", SkillState->SkillType));
		return 0;
	}

	int ConstIndex = 0;
	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote)
	{
		if (SkillRow.SkillNote == ESkillNote::None)
		{
			ConstIndex = 0;
		}
		else if (SkillRow.SkillNote == ESkillNote::Ace)
		{
			ConstIndex = 1;
		}
		else if (SkillRow.SkillNote == ESkillNote::Break)
		{
			ConstIndex = 2;
		}
		else if (SkillRow.SkillNote == ESkillNote::Closer)
		{
			ConstIndex = 3;
		}
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Ultimate)
	{
		ConstIndex = 0;
	}
	else if (SkillRow.SkillCategory == ESkillCategory::Double)
	{
		ConstIndex = 4;
	}
	else
	{
		Q6JsonLog(Warning, "calc overkill wrong skill category",
			Q6KV("UnitType", SourceUnit.UnitType),
			Q6KV("SkillType", SkillState->SkillType),
			Q6KV("category", (int32)SkillRow.SkillCategory));
		return 0;
	}

	// [None, Ace, Break, Closer, Double]
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).DefaultOverKillConst.Num() == 5);
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).ChordOverKillConst.Num() == 5);
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).VirtualHitCount.Num() == 5);
	ensure(CMS->GetFormulaConstValues(AliveUnitCount).OverKillConst.Num() == 5);

	int32 OverKill = FormulaRaw::CalcOverKill(bChordNote, SourceUnit.bStraightNote, (int32)SkillRow.SkillNote,
		(int32)ESkillNote::Closer, ConstIndex,
		CMS->GetFormulaConstValues(AliveUnitCount).DefaultOverKillConst.GetData(),
		CMS->GetFormulaConstValues(AliveUnitCount).ChordOverKillConst.GetData(),
		CMS->GetFormulaConstValues(AliveUnitCount).VirtualHitCount.GetData(),
		CMS->GetFormulaConstValues(AliveUnitCount).OverKillConst.GetData(),
		DefenseUnitRemainHealth, Damage,
		SourceUnit.GetAttributeValue(EUnitAttribute::NoteBreakBonus),
		SourceUnit.GetAttributeValue(EUnitAttribute::NoteBreakBonusVaryper));

	OverKill = CalcOverKillNoDamage(CMS, SourceUnit, OverKill, BornCategory);
	return FMath::Clamp(OverKill, CMS->GetFormulaConstValues(AliveUnitCount).OverKillMin, CMS->GetFormulaConstValues(AliveUnitCount).OverKillMax);
}

int32 Formula::CalcOverKillNoDamage(UCMS* CMS, FCCUnitState& Unit, int32 InOverKill, ESkillCategory BornCategory)
{
	if (!Unit.CanGetOverkill())
	{
		return 0;
	}

	int32 OverKillVaryper = Unit.GetAttributeValue(EUnitAttribute::OverKillVaryper);

	return FormulaRaw::CalcOverKillNoDamage(InOverKill, OverKillVaryper,
		(int32)BornCategory, (int32)ESkillCategory::TurnBegin, (int32)ESkillCategory::Equipment);
}

int64 Formula::InterpolatedBySkillLevelOrTier(int32 InSkillLevelOrTier, int64 InMin, int64 InMax, ESkillCategory InBornCategory)
{
	int64 OutValue = FormulaRaw::InterpolatedBySkillLevelOrTier(InSkillLevelOrTier, InMin, InMax, (int)InBornCategory,
		CombatCubeConst::Q6_MAX_SKILL_LEVEL, CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL, CombatCubeConst::Q6_MAX_TIER,
		(int)ESkillCategory::Ultimate, (int)ESkillCategory::Equipment);

	Q6JsonLogBro(Display, "Interpolate By Skill Level",
		Q6KV("Value", OutValue),
		Q6KV("SkillCategory", (int32)InBornCategory),
		Q6KV("SkillLevel or Tier", InSkillLevelOrTier),
		Q6KV("Minimum", InMin),
		Q6KV("Maximum", InMax));

	return OutValue;
}

int64 Formula::InterpolatedByTier(int32 InTier, int64 InMin, int64 InMax)
{
	return InterpolatedBySkillLevelOrTier(InTier, InMin, InMax, ESkillCategory::Equipment);
}

ENatureRelationType Formula::GetNatureRelationType(UCMS* CMS, ECCFaction SourceFaction, ENatureType SourceNatureType, ENatureType TargetNatureType, FSagaType SagaType)
{
	 int32 Bonus = GetNatureBonus(CMS, SourceFaction, SourceNatureType, TargetNatureType, SagaType);
	 return (ENatureRelationType)FormulaRaw::GetNatureRelationType(Bonus,
		 (int32)ENatureRelationType::Strong, (int32)ENatureRelationType::Weak, (int32)ENatureRelationType::Normal);
}

int64 Formula::GetShieldDMGper(UCMS* CMS, int32 ShieldWeakPoint, ESkillCategory Category, ESkillNote Note, int32 AliveUnitCount)
{
	return FormulaRaw::GetShieldDMGper(ShieldWeakPoint, CombatCubeConst::Q6_DEFAULT_ADDSHIELDDMGPER,
		CMS->GetFormulaConstValues(AliveUnitCount).AddShieldDMGper,
		(int32)Category, (int32)ESkillCategory::Ultimate, (int32)ESkillCategory::Normal, (int32)ESkillCategory::Double,
		(int32)Note, (int32)ESkillNote::Ace, (int32)ESkillNote::Break, (int32)ESkillNote::Closer);
}

int64 Formula::CalcTotalAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType)
{
	int64 Atk = OffenseUnit.GetAttributeValue(EUnitAttribute::Atk);
	int64 AtkVary = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVary);
	int64 AtkVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVaryper);

	int32 NatureBonus = GetNatureBonus(CMS, OffenseUnit.Faction, OffenseUnit.GetNatureType(), DefenseUnit.GetNatureType(), SagaType);

	int32 OrderCalculation = DEFAULT_ORDER_BONUS;
	if (SkillSequence > 0)
	{
		OrderCalculation = CMS->GetFormulaConstValues(AliveUnitCount).OrderCalculation[SkillSequence - 1];
	}

	int64 AtkConst = CMS->GetFormulaConstValues(AliveUnitCount).AtkConst;

	return FormulaRaw::CalcTotalAtk(Atk, AtkVary, AtkVaryper, SkillDMGper, AtkConst, NatureBonus, OrderCalculation);
}

int64 Formula::CalcExtraAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 ExtraDMGper)
{
	int64 Atk = OffenseUnit.GetAttributeValue(EUnitAttribute::Atk);
	int64 AtkVary = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVary);
	int64 AtkVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVaryper);

	return FormulaRaw::CalcExtraAtk(Atk, AtkVary, AtkVaryper, SkillDMGper, ExtraDMGper);
}

int64 Formula::CalcShieldAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 SkillSequence, int32 AliveUnitCount)
{
	int64 Atk = OffenseUnit.GetAttributeValue(EUnitAttribute::Atk);
	int64 AtkVary = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVary);
	int64 AtkVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVaryper);

	int32 NatureBonus = 1000;
	int32 OrderCalculation = DEFAULT_ORDER_BONUS;
	if (SkillSequence > 0)
	{
		OrderCalculation = CMS->GetFormulaConstValues(AliveUnitCount).OrderCalculation[SkillSequence - 1];
	}

	return FormulaRaw::CalcShieldAtk(Atk, AtkVary, AtkVaryper, SkillDMGper, AddShieldDMGper, NatureBonus, OrderCalculation);
}

int64 Formula::CalcExtraShieldAtk(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 SkillDMGper, int32 AddShieldDMGper, int32 ExtraDMGper)
{
	int64 Atk = OffenseUnit.GetAttributeValue(EUnitAttribute::Atk);
	int64 AtkVary = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVary);
	int64 AtkVaryper = OffenseUnit.GetAttributeValue(EUnitAttribute::AtkVaryper);

	return FormulaRaw::CalcExtraShieldAtk(Atk, AtkVary, AtkVaryper, SkillDMGper, AddShieldDMGper, ExtraDMGper);
}

int64 Formula::CalcTotalDef(UCMS* CMS, FCCUnitState& OffenseUnit, FCCUnitState& DefenseUnit, int32 AliveUnitCount)
{
	int64 IgnoreDefConst = 1000LL;
	if (OffenseUnit.GetCrowdControlState(CMS, ECrowdControl::IgnoreDef) > 0)
	{
		Q6JsonLogObiwan(Display, "ignore defance",
			Q6KV("offense UnitType", OffenseUnit.UnitType.x),
			Q6KV("defense UnitType", DefenseUnit.UnitType.x));
		IgnoreDefConst = CMS->GetFormulaConstValues(AliveUnitCount).IgnoreDef;
	}

	int64 Def = DefenseUnit.GetAttributeValue(EUnitAttribute::Def);
	int64 DefVary = DefenseUnit.GetAttributeValue(EUnitAttribute::DefVary);
	int64 DefVaryper = DefenseUnit.GetAttributeValue(EUnitAttribute::DefVaryper);

	return FormulaRaw::CalcTotalDef(Def, DefVary, DefVaryper,
		CMS->GetFormulaConstValues(AliveUnitCount).TotalDef,
		CMS->GetFormulaConstValues(AliveUnitCount).TotalDefBig,
		IgnoreDefConst);
}

int32 Formula::GetNatureBonus(UCMS* CMS, ECCFaction SourceFaction, ENatureType SourceNatureType, ENatureType TargetNatureType, FSagaType SagaType)
{
	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);
	const FCMSDifficultyNatureBonusRow* Values = CMS->GetDifficultyNatureBonus(SagaRow.Difficulty);
	int32 TargetIdx = static_cast<int32>(TargetNatureType);
	static_assert(static_cast<int32>(ENatureType::Fire) == 0, "ENatureType used to array index.");
	static_assert(static_cast<int32>(ENatureType::Water) == 1, "ENatureType used to array index.");
	static_assert(static_cast<int32>(ENatureType::Wind) == 2, "ENatureType used to array index.");
	static_assert(static_cast<int32>(ENatureType::Light) == 3, "ENatureType used to array index.");
	static_assert(static_cast<int32>(ENatureType::Dark) == 4, "ENatureType used to array index.");

	return FormulaRaw::GetNatureBonus((int32)SourceFaction, (int32)SourceNatureType, (int32)TargetNatureType,
		(int32)ECCFaction::Ally, (int32)ECCFaction::Enemy,
		Values->AllyNatureFireBonus.GetData(), Values->AllyNatureWindBonus.GetData(), Values->AllyNatureWindBonus.GetData(),
		Values->AllyNatureLightBonus.GetData(), Values->AllyNatureDarkBonus.GetData(),
		Values->EnemyNatureFireBonus.GetData(), Values->EnemyNatureWindBonus.GetData(), Values->EnemyNatureWindBonus.GetData(),
		Values->EnemyNatureLightBonus.GetData(), Values->EnemyNatureDarkBonus.GetData(),
		(int32)ENatureType::Fire, (int32)ENatureType::Water, (int32)ENatureType::Wind, (int32)ENatureType::Light, (int32)ENatureType::Dark);
}

int64 Formula::CalcTotalTurnAtk(UCMS* CMS, FCCUnitState& SourceUnit, FCCUnitState& TargetUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType)
{
	int64 Atk = SourceUnit.GetAttributeValue(EUnitAttribute::Atk);
	int64 AtkVary = SourceUnit.GetAttributeValue(EUnitAttribute::AtkVary);
	int64 AtkVaryper = SourceUnit.GetAttributeValue(EUnitAttribute::AtkVaryper);

	int64 OrderCalculation = DEFAULT_ORDER_BONUS;
	if (SkillSequence > 0)
	{
		OrderCalculation = CMS->GetFormulaConstValues(AliveUnitCount).OrderCalculation[SkillSequence - 1];
	}

	return FormulaRaw::CalcTotalTurnAtk(Atk, AtkVary, AtkVaryper,
		TurnAtk, TurnAtkper,
		GetNatureBonus(CMS, SourceUnit.Faction, SourceUnit.GetNatureType(), TargetUnit.GetNatureType(), SagaType),
		OrderCalculation);
}

int64 Formula::CalcRaidTotalTurnAtk(UCMS* CMS, const TArray<int32>& Attributes, ECCFaction SourceFaction, ENatureType SourceNature,
	FCCUnitState& TargetUnit, int32 TurnAtk, int32 TurnAtkper, int32 SkillSequence, int32 AliveUnitCount, FSagaType SagaType)
{
	int64 Atk = 0;
	int64 AtkVary = 0;
	int64 AtkVaryper = 0;

	int32 AtkIndex = static_cast<int32>(EUnitAttribute::Atk);
	if (Attributes.IsValidIndex(AtkIndex))
	{
		Atk = Attributes[AtkIndex];
	}

	int32 AtkVaryIndex = static_cast<int32>(EUnitAttribute::AtkVary);
	if (Attributes.IsValidIndex(AtkVaryIndex))
	{
		AtkVary = Attributes[AtkVaryIndex];
	}

	int32 AtkVaryperIndex = static_cast<int32>(EUnitAttribute::AtkVaryper);
	if (Attributes.IsValidIndex(AtkVaryperIndex))
	{
		AtkVaryper = Attributes[AtkVaryperIndex];
	}

	int64 ValueA = ((Atk + AtkVary) * (1000 + AtkVaryper)) / 1000;
	int64 ValueB = (ValueA * TurnAtkper) / 1000;
	int64 ValueC = GetNatureBonus(CMS, SourceFaction, SourceNature, TargetUnit.GetNatureType(), SagaType);

	int64 ValueD = DEFAULT_ORDER_BONUS;
	if (SkillSequence > 0)
	{
		ValueD = CMS->GetFormulaConstValues(AliveUnitCount).OrderCalculation[SkillSequence - 1];
	}

	int64 ValueE = (TurnAtk + ValueB) * (ValueC + ValueD);
	int64 Total = ValueE / 1000;

	return Total;
}

void Attribute::GetCharacterAttribute(UCMS* CMS, const FCharacterInfo& InCharacterInfo, int64& OutMaxHealth, int64& OutAtk, int64& OutDef)
{
	FUnitType UnitType = CMS->GetUnitType(InCharacterInfo.Type);

	GetUnitAttribute(CMS, EAttributeCategory::Character,
		UnitType, InCharacterInfo.Level, InCharacterInfo.Grade, nullptr,
		OutMaxHealth, OutAtk, OutDef);
}

static bool CheckValidItem(int64 ItemType, int32 InLevel, EItemGrade InGrade)
{
	if (ItemType <= 0)
	{
		Q6JsonLogRoze(Display, "wrong item type on _CheckValidItem().");
		return false;
	}

	if (InLevel <= 0)
	{
		Q6JsonLogRoze(Display, "wrong level on _CheckValidItem().", Q6KV("level", InLevel));
		return false;
	}

	if (InGrade == EItemGrade::NONE || !IsValidEItemGrade((int32)InGrade))
	{
		Q6JsonLogRoze(Display, "wrong grade on _CheckValidItem().", Q6KV("grade", (int32)InGrade));
		return false;
	}

	return true;
}

static bool CheckValidEquip(int64 ItemType, int32 InLevel, int32 InTier, EItemGrade InGrade)
{
	if (!CheckValidItem(ItemType, InLevel, InGrade))
	{
		return false;
	}

	if ((InTier <= 0) || (InTier > CombatCubeConst::Q6_MAX_TIER))
	{
		Q6JsonLogRoze(Display, "wrong Relic on _CheckValidEquip().", Q6KV("RelicType", ItemType),
			Q6KV("Tier", InTier));
		return false;
	}

	return true;
}

void Attribute::GetUnitAttribute(UCMS* CMS, EAttributeCategory InRatioType, FUnitType InUnitType, int32 InLevel, EItemGrade InGrade, const FCMSAdditionalPointRow* InAdditionalPoint,
	int64& OutMaxHealth, int64& OutAtk, int64& OutDef)
{
	OutMaxHealth = 0;
	OutAtk = 0;
	OutDef = 0;

	if (!CheckValidItem(InUnitType.x, InLevel, InGrade))
	{
		Q6JsonLogObiwan(Display, "wrong Unit on GetUnitAttribute().", Q6KV("UnitType", InUnitType.x),
			Q6KV("level", InLevel), Q6KV("grade", (int32)InGrade));
		return;
	}

	const FCMSUnitRow& Unit = CMS->GetUnitRowOrDummy(InUnitType);

	const FCMSAdditionalPointRow* AdditionalPoint = nullptr;
	if (InAdditionalPoint)
	{
		AdditionalPoint = InAdditionalPoint;
	}
	else
	{
		AdditionalPoint = CMS->GetAdditionalPoint(CombatCubeConst::Q6_DEFAULT_DIFFICULTY, Unit.AttributeCategory); // Unit:AdditionalPoint = 1:1. Unit always has an AdditionalPoint.
	}

	const FCMSAttributeRatioRow* AttributeRatio = CMS->GetAttributeRatio(InRatioType);
	if (!AttributeRatio)
	{
		Q6JsonLogObiwan(Display, "wrong unit ratio on GetUnitAttribute().", Q6KV("UnitType", InUnitType.x), Q6KV("ratio", (int32)InRatioType));
		return;
	}

	const FCMSWeightRow* Weight = Unit.GetWeight()[0];  // Unit:Weight = 1:1. Unit always has an Weight.

	FormulaRaw::GetUnitAttribute(Unit.IgnoreWeight, Unit.HP, Unit.Atk, Unit.Def,
		Weight->HPWeight, Weight->AtkWeight, Weight->DefWeight,
		AttributeRatio->HP, AttributeRatio->Atk, AttributeRatio->Def,
		AdditionalPoint->HP, AdditionalPoint->Atk, AdditionalPoint->Def,
		CMS->GetAttributeConstValues().ConstA,
		CMS->GetAttributeConstValues().ConstKs[0], CMS->GetAttributeConstValues().ConstKs[1], CMS->GetAttributeConstValues().ConstKs[2],
		CMS->GetAttributeConstValues().ConstUnitZGrades[(int32)InGrade - 1] /* 0 base */,
		OutMaxHealth, OutAtk, OutDef);
}

void Attribute::GetRelicAttribute(UCMS* CMS, FRelicType InType, int32 InLevel, int32 InTier, EItemGrade InGrade, int64& OutMaxHealth, int64& OutAtk, int64& OutDef)
{
	OutMaxHealth = 0;
	OutAtk = 0;
	OutDef = 0;

	if (InType == RelicTypeInvalid)
	{
		return;
	}

	if (!CheckValidEquip(InType.x, InLevel, InTier, InGrade))
	{
		Q6JsonLogObiwan(Display, "wrong Relic on GetRelicAttribute().", Q6KV("RelicType", InType.x),
			Q6KV("level", InLevel), Q6KV("tier", InTier), Q6KV("grade", (int32)InGrade));
		return;
	}

	const FCMSRelicRow& Relic = CMS->GetRelicRowOrDummy(InType);
	const FCMSAdditionalPointRow* AdditionalPoint = CMS->GetAdditionalPoint(CombatCubeConst::Q6_DEFAULT_DIFFICULTY, EAttributeCategory::Relic);
	const FCMSAttributeRatioRow* AttributeRatio = CMS->GetAttributeRatio(EAttributeCategory::Relic);
	if (!AttributeRatio || !AdditionalPoint)
	{
		Q6JsonLogRoze(Error, "wrong relic ratio on GetRelicAttribute().", Q6KV("RelicType", InType.x));
		return;
	}

	const FCMSWeightRow* Weight = Relic.GetWeight()[0];  // Relic:Weight = 1:1. Relic always has an Weight.

	FormulaRaw::GetRelicAttribute(InLevel, Weight->HPWeight, Weight->AtkWeight, Weight->DefWeight,
		AttributeRatio->HP, AttributeRatio->Atk, AttributeRatio->Def,
		AdditionalPoint->HP, AdditionalPoint->Atk, AdditionalPoint->Def,
		CMS->GetAttributeConstValues().ConstA,
		CMS->GetAttributeConstValues().ConstKs[0], CMS->GetAttributeConstValues().ConstKs[1], CMS->GetAttributeConstValues().ConstKs[2],
		CMS->GetAttributeConstValues().ConstEquipZGrades[(int32)InGrade - 1] /* 0 base */,
		CMS->GetAttributeConstValues().TierRatio[InTier - 1] /* 0 base */,
		OutMaxHealth, OutAtk, OutDef);
}

void Attribute::GetSculptureAttribute(UCMS* CMS, FSculptureType InType, int32 InLevel, int32 InTier, EItemGrade InGrade, int64& OutMaxHealth, int64& OutAtk, int64& OutDef)
{
	OutMaxHealth = 0;
	OutAtk = 0;
	OutDef = 0;

	if (InType == SculptureTypeInvalid)
	{
		return;
	}

	if (!CheckValidEquip(InType.x, InLevel, InTier, InGrade))
	{
		Q6JsonLogObiwan(Display, "wrong Sculpture on GetSculptureAttribute().", Q6KV("SculptureType", InType.x),
			Q6KV("level", InLevel), Q6KV("tier", InTier), Q6KV("grade", (int32)InGrade));
		return;
	}

	const FCMSSculptureRow& Sculpture = CMS->GetSculptureRowOrDummy(InType);
	const FCMSAdditionalPointRow* AdditionalPoint = CMS->GetAdditionalPoint(CombatCubeConst::Q6_DEFAULT_DIFFICULTY, EAttributeCategory::Sculpture);
	const FCMSAttributeRatioRow* AttributeRatio = CMS->GetAttributeRatio(EAttributeCategory::Sculpture);
	if (!AdditionalPoint || !AttributeRatio)
	{
		Q6JsonLogRoze(Error, "wrong sculpture ratio on GetRelicAttribute().");
		return;
	}

	const FCMSWeightRow* Weight = Sculpture.GetWeight()[0];  // Sculpture:Weight = 1:1. Sculpture always has an Weight.

	FormulaRaw::GetSculptureAttribute(InLevel, Weight->HPWeight, Weight->AtkWeight, Weight->DefWeight,
		AttributeRatio->HP, AttributeRatio->Atk, AttributeRatio->Def,
		AdditionalPoint->HP, AdditionalPoint->Atk, AdditionalPoint->Def,
		CMS->GetAttributeConstValues().ConstA,
		CMS->GetAttributeConstValues().ConstKs[0], CMS->GetAttributeConstValues().ConstKs[1], CMS->GetAttributeConstValues().ConstKs[2],
		CMS->GetAttributeConstValues().ConstEquipZGrades[(int32)InGrade - 1] /* 0 base */,
		CMS->GetAttributeConstValues().TierRatio[InTier - 1] /* 0 base */,
		OutMaxHealth, OutAtk, OutDef);
}
