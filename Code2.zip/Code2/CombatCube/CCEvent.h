#pragma once
#include "Q6GameState.h"
#include "ccStruct_gen.h"
#include "CCEvent.generated.h"

UCLASS(BlueprintType)
class UCCReportErrorEvent : public UCCReportErrorEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::ReportError; }
};

UCLASS(BlueprintType)
class UCCStartGameEvent : public UCCStartGameEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::StartGame; }
};

UCLASS(BlueprintType)
class UCCStartWaveEvent : public UCCStartWaveEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::StartWave; }
};

UCLASS(BlueprintType)
class UCCTakeTurnEvent : public UCCTakeTurnEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::TakeTurn; }
};

UCLASS(BlueprintType)
class UCCSpawnUnitEvent : public UCCSpawnUnitEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SpawnUnit; }
};

UCLASS(BlueprintType)
class UCCDespawnUnitEvent : public UCCDespawnUnitEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::DespawnUnit; }
};

UCLASS(BlueprintType)
class UCCUnitDeadEvent : public UCCUnitDeadEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::UnitDead; }
};

UCLASS(BlueprintType)
class UCCStartTurnEvent : public UCCStartTurnEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::StartTurn; }
};

UCLASS(BlueprintType)
class UCCStartPhaseEvent : public UCCStartPhaseEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::StartPhase; }
};

UCLASS(BlueprintType)
class UCCSkillUsedEvent : public UCCSkillUsedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SkillUsed; }
};

UCLASS(BlueprintType)
class UCCSkillEndEvent : public UCCSkillEndEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SkillEnd; }
};

UCLASS(BlueprintType)
class UCCSkillFailedEvent : public UCCSkillFailedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SkillFailed; }
};

UCLASS(BlueprintType)
class UCCAttackPassEvent : public UCCAttackPassEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::AttackPass; }
};

UCLASS(BlueprintType)
class UCCUnitHealthChangedEvent : public UCCUnitHealthChangedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::HealthChanged; }

	void SetEvent(FCCUnitId InUnitId, FCCSkillId InSkillId, int64 InOldHealth, int64 InNewHealth, int64 InAddedHealth, EHealthChangeReason InReason);
};

UCLASS(BlueprintType)
class UCCDamageBuffPerUnit : public UObject
{
	GENERATED_BODY()

public:
	void SetEvent(ENatureRelationType InNatureRelationType, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType,
		int64 InOldHealth, int64 InNewHealth, int64 InBaseDamage, int64 InShieldDamage, bool bInDodged);

public:
	UPROPERTY(BlueprintReadOnly)
	ENatureRelationType NatureRelationType;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId TargetUnitId;

	UPROPERTY(BlueprintReadOnly)
	int32 BuffType;

	UPROPERTY(BlueprintReadOnly)
	int32 BuffEffectType;

	UPROPERTY(BlueprintReadOnly)
	int64 OldHealth;

	UPROPERTY(BlueprintReadOnly)
	int64 NewHealth;

	UPROPERTY(BlueprintReadOnly)
	int64 BaseDamage;

	UPROPERTY(BlueprintReadOnly)
	int64 ShieldDamage;

	UPROPERTY(BlueprintReadOnly)
	bool bDodged;
};

UCLASS(BlueprintType)
class UCCDamageBuffEvent : public UCCDamageBuffEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const { return ECCEventType::DamageBuff; }

    void AppendEvent(ENatureRelationType InNatureRelationType, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType,
		int32 InOldHealth, int32 InNewHealth, int32 InBaseDamage, int32 InShieldDamage, bool bInCCDefence);

	int32 EventNum() const { return Events.Num(); }
	const TArray<UCCDamageBuffPerUnit*>& GetEvents() const { return Events; }
};

UCLASS(BlueprintType)
class UCCHealBuffPerUnit : public UObject
{
	GENERATED_BODY()

public:
	void SetEvent(FCCUnitId InSourceUnitId, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType, int32 InOldHealth, int32 InNewHealth, int32 InHeal, EHealthChangeReason InReason);

public:
	UPROPERTY(BlueprintReadOnly)
	FCCUnitId SourceUnitId;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId TargetUnitId;

	UPROPERTY(BlueprintReadOnly)
	int32 BuffType;

	UPROPERTY(BlueprintReadOnly)
	int32 BuffEffectType;

	UPROPERTY(BlueprintReadOnly)
	int32 OldHealth;

	UPROPERTY(BlueprintReadOnly)
	int32 NewHealth;

	UPROPERTY(BlueprintReadOnly)
	int32 Heal;

	UPROPERTY(BlueprintReadOnly)
	EHealthChangeReason Reason;
};

UCLASS(BlueprintType)
class UCCHealBuffEvent : public UCCHealBuffEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const { return ECCEventType::HealBuff; }

	void AppendEvent(FCCUnitId InSourceUnitId, FCCUnitId InTargetUnitId, int32 InBuffType, int32 InBuffEffectType, int32 InOldHealth, int32 InNewHealth, int32 InHeal, EHealthChangeReason InReason);

	int32 EventNum() const { return Events.Num(); }
	const TArray<UCCHealBuffPerUnit*>& GetEvents() const { return Events; }
};

UCLASS(BlueprintType)
class UCCUnitUAChangedEvent : public UCCUnitUAChangedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::UAChanged; }
};

UCLASS(BlueprintType)
class UCCUnitSAChangedEvent : public UCCUnitSAChangedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SAChanged; }
};

UCLASS(BlueprintType)
class UCCUnitOverKillChangedEvent : public UCCUnitOverKillChangedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::OverKillChanged; }
};

UCLASS(BlueprintType)
class UCCTargetSelectedEvent : public UCCTargetSelectedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::Target; }
};

UCLASS(BlueprintType)
class UCCAllyWipeoutEvent : public UCCAllyWipeoutEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::AllyWipeout; }
};

UCLASS(BlueprintType)
class UCCEndGameEvent : public UCCEndGameEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::EndGame; }
};

UCLASS(BlueprintType)
class UCCSetSkillTimeEvent : public UCCSetSkillTimeEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SetSkillCooldown; }
};

UCLASS(BlueprintType)
class UCCSetCheatSkillCooldownEvent : public UCCSetCheatSkillCooldownEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SetCheatSkillCooldown; }
};

UCLASS(BlueprintType)
class UCCCreateBuffEvent : public UCCCreateBuffEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::CreateBuff; }
};

UCLASS(BlueprintType)
class UCCRemoveBuffEvent : public UCCRemoveBuffEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::RemoveBuff; }
};

UCLASS(BlueprintType)
class UCCRemoveBuffFailedEvent : public UCCRemoveBuffFailedEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::RemoveBuffFailed;  }
};

UCLASS(BlueprintType)
class UCCImmuneBuffEvent : public UCCImmuneBuffEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::ImmuneBuff; }
};

UCLASS(BlueprintType)
class UCCSkillEffectHealthEvent : public UCCSkillEffectHealthEventBase
{
	GENERATED_BODY()

public:
	virtual ECCEventType GetEventType() const override { return ECCEventType::SkillEffectHealth; }

	void SetEvent(FCCUnitId InUnitId, int64 InOldHealth, int64 InNewHealth, int64 InAddedBaseHealth, int64 InAddedExtraHealth, int64 InShieldDamage, int64 InExtraShieldDamage, bool bInShieldWeakPoint,
		int32 InAddedOverKill, EHealthChangeReason InReason, bool bInCritical = false, bool bInDodged = false);
};

UCLASS(BlueprintType)
class UCCSkillEffectEvent : public UCCSkillEffectEventBase
{
	GENERATED_BODY()

public:
	UCCSkillEffectEvent() { SourceUnitId = CCUnitIdInvalid; }
	virtual ECCEventType GetEventType() const { return ECCEventType::SkillEffect; }

	void CreateDamageEventPerUnit(FCCUnitState& TargetUnit, int64 BaseDamage, int64 ExtraDamage, int64 ShieldDamage, int64 ExtraShieldDamage, bool bShieldWeakPoint,
		int32 OverKillPoint, EHealthChangeReason Reason, bool bNoDamage, bool bCritical = false, bool bCCDefence = false);
	void CreateHealEventPerUnit(const UCMS* CMS, FCCUnitState& TargetUnit, int64 Heal, EHealthChangeReason Reason);
};

UCLASS(BlueprintType)
class UCCPointVaryUsedEvent : public UCCPointVaryUsedEventBase
{
	GENERATED_BODY()

public:
	UCCPointVaryUsedEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::PointVaryUsed; }
};

UCLASS(BlueprintType)
class UCCPointVaryStateChangedEvent : public UCCPointVaryStateChangedEventBase
{
	GENERATED_BODY()

public:
	UCCPointVaryStateChangedEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::PointVaryStateChanged; }
};

UCLASS(BlueprintType)
class UCCPointVaryEndEvent : public UCCPointVaryEndEventBase
{
	GENERATED_BODY()

public:
	UCCPointVaryEndEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::PointVaryEnd; }
};

UCLASS(BlueprintType)
class UCCUpdateAttributesEvent : public UCCUpdateAttributesEventBase
{
	GENERATED_BODY()

public:
	UCCUpdateAttributesEvent() {
		UnitAttributeType = UnitAttributeTypeInvalid;
		UnitId = CCUnitIdInvalid;
		AddedValue = 0;
	}

	virtual ECCEventType GetEventType() const { return ECCEventType::UpdateAttributes; }
};

UCLASS(BlueprintType)
class UCCUpdateBuffDurationsEvent : public UCCUpdateBuffDurationsEventBase
{
	GENERATED_BODY()

public:
	UCCUpdateBuffDurationsEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::UpdateBuffDurations; }
};

UCLASS(BlueprintType)
class UCCMissionEvent : public UCCEvent
{
	GENERATED_BODY()

public:
	UCCMissionEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::CombatMission; }

public:
	UPROPERTY()
	TArray<FMissionType> CombatWeeklyMission;

	UPROPERTY()
	TArray<FCharMissionType> CombatCharacterMission;
};

UCLASS(BlueprintType)
class UCCRaidTurnSkillEffectEvent : public UCCEvent
{
	GENERATED_BODY()

public:
	UCCRaidTurnSkillEffectEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::RaidTurnSkillEffect; }

public:
	UPROPERTY()
	int32 SkillType;

	UPROPERTY()
	FString UserName;

	UPROPERTY()
	FCharacterType CharacterType;
};

UCLASS(BlueprintType)
class UCCRaidTurnSkillFinishedEvent : public UCCEvent
{
	GENERATED_BODY()

public:
	UCCRaidTurnSkillFinishedEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::RaidTurnSkillFinished; }
};

USTRUCT()
struct FRaidSkillUsedElement
{
	GENERATED_BODY()

	UPROPERTY()
	FCharacterId UsedChar;

	UPROPERTY()
	ENatureType NatureType;

	UPROPERTY()
	FSkillType UsedSkill;

	UPROPERTY()
	int32 Slot;

	UPROPERTY()
	TArray<int32> Attributes;
};

UCLASS(BlueprintType)
class UCCRaidSkillUsed : public UCCEvent
{
	GENERATED_BODY()

public:
	UCCRaidSkillUsed() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::RaidSkillUsed; }

public:
	UPROPERTY()
	TArray<FRaidSkillUsedElement> Elements;

	UPROPERTY()
	int32 Damage;
};

UCLASS(BlueprintType)
class UCCSelectedPatternUltimate : public UCCSelectedPatternUltimateBase
{
	GENERATED_BODY()

public:
	UCCSelectedPatternUltimate() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::SelectedPatternUltimate; }
};

UCLASS(BlueprintType)
class UCCEnemyAttackPassEvent : public UCCEnemyAttackPassEventBase
{
	GENERATED_BODY()

public:
	UCCEnemyAttackPassEvent() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::EnemyAttackPass; }
};

UCLASS(BlueprintType)
class UCCChangeCombatMultiSide : public UCCEvent
{
	GENERATED_BODY()

public:
	UCCChangeCombatMultiSide() {}
	virtual ECCEventType GetEventType() const { return ECCEventType::ChangeCombatMultiSide; }

public:
	UPROPERTY(BlueprintReadOnly)
	ECombatMultiSide CurrentCombatMultiSide;

	UPROPERTY(BlueprintReadOnly)
	int32 Wave;

	UPROPERTY(BlueprintReadOnly)
	int32 WaveEnemyNumSlots;

	UPROPERTY(BlueprintReadOnly)
	int32 WaveRowIndex;

	UPROPERTY(BlueprintReadOnly)
	bool bStartWave;
};
