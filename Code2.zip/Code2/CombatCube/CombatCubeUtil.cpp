#include "CombatCubeUtil.h"

#include "BondManager.h"
#include "HUDStore/HUDStore.h"
#include "Q6.h"

FCCUnitState& UCombatCubeStateUtil::FindUnitStateByUnitId(FCCCombatCubeState& State, FCCUnitId UnitId)
{
	return State.UnitsState.FindUnitState(UnitId, true);
}

void UCombatCubeStateUtil::ConvertCCBuffStateToBuffState(const FCCBuffState& InBuffState, FBuffState* OutBuffState, int32& OutShield, int32& OutMaxShield)
{
	if (!OutBuffState)
	{
		return;
	}

	OutBuffState->BuffId = InBuffState.BuffId;
	OutBuffState->BuffLevel = InBuffState.BuffLevel;
	OutBuffState->BuffType = InBuffState.BuffType;
	OutBuffState->Duration = InBuffState.Duration;
	OutBuffState->Multiple = InBuffState.Multiple;
	OutBuffState->BornCategory = InBuffState.BornCategory;
	OutBuffState->HitCount = InBuffState.HitCount;
	OutBuffState->SourceUnitId = InBuffState.SourceUnitId;

	if (InBuffState.Shield)
	{
		OutShield = InBuffState.Shield;
		OutMaxShield = InBuffState.MaxShield;
	}
}

void UCombatCubeStateUtil::ConvertCCUnitStateToUnitState(const FCCUnitState& InUnitState, FUnitState* OutUnitState)
{
	if (!OutUnitState)
	{
		return;
	}

	OutUnitState->UnitId = InUnitState.UnitId;
	OutUnitState->UnitType = InUnitState.UnitType.x;
	OutUnitState->Slot = InUnitState.Slot;
	OutUnitState->Faction = InUnitState.Faction;
	OutUnitState->Category = InUnitState.Category;
	OutUnitState->Level = InUnitState.Level;
	OutUnitState->Grade = InUnitState.Grade;
	OutUnitState->Health = InUnitState.Health;
	OutUnitState->UA = InUnitState.UA;
	OutUnitState->SA = InUnitState.SA;
	OutUnitState->OverKill = InUnitState.OverKill;

	ConvertCCSkillStateToSkillState(InUnitState.GetSkillStates(ESkillCategory::Normal), &(OutUnitState->Normals));
	ConvertCCSkillStateToSkillState(InUnitState.GetSkillStates(ESkillCategory::Ultimate), &(OutUnitState->Ultimates));
	ConvertCCSkillStateToSkillState(InUnitState.GetSkillStates(ESkillCategory::TurnBegin), &(OutUnitState->TurnBegins));
	ConvertCCSkillStateToSkillState(InUnitState.GetSkillStates(ESkillCategory::Support), &(OutUnitState->Supports));
	ConvertCCSkillStateToSkillState(InUnitState.GetSkillStates(ESkillCategory::Artifact), &(OutUnitState->Artifacts));

	ConvertCCSculptureInfoToSculptureInfo(InUnitState.Sculpture, OutUnitState->Sculpture);
	ConvertCCRelicInfoToRelicInfo(InUnitState.Relic, OutUnitState->Relic);
	ConvertCCUnitAttributesToUnitAttributes(InUnitState.UnitAttributes, OutUnitState->UnitAttributes);

	OutUnitState->MaxHealth = InUnitState.GetAttributeValue(EUnitAttribute::MaxHealth);
	OutUnitState->MaxUA = InUnitState.GetAttributeValue(EUnitAttribute::MaxUA);
	OutUnitState->MaxSA = InUnitState.GetAttributeValue(EUnitAttribute::MaxSA);
	OutUnitState->NatureType = InUnitState.GetNatureType();

	OutUnitState->Shield = 0;
	OutUnitState->MaxShield = 0;

	OutUnitState->Buffs.SetNum(InUnitState.Buffs.Num());
	for (int32 i = 0; i < InUnitState.Buffs.Num(); ++i)
	{
		ConvertCCBuffStateToBuffState(InUnitState.Buffs[i], &OutUnitState->Buffs[i], OutUnitState->Shield, OutUnitState->MaxShield);
	}

	// combat multi side
	OutUnitState->CombatMultiSide = InUnitState.CombatMultiSide;
	OutUnitState->SpawnedWaveIndex = InUnitState.SpawnedWaveIndex;
}

void UCombatCubeStateUtil::ConvertCCSkillStateToSkillState(const TArray<const FCCSkillState*>& InUnitState, TArray<FSkillState>* OutUnitState)
{
	OutUnitState->SetNum(InUnitState.Num());
	for (int i = 0; i < OutUnitState->Num(); ++i)
	{
		(*OutUnitState)[i].Cooldown = InUnitState[i]->Cooldown;
		(*OutUnitState)[i].Level = InUnitState[i]->Level;
		(*OutUnitState)[i].SkillType = InUnitState[i]->SkillType;
		(*OutUnitState)[i].SkillId = InUnitState[i]->SkillId;
		(*OutUnitState)[i].CoolTime = InUnitState[i]->CoolTime;
		(*OutUnitState)[i].WaitDown = InUnitState[i]->Waitdown;
		(*OutUnitState)[i].WaitTime = InUnitState[i]->WaitTime;
		(*OutUnitState)[i].UsingCount = InUnitState[i]->UsingCount;
		(*OutUnitState)[i].bPattern= InUnitState[i]->IsPattern;
	}
}

void UCombatCubeStateUtil::ConvertCCSculptureInfoToSculptureInfo(const FCCSculptureInfo& InSculptureInfo, FSculptureInfo& OutSculptureInfo)
{
	OutSculptureInfo.Type = InSculptureInfo.Type;
	OutSculptureInfo.Level = InSculptureInfo.Level;
	OutSculptureInfo.Tier = InSculptureInfo.Tier;
	OutSculptureInfo.Grade = InSculptureInfo.Grade;

	// useless in combat
	OutSculptureInfo.UserId = FUserId::InvalidValue();
	OutSculptureInfo.SculptureId = FSculptureId::InvalidValue();
	OutSculptureInfo.Xp = 0;
	OutSculptureInfo.Star = 0;
	OutSculptureInfo.Locked = 0;
	OutSculptureInfo.Newly = 0;
	OutSculptureInfo.Stashed = 0;
	OutSculptureInfo.Created = 0;
}

void UCombatCubeStateUtil::ConvertCCRelicInfoToRelicInfo(const FCCRelicInfo& InRelicInfo, FRelicInfo& OutRelicInfo)
{
	OutRelicInfo.Type = InRelicInfo.Type;
	OutRelicInfo.Level = InRelicInfo.Level;
	OutRelicInfo.Tier = InRelicInfo.Tier;
	OutRelicInfo.Grade = InRelicInfo.Grade;

	// useless in combat
	OutRelicInfo.UserId = FUserId::InvalidValue();
	OutRelicInfo.RelicId = FRelicId::InvalidValue();
	OutRelicInfo.Xp = 0;
	OutRelicInfo.Star = 0;
	OutRelicInfo.Locked = 0;
	OutRelicInfo.Newly = 0;
	OutRelicInfo.Stashed = 0;
	OutRelicInfo.Created = 0;
}

void UCombatCubeStateUtil::ConvertCCUnitAttributesToUnitAttributes(const UCCUnitAttributes* InAttributes, FUnitAttributes& OutAttributes)
{
	OutAttributes.Attack = InAttributes->GetAttributeValue(EUnitAttribute::Atk);
	OutAttributes.AttackVary = InAttributes->GetAttributeValue(EUnitAttribute::AtkVary);
	OutAttributes.AttackVaryPercent = InAttributes->GetAttributeValue(EUnitAttribute::AtkVaryper);

	OutAttributes.Defense = InAttributes->GetAttributeValue(EUnitAttribute::Def);
	OutAttributes.DefenseVary = InAttributes->GetAttributeValue(EUnitAttribute::DefVary);
	OutAttributes.DefenseVaryPercent = InAttributes->GetAttributeValue(EUnitAttribute::DefVaryper);
}

void UCombatCubeStateUtil::ConvertCCMasterStateToMasterState(const TArray<FCCUnitState>& InMasterState, TArray<FMasterState>* OutMasterState)
{
	OutMasterState->SetNum(InMasterState.Num());
	for (int32 i = 0; i < OutMasterState->Num(); ++i)
	{
		(*OutMasterState)[i].MasterId = InMasterState[i].UnitId;
		UCombatCubeStateUtil::ConvertCCSkillStateToSkillState(InMasterState[i].GetSkillStates(ESkillCategory::Pet), &(*OutMasterState)[i].Pets);
		UCombatCubeStateUtil::ConvertCCSkillStateToSkillState(InMasterState[i].GetSkillStates(ESkillCategory::Artifact), &(*OutMasterState)[i].Artifacts);
	}
}

void UCombatCubeStateUtil::ConvertCharacterInfoToCombatSeedUnit(const FCharacterInfo& InCharacterInfo, const FSculptureInfo* InSculpture, const FRelicInfo* InRelic, int32 SupportSkillLevel,
	EAttributeCategory InAttributeCategory, FCCCombatSeedUnit* OutSeedUnit)
{
	OutSeedUnit->UnitType = GetCMS()->GetUnitType(InCharacterInfo.Type);
	OutSeedUnit->Faction = ECCFaction::Ally;
	OutSeedUnit->Category = InAttributeCategory;
	OutSeedUnit->Level = InCharacterInfo.Level;
	OutSeedUnit->Grade = InCharacterInfo.Grade; //I don't know the origin enum type of characterInfo.Grade.

	OutSeedUnit->UltimateSkillLevel = InCharacterInfo.UltimateSkillLevel;
	OutSeedUnit->SupportSkillLevel = SupportSkillLevel;
	OutSeedUnit->TurnSkillLevels.Init(CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL, CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
	OutSeedUnit->TurnSkillLevels[0] = InCharacterInfo.TurnSkill1Level;
	OutSeedUnit->TurnSkillLevels[1] = InCharacterInfo.TurnSkill2Level;
	OutSeedUnit->TurnSkillLevels[2] = InCharacterInfo.TurnSkill3Level;
	OutSeedUnit->CharacterId = InCharacterInfo.CharacterId;

	if (InAttributeCategory == EAttributeCategory::Character)
	{
		OutSeedUnit->SupportSkillLevel = GetHUDStore().GetBondManager().GetSupportSkillLevel(InCharacterInfo.Type);
	}

	if (InSculpture)
	{
		OutSeedUnit->Sculpture = FCCSculptureInfo(*InSculpture);
	}

	if (InRelic)
	{
		OutSeedUnit->Relic = FCCRelicInfo(*InRelic);
	}
}

void UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(const FCCCombatSeedUnit& InCombatSeedUnit, FCCSpawnUnitParam* OutSpawnUnitParam,
	ESpawnReason SpawnReason, int32 Slot, int32 RebirthSkillCount, int32 HealthPermil, int32 LiveTurnCount)
{
	OutSpawnUnitParam->UnitType = InCombatSeedUnit.UnitType;
	OutSpawnUnitParam->Faction = InCombatSeedUnit.Faction;
	OutSpawnUnitParam->Category = InCombatSeedUnit.Category;
	OutSpawnUnitParam->Level = InCombatSeedUnit.Level;
	OutSpawnUnitParam->Grade = InCombatSeedUnit.Grade;
	OutSpawnUnitParam->UltimateSkillLevel = InCombatSeedUnit.UltimateSkillLevel;
	OutSpawnUnitParam->SupportSkillLevel = InCombatSeedUnit.SupportSkillLevel;
	OutSpawnUnitParam->TurnSkillLevels = InCombatSeedUnit.TurnSkillLevels;
	OutSpawnUnitParam->Sculpture = InCombatSeedUnit.Sculpture;
	OutSpawnUnitParam->Relic = InCombatSeedUnit.Relic;
	OutSpawnUnitParam->Slot = Slot;
	OutSpawnUnitParam->HealthPermil = HealthPermil;
	OutSpawnUnitParam->RebirthSkillCount = RebirthSkillCount;
	OutSpawnUnitParam->LiveTurnCount = RebirthSkillCount;
	OutSpawnUnitParam->SpawnReason = SpawnReason;
	OutSpawnUnitParam->CharacterId = InCombatSeedUnit.CharacterId;
	OutSpawnUnitParam->CombatMultiSide = InCombatSeedUnit.CombatMultiSide;
}

static bool MatchLiveTurnCount(const FCMSMonsterPatternRow& PRow, FCCUnitState* SourceUnit)
{
	// less or equal or greater live turn count
	if (PRow.LiveTurnCount[0] != 0 || PRow.LiveTurnCount[1] != 0 || PRow.LiveTurnCount[2] != 0)
	{
		int32 Matched = 0;
		if (PRow.LiveTurnCount[0] != 0)
		{
			if (SourceUnit->LiveTurnCount < PRow.LiveTurnCount[0])
			{
				++Matched;
			}
		}
		else
		{
			++Matched;
		}

		if (PRow.LiveTurnCount[1] != 0)
		{
			if (SourceUnit->LiveTurnCount == PRow.LiveTurnCount[1])
			{
				++Matched;
			}
		}
		else
		{
			++Matched;
		}

		if (PRow.LiveTurnCount[2] != 0)
		{
			if (SourceUnit->LiveTurnCount > PRow.LiveTurnCount[2])
			{
				++Matched;
			}
		}
		else
		{
			++Matched;
		}

		if (Matched == PRow.LiveTurnCount.Num())
		{
			return true;
		}

		return false;
	}

	return true;
}

static bool MatchHPRatio(const FCMSMonsterPatternRow& PRow, FCCUnitState* SourceUnit)
{
	// less or equal or greater current HP / max hp
	if (PRow.HPRatio[0] != 0 || PRow.HPRatio[1] != 0 || PRow.HPRatio[2] != 0)
	{
		int32 Ratio = (SourceUnit->Health * 1000) / SourceUnit->GetAttributeValue(EUnitAttribute::MaxHealth);

		int32 Matched = 0;
		if (PRow.HPRatio[0] != 0)
		{
			if (Ratio < PRow.HPRatio[0])
			{
				++Matched;
			}
		}
		else
		{
			++Matched;
		}

		if (PRow.HPRatio[1] != 0)
		{
			if (Ratio == PRow.HPRatio[1])
			{
				++Matched;
			}
		}
		else
		{
			++Matched;
		}

		if (PRow.HPRatio[2] != 0)
		{
			if (Ratio > PRow.HPRatio[2])
			{
				++Matched;
			}
		}
		else
		{
			++Matched;
		}

		if (Matched == PRow.HPRatio.Num())
		{
			return true;
		}

		return false;
	}

	return true;
}

static bool MatchUsableCount(const FCMSMonsterPatternRow& PRow, FCCUnitState* SourceUnit, const FCCPatternState& PState)
{
	// this pattern live in skill usable count.
	if (PRow.UsableCount != 0)
	{
		const FCCSkillState* S = SourceUnit->GetSkillState(PState.SkillId);
		if (S->UsingCount < PRow.UsableCount)
		{
			return true;
		}

		return false;
	}

	return true;
}

bool UCombatCubeStateUtil::IsPatternMatched(const FCMSMonsterPatternRow& PRow, FCCUnitState* SourceUnit, const FCCPatternState& PState)
{
	return MatchLiveTurnCount(PRow, SourceUnit) && MatchHPRatio(PRow, SourceUnit) && MatchUsableCount(PRow, SourceUnit, PState);
}

bool UCombatCubeStateUtil::IsCurrentCombatMultiSide(ECombatMultiSide InCurrentCombatMultiSide, ECombatMultiSide InCombatMultiSide, int32 InCurrentWaveIndex, int32 InWaveIndex)
{
	// check spawned wave index for combat multi side both
	if (InCombatMultiSide == ECombatMultiSide::Both)
	{
		if (InCurrentWaveIndex != InWaveIndex)
		{
			return false;
		}

		return true;
	}

	if (InCurrentCombatMultiSide != InCombatMultiSide)
	{
		return false;
	}

	return true;
}

int32 UCombatCubeStateUtil::GetCombatMultiSideWaveRowIndex(const FCCCombatSeed& InCombatSeed, ECombatMultiSide InCurrentCombatMultiSide, const int32 InWaveRowIndex)
{
	int32 WaveRowIndex = InWaveRowIndex * 2;

	if (InCurrentCombatMultiSide == ECombatMultiSide::Sub)
	{
		WaveRowIndex++;
	}

	const int32 LastWaveIndex = FMath::Max(0, InCombatSeed.Seed.WaveMonsters.Num() - 1);
	WaveRowIndex = FMath::Min(WaveRowIndex, LastWaveIndex);

	return WaveRowIndex;
}
