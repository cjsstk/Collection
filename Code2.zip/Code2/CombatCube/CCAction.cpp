#include "CCAction.h"

#include "CCEvent.h"
#include "CombatCube.h"
#include "CombatCubeUtil.h"
#include "Q6Log.h"
#include "Formula.h"
#include "Q6.h"
#include "Q6Define.h"
#include "Q6Util.h"
#include "Q6GameInstance.h"
#include "HUDStore.h"
#include "SystemConstHelper.h"
#include "HSAction.h"

const ECCFaction VERSA_FACTION = ECCFaction::Ally;
const ECCFaction CHAIN_FACTION = ECCFaction::Ally;

static void UseSkill(const FActionContext& Context, FCCCombatCubeState& InOutState,
	const FCCSkillId& SkillId, const FCCUnitId& UnitId, FCCUnitId TargetUnitId, ESkillCategory InBornCategory, EMoment InMoment, bool bIsPlayerUseSkill, bool bPattern);
static void _ReadyMomentSkill(FCCCombatCubeState& InOutState, FCCUnitState& Unit, ESkillCategory SkillCategory, EMoment Moment,
	const FCCUnitId& TargetUnitId, const FCCBuffId& ExpireBuffId = CCBuffIdInvalid);
static void _ChangePhase(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCTurnPhase NewPhase);
static bool _ApplyChainSkill(const FActionContext& Context, FCCCombatCubeState& InOutState);
static void _ClearSubParts(const FActionContext& Context, FCCCombatCubeState& InOutState, const FCCUnitState& Main);
static void _SpawnCombatMultiSideMonsters(const FActionContext& Context, FCCCombatCubeState& InOutState, bool bInIsNeedToSpawn);
static void _DespawnOldWaveMonsters(const FActionContext& Context, FCCCombatCubeState& InOutState);

static void BroadcastRemoveBuffEvent(const FActionContext& Context, const FCCUnitId& UnitId,
	const FCCBuffId& BuffId, ERemoveBuffReason Reason, bool IsVersa)
{
	UCCRemoveBuffEvent* RemoveBuffEvent = NewObject<UCCRemoveBuffEvent>();
	RemoveBuffEvent->UnitIds.Add(UnitId);
	RemoveBuffEvent->BuffIds.Add(BuffId);
	RemoveBuffEvent->Reason = Reason;
	RemoveBuffEvent->IsVersa = IsVersa;
	Context.OnEvent.Broadcast(RemoveBuffEvent);
}

static void BroadcastRemoveBuffEventSameTime(const FActionContext& Context, const TArray<FCCUnitId>& UnitIds,
	const TArray<FCCBuffId>& BuffIds, ERemoveBuffReason Reason, bool IsVersa)
{
	UCCRemoveBuffEvent* RemoveBuffEvent = NewObject<UCCRemoveBuffEvent>();
	RemoveBuffEvent->UnitIds = UnitIds;
	RemoveBuffEvent->BuffIds = BuffIds;
	RemoveBuffEvent->Reason = Reason;
	RemoveBuffEvent->IsVersa = IsVersa;
	Context.OnEvent.Broadcast(RemoveBuffEvent);
}

static void BroadcastRemoveBuffFailedEvent(const FActionContext& Context, const FCCUnitId& UnitId,
	ERemoveBuffFailedReason Reason, EApplyTag NoApplyTag)
{
	UCCRemoveBuffFailedEvent* RemoveBuffFailedEvent = NewObject<UCCRemoveBuffFailedEvent>();
	RemoveBuffFailedEvent->UnitId = UnitId;
	RemoveBuffFailedEvent->Reason = Reason;
	RemoveBuffFailedEvent->NoApplyTag = NoApplyTag;
	Context.OnEvent.Broadcast(RemoveBuffFailedEvent);
}

template <typename ElementType>
void ShuffleArray(const FActionContext& Context, TArray<ElementType>& InOutArray)
{
	for (int32 i = InOutArray.Num() - 1; i >= 1; --i)
	{
		int Candidate = Context.MT19937->Gen() % (i + 1);
		InOutArray.Swap(Candidate, i);
	}
}

static void _ReportError(const FActionContext& Context, bool bIsPlayer, ECCErrorCode InCode)
{
	if (!bIsPlayer)
	{
		return;
	}

	UCCReportErrorEvent* Event = NewObject<UCCReportErrorEvent>();
	Event->Code = (int32)InCode;
	Context.OnEvent.Broadcast(Event);
}

static void _WeeklyMissionEvent(const FActionContext& InContext
	, FCCCombatCubeState& InOutState, const EMissionCategory InCategory)
{
	const UCMS* CMS = GetCMS();

	for (const FCCWeeklyMissionInfo& WeeklyMissionInfo : InOutState.MissionState.WeeklyMissionStates)
	{
		if (WeeklyMissionInfo.Category != InCategory)
		{
			continue;
		}

		const FCMSMissionRow& MissionRow = CMS->GetMissionRowOrDummy(WeeklyMissionInfo.Type);
		if (MissionRow.IsInvalid())
		{
			continue;
		}

		if (!MissionRow.Combat)
		{
			continue;
		}

		TArray<FMissionType> CombatWeeklyMission;
		CombatWeeklyMission.Add(WeeklyMissionInfo.Type);

		UCCMissionEvent* Event = NewObject<UCCMissionEvent>();
		Event->CombatWeeklyMission = CombatWeeklyMission;
		InContext.OnEvent.Broadcast(Event);
	}
}

static void _CharacterMissionEvent(const FActionContext& InContext
	, FCCCombatCubeState& InOutState, const ECharMissionCategory InCategory, const FCCUnitState* InUnitState)
{
	const UCMS* CMS = GetCMS();

	for (const FCCCharacterMissionInfo& CharacterMissionInfo : InOutState.MissionState.CharacterMissionStates)
	{
		if (CharacterMissionInfo.Category != InCategory)
		{
			continue;
		}

		const FCMSCharMissionRow& CharMissionRow = CMS->GetCharMissionRowOrDummy(CharacterMissionInfo.Type);
		if (CharMissionRow.IsInvalid())
		{
			continue;
		}

		if (!CharMissionRow.Combat)
		{
			continue;
		}

		if (InUnitState && InUnitState->UnitType != CharacterMissionInfo.UnitType)
		{
			continue;
		}

		TArray<FCharMissionType> CombatCharacterMission;
		CombatCharacterMission.Add(CharacterMissionInfo.Type);

		UCCMissionEvent* Event = NewObject<UCCMissionEvent>();
		Event->CombatCharacterMission = CombatCharacterMission;
		InContext.OnEvent.Broadcast(Event);
	}
}

template<class T>
static T GetMissionCategoryBySkillUsedEvent(FCCCombatCubeState& InOutState, const UCCSkillUsedEvent* InEvent)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(InEvent->SkillType);
	if (SkillRow.IsInvalid())
	{
		return T::KillEnemy;
	}

	switch (InEvent->SkillCategory)
	{
		case ESkillCategory::Chain:
		{
			switch (SkillRow.SkillNote)
			{
				case ESkillNote::Ace:
					return T::UseAceChain;
				case ESkillNote::Break:
					return T::UseBreakChain;
				case ESkillNote::Closer:
					return T::UseCloserChain;
			}
		}
		break;
		case ESkillCategory::Normal:
		{
			switch (SkillRow.SkillNote)
			{
				case ESkillNote::Ace:
					return T::UseAceAttack;
				case ESkillNote::Break:
					return T::UseBreakAttack;
				case ESkillNote::Closer:
					return  T::UseCloserAttack;
			}
		}
		break;
		case ESkillCategory::TurnBegin:
		{
			const FCCUnitState& UnitState = InOutState.UnitsState.FindUnitState(InEvent->UnitId);
			if (UnitState.UnitId == CCUnitIdInvalid
				|| UnitState.Faction == ECCFaction::Enemy
				|| UnitState.Category != EAttributeCategory::Character
				|| UnitState.IsDead())
			{
				return T::KillEnemy;
			}

			const FCMSUnitRow& Unit = GetCMS()->GetUnitRowOrDummy(UnitState.UnitType);
			if (Unit.IsInvalid())
			{
				return T::KillEnemy;
			}

			int32 FindTurnIndex = Unit.GetTurnSkills().IndexOfByPredicate(
				[&InEvent](const FCMSSkillRow* Elem)
			{
				return Elem->Type == InEvent->SkillType;
			});
			if (FindTurnIndex == INDEX_NONE)
			{
				return T::KillEnemy;
			}

			EMissionCategory MissionCategory(EMissionCategory::KillEnemy);
			switch (FindTurnIndex)
			{
				case 0:
					return T::UseTurnSkillA;
				case 1:
					return T::UseTurnSkillB;
				case 2:
					return T::UseTurnSkillC;
			}
		}
		break;
	}

	return T::KillEnemy;
}

template<class T>
static T GetMissionCategoryByUnitDeadEvent(FCCCombatCubeState& InOutState, const FCCUnitId& InUnitId)
{
	const FCCUnitState& UnitState = InOutState.UnitsState.FindUnitState(InUnitId);
	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(UnitState.UnitType));
	switch (CMSUnitRow.NatureType)
	{
		case ENatureType::Fire:
			return T::KillFireEnemy;
		case ENatureType::Wind:
			return T::KillWindEnemy;
		case ENatureType::Water:
			return T::KillWaterEnemy;
		case ENatureType::Light:
			return T::KillLightEnemy;
		case ENatureType::Dark:
			return T::KillDarkEnemy;
	}

	return T::KillEnemy;
}

static void _UseSkillMissionEvent(const FActionContext& InContext
	, FCCCombatCubeState& InOutState, const UCCSkillUsedEvent* InEvent, const FCCUnitState* InUnitState)
{
	switch (InEvent->SkillCategory)
	{
		case ESkillCategory::Chain:
		{
			_WeeklyMissionEvent(InContext, InOutState, EMissionCategory::UseChain);
			_CharacterMissionEvent(InContext, InOutState, ECharMissionCategory::UseChain, InUnitState);

			EMissionCategory MissionCategory = GetMissionCategoryBySkillUsedEvent<EMissionCategory>(InOutState, InEvent);
			if (MissionCategory != EMissionCategory::KillEnemy)
			{
				_WeeklyMissionEvent(InContext, InOutState, MissionCategory);
			}

			ECharMissionCategory CharMissionCategory = GetMissionCategoryBySkillUsedEvent<ECharMissionCategory>(InOutState, InEvent);
			if (CharMissionCategory != ECharMissionCategory::KillEnemy)
			{
				_CharacterMissionEvent(InContext, InOutState, CharMissionCategory, InUnitState);
			}
		}
		break;
		case ESkillCategory::Double:
		{
			_WeeklyMissionEvent(InContext, InOutState, EMissionCategory::UseStraightChain);
			_CharacterMissionEvent(InContext, InOutState, ECharMissionCategory::UseStraightChain, InUnitState);
		}
		break;
		case ESkillCategory::Normal:
		case ESkillCategory::TurnBegin:
		{
			EMissionCategory MissionCategory = GetMissionCategoryBySkillUsedEvent<EMissionCategory>(InOutState, InEvent);
			if (MissionCategory != EMissionCategory::KillEnemy)
			{
				_WeeklyMissionEvent(InContext, InOutState, MissionCategory);
			}

			ECharMissionCategory CharMissionCategory = GetMissionCategoryBySkillUsedEvent<ECharMissionCategory>(InOutState, InEvent);
			if (CharMissionCategory != ECharMissionCategory::KillEnemy)
			{
				_CharacterMissionEvent(InContext, InOutState, CharMissionCategory, InUnitState);
			}
		}
		break;
		case ESkillCategory::Ultimate:
		{
			_WeeklyMissionEvent(InContext, InOutState, EMissionCategory::UseUASkill);
			_CharacterMissionEvent(InContext, InOutState, ECharMissionCategory::UseUASkill, InUnitState);
		}
		break;
		case ESkillCategory::Support:
		{
			_WeeklyMissionEvent(InContext, InOutState, EMissionCategory::UseSupportSkill);
			_CharacterMissionEvent(InContext, InOutState, ECharMissionCategory::UseSupportSkill, InUnitState);
		}
		break;
	}
}

static void _KillMissionEvent(const FActionContext& Context, FCCCombatCubeState& InOutState
	, const FCCUnitId& InUnitId)
{
	_WeeklyMissionEvent(Context, InOutState, EMissionCategory::KillEnemy);
	_CharacterMissionEvent(Context, InOutState, ECharMissionCategory::KillEnemy, nullptr);

	EMissionCategory MissionCategory = GetMissionCategoryByUnitDeadEvent<EMissionCategory>(InOutState, InUnitId);
	if (MissionCategory != EMissionCategory::KillEnemy)
	{
		_WeeklyMissionEvent(Context, InOutState, MissionCategory);
	}

	ECharMissionCategory CharMissionCategory = GetMissionCategoryByUnitDeadEvent<ECharMissionCategory>(InOutState, InUnitId);
	if (CharMissionCategory != ECharMissionCategory::KillEnemy)
	{
		_CharacterMissionEvent(Context, InOutState, CharMissionCategory, nullptr);
	}
}

static void _DeadEvent(const FActionContext& Context, FCCCombatCubeState& InOutState,
	const TArray<FCCUnitId>& UnitIds, const FCCSkillId& SkillId, bool bIsAlly, bool bSubPartClearing)
{
	UCCUnitDeadEvent* Event = NewObject<UCCUnitDeadEvent>();
	Event->UnitIds = UnitIds;
	Event->DrivenSkillId = SkillId;
	Event->IsSubPartClearing = bSubPartClearing;
	Context.OnEvent.Broadcast(Event);

	if (!bIsAlly)
	{
		for (const FCCUnitId& UnitId : UnitIds)
		{
			_KillMissionEvent(Context, InOutState, UnitId);

			InOutState.UnitsState.CheckClearUnits(UnitId);
		}
	}
}

static void _DeadEvent(const FActionContext& Context, FCCCombatCubeState& InOutState,
	const FCCUnitId& UnitId, const FCCSkillId& SkillId, bool bIsAlly, bool bSubPartClearing)
{
	TArray<FCCUnitId> UnitIds;
	UnitIds.Add(UnitId);

	_DeadEvent(Context, InOutState, UnitIds, SkillId, bIsAlly, bSubPartClearing);
}

static void _EndGame(const FActionContext& InContext, FCCCombatCubeState& InOutState, ECCResult InResult, bool bInParamCombat, ECCEndReason InEndReason)
{
	InOutState.Result = InResult;
	InOutState.bInCombat = bInParamCombat;

	UCCEndGameEvent* EndGameEvent = NewObject<UCCEndGameEvent>();
	EndGameEvent->Result = InOutState.Result;
	EndGameEvent->EndReason = InEndReason;
	EndGameEvent->ContentType = InOutState.CombatSeed.Content;
	EndGameEvent->TurnPhase = InOutState.TurnState.CurrentPhase;
	EndGameEvent->FinalTurnCount = InOutState.TurnState.TurnCount;
	EndGameEvent->GemWipeoutContinueCount = InOutState.GemWipeoutContinueCount;
	EndGameEvent->BossHpRatio = InOutState.GetBossHpRatio();

	for (const FSeedArtifact& A : InOutState.CombatSeed.Seed.ArtifactAvailable)
	{
		EndGameEvent->ArtifactAvailable.Push(A.Available);
	}
	InContext.OnEvent.Broadcast(EndGameEvent);
}

static int32 HasCrowdControlState(const FCCBuffState& Buff, ECrowdControl Control)
{
	ensure(Control != ECrowdControl::ExtraDamage);

	for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(Buff, Control))
	{
		if (Control == ECrowdControl::Provoke)
		{
			return Buff.SourceUnitId.X;
		}

		return Formula::InterpolatedBySkillLevelOrTier(Buff.BuffLevel, Effect->Param2Min, Effect->Param2, Buff.BornCategory);
	}

	return 0;
}

static bool IsVersaBuff(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCFaction SourceFaction, int32 BuffType)
{
	if (SourceFaction != VERSA_FACTION)
	{
		return false;
	}

	const FCMSFormulaConstRow& Row = GetCMS()->GetFormulaConstValues(InOutState.UnitsState.EntryAliveUnitCount[(int32)VERSA_FACTION]);
	if (Row.VersaBuffId == BuffType)
	{
		return true;
	}

	const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(BuffType));
	for (const FCMSBuffEffectRow* E : BuffRow.GetBuffEffect())
	{
		if (E->BuffEffectCategory != EBuffEffectCategory::ModifyCrowdControl)
		{
			continue;
		}

		const FCMSCrowdControlRow& InRow = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(E->Param1));
		if (InRow.CrowdControl == ECrowdControl::Versa)
		{
			return true;
		}
	}

	return false;
}

static bool IsVersaSkill(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCFaction SourceFaction, int32 SkillType)
{
	if (SourceFaction != VERSA_FACTION)
	{
		return false;
	}

	const FCMSFormulaConstRow& Row = GetCMS()->GetFormulaConstValues(InOutState.UnitsState.EntryAliveUnitCount[(int32)VERSA_FACTION]);
	for (int32 Type : Row.VersaSkillIds)
	{
		if (Type == SkillType)
		{
			return true;
		}
	}

	return false;
}

static TArray<FCCUnitId> _GetTargetUnits(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId SourceUnitId,
	ECCFaction SourceUnitFaction, ETargetType InTargetType, FCCUnitId InTargetUnitId, const UCMS* CMS, ESkillCategory SkillCategory)
{
	TArray<FCCUnitId> TargetUnitIds;

	FCCUnitState& SourceUnit = InOutState.UnitsState.FindUnitState(SourceUnitId, true);
	FCCUnitId ProvokeTargetUnitId(SourceUnit.GetCrowdControlState(CMS, ECrowdControl::Provoke));
	if (ProvokeTargetUnitId.X > CCUnitIdInvalid.X
		&& InTargetType == ETargetType::HostileSingle)
	{
		Q6JsonLogObiwan(Display, "unit provoked", Q6KV("UnitType", SourceUnit.UnitType.x));
		TargetUnitIds.Add(ProvokeTargetUnitId);
	}
	else if (InTargetType == ETargetType::FriendlyAll)
	{
		TargetUnitIds = (SourceUnitFaction == ECCFaction::Ally) ? InOutState.UnitsState.GetAllyUnits() : InOutState.UnitsState.GetEnemyUnits();
	}
	else if (InTargetType == ETargetType::FriendlyOther)
	{
		TargetUnitIds = (SourceUnitFaction == ECCFaction::Ally) ? InOutState.UnitsState.GetAllyUnits() : InOutState.UnitsState.GetEnemyUnits();
		TargetUnitIds.Remove(SourceUnitId);
	}
	else if (InTargetType == ETargetType::HostileSingle ||
		InTargetType == ETargetType::HostileAll)
	{
		TargetUnitIds = (SourceUnitFaction == ECCFaction::Enemy) ? InOutState.UnitsState.GetAllyUnits() : InOutState.UnitsState.GetAutoTargetEnemyUnits();
	}
	else if (InTargetType == ETargetType::Self)
	{
		bool IsMasterSource = InOutState.UnitsState.IsMaster(SourceUnitId);

		if (SkillCategory == ESkillCategory::Support)
		{
			TargetUnitIds.Add(InTargetUnitId);
		}
		else if (IsMasterSource)
		{
			TargetUnitIds.Add(InTargetUnitId);
		}
		else
		{
			TargetUnitIds.Add(SourceUnitId);
		}
	}
	else
	{
		ensure(0);
	}

	// Remove dead units
	TargetUnitIds.RemoveAll([&InOutState](const FCCUnitId& TargetUnitId) {
		FCCUnitState& Unit = InOutState.UnitsState.FindUnitState(TargetUnitId);
		return Unit.IsDead();
	});

	FCCUnitId CurTargetUnitId = CCUnitIdInvalid;
	if (SourceUnitFaction == ECCFaction::Ally)
	{
		if (InTargetUnitId != CCUnitIdInvalid)
		{
			CurTargetUnitId = InTargetUnitId;
		}
		else
		{
			CurTargetUnitId = InOutState.TurnState.PlayerTargetUnitId;
		}
	}
	else if (SourceUnitFaction == ECCFaction::Enemy)
	{
		CurTargetUnitId = InTargetUnitId;
	}

	if (InTargetType == ETargetType::HostileSingle)
	{
		if (InOutState.SkillProp[(int32)SkillCategory].bUsableToDeadUnit) // even through dead unit, force add.
		{
			TargetUnitIds.Empty();
			TargetUnitIds.Add(CurTargetUnitId);
		}
		else if (SkillCategory == ESkillCategory::Support
			&& SourceUnitFaction == ECCFaction::Ally)
		{
			TargetUnitIds.Empty();
			TargetUnitIds.Add(InOutState.TurnState.PlayerTargetUnitId);
		}
		else if (!TargetUnitIds.FindByKey(CurTargetUnitId) && SkillCategory != ESkillCategory::Moment)
		{
			if (SourceUnitFaction == ECCFaction::Enemy)
			{
				ShuffleArray(Context, TargetUnitIds);
			}

			if (TargetUnitIds.Num() > 0)
			{
				TargetUnitIds.SetNum(1);
			}
			else
			{
				Q6JsonLog(Warning, "all targets are dead.", Q6KV("unit", SourceUnitId), Q6KV("skill category", (int32)SkillCategory));
			}
		}
		else
		{
			TargetUnitIds.Empty();
			if (CurTargetUnitId != CCUnitIdInvalid)
			{
				TargetUnitIds.Add(CurTargetUnitId);
			}
		}
	}
	else if (InTargetType == ETargetType::FriendlyAll ||
		InTargetType == ETargetType::HostileAll ||
		InTargetType == ETargetType::FriendlyOther)
	{
		int32 CurTargetIndex = TargetUnitIds.IndexOfByKey(CurTargetUnitId);
		if (CurTargetIndex != INDEX_NONE)
		{
			TargetUnitIds.Swap(0, CurTargetIndex);
		}
	}

	return TargetUnitIds;
}

static TArray<FCCUnitId> _GetAttackPassUnits(FCCCombatCubeState& InOutState, ECCFaction SourceUnitFaction)
{
	TArray<FCCUnitState*> CandidateUnits;
	TArray<FCCUnitState*> TargetUnits;

	if (SourceUnitFaction == ECCFaction::Ally)
	{
		CandidateUnits = InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally);
		TargetUnits = InOutState.UnitsState.GetAliveUnits(ECCFaction::Enemy);
	}
	else
	{
		CandidateUnits = InOutState.UnitsState.GetAliveUnits(ECCFaction::Enemy);
		TargetUnits = InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally);
	}

	int32 AliveTarget = TargetUnits.Num();

	TArray<FCCUnitId> PassUnitIds;
	if (AliveTarget)
	{
		return PassUnitIds;
	}

	for (FCCUnitState* Unit: CandidateUnits)
	{
		if (!Unit->HasSkillOnAttack())
		{
			continue;
		}

		Unit->MakeToAttackPass();
		PassUnitIds.Add(Unit->UnitId);
	}

	return PassUnitIds;
}

static void _SetSkillTime(const FActionContext& Context, FCCCombatCubeState& InOutState,
	FCCUnitState& Unit, const FCCSkillId& SkillId, int32 InCooldown, int32 InWaitdown, ESetSkillTimeType InSetSkillTimeType = ESetSkillTimeType::None, int32 InTimeDiff = 0)
{
	FCCSkillState* SkillState = Unit.GetSkillState(SkillId);
	if (!SkillState)
	{
		return;
	}

	SkillState->Cooldown = FMath::Max(0, InCooldown);
	SkillState->Waitdown = FMath::Max(0, InWaitdown);

	UCCSetSkillTimeEvent* Event = NewObject<UCCSetSkillTimeEvent>();
	Event->UnitId = Unit.UnitId;
	Event->SkillId = SkillState->SkillId;
	Event->Cooldown = SkillState->Cooldown;
	Event->Waitdown = SkillState->Waitdown;
	Event->TimeDiff = InTimeDiff;
	Event->SetSkillTimeType = InSetSkillTimeType;
	Context.OnEvent.Broadcast(Event);
}

static void _SetCheatCooldown(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitState& Unit, const FCCSkillId& SkillId, int32 InCooldown)
{
	FCCSkillState* SkillState = Unit.GetSkillState(SkillId);
	if (!SkillState)
	{
		return;
	}

	SkillState->Cooldown = FMath::Max(0, InCooldown);
	SkillState->Waitdown = FMath::Max(0, InCooldown);

	UCCSetCheatSkillCooldownEvent* Event = NewObject<UCCSetCheatSkillCooldownEvent>();
	Event->UnitId = Unit.UnitId;
	Event->SkillId = SkillState->SkillId;
	Event->Cooldown = SkillState->Cooldown;
	Context.OnEvent.Broadcast(Event);
}

void _SetNewUA(const FActionContext& Context, FCCUnitState& Unit, int32 SkillType, int64 InNewUA, EPointChangeReason InReason)
{
	if (Unit.IsDead())
	{
		return;
	}

	int64 OldUA = Unit.UA;
	Unit.UA = FMath::Clamp(InNewUA, 0LL, Unit.GetAttributeValue(EUnitAttribute::MaxUA));

	UCCUnitUAChangedEvent* ChangeEvent = NewObject<UCCUnitUAChangedEvent>();
	ChangeEvent->UnitId = Unit.UnitId;
	ChangeEvent->SkillType = SkillType;
	ChangeEvent->OldUA = OldUA;
	ChangeEvent->NewUA = Unit.UA;
	ChangeEvent->AddedUA = Unit.UA - OldUA;
	ChangeEvent->Reason = InReason;
	Context.OnEvent.Broadcast(ChangeEvent);
}

void _SetNewSA(const FActionContext& Context, FCCUnitState& Unit, int32 SkillType, int64 InNewSA, EPointChangeReason InReason)
{
	if (Unit.IsDead())
	{
		return;
	}

	int64 OldSA = Unit.SA;
	Unit.SA = FMath::Clamp(InNewSA, 0LL, Unit.GetAttributeValue(EUnitAttribute::MaxSA));

	UCCUnitSAChangedEvent* ChangeEvent = NewObject<UCCUnitSAChangedEvent>();
	ChangeEvent->UnitId = Unit.UnitId;
	ChangeEvent->SkillType = SkillType;
	ChangeEvent->OldSA = OldSA;
	ChangeEvent->NewSA = Unit.SA;
	ChangeEvent->AddedSA = Unit.SA - OldSA;
	ChangeEvent->Reason = InReason;
	Context.OnEvent.Broadcast(ChangeEvent);
}

void _SetNewOverKill(const FActionContext& Context, FCCUnitState& Unit, int32 GotOverKill, int32 AliveAllyCount, EPointChangeReason InReason)
{
	if (!Unit.CanGetOverkill() && GotOverKill > 0)
	{
		Q6JsonLog(Error, "this unit can not get overkills.", Q6KV("unit", Unit.UnitType), Q6KV("overkill", GotOverKill));
		GotOverKill = 0;
	}

	int32 OldOverKill = Unit.OverKill;
	int32 NewOverKill = Unit.OverKill + GotOverKill;
	Unit.OverKill = FMath::Clamp(NewOverKill, 0, GetCMS()->GetFormulaConstValues(AliveAllyCount).OverKillLimit);
	Q6JsonLog(Display, "set new overkill", Q6KV("unit", Unit.UnitType), Q6KV("old", OldOverKill), Q6KV("new", Unit.OverKill));

	UCCUnitOverKillChangedEvent* ChangeEvent = NewObject<UCCUnitOverKillChangedEvent>();
	ChangeEvent->UnitId = Unit.UnitId;
	ChangeEvent->OldOverKill = OldOverKill;
	ChangeEvent->NewOverKill = Unit.OverKill;
	ChangeEvent->AddedOverKill = Unit.OverKill - OldOverKill;
	ChangeEvent->Reason = InReason;
	Context.OnEvent.Broadcast(ChangeEvent);
}

void _SetHealth(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitState& Unit, FCCSkillId SkillId, int64 NewHealth, bool bImmediateKill, bool bSubPartClearing, TArray<FCCUnitId>* OutDeadEventSentUnits)
{
	int64 OldHealth = Unit.Health;

	EHealthChangeReason Reason;
	if (NewHealth > Unit.Health)
	{
		Reason = EHealthChangeReason::Heal;
	}
	else
	{
		Reason = EHealthChangeReason::Damage;
	}

	if (Unit.GetCrowdControlState(GetCMS(), ECrowdControl::HealBlock) > 0 && Reason == EHealthChangeReason::Heal)
	{
		Q6JsonLog(Display, "heal block", Q6KV("unit", Unit.UnitType));
		NewHealth = OldHealth;
		Reason = EHealthChangeReason::HealBlock;
	}

	if (bImmediateKill)
	{
		NewHealth = 0;
		Reason = EHealthChangeReason::ImmediateKill;
	}

	Unit.Health = FMath::Clamp(NewHealth, 0LL, Unit.GetAttributeValue(EUnitAttribute::MaxHealth));

	UCCUnitHealthChangedEvent* HealthChangeEvent = NewObject<UCCUnitHealthChangedEvent>();
	HealthChangeEvent->SetEvent(Unit.UnitId, SkillId, OldHealth, Unit.Health, Unit.Health - OldHealth, Reason);
	Context.OnEvent.Broadcast(HealthChangeEvent);

	if (OldHealth > 0 && Unit.IsDead())
	{
		_ClearSubParts(Context, InOutState, Unit);
		_DeadEvent(Context, InOutState, Unit.UnitId, SkillId, Unit.IsAlly(), bSubPartClearing);

		if (OutDeadEventSentUnits)
		{
			OutDeadEventSentUnits->Add(Unit.UnitId);
		}
	}
}

static EApplyTag NatureTypeToApplyTag(ENatureType InNature)
{
	switch (InNature)
	{
	case ENatureType::Dark:
		return EApplyTag::Dark;

	case ENatureType::Fire:
		return EApplyTag::Fire;

	case ENatureType::Light:
		return EApplyTag::Light;

	case ENatureType::Water:
		return EApplyTag::Water;

	case ENatureType::Wind:
		return EApplyTag::Wind;
	}

	ensure(0);
	return EApplyTag::None;
}

static EApplyTag SkillLevelToApplyTag(int32 SkillLevel)
{
	if (SkillLevel <= 0 || SkillLevel > CombatCubeConst::Q6_MAX_SKILL_LEVEL)
	{
		return EApplyTag::None;
	}

	return (EApplyTag)((int32)(EApplyTag::Level1) + SkillLevel - 1);
}

static EApplyTag EquipmentTierToApplyTag(int32 Tier)
{
	if (Tier <= 0 || Tier > CombatCubeConst::Q6_MAX_TIER)
	{
		return EApplyTag::None;
	}

	return (EApplyTag)((int32)(EApplyTag::Tier1) + Tier - 1);
}

static TArray<EApplyTag> SkillSequenceToApplyTag(const FCCCombatCubeState& InOutState, int32 EntryAliveUnitCount, int32 SkillSequence, ESkillCategory Category)
{
	TArray<EApplyTag> Tags;

	if (!InOutState.SkillProp[(int32)Category].bHasNote)
	{
		return Tags;
	}

	if (EntryAliveUnitCount == 3)
	{
		if (SkillSequence == 0) // for _ApplyTagUseSkill() before AddSkillOnCurPhase().
		{
			Tags.Add(EApplyTag::ChordAce);
		}
		else if (SkillSequence == 1)
		{
			Tags.Add(EApplyTag::ChordAce);
		}
		else if (SkillSequence == 2)
		{
			Tags.Add(EApplyTag::ChordBreak);
		}
		else if (SkillSequence == 3)
		{
			Tags.Add(EApplyTag::ChordBreak);
			Tags.Add(EApplyTag::ChordCloser);
		}
		else
		{
			ensure(0);
		}
	}
	else if (EntryAliveUnitCount == 2)
	{
		if (SkillSequence == 0) // for _ApplyTagUseSkill() before AddSkillOnCurPhase().
		{
			Tags.Add(EApplyTag::ChordAce);
		}
		else if (SkillSequence == 1)
		{
			Tags.Add(EApplyTag::ChordAce);
		}
		else if (SkillSequence == 2)
		{
			Tags.Add(EApplyTag::ChordBreak);
			Tags.Add(EApplyTag::ChordCloser);
		}
		else
		{
			ensure(0);
		}
	}
	else if (EntryAliveUnitCount == 1)
	{
		if (SkillSequence == 0) // for _ApplyTagUseSkill() before AddSkillOnCurPhase().
		{
			Tags.Add(EApplyTag::ChordAce);
			Tags.Add(EApplyTag::ChordCloser);
		}
		else if (SkillSequence == 1)
		{
			Tags.Add(EApplyTag::ChordAce);
			Tags.Add(EApplyTag::ChordCloser);
		}
		else
		{
			ensure(0);
		}
	}
	else
	{
		ensure(0);
	}

	return Tags;
}

static ESkillNote _GetChainSkillNote(const FCCCombatCubeState& InOutState)
{
	int32 MatchCount = 0;
	ESkillNote Note = ESkillNote::None;

	for (const FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(CHAIN_FACTION))
	{
		const FCCSkillState* SkillState = InOutState.UnitsState.GetNormalSkillByTurn(Unit->UnitId, InOutState.TurnState.TurnCount);
		const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(SkillState->SkillType);
		if (Note == ESkillNote::None)
		{
			Note = InSkillRow.SkillNote;
		}

		if (Note == InSkillRow.SkillNote)
		{
			++MatchCount;
		}
	}

	if (MatchCount != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT || Note == ESkillNote::None)
	{
		return ESkillNote::None;
	}

	return Note;
}

static EApplyTag ChainSkillToApplyTag(const FCCCombatCubeState& InOutState, const FCCUnitState* Unit)
{
	if (Unit->Faction != CHAIN_FACTION)
	{
		return EApplyTag::None;
	}

	ESkillNote Note = _GetChainSkillNote(InOutState);
	if (Note == ESkillNote::None)
	{
		return EApplyTag::None;
	}

	switch (Note)
	{
	case ESkillNote::Ace:
		return EApplyTag::AceChain;
	case ESkillNote::Break:
		return EApplyTag::BreakChain;
	case ESkillNote::Closer:
		return EApplyTag::CloserChain;
	default:
		ensure(0);
		break;
	}

	return EApplyTag::None;
}

int32 ChanceApplyTagToPercent(EApplyTag Tag)
{
	if (Tag < EApplyTag::Chance5 || Tag > EApplyTag::Chance95)
	{
		ensure(0);
		return 0;
	}

	switch (Tag)
	{
	case EApplyTag::Chance5:
		return 5;
	case EApplyTag::Chance10:
		return 10;
	case EApplyTag::Chance15:
		return 15;
	case EApplyTag::Chance20:
		return 20;
	case EApplyTag::Chance25:
		return 25;
	case EApplyTag::Chance30:
		return 30;
	case EApplyTag::Chance35:
		return 35;
	case EApplyTag::Chance40:
		return 40;
	case EApplyTag::Chance45:
		return 45;
	case EApplyTag::Chance50:
		return 50;
	case EApplyTag::Chance55:
		return 55;
	case EApplyTag::Chance60:
		return 60;
	case EApplyTag::Chance65:
		return 65;
	case EApplyTag::Chance70:
		return 70;
	case EApplyTag::Chance75:
		return 75;
	case EApplyTag::Chance80:
		return 80;
	case EApplyTag::Chance85:
		return 85;
	case EApplyTag::Chance90:
		return 90;
	case EApplyTag::Chance95:
		return 95;
	default:
		ensure(0);
		break;
	}

	return 0;
}

int32 HPApplyTagToPercent(EApplyTag Tag)
{
	if (Tag < EApplyTag::HP5 || Tag > EApplyTag::HP100)
	{
		ensure(0);
		return 0;
	}

	int32 Delta = (int32)Tag - (int32)EApplyTag::HP5 + 1;
	return Delta * 5;
}

int32 OverKillApplyTagToInteger(EApplyTag Tag)
{
	if (Tag < EApplyTag::OK5 || Tag > EApplyTag::OK100)
	{
		ensure(0);
		return 0;
	}

	int32 Delta = (int32)Tag - (int32)EApplyTag::OK5 + 1;
	return Delta * 5;
}

int32 UAApplyTagToInteger(EApplyTag Tag)
{
	if (Tag < EApplyTag::UA10 || Tag > EApplyTag::UA200)
	{
		ensure(0);
		return 0;
	}

	int32 Delta = (int32)Tag - (int32)EApplyTag::UA10 + 1;
	return Delta * 10;
}

int32 SAApplyTagToInteger(EApplyTag Tag)
{
	if (Tag < EApplyTag::SA10 || Tag > EApplyTag::SA200)
	{
		ensure(0);
		return 0;
	}

	int32 Delta = (int32)Tag - (int32)EApplyTag::SA10 + 1;
	return Delta * 10;
}

static TArray<EApplyTag> ImmuneBuffToApplyTag(const UCMS* CMS, const FCCUnitState* TargetUnit)
{
	TArray<EApplyTag> Ret;

	for (const FCCBuffState& IterBuff : TargetUnit->Buffs)
	{
		for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyUnitAttributeEffects(IterBuff, EUnitAttribute::Immune))
		{
			const FCMSApplyTagRow& TagRow = CMS->GetApplyTagRowOrDummy(FApplyTagType(Effect->Param2));
			if (TagRow.IsInvalid())
			{
				Q6JsonLog(Error, "Immune BuffEffect invalid param2", Q6KV("UnitType", TargetUnit->UnitType), \
					Q6KV("BuffEffect", Effect->CmsType()), \
					Q6KV("param2", Effect->Param2));
				continue;
			}

			Ret.Add(TagRow.ApplyTag);

			Q6JsonLog(Display, "Immune find BuffEffect", Q6KV("UnitType", TargetUnit->UnitType), \
				Q6KV("BuffEffect", Effect->CmsType()), \
				Q6KV("ApplyTag", TagRow.CmsType()));
		}
	}

	return Ret;
}

static TArray<EApplyTag> CrowdControlBuffToApplyTag(const UCMS* CMS, int32 BuffType)
{
	TArray<EApplyTag> Ret;

	for (const FCMSBuffEffectRow* E : CMS->GetBuffEffects(BuffType, EBuffEffectCategory::ModifyCrowdControl))
	{
		const FCMSCrowdControlRow& Row = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(E->Param1));
		if (Row.ApplyTag == EApplyTag::None)
		{
			continue;
		}

		Ret.Add(Row.ApplyTag);
	}

	return Ret;
}

static TArray<EApplyTag> UnitAttributeBuffToApplyTag(const UCMS* CMS, int32 BuffType)
{
	TArray<EApplyTag> Ret;

	for (const FCMSBuffEffectRow* E : CMS->GetBuffEffects(BuffType, EBuffEffectCategory::ModifyUnitAttribute))
	{
		const FCMSUnitAttributeRow& Row = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType(E->Param1));

		if (E->Param2 > 0)
		{
			if (Row.PositiveApplyTag == EApplyTag::None)
			{
				continue;
			}

			Ret.Add(Row.PositiveApplyTag);
		}
		else if (E->Param2 < 0)
		{
			if (Row.NegativeApplyTag == EApplyTag::None)
			{
				continue;
			}

			Ret.Add(Row.NegativeApplyTag);
		}
	}

	return Ret;
}

static bool _ApplyTagMustBe(int32 Threshold, int32 Value, EApplyTag Tag, FString ValueType, bool CompareGreaterEqual,
	EApplyTagFailedReason Reason, FApplyTagFailedInfo* OutFailedInfo = nullptr)
{
	if (CompareGreaterEqual)
	{
		if ((Threshold >= Value)
			&& Tag != EApplyTag::None)
		{
			Q6JsonLog(Display, "Failed ApplyTag GreaterEqual",
				Q6KV("ApplyTag value", Threshold),
				Q6KV("value", Value),
				Q6KV("type", ValueType));

			if (OutFailedInfo)
			{
				OutFailedInfo->Reason = Reason;
				OutFailedInfo->ReasonTag = Tag;
			}
			return false;
		}
		else
		{
			Q6JsonLog(Display, "Pass ApplyTag GreaterEqual",
				Q6KV("ApplyTag value", Threshold),
				Q6KV("value", Value),
				Q6KV("type", ValueType));
		}
	}
	else
	{
		if ((Threshold < Value)
			&& Tag != EApplyTag::None)
		{
			Q6JsonLog(Display, "Failed ApplyTag Smaller",
				Q6KV("ApplyTag value", Threshold),
				Q6KV("value", Value),
				Q6KV("type", ValueType));

			if (OutFailedInfo)
			{
				OutFailedInfo->Reason = Reason;
				OutFailedInfo->ReasonTag = Tag;
			}
			return false;
		}
		else
		{
			Q6JsonLog(Display, "Pass ApplyTag Smaller",
				Q6KV("ApplyTag value", Threshold),
				Q6KV("value", Value),
				Q6KV("type", ValueType));
		}
	}

	return true;
}

static bool _ApplyTagEq(const FActionContext& Context, const FCCCombatCubeState& InOutState, const FCCUnitState& SourceUnit, const FCCUnitState& TargetUnit,
	EApplyTagTarget ApplyTagTarget, const TArray<EApplyTag>& ApplyTagEquals, const TArray<EApplyTag>& ApplyTagNotEquals, int32 InLevelOrTier, ESkillCategory BornCategory, FApplyTagFailedInfo* OutFailedInfo = nullptr)
{
	const FCMSSagaRow& Saga = GetCMS()->GetSagaRowOrDummy(InOutState.CombatSeed.SagaType);
	if (Saga.IsInvalid())
	{
		ensure(0);
	}

	const FCCUnitState* Unit = nullptr;
	if (ApplyTagTarget == EApplyTagTarget::Source)
	{
		Unit = &SourceUnit;
	}
	else
	{
		Unit = &TargetUnit;
	}

	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(Unit->UnitType));

	TArray<EApplyTag> ApplyTags;
	ApplyTags.Add(NatureTypeToApplyTag(Unit->GetNatureType()));
	ApplyTags.Append(CMSUnitRow.ApplyTags);
	for (const FCCBuffState& B : Unit->Buffs)
	{
		const FCMSBuffRow& Row = GetCMS()->GetBuffRowOrDummy(FBuffType(B.BuffType));
		ApplyTags.Append(CrowdControlBuffToApplyTag(GetCMS(), B.BuffType));
		ApplyTags.Append(UnitAttributeBuffToApplyTag(GetCMS(), B.BuffType));
		if (Row.ApplyTag != EApplyTag::None)
		{
			ApplyTags.Add(Row.ApplyTag);
		}
	}
	ApplyTags.Append(Saga.ApplyTags);
	if (BornCategory == ESkillCategory::Equipment)
	{
		ApplyTags.Add(EquipmentTierToApplyTag(InLevelOrTier));
	}
	else
	{
		ApplyTags.Add(SkillLevelToApplyTag(InLevelOrTier));
	}

	int32 EntryAliveUnitCount = InOutState.UnitsState.EntryAliveUnitCount[(int32)SourceUnit.Faction];
	int32 SkillSequence = InOutState.UnitsState.GetCountSkillsOnCurPhase(InOutState, SourceUnit.Faction, BornCategory);
	ApplyTags.Append(SkillSequenceToApplyTag(InOutState, EntryAliveUnitCount, SkillSequence, BornCategory));

	ApplyTags.Add(ChainSkillToApplyTag(InOutState, Unit));

	for (EApplyTag NotEqual : ApplyTagNotEquals)
	{
		EApplyTagCompare NotEqualComp = GetCMS()->GetApplyTagCompare(NotEqual);
		if (NotEqualComp == EApplyTagCompare::Chance)
		{
			int32 Percent = ChanceApplyTagToPercent(NotEqual);
			int32 Dice = Context.MT19937->GenRandom(100) + 1;
			if (!_ApplyTagMustBe(Percent, Dice, NotEqual, TEXT("Dice"), true, EApplyTagFailedReason::ApplyTagNotEquals, OutFailedInfo))
			{
				return false;
			}

			continue;
		}

		if (NotEqualComp == EApplyTagCompare::HP)
		{
			int32 Percent = HPApplyTagToPercent(NotEqual);
			int64 Health = Unit->Health * 100 / Unit->UnitAttributes->GetAttributeValue(EUnitAttribute::MaxHealth);
			if (!_ApplyTagMustBe(Health, Percent, NotEqual, TEXT("HP"), true, EApplyTagFailedReason::ApplyTagNotEquals, OutFailedInfo))
			{
				return false;
			}

			continue;
		}

		if (NotEqualComp == EApplyTagCompare::OK)
		{
			int32 Absolute = OverKillApplyTagToInteger(NotEqual);
			int32 OverKill = Unit->OverKill;
			if (!_ApplyTagMustBe(OverKill, Absolute, NotEqual, TEXT("OverKill"), true, EApplyTagFailedReason::ApplyTagNotEquals, OutFailedInfo))
			{
				return false;
			}

			continue;
		}

		if (NotEqualComp == EApplyTagCompare::UA)
		{
			int32 Absolute = UAApplyTagToInteger(NotEqual);
			int32 UA = Unit->UA;
			if (!_ApplyTagMustBe(UA, Absolute, NotEqual, TEXT("UA"), true, EApplyTagFailedReason::ApplyTagNotEquals, OutFailedInfo))
			{
				return false;
			}

			continue;
		}

		if (NotEqualComp == EApplyTagCompare::SA)
		{
			int32 Absolute = SAApplyTagToInteger(NotEqual);
			int32 SA = Unit->SA;
			if (!_ApplyTagMustBe(SA, Absolute, NotEqual, TEXT("SA"), true, EApplyTagFailedReason::ApplyTagNotEquals, OutFailedInfo))
			{
				return false;
			}

			continue;
		}

		for (EApplyTag T : ApplyTags)
		{
			EApplyTagCompare TComp = GetCMS()->GetApplyTagCompare(T);
			if (TComp != NotEqualComp)
			{
				continue;
			}

			if (TComp == EApplyTagCompare::Keyword)
			{
				if (NotEqual == T
					&& NotEqual != EApplyTag::None)
				{
					if (OutFailedInfo)
					{
						OutFailedInfo->Reason = EApplyTagFailedReason::ApplyTagNotEquals;
						OutFailedInfo->ReasonTag = T;
					}
					return false;
				}
			}
			else if (TComp == EApplyTagCompare::Level)
			{
				if ((int32)T >= (int32)NotEqual
					&& NotEqual != EApplyTag::None)
				{
					if (OutFailedInfo)
					{
						OutFailedInfo->Reason = EApplyTagFailedReason::ApplyTagNotEquals;
						OutFailedInfo->ReasonTag = T;
					}
					return false;
				}
			}
			else if (TComp == EApplyTagCompare::Tier)
			{
				if ((int32)T >= (int32)NotEqual
					&& NotEqual != EApplyTag::None)
				{
					if (OutFailedInfo)
					{
						OutFailedInfo->Reason = EApplyTagFailedReason::ApplyTagNotEquals;
						OutFailedInfo->ReasonTag = T;
					}
					return false;
				}
			}
			else
			{
				ensure(0);
			}
		}
	}

	if (ApplyTagEquals.Num() <= 0)
	{
		return true;
	}

	if (ApplyTagEquals.Num() <= 1 && ApplyTagEquals[0] == EApplyTag::None)
	{
		return true;
	}

	for (EApplyTag Equal : ApplyTagEquals)
	{
		EApplyTagCompare EqualComp = GetCMS()->GetApplyTagCompare(Equal);
		if (EqualComp == EApplyTagCompare::Chance)
		{
			int32 Percent = ChanceApplyTagToPercent(Equal);
			int32 Dice = Context.MT19937->GenRandom(100) + 1;
			if (!_ApplyTagMustBe(Percent, Dice, Equal, TEXT("Chance"), false, EApplyTagFailedReason::ApplyTagEquals, OutFailedInfo))
			{
				return false;
			}
		}

		if (EqualComp == EApplyTagCompare::HP)
		{
			int32 Percent = HPApplyTagToPercent(Equal);
			int64 Health = Unit->Health * 100 / Unit->UnitAttributes->GetAttributeValue(EUnitAttribute::MaxHealth);
			if (!_ApplyTagMustBe(Health, Percent, Equal, TEXT("HP"), false, EApplyTagFailedReason::ApplyTagEquals, OutFailedInfo))
			{
				return false;
			}
		}

		if (EqualComp == EApplyTagCompare::OK)
		{
			int32 Absolute = OverKillApplyTagToInteger(Equal);
			int32 OverKill = Unit->OverKill;
			if (!_ApplyTagMustBe(OverKill, Absolute, Equal, TEXT("OK"), false, EApplyTagFailedReason::ApplyTagEquals, OutFailedInfo))
			{
				return false;
			}
		}

		if (EqualComp == EApplyTagCompare::UA)
		{
			int32 Absolute = UAApplyTagToInteger(Equal);
			int32 UA = Unit->UA;
			if (!_ApplyTagMustBe(UA, Absolute, Equal, TEXT("UA"), false, EApplyTagFailedReason::ApplyTagEquals, OutFailedInfo))
			{
				return false;
			}
		}

		if (EqualComp == EApplyTagCompare::SA)
		{
			int32 Absolute = SAApplyTagToInteger(Equal);
			int32 SA = Unit->SA;
			if (!_ApplyTagMustBe(SA, Absolute, Equal, TEXT("SA"), false, EApplyTagFailedReason::ApplyTagEquals, OutFailedInfo))
			{
				return false;
			}
		}
	}

	bool PassEqualsTag = true;
	for (EApplyTag Equal : ApplyTagEquals)
	{
		EApplyTagCompare EqualComp = GetCMS()->GetApplyTagCompare(Equal);
		if (EqualComp == EApplyTagCompare::Chance
			|| EqualComp == EApplyTagCompare::HP
			|| EqualComp == EApplyTagCompare::OK
			|| EqualComp == EApplyTagCompare::UA
			|| EqualComp == EApplyTagCompare::SA)
		{
			continue;
		}

		PassEqualsTag = false;

		for (EApplyTag T : ApplyTags)
		{
			EApplyTagCompare TComp = GetCMS()->GetApplyTagCompare(T);
			if (TComp != EqualComp)
			{
				continue;
			}

			if (TComp == EApplyTagCompare::Keyword)
			{
				if (Equal == T
					&& Equal != EApplyTag::None)
				{
					PassEqualsTag = true;
				}
			}
			else if (TComp == EApplyTagCompare::Level)
			{
				if ((int32)T >= (int32)Equal
					&& Equal != EApplyTag::None)
				{
					PassEqualsTag = true;
				}
			}
			else if (TComp == EApplyTagCompare::Tier)
			{
				if ((int32)T >= (int32)Equal
					&& Equal != EApplyTag::None)
				{
					PassEqualsTag = true;
				}
			}
			else
			{
				ensure(0);
			}
		}

		if (PassEqualsTag)
		{
			break;
		}
	}

	if (PassEqualsTag)
	{
		return true;
	}
	else
	{
		if (OutFailedInfo)
		{
			OutFailedInfo->Reason = EApplyTagFailedReason::ApplyTagEquals;
			OutFailedInfo->ReasonTag = EApplyTag::None;
		}
		return false;
	}
}

static EApplyTag MatchedSkillChordNote(const FActionContext& Context, const FCCCombatCubeState& InOutState, int32 EntryAliveUnitCount, int32 SkillSequence, const FCMSSkillRow& SkillRow)
{
	if (!InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote)
	{
		return EApplyTag::None;
	}

	TArray<EApplyTag> CurChords = SkillSequenceToApplyTag(InOutState, EntryAliveUnitCount, SkillSequence, SkillRow.SkillCategory);

	TArray<EApplyTag> SkillChords;
	switch (SkillRow.SkillNote)
	{
	case ESkillNote::Ace:
		SkillChords.Add(EApplyTag::ChordAce);
		break;
	case ESkillNote::Break:
		SkillChords.Add(EApplyTag::ChordBreak);
		break;
	case ESkillNote::Closer:
		SkillChords.Add(EApplyTag::ChordCloser);
		break;
	default:
		break;
	}

	for (const FCMSSkillEffectRow* Effect : SkillRow.GetSkillEffect())
	{
		SkillChords.Append(Effect->ApplyTagEquals);

		if (Effect->EffectCategory == EEffectCategory::Buff)
		{
			int32 BuffType = Effect->Param1;

			const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(BuffType));
			SkillChords.Append(BuffRow.ApplyTagEquals);
		}
	}

	for (EApplyTag CurTag : CurChords)
	{
		if (SkillChords.Find(CurTag) != INDEX_NONE)
		{
			return CurTag;
		}
	}

	return EApplyTag::None;
}

static void _ResolveProvokeOnDie(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId DieUnitId)
{
	FCCUnitState& DieUnit = InOutState.UnitsState.FindUnitState(DieUnitId);
	ECCFaction ExcludeFaction = (DieUnit.Faction == ECCFaction::Ally) ? ECCFaction::Enemy : ECCFaction::Ally;

 	TArray<FCCUnitId> RemoveBuffUnitIds;
	TArray<FCCBuffId> RemoveBuffIds;
 	for (FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(ExcludeFaction))
 	{
 		for (int i = Unit->Buffs.Num() - 1; i >= 0; --i)
 		{
 			FCCBuffState& Buff = Unit->Buffs[i];
 			if (HasCrowdControlState(Buff, ECrowdControl::Provoke) == 0)
 			{
 				continue;
 			}

 			if (Buff.SourceUnitId != DieUnit.UnitId)
 			{
 				continue;
 			}

 			RemoveBuffUnitIds.Add(Unit->UnitId);
			RemoveBuffIds.Add(Buff.BuffId);

			Unit->Buffs.RemoveAt(i);
 		}
 	}

	BroadcastRemoveBuffEventSameTime(Context, RemoveBuffUnitIds, RemoveBuffIds, ERemoveBuffReason::RemoveSkill, false);
}

static void _ResolveProvokeOnCrossFire(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId SourceUnitId)
{
	FCCUnitState& SourceUnit = InOutState.UnitsState.FindUnitState(SourceUnitId);

	for (FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(SourceUnit.Faction))
	{
		for (int i = Unit->Buffs.Num() - 1; i >= 0; --i)
		{
			FCCBuffState& Buff = Unit->Buffs[i];
			if (HasCrowdControlState(Buff, ECrowdControl::Provoke) == 0)
			{
				continue;
			}

			BroadcastRemoveBuffEvent(Context, Unit->UnitId, Buff.BuffId, ERemoveBuffReason::RemoveSkill, false);
			Unit->Buffs.RemoveAt(i);
		}
	}
}

static void _ResolveCrossFireOnProvoke(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId SourceUnitId)
{
	FCCUnitState& SourceUnit = InOutState.UnitsState.FindUnitState(SourceUnitId);

	for (FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(SourceUnit.Faction))
	{
		for (int i = Unit->Buffs.Num() - 1; i >= 0; --i)
		{
			FCCBuffState& Buff = Unit->Buffs[i];
			if (HasCrowdControlState(Buff, ECrowdControl::CrossFire) == 0)
			{
				continue;
			}

			BroadcastRemoveBuffEvent(Context, Unit->UnitId, Buff.BuffId, ERemoveBuffReason::RemoveSkill, false);
			Unit->Buffs.RemoveAt(i);
		}
	}
}

static void _ClearSubParts(const FActionContext& Context, FCCCombatCubeState& InOutState, const FCCUnitState& Main)
{
	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(Main.UnitType));
	if (CMSUnitRow.MonsterParts != EMonsterParts::Main)
	{
		return;
	}

	for (FCCUnitState* U : InOutState.UnitsState.GetAliveUnits(Main.Faction))
	{
		if (U->UnitId == Main.UnitId)
		{
			continue;
		}

		const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(U->UnitType));
		if (UnitRow.MonsterParts != EMonsterParts::Sub)
		{
			continue;
		}

		_SetHealth(Context, InOutState, *U, CCSkillIdInvalid, 0, false, true, nullptr);
		_ResolveProvokeOnDie(Context, InOutState, U->UnitId);
	}
}

static const FCCRaidSkillState* GetRaidSkillState(ESkillCategory BornCategory, FCCSkillId InSkillId, FCCCombatCubeState& InOutState)
{
	FCCRaidSkillState* RaidSkillState = nullptr;
	switch (BornCategory)
	{
		case ESkillCategory::RaidTurnBegin:
		{
			RaidSkillState = InOutState.RaidState.RaidTurnSkillStates.FindByPredicate(
				[&InSkillId](const FCCRaidSkillState& Elem)
			{
				return Elem.SkillState.SkillId == InSkillId;
			});
		}
		break;
		case ESkillCategory::RaidSupport:
		{
			RaidSkillState = InOutState.RaidState.RaidSupportSkillStates.FindByPredicate(
				[&InSkillId](const FCCRaidSkillState& Elem)
			{
				return Elem.SkillState.SkillId == InSkillId;
			});
		}
		break;
	}

	check(RaidSkillState != nullptr);
	return RaidSkillState;
}

static int64 _GetBuffDamage(int32 InBuffLevel, const TArray<const FCMSBuffEffectRow*>& Effects, FCCCombatCubeState& InOutState,
	FCCUnitState& SourceUnit, FCCUnitState& TargetUnit, bool bInCheat, int32 Multiple, ESkillCategory BornCategory, FCCSkillId BornSkillId)
{
	int64 TurnAtk = 0LL;
	int64 TurnAtkper = 0LL;
	for (const FCMSBuffEffectRow* Effect : Effects)
	{
		TurnAtk += (int32)Formula::InterpolatedBySkillLevelOrTier(InBuffLevel, Effect->Param2Min * Multiple, Effect->Param2 * Multiple, BornCategory);
		TurnAtkper += (int32)Formula::InterpolatedBySkillLevelOrTier(InBuffLevel, Effect->Param3Min * Multiple, Effect->Param3 * Multiple, BornCategory);
	}

	int64 Damage = 0;
	if (TurnAtk != 0 && TurnAtkper != 0)
	{
		int32 SkillSeq = InOutState.UnitsState.GetCountSkillsOnCurPhase(InOutState, SourceUnit.Faction, BornCategory);
		SkillSeq = !bInCheat ? SkillSeq : 1; //cheat buff always sequence number 1.

		switch (BornCategory)
		{
			case ESkillCategory::Ultimate:
			{
				Damage = Formula::CalcUltimateBuffDamage(GetCMS(), SourceUnit, TargetUnit, TurnAtk, TurnAtkper, SkillSeq,
					InOutState.UnitsState.EntryAliveUnitCount[(int32)SourceUnit.Faction], InOutState.CombatSeed.SagaType);
				Q6JsonLog(Display, "buff ultimate damage", Q6KV("value", Damage));
			}
			break;
			case ESkillCategory::RaidTurnBegin:
			case ESkillCategory::RaidSupport:
			{
				const FCCRaidSkillState* RaidSkillState = GetRaidSkillState(BornCategory, BornSkillId, InOutState);

				Damage = Formula::CalcRaidNormalBuffDamage(GetCMS(), RaidSkillState->Attributes, RaidSkillState->NatureType, SourceUnit, TargetUnit,
					TurnAtk, TurnAtkper, SkillSeq, InOutState.UnitsState.EntryAliveUnitCount[(int32)SourceUnit.Faction], InOutState.CombatSeed.SagaType);
				Q6JsonLog(Display, "buff Raid damage", Q6KV("value", Damage));
			}
			break;
			default:
			{
				Damage = Formula::CalcNormalBuffDamage(GetCMS(), SourceUnit, TargetUnit, TurnAtk, TurnAtkper, SkillSeq,
					InOutState.UnitsState.EntryAliveUnitCount[(int32)SourceUnit.Faction], InOutState.CombatSeed.SagaType);
				Q6JsonLog(Display, "buff normal damage", Q6KV("value", Damage));
			}
		}
	}

	return Damage;
}

static int64 _GetBuffHeal(int32 InBuffLevel, const TArray<const FCMSBuffEffectRow*>& Effects, FCCCombatCubeState& InOutState,
	FCCUnitState& SourceUnit, bool bInCheat, int32 Multiple, ESkillCategory BornCategory, FCCSkillId BornSkillId)
{
	int64 TurnHeal = 0LL;
	int64 TurnHealper = 0LL;
	for (const FCMSBuffEffectRow* Effect : Effects)
	{
		TurnHeal += (int32)Formula::InterpolatedBySkillLevelOrTier(InBuffLevel, Effect->Param2Min * Multiple, Effect->Param2 * Multiple, BornCategory);
		TurnHealper += (int32)Formula::InterpolatedBySkillLevelOrTier(InBuffLevel, Effect->Param3Min * Multiple, Effect->Param3 * Multiple, BornCategory);
	}

	int64 Heal = 0;
	if (TurnHeal != 0 && TurnHealper != 0)
	{
		if (BornCategory == ESkillCategory::RaidTurnBegin
			|| BornCategory == ESkillCategory::RaidSupport)
		{
			const FCCRaidSkillState* RaidSkillState = GetRaidSkillState(BornCategory, BornSkillId, InOutState);
			Heal = Formula::CalcRaidBuffHeal(GetCMS(), RaidSkillState->Attributes, TurnHeal, TurnHealper, InOutState.UnitsState.EntryAliveUnitCount[(int32)SourceUnit.Faction]);
		}
		else
		{
			Heal = Formula::CalcBuffHeal(GetCMS(), SourceUnit, TurnHeal, TurnHealper, InOutState.UnitsState.EntryAliveUnitCount[(int32)SourceUnit.Faction]);
		}

		Q6JsonLog(Display, "buff heal", Q6KV("value", Heal));
	}

	return Heal;
}

static bool _ApplyTagBuff(const FActionContext& Context, const FCCCombatCubeState& InOutState,
	const FCMSBuffRow& InBuff, const FCCUnitState& SourceUnit, const FCCUnitState& TargetUnit, int32 InLevelOrTier, ESkillCategory BornCategory)
{
	if (_ApplyTagEq(Context, InOutState, SourceUnit, TargetUnit, InBuff.ApplyTagTarget, InBuff.ApplyTagEquals, InBuff.ApplyTagNotEquals, InLevelOrTier, BornCategory))
	{
		Q6JsonLog(Display, "Pass ApplyTag Buff",\
			Q6KV("source unit type", SourceUnit.UnitType.x),\
			Q6KV("target unit type", TargetUnit.UnitType.x),\
			Q6KV("buff type", InBuff.Type),\
			Q6KV("skill level or tier", InLevelOrTier));
		return true;
	}
	else
	{
		Q6JsonLog(Display, "Failed ApplyTag Buff",\
			Q6KV("source unit type", SourceUnit.UnitType.x),\
			Q6KV("target unit type", TargetUnit.UnitType.x),\
			Q6KV("buff type", InBuff.Type),\
			Q6KV("skill level or tier", InLevelOrTier));
		return false;
	}
}

static EApplyTag _IdentifyBuffImmune(FCCUnitState& TargetUnit, const FCMSBuffRow& BuffRow)
{
	TArray<EApplyTag> CCTag = CrowdControlBuffToApplyTag(GetCMS(), BuffRow.Type);
	TArray<EApplyTag> UATag = UnitAttributeBuffToApplyTag(GetCMS(), BuffRow.Type);
	TArray<EApplyTag> Immune = ImmuneBuffToApplyTag(GetCMS(), &TargetUnit);

	for (EApplyTag CC : CCTag)
	{
		if (Immune.Find(CC) != INDEX_NONE)
		{
			return CC;
		}
	}

	for (EApplyTag UA : UATag)
	{
		if (Immune.Find(UA) != INDEX_NONE)
		{
			return UA;
		}
	}

	if (Immune.Find(BuffRow.ApplyTag) != INDEX_NONE)
	{
		return BuffRow.ApplyTag;
	}

	return EApplyTag::None;
}

static void _CreateBuff(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId SourceUnitId, FCCUnitId TargetUnitId,
	int32 BuffType, int32 Duration, int32 HitCount, int32 InSkillLevelOrTier, int32 CreatedTurnCount,
	bool bInCheat, ESkillCategory BornCategory, FCCSkillId BornSkillId, bool bInPassive = false)
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(TargetUnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	FCCUnitState& SourceUnit = InOutState.UnitsState.FindUnitState(SourceUnitId, true);
	if (!ensure(SourceUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	const UCMS* CMS = GetCMS();
	const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffType));
	if (Duration <= 0)
	{
		ensure(BuffRow.Duration > 0);
		Duration = BuffRow.Duration;
	}

	if (Duration <= 0)
	{
		Q6JsonLogBro(Warning, "Buff Duration is 0 or less", Q6KV("BuffType", BuffType));
		return;
	}

	EApplyTag ImmuneTag = _IdentifyBuffImmune(TargetUnit, BuffRow);
	if (ImmuneTag != EApplyTag::None)
	{
		Q6JsonLog(Display, "buff immune", Q6KV("UnitType", TargetUnit.UnitType), Q6KV("BuffType", BuffType));

		UCCImmuneBuffEvent* ImmuneBuffEvent = NewObject<UCCImmuneBuffEvent>();
		ImmuneBuffEvent->UnitId = TargetUnit.UnitId;
		ImmuneBuffEvent->BuffType = BuffType;
		ImmuneBuffEvent->ImmuneTag = ImmuneTag;
		Context.OnEvent.Broadcast(ImmuneBuffEvent);

		return;
	}

	if (!_ApplyTagBuff(Context, InOutState, BuffRow, SourceUnit, TargetUnit, InSkillLevelOrTier, BornCategory))
	{
		return;
	}

	if (BornCategory == ESkillCategory::Equipment
		&& InOutState.TurnState.TurnCount == 0)
	{
		++Duration;
	}

	FCCBuffState NewBuffState(TargetUnit.NextBuffId, BuffType, InSkillLevelOrTier,
		InOutState.TurnState.TurnCount, Duration, HitCount, 0, 0, SourceUnitId, BornCategory);
	NewBuffState.MaxShield = NewBuffState.Shield = HasCrowdControlState(NewBuffState, ECrowdControl::Shield);
	int32 NewBuffIndex = 0;
	bool bNew = true;

	bool bCreateShieldBuff = (NewBuffState.MaxShield > 0) ? true : false;
	bool bTargetHasShieldBuff = (TargetUnit.GetCrowdControlState(CMS, ECrowdControl::Shield) != 0) ? true : false;
	bool bCreateNatureTypeBuff = (HasCrowdControlState(NewBuffState, ECrowdControl::ChangeNature) != 0) ? true : false;
	bool bTargetHasNatureTypebuff = (TargetUnit.GetCrowdControlState(CMS, ECrowdControl::ChangeNature) != 0) ? true : false;
	bool bCreateCrossFireBuff = (HasCrowdControlState(NewBuffState, ECrowdControl::CrossFire) != 0) ? true : false;
	bool bTargetHasCrossBureBuff = (TargetUnit.GetCrowdControlState(CMS, ECrowdControl::CrossFire) != 0) ? true : false;

	if (bCreateCrossFireBuff)
	{
		_ResolveProvokeOnCrossFire(Context, InOutState, SourceUnitId);
	}

	if ((bCreateShieldBuff && bTargetHasShieldBuff)
		|| (bCreateNatureTypeBuff && bTargetHasNatureTypebuff)
		|| (bCreateCrossFireBuff && bTargetHasCrossBureBuff))
	{
		for (int i = 0; i < TargetUnit.Buffs.Num(); ++i)
		{
			FCCBuffState& Itor = TargetUnit.Buffs[i];
			if ((bCreateShieldBuff && HasCrowdControlState(Itor, ECrowdControl::Shield) != 0)
				|| (bCreateNatureTypeBuff && HasCrowdControlState(Itor, ECrowdControl::ChangeNature) != 0)
				|| (bCreateCrossFireBuff && HasCrowdControlState(Itor, ECrowdControl::CrossFire) != 0))
			{
				if (Itor.SourceUnitId != SourceUnitId
					|| Itor.BuffType != BuffType)
				{
					BroadcastRemoveBuffEvent(Context, TargetUnit.UnitId, Itor.BuffId, ERemoveBuffReason::Overlap, false);

					TargetUnit.Buffs.RemoveAt(i);

					bNew = true;
					break;
				}
			}
		}
	}

	bool bCreateProvokeBuff = (HasCrowdControlState(NewBuffState, ECrowdControl::Provoke) != 0) ? true : false;
	bool bTargetHasProvoke = (TargetUnit.GetCrowdControlState(GetCMS(), ECrowdControl::Provoke) != 0) ? true : false;

	if (bCreateProvokeBuff)
	{
		_ResolveCrossFireOnProvoke(Context, InOutState, SourceUnitId);
	}

	if (bCreateProvokeBuff && bTargetHasProvoke)
	{
		for (int i = 0; i < TargetUnit.Buffs.Num(); ++i)
		{
			FCCBuffState& Itor = TargetUnit.Buffs[i];
			if (HasCrowdControlState(Itor, ECrowdControl::Provoke) != 0)
			{
				BroadcastRemoveBuffEvent(Context, TargetUnitId, Itor.BuffId, ERemoveBuffReason::Overlap, false);

				TargetUnit.Buffs.RemoveAt(i);

				bNew = true;
				break;
			}
		}
	}
	else
	{
		for (int i = 0; i < TargetUnit.Buffs.Num(); ++i)
		{
			FCCBuffState& Itor = TargetUnit.Buffs[i];

			if (Itor.BuffType != BuffType)
			{
				continue;
			}

			if (Itor.SourceUnitId != SourceUnitId)
			{
				bNew = true;
			}
			else
			{
				if (BuffRow.BuffOverlap == EBuffOverlap::Overwrite
					|| BuffRow.BuffOverlap == EBuffOverlap::Multiple)
				{
					if (BuffRow.BuffOverlap == EBuffOverlap::Multiple)
					{
						NewBuffState.Multiple = Itor.Multiple + 1;
						if (BuffRow.MaxOverlap > 0)
						{
							NewBuffState.Multiple = FMath::Clamp(NewBuffState.Multiple, 1, BuffRow.MaxOverlap);
						}
					}

					BroadcastRemoveBuffEvent(Context, TargetUnitId, Itor.BuffId, ERemoveBuffReason::Overlap, false);

					TargetUnit.Buffs.RemoveAt(i);

					bNew = true;
				}
				else if (BuffRow.BuffOverlap == EBuffOverlap::Add
					|| BuffRow.BuffOverlap == EBuffOverlap::Combine)
				{
					Itor.Duration += Duration;

					if (BuffRow.BuffOverlap == EBuffOverlap::Add)
					{
						Itor.HitCount = HitCount;
						Itor.Shield = NewBuffState.Shield;
					}
					else if (BuffRow.BuffOverlap == EBuffOverlap::Combine)
					{
						Itor.HitCount += HitCount;
						Itor.Shield += NewBuffState.Shield;

						++Itor.Multiple;

						if (BuffRow.MaxOverlap > 0)
						{
							Itor.Duration = FMath::Clamp(Itor.Duration, Duration, Duration * BuffRow.MaxOverlap);
							Itor.HitCount = FMath::Clamp(Itor.HitCount, HitCount, HitCount * BuffRow.MaxOverlap);
							Itor.Shield = FMath::Clamp(Itor.Shield, NewBuffState.Shield, NewBuffState.Shield * BuffRow.MaxOverlap);
							Itor.MaxShield = FMath::Clamp(Itor.MaxShield, NewBuffState.MaxShield, NewBuffState.MaxShield * BuffRow.MaxOverlap);
							Itor.Multiple = FMath::Clamp(Itor.Multiple, 1, BuffRow.MaxOverlap);
						}
					}

					bNew = false;
					NewBuffIndex = i;
				}
			}

			break;
		}
	}

	if (bNew)
	{
		FCCBuffId EmptyId = CCBuffIdInvalid;

		TArray<FCCBuffId> ExistIds;
		ExistIds.Push(NewBuffState.BuffId);
		for (const FCCBuffState& B : TargetUnit.Buffs)
		{
			ExistIds.Push(B.BuffId);
		}

		for (int TryId = 1; TryId <= CombatCubeConst::Q6_MAX_BUFFS_PER_UNITS; ++TryId)
		{
			if (ExistIds.Find(FCCBuffId(TryId)) != INDEX_NONE)
			{
				continue;
			}

			EmptyId = FCCBuffId(TryId);
			break;
		}

		if (EmptyId == CCBuffIdInvalid)
		{
			Q6JsonLog(Error, "can not create buff. there is too many buffs.",
				Q6KV("unit type", TargetUnit.UnitType.x),
				Q6KV("buff type", NewBuffState.BuffType));
			return;
		}

		NewBuffIndex = TargetUnit.Buffs.Add(NewBuffState);
		TargetUnit.NextBuffId = EmptyId;
	}

	const TArray<TPair<int64, int64>>& UpdatedUnitAttributes = TargetUnit.UnitAttributes->UpdateUnitAttributes(Context, TargetUnit);

	for (const TPair<int64, int64>& UpdatedUnitAttribute : UpdatedUnitAttributes)
	{
		UCCUpdateAttributesEvent* UpdateAttributeEvent = NewObject<UCCUpdateAttributesEvent>();
		UpdateAttributeEvent->UnitAttributeType = CMS->GetUnitAttributeType(EUnitAttribute(UpdatedUnitAttribute.Key));
		UpdateAttributeEvent->UnitId = TargetUnitId;
		UpdateAttributeEvent->AddedValue = UpdatedUnitAttribute.Value;
		Context.OnEvent.Broadcast(UpdateAttributeEvent);
	}

	FCCBuffState& UpdateBuffState = TargetUnit.Buffs[NewBuffIndex];
	UpdateBuffState.Damage = _GetBuffDamage(InSkillLevelOrTier, GetCMS()->GetModifyCrowdControlEffects(UpdateBuffState, ECrowdControl::TurnAtk),
		InOutState, SourceUnit, TargetUnit, bInCheat, UpdateBuffState.Multiple, BornCategory, BornSkillId);
	UpdateBuffState.Heal = _GetBuffHeal(InSkillLevelOrTier, GetCMS()->GetModifyCrowdControlEffects(UpdateBuffState, ECrowdControl::TurnHeal),
		InOutState, SourceUnit, bInCheat, UpdateBuffState.Multiple, BornCategory, BornSkillId);

	UCCCreateBuffEvent* BuffEvent = NewObject<UCCCreateBuffEvent>();
	BuffEvent->SourceUnitId = SourceUnitId;
	BuffEvent->TargetUnitId = TargetUnitId;
	BuffEvent->BuffLevel = InSkillLevelOrTier;
	BuffEvent->BuffId = UpdateBuffState.BuffId;
	BuffEvent->BuffType = UpdateBuffState.BuffType;
	BuffEvent->Duration = UpdateBuffState.Duration;
	BuffEvent->HitCount = UpdateBuffState.HitCount;
	BuffEvent->Shield = UpdateBuffState.Shield;
	BuffEvent->Multiple = UpdateBuffState.Multiple;
	BuffEvent->IsNew = bNew;
	BuffEvent->BornCategory = BornCategory;
	BuffEvent->IsPassive = bInPassive;
	Context.OnEvent.Broadcast(BuffEvent);

	if (UpdateBuffState.Multiple == BuffRow.MaxOverlap)
	{
		_ReadyMomentSkill(InOutState, TargetUnit, BornCategory, EMoment::AtBuffMaxOverlap, TargetUnit.UnitId);
	}
}

static void _FlushUnitHitCountBuff(const FActionContext& Context, FCCCombatCubeState& InOutState, const TArray<FCCUnitId>& TargetUnitIds)
{
	for (const FCCUnitId& Id : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(Id);
		if (TargetUnit.IsDead())
		{
			continue;
		}

		for (int i = TargetUnit.Buffs.Num() - 1; i >= 0; --i)
		{
			FCCBuffState& Buff = TargetUnit.Buffs[i];
			if (Buff.HitCount <= 0)
			{
				continue;
			}

			--Buff.HitCount;
			Q6JsonLog(Display, "decrease buff hitcount", \
				Q6KV("unit type", TargetUnit.UnitType.x), \
				Q6KV("buff type", Buff.BuffType), \
				Q6KV("hitcount", Buff.HitCount));

			if (Buff.HitCount <= 0)
			{
				BroadcastRemoveBuffEvent(Context, TargetUnit.UnitId, Buff.BuffId, ERemoveBuffReason::HitCount, false);

				TargetUnit.Buffs.RemoveAt(i);
			}
		}
	}
}

struct CCSkillYard {
	const FActionContext& Context;
	FCCCombatCubeState& InOutState;
	FCCUnitState& SourceUnit;
	const FCMSSkillRow& SkillDesc;
	FCCSkillId SkillId;
	int32 SkillType;
	bool bIsPlayerUseSkill;
	FCCUnitId TargetUnitId;
	int32 SkillLevel;
	TArray<FCCUnitId> TargetUnitIds;
	ESkillCategory BornCategory;
	EApplyTag ChordNote;

	CCSkillYard(const FActionContext& InContext, FCCCombatCubeState& InInOutState, FCCUnitState& InSourceUnit, const FCMSSkillRow& InSkillDesc) :
		Context(InContext),
		InOutState(InInOutState),
		SourceUnit(InSourceUnit),
		SkillDesc(InSkillDesc),
		ChordNote(EApplyTag::None)
	{}
};

static bool _ApplyTagUseSkill(const FActionContext& Context, FCCCombatCubeState& InOutState,
	const FCMSSkillRow& SkillRow, FCCUnitState& SourceUnit, const FCCUnitId& InTargetId, int32 InLevelOrTier, ESkillCategory BornCategory, FApplyTagFailedInfo& OutFailedInfo)
{
	ETargetType Target;
	if (SkillRow.ApplyTagTarget == EApplyTagTarget::Source)
	{
		Target = ETargetType::Self;
	}
	else
	{
		Target = SkillRow.Target;
	}

	TArray<FCCUnitId> TagUnitIds = _GetTargetUnits(Context, InOutState, SourceUnit.UnitId, SourceUnit.Faction, Target, InTargetId, GetCMS(), SkillRow.SkillCategory);
	for (const FCCUnitId& Id : TagUnitIds)
	{
		FCCUnitState& TagUnit = InOutState.UnitsState.FindUnitState(Id);
		if (!_ApplyTagEq(Context, InOutState, SourceUnit, TagUnit, SkillRow.ApplyTagTarget, SkillRow.ApplyTagEquals, SkillRow.ApplyTagNotEquals, InLevelOrTier, BornCategory, &OutFailedInfo))
		{
			Q6JsonLog(Display, "Failed ApplyTag use Skill", \
				Q6KV("source unit type", SourceUnit.UnitType.x), \
				Q6KV("tag unit type", TagUnit.UnitType.x), \
				Q6KV("skill type", SkillRow.Type), \
				Q6KV("skill level or tier", InLevelOrTier));
			return false;
		}
	}

	Q6JsonLog(Display, "Pass ApplyTag use Skill", \
		Q6KV("source unit type", SourceUnit.UnitType.x), \
		Q6KV("skill type", SkillRow.Type), \
		Q6KV("skill level or tier", InLevelOrTier));
	return true;
}

static bool _ApplyTagSkillEffect(const FActionContext& Context, const FCCCombatCubeState& InOutState,
	const FCMSSkillEffectRow& InEffect, FCCUnitState& SourceUnit, FCCUnitState& TargetUnit, int32 InLevelOrTier, ESkillCategory BornCategory)
{
	if (_ApplyTagEq(Context, InOutState, SourceUnit, TargetUnit, InEffect.ApplyTagTarget, InEffect.ApplyTagEquals, InEffect.ApplyTagNotEquals, InLevelOrTier, BornCategory))
	{
		Q6JsonLog(Display, "Pass ApplyTag Skill Effect",\
			Q6KV("source unit type", SourceUnit.UnitType.x),\
			Q6KV("target unit type", TargetUnit.UnitType.x),\
			Q6KV("skill effect type", InEffect.Type),\
			Q6KV("skill level or tier", InLevelOrTier));
		return true;
	}
	else
	{
		Q6JsonLog(Display, "Failed ApplyTag Skill Effect",\
			Q6KV("source unit type", SourceUnit.UnitType.x),\
			Q6KV("target unit type", TargetUnit.UnitType.x),\
			Q6KV("skill effect type", InEffect.Type),\
			Q6KV("skill level or tier", InLevelOrTier));
		return false;
	}
}

static bool _ApplyTagExtraDamage(const FActionContext& Context, const FCCCombatCubeState& InOutState,
	EApplyTag Tag, FCCUnitState& SourceUnit, FCCUnitState& TargetUnit, int32 InLevelOrTier, ESkillCategory BornCategory)
{
	TArray<EApplyTag> Equals;
	Equals.Add(Tag);
	TArray<EApplyTag> NotEquals;

	if (_ApplyTagEq(Context, InOutState, SourceUnit, TargetUnit, EApplyTagTarget::Target, Equals, NotEquals, InLevelOrTier, BornCategory))
	{
		Q6JsonLog(Display, "Pass ApplyTag extra damage", \
			Q6KV("source unit type", SourceUnit.UnitType.x), \
			Q6KV("target unit type", TargetUnit.UnitType.x), \
			Q6KV("extra damage applytag", (int32)Tag));
		return true;
	}
	else
	{
		Q6JsonLog(Display, "Failed ApplyTag extra damage", \
			Q6KV("source unit type", SourceUnit.UnitType.x), \
			Q6KV("target unit type", TargetUnit.UnitType.x), \
			Q6KV("extra damage applytag", (int32)Tag));
		return false;
	}
}

static void _GetSkillTime(int32 Type, int32 Level, int32& CoolTime, int32& WaitTime, int32& InitWaitDown)
{
	CoolTime = CombatCubeConst::Q6_BASE_SKILL_COOLDOWN;
	WaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	InitWaitDown = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;

	int32 FirstWaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	int32 CommonWaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(Type);
	if (SkillRow.IsInvalid())
	{
		return;
	}

	for (const FCMSSkillEffectRow* E : SkillRow.GetSkillEffect())
	{
		if (E->EffectCategory == EEffectCategory::CoolTime)
		{
			CoolTime = E->Param1 - GetCMS()->GetCooltimeReduce(Level);
			CoolTime = FMath::Max(1, CoolTime);
		}
		else if (E->EffectCategory == EEffectCategory::FirstWaitTime)
		{
			FirstWaitTime = E->Param1;
		}
		else if (E->EffectCategory == EEffectCategory::WaitTime)
		{
			CommonWaitTime = E->Param1;
		}
	}

	if (FirstWaitTime != CombatCubeConst::Q6_BASE_SKILL_WAITDOWN)
	{
		InitWaitDown = FirstWaitTime;
	}
	else
	{
		InitWaitDown = CommonWaitTime;
	}

	WaitTime = CommonWaitTime;
}

static void _FillSkillStateFromCMS(FCCSkillId& NewSkillId, ESkillCategory InSkillCategory, const TArray<const FCMSSkillRow*>& InCMSSkills, TArray<FCCSkillState>& OutSkillState)
{
	int32 NewItemIdx = INDEX_NONE;
	for (const FCMSSkillRow* Row : InCMSSkills)
	{
		if (Row->SkillCategory != InSkillCategory)
		{
			continue;
		}

		int32 CoolTime = CombatCubeConst::Q6_BASE_SKILL_COOLDOWN;
		int32 WaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
		int32 InitWaitDown = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
		_GetSkillTime(Row->Type, CombatCubeConst::Q6_MAX_SKILL_LEVEL, CoolTime, WaitTime, InitWaitDown);

		NewItemIdx = OutSkillState.Add(FCCSkillState(NewSkillId, InSkillCategory, Row->Type,
			CombatCubeConst::Q6_MAX_SKILL_LEVEL, CoolTime, WaitTime, InitWaitDown));
		++NewSkillId.X;
	}
}

static void _FillSkillStateFromVersa(FCCSkillId& NewSkillId, const FActionContext& Context, TArray<FCCSkillState>& OutSkillState)
{
	int32 NewItemIdx = INDEX_NONE;
	for (int32 VersaSkillType : GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT).VersaSkillIds)
	{
		const FCMSSkillRow& VersaSkillRow = GetCMS()->GetSkillRowOrDummy(VersaSkillType);
		NewItemIdx = OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Versa, VersaSkillType,
			CombatCubeConst::Q6_MAX_SKILL_LEVEL,
			CombatCubeConst::Q6_BASE_SKILL_COOLDOWN,
			CombatCubeConst::Q6_BASE_SKILL_WAITDOWN,
			CombatCubeConst::Q6_BASE_SKILL_WAITDOWN));
		++NewSkillId.X;
	}
}

static void _FillSkillStateFromChain(FCCSkillId& NewSkillId, const FActionContext& Context, TArray<FCCSkillState>& OutSkillState)
{
	int32 NewItemIdx = INDEX_NONE;

	int32 SkillType = GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT).ChainAceSkillId;
	const FCMSSkillRow& AceRow = GetCMS()->GetSkillRowOrDummy(SkillType);
	NewItemIdx = OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Chain, AceRow.Type,
		CombatCubeConst::Q6_MAX_SKILL_LEVEL,
		CombatCubeConst::Q6_BASE_SKILL_COOLDOWN,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN));
	++NewSkillId.X;

	SkillType = GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT).ChainBreakSkillId;
	const FCMSSkillRow& BreakRow = GetCMS()->GetSkillRowOrDummy(SkillType);
	NewItemIdx = OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Chain, BreakRow.Type,
		CombatCubeConst::Q6_MAX_SKILL_LEVEL,
		CombatCubeConst::Q6_BASE_SKILL_COOLDOWN,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN));
	++NewSkillId.X;

	SkillType = GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT).ChainCloserSkillId;
	const FCMSSkillRow& CloserRow = GetCMS()->GetSkillRowOrDummy(SkillType);
	NewItemIdx = OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Chain, CloserRow.Type,
		CombatCubeConst::Q6_MAX_SKILL_LEVEL,
		CombatCubeConst::Q6_BASE_SKILL_COOLDOWN,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN));
	++NewSkillId.X;
}

static void _FillSkillStateFromArtifact(FCCSkillId& NewSkillId, const TArray<FSeedArtifact>& ArtifactAvailable, const FActionContext& Context, TArray<FCCSkillState>& OutSkillState)
{
	int32 NewItemIdx = INDEX_NONE;

	for (int i = 0; i < SystemConst::Q6_MAX_TEMPLE_ARTIFACTS; ++i)
	{
		if (!ArtifactAvailable.IsValidIndex(i))
		{
			continue;
		}

		int32 SkillType = SystemConstHelper::GetArtifactSkillType(i);
		int32 SkillCooltime = SystemConstHelper::GetArtifactSkillCooltime(i);
		bool bCanUse = ArtifactAvailable[i].Available;
		const FCMSSkillRow& Row = GetCMS()->GetSkillRowOrDummy(SkillType);
		FCCSkillState SkillState(NewSkillId, ESkillCategory::Artifact, Row.Type, ArtifactAvailable[i].Level, SkillCooltime,
			CombatCubeConst::Q6_BASE_SKILL_WAITDOWN,
			CombatCubeConst::Q6_BASE_SKILL_WAITDOWN);
		SkillState.Cooldown = bCanUse ? 0 : SkillCooltime;
		NewItemIdx = OutSkillState.Add(SkillState);
		++NewSkillId.X;
	}

	const FCMSSkillRow& GemRow = GetCMS()->GetSkillRowOrDummy(SystemConst::Q6_GEM_REBIRTH_SKILL_ID);
	NewItemIdx = OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Artifact, GemRow.Type,
		CombatCubeConst::Q6_MAX_SKILL_LEVEL, 0,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN,
		CombatCubeConst::Q6_BASE_SKILL_WAITDOWN));
	++NewSkillId.X;
}

static void _FillSkillStateFromPet(FCCSkillId& NewSkillId, const FPetInfo& Info, TArray<FCCSkillState>& OutSkillState)
{
	const FCMSPetRow& Row = GetCMS()->GetPetRowOrDummy(Info.Type);
	if (Row.IsInvalid())
	{
		Q6JsonLog(Error, "no exist pet type", Q6KV("type", Info.Type));
		return;
	}

	if (Row.GetSkills().Num() != SystemConst::Q6_MAX_PET_SKILL_COUNT)
	{
		Q6JsonLog(Error, "wrong pet skill count", Q6KV("type", Info.Type), Q6KV("count", Row.GetSkills().Num()));
		return;
	}

	const FCMSSkillRow& Skill1Row = GetCMS()->GetSkillRowOrDummy(Row.GetSkills()[0]->Type);
	if (Skill1Row.IsInvalid())
	{
		Q6JsonLog(Error, "wrong pet skill1", Q6KV("type", Info.Type), Q6KV("skill", Row.GetSkills()[0]->Type));
		return;
	}
	int32 CoolTime = CombatCubeConst::Q6_BASE_SKILL_COOLDOWN;
	int32 WaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	int32 InitWaitDown = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	_GetSkillTime(Skill1Row.Type, Info.Skill1Level, CoolTime, WaitTime, InitWaitDown);

	OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Pet, Skill1Row.Type, Info.Skill1Level, CoolTime, WaitTime, InitWaitDown));
	++NewSkillId.X;

	const FCMSSkillRow& Skill2Row = GetCMS()->GetSkillRowOrDummy(Row.GetSkills()[1]->Type);
	if (Skill2Row.IsInvalid())
	{
		Q6JsonLog(Error, "wrong pet skill2", Q6KV("type", Info.Type), Q6KV("skill", Row.GetSkills()[1]->Type));
		return;
	}
	CoolTime = CombatCubeConst::Q6_BASE_SKILL_COOLDOWN;
	WaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	InitWaitDown = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	_GetSkillTime(Skill2Row.Type, Info.Skill2Level, CoolTime, WaitTime, InitWaitDown);

	OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Pet, Skill2Row.Type, Info.Skill2Level, CoolTime, WaitTime, InitWaitDown));
	++NewSkillId.X;

	const FCMSSkillRow& Skill3Row = GetCMS()->GetSkillRowOrDummy(Row.GetSkills()[2]->Type);
	if (Skill3Row.IsInvalid())
	{
		Q6JsonLog(Error, "wrong pet skill3", Q6KV("type", Info.Type), Q6KV("skill", Row.GetSkills()[2]->Type));
		return;
	}
	CoolTime = CombatCubeConst::Q6_BASE_SKILL_COOLDOWN;
	WaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	InitWaitDown = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
	_GetSkillTime(Skill3Row.Type, Info.Skill3Level, CoolTime, WaitTime, InitWaitDown);

	OutSkillState.Add(FCCSkillState(NewSkillId, ESkillCategory::Pet, Skill3Row.Type, Info.Skill3Level, CoolTime, WaitTime, InitWaitDown));
	++NewSkillId.X;
}

static void _SyncRebirthUnit(const FActionContext& Context, FCCCombatCubeState& InOutState, const FCCUnitId& OriginUnitId, FCCUnitState& RebirthUnit)
{
	FCCUnitState& OriginUnit = InOutState.UnitsState.FindUnitState(OriginUnitId);

	for (int32 i = RebirthUnit.Skills.Num() - 1; i >= 0; --i)
	{
		const FCCSkillState& S = RebirthUnit.Skills[i];
		if (InOutState.SkillProp[(int32)S.Category].bHasWaitTime == false
			&& InOutState.SkillProp[(int32)S.Category].bHasNote == false)
		{
			continue;
		}

		RebirthUnit.Skills.RemoveAtSwap(i);
	}

	for (int c = 0; c < dimof(InOutState.SkillProp); ++c)
	{
		if (InOutState.SkillProp[c].bHasNote == false
			&& InOutState.SkillProp[c].bHasWaitTime == false)
		{
			continue;
		}

		TArray<FCCSkillState*> Skills = OriginUnit.GetSkillStates((ESkillCategory)c);
		for (const FCCSkillState* S : Skills)
		{
			RebirthUnit.Skills.Add(*S);
		}
	}

	for (const FCCSkillState& S : RebirthUnit.Skills)
	{
		if (InOutState.SkillProp[(int32)S.Category].bHasWaitTime == false)
		{
			continue;
		}

		if (S.Cooldown == CombatCubeConst::Q6_BASE_SKILL_COOLDOWN
			&& S.WaitTime == CombatCubeConst::Q6_BASE_SKILL_WAITDOWN)
		{
			continue;
		}

		UCCSetSkillTimeEvent* Event = NewObject<UCCSetSkillTimeEvent>();
		Event->UnitId = RebirthUnit.UnitId;
		Event->SkillId = S.SkillId;
		Event->Cooldown = S.Cooldown;
		Event->Waitdown = S.Waitdown;
		Event->TimeDiff = 0;
		Event->SetSkillTimeType = ESetSkillTimeType::None;
		Context.OnEvent.Broadcast(Event);
	}

	RebirthUnit.UA = OriginUnit.UA;
	RebirthUnit.SA = OriginUnit.SA;
	RebirthUnit.OverKill = OriginUnit.OverKill;
}

static const FCCUnitState& _FindCrossFireUnit(FCCCombatCubeState& InOutState, ECCFaction Faction, int32 Slot)
{
	const ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	const int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;

	for (FCCUnitState& Unit : InOutState.UnitsState.Units)
	{
		if (Unit.Faction != Faction)
		{
			continue;
		}

		if (Unit.Slot != Slot)
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Unit.CombatMultiSide, CurrentWaveIndex, Unit.SpawnedWaveIndex))
		{
			continue;
		}

		if (Unit.GetCrowdControlState(GetCMS(), ECrowdControl::CrossFire) == 0)
		{
			continue;
		}

		return Unit;
	}

	static FCCUnitState Dummy;
	return Dummy;
}

FCCUnitId _SwitchToCrossFire(FCCCombatCubeState& InOutState, ECCFaction SourceFaction, const FCMSSkillRow& SkillRow, const FCCUnitId& OriginalTargetId)
{
	if (SkillRow.Target == ETargetType::HostileSingle
		|| SkillRow.Target == ETargetType::HostileAll)
	{
		ECCFaction EnemyFaction = (SourceFaction == ECCFaction::Ally) ? ECCFaction::Enemy : ECCFaction::Ally;
		for (const FCCUnitState* U : InOutState.UnitsState.GetAliveUnits(EnemyFaction))
		{
			if (U->GetCrowdControlState(GetCMS(), ECrowdControl::CrossFire) > 0)
			{
				FCCUnitState& TempTargetUnit = InOutState.UnitsState.FindUnitState(OriginalTargetId, false);
				Q6JsonLog(Display, "CrossFire change target",
					Q6KV("old unit type", TempTargetUnit.UnitType),
					Q6KV("new unit type", U->UnitType));

				return U->UnitId;
			}
		}
	}

	return OriginalTargetId;
}

static void _InheritCrossFire(const FActionContext& Context, FCCCombatCubeState& InOutState, const FCCUnitId& ParentId, const FCCUnitId& ChildId)
{
	if (ParentId == CCUnitIdInvalid)
	{
		return;
	}
	FCCUnitState& Parent = InOutState.UnitsState.FindUnitState(ParentId);
	if (Parent.UnitId == CCUnitIdInvalid)
	{
		return;
	}

	const FCCUnitState& Child = InOutState.UnitsState.FindUnitState(ChildId);

	for (int i = Parent.Buffs.Num() - 1; i >= 0; --i)
	{
		FCCBuffState& B = Parent.Buffs[i];
		if (HasCrowdControlState(B, ECrowdControl::CrossFire) == 0)
		{
			continue;
		}

		_CreateBuff(Context, InOutState, B.SourceUnitId, ChildId, B.BuffType, B.Duration, B.HitCount, B.BuffLevel, InOutState.TurnState.TurnCount,
			false, B.BornCategory, CCSkillIdInvalid, false);
		Parent.Buffs.RemoveAt(i);
		Q6JsonLog(Display, "inherit crossfile", Q6KV("parent unit type", Parent.UnitType), Q6KV("child unit type", Child.UnitType));
		return;
	}
}

static void _InitMonster(FCCUnitState& NewUnitState, const FCMSMonsterRow& MonsterRow)
{
	if (MonsterRow.IsInvalid())
	{
		return;
	}

	NewUnitState.TurnSkillGroup = MonsterRow.TurnSkillGroup;

	for (const FCMSMonsterPatternRow* P : MonsterRow.GetPatterns())
	{
		const FCMSSkillRow& SRow = P->GetSkill();
		if (SRow.IsInvalid())
		{
			continue;
		}

		for (FCCSkillState& S : NewUnitState.Skills)
		{
			if (S.SkillType != SRow.Type)
			{
				continue;
			}

			S.IsPattern = true;

			FCCPatternState NewPattern;
			NewPattern.Type = P->CmsType();
			NewPattern.SkillId = S.SkillId;

			NewUnitState.Patterns.Add(NewPattern);
			break;
		}
	}
}

static void _SpawnUnit(const FActionContext& Context, FCCCombatCubeState& InOutState, const FCCSpawnUnitParam& InSpawnParam, FCCUnitId OriginalUnitId = CCUnitIdInvalid, FCCUnitId SourceUnitId = CCUnitIdInvalid)
{
	if (InSpawnParam.UnitType == UnitTypeInvalid.x)
	{
		return;
	}

	FCCUnitState NewUnitState;
	NewUnitState.UnitId = InOutState.UnitsState.NextUnitId;
	NewUnitState.UnitType = InSpawnParam.UnitType;
	NewUnitState.Slot = InSpawnParam.Slot;
	NewUnitState.Faction = InSpawnParam.Faction;
	NewUnitState.Category = InSpawnParam.Category;
	NewUnitState.Level = InSpawnParam.Level;
	NewUnitState.Grade = InSpawnParam.Grade;
	NewUnitState.RebirthSkillCount = InSpawnParam.RebirthSkillCount;
	NewUnitState.LiveTurnCount = InSpawnParam.LiveTurnCount;
	NewUnitState.Sculpture = InSpawnParam.Sculpture;
	NewUnitState.Relic = InSpawnParam.Relic;
	NewUnitState.CharacterId = InSpawnParam.CharacterId;
	NewUnitState.UnitAttributes = NewObject<UCCUnitAttributes>();
	NewUnitState.CheatFixedNoteSkillId = CCSkillIdInvalid;
	NewUnitState.CombatMultiSide = InSpawnParam.CombatMultiSide;

	const FCMSAdditionalPointRow* AdditionalPoint = nullptr;
	if (NewUnitState.Faction == ECCFaction::Enemy)
	{
		const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InOutState.CombatSeed.SagaType);
		if (SagaRow.IsInvalid())
		{
			Q6JsonLog(Error, "failed spawnunit(). there is no saga info.", Q6KV("UnitType", NewUnitState.UnitType.x));
			return;
		}
		AdditionalPoint = const_cast<FCMSAdditionalPointRow*>(GetCMS()->GetAdditionalPoint(SagaRow.Difficulty, NewUnitState.Category));
		if (!AdditionalPoint)
		{
			Q6JsonLog(Error, "wrong wave monster additional point.", Q6KV("UnitType", NewUnitState.UnitType.x));
			return;
		}
	}

	int64 OutUnitMaxHealth;
	int64 OutUnitAtk;
	int64 OutUnitDef;
	Attribute::GetUnitAttribute(GetCMS(), InSpawnParam.Category, FUnitType(InSpawnParam.UnitType), InSpawnParam.Level, InSpawnParam.Grade, AdditionalPoint,
		OutUnitMaxHealth, OutUnitAtk, OutUnitDef);

	int64 OutSculptureMaxHealth;
	int64 OutSculptureAtk;
	int64 OutSculptureDef;
	Attribute::GetSculptureAttribute(GetCMS(), InSpawnParam.Sculpture.Type, InSpawnParam.Sculpture.Level, InSpawnParam.Sculpture.Tier, InSpawnParam.Sculpture.Grade,
		OutSculptureMaxHealth, OutSculptureAtk, OutSculptureDef);

	int64 OutRelicMaxHealth;
	int64 OutRelicAtk;
	int64 OutRelicDef;
	Attribute::GetRelicAttribute(GetCMS(), InSpawnParam.Relic.Type, InSpawnParam.Relic.Level, InSpawnParam.Relic.Tier, InSpawnParam.Relic.Grade,
		OutRelicMaxHealth, OutRelicAtk, OutRelicDef);

	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::MaxHealth, OutUnitMaxHealth + OutSculptureMaxHealth + OutRelicMaxHealth);
	NewUnitState.Health = (NewUnitState.UnitAttributes->GetAttributeValue(EUnitAttribute::MaxHealth) * InSpawnParam.HealthPermil) / 1000;
	NewUnitState.UA = 0;
	NewUnitState.SA = 0;
	NewUnitState.OverKill = 0;

	bool bUASADisabled = NewUnitState.Category == EAttributeCategory::RecommendJoker;
	const FCMSCharacterXpRow& XpRow = GetCMS()->GetCharacterXpRowOrDummy(FCharacterXpType(InSpawnParam.Level));
	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::MaxUA, bUASADisabled ? 0 : XpRow.MaxUA);
	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::MaxSA, bUASADisabled ? 0 : XpRow.MaxSA);

	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::Atk, OutUnitAtk + OutSculptureAtk + OutRelicAtk);
	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::Def, OutUnitDef + OutSculptureDef + OutRelicDef);
	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(NewUnitState.UnitType));
	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::Criper, CMSUnitRow.Criper);
	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::NoteAceBonus, CMSUnitRow.NoteAceBonus);
	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::NoteBreakBonus, CMSUnitRow.NoteBreakBonus);
	NewUnitState.UnitAttributes->SetConstAttributeValue(EUnitAttribute::NoteCloserBonus, CMSUnitRow.NoteCloserBonus);

	NewUnitState.bSupporter = false;
	NewUnitState.bStraightNote = false;
	NewUnitState.NextBuffId = FCCBuffId(1);
	NewUnitState.NextSkillId = INITIALIZE_SKILL_ID;

	// ECombatMultiSide::Both use SpawnedWaveIndex only
	NewUnitState.SpawnedWaveIndex = InOutState.TurnState.CurrentWaveIndex;

	const FCMSUnitRow& SpawnUnitCMSRow = CMSUnitRow;
	_FillSkillStateFromCMS(NewUnitState.NextSkillId, ESkillCategory::Ultimate, SpawnUnitCMSRow.GetUltimateSkills(), NewUnitState.Skills);
	_FillSkillStateFromCMS(NewUnitState.NextSkillId, ESkillCategory::Normal, SpawnUnitCMSRow.GetNormalSkills(), NewUnitState.Skills);
	_FillSkillStateFromCMS(NewUnitState.NextSkillId, ESkillCategory::Support, SpawnUnitCMSRow.GetSupportSkills(), NewUnitState.Skills);
	_FillSkillStateFromCMS(NewUnitState.NextSkillId, ESkillCategory::TurnBegin, SpawnUnitCMSRow.GetTurnSkills(), NewUnitState.Skills);
	_FillSkillStateFromCMS(NewUnitState.NextSkillId, ESkillCategory::Double, SpawnUnitCMSRow.GetDoubleSkill(), NewUnitState.Skills);

	ensure(InOutState.UnitsState.Units.FindByPredicate([&NewUnitState](const FCCUnitState& InUnitState) { return InUnitState.UnitId == NewUnitState.UnitId; }) == nullptr);

	if (InSpawnParam.SpawnReason == ESpawnReason::Rebirth)
	{
		_SyncRebirthUnit(Context, InOutState, OriginalUnitId, NewUnitState);
	}
	else
	{
		for (FCCSkillState* ItSkill : NewUnitState.GetSkillStates(ESkillCategory::Ultimate))
		{
			ItSkill->Level = FMath::Clamp(InSpawnParam.UltimateSkillLevel,
				CombatCubeConst::Q6_MIN_SKILL_LEVEL,
				CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);
		}
		for (FCCSkillState* ItSkill : NewUnitState.GetSkillStates(ESkillCategory::Support))
		{
			ItSkill->Level = FMath::Clamp(InSpawnParam.SupportSkillLevel,
				CombatCubeConst::Q6_MIN_SKILL_LEVEL,
				CombatCubeConst::Q6_MAX_SKILL_LEVEL);
		}
		TArray<FCCSkillState*> TurnBegins = NewUnitState.GetSkillStates(ESkillCategory::TurnBegin);
		for (int32 i = 0; i < TurnBegins.Num(); ++i)
		{
			if (InSpawnParam.TurnSkillLevels.IsValidIndex(i))
			{
				TurnBegins[i]->Level = FMath::Clamp(InSpawnParam.TurnSkillLevels[i],
					CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL);
			}
			else
			{
				TurnBegins[i]->Level = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
			}
		}

		for (FCCSkillState& S : NewUnitState.Skills)
		{
			if (InOutState.SkillProp[(int32)S.Category].bHasWaitTime == false)
			{
				continue;
			}

			int32 CoolTime = CombatCubeConst::Q6_BASE_SKILL_COOLDOWN;
			int32 WaitTime = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
			int32 InitWaitDown = CombatCubeConst::Q6_BASE_SKILL_WAITDOWN;
			_GetSkillTime(S.SkillType, S.Level, CoolTime, WaitTime, InitWaitDown);
			S.CoolTime = CoolTime;
			S.WaitTime = WaitTime;
			S.Waitdown = InitWaitDown;
			S.UsingCount = 0;
		}
	}

	const FCMSMonsterRow& MonsterRow = GetCMS()->GetMonsterRowOrDummy(FMonsterType(SpawnUnitCMSRow.Type));
	_InitMonster(NewUnitState, MonsterRow);

	InOutState.UnitsState.Units.Add(NewUnitState);

	Q6JsonLog(Display, "_SpawnUnit",\
		Q6KV("unit type", InSpawnParam.UnitType),\
		Q6KV("slot", InSpawnParam.Slot), \
		Q6KV("MaxHealth", OutUnitMaxHealth),\
		Q6KV("Atk", OutUnitAtk),\
		Q6KV("Def", OutUnitDef));

	if (InOutState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		if (UCombatCubeStateUtil::IsCurrentCombatMultiSide(InOutState.TurnState.CurrentCombatMultiSide, NewUnitState.CombatMultiSide))
		{
			UCCSpawnUnitEvent* SpawnUnitEvent = NewObject<UCCSpawnUnitEvent>();
			SpawnUnitEvent->UnitState = NewUnitState;
			SpawnUnitEvent->SourceUnitId = SourceUnitId;
			SpawnUnitEvent->SpawnReason = InSpawnParam.SpawnReason;
			Context.OnEvent.Broadcast(SpawnUnitEvent);
		}
	}
	else
	{
		UCCSpawnUnitEvent* SpawnUnitEvent = NewObject<UCCSpawnUnitEvent>();
		SpawnUnitEvent->UnitState = NewUnitState;
		SpawnUnitEvent->SourceUnitId = SourceUnitId;
		SpawnUnitEvent->SpawnReason = InSpawnParam.SpawnReason;
		Context.OnEvent.Broadcast(SpawnUnitEvent);
	}

	FCCUnitId EmptyId = CCUnitIdInvalid;

	TArray<FCCUnitId> ExistIds;
	ExistIds.Push(NewUnitState.UnitId);
	for (const FCCUnitState& U : InOutState.UnitsState.Masters)
	{
		ExistIds.Push(U.UnitId);
	}
	for (const FCCUnitState& U : InOutState.UnitsState.Units)
	{
		ExistIds.Push(U.UnitId);
	}

	for (int TryId = 1; TryId <= CombatCubeConst::Q6_MAX_SPAWN_UNITS_PER_GAME; ++TryId)
	{
		if (ExistIds.Find(FCCUnitId(TryId)) != INDEX_NONE)
		{
			continue;
		}

		EmptyId = FCCUnitId(TryId);
		break;
	}

	if (EmptyId == CCUnitIdInvalid)
	{
		Q6JsonLogBro(Warning, "Spawn unit count per game is over limit",
			Q6KV("limit", CombatCubeConst::Q6_MAX_SPAWN_UNITS_PER_GAME));
		return;
	}

	InOutState.UnitsState.NextUnitId = EmptyId;

	int32 CreatedTurnCount = InOutState.TurnState.TurnCount;
	if (InOutState.TurnState.CurrentPhase == ECCTurnPhase::Prepare)
	{
		CreatedTurnCount = InOutState.TurnState.TurnCount + 1;
	}

	for (const FCMSBuffRow* PassiveRow : SpawnUnitCMSRow.GetPassiveBuffs())
	{
		if (NewUnitState.RebirthSkillCount > 0
			&& (PassiveRow->FollowMoment == EMoment::PostDie
			|| PassiveRow->FollowMoment == EMoment::AtFirstSpawn))
		{
			continue;
		}

		_CreateBuff(Context, InOutState, NewUnitState.UnitId, NewUnitState.UnitId, PassiveRow->Type, PassiveRow->Duration, PassiveRow->HitCount,
			CombatCubeConst::Q6_MAX_SKILL_LEVEL, CreatedTurnCount, false, ESkillCategory::Equipment, CCSkillIdInvalid, true);
	}

	if (InSpawnParam.Sculpture.Type != SculptureTypeInvalid)
	{
		const FCMSSculptureRow& Row = GetCMS()->GetSculptureRowOrDummy(InSpawnParam.Sculpture.Type);
		for (const FCMSBuffRow* Buff : Row.GetBuff())
		{
			if (NewUnitState.RebirthSkillCount > 0
				&& (Buff->FollowMoment == EMoment::PostDie
				|| Buff->FollowMoment == EMoment::AtFirstSpawn))
			{
				continue;
			}

			_CreateBuff(Context, InOutState, NewUnitState.UnitId, NewUnitState.UnitId, Buff->Type, Buff->Duration, Buff->HitCount,
				InSpawnParam.Sculpture.Tier, CreatedTurnCount, false, ESkillCategory::Equipment, CCSkillIdInvalid);
		}
	}

	if (InSpawnParam.Relic.Type != RelicTypeInvalid)
	{
		const FCMSRelicRow& Row = GetCMS()->GetRelicRowOrDummy(InSpawnParam.Relic.Type);
		for (const FCMSBuffRow* Buff : Row.GetBuff())
		{
			if (NewUnitState.RebirthSkillCount > 0
				&& (Buff->FollowMoment == EMoment::PostDie
					|| Buff->FollowMoment == EMoment::AtFirstSpawn))
			{
				continue;
			}

			_CreateBuff(Context, InOutState, NewUnitState.UnitId, NewUnitState.UnitId, Buff->Type, Buff->Duration, Buff->HitCount,
				InSpawnParam.Relic.Tier, CreatedTurnCount, false, ESkillCategory::Equipment, CCSkillIdInvalid);
		}
	}

	_InheritCrossFire(Context, InOutState, OriginalUnitId, NewUnitState.UnitId);

	FCCUnitState& MomentTargetUnit = InOutState.UnitsState.FindUnitState(NewUnitState.UnitId);
	_ReadyMomentSkill(InOutState, MomentTargetUnit, ESkillCategory::Equipment, EMoment::AtFirstSpawn, CCUnitIdInvalid);
	_ReadyMomentSkill(InOutState, MomentTargetUnit, ESkillCategory::Equipment, EMoment::AtSpawn, CCUnitIdInvalid);
}

static void _SpawnWaveMonsters(const FActionContext& Context, FCCCombatCubeState& InOutState, const FCMSWaveRow* InWaveRow, const int32 InWaveIndex)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InOutState.CombatSeed.SagaType);
	const int32 TotalWaveIndex = InOutState.CombatSeed.Seed.WaveMonsters.Num();
	const bool bHasBothSide = TotalWaveIndex % 2 == 1;

	// Spawn Monsters
	for (int32 i = 1; i <= CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT; ++i)
	{
		FUnitType OutUnitType = UnitTypeInvalid;
		int32 OutLevel = 1;
		FCMSAdditionalPointRow* OutAdditionalPoint = nullptr;

		if (!GetCMS()->GetWaveMonsterInfo(Context, InOutState, InWaveRow, SagaRow.Difficulty, i, InWaveIndex, OutUnitType, OutLevel, &OutAdditionalPoint))
		{
			continue;
		}

		const FCMSUnitRow& MonsterRow = GetCMS()->GetUnitRowOrDummy(OutUnitType);

		FCCCombatSeedUnit EnemySeed;
		EnemySeed.UnitType = OutUnitType;
		EnemySeed.Faction = ECCFaction::Enemy;
		EnemySeed.Category = MonsterRow.AttributeCategory;
		EnemySeed.Level = OutLevel;
		EnemySeed.Grade = OutAdditionalPoint->Grade;
		EnemySeed.UltimateSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
		EnemySeed.SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
		EnemySeed.TurnSkillLevels.Init(CombatCubeConst::Q6_MIN_SKILL_LEVEL, CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);

		// the odd waves means the last wave is both side
		if (InOutState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide && bHasBothSide && InWaveIndex == TotalWaveIndex - 1)
		{
			EnemySeed.CombatMultiSide = ECombatMultiSide::Both;
		}
		else
		{
			EnemySeed.CombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
		}

		FCCSpawnUnitParam Params;
		UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(EnemySeed, &Params, ESpawnReason::Init, i, 0, 1000, 0);

		_SpawnUnit(Context, InOutState, Params);
	}
}

static void _SpawnCombatMultiSideUnits(const FActionContext& Context, FCCCombatCubeState& InOutState, bool bInIsNeedToSpawn)
{
	if (bInIsNeedToSpawn)
	{
		const ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;

		int32 UnitCount = InOutState.CombatSeed.Units.Num();
		UnitCount = FMath::Min(UnitCount, CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT + CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
		for (int i = 0; i < UnitCount; ++i)
		{
			const FCCCombatSeedUnit& SeedUnit = InOutState.CombatSeed.Units[i];
			if (SeedUnit.Faction != ECCFaction::Ally)
			{
				Q6JsonLogPawn(Error, "CombatSeed ally units are broken");
				return;
			}

			if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, SeedUnit.CombatMultiSide))
			{
				continue;
			}

			const int32 SlotIndex = i % CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT + 1;

			FCCSpawnUnitParam Params;
			UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(SeedUnit, &Params, ESpawnReason::Init, SlotIndex, 0, 1000, 0);

			_SpawnUnit(Context, InOutState, Params);
		}
	}
	else
	{
		// if this turn is not new wave, don't need to spawn units
		for (FCCUnitId& UnitId : InOutState.UnitsState.GetAllyUnits())
		{
			const FCCUnitState& UnitState = InOutState.UnitsState.FindUnitState(UnitId);

			UCCSpawnUnitEvent* SpawnUnitEvent = NewObject<UCCSpawnUnitEvent>();
			SpawnUnitEvent->UnitState = UnitState;
			SpawnUnitEvent->SourceUnitId = UnitId;
			SpawnUnitEvent->SpawnReason = ESpawnReason::ChangeCombatMultiSide;
			Context.OnEvent.Broadcast(SpawnUnitEvent);
		}
	}
}

static void _SpawnCombatMultiSideMonsters(const FActionContext& Context, FCCCombatCubeState& InOutState, bool bInIsNeedToSpawn)
{
	if (bInIsNeedToSpawn)
	{
		if (InOutState.CombatSeed.CombatMultiSideInfo.OfflineEnemies.Num() == 0)
		{
			return;
		}

		const int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;
		const ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;

		const int32 EnemyCount = CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT + CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT;
		const int32 EnemyIndex = CurrentWaveIndex * EnemyCount;

		for (int32 i = 0; i < EnemyCount; ++i)
		{
			int32 Index = EnemyIndex + i;
			if (!InOutState.CombatSeed.CombatMultiSideInfo.OfflineEnemies.IsValidIndex(Index))
			{
				break;
			}

			FCCCombatSeedUnit& EnemySeed = InOutState.CombatSeed.CombatMultiSideInfo.OfflineEnemies[Index];
			if (EnemySeed.UnitType == UnitTypeInvalid || !UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, EnemySeed.CombatMultiSide))
			{
				continue;
			}

			const int32 SlotIndex = i % CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT + 1;

			FCCSpawnUnitParam Params;
			UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(EnemySeed, &Params, ESpawnReason::Init, SlotIndex, 0, 1000, 0);

			_SpawnUnit(Context, InOutState, Params);
		}
	}
	else
	{
		// if this turn is not new wave, don't need to spawn units
		for (FCCUnitId& UnitId : InOutState.UnitsState.GetEnemyUnits())
		{
			const FCCUnitState& UnitState = InOutState.UnitsState.FindUnitState(UnitId);

			UCCSpawnUnitEvent* SpawnUnitEvent = NewObject<UCCSpawnUnitEvent>();
			SpawnUnitEvent->UnitState = UnitState;
			SpawnUnitEvent->SourceUnitId = UnitId;
			SpawnUnitEvent->SpawnReason = ESpawnReason::ChangeCombatMultiSide;
			Context.OnEvent.Broadcast(SpawnUnitEvent);
		}
	}
}

static void _ChangeCombatMultiSideInfo(FCCCombatCubeState& InOutState)
{
	// change to other side
	InOutState.TurnState.CurrentCombatMultiSide = (InOutState.TurnState.CurrentCombatMultiSide == ECombatMultiSide::Sub) ? ECombatMultiSide::Main : ECombatMultiSide::Sub;

	// swap the CurrentWaveIndex
	int32 OldCombatMultiSideWaveIndex = InOutState.TurnState.OldCombatMultiSideWaveIndex;
	InOutState.TurnState.OldCombatMultiSideWaveIndex = InOutState.TurnState.CurrentWaveIndex;
	InOutState.TurnState.CurrentWaveIndex = OldCombatMultiSideWaveIndex;

	// swap the PlayerTargetUnitId
	FCCUnitId OldCombatMultiSidePlayerTargetUnitId = InOutState.TurnState.OldCombatMultiSidePlayerTargetUnitId;
	InOutState.TurnState.OldCombatMultiSidePlayerTargetUnitId = InOutState.TurnState.PlayerTargetUnitId;
	InOutState.TurnState.PlayerTargetUnitId = OldCombatMultiSidePlayerTargetUnitId;

	// units state
	InOutState.UnitsState.CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	InOutState.UnitsState.CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;
}

static int32 _GetOfflineEnemyNumSlots(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	const int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;
	const ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;

	const int32 EnemyCount = CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT + CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT;
	const int32 EnemyIndex = CurrentWaveIndex * EnemyCount;

	int32 OfflineEnemyNumSlots = 0;

	for (int32 i = 0; i < EnemyCount; ++i)
	{
		int32 Index = EnemyIndex + i;
		if (!InOutState.CombatSeed.CombatMultiSideInfo.OfflineEnemies.IsValidIndex(Index))
		{
			break;
		}

		FCCCombatSeedUnit& EnemySeed = InOutState.CombatSeed.CombatMultiSideInfo.OfflineEnemies[Index];
		if (EnemySeed.UnitType == UnitTypeInvalid || !UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, EnemySeed.CombatMultiSide))
		{
			continue;
		}

		OfflineEnemyNumSlots++;
	}

	return OfflineEnemyNumSlots;
}

static bool _IsAchievedMultiSideBattleRankBonusBySkillCategory(EMultiSideRankBonusCategory InBonusCategory, ESkillCategory InSkillCategory)
{
	if ((InBonusCategory == EMultiSideRankBonusCategory::Ultimate && InSkillCategory == ESkillCategory::Ultimate)
		|| (InBonusCategory == EMultiSideRankBonusCategory::Double && InSkillCategory == ESkillCategory::Double))
	{
		return true;
	}

	return false;
}

static bool _IsAchievedMultiSideBattleRankBonusBySkillNote(EMultiSideRankBonusCategory InBonusCategory, ESkillNote InSkillNote)
{
	if ((InBonusCategory == EMultiSideRankBonusCategory::Ace && InSkillNote == ESkillNote::Ace)
		|| (InBonusCategory == EMultiSideRankBonusCategory::Break && InSkillNote == ESkillNote::Break)
		|| (InBonusCategory == EMultiSideRankBonusCategory::Closer && InSkillNote == ESkillNote::Closer))
	{
		return true;
	}

	return false;
}

static bool _IsAchievedMultiSideBattleRankBonusByCritical(EMultiSideRankBonusCategory InBonusCategory, bool bInCritical)
{
	if (InBonusCategory == EMultiSideRankBonusCategory::Critical && bInCritical)
	{
		return true;
	}

	return false;
}

static bool _IsAchievedMultiSideBattleRankBonusByOverKillPoint(EMultiSideRankBonusCategory InBonusCategory, bool bInGotOverKillPoint)
{
	if (InBonusCategory == EMultiSideRankBonusCategory::OverKillPoint && bInGotOverKillPoint)
	{
		return true;
	}

	return false;
}

static bool _IsAchievedMultiSideBattleRankBonusByNatureType(EMultiSideRankBonusCategory InBonusCategory, ENatureType InNatureType)
{
	if ((InBonusCategory == EMultiSideRankBonusCategory::Fire && InNatureType == ENatureType::Fire)
		|| (InBonusCategory == EMultiSideRankBonusCategory::Water && InNatureType == ENatureType::Water)
		|| (InBonusCategory == EMultiSideRankBonusCategory::Wind && InNatureType == ENatureType::Wind)
		|| (InBonusCategory == EMultiSideRankBonusCategory::Light && InNatureType == ENatureType::Light)
		|| (InBonusCategory == EMultiSideRankBonusCategory::Dark && InNatureType == ENatureType::Dark))
	{
		return true;
	}

	return false;
}

static bool _IsAchievedMultiSideBattleRankBonusByChainSkillNote(EMultiSideRankBonusCategory InBonusCategory, ESkillNote InChainSkillNote, int32 InSkillSequence)
{
	if ((InBonusCategory == EMultiSideRankBonusCategory::ChainAce && InChainSkillNote == ESkillNote::Ace)
		|| (InBonusCategory == EMultiSideRankBonusCategory::ChainBreak && InChainSkillNote == ESkillNote::Break)
		|| (InBonusCategory == EMultiSideRankBonusCategory::ChainCloser && InChainSkillNote == ESkillNote::Closer))
	{
		if (InSkillSequence == 3)
		{
			return true;
		}
	}
	return false;
}

static bool _IsAchievedMultiSideBattleRankBonusByChordNote(EMultiSideRankBonusCategory InBonusCategory, EApplyTag InChordNote)
{
	if ((InBonusCategory == EMultiSideRankBonusCategory::ChordAce && InChordNote == EApplyTag::ChordAce)
		|| (InBonusCategory == EMultiSideRankBonusCategory::ChordBreak && InChordNote == EApplyTag::ChordBreak)
		|| (InBonusCategory == EMultiSideRankBonusCategory::ChordCloser && InChordNote == EApplyTag::ChordCloser))
	{
		return true;
	}

	return false;
}

static int32 _GetMultiSideBattleRankBonusConst(const CCSkillYard& InYard, FCCCombatCubeState& InOutState, bool bInCritical, bool bInGotOverKillPoint)
{
	EMultiSideRankBonusCategory BonusCategory = InOutState.CombatSeed.CombatMultiSideInfo.RankBonusCategory;
	if (BonusCategory == EMultiSideRankBonusCategory::None || !IsValidEMultiSideRankBonusCategory((int32)BonusCategory))
	{
		return 0;
	}

	ESkillNote ChainSkillNote = ESkillNote::None;
	int32 SkillSequence = 0;

	if (BonusCategory == EMultiSideRankBonusCategory::ChainAce
		|| BonusCategory == EMultiSideRankBonusCategory::ChainBreak
		|| BonusCategory == EMultiSideRankBonusCategory::ChainCloser)
	{
		ChainSkillNote = _GetChainSkillNote(InOutState);
		SkillSequence = InOutState.UnitsState.GetCountSkillsOnCurPhase(InOutState, InYard.SourceUnit.Faction, InYard.SkillDesc.SkillCategory);
	}

	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(InYard.SourceUnit.UnitType));
	bool bAchieveBonusCondition = false;
	if (_IsAchievedMultiSideBattleRankBonusBySkillCategory(BonusCategory, InYard.SkillDesc.SkillCategory))
	{
		bAchieveBonusCondition = true;
	}
	else if (_IsAchievedMultiSideBattleRankBonusBySkillNote(BonusCategory, InYard.SkillDesc.SkillNote))
	{
		bAchieveBonusCondition = true;
	}
	else if (_IsAchievedMultiSideBattleRankBonusByCritical(BonusCategory, bInCritical))
	{
		bAchieveBonusCondition = true;
	}
	else if (_IsAchievedMultiSideBattleRankBonusByOverKillPoint(BonusCategory, bInGotOverKillPoint))
	{
		bAchieveBonusCondition = true;
	}
	else if (_IsAchievedMultiSideBattleRankBonusByNatureType(BonusCategory, CMSUnitRow.NatureType))
	{
		bAchieveBonusCondition = true;
	}
	else if (_IsAchievedMultiSideBattleRankBonusByChainSkillNote(BonusCategory, ChainSkillNote, SkillSequence))
	{
		bAchieveBonusCondition = true;
	}
	else if (_IsAchievedMultiSideBattleRankBonusByChordNote(BonusCategory, InYard.ChordNote))
	{
		bAchieveBonusCondition = true;
	}

	if (bAchieveBonusCondition)
	{
		return GetCMS()->GetMultiSideBattleRankBonusConst(BonusCategory);
	}

	return 0;
}

static void _AccumulateCombatMultiSideRankScore(const CCSkillYard& InYard, FCCCombatCubeState& InOutState, int32 InBaseDamage, int32 InExtraDamage, bool bInCritical, bool bInGotOverKillPoint)
{
	const int32 Damage = (InBaseDamage + InExtraDamage);

	const int32 BonusScoreConst = _GetMultiSideBattleRankBonusConst(InYard, InOutState, bInCritical, bInGotOverKillPoint);
	const int32 BonusScore = Damage * BonusScoreConst / 1000 * MultiSideBattleRankConst::Q6_RANK_DMG_CONST / 1000;
	const int32 CombatScore = Damage * MultiSideBattleRankConst::Q6_RANK_DMG_CONST / 1000;

	const int32 CombatRankingScore = CombatScore + BonusScore;

	InOutState.CombatMultiSideState.AccumulatedRankScore += CombatRankingScore;
	InOutState.CombatMultiSideState.AccumulatedBonusScore += BonusScore;

#if !UE_BUILD_SHIPPING
	GEngine->ClearOnScreenDebugMessages();

	if (UQ6GameInstance::Get() && UQ6GameInstance::Get()->IsShowMultiSideBattleRankScore())
	{
		const int32 TimeToDisplay = 1000;
		const int32 TurnCount = InOutState.TurnState.TurnCount;
		const int32 TotalScore = InOutState.CombatMultiSideState.AccumulatedRankScore;
		const int32 TotalBonus = InOutState.CombatMultiSideState.AccumulatedBonusScore;
		Q6JsonLogPawn(Display, "MultiSideBattleRankScore", Q6KV("Turn", TurnCount));
		Q6JsonLogPawn(Display, "MultiSideBattleRankScore", Q6KV("Score", CombatRankingScore), Q6KV("Bonus", BonusScore));
		Q6JsonLogPawn(Display, "MultiSideBattleRankScore", Q6KV("TotalScore", TotalScore), Q6KV("TotalBonus", TotalBonus));

		GEngine->AddOnScreenDebugMessage(1, TimeToDisplay, FColor::Yellow, FString::Printf(TEXT("\n\n\nScore : %d, Bonus : %d"), CombatRankingScore, BonusScore));
		GEngine->AddOnScreenDebugMessage(2, TimeToDisplay, FColor::Yellow, FString::Printf(TEXT("TotalScore : %d, TotalBonus : %d"), TotalScore, TotalBonus));
	}
#endif
}

static void _SendCombatMultiSideRankScore(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	// bonus score will be used in widget
	const int32 AccumulatedRankScore = InOutState.CombatMultiSideState.AccumulatedRankScore;
	const int32 AccumulatedBonusScore = InOutState.CombatMultiSideState.AccumulatedBonusScore;

	const int32 TurnCount = InOutState.TurnState.TurnCount;
	const int32	TurnConst = FMath::Max(100, MultiSideBattleRankConst::Q6_RANK_ACONST - TurnCount * MultiSideBattleRankConst::Q6_RANK_TURN_CONST);

	const int32 SurviveCount = FMath::Max(0, InOutState.UnitsState.GetAliveUnitsAllOfCombatMultiSide(ECCFaction::Ally).Num() - 1);
	const int32 SurviveScoreConst = SurviveCount * MultiSideBattleRankConst::Q6_RANK_SURVIVE_CONST + 1000;

	const int32 BossKillConst = FMath::Max(1000, MultiSideBattleRankConst::Q6_RANK_BOSS_KILL_CONST);

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InOutState.CombatSeed.SagaType);
	const int32 EventConst = GetCMS()->GetMultiSideBattleRankEventConst(SagaRow.Difficulty) + 1000;

	int32 FinalRankScore = AccumulatedRankScore * TurnConst  / 1000 * SurviveScoreConst / 1000 * BossKillConst / 1000 * EventConst / 1000;
	int32 FinalBonusScore = AccumulatedBonusScore * TurnConst / 1000 * SurviveScoreConst / 1000 * BossKillConst / 1000 * EventConst / 1000;

	InOutState.CombatMultiSideState.FinalRankScore = FinalRankScore;
	InOutState.CombatMultiSideState.FinalBonusScore = FinalBonusScore;
}

static void _ChangeCombatMultiSide(const FActionContext& Context, FCCCombatCubeState& InOutState, bool bInClearWave)
{
	if (bInClearWave)
	{
		InOutState.TurnState.CurrentWaveIndex++;

		// only despawn old side wave monster -> spawn will be happened the next turn.
		_DespawnOldWaveMonsters(Context, InOutState);
	}

	_ChangeCombatMultiSideInfo(InOutState);

	bool bIsFirstTurn = InOutState.TurnState.TurnCount <= 1;
	bool bIsAliveOldSide = true;

	// if next combat multiside's ally were all dead, rechange combat multiside
	if (!bIsFirstTurn && InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally).Num() == 0)
	{
		_ChangeCombatMultiSideInfo(InOutState);

		bIsAliveOldSide = false;

		if (!bInClearWave)
		{
			// if main or sub party was dead, add turn count always
			InOutState.TurnState.CombatMultiSideTurnCount++;

			// don't need to play wave action
			_ChangePhase(Context, InOutState, ECCTurnPhase::Prepare);
			return;
		}
	}

	// wait to process changing combat multi side
	_ChangePhase(Context, InOutState, ECCTurnPhase::ChangeCombatMultiSide);

	ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	int32 WaveRowIndex = InOutState.TurnState.CurrentWaveIndex;

	bool bIsOfflineMode = InOutState.CombatSeed.CombatMultiSideInfo.bIsOfflineMode;
	if (!bIsOfflineMode)
	{
		WaveRowIndex = UCombatCubeStateUtil::GetCombatMultiSideWaveRowIndex(InOutState.CombatSeed, CurrentCombatMultiSide, WaveRowIndex);
	}

	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(InOutState.CombatSeed.SagaType, WaveRowIndex);
	if (!bIsOfflineMode && !WaveRow)
	{
		Q6JsonLogPawn(Error, "No Wave info - CombatMultiSide", Q6KV("SagaType", InOutState.CombatSeed.SagaType), Q6KV("WaveRowIndex", WaveRowIndex));
		return;
	}

	if (InOutState.CombatSeed.CombatMultiSideInfo.bIsOfflineMode)
	{
		InOutState.TurnState.WaveEnemyNumSlots = _GetOfflineEnemyNumSlots(Context, InOutState);
	}
	else if (WaveRow)
	{
		int32 NumSlots = 0;
		NumSlots = ((WaveRow->Spawns01[0] != UnitTypeInvalid.x) || (WaveRow->Spawns01.Num() > 1)) ? NumSlots + 1 : NumSlots;
		NumSlots = ((WaveRow->Spawns02[0] != UnitTypeInvalid.x) || (WaveRow->Spawns02.Num() > 1)) ? NumSlots + 1 : NumSlots;
		NumSlots = ((WaveRow->Spawns03[0] != UnitTypeInvalid.x) || (WaveRow->Spawns03.Num() > 1)) ? NumSlots + 1 : NumSlots;
		InOutState.TurnState.WaveEnemyNumSlots = NumSlots;
	}

	int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex + 1;	// use wave count for Widget (bonus wave)
	int32 CurrentWaveEnemyNumSlots = InOutState.TurnState.WaveEnemyNumSlots;

	// finish wave or turn
	UCCChangeCombatMultiSide* FinishEvent = NewObject<UCCChangeCombatMultiSide>();
	FinishEvent->CurrentCombatMultiSide = CurrentCombatMultiSide;
	FinishEvent->Wave = CurrentWaveIndex;
	FinishEvent->WaveEnemyNumSlots = CurrentWaveEnemyNumSlots;
	FinishEvent->WaveRowIndex = WaveRowIndex;
	FinishEvent->bStartWave = false;
	Context.OnEvent.Broadcast(FinishEvent);

	// sub side units will be spawned
	bool bIsNeedToSpawnUnits = bIsFirstTurn;
	_SpawnCombatMultiSideUnits(Context, InOutState, bIsNeedToSpawnUnits);

	// start wave or turn
	UCCChangeCombatMultiSide* StartEvent = NewObject<UCCChangeCombatMultiSide>();
	StartEvent->CurrentCombatMultiSide = CurrentCombatMultiSide;
	StartEvent->Wave = CurrentWaveIndex;
	StartEvent->WaveEnemyNumSlots = CurrentWaveEnemyNumSlots;
	StartEvent->WaveRowIndex = WaveRowIndex;
	StartEvent->bStartWave = true;
	Context.OnEvent.Broadcast(StartEvent);

	bool bIsNeedToSpawnMonsters = InOutState.UnitsState.GetAliveUnits(ECCFaction::Enemy).Num() == 0;
	if (bIsNeedToSpawnMonsters && WaveRow && !bIsOfflineMode)
	{
		// combat multi side use WaveRowIndex
		_SpawnWaveMonsters(Context, InOutState, WaveRow, WaveRowIndex);
	}
	else
	{
		_SpawnCombatMultiSideMonsters(Context, InOutState, bIsNeedToSpawnMonsters);
	}

	// select current side target
	UCCTargetSelectedEvent* TargetSelectedEvent = NewObject<UCCTargetSelectedEvent>();
	TargetSelectedEvent->UnitId = InOutState.TurnState.PlayerTargetUnitId;
	TargetSelectedEvent->OldUnitId = CCUnitIdInvalid;
	Context.OnEvent.Broadcast(TargetSelectedEvent);

	// if main party units are alive, add turn count when changing multiside to main
	if (CurrentCombatMultiSide == ECombatMultiSide::Main || !bIsAliveOldSide)
	{
		InOutState.TurnState.CombatMultiSideTurnCount++;
	}

	_ChangePhase(Context, InOutState, ECCTurnPhase::Prepare);
}

static void _InitMasters(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	static_assert((int32)ECCFaction::Max == 2, "need more master.");

	InOutState.UnitsState.Masters.SetNum((int32)ECCFaction::Max);
	for (int i = 0; i < (int32)ECCFaction::Max; ++i)
	{
		FCCUnitState& Master = InOutState.UnitsState.Masters[i];
		Master.UnitId = InOutState.UnitsState.NextUnitId;
		Master.UnitType = UnitTypeInvalid;
		Master.Slot = CombatCubeConst::Q6_INVALID_SLOT;
		Master.Faction = (ECCFaction)i;
		Master.Category = EAttributeCategory::Character;
		Master.Level = 1;
		Master.Grade = EItemGrade::N;
		Master.RebirthSkillCount = 0;
		Master.LiveTurnCount = 0;
		Master.Sculpture = FCCSculptureInfo();
		Master.Relic = FCCRelicInfo();
		Master.CharacterId = FCharacterId();
		Master.UnitAttributes = NewObject<UCCUnitAttributes>();
		Master.UnitAttributes->SetConstAttributeValue(EUnitAttribute::MaxHealth, 1);
		Master.Health = 1;
		Master.UnitAttributes->SetConstAttributeValue(EUnitAttribute::MaxUA, CombatCubeConst::Q6_DEFAULT_MAX_ULTIMATE_GAUGE);
		Master.UA = 0;
		Master.UnitAttributes->SetConstAttributeValue(EUnitAttribute::MaxSA, CombatCubeConst::Q6_DEFAULT_MAX_SUPPORT_GAUGE);
		Master.SA = 0;
		Master.OverKill = 0;
		Master.UnitAttributes->SetConstAttributeValue(EUnitAttribute::Atk, 1);
		Master.UnitAttributes->SetConstAttributeValue(EUnitAttribute::Def, 1);
		Master.UnitAttributes->SetConstAttributeValue(EUnitAttribute::Criper, 0);
		Master.bSupporter = false;
		Master.bStraightNote = false;
		Master.NextBuffId = FCCBuffId(1);
		Master.NextSkillId = INITIALIZE_SKILL_ID;

		if (Master.Faction == ECCFaction::Ally)
		{
			_FillSkillStateFromChain(Master.NextSkillId, Context, Master.Skills);
			_FillSkillStateFromVersa(Master.NextSkillId, Context, Master.Skills);
			_FillSkillStateFromArtifact(Master.NextSkillId, InOutState.CombatSeed.Seed.ArtifactAvailable, Context, Master.Skills);

			const FPetInfo& PetInfo = InOutState.CombatSeed.Seed.PetInfo;
			if (!PetInfo.PetId.IsInvalid())
			{
				_FillSkillStateFromPet(Master.NextSkillId, PetInfo, Master.Skills);
			}
		}

		Q6JsonLog(Display, "_InitMasters", \
			Q6KV("master unit id", Master.UnitId), \
			Q6KV("master faction", (int32)Master.Faction));

		++InOutState.UnitsState.NextUnitId.X;
	}
}

static void _ReadyMomentSkill(FCCCombatCubeState& InOutState, FCCUnitState& Unit, ESkillCategory SkillCategory, EMoment Moment,
	const FCCUnitId& TargetUnitId, const FCCBuffId& ExpireBuffId)
{
	if (SkillCategory == ESkillCategory::Moment) // prevent recursive call.
	{
		if (Moment != EMoment::PostDie)
		{
			return;
		}
	}

	if (Moment == EMoment::AtBuffExpire
		&& ExpireBuffId == CCBuffIdInvalid)
	{
		Q6JsonLog(Error, "wrong AtBuffExpire moment buff id", Q6KV("buff id", ExpireBuffId));
		return;
	}

	if (Moment == EMoment::AtBeaten
		|| Moment == EMoment::AtDodge)
	{
		if (InOutState.SkillProp[(int32)SkillCategory].bActiveAttack != true)
		{
			Q6JsonLog(Error, "wrong AtBeaten,AtDodge moment skill category", Q6KV("skill category", (int32)SkillCategory));
			return;
		}
	}

	for (const FCCBuffState& B : Unit.Buffs)
	{
		const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(B.BuffType));
		if (CMSBuffRow.FollowMoment != Moment || CMSBuffRow.FollowMoment == EMoment::None)
		{
			continue;
		}

		if (ExpireBuffId != CCBuffIdInvalid
			&& ExpireBuffId != B.BuffId)
		{
			continue;
		}

		if (B.BornCategory == ESkillCategory::Equipment
			&& CMSBuffRow.FollowMoment == EMoment::PostDie
			&& Unit.RebirthSkillCount > 0)
		{
			Q6JsonLog(Display, "rebirth unit can not use PostDie from Equipment", Q6KV("unit type", Unit.UnitType), Q6KV("buff type", B.BuffType));
			continue;
		}

		for (const FCMSSkillRow* S : CMSBuffRow.GetFollowMomentSkill())
		{
			if (S->SkillCategory != ESkillCategory::Moment)
			{
				Q6JsonLog(Error, "wrong moment skill", Q6KV("buff type", B.BuffType), Q6KV("follow skill type", S->Type));
				continue;
			}


			int32 NewItemIdx = Unit.Skills.Add(FCCSkillState(Unit.NextSkillId, ESkillCategory::Moment, S->Type, B.BuffLevel,
				CombatCubeConst::Q6_BASE_SKILL_COOLDOWN,
				CombatCubeConst::Q6_BASE_SKILL_WAITDOWN,
				CombatCubeConst::Q6_BASE_SKILL_WAITDOWN));
			++Unit.NextSkillId.X;

			int32 NewIndex = InOutState.ReadyMomentSkills.AddDefaulted();
			FCCMomentSkill* Ready = &(InOutState.ReadyMomentSkills[NewIndex]);
			Ready->UnitId = Unit.UnitId;
			Ready->SkillId = Unit.Skills[NewItemIdx].SkillId;
			Ready->Moment = CMSBuffRow.FollowMoment;
			Ready->BornCategory = B.BornCategory;
			Ready->TargetUnitId = TargetUnitId;

			Q6JsonLog(Display, "ready moment skill", Q6KV("unit id", Ready->UnitId), Q6KV("moment", (int32)Ready->Moment),
				Q6KV("skill id", Unit.Skills[NewItemIdx].SkillId), Q6KV("skill type", S->Type));
		}
	}
}

static void _ApplyMomentSkills(const FActionContext& Context, FCCCombatCubeState& InOutState, EMoment Moment)
{
	// prevent recursive assign.
	TArray<FCCMomentSkill> RebirthSkills;
	TArray<FCCMomentSkill> Skills;
	for (int i = InOutState.ReadyMomentSkills.Num() - 1; i >= 0; --i)
	{
		FCCMomentSkill& R = InOutState.ReadyMomentSkills[i];
		if (R.Moment != Moment)
		{
			continue;
		}

		FCCUnitState& Unit = InOutState.UnitsState.FindUnitState(R.UnitId);
		FCCSkillState* Skill = Unit.GetSkillState(R.SkillId);
		if (!Skill)
		{
			Q6JsonLog(Warning, "moment skill sync failed", Q6KV("unit id", R.UnitId), Q6KV("moment", (int32)R.Moment), Q6KV("skill id", R.SkillId));
			continue;
		}

		bool bRebirth = false;
		bool bSummon = false;
		const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(Skill->SkillType);
		for (const FCMSSkillEffectRow* Row : InSkillRow.GetSkillEffect())
		{
			if (Row->EffectCategory == EEffectCategory::Rebirth
				|| Row->EffectCategory == EEffectCategory::RebirthSummon)
			{
				bRebirth = true;
			}
			if (Row->EffectCategory == EEffectCategory::Summon)
			{
				bSummon = true;
			}
		}

		if (bRebirth && !bSummon)
		{
			RebirthSkills.Add(R);
		}
		else
		{
			Skills.Add(R);
		}

		InOutState.ReadyMomentSkills.RemoveAt(i);
	}

	RebirthSkills.StableSort([&InOutState](const FCCMomentSkill& M1, const FCCMomentSkill& M2)
	{
		FCCUnitState& U1 = InOutState.UnitsState.FindUnitState(M1.UnitId);
		FCCUnitState& U2 = InOutState.UnitsState.FindUnitState(M2.UnitId);
		if (U1.UnitId == CCUnitIdInvalid || U2.UnitId == CCUnitIdInvalid)
		{
			return false;
		}
		FCCSkillState* S1 = U1.GetSkillState(M1.SkillId);
		FCCSkillState* S2 = U2.GetSkillState(M2.SkillId);
		if (S1 == nullptr || S2 == nullptr)
		{
			return false;
		}
		const FCMSSkillRow& Row1 = GetCMS()->GetSkillRowOrDummy(S1->SkillType);
		const FCMSSkillRow& Row2 = GetCMS()->GetSkillRowOrDummy(S2->SkillType);

		int32 S1Param = 0;
		for (const FCMSSkillEffectRow* E : Row1.GetSkillEffect())
		{
			if (E->EffectCategory != EEffectCategory::Rebirth)
			{
				continue;
			}
			if (E->Param1 > S1Param)
			{
				S1Param = E->Param1;
			}
		}
		int32 S2Param = 0;
		for (const FCMSSkillEffectRow* E : Row2.GetSkillEffect())
		{
			if (E->EffectCategory != EEffectCategory::Rebirth)
			{
				continue;
			}
			if (E->Param1 > S2Param)
			{
				S2Param = E->Param1;
			}
		}

		if (S1Param > S2Param)
		{
			return true;
		}

		return false;
	});

	for (const FCCMomentSkill& R : RebirthSkills)
	{
		Q6JsonLog(Display, "apply moment skill", Q6KV("unit id", R.UnitId), Q6KV("moment", (int32)R.Moment), Q6KV("skill id", R.SkillId));

		UseSkill(Context, InOutState, R.SkillId, R.UnitId, R.TargetUnitId, R.BornCategory, R.Moment, false, false);
	}

	for (const FCCMomentSkill& R : Skills)
	{
		Q6JsonLog(Display, "apply moment skill", Q6KV("unit id", R.UnitId), Q6KV("moment", (int32)R.Moment), Q6KV("skill id", R.SkillId));

		UseSkill(Context, InOutState, R.SkillId, R.UnitId, R.TargetUnitId, R.BornCategory, R.Moment, false, false);
	}
}

static void _ApplyDamageSkillEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	check(EffectRow.EffectCategory == EEffectCategory::Damage);
	bool bNoDamage = Yard.InOutState.GetGameFlag(EGameFlags::NoDamage);

	UCCSkillEffectEvent* EffectEvent = NewObject<UCCSkillEffectEvent>();
	EffectEvent->SkillEffectType = EffectRow.Type;
	EffectEvent->SourceUnitId = Yard.SourceUnit.UnitId;
	int32 SkillSequence = Yard.InOutState.UnitsState.GetCountSkillsOnCurPhase(Yard.InOutState, Yard.SourceUnit.Faction, Yard.SkillDesc.SkillCategory);
	const int32 OriginDamage = Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (TargetUnit.IsDead()
			&& Yard.InOutState.SkillProp[(int32)Yard.SkillDesc.SkillCategory].bUsableToDeadUnit == false)
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		bool Zombie = TargetUnit.IsDead();

		int64 SumOfAll = 0;
		int64 BaseDamage = 0;
		int64 ExtraDamage = 0;
		int64 ShieldDamage = 0;
		int64 ExtraShieldDamage = 0;

		UCMS* InCMS = GetCMS();
		BaseDamage = Formula::CalcDamage(InCMS, Yard.SourceUnit.Faction, Yard.SourceUnit.GetNatureType(), TargetUnit.GetNatureType(), OriginDamage,
			Yard.InOutState.CombatSeed.SagaType);

		int32 ExtraDMGper = Yard.SourceUnit.GetExtraDMGper(Yard.Context, Yard.InOutState, GetCMS(), TargetUnit, Yard.SkillLevel, Yard.BornCategory);
		if (ExtraDMGper > 0)
		{
			Q6JsonLog(Display, "ExtraDMGper", Q6KV("value", ExtraDMGper));

			ExtraDamage = Formula::CalcExtraDamage(InCMS, OriginDamage, ExtraDMGper);
		}

		int32 ShieldBuffIdx = -1;
		int32 AddShieldDMGper = 0;
		for (int i = 0; i < TargetUnit.Buffs.Num(); ++i)
		{
			FCCBuffState& Itor = TargetUnit.Buffs[i];

			for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(Itor, ECrowdControl::Shield))
			{
				ShieldBuffIdx = i;
				AddShieldDMGper = Formula::GetShieldDMGper(GetCMS(), Effect->Param3,
					Yard.SkillDesc.SkillCategory, Yard.SkillDesc.SkillNote, Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
				Q6JsonLog(Display, "shield AddShieldDMGper", Q6KV("value", AddShieldDMGper));
				break;
			}
		}
		bool bShieldWeakPoint = AddShieldDMGper > CombatCubeConst::Q6_DEFAULT_ADDSHIELDDMGPER;

		if (TargetUnit.Buffs.IsValidIndex(ShieldBuffIdx))
		{
			FCCBuffState& ShieldBuff = TargetUnit.Buffs[ShieldBuffIdx];

			ShieldDamage = Formula::CalcShieldDamage(GetCMS(), OriginDamage, AddShieldDMGper);
			Q6JsonLog(Display, "shield damage", Q6KV("value", ShieldDamage));

			if (ExtraDMGper > 0)
			{
				ExtraShieldDamage = Formula::CalcExtraShieldDamage(GetCMS(), OriginDamage, AddShieldDMGper, ExtraDMGper);
				Q6JsonLog(Display, "extra shield damage", Q6KV("value", ExtraShieldDamage));
			}

			int64 TotalDamage = BaseDamage + ExtraDamage;
			int64 TotalShieldDamage = ShieldDamage + ExtraShieldDamage;
			int64 Shield = ShieldBuff.Shield;
			if (ShieldBuff.Shield - TotalShieldDamage > 0)
			{
				ShieldBuff.Shield = Shield - TotalShieldDamage;
				BaseDamage = 0;
				ExtraDamage = 0;
			}
			else
			{
				ExtraShieldDamage = (ExtraShieldDamage * Shield) / TotalShieldDamage;
				ShieldDamage = Shield - ExtraShieldDamage;

				int64 NewTotalDamage = FMath::Max(0LL, TotalDamage - Shield);
				ExtraDamage = (ExtraDamage * NewTotalDamage) / TotalDamage;
				BaseDamage = NewTotalDamage - ExtraDamage;

				BroadcastRemoveBuffEvent(Yard.Context, TargetUnit.UnitId, ShieldBuff.BuffId, ERemoveBuffReason::Shield, false);

				TargetUnit.Buffs.RemoveAt(ShieldBuffIdx);
			}
		}

		SumOfAll = BaseDamage + ExtraDamage + ShieldDamage + ExtraShieldDamage;
		Q6JsonLog(Display, "sum of all damage", Q6KV("sum", SumOfAll),
			Q6KV("base damage", BaseDamage), Q6KV("extra damage", ExtraDamage),
			Q6KV("shield damage", ShieldDamage), Q6KV("extra shield damage", ExtraShieldDamage));

		int64 BloodSucking = Formula::CalcBloodSucking(Yard.SourceUnit, SumOfAll);
		if (BloodSucking > 0)
		{
			EffectEvent->CreateHealEventPerUnit(InCMS, Yard.SourceUnit, BloodSucking, EHealthChangeReason::Sucking);
			Q6JsonLog(Display, "blood sucking", Q6KV("value", BloodSucking));
		}

		int64 TargetUnitRemainHP = TargetUnit.Health;
		int32 GotOverKillPoint = Formula::CalcOverKill(Yard.InOutState, InCMS, Yard.SourceUnit, TargetUnitRemainHP, BaseDamage + ExtraDamage,
			Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.SkillId, Yard.ChordNote != EApplyTag::None, Yard.BornCategory);
		Yard.SourceUnit.OverKill += GotOverKillPoint;
		if (GotOverKillPoint > 0)
		{
			Q6JsonLog(Display, "get overkill", Q6KV("value", GotOverKillPoint));
		}
		EffectEvent->CreateDamageEventPerUnit(TargetUnit, BaseDamage, ExtraDamage, ShieldDamage, ExtraShieldDamage, bShieldWeakPoint, GotOverKillPoint, EHealthChangeReason::Damage, bNoDamage);

		if (Yard.InOutState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide
			&& TargetUnit.Faction == ECCFaction::Enemy && !bNoDamage)
		{
			// accumulate damage of enemy for the multi side battle rank score
			bool bGotOverKillPoint = GotOverKillPoint > 0;
			_AccumulateCombatMultiSideRankScore(Yard, Yard.InOutState, BaseDamage, ExtraDamage, false, bGotOverKillPoint);
		}

		int32 GotAttackUA = Formula::CalcAttackUA(Yard.InOutState, GetCMS(), Yard.SourceUnit, SkillSequence,
			Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.SkillId, Yard.ChordNote != EApplyTag::None);
		Q6JsonLog(Display, "add attack ua", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("ua", GotAttackUA));
		_SetNewUA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.UA + GotAttackUA, EPointChangeReason::Attack);

		int32 GotAttackSA = Formula::CalcAttackSA(Yard.InOutState, GetCMS(), Yard.SourceUnit, SkillSequence,
			Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.SkillId, Yard.ChordNote != EApplyTag::None);
		Q6JsonLog(Display, "add attack sa", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("ua", GotAttackSA));
		_SetNewSA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.SA + GotAttackSA, EPointChangeReason::Attack);

		if (Yard.SourceUnit.IsAlly() && TargetUnit.IsDead() && !Zombie)
		{
			int32 KillBonusUA = Formula::CalcKillTargetUABonus(InCMS, Yard.SourceUnit, EffectRow.Param1, SkillSequence,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewUA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.UA + KillBonusUA, EPointChangeReason::KillBonus);

			int32 KillBonusSA = Formula::CalcKillTargetSABonus(InCMS, Yard.SourceUnit, EffectRow.Param1, SkillSequence,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewSA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.SA + KillBonusSA, EPointChangeReason::KillBonus);
		}

		if (TargetUnit.IsAlly())
		{
			int32 BeatenUA = Formula::CalcBeatenUA(InCMS, TargetUnit, SumOfAll,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewUA(Yard.Context, TargetUnit, Yard.SkillType, TargetUnit.UA + BeatenUA, EPointChangeReason::Beaten);

			int32 BeatenSA = Formula::CalcBeatenSA(InCMS, TargetUnit, SumOfAll, TargetUnitRemainHP,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewSA(Yard.Context, TargetUnit, Yard.SkillType, TargetUnit.SA + BeatenSA, EPointChangeReason::Beaten);
		}

		if (Yard.InOutState.SkillProp[(int32)Yard.SkillDesc.SkillCategory].bUsableToDeadUnit)
		{
			_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::AtBeaten, Yard.SourceUnit.UnitId);
			if (TargetUnit.IsDead())
			{
				_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::PostDie, Yard.SourceUnit.UnitId);
			}
			continue;
		}

		bool bHasDoubleSkill = false;
		Yard.InOutState.UnitsState.PossibleAttackByFaction(Yard.SourceUnit.Faction, GetCMS(), &bHasDoubleSkill);

		bool bNormalCloserAtDoubleCondition = bHasDoubleSkill
			&& Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bHasNote
			&& Yard.SkillDesc.SkillNote == ESkillNote::Closer;

		if (!bNormalCloserAtDoubleCondition)
		{
			_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::AtBeaten, Yard.SourceUnit.UnitId);

			if (TargetUnit.IsDead())
			{
				_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::PostDie, Yard.SourceUnit.UnitId);
			}
		}
	}

	Yard.Context.OnEvent.Broadcast(EffectEvent);
}

static void _ApplyHealSkillEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	check(EffectRow.EffectCategory == EEffectCategory::Heal);

	UCCSkillEffectEvent* EffectEvent = NewObject<UCCSkillEffectEvent>();
	EffectEvent->SkillEffectType = EffectRow.Type;
	EffectEvent->SourceUnitId = Yard.SourceUnit.UnitId;

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (TargetUnit.IsDead())
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		const int32 Heal = Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);
		EffectEvent->CreateHealEventPerUnit(GetCMS(), TargetUnit, Heal, EHealthChangeReason::Heal);
	}

	Yard.Context.OnEvent.Broadcast(EffectEvent);
}

static void _ApplyAddUASkillEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	check(EffectRow.EffectCategory == EEffectCategory::AddUA);

	int32 OriginAddUA = Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		int32 CalculatedUA = Formula::CalcAddUA(GetCMS(), TargetUnit, OriginAddUA,
			Yard.InOutState.UnitsState.GetCountSkillsOnCurPhase(Yard.InOutState, Yard.SourceUnit.Faction, Yard.SkillDesc.SkillCategory),
			Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.BornCategory);
		const int32 OldUA = TargetUnit.UA;
		const int32 NewUA = FMath::Clamp(TargetUnit.UA + CalculatedUA, 0, (int32)TargetUnit.GetAttributeValue(EUnitAttribute::MaxUA));

		_SetNewUA(Yard.Context, TargetUnit, Yard.SkillType, NewUA, EPointChangeReason::SkillEffect);
	}
}

static void _ApplyAddSASkillEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	check(EffectRow.EffectCategory == EEffectCategory::AddSA);

	int32 OriginAddSA = Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		int32 CalculatedSA = Formula::CalcAddSA(GetCMS(), TargetUnit, OriginAddSA,
			Yard.InOutState.UnitsState.GetCountSkillsOnCurPhase(Yard.InOutState, Yard.SourceUnit.Faction, Yard.SkillDesc.SkillCategory),
			Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.BornCategory);
		const int32 OldSA = TargetUnit.SA;
		const int32 NewSA = FMath::Clamp(TargetUnit.SA + CalculatedSA, 0, (int32)TargetUnit.GetAttributeValue(EUnitAttribute::MaxSA));

		_SetNewSA(Yard.Context, TargetUnit, Yard.SkillType, NewSA, EPointChangeReason::SkillEffect);
	}
}

static void _ApplySetUltimateWaitTimeEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	if (Yard.BornCategory == ESkillCategory::RaidTurnBegin)
	{
		return;
	}

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		for (const FCCSkillState& S : TargetUnit.Skills)
		{
			if (Yard.InOutState.SkillProp[(int32)S.Category].bHasWaitTime == false)
			{
				continue;
			}

			if (S.Category != ESkillCategory::Ultimate)
			{
				continue;
			}

			int32 MaxWaitTime = S.WaitTime;
			if (S.UsingCount == 0)
			{
				int32 DummyCoolTime = 0;
				int32 DummyWaitTime = 0;
				int32 InitialWaitTime = 0;
				_GetSkillTime(S.SkillType, S.Level, DummyCoolTime, DummyWaitTime, InitialWaitTime);

				MaxWaitTime = InitialWaitTime;
			}

			int32 NewWaitDown = S.Waitdown - EffectRow.Param1;
			// NewWaitDown should be remained at least 1
			NewWaitDown = FMath::Clamp(NewWaitDown, 0, MaxWaitTime - 1);

			Q6JsonLog(Display, "set ultimate skill wait down.", Q6KV("unit type", TargetUnit.UnitType), Q6KV("skill type", S.SkillType),
				Q6KV("old wait down", S.Waitdown), Q6KV("new wait down", NewWaitDown));

			int32 TimeDiff = NewWaitDown - S.Waitdown;
			_SetSkillTime(Yard.Context, Yard.InOutState, TargetUnit, S.SkillId, S.Cooldown, NewWaitDown, ESetSkillTimeType::ChargeDown, TimeDiff);
			break; // set first ultimate skill.
		}
	}
}

static void _ApplySetTurnBeginCoolTimeEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	if (Yard.BornCategory == ESkillCategory::RaidTurnBegin)
	{
		return;
	}

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		for (const FCCSkillState& S : TargetUnit.Skills)
		{
			if (S.Category != ESkillCategory::TurnBegin)
			{
				continue;
			}

			if (!S.IsInCooldown())
			{
				continue;
			}

			if (S.SkillId == Yard.SkillId)
			{
				continue;
			}

			Q6JsonLog(Display, "set turnbegin skill cool down.", Q6KV("unit type", TargetUnit.UnitType), Q6KV("skill type", S.SkillType),
				Q6KV("old cool down", S.Cooldown), Q6KV("new cool down", S.Cooldown + EffectRow.Param1));
			_SetSkillTime(Yard.Context, Yard.InOutState, TargetUnit, S.SkillId, S.Cooldown + EffectRow.Param1, S.Waitdown, ESetSkillTimeType::Cooldown, EffectRow.Param1);
		}
	}
}

static void _ApplySetCooldownEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	if (Yard.BornCategory == ESkillCategory::RaidTurnBegin)
	{
		return;
	}

	check(EffectRow.EffectCategory == EEffectCategory::CoolTime);
	check(EffectRow.Target == ETargetType::Self);

	FCCSkillState* SkillState = Yard.SourceUnit.GetSkillState(Yard.SkillId);
	_SetSkillTime(Yard.Context, Yard.InOutState, Yard.SourceUnit, Yard.SkillId, SkillState->CoolTime, SkillState->Waitdown);
}

static void _ApplyBuffEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	check(EffectRow.EffectCategory == EEffectCategory::Buff);

	const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(EffectRow.Param1));

	bool VersaSkill = IsVersaSkill(Yard.Context, Yard.InOutState, Yard.SourceUnit.Faction, Yard.SkillType);
	bool VersaBuff = IsVersaBuff(Yard.Context, Yard.InOutState, Yard.SourceUnit.Faction, BuffRow.Type);

	ESkillCategory BornCategory = Yard.BornCategory;
	if (VersaSkill || VersaBuff)
	{
		BornCategory = ESkillCategory::Versa;
	}

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		_CreateBuff(Yard.Context, Yard.InOutState, Yard.SourceUnit.UnitId, TargetUnitId, BuffRow.Type, BuffRow.Duration, BuffRow.HitCount,
			Yard.SkillLevel, Yard.InOutState.TurnState.TurnCount, false, BornCategory, Yard.SkillId);
	}
}

static void _ApplySkillDMGperEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds, bool IsHPDMG, bool bCritical)
{
	check(EffectRow.EffectCategory == EEffectCategory::SkillDMGper
		|| EffectRow.EffectCategory == EEffectCategory::HPDMGper);
	bool bNoDamage = Yard.InOutState.GetGameFlag(EGameFlags::NoDamage);

	UCCSkillEffectEvent* EffectEvent = NewObject<UCCSkillEffectEvent>();
	EffectEvent->SkillEffectType = EffectRow.Type;
	EffectEvent->SourceUnitId = Yard.SourceUnit.UnitId;

	int32 SkillSequence = Yard.InOutState.UnitsState.GetCountSkillsOnCurPhase(Yard.InOutState, Yard.SourceUnit.Faction, Yard.SkillDesc.SkillCategory);
	int32 OriginSkillDMGPer = (int32)Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);
	OriginSkillDMGPer = Formula::CalcAttackDamage(Yard.InOutState, GetCMS(), Yard.SourceUnit,
		Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.SkillId, OriginSkillDMGPer, Yard.ChordNote != EApplyTag::None);
	Q6JsonLog(Display, "add attack damage", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("damage", OriginSkillDMGPer));

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (TargetUnit.IsDead()
			&& Yard.InOutState.SkillProp[(int32)Yard.SkillDesc.SkillCategory].bUsableToDeadUnit == false)
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		bool Zombie = TargetUnit.IsDead();

		bool bDodge = false;
		if (TargetUnit.GetCrowdControlState(GetCMS(), ECrowdControl::Dodged) > 0)
		{
			if (Yard.SourceUnit.GetCrowdControlState(GetCMS(), ECrowdControl::IgnoreDodged) > 0
				|| Yard.SourceUnit.GetCrowdControlState(GetCMS(), ECrowdControl::IgnoreInvincible) > 0)
			{
				bDodge = false;
				Q6JsonLog(Display, "ignore dodge", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("target unit", TargetUnit.UnitType));
			}
			else
			{
				bDodge = true;
				Q6JsonLog(Display, "dodge damage", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("target unit", TargetUnit.UnitType));
			}
		}

		bool bInvincible = false;
		if (TargetUnit.GetCrowdControlState(GetCMS(), ECrowdControl::Invincible) > 0)
		{
			if (Yard.SourceUnit.GetCrowdControlState(GetCMS(), ECrowdControl::IgnoreInvincible) > 0)
			{
				bInvincible = false;
				Q6JsonLog(Display, "ignore invincible", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("target unit", TargetUnit.UnitType));
			}
			else
			{
				bInvincible = true;
				Q6JsonLog(Display, "invincible damage", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("target unit", TargetUnit.UnitType));
			}
		}

		int64 TargetUnitRemainHP = TargetUnit.Health;
		int32 GotOverKillPoint = 0;

		int64 SumOfAll = 0;
		int64 BaseDamage = 0;
		int64 ExtraDamage = 0;
		int64 ShieldDamage = 0;
		int64 ExtraShieldDamage = 0;
		bool bShieldWeakPoint = false;
		bool bCCDefence = false;

		if (bDodge || bInvincible)
		{
			bCCDefence = true;
		}

		if (Yard.SkillDesc.SkillCategory == ESkillCategory::Ultimate)
		{
			BaseDamage = Formula::CalcUltimateDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer, SkillSequence,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], IsHPDMG, Yard.InOutState.CombatSeed.SagaType);
			Q6JsonLog(Display, "ultimate damage", Q6KV("value", BaseDamage));
		}
		else
		{
			BaseDamage = Formula::CalcNormalDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer, SkillSequence,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], IsHPDMG, Yard.InOutState.CombatSeed.SagaType);
			Q6JsonLog(Display, "normal damage", Q6KV("value", BaseDamage));
		}

		if (bCritical)
		{
			BaseDamage = Formula::CalcCriDamage(GetCMS(), Yard.SourceUnit, BaseDamage,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.BornCategory);
			Q6JsonLog(Display, "cri damage", Q6KV("value", BaseDamage));
		}

		int32 ExtraDMGper = Yard.SourceUnit.GetExtraDMGper(Yard.Context, Yard.InOutState, GetCMS(), TargetUnit, Yard.SkillLevel, Yard.BornCategory);
		if (ExtraDMGper > 0)
		{
			Q6JsonLog(Display, "ExtraDMGper", Q6KV("value", ExtraDMGper));

			if (Yard.SkillDesc.SkillCategory == ESkillCategory::Ultimate)
			{
				ExtraDamage = Formula::CalcExtraUltimateDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer,
					Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], ExtraDMGper, IsHPDMG);
				Q6JsonLog(Display, "ultimate extra damage", Q6KV("value", ExtraDamage));
			}
			else
			{
				ExtraDamage = Formula::CalcExtraNormalDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer,
					Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], ExtraDMGper, IsHPDMG);
				Q6JsonLog(Display, "normal extra damage", Q6KV("value", ExtraDamage));
			}
		}

		int32 ShieldBuffIdx = -1;
		int32 AddShieldDMGper = 0;
		for (int i = 0; i < TargetUnit.Buffs.Num(); ++i)
		{
			FCCBuffState& Itor = TargetUnit.Buffs[i];

			for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(Itor, ECrowdControl::Shield))
			{
				ShieldBuffIdx = i;
				AddShieldDMGper = Formula::GetShieldDMGper(GetCMS(), Effect->Param3,
					Yard.SkillDesc.SkillCategory, Yard.SkillDesc.SkillNote, Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
				Q6JsonLog(Display, "shield AddShieldDMGper", Q6KV("value", AddShieldDMGper));
				break;
			}
		}
		bShieldWeakPoint = AddShieldDMGper > CombatCubeConst::Q6_DEFAULT_ADDSHIELDDMGPER;

		if (TargetUnit.Buffs.IsValidIndex(ShieldBuffIdx))
		{
			FCCBuffState& ShieldBuff = TargetUnit.Buffs[ShieldBuffIdx];

			if (Yard.SkillDesc.SkillCategory == ESkillCategory::Ultimate)
			{
				ShieldDamage = Formula::CalcShieldUltimateDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer, SkillSequence,
					Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], AddShieldDMGper, IsHPDMG);
				Q6JsonLog(Display, "ultimate shield damage", Q6KV("value", ShieldDamage));
			}
			else
			{
				ShieldDamage = Formula::CalcShieldNormalDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer, SkillSequence,
					Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], AddShieldDMGper, IsHPDMG);
				Q6JsonLog(Display, "normal shield damage", Q6KV("value", ShieldDamage));
			}

			if (bCritical)
			{
				ShieldDamage = Formula::CalcCriDamage(GetCMS(), Yard.SourceUnit, ShieldDamage,
					Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.BornCategory);
				Q6JsonLog(Display, "cri shield damage", Q6KV("value", ShieldDamage));
			}

			if (ExtraDMGper > 0)
			{
				if (Yard.SkillDesc.SkillCategory == ESkillCategory::Ultimate)
				{
					ExtraShieldDamage = Formula::CalcExtraShieldUltimateDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer, AddShieldDMGper, ExtraDMGper, IsHPDMG);
					Q6JsonLog(Display, "ultimate extra shield damage", Q6KV("value", ExtraShieldDamage));
				}
				else
				{
					ExtraShieldDamage = Formula::CalcExtraShieldNormalDamage(GetCMS(), Yard.SourceUnit, TargetUnit, OriginSkillDMGPer, AddShieldDMGper, ExtraDMGper, IsHPDMG);
					Q6JsonLog(Display, "normal extra shield damage", Q6KV("value", ExtraShieldDamage));
				}
			}

			if (!bCCDefence)
			{
				int64 TotalDamage = BaseDamage + ExtraDamage;
				int64 TotalShieldDamage = ShieldDamage + ExtraShieldDamage;
				int64 Shield = ShieldBuff.Shield;
				if (ShieldBuff.Shield - TotalShieldDamage > 0)
				{
					ShieldBuff.Shield = Shield - TotalShieldDamage;
					BaseDamage = 0;
					ExtraDamage = 0;
				}
				else
				{
					ExtraShieldDamage = (ExtraShieldDamage * Shield) / TotalShieldDamage;
					ShieldDamage = Shield - ExtraShieldDamage;

					int64 NewTotalDamage = FMath::Max(0LL, TotalDamage - Shield);
					ExtraDamage = (ExtraDamage * NewTotalDamage) / TotalDamage;
					BaseDamage = NewTotalDamage - ExtraDamage;

					BroadcastRemoveBuffEvent(Yard.Context, TargetUnit.UnitId, ShieldBuff.BuffId, ERemoveBuffReason::Shield, false);

					TargetUnit.Buffs.RemoveAt(ShieldBuffIdx);
				}
			}
		}

		SumOfAll = BaseDamage + ExtraDamage + ShieldDamage + ExtraShieldDamage;
		Q6JsonLog(Display, "sum of all damage", Q6KV("sum", SumOfAll),
			Q6KV("base damage", BaseDamage), Q6KV("extra damage", ExtraDamage),
			Q6KV("shield damage", ShieldDamage), Q6KV("extra shield damage", ExtraShieldDamage));

		if (!bCCDefence)
		{
			int64 BloodSucking = Formula::CalcBloodSucking(Yard.SourceUnit, SumOfAll);
			if (BloodSucking > 0)
			{
				EffectEvent->CreateHealEventPerUnit(GetCMS(), Yard.SourceUnit, BloodSucking, EHealthChangeReason::Sucking);
				Q6JsonLog(Display, "blood sucking", Q6KV("value", BloodSucking));
			}

			GotOverKillPoint = Formula::CalcOverKill(Yard.InOutState, GetCMS(), Yard.SourceUnit, TargetUnitRemainHP, BaseDamage + ExtraDamage,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.SkillId, Yard.ChordNote != EApplyTag::None, Yard.BornCategory);
			Yard.SourceUnit.OverKill += GotOverKillPoint;
			if (GotOverKillPoint > 0)
			{
				Q6JsonLog(Display, "get overkill", Q6KV("value", GotOverKillPoint));
			}
		}

		if (Yard.InOutState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide
			&& TargetUnit.Faction == ECCFaction::Enemy && !bNoDamage && !bCCDefence)
		{
			// accumulate damage of enemy for the multi side battle rank score
			bool bGotOverKillPoint = GotOverKillPoint > 0;
			_AccumulateCombatMultiSideRankScore(Yard, Yard.InOutState, BaseDamage, ExtraDamage, bCritical, bGotOverKillPoint);
		}

		int32 GotAttackUA = Formula::CalcAttackUA(Yard.InOutState, GetCMS(), Yard.SourceUnit, SkillSequence,
			Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.SkillId, Yard.ChordNote != EApplyTag::None);
		Q6JsonLog(Display, "add attack ua", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("ua", GotAttackUA));
		_SetNewUA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.UA + GotAttackUA, EPointChangeReason::Attack);

		int32 GotAttackSA = Formula::CalcAttackSA(Yard.InOutState, GetCMS(), Yard.SourceUnit, SkillSequence,
			Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], Yard.SkillId, Yard.ChordNote != EApplyTag::None);
		Q6JsonLog(Display, "add attack sa", Q6KV("source unit", Yard.SourceUnit.UnitType), Q6KV("ua", GotAttackSA));
		_SetNewSA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.SA + GotAttackSA, EPointChangeReason::Attack);

		bool bCriticalEffect = bCritical;
		if (bCCDefence)
		{
			bCriticalEffect = false;
		}
		EffectEvent->CreateDamageEventPerUnit(TargetUnit, BaseDamage, ExtraDamage, ShieldDamage, ExtraShieldDamage, bShieldWeakPoint,
			GotOverKillPoint, EHealthChangeReason::Damage, bNoDamage, bCriticalEffect, bCCDefence);

		if (Yard.SourceUnit.IsAlly() && TargetUnit.IsDead() && !Zombie)
		{
			int32 KillBonusUA = Formula::CalcKillTargetUABonus(GetCMS(), Yard.SourceUnit, EffectRow.Param1, SkillSequence,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewUA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.UA + KillBonusUA, EPointChangeReason::KillBonus);

			int32 KillBonusSA = Formula::CalcKillTargetSABonus(GetCMS(), Yard.SourceUnit, EffectRow.Param1, SkillSequence,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewSA(Yard.Context, Yard.SourceUnit, Yard.SkillType, Yard.SourceUnit.SA + KillBonusSA, EPointChangeReason::KillBonus);
		}

		if (TargetUnit.IsAlly())
		{
			int32 BeatenUA = Formula::CalcBeatenUA(GetCMS(), TargetUnit, SumOfAll,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewUA(Yard.Context, TargetUnit, Yard.SkillType, TargetUnit.UA + BeatenUA, EPointChangeReason::Beaten);

			int32 BeatenSA = Formula::CalcBeatenSA(GetCMS(), TargetUnit, SumOfAll, TargetUnitRemainHP,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
			_SetNewSA(Yard.Context, TargetUnit, Yard.SkillType, TargetUnit.SA + BeatenSA, EPointChangeReason::Beaten);
		}

		if (Yard.InOutState.SkillProp[(int32)Yard.SkillDesc.SkillCategory].bUsableToDeadUnit)
		{
			_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::AtBeaten, Yard.SourceUnit.UnitId);
			if (TargetUnit.IsDead())
			{
				_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::PostDie, Yard.SourceUnit.UnitId);
			}
			continue;
		}

		bool bHasDoubleSkill = false;
		Yard.InOutState.UnitsState.PossibleAttackByFaction(Yard.SourceUnit.Faction, GetCMS(), &bHasDoubleSkill);

		bool bNormalCloserAtDoubleCondition = bHasDoubleSkill
			&& Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bHasNote
			&& Yard.SkillDesc.SkillNote == ESkillNote::Closer;

		if (!bNormalCloserAtDoubleCondition)
		{
			if (TargetUnit.IsDead())
			{
				_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::AtBeaten, Yard.SourceUnit.UnitId);
				_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::PostDie, Yard.SourceUnit.UnitId);
			}
			else
			{
				if (bCCDefence)
				{
					_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::AtDodge, Yard.SourceUnit.UnitId);
				}

				_ReadyMomentSkill(Yard.InOutState, TargetUnit, Yard.SkillDesc.SkillCategory, EMoment::AtBeaten, Yard.SourceUnit.UnitId);
			}
		}
	}

	Yard.Context.OnEvent.Broadcast(EffectEvent);
}

static void _ApplySkillHEALperEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	check(EffectRow.EffectCategory == EEffectCategory::SkillHEALper);

	UCCSkillEffectEvent* EffectEvent = NewObject<UCCSkillEffectEvent>();
	EffectEvent->SkillEffectType = EffectRow.Type;
	EffectEvent->SourceUnitId = Yard.SourceUnit.UnitId;

	const int32 OriginHealPer = (int32)Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (TargetUnit.IsDead())
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		int64 Heal = 0;
		if (Yard.BornCategory == ESkillCategory::RaidTurnBegin
			|| Yard.BornCategory == ESkillCategory::RaidSupport)
		{
			const FCCRaidSkillState* RaidSkillState = GetRaidSkillState(Yard.BornCategory, Yard.SkillId, Yard.InOutState);
			Heal = Formula::CalcRaidSkillHeal(GetCMS(), RaidSkillState->Attributes, OriginHealPer,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
		}
		else
		{
			Heal = Formula::CalcSkillHeal(GetCMS(), Yard.SourceUnit, OriginHealPer,
				Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction]);
		}

		Q6JsonLog(Display, "skill heal", Q6KV("value", Heal));

		EffectEvent->CreateHealEventPerUnit(GetCMS(), TargetUnit, Heal, EHealthChangeReason::Heal);
	}

	Yard.Context.OnEvent.Broadcast(EffectEvent);
}

static void _ApplyAddOverKillPointEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (TargetUnit.IsDead())
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		const int64 AddPoint = Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);
		int32 CalcPoint = Formula::CalcOverKillNoDamage(GetCMS(), TargetUnit, AddPoint, Yard.BornCategory);
		if (!TargetUnit.CanGetOverkill())
		{
			CalcPoint = 0;
		}

		Q6JsonLog(Display, "AddOverKillPoint", Q6KV("effect value", AddPoint), Q6KV("calc value", CalcPoint));

		if (Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bChangeOverKillPoint
			&& TargetUnitId == Yard.SourceUnit.UnitId)
		{
			TargetUnit.OverKill += CalcPoint;
		}
		else
		{
			_SetNewOverKill(Yard.Context, TargetUnit, CalcPoint, Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], EPointChangeReason::SkillEffect);
		}
	}
}

static void _ApplyRemoveLastBuff(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	const UCMS* CMS = GetCMS();

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		if (TargetUnit.Buffs.Num() <= 0)
		{
			BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::NoBuff, EApplyTag::None);
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		int32 LastIdx = TargetUnit.Buffs.Num() - 1;
		const FCCBuffState& Buff = TargetUnit.Buffs[LastIdx];
		bool Versa = IsVersaBuff(Yard.Context, Yard.InOutState, TargetUnit.Faction, Buff.BuffType);

		const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Buff.BuffType));
		if (CMSBuffRow.Lock)
		{
			BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::Locked, EApplyTag::None);
			continue;
		}

		BroadcastRemoveBuffEvent(Yard.Context, TargetUnit.UnitId, Buff.BuffId, ERemoveBuffReason::RemoveSkill, Versa);

		TargetUnit.Buffs.RemoveAt(LastIdx);

		const TArray<TPair<int64, int64>>& UpdatedUnitAttributes = TargetUnit.UnitAttributes->UpdateUnitAttributes(Yard.Context, TargetUnit);

		for (const TPair<int64, int64>& UpdatedUnitAttribute : UpdatedUnitAttributes)
		{
			UCCUpdateAttributesEvent* UpdateAttributeEvent = NewObject<UCCUpdateAttributesEvent>();
			UpdateAttributeEvent->UnitAttributeType = CMS->GetUnitAttributeType(EUnitAttribute(UpdatedUnitAttribute.Key));
			UpdateAttributeEvent->UnitId = TargetUnitId;
			UpdateAttributeEvent->AddedValue = UpdatedUnitAttribute.Value;
			Yard.Context.OnEvent.Broadcast(UpdateAttributeEvent);
		}
	}
}

static void _ApplyRemoveLastBuffByCategory(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds, EBuffCategory InCategory)
{
	const UCMS* CMS = GetCMS();

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		bool bHasSuchBuff = false;
		for (int i = TargetUnit.Buffs.Num() - 1; i >= 0; --i)
		{
			FCCBuffState& Buff = TargetUnit.Buffs[i];
			const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Buff.BuffType));
			if (CMSBuffRow.BuffCategory != InCategory)
			{
				continue;
			}

			bHasSuchBuff = true;
			bool Versa = IsVersaBuff(Yard.Context, Yard.InOutState, TargetUnit.Faction, Buff.BuffType);

			if (CMSBuffRow.Lock)
			{
				BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::Locked, EApplyTag::None);
				continue;
			}

			BroadcastRemoveBuffEvent(Yard.Context, TargetUnit.UnitId, Buff.BuffId, ERemoveBuffReason::RemoveSkill, Versa);

			TargetUnit.Buffs.RemoveAt(i);

			const TArray<TPair<int64, int64>>& UpdatedUnitAttributes = TargetUnit.UnitAttributes->UpdateUnitAttributes(Yard.Context, TargetUnit);

			for (const TPair<int64, int64>& UpdatedUnitAttribute : UpdatedUnitAttributes)
			{
				UCCUpdateAttributesEvent* UpdateAttributeEvent = NewObject<UCCUpdateAttributesEvent>();
				UpdateAttributeEvent->UnitAttributeType = CMS->GetUnitAttributeType(EUnitAttribute(UpdatedUnitAttribute.Key));
				UpdateAttributeEvent->UnitId = TargetUnitId;
				UpdateAttributeEvent->AddedValue = UpdatedUnitAttribute.Value;
				Yard.Context.OnEvent.Broadcast(UpdateAttributeEvent);
			}

			break;
		}

		if (!bHasSuchBuff)
		{
			BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::NoBuff, EApplyTag::None);
		}
	}
}

static void _ApplyRemoveAllBuffs(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	const UCMS* CMS = GetCMS();

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		if (TargetUnit.Buffs.Num() <= 0)
		{
			BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::NoBuff, EApplyTag::None);
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		for (int i = TargetUnit.Buffs.Num() - 1; i >= 0; --i)
		{
			FCCBuffState& Buff = TargetUnit.Buffs[i];
			bool Versa = IsVersaBuff(Yard.Context, Yard.InOutState, TargetUnit.Faction, Buff.BuffType);

			const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Buff.BuffType));
			if (CMSBuffRow.Lock)
			{
				BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::Locked, EApplyTag::None);
				continue;
			}

			BroadcastRemoveBuffEvent(Yard.Context, TargetUnit.UnitId, Buff.BuffId, ERemoveBuffReason::RemoveSkill, Versa);

			TargetUnit.Buffs.RemoveAt(i);

			const TArray<TPair<int64, int64>>& UpdatedUnitAttributes = TargetUnit.UnitAttributes->UpdateUnitAttributes(Yard.Context, TargetUnit);

			for (const TPair<int64, int64>& UpdatedUnitAttribute : UpdatedUnitAttributes)
			{
				UCCUpdateAttributesEvent* UpdateAttributeEvent = NewObject<UCCUpdateAttributesEvent>();
				UpdateAttributeEvent->UnitAttributeType = CMS->GetUnitAttributeType(EUnitAttribute(UpdatedUnitAttribute.Key));
				UpdateAttributeEvent->UnitId = TargetUnitId;
				UpdateAttributeEvent->AddedValue = UpdatedUnitAttribute.Value;
				Yard.Context.OnEvent.Broadcast(UpdateAttributeEvent);
			}
		}
	}
}

static void _ApplyRemoveAllBuffByApplyTag(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	const UCMS* CMS = GetCMS();
	const FCMSApplyTagRow& TagRow = CMS->GetApplyTagRowOrDummy(FApplyTagType(EffectRow.Param1));

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		bool bHasSuchBuff = false;
		for (int i = TargetUnit.Buffs.Num() - 1; i >= 0; --i)
		{
			FCCBuffState& Buff = TargetUnit.Buffs[i];
			const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Buff.BuffType));
			const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMSBuffRow.GetBuffEffect();

			if (CMSBuffRow.ApplyTag == TagRow.ApplyTag)
			{
				goto REMOVE_BUFF_BY_TAG;
			}

			for (const FCMSBuffEffectRow* E : BuffEffectRows)
			{
				if (E->BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
				{
					const FCMSCrowdControlRow& Row = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(E->Param1));
					if (Row.ApplyTag == TagRow.ApplyTag)
					{
						goto REMOVE_BUFF_BY_TAG;
					}
				}
				else if (E->BuffEffectCategory == EBuffEffectCategory::ModifyUnitAttribute)
				{
					const FCMSUnitAttributeRow& Row = CMS->GetUnitAttributeRowOrDummy(FUnitAttributeType(E->Param1));
					if (E->Param2 > 0)
					{
						if (Row.PositiveApplyTag == TagRow.ApplyTag)
						{
							goto REMOVE_BUFF_BY_TAG;
						}
					}
					else if (E->Param2 < 0)
					{
						if (Row.NegativeApplyTag == TagRow.ApplyTag)
						{
							goto REMOVE_BUFF_BY_TAG;
						}
					}
				}
			}

			continue;

REMOVE_BUFF_BY_TAG:
			bHasSuchBuff = true;
			bool Versa = IsVersaBuff(Yard.Context, Yard.InOutState, TargetUnit.Faction, Buff.BuffType);

			if (CMSBuffRow.Lock)
			{
				BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::Locked, TagRow.ApplyTag);
				continue;
			}

			BroadcastRemoveBuffEvent(Yard.Context, TargetUnit.UnitId, Buff.BuffId, ERemoveBuffReason::RemoveSkill, Versa);

			TargetUnit.Buffs.RemoveAt(i);

			const TArray<TPair<int64, int64>>& UpdatedUnitAttributes = TargetUnit.UnitAttributes->UpdateUnitAttributes(Yard.Context, TargetUnit);

			for (const TPair<int64, int64>& UpdatedUnitAttribute : UpdatedUnitAttributes)
			{
				UCCUpdateAttributesEvent* UpdateAttributeEvent = NewObject<UCCUpdateAttributesEvent>();
				UpdateAttributeEvent->UnitAttributeType = CMS->GetUnitAttributeType(EUnitAttribute(UpdatedUnitAttribute.Key));
				UpdateAttributeEvent->UnitId = TargetUnitId;
				UpdateAttributeEvent->AddedValue = UpdatedUnitAttribute.Value;
				Yard.Context.OnEvent.Broadcast(UpdateAttributeEvent);
			}
		}

		if (!bHasSuchBuff)
		{
			BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::NoApplyTag, TagRow.ApplyTag);
		}
	}
}

static void _ApplyRemoveVersaBuff(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds, bool AllTarget)
{
	const UCMS* CMS = GetCMS();

	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);

		bool bHasSuchBuff = false;
		for (int i = TargetUnit.Buffs.Num() - 1; i >= 0; --i)
		{
			FCCBuffState& Buff = TargetUnit.Buffs[i];
			if (HasCrowdControlState(Buff, ECrowdControl::Versa) == 0)
			{
				continue;
			}

			bHasSuchBuff = true;

			const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Buff.BuffType));
			if (CMSBuffRow.Lock)
			{
				BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::Locked, EApplyTag::None);
				continue;
			}

			BroadcastRemoveBuffEvent(Yard.Context, TargetUnit.UnitId, Buff.BuffId, ERemoveBuffReason::RemoveSkill, true);

			TargetUnit.Buffs.RemoveAt(i);
			TargetUnit.UnitAttributes->UpdateUnitAttributes(Yard.Context, TargetUnit);
			const TArray<TPair<int64, int64>>& UpdatedUnitAttributes = TargetUnit.UnitAttributes->UpdateUnitAttributes(Yard.Context, TargetUnit);

			for (const TPair<int64, int64>& UpdatedUnitAttribute : UpdatedUnitAttributes)
			{
				UCCUpdateAttributesEvent* UpdateAttributeEvent = NewObject<UCCUpdateAttributesEvent>();
				UpdateAttributeEvent->UnitAttributeType = CMS->GetUnitAttributeType(EUnitAttribute(UpdatedUnitAttribute.Key));
				UpdateAttributeEvent->UnitId = TargetUnitId;
				UpdateAttributeEvent->AddedValue = UpdatedUnitAttribute.Value;
				Yard.Context.OnEvent.Broadcast(UpdateAttributeEvent);
			}

			if (!AllTarget)
			{
				return;
			}
		}

		if (!bHasSuchBuff)
		{
			BroadcastRemoveBuffFailedEvent(Yard.Context, TargetUnit.UnitId, ERemoveBuffFailedReason::NoVersa, EApplyTag::None);
		}
	}
}

static void _ApplyRemoveBuff(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds)
{
	check(IsValidEBuffRemovalCategory(EffectRow.EffectSubCategory));

	switch (EBuffRemovalCategory(EffectRow.EffectSubCategory))
	{
	case EBuffRemovalCategory::RemoveLastBuff:
		_ApplyRemoveLastBuff(Yard, EffectRow, TargetUnitIds);
		break;
	case EBuffRemovalCategory::RemoveLastCategoryBuff:
		_ApplyRemoveLastBuffByCategory(Yard, EffectRow, TargetUnitIds, EBuffCategory::Buff);
		break;
	case EBuffRemovalCategory::RemoveLastCategoryDebuff:
		_ApplyRemoveLastBuffByCategory(Yard, EffectRow, TargetUnitIds, EBuffCategory::Debuff);
		break;
	case EBuffRemovalCategory::RemoveAllBuffs:
		_ApplyRemoveAllBuffs(Yard, EffectRow, TargetUnitIds);
		break;
	case EBuffRemovalCategory::RemoveBuffApplyTag:
		_ApplyRemoveAllBuffByApplyTag(Yard, EffectRow, TargetUnitIds);
		break;
	case EBuffRemovalCategory::RemoveBuffVersaSingle:
		_ApplyRemoveVersaBuff(Yard, EffectRow, TargetUnitIds, false);
		break;
	case EBuffRemovalCategory::RemoveBuffVersaAll:
		_ApplyRemoveVersaBuff(Yard, EffectRow, TargetUnitIds, true);
		break;
	default:
		ensureMsgf(0, TEXT("Unhandled buff removal type: %d"), (int32)EffectRow.EffectSubCategory);
		break;
	}
}

static void _ApplySummonEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow)
{
	const FCMSUnitRow& SummonRow = GetCMS()->GetUnitRowOrDummy(FUnitType(EffectRow.Param1));
	if (SummonRow.IsInvalid())
	{
		Q6JsonLogObiwan(Error, "summon invalid unit", Q6KV("summon unit Type", SummonRow.CmsType()));
		return;
	}

	if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, Yard.SourceUnit, Yard.SkillLevel, Yard.BornCategory))
	{
		Q6JsonLogObiwan(Display, "failed summon skill applytag", Q6KV("summon unit Type", SummonRow.CmsType()));
		return;
	}

	TArray<int32> EmptySlots = Yard.InOutState.UnitsState.GetEmptySlots(Yard.SourceUnit.Faction);
	if (!EmptySlots.Num())
	{
		Q6JsonLogObiwan(Display, "failed finding empty slot for summon", Q6KV("summon unit Type", SummonRow.CmsType()));
		return;
	}

	int32 SpawnSlot = EmptySlots[0];
	if (EffectRow.EffectSubCategory != 0)
	{
		if (EmptySlots.Find(EffectRow.EffectSubCategory) != INDEX_NONE)
		{
			SpawnSlot = EffectRow.EffectSubCategory;
		}
		else
		{
			Q6JsonLogObiwan(Display, "failed finding slot for summon",
				Q6KV("summon unit Type", SummonRow.CmsType()),
				Q6KV("slot", EffectRow.EffectSubCategory));
			return;
		}
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Yard.InOutState.CombatSeed.SagaType);
	const FCMSAdditionalPointRow* AdditionalPoint = GetCMS()->GetAdditionalPoint(SagaRow.Difficulty, SummonRow.AttributeCategory);
	if (!AdditionalPoint)
	{
		Q6JsonLogObiwan(Display, "failed finding additional point", Q6KV("summon unit Type", SummonRow.CmsType()));
		return;
	}

	const FCCUnitState& CrossFiredUnit = _FindCrossFireUnit(Yard.InOutState, Yard.SourceUnit.Faction, SpawnSlot);

	FCCCombatSeedUnit SummonSeedUnit;
	SummonSeedUnit.UnitType = FUnitType(SummonRow.Type);
	SummonSeedUnit.Faction = Yard.SourceUnit.Faction;
	SummonSeedUnit.Category = SummonRow.AttributeCategory;
	SummonSeedUnit.Level = Yard.SourceUnit.Level;
	SummonSeedUnit.Grade = AdditionalPoint->Grade;
	SummonSeedUnit.UltimateSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	SummonSeedUnit.SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	SummonSeedUnit.TurnSkillLevels.Init(CombatCubeConst::Q6_MIN_SKILL_LEVEL, CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
	SummonSeedUnit.CombatMultiSide = Yard.SourceUnit.CombatMultiSide;

	FCCSpawnUnitParam SpawnUnit;
	UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(SummonSeedUnit, &SpawnUnit, ESpawnReason::Summon, SpawnSlot, 0, 1000, 0);

	_SpawnUnit(Yard.Context, Yard.InOutState, SpawnUnit, CrossFiredUnit.UnitId, Yard.SourceUnit.UnitId);
}

static void _ApplyRebirthEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow)
{
	if (!Yard.SourceUnit.IsDead())
	{
		Q6JsonLogObiwan(Display, "failed rebirth alive unit", Q6KV("unit Type", Yard.SourceUnit.UnitType));
		return;
	}

	if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, Yard.SourceUnit, Yard.SkillLevel, Yard.BornCategory))
	{
		Q6JsonLogObiwan(Display, "failed rebirth skill applytag", Q6KV("unit Type", Yard.SourceUnit.UnitType));
		return;
	}

	TArray<int32> EmptySlots = Yard.InOutState.UnitsState.GetEmptySlots(Yard.SourceUnit.Faction);
	if (EmptySlots.Find(Yard.SourceUnit.Slot) == INDEX_NONE)
	{
		Q6JsonLogObiwan(Display, "failed finding empty slot for rebirth.", Q6KV("rebirth unit Type", Yard.SourceUnit.UnitType));
		return;
	}

	FCCCombatSeedUnit SummonSeedUnit;
	SummonSeedUnit.UnitType = Yard.SourceUnit.UnitType;
	SummonSeedUnit.Faction = Yard.SourceUnit.Faction;
	SummonSeedUnit.Category = Yard.SourceUnit.Category;
	SummonSeedUnit.Level = Yard.SourceUnit.Level;
	SummonSeedUnit.Grade = Yard.SourceUnit.Grade;
	SummonSeedUnit.Sculpture = Yard.SourceUnit.Sculpture;
	SummonSeedUnit.Relic = Yard.SourceUnit.Relic;
	SummonSeedUnit.CombatMultiSide = Yard.SourceUnit.CombatMultiSide;

	SummonSeedUnit.UltimateSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	for (const FCCSkillState* S : Yard.SourceUnit.GetSkillStates(ESkillCategory::Ultimate))
	{
		SummonSeedUnit.UltimateSkillLevel = S->Level;
	}
	SummonSeedUnit.SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	for (const FCCSkillState& S : Yard.SourceUnit.Skills)
	{
		if (S.Category != ESkillCategory::Support)
		{
			continue;
		}
		SummonSeedUnit.SupportSkillLevel = S.Level;
	}
	for (const FCCSkillState* S : Yard.SourceUnit.GetSkillStates(ESkillCategory::TurnBegin))
	{
		SummonSeedUnit.TurnSkillLevels.Add(S->Level);
	}
	SummonSeedUnit.CharacterId = Yard.SourceUnit.CharacterId;

	const int64 HealthPermil = Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);

	FCCSpawnUnitParam SpawnUnit;
	UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(SummonSeedUnit, &SpawnUnit,
		ESpawnReason::Rebirth,
		Yard.SourceUnit.Slot,
		++Yard.SourceUnit.RebirthSkillCount,
		HealthPermil,
		Yard.SourceUnit.LiveTurnCount);

	_SpawnUnit(Yard.Context, Yard.InOutState, SpawnUnit, Yard.SourceUnit.UnitId, Yard.SourceUnit.UnitId);
}

static void _ApplyRebirthSummonEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow)
{
	const FCMSUnitRow& SummonRow = GetCMS()->GetUnitRowOrDummy(FUnitType(EffectRow.Param1));
	if (SummonRow.IsInvalid())
	{
		Q6JsonLogObiwan(Error, "rebirthsummon invalid unit", Q6KV("rebirthsummon unit Type", SummonRow.CmsType()));
		return;
	}

	if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, Yard.SourceUnit, Yard.SkillLevel, Yard.BornCategory))
	{
		Q6JsonLogObiwan(Display, "failed rebirthsummon skill applytag", Q6KV("rebirthsummon unit Type", SummonRow.CmsType()));
		return;
	}

	TArray<int32> EmptySlots = Yard.InOutState.UnitsState.GetEmptySlots(Yard.SourceUnit.Faction);
	if (!EmptySlots.Num())
	{
		Q6JsonLogObiwan(Display, "failed finding empty slot for rebirthsummon", Q6KV("rebirthsummon unit Type", SummonRow.CmsType()));
		return;
	}

	int32 SpawnSlot = EmptySlots[0];
	if (EffectRow.EffectSubCategory != 0)
	{
		if (EmptySlots.Find(EffectRow.EffectSubCategory) != INDEX_NONE)
		{
			SpawnSlot = EffectRow.EffectSubCategory;
		}
		else
		{
			Q6JsonLogObiwan(Display, "failed finding slot for rebirthsummon",
				Q6KV("rebirthsummon unit Type", SummonRow.CmsType()),
				Q6KV("slot", EffectRow.EffectSubCategory));
			return;
		}
	}
	else if (EmptySlots.Find(Yard.SourceUnit.Slot) != INDEX_NONE)
	{
		SpawnSlot = Yard.SourceUnit.Slot;
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Yard.InOutState.CombatSeed.SagaType);
	const FCMSAdditionalPointRow* AdditionalPoint = GetCMS()->GetAdditionalPoint(SagaRow.Difficulty, SummonRow.AttributeCategory);
	if (!AdditionalPoint)
	{
		Q6JsonLogObiwan(Display, "failed finding additional point", Q6KV("rebirthsummon unit Type", SummonRow.CmsType()));
		return;
	}

	const FCCUnitState& CrossFiredUnit = _FindCrossFireUnit(Yard.InOutState, Yard.SourceUnit.Faction, SpawnSlot);

	FCCCombatSeedUnit SummonSeedUnit;
	SummonSeedUnit.UnitType = FUnitType(SummonRow.Type);
	SummonSeedUnit.Faction = Yard.SourceUnit.Faction;
	SummonSeedUnit.Category = SummonRow.AttributeCategory;
	SummonSeedUnit.Level = Yard.SourceUnit.Level;
	SummonSeedUnit.Grade = AdditionalPoint->Grade;
	SummonSeedUnit.UltimateSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	SummonSeedUnit.SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
	SummonSeedUnit.TurnSkillLevels.Init(CombatCubeConst::Q6_MIN_SKILL_LEVEL, CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
	SummonSeedUnit.CombatMultiSide = Yard.SourceUnit.CombatMultiSide;

	FCCSpawnUnitParam SpawnUnit;
	UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(SummonSeedUnit, &SpawnUnit, ESpawnReason::RebirthSummon, SpawnSlot, 0, 1000, 0);

	_SpawnUnit(Yard.Context, Yard.InOutState, SpawnUnit, CrossFiredUnit.UnitId, Yard.SourceUnit.UnitId);
}

static void _ApplyPointVaryEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& ConsumeUnitIds, TArray<FCCUnitId>& OutDeadEventSentUnits)
{
	const UCMS* CMS = GetCMS();
	const FCMSPointVaryRow& Row = CMS->GetPointVaryRowOrDummy(FPointVaryType(EffectRow.EffectSubCategory));
	if (Row.IsInvalid())
	{
		ensure(0);
		return;
	}

	if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, Yard.SourceUnit, Yard.SkillLevel, Yard.BornCategory))
	{
		Q6JsonLogObiwan(Display, "failed pointvary skill applytag", Q6KV("unit Type", Yard.SourceUnit.UnitType));
		return;
	}

	UCCPointVaryUsedEvent* UsedEvent = NewObject<UCCPointVaryUsedEvent>();
	UsedEvent->ConsumeType = Row.ConsumeType;
	UsedEvent->ConvertType = Row.ConvertType;
	Yard.Context.OnEvent.Broadcast(UsedEvent);

	int64 ConsumeTotal = 0;
	for (const FCCUnitId& Id : ConsumeUnitIds)
	{
		FCCUnitState& Unit = Yard.InOutState.UnitsState.FindUnitState(Id);
		if (Unit.UnitId == CCUnitIdInvalid)
		{
			continue;
		}

		static_assert(EPointVaryConsumeTypeMax == 4, "need more consume type.");

		if (Row.ConsumeUnit == EPointVaryConsumeUnit::Permil)
		{
			switch (Row.ConsumeType)
			{
			case EPointVaryConsumeType::Health:
			{
				int64 ConsumeAmount = (Unit.GetAttributeValue(EUnitAttribute::MaxHealth) * Row.ConsumeAmount) / 1000;
				ConsumeTotal += ConsumeAmount;
				_SetHealth(Yard.Context, Yard.InOutState, Unit, Yard.SkillId, Unit.Health - ConsumeAmount, false, false, &OutDeadEventSentUnits);
				Q6JsonLogObiwan(Display, "pointvary consume health by permil", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
			break;
			case EPointVaryConsumeType::UA:
			{
				int32 ConsumeAmount = (Unit.UA * Row.ConsumeAmount) / 1000;
				ConsumeTotal += ConsumeAmount;
				_SetNewUA(Yard.Context, Unit, Yard.SkillType, Unit.UA - ConsumeAmount, EPointChangeReason::SkillEffect);
				Q6JsonLogObiwan(Display, "pointvary consume UA by permil", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
				break;
			case EPointVaryConsumeType::SA:
			{
				int32 ConsumeAmount = (Unit.SA * Row.ConsumeAmount) / 1000;
				ConsumeTotal += ConsumeAmount;
				_SetNewSA(Yard.Context, Unit, Yard.SkillType, Unit.SA - ConsumeAmount, EPointChangeReason::SkillEffect);
				Q6JsonLogObiwan(Display, "pointvary consume SA by permil", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
				break;
			case EPointVaryConsumeType::OverKillPoint:
			{
				int32 ConsumeAmount = (Unit.OverKill * Row.ConsumeAmount) / 1000;
				ConsumeTotal += ConsumeAmount;
				if (Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bChangeOverKillPoint
					&& Id == Yard.SourceUnit.UnitId)
				{
					Yard.SourceUnit.OverKill -= ConsumeAmount;
				}
				else
				{
					_SetNewOverKill(Yard.Context, Unit, -ConsumeAmount,
						CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT,
						EPointChangeReason::SkillEffect);
				}
				Q6JsonLogObiwan(Display, "pointvary consume overkill by permil", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
				break;

			default:
				ensureMsgf(0, TEXT("Unhandled pointvary consume type: %d"), (int32)Row.ConsumeType);
				break;
			}

		}
		else if (Row.ConsumeUnit == EPointVaryConsumeUnit::Integer)
		{
			switch (Row.ConsumeType)
			{
			case EPointVaryConsumeType::Health:
			{
				int64 ConsumeAmount = (Unit.Health >= Row.ConsumeAmount) ? Row.ConsumeAmount : Unit.Health;
				ConsumeTotal += ConsumeAmount;
				_SetHealth(Yard.Context, Yard.InOutState, Unit, Yard.SkillId, Unit.Health - ConsumeAmount, false, false, &OutDeadEventSentUnits);
				Q6JsonLogObiwan(Display, "pointvary consume health by integer", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
				break;
			case EPointVaryConsumeType::UA:
			{
				int32 ConsumeAmount = (Unit.UA >= Row.ConsumeAmount) ? Row.ConsumeAmount : Unit.UA;
				ConsumeTotal += ConsumeAmount;
				_SetNewUA(Yard.Context, Unit, Yard.SkillType, Unit.UA - ConsumeAmount, EPointChangeReason::SkillEffect);
				Q6JsonLogObiwan(Display, "pointvary consume UA by integer", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
				break;
			case EPointVaryConsumeType::SA:
			{
				int32 ConsumeAmount = (Unit.SA >= Row.ConsumeAmount) ? Row.ConsumeAmount : Unit.SA;
				ConsumeTotal += ConsumeAmount;
				_SetNewSA(Yard.Context, Unit, Yard.SkillType, Unit.SA - ConsumeAmount, EPointChangeReason::SkillEffect);
				Q6JsonLogObiwan(Display, "pointvary consume SA by integer", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
				break;
			case EPointVaryConsumeType::OverKillPoint:
			{
				int32 ConsumeAmount = (Unit.OverKill >= Row.ConsumeAmount) ? Row.ConsumeAmount : Unit.OverKill;
				ConsumeTotal += ConsumeAmount;
				if (Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bChangeOverKillPoint
					&& Id == Yard.SourceUnit.UnitId)
				{
					Yard.SourceUnit.OverKill -= ConsumeAmount;
				}
				else
				{
					_SetNewOverKill(Yard.Context, Unit, -ConsumeAmount,
						CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT, EPointChangeReason::SkillEffect);
				}
				Q6JsonLogObiwan(Display, "pointvary consume overkill by integer", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConsumeAmount));
			}
				break;

			default:
				ensureMsgf(0, TEXT("Unhandled pointvary consume type: %d"), (int32)Row.ConsumeType);
				break;
			}
		}
	}

	UCCPointVaryStateChangedEvent* StateChangedEvent = NewObject<UCCPointVaryStateChangedEvent>();
	Yard.Context.OnEvent.Broadcast(StateChangedEvent);

	const int64 InterpolatedParam = Formula::InterpolatedBySkillLevelOrTier(Yard.SkillLevel, EffectRow.Param1Min, EffectRow.Param1, Yard.BornCategory);
	int64 ConvertAmount = 0;
	if (Row.UseConsumeValue)
	{
		ConvertAmount = (ConsumeTotal * InterpolatedParam) / 1000;
	}
	else
	{
		ConvertAmount = InterpolatedParam;
	}

	const TArray<FCCUnitId> TargetUnitIds = _GetTargetUnits(Yard.Context, Yard.InOutState,
		Yard.SourceUnit.UnitId, Yard.SourceUnit.Faction, Row.ConvertTarget, CCUnitIdInvalid, CMS, Yard.BornCategory);

	for (const FCCUnitId& Id : TargetUnitIds)
	{
		FCCUnitState& Unit = Yard.InOutState.UnitsState.FindUnitState(Id);
		if (Unit.UnitId == CCUnitIdInvalid)
		{
			continue;
		}

		static_assert(EPointVaryConvertTypeMax == 16, "need more convert type.");

		switch (Row.ConvertType)
		{
		case EPointVaryConvertType::Health:
			_SetHealth(Yard.Context, Yard.InOutState, Unit, Yard.SkillId, Unit.Health + ConvertAmount, false, false, &OutDeadEventSentUnits);
			Q6JsonLogObiwan(Display, "pointvary convert to health.", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConvertAmount));
			break;
		case EPointVaryConvertType::UA:
			_SetNewUA(Yard.Context, Unit, Yard.SkillType, Unit.UA + ConvertAmount, EPointChangeReason::SkillEffect);
			Q6JsonLogObiwan(Display, "pointvary convert to UA.", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConvertAmount));
			break;
		case EPointVaryConvertType::SA:
			_SetNewSA(Yard.Context, Unit, Yard.SkillType, Unit.SA + ConvertAmount, EPointChangeReason::SkillEffect);
			Q6JsonLogObiwan(Display, "pointvary convert to SA.", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConvertAmount));
			break;
		case EPointVaryConvertType::OverKillPoint:
			if (Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bChangeOverKillPoint
				&& Id == Yard.SourceUnit.UnitId)
			{
				if (!Yard.SourceUnit.CanGetOverkill())
				{
					ConvertAmount = 0;
				}

				Yard.SourceUnit.OverKill += ConvertAmount;
			}
			else
			{
				if (!Unit.CanGetOverkill())
				{
					ConvertAmount = 0;
				}

				_SetNewOverKill(Yard.Context, Unit, ConvertAmount,
					CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT, EPointChangeReason::SkillEffect);
			}
			Q6JsonLogObiwan(Display, "pointvary convert to overkill.", Q6KV("unit Type", Unit.UnitType), Q6KV("amount", ConvertAmount));
			break;
		case EPointVaryConvertType::AtkVary:
		case EPointVaryConvertType::AtkVaryper:
		case EPointVaryConvertType::DefVary:
		case EPointVaryConvertType::DefVaryper:
		case EPointVaryConvertType::CriVaryper:
		case EPointVaryConvertType::CriDamVaryper:
		case EPointVaryConvertType::UltimateVary:
		case EPointVaryConvertType::UltimateVaryper:
		case EPointVaryConvertType::DamageVary:
		case EPointVaryConvertType::DamageVaryper:
		case EPointVaryConvertType::HealVary:
		case EPointVaryConvertType::HealVaryper:
			{
				Unit.UnitAttributes->SetPointVaryAttributeValue(Row.ConvertType, ConvertAmount);
				Q6JsonLogObiwan(Display, "pointvary convert to unitattribute.", Q6KV("unit Type", Unit.UnitType),
					Q6KV("attribute", (int32)Row.ConvertType), Q6KV("amount", ConvertAmount));

				Unit.UnitAttributes->UpdateUnitAttributes(Yard.Context, Unit);

				FUnitAttributeType UnitAttributeType = CMS->GetUnitAttributeType(Row.ConvertType);

				UCCUpdateAttributesEvent* UpdateEvent = NewObject<UCCUpdateAttributesEvent>();
				UpdateEvent->UnitAttributeType = UnitAttributeType;
				UpdateEvent->UnitId = Id;
				UpdateEvent->AddedValue = ConvertAmount;
				Yard.Context.OnEvent.Broadcast(UpdateEvent);
			}
			break;

		default:
			ensureMsgf(0, TEXT("Unhandled point vary convert type: %d"), (int32)Row.ConvertType);
			break;
		}
	}

	UCCPointVaryEndEvent* EndEvent = NewObject<UCCPointVaryEndEvent>();
	Yard.Context.OnEvent.Broadcast(EndEvent);
}

static void _ApplyImmediateKillEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds, TArray<FCCUnitId>& OutDeadEventSent)
{
	for (const FCCUnitId& TargetUnitId : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = Yard.InOutState.UnitsState.FindUnitState(TargetUnitId);
		if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
		{
			continue;
		}

		if (TargetUnit.IsDead())
		{
			continue;
		}

		if (!_ApplyTagSkillEffect(Yard.Context, Yard.InOutState, EffectRow, Yard.SourceUnit, TargetUnit, Yard.SkillLevel, Yard.BornCategory))
		{
			continue;
		}

		_SetHealth(Yard.Context, Yard.InOutState, TargetUnit, Yard.SkillId, 0, true, false, &OutDeadEventSent);
	}
}

static void _ApplySkillEffect(const CCSkillYard& Yard, const FCMSSkillEffectRow& EffectRow, const TArray<FCCUnitId>& TargetUnitIds, TArray<FCCUnitId>& OutDeadEventSentUnits, bool bCritical)
{
	ensure(Yard.BornCategory != ESkillCategory::Moment);

	switch (EffectRow.EffectCategory)
	{
	case EEffectCategory::Damage:
		_ApplyDamageSkillEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::Heal:
		_ApplyHealSkillEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::AddUA:
		_ApplyAddUASkillEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::AddSA:
		_ApplyAddSASkillEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::FirstWaitTime:
	case EEffectCategory::WaitTime:
		// do nothing.
		break;
	case EEffectCategory::AddUltimateWaitTime:
		_ApplySetUltimateWaitTimeEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::AddTurnBeginCoolTime:
		_ApplySetTurnBeginCoolTimeEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::CoolTime:
		_ApplySetCooldownEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::Buff:
		_ApplyBuffEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::SkillDMGper:
		_ApplySkillDMGperEffect(Yard, EffectRow, TargetUnitIds, false, bCritical);
		break;
	case EEffectCategory::HPDMGper:
		_ApplySkillDMGperEffect(Yard, EffectRow, TargetUnitIds, true, bCritical);
		break;
	case EEffectCategory::RemoveBuff:
		_ApplyRemoveBuff(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::SkillHEALper:
		_ApplySkillHEALperEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::AddOverKillPoint:
		_ApplyAddOverKillPointEffect(Yard, EffectRow, TargetUnitIds);
		break;
	case EEffectCategory::Summon:
		_ApplySummonEffect(Yard, EffectRow);
		break;
	case EEffectCategory::Rebirth:
		_ApplyRebirthEffect(Yard, EffectRow);
		break;
	case EEffectCategory::RebirthSummon:
		_ApplyRebirthSummonEffect(Yard, EffectRow);
		break;
	case EEffectCategory::PointVary:
		_ApplyPointVaryEffect(Yard, EffectRow, TargetUnitIds, OutDeadEventSentUnits);
		break;
	case EEffectCategory::ImmediateKill:
		_ApplyImmediateKillEffect(Yard, EffectRow, TargetUnitIds, OutDeadEventSentUnits);
		break;
	default:
		ensureMsgf(0, TEXT("Unhandled skill effect type: %d"), (int32)EffectRow.EffectCategory);
		break;
	}
}

static void _ApplySkillEffects(CCSkillYard Yard, TArray<FCCUnitId>& OutDeadEventSentUnits)
{
	if (Yard.InOutState.GetGameFlag(EGameFlags::Immune))
	{
		return;
	}

	TArray<const FCMSSkillEffectRow*> SkillEffects = Yard.SkillDesc.GetSkillEffect();
	SkillEffects.StableSort([](const FCMSSkillEffectRow& E1, const FCMSSkillEffectRow& E2)
	{
		if ((E1.EffectCategory == EEffectCategory::Rebirth || E2.EffectCategory == EEffectCategory::RebirthSummon)
			&& E2.EffectCategory == EEffectCategory::Summon)
		{
			return true;
		}

		return false;
	});

	// buff first for update unit attribute.
	for (const FCMSSkillEffectRow* EffectRow : SkillEffects)
	{
		if (EffectRow->EffectCategory != EEffectCategory::Buff)
		{
			continue;
		}

		TArray<FCCUnitId> TargetUnitIds;
		if (Yard.SkillDesc.Target == EffectRow->Target)
		{
			TargetUnitIds = Yard.TargetUnitIds;
		}
		else
		{
			TargetUnitIds = _GetTargetUnits(Yard.Context, Yard.InOutState, Yard.SourceUnit.UnitId, Yard.SourceUnit.Faction,
				EffectRow->Target, Yard.TargetUnitId, GetCMS(), Yard.SkillDesc.SkillCategory);
		}

		if (TargetUnitIds.Num() > 0)
		{
			_ApplySkillEffect(Yard, *EffectRow, TargetUnitIds, OutDeadEventSentUnits, false);
		}
		else
		{
			Q6JsonLogMild(Warning, "TargetUnitIds Num is Zero.", Q6KV("SkillType", Yard.SkillType), Q6KV("SkillEffectType", EffectRow->Type));
		}
	}

	bool bCritical = false;
	int32 OldOverKillPoint = Yard.SourceUnit.OverKill;
	if (Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bConsumeOverKillPoint)
	{
		if (Formula::CalcTotalCri(Yard.SourceUnit) >= (Yard.Context.MT19937->GenRandom(1000) + 1))
		{
			bCritical = true;
			Q6JsonLog(Display, "take cri", Q6KV("unit type", Yard.SourceUnit.UnitType), Q6KV("used overkill", OldOverKillPoint));
		}

		Yard.SourceUnit.OverKill = 0;
	}

	for (const FCMSSkillEffectRow* EffectRow : SkillEffects)
	{
		if (EffectRow->EffectCategory == EEffectCategory::Buff)
		{
			continue;
		}

		TArray<FCCUnitId> TargetUnitIds;
		if (Yard.SkillDesc.Target == EffectRow->Target)
		{
			TargetUnitIds = Yard.TargetUnitIds;
		}
		else
		{
			TargetUnitIds = _GetTargetUnits(Yard.Context, Yard.InOutState, Yard.SourceUnit.UnitId, Yard.SourceUnit.Faction,
				EffectRow->Target, Yard.TargetUnitId, GetCMS(), Yard.SkillDesc.SkillCategory);
		}

		if (TargetUnitIds.Num() <= 0)
		{
			if (EffectRow->EffectCategory == EEffectCategory::Rebirth
				|| EffectRow->EffectCategory == EEffectCategory::Summon
				|| EffectRow->EffectCategory == EEffectCategory::RebirthSummon)
			{
				TargetUnitIds.Add(Yard.SourceUnit.UnitId);
			}
		}

		if (TargetUnitIds.Num() > 0)
		{
			_ApplySkillEffect(Yard, *EffectRow, TargetUnitIds, OutDeadEventSentUnits, bCritical);
		}
		else
		{
			Q6JsonLogMild(Warning, "TargetUnitIds Num is Zero.", Q6KV("SkillType", Yard.SkillType), Q6KV("SkillEffectType", EffectRow->Type));
		}
	}

	if (Yard.InOutState.SkillProp[(int32)Yard.BornCategory].bChangeOverKillPoint)
	{
		int32 GotOverKillPoint = Yard.SourceUnit.OverKill;
		Yard.SourceUnit.OverKill = OldOverKillPoint;

		if (bCritical)
		{
			_SetNewOverKill(Yard.Context, Yard.SourceUnit, -OldOverKillPoint, Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], EPointChangeReason::SkillConsume);
		}

		_SetNewOverKill(Yard.Context, Yard.SourceUnit, GotOverKillPoint, Yard.InOutState.UnitsState.EntryAliveUnitCount[(int32)Yard.SourceUnit.Faction], EPointChangeReason::SkillEffect);
	}
}

static void _UseAllSupportSkills(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId UltimateUnitId)
{
	TArray<FCCUsedCharSkillInfo> UsedSupportSkills;
	for (FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally))
	{
		if (Unit->UnitId == UltimateUnitId)
		{
			continue;
		}

		if (!Unit->IsSupporter() && Unit->SA < CombatCubeConst::Q6_UA_SA_CONSUME)
		{
			continue;
		}
		// if unit is supporter or has enough SA, then uses support skill.

		TArray<FCCSkillState*> Supports = Unit->GetSkillStates(ESkillCategory::Support);
		if (Supports.Num() == 0)
		{
			Q6JsonLog(Error, "No Support Skill", Q6KV("UnitType", Unit->UnitType.x));
			continue;
		}

		UseSkill(Context, InOutState, Supports[0]->SkillId
			, Unit->UnitId, UltimateUnitId, ESkillCategory::Support, EMoment::None, false, false);

		if (InOutState.CombatSeed.Content == EContentType::Raid)
		{
			FCCUsedCharSkillInfo CharSkillInfo;
			CharSkillInfo.CharacterId = Unit->CharacterId;
			CharSkillInfo.NatureType = Unit->GetNatureType();
			CharSkillInfo.SkillType = FSkillType(Supports[0]->SkillType);
			CharSkillInfo.Slot = Unit->Slot;

			for (int32 Index = 0; Index < EUnitAttributeMax; ++Index)
			{
				EUnitAttribute Attribute = static_cast<EUnitAttribute>(Index);
				CharSkillInfo.Attributes.Add(Unit->GetAttributeValue(Attribute));
			}

			UsedSupportSkills.Add(CharSkillInfo);
		}
	}

	if (InOutState.CombatSeed.Content == EContentType::Raid)
	{
		InOutState.RaidState.UsedSupportSkills.Append(UsedSupportSkills);

		TArray<FCCRaidSkillState>& RaidSupportSkillStates = InOutState.RaidState.RaidSupportSkillStates;
		int32 UsedSupportSkillCount = UsedSupportSkills.Num();
		for (int32 Index = 0; Index < CombatCubeConst::Q6_MAX_SUPPORT_SKILL_AT_ONE_TIME - UsedSupportSkillCount; ++Index)
		{
			if (!RaidSupportSkillStates.IsValidIndex(Index))
			{
				continue;
			}

			if (RaidSupportSkillStates[Index].bIsUsed)
			{
				continue;
			}

			UseSkill(Context, InOutState, RaidSupportSkillStates[Index].SkillState.SkillId
				, UltimateUnitId, UltimateUnitId, ESkillCategory::RaidSupport, EMoment::None, false, false);

			RaidSupportSkillStates[Index].bIsUsed = true;
		}
	}
}

static void _UseVersaSkills(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId TargetUnitId, ESkillCategory SkillCategory)
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(TargetUnitId);
	FCCUnitState& Master = InOutState.UnitsState.Masters[(int32)TargetUnit.Faction];

	int32 SkillSequence = InOutState.UnitsState.GetCountSkillsOnCurPhase(InOutState, Master.Faction, SkillCategory);

	int32 SkillType = GetCMS()->GetFormulaConstValues(InOutState.UnitsState.EntryAliveUnitCount[(int32)Master.Faction]).VersaSkillIds[SkillSequence];
	FCCSkillId SkillId = Master.GetVersaSkillId(SkillType);

	if (SkillId == CCSkillIdInvalid)
	{
		Q6JsonLog(Warning, "wrong versa skill", Q6KV("unit type", Master.UnitType.x), Q6KV("skill type", SkillType));
		return;
	}

	Q6JsonLog(Display, "use versa skill", Q6KV("unit type", Master.UnitType.x), Q6KV("skill type", SkillType));
	UseSkill(Context, InOutState, SkillId, Master.UnitId, TargetUnitId, ESkillCategory::Versa, EMoment::None, false, false);
}

static void _CheckStraightNote(FCCUnitState& Unit, ESkillNote Note, int32 EntryAliveUnitCount, int32 SkillSequence)
{
	if (Note == ESkillNote::None)
	{
		return;
	}

	if (EntryAliveUnitCount == 3)
	{
		if (SkillSequence == 1 && Note == ESkillNote::Ace)
		{
			Unit.bStraightNote = true;
		}
		else if (SkillSequence == 2 && Note == ESkillNote::Break)
		{
			Unit.bStraightNote = true;
		}
		else if (SkillSequence == 3 && Note == ESkillNote::Closer)
		{
			Unit.bStraightNote = true;
		}
	}
	else if (EntryAliveUnitCount == 2)
	{
		if (SkillSequence == 1 && Note == ESkillNote::Ace)
		{
			Unit.bStraightNote = true;
		}
		else if (SkillSequence == 2 && Note == ESkillNote::Closer)
		{
			Unit.bStraightNote = true;
		}
	}
	else if (EntryAliveUnitCount == 1)
	{
		if (SkillSequence == 1 && Note == ESkillNote::Closer)
		{
			Unit.bStraightNote = true;
		}
	}
	else
	{
		ensure(0);
	}
}

static bool _ApplyDoubleSkill(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitState& SourceUnit, const FCCUnitId& TargetUnitId)
{
	int32 StraightCount = 0;

	for (const FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(SourceUnit.Faction))
	{
		if (Unit->HasSkillOnAttack())
		{
			continue;
		}

		if (Unit->bStraightNote)
		{
			++StraightCount;
		}
	}

	// is all unit finished straight attack.
	if (CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT != StraightCount)
	{
		return false;
	}

	for (FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(SourceUnit.Faction))
	{
		Unit->bStraightNote = false;
	}

	FCCSkillId DoubleSkillId = SourceUnit.GetDoubleSkillId();
	if (DoubleSkillId == CCSkillIdInvalid)
	{
		Q6JsonLog(Display, "use not exist double skill", Q6KV("unit type", SourceUnit.UnitType.x), Q6KV("target type", TargetUnitId.X));
		return false;
	}

	Q6JsonLog(Display, "use double skill", Q6KV("unit type", SourceUnit.UnitType.x), Q6KV("target type", TargetUnitId), Q6KV("skill type", DoubleSkillId));

	UseSkill(Context, InOutState, DoubleSkillId, SourceUnit.UnitId, TargetUnitId, ESkillCategory::Double, EMoment::None, false, false);

	return true;
}

static const FCCSkillState* GetSkillState(FCCUnitState& Unit, const FCCSkillId& SkillId, FCCCombatCubeState& InOutState, ESkillCategory InBornCategory)
{
	switch (InBornCategory)
	{
		case ESkillCategory::RaidTurnBegin:
			{
				for (const FCCRaidSkillState& RaidTurnSkillState : InOutState.RaidState.RaidTurnSkillStates)
				{
					if (SkillId == RaidTurnSkillState.SkillState.SkillId)
					{
						return &RaidTurnSkillState.SkillState;
					}
				}
			}
			break;
		case ESkillCategory::RaidSupport:
			{
				for (const FCCRaidSkillState& RaidSupportSkillState : InOutState.RaidState.RaidSupportSkillStates)
				{
					if (SkillId == RaidSupportSkillState.SkillState.SkillId)
					{
						return &RaidSupportSkillState.SkillState;
					}
				}
			}
			break;
		default:
			return Unit.GetSkillState(SkillId);
			break;
	}

	return nullptr;
}

static bool IsVaildTurnSkillInRaid(bool bIsPlayerUseSkill, const FCCCombatCubeState& InOutState
	, const FCCUnitState& Unit, const FCMSSkillRow& SkillRow)
{
	if (!bIsPlayerUseSkill)
	{
		return false;
	}

	if (InOutState.CombatSeed.Content != EContentType::Raid)
	{
		return false;
	}

	if (SkillRow.SkillCategory != ESkillCategory::TurnBegin)
	{
		return false;
	}

	if (Unit.Category != EAttributeCategory::Character
		|| Unit.Faction != ECCFaction::Ally)
	{
		return false;
	}

	return true;
}

static bool _IsSkillDrivenMoment(EMoment InMoment)
{
	switch (InMoment)
	{
		case EMoment::AtBeaten:
		case EMoment::AtDodge:
		case EMoment::PostDie:
		case EMoment::AtBuffExpire:
		case EMoment::AtKill:
		case EMoment::AtAttack:
		case EMoment::AtBuffMaxOverlap:
			return true;
		default:
			return false;
	}
}

static void UseSkill(const FActionContext& Context, FCCCombatCubeState& InOutState,
	const FCCSkillId& SkillId, const FCCUnitId& UnitId, FCCUnitId TargetUnitId, ESkillCategory InBornCategory, EMoment InMoment, bool bIsPlayerUseSkill, bool bPattern)
{
	FCCUnitState& Unit = InOutState.UnitsState.FindUnitState(UnitId, true);
	if (!ensure(Unit.UnitId != CCUnitIdInvalid))
	{
		// Where the hell unit has gone?
		return;
	}

	if (SkillId == CCSkillIdInvalid)
	{
		// Monster has no skill in it's turn. so, it needs to skip to use skill.(by push invalid skill)
		Unit.AddSkillOnAttack(SkillTypeInvalid.x);
		ensure(0);
		return;
	}

	const FCCSkillState* SkillState = GetSkillState(Unit, SkillId, InOutState, InBornCategory);
	if (!SkillState)
	{
		Q6JsonLog(Warning, "use skill no exist.", Q6KV("unit type", Unit.UnitType), Q6KV("skill id", SkillId), Q6KV("skill category", (int32)InBornCategory));
		return;
	}
	int32 SkillLevel = FMath::Clamp(SkillState->Level, CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL);
	if (SkillLevel == CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL)
	{
		Q6JsonLog(Warning, "skill is locked.", Q6KV("unit type", Unit.UnitType), Q6KV("skill id", SkillId));
		return;
	}
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillState->SkillType);

	TargetUnitId = _SwitchToCrossFire(InOutState, Unit.Faction, SkillRow, TargetUnitId);

	Q6JsonLog(Display, "use skill", Q6KV("unit type", Unit.UnitType), Q6KV("skill type", SkillState->SkillType),
		Q6KV("alive unit count", InOutState.UnitsState.EntryAliveUnitCount), Q6KV("parent skill category", (int32)InBornCategory));

	if (Unit.IsDead()
		&& SkillRow.SkillCategory != ESkillCategory::Moment)
	{
		_ReportError(Context, bIsPlayerUseSkill, ECCErrorCode::Dead);
		return;
	}

	if (Unit.IsInCooldown(Context, SkillId)
		&& InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasCoolTime
		&& InBornCategory != ESkillCategory::RaidTurnBegin
		&& InBornCategory != ESkillCategory::RaidSupport
		)
	{
		_ReportError(Context, bIsPlayerUseSkill, ECCErrorCode::Cooldown);
		return;
	}

	if (!Unit.CanUseSkillOnCurrentPhase(SkillRow, InOutState.TurnState.CurrentPhase))
	{
		_ReportError(Context, bIsPlayerUseSkill, ECCErrorCode::CantUseOnCurrentPhase);
		return;
	}

	FApplyTagFailedInfo ApplyTagFailedInfo;
	if (!_ApplyTagUseSkill(Context, InOutState, SkillRow, Unit, TargetUnitId, SkillState->Level, InBornCategory, ApplyTagFailedInfo))
	{
		if (Unit.Faction == ECCFaction::Ally)
		{
			UCCSkillFailedEvent* Event = NewObject<UCCSkillFailedEvent>();
			Event->UnitId = UnitId;
			Event->SkillType = SkillRow.Type;
			Event->FailedInfo = ApplyTagFailedInfo;
			Event->IsBlocking = InBornCategory == ESkillCategory::RaidTurnBegin;
			Context.OnEvent.Broadcast(Event);
		}
		return;
	}

	bool bConsumeSA = false;
	if (SkillRow.SkillCategory == ESkillCategory::Support)
	{
		if (bIsPlayerUseSkill)
		{
			_ReportError(Context, bIsPlayerUseSkill, ECCErrorCode::CantUseSupportSkill);
			return;
		}

		if (InBornCategory != ESkillCategory::RaidSupport)
		{
			if (!Unit.IsSupporter())
			{
				if (Unit.SA < CombatCubeConst::Q6_UA_SA_CONSUME)
				{
					return;
				}

				bConsumeSA = true;
				Unit.bSupporter = true;
			}
		}

		// else, No consume SA and keep doing support skill
	}

	bool bConsumeUA = false;
	if (bIsPlayerUseSkill)
	{
		if (!Unit.HasSkillOnAttack())
		{
			_ReportError(Context, bIsPlayerUseSkill, ECCErrorCode::UseSkillOnlyOnceOnPhase);
			return;
		}

		if (SkillRow.SkillCategory == ESkillCategory::Ultimate)
		{
			if (Unit.UA < CombatCubeConst::Q6_UA_SA_CONSUME)
			{
				_ReportError(Context, bIsPlayerUseSkill, ECCErrorCode::NotEnoughUA);
				return;
			}

			bConsumeUA = true;
			_UseAllSupportSkills(Context, InOutState, UnitId);
		}
	}

	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bInvokeVersa)
	{
		if (Unit.GetCrowdControlState(GetCMS(), ECrowdControl::Versa) > 0)
		{
			_UseVersaSkills(Context, InOutState, UnitId, SkillRow.SkillCategory);
		}
	}

	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bDependOnSequence)
	{
		Unit.AddSkillOnAttack(SkillState->SkillType);
	}

	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasCoolTime)
	{
		if (InBornCategory != ESkillCategory::RaidTurnBegin)
		{
			_SetSkillTime(Context, InOutState, Unit, SkillId,
				CombatCubeConst::Q6_BASE_SKILL_COOLDOWN,
				CombatCubeConst::Q6_BASE_SKILL_WAITDOWN);
		}
	}

	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bHasNote == true)
	{
		_CheckStraightNote(Unit, SkillRow.SkillNote,
			InOutState.UnitsState.EntryAliveUnitCount[(int32)Unit.Faction],
			InOutState.UnitsState.GetCountSkillsOnCurPhase(InOutState, Unit.Faction, SkillRow.SkillCategory));
	}

	TArray<FCCUnitId> TargetUnitIds = _GetTargetUnits(Context, InOutState, Unit.UnitId, Unit.Faction, SkillRow.Target, TargetUnitId, GetCMS(), SkillRow.SkillCategory);
	int32 SkillSequence = InOutState.UnitsState.GetCountSkillsOnCurPhase(InOutState, Unit.Faction, SkillRow.SkillCategory);

	CCSkillYard Yard(Context, InOutState, Unit, SkillRow);
	Yard.SkillId = SkillId;
	Yard.SkillType = SkillState->SkillType;
	Yard.bIsPlayerUseSkill = bIsPlayerUseSkill;
	Yard.TargetUnitId = TargetUnitId;
	Yard.TargetUnitIds = TargetUnitIds;
	Yard.SkillLevel = SkillLevel;
	Yard.BornCategory = Yard.SkillDesc.SkillCategory;
	if (Yard.SkillDesc.SkillCategory == ESkillCategory::Moment
		|| InBornCategory == ESkillCategory::RaidTurnBegin
		|| InBornCategory == ESkillCategory::RaidSupport
		)
	{
		Yard.BornCategory = InBornCategory;
	}
	Yard.ChordNote = MatchedSkillChordNote(Context, InOutState,
		InOutState.UnitsState.EntryAliveUnitCount[(int32)Unit.Faction],
		SkillSequence,
		SkillRow);
	ensure(Yard.BornCategory != ESkillCategory::Moment);

	UCCSkillUsedEvent* UsedEvent = NewObject<UCCSkillUsedEvent>();
	UsedEvent->SkillId = SkillId;
	UsedEvent->UnitId = UnitId;
	UsedEvent->TargetUnitId = TargetUnitIds.IsValidIndex(0) ? TargetUnitIds[0] : TargetUnitId;
	UsedEvent->SkillType = SkillState->SkillType;
	UsedEvent->IsSupporter = Unit.IsSupporter();
	UsedEvent->IsLast = !InOutState.UnitsState.PossibleAttackByFaction(Unit.Faction, GetCMS());
	UsedEvent->AttackOrder = SkillSequence;
	UsedEvent->ChordNote = Yard.ChordNote;
	UsedEvent->SkillCategory = (InBornCategory == ESkillCategory::RaidTurnBegin) ? InBornCategory : SkillRow.SkillCategory;
	UsedEvent->Moment = InMoment;
	UsedEvent->IsPattern = bPattern;

	Context.OnEvent.Broadcast(UsedEvent);

	if (Unit.IsAlly())
	{
		_UseSkillMissionEvent(Context, InOutState, UsedEvent, &Unit);
	}

	if (bConsumeSA)
	{
		_SetNewSA(Context, Unit, SkillState->SkillType, Unit.SA - CombatCubeConst::Q6_UA_SA_CONSUME, EPointChangeReason::SkillConsume);
	}

	if (bConsumeUA)
	{
		_SetNewUA(Context, Unit, SkillState->SkillType, Unit.UA - CombatCubeConst::Q6_UA_SA_CONSUME, EPointChangeReason::SkillConsume);
	}

	if (Unit.Faction == ECCFaction::Ally && UsedEvent->TargetUnitId != InOutState.TurnState.PlayerTargetUnitId)
	{
		if (!Unit.GetCrowdControlState(GetCMS(), ECrowdControl::Provoke))
		{
			FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UsedEvent->TargetUnitId);
			if (TargetUnit.Faction == ECCFaction::Enemy)
			{
				FCCUnitId OldTargetUnitId = InOutState.TurnState.PlayerTargetUnitId;
				InOutState.TurnState.PlayerTargetUnitId = UsedEvent->TargetUnitId;

				UCCTargetSelectedEvent* TargetSelectedEvent = NewObject<UCCTargetSelectedEvent>();
				TargetSelectedEvent->UnitId = InOutState.TurnState.PlayerTargetUnitId;
				TargetSelectedEvent->OldUnitId = OldTargetUnitId;
				Context.OnEvent.Broadcast(TargetSelectedEvent);
			}
		}
	}

	const_cast<FCCSkillState*>(SkillState)->UsingCount++;

	TArray<FCCUnitId> Zombie;
	for (const FCCUnitId& Id : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(Id);
		if (!TargetUnit.IsDead())
		{
			continue;
		}
		Zombie.Add(Id);
	}

	TArray<FCCUnitId> DeadEventSentUnits;
	_ApplySkillEffects(Yard, DeadEventSentUnits);

	TArray<FCCUnitId> DieUnit;
	TArray<FCCUnitId> DieEnemyUnits;
	for (const FCCUnitId& Id : TargetUnitIds)
	{
		FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(Id);
		if (!TargetUnit.IsDead())
		{
			continue;
		}

		if (Zombie.Find(Id) != INDEX_NONE)
		{
			continue;
		}

		if (TargetUnit.Faction == ECCFaction::Enemy)
		{
			DieEnemyUnits.Add(Id);
		}

		DieUnit.Add(Id);
	}

	UCCSkillEndEvent* EndEvent = NewObject<UCCSkillEndEvent>();
	EndEvent->IsSkillOwnerDead = Unit.IsDead();
	Context.OnEvent.Broadcast(EndEvent);

	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bActiveAttack == true)
	{
		_FlushUnitHitCountBuff(Context, InOutState, TargetUnitIds);
	}

	for (const FCCUnitId& Id : DieUnit)
	{
		FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(Id);
		_ClearSubParts(Context, InOutState, TargetUnit);
	}

	_ApplyMomentSkills(Context, InOutState, EMoment::AtBeaten);
	_ApplyMomentSkills(Context, InOutState, EMoment::AtDodge);
	_ApplyMomentSkills(Context, InOutState, EMoment::PostDie);

	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bActiveAttack == true)
	{
		if (DieUnit.Num())
		{
			_ReadyMomentSkill(InOutState, Unit, SkillRow.SkillCategory, EMoment::AtKill, CCUnitIdInvalid);
		}

		if (SkillRow.SkillCategory == ESkillCategory::Normal)
		{
			bool Double = _ApplyDoubleSkill(Context, InOutState, Unit, UsedEvent->TargetUnitId);
			bool Chain = _ApplyChainSkill(Context, InOutState);
			if (!Double && !Chain)
			{
				_ReadyMomentSkill(InOutState, Unit, SkillRow.SkillCategory, EMoment::AtAttack, TargetUnitId);
			}
		}
		else
		{
			_ReadyMomentSkill(InOutState, Unit, SkillRow.SkillCategory, EMoment::AtAttack, TargetUnitId);
		}
	}

	bool bSendDeadEvent = false;
	if (bIsPlayerUseSkill)
	{
		for (FCCUnitId Id : DeadEventSentUnits)
		{
			if (DieEnemyUnits.Contains(Id))
			{
				DieEnemyUnits.Remove(Id);
			}
		}

		// enemies could be died multiple (not allies)
		if (DieEnemyUnits.Num() > 0)
		{
			_DeadEvent(Context, InOutState, DieEnemyUnits, SkillId, false, false);
			bSendDeadEvent = true;
		}
	}
	else
	{
		//HACK-HACK-HACK for Kakao.

		if (SkillRow.SkillCategory == ESkillCategory::Ultimate)
		{
			if (SystemConstHelper::IsBoneDragonSagaType(InOutState.CombatSeed.SagaType))
			{
				int32 AlliesCount = 0;
				int32 EnemiesCount = 0;

				if (InOutState.VerifyFinishCondition(AlliesCount, EnemiesCount))
				{
					_EndGame(Context, InOutState, ECCResult::Win, false, ECCEndReason::None);
					return;
				}
			}
		}
	}

	for (const FCCUnitId& Id : DieUnit)
	{
		FCCUnitState& DeadUnit = InOutState.UnitsState.FindUnitState(Id);
		if ((!bSendDeadEvent || DeadUnit.Faction != ECCFaction::Enemy) && !DeadEventSentUnits.Contains(Id))
		{
			_DeadEvent(Context, InOutState, Id, SkillId, DeadUnit.IsAlly(), false);
		}

		if (Id == InOutState.TurnState.PlayerTargetUnitId)
		{
			FCCUnitId OldTargetUnitId = InOutState.TurnState.PlayerTargetUnitId;
			InOutState.TurnState.PlayerTargetUnitId = CCUnitIdInvalid;

			UCCTargetSelectedEvent* TargetSelectedEvent = NewObject<UCCTargetSelectedEvent>();
			TargetSelectedEvent->UnitId = InOutState.TurnState.PlayerTargetUnitId;
			TargetSelectedEvent->OldUnitId = OldTargetUnitId;
			Context.OnEvent.Broadcast(TargetSelectedEvent);
		}

		_ResolveProvokeOnDie(Context, InOutState, Id);
	}

	if (InOutState.SkillProp[(int32)SkillRow.SkillCategory].bActiveAttack == true)
	{
		_ApplyMomentSkills(Context, InOutState, EMoment::AtKill);
		_ApplyMomentSkills(Context, InOutState, EMoment::AtAttack);
	}

	_ApplyMomentSkills(Context, InOutState, EMoment::AtBuffMaxOverlap);

	if (!_IsSkillDrivenMoment(InMoment))
	{
		UCCAttackPassEvent* PassEvent = NewObject<UCCAttackPassEvent>();
		PassEvent->PhasePassUnitIds = _GetAttackPassUnits(InOutState, Unit.Faction);
		Context.OnEvent.Broadcast(PassEvent);
	}

	if (IsVaildTurnSkillInRaid(bIsPlayerUseSkill, InOutState, Unit, SkillRow))
	{
		FCCUsedCharSkillInfo UsedTurnSkillInfo;
		UsedTurnSkillInfo.CharacterId = Unit.CharacterId;
		UsedTurnSkillInfo.NatureType = Unit.GetNatureType();
		UsedTurnSkillInfo.SkillType = FSkillType(SkillState->SkillType);
		UsedTurnSkillInfo.Slot = Unit.Slot;

		for (int32 Index = 0; Index < EUnitAttributeMax; ++Index)
		{
			EUnitAttribute Attribute = static_cast<EUnitAttribute>(Index);
			UsedTurnSkillInfo.Attributes.Add(Unit.GetAttributeValue(Attribute));
		}

		InOutState.RaidState.UsedTurnSkillInfos.Add(UsedTurnSkillInfo);
	}

	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(TargetUnitId);
	if (Unit.Faction == ECCFaction::Enemy && TargetUnit.Faction == ECCFaction::Ally)
	{
		InOutState.LastEnemyTarget = TargetUnitId;
	}
}

static void _FlushPhaseRelatedStuffsAll(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;
	for (FCCUnitState& Iter : InOutState.UnitsState.Units)
	{
		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Iter.CombatMultiSide, CurrentWaveIndex, Iter.SpawnedWaveIndex))
		{
			continue;
		}

		Iter.SkillsOnAttack.Empty();
		Iter.bSupporter = false;
		Iter.bStraightNote = false;
		for (int32 i = Iter.Skills.Num() - 1; i >= 0; --i)
		{
			const FCCSkillState& S = Iter.Skills[i];
			if (S.Category != ESkillCategory::Moment)
			{
				continue;
			}

			Iter.Skills.RemoveAtSwap(i);
		}
	}
}

static void _SelectPatternUltimate(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	for (FCCUnitState* U : InOutState.UnitsState.GetAliveUnits(ECCFaction::Enemy))
	{
		if (U->Patterns.Num() <= 0)
		{
			continue;
		}
		if (U->SelectedPatternsUltimate != MonsterPatternTypeInvalid)
		{
			continue;
		}

		for (const FCCPatternState& P : U->Patterns)
		{
			const FCMSMonsterPatternRow& PRow = GetCMS()->GetMonsterPatternRowOrDummy(P.Type);
			FCCSkillState* S = U->GetSkillState(P.SkillId);

			if (PRow.IsInvalid() || S == nullptr)
			{
				continue;
			}

			if (S->Category != ESkillCategory::Ultimate)
			{
				continue;
			}
			if (S->IsInCooldown())
			{
				continue;
			}
			if (S->IsInWaitdown())
			{
				continue;
			}

			if (!UCombatCubeStateUtil::IsPatternMatched(PRow, U, P))
			{
				continue;
			}

			U->SelectedPatternsUltimate = P.Type;

			UCCSelectedPatternUltimate* Event = NewObject<UCCSelectedPatternUltimate>();
			Event->UnitId = U->UnitId;
			Event->SkillId = P.SkillId;
			Context.OnEvent.Broadcast(Event);

			Q6JsonLog(Display, "selected pattern ultimate skill", Q6KV("unit type", U->UnitType),
				Q6KV("skill type", S->SkillType));
		}

		break;
	}
}

static void _FlushUnitSelectedPatternUltimate(FCCCombatCubeState& InOutState)
{
	for (FCCUnitState* U : InOutState.UnitsState.GetAliveUnits(ECCFaction::Max))
	{
		U->SelectedPatternsUltimate = MonsterPatternTypeInvalid;
	}
}


static void _FlushSkillCoolDown(TArray<FCCSkillState>& Skills, FCCCombatCubeState& InOutState)
{
	for (FCCSkillState& SkillIter : Skills)
	{
		if (InOutState.SkillProp[(int32)SkillIter.Category].bUtilizeCoolTimeForAvailable == true)
		{
			continue;
		}

		SkillIter.Cooldown = FMath::Max(SkillIter.Cooldown - 1, 0);
	}
}

static void _FlushUnitCoolDown(FCCCombatCubeState& InOutState)
{
	ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;

	for (FCCUnitState& Iter : InOutState.UnitsState.Units)
	{
		if (Iter.IsDead())
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Iter.CombatMultiSide, CurrentWaveIndex, Iter.SpawnedWaveIndex))
		{
			continue;
		}

		_FlushSkillCoolDown(Iter.Skills, InOutState);
	}

	for (FCCUnitState& Iter : InOutState.UnitsState.Masters)
	{
		_FlushSkillCoolDown(Iter.Skills, InOutState);
	}
}

static void _FlushSkillWaitDown(TArray<FCCSkillState*>& Skills)
{
	if (Skills.Num() <= 0)
	{
		return;
	}

	FCCSkillState* FirstSkill = Skills[0];
	FirstSkill->Waitdown = FMath::Max(FirstSkill->Waitdown - 1, 0);
}

static void _FlushUnitWaitDown(FCCCombatCubeState& InOutState)
{
	ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;

	for (FCCUnitState& Iter : InOutState.UnitsState.Units)
	{
		if (Iter.IsDead())
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Iter.CombatMultiSide, CurrentWaveIndex, Iter.SpawnedWaveIndex))
		{
			continue;
		}

		for (int c = 0; c < dimof(InOutState.SkillProp); ++c)
		{
			if (InOutState.SkillProp[c].bHasWaitTime == false)
			{
				continue;
			}

			TArray<FCCSkillState*> Skills = Iter.GetSkillStates((ESkillCategory)c);
			_FlushSkillWaitDown(Skills);
		}
	}
}

static void _FlushUnitBuffEffect(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	const UCMS* CMS = GetCMS();

	ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;

	for (FCCUnitState& Iter : InOutState.UnitsState.Units)
	{
		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Iter.CombatMultiSide, CurrentWaveIndex, Iter.SpawnedWaveIndex))
		{
			continue;
		}

		if (Iter.IsDead())
		{
			for (int32 i = Iter.Buffs.Num() - 1; i >= 0; --i)
			{
				const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Iter.Buffs[i].BuffType));
				if (CMSBuffRow.Infinity)
				{
					continue;
				}

				if (Iter.Buffs[i].CreatedTurnCount >= InOutState.TurnState.TurnCount)
				{
					continue;
				}

				Iter.Buffs[i].Duration = FMath::Max(Iter.Buffs[i].Duration - 1, 0);
				if (Iter.Buffs[i].Duration == 0)
				{
					Iter.Buffs.RemoveAtSwap(i);
				}
			}

			continue;
		}

		Iter.UnitAttributes->ClearPointVaryAttributes();

		for (int32 i = Iter.Buffs.Num() - 1; i >= 0; --i)
		{
			const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(Iter.Buffs[i].BuffType));
			if (CMSBuffRow.Infinity)
			{
				continue;
			}

			if (Iter.Buffs[i].CreatedTurnCount >= InOutState.TurnState.TurnCount)
			{
				continue;
			}

			Iter.Buffs[i].Duration = FMath::Max(Iter.Buffs[i].Duration - 1, 0);
			if (Iter.Buffs[i].Duration == 0)
			{
				bool Versa = IsVersaBuff(Context, InOutState, Iter.Faction, Iter.Buffs[i].BuffType);
				FCCBuffId RemoveBuffId = Iter.Buffs[i].BuffId;

				_ReadyMomentSkill(InOutState, Iter, Iter.Buffs[i].BornCategory, EMoment::AtBuffExpire, CCUnitIdInvalid, RemoveBuffId);

				BroadcastRemoveBuffEvent(Context, Iter.UnitId, RemoveBuffId, ERemoveBuffReason::TimeExpired, Versa);

				Iter.Buffs.RemoveAtSwap(i);
			}
		}

		const TArray<TPair<int64, int64>>& UpdatedUnitAttributes = Iter.UnitAttributes->UpdateUnitAttributes(Context, Iter);

		for (const TPair<int64, int64>& UpdatedUnitAttribute : UpdatedUnitAttributes)
		{
			UCCUpdateAttributesEvent* UpdateAttributeEvent = NewObject<UCCUpdateAttributesEvent>();
			UpdateAttributeEvent->UnitAttributeType = CMS->GetUnitAttributeType(EUnitAttribute(UpdatedUnitAttribute.Key));
			UpdateAttributeEvent->UnitId = Iter.UnitId;
			UpdateAttributeEvent->AddedValue = UpdatedUnitAttribute.Value;
			Context.OnEvent.Broadcast(UpdateAttributeEvent);
		}
	}

	UCCUpdateBuffDurationsEvent* UpdateBuffDurationsEvent = NewObject<UCCUpdateBuffDurationsEvent>();
	UpdateBuffDurationsEvent->UnitStates = InOutState.UnitsState.Units;
	Context.OnEvent.Broadcast(UpdateBuffDurationsEvent);
}

static void _PickVersaCharacter(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	TArray<FCCUnitId> CollectUnitIds;
	for (const FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(VERSA_FACTION))
	{
		if (Unit->GetCrowdControlState(GetCMS(), ECrowdControl::PriorityVersa) <= 0)
		{
			continue;
		}

		CollectUnitIds.Add(Unit->UnitId);
	}

	if (CollectUnitIds.Num() <= 0)
	{
		for (const FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(VERSA_FACTION))
		{
			CollectUnitIds.Add(Unit->UnitId);
		}
	}

	if (CollectUnitIds.Num() == 0)
	{
		return;
	}

	int32 PickCount = Context.MT19937->GenRandom(CollectUnitIds.Num());
	FCCUnitId PickUnitId = CollectUnitIds[PickCount];

	const FCMSFormulaConstRow& Row = GetCMS()->GetFormulaConstValues(InOutState.UnitsState.EntryAliveUnitCount[(int32)VERSA_FACTION]);

	FCCUnitState& Unit = InOutState.UnitsState.FindUnitState(PickUnitId);
	Q6JsonLog(Display, "pick versa character", Q6KV("unit type", Unit.UnitType.x), Q6KV("buff type", Row.VersaBuffId));

	// I dont know versa buff's level.
	_CreateBuff(Context, InOutState, PickUnitId, PickUnitId, Row.VersaBuffId, 1, 0,
		CombatCubeConst::Q6_MAX_SKILL_LEVEL, InOutState.TurnState.TurnCount, false, ESkillCategory::Versa, CCSkillIdInvalid);
}

static void _DespawnOldWaveMonsters(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	for (const FCCUnitId& Iter : InOutState.UnitsState.GetEnemyUnits())
	{
		InOutState.UnitsState.Units.RemoveAll([Iter](const FCCUnitState& InUnitState) {
			return InUnitState.UnitId == Iter;
		});

		if (Iter == InOutState.TurnState.PlayerTargetUnitId)
		{
			FCCUnitId OldTargetUnitId = InOutState.TurnState.PlayerTargetUnitId;
			InOutState.TurnState.PlayerTargetUnitId = CCUnitIdInvalid;

			UCCTargetSelectedEvent* TargetSelectedEvent = NewObject<UCCTargetSelectedEvent>();
			TargetSelectedEvent->UnitId = InOutState.TurnState.PlayerTargetUnitId;
			TargetSelectedEvent->OldUnitId = OldTargetUnitId;
			Context.OnEvent.Broadcast(TargetSelectedEvent);
		}
		UCCDespawnUnitEvent* DespawnEvent = NewObject<UCCDespawnUnitEvent>();
		DespawnEvent->UnitId = Iter;
		Context.OnEvent.Broadcast(DespawnEvent);
	}
}

static void _DespawnUnit(const FActionContext& Context, FCCCombatCubeState& InOutState, FCCUnitId InUnitId)
{
	ECombatMultiSide CurrentCombatMultiSide = InOutState.TurnState.CurrentCombatMultiSide;
	int32 CurrentWaveIndex = InOutState.TurnState.CurrentWaveIndex;

	for (int32 i = 0; i < InOutState.UnitsState.Units.Num(); ++i)
	{
		if (InOutState.UnitsState.Units[i].UnitId == InUnitId &&
			UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, InOutState.UnitsState.Units[i].CombatMultiSide, CurrentWaveIndex, InOutState.UnitsState.Units[i].SpawnedWaveIndex))
		{
			InOutState.UnitsState.Units.RemoveAtSwap(i);
			UCCDespawnUnitEvent* DespawnEvent = NewObject<UCCDespawnUnitEvent>();
			DespawnEvent->UnitId = InUnitId;
			Context.OnEvent.Broadcast(DespawnEvent);
		}
	}
}

static void _ApplyBuffDamage(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCTurnPhase NewPhase, ECCFaction InFaction)
{
	if (NewPhase != ECCTurnPhase::Prepare)
	{
		return;
	}

	FCCUnitId KillerUnitId = CCUnitIdInvalid;

	UCCDamageBuffEvent* Event = NewObject<UCCDamageBuffEvent>();

	TArray<UCCUnitDeadEvent*> DieEvents;
	for (FCCUnitState* TargetUnit : InOutState.UnitsState.GetAliveUnits(InFaction))
	{
		for (int i = 0; i < TargetUnit->Buffs.Num(); ++i)
		{
			FCCBuffState& Itor = TargetUnit->Buffs[i];
			if (Itor.Damage <= 0)
			{
				continue;
			}

			int32 BuffEffectType = 0;

			for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(Itor, ECrowdControl::TurnAtk))
			{
				BuffEffectType = Effect->Type;
			}

			int32 OriginalDamage = (int32)Itor.Damage;
			if (InOutState.GetGameFlag(EGameFlags::NoDamage)) // -V1051
			{
				Q6JsonLog(Warning, "cheat No Damage", Q6KV("real damage", OriginalDamage));
				OriginalDamage = 0;
			}

			FCCUnitState& SourceUnit = InOutState.UnitsState.FindUnitState(Itor.SourceUnitId);

			bool bCCDefence = false;
			if (TargetUnit->GetCrowdControlState(GetCMS(), ECrowdControl::Invincible) > 0)
			{
				if (SourceUnit.GetCrowdControlState(GetCMS(), ECrowdControl::IgnoreInvincible) > 0)
				{
					Q6JsonLog(Display, "ignore TurnAtk Invincible", Q6KV("unit", TargetUnit->UnitType), Q6KV("buff type", Itor.BuffType));
				}
				else
				{
					Q6JsonLog(Display, "TurnAtk Invincible", Q6KV("unit", TargetUnit->UnitType), Q6KV("buff type", Itor.BuffType), Q6KV("original damage", OriginalDamage));
					OriginalDamage = 0;
					bCCDefence = true;
				}
			}

			int32 ShieldBuffIdx = -1;
			for (int index = 0; index < TargetUnit->Buffs.Num(); ++index)
			{
				FCCBuffState& B = TargetUnit->Buffs[index];

				for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(B, ECrowdControl::Shield))
				{
					ShieldBuffIdx = index;
					break;
				}
			}

			int32 BaseDamage = OriginalDamage;
			int32 ShieldDamage = 0;
			if (TargetUnit->Buffs.IsValidIndex(ShieldBuffIdx))
			{
				ShieldDamage = OriginalDamage;

				FCCBuffState& ShieldBuff = TargetUnit->Buffs[ShieldBuffIdx];

				int32 Shield = ShieldBuff.Shield;
				if (ShieldBuff.Shield - ShieldDamage > 0)
				{
					ShieldBuff.Shield = Shield - ShieldDamage;
					BaseDamage = 0;
				}
				else
				{
					ShieldDamage = Shield;
					BaseDamage = FMath::Max(0, BaseDamage - Shield);

					BroadcastRemoveBuffEvent(Context, TargetUnit->UnitId, ShieldBuff.BuffId, ERemoveBuffReason::Shield, false);

					TargetUnit->Buffs.RemoveAt(ShieldBuffIdx);
				}
			}

			int64 OldHealth = TargetUnit->Health;
			int64 NewHealth = FMath::Clamp(OldHealth - BaseDamage, 0LL, TargetUnit->GetAttributeValue(EUnitAttribute::MaxHealth));
			TargetUnit->Health = NewHealth;

			Q6JsonLog(Display, "apply buff damage", Q6KV("unit", TargetUnit->UnitType), Q6KV("buff type", Itor.BuffType),
				Q6KV("base damage", BaseDamage), Q6KV("shield damage", ShieldDamage));

			ENatureRelationType NatureRelationType = Formula::GetNatureRelationType(GetCMS(), SourceUnit.Faction, SourceUnit.GetNatureType(), TargetUnit->GetNatureType(), InOutState.CombatSeed.SagaType);
			Event->AppendEvent(NatureRelationType, TargetUnit->UnitId, Itor.BuffType, BuffEffectType, OldHealth, NewHealth, BaseDamage, ShieldDamage, bCCDefence);

			if (TargetUnit->IsDead())
			{
				KillerUnitId = Itor.SourceUnitId;
				break;
			}
		}

		if (TargetUnit->IsDead())
		{
			const FCCUnitId& TargetUnitId = TargetUnit->UnitId;
			UCCUnitDeadEvent* DieEvent = NewObject<UCCUnitDeadEvent>();
			DieEvent->UnitIds.Add(TargetUnitId);
			DieEvent->DrivenSkillId = CCSkillIdInvalid;
			DieEvents.Add(DieEvent);

			if (!TargetUnit->IsAlly())
			{
				_KillMissionEvent(Context, InOutState, TargetUnitId);

				InOutState.UnitsState.CheckClearUnits(TargetUnitId);
			}

			_ReadyMomentSkill(InOutState, *TargetUnit, ESkillCategory::TurnBegin, EMoment::PostDie, KillerUnitId);
		}
	}

	if (Event->EventNum())
	{
		Context.OnEvent.Broadcast(Event);
	}
	else
	{
		Event = nullptr;
	}

	_ApplyMomentSkills(Context, InOutState, EMoment::PostDie);

	for (const UCCUnitDeadEvent* E : DieEvents)
	{
		for (const FCCUnitId& UnitId : E->UnitIds)
		{
			FCCUnitState& Main = InOutState.UnitsState.FindUnitState(UnitId);
			_ClearSubParts(Context, InOutState, Main);
			Context.OnEvent.Broadcast(E);

			_ResolveProvokeOnDie(Context, InOutState, UnitId);
		}
	}
}

static void _ApplyBuffHeal(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCTurnPhase NewPhase, ECCFaction InFaction)
{
	if (NewPhase != ECCTurnPhase::Prepare)
	{
		return;
	}

	UCCHealBuffEvent* Event = NewObject<UCCHealBuffEvent>();

	for (FCCUnitState* TargetUnit : InOutState.UnitsState.GetAliveUnits(InFaction))
	{
		for (const FCCBuffState& Itor : TargetUnit->Buffs)
		{
			if (Itor.Heal <= 0)
			{
				continue;
			}

			int32 BuffEffectType = 0;

			for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(Itor, ECrowdControl::TurnHeal))
			{
				BuffEffectType = Effect->Type;
			}

			EHealthChangeReason Reason = EHealthChangeReason::Heal;
			int64 OldHealth = TargetUnit->Health;
			int64 NewHealth = FMath::Clamp(OldHealth + (int64)Itor.Heal, 0LL, TargetUnit->GetAttributeValue(EUnitAttribute::MaxHealth));
			if (TargetUnit->GetCrowdControlState(GetCMS(), ECrowdControl::HealBlock) > 0)
			{
				Q6JsonLog(Display, "heal block", Q6KV("unit", TargetUnit->UnitType));
				NewHealth = OldHealth;
				Reason = EHealthChangeReason::HealBlock;
			}

			Q6JsonLog(Display, "apply buff heal", Q6KV("unit", TargetUnit->UnitType), Q6KV("buff type", Itor.BuffType), Q6KV("heal", Itor.Heal));

			TargetUnit->Health = NewHealth;

			Event->AppendEvent(Itor.SourceUnitId, TargetUnit->UnitId, Itor.BuffType, BuffEffectType, OldHealth, NewHealth, NewHealth - OldHealth, Reason);
		}
	}

	if (Event->EventNum())
	{
		Context.OnEvent.Broadcast(Event);
	}
	else
	{
		Event = nullptr;
	}
}

static void _ApplySelfHeal(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCTurnPhase NewPhase, ECCFaction InFaction)
{
	if (NewPhase != ECCTurnPhase::Prepare)
	{
		return;
	}

	for (FCCUnitState* TargetUnit : InOutState.UnitsState.GetAliveUnits(InFaction))
	{
		const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(TargetUnit->UnitType));
		if (CMSUnitRow.HealthRegen <= 0)
		{
			continue;
		}

		if (TargetUnit->Health >= TargetUnit->GetAttributeValue(EUnitAttribute::MaxHealth))
		{
			continue;
		}

		_SetHealth(Context, InOutState, *TargetUnit, CCSkillIdInvalid, TargetUnit->Health + CMSUnitRow.HealthRegen, false, false, nullptr);
		Q6JsonLog(Display, "Self Heal", Q6KV("value", CMSUnitRow.HealthRegen));
	}
}

static void _ShuffleSkills(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	for (FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(ECCFaction::Max))
	{
		for (int c = 0; c < dimof(InOutState.SkillProp); ++c)
		{
			if (!InOutState.SkillProp[c].bHasNote)
			{
				continue;
			}

			TArray<FCCSkillState*> Skills = Unit->GetSkillStates((ESkillCategory)c);
			int32 SkillCount = Skills.Num();
			if (SkillCount <= 0)
			{
				continue;
			}

			int32 Index = InOutState.TurnState.TurnCount % SkillCount;
			if (Index != 0)
			{
				continue;
			}

			for (int32 i = 0; i < SkillCount - 1; ++i)
			{
				int32 j = Context.MT19937->GenRandom(SkillCount);

				FCCSkillState Temp = *Skills[i];
				*Skills[i] = *Skills[j];
				*Skills[j] = Temp;
			}
		}
	}
}

static void _SelectRandomTurnSkills(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	for (FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(ECCFaction::Max))
	{
		int32 RandomGroupCount = Unit->TurnSkillGroup.Num();
		if (RandomGroupCount <= 0)
		{
			continue;
		}

		TArray<FCCSkillState*> TurnBegins = Unit->GetSkillStates(ESkillCategory::TurnBegin);

		TArray<FCCSkillState*> RandomTurnBegins;
		for (FCCSkillState* S : TurnBegins)
		{
			if (S->IsPattern)
			{
				continue;
			}
			RandomTurnBegins.Add(S);
		}

		int32 AccumWaitTime = 0;
		for (int32 i = 0; i < RandomGroupCount; ++i)
		{
			if (RandomTurnBegins.IsValidIndex(i) == false)
			{
				continue;
			}

			AccumWaitTime += RandomTurnBegins[i]->WaitTime;
		}

		int32 Index = Unit->LiveTurnCount % (RandomGroupCount + AccumWaitTime);
		if (Index != 0)
		{
			continue;
		}

		// reset
		TurnBegins.StableSort([](const FCCSkillState& S1, const FCCSkillState& S2)
		{
			if (S1.IsPattern) // pattern skill was excluded from random skill.
			{
				return false;
			}

			if (S1.SkillId.X < S2.SkillId.X)
			{
				return true;
			}

			return false;
		});

		// select 1 by group
		int32 AccumTurnSkillIndex = 0;
		for (int32 i = 0; i < RandomGroupCount; ++i)
		{
			int Length = Unit->TurnSkillGroup[i];
			int32 Select = Context.MT19937->GenRandom(Length) + AccumTurnSkillIndex;

			if (TurnBegins.IsValidIndex(i) == false
				|| TurnBegins.IsValidIndex(Select) == false)
			{
				Q6JsonLog(Error, "Select Random TurnSkills wrong index",
					Q6KV("UnitType", Unit->UnitType),
					Q6KV("dst index", i),
					Q6KV("src index", Select));
				continue;
			}

			FCCSkillState Temp = *TurnBegins[i];
			*TurnBegins[i] = *TurnBegins[Select];
			*TurnBegins[Select] = Temp;

			AccumTurnSkillIndex += Length;
		}

		Q6JsonLog(Display, "Select Random TurnSkills", Q6KV("UnitType", Unit->UnitType));
	}
}

static bool _ApplyChainSkill(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	ESkillNote Note = _GetChainSkillNote(InOutState);
	if (Note == ESkillNote::None)
	{
		return false;
	}

	int UsedNoteSkillCount = 0;
	for (const FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(CHAIN_FACTION))
	{
		const TArray<int32> UsedSkills = Unit->GetUsedSkillsOnAttack();
		if (UsedSkills.Num() <= 0)
		{
			continue;
		}

		const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(UsedSkills[0]);
		if (InSkillRow.SkillNote == ESkillNote::None)
		{
			continue;
		}

		++UsedNoteSkillCount;
	}

	if (UsedNoteSkillCount != CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
	{
		return false;
	}

	Q6JsonLog(Display, "confirm chain bonus", Q6KV("chain note", (int32)Note));

	FSkillType ChainSkill;
	const FCMSFormulaConstRow& Row = GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
	switch (Note)
	{
	case ESkillNote::None:
		ensure(0);
		break;
	case ESkillNote::Ace:
		ChainSkill.x = Row.ChainAceSkillId;
		break;
	case ESkillNote::Break:
		ChainSkill.x = Row.ChainBreakSkillId;
		break;
	case ESkillNote::Closer:
		ChainSkill.x = Row.ChainCloserSkillId;
		break;
	default:
		ensure(0);
		break;
	}

	const FCCUnitState& Master = InOutState.UnitsState.Masters[(int32)CHAIN_FACTION];
	FCCSkillId SkillId = Master.GetChainSkillId(ChainSkill.x);

	for (const FCCUnitState* Unit : InOutState.UnitsState.GetAliveUnits(CHAIN_FACTION))
	{
		Q6JsonLog(Display, "apply chain bonus", Q6KV("unit id", Unit->UnitId), Q6KV("skill id", SkillId));

		UseSkill(Context, InOutState, SkillId, Master.UnitId, Unit->UnitId, ESkillCategory::Chain, EMoment::None, false, false);

		break;
	}

	return true;
}

static void SendRaidInfoToRaidServer(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	UCCRaidSkillUsed* Event = NewObject<UCCRaidSkillUsed>();

	for (const FCCUsedCharSkillInfo& Elem : InOutState.RaidState.UsedTurnSkillInfos)
	{
		FRaidSkillUsedElement E;
		E.UsedChar = Elem.CharacterId;
		E.NatureType = Elem.NatureType;
		E.UsedSkill = Elem.SkillType;
		E.Slot = Elem.Slot;
		E.Attributes = Elem.Attributes;
		Event->Elements.Add(E);
	}

	int64 TotalDamage(0);
	TArray<FCCUnitId> Enemies = InOutState.UnitsState.GetEnemyUnits();
	for (const FCCUnitId& UnitId : Enemies)
	{
		FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
		if (TargetUnit.UnitId == CCUnitIdInvalid)
		{
			continue;
		}

		int64 Damage = TargetUnit.GetAttributeValue(EUnitAttribute::MaxHealth) - TargetUnit.Health;
		check(Damage >= 0);

		TotalDamage += Damage;
		if (TotalDamage < 0)
		{
			Q6JsonLogGenie(Warning, "TotalDamage overflow"
				, Q6KV("TotalDamage", TotalDamage));
		}
	}

	Event->Damage = static_cast<int32>(TotalDamage - InOutState.RaidState.AccumulatedDamage);

	InOutState.RaidState.AccumulatedDamage = TotalDamage;

	InOutState.RaidState.RaidSupportSkillStates.RemoveAll([](const FCCRaidSkillState& State)
	{
		return State.bIsUsed;
	});

	if (InOutState.RaidState.RaidSupportSkillStates.Num() > 0 || InOutState.RaidState.UsedSupportSkills.Num() > 0)
	{
		ACTION_DISPATCH_RaidSetSkills(InOutState.RaidState.RaidSupportSkillStates, InOutState.RaidState.UsedSupportSkills);
	}

	InOutState.RaidState.UsedSupportSkills.Reset();
	InOutState.RaidState.UsedTurnSkillInfos.Reset();

	TArray<FRaidUserCharacterInfo> UserCharInfos;
	for (const FCCUnitId& IdItor : InOutState.UnitsState.GetAllyUnits())
	{
		FCCUnitState& ItorUnitState = InOutState.UnitsState.FindUnitState(IdItor);

		FRaidUserCharacterInfo UserCharInfo;
		UserCharInfo.CharacterId = InOutState.UnitsState.GetCharacterId(IdItor);
		UserCharInfo.bPlaying = true;
		UserCharInfo.Health = ItorUnitState.Health;
		UserCharInfo.MaxHealth = ItorUnitState.GetAttributeValue(EUnitAttribute::MaxHealth);
		switch (ItorUnitState.Category)
		{
			case EAttributeCategory::FriendJoker:
			case EAttributeCategory::RecommendJoker:
			case EAttributeCategory::SystemJoker:
				UserCharInfo.bJoker = true;
				break;
			default:
				UserCharInfo.bJoker = false;
		}
		UserCharInfos.Add(UserCharInfo);
	}

	if (UserCharInfos.Num() > 0)
	{
		ACTION_DISPATCH_RaidCharInfos(UserCharInfos);
	}

	Context.OnEvent.Broadcast(Event);
}

void _UpdateFactionSubParty(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCFaction Faction)
{
	TArray<int32> EmptySlots = InOutState.UnitsState.GetEmptySlots(Faction);
	for (int32 Slot : EmptySlots)
	{
		int Index = 0;
		for (const FCCCombatSeedUnit& Sub : InOutState.CombatSeed.SubUnits)
		{
			if (Sub.Faction != Faction)
			{
				continue;
			}

			if (Index >= InOutState.SpawnedSubUnitCount[(int32)Faction])
			{
				Q6JsonLog(Display, "_ReqSpawnSubUnit", \
					Q6KV("spawn unit type", Sub.UnitType), \
					Q6KV("slot", Slot));

				FCCSpawnUnitParam SpawnSubUnit;
				UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(Sub, &SpawnSubUnit, ESpawnReason::SubParty, Slot, 0, InOutState.WipeoutContinueHealthPermil, 0);

				const FCCUnitState& CrossFiredUnit = _FindCrossFireUnit(InOutState, Faction, Slot);

				_SpawnUnit(Context, InOutState, SpawnSubUnit, CrossFiredUnit.UnitId);

				++InOutState.SpawnedSubUnitCount[(int32)Faction];
				break;
			}

			++Index;
		}
	}
}

void _UpdateSubParty(const FActionContext& Context, FCCCombatCubeState& InOutState)
{
	_UpdateFactionSubParty(Context, InOutState, ECCFaction::Ally);
	_UpdateFactionSubParty(Context, InOutState, ECCFaction::Enemy);
}

static void _ChangePhase(const FActionContext& Context, FCCCombatCubeState& InOutState, ECCTurnPhase NewPhase)
{
	if (NewPhase == ECCTurnPhase::Prepare)
	{
		_UpdateSubParty(Context, InOutState);
	}

	InOutState.TurnState.CurrentPhase = NewPhase;

	if (NewPhase != ECCTurnPhase::ChangeCombatMultiSide)
	{
		static_assert(static_cast<int32>(ECCFaction::Max) == 2, "EntryAliveUnitCount should be initialized.");
		InOutState.UnitsState.EntryAliveUnitCount[(int32)ECCFaction::Ally] = InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally).Num();
		InOutState.UnitsState.EntryAliveUnitCount[(int32)ECCFaction::Enemy] = InOutState.UnitsState.GetAliveUnits(ECCFaction::Enemy).Num();
	}

	if (NewPhase == ECCTurnPhase::Prepare)
	{
		_ShuffleSkills(Context, InOutState); // should invoke when TrunCount == 0.
		_SelectRandomTurnSkills(Context, InOutState); // should invoke when LiveTrunCount == 0.
		++InOutState.TurnState.TurnCount;
		for (FCCUnitState* U : InOutState.UnitsState.GetAliveUnits(ECCFaction::Max))
		{
			++U->LiveTurnCount;
		}

		_FlushUnitSelectedPatternUltimate(InOutState);
		_FlushUnitCoolDown(InOutState);
		_FlushUnitWaitDown(InOutState);

		UCCStartTurnEvent* NewTurnEvent = NewObject<UCCStartTurnEvent>();
		NewTurnEvent->TurnCount = InOutState.TurnState.TurnCount;
		NewTurnEvent->UnitStates = InOutState.UnitsState.Units;
		NewTurnEvent->MasterStates = InOutState.UnitsState.Masters;
		NewTurnEvent->CombatMultiSideTurnCount = InOutState.TurnState.CombatMultiSideTurnCount;
		Context.OnEvent.Broadcast(NewTurnEvent);

		if (InOutState.CombatSeed.Content == EContentType::Raid)
		{
			InOutState.RaidState.bRaidTurnSkillArrived = false;
		}
	}

	if (NewPhase == ECCTurnPhase::TurnSkill)
	{
		_PickVersaCharacter(Context, InOutState);
	}

	UCCStartPhaseEvent* Event = NewObject<UCCStartPhaseEvent>();
	Event->Phase = NewPhase;
	Context.OnEvent.Broadcast(Event);

	_ApplySelfHeal(Context, InOutState, NewPhase, ECCFaction::Enemy);
	_ApplyBuffHeal(Context, InOutState, NewPhase, ECCFaction::Enemy);
	_ApplyBuffDamage(Context, InOutState, NewPhase, ECCFaction::Enemy);
	_ApplySelfHeal(Context, InOutState, NewPhase, ECCFaction::Ally);
	_ApplyBuffHeal(Context, InOutState, NewPhase, ECCFaction::Ally);
	_ApplyBuffDamage(Context, InOutState, NewPhase, ECCFaction::Ally);

	if (NewPhase == ECCTurnPhase::Prepare)
	{
		for (FCCUnitState* U : InOutState.UnitsState.GetAliveUnits(ECCFaction::Max))
		{
			_ReadyMomentSkill(InOutState, *U, ESkillCategory::TurnBegin, EMoment::AtTurnBegin, CCUnitIdInvalid);
		}
		_ApplyMomentSkills(Context, InOutState, EMoment::AtTurnBegin);

		_FlushUnitBuffEffect(Context, InOutState);
		_ApplyMomentSkills(Context, InOutState, EMoment::AtBuffExpire);

		_ApplyMomentSkills(Context, InOutState, EMoment::AtFirstSpawn);
	}
	_ApplyMomentSkills(Context, InOutState, EMoment::AtSpawn);

	if (NewPhase == ECCTurnPhase::OppAttack
		&& InOutState.CombatSeed.Content == EContentType::Raid)
	{
		SendRaidInfoToRaidServer(Context, InOutState);
	}

	if (NewPhase != ECCTurnPhase::ChangeCombatMultiSide)
	{
		_FlushPhaseRelatedStuffsAll(Context, InOutState);

		_SelectPatternUltimate(Context, InOutState);
	}
}

static bool _IsBonusWave(const FCMSWaveRow* WaveRow)
{
	return WaveRow->AppearanceRatio < 1000;
}

static void _ChangeWave(const FActionContext& Context, FCCCombatCubeState& InOutState, int32 WaveIndex)
{
	InOutState.TurnState.CurrentWaveIndex = WaveIndex;

	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(InOutState.CombatSeed.SagaType, InOutState.TurnState.CurrentWaveIndex);
	if (!WaveRow)
	{
		Q6JsonLogSunny(Error, "Critical!! No Wave info", Q6KV("SagaType", InOutState.CombatSeed.SagaType), Q6KV("Wave", InOutState.TurnState.CurrentWaveIndex));
		return;
	}

	if (!_IsBonusWave(WaveRow))
	{
		++InOutState.TurnState.WaveCount;
	}

	int32 NumSlots = 0;
	NumSlots = ((WaveRow->Spawns01[0] != UnitTypeInvalid.x) || (WaveRow->Spawns01.Num() > 1)) ? NumSlots + 1 : NumSlots;
	NumSlots = ((WaveRow->Spawns02[0] != UnitTypeInvalid.x) || (WaveRow->Spawns02.Num() > 1)) ? NumSlots + 1 : NumSlots;
	NumSlots = ((WaveRow->Spawns03[0] != UnitTypeInvalid.x) || (WaveRow->Spawns03.Num() > 1)) ? NumSlots + 1 : NumSlots;
	InOutState.TurnState.WaveEnemyNumSlots = NumSlots;

	UCCStartWaveEvent* NewWaveEvent = NewObject<UCCStartWaveEvent>();
	NewWaveEvent->WaveCount = InOutState.TurnState.WaveCount;
	NewWaveEvent->WaveIndex = InOutState.TurnState.CurrentWaveIndex;
	NewWaveEvent->WaveEnemyNumSlots = InOutState.TurnState.WaveEnemyNumSlots;
	NewWaveEvent->FirstWaveIndex = InOutState.CombatSeed.Seed.FirstWaveIndex;
	Context.OnEvent.Broadcast(NewWaveEvent);

	_DespawnOldWaveMonsters(Context, InOutState);

	if (!InOutState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide || !InOutState.CombatSeed.CombatMultiSideInfo.bIsOfflineMode)
	{
		_SpawnWaveMonsters(Context, InOutState, WaveRow, InOutState.TurnState.CurrentWaveIndex);
	}
	else
	{
		// pawn - spawn offline enemies
		_SpawnCombatMultiSideMonsters(Context, InOutState, true);
	}

	_ChangePhase(Context, InOutState, ECCTurnPhase::Prepare);

	InOutState.bInCombat = true;
}

static void InitRaidCombatCube(FCCCombatCubeState& InOutState)
{
	InOutState.RaidState.bRaidTurnSkillArrived = false;
	InOutState.RaidState.AccumulatedDamage = 0;
}

static void _InitCombatMultiSideCombatCube(FCCCombatCubeState& InOutState)
{
	// rounding wave numbers
	const FCMSSagaRow& Row = GetCMS()->GetSagaRowOrDummy(InOutState.CombatSeed.SagaType);
	const int32 WaveNum = (Row.GetWave().Num() + 1) / 2;

	InOutState.CombatSeed.Seed.FirstWaveIndex = 0;
	InOutState.CombatSeed.Seed.LastWaveIndex = WaveNum - 1;
	InOutState.CombatSeed.Seed.TotalWaveNum = WaveNum;
	InOutState.CombatSeed.Seed.AppearanceWave.Init(true, WaveNum);

	for (FCCCombatSeedUnit& SubUnit : InOutState.CombatSeed.SubUnits)
	{
		SubUnit.CombatMultiSide = ECombatMultiSide::Sub;
	}

	InOutState.CombatSeed.Units.Append(InOutState.CombatSeed.SubUnits);
	InOutState.CombatSeed.SubUnits.Empty();

	InOutState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide = true;

	// rank bonus category
	FEventContentType EventContentType = GetCMS()->GetEventContentType(InOutState.CombatSeed.SagaType);
	const FCMSEventContentMultiSideBattleRow* EventContentMultiSideBattleRow = GetCMS()->GetEventContentMultiSideBattleRow(EventContentType);
	InOutState.CombatSeed.CombatMultiSideInfo.RankBonusCategory = EventContentMultiSideBattleRow->RankBonus;
}

void FCCInitCombatCubeAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	InOutState.CombatSeed = Seed;
	InOutState.UnitsState.NextUnitId = FCCUnitId(1);
	InOutState.UnitsState.Units.Empty();
	InOutState.TurnState.PlayerTargetUnitId = CCUnitIdInvalid;
	InOutState.Result = ECCResult::Unknown;
	InOutState.bInCombat = false;
	InOutState.GameFlags.SetNumZeroed((int32)EGameFlags::Max);
	InOutState.GemWipeoutContinueCount = 0;
	InOutState.WipeoutContinueHealthPermil = 1000;
	InOutState.SpawnedSubUnitCount[(int32)ECCFaction::Ally] = 0;
	InOutState.SpawnedSubUnitCount[(int32)ECCFaction::Enemy] = 0;
	InOutState.TurnState.WaveCount = 0;
	InOutState.TurnState.TurnCount = 0;
	InOutState.TurnState.CombatMultiSideTurnCount = CombatCubeConst::Q6_FIRST_TURN;

	if (InOutState.CombatSeed.Content == EContentType::Raid)
	{
		InitRaidCombatCube(InOutState);
	}
	else if (InOutState.CombatSeed.Content == EContentType::MultiSideBattle)
	{
		_InitCombatMultiSideCombatCube(InOutState);
	}

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Seed.SagaType);

	GetCMS()->SetBonusMonsterInfo(SagaRow, InOutState.CombatSeed.Seed.BonusMonster);

	TArray<const FCMSWaveRow*> WaveRows = SagaRow.GetWave();
	if (WaveRows.Num() == 0)
	{
		Q6JsonLogSunny(Warning, "No wave info for saga", Q6KV("SagaType", SagaRow.CmsType()));
		return;
	}

	_InitMasters(Context, InOutState);

	InOutState.UnitsState.InitClearUnits(SagaRow);

	// start game
	UCCStartGameEvent* NewGameEvent = NewObject<UCCStartGameEvent>();
	NewGameEvent->CombatSeed = InOutState.CombatSeed;
	NewGameEvent->MasterStates.SetNum((int32)ECCFaction::Max);
	NewGameEvent->MasterStates[(int32)ECCFaction::Ally] = InOutState.UnitsState.Masters[(int32)ECCFaction::Ally];
	NewGameEvent->MasterStates[(int32)ECCFaction::Enemy] = InOutState.UnitsState.Masters[(int32)ECCFaction::Enemy];
	NewGameEvent->TotalWaveNum = InOutState.CombatSeed.Seed.TotalWaveNum;
	Context.OnEvent.Broadcast(NewGameEvent);

	int32 UnitCount = InOutState.CombatSeed.Units.Num();
	int32 SlotCount = (UnitCount < CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT) ? UnitCount : CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT;
	for (int SlotIndex = 1; SlotIndex <= SlotCount; ++SlotIndex)
	{
		const FCCCombatSeedUnit& SeedUnit = InOutState.CombatSeed.Units[SlotIndex - 1];
		if (SeedUnit.Faction != ECCFaction::Ally)
		{
			Q6JsonLogSunny(Error, "CombatSeed ally units broken");
			return;
		}

		FCCSpawnUnitParam Params;
		UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(SeedUnit, &Params, ESpawnReason::Init, SlotIndex, 0, 1000, 0);

		_SpawnUnit(Context, InOutState, Params);
	}

	_ChangeWave(Context, InOutState, InOutState.CombatSeed.Seed.FirstWaveIndex);

	if (InOutState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		// below variables of turn state only use in combat multi side mode
		InOutState.TurnState.OldCombatMultiSideWaveIndex = InOutState.CombatSeed.Seed.FirstWaveIndex;
		InOutState.TurnState.OldCombatMultiSidePlayerTargetUnitId = CCUnitIdInvalid;
	}
}

void FCCStartWaveAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	_ChangeWave(Context, InOutState, WaveIndex);
}

void FCCPassPhaseAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	if (InOutState.TurnState.CurrentPhase == ECCTurnPhase::TurnSkill)
	{
		if (InOutState.CombatSeed.Content == EContentType::Raid)
		{
			if (InOutState.RaidState.bRaidTurnSkillArrived
				|| InOutState.TurnState.TurnCount <= CombatCubeConst::Q6_FIRST_TURN)
			{
				_ChangePhase(Context, InOutState, ECCTurnPhase::Attack);
			}
			else
			{
				Q6JsonLogGenie(Display, "raidturnskill has not arrived yet");
			}
		}
		else
		{
			_ChangePhase(Context, InOutState, ECCTurnPhase::Attack);
		}
	}
	else
	{
		_ReportError(Context, true, ECCErrorCode::PassPhaseOnlyInAttack);
	}
}

void FCCSelectTargetAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitId OldTargetUnitId = InOutState.TurnState.PlayerTargetUnitId;
	if (OldTargetUnitId == TargetUnitId)
	{
		return;
	}

	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(TargetUnitId);
	if (TargetUnit.IsDead())
	{
		return;
	}

	InOutState.TurnState.PlayerTargetUnitId = TargetUnitId;

	UCCTargetSelectedEvent* TargetSelectedEvent = NewObject<UCCTargetSelectedEvent>();
	TargetSelectedEvent->UnitId = InOutState.TurnState.PlayerTargetUnitId;
	TargetSelectedEvent->OldUnitId = OldTargetUnitId;
	Context.OnEvent.Broadcast(TargetSelectedEvent);
}

static bool CanAttackFactionFromPhase(ECCTurnPhase InPhase, ECCFaction InFaction)
{
	switch (InPhase)
	{
	case ECCTurnPhase::Prepare:
		return true;

	case ECCTurnPhase::TurnSkill:
	case ECCTurnPhase::Attack:
		if (InFaction == ECCFaction::Ally)
		{
			return true;
		}
		return false;

	case ECCTurnPhase::OppTurnSkill:
	case ECCTurnPhase::OppAttack:
		if (InFaction == ECCFaction::Enemy)
		{
			return true;
		}
		return false;

	default:
		ensure(0);
		return false;
	}
}

void FCCUseSkillAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	if (TurnCount != 0
		&& TurnCount != InOutState.TurnState.TurnCount)
	{
		return;
	}

	FCCUnitState& Unit = InOutState.UnitsState.FindUnitState(UnitId);

	if (Unit.GetCrowdControlState(GetCMS(), ECrowdControl::Stun) > 0)
	{
		_ReportError(Context, IsPlayerUseSkill, ECCErrorCode::UseSkillOnStun);
		return;
	}

	if (!CanAttackFactionFromPhase(InOutState.TurnState.CurrentPhase, Unit.Faction))
	{
		_ReportError(Context, IsPlayerUseSkill, ECCErrorCode::UseSkillInAttackPhase);
		return;
	}

	FCCSkillState* SkillState = Unit.GetSkillState(SkillId);
	if (!SkillState)
	{
		return;
	}

	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillState->SkillType);
	if (Unit.GetCrowdControlState(GetCMS(), ECrowdControl::Silence) > 0
		&& (SkillRow.SkillCategory == ESkillCategory::Ultimate
			|| SkillRow.SkillCategory == ESkillCategory::Support
			|| SkillRow.SkillCategory == ESkillCategory::TurnBegin))
	{
		_ReportError(Context, IsPlayerUseSkill, ECCErrorCode::UseSkillOnSilence);
		return;
	}

	FCCUnitId TargetUnitId = CCUnitIdInvalid;
	if (SkillRow.Target == ETargetType::HostileSingle || SkillRow.Target == ETargetType::HostileAll)
	{
		const FCCUnitId CurrentTargetUnitId = InOutState.TurnState.PlayerTargetUnitId;

		for (const FCCUnitId& IdItor : InOutState.UnitsState.GetAllyUnits())
		{
			if (UnitId != IdItor)
			{
				continue;
			}

			FCCUnitState& ItorUnitState = InOutState.UnitsState.FindUnitState(IdItor);
			FCCUnitId NewTargetUnitID = FCCUnitId(ItorUnitState.GetCrowdControlState(GetCMS(), ECrowdControl::Provoke));

			if (NewTargetUnitID == CCUnitIdInvalid)
			{
				break;
			}

			if (CurrentTargetUnitId != NewTargetUnitID)
			{
				Q6JsonLogGunny(Display, "Unit was provoked by", Q6KV("UnitId", ItorUnitState.UnitId));

				if (SkillRow.SkillCategory == ESkillCategory::TurnBegin)
				{
					UCCSkillFailedEvent* SkillFaildEvent = NewObject<UCCSkillFailedEvent>();
					SkillFaildEvent->UnitId = UnitId;
					SkillFaildEvent->SkillType = SkillRow.Type;

					FApplyTagFailedInfo FailedInfo;
					FailedInfo.Reason = EApplyTagFailedReason::ApplyTagNotEquals;
					FailedInfo.ReasonTag = EApplyTag::Provoke;

					SkillFaildEvent->FailedInfo = FailedInfo;
					SkillFaildEvent->IsBlocking = false;
					Context.OnEvent.Broadcast(SkillFaildEvent);
					return;
				}
				else
				{
					TargetUnitId = NewTargetUnitID;
					break;
				}
			}
		}
	}

	if (Unit.Faction == ECCFaction::Enemy && PreferTarget != EPreferTarget::None)
	{
		TargetUnitId = GetPreferTargetId(InOutState, PreferTarget);
	}

	UseSkill(Context, InOutState, SkillId, UnitId, TargetUnitId, SkillRow.SkillCategory, EMoment::None, IsPlayerUseSkill, IsPattern);
}

FCCUnitId FCCUseSkillAction::GetPreferTargetId(const FCCCombatCubeState& InOutState, EPreferTarget InPreferTarget) const
{
	TArray<const FCCUnitState*> Candidates = InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally);
	switch (InPreferTarget)
	{
	case EPreferTarget::HPHigh:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.Health > C2.Health)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::HPLow:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.Health < C2.Health)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::AtkHigh:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			int32 Atk1 = (C1.GetAttributeValue(EUnitAttribute::Atk) + C1.GetAttributeValue(EUnitAttribute::AtkVary)) * ((1 + C1.GetAttributeValue(EUnitAttribute::AtkVaryper)) / 1000);
			int32 Atk2 = (C2.GetAttributeValue(EUnitAttribute::Atk) + C2.GetAttributeValue(EUnitAttribute::AtkVary)) * ((1 + C2.GetAttributeValue(EUnitAttribute::AtkVaryper)) / 1000);
			if (Atk1 > Atk2)
			{
				return true;
			}
			return false;
		});
		break;
	case EPreferTarget::AtkLow:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			int32 Atk1 = (C1.GetAttributeValue(EUnitAttribute::Atk) + C1.GetAttributeValue(EUnitAttribute::AtkVary)) * ((1 + C1.GetAttributeValue(EUnitAttribute::AtkVaryper)) / 1000);
			int32 Atk2 = (C2.GetAttributeValue(EUnitAttribute::Atk) + C2.GetAttributeValue(EUnitAttribute::AtkVary)) * ((1 + C2.GetAttributeValue(EUnitAttribute::AtkVaryper)) / 1000);
			if (Atk1 < Atk2)
			{
				return true;
			}
			return false;
		});
		break;
	case EPreferTarget::DefHigh:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			int32 Def1 = (C1.GetAttributeValue(EUnitAttribute::Def) + C1.GetAttributeValue(EUnitAttribute::DefVary)) * ((1 + C1.GetAttributeValue(EUnitAttribute::DefVaryper)) / 1000);
			int32 Def2 = (C2.GetAttributeValue(EUnitAttribute::Def) + C2.GetAttributeValue(EUnitAttribute::DefVary)) * ((1 + C2.GetAttributeValue(EUnitAttribute::DefVaryper)) / 1000);
			if (Def1 > Def2)
			{
				return true;
			}
			return false;
		});
		break;
	case EPreferTarget::DefLow:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			int32 Def1 = (C1.GetAttributeValue(EUnitAttribute::Def) + C1.GetAttributeValue(EUnitAttribute::DefVary)) * ((1 + C1.GetAttributeValue(EUnitAttribute::DefVaryper)) / 1000);
			int32 Def2 = (C2.GetAttributeValue(EUnitAttribute::Def) + C2.GetAttributeValue(EUnitAttribute::DefVary)) * ((1 + C2.GetAttributeValue(EUnitAttribute::DefVaryper)) / 1000);
			if (Def1 < Def2)
			{
				return true;
			}
			return false;
		});
		break;
	case EPreferTarget::UAHigh:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.UA > C2.UA)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::UALow:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.UA < C2.UA)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::SAHigh:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.SA > C2.SA)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::SALow:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.SA < C2.SA)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::OverKillHigh:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.OverKill > C2.OverKill)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::OverKillLow:
		Candidates.StableSort([](const FCCUnitState& C1, const FCCUnitState& C2)
		{
			if (C1.OverKill < C2.OverKill)
			{
				return true;
			}
			return false;
		});
	break;
	case EPreferTarget::Follower:
		return InOutState.LastEnemyTarget;
		break;
	case EPreferTarget::Geek:
		for (const FCCUnitState* U : Candidates)
		{
			if (U->UnitId != InOutState.LastEnemyTarget)
			{
				return U->UnitId;
			}
		}
		break;
	default:
		break;
	}

	return Candidates[0]->UnitId;
}

void FCCUseArtifactAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	if (!InOutState.CombatSeed.Seed.ArtifactAvailable.IsValidIndex(Index))
	{
		Q6JsonLog(Warning, "artifact wrong index", Q6KV("unit id", TargetUnitId), Q6KV("index", Index));
		return;
	}

	if (!InOutState.CombatSeed.Seed.ArtifactAvailable[Index].Available)
	{
		Q6JsonLog(Warning, "artifact disable index", Q6KV("unit id", TargetUnitId), Q6KV("index", Index));
		return;
	}

	if (Index == CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX)
	{
		Q6JsonLog(Warning, "wipieout continue artifact should use FCCWipeoutContinue.");
		return;
	}

	int32 ArtifactType = SystemConstHelper::GetArtifactSkillType(Index);
	if (ArtifactType == 0)
	{
		return;
	}

	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(TargetUnitId);
	FCCUnitState& Master = InOutState.UnitsState.Masters[(int32)TargetUnit.Faction];

	FCCSkillId ArtifactId = Master.GetArtifactId(ArtifactType);
	if (ArtifactId == CCSkillIdInvalid)
	{
		Q6JsonLog(Warning, "artifact master not have type", Q6KV("unit id", TargetUnitId), Q6KV("type", ArtifactType));
		return;
	}

	FCCSkillState* SkillState = Master.GetSkillState(ArtifactId);
	if (!SkillState)
	{
		Q6JsonLog(Warning, "artifact master not have skill", Q6KV("unit id", TargetUnitId), Q6KV("type", ArtifactType));
		return;
	}

	const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(SkillState->SkillType);
	if (InSkillRow.SkillCategory != ESkillCategory::Artifact)
	{
		return;
	}

	InOutState.CombatSeed.Seed.ArtifactAvailable[Index].Available = false;

	UseSkill(Context, InOutState, ArtifactId, Master.UnitId, TargetUnitId, ESkillCategory::Artifact, EMoment::None, false, false);
}

void FCCWipeoutContinue::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCSkillState* SkillState = GetSkill(InOutState);
	if (!SkillState)
	{
		Q6JsonLog(Error, "can not found wipeout continue skill");
		return;
	}

	const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(SkillState->SkillType);
	if (InSkillRow.SkillCategory != ESkillCategory::Artifact)
	{
		Q6JsonLog(Error, "wipeout continue skill category should be Artifact.", Q6KV("skill type", SkillState->SkillType));
		return;
	}

	Q6JsonLog(Display, "use wipeout continue");

	if (!IsGemContinue)
	{
		InOutState.CombatSeed.Seed.ArtifactAvailable[CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX].Available = false;
	}
	else
	{
		const UWorldUser& User = GetUser();
		int32 FreeGem = User.GetFreeGem();
		int32 PaidGem = User.GetPaidGem();

		int32 Cost = InOutState.GemWipeoutContinueCount * SystemConst::Q6_REBIRTH_GEM_COST;
		int32 OnetimeCost = SystemConst::Q6_REBIRTH_GEM_COST;
		if (ResurrectionCount == 0)
		{
			Cost = FMath::Max(0, InOutState.GemWipeoutContinueCount - 1) * SystemConst::Q6_REBIRTH_GEM_COST;
			if (InOutState.GemWipeoutContinueCount == 0)
			{
				OnetimeCost = 0;
			}
		}

		if (FreeGem + PaidGem < OnetimeCost)
		{
			Q6JsonLog(Error, "wipeout continue not enought gems.", Q6KV("free", FreeGem), Q6KV("paid", PaidGem));
			return;
		}

		++InOutState.GemWipeoutContinueCount;

		FCombatSeed& Seed = InOutState.CombatSeed.Seed;
		int32 Remainder = Seed.FreeGem - Cost;
		if (Remainder >= 0)
		{
			FreeGem = Remainder;
		}
		else
		{
			FreeGem = 0;
			PaidGem = PaidGem + Remainder;
		}

		ACTION_DISPATCH_GemConsume(FreeGem, PaidGem);
	}

	InOutState.bInCombat = true;
	InOutState.WipeoutContinueHealthPermil = GetHealthPermil(InOutState);
	InOutState.SpawnedSubUnitCount[(int32)ECCFaction::Ally] = 0;
	InOutState.SpawnedSubUnitCount[(int32)ECCFaction::Enemy] = 0;

	for (int i = 0; i < InOutState.CombatSeed.Units.Num(); )
	{
		FCCCombatSeedUnit& Unit = InOutState.CombatSeed.Units[i];
		if (Unit.Faction != ECCFaction::Ally)
		{
			continue;
		}

		int32 Slot = i + 1;
		FCCSpawnUnitParam SpawnUnit;
		UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(Unit, &SpawnUnit,
			ESpawnReason::WipeoutContinue,
			Slot, 1, InOutState.WipeoutContinueHealthPermil, 0);

		const FCCUnitState& CrossFiredUnit = _FindCrossFireUnit(InOutState, ECCFaction::Ally, Slot);

		_SpawnUnit(Context, InOutState, SpawnUnit, CrossFiredUnit.UnitId);

		++i;
		if (i >= CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
		{
			break;
		}
	}

	FCCUnitId AnyAllyUnit = CCUnitIdInvalid;
	for (FCCUnitId& Id : InOutState.UnitsState.GetAllyUnits())
	{
		const FCCUnitState& State = InOutState.UnitsState.FindUnitState(Id);
		if (State.IsDead())
		{
			continue;
		}

		AnyAllyUnit = State.UnitId;
		break;
	}

	_ChangePhase(Context, InOutState, ECCTurnPhase::Prepare);

	FCCUnitState& Master = InOutState.UnitsState.Masters[(int32)ECCFaction::Ally];
	UseSkill(Context, InOutState, SkillState->SkillId, Master.UnitId, AnyAllyUnit, ESkillCategory::Artifact, EMoment::None, false, false);

	if (IsGemContinue)
	{
		_SetSkillTime(Context, InOutState, Master, SkillState->SkillId, 0, 0);
	}
}

FCCSkillState* FCCWipeoutContinue::GetSkill(FCCCombatCubeState& InOutState) const
{
	FCCUnitState& Master = InOutState.UnitsState.Masters[(int32)ECCFaction::Ally];

	if (IsGemContinue)
	{
		for (FCCSkillState* S : Master.GetSkillStates(ESkillCategory::Artifact))
		{
			if (S->SkillType == SystemConst::Q6_GEM_REBIRTH_SKILL_ID)
			{
				return S;
			}
		}
	}
	else
	{
		if (!InOutState.CombatSeed.Seed.ArtifactAvailable.IsValidIndex(CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX))
		{
			Q6JsonLog(Error, "artifact wrong index", Q6KV("index", CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX));
			return nullptr;
		}

		if (!InOutState.CombatSeed.Seed.ArtifactAvailable[CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX].Available)
		{
			Q6JsonLog(Error, "artifact disable index", Q6KV("index", CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX));
			return nullptr;
		}

		for (FCCSkillState* S : Master.GetSkillStates(ESkillCategory::Artifact))
		{
			if (S->SkillType == TempleConst::Q6_ARTIFACT3_SKILL_ID)
			{
				return S;
			}
		}
	}

	return nullptr;
}

int32 FCCWipeoutContinue::GetHealthPermil(FCCCombatCubeState& InOutState) const
{
	if (IsGemContinue)
	{
		return GetCMS()->GetFormulaConstValues(InOutState.SeedUnitCount(ECCFaction::Ally)).GemContinueHealthPermil;
	}
	else
	{
		int32 Level = InOutState.CombatSeed.Seed.ArtifactAvailable[CombatCubeConst::Q6_ARTIFACT_REBIRTH_SKILL_INDEX].Level;
		int32 Min = GetCMS()->GetFormulaConstValues(InOutState.SeedUnitCount(ECCFaction::Ally)).ArtifactContinueHealthPermilMin;
		int32 Max = GetCMS()->GetFormulaConstValues(InOutState.SeedUnitCount(ECCFaction::Ally)).ArtifactContinueHealthPermilMax;
		return (int32)Formula::InterpolatedBySkillLevelOrTier(Level, Min, Max, ESkillCategory::Artifact);
	}
}

void FCCUsePetAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& Master = InOutState.UnitsState.Masters[(int32)ECCFaction::Ally];
	FCCSkillState* SkillState = Master.GetSkillState(SkillId);
	if (!SkillState)
	{
		return;
	}

	const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(SkillState->SkillType);
	if (InSkillRow.SkillCategory != ESkillCategory::Pet)
	{
		return;
	}

	UseSkill(Context, InOutState, SkillId, Master.UnitId, TargetUnitId, ESkillCategory::Pet, EMoment::None, false, false);
}

void FCCUnitRetreatAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& Unit = InOutState.UnitsState.FindUnitState(UnitId);

	Unit.Health = 0;

	UCCDespawnUnitEvent* DespawnEvent = NewObject<UCCDespawnUnitEvent>();
	DespawnEvent->UnitId = UnitId;
	Context.OnEvent.Broadcast(DespawnEvent);

	_ResolveProvokeOnDie(Context, InOutState, UnitId);

	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(Unit.UnitType));
	if (CMSUnitRow.MonsterParts == EMonsterParts::Main)
	{
		for (FCCUnitState* U : InOutState.UnitsState.GetAliveUnits(Unit.Faction))
		{
			if (U->UnitId == Unit.UnitId)
			{
				continue;
			}

			const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(U->UnitType));
			if (UnitRow.MonsterParts != EMonsterParts::Sub)
			{
				continue;
			}

			U->Health = 0;

			UCCDespawnUnitEvent* SubUnitDespawnEvent = NewObject<UCCDespawnUnitEvent>();
			SubUnitDespawnEvent->UnitId = U->UnitId;
			Context.OnEvent.Broadcast(SubUnitDespawnEvent);

			_ResolveProvokeOnDie(Context, InOutState, U->UnitId);
		}
	}
}

void FCCInitMissionAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	const UCMS* CMS = GetCMS();

	FCCMissionState& MissionState = InOutState.MissionState;

	MissionState.WeeklyMissionStates.Empty();
	for (const FMissionType& Type : CombatWeeklyMission)
	{
		const FCMSMissionRow& MissionRow = CMS->GetMissionRowOrDummy(Type);
		if (MissionRow.IsInvalid())
		{
			Q6JsonLogGenie(Error, "no exist mission type", Q6KV("type", Type));
			continue;
		}

		if (!MissionRow.Combat)
		{
			continue;
		}

		FCCWeeklyMissionInfo MissionInfo;
		MissionInfo.Type = Type;
		MissionInfo.Category = MissionRow.Category;

		MissionState.WeeklyMissionStates.Add(MissionInfo);
	}

	MissionState.CharacterMissionStates.Empty();
	for (const FCCCharacterMissionInfo& CharacterMissionInfo : CombatCharacterMission)
	{
		const FCMSCharMissionRow& CharacterMissionRow = CMS->GetCharMissionRowOrDummy(
			CharacterMissionInfo.Type);
		if (CharacterMissionRow.IsInvalid())
		{
			Q6JsonLogGenie(Error, "no exist char mission type", Q6KV("type"
				, CharacterMissionInfo.Type));
			continue;
		}

		if (!CharacterMissionRow.Combat)
		{
			continue;
		}

		MissionState.CharacterMissionStates.Add(CharacterMissionInfo);
	}
}

void FCCUseRaidTurnSkillAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	check(InOutState.TurnState.CurrentPhase == ECCTurnPhase::TurnSkill);
	check(InOutState.CombatSeed.Content == EContentType::Raid);
	check(InOutState.TurnState.TurnCount > CombatCubeConst::Q6_FIRST_TURN);

	for (const FCCRaidSkillState& RaidTurnSkillState : InOutState.RaidState.RaidTurnSkillStates)
	{
		UCCRaidTurnSkillEffectEvent* RaidTurnSkillEffectEvent = NewObject<UCCRaidTurnSkillEffectEvent>();
		RaidTurnSkillEffectEvent->UserName = RaidTurnSkillState.UserName;
		RaidTurnSkillEffectEvent->SkillType = RaidTurnSkillState.SkillState.SkillType;
		RaidTurnSkillEffectEvent->CharacterType = RaidTurnSkillState.CharInfo.Type;
		Context.OnEvent.Broadcast(RaidTurnSkillEffectEvent);

		int32 Slot = RaidTurnSkillState.Slot;
		const FCCUnitState* FoundUnit = InOutState.UnitsState.Units.FindByPredicate([&Slot](const FCCUnitState& Elem)
		{
			return Elem.Slot == Slot
				&& !Elem.IsDead()
				&& Elem.Faction == ECCFaction::Ally;
		});
		if (!FoundUnit)
		{
			for (const FCCUnitState& UnitState : InOutState.UnitsState.Units)
			{
				if (!UnitState.IsDead() && UnitState.Faction == ECCFaction::Ally)
				{
					FoundUnit = &UnitState;
					break;
				}
			}
		}
		if (!FoundUnit)
		{
			UCCSkillFailedEvent* SkillFailedEvent = NewObject<UCCSkillFailedEvent>();
			SkillFailedEvent->SkillType = RaidTurnSkillState.SkillState.SkillType;
			SkillFailedEvent->IsBlocking = true;

			FApplyTagFailedInfo ApplyTagFailedInfo;
			SkillFailedEvent->FailedInfo = ApplyTagFailedInfo;
			Context.OnEvent.Broadcast(SkillFailedEvent);
			continue;
		}

		UseSkill(Context, InOutState, RaidTurnSkillState.SkillState.SkillId,
			FoundUnit->UnitId, CCUnitIdInvalid, ESkillCategory::RaidTurnBegin, EMoment::None, false, false);
		Q6JsonLogGenie(Display, "Use Raid Turn Skill"
			, Q6KV("FCCSkillState", RaidTurnSkillState.SkillState)
			, Q6KV("FCharacterInfo", RaidTurnSkillState.CharInfo)
			, Q6KV("Slot", RaidTurnSkillState.Slot)
			, Q6KV("UserName", RaidTurnSkillState.UserName)
			, Q6KV("UserId", RaidTurnSkillState.UserId)
		);
	}

	UCCRaidTurnSkillFinishedEvent* RaidTurnSkillFinishedEvent = NewObject<UCCRaidTurnSkillFinishedEvent>();
	Context.OnEvent.Broadcast(RaidTurnSkillFinishedEvent);

	InOutState.RaidState.RaidTurnSkillStates.Reset();
}

void FCCChangePhaseTo::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	_ChangePhase(Context, InOutState, ChangePhase);

	AQ6CombatGameMode* GameMode = GetCombatGameMode(UQ6GameInstance::Get());
	GameMode->CombatCube->UpdateFinishCondition(InOutState);
}

void FCCAllyWipeoutAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	InOutState.bInCombat = false;

	UCCAllyWipeoutEvent* Event = NewObject<UCCAllyWipeoutEvent>();
	Context.OnEvent.Broadcast(Event);
}

void FCCEndGameAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	// Raid could send the win result - Win & ( TurnOver | TimeOver | Withdraw )
	// if EndReason is ClearUnits, EnemiesCount may not be zero
	if (Result == ECCResult::Win
		&& InOutState.CombatSeed.Content != EContentType::Raid && EndReason != ECCEndReason::ClearUnits)
	{
		int32 AlliesCount;
		int32 EnemiesCount;
		if (!InOutState.VerifyFinishCondition(AlliesCount, EnemiesCount))
		{
			Q6JsonLog(Error, "end game action wrong codition", Q6KV("AlliesCount", AlliesCount), Q6KV("EnemiesCount", EnemiesCount));
			return;
		}
	}

	if (InOutState.CombatSeed.Content == EContentType::Raid)
	{
		SendRaidInfoToRaidServer(Context, InOutState);
	}
	else if (InOutState.CombatSeed.Content == EContentType::MultiSideBattle && Result == ECCResult::Win)
	{
		_SendCombatMultiSideRankScore(Context, InOutState);
	}

	_EndGame(Context, InOutState, Result, false, EndReason);
}

void FCCCheatSpawnSubUnitAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	_SpawnUnit(Context, InOutState, SpawnUnit);
}

void FCCCheatCreateBuffAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	_CreateBuff(Context, InOutState, UnitId, TargetUnitId, BuffType, Duration, 0, CombatCubeConst::Q6_MAX_SKILL_LEVEL,
		InOutState.TurnState.TurnCount, true, ESkillCategory::TurnBegin, CCSkillIdInvalid);
}

void FCCCheatKillUnitAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	_SetHealth(Context, InOutState, TargetUnit, CCSkillIdInvalid, 0, false, false, nullptr);
}

void FCCCheatRebirthUnitAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	_SetHealth(Context, InOutState, TargetUnit, CCSkillIdInvalid, TargetUnit.GetAttributeValue(EUnitAttribute::MaxHealth), false, false, nullptr);
}

void FCCCheatGameFlagAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	InOutState.SetGameFlag(GameFlag, FlagValue);
}

void FCCCheatUnitAttributeAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	if (IsCheat)
	{
		TargetUnit.UnitAttributes->SetCheatAttributeValue(UnitAttribute, CheatValue);
	}
	else
	{
		TargetUnit.UnitAttributes->RevertCheatAttribute(UnitAttribute);
	}
}

void FCCCheatUAAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	_SetNewUA(Context, TargetUnit, SkillTypeInvalid.x, CheatUA, EPointChangeReason::Cheat);
}

void FCCCheatSAAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	_SetNewSA(Context, TargetUnit, SkillTypeInvalid.x, CheatSA, EPointChangeReason::Cheat);
}

void FCCCheatHealthAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	_SetHealth(Context, InOutState, TargetUnit, CCSkillIdInvalid, CheatHealth, false, false, nullptr);
}

void FCCCheatOverKillAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	FCCUnitState& TargetUnit = InOutState.UnitsState.FindUnitState(UnitId);
	if (!ensure(TargetUnit.UnitId != CCUnitIdInvalid))
	{
		return;
	}

	int32 AddedOverKill = CheatOverKill - TargetUnit.OverKill;
	_SetNewOverKill(Context, TargetUnit, AddedOverKill,
		CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT, EPointChangeReason::Cheat);
}

void FCCCheatDespawnUnitAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	_DespawnUnit(Context, InOutState, UnitId);
}

void FCCCheatEndGameAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	_EndGame(Context, InOutState, Result, false, ECCEndReason::None);
}

void FCCCheatFixSkillNoteAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	for (FCCUnitState* UnitState : InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally))
	{
		if (UnitState->Slot != Slot)
		{
			continue;
		}

		int32 Count = 0;
		for (const FCCSkillState* SkillState : UnitState->GetSkillStates(ESkillCategory::Normal))
		{
			const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(SkillState->SkillType);
			if (SkillRow.SkillNote != Note)
			{
				continue;
			}
			if (Count != Index)
			{
				++Count;
				continue;
			}

			UnitState->CheatFixedNoteSkillId = SkillState->SkillId;
			Q6JsonLog(Warning, "succeeded: fixed skill note", Q6KV("unit type", UnitState->UnitType), Q6KV("skill type", SkillState->SkillType));
			return;
		}
	}

	Q6JsonLog(Warning, "failed: fixed skill note", Q6KV("slot", Slot), Q6KV("note", (int32)Note), Q6KV("index", Index));
}

void FCCCheatSkillNoteShuffleAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	for (FCCUnitState* UnitState : InOutState.UnitsState.GetAliveUnits(ECCFaction::Ally))
	{
		if (UnitState->Slot != Slot)
		{
			continue;
		}

		UnitState->CheatFixedNoteSkillId = CCSkillIdInvalid;
		Q6JsonLog(Warning, "succeeded: shuffle skill note", Q6KV("unit type", UnitState->UnitType));
		return;
	}

	Q6JsonLog(Warning, "failed: shuffle skill note", Q6KV("slot", Slot));
}

void FCCCheatCooldownAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	if (SkillType == SkillTypeInvalid)
	{
		FCCUnitState& ResetCooldownUnit = InOutState.UnitsState.FindUnitState(UnitId);

		for (const FCCSkillState* ItNormal : ResetCooldownUnit.GetSkillStates(ESkillCategory::Normal))
		{
			if (ItNormal->Cooldown > 0)
			{
				_SetCheatCooldown(Context, InOutState, ResetCooldownUnit, ItNormal->SkillId, 0);
			}
		}
		for (const FCCSkillState* ItUltimate : ResetCooldownUnit.GetSkillStates(ESkillCategory::Ultimate))
		{
			if (ItUltimate->Cooldown > 0)
			{
				_SetCheatCooldown(Context, InOutState, ResetCooldownUnit, ItUltimate->SkillId, 0);
			}
		}
		for (const FCCSkillState* ItTurnBegin : ResetCooldownUnit.GetSkillStates(ESkillCategory::TurnBegin))
		{
			if (ItTurnBegin->Cooldown > 0)
			{
				_SetCheatCooldown(Context, InOutState, ResetCooldownUnit, ItTurnBegin->SkillId, 0);
			}
		}
	}
	else
	{
		FCCUnitState& ResetCoolownEnemyUnit = InOutState.UnitsState.FindUnitState(UnitId);

		for (int32 CountIndex = 0; CountIndex < ResetCoolownEnemyUnit.Skills.Num(); ++CountIndex)
		{
			if (ResetCoolownEnemyUnit.Skills[CountIndex].SkillType == SkillType)
			{
				_SetCheatCooldown(Context, InOutState, ResetCoolownEnemyUnit, ResetCoolownEnemyUnit.Skills[CountIndex].SkillId, 0);
				ResetCoolownEnemyUnit.Skills.Swap(0, CountIndex);
				return;
			}
		}
	}
}

FCCSkillState* FCCUnitState::GetSkillState(const FCCSkillId& SkillId)
{
	for (int32 i = 0; i < Skills.Num(); ++i)
	{
		if (Skills[i].SkillId == SkillId)
		{
			return &Skills[i];
		}
	}

	Q6JsonLog(Warning, "unregister skill", Q6KV("unit type", UnitType), Q6KV("unit id", UnitId), Q6KV("skill id", SkillId));
	return nullptr;
}

void FCCUnitState::AddSkillOnAttack(int32 SkillType)
{
	SkillsOnAttack.Add(SkillType);
}

void FCCUnitState::MakeToAttackPass()
{
	SkillsOnAttack.Add(SkillTypeInvalid.x);
}

TArray<FCCSkillState*> FCCUnitState::GetSkillStates(ESkillCategory InCategory)
{
	TArray<FCCSkillState*> Ret;

	for (FCCSkillState& S : Skills)
	{
		if (S.Category != InCategory)
		{
			continue;
		}

		Ret.Add(&S);
	}

	if (Ret.Num() <= 0)
	{
		Q6JsonLog(Warning, "no skill states", Q6KV("unittype", UnitType), Q6KV("category", (int32)InCategory));
	}

	return Ret;
}

TArray<const FCCSkillState*> FCCUnitState::GetSkillStates(ESkillCategory InCategory) const
{
	TArray<const FCCSkillState*> Ret;

	for (const FCCSkillState& S : Skills)
	{
		if (S.Category != InCategory)
		{
			continue;
		}

		Ret.Add(&S);
	}

	if (Ret.Num() <= 0)
	{
		Q6JsonLog(Warning, "no skill states", Q6KV("unittype", UnitType), Q6KV("category", (int32)InCategory));
	}

	return Ret;
}

bool FCCSkillState::IsInCooldown() const
{
	return Cooldown > 0;
}

bool FCCSkillState::IsInWaitdown() const
{
	if (WaitTime > 0 && Waitdown > 0)
	{
		return true;
	}

	return false;
}

UCCUnitAttributes::UCCUnitAttributes()
{
	CachedAttributes.Reset(EUnitAttributeMax);
	CachedAttributes.AddZeroed(EUnitAttributeMax);
	CheatAttributes.Reset(EUnitAttributeMax);
	CheatAttributes.AddZeroed(EUnitAttributeMax);
	bCheatedAttributes.Reset(EUnitAttributeMax);
	bCheatedAttributes.AddZeroed(EUnitAttributeMax);
	PointVaryAttributes.Reset(EUnitAttributeMax);
	PointVaryAttributes.AddZeroed(EUnitAttributeMax);
}

int64 UCCUnitAttributes::GetCachedAttributeValue(EUnitAttribute InAttribute) const
{
	if (!CachedAttributes.IsValidIndex((int32)InAttribute))
	{
		ensure(0);
		return 0;
	}

	return CachedAttributes[(int32)InAttribute];
}

int64 UCCUnitAttributes::GetCheatAttributeValue(EUnitAttribute InAttribute) const
{
	if (!CheatAttributes.IsValidIndex((int32)InAttribute))
	{
		ensure(0);
		return 0;
	}

	return CheatAttributes[(int32)InAttribute];
}

int64 UCCUnitAttributes::GetAttributeValue(EUnitAttribute InAttribute) const
{
	if (IsCheated(InAttribute))
	{
		return GetCheatAttributeValue(InAttribute);
	}

	return GetCachedAttributeValue(InAttribute);
}

TArray<int64>& UCCUnitAttributes::GetPointVaryAttributes()
{
	return PointVaryAttributes;
}

void UCCUnitAttributes::SetCheatAttributeValue(EUnitAttribute InAttribute, int64 InValue)
{
	if (!CheatAttributes.IsValidIndex((int32)InAttribute))
	{
		ensure(0);
		return;
	}

	CheatAttributes[(int32)InAttribute] = InValue;
	bCheatedAttributes[(int32)InAttribute] = true;
}

void UCCUnitAttributes::SetPointVaryAttributeValue(EPointVaryConvertType ConvertType, int64 InValue)
{
	EUnitAttribute UnitAttribute;
	if (!GetCMS()->GetUnitAttributeFromPointVaryConvertType(ConvertType, UnitAttribute))
	{
		return;
	}

	if (!PointVaryAttributes.IsValidIndex((int32)UnitAttribute))
	{
		ensure(0);
		return;
	}

	PointVaryAttributes[(int32)UnitAttribute] += InValue;
}

void UCCUnitAttributes::RevertCheatAttribute(EUnitAttribute InAttribute)
{
	if (!bCheatedAttributes.IsValidIndex((int32)InAttribute))
	{
		ensure(0);
		return;
	}

	bCheatedAttributes[(int32)InAttribute] = false;
}

bool UCCUnitAttributes::IsConstAttribute(EUnitAttribute InAttribute) const
{
	switch (InAttribute)
	{
	case EUnitAttribute::MaxHealth:
	case EUnitAttribute::MaxUA:
	case EUnitAttribute::MaxSA:
	case EUnitAttribute::Atk:
	case EUnitAttribute::Def:
	case EUnitAttribute::Criper:
	case EUnitAttribute::HealthRegen:
	case EUnitAttribute::NoteAceBonus:
	case EUnitAttribute::NoteBreakBonus:
	case EUnitAttribute::NoteCloserBonus:
		return true;
	default:
		return false;
	}
}

void UCCUnitAttributes::ClearPointVaryAttributes()
{
	PointVaryAttributes.Reset(EUnitAttributeMax);
	PointVaryAttributes.AddZeroed(EUnitAttributeMax);
}

void UCCUnitAttributes::SetConstAttributeValue(EUnitAttribute InAttribute, int64 InValue)
{
	if (!IsConstAttribute(InAttribute))
	{
		return;
	}

	CachedAttributes[(int32)InAttribute] = InValue;
}

bool UCCUnitAttributes::IsCheated(EUnitAttribute InAttribute) const
{
	if (!bCheatedAttributes.IsValidIndex((int32)InAttribute))
	{
		return false;
	}

	return bCheatedAttributes[(int32)InAttribute];
}

TArray<TPair<int64, int64>> UCCUnitAttributes::UpdateUnitAttributes(const FActionContext& Context, const FCCUnitState& Unit)
{
	TArray<TPair<int64, int64>> UpdatedAttributes;

	TArray<int64, TInlineAllocator<EUnitAttributeMax>> NewCacheAttributes;
	NewCacheAttributes.AddZeroed(EUnitAttributeMax);
	for (const FCCBuffState& IterBuff : Unit.Buffs)
	{
		const FCMSBuffRow& CMSBuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(IterBuff.BuffType));
		const TArray<const FCMSBuffEffectRow*>& Effects = CMSBuffRow.GetBuffEffect();
		for (const FCMSBuffEffectRow* Effect : Effects)
		{
			if (Effect->BuffEffectCategory != EBuffEffectCategory::ModifyUnitAttribute)
			{
				continue;
			}

			const FCMSUnitAttributeRow& InRow = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType(Effect->Param1));

			int64 Amount = (int64)Formula::InterpolatedBySkillLevelOrTier(IterBuff.BuffLevel,
				Effect->Param2Min * IterBuff.Multiple,
				Effect->Param2 * IterBuff.Multiple,
				IterBuff.BornCategory);

			NewCacheAttributes[(int32)InRow.UnitAttribute] += Amount;

			UpdatedAttributes.Add(TPair<int64, int64>((int64)InRow.UnitAttribute, Amount));
		}
	}

	for (int32 i = 0; i < EUnitAttributeMax; ++i)
	{
		NewCacheAttributes[i] += PointVaryAttributes[i];
	}

	for (int32 i = 0; i < EUnitAttributeMax; ++i)
	{
		if (NewCacheAttributes[i] == CachedAttributes[i])
		{
			continue;
		}

		if (IsConstAttribute((EUnitAttribute)i))
		{
			continue;
		}

		CachedAttributes[i] = NewCacheAttributes[i];
	}

	return UpdatedAttributes;
}

bool FCCUnitState::IsInCooldown(const FActionContext& Context, const FCCSkillId& SkillId)
{
	const FCCSkillState* SkillState = GetSkillState(SkillId);
	if (!SkillState)
	{
		return true;
	}

	return SkillState->IsInCooldown();
}

bool FCCUnitState::IsDead() const
{
	return Health <= 0;
}

bool FCCUnitState::CanUseSkillOnCurrentPhase(const FCMSSkillRow& SkillRow, ECCTurnPhase InCurrentPhase) const
{
	switch (SkillRow.SkillCategory)
	{
	case ESkillCategory::Moment: // always ok?
		return true;

	case ESkillCategory::Normal:
	case ESkillCategory::Support:
	case ESkillCategory::Ultimate:
	case ESkillCategory::Versa:
	case ESkillCategory::Chain:
	case ESkillCategory::Double:
		switch (InCurrentPhase)
		{
		case ECCTurnPhase::Attack:
		case ECCTurnPhase::OppAttack:
			return true;
		default:
			return false;
		}
	case ESkillCategory::Pet:
		switch (InCurrentPhase)
		{
		case ECCTurnPhase::TurnSkill:
		case ECCTurnPhase::Attack:
			return true;
		default:
			return false;
		}
	case ESkillCategory::TurnBegin:
	case ESkillCategory::Artifact:
		switch (InCurrentPhase)
		{
		case ECCTurnPhase::Prepare:
		case ECCTurnPhase::TurnSkill:
		case ECCTurnPhase::OppTurnSkill:
			return true;
		default:
			return false;
		}
	default:
		return false;
	}
}

int64 FCCUnitState::GetAttributeValue(EUnitAttribute InAttribute) const
{
	return UnitAttributes->GetAttributeValue(InAttribute);
}

int32 FCCUnitState::GetCrowdControlState(const UCMS* CMS, ECrowdControl Control) const
{
	ensure(Control != ECrowdControl::ExtraDamage);

	int32 Out = 0;

	for (const FCCBuffState& Itor : Buffs)
	{
		Out += HasCrowdControlState(Itor, Control);
		if (Control == ECrowdControl::Provoke
			&& Out != 0)
		{
			return Out;
		}
	}

	return Out;
}

int32 FCCUnitState::GetExtraDMGper(const FActionContext& Context, const FCCCombatCubeState& InOutState, const UCMS* CMS,
	FCCUnitState& TargetUnit, int32 InLevelOrTier, ESkillCategory BornCategory)
{
	int32 ExtraDMGper = 0;

	for (const FCCBuffState& Itor : Buffs)
	{
		for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(Itor, ECrowdControl::ExtraDamage))
		{
			const FCMSApplyTagRow& TagRow = CMS->GetApplyTagRowOrDummy(FApplyTagType(Effect->Param2));
			if (TagRow.IsInvalid())
			{
				continue;
			}

			if (!_ApplyTagExtraDamage(Context, InOutState, TagRow.ApplyTag, *this, TargetUnit, InLevelOrTier, BornCategory))
			{
				continue;
			}

			ExtraDMGper += Formula::InterpolatedBySkillLevelOrTier(Itor.BuffLevel, Effect->Param3Min, Effect->Param3, Itor.BornCategory);
		}
	}

	return ExtraDMGper;
}

const FCCSkillState* FCCUnitState::GetNormalSkillByTurn(int32 TurnCount) const
{
	TArray<const FCCSkillState*> Normals = GetSkillStates(ESkillCategory::Normal);
	if (CheatFixedNoteSkillId != CCSkillIdInvalid)
	{
		for (const FCCSkillState* S : Normals)
		{
			if (S->SkillId == CheatFixedNoteSkillId)
			{
				Q6JsonLog(Warning, "cheat fixed skill note", Q6KV("unit type", UnitType), Q6KV("skill type", S->SkillType));
				return S;
			}
		}
	}

	int32 Num = Normals.Num();
	if (Num <= 0)
	{
		return nullptr;
	}
	int32 Index = TurnCount % Num;

	return Normals[Index];
}

const FCCSkillState* FCCUnitState::GetUltimateSkillByTurn(int32 TurnCount) const
{
	TArray<const FCCSkillState*> Ultimates = GetSkillStates(ESkillCategory::Ultimate);

	int32 Num = Ultimates.Num();
	if (Num <= 0)
	{
		return nullptr;
	}
	int32 Index = TurnCount % Num;

	return Ultimates[Index];
}

FCCSkillId FCCUnitState::GetVersaSkillId(int32 SkillType) const
{
	for (const FCCSkillState& S : Skills)
	{
		if (S.SkillType != SkillType)
		{
			continue;
		}

		const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(S.SkillType);
		if (InSkillRow.SkillCategory != ESkillCategory::Versa)
		{
			Q6JsonLog(Warning, "wrong versa skill type", Q6KV("type", SkillType));
			return CCSkillIdInvalid;
		}

		return S.SkillId;
	}

	return CCSkillIdInvalid;
}

FCCSkillId FCCUnitState::GetChainSkillId(int32 SkillType) const
{
	for (const FCCSkillState& S : Skills)
	{
		if (S.SkillType != SkillType)
		{
			continue;
		}

		const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(S.SkillType);
		if (InSkillRow.SkillCategory != ESkillCategory::Chain)
		{
			Q6JsonLog(Warning, "wrong chain skill type", Q6KV("type", SkillType));
			return CCSkillIdInvalid;
		}

		return S.SkillId;
	}

	return CCSkillIdInvalid;
}

FCCSkillId FCCUnitState::GetDoubleSkillId() const
{
	for (const FCCSkillState& S : Skills)
	{
		if (S.Category == ESkillCategory::Double)
		{
			return S.SkillId;
		}
	}

	return CCSkillIdInvalid;
}

FCCSkillId FCCUnitState::GetArtifactId(int32 SkillType) const
{
	for (const FCCSkillState& S : Skills)
	{
		if (S.SkillType != SkillType)
		{
			continue;
		}

		const FCMSSkillRow& InSkillRow = GetCMS()->GetSkillRowOrDummy(S.SkillType);
		if (InSkillRow.SkillCategory != ESkillCategory::Artifact)
		{
			Q6JsonLog(Warning, "wrong artifact type", Q6KV("type", SkillType));
			return CCSkillIdInvalid;
		}

		return S.SkillId;
	}

	return CCSkillIdInvalid;
}

ENatureType FCCUnitState::GetNatureType() const
{
	for (const FCCBuffState& B : Buffs)
	{
		for (const FCMSBuffEffectRow* Effect : GetCMS()->GetModifyCrowdControlEffects(B, ECrowdControl::ChangeNature))
		{
			return (ENatureType)(Effect->Param2 - 1); // 1 base.
		}
	}

	const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(FUnitType(this->UnitType));
	return CMSUnitRow.NatureType;
}

bool FCCUnitState::CanGetOverkill() const
{
	switch (Category)
	{
	case EAttributeCategory::Character:
	case EAttributeCategory::SystemJoker:
	case EAttributeCategory::FriendJoker:
	case EAttributeCategory::RecommendJoker:
		return true;

	default:
		return false;
	}

	return false;
}

TArray<FCCUnitId> FCCUnitsState::GetAllyUnits() const
{
	TArray<FCCUnitId> OutUnits;

	for (const FCCUnitState& UnitState : Units)
	{
		if (UnitState.Faction == ECCFaction::Ally
			&& UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, UnitState.CombatMultiSide, CurrentWaveIndex, UnitState.SpawnedWaveIndex))
		{
			OutUnits.Add(UnitState.UnitId);
		}
	}

	return OutUnits;
}

TArray<FCCUnitState*> FCCUnitsState::GetAliveUnits(ECCFaction Faction)
{
	TArray<FCCUnitState*> Ret;

	for (FCCUnitState& U : Units)
	{
		if (U.IsDead())
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, U.CombatMultiSide, CurrentWaveIndex, U.SpawnedWaveIndex))
		{
			continue;
		}

		if (Faction == ECCFaction::Max)
		{
			Ret.Emplace(&U);
		}
		else if (Faction == U.Faction)
		{
			Ret.Emplace(&U);
		}
	}

	return Ret;
}

TArray<const FCCUnitState*> FCCUnitsState::GetAliveUnits(ECCFaction Faction) const
{
	TArray<const FCCUnitState*> Ret;

	for (const FCCUnitState& U : Units)
	{
		if (U.IsDead())
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, U.CombatMultiSide, CurrentWaveIndex, U.SpawnedWaveIndex))
		{
			continue;
		}

		if (Faction == ECCFaction::Max)
		{
			Ret.Emplace(&U);
		}
		else if (Faction == U.Faction)
		{
			Ret.Emplace(&U);
		}
	}

	return Ret;
}

int32 FCCUnitsState::GetCountSkillsOnCurPhase(const FCCCombatCubeState& InOutState, ECCFaction InFaction, ESkillCategory Category) const
{
	if (!InOutState.SkillProp[(int32)Category].bDependOnSequence)
	{
		return 0;
	}

	int32 Count = 0;
	for (const FCCUnitState& UnitState : Units)
	{
		if (UnitState.Faction == InFaction &&
			UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, UnitState.CombatMultiSide, CurrentWaveIndex, UnitState.SpawnedWaveIndex))
		{
			Count += UnitState.GetCountSkillsOnAttack();
		}
	}

	return Count;
}

const FCCSkillState* FCCUnitsState::GetNormalSkillByTurn(FCCUnitId UnitId, int32 TurnCount) const
{
	for (const FCCUnitState& Unit : Units)
	{
		if (Unit.UnitId != UnitId)
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Unit.CombatMultiSide, CurrentWaveIndex, Unit.SpawnedWaveIndex))
		{
			continue;
		}

		return Unit.GetNormalSkillByTurn(TurnCount);
	}

	return nullptr;
}

const FCCSkillState* FCCUnitsState::GetUltimateSkillByTurn(FCCUnitId UnitId, int32 TurnCount) const
{
	for (const FCCUnitState& Unit : Units)
	{
		if (Unit.UnitId != UnitId)
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Unit.CombatMultiSide, CurrentWaveIndex, Unit.SpawnedWaveIndex))
		{
			continue;
		}

		return Unit.GetUltimateSkillByTurn(TurnCount);
	}

	return nullptr;
}

const FCharacterId& FCCUnitsState::GetCharacterId(const FCCUnitId& UnitId) const
{
	for (const FCCUnitState& Unit : Units)
	{
		if (Unit.UnitId != UnitId)
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, Unit.CombatMultiSide, CurrentWaveIndex, Unit.SpawnedWaveIndex))
		{
			continue;
		}

		return Unit.CharacterId;
	}

	return FCharacterId::InvalidValue();
}

FCCUnitState& FCCUnitsState::FindUnitState(const FCCUnitId& UnitId, bool bWithMaster)
{
	for (FCCUnitState& UnitState : Units)
	{
		if (UnitState.UnitId == UnitId &&
			UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, UnitState.CombatMultiSide, CurrentWaveIndex, UnitState.SpawnedWaveIndex))
		{
			return UnitState;
		}
	}

	if (bWithMaster)
	{
		for (FCCUnitState& UnitState : Masters)
		{
			if (UnitState.UnitId == UnitId)
			{
				return UnitState;
			}
		}
	}

	static FCCUnitState Dummy;

	return Dummy;
}

bool FCCUnitsState::IsMaster(const FCCUnitId& UnitId)
{
	static_assert((int32)ECCFaction::Max == 2, "need more master.");

	if (Masters[(int32)ECCFaction::Ally].UnitId == UnitId
		|| Masters[(int32)ECCFaction::Enemy].UnitId == UnitId)
	{
		return true;
	}

	return false;
}

void FCCUnitsState::InitClearUnits(const FCMSSagaRow& InSagaRow)
{
	const TArray<const FCMSUnitRow*>& ClearUnits = InSagaRow.GetClearUnit();
	for (const FCMSUnitRow* ClearUnit : ClearUnits)
	{
		ClearUnitTypes.Add((FUnitType)ClearUnit->Type);
	}

	bHasClearUnitTypes = ClearUnitTypes.Num() > 0;
}

void FCCUnitsState::CheckClearUnits(const FCCUnitId& UnitId)
{
	if (!bHasClearUnitTypes)
	{
		return;
	}

	const FCCUnitState& UnitState = FindUnitState(UnitId);
	ClearUnitTypes.Remove(UnitState.UnitType);
}

bool FCCUnitsState::IsFinishConditionByClearUnits()
{
	return bHasClearUnitTypes && ClearUnitTypes.Num() == 0;
}

void FCCCombatCubeState::InitSkillProp()
{
	static_assert(ESkillCategoryMax == 13, "InitSkillProp()");

	for (FCCSkillCategoryProperty& Prop : SkillProp)
	{
		Prop.bHasCoolTime = false;
		Prop.bHasNote = false;
		Prop.bDependOnSequence = false;
		Prop.bChangeOverKillPoint = false;
		Prop.bConsumeOverKillPoint = false;
		Prop.bUsableToDeadUnit = false;
		Prop.bHasWaitTime = false;
		Prop.bUtilizeCoolTimeForAvailable = false;
		Prop.bActiveAttack = false;
		Prop.bInvokeVersa = false;
	}

	for (int i = 0; i < dimof(SkillProp); ++i)
	{
		ESkillCategory Category = (ESkillCategory)i;
		FCCSkillCategoryProperty& Prop = SkillProp[i];

		switch (Category)
		{
		case ESkillCategory::Normal:
		case ESkillCategory::Ultimate:
		case ESkillCategory::TurnBegin:
		case ESkillCategory::Pet:
		case ESkillCategory::Artifact:
			Prop.bHasCoolTime = true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::Normal:
		case ESkillCategory::Ultimate:
		case ESkillCategory::Double:
			Prop.bActiveAttack = true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::Normal:
			Prop.bHasNote= true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::Normal:
		case ESkillCategory::Ultimate:
			Prop.bDependOnSequence = true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::Normal:
			Prop.bInvokeVersa = true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::Normal:
		case ESkillCategory::Ultimate:
			Prop.bConsumeOverKillPoint = true;
			break;
		}
		if (Prop.bConsumeOverKillPoint)
		{
			Prop.bChangeOverKillPoint = true;
		}

		switch (Category)
		{
		case ESkillCategory::Double:
			Prop.bChangeOverKillPoint = true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::Double:
			Prop.bUsableToDeadUnit = true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::TurnBegin:
		case ESkillCategory::Ultimate:
			Prop.bHasWaitTime = true;
			break;
		}

		switch (Category)
		{
		case ESkillCategory::Artifact:
			Prop.bUtilizeCoolTimeForAvailable = true;
			break;
		}
	}
}

int32 FCCCombatCubeState::GetGameFlag(EGameFlags InGameFlag) const
{
	if (!GameFlags.IsValidIndex((int32)InGameFlag))
	{
		return 0;
	}

	return GameFlags[(int32)InGameFlag];
}

void FCCCombatCubeState::SetGameFlag(EGameFlags InGameFlag, int32 InValue)
{
	if (GameFlags.IsValidIndex((int32)InGameFlag))
	{
		GameFlags[(int32)InGameFlag] = InValue;
	}
}

int32 FCCCombatCubeState::SeedUnitCount(ECCFaction Faction)
{
	int32 Count = 0;
	for (const FCCCombatSeedUnit& Unit : CombatSeed.Units)
	{
		if (Unit.Faction == Faction)
		{
			++Count;
		}
	}

	return Count;
}

bool FCCCombatCubeState::IsLastWave() const
{
	return TurnState.CurrentWaveIndex == CombatSeed.Seed.LastWaveIndex;
}

int32 FCCCombatCubeState::GetNextWave() const
{
	for (int i = TurnState.CurrentWaveIndex + 1; i <= CombatSeed.Seed.LastWaveIndex; ++i)
	{
		if (!CombatSeed.Seed.AppearanceWave[i])
		{
			continue;
		}

		return i;
	}

	ensure(0);
	return CombatSeed.Seed.LastWaveIndex;
}

bool FCCCombatCubeState::VerifyFinishCondition(int32& OutAlliesCount, int32& OutEnemiesCount)
{
	OutEnemiesCount = UnitsState.GetAliveUnits(ECCFaction::Enemy).Num();
	OutAlliesCount = UnitsState.GetAliveUnits(ECCFaction::Ally).Num();

	for (const FCCSpawnUnitParam& SpawnUnit : UnitsState.ReqSpawnSubUnits)
	{
		if (SpawnUnit.Faction == ECCFaction::Ally)
		{
			++OutAlliesCount;
		}
		else
		{
			++OutEnemiesCount;
		}
	}

	static_assert((int32)ECCFaction::Max == 2, "need more SpawnedSubUnitCount.");
	int32 AllySubCount = 0;
	int32 EnemySubCount = 0;
	for (const FCCCombatSeedUnit& SubUnit : CombatSeed.SubUnits)
	{
		if (SubUnit.Faction == ECCFaction::Ally)
		{
			++AllySubCount;
		}
		else
		{
			++EnemySubCount;
		}
	}
	OutAlliesCount += AllySubCount - SpawnedSubUnitCount[(int32)ECCFaction::Ally];
	OutEnemiesCount += EnemySubCount - SpawnedSubUnitCount[(int32)ECCFaction::Enemy];

	if (OutAlliesCount > 0 && OutEnemiesCount > 0)
	{
		return false;
	}

	return true;
}

const int32 FCCCombatCubeState::GetBossHpRatio() const
{
	if (!IsLastWave())
	{
		return 0;
	}

	FUnitType BossUnitType = UnitTypeInvalid;
	if (CombatSeed.Content == EContentType::DailyDungeon)
	{
		if (const FCMSDailyDungeonRow* Row = GetCMS()->GetDailyDungeonRow(CombatSeed.SagaType))
		{
			BossUnitType = FUnitType(Row->BossId);
		}
	}

	const FCCUnitState* BossUnit = UnitsState.GetBossUnit(BossUnitType);
	if (!BossUnit)
	{
		return 0;
	}

	int32 MaxHealth = BossUnit->GetAttributeValue(EUnitAttribute::MaxHealth);
	int32 DamagedHealth = MaxHealth - BossUnit->Health;

	int32 HpRatio = (float)DamagedHealth / MaxHealth * 100;
	return HpRatio;
}

const FCCUnitState* FCCUnitsState::GetBossUnit(FUnitType UnitType) const
{
	for (const FCCUnitState& Unit : Units)
	{
		if (Unit.IsAlly())
		{
			continue;
		}

		if (Unit.UnitType == UnitType)
		{
			return &Unit;
		}
	}

	return nullptr;
}

TArray<FCCUnitId> FCCUnitsState::GetEnemyUnits() const
{
	TArray<FCCUnitId> OutUnits;

	for (const FCCUnitState& UnitState : Units)
	{
		if (UnitState.Faction == ECCFaction::Enemy
			&& UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, UnitState.CombatMultiSide, CurrentWaveIndex, UnitState.SpawnedWaveIndex))
		{
			OutUnits.Add(UnitState.UnitId);
		}
	}

	return OutUnits;
}

TArray<FCCUnitState*> FCCUnitsState::GetAliveUnitsAllOfCombatMultiSide(ECCFaction Faction)
{
	TArray<FCCUnitState*> Ret;

	for (FCCUnitState& U : Units)
	{
		if (U.IsDead())
		{
			continue;
		}

		if (Faction == ECCFaction::Max)
		{
			Ret.Emplace(&U);
		}
		else if (Faction == U.Faction)
		{
			Ret.Emplace(&U);
		}
	}

	return Ret;
}

TArray<FCCUnitId> FCCUnitsState::GetAutoTargetEnemyUnits() const
{
	const ECombatMultiSide CombatMultiSide = CurrentCombatMultiSide;
	const int32 WaveIndex = CurrentWaveIndex;

	TArray<FCCUnitId> OutUnits;
	for (int32 SlotOrder : ALLY_AUTO_TARGET_SLOT_ORDER)
	{
		const FCCUnitState* UnitState = Units.FindByPredicate([SlotOrder, CombatMultiSide, WaveIndex](const FCCUnitState& InUnitState)
		{
			return InUnitState.Faction == ECCFaction::Enemy && InUnitState.Slot == SlotOrder && !InUnitState.IsDead()
				&& UCombatCubeStateUtil::IsCurrentCombatMultiSide(CombatMultiSide, InUnitState.CombatMultiSide, WaveIndex, InUnitState.SpawnedWaveIndex);
		});

		if (UnitState)
		{
			OutUnits.Add(UnitState->UnitId);
		}
	}

	return OutUnits;
}

TArray<int32> FCCUnitsState::GetEmptySlots(ECCFaction Faction) const
{
	TArray<int32> SlotsInOrder = { 1, 2, 3 };

	for (const FCCUnitState& UnitState : Units)
	{
		if (UnitState.Faction != Faction)
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, UnitState.CombatMultiSide, CurrentWaveIndex, UnitState.SpawnedWaveIndex))
		{
			continue;
		}

		if (!UnitState.IsDead())
		{
			ensure(SlotsInOrder.Contains(UnitState.Slot));
			SlotsInOrder.Remove(UnitState.Slot);
		}
	}

	return SlotsInOrder;
}

bool FCCUnitsState::PossibleAttackByFaction(ECCFaction InFaction, const UCMS* CMS, bool* bOutHasDoubleSkill /* = nullptr */) const
{
	for (const FCCUnitState& UnitState : Units)
	{
		if (UnitState.Faction == InFaction &&
			!UnitState.IsDead() &&
			UnitState.HasSkillOnAttack() &&
			UnitState.GetCrowdControlState(CMS, ECrowdControl::Stun) == 0 &&
			UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, UnitState.CombatMultiSide, CurrentWaveIndex, UnitState.SpawnedWaveIndex))
		{
			return true;
		}
	}

	// "Double" skill check
	if (GetAliveUnits(InFaction).Num() == CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT)
	{
		for (const FCCUnitState& UnitState : Units)
		{
			if (UnitState.Faction == InFaction &&
				!UnitState.IsDead() &&
				UnitState.bStraightNote == false &&
				UCombatCubeStateUtil::IsCurrentCombatMultiSide(CurrentCombatMultiSide, UnitState.CombatMultiSide, CurrentWaveIndex, UnitState.SpawnedWaveIndex))
			{
				return false;
			}
		}

		if (bOutHasDoubleSkill)
		{
			*bOutHasDoubleSkill = true;
		}
		return true;
	}

	return false;
}

void FCCAddRaidTurnSkillAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	check(InOutState.CombatSeed.Content == EContentType::Raid);

	InOutState.RaidState.NextSkillId = INITIALIZE_SKILL_ID;
	for (const FCharSkill& RaidTurnSkill : RaidTurnSkills)
	{
		FCCRaidSkillState TurnSkillState;

		TurnSkillState.SkillState.SkillId	= InOutState.RaidState.NextSkillId;
		TurnSkillState.SkillState.SkillType	= RaidTurnSkill.Skill.x;
		TurnSkillState.CharInfo			= RaidTurnSkill.CharInfo;
		TurnSkillState.NatureType		= RaidTurnSkill.NatureType;
		TurnSkillState.Attributes		= RaidTurnSkill.Attributes;

		TurnSkillState.SkillState.Level = CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL;
		const FCMSUnitRow& Unit = GetCMS()->GetUnitRowOrDummy(RaidTurnSkill.CharInfo.Type);
		if (!Unit.IsInvalid())
		{
			int32 SkillType = TurnSkillState.SkillState.SkillType;
			int32 FindIndex = Unit.GetTurnSkills().IndexOfByPredicate([&SkillType](const FCMSSkillRow* Elem)
			{
				return Elem->Type == SkillType;
			});
			if (FindIndex != INDEX_NONE)
			{
				switch (FindIndex)
				{
					case 0: TurnSkillState.SkillState.Level = RaidTurnSkill.CharInfo.TurnSkill1Level; break;
					case 1: TurnSkillState.SkillState.Level = RaidTurnSkill.CharInfo.TurnSkill2Level; break;
					case 2: TurnSkillState.SkillState.Level = RaidTurnSkill.CharInfo.TurnSkill3Level; break;
					default:
						break;
				}
			}
		}
		TurnSkillState.SkillState.Level	
			= FMath::Clamp(TurnSkillState.SkillState.Level, CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL, CombatCubeConst::Q6_MAX_SKILL_LEVEL);
		TurnSkillState.SkillState.Cooldown = CombatCubeConst::Q6_INVALID_COOLDOWN;
		TurnSkillState.Slot			= RaidTurnSkill.Slot;
		TurnSkillState.UserName			= RaidTurnSkill.UserName;
		TurnSkillState.UserId			= RaidTurnSkill.UserId;

		InOutState.RaidState.RaidTurnSkillStates.Emplace(TurnSkillState);
		Q6JsonLogGenie(Display, "Add Raid Turn Skill"
			, Q6KV("FCCSkillState", TurnSkillState.SkillState)
			, Q6KV("FCharacterInfo", TurnSkillState.CharInfo)
			, Q6KV("NatureType", (int32)TurnSkillState.NatureType)
			, Q6KV("Slot", TurnSkillState.Slot)
			, Q6KV("UserName", TurnSkillState.UserName)
			, Q6KV("UserId", TurnSkillState.UserId)
		);

		++InOutState.RaidState.NextSkillId.X;
	}

	for (const FCharSkill& RaidSupportSkill : RaidSupportSkills)
	{
		FCCRaidSkillState SupportSkillState;

		SupportSkillState.SkillState.SkillId = InOutState.RaidState.NextSkillId;
		SupportSkillState.SkillState.SkillType = RaidSupportSkill.Skill.x;
		SupportSkillState.SkillState.Level = RaidSupportSkill.SupportSkillLevel;
		SupportSkillState.SkillState.Cooldown = CombatCubeConst::Q6_INVALID_COOLDOWN;
		SupportSkillState.CharInfo = RaidSupportSkill.CharInfo;
		SupportSkillState.NatureType = RaidSupportSkill.NatureType;
		SupportSkillState.Slot = RaidSupportSkill.Slot;
		SupportSkillState.SupportSkillLevel = RaidSupportSkill.SupportSkillLevel;
		SupportSkillState.UserName = RaidSupportSkill.UserName;
		SupportSkillState.UserId = RaidSupportSkill.UserId;
		SupportSkillState.Attributes = RaidSupportSkill.Attributes;
		SupportSkillState.bIsUsed = false;

		InOutState.RaidState.RaidSupportSkillStates.Emplace(SupportSkillState);
		Q6JsonLogGenie(Display, "Add Raid Support Skill"
			, Q6KV("FCCSkillState", SupportSkillState.SkillState)
			, Q6KV("FCharacterInfo", SupportSkillState.CharInfo)
			, Q6KV("NatureType", (int32)SupportSkillState.NatureType)
			, Q6KV("Slot", SupportSkillState.Slot)
			, Q6KV("UserName", SupportSkillState.UserName)
			, Q6KV("UserId", SupportSkillState.UserId)
		);

		++InOutState.RaidState.NextSkillId.X;
	}

	InOutState.RaidState.bRaidTurnSkillArrived = true;

	if (InOutState.RaidState.NextSkillId != INITIALIZE_SKILL_ID)
	{
		ACTION_DISPATCH_RaidClearSkills();
	}
}

void FCCChangeCombatMultiSideAction::DoAction(const FActionContext& Context, FCCCombatCubeState& InOutState) const
{
	check(InOutState.TurnState.CurrentCombatMultiSide == CurrentCombatSide);

	_ChangeCombatMultiSide(Context, InOutState, bClearWave);
}
