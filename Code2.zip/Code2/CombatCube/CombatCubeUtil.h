#pragma once

#include "Q6Minimal.h"
#include "Q6GameState.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "CombatPresenter.h"
#include "Unit.h"
#include "Q6GameState.h"

#include "CombatCubeUtil.generated.h"

struct FSculpture;
struct FRelic;

UCLASS()
class Q6_API UCombatCubeStateUtil : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	static FCCUnitState& FindUnitStateByUnitId(UPARAM(ref) FCCCombatCubeState& State, FCCUnitId UnitId);

	static void ConvertCCBuffStateToBuffState(const FCCBuffState& InBuffState, FBuffState* OutBuffState, int32& OutShield, int32& OutMaxShield);
	static void ConvertCCUnitStateToUnitState(const FCCUnitState& InUnitState, FUnitState* OutUnitState);
	static void ConvertCCSkillStateToSkillState(const TArray<const FCCSkillState*>& InUnitState, TArray<FSkillState>* OutUnitState);
	static void ConvertCCSculptureInfoToSculptureInfo(const FCCSculptureInfo& InSculptureInfo, FSculptureInfo& OutSculptureInfo);
	static void ConvertCCRelicInfoToRelicInfo(const FCCRelicInfo& InRelicInfo, FRelicInfo& OutRelicInfo);
	static void ConvertCCMasterStateToMasterState(const TArray<FCCUnitState>& InMasterState, TArray<FMasterState>* OutMasterState);
	static void ConvertCCUnitAttributesToUnitAttributes(const UCCUnitAttributes* InAttributes, FUnitAttributes& OutAttributes);

	static void ConvertCharacterInfoToCombatSeedUnit(const FCharacterInfo& InCharacterInfo, const FSculptureInfo* InSculpture, const FRelicInfo* InRelic, int32 SupportSkillLevel,
		EAttributeCategory InAttributeCategory, FCCCombatSeedUnit* OutSeedUnit);
	static void ConvertCombatSeedUnitToSpawnUnitParam(const FCCCombatSeedUnit& InCombatSeedUnit, FCCSpawnUnitParam* OutSpawnUnitParam, ESpawnReason SpawnReason,
		int32 Slot, int32 RebirthSkillCount, int32 HealthPermil, int32 LiveTurnCount);

	template <typename ElementType>
	static bool ShiftSkills(TArray<ElementType>& InSkills)
	{
		if (InSkills.Num() <= 1)
		{
			return false;
		}

		ElementType PushBackElement = InSkills[0];
		int32 SkillsLastIdx = InSkills.Num() - 1;

		FMemory::Memcpy(InSkills.GetData(), InSkills.GetData() + 1, SkillsLastIdx * InSkills.GetTypeSize());
		InSkills[SkillsLastIdx] = PushBackElement;

		return true;
	}

	static void ShiftSkillsPointer(TArray<FCCSkillState*>& InSkills)
	{
		if (InSkills.Num() <= 1)
		{
			return;
		}

		FCCSkillState PushBackElement = *InSkills[0];
		for (int i = 0; i < InSkills.Num() - 1; ++i)
		{
			*InSkills[i] = *InSkills[i + 1];
		}
		*InSkills[InSkills.Num() - 1] = PushBackElement;
	}

	static bool IsPatternMatched(const FCMSMonsterPatternRow& PRow, FCCUnitState* SourceUnit, const FCCPatternState& PState);

	static bool IsCurrentCombatMultiSide(ECombatMultiSide InCurrentCombatMultiSide, ECombatMultiSide InCombatMultiSide, int32 InCurrentWaveIndex = 0, int32 InWaveIndex = 0);
	static int32 GetCombatMultiSideWaveRowIndex(const FCCCombatSeed& InCombatSeed, ECombatMultiSide InCurrentCombatMultiSide, const int32 InWaveRowIndex);
};
