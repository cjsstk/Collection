#pragma once
#include "Q6Define.h"
#include "CMSTable.h"
#include "LobbyObj_gen.h"
#include "SystemConst_gen.h"
#include "Q6GameState.generated.h"

struct FCCUnitState;
struct FActionContext;
struct FCCCombatCubeState;

USTRUCT(BlueprintType)
struct FCCSculptureInfo
{
	GENERATED_BODY()

public:
	FCCSculptureInfo()
		: Type(SculptureTypeInvalid), Level(ItemXpTypeInvalid), Tier(0), Grade(EItemGrade::NONE) {}
	explicit FCCSculptureInfo(FSculptureInfo InInfo)
		: Type(InInfo.Type), Level(InInfo.Level), Tier(InInfo.Tier), Grade(InInfo.Grade) {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FSculptureType Type;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FItemXpType Level;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Tier;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EItemGrade Grade;
};

USTRUCT(BlueprintType)
struct FCCRelicInfo
{
	GENERATED_BODY()

public:
	FCCRelicInfo()
		: Type(RelicTypeInvalid), Level(ItemXpTypeInvalid), Tier(0), Grade(EItemGrade::NONE) {}
	explicit FCCRelicInfo(FRelicInfo InInfo)
		: Type(InInfo.Type), Level(InInfo.Level), Tier(InInfo.Tier), Grade(InInfo.Grade) {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FRelicType Type;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FItemXpType Level;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Tier;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EItemGrade Grade;
};

USTRUCT(BlueprintType)
struct FCCCombatSeedUnit
{
	GENERATED_BODY()

public:
	FCCCombatSeedUnit()
	{
		UnitType = UnitTypeInvalid;
		Faction = ECCFaction::Max;
		Category = EAttributeCategory::Character;
		Level = 1;
		Grade = EItemGrade::NONE;
		UltimateSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
		SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
		TurnSkillLevels.Init(CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL, CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
		Sculpture.Type = SculptureTypeInvalid;
		Relic.Type = RelicTypeInvalid;
		CharacterId = FCharacterId::InvalidValue();
		CombatMultiSide = ECombatMultiSide::Main;
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FUnitType UnitType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ECCFaction Faction;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EAttributeCategory Category;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Level;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EItemGrade Grade;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 UltimateSkillLevel;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 SupportSkillLevel;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<int32> TurnSkillLevels;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FCCSculptureInfo Sculpture;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FCCRelicInfo Relic;

	UPROPERTY()
	FCharacterId CharacterId;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	ECombatMultiSide CombatMultiSide;
};

USTRUCT(Blueprintable)
struct FCombatMultiSideInfo
{
	GENERATED_BODY()

public:
	FCombatMultiSideInfo()
	{
		bIsCombatMultiSide = false;
		RankBonusCategory = EMultiSideRankBonusCategory::None;
		TotalWaveNum = 1;
		bIsOfflineMode = false;
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = CombatMultiSideInfo)
	bool bIsCombatMultiSide;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = CombatMultiSideInfo)
	EMultiSideRankBonusCategory RankBonusCategory;

	// Offline Mode
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bIsCombatMultiSide"), Category = CombatMultiSideInfo)
	int32 TotalWaveNum;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (EditCondition = "bIsCombatMultiSide"), Category = CombatMultiSideInfo)
	TArray<FCCCombatSeedUnit> OfflineEnemies;

	UPROPERTY()
	bool bIsOfflineMode;
};

///////////////////////////////////////////////////////////////////////////////////////////
// UOfflineUser

UCLASS(Blueprintable)
class Q6_API UOfflineUser : public UObject
{
	GENERATED_BODY()

public:
	UOfflineUser() {}
	virtual ~UOfflineUser() {}

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	TArray<FCCCombatSeedUnit> OfflineAllies;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	TArray<int32> OfflineArtifactLevels;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	FPetType OfflinePetType;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	TArray<int32> OfflinePetSkillLevels;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	int32 Episode;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	int32 Stage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	int32 SubStage;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = Offline)
	FCombatMultiSideInfo CombatMultiSideInfo;
};

USTRUCT()
struct FCCSpawnUnitParam : public FCCCombatSeedUnit
{
	GENERATED_BODY()

	FCCSpawnUnitParam()
	{
		HealthPermil = 1000;
		RebirthSkillCount = 0;
		LiveTurnCount = 0;
	}

	UPROPERTY()
	int32 Slot;

	UPROPERTY()
	int32 HealthPermil;

	UPROPERTY()
	int32 RebirthSkillCount;

	UPROPERTY()
	int32 LiveTurnCount;

	UPROPERTY()
	ESpawnReason SpawnReason;
};

USTRUCT(BlueprintType)
struct FCCCombatSeed
{
	GENERATED_BODY()

	UPROPERTY()
	FSagaType SagaType;

	UPROPERTY()
	EContentType Content;

	UPROPERTY(BlueprintReadOnly)
	TArray<FCCCombatSeedUnit> Units;

	UPROPERTY(BlueprintReadOnly)
	TArray<FCCCombatSeedUnit> SubUnits;

	UPROPERTY()
	FCombatSeed Seed;

	UPROPERTY()
	int32 PartyId;

	UPROPERTY()
	TArray<int32> BanIndices;

	UPROPERTY()
	FCombatMultiSideInfo CombatMultiSideInfo;
};

USTRUCT()
struct FCCSkillCategoryProperty
{
	GENERATED_BODY()

	UPROPERTY()
	bool bHasCoolTime;

	UPROPERTY()
	bool bHasNote;

	UPROPERTY()
	bool bDependOnSequence;

	UPROPERTY()
	bool bChangeOverKillPoint;

	UPROPERTY()
	bool bConsumeOverKillPoint;

	UPROPERTY()
	bool bUsableToDeadUnit;

	UPROPERTY()
	bool bHasWaitTime;

	UPROPERTY()
	bool bUtilizeCoolTimeForAvailable;

	UPROPERTY()
	bool bActiveAttack;

	UPROPERTY()
	bool bInvokeVersa;
};

USTRUCT(BlueprintType)
struct FCCSkillState
{
	GENERATED_BODY()

	FCCSkillState()
		: Category(ESkillCategory::Normal), SkillType(0), Level(0), Cooldown(0), CoolTime(0), Waitdown(0), WaitTime(0), UsingCount(0), IsPattern(false) {}
	explicit FCCSkillState(FCCSkillId InSkillId, ESkillCategory InCategory, int32 InSkillType, int32 InLevel,
		int32 InCoolTime, int32 InWaitTime, int32 InitWaitDown)
		: SkillId(InSkillId), Category(InCategory), SkillType(InSkillType), Level(InLevel),
		Cooldown(0), CoolTime(InCoolTime), Waitdown(InitWaitDown), WaitTime(InWaitTime), UsingCount(0), IsPattern(false) {}

	UPROPERTY(BlueprintReadWrite)
	FCCSkillId SkillId;

	UPROPERTY(BlueprintReadWrite)
	ESkillCategory Category;

	UPROPERTY(BlueprintReadWrite)
	int32 SkillType;

	UPROPERTY(BlueprintReadWrite)
	int32 Level;

	UPROPERTY(BlueprintReadWrite)
	int32 Cooldown;

	UPROPERTY()
	int32 CoolTime;

	UPROPERTY(BlueprintReadWrite)
	int32 Waitdown;

	UPROPERTY()
	int32 WaitTime;

	UPROPERTY()
	int32 UsingCount;

	UPROPERTY()
	bool IsPattern;

	bool IsInCooldown() const;
	bool IsInWaitdown() const;
};

USTRUCT(BlueprintType)
struct FCCBuffState
{
	GENERATED_BODY()

	FCCBuffState(): BuffType(0), BuffLevel(0), CreatedTurnCount(0),
		Duration(0), HitCount(0), Shield(0), MaxShield(0), Multiple(0), BornCategory(ESkillCategory::Normal) {}
	explicit FCCBuffState(FCCBuffId InBuffId, int32 InBuffType, int32 InSkillLevelOrTier, int32 InCreatedTurnCount,
		int32 InDuration, int32 InHitCount, int64 InShield, int64 InMaxShield, FCCUnitId InSourceUnitId, ESkillCategory InBornCategory)
	: BuffId(InBuffId)
	, BuffType(InBuffType)
	, BuffLevel(InSkillLevelOrTier)
	, CreatedTurnCount(InCreatedTurnCount)
	, Duration(InDuration)
	, HitCount(InHitCount)
	, Shield(InShield)
	, MaxShield(InMaxShield)
	, SourceUnitId(InSourceUnitId)
	, Multiple(1)
	, BornCategory(InBornCategory)
	, Damage(0)
	, Heal(0)
	{}

	UPROPERTY(BlueprintReadWrite)
	FCCBuffId BuffId;

	UPROPERTY(BlueprintReadWrite)
	int32 BuffType;

	UPROPERTY(BlueprintReadWrite)
	int32 BuffLevel;

	UPROPERTY(BlueprintReadWrite)
	int32 CreatedTurnCount;

	UPROPERTY(BlueprintReadWrite)
	int32 Duration;

	UPROPERTY(BlueprintReadWrite)
	int32 HitCount;

	UPROPERTY(BlueprintReadWrite)
	int64 Shield;

	UPROPERTY(BlueprintReadWrite)
	int64 MaxShield;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId SourceUnitId;

	UPROPERTY(BlueprintReadOnly)
	int32 Multiple;

	UPROPERTY(BlueprintReadOnly)
	ESkillCategory BornCategory;

	int64 Damage; // int64 was not supported on blueprint

	int64 Heal; // int64 was not supported on blueprint
};

UCLASS(BlueprintType)
class UCCUnitAttributes : public UObject
{
	GENERATED_BODY()

public:
	UCCUnitAttributes();

	// updated UnitAttribute, amount
	TArray<TPair<int64, int64>> UpdateUnitAttributes(const FActionContext& Context, const FCCUnitState& Unit);
	void SetConstAttributeValue(EUnitAttribute InAttribute, int64 InValue);
	void SetCheatAttributeValue(EUnitAttribute InAttribute, int64 InValue);
	void SetPointVaryAttributeValue(EPointVaryConvertType ConvertType, int64 InValue);
	void RevertCheatAttribute(EUnitAttribute InAttribute);
	bool IsConstAttribute(EUnitAttribute InAttribute) const;
	void ClearPointVaryAttributes();

	UFUNCTION(BlueprintCallable)
	int64 GetAttributeValue(EUnitAttribute InAttribute) const;

	TArray<int64>& GetPointVaryAttributes();

private:

	int64 GetCachedAttributeValue(EUnitAttribute InAttribute) const;
	int64 GetCheatAttributeValue(EUnitAttribute InAttribute) const;

	bool IsCheated(EUnitAttribute InAttribute) const;

	UPROPERTY()
	TArray<int64> CachedAttributes;

	UPROPERTY()
	TArray<bool> bCheatedAttributes;

	UPROPERTY()
	TArray<int64> CheatAttributes;

	UPROPERTY()
	TArray<int64> PointVaryAttributes;
};

USTRUCT()
struct FCCPatternState
{
	GENERATED_BODY()

	UPROPERTY()
	FMonsterPatternType Type;

	UPROPERTY()
	FCCSkillId SkillId;
};

USTRUCT(BlueprintType)
struct FCCUnitState
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId UnitId;

	UPROPERTY(BlueprintReadOnly)
	FUnitType UnitType;

	UPROPERTY(BlueprintReadOnly)
	int32 Slot;

	UPROPERTY(BlueprintReadOnly)
	ECCFaction Faction;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	EAttributeCategory Category;

	UPROPERTY(BlueprintReadOnly)
	int32 Level;

	UPROPERTY(BlueprintReadOnly)
	EItemGrade Grade;

	UPROPERTY(BlueprintReadOnly)
	int64 Health;

	UPROPERTY(BlueprintReadOnly)
	TArray<FCCSkillState> Skills;

	UPROPERTY(BlueprintReadOnly)
	TArray<int32> TurnSkillGroup;

	UPROPERTY(BlueprintReadOnly)
	int32 UA;

	UPROPERTY(BlueprintReadOnly)
	int32 SA;

	UPROPERTY(BlueprintReadOnly)
	int32 OverKill;

	// rebirth.
	UPROPERTY(BlueprintReadOnly)
	int32 RebirthSkillCount;

	UPROPERTY(BlueprintReadOnly)
	int32 LiveTurnCount;

	UPROPERTY(BlueprintReadOnly)
	FCCSculptureInfo Sculpture;

	UPROPERTY(BlueprintReadOnly)
	FCCRelicInfo Relic;

	UPROPERTY(BlueprintReadOnly)
	TArray<int32> SkillsOnAttack;

	UPROPERTY(BlueprintReadOnly)
	bool bSupporter;

	UPROPERTY(BlueprintReadOnly)
	bool bStraightNote;

	UPROPERTY(BlueprintReadOnly)
	FCCBuffId NextBuffId;

	UPROPERTY(BlueprintReadOnly)
	TArray<FCCBuffState> Buffs;

	UPROPERTY(BlueprintReadOnly)
	UCCUnitAttributes* UnitAttributes;

	UPROPERTY()
	FCharacterId CharacterId;

	UPROPERTY(BlueprintReadOnly)
	FCCSkillId NextSkillId;

	UPROPERTY()
	TArray<FCCPatternState> Patterns;

	UPROPERTY()
	FMonsterPatternType SelectedPatternsUltimate;

	UPROPERTY()
	FCCSkillId CheatFixedNoteSkillId;

	UPROPERTY()
	ECombatMultiSide CombatMultiSide;

	UPROPERTY()
	int32 SpawnedWaveIndex;	// only use it on combat multi side mode

	FCCSkillState* GetSkillState(const FCCSkillId& SkillId);
	void AddSkillOnAttack(int32 SkillType);
	const TArray<int32>& GetUsedSkillsOnAttack() const { return SkillsOnAttack;  }
	void MakeToAttackPass();
	TArray<FCCSkillState*> GetSkillStates(ESkillCategory Category);
	TArray<const FCCSkillState*> GetSkillStates(ESkillCategory Category) const;

	bool IsInCooldown(const FActionContext& Context, const FCCSkillId& SkillId);
	bool IsDead() const;
	bool HasSkillOnAttack() const { return GetCountSkillsOnAttack() == 0; }
	int32 GetCountSkillsOnAttack() const { return SkillsOnAttack.Num(); }
	bool IsSupporter() const { return bSupporter; }
	bool IsAlly() const { return Faction == ECCFaction::Ally; }
	bool CanUseSkillOnCurrentPhase(const FCMSSkillRow& SkillRow, ECCTurnPhase InCurrentPhase) const;

	int64 GetAttributeValue(EUnitAttribute InAttribute) const;

	int32 GetCrowdControlState(const UCMS* CMS, ECrowdControl Control) const;
	int32 GetExtraDMGper(const FActionContext& Context, const FCCCombatCubeState& InOutState, const UCMS* CMS,
		FCCUnitState& TargetUnit, int32 InLevelOrTier, ESkillCategory BornCategory);

	const FCCSkillState* GetNormalSkillByTurn(int32 TurnCount) const;
	const FCCSkillState* GetUltimateSkillByTurn(int32 TurnCount) const;
	FCCSkillId GetVersaSkillId(int32 SkillType) const;
	FCCSkillId GetChainSkillId(int32 SkillType) const;
	FCCSkillId GetDoubleSkillId() const;
	FCCSkillId GetArtifactId(int32 SkillType) const;

	ENatureType GetNatureType() const;
	bool CanGetOverkill() const;
};

USTRUCT(BlueprintType)
struct FCCUnitsState
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId NextUnitId;

	UPROPERTY()
	TArray<FCCUnitState> Masters;

	UPROPERTY(BlueprintReadOnly)
	TArray<FCCUnitState> Units;

	UPROPERTY()
	int32 EntryAliveUnitCount[(int32)ECCFaction::Max];

	UPROPERTY()
	TArray<FCCSpawnUnitParam> ReqSpawnSubUnits;

	UPROPERTY()
	ECombatMultiSide CurrentCombatMultiSide;

	UPROPERTY()
	int32 CurrentWaveIndex;	// only use it on combat multi side mode

	UPROPERTY()
	TArray<FUnitType> ClearUnitTypes;

	UPROPERTY()
	bool bHasClearUnitTypes;

	TArray<FCCUnitId> GetAllyUnits() const;
	TArray<FCCUnitId> GetEnemyUnits() const;
	TArray<FCCUnitState*> GetAliveUnits(ECCFaction Faction);
	TArray<const FCCUnitState*> GetAliveUnits(ECCFaction Faction) const;

	TArray<FCCUnitState*> GetAliveUnitsAllOfCombatMultiSide(ECCFaction Faction);

	TArray<FCCUnitId> GetAutoTargetEnemyUnits() const;

	TArray<int32> GetEmptySlots(ECCFaction Faction) const;

	bool PossibleAttackByFaction(ECCFaction InFaction, const UCMS* CMS, bool* bOutHasDoubleSkill = nullptr) const;
	int32 GetCountSkillsOnCurPhase(const FCCCombatCubeState& InOutState, ECCFaction InFaction, ESkillCategory Category) const;

	const FCCSkillState* GetNormalSkillByTurn(FCCUnitId UnitId, int32 TurnCount) const;
	const FCCSkillState* GetUltimateSkillByTurn(FCCUnitId UnitId, int32 TurnCount) const;
	const FCharacterId& GetCharacterId(const FCCUnitId& UnitId) const;

	FCCUnitState& FindUnitState(const FCCUnitId& UnitId, bool bWithMaster = false);
	bool IsMaster(const FCCUnitId& UnitId);

	void InitClearUnits(const FCMSSagaRow& InSagaRow);
	void CheckClearUnits(const FCCUnitId& UnitId);
	bool IsFinishConditionByClearUnits();

	const FCCUnitState* GetBossUnit(FUnitType UnitType) const;
};

USTRUCT(BlueprintType)
struct FCCTurnState
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	int32 CurrentWaveIndex;

	UPROPERTY(BlueprintReadOnly)
	int32 WaveCount;

	UPROPERTY(BlueprintReadOnly)
	int32 WaveEnemyNumSlots;

	UPROPERTY(BlueprintReadOnly)
	int32 TurnCount;

	UPROPERTY(BlueprintReadOnly)
	ECCTurnPhase CurrentPhase;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId PlayerTargetUnitId;

	UPROPERTY(BlueprintReadOnly)
	ECombatMultiSide CurrentCombatMultiSide;

	UPROPERTY(BlueprintReadOnly)
	int32 OldCombatMultiSideWaveIndex;	// only use it on combat multi side mode

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId OldCombatMultiSidePlayerTargetUnitId;	// only use it on combat multi side mode

	UPROPERTY(BlueprintReadOnly)
	int32 CombatMultiSideTurnCount;	// only use it on combat multi side mode

	int32 GetWaveNumSlots() const { return WaveEnemyNumSlots; }
};

USTRUCT(BlueprintType)
struct FCCMomentSkill
{
	GENERATED_BODY()

	FCCMomentSkill()
		: UnitId(CCUnitIdInvalid)
		, SkillId(CCSkillIdInvalid)
		, Moment(EMoment::None)
		, BornCategory(ESkillCategory::Moment)
		, TargetUnitId(CCUnitIdInvalid)
	{}

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId UnitId;

	UPROPERTY(BlueprintReadWrite)
	FCCSkillId SkillId;

	UPROPERTY(BlueprintReadWrite)
	EMoment Moment;

	UPROPERTY(BlueprintReadWrite)
	ESkillCategory BornCategory;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId TargetUnitId;
};

USTRUCT()
struct FCCRaidSkillState
{
	GENERATED_BODY()

	UPROPERTY()
	FCCSkillState SkillState;

	UPROPERTY()
	FCharacterInfo CharInfo;

	UPROPERTY()
	ENatureType NatureType;

	UPROPERTY()
	int32 Slot;

	UPROPERTY()
	int32 SupportSkillLevel;

	UPROPERTY()
	FString UserName;

	UPROPERTY()
	FUserId UserId;

	UPROPERTY()
	TArray<int32> Attributes;

	UPROPERTY()
	bool bIsUsed;
};

USTRUCT()
struct FCCUsedCharSkillInfo
{
	GENERATED_BODY()

	UPROPERTY()
	FCharacterId CharacterId;

	UPROPERTY()
	ENatureType NatureType;

	UPROPERTY()
	FSkillType SkillType;

	UPROPERTY()
	int32 Slot;

	UPROPERTY()
	TArray<int32> Attributes;
};


USTRUCT()
struct FCCRaidState
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FCCRaidSkillState> RaidTurnSkillStates;

	UPROPERTY()
	TArray<FCCUsedCharSkillInfo> UsedTurnSkillInfos;

	UPROPERTY()
	TArray<FCCRaidSkillState> RaidSupportSkillStates;

	UPROPERTY()
	TArray<FCCUsedCharSkillInfo> UsedSupportSkills;

	UPROPERTY()
	FCCSkillId NextSkillId;

	UPROPERTY()
	bool bRaidTurnSkillArrived;

	UPROPERTY()
	int64 AccumulatedDamage;
};

USTRUCT()
struct FRaidUserCharacterInfo
{
	GENERATED_BODY()

	FRaidUserCharacterInfo()
		: CharacterId(0)
		, Health(0)
		, MaxHealth(0)
		, bPlaying(false)
		, bJoker(false)
	{}

	explicit FRaidUserCharacterInfo(const int64 InCharacterId
		, const int32 InHealth
		, const int32 InMaxHealth
		, const bool bInPlaying
		, const bool bInIsJoker)
		: CharacterId(InCharacterId)
		, Health(InHealth)
		, MaxHealth(InMaxHealth)
		, bPlaying(bInPlaying)
		, bJoker(bInIsJoker)
	{}

	UPROPERTY()
	int64 CharacterId;

	UPROPERTY()
	int32 Health;

	UPROPERTY()
	int32 MaxHealth;

	UPROPERTY()
	bool bPlaying;

	UPROPERTY()
	bool bJoker;
};

USTRUCT()
struct FCCWeeklyMissionInfo
{
	GENERATED_BODY()

	UPROPERTY()
	FMissionType Type;

	UPROPERTY()
	EMissionCategory Category;
};

USTRUCT()
struct FCCCharacterMissionInfo
{
	GENERATED_BODY()

	UPROPERTY()
	FCharMissionType Type;

	UPROPERTY()
	FUnitType UnitType;

	UPROPERTY()
	ECharMissionCategory Category;
};

USTRUCT()
struct FCCMissionState
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FCCWeeklyMissionInfo> WeeklyMissionStates;

	UPROPERTY()
	TArray<FCCCharacterMissionInfo> CharacterMissionStates;
};

USTRUCT()
struct FCCCombatMultiSideState
{
	GENERATED_BODY()

	FCCCombatMultiSideState()
		: AccumulatedRankScore(0)
		, AccumulatedBonusScore(0)
		, FinalRankScore(0)
		, FinalBonusScore(0)
	{
	}

	UPROPERTY()
	int32 AccumulatedRankScore;

	UPROPERTY()
	int32 AccumulatedBonusScore;

	UPROPERTY()
	int32 FinalRankScore;

	UPROPERTY()
	int32 FinalBonusScore;
};

USTRUCT(BlueprintType)
struct FCCCombatCubeState
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FCCCombatSeed CombatSeed;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitsState UnitsState;

	UPROPERTY(BlueprintReadOnly)
	TArray<FCCMomentSkill> ReadyMomentSkills;

	UPROPERTY(BlueprintReadOnly)
	FCCTurnState TurnState;

	UPROPERTY(BlueprintReadOnly)
	ECCResult Result;

	UPROPERTY(BlueprintReadOnly)
	bool bInCombat;

	UPROPERTY(BlueprintReadOnly)
	TArray<int32> GameFlags;

	UPROPERTY()
	FCCRaidState RaidState;

	UPROPERTY()
	FCCMissionState MissionState;

	UPROPERTY()
	FCCSkillCategoryProperty SkillProp[ESkillCategoryMax];

	UPROPERTY()
	int32 GemWipeoutContinueCount;

	UPROPERTY()
	int32 WipeoutContinueHealthPermil;

	UPROPERTY()
	FCCUnitId LastEnemyTarget;

	UPROPERTY()
	int32 SpawnedSubUnitCount[(int32)ECCFaction::Max];

	UPROPERTY()
	FCCCombatMultiSideState CombatMultiSideState;

	void InitSkillProp();

	bool IsGameFinished() const { return Result != ECCResult::Unknown; }
	bool IsInCombat() const { return bInCombat; }
	int32 GetGameFlag(EGameFlags InGameFlag) const;
	void SetGameFlag(EGameFlags InGameFlag, int32 InValue);

	int32 SeedUnitCount(ECCFaction Faction);

	bool IsLastWave() const;
	int32 GetNextWave() const;

	bool VerifyFinishCondition(int32& OutAlliesCount, int32& OutEnemiesCount);

	const int32 GetBossHpRatio() const;
};

USTRUCT()
struct FCombatMissionInfo
{
	GENERATED_BODY()

	UPROPERTY()
	TArray<FMissionCombat> WeeklyCombatMissionInfo;

	UPROPERTY()
	TArray<FCharMissionCombat> CharCombatMissionInfo;
};

USTRUCT()
struct FSummonResult
{
	GENERATED_BODY()

	UPROPERTY()
	FBoxProductType BoxProductType;

	UPROPERTY()
	TArray<ELootCategory> Categories;

	UPROPERTY()
	TArray<bool> FirstOrNots;

	UPROPERTY()
	TArray<FCharacterInfo> Characters;

	UPROPERTY()
	TArray<FSculptureInfo> Sculptures;

	UPROPERTY()
	TArray<FRelicInfo> Relics;

	UPROPERTY()
	bool bPickup;

	UPROPERTY()
	bool bCanRepeatSummon;
};
