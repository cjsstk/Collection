// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatCube.h"
#include "CombatCubeUtil.h"
#include "CCAction.h"
#include "CCEvent.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6GameInstance.h"
#include "Q6CombatGameMode.h"
#include "JsonObjectConverter.h"
#include "BaseHUD.h"
#include "DebugWidgets.h"

TAutoConsoleVariable<int32> CVarQ6UseLobbyCombat(
	TEXT("Q6.UseLobbyCombat"),
	0,
	TEXT("use lobbyd combat cube.\n"),
	ECVF_Default);

ACombatCube::ACombatCube(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
	Store = CreateDefaultSubobject<UCCCombatCubeStore>(TEXT("CombatCubeStore"));
}

void ACombatCube::BeginPlay()
{
	Super::BeginPlay();

	Store->BindOnEvent();
}

void ACombatCube::SetMode(ECombatCubeMode InMode)
{
	Store->SetMode(InMode);
}

bool ACombatCube::IsTickableMode() const
{
	return Store->IsTickableMode();
}

bool ACombatCube::IsSavingChronicleMode() const
{
	return Store->IsSavingChronicleMode();
}

bool ACombatCube::IsBossRewardWave(const FCCCombatCubeState& InCubeState) const
{
	EContentType ContentType = InCubeState.CombatSeed.Content;
	if (ContentType == EContentType::DailyDungeon)
	{
		FSagaType SagaType = InCubeState.CombatSeed.SagaType;
		return GetCMS()->HasBossBonusDailyDungeon(SagaType) && InCubeState.IsLastWave();
	}

	if (ContentType == EContentType::Raid)
	{
		return true;
	}

	return false;
}

void ACombatCube::InitCombatCube(const FCCCombatSeed& Seed)
{
	Store->InitChronicle(Seed.SagaType);
	Store->SetRandomSeed(Seed);
	GetCheckedCombatPresenter(this)->SetStartBattleEpoch(Seed.Seed.StartBattleEpoch);

	Store->Dispatch(FCCInitCombatCubeAction(Seed));
}

void ACombatCube::InitCombatMission(const TArray<FMissionType>& InCombatWeeklyMission
	, const TArray<FCCCharacterMissionInfo>& InCombatCharacterMission)
{
	Store->Dispatch(FCCInitMissionAction(InCombatWeeklyMission, InCombatCharacterMission));
}

void ACombatCube::UseRaidTurnSkills()
{
	Store->Dispatch(FCCUseRaidTurnSkillAction());
}

void ACombatCube::AddRaidTurnSkills(const TArray<FCharSkill>& RaidTurnSkills, const TArray<FCharSkill>& RaidSupportSkills)
{
	Store->Dispatch(FCCAddRaidTurnSkillAction(RaidTurnSkills, RaidSupportSkills));
}

void ACombatCube::SaveChronicle()
{
	Store->SaveDevChronicle();
}

void ACombatCube::SaveOngoingChronicle()
{
	Store->SaveOngoingChronicle();
}

void ACombatCube::SetRaidInfoToChronicle(FRaidId InRaidId)
{
	Store->SetRaidInfoToChronicle(InRaidId);
}

ECombatCubeMode ACombatCube::GetMode() const
{
	return Store->GetMode();
}

void ACombatCube::ProceedToNextTurn()
{
	Store->Dispatch(FCCPassPhaseAction());
}

void ACombatCube::KillAllEnemies()
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this](FCCUnitId ReqUnitId, FCombatState RepState) {
		TArray<int32> Enemies = RepState.EnemyIds;
		for (int32 EnemyUnitId : Enemies)
		{
			Store->Dispatch(FCCCheatKillUnitAction(FCCUnitId(EnemyUnitId)));
		}
	}));
}

void ACombatCube::WinGame()
{
	Store->Dispatch(FCCCheatEndGameAction(ECCResult::Win));
}

void ACombatCube::KillTargetUnit()
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this](FCCUnitId ReqUnitId, FCombatState RepState) {
		FCCUnitId TargetUnitId(RepState.PlayerTargetUnitId);
		if (TargetUnitId != CCUnitIdInvalid)
		{
			Store->Dispatch(FCCCheatKillUnitAction(TargetUnitId));
		}
	}));
}

void ACombatCube::RebirthTargetUnit()
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this](FCCUnitId ReqUnitId, FCombatState RepState) {
		FCCUnitId TargetUnitId(RepState.PlayerTargetUnitId);
		if (TargetUnitId != CCUnitIdInvalid)
		{
			Store->Dispatch(FCCCheatRebirthUnitAction(TargetUnitId));
		}
	}));
}

void ACombatCube::ToggleNoDamage(UDebugCombatWidget* DebugCombatWidget)
{
	TWeakObjectPtr<UDebugCombatWidget> Widget(DebugCombatWidget);

	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda(
			[this, Widget](FCCUnitId ReqUnitId, FCombatState RepState) {
		if (!RepState.GameFlags.IsValidIndex((int32)EGameFlags::NoDamage))
		{
			return;
		}

		int32 InWidgetState = 0;
		if (RepState.GameFlags[(int32)EGameFlags::NoDamage])
		{
			Store->Dispatch(FCCCheatGameFlagAction(EGameFlags::NoDamage, 0));
			Q6JsonLogSunny(Display, "No Damage OFF");
		}
		else
		{
			Store->Dispatch(FCCCheatGameFlagAction(EGameFlags::NoDamage, 1));
			Q6JsonLogSunny(Display, "No Damage ON");
			InWidgetState = 1;
		}

		if (Widget.IsValid())
		{
			Widget->SetNoDamageState(InWidgetState);
		}
	}));
}

void ACombatCube::ToggleImmune(UDebugCombatWidget* DebugCombatWidget)
{
	TWeakObjectPtr<UDebugCombatWidget> Widget(DebugCombatWidget);

	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda(
			[this, Widget](FCCUnitId ReqUnitId, FCombatState RepState) {
		if (!RepState.GameFlags.IsValidIndex((int32)EGameFlags::Immune))
		{
			return;
		}

		int32 InWidgetState = 0;
		if (RepState.GameFlags[(int32)EGameFlags::Immune])
		{
			Store->Dispatch(FCCCheatGameFlagAction(EGameFlags::Immune, 0));
			Q6JsonLogSunny(Display, "Immune OFF");
		}
		else
		{
			Store->Dispatch(FCCCheatGameFlagAction(EGameFlags::Immune, 1));
			Q6JsonLogSunny(Display, "Immune ON");
			InWidgetState = 1;
		}
		if (Widget.IsValid())
		{
			Widget->SetImmuneState(InWidgetState);
		}
	}));
}

void ACombatCube::SetTargetUnitAttributeCheatValue(EUnitAttribute InUnitAttribute, int32 InValue)
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda(
			[this, InUnitAttribute, InValue](FCCUnitId ReqUnitId, FCombatState RepState) {

		Store->Dispatch(FCCCheatUnitAttributeAction(FCCUnitId(RepState.PlayerTargetUnitId), InUnitAttribute, true, InValue));
	}));
}

void ACombatCube::RevertTargetUnitAttributeCheatValue(EUnitAttribute InUnitAttribute)
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InUnitAttribute](FCCUnitId ReqUnitId, FCombatState RepState) {

		Store->Dispatch(FCCCheatUnitAttributeAction(FCCUnitId(RepState.PlayerTargetUnitId), InUnitAttribute, false, 0));
	}));
}

void ACombatCube::CheatFillAlliesUASA()
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this](FCCUnitId ReqUnitId, FCombatState RepState) {
		TArray<int32> Allies = RepState.AllyIds;
		for (int32 AllyUnitId : Allies)
		{
			Store->Dispatch(FCCCheatUAAction(FCCUnitId(AllyUnitId), 100));
			Store->Dispatch(FCCCheatSAAction(FCCUnitId(AllyUnitId), 100));
		}
	}));
}

void ACombatCube::CheatUA(int32 InUA)
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InUA](FCCUnitId ReqUnitId, FCombatState RepState) {
		Store->Dispatch(FCCCheatUAAction(FCCUnitId(RepState.PlayerTargetUnitId), InUA));
	}));
}

void ACombatCube::CheatFillUAForTutorial(FCCUnitId InTargetUnitId)
{
	Store->Dispatch(FCCCheatUAAction(InTargetUnitId, 100000));
}

void ACombatCube::CheatFillSAForTutorial(FCCUnitId InTargetUnitId)
{
	Store->Dispatch(FCCCheatSAAction(InTargetUnitId, 100000));
}

void ACombatCube::CheatSA(int32 InSA)
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InSA](FCCUnitId ReqUnitId, FCombatState RepState) {
		Store->Dispatch(FCCCheatSAAction(FCCUnitId(RepState.PlayerTargetUnitId), InSA));
	}));
}

void ACombatCube::CheatHealth(int32 InHealth)
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InHealth](FCCUnitId ReqUnitId, FCombatState RepState) {
		Store->Dispatch(FCCCheatHealthAction(FCCUnitId(RepState.PlayerTargetUnitId), InHealth));
	}));
}

void ACombatCube::CheatOverKill(int32 InOverKill)
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InOverKill](FCCUnitId ReqUnitId, FCombatState RepState) {
		Store->Dispatch(FCCCheatOverKillAction(FCCUnitId(RepState.PlayerTargetUnitId), InOverKill));
	}));
}

void ACombatCube::CheatBuff(int32 InBuffType, bool bInUltimate, int32 InDuration)
{
	const FCMSBuffRow& Row = CMS->GetBuffRowOrDummy(FBuffType(InBuffType));
	if (Row.IsInvalid())
	{
		Q6JsonLogObiwan(Warning, "not exist buff.", Q6KV("BuffType", InBuffType));
		return;
	}

	bool bIsProvokeBuff = false;
	for (const FCMSBuffEffectRow* E : Row.GetBuffEffect())
	{
		if (E->BuffEffectCategory != EBuffEffectCategory::ModifyCrowdControl)
		{
			continue;
		}

		const FCMSCrowdControlRow& InRow = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(E->Param1));
		if (InRow.CrowdControl == ECrowdControl::Provoke)
		{
			bIsProvokeBuff = true;
		}
	}

	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda(
			[this, InBuffType, bInUltimate, InDuration, bIsProvokeBuff](FCCUnitId ReqUnitId, FCombatState RepState) {

			FCCUnitId SourceUnitId = FCCUnitId(RepState.PlayerTargetUnitId);
			FCCUnitId TargetUnitId = FCCUnitId(RepState.PlayerTargetUnitId);

			if (bIsProvokeBuff)
			{
				// choose first enemy to source unit
				FCCUnitState UnitState;
				FJsonObjectConverter::JsonObjectStringToUStruct(RepState.PlayerTargetUnitState, &UnitState, 0, 0);
				if (UnitState.Faction == ECCFaction::Ally)
				{
					SourceUnitId = FCCUnitId(RepState.EnemyIds[0]);
				}
				else
				{
					SourceUnitId = FCCUnitId(RepState.AllyIds[0]);
				}
			}

			Store->Dispatch(FCCCheatCreateBuffAction(SourceUnitId, TargetUnitId, InBuffType, bInUltimate, InDuration));
	}));
}

void ACombatCube::DespawnUnit(FCCUnitId InUnitId)
{
	Store->Dispatch(FCCCheatDespawnUnitAction(InUnitId));
}

void ACombatCube::CheatReplaceUnit(FCCUnitId FromUnitId, FUnitType ToUnitType, ESpawnReason InReason)
{
	SelectTarget(FromUnitId); // for lobbyd/state api refresh.

	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda(
			[this, FromUnitId, ToUnitType, InReason](FCCUnitId ReqUnitId, FCombatState RepState) {

		FCCUnitState UnitState;
		FJsonObjectConverter::JsonObjectStringToUStruct(RepState.PlayerTargetUnitState, &UnitState, 0, 0);

		if (UnitState.UnitId == CCUnitIdInvalid)
		{
			return;
		}

		FCCCombatSeedUnit SummonSeedUnit;
		SummonSeedUnit.UnitType = ToUnitType;
		SummonSeedUnit.Faction = UnitState.Faction;
		SummonSeedUnit.Category = UnitState.Category;
		SummonSeedUnit.Level = UnitState.Level;
		SummonSeedUnit.Grade = UnitState.Grade;
		SummonSeedUnit.UltimateSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
		SummonSeedUnit.SupportSkillLevel = CombatCubeConst::Q6_MIN_SKILL_LEVEL;
		SummonSeedUnit.TurnSkillLevels.Init(CombatCubeConst::Q6_MIN_SKILL_LEVEL, CombatCubeConst::Q6_MAX_TURN_SKILL_COUNT);
		SummonSeedUnit.CharacterId = UnitState.CharacterId;

		FCCSpawnUnitParam NewUnit;
		UCombatCubeStateUtil::ConvertCombatSeedUnitToSpawnUnitParam(SummonSeedUnit, &NewUnit,
			InReason, UnitState.Slot, 0, 1000, 0);

		DespawnUnit(FromUnitId);

		if (ToUnitType != UnitTypeInvalid)
		{
			Store->Dispatch(FCCCheatSpawnSubUnitAction(NewUnit));
		}
	}));
}

void ACombatCube::CheatReplaceUnit(int32 InUnitType)
{
	if (InUnitType == UnitTypeInvalid.x)
	{
		return;
	}

	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InUnitType](FCCUnitId ReqUnitId, FCombatState RepState) {
		FCCUnitId TargetUnitId(RepState.PlayerTargetUnitId);
		CheatReplaceUnit(TargetUnitId, FUnitType(InUnitType), ESpawnReason::Cheat);
	}));
}

void ACombatCube::CheatResetCooldown(int32 InSkillId)
{
	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, InSkillId](FCCUnitId ReqUnitId, FCombatState RepState) {
		if (InSkillId == SkillTypeInvalid)
		{
			TArray<int32> Allies = RepState.AllyIds;
			for (const int32 AllyUnitId : Allies)
			{
				Store->Dispatch(FCCCheatCooldownAction(FCCUnitId(AllyUnitId), InSkillId));
			}
		}
		else
		{
			FCCUnitId TargetUnitId(RepState.PlayerTargetUnitId);
			Store->Dispatch(FCCCheatCooldownAction(TargetUnitId, InSkillId));
		}
	}));
}

void ACombatCube::CheatFixSkillNote(int32 Slot, ESkillNote Note, int32 Index)
{
	Store->Dispatch(FCCCheatFixSkillNoteAction(Slot, Note, Index));
}

void ACombatCube::CheatShuffleSkillNote(int32 Slot)
{
	Store->Dispatch(FCCCheatSkillNoteShuffleAction(Slot));
}

void ACombatCube::GetTargetCCUnitState(UDebugCombatWidget* DebugCombatWidget)
{
	TWeakObjectPtr<UDebugCombatWidget> Widget(DebugCombatWidget);

	Store->ReqCCState(
		CCUnitIdInvalid, FOnCCStateGot::CreateLambda([this, Widget](FCCUnitId ReqUnitId, FCombatState RepState) {
		if (!Widget.IsValid())
		{
			return;
		}

		FCCUnitState TargetUnitState;
		if (FJsonObjectConverter::JsonObjectStringToUStruct(RepState.PlayerTargetUnitState, &TargetUnitState, 0, 0))
		{
			Widget->SaveTargetInfoFromServer(TargetUnitState);

			const FCMSUnitRow& CMSUnitRow = GetCMS()->GetUnitRowOrDummy(TargetUnitState.UnitType);
			Widget->SetTargetInfo(TargetUnitState, CMSUnitRow);
		}
	}));
}

void ACombatCube::SelectTarget(FCCUnitId UnitId)
{
	Store->Dispatch(FCCSelectTargetAction(UnitId));
}

void ACombatCube::UseSkill(FCCUnitId UnitId, FCCSkillId SkillId, int32 TurnCount)
{
	FCCUseSkillAction Action(UnitId, SkillId, true, TurnCount, EPreferTarget::None, false);
	Store->Dispatch(Action);
}

void ACombatCube::TurnAction(FCCUnitId UnitId, FCCSkillId SkillId, int32 TurnCount)
{
	FCCUseTurnAction Action(UnitId, SkillId, true, TurnCount, EPreferTarget::None, false);
	Store->Dispatch(Action);
}

void ACombatCube::UseArtifact(FCCUnitId UnitId, int32 Index)
{
	FCCUseArtifactAction Action(UnitId, Index);
	Store->Dispatch(Action);
}

void ACombatCube::UseWipeoutContinue(int32 InResurrectionCount, bool bGemContinue)
{
	FCCWipeoutContinue Action(InResurrectionCount, bGemContinue);
	Store->Dispatch(Action);
}

void ACombatCube::Withdraw()
{
	const FCCCombatCubeState& CombatCubeState = GetState();
	EContentType ContentType = CombatCubeState.CombatSeed.Content;
	if (ContentType == EContentType::Raid)
	{
		Store->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::Withdraw));
	}
	else
	{
		Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Withdraw));
	}
}

void ACombatCube::UsePet(FCCUnitId UnitId, FCCSkillId SkillId)
{
	FCCUsePetAction Action(UnitId, SkillId);
	Store->Dispatch(Action);
}

void ACombatCube::UpdateFinishCondition(FCCCombatCubeState& CubeState) const
{
	if (CubeState.IsGameFinished() || !CubeState.IsInCombat())
	{
		return;
	}

	int32 AlliesCount;
	int32 EnemiesCount;
	bool bFinishCondition = CubeState.VerifyFinishCondition(AlliesCount, EnemiesCount);

	// if clear units are dead all, this game will end
	if (AlliesCount > 0 && CubeState.UnitsState.IsFinishConditionByClearUnits())
	{
		Store->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::ClearUnits));
		return;
	}

	if (!bFinishCondition)
	{
		return;
	}

	EContentType ContentType = CubeState.CombatSeed.Content;
	if (ContentType == EContentType::Raid)
	{
		Store->Dispatch(FCCEndGameAction(
			ECCResult::Win, EnemiesCount <= 0 ? ECCEndReason::None : ECCEndReason::Eliminated));
		return;
	}
	else if (ContentType == EContentType::RaidFinal)
	{
		Store->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::None));
		return;
	}

	if (CubeState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
	{
		int32 TotalEnemiesCount = CubeState.UnitsState.GetAliveUnitsAllOfCombatMultiSide(ECCFaction::Enemy).Num();
		int32 TotalAlliesCount = CubeState.UnitsState.GetAliveUnitsAllOfCombatMultiSide(ECCFaction::Ally).Num();

		if (TotalAlliesCount <= 0 && TotalEnemiesCount > 0)
		{
			// if turn count is 1, sub side units & enemies are not yet spawned
			if (CubeState.TurnState.TurnCount <= 1)
			{
				Store->Dispatch(FCCChangeCombatMultiSideAction(CubeState.TurnState.CurrentCombatMultiSide, false));
			}
			else
			{
				Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Eliminated));
			}
		}
		else if (TotalAlliesCount <= 0 && TotalEnemiesCount <= 0)
		{
			Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Eliminated));
		}
		else if (EnemiesCount <= 0)
		{
			if (CubeState.IsLastWave())
			{
				Store->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::None));
			}
			else
			{
				Store->Dispatch(FCCChangeCombatMultiSideAction(CubeState.TurnState.CurrentCombatMultiSide, true));
			}
		}
		else if (AlliesCount <= 0)
		{
			Store->Dispatch(FCCChangeCombatMultiSideAction(CubeState.TurnState.CurrentCombatMultiSide, false));
		}
		else
		{
			Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Eliminated));
		}
	}
	else
	{
		if (AlliesCount <= 0 && EnemiesCount > 0)
		{
			if (ContentType == EContentType::DailyDungeon)
			{
				if (IsBossRewardWave(CubeState))
				{
					Store->Dispatch(FCCEndGameAction(ECCResult::Tied, ECCEndReason::Eliminated));
				}
				else
				{
					Store->Dispatch(FCCAllyWipeoutAction());
				}
			}
			else
			{
				Store->Dispatch(FCCAllyWipeoutAction());
			}
		}
		else if (AlliesCount <= 0 && EnemiesCount <= 0)
		{
			if (ContentType == EContentType::DailyDungeon)
			{
				if (IsBossRewardWave(CubeState))
				{
					Store->Dispatch(FCCEndGameAction(ECCResult::Tied, ECCEndReason::Eliminated));
				}
				else
				{
					Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Eliminated));
				}
			}
			else
			{
				Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Eliminated));
			}
		}
		else if (EnemiesCount <= 0)
		{
			if (CubeState.IsLastWave())
			{
				Store->Dispatch(FCCEndGameAction(ECCResult::Win, ECCEndReason::None));
			}
			else
			{
				Store->Dispatch(FCCStartWaveAction(CubeState.GetNextWave()));
			}
		}
		else
		{
			if (ContentType == EContentType::DailyDungeon)
			{
				if (IsBossRewardWave(CubeState))
				{
					Store->Dispatch(FCCEndGameAction(ECCResult::Tied, ECCEndReason::Eliminated));
				}
				else
				{
					Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Eliminated));
				}
			}
			else
			{
				Store->Dispatch(FCCEndGameAction(ECCResult::Lost, ECCEndReason::Eliminated));
			}
		}
	}
}

void ACombatCube::MonsterUseTurnSkill(FCCCombatCubeState& CubeState, FCCUnitState* UnitState)
{
	bool bUse = false;
	for (const FCCSkillState* SkillState : UnitState->GetSkillStates(ESkillCategory::TurnBegin))
	{
		if (SkillState->IsPattern)
		{
			continue;
		}
		if (SkillState->IsInCooldown())
		{
			continue;
		}

		if (SkillState->IsInWaitdown())
		{
			Q6JsonLogObiwan(Display, "skill wait time",
				Q6KV("UnitType", UnitState->UnitType.x),
				Q6KV("skilltype", SkillState->SkillType),
				Q6KV("waitdown", SkillState->Waitdown));

			UCCSetSkillTimeEvent* Event = NewObject<UCCSetSkillTimeEvent>();
			Event->UnitId = UnitState->UnitId;
			Event->SkillId = SkillState->SkillId;
			Event->Cooldown = SkillState->Cooldown;
			Event->Waitdown = SkillState->Waitdown;
			Event->TimeDiff = 0;
			Event->SetSkillTimeType = ESetSkillTimeType::None;
			Store->OnEvent.Broadcast(Event);
			break;
		}

		FCCUseSkillAction UseSkillAction(UnitState->UnitId, SkillState->SkillId, false, CubeState.TurnState.TurnCount, EPreferTarget::None, false);
		Store->Dispatch(UseSkillAction);
		bUse = true;
		break;
	}

	if (bUse)
	{
		TArray<FCCSkillState*> TurnBegins = UnitState->GetSkillStates(ESkillCategory::TurnBegin);
		TurnBegins[0]->Waitdown = TurnBegins[0]->WaitTime;

		do
		{
			UCombatCubeStateUtil::ShiftSkillsPointer(TurnBegins);
		} while (TurnBegins[0]->IsPattern == true);
		if (TurnBegins[0]->Waitdown <= 0)
		{
			TurnBegins[0]->Waitdown = TurnBegins[0]->WaitTime;
		}
	}
}

void ACombatCube::MonsterUseTurnSkillByPattern(FCCCombatCubeState& CubeState, FCCUnitState* UnitState)
{
	for (const FCCPatternState& P : UnitState->Patterns)
	{
		const FCMSMonsterPatternRow& PRow = GetCMS()->GetMonsterPatternRowOrDummy(P.Type);
		FCCSkillState* S = UnitState->GetSkillState(P.SkillId);

		if (PRow.IsInvalid() || S == nullptr)
		{
			continue;
		}

		if (S->Category != ESkillCategory::TurnBegin)
		{
			continue;
		}
		if (S->IsInCooldown())
		{
			continue;
		}
		if (S->IsInWaitdown())
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsPatternMatched(PRow, UnitState, P))
		{
			continue;
		}

		Q6JsonLog(Display, "use pattern turnbegin skill", Q6KV("unit type", UnitState->UnitType),
			Q6KV("skill type", S->SkillType));

		const FCMSFormulaConstRow& Row = GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
		if (Row.RetreatSkillId == S->SkillType)
		{
			FCCUnitRetreatAction RetreatAction(UnitState->UnitId);
			Store->Dispatch(RetreatAction);
		}
		else
		{
			FCCUseSkillAction UseSkillAction(UnitState->UnitId, S->SkillId, false, CubeState.TurnState.TurnCount, PRow.PreferTarget, true);
			Store->Dispatch(UseSkillAction);
		}
	}
}

bool ACombatCube::MonsterUltimate(FCCCombatCubeState& CubeState, FCCUnitState* UnitState)
{
	bool UltimateUsed = false;
	if (UnitState->GetCrowdControlState(CMS, ECrowdControl::Silence) <= 0)
	{
		for (const FCCSkillState* SkillState : UnitState->GetSkillStates(ESkillCategory::Ultimate))
		{
			if (SkillState->IsPattern)
			{
				continue;
			}
			if (SkillState->IsInCooldown())
			{
				continue;
			}

			if (SkillState->IsInWaitdown())
			{
				Q6JsonLogObiwan(Display, "skill wait time",
					Q6KV("UnitType", UnitState->UnitType.x),
					Q6KV("skilltype", SkillState->SkillType),
					Q6KV("waitdown", SkillState->Waitdown));

				UCCSetSkillTimeEvent* Event = NewObject<UCCSetSkillTimeEvent>();
				Event->UnitId = UnitState->UnitId;
				Event->SkillId = SkillState->SkillId;
				Event->Cooldown = SkillState->Cooldown;
				Event->Waitdown = SkillState->Waitdown;
				Event->TimeDiff = 0;
				Event->SetSkillTimeType = ESetSkillTimeType::None;
				Store->OnEvent.Broadcast(Event);
				break;
			}

			FCCUseSkillAction UseSkillAction(UnitState->UnitId, SkillState->SkillId, false, CubeState.TurnState.TurnCount, EPreferTarget::None, false);
			Store->Dispatch(UseSkillAction);

			UltimateUsed = true;
			break;
		}

		if (UltimateUsed)
		{
			TArray<FCCSkillState*> Ultimates = UnitState->GetSkillStates(ESkillCategory::Ultimate);
			Ultimates[0]->Waitdown = Ultimates[0]->WaitTime;

			do
			{
				UCombatCubeStateUtil::ShiftSkillsPointer(Ultimates);
			} while (Ultimates[0]->IsPattern == true);
			if (Ultimates[0]->Waitdown <= 0)
			{
				Ultimates[0]->Waitdown = Ultimates[0]->WaitTime;
			}
		}
	}
	else
	{
		Q6JsonLogObiwan(Display, "unit silenced", Q6KV("UnitType", UnitState->UnitType.x));
	}

	return UltimateUsed;
}

void ACombatCube::MonsterNormal(FCCCombatCubeState& CubeState, FCCUnitState* UnitState)
{
	for (const FCCSkillState* SkillState : UnitState->GetSkillStates(ESkillCategory::Normal))
	{
		if (SkillState->IsPattern)
		{
			continue;
		}
		if (SkillState->IsInCooldown())
		{
			continue;
		}

		FCCUseSkillAction UseSkillAction(UnitState->UnitId, SkillState->SkillId, false, CubeState.TurnState.TurnCount, EPreferTarget::None, false);
		Store->Dispatch(UseSkillAction);
		return;
	}
}

bool ACombatCube::MonsterUltimateByPattern(FCCCombatCubeState& CubeState, FCCUnitState* UnitState)
{
	if (UnitState->SelectedPatternsUltimate != MonsterPatternTypeInvalid)
	{
		for (const FCCPatternState& P : UnitState->Patterns)
		{
			if (P.Type == UnitState->SelectedPatternsUltimate)
			{
				const FCMSMonsterPatternRow& PRow = GetCMS()->GetMonsterPatternRowOrDummy(P.Type);

				const FCMSFormulaConstRow& Row = GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
				if (Row.RetreatSkillId == PRow.GetSkill().Type)
				{
					FCCUnitRetreatAction RetreatAction(UnitState->UnitId);
					Store->Dispatch(RetreatAction);
				}
				else
				{
					FCCUseSkillAction UseSkillAction(UnitState->UnitId, P.SkillId, false, CubeState.TurnState.TurnCount, PRow.PreferTarget, true);
					Store->Dispatch(UseSkillAction);
				}

				return true;
			}
		}
		
	}

	return false;
}

bool ACombatCube::MonsterNormalByPattern(FCCCombatCubeState& CubeState, FCCUnitState* UnitState)
{
	for (const FCCPatternState& P : UnitState->Patterns)
	{
		const FCMSMonsterPatternRow& PRow = GetCMS()->GetMonsterPatternRowOrDummy(P.Type);
		FCCSkillState* S = UnitState->GetSkillState(P.SkillId);

		if (PRow.IsInvalid() || S == nullptr)
		{
			continue;
		}

		if (S->Category != ESkillCategory::Normal)
		{
			continue;
		}
		if (S->IsInCooldown())
		{
			continue;
		}
		if (S->IsInWaitdown())
		{
			continue;
		}

		if (!UCombatCubeStateUtil::IsPatternMatched(PRow, UnitState, P))
		{
			continue;
		}

		Q6JsonLog(Display, "use pattern normal skill", Q6KV("unit type", UnitState->UnitType),
			Q6KV("skill type", S->SkillType));

		const FCMSFormulaConstRow& Row = GetCMS()->GetFormulaConstValues(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
		if (Row.RetreatSkillId == S->SkillType)
		{
			FCCUnitRetreatAction RetreatAction(UnitState->UnitId);
			Store->Dispatch(RetreatAction);
		}
		else
		{
			FCCUseSkillAction UseSkillAction(UnitState->UnitId, S->SkillId, false, CubeState.TurnState.TurnCount, PRow.PreferTarget, true);
			Store->Dispatch(UseSkillAction);
		}

		return true;
	}

	return false;
}

void ACombatCube::MonsterAttackPass(FCCUnitState* UnitState)
{
	UCCEnemyAttackPassEvent* Event = NewObject<UCCEnemyAttackPassEvent>();
	Event->UnitId = UnitState->UnitId;
	Store->OnEvent.Broadcast(Event);
}

void ACombatCube::UpdatePhase(FCCCombatCubeState& CubeState)
{
	if (CubeState.IsGameFinished() || !CubeState.IsInCombat())
	{
		return;
	}

	if (CubeState.TurnState.CurrentPhase == ECCTurnPhase::Prepare)
	{
		Store->Dispatch(FCCChangePhaseTo(ECCTurnPhase::OppTurnSkill));
		return;
	}
	else if (CubeState.TurnState.CurrentPhase == ECCTurnPhase::OppTurnSkill)
	{
		for (FCCUnitState* UnitState : CubeState.UnitsState.GetAliveUnits(ECCFaction::Enemy))
		{
			if (UnitState->GetCrowdControlState(CMS, ECrowdControl::Stun) > 0)
			{
				continue;
			}

			if (UnitState->GetCrowdControlState(CMS, ECrowdControl::Silence) > 0)
			{
				continue;
			}

			MonsterUseTurnSkillByPattern(CubeState, UnitState);
			MonsterUseTurnSkill(CubeState, UnitState);
		}

		Store->Dispatch(FCCChangePhaseTo(ECCTurnPhase::TurnSkill));
		return;
	}
	else if (CubeState.TurnState.CurrentPhase == ECCTurnPhase::TurnSkill)
	{
		// change phase by combat presenter.
	}
	else if (CubeState.TurnState.CurrentPhase == ECCTurnPhase::Attack)
	{
		if (!CubeState.UnitsState.PossibleAttackByFaction(ECCFaction::Ally, CMS))
		{
			Store->Dispatch(FCCChangePhaseTo(ECCTurnPhase::OppAttack));
			return;
		}
	}
	else if (CubeState.TurnState.CurrentPhase == ECCTurnPhase::OppAttack)
	{
		for (FCCUnitState* UnitState : CubeState.UnitsState.GetAliveUnits(ECCFaction::Enemy))
		{
			if (!UnitState->HasSkillOnAttack())
			{
				continue;
			}

			if (UnitState->Category == EAttributeCategory::StaticMonster)
			{
				MonsterAttackPass(UnitState);
				continue;
			}

			if (UnitState->GetCrowdControlState(CMS, ECrowdControl::Stun) > 0)
			{
				continue;
			}

			const FCMSMonsterRow& MonsterRow = GetCMS()->GetMonsterRowOrDummy(FMonsterType(UnitState->UnitType.x));
			if (!MonsterUltimateByPattern(CubeState, UnitState))
			{
				if (!MonsterUltimate(CubeState, UnitState))
				{
					if (!MonsterNormalByPattern(CubeState, UnitState))
					{
						MonsterNormal(CubeState, UnitState);
					}
				}
			}
		}

		UpdateFinishCondition(CubeState);

		if (CubeState.CombatSeed.CombatMultiSideInfo.bIsCombatMultiSide)
		{
			Store->Dispatch(FCCChangeCombatMultiSideAction(CubeState.TurnState.CurrentCombatMultiSide, false));
		}
		else
		{
			Store->Dispatch(FCCChangePhaseTo(ECCTurnPhase::Prepare));
		}
		return;
	}
}

void ACombatCube::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!IsTickableMode())
	{
		return;
	}

	if (!CVarQ6UseLobbyCombat.GetValueOnGameThread())
	{
		FCCCombatCubeState& CubeState = const_cast<FCCCombatCubeState&>(Store->GetState());

		UpdateFinishCondition(CubeState);
		UpdatePhase(CubeState);
	}
}

///////////////////////////////////////////////////////////////////////////////
// UCCCombatCubeStoreUCCCombatCubeStore
///////////////////////////////////////////////////////////////////////////////

UCCCombatCubeStore::UCCCombatCubeStore(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CombatCubeMode(ECombatCubeMode::Normal)
{
	MT19937 = new FMT19937Uint32(0);
	CombatCubeState.InitSkillProp();
}

UCCCombatCubeStore::~UCCCombatCubeStore()
{
	delete MT19937;
	MT19937 = nullptr;
}

void UCCCombatCubeStore::SetRandomSeed(const FCCCombatSeed& CombatSeed)
{
	MT19937->Seed(CombatSeed.Seed.RandomSeed);
}

bool UCCCombatCubeStore::IsTickableMode() const
{
	switch (CombatCubeMode)
	{
	case ECombatCubeMode::Normal:
		return true;
	case ECombatCubeMode::Verification:
	default:
		return false;
	}
}

bool UCCCombatCubeStore::IsSavingChronicleMode() const // -V524
{
	switch (CombatCubeMode)
	{
	case ECombatCubeMode::Normal:
		return true;
	case ECombatCubeMode::Verification:
	default:
		return false;
	}
}

void UCCCombatCubeStore::OnCombatCubeEvent(const UCCEvent* Event)
{
	if (IsSavingChronicleMode())
	{
		return;
	}
#if !UE_BUILD_SHIPPING
	Chronicle.QueueEvent(Event);
#endif
}

void UCCCombatCubeStore::InitChronicle(FSagaType InSagaType)
{
	Chronicle.Init(InSagaType);
}

void UCCCombatCubeStore::SaveDevChronicle()
{
	if (!IsSavingChronicleMode())
	{
		return;
	}

#if !UE_BUILD_SHIPPING
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Chronicle.SagaType);

	FString JsonString = GetChronicleJson();
	FString CurDate = FDateTime::Now().ToString();
	FString Filename = FString::Printf(TEXT("%s_%d_%d_%d.json"), *CurDate, SagaRow.Episode, SagaRow.Stage, SagaRow.SubStage);

	FString OutputFilePath = FPaths::ProjectSavedDir() / "Chronicles" / Filename;
	if (!FFileHelper::SaveStringToFile(JsonString, *OutputFilePath))
	{
		Q6JsonLogBro(Error, "Failed to save output file", Q6KV("OutputFilePath", *OutputFilePath));
	}
#endif
}

void UCCCombatCubeStore::SaveOngoingChronicle()
{
	if (!IsSavingChronicleMode())
	{
		return;
	}

	UQ6GameInstance::Get()->SaveOngoingChronicleFile(Chronicle.ToJsonActions());
}

void UCCCombatCubeStore::SetRaidInfoToChronicle(FRaidId InRaidId)
{
	Chronicle.SetRaidInfo(InRaidId);
}

void UCCCombatCubeStore::BindOnEvent()
{
	OnEvent.AddDynamic(this, &UCCCombatCubeStore::OnCombatCubeEvent);
}

void UCCCombatCubeStore::Dispatch(const FCCAction& Action)
{
#if UE_BUILD_SHIPPING
	if (Action.IsDevAction())
	{
		return;
	}
#else
	if (IsSavingChronicleMode())
	{
		FCCAction* ClonedAction = Action.Clone();
		if (ClonedAction)
		{
			Chronicle.QueueAction(ClonedAction);
		}
	}
#endif
	if (!CVarQ6UseLobbyCombat.GetValueOnGameThread())
	{
		FActionContext Context({ MT19937, OnEvent });

		Action.DoAction(Context, CombatCubeState);

		OnChanged.Broadcast(CombatCubeState);
	}
	else
	{
		SendAction(Action);
	}

#if !UE_BUILD_SHIPPING
	if (IsSavingChronicleMode())
	{
		if (Action.GetActionType() == ECCActionType::EndGame)
		{
			SaveDevChronicle();
		}
	}
#endif
}

static TSharedPtr<FJsonValue> CCJSONReplacer(UProperty* Property, const void* Value)
{
	TSharedPtr<FJsonValue> NullSharedPtr;

	// replace enum "string" to integer
	if (UEnumProperty* EnumProperty = Cast<UEnumProperty>(Property))
	{
		return MakeShareable(new FJsonValueNumber(EnumProperty->GetUnderlyingProperty()->GetSignedIntPropertyValue(Value)));
	}

	return NullSharedPtr;
}

void UCCCombatCubeStore::SendAction(const FCCAction& Action)
{
	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();

	FJsonObjectConverter::CustomExportCallback cbDelegate;
	cbDelegate.BindStatic(&CCJSONReplacer);

	FString ActionJsonString;
	FJsonObjectConverter::UStructToJsonObjectString(Action.GetScriptStruct(), &Action, ActionJsonString, 0, 0, 0, &cbDelegate, false);

	struct FC2LCombatCubeAction Out;
	Out.ActionType = (int32)Action.GetActionType();
	Out.Msg = ActionJsonString;

	ClientNetwork.WsRequest(TEXT("combatCube/action"), Out,
		TQ6ResponseDelegate<FL2CCombatCubeActionResp>::CreateUObject(
			const_cast<UCCCombatCubeStore*>(this), &UCCCombatCubeStore::OnRecvEvent));
}

void UCCCombatCubeStore::OnRecvEvent(const FResError* Error, const FL2CCombatCubeActionResp& Res)
{
	if (Error) {
		GetBaseHUD(this)->OnError(Error);
		return;
	}

	AQ6CombatGameMode* InCombatGameMode = GetCombatGameMode(this);
	ensure(InCombatGameMode);

	TArray<UCCEvent*> Events = InCombatGameMode->ParseLobbyCCEvents(Res.Msg);

	for (const UCCEvent* E : Events)
	{
		OnEvent.Broadcast(E);
	}
}

void UCCCombatCubeStore::ReqCCState(const FCCUnitId& InSkillNoteUnitId, FOnCCStateGot ResponsCB)
{
	if (!CVarQ6UseLobbyCombat.GetValueOnGameThread())
	{
		FCombatState Ret;
		Ret.FinalBonusScore = CombatCubeState.CombatMultiSideState.FinalBonusScore;

		const FCCSkillState* Normal = CombatCubeState.UnitsState.GetNormalSkillByTurn(
			InSkillNoteUnitId, CombatCubeState.TurnState.TurnCount);
		Ret.NormalSkillIdByTurn = Normal ? Normal->SkillId.X : CCSkillIdInvalid.X;
		Ret.NormalSkillTypeByTurn = Normal ? Normal->SkillType : 0;

		const FCCSkillState* Ultimate = CombatCubeState.UnitsState.GetUltimateSkillByTurn(
			InSkillNoteUnitId, CombatCubeState.TurnState.TurnCount);
		Ret.UltimateSkillIdByTurn = Ultimate ? Ultimate->SkillId.X : CCSkillIdInvalid.X;
		Ret.UltimateSkillTypeByTurn = Ultimate ? Ultimate->SkillType : 0;

		Ret.CurrentPhase = (int32)CombatCubeState.TurnState.CurrentPhase;

		Ret.GemWipeoutContinueCount = CombatCubeState.GemWipeoutContinueCount;

		for (const FCCUnitState* UnitState : CombatCubeState.UnitsState.GetAliveUnits(ECCFaction::Enemy))
		{
			Ret.EnemyIds.Push(UnitState->UnitId.X);
		}

		for (const FCCUnitState* UnitState : CombatCubeState.UnitsState.GetAliveUnits(ECCFaction::Ally))
		{
			Ret.AllyIds.Push(UnitState->UnitId.X);
		}

		Ret.PlayerTargetUnitId = CombatCubeState.TurnState.PlayerTargetUnitId.X;

		FCCUnitState& UnitState = CombatCubeState.UnitsState.FindUnitState(CombatCubeState.TurnState.PlayerTargetUnitId);
		if (UnitState.UnitId == CCUnitIdInvalid)
		{
			Ret.PlayerTargetUnitState = FString("");
		}
		else
		{
			FJsonObjectConverter::CustomExportCallback cbDelegate;
			cbDelegate.BindStatic(&CCJSONReplacer);

			FString UnitStateJsonString;
			FJsonObjectConverter::UStructToJsonObjectString(UnitState, UnitStateJsonString, 0, 0, 0, nullptr, false);

			Ret.PlayerTargetUnitState = UnitStateJsonString;
		}

		Ret.GameFlags = CombatCubeState.GameFlags;

		ResponsCB.ExecuteIfBound(InSkillNoteUnitId, Ret);
		return;
	}

	struct FC2LCombatCubeState Out;
	Out.SkillNoteUnitId = InSkillNoteUnitId.X;

	FQ6ClientNetwork& ClientNetwork = UQ6GameInstance::Get()->GetClientNetwork();
	ClientNetwork.WsRequest(TEXT("combatCube/state"), Out,
		TQ6ResponseDelegate<FL2CCombatCubeStateResp>::CreateLambda(
			[=](const FResError* Error, const FL2CCombatCubeStateResp& Res)
	{
		if (Error) {
			GetBaseHUD(this)->OnError(Error);
			return;
		}

		ResponsCB.ExecuteIfBound(InSkillNoteUnitId, Res.State);
	}));
}

bool UCCCombatCubeStore::RestoreCCState(const FString& StateStr, FCCCombatCubeState& OutState)
{
	if (!FJsonObjectConverter::JsonObjectStringToUStruct(StateStr, &OutState, 0, 0))
	{
		Q6JsonLogNet(Error, "failed: RestoreCCState");
		return false;
	}

	return true;
}
