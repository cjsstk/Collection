// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6.h"
#include "Modules/ModuleManager.h"
#include "Q6Log.h"
#include "GameResource.h"
#include "Unit.h"
#include "BaseHUD.h"
#include "HUDStore.h"
#include "CombatHUD.h"
#include "LobbyHUD.h"
#include "SummonHUD.h"
#include "LevelUtil.h"
#include "LobbyPlayerController.h"
#include "Patch/Q6Patch.h"
#include "Q6Account.h"
#include "Q6CombatGameMode.h"
#include "Q6SummonGameMode.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "CombatCameraComponent.h"
#include "CombatPlayerController.h"
#include "SystemConst_gen.h"

#if WITH_EDITOR
#include "Editor.h"
#endif

const FCCUnitId CCUnitIdInvalid;
const FCCBuffId CCBuffIdInvalid;
const FCPInstanceId CCInstanceIdInvalid;
const FCCSkillId CCSkillIdInvalid;
const FCPInstanceId INITIALIZE_INSTANCE_ID(1);
const FCCSkillId INITIALIZE_SKILL_ID(1);
const TArray<int32> ALLY_AUTO_TARGET_SLOT_ORDER = {
	CombatCubeConst::Q6_ALLY_AUTO_TARGET_SLOT1__ORDER,
	CombatCubeConst::Q6_ALLY_AUTO_TARGET_SLOT2__ORDER,
	CombatCubeConst::Q6_ALLY_AUTO_TARGET_SLOT3__ORDER };

FQ6GameModuleImpl* FQ6GameModuleImpl::Singleton = nullptr;

IMPLEMENT_PRIMARY_GAME_MODULE(FQ6GameModuleImpl, Q6, "Q6");

#if WITH_EDITOR

static void OnPreSaveWorld(uint32 SaveFlags, UWorld* World)
{
	ULevelUtil::BuildCombatCameraCulling(World);

	for (TActorIterator<AUnit> It(World); It; ++It)
	{
		AUnit* Unit = *It;
		Unit->UnloadAsset();
	}
}

static void OnPostSaveWorld(uint32 SaveFlags, UWorld* World, bool bSuccess)
{
	if (!IsRunningCommandlet())
	{
		for (TActorIterator<AUnit> It(World); It; ++It)
		{
			AUnit* Unit = *It;
			Unit->StreamLoadAsset();
		}
	}
}

FDelegateHandle OnPreSaveWorldHandle;
FDelegateHandle OnPostSaveWorldHandle;

#endif // WITH_EDITOR


FQ6GameModuleImpl::FQ6GameModuleImpl()
	: GameResource(nullptr)
	, CMS(nullptr)
	, Patch(nullptr)
{
}

void FQ6GameModuleImpl::StartupModule()
{
	ApplyCVarSettingsFromIni(TEXT("Q6ConsoleVariables"), *GGameIni, ECVF_SetByProjectSetting);

	Q6JsonLog(Display, "Q6 Module Startup");
	FText VersionText = Q6Util::GetVersionText(true, true, true);
	Q6JsonLog(Display, "Q6 Version Info", Q6KV("Version", *VersionText.ToString()));

	FQ6GameModuleImpl::Singleton = this;

	FDefaultGameModuleImpl::StartupModule();

#if !USE_PATCH
#if WITH_EDITOR
	if (!IsRunningCommandlet())
	{
		LoadResource();
	}
#else
	LoadResource();
#endif
#else
	Patch = new FQ6Patch;
#endif

#if WITH_EDITOR
	UCombatCameraComponent::RegisterCustomDetails();
	OnPreSaveWorldHandle = FEditorDelegates::PreSaveWorld.AddStatic(&OnPreSaveWorld);
	OnPostSaveWorldHandle = FEditorDelegates::PostSaveWorld.AddStatic(&OnPostSaveWorld);
#endif

	Q6JsonLog(Display, "Q6 Module Startup - done");
}

void FQ6GameModuleImpl::ShutdownModule()
{
	Q6JsonLog(Display, "Q6 Module Shutdown");

	if (!GExitPurge && GameResource)
	{
		GameResource->RemoveFromRoot();
	}
	GameResource = nullptr;

	if (!GExitPurge && CMS)
	{
		CMS->RemoveFromRoot();
	}
	CMS = nullptr;

#if USE_PATCH
	if (Patch)
	{
		delete Patch;
		Patch = nullptr;
	}
#endif

	Q6JsonLog(Display, "Q6 Module Shutdown - done");
}

void FQ6GameModuleImpl::LoadResource()
{
	if (GameResource)
	{
		return;
	}

	Q6JsonLog(Display, "FQ6GameModuleImpl loading resources ..");

	UClass* GameResourceClass = StaticLoadClass(UGameResource::StaticClass(), NULL, TEXT("/Game/Resources/GameResourceBP.GameResourceBP_C"));

	if (!GameResourceClass)
	{
		// TODO: need to pop-up error msg to UI
		Q6JsonLog(Display, "Can't find GameResource file");
		return;
	}

	GameResource = NewObject<UGameResource>(GetTransientPackage(), GameResourceClass);
	check(GameResource);
	GameResource->AddToRoot();

	CMS = NewObject<UCMS>();
	check(CMS);
	CMS->LoadCMS();
	CMS->AddToRoot();

	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	if (GameInstance && GameInstance->IsHUDStoreInitialized())
	{
		GetHUDStore().OnPostLoadResource();
	}

	Q6JsonLog(Display, "FQ6GameModuleImpl loading resources .. done!");
}

UGameResource& FQ6GameModuleImpl::GetGameResource() const
{
	check(GameResource);
	return *GameResource;
}

UGameResource* FQ6GameModuleImpl::GetGameResourcePtr() const
{
	return GameResource;
}

UCMS* FQ6GameModuleImpl::GetCMS() const
{
	check(CMS);
	return CMS;
}

APlayerController* GetLocalPlayerController(const UObject* Object)
{
	// we don't care about split-screen game (which has multiple local players)
	// codes are based on World::GetFirstLocalPlayerFromController
	UWorld* World = GEngine->GetWorldFromContextObjectChecked(Object);
	if (!World)
	{
		return nullptr;
	}

	for (FConstPlayerControllerIterator Iterator = World->GetPlayerControllerIterator(); Iterator; ++Iterator)
	{
		APlayerController* PlayerController = Iterator->IsValid() ? Iterator->Get() : nullptr;
		if (PlayerController)
		{
			ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(PlayerController->Player);
			if (LocalPlayer)
			{
				return PlayerController;
			}
		}
	}

	return nullptr;
}

ALobbyPlayerController* GetLobbyPlayerController(const UObject* Object)
{
	return Cast<ALobbyPlayerController>(GetLocalPlayerController(Object));
}

ACombatPlayerController* GetCombatPlayerController(const UObject* Object)
{
	return Cast<ACombatPlayerController>(GetLocalPlayerController(Object));
}

FQ6GameModuleImpl* GetGameModule()
{
	return FQ6GameModuleImpl::Get();
}

UGameResource& GetGameResource()
{
	return GetGameModule()->GetGameResource();
}

UGameResource* GetGameResourcePtr()
{
	return GetGameModule()->GetGameResourcePtr();
}

UCMS* GetCMS()
{
	return GetGameModule()->GetCMS();
}

UUIResource& GetUIResource()
{
	return GetGameModule()->GetGameResource().GetUIResource();
}

UUIClassResource& GetUIClassResource()
{
	return GetGameModule()->GetGameResource().GetUIClassResource();
}

USoundResource& GetGameSoundResource()
{
	return GetGameModule()->GetGameResource().GetSoundResource();
}

ASummonHUD* GetSummonHUD(const UObject* Object)
{
	APlayerController* PlayerController = GetLocalPlayerController(Object);
	return PlayerController ? Cast<ASummonHUD>(PlayerController->GetHUD()) : nullptr;
}

ASummonHUD* GetCheckedSummonHUD(const UObject* Object)
{
	APlayerController* PlayerController = GetLocalPlayerController(Object);
	check(PlayerController);
	return CastChecked<ASummonHUD>(PlayerController->GetHUD());
}

ABaseHUD* GetBaseHUD(const UObject* Object)
{
	APlayerController* PlayerController = GetLocalPlayerController(Object);
	return PlayerController ? Cast<ABaseHUD>(PlayerController->GetHUD()) : nullptr;
}

ACombatHUD* GetCombatHUD(const UObject* Object)
{
	APlayerController* PlayerController = GetLocalPlayerController(Object);
	return PlayerController ? Cast<ACombatHUD>(PlayerController->GetHUD()) : nullptr;
}

ACombatHUD* GetCheckedCombatHUD(const UObject* Object)
{
	APlayerController* PlayerController = GetLocalPlayerController(Object);
	check(PlayerController);
	return CastChecked<ACombatHUD>(PlayerController->GetHUD());
}

AQ6CombatGameMode* GetCombatGameMode(const UObject* Object)
{
	UWorld* World = Object->GetWorld();
	return World ? Cast<AQ6CombatGameMode>(World->GetAuthGameMode()) : nullptr;
}

AQ6SummonGameMode* GetSummonGameMode(const UObject* Object)
{
	UWorld* World = Object->GetWorld();
	return World ? Cast<AQ6SummonGameMode>(World->GetAuthGameMode()) : nullptr;
}

ACombatCube* GetCheckedCombatCube(const UObject* Object)
{
	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(Object);
	check(CombatGameMode && CombatGameMode->CombatCube);
	return CombatGameMode->CombatCube;
}

ACombatPresenter* GetCheckedCombatPresenter(const UObject* Object)
{
	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(Object);
	check(CombatGameMode && CombatGameMode->Presenter);
	return CombatGameMode->Presenter;
}

UCombatGameResource* GetCombatGameResource(const UObject* Object)
{
	AQ6CombatGameMode* CombatGameMode = GetCombatGameMode(Object);
	return CombatGameMode ? CombatGameMode->GetCombatGameResource() : nullptr;
}

ALobbyHUD* GetLobbyHUD(const UObject* Object)
{
	APlayerController* PlayerController = GetLocalPlayerController(Object);
	return PlayerController ? Cast<ALobbyHUD>(PlayerController->GetHUD()) : nullptr;
}

ALobbyTutorial* GetLobbyTutorial(const UObject* InObject)
{
	ALobbyHUD* InLobbyHUD = GetLobbyHUD(InObject);
	return InLobbyHUD ? InLobbyHUD->GetLobbyTutorial() : nullptr;
}

ACombatTutorial* GetCombatTutorial(const UObject* InObject)
{
	ACombatHUD* InCombatHUD = GetCombatHUD(InObject);
	return InCombatHUD ? InCombatHUD->GetCombatTutorial() : nullptr;
}

ABaseTutorial* GetBaseTutorial(const UObject* InObject)
{
	ABaseHUD* InBaseHUD = GetBaseHUD(InObject);
	return InBaseHUD ? InBaseHUD->GetTutorial() : nullptr;
}

UQ6SaveGame* GetQ6SaveGame()
{
	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	check(GameInstance);
	return GameInstance->GetSaveGame();
}

ALobbyHUD* GetCheckedLobbyHUD(const UObject* Object)
{
	APlayerController* PlayerController = GetLocalPlayerController(Object);
	check(PlayerController);
	return CastChecked<ALobbyHUD>(PlayerController->GetHUD());
}

UCombatGameResource& GetCheckedCombatGameResource(const UObject* Object)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(Object);
	check(CombatGameResource);
	return *CombatGameResource;
}

UQ6SoundPlayer& GetSoundPlayer()
{
	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	check(GameInstance);
	return GameInstance->GetSoundPlayer();
}

UCharacterVoiceHelper* GetCharacterVoiceHelper()
{
	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	return GameInstance ? GameInstance->GetCharacterVoiceHelper() : nullptr;
}

const UWorldUser& GetUser()
{
	return GetHUDStore().GetWorldUser();
}

UHUDStore& GetHUDStore()
{
	UQ6GameInstance* GameInstance = UQ6GameInstance::Get();
	check(GameInstance);
	return GameInstance->GetHUDStore();
}
