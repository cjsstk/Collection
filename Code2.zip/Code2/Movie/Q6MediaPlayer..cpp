// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6MediaPlayer.h"
#include "Engine.h"
#include "Q6.h"
#include "MediaSoundComponent.h"
#include "MediaPlayer.h"
#include "WidgetUtil.h"
#include "MediaPlayerWidget.h"

#define LOCTEXT_NAMESPACE "Q6MovieActor"

AQ6MediaPlayer::AQ6MediaPlayer(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	RootComponent = MediaSoundComponent = CreateDefaultSubobject<UMediaSoundComponent>(TEXT("MediaSoundComponent"));
	MediaPlayerWidget = nullptr;
}

bool AQ6MediaPlayer::OpenSource(UFileMediaSource* MediaSource)
{
	return OpenSource(MediaSource, FSimpleDelegate());
}

bool AQ6MediaPlayer::OpenSource(UFileMediaSource* MediaSource, FSimpleDelegate InFinishedCallback)
{
	if (!MediaSource)
	{
		return false;
	}

	if (!MediaPlayerWidget)
	{
		MediaPlayerWidget = CreateWidget<UMediaPlayerWidget>(GetLocalPlayerController(this), MediaPlayerWidgetClass.LoadSynchronous());

		if (!MediaPlayerWidget)
		{
			return false;
		}
	}

	if (MediaSoundComponent && !MediaSoundComponent->GetMediaPlayer())
	{
		MediaSoundComponent->SetMediaPlayer(MediaPlayerWidget->GetMediaPlayer());
	}

	return MediaPlayerWidget->OpenSource(MediaSource, InFinishedCallback);
}

void AQ6MediaPlayer::CloseMediaPlayer()
{
	if (!MediaPlayerWidget)
	{
		return;
	}

	MediaPlayerWidget->CloseMediaPlayer();
}

#undef LOCTEXT_NAMESPACE