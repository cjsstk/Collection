// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "GameFramework/Actor.h"
#include "Q6Minimal.h"
#include "Q6MediaPlayer.generated.h"

class UMediaSoundComponent;
class UFileMediaSource;
class UMediaPlayerWidget;

UCLASS(ShowCategories = (Actor))
class Q6_API AQ6MediaPlayer : public AActor
{
	GENERATED_BODY()
public:
	UPROPERTY(EditAnywhere, Category = Movie)
	TSoftClassPtr<UMediaPlayerWidget> MediaPlayerWidgetClass;

public:
	AQ6MediaPlayer(const FObjectInitializer& ObjectInitializer);

	UFUNCTION(BlueprintCallable)
	bool OpenSource(UFileMediaSource* MediaSource);

	bool OpenSource(UFileMediaSource* MediaSource, FSimpleDelegate InFinishedCallback);

	UFUNCTION(BlueprintCallable)
	void CloseMediaPlayer();

private:
	UPROPERTY(EditAnywhere, Category = Movie)
	UMediaSoundComponent* MediaSoundComponent;

	UPROPERTY(Transient)
	UMediaPlayerWidget* MediaPlayerWidget;
};