
#include "Chronicle.h"
#include "CombatCube/CombatCube.h"
#include "CombatPresenter.h"
#include "JsonObjectConverter.h"
#include "LobbyObj_gen.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "RaidManager.h"
#include "Utils/LevelUtil.h"

extern TAutoConsoleVariable<int32> CVarQ6UseLobbyCombat;

FChronicle::FChronicle() : NextChronicleId(1)
{

}

void FChronicle::QueueAction(FCCAction* InAction)
{
	FChronicleAction NewAction;
	NewAction.ChronicleId = NextChronicleId;
	NewAction.Action = InAction;

	ChronicleActions.Add(NewAction);

	++NextChronicleId;
}

void FChronicle::QueueEvent(const UCCEvent* InEvent)
{
	FChronicleEvent NewEvent;
	NewEvent.ChronicleId = NextChronicleId;
	NewEvent.Event = InEvent;

	ChronicleEvents.Add(NewEvent);

	++NextChronicleId;
}

void FChronicle::WriteActionsInternal(TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>>& OutWriter) const
{
	if (!RaidId.IsInvalid())
	{
		OutWriter->WriteObjectStart(TEXT("raidInfo"));
		OutWriter->WriteValue(TEXT("RaidId"), RaidId.S);
		OutWriter->WriteObjectEnd();
	}

	OutWriter->WriteArrayStart(TEXT("actions"));
	const UEnum* ActionEnumPtr = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECCActionType"));
	for (const FChronicleAction& IterAction : ChronicleActions)
	{
		OutWriter->WriteObjectStart();
		FString CommandJsonString;
		FJsonObjectConverter::UStructToJsonObjectString(IterAction.Action->GetScriptStruct(), IterAction.Action, CommandJsonString, 0, 0);
		OutWriter->WriteValue(TEXT("ChronicleId"), IterAction.ChronicleId);
		FString StringValue = ActionEnumPtr->GetNameStringByValue((int64)IterAction.Action->GetActionType());
		OutWriter->WriteValue(TEXT("ActionType"), StringValue);
		OutWriter->WriteRawJSONValue(TEXT("Action"), CommandJsonString);
		OutWriter->WriteObjectEnd();
	}
	OutWriter->WriteArrayEnd();
}

void FChronicle::WriteEventsInternal(TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>>& OutWriter) const
{
	OutWriter->WriteArrayStart(TEXT("events"));
	const UEnum* EventEnumPtr = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECCEventType"));
	for (const FChronicleEvent& IterEvent : ChronicleEvents)
	{
		OutWriter->WriteObjectStart();
		FString CommandJsonString;
		FJsonObjectConverter::UStructToJsonObjectString(IterEvent.Event->GetClass(), IterEvent.Event, CommandJsonString, 0, 0);
		OutWriter->WriteValue(TEXT("ChronicleId"), IterEvent.ChronicleId);
		FString StringValue = EventEnumPtr->GetNameStringByValue((int64)IterEvent.Event->GetEventType());
		OutWriter->WriteValue(TEXT("EventType"), StringValue);
		OutWriter->WriteRawJSONValue(TEXT("Event"), CommandJsonString);
		OutWriter->WriteObjectEnd();
	}
	OutWriter->WriteArrayEnd();
}

FString FChronicle::ToJson() const
{
	FString ChronicleString;
	TSharedRef<TJsonWriter<TCHAR>> JsonWriter = TJsonWriterFactory<TCHAR>::Create(&ChronicleString);
	JsonWriter->WriteObjectStart();
	{
		WriteActionsInternal(JsonWriter);
		WriteEventsInternal(JsonWriter);
	}

	JsonWriter->WriteObjectEnd();
	JsonWriter->Close();

	return ChronicleString;
}

FString FChronicle::ToJsonActions() const
{
	FString ChronicleString;
	TSharedRef<TJsonWriter<TCHAR>> JsonWriter = TJsonWriterFactory<TCHAR>::Create(&ChronicleString);
	JsonWriter->WriteObjectStart();
	{
		WriteActionsInternal(JsonWriter);
	}
	JsonWriter->WriteObjectEnd();
	JsonWriter->Close();

	return ChronicleString;
}

void FChronicle::SetRaidInfo(FRaidId InRaidId)
{
	RaidId = InRaidId;
}

void FChronicle::Clear()
{
	NextChronicleId = 1;
	for (FChronicleAction& IterAction : ChronicleActions)
	{
		delete IterAction.Action;
	}
	ChronicleActions.Empty();
	ChronicleEvents.Empty();
}

void FChronicle::Init(FSagaType InSagaType)
{
	SagaType = InSagaType;

	Clear();
}

#define REGISTER_CCEVENT_OBJECT_FACTORY(CCEventType, EventObject) CreateEventFunctions[(int32)CCEventType] = &UChronicleLoader::CreatedEventObject<EventObject>;
#define REGISTER_CCACTION_STRUCT_FACTORY(CCActionType, ActionStruct) CreateActionFunctions[(int32)CCActionType] = &UChronicleLoader::CreatedActionStruct<ActionStruct>;

void UChronicleLoader::InitLoader()
{
	EventTypeEnum = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECCEventType"), true);
	check(EventTypeEnum);

	CreateEventFunctions.Reset(EventTypeEnum->NumEnums());
	CreateEventFunctions.AddZeroed(EventTypeEnum->NumEnums());
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::ReportError, UCCReportErrorEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::StartGame, UCCStartGameEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::StartWave, UCCStartWaveEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::TakeTurn, UCCTakeTurnEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::StartTurn, UCCStartTurnEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::StartPhase, UCCStartPhaseEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SkillUsed, UCCSkillUsedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SkillEnd, UCCSkillEndEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SkillFailed, UCCSkillFailedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::AttackPass, UCCAttackPassEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SkillEffect, UCCSkillEffectEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SkillEffectHealth, UCCSkillEffectHealthEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::PointVaryUsed, UCCPointVaryUsedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::PointVaryStateChanged, UCCPointVaryStateChangedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::PointVaryEnd, UCCPointVaryEndEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::HealthChanged, UCCUnitHealthChangedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SpawnUnit, UCCSpawnUnitEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::DespawnUnit, UCCDespawnUnitEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::UnitDead, UCCUnitDeadEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::AllyWipeout, UCCAllyWipeoutEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::EndGame, UCCEndGameEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::Target, UCCTargetSelectedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::UAChanged, UCCUnitUAChangedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SAChanged, UCCUnitSAChangedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::OverKillChanged, UCCUnitOverKillChangedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SetSkillCooldown, UCCSetSkillTimeEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SetCheatSkillCooldown, UCCSetCheatSkillCooldownEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::CreateBuff, UCCCreateBuffEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::RemoveBuff, UCCRemoveBuffEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::RemoveBuffFailed, UCCRemoveBuffFailedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::ImmuneBuff, UCCImmuneBuffEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::DamageBuff, UCCDamageBuffEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::HealBuff, UCCHealBuffEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::UpdateAttributes, UCCUpdateAttributesEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::UpdateBuffDurations, UCCUpdateBuffDurationsEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::RaidTurnSkillEffect, UCCRaidTurnSkillEffectEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::RaidTurnSkillFinished, UCCRaidTurnSkillFinishedEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::RaidSkillUsed, UCCRaidSkillUsed);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::CombatMission, UCCMissionEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::SelectedPatternUltimate, UCCSelectedPatternUltimate);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::EnemyAttackPass, UCCEnemyAttackPassEvent);
	REGISTER_CCEVENT_OBJECT_FACTORY(ECCEventType::ChangeCombatMultiSide, UCCChangeCombatMultiSide);

	for (int32 i = (int32)ECCEventType::Invalid + 1; i < (int32)ECCEventType::Max; ++i)
	{
		if (!CreateEventFunctions[i])
		{
			Q6JsonLogNet(Error, "Hey! New ECCEventType, New CreateEventFunctions here. Remember.", Q6KV("EventType", i));
		}
	}

	ActionTypeEnum = FindObject<UEnum>(ANY_PACKAGE, TEXT("ECCActionType"), true);
	check(ActionTypeEnum);

	CreateActionFunctions.Reset(ActionTypeEnum->NumEnums());
	CreateActionFunctions.AddZeroed(ActionTypeEnum->NumEnums());

	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::InitCombatCube, FCCInitCombatCubeAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::StartWave, FCCStartWaveAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::PassPhase, FCCPassPhaseAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::SelectTarget, FCCSelectTargetAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::UseSkill, FCCUseSkillAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::UseTurnAction, FCCUseTurnAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::UseArtifact, FCCUseArtifactAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::WipeoutContinue, FCCWipeoutContinue);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::UsePet, FCCUsePetAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::RetreatUnit, FCCUnitRetreatAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::ChangePhaseTo, FCCChangePhaseTo);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::AllyWipeout, FCCAllyWipeoutAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::EndGame, FCCEndGameAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatSpawnSubUnit, FCCCheatSpawnSubUnitAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatCreateBuff, FCCCheatCreateBuffAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatKillUnit, FCCCheatKillUnitAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatRebirthUnit, FCCCheatRebirthUnitAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatGameFlag, FCCCheatGameFlagAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatUnitAttribute, FCCCheatUnitAttributeAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatUA, FCCCheatUAAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatSA, FCCCheatSAAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatHealth, FCCCheatHealthAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatOverKill, FCCCheatOverKillAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatDespawnUnit, FCCCheatDespawnUnitAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatCooldown, FCCCheatCooldownAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatEndGame, FCCCheatEndGameAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatFixSkillNote, FCCCheatFixSkillNoteAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::CheatSkillNoteShuffle, FCCCheatSkillNoteShuffleAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::AddRaidTurnSkill, FCCAddRaidTurnSkillAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::UseRaidTurnSkill, FCCUseRaidTurnSkillAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::InitCombatWeeklyMission, FCCInitMissionAction);
	REGISTER_CCACTION_STRUCT_FACTORY(ECCActionType::ChangeCombatMultiSide, FCCChangeCombatMultiSideAction);

	for (int32 i = (int32)ECCActionType::Invalid + 1; i < (int32)ECCActionType::Max; ++i)
	{
		if (!CreateActionFunctions[i])
		{
			Q6JsonLogNet(Error, "Hey! New ECCActionType, New CreateActionFunctions here. Remember.", Q6KV("ActionType", i));
		}
	}

	bInitLoader = true;
}

FRaidId UChronicleLoader::GetRaidId() const
{
	return RaidId;
}

FSagaType UChronicleLoader::GetSagaTypeFromChronicle(FString InChronicleJSon) const
{
	// no need bInitLoader, doesn't use LoadedElements.

	TSharedPtr<FJsonObject> JsonChronicle;
	TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(InChronicleJSon);
	if (!FJsonSerializer::Deserialize(JsonReader, JsonChronicle) || !JsonChronicle.IsValid())
	{
		return SagaTypeInvalid;
	}

	const TArray<TSharedPtr<FJsonValue>>* JSonActions = nullptr;
	if (!JsonChronicle->TryGetArrayField(TEXT("actions"), JSonActions))
	{
		return SagaTypeInvalid;
	}

	if (!JSonActions || !JSonActions->IsValidIndex(0))
	{
		return SagaTypeInvalid;
	}

	// check for allies wiped out
	int32 NumOfWipeout = 0;
	int32 NumOfWipeoutContinue = 0;
	for (int i = 0; i < (*JSonActions).Num(); ++i)
	{
		const TSharedPtr<FJsonObject>& ActionObject = (*JSonActions)[i]->AsObject();
		const FString& StringField = ActionObject->GetStringField(TEXT("ActionType"));
		if (StringField == TEXT("AllyWipeout"))
		{
			NumOfWipeout++;
		}
		else if (StringField == TEXT("WipeoutContinue"))
		{
			NumOfWipeoutContinue++;
		}
	}
	if (NumOfWipeout > NumOfWipeoutContinue)
	{
		return SagaTypeInvalid;
	}

	const TSharedPtr<FJsonObject>& InitCombatCubeActionJson = (*JSonActions)[0]->AsObject();
	if (!InitCombatCubeActionJson.IsValid())
	{
		return SagaTypeInvalid;
	}

	const TSharedPtr<FJsonObject>& ActionStructJson = InitCombatCubeActionJson->GetObjectField(TEXT("Action"));
	if (!ActionStructJson.IsValid())
	{
		return SagaTypeInvalid;
	}

	const TSharedPtr<FJsonObject>& SeedJson = ActionStructJson->GetObjectField(TEXT("seed"));
	if (!SeedJson.IsValid())
	{
		return SagaTypeInvalid;
	}

	const TSharedPtr<FJsonObject>& SagaTypeJson = SeedJson->GetObjectField(TEXT("sagaType"));
	if (!SagaTypeJson.IsValid())
	{
		return SagaTypeInvalid;
	}

	return FSagaType(SagaTypeJson->GetIntegerField(TEXT("x")));
}

TArray<UCCEvent*> UChronicleLoader::ParseLobbyCCEvents(const FString& Msg)
{
	TArray<UCCEvent*> Ret;
	TSharedPtr<FJsonObject> JsonMsg;
	TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(Msg);
	if (!FJsonSerializer::Deserialize(JsonReader, JsonMsg) || !JsonMsg.IsValid())
	{
		Q6JsonLogNet(Error, "ParseLobbyCCEvents:Deserialize");
		return Ret;
	}

	const TArray<TSharedPtr<FJsonValue>>* JSonEvents = nullptr;
	if (!JsonMsg->TryGetArrayField(TEXT("events"), JSonEvents))
	{
		Q6JsonLogNet(Error, "ParseLobbyCCEvents:get events");
		return Ret;
	}

	for (const auto& JSonEvent : *JSonEvents)
	{
		const TSharedPtr<FJsonObject>& JsonEventObject = JSonEvent->AsObject();
		FString EventTypeStr = JsonEventObject->GetStringField(TEXT("type"));
		ECCEventType InEventType = (ECCEventType)EventTypeEnum->GetValueByIndex(FCString::Atoi(*EventTypeStr));
		UCCEvent* CreatedEvent = CreateEventByType(InEventType);
		if (!CreatedEvent)
		{
			Q6JsonLogNet(Error, "ParseLobbyCCEvents:CreateEventByType", Q6KV("EventType", (int32)InEventType));
			return Ret;
		}

		const TSharedPtr<FJsonObject>& JSonEventStructObject = JsonEventObject->GetObjectField(TEXT("event"));
		if (!FJsonObjectConverter::JsonObjectToUStruct(JSonEventStructObject.ToSharedRef(), CreatedEvent->GetClass(), CreatedEvent, 0, 0))
		{
			Q6JsonLogNet(Error, "ParseLobbyCCEvents:get event", Q6KV("EventType", (int32)InEventType));
			return Ret;
		}

		Ret.Add(CreatedEvent);
	}

	return Ret;
}

bool UChronicleLoader::LoadFromString(FString ChronicleJsonStr, bool bInLoadEvents, TArray<FChronicleElement>* LoadedElements, EQ6Judgement* OutLoadingError)
{
	if (!bInitLoader)
	{
		(*OutLoadingError) = EQ6Judgement::InternalError;
		return false;
	}

	TSharedPtr<FJsonObject> JsonChronicle;
	TSharedRef<TJsonReader<>> JsonReader = TJsonReaderFactory<>::Create(ChronicleJsonStr);
	if (!FJsonSerializer::Deserialize(JsonReader, JsonChronicle) || !JsonChronicle.IsValid())
	{
		(*OutLoadingError) = EQ6Judgement::JSonInvalidDeserialize;
		return false;
	}

	const TSharedPtr<FJsonObject>* JsonRaidInfo = nullptr;
	if (JsonChronicle->TryGetObjectField(TEXT("raidInfo"), JsonRaidInfo))
	{
		RaidId = FRaidId(JsonRaidInfo->Get()->GetIntegerField(TEXT("RaidId")));
	}

	const TArray<TSharedPtr<FJsonValue>>* JSonActions = nullptr;
	if (!JsonChronicle->TryGetArrayField(TEXT("actions"), JSonActions))
	{
		(*OutLoadingError) = EQ6Judgement::JSonInvalidNoActions;
		return false;
	}
	int32 ActionsNum = JSonActions->Num();

	int32 EventsNum = 0;
	const TArray<TSharedPtr<FJsonValue>>* JSonEvents = nullptr;
	if (bInLoadEvents)
	{
		if (!JsonChronicle->TryGetArrayField(TEXT("events"), JSonEvents))
		{
			(*OutLoadingError) = EQ6Judgement::JSonInvalidNoEvents;
			return false;
		}
		EventsNum = JSonEvents->Num();
	}

	int32 ElementCount = ActionsNum + EventsNum + 1; //ChronicleId start from 1
	LoadedElements->Reset(ElementCount);
	LoadedElements->AddZeroed(ElementCount);

	for (const auto& JSonAction : *JSonActions)
	{
		const TSharedPtr<FJsonObject>& JsonActionObject = JSonAction->AsObject();
		int32 ChronicleId = JsonActionObject->GetIntegerField(TEXT("ChronicleId"));
		FString ActionTypeStr = JsonActionObject->GetStringField(TEXT("ActionType"));
		ECCActionType InActionType = (ECCActionType)ActionTypeEnum->GetValueByName(*ActionTypeStr);
		FCCAction* CreatedAction = CreateActionByType(InActionType);
		if (!CreatedAction)
		{
			(*OutLoadingError) = EQ6Judgement::JSonInvalidUnknowAction;
			return false;
		}

		const TSharedPtr<FJsonObject>& JSonActionStructObject = JsonActionObject->GetObjectField(TEXT("Action"));
		if (!FJsonObjectConverter::JsonObjectToUStruct(JSonActionStructObject.ToSharedRef(), CreatedAction->GetScriptStruct(), CreatedAction, 0, 0))
		{
			(*OutLoadingError) = EQ6Judgement::JSonInvalidUnknowAction;
			return false;
		}

		if (LoadedElements->IsValidIndex(ChronicleId))
		{
			(*LoadedElements)[ChronicleId].ChronicleId = ChronicleId;
			(*LoadedElements)[ChronicleId].Action = CreatedAction;
			(*LoadedElements)[ChronicleId].Event = nullptr;
		}
	}

	if (bInLoadEvents && JSonEvents)
	{
		for (const auto& JSonEvent : *JSonEvents)
		{
			const TSharedPtr<FJsonObject>& JsonEventObject = JSonEvent->AsObject();
			int32 ChronicleId = JsonEventObject->GetIntegerField(TEXT("ChronicleId"));
			FString EventTypeStr = JsonEventObject->GetStringField(TEXT("EventType"));
			ECCEventType InEventType = (ECCEventType)EventTypeEnum->GetValueByName(*EventTypeStr);
			UCCEvent* CreatedEvent = CreateEventByType(InEventType);
			if (!CreatedEvent)
			{
				(*OutLoadingError) = EQ6Judgement::JSonInvalidUnknowEvent;
				return false;
			}

			const TSharedPtr<FJsonObject>& JSonEventStructObject = JsonEventObject->GetObjectField(TEXT("Event"));
			if (!FJsonObjectConverter::JsonObjectToUStruct(JSonEventStructObject.ToSharedRef(), CreatedEvent->GetClass(), CreatedEvent, 0, 0))
			{
				(*OutLoadingError) = EQ6Judgement::JSonInvalidUnknowEvent;
				return false;
			}

			if (LoadedElements->IsValidIndex(ChronicleId))
			{
				(*LoadedElements)[ChronicleId].ChronicleId = ChronicleId;
				(*LoadedElements)[ChronicleId].Action = nullptr;
				(*LoadedElements)[ChronicleId].Event = CreatedEvent;
			}
		}
	}

	if (!LoadedElements->IsValidIndex(1) || (*LoadedElements)[1].Action == nullptr)
	{
		(*OutLoadingError) = EQ6Judgement::JSonInvalidFirstActionNotInit;
		return false;
	}

	(*OutLoadingError) = EQ6Judgement::NotGuilty;
	return true;
}


template<typename T>
UCCEvent* UChronicleLoader::CreatedEventObject()
{
	return NewObject<T>();
}

template<typename T>
FCCAction* UChronicleLoader::CreatedActionStruct()
{
	return new T;
}


UCCEvent* UChronicleLoader::CreateEventByType(ECCEventType InType)
{
	if (!CreateEventFunctions.IsValidIndex((int32)InType))
	{
		Q6JsonLogNet(Error, "Invalid event type", Q6KV("EventType", (int32)InType));
		return nullptr;
	}

	if (!CreateEventFunctions[(int32)InType])
	{
		Q6JsonLogNet(Error, "Unkown event type", Q6KV("EventType", (int32)InType));
		return nullptr;
	}

	return (this->* (CreateEventFunctions[(int32)InType]))();
}

FCCAction* UChronicleLoader::CreateActionByType(ECCActionType InType)
{
	if (!CreateActionFunctions.IsValidIndex((int32)InType))
	{
		Q6JsonLogNet(Error, "Invalid action type", Q6KV("ActionType", (int32)InType));
		return nullptr;
	}

	if (!CreateActionFunctions[(int32)InType])
	{
		Q6JsonLogNet(Error, "Unkown action type", Q6KV("ActionType", (int32)InType));
		return nullptr;
	}

	return (this->* (CreateActionFunctions[(int32)InType]))();
}

AChronicleProsecutor::AChronicleProsecutor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, StartTime(0.f)
	, bInvestigating(false)
{
	PrimaryActorTick.bCanEverTick = true;

	Loader = ObjectInitializer.CreateDefaultSubobject<UChronicleLoader>(this, TEXT("ChronicleLoader"));
	Loader->InitLoader();
}

EQ6Judgement AChronicleProsecutor::AcceptChronicle(int32 InRequestId, const FString& QueryString, const FString& ChronicleJsonStr)
{
	StartTime = FPlatformTime::Seconds();
	Q6JsonLogNet(Display, "Request START", Q6KV("Request", InRequestId));
	CleanupChronicleElements();

	TSharedPtr<FJsonObject> CombatSeed;
	TSharedRef<TJsonReader<>> CombatSeedReader = TJsonReaderFactory<>::Create(QueryString);
	if (!FJsonSerializer::Deserialize(CombatSeedReader, CombatSeed) || !CombatSeed.IsValid())
	{
		return EQ6Judgement::InvalidCombatSeed;
	}

	const TArray<TSharedPtr<FJsonValue>>* JsonUnits = nullptr;
	if (!CombatSeed->TryGetArrayField(TEXT("units"), JsonUnits))
	{
		return EQ6Judgement::InvalidCombatSeed;
	}

	int32 Episode = CombatSeed->GetIntegerField(TEXT("episode"));
	int32 Stage = CombatSeed->GetIntegerField(TEXT("stage"));
	int32 RandomSeed = CombatSeed->GetIntegerField(TEXT("combatSeed"));
	TArray<int32> Units; // obiwan need more unit infomation. skill level.
	for (const auto& JsonUnit : *JsonUnits)
	{
		Units.Add(static_cast<int32>(JsonUnit->AsNumber()));
	}
	Q6JsonLogNet(Display, "CombatSeed", Q6KV("QueryString", QueryString));

	EQ6Judgement JudgementOnLoading;
	if (!Loader->LoadFromString(ChronicleJsonStr, true, &Elements, &JudgementOnLoading))
	{
		CleanupChronicleElements();
		return JudgementOnLoading;
	}

	const FCCInitCombatCubeAction* InitCombatCubeAction = (const FCCInitCombatCubeAction*)(Elements[1].Action);
	CombatCube->GetStore()->SetRandomSeed(InitCombatCubeAction->Seed);
	// obiwan need to set unit

	CurChronicleId = 1;
	RequestId = InRequestId;
	bInvestigating = true;

	DispatchCurActionPerTick();

	return EQ6Judgement::NotGuilty;
}

void AChronicleProsecutor::BeginPlay()
{
	Super::BeginPlay();

	CombatCube = GetWorld()->SpawnActor<ACombatCube>();
	CombatCube->SetMode(ECombatCubeMode::Verification);
	CombatCube->GetStore()->OnEvent.AddDynamic(this, &AChronicleProsecutor::OnCombatCubeEvent);
}

void AChronicleProsecutor::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	const float ExpireInvestigationTime = 3.f; // seconds

	if (bInvestigating)
	{
		if (FPlatformTime::Seconds() - StartTime > ExpireInvestigationTime)
		{
			EndInvestigation(EQ6Judgement::TimeExpired);
			return;
		}
	}

	DispatchCurActionPerTick();
}

void AChronicleProsecutor::OnCombatCubeEvent(const UCCEvent* Event)
{
	if (!Event)
	{
		EndInvestigation(EQ6Judgement::MismatchNotEvent);
		return;
	}

	if (!Elements.IsValidIndex(CurChronicleId))
	{
		EndInvestigation(EQ6Judgement::MismatchCount);
		return;
	}

	if (!Elements[CurChronicleId].IsEvent())
	{
		EndInvestigation(EQ6Judgement::MismatchNotEvent);
		return;
	}

	if (Event->GetEventType() != Elements[CurChronicleId].Event->GetEventType())
	{
		EndInvestigation(EQ6Judgement::MismatchDiffEvent);
		return;
	}

	if (Event->GetEventType() == ECCEventType::EndGame)
	{
		const UCCEndGameEvent* SimulatedEvent = CastChecked<UCCEndGameEvent>(Event);
		UCCEndGameEvent* ChronicleEvent = CastChecked<UCCEndGameEvent>(Elements[CurChronicleId].Event);

		EQ6Judgement Judgement = (SimulatedEvent->Result == ChronicleEvent->Result ? EQ6Judgement::NotGuilty : EQ6Judgement::MismatchResult);
		EndInvestigation(Judgement);
	}

	++CurChronicleId;
}

void AChronicleProsecutor::EndInvestigation(EQ6Judgement InResult)
{
	if (!bInvestigating)
	{
		return;
	}

	double ElapsedTime = FPlatformTime::Seconds() - StartTime;
	Q6JsonLogNet(Display, "Request END", Q6KV("Request", RequestId), Q6KV("ElapsedTime", ElapsedTime));

	bInvestigating = false;
	UQ6GameInstance::Get(this)->CompleteJudgeChronicle(RequestId, InResult);
	CleanupChronicleElements();
}

void AChronicleProsecutor::DispatchCurAction()
{
	if (!Elements.IsValidIndex(CurChronicleId))
	{
		EndInvestigation(EQ6Judgement::MismatchCount);
		return;
	}

	if (!Elements[CurChronicleId].IsAction())
	{
		return;
	}

	int32 DispatchChronicleId = CurChronicleId;
	++CurChronicleId;
	CombatCube->GetStore()->Dispatch(*(Elements[DispatchChronicleId].Action));
}

void AChronicleProsecutor::DispatchCurActionPerTick()
{
	const int32 InvestigationCountPerTick = 10000;

	for (int32 i = 1; i < InvestigationCountPerTick && bInvestigating; ++i)
	{
		DispatchCurAction();
	}
}

void AChronicleProsecutor::CleanupChronicleElements()
{
	for (auto& Iter : Elements)
	{
		delete Iter.Action;
	}

	Elements.Empty();
}

AChronicleRunner::AChronicleRunner(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;

	Loader = ObjectInitializer.CreateDefaultSubobject<UChronicleLoader>(this, TEXT("ChronicleLoader"));
	Loader->InitLoader();
}

void AChronicleRunner::BeginPlay()
{
	Super::BeginPlay();

}

void AChronicleRunner::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);
	// Some steps that user didn't watch should play again when they resume play.
	// that's the reason why this runner is actor and have ticks.
}

void AChronicleRunner::SetTargets(ACombatCube* InCombatCube, ACombatPresenter* InPresenter)
{
	TargetCombatCube = InCombatCube;
	TargetPresenter = InPresenter;
}

void AChronicleRunner::LoadOngoing()
{
	EQ6Judgement JudgementOnLoading;
	if (!Loader->LoadFromString(UQ6GameInstance::Get()->GetOngoingChronicle(), false, &LoadedElements, &JudgementOnLoading))
	{
		CleanupLoadedElements();
		return;
	}

	FRaidId RaidId = Loader->GetRaidId();
	if (!RaidId.IsInvalid())
	{
		const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
		const FRaidFinal* RaidFinal = RaidManager.Find(RaidId);
		if (RaidFinal) {
			ACTION_DISPATCH_SelectFinal(RaidFinal->GetInfo().Type, RaidId);
		}
	}
}

bool AChronicleRunner::IsLoaded() const
{
	return LoadedElements.Num() > 0;
}

void AChronicleRunner::CleanupLoadedElements()
{
	for (auto& Iter : LoadedElements)
	{
		delete Iter.Action;
	}

	LoadedElements.Empty();
}

void AChronicleRunner::Run()
{
	if (!TargetCombatCube)
	{
		return;
	}

	UCCCombatCubeStore* InCombatCubeStore = TargetCombatCube->GetStore();
	if (!InCombatCubeStore)
	{
		return;
	}

	if (!CVarQ6UseLobbyCombat.GetValueOnGameThread()) {
		const FCCInitCombatCubeAction* InitCombatCubeAction = (const FCCInitCombatCubeAction*)(LoadedElements[1].Action);
		if (!InitCombatCubeAction)
		{
			Q6JsonLogBro(Error, "Ongoing chronicle in invalid missing init");
			return;
		}

		TargetCombatCube->InitCombatCube(InitCombatCubeAction->Seed);

		// some code depends on Q6GameInstance seed information so need to set that structure.
		UQ6GameInstance::Get()->InitCombatSeed(InitCombatCubeAction->Seed);

		ULevelUtil::LoadSagaLightPreset(GetWorld(), GetCMS()->GetLightPreset(InitCombatCubeAction->Seed.SagaType));

		// elements start from 1 and initcombatcube was done before.
		for (int32 i = 2; i < LoadedElements.Num(); ++i)
		{
			if (LoadedElements[i].IsAction())
			{
				InCombatCubeStore->Dispatch(*(LoadedElements[i].Action));
			}
		}

		const FCCCombatCubeState& CombatCubeState = TargetCombatCube->GetStore()->GetState();
		if (CombatCubeState.TurnState.CurrentPhase != ECCTurnPhase::TurnSkill)
		{
			Q6JsonLogBro(Error, "Ongoing chronicle should end at turn_skill phase");
			return;
		}

		TargetPresenter->SynchronizeCCState(TargetCombatCube->GetStore()->GetState());
	}
	else
	{
		FCCCombatCubeState State;
		const FString& StateStr = UQ6GameInstance::Get()->GetOnGoingCCState();
		if (!TargetCombatCube->GetStore()->RestoreCCState(StateStr, State)) {
			return;
		}
		UQ6GameInstance::Get()->ClearOnGoingCCState();

		UQ6GameInstance::Get()->InitCombatSeed(State.CombatSeed);

		TargetPresenter->SynchronizeCCState(State);
	}

	TargetPresenter->BindCombatCubeEvent(TargetCombatCube);
	TargetPresenter->PostSynchronizeCCState();

	CleanupLoadedElements();
}

TArray<UCCEvent*> AChronicleRunner::ParseLobbyCCEvents(const FString& Msg)
{
	return Loader->ParseLobbyCCEvents(Msg);
}