// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CombatCube/CCAction.h"
#include "CombatCube/CCEvent.h"
#include "GameFramework/Actor.h"
#include "Chronicle.generated.h"

USTRUCT()
struct FChronicleAction
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ChronicleId;

	FCCAction* Action;
};

USTRUCT()
struct FChronicleEvent
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ChronicleId;

	UPROPERTY()
	const UCCEvent* Event;
};

USTRUCT()
struct FChronicle
{
	GENERATED_BODY()

	FChronicle();

	void QueueAction(FCCAction* InAction);
	void QueueEvent(const UCCEvent* InEvent);
	FString ToJson() const;
	FString ToJsonActions() const;

	void SetRaidInfo(FRaidId InRaidId);

	void Init(FSagaType InSagaType);
	void Clear();

private:
	void WriteActionsInternal(TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>>& InJsonWriter) const;
	void WriteEventsInternal(TSharedRef<TJsonWriter<TCHAR, TPrettyJsonPrintPolicy<TCHAR>>>& InJsonWriter) const;

public:

	UPROPERTY()
	TArray<FChronicleAction> ChronicleActions;

	UPROPERTY()
	TArray<FChronicleEvent> ChronicleEvents;

	UPROPERTY()
	int32 NextChronicleId;

	UPROPERTY()
	FSagaType SagaType;

	UPROPERTY()
	FRaidId RaidId;
};

struct FCCAction;

USTRUCT()
struct FChronicleElement
{
	GENERATED_BODY()

	bool IsAction() const { return Action && !Event; }
	bool IsEvent() const { return !Action && Event; }

	UPROPERTY()
	int32 ChronicleId;

	FCCAction* Action;

	UPROPERTY()
	UCCEvent* Event;
};

class ACombatCube;
class ACombatPresenter;

/*
* UChronicleLoader
* load chronicle from string
*/
UCLASS()
class Q6_API UChronicleLoader : public UObject
{
	GENERATED_BODY()

public:

	void InitLoader();
	FRaidId GetRaidId() const;
	bool LoadFromString(FString ChronicleJsonStr, bool bInLoadEvents, TArray<FChronicleElement>* LoadedElements, EQ6Judgement* OutLoadingError);
	FSagaType GetSagaTypeFromChronicle(FString InChronicleJSon) const;

	TArray<UCCEvent*> ParseLobbyCCEvents(const FString& Msg);
private:

	UPROPERTY()
	bool bInitLoader = false;

	template<typename T>
	UCCEvent* CreatedEventObject();

	template<typename T>
	FCCAction* CreatedActionStruct();

	typedef UCCEvent* (UChronicleLoader::*CreateEventFunc)();
	typedef FCCAction* (UChronicleLoader::*CreateActionFunc)();

	UCCEvent* CreateEventByType(ECCEventType InType);
	FCCAction* CreateActionByType(ECCActionType InType);

	UPROPERTY(Transient)
	UEnum* ActionTypeEnum = nullptr;

	UPROPERTY(Transient)
	UEnum* EventTypeEnum = nullptr;

	FRaidId RaidId;

	TArray<CreateEventFunc> CreateEventFunctions;
	TArray<CreateActionFunc> CreateActionFunctions;
};


/*
* AChronicleProsecutor
* check chronicle json is valid or not.
*/
UCLASS()
class Q6_API AChronicleProsecutor : public AActor
{
	GENERATED_BODY()

public:
	AChronicleProsecutor(const FObjectInitializer& ObjectInitializer);

	EQ6Judgement AcceptChronicle(int32 InRequestId, const FString& QueryString, const FString& ChronicleJsonStr);
	bool IsInvestigating() const { return bInvestigating; }

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

private:
	UFUNCTION()
	void OnCombatCubeEvent(const UCCEvent* Event);

	void CleanupChronicleElements();

	void DispatchCurActionPerTick();
	void DispatchCurAction();

	void EndInvestigation(EQ6Judgement InResult);

	UPROPERTY()
	ACombatCube* CombatCube;

	UPROPERTY(Transient)
	TArray<FChronicleElement> Elements;

	UPROPERTY()
	int32 CurChronicleId;

	UPROPERTY()
	UChronicleLoader* Loader;

	UPROPERTY()
	int32 RequestId;

	UPROPERTY()
	double StartTime;

	UPROPERTY()
	bool bInvestigating;
};

/*
* AChronicleRunner
* push actions to CombatCube and resume CombatPresenter
*/
UCLASS()
class Q6_API AChronicleRunner : public AActor
{
	GENERATED_BODY()

public:
	AChronicleRunner(const FObjectInitializer& ObjectInitializer);

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	void SetTargets(ACombatCube* InCombatCube, ACombatPresenter* InPresenter);
	void LoadOngoing();
	bool IsLoaded() const;
	void Run();

	TArray<UCCEvent*> ParseLobbyCCEvents(const FString& Msg);

private:

	void CleanupLoadedElements();

	UPROPERTY()
	ACombatCube* TargetCombatCube;

	UPROPERTY()
	ACombatPresenter* TargetPresenter;

	UPROPERTY(Transient)
	TArray<FChronicleElement> LoadedElements;

	UPROPERTY()
	int32 CurChronicleId;

	UPROPERTY()
	UChronicleLoader* Loader;
};