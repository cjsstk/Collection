#pragma once

#include "CMS_gen.h"

UENUM(BlueprintType)
enum class ECPTurnPhase : uint8
{
	Prepare,
	OppTurnSkill,
	TurnSkill,
	Steady,
	Attack,
	OppAttack,
	EnemyUltimateReady,
	ChangeCombatMultiSide,
};

UENUM()
enum class EQ6GameSpeed : uint8
{
	Normal,
	Speedy,
	Fast,
};

UENUM()
enum class ECombatCamera : uint8
{
	Wave,
	Prepare,
	AllyAll,
	Ally1,
	Ally2,
	Ally3,
	EnemyAll,
	Enemy1,
	Enemy2,
	Enemy3,
	Enemy4,
	Enemy5,
	Result,
};

UENUM()
enum class ECPInstanceState : uint8
{
	NA,
	Prepare,
	Start,
	ProceedNext,
	End
};

UENUM()
enum class EPointVaryState : uint8
{
	Consume,
	Convert
};

UENUM(BlueprintType)
enum class EZoneAttribute : uint8
{
	Ground,
	Water,
	Ice,
	Grass,
	Rock,
	Lava,
};

UENUM(BlueprintType)
enum class EDialogueType : uint8
{
	None = 0,
	Saga = 1,
	Special = 2,
	Daily = 3,
	Training = 4,
	Raid = 5,
	Vacation = 6,
	Event = 7,
	MultiSide = 8,
};

UENUM(BlueprintType)
enum class EDialogueMode : uint8
{
	None = 0,
	Normal = 1,
	Chat = 2,
};

UENUM(BlueprintType)
enum class ETrainingStepState : uint8
{
	NotAchieved,
	Trying,
	Achieved,
	Cleared,
};

UENUM(BlueprintType)
enum class ECharacterVoiceCategory : uint8
{
	None,
	TurnSkill1,
	TurnSkill2,
	TurnSkill3,
	NormalSkill,
	AceSkill,
	BreakSkill,
	CloserSkill,
	DoubleSkill,
	UltimateSkill,
	TurnSpawn,
	CombatStart,
	Victory,
	SupportSkill,
	Dead,
	Hit,
	NarrativeBonus,
	Welcome,
	LobbyIdle,
	LobbyInteraction,
};
