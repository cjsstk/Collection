// Fill out your copyright notice in the Description page of Project Settings.

using UnrealBuildTool;

public class Q6 : ModuleRules
{
	public Q6(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"ApplicationCore",
			"Core",
			"CoreUObject",
			"CinematicCamera",
			"Engine",
			"InputCore",
			"Json",
			"Http",
			"JsonUtilities",
			"Networking",
			"LevelSequence",
			"MovieScene",
			"MovieSceneTracks",
			"MoviePlayer",
			"WebSockets",
			"PakFile",
            "MediaAssets"
        });

		AddEngineThirdPartyPrivateStaticDependencies(Target, "OpenSSL", "libWebSockets", "zlib");
		PrivateDependencyModuleNames.Add("SSL");

		if (Target.Type == TargetType.Editor)
		{
			PrivateDependencyModuleNames.AddRange(new string[]
			{
				"UnrealEd",
				"PropertyEditor",
				"EditorStyle",
				"Kismet",
				"RawMesh",
			});
		}

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Slate",
			"SlateCore",
			"Paper2D",
			"UltimateMobileKit",
			"Projects",
			"RenderCore"
		});

		PublicIncludePaths.AddRange(new string[]
		{
			"Q6",
			"Q6/AnimNotify",
			"Q6/Chronicle",
			"Q6/CMS",
			"Q6/Combat",
			"Q6/CombatCube",
			"Q6/Dialogue",
			"Q6/FSM",
			"Q6/GameMode",
			"Q6/HUD",
			"Q6/HUDStore",
			"Q6/Lobby",
			"Q6/Network",
			"Q6/Patch",
			"Q6/PlayerController",
			"Q6/Resource",
			"Q6/Sound",
			"Q6/Summon",
			"Q6/Templates",
			"Q6/Test",
			"Q6/Unit",
            "Q6/Capture",
            "Q6/Utils",
			"Q6/Widget",
            "Q6/Movie",
            "../../../source/node/ts_root/lobbyd/src/combatCube"
        });

		if (Target.Platform == UnrealTargetPlatform.Android)
		{
			PrivateDependencyModuleNames.AddRange(new string[] { "AndroidRuntimeSettings" });
			// Add UPL to add configrules.txt to our APK
			string PluginPath = Utils.MakePathRelativeTo(ModuleDirectory, Target.RelativeEnginePath);
			AdditionalPropertiesForReceipt.Add("AndroidPlugin", System.IO.Path.Combine(PluginPath, "Q6_UPL.xml"));
		}
		else if (Target.Platform == UnrealTargetPlatform.IOS)
		{
			PrivateDependencyModuleNames.AddRange(new string[] { "IOSRuntimeSettings" });
		}
		else if (Target.Platform == UnrealTargetPlatform.Linux ||
			Target.Platform == UnrealTargetPlatform.Win64)
		{
			PrivateDependencyModuleNames.AddRange(new string[] { "mongoose" });
			PrivateIncludePathModuleNames.AddRange(new string[] { "mongoose" });
		}

        PrivateDependencyModuleNames.AddRange(new string[] { "BuildPatchServices" });
        PrivateIncludePathModuleNames.AddRange(new string[] { "BuildPatchServices" });

		// Uncomment if you are using online features
		// PrivateDependencyModuleNames.Add("OnlineSubsystem");

		// To include OnlineSubsystemSteam, add it to the plugins section in your uproject file with the Enabled attribute set to true
	}
}
