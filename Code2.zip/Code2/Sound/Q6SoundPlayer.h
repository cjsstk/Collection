// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMS_gen.h"
#include "Components/AudioComponent.h"
#include "Q6Enum.h"
#include "Q6SoundPlayer.generated.h"

struct FSpawnSoundParams;

class USoundBase;
class UAudioComponent;

UCLASS()
class Q6_API UQ6SoundPlayer : public UObject
{
	GENERATED_BODY()

public:
	void Initialize();
	void Shutdown();

	void PlayMainBGM(const FName& Name, float FadeSeconds = -1.0f);
	void StopMainBGM(float FadeOutSeconds = -1.0f);

	void RegisterVoiceComponentToWorld();
	void UnRegisterVoiceComponent();
	FOnAudioFinished& GetVoiceFinishedDelegate() { return VoiceComponent->OnAudioFinished; }
	void ClearCharacterVoiceDelegates();

	void PlayVoice(USoundBase* InSound);

	void PlayCharacterVoice(FCharacterType CharacterType, ECharacterVoiceCategory VoiceCategory);
	void PlayCharacterVoice(TSoftObjectPtr<USoundBase> InCharacterVoice);
	void StopCharacterVoice();

	float PlayDialogueVoice(EDialogueType DialogueType, const FName& Name);
	void StopDialogueVoice();

	bool HasDialogueVoice(EDialogueType DialogueType, const FName& Name) const;
	float GetDialogueVoiceLength(EDialogueType DialogueType, const FName& Name) const;

	float PlayDialogueSound(int32 SoundType);
	float GetDialogueSoundLength(int32 SoundType) const;

	void PlaySkillBGM(TSoftObjectPtr<USoundBase> InSkillBGM);
	void StopSkillBGM();

	void PlayEffectSound(const FSpawnSoundParams& Param);

private:
	void InitBGMComponents(USoundBase* DummySound);
	void ShutdownBGMComponents();
	UAudioComponent* GetActiveBGMComponent();
	UAudioComponent* GetNextBGMComponent();

	void CrossFadeInOutSkillBGM(bool bFadeIn);

	void ValidateComponents();
	void PlaySoundComponent(UAudioComponent* Component, USoundBase* Sound, float FadeInSeconds = 0.0f, float FadeOutSeconds = 0.0f, bool bRestart = false);
	void StopSoundComponent(UAudioComponent* Component, float FadeOutSeconds = 0.0f);

	void OnStartEffectSound(const FSpawnSoundParams Param);

public:
	FSimpleDelegate OnCharacterVoicePlayDelegate;

private:
	UPROPERTY(Transient)
	TArray<UAudioComponent*> BGMComponents;

	UPROPERTY(Transient)
	UAudioComponent* SkillBGMComponent;

	UPROPERTY(Transient)
	UAudioComponent* VoiceComponent;

	int32 ActiveBGMIndex;
};
