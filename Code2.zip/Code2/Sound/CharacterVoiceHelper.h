// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "CMS_gen.h"
#include "GameResource.h"
#include "CharacterVoiceHelper.generated.h"

struct FSortedVoiceInfo
{
	ECharacterVoiceCategory Category;
	TArray<TSoftObjectPtr<USoundBase>> UnlockedVoiceSounds;
};

struct FSortedCharacterVoiceInfo
{
	FCharacterType CharacterType;
	TArray<FSortedVoiceInfo> SortedVoiceInfos;
};

UCLASS()
class Q6_API UCharacterVoiceHelper : public UObject
{
	GENERATED_BODY()
	
public:
	UCharacterVoiceHelper(const FObjectInitializer& ObjectInitializer);

	void GatherCharacterVoices(FCharacterType CharacterType);
	TSoftObjectPtr<USoundBase> GetCharacterVoiceSound(FCharacterType InCharacterType, ECharacterVoiceCategory InCategory) const;

private:
	FSortedCharacterVoiceInfo* FindOrAddSortedCharacterVoiceInfo(FCharacterType InCharacterType);

	TArray<FSortedCharacterVoiceInfo> GatheredCharacterVoiceInfos;
};
