// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "CharacterVoiceHelper.h"
#include "CMS/CMSTable.h"
#include "HUDStore.h"
#include "Q6.h"

UCharacterVoiceHelper::UCharacterVoiceHelper(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

FSortedCharacterVoiceInfo* UCharacterVoiceHelper::FindOrAddSortedCharacterVoiceInfo(FCharacterType InCharacterType)
{
	for (FSortedCharacterVoiceInfo& GatheredCharacterVoiceInfo : GatheredCharacterVoiceInfos)
	{
		if (GatheredCharacterVoiceInfo.CharacterType == InCharacterType)
		{
			GatheredCharacterVoiceInfo.SortedVoiceInfos.Empty();
			return &GatheredCharacterVoiceInfo;
		}
	}

	FSortedCharacterVoiceInfo* AddedCharacterVoiceInfo = &GatheredCharacterVoiceInfos.AddDefaulted_GetRef();
	AddedCharacterVoiceInfo->CharacterType = InCharacterType;
	return AddedCharacterVoiceInfo;
}

void UCharacterVoiceHelper::GatherCharacterVoices(FCharacterType CharacterType)
{
	FSortedCharacterVoiceInfo* GatheringCharacterVoiceInfo = FindOrAddSortedCharacterVoiceInfo(CharacterType);
	ensure(GatheringCharacterVoiceInfo);

	const FCMSCharUnlockElemSetRow* CharUnlockElemSetRow = GetCMS()->GetCharUnlockElemSetRowByCharType(CharacterType);
	if (!CharUnlockElemSetRow)
	{
		Q6JsonLogSunny(Warning, "UCharacterVoiceHelper::GatherCharacterVoices - no CharUnlockElemSetRow", Q6KV("CharacterType", CharacterType));
		return;
	}

	TArray<int32> UnlockedVoiceIds;
	const TArray<const FCMSCharUnlockElemRow*>& UnlockElems = CharUnlockElemSetRow->GetUnlockElem();
	for (const FCMSCharUnlockElemRow* UnlockElem : UnlockElems)
	{
		if (!UnlockElem)
		{
			continue;
		}

		if (UnlockElem->Category != ECharUnlockElemCategory::Voice)
		{
			continue;
		}

		if (UnlockedVoiceIds.Contains(UnlockElem->Param1))
		{
			Q6JsonLogSunny(Warning, "UCharacterVoiceHelper::GatherCharacterVoices - Duplicated CharUnlockElem Voice Param1", Q6KV("VoiceId", UnlockElem->Param1));
			continue;
		}

		if (GetHUDStore().IsUnlockedCharUnlockElem(CharacterType, UnlockElem))
		{
			UnlockedVoiceIds.Add(UnlockElem->Param1);
		}
	}

	const FCharacterVoiceAssetRow* CharacterVoiceAssetRow = GetGameSoundResource().GetCharacterVoiceAssetRow(CharacterType);
	if (!CharacterVoiceAssetRow)
	{
		Q6JsonLogSunny(Warning, "UCharacterVoiceHelper::GatherCharacterVoices - no CharacterVoiceAssetRow", Q6KV("CharacterType", CharacterType));
		return;
	}

	for (const FCharacterVoiceInfo& CharacterVoiceInfo : CharacterVoiceAssetRow->CharacterVoiceInfos)
	{
		FSortedVoiceInfo& GatheringVoiceInfo = GatheringCharacterVoiceInfo->SortedVoiceInfos.AddDefaulted_GetRef();
		GatheringVoiceInfo.Category = CharacterVoiceInfo.Category;

		for (const FVoiceInfo& VoiceInfo : CharacterVoiceInfo.VoiceInfos)
		{
			if (UnlockedVoiceIds.Contains(VoiceInfo.VoiceId))
			{
				GatheringVoiceInfo.UnlockedVoiceSounds.Add(VoiceInfo.Sound);
				UnlockedVoiceIds.Remove(VoiceInfo.VoiceId);
			}
		}
	}

	ensure(!UnlockedVoiceIds.Num());
}

TSoftObjectPtr<USoundBase> UCharacterVoiceHelper::GetCharacterVoiceSound(FCharacterType InCharacterType, ECharacterVoiceCategory InCategory) const
{
	for (const FSortedCharacterVoiceInfo& GatheredCharacterVoiceInfo : GatheredCharacterVoiceInfos)
	{
		if (GatheredCharacterVoiceInfo.CharacterType != InCharacterType)
		{
			continue;
		}

		for (const FSortedVoiceInfo& SortedVoiceInfo : GatheredCharacterVoiceInfo.SortedVoiceInfos)
		{
			if (SortedVoiceInfo.Category != InCategory)
			{
				continue;
			}

			if (!SortedVoiceInfo.UnlockedVoiceSounds.Num())
			{
				return nullptr;
			}

			int32 RandIndex = FMath::RandRange(0, SortedVoiceInfo.UnlockedVoiceSounds.Num() - 1);
			return SortedVoiceInfo.UnlockedVoiceSounds[RandIndex];
		}
	}

	return nullptr;
}
