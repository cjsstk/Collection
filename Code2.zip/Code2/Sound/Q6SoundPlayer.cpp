// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6SoundPlayer.h"

#include "AudioDevice.h"
#include "CharacterVoiceHelper.h"
#include "GameResource.h"
#include "Q6.h"
#include "Q6Define.h"

static TAutoConsoleVariable<float> CVarQ6BGMFadeInSeconds(
	TEXT("q6.BGMFadeInSeconds"),
	1.5f,
	TEXT("Time in seconds for BGM to fade in"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarQ6BGMFadeOutSeconds(
	TEXT("q6.BGMFadeOutSeconds"),
	1.5f,
	TEXT("Time in seconds for BGM to fade out"),
	ECVF_Cheat);

static int32 MAX_BGM_COMPONENTS = 2;

float GetFadeInSeconds(float Seconds)
{
	if (Seconds < 0.0f)
	{
		return CVarQ6BGMFadeInSeconds.GetValueOnGameThread();
	}

	return Seconds;
}

float GetFadeOutSeconds(float Seconds)
{
	if (Seconds < 0.0f)
	{
		return CVarQ6BGMFadeOutSeconds.GetValueOnGameThread();
	}

	return Seconds;
}

void UQ6SoundPlayer::Initialize()
{
	USoundBase* DummySound = GetGameSoundResource().GetBGM("Dummy");
	if (!DummySound)
	{
		Q6JsonLogZagal(Warning, "UQ6SoundPlayer::Initialize - No DummySound");
		return;
	}

	InitBGMComponents(DummySound);

	FAudioDevice::FCreateComponentParams Params(GetWorld()->GetAudioDevice());

	SkillBGMComponent = FAudioDevice::CreateComponent(DummySound, Params);
	if (SkillBGMComponent)
	{
		SkillBGMComponent->bAllowSpatialization = false;
		SkillBGMComponent->bIgnoreForFlushing = true;
	}

	VoiceComponent = FAudioDevice::CreateComponent(DummySound, Params);
	if (VoiceComponent)
	{
		VoiceComponent->bAllowSpatialization = false;
		VoiceComponent->bIsUISound = true;
		VoiceComponent->bIgnoreForFlushing = false;
	}
}

void UQ6SoundPlayer::Shutdown()
{
	ShutdownBGMComponents();

	if (SkillBGMComponent)
	{
		SkillBGMComponent->Stop();
		SkillBGMComponent = nullptr;
	}

	if (VoiceComponent)
	{
		VoiceComponent->Stop();
		VoiceComponent = nullptr;
	}
}

void UQ6SoundPlayer::InitBGMComponents(USoundBase* DummySound)
{
	FAudioDevice::FCreateComponentParams Params(GetWorld()->GetAudioDevice());

	if (USoundConcurrency* ConcurrencySettings = GetGameSoundResource().GetBGMConcurrency())
	{
		Params.ConcurrencySet.Add(ConcurrencySettings);
	}

	BGMComponents.Empty(MAX_BGM_COMPONENTS);
	ActiveBGMIndex = 0;

	for (int32 i = 0; i < MAX_BGM_COMPONENTS; i++)
	{
		UAudioComponent* Comp = FAudioDevice::CreateComponent(DummySound, Params);
		if (Comp)
		{
			Comp->bAllowSpatialization = false;
			Comp->bIgnoreForFlushing = true;

			BGMComponents.Add(Comp);
		}
	}
}

void UQ6SoundPlayer::ShutdownBGMComponents()
{
	for (UAudioComponent* Comp : BGMComponents)
	{
		Comp->Stop();
	}

	BGMComponents.Empty();
}

UAudioComponent* UQ6SoundPlayer::GetActiveBGMComponent()
{
	if (BGMComponents.IsValidIndex(ActiveBGMIndex))
	{
		return BGMComponents[ActiveBGMIndex];
	}

	return nullptr;
}

UAudioComponent* UQ6SoundPlayer::GetNextBGMComponent()
{
	ActiveBGMIndex = (ActiveBGMIndex + 1) % MAX_BGM_COMPONENTS;
	return GetActiveBGMComponent();
}

void UQ6SoundPlayer::PlayMainBGM(const FName& Name, float FadeSeconds)
{
	if (Name.IsNone())
	{
		return;
	}

	USoundBase* Sound = GetGameSoundResource().GetBGM(Name);
	if (!Sound)
	{
		return;
	}

	ValidateComponents();

	float FadeInSeconds = GetFadeInSeconds(FadeSeconds);
	float FadeOutSeconds = GetFadeOutSeconds(FadeSeconds);

	if (UAudioComponent* Comp = GetActiveBGMComponent())
	{
		StopSoundComponent(Comp, FadeOutSeconds);
	}

	if (UAudioComponent* Comp = GetNextBGMComponent())
	{
		PlaySoundComponent(Comp, Sound, FadeInSeconds, FadeOutSeconds, true);
	}
}

void UQ6SoundPlayer::StopMainBGM(float FadeOutSeconds)
{
	FadeOutSeconds = GetFadeOutSeconds(FadeOutSeconds);

	if (UAudioComponent* Comp = GetActiveBGMComponent())
	{
		StopSoundComponent(Comp, FadeOutSeconds);
	}
}

void UQ6SoundPlayer::RegisterVoiceComponentToWorld()
{
	if (VoiceComponent)
	{
		VoiceComponent->RegisterComponentWithWorld(GetWorld());
	}
}

void UQ6SoundPlayer::UnRegisterVoiceComponent()
{
	if (VoiceComponent)
	{
		VoiceComponent->UnregisterComponent();
	}
}

void UQ6SoundPlayer::ClearCharacterVoiceDelegates()
{
	OnCharacterVoicePlayDelegate.Unbind();

	if (VoiceComponent)
	{
		VoiceComponent->OnAudioFinished.Clear();
	}
}

void UQ6SoundPlayer::PlayVoice(USoundBase* InSound)
{
	if (InSound)
	{
		ValidateComponents();
		PlaySoundComponent(VoiceComponent, InSound);
	}
}

void UQ6SoundPlayer::PlayCharacterVoice(FCharacterType CharacterType, ECharacterVoiceCategory VoiceCategory)
{
	UCharacterVoiceHelper* CharacterVoiceHelper = GetCharacterVoiceHelper();
	if (!CharacterVoiceHelper)
	{
		return;
	}

	TSoftObjectPtr<USoundBase> VoiceSound = CharacterVoiceHelper->GetCharacterVoiceSound(CharacterType, VoiceCategory);
	PlayCharacterVoice(VoiceSound);
}

void UQ6SoundPlayer::PlayCharacterVoice(TSoftObjectPtr<USoundBase> InCharacterVoice)
{
	if (InCharacterVoice.IsNull())
	{
		Q6JsonLogSunny(Warning, "UQ6SoundPlayer::PlayCharacterVoice - Not found character voice");
		return;
	}

	USoundBase* CharacterVoice = InCharacterVoice.LoadSynchronous();
	if (CharacterVoice)
	{
		ValidateComponents();
		PlaySoundComponent(VoiceComponent, CharacterVoice);
		OnCharacterVoicePlayDelegate.ExecuteIfBound();
	}
}

void UQ6SoundPlayer::StopCharacterVoice()
{
	StopSoundComponent(VoiceComponent);
}

float UQ6SoundPlayer::PlayDialogueVoice(EDialogueType DialogueType, const FName& Name)
{
	USoundBase* Voice = GetGameSoundResource().GetDialogueVoice(DialogueType, Name);
	if (Voice)
	{
		ValidateComponents();
		PlaySoundComponent(VoiceComponent, Voice);
		return Voice->GetDuration();
	}

	return 0.0f;
}

void UQ6SoundPlayer::StopDialogueVoice()
{
	StopSoundComponent(VoiceComponent);
}

bool UQ6SoundPlayer::HasDialogueVoice(EDialogueType DialogueType, const FName& Name) const
{
	return (GetGameSoundResource().GetDialogueVoice(DialogueType, Name) != nullptr);
}

float UQ6SoundPlayer::GetDialogueVoiceLength(EDialogueType DialogueType, const FName& Name) const
{
	USoundBase* Voice = GetGameSoundResource().GetDialogueVoice(DialogueType, Name);
	if (Voice)
	{
		return Voice->GetDuration();
	}

	return 0.0f;
}

float UQ6SoundPlayer::PlayDialogueSound(int32 SoundType)
{
	USoundBase* Sound = GetGameSoundResource().GetDialogueSound(SoundType);
	if (Sound)
	{
		ValidateComponents();
		PlaySoundComponent(VoiceComponent, Sound, 0.0f, 0.0f, true);
		return Sound->GetDuration();
	}

	return 0.0f;
}

float UQ6SoundPlayer::GetDialogueSoundLength(int32 SoundType) const
{
	USoundBase* Sound = GetGameSoundResource().GetDialogueSound(SoundType);
	if (Sound)
	{
		return Sound->GetDuration();
	}

	return 0.0f;
}

void UQ6SoundPlayer::PlaySkillBGM(TSoftObjectPtr<USoundBase> InSkillBGM)
{
	if (InSkillBGM.IsNull())
	{
		return;
	}

	USoundBase* SkillBGM = InSkillBGM.LoadSynchronous();
	if (SkillBGM)
	{
		ValidateComponents();
		SkillBGMComponent->SetSound(SkillBGM);

		CrossFadeInOutSkillBGM(true);
	}
}

void UQ6SoundPlayer::StopSkillBGM()
{
	ValidateComponents();
	CrossFadeInOutSkillBGM(false);
}

void UQ6SoundPlayer::PlayEffectSound(const FSpawnSoundParams& Param)
{
	USoundBase* Sound = Param.Sound;
	if (!Sound)
	{
		return;
	}

	if (Param.Delay > 0.f)
	{
		FTimerHandle UniqueHandle;
		FTimerDelegate HitSoundDelegate = FTimerDelegate::CreateUObject(this, &UQ6SoundPlayer::OnStartEffectSound, Param);
		GetWorld()->GetTimerManager().SetTimer(UniqueHandle, HitSoundDelegate, Param.Delay, false);
	}
	else
	{
		OnStartEffectSound(Param);
	}
}

void UQ6SoundPlayer::OnStartEffectSound(const FSpawnSoundParams Param)
{
	UGameplayStatics::PlaySound2D(this, Param.Sound, Param.VolumeMultiplier, Param.PitchMultiplier);
}

void UQ6SoundPlayer::CrossFadeInOutSkillBGM(bool bFadeIn)
{
	UAudioComponent* BGMComponent = GetActiveBGMComponent();
	if (!BGMComponent || !SkillBGMComponent)
	{
		return;
	}

	if (bFadeIn)
	{
		BGMComponent->FadeOut(0.0f, 0.0f);
		SkillBGMComponent->FadeIn(0.0f);
	}
	else
	{
		BGMComponent->FadeIn(0.0f);
		SkillBGMComponent->FadeOut(0.0f, 0.0f);
	}
}

void UQ6SoundPlayer::ValidateComponents()
{
	if (BGMComponents.Num() != MAX_BGM_COMPONENTS || !SkillBGMComponent || !VoiceComponent)
	{
		Shutdown();
		Initialize();
	}
}

void UQ6SoundPlayer::PlaySoundComponent(UAudioComponent* Component, USoundBase* Sound, float FadeInSeconds, float FadeOutSeconds, bool bRestart)
{
	if (!Component)
	{
		// It's possible if sound is turned off (GEngine->UseSound())
		return;
	}

	if (Component->IsPlaying())
	{
		if (!bRestart && Component->Sound == Sound)
		{
			return;
		}

		StopSoundComponent(Component, FadeOutSeconds);
	}

	Component->SubtitlePriority = Sound->GetSubtitlePriority();

	Component->SetSound(Sound);
	Component->FadeIn(FadeInSeconds);
}

void UQ6SoundPlayer::StopSoundComponent(UAudioComponent* Component, float FadeOutSeconds)
{
	if (Component)
	{
		Component->FadeOut(FadeOutSeconds, 0.0f);
	}
}
