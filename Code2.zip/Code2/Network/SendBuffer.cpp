#include "SendBuffer.h"

FSendBuffer::FSendBuffer(int InSize)
	: Size(InSize)
	, Fill(0)
	, Buffer(nullptr)
	, ReadPos(nullptr)
	, WritePos(nullptr)
{
	Buffer = new TArray<uint8>[(size_t)Size]; //-V201
	ReadPos = Buffer;
	WritePos = Buffer;
}

FSendBuffer::~FSendBuffer()
{
	delete [] Buffer;
}

void FSendBuffer::Add(TArray<uint8>&& Item)
{
	*WritePos = MoveTemp(Item);
	IncWritePos();
}

void FSendBuffer::Pop()
{
	ensure(ReadableSize() > 0);

	IncReadPos();
}

void FSendBuffer::IncWritePos()
{
	++Fill;
	size_t Offset = WritePos - Buffer;
	Offset = (Offset + 1) % (size_t)Size; //-V201
	WritePos = Buffer + Offset;
}

void FSendBuffer::IncReadPos()
{
	--Fill;
	size_t Offset = ReadPos - Buffer;
	Offset = (Offset + 1) % (size_t)Size; //-V201
	ReadPos = Buffer + Offset;
}
