#include "Q6ServerNetwork.h"

#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "Q6Util.h"
#include "Q6HttpServer.h"

////////////////////////////////////////////////////////////////////////////////
//
FQ6ServerNetwork::FQ6ServerNetwork(UQ6GameInstance* InGameInstance)
	: GameInstance(InGameInstance)
	, HttpServerThread(nullptr)
{
	HttpServerThread = new FQ6HttpServerThread(TEXT("Q6HttpServerThread"));
	HttpServerThread->InitGame(GameInstance);
}

FQ6ServerNetwork::~FQ6ServerNetwork()
{
	if (HttpServerThread)
	{
		delete HttpServerThread;
		HttpServerThread = nullptr;
	}
}

bool FQ6ServerNetwork::Tick(float DeltaTime)
{
	if (HttpServerThread)
	{
		HttpServerThread->GameTick(GameInstance);
	}

	return true;
}

void FQ6ServerNetwork::Stop()
{
	if (HttpServerThread)
	{
		HttpServerThread->Stop();
	}
}