// Copyright (c) 2015 XLGames, Inc. All rights reserved.
//
// ring buffer to send binary stream over libwebsockets
//
#pragma once

#include "Core.h"
#include "Engine.h"

class FSendBuffer {
public:
	explicit FSendBuffer(int InSize);
	~FSendBuffer();

	int WritableSize()
	{
		return Size - Fill;
	}

	int ReadableSize()
	{
		return Fill;
	}

	TArray<uint8>& Front()
	{
		return *ReadPos;
	}

	void Add(TArray<uint8>&& Item);
	void Pop();

private:
	void IncWritePos();
	void IncReadPos();

	int Size;
	int Fill;
	TArray<uint8>* Buffer;
	TArray<uint8>* ReadPos;
	TArray<uint8>* WritePos;
};
