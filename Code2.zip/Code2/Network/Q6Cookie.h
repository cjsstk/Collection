// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#pragma once

#include "Http.h"

class FQ6SessionId;

class FQ6Cookie
{
public:
	FQ6Cookie();
	~FQ6Cookie();

	void Reset();
	void Parse(FHttpResponsePtr Response);
	void Emit(FHttpRequestPtr Request);
	void Emit(char** Buffer, int32 Len);

private:
	void ParseHeader(const FString& Header);

	FString SessionId;
};
