// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#pragma once

#include "Engine.h"
#include "Q6Define.h"
#include "Q6Log.h"
#include "LobbyMsg.h"
#include "Interfaces/IHttpRequest.h"
#include "Q6ClientNetwork.generated.h"

class UQ6GameInstance;
class FQ6WsThread;
struct FQ6WsContext;
struct FL2CAuthLoginResp;
struct FL2CAuthEnterLobbyResp;

const int32 E_NETWORK_CLIENT = -1;

USTRUCT()
struct FResError
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	int32 Code;

	UPROPERTY()
	FL2CError Body;
};

USTRUCT()
struct FMaintenanceInfo
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	bool Success;

	UPROPERTY()
	bool Check;

	UPROPERTY()
	int64 Begin;

	UPROPERTY()
	int64 End;

	UPROPERTY()
	FString Notice;
};

// web socket response delegate
DECLARE_DELEGATE_TwoParams(FQ6NetWsDelegate, const FResError*, const TSharedRef<FJsonObject>&);

// web socket push delegate
DECLARE_DELEGATE_OneParam(FQ6NetPushDelegate, const TSharedRef<FJsonObject>&);

// network state changed delegate

UENUM(BlueprintType)
enum class ENetworkState : uint8
{
	INIT = 0,
	CONNECTED,
	LOGIN,
	LOGGED_IN,
	DISCONNECTING,
	DISCONNECTED,
	CLOSED
};

template<typename ResponseMsgType>
struct TQ6ResponseDelegate : public TBaseDelegate<void, const FResError*, const ResponseMsgType&> {};

template<typename PushMsgType>
struct TQ6PushDelegate : public TBaseDelegate<void, const PushMsgType&> {};

extern FString GEmptyJsonString;

class FScopeBool
{
public:
	FScopeBool(bool* InVar) : Var(InVar)
	{
		*Var = true;
	}

	~FScopeBool()
	{
		*Var = false;
	}

private:
	bool* Var;
};

class FScopeVolatileBool
{
public:
	FScopeVolatileBool(volatile bool* InVar) : Var(InVar)
	{
		*Var = true;
	}

	~FScopeVolatileBool()
	{
		*Var = false;
	}

private:
	volatile bool* Var;
};


struct FQ6ClientNetwork
{
public:
	struct FWsReqQueueItem
	{
		int32 Seq;
		int32 SavedSeq;
		FString Api;
		FString Body;
		FQ6NetWsDelegate Delegate;
		bool bBlocking;
	};

	FQ6ClientNetwork(UQ6GameInstance* InGameInstance);
	~FQ6ClientNetwork();

	bool Tick(float DeltaTime);

	// connect or disconnect
	void EnsureContextDisconnect();
	void Connect();
	void PanicRestartGame(const TCHAR* From);
	void BackToLoginLevel();

	void CreateSession(const FString& InIdString, const FString& InMd5Password);
	void Reconnect();
	void ReqLogin();
	void EnterLobby();
	void ReenterLobby();
	void ReqEnterLobbyFinal(FSagaType InSagaType, FRaidId InRaidId);

	void CheckMaintenance();
	void OnRequestMaintenanceCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded);
	void OnDelayedNetworkConnectFailed();

	void OnLogin(const FResError* Err, const FL2CAuthLoginResp& Resp);
	void OnEnterLobby(const FResError* Err, const FL2CAuthEnterLobbyResp& Resp);
	void OnEnterLobbyFinal(const FResError* Err, const FL2CAuthEnterLobbyFinalResp& Resp);

	// ms unit, 0 means calculating(not enough samples)
	int32 GetPing();

	double GetConnectionClosedSeconds() const { return WsConnectionClosedSeconds; }

	/**
	 * Web socket related
	 */
	bool IsWebSocketConnected() const { return bWsConnected; }

	template<typename PushMsgType>
	void RegisterPush(const FString& Category, TBaseDelegate<void, const PushMsgType&> Delegate)
	{
		InternalRegisterPush(Category, FQ6NetPushDelegate::CreateLambda([Delegate](const TSharedRef<FJsonObject>& BodyObject)
		{
			PushMsgType Msg;
			if (!JsonToPacketInternal(BodyObject, PushMsgType::StaticStruct(), &Msg))
			{
				Q6JsonLog(Warning, "CastPushDelegate: Failed to parse",
					Q6KV("MessageType", *PushMsgType::StaticStruct()->GetName()));
				return;
			}

			Delegate.ExecuteIfBound(Msg);
		}));
	}

	void UnregisterAllPush();

	/**
	* Invoke server API,  No delegate, No body, Non-blocking
	*/
	void WsInvoke(const FString& Api);

	/**
	* Request by Json String, Receive by Json object
	*/
	void WsRequest(const FQ6NetWsDelegate& Delegate, const FString& Api, const FString& Body)
	{
		WsRequestCommon(Delegate, Api, Body, true);
	}

	void WsRequestNonBlock(const FQ6NetWsDelegate& Delegate, const FString& Api, const FString& Body)
	{
		WsRequestCommon(Delegate, Api, Body, false);
	}

	/**
	* Request by Message Object, Receive by Json object
	*/
	template<typename RequestMsgType>
	void WsRequest(const FQ6NetWsDelegate& Delegate, const FString& Api, const RequestMsgType& RequestMsg)
	{
		WsRequestByStruct(Delegate, Api, RequestMsgType::StaticStruct(), &RequestMsg, true);
	}

	template<typename RequestMsgType>
	void WsRequestNonBlock(const FQ6NetWsDelegate& Delegate, const FString& Api, const RequestMsgType& RequestMsg)
	{
		WsRequestByStruct(Delegate, Api, RequestMsgType::StaticStruct(), &RequestMsg, false);
	}

	/**
	* Request by Message Object, Receive by Message Object
	*/
	template<typename ResponseMsgType, typename RequestMsgType>
	void WsRequest(const FString& Api, const RequestMsgType& RequestMsg, TBaseDelegate<void, const FResError*, const ResponseMsgType&> Delegate)
	{
		FQ6NetWsDelegate InternalDelegate;
		InternalDelegate.BindRaw(this, &FQ6ClientNetwork::CastWsDelegate<ResponseMsgType>, Delegate);
		WsRequestByStruct(InternalDelegate, Api, RequestMsgType::StaticStruct(), &RequestMsg, true);
	}

	template<typename ResponseMsgType, typename RequestMsgType>
	void WsRequestNonBlock(const FString& Api, const RequestMsgType& RequestMsg, TBaseDelegate<void, const FResError*, const ResponseMsgType&> Delegate)
	{
		FQ6NetWsDelegate InternalDelegate;
		InternalDelegate.BindRaw(this, &FQ6ClientNetwork::CastWsDelegate<ResponseMsgType>, Delegate);
		WsRequestByStruct(InternalDelegate, Api, RequestMsgType::StaticStruct(), &RequestMsg, false);
	}

	/**
	 * Request by Key-Value pair, Receive by Json Object
	 */
	template <typename ... KeyValueTypes>
	void WsRequestByPair(const FString& Api, const FQ6NetWsDelegate& Delegate, const KeyValueTypes&... KeyValues)
	{
		static const int KeyValueCount = sizeof...(KeyValueTypes);
		static_assert(KeyValueCount % 2 == 0, "Template parameter should be Key-Value pair!");

		FString JsonString = Q6MakeJsonWithPairs(KeyValues...);

		WsRequest(Delegate, Api, JsonString);
	}

private:
	UQ6GameInstance* GameInstance;
	FString ServerAddr;
	int32 ServerPort;
	int32 UseSSL;

#if !UE_SERVER
	/**
	* Web socket common
	*/
	FQ6WsThread* WebSocketThread;
#endif

	/**
	 * General Web socket related
	 */
	void WsConnect();
	void ReqEnterLobby(const FC2LAuthEnterLobby& Req);
	void WsSendReqItem(const FWsReqQueueItem& Item);
	void PeekWsRequestAndSend();
	void AddToWsRetryQueue(const FWsReqQueueItem& Item);
	void WsRequestCommon(const FQ6NetWsDelegate& Delegate, const FString& Api, const FString& Body, bool bBlocking);
	void WsRequestByStruct(const FQ6NetWsDelegate& Delegate, const FString& Api, const UStruct* Definition, const void* Struct, bool bBlocking);
	void InternalRegisterPush(const FString& Category, FQ6NetPushDelegate Delegate);
	void OnWsConnected();
	void OnWsDisconnected(int32 CloseReason, const FString& CloseDescription);
	void RaiseWsClientError(const FString& Desc);
	void HandleWsError(const FResError& Error);
	bool CloseWsConn(bool* bConnectFailed);
	bool CloseMaintenanceConn();
	void OnWsReceived(const FString& Message);
	void HandleWsResponse(const FL2CHeader& Header, const TSharedRef<FJsonObject>& Body, const FString& Message);
	void HandlePush(const FL2CHeader& Header, const TSharedRef<FJsonObject>& Body, const FString& Message);

	TSharedPtr<FJsonValue> Replacer(UProperty* Property, const void* Value);

	template<typename ResponseMsgType>
	void CastWsDelegate(const FResError* Error, const TSharedRef<FJsonObject>& BodyObject, TBaseDelegate<void, const FResError*, const ResponseMsgType&> Delegate)
	{
		ResponseMsgType Msg;
		if (!Error && !JsonToPacketInternal(BodyObject, ResponseMsgType::StaticStruct(), &Msg))
		{
			//Q6JsonLogNet(Warning, "CastWsDelegate: Failed to parse",
			//	Q6KV("MessageType", *ResponseMsgType::StaticStruct()->GetName()));
			return;
		}

		Delegate.ExecuteIfBound(Error, Msg);
	}

	int32 WsMsgSeq;
	bool bWsConnected;
	double WsConnectionRequestedSeconds;
	double WsConnectionClosedSeconds;
	FQ6WsContext* WsContext;
	TSharedPtr<IHttpRequest> MaintenanceContext;

	TQueue<FWsReqQueueItem> WsReqQueue;
	TQueue<FWsReqQueueItem> WsRetryQueue;
	TMap<FString, FQ6NetPushDelegate> PushHandlerMap;
	bool bWsInDelegate;
	int32 NumBlockingReq;
	FString Md5Password;
	FString SessionId;

	FTimerHandle CheckMaintenanceTimerHandle;

	/**
	 * Server send this random string for each session we made
	 * and we encrypt client hash with it before send it to server
	 */
	FString RandHash;

	/**
	* ETC
	*/
	FString DummySigLibHash;
};

inline bool IsClientError(const FResError& Error)
{
	return (Error.Code == E_NETWORK_CLIENT);
}

inline void SetClientError(FResError& Error)
{
	Error.Code = E_NETWORK_CLIENT;
}
