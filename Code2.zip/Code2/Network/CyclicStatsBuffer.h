// Copyright (c) 2015 XLGames, Inc. All rights reserved.
//
// ring buffer to hold statistics data
//

#pragma once

#include "Core.h"
#include "Engine.h"

template <class T, int N>
class CyclicStatsBuffer {
public:
	CyclicStatsBuffer() : Count(0), bHaveMedian(false), bHaveTotal(false) {}

	void Clear()
	{
		Count = 0;
		bHaveMedian = bHaveTotal = false;
	}

	void AddSample(T x)
	{
		Values[Count++ % N] = x;
		bHaveMedian = bHaveTotal = false;
	}

	bool Empty() const
	{
		return Count == 0;
	}

	int Size() const
	{
		return Count > N ? N : Count;
	}

	int Capacity() const
	{
		return N;
	}

	T GetTotal() const
	{
		if (!bHaveTotal) {
			T sum = 0;
			int last = Size();
			for (int i = 0; i < last; i++)
				sum += Values[i];
			Total = sum;
			bHaveTotal = true;
		}
		return Total;
	}

	T GetMedian() const
	{
		if (!bHaveMedian) {
			T temp[N];
			int last = Size();
			memcpy(temp, Values, last * sizeof(T)); //-V104
			Sort(temp, last);
			Median = temp[last / 2];
			bHaveMedian = true;
		}
		return Median;
	}

	float GetAverage() const
	{
		return float(GetTotal()) / Size();
	}

	T GetFirst() const
	{
		assert(!Empty());
		if (Count > N)
			return Values[Count % N];
		else
			return Values[0];
	}

	T GetLast() const
	{
		assert(!Empty());
		if (Count >= N)
			return Values[(Count + N - 1) % N];
		else
			return Values[Count - 1];
	}

	T GetAt(int i) const
	{
		assert(!Empty());
		if (Count > N)
			return Values[(Count + N + i) % N];
		else
			return Values[i];
	}

private:
	int Count;
	T Values[N];

	mutable bool bHaveMedian;
	mutable bool bHaveTotal;
	mutable T Median;
	mutable T Total;
};
