// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6HttpServer.h"

#include "JsonObjectConverter.h"
#include "Q6Define.h"
#include "Q6GameInstance.h"
#include "Q6Log.h"
#include "Q6Util.h"
#if PLATFORM_WINDOWS
#include "Windows/AllowWindowsPlatformTypes.h"
#endif

#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)

#undef INT64_FMT
#undef INT64_X_FMT
#undef SIZE_T_FMT

#include "mongoose.h"
#endif

#if PLATFORM_WINDOWS
#include "Windows/HideWindowsPlatformTypes.h"
#endif

static FQ6HttpServerThread* HttpThread = nullptr;

#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)
static struct mg_serve_http_opts s_http_server_opts;

void ev_handler(FMGConnection* MGConn, int Ev, void *MessagePtr) {
	if (Ev == MG_EV_HTTP_REQUEST) {
		struct http_message* hm = (struct http_message*)MessagePtr;

		if (HttpThread)
		{
			HttpThread->AddRequest(MGConn, hm);
		}
	}
}
#endif

FQ6HttpServerThread::FQ6HttpServerThread(const TCHAR* ThreadName)
	: Thread(nullptr)
	, MGManager(nullptr)
	, NextRequestId(1)
	, ListenPortStr("8889")
	, GameLocked(false)
{
	HttpThread = this;
	Thread = FRunnableThread::Create(this, ThreadName, 128 * 1024, TPri_AboveNormal,
		FPlatformAffinity::GetPoolThreadMask());
	if (!Thread)
	{
		Q6JsonLogNet(Error, "FQ6HttpServerThread cannot create thread");
	}
}

FQ6HttpServerThread::~FQ6HttpServerThread()
{
	if (Thread)
	{
		Thread->Kill(true);
		delete Thread;
		Thread = nullptr;
	}

#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)
	if (MGManager)
	{
		delete MGManager;
		MGManager = nullptr;
	}
#endif
}

uint32 FQ6HttpServerThread::Run()
{
	while (!HasExitRequest()) {
#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)
		mg_mgr_poll(MGManager, 1000);
#endif
		SendResponses();
	}

	return 0;
}

void FQ6HttpServerThread::SendResponses()
{
#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)
	FScopeLock ScopeLock(&Lock);

	if (Requests.Num() == 0)
	{
		return;
	}

	for (int32 i = Requests.Num() - 1; i >= 0; --i)
	{
		const FQ6HttpContext& InRequest = Requests[i];
		if (InRequest.RequestState == EQ6HttpRequestState::Completed ||
			InRequest.RequestState == EQ6HttpRequestState::Failed)
		{
			FJ2LJudgementResponse Judgement;
			Judgement.ErrorCode = InRequest.Judgement;
			FString OutJsonStr;
			FJsonObjectConverter::UStructToJsonObjectString(FJ2LJudgementResponse::StaticStruct(), &Judgement, OutJsonStr, 0, 0);
			mg_send_head(InRequest.Conn, 200, -1, NULL);
			mg_printf_http_chunk(InRequest.Conn, TCHAR_TO_ANSI(*OutJsonStr));
			mg_send_http_chunk(InRequest.Conn, "", 0);
			Requests.RemoveAtSwap(i);
		}
	}
#endif
}

void FQ6HttpServerThread::Stop()
{
	ExitRequest.Increment();
}

bool FQ6HttpServerThread::Init()
{
#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)
	MGManager = new FMGManager;
	if (!MGManager)
	{
		Q6JsonLogNet(Error, "FMGManager cannot create thread");
	}

	mg_mgr_init(MGManager, NULL);

	FString PortValue;
	if (FParse::Value(FCommandLine::Get(), TEXT("ListenPort"), PortValue))
	{
		PortValue = PortValue.Replace(TEXT("="), TEXT(""));
		ListenPortStr = PortValue;
	}

	Q6JsonLogNet(Display, "Starting web server on port ", Q6KV("Port", *ListenPortStr));
	FMGConnection* MGConnection = mg_bind(MGManager, TCHAR_TO_ANSI(*ListenPortStr), ev_handler);
	if (MGConnection == NULL) {
		Q6JsonLogNet(Display, "Failed to create listener");
		return false;
	}

	// Set up HTTP server parameters
	mg_set_protocol_http_websocket(MGConnection);
	s_http_server_opts.document_root = ".";  // Serve current directory
	s_http_server_opts.enable_directory_listing = "yes";
#endif

	return true;
}

void FQ6HttpServerThread::Exit()
{
#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)
	mg_mgr_free(MGManager);
#endif
}

void FQ6HttpServerThread::InitGame(UQ6GameInstance* InGameInstance)
{
	InGameInstance->GetJudgementDelegate().BindRaw(this, &FQ6HttpServerThread::OnCompleteJudgement);
}

void FQ6HttpServerThread::AddRequest(FMGConnection* InConn, FMGHttpMessage* InMessage)
{
#if UE_SERVER || (PLATFORM_WINDOWS && UE_EDITOR)
	FQ6HttpContext InContext;
	InContext.RequestId = NextRequestId++;
	InContext.Conn = InConn;
	InContext.Message = InMessage;
	InContext.RequestBodyJSonStr = InMessage->body.p;
	InContext.RequestBodyJSonStr = InContext.RequestBodyJSonStr.Left((int32)InMessage->body.len);
	InContext.RequestState = EQ6HttpRequestState::Queued;

	if (InMessage->query_string.p != nullptr && InMessage->query_string.len > 0)
	{
		mg_str QueryString = mg_mk_str_n(InMessage->query_string.p, InMessage->query_string.len);
		int Ret = mg_url_decode(InMessage->query_string.p, InMessage->query_string.len, const_cast<char*>(QueryString.p), QueryString.len, 1);
		if (Ret >= 0)
		{
			InContext.QueryString = ANSI_TO_TCHAR(QueryString.p);
		}
	}

	if (GameLocked)
	{
		Requests.Add(InContext);
	}
	else
	{
		FScopeLock ScopeLock(&Lock);
		Requests.Add(InContext);
	}
#endif
}

// Accessing GameInstance should be done AFTER acquire Lock.
void FQ6HttpServerThread::GameTick(UQ6GameInstance* InGameInstance)
{
	FScopeLock ScopeLock(&Lock);
	FScopeVolatileBool ScopeBool(&GameLocked);

	for (auto& InRequest : Requests)
	{
		if (InRequest.RequestState == EQ6HttpRequestState::Queued)
		{
			InRequest.RequestState = EQ6HttpRequestState::Processing;
			EQ6Judgement RequestJudge = InGameInstance->JudgeChronicle(InRequest.RequestId, InRequest.QueryString, InRequest.RequestBodyJSonStr);
			if (RequestJudge != EQ6Judgement::NotGuilty)
			{
				InRequest.RequestState = EQ6HttpRequestState::Failed;
				InRequest.Judgement = RequestJudge;
			}
		}
	}
}

void FQ6HttpServerThread::OnCompleteJudgement(int32 InRequestId, EQ6Judgement InJudgement)
{
	FScopeLock ScopeLock(&Lock);
	FScopeVolatileBool ScopeBool(&GameLocked);

	FQ6HttpContext* HttpContext = Requests.FindByPredicate([InRequestId](const FQ6HttpContext& InRequest) {
		return InRequest.RequestId == InRequestId;
	});

	if (!HttpContext)
	{
		Q6JsonLogBro(Warning, "Unknown request completed", Q6KV("RequestId", InRequestId));
		return;
	}

	HttpContext->RequestState = EQ6HttpRequestState::Completed;
	HttpContext->Judgement = InJudgement;
}