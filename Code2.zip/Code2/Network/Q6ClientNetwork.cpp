#include "Q6ClientNetwork.h"

#include "Q6GameInstance.h"
#include "Json.h"
#include "JsonObjectConverter.h"

#if UE_SERVER
class FQ6WsThread {}; // Dummy
#else
#include "Q6WebSocket.h"
#endif

#include "Http.h"
#include "HttpRetrySystem.h"
#include "Q6Log.h"
#include "Q6Util.h"
#include "LevelUtil.h"
#include "HSAction.h"
#include "BaseHUD.h"
#include "ErrCode_gen.h"
#include "LobbyObj_gen.h"
#include "Q6.h"
#include "RaidManager.h"
#include "Interfaces/IHttpResponse.h"
#include "Internationalization/Text.h"
#include "HttpModule.h"

/////////////////////////////////////////////////////
// Global variables
FString GEmptyJsonString(TEXT("{}"));

/////////////////////////////////////////////////////
// Console variables
static TAutoConsoleVariable<FString> CVarQ6ServerAddr(
	TEXT("q6.ServerAddr"),
	//TEXT("fgt.q6.cube-xlgames.com"),
	TEXT("dev.q6.cube-xlgames.com"),
	TEXT("Server address(name or ip) to connect.\n"),
	ECVF_Default);

static TAutoConsoleVariable<FString> CVarQ6MaintenanceApiHost(
	TEXT("q6.MaintenanceApiHost"),
	TEXT("dev.maintenance.q6.cube-xlgames.com:8900"),
	TEXT("maintenance server host.\n"),
	ECVF_Default);

static TAutoConsoleVariable<int32> CVarQ6CheckMaintenance(
	TEXT("q6.CheckMaintenance"),
	1,
	TEXT("use maintenance-checking or not. 1 or 0.\n"),
	ECVF_Default);

static TAutoConsoleVariable<int32> CVarQ6UseHttpsToCheckMaintenance(
	TEXT("q6.UseHttpsToCheckMaintenance"),
	0,
	TEXT("use https to check maintenance. 1 or 0.\n"),
	ECVF_Default);

static TAutoConsoleVariable<float> CVarQ6CheckMaintenanceInterval(
	TEXT("Q6.CheckMaintenanceInterval"),
	1.0f,
	TEXT("web socket minimum interval to try reconnect in seconds\n"),
	ECVF_Default);

/*
static TAutoConsoleVariable<FString> CVarQ6ServerAddrLocal(
	TEXT("q6.ServerAddr"),
	TEXT("127.0.0.1"),
	TEXT("Server address(name or ip) to connect.\n"),
	ECVF_Default);
*/

static TAutoConsoleVariable<int32> CVarQ6ServerPort(
	TEXT("q6.ServerPort"),
	8888,
	TEXT("Server port to connect.\n"),
	ECVF_Default);

// from libwebsockets.h
//enum lws_client_connect_ssl_connection_flags {
//	LCCSCF_USE_SSL = (1 << 0),
//	LCCSCF_ALLOW_SELFSIGNED = (1 << 1),
//	LCCSCF_SKIP_SERVER_CERT_HOSTNAME_CHECK = (1 << 2)
//};
// use one of 0, 1, 3, 7

static TAutoConsoleVariable<int32> CVarQ6UseSSL(
	TEXT("q6.UseSSL"),
	1, // ref; lws_client_connect_ssl_connection_flags
	TEXT("enable(1/3/7) or disable(0) SSL.\n"),
	ECVF_Default);

static TAutoConsoleVariable<int32> CVarQ6WsMaxMessageQueue(
	TEXT("q6.WebSocketMaxMessageQueue"),
	256,
	TEXT("web socket max queue size for messages to send\n"),
	ECVF_Default);

static TAutoConsoleVariable<FString> CVarQ6ServerRegion(
	TEXT("q6.ServerRegion"),
	TEXT("Default"),
	TEXT("Server region for HIVE Maintenance Popup.\n"),
	ECVF_Default);

static TAutoConsoleVariable<int32> CVarQ6ShowMaintenancePopup(
	TEXT("q6.MaintenancePopup"),
	1,
	TEXT("on/off for HIVE Maintenance Popup.\n"),
	ECVF_Default);

const FHttpRetrySystem::FRetryLimitCountSetting& InRetryLimitCountOverride = FHttpRetrySystem::FRetryLimitCountSetting(10);
const FHttpRetrySystem::FRetryResponseCodes& InRetryResponseCodes = FHttpRetrySystem::FRetryResponseCodes();

static const TArray<FString> ApisBeforeEnterLobby = {
	FString(TEXT("auth/login")),
	FString(TEXT("auth/reconnect")),
	FString(TEXT("auth/enterLobby")),
	FString(TEXT("auth/enterLobbyFinal")),
	// contents (currency)
	FString(TEXT("currency/load")),
	// contents (character/equip)
	FString(TEXT("character/list")),
	FString(TEXT("bagItem/list")),
	FString(TEXT("relic/list")),
	FString(TEXT("sculpture/list")),
	// contents (others-sorted)
	FString(TEXT("actRecord/list")),
	FString(TEXT("codex/listChar")),
	FString(TEXT("codex/listSculpture")),
	FString(TEXT("codex/listRelic")),
	FString(TEXT("weeklyMission/load")),
	FString(TEXT("charMission/list")),
	FString(TEXT("eventMission/list")),
	FString(TEXT("bond/load")),
	FString(TEXT("friend/load")),
	FString(TEXT("friendCooltime/list")),
	FString(TEXT("jokerSet/load")),
	FString(TEXT("party/load")),
	FString(TEXT("saga/load")),
	FString(TEXT("special/load")),
	FString(TEXT("trainingCenter/load")),
	FString(TEXT("daily/list")),
	FString(TEXT("pyramid/load")),
	FString(TEXT("temple/load")),
	FString(TEXT("powerPlant/load")),
	FString(TEXT("pet/load")),
	FString(TEXT("vacation/load")),
	FString(TEXT("smelter/load")),
	FString(TEXT("alchemylab/load")),
	FString(TEXT("raid/list")),
	FString(TEXT("mail/list")),
	FString(TEXT("checkIn/list")),
	FString(TEXT("shop/list")),
	FString(TEXT("lobbyTemplate/list")),
	FString(TEXT("lobbySet/load")),
	FString(TEXT("userTitle/list")),
	FString(TEXT("contentFeatureOpen/list")),
	FString(TEXT("summon/load")),
	FString(TEXT("eventContent/list")),
	FString(TEXT("avatar/load")),
};

static bool IsApiBeforeEnterLobby(const FString& Api)
{
	return ApisBeforeEnterLobby.Contains(Api);
}

static const TArray<FString> ApisOnCombatCube = {
	FString(TEXT("combatCube/action")),
	FString(TEXT("combatCube/state")),
};

static bool IsApiOnCombatCube(const FString& Api)
{
	return ApisOnCombatCube.Contains(Api);
}

////////////////////////////////////////////////////////////////////////////////
//
FQ6ClientNetwork::FQ6ClientNetwork(UQ6GameInstance* InGameInstance)
	: GameInstance(InGameInstance)
	, ServerPort(-1)
#if !UE_SERVER
	, WebSocketThread(nullptr)
#endif
	, WsMsgSeq(-1)
	, bWsConnected(false)
	, WsConnectionRequestedSeconds(0.0)
	, WsConnectionClosedSeconds(0.0)
	, WsContext(nullptr)
	, MaintenanceContext(nullptr)
	, bWsInDelegate(false)
	, NumBlockingReq(0)
{

	UseSSL = CVarQ6UseSSL.GetValueOnGameThread();
#if !UE_SERVER
	WebSocketThread = new FQ6WsThread(TEXT("Q6WsThread"));
#endif

	uint8 DummyHash[FSHA1::DigestSize];
	FMemory::Memzero(DummyHash, sizeof(DummyHash));
	DummySigLibHash = BytesToHex(DummyHash, FSHA1::DigestSize);

	// obiwan temporary
	ServerAddr = CVarQ6ServerAddr.GetValueOnGameThread();
	// ServerAddr = CVarQ6ServerAddrLocal.GetValueOnGameThread();
	ServerPort = CVarQ6ServerPort.GetValueOnGameThread();
}

FQ6ClientNetwork::~FQ6ClientNetwork()
{
#if !UE_SERVER
	delete WebSocketThread;
#endif
}

bool FQ6ClientNetwork::Tick(float DeltaTime)
{
#if !UE_SERVER
	WebSocketThread->GameTick();
#endif
	//uint32 FileCount = 0, FailingCount = 0, FailedCount = 0, CompletedCount = 0;
	//GEngine->AddOnScreenDebugMessage((uint64)((PTRINT)this), 0.f, FColor::Red, FString::Printf(TEXT("%d, %d, %d, %d"), FileCount, FailingCount, FailedCount, CompletedCount));
	return true;
}

void FQ6ClientNetwork::EnsureContextDisconnect()
{
	if (WsContext)
	{
		CloseWsConn(nullptr);
	}

	CloseMaintenanceConn();

	GameInstance->SetLogin(false);
}

void FQ6ClientNetwork::Connect()
{
	EnsureContextDisconnect();

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (!Q6BaseHUD)
	{
		PanicRestartGame(TEXT("Connect"));
		return;
	}


	Q6BaseHUD->OnNetworkStartConnect();

	if (CVarQ6CheckMaintenance.GetValueOnGameThread())
	{
		CheckMaintenance();
	}
	else
	{
		WsConnect();
	}
}

int32 FQ6ClientNetwork::GetPing()
{
#if UE_SERVER
	return 0;
#else
	return WebSocketThread->GetPingMs(WsContext);
#endif
}

void FQ6ClientNetwork::UnregisterAllPush()
{
	for (auto& Elem : PushHandlerMap)
	{
		FQ6NetPushDelegate& Delegate = Elem.Value;
		Delegate.Unbind();
	}

	PushHandlerMap.Empty();
}

void FQ6ClientNetwork::WsInvoke(const FString& Api)
{
	FQ6NetWsDelegate DummyDelegate;
	WsRequest(DummyDelegate, Api, GEmptyJsonString);
}

void FQ6ClientNetwork::WsConnect()
{
	Q6JsonLogNet(Display, "WebSocket", Q6KV("ServerAddr", *ServerAddr), Q6KV("port", ServerPort), Q6KV("UseSSL", UseSSL));

#if !UE_SERVER
	check(WsContext == nullptr);
	WsConnectionRequestedSeconds = FPlatformTime::Seconds();

	FQ6WsConfig* Config = new FQ6WsConfig;
	Config->ServerAddr = ServerAddr;
	Config->ServerPort = ServerPort;
	Config->UseSSL = UseSSL;
	Config->bCompress = true;
	Config->ReceivedCallBack.BindRaw(this, &FQ6ClientNetwork::OnWsReceived);
	Config->ConnectedCallBack.BindRaw(this, &FQ6ClientNetwork::OnWsConnected);
	Config->ErrorCallBack.BindRaw(this, &FQ6ClientNetwork::OnWsDisconnected);
	Config->Cookie = nullptr;
	Config->Protocol = EQ6WsProtocol::Lobby;
	Config->SendQueueSize = CVarQ6WsMaxMessageQueue.GetValueOnGameThread();
	WsContext = WebSocketThread->CreateConn(Config);
#endif
}

void FQ6ClientNetwork::ReqEnterLobby(const FC2LAuthEnterLobby& Req)
{
	WsRequest("auth/enterLobby", Req,
		TQ6ResponseDelegate<FL2CAuthEnterLobbyResp>::CreateRaw(this, &FQ6ClientNetwork::OnEnterLobby));

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (Q6BaseHUD)
	{
		Q6BaseHUD->OnNetworkEnteringLobby();
		return;
	}

	PanicRestartGame(TEXT("ReqEnterLobby"));
}

void FQ6ClientNetwork::WsSendReqItem(const FWsReqQueueItem& Item)
{
#if !UE_SERVER
	FC2LHeader Header(Item.Seq, Item.Api, Item.SavedSeq);
	FString HeaderStr;
	if (!FJsonObjectConverter::UStructToJsonObjectString(FC2LHeader::StaticStruct(), &Header, HeaderStr, 0, 0, 0))
	{
		RaiseWsClientError(FString::Printf(TEXT("WsSendReqItem json error %s"), *Item.Api));
		return;
	}

	FString Message = FString::Printf(TEXT("{\"header\":%s,\"body\":%s}"), *HeaderStr, *Item.Body);

	if (!WebSocketThread->Send(WsContext, Message))
	{
		RaiseWsClientError(FString::Printf(TEXT("WsSendReqItem send error %s"), *Item.Api));
	}
#endif
}

void FQ6ClientNetwork::PeekWsRequestAndSend()
{
	FWsReqQueueItem FirstItem;
	bool bPeeked = WsReqQueue.Peek(FirstItem);
	if (!bPeeked)
	{
		return;
	}

	WsSendReqItem(FirstItem);
}

void FQ6ClientNetwork::AddToWsRetryQueue(const FWsReqQueueItem& Item)
{
	WsRetryQueue.Enqueue(Item);

	if (Item.bBlocking)
	{
		ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
		if (!Q6BaseHUD)
		{
			PanicRestartGame(TEXT("WsRequestCommon"));
			return;
		}

		Q6BaseHUD->OnNetworkQueuingRequestToRetry();
	}
}

void FQ6ClientNetwork::WsRequestCommon(const FQ6NetWsDelegate& Delegate, const FString& Api, const FString& Body, bool bBlocking)
{
#if !UE_SERVER
	FWsReqQueueItem Item;
	Item.Seq = 0;
	Item.SavedSeq = 0;
	Item.Api = Api;
	Item.Body = Body;
	Item.bBlocking = bBlocking;
	Item.Delegate = Delegate;

	/* auto retry when reconnected. */
	if (IsWebSocketConnected())
	{
		if (!GameInstance->IsEnteredLobby() && !IsApiBeforeEnterLobby(Api) && !GameInstance->GetNoAuthCC())
		{
			AddToWsRetryQueue(Item);
			return;
		}

		if (GameInstance->GetNoAuthCC() && !IsApiOnCombatCube(Api))
		{
			return;
		}
	}
	else
	{
		if (IsApiBeforeEnterLobby(Api))
		{
			RaiseWsClientError(FString::Printf(TEXT("WsRequestCommon no connection %s"), *Api));
			return;
		}
		AddToWsRetryQueue(Item);
		return;
	}
	/* auto retry when reconnected. */

	bool bQueueEmpty = WsReqQueue.IsEmpty();
	Item.Seq = WsMsgSeq++;
	WsReqQueue.Enqueue(Item);

	if (bBlocking)
	{
		if (++NumBlockingReq == 1)
		{
			ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
			if (!Q6BaseHUD)
			{
				PanicRestartGame(TEXT("WsRequestCommon"));
				return;
			}

			Q6BaseHUD->OnNetworkStartBlockingRequest();
		}
	}


	if (!bQueueEmpty || bWsInDelegate)
	{
		return;
	}

	WsSendReqItem(Item);
#endif
}

TSharedPtr<FJsonValue> FQ6ClientNetwork::Replacer(UProperty* Property, const void* Value)
{
	TSharedPtr<FJsonValue> NullSharedPtr;

	if (UEnumProperty* EnumProperty = Cast<UEnumProperty>(Property))
	{
		return MakeShareable(new FJsonValueNumber(EnumProperty->GetUnderlyingProperty()->GetSignedIntPropertyValue(Value)));
	}

	if (UInt64Property* Int64Property = Cast<UInt64Property>(Property)) {
		FString IdTypeName = FString(TEXT("S"));
		FString VarName = Property->GetNameCPP();
		if (VarName.Equals(IdTypeName)) {
			FString StringValue;
			Property->ExportTextItem(StringValue, Value, NULL, NULL, PPF_None);
			return MakeShareable(new FJsonValueString(StringValue));
		}
	}

	return NullSharedPtr;
}

void FQ6ClientNetwork::WsRequestByStruct(const FQ6NetWsDelegate& Delegate, const FString& Api, const UStruct* Definition, const void* Struct, bool bBlocking)
{
	FJsonObjectConverter::CustomExportCallback cbDelegate;
	cbDelegate.BindRaw(this, &FQ6ClientNetwork::Replacer);

	FString JsonStr;
	if (!FJsonObjectConverter::UStructToJsonObjectString(Definition, Struct, JsonStr, 0, 0, 0, &cbDelegate))
	{
		RaiseWsClientError(FString::Printf(TEXT("WsRequestByStruct to json str %s"), *Api));
		return;
	}

	WsRequestCommon(Delegate, Api, JsonStr, bBlocking);
}

void FQ6ClientNetwork::InternalRegisterPush(const FString& Category, FQ6NetPushDelegate Delegate)
{
	PushHandlerMap.Add(Category, Delegate);
}

void FQ6ClientNetwork::OnWsConnected()
{
	if (!WsContext)
	{
		Q6JsonLogNet(Warning, "web socket connected with no context");
		return;
	}

	WsMsgSeq = 1;
	bWsConnected = true;
	Q6JsonLogNet(Display, "web socket connected");

	if (!GameInstance->GetNoAuthCC())
	{
		ReqLogin();
	}
	else
	{
		GameInstance->ReqNoAuthCC();
	}

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (Q6BaseHUD)
	{
		Q6BaseHUD->OnNetworkConnected();
		return;
	}

	PanicRestartGame(TEXT("OnWsConnected"));
}

void FQ6ClientNetwork::OnWsDisconnected(int32 CloseReason, const FString& CloseDescription)
{
	if (!WsContext)
	{
		Q6JsonLogNet(Warning, "web socket disconnected with no context");
		return;
	}

	bool bConnectFailed;
	if (!CloseWsConn(&bConnectFailed))
	{
		return;
	}

	Q6JsonLogNet(Display, "web socket disconnected", Q6KV("Code", CloseReason), Q6KV("Desc", CloseDescription));

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);

	// Check if the server kicked.
	const static int32 KICK_CLOSE_CODE = 4001;
	if (CloseReason == KICK_CLOSE_CODE)
	{
		if (Q6BaseHUD)
		{
			Q6BaseHUD->OnKicked(CloseDescription);
			return;
		}

		Q6JsonLogNet(Warning, "Kicked by server! Closing the app...");

#if PLATFORM_IOS
		FGenericPlatformMisc::RequestExit(true);
#else
		FGenericPlatformMisc::RequestExit(false);
#endif // PLATFORM_IOS

		return;
	}

	// Try reconnecting.
	if (Q6BaseHUD)
	{
		bConnectFailed ? Q6BaseHUD->OnNetworkConnectFailed() : Q6BaseHUD->OnNetworkDisconnected();
		return;
	}

	PanicRestartGame(TEXT("OnWsDisconnected"));
}

void FQ6ClientNetwork::RaiseWsClientError(const FString& Desc)
{
	FResError Error;
	Error.Code = E_NETWORK_CLIENT;
	Error.Body.Error = Desc;
	HandleWsError(Error);
}

void FQ6ClientNetwork::HandleWsError(const FResError& Error)
{
	bool bConnectFailed;
	if (!CloseWsConn(&bConnectFailed))
	{
		return;
	}

	Q6JsonLogNet(Display, "web socket error", Q6KV("code", Error.Code), Q6KV("desc", *(Error.Body.Error)));

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (!Q6BaseHUD)
	{
		PanicRestartGame(TEXT("HandleWsError"));
		return;
	}

	if (bConnectFailed)
	{
		Q6BaseHUD->OnNetworkConnectFailed();
		return;
	}

#if UE_BUILD_SHIPPING
	if (IsClientError(Error))
	{
		Q6BaseHUD->OnNetworkError(Q6_ERROR_RESTART_GAME, Error.Body.Error);
	}
	else if (Error.Code == 401)
	{
		Q6BaseHUD->OnNetworkError(Q6_ERROR_SESSION_EXPIRE, Error.Body.Error);
	}
	else
	{
		Q6BaseHUD->OnNetworkError(Q6_ERROR_INTERNAL, Error.Body.Error);
	}
#else
	Q6BaseHUD->OnNetworkError(Error.Body.ErrorCode, Error.Body.Error);
#endif
}

bool FQ6ClientNetwork::CloseWsConn(bool *bConnectFailed)
{
	if (WsContext == nullptr)
	{
		Q6JsonLogNet(Error, "CloseWsConn no context");
		return false;
	}

#if !UE_SERVER
	WebSocketThread->RemoveConn(WsContext);
#endif

	WsContext = nullptr;
	if (bConnectFailed)
	{
		if (bWsConnected)
		{
			WsConnectionClosedSeconds = FPlatformTime::Seconds();
		}

		*bConnectFailed = bWsConnected ? false : true;
	}

	bWsConnected = false;
	NumBlockingReq = 0;

	FWsReqQueueItem RetryItem;
	while (WsReqQueue.Dequeue(RetryItem))
	{
		if (!IsApiBeforeEnterLobby(RetryItem.Api))
		{
			AddToWsRetryQueue(RetryItem);
		}
	}

	return true;
}


bool FQ6ClientNetwork::CloseMaintenanceConn()
{
	if (nullptr != MaintenanceContext)
	{
		MaintenanceContext->OnProcessRequestComplete().Unbind();
		MaintenanceContext->CancelRequest();
		MaintenanceContext.Reset();
		return true;
	}

	return false;
}

void FQ6ClientNetwork::PanicRestartGame(const TCHAR* From)
{
	ensure(0);
	Q6JsonLogNet(Error, "PanicRestartGame", Q6KV("from", From));

	BackToLoginLevel();
}

void FQ6ClientNetwork::BackToLoginLevel()
{
	EnsureContextDisconnect();
	UnregisterAllPush();

	ULevelUtil::LoadLoginLevel(GameInstance->GetWorld());
}

void FQ6ClientNetwork::CreateSession(const FString& InIdString, const FString& InMd5Password)
{
	GameInstance->ResetHUDStore();

	// ID/PW is not need now. but this was already made like this.
	ACTION_DISPATCH_AccountName(InIdString);
	Md5Password = InMd5Password;

	Connect();
}

void FQ6ClientNetwork::Reconnect()
{
	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (!Q6BaseHUD)
	{
		PanicRestartGame(TEXT("Connect"));
		return;
	}

	Q6BaseHUD->OnNetworkStartConnect();


	if (CVarQ6CheckMaintenance.GetValueOnGameThread())
	{
		CheckMaintenance();
	}
	else
	{
		WsConnect();
	}
}

void FQ6ClientNetwork::ReqLogin()
{
	if (!WsContext)
	{
		Q6JsonLogNet(Warning, "ReqLogin with no context");
		return;
	}

	const UWorldUser& WorldUser = GetUser();

	FC2LAuthLogin Req;
	Req.Name = WorldUser.GetAccountName();
	Req.Password = Md5Password;
	Req.Language = Q6Util::GetCurrentCultureCountryCode();
	Req.Device = Q6Util::GetDeviceModel();
	Req.Platform = UGameplayStatics::GetPlatformName();
	WsRequest("auth/login", Req,
		TQ6ResponseDelegate<FL2CAuthLoginResp>::CreateRaw(this, &FQ6ClientNetwork::OnLogin));
}

void FQ6ClientNetwork::OnLogin(const FResError* Err, const FL2CAuthLoginResp& Resp)
{
	if (Err)
	{
		ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
		if (!Q6BaseHUD)
		{
			PanicRestartGame(TEXT("HandleWsError"));
			return;
		}

		// Q3 Has the feature that block account
		//if (Error->Body.Error.Equals("auth-banned"))
		//{
		//	FNoParamDelegate Delegate;
		//	Delegate.BindLambda([this]() {
		//		Q3JsonLogObiwan(Warning, "OnBanned(). Closing the app...");
		//		FGenericPlatformMisc::RequestExit(false);
		//	});
		//	Q6BaseHUD->OnAlert(Error->Body.Error, Delegate);
		//}
		//else
		//{
			Q6BaseHUD->OnError(Err);
		//}
		return;
	}

	if (!Resp.Succeed)
	{
		ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
		FText Error = FText::FromString(FString("failed-to-login"));
		BaseHUDOnError(Q6BaseHUD, Error);
		return;
	}

	Q6JsonLogNet(Verbose, "OnLogin",
		Q6KV("SessionId", Resp.SessionId),
		Q6KV("Region", Resp.Region),
		Q6KV("RandHash", Resp.RandHash),
		Q6KV("Succeed", Resp.Succeed));
	SessionId = Resp.SessionId;
	RandHash = Resp.RandHash;
	GameInstance->SetLogin(true);

	ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
	if (Q6BaseHUD)
	{
		Q6BaseHUD->OnNetworkLogin(Resp);
		return;
	}

	PanicRestartGame(TEXT("OnCreateSessionRes"));
}

void FQ6ClientNetwork::EnterLobby()
{
	FC2LAuthEnterLobby Req;
	Req.IsComingBack = false;

	ReqEnterLobby(Req);
}

void FQ6ClientNetwork::ReenterLobby()
{
	FC2LAuthEnterLobby Req;
	Req.IsComingBack = true;

	ReqEnterLobby(Req);
}

void FQ6ClientNetwork::ReqEnterLobbyFinal(FSagaType InSagaType, FRaidId InRaidId)
{
	FC2LAuthEnterLobbyFinal Req;
	Req.OngoingSagaType = InSagaType;
	Req.RaidId = InRaidId;

	WsRequest("auth/enterLobbyFinal", Req,
		TQ6ResponseDelegate<FL2CAuthEnterLobbyFinalResp>::CreateRaw(this, &FQ6ClientNetwork::OnEnterLobbyFinal));
}

void FQ6ClientNetwork::CheckMaintenance()
{
	Q6JsonLog(Verbose, "CheckMaintenance");

	//check(!MaintenanceContext.IsValid());
	if (!MaintenanceContext.IsValid())
	{
		const FString url = CVarQ6UseHttpsToCheckMaintenance.GetValueOnGameThread() ?
			TEXT("https://") + CVarQ6MaintenanceApiHost.GetValueOnGameThread() :
			TEXT("http://") + CVarQ6MaintenanceApiHost.GetValueOnGameThread();

		MaintenanceContext = FHttpModule::Get().CreateRequest();
		MaintenanceContext->OnProcessRequestComplete().BindRaw(this, &FQ6ClientNetwork::OnRequestMaintenanceCompleted);
		MaintenanceContext->SetHeader(TEXT("Content-Type"), TEXT("application/json; charset=utf-8"));
		MaintenanceContext->SetURL(url);
		MaintenanceContext->SetVerb("GET");
		MaintenanceContext->ProcessRequest();
	}

}

void FQ6ClientNetwork::OnRequestMaintenanceCompleted(FHttpRequestPtr HttpRequest, FHttpResponsePtr HttpResponse, bool bSucceeded)
{
	if (!bSucceeded || !HttpResponse.IsValid())
	{
		Q6JsonLog(Error, "Failed to get maintenance data", Q6KV("URL", HttpRequest->GetURL()));
		OnDelayedNetworkConnectFailed();
		return;
	}

	if (!EHttpResponseCodes::IsOk(HttpResponse->GetResponseCode()))
	{
		Q6JsonLog(Error, "Error response on maintenance request",
			Q6KV("URL", HttpRequest->GetURL()),
			Q6KV("ResponseCode", HttpResponse->GetResponseCode()),
			Q6KV("Response", HttpResponse->GetContentAsString()));
		OnDelayedNetworkConnectFailed();
		return;
	}

	FString ResponseStr = HttpResponse->GetContentAsString();

	FMaintenanceInfo Info;
	if (!JsonToPacket(ResponseStr, &Info))
	{
		Q6JsonLog(Error, "Error to deserialize response body",
			Q6KV("URL", HttpRequest->GetURL()),
			Q6KV("ResponseCode", HttpResponse->GetResponseCode()),
			Q6KV("Response", HttpResponse->GetContentAsString()));
		OnDelayedNetworkConnectFailed();
		return;
	}

	Q6JsonLog(Verbose, "maintenance data",
		Q6KV("success", Info.Success),
		Q6KV("check", Info.Check),
		Q6KV("begin", Info.Begin),
		Q6KV("end", Info.End),
		Q6KV("notice", Info.Notice));

	if (Info.Check)
	{
		GetBaseHUD(GameInstance)->OnNetworkMaintenance(Info);
		return;
	}

	EnsureContextDisconnect();
	WsConnect();
}


void FQ6ClientNetwork::OnDelayedNetworkConnectFailed()
{
	GameInstance->GetWorld()->GetTimerManager().SetTimer(CheckMaintenanceTimerHandle, [&] {
		CloseMaintenanceConn();
		GetBaseHUD(GameInstance)->OnNetworkConnectFailed();
	}, CVarQ6CheckMaintenanceInterval.GetValueOnGameThread(), false);
}

void FQ6ClientNetwork::OnEnterLobby(const FResError* Err, const FL2CAuthEnterLobbyResp& Resp)
{
	if (Err)
	{
		ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
		if (!Q6BaseHUD)
		{
			PanicRestartGame(TEXT("HandleWsError"));
			return;
		}

		Q6BaseHUD->OnError(Err);
		return;
	}

	GameInstance->HandleEnteredLobby(Resp);
}

void FQ6ClientNetwork::OnEnterLobbyFinal(const FResError* Err, const FL2CAuthEnterLobbyFinalResp& Resp)
{
	if (Err)
	{
		ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
		if (!Q6BaseHUD)
		{
			PanicRestartGame(TEXT("HandleWsError"));
			return;
		}

		Q6BaseHUD->OnError(Err);
		return;
	}

	GameInstance->HandleEnteredLobbyFinal(Resp);

	// be careful not to have infinite loop
	FWsReqQueueItem RetryItem;
	while (WsRetryQueue.Dequeue(RetryItem) && IsWebSocketConnected())
	{
		bool bQueueEmpty = WsReqQueue.IsEmpty();
		RetryItem.SavedSeq = RetryItem.Seq;
		RetryItem.Seq = WsMsgSeq++;
		WsReqQueue.Enqueue(RetryItem);
		if (bQueueEmpty && !bWsInDelegate)
		{
			WsSendReqItem(RetryItem);
		}
	}

	// if something is left, it's critical error and we should be transitioning to WorldSelect
	if (!WsRetryQueue.IsEmpty())
	{
		Q6JsonLogNet(Warning, "error again with WsWorldRetry, are we going to WorldSelect?");
	}
}

void FQ6ClientNetwork::OnWsReceived(const FString& Message)
{
	if (!WsContext)
	{
		Q6JsonLogNet(Warning, "web socket connected with no context");
		return;
	}

	Q6JsonLogNet(Verbose, "web socket", Q6KV("message", *Message));

	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<> > JsonReader = TJsonReaderFactory<>::Create(Message);
	if (!FJsonSerializer::Deserialize(JsonReader, JsonObject) || !JsonObject.IsValid())
	{
		RaiseWsClientError(FString::Printf(TEXT("OnWsReceived - parsing error: %s"), *Message));
		return;
	}

	const TSharedPtr<FJsonObject>* HeaderObject = nullptr;
	if (!JsonObject->TryGetObjectField(TEXT("header"), HeaderObject))
	{
		RaiseWsClientError(FString::Printf(TEXT("OnWsReceived - no header: %s"), *Message));
		return;
	}

	const TSharedPtr<FJsonObject>* BodyObject = nullptr;
	if (!JsonObject->TryGetObjectField(TEXT("body"), BodyObject))
	{
		RaiseWsClientError(FString::Printf(TEXT("OnWsReceived - no body: %s"), *Message));
		return;
	}

	FL2CHeader Header;
	if (!JsonToPacketInternal(HeaderObject->ToSharedRef(), FL2CHeader::StaticStruct(), &Header))
	{
		RaiseWsClientError(FString::Printf(TEXT("OnWsReceived - header parsing error: %s"), *Message));
		return;
	}

	// TODO: check if header is valid

	if (Header.Push.IsEmpty())
	{
		HandleWsResponse(Header, BodyObject->ToSharedRef(), Message);
	}
	else
	{
		HandlePush(Header, BodyObject->ToSharedRef(), Message);
	}
}

void FQ6ClientNetwork::HandleWsResponse(const FL2CHeader& Header, const TSharedRef<FJsonObject>& Body, const FString& Message)
{
	//TODO: on error, we should alert the player and restart the game

	FWsReqQueueItem FirstItem;
	if (!WsReqQueue.Dequeue(FirstItem))
	{
		RaiseWsClientError(FString::Printf(TEXT("OnWsReceived - no request: %s"), *Message));
		return;
	}

	if (FirstItem.Seq != Header.Ack)
	{
		RaiseWsClientError(FString::Printf(TEXT("OnWsReceived - sequence error: %s"), *Message));
		return;
	}

	// possible status
	// 200: OK
	// 400: possible error, each delegate will handle it
	// 401: session expire
	// 500: critical error
	//
	// 200 and 400: call delegate
	// all other status including 401 and 500: warn the player and restart the game
	// TODO: on warning, show different message

	if (FirstItem.bBlocking)
	{
		if (--NumBlockingReq == 0)
		{
			ABaseHUD* Q6BaseHUD = GetBaseHUD(GameInstance);
			if (!Q6BaseHUD)
			{
				PanicRestartGame(TEXT("HandleWsResponse"));
				return;
			}
			Q6BaseHUD->OnNetworkEndBlockingRequest();
		}

	}

	FScopeBool ScopeBool(&bWsInDelegate);


	if (Header.Status == 200)
	{
		FirstItem.Delegate.ExecuteIfBound(nullptr, Body);
		PeekWsRequestAndSend();
		return;
	}

	FResError RespError;
	FL2CError ServerError;
	if (!JsonToPacketInternal(Body, FL2CError::StaticStruct(), &ServerError))
	{
		RespError.Body.Error = TEXT("Error.Unknown");
	}
	else
	{
		// RespError.Body.Error = ServerError.Error;
		RespError.Body = ServerError;
	}
	RespError.Code = Header.Status;

	if (Header.Status == 400)
	{
		// logic error comes here too
		Q6JsonLogNet(Display, "HandleWsResponse - known error", Q6KV("Json", *Message));
		FirstItem.Delegate.ExecuteIfBound(&RespError, Body);
		PeekWsRequestAndSend();
		return;
	}

	HandleWsError(RespError);
}

void FQ6ClientNetwork::HandlePush(const FL2CHeader& Header, const TSharedRef<FJsonObject>& Body, const FString& Message)
{
	const FString& Category = Header.Push;
	const FQ6NetPushDelegate* Delegate = PushHandlerMap.Find(Category);
	if (!Delegate || !Delegate->IsBound())
	{
		Q6JsonLogNet(Warning, "HandlePush - no handler", Q6KV("Category", *Category));
		return;
	}

	Delegate->Execute(Body);
}
