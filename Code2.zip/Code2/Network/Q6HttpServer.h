// Copyright (c) 2018 XLGames, Inc. All rights reserved.
//
// mongoose server wrapper, adapted from FWebSocket class
//
#pragma once

#include "Core.h"
#include "Engine.h"
#include "Q6Define.h"

#include "Q6HttpServer.generated.h"

typedef struct mg_mgr FMGManager;
typedef struct mg_connection FMGConnection;
typedef struct http_message FMGHttpMessage;

class UQ6GameInstance;

UENUM()
enum class EQ6HttpRequestState : uint8
{
	Queued,
	Processing,
	Completed,
	Failed,
};

struct FQ6HttpContext
{
	int32 RequestId;
	FMGConnection* Conn;
	FMGHttpMessage* Message;
	FString RequestBodyJSonStr;
	FString QueryString;
	EQ6HttpRequestState RequestState;
	EQ6Judgement Judgement;
};

USTRUCT()
struct FJ2LJudgementResponse
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	EQ6Judgement ErrorCode;
};

class FQ6HttpServerThread : public FRunnable
{
public:

	FQ6HttpServerThread(const TCHAR* ThreadName);
	~FQ6HttpServerThread();

	// FRunnable interface
	virtual uint32 Run() override;
	virtual void Stop() override;
	virtual bool Init() override;
	virtual void Exit() override;

	bool HasExitRequest() const { return ExitRequest.GetValue() > 0; }

	void InitGame(UQ6GameInstance* InGameInstance);
	void AddRequest(FMGConnection* InConn, FMGHttpMessage* InMessage);

	// game tick to from the game thread
	void GameTick(UQ6GameInstance* InGameInstance);


private:

	void SendResponses();
	void OnCompleteJudgement(int32 InRequestId, EQ6Judgement InJudgement);

	// unreal thread object
	FRunnableThread* Thread;

	// exit request
	FThreadSafeCounter ExitRequest;

	FMGManager* MGManager;
	TArray<FQ6HttpContext> Requests;

	int32 NextRequestId;

	FString ListenPortStr;

	// lock to coordinate between game thread and socket thread
	volatile bool GameLocked;
	FCriticalSection Lock;
};