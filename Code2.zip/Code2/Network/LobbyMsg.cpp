// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "LobbyMsg.h"
#include "JsonObjectConverter.h"

bool JsonToPacketInternal(const TSharedRef<FJsonObject>& JsonObject, const UStruct* StructDefinition, void* OutPacketObject)
{
	if (!FJsonObjectConverter::JsonObjectToUStruct(JsonObject, StructDefinition, OutPacketObject, 0, 0))
	{
		return false;
	}

	return true;
}
