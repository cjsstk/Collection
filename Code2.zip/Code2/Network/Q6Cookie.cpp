// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "Q6Cookie.h"
#include "Q6Log.h"

FQ6Cookie::FQ6Cookie()
{
}


FQ6Cookie::~FQ6Cookie()
{
}

void FQ6Cookie::Reset()
{
	SessionId.Empty();
}

void FQ6Cookie::Parse(FHttpResponsePtr Response)
{
	if (!SessionId.IsEmpty())
	{
		// we don't need to parse every request
		return;
	}

	TArray<FString> AllHeaders = Response->GetAllHeaders();
	for (auto&& Iter : AllHeaders)
	{
		ParseHeader(*Iter);
	}
}

void FQ6Cookie::Emit(FHttpRequestPtr Request)
{
	if (SessionId.IsEmpty())
	{
		// nothing
		return;
	}

	Request->SetHeader(TEXT("Cookie"), *SessionId);
}

void FQ6Cookie::Emit(char** Buffer, int32 Len)
{
	if (SessionId.IsEmpty())
	{
		// nothing
		return;
	}


	FString Header = FString::Printf(TEXT("Cookie: %s\r\n"), *SessionId);
	int32 RequiredLen = Header.Len();
	if (Len < RequiredLen)
	{
		Q6JsonLogNet(Error, "insufficient cookie buffer", Q6KV("required", RequiredLen), Q6KV("input", Len));
		return;
	}
	FMemory::Memcpy((void*)*Buffer, TCHAR_TO_ANSI(*Header), Header.Len());
	*Buffer += Header.Len();
	*(*Buffer) = '\0';
}

void FQ6Cookie::ParseHeader(const FString& Header)
{
	if (Header.StartsWith(TEXT("Set-Cookie:"), ESearchCase::IgnoreCase))
	{
		FString PartSetCookie;
		FString PartExt;
		Header.Split(TEXT(" "), &PartSetCookie, &PartExt);
		if (PartExt.StartsWith(TEXT("sessionid="), ESearchCase::IgnoreCase))
		{
			FString PartSessionId;
			FString PartPath;
			PartExt.Split(TEXT(" "), &PartSessionId, &PartPath);
			SessionId = PartSessionId;
			
		}
	}
}
