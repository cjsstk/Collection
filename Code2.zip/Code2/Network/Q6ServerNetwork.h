// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Engine.h"
#include "Q6Log.h"

//#include "Q6ServerNetwork.generated.h"

class UQ6GameInstance;
class FQ6HttpServerThread;


struct FQ6ServerNetwork
{
public:

	FQ6ServerNetwork(UQ6GameInstance* InGameInstance);
	~FQ6ServerNetwork();

	bool Tick(float DeltaTime);
	void Stop();

private:
	UQ6GameInstance* GameInstance;

	FQ6HttpServerThread* HttpServerThread;
};