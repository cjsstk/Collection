// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "Q6WebSocket.h"
#include "Ssl.h"
#include "Q6Cookie.h"
#include "Q6ClientNetwork.h"
#include "Networking.h"
#include "CyclicStatsBuffer.h"
#include "SendBuffer.h"

#if !PLATFORM_LINUX && !UE_SERVER

#if PLATFORM_WINDOWS
#   include "Windows/WindowsHWrapper.h"
#	include "Windows/AllowWindowsPlatformTypes.h"
#endif

#define UI UI_ST
	THIRD_PARTY_INCLUDES_START
	#include "libwebsockets.h"
	THIRD_PARTY_INCLUDES_END
#undef UI

#if PLATFORM_WINDOWS
#	include "Windows/HideWindowsPlatformTypes.h"
#endif

#if PLATFORM_ANDROID
#include <arpa/inet.h>
#endif

#include "Q6Log.h"
#include "Q6Util.h"

typedef enum lws_callback_reasons Q6WsCallbackReasons;

static const int32 PRE_SIZE = static_cast<int32>(LWS_PRE);
static uint8 PREPADDING[PRE_SIZE];

static TAutoConsoleVariable<float> CVarQ6WsPingTimeout(
	TEXT("Q6.WebSocketPingTimeout"),
	10.0f,
	TEXT("web socket timeout in seconds to give up and disconnect\n"),
	ECVF_Default);

static TAutoConsoleVariable<float> CVarQ6WsPingInterval(
	TEXT("Q6.WebSocketPingInterval"),
	10.0f,
	TEXT("web socket ping interval in seconds\n"),
	ECVF_Default);

static TAutoConsoleVariable<float> CVarQ6WsReconnectMinInterval(
	TEXT("Q6.WebSocketReconnectMinInterval"),
	1.0f,
	TEXT("web socket minimum interval to try reconnect in seconds\n"),
	ECVF_Default);

static TAutoConsoleVariable<int32> CVarQ6WsMaxMessageSize(
	TEXT("Q6.WebSocketMaxMessageSize"),
	512 * 1024,
	TEXT("web socket max message size in bytes\n"),
	ECVF_Default);

static TAutoConsoleVariable<int32> CVarQ6WsMaxUncompressedMessageSize(
	TEXT("Q6.WebSocketMaxUncompressedMessageSize"),
	1024 * 1024,
	TEXT("web socket max uncompressed message size in bytes\n"),
	ECVF_Default);

static TAutoConsoleVariable<int32> CVarQ6WsCompressThresholdBytes(
	TEXT("Q6.WebSocketCompressThresholdBytes"),
	512,
	TEXT("web socket message size over this value will be compressed\n"),
	ECVF_Default);

static const char* ProtocolNames[(int)EQ6WsProtocol::Max] = { "q6-push-protocol" };
static const char* OriginQ6EnterWorld = "q6-enter-world";
static lws_protocols Protocols[(int)EQ6WsProtocol::Max + 1];

static FQ6WsThread* WsThread = nullptr;

static void WsInternalLog(int level, const char *line)
{
	Q6JsonLogNet(Display, "libwebsocket", Q6KV("level", (int32)level), Q6KV("log", FString(line)));
}

struct FWsPing
{
	uint8 Pre[PRE_SIZE];
	struct FData
	{
		double Timestamp;
	} Data;
};

class FQ6WebSocket
{
public:
	// Initialize as client side socket. 
	FQ6WebSocket(Q6WsContext* InContext, const FQ6WsConfig* Config);

	// clean up. 
	~FQ6WebSocket();

	// thread tick
	void ThreadTick(double NowSeconds);

	Q6WsInternal* GetWsi() { return Wsi; }

	/** Send raw data or string to remote end point. */
	bool Send(uint8* Data, uint32 Size);

	/** Helper functions to describe end points. */
	FString RemoteEndPoint();
	FString LocalEndPoint();

	FQ6WsThread::EState GetState() { return State; }
	TArray<FString>& GetReceivedMessages() { return ReceivedMessages; }
	double PingTime() { return PingStat.GetMedian();  }

	/** Close reason and description. **/
	uint16 GetCloseReason() const { return CloseReason; }
	const FString& GetCloseDescription() const { return CloseDescription; }
private:
	friend int Q6WsInternalCallbackInternal(Q6WsContext* Context, Q6WsInternal* Wsi,
		Q6WsCallbackReasons Reason, void *User, void *In, size_t Len);

	bool Ping(bool* bSent);
	int32 TryCompressAndWrite(TArray<uint8>& Packet);

	void OnRawConnected();
	bool OnRawReceiveString(void* Data, uint32 Size);
	bool OnRawReceiveBinary(void* Data, uint32 Size);
	void OnRawPong(void* Data, uint32 Size);
	bool OnRawWritable();
	void OnRawCloseInitiated(void* Data, uint32 Size);
	void OnRawClosed();

	/**  Max message size after compression */
	int32 MaxMessageSize;

	/**  Send buffers, serviced during the Tick */
	FSendBuffer* SendBuffer;

	/** Received message, to avoid memory allocation */
	TArray<FString> ReceivedMessages;

	/** libwebsocket context */
	Q6WsContext* Context;

	/** libwebsocket handle */
	Q6WsInternal* Wsi;

	/** socket state */
	FQ6WsThread::EState State;

	/** Cookie for authentication */
	FQ6Cookie* Cookie;

	/** compression */
	bool bCompress;
	TArray<uint8> CompressBuffer;
	int32 CompressThresholdBytes;
	int32 MaxUncompressedMessageSize;

	/* ping */
	bool bWaitingPong;
	double LastPingTime;
	double PingTimeout;
	double PingInterval;
	FWsPing PingBuffer;
	CyclicStatsBuffer<double, 5> PingStat;

	/** Close reason and description. **/
	uint16 CloseReason;
	FString CloseDescription;
};

int Q6WsInternalCallbackInternal(Q6WsContext* Context, Q6WsInternal* Wsi, 
								Q6WsCallbackReasons Reason, 
								void *User, 
								void *In, size_t MemLen)
{
	FQ6WebSocket* Socket = nullptr;
	uint32 Len = static_cast<uint32>(MemLen); //-V202
	bool bExitRequest = false;

	if (WsThread)
	{
		bExitRequest = WsThread->HasExitRequest();
		Socket = WsThread->FindWebSocket(Wsi);
	}

	switch (Reason)
	{
		 //v1.5 bug: User is nullptr with this callback
		case LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER:
		{
			if (!Socket)
			{
				Q6JsonLogNet(Warning, "LWS_CALLBACK_CLIENT_APPEND_HANDSHAKE_HEADER no socket");
				return -1;
			}

			if (Socket->Cookie)
			{
				char** Buffer = (char**)In; //-V206
				Socket->Cookie->Emit(Buffer, static_cast<int32>(Len));
			}
			break;
		}

		case LWS_CALLBACK_OPENSSL_LOAD_EXTRA_CLIENT_VERIFY_CERTS:
		{
			FSslModule::Get().GetCertificateManager().AddCertificatesToSslContext(static_cast<SSL_CTX*>(User));
			Q6JsonLogNet(Display, "LWS_CALLBACK_OPENSSL_LOAD_EXTRA_CLIENT_VERIFY_CERTS");
			break;
		}

		case LWS_CALLBACK_CLIENT_ESTABLISHED:
		{
			if (!Socket)
			{
				Q6JsonLogNet(Warning, "LWS_CALLBACK_CLIENT_ESTABLISHED no socket");
				return -1;
			}

			Socket->OnRawConnected();
			lws_callback_on_writable(Wsi);
			break;
		}
		case LWS_CALLBACK_CLIENT_CONNECTION_ERROR:
		{
			if (!Socket)
			{
				Q6JsonLogNet(Warning, "LWS_CALLBACK_CLIENT_CONNECTION_ERROR no socket");
				return -1;
			}

			Q6JsonLogNet(Display, "LWS_CALLBACK_CLIENT_CONNECTION_ERROR");
			Socket->OnRawClosed();
			return -1;
		}
		case LWS_CALLBACK_CLIENT_RECEIVE:
		{
			if (!Socket)
			{
				Q6JsonLogNet(Warning, "LWS_CALLBACK_CLIENT_RECEIVE no socket");
				return -1;
			}

			bool bSuccess;
			check(lws_remaining_packet_payload(Wsi) == 0);
			if (lws_frame_is_binary(Wsi))
			{
				bSuccess = Socket->OnRawReceiveBinary(In, Len);
			}
			else
			{
				bSuccess = Socket->OnRawReceiveString(In, Len);
			}
			if (!bSuccess)
			{
				return -1;
			}
			break;
		}
		case LWS_CALLBACK_CLIENT_RECEIVE_PONG:
		{
			if (!Socket)
			{
				Q6JsonLogNet(Warning, "LWS_CALLBACK_CLIENT_RECEIVE_PONG no socket");
				return -1;
			}

			check(lws_remaining_packet_payload(Wsi) == 0);
			Socket->OnRawPong(In, Len);
			break;
		}
		case LWS_CALLBACK_CLIENT_WRITEABLE:
		{
			if (!Socket)
			{
				if (!bExitRequest)
				{
					Q6JsonLogNet(Warning, "LWS_CALLBACK_CLIENT_WRITEABLE no socket");
				}
				return -1;
			}

			if (Socket->OnRawWritable())
			{
				lws_callback_on_writable(Wsi);
			}
			else
			{
				// error and close
				return -1;
			}
			break;
		}
		case LWS_CALLBACK_WS_PEER_INITIATED_CLOSE:
		{
			if (!Socket)
			{
				Q6JsonLogNet(Warning, "LWS_CALLBACK_WS_PEER_INITIATED_CLOSE no socket");
				return -1;
			}

			if (In && Len > 0)
			{
				Socket->OnRawCloseInitiated(In, Len);
			}
			break;
		}
		case LWS_CALLBACK_CLOSED:
		{
			if (!Socket)
			{
				Q6JsonLogNet(Verbose, "LWS_CALLBACK_CLOSED no socket");
				return -1;
			}

			Q6JsonLogNet(Display, "LWS_CALLBACK_CLOSED");
			Socket->OnRawClosed();
			return -1;
		}
		case LWS_CALLBACK_WSI_DESTROY:
		{
			if (!Socket)
			{
				if (!bExitRequest)
				{
					Q6JsonLogNet(Warning, "LWS_CALLBACK_WSI_DESTROY no socket");
				}
				return -1;
			}

			Q6JsonLogNet(Display, "LWS_CALLBACK_WSI_DESTROY");
			Socket->OnRawClosed();
			return -1;
		}
	}

	return 0;
}

static int Q6WsInternalCallback(Q6WsInternal* Wsi,
								Q6WsCallbackReasons Reason,
								void *User,
								void *In, size_t Len)
{
	Q6WsContext* Context = lws_get_context(Wsi);
	return Q6WsInternalCallbackInternal(Context, Wsi, Reason, User, In, Len);
}

FQ6WebSocket::FQ6WebSocket(Q6WsContext* InContext, const FQ6WsConfig* Config)
	: Context(InContext)
	, Wsi(nullptr)
	, State(FQ6WsThread::EState::Connecting)
	, Cookie(Config->Cookie)
	, bWaitingPong(false)
	, CloseReason(0)
{
	CompressThresholdBytes = CVarQ6WsCompressThresholdBytes.GetValueOnAnyThread();
	LastPingTime = FPlatformTime::Seconds();
	PingTimeout = CVarQ6WsPingTimeout.GetValueOnAnyThread();
	PingInterval = CVarQ6WsPingInterval.GetValueOnAnyThread();
	bCompress = Config->bCompress;
	MaxMessageSize = static_cast<int32>(Protocols[(int)Config->Protocol].rx_buffer_size); //-V202
	MaxUncompressedMessageSize = CVarQ6WsMaxUncompressedMessageSize.GetValueOnAnyThread();

	SendBuffer = new FSendBuffer(Config->SendQueueSize);
	for (int i = 0; i < PingStat.Capacity(); ++i)
	{
		PingStat.AddSample(0.0f);
	}

	char AnsiServerAddr[512];
	FCStringAnsi::Strncpy(AnsiServerAddr, TCHAR_TO_ANSI(*Config->ServerAddr), dimof(AnsiServerAddr));

	struct lws_client_connect_info Info;
	FMemory::Memzero(&Info, sizeof(Info));
	Info.context = Context;
	Info.address = AnsiServerAddr;
	Info.port =  Config->ServerPort;
	Info.ssl_connection = Config->UseSSL;
	Info.path = "/";
	Info.host = AnsiServerAddr;
	Info.origin = OriginQ6EnterWorld;
	Info.protocol = Protocols[(int)Config->Protocol].name;
	Info.userdata = this;
	Info.ietf_version_or_minus_one = -1;
	Wsi = lws_client_connect_via_info(&Info);

	// happens while hot-swapping
	if (!Wsi)
	{
		Context = nullptr;
		State = FQ6WsThread::EState::Closed;
	}
}

void FQ6WebSocket::ThreadTick(double NowSeconds)
{
	// now, only job is detecting ping timeout

	if (!Wsi || State == FQ6WsThread::EState::Closed)
	{
		// already closed
		return;
	}

	if (!bWaitingPong)
	{
		if (NowSeconds > LastPingTime + PingInterval + PingTimeout)
		{
			// IOS workaround for libwebsockets going completly unresponsive
			// this happens when you turn off the device
			Q6JsonLogNet(Warning, "FQ6WebSocket cannot ping");
			OnRawClosed();
			
		}
		return;
	}

	if (NowSeconds < LastPingTime + PingTimeout)
	{
		return;
	}

	Q6JsonLogNet(Warning, "FQ6WebSocket ping timeout");
	OnRawClosed();
}

bool FQ6WebSocket::Send(uint8* Data, uint32 Size)
{
	if (SendBuffer->WritableSize() == 0)
	{
		Q6JsonLogNet(Error, "FQ6WebSocket send buffer full");
		return false;
	}

	TArray<uint8> Buffer;
	Buffer.Append((uint8*)PREPADDING, sizeof(PREPADDING));
	Buffer.Append((uint8*)Data, Size);
	SendBuffer->Add(MoveTemp(Buffer));

	return true;
}

bool FQ6WebSocket::Ping(bool* bSent)
{
	// return false if error
	*bSent = false;

	if (bWaitingPong)
	{
		return true;
	}

	const double NowSeconds = FPlatformTime::Seconds();
	if (NowSeconds < LastPingTime + PingInterval)
	{
		return true;
	}

	check(Wsi);

	bWaitingPong = true;
	LastPingTime = NowSeconds;
	*bSent = true;

	PingBuffer.Data.Timestamp = NowSeconds;
	int32 DataToSend = (int32)sizeof(FWsPing::FData);
	int Sent = lws_write(Wsi, (uint8*)&PingBuffer.Data, DataToSend, LWS_WRITE_PING);
	if (Sent < DataToSend)
	{
		Q6JsonLogNet(Warning, "FQ6WebSocket parital write(ping)", Q6KV("sending", DataToSend), Q6KV("sent", Sent));
		return false;
	}

	check(lws_partial_buffered(Wsi) != 1);

	return true;
}

FString FQ6WebSocket::RemoteEndPoint()
{
	check(Wsi);

	ANSICHAR Peer_Name[128];
	ANSICHAR Peer_Ip[128];
	lws_get_peer_addresses(Wsi, (lws_sockfd_type)lws_get_socket_fd(Wsi), Peer_Name, sizeof Peer_Name, Peer_Ip, sizeof Peer_Ip); //-V201
	return FString(Peer_Name);
}

FString FQ6WebSocket::LocalEndPoint()
{
	return FString(ANSI_TO_TCHAR(lws_canonical_hostname(Context)));
}

int32 FQ6WebSocket::TryCompressAndWrite(TArray<uint8>& Packet)
{
	if (!bCompress)
	{
		return 0;
	}

#define TEST_COMPRESS_ALWAYS 0

	int32 OrgDataSize = Packet.Num() - PRE_SIZE;

#if !TEST_COMPRESS_ALWAYS
	if (OrgDataSize <= CompressThresholdBytes)
	{
		return 0;
	}
#endif

	int32 PrefixSize = PRE_SIZE + (int32)sizeof(int32);
	CompressBuffer.Reset(PrefixSize + OrgDataSize);
	CompressBuffer.AddUninitialized(PrefixSize + OrgDataSize);
	int32* UncompressedSize = ((int32*)(CompressBuffer.GetData() + PRE_SIZE)); //-V206
	*UncompressedSize = OrgDataSize;
	int32 CompressedSize = OrgDataSize;

	bool bSuccess = FCompression::CompressMemory(
		NAME_Zlib,
		CompressBuffer.GetData() + PrefixSize,
		CompressedSize,
		Packet.GetData() + PRE_SIZE,
		OrgDataSize,
		COMPRESS_BiasMemory);

	if (!bSuccess)
	{
		Q6JsonLogNet(Warning, "FQ6WebSocket parital write(ping)", Q6KV("text size", OrgDataSize));
		return 0;
	}

	int32 NewDataSize = CompressedSize + (int32)sizeof(int32);
	if (NewDataSize > MaxMessageSize)
	{
		Q6JsonLogNet(Error, "compressed message size overflow", Q6KV("Max", MaxMessageSize), Q6KV("Reqeust", CompressedSize));
		return -1;
	}

#if !TEST_COMPRESS_ALWAYS
	if (NewDataSize >= OrgDataSize)
	{
		Q6JsonLogNet(Warning, "FQ6WebSocket compression backfire", Q6KV("text size", OrgDataSize));
		return 0;
	}
#endif
	check(Wsi);

	int Sent = lws_write(Wsi, CompressBuffer.GetData() + PRE_SIZE, (size_t)NewDataSize, LWS_WRITE_BINARY); //-V201
	if (Sent < 0)
	{
		return Sent;
	}

	if (Sent < NewDataSize)
	{
		Q6JsonLogNet(Warning, "FQ6WebSocket parital write(compression)", Q6KV("sending", NewDataSize), Q6KV("sent", Sent));
		return -1;
	}

	check(lws_partial_buffered(Wsi) != 1);

	return Sent;
}

bool FQ6WebSocket::OnRawReceiveString(void* Data, uint32 Size)
{
	((char*)Data)[Size] = '\0';
	FString Message;
	FUTF8ToTCHAR Converted(((const ANSICHAR*)Data));
	Message.AppendChars(Converted.Get(), Converted.Length());
	ReceivedMessages.Add(MoveTemp(Message));
	return true;
}

bool FQ6WebSocket::OnRawReceiveBinary(void* Data, uint32 Size)
{
	int32 UncompressedSize = *((int32*)Data); //-V206

	if (UncompressedSize > MaxUncompressedMessageSize || UncompressedSize <= 0)
	{
		Q6JsonLogNet(Error, "FQ6WebSocket bad uncompressed size", Q6KV("received", UncompressedSize), Q6KV("max", MaxUncompressedMessageSize));
		return false;
	}

	// include null padding
	CompressBuffer.Reset(UncompressedSize + 1);
	CompressBuffer.AddUninitialized(UncompressedSize);

	bool bSuccess = FCompression::UncompressMemory(
		NAME_Zlib,
		CompressBuffer.GetData(),
		CompressBuffer.Num(),
		((uint8*)Data) + 4,
		(int32)Size - 4,
		COMPRESS_BiasMemory);

	if (bSuccess)
	{
		return OnRawReceiveString(CompressBuffer.GetData(), (uint32)CompressBuffer.Num());
	}

	Q6JsonLogNet(Error, "FQ6WebSocket uncompress fail");
	return false;
}

void FQ6WebSocket::OnRawPong(void* Data, uint32 Size)
{
	if (!Wsi || State == FQ6WsThread::EState::Closed)
	{
		return;
	}

	check(bWaitingPong);
	check(Size == sizeof(FWsPing::FData));

	FWsPing::FData* PongData = (FWsPing::FData*)Data;
	const double NowSeconds = FPlatformTime::Seconds();
	check(PongData->Timestamp < NowSeconds);
	PingStat.AddSample(NowSeconds - PongData->Timestamp);

	bWaitingPong = false;
}

bool FQ6WebSocket::OnRawWritable()
{
	// return false if you want to close the connection because of error
	if (!Wsi || State == FQ6WsThread::EState::Closed)
	{
		return false;
	}

	bool bPingSent;
	bool bSuccess = Ping(&bPingSent);
	if (!bSuccess)
	{
		return false;
	}

	if (bPingSent)
	{
		// send next time
		return true;
	}

	if (SendBuffer->ReadableSize() == 0)
	{
		return true;
	}

	TArray<uint8>& Packet = SendBuffer->Front();
	int32 Sent = TryCompressAndWrite(Packet);

	if (Sent < 0)
	{
		// fatal
		return false;
	}

	if (Sent > 0)
	{
		SendBuffer->Pop();
		return true;
	}

	int32 DataToSend = Packet.Num() - PRE_SIZE;

	Sent = lws_write(Wsi, Packet.GetData() + PRE_SIZE, (size_t)DataToSend, LWS_WRITE_TEXT); //-V201

	if (Sent < 0)
	{
		return false;
	}
		
	// partial writing is rare event
	if (Sent < DataToSend)
	{
		Q6JsonLogNet(Warning, "FQ6WebSocket parital write", Q6KV("sending", DataToSend), Q6KV("sent", Sent));
		return false;
	}

	check(lws_partial_buffered(Wsi) != 1);

	SendBuffer->Pop();
	return true;
}

void FQ6WebSocket::OnRawCloseInitiated(void* Data, uint32 Size)
{
	// Set close reason and description.
	CloseReason = ntohs(*(uint16*)Data);

	((char*)Data)[Size] = '\0';
	FUTF8ToTCHAR Converted(((const ANSICHAR*)Data + 2));
	CloseDescription.AppendChars(Converted.Get(), Converted.Length());

	Q6JsonLogNet(Warning, "FQ6WebSocket close initiated.", Q6KV("CloseReason", CloseReason), Q6KV("CloseDescription", CloseDescription));
}

void FQ6WebSocket::OnRawConnected()
{
	check(State == FQ6WsThread::EState::Connecting);
	State = FQ6WsThread::EState::Connected;
}

void FQ6WebSocket::OnRawClosed()
{
	if (Wsi)
	{
		State = FQ6WsThread::EState::Closed;

		// comment-out: hot fix for CBT
		// Wsi needs to be intact since it's only way to remove this socket from FQ6WsThread::WsiSocketMap
		//Wsi = nullptr;
	}
}

FQ6WebSocket::~FQ6WebSocket()
{
	// rain-check
	OnRawClosed();
	delete SendBuffer;
}

struct FQ6WsContext
{
	FQ6WsContext(FQ6WsConfig* InConfig)
		: Config(InConfig)
		, State(FQ6WsThread::EState::Closed)
		, PingMs(0)
		, WebSocket(nullptr)
	{}

	~FQ6WsContext()
	{
		delete Config;
		Config = nullptr;
		delete WebSocket;
		WebSocket = nullptr;
	}

	FQ6WsConfig* Config;
	FQ6WsThread::EState State;
	int32 PingMs;
	FQ6WebSocket* WebSocket;
};

static inline void MakeServerLocFromConnRequest(const FQ6WsThread::FConnRequest& Req, FQ6WsThread::FServerLoc* Out)
{
	Out->Addr = Req.Ctx->Config->ServerAddr;
	Out->Port = Req.Ctx->Config->ServerPort;
}

FQ6WsThread::FQ6WsThread(const TCHAR* ThreadName)
	: WsContext(nullptr)
	, WorkEvent(nullptr)
	, Thread(nullptr)
	, GameLocked(false)
{
	WsThread = this;

	FMemory::Memzero(Protocols, sizeof(Protocols));

	check(dimof(ProtocolNames) == (int)EQ6WsProtocol::Max);
	check(dimof(Protocols) == (int)EQ6WsProtocol::Max + 1);

	// to avoid PVS V1008, for loop is not used https://www.viva64.com/en/w/v1008/
	// if the count of protocols is more than 1, use for loop
	check((int)EQ6WsProtocol::Max == 1);
	check(ProtocolNames[0]);
	Protocols[0].name = ProtocolNames[0];
	Protocols[0].callback = Q6WsInternalCallback;
	Protocols[0].rx_buffer_size = (size_t)CVarQ6WsMaxMessageSize.GetValueOnGameThread() + 1; //-V201

	WorkEvent = FPlatformProcess::GetSynchEventFromPool();
	if (!WorkEvent)
	{
		Q6JsonLogNet(Error, "FQ6WsThread cannot create event");
		return;
	}

	Thread = FRunnableThread::Create(this, ThreadName, 128 * 1024, TPri_AboveNormal,
		FPlatformAffinity::GetPoolThreadMask());
	if (!Thread)
	{
		Q6JsonLogNet(Error, "FQ6WsThread cannot create thread");
	}
}

FQ6WsThread::~FQ6WsThread()
{
	if (Thread)
	{
		Thread->Kill(true);
		delete Thread;
		Thread = nullptr;
	}

	if (WorkEvent)
	{
		FPlatformProcess::ReturnSynchEventToPool(WorkEvent);
		WorkEvent = nullptr;
	}

	check(CtxRunning.Num() == 0); //-V509

	for (const auto& Req : CtxReq)
	{
		delete Req.Ctx;
	}

	CtxReq.Empty();

	WsThread = nullptr;
}

FQ6WsThread::EState FQ6WsThread::GetState(FQ6WsContext* Ctx) const
{ 
	if (!Ctx)
	{
		return EState::Closed;
	}

	return Ctx->State;
}

bool FQ6WsThread::IsConnected(FQ6WsContext* Ctx) const
{ 
	if (!Ctx)
	{
		return false;
	}
		
	return Ctx->State == FQ6WsThread::EState::Connected;
}

int32 FQ6WsThread::GetPingMs(FQ6WsContext* Ctx) const
{ 
	if (!Ctx)
	{
		return 0;
	}

	return Ctx->PingMs;
}

FString FQ6WsThread::GetServerAddr(const FQ6WsContext* Ctx) const
{
	if (!Ctx || !Ctx->Config)
	{
		return "";
	}

	return Ctx->Config->ServerAddr;
}

int32 FQ6WsThread::GetServerPort(const FQ6WsContext* Ctx) const
{
	if (!Ctx || !Ctx->Config)
	{
		return 0;
	}

	return Ctx->Config->ServerPort;
}

uint32 FQ6WsThread::Run()
{
	// we want to new or delete web socket here in dedicated thread
	while (!HasExitRequest())
	{
		WorkEvent->Wait(CalculateWaitTime());
		FScopeLock ScopeLock(&Lock);

		double NowSeconds = FPlatformTime::Seconds();

		for (auto Ctx : CtxRunning)
		{
			Ctx->WebSocket->ThreadTick(NowSeconds);
		}

		for (auto& Req : CtxReq)
		{
			Req.bHandled = HandleRequest(Req);
		}
		CtxReq.RemoveAll([](const FConnRequest& Req)
		{
			return (Req.bHandled == true);
		});
		lws_service(WsContext, 0);
	}

	return 0;
}

void FQ6WsThread::Stop()
{
	ExitRequest.Increment();
	WorkEvent->Trigger();
}

bool FQ6WsThread::Init()
{
#if !UE_BUILD_SHIPPING
	lws_set_log_level(LLL_ERR | LLL_WARN | LLL_NOTICE | LLL_INFO, WsInternalLog);
#endif

	InitWsContext();
	return true;
}

void FQ6WsThread::Exit()
{
	if (WsContext)
	{
		lws_context_destroy(WsContext);
		WsContext = nullptr;
	}

	for (auto Ctx : CtxRunning)
	{
		delete Ctx;
	}
	CtxRunning.Empty();
}

FQ6WsContext* FQ6WsThread::CreateConn(FQ6WsConfig* Config)
{
	FConnRequest Req;
	Req.Ctx = new FQ6WsContext(Config);
	Req.bCreate = true;
	Req.bHandled = false;

	PushRequest(Req);

	return Req.Ctx;
}

void FQ6WsThread::RemoveConn(FQ6WsContext* Ctx)
{
	if (!Ctx)
	{
		return;
	}

	FConnRequest Req;
	Req.Ctx = Ctx;
	Req.bCreate = false;
	Req.bHandled = false;

	PushRequest(Req);
}

void FQ6WsThread::GameTick()
{
	FScopeLock ScopeLock(&Lock);
	FScopeVolatileBool ScopeBool(&GameLocked);

	for (auto Ctx : CtxRunning)
	{
		if (Ctx->State != Ctx->WebSocket->GetState())
		{
			Ctx->State = Ctx->WebSocket->GetState();
			if (Ctx->State == EState::Connected)
			{
				Ctx->Config->ConnectedCallBack.ExecuteIfBound();
			}
			else if (Ctx->State == EState::Closed)
			{
				ConsumeReceivedMessages(Ctx);
				Ctx->Config->ErrorCallBack.ExecuteIfBound(
					Ctx->WebSocket->GetCloseReason(),
					Ctx->WebSocket->GetCloseDescription());
			}
			continue;
		}

		if (Ctx->State == EState::Connected)
		{
			Ctx->PingMs = int32(Ctx->WebSocket->PingTime() * 1000.0f);
			ConsumeReceivedMessages(Ctx);
		}
	}
}

bool FQ6WsThread::Send(FQ6WsContext* Ctx, const FString& Message)
{
	if (!Ctx)
	{
		return false;
	}

	int32 MaxMessageSize = CVarQ6WsMaxUncompressedMessageSize.GetValueOnGameThread();

	FTCHARToUTF8 Converted(*Message);
	int32 Size = Converted.Length();
	if (Size > MaxMessageSize || Size < 0)
	{
		Q6JsonLogNet(Error, "uncompressed message size overflow", Q6KV("Max", (int32)MaxMessageSize), Q6KV("Reqeust", (int32)Size));
		return false;
	}

	if (GameLocked)
	{
		check(Ctx->WebSocket);
		return Ctx->WebSocket->Send((uint8*)Converted.Get(), (uint32)Size);
	}
	else
	{
		FScopeLock ScopeLock(&Lock);
		check(Ctx->WebSocket);
		return Ctx->WebSocket->Send((uint8*)Converted.Get(), (uint32)Size);
	}
}

FQ6WebSocket* FQ6WsThread::FindWebSocket(Q6WsInternal* Wsi)
{
	check(!IsInGameThread());
	FQ6WebSocket** WebSocket = WsiSocketMap.Find(Wsi);
	if (WebSocket)
	{
		return *WebSocket;
	}
	
	return nullptr;
}

void FQ6WsThread::ConsumeReceivedMessages(FQ6WsContext* Ctx)
{
	TArray<FString>& Messages = Ctx->WebSocket->GetReceivedMessages();

	for (const auto& Message : Messages)
	{
		Ctx->Config->ReceivedCallBack.ExecuteIfBound(Message);
	}

	Messages.Empty();
}

FTimespan FQ6WsThread::CalculateWaitTime() const
{
#if PLATFORM_IOS
	return FTimespan::FromMilliseconds(14);
#else
	return FTimespan::FromMilliseconds(1);
#endif
}

void FQ6WsThread::PushRequest(const FConnRequest& Req)
{
	if (GameLocked)
	{
		CtxReq.Push(Req);
	}
	else
	{
		FScopeLock ScopeLock(&Lock);
		CtxReq.Push(Req);
	}
}

bool FQ6WsThread::HandleRequest(FConnRequest& Req)
{
	if (Req.bCreate)
	{
		if (Req.bHandled)
		{
			return true;
		}

		FServerLoc Loc;
		MakeServerLocFromConnRequest(Req, &Loc);
		double* LastSeconds = LastServerDisconnection.Find(Loc);
		if (LastSeconds)
		{
			const double NowSeconds = FPlatformTime::Seconds();
			if (NowSeconds < *LastSeconds + (double)CVarQ6WsReconnectMinInterval.GetValueOnAnyThread())
			{
				return false;
			}
		}

		Req.Ctx->State = EState::Connecting;
		Req.Ctx->WebSocket = new FQ6WebSocket(WsContext, Req.Ctx->Config);
		CtxRunning.Push(Req.Ctx);
		Q6WsInternal* Wsi = Req.Ctx->WebSocket->GetWsi();
		if (Wsi)
		{
			check(WsiSocketMap.Find(Wsi) == nullptr);
			WsiSocketMap.Add(Req.Ctx->WebSocket->GetWsi(), Req.Ctx->WebSocket);
		}
		return true;
	}
	else
	{
		CtxRunning.RemoveSingleSwap(Req.Ctx);
		FServerLoc Loc;
		MakeServerLocFromConnRequest(Req, &Loc);
		LastServerDisconnection.Add(Loc, FPlatformTime::Seconds());
		if (Req.Ctx->WebSocket)
		{
			Q6WsInternal* Wsi = Req.Ctx->WebSocket->GetWsi();
			if (Wsi)
			{
				check(*WsiSocketMap.Find(Wsi) == Req.Ctx->WebSocket);

				WsiSocketMap.Remove(Wsi);
			}
		}

		for (auto& WaitingReq : CtxReq)
		{
			// handle removing without waiting for the result of creating
			if (WaitingReq.bCreate && WaitingReq.Ctx == Req.Ctx)
			{
				WaitingReq.bHandled = true;
			}
		}

		delete Req.Ctx;
		Req.Ctx = nullptr;
		return true;
	}
}

void FQ6WsThread::InitWsContext()
{
	// check SSL certificate exists
	// certificate is used by unreal SSL module internally in SslCertifcateManager.cpp
	FString ContentCAFilePath = FPaths::ProjectContentDir() + TEXT("Certificates/cacert.pem");
	if (!FPaths::FileExists(ContentCAFilePath))
	{
		Q6JsonLogNet(Error, "No CA file", Q6KV("Path", *ContentCAFilePath));
		return;
	}

	struct lws_context_creation_info Info;
	FMemory::Memzero(&Info, sizeof(Info));

	Info.port = CONTEXT_PORT_NO_LISTEN;
	Info.protocols = Protocols;
	Info.gid = -1;
	Info.uid = -1;
	Info.options |= LWS_SERVER_OPTION_DO_SSL_GLOBAL_INIT;

	WsContext = lws_create_context(&Info);
	check(WsContext);

	Q6JsonLogNet(Display, "WsContext created");
}

#endif