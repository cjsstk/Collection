// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Kismet/GameplayStatics.h"
#include "Q6Util.h"
#include "Q6Log.h"
#include "LobbyMsg_gen.h"
#include "LobbyMsg.generated.h"

////////////////////////////////////////////////////////////////////////////////
//
// Serializer (Json <-> Packet Structure)
//

bool JsonToPacketInternal(const TSharedRef<FJsonObject>& JsonObject, const UStruct* StructDefinition, void* OutPacketObject);

template<typename PacketType>
bool JsonToPacket(const FString& JsonString, PacketType* OutPacketObject)
{
	TSharedPtr<FJsonObject> JsonObject;
	TSharedRef<TJsonReader<> > JsonReader = TJsonReaderFactory<>::Create(JsonString);
	if (!FJsonSerializer::Deserialize(JsonReader, JsonObject) || !JsonObject.IsValid())
	{
		Q6JsonLog(Warning, "JsonToPacket - Unable to parse json", Q6KV("Json", *JsonString));
		return false;
	}
	if (!JsonToPacketInternal(JsonObject.ToSharedRef(), PacketType::StaticStruct(), OutPacketObject))
	{
		Q6JsonLog(Warning, "JsonToPacket - Unable to deserialize", Q6KV("Json", *JsonString));
		return false;
	}
	return true;
}

////////////////////////////////////////////////////////////////////////////////
//
// Common
//
static const uint32 MAX_CHAT_MESSAGE = 64;

USTRUCT()
struct FC2LHeader
{
	GENERATED_USTRUCT_BODY()

	FC2LHeader() : Seq(0), SavedSeq(0) {}
	FC2LHeader(int32 InSeq, const FString& InPath, int32 InSavedSeq) : Seq(InSeq), Path(InPath), SavedSeq(InSavedSeq) {}

	UPROPERTY()
	int32 Seq;

	UPROPERTY()
	FString Path;

	UPROPERTY()
	int32 SavedSeq;
};

USTRUCT()
struct FL2CHeader
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	int32 Seq;

	UPROPERTY()
	int32 Ack;

	UPROPERTY()
	int32 Status;

	UPROPERTY()
	FString Push;
};

USTRUCT()
struct FL2CError
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY()
	int32 ErrorCode;

	UPROPERTY()
	FString Error;

	UPROPERTY()
	TArray<int32> Extra;
};
