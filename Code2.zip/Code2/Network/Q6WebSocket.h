// Copyright (c) 2015 XLGames, Inc. All rights reserved.
//
// libwebsocket client wrapper, adapted from FWebSocket class
//
#pragma once

#include "Core.h"
#include "Engine.h"

#if !UE_SERVER

class FQ6WebSocket;
class FQ6WsThread;
class FQ6Cookie;
struct FQ6WsContext;

typedef struct lws_context Q6WsContext;
typedef struct lws Q6WsInternal;

DECLARE_DELEGATE_OneParam(FQ6WsReceivedCallBack, const FString& /*Message*/);
DECLARE_DELEGATE(FQ6WsInfoCallBack);
DECLARE_DELEGATE_TwoParams(FQ6WsErrorCallBack, int32 /* CloseReason */, const FString& /* CloseDescription */);

enum class EQ6WsProtocol : uint8
{
	Lobby = 0,
	Max,
};

struct FQ6WsConfig
{
	FString ServerAddr;
	int32 ServerPort;

	// from libwebsockets.h
	//enum lws_client_connect_ssl_connection_flags {
	//	LCCSCF_USE_SSL = (1 << 0),
	//	LCCSCF_ALLOW_SELFSIGNED = (1 << 1),
	//	LCCSCF_SKIP_SERVER_CERT_HOSTNAME_CHECK = (1 << 2)
	//};
	// use one of 0, 1, 3, 7
	int32 UseSSL;

	bool bCompress;

	// callbacks
	FQ6WsReceivedCallBack ReceivedCallBack;
	FQ6WsInfoCallBack ConnectedCallBack;
	FQ6WsErrorCallBack ErrorCallBack;

	// authentication cookie to embed while connecting
	FQ6Cookie* Cookie;

	EQ6WsProtocol Protocol;

	// configuration from console vars
	int SendQueueSize;
};

class FQ6WsThread : public FRunnable
{
public:
	enum class EState
	{
		Connecting,
		Connected,
		Closed
	};

	struct FConnRequest
	{
		// create or remove
		bool bCreate;
		FQ6WsContext* Ctx;
		bool bHandled;
	};

	struct FServerLoc
	{
		FString Addr;
		int32 Port;

		bool operator ==(const FServerLoc& Other) const
		{
			return (Addr.Equals(Other.Addr) && Port == Other.Port);
		}

		friend FORCEINLINE uint32 GetTypeHash(const FServerLoc& Loc)
		{
			return FCrc::StrCrc32(*(Loc.Addr));
		}
	};

	FQ6WsThread(const TCHAR* ThreadName);
	~FQ6WsThread();

	// FRunnable interface
	virtual uint32 Run() override;
	virtual void Stop() override;
	virtual bool Init() override;
	virtual void Exit() override;

	// You can pass nullptr for Ctx
	EState GetState(FQ6WsContext* Ctx) const;
	bool IsConnected(FQ6WsContext* Ctx) const;
	int32 GetPingMs(FQ6WsContext* Ctx) const;
	FString GetServerAddr(const FQ6WsContext* Ctx) const;
	int32 GetServerPort(const FQ6WsContext* Ctx) const;

	// request new connection from the game thread
	// the config should be allocated from the heap(by new)
	FQ6WsContext* CreateConn(FQ6WsConfig* Config);

	// request remove connection
	// you can't use Ctx any more, it can be deleted any time
	void RemoveConn(FQ6WsContext* Ctx);

	// game tick to from the game thread
	void GameTick();

	// queue message to send from the game thread
	// if Ctx is null or message size is big, it returns false
	bool Send(FQ6WsContext* Ctx, const FString& Message);

	// internal use only
	FQ6WebSocket* FindWebSocket(Q6WsInternal* Wsi);

	bool HasExitRequest() const { return ExitRequest.GetValue() > 0; }

private:
	void ConsumeReceivedMessages(FQ6WsContext* Ctx);
	FTimespan CalculateWaitTime() const;
	void PushRequest(const FConnRequest& Req);
	bool HandleRequest(FConnRequest& Req);
	void InitWsContext();

	// exit request
	FThreadSafeCounter ExitRequest;

	// libwebsockets context
	Q6WsContext* WsContext;

	// to wake up the thread
	FEvent* WorkEvent;

	// unreal thread object
	FRunnableThread* Thread;

	// Contexts
	TArray<FConnRequest> CtxReq;
	TArray<FQ6WsContext*> CtxRunning;
	TMap<Q6WsInternal*, FQ6WebSocket*> WsiSocketMap;

	// Recent disconnection info
	TMap<FServerLoc, double> LastServerDisconnection;

	// lock to coordinate between game thread and socket thread
	volatile bool GameLocked;
	FCriticalSection Lock;
};

#endif
