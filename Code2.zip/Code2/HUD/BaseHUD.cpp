// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "BaseHUD.h"
#include "CharacterWidgets.h"
#include "CMS/ErrCode_gen.h"
#include "CommonWidgets.h"
#include "ErrText.h"
#include "GameResource.h"
#include "GuidePopupWidget.h"
#include "HUDStore/HUDStore.h"
#include "HUDStore/FriendBook.h"
#include "ItemWidgets.h"
#include "LoginHUD.h"
#include "MailManager.h"
#include "PointWidgets.h"
#include "PopupWidgets.h"
#include "SagaManager.h"
#include "SettingPopupWidgets.h"
#include "ShopWidgets.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "UIStateManager.h"
#include "UIClassResource.h"
#include "RaidManager.h"
#include "Slate/SceneViewport.h"
#include "Utils/LevelUtil.h"
#include "Widget/EventWidgets.h"

static TAutoConsoleVariable<float> CVarQ6BackgroundAbnormalTimeout(
	TEXT("q6.BackgroundAbnormalTimeout"),
	300.0f,
	TEXT("after this timeout of seconds in background with disconnected, the client goes to login\n"),
	ECVF_Default);

static TAutoConsoleVariable<float> CVarQ6BackgroundNormalTimeout(
	TEXT("q6.BackgroundNormalTimeout"),
	1800.0f,
	TEXT("after this timeout of seconds in background, the client goes to login\n"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarQ6ReconnectTimeout(
	TEXT("q6.ReconnectTimeout"),
	180.0f,
	TEXT("after this timeout of seconds in background with disconnected, the client goes to login\n"),
	ECVF_Default);

static TAutoConsoleVariable<float> CVarQ6ShowWaitingTimeout(
	TEXT("q6.ShowWaitingTimeout"),
	0.9f,
	TEXT("if response doesn't arrive till this timeout of seconds, the client shows waiting throbber\n"),
	ECVF_Default);

ABaseHUD::ABaseHUD()
	: bDesiredSilentReconnect(false)
	, BlockInputForNetworkStartTime(-1.0)
	, bReconnecting(false)
	, bSilentReconnect(false)
	, bKicked(false)
{
	EnterBackgroundSeconds = FPlatformTime::Seconds();
}

void ABaseHUD::BeginPlay()
{
	Super::BeginPlay();

	// workaround for LG G6
	// FPlatformMisc::ControlScreensaver(FGenericPlatformMisc::Disable);

	// Initialize error pop-up.
	if (!ConfirmPopupWidgetClass.Get())
	{
		ConfirmPopupWidgetClass.LoadSynchronous();
	}

	ErrorPopupWidget = CreateWidget<UConfirmPopupWidget>(GetLocalPlayerController(this), ConfirmPopupWidgetClass.Get());
	ErrorPopupWidget->AddToViewport(ZORDER_ERROR_POPUP);
	ErrorPopupWidget->SetTitle(FText::GetEmpty());
	ErrorPopupWidget->SetConfirmFlags(EConfirmPopupFlag::Yes);
	ErrorPopupWidget->ClosePopup();
	ErrorPopupWidget->SetPopupKind(EPopupKind::Error);
	ErrorPopupWidget->OnPopupClosedDelegate.BindUObject(this, &ABaseHUD::HandleError);
	ErrorPopupWidget->OnConfirmPopupDelegate.BindUObject(this, &ABaseHUD::OnConfirmErrorPopupInternal);

	NetworkProgressWidget =
		CreateWidget<UNetworkProgressWidget>(GetLocalPlayerController(this), NetworkProgressWidgetClass);
	NetworkProgressWidget->AddToViewport(ZORDER_ERROR_POPUP - 1);
	NetworkProgressWidget->Hide();

	FInputModeGameAndUI InputMode;
	InputMode.SetLockMouseToViewportBehavior(EMouseLockMode::LockOnCapture);
	InputMode.SetHideCursorDuringCapture(false);

	GetLocalPlayerController(this)->SetInputMode(InputMode);
	GetLocalPlayerController(this)->bShowMouseCursor = true;

	GetWorld()->GetGameViewport()->GetGameViewportWidget()->SetVisibility(EVisibility::Visible);

	bSilentReconnect = bDesiredSilentReconnect;
}

void ABaseHUD::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (bKicked)
	{
		return;
	}

	if (bReconnecting)
	{
		return;
	}

	if (BlockInputForNetworkStartTime > 0 &&
		!NetworkProgressWidget->IsVisible() &&
		FPlatformTime::Seconds() - BlockInputForNetworkStartTime > (double)CVarQ6ShowWaitingTimeout.GetValueOnGameThread())
	{
		NetworkProgressWidget->Show(Q6Util::GetLocalizedTextOrKey("Service", "WaitingResponse"));
	}
}

ABaseTutorial* ABaseHUD::GetTutorial()
{
	return nullptr;
}

bool ABaseHUD::GotoBack(bool bForced)
{
	UPopupBaseWidget* TopPopup = nullptr;

	for (UPopupBaseWidget* CreatedPopupWidget : PopupWidgets)
	{
		if (!CreatedPopupWidget->IsOpened())
		{
			continue;
		}

		if (!TopPopup || (CreatedPopupWidget->GetOrder() > TopPopup->GetOrder()))
		{
			TopPopup = CreatedPopupWidget;
		}
	}

	if (TopPopup && TopPopup->OnBack())
	{
		TopPopup->ClosePopup();
		return false;
	}

	return true;
}

bool ABaseHUD::HasOpenedPopup()
{
	for (UPopupBaseWidget* CreatedPopupWidget : PopupWidgets)
	{
		if (CreatedPopupWidget->IsOpened())
		{
			return true;
		}
	}

	return false;
}

UConfirmPopupWidget* ABaseHUD::OpenConfirmPopup(const FText& TitleText, const FText& ContentText)
{
	UConfirmPopupWidget* ConfirmPopupWidget = CastChecked<UConfirmPopupWidget>(OpenPopup(ConfirmPopupWidgetClass));
	ConfirmPopupWidget->SetTitle(TitleText);
	ConfirmPopupWidget->SetContent(ContentText);
	ConfirmPopupWidget->SetConfirmFlags(EConfirmPopupFlag::Yes | EConfirmPopupFlag::No);

	return ConfirmPopupWidget;
}

void ABaseHUD::OpenErrorPopup(EPopupKind InKind, const FText& TitleText, const FText& ContentText)
{
	if (!ErrorPopupWidget->IsInViewport())
	{
		ErrorPopupWidget->AddToViewport(ZORDER_ERROR_POPUP);
	}

	ErrorPopupWidget->SetTitle(TitleText);
	ErrorPopupWidget->SetContent(ContentText);
	ErrorPopupWidget->SetPopupKind(InKind);
	ErrorPopupWidget->SetCancelable(false);
	ErrorPopupWidget->SetNoGoBackOnConfirm();
}

UItemListPopupWidget* ABaseHUD::OpenItemListPopup(EUpgradeCategory ItemCategory, const TArray<int64>& MaterialIds, bool bVisibleUltLevel)
{
	UItemListPopupWidget* ItemListPopup = CastChecked<UItemListPopupWidget>(OpenPopup(ItemListPopupWidgetClass));
	ItemListPopup->SetItems(ItemCategory, MaterialIds, bVisibleUltLevel);

	return ItemListPopup;
}

UPlayNotifyPopupWidget* ABaseHUD::OpenPlayNotifyPopup(const FText& TitleText, const FText& StageNameText, const FText& ContentText)
{
	UPlayNotifyPopupWidget* PlayNotifyPopup = CastChecked<UPlayNotifyPopupWidget>(OpenPopup(PlayNotifyPopupWidgetClass));
	PlayNotifyPopup->SetTitle(TitleText);
	PlayNotifyPopup->SetStageName(StageNameText);
	PlayNotifyPopup->SetContent(ContentText);

	return PlayNotifyPopup;
}

UWattRechargePointSelectPopupWidget* ABaseHUD::OpenWattRechargePopup()
{
	UWattRechargePointSelectPopupWidget* RechargePopup = CastChecked<UWattRechargePointSelectPopupWidget>(OpenPopup(WattRechargePopupWidgetClass));
	RechargePopup->SetPointList();

	return RechargePopup;
}

UItemDetailWidget* ABaseHUD::OpenItemDetailPopup(const FItemIconInfo& ItemInfo)
{
	UItemDetailWidget* DetailPopup = CastChecked<UItemDetailWidget>(OpenPopup(ItemDetailPopupWidgetClass));
	DetailPopup->SetItem(ItemInfo);

	return DetailPopup;
}

UItemTooltipWidget* ABaseHUD::OpenItemTooltipPopup(FBagItemType ItemType)
{
	UItemTooltipWidget* TooltipPopup = CastChecked<UItemTooltipWidget>(OpenPopup(ItemTooltipPopupWidgetClass));
	TooltipPopup->SetItem(ItemType);

	return TooltipPopup;
}

UItemTooltipWidget* ABaseHUD::OpenItemTooltipPopup(EPointType PointType)
{
	UItemTooltipWidget* TooltipPopup = CastChecked<UItemTooltipWidget>(OpenPopup(ItemTooltipPopupWidgetClass));
	TooltipPopup->SetPoint(PointType);

	return TooltipPopup;
}

UItemTooltipWidget* ABaseHUD::OpenItemTooltipPopup(FEventContentType EventContentType, int32 PointIndex)
{
	UItemTooltipWidget* TooltipPopup = CastChecked<UItemTooltipWidget>(OpenPopup(ItemTooltipPopupWidgetClass));
	TooltipPopup->SetEventPoint(EventContentType, PointIndex);

	return TooltipPopup;
}

UItemTooltipWidget* ABaseHUD::OpenItemTooltipPopup(FAvatarEffectType AvatarEffectType)
{
	UItemTooltipWidget* TooltipPopup = CastChecked<UItemTooltipWidget>(OpenPopup(ItemTooltipPopupWidgetClass));
	TooltipPopup->SetAvatarEffect(AvatarEffectType);

	return TooltipPopup;
}

UItemTooltipWidget* ABaseHUD::OpenItemTooltipPopup(FAvatarFrameType AvatarFrameType)
{
	UItemTooltipWidget* TooltipPopup = CastChecked<UItemTooltipWidget>(OpenPopup(ItemTooltipPopupWidgetClass));
	TooltipPopup->SetAvatarFrame(AvatarFrameType);

	return TooltipPopup;
}

URaidJoinPopupWidget* ABaseHUD::OpenRaidJoinPopup(FRaidType RaidType)
{
	const FLobbyUIState* UIState = GetHUDStore().GetUIStateManager().GetUIState();
	if (UIState && UIState->GetHUDWidgetType() == EHUDWidgetType::Raid)
	{
		return nullptr;
	}

	RaidJoinPopupWidget = CastChecked<URaidJoinPopupWidget>(OpenPopup(RaidJoinPopupWidgetClass));
	if (!RaidJoinPopupWidget)
	{
		Q6JsonLogGunny(Warning, "ABaseHUD::OpenRaidJoinPopup - Cannot open RaidJoinPopupWdiget");
		return nullptr;
	}

	float CloseTime = RaidJoinPopupCloseTime;
	const UCMS* CMS = GetCMS();
	const FCMSRaidRow& RaidRow = CMS->GetRaidRowOrDummy(RaidType);
	if (!RaidRow.IsInvalid())
	{
		CloseTime = static_cast<float>(RaidRow.ReadySec);
	}

	RaidJoinPopupWidget->SetAutoCloseTime(CloseTime);

	const FCMSSagaRow& SagaRow = RaidRow.GetSaga();
	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "ABaseHUD::OpenRaidJoinPopup SagaRows don't exist.");
		return nullptr;
	}

	RaidJoinPopupWidget->SetInfo(SagaRow
		, RaidRow.RegularRaidScheduleIds.Num() > 0 ? ERaidCategory::RegularRaid : ERaidCategory::GeneralRaid);
	return RaidJoinPopupWidget;
}

UBondRewardInfoPopupWidget* ABaseHUD::OpenBondRewardInfoPopup(FCharacterType CharacterType)
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().BondRewardInfoPopupWidgetClass);
	UBondRewardInfoPopupWidget* BondRewardInfoPopup = CastChecked<UBondRewardInfoPopupWidget>(BasePopup);
	if (BondRewardInfoPopup)
	{
		BondRewardInfoPopup->SetInfo(CharacterType);
	}

	return BondRewardInfoPopup;
}

UCurrencyUsePopupWidget* ABaseHUD::OpenCurrencyUsePopup()
{
	return CastChecked<UCurrencyUsePopupWidget>(OpenPopup(GetUIClassResource().CurrencyUsePopupWidgetClass));
}

UGemShopPurchasePopupWidget* ABaseHUD::OpenGemShopPurchasePopup()
{
	UGemShopPurchasePopupWidget* GemShopPurchaseWidget = CastChecked<UGemShopPurchasePopupWidget>(OpenPopup(GetUIClassResource().GemShopPurchasePopupWidgetClass));
	GemShopPurchaseWidget->SetInfo();

	return GemShopPurchaseWidget;
}

USettingPopupWidget* ABaseHUD::OpenSettingPopup()
{
	USettingPopupWidget* SettingPopup = CastChecked<USettingPopupWidget>(OpenPopup(GetUIClassResource().SettingPopupWidgetClass));
	SettingPopup->SetView();

	return SettingPopup;
}

UEventRewardPopupWidget* ABaseHUD::OpenEventRewardPopupWidget()
{
	return CastChecked<UEventRewardPopupWidget>(OpenPopup(GetUIClassResource().EventRewardPopupWidgetClass));
}

void ABaseHUD::CloseRaidJoinPopup()
{
	if (RaidJoinPopupWidget)
	{
		RaidJoinPopupWidget->ClosePopup();
	}
}

#if !UE_BUILD_SHIPPING
UCheatCommandHelpPopupWidget* ABaseHUD::OpenCheatCommandHelpPopup(const TArray<IConsoleObject*>& ConsoleObjects, const TArray<FString>& CommandHistory)
{
	UCheatCommandHelpPopupWidget* HelpPopup = CastChecked<UCheatCommandHelpPopupWidget>(OpenPopup(CheatCommandHelpPopupWidgetClass));
	if (HelpPopup)
	{
		HelpPopup->SetTitle(FText::FromName("<Title>Cheat help</>"));
		HelpPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
		HelpPopup->SetHelp(ConsoleObjects, CommandHistory);
	}

	return HelpPopup;
}
#endif

void ABaseHUD::ClosePopup(UPopupBaseWidget* InPopupWidget)
{
	for (UPopupBaseWidget* PopupWidget : PopupWidgets)
	{
		if (PopupWidget != InPopupWidget)
		{
			continue;
		}

		PopupWidget->ClosePopup();
	}
}

void ABaseHUD::ClosePopupOnTop()
{
	UPopupBaseWidget* PopupWidget = PopupWidgets.Last();
	if (PopupWidget)
	{
		PopupWidget->ClosePopup();
	}
}

void ABaseHUD::CloseAllPopups()
{
	for (UPopupBaseWidget* PopupWidget : PopupWidgets)
	{
		check(PopupWidget);

		if (PopupWidget->IsOpened())
		{
			PopupWidget->ClosePopup();
		}
	}
}

void ABaseHUD::OnPopupClosed()
{
	--PopupOrder;
}

void ABaseHUD::ShowNotification(ENotificationType Type, const FText& Text)
{
	if (CreateWidgetIfNotCreated(&NotificationWidget, NotificationWidgetClass))
	{
		NotificationWidget->ShowNotification(Type, Text);
	}
}

void ABaseHUD::ShowNotification(ENotificationType Type, const TArray<FText>& Texts)
{
	if (CreateWidgetIfNotCreated(&NotificationWidget, NotificationWidgetClass))
	{
		NotificationWidget->ShowNotifications(Type, Texts);
	}
}

void ABaseHUD::ShowNotOpenedYetNotification(EFeatureOpenType Type)
{
	const FCMSContentFeatureOpenRow* FeatureOpenRow = GetCMS()->GetContentFeatureOpenRowByOpenType(Type);
	if (!FeatureOpenRow)
	{
		return;
	}

	ShowNotOpenedYetNotification(FSagaType(FeatureOpenRow->ConditionValue));
}

void ABaseHUD::ShowNotOpenedYetNotification(FSagaType Type)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Type);
	if (SagaRow.IsInvalid())
	{
		return;
	}

	FText Desc = Q6Util::GetNotOpenedYetText(SagaRow.Episode, SagaRow.Stage, SagaRow.SubStage);
	ShowNotification(ENotificationType::Short, Desc);
}

void ABaseHUD::ShowNotOpenedYetNotification(EWonderCategory Category, ENotOpenedYetWonderDescType DescType)
{
	EFeatureOpenType FeatureOpenType = GetFeatureOpenType(Category);
	const FCMSContentFeatureOpenRow* SpecialFeatureOpenRow = GetCMS()->GetContentFeatureOpenRowByOpenType(
		FeatureOpenType);
	if (!SpecialFeatureOpenRow)
	{
		return;
	}

	const FCMSSagaRow& SagaSpecialRow = GetCMS()->GetSagaRowOrDummy(
		FSagaType(SpecialFeatureOpenRow->ConditionValue));
	if (SagaSpecialRow.IsInvalid())
	{
		return;
	}

	const FCMSContentFeatureOpenRow* SagaFeatureOpenRow = GetCMS()->GetContentFeatureOpenRowByOpenValue(
		SpecialFeatureOpenRow->ConditionValue);
	if (!SagaFeatureOpenRow)
	{
		return;
	}

	FSagaType SagaType(SagaFeatureOpenRow->ConditionValue);
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.IsInvalid())
	{
		return;
	}

	if (DescType == ENotOpenedYetWonderDescType::OnlyFirstStep)
	{
		ShowNotOpenedYetNotification(SagaType);
		return;
	}

	FText Desc;
	if (GetHUDStore().GetSagaManager().IsStageCleared(SagaRow.Episode, SagaRow.Stage, SagaRow.SubStage))
	{
		Desc = FText::Format(Q6Util::GetLocalizedText("Lobby", "WonderIsNotOpenedYet1")
			, SagaSpecialRow.DescName);
	}
	else
	{
		if (SagaRow.SubStage == 0)
		{
			Desc = FText::Format(Q6Util::GetLocalizedText("Lobby", "WonderIsNotOpenedYet2")
				, FText::AsNumber(SagaRow.Episode)
				, FText::AsNumber(SagaRow.Stage)
				, SagaSpecialRow.DescName);
		}
		else
		{
			Desc = FText::Format(Q6Util::GetLocalizedText("Lobby", "WonderIsNotOpenedYet3")
				, FText::AsNumber(SagaRow.Episode)
				, FText::AsNumber(SagaRow.Stage)
				, FText::AsNumber(SagaRow.SubStage)
				, SagaSpecialRow.DescName);
		}
	}

	ShowNotification(ENotificationType::Short, Desc);
}

void ABaseHUD::ShowNotOpenedYetNotification(ESpecialCategory Category)
{
	switch (Category)
	{
		case ESpecialCategory::Saga:
		{
			const FCMSSpecialRow* SpecialRow = GetCMS()->GetFirstSpecialRowByCategory(Category);
			if (!SpecialRow)
			{
				break;
			}

			const FCMSContentFeatureOpenRow* FeatureOpenRow = GetCMS()->GetContentFeatureOpenRowByOpenValue(
				SpecialRow->Type);
			if (!FeatureOpenRow)
			{
				break;
			}

			ShowNotOpenedYetNotification(FSagaType(FeatureOpenRow->ConditionValue));
		}
		break;
		case ESpecialCategory::Wonder:
		{
			TArray<EWonderCategory> Categories = GetGameResource().GetSpecialWonderStageLineup();
			if (Categories.IsValidIndex(0))
			{
				ShowNotOpenedYetNotification(Categories[0], ENotOpenedYetWonderDescType::OnlyFirstStep);
			}
		}
		break;
	}
}

void ABaseHUD::ShowMissionToast(const FWeeklyMissionToastInfo& InWeeklyMission)
{
	if (CreateWidgetIfNotCreated(&MissionToastWidget, MissionToastWidgetClass))
	{
		MissionToastWidget->ShowMissionToast(InWeeklyMission);
	}
}

void ABaseHUD::ShowGuidePopup(const FRewardStep& RewardStep)
{
	if (CreateWidgetIfNotCreated(&GuidePopupWidget, GuidePopupWidgetClass))
	{
		GuidePopupWidget->ShowGuidePopupWidget(RewardStep);
	}
}

bool ABaseHUD::CheckMaxItemNum(ECurrencyCheckType CheckType, bool bCheckCollection)
{
	if (bCheckCollection && GetHUDStore().HasMaxCollection())
	{
		ShowNotification(ENotificationType::Short, Q6Util::GetMaxCollectionText(CheckType));
		return true;
	}

	ECurrencyType CurrencyType = GetHUDStore().GetWorldUser().HasMaxCurrency(CheckType);
	if (CurrencyType != ECurrencyType::None)
	{
		ShowNotification(ENotificationType::Short, Q6Util::GetMaxCurrencyText(CheckType, CurrencyType));
		return true;
	}

	return false;
}

bool ABaseHUD::CheckMaxItemNum(const TArray<FMailId>& MailIds)
{
	const UMailManager& MailMgr = GetHUDStore().GetMailManager();
	const UWorldUser& WorldUser = GetHUDStore().GetWorldUser();

	for (const FMailId& MailId : MailIds)
	{
		const FMailInfo* MailInfo = MailMgr.Find(MailId);
		if (!MailInfo)
		{
			Q6JsonLogRoze(Error, "ALobbyHUD::CheckMaxItemNum - Not found mail info", Q6KV("MailId", MailId.S));
			continue;
		}

		const FItemData& RewardItem = MailInfo->RewardItem;
		if (IsCollectionCategory(RewardItem.Category) && GetHUDStore().HasMaxCollection())
		{
			ShowNotification(ENotificationType::Short, Q6Util::GetLocalizedText("Lobby", "MaxCollection"));
			return true;
		}

		ECurrencyType CurrencyType = GetCurrencyType(RewardItem.Category);
		if (CurrencyType != ECurrencyType::None && WorldUser.IsMaxCurrency(CurrencyType))
		{
			ShowNotification(ENotificationType::Short, Q6Util::GetMaxCurrencyText(ECurrencyCheckType::None, CurrencyType));
			return true;
		}
	}

	return false;
}

void ABaseHUD::ClearBlackoutDelegates() const
{
	if (BlackoutWidget)
	{
		BlackoutWidget->OnBlackoutShowingDelegate.Unbind();
		BlackoutWidget->OnBlackoutFinishedDelegate.Unbind();
	}
}

void ABaseHUD::SetBlackoutDelegates(FBoolParamDelegate InBlackoutShowingEvent, FBoolParamDelegate InBlackoutFinishEvent)
{
	if (CreateWidgetIfNotCreated(&BlackoutWidget, BlackoutWidgetClass))
	{
		BlackoutWidget->OnBlackoutShowingDelegate = InBlackoutShowingEvent;
		BlackoutWidget->OnBlackoutFinishedDelegate = InBlackoutFinishEvent;
	}
}

void ABaseHUD::ShowBlackout(EBlackoutType Type)
{
	if (CreateWidgetIfNotCreated(&BlackoutWidget, BlackoutWidgetClass))
	{
		BlackoutWidget->ShowBlackout(Type);
	}
}

void ABaseHUD::HideBlackout() const
{
	if (BlackoutWidget)
	{
		BlackoutWidget->HideBlackout();
	}
}

void ABaseHUD::StopBlackout()
{
	if (BlackoutWidget)
	{
		BlackoutWidget->StopBlackout();
	}
}

bool ABaseHUD::IsShowingBlackout() const
{
	if (BlackoutWidget)
	{
		return BlackoutWidget->IsShowing();
	}

	return false;
}

bool ABaseHUD::IsWorkingBlackout() const
{
	if (BlackoutWidget)
	{
		return BlackoutWidget->IsWorking();
	}

	return false;
}

void ABaseHUD::SetClearUI(bool bClear, bool bSetOthersVis /* = true */, bool bDimmed /* = false */)
{
	if (bClear)
	{
		if (CreateWidgetIfNotCreated(&ClearUIWidget, ClearUIWidgetClass))
		{
			ClearUIWidget->ShowClearUIWidget(bDimmed);
		}
	}
	else if (ClearUIWidget)
	{
		ClearUIWidget->RemoveFromParent();
	}

	if (bSetOthersVis)
	{
		SetWidgetsVisible(!bClear);
	}
}

bool ABaseHUD::IsUICleared() const
{
	if (ClearUIWidget)
	{
		return ClearUIWidget->IsVisible();
	}

	return false;
}

void ABaseHUD::SetWidgetsVisible(bool bInVisible)
{
	for (UPopupBaseWidget* PopupWidget : PopupWidgets)
	{
		check(PopupWidget);

		if (PopupWidget->IsOpened())
		{
			PopupWidget->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
		}
	}
}

void ABaseHUD::OnBackgroundTouched()
{
	if (IsUICleared())
	{
		ClearUIWidget->ToggleBackButtonVisibility();
	}
}

void ABaseHUD::OnNetworkStartConnect()
{
	if (!bSilentReconnect)
	{
		NetworkProgressWidget->Show(Q6Util::GetLocalizedTextOrKey("Service", "Reconnecting"));
	}
}

void ABaseHUD::OnNetworkMaintenance(const FMaintenanceInfo& /*Info*/)
{
	OnNetworkError(Q6_ERROR_MAINTENANCE, FString(""));
}

void ABaseHUD::OnNetworkConnected()
{
}

void ABaseHUD::OnNetworkConnectFailed()
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();

	if (!GameInstance->IsForeground())
	{
		Q6JsonLogNet(Display, "OnNetworkConnectFailed, give up in background");
		return;
	}

	Q6JsonLogNet(Display, "OnNetworkConnectFailed, retrying");
	StartReconnect();
}

void ABaseHUD::OnNetworkDisconnected()
{
	// cleanup errors
	ErrorPopupWidget->ClosePopup();

	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();

	bReconnecting = true;

	if (!bSilentReconnect)
	{
		BlockInputForNetwork();
	}

	if (!GameInstance->IsForeground())
	{
		Q6JsonLogNet(Display, "OnNetworkDisconnected, give up in background");
		return;
	}

	Q6JsonLogNet(Display, "OnNetworkDisconnected, retrying");
	StartReconnect();
}

void ABaseHUD::OnNetworkLogin(const FL2CAuthLoginResp& Res)
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.ReenterLobby();
}

void ABaseHUD::OnNetworkEnteredLobby(const FL2CAuthEnterLobbyResp& Res)
{
}

void ABaseHUD::OnNetworkEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp)
{
	bReconnecting = false;
	bSilentReconnect = bDesiredSilentReconnect;
	UnblockInputForNetwork();
}

void ABaseHUD::OnNetworkStartBlockingRequest()
{
	if (!bReconnecting)
	{
		BlockInputForNetwork();
	}
}

void ABaseHUD::OnNetworkEndBlockingRequest()
{
	if (!bReconnecting)
	{
		UnblockInputForNetwork();
	}
}

void ABaseHUD::OnNetworkQueuingRequestToRetry()
{
	if (!bSilentReconnect)
	{
		return;
	}

	bSilentReconnect = false;

	if (!bReconnecting)
	{
		return;
	}

	BlockInputForNetwork();
	NetworkProgressWidget->Show(Q6Util::GetLocalizedTextOrKey("Service", "Reconnecting"));
}

void ABaseHUD::OnKicked(const FString& ReasonDesc)
{
	bKicked = true;

	UnblockInputForNetwork();

	// TODO: ui need to add error code for duplicated login.
	UConfirmPopupWidget* ConfirmPopup = OpenConfirmPopup(FText::FromString("kicked"), FText::FromString("kicked"));
	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
	APlayerController* FirstPlayerController = GetWorld()->GetFirstPlayerController();
	ConfirmPopup->OnPopupClosedDelegate.BindLambda([FirstPlayerController]() {
#if PLATFORM_IOS
		FGenericPlatformMisc::RequestExit(true);
#else
		FirstPlayerController->ConsoleCommand("quit");
#endif // PLATFORM_IOS
	});
}

void ABaseHUD::HandleError()
{
	if (ErrorPopupWidget->GetKind() == EPopupKind::Fatal)
	{
		APlayerController* InPlayerController = UGameplayStatics::GetPlayerController(GetWorld(), 0);
		InPlayerController->ConsoleCommand("quit force");
		return;
	}

	if (ErrorPopupWidget->GetKind() == EPopupKind::Maintenance)
	{
		ALoginHUD* LoginHUD = Cast<ALoginHUD>(this);
		if (!LoginHUD)
		{
			UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
			FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
			ClientNetwork.BackToLoginLevel();
		}
		else
		{
			ErrorPopupWidget->ClosePopup();
		}

		return;
	}

	if (ErrorPopupWidget->GetKind() != EPopupKind::Info)
	{
		UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
		FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
		ClientNetwork.PanicRestartGame(TEXT("HandleError"));
	}
	else
	{
		ErrorPopupWidget->ClosePopup();
	}
}

void ABaseHUD::OnConfirmErrorPopupInternal(EConfirmPopupFlag InPopupFlag)
{
	HandleError();
}

void ABaseHUD::OnNetworkError(int32 InErrorCode, FString InErrorMsg)
{
	bReconnecting = false;
	UnblockInputForNetwork();

	ShowNetworkErrorPopup(InErrorCode, InErrorMsg);
}

void ABaseHUD::StartReconnect()
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	const double NowSeconds = FPlatformTime::Seconds();

	if (NowSeconds > ClientNetwork.GetConnectionClosedSeconds() + (double)CVarQ6ReconnectTimeout.GetValueOnGameThread())
	{
		OnNetworkError(Q6_ERROR_DISCONNECTED, FString(""));
		return;
	}

	ClientNetwork.Reconnect();
}

void ABaseHUD::OnEnterBackground()
{
	EnterBackgroundSeconds = FPlatformTime::Seconds();
}

void ABaseHUD::OnBackgroundTimeout()
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.PanicRestartGame(TEXT("HandleBackgroundTimeout"));
}

void ABaseHUD::OnEnterForeground()
{
	const double NowSeconds = FPlatformTime::Seconds();
	const double PrevEnterBackgroundSeconds = EnterBackgroundSeconds;
	EnterBackgroundSeconds = NowSeconds;

	if (NowSeconds > PrevEnterBackgroundSeconds + (double)CVarQ6BackgroundNormalTimeout.GetValueOnGameThread())
	{
		OnBackgroundTimeout();
		return;
	}

	// if disconnected long ago, go to world select
	if (bReconnecting)
	{
		// if error popped long ago, go to world select
		if (NowSeconds > PrevEnterBackgroundSeconds + (double)CVarQ6BackgroundAbnormalTimeout.GetValueOnGameThread())
		{
			OnBackgroundTimeout();
		}
		else
		{
			UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
			FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
			ClientNetwork.EnsureContextDisconnect();
			ClientNetwork.Reconnect();
		}
		return;
	}

	if (!NetworkProgressWidget || !ErrorPopupWidget)
	{
		return;
	}

	if (!NetworkProgressWidget->IsVisible() && !ErrorPopupWidget->IsVisible())
	{
		return;
	}

	// if error popped long ago, go to world select
	if (NowSeconds > PrevEnterBackgroundSeconds + (double)CVarQ6BackgroundAbnormalTimeout.GetValueOnGameThread())
	{
		OnBackgroundTimeout();
	}
}

void ABaseHUD::BlockInputForNetwork()
{
	if (BlockInputForNetworkStartTime > 0) {
		// already blocking
		return;
	}

	BlockInputForNetworkStartTime = FPlatformTime::Seconds();
	GetLocalPlayerController(this)->DisableInput(nullptr);
	GetWorld()->GetGameViewport()->GetGameViewportWidget()->SetVisibility(EVisibility::HitTestInvisible);

	// Since "SetVisibility(EVisibility::HitTestInvisible)" doesn't effect immediatly,
	// we need to clear hit test grid up to avoid some other input gets slick in
	// Grid will be fully restored at next Draw process
	//SWindow* GameViewportWindow = GetWorld()->GetGameViewport()->GetGameViewport()->FindWindow().Get();
	//if (GameViewportWindow)
	//{
	//	FHittestGrid& HittestGrid = GameViewportWindow->GetHittestGrid().Get();
	//	HittestGrid.ClearGridForNewFrame(FSlateRect(0, 0, 0, 0));
	//}
}

void ABaseHUD::UnblockInputForNetwork()
{
	BlockInputForNetworkStartTime = -1;
	GetLocalPlayerController(this)->EnableInput(nullptr);
	GetWorld()->GetGameViewport()->GetGameViewportWidget()->SetVisibility(EVisibility::Visible);

	NetworkProgressWidget->Hide();
}

FString ABaseHUD::MakeErrorText(FErrTextType ErrType, const TArray<int32>& Extra) const
{
	switch (ErrType.x)
	{
	case Q6_ERROR_XP_UPDATE_USER_XP:
		return OnErrAddXp(GetCMS(), ErrType, GetUser().GetAccountName(), Extra);
	case Q6_ERROR_CHARACTER_UPDATE_CHARACTER:
		return OnErrCharacterUpdate(GetCMS(), ErrType, Extra);
	case Q6_ERROR_INVALID_BOX_ID:
	case Q6_ERROR_CHARACTER_INVALID:
	case Q6_ERROR_INVALID_PARTY_INFO:
	case Q6_ERROR_CONTENT_IS_OUT_OF_DATE:
		return OnErrParam1(GetCMS(), ErrType, Extra);
	case Q6_ERROR_INSUFFICIENT_GEM:
	case Q6_ERROR_INSUFFICIENT_WATT:
	case Q6_ERROR_INSUFFICIENT_SCULPTURE_POINT:
	case Q6_ERROR_INSUFFICIENT_RELIC_POINT:
	case Q6_ERROR_INSUFFICIENT_FRIENDSHIP_POINT:
		return OnErrParam2(GetCMS(), ErrType, Extra);
	case Q6_ERROR_NOT_ENOUGH_MATERIAL:
		return OnNotEnoughMaterial(GetCMS(), ErrType, Extra);
	default:
		return OnErrNoParam(GetCMS(), ErrType);
	}
}

void ABaseHUD::OnError(const FResError* Error)
{
	ShowErrorPopupInternal(Error->Code, Error->Body.ErrorCode, Error->Body.Error, Error->Body.Extra);
}

void ABaseHUD::OnError(FText InErrorMsg)
{
	ShowErrorPopupInternal(FText::GetEmpty(), InErrorMsg);
}

void ABaseHUD::OnAlert(FText InAlertMsg)
{
	ShowAlertPopupInternal(FText::GetEmpty(), InAlertMsg);
}

void ABaseHUD::OnFatal(FText InFatalMsg)
{
	ShowFatalPopupInternal(FText::GetEmpty(), InFatalMsg);
}

void ABaseHUD::OnMaintenance(FText InMaintenanceMsg)
{
	ShowMaintenancePopupInternal(FText::GetEmpty(), InMaintenanceMsg);
}

void ABaseHUD::ShowNetworkErrorPopup(int32 InQ6ErrorCode, FString InErrorMsg)
{
	// network event is almost 500. session expire is 401, but we don't use it.
	TArray<int32> InEmptyExtra;
	ShowErrorPopupInternal(500, InQ6ErrorCode, InErrorMsg, InEmptyExtra);
}

static EPopupKind GetPopupKindBy(int32 InHttpStatusCode, int32 InQ6ErrorCode)
{
	if (InHttpStatusCode == 200)
	{
		return EPopupKind::Info;
	}
	else if (InHttpStatusCode < 400)
	{
		return EPopupKind::Error;
	}
	else
	{
		if (InQ6ErrorCode == Q6_ERROR_MAINTENANCE)
		{
			return EPopupKind::Maintenance;
		}

		return EPopupKind::NetError;
	}
}

void ABaseHUD::ShowErrorPopupInternal(int32 InHttpStatusCode, int32 InQ6ErrorCode, FString InErrorMsg, const TArray<int32>& InExtra)
{
	// todo: handle shiping-build.
	const FText title = FText::FromString(FString::Printf(TEXT("%d-%d"), InHttpStatusCode, InQ6ErrorCode));
	const FText ErrorMsg = FText::FromString(MakeErrorText(FErrTextType(InQ6ErrorCode), InExtra) + InErrorMsg);

//#if !UE_BUILD_SHIPPING
//	const FText title = FText::FromString(FString::Printf(TEXT("HttpStatusCode: %d / Q6ErrorCode: %d"), InHttpStatusCode, InQ6ErrorCode));
//	const FText ErrorMsg = FText::FromString(MakeErrorText(FErrTextType(InQ6ErrorCode), InExtra) + InErrorMsg);
//#else
//	const FText title = FText::GetEmpty(); // TODO: need a proper title for shipping version.
//	const FText ErrorMsg = FText::FromString(MakeErrorText(FErrTextType(InQ6ErrorCode), InExtra));
//#endif

	OpenErrorPopup(GetPopupKindBy(InHttpStatusCode, InQ6ErrorCode), title, ErrorMsg);
}

void ABaseHUD::ShowErrorPopupInternal(FText InTitle, FText InErrorMsg)
{
	OpenErrorPopup(EPopupKind::Error, InTitle, InErrorMsg);
}

void ABaseHUD::ShowAlertPopupInternal(FText InTitle, FText InAlertMsg)
{
	OpenErrorPopup(EPopupKind::Info, InTitle, InAlertMsg);
}

void ABaseHUD::ShowFatalPopupInternal(FText InTitle, FText InFatalMsg)
{
	OpenErrorPopup(EPopupKind::Fatal, InTitle, InFatalMsg);
}

void ABaseHUD::ShowMaintenancePopupInternal(FText InTitle, FText InFatalMsg)
{
	OpenErrorPopup(EPopupKind::Maintenance, InTitle, InFatalMsg);
}
