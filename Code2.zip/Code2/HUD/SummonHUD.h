// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "BaseHUD.h"

#include "SummonHUD.generated.h"

class USummonHUDWidget;
class USummonResultWidget;

struct FNetInfo;
struct FSummonInfo;

UCLASS()
class Q6_API ASummonHUD : public ABaseHUD
{
	GENERATED_BODY()

public:
	ASummonHUD();

	virtual void BeginPlay() override;
	virtual EHUDType GetHUDType() override { return EHUDType::Summon; }

	void InteractionReady();
	void SetSummonInfo(const FSummonInfo& Info, const FSimpleDelegate& EndDelegate);
	void MoveToNextSummonInfo();
	void HideSummonInfo();
	void ShowResultWidget();
	void HideResultWidget();

	void ShowSkipButton(bool bShow);

private:
	void CreateWidgets();

	// Widget Classes

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<USummonHUDWidget> SummonHUDWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<USummonResultWidget> SummonResultWidgetClass;

	// Widgets

	UPROPERTY(Transient)
	USummonHUDWidget* HUDWidget;

	UPROPERTY(Transient)
	USummonResultWidget* ResultWidget;
};