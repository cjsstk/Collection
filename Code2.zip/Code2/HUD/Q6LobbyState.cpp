#include "Q6LobbyState.h"

#include "GameResource.h"
#include "Q6GameInstance.h"
#include "Q6.h"
#include "Q6Log.h"
#include "HUDStore/RaidManager.h"

void FLobbyUIState::GetDefaultNaviBar(FNaviBarState& InOutNaviBarState) const
{
	InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Lobby", "TitleHome");
	InOutNaviBarState.TitleText = FText::Format(InOutNaviBarState.TitleText, FText::FromString(GetHUDStore().GetWorldUser().GetNickname()));
	InOutNaviBarState.TopBarType = ETopBarType::Default;
	InOutNaviBarState.bBottomBarVisible = true;
	InOutNaviBarState.bBackVisible = true;
}

void FLobbyUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Lobby", "TitleHome");
	InOutNaviBarState.TitleText = FText::Format(InOutNaviBarState.TitleText, FText::FromString(GetHUDStore().GetWorldUser().GetNickname()));
	InOutNaviBarState.TopBarType = ETopBarType::Default;
	InOutNaviBarState.bBottomBarVisible = true;
	InOutNaviBarState.bBackVisible = false;
}

FString FLobbyUIState::ToString() const
{
	return ENUM_TO_STRING(EHUDWidgetType, GetHUDWidgetType());
}

void FLobbySettingUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	FText TitleText;
	switch (EditType)
	{
		case ELobbySettingEditType::EditTemplate:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleLobbySettingEditTemplate");
			break;
		case ELobbySettingEditType::EditCharacter:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleLobbySettingEditCharacter");
			break;
		default:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleLobbySetting");
			break;
	}

	InOutNaviBarState.SetNaviBarState(TitleText, ETopBarType::None, false, true);
}

bool FLobbySettingUIState::GotoBackState()
{
	if (EditType != ELobbySettingEditType::None)
	{
		EditType = ELobbySettingEditType::None;
		return true;
	}

	return false;
}

EHUDWidgetType FInventoryUIState::GetHUDWidgetType() const
{
	if (Category == EInventoryCategory::Collection)
	{
		return EHUDWidgetType::Collection;
	}

	if (Category == EInventoryCategory::StorageBox)
	{
		return EHUDWidgetType::StorageBox;
	}

	Q6JsonLogRoze(Error, "FInventoryUIState::GetHUDWidgetType - Where are you in there?");
	return EHUDWidgetType::Invalid;
}

void FInventoryUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	ETopBarType BarType = ETopBarType::None;
	bool bBottomVisible = false;
	bool bBackVisible = true;
	FString KeyStr = TEXT("Title");
	if (EditType == EInventoryEdit::None)
	{
		KeyStr.Append(Category == EInventoryCategory::Collection ? "Collection" : "StorageBox");
		bBottomVisible = true;
		bBackVisible = false;
		BarType = ETopBarType::Default;
	}
	else if (EditType == EInventoryEdit::PullOut)
	{
		KeyStr.Append("PullOut");
	}
	else if (EditType == EInventoryEdit::Stash)
	{
		KeyStr.Append("Stash");
	}

	switch (InventoryType)
	{
		case EInventoryType::Character: KeyStr.Append("Character");	break;
		case EInventoryType::Relic:		KeyStr.Append("Relic");		break;
		case EInventoryType::Sculpture:	KeyStr.Append("Sculpture");	break;
	}

	InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", *KeyStr), BarType, bBottomVisible, bBackVisible);
}

bool FInventoryUIState::GotoBackState()
{
	if (EditType != EInventoryEdit::None)
	{
		EditType = EInventoryEdit::None;
		return true;
	}

	return false;
}

void FDialogueUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.SetNaviBarState(FText::GetEmpty(), ETopBarType::None, false, false);
}

EHUDWidgetType FPartyUIState::GetHUDWidgetType() const
{
	switch (WidgetType)
	{
		case EPartyWidgetType::Party:
		case EPartyWidgetType::CombatReady:
			return EHUDWidgetType::Party;
		case EPartyWidgetType::JokerSet:
			return EHUDWidgetType::Joker;
	}

	Q6JsonLogRoze(Error, "FPartyUIState::GetHUDWidgetType - Where are you in there?");
	return EHUDWidgetType::Invalid;
}

void FPartyUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (WidgetType == EPartyWidgetType::Party)
	{
		if (bIsEdit)
		{
			InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitlePartyEdit"), ETopBarType::None, false);
		}
		else
		{
			FText TitleTextFormat = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleParty"), PageNum);
			InOutNaviBarState.SetNaviBarState(TitleTextFormat, ETopBarType::Default, true, false);
		}
	}
	if (WidgetType == EPartyWidgetType::JokerSet)
	{
		if (bIsEdit)
		{
			InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleJokerSetup"), ETopBarType::None, false);
		}
		else
		{
			FText TitleTextFormat = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleJokerSet"), PageNum);
			InOutNaviBarState.SetNaviBarState(TitleTextFormat, ETopBarType::Default, true, false);
		}
	}
	else if (WidgetType == EPartyWidgetType::CombatReady)
	{
		if (bIsEdit)
		{
			InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitlePartyEdit"), ETopBarType::CombatReady, false);
		}
		else
		{
			const UCMS* CMS = GetCMS();
			const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);
			FText TitleTextFormat;

			if (SagaRow.ContentType == EContentType::MultiSideBattle)
			{
				TitleTextFormat = FText::Format(Q6Util::GetLocalizedText("Lobby", "MultiSideParty"), PageNum);
			}
			else
			{
				TitleTextFormat = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleParty"), PageNum);
			}

			InOutNaviBarState.SetNaviBarState(TitleTextFormat, ETopBarType::CombatReady, true, true);
			
		}

		InOutNaviBarState.TopBarType = ETopBarType::CombatReady;
	}

	const FRegularRaidState& RegularRaidState = GetHUDStore().GetRaidManager().GetRegularRaidState();
	if (RegularRaidState.RespReady)
	{
		const UCMS* CMS = GetCMS();
		const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);
		if (SagaRow.ContentType == EContentType::Raid)
		{
			InOutNaviBarState.SetNaviBarState(InOutNaviBarState.TitleText, InOutNaviBarState.TopBarType
				, false, InOutNaviBarState.bBackVisible);
		}
	}
}

bool FPartyUIState::GotoBackState()
{
	if ((WidgetType == EPartyWidgetType::JokerSet) && !bIsEdit)
	{
		WidgetType = EPartyWidgetType::Party;
		return true;
	}

	if (bIsEdit)
	{
		bIsEdit = false;
		return true;
	}

	if (bIsPetEdit)
	{
		bIsPetEdit = false;
		return true;
	}

	return false;
}

void FJokerSelectUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (FriendMenu == EFriendMenu::MainView)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleJokerSelect"));
	}
	else if (FriendMenu == EFriendMenu::JokerSetView)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleJokerSetList"));
	}

	InOutNaviBarState.TopBarType = ETopBarType::CombatReady;

	const FRegularRaidState& RegularRaidState = GetHUDStore().GetRaidManager().GetRegularRaidState();
	if (RegularRaidState.RespReady)
	{
		const UCMS* CMS = GetCMS();
		const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);
		if (SagaRow.ContentType == EContentType::Raid)
		{
			InOutNaviBarState.SetNaviBarState(InOutNaviBarState.TitleText, InOutNaviBarState.TopBarType
				, false, InOutNaviBarState.bBackVisible);
		}
	}
}

bool FJokerSelectUIState::GotoBackState()
{
	if (FriendMenu != EFriendMenu::MainView)
	{
		FriendMenu = EFriendMenu::MainView;
		return true;
	}

	return false;
}

void FSagaUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (SagaTab == ESagaTab::Episode)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSaga"));
	}
	else
	{
		InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Lobby", "TitleSagaStage");

		InOutNaviBarState.SetNaviBarState(FText::Format(InOutNaviBarState.TitleText, FText::AsNumber(Episode), SagaTitleText));
	}
}

bool FSagaUIState::GotoBackState()
{
	if (SagaTab == ESagaTab::Stage)
	{
		SagaTab = ESagaTab::Episode;
		return true;
	}

	return false;
}

FString FSagaUIState::ToString() const
{
	return Super::ToString() + FString::Printf(TEXT(" - SagaTab(%s), Episode(%d)"), *ENUM_TO_STRING(ESagaTab, SagaTab), Episode);
}

void FSpecialUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (MenuType == ESpecialStageMenuType::Main)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSpecialStage"));
	}
	else
	{
		switch (Category)
		{
			case ESpecialCategory::Character:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSpecialCharacter"));
				break;

			case ESpecialCategory::Saga:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSpecialBoss"));
				break;

			case ESpecialCategory::Wonder:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSpecialWonder"));
				break;

			case ESpecialCategory::Event:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSpecialEvent"));
				break;

			default:
				InOutNaviBarState.SetNaviBarState(FText::GetEmpty());
				Q6JsonLogZagal(Warning, "Invalid ESpecialCategory",
					Q6KV("Category", ENUM_TO_STRING(ESpecialCategory, Category)));
				break;
		}

		if (SpecialType != SpecialTypeInvalid)
		{
			if (Category == ESpecialCategory::Character)
			{
				const UCMS* CMS = GetCMS();
				const FCMSSpecialRow& SpecialRow = CMS->GetSpecialRowOrDummy(SpecialType);
				const FCMSUnitRow& UnitRow = CMS->GetUnitRowOrDummy(FCharacterType(SpecialRow.ConditionId));

				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSpecialCharacterStage"));
				InOutNaviBarState.TitleText = FText::Format(InOutNaviBarState.TitleText, UnitRow.DescName);
			}
			else if (Category == ESpecialCategory::Wonder)
			{
				// Not implemented yet
				// TitleState.SetTitleState(Q6Util::GetLocalizedText("Lobby", "TitleSpecialCharacterStage"));
			}
		}
	}
}

bool FSpecialUIState::GotoBackState()
{
	if (MenuType == ESpecialStageMenuType::StageList)
	{
		MenuType = ESpecialStageMenuType::EpisodeList;
		SpecialType = SpecialTypeInvalid;

		switch (Category)
		{
			case ESpecialCategory::Saga:
				MenuType = ESpecialStageMenuType::Main;
				break;

			case ESpecialCategory::CharacterPortal:
			case ESpecialCategory::RelicPortal:
			case ESpecialCategory::SculpturePortal:
			case ESpecialCategory::Vacation:
			case ESpecialCategory::Pet:
			case ESpecialCategory::PetSecondSkill:
			case ESpecialCategory::PetThirdSkill:
			case ESpecialCategory::Pyramid:
				Category = ESpecialCategory::Wonder;
				break;
		}

		return true;
	}
	else if (MenuType == ESpecialStageMenuType::EpisodeList)
	{
		MenuType = ESpecialStageMenuType::Main;
		return true;
	}

	return false;
}

void FDailyDungeonUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (MenuType == EDailyDungeonMenuType::Main || 
		MenuType == EDailyDungeonMenuType::Info)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleDailyDungeon"));
		return;
	}

	switch (DungeonCategory)
	{
		case EDailyDungeonCategory::None:
			InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleDailyDungeon"));
			break;
		case EDailyDungeonCategory::Promote:
			InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleDailyPromote"));
			break;
		case EDailyDungeonCategory::Xp:
			InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleDailyXP"));
			break;
		case EDailyDungeonCategory::Gold:
			InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleDailyGold"));
			break;
	}
}

bool FDailyDungeonUIState::GotoBackState()
{
	if (MenuType == EDailyDungeonMenuType::StageList)
	{
		MenuType = EDailyDungeonMenuType::Main;
		return true;
	}

	return false;
}

void FTrainingCenterUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleTrainingCenter"));
}

void FSummonUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	switch (Sequence)
	{
	case ESummonSequence::Main:
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleSummon"), ETopBarType::Default, true, false);
		break;
	case ESummonSequence::Result:
		InOutNaviBarState.SetNaviBarState(FText::GetEmpty(), ETopBarType::None, false, false);
		break;
	}
}

bool FSummonUIState::GotoBackState()
{
	if (Sequence == ESummonSequence::Result)
	{
		Sequence = ESummonSequence::Main;
		return true;
	}

	return false;
}

void FUpgradeUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (UpgradeSequence == EUpgradeSequence::Main)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleUpgrade"));
		InOutNaviBarState.bBackVisible = false;
		return;
	}

	if (UpgradeSequence == EUpgradeSequence::Upgrade)
	{
		InOutNaviBarState.TopBarType = ETopBarType::None;
		InOutNaviBarState.bBottomBarVisible = false;
	}

	const UUIResource& UIResource = GetUIResource();
	if (Category == EUpgradeCategory::Character)
	{
		const TArray<FText>& TextArray = UIResource.GetUpgradeCharacterTitles();

		if (TextArray.IsValidIndex(UpgradeMenuIndex))
		{
			InOutNaviBarState.TitleText = TextArray[UpgradeMenuIndex];
		}
	}
	else if (Category == EUpgradeCategory::Skill)
	{
		const TArray<FText>& TextArray = UIResource.GetUpgradeSkillTitles();

		if (TextArray.IsValidIndex(UpgradeMenuIndex))
		{
			InOutNaviBarState.TitleText = TextArray[UpgradeMenuIndex];
		}
	}
	else if (Category == EUpgradeCategory::Sculpture)
	{
		const TArray<FText>& TextArray = UIResource.GetUpgradeSculptureTitles();

		if (TextArray.IsValidIndex(UpgradeMenuIndex))
		{
			InOutNaviBarState.TitleText = TextArray[UpgradeMenuIndex];
		}
	}
	else if (Category == EUpgradeCategory::Relic)
	{
		const TArray<FText>& TextArray = UIResource.GetUpgradeRelicTitles();

		if (TextArray.IsValidIndex(UpgradeMenuIndex))
		{
			InOutNaviBarState.TitleText = TextArray[UpgradeMenuIndex];
		}

	}
	else
	{
		InOutNaviBarState.TitleText = FText::GetEmpty();
		Q6JsonLogMoon(Warning, "Invalid EUpgradELootCategory Type");
	}
}

bool FUpgradeUIState::GotoBackState()
{
	if (UpgradeSequence == EUpgradeSequence::Inventory)
	{
		UpgradeSequence = EUpgradeSequence::Main;
		return true;
	}
	else if (UpgradeSequence == EUpgradeSequence::Upgrade)
	{
		UpgradeSequence = EUpgradeSequence::Inventory;
		return true;
	}

	return false;
}

void FFriendUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (FriendMenu == EFriendMenu::MainView)
	{
		switch (FriendCategory)
		{
			case EFriendCategory::FriendConnected:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleFriendsList"));
				break;
			case EFriendCategory::FriendReceiving:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleFriendPending"));
				break;
			case EFriendCategory::FriendSearching:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleFriendSearch"));
				break;
			case EFriendCategory::FriendBookFeed:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleFriendFeed"));
				break;
		}

		InOutNaviBarState.bBackVisible = false;
	}
	else if (FriendMenu == EFriendMenu::JokerSetView)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleJokerSetList"));
	}
}

bool FFriendUIState::GotoBackState()
{
	if (FriendMenu != EFriendMenu::MainView)
	{
		FriendMenu = EFriendMenu::MainView;
		return true;
	}

	return false;
}

void FInitialRewardEventUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.SetNaviBarState(FText::GetEmpty(), ETopBarType::None, false, false);
}

FString FInitialRewardEventUIState::ToString() const
{
	return Super::ToString() +
		FString::Printf(TEXT(" - SagaType(%d), Widget(%s), RewardIndex(%d)"),
			SagaType.x,
			*ENUM_TO_STRING(EInitialRewardWidgetType, WidgetType),
			RewardIndex);
}

void FWonderUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	switch (Category)
	{
		case EWonderCategory::Main:
			InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Lobby", "Wonder");
			InOutNaviBarState.bBackVisible = false;
			break;
		case EWonderCategory::Pyramid:
			InOutNaviBarState.TitleText = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleWonderPyramid"), FText::AsNumber(Level));
			InOutNaviBarState.TopBarType = ETopBarType::None;
			InOutNaviBarState.bBottomBarVisible = false;
			break;
		case EWonderCategory::PetPark:
			InOutNaviBarState.TitleText = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleWonderPetPark"), FText::AsNumber(Level));
			InOutNaviBarState.TopBarType = ETopBarType::None;
			InOutNaviBarState.bBottomBarVisible = false;
			break;
		case EWonderCategory::Powerplant:
			InOutNaviBarState.TitleText = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleWonderPowerplant"), FText::AsNumber(Level));
			InOutNaviBarState.TopBarType = ETopBarType::None;
			InOutNaviBarState.bBottomBarVisible = false;
			break;
		case EWonderCategory::Temple:
			InOutNaviBarState.TitleText = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleWonderHolyRelic"), FText::AsNumber(Level));
			InOutNaviBarState.TopBarType = ETopBarType::None;
			InOutNaviBarState.bBottomBarVisible = false;
			break;
		case EWonderCategory::Vacation:
			InOutNaviBarState.TitleText = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleWonderVacation"), FText::AsNumber(Level));
			InOutNaviBarState.TopBarType = ETopBarType::None;
			InOutNaviBarState.bBottomBarVisible = false;
			break;
		case EWonderCategory::AlchemyLab:
			InOutNaviBarState.TitleText = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleWonderAlchemyLab"), FText::AsNumber(Level));
			InOutNaviBarState.TopBarType = ETopBarType::None;
			InOutNaviBarState.bBottomBarVisible = false;
			break;
		case EWonderCategory::MigriumRefinery:
			InOutNaviBarState.TitleText = FText::Format(Q6Util::GetLocalizedText("Lobby", "TitleWonderMigriumRefinery"), FText::AsNumber(Level));
			InOutNaviBarState.TopBarType = ETopBarType::None;
			InOutNaviBarState.bBottomBarVisible = false;
			break;
		default:
			InOutNaviBarState.bBottomBarVisible = false;
			InOutNaviBarState.bBackVisible = true;
			break;
	}
}

bool FWonderUIState::GotoBackState()
{
	if (Category != EWonderCategory::Main)
	{
		Category = EWonderCategory::Main;
		return true;
	}

	return false;
}

void FRaidUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "Raid"));
}

void FBondUpResultUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.SetNaviBarState(FText::GetEmpty(), ETopBarType::None, false, false);
}

void FCodexUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (bEquipFullView)
	{
		InOutNaviBarState.SetNaviBarState(FText::GetEmpty(), ETopBarType::None, false, false);
		return;
	}

	FText TitleText;
	switch (CodexCategory)
	{
		case ECodexCategory::CodexCharacter:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleCodexCharacter");
			break;
		case ECodexCategory::CodexSculpture:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleCodexSculpture");
			break;
		case ECodexCategory::CodexRelic:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleCodexRelic");
			break;
		default:
			check(false);
			break;
	}

	InOutNaviBarState.SetNaviBarState(TitleText, ETopBarType::Default, true, false);
}

void FWeeklyMissionUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "WeeklyMission")
		, ETopBarType::Default
		, true
		, false);
}

void FShopUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	FText TitleText;
	bool bBackButtonVisible = true;
	bool bBottomBarVisible = false;
	ETopBarType TopBarType = ETopBarType::None;

	switch (ShopMenu)
	{
		case EShopMenu::Lumicube:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleLumicubeShop");
			break;
		case EShopMenu::DiskCharacter:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleDiskExchangeCharacter");
			break;
		case EShopMenu::DiskSculpture:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleDiskExchangeSculpture");
			break;
		case EShopMenu::DiskRelic:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleDiskExchangeRelic");
			break;
		case EShopMenu::Gem:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleGemShop");
			break;
		case EShopMenu::Sell:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleSellCharacter");
			break;
		case EShopMenu::None:
			TitleText = Q6Util::GetLocalizedText("Lobby", "TitleShop");
			bBackButtonVisible = false;
			bBottomBarVisible = true;
			TopBarType = ETopBarType::Default;
			break;
		default:
			break;
	}

	InOutNaviBarState.SetNaviBarState(TitleText, TopBarType, bBottomBarVisible, bBackButtonVisible);
}

void FBagUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Lobby", "Item");
	InOutNaviBarState.bBackVisible = false;
}

void FAccountUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Lobby", "Account");
	InOutNaviBarState.bBackVisible = false;
}

void FEventUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	switch (EventMenu)
	{
		case EEventMenu::Main:
		case EEventMenu::Stage:	// fall through
		{
			const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
			switch (EventContentRow.Category)
			{
				case EEventContentCategory::Collabo01:
					break;
				case EEventContentCategory::ValentineDay:
					InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Event", "ValentineTitle");
					break;
				case EEventContentCategory::MultiSideBattle:
					InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Event", "MultisideTitle");
					break;
				default:
					Q6JsonLogGunny(Error, "FEventUIState::GetNaviBarState", Q6KV("StageCategory", (int32)EventContentRow.Category));
					break;
			}

			InOutNaviBarState.bBottomBarVisible = true;
			InOutNaviBarState.TopBarType = ETopBarType::Default;
			break;
		}
		case EEventMenu::Shop:
		{
			const FCMSEventContentRow& EventContentRow = GetCMS()->GetEventContentRowOrDummy(EventContentType);
			switch (EventContentRow.Category)
			{
				case EEventContentCategory::Collabo01:
					break;
				case EEventContentCategory::ValentineDay:
					InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Event", "ValentineShop");
					break;
				case EEventContentCategory::MultiSideBattle:
					InOutNaviBarState.TitleText = Q6Util::GetLocalizedText("Event", "MultisideShop");
					break;
				default:
					Q6JsonLogGunny(Error, "FEventUIState::GetNaviBarState", Q6KV("ShopCategory", (int32)EventContentRow.Category));
					break;
			}

			InOutNaviBarState.bBottomBarVisible = false;
			InOutNaviBarState.TopBarType = ETopBarType::None;
			break;
		}
	}
}

void FStoryUIState::GetNaviBarState(FNaviBarState& InOutNaviBarState) const
{
	GetDefaultNaviBar(InOutNaviBarState);

	if (MenuType == EStoryMenuType::Main)
	{
		InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleStoryReplay"));
	}
	else
	{
		switch (Category)
		{
			case EStoryMenuCategory::DailyDungeon:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleStoryDailyDungeon"));
				break;
			case EStoryMenuCategory::TrainingCenter:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleStoryTrainingCenter"));
				break;
			case EStoryMenuCategory::Raid:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleStoryRaid"));
				break;
			case EStoryMenuCategory::Event:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleStoryEvent"));
				break;
			case EStoryMenuCategory::Movie:
				InOutNaviBarState.SetNaviBarState(Q6Util::GetLocalizedText("Lobby", "TitleStoryMovie"));
				break;
		}
	}
}
