// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "SummonHUD.h"

#include "Q6.h"
#include "Q6GameInstance.h"

#include "SummonWidgets.h"
#include "SummonHUDWidget.h"
#include "Q6SummonGameMode.h"

ASummonHUD::ASummonHUD()
{
}

void ASummonHUD::BeginPlay()
{
	Super::BeginPlay();

	CreateWidgets();
}

void ASummonHUD::CreateWidgets()
{
	AQ6SummonGameMode* GameMode = Cast<AQ6SummonGameMode>(GetWorld()->GetAuthGameMode());
	if (!GameMode)
	{
		Q6JsonLogZagal(Warning, "ASummonHUD::CreateWidgets - No GameMode!");
		return;
	}

	if (CreateWidgetIfNotCreated(&HUDWidget, SummonHUDWidgetClass))
	{
		HUDWidget->AddToViewport(ZORDER_HUDWIDGET);

		HUDWidget->MoveToNextDelegate.BindUObject(GameMode, &AQ6SummonGameMode::OnMoveToNext);
		HUDWidget->SkipDelegate.BindUObject(GameMode, &AQ6SummonGameMode::OnSkip);
		HUDWidget->InteractionDelegate.BindUObject(GameMode, &AQ6SummonGameMode::OnInteraction);
	}

	if (CreateWidgetIfNotCreated(&ResultWidget, SummonResultWidgetClass))
	{
		ResultWidget->OnBackDelegate.BindUObject(GameMode, &AQ6SummonGameMode::OnBack);
	}
}

void ASummonHUD::InteractionReady()
{
	HUDWidget->InterationReady();
}

void ASummonHUD::SetSummonInfo(const FSummonInfo& Info, const FSimpleDelegate& EndDelegate)
{
	HUDWidget->SetSummonInfo(Info, EndDelegate);
}

void ASummonHUD::MoveToNextSummonInfo()
{
	HUDWidget->MoveToNextSummonInfo();
}

void ASummonHUD::HideSummonInfo()
{
	HUDWidget->HideSummonInfo();
}

void ASummonHUD::ShowResultWidget()
{
	ResultWidget->AddToViewport(ZORDER_HUDWIDGET + 1);
	ResultWidget->SetSummonResult();
}

void ASummonHUD::HideResultWidget()
{
	ResultWidget->RemoveFromViewport();
}

void ASummonHUD::ShowSkipButton(bool bShow)
{
	HUDWidget->ShowSkipButton(bShow);
}