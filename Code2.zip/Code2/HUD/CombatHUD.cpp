// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CombatHUD.h"

#include "SystemConst_gen.h"
#include "Camera/CameraLayerActor.h"
#include "CCEvent.h"
#include "CombatHUDWidget.h"
#include "CombatPlayerController.h"
#include "CombatPresenter.h"
#include "CombatTextWidget.h"
#include "CombatWidgets.h"
#include "CommonWidgets.h"
#include "CPInstances.h"
#include "DebugWidgets.h"
#include "FriendWidgets.h"
#include "GameResource.h"
#include "HUDStore/UserRecordManager.h"
#include "LevelUtil.h"
#include "LobbyObj_gen.h"
#include "PopupWidgets.h"
#include "Q6.h"
#include "Q6ClientNetwork.h"
#include "Q6CombatGameMode.h"
#include "Q6GameInstance.h"
#include "Q6GameState.h"
#include "Q6Log.h"
#include "RaidManager.h"
#include "RewardManager.h"
#include "SkillWidgets.h"
#include "Tutorial/CombatTutorial.h"
#include "Unit.h"
#include "WidgetUtil.h"
#include "DropBox.h"

ACombatHUD::ACombatHUD(const FObjectInitializer& ObjectInitializer)
	: bUltimateSkillNoSkip(false)
	, bHasItemDrop(false)
	, WaveIndex(0)
{
	bDesiredSilentReconnect = true;

	PrimaryActorTick.bTickEvenWhenPaused = true;
}

void ACombatHUD::BeginPlay()
{
	Super::BeginPlay();

	SkillUsedUnitId = CCUnitIdInvalid;
	UsedSkillType = SkillTypeInvalid.x;

	DamageTextWidgets.Reserve(MAX_COMMON_COMBAT_TEXT_POOL_SIZE);
	for (int32 i = 0; i < MAX_COMMON_COMBAT_TEXT_POOL_SIZE; ++i)
	{
		UCombatDamageTextWidget* Widget = CreateWidget<UCombatDamageTextWidget>(PlayerOwner, DamageTextWidgetClass);
		ensure(Widget);
		DamageTextWidgets.Add(Widget);
	}

	AllyUnitNoticeListWidgets.Reserve(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
	AllyUnitStateNoticeListWidgets.Reserve(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
	AllyUnitApplyEffectLabelListWidgets.Reserve(CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT);
	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_SPAWNED_ALLY_UNIT; ++i)
	{
		UCombatUnitNoticeListWidget* UnitNoticeListWidget = CreateWidget<UCombatUnitNoticeListWidget>(PlayerOwner, UnitNoticeListWidgetClass);
		ensure(UnitNoticeListWidget);
		UnitNoticeListWidget->OnNotificationFinishedDelegate.BindUObject(this, &ACombatHUD::OnUnitNoticeAnimFinished);
		AllyUnitNoticeListWidgets.Add(UnitNoticeListWidget);

		UCombatUnitStateNoticeListWidget* UnitStateNoticeListWidget = CreateWidget<UCombatUnitStateNoticeListWidget>(PlayerOwner, UnitStateNoticeListWidgetClass);
		ensure(UnitStateNoticeListWidget);
		UnitStateNoticeListWidget->OnNotificationStartDelegate.BindUObject(this, &ACombatHUD::OnUnitStateNoticeStartNext);
		UnitStateNoticeListWidget->OnNotificationFinishedDelegate.BindUObject(this, &ACombatHUD::OnUnitNoticeAnimFinished);
		AllyUnitStateNoticeListWidgets.Add(UnitStateNoticeListWidget);

		UCombatUnitApplyEffectLabelListWidget* UnitApplyEffectLabelListWidget = CreateWidget<UCombatUnitApplyEffectLabelListWidget>(PlayerOwner, UCombatUnitApplyEffectLabelListWidgetClass);
		ensure(UnitApplyEffectLabelListWidget);
		AllyUnitApplyEffectLabelListWidgets.Add(UnitApplyEffectLabelListWidget);
	}

	EnemyUnitNoticeListWidgets.Reserve(CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT);
	EnemyUnitStateNoticeListWidgets.Reserve(CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT);
	EnemyUnitApplyEffectLabelListWidgets.Reserve(CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT);
	for (int32 i = 0; i < CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT; ++i)
	{
		UCombatUnitNoticeListWidget* UnitNoticeListWidget = CreateWidget<UCombatUnitNoticeListWidget>(PlayerOwner, UnitNoticeListWidgetClass);
		ensure(UnitNoticeListWidget);
		UnitNoticeListWidget->OnNotificationFinishedDelegate.BindUObject(this, &ACombatHUD::OnUnitNoticeAnimFinished);
		EnemyUnitNoticeListWidgets.Add(UnitNoticeListWidget);

		UCombatUnitStateNoticeListWidget* UnitStateNoticeListWidget = CreateWidget<UCombatUnitStateNoticeListWidget>(PlayerOwner, UnitStateNoticeListWidgetClass);
		ensure(UnitStateNoticeListWidget);
		UnitStateNoticeListWidget->OnNotificationStartDelegate.BindUObject(this, &ACombatHUD::OnUnitStateNoticeStartNext);
		UnitStateNoticeListWidget->OnNotificationFinishedDelegate.BindUObject(this, &ACombatHUD::OnUnitNoticeAnimFinished);
		EnemyUnitStateNoticeListWidgets.Add(UnitStateNoticeListWidget);

		UCombatUnitApplyEffectLabelListWidget* UnitApplyEffectLabelListWidget = CreateWidget<UCombatUnitApplyEffectLabelListWidget>(PlayerOwner, UCombatUnitApplyEffectLabelListWidgetClass);
		ensure(UnitApplyEffectLabelListWidget);
		EnemyUnitApplyEffectLabelListWidgets.Add(UnitApplyEffectLabelListWidget);
	}

	TutorialButtonClickDelegate.BindUObject(this, &ACombatHUD::TutorialButtonClick);
	CombatTutorial = GetWorld()->SpawnActor<ACombatTutorial>(CombatTutorialClass);
}

void ACombatHUD::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

#if !UE_BUILD_SHIPPING
	UpdateCombatPresenterDebugState();
#endif

	UpdateProgressBar(DeltaTime);
	UpdateSkillGaugeProgressBar(DeltaTime);
}

void ACombatHUD::SetWidgetsVisible(bool bInVisible)
{
	Super::SetWidgetsVisible(bInVisible);

	if (CombatHUDWidget)
	{
		CombatHUDWidget->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}
}

void ACombatHUD::AddProgressTask(UProgressBar* Obj, float InTarget, float InLength,
	FSimpleDelegate InCBStart, FSimpleDelegate InCBEnd, FFloatParamDelegate InCBUpdate)
{
	auto FindIndex = ProgressTasks.IndexOfByPredicate([Obj](const FProgressUpdateTask& Info) {
		return Info.WeakObj == Obj;
	});
	if (FindIndex != INDEX_NONE)
	{
		ProgressTasks.RemoveAt(FindIndex, 1, false);
	}

	InLength = FMath::Clamp(InLength, 0.f, MAX_PROGRESS_TASK_TICK_TIME);
	ProgressTasks.Add(FProgressUpdateTask(Obj, Obj->Percent, InTarget, InLength, InCBStart, InCBEnd, InCBUpdate));
}

void ACombatHUD::UpdateProgressBar(float DeltaTime)
{
	for (int i = ProgressTasks.Num() - 1; i >= 0; --i)
	{
		FProgressUpdateTask& Task = ProgressTasks[i];

		if (!Task.WeakObj->IsValidLowLevelFast())
		{
			Q6JsonLogMild(Warning, "Invalid ProgressBar");
			ProgressTasks.RemoveAtSwap(i, 1, false);
			continue;
		}

		if (FMath::IsNearlyZero(Task.Age, KINDA_SMALL_NUMBER))
		{
			Task.CBStart.ExecuteIfBound();
		}

		Task.Age += DeltaTime;

		if (Task.Age < Task.Length)
		{
			Task.StartPercent = Task.WeakObj->Percent; // continue from prev task.

			float Alpha = FMath::Clamp(Task.Age / Task.Length, 0.f, 1.f);
			float NewPercent = FMath::Lerp(Task.StartPercent, Task.EndPercent, Alpha);
			Task.WeakObj->SetPercent(NewPercent);
			Task.CBUpdate.ExecuteIfBound(NewPercent);
		}
		else
		{
			Task.WeakObj->SetPercent(Task.EndPercent);
			Task.CBEnd.ExecuteIfBound();
			ProgressTasks.RemoveAtSwap(i, 1, false);
		}
	}
}

void ACombatHUD::AddSkillGaugeProgressSerialTask(const FSkillGaugeProgressUpdateTask& Task)
{
	SkillGaugeProgressTasks.Add(Task);
}

void ACombatHUD::UpdateSkillGaugeProgressBar(float DeltaTime)
{
	// skill gauge progress task need to preserve order
	int32 Index = 0;
	while (SkillGaugeProgressTasks.IsValidIndex(Index))
	{
		FSkillGaugeProgressUpdateTask& Task = SkillGaugeProgressTasks[Index];

		if (!Task.WeakObj->IsValidLowLevelFast())
		{
			Q6JsonLogSunny(Warning, "Invalid SkillGaugeBar");
			SkillGaugeProgressTasks.RemoveAt(Index, 1, false);
			continue;
		}

		if (FMath::IsNearlyZero(Task.Age, KINDA_SMALL_NUMBER))
		{
			Task.CBStart.ExecuteIfBound();
		}

		Task.Age += DeltaTime;

		if (Task.Age < Task.Length)
		{
			Task.StartPercent = Task.WeakObj->Percent; // continue from prev task.

			float Alpha = FMath::Clamp(Task.Age / Task.Length, 0.f, 1.f);
			float NewPercent = FMath::Lerp(Task.StartPercent, Task.EndPercent, Alpha);
			Task.WeakObj->SetPercent(NewPercent);
			Task.CBUpdate.ExecuteIfBound(NewPercent);
			++Index;
		}
		else
		{
			Task.WeakObj->SetPercent(Task.EndPercent);
			Task.CBEnd.ExecuteIfBound();
			SkillGaugeProgressTasks.RemoveAt(Index, 1, false);
		}
	}
}

void ACombatHUD::SetItemDropInfo()
{
	DropBoxes.Empty();
	DropCurrencies.Empty();

	bHasItemDrop = false;

	TArray<int32> DeadUnitSlots = GetCheckedCombatPresenter(this)->FindDeadUnitSlotsByFaction(ECCFaction::Enemy);
	if (WaveIndex == 0 && DeadUnitSlots.Num() == 0)
	{
		return;
	}

	const TArray<FItemDropInfo>& ItemDropInfos = GetCheckedCombatPresenter(this)->GetItemDropInfo();
	GatherItemDropInfos(ItemDropInfos, DeadUnitSlots);

	const TArray<FItemDropInfo>& RandomSpawnItemDropInfos = GetCheckedCombatPresenter(this)->GetRandomSpawnItemDropInfo();
	GatherItemDropInfos(RandomSpawnItemDropInfos, DeadUnitSlots);
}

void ACombatHUD::RefreshEnemyBarWidget(FCCUnitId InUnitId)
{
	CombatHUDWidget->RefreshEnemyUltimateSkills(InUnitId);
}

ABaseTutorial* ACombatHUD::GetTutorial()
{
	return CombatTutorial;
}

ACombatTutorial* ACombatHUD::GetCombatTutorial()
{
	return CombatTutorial;
}

bool ACombatHUD::IsShowProvokedEnemyBar() const
{
	if (CombatHUDWidget)
	{
		return CombatHUDWidget->IsShowProvokedEnemyBar();
	}

	return false;
}

void ACombatHUD::SelectTarget(FCCUnitId InUnitId)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->SelectTarget(InUnitId);
	}
}

void ACombatHUD::TutorialButtonClick(FString InSource)
{
	CombatTutorial->TutorialButtonClick(InSource);
}

void ACombatHUD::GatherItemDropInfos(const TArray<FItemDropInfo>& ItemDropInfos, const TArray<int32>& InDeadUnitSlots)
{
	TMap<int32, int32> TotalDropBoxes;
	int32 TotalGainGold = 0;

	for (const FItemDropInfo& ItemDropInfo : ItemDropInfos)
	{
		if (ItemDropInfo.WaveIndex < WaveIndex
			|| (ItemDropInfo.WaveIndex == WaveIndex && InDeadUnitSlots.Contains(ItemDropInfo.Slot)))
		{
			for (const auto& DropBox : ItemDropInfo.DropBoxes)
			{
				int32* FoundDropBox = TotalDropBoxes.Find(DropBox.Key);
				if (!FoundDropBox)
				{
					TotalDropBoxes.Add(DropBox.Key, DropBox.Value);
				}
				else
				{
					*FoundDropBox += DropBox.Value;
				}
			}

			TotalGainGold += ItemDropInfo.GainGold;
		}

		if (ItemDropInfo.WaveIndex > WaveIndex)
		{
			break;
		}
	}

	// sorted by grade
	TotalDropBoxes.KeySort([](int32 Key1, int32 Key2) {
		return Key1 > Key2;
	});

	if (TotalDropBoxes.Num() > 0)
	{
		for (const auto& Box : TotalDropBoxes)
		{
			FDropBox DropBox;
			DropBox.RewardType = ESagaRewardType::Clear;
			DropBox.Grade = (EDropBoxType)Box.Key;
			DropBox.Count = Box.Value;
			DropBoxes.Emplace(DropBox);
		}

		bHasItemDrop = true;
	}

	if (TotalGainGold > 0)
	{
		// Clear reward shows gold only
		FDropCurrency DropCurrency;
		DropCurrency.RewardType = ESagaRewardType::Clear;
		DropCurrency.Type = ECurrencyType::Gold;
		DropCurrency.Count = TotalGainGold;
		DropCurrencies.Emplace(DropCurrency);

		bHasItemDrop = true;
	}
}

void ACombatHUD::CreateDebugWidget()
{
#if !UE_BUILD_SHIPPING
	if (!DebugCombatWidget)
	{
		if (CreateWidgetIfNotCreated(&DebugCombatWidget, DebugCombatWidgetClass))
		{
			DebugCombatWidget->AddToViewport(ZORDER_DEBUG);
		}
	}
#endif
}

void ACombatHUD::ToggleDebugWidget()
{
#if !UE_BUILD_SHIPPING
	if (!DebugCombatWidget)
	{
		CreateDebugWidget();
		DebugCombatWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
		return;
	}

	DebugCombatWidget->IsVisible() ? DebugCombatWidget->SetVisibility(ESlateVisibility::Collapsed) : DebugCombatWidget->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
#endif
}

void ACombatHUD::ToggleNoDamage()
{
#if !UE_BUILD_SHIPPING
	if (DebugCombatWidget)
	{
		DebugCombatWidget->ToggleNoDamage();
	}
#endif
}

void ACombatHUD::ToggleImmune()
{
#if !UE_BUILD_SHIPPING
	if (DebugCombatWidget)
	{
		DebugCombatWidget->ToggleImmune();
	}
#endif
}

void ACombatHUD::UpdateCombatPresenterDebugState()
{
#if !UE_BUILD_SHIPPING
	if (!DebugCombatWidget)
	{
		return;
	}

	AQ6CombatGameMode* GameMode = GetCombatGameMode(this);
	if (!GameMode)
	{
		return;
	}

	check(GameMode->Presenter);
	GameMode->Presenter->UpdateDebugState(DebugCombatWidget);
#endif
}

void ACombatHUD::OnReportError(const UCCReportErrorEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnReportError(Event);
	}
}

void ACombatHUD::OnStartGame(const UCCStartGameEvent* Event)
{
	if (Event->CombatSeed.Content == EContentType::Raid)
	{
		SetSilentReconnect(true);
	}

	if (ResultWidget)
	{
		ResultWidget->RemoveFromParent();
	}

	if (CreateHUDWidgetAndBindEvents())
	{
		CombatHUDWidget->OnStartGame(Event);
	}
}

bool ACombatHUD::CreateHUDWidgetAndBindEvents()
{
	Q6SetStringToFirebaseCrashlytics("Widget", "Combat");

	if (!CreateWidgetIfNotCreated(&CombatHUDWidget, CombatHUDWidgetClass))
	{
		Q6JsonLogBro(Error, "Create CombatHUDWidget failed");
		return false;
	}

	CombatHUDWidget->AddToViewport(ZORDER_HUDWIDGET);
	CombatHUDWidget->OnSpawnAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnSpawnAnimFinished);
	CombatHUDWidget->OnSkillStartAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnSkillStartAnimFinished);
	CombatHUDWidget->OnStartTurnPhaseAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnStartTurnPhaseAnimFinished);
	CombatHUDWidget->OnEnemyUltimateReadyAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnEnemyUltimateReadyAnimFinished);
	CombatHUDWidget->OnRaidAssistStartAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnRaidAssistStartAnimFinished);
	CombatHUDWidget->OnSkillFailedAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnSkillFailedAnimFinished);
	return true;
}

void ACombatHUD::OnStartWave(const UCCStartWaveEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnStartWave(Event);
	}

	WaveIndex = Event->WaveIndex;
}

void ACombatHUD::OnTakeTurn(const UCCTakeTurnEvent* Event)
{
	// temporary direction
	const AUnit* U = GetCheckedCombatPresenter(this)->FindUnit(Event->TurnUnitId);
	if (U->GetOverrideFaction() == ECCFaction::Ally)
	{
		CombatHUDWidget->OnAllyBarClicked(Event->TurnUnitId, 0);
	}
	else
	{
		CombatHUDWidget->OnEnemyBarClicked(Event->TurnUnitId);
	}
}

void ACombatHUD::OnStartTurn(const UCCStartTurnEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnStartTurn(Event);
	}
}

void ACombatHUD::OnStartPhase(const UCCStartPhaseEvent* Event)
{
	// Attack Phase not enter this function.

	SupporterBonus = 0;
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnStartPhase(Event);
	}
}

void ACombatHUD::OnEnemyUltimateReady(const AUnit* EnemyUnit)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnEnemyUltimateReady(EnemyUnit);
	}
}

void ACombatHUD::OnPrepareTurnSkillPhase()
{
	const ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);

	EContentType Content = CombatPresenter->GetCombatSeed().Content;
	if (Content == EContentType::Raid
		&& CombatPresenter->GetTurnCount() > CombatCubeConst::Q6_FIRST_TURN)
	{
		GetCheckedCombatCube(this)->UseRaidTurnSkills();
	}
	else
	{
		OnStartTurnSkillPhase();
	}
}

void ACombatHUD::OnStartTurnSkillPhase()
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnStartCPPhase(ECPTurnPhase::TurnSkill);
	}
}

void ACombatHUD::OnSpawnUnit(const UCCSpawnUnitEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSpawnUnit(Event);
	}
}

void ACombatHUD::OnDespawnUnit(const UCCDespawnUnitEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnDespawnUnit(Event);
	}
}

void ACombatHUD::OnSkillPass(const TArray<FCCUnitId>& PhasePassUnitIds)
{
	for (const FCCUnitId& UnitId : PhasePassUnitIds)
	{
		CombatHUDWidget->OnPhasePass(UnitId);
	}
}

void ACombatHUD::OnSkillUsed(const UCCSkillUsedEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSkillUsed(Event);
	}
}

void ACombatHUD::OnSkillFailed(const UCCSkillFailedEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSkillFailed(Event);
	}
}

void ACombatHUD::OnSkillStart(const UCCSkillUsedEvent* Event)
{
	SkillUsedUnitId = Event->UnitId;
	UsedSkillType = Event->SkillType;

	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSkillStart(Event);
	}
}

void ACombatHUD::OnSkillEnd(FCCUnitId SourceUnitId, ESkillCategory SkillCategory, bool bInPattern)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSkillEnd(SourceUnitId, SkillCategory, bInPattern);
	}
}

void ACombatHUD::OnSkillDrivenEffectEnd()
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSkillDrivenEffectEnd();
	}

	// to clear on CPInstance timeout
	ResetUnitNoticeCaches();
}

void ACombatHUD::OnUltimateSkillSequenceStarted(bool bNoSkip)
{
	bUltimateSkillNoSkip = bNoSkip;

	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnUltimateSkillSequenceStarted();
	}
}

void ACombatHUD::OnUltimateSkillSequenceFinished()
{
	ShowUltimateSkipWidget(false);

	if (UltimateSkillAnimWidget)
	{
		UltimateSkillAnimWidget->StopSkillAnimation();
	}

	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnUltimateSkillSequenceFinished();
	}
}

void ACombatHUD::OnSelectTarget(const FCCUnitId UnitId)
{
#if !UE_BUILD_SHIPPING
	if (!DebugCombatWidget)
	{
		CreateDebugWidget();
		DebugCombatWidget->SetVisibility(ESlateVisibility::Collapsed);
	}

	DebugCombatWidget->OnTargetSelected();
#endif

	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSelectTarget(UnitId);
	}
}

void ACombatHUD::OnHealthChanged(const UCCUnitHealthChangedEvent* Event)
{
	FCCUnitId TargetUnitId = Event->UnitId;
	int32 AddedHealth = Event->AddedHealth;
	EHealthChangeReason Reason = Event->Reason;

	SpawnCombatText(TargetUnitId, ENatureRelationType::Normal, AddedHealth, 0, Reason, false, false, false, false, false);

	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnHealthChanged(Event);
	}
}

void ACombatHUD::OnAllyWipeout(const UCCAllyWipeoutEvent* Event)
{
	CreateWidgetIfNotCreated(&WipeoutWidget, WipeoutWidgetClass);
	if (!WipeoutWidget)
	{
		Q6JsonLogGunny(Warning, "ACombatHUD::OnAllyWipeout - WipeoutWidget was not created.");
		return;
	}

	WipeoutWidget->AddToViewport(ZORDER_HUDWIDGET);
	WipeoutWidget->SetWipeout();
}

void ACombatHUD::OnEndGame(const UCCEndGameEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->RemoveFromParent();
	}

	FCombatMissionInfo CombatMissionInfo = GetCombatMissionInfo();
	EContentType ContentType = Event->ContentType;

	if (Event->Result == ECCResult::Win)
	{
		UQ6GameInstance::Get(this)->RequestEndStage(Event, CombatMissionInfo);

		CreateWidgetIfNotCreated(&ResultWidget, CombatResultWidgetClass);
		if (!ResultWidget)
		{
			Q6JsonLogGunny(Warning, "ACombatHUD::OnEndGame - ResultWidget was not created.");
			return;
		}

		ResultWidget->AddToViewport(ZORDER_HUDWIDGET);
		ResultWidget->SetResult(ContentType, Event->Result);

		// ClearUnits is not fail reason
		if (Event->EndReason != ECCEndReason::None && Event->EndReason != ECCEndReason::ClearUnits)
		{
			ResultWidget->SetFailedResult(ContentType, Event->EndReason, Event->Result);
		}
		else
		{
			ResultWidget->OnWinAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnWinAnimFinished);
		}

		ResultWidget->OnCloseWidgetDelegate.BindUObject(this, &ACombatHUD::OnResultWidgetClosed);
	}
	else
	{
		if (Event->EndReason != ECCEndReason::None)
		{
			UQ6GameInstance::Get(this)->RequestEndStage(Event, CombatMissionInfo);

			// withdraw - go to menu directly without result widget.
			if (Event->EndReason == ECCEndReason::Withdraw)
			{
				if (ContentType != EContentType::Raid)
				{
					ULevelUtil::LoadLobbyLevel(GetWorld());
				}

				return;
			}

			if (WipeoutWidget && WipeoutWidget->IsInViewport())
			{
				WipeoutWidget->RemoveFromParent();
			}

			CreateWidgetIfNotCreated(&ResultWidget, CombatResultWidgetClass);
			if (!ResultWidget)
			{
				Q6JsonLogGunny(Warning, "ACombatHUD::OnEndGame - ResultWidget was not created.");
				return;
			}

			ResultWidget->AddToViewport(ZORDER_HUDWIDGET);
			ResultWidget->SetFailedResult(ContentType, Event->EndReason, Event->Result);
		}
		else
		{
			ensure(0);
		}
	}
}

void ACombatHUD::OnBoneDragonEndGame(const UCCEndGameEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->RemoveFromParent();
	}

	FCombatMissionInfo CombatMissionInfo = GetCombatMissionInfo();
	UQ6GameInstance::Get(this)->RequestEndStage(Event, CombatMissionInfo);
}

void ACombatHUD::OnUAChanged(const UCCUnitUAChangedEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnUAChanged(Event);
	}
}

void ACombatHUD::OnSAChanged(const UCCUnitSAChangedEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSAChanged(Event);
	}
}

void ACombatHUD::OnOverKillChanged(const UCCUnitOverKillChangedEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnOverKillChanged(Event);
	}
}

void ACombatHUD::AddOverKill(FCCUnitId InUnitId, int32 InValue)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->AddOverKill(InUnitId, InValue);
	}
}

void ACombatHUD::OnSetSkillCooldown(const UCCSetSkillTimeEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSetSkillCooldown(Event);
	}
}

void ACombatHUD::OnSetCheatSkillCooldown(const UCCSetCheatSkillCooldownEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnSetCheatSkillCooldown(Event);
	}
}

static FText _GetConsumeValueText(EPointVaryConsumeType ConsumeType, int32 Value)
{
	switch (ConsumeType)
	{
		case EPointVaryConsumeType::UA:
		case EPointVaryConsumeType::SA:
			return FText::AsPercent(Value / 100.f);
		default:
			break;
	}

	return FText::AsNumber(Value);
}

void ACombatHUD::OnPointChanged(FCCUnitId UnitId, EPointVaryConsumeType PointType, int32 Value)
{
	FString PointTypeKeyStr = ENUM_TO_STRING(EPointVaryConsumeType, PointType);
	const FText& ValueText = _GetConsumeValueText(PointType, FMath::Abs(Value));
	EPointVaryState PointVaryState = Value < 0 ? EPointVaryState::Consume : EPointVaryState::Convert;
	SpawnUnitPointNotice(UnitId, PointVaryState, PointTypeKeyStr, ValueText, false);
}

void ACombatHUD::OnImmediateKill(FCCUnitId UnitId)
{
	SpawnUnitImmediateKillNotice(UnitId);
}

void ACombatHUD::OnSkillTimeChanged(FCCUnitId UnitId, ESetSkillTimeType SetSkillTimeType, int32 Value)
{
	SpawnUnitSkillTimeNotice(UnitId, SetSkillTimeType, Value);
}

void ACombatHUD::OnPointVaryConsume(FCCUnitId UnitId, EPointVaryConsumeType ConsumeType, int32 Value)
{
	FString ConsumeTypeKeyStr = ENUM_TO_STRING(EPointVaryConsumeType, ConsumeType);
	const FText& ValueText = _GetConsumeValueText(ConsumeType, FMath::Abs(Value));
	SpawnUnitPointNotice(UnitId, EPointVaryState::Consume, ConsumeTypeKeyStr, ValueText, false);
}

FString ACombatHUD::GetConvertTypeKeyString(EPointVaryConvertType ConvertType)
{
	switch (ConvertType)
	{
		case EPointVaryConvertType::AtkVaryper:
			ConvertType = EPointVaryConvertType::AtkVary;
			break;
		case EPointVaryConvertType::DefVaryper:
			ConvertType = EPointVaryConvertType::DefVary;
			break;
		case EPointVaryConvertType::UltimateVaryper:
			ConvertType = EPointVaryConvertType::UltimateVary;
			break;
		case EPointVaryConvertType::DamageVaryper:
			ConvertType = EPointVaryConvertType::DamageVary;
			break;
		case EPointVaryConvertType::HealVaryper:
			ConvertType = EPointVaryConvertType::HealVary;
			break;
		default:
			break;
	}

	return ENUM_TO_STRING(EPointVaryConvertType, ConvertType);
}

FText ACombatHUD::GetConvertValueText(EPointVaryConvertType ConvertType, int32 Value)
{
	switch (ConvertType)
	{
		case EPointVaryConvertType::UA:
		case EPointVaryConvertType::SA:
			return FText::AsPercent(Value / 100.f);
		case EPointVaryConvertType::AtkVaryper:
		case EPointVaryConvertType::DefVaryper:
		case EPointVaryConvertType::CriVaryper:
		case EPointVaryConvertType::CriDamVaryper:
		case EPointVaryConvertType::UltimateVaryper:
		case EPointVaryConvertType::DamageVaryper:
		case EPointVaryConvertType::HealVaryper:
			return FText::AsPercent(Value / 1000.f);
		default:
			break;
	}

	return FText::AsNumber(Value);
}

static bool _IsUnitAttributeConvertType(EPointVaryConvertType ConvertType)
{
	switch (ConvertType)
	{
		case EPointVaryConvertType::AtkVary:
		case EPointVaryConvertType::AtkVaryper:
		case EPointVaryConvertType::DefVary:
		case EPointVaryConvertType::DefVaryper:
		case EPointVaryConvertType::CriVaryper:
		case EPointVaryConvertType::CriDamVaryper:
		case EPointVaryConvertType::UltimateVary:
		case EPointVaryConvertType::UltimateVaryper:
		case EPointVaryConvertType::DamageVary:
		case EPointVaryConvertType::DamageVaryper:
		case EPointVaryConvertType::HealVary:
		case EPointVaryConvertType::HealVaryper:
			return true;
		default:
			return false;
	}
}

void ACombatHUD::OnPointVaryConvert(FCCUnitId UnitId, EPointVaryConvertType ConvertType, int32 Value)
{
	static_assert(EPointVaryConvertTypeMax == 16, "need more convert type.");

	const FString& ConvertTypeKeyStr = GetConvertTypeKeyString(ConvertType);
	const FText& ValueText = GetConvertValueText(ConvertType, Value);
	SpawnUnitPointNotice(UnitId, EPointVaryState::Convert, ConvertTypeKeyStr, ValueText, _IsUnitAttributeConvertType(ConvertType));
}

void ACombatHUD::OnCreateBuff(const UCCCreateBuffEvent* Event, bool bSkipUnitNotice, bool bSkipUnitBar)
{
	if (!bSkipUnitBar && CombatHUDWidget)
	{
		CombatHUDWidget->OnCreateBuff(Event, !bSkipUnitNotice);
	}

	if (!bSkipUnitNotice)
	{
		SpawnUnitBuffNotices(EBuffNoticeType::AddBuff, Event->TargetUnitId, FBuffType(Event->BuffType), Event->BuffLevel, Event->BornCategory);
	}
}

void ACombatHUD::OnRemoveBuff(const UCCRemoveBuffEvent* Event, const FBuffType& BuffType, bool bSkipUnitNotice)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnRemoveBuff(Event, BuffType);
	}

	for (const FCCUnitId& UnitId : Event->UnitIds)
	{
		AUnit* TargetUnit = GetCheckedCombatPresenter(this)->FindUnit(UnitId);
		if (TargetUnit)
		{
			if (!bSkipUnitNotice && !TargetUnit->IsDead())
			{
				SpawnUnitBuffNotices(EBuffNoticeType::RemoveBuff, UnitId, BuffType);
			}
		}
	}
}

void ACombatHUD::OnRemoveBuffFailed(const UCCRemoveBuffFailedEvent* Event, bool bSkipUnitNotice)
{
	if (!bSkipUnitNotice)
	{
		SpawnUnitRemoveBuffFailedNotice(Event->UnitId, Event->Reason, Event->NoApplyTag);
	}
}

void ACombatHUD::OnImmuneBuff(const UCCImmuneBuffEvent* Event, bool bSkipUnitNotice)
{
	if (!bSkipUnitNotice)
	{
		SpawnUnitImmuneBuffNotice(Event->UnitId, Event->ImmuneTag);
	}
}

void ACombatHUD::OnRaidTurnSkillEffect(const UCCRaidTurnSkillEffectEvent* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnRaidTurnSkillEffect(Event);
	}
}

void ACombatHUD::OnCombatMission(const UCCMissionEvent* Event)
{
	for (const FMissionType& Type : Event->CombatWeeklyMission)
	{
		if (WeeklyCombatMission.Contains(Type))
		{
			++WeeklyCombatMission[Type];
		}
		else
		{
			WeeklyCombatMission.Emplace(Type, 1);
		}
	}

	for (const FCharMissionType& Type : Event->CombatCharacterMission)
	{
		if (CharacterCombatMission.Contains(Type))
		{
			++CharacterCombatMission[Type];
		}
		else
		{
			CharacterCombatMission.Emplace(Type, 1);
		}
	}
}

void ACombatHUD::WarningPatternUltimate(const UCCSelectedPatternUltimate* Event)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->WarningPatternUltimate(Event);
	}
}

void ACombatHUD::OnHit(const UUnitHit* HitPerUnit, bool bIsActiveSkillHit, bool bPassOverTotal)
{
	ENatureRelationType NatureRelationType = HitPerUnit->NatureRelationType;
	FCCUnitId TargetUnitId = HitPerUnit->TargetUnitId;
	EHealthChangeReason Reason = HitPerUnit->Reason;
	bool bDodged = HitPerUnit->bDodged;
	bool bCritical = HitPerUnit->bCritical;

	bool bDamage = HitPerUnit->AddedBaseHealth != 0;
	bool bShieldDamage = HitPerUnit->ShieldDamage != 0;

	if (bShieldDamage)
	{
		ensure(Reason == EHealthChangeReason::Damage);
		SpawnCombatText(TargetUnitId, NatureRelationType, HitPerUnit->ShieldDamage, HitPerUnit->ExtraShieldDamage, Reason, bDodged, bCritical, true, bDamage, bIsActiveSkillHit);

		if (bDamage)
		{
			SpawnCombatText(TargetUnitId, NatureRelationType, HitPerUnit->AddedBaseHealth, HitPerUnit->AddedExtraHealth, Reason, bDodged, bCritical, false, false, bIsActiveSkillHit);
		}
	}
	else
	{
		SpawnCombatText(TargetUnitId, NatureRelationType, HitPerUnit->AddedBaseHealth, HitPerUnit->AddedExtraHealth, Reason, bDodged, bCritical, false, false, bIsActiveSkillHit);
	}

	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnHit(HitPerUnit, bDamage, bShieldDamage, bPassOverTotal);
	}
}

void ACombatHUD::OnDamageBuffHit(const UCCDamageBuffPerUnit* DamageInfo)
{
	const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(DamageInfo->BuffType));
	SpawnUnitStateNotice(DamageInfo->TargetUnitId, FBuffEffectState(FBuffEffectType(DamageInfo->BuffEffectType), BuffRow.Lock));
}

void ACombatHUD::OnHealBuffHit(const UCCHealBuffPerUnit* HealInfo)
{
	if (HealInfo->Reason == EHealthChangeReason::HealBlock)
	{
		AUnit* TargetUnit = GetCheckedCombatPresenter(this)->FindUnit(HealInfo->TargetUnitId);
		if (TargetUnit)
		{
			TArray<FBuffEffectState> HealBlockEffectStates;
			TargetUnit->GatherCCBuffEffects(HealBlockEffectStates, ECrowdControl::HealBlock);
			if (HealBlockEffectStates.Num())
			{
				SpawnUnitStateNotice(HealInfo->TargetUnitId, HealBlockEffectStates[0]);
			}
		}
	}
	else
	{
		const FCMSBuffRow& BuffRow = GetCMS()->GetBuffRowOrDummy(FBuffType(HealInfo->BuffType));
		SpawnUnitStateNotice(HealInfo->TargetUnitId, FBuffEffectState(FBuffEffectType(HealInfo->BuffEffectType), BuffRow.Lock));
	}
}

void ACombatHUD::OnDead(FCCUnitId UnitId)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnDead(UnitId);
	}
}

void ACombatHUD::OnFinishWave()
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->OnFinishWave();
	}
}

void ACombatHUD::CreateSkillAnimWidgetIfNotCreated(USkillAnimationWidget** OutWidget, const TSoftClassPtr<USkillAnimationWidget>& SkillAnimWidgetClass)
{
	if (!SkillAnimWidgetClass.Get())
	{
		SkillAnimWidgetClass.LoadSynchronous();
	}

	for (USkillAnimationWidget* SkillAnimWidget : SkillAnimWidgets)
	{
		if (SkillAnimWidget && (SkillAnimWidget->GetClass() == SkillAnimWidgetClass.Get()))
		{
			*OutWidget = SkillAnimWidget;
			return;
		}
	}

	*OutWidget = CreateWidget<USkillAnimationWidget>(PlayerOwner, SkillAnimWidgetClass.Get());
	check(*OutWidget);

	SkillAnimWidgets.AddUnique(*OutWidget);
}

bool ACombatHUD::PlaySkillAnimation()
{
	if (!CombatHUDWidget)
	{
		Q6JsonLogRoze(Error, "ACombatHUD::PlaySkillAnimationInternal - Where is CombatHUDWidget?");
		OnUltimateSkillAnimFinished();
		return false;
	}

	const AUnit* OwnedUnit = GetCheckedCombatPresenter(this)->FindUnit(SkillUsedUnitId);
	if (!OwnedUnit)
	{
		OnUltimateSkillAnimFinished();
		return false;
	}

	const FUltimateSkillSequenceAssetRow& SkillAssetRow = OwnedUnit->GetUltimateSkillSequenceAssetRow(UsedSkillType);
	if (SkillAssetRow.WidgetAnimationClass.IsNull())
	{
		OnUltimateSkillAnimFinished();
		return false;
	}

	CreateSkillAnimWidgetIfNotCreated(&UltimateSkillAnimWidget, SkillAssetRow.WidgetAnimationClass);
	check(UltimateSkillAnimWidget);

	UCommonSkillAnimationWidget* CommonSkillAnimWidget = Cast<UCommonSkillAnimationWidget>(UltimateSkillAnimWidget);
	if (!CommonSkillAnimWidget || !SkillAssetRow.UnitTexture.IsNull())
	{
		// Customized or illustrated animation
		CombatHUDWidget->OnUltimateSkillIllustAnimStarted();
	}

	UltimateSkillAnimWidget->SkillAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnUltimateSkillAnimFinished);
	UltimateSkillAnimWidget->PlaySkillAnimation(UsedSkillType, SkillAssetRow);
	if (CommonSkillAnimWidget)
	{
		CommonSkillAnimWidget->PlayNatureAnimation(OwnedUnit->GetNature());
	}

	return true;
}

void ACombatHUD::OnUltimateSkillAnimFinished()
{
	++SupporterBonus;

	ShowUltimateSkipWidget(!bUltimateSkillNoSkip);

	OnSkillAnimFinishedDelegate.ExecuteIfBound();

	SkillUsedUnitId = CCUnitIdInvalid;
	UsedSkillType = SkillTypeInvalid.x;
}

bool ACombatHUD::PlaySupportSkillAnims()
{
	if (SkillUsedUnitId == CCUnitIdInvalid)
	{
		return false;
	}

	struct FSupportSkillInfo
	{
		int32 ModelType;
		int32 SkillType;
	};

	TArray<FSupportSkillInfo> SupportSkillInfos;

	ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	TArray<const AUnit*> Supporters = CombatPresenter->GetSupporters(SkillUsedUnitId);

	for (const AUnit* Unit : Supporters)
	{
		if (!Unit)
		{
			continue;
		}

		FSupportSkillInfo SupportSkillInfo;
		SupportSkillInfo.ModelType = Unit->GetModelType();
		SupportSkillInfo.SkillType = Unit->GetFirstSupportSkillType();

		SupportSkillInfos.Emplace(SupportSkillInfo);
	}

	if (CombatPresenter->GetCombatSeed().Content == EContentType::Raid)
	{
		const FCCCombatCubeState& CCState = GetCheckedCombatCube(this)->GetState();
		for (const auto& RaidSupportSkill : CCState.RaidState.RaidSupportSkillStates)
		{
			if (!RaidSupportSkill.bIsUsed)
			{
				continue;
			}

			const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(RaidSupportSkill.CharInfo.Type);
			if (UnitRow.IsInvalid())
			{
				continue;
			}

			FSupportSkillInfo SupportSkillInfo;
			SupportSkillInfo.ModelType = UnitRow.Model;
			SupportSkillInfo.SkillType = RaidSupportSkill.SkillState.SkillType;

			SupportSkillInfos.Emplace(SupportSkillInfo);
		}
	}

	if (!SupportSkillInfos.Num())
	{
		return false;
	}

	ensure(SupportSkillInfos.Num() <= CombatCubeConst::Q6_MAX_SUPPORT_SKILL_AT_ONE_TIME);

	bool bIsLeftSupporter = SupportSkillInfos.IsValidIndex(0);
	bool bIsRightSupporter = SupportSkillInfos.IsValidIndex(1);

	if (bIsLeftSupporter)
	{
		if (!CreateWidgetIfNotCreated(&SupportSkillLeftAnimWidget, SupportSkillLeftAnimationWidgetClass))
		{
			return false;
		}

		if (!bIsRightSupporter)
		{
			SupportSkillLeftAnimWidget->AnimationFinishedDelegate.BindUObject(this, &ACombatHUD::OnSupportSkillAnimFinished);
		}
		SupportSkillLeftAnimWidget->PlayHelpSkillAnimation(
			SupportSkillInfos[0].ModelType
			, SupportSkillInfos[0].SkillType
			, SupporterBonus);
	}

	if (bIsRightSupporter)
	{
		if (!CreateWidgetIfNotCreated(&SupportSkillRightAnimWidget, SupportSkillRightAnimationWidgetClass))
		{
			return false;
		}

		SupportSkillRightAnimWidget->AnimationFinishedDelegate.BindUObject(this, &ACombatHUD::OnSupportSkillAnimFinished);
		SupportSkillRightAnimWidget->PlayHelpSkillAnimation(
			SupportSkillInfos[1].ModelType
			, SupportSkillInfos[1].SkillType
			, SupporterBonus);
	}

	return true;
}

void ACombatHUD::PlayRewardAnimation()
{
	if (ResultWidget)
	{
		ResultWidget->PlayRewardAnimation();
		ACTION_DISPATCH_WeeklyMissionToast();
	}
	else
	{
		Q6JsonLogGunny(Warning, "ACombatHUD::PlayResultAnimation - ResultWidget does not exist. ");
	}
}

void ACombatHUD::PlayRaidResultAnim(bool bRaidFinal)
{
	if (ResultWidget)
	{
		ResultWidget->PlayRaidResultAnim(bRaidFinal);
		ACTION_DISPATCH_WeeklyMissionToast();
	}
}

void ACombatHUD::PlayArtifactAnimation(int32 SkillType, FCCUnitId TargetUnitId)
{
	CreateWidgetIfNotCreated(&ArtifactAnimWidget, ArtifactAnimWidgetClass);
	if (ArtifactAnimWidget)
	{
		ArtifactAnimWidget->ArtifactAnimFinishedDelegate.BindUObject(this, &ACombatHUD::OnArtifactAnimFinished);
		ArtifactAnimWidget->PlayArtifactAnimation(SkillType, TargetUnitId);
	}
}

int32 ACombatHUD::GetSelectedTurnSkillIndex() const
{
	if (CombatHUDWidget)
	{
		return CombatHUDWidget->GetSelectedTurnSkillIndex();
	}

	return INDEX_NONE;
}

FCombatMissionInfo ACombatHUD::GetCombatMissionInfo() const
{
	FCombatMissionInfo Out;

	for (const TPair<FMissionType, int32>& Elem : WeeklyCombatMission)
	{
		FMissionCombat MissionCombat;
		MissionCombat.Type = Elem.Key;
		MissionCombat.Value = Elem.Value;

		Out.WeeklyCombatMissionInfo.Add(MissionCombat);
	}

	TArray<FCharMissionCombat> CharMissionCombatInfo;
	for (const TPair<FCharMissionType, int32>& Elem : CharacterCombatMission)
	{
		FCharMissionCombat CharMissionCombat;
		CharMissionCombat.Type = Elem.Key;
		CharMissionCombat.Value = Elem.Value;

		Out.CharCombatMissionInfo.Add(CharMissionCombat);
	}

	return Out;
}

void ACombatHUD::SetAllyTurnSkillPhaseSelectable(bool bInSelectable)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->SetAllyTurnSkillPhaseSelectable(bInSelectable);
	}
}

void ACombatHUD::PickFirstAliveAlly()
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->PickFirstAliveAlly();
	}
}

void ACombatHUD::ResetTotalDamage()
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->ResetTotalDamage();
	}
}

void ACombatHUD::ResetUnitNoticeCaches()
{
	UnitNoticeShowingUnitIds.Reset();
	UnitStateNoticeStartedUnitIds.Reset();
}

void ACombatHUD::ShowUltimateSkipWidget(bool bShow)
{
	if (bShow)
	{
		if (CreateWidgetIfNotCreated(&UltimateSkipWidget, UltimateSkipWidgetClass))
		{
			if (!UltimateSkipWidget->IsInViewport())
			{
				UltimateSkipWidget->AddToViewport(ZORDER_HUDWIDGET);
			}

			UltimateSkipWidget->OnSkipDelegate.BindUObject(this, &ACombatHUD::OnUltimateSkillSkipped);
		}
	}
	else
	{
		if (UltimateSkipWidget && UltimateSkipWidget->IsInViewport())
		{
			UltimateSkipWidget->RemoveFromViewport();
		}
	}
}

void ACombatHUD::ClearPointVaryUnitAttributes(FCCUnitId InUnitId)
{
	if (CombatHUDWidget)
	{
		CombatHUDWidget->ClearPointVaryUnitAttributes(InUnitId);
	}
}

float _GetReservedValue(float Value, float MaxValue, float Offset)
{
	if (Value - Offset < 0.f)
	{
		return Offset;
	}

	if (Value + Offset > MaxValue)
	{
		return MaxValue - Offset;
	}

	return Value;
}

bool ACombatHUD::GetViewportPosition(const FCCUnitId TargetUnitId, const FName& SocketName, const FVector& InSpawnPositionOffset, const FVector2D& InWidgetSize, FVector2D& InOutViewportPosition)
{
	APlayerController* PlayerController = GetLocalPlayerController(this);
	if (!ensure(PlayerController))
	{
		return false;
	}

	ULocalPlayer* LocalPlayer = Cast<ULocalPlayer>(PlayerController->Player);
	if (!LocalPlayer || !LocalPlayer->ViewportClient || !LocalPlayer->ViewportClient->Viewport)
	{
		return false;
	}

	// Todo : Caching or Change other solution.
	// Create a view family for the game viewport
	FSceneViewFamilyContext ViewFamily(FSceneViewFamily::ConstructionValues(
		LocalPlayer->ViewportClient->Viewport,
		GetWorld()->Scene,
		LocalPlayer->ViewportClient->EngineShowFlags)
		.SetRealtimeUpdate(true));

	// Calculate a view where the player is to update the streaming from the players start location
	FVector ViewLocation;
	FRotator ViewRotation;
	FSceneView* SceneView = LocalPlayer->CalcSceneView(&ViewFamily, /*out*/ ViewLocation, /*out*/ ViewRotation, LocalPlayer->ViewportClient->Viewport);
	FViewport* ViewportCache = LocalPlayer->ViewportClient->Viewport;

	if (!ensureMsgf(SceneView, TEXT("Invalid Scene")))
	{
		return false;
	}

	const AUnit* TargetUnit = GetCheckedCombatPresenter(this)->FindUnit(TargetUnitId);
	if (!ensureMsgf(TargetUnit, TEXT("Invalid TargetUnit")))
	{
		return false;
	}

	if (TargetUnit->IsHidden())
	{
		return false;
	}

	FVector TargetLocation;
	if (TargetUnit->GetMesh()->DoesSocketExist(SocketName))
	{
		TargetLocation = TargetUnit->GetSocketTransform(SocketName).GetLocation();
	}
	else
	{
		TargetLocation = TargetUnit->GetActorLocation();
	}
	
	if (TargetUnit->IsAttached())
	{
		const ACameraLayerActor* CameraLayerActor = GetCheckedCombatPresenter(this)->GetCameraLayerActor();
		if (CameraLayerActor)
		{
			FVector TargetLocationOffset = TargetLocation - CameraLayerActor->GetActorLocation();
			TargetLocationOffset = CameraLayerActor->GetActorRotation().UnrotateVector(TargetLocationOffset);
			TargetLocationOffset = ViewRotation.RotateVector(TargetLocationOffset);
			TargetLocation = ViewLocation + TargetLocationOffset;
		}
	}

	SceneView->WorldToPixel(TargetLocation + InSpawnPositionOffset, InOutViewportPosition);

	const FVector2D ViewportSize = FVector2D(LocalPlayer->ViewportClient->Viewport->GetSizeXY());
	InOutViewportPosition.X = _GetReservedValue(InOutViewportPosition.X, ViewportSize.X, InWidgetSize.X / 2);
	InOutViewportPosition.Y = _GetReservedValue(InOutViewportPosition.Y, ViewportSize.Y, InWidgetSize.Y / 2);

	return true;
}

void ACombatHUD::SpawnCombatText(FCCUnitId TargetUnitId, ENatureRelationType NatureRelationType, int32 BaseValue, int32 ExtraValue, EHealthChangeReason Reason, bool bDodged, bool bCritical, bool bShield, bool bMultiple, bool bAddRandomOffset)
{
	int32 WidgetIndex = DamageTextWidgets.IndexOfByPredicate([](const UCombatDamageTextWidget* CombatText)->bool {
		return !CombatText->IsInViewport();
	});

	if (ensureMsgf(WidgetIndex != INDEX_NONE, TEXT("CombatText Widget Pool Full.")))
	{
		UCombatDamageTextWidget* DamageWidget = DamageTextWidgets[WidgetIndex];
		ensure(DamageWidget);

		DamageWidget->AddToViewport(ZORDER_BELOW_HUD);
		DamageWidget->SetAlignmentInViewport(FVector2D(0.5f, 1.f));

		if (DamageWidget->InitCombatText(TargetUnitId, NatureRelationType, BaseValue, ExtraValue, Reason, bDodged, bCritical, bShield, bMultiple, bAddRandomOffset))
		{
			DamageWidget->CombatTextAnimationFinished.BindUObject(this, &ACombatHUD::OnDamageTextAnimFinished);
			DamageWidget->StartCombatTextAnimation();
		}
		else
		{
			DamageWidget->RemoveFromParent();
		}
	}
}

UCombatUnitNoticeListWidget* ACombatHUD::GetUnitNoticeList(FCCUnitId TargetUnitId)
{
	const AUnit* TargetUnit = GetCheckedCombatPresenter(this)->FindUnit(TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Warning, "ACombatHUD::GetUnitNoticeList - Invalid target unit", Q6KV("TargetUnitId", TargetUnitId));
		return nullptr;
	}

	UCombatUnitNoticeListWidget* TargetNoticeListWidget = nullptr;

	int32 TargetSlotIndex = TargetUnit->GetUnitState().Slot - 1;
	if (TargetUnit->GetOverrideFaction() == ECCFaction::Ally)
	{
		if (AllyUnitNoticeListWidgets.IsValidIndex(TargetSlotIndex))
		{
			TargetNoticeListWidget = AllyUnitNoticeListWidgets[TargetSlotIndex];
		}
	}
	else
	{
		if (EnemyUnitNoticeListWidgets.IsValidIndex(TargetSlotIndex))
		{
			TargetNoticeListWidget = EnemyUnitNoticeListWidgets[TargetSlotIndex];
		}
	}

	if (!TargetNoticeListWidget)
	{
		return nullptr;
	}

	if (GetUnitNoticeListInternal(TargetUnitId, TargetNoticeListWidget))
	{
		return TargetNoticeListWidget;
	}

	return nullptr;
}

UCombatUnitStateNoticeListWidget* ACombatHUD::GetUnitStateNoticeList(FCCUnitId TargetUnitId)
{
	const AUnit* TargetUnit = GetCheckedCombatPresenter(this)->FindUnit(TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Warning, "ACombatHUD::GetUnitStateNoticeList - Invalid target unit", Q6KV("TargetUnitId", TargetUnitId));
		return nullptr;
	}

	UCombatUnitStateNoticeListWidget* TargetNoticeListWidget = nullptr;

	int32 TargetSlotIndex = TargetUnit->GetUnitState().Slot - 1;
	if (TargetUnit->GetOverrideFaction() == ECCFaction::Ally)
	{
		if (AllyUnitStateNoticeListWidgets.IsValidIndex(TargetSlotIndex))
		{
			TargetNoticeListWidget = AllyUnitStateNoticeListWidgets[TargetSlotIndex];
		}
	}
	else
	{
		if (EnemyUnitStateNoticeListWidgets.IsValidIndex(TargetSlotIndex))
		{
			TargetNoticeListWidget = EnemyUnitStateNoticeListWidgets[TargetSlotIndex];
		}
	}

	if (!TargetNoticeListWidget)
	{
		return nullptr;
	}

	if (GetUnitNoticeListInternal(TargetUnitId, TargetNoticeListWidget))
	{
		return TargetNoticeListWidget;
	}

	return nullptr;
}

bool ACombatHUD::GetUnitNoticeListInternal(FCCUnitId InUnitId, UCombatUnitNoticeListBaseWidget* InWidget)
{
	bool bFullView = false;
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		bFullView = PlayerController->GetCombatCameraType() == ECombatCamera::Wave;
	}

	if (InWidget->SetPosition(InUnitId, bFullView))
	{
		if (!InWidget->IsInViewport())
		{
			InWidget->AddToViewport(ZORDER_BELOW_HUD);
		}
		InWidget->SetAlignmentInViewport(FVector2D(0.5f, 1.f));

		return true;
	}

	return false;
}

void ACombatHUD::SpawnUnitBuffNotices(EBuffNoticeType BuffNoticeType, FCCUnitId TargetUnitId, const FBuffType& BuffType, int32 BuffLevel /* = 1 */, ESkillCategory BornCategory /* = ESkillCategory::Normal */)
{
	UCombatUnitNoticeListWidget* TargetNoticeListWidget = GetUnitNoticeList(TargetUnitId);
	if (TargetNoticeListWidget)
	{
		UnitNoticeShowingUnitIds.AddUnique(TargetUnitId);
		TargetNoticeListWidget->SetBuffNotices(BuffNoticeType, BuffType, BuffLevel, BornCategory);
	}
	else
	{
		OnUnitNoticeAnimFinishedInternal();
	}
}

void ACombatHUD::SpawnUnitRemoveBuffFailedNotice(FCCUnitId TargetUnitId, ERemoveBuffFailedReason Reason, EApplyTag NoApplyTag)
{
	UCombatUnitNoticeListWidget* TargetNoticeListWidget = GetUnitNoticeList(TargetUnitId);
	if (TargetNoticeListWidget)
	{
		UnitNoticeShowingUnitIds.AddUnique(TargetUnitId);
		TargetNoticeListWidget->SetBuffRemovalFailedNotice(Reason, NoApplyTag);
	}
	else
	{
		OnUnitNoticeAnimFinishedInternal();
	}
}

void ACombatHUD::SpawnUnitImmuneBuffNotice(FCCUnitId TargetUnitId, EApplyTag ImmuneTag)
{
	UCombatUnitNoticeListWidget* TargetNoticeListWidget = GetUnitNoticeList(TargetUnitId);
	if (TargetNoticeListWidget)
	{
		UnitNoticeShowingUnitIds.AddUnique(TargetUnitId);
		TargetNoticeListWidget->SetBuffImmuneNotice(ImmuneTag);
	}
	else
	{
		OnUnitNoticeAnimFinishedInternal();
	}
}

void ACombatHUD::SpawnUnitPointNotice(FCCUnitId TargetUnitId, EPointVaryState PointVaryState, const FString& TypeKeyStr, const FText& ValueText, bool bUnitAttribute)
{
	UCombatUnitNoticeListWidget* TargetNoticeListWidget = GetUnitNoticeList(TargetUnitId);
	if (TargetNoticeListWidget)
	{
		UnitNoticeShowingUnitIds.AddUnique(TargetUnitId);
		TargetNoticeListWidget->SetPointNotice(PointVaryState, TypeKeyStr, ValueText, bUnitAttribute);
	}
	else
	{
		OnUnitNoticeAnimFinishedInternal();
	}
}

void ACombatHUD::SpawnUnitImmediateKillNotice(FCCUnitId TargetUnitId)
{
	UCombatUnitNoticeListWidget* TargetNoticeListWidget = GetUnitNoticeList(TargetUnitId);
	if (TargetNoticeListWidget)
	{
		UnitNoticeShowingUnitIds.AddUnique(TargetUnitId);
		TargetNoticeListWidget->PlayImmediateKillNotice();
	}
	else
	{
		OnUnitNoticeAnimFinishedInternal();
	}
}

void ACombatHUD::SpawnUnitSkillTimeNotice(FCCUnitId TargetUnitId, ESetSkillTimeType SetSkillTimeType, int32 Value)
{
	UCombatUnitNoticeListWidget* TargetNoticeListWidget = GetUnitNoticeList(TargetUnitId);
	if (TargetNoticeListWidget)
	{
		UnitNoticeShowingUnitIds.AddUnique(TargetUnitId);
		TargetNoticeListWidget->SetSkillTimeNotice(SetSkillTimeType, Value);
	}
	else
	{
		OnUnitNoticeAnimFinishedInternal();
	}
}

void ACombatHUD::SpawnUnitStateNotice(FCCUnitId TargetUnitId, const FBuffEffectState& BuffEffectState)
{
	UCombatUnitStateNoticeListWidget* UnitStateNoticeList = GetUnitStateNoticeList(TargetUnitId);
	if (UnitStateNoticeList)
	{
		UnitStateNoticeStartedUnitIds.AddUnique(TargetUnitId);
		UnitNoticeShowingUnitIds.AddUnique(TargetUnitId);
		UnitStateNoticeList->AddBuffNotice(BuffEffectState);
	}
}

UCombatUnitApplyEffectLabelListWidget* ACombatHUD::GetUnitApplyEffectLabelList(FCCUnitId TargetUnitId)
{
	const AUnit* TargetUnit = GetCheckedCombatPresenter(this)->FindUnit(TargetUnitId);
	if (!TargetUnit)
	{
		Q6JsonLogSunny(Warning, "ACombatHUD::PlayUnitApplyEquipmentEffect - Invalid target unit", Q6KV("TargetUnitId", TargetUnitId));
		return nullptr;
	}

	UCombatUnitApplyEffectLabelListWidget* TargetLabelListWidget = nullptr;

	int32 TargetSlotIndex = TargetUnit->GetUnitState().Slot - 1;
	if (TargetUnit->GetOverrideFaction() == ECCFaction::Ally)
	{
		if (AllyUnitApplyEffectLabelListWidgets.IsValidIndex(TargetSlotIndex))
		{
			TargetLabelListWidget = AllyUnitApplyEffectLabelListWidgets[TargetSlotIndex];
		}
	}
	else
	{
		if (EnemyUnitApplyEffectLabelListWidgets.IsValidIndex(TargetSlotIndex))
		{
			TargetLabelListWidget = EnemyUnitApplyEffectLabelListWidgets[TargetSlotIndex];
		}
	}

	bool bFullView = false;
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		bFullView = PlayerController->GetCombatCameraType() == ECombatCamera::Wave;
	}

	if (!TargetLabelListWidget || !TargetLabelListWidget->SetPosition(TargetUnitId, bFullView))
	{
		return nullptr;
	}

	if (!TargetLabelListWidget->IsInViewport())
	{
		TargetLabelListWidget->AddToViewport(ZORDER_BELOW_HUD);
	}
	TargetLabelListWidget->SetAlignmentInViewport(FVector2D(0.5f, 1.f));

	return TargetLabelListWidget;
}


void ACombatHUD::OnNetworkEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp)
{
	Super::OnNetworkEnteredLobbyFinal(Resp);

	if (EOngoingCategory::None == Resp.OngoingCategory)
	{
		// TODO(cylee): use proper text here.
		UConfirmPopupWidget* ConfirmPopup = OpenConfirmPopup(FText::FromString("failed-to-restore"), FText::FromString("failed-to-restore"));
		ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
		ConfirmPopup->OnPopupClosedDelegate.BindLambda([&]() {
			UQ6GameInstance* GameInstance = CastChecked<UQ6GameInstance>(GetGameInstance());
			GameInstance->RemoveOngoingChronicleFile();
			ACTION_DISPATCH_SetOnGoingRaid(RaidTypeInvalid, FRaidId::InvalidValue());

			FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
			ClientNetwork.PanicRestartGame(TEXT("HandleRestoreOngoingError"));
		});
	}
}

void ACombatHUD::PlayUnitApplyMomentEffect(FCCUnitId TargetUnitId, EMoment Moment)
{
	UCombatUnitApplyEffectLabelListWidget* TargetApplyEffectLabelListWidget = GetUnitApplyEffectLabelList(TargetUnitId);
	if (!TargetApplyEffectLabelListWidget)
	{
		return;
	}

	TargetApplyEffectLabelListWidget->AddMomentLabel(Moment);
}

URaidUserPopupWidget* ACombatHUD::OpenRaidUserPopup()
{
	RaidUserPopupWidget = CastChecked<URaidUserPopupWidget>(OpenPopup(RaidUserPopupWidgetClass));
	return RaidUserPopupWidget;
}

UFriendRequestPopupWidget* ACombatHUD::OpenFriendRequestPopup()
{
	CreateWidgetIfNotCreated(&FriendRequestPopupWidget, FriendRequestPopupWidgetClass);
	if (FriendRequestPopupWidget)
	{
		FriendRequestPopupWidget->AddToViewport(ZORDER_HUDWIDGET);
	}
	return FriendRequestPopupWidget;
}

UJokerSetViewPopupWidget* ACombatHUD::OpenJokerSetViewPopup(const FFriendInfo& FriendInfo)
{
	UJokerSetViewPopupWidget* JokerSetViewPopup = CastChecked<UJokerSetViewPopupWidget>(OpenPopup(JokerSetViewPopupWidgetClass));
	JokerSetViewPopup->SetFriendInfo(FriendInfo);
	return JokerSetViewPopup;
}

UWithdrawPopupWidget* ACombatHUD::OpenWithdrawPopup(EContentType InContentType)
{
	WithdrawPopupWidget = CastChecked<UWithdrawPopupWidget>(OpenPopup(WithdrawPopupWidgetClass));
	WithdrawPopupWidget->SetContentType(InContentType);
	return WithdrawPopupWidget;
}

void ACombatHUD::OnSpawnAnimFinished()
{
	OnSpawnAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnSkillStartAnimFinished()
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(UsedSkillType);
	if (SkillRow.SkillCategory == ESkillCategory::Ultimate)
	{
		if (!PlaySupportSkillAnims())
		{
			OnSkillPreAnimFinished();
		}
	}
}

void ACombatHUD::OnSupportSkillAnimFinished()
{
	if (SupportSkillLeftAnimWidget)
	{
		SupportSkillLeftAnimWidget->AnimationFinishedDelegate.Unbind();
	}
	if (SupportSkillRightAnimWidget)
	{
		SupportSkillRightAnimWidget->AnimationFinishedDelegate.Unbind();
	}

	OnSkillPreAnimFinished();
}

void ACombatHUD::OnSkillPreAnimFinished()
{
	OnSkillPreAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnDamageTextAnimFinished()
{
	OnDamageTextAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnUnitStateNoticeStartNext(FCCUnitId InUnitId)
{
	if (!UnitStateNoticeStartedUnitIds.Contains(InUnitId))
	{
		return;
	}

	UnitStateNoticeStartedUnitIds.Remove(InUnitId);

	if (UnitStateNoticeStartedUnitIds.Num() <= 0)
	{
		OnUnitNoticeAnimStartDelegate.ExecuteIfBound();
	}
}

void ACombatHUD::OnUnitNoticeAnimFinished(FCCUnitId InUnitId)
{
	if (!UnitNoticeShowingUnitIds.Contains(InUnitId))
	{
		return;
	}

	UnitNoticeShowingUnitIds.Remove(InUnitId);

	if (UnitNoticeShowingUnitIds.Num() <= 0)
	{
		OnUnitNoticeAnimFinishedInternal();
	}
}

void ACombatHUD::OnUnitNoticeAnimFinishedInternal()
{
	OnUnitNoticeAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnStartTurnPhaseAnimFinished()
{
	OnStartTurnPhaseAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnEnemyUltimateReadyAnimFinished()
{
	OnEnemyUltimateReadyAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnWinAnimFinished()
{
	WinAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnResultWidgetClosed()
{
	ResultWidgetClosedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnRaidAssistStartAnimFinished()
{
	OnRaidAssistStartAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnSkillFailedAnimFinished()
{
	OnSkillFailedAnimFinishedDelegate.ExecuteIfBound();
}

void ACombatHUD::OnArtifactAnimFinished(int32 SkillType, FCCUnitId TargetUnitId)
{
	int32 ArtifactIndex = GetCMS()->GetArtifactIndex(SkillType);
	int32 InResurrectionCount = GetHUDStore().GetUserRecordManager().GetResurrectionCount();
	if (ArtifactIndex != INDEX_NONE)
	{
		if (SkillType == TempleConst::Q6_ARTIFACT3_SKILL_ID)
		{
			GetCheckedCombatCube(this)->UseWipeoutContinue(InResurrectionCount, false);
		}
		else
		{
			GetCheckedCombatCube(this)->UseArtifact(TargetUnitId, ArtifactIndex);
		}
	}
	else if (SkillType == SystemConst::Q6_GEM_REBIRTH_SKILL_ID)
	{
		GetCheckedCombatCube(this)->UseWipeoutContinue(InResurrectionCount, true);
	}
}

void ACombatHUD::OnUltimateSkillSkipped()
{
	ACombatPlayerController* PlayerController = GetCombatPlayerController(this);
	if (PlayerController)
	{
		PlayerController->JumpToEndFrame();
	}
}

void ACombatHUD::SynchronizeCCState(const FCCCombatCubeState& InState)
{
	// TODO Sync hud state.
	CreateHUDWidgetAndBindEvents(); //CombatHUDWidget;

	// DebugCombatWidget : no need
	// ResultWidget : no need
	// FriendRequestPopupWidget : no need
	// DamageTextWidgets : no need

	// TODO: AllyUnitNoticeListWidgets;
	// TODO: EnemyUnitNoticeListWidgets;

	// SupportSkillLeftAnimWidget : no need
	// SupportSkillRightAnimWidget no need
	// UltimateSkillAnimWidget; : no need
	// SkillAnimWidgets : no need
	// ProgressTasks : no need
	// SkillGaugeProgressTasks : no need
	// SkillUsedUnitId : no need
	// UsedSkillType : no need
	// SupporterBonus : no need

	WaveIndex = InState.TurnState.CurrentWaveIndex;

	CombatHUDWidget->SynchronizeCCState(InState);

	CombatTutorial->InitTutorial();
}

void ACombatHUD::PostSynchronizeCCState()
{
	CombatHUDWidget->PostSynchronizeCCState();
}