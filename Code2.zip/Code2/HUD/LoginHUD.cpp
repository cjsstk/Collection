// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "LoginHUD.h"

#include "CommonWidgets.h"
#include "DailyDungeonManager.h"
#include "ErrCode_gen.h"
#include "HUDStore.h"
#include "HSAction.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "RaidManager.h"
#include "Network/Q6ClientNetwork.h"
#include "Widget/LoginHUDWidget.h"
#include "Utils/LevelUtil.h"

ALoginHUD::ALoginHUD()
	: OngoingSagaType(SagaTypeInvalid),
	ExpireTime(0)
{
}

void ALoginHUD::BeginPlay()
{
	Super::BeginPlay();

	LoginHUDWidget = CreateWidget<ULoginHUDWidget>(GetLocalPlayerController(this), LoginHUDWidgetClass);
	LoginHUDWidget->AddToViewport(ZORDER_HUDWIDGET);

	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	GameInstance->OnNetworkReady().BindUObject(this, &ALoginHUD::OnNetworkReady);
}

void ALoginHUD::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}

void ALoginHUD::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (OngoingSagaType == SagaTypeInvalid)
	{
		return;
	}

	if (ExpireTime < FDateTime::UtcNow().ToUnixTimestamp())
	{
		OpenExpireConfirmPopup(OngoingSagaType);
		OngoingSagaType = SagaTypeInvalid;
		return;
	}

	RefreshOngoingPopup();
}

void ALoginHUD::OnNetworkStartConnect()
{
	NetworkProgressWidget->Show(Q6Util::GetLocalizedTextOrKey("Service", "ConnectingToServer"));
}

void ALoginHUD::OnNetworkMaintenance(const FMaintenanceInfo& Info)
{
	SetDefaultVisibility();

	FTextFormat TextFormat = FTextFormat::FromString("now maintenance in progress. \nbegin:{begin} \nend:{end} \nnotice:{notice}");

	FFormatNamedArguments Arguments;

	Arguments.Add(TEXT("begin"), Q6Util::GetLocalDateTimeText(Info.Begin));
	Arguments.Add(TEXT("end"), Q6Util::GetLocalDateTimeText(Info.End));
	Arguments.Add(TEXT("notice"), FText::FromString(Info.Notice));
	OnMaintenance(FText::Format(TextFormat, Arguments));
}

void ALoginHUD::OnNetworkConnected()
{
	NetworkProgressWidget->Show(Q6Util::GetLocalizedTextOrKey("Service", "TryingLogin"));
}

void ALoginHUD::OnNetworkConnectFailed()
{
	SetDefaultVisibility();
	OnError(Q6Util::GetLocalizedTextOrKey("Service", "CannotConnect"));
}

void ALoginHUD::SetDefaultVisibility()
{
	NetworkProgressWidget->Hide();
	LoginHUDWidget->SetDefaultVisibility();
}

void ALoginHUD::OpenDialogueContinueConfirmPopup()
{
	FText TitleText = Q6Util::GetLocalizedText("Popup", "DialogueContinueTitle");
	FText ContentText = Q6Util::GetLocalizedText("Popup", "DialogueContinueContent");
	ConfirmPopup = OpenConfirmPopup(TitleText, ContentText);

	ConfirmPopup->SetCancelable(false);
	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes | EConfirmPopupFlag::No);
	ConfirmPopup->SetYesNoText(Q6Util::GetLocalizedText("Common", "DialogueContinue"), Q6Util::GetLocalizedText("Common", "DialogueCancel"));
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &ALoginHUD::OnDialogueContinue);
}

void ALoginHUD::OpenDialogueExpiredConfirmPopup()
{
	FText TitleText = Q6Util::GetLocalizedText("Popup", "DialogueExpiredTitle");
	FText ContentText = Q6Util::GetLocalizedText("Popup", "DialogueExpiredContent");
	ConfirmPopup = OpenConfirmPopup(TitleText, ContentText);

	ConfirmPopup->SetCancelable(false);
	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
	ConfirmPopup->SetYesNoText(Q6Util::GetLocalizedText("Common", "DialogueGotoHome"), FText::GetEmpty());
	ConfirmPopup->OnPopupClosedDelegate.BindUObject(this, &ALoginHUD::OnDialogueExpired);
}

void ALoginHUD::OpenRaidFinalConfirmPopup()
{
	FText TitleText = Q6Util::GetLocalizedText("Popup", "RaidClosed");
	FText ContentText = Q6Util::GetLocalizedText("Popup", "RiadFinalOpened");
	ConfirmPopup = OpenConfirmPopup(TitleText, ContentText);

	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
	ConfirmPopup->OnPopupClosedDelegate.BindUObject(this, &ALoginHUD::OpenLobbyMenu, EHUDWidgetType::Raid);
}

void ALoginHUD::OpenOngoingContinueConfirmPopup(const FSagaType SagaType, const int64 RemainTime)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	const FText& ContinueTitleText = Q6Util::GetLocalizedText("Popup", "ContinueTitle");
	const FText& ContinueContentText =
		FText::Format(Q6Util::GetLocalizedText("Popup", "ContinueContent"),
			Q6Util::GetContentText(SagaRow.ContentType), SagaRow.DescName,
			Q6Util::GetShortTimeText(RemainTime));

	const auto& CommonContinue = Q6Util::GetLocalizedText("Common", "Continue");
	const auto& CommonGotoHome = Q6Util::GetLocalizedText("Common", "GotoHome");
	ConfirmPopup = OpenConfirmPopup(ContinueTitleText, ContinueContentText);
	ConfirmPopup->SetCancelable(false);
	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes | EConfirmPopupFlag::No);
	ConfirmPopup->SetYesNoText(CommonContinue, CommonGotoHome);
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &ALoginHUD::OnConfirmOnGoingChronicle, SagaType);
}

void ALoginHUD::OpenExpireConfirmPopup(FSagaType SagaType)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	const FText& OngoingExpireTitleText = Q6Util::GetLocalizedText("Popup", "OngoingExpireTitle");
	const FText& OngoingExpireContentText =
		FText::Format(Q6Util::GetLocalizedText("Popup", "OngoingExpireContent"),
			Q6Util::GetContentText(SagaRow.ContentType), SagaRow.DescName);

	const auto& CommonGotoHome = Q6Util::GetLocalizedText("Common", "GotoHome");
	if (!ConfirmPopup || !ConfirmPopup->IsOpened())
	{
		ConfirmPopup = OpenConfirmPopup(OngoingExpireTitleText, OngoingExpireContentText);
	}
	else
	{
		ConfirmPopup->SetTitle(OngoingExpireTitleText);
		ConfirmPopup->SetContent(OngoingExpireContentText);
	}

	ConfirmPopup->SetCancelable(false);
	ConfirmPopup->SetConfirmFlags(EConfirmPopupFlag::Yes);
	ConfirmPopup->SetYesNoText(CommonGotoHome, FText::GetEmpty());
	ConfirmPopup->OnConfirmPopupDelegate.BindUObject(this, &ALoginHUD::OnConfirmOngoingExpire);
}

void ALoginHUD::RefreshOngoingPopup()
{
	if (!ConfirmPopup)
	{
		return;
	}

	int32 RemainTime = ExpireTime - FDateTime::UtcNow().ToUnixTimestamp();
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(OngoingSagaType);
	const FText& ContinueContentText =
		FText::Format(Q6Util::GetLocalizedText("Popup", "ContinueContent"),
			Q6Util::GetContentText(SagaRow.ContentType), SagaRow.DescName,
			Q6Util::GetShortTimeText(RemainTime));
	ConfirmPopup->SetContent(ContinueContentText);
}

void ALoginHUD::OpenLobbyMenu(EHUDWidgetType WidgetType)
{
	GetGameInstance<UQ6GameInstance>()->RemoveOngoingChronicleFile();

	ACTION_DISPATCH_MenuChange(WidgetType, true);
	ULevelUtil::LoadLobbyLevel(GetWorld());
}

void ALoginHUD::OnNetworkReady(UQ6GameInstance* GameInstance)
{
}

void ALoginHUD::OnNetworkDisconnected()
{
	OnNetworkError(Q6_ERROR_DISCONNECTED, FString(""));
}

void ALoginHUD::OnNetworkLogin(const FL2CAuthLoginResp& Res)
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.EnterLobby();
}

void ALoginHUD::OnNetworkEnteringLobby()
{
	 NetworkProgressWidget->Show(Q6Util::GetLocalizedTextOrKey("Service", "EnteringServer"));
}

void ALoginHUD::OnNetworkEnteredLobby(const FL2CAuthEnterLobbyResp& Resp)
{

}

void ALoginHUD::OnNetworkEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp)
{
	OngoingSagaType = Resp.OngoingSagaType;

	NetworkProgressWidget->Hide();

	ACTION_DISPATCH_FriendBookNewFeedsFromFile(GetQ6SaveGame()->GetLatestFriendBookFeed(), GetQ6SaveGame()->GetReadFriendBookFeed());
	GetHUDStore().GetFriendBook().ReqTimeline(FFriendBookFeedId::InvalidValue());

	ACTION_DISPATCH_AuthEnterLobbyFinalResp(Resp);

	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	check(GameInstance);

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Resp.OngoingSagaType);
	if (SagaRow.ContentType == EContentType::Raid)
	{
		FRaidType OnGoingRaidType = GetCMS()->GetRaidTypeBySagaType(SagaRow.CmsType());

		FRaidId OnGoingRaidId;
		const UQ6SaveGame* SaveGameInstance = GameInstance->GetSaveGame();
		if (SaveGameInstance)
		{
			OnGoingRaidId = SaveGameInstance->GetRaidId();
		}

		const URaidManager& RaidManager = GetHUDStore().GetRaidManager();
		int64 StartUtc = RaidManager.GetRaidStartUtcByRaidId(OnGoingRaidId);

		const FCMSRaidRow& RaidRow = GetCMS()->GetRaidRowOrDummy(OnGoingRaidType);
		if (!RaidRow.IsInvalid() && StartUtc > 0)
		{
			int64 NowUtc = FDateTime::UtcNow().ToUnixTimestamp();
			if (StartUtc + RaidRow.TotalSec > NowUtc)
			{
				ExpireTime = StartUtc + RaidRow.TotalSec;
				OpenOngoingContinueConfirmPopup(Resp.OngoingSagaType
					, StartUtc - NowUtc + RaidRow.TotalSec);
			}
			else
			{
				OpenRaidFinalConfirmPopup();
			}
			return;
		}
	}
	else
	{
		if (Resp.OngoingCategory == EOngoingCategory::Restore)
		{
			ExpireTime = Resp.ExpireTime;
			OpenOngoingContinueConfirmPopup(Resp.OngoingSagaType
				, ExpireTime - FDateTime::UtcNow().ToUnixTimestamp());
			return;
		}
		else if (Resp.OngoingCategory == EOngoingCategory::Expire)
		{
			OpenExpireConfirmPopup(Resp.OngoingSagaType);
			return;
		}
	}

	const FDialogueRecord& DialogueRecord = GameInstance->GetDialogueRecord();
	if (DialogueRecord.IsDialogueContinue())
	{
		bool bExpired = GameInstance->IsDialogueExpired(DialogueRecord);
		if (bExpired)
		{
			OpenDialogueExpiredConfirmPopup();
		}
		else
		{
			OpenDialogueContinueConfirmPopup();
		}

		return;
	}

	OpenLobbyMenu(EHUDWidgetType::Main);
}

void ALoginHUD::OnBackgroundTimeout()
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.EnsureContextDisconnect();
	HandleError();
}

void ALoginHUD::HandleError()
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();

	NetworkProgressWidget->Hide();
#if UE_BUILD_SHIPPING
	OnNetworkReady(GameInstance);
#endif
}

void ALoginHUD::OnConfirmOnGoingChronicle(EConfirmPopupFlag InConfirmFlag, FSagaType NotFinishedSagaType)
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();

	const UCMS* CMS = GetCMS();
	check(CMS);

	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(NotFinishedSagaType);
	if (InConfirmFlag == EConfirmPopupFlag::Yes)
	{
		if (SagaRow.ContentType == EContentType::Raid)
		{
			const UQ6SaveGame* SaveGameInstance = GameInstance->GetSaveGame();
			if (SaveGameInstance)
			{
				// need to compare raidId
				FRaidType OnGoingRaidType = CMS->GetRaidTypeBySagaType(SagaRow.CmsType());
				FRaidId OnGoingRaidId = SaveGameInstance->GetRaidId();

				ACTION_DISPATCH_SetOnGoingRaid(OnGoingRaidType, OnGoingRaidId);
				ULevelUtil::LoadSagaLevel(GetWorld(), NotFinishedSagaType);
			}
			else
			{
				ULevelUtil::LoadLobbyLevel(GetWorld());
			}
		}
		else
		{
			ULevelUtil::LoadSagaLevel(GetWorld(), NotFinishedSagaType);
		}
	}
	else
	{
		if (SagaRow.ContentType == EContentType::Raid)
		{
			GetHUDStore().GetRaidManager().ReqOngoingStageEnd(NotFinishedSagaType);
		}

		CancelStage();
	}
}

void ALoginHUD::OnConfirmOngoingExpire(EConfirmPopupFlag InConfirmFlag)
{
	CancelStage();
}

void ALoginHUD::OnDialogueContinue(EConfirmPopupFlag InConfirmFlag)
{
	if (InConfirmFlag != EConfirmPopupFlag::Yes)
	{
		// Cancel dialogue continue
		// If has any reward, it will be reward sequence play only.
		UQ6GameInstance::Get(this)->ClearDialogueRecord();
		OpenLobbyMenu(EHUDWidgetType::Main);
		return;
	}

	const FDialogueRecord& DialogueRecord = UQ6GameInstance::Get(this)->GetDialogueRecord();
	EDialogueType DialogueType = DialogueRecord.DialogueType;

	// Make LobbyUIState history

	if (DialogueType == EDialogueType::Saga)
	{
		const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(DialogueRecord.SagaType);
		ACTION_DISPATCH_SagaStageList(SagaRow.Episode);
	}
	else if (DialogueType == EDialogueType::Special)
	{
		const FCMSSpecialRow* SpecialRow = GetCMS()->GetSpecialRow(DialogueRecord.SagaType);
		if (!SpecialRow)
		{
			Q6JsonLogRoze(Error, "ALoginHUD::OnDialogueContinue - Not found special row", Q6KV("SagaType", DialogueRecord.SagaType.x));
			OpenLobbyMenu(EHUDWidgetType::Main);
			return;
		}

		// Goto special stage list according to special category
		if (SpecialRow->ConditionType == ESpecialCategory::Character)
		{
			ACTION_DISPATCH_SpecialCharacterStageList(SpecialRow->CmsType());
		}
		else if (SpecialRow->ConditionType == ESpecialCategory::Saga)
		{
			ACTION_DISPATCH_SpecialSagaStageList();
		}
		else if (SpecialRow->ConditionType == ESpecialCategory::Wonder)
		{
			EWonderCategory WonderCategory = GetWonderCategory(SpecialRow->ConditionType);
			ACTION_DISPATCH_SpecialWonderStageList(WonderCategory);
		}
	}
	else if (DialogueType == EDialogueType::Daily)
	{
		if (DialogueRecord.SagaType == SagaTypeInvalid)
		{
			// It doesn't stage dialogue, goto daily main
			ACTION_DISPATCH_DailyDungeonPageChange(EDailyDungeonMenuType::Main);
		}
		else
		{
			// Goto daily stage list
			EDayOfWeekType DayOfWeekType = GetHUDStore().GetDailyDungeonManager().GetDayOfWeekType();
			EDailyDungeonCategory DailyCategory = GetCMS()->GetDailyDungeonCategory(DialogueRecord.SagaType, DayOfWeekType);
			ACTION_DISPATCH_DailyDungeonStageList(DailyCategory);
		}
	}
	else if (DialogueType == EDialogueType::Training)
	{
		ACTION_DISPATCH_TrainingCenterOpen();
	}
	else if (DialogueType == EDialogueType::Raid)
	{
		ACTION_DISPATCH_RaidOpen();
	}
	else if (DialogueType == EDialogueType::Event
		|| DialogueType == EDialogueType::MultiSide)
	{
		ACTION_DISPATCH_EventMenuChange(EEventMenu::Stage, DialogueRecord.EventContentType);
	}
	else
	{
		Q6JsonLogRoze(Error, "ALoginHUD::OnDialogueContinue - Invalid dialogue type for continue", Q6KV("EDialogueType", (int32)DialogueType));
		OpenLobbyMenu(EHUDWidgetType::Main);
		return;
	}

	ULevelUtil::LoadLobbyLevel(GetWorld());
}

void ALoginHUD::OnDialogueExpired()
{
	UQ6GameInstance::Get(this)->ClearDialogueRecord();

	OpenLobbyMenu(EHUDWidgetType::Main);
}

void ALoginHUD::CancelStage()
{
	UQ6GameInstance* GameInstance = GetGameInstance<UQ6GameInstance>();
	FQ6ClientNetwork& ClientNetwork = GameInstance->GetClientNetwork();
	ClientNetwork.WsRequest(FQ6NetWsDelegate(), TEXT("user/cancelStage"), FC2LUserCancelStage());

	GameInstance->RemoveOngoingChronicleFile();
	ULevelUtil::LoadLobbyLevel(GetWorld());
}
