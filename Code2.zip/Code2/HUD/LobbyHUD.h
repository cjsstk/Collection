// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseHUD.h"
#include "Q6UIDefine.h"
#include "Q6LobbyState.h"
#include "Q6ClientNetwork.h"

#include "LobbyHUD.generated.h"

class UAccountWidget;
class UBagWidget;
class UCheckInBaseWidget;
class UDailyDungeonWidget;
class UTrainingCenterWidget;
class UDialogueWidget;
class UFriendshipCollectPopupWidget;
class UFriendWidget;
class UInventoryWidget;
class UItemMaxLevelUpConfirmPopupWidget;
class UItemRewardPopupWidget;
class UJokerSelectWidget;
class ULobbyHUDWidget;
class UMainWidget;
class ULobbySettingWidget;
class UNavigationBarWidget;
class UPartyWidget;
class UItemSelectPopupWidget;
class UMailListPopupWidget;
class UMailReceivedPopupWidget;
class USagaWidget;
class USortingChangePopupWidget;
class USpecialWidget;
class USummonWidget;
class USkillUpgradeConfirmPopupWidget;
class UUpgradeResultWidget;
class UUpgradeWidget;
class UInitialRewardEventWidget;
class UWonderWidget;
class URaidWidget;
class UBondUpResultWidget;
class UBondRewardInfoPopupWidget;
class UCodexWidget;
class UWeeklyMissionWidget;
class UShopWidget;
class USellShopWidget;
class UItemReceivedPopupWidget;
class UAchievementsPageWidget;
class UAchievementsPuzzleWidget;
class UPlayRecordPopupWidget;
class USellShopPurchasePopupWidget;
class UEventMainWidget;
class ALobbyTutorial;
class UGetAkaConfirmPopupWidget;
class UStoryWidget;

struct FCheckInAssetRow;
struct FDialogueRecord;
struct FVacationResult;

UCLASS()
class Q6_API ALobbyHUD : public ABaseHUD
{
	GENERATED_BODY()

public:
	ALobbyHUD();

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;

	virtual bool GotoBack(bool bForced = false) override;
	virtual EHUDType GetHUDType() override { return EHUDType::Lobby; }
	virtual void ProcessReward(bool bMenuBack = true) override;

	void SetWidgetsVisible(bool bInVisible) override;
	void SetShowMainWidgets(bool bInShow);
	void StopMainWidgetsAnimations();

	bool IsInAppreciation() const { return bInAppreciation; }
	void UpdateAppreciationActorVisibility(bool bInVisible);
	bool PlaySkillAnimation(FUnitType LobbyUnitType);
	void StopSkillAnimation();

	void ReEnterHUD();
	void RefreshHUD();
	void SetBackEnabled(bool bInEnabled);

	void RefreshNaviBar();

	void PlayDialogueContinue(const FDialogueRecord& DialogueRecord, const FDialogueType PlayingDialogueType);
	void PlaySagaWithStoryClear(FSagaType InSagaType, bool bInPrologue, bool bInReplay);
	void PlayDaily(EDayOfWeekType InDayOfWeek, bool bInReplay);
	void PlayTraining(FTrainingCenterType InTraingType, FSagaType InSagaType, bool bInPrologue, bool bInReplay);
	void PlayVacation(const FVacationResult& InResult);
	void PlayValentineDayEventWithStoryClear(FEventContentValentineDayType InValentineDayType, bool bInPrologue, bool bInReplay);
	void PlayMultisideBattleWithStoryClear(FEventContentMultiSideBattleStageType InMultisideBattleStageType, bool bInPrologue, bool bInReplay);
	void GotoDialogue(int32 GotoId);

	bool HasPlayableDialogue(FSagaType InSagaType);

	void OpenDailyDungeon();

	UPROPERTY(EditDefaultsOnly, Category = "Lobby Tutorial Help Actor")
	TSubclassOf<ALobbyTutorial> LobbyTutorialClass;

	UUpgradeResultWidget* OpenUpgradeResultPopup();
	UItemMaxLevelUpConfirmPopupWidget* OpenPromoteConfirmPopup();
	UItemRewardPopupWidget* OpenItemRewardPopup(FSagaType SagaType, bool bVisibleCount = true,  bool bAllowDuplicated = true);
	UItemRewardPopupWidget* OpenItemRewardPopup(const TArray<FRewardInfo>& RewardInfos);
	UItemRewardPopupWidget* OpenItemRewardPopup(FEventContentType InEventContentType, FSagaType SagaType, bool bVisibleCount = true, bool bAllowDuplicated = true);
	USkillUpgradeConfirmPopupWidget* OpenSkillUpgradeConfirmPopup();
	USortingChangePopupWidget* OpenSortingChangePopup(ESortMenu SortMenu, ESortCategory Category);
	UFriendshipCollectPopupWidget* OpenFriendshipCollectPopup();
	UItemSelectPopupWidget* OpenVacationCharacterListPopup();
	UItemSelectPopupWidget* OpenPortalConnectItemListPopup(EPortalType PortalType, bool bConnect);
	UMailListPopupWidget* OpenMailListPopup();
	UMailReceivedPopupWidget* OpenMailReceivedPopupWidget(const TArray<FMailInfo> RewardInfos);
	UCheckInBaseWidget* OpenCheckInPopup(FCheckInBoardType BoardType, const FCheckInAssetRow& CheckInAssetRow);
	UItemReceivedPopupWidget* OpenItemReceivedPopup();
	UAchievementsPageWidget* OpenAchievementsPagePopup();
	UAchievementsPuzzleWidget* OpenAchievementPuzzlePopup();
	UPlayRecordPopupWidget* OpenPlayRecordPopup();
	USellShopPurchasePopupWidget* OpenSellShopPurchasePopupWidget();
	UGetAkaConfirmPopupWidget* OpenGetAkaConfirmPopup(FUserTitleType InUserTitleType);

	void SetHUDType(EHUDWidgetType HUDWidgetType, bool bMenuChanged = false);
	void ChangeHUDType(EHUDWidgetType HUDWidgetType, bool bMenuChanged = false);
	void ChangeHUDTypeIfNot(EHUDWidgetType HUDWidgetType, bool bMenuChanged = false);

	ULobbyHUDWidget* GetHUDWidget(EHUDWidgetType HUDWidgetType);
	ULobbyHUDWidget* GetCurrentHUDWidget() { return GetHUDWidget(CurrentHUDWidgetType); }

	EHUDWidgetType GetCurrentHUDWidgetType() { return CurrentHUDWidgetType; }
	virtual ABaseTutorial* GetTutorial() override;
	ALobbyTutorial* GetLobbyTutorial();

	virtual void OnTouched() override;

	void OnStoryStageClear();

private:
	void SetHUDInternal(EHUDWidgetType HUDWidgetType, bool bMenuChanged, bool bClearHistory);

	void PlaySaga(FSagaType InSagaType, bool bInPrologue, bool bInReplay);
	void PlayEvent(FEventContentType InEventContentType, FSagaType InSagaType, bool bInPrologue, bool bInReplay);

	void OnPostLoadMap(UWorld* World);
	void OnOutroReward(FSagaType SagaType, const FRewardStep& RewardStep);
	void OnInitailReward(FSagaType SagaType, const FRewardStep& RewardStep);
	void OnWeedGrowReward(FWeedGrowType WeedGrowType);
	void OnContentOpenGuide(FSagaType SagaType, const FRewardStep& RewardStep);
	void OnTitleReward(const FRewardStep& RewardStep);
	void RefreshsHUDCheckMoviePlay(FSagaType SagaType);
	void TutorialButtonClick(FString InSource);

	// Actor visibility depending on HUDWidget using layers
	bool ShouldUpdateActorVisibility();
	FName GetCurrentHUDWidgetLayerName();
	void UpdateActorVisibility(FName LayerName = "");

	EHUDWidgetType CurrentHUDWidgetType;
	EHUDWidgetType LastVisibilityUpdatedHUDWidgetType;
	bool bInAppreciation;

	// Lobby HUD Widgets

	UPROPERTY()
	UMainWidget* MainWidget;

	UPROPERTY()
	UEventMainWidget* EventMainWidget;

	UPROPERTY()
	ULobbySettingWidget* LobbySettingWidget;

	UPROPERTY()
	USagaWidget* SagaWidget;

	UPROPERTY()
	USummonWidget* SummonWidget;

	UPROPERTY()
	UInventoryWidget* InventoryWidget;

	UPROPERTY()
	UPartyWidget* PartyWidget;

	UPROPERTY()
	UDialogueWidget* DialogueWidget;

	UPROPERTY()
	UJokerSelectWidget* JokerSelectWidget;

	UPROPERTY()
	UUpgradeWidget* UpgradeWidget;

	UPROPERTY()
	USpecialWidget* SpecialWidget;

	UPROPERTY()
	UFriendWidget* FriendWidget;

	UPROPERTY()
	UDailyDungeonWidget* DailyDungeonWidget;

	UPROPERTY()
	UTrainingCenterWidget* TrainingCenterWidget;

	UPROPERTY()
	UInitialRewardEventWidget* InitialRewardEventWidget;

	UPROPERTY()
	UWonderWidget* WonderWidget;

	UPROPERTY()
	URaidWidget* RaidWidget;

	UPROPERTY()
	UBondUpResultWidget* BondUpResultWidget;

	UPROPERTY()
	UCodexWidget* CodexWidget;

	UPROPERTY()
	UWeeklyMissionWidget* WeeklyMissionWidget;

	UPROPERTY()
	UShopWidget* ShopWidget;

	UPROPERTY()
	UBagWidget* BagWidget;

	UPROPERTY()
	UAccountWidget* AccountWidget;

	UPROPERTY()
	UStoryWidget* StoryWidget;

	// LobbyTutorial
	UPROPERTY()
	ALobbyTutorial* LobbyTutorial;

	// CharacterDetail
	UPROPERTY(Transient)
	USkillAnimationWidget* SkillAnimationWidget;

	// Bars

	UPROPERTY()
	UNavigationBarWidget* NavigationBarWidget;

	// Fields

	UPROPERTY(EditDefaultsOnly, Category = "UI")
	int32 HideAllWidgetsIntervalTimeSec;
	float HideAllWidgetsTime;

	FNaviBarState NaviBarState;
};
