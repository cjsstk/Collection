#pragma once
#include "LobbyObj_gen.h"
#include "Q6UIDefine.h"
#include "Q6LobbyState.generated.h"

struct FAccountUIState;
struct FBagUIState;
struct FInventoryUIState;
struct FDialogueUIState;
struct FJokerSelectUIState;
struct FFriendUIState;
struct FPartyUIState;
struct FUpgradeUIState;
struct FSagaUIState;
struct FSpecialUIState;
struct FDailyDungeonUIState;
struct FTrainingCenterUIState;
struct FSummonUIState;
struct FInitialRewardEventUIState;
struct FWonderUIState;
struct FRaidUIState;
struct FBondUpResultUIState;
struct FCodexUIState;
struct FWeeklyMissionUIState;
struct FShopUIState;
struct FStoryUIState;

UENUM()
enum class ETopBarType : uint8
{
	None = 0,
	Default = 1,
	CombatReady = 2,
};

USTRUCT()
struct FNaviBarState
{
	GENERATED_USTRUCT_BODY()

	FNaviBarState()
		: TitleText(FText::GetEmpty())
		, TopBarType(ETopBarType::Default)
		, bBottomBarVisible(true)
		, bBackVisible(true) {}

	FNaviBarState(FText InText, ETopBarType InTopBarType, bool bInBottomBarVisible, bool bInBackVisible)
		: TitleText(InText)
		, TopBarType(InTopBarType)
		, bBottomBarVisible(bInBottomBarVisible)
		, bBackVisible(bInBackVisible) {}

	void SetNaviBarState(FText InText, ETopBarType InTopBarType = ETopBarType::Default, bool bInBottomBarVisible = true, bool bInBackVisible = true)
	{
		TitleText = InText;
		TopBarType = InTopBarType;
		bBottomBarVisible = bInBottomBarVisible;
		bBackVisible = bInBackVisible;
	}

	UPROPERTY()
	FText TitleText;

	UPROPERTY()
	ETopBarType TopBarType;

	UPROPERTY()
	bool bBottomBarVisible;

	UPROPERTY()
	bool bBackVisible;
};


USTRUCT()
struct FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FLobbyUIState(){}
	virtual ~FLobbyUIState() {}

public:
	virtual EHUDWidgetType GetHUDWidgetType() const { return EHUDWidgetType::Main; }

	virtual const FLobbySettingUIState* CastToLobbySettingUIState() const { return nullptr; }
	virtual const FInventoryUIState* CastToInventoryUIState() const { return nullptr; }
	virtual const FDialogueUIState* CastToDialogueUIState() const { return nullptr; }
	virtual const FJokerSelectUIState* CastToJokerSelectUIState() const { return nullptr; }
	virtual const FFriendUIState* CastToFriendUIState() const { return nullptr; }
	virtual const FPartyUIState* CastToPartyUIState() const { return nullptr; }
	virtual const FUpgradeUIState* CastToUpgradeUIState() const { return nullptr; }
	virtual const FSagaUIState* CastToSagaUIState() const { return nullptr; }
	virtual const FSpecialUIState* CastToSpecialUIState() const { return nullptr; }
	virtual const FDailyDungeonUIState* CastToDailyDungeonUIState() const { return nullptr; }
	virtual const FTrainingCenterUIState* CastToTrainingCenterUIState() const { return nullptr; }
	virtual const FSummonUIState* CastToSummonUIState() const { return nullptr; }
	virtual const FInitialRewardEventUIState* CastToInitialRewardEventUIState() const { return nullptr; }
	virtual const FWonderUIState* CastToWonderUIState() const { return nullptr; }
	virtual const FRaidUIState* CastToRaidUIState() const { return nullptr; }
	virtual const FBondUpResultUIState* CastToBondUpResultUIState() const { return nullptr; }
	virtual const FCodexUIState* CastToCodexUIState() const { return nullptr; }
	virtual const FWeeklyMissionUIState* CastToWeeklyMissionUIState() const { return nullptr; }
	virtual const FShopUIState* CastToShopUIState() const { return nullptr; }
	virtual const FBagUIState* CastToBagUIState() const { return nullptr; }
	virtual const FEventUIState* CastToEventUIState() const { return nullptr; }
	virtual const FAccountUIState* CastToAccountUIState() const { return nullptr; }
	virtual const FStoryUIState* CastToStoryUIState() const { return nullptr; }

	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const; // Widget Menu Title Setting
	virtual bool GotoBackState() { return false; }
	virtual FString ToString() const;

protected:
	void GetDefaultNaviBar(FNaviBarState& InOutNaviBarState) const;
};

USTRUCT()
struct FLobbySettingUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FLobbySettingUIState() : EditType(ELobbySettingEditType::None) {}
	explicit FLobbySettingUIState(ELobbySettingEditType InEditType) : EditType(InEditType) {}
	virtual ~FLobbySettingUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::LobbySetting; }
	virtual const FLobbySettingUIState* CastToLobbySettingUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	ELobbySettingEditType EditType;
};

USTRUCT()
struct FInventoryUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FInventoryUIState() : InventoryType(EInventoryType::Character), Category(EInventoryCategory::Collection), EditType(EInventoryEdit::None) {}
	explicit FInventoryUIState(EInventoryType InInventoryType, EInventoryCategory InCategory, EInventoryEdit InEditType)
		: InventoryType(InInventoryType), Category(InCategory), EditType(InEditType) {}

	virtual ~FInventoryUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override;
	virtual const FInventoryUIState* CastToInventoryUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	EInventoryType InventoryType;

	UPROPERTY()
	EInventoryCategory Category;

	UPROPERTY()
	EInventoryEdit EditType;
};

USTRUCT()
struct FDialogueUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FDialogueUIState() {}
	virtual ~FDialogueUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Dialogue; }
	virtual const FDialogueUIState* CastToDialogueUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
};


USTRUCT()
struct FPartyUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	explicit FPartyUIState()
		: bIsEdit(false)
		, bIsPetEdit(false)
		, PageNum(1)
		, ItemType(EPartyIconItemType::Character)
		, SelectedSlotIdx(INDEX_NONE)
		, WidgetType(EPartyWidgetType::Party)
		, SagaType(SagaTypeInvalid)
		, EventContentType(EventContentTypeInvalid)
	{}

	virtual ~FPartyUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override;
	virtual const FPartyUIState* CastToPartyUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	bool bIsEdit;

	UPROPERTY()
	bool bIsPetEdit;

	UPROPERTY()
	int32 PageNum;

	UPROPERTY()
	EPartyIconItemType ItemType;

	UPROPERTY()
	int32 SelectedSlotIdx;

	UPROPERTY()
	EPartyWidgetType WidgetType;

	UPROPERTY()
	FSagaType SagaType;

	UPROPERTY()
	FEventContentType EventContentType;
};

USTRUCT()
struct FFriendUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FFriendUIState()
		: FriendMenu(EFriendMenu::MainView)
		, FriendCategory(EFriendCategory::FriendConnected)
		, FriendBookFilter(EFriendBookFilter::All)
	{}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Friend; }
	virtual const FFriendUIState* CastToFriendUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	EFriendMenu FriendMenu;

	UPROPERTY()
	EFriendCategory FriendCategory;

	UPROPERTY()
	EFriendBookFilter FriendBookFilter;
};

USTRUCT()
struct FJokerSelectUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FJokerSelectUIState()
		: FriendMenu(EFriendMenu::MainView)
	{
	}

	virtual ~FJokerSelectUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::JokerSelect; }
	virtual const FJokerSelectUIState* CastToJokerSelectUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	FSagaType SagaType;

	UPROPERTY()
	EFriendMenu FriendMenu;
};

USTRUCT()
struct FUpgradeUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FUpgradeUIState()
		: UpgradeSequence(EUpgradeSequence::Main)
		, Category(EUpgradeCategory::Max)
		, UpgradeMenuIndex(0)
		, ItemId(0)
	{}

	virtual ~FUpgradeUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Upgrade; }
	virtual const FUpgradeUIState* CastToUpgradeUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	EUpgradeSequence UpgradeSequence;

	UPROPERTY()
	EUpgradeCategory Category;

	UPROPERTY()
	int32 UpgradeMenuIndex;

	UPROPERTY()
	int64 ItemId;
};

USTRUCT()
struct FSagaUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FSagaUIState() : SagaTab(ESagaTab::Episode), Episode(0) {}

	virtual ~FSagaUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Saga; }
	virtual const FSagaUIState* CastToSagaUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;
	virtual FString ToString() const override;

	UPROPERTY()
	ESagaTab SagaTab;

	UPROPERTY()
	int32 Episode;

	UPROPERTY()
	FText SagaTitleText;
};

USTRUCT()
struct FSpecialUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FSpecialUIState() : MenuType(ESpecialStageMenuType::Main), Category(ESpecialCategory::None), SpecialType(SpecialTypeInvalid), Wonder(EWonderCategory::Main) {}
	virtual ~FSpecialUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Special; }
	virtual const FSpecialUIState* CastToSpecialUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	ESpecialStageMenuType MenuType;

	UPROPERTY()
	ESpecialCategory Category;

	UPROPERTY()
	FSpecialType SpecialType;

	UPROPERTY()
	EWonderCategory Wonder;
};

USTRUCT()
struct FDailyDungeonUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FDailyDungeonUIState() : MenuType(EDailyDungeonMenuType::Main), DungeonCategory(EDailyDungeonCategory::None) {}

	virtual ~FDailyDungeonUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::DailyDungeon; }
	virtual const FDailyDungeonUIState* CastToDailyDungeonUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	EDailyDungeonMenuType MenuType;

	UPROPERTY()
	EDailyDungeonCategory DungeonCategory;
};

USTRUCT()
struct FTrainingCenterUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FTrainingCenterUIState() {}

	virtual ~FTrainingCenterUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::TrainingCenter; }
	virtual const FTrainingCenterUIState* CastToTrainingCenterUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
};

USTRUCT()
struct FSummonUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FSummonUIState() : Sequence(ESummonSequence::WaitSchedule), FocusPage(1) {}

	virtual ~FSummonUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Summon; }
	virtual const FSummonUIState* CastToSummonUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	UPROPERTY()
	ESummonSequence Sequence;

	UPROPERTY()
	int32 FocusPage;
};

USTRUCT()
struct FInitialRewardEventUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FInitialRewardEventUIState()
		: SagaType(SagaTypeInvalid)
		, WidgetType(EInitialRewardWidgetType::None)
		, RewardIndex(-1)
		, OpenType(ContentFeatureOpenTypeInvalid)
	{}

	FInitialRewardEventUIState(FSagaType InSagaType
		, EInitialRewardWidgetType InWidgetType
		, int32 InRewardIndex
		, FContentFeatureOpenType InOpenType)
		: SagaType(InSagaType)
		, WidgetType(InWidgetType)
		, RewardIndex(InRewardIndex)
		, OpenType(InOpenType)
	{}

	virtual ~FInitialRewardEventUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::InitialRewardEvent; }
	virtual const FInitialRewardEventUIState* CastToInitialRewardEventUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual FString ToString() const override;

	FSagaType SagaType;
	EInitialRewardWidgetType WidgetType;
	int32 RewardIndex;
	FContentFeatureOpenType OpenType;
};

USTRUCT()
struct FWonderUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FWonderUIState() {}
	FWonderUIState(EWonderCategory InCategory) : Category(InCategory), Level(0), SelectedSlot(0) {}
	virtual ~FWonderUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Wonder; }
	virtual const FWonderUIState* CastToWonderUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
	virtual bool GotoBackState() override;

	EWonderCategory Category;
	int32 Level;
	int32 SelectedSlot;	// 1-base
};

USTRUCT()
struct FRaidUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FRaidUIState() {}
	virtual ~FRaidUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Raid; }
	virtual const FRaidUIState* CastToRaidUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
};


USTRUCT()
struct FBondUpResultUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FBondUpResultUIState() {}
	virtual ~FBondUpResultUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::BondUpResult; }
	virtual const FBondUpResultUIState* CastToBondUpResultUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
};

USTRUCT()
struct FCodexUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FCodexUIState()
		: CodexCategory(ECodexCategory::None)
		, bEquipFullView(false)
	{}
	virtual ~FCodexUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Codex; }
	virtual const FCodexUIState* CastToCodexUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;

	UPROPERTY()
	ECodexCategory CodexCategory;

	UPROPERTY()
	bool bEquipFullView;
};

USTRUCT()
struct FWeeklyMissionUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FWeeklyMissionUIState()	{}
	virtual ~FWeeklyMissionUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Mission; }
	virtual const FWeeklyMissionUIState* CastToWeeklyMissionUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
};

USTRUCT()
struct FShopUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FShopUIState() : ShopMenu(EShopMenu::None), bPlayAnim(true) {}
	FShopUIState(EShopMenu InShopMenu, bool bInPlayAnim = true) : ShopMenu(InShopMenu), bPlayAnim(bInPlayAnim) {}
	virtual ~FShopUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Shop; }
	virtual const FShopUIState* CastToShopUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;

	UPROPERTY()
	EShopMenu ShopMenu;

	UPROPERTY()
	bool bPlayAnim;
};

USTRUCT()
struct FBagUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FBagUIState() {}
	virtual ~FBagUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Bag; }
	virtual const FBagUIState* CastToBagUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
};

USTRUCT()
struct FEventUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FEventUIState() : EventContentType(EventContentTypeInvalid), EventMenu(EEventMenu::Main) {}
	virtual ~FEventUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Event; }
	virtual const FEventUIState* CastToEventUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;

	FEventContentType EventContentType;
	EEventMenu EventMenu;
};

USTRUCT()
struct FAccountUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FAccountUIState() {}
	virtual ~FAccountUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Account; }
	virtual const FAccountUIState* CastToAccountUIState() const override { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;
};

USTRUCT()
struct FStoryUIState : public FLobbyUIState
{
	GENERATED_USTRUCT_BODY()

	FStoryUIState() : MenuType(EStoryMenuType::Main), Category(EStoryMenuCategory::DailyDungeon) {}
	virtual ~FStoryUIState() {}

	virtual EHUDWidgetType GetHUDWidgetType() const override { return EHUDWidgetType::Story; }
	virtual const FStoryUIState* CastToStoryUIState() const { return this; }
	virtual void GetNaviBarState(FNaviBarState& InOutNaviBarState) const override;

	EStoryMenuType MenuType;
	EStoryMenuCategory Category;
};
