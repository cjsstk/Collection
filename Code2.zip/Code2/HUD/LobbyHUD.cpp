// Copyright (c) 2015 XLGames, Inc. All rights reserved.

#include "LobbyHUD.h"

#include "AccountWidgets.h"
#include "AchievementsPageWidgets.h"
#include "BagWidgets.h"
#include "CharacterManager.h"
#include "CheckInWidgets.h"
#include "CodexWidgets.h"
#include "CombatReadyWidgets.h"
#include "CombatWidgets.h"
#include "CommonWidgets.h"
#include "DailyDungeonManager.h"
#include "DailyDungeonWidget.h"
#include "DialogueWidget.h"
#include "EventWidgets.h"
#include "FriendWidgets.h"
#include "GameResource.h"
#include "HUDStore.h"
#include "HUDStore/EventManager.h"
#include "InventoryWidgets.h"
#include "ItemWidgets.h"
#include "LevelUtil.h"
#include "LobbyPlayerController.h"
#include "LobbySettingWidgets.h"
#include "MailManager.h"
#include "MailWidgets.h"
#include "MainWidgets.h"
#include "NavigationBarWidgets.h"
#include "PartyWidgets.h"
#include "PlayRecordPopupWidgets.h"
#include "Q6.h"
#include "Q6Account.h"
#include "Q6Capture2D.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "Q6LobbyState.h"
#include "Q6Log.h"
#include "RaidManager.h"
#include "RaidWidgets.h"
#include "RewardManager.h"
#include "SagaManager.h"
#include "SagaWidgets.h"
#include "ShopWidgets.h"
#include "SkillWidgets.h"
#include "SortingWidgets.h"
#include "SpecialManager.h"
#include "SpecialWidgets.h"
#include "SummonWidgets.h"
#include "TrainingCenterManager.h"
#include "TrainingCenterWidget.h"
#include "Tutorial/LobbyTutorial.h"
#include "UIClassResource.h"
#include "UpgradeWidgets.h"
#include "WeeklyMissionWidgets.h"
#include "WidgetUtil.h"
#include "WonderWidgets.h"
#include "StoryWidgets.h"


ALobbyHUD::ALobbyHUD()
	: CurrentHUDWidgetType(EHUDWidgetType::Invalid)
	, LastVisibilityUpdatedHUDWidgetType(EHUDWidgetType::Invalid)
	, bInAppreciation(false)
	, HideAllWidgetsTime(0.f)
{
}

void ALobbyHUD::BeginPlay()
{
	Super::BeginPlay();

	if (CreateWidgetIfNotCreated(&NavigationBarWidget, GetUIClassResource().NavigationBarWidgetClass))
	{
		NavigationBarWidget->AddToViewport(ZORDER_BAR);
	}

	FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &ALobbyHUD::OnPostLoadMap);

	TutorialButtonClickDelegate.BindUObject(this, &ALobbyHUD::TutorialButtonClick);

	LobbyTutorial = GetWorld()->SpawnActor<ALobbyTutorial>(LobbyTutorialClass);
}

void ALobbyHUD::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	FCoreUObjectDelegates::PostLoadMapWithWorld.RemoveAll(this);
	Super::EndPlay(EndPlayReason);
}

void ALobbyHUD::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	HideAllWidgetsTime += DeltaSeconds;
	if (HideAllWidgetsTime >= HideAllWidgetsIntervalTimeSec)
	{
		if ((CurrentHUDWidgetType != EHUDWidgetType::Main) || HasOpenedPopup())
		{
			return;
		}

		if (GetLobbyTutorial())
		{
			if (GetLobbyTutorial()->IsInLobbyTutorial())
			{
				return;
			}
		}

		if (IsUICleared())
		{
			return;
		}

		SetClearUI(true);
	}
}

void ALobbyHUD::OnTouched()
{
	HideAllWidgetsTime = 0;
}

void ALobbyHUD::OnPostLoadMap(UWorld* World)
{
	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	LobbyPC->OnPostLoadMap();
	LobbyTutorial->InitTutorial();
	ACTION_DISPATCH_SortingInit();

	UQ6GameInstance* GameInstance = UQ6GameInstance::Get(this);
	const FDialogueRecord& DialogueRecord = GameInstance->GetDialogueRecord();
	if (DialogueRecord.IsDialogueContinue())
	{
		const FDialogueType PlayingDialogueType = GameInstance->LoadPlayingDialogueType();

		if (PlayingDialogueType == DialogueTypeInvalid)
		{
			GameInstance->ClearDialogueRecord();
			SetHUDType(EHUDWidgetType::Main);
		}
		else
		{
			PlayDialogueContinue(DialogueRecord, PlayingDialogueType);
		}
	}
	else if (GameInstance->HasRewardStep())
	{
		ProcessReward(false);
	}
	else
	{
		const FLobbyUIState* UIState = GetHUDStore().GetUIStateManager().GetUIState();
		if (UIState)
		{
			ChangeHUDType(UIState->GetHUDWidgetType(), true);
		}
		else
		{
			SetHUDType(EHUDWidgetType::Main);
		}
	}

	SetWidgetsVisible(LobbyPC->IsWidgetShowingView());
}

void ALobbyHUD::TutorialButtonClick(FString InSource)
{
	LobbyTutorial->TutorialButtonClick(InSource);
}

void ALobbyHUD::SetHUDType(EHUDWidgetType HUDWidgetType, bool bMenuChanged)
{
	SetHUDInternal(HUDWidgetType, bMenuChanged, true);
}

void ALobbyHUD::ChangeHUDType(EHUDWidgetType HUDWidgetType, bool bMenuChanged)
{
	SetHUDInternal(HUDWidgetType, bMenuChanged, false);
}

void ALobbyHUD::ChangeHUDTypeIfNot(EHUDWidgetType HUDWidgetType, bool bMenuChanged)
{
	if (CurrentHUDWidgetType != HUDWidgetType)
	{
		ChangeHUDType(HUDWidgetType, bMenuChanged);
	}
}

void ALobbyHUD::SetHUDInternal(EHUDWidgetType HUDWidgetType, bool bMenuChanged, bool bClearHistory)
{
	const UUIStateManager& UIMgr = GetHUDStore().GetUIStateManager();

	ULobbyHUDWidget* CurrentHUDWidget = GetHUDWidget(CurrentHUDWidgetType);
	if (CurrentHUDWidget)
	{
		if (CurrentHUDWidgetType == HUDWidgetType)
		{
			if (!bMenuChanged)
			{
				ACTION_DISPATCH_MenuChange(HUDWidgetType, bClearHistory);
			}

			Q6SetStringToFirebaseCrashlytics("Widget", ENUM_TO_STRING(EHUDWidgetType, HUDWidgetType));

			CurrentHUDWidget->RefreshMenu();
			LobbyTutorial->OnChangeHUDWidget(CurrentHUDWidgetType);
			return;
		}

		CurrentHUDWidget->OnLeaveMenu();
		CurrentHUDWidget->RemoveFromViewport();
	}

	CurrentHUDWidgetType = HUDWidgetType;

	// Note : Some Widget needs to check if which actor is visible.
	// So, this must be called before initialize new widget
	if (ShouldUpdateActorVisibility())
	{
		UpdateActorVisibility(GetCurrentHUDWidgetLayerName());
	}

	ULobbyHUDWidget* NewHUDWidget = GetHUDWidget(HUDWidgetType);
	if (NewHUDWidget)
	{
		if (!bMenuChanged)
		{
			ACTION_DISPATCH_MenuChange(HUDWidgetType, bClearHistory);
		}

		NewHUDWidget->AddToViewport(ZORDER_HUDWIDGET);
		NewHUDWidget->OnEnterMenu();
		NewHUDWidget->RefreshMenu();

		Q6SetStringToFirebaseCrashlytics("Widget", ENUM_TO_STRING(EHUDWidgetType, HUDWidgetType));
	}

	LobbyTutorial->OnChangeHUDWidget(CurrentHUDWidgetType);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	LobbyPC->OnChangeHUDWidget(CurrentHUDWidgetType);

	GEngine->ForceGarbageCollection();

	SetClearUI(false);
}

ULobbyHUDWidget* ALobbyHUD::GetHUDWidget(EHUDWidgetType HUDWidgetType)
{
	UUIClassResource& UIClasses = GetUIClassResource();

	switch (HUDWidgetType)
	{
	case EHUDWidgetType::Main:
		CreateWidgetIfNotCreated(&MainWidget, UIClasses.MainWidgetClass);
		return MainWidget;
	case EHUDWidgetType::LobbySetting:
		CreateWidgetIfNotCreated(&LobbySettingWidget, UIClasses.LobbySettingWidgetClass);
		return LobbySettingWidget;
	case EHUDWidgetType::Saga:
		CreateWidgetIfNotCreated(&SagaWidget, UIClasses.SagaWidgetClass);
		return SagaWidget;
	case EHUDWidgetType::Collection:
	case EHUDWidgetType::StorageBox:
		CreateWidgetIfNotCreated(&InventoryWidget, UIClasses.InventoryWidgetClass);
		return InventoryWidget;
	case EHUDWidgetType::Summon:
		CreateWidgetIfNotCreated(&SummonWidget, UIClasses.SummonWidgetClass);
		return SummonWidget;
	case EHUDWidgetType::Dialogue:
		CreateWidgetIfNotCreated(&DialogueWidget, UIClasses.DialogueWidgetClass);
		return DialogueWidget;
	case EHUDWidgetType::Party:
	case EHUDWidgetType::Joker:
		CreateWidgetIfNotCreated(&PartyWidget, UIClasses.PartyWidgetClass);
		return PartyWidget;
	case EHUDWidgetType::JokerSelect:
		CreateWidgetIfNotCreated(&JokerSelectWidget, UIClasses.JokerSelectWidgetClass);
		return JokerSelectWidget;
	case EHUDWidgetType::Upgrade:
		CreateWidgetIfNotCreated(&UpgradeWidget, UIClasses.UpgradeWidgetClass);
		return UpgradeWidget;
	case EHUDWidgetType::Special:
		CreateWidgetIfNotCreated(&SpecialWidget, UIClasses.SpecialWidgetClass);
		return SpecialWidget;
	case EHUDWidgetType::Friend:
		CreateWidgetIfNotCreated(&FriendWidget, UIClasses.FriendWidgetClass);
		return FriendWidget;
	case EHUDWidgetType::DailyDungeon:
		CreateWidgetIfNotCreated(&DailyDungeonWidget, UIClasses.DailyDungeonWidgetClass);
		return DailyDungeonWidget;
	case EHUDWidgetType::TrainingCenter:
		CreateWidgetIfNotCreated(&TrainingCenterWidget, UIClasses.TrainingCenterWidgetClass);
		return TrainingCenterWidget;
	case EHUDWidgetType::InitialRewardEvent:
		CreateWidgetIfNotCreated(&InitialRewardEventWidget, UIClasses.InitialRewardEventWidgetClass);
		return InitialRewardEventWidget;
	case EHUDWidgetType::Wonder:
		CreateWidgetIfNotCreated(&WonderWidget, UIClasses.WonderWidgetClass);
		return WonderWidget;
	case EHUDWidgetType::Raid:
		CreateWidgetIfNotCreated(&RaidWidget, UIClasses.RaidWidgetClass);
		return RaidWidget;
	case EHUDWidgetType::BondUpResult:
		CreateWidgetIfNotCreated(&BondUpResultWidget, UIClasses.BondUpResultWidgetClass);
		return BondUpResultWidget;
	case EHUDWidgetType::Codex:
		CreateWidgetIfNotCreated(&CodexWidget, UIClasses.CodexWidgetClass);
		return CodexWidget;
	case EHUDWidgetType::Mission:
		CreateWidgetIfNotCreated(&WeeklyMissionWidget, UIClasses.WeeklyMissionWidgetClass);
		return WeeklyMissionWidget;
	case EHUDWidgetType::Shop:
		CreateWidgetIfNotCreated(&ShopWidget, UIClasses.ShopWidgetClass);
		return ShopWidget;
	case EHUDWidgetType::Bag:
		CreateWidgetIfNotCreated(&BagWidget, UIClasses.BagWidgetClass);
		return BagWidget;
	case EHUDWidgetType::Event:
		CreateWidgetIfNotCreated(&EventMainWidget, UIClasses.EventMainWidgetClass);
		return EventMainWidget;
	case EHUDWidgetType::Account:
		CreateWidgetIfNotCreated(&AccountWidget, UIClasses.AccountWidgetClass);
		return AccountWidget;
	case EHUDWidgetType::Story:
		CreateWidgetIfNotCreated(&StoryWidget, UIClasses.StoryWidgetClass);
		return StoryWidget;
	default:
		return MainWidget;
	}
}

ABaseTutorial* ALobbyHUD::GetTutorial()
{
	return LobbyTutorial;
}

ALobbyTutorial* ALobbyHUD::GetLobbyTutorial()
{
	return LobbyTutorial;
}

bool ALobbyHUD::GotoBack(bool bForced)
{
	if (Super::GotoBack(bForced))
	{
		if (!NaviBarState.bBackVisible && !bForced)
		{
			return false;
		}

		ULobbyHUDWidget* LobbyHUDWidget = GetHUDWidget(CurrentHUDWidgetType);
		if (LobbyHUDWidget->OnBack())
		{
			ACTION_DISPATCH_MenuBack();
			RefreshHUD();
			return true;
		}
	}

	return false;
}

void ALobbyHUD::ProcessReward(bool bMenuBack)
{
	if (bMenuBack)
	{
		ACTION_DISPATCH_MenuBack();
	}

	UQ6GameInstance* GameInstance = UQ6GameInstance::Get(this);
	check(GameInstance);

	FSagaType SagaType = GameInstance->GetRewardSagaType();

	FRewardStep RewardStep;
	GameInstance->HeapPopRewardStep(RewardStep);

	switch (RewardStep.RewardSequence)
	{
		case ERewardSequence::Bond:
			ChangeHUDType(EHUDWidgetType::BondUpResult);
			break;
		case ERewardSequence::Outro:
			OnOutroReward(SagaType, RewardStep);
			break;
		case ERewardSequence::WeedGrow:
			OnWeedGrowReward(RewardStep.WeedGrowType);
			break;
		case ERewardSequence::StageClear:
		case ERewardSequence::DailyFirstClear:
		case ERewardSequence::VacationReward:
		case ERewardSequence::TrainingPhaseClear:
		case ERewardSequence::EpisodeClear:
		case ERewardSequence::FoundRaid:
		case ERewardSequence::WonderOpen:
		case ERewardSequence::WonderReward:
			OnInitailReward(SagaType, RewardStep);
			break;
		case ERewardSequence::ContentOpenGuide:
			OnContentOpenGuide(SagaType, RewardStep);
			break;
		case ERewardSequence::Title:
			OnTitleReward(RewardStep);
			break;
		case ERewardSequence::None:
			 RefreshsHUDCheckMoviePlay(SagaType);
			break;
	}
}

void ALobbyHUD::RefreshsHUDCheckMoviePlay(FSagaType SagaType)
{
	const UCMS* CMS = GetCMS();
	const FCMSSagaRow& SagaRow = CMS->GetSagaRowOrDummy(SagaType);
	ULevelUtil::PlayMovie(SagaRow.Episode, SagaRow.Stage, SagaRow.SubStage,
		FSimpleDelegate::CreateLambda([this]()
	{
		RefreshHUD();
	}));
}

void ALobbyHUD::SetWidgetsVisible(bool bInVisible)
{
	Super::SetWidgetsVisible(bInVisible);

	ULobbyHUDWidget* HUDWidget = GetCurrentHUDWidget();
	if (HUDWidget)
	{
		HUDWidget->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
	}

	NavigationBarWidget->SetVisibility(bInVisible ? ESlateVisibility::SelfHitTestInvisible : ESlateVisibility::Collapsed);
}

void ALobbyHUD::SetShowMainWidgets(bool bInShow)
{
	if (!bInShow && IsUICleared())
	{
		SetClearUI(false, false);
		return;
	}

	SetWidgetsVisible(true);

	if (MainWidget)
	{
		MainWidget->SetShow(bInShow);
	}

	if (NavigationBarWidget)
	{
		NavigationBarWidget->SetShow(bInShow);
	}
}

void ALobbyHUD::StopMainWidgetsAnimations()
{
	if (MainWidget)
	{
		MainWidget->StopAllAnimations();
	}

	if (NavigationBarWidget)
	{
		NavigationBarWidget->StopAllAnimations();
	}
}

void ALobbyHUD::UpdateAppreciationActorVisibility(bool bInVisible)
{
	FName LayerName = bInVisible ? "Appreciation" : GetCurrentHUDWidgetLayerName();
	UpdateActorVisibility(LayerName);

	bInAppreciation = bInVisible;
}

bool ALobbyHUD::PlaySkillAnimation(FUnitType LobbyUnitType)
{
	const FCMSUnitRow& UnitRow = GetCMS()->GetUnitRowOrDummy(LobbyUnitType);

	const FUltimateSkillSequenceAssetRow& UltimateSkillSequenceAssetRow = GetGameResource().GetModelUltimateSkillSequenceAssetRow(UnitRow.Model, false);
	if (UltimateSkillSequenceAssetRow.WidgetAnimationClass.IsNull())
	{
		return false;
	}

	if (!UltimateSkillSequenceAssetRow.WidgetAnimationClass.Get())
	{
		UltimateSkillSequenceAssetRow.WidgetAnimationClass.LoadSynchronous();
	}

	SkillAnimationWidget = CreateWidget<USkillAnimationWidget>(PlayerOwner, UltimateSkillSequenceAssetRow.WidgetAnimationClass.Get());
	check(SkillAnimationWidget);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		SkillAnimationWidget->SkillAnimFinishedDelegate.BindUObject(LobbyPC, &ALobbyPlayerController::ResumeSequencePlayer);
	}

	SkillAnimationWidget->PlaySkillAnimation(UnitRow.GetUltimateSkills()[0]->Type, UltimateSkillSequenceAssetRow);

	UCommonSkillAnimationWidget* CommonSkillAnimWidget = Cast<UCommonSkillAnimationWidget>(SkillAnimationWidget);
	if (CommonSkillAnimWidget)
	{
		CommonSkillAnimWidget->PlayNatureAnimation(UnitRow.NatureType);
	}

	return true;
}

void ALobbyHUD::StopSkillAnimation()
{
	if (SkillAnimationWidget)
	{
		SkillAnimationWidget->StopSkillAnimation();
	}
}

void ALobbyHUD::ReEnterHUD()
{
	ULobbyHUDWidget* CurrentHUDWidget = GetHUDWidget(CurrentHUDWidgetType);
	if (CurrentHUDWidget)
	{
		ACTION_DISPATCH_MenuChange(CurrentHUDWidgetType, true);

		CurrentHUDWidget->OnEnterMenu();
		CurrentHUDWidget->RefreshMenu();
		LobbyTutorial->OnChangeHUDWidget(CurrentHUDWidgetType);
	}
}

void ALobbyHUD::RefreshHUD()
{
	const FLobbyUIState* LobbyUIState = GetHUDStore().GetUIStateManager().GetUIState();
	if (LobbyUIState)
	{
		if (LobbyUIState->GetHUDWidgetType() != CurrentHUDWidgetType)
		{
			ChangeHUDType(LobbyUIState->GetHUDWidgetType(), true);
		}
		else
		{
			ULobbyHUDWidget* CurHUDWidget = GetHUDWidget(CurrentHUDWidgetType);
			if (CurHUDWidget)
			{
				CurHUDWidget->RefreshMenu();
			}
		}
	}
}

void ALobbyHUD::SetBackEnabled(bool bInEnabled)
{
	NavigationBarWidget->SetBackButtonVisible(bInEnabled);
}

void ALobbyHUD::RefreshNaviBar()
{
	const UUIStateManager& UIMgr = GetHUDStore().GetUIStateManager();

	if (const FLobbyUIState* UIState = UIMgr.GetUIState())
	{
		UIState->GetNaviBarState(NaviBarState);
		NavigationBarWidget->SetNaviBar(UIState->GetHUDWidgetType(), NaviBarState);
		NavigationBarWidget->RefreshMenuButtons(UIMgr.GetRootHUDWidgetType());
	}
}

void ALobbyHUD::PlayDialogueContinue(const FDialogueRecord& DialogueRecord, const FDialogueType PlayingDialogueType)
{
	ChangeHUDTypeIfNot(EHUDWidgetType::Dialogue);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->PlayContinue(DialogueRecord, PlayingDialogueType);
	}
}

void ALobbyHUD::PlaySagaWithStoryClear(FSagaType InSagaType, bool bInPrologue, bool bInReplay)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(InSagaType);
	if (IsStoryLikeStageType(SagaRow.StageType) && !bInReplay)
	{
		UQ6GameInstance* GameInstance = UQ6GameInstance::Get(this);
		check(GameInstance);

		GameInstance->RequestSagaStoryStage(InSagaType);
	}

	PlaySaga(InSagaType, bInPrologue, bInReplay);
}

void ALobbyHUD::PlayDaily(EDayOfWeekType InDayOfWeek, bool bInReplay)
{
	ChangeHUDTypeIfNot(EHUDWidgetType::Dialogue);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->PlayDaily(InDayOfWeek, bInReplay);
	}
}

void ALobbyHUD::PlayTraining(FTrainingCenterType InTraingType, FSagaType InSagaType, bool bInPrologue, bool bInReplay)
{
	ChangeHUDTypeIfNot(EHUDWidgetType::Dialogue);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->PlayTraining(InTraingType, InSagaType, bInPrologue, bInReplay);
	}
}

void ALobbyHUD::PlayVacation(const FVacationResult& InResult)
{
	ChangeHUDTypeIfNot(EHUDWidgetType::Dialogue);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->PlayVacation(InResult);
	}
}

void ALobbyHUD::PlayValentineDayEventWithStoryClear(FEventContentValentineDayType InValentineDayType, bool bInPrologue, bool bInReplay)
{
	const FCMSEventContentValentineDayRow& Row = GetCMS()->GetEventContentValentineDayRowOrDummy(InValentineDayType);
	const FCMSSagaRow& SagaRow = Row.GetSaga();

	if (IsStoryLikeStageType(SagaRow.StageType) && !bInReplay)
	{
		GetHUDStore().GetEventManager().ReqEventContentValentineDayStoryStageClear(InValentineDayType, SagaRow.CmsType());
	}

	PlayEvent(Row.GetEventContent().CmsType(), SagaRow.CmsType(), bInPrologue, bInReplay);
}

void ALobbyHUD::PlayMultisideBattleWithStoryClear(FEventContentMultiSideBattleStageType InMultisideBattleStageType, bool bInPrologue, bool bInReplay)
{
	const FCMSEventContentMultiSideBattleStageRow& Row = GetCMS()->GetEventContentMultiSideBattleStageRowOrDummy(InMultisideBattleStageType);
	const FCMSSagaRow& SagaRow = Row.GetSaga();

	if (IsStoryLikeStageType(SagaRow.StageType) && !bInReplay)
	{
		GetHUDStore().GetEventManager().ReqEventContentMultiSideBattleStoryStageClear(InMultisideBattleStageType);
	}

	PlayEvent(Row.GetEventContent().CmsType(), SagaRow.CmsType(), bInPrologue, bInReplay);
}

void ALobbyHUD::PlaySaga(FSagaType InSagaType, bool bInPrologue, bool bInReplay)
{
	ChangeHUDTypeIfNot(EHUDWidgetType::Dialogue);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->PlaySaga(InSagaType, bInPrologue, bInReplay);
	}
}

void ALobbyHUD::PlayEvent(FEventContentType InEventContentType, FSagaType InSagaType, bool bInPrologue, bool bInReplay)
{
	ChangeHUDTypeIfNot(EHUDWidgetType::Dialogue);

	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->PlayEvent(InEventContentType, InSagaType, bInPrologue, bInReplay);
	}
}

void ALobbyHUD::GotoDialogue(int32 GotoId)
{
	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->GotoDialogue(GotoId);
	}
}

bool ALobbyHUD::HasPlayableDialogue(FSagaType InSagaType)
{
	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		return LobbyPC->HasPlayableDialogue(InSagaType);
	}

	return false;
}

void ALobbyHUD::OpenDailyDungeon()
{
	SetHUDType(EHUDWidgetType::DailyDungeon);

	if (UQ6SaveGame* SaveGameInstance = UQ6GameInstance::Get(this)->GetSaveGame())
	{
		if (SaveGameInstance->IsFirstDailyDungeonOnToday())
		{
			EDayOfWeekType DayOfWeek = GetHUDStore().GetDailyDungeonManager().GetDayOfWeekType();
			SaveGameInstance->UpdateDailyDungeonDate();

			PlayDaily(DayOfWeek, false);
		}
	}
}

void ALobbyHUD::OnStoryStageClear()
{
	ALobbyPlayerController* LobbyPC = CastChecked<ALobbyPlayerController>(PlayerOwner);
	if (LobbyPC)
	{
		LobbyPC->OnStoryStageClear();
	}
}

UUpgradeResultWidget* ALobbyHUD::OpenUpgradeResultPopup()
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().UpgradeResultWidgetClass);
	return CastChecked<UUpgradeResultWidget>(BasePopup);
}

UItemMaxLevelUpConfirmPopupWidget* ALobbyHUD::OpenPromoteConfirmPopup()
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().PromoteConfirmPopupWidgetClass);
	return CastChecked<UItemMaxLevelUpConfirmPopupWidget>(BasePopup);
}

UItemRewardPopupWidget* ALobbyHUD::OpenItemRewardPopup(FSagaType SagaType, bool bVisibleCount, bool bAllowDuplicated)
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().ItemRewardPopupWidgetClass);
	UItemRewardPopupWidget* ItemRewardPopup = CastChecked<UItemRewardPopupWidget>(BasePopup);
	if (ItemRewardPopup)
	{
		ItemRewardPopup->SetReward(SagaType, bVisibleCount, bAllowDuplicated);
	}

	return ItemRewardPopup;
}

UItemRewardPopupWidget* ALobbyHUD::OpenItemRewardPopup(const TArray<FRewardInfo>& RewardInfos)
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().ItemRewardPopupWidgetClass);
	UItemRewardPopupWidget* ItemRewardPopup = CastChecked<UItemRewardPopupWidget>(BasePopup);
	if (ItemRewardPopup)
	{
		ItemRewardPopup->SetReward(RewardInfos);
	}

	return ItemRewardPopup;
}

UItemRewardPopupWidget* ALobbyHUD::OpenItemRewardPopup(FEventContentType InEventContentType, FSagaType SagaType, bool bVisibleCount, bool bAllowDuplicated)
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().ItemRewardPopupWidgetClass);
	UItemRewardPopupWidget* ItemRewardPopup = CastChecked<UItemRewardPopupWidget>(BasePopup);
	if (ItemRewardPopup)
	{
		ItemRewardPopup->SetReward(InEventContentType, SagaType, bVisibleCount, bAllowDuplicated);
	}

	return ItemRewardPopup;
}

USkillUpgradeConfirmPopupWidget * ALobbyHUD::OpenSkillUpgradeConfirmPopup()
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().SkillUpgradeConfirmPopupClass);
	USkillUpgradeConfirmPopupWidget * SkillConfirmPopupWidget = CastChecked<USkillUpgradeConfirmPopupWidget>(BasePopup);
	if (SkillConfirmPopupWidget)
	{
		SkillConfirmPopupWidget->SetConfirmFlags(EConfirmPopupFlag::Yes | EConfirmPopupFlag::No);
	}

	return SkillConfirmPopupWidget;
}

USortingChangePopupWidget* ALobbyHUD::OpenSortingChangePopup(ESortMenu SortMenu, ESortCategory Category)
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().SortingOrderFilterPopupWidgetClass);
	USortingChangePopupWidget* SortingChangePopupWidget = CastChecked<USortingChangePopupWidget>(BasePopup);
	if (SortingChangePopupWidget)
	{
		SortingChangePopupWidget->SetConfirmFlags(EConfirmPopupFlag::Yes | EConfirmPopupFlag::No);
		SortingChangePopupWidget->SetSortingOption(SortMenu, Category);
	}

	return SortingChangePopupWidget;
}

UFriendshipCollectPopupWidget* ALobbyHUD::OpenFriendshipCollectPopup()
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().FriendshipCollectPopupWidgetClass);
	return CastChecked<UFriendshipCollectPopupWidget>(BasePopup);
}

UItemSelectPopupWidget* ALobbyHUD::OpenVacationCharacterListPopup()
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().ItemSelectPopupWidgetClass);
	UItemSelectPopupWidget* SelectItemPopup = CastChecked<UItemSelectPopupWidget>(BasePopup);
	if (SelectItemPopup)
	{
		SelectItemPopup->SetVacation();
	}

	return SelectItemPopup;
}

UItemSelectPopupWidget* ALobbyHUD::OpenPortalConnectItemListPopup(EPortalType PortalType, bool bConnect)
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().ItemSelectPopupWidgetClass);
	UItemSelectPopupWidget* PortalConnectItemListPopup = CastChecked<UItemSelectPopupWidget>(BasePopup);
	if (PortalConnectItemListPopup)
	{
		PortalConnectItemListPopup->SetPortal(PortalType, bConnect);
	}

	return PortalConnectItemListPopup;
}

UMailListPopupWidget* ALobbyHUD::OpenMailListPopup()
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().MailListPopupWidgetClass);
	UMailListPopupWidget* MailListPopup = CastChecked<UMailListPopupWidget>(BasePopup);
	if (MailListPopup)
	{
		const UMailManager& MailManager = GetHUDStore().GetMailManager();
		MailManager.ReqRefreshList();
		MailListPopup->Refresh();
	}

	return MailListPopup;
}

UCheckInBaseWidget* ALobbyHUD::OpenCheckInPopup(FCheckInBoardType BoardType, const FCheckInAssetRow& CheckInAssetRow)
{
	check(!CheckInAssetRow.BoardWidgetClass.IsNull());

	UPopupBaseWidget* BasePopup = OpenPopup(CheckInAssetRow.BoardWidgetClass);
	UCheckInBaseWidget* CheckInPopupWidget = CastChecked<UCheckInBaseWidget>(BasePopup);
	CheckInPopupWidget->SetBoard(BoardType, CheckInAssetRow);

	return CheckInPopupWidget;
}

UItemReceivedPopupWidget* ALobbyHUD::OpenItemReceivedPopup()
{
	return CastChecked<UItemReceivedPopupWidget>(OpenPopup(GetUIClassResource().ItemReceivedPopupWidgetClass));
}

UAchievementsPageWidget* ALobbyHUD::OpenAchievementsPagePopup()
{
	return CastChecked<UAchievementsPageWidget>(
		OpenPopup(GetUIClassResource().AchievementsPageWidgetClass));
}

UAchievementsPuzzleWidget* ALobbyHUD::OpenAchievementPuzzlePopup()
{
	return CastChecked<UAchievementsPuzzleWidget>(
		OpenPopup(GetUIClassResource().AchievementsPuzzleWidgetClass));
}

UPlayRecordPopupWidget* ALobbyHUD::OpenPlayRecordPopup()
{
	UPlayRecordPopupWidget* PlayRecordPopup = CastChecked<UPlayRecordPopupWidget>(
		OpenPopup(GetUIClassResource().PlayRecordPopupWidgetClass));

	PlayRecordPopup->InitPlayRecordPopup();

	return PlayRecordPopup;
}

USellShopPurchasePopupWidget* ALobbyHUD::OpenSellShopPurchasePopupWidget()
{
	return CastChecked<USellShopPurchasePopupWidget>(OpenPopup(GetUIClassResource().SellShopPurchasePopupWidgetClass));
}

UMailReceivedPopupWidget* ALobbyHUD::OpenMailReceivedPopupWidget(const TArray<FMailInfo> RewardInfos)
{
	UPopupBaseWidget* BasePopup = OpenPopup(GetUIClassResource().MailReceivedPopupWidgetClass);
	UMailReceivedPopupWidget* MailReceivedPopup = CastChecked<UMailReceivedPopupWidget>(BasePopup);
	if (MailReceivedPopup)
	{
		MailReceivedPopup->SetMailLists(RewardInfos);
	}

	return MailReceivedPopup;
}

UGetAkaConfirmPopupWidget* ALobbyHUD::OpenGetAkaConfirmPopup(FUserTitleType InUserTitleType)
{
	UGetAkaConfirmPopupWidget* GetAkaConfirmPopup = CastChecked<UGetAkaConfirmPopupWidget>(
		GetCheckedLobbyHUD(this)->OpenPopup(GetUIClassResource().GetAkaConfirmPopupWidgetClass));
	GetAkaConfirmPopup->InitGetAkaConfirmPopup(InUserTitleType);

	return GetAkaConfirmPopup;
}

bool ALobbyHUD::ShouldUpdateActorVisibility()
{
	if (LastVisibilityUpdatedHUDWidgetType == CurrentHUDWidgetType)
	{
		return false;
	}

	switch (LastVisibilityUpdatedHUDWidgetType)
	{
		case EHUDWidgetType::Main:
			return CurrentHUDWidgetType != EHUDWidgetType::LobbySetting;
		case EHUDWidgetType::Dialogue:
			return true;
		default:
			break;
	}

	switch (CurrentHUDWidgetType)
	{
		case EHUDWidgetType::Main:
		case EHUDWidgetType::Dialogue:
		case EHUDWidgetType::Codex:
			return true;
		default:
			return false;
	}

	return false;
}

FName ALobbyHUD::GetCurrentHUDWidgetLayerName()
{
	switch (CurrentHUDWidgetType)
	{
		case EHUDWidgetType::Dialogue:
			return "Dialogue";
		case EHUDWidgetType::Main:
		case EHUDWidgetType::LobbySetting:
			return "Lobby";
		case EHUDWidgetType::Codex:
			return "Showcase";
		default:
			return "";
	}
}

void ALobbyHUD::UpdateActorVisibility(FName LayerName)
{
	ULevelUtil::LayerActorVisibilityChange(GetWorld(), LayerName);

	LastVisibilityUpdatedHUDWidgetType = CurrentHUDWidgetType;
}

void ALobbyHUD::OnOutroReward(FSagaType SagaType, const FRewardStep& RewardStep)
{
	if (RewardStep.TrainingCenterType != TrainingCenterTypeInvalid)
	{
		PlayTraining(RewardStep.TrainingCenterType, SagaType, false, false);
	}
	else if (RewardStep.EventContentType != EventContentTypeInvalid)
	{
		PlayEvent(RewardStep.EventContentType, SagaType, false, false);
	}
	else
	{
		PlaySaga(SagaType, false, false);
	}
}

void ALobbyHUD::OnInitailReward(FSagaType SagaType, const FRewardStep& RewardStep)
{
	FInitialRewardEventUIState UIState;
	UIState.SagaType = SagaType;
	UIState.RewardIndex = RewardStep.RewardIndex;
	UIState.OpenType = RewardStep.ContentFeatureOpenType;

	switch (RewardStep.RewardSequence)
	{
		case ERewardSequence::VacationReward:
			UIState.WidgetType = EInitialRewardWidgetType::VacationReward;
			break;
		case ERewardSequence::FoundRaid:
			UIState.WidgetType = EInitialRewardWidgetType::FoundRaid;
			break;
		case ERewardSequence::WonderOpen:
			UIState.WidgetType = EInitialRewardWidgetType::WonderOpen;
			break;
		case ERewardSequence::WonderReward:
			UIState.WidgetType = EInitialRewardWidgetType::WonderReward;
			break;
		default:
			UIState.WidgetType = EInitialRewardWidgetType::RewardItem;
			break;
	}

	ACTION_DISPATCH_InitialRewardEventOpen(UIState);
	ChangeHUDType(EHUDWidgetType::InitialRewardEvent, true);
}

void ALobbyHUD::OnWeedGrowReward(FWeedGrowType WeedGrowType)
{
	if (WeedGrowType == WeedGrowTypeInvalid)
	{
		return;
	}

	FCharacterInfo WeedInfo;
	if (!GetHUDStore().GetCharacterManager().GetMyWeedInfo(WeedInfo))
	{
		return;
	}

	UUpgradeResultWidget* ResultPopup = OpenUpgradeResultPopup();
	if (ResultPopup)
	{
		ResultPopup->SetWeedGrowResult(WeedGrowType, WeedInfo);
		ResultPopup->OnPopupClosedDelegate.BindUObject(this, &ALobbyHUD::ProcessReward, false);
	}
}

void ALobbyHUD::OnContentOpenGuide(FSagaType SagaType, const FRewardStep& RewardStep)
{
	if (!GetGameResource().GetGuideActionAssetRow(RewardStep.ContentFeatureOpenType))
	{
		ProcessReward(false);
		return;
	}

	RefreshHUD();
	ShowGuidePopup(RewardStep);
}

void ALobbyHUD::OnTitleReward(const FRewardStep& RewardStep)
{
	RefreshHUD();

	OpenGetAkaConfirmPopup(RewardStep.UserTitleType);
}
