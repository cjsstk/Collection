// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseHUD.h"
#include "Widget/LoginHUDWidget.h"
#include "Q6ClientNetwork.h"

#include "LoginHUD.generated.h"

class UQ6GameInstance;
class ULoginHUDWidget;

struct FLobbyUIState;

enum class EHUDWidgetType : uint8;

UCLASS()
class Q6_API ALoginHUD : public ABaseHUD
{
	GENERATED_BODY()

public:
	ALoginHUD();

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;
	virtual void Tick(float DeltaSeconds) override;

private:

	void OnNetworkStartConnect() override;
	void OnNetworkMaintenance(const FMaintenanceInfo& Info) override;
	void OnNetworkConnected() override;
	void OnNetworkConnectFailed() override;
	void OnNetworkReady(UQ6GameInstance* GameInstance);
	void OnNetworkDisconnected() override;
	void OnNetworkLogin(const FL2CAuthLoginResp& Res) override;
	void OnNetworkEnteringLobby() override;
	void OnNetworkEnteredLobby(const FL2CAuthEnterLobbyResp& Res);
	void OnNetworkEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp);
	void OnNetworkStartBlockingRequest() override {}
	void OnNetworkEndBlockingRequest() override {}

	void OnBackgroundTimeout() override;

	void HandleError();

	void OnConfirmOnGoingChronicle(EConfirmPopupFlag InConfirmFlag, FSagaType NotFinishedSagaType);
	void OnConfirmOngoingExpire(EConfirmPopupFlag InConfirmFlag);
	void OnDialogueContinue(EConfirmPopupFlag InConfirmFlag);
	void OnDialogueExpired();

	void CancelStage();

	void SetDefaultVisibility();

	void OpenDialogueContinueConfirmPopup();
	void OpenDialogueExpiredConfirmPopup();
	void OpenRaidFinalConfirmPopup();
	void OpenOngoingContinueConfirmPopup(const FSagaType SagaType, const int64 RemainTime);
	void OpenExpireConfirmPopup(FSagaType SagaType);
	void RefreshOngoingPopup();

	void OpenLobbyMenu(EHUDWidgetType WidgetType);

	UPROPERTY(EditDefaultsOnly, Category = "LoginHUDWidget")
	TSubclassOf<ULoginHUDWidget> LoginHUDWidgetClass;

	UPROPERTY()
	ULoginHUDWidget* LoginHUDWidget;

	UPROPERTY()
	UConfirmPopupWidget* ConfirmPopup;

	FSagaType OngoingSagaType;
	int32 ExpireTime;
};
