// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "BaseHUD.h"
#include "Widget/PatchHUDWidget.h"
#include "Q6ClientNetwork.h"

#include "PatchHUD.generated.h"

class UQ6GameInstance;

UCLASS()
class Q6_API APatchHUD : public ABaseHUD
{
	GENERATED_BODY()

public:
	APatchHUD();

	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:

	UPROPERTY(EditDefaultsOnly, Category = "PatchHUDWidget")
	TSubclassOf<UPatchHUDWidget> PatchHUDWidgetClass;

	UPROPERTY()
	UPatchHUDWidget* PatchHUDWidget;
};
