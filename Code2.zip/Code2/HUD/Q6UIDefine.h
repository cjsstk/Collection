#pragma once
#include "CMS_gen.h"
#include "Q6UIDefine.generated.h"

struct FCharacterId;
struct FCharacterType;
struct FUserId;
struct FCharacterInfo;
struct FFriendInfo;

const int32 ITEM_INVALID = 0;
const int32 ITEM_TYPE_INVALID = 0;
const int32 MAX_PARTY_COUNT = 6;
const int32 PARTY_JOKER_SLOT_INDEX = 2;
const int32 SUB_PARTY_CHARACTER_FIRST_SLOT = 3;
const int32 SUB_PARTY_CHARACTER_SECOND_SLOT = 4;
const int32 SUB_PARTY_CHARACTER_THIRD_SLOT = 5;
const int32 MAX_JOKERSET_COUNT = 3;
const int32 MAX_JOKER_SLOT = 6;
const int32 MAX_REWARD_ICON_COUNT = 5;
const int32 MAX_BOND_ICON_COUNT = 6;
const int32 MAX_STAT_COUNT = 3;
const int32 MAX_DAY_COUNT = 7;
const int32 LENGTH_OF_WEEK = 7;
const int32 MAX_NUM_OF_NATURE = 5;
const int32 MAX_BOND_UP_REWARD_ICON = 3;
const int32 MAX_BOND_REWARD = 2;
const int32 MIN_RAID_TIME_DIGIT = 2;
const int32 MAX_RAID_EMOTICON_COUNT = 10;
const int32 MAX_BONUS_REWARD_MARK = 10;
const int32 RAID_EMOTICON_INTERVAL_TIME = 10;
const int32 MAX_LOBBY_TEMPLATE_CHAR_SLOT_COUNT = 6;
const int32 MAX_LOBBY_SET_INFO_COUNT = 5;
const int32 MAX_MISSION_BINGO_BOARD_SIZE = 3;
const int32 MAX_CHAR_MISSION_PUZZLE_BOARD_SIZE = 3;
const int32 MAX_CHAR_MISSION = 8;
const int32 MAX_CHAR_MISSION_REWARD = 9;
const int32 MAX_CHAR_MISSION_PUZZLE_PIECE = 9;
const int32 MAX_COMMAND_HISTORY_COUNT = 20;
const int32 MAX_ALCHEMY_LAB_STOCK = 99;
const int32 MAX_SMELTER_STOCK = 99;
const int32 INVALID_DAY = -1;
const int32 NUM_OF_PARTY_MEMBER = 3;

UENUM()
enum class EHUDWidgetType : uint8
{
	// Order has mean

	// Main menu

	Main = 0,
	Party,
	Upgrade,
	Wonder,
	Summon,

	// Sub menu

	Collection,
	StorageBox,
	Bag,
	Codex,
	Friend,
	Joker,
	Mission,
	Account,
	Shop,
	Setting,
	Story,

	// Others

	JokerSelect,
	Saga,
	Dialogue,
	Special,
	DailyDungeon,
	TrainingCenter,
	InitialRewardEvent,
	Raid,
	BondUpResult,
	LobbySetting,
	Event,
	Invalid,
};

UENUM()
enum class EInventoryType : uint8
{
	Character = 0,
	Sculpture = 1,
	Relic = 2,
	Max = 3,
};

UENUM()
enum class EInventoryCategory : uint8
{
	Collection = 0,
	StorageBox = 1,
};

UENUM()
enum class EInventoryEdit : uint8
{
	None = 0,
	PullOut = 1,
	Stash = 2,
};

UENUM()
enum class EPointType : uint8
{
	None = 0,
	Gold = 1,
	FreeGem = 2,
	PaidGem = 3,
	AnyGem = 4,
	Watt = 5,
	Sculpture = 6,
	Relic = 7,
	Friendship = 8,
	SummonTicket = 9,
	StoredWater = 10,
	SmallBattery = 11,
	MediumBattery = 12,
	LargeBattery = 13,
	Lumicube = 14,
	CharacterDisk = 15,
	SculptureDisk = 16,
	RelicDisk = 17,
	Special = 18,
	CharUnlockElem = 19,
	Event = 20,
	Migrium = 21,
};

UENUM()
enum class EPointWidgetOption : uint8
{
	NONE = 0,
	VisibleMaxPoint = 0x1,	// V
	CompLessThan = 0x2,		// L
	IncludeEqual = 0x4,		// E
	ChangeColor = 0x8,		// C

	LessEqual = CompLessThan | IncludeEqual,
	LessColor = ChangeColor | CompLessThan,
	EqualColor = ChangeColor | IncludeEqual,
	LessEqualColor = ChangeColor | LessEqual,
	LessVisible = VisibleMaxPoint | CompLessThan,
	EqualVisible = VisibleMaxPoint | IncludeEqual,
	ColorVisible = VisibleMaxPoint | ChangeColor,
	LessEqualVisible = VisibleMaxPoint | LessEqual,
	LessColorVisible = VisibleMaxPoint | LessColor,
	EqualColorVisible = VisibleMaxPoint | EqualColor,
	LessEqualColorVisible = VisibleMaxPoint | LessEqualColor
};

UENUM()
enum class EBlackoutType : uint8
{
	None = 0,
	OpacityFill = 1,
	SlideFill = 2,
	SlidOutLeft = 3,
	SlidOutRight = 4,
	BlinkOpen = 5,
	BlinkClose = 6,
	Login = 7,
	Logout = 8,
	Recall = 9,
	ChatMode = 10,
	OpacityFillWhite = 11,
	SlideFillWhite = 12,
	// to be added
	BlinkOpenWhite = 15,
	BlinkCloseWhite = 16,
	Max = 17
};

UENUM()
enum class ENotificationType : uint8
{
	Short = 0,
	Long = 1,
	Loop = 2,
	Max = 3
};

UENUM()
enum class EMissionGaugeType : uint8
{
	Full,
	Toast,
	Page,
	Max
};

UENUM()
enum class EMissionToastType : uint8
{
	Start,
	Normal,
	Full,
	Max
};

UENUM()
enum class EMissionToastIconType : uint8
{
	WeeklyMission,
	Max
};

UENUM()
enum class EWeeklyMissionAnimType : uint8
{
	Start,
	StateSelected,
	StateNone,
	StateShuffle,
	Max
};

UENUM()
enum class EMissionButtonAnimType : uint8
{
	Normal,
	Activate,
	CompleteStart,
	BingoStart,
	Shuffle,
	Complete,
	Bingo,
	Max
};

UENUM()
enum class EMissionBonusButtonAnimType : uint8
{
	Normal,
	Activate,
	Max
};

UENUM()
enum class EMissionBingoBoardState : uint8
{
	Normal,
	Activate,
	Complete
};

UENUM()
enum class EAchievementsPageAnimType : uint8
{
	Normal,
	PuzzleActiveLoop,
	PuzzleComplete,
	Max
};

UENUM()
enum class EAchievementsPuzzleImageType : uint8
{
	GeneralPuzzleImage,
	UlimateSkillAnimationWidgetImage,
	Max
};

UENUM()
enum class EAchievementsPuzzleAnimType : uint8
{
	PuzzleEnabled,
	PuzzleDisabled,
	PuzzleClear,
	Max
};

UENUM()
enum class EAchievementsListAnimType : uint8
{
	Normal,
	Active,
	Complete,
	Max
};

UENUM()
enum class EPuzzlePieceAnimType : uint8
{
	HighlightLoop,
	LastPiece,
	MoveRight,
	MoveLeft,
	MoveUp,
	MoveDown,
	GetPiece,
	Max
};

UENUM()
enum class EUpgradeSequence : uint8
{
	Main = 0,
	Inventory = 1,
	Upgrade = 2,
};

UENUM()
enum class EUpgradeCategory : uint8
{
	Character = 0,
	Skill = 1,
	Sculpture = 2,
	Relic = 3,

	Max = 4,
};

UENUM()
enum class EUpgradeCharacterCategory : uint8
{
	// Character
	LevelUp = 0,
	Promote = 1,
	Unbind = 2,
	Evolute = 3,

	Max = 4,
};

UENUM()
enum class EUpgradeEquipCategory : uint8
{
	// Sculpture
	LevelUp = 0,
	Promote = 1,
	TierUp = 2,

	Max = 3,
};

UENUM()
enum class EUpgradeSkillCategory : uint8
{
	TurnBegin = 0,
	Ultimate = 1,
	Max = 2,
};

UENUM()
enum class EFriendMenu : uint8
{
	MainView = 0,
	JokerSetView = 1,
};

UENUM()
enum class EFriendCategory : uint8
{
	FriendConnected = 0,
	FriendReceiving = 1,
	FriendSearching = 2,
	FriendBookFeed = 3,
};

UENUM()
enum class EFriendBookFilter : uint8
{
	All = 0,
	Mine = 1,
};

UENUM()
enum class EFriendTab : uint8
{
	FriendList = 0,
	FriendSearch = 1,
	FriendBookFeed = 2,
};

UENUM()
enum class ESearchResultTab : uint8
{
	Default = 0,
	UserResult = 1,
	UserNone= 2,
};

UENUM()
enum class ESagaTab : uint8
{
	Episode = 0,
	Stage = 1,
};

UENUM()
enum class ESpecialStageMenuType : uint8
{
	Main = 0,
	EpisodeList = 1,
	StageList = 2,
};

UENUM()
enum class EStoryMenuType : uint8
{
	Main = 0,
	StoryList = 1,
};

UENUM()
enum class EStoryMenuCategory : uint8
{
	DailyDungeon = 0,
	TrainingCenter = 1,
	Raid = 2,
	Event = 3,
	Movie = 4,
	Max = 5,
};

UENUM()
enum class EDailyDungeonMenuType : uint8
{
	Main = 0,
	StageList = 1,
	Info = 2,
};

UENUM()
enum class ESummonSequence : uint8
{
	WaitSchedule = 0,
	EmptySchedule = 1,
	Main = 2,
	Result = 3,
};

UENUM(BlueprintType)
enum class EIconSelectType : uint8
{
	Deselected = 0,
	Selected = 1,
	Highlight = 2,
	Selectable = 3,
	Disabled = 4,
	Max = 5,
};

UENUM(BlueprintType)
enum class EPartyWidgetType : uint8
{
	Party = 0,
	JokerSet = 1,
	CombatReady = 2,
};

UENUM()
enum class EPartyIconViewType : uint8
{
	List = 0,
	Edit = 1,
};

UENUM()
enum class EPartyIconItemType : uint8
{
	Character = 0,
	Sculpture = 1,
	Relic = 2,
	Max = 3,
};

UENUM(BlueprintType)
enum class EPartyIconType : uint8
{
	Normal = 0,
	Empty = 1,
	Disable = 2,
	Joker = 3,
	EmptyJoker = 4,
	RandomJoker = 5,
	Lock = 6,
	Max = 7,
};

UENUM(BlueprintType)
enum class ESortOrderType : uint8
{
	LastLogin = 0,
	FriendLevel = 1,
	Level = 2,
	Hp = 3,
	Atk = 4,
	Def = 5,
	Nature = 6,
	UltimateSkill = 7,
	Grade = 8,
	Name = 9,
	Created = 10,
	Type = 11,

	Max,
};

UENUM(BlueprintType)
enum class ESortDirection : uint8
{
	Descending,
	Ascending = 1,

	Max,
};

UENUM(BlueprintType)
enum class ESortFilterType : uint8
{
	Nature = 0,
	Tier = 1,

	Invalid,
};

UENUM(BlueprintType)
enum class ESortCategory : uint8
{
	OwnedCharacter = 0,
	OwnedRelic,
	OwnedSculpture,
	OwnedCharacterWithExp,
	OwnedRelicWithExp,
	OwnedSculptureWithExp,
	NotOwnedCharacter,
	NotOwnedRelic,
	NotOwnedSculpture,
	Friend,
};

UENUM()
enum class ESortMenu : uint8
{
	Collection = 0,
	PartyEdit,
	Codex,
	UpgradeTarget,
	UpgradeMaterial,
	StorageBox,
	JokerEdit,
	FriendList,
	JokerSelect,

	Max,
};

UENUM()
enum class EInitialRewardWidgetType : uint8
{
	None,
	RewardItem,
	VacationReward,
	FoundRaid,
	WonderOpen,
	WonderReward
};

UENUM()
enum class EInitialRewardSpecialTagType : uint8
{
	NewStage,
	Open,
	Get,
	None,
};

UENUM(BlueprintType)
enum class EWonderUpgradeState : uint8
{
	Normal = 0,
	Upgrading = 1,
	Upgraded = 2,
	Locked = 3,
};

enum class EIncomeState : uint8
{
	Invalid,
	NotStored,
	Stored,
	MaxStored,
};

UENUM()
enum class EAlchemyLabMakeType : uint8
{
	None,
	RGradeRelicExpCard,
	RGradeSculptureExpCard,
	SRGradeRelicExpCard,
	SRGradeSculptureExpCard,
	Lumicube
};

UENUM()
enum class ENotOpenedYetWonderDescType : uint8
{
	OnlyFirstStep,
	Conditional,
};

UENUM()
enum class EBonusRewardMarkAnimType : uint8
{
	Checked,
	Show,
	Max
};

UENUM()
enum class ERaidState : uint8
{
	None,
	Progress,
	End,
	Max
};

UENUM()
enum class ERaidStageState : uint8
{
	Found,
	Joinable,
	Final,
	InProgress,
	Registrable,
	Resistration,
	Max
};

UENUM()
enum class ERaidUserState : uint8
{
	OnGoing,
	End,
	Max
};

UENUM()
enum class ERaidUserCharacterAnimType : uint8
{
	Playing,
	Dead,
	Waiting,
	Max
};

UENUM(BlueprintType)
enum class ERaidCategory : uint8
{
	RegularRaid,
	GeneralRaid
};

UENUM()
enum class EAkaListAnimType : uint8
{
	InUse,
	Selectable,
	Locked,
	Max
};

UENUM()
enum class ERewardSequence : uint8
{
	None,
	Bond,
	Outro,
	WeedGrow,
	StageClear,
	DailyFirstClear,
	TrainingPhaseClear,
	EpisodeClear,
	VacationReward,
	FoundRaid,
	Title,
	ContentOpenGuide,
	WonderOpen,
	WonderReward
};

UENUM()
enum class ERewardType : uint8
{
	First,
	Ranking,
	Goal,
	Found,
	Join,
	Promote,
	EpisodeClearReward,
	Bonus,

	None
};

UENUM(BlueprintType)
enum class EHealthBarAction : uint8
{
	None,
	SingleHit,
	FirstHit,
	Hit,
	LastHit,
	Recover,
	HealBlock,
};

UENUM()
enum class EAlchemyLabItemListPopupType : uint8
{
	None,
	Select,
	View
};

UENUM()
enum class ECodexCategory : uint8
{
	CodexCharacter,
	CodexSculpture,
	CodexRelic,
	None,
};

// Do not fix ordering
UENUM()
enum class EShopMenu : uint8
{
	DiskCharacter,
	DiskSculpture,
	DiskRelic,
	Lumicube,
	Gem,
	Sell,
	None,
};

UENUM()
enum class ESettingMenu : uint8
{
	QualityView = 0,
	NoticeView = 1,
};

UENUM()
enum class ELobbySettingEditType : uint8
{
	None,
	EditTemplate,
	EditCharacter
};

UENUM()
enum class EEventMenu : uint8
{
	Main,
	Shop,
	Stage
};

UENUM()
enum class EGemAmount : uint8
{
	Small,
	Medium,
	Large,
	FullBox,
	None
};

UENUM()
enum class ENewMarkType : uint8
{
	None = 0,
	Dot,
	New,
	ComingSoon,
	Clear,
};

UENUM()
enum class EProfileCategory : uint8
{
	None,
	CharacterName,
	NickName,
	RealName,
	Sex,
	NativePlace,
	HomePlace,
	Height,
	Weight,
	BloodType,
	DateOfBirth,
	StarSign,
	Tendency,
	Likes,
	Dislikes,
	Etc,
};

UENUM()
enum class ERewardState : uint8
{
	None,
	Already,
	NowGet,
	NotYet
};

/**
* Use for character, sculpture, relic icon minimal data
*/
USTRUCT()
struct FItemIconInfo
{
	GENERATED_USTRUCT_BODY()

	FItemIconInfo() :Id(0), AttributeType((EAttributeCategory)EAttributeCategoryMax)
		, Type(0), Grade(EItemGrade::NONE), Star(0), Level(0), Xp(0), bLocked(false), bUsed(false), bFinalArt(false)
		, Tier(0), Moon(0), BondXp(0), TurnSkill1Level(0), TurnSkill2Level(0), TurnSkill3Level(0), UltSkillLevel(0), SupportSkillLevel(0)
	{}

	bool IsValid() const
	{
		bool bIsValidId = Id > ITEM_INVALID;

		if (AttributeType == EAttributeCategory::SystemJoker)
		{
			bIsValidId = true;
		}

		return bIsValidId && (Type > ITEM_INVALID) && ((int32)AttributeType < EAttributeCategoryMax);
	}

	void SetSkillLevels(int32 InTurnSkill1Level, int32 InTurnSkill2Level, int32 InTurnSkill3Level, int32 InUltSkillLevel, int32 InSupportSkillLevel)
	{
		TurnSkill1Level = InTurnSkill1Level;
		TurnSkill2Level = InTurnSkill2Level;
		TurnSkill3Level = InTurnSkill3Level;
		UltSkillLevel = InUltSkillLevel;
		SupportSkillLevel = InSupportSkillLevel;
	}

	UPROPERTY()
	int64 Id;

	UPROPERTY()
	EAttributeCategory AttributeType;

	UPROPERTY()
	int32 Type;

	UPROPERTY()
	EItemGrade Grade;

	UPROPERTY()
	int32 Star;

	UPROPERTY()
	int32 Level;

	UPROPERTY()
	int32 Xp;

	UPROPERTY()
	bool bLocked;

	UPROPERTY()
	bool bUsed;

	UPROPERTY()
	bool bFinalArt;

	// Equipment only properties

	UPROPERTY()
	int32 Tier;

	// Character only properties

	UPROPERTY()
	int32 Moon;

	UPROPERTY()
	int32 BondXp;

	UPROPERTY()
	int32 TurnSkill1Level;

	UPROPERTY()
	int32 TurnSkill2Level;

	UPROPERTY()
	int32 TurnSkill3Level;

	UPROPERTY()
	int32 UltSkillLevel;

	UPROPERTY()
	int32 SupportSkillLevel;
};

USTRUCT()
struct FWonderInfo
{
	GENERATED_USTRUCT_BODY()

	FWonderInfo() : Category(EWonderCategory::Main), bOpened(false), Level(1), WonderState(EWonderUpgradeState::Locked),
		UpgradeStartTimeSec(0), UpgradeLeadTimeSec(0), UpgradeRemainTimeSec(0), RemainMaxIncomeTimeSec(0), IncomeAmount(0){}

	UPROPERTY()
	EWonderCategory Category;

	UPROPERTY()
	bool bOpened;

	UPROPERTY()
	int32 Level;

	UPROPERTY()
	EWonderUpgradeState WonderState;

	UPROPERTY()
	int64 UpgradeStartTimeSec;

	UPROPERTY()
	int64 UpgradeLeadTimeSec;

	UPROPERTY()
	int64 UpgradeRemainTimeSec;

	UPROPERTY()
	int64 RemainMaxIncomeTimeSec;

	UPROPERTY()
	int32 IncomeAmount;
};

USTRUCT()
struct FBondHistory
{
	GENERATED_USTRUCT_BODY()

	FBondHistory() :
		CharacterType(CharacterTypeInvalid),
		GainedXp(0),
		bLevelUp(false)
	{}

	UPROPERTY()
	FCharacterType CharacterType;

	UPROPERTY()
	int32 GainedXp;

	UPROPERTY()
	bool bLevelUp;
};

USTRUCT()
struct FRewardStep
{
	GENERATED_USTRUCT_BODY()

	FRewardStep() :
		RewardSequence(ERewardSequence::None),
		RewardIndex(-1)
	{}

	UPROPERTY()
	FWeedGrowType WeedGrowType;

	UPROPERTY()
	ERewardSequence RewardSequence;

	UPROPERTY()
	int32 RewardIndex;

	UPROPERTY()
	FUserTitleType UserTitleType;

	UPROPERTY()
	FContentFeatureOpenType ContentFeatureOpenType;

	UPROPERTY()
	FTrainingCenterType TrainingCenterType;

	UPROPERTY()
	FEventContentType EventContentType;
};

USTRUCT()
struct FWeeklyMissionToastInfo
{
	GENERATED_USTRUCT_BODY()

	FWeeklyMissionToastInfo()
		: Type(MissionTypeInvalid)
		, BeforeValue(0)
		, CurrValue(0)
		, MaxValue(0)
	{}

	explicit FWeeklyMissionToastInfo(const FMissionType& InType
		, const int32 InBeforeValue
		, const int32 InCurrValue
		, const int32 InMaxValue)
		: Type(InType)
		, BeforeValue(InBeforeValue)
		, CurrValue(InCurrValue)
		, MaxValue(InMaxValue)
	{}

	UPROPERTY()
	FMissionType Type;

	UPROPERTY()
	int32 BeforeValue;

	UPROPERTY()
	int32 CurrValue;

	UPROPERTY()
	int32 MaxValue;
};

DECLARE_DELEGATE_OneParam(FCharacterInfoDelegate, const FCharacterInfo& /* CharacterInfo */);
DECLARE_DELEGATE_OneParam(FFriendRequestDelegate, const FFriendInfo&);

DECLARE_DELEGATE_TwoParams(FCharacterTypeDelegate, const FCharacterType& /* CharacterType */, int32 /* CharacterLevel */);
DECLARE_DELEGATE_TwoParams(FFriendButtonDelegate, const FFriendInfo& /* FriendInfo */, bool /*bAccept*/);
DECLARE_DELEGATE_TwoParams(FUserCharacterDelegate, const FCharacterId& /* CharacterId */, const FUserId& /* UserId */);
