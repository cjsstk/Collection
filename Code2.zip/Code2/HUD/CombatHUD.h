// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "HUD/BaseHUD.h"
#include "CCEvent.h"
#include "BaseWidget.h"
#include "CombatHUD.generated.h"

class AUnit;
class ACombatTutorial;
class UArtifactAnimationWidget;
class UCombatHUDWidget;
class UCombatResultWidget;
class UCombatDamageTextWidget;
class UCombatUnitNoticeListBaseWidget;
class UCombatUnitNoticeListWidget;
class UCombatUnitStateNoticeListWidget;
class UCombatUnitApplyEffectLabelListWidget;
class UCombatWipeoutWidget;
class UDebugCombatWidget;
class UFriendRequestPopupWidget;
class UItemPopupWidget;
class UJokerSetViewPopupWidget;
class URaidUserPopupWidget;
class UWithdrawPopupWidget;
class UPopupWidget;
class USkillAnimationWidget;
class USupportSkillAnimationWidget;
class UUltimateSkipWidget;

struct FNetInfo;
struct FItemData;
struct FCCCombatCubeState;
struct FBuffEffectState;
struct FMissionCombat;
struct FRewardInfo;
struct FItemDropInfo;

enum class EBuffNoticeType : uint8;
enum class EPointVaryState : uint8;
enum class EPointVaryConsumeType : uint8;
enum class EPointVaryConvertType : uint8;
enum class EInitialRewardWidgetType : uint8;
enum class ESagaRewardType : uint8;
enum class EDropBoxType : uint8;
enum class ECurrencyType : uint8;

USTRUCT()
struct FDropBox
{
	GENERATED_USTRUCT_BODY()

	FDropBox()
		: Count(0) {}

	UPROPERTY()
	ESagaRewardType RewardType;

	UPROPERTY()
	EDropBoxType Grade;

	UPROPERTY()
	int32 Count;
};

USTRUCT()
struct FDropCurrency
{
	GENERATED_USTRUCT_BODY()

	FDropCurrency()
		: Count(0) {}

	UPROPERTY()
	ESagaRewardType RewardType;

	UPROPERTY()
	ECurrencyType Type;

	UPROPERTY()
	int32 Count;
};

/**
 * Combat HUD
 */
UCLASS()
class Q6_API ACombatHUD : public ABaseHUD
{
	GENERATED_BODY()

public:
	ACombatHUD(const FObjectInitializer& ObjectInitializer);
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual ABaseTutorial* GetTutorial() override;

	virtual EHUDType GetHUDType() override { return EHUDType::Combat; }

	virtual void SetWidgetsVisible(bool bInVisible) override;

	void SynchronizeCCState(const FCCCombatCubeState& InState);
	void PostSynchronizeCCState();

	// CombatPlayerController Calls.
	void ToggleDebugWidget();
	void ToggleNoDamage();
	void ToggleImmune();

	// Combat Presenter Event Handling.
	void OnReportError(const UCCReportErrorEvent* Event);
	void OnStartGame(const UCCStartGameEvent* Event);
	void OnStartWave(const UCCStartWaveEvent* Event);
	void OnTakeTurn(const UCCTakeTurnEvent* Event);
	void OnStartTurn(const UCCStartTurnEvent* Event);
	void OnStartPhase(const UCCStartPhaseEvent* Event);
	void OnSpawnUnit(const UCCSpawnUnitEvent* Event);
	void OnDespawnUnit(const UCCDespawnUnitEvent* Event);
	void OnSkillUsed(const UCCSkillUsedEvent* Event);
	void OnSkillFailed(const UCCSkillFailedEvent* Event);
	void OnSkillStart(const UCCSkillUsedEvent* Event);
	void OnHealthChanged(const UCCUnitHealthChangedEvent* Event);
	void OnAllyWipeout(const UCCAllyWipeoutEvent* Event);
	void OnEndGame(const UCCEndGameEvent* Event);
	void OnBoneDragonEndGame(const UCCEndGameEvent* Event);
	void OnUAChanged(const UCCUnitUAChangedEvent* Event);
	void OnSAChanged(const UCCUnitSAChangedEvent* Event);
	void OnOverKillChanged(const UCCUnitOverKillChangedEvent* Event);
	void OnSetSkillCooldown(const UCCSetSkillTimeEvent* Event);
	void OnSetCheatSkillCooldown(const UCCSetCheatSkillCooldownEvent* Event);
	void OnCreateBuff(const UCCCreateBuffEvent* Event, bool bSkipUnitNotice, bool bSkipUnitBar);
	void OnRemoveBuff(const UCCRemoveBuffEvent* Event, const FBuffType& BuffType, bool bSkipUnitNotice);
	void OnRemoveBuffFailed(const UCCRemoveBuffFailedEvent* Event, bool bSkipUnitNotice);
	void OnImmuneBuff(const UCCImmuneBuffEvent* Event, bool bSkipUnitNotice);
	void OnRaidTurnSkillEffect(const UCCRaidTurnSkillEffectEvent* Event);
	void OnCombatMission(const UCCMissionEvent* Event);
	void WarningPatternUltimate(const UCCSelectedPatternUltimate* Event);

	void OnEnemyUltimateReady(const AUnit* EnemyUnit);
	void OnPrepareTurnSkillPhase();
	void OnStartTurnSkillPhase();
	void OnSkillPass(const TArray<FCCUnitId>& PhasePassUnitIds);
	void OnSkillEnd(FCCUnitId UnitId, ESkillCategory SkillCategory, bool bInPattern);
	void OnSkillDrivenEffectEnd();
	void OnUltimateSkillSequenceStarted(bool bNoSkip);
	void OnUltimateSkillSequenceFinished();
	void OnPointChanged(FCCUnitId UnitId, EPointVaryConsumeType PointType, int32 Value);
	void OnImmediateKill(FCCUnitId UnitId);
	void OnSkillTimeChanged(FCCUnitId UnitId, ESetSkillTimeType SetSkillTimeType, int32 Value);
	void OnPointVaryConsume(FCCUnitId UnitId, EPointVaryConsumeType ConsumeType, int32 Value);
	void OnPointVaryConvert(FCCUnitId UnitId, EPointVaryConvertType ConvertType, int32 Value);
	void OnHit(const UUnitHit* HitPerUnit, bool bIsActiveSkillHit, bool bPassOverTotal);
	void OnDamageBuffHit(const UCCDamageBuffPerUnit* DamageInfo);
	void OnHealBuffHit(const UCCHealBuffPerUnit* HealInfo);
	void OnDead(FCCUnitId UnitId);
	void OnSelectTarget(const FCCUnitId UnitId);
	void OnFinishWave();

	void AddProgressTask(UProgressBar* Obj, float InTarget, float InLength,
		FSimpleDelegate InCBStart = FSimpleDelegate(), FSimpleDelegate InCBEnd = FSimpleDelegate(), FFloatParamDelegate InCBUpdate = FFloatParamDelegate());
	void AddSkillGaugeProgressSerialTask(const FSkillGaugeProgressUpdateTask& Task);

	void AddOverKill(FCCUnitId InUnitId, int32 InValue);

	int32 GetSelectedTurnSkillIndex() const;
	FCombatMissionInfo GetCombatMissionInfo() const;

	void SetAllyTurnSkillPhaseSelectable(bool bInSelectable);
	void PickFirstAliveAlly();

	void ResetTotalDamage();
	void ResetUnitNoticeCaches();

	void ShowUltimateSkipWidget(bool bShow);

	FString GetConvertTypeKeyString(EPointVaryConvertType ConvertType);
	FText GetConvertValueText(EPointVaryConvertType ConvertType, int32 Value);
	void ClearPointVaryUnitAttributes(FCCUnitId InUnitId);

	bool GetViewportPosition(const FCCUnitId TargetUnitId, const FName& SocketName, const FVector& InSpawnPositionOffset, const FVector2D& InWidgetSize, FVector2D& InOutViewportPosition);

	void PlayUnitApplyMomentEffect(FCCUnitId TargetUnitId, EMoment Moment);

	UCombatResultWidget* GetResultWidget() const { return ResultWidget; }

	URaidUserPopupWidget* OpenRaidUserPopup();
	UFriendRequestPopupWidget* OpenFriendRequestPopup();
	UJokerSetViewPopupWidget* OpenJokerSetViewPopup(const FFriendInfo& FriendInfo);
	UWithdrawPopupWidget* OpenWithdrawPopup(EContentType InContentType);

	void SetItemDropInfo();
	bool HasItemDrop() const { return bHasItemDrop; }

	void RefreshEnemyBarWidget(FCCUnitId InUnitId);

	const TArray<FDropBox>& GetDropBoxes() const { return DropBoxes; }
	const TArray<FDropCurrency>& GetDropCurrencies() const { return DropCurrencies; }

	ACombatTutorial* GetCombatTutorial();

	bool IsShowProvokedEnemyBar() const;
	void SelectTarget(FCCUnitId InUnitId);

	UFUNCTION()
	bool PlaySkillAnimation();

	UFUNCTION()
	void PlayRewardAnimation();

	UFUNCTION()
	void PlayRaidResultAnim(bool bRaidFinal);

	UFUNCTION()
	void PlayArtifactAnimation(int32 SkillType, FCCUnitId TargetUnitId);

	UPROPERTY(EditDefaultsOnly, Category = "Combat Tutorial Help Actor")
	TSubclassOf<ACombatTutorial> CombatTutorialClass;

	FSimpleDelegate OnSpawnAnimFinishedDelegate;
	FSimpleDelegate OnSkillPreAnimFinishedDelegate;
	FSimpleDelegate OnDamageTextAnimFinishedDelegate;
	FSimpleDelegate OnUnitNoticeAnimStartDelegate;
	FSimpleDelegate OnUnitNoticeAnimFinishedDelegate;

	FSimpleDelegate OnStartTurnPhaseAnimFinishedDelegate;
	FSimpleDelegate OnEnemyUltimateReadyAnimFinishedDelegate;

	FSimpleDelegate WinAnimFinishedDelegate;
	FSimpleDelegate ResultWidgetClosedDelegate;

	FSimpleDelegate OnRaidAssistStartAnimFinishedDelegate;
	FSimpleDelegate OnSkillFailedAnimFinishedDelegate;
	FSimpleDelegate OnSkillAnimFinishedDelegate;

private:
	bool CreateHUDWidgetAndBindEvents();

	void CreateDebugWidget();
	void UpdateCombatPresenterDebugState();

	void CreateSkillAnimWidgetIfNotCreated(USkillAnimationWidget** OutWidget, const TSoftClassPtr<USkillAnimationWidget>& SkillAnimWidgetClass);
	void OnUltimateSkillAnimFinished();

	bool PlaySupportSkillAnims();

	void SpawnCombatText(FCCUnitId TargetUnitId, ENatureRelationType NatureRelationType, int32 BaseValue, int32 ExtraValue, EHealthChangeReason Reason, bool bDodged, bool bCritical, bool bShield, bool bMultiple, bool bAddRandomOffset);

	UCombatUnitNoticeListWidget* GetUnitNoticeList(FCCUnitId TargetUnitId);
	UCombatUnitStateNoticeListWidget* GetUnitStateNoticeList(FCCUnitId TargetUnitId);
	bool GetUnitNoticeListInternal(FCCUnitId InUnitId, UCombatUnitNoticeListBaseWidget* InWidget);

	void SpawnUnitBuffNotices(EBuffNoticeType BuffNoticeType, FCCUnitId TargetUnitId, const FBuffType& BuffType, int32 BuffLevel = 1, ESkillCategory BornCategory = ESkillCategory::Normal);
	void SpawnUnitRemoveBuffFailedNotice(FCCUnitId TargetUnitId, ERemoveBuffFailedReason Reason, EApplyTag NoApplyTag);
	void SpawnUnitImmuneBuffNotice(FCCUnitId TargetUnitId, EApplyTag ImmuneTag);
	void SpawnUnitPointNotice(FCCUnitId TargetUnitId, EPointVaryState PointVaryState, const FString& TypeKeyStr, const FText& ValueText, bool bUnitAttribute);
	void SpawnUnitImmediateKillNotice(FCCUnitId TargetUnitId);
	void SpawnUnitSkillTimeNotice(FCCUnitId TargetUnitId, ESetSkillTimeType SetSkillTimeType, int32 Value);

	void SpawnUnitStateNotice(FCCUnitId TargetUnitId, const FBuffEffectState& BuffEffectState);

	UCombatUnitApplyEffectLabelListWidget* GetUnitApplyEffectLabelList(FCCUnitId TargetUnitId);

	void OnNetworkEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp);
	void OnSpawnAnimFinished();
	void OnSkillStartAnimFinished();
	void OnSupportSkillAnimFinished();
	void OnSkillPreAnimFinished();
	void OnDamageTextAnimFinished();
	void OnUnitStateNoticeStartNext(FCCUnitId InUnitId);
	void OnUnitNoticeAnimFinished(FCCUnitId InUnitId);
	void OnUnitNoticeAnimFinishedInternal();
	void OnStartTurnPhaseAnimFinished();
	void OnEnemyUltimateReadyAnimFinished();
	void OnWinAnimFinished();
	void OnResultWidgetClosed();
	void OnRaidAssistStartAnimFinished();
	void OnSkillFailedAnimFinished();
	void OnArtifactAnimFinished(int32 SkillType, FCCUnitId TargetUnitId);
	void OnUltimateSkillSkipped();

	void UpdateProgressBar(float DeltaTime);
	void UpdateSkillGaugeProgressBar(float DeltaTime);

	void GatherItemDropInfos(const TArray<FItemDropInfo>& ItemDropInfos, const TArray<int32>& InDeadUnitSlots);

	void TutorialButtonClick(FString InSource);

	// Widget Classes

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCombatHUDWidget> CombatHUDWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCombatResultWidget> CombatResultWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UCombatWipeoutWidget> WipeoutWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UDebugCombatWidget> DebugCombatWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	TSoftClassPtr<USupportSkillAnimationWidget> SupportSkillLeftAnimationWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	TSoftClassPtr<USupportSkillAnimationWidget> SupportSkillRightAnimationWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	TSoftClassPtr<UArtifactAnimationWidget> ArtifactAnimWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Skill")
	TSoftClassPtr<UUltimateSkipWidget> UltimateSkipWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<URaidUserPopupWidget> RaidUserPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UFriendRequestPopupWidget> FriendRequestPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UJokerSetViewPopupWidget> JokerSetViewPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UWithdrawPopupWidget> WithdrawPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "UnitWidget")
	TSubclassOf<UCombatDamageTextWidget> DamageTextWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "UnitWidget")
	TSubclassOf<UCombatUnitNoticeListWidget> UnitNoticeListWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "UnitWidget")
	TSubclassOf<UCombatUnitStateNoticeListWidget> UnitStateNoticeListWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "UnitWidget")
	TSubclassOf<UCombatUnitApplyEffectLabelListWidget> UCombatUnitApplyEffectLabelListWidgetClass;

	// Widgets

	UPROPERTY(Transient)
	UDebugCombatWidget* DebugCombatWidget;

	UPROPERTY(Transient)
	UCombatHUDWidget* CombatHUDWidget;

	UPROPERTY(Transient)
	UCombatResultWidget* ResultWidget;

	UPROPERTY(Transient)
	URaidUserPopupWidget* RaidUserPopupWidget;

	UPROPERTY(Transient)
	UFriendRequestPopupWidget* FriendRequestPopupWidget;

	UPROPERTY(Transient)
	TArray<UCombatDamageTextWidget*> DamageTextWidgets;

	UPROPERTY(Transient)
	TArray<UCombatUnitNoticeListWidget*> AllyUnitNoticeListWidgets;

	UPROPERTY(Transient)
	TArray<UCombatUnitStateNoticeListWidget*> AllyUnitStateNoticeListWidgets;

	UPROPERTY(Transient)
	TArray<UCombatUnitApplyEffectLabelListWidget*> AllyUnitApplyEffectLabelListWidgets;

	UPROPERTY(Transient)
	TArray<UCombatUnitNoticeListWidget*> EnemyUnitNoticeListWidgets;

	UPROPERTY(Transient)
	TArray<UCombatUnitStateNoticeListWidget*> EnemyUnitStateNoticeListWidgets;

	UPROPERTY(Transient)
	TArray<UCombatUnitApplyEffectLabelListWidget*> EnemyUnitApplyEffectLabelListWidgets;

	UPROPERTY(Transient)
	USupportSkillAnimationWidget* SupportSkillLeftAnimWidget;

	UPROPERTY(Transient)
	USupportSkillAnimationWidget* SupportSkillRightAnimWidget;

	UPROPERTY(Transient)
	USkillAnimationWidget* UltimateSkillAnimWidget;

	UPROPERTY(Transient)
	UArtifactAnimationWidget* ArtifactAnimWidget;

	UPROPERTY(Transient)
	TArray<USkillAnimationWidget*> SkillAnimWidgets;

	UPROPERTY(Transient)
	UCombatWipeoutWidget* WipeoutWidget;

	UPROPERTY(Transient)
	UUltimateSkipWidget* UltimateSkipWidget;

	UPROPERTY(Transient)
	UWithdrawPopupWidget* WithdrawPopupWidget;

	UPROPERTY(Transient)
	ACombatTutorial* CombatTutorial;

	TArray<FProgressUpdateTask> ProgressTasks;
	TArray<FSkillGaugeProgressUpdateTask> SkillGaugeProgressTasks;

	FCCUnitId SkillUsedUnitId;
	int32 UsedSkillType;
	int32 SupporterBonus;
	bool bUltimateSkillNoSkip;

	TArray<FCCUnitId> UnitNoticeShowingUnitIds;
	TArray<FCCUnitId> UnitStateNoticeStartedUnitIds;

	TMap<FMissionType, int32> WeeklyCombatMission;
	TMap<FCharMissionType, int32> CharacterCombatMission;

	TArray<FDropBox> DropBoxes;
	TArray<FDropCurrency> DropCurrencies;

	bool bHasItemDrop;

	int32 WaveIndex;
};
