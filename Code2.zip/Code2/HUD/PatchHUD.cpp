// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "PatchHUD.h"

#include "Q6.h"
#include "Q6GameInstance.h"
#include "Widget/PatchHUDWidget.h"

APatchHUD::APatchHUD()
{
}

void APatchHUD::BeginPlay()
{
	Super::BeginPlay();

	PatchHUDWidget = CreateWidget<UPatchHUDWidget>(GetLocalPlayerController(this), PatchHUDWidgetClass);
	PatchHUDWidget->AddToViewport(ZORDER_HUDWIDGET);
}

void APatchHUD::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	Super::EndPlay(EndPlayReason);
}