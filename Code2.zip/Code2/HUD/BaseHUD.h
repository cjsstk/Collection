// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6UIDefine.h"
#include "UMG.h"
#include "GameFramework/HUD.h"
#include "PopupWidgets.h"

#include "BaseHUD.generated.h"

DECLARE_DELEGATE_OneParam(FButtonClickDelegate, FString)

class ABaseTutorial;

class UMainWidget;
class UItemDetailWidget;
class UItemTooltipWidget;
class UCurrencyUsePopupWidget;
class UGemShopPurchasePopupWidget;
class UGuidePopupWidget;
class UNotificationWidget;
class UMissionToastWidget;
class UBlackoutWidget;
class UErrorPopupWidget;
class UUpgradeResultWidget;
class UPlayNotifyPopupWidget;
class UItemDetailWidget;
class UNetworkProgressWidget;
class URaidJoinPopupWidget;
class UWattRechargePointSelectPopupWidget;
class USettingPopupWidget;
class UClearUIWidget;
class UEventRewardPopupWidget;

struct FMaintenanceInfo;
struct FL2CAuthEnterLobbyResp;
struct FL2CAuthEnterLobbyFinalResp;
struct FL2CAuthLoginResp;

// BaseHUD null check macro
#define BaseHUDOnError(BaseHUD, Param1) \
{ \
	if (!BaseHUD) \
	{ \
		check(0); \
		return; \
	} \
	BaseHUD->OnError(Param1); \
}

#define TUTORIAL_MONITORING_BUTTON_CLICK(InSource) if (GetBaseHUD(this)) GetBaseHUD(this)->GetTutorialButtonClickDelegate().ExecuteIfBound(InSource)

UENUM()
enum class EHUDType : uint8
{
	Base,
	Lobby,
	Combat,
	Summon,
	Max,
};

/**
* Q6 Base HUD
*/
UCLASS()
class Q6_API ABaseHUD : public AHUD
{
	GENERATED_BODY()

public:
	ABaseHUD();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;

	virtual bool GotoBack(bool bForced = false);
	virtual EHUDType GetHUDType() { check(false); return EHUDType::Base; }
	virtual void ProcessReward(bool bMenuBack = true) { check(false); };
	virtual ABaseTutorial* GetTutorial();

	// Popup
	template <typename WidgetType>
	UPopupBaseWidget* OpenPopup(const TSoftClassPtr<WidgetType>& PopupClass, bool bOverlappable = true);

	template <typename WidgetType>
	UPopupBaseWidget* GetOpenedPopup(const TSoftClassPtr<WidgetType>& PopupClass);

	UConfirmPopupWidget* OpenConfirmPopup(const FText& TitleText, const FText& ContentText);
	void OpenErrorPopup(EPopupKind InKind, const FText& TitleText, const FText& ContentText);
	UItemListPopupWidget* OpenItemListPopup(EUpgradeCategory ItemCategory, const TArray<int64>& MaterialIds, bool bVisibleUltLevel = 0);
	UPlayNotifyPopupWidget* OpenPlayNotifyPopup(const FText& TitleText, const FText& StageNameText, const FText& ContentText);
	UWattRechargePointSelectPopupWidget* OpenWattRechargePopup();
	UItemDetailWidget* OpenItemDetailPopup(const FItemIconInfo& ItemInfo);

	// Item Tooltip
	UItemTooltipWidget* OpenItemTooltipPopup(FBagItemType ItemType);
	UItemTooltipWidget* OpenItemTooltipPopup(EPointType PointType);
	UItemTooltipWidget* OpenItemTooltipPopup(FEventContentType EventContentType, int32 PointIndex);
	UItemTooltipWidget* OpenItemTooltipPopup(FAvatarEffectType AvatarEffectType);
	UItemTooltipWidget* OpenItemTooltipPopup(FAvatarFrameType AvatarFrameType);

	URaidJoinPopupWidget* OpenRaidJoinPopup(FRaidType RaidType);
	UBondRewardInfoPopupWidget* OpenBondRewardInfoPopup(FCharacterType CharacterType);
	UCurrencyUsePopupWidget* OpenCurrencyUsePopup();
	UGemShopPurchasePopupWidget* OpenGemShopPurchasePopup();
	USettingPopupWidget* OpenSettingPopup();
	UEventRewardPopupWidget* OpenEventRewardPopupWidget();

	void CloseRaidJoinPopup();

	// Tutorial
	FButtonClickDelegate& GetTutorialButtonClickDelegate() { return TutorialButtonClickDelegate; }

#if !UE_BUILD_SHIPPING
	UCheatCommandHelpPopupWidget* OpenCheatCommandHelpPopup(const TArray<IConsoleObject*>& ConsoleObjects, const TArray<FString>& CommandHistory);
#endif

	bool IsReconnecting() const { return bReconnecting; }
	void SetSilentReconnect(bool bInSilentReconnect) { bSilentReconnect = bInSilentReconnect; }

	FString MakeErrorText(FErrTextType ErrType, const TArray<int32>& Extra) const;

	void OnError(const FResError* Error);
	void OnError(FText InErrorMsg);
	void OnAlert(FText InAlertMsg);
	void OnFatal(FText InFatalMsg);
	void OnMaintenance(FText InMaintenanceMsg);

	virtual void ClosePopup(UPopupBaseWidget* InPopupWidget);
	virtual void ClosePopupOnTop();
	virtual void CloseAllPopups();

	// Notification
	void ShowNotification(ENotificationType Type, const FText& Text);
	void ShowNotification(ENotificationType Type, const TArray<FText>& Text);

	void ShowNotOpenedYetNotification(EWonderCategory Category
		, ENotOpenedYetWonderDescType DescType = ENotOpenedYetWonderDescType::Conditional);
	void ShowNotOpenedYetNotification(FSagaType Type);
	void ShowNotOpenedYetNotification(EFeatureOpenType Type);
	void ShowNotOpenedYetNotification(ESpecialCategory Category);

	void ShowMissionToast(const FWeeklyMissionToastInfo& InWeeklyMission);

	void ShowGuidePopup(const FRewardStep& RewardStep);

	bool CheckMaxItemNum(ECurrencyCheckType CheckType, bool bCheckCollection);
	bool CheckMaxItemNum(const TArray<FMailId>& MailIds);

	// Blackout
	void ClearBlackoutDelegates() const;
	void SetBlackoutDelegates(FBoolParamDelegate InBlackoutShowingEvent, FBoolParamDelegate InBlackoutFinishEvent);
	void ShowBlackout(EBlackoutType Type);
	void HideBlackout() const;
	void StopBlackout();
	bool IsShowingBlackout() const;	// if showing
	bool IsWorkingBlackout() const;	// if showing or hiding

	// ClearUI
	void SetClearUI(bool bClear, bool bSetOthersVis = true, bool bDimmed = false);
	bool IsUICleared() const;

	virtual void SetWidgetsVisible(bool bInVisible);
	virtual void OnTouched() {};
	void OnBackgroundTouched();

	// Network
	virtual void OnNetworkStartConnect();
	virtual void OnNetworkMaintenance(const FMaintenanceInfo& Info);
	virtual void OnNetworkConnected();
	virtual void OnNetworkConnectFailed();
	virtual void OnNetworkEnteredLobby(const FL2CAuthEnterLobbyResp& Res);
	virtual void OnNetworkEnteredLobbyFinal(const FL2CAuthEnterLobbyFinalResp& Resp);
	virtual void OnNetworkLogin(const FL2CAuthLoginResp& Res);
	virtual void OnNetworkEnteringLobby() {}
	// Show the network error message and go to world select when the popup closed.
	virtual void OnNetworkError(int32 InErrorCode, FString InErrorMsg);
	virtual void OnNetworkDisconnected();
	virtual void OnNetworkStartBlockingRequest();
	virtual void OnNetworkEndBlockingRequest();
	virtual void OnNetworkQueuingRequestToRetry();
	// Kicked by server.
	void OnKicked(const FString& ReasonDesc);

	virtual void OnDeactivate() {}
	virtual void OnReactivate() {}
	virtual void OnEnterBackground();
	virtual void OnBackgroundTimeout();
	virtual void OnEnterForeground();

	void BlockInputForNetwork();
	void UnblockInputForNetwork();

	FSimpleDelegate OnPopupClosedDelegate;

private:
	void HandleError();
	void OnConfirmErrorPopupInternal(EConfirmPopupFlag InPopupFlag);
	void StartReconnect();

protected:
	template <typename WidgetType>
	bool CreateWidgetIfNotCreated(WidgetType** OutWidget, const TSoftClassPtr<WidgetType>& WidgetClassAsset);

	bool HasOpenedPopup();
	virtual void OnPopupClosed();

private:
	void ShowNetworkErrorPopup(int32 InQ6ErrorCode, FString InErrorMsg);
	void ShowErrorPopupInternal(int32 InHttpStatusCode, int32 InQ6ErrorCode, FString InErrorMsg, const TArray<int32>& InExtra);
	void ShowErrorPopupInternal(FText InTitle, FText InErrorMsg);
	void ShowAlertPopupInternal(FText InTitle, FText InAlertMsg);
	void ShowFatalPopupInternal(FText InTitle, FText InFatalMsg);
	void ShowMaintenancePopupInternal(FText InTitle, FText InFatalMsg);

	template <typename WidgetType>
	WidgetType* FindClosedPopup(const TSoftClassPtr<WidgetType>& PopupClass);

	template <typename WidgetType>
	WidgetType* FindOrCreatePopup(const TSoftClassPtr<WidgetType>& PopupClass);

protected:
	// Enabling silent reconnect or not is almost depend on this variable, but raid only depend on SetSilentReconnect f
	bool bDesiredSilentReconnect;

	UPROPERTY()
	UNetworkProgressWidget* NetworkProgressWidget;

	EHUDWidgetType CurrentHUDWidgetType;

	// Tutorial monitor events
	FButtonClickDelegate TutorialButtonClickDelegate;

private:
	// Popup Widget Classes

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UItemListPopupWidget> ItemListPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UConfirmPopupWidget> ConfirmPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UPlayNotifyPopupWidget> PlayNotifyPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UWattRechargePointSelectPopupWidget> WattRechargePopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UItemDetailWidget> ItemDetailPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UItemTooltipWidget> ItemTooltipPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<URaidJoinPopupWidget> RaidJoinPopupWidgetClass;

	UPROPERTY(EditDefaultsOnly, Category = "Popup")
	TSoftClassPtr<UCheatCommandHelpPopupWidget> CheatCommandHelpPopupWidgetClass;

	// Widget Classes

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UNotificationWidget> NotificationWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UMissionToastWidget> MissionToastWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UGuidePopupWidget> GuidePopupWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UBlackoutWidget> BlackoutWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSoftClassPtr<UClearUIWidget> ClearUIWidgetClass;

	UPROPERTY(EditDefaultsOnly)
	TSubclassOf<UNetworkProgressWidget> NetworkProgressWidgetClass;

	// Widgets
	UPROPERTY()
	TArray<UPopupBaseWidget*> PopupWidgets;

	UPROPERTY()
	UConfirmPopupWidget* ErrorPopupWidget;

	UPROPERTY()
	UNotificationWidget* NotificationWidget;

	UPROPERTY()
	UMissionToastWidget* MissionToastWidget;

	UPROPERTY()
	UGuidePopupWidget* GuidePopupWidget;

	UPROPERTY()
	UBlackoutWidget* BlackoutWidget;

	UPROPERTY()
	UClearUIWidget* ClearUIWidget;

	UPROPERTY()
	URaidJoinPopupWidget* RaidJoinPopupWidget;

	int32 PopupOrder;

	// Network related members
	double BlockInputForNetworkStartTime;
	double EnterBackgroundSeconds;
	bool bReconnecting;
	bool bSilentReconnect;
	bool bKicked;
};


/**
* CreateWidget for given type and asset if not created yet
*/
template <typename WidgetType>
bool ABaseHUD::CreateWidgetIfNotCreated(WidgetType** OutWidget, const TSoftClassPtr<WidgetType>& WidgetClassAsset)
{
	if (*OutWidget)
	{
		// Already created. Nothing todo
		return true;
	}

	*OutWidget = CreateWidget<WidgetType>(PlayerOwner, WidgetClassAsset.LoadSynchronous());
	check(*OutWidget);

	return (*OutWidget != nullptr);
}

template <typename WidgetType>
WidgetType* ABaseHUD::FindClosedPopup(const TSoftClassPtr<WidgetType>& PopupClass)
{
	WidgetType* PopupWidget = nullptr;
	for (UPopupBaseWidget* CreatedPopupWidget : PopupWidgets)
	{
		if (CreatedPopupWidget->GetClass() != PopupClass.Get())
		{
			continue;
		}

		if (!CreatedPopupWidget->IsOpened())
		{
			PopupWidget = CastChecked<WidgetType>(CreatedPopupWidget);
			break;
		}
	}

	return PopupWidget;
}

template <typename WidgetType>
WidgetType* ABaseHUD::FindOrCreatePopup(const TSoftClassPtr<WidgetType>& PopupClass)
{
	WidgetType* PopupWidget = FindClosedPopup(PopupClass);

	if (CreateWidgetIfNotCreated(&PopupWidget, PopupClass))
	{
		PopupWidgets.AddUnique(PopupWidget);
	}

	return PopupWidget;
}

template <typename WidgetType>
UPopupBaseWidget* ABaseHUD::OpenPopup(const TSoftClassPtr<WidgetType>& PopupClass, bool bOverlappable)
{
	if (!bOverlappable)
	{
		UPopupBaseWidget* OpendWidget = GetOpenedPopup(PopupClass);
		if (OpendWidget)
		{
			return OpendWidget;
		}
	}

	UPopupBaseWidget* PopupWidget = CastChecked<UPopupBaseWidget>(FindOrCreatePopup(PopupClass));
	if (PopupWidget)
	{
		PopupWidget->OpenPopup(PopupOrder++);
		PopupWidget->OnPopupClosedDelegateForHUD.BindUObject(this, &ABaseHUD::OnPopupClosed);
	}

	return PopupWidget;
}

template <typename WidgetType>
UPopupBaseWidget* ABaseHUD::GetOpenedPopup(const TSoftClassPtr<WidgetType>& PopupClass)
{
	for (UPopupBaseWidget* CreatedPopupWidget : PopupWidgets)
	{
		if (CreatedPopupWidget->GetClass() != PopupClass.Get())
		{
			continue;
		}

		if (CreatedPopupWidget->IsOpened())
		{
			return CreatedPopupWidget;
		}
	}

	return nullptr;
}
