// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Q6GameUserSettings.h"
#include "Q6GameInstance.h"
#include "Q6.h"
#include "GameResource.h"

static const float FrameRateLimits[] = { 20.0f, 30.0f, 50.0f };
enum class EFrameRateCap : uint8
{
	Frame20 = 0,
	Frame30 = 1,
	Frame50 = 2,
};

UQ6GameUserSettings::UQ6GameUserSettings(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
}

void UQ6GameUserSettings::InitSettings()
{
#if !UE_BUILD_SHIPPING
	IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("q6.frame_limit"),
		TEXT("q6.frame_limit [0: High(50FPS), 1: Mid(default)(30FPS), 2: Low(20FPS)]"),
		FConsoleCommandWithArgsDelegate::CreateUObject(this, &UQ6GameUserSettings::OnDevLimitFrame),
		ECVF_Cheat);
#endif // #if !UE_BUILD_SHIPPING

	ApplyGameData(GameSettingData, GameNoticeData, true);
}

void UQ6GameUserSettings::OnDevLimitFrame(const TArray<FString>& Args)
{
	int32 InFrameRate = (int32)EFrameRateCap::Frame30;
	if (!Args.IsValidIndex(0))
	{
		Q6JsonLogBro(Display, "Usage: q6.frame_limit [0: Low(20FPS), 1: Mid(default)(30FPS), 2: High(50FPS)]");
		return;
	}

	InFrameRate = FMath::Clamp(FCString::Atoi(*Args[0]), (int32)EFrameRateCap::Frame20, (int32)EFrameRateCap::Frame50);

	SetFrameRateLimit(FrameRateLimits[InFrameRate]);
	SetFrameRateLimitCVar(GetEffectiveFrameRateLimit());
}

void UQ6GameUserSettings::SetIdString(const FString& InIdString)
{
	IdString = InIdString;
	SaveSettings();
}

void UQ6GameUserSettings::SetMD5Password(const FString& InMD5Password)
{
	MD5Password = InMD5Password;
	SaveSettings();
}

UQ6GameUserSettings* UQ6GameUserSettings::Get()
{
	return CastChecked<UQ6GameUserSettings>(UGameUserSettings::GetGameUserSettings());
}

UQ6GameUserSettings* UQ6GameUserSettings::GetSafe()
{
	if (!GEngine)
	{
		return nullptr;
	}

	return Cast<UQ6GameUserSettings>(UGameUserSettings::GetGameUserSettings());
}

void UQ6GameUserSettings::UpdateGraphicQuality(int32 GraphicQuality)
{
	GraphicQuality = FMath::Clamp(GraphicQuality, 0, 2);

	ScalabilityQuality.SetFromSingleQualityLevel(GraphicQuality + 1);
	Scalability::SetQualityLevels(ScalabilityQuality);
}

void UQ6GameUserSettings::UpdateMSAAQuality(int32 MSAAQuality)
{
	MSAAQuality = FMath::Clamp(MSAAQuality, 0, 2);

	static const int32 MSAASetting[3] = { 1,2,4 };
	static auto CVarMobileMSAA = IConsoleManager::Get().FindConsoleVariable(TEXT("r.MobileMSAA"));

	CVarMobileMSAA->Set(MSAASetting[MSAAQuality], ECVF_SetByProjectSetting);
}

void UQ6GameUserSettings::UpdateOutlineQuality(int32 OutlineQuality)
{
	OutlineQuality = FMath::Clamp(OutlineQuality, 0, 2);

	static auto ICVar = IConsoleManager::Get().FindConsoleVariable(TEXT("r.Mobile.OutlineRendering"));
	ICVar->Set(OutlineQuality);
}

void UQ6GameUserSettings::UpdateFrameRate(int32 FrameRate)
{
	FrameRate = FMath::Clamp(FrameRate, 0, 2);

	SetFrameRateLimit(FrameRateLimits[FrameRate]);
	SetFrameRateLimitCVar(GetEffectiveFrameRateLimit());
}

void UQ6GameUserSettings::UpdateSoundSettings(const FGameSettingData& SettingData)
{
	if (GetGameResourcePtr())
	{
		GetGameSoundResource().GetBGMSoundClass()->Properties.Volume = SettingData.BGMVolume;
		GetGameSoundResource().GetEffectSoundClass()->Properties.Volume = SettingData.EffectVolume;
		GetGameSoundResource().GetVoiceSoundClass()->Properties.Volume = SettingData.VoiceVolume;
		GetGameSoundResource().GetUISoundClass()->Properties.Volume = SettingData.UIVolume;
	}
}

void UQ6GameUserSettings::SetGameData(const FGameSettingData& SettingData, const FGameNoticeData& NoticeData)
{
	GameSettingData = SettingData;
	GameNoticeData = NoticeData;

	ApplyGameData(GameSettingData, GameNoticeData);

	SaveSettings();
}

void UQ6GameUserSettings::ApplyGameData(const FGameSettingData& SettingData,
										const FGameNoticeData& NoticeData,
										bool bSkipSound)
{
	UpdateGraphicQuality(SettingData.GraphicQuality);
	UpdateMSAAQuality(SettingData.MSAAQuality);
	UpdateOutlineQuality(SettingData.OutlineQuality);
	UpdateFrameRate(SettingData.FrameRate);

	if (!bSkipSound)
	{
		UpdateSoundSettings(SettingData);
	}
}

void UQ6GameUserSettings::ApplySoundSettings()
{
	UpdateSoundSettings(GameSettingData);
}