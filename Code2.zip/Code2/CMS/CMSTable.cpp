// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "CMSTable.h"

#include "CombatCube/Q6GameState.h"
#include "Q6.h"
#include "Q6Log.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"
#include "LobbyObj_gen.h"
#include "SystemConstHelper.h"
#include "WidgetUtil.h"

const FUserLevelType MinLevel(1);

/////////////////////////////////////////////////////////////////////////////////////////////////////
// Member Functions

bool UCMS::OnPostLoading()
{
	if (!UCMSBase::OnPostLoading())
	{
		return false;
	}

	TArray<FName> RowNames = UCMSBase::FXpTable->GetRowNames();
	MaxLevel = FUserLevelType(RowNames.Num());
	Q6JsonLogKalms(Display, "GetMaxLevel", Q6KV("MaxLevel", MaxLevel));

	const FCMSXpRow& MaxXpRow = UCMSBase::GetXpRowOrDummy(MaxLevel);
	MaxXp = MaxXpRow.Acc;
	MaxWatt = MaxXpRow.WattRegenLimit;
	MaxFriendLimit = MaxXpRow.FriendCount;
	Q6JsonLogKalms(Display, "GetMaxXp", Q6KV("MaxXp", MaxXp));

	FourmulaConstRowCount = FFormulaConstTable->GetRowNames().Num();

	const int32 CooldownReduceOneLevel = SystemConst::Q6_COOLDOWN_REDUCE_LV_AMOUNT_ONE - 1;
	check(CooldownReduceOneLevel);
	const int32 CooldownReduceTwoLevel = SystemConst::Q6_COOLDOWN_REDUCE_LV_AMOUNT_TWO - 1;
	check(CooldownReduceTwoLevel);

	if (!ensure(CooldownReduceOneLevel < CooldownReduceTwoLevel
		&&CooldownReduceTwoLevel <= CombatCubeConst::Q6_MAX_SKILL_LEVEL))
	{
		return false;
	}

	CooldownReduce.SetNum(CombatCubeConst::Q6_MAX_SKILL_LEVEL);

	for (int i = 0; i < CombatCubeConst::Q6_MAX_SKILL_LEVEL; ++i)
	{
		CooldownReduce[i] = 2;
	}
	for (int i = 0; i < CooldownReduceOneLevel; ++i)
	{
		CooldownReduce[i] = 0;
	}
	for (int i = CooldownReduceOneLevel; i < CooldownReduceTwoLevel; ++i)
	{
		CooldownReduce[i] = 1;
	}

	// Box products

	TArray<FCMSBoxProductRow*> RowArray;
	UCMSBase::FBoxProductTable->GetAllRows("GetBoxProduct", RowArray);
	for (const FCMSBoxProductRow* BoxProductRow : RowArray)
	{
		BoxProducts.Add(BoxProductRow->PageKey, BoxProductRow);
	}

	// Episode clear rewards
	TArray<FCMSSagaRow*> OutRowArray;
	UCMSBase::FSagaTable->GetAllRows("GetStageRows", OutRowArray);
	for (const FCMSSagaRow* CurRow : OutRowArray)
	{
		bool EpisodeClearEnabled = true;
		EpisodeClearEnabled &= (CurRow->ContentType == EContentType::Saga || CurRow->ContentType == EContentType::Special);
		EpisodeClearEnabled &= (CurRow->GetEpisodeClearLootGroup().Num() == 1);
		if (EpisodeClearEnabled)
		{
			if (!EpisodeClearSagas.Contains(CurRow->Episode))
			{
				EpisodeClearSagas.Emplace(CurRow->Episode, CurRow);
			}
		}
	}

	TArray<FCMSSagaEpisodeOpenScheduleRow*> OutScheduleRowArray;
	UCMSBase::FSagaEpisodeOpenScheduleTable->GetAllRows("GetSagaEpisodeOpenScheduleRows", OutScheduleRowArray);
	for (const FCMSSagaEpisodeOpenScheduleRow* InRow : OutScheduleRowArray)
	{
		FSagaOpenSchedule& InAddedSchedule = SagaEpisodeOpenScheduleMap.Add(InRow->Episode);
		InAddedSchedule.CMSType = InRow->CmsType();
		FDateTime::Parse(InRow->OpenDate, InAddedSchedule.OpenDate);
		FDateTime::Parse(InRow->PresentDate, InAddedSchedule.PresentDate);
	}

	TArray<FCMSTrainingCenterRow*> OutTCRowArray;
	UCMSBase::GetTrainingCenter()->GetAllRows(TEXT("GetTrainingCenterType"), OutTCRowArray);
	for (int32 i = 0; i < OutTCRowArray.Num(); ++i)
	{
		FTrainingCenterType NextTCType = OutTCRowArray.IsValidIndex(i + 1) ? OutTCRowArray[i + 1]->CmsType() : TrainingCenterTypeInvalid;
		TrainingCenterNextMap.Add(OutTCRowArray[i]->CmsType(), NextTCType);
	}

	return true;
};

const FCMSSkillRow& UCMS::GetSkillRowOrDummy(int32 Type) const
{
	return UCMSBase::GetSkillRowOrDummy(FSkillType(Type));
}

const FCMSBuffRow& UCMS::GetBuffRowOrDummyBP(int32 Type) const
{
	return UCMSBase::GetBuffRowOrDummy(FBuffType(Type));
}

TArray<FCMSSkillEffectRow> UCMS::GetSkillEffects(int32 Type) const
{
	const FCMSSkillRow& Row = UCMSBase::GetSkillRowOrDummy(FSkillType(Type));
	const TArray<const FCMSSkillEffectRow*>& EffectRow = Row.GetSkillEffect();

	TArray<FCMSSkillEffectRow> ReturnArray;
	for (const auto& Iter : EffectRow)
	{
		ReturnArray.Add(*Iter);
	}

	return ReturnArray;
}

TArray<FCMSBuffEffectRow> UCMS::GetBuffEffects(int32 Type) const
{
	const FCMSBuffRow& Row = UCMSBase::GetBuffRowOrDummy(FBuffType(Type));
	const TArray<const FCMSBuffEffectRow*>& EffectRow = Row.GetBuffEffect();

	TArray<FCMSBuffEffectRow> ReturnArray;
	for (const auto& Iter : EffectRow)
	{
		ReturnArray.Add(*Iter);
	}

	return ReturnArray;
}

const TArray<const FCMSBuffEffectRow*> UCMS::GetBuffEffects(int32 BuffType, EBuffEffectCategory BuffEffectCategory) const
{
	const FCMSBuffRow& BuffRow = UCMSBase::GetBuffRowOrDummy(FBuffType(BuffType));
	const TArray<const FCMSBuffEffectRow*>& BuffEffectRows = BuffRow.GetBuffEffect();

	TArray<const FCMSBuffEffectRow*> ReturnArray;
	for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
	{
		if (BuffEffectRow->BuffEffectCategory == BuffEffectCategory)
		{
			ReturnArray.Add(BuffEffectRow);
		}
	}

	return ReturnArray;
}

const FCMSUnitRow& UCMS::GetUnitRowOrDummy(FUnitType UnitType) const
{
	return UCMSBase::GetUnitRowOrDummy(UnitType);
}

int32 UCMS::GetModelTypeFromUnitType(int32 UnitType) const
{
	const FCMSUnitRow& Row = UCMSBase::GetUnitRowOrDummy(FUnitType(UnitType));
	return Row.Model;
}

FUnitType UCMS::GetUnitType(FCharacterType CharacterType) const
{
	const FCMSUnitRow** Ret = UCMSBase::FCharacterToUnitMap.Find(CharacterType);
	if (Ret)
	{
		return (**Ret).CmsType();
	}

	ensureMsgf(0, TEXT("Character has no Unit : %d"), CharacterType.x);
	return UnitTypeInvalid;
}

const FCMSUnitRow& UCMS::GetUnitRowOrDummy(FCharacterType CharacterType) const
{
	const FCMSCharacterRow& Row = GetCharacterRowOrDummy(CharacterType);
	return Row.GetUnit();
}

// It must be replace CMS_Gen Generated function
FSagaType UCMS::FindSagaType(int32 InEpisode, int32 InStage, int32 InSubStage) const
{
	TArray<FCMSSagaRow*> OutRowArray;
	UCMSBase::FSagaTable->GetAllRows(TEXT("FindSagaType"), OutRowArray);

	for (const FCMSSagaRow* CurRow : OutRowArray)
	{
		if (CurRow->Episode == InEpisode && CurRow->Stage == InStage && CurRow->SubStage == InSubStage)
		{
			return CurRow->CmsType();
		}
	}

	return SagaTypeInvalid;
}

void UCMS::GetSagaFinishCondition(const FSagaType& Type, int32& LimitTurn, int32& LimitTime) const
{
	LimitTurn = 0;
	LimitTime = 0;

	const FCMSSagaRow& Row = GetCMS()->GetSagaRowOrDummy(Type);
	if (Row.IsInvalid())
	{
		return;
	}

	LimitTurn = Row.LimitTurn;
	LimitTime = Row.LimitTime;
}

const FCMSWaveRow* UCMS::GetWaveRow(FSagaType SagaType, int32 InWaveIndex) const
{
	if (bHasBonusMonster)
	{
		if (InWaveIndex > LastBonusWaveIndex)
		{
			// correct wave index
			InWaveIndex -= (LastBonusWaveIndex - StartBonusWaveIndex + 1);
		}
		else if (InWaveIndex == LastBonusWaveIndex)
		{
			return &LastBonusMonsterWaveRow;
		}
		else if (InWaveIndex >= StartBonusWaveIndex)
		{
			return &BonusMonsterWaveRow;
		}
	}

	const TArray<const FCMSWaveRow*>* Waves = UCMSBase::FSagaToWaveMap.Find(SagaType);

	if (ensure(Waves) && Waves->IsValidIndex(InWaveIndex))
	{
		return (*Waves)[InWaveIndex];
	}

	ensureMsgf(0, TEXT("Invalid CMSWaveRow Info : %d"), InWaveIndex);
	return nullptr;
}

const FString& UCMS::GetMapPath(FSagaType SagaType) const
{
	if (ensure(SagaType != SagaTypeInvalid))
	{
		const FCMSSagaRow& SagaRow = UCMSBase::GetSagaRowOrDummy(SagaType);
		const TArray<const FCMSMapRow*>& Maps = SagaRow.GetMap();
		if (ensure(Maps.IsValidIndex(0)))
		{
			return Maps[0]->MapPath;
		}
	}

	ensureMsgf(0, TEXT("Invalid CMSMapRow Info: %d"), SagaType.x);
	static FString Dummy(TEXT("/Game/Maps/Combat/Saga/Saga_1"));
	return Dummy;
}

int32 UCMS::GetMapLocatorGroup(FSagaType SagaType) const
{
	if (ensure(SagaType != SagaTypeInvalid))
	{
		const FCMSSagaRow& SagaRow = UCMSBase::GetSagaRowOrDummy(SagaType);
		const TArray<const FCMSMapRow*>& Maps = SagaRow.GetMap();
		if (ensure(Maps.IsValidIndex(0)))
		{
			return Maps[0]->LocatorGroup;
		}
	}

	ensureMsgf(0, TEXT("Invalid CMSMapRow Info: %d"), SagaType.x);
	return 1;
}

const FString& UCMS::GetLightPreset(FSagaType SagaType) const
{
	if (ensure(SagaType != SagaTypeInvalid))
	{
		const FCMSSagaRow& SagaRow = UCMSBase::GetSagaRowOrDummy(SagaType);
		const TArray<const FCMSMapRow*>& Maps = SagaRow.GetMap();
		if (ensure(Maps.IsValidIndex(0)))
		{
			return Maps[0]->LightPreset;
		}
	}

	ensureMsgf(0, TEXT("Invalid CMSMapRow Info: %d"), SagaType.x);
	static FString Dummy(TEXT(""));
	return Dummy;
}

const FCMSSkillUpgradeCostRow& UCMS::GetSkillUpgradeCostRowOrDummy(const FCMSSkillRow& SkillRow, int32 TargetLevel) const
{
	int32 MaterialIndex = FMath::Max(FMath::Min(TargetLevel, CombatCubeConst::Q6_MAX_SKILL_LEVEL) - 2, 0);	// level to material index
	const TArray<const FCMSSkillUpgradeCostRow*>& MaterialsRows = SkillRow.GetSkillUpgradeCost();
	if (!MaterialsRows.IsValidIndex(MaterialIndex) || !MaterialsRows[MaterialIndex])
	{
		Q6JsonLogRoze(Warning, "UCMS::GetSkillUpgradeMaterialsRowOrDummy - Not found materials", Q6KV("SkillType", SkillRow.Type));
		static const FCMSSkillUpgradeCostRow DummyRow;
		return DummyRow;
	}

	return *MaterialsRows[MaterialIndex];
}

const FCMSSkillEffectRow* UCMS::GetSkillEffectRow(int32 SkillType, EEffectCategory EffectCategory) const
{
	const FCMSSkillRow& SkillRow = UCMSBase::GetSkillRowOrDummy(FSkillType(SkillType));

	for (const FCMSSkillEffectRow* SkillEffectRow : SkillRow.GetSkillEffect())
	{
		if (SkillEffectRow->EffectCategory == EffectCategory)
		{
			return SkillEffectRow;
		}
	}

	return nullptr;
}

TArray<const FCMSBuffEffectRow*> UCMS::GetModifyCrowdControlEffects(const FCCBuffState& Buff, ECrowdControl Control)
{
	TArray<const FCMSBuffEffectRow*> Ret;

	for (const FCMSBuffEffectRow* Effect : GetBuffEffects(Buff.BuffType, EBuffEffectCategory::ModifyCrowdControl))
	{
		const FCMSCrowdControlRow& InRow = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(Effect->Param1));
		if (InRow.CrowdControl != Control)
		{
			continue;
		}

		Ret.Emplace(Effect);
	}

	return Ret;
}

TArray<const FCMSBuffEffectRow*> UCMS::GetModifyUnitAttributeEffects(const FCCBuffState& Buff, EUnitAttribute Attribute)
{
	TArray<const FCMSBuffEffectRow*> Ret;

	for (const FCMSBuffEffectRow* Effect : GetBuffEffects(Buff.BuffType, EBuffEffectCategory::ModifyUnitAttribute))
	{
		const FCMSUnitAttributeRow& InRow = GetCMS()->GetUnitAttributeRowOrDummy(FUnitAttributeType(Effect->Param1));
		if (InRow.UnitAttribute != Attribute)
		{
			continue;
		}

		Ret.Emplace(Effect);
	}

	return Ret;
}

const FCMSFormulaConstRow& UCMS::GetFormulaConstValues(int32 AliveAllyCount) const
{
	ensure(AliveAllyCount > 0);

	AliveAllyCount = FMath::Clamp(AliveAllyCount, 1, FourmulaConstRowCount);

	const FCMSFormulaConstRow& Row = UCMSBase::GetFormulaConstRowOrDummy(FFormulaConstType(AliveAllyCount));
	return Row;
}

const FCMSAttributeConstRow& UCMS::GetAttributeConstValues() const
{
	return UCMSBase::GetAttributeConstRowOrDummy(FAttributeConstType(1));
}

const FCMSAdditionalPointRow* UCMS::GetAdditionalPoint(int32 Difficulty, EAttributeCategory Category)
{
	TArray<FCMSAttributeDifficultyRow*> Rows;
	FAttributeDifficultyTable->GetAllRows("GetAdditionalPoint", Rows);

	for (const FCMSAttributeDifficultyRow* R : Rows)
	{
		if (R->Difficulty == Difficulty
			&& R->AttributeCategory == Category)
		{
			return &(R->GetAdditionalPoint());
		}
	}

	for (const FCMSAttributeDifficultyRow* R : Rows)
	{
		if (R->Difficulty == CombatCubeConst::Q6_DEFAULT_DIFFICULTY
			&& R->AttributeCategory == Category)
		{
			Q6JsonLog(Warning, "use default difficulty AdditionalPoint.", Q6KV("attribute", (int32)Category));
			return &(R->GetAdditionalPoint());
		}
	}

	Q6JsonLog(Error, "can not find AdditionalPoint.", Q6KV("Difficulty", Difficulty), Q6KV("attribute", (int32)Category));
	return nullptr;
}

const FCMSAttributeRatioRow* UCMS::GetAttributeRatio(EAttributeCategory Category)
{
	TArray<FCMSAttributeRatioRow*> Rows;
	FAttributeRatioTable->GetAllRows("GetAttributeRatio", Rows);

	for (const FCMSAttributeRatioRow* R : Rows)
	{
		if (R->AttributeCategory == Category)
		{
			return R;
		}
	}

	Q6JsonLog(Error, "can not find AttributeRatio.", Q6KV("attribute", (int32)Category));
	return nullptr;
}

const FCMSDifficultyNatureBonusRow* UCMS::GetDifficultyNatureBonus(int32 Difficulty)
{
	TArray<FCMSDifficultyNatureBonusRow*> Rows;
	FDifficultyNatureBonusTable->GetAllRows("GetDifficultyNatureBonus", Rows);

	for (const FCMSDifficultyNatureBonusRow* R : Rows)
	{
		if (R->Difficulty == Difficulty)
		{
			return R;
		}
	}

	for (const FCMSDifficultyNatureBonusRow* R : Rows)
	{
		if (R->Difficulty == CombatCubeConst::Q6_DEFAULT_DIFFICULTY)
		{
			Q6JsonLog(Warning, "use default difficulty DifficultyNatureBonus.");
			return R;
		}
	}

	Q6JsonLog(Error, "can not find DifficultyNatureBonus.", Q6KV("Difficulty", Difficulty));
	return nullptr;
}

TArray<int32> UCMS::GetEpisodes(EContentType ContentType) const
{
	TArray<int32> Episodes;
	TArray<FCMSSagaRow*> OutRowArray;
	UCMSBase::FSagaTable->GetAllRows("GetEpisodes", OutRowArray);

	for (const FCMSSagaRow* CurRow : OutRowArray)
	{
		if (CurRow->ContentType == ContentType)
		{
			Episodes.AddUnique(CurRow->Episode);
		}
	}

	Episodes.Sort();

	return Episodes;
}

TArray<const FCMSSagaRow*> UCMS::GetStageRows(EContentType ContentType, int32 Episode) const
{
	TArray<const FCMSSagaRow*> Stages;
	TArray<FCMSSagaRow*> OutRowArray;
	UCMSBase::FSagaTable->GetAllRows("GetStageRows", OutRowArray);

	for (const FCMSSagaRow* CurRow : OutRowArray)
	{
		if (CurRow->ContentType == ContentType && CurRow->Episode == Episode)
		{
			Stages.Add(CurRow);
		}
	}

	Stages.Sort([](const FCMSSagaRow& lhs, const FCMSSagaRow& rhs)
	{
		if (lhs.Stage == rhs.Stage)
		{
			return lhs.SubStage < rhs.SubStage;
		}

		return lhs.Stage < rhs.Stage;
	});

	return Stages;
}

int32 UCMS::GetNumStageRows(EContentType ContentType, int32 Episode) const
{
	TArray<FCMSSagaRow*> RowArray;
	UCMSBase::FSagaTable->GetAllRows(TEXT("GetNumStageRows"), RowArray);

	int32 NumStageRows = 0;

	for (auto& CurRow : RowArray)
	{
		if (CurRow->ContentType == ContentType && CurRow->Episode == Episode)
		{
			++NumStageRows;
		}
	}

	return NumStageRows;
}

int32 UCMS::GetStartXpFromLevel(const FUserLevelType& InLevel) const
{
	if (InLevel.x < MaxLevel.x)
	{
		const FCMSXpRow& XpRow = UCMSBase::GetXpRowOrDummy(InLevel);
		return XpRow.Acc;
	}
	return MaxXp;
}

int32 UCMS::GetEndXpFromLevel(const FUserLevelType& InLevel) const
{
	return GetStartXpFromLevel(FUserLevelType(InLevel.x + 1));
}

int32 UCMS::GetCharacterLevelFromXP(int64 XP) const
{
	TArray<FCMSCharacterXpRow *> RowArray;
	UCMSBase::GetCharacterXp()->GetAllRows(TEXT("GetCharacterXp"), RowArray);
	FCMSCharacterXpRow** Found = RowArray.FindByPredicate([&XP](FCMSCharacterXpRow* Row)
	{
		return (Row->Acc > XP);
	});
	if (!Found)
	{
		return RowArray.Num();
	}
	return (*Found)->Type - 1;
}

int32 UCMS::GetEquipLevelFromXP(int64 Xp) const
{
	TArray<FCMSItemXpRow *> RowArray;
	UCMSBase::GetItemXp()->GetAllRows(TEXT("GetItemXp"), RowArray);
	FCMSItemXpRow** Found = RowArray.FindByPredicate([&Xp](FCMSItemXpRow* Row)
	{
		return (Row->Acc > Xp);
	});
	if (!ensure(Found))
	{
		return RowArray.Num();
	}
	return (*Found)->Type - 1;
}

int32 UCMS::GetWattLimitFromLevel(const FUserLevelType& InLevel) const
{
	if (InLevel.x < MaxLevel.x)
	{
		const FCMSXpRow& XpRow = UCMSBase::GetXpRowOrDummy(InLevel);
		return XpRow.WattRegenLimit;
	}
	return MaxWatt;
}

int32 UCMS::GetFriendLimitFromLevel(const FUserLevelType& InLevel) const
{
	if (InLevel.x < MaxLevel.x)
	{
		const FCMSXpRow& XpRow = UCMSBase::GetXpRowOrDummy(InLevel);
		return XpRow.FriendCount;
	}
	return MaxFriendLimit;
}

int32 UCMS::GetCoolTimeOriginal(int32 SkillType) const
{
	int32 CoolTime = 1;

	const FCMSSkillEffectRow* SkillEffectRow = GetSkillEffectRow(SkillType, EEffectCategory::CoolTime);
	if (SkillEffectRow)
	{
		CoolTime = SkillEffectRow->Param1;
	}

	return CoolTime;
}

int32 UCMS::GetCooltimeReduce(int32 SkillLevel) const
{
	int32 SkillLevelIndex = FMath::Clamp(SkillLevel - 1,
		CombatCubeConst::Q6_BLOCKED_SKILL_LEVEL,
		CombatCubeConst::Q6_MAX_SKILL_LEVEL);
	check(CooldownReduce.IsValidIndex(SkillLevelIndex));
	return CooldownReduce[SkillLevelIndex];
}

int32 UCMS::GetCooltimeByLevel(int32 SkillType, int32 SkillLevel) const
{
	int32 OriginalCooltime = GetCoolTimeOriginal(SkillType);
	int32 SkillLevelIndex = SkillLevel - 1;
	if (CooldownReduce.IsValidIndex(SkillLevelIndex))
	{
		int32 ResultCooltime = FMath::Max(OriginalCooltime - CooldownReduce[SkillLevelIndex], 0);
		return ResultCooltime;
	}

	return -1;
}

bool UCMS::GetWaveMonsterInfo(const FActionContext& Context, const FCCCombatCubeState& InOutState, const FCMSWaveRow* Wave, int32 InDifficulty, int32 InSlot,
	int32 InWaveIndex, FUnitType& OutUnitType, int32& OutLevel, FCMSAdditionalPointRow** OutAdditionalPoint)
{
	*OutAdditionalPoint = nullptr;

	switch (InSlot)
	{
	case 1:
		OutUnitType = InOutState.CombatSeed.Seed.WaveMonsters[InWaveIndex].SpawnUnitType[0];
		OutLevel = Wave->Spawn01Level;
		break;

	case 2:
		OutUnitType = InOutState.CombatSeed.Seed.WaveMonsters[InWaveIndex].SpawnUnitType[1];
		OutLevel = Wave->Spawn02Level;
		break;

	case 3:
		OutUnitType = InOutState.CombatSeed.Seed.WaveMonsters[InWaveIndex].SpawnUnitType[2];
		OutLevel = Wave->Spawn03Level;
		break;

	default:
		OutUnitType = UnitTypeInvalid;
		return false;
	}

	if (OutUnitType == UnitTypeInvalid)
	{
		Q6JsonLogBro(Display, "wrong unit type attribute.", Q6KV("UnitType", OutUnitType.x), Q6KV("slot", InSlot));
		return false;
	}

	const FCMSUnitRow& Unit = GetUnitRowOrDummy(OutUnitType);
	if (Unit.IsInvalid())
	{
		Q6JsonLogBro(Display, "wrong unit type attribute.", Q6KV("UnitType", OutUnitType), Q6KV("slot", InSlot));
		return false;
	}

	*OutAdditionalPoint = const_cast<FCMSAdditionalPointRow*>(GetAdditionalPoint(InDifficulty, Unit.AttributeCategory));
	if (!(*OutAdditionalPoint))
	{
		Q6JsonLogBro(Error, "wrong wave monster additional point.", Q6KV("UnitType", OutUnitType.x), Q6KV("slot", InSlot));
		return false;
	}

	return true;
}

EApplyTagCompare UCMS::GetApplyTagCompare(EApplyTag Tag)
{
	TArray<FCMSApplyTagRow*> RowArray;
	UCMSBase::GetApplyTag()->GetAllRows(TEXT("GetApplyTagCompare"), RowArray);
	FCMSApplyTagRow** Found = RowArray.FindByPredicate([Tag](FCMSApplyTagRow* Row)
	{
		return (Row->ApplyTag == Tag);
	});
	if (!ensure(Found))
	{
		return EApplyTagCompare::Keyword;
	}
	return (*Found)->CompareType;
}

FText UCMS::GetApplyTagDesc(EApplyTag Tag) const
{
	TArray<FCMSApplyTagRow*> RowArray;
	UCMSBase::GetApplyTag()->GetAllRows(TEXT("GetApplyTagDesc"), RowArray);
	FCMSApplyTagRow** Found = RowArray.FindByPredicate([Tag](FCMSApplyTagRow* Row)
	{
		return (Row->ApplyTag == Tag);
	});
	if (!ensure(Found))
	{
		return FText::GetEmpty();
	}
	return (*Found)->Desc;
}

bool UCMS::IsSagaEpisodeOpen(int32 InEpisode) const
{
	const FSagaOpenSchedule* InFoundSchedule = SagaEpisodeOpenScheduleMap.Find(InEpisode);
	if (!InFoundSchedule)
	{
		return true;
	}

	return FDateTime::Now() > InFoundSchedule->OpenDate;
}

bool UCMS::IsSagaEpisodePresent(int32 InEpisode) const
{
	const FSagaOpenSchedule* InFoundSchedule = SagaEpisodeOpenScheduleMap.Find(InEpisode);
	if (!InFoundSchedule)
	{
		return true;
	}

	return FDateTime::Now() > InFoundSchedule->PresentDate;
}

FText UCMS::GetSagaEpisodeOpenScheduleDesc(int32 InEpisode) const
{
	const FSagaOpenSchedule* InFoundSchedule = SagaEpisodeOpenScheduleMap.Find(InEpisode);
	if (!InFoundSchedule)
	{
		return FText::GetEmpty();
	}

	const FCMSSagaEpisodeOpenScheduleRow& InRow = GetSagaEpisodeOpenScheduleRowOrDummy(InFoundSchedule->CMSType);
	return InRow.Desc;
}

const FCMSPromoteCostRow& UCMS::GetCharacterUpStarCostRowOrDummy(EUpgradeCharacterCategory UpCategory, const FCharacterInfo& CharacterInfo) const
{
	const FCMSUnitRow& UnitRow = GetUnitRowOrDummy(CharacterInfo.Type);
	ENatureType NatureType = UnitRow.NatureType;

	if (UpCategory == EUpgradeCharacterCategory::Unbind)
	{
		return GetCharacterUnbindCostRowOrDummy(CharacterInfo);
	}

	return GetPromoteCostRowOrDummy(EPromoteCategory::Character, NatureType, CharacterInfo.Star + 1);
}

const FCMSPromoteCostRow& UCMS::GetCharacterUnbindCostRowOrDummy(const FCharacterInfo& CharacterInfo) const
{
	const FCMSUnitRow& UnitRow = GetUnitRowOrDummy(CharacterInfo.Type);
	TArray<FCMSPromoteCostRow*> RowArray;
	UCMSBase::GetPromoteCost()->GetAllRows(TEXT("GetPromoteCost"), RowArray);
	FCMSPromoteCostRow** Found = RowArray.FindByPredicate([=](FCMSPromoteCostRow* Row)
	{
		if (Row->Category != EPromoteCategory::Character)
		{
			return false;
		}

		if (Row->UnbindId != CharacterInfo.Type)
		{
			return false;
		}

		if (Row->NatureType != UnitRow.NatureType)
		{
			return false;
		}

		if (Row->Star != (CharacterInfo.Star + 1))
		{
			return false;
		}

		return true;
	});

	if (Found)
	{
		return **Found;
	}

	Q6JsonLogRoze(Warning, "FCMSPromoteCostRow::GetCharacterUnbindCostRowOrDummy() - Not found unbind cost");
	static const FCMSPromoteCostRow DummyRow;
	return DummyRow;
}

const FCMSSkillRow& UCMS::GetCharacterUltimateSkillRow(FCharacterType CharacterType) const
{
	const FCMSUnitRow& UnitRow = GetUnitRowOrDummy(CharacterType);
	return GetCharacterUltimateSkillRow(UnitRow);
}

const FCMSSkillRow& UCMS::GetCharacterUltimateSkillRow(const FCMSUnitRow& UnitRow) const
{
	if ((UnitRow.GetUltimateSkills().Num() <= 0) || !UnitRow.GetUltimateSkills()[0])
	{
		Q6JsonLogRoze(Error, "Invalid ultimate skill", Q6KV("UnitType", UnitRow.Type));
		static FCMSSkillRow SkillRow;
		return SkillRow;
	}

	return *UnitRow.GetUltimateSkills()[0];
}

const FCMSSkillRow* UCMS::GetCharacterTurnSkillRow(const FCMSUnitRow& UnitRow, int32 Index) const
{
	const TArray<const FCMSSkillRow*>& TurnSkills = UnitRow.GetTurnSkills();

	if (TurnSkills.IsValidIndex(Index))
	{
		return TurnSkills[Index];
	}

	Q6JsonLogRoze(Error, "UCMS::GetCharacterTurnSkillRow - Not found turn skill", Q6KV("UnitType", UnitRow.Type), Q6KV("Index", Index));
	return nullptr;
}

const FCMSSkillRow& UCMS::GetCharacterSupportSkillRow(FCharacterType CharacterType) const
{
	const FCMSUnitRow& UnitRow = GetUnitRowOrDummy(CharacterType);
	return GetCharacterSupportSkillRow(UnitRow);
}

const FCMSSkillRow& UCMS::GetCharacterSupportSkillRow(const FCMSUnitRow& UnitRow) const
{
	if ((UnitRow.GetSupportSkills().Num() <= 0) || !UnitRow.GetSupportSkills()[0])
	{
		Q6JsonLogRoze(Error, "Invalid support skill", Q6KV("UnitType", UnitRow.Type));
		static FCMSSkillRow SkillRow;
		return SkillRow;
	}

	return *UnitRow.GetSupportSkills()[0];
}

const FCMSPromoteCostRow& UCMS::GetEquipPromoteCostRowOrDummy(EPromoteCategory Category, int32 TargetStar) const
{
	// Relic and sculpture have no nature. default nature type is fire.
	return GetPromoteCostRowOrDummy(Category, ENatureType::None, TargetStar);
}

const FCMSPromoteCostRow& UCMS::GetPromoteCostRowOrDummy(EPromoteCategory Category, ENatureType NatureType, int32 TargetStar) const
{
	TArray<FCMSPromoteCostRow*> RowArray;
	UCMSBase::GetPromoteCost()->GetAllRows(TEXT("GetPromoteCost"), RowArray);
	FCMSPromoteCostRow** Found = RowArray.FindByPredicate([&Category, &NatureType, &TargetStar](FCMSPromoteCostRow* Row)
	{
		if (Row->Category != Category)
		{
			return false;
		}

		if (Row->NatureType != NatureType)
		{
			return false;
		}

		if (Row->Star != TargetStar)
		{
			return false;
		}

		return true;
	});

	if (Found)
	{
		return **Found;
	}

	Q6JsonLogRoze(Warning, "FCMSPromoteCostRow::GetPromoteCostRowOrDummy() - Not found promote cost");
	static const FCMSPromoteCostRow DummyRow;
	return DummyRow;
}

float UCMS::GetCharacterNatureTypeBonusRatio() const
{
	return CharacterFormulaConst::Q6_SAME_TYPE_BONUS_RATIO / 100.f;
}

const TArray<const FCMSDailyDungeonRow*> UCMS::GetDailyDungeonValidRows(EDayOfWeekType DayOfWeek) const
{
	TArray<const FCMSDailyDungeonRow*> RowArray, FilteredRowArray;

	UCMSBase::GetDailyDungeon()->GetAllRows(TEXT("GetDailyDungeon"), RowArray);

	for (const FCMSDailyDungeonRow* Row : RowArray)
	{
		check(Row);

		if (Row->DayOfWeek != EDayOfWeekType::All && Row->DayOfWeek != DayOfWeek)
		{
			continue;
		}

		FilteredRowArray.AddUnique(Row);
	}

	return FilteredRowArray;
}

EDailyDungeonCategory UCMS::GetDailyDungeonCategory(FSagaType SagaType, EDayOfWeekType DayOfWeekType) const
{
	const TArray<const FCMSDailyDungeonRow*> DailyRows = GetDailyDungeonValidRows(DayOfWeekType);
	for (const FCMSDailyDungeonRow* Row : DailyRows)
	{
		if (Row->GetSaga().CmsType() == SagaType)
		{
			return Row->DungeonType;
		}
	}

	return EDailyDungeonCategory::None;
}

const FCMSDailyDungeonRow* UCMS::GetDailyDungeonRow(FSagaType SagaType) const
{
	TArray<const FCMSDailyDungeonRow*> RowArray;
	UCMSBase::GetDailyDungeon()->GetAllRows(TEXT("GetDailyDungeon"), RowArray);

	for (const FCMSDailyDungeonRow* Row : RowArray)
	{
		check(Row);

		if (Row->GetSaga().CmsType() != SagaType)
		{
			continue;
		}

		return Row;
	}

	return nullptr;
}

bool UCMS::HasBossBonusDailyDungeon(FSagaType SagaType) const
{
	const FCMSDailyDungeonRow* Row = GetDailyDungeonRow(SagaType);
	if (!Row)
	{
		return false;
	}

	return (Row->BossId > 0);
}

TArray<const FCMSSpecialRow*> UCMS::GetSpecialEpisodes(ESpecialCategory Category) const
{
	TArray<const FCMSSpecialRow*> RowArray, FilteredRowArray;

	UCMSBase::GetSpecial()->GetAllRows(TEXT("GetSpecial"), RowArray);

	for (const FCMSSpecialRow* Row : RowArray)
	{
		check(Row);

		if (Row->ConditionType != Category)
		{
			continue;
		}

		FilteredRowArray.AddUnique(Row);
	}

	return FilteredRowArray;
}

const FCMSSpecialRow* UCMS::GetSpecialRow(ESpecialCategory Category, int32 Episode) const
{
	TArray<const FCMSSpecialRow*> RowArray;
	UCMSBase::GetSpecial()->GetAllRows(TEXT("GetSpecial"), RowArray);

	const FCMSSpecialRow** Found = RowArray.FindByPredicate([&Category, &Episode](const FCMSSpecialRow* Row)
	{
		if (Row->ConditionType != Category)
		{
			return false;
		}

		if (Row->Episode != Episode)
		{
			return false;
		}

		return true;
	});

	if (Found)
	{
		return *Found;
	}

	return nullptr;
}

const FCMSSpecialRow* UCMS::GetFirstSpecialRowByCategory(ESpecialCategory Category) const
{
	TArray<const FCMSSpecialRow*> RowArray;
	UCMSBase::GetSpecial()->GetAllRows(TEXT("GetSpecial"), RowArray);

	for (const FCMSSpecialRow* Row : RowArray)
	{
		if (!Row)
		{
			continue;
		}

		if (Row->ConditionType == Category)
		{
			return Row;
		}
	}

	return nullptr;
}

TArray<const FCMSSagaRow*> UCMS::GetPrevSpecialSagaRows(FSagaType SagaType) const
{
	TArray<FCMSSagaRow*> OutRowArray;
	UCMSBase::GetSaga()->GetAllRows(TEXT("FindSagaType"), OutRowArray);

	TArray<const FCMSSagaRow*> SagaRows;
	for (const FCMSSagaRow* Row : OutRowArray)
	{
		check(Row);

		if (Row->NextType != SagaType)
		{
			continue;
		}

		if (Row->Type == SagaType)
		{
			continue;
		}

		SagaRows.AddUnique(Row);
	}

	return SagaRows;
}

const FCMSSpecialRow* UCMS::GetSpecialRow(FSagaType SagaType) const
{
	TArray<const FCMSSpecialRow*> RowArray;
	UCMSBase::GetSpecial()->GetAllRows(TEXT("GetDailyFirstClearReward"), RowArray);

	const FCMSSagaRow& SagaRow = GetSagaRowOrDummy(SagaType);
	for (const FCMSSpecialRow* Row : RowArray)
	{
		check(Row);

		if (Row->Episode == SagaRow.Episode)
		{
			return Row;
		}
	}

	return nullptr;
}

const FCMSDailyFirstClearRewardRow& UCMS::GetDailyFirstClearRewardRowByDayOfWeek(EDayOfWeekType InDayOfWeek) const
{
	TArray<const FCMSDailyFirstClearRewardRow*> RowArray;
	UCMSBase::GetDailyFirstClearReward()->GetAllRows(TEXT("GetDailyFirstClearReward"), RowArray);

	for (const FCMSDailyFirstClearRewardRow* Row : RowArray)
	{
		check(Row);

		if (Row->DayOfWeek != InDayOfWeek)
		{
			continue;
		}

		return *Row;
	}

	static const FCMSDailyFirstClearRewardRow DummyRow;
	return DummyRow;
}

FSagaType UCMS::GetEpisodeClearSagaType(int32 Episode) const
{
	const FCMSSagaRow*const * SagaRowPtr = EpisodeClearSagas.Find(Episode);
	if (SagaRowPtr)
	{
		return (*SagaRowPtr)->CmsType();
	}

	return SagaTypeInvalid;
}

const FCMSLootDataRow& UCMS::GetEpisodeClearReward(FSagaType SagaType) const
{
	const FCMSSagaRow& SagaRow = GetSagaRowOrDummy(SagaType);
	if (!SagaRow.IsInvalid())
	{
		const TArray<const FCMSLootGroupRow*> LootGroupRows = SagaRow.GetEpisodeClearLootGroup();
		if (LootGroupRows.Num() == 1)
		{
			return GetFirstLootDataOrDummyFromLootGroups(LootGroupRows);
		}
	}

	static const FCMSLootDataRow Dummy;
	return Dummy;
}

const FCMSLootDataRow& UCMS::GetEpisodeClearRewardByEpisode(int32 Episode) const
{
	FSagaType SagaType = GetEpisodeClearSagaType(Episode);
	return GetEpisodeClearReward(SagaType);
}

bool UCMS::GetBoxProductRows(int32 PageKey, TArray<const FCMSBoxProductRow*>& BoxProductArray) const
{
	BoxProducts.MultiFind(PageKey, BoxProductArray);
	return (BoxProductArray.Num() > 0);
}

int32 UCMS::GetNeedPickupMileage(int32 EventId) const
{
	for (const auto& Elem : BoxProducts)
	{
		const FCMSBoxProductRow* Row = Elem.Value;
		check(Row);

		if (Row->EventId != EventId)
		{
			continue;
		}

		return Row->NeedPickupMileage;
	}

	Q6JsonLogRoze(Error, "UCMS::GetNeedPickupMileage - Not found box product row", Q6KV("EventId", EventId));
	return 0;
}

const FCMSLootDataRow& UCMS::GetLootDataOrDummy(int32 LootId) const
{
	TArray<const FCMSLootDataRow*> RowArray;

	UCMSBase::GetLootData()->GetAllRows(TEXT("GetLootData"), RowArray);
	const FCMSLootDataRow** Found = RowArray.FindByPredicate([&LootId](const FCMSLootDataRow* Row)
	{
		if (Row->LootId != LootId)
		{
			return false;
		}

		return true;
	});

	if (Found)
	{
		return **Found;
	}

	Q6JsonLogRoze(Warning, "UCMS::GetLootDataOrDummy - Invalid loot id", Q6KV("LootId", LootId));
	static const FCMSLootDataRow DummyRow;
	return DummyRow;
}

const FCMSLootDataRow& UCMS::GetFirstLootDataOrDummyFromLootGroups(const FCMSLootGroupRow& LootGroupRow) const
{
	static const FCMSLootDataRow DummyRow;

	if (LootGroupRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UCMS::GetFirstLootDataOrDummyFromLootGroups - No LootGroupRows!");
		return DummyRow;
	}

	const TArray<int32> LootIds = LootGroupRow.LootIds;
	if (!LootIds.IsValidIndex(0))
	{
		Q6JsonLogGunny(Warning, "UCMS::GetFirstLootDataOrDummyFromLootGroups - No LootIds!");
		return DummyRow;
	}
	return GetLootDataOrDummy(LootIds[0]);
}

const FCMSLootDataRow& UCMS::GetFirstLootDataOrDummyFromLootGroups(const TArray<const FCMSLootGroupRow*>& LootGroupRows) const
{
	static const FCMSLootDataRow DummyRow;

	if (!LootGroupRows.IsValidIndex(0))
	{
		Q6JsonLogGunny(Warning, "UCMS::GetFirstLootDataOrDummyFromLootGroups - No LootGroupRows!");
		return DummyRow;
	}
	const TArray<int32> LootIds = LootGroupRows[0]->LootIds;

	if (!LootIds.IsValidIndex(0))
	{
		Q6JsonLogGunny(Warning, "UCMS::GetFirstLootDataOrDummyFromLootGroups - No LootIds!");
		return DummyRow;
	}
	return GetLootDataOrDummy(LootIds[0]);
}

bool UCMS::IsPercentAttribute(FUnitAttributeType UnitAttributeType) const
{
	EUnitAttribute UnitAttribute = EUnitAttribute(UnitAttributeType.x - 1);	// Convert 1-base to 0-base
	switch (UnitAttribute)
	{
		case EUnitAttribute::AtkVary:
		case EUnitAttribute::DefVary:
		case EUnitAttribute::HealthRegen:
		case EUnitAttribute::UltimateVary:
		case EUnitAttribute::DamageVary:
		case EUnitAttribute::MaxHealth:
		case EUnitAttribute::MaxSA:
		case EUnitAttribute::MaxUA:
		case EUnitAttribute::Atk:
		case EUnitAttribute::Def:
		case EUnitAttribute::HealVary:
		case EUnitAttribute::Immune:
			return false;
		default:
			return true;
	}
}

bool UCMS::GetPointVaryConvertTypeFromUnitAttribute(EUnitAttribute InUnitAttribute, EPointVaryConvertType& OutPointVaryConvertType) const
{
	static_assert(EPointVaryConvertTypeMax == 16, "need more convert type.");

	switch (InUnitAttribute)
	{
		case EUnitAttribute::AtkVary:
			OutPointVaryConvertType = EPointVaryConvertType::AtkVary;
			return true;
		case EUnitAttribute::AtkVaryper:
			OutPointVaryConvertType = EPointVaryConvertType::AtkVaryper;
			return true;
		case EUnitAttribute::DefVary:
			OutPointVaryConvertType = EPointVaryConvertType::DefVary;
			return true;
		case EUnitAttribute::DefVaryper:
			OutPointVaryConvertType = EPointVaryConvertType::DefVaryper;
			return true;
		case EUnitAttribute::CriVaryper:
			OutPointVaryConvertType = EPointVaryConvertType::CriVaryper;
			return true;
		case EUnitAttribute::CriDamVaryper:
			OutPointVaryConvertType = EPointVaryConvertType::CriDamVaryper;
			return true;
		case EUnitAttribute::UltimateVary:
			OutPointVaryConvertType = EPointVaryConvertType::UltimateVary;
			return true;
		case EUnitAttribute::UltimateVaryper:
			OutPointVaryConvertType = EPointVaryConvertType::UltimateVaryper;
			return true;
		case EUnitAttribute::DamageVary:
			OutPointVaryConvertType = EPointVaryConvertType::DamageVary;
			return true;
		case EUnitAttribute::DamageVaryper:
			OutPointVaryConvertType = EPointVaryConvertType::DamageVaryper;
			return true;
		case EUnitAttribute::HealVary:
			OutPointVaryConvertType = EPointVaryConvertType::HealVary;
			return true;
		case EUnitAttribute::HealVaryper:
			OutPointVaryConvertType = EPointVaryConvertType::HealVaryper;
			return true;
	default:
		ensure(0);
		return false;
	}
}

bool UCMS::GetUnitAttributeFromPointVaryConvertType(EPointVaryConvertType InConvertType, EUnitAttribute& OutUnitAttribute) const
{
	static_assert(EPointVaryConvertTypeMax == 16, "need more convert type.");

	switch (InConvertType)
	{
		case EPointVaryConvertType::AtkVary:
			OutUnitAttribute = EUnitAttribute::AtkVary;
			return true;
		case EPointVaryConvertType::AtkVaryper:
			OutUnitAttribute = EUnitAttribute::AtkVaryper;
			return true;
		case EPointVaryConvertType::DefVary:
			OutUnitAttribute = EUnitAttribute::DefVary;
			return true;
		case EPointVaryConvertType::DefVaryper:
			OutUnitAttribute = EUnitAttribute::DefVaryper;
			return true;
		case EPointVaryConvertType::CriVaryper:
			OutUnitAttribute = EUnitAttribute::CriVaryper;
			return true;
		case EPointVaryConvertType::CriDamVaryper:
			OutUnitAttribute = EUnitAttribute::CriDamVaryper;
			return true;
		case EPointVaryConvertType::UltimateVary:
			OutUnitAttribute = EUnitAttribute::UltimateVary;
			return true;
		case EPointVaryConvertType::UltimateVaryper:
			OutUnitAttribute = EUnitAttribute::UltimateVaryper;
			return true;
		case EPointVaryConvertType::DamageVary:
			OutUnitAttribute = EUnitAttribute::DamageVary;
			return true;
		case EPointVaryConvertType::DamageVaryper:
			OutUnitAttribute = EUnitAttribute::DamageVaryper;
			return true;
		case EPointVaryConvertType::HealVary:
			OutUnitAttribute = EUnitAttribute::HealVary;
			return true;
		case EPointVaryConvertType::HealVaryper:
			OutUnitAttribute = EUnitAttribute::HealVaryper;
			return true;
	default:
		ensure(0);
		return false;
	}
}

FUnitAttributeType UCMS::GetUnitAttributeType(EPointVaryConvertType InPointVaryConvertType) const
{
	EUnitAttribute PointVaryUnitAttribute;
	if (!GetUnitAttributeFromPointVaryConvertType(InPointVaryConvertType, PointVaryUnitAttribute))
	{
		return UnitAttributeTypeInvalid;
	}

	return GetUnitAttributeType(PointVaryUnitAttribute);
}

FUnitAttributeType UCMS::GetUnitAttributeType(EUnitAttribute InUnitAttribute) const
{
	const UDataTable* UnitAttributeTable = UCMSBase::GetUnitAttribute();
	if (!UnitAttributeTable)
	{
		return UnitAttributeTypeInvalid;
	}

	TArray<const FCMSUnitAttributeRow*> UnitAttributeRows;
	UnitAttributeTable->GetAllRows("GetUnitAttributeRows", UnitAttributeRows);
	for (const FCMSUnitAttributeRow* UnitAttributeRow : UnitAttributeRows)
	{
		if (!UnitAttributeRow)
		{
			continue;
		}

		if (UnitAttributeRow->UnitAttribute == InUnitAttribute)
		{
			return UnitAttributeRow->CmsType();
		}
	}

	return UnitAttributeTypeInvalid;
}

bool UCMS::IsInfinityEventScheduleFormat(const FEventScheduleInfo& Info)
{
	return (Info.StartDate == -1 || Info.EndDate == -1);
}

TArray<int32> UCMS::GetValidOrderedPageList(const TArray<FEventScheduleInfo>& Infos)
{
	TArray<int32> OrderedPages;
	TArray<FCMSBoxProductRow*> RowArray;
	UCMSBase::GetBoxProduct()->GetAllRows(TEXT("GetValidOrderedPageList"), RowArray);

	for (const FCMSBoxProductRow* Row : RowArray)
	{
		int32 EventId = Row->EventId;
		bool bValid = Infos.ContainsByPredicate([&EventId](const FEventScheduleInfo& ScheduleInfo)
		{
			return ScheduleInfo.EventId == EventId;
		});

		if (!bValid)
		{
			continue;
		}

		OrderedPages.AddUnique(Row->PageKey);
	}

	OrderedPages.Sort();
	return OrderedPages;
}

bool UCMS::IsValidTrainingCenter(FTrainingCenterType Type, FSagaType SagaType)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(SagaType);
	if (SagaRow.IsInvalid() || SagaRow.ContentType != EContentType::TrainingCenter)
	{
		return false;
	}

	const FCMSTrainingCenterRow& TrainingCenterRow = GetCMS()->GetTrainingCenterRowOrDummy(Type);
	if (TrainingCenterRow.IsInvalid())
	{
		return false;
	}

	auto Ret = GetCMS()->GetTrainingCenterToStartSagaMap().Find(Type);

	if (!Ret)
	{
		return false;
	}

	FSagaType FindSagaType = (*Ret)->CmsType();
	if (FindSagaType == SagaType)
	{
		return true;
	}

	while (1)
	{
		const FCMSSagaRow& FindSagaRow = GetCMS()->GetSagaRowOrDummy(FindSagaType);
		if (FindSagaRow.IsInvalid())
		{
			break;
		}

		if (FindSagaRow.Episode != SagaRow.Episode)
		{
			break;
		}

		FSagaType NextSagaType = FSagaType(FindSagaRow.NextType);
		if (NextSagaType == SagaType)
		{
			return true;
		}

		FindSagaType = NextSagaType;
	}

	return false;
}

bool UCMS::HasNextStepInTrainingCenter(FTrainingCenterType InType) const
{
	if (TrainingCenterNextMap.Contains(InType))
	{
		return TrainingCenterNextMap[InType] != TrainingCenterTypeInvalid;
	}

	return false;
}

bool UCMS::IsPlayableStepInTrainingCenter(const FCMSTrainingCenterRow& InBeginRow, FTrainingCenterType InType) const
{
	return InBeginRow.PlayableTrainingCenterType >= InType.x;
}

FTrainingCenterType UCMS::GetNextTrainingCenter(FTrainingCenterType InType) const
{
	if (InType == TrainingCenterTypeInvalid)
	{
		return TrainingCenterTypeInvalid;
	}

	if (TrainingCenterNextMap.Contains(InType))
	{
		return TrainingCenterNextMap[InType];
	}

	return TrainingCenterTypeInvalid;
}

FCharacterType UCMS::GetTrainingCenterJokerType(FTrainingCenterType Type) const
{
	const FCMSTrainingCenterRow& TrainingCenterRow = GetTrainingCenterRowOrDummy(Type);
	const FCMSSagaRow& SagaRow = TrainingCenterRow.GetStartSaga();

	if (SagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UCMS::GetTrainingCenterJoker - SagaRows does not exist. ");
		return CharacterTypeInvalid;
	}

	const TArray<const FCMSCharacterRow*>& CharacterRows = SagaRow.GetJoker();
	if (!CharacterRows.IsValidIndex(0))
	{
		return CharacterTypeInvalid;
	}

	return CharacterRows[0]->CmsType();
}

const FCMSLootDataRow& UCMS::GetTrainingCenterClearReward(FTrainingCenterType Type) const
{
	const FCMSTrainingCenterRow& TrainingCenterRow = GetTrainingCenterRowOrDummy(Type);
	const TArray<const FCMSLootGroupRow*>& ClearRewards = TrainingCenterRow.GetEndSaga().GetEpisodeClearLootGroup();
	static const FCMSLootDataRow DummyRow;

	if (!ClearRewards.IsValidIndex(0))
	{
		Q6JsonLogGunny(Warning, "UCMS::GetTrainingCenterClearReward - TrainingCenterRow does not have data.");
		return DummyRow;
	}

	const TArray<int32>& LootIds = ClearRewards[0]->LootIds;
	if (!LootIds.IsValidIndex(0))
	{
		Q6JsonLogGunny(Warning, "UCMS::GetTrainingCenterClearReward - TrainingCenterRow does not have LootIds.");
		return DummyRow;
	}

	return GetLootDataOrDummy(LootIds[0]);
}

FTrainingCenterType UCMS::GetTrainingCenterType(FSagaType SagaType) const
{
	TArray<FCMSTrainingCenterRow*> RowArray;
	UCMSBase::GetTrainingCenter()->GetAllRows(TEXT("GetTrainingCenterType"), RowArray);
	const FCMSSagaRow& InSagaRow = GetSagaRowOrDummy(SagaType);
	if (InSagaRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UCMS::GetTrainingCenterType - InSagaRow doesn't exist. ", Q6KV("SagaType", SagaType));
		return TrainingCenterTypeInvalid;
	}

	for (auto& Row : RowArray)
	{
		const FCMSSagaRow& SagaRow = Row->GetStartSaga();
		if (SagaRow.IsInvalid())
		{
			Q6JsonLogGunny(Warning, "UCMS::GetTrainingCenterType - SagaRows don't exist. ", Q6KV("SagaType", SagaType));
			return TrainingCenterTypeInvalid;
		}

		if (SagaRow.Episode == InSagaRow.Episode)
		{
			return Row->CmsType();
		}
	}

	Q6JsonLogGunny(Warning, "UCMS::GetTrainingCenterType - Cannot find that SagaType. ", Q6KV("SagaType", SagaType));
	return TrainingCenterTypeInvalid;
}

int64 UCMS::GetUpgradeTimeSec(EWonderCategory WonderCategory, int32 TargetLevel) const
{
	if (TargetLevel >= WonderMaxLevel)
	{
		return 0;
	}

	const FCMSWonderRow* WonderRow = GetWonderRow(WonderCategory, TargetLevel);
	if (WonderRow)
	{
		return WonderRow->UpgradeTime * 60;
	}

	return 0;
}

const FCMSWonderRow* UCMS::GetWonderRow(EWonderCategory Category, int32 TargetLevel) const
{
	TArray<FCMSWonderRow*> RowArray;
	UCMSBase::GetWonder()->GetAllRows(TEXT("GetWonderRows"), RowArray);
	FCMSWonderRow** Found = RowArray.FindByPredicate([&Category, &TargetLevel](FCMSWonderRow* Row)
	{
		return ((Row->Category == Category) && (Row->TargetLevel == TargetLevel));
	});

	if (!ensure(Found))
	{
		return nullptr;
	}

	return *Found;
}

const FCMSWonderProductRow* UCMS::GetWonderProductRow(EWonderCategory Category, int32 TargetLevel) const
{
	TArray<FCMSWonderProductRow*> RowArray;
	UCMSBase::GetWonderProduct()->GetAllRows(TEXT("GetWonderProductRow"), RowArray);
	FCMSWonderProductRow** Found = RowArray.FindByPredicate([&Category, &TargetLevel](FCMSWonderProductRow* Row)
	{
		return ((Row->Category == Category) && (Row->Level == TargetLevel));
	});

	if (!Found)
	{
		return nullptr;
	}

	return *Found;

}

const FCMSWonderCostRow* UCMS::GetPortalBoostCost(EPortalType PortalType) const
{
	TArray<FCMSWonderCostRow*> RowArray;
	UCMSBase::GetWonderCost()->GetAllRows(TEXT("GetWonderCostRows"), RowArray);
	FCMSWonderCostRow** Found = RowArray.FindByPredicate([&PortalType](FCMSWonderCostRow* Row)
	{
		return ((Row->Category == EWonderCategory::Pyramid) && (Row->ContentType == (int32)PortalType));
	});

	if (!ensure(Found))
	{
		Q6JsonLogRoze(Error, "UCMS::GetBuildBoostCost - No have build boost cost", Q6KV("Slot", (int32)PortalType));
		return nullptr;
	}

	return *Found;
}

const FCMSSkillRow& UCMS::GetArtifactSkillRowOrDummy(int32 Index) const
{
	FSkillType SkillType = FSkillType(SystemConstHelper::GetArtifactSkillType(Index));

	return GetSkillRowOrDummy(SkillType);
}

int32 UCMS::GetArtifactIndex(int32 InSkillType) const
{
	for (int32 i = 0; i < SystemConst::Q6_MAX_TEMPLE_ARTIFACTS; ++i)
	{
		int32 SkillType = SystemConstHelper::GetArtifactSkillType(i);
		if (SkillType == InSkillType)
		{
			return i;
		}
	}

	return INDEX_NONE;
}

const FCMSSagaRow* UCMS::GetArtifactOpenConditionSagaRow(FSkillType SkillType) const
{
	const int32 ArtifactId = GetArtifactIndex(SkillType.x) + 1;

	const TArray<const FCMSSpecialRow*> SpecialRows = GetSpecialEpisodes(ESpecialCategory::Temple);
	for (const FCMSSpecialRow* SpecialRow : SpecialRows)
	{
		if (SpecialRow->ConditionId != ArtifactId)
		{
			continue;
		}

		TArray<const FCMSSagaRow*> SagaRows = GetCMS()->GetStageRows(EContentType::Special, SpecialRow->Episode);
		if (SagaRows.Num() <= 0)
		{
			continue;
		}

		return SagaRows[0];
	}

	Q6JsonLogRoze(Error, "UCMS::GetPetSkillOpenConditionSpecialSagaRow - No set artifact skill open special", Q6KV("SkillType", SkillType));
	return nullptr;
}

const FCMSSagaRow* UCMS::GetPetSkillOpenConditionSagaRow(FSkillType SkillType) const
{
	TArray<const FCMSPetRow*> RowArray;
	UCMSBase::GetPet()->GetAllRows(TEXT("GetPetSkillOpenConditionSpecialRow"), RowArray);

	for (const FCMSPetRow* PetRow : RowArray)
	{
		check(PetRow);

		int32 SkillIndex = PetRow->GetSkills().IndexOfByPredicate([SkillType](const FCMSSkillRow* SkillRow)
		{
			return SkillRow->CmsType() == SkillType;
		});

		const TArray<const FCMSSpecialRow*>& SpecialRows = PetRow->GetSkillSpecials();
		if (!SpecialRows.IsValidIndex(SkillIndex))
		{
			continue;
		}

		TArray<const FCMSSagaRow*> SagaRows = GetCMS()->GetStageRows(EContentType::Special, SpecialRows[SkillIndex]->Episode);
		if (SagaRows.Num() <= 0)
		{
			continue;
		}

		return SagaRows[0];
	}

	Q6JsonLogRoze(Error, "UCMS::GetPetSkillOpenConditionSpecialSagaRow - No set pet skill open special", Q6KV("PetSkillType", SkillType));
	return nullptr;
}

int32 UCMS::GetBondXpByRow(EBondCategory BondCatg, const FCMSBondXpRow& BondXpRow) const
{
	if (BondCatg == EBondCategory::XpExclusive)
	{
		Q6JsonLogGunny(Warning, "UCMS::GetBondXpByRow - BondCategory is exclusive.");
		return 0;
	}

	TArray<int32> BondXpArray;
	BondXpArray.Add((int32)EBondCategory::XpExclusive);
	BondXpArray.Add(BondXpRow.BondCategory1);
	BondXpArray.Add(BondXpRow.BondCategory2);
	BondXpArray.Add(BondXpRow.BondCategory3);
	BondXpArray.Add(BondXpRow.BondCategory4);
	BondXpArray.Add(BondXpRow.BondCategory5);
	BondXpArray.Add(BondXpRow.BondCategory6);
	BondXpArray.Add(BondXpRow.BondCategory7);
	BondXpArray.Add(BondXpRow.BondCategory8);
	BondXpArray.Add(BondXpRow.BondCategory9);
	BondXpArray.Add(BondXpRow.BondCategory10);
	BondXpArray.Add(BondXpRow.BondCategory11);
	BondXpArray.Add(BondXpRow.BondCategory12);
	BondXpArray.Add(BondXpRow.BondCategory13);
	BondXpArray.Add(BondXpRow.BondCategory14);
	BondXpArray.Add(BondXpRow.BondCategory15);
	BondXpArray.Add(BondXpRow.BondCategory16);

	if (BondXpArray.IsValidIndex((int32)BondCatg))
	{
		return BondXpArray[(int32)BondCatg];
	}

	Q6JsonLogRoze(Error, "UCMS::GetBondXp - Invalid bond category");
	return 0;
}

int32 UCMS::GetBondXpByLevel(EBondCategory BondCatg, int32 BondLevel) const
{
	const FCMSBondXpRow& BondXpRow = GetBondXpRowOrDummy(FBondXpType(BondLevel));
	return GetBondXpByRow(BondCatg, BondXpRow);
}

int32 UCMS::GetStartBondXpByLevel(EBondCategory BondCatg, int32 BondLevel) const
{
	int32 TotalXp = 0;

	for (int32 i = 1; i <= BondLevel; ++i)
	{
		const FCMSBondXpRow& BondXpRow = GetBondXpRowOrDummy(FBondXpType(i));
		TotalXp += GetBondXpByRow(BondCatg, BondXpRow);
	}

	return TotalXp;
}

int32 UCMS::GetMaxBondXp(EBondCategory BondCatg) const
{
	return GetBondXpByLevel(BondCatg, MaxBondLevel);
}

const FCMSBondRewardRow* UCMS::GetBondRewardRow(FCharacterType CharacterType, int32 BondLevel) const
{
	TArray<const FCMSBondRewardRow*> RowArray;
	UCMSBase::GetBondReward()->GetAllRows(TEXT("GetBondReward"), RowArray);

	for (const FCMSBondRewardRow* Row : RowArray)
	{
		if ((FCharacterType(Row->Character) == CharacterType) &&
			Row->BondLevel == BondLevel)
		{
			return Row;
		}
	}

	Q6JsonLogGunny(Warning, "UCMS::GetBondRewardRow - BondRewardRow does not exist.",
		Q6KV("CharacterType", CharacterType), Q6KV("BondLevel", BondLevel));

	return nullptr;
}

const FCMSWonderCostRow* UCMS::GetVacationCost(FVacationSpotType SpotType) const
{
	TArray<FCMSWonderCostRow*> RowArray;
	UCMSBase::GetWonderCost()->GetAllRows(TEXT("GetWonderCostRows"), RowArray);
	FCMSWonderCostRow** Found = RowArray.FindByPredicate([&SpotType](FCMSWonderCostRow* Row)
	{
		return ((Row->Category == EWonderCategory::Vacation) && (Row->ContentType == (int32)SpotType));
	});

	if (!ensure(Found))
	{
		Q6JsonLogRoze(Error, "UCMS::GetVacationCost - No have vacation start cost", Q6KV("Spot", (int32)SpotType));
		return nullptr;
	}

	return *Found;
}

int32 GetLastDay(TArray<const FCMSCheckInRewardRow*>& RewardRows)
{
	int32 LastCheckInDay = 0;
	for (const FCMSCheckInRewardRow* RewardRow : RewardRows)
	{
		check(RewardRow);

		if (RewardRow->RewardDay <= LastCheckInDay)
		{
			continue;
		}

		LastCheckInDay = RewardRow->RewardDay;
	}

	return LastCheckInDay;
}

int32 UCMS::GetLastCheckInDay(FCheckInBoardType BoardType) const
{
	const FCMSCheckInBoardRow& CheckInRow = GetCheckInBoardRowOrDummy(BoardType);
	if (CheckInRow.RotationRewardId > 0)
	{
		return 0;
	}

	TArray<const FCMSCheckInRewardRow*> RewardRows = GetCheckInRewards(CheckInRow.AnniversaryRewardId);
	return GetLastDay(RewardRows);
}

int32 UCMS::GetRotationCheckInDay(FCheckInBoardType BoardType) const
{
	const FCMSCheckInBoardRow& CheckInRow = GetCheckInBoardRowOrDummy(BoardType);

	TArray<const FCMSCheckInRewardRow*> RewardRows = GetCheckInRewards(CheckInRow.RotationRewardId);
	return GetLastDay(RewardRows);
}

TArray<const FCMSCheckInRewardRow*> UCMS::GetCheckInRewards(int32 RewardId) const
{
	TArray<FCMSCheckInRewardRow*> RowArray;
	UCMSBase::GetCheckInReward()->GetAllRows(TEXT("GetAttendanceRewards"), RowArray);

	TArray<const FCMSCheckInRewardRow*> FoundRows;
	for (const FCMSCheckInRewardRow* RewardRow : RowArray)
	{
		check(RewardRow);

		if (RewardRow->RewardId != RewardId)
		{
			continue;
		}

		FoundRows.AddUnique(RewardRow);
	}

	FoundRows.Sort([](const FCMSCheckInRewardRow& RowA, const FCMSCheckInRewardRow& RowB)
	{
		return RowA.RewardDay < RowB.RewardDay;
	});

	return FoundRows;
}

FRaidType UCMS::GetRaidTypeBySagaType(const FSagaType& SagaType) const
{
	const UDataTable* RaidTable = UCMSBase::GetRaid();
	if (!RaidTable)
	{
		return RaidTypeInvalid;
	}

	TArray<const FCMSRaidRow*> RaidRows;
	RaidTable->GetAllRows("GetRaidRows", RaidRows);

	for (const FCMSRaidRow* RaidRow : RaidRows)
	{
		if (!RaidRow)
		{
			continue;
		}

		if (RaidRow->GetSaga().CmsType() == SagaType)
		{
			return RaidRow->CmsType();
		}
	}

	return RaidTypeInvalid;
}

TArray<const FCMSRaidRow*> UCMS::GetRaidRows() const
{
	TArray<const FCMSRaidRow*> Out;
	UCMSBase::GetRaid()->GetAllRows(TEXT("GetRaidRows"), Out);

	return Out;
}

void UCMS::GetCodexCharacterRows(
	const TMap<FCharacterType, FCodexCharInfo>& CodexInfos,
	TArray<const FCMSCharacterRow*>& OutOwnedRows,
	TArray<const FCMSCharacterRow*>& OutNotOwnedRows) const
{
	const UDataTable* CharacterTable = UCMSBase::GetCharacter();
	if (!CharacterTable)
	{
		return;
	}

	TArray<const FCMSCharacterRow*> CharacterRows;
	CharacterTable->GetAllRows("GetCodexCharacterRows", CharacterRows);
	for (const FCMSCharacterRow* CharacterRow : CharacterRows)
	{
		if (!CharacterRow)
		{
			continue;
		}

		if (!CharacterRow->Codex)
		{
			continue;
		}

		if (CharacterRow->XpExclusive)
		{
			continue;
		}

		bool bOwned = CodexInfos.Contains(CharacterRow->CmsType());
		if (bOwned)
		{
			OutOwnedRows.Add(CharacterRow);
		}
		else
		{
			OutNotOwnedRows.Add(CharacterRow);
		}
	}
}

void UCMS::GetCodexSculptureRows(
	const TMap<FSculptureType, FCodexSculptureInfo>& CodexInfos,
	TArray<const FCMSSculptureRow*>& OutOwnedRows,
	TArray<const FCMSSculptureRow*>& OutNotOwnedRows) const
{
	const UDataTable* SculptureTable = UCMSBase::GetSculpture();
	if (!SculptureTable)
	{
		return;
	}

	TArray<const FCMSSculptureRow*> SculptureRows;
	SculptureTable->GetAllRows("GetCodexSculptureRows", SculptureRows);
	for (const FCMSSculptureRow* SculptureRow : SculptureRows)
	{
		if (!SculptureRow)
		{
			continue;
		}

		if (!SculptureRow->Codex)
		{
			continue;
		}

		if (SculptureRow->XpExclusive)
		{
			continue;
		}

		bool bOwned = CodexInfos.Contains(SculptureRow->CmsType());
		if (bOwned)
		{
			OutOwnedRows.Add(SculptureRow);
		}
		else
		{
			OutNotOwnedRows.Add(SculptureRow);
		}
	}
}

void UCMS::GetCodexRelicRows(
	const TMap<FRelicType, FCodexRelicInfo>& CodexInfos,
	TArray<const FCMSRelicRow*>& OutOwnedRows,
	TArray<const FCMSRelicRow*>& OutNotOwnedRows) const
{
	const UDataTable* RelicTable = UCMSBase::GetRelic();
	if (!RelicTable)
	{
		return;
	}

	TArray<const FCMSRelicRow*> RelicRows;
	RelicTable->GetAllRows("GetCodexRelicRows", RelicRows);
	for (const FCMSRelicRow* RelicRow : RelicRows)
	{
		if (!RelicRow)
		{
			continue;
		}

		if (!RelicRow->Codex)
		{
			continue;
		}

		if (RelicRow->XpExclusive)
		{
			continue;
		}

		bool bOwned = CodexInfos.Contains(RelicRow->CmsType());
		if (bOwned)
		{
			OutOwnedRows.Add(RelicRow);
		}
		else
		{
			OutNotOwnedRows.Add(RelicRow);
		}
	}
}

TArray<const FCMSAlchemyLabRow*> UCMS::GetAlchemyLabRows() const
{
	TArray<const FCMSAlchemyLabRow*> Out;
	UCMSBase::GetAlchemyLab()->GetAllRows(TEXT("GetAlchemyLabRows"), Out);

	return Out;
}

const FCMSSmelterRow* UCMS::GetSmelterRowByLevel(const int32 Level) const
{
	TArray<FCMSSmelterRow*> SmelterRows;
	UCMSBase::GetSmelter()->GetAllRows(TEXT("GetSmelterRows"), SmelterRows);

	for (const FCMSSmelterRow* SmelterRow : SmelterRows)
	{
		if (!SmelterRow)
		{
			continue;
		}

		if (SmelterRow->Level == Level)
		{
			return SmelterRow;
		}
	}

	Q6JsonLogGenie(Warning, "Cannot find SmelterRow", Q6KV("Level", Level));
	return nullptr;
}

TArray<const FCMSUserTitleRow*> UCMS::GetUserTitleRowsByCategory(const EUserTitleCategory Category) const
{
	TArray<const FCMSUserTitleRow*> Out;

	const UDataTable* UserTitleTable = UCMSBase::GetUserTitle();
	if (!UserTitleTable)
	{
		return Out;
	}

	TArray<const FCMSUserTitleRow*> UserTitleRows;
	UserTitleTable->GetAllRows("GetUserTitleRows", UserTitleRows);

	for (const FCMSUserTitleRow* UserTitleRow : UserTitleRows)
	{
		if (!UserTitleRow)
		{
			continue;
		}

		if (UserTitleRow->Category == Category)
		{
			Out.Add(UserTitleRow);
		}
	}

	return Out;
}

TArray<const FCMSUserTitleRow*> UCMS::GetUserTitleRowByMissionCategory(const EUserTitleMissionCategory MissionCategory) const
{
	TArray<const FCMSUserTitleRow*> Out;

	const UDataTable* UserTitleTable = UCMSBase::GetUserTitle();
	if (!UserTitleTable)
	{
		return Out;
	}

	TArray<const FCMSUserTitleRow*> UserTitleRows;
	UserTitleTable->GetAllRows("GetUserTitleRows", UserTitleRows);

	for (const FCMSUserTitleRow* UserTitleRow : UserTitleRows)
	{
		if (!UserTitleRow)
		{
			continue;
		}

		if (UserTitleRow->MissionCategory == MissionCategory)
		{
			Out.Add(UserTitleRow);
		}
	}

	return Out;
}

const FCMSContentFeatureOpenRow* UCMS::GetContentFeatureOpenRowBySubPartySlotIndex(const int32 Index) const
{
	check(SUB_PARTY_CHARACTER_FIRST_SLOT <= Index);
	check(Index <= SUB_PARTY_CHARACTER_THIRD_SLOT);

	EFeatureOpenType FeatureOpenType(EFeatureOpenType::PartySubFirstSlot);
	switch (Index)
	{
		case SUB_PARTY_CHARACTER_FIRST_SLOT:
			FeatureOpenType = EFeatureOpenType::PartySubFirstSlot;
			break;
		case SUB_PARTY_CHARACTER_SECOND_SLOT:
			FeatureOpenType = EFeatureOpenType::PartySubSecondSlot;
			break;
		case SUB_PARTY_CHARACTER_THIRD_SLOT:
			FeatureOpenType = EFeatureOpenType::PartySubThirdSlot;
			break;
	}

	return GetContentFeatureOpenRowByOpenType(FeatureOpenType);
}

const FCMSContentFeatureOpenRow* UCMS::GetContentFeatureOpenRowByOpenType(const EFeatureOpenType OpenType) const
{
	const UDataTable* ContentFeatureOpenTable = UCMSBase::GetContentFeatureOpen();
	if (!ContentFeatureOpenTable)
	{
		return nullptr;
	}

	TArray<const FCMSContentFeatureOpenRow*> ContentFeatureOpenRows;
	ContentFeatureOpenTable->GetAllRows("GetContentFeatureOpenRows", ContentFeatureOpenRows);
	for (const FCMSContentFeatureOpenRow* ContentFeatureOpenRow : ContentFeatureOpenRows)
	{
		if (!ContentFeatureOpenRow)
		{
			continue;
		}

		if (ContentFeatureOpenRow->OpenType != OpenType)
		{
			continue;
		}

		return ContentFeatureOpenRow;
	}

	return nullptr;
}

const FCMSContentFeatureOpenRow* UCMS::GetContentFeatureOpenRowByOpenValue(const int32 OpenValue) const
{
	const UDataTable* ContentFeatureOpenTable = UCMSBase::GetContentFeatureOpen();
	if (!ContentFeatureOpenTable)
	{
		return nullptr;
	}

	TArray<const FCMSContentFeatureOpenRow*> ContentFeatureOpenRows;
	ContentFeatureOpenTable->GetAllRows("GetContentFeatureOpenRows", ContentFeatureOpenRows);
	for (const FCMSContentFeatureOpenRow* ContentFeatureOpenRow : ContentFeatureOpenRows)
	{
		if (!ContentFeatureOpenRow)
		{
			continue;
		}

		if (ContentFeatureOpenRow->OpenValue != OpenValue)
		{
			continue;
		}

		return ContentFeatureOpenRow;
	}

	return nullptr;
}

const FCMSMissionSetRow* UCMS::GetMissionSetRowByWeekNum(const int32 InWeekNum) const
{
	const UDataTable* MissionSetTable = UCMSBase::GetMissionSet();
	if (!MissionSetTable)
	{
		return nullptr;
	}

	TArray<const FCMSMissionSetRow*> MissionSetRows;
	MissionSetTable->GetAllRows("GetMissionSetRows", MissionSetRows);
	for (const FCMSMissionSetRow* MissionSetRow : MissionSetRows)
	{
		if (!MissionSetRow)
		{
			continue;
		}

		if (MissionSetRow->WeekNum == InWeekNum)
		{
			return MissionSetRow;
		}
	}

	return MissionSetRows[0];
}

const FCMSCharMissionSetRow* UCMS::GetCharMissionSetRowByCharType(const FCharacterType& Type) const
{
	const UDataTable* CharMissionSetTable = UCMSBase::GetCharMissionSet();
	if (!CharMissionSetTable)
	{
		return nullptr;
	}

	TArray<const FCMSCharMissionSetRow*> CharMissionSetRows;
	CharMissionSetTable->GetAllRows("GetCharMissionSetRows", CharMissionSetRows);

	for (const FCMSCharMissionSetRow* CharMissionSetRow : CharMissionSetRows)
	{
		if (!CharMissionSetRow)
		{
			continue;
		}

		if (CharMissionSetRow->GetChar().CmsType() != Type)
		{
			continue;
		}

		return CharMissionSetRow;
	}

	return nullptr;
}

const FCMSCharUnlockElemSetRow* UCMS::GetCharUnlockElemSetRowByCharType(const FCharacterType& Type) const
{
	const UDataTable* CharUnlockElemSetTable = UCMSBase::GetCharUnlockElemSet();
	if (!CharUnlockElemSetTable)
	{
		return nullptr;
	}

	TArray<const FCMSCharUnlockElemSetRow*> CharUnlockElemSetRows;
	CharUnlockElemSetTable->GetAllRows("GetCharUnlockElemSetRows", CharUnlockElemSetRows);

	for (const FCMSCharUnlockElemSetRow* CharUnlockElemSetRow : CharUnlockElemSetRows)
	{
		if (!CharUnlockElemSetRow)
		{
			continue;
		}

		if (CharUnlockElemSetRow->GetChar().CmsType() != Type)
		{
			continue;
		}

		return CharUnlockElemSetRow;
	}

	return nullptr;
}

void UCMS::GetUserRecordRows(TMap<FUserRecordType, const FCMSUserRecordRow*>& Out) const
{
	const UDataTable* UserRecordTable = UCMSBase::GetUserRecord();
	if (!UserRecordTable)
	{
		return;
	}

	TArray<const FCMSUserRecordRow*> UserRecordRows;
	UserRecordTable->GetAllRows("GetUserRecordRows", UserRecordRows);
	for (const FCMSUserRecordRow* UserRecordRow : UserRecordRows)
	{
		if (!UserRecordRow)
		{
			continue;
		}
		else if (!UserRecordRow->IsDisplay)
		{
			continue;
		}

		Out.Emplace(UserRecordRow->Type, UserRecordRow);
	}
}

TArray<const FCMSShopRow*> UCMS::GetShopRowsByShopCategory(EShopCategory InCategory) const
{
	TArray<FCMSShopRow*> RowArray;
	UCMSBase::GetShop()->GetAllRows(TEXT("GetShopRows"), RowArray);


	TArray<const FCMSShopRow*> ShopRows;
	for (const FCMSShopRow* Iter : RowArray)
	{
		if (Iter->ShopCategory == InCategory)
		{
			ShopRows.AddUnique(Iter);
		}
	}

	return ShopRows;
}

TArray<const FCMSWeedGrowRow*> UCMS::GetWeedGrowRowsByCategory(EWeedGrowCategory Category) const
{
	TArray<FCMSWeedGrowRow*> RowArray;
	UCMSBase::GetWeedGrow()->GetAllRows(TEXT("GetWeedGrows"), RowArray);

	TArray<const FCMSWeedGrowRow*> WeedRows;
	for (const FCMSWeedGrowRow* Iter : RowArray)
	{
		if (Iter->Category == Category)
		{
			WeedRows.Add(Iter);
		}
	}

	return WeedRows;
}

const FCMSWeedGrowRow* UCMS::GetTurnSkillOpenWeedGrowRow(int32 TurnSkillIndex) const
{
	TArray<const FCMSWeedGrowRow*> RowArray = GetWeedGrowRowsByCategory(EWeedGrowCategory::TurnSkillOpen);
	for (const FCMSWeedGrowRow* Row : RowArray)
	{
		if (Row->TurnSkillIndex == TurnSkillIndex)
		{
			return Row;
		}
	}

	Q6JsonLogRoze(Error, "UCMS::GetTurnSkillOpenWeedGrowRow - Not found turn skill open weed grow row", Q6KV("TurnSkillIndex", TurnSkillIndex));
	return nullptr;
}

const FCMSWeedGrowRow* UCMS::GetPreWeedGrowRow(FWeedGrowType Type) const
{
	const FCMSWeedGrowRow& WeedGrow = UCMSBase::GetWeedGrowRowOrDummy(Type);
	if (WeedGrow.IsInvalid())
	{
		Q6JsonLogZagal(Warning, "Invalid WeedGrowType", Q6KV("Type", Type));
		return nullptr;
	}

	TArray<const FCMSWeedGrowRow*> WeedRows = GetWeedGrowRowsByCategory(WeedGrow.Category);

	for (int32 i = 1; i < WeedRows.Num(); i++)
	{
		const FCMSWeedGrowRow* Row = WeedRows[i];
		if (Row->CmsType() == Type)
		{
			return WeedRows[i - 1];
		}
	}

	return nullptr;
}

ENatureType UCMS::GetChangeNatureTypeFromBuff(FBuffType InBuffType) const
{
	const FCMSBuffRow& BuffRow = GetBuffRowOrDummy(InBuffType);
	if (BuffRow.IsInvalid())
	{
		Q6JsonLogGunny(Warning, "UCMS::GetChangeNatureTypeFromBuff - BuffRow does not exist.", Q6KV("BuffType", InBuffType));
		return ENatureType::None;
	}

	const TArray<const FCMSBuffEffectRow*> BuffEffects = BuffRow.GetBuffEffect();

	for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffects)
	{
		if (BuffEffectRow->BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
		{
			const FCMSCrowdControlRow& Row = GetCMS()->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
			if (Row.CrowdControl == ECrowdControl::ChangeNature)
			{
				// Param2 is added 1
				return ENatureType(FMath::Clamp(BuffEffectRow->Param2 - 1, 0, static_cast<int>(ENatureType::None)));
			}

		}
	}

	return ENatureType::None;
}

bool UCMS::HasShieldStateFromBuff(int32 InBuffType) const
{
	const TArray<const FCMSBuffEffectRow*> BuffEffectRows = GetBuffEffects(InBuffType, EBuffEffectCategory::ModifyCrowdControl);
	for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
	{
		const FCMSCrowdControlRow& CCRow = GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1));
		if (CCRow.CrowdControl == ECrowdControl::Shield)
		{
			return true;
		}
	}

	return false;
}

const FCMSCurrencyPointRow* UCMS::GetCurrencyPointRow(EPointType PointType) const
{
	TArray<FCMSCurrencyPointRow*> RowArray;
	UCMSBase::GetCurrencyPoint()->GetAllRows(TEXT("GetCurrencyPointRow"), RowArray);

	for (const FCMSCurrencyPointRow* Row : RowArray)
	{
		if (Row->EventId != 0)
		{
			continue;
		}

		if (Row->Value != (int32)PointType)
		{
			continue;
		}

		return Row;
	}

	Q6JsonLogRoze(Error, "UCMS::GetCurrencyPointRow - Invalid point type", Q6KV("PointType", (int32)PointType));
	return nullptr;
}

const FCMSCurrencyPointRow* UCMS::GetEventCurrencyPointRow(FEventContentType InEventContentType, int32 InPointIndex) const
{
	TArray<FCMSCurrencyPointRow*> RowArray;
	UCMSBase::GetCurrencyPoint()->GetAllRows(TEXT("GetCurrencyPointRow"), RowArray);

	for (const FCMSCurrencyPointRow* Row : RowArray)
	{
		if (Row->EventId == 0)
		{
			continue;
		}

		if (Row->EventId != InEventContentType.x)
		{
			continue;
		}

		if (Row->Value != InPointIndex)
		{
			continue;
		}

		return Row;
	}

	Q6JsonLogGunny(Error, "UCMS::GetEventCurrencyPointRow - Invalid point index", Q6KV("InPointIndex", (int32)InPointIndex));
	return nullptr;
}

TArray<const FCMSShopRow*> UCMS::GetEventShop(FEventContentType InEventContentType) const
{
	TArray<FCMSShopRow*> RowArray;
	UCMSBase::GetShop()->GetAllRows(TEXT("GetShop"), RowArray);

	TArray<const FCMSShopRow*> EventShop;
	for (const FCMSShopRow* Iter : RowArray)
	{
		if (Iter->ShopCategory != EShopCategory::EventContent)
		{
			continue;
		}

		if (Iter->EventContentId == InEventContentType.x)
		{
			EventShop.Add(Iter);
		}
	}

	return EventShop;
}

FEventContentType UCMS::GetEventContentType(FSagaType InSagaType) const
{
	TArray<FCMSEventContentValentineDayRow*> ValentineDayRowArray;
	UCMSBase::GetEventContentValentineDay()->GetAllRows(TEXT("GetEventContentValentineDay"), ValentineDayRowArray);

	for (const FCMSEventContentValentineDayRow* Iter : ValentineDayRowArray)
	{
		if (Iter->GetSaga().CmsType() == InSagaType)
		{
			return Iter->GetEventContent().CmsType();
		}
	}

	TArray<FCMSEventContentMultiSideBattleStageRow*> MultisideRowArray;
	UCMSBase::GetEventContentMultiSideBattleStage()->GetAllRows(TEXT("GetEventContentMultiSideBattleStage"), MultisideRowArray);

	for (const FCMSEventContentMultiSideBattleStageRow* Iter : MultisideRowArray)
	{
		if (Iter->GetSaga().CmsType() == InSagaType)
		{
			return Iter->GetEventContent().CmsType();
		}
	}

	Q6JsonLogGunny(Warning, "UCMS::GetContentType - EventContentType does not exist.", Q6KV("SagaType", InSagaType));
	return EventContentTypeInvalid;
}

const int32 UCMS::GetEventContentRouletteLineUpTotalItemCount(const FEventContentRouletteLineUpInfo& InEventContentRouletteLineUpInfo) const
{
	int32 TotalItemCount = 0;
	TArray<FCMSEventContentRouletteRow*> OutEventContentRouletteRowArray;
	UCMSBase::GetEventContentRoulette()->GetAllRows(TEXT("GetEventContentRouletteRow"), OutEventContentRouletteRowArray);
	for (const FCMSEventContentRouletteRow* InRow : OutEventContentRouletteRowArray)
	{
		if (InRow->GetEventContent().CmsType() == InEventContentRouletteLineUpInfo.EventContentType && InRow->LineUp == InEventContentRouletteLineUpInfo.LineUp)
		{
			TotalItemCount += InRow->LimitCount;
		}
	}

	return TotalItemCount;
}

FEventContentValentineDayType UCMS::GetEventContentValentineDayType(FSagaType InSagaType) const
{
	TArray<FCMSEventContentValentineDayRow*> RowArray;
	UCMSBase::GetEventContentValentineDay()->GetAllRows(TEXT("GetEventContentValentineDayType"), RowArray);

	for (auto& Row : RowArray)
	{
		const FCMSSagaRow& SagaRow = Row->GetSaga();

		if (SagaRow.CmsType() == InSagaType)
		{
			return Row->CmsType();
		}
	}

	Q6JsonLogGunny(Warning, "UCMS::GetEventContentValentineDayType - Cannot find FEventContentValentineDayType.", Q6KV("SagaType", InSagaType));
	return EventContentValentineDayTypeInvalid;
}

FEventContentMapType UCMS::GetEventContentMapType(FSagaType InSagaType) const
{
	TArray<FCMSEventContentMapRow*> RowArray;
	UCMSBase::GetEventContentMap()->GetAllRows(TEXT("GetEventContentMapType"), RowArray);

	for (auto& Row : RowArray)
	{
		const FCMSSagaRow& SagaRow = Row->GetSaga();

		if (SagaRow.CmsType() == InSagaType)
		{
			return Row->CmsType();
		}
	}

	Q6JsonLogGunny(Warning, "UCMS::GetEventContentMapType - Cannot find FEventContentMapType.", Q6KV("SagaType", InSagaType));
	return EventContentMapTypeInvalid;
}

TArray<const FCMSEventContentAccumPointRewardRow*> UCMS::GetEventContentAccumPointRewards(FEventContentType InEventContentType) const
{
	TArray<FCMSEventContentAccumPointRewardRow*> RowArray;
	UCMSBase::GetEventContentAccumPointReward()->GetAllRows(TEXT("GetEventContentAccumPointReward"), RowArray);

	TArray<const FCMSEventContentAccumPointRewardRow*> EventContentAccumPointRewards;
	for (const FCMSEventContentAccumPointRewardRow* Iter : RowArray)
	{
		if (Iter->GetEventContent().CmsType() == InEventContentType)
		{
			EventContentAccumPointRewards.Add(Iter);
		}
	}

	return EventContentAccumPointRewards;
}

const int32 UCMS::GetMultiSideBattleRankEventConst(int32 InDifficulty) const
{
	TArray<FCMSMultiSideBattleRankDifficultyRow*> Rows;
	FMultiSideBattleRankDifficultyTable->GetAllRows("Value", Rows);

	for (const FCMSMultiSideBattleRankDifficultyRow* R : Rows)
	{
		if (R->Difficulty == InDifficulty)
		{
			return R->Value;
		}
	}

	for (const FCMSMultiSideBattleRankDifficultyRow* R : Rows)
	{
		if (R->Difficulty == CombatCubeConst::Q6_DEFAULT_DIFFICULTY)
		{
			Q6JsonLogPawn(Warning, "use default difficulty MultiSideBattleRankEventConst.");
			return R->Value;
		}
	}

	Q6JsonLogPawn(Error, "can not find MultiSideBattleRankEventConst.", Q6KV("Difficulty", InDifficulty));
	return 0;
}

const int32 UCMS::GetMultiSideBattleRankBonusConst(EMultiSideRankBonusCategory InCategory) const
{
	const FCMSMultiSideBattleRankBonusRow* Row = GetMultiSideBattleRankBonusRow(InCategory);
	if (Row)
	{
		return Row->Value;
	}

	return 0;
}

const FText UCMS::GetMultiSideBattleRankBonusDesc(EMultiSideRankBonusCategory InCategory) const
{
	const FCMSMultiSideBattleRankBonusRow* Row = GetMultiSideBattleRankBonusRow(InCategory);
	if (Row)
	{
		return Row->Desc;
	}

	return FText::GetEmpty();
}

const FCMSMultiSideBattleRankBonusRow* UCMS::GetMultiSideBattleRankBonusRow(EMultiSideRankBonusCategory InCategory) const
{
	TArray<FCMSMultiSideBattleRankBonusRow*> Rows;
	FMultiSideBattleRankBonusTable->GetAllRows("Value", Rows);

	for (const FCMSMultiSideBattleRankBonusRow* Row : Rows)
	{
		if (Row->Category == InCategory)
		{
			return Row;
		}
	}

	Q6JsonLogPawn(Error, "can not find MultiSideBattleRankBonusConst.", Q6KV("Category", (int32)InCategory));
	return nullptr;
}

TArray<const FCMSEventContentMultiSideBattleRewardRow*> UCMS::GetMultisideBattleRewards(FEventContentType InContentType) const
{
	TArray<FCMSEventContentMultiSideBattleRewardRow*> RowArray;
	UCMSBase::GetEventContentMultiSideBattleReward()->GetAllRows(TEXT("GetEventContentMultiSideBattleReward"), RowArray);

	TArray<const FCMSEventContentMultiSideBattleRewardRow*> BattleRewards;
	for (const FCMSEventContentMultiSideBattleRewardRow* Iter : RowArray)
	{
		if (Iter->GetEventContent().CmsType() == InContentType)
		{
			BattleRewards.Add(Iter);
		}
	}

	return BattleRewards;
}

FEventContentMultiSideBattleStageType UCMS::GetEventContentMultiSideBattleStageType(FSagaType InSagaType) const
{
	TArray<FCMSEventContentMultiSideBattleStageRow*> RowArray;
	UCMSBase::GetEventContentMultiSideBattleStage()->GetAllRows(TEXT("GetEventContentMultiSideBattleStageType"), RowArray);

	for (auto& Row : RowArray)
	{
		const FCMSSagaRow& SagaRow = Row->GetSaga();

		if (SagaRow.CmsType() == InSagaType)
		{
			Q6JsonLogGunny(Warning, "UCMS::GetEventContentMultiSideBattleStageType - found.", Q6KV("SagaType", InSagaType), Q6KV("StageType", Row->CmsType()));
			return Row->CmsType();
		}
	}

	Q6JsonLogGunny(Warning, "UCMS::GetEventContentMultiSideBattleStageType - Cannot find FEventContentMultiSideBattleStageType.", Q6KV("SagaType", InSagaType));
	return EventContentMultiSideBattleStageTypeInvalid;
}

const FCMSEventContentMultiSideBattleRow* UCMS::GetEventContentMultiSideBattleRow(FEventContentType InContentType) const
{
	TArray<const FCMSEventContentMultiSideBattleRow*> Rows;
	UCMSBase::GetEventContentMultiSideBattle()->GetAllRows("GetEventContentMultiSideBattle", Rows);

	for (const FCMSEventContentMultiSideBattleRow* Row : Rows)
	{
		if (Row->GetEventContent().CmsType() == InContentType)
		{
			return Row;
		}
	}

	Q6JsonLogPawn(Error, "can not find MultiSideBattleRow.", Q6KV("ContentType", (int32)InContentType));
	return nullptr;
}

TArray<const FCMSEventContentMultiSideBattleStageRow*> UCMS::GetEventContentMultisideBattleStageRows(FEventContentType InContentType) const
{
	TArray<const FCMSEventContentMultiSideBattleStageRow*> Rows;
	UCMSBase::GetEventContentMultiSideBattleStage()->GetAllRows(TEXT("EventContentMultiSideBattleStageRow"), Rows);

	TArray<const FCMSEventContentMultiSideBattleStageRow*> RetValue;

	for (const FCMSEventContentMultiSideBattleStageRow* Row : Rows)
	{
		if (Row->GetEventContent().CmsType() == InContentType)
		{
			RetValue.Add(Row);
		}
	}

	return RetValue;
}

void UCMS::SetBonusMonsterInfo(const FCMSSagaRow& InSagaRow, const FBonusMonster& InBonusMonster)
{
	ResetBonusMonsterWaveRows();

	bHasBonusMonster = InBonusMonster.UnitType != 0 && InBonusMonster.SpawnCount != 0;

	if (bHasBonusMonster)
	{
		int32 BonusMonsterWaveCount = InBonusMonster.SpawnCount / CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT;
		if (InBonusMonster.SpawnCount % CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT != 0)
		{
			BonusMonsterWaveCount++;
		}
		const TArray<const FCMSBonusMonsterRow*>& BonusMonsterRow = InSagaRow.GetBonusMonster();
		if (!BonusMonsterRow[0] || BonusMonsterRow[0]->IsInvalid())
		{
			return;
		}

		// find bonus monster wave index
		const TArray<const FCMSWaveRow*>& Waves = InSagaRow.GetWave();
		const int32 AfterWaveId = BonusMonsterRow[0]->AfterWaveId;
		const int32 SpawnLevel = BonusMonsterRow[0]->SpawnLevel;
		int32 BonusWaveIndex = 0;
		for (const FCMSWaveRow* Wave : Waves)
		{
			if (Wave->Type == AfterWaveId)
			{
				break;
			}

			BonusWaveIndex++;
		}

		StartBonusWaveIndex = BonusWaveIndex + 1;
		LastBonusWaveIndex = BonusWaveIndex + BonusMonsterWaveCount;

		SetBonusMonsterWaveRow(BonusMonsterWaveRow, InBonusMonster, SpawnLevel, false);
		SetBonusMonsterWaveRow(LastBonusMonsterWaveRow, InBonusMonster, SpawnLevel, true);
	}
}

void UCMS::SetBonusMonsterWaveRow(FCMSWaveRow& OutBonusWaveRow, const FBonusMonster& InBonusMonster, int32 InSpawnLevel, bool bInIsLastBonusMonsterRow)
{
	int32 RemainBonusMonsterNum = CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT;
	if (bInIsLastBonusMonsterRow)
	{
		RemainBonusMonsterNum = InBonusMonster.SpawnCount % CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT;
		if (RemainBonusMonsterNum == 0)
		{
			RemainBonusMonsterNum = CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT;
		}
	}

	// 1 : X O X
	// 2 : O O X
	// 3 : O O O

	if (RemainBonusMonsterNum == 1)
	{
		OutBonusWaveRow.Spawns01.Add(UnitTypeInvalid);
		OutBonusWaveRow.Spawns01Ratio.Add(0);
		OutBonusWaveRow.Spawn01Level = 0;
	}
	else
	{
		OutBonusWaveRow.Spawns01.Add(InBonusMonster.UnitType);
		OutBonusWaveRow.Spawns01Ratio.Add(1000);
		OutBonusWaveRow.Spawn01Level = InSpawnLevel;
	}

	OutBonusWaveRow.Spawns02.Add(InBonusMonster.UnitType);
	OutBonusWaveRow.Spawns02Ratio.Add(1000);
	OutBonusWaveRow.Spawn02Level = InSpawnLevel;

	if (RemainBonusMonsterNum != CombatCubeConst::Q6_MAX_SPAWNED_ENEMY_UNIT)
	{
		OutBonusWaveRow.Spawns03.Add(UnitTypeInvalid);
		OutBonusWaveRow.Spawns03Ratio.Add(0);
		OutBonusWaveRow.Spawn03Level = 0;
	}
	else
	{
		OutBonusWaveRow.Spawns03.Add(InBonusMonster.UnitType);
		OutBonusWaveRow.Spawns03Ratio.Add(1000);
		OutBonusWaveRow.Spawn03Level = InSpawnLevel;
	}

	OutBonusWaveRow.Type = WaveTypeInvalid.x;	// there is no wave type
	OutBonusWaveRow.AppearanceRatio = 1;		// bonus wave
}

void UCMS::ResetBonusMonsterWaveRows()
{
	BonusMonsterWaveRow.Spawns01.Empty();
	BonusMonsterWaveRow.Spawns01Ratio.Empty();
	BonusMonsterWaveRow.Spawn01Level = 0;

	BonusMonsterWaveRow.Spawns02.Empty();
	BonusMonsterWaveRow.Spawns02Ratio.Empty();
	BonusMonsterWaveRow.Spawn02Level = 0;

	BonusMonsterWaveRow.Spawns03.Empty();
	BonusMonsterWaveRow.Spawns03Ratio.Empty();
	BonusMonsterWaveRow.Spawn03Level = 0;

	BonusMonsterWaveRow.Type = WaveTypeInvalid.x;
	BonusMonsterWaveRow.AppearanceRatio = 0;

	LastBonusMonsterWaveRow = BonusMonsterWaveRow;

	StartBonusWaveIndex = 0;
	LastBonusWaveIndex = 0;
}
