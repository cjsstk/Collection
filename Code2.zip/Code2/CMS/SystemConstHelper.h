#include "SystemConst_gen.h"
#include "CMSType_gen.h"

enum class EItemGrade : uint8;
enum class EPortalType : uint8;
enum class ECurrencyType : uint8;
enum class EUpgradeCharacterCategory : uint8;

struct FCharacterInfo;

namespace SystemConstHelper
{
	// CharacterFormulaConst
	int32 GetGold4TurnSkillUpgrade(EItemGrade Grade, int32 Level);
	int32 GetCharacterAddXpCost(EItemGrade MaterialGrade, int32 Level);
	int32 GetCharacterEvoluteCost(int32 Moon, EItemGrade ItemGrade);
	int32 GetUltimateCostCharacterFormulaConst(int32 SkillLevel);
	int32 GetCharacterUltimateUpCost(int32 CurLevel, int32 TargetLevel);
	int32 GetCharacterBaseXP(bool bExclusive);
	int32 GetCharacterMultiplierGradeXP(EItemGrade MaterialGrade, bool bExclusive);
	int32 GetCharacterMaxUnbindStar(EItemGrade ItemGrade);
	int32 GetCharacterMaxPromoteStar(EUpgradeCharacterCategory UpCategory, EItemGrade ItemGrade);
	int32 GetStartEvolutionStep(EItemGrade ItemGrade);
	int32 GetUpgradeTargetMoon(EItemGrade ItemGrade, int32 Moon);
	int32 GetCharacterMaxLevelByStar(int32 Star);
	int32 GetCharacterMaxLevelByMoon(int32 Moon);
	int32 GetCharacterMaxLevel(int32 Star, int32 Moon);
	int32 GetCharacterMaxLevel(int32 Star, int32 Moon);
	int32 GetCharacterStarByMoon(EItemGrade ItemGrade, int32 Moon);
	int32 GetCharacterTurnSkillCount(int32 Star);
	int32 GetTurnSkillUpgradeCharacterLevel(int32 TargetSkillLevel);
	bool CanTurnSkillUpgradeLevel(int32 TargetSkillLevel, int32 CharacterLevel);
	bool IsGainedTurnSkill(int32 Star);

	// EquipFormulaConst
	int32 GetEquipAddXpCost(EItemGrade MaterialGrade, int32 Level);
	int32 GetEquipBaseXP();
	int32 GetEquipExclusiveBaseXP();
	int32 GetEquipMultiplierGradeXP(EItemGrade MaterialGrade);
	int32 GetEquipMultiplierExclusiveGradeXP(EItemGrade MaterialGrade);
	int32 GetEquipMaxLevel(int32 Star);
	int32 GetEquipTierUpCost(int32 CurTier, int32 TargetTier);

	// Pyramid
	int32 GetMaxBoostCount(EPortalType PortalType);
	int32 GetDailyBoostCount(EPortalType PortalType);
	int32 GetPortalBoostMaterialReduceCount(int32 Level);
	int32 GetPortalBoostGoldReduceCost(int32 Level);
	int32 GetPortalBuildingDays(EPortalType PortalType);
	int32 GetPortalConnectingDays(EPortalType PortalType);

	// Temple
	int32 GetArtifactSkillType(int32 Index);
	int32 GetArtifactSkillCooltime(int32 Index);

	// Vacation
	int32 GetVacationLevelBonusBond(int32 Level);

	// Currency
	int32 GetMaxCurrencyAmount(ECurrencyType CurrencyType);

	bool IsWeed(const FCharacterInfo& Info);
	bool IsWeed(FCharacterType CharacterType);

	// Sell Shop
	// Character
	int32 GetSellCharacterGoldByGrade(EItemGrade ItemGrade);
	int32 GetSellCharacterLumicubeByGrade(EItemGrade ItemGrade);
	int32 GetSellCharacterExpGoldByGrade(EItemGrade ItemGrade);
	int32 GetSellCharacterExpLumicubeByGrade(EItemGrade ItemGrade);
	// Sculpture
	int32 GetSellSculptureGoldByGrade(EItemGrade ItemGrade);
	int32 GetSellSculptureLumicubeByGrade(EItemGrade ItemGrade);
	int32 GetSellSculptureExpGoldByGrade(EItemGrade ItemGrade);
	int32 GetSellSculptureExpLumicubeByGrade(EItemGrade ItemGrade);

	// Relic
	int32 GetSellRelicGoldByGrade(EItemGrade ItemGrade);
	int32 GetSellRelicLumicubeByGrade(EItemGrade ItemGrade);
	int32 GetSellRelicExpGoldByGrade(EItemGrade ItemGrade);
	int32 GetSellRelicExpLumicubeByGrade(EItemGrade ItemGrade);

	bool IsBoneDragonSagaType(FSagaType SagaType);
}
