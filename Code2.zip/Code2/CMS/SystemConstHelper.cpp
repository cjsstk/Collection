#include "SystemConstHelper.h"

#include "CMS_gen.h"
#include "LobbyObj_gen.h"
#include "Q6Log.h"
#include "Q6Minimal.h"
#include "Q6Define.h"
#include "Q6UIDefine.h"

namespace SystemConstHelper
{

	int32 GetGold4TurnSkillUpgrade(EItemGrade Grade, int32 SkillLevel)
	{
		switch (SkillLevel) {
		case 2:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N2
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R2
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR2
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR2
				: 0;
		case 3:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N3
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R3
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR3
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR3
				: 0;
		case 4:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N4
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R4
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR4
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR4
				: 0;
		case 5:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N5
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R5
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR5
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR5
				: 0;
		case 6:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N6
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R6
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR6
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR6
				: 0;
		case 7:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N7
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R7
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR7
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR7
				: 0;
		case 8:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N8
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R8
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR8
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR8
				: 0;
		case 9:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N9
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R9
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR9
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR9
				: 0;
		case 10:
			return Grade == EItemGrade::N ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_N10
				: Grade == EItemGrade::R ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_R10
				: Grade == EItemGrade::SR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SR10
				: Grade == EItemGrade::SSR ? CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE_GOLD_SSR10
				: 0;
		default:
			return 0;
		}
	}

	int32 GetCharacterAddXpCost(EItemGrade MaterialGrade, int32 Level)
	{
		switch (MaterialGrade)
		{
			case EItemGrade::N:
				return (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_N1 + (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_N2 * Level));
			case EItemGrade::R:
				return (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_R1 + (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_R2 * Level));
			case EItemGrade::SR:
				return (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SR1 + (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SR2 * Level));
			case EItemGrade::SSR:
				return (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SSR1 + (CharacterFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SSR2 * Level));
			default:
				return CharacterFormulaConst::Q6_NONE;
		}
	}


	int32 GetCharacterEvoluteCost(int32 Moon, EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				switch (Moon)
				{
					case 1:
						return CharacterFormulaConst::Q6_COST_EVOLUTION1_GRADE_N;
					case 2:
						return CharacterFormulaConst::Q6_COST_EVOLUTION2_GRADE_N;
					case 3:
						return CharacterFormulaConst::Q6_COST_EVOLUTION3_GRADE_N;
					case 4:
						return CharacterFormulaConst::Q6_COST_EVOLUTION4_GRADE_N;
					case 5:
						return CharacterFormulaConst::Q6_COST_EVOLUTION5_GRADE_N;
					case 6:
						return CharacterFormulaConst::Q6_COST_EVOLUTION6_GRADE_N;
					case 7:
						return CharacterFormulaConst::Q6_COST_EVOLUTION7_GRADE_N;
					case 8:
						return CharacterFormulaConst::Q6_COST_EVOLUTION8_GRADE_N;
					case 9:
						return CharacterFormulaConst::Q6_COST_EVOLUTION9_GRADE_N;
					case 10:
						return CharacterFormulaConst::Q6_COST_EVOLUTION10_GRADE_N;
					case 11:
						return CharacterFormulaConst::Q6_COST_EVOLUTION11_GRADE_N;
					default:
						Q6JsonLogGunny(Warning, "UCMS::GetCharacterEvoluteCost - Invalid Moon.", Q6KV("Moon", Moon));
						return 0;
				}
			case EItemGrade::R:
				switch (Moon)
				{
					case 3:
						return CharacterFormulaConst::Q6_COST_EVOLUTION3_GRADE_R;
					case 4:
						return CharacterFormulaConst::Q6_COST_EVOLUTION4_GRADE_R;
					case 5:
						return CharacterFormulaConst::Q6_COST_EVOLUTION5_GRADE_R;
					case 6:
						return CharacterFormulaConst::Q6_COST_EVOLUTION6_GRADE_R;
					case 7:
						return CharacterFormulaConst::Q6_COST_EVOLUTION7_GRADE_R;
					case 8:
						return CharacterFormulaConst::Q6_COST_EVOLUTION8_GRADE_R;
					case 9:
						return CharacterFormulaConst::Q6_COST_EVOLUTION9_GRADE_R;
					case 10:
						return CharacterFormulaConst::Q6_COST_EVOLUTION10_GRADE_R;
					case 11:
						return CharacterFormulaConst::Q6_COST_EVOLUTION11_GRADE_R;
					default:	// fall through
						Q6JsonLogGunny(Warning, "UCMS::GetCharacterEvoluteCost - R Grade starts at 3(Moon).", Q6KV("Moon", Moon));
						return 0;
				}
			case EItemGrade::SR:
				switch (Moon)
				{
					case 5:
						return CharacterFormulaConst::Q6_COST_EVOLUTION5_GRADE_SR;
					case 6:
						return CharacterFormulaConst::Q6_COST_EVOLUTION6_GRADE_SR;
					case 7:
						return CharacterFormulaConst::Q6_COST_EVOLUTION7_GRADE_SR;
					case 8:
						return CharacterFormulaConst::Q6_COST_EVOLUTION8_GRADE_SR;
					case 9:
						return CharacterFormulaConst::Q6_COST_EVOLUTION9_GRADE_SR;
					case 10:
						return CharacterFormulaConst::Q6_COST_EVOLUTION10_GRADE_SR;
					case 11:
						return CharacterFormulaConst::Q6_COST_EVOLUTION11_GRADE_SR;
					default:	// fall through
						Q6JsonLogGunny(Warning, "UCMS::GetCharacterEvoluteCost - SR Grade starts at 5(Moon).", Q6KV("Moon", Moon));
						return 0;
				}
			case EItemGrade::SSR:
				switch (Moon)
				{
					case 7:
						return CharacterFormulaConst::Q6_COST_EVOLUTION7_GRADE_SSR;
					case 8:
						return CharacterFormulaConst::Q6_COST_EVOLUTION8_GRADE_SSR;
					case 9:
						return CharacterFormulaConst::Q6_COST_EVOLUTION9_GRADE_SSR;
					case 10:
						return CharacterFormulaConst::Q6_COST_EVOLUTION10_GRADE_SSR;
					case 11:
						return CharacterFormulaConst::Q6_COST_EVOLUTION11_GRADE_SSR;
					default:	// fall through
						Q6JsonLogGunny(Warning, "UCMS::GetCharacterEvoluteCost - SSR Grade starts at 7(Moon).", Q6KV("Moon", Moon));
						return 0;
				}
			case EItemGrade::NONE:
			default:	// fall through
				Q6JsonLogGunny(Warning, "UCMS::GetCharacterEvoluteCost - invalid itemgrade");
				return 0;
		}
	}

	int32 GetUltimateCostCharacterFormulaConst(int32 SkillLevel)
	{
		switch (SkillLevel)
		{
			case 2:
				return CharacterFormulaConst::Q6_ULTIMATE_SKILL_UPGRADE_COST2;
			case 3:
				return CharacterFormulaConst::Q6_ULTIMATE_SKILL_UPGRADE_COST3;
			case 4:
				return CharacterFormulaConst::Q6_ULTIMATE_SKILL_UPGRADE_COST4;
			case 5:
				return CharacterFormulaConst::Q6_ULTIMATE_SKILL_UPGRADE_COST5;
			default:
				return 0;
		}
	}

	int32 GetCharacterUltimateUpCost(int32 CurLevel, int32 TargetLevel)
	{
		check(TargetLevel <= CombatCubeConst::Q6_MAX_ULTIMATE_SKILL_LEVEL);

		if (CurLevel == TargetLevel)
		{
			return 0;
		}

		int32 TotalCost = 0;
		for (int32 Level = CurLevel + 1; Level <= TargetLevel; ++Level)
		{
			TotalCost += GetUltimateCostCharacterFormulaConst(Level);
		}

		return TotalCost;
	}

	int32 GetCharacterBaseXP(bool bExclusive)
	{
		if (bExclusive)
		{
			return CharacterFormulaConst::Q6_EXCLUSIVE_XP;
		}

		return CharacterFormulaConst::Q6_BASE_XP;
	}

	int32 GetCharacterMultiplierGradeXP(EItemGrade MaterialGrade, bool bExclusive)
	{
		switch (MaterialGrade)
		{
			case EItemGrade::N:
				return bExclusive ? CharacterFormulaConst::Q6_MUL_EX_GRADE1 : CharacterFormulaConst::Q6_MUL_GRADE1;
			case EItemGrade::R:
				return bExclusive ? CharacterFormulaConst::Q6_MUL_EX_GRADE2 : CharacterFormulaConst::Q6_MUL_GRADE2;
			case EItemGrade::SR:
				return bExclusive ? CharacterFormulaConst::Q6_MUL_EX_GRADE3 : CharacterFormulaConst::Q6_MUL_GRADE3;
			case EItemGrade::SSR:
				return bExclusive ? CharacterFormulaConst::Q6_MUL_EX_GRADE4 : CharacterFormulaConst::Q6_MUL_GRADE4;
		}

		return 0;
	}

	int32 GetCharacterMaxUnbindStar(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return CharacterFormulaConst::Q6_PROMOTE_MAX_STEP_GRADE_N;
			case EItemGrade::R:
				return CharacterFormulaConst::Q6_PROMOTE_MAX_STEP_GRADE_R;
			case EItemGrade::SR:
				return CharacterFormulaConst::Q6_PROMOTE_MAX_STEP_GRADE_SR;
			case EItemGrade::SSR:
				return CharacterFormulaConst::Q6_PROMOTE_MAX_STEP_GRADE_SSR;
			default:
				return 0;
		}
	}

	int32 GetCharacterMaxPromoteStar(EUpgradeCharacterCategory UpCategory, EItemGrade ItemGrade)
	{
		switch (UpCategory)
		{
			case EUpgradeCharacterCategory::Unbind:
			case EUpgradeCharacterCategory::Evolute:
				return GetCharacterMaxUnbindStar(ItemGrade);
			default:
				return MAX_EQUIP_STAR;
		}
	}

	int32 GetStartEvolutionStep(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return CharacterFormulaConst::Q6_EVOLUTION_START_STEP_GRADE_N;
			case EItemGrade::R:
				return CharacterFormulaConst::Q6_EVOLUTION_START_STEP_GRADE_R;
			case EItemGrade::SR:
				return CharacterFormulaConst::Q6_EVOLUTION_START_STEP_GRADE_SR;
			case EItemGrade::SSR:
				return CharacterFormulaConst::Q6_EVOLUTION_START_STEP_GRADE_SSR;
			default:
				return 0;
		}
	}

	int32 GetUpgradeTargetMoon(EItemGrade ItemGrade, int32 Moon)
	{
		return (Moon > 0 ? (Moon + 1) : GetStartEvolutionStep(ItemGrade));
	}

	int32 GetCharacterMaxLevelByStar(int32 Star)
	{
		switch (Star)
		{
			case 1:
				return CharacterFormulaConst::Q6_ONE_STAR_MAX_LV;
			case 2:
				return CharacterFormulaConst::Q6_TWO_STAR_MAX_LV;
			case 3:
				return CharacterFormulaConst::Q6_THREE_STAR_MAX_LV;
			case 4:
				return CharacterFormulaConst::Q6_FOUR_STAR_MAX_LV;
			case 5:
				return CharacterFormulaConst::Q6_FIVE_STAR_MAX_LV;
			case 6:
				return CharacterFormulaConst::Q6_SIX_STAR_MAX_LV;
			case 7:
				return CharacterFormulaConst::Q6_SEVEN_STAR_MAX_LV;
			case 8:
				return CharacterFormulaConst::Q6_EIGHT_STAR_MAX_LV;
			case 9:
				return CharacterFormulaConst::Q6_NINE_STAR_MAX_LV;
			case 10:
			default:
				return CharacterFormulaConst::Q6_TEN_STAR_MAX_LV;
		}
	}

	int32 GetCharacterMaxLevelByMoon(int32 Moon)
	{
		if (Moon <= 0)
		{
			Q6JsonLogRoze(Warning, "UCMS::GetMaxLevelByMoon - Invalid evolution step for calculate max level");
			return GetCharacterMaxLevelByStar(MAX_EQUIP_STAR);
		}

		switch (Moon)
		{
			case 1:
				return CharacterFormulaConst::Q6_ONE_MOON_MAX_LV;
			case 2:
				return CharacterFormulaConst::Q6_TWO_MOON_MAX_LV;
			case 3:
				return CharacterFormulaConst::Q6_THREE_MOON_MAX_LV;
			case 4:
				return CharacterFormulaConst::Q6_FOUR_MOON_MAX_LV;
			case 5:
				return CharacterFormulaConst::Q6_FIVE_MOON_MAX_LV;
			case 6:
				return CharacterFormulaConst::Q6_SIX_MOON_MAX_LV;
			case 7:
				return CharacterFormulaConst::Q6_SEVEN_MOON_MAX_LV;
			case 8:
				return CharacterFormulaConst::Q6_EIGHT_MOON_MAX_LV;
			case 9:
				return CharacterFormulaConst::Q6_NINE_MOON_MAX_LV;
			case 10:
				return CharacterFormulaConst::Q6_TEN_MOON_MAX_LV;
			case 11:
			default:
				return CharacterFormulaConst::Q6_ELEVEN_MOON_MAX_LV;
		}
	}

	int32 GetCharacterMaxLevel(int32 Star, int32 Moon)
	{
		if (Moon <= 0)
		{
			return GetCharacterMaxLevelByStar(Star);
		}

		return GetCharacterMaxLevelByMoon(Moon);
	}


	int32 GetCharacterStarByMoon(EItemGrade ItemGrade, int32 Moon)
	{
		int32 UpgradeStar = GetCharacterMaxUnbindStar(ItemGrade);
		if (Moon <= 0)
		{
			return UpgradeStar;
		}

		int32 MaxLevelByMoon = GetCharacterMaxLevelByMoon(Moon);
		for (int32 star = 1; star <= MAX_STAR; ++star)
		{
			int32 MaxLevelByStar = GetCharacterMaxLevelByStar(star);
			if (MaxLevelByStar > MaxLevelByMoon)
			{
				break;
			}

			UpgradeStar = star;
		}

		return UpgradeStar;
	}

	int32 GetCharacterTurnSkillCount(int32 Star)
	{
		if (Star <= 0)
		{
			Q6JsonLogRoze(Warning, "SystemConstHelper::GetCharacterTurnSkillCount - How could you!");
			return 0;
		}

		switch (Star)
		{
			case 1:
				return CharacterFormulaConst::Q6_NUM_OF_TURN_SKILL_STAR1;
			case 2:
				return CharacterFormulaConst::Q6_NUM_OF_TURN_SKILL_STAR2;
			case 3:
				return CharacterFormulaConst::Q6_NUM_OF_TURN_SKILL_STAR3;
			case 4:
				return CharacterFormulaConst::Q6_NUM_OF_TURN_SKILL_STAR4;
		}

		return CharacterFormulaConst::Q6_NUM_OF_TURN_SKILL_STAR5;
	}

	int32 GetTurnSkillUpgradeCharacterLevel(int32 TargetSkillLevel)
	{
		switch (TargetSkillLevel) {
			case 2: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE2_CHARACTER_LEVEL;
			case 3: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE3_CHARACTER_LEVEL;
			case 4: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE4_CHARACTER_LEVEL;
			case 5: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE5_CHARACTER_LEVEL;
			case 6: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE6_CHARACTER_LEVEL;
			case 7: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE7_CHARACTER_LEVEL;
			case 8: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE8_CHARACTER_LEVEL;
			case 9: return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE9_CHARACTER_LEVEL;
		}

		return CharacterFormulaConst::Q6_TURN_SKILL_UPGRADE10_CHARACTER_LEVEL;
	}

	bool CanTurnSkillUpgradeLevel(int32 TargetSkillLevel, int32 CharacterLevel)
	{
		if (TargetSkillLevel <= 1)
		{
			Q6JsonLogRoze(Error, "Not opened turn skill");
			return false;
		}

		int32 RequiredLevel = GetTurnSkillUpgradeCharacterLevel(TargetSkillLevel);
		return (CharacterLevel >= RequiredLevel);
	}

	bool IsGainedTurnSkill(int32 Star)
	{
		if (SystemConstHelper::GetCharacterTurnSkillCount(Star - 1) == SystemConstHelper::GetCharacterTurnSkillCount(Star))
		{
			return false;
		}

		return true;
	}

	int32 GetEquipAddXpCost(EItemGrade MaterialGrade, int32 Level)
	{
		switch (MaterialGrade)
		{
			case EItemGrade::N:
				return (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_N1 + (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_N2 * Level));
			case EItemGrade::R:
				return (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_R1 + (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_R2 * Level));
			case EItemGrade::SR:
				return (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SR1 + (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SR2 * Level));
			case EItemGrade::SSR:
				return (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SSR1 + (EquipFormulaConst::Q6_UPGRADE_GOLD_COST_GRADE_SSR2 * Level));
			default:
				return EquipFormulaConst::Q6_NONE;
		}
	}

	int32 GetEquipBaseXP()
	{
		return EquipFormulaConst::Q6_BASE_XP;
	}

	int32 GetEquipExclusiveBaseXP()
	{
		return EquipFormulaConst::Q6_EXCLUSIVE_XP;
	}

	int32 GetEquipMultiplierGradeXP(EItemGrade MaterialGrade)
	{
		switch (MaterialGrade)
		{
		case EItemGrade::N:
			return EquipFormulaConst::Q6_MUL_GRADE1;
		case EItemGrade::R:
			return EquipFormulaConst::Q6_MUL_GRADE2;
		case EItemGrade::SR:
			return EquipFormulaConst::Q6_MUL_GRADE3;
		case EItemGrade::SSR:
			return EquipFormulaConst::Q6_MUL_GRADE4;
		default:
			return EquipFormulaConst::Q6_NONE;
		}
	}

	int32 GetEquipMultiplierExclusiveGradeXP(EItemGrade MaterialGrade)
	{
		switch (MaterialGrade)
		{
		case EItemGrade::N:
			return EquipFormulaConst::Q6_MUL_EX_GRADE1;
		case EItemGrade::R:
			return EquipFormulaConst::Q6_MUL_EX_GRADE2;
		case EItemGrade::SR:
			return EquipFormulaConst::Q6_MUL_EX_GRADE3;
		case EItemGrade::SSR:
			return EquipFormulaConst::Q6_MUL_EX_GRADE4;
		default:
			return EquipFormulaConst::Q6_NONE;
		}
	}

	int32 GetEquipMaxLevel(int32 Star)
	{
		switch (Star)
		{
		case 1:
			return EquipFormulaConst::Q6_ONE_STAR_MAX_LV;
		case 2:
			return EquipFormulaConst::Q6_TWO_STAR_MAX_LV;
		case 3:
			return EquipFormulaConst::Q6_THREE_STAR_MAX_LV;
		case 4:
			return EquipFormulaConst::Q6_FOUR_STAR_MAX_LV;
		case 5:
		default:
			return EquipFormulaConst::Q6_FIVE_STAR_MAX_LV;
		}
	}

	int32 GetTierCostEquipFormulaConst(int32 Tier)
	{
		switch (Tier)
		{
		case 2:
			return EquipFormulaConst::Q6_TIER_UPGRADE_COST2;
		case 3:
			return EquipFormulaConst::Q6_TIER_UPGRADE_COST3;
		case 4:
			return EquipFormulaConst::Q6_TIER_UPGRADE_COST4;
		case 5:
			return EquipFormulaConst::Q6_TIER_UPGRADE_COST5;
		default:
			return EquipFormulaConst::Q6_NONE;
		}
	}

	int32 GetEquipTierUpCost(int32 CurTier, int32 TargetTier)
	{
		check(TargetTier <= CombatCubeConst::Q6_MAX_TIER);

		if (CurTier == TargetTier)
		{
			return 0;
		}

		int32 TotalCost = 0;
		for (int32 Tier = CurTier + 1; Tier <= TargetTier; ++Tier)
		{
			TotalCost += GetTierCostEquipFormulaConst(Tier);
		}

		return TotalCost;
	}

	int32 GetMaxBoostCount(EPortalType PortalType)
	{
		switch (PortalType)
		{
		case EPortalType::Character:
			return PyramidFormulaConst::Q6_CHARACTER_PORTAL_BUILD_BOOST_COUNT;
		case EPortalType::Relic:
			return PyramidFormulaConst::Q6_RELIC_PORTAL_BUILD_BOOST_COUNT;
		case EPortalType::Sculpture:
			return PyramidFormulaConst::Q6_SCULPTURE_PORTAL_BUILD_BOOST_COUNT;
		default:
			return 0;
		}
	}

	int32 GetDailyBoostCount(EPortalType PortalType)
	{
		switch (PortalType)
		{
		case EPortalType::Character:
			return PyramidFormulaConst::Q6_CHARACTER_PORTAL_DAILY_BUILD_BOOST;
		case EPortalType::Relic:
			return PyramidFormulaConst::Q6_RELIC_PORTAL_DAILY_BUILD_BOOST;
		case EPortalType::Sculpture:
			return PyramidFormulaConst::Q6_SCULPTURE_PORTAL_DAILY_BUILD_BOOST;
		default:
			return 0;
		}
	}

	int32 GetPortalBoostMaterialReduceCount(int32 Level)
	{
		switch (Level)
		{
		case 2:
			return PyramidFormulaConst::Q6_LEVEL2_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 3:
			return PyramidFormulaConst::Q6_LEVEL3_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 4:
			return PyramidFormulaConst::Q6_LEVEL4_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 5:
			return PyramidFormulaConst::Q6_LEVEL5_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 6:
			return PyramidFormulaConst::Q6_LEVEL6_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 7:
			return PyramidFormulaConst::Q6_LEVEL7_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 8:
			return PyramidFormulaConst::Q6_LEVEL8_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 9:
			return PyramidFormulaConst::Q6_LEVEL9_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		case 10:
			return PyramidFormulaConst::Q6_LEVEL10_PORTAL_BUILD_BOOST_MATERIAL_REDUCE;
		default:
			return 0;
		}
	}

	int32 GetPortalBoostGoldReduceCost(int32 Level)
	{
		int32 GoldReduce = PyramidFormulaConst::Q6_PORTAL_BUILD_BOOST_GOLD_REDUCE;

		switch (Level)
		{
		case 2:
			return PyramidFormulaConst::Q6_LEVEL2_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 3:
			return PyramidFormulaConst::Q6_LEVEL3_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 4:
			return PyramidFormulaConst::Q6_LEVEL4_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 5:
			return PyramidFormulaConst::Q6_LEVEL5_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 6:
			return PyramidFormulaConst::Q6_LEVEL6_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 7:
			return PyramidFormulaConst::Q6_LEVEL7_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 8:
			return PyramidFormulaConst::Q6_LEVEL8_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 9:
			return PyramidFormulaConst::Q6_LEVEL9_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		case 10:
			return PyramidFormulaConst::Q6_LEVEL10_PORTAL_BUILD_BOOST_MATERIAL_REDUCE * GoldReduce;
		default:
			return 0;
		}
	}

	int32 GetPortalBuildingDays(EPortalType PortalType)
	{
		switch (PortalType)
		{
		case EPortalType::Character:
			return PyramidFormulaConst::Q6_CHARACTER_PORTAL_BUILDING_DAYS;
		case EPortalType::Relic:
			return PyramidFormulaConst::Q6_RELIC_PORTAL_BUILDING_DAYS;
		case EPortalType::Sculpture:
			return PyramidFormulaConst::Q6_SCULPTURE_PORTAL_BUILDING_DAYS;
		}

		return 0;
	}

	int32 GetPortalConnectingDays(EPortalType PortalType)
	{
		switch (PortalType)
		{
		case EPortalType::Character:
			return PyramidFormulaConst::Q6_CHARACTER_PORTAL_CONNECTING_DAYS;
		case EPortalType::Relic:
			return PyramidFormulaConst::Q6_RELIC_PORTAL_CONNECTING_DAYS;
		case EPortalType::Sculpture:
			return PyramidFormulaConst::Q6_SCULPTURE_PORTAL_CONNECTING_DAYS;
		}

		return 0;
	}

	int32 GetArtifactSkillType(int32 Index)
	{
		switch (Index)
		{
		case 0:
			return TempleConst::Q6_ARTIFACT1_SKILL_ID;
		case 1:
			return TempleConst::Q6_ARTIFACT2_SKILL_ID;
		case 2:
			return TempleConst::Q6_ARTIFACT3_SKILL_ID;
		}

		return 0;
	}

	int32 GetArtifactSkillCooltime(int32 Index)
	{
		switch (Index)
		{
		case 0:
			return TempleConst::Q6_ARTIFACT1_COOLTIME;
		case 1:
			return TempleConst::Q6_ARTIFACT2_COOLTIME;
		case 2:
			return TempleConst::Q6_ARTIFACT3_COOLTIME;
		}

		return 0;
	}

	int32 GetVacationLevelBonusBond(int32 Level)
	{
		switch (Level)
		{
		case 2:
			return VacationFormulaConst::Q6_LEVEL2_BOND_BUFF;
		case 3:
			return VacationFormulaConst::Q6_LEVEL3_BOND_BUFF;
		case 4:
			return VacationFormulaConst::Q6_LEVEL4_BOND_BUFF;
		case 5:
			return VacationFormulaConst::Q6_LEVEL5_BOND_BUFF;
		case 6:
			return VacationFormulaConst::Q6_LEVEL6_BOND_BUFF;
		case 7:
			return VacationFormulaConst::Q6_LEVEL7_BOND_BUFF;
		case 8:
			return VacationFormulaConst::Q6_LEVEL8_BOND_BUFF;
		case 9:
			return VacationFormulaConst::Q6_LEVEL9_BOND_BUFF;
		case 10:
			return VacationFormulaConst::Q6_LEVEL10_BOND_BUFF;
		default:
			return 0;
		}
	}

	int32 GetMaxCurrencyAmount(ECurrencyType CurrencyType)
	{
		switch (CurrencyType)
		{
			case ECurrencyType::FreeGem:
			case ECurrencyType::PaidGem:
				return SystemConst::Q6_MAX_GEM_AMOUNT;
			case ECurrencyType::SummonTicket:
				return SystemConst::Q6_MAX_SUMMON_TICKET_AMOUNT;
			case ECurrencyType::SculpturePoint:
				return SystemConst::Q6_MAX_SCULPTURE_POINT_AMOUNT;
			case ECurrencyType::RelicPoint:
				return SystemConst::Q6_MAX_RELIC_POINT_AMOUNT;
			case ECurrencyType::FriendshipPoint:
				return SystemConst::Q6_MAX_FRIENDSHIP_POINT_AMOUNT;
			case ECurrencyType::Lumicube:
				return SystemConst::Q6_MAX_LUMICUBE_AMOUNT;
			case ECurrencyType::CharacterDisk:
			case ECurrencyType::SculptureDisk:
			case ECurrencyType::RelicDisk:
				return SystemConst::Q6_MAX_DISK_AMOUNT;
			case ECurrencyType::SmallBattery:
			case ECurrencyType::MediumBattery:
			case ECurrencyType::LargeBattery:
				return SystemConst::Q6_MAX_BATTERY_AMOUNT;
		}

		// default is gold max amount
		return SystemConst::Q6_MAX_GOLD_AMOUNT;
	}

	bool IsWeed(FCharacterType CharacterType)
	{
		return (CharacterType == FCharacterType(SystemConst::Q6_WEED_CHARACTER_ID) ||
			CharacterType == FCharacterType(SystemConst::Q6_CHANGEUP_WEED_CHARACTER_ID));
	}

	bool IsWeed(const FCharacterInfo& Info)
	{
		return IsWeed(Info.Type);
	}

	int32 GetSellCharacterGoldByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_GOLD_N;
			case EItemGrade::R:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_GOLD_R;
			case EItemGrade::SR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_GOLD_SR;
			case EItemGrade::SSR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_GOLD_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellCharacterGoldByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellCharacterLumicubeByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_LUMI_CUBE_N;
			case EItemGrade::R:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_LUMI_CUBE_R;
			case EItemGrade::SR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_LUMI_CUBE_SR;
			case EItemGrade::SSR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_LUMI_CUBE_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellCharacterLumicubeByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellCharacterExpGoldByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_GOLD_N;
			case EItemGrade::R:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_GOLD_R;
			case EItemGrade::SR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_GOLD_SR;
			case EItemGrade::SSR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_GOLD_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellCharacterExpGoldByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellCharacterExpLumicubeByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_LUMI_CUBE_N;
			case EItemGrade::R:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_LUMI_CUBE_R;
			case EItemGrade::SR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_LUMI_CUBE_SR;
			case EItemGrade::SSR:
				return CharacterFormulaConst::Q6_SELL_CHARACTER_EXP_LUMI_CUBE_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellCharacterExpLumicubeByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellSculptureGoldByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_GOLD_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_GOLD_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_GOLD_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_GOLD_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellSculptureGoldByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellSculptureLumicubeByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_LUMI_CUBE_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_LUMI_CUBE_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_LUMI_CUBE_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_LUMI_CUBE_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellSculptureLumicubeByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellSculptureExpGoldByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_GOLD_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_GOLD_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_GOLD_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_GOLD_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellSculptureExpGoldByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellSculptureExpLumicubeByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_LUMI_CUBE_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_LUMI_CUBE_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_LUMI_CUBE_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_SCULPTURE_EXP_LUMI_CUBE_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellSculptureExpLumicubeByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellRelicGoldByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_RELIC_GOLD_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_RELIC_GOLD_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_RELIC_GOLD_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_RELIC_GOLD_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellRelicGoldByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellRelicLumicubeByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_RELIC_LUMI_CUBE_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_RELIC_LUMI_CUBE_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_RELIC_LUMI_CUBE_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_RELIC_LUMI_CUBE_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellRelicLumicubeByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellRelicExpGoldByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_GOLD_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_GOLD_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_GOLD_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_GOLD_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellRelicExpGoldByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	int32 GetSellRelicExpLumicubeByGrade(EItemGrade ItemGrade)
	{
		switch (ItemGrade)
		{
			case EItemGrade::N:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_LUMI_CUBE_N;
			case EItemGrade::R:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_LUMI_CUBE_R;
			case EItemGrade::SR:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_LUMI_CUBE_SR;
			case EItemGrade::SSR:
				return EquipFormulaConst::Q6_SELL_RELIC_EXP_LUMI_CUBE_SSR;
			default:
				Q6JsonLogGunny(Warning, "CharacterFormulaConst::GetSellRelicExpLumicubeByGrade - Invalid itemgrade"
					, Q6KV("ItemGrade", static_cast<int>(ItemGrade)));
				return 0;
		}
	}

	bool IsBoneDragonSagaType(FSagaType SagaType)
	{
		return (SystemConst::Q6_BONE_DRAGON_SAGA_TYPE == SagaType.x);
	}
} // namespace SystemConstHelper
