// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMS_gen.h"
#include "CMSTable.generated.h"

struct FEventScheduleInfo;
struct FCharacterInfo;
struct FActionContext;
struct FCCCombatCubeState;
struct FCCBuffState;
struct FBonusMonster;
struct FCodexCharInfo;
struct FCodexRelicInfo;
struct FCodexSculptureInfo;
struct FEventContentRouletteLineUpInfo;

USTRUCT()
struct FSagaOpenSchedule
{
	GENERATED_USTRUCT_BODY()

	FSagaOpenSchedule() : CMSType(SagaEpisodeOpenScheduleTypeInvalid),
		OpenDate(FDateTime::MinValue()),
		PresentDate(FDateTime::MinValue())
	{}

	UPROPERTY()
	FSagaEpisodeOpenScheduleType CMSType;

	UPROPERTY()
	FDateTime OpenDate;

	UPROPERTY()
	FDateTime PresentDate;
};

enum class EUpgradeCharacterCategory : uint8;
enum class EDayOfWeekType : uint8;
enum class ERewardType : uint8;
enum class EPointType : uint8;

typedef FXpType FUserLevelType;
extern const FUserLevelType MinLevel;
static const int32 CharacterEvoluteMaterialCount = 1;
static const int32 BondTemperaturePerLevel = 5;
static const int32 WonderMaxLevel = 10;
static const int32 MaxBondLevel = 20;

UCLASS(BlueprintType)
class UCMS : public UCMSBase
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable)
	const FCMSSkillRow& GetSkillRowOrDummy(int32 Type) const;

	UFUNCTION(BlueprintCallable)
	const FCMSBuffRow& GetBuffRowOrDummyBP(int32 Type) const;

	UFUNCTION(BlueprintCallable)
	TArray<FCMSSkillEffectRow> GetSkillEffects(int32 Type) const;

	UFUNCTION(BlueprintCallable)
	TArray<FCMSBuffEffectRow> GetBuffEffects(int32 Type) const;
	const TArray<const FCMSBuffEffectRow*> GetBuffEffects(int32 BuffType, EBuffEffectCategory BuffEffectCategory) const;

	UFUNCTION(BlueprintCallable)
	const FCMSUnitRow& GetUnitRowOrDummy(FUnitType UnitType) const;

	UFUNCTION(BlueprintCallable)
	int32 GetModelTypeFromUnitType(int32 UnitType) const;

	FUnitType GetUnitType(FCharacterType CharacterType) const;
	const FCMSUnitRow& GetUnitRowOrDummy(FCharacterType CharacterType) const;
	ENatureType GetNatureType(FCharacterType CharacterType) const { return GetUnitRowOrDummy(CharacterType).NatureType; }
	static EJokerSlotType ToJokerSlotType(ENatureType NatureType)
	{
		switch (NatureType)
		{
			case ENatureType::Fire: return EJokerSlotType::Fire;
			case ENatureType::Water: return EJokerSlotType::Water;
			case ENatureType::Wind: return EJokerSlotType::Wind;
			case ENatureType::Light: return EJokerSlotType::Light;
			case ENatureType::Dark: return EJokerSlotType::Dark;
			default: break;
		}
		check(false);
		return EJokerSlotType::All;
	}
	static ENatureType ToNatureType(EJokerSlotType JokerSlot)
	{
		check(JokerSlot != EJokerSlotType::All);
		switch (JokerSlot)
		{
			case EJokerSlotType::Fire: return ENatureType::Fire;
			case EJokerSlotType::Water: return ENatureType::Water;
			case EJokerSlotType::Wind: return ENatureType::Wind;
			case EJokerSlotType::Light: return ENatureType::Light;
			case EJokerSlotType::Dark: return ENatureType::Dark;
			default: break;
		}
		check(false);
		return ENatureType::Fire;
	}
	EJokerSlotType GetJokerSlotType(FCharacterType CharacterType) const { return UCMS::ToJokerSlotType(GetNatureType(CharacterType)); }

	FSagaType FindSagaType(int32 InEpisode, int32 InStage, int32 InSubStage) const;
	void GetSagaFinishCondition(const FSagaType& Type, int32& LimitTurn, int32& LimitTime) const;
	const FCMSWaveRow* GetWaveRow(FSagaType SagaType, int32 InWaveIndex) const;
	const FString& GetMapPath(FSagaType SagaType) const;
	int32 GetMapLocatorGroup(FSagaType SagaType) const;
	const FString& GetLightPreset(FSagaType SagaType) const;
	const FCMSFormulaConstRow& GetFormulaConstValues(int32 AliveAllyCount) const;
	const FCMSAttributeConstRow& GetAttributeConstValues() const;
	const FCMSAdditionalPointRow* GetAdditionalPoint(int32 Difficulty, EAttributeCategory Category);
	const FCMSAttributeRatioRow* GetAttributeRatio(EAttributeCategory Category);
	const FCMSDifficultyNatureBonusRow* GetDifficultyNatureBonus(int32 Difficulty);

	const FCMSSkillUpgradeCostRow& GetSkillUpgradeCostRowOrDummy(const FCMSSkillRow& SkillRow, int32 TargetLevel) const;
	const FCMSSkillEffectRow* GetSkillEffectRow(int32 SkillType, EEffectCategory EffectCategory) const;
	TArray<const FCMSBuffEffectRow*> GetModifyCrowdControlEffects(const FCCBuffState& Buff, ECrowdControl Control);
	TArray<const FCMSBuffEffectRow*> GetModifyUnitAttributeEffects(const FCCBuffState& Buff, EUnitAttribute Attribute);

	template <typename VisitFunc>
	void VisitSkillEffects(int32 SkillType, VisitFunc Visitor)
	{
		const FCMSSkillRow& SkillRow = UCMSBase::GetSkillRowOrDummy(FSkillType(SkillType));
		for (const FCMSSkillEffectRow* SkillEffectRow : SkillRow.GetSkillEffect())
		{
			Visitor(SkillEffectRow);
		}
	}

	TArray<int32> GetEpisodes(EContentType ContentType) const;

	TArray<const FCMSSagaRow*> GetStageRows(EContentType ContentType, int32 Episode) const;
	int32 GetNumStageRows(EContentType ContentType, int32 Episode) const;

	FUserLevelType GetMaxLevel() const { return MaxLevel; }
	int32 GetMaxXp() const { return MaxXp; }
	int32 GetMaxWatt() const { return MaxWatt; }
	int32 GetMaxFriendLimit() const { return MaxFriendLimit; }

	int32 GetStartXpFromLevel(const FUserLevelType& InLevel) const;
	int32 GetEndXpFromLevel(const FUserLevelType& InLevel) const;
	int32 GetWattLimitFromLevel(const FUserLevelType& InLevel) const;
	int32 GetFriendLimitFromLevel(const FUserLevelType& InLevel) const;
	int32 GetCharacterLevelFromXP(int64 Xp) const;
	int32 GetEquipLevelFromXP(int64 Xp) const;

	int32 GetCoolTimeOriginal(int32 SkillType) const;
	int32 GetCooltimeReduce(int32 SkillLevel) const;
	int32 GetCooltimeByLevel(int32 SkillType, int32 SkillLevel) const;

	int32 GetFourmulaConstRowCount() const { return FourmulaConstRowCount; }
	bool GetWaveMonsterInfo(const FActionContext& Context, const FCCCombatCubeState& InOutState, const FCMSWaveRow* Wave, const int32 InDifficulty,
		int32 InSlot, int32 InWaveIndex, FUnitType& OutUnitType, int32& OutLevel, FCMSAdditionalPointRow** OutAdditionalPoint);
	EApplyTagCompare GetApplyTagCompare(EApplyTag Tag);
	FText GetApplyTagDesc(EApplyTag Tag) const;
	bool IsSagaEpisodeOpen(int32 InEpisode) const;
	bool IsSagaEpisodePresent(int32 InEpisode) const;
	FText GetSagaEpisodeOpenScheduleDesc(int32 InEpisode) const;

	// Character

	const FCMSSkillRow& GetCharacterUltimateSkillRow(FCharacterType CharacterType) const;
	const FCMSSkillRow& GetCharacterUltimateSkillRow(const FCMSUnitRow& UnitRow) const;

	const FCMSSkillRow* GetCharacterTurnSkillRow(const FCMSUnitRow& UnitRow, int32 Index) const;

	const FCMSSkillRow& GetCharacterSupportSkillRow(FCharacterType CharacterType) const;
	const FCMSSkillRow& GetCharacterSupportSkillRow(const FCMSUnitRow& UnitRow) const;

	const FCMSPromoteCostRow& GetCharacterUpStarCostRowOrDummy(EUpgradeCharacterCategory UpCategory, const FCharacterInfo& CharacterInfo) const;
	const FCMSPromoteCostRow& GetCharacterUnbindCostRowOrDummy(const FCharacterInfo& CharacterInfo) const;

	// Relic and Sculpture

	const FCMSPromoteCostRow& GetEquipPromoteCostRowOrDummy(EPromoteCategory Category, int32 TargetStar) const;
	const FCMSPromoteCostRow& GetPromoteCostRowOrDummy(EPromoteCategory Category, ENatureType NatureType, int32 TargetStar) const;

	// 0 to 1
	float GetCharacterNatureTypeBonusRatio() const;

	// SpecialStage
	TArray<const FCMSSpecialRow*> GetSpecialEpisodes(ESpecialCategory Category) const;
	const FCMSSpecialRow* GetSpecialRow(ESpecialCategory Category, int32 Episode) const;
	const FCMSSpecialRow* GetFirstSpecialRowByCategory(ESpecialCategory Category) const;
	TArray<const FCMSSagaRow*> GetPrevSpecialSagaRows(FSagaType SagaType) const;
	const FCMSSpecialRow* GetSpecialRow(FSagaType SagaType) const;

	// DailyDungeon
	const TArray<const FCMSDailyDungeonRow*> GetDailyDungeonValidRows(EDayOfWeekType DayOfWeek) const;
	EDailyDungeonCategory GetDailyDungeonCategory(FSagaType SagaType, EDayOfWeekType DayOfWeek) const;
	const FCMSDailyDungeonRow* GetDailyDungeonRow(FSagaType SagaType) const;
	bool HasBossBonusDailyDungeon(FSagaType SagaType) const;

	// DailyFirstClear Reward
	const FCMSDailyFirstClearRewardRow& GetDailyFirstClearRewardRowByDayOfWeek(EDayOfWeekType InDayOfWeek) const;

	// Episode clear reward
	FSagaType GetEpisodeClearSagaType(int32 Episode) const;
	const FCMSLootDataRow& GetEpisodeClearReward(FSagaType SagaType) const;
	const FCMSLootDataRow& GetEpisodeClearRewardByEpisode(int32 Episode) const;

	// BoxProduct
	bool GetBoxProductRows(int32 PageKey, TArray<const FCMSBoxProductRow*>& BoxProductArray) const;
	int32 GetNeedPickupMileage(int32 EventId) const;

	// Loot
	const FCMSLootDataRow& GetLootDataOrDummy(int32 LootId) const;
	const FCMSLootDataRow& GetFirstLootDataOrDummyFromLootGroups(const FCMSLootGroupRow& LootGroupRow) const;
	const FCMSLootDataRow& GetFirstLootDataOrDummyFromLootGroups(const TArray<const FCMSLootGroupRow*>& LootGroupRows) const;

	// UnitAttribute
	bool IsPercentAttribute(FUnitAttributeType UnitAttributeType) const;
	bool GetPointVaryConvertTypeFromUnitAttribute(EUnitAttribute InUnitAttribute, EPointVaryConvertType& OutPointVaryConvertType) const;
	bool GetUnitAttributeFromPointVaryConvertType(EPointVaryConvertType InConvertType, EUnitAttribute& OutUnitAttribute) const;
	FUnitAttributeType GetUnitAttributeType(EPointVaryConvertType InPointVaryConvertType) const;
	FUnitAttributeType GetUnitAttributeType(EUnitAttribute InUnitAttribute) const;

	// Summon
	static bool IsInfinityEventScheduleFormat(const FEventScheduleInfo& Info);
	TArray<int32> GetValidOrderedPageList(const TArray<FEventScheduleInfo>& Infos);

	// TrainingCenter
	bool IsValidTrainingCenter(FTrainingCenterType Type, FSagaType SagaType);
	bool HasNextStepInTrainingCenter(FTrainingCenterType InType) const;
	bool IsPlayableStepInTrainingCenter(const FCMSTrainingCenterRow& InBeginRow, FTrainingCenterType InType) const;
	FTrainingCenterType GetNextTrainingCenter(FTrainingCenterType InType) const;
	FCharacterType GetTrainingCenterJokerType(FTrainingCenterType CharacterType) const;
	const FCMSLootDataRow& GetTrainingCenterClearReward(FTrainingCenterType Type) const;
	FTrainingCenterType GetTrainingCenterType(FSagaType SagaType) const;

	// Wonder
	int64 GetUpgradeTimeSec(EWonderCategory WonderCategory, int32 TargetLevel) const;
	const FCMSWonderRow* GetWonderRow(EWonderCategory Category, int32 TargetLevel) const;
	const FCMSWonderProductRow* GetWonderProductRow(EWonderCategory Category, int32 TargetLevel) const;

	// Pyramid
	const FCMSWonderCostRow* GetPortalBoostCost(EPortalType PortalType) const;

	// Temple
	const FCMSSkillRow& GetArtifactSkillRowOrDummy(int32 Index) const;
	int32 GetArtifactIndex(int32 InSkillType) const;
	const FCMSSagaRow* GetArtifactOpenConditionSagaRow(FSkillType SkillType) const;

	// Pet
	const FCMSSagaRow* GetPetSkillOpenConditionSagaRow(FSkillType SkillType) const;

	// Bond

	int32 GetBondXpByRow(EBondCategory BondCatg, const FCMSBondXpRow& BondXpRow) const;
	int32 GetBondXpByLevel(EBondCategory BondCatg, int32 BondLevel) const;
	int32 GetStartBondXpByLevel(EBondCategory BondCatg, int32 BondLevel) const;
	int32 GetMaxBondXp(EBondCategory BondCatg) const;
	const FCMSBondRewardRow* GetBondRewardRow(FCharacterType CharacterType, int32 BondLevel) const;

	// Vacation
	const FCMSWonderCostRow* GetVacationCost(FVacationSpotType SpotType) const;

	// CheckIn
	int32 GetLastCheckInDay(FCheckInBoardType BoardType) const;
	int32 GetRotationCheckInDay(FCheckInBoardType BoardType) const;
	TArray<const FCMSCheckInRewardRow*> GetCheckInRewards(int32 RewardId) const;

	// Raid
	FRaidType GetRaidTypeBySagaType(const FSagaType& SagaType) const;
	TArray<const FCMSRaidRow*> GetRaidRows() const;

	// Codex
	void GetCodexCharacterRows(
		const TMap<FCharacterType, FCodexCharInfo>& CodexInfos,
		TArray<const FCMSCharacterRow*>& OutOwnedRows,
		TArray<const FCMSCharacterRow*>& OutNotOwnedRows) const;
	void GetCodexSculptureRows(
		const TMap<FSculptureType, FCodexSculptureInfo>& CodexInfos,
		TArray<const FCMSSculptureRow*>& OutOwnedRows,
		TArray<const FCMSSculptureRow*>& OutNotOwnedRows) const;
	void GetCodexRelicRows(
		const TMap<FRelicType, FCodexRelicInfo>& CodexInfos,
		TArray<const FCMSRelicRow*>& OutOwnedRows,
		TArray<const FCMSRelicRow*>& OutNotOwnedRows) const;

	// AlchemyLab
	TArray<const FCMSAlchemyLabRow*> GetAlchemyLabRows() const;

	// MigriumRefinery
	const FCMSSmelterRow* GetSmelterRowByLevel(const int32 Level) const;

	// UserTitle
	TArray<const FCMSUserTitleRow*> GetUserTitleRowsByCategory(const EUserTitleCategory Category) const;
	TArray<const FCMSUserTitleRow*> GetUserTitleRowByMissionCategory(const EUserTitleMissionCategory MissionCategory) const;

	// ContentFeatureOpen
	const FCMSContentFeatureOpenRow* GetContentFeatureOpenRowBySubPartySlotIndex(const int32 Index) const;
	const FCMSContentFeatureOpenRow* GetContentFeatureOpenRowByOpenType(const EFeatureOpenType OpenType) const;
	const FCMSContentFeatureOpenRow* GetContentFeatureOpenRowByOpenValue(const int32 OpenValue) const;

	// WeeklyMission
	const FCMSMissionSetRow* GetMissionSetRowByWeekNum(const int32 InWeekNum) const;

	// CharMission
	const FCMSCharMissionSetRow* GetCharMissionSetRowByCharType(const FCharacterType& Type) const;

	// CharUnlockElem
	const FCMSCharUnlockElemSetRow* GetCharUnlockElemSetRowByCharType(const FCharacterType& Type) const;

	// UserRecord
	void GetUserRecordRows(TMap<FUserRecordType, const FCMSUserRecordRow*>& Out) const;

	// Shop
	TArray<const FCMSShopRow*> GetShopRowsByShopCategory(EShopCategory InCategory) const;

	// Weed
	TArray<const FCMSWeedGrowRow*> GetWeedGrowRowsByCategory(EWeedGrowCategory Category) const;
	const FCMSWeedGrowRow* GetTurnSkillOpenWeedGrowRow(int32 TurnSkillIndex) const;
	const FCMSWeedGrowRow* GetPreWeedGrowRow(FWeedGrowType Type) const;

	// Buff
	ENatureType GetChangeNatureTypeFromBuff(FBuffType InBuffType) const;
	bool HasShieldStateFromBuff(int32 InBuffType) const;

	// CurrencyPoint
	const FCMSCurrencyPointRow* GetCurrencyPointRow(EPointType PointType) const;
	const FCMSCurrencyPointRow* GetEventCurrencyPointRow(FEventContentType InEventContentType, int32 InPointIndex) const;

	// Event
	TArray<const FCMSShopRow*> GetEventShop(FEventContentType InEventContentType) const;
	FEventContentType GetEventContentType(FSagaType InSagaType) const;
	const int32 GetEventContentRouletteLineUpTotalItemCount(const FEventContentRouletteLineUpInfo& InEventContentRouletteLineUpInfo) const;

	//Valentine
	FEventContentValentineDayType GetEventContentValentineDayType(FSagaType InSagaType) const;
	TArray<const FCMSEventContentAccumPointRewardRow*> GetEventContentAccumPointRewards(FEventContentType InEventContentType) const;

	FEventContentMapType GetEventContentMapType(FSagaType InSagaType) const;

	// MultiSideBattleRank
	const int32 GetMultiSideBattleRankEventConst(int32 InDifficulty) const;
	const int32 GetMultiSideBattleRankBonusConst(EMultiSideRankBonusCategory InCategory) const;
	const FText GetMultiSideBattleRankBonusDesc(EMultiSideRankBonusCategory InCategory) const;
	const FCMSMultiSideBattleRankBonusRow* GetMultiSideBattleRankBonusRow(EMultiSideRankBonusCategory InCategory) const;
	TArray<const FCMSEventContentMultiSideBattleRewardRow*> GetMultisideBattleRewards(FEventContentType InContentType) const;
	FEventContentMultiSideBattleStageType GetEventContentMultiSideBattleStageType(FSagaType InSagaType) const;
	const FCMSEventContentMultiSideBattleRow* GetEventContentMultiSideBattleRow(FEventContentType InContentType) const;
	TArray<const FCMSEventContentMultiSideBattleStageRow*> GetEventContentMultisideBattleStageRows(FEventContentType InContentType) const;

	// Bonus Monster
	void SetBonusMonsterInfo(const FCMSSagaRow& InSagaRow, const FBonusMonster& InBonusMonster);

private:

	virtual bool OnPostLoading() override;

	void SetBonusMonsterWaveRow(FCMSWaveRow& OutBonusWaveRow, const FBonusMonster& InBonusMonster, int32 InSpawnLevel, bool bInIsLastBonusMonsterRow);
	void ResetBonusMonsterWaveRows();

	FUserLevelType MaxLevel;
	int32 MaxXp;
	int32 MaxWatt;
	int32 MaxFriendLimit;
	int32 FourmulaConstRowCount;
	TArray<int32> CooldownReduce;
	TMultiMap<int32 /* PageKey */, const FCMSBoxProductRow*> BoxProducts;
	TMap<int32, const FCMSSagaRow*> EpisodeClearSagas;
	TMap<int32, FSagaOpenSchedule> SagaEpisodeOpenScheduleMap;

	// bonus monster
	FCMSWaveRow BonusMonsterWaveRow;
	FCMSWaveRow LastBonusMonsterWaveRow;
	int32 StartBonusWaveIndex;
	int32 LastBonusWaveIndex;
	bool bHasBonusMonster;

	TMap<FTrainingCenterType, FTrainingCenterType> TrainingCenterNextMap;
};
