// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#include "SummonBranch.h"

#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"
#include "Engine/StaticMeshActor.h"
#include "Animation/SkeletalMeshActor.h"
#include "Sections/MovieSceneEventTriggerSection.h"
#include "Tracks/MovieSceneEventTrack.h"
#include "Channels/MovieSceneEvent.h"

#include "Q6.h"
#include "GameResource.h"
#include "UnitAnimInstance.h"
#include "LevelUtil.h"

USummonBranch::USummonBranch()
{
	PlayingIndex = 0;
}

void USummonBranch::Initialize(const TArray<ULevelSequence*>& InSequences, const FSummonBranchParam& InParam)
{
	Sequences = InSequences;
	BranchParam = InParam;

	TArray<FFrameTime> SkipFrames;
	BranchSkipFrames.Reserve(Sequences.Num());

	for (ULevelSequence* Sequence : Sequences)
	{
		ImportSkipFrame(Sequence, SkipFrames);
		BranchSkipFrames.Add(SkipFrames);
	}
}

bool USummonBranch::Play(AActor* Receiver, bool bInJumpToSkip)
{
	EventReceivers.SetNum(1);
	EventReceivers[0] = Receiver;

	PlayingIndex = 0;

	if (bInJumpToSkip)
	{
		for (int32 i = 0; i < BranchSkipFrames.Num(); i++)
		{
			if (BranchSkipFrames[i].Num() > 0)
			{
				PlayingIndex = i;
				break;
			}
		}
	}

	if (PlayInternal(PlayingIndex))
	{
		if (bInJumpToSkip)
		{
			JumpToNextSkipFrame();
		}

		return true;
	}

	return false;
}

bool USummonBranch::PlayInternal(int32 Index)
{
	if (!Sequences.IsValidIndex(Index))
	{
		Q6JsonLogZagal(Warning, "Summon - Invalid Sequence Index", Q6KV("Index", Index));
		return false;
	}

	ULevelSequence* Sequence = Sequences[Index];
	if (!Sequence)
	{
		Q6JsonLogZagal(Warning, "Summon - Sequence is NULL", Q6KV("Index", Index));
		return false;
	}

	DestroySequenceActor();
	ModelCustomizing();

	FMovieSceneSequencePlaybackSettings Settings;
	Settings.bHidePlayer = true;
	Settings.bPauseAtEnd = BranchParam.bPauseAtEnd;

	bool bFireLoopBegin = false;
	if (BranchParam.LoopIndex == Index)
	{
		Settings.LoopCount.Value = -1;
		bFireLoopBegin = true;
	}

	SequencePlayer = ULevelSequencePlayer::CreateLevelSequencePlayer(this, Sequence, Settings, SequenceActor);
	if (!SequencePlayer)
	{
		Q6JsonLogZagal(Warning, "Summon - Failed to CreateLevelSequencePlayer");
		return false;
	}

	SequenceActor->SetEventReceivers(EventReceivers);
	SequencePlayer->OnFinished.AddUniqueDynamic(this, &USummonBranch::OnSequenceEnd);
	SequencePlayer->Play();

	if (bFireLoopBegin)
	{
		LoopBegin.ExecuteIfBound();
	}

	return true;
}

void USummonBranch::StopLooping()
{
	if (PlayingIndex == BranchParam.LoopIndex)
	{
		OnSequenceEnd();
	}
}

void USummonBranch::JumpToLoop()
{
	if (PlayingIndex < BranchParam.LoopIndex)
	{
		PlayingIndex = BranchParam.LoopIndex;
		PlayInternal(PlayingIndex);
	}
}

void USummonBranch::JumpToLastFrame()
{
	if (SequencePlayer && SequencePlayer->IsPlaying())
	{
		FFrameTime EndTime = SequencePlayer->GetEndTime().Time;
		JumpToFrame(EndTime);
	}
}

bool USummonBranch::JumpToNextSkipFrame()
{
	if (SequencePlayer && SequencePlayer->IsPlaying())
	{
		FFrameTime CurrentTime = SequencePlayer->GetCurrentTime().Time;

		for (const FFrameTime& SkipTime : BranchSkipFrames[PlayingIndex])
		{
			if (CurrentTime < SkipTime)
			{
				JumpToFrame(SkipTime);
				return true;
			}
		}
	}

	return false;
}

void USummonBranch::DestroySequenceActor()
{
	if (SequencePlayer)
	{
		SequencePlayer->Stop();
		SequencePlayer = nullptr;
	}

	if (SequenceActor)
	{
		SequenceActor->Destroy();
		SequenceActor = nullptr;
	}
}

void USummonBranch::JumpToFrame(FFrameTime FrameTime)
{
	if (SequencePlayer && SequencePlayer->IsPlaying())
	{
		FFrameTime JumpFrame(FrameTime.FrameNumber - 1, 0.99999994f);
		SequencePlayer->JumpToFrame(JumpFrame);

		Q6JsonLogZagal(Display, "JumpToFrame - ", Q6KV("Time", JumpFrame.FrameNumber.Value));
	}
}

void USummonBranch::ImportSkipFrame(ULevelSequence* Sequence, TArray<FFrameTime>& OutFrames)
{
	OutFrames.Empty();

	UMovieScene* MovieScene = Sequence->GetMovieScene();
	if (!MovieScene)
	{
		return;
	}

	UMovieSceneEventTrack* EventTrack = nullptr;
	if (!MovieScene->GetMasterTracks().FindItemByClass(&EventTrack))
	{
		return;
	}

	UMovieSceneEventTriggerSection* EventSection = nullptr;
	if (!EventTrack->GetAllSections().FindItemByClass(&EventSection))
	{
		return;
	}

	FFrameRate SourceRate = MovieScene->GetTickResolution();
	FFrameRate DestinationRate = MovieScene->GetDisplayRate();

	TArrayView<const FFrameNumber> Times = EventSection->EventChannel.GetData().GetTimes();

	for (int32 KeyIndex = 0; KeyIndex < Times.Num(); ++KeyIndex)
	{
		FFrameTime FrameTime = ConvertFrameTime(Times[KeyIndex], SourceRate, DestinationRate);
		OutFrames.Add(FrameTime);

		Q6JsonLogZagal(Display, "Summon - Imported Skip Time", Q6KV("Time", FrameTime.GetFrame().Value));
	}
}

void USummonBranch::OnSequenceEnd()
{
	int32 NewIndex = PlayingIndex + 1;
	if (Sequences.IsValidIndex(NewIndex))
	{
		PlayingIndex = NewIndex;
		PlayInternal(PlayingIndex);
	}
	else
	{
		SequenceEnd.ExecuteIfBound();
	}
}

void USummonBranch::GatherCharacterActors(TArray<ASkeletalMeshActor*>& Actors)
{
	FName Names[] = { TEXT("Character"), TEXT("Character_SR"), TEXT("Character_SSR"),
				  TEXT("Character2"), TEXT("Character2_SR"), TEXT("Character2_SSR") };

	for (TActorIterator<ASkeletalMeshActor> It(GetWorld(), ASkeletalMeshActor::StaticClass()); It; ++It)
	{
		ASkeletalMeshActor* Actor = *It;

		for (int32 i = 0; i < UE_ARRAY_COUNT(Names); i++)
		{
			if (Actor->GetFName().IsEqual(Names[i], ENameCase::IgnoreCase, false))
			{
				Actors.Add(Actor);
				break;
			}
		}
	}
}

void _SetModelCustomizing(ASkeletalMeshActor* Actor, const FUnitModelAssetRow& Row, int32 ModelType, bool bCustomInstance)
{
	USkeletalMeshComponent* Mesh = Actor->GetSkeletalMeshComponent();

	Mesh->SetAnimInstanceClass(nullptr);
	ULevelUtil::LoadSkeletalMesh(Mesh, Row, ModelType, true, true, false);

	if (bCustomInstance)
	{
		Mesh->SetAnimationMode(EAnimationMode::AnimationCustomMode);
	}
	else
	{
		Mesh->SetAnimInstanceClass(Row.AnimInstanceClass.LoadSynchronous());

		if (UUnitAnimInstance* AnimInst = Cast<UUnitAnimInstance>(Mesh->GetAnimInstance()))
		{
			FAnimLoadingOption LoadingOption;
			LoadingOption.ModelType = ModelType;
			LoadingOption.bInCombat = false;

			AnimInst->LoadAnimations(LoadingOption, true);
			AnimInst->SetRelaxed(true);
		}
	}
}

void USummonBranch::ModelCustomizing()
{
	if (BranchParam.ModelType <= 0)
	{
		return;
	}

	TArray<ASkeletalMeshActor*> Actors;
	GatherCharacterActors(Actors);

	const FUnitModelAssetRow& Row = GetGameResource().GetUnitModelAssetRow(BranchParam.ModelType);

	for (ASkeletalMeshActor* Actor : Actors)
	{
		_SetModelCustomizing(Actor, Row, BranchParam.ModelType, BranchParam.bCustomInstance);
	}
}
