// Copyright (c) 2019 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"

#include "SummonBranch.generated.h"

class ALevelSequenceActor;
class ASkeletalMeshActor;
class ULevelSequence;
class ULevelSequencePlayer;

struct FSummonBranchParam
{
	int32 ModelType;
	int32 LoopIndex;
	bool bPauseAtEnd;
	bool bCustomInstance;

	FSummonBranchParam()
	{
		ModelType = 0;
		LoopIndex = -1;
		bPauseAtEnd = false;
		bCustomInstance = true;
	}
};

UCLASS()
class Q6_API USummonBranch : public UObject
{
	GENERATED_BODY()

public:
	USummonBranch();

	void Initialize(const TArray<ULevelSequence*>& InSequences, const FSummonBranchParam& InParam);
	bool Play(AActor* Receiver, bool bInJumpToSkip);
	void StopLooping();

	void JumpToLoop();
	void JumpToLastFrame();
	bool JumpToNextSkipFrame();
	void DestroySequenceActor();

	FSimpleDelegate SequenceEnd;
	FSimpleDelegate LoopBegin;

private:
	void JumpToFrame(FFrameTime FrameTime);
	bool PlayInternal(int32 Index);

	void ImportSkipFrame(ULevelSequence* Sequence, TArray<FFrameTime>& OutFrames);

	void GatherCharacterActors(TArray<ASkeletalMeshActor*>& Actors);
	void ModelCustomizing();

	UFUNCTION()
	void OnSequenceEnd();

	UPROPERTY(Transient)
	ALevelSequenceActor* SequenceActor;

	UPROPERTY(Transient)
	ULevelSequencePlayer* SequencePlayer;

	UPROPERTY(Transient)
	TArray<ULevelSequence*> Sequences;

	FSummonBranchParam BranchParam;
	TArray<TArray<FFrameTime>> BranchSkipFrames;
	
	TArray<AActor*> EventReceivers;
	int32 PlayingIndex;
};
