// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "ImportCmsCommandlet.h"

#if WITH_EDITOR
#include "UnrealEd.h"
#include "Q6Log.h"
#include "PackageHelperFunctions.h"

static FString LoadCmsData(const FString& FilePath)
{
	FString Data;
	if (!FFileHelper::LoadFileToString(Data, *FilePath))
	{
		Q6JsonLog(Error, "LoadCmsData", Q6KV("Error", *FilePath));
		return FString();
	}
	return Data;
}

static void CleanUpUassets()
{
	TArray<FString> UassetFiles;
	IFileManager* FileManager = &IFileManager::Get();

	FString CmsDirectory = FPaths::ProjectContentDir() / "CMS";
	FileManager->FindFiles(UassetFiles, *CmsDirectory, TEXT("*.uasset"));

	for (const FString& UassetFile : UassetFiles)
	{
		FString Path = CmsDirectory / UassetFile;
		FileManager->Delete(*Path);
	}
}

static FString GetBaseModelName(const FString& InModelName)
{
	FString BaseModelName = InModelName;

	int32 RestPos = BaseModelName.Find(TEXT("_"), ESearchCase::IgnoreCase, ESearchDir::FromStart);
	if (RestPos != INDEX_NONE)
	{
		BaseModelName = BaseModelName.Left(RestPos);
	}

	return BaseModelName;
}

bool ParseFilter(const FString& Params, TArray<FString>& Filters)
{
	FRegexPattern FiltersPattern(TEXT("-filter=(\\S+)"));
	FRegexMatcher FiltersMatcher(FiltersPattern, Params);
	if (FiltersMatcher.FindNext()) {
		const FString FiltersParam = Params.Mid(FiltersMatcher.GetMatchBeginning() + FString(TEXT("-filter=")).Len(), FiltersMatcher.GetMatchEnding());
		if (FiltersParam.ParseIntoArray(Filters, TEXT(","), true) > 0) {
			return true;
		}
	}

	return false;
}

#endif // WITH_EDITOR

int32 UImportCmsCommandlet::Main(const FString& Params)
{
#if WITH_EDITOR
	TArray<FString> Filters;
	const bool FilterUsedFlag = ParseFilter(Params, Filters);

	TArray<FString> CmsFiles;
	IFileManager* FileManager = &IFileManager::Get();

	FString CmsDirectory = FPaths::ProjectContentDir() / "CMS";
	FileManager->FindFiles(CmsFiles, *CmsDirectory, TEXT("*.csv"));
	bool result = true;

	// If fields are appended previous tables does not load the values of these fields.
	// So clean up previous uasset files.
	if (!FilterUsedFlag) {
		CleanUpUassets();
	}

	// Disable pop-up message
	ShowErrorCount = false;

	for (const FString& CmsFile : CmsFiles)
	{
		FString ModelName = FPaths::GetBaseFilename(CmsFile);

		if (FilterUsedFlag && !Filters.ContainsByPredicate([ModelName](const FString& Filter) {
			return ModelName == Filter || ModelName.StartsWith(Filter + TEXT("To"));
		})) {
			continue;
		}

		FString PackageName = FString::Printf(TEXT("/Game/CMS/%s"), *ModelName);
		FString AssetPath = FString::Printf(TEXT("%s.%s"), *PackageName, *ModelName);
		FString CmsFullPath = FString::Printf(TEXT("%s/%s"), *CmsDirectory, *CmsFile);
		FString StructName = FString::Printf(TEXT("CMS%sRow"), *GetBaseModelName(ModelName));

		Q6JsonLog(Display, "Begin Load Asset", Q6KV("message", *AssetPath));

		UDataTable* DataTable = LoadObject<UDataTable>(nullptr, *AssetPath);
		if (!DataTable)
		{
			Q6JsonLog(Display, "Asset Load Faild");

			FString CSV = LoadCmsData(CmsDirectory / CmsFile);
			if (CSV.IsEmpty())
			{
				Q6JsonLog(Error, "ImportCmsCommandlet] CSV is empty", Q6KV("Error", *CmsFile));
				result = false;
				continue;
			}

			UScriptStruct* ImportRowStruct = FindObject<UScriptStruct>(ANY_PACKAGE, *StructName);
			if (!ImportRowStruct)
			{
				Q6JsonLog(Display, "ImportCmsCommandlet] Cannot find struct", Q6KV("Error", *StructName));
				result = false;
				continue;
			}

			UPackage* NewPackage = CreatePackage(nullptr, *PackageName);
			NewPackage->FullyLoad();
			EObjectFlags Flags = RF_Public | RF_Standalone;

			DataTable = NewObject<UDataTable>(NewPackage, UDataTable::StaticClass(), *ModelName, Flags);
			DataTable->RowStruct = ImportRowStruct;
			DataTable->CreateTableFromCSVString(CSV);
			DataTable->PostInitProperties();
			DataTable->AssetImportData->Update(CmsFullPath);
		}
		else
		{
			Q6JsonLog(Display, "Asset Load Success");

			UScriptStruct* ImportRowStruct = FindObject<UScriptStruct>(ANY_PACKAGE, *StructName);
			if (!ImportRowStruct)
			{
				Q6JsonLog(Display, "Already Deleted schema struct.", Q6KV("message", *AssetPath));
				continue;
			}

			Q6JsonLog(Display, "Asset Reimport Process Begin.");
			if (!FReimportManager::Instance()->Reimport(DataTable, false, false))
			{
				Q6JsonLog(Error, "ImportCmsCommandlet] Reimport", Q6KV("Error", *AssetPath));
				result = false;
				continue;
			}
			Q6JsonLog(Display, "Asset Reimport Process End.");
		}

		UPackage* Package = DataTable->GetOutermost();
		if (!Package)
		{
			Q6JsonLog(Error, "ImportCmsCommandlet] No Package", Q6KV("Error", *PackageName));
			result = false;
			continue;
		}

		DataTable->MarkPackageDirty();
		if (!SavePackageHelper(Package, *FPackageName::LongPackageNameToFilename(PackageName, FPackageName::GetAssetPackageExtension())))
		{
			Q6JsonLog(Error, "ImportCmsCommandlet] Save UDataTable uasset", Q6KV("Error", *PackageName));
			result = false;
			continue;
		}

		Q6JsonLog(Display, "ImportCmsCommandlet] Success", Q6KV("Info", *PackageName));
	}

	if (result) {
		// Delete CSV files
		for (const FString& CmsFile : CmsFiles)
		{
			FileManager->Delete(*CmsFile);
		}
	}
#endif // WITH_EDITOR

	return 0;
}
