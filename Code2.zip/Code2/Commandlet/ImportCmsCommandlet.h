// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Commandlets/Commandlet.h"
#include "ImportCmsCommandlet.generated.h"

/**
 * UImportCmsCommandlet
 */
UCLASS()
class Q6_API UImportCmsCommandlet : public UCommandlet
{
	GENERATED_BODY()
	
public:
	// Begin UCommandlet Interface
	virtual int32 Main(const FString& Params) override;
	// End UCommandlet Interface
};
