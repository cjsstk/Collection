// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "GameFramework/Character.h"
#include "CMSType_gen.h"
#include "UnitBase.generated.h"

class UGameAssetCache;
class UPaperSpriteComponent;
struct FUnitModelAssetRow;

USTRUCT(BlueprintType)
struct FUnitInitParams
{
	GENERATED_USTRUCT_BODY()

	FUnitInitParams() : bBlockingLoad(false), bNeedAsset(true), StreamingPriority(0)
	{}

	explicit FUnitInitParams(bool bInBlockingLoad) : bBlockingLoad(bInBlockingLoad), bNeedAsset(true), StreamingPriority(0)
	{}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bBlockingLoad;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	bool bNeedAsset;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 StreamingPriority;
};

UCLASS()
class Q6_API AUnitBase : public ACharacter
{
	GENERATED_BODY()

public:
	AUnitBase(const FObjectInitializer& ObjectInitializer);

	FUnitType GetUnitType() const { return FUnitType(DescType); }
	int32 GetModelType() const { return ModelType; }

	// Streaming
	virtual void StreamLoadAsset();
	bool IsStreaming() const;
	bool IsAssetLoaded() const;
	void UnloadAsset();

	void EnableUnit();
	void DisableUnit();

	virtual void SetSequenceAnimMode(bool bInSeqAnimMode);

protected:
	virtual void InitMesh();
	void InitMeshInternal(const FUnitModelAssetRow& Row);

	virtual void LoadAnimations() {}
	virtual void LoadSkillSequences() {}

	void OnAssetStreamCompleted();
	void ResetAnimation();
	void UpdateAnimationImmediately();
	void ForceRecentlyRendered();

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Unit)
	int32 DescType;

	int32 ModelType;
	float MeshScale;
	float BoundRadius;

	UPROPERTY(Transient)
	FUnitInitParams UnitInitParams;

	// Decal
	UPROPERTY(Transient)
	UPaperSpriteComponent* ShadowComponent;

	// Asset cache
	UPROPERTY(Transient)
	UGameAssetCache* AssetCache;

	bool bSequenceAnimMode;
};
