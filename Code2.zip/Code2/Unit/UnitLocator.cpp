// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "UnitLocator.h"
#include "Q6Define.h"

ACharacterLocator::ACharacterLocator(const FObjectInitializer& ObjectInitializer)
	: AUnit(ObjectInitializer)
{
	OverrideFaction = ECCFaction::Ally;
}

AMonsterLocator::AMonsterLocator(const FObjectInitializer& ObjectInitializer)
	: AUnit(ObjectInitializer)
{
	OverrideFaction = ECCFaction::Enemy;
}
