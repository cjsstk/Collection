// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "UnitBase.h"
#include "PetUnit.generated.h"

class ULevelSequence;
class UPetUnitAnimInstance;

struct FPetType;

UCLASS()
class Q6_API APetUnit : public AUnitBase
{
	GENERATED_BODY()
	
public:	
	APetUnit(const FObjectInitializer& ObjectInitializer);

	void InitPetUnit(FPetType InPetType, FUnitInitParams InInitParams = FUnitInitParams());

	void PlaySpawnAnimation();
	void SetRandomIdleAnimTimer();
	void ClearRandomIdleAnimTimer();

	ULevelSequence* GetSkillSequence(int32 Index) const;

private:
	UPetUnitAnimInstance* GetPetUnitAnimInstance() const;
	virtual void LoadAnimations() override;
	virtual void LoadSkillSequences() override;
};
