// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "MainPartUnit.h"
#include "CombatGameResource.h"
#include "MainPartUnitAnimInstance.h"
#include "Q6.h"
#include "Q6Log.h"

extern TAutoConsoleVariable<float> CVarSpawnMaterialDuration;
extern TAutoConsoleVariable<float> CVarDeadMaterialDuration;


AMainPartUnit::AMainPartUnit(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, CurSubPartIndex(INDEX_NONE)
{}

UMainPartUnitAnimInstance* AMainPartUnit::GetMainPartUnitAnimInstance() const
{
	UMainPartUnitAnimInstance* AnimInstance = Cast<UMainPartUnitAnimInstance>(GetMesh()->GetAnimInstance());
	return AnimInstance;
}

void AMainPartUnit::InitMesh()
{
	Super::InitMesh();

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		ActiveSubPartIndexes = AnimInstance->GetDefaultSubPartIndexes();

		const TArray<FMaterialSlotIndexes>& SubPartsMaterialSlotIndexes = AnimInstance->GetSubPartsMaterialSlotIndexes();
		for (int32 i = 0; i < SubPartsMaterialSlotIndexes.Num(); ++i)
		{
			if (ActiveSubPartIndexes.Contains(i))
			{
				continue;
			}

			// hide non default material slots
			const FMaterialSlotIndexes& SubPartMaterialSlotIndexes = SubPartsMaterialSlotIndexes[i];
			for (int32 MaterialSlotIndex : SubPartMaterialSlotIndexes.MaterialSlotIndexes)
			{
				GetMesh()->ShowMaterialSection(MaterialSlotIndex, 0, false, 0);
			}
		}
	}
}

void AMainPartUnit::LoadAnimations()
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		FAnimLoadingOption LoadingOption;
		LoadingOption.ModelType = ModelType;
		LoadingOption.bIsCharacter = false;
		LoadingOption.bInCombat = (GetCombatGameMode(this) != nullptr);
		AnimInstance->LoadAnimations(LoadingOption, true);
	}
}

float AMainPartUnit::GetTurnSkillAnimLength() const
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	UAnimSequenceBase* Animation = nullptr;
	if (AnimInstance)
	{
		Animation = AnimInstance->GetCombatTurnSkillAnimation();
	}
	return Animation ? Animation->GetPlayLength() : 0.f;
}

float AMainPartUnit::GetDeadAnimLength() const
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	UAnimSequenceBase* Animation = AnimInstance ? AnimInstance->GetDeadAnimation() : nullptr;
	return Animation ? Animation->GetPlayLength() : 0.f;
}

float AMainPartUnit::GetSubPartDeadAnimLength(int32 InSubPartIndex) const
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	UAnimSequenceBase* Animation = AnimInstance ? AnimInstance->GetSubPartDeadAnimation(InSubPartIndex) : nullptr;
	return Animation ? Animation->GetPlayLength() : 0.f;
}

void AMainPartUnit::GetSkillAnimNotifyInfo(int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo)
{
	OutSkillAnimHitInfo.Empty();

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		ensure(OverrideFaction == ECCFaction::Enemy);
		AnimInstance->GetSkillAnimNotifyInfo(OverrideFaction, InSkillType, OutSkillAnimHitInfo, bSkillAnimHasSequenceStart);
	}
}

void AMainPartUnit::GetSubPartSkillAnimNotifyInfo(int32 InSubPartIndex, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart)
{
	OutSkillAnimHitInfo.Empty();

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->GetSubPartSkillAnimNotifyInfo(InSubPartIndex, InSkillType, OutSkillAnimHitInfo, bSkillAnimHasSequenceStart);
	}
}

void AMainPartUnit::EnableSubPart(int32 InSubPartIndex)
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		const FMaterialSlotIndexes& SubPartMaterialSlotIndexes = AnimInstance->GetSubPartMaterialSlotIndexes(InSubPartIndex);
		for (int32 SubPartMaterialSlotIndex : SubPartMaterialSlotIndexes.MaterialSlotIndexes)
		{
			GetMesh()->ShowMaterialSection(SubPartMaterialSlotIndex, 0, true, 0);
		}
	}
}

void AMainPartUnit::DisableSubPart(int32 InSubPartIndex)
{
	if (ActiveSubPartIndexes.Contains(InSubPartIndex))
	{
		return;
	}

	ensure(CurSubPartIndex == InSubPartIndex);

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{	
		const FMaterialSlotIndexes& SubPartMaterialSlotIndexes = AnimInstance->GetSubPartMaterialSlotIndexes(InSubPartIndex);
		for (int32 SubPartMaterialSlotIndex : SubPartMaterialSlotIndexes.MaterialSlotIndexes)
		{
			GetMesh()->ShowMaterialSection(SubPartMaterialSlotIndex, 0, false, 0);
		}
	}

	CurSubPartIndex = INDEX_NONE;
}

void AMainPartUnit::ApplyMaterialOverride(UMaterialInterface* OverrideMaterial)
{
	int32 NumMaterials = DefaultMeshMaterials.Num();
	for (int32 i = 0; i < NumMaterials; ++i)
	{
		if (!GetMesh()->IsMaterialSectionShown(i, 0))
		{
			continue;
		}

		if (OverrideMaterial)
		{
			UMaterialInstanceDynamic* DynamicMaterial = GetMesh()->CreateDynamicMaterialInstance(i, OverrideMaterial);
			DynamicMaterial->K2_CopyMaterialInstanceParameters(OverrideMaterial);
		}
		else
		{
			UMaterialInterface* DefaultMaterial = DefaultMeshMaterials[i];
			GetMesh()->SetMaterial(i, DefaultMaterial);
		}
	}
}

void AMainPartUnit::ApplySubPartMaterialOverride(const FMaterialSlotIndexes& ApplyMaterialSlotIndexes, UMaterialInterface* OverrideMaterial)
{
	for (int32 ApplyIndex : ApplyMaterialSlotIndexes.MaterialSlotIndexes)
	{
		if (!GetMesh()->IsMaterialSectionShown(ApplyIndex, 0))
		{
			continue;
		}

		if (OverrideMaterial)
		{
			UMaterialInstanceDynamic* DynamicMaterial = GetMesh()->CreateDynamicMaterialInstance(ApplyIndex, OverrideMaterial);
			DynamicMaterial->K2_CopyMaterialInstanceParameters(OverrideMaterial);
		}
		else
		{
			UMaterialInterface* DefaultMaterial = DefaultMeshMaterials[ApplyIndex];
			GetMesh()->SetMaterial(ApplyIndex, DefaultMaterial);
		}
	}
}

void AMainPartUnit::ApplySubPartMaterialEffect(int32 InSubPartIndex)
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (!AnimInstance)
	{
		return;
	}

	UMaterialInterface* EffectMaterial = nullptr;
	for (int i = 0; i < (int)EUnitMaterialEffectLayer::Max; ++i)
	{
		if (EffectMaterials[i] == nullptr)
		{
			continue;
		}

		EffectMaterial = EffectMaterials[i];
	}

	const FMaterialSlotIndexes& SubPartMaterialSlotIndexes = AnimInstance->GetSubPartMaterialSlotIndexes(InSubPartIndex);
	ApplySubPartMaterialOverride(SubPartMaterialSlotIndexes, EffectMaterial);

	TickMaterialEffect(0);
}

void AMainPartUnit::SetSubPartMaterialEffect(int32 InSubPartIndex, EUnitMaterialEffectLayer Layer, UMaterialInterface* Material, float Duration /* = -1.0f */)
{
	if (EffectMaterials[(int32)Layer] == Material)
	{
		return;
	}

	EffectMaterials[(int32)Layer] = Material;
	EffectMaterialAgeSeconds[(int32)Layer] = 0;
	EffectMaterialDurationSeconds[(int32)Layer] = Duration;

	ApplySubPartMaterialEffect(InSubPartIndex);
}

void AMainPartUnit::SetSubPartSubMaterialEffect(int32 InSubPartIndex, const FSubMaterialEffectParams& SubMaterialParams)
{
	int32 Mask = -1;
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		Mask = AnimInstance->GetSubPartSubMaterialMask(InSubPartIndex);
	}

	SetSubMaterialEffect(SubMaterialParams, Mask);
}

void AMainPartUnit::StartSubPartSpawnFX(int32 InSubPartIndex, ESpawnReason InReason)
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (!AnimInstance)
	{
		return;
	}

	GetWorldTimerManager().ClearTimer(SpawnEffectTimerHandle);
	GetWorldTimerManager().SetTimer(SpawnEffectTimerHandle, this, &AMainPartUnit::OnSpawnMaterialEffectEnd, CVarSpawnMaterialDuration.GetValueOnGameThread());

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StartSubPartSpawnFX failed, no CombatGameResource");
		return;
	}

	UMaterialInterface* SpawnEffectMaterial = CombatGameResource->GetSpawnEffectMaterial(InReason, CommonEffectIndex);
	if (SpawnEffectMaterial)
	{
		SetSubPartMaterialEffect(InSubPartIndex, EUnitMaterialEffectLayer::Overlay, SpawnEffectMaterial);
	}

	UParticleSystem* SpawnEffetParticle = CombatGameResource->GetSpawnEffectParticle(InReason, CommonEffectIndex);
	if (SpawnEffetParticle)
	{
		UGameplayStatics::SpawnEmitterAttached(SpawnEffetParticle, GetMesh(), NAME_None, FVector(ForceInit), FRotator::ZeroRotator);
	}

	USoundBase* SpawnEffectSound = CombatGameResource->GetSpawnEffectSound(InReason);
	if (SpawnEffectSound)
	{
		UGameplayStatics::PlaySound2D(this, SpawnEffectSound);
	}
}

void AMainPartUnit::StartSubPartDeadFX(int32 InSubPartIndex)
{
	GetWorldTimerManager().ClearTimer(DeadEffectTimerHandle);
	GetWorldTimerManager().SetTimer(DeadEffectTimerHandle, this, &AMainPartUnit::OnSubPartDeadMaterialEffectEnd, CVarDeadMaterialDuration.GetValueOnGameThread());

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StartSubPartDeadFX failed, no CombatGameResource");
		return;
	}

	UMaterialInterface* DeadEffectMaterial = CombatGameResource->GetDeadEffectMaterial(CommonEffectIndex);
	if (DeadEffectMaterial)
	{
		SetSubPartMaterialEffect(InSubPartIndex, EUnitMaterialEffectLayer::Overlay, DeadEffectMaterial);
	}

	UParticleSystem* DeadEffectParticle = CombatGameResource->GetDeadEffectParticle(CommonEffectIndex);
	if (DeadEffectParticle)
	{
		UWorld* const World = GetWorld();
		if (World)
		{
			FVector CenterSocketLocation = GetMesh()->GetSocketLocation(UnitSocket::Center);
			UGameplayStatics::SpawnEmitterAtLocation(World, DeadEffectParticle, CenterSocketLocation);
		}
	}

	USoundBase* DeadEffectSound = CombatGameResource->GetDeadEffectSound();
	if (DeadEffectSound)
	{
		UGameplayStatics::PlaySound2D(this, DeadEffectSound);
	}
}

void AMainPartUnit::SetStunned(bool bInStunned)
{
	if (bAnimPaused)
	{
		return;
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetStunned(bInStunned);
	}
}

void AMainPartUnit::SetMoving(bool bInMoving)
{
	if (bAnimPaused)
	{
		return;
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetMoving(bInMoving);
	}
}

void AMainPartUnit::SetDead()
{
	if (bAnimPaused)
	{
		SetAnimPaused(false);
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	SetDeadInternal(AnimInstance);
}

void AMainPartUnit::SetSubPartSpawn(int32 InSubPartIndex, ESpawnReason InReason)
{
	if (ActiveSubPartIndexes.Contains(InSubPartIndex))
	{
		return;
	}

	ActiveSubPartIndexes.AddUnique(InSubPartIndex);

	EnableSubPart(InSubPartIndex);
	StartSubPartSpawnFX(InSubPartIndex, InReason);
}

void AMainPartUnit::SetSubPartDead(int32 InSubPartIndex)
{
	if (ActiveSubPartIndexes.Contains(InSubPartIndex))
	{
		ActiveSubPartIndexes.Remove(InSubPartIndex);
	}

	if (bAnimPaused)
	{
		SetAnimPaused(false);
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		CurSubPartIndex = InSubPartIndex;
		AnimInstance->SetSubPartDead(InSubPartIndex, true);

		UAnimSequenceBase* DeadAnimation = AnimInstance->GetSubPartDeadAnimation(InSubPartIndex);
		const float DeadAnimationLength = DeadAnimation ? DeadAnimation->GetPlayLength() : 0.0f;
		GetWorldTimerManager().ClearTimer(DeadAnimTimerHandle);
		GetWorldTimerManager().SetTimer(DeadAnimTimerHandle, this, &AMainPartUnit::OnDeadAnimEnd, DeadAnimationLength);

		const float DeadEffectStartDelay = FMath::Max(0.0f, DeadAnimationLength * 0.5f);
		GetWorldTimerManager().ClearTimer(DeadEffectTimerHandle);
		GetWorldTimerManager().SetTimer(DeadEffectTimerHandle, this, &AMainPartUnit::OnSubPartDeadMaterialEffectStart, DeadEffectStartDelay);
	}
	else
	{
		StartSubPartDeadFX(InSubPartIndex);
	}
}

void AMainPartUnit::OnSubPartDeadMaterialEffectStart()
{
	DeadEffectTimerHandle.Invalidate();
	StartSubPartDeadFX(CurSubPartIndex);
}

void AMainPartUnit::OnSubPartDeadMaterialEffectEnd()
{
	DeadEffectTimerHandle.Invalidate();
	DisableSubPart(CurSubPartIndex);
}

void AMainPartUnit::SetSubPartHit(int32 InSubPartIndex, const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam)
{
	PlaySubPartHit(InSubPartIndex);

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "SetSubPartHit SubMaterialEffect failed, no CombatGameResource");
	}
	else
	{
		const FSubMaterialEffectParams& HitEffectMaterialParams = CombatGameResource->GetHitEffectMaterialParams();
		SetSubPartSubMaterialEffect(InSubPartIndex, HitEffectMaterialParams);
	}

	StartParticleEffects(ParticleParam, SoundParam);
}

void AMainPartUnit::SetShieldHit(bool bBroken)
{
	// sunny-to-do-fxs
}

void AMainPartUnit::SetSubPartShieldHit(int32 InSubPartIndex, bool bBroken)
{
	// sunny-to-do-fxs
}

void AMainPartUnit::SetUltimateSkillState(bool bIsOn)
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetUltimateSkill(bIsOn);
	}
}

void AMainPartUnit::SetTurnSkillIndex(int32 InIndex)
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetCombatTurnSkillIndex(InIndex);
	}
}

void AMainPartUnit::SetSubPartTurnSkillIndex(int32 InSubPartIndex, int32 InIndex)
{
	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetSubPartCombatTurnSkillIndex(InSubPartIndex, InIndex);
	}
}

void AMainPartUnit::PlayNormalSkill(const FVector& InTargetLocation, bool bIsDouble)
{
	if (bAnimPaused)
	{
		return;
	}

	UpdateTargetTransform(InTargetLocation, true);
	ensure(!bIsDouble);

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (!AnimInstance)
	{
		OnAnimNotifySkillEnd();
	}
	else
	{
		if (!AnimInstance->SetSkill(true))
		{
			OnAnimNotifySkillEnd();
		}
	}
}

void AMainPartUnit::PlayTurnSkill()
{
	if (bAnimPaused)
	{
		return;
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (!AnimInstance || !AnimInstance->SetTurnSkill(true))
	{
		OnAnimNotifyTurnSkillEnd();
	}
}

void AMainPartUnit::PlayShout()
{
	if (bAnimPaused)
	{
		return;
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (!AnimInstance || !AnimInstance->SetShout(true))
	{
		OnAnimNotifyShoutEnd();
	}
}

void AMainPartUnit::PlayHit()
{
	if (bAnimPaused)
	{
		return;
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetHit(true);
	}
}

void AMainPartUnit::PlaySubPartHit(int32 InSubPartIndex)
{
	if (bAnimPaused)
	{
		return;
	}

	UMainPartUnitAnimInstance* AnimInstance = GetMainPartUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetSubPartHit(InSubPartIndex, true);
	}
}
