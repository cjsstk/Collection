// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "Unit.h"
#include "AnimationRuntime.h"
#include "CombatCubeUtil.h"
#include "CombatGameResource.h"
#include "CombatPlayerController.h"
#include "GameAssetCache.h"
#include "GameResource.h"
#include "PaperSpriteComponent.h"
#include "Particles/ParticleSystemComponent.h"
#include "Q6.h"
#include "Q6SoundPlayer.h"
#include "UnitAnimInstance.h"
#if WITH_EDITOR
#include "Editor.h"
#endif

TAutoConsoleVariable<float> CVarSpawnMaterialDuration(
	TEXT("q6.SpawnMaterialDuration"),
	1.2f,
	TEXT("time to wait for spawn material effects"),
	ECVF_Cheat);

TAutoConsoleVariable<float> CVarDeadMaterialDuration(
	TEXT("q6.DeadMaterialDuration"),
	1.2f,
	TEXT("time to wait for dead material effects before hide unit"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarBuffMaterialDuration(
	TEXT("q6.BuffMaterialDuration"),
	2.f,
	TEXT("time to wait for buff material effects"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarMoveToUnitDistOffset(
	TEXT("q6.MoveToUnitDistOffset"),
	150.f,
	TEXT("additional offset between units on move"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarCCStateInterval(
	TEXT("q6.CCStateInterval"),
	3.f,
	TEXT("time to show one CC state if has multiple CCs"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarCCStateParticleScaleMultiplier(
	TEXT("q6.CCStateParticleScaleMultiplier"),
	0.6f,
	TEXT("multiplier to make CC state particles smaller on camera layer attached unit"),
	ECVF_Cheat);

static TAutoConsoleVariable<float> CVarUnitRotateTime(
	TEXT("q6.UnitRotateTime"),
	0.3f,
	TEXT("time to rotate unit"),
	ECVF_Cheat);

AUnit::AUnit(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, OverrideFaction(ECCFaction::Enemy)
	, CommonEffectIndex(0)
	, bAnimPaused(false)
	, bSkillAnimHasSequenceStart(false)
	, bRotatable(true)
	, bInvisibleDropBox(false)
	, bAnimRelaxed(true)
	, bRotating(false)
	, bMoving(false)
	, bSkipMoveBack(false)
	, bCCStateEffectsHidden(false)
	, MoveStartTime(0.f)
	, LastUpdatedCCStateEffectIndex(INDEX_NONE)
	, LastCCStateUpdateTime(0.f)
	, bMuteDeadVoice(false)
{
	PrimaryActorTick.bCanEverTick = true;
	UnitState.UnitId = CCUnitIdInvalid;

	for (int32 Index = 0; Index < UE_ARRAY_COUNT(EffectMaterialAgeSeconds); ++Index)
	{
		EffectMaterialAgeSeconds[Index] = 0;
		EffectMaterialDurationSeconds[Index] = 0;
	}

	SubMaterialAgeSecond = 0;

	for (int32 Index = 0; Index < UE_ARRAY_COUNT(DecalMode); ++Index)
	{
		DecalMode[Index] = false;
	}
}

#if WITH_EDITOR
void AUnit::PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent)
{
	if (PropertyChangedEvent.Property)
	{
		if (PropertyChangedEvent.Property->GetName() == GET_MEMBER_NAME_STRING_CHECKED(AUnit, DescType))
		{
			InitFromDesc();
		}
	}
	else
	{
		// Usually, this is case where 'compile' is clicked in editor
		InitFromDesc();
	}

	Super::PostEditChangeProperty(PropertyChangedEvent);
}

void AUnit::RerunConstructionScripts()
{
	Super::RerunConstructionScripts();

	// Load unit mesh for editor edit view
	// shouldn't call InitFromDesc in play mode

	// NOTE : RerunConstructionScripts() gets called twice. first at LoadPackage(Level) and second at Exc Map Load
	//        We shouldn't load any asset at first one. Otherwise, PostLoad() will not be
	//        called(ThreadContext.ObjBeginLoadCount is not 1) immediately and
	//		  it will crash due to SkeletonMesh::Skeleton is NULL
	bool bIsLevelLoaded = GetWorld() && GetWorld()->GetOuter()->HasAnyFlags(RF_WasLoaded);

	if (GEditor && !GetLocalPlayerController(this) && !IsRunningCommandlet() && bIsLevelLoaded)
	{
		InitFromDesc();
	}
}

#endif // WITH_EDITOR

void AUnit::InitUnit(int32 InUnitType, FUnitInitParams InInitParams /* = FUnitInitParams() */)
{
	DescType = InUnitType;
	UnitInitParams = InInitParams;

	ClearIntermediateState();
	InitFromDesc();
}

void AUnit::InitFromUnitState(const FUnitState& InUnitState, bool bInAnimRelaxed, bool bBlockingLoad)
{
	if (InUnitState.UnitId == CCUnitIdInvalid)
	{
		Q6JsonLogSunny(Error, "AUnit::InitFromUnitState - Invalid unit id");
		return;
	}

	// pawn - bBlockingLoad could be true in CombatPresenter::SynchronizeCCState() for calling OnAssetStreamCompleted() directly
	//		  Unit's assets are loaded by CombatPresenter::CacheStageAssets() already
	UnitInitParams.bBlockingLoad |= bBlockingLoad;

	UnitState = InUnitState;
	DescType = UnitState.UnitType;
	OverrideFaction = UnitState.Faction;
	bAnimRelaxed = bInAnimRelaxed;

	ClearIntermediateState();
	InitFromDesc();
}

void AUnit::InitFromDesc()
{
	if (!DescType)
	{
		return;
	}
	Q6JsonLogSunny(Display, "Init Unit from desc", Q6KV("DescType", DescType));

	ModelType = GetCMS()->GetModelTypeFromUnitType(DescType);

	// We don't use UE movement component. We just follow Combat cube unit.
	if (GetMovementComponent())
	{
		GetMovementComponent()->DestroyComponent();
	}

	UnloadAsset();

	if (UnitInitParams.bNeedAsset)
	{
		// Stream Assets
		FUnitAssetCacheOptions CacheOptions;
		CacheOptions.bBlocking = UnitInitParams.bBlockingLoad;
		CacheOptions.Priority = UnitInitParams.StreamingPriority;

		bool bIsCombatAllyUnit = UnitState.UnitId != CCUnitIdInvalid && OverrideFaction == ECCFaction::Ally;
		CacheOptions.bIncludeCombatPortraits = bIsCombatAllyUnit;
		CacheOptions.bIncludeResultSequence = bIsCombatAllyUnit;

		if (AssetCache)
		{
			AssetCache->CancelStreaming();
		}

		AssetCache = GetGameResource().GetCacheManager()->CacheUnit(DescType, CacheOptions,
			FGameAssetStreamDelegate::CreateUObject(this, &AUnit::OnAssetStreamCompleted));
	}

	// this information is needed before OnAssetStreamCompleted()
	const FUnitModelAssetRow& Row = GetGameResource().GetUnitModelAssetRow(ModelType);
	bInvisibleDropBox = Row.bInvisibleDropBox;
}

bool AUnit::IsAttached() const
{
	USceneComponent* Parent = GetRootComponent() ? GetRootComponent()->GetAttachParent() : nullptr;
	return Parent != nullptr;
}

void AUnit::AttachUnitTo(UStaticMeshComponent* InParentSceneComponent, const FName& SocketName)
{
	if (!InParentSceneComponent || !InParentSceneComponent->DoesSocketExist(SocketName))
	{
		return;
	}

	UpdateRotationToEnd();
	UpdateCCStateEffectsScale(CVarCCStateParticleScaleMultiplier.GetValueOnGameThread());

	AttachToComponent(InParentSceneComponent, FAttachmentTransformRules::SnapToTargetNotIncludingScale, SocketName);
}

void AUnit::DetachAndReturnToInitialPosition()
{
	if (!IsAttached())
	{
		return;
	}

	UpdateCCStateEffectsScale(1.f / CVarCCStateParticleScaleMultiplier.GetValueOnGameThread());

	DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	SetActorTransform(InitialTransform);
}

void AUnit::PlayPrepareSpawnAnimation()
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance && AnimInstance->SetPrepareSpawn(true))
	{
		UpdateAnimationImmediately();
		ForceRecentlyRendered();
	}
}

void AUnit::StopPrepareSpawnAnimation()
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetPrepareSpawn(false);
	}
}

void AUnit::SetSkillCooldown(const FCCSkillId& Id, int32 Cooldown)
{
	for (FSkillState& SkillState : UnitState.TurnBegins)
	{
		if (SkillState.SkillId != Id)
		{
			continue;
		}

		SkillState.Cooldown = Cooldown;
		return;
	}

	for (FSkillState& SkillState : UnitState.Ultimates)
	{
		if (SkillState.SkillId != Id)
		{
			continue;
		}

		SkillState.Cooldown = Cooldown;
		return;
	}
}

void AUnit::SetSkillWaitdown(const FCCSkillId& Id, int32 Waitdown)
{
	for (FSkillState& SkillState : UnitState.TurnBegins)
	{
		if (SkillState.SkillId != Id)
		{
			continue;
		}

		SkillState.WaitDown = Waitdown;
		return;
	}

	for (FSkillState& SkillState : UnitState.Ultimates)
	{
		if (SkillState.SkillId != Id)
		{
			continue;
		}

		SkillState.WaitDown = Waitdown;
		return;
	}
}

void AUnit::SetBuffDuration(int32 BuffType, int32 Duration)
{
	for (FBuffState& BuffState : UnitState.Buffs)
	{
		if (BuffState.BuffType != BuffType)
		{
			continue;
		}

		BuffState.Duration = Duration;
	}
}

void AUnit::SetNature(ENatureType InNatureType)
{
	UnitState.NatureType = InNatureType;
}

void AUnit::SetBaseTransform(const FTransform& InTransform)
{
	BaseTransform = InTransform;
}

void AUnit::IncreaseSkillUsingCount(FCCSkillId InId)
{
	for (FSkillState& SkillState : UnitState.Normals)
	{
		if (SkillState.SkillId != InId)
		{
			continue;
		}

		SkillState.UsingCount++;
		return;
	}

	for (FSkillState& SkillState : UnitState.Ultimates)
	{
		if (SkillState.SkillId != InId)
		{
			continue;
		}

		SkillState.UsingCount++;
		return;
	}

	for (FSkillState& SkillState : UnitState.Supports)
	{
		if (SkillState.SkillId != InId)
		{
			continue;
		}

		SkillState.UsingCount++;
		return;
	}

	for (FSkillState& SkillState : UnitState.TurnBegins)
	{
		if (SkillState.SkillId != InId)
		{
			continue;
		}

		SkillState.UsingCount++;
		return;
	}

	for (FSkillState& SkillState : UnitState.Artifacts)
	{
		if (SkillState.SkillId != InId)
		{
			continue;
		}

		SkillState.UsingCount++;
		return;
	}
}

void AUnit::AddBuff(const FBuffState& BuffState)
{
	UnitState.Buffs.Add(BuffState);

	SortBuffsByDuration();
}

void AUnit::UpdateBuff(const FBuffState& InBuffState)
{
	TArray<FBuffState>& BuffStates = UnitState.Buffs;

	for (FBuffState& BuffState : BuffStates)
	{
		if (BuffState.BuffId == InBuffState.BuffId)
		{
			BuffState = InBuffState;
		}
	}

	SortBuffsByDuration();
}

void AUnit::RemoveBuff(FCCBuffId BuffId)
{
	for (int32 i = 0; i < UnitState.Buffs.Num(); ++i)
	{
		if (UnitState.Buffs[i].BuffId == BuffId)
		{
			UnitState.Buffs.RemoveAt(i);
			break;
		}
	}

	SortBuffsByDuration();
}

void AUnit::SortBuffsByDuration()
{
	UCMS* CMS = GetCMS();
	UnitState.Buffs.Sort([CMS](const FBuffState& BuffA, const FBuffState& BuffB)
	{
		const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffA.BuffType));
		if (BuffRow.Infinity)
		{
			return true;
		}

		return (BuffA.Duration < BuffB.Duration);
	});
}

bool AUnit::HasVersaBuff() const
{
	return GetUnitState().Buffs.FindByPredicate([](const FBuffState& InBuffState) {
		return InBuffState.BornCategory == ESkillCategory::Versa;
	});
}

bool AUnit::HasUltimateSkills() const
{
	if (IsDead())
	{
		return false;
	}

	bool bHasUltimate = false;

	for (auto& Iter : UnitState.Ultimates)
	{
		if (!Iter.bPattern)
		{
			bHasUltimate = true;
		}
	}

	return bHasUltimate;
}

void AUnit::AddPointVaryUnitAttribute(EPointVaryConvertType InPointVaryUnitAttributeType, int32 InValue)
{
	FUnitAttributeType UnitAttributetType = GetCMS()->GetUnitAttributeType(InPointVaryUnitAttributeType);
	FPointVaryUnitAttributeState PointVaryUnitAttributeState(UnitAttributetType, InValue);

	UnitState.PointVaryUnitAttributes.Add(PointVaryUnitAttributeState);
}

bool AUnit::ClearPointVaryUnitAttributes()
{
	if (!UnitState.PointVaryUnitAttributes.Num())
	{
		return false;
	}

	UnitState.PointVaryUnitAttributes.Empty();
	return true;
}

void AUnit::UpdateUnitAttributes(FUnitAttributeType UnitAttributeType, int32 InAmount)
{
	if (UnitAttributeType == UnitAttributeTypeInvalid)
	{
		return;
	}

	const UCMS* CMS = GetCMS();
	const FCMSUnitAttributeRow& UnitAttributeRow = CMS->GetUnitAttributeRowOrDummy(UnitAttributeType);

	switch (UnitAttributeRow.UnitAttribute)
	{
		case EUnitAttribute::Atk:
			UnitState.UnitAttributes.Attack = InAmount;
			break;
		case EUnitAttribute::AtkVary:
			UnitState.UnitAttributes.AttackVary = InAmount;
			break;
		case EUnitAttribute::AtkVaryper:
			UnitState.UnitAttributes.AttackVaryPercent = InAmount;
			break;
		case EUnitAttribute::Def:
			UnitState.UnitAttributes.Defense = InAmount;
			break;
		case EUnitAttribute::DefVary:
			UnitState.UnitAttributes.DefenseVary = InAmount;
			break;
		case EUnitAttribute::DefVaryper:
			UnitState.UnitAttributes.DefenseVaryPercent = InAmount;
			break;
	}
}

bool AUnit::ShiftUltimateSkillStats()
{
	TArray<FSkillState>& UnitUlts = UnitState.Ultimates;
	return UCombatCubeStateUtil::ShiftSkills(UnitUlts);
}

void AUnit::GetNextUltimateSkillWaitdown(int32& OutSkillWaitdown, int32* OutInitialWaitdown) const
{
	if (!HasUltimateSkills())
	{
		return;
	}

	OutSkillWaitdown = UnitState.Ultimates[0].WaitDown;
	if (OutInitialWaitdown)
	{
		(*OutInitialWaitdown) = UnitState.Ultimates[0].WaitTime;
	}
}

const FUltimateSkillSequenceAssetRow& AUnit::GetUltimateSkillSequenceAssetRow(int32 InSkillType, bool bInAddMissingLog /* = true */) const
{
	UGameResource& GameResource = GetGameResource();

	if (GetUltimateSkillCount() > 1)
	{
		return GameResource.GetSkillUltimateSkillSequenceAssetRow(InSkillType, bInAddMissingLog);
	}

	return GameResource.GetModelUltimateSkillSequenceAssetRow(ModelType, bInAddMissingLog);
}

static bool _CheckCCApplyPhase(ECrowdControl CC, ECPTurnPhase Phase, ECCFaction Faction)
{
	if (Phase == ECPTurnPhase::Prepare)
	{
		return false;
	}

	if (Faction == ECCFaction::Ally)
	{
		switch (Phase)
		{
			case ECPTurnPhase::TurnSkill:
				return ((CC == ECrowdControl::Stun) || (CC == ECrowdControl::Silence));
			case ECPTurnPhase::Steady:
				return ((CC == ECrowdControl::Stun) || (CC == ECrowdControl::Silence) ||
					(CC == ECrowdControl::Provoke) || (CC == ECrowdControl::CrossFire) ||
					(CC == ECrowdControl::IgnoreDodged) || (CC == ECrowdControl::IgnoreInvincible));
			case ECPTurnPhase::OppAttack:
				return (CC == ECrowdControl::IgnoreDef);
			default:
				return false;
		}
	}

	if (Faction == ECCFaction::Enemy)
	{
		switch (Phase)
		{
			case ECPTurnPhase::OppTurnSkill:
				return ((CC == ECrowdControl::Stun) || (CC == ECrowdControl::Silence));
			case ECPTurnPhase::OppAttack:
				return ((CC == ECrowdControl::Stun) || (CC == ECrowdControl::Silence) ||
					(CC == ECrowdControl::Provoke) || (CC == ECrowdControl::CrossFire) ||
					(CC == ECrowdControl::IgnoreDodged) || (CC == ECrowdControl::IgnoreInvincible));
			case ECPTurnPhase::Steady:
				return (CC == ECrowdControl::IgnoreDef);
			default:
				return false;
		}
	}

	return false;
}

static bool _CheckCCApplySkillUse(ECrowdControl CC, ESkillCategory SkillCategory)
{
	switch (SkillCategory)
	{
	case ESkillCategory::Normal:
		return (CC == ECrowdControl::Stun);
	case ESkillCategory::Ultimate:
	case ESkillCategory::Support:
	case ESkillCategory::TurnBegin:
		return ((CC == ECrowdControl::Silence) || (CC == ECrowdControl::Stun));
	}

	return false;
}

void AUnit::GatherCCBuffEffectsOnPhase(TArray<FBuffEffectState>& Out, ECPTurnPhase Phase) const
{
	const UCMS* CMS = GetCMS();

	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(BuffState.BuffType, EBuffEffectCategory::ModifyCrowdControl);
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			ECrowdControl CC = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1)).CrowdControl;
			bool bIsApply = _CheckCCApplyPhase(CC, Phase, UnitState.Faction);
			if (bIsApply)
			{
				const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffState.BuffType));
				Out.AddUnique(FBuffEffectState(FBuffEffectType(BuffEffectRow->Type), BuffRow.Lock));
			}
		}
	}
}

void AUnit::GatherCCBuffEffectsOnSkillUse(TArray<FBuffEffectState>& Out, ESkillCategory SkillCategory) const
{
	const UCMS* CMS = GetCMS();

	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(BuffState.BuffType, EBuffEffectCategory::ModifyCrowdControl);
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			ECrowdControl CC = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1)).CrowdControl;
			bool bIsApply = _CheckCCApplySkillUse(CC, SkillCategory);
			if (bIsApply)
			{
				const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffState.BuffType));
				Out.AddUnique(FBuffEffectState(FBuffEffectType(BuffEffectRow->Type), BuffRow.Lock));
			}
		}
	}
}

void AUnit::GatherCCBuffEffects(TArray<FBuffEffectState>& Out, ECrowdControl InCC) const
{
	const UCMS* CMS = GetCMS();

	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(BuffState.BuffType, EBuffEffectCategory::ModifyCrowdControl);
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			ECrowdControl CC = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1)).CrowdControl;
			if (CC == InCC)
			{
				const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffState.BuffType));
				Out.AddUnique(FBuffEffectState(FBuffEffectType(BuffEffectRow->Type), BuffRow.Lock));
			}
		}
	}
}

bool AUnit::HasCCBuffEffect(ECrowdControl InCC) const
{
	const UCMS* CMS = GetCMS();

	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(BuffState.BuffType, EBuffEffectCategory::ModifyCrowdControl);
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			ECrowdControl CC = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1)).CrowdControl;
			if (CC == InCC)
			{
				return true;
			}
		}
	}

	return false;
}

FCCBuffCoolTime AUnit::GetCCBuffCoolTime() const
{
	const UCMS* CMS = GetCMS();

	FCCBuffCoolTime CCBuffCoolTime;

	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(BuffState.BuffType, EBuffEffectCategory::ModifyCrowdControl);
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			ECrowdControl CC = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1)).CrowdControl;
			if (CC == ECrowdControl::Silence || CC == ECrowdControl::Stun)
			{
				if (BuffState.Duration > CCBuffCoolTime.CCDuration)
				{
					CCBuffCoolTime.CCDuration = BuffState.Duration;

					if (!CCBuffCoolTime.bInfinity)
					{
						const FCMSBuffRow& BuffRow = CMS->GetBuffRowOrDummy(FBuffType(BuffState.BuffType));
						CCBuffCoolTime.bInfinity = BuffRow.Infinity;
						return CCBuffCoolTime;
					}
				}
			}
		}
	}

	return CCBuffCoolTime;
}

FBuffType AUnit::GetBuffType(const FCCBuffId& InBuffId) const
{
	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		if (BuffState.BuffId == InBuffId)
		{
			return FBuffType(BuffState.BuffType);
		}
	}

	return BuffTypeInvalid;
}

FCCUnitId AUnit::GetProvokeTargetUnitId() const
{
	const UCMS* CMS = GetCMS();

	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		const TArray<const FCMSBuffEffectRow*> BuffEffectRows = CMS->GetBuffEffects(BuffState.BuffType, EBuffEffectCategory::ModifyCrowdControl);
		for (const FCMSBuffEffectRow* BuffEffectRow : BuffEffectRows)
		{
			ECrowdControl CC = CMS->GetCrowdControlRowOrDummy(FCrowdControlType(BuffEffectRow->Param1)).CrowdControl;
			if (CC == ECrowdControl::Provoke)
			{
				return BuffState.SourceUnitId;
			}
		}
	}

	return CCUnitIdInvalid;
}

FTransform AUnit::GetBottomTransform() const
{
	return GetMesh()->GetComponentTransform();
}

FTransform AUnit::GetSocketTransform(const FName Socket) const
{
	return GetMesh()->GetSocketTransform(Socket);
}

FTransform AUnit::GetSocketComponentSpaceRefTransform(const FName Socket) const
{
	FName SocketBoneName = GetMesh()->GetSocketBoneName(Socket);
	if (SocketBoneName == NAME_None)
	{
		Q6JsonLogSunny(Error, "AUnit::GetSocketComponentSpaceRefTransform - Invalid socket", Q6KV("Socket", Socket.ToString()));
		return FTransform::Identity;
	}

	int32 BoneIndex = GetMesh()->GetBoneIndex(SocketBoneName);
	if (BoneIndex == INDEX_NONE)
	{
		Q6JsonLogSunny(Error, "AUnit::GetSocketComponentSpaceRefTransform - Invalid bone", Q6KV("Bone", SocketBoneName.ToString()));
		return FTransform::Identity;
	}

	FTransform RefTransform = FAnimationRuntime::GetComponentSpaceTransformRefPose(GetMesh()->SkeletalMesh->RefSkeleton, BoneIndex);
	FTransform SocketBoneTransform = GetMesh()->GetSocketTransform(Socket, RTS_ParentBoneSpace);
	return SocketBoneTransform * RefTransform;
}

void AUnit::StreamLoadAsset()
{
	Super::StreamLoadAsset();

	InitFromDesc();
}

UUnitAnimInstance* AUnit::GetUnitAnimInstance() const
{
	UUnitAnimInstance* AnimInstance = Cast<UUnitAnimInstance>(GetMesh()->GetAnimInstance());
	return AnimInstance;
}

FTransform AUnit::GetMultiLayerAttachmentTransform() const
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	return AnimInstance ? AnimInstance->GetAttachmentTransform() : FTransform();
}

FTransform AUnit::GetMultiLayerAttachmentLightTransform() const
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	return AnimInstance ? AnimInstance->GetAttachmentLightTransform() : FTransform();
}

float AUnit::GetTurnSkillAnimLength() const
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	UAnimSequenceBase* Animation = nullptr;
	if (AnimInstance)
	{
		Animation = OverrideFaction == ECCFaction::Ally ? AnimInstance->GetTurnSkillAnimation() : AnimInstance->GetCombatTurnSkillAnimation();
	}
	return Animation ? Animation->GetPlayLength() : 0.f;
}

float AUnit::GetDeadAnimLength() const
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	UAnimSequenceBase* Animation = AnimInstance ? AnimInstance->GetDeadAnimation() : nullptr;
	return Animation ? Animation->GetPlayLength() : 0.f;
}

void AUnit::GetSkillAnimNotifyInfo(int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo)
{
	OutSkillAnimHitInfo.Empty();

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->GetSkillAnimNotifyInfo(OverrideFaction, InSkillType, OutSkillAnimHitInfo, bSkillAnimHasSequenceStart);
	}
}

void AUnit::SetSequenceAnimMode(bool bInSeqAnimMode)
{
	Super::SetSequenceAnimMode(bInSeqAnimMode);

	SetCCStateEffectsHidden(bSequenceAnimMode);

	if (!bSequenceAnimMode)
	{
		SetAnimRelaxed(bAnimRelaxed);
	}
}

void AUnit::LoadAnimations()
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		FAnimLoadingOption LoadingOption;
		LoadingOption.ModelType = ModelType;
		LoadingOption.bIsCharacter = (OverrideFaction == ECCFaction::Ally);
		LoadingOption.bInCombat = (GetCombatGameMode(this) != nullptr);
		AnimInstance->LoadAnimations(LoadingOption, true);
	}
}

void AUnit::SetAnimRelaxed(bool bRelaxed)
{
	bAnimRelaxed = bRelaxed;

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (!AnimInstance || !AnimInstance->SetRelaxed(bRelaxed))
	{
		if (bRelaxed)
		{
			OnAnimNotifyRelaxed();
		}
		else
		{
			OnAnimNotifyUnrelaxed();
		}
	}
}

void AUnit::SetAnimPaused(bool bInPaused)
{
	bAnimPaused = bInPaused;
	GetMesh()->bPauseAnims = bInPaused;
}

void AUnit::SetStunned(bool bInStunned)
{
	if (bAnimPaused)
	{
		return;
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetStunned(bInStunned);
	}
}

void AUnit::SetMoving(bool bInMoving)
{
	if (bAnimPaused)
	{
		return;
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetMoving(bInMoving);
	}
}

void AUnit::SetDead()
{
	if (bAnimPaused)
	{
		SetAnimPaused(false);
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	SetDeadInternal(AnimInstance);
}

void AUnit::SetDeadInternal(UUnitAnimInstanceBase* InAnimInstance)
{
	if (InAnimInstance)
	{
		InAnimInstance->SetDead(true);

		UAnimSequenceBase* DeadAnimation = InAnimInstance->GetDeadAnimation();
		const float DeadAnimationLength = DeadAnimation ? DeadAnimation->GetPlayLength() : 0.0f;
		GetWorldTimerManager().ClearTimer(DeadAnimTimerHandle);
		GetWorldTimerManager().SetTimer(DeadAnimTimerHandle, this, &AUnit::OnDeadAnimEnd, DeadAnimationLength);

		const float DeadEffectStartDelay = FMath::Max(0.0f, DeadAnimationLength * 0.5f);
		GetWorldTimerManager().ClearTimer(DeadEffectTimerHandle);
		GetWorldTimerManager().SetTimer(DeadEffectTimerHandle, this, &AUnit::OnDeadMaterialEffectStart, DeadEffectStartDelay);
	}
	else
	{
		StartDeadFX();
	}

	ClearCCStateEffect();
	ClearShadowDecal();
}

void AUnit::SetHit(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam)
{
	PlayHit();

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "SetHit SubMaterialEffect failed, no CombatGameResource");
	}
	else
	{
		const FSubMaterialEffectParams& HitEffectMaterialParams = CombatGameResource->GetHitEffectMaterialParams();
		SetSubMaterialEffect(HitEffectMaterialParams);
	}

	StartParticleEffects(ParticleParam, SoundParam);
}

void AUnit::SetShieldHit(bool bBroken)
{
	if (bBroken)
	{
		UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
		if (CombatGameResource == nullptr)
		{
			Q6JsonLogSunny(Warning, "SetShieldHit ShieldBrokenEffect failed, no CombatGameResource");
		}
		else
		{
			const FSpawnParticleParams& ParticleParams = CombatGameResource->GetShieldBrokenEffectParticleParams();

			FSpawnSoundParams SoundParams;
			SoundParams.Sound = CombatGameResource->GetShieldBrokenEffectSound();

			StartParticleEffects(ParticleParams, SoundParams);
		}
	}
	else
	{
		TArray<FBuffEffectState> ShieldEffectStates;
		GatherCCBuffEffects(ShieldEffectStates, ECrowdControl::Shield);
		if (ShieldEffectStates.Num())
		{
			StartBuffEffectFX(ShieldEffectStates[0].EffectType);
		}
	}
}

ESkillNote AUnit::GetSkillNote() const
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		return AnimInstance->GetSkillNote();
	}

	return ESkillNote::None;
}

void AUnit::SetSkillNote(ESkillNote InSkillNote)
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetSkillNote(InSkillNote);
	}
}

void AUnit::SetDoubleSkillFollowing(bool bIsFollowing)
{
	bSkipMoveBack = bIsFollowing;
}

void AUnit::SetUltimateSkillState(bool bIsOn)
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetUltimateSkill(bIsOn);
	}
}

void AUnit::SetTurnSkillIndex(int32 InIndex)
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		if (OverrideFaction == ECCFaction::Ally)
		{
			AnimInstance->SetTurnSkillIndex(InIndex);
		}
		else
		{
			AnimInstance->SetCombatTurnSkillIndex(InIndex);
		}
	}
}

void AUnit::PlayNormalSkill(const FVector& InTargetLocation, bool bIsDouble)
{
	if (bAnimPaused)
	{
		return;
	}

	UpdateTargetTransform(InTargetLocation, true);

	if (bIsDouble)
	{
		bSkipMoveBack = false;
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (!AnimInstance)
	{
		OnAnimNotifySkillEnd();
	}
	else
	{
		AnimInstance->SetDoubleSkill(bIsDouble);
		if (!AnimInstance->SetSkill(true))
		{
			OnAnimNotifySkillEnd();
		}
	}
}

void AUnit::PlayTurnSkill()
{
	if (bAnimPaused)
	{
		return;
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (!AnimInstance || !AnimInstance->SetTurnSkill(true))
	{
		OnAnimNotifyTurnSkillEnd();
	}
}

void AUnit::PlayShout()
{
	if (bAnimPaused)
	{
		return;
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (!AnimInstance || !AnimInstance->SetShout(true))
	{
		OnAnimNotifyShoutEnd();
	}
}

void AUnit::PlayHit()
{
	if (bAnimPaused)
	{
		return;
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetHit(true);
	}
}

void AUnit::RotateToTargetUnit(const AUnit* InTargetUnit)
{
	if (!bRotatable)
	{
		return;
	}

	if (bAnimPaused)
	{
		return;
	}

	if (!InTargetUnit)
	{
		TargetTransform.SetRotation(InitialTransform.GetRotation());
		RotateToTargetRotation();
	}
	else
	{
		FVector TargetLocation = InTargetUnit->GetActorLocation();
		RotateToLocation(TargetLocation);
	}
}

void AUnit::RotateToLocation(const FVector& InLocation)
{
	if (!bRotatable)
	{
		return;
	}

	FVector Location = GetActorLocation();
	FVector Dir = InLocation - Location;
	Dir.Z = 0.f;

	TargetTransform.SetRotation(Dir.Rotation().Quaternion());
	RotateToTargetRotation();
}

void AUnit::RotateToTargetRotation()
{
	if (GetActorRotation().Quaternion().Equals(TargetTransform.GetRotation()))
	{
		return;
	}

	RotateStartRotation = GetActorRotation().Quaternion();
	RotateStartTime = GetWorld()->GetTimeSeconds();

	bRotating = true;
}

void AUnit::UpdateRotationToEnd()
{
	if (bRotating)
	{
		SetActorRotation(TargetTransform.GetRotation());
		bRotating = false;
	}
}

void AUnit::TickRotation(float DeltaSeconds, FTransform& InOutCurTargetTransform)
{
	const float RotateDeltaTime = GetWorld()->GetTimeSeconds() - RotateStartTime;
	const float Alpha = FMath::Min(RotateDeltaTime / CVarUnitRotateTime.GetValueOnGameThread(), 1.0f);

	if (Alpha < 1.0f)
	{
		InOutCurTargetTransform.SetRotation(FMath::Lerp(RotateStartRotation, TargetTransform.GetRotation(), Alpha));
	}
	else
	{
		InOutCurTargetTransform.SetRotation(TargetTransform.GetRotation());
		bRotating = false;
	}
}

FVector AUnit::GetMoveTargetLocation(const AUnit* InTargetUnit) const
{
	FVector Location = GetActorLocation();
	FVector TargetLocation = InTargetUnit->GetActorLocation();

	FVector Dir = TargetLocation - Location;
	Dir.Z = 0.f;

	float Offset = InTargetUnit->GetBoundRadius() + BoundRadius;
	Offset = FMath::Max(Offset, CVarMoveToUnitDistOffset.GetValueOnGameThread());

	float Dist = FVector::DistXY(TargetLocation, Location);
	Dist -= Offset;

	Dir.Normalize();
	TargetLocation = Location + Dir * Dist;

	return TargetLocation;
}

void AUnit::MoveToWave(const FTransform& InWaveTransform)
{
	TargetTransform = InWaveTransform;
	FinalTargetTransform = InWaveTransform;
	InitialTransform = InWaveTransform;

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (!AnimInstance || !AnimInstance->SetMoving(true, true))
	{
		OnMoveEnd(true);
	}
}

void AUnit::MoveToTargetLocation()
{
	if (FVector::PointsAreNear(GetActorLocation(), TargetTransform.GetLocation(), 1.0f))
	{
		return;
	}

	MoveStartLocation = GetActorLocation();
	MoveStartTime = GetWorld()->GetTimeSeconds();

	bMoving = true;
}

void AUnit::OnMoveEnd(bool bSetActorTransform /* = false */)
{
	if (bSetActorTransform)
	{
		SetActorTransform(TargetTransform);
	}

	AnimMoveEndDelegate.ExecuteIfBound();
}

void AUnit::OnAnimNotifyMove(float DistanceLeft, bool bBackward, float TotalDuration)
{
	if (bMoving)
	{
		return;
	}

	FVector Location = GetActorLocation();
	FVector TargetLocation = bBackward ? InitialTransform.GetLocation() : FinalTargetTransform.GetLocation();

	if (!FMath::IsNearlyZero(DistanceLeft))
	{
		FVector Dir = FVector::PointsAreNear(TargetLocation, Location, 1.f) ? GetActorRotation().Vector() : TargetLocation - Location;
		Dir.Z = 0.f;
		Dir.Normalize();

		float Dist = FVector::DistXY(TargetLocation, Location);
		float MovingDist = Dist - DistanceLeft * 100.f;

		TargetLocation = Location + Dir * MovingDist;
	}
	UpdateTargetTransform(TargetLocation, false);

	UpdateMoveTime(TotalDuration);
	MoveToTargetLocation();
}

void AUnit::UpdateTargetTransform(const FVector& InLocation, bool bFinal)
{
	TargetTransform.SetLocation(InLocation);

	if (bFinal)
	{
		FinalTargetTransform = TargetTransform;
	}
}

void AUnit::UpdateMoveTime(float InMoveTime /* = 0.f */)
{
	if (InMoveTime > 0.f)
	{
		MoveTime = InMoveTime;
		return;
	}

	// Get move time from animation length
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		MoveTime = AnimInstance->GetCurrentAnimMoveTime();
	}
	else
	{
		MoveTime = 0.2f;
	}
}

void AUnit::TickMovement(float DeltaSeconds, FTransform& InOutCurTargetTransform)
{
	const float MoveDeltaTime = GetWorld()->GetTimeSeconds() - MoveStartTime;
	const float Alpha = FMath::Min(MoveDeltaTime / MoveTime, 1.0f);

	if (Alpha < 1.0f)
	{
		InOutCurTargetTransform.SetLocation(FMath::Lerp(MoveStartLocation, TargetTransform.GetLocation(), Alpha));
	}
	else
	{
		InOutCurTargetTransform.SetLocation(TargetTransform.GetLocation());
		bMoving = false;

		FVector TargetLocation = TargetTransform.GetLocation();
		FVector InitialLocation = InitialTransform.GetLocation();

		if (TargetLocation.Equals(InitialLocation))
		{
			SetMoving(false);
			OnMoveEnd();
		}
	}
}

void AUnit::OnAnimNotifyStartCameraSequence()
{
	NormalSkillSequencePlayDelegate.ExecuteIfBound(FinalTargetTransform);
}

void AUnit::OnAnimNotifySkillStart()
{
	if (!bSkipMoveBack)
	{
		SetMoving(true);
	}

	if (!bSkillAnimHasSequenceStart && !GetCombatPlayerController(this)->IsPlayingSequence())
	{
		NormalSkillSequencePlayDelegate.ExecuteIfBound(FinalTargetTransform);
	}
}

void AUnit::OnAnimNotifySkillEnd()
{
	if (bSkipMoveBack)
	{
		SetMoving(false);
		OnMoveEnd();
	}
	else
	{
		if (FVector::PointsAreNear(GetActorLocation(), InitialTransform.GetLocation(), 1.f))
		{
			SetMoving(false);
			OnMoveEnd();
		}
		else
		{
			UpdateTargetTransform(InitialTransform.GetLocation(), true);

			UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
			if (!AnimInstance || !AnimInstance->GetMoving())
			{
				OnMoveEnd(true);
			}
		}
	}

	AnimSkillEndDelegate.ExecuteIfBound();
}

void AUnit::OnAnimNotifyTurnSkillEnd()
{
	AnimTurnSkillEndDelegate.ExecuteIfBound();
}

void AUnit::OnAnimNotifyShoutEnd()
{
	AnimShoutEndDelegate.ExecuteIfBound();
}

void AUnit::OnAnimNotifyRunStart()
{
	ensure(!bMoving);

	UpdateMoveTime();
	MoveToTargetLocation();
}

void AUnit::OnAnimNotifyRelaxed()
{
	AnimRelaxedDelegate.ExecuteIfBound();
}

void AUnit::OnAnimNotifyUnrelaxed()
{
	AnimUnrelaxedDelegate.ExecuteIfBound();
}

void AUnit::OnAnimNotifyHit(const FSpawnParticleParams& ParticleParams, const FSpawnSoundParams& SoundParams)
{
	AnimHitDelegate.ExecuteIfBound(ParticleParams, SoundParams);
}

void AUnit::OnAnimNotifyFireProjectile(const FProjectileEffectDesc& Desc, const FSpawnParticleParams& ParticleParams, const FSpawnSoundParams& SoundParams)
{
	if (!Desc.Projectile.IsNull())
	{
		AnimFireProjectileDelegate.ExecuteIfBound(Desc, ParticleParams, SoundParams);
	}
}

void AUnit::OnAnimNotifyPlayBeamParticleEffect(const FBeamParticleEffectDesc& Desc, float TotalDuration)
{
	if (Desc.Particle)
	{
		AnimPlayBeamParticleEffectDelegate.ExecuteIfBound(Desc, TotalDuration);
	}
}

void AUnit::OnAnimNotifyPlayParticleEffectOnTarget(const FSpawnParticleParams& ParticleParams, const FSpawnSoundParams& SoundParams)
{
	AnimPlayParticleEffectOnTargetDelegate.ExecuteIfBound(ParticleParams, SoundParams);
}

void AUnit::OnAnimNotifySpawnSkeletalMesh(const FSpawnSkeletalMeshDesc& Desc, float Duration, bool bTarget)
{
	AnimNotifySpawnSkeletalMeshDelegate.ExecuteIfBound(Desc, Duration, bTarget);
}

void AUnit::InitMesh()
{
	Super::InitMesh();

	GetMesh()->SetRelativeLocation(FVector(0, 0, -GetCapsuleComponent()->GetScaledCapsuleHalfHeight() / FMath::Max(0.01f, GetRootComponent()->GetComponentScale().Z)));
	GetMesh()->UpdateBounds();

	InitDefaultMaterials();
	SetAnimRelaxed(bAnimRelaxed);

	const FUnitModelAssetRow& Row = GetGameResource().GetUnitModelAssetRow(ModelType);
	CommonEffectIndex = Row.CommonEffectIndex;
	bRotatable = Row.bRotatable;
}

void AUnit::ClearIntermediateState()
{
	if (GetMesh())
	{
		SetSequenceAnimMode(false);
	}

	ClearTransforms();
	ClearCCStateEffect();
	ClearMaterialEffect();

	GetWorldTimerManager().ClearTimer(SpawnEffectTimerHandle);
	SpawnEffectTimerHandle.Invalidate();

	GetWorldTimerManager().ClearTimer(DeadEffectTimerHandle);
	DeadEffectTimerHandle.Invalidate();
}

void AUnit::ClearTransforms()
{
	InitialTransform = BaseTransform;
	TargetTransform = BaseTransform;
	FinalTargetTransform = BaseTransform;
}

void AUnit::CreatePhysicsState()
{
	GetCapsuleComponent()->CreatePhysicsState();
}

void AUnit::DestroyPhysicsState()
{
	GetCapsuleComponent()->DestroyPhysicsState();
}

void AUnit::SetActorHiddenInGame(bool bNewHidden)
{
	Super::SetActorHiddenInGame(bNewHidden);

	if (bNewHidden)
	{
		DestroyPhysicsState();
	}
	else
	{
		CreatePhysicsState();
	}
}

void AUnit::OnSpawnMaterialEffectEnd()
{
	SpawnEffectTimerHandle.Invalidate();
	ClearMaterialEffect();

	SpawnEffectFinishedDelegate.ExecuteIfBound();
}

void AUnit::OnDeadMaterialEffectStart()
{
	DeadEffectTimerHandle.Invalidate();
	StartDeadFX();
}

void AUnit::OnDeadMaterialEffectEnd()
{
	DeadEffectTimerHandle.Invalidate();
	DisableUnit();
}

void AUnit::OnDeadAnimEnd()
{
	DeadAnimTimerHandle.Invalidate();
	DeadEffectFinishedDelegate.ExecuteIfBound();
}

void AUnit::InitDefaultMaterials()
{
	DefaultMeshMaterials.Empty();

	if (GetMesh() && GetMesh()->SkeletalMesh)
	{
		for (int i = 0; i < GetMesh()->SkeletalMesh->Materials.Num(); ++i)
		{
			if (GetMesh()->OverrideMaterials.IsValidIndex(i))
			{
				DefaultMeshMaterials.Add(GetMesh()->OverrideMaterials[i]);
				continue;
			}

			UMaterialInterface* Material = GetMesh()->SkeletalMesh->Materials[i].MaterialInterface;
			if (Material)
			{
				DefaultMeshMaterials.Add(Material);
			}
		}
	}
}

void AUnit::ClearMaterialEffect()
{
	for (int32 i = 0; i < (int32)EUnitMaterialEffectLayer::Max; ++i)
	{
		EffectMaterials[i] = nullptr;
	}

	ApplyMaterialEffect();
}

void AUnit::ApplyMaterialEffect()
{
	UMaterialInterface* EffectMaterial = nullptr;
	for (int32 i = 0; i < (int)EUnitMaterialEffectLayer::Max; ++i)
	{
		if (EffectMaterials[i] == nullptr)
		{
			continue;
		}

		EffectMaterial = EffectMaterials[i];
	}

	ApplyMaterialOverride(EffectMaterial);

	TickMaterialEffect(0);
}

void AUnit::ApplyMaterialOverride(UMaterialInterface* OverrideMaterial)
{
	int32 NumMaterials = DefaultMeshMaterials.Num();
	for (int32 i = 0; i < NumMaterials; ++i)
	{
		if (OverrideMaterial)
		{
			UMaterialInstanceDynamic* DynamicMaterial = GetMesh()->CreateDynamicMaterialInstance(i, OverrideMaterial);
			DynamicMaterial->K2_CopyMaterialInstanceParameters(OverrideMaterial);
		}
		else
		{
			UMaterialInterface* DefaultMaterial = DefaultMeshMaterials[i];
			GetMesh()->SetMaterial(i, DefaultMaterial);
		}
	}
}

static void _SetMaterialScalarParameter(USkeletalMeshComponent* Mesh, FName ParameterName, float ScalarValue)
{
	int32 NumMaterials = Mesh->GetNumMaterials();
	for (int32 Index = 0; Index < NumMaterials; ++Index)
	{
		UMaterialInstanceDynamic* Material = Cast<UMaterialInstanceDynamic>(Mesh->GetMaterial(Index));
		if (Material == nullptr)
		{
			continue;
		}

		Material->SetScalarParameterValue(ParameterName, ScalarValue);
	}
}

void AUnit::TickMaterialEffect(float DeltaSeconds)
{
	//SCOPE_CYCLE_COUNTER(STAT_TickMaterialEffect);

	//static_assert(UE_ARRAY_COUNT(EffectMaterials) == UE_ARRAY_COUNT(EffectMaterialAgeSeconds), "What's going on here");

	const static FName TimeName("Time");
	float Dummy;

	for (int32 Index = 0; Index < UE_ARRAY_COUNT(EffectMaterials); ++Index)
	{
		if (EffectMaterials[Index] == nullptr)
		{
			continue;
		}

		EffectMaterialAgeSeconds[Index] += DeltaSeconds;

		if (EffectMaterials[Index]->GetScalarParameterValue(TimeName, Dummy))
		{
			_SetMaterialScalarParameter(GetMesh(), TimeName, EffectMaterialAgeSeconds[Index]);
		}

		if (EffectMaterialDurationSeconds[Index] > 0 && EffectMaterialAgeSeconds[Index] > EffectMaterialDurationSeconds[Index])
		{
			SetMaterialEffect((EUnitMaterialEffectLayer)Index, nullptr);
		}
	}

	// sub material
	UMaterialInterface* SubMaterial = GetMesh()->GetSubMaterial();
	if (SubMaterial)
	{
		if (SubMaterial->GetScalarParameterValue(TimeName, Dummy))
		{
			UMaterialInstanceDynamic* SubMaterialDynamic = Cast<UMaterialInstanceDynamic>(SubMaterial);
			if (SubMaterialDynamic)
			{
				SubMaterialAgeSecond += DeltaSeconds;
				SubMaterialDynamic->SetScalarParameterValue(TimeName, SubMaterialAgeSecond);
			}
		}
	}
}

void AUnit::SetMaterialEffectBP(EUnitMaterialEffectLayer Layer, UMaterialInterface* Material, float InDuration /* = -1.0f */)
{
	SetMaterialEffect(Layer, Material, InDuration);
}

void AUnit::SetMaterialEffect(EUnitMaterialEffectLayer Layer, UMaterialInterface* Material, float Duration /* = -1.0f */)
{
	if (EffectMaterials[(int32)Layer] == Material)
	{
		return;
	}

	EffectMaterials[(int32)Layer] = Material;
	EffectMaterialAgeSeconds[(int32)Layer] = 0;
	EffectMaterialDurationSeconds[(int32)Layer] = Duration;

	ApplyMaterialEffect();
}

void AUnit::ClearSubMaterialEffect()
{
	GetMesh()->ClearSubMaterial();
}

void AUnit::SetSubMaterialEffect(const FSubMaterialEffectParams& SubMaterialParams, int32 Mask /* = -1 */)
{
	if (!SubMaterialParams.Material)
	{
		return;
	}

	SubMaterialAgeSecond = 0;

	UMaterialInstanceDynamic* DynamicMaterialInstance = UMaterialInstanceDynamic::Create(SubMaterialParams.Material, this, NAME_None);
	DynamicMaterialInstance->SetVectorParameterValue(FName(TEXT("RimColor")), SubMaterialParams.Color);

	DynamicMaterialInstance->SetScalarParameterValue(FName(TEXT("SubMaterialFalloff")), SubMaterialParams.SubMaterialFalloff);
	DynamicMaterialInstance->SetScalarParameterValue(FName(TEXT("SubMaterialWeight")), SubMaterialParams.SubMaterialWeight);

	GetMesh()->SetSubMaterialBP(DynamicMaterialInstance, SubMaterialParams.Duration, Mask);
}

void AUnit::StartSpawnFX(ESpawnReason InReason)
{
	GetWorldTimerManager().ClearTimer(SpawnEffectTimerHandle);
	GetWorldTimerManager().SetTimer(SpawnEffectTimerHandle, this, &AUnit::OnSpawnMaterialEffectEnd, CVarSpawnMaterialDuration.GetValueOnGameThread());

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StartSpawnFX failed, no CombatGameResource");
		return;
	}

	UMaterialInterface* SpawnEffectMaterial = CombatGameResource->GetSpawnEffectMaterial(InReason, CommonEffectIndex);
	if (SpawnEffectMaterial)
	{
		SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, SpawnEffectMaterial);
	}

	UParticleSystem* SpawnEffetParticle = CombatGameResource->GetSpawnEffectParticle(InReason, CommonEffectIndex);
	if (SpawnEffetParticle)
	{
		UGameplayStatics::SpawnEmitterAttached(SpawnEffetParticle, GetMesh(), NAME_None, FVector(ForceInit), FRotator::ZeroRotator);
	}

	USoundBase* SpawnEffectSound = CombatGameResource->GetSpawnEffectSound(InReason);
	if (SpawnEffectSound)
	{
		UGameplayStatics::PlaySound2D(this, SpawnEffectSound);
	}
}

void AUnit::StartDeadFX()
{
	GetWorldTimerManager().ClearTimer(DeadEffectTimerHandle);
	GetWorldTimerManager().SetTimer(DeadEffectTimerHandle, this, &AUnit::OnDeadMaterialEffectEnd, CVarDeadMaterialDuration.GetValueOnGameThread());

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StartDeadFX failed, no CombatGameResource");
		return;
	}

	UMaterialInterface* DeadEffectMaterial = CombatGameResource->GetDeadEffectMaterial(CommonEffectIndex);
	if (DeadEffectMaterial)
	{
		SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, DeadEffectMaterial);
	}

	UParticleSystem* DeadEffectParticle = CombatGameResource->GetDeadEffectParticle(CommonEffectIndex);
	if (DeadEffectParticle)
	{
		UWorld* const World = GetWorld();
		if (World)
		{
			FVector CenterSocketLocation = GetMesh()->GetSocketLocation(UnitSocket::Center);
			UGameplayStatics::SpawnEmitterAtLocation(World, DeadEffectParticle, CenterSocketLocation);
		}
	}

	USoundBase* DeadEffectSound = CombatGameResource->GetDeadEffectSound();
	if (DeadEffectSound)
	{
		UGameplayStatics::PlaySound2D(this, DeadEffectSound);
	}
}

UParticleSystemComponent* AUnit::SpawnParticle(const FSpawnParticleParams& ParticleParam)
{
	const FName Socket = ParticleParam.Socket;
	FName AttachPointName;
	if (GetMesh()->DoesSocketExist(Socket))
	{
		AttachPointName = Socket;
	}

	return SpawnParticleInternal(ParticleParam, AttachPointName);
}

UParticleSystemComponent* AUnit::SpawnParticleInternal(const FSpawnParticleParams& ParticleParam, FName AttachPointName)
{
	UParticleSystem* Particle = ParticleParam.Particle;
	if (!Particle)
	{
		return nullptr;
	}

	UParticleSystemComponent* PSC = nullptr;

	FVector Offset = ParticleParam.Offset;
	FVector Rotation = ParticleParam.Rotation;
	FVector Scale = ParticleParam.Scale;

	FRotator Rotator(Rotation.Y, Rotation.Z, Rotation.X);

	if (ParticleParam.bAbsoluteLocation)
	{
		if (ParticleParam.bAttachToUnit)
		{
			FTransform SocketCompTransform;
			if (ParticleParam.bUseNonAnimatedTransform && GetMesh()->SkeletalMesh)
			{
				SocketCompTransform = GetSocketComponentSpaceRefTransform(AttachPointName);
			}
			else
			{
				SocketCompTransform = GetMesh()->GetSocketTransform(AttachPointName, RTS_Component);
			}
			FVector SpawnLocation = SocketCompTransform.GetLocation() + Offset;
			FRotator SpawnRotator = ParticleParam.bAbsoluteRotation ? Rotator : SocketCompTransform.Rotator() + Rotator;
			PSC = UGameplayStatics::SpawnEmitterAttached(Particle, GetMesh(), NAME_None, SpawnLocation, SpawnRotator);
		}
		else
		{
			UWorld* const World = GetWorld();
			if (World)
			{
				FTransform SocketWorldTransform;
				if (ParticleParam.bUseNonAnimatedTransform && GetMesh()->SkeletalMesh)
				{
					FTransform SocketCompTransform = GetSocketComponentSpaceRefTransform(AttachPointName);
					SocketWorldTransform = SocketCompTransform * GetBottomTransform();
				}
				else
				{
					SocketWorldTransform = GetSocketTransform(AttachPointName);
				}
				SocketWorldTransform.SetScale3D(FVector(1.f));

				if (ParticleParam.bAbsoluteRotation)
				{
					// use unit quat instead of socket quat
					SocketWorldTransform.SetRotation(GetActorQuat());
				}

				const FTransform ComponentToWorld(Rotator, Offset);
				FTransform SpawnTransform;
				FTransform::Multiply(&SpawnTransform, &ComponentToWorld, &SocketWorldTransform);
				PSC = UGameplayStatics::SpawnEmitterAtLocation(World, Particle, SpawnTransform);
			}
		}
	}
	else
	{
		PSC = UGameplayStatics::SpawnEmitterAttached(Particle, GetMesh(), AttachPointName, Offset, Rotator);

		if (ParticleParam.bAbsoluteRotation && PSC)
		{
			PSC->SetUsingAbsoluteSocketRotation(true);
		}
	}

	if (PSC)
	{
		PSC->SetRelativeScale3D(Scale);
	}

	return PSC;
}

void AUnit::StartParticleEffects(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam)
{
	SpawnParticle(ParticleParam);
	GetSoundPlayer().PlayEffectSound(SoundParam);
}

void AUnit::StartBuffEffectFX(const FBuffType InBuffType)
{
	const UCMS* CMS = GetCMS();

	const TArray<const FCMSBuffEffectRow*> CCBuffEffectRows = CMS->GetBuffEffects(InBuffType, EBuffEffectCategory::ModifyCrowdControl);
	for (const FCMSBuffEffectRow* CCBuffEffectRow : CCBuffEffectRows)
	{
		StartCCFX(FCrowdControlType(CCBuffEffectRow->Param1));
	}

	const TArray<const FCMSBuffEffectRow*> UnitAttrBuffEffectRows = CMS->GetBuffEffects(InBuffType, EBuffEffectCategory::ModifyUnitAttribute);
	for (const FCMSBuffEffectRow* UnitAttrBuffEffectRow : UnitAttrBuffEffectRows)
	{
		StartUnitAttrFX(UnitAttrBuffEffectRow->Param2 < 0);
	}
}

void AUnit::StartBuffEffectFX(const FBuffEffectType InBuffEffectType)
{
	const FCMSBuffEffectRow& BuffEffectRow = GetCMS()->GetBuffEffectRowOrDummy(InBuffEffectType);
	if (BuffEffectRow.BuffEffectCategory == EBuffEffectCategory::ModifyCrowdControl)
	{
		StartCCFX(FCrowdControlType(BuffEffectRow.Param1));
	}

	// damage/heal buff do no use unit attr fx
}

void AUnit::StopBuffEffectFX(const FBuffType InBuffType)
{
	const TArray<const FCMSBuffEffectRow*> CCBuffEffectRows = GetCMS()->GetBuffEffects(InBuffType, EBuffEffectCategory::ModifyCrowdControl);
	for (const FCMSBuffEffectRow* CCBuffEffectRow : CCBuffEffectRows)
	{
		StopCCFX(FCrowdControlType(CCBuffEffectRow->Param1));
	}
}

void AUnit::StartCCFX(const FCrowdControlType InCCType)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StartCCFX failed, no CombatGameResource");
		return;
	}

	const FCrowdControlAssetRow& CCAssetRow = CombatGameResource->GetCrowdControlAssetRow(InCCType);

	if (CCAssetRow.UnitAction.bHit)
	{
		if (!HasCCBuffEffect(ECrowdControl::Invincible))
		{
			PlayHit();
		}
	}
	if (CCAssetRow.UnitAction.HitSubMaterialParam.IsValid())
	{
		SetSubMaterialEffect(CCAssetRow.UnitAction.HitSubMaterialParam);
	}
	if (CCAssetRow.UnitAction.HitParticleParam.IsValid())
	{
		StartParticleEffects(CCAssetRow.UnitAction.HitParticleParam, CCAssetRow.UnitAction.SoundParam);
	}

	if (CCAssetRow.UnitAction.bShout)
	{
		PlayShout();
	}
	if (CCAssetRow.UnitAction.bStun)
	{
		SetStunned(true);
	}
	if (CCAssetRow.UnitAction.bPause)
	{
		SetAnimPaused(true);
	}

	// state effect from here
	if (HasCCStateEffect(InCCType))
	{
		return;
	}

	int32 AddedIndex = CCStateEffects.AddDefaulted();
	FCCStateEffect& AddedCCStateEffect = CCStateEffects[AddedIndex];
	AddedCCStateEffect.CCType = InCCType;

	if (!CCAssetRow.UnitAction.StateMaterial.IsNull())
	{
		UMaterialInterface* StateMaterial = CCAssetRow.UnitAction.StateMaterial.LoadSynchronous();
		SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, StateMaterial);
		if (StateMaterial)
		{
			AddedCCStateEffect.CCStateMaterial = StateMaterial;
		}
	}
	if (CCAssetRow.UnitAction.StateParticleParam.IsValid())
	{
		UParticleSystemComponent* StatePSC = SpawnParticle(CCAssetRow.UnitAction.StateParticleParam);
		if (StatePSC)
		{
			if (IsAttached())
			{
				FVector OriginalScale = StatePSC->GetRelativeScale3D();
				FVector NewScale = OriginalScale * CVarCCStateParticleScaleMultiplier.GetValueOnGameThread();
				StatePSC->SetRelativeScale3D(NewScale);
			}

			AddedCCStateEffect.CCStateParticleComponent = StatePSC;
		}
	}

	if (AddedCCStateEffect.IsValid())
	{
		LastUpdatedCCStateEffectIndex = AddedIndex;
		LastCCStateUpdateTime = GetWorld()->GetTimeSeconds();
	}
	else
	{
		CCStateEffects.RemoveAtSwap(AddedIndex);
	}
}

void AUnit::StopCCFX(const FCrowdControlType InCCType)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StopCCFX failed, no CombatGameResource");
		return;
	}

	const FCrowdControlAssetRow& CCAssetRow = CombatGameResource->GetCrowdControlAssetRow(InCCType);
	if (CCAssetRow.UnitAction.bStun)
	{
		SetStunned(false);
	}
	if (CCAssetRow.UnitAction.bPause)
	{
		SetAnimPaused(false);
	}

	// state effect from here
	if (!HasCCStateEffect(InCCType))
	{
		return;
	}

	bool bIsLastCCStateMaterial = true;
	int32 RemoveIndex = INDEX_NONE;

	for (int32 i = 0; i < CCStateEffects.Num(); ++i)
	{
		if (CCStateEffects[i].CCType == InCCType)
		{
			CCStateEffects[i].SetEmpty();
			RemoveIndex = i;
		}

		if (CCStateEffects[i].CCStateMaterial)
		{
			bIsLastCCStateMaterial = false;
		}
	}

	if (bIsLastCCStateMaterial)
	{
		SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, nullptr);
	}

	if (CCStateEffects.IsValidIndex(RemoveIndex))
	{
		CCStateEffects.RemoveAt(RemoveIndex);
		LastUpdatedCCStateEffectIndex = INDEX_NONE;
	}
}

void AUnit::StartUnitAttrFX(bool bInDemerit)
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StartUnitAttrFX failed, no CombatGameResource");
		return;
	}

	const FSubMaterialEffectParams& BuffEffectMaterialParams = CombatGameResource->GetBuffEffectMaterialParams(bInDemerit);
	SetSubMaterialEffect(BuffEffectMaterialParams);

	const FSpawnParticleParams& BuffEffectParticleParams = CombatGameResource->GetBuffEffectParticleParams(bInDemerit);

	FSpawnSoundParams BuffEffectSoundParam;
	BuffEffectSoundParam.Sound = CombatGameResource->GetBuffEffectSound(bInDemerit);

	StartParticleEffects(BuffEffectParticleParams, BuffEffectSoundParam);
}

void AUnit::StartLootEffectFX()
{
	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (CombatGameResource == nullptr)
	{
		Q6JsonLogSunny(Warning, "StartLootEffectFX failed, no CombatGameResource");
		return;
	}

	const FSubMaterialEffectParams& LootEffectMaterialParams = CombatGameResource->GetLootEffectMaterialParams();
	SetSubMaterialEffect(LootEffectMaterialParams);

	const FSpawnParticleParams& ParticleParams = CombatGameResource->GetLootEffectParticleParams();

	FSpawnSoundParams SoundParams;
	SoundParams.Sound = CombatGameResource->GetLootEffectSound();

	StartParticleEffects(ParticleParams, SoundParams);
}

void AUnit::SetShadowDecalMode(ECCFaction Mode, bool bOn)
{
	check(static_cast<int32>(Mode) >= 0 && static_cast<int32>(Mode) < UE_ARRAY_COUNT(DecalMode));
	if (DecalMode[static_cast<int32>(Mode)] == bOn)
	{
		return;
	}

	DecalMode[(int32)Mode] = bOn;
	ApplyDecalMode();
}

void AUnit::ApplyDecalMode()
{
	bool bHide = false;

	float DecalScale = 1.f;
	if (IsBossMonsterCategory(UnitState.Category))
	{
		UGameResource& GameResource = GetGameResource();
		const FBossSettingAssetRow& BossSettingAssetRow = GameResource.GetBossSettingAssetRow(UnitState.UnitType);
		DecalScale = BossSettingAssetRow.DecalScale;
	}

	UCombatGameResource& CombatGameResource = GetCheckedCombatGameResource(this);

	if (DecalMode[(int32)ECCFaction::Ally])
	{
		const FDecalSpriteInfo& DecalInfo = CombatGameResource.GetUnitAllyDecalInfo();
		ensure(DecalInfo.PaperSprite);
		ShadowComponent->SetSprite(DecalInfo.PaperSprite);
		ShadowComponent->SetRelativeScale3D(FVector(DecalScale));
		ShadowComponent->SetRelativeLocation(DecalInfo.DecalOffset + FVector(0, 0, -GetCapsuleComponent()->GetScaledCapsuleHalfHeight()));
	}
	else if (DecalMode[(int32)ECCFaction::Enemy])
	{
		const FDecalSpriteInfo& DecalInfo = CombatGameResource.GetUnitEnemyDecalInfo();
		ensure(DecalInfo.PaperSprite);
		ShadowComponent->SetSprite(DecalInfo.PaperSprite);
		ShadowComponent->SetRelativeScale3D(FVector(DecalScale));
		ShadowComponent->SetRelativeLocation(DecalInfo.DecalOffset + FVector(0, 0, -GetCapsuleComponent()->GetScaledCapsuleHalfHeight()));
	}
	else
	{
		bHide = true;
	}
	ShadowComponent->SetVisibility(!bHide);
}

void AUnit::ClearShadowDecal()
{
	for (int32 Index = 0; Index < UE_ARRAY_COUNT(DecalMode); ++Index)
	{
		DecalMode[Index] = false;
	}

	ApplyDecalMode();
}

void FCCStateEffect::SetEmpty()
{
	CCStateMaterial = nullptr;
	if (CCStateParticleComponent)
	{
		CCStateParticleComponent->DeactivateSystem();
		CCStateParticleComponent = nullptr;
	}
}

void AUnit::ClearCCStateEffect()
{
	for (FCCStateEffect& CCStateEffect : CCStateEffects)
	{
		CCStateEffect.SetEmpty();
	}
	CCStateEffects.Empty();
}

bool AUnit::HasCCStateEffect(const FCrowdControlType InCCType) const
{
	for (const FCCStateEffect& CCStateEffect : CCStateEffects)
	{
		if (CCStateEffect.CCType == InCCType)
		{
			return true;
		}
	}

	return false;
}

int32 AUnit::GetNextCCStateIndex() const
{
	if (CCStateEffects.Num())
	{
		if (CCStateEffects.IsValidIndex(LastUpdatedCCStateEffectIndex + 1))
		{
			return LastUpdatedCCStateEffectIndex + 1;
		}

		return 0;
	}

	return INDEX_NONE;
}

void AUnit::SetCCStateEffectsHidden(bool bInHidden)
{
	bCCStateEffectsHidden = bInHidden;

	if (bInHidden)
	{
		if (CCStateEffects.IsValidIndex(LastUpdatedCCStateEffectIndex))
		{
			FCCStateEffect& CurCCStateEffect = CCStateEffects[LastUpdatedCCStateEffectIndex];
			if (CurCCStateEffect.HasMaterialEffect())
			{
				SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, nullptr);
			}
			if (CurCCStateEffect.HasParticleEffect())
			{
				CurCCStateEffect.CCStateParticleComponent->SetHiddenInGame(true);
			}

			LastUpdatedCCStateEffectIndex = INDEX_NONE;
		}
	}
}

void AUnit::UpdateCCStateEffectsScale(float InMultiplier)
{
	for (FCCStateEffect& CCStateEffect : CCStateEffects)
	{
		UParticleSystemComponent* StatePSC = CCStateEffect.CCStateParticleComponent;
		if (!StatePSC)
		{
			continue;
		}

		FVector OriginalScale = StatePSC->GetRelativeScale3D();
		FVector NewScale = OriginalScale * InMultiplier;
		StatePSC->SetRelativeScale3D(NewScale);
	}
}

void AUnit::TickCCStates(float DeltaSeconds)
{
	if (bCCStateEffectsHidden)
	{
		return;
	}

	float TimeNow = GetWorld()->GetTimeSeconds();
	if (TimeNow - LastCCStateUpdateTime < CVarCCStateInterval.GetValueOnGameThread())
	{
		return;
	}

	int32 NextCCStateIndex = GetNextCCStateIndex();
	if (NextCCStateIndex == INDEX_NONE || NextCCStateIndex == LastUpdatedCCStateEffectIndex)
	{
		return;
	}

	if (CCStateEffects.IsValidIndex(LastUpdatedCCStateEffectIndex))
	{
		FCCStateEffect& CurCCStateEffect = CCStateEffects[LastUpdatedCCStateEffectIndex];
		if (CurCCStateEffect.HasParticleEffect())
		{
			CurCCStateEffect.CCStateParticleComponent->SetHiddenInGame(true);
		}
	}

	FCCStateEffect& NextCCStateEffect = CCStateEffects[NextCCStateIndex];
	if (NextCCStateEffect.HasMaterialEffect())
	{
		SetMaterialEffect(EUnitMaterialEffectLayer::Overlay, NextCCStateEffect.CCStateMaterial);
	}
	if (NextCCStateEffect.HasParticleEffect())
	{
		NextCCStateEffect.CCStateParticleComponent->SetHiddenInGame(false);
	}

	LastUpdatedCCStateEffectIndex = NextCCStateIndex;
	LastCCStateUpdateTime = TimeNow;
}

void AUnit::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	TickCCStates(DeltaTime);
	TickMaterialEffect(DeltaTime);

	if (!bMoving && !bRotating)
	{
		return;
	}

	FTransform CurTargetTransform(GetActorTransform());
	if (bRotating)
	{
		TickRotation(DeltaTime, CurTargetTransform);
	}
	if (bMoving)
	{
		TickMovement(DeltaTime, CurTargetTransform);
	}

	SetActorTransform(CurTargetTransform);
}

void AUnit::TurnSkillOverrideMaterialParamters(bool bOverride)
{
	if (UUnitAnimInstance* AnimInstance = GetUnitAnimInstance())
	{
		for (auto& Override : AnimInstance->GetAttachmentMaterialOverride())
		{
			if (UMaterialInterface* Mat = GetMesh()->GetMaterial(Override.Slot))
			{
				if (bOverride)
				{
					UMaterialInstanceDynamic* DynamicMaterial = GetMesh()->CreateDynamicMaterialInstance(Override.Slot, Mat);
					DynamicMaterial->K2_CopyMaterialInstanceParameters(Mat);

					for (auto& param : Override.Params)
					{
						DynamicMaterial->SetScalarParameterValue(param.Name, param.Value);
					}
				}
				else
				{
					GetMesh()->SetMaterial(Override.Slot, nullptr);
				}
			}
		}
	}
}

void AUnit::SynchronizeUnitState()
{
	SortBuffsByDuration();

	// start buff effects fx all
	const UCMS* CMS = GetCMS();
	for (const FBuffState& BuffState : UnitState.Buffs)
	{
		StartBuffEffectFX((FBuffType)BuffState.BuffType);
	}
}
