// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "MainPartUnitAnimInstance.h"
#include "CMS/CMSTable.h"
#include "CMS_gen.h"
#include "Q6.h"
#include "Q6Enum.h"
#include "Q6Log.h"

UMainPartUnitAnimInstance::UMainPartUnitAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bSubPartDead(false)
{}

void UMainPartUnitAnimInstance::GatherAnimationPaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths)
{
	if (!InLoadingOption.bInCombat)
	{
		return;
	}

	int32 InModelType = InLoadingOption.ModelType;

	// main part required
	AddValidAnimation(InModelType, OutPaths, "CombatIdle", CombatIdleAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "NormalSkill", NormalSkillAnimInfo.SkillAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Damage", DamageAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Stun", StunAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Dead", DeadAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Shout", ShoutAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "CombatTurnSkill", CombatTurnSkillAnimation, true);

	// optional
	AddValidAnimation(InModelType, OutPaths, "MoveBack", MoveBackAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "NormalSkillMoveTo", NormalSkillAnimInfo.MoveToAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "NormalSkillMoveBack", NormalSkillAnimInfo.MoveBackAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "UltimateSkill", UltimateSkillAnimation, false);

	for (TSoftObjectPtr<UAnimSequenceBase> CombatTurnSkillAnimationVary : CombatTurnSkillAnimationVaries)
	{
		AddValidAnimation(InModelType, OutPaths, "CombatTurnSkill", CombatTurnSkillAnimationVary, false);
	}

	// sub part
	for (FSkillAnimInfo& SubPartNormalSkillAnimInfo : SubPartNormalSkillAnimInfos)
	{
		AddValidAnimation(InModelType, OutPaths, "SubPartNormalSkill", SubPartNormalSkillAnimInfo.SkillAnimation, true);
		AddValidAnimation(InModelType, OutPaths, "SubPartNormalSkillMoveTo", SubPartNormalSkillAnimInfo.MoveToAnimation, false);
		AddValidAnimation(InModelType, OutPaths, "SubPartNormalSkillMoveBack", SubPartNormalSkillAnimInfo.MoveBackAnimation, false);
	}
	for (TSoftObjectPtr<UAnimSequenceBase> SubPartUltimateSkillAnimation : SubPartUltimateSkillAnimations)
	{
		AddValidAnimation(InModelType, OutPaths, "SubPartUltimateSkill", SubPartUltimateSkillAnimation, false);
	}
	for (FCombatTurnSkillAnimationVaries& SubPartCombatTurnSkillAnimationVaries : SubPartsCombatTurnSkillAnimationVaries)
	{
		for (TSoftObjectPtr<UAnimSequenceBase> SubPartCombatTurnSkillAnimationVary : SubPartCombatTurnSkillAnimationVaries.CombatTurnSkillAnimationVaries)
		{
			AddValidAnimation(InModelType, OutPaths, "SubPartCombatTurnSkill", SubPartCombatTurnSkillAnimationVary, false);
		}
	}
	for (TSoftObjectPtr<UAnimSequenceBase> SubPartDeadAnimation : SubPartDeadAnimations)
	{
		AddValidAnimation(InModelType, OutPaths, "SubPartDead", SubPartDeadAnimation, false);
	}
	for (TSoftObjectPtr<UAnimSequenceBase> SubPartDamageAnimation : SubPartDamageAnimations)
	{
		AddValidAnimation(InModelType, OutPaths, "SubPartDamage", SubPartDamageAnimation, false);
	}
}

static const FMaterialSlotIndexes DummyMaterialSlotIndexes;

const FMaterialSlotIndexes& UMainPartUnitAnimInstance::GetSubPartMaterialSlotIndexes(int32 InSubPartIndex) const
{
	if (SubPartMaterialSlotIndexes.IsValidIndex(InSubPartIndex))
	{
		return SubPartMaterialSlotIndexes[InSubPartIndex];
	}

	return DummyMaterialSlotIndexes;
}

int32 UMainPartUnitAnimInstance::GetSubPartSubMaterialMask(int32 InSubPartIndex) const
{
	if (!SubPartSubMaterialSlotIndexes.IsValidIndex(InSubPartIndex))
	{
		return 0;
	}

	int32 Mask = 0;
	for (int32 MaterialSlotIndex : SubPartSubMaterialSlotIndexes[InSubPartIndex].MaterialSlotIndexes)
	{
		Mask |= 1 << MaterialSlotIndex;
	}

	return Mask;
}

void UMainPartUnitAnimInstance::GetSkillAnimNotifyInfo(ECCFaction InFaction, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart)
{
	if (InFaction == ECCFaction::Ally)
	{
		Q6JsonLogSunny(Warning, "Invalid faction for main part unit");
		return;
	}

	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(InSkillType);
	
	UAnimSequenceBase* AnimSequence = nullptr;
	switch (SkillRow.SkillCategory)
	{
		case ESkillCategory::Normal:
			CurNormalSkillAnimInfo = NormalSkillAnimInfo;
			AnimSequence = CurNormalSkillAnimInfo.SkillAnimation.Get();
			break;
		case ESkillCategory::Ultimate:
			AnimSequence = UltimateSkillAnimation.Get();
			break;
		case ESkillCategory::TurnBegin:
			AnimSequence = GetCombatTurnSkillAnimation();
			break;
		default:
			break;
	}

	if (AnimSequence == nullptr || !IsValidAnim(AnimSequence))
	{
		Q6JsonLogSunny(Warning, "Invalid Anim Sequence", Q6KV("SkillCategory", (uint8)SkillRow.SkillCategory));
		return;
	}

	GetSkillAnimNotifyInfoInternal(AnimSequence, OutSkillAnimHitInfo, bOutHasSequenceStart);
}

void UMainPartUnitAnimInstance::GetSubPartSkillAnimNotifyInfo(int32 InSubPartIndex, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(InSkillType);

	UAnimSequenceBase* AnimSequence = nullptr;
	switch (SkillRow.SkillCategory)
	{
		case ESkillCategory::Normal:
			if (SubPartNormalSkillAnimInfos.IsValidIndex(InSubPartIndex))
			{
				CurNormalSkillAnimInfo = SubPartNormalSkillAnimInfos[InSubPartIndex];
				AnimSequence = CurNormalSkillAnimInfo.SkillAnimation.Get();
			}
			break;
		case ESkillCategory::Ultimate:
			if (SubPartUltimateSkillAnimations.IsValidIndex(InSubPartIndex))
			{
				AnimSequence = SubPartUltimateSkillAnimations[InSubPartIndex].Get();
			}
			break;
		case ESkillCategory::TurnBegin:
			AnimSequence = GetCombatTurnSkillAnimation();
			break;
		default:
			break;
	}

	if (AnimSequence == nullptr || !IsValidAnim(AnimSequence))
	{
		Q6JsonLogSunny(Warning, "Invalid Anim Sequence", Q6KV("SkillCategory", (uint8)SkillRow.SkillCategory));
		return;
	}

	GetSkillAnimNotifyInfoInternal(AnimSequence, OutSkillAnimHitInfo, bOutHasSequenceStart);
}

void UMainPartUnitAnimInstance::SetSubPartCombatTurnSkillIndex(int32 InSubPartIndex, int32 InIndex)
{
	if (SubPartsCombatTurnSkillAnimationVaries.IsValidIndex(InSubPartIndex))
	{
		FCombatTurnSkillAnimationVaries& SubPartCombatTurnSkillAnimationVary = SubPartsCombatTurnSkillAnimationVaries[InSubPartIndex];
		if (SubPartCombatTurnSkillAnimationVary.CombatTurnSkillAnimationVaries.IsValidIndex(InIndex))
		{
			if (IsValidAnim(SubPartCombatTurnSkillAnimationVary.CombatTurnSkillAnimationVaries[InIndex]))
			{
				CurCombatTurnSkillAnimation = SubPartCombatTurnSkillAnimationVary.CombatTurnSkillAnimationVaries[InIndex];
				return;
			}
		}
	}

	CurCombatTurnSkillAnimation = CombatTurnSkillAnimation;
}

void UMainPartUnitAnimInstance::SetDead(bool bInDead)
{
	if (bInDead)
	{
		CurDeadAnimation = DeadAnimation.Get();
		if (!IsValidAnim(CurDeadAnimation))
		{
			return;
		}
	}

	bDead = bInDead;
}

void UMainPartUnitAnimInstance::SetSubPartDead(int32 InSubPartIndex, bool bInDead)
{
	if (bInDead)
	{
		CurDeadAnimation = GetSubPartDeadAnimation(InSubPartIndex);
		if (!IsValidAnim(CurDeadAnimation))
		{
			return;
		}
	}

	bSubPartDead = bInDead;
}

void UMainPartUnitAnimInstance::SetHit(bool bInHit)
{
	if (bDead)
	{
		return;
	}

	CurDamageAnimation = DamageAnimation.Get();
	if (!IsValidAnim(CurDamageAnimation))
	{
		return;
	}

	bHit = bInHit;
}

void UMainPartUnitAnimInstance::SetSubPartHit(int32 InSubPartIndex, bool bInHit)
{
	if (bDead)
	{
		return;
	}

	CurDamageAnimation = GetSubPartDamageAnimation(InSubPartIndex);
	if (!IsValidAnim(CurDamageAnimation))
	{
		return;
	}

	bHit = bInHit;
}

UAnimSequenceBase* UMainPartUnitAnimInstance::GetSubPartDeadAnimation(int32 InSubPartIndex) const
{
	if (!SubPartDeadAnimations.IsValidIndex(InSubPartIndex))
	{
		return nullptr;
	}

	return SubPartDeadAnimations[InSubPartIndex].Get();
}

UAnimSequenceBase* UMainPartUnitAnimInstance::GetSubPartDamageAnimation(int32 InSubPartIndex) const
{
	if (!SubPartDamageAnimations.IsValidIndex(InSubPartIndex))
	{
		return nullptr;
	}

	return SubPartDamageAnimations[InSubPartIndex].Get();
}
