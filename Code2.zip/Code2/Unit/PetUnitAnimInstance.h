// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6AnimInstance.h"
#include "PetUnitAnimInstance.generated.h"

class ULevelSequence;

/**
 * Pet Unit Anim Instance
 */
UCLASS()
class Q6_API UPetUnitAnimInstance : public UQ6AnimInstance
{
	GENERATED_BODY()
	
public:
	UPetUnitAnimInstance(const FObjectInitializer& ObjectInitializer);

	void SetSpawn(bool bInSpawn);

	UFUNCTION(BlueprintImplementableEvent)
	void SetRandomIdleTimer();

	UFUNCTION(BlueprintImplementableEvent)
	void ClearRandomIdleTimer();

	ULevelSequence* GetSkillSequence(int32 Index) const;

protected:
	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bSpawn;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bRandomIdle;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> IdleAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> RandomIdleAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> SpawnAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Level Sequence")
	TArray<TSoftObjectPtr<ULevelSequence>> SkillLevelSequences;

private:
	virtual void GatherAnimationPaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths) override;
	virtual void GatherLevelSequencePaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths) override;
};
