// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "PetUnitAnimInstance.h"
#include "LevelSequence.h"

UPetUnitAnimInstance::UPetUnitAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bSpawn(false)
{}

void UPetUnitAnimInstance::GatherAnimationPaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths)
{
	int32 InModelType = InLoadingOption.ModelType;
	AddValidAnimation(InModelType, OutPaths, "Idle", IdleAnimation, true);

	if (!InLoadingOption.bInCombat)
	{
		return;
	}

	AddValidAnimation(InModelType, OutPaths, "Spawn", SpawnAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "RandomIdle", RandomIdleAnimation, false);
}

void UPetUnitAnimInstance::GatherLevelSequencePaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths)
{
	if (!InLoadingOption.bInCombat)
	{
		return;
	}

	for (TSoftObjectPtr<ULevelSequence> SkillLevelSequence : SkillLevelSequences)
	{
		AddValidLevelSequence(InLoadingOption.ModelType, OutPaths, "Skill", SkillLevelSequence, true);
	}
}

void UPetUnitAnimInstance::SetSpawn(bool bInSpawn)
{
	bSpawn = bInSpawn;
}

ULevelSequence* UPetUnitAnimInstance::GetSkillSequence(int32 Index) const
{
	if (!SkillLevelSequences.IsValidIndex(Index))
	{
		return nullptr;
	}

	if (SkillLevelSequences[Index].IsNull())
	{
		return nullptr;
	}

	return SkillLevelSequences[Index].Get();
}
