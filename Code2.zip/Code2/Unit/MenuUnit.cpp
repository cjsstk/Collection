// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "MenuUnit.h"
#include "GameResource.h"
#include "LevelUtil.h"
#include "LobbyPlayerController.h"
#include "Q6.h"
#include "Q6Enum.h"
#include "Q6Log.h"
#include "CMSTable.h"
#include "Q6SoundPlayer.h"
#include "GameAssetCache.h"
#include "UnitAnimInstance.h"

AMenuUnit::AMenuUnit(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bUseControllerRotationPitch = false;
	bUseControllerRotationYaw = false;
	bUseControllerRotationRoll = false;

	SpringArm = ObjectInitializer.CreateDefaultSubobject<USpringArmComponent>(this, TEXT("CameraAttachmentArm"));
	SpringArm->SetWorldLocation(GetActorLocation());
	SpringArm->SetupAttachment(GetRootComponent());

	SpringArm->TargetArmLength = 200.f;
	SpringArm->bUsePawnControlRotation = false;
	SpringArm->bInheritPitch = false;
	SpringArm->bInheritYaw = false;
	SpringArm->bInheritRoll = false;
	SpringArm->bDoCollisionTest = false;
	SpringArm->ProbeSize = 10.f;
	SpringArm->bEnableCameraLag = true;
	SpringArm->CameraLagSpeed = 30.f;

	SpringArm->SetMobility(EComponentMobility::Movable);
	SpringArm->SetRelativeRotation(FRotator(0.f, -180.f, 0.f));
	SpringArm->SetRelativeLocation(FVector::ZeroVector);
	SpringArm->TargetOffset = GetMesh()->GetRelativeTransform().GetLocation();

	FaceFocusingOffset = FVector(0.f, 0.f, 150.f);
	BodyFocusingOffset = FVector(0.f, 0.f, 120.f);
	BottomFocusingOffset = FVector(0.f, 0.f, 30.f);

	ArmLengthMin = 100.f;
	ArmLengthMax = 300.f;

	CharacterType = CharacterTypeInvalid;
	HUDWidgetType = EHUDWidgetType::Invalid;

	bFullView = false;
	bBlackMaterial = false;
}

void AMenuUnit::InitCharacterUnit(FCharacterType InCharacterType, EHUDWidgetType InHUDWidgetType, bool bInOwned)
{
	CharacterType = InCharacterType;
	HUDWidgetType = InHUDWidgetType;
	bBlackMaterial = !bInOwned;

	DescType = GetCMS()->GetUnitType(InCharacterType);
	ModelType = GetCMS()->GetModelTypeFromUnitType(DescType);
	UnloadAsset();

	UnitInitParams = FUnitInitParams();
	if (UnitInitParams.bNeedAsset)
	{
		// Stream Assets
		FUnitAssetCacheOptions CacheOptions;
		CacheOptions.bBlocking = UnitInitParams.bBlockingLoad;
		CacheOptions.Priority = UnitInitParams.StreamingPriority;
		CacheOptions.bIncludeCombatPortraits = false;
		CacheOptions.bIncludeResultSequence = true;

		if (AssetCache)
		{
			AssetCache->CancelStreaming();
		}

		AssetCache = GetGameResource().GetCacheManager()->CacheUnit(DescType, CacheOptions,
			FGameAssetStreamDelegate::CreateUObject(this, &AMenuUnit::OnAssetStreamCompleted));

		if (AssetCache && !AssetCache->IsLoaded())
		{
			// Change to loading mesh
			if (GetGameResource().UnitLoadingMesh)
			{
				GetMesh()->SetSkeletalMesh(GetGameResource().UnitLoadingMesh);

				if (GetGameResource().UnitLoadingAnimation)
				{
					GetMesh()->PlayAnimation(GetGameResource().UnitLoadingAnimation, true);
				}
				GetMesh()->SetRelativeScale3D(FVector(1, 1, 1));
			}
		}
	}
}

bool AMenuUnit::IsLoaded() const
{
	return AssetCache && AssetCache->IsLoaded();
}

void AMenuUnit::InitMesh()
{
	const FUnitModelAssetRow& Row = GetGameResource().GetUnitModelAssetRow(ModelType);

	GetMesh()->SetAnimInstanceClass(nullptr);
	ULevelUtil::LoadSkeletalMesh(GetMesh(), Row, ModelType, true, !bBlackMaterial, true, !bBlackMaterial);
	GetMesh()->KinematicBonesUpdateType = EKinematicBonesUpdateToPhysics::SkipAllBones;

	InitMeshInternal(Row);

	GetMesh()->SetRelativeLocation(FVector(0, 0, -GetCapsuleComponent()->GetScaledCapsuleHalfHeight() / FMath::Max(0.01f, GetRootComponent()->GetComponentScale().Z)));
	GetMesh()->UpdateBounds();

	if (HUDWidgetType == EHUDWidgetType::Codex)
	{
		PostCodexUnitInitMesh();
	}

	UpdateAnimationImmediately();
	SetFullView(bFullView);
}

void AMenuUnit::PostCodexUnitInitMesh()
{
	if (bBlackMaterial)
	{
		GetLobbyPlayerController(this)->SetCodexCameraFocalRegion(true);
		SetBlackMaterial();
	}

	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetDialogueMode(true);
	}

	if (CodexAnimationHelper)
	{
		if (bBlackMaterial)
		{
			if (CodexAnimationHelper->IdleAnimations.Num())
			{
				PlayAnimAsMontage(CodexAnimationHelper->IdleAnimations[0], true, 0.f, 0.f);
			}
		}
		else
		{
			PlayAnimAsMontage(CodexAnimationHelper->WelcomeAnimation, false, 0.f, 0.25f);
		}
	}
}

void AMenuUnit::InitDefaultFocusing()
{
	if (!ModelType)
	{
		return;
	}

	const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(ModelType);

	FaceFocusingOffset = CharacterAssetRow.FaceFocusingOffset;
	BodyFocusingOffset = CharacterAssetRow.BodyFocusingOffset;
	BottomFocusingOffset = FVector(BodyFocusingOffset.X, BodyFocusingOffset.Y, BottomFocusingOffset.Z);

	ArmLengthMin = CharacterAssetRow.ZoomDistanceMin;
	ArmLengthMax = CharacterAssetRow.ZoomDistanceMax;

	RootComponent->SetRelativeRotation(FRotator::ZeroRotator);

	SpringArm->TargetArmLength = ArmLengthMax;
	SpringArm->SetRelativeLocation(BodyFocusingOffset);

	bFullView = true;
}

void AMenuUnit::ClearUnit()
{
	if (CodexAnimationHelper)
	{
		CodexAnimationHelper = nullptr;
	}

	DisableUnit();
}

void AMenuUnit::SetBlackMaterial()
{
	UMaterialInterface* BlackMaterial = GetGameResource().BlackMaterial.LoadSynchronous();
	if (!BlackMaterial)
	{
		return;
	}

	USkeletalMeshComponent* SkeletalMesh = GetMesh();
	if (!SkeletalMesh)
	{
		return;
	}

	const int32 MaterialNum = SkeletalMesh->GetNumMaterials();
	for (int32 MaterialIndex = 0; MaterialIndex < MaterialNum; ++MaterialIndex)
	{
		SkeletalMesh->SetMaterial(MaterialIndex, BlackMaterial);
	}
}

static float _InverseLerp(float A, float B, float Value)
{
	return ((Value - A) / (B - A));
}

FVector AMenuUnit::CalcOffsetFromArmLength() const
{
	float Ratio = _InverseLerp(ArmLengthMin, ArmLengthMax, SpringArm->TargetArmLength);
	return FMath::Lerp(FaceFocusingOffset, BodyFocusingOffset, Ratio);
}

void AMenuUnit::SetSpringArmOffset(const FVector& Offset, const FVector& Min, const FVector& Max)
{
	FVector Location = ClampVector(Offset, Min, Max);
	SpringArm->SetRelativeLocation(Location);
}

void AMenuUnit::AddTargetArmLength(float Length)
{
	float MovedArmLength = FMath::Clamp(SpringArm->TargetArmLength + Length, ArmLengthMin, ArmLengthMax);
	SpringArm->TargetArmLength = MovedArmLength;

	SetSpringArmOffset(CalcOffsetFromArmLength(), BodyFocusingOffset, FaceFocusingOffset);
}

void AMenuUnit::SetFullView(bool bInFullView)
{
	if (bInFullView)
	{
		SpringArm->SetRelativeLocation(BodyFocusingOffset);
		SetActorRotation(FRotator::ZeroRotator);
	}
	else
	{
		SpringArm->TargetArmLength = ArmLengthMax;

		float FullViewOffsetY = FMath::Max(BoundRadius / 2, 30.f);
		FVector FullViewOffset = FVector(BodyFocusingOffset.X, BodyFocusingOffset.Y + FullViewOffsetY, BodyFocusingOffset.Z);
		SpringArm->SetRelativeLocation(FullViewOffset);

		FVector Dir = FVector(SpringArm->TargetArmLength, BoundRadius, 0.f);
		Dir.Normalize();
		SetActorRotation(Dir.Rotation());
	}

	bFullView = bInFullView;
}

void AMenuUnit::RotateUnit(float ScrollVelocity)
{
	FRotator UnitRot = GetActorRotation();
	UnitRot.Yaw = FRotator::NormalizeAxis(UnitRot.Yaw - ScrollVelocity);
	SetActorRotation(UnitRot);
}

void AMenuUnit::InputDragged(const FVector2D& DeltaLocation, float ScrollVelocity)
{
	if (!IsInFullView() || IsBlack() || IsHidden())
	{
		return;
	}

	if ((SpringArm->TargetArmLength < ArmLengthMax) && (FMath::Abs(DeltaLocation.X) < FMath::Abs(DeltaLocation.Y)))
	{
		FVector Offset = SpringArm->GetRelativeLocation();
		Offset.Z += ScrollVelocity;
		SetSpringArmOffset(Offset, BottomFocusingOffset, FaceFocusingOffset);
	}
	else
	{
		RotateUnit(ScrollVelocity);
	}
}

UUnitAnimInstance* AMenuUnit::GetUnitAnimInstance() const
{
	UUnitAnimInstance* AnimInstance = Cast<UUnitAnimInstance>(GetMesh()->GetAnimInstance());
	return AnimInstance;
}

void AMenuUnit::LoadAnimations()
{
	if (HUDWidgetType == EHUDWidgetType::Codex)
	{
		if (CodexAnimationHelper)
		{
			CodexAnimationHelper = nullptr;
		}
		CodexAnimationHelper = NewObject<ULobbyAnimationHelper>();

		const FCharacterAssetRow& CharacterAssetRow = GetGameResource().GetCharacterAssetRow(CharacterType);
		FLobbyAnimationInfo AnimInfo = CharacterAssetRow.LobbyAnimationInfo;
		CodexAnimationHelper->InitAnimations(AnimInfo);
	}
	else
	{
		UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
		if (AnimInstance)
		{
			FAnimLoadingOption LoadingOption;
			LoadingOption.ModelType = ModelType;
			LoadingOption.bIsCharacter = true;
			LoadingOption.bInCombat = false;
			AnimInstance->LoadAnimations(LoadingOption, true);
		}
	}
}

bool AMenuUnit::PlayPreviewAnimation(ECharacterVoiceCategory InVoiceCategory)
{
	switch (InVoiceCategory)
	{
		case ECharacterVoiceCategory::TurnSkill1:
		case ECharacterVoiceCategory::TurnSkill2:
		case ECharacterVoiceCategory::TurnSkill3:
		case ECharacterVoiceCategory::NormalSkill:
		case ECharacterVoiceCategory::AceSkill:
		case ECharacterVoiceCategory::BreakSkill:
		case ECharacterVoiceCategory::CloserSkill:
		case ECharacterVoiceCategory::DoubleSkill:
		case ECharacterVoiceCategory::TurnSpawn:
		case ECharacterVoiceCategory::Dead:
		case ECharacterVoiceCategory::Hit:
			{
				UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
				if (AnimInstance && AnimInstance->SetPreview(InVoiceCategory))
				{
					return true;
				}
			}
			break;
		default:
			break;
	}

	OnAnimNotifyPlayVoice();

	return false;
}

void AMenuUnit::StopPreviewAnimation()
{
	UUnitAnimInstance* AnimInstance = GetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetPreview(ECharacterVoiceCategory::None);
	}
	else
	{
		OnAnimNotifyPreviewAnimEnd();
	}
}

void AMenuUnit::OnAnimNotifyPlayVoice()
{
	if (VoiceSound)
	{
		GetSoundPlayer().PlayCharacterVoice(VoiceSound);
		VoiceSound = nullptr;
	}
}

void AMenuUnit::OnAnimNotifyPreviewAnimEnd()
{
	OnPreviewAnimEndDelegate.ExecuteIfBound();
}

void AMenuUnit::OnTouched()
{
	if (!GetMesh() || IsHidden())
	{
		return;
	}

	if (HUDWidgetType != EHUDWidgetType::Codex || bBlackMaterial)
	{
		return;
	}

	if (!CodexAnimationHelper || CodexAnimationHelper->bPlayingOneShotAnim || !CodexAnimationHelper->InteractionAnimations.Num())
	{
		return;
	}

	PlayAnimAsMontage(GetRandomElement(CodexAnimationHelper->InteractionAnimations), false, 0.f, 0.25f);
}

void AMenuUnit::PlayAnimAsMontage(UAnimSequenceBase* Anim, bool bLoop, float BlendInTime /* = 0.f */, float BlendOutTime /* = 0.f */)
{
	if (!CodexAnimationHelper)
	{
		return;
	}

	FOnMontageBlendingOutStarted Delegate;
	Delegate.BindUObject(this, &AMenuUnit::OnMontageBlendingOut);

	UUnitAnimInstance* AnimInst = GetUnitAnimInstance();
	CodexAnimationHelper->PlayAnimAsMontage(AnimInst, Anim, Delegate, bLoop, BlendInTime, BlendOutTime);
}

void AMenuUnit::OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted)
{
	if (!CodexAnimationHelper)
	{
		return;
	}

	UUnitAnimInstance* AnimInst = GetUnitAnimInstance();
	CodexAnimationHelper->OnMontageBlendingOut(AnimInst, Montage, bInterrupted);
}
