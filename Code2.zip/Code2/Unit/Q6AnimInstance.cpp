// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "Q6AnimInstance.h"
#include "GameAssetCache.h"
#include "GameResource.h"
#include "Q6Log.h"

UQ6AnimInstance::UQ6AnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bDialogueMode(false)
{}

void UQ6AnimInstance::LoadAnimations(const FAnimLoadingOption& InLoadingOption, bool bInBlockingLoad)
{
	TArray<FSoftObjectPath> AnimationPaths;
	GatherAnimationPaths(InLoadingOption, AnimationPaths);

	FAssetCacheOptions CacheOptions;
	CacheOptions.bBlocking = bInBlockingLoad;
	CacheOptions.Priority = 0;

	if (AnimationAssetCache)
	{
		AnimationAssetCache->CancelStreaming();
	}

	AnimationAssetCache = GetGameResource().GetCacheManager()->CacheAnimations(InLoadingOption.ModelType, AnimationPaths, CacheOptions, FGameAssetStreamDelegate());
}

void UQ6AnimInstance::LoadLevelSequences(const FAnimLoadingOption& InLoadingOption, bool bInBlockingLoad)
{
	TArray<FSoftObjectPath> LevelSequencePaths;
	GatherLevelSequencePaths(InLoadingOption, LevelSequencePaths);

	FAssetCacheOptions CacheOptions;
	CacheOptions.bBlocking = bInBlockingLoad;
	CacheOptions.Priority = 0;

	if (LevelSequenceAssetCache)
	{
		LevelSequenceAssetCache->CancelStreaming();
	}

	LevelSequenceAssetCache = GetGameResource().GetCacheManager()->CacheSkillSequences(InLoadingOption.ModelType, LevelSequencePaths, CacheOptions, FGameAssetStreamDelegate());
}

void UQ6AnimInstance::AddValidAnimation(int32 InModelType, TArray<FSoftObjectPath>& OutPaths, const FString& InLogName, const TSoftObjectPtr<UAnimSequenceBase>& InAnimToAdd, bool bInAddMissingLog)
{
	if (InAnimToAdd.IsNull())
	{
		if (bInAddMissingLog)
		{
			Q6JsonLogBro(Error, "Animation Missing", Q6KV("ModelType", InModelType), Q6KV("AnimName", *InLogName));
		}
		return;
	}

	OutPaths.AddUnique(InAnimToAdd.GetUniqueID());
}

void UQ6AnimInstance::AddValidLevelSequence(int32 InModelType, TArray<FSoftObjectPath>& OutPaths, const FString& InLogName, const TSoftObjectPtr<ULevelSequence>& InSequenceToAdd, bool bInAddMissingLog)
{
	if (InSequenceToAdd.IsNull())
	{
		if (bInAddMissingLog)
		{
			Q6JsonLogSunny(Error, "LevelSequence Missing", Q6KV("ModelType", InModelType), Q6KV("LevelSequenceName", *InLogName));
		}
		return;
	}

	OutPaths.AddUnique(InSequenceToAdd.GetUniqueID());
}

bool UQ6AnimInstance::IsValidAnim(const TSoftObjectPtr<UAnimSequenceBase>& InAnim) const
{
	if (InAnim.IsNull())
	{
		return false;
	}

	UAnimSequenceBase* AnimSequence = InAnim.Get();
	if (!AnimSequence)
	{
		return false;
	}

	return CurrentSkeleton->IsCompatible(AnimSequence->GetSkeleton());
}

UAnimMontage* UQ6AnimInstance::PlaySlotAnimAsMontage(UAnimSequenceBase* Asset, FName SlotName, bool bStopAllMontages, float BlendInTime /* = 0.f */, float BlendOutTime /* = 0.f */)
{
	if (!Asset || !CurrentSkeleton->IsCompatible(Asset->GetSkeleton()))
	{
		return nullptr;
	}

	const float PlayRate = 1.0f;
	const float TimeToStartMontageAt = 0.0f;
	const float BlendOutTriggerTime = 0.0f;

	UAnimMontage* NewMontage = UAnimMontage::CreateSlotAnimationAsDynamicMontage(Asset, SlotName, BlendInTime, BlendOutTime, PlayRate, 1, BlendOutTriggerTime, TimeToStartMontageAt);
	if (NewMontage)
	{
		float PlayTime = Montage_Play(NewMontage, PlayRate, EMontagePlayReturnType::MontageLength, TimeToStartMontageAt, bStopAllMontages);
		return PlayTime > 0.0f ? NewMontage : nullptr;
	}

	return nullptr;
}
