// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "PetUnit.h"
#include "GameAssetCache.h"
#include "GameResource.h"
#include "PetUnitAnimInstance.h"

APetUnit::APetUnit(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	PrimaryActorTick.bCanEverTick = true;
}

void APetUnit::InitPetUnit(FPetType InPetType, FUnitInitParams InInitParams /* = FUnitInitParams() */)
{
	const FPetAssetRow& PetAssetRow = GetGameResource().GetPetAssetRow(InPetType);
	ModelType = PetAssetRow.ModelType;

	UnitInitParams = InInitParams;

	if (UnitInitParams.bNeedAsset)
	{
		// Stream Assets
		FUnitAssetCacheOptions CacheOptions;
		CacheOptions.bBlocking = UnitInitParams.bBlockingLoad;
		CacheOptions.Priority = UnitInitParams.StreamingPriority;

		if (AssetCache)
		{
			AssetCache->CancelStreaming();
		}

		AssetCache = GetGameResource().GetCacheManager()->CachePetUnit(InPetType, CacheOptions,
			FGameAssetStreamDelegate::CreateUObject(this, &APetUnit::OnAssetStreamCompleted));
	}
}

UPetUnitAnimInstance* APetUnit::GetPetUnitAnimInstance() const
{
	UPetUnitAnimInstance* AnimInstance = Cast<UPetUnitAnimInstance>(GetMesh()->GetAnimInstance());
	return AnimInstance;
}

void APetUnit::LoadAnimations()
{
	UPetUnitAnimInstance* AnimInstance = GetPetUnitAnimInstance();
	if (AnimInstance)
	{
		FAnimLoadingOption LoadingOption;
		LoadingOption.ModelType = ModelType;
		LoadingOption.bIsCharacter = false;
		LoadingOption.bInCombat = (GetCombatGameMode(this) != nullptr);
		AnimInstance->LoadAnimations(LoadingOption, true);
	}
}

void APetUnit::LoadSkillSequences()
{
	UPetUnitAnimInstance* AnimInstance = GetPetUnitAnimInstance();
	if (AnimInstance)
	{
		FAnimLoadingOption LoadingOption;
		LoadingOption.ModelType = ModelType;
		LoadingOption.bIsCharacter = false;
		LoadingOption.bInCombat = (GetCombatGameMode(this) != nullptr);
		AnimInstance->LoadLevelSequences(LoadingOption, true);
	}
}

void APetUnit::PlaySpawnAnimation()
{
	UPetUnitAnimInstance* AnimInstance = GetPetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetSpawn(true);
	}
}

void APetUnit::SetRandomIdleAnimTimer()
{
	UPetUnitAnimInstance* AnimInstance = GetPetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->SetRandomIdleTimer();
	}
}

void APetUnit::ClearRandomIdleAnimTimer()
{
	UPetUnitAnimInstance* AnimInstance = GetPetUnitAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->ClearRandomIdleTimer();
	}
}

ULevelSequence* APetUnit::GetSkillSequence(int32 Index) const
{
	UPetUnitAnimInstance* AnimInstance = GetPetUnitAnimInstance();
	if (AnimInstance)
	{
		return AnimInstance->GetSkillSequence(Index);
	}

	return nullptr;
}