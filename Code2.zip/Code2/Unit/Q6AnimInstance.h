// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Animation/AnimInstance.h"
#include "Q6AnimInstance.generated.h"

class UGameAssetCache;
class ULevelSequence;

USTRUCT()
struct FAnimLoadingOption
{
	GENERATED_BODY()

	UPROPERTY()
	int32 ModelType;

	UPROPERTY()
	bool bIsCharacter;

	UPROPERTY()
	bool bInCombat;
};

/**
 * Q6 Anim Instance
 */
UCLASS()
class Q6_API UQ6AnimInstance : public UAnimInstance
{
	GENERATED_BODY()

public:
	UQ6AnimInstance(const FObjectInitializer& ObjectInitializer);

	void LoadAnimations(const FAnimLoadingOption& InLoadingOption, bool bInBlockingLoad);
	void LoadLevelSequences(const FAnimLoadingOption& InLoadingOption, bool bInBlockingLoad);

	void SetDialogueMode(bool bEnable) { bDialogueMode = bEnable; }
	UAnimMontage* PlaySlotAnimAsMontage(UAnimSequenceBase* Asset, FName SlotName, bool bStopAllMontages, float BlendInTime = 0.f, float BlendOutTime = 0.f);

	virtual bool SetRelaxed(bool bInRelaxed) { return true; }

protected:
	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "Dialogue State Flag")
	bool bDialogueMode;

	virtual void GatherAnimationPaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths) {}
	void AddValidAnimation(int32 InModelType, TArray<FSoftObjectPath>& OutPaths, const FString& InLogName, const TSoftObjectPtr<UAnimSequenceBase>& InAnimToAdd, bool bInAddMissingLog);

	virtual void GatherLevelSequencePaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths) {}
	void AddValidLevelSequence(int32 InModelType, TArray<FSoftObjectPath>& OutPaths, const FString& InLogName, const TSoftObjectPtr<ULevelSequence>& InSequenceToAdd, bool bInAddMissingLog);

	bool IsValidAnim(const TSoftObjectPtr<UAnimSequenceBase>& InAnim) const;

private:
	UPROPERTY(Transient)
	UGameAssetCache* AnimationAssetCache;

	UPROPERTY(Transient)
	UGameAssetCache* LevelSequenceAssetCache;
};
