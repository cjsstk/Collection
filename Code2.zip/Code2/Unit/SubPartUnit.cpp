// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "SubPartUnit.h"
#include "CombatPresenter.h"
#include "GameResource.h"
#include "MainPartUnit.h"
#include "Q6.h"

ASubPartUnit::ASubPartUnit(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, MainPartUnitId(CCUnitIdInvalid)
	, SubPartIndex(INDEX_NONE)
{}

void ASubPartUnit::InitFromUnitState(const FUnitState& InUnitState, bool bInAnimRelaxed, bool bBlockingLoad /* = false */)
{
	UnitInitParams.bNeedAsset = false;

	Super::InitFromUnitState(InUnitState, bInAnimRelaxed, bBlockingLoad);
}

AUnit* ASubPartUnit::GetSourceUnit() const
{
	return GetCheckedCombatPresenter(this)->FindUnit(MainPartUnitId);
}

AMainPartUnit* ASubPartUnit::GetMainPartUnit() const
{
	return Cast<AMainPartUnit>(GetSourceUnit());
}

FTransform ASubPartUnit::GetSocketTransform(const FName Socket) const
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		const FName SubPartSocket = FName(*FString::Printf(TEXT("%s%d"), *Socket.ToString(), SubPartIndex));
		return MainPartUnit->GetSocketTransform(SubPartSocket);
	}

	return GetBottomTransform();
}

void ASubPartUnit::InitFromDesc()
{
	Super::InitFromDesc();

	// SubPartUnit CMS data has part numbering (1-based)
	SubPartIndex = ModelType - 1;
}

const FUltimateSkillSequenceAssetRow& ASubPartUnit::GetUltimateSkillSequenceAssetRow(int32 InSkillType, bool bInAddMissingLog /* = true */) const
{
	return GetGameResource().GetSkillUltimateSkillSequenceAssetRow(InSkillType, bInAddMissingLog);
}

float ASubPartUnit::GetTurnSkillAnimLength() const
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		return MainPartUnit->GetTurnSkillAnimLength();
	}

	return 0.f;
}

float ASubPartUnit::GetDeadAnimLength() const
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		return MainPartUnit->GetSubPartDeadAnimLength(SubPartIndex);
	}
	
	return 0.f;
}

void ASubPartUnit::GetSkillAnimNotifyInfo(int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->GetSubPartSkillAnimNotifyInfo(SubPartIndex, InSkillType, OutSkillAnimHitInfo, bSkillAnimHasSequenceStart);
	}
}

void ASubPartUnit::StartSpawnFX(ESpawnReason InReason)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->SetSubPartSpawn(SubPartIndex, InReason);
	}
}

void ASubPartUnit::SetDead()
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->SetSubPartDead(SubPartIndex);
	}

	ClearCCStateEffect();
	ClearShadowDecal();
}

void ASubPartUnit::SetHit(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->SetSubPartHit(SubPartIndex, ParticleParam, SoundParam);
	}
}

void ASubPartUnit::SetShieldHit(bool bBroken)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->SetSubPartShieldHit(SubPartIndex, bBroken);
	}
}

void ASubPartUnit::SetUltimateSkillState(bool bIsOn)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->SetUltimateSkillState(bIsOn);
	}
}

void ASubPartUnit::SetTurnSkillIndex(int32 InIndex)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->SetSubPartTurnSkillIndex(SubPartIndex, InIndex);
	}
}

void ASubPartUnit::PlayNormalSkill(const FVector& InTargetLocation, bool bIsDouble)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->PlayNormalSkill(InTargetLocation, bIsDouble);
	}
}

void ASubPartUnit::PlayTurnSkill()
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->PlayTurnSkill();
	}
}

void ASubPartUnit::SetSubMaterialEffect(const FSubMaterialEffectParams& SubMaterialParams, int32 Mask /* = -1 */)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		MainPartUnit->SetSubPartSubMaterialEffect(SubPartIndex, SubMaterialParams);
	}
}

UParticleSystemComponent* ASubPartUnit::SpawnParticle(const FSpawnParticleParams& ParticleParam)
{
	AMainPartUnit* MainPartUnit = GetMainPartUnit();
	if (MainPartUnit)
	{
		const FName Socket = FName(*FString::Printf(TEXT("%s%d"), *ParticleParam.Socket.ToString(), SubPartIndex));
		FName AttachPointName;
		if (MainPartUnit->GetMesh()->DoesSocketExist(Socket))
		{
			AttachPointName = Socket;
		}

		return MainPartUnit->SpawnParticleInternal(ParticleParam, AttachPointName);
	}

	return SpawnParticleInternal(ParticleParam, NAME_None);
}
