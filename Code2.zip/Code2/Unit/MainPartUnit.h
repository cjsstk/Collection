// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Unit/Unit.h"
#include "MainPartUnit.generated.h"

class UMainPartUnitAnimInstance;

struct FMaterialSlotIndexes;

enum class ECCFaction : uint8;

/**
 * Main Part Unit
 */
UCLASS()
class Q6_API AMainPartUnit : public AUnit
{
	GENERATED_BODY()
	
public:
	AMainPartUnit(const FObjectInitializer& ObjectInitializer);

	void AddSubPartUnitId(FCCUnitId InUnitId) { SubPartUnitIds.Add(InUnitId); }

	virtual float GetTurnSkillAnimLength() const override;
	virtual float GetDeadAnimLength() const override;
	float GetSubPartDeadAnimLength(int32 InSubPartIndex) const;

	virtual void GetSkillAnimNotifyInfo(int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo) override;
	void GetSubPartSkillAnimNotifyInfo(int32 InSubPartIndex, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart);

	virtual void SetStunned(bool bInStunned) override;
	virtual void SetMoving(bool bInMoving) override;
	virtual void SetDead() override;
	void SetSubPartSpawn(int32 InSubPartIndex, ESpawnReason InReason);
	void SetSubPartDead(int32 InSubPartIndex);
	void SetSubPartHit(int32 InSubPartIndex, const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam);
	virtual void SetShieldHit(bool bBroken) override;
	void SetSubPartShieldHit(int32 InSubPartIndex, bool bBroken);

	virtual void SetUltimateSkillState(bool bIsOn) override;
	virtual void SetTurnSkillIndex(int32 InIndex) override;
	void SetSubPartTurnSkillIndex(int32 InSubPartIndex, int32 InIndex);

	virtual void PlayNormalSkill(const FVector& InTargetLocation, bool bIsDouble) override;
	virtual void PlayTurnSkill() override;
	virtual void PlayShout() override;
	virtual void PlayHit() override;
	void PlaySubPartHit(int32 InSubPartIndex);

	void SetSubPartSubMaterialEffect(int32 InSubPartIndex, const FSubMaterialEffectParams& SubMaterialParams);

private:
	UMainPartUnitAnimInstance* GetMainPartUnitAnimInstance() const;

	virtual void InitMesh() override;

	virtual void LoadAnimations() override;
	virtual void LoadSkillSequences() override {};

	void EnableSubPart(int32 InSubPartIndex);
	void DisableSubPart(int32 InSubPartIndex);

	virtual void ApplyMaterialOverride(UMaterialInterface* OverrideMaterial) override;
	void ApplySubPartMaterialOverride(const FMaterialSlotIndexes& ApplyMaterialSlotIndexes, UMaterialInterface* OverrideMaterial);
	void ApplySubPartMaterialEffect(int32 InSubPartIndex);
	void SetSubPartMaterialEffect(int32 InSubPartIndex, EUnitMaterialEffectLayer Layer, UMaterialInterface* Material, float Duration = -1.0f);

	void StartSubPartSpawnFX(int32 InSubPartIndex, ESpawnReason InReason);
	void StartSubPartDeadFX(int32 InSubPartIndex);

	void OnSubPartDeadMaterialEffectStart();
	void OnSubPartDeadMaterialEffectEnd();

	TArray<FCCUnitId> SubPartUnitIds;

	TArray<int32> ActiveSubPartIndexes;
	int32 CurSubPartIndex;
};
