// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6AnimInstance.h"
#include "UnitAnimInstance.generated.h"

struct FSkillAnimHitInfo;

enum class ESkillCategory : uint8;
enum class ESkillNote : uint8;
enum class ECCFaction : uint8;
enum class ECharacterVoiceCategory : uint8;

USTRUCT(BlueprintType)
struct FSkillAnimInfo
{
	GENERATED_BODY()

	FSkillAnimInfo()
		: MoveToAnimation(nullptr)
		, SkillAnimation(nullptr)
		, MoveBackAnimation(nullptr)
	{}

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	TSoftObjectPtr<UAnimSequenceBase> MoveToAnimation;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	TSoftObjectPtr<UAnimSequenceBase> SkillAnimation;

	UPROPERTY(BlueprintReadOnly, EditAnywhere)
	TSoftObjectPtr<UAnimSequenceBase> MoveBackAnimation;
};

USTRUCT(BlueprintType)
struct FMaterialScalarParameterOverride
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	FName Name;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	float Value;
};

USTRUCT(BlueprintType)
struct FQ6MaterialSlotOverride
{
	GENERATED_USTRUCT_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 Slot;

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	TArray<FMaterialScalarParameterOverride> Params;
};

/**
 * Unit Anim Instance Base
 */

UCLASS()
class Q6_API UUnitAnimInstanceBase : public UQ6AnimInstance
{
	GENERATED_BODY()

public:
	UUnitAnimInstanceBase(const FObjectInitializer& ObjectInitializer);

	virtual void NativeInitializeAnimation() override;

	virtual float GetCurrentAnimMoveTime();
	virtual void GetSkillAnimNotifyInfo(ECCFaction InFaction, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart) {}

	void SetUltimateSkill(bool bInUltimateSkill);
	void SetCombatTurnSkillIndex(int32 InCombatTurnSkillIndex);

	bool GetMoving() const { return bMoving; }
	bool SetMoving(bool bInMoving);

	virtual void SetDead(bool bInDead);
	virtual void SetHit(bool bInHit);
	void SetStunned(bool bInStunned);
	bool SetShout(bool bInShout);

	virtual bool SetSkill(bool bInSkill);
	virtual bool SetTurnSkill(bool bInTurnSkill);

	UAnimSequenceBase* GetCombatTurnSkillAnimation() const { return CurCombatTurnSkillAnimation.Get(); }
	UAnimSequenceBase* GetDeadAnimation() const { return DeadAnimation.Get(); }

protected:
	void GatherLevelSequencePaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths) override {}
	void GetSkillAnimNotifyInfoInternal(const UAnimSequenceBase* InAnimSequence, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart) const;

	UPROPERTY(BlueprintReadOnly, EditInstanceOnly, Category = "State Flag")
	bool bDead;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bHit;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bStunned;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bSkipMoveToState;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bMoving;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bUltimateSkill;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bSkill;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bTurnSkill;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bShout;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> CombatIdleAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	FSkillAnimInfo NormalSkillAnimInfo;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TSoftObjectPtr<UAnimSequenceBase> UltimateSkillAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TSoftObjectPtr<UAnimSequenceBase> MoveBackAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> DamageAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> StunAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> DeadAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> ShoutAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TSoftObjectPtr<UAnimSequenceBase> CombatTurnSkillAnimation;

	// FriendlyTarget: 0, HostileTarget: 1
	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TArray<TSoftObjectPtr<UAnimSequenceBase>> CombatTurnSkillAnimationVaries;

	UPROPERTY(BlueprintReadOnly, Transient)
	FSkillAnimInfo CurNormalSkillAnimInfo;

	UPROPERTY(BlueprintReadOnly, Transient)
	TSoftObjectPtr<UAnimSequenceBase> CurMoveBackAnimation;

	UPROPERTY(BlueprintReadOnly, Transient)
	TSoftObjectPtr<UAnimSequenceBase> CurCombatTurnSkillAnimation;

	UPROPERTY(BlueprintReadOnly, Transient)
	TSoftObjectPtr<UAnimSequenceBase> CurPreviewAnimation;

	FAnimNode_StateMachine* StateMachine;
	int32 MachineIndex;
};

/**
 * Unit Anim Instance
 */
UCLASS()
class Q6_API UUnitAnimInstance : public UUnitAnimInstanceBase
{
	GENERATED_BODY()

public:
	UUnitAnimInstance(const FObjectInitializer& ObjectInitializer);

	void NativeInitializeAnimation() override;

	float GetCurrentAnimMoveTime() override;
	void GetSkillAnimNotifyInfo(ECCFaction InFaction, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart) override;

	ESkillNote GetSkillNote() const { return SkillNote; }
	void SetSkillNote(ESkillNote InSkillNote) { SkillNote = InSkillNote; }
	void SetDoubleSkill(bool bInDoubleSkill) { bDoubleSkill = bInDoubleSkill; }
	void SetTurnSkillIndex(int32 InTurnSkillIndex);

	bool SetPrepareSpawn(bool bInPrepareSpawn);
	bool SetMoving(bool bInMoving, bool bIsRun = false);
	bool SetSkill(bool bInSkill) override;
	bool SetTurnSkill(bool bInTurnSkill) override;

	/**
	* WARN: do not use directly. use AUnit::SetAnimRelaxed() since UnitAnimInstance can be NULL during streaming
	*/
	bool SetRelaxed(bool bInRelaxed) override;

	bool SetPreview(ECharacterVoiceCategory InVoiceCategory);

	UAnimSequenceBase* GetTurnSkillAnimation() const { return CurTurnSkillAnimation.Get(); }
	UAnimSequenceBase* GetPreparePhaseAnimation() const { return PreparePhaseAnimation.Get(); }

	const FTransform& GetAttachmentTransform() const { return AttachmentTransform; }
	const FTransform& GetAttachmentLightTransform() const { return AttachmentLightTransform; }
	TArray<FQ6MaterialSlotOverride>& GetAttachmentMaterialOverride() { return AttachmentMaterialOverride; }

protected:
	UPROPERTY(BlueprintReadOnly, EditInstanceOnly, Category = "State Flag")
	bool bRelaxed;

	UPROPERTY(BlueprintReadOnly, Transient)
	ESkillNote SkillNote;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bDoubleSkill;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bPrepareSpawn;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "Preview State Flag")
	bool bPreview;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> IdleAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> RunAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	FSkillAnimInfo AceSkillAnimInfo;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	FSkillAnimInfo BreakSkillAnimInfo;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	FSkillAnimInfo CloserSkillAnimInfo;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	FSkillAnimInfo DoubleSkillAnimInfo;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimSequenceBase> PreparePhaseAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TSoftObjectPtr<UAnimSequenceBase> TurnSkillAnimation;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TArray<TSoftObjectPtr<UAnimSequenceBase>> TurnSkillAnimationVaries;

	UPROPERTY(BlueprintReadOnly, Transient)
	TSoftObjectPtr<UAnimSequenceBase> CurTurnSkillAnimation;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "Attachment")
	FTransform AttachmentTransform;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "Attachment")
	FTransform AttachmentLightTransform;

	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "Attachment")
	TArray<FQ6MaterialSlotOverride> AttachmentMaterialOverride;

private:
	void GatherAnimationPaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths) override;

	FSkillAnimInfo GetNormalSkillAnimInfo() const;

	TArray<const FSkillAnimInfo*> ValidNoteSkillAnimInfos;
};
