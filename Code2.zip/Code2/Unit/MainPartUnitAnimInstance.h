// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Unit/UnitAnimInstance.h"
#include "MainPartUnitAnimInstance.generated.h"

enum class ECCFaction : uint8;

USTRUCT(BlueprintType)
struct FMaterialSlotIndexes
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly)
	TArray<int32> MaterialSlotIndexes;
};

USTRUCT(BlueprintType)
struct FCombatTurnSkillAnimationVaries
{
	GENERATED_BODY()

	// FriendlyTarget: 0, HostileTarget: 1
	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly)
	TArray<TSoftObjectPtr<UAnimSequenceBase>> CombatTurnSkillAnimationVaries;
};

/**
 * Main Part Unit Anim Instance
 */
UCLASS()
class Q6_API UMainPartUnitAnimInstance : public UUnitAnimInstanceBase
{
	GENERATED_BODY()
	
public:
	UMainPartUnitAnimInstance(const FObjectInitializer& ObjectInitializer);

	const TArray<int32>& GetDefaultSubPartIndexes() const { return DefaultSubPartIndexes; }
	const TArray<FMaterialSlotIndexes>& GetSubPartsMaterialSlotIndexes() const { return SubPartMaterialSlotIndexes; }
	const FMaterialSlotIndexes& GetSubPartMaterialSlotIndexes(int32 InSubPartIndex) const;
	int32 GetSubPartSubMaterialMask(int32 InSubPartIndex) const;

	void GetSkillAnimNotifyInfo(ECCFaction InFaction, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart) override;
	void GetSubPartSkillAnimNotifyInfo(int32 InSubPartIndex, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart);

	void SetSubPartCombatTurnSkillIndex(int32 InSubPartIndex, int32 InIndex);

	void SetDead(bool bInDead) override;
	void SetSubPartDead(int32 InSubPartIndex, bool bInDead);

	void SetHit(bool bInHit) override;
	void SetSubPartHit(int32 InSubPartIndex, bool bInHit);

	UAnimSequenceBase* GetSubPartDeadAnimation(int32 InSubPartIndex) const;

protected:
	UPROPERTY(BlueprintReadWrite, EditInstanceOnly, Category = "State Flag")
	bool bSubPartDead;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Material")
	FMaterialSlotIndexes MainPartMaterialSlotIndexes;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Material")
	TArray<FMaterialSlotIndexes> SubPartMaterialSlotIndexes;

	UPROPERTY(BlueprintReadWrite, EditDefaultsOnly, Category = "Material")
	TArray<FMaterialSlotIndexes> SubPartSubMaterialSlotIndexes;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Material")
	TArray<int32> DefaultSubPartIndexes;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TArray<FSkillAnimInfo> SubPartNormalSkillAnimInfos;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TArray<TSoftObjectPtr<UAnimSequenceBase>> SubPartUltimateSkillAnimations;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Skill Animation")
	TArray<FCombatTurnSkillAnimationVaries> SubPartsCombatTurnSkillAnimationVaries;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TArray<TSoftObjectPtr<UAnimSequenceBase>> SubPartDeadAnimations;

	UPROPERTY(BlueprintReadOnly, EditDefaultsOnly, Category = "Animation")
	TArray<TSoftObjectPtr<UAnimSequenceBase>> SubPartDamageAnimations;

	UPROPERTY(BlueprintReadOnly, Transient)
	TSoftObjectPtr<UAnimSequenceBase> CurDeadAnimation;

	UPROPERTY(BlueprintReadOnly, Transient)
	TSoftObjectPtr<UAnimSequenceBase> CurDamageAnimation;

private:
	void GatherAnimationPaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths) override;

	UAnimSequenceBase* GetSubPartDamageAnimation(int32 InSubPartIndex) const;
};
