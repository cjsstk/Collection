// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "Unit/Unit.h"
#include "SubPartUnit.generated.h"

class AMainPartUnit;

/**
 * Sub Part Unit
 */
UCLASS()
class Q6_API ASubPartUnit : public AUnit
{
	GENERATED_BODY()
	
public:
	ASubPartUnit(const FObjectInitializer& ObjectInitializer);

	virtual void InitFromUnitState(const FUnitState& InUnitState, bool bInAnimRelaxed, bool bBlockingLoad = false) override;

	virtual AUnit* GetSourceUnit() const override;
	virtual FTransform GetSocketTransform(const FName Socket) const override;

	void SetMainPartUnitId(FCCUnitId InUnitId) { MainPartUnitId = InUnitId; }
	FCCUnitId GetMainPartUnitId() const { return MainPartUnitId; }

	void SetSubPartIndex(int32 InIndex) { SubPartIndex = InIndex; }

	virtual const FUltimateSkillSequenceAssetRow& GetUltimateSkillSequenceAssetRow(int32 InSkillType, bool bInAddMissingLog = true) const override;

	virtual float GetTurnSkillAnimLength() const override;
	virtual float GetDeadAnimLength() const override;
	virtual void GetSkillAnimNotifyInfo(int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo) override;

	virtual void StartSpawnFX(ESpawnReason InReason) override;

	virtual void SetStunned(bool bInStunned) override {}
	virtual void SetMoving(bool bInMoving) override {}
	virtual void SetDead() override;
	virtual void SetHit(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam) override;
	virtual void SetShieldHit(bool bBroken) override;

	virtual void SetUltimateSkillState(bool bIsOn) override;
	virtual void SetTurnSkillIndex(int32 InIndex) override;

	virtual void PlayNormalSkill(const FVector& InTargetLocation, bool bIsDouble) override;
	virtual void PlayTurnSkill() override;
	virtual void PlayShout() override {}
	virtual void PlayHit() override {}

	virtual void RotateToTargetUnit(const AUnit* InTargetUnit) override {};
	virtual void RotateToLocation(const FVector& InLocation) override {};
	virtual void UpdateRotationToEnd() override {};

private:
	AMainPartUnit* GetMainPartUnit() const;

	virtual void InitFromDesc() override;

	virtual void SetSubMaterialEffect(const FSubMaterialEffectParams& SubMaterialParams, int32 Mask = -1) override;
	virtual UParticleSystemComponent* SpawnParticle(const FSpawnParticleParams& ParticleParam) override;

	FCCUnitId MainPartUnitId;
	int32 SubPartIndex;
};
