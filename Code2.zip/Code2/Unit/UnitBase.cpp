// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "UnitBase.h"
#include "GameAssetCache.h"
#include "GameResource.h"
#include "LevelUtil.h"
#include "Q6GameInstance.h"
#include "PaperSpriteComponent.h"

AUnitBase::AUnitBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer.DoNotCreateDefaultSubobject(ACharacter::CharacterMovementComponentName))
	, DescType(0)
	, ModelType(0)
	, MeshScale(1.f)
	, BoundRadius(0.f)
	, bSequenceAnimMode(false)
{
	PrimaryActorTick.bCanEverTick = true;
	GetCapsuleComponent()->SetEnableGravity(false);
	GetCapsuleComponent()->bAlwaysCreatePhysicsState = false;

	GetMesh()->SetEnableGravity(false);
	GetMesh()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	GetMesh()->VisibilityBasedAnimTickOption = EVisibilityBasedAnimTickOption::AlwaysTickPose;
	GetMesh()->SetRelativeLocation(FVector(0, 0, -GetCapsuleComponent()->GetScaledCapsuleHalfHeight()));
	GetMesh()->SetRelativeRotation(FRotator(0, -90, 0));
	GetMesh()->bCastDynamicShadow = true;
	GetMesh()->SetMaterialParameterExistOnly(true);

	ShadowComponent = ObjectInitializer.CreateDefaultSubobject<UPaperSpriteComponent>(this, TEXT("ShadowComponent"));
	ShadowComponent->SetupAttachment(GetCapsuleComponent());
	ShadowComponent->SetRelativeRotation(FRotator(0, 0, 90));
	ShadowComponent->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

void AUnitBase::StreamLoadAsset()
{
	if (AssetCache)
	{
		return;
	}

	UnitInitParams.bNeedAsset = true;
}

bool AUnitBase::IsStreaming() const
{
	if (!AssetCache)
	{
		return false;
	}

	return !AssetCache->IsLoaded();
}

bool AUnitBase::IsAssetLoaded() const
{
	return AssetCache && AssetCache->IsLoaded();
}

void AUnitBase::UnloadAsset()
{
	if (AssetCache)
	{
		AssetCache->CancelStreaming();
		AssetCache = nullptr;
	}

	GetMesh()->SetAnimInstanceClass(nullptr);
	GetMesh()->SetSkeletalMesh(nullptr);
	GetMesh()->EmptyOverrideMaterials();
	GetMesh()->KinematicBonesUpdateType = EKinematicBonesUpdateToPhysics::SkipAllBones;
}

void AUnitBase::InitMesh()
{
	const FUnitModelAssetRow& Row = GetGameResource().GetUnitModelAssetRow(ModelType);

	GetMesh()->SetAnimInstanceClass(nullptr);
	ULevelUtil::LoadSkeletalMesh(GetMesh(), Row, ModelType, true, true);
	GetMesh()->KinematicBonesUpdateType = EKinematicBonesUpdateToPhysics::SkipAllBones;

	InitMeshInternal(Row);
}

void AUnitBase::InitMeshInternal(const FUnitModelAssetRow& Row)
{
	bool bSetAnimInstance = true;
#if WITH_EDITOR
	UQ6GameInstance* GameInsatnce = UQ6GameInstance::Get();
	bSetAnimInstance = GameInsatnce != nullptr;
#endif
	if (bSetAnimInstance) //-V547
	{
		if (Row.AnimInstanceClass.IsValid())
		{
			GetMesh()->SetAnimInstanceClass(Row.AnimInstanceClass.Get());
			//ResetAnimation();

			GetMesh()->SetAnimationMode(EAnimationMode::AnimationBlueprint);
			LoadAnimations();
			LoadSkillSequences();
		}
		else
		{
			Q6JsonLogSunny(Warning, "Model has no animation class", Q6KV("ModelType", ModelType));
		}
	}

	MeshScale = Row.MeshScale;
	if (FMath::IsNearlyZero(MeshScale, KINDA_SMALL_NUMBER))
	{
		MeshScale = 1.f;
		Q6JsonLogSunny(Warning, "Zero scale value was converted to 1.0", Q6KV("ModelType", ModelType));
	}
	GetMesh()->SetRelativeScale3D(FVector(MeshScale));
	GetMesh()->UpdateBounds();

	BoundRadius = Row.BoundRadius * MeshScale;
}

void AUnitBase::OnAssetStreamCompleted()
{
	Q6JsonLogSunny(Display, "Model Asset Streaming Completed", Q6KV("ModelType", ModelType));

	InitMesh();
}

void AUnitBase::EnableUnit()
{
	SetActorHiddenInGame(false);
	RegisterAllActorTickFunctions(true, true);
}

void AUnitBase::DisableUnit()
{
	SetActorHiddenInGame(true);
	RegisterAllActorTickFunctions(false, true);
}

void AUnitBase::SetSequenceAnimMode(bool bInSeqAnimMode)
{
	bSequenceAnimMode = bInSeqAnimMode;

	if (bSequenceAnimMode)
	{
		GetMesh()->SetRelativeScale3D(FVector(1.f));
		GetMesh()->SetAnimationMode(EAnimationMode::AnimationCustomMode);
	}
	else
	{
		GetMesh()->SetRelativeScale3D(FVector(MeshScale));
		if (GetMesh()->GetAnimationMode() != EAnimationMode::AnimationBlueprint)
		{
			ResetAnimation();
		}
	}
}

void AUnitBase::ResetAnimation()
{
	GetMesh()->SetAnimationMode(EAnimationMode::AnimationBlueprint);

	// load anim db since remade anim instance not having it yet.
	LoadAnimations();
	LoadSkillSequences();
}

void AUnitBase::UpdateAnimationImmediately()
{
	UAnimInstance* AnimInstance = GetMesh()->GetAnimInstance();
	if (AnimInstance)
	{
		AnimInstance->UpdateAnimation(0.f, false);

		GetMesh()->RefreshBoneTransforms();
		GetMesh()->RefreshSlaveComponents();
		GetMesh()->UpdateComponentToWorld();
	}
}

void AUnitBase::ForceRecentlyRendered()
{
	float TimeNow = GetWorld()->GetTimeSeconds();
	GetMesh()->SetLastRenderTime(TimeNow);
}
