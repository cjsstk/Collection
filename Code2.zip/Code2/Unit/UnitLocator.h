// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "Unit.h"
#include "UnitLocator.generated.h"


UCLASS()
class Q6_API ACharacterLocator : public AUnit
{
	GENERATED_BODY()
	
public:	
	ACharacterLocator(const FObjectInitializer& ObjectInitializer);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Unit")
	int32 Slot;
};


UCLASS()
class Q6_API AMonsterLocator : public AUnit
{
	GENERATED_BODY()

public:
	AMonsterLocator(const FObjectInitializer& ObjectInitializer);

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Unit")
	int32 Wave;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Unit")
	int32 Slot;
};