// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "UnitAnimInstance.h"
#include "Animation/AnimNode_StateMachine.h"
#include "AnimNotify/UnitAnimNotifies.h"
#include "Q6.h"
#include "Q6Enum.h"
#include "Q6Log.h"
#include "CMSTable.h"

UUnitAnimInstanceBase::UUnitAnimInstanceBase(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bDead(false)
	, bHit(false)
	, bStunned(false)
	, bSkipMoveToState(false)
	, bMoving(false)
	, bUltimateSkill(false)
	, bSkill(false)
	, bTurnSkill(false)
	, bShout(false)
	, StateMachine(nullptr)
	, MachineIndex(INDEX_NONE)
{}

void UUnitAnimInstanceBase::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();

	const FBakedAnimationStateMachine* BakedStateMachine = GetStateMachineInstanceDesc("Normal");
	MachineIndex = GetStateMachineIndex("Normal");
	StateMachine = GetStateMachineInstance(MachineIndex);
}

float UUnitAnimInstanceBase::GetCurrentAnimMoveTime()
{
	UAnimSequenceBase* AnimSequence;

	FName CurrentStateName = GetCurrentStateName(MachineIndex);
	if (CurrentStateName.IsEqual(FName("MoveTo")))
	{
		AnimSequence = CurNormalSkillAnimInfo.MoveToAnimation.Get();
	}
	else if (CurrentStateName.IsEqual(FName("MoveBack")))
	{
		AnimSequence = CurMoveBackAnimation.Get();
	}
	else
	{
		Q6JsonLogSunny(Warning, "Invalid animation state name to get move time", Q6KV("State", *CurrentStateName.ToString()));
		return 0.f;
	}

	if (!AnimSequence)
	{
		Q6JsonLogSunny(Warning, "Invalid animation sequence", Q6KV("State", *CurrentStateName.ToString()));
		return 0.f;
	}

	float MoveStartTime = 0.f;
	float MoveEndTime = AnimSequence->GetPlayLength();
	for (const FAnimNotifyEvent& Event : AnimSequence->Notifies)
	{
		if (!Event.NotifyName.IsValid())
		{
			Q6JsonLogSunny(Warning, "Invalid animation event name", Q6KV("Animation", *AnimSequence->GetName()));
			continue;
		}

		if (Event.NotifyName == "MoveStart")
		{
			MoveStartTime = Event.GetTime();
		}
		else if (Event.NotifyName == "MoveEnd")
		{
			MoveEndTime = Event.GetTime();
		}
	}

	return FMath::Max(MoveEndTime - MoveStartTime, 0.f);
}

static bool _HasDuplicatedTimeHitNoties(const FAnimNotifyEvent& InHitNoti, const TArray<FAnimNotifyEvent>& InNotifies)
{
	for (const FAnimNotifyEvent& Event : InNotifies)
	{
		if (UHitWithWeight* HitWithWeight = Cast<UHitWithWeight>(Event.Notify))
		{
			if (Event == InHitNoti)
			{
				continue;
			}

			if (FMath::IsNearlyEqual(Event.GetTime(), InHitNoti.GetTime()))
			{
				return true;
			}
		}
	}

	return false;
}

void UUnitAnimInstanceBase::GetSkillAnimNotifyInfoInternal(const UAnimSequenceBase* InAnimSequence, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart) const
{
	// check weight valid
	FSkillAnimHitInfo SkillEffectHitInfo;
	for (const FAnimNotifyEvent& Event : InAnimSequence->Notifies)
	{
		if (!Event.NotifyName.IsValid())
		{
			Q6JsonLogSunny(Warning, "Invalid animation notify name", Q6KV("Animation", *InAnimSequence->GetName()));
			continue;
		}

		if (Event.NotifyName == "StartCameraSequence")
		{
			bOutHasSequenceStart = true;
			continue;
		}

		if (UHitWithWeight* HitWithWeight = Cast<UHitWithWeight>(Event.Notify))
		{
			if (!SkillEffectHitInfo.bWeightValid)
			{
				SkillEffectHitInfo.bWeightValid = !FMath::IsNearlyEqual(HitWithWeight->Weight, 1.f, KINDA_SMALL_NUMBER) ||
					_HasDuplicatedTimeHitNoties(Event, InAnimSequence->Notifies);
			}
		}
		else if (Event.NotifyName == "NextSkillEffect")
		{
			OutSkillAnimHitInfo.Add(SkillEffectHitInfo);
			SkillEffectHitInfo.Empty();
		}
	}
	OutSkillAnimHitInfo.Add(SkillEffectHitInfo);

	// add values
	int32 CurSkillEffectHitInfoIndex = 0;
	for (const FAnimNotifyEvent& Event : InAnimSequence->Notifies)
	{
		if (!Event.NotifyName.IsValid())
		{
			Q6JsonLogSunny(Warning, "Invalid animation notify name", Q6KV("Animation", *InAnimSequence->GetName()));
			continue;
		}

		if (UFireProjectile* FireProjectile = Cast<UFireProjectile>(Event.Notify))
		{
			int32 ProjectileHitCount = FireProjectile->ProjectileEffectDesc.HitInfo.HitCount;
			if (ProjectileHitCount <= 0)
			{
				continue;
			}

			float ProjectileHitInterval = FireProjectile->ProjectileEffectDesc.HitInfo.HitInterval;
			for (int32 i = 0; i < ProjectileHitCount; ++i)
			{
				if (OutSkillAnimHitInfo[CurSkillEffectHitInfoIndex].bWeightValid)
				{
					OutSkillAnimHitInfo[CurSkillEffectHitInfoIndex].HitValues.Add(FireProjectile->Weight / ProjectileHitCount);
				}
				else
				{
					OutSkillAnimHitInfo[CurSkillEffectHitInfoIndex].HitValues.Add(Event.GetTime() + ProjectileHitInterval * i);
				}
			}
		}
		else if (UHitWithWeight* HitWithWeight = Cast<UHitWithWeight>(Event.Notify))
		{
			if (OutSkillAnimHitInfo[CurSkillEffectHitInfoIndex].bWeightValid)
			{
				OutSkillAnimHitInfo[CurSkillEffectHitInfoIndex].HitValues.Add(HitWithWeight->Weight);
			}
			else
			{
				OutSkillAnimHitInfo[CurSkillEffectHitInfoIndex].HitValues.Add(Event.GetTime());
			}
		}
		else if (Event.NotifyName == "NextSkillEffect")
		{
			++CurSkillEffectHitInfoIndex;
		}
	}
}

void UUnitAnimInstanceBase::SetUltimateSkill(bool bInUltimateSkill)
{
	bUltimateSkill = bInUltimateSkill;
	CurMoveBackAnimation = MoveBackAnimation;
}

void UUnitAnimInstanceBase::SetCombatTurnSkillIndex(int32 InCombatTurnSkillIndex)
{
	if (CombatTurnSkillAnimationVaries.IsValidIndex(InCombatTurnSkillIndex))
	{
		if (IsValidAnim(CombatTurnSkillAnimationVaries[InCombatTurnSkillIndex]))
		{
			CurCombatTurnSkillAnimation = CombatTurnSkillAnimationVaries[InCombatTurnSkillIndex];
			return;
		}
	}

	CurCombatTurnSkillAnimation = CombatTurnSkillAnimation;
}

bool UUnitAnimInstanceBase::SetMoving(bool bInMoving)
{
	if (bDead)
	{
		return true;
	}

	if (bInMoving)
	{
		if (!IsValidAnim(CurMoveBackAnimation))
		{
			return false;
		}
	}

	bMoving = bInMoving;

	return true;
}

void UUnitAnimInstanceBase::SetDead(bool bInDead)
{
	bDead = bInDead;
}

void UUnitAnimInstanceBase::SetHit(bool bInHit)
{
	if (bDead)
	{
		return;
	}

	if (!IsValidAnim(DamageAnimation))
	{
		return;
	}

	bHit = bInHit;
}

void UUnitAnimInstanceBase::SetStunned(bool bInStunned)
{
	if (bDead)
	{
		return;
	}

	if (!IsValidAnim(StunAnimation))
	{
		return;
	}

	bStunned = bInStunned;
}

bool UUnitAnimInstanceBase::SetShout(bool bInShout)
{
	if (bDead)
	{
		return true;
	}

	if (!IsValidAnim(ShoutAnimation))
	{
		return false;
	}

	bShout = bInShout;

	return true;
}

bool UUnitAnimInstanceBase::SetSkill(bool bInSkill)
{
	if (bDead)
	{
		return true;
	}

	if (!IsValidAnim(CurNormalSkillAnimInfo.SkillAnimation))
	{
		return false;
	}

	bSkipMoveToState = !IsValidAnim(CurNormalSkillAnimInfo.MoveToAnimation);
	CurMoveBackAnimation = CurNormalSkillAnimInfo.MoveBackAnimation;

	bSkill = bInSkill;

	return true;
}

bool UUnitAnimInstanceBase::SetTurnSkill(bool bInTurnSkill)
{
	if (bDead)
	{
		return true;
	}

	if (!IsValidAnim(CurCombatTurnSkillAnimation))
	{
		return false;
	}

	bTurnSkill = bInTurnSkill;

	return true;
}


UUnitAnimInstance::UUnitAnimInstance(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
	, bRelaxed(true)
	, SkillNote(ESkillNote::None)
	, bDoubleSkill(false)
	, bPrepareSpawn(false)
{}

void UUnitAnimInstance::NativeInitializeAnimation()
{
	Super::NativeInitializeAnimation();

	ValidNoteSkillAnimInfos.Empty();
	if (!AceSkillAnimInfo.SkillAnimation.IsNull())
	{
		ValidNoteSkillAnimInfos.Add(&AceSkillAnimInfo);
	}
	if (!BreakSkillAnimInfo.SkillAnimation.IsNull())
	{
		ValidNoteSkillAnimInfos.Add(&BreakSkillAnimInfo);
	}
	if (!CloserSkillAnimInfo.SkillAnimation.IsNull())
	{
		ValidNoteSkillAnimInfos.Add(&CloserSkillAnimInfo);
	}
}

void UUnitAnimInstance::GatherAnimationPaths(const FAnimLoadingOption& InLoadingOption, TArray<FSoftObjectPath>& OutPaths)
{
	int32 InModelType = InLoadingOption.ModelType;
	AddValidAnimation(InModelType, OutPaths, "Idle", IdleAnimation, true);

	// all required
	AddValidAnimation(InModelType, OutPaths, "NormalSkill", NormalSkillAnimInfo.SkillAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Damage", DamageAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Dead", DeadAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "TurnSkill", TurnSkillAnimation, true);

	// character required
	AddValidAnimation(InModelType, OutPaths, "AceSkill", AceSkillAnimInfo.SkillAnimation, InLoadingOption.bIsCharacter);
	AddValidAnimation(InModelType, OutPaths, "BreakSkill", BreakSkillAnimInfo.SkillAnimation, InLoadingOption.bIsCharacter);
	AddValidAnimation(InModelType, OutPaths, "CloserSkill", CloserSkillAnimInfo.SkillAnimation, InLoadingOption.bIsCharacter);
	AddValidAnimation(InModelType, OutPaths, "DoubleSkill", DoubleSkillAnimInfo.SkillAnimation, InLoadingOption.bIsCharacter);
	AddValidAnimation(InModelType, OutPaths, "PreparePhase", PreparePhaseAnimation, InLoadingOption.bIsCharacter);

	if (InLoadingOption.bIsCharacter)
	{
		for (TSoftObjectPtr<UAnimSequenceBase> TurnSkillAnimationVary : TurnSkillAnimationVaries)
		{
			AddValidAnimation(InModelType, OutPaths, "TurnSkill", TurnSkillAnimationVary, false);
		}
	}

	if (!InLoadingOption.bInCombat)
	{
		return;
	}

	// all required
	AddValidAnimation(InModelType, OutPaths, "CombatIdle", CombatIdleAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Stun", StunAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "CombatTurnSkill", CombatTurnSkillAnimation, true);
	AddValidAnimation(InModelType, OutPaths, "Shout", ShoutAnimation, true);

	// character required
	AddValidAnimation(InModelType, OutPaths, "Run", RunAnimation, InLoadingOption.bIsCharacter);

	// optional
	AddValidAnimation(InModelType, OutPaths, "NormalSkillMoveTo", NormalSkillAnimInfo.MoveToAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "NormalSkillMoveBack", NormalSkillAnimInfo.MoveBackAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "AceSkillMoveTo", AceSkillAnimInfo.MoveToAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "AceSkillMoveBack", AceSkillAnimInfo.MoveBackAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "BreakSkillMoveTo", BreakSkillAnimInfo.MoveToAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "BreakSkillMoveBack", BreakSkillAnimInfo.MoveBackAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "CloserSkillMoveTo", CloserSkillAnimInfo.MoveToAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "CloserSkillMoveBack", CloserSkillAnimInfo.MoveBackAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "MoveBack", MoveBackAnimation, false);
	AddValidAnimation(InModelType, OutPaths, "UltimateSkill", UltimateSkillAnimation, false);

	if (InLoadingOption.bIsCharacter)
	{
		AddValidAnimation(InModelType, OutPaths, "DoubleSkillMoveTo", DoubleSkillAnimInfo.MoveToAnimation, false);
		AddValidAnimation(InModelType, OutPaths, "DoubleSkillMoveBack", DoubleSkillAnimInfo.MoveBackAnimation, false);
	}
	else
	{
		for (TSoftObjectPtr<UAnimSequenceBase> CombatTurnSkillAnimationVary : CombatTurnSkillAnimationVaries)
		{
			AddValidAnimation(InModelType, OutPaths, "CombatTurnSkill", CombatTurnSkillAnimationVary, false);
		}
	}
}

float UUnitAnimInstance::GetCurrentAnimMoveTime()
{
	FName CurrentStateName = GetCurrentStateName(MachineIndex);
	if (CurrentStateName.IsEqual(FName("Run")))
	{
		return 1.f; // temp-fix?
	}

	return Super::GetCurrentAnimMoveTime();
}

FSkillAnimInfo UUnitAnimInstance::GetNormalSkillAnimInfo() const
{
	switch (SkillNote)
	{
		case ESkillNote::None:
			if (ValidNoteSkillAnimInfos.Num())
			{
				int32 Index = FMath::RandHelper(ValidNoteSkillAnimInfos.Num());
				return *ValidNoteSkillAnimInfos[Index];
			}
			break;
		case ESkillNote::Ace:
			return AceSkillAnimInfo;
		case ESkillNote::Break:
			return BreakSkillAnimInfo;
		case ESkillNote::Closer:
			return CloserSkillAnimInfo;
		default:
			Q6JsonLogSunny(Warning, "UUnitAnimInstance::GetNormalSkillInfo - Invalid SkillNote", Q6KV("SkillNote", (uint8)SkillNote));
			break;
	}

	return NormalSkillAnimInfo;
}

void UUnitAnimInstance::SetTurnSkillIndex(int32 InTurnSkillIndex)
{
	if (TurnSkillAnimationVaries.IsValidIndex(InTurnSkillIndex))
	{
		if (IsValidAnim(TurnSkillAnimationVaries[InTurnSkillIndex]))
		{
			CurTurnSkillAnimation = TurnSkillAnimationVaries[InTurnSkillIndex];
			return;
		}
	}
	
	CurTurnSkillAnimation = TurnSkillAnimation;
}

void UUnitAnimInstance::GetSkillAnimNotifyInfo(ECCFaction InFaction, int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo, bool& bOutHasSequenceStart)
{
	const FCMSSkillRow& SkillRow = GetCMS()->GetSkillRowOrDummy(InSkillType);

	UAnimSequenceBase* AnimSequence = nullptr;
	if (InFaction == ECCFaction::Ally)
	{
		switch (SkillRow.SkillCategory)
		{
			case ESkillCategory::Normal:
				CurNormalSkillAnimInfo = GetNormalSkillAnimInfo();
				AnimSequence = CurNormalSkillAnimInfo.SkillAnimation.Get();
				break;
			case ESkillCategory::Double:
				AnimSequence = DoubleSkillAnimInfo.SkillAnimation.Get();
				break;
			case ESkillCategory::Ultimate:
				AnimSequence = UltimateSkillAnimation.Get();
				break;
			case ESkillCategory::TurnBegin:
			case ESkillCategory::Artifact:
				AnimSequence = GetTurnSkillAnimation();
				break;
			default:
				break;
		}
	}
	else
	{
		switch (SkillRow.SkillCategory)
		{
			case ESkillCategory::Normal:
				CurNormalSkillAnimInfo = GetNormalSkillAnimInfo();
				AnimSequence = CurNormalSkillAnimInfo.SkillAnimation.Get();
				break;
			case ESkillCategory::Ultimate:
				AnimSequence = UltimateSkillAnimation.Get();
				break;
			case ESkillCategory::TurnBegin:
				AnimSequence = GetCombatTurnSkillAnimation();
				break;
			default:
				break;
		}
	}

	if (AnimSequence == nullptr || !IsValidAnim(AnimSequence))
	{
		Q6JsonLogSunny(Warning, "Invalid Anim Sequence", Q6KV("SkillCategory", (uint8)SkillRow.SkillCategory));
		return;
	}

	GetSkillAnimNotifyInfoInternal(AnimSequence, OutSkillAnimHitInfo, bOutHasSequenceStart);
}

bool UUnitAnimInstance::SetPrepareSpawn(bool bInPrepareSpawn)
{
	if (bDead)
	{
		return true;
	}

	if (bStunned)
	{
		return false;
	}

	if (!IsValidAnim(PreparePhaseAnimation))
	{
		return false;
	}

	bPrepareSpawn = bInPrepareSpawn;

	return true;
}

bool UUnitAnimInstance::SetMoving(bool bInMoving, bool bIsRun /* = false */)
{
	if (bInMoving)
	{
		if (bIsRun)
		{
			if (!IsValidAnim(RunAnimation))
			{
				return false;
			}

			bMoving = true;

			return true;
		}
	}

	return Super::SetMoving(bInMoving);
}

bool UUnitAnimInstance::SetSkill(bool bInSkill)
{
	if (bDoubleSkill)
	{
		CurNormalSkillAnimInfo = DoubleSkillAnimInfo;
	}

	return Super::SetSkill(bInSkill);
}

bool UUnitAnimInstance::SetTurnSkill(bool bInTurnSkill)
{
	if (bRelaxed)
	{
		if (!IsValidAnim(CurTurnSkillAnimation))
		{
			return false;
		}

		bTurnSkill = bInTurnSkill;

		return true;
	}

	return Super::SetTurnSkill(bInTurnSkill);
}

bool UUnitAnimInstance::SetRelaxed(bool bInRelaxed)
{
	if (bInRelaxed == bRelaxed)
	{
		return false;
	}

	bRelaxed = bInRelaxed;

	return true;
}

bool UUnitAnimInstance::SetPreview(ECharacterVoiceCategory InVoiceCategory)
{
	switch (InVoiceCategory)
	{
		case ECharacterVoiceCategory::TurnSkill1:
			SetTurnSkillIndex(0);
			CurPreviewAnimation = CurTurnSkillAnimation;
			break;
		case ECharacterVoiceCategory::TurnSkill2:
			SetTurnSkillIndex(1);
			CurPreviewAnimation = CurTurnSkillAnimation;
			break;
		case ECharacterVoiceCategory::TurnSkill3:
			SetTurnSkillIndex(2);
			CurPreviewAnimation = CurTurnSkillAnimation;
			break;
		case ECharacterVoiceCategory::NormalSkill:
			SetSkillNote(ESkillNote::None);
			CurPreviewAnimation = GetNormalSkillAnimInfo().SkillAnimation;
			break;
		case ECharacterVoiceCategory::AceSkill:
			SetSkillNote(ESkillNote::Ace);
			CurPreviewAnimation = GetNormalSkillAnimInfo().SkillAnimation;
			break;
		case ECharacterVoiceCategory::BreakSkill:
			SetSkillNote(ESkillNote::Break);
			CurPreviewAnimation = GetNormalSkillAnimInfo().SkillAnimation;
			break;
		case ECharacterVoiceCategory::CloserSkill:
			SetSkillNote(ESkillNote::Closer);
			CurPreviewAnimation = GetNormalSkillAnimInfo().SkillAnimation;
			break;
		case ECharacterVoiceCategory::DoubleSkill:
			CurPreviewAnimation = DoubleSkillAnimInfo.SkillAnimation;
			break;
		case ECharacterVoiceCategory::TurnSpawn:
			CurPreviewAnimation = PreparePhaseAnimation;
			break;
		case ECharacterVoiceCategory::Dead:
			CurPreviewAnimation = DeadAnimation;
			break;
		case ECharacterVoiceCategory::Hit:
			CurPreviewAnimation = DamageAnimation;
			break;
		default:
			bPreview = false;
			return true;
	}

	if (!IsValidAnim(CurPreviewAnimation))
	{
		Q6JsonLogSunny(Warning, "Invalid Preview Anim Sequence", Q6KV("VoiceCategory", *ENUM_TO_STRING(ECharacterVoiceCategory, InVoiceCategory)));
		return false;
	}

	bPreview = true;
	return true;
}
