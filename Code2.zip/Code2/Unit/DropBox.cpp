// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#include "DropBox.h"

#include "CMSTable.h"
#include "Q6.h"
#include "Q6Log.h"
#include "CombatPresenter.h"
#include "GameResource.h"
#include "CombatGameResource.h"
#include "GameAssetCache.h"

static TAutoConsoleVariable<int32> CVarQ6DropBoxSpawnQueueSize(
	TEXT("q6.dropboxSpawnQueueSize"),
	10,
	TEXT(""),
	ECVF_Cheat);

void UDropBoxSpawner::BeginPlay()
{
	int32 DropBoxSpawnQueueSize = CVarQ6DropBoxSpawnQueueSize.GetValueOnGameThread();
	SpawnDropBoxQueue.Reset(new TCircularQueue<FSpawnDropBoxParams>(DropBoxSpawnQueueSize));
}

void UDropBoxSpawner::EndPlay()
{
	SpawnDropBoxQueue.Reset();
	SpawnedDropBoxHistories.Empty();

	for (UDropBoxes* DropBoxes : SpawnDropBoxes)
	{
		DropBoxes->EndPlay();
	}
	SpawnDropBoxes.Empty();

	for (UGameAssetCache* DropBoxCache : DropBoxCaches)
	{
		DropBoxCache->CancelStreaming();
	}
	DropBoxCaches.Empty();
}

void UDropBoxSpawner::Update()
{
	if (!SpawnDropBoxQueue->IsEmpty())
	{
		FSpawnDropBoxParams Params;
		if (SpawnDropBoxQueue->Peek(Params))
		{
			// spawn the dropbox when playing unit's dead animation half (dead effect start time)
			if (Params.SpawnDelayTime < GetWorld()->GetTimeSeconds())
			{
				UDropBoxes* DropBoxes = NewObject<UDropBoxes>(this);
				DropBoxes->SetSpawnDropBoxParams(Params);
				SpawnDropBoxes.Add(DropBoxes);

				SpawnDropBoxQueue->Dequeue(Params);
			}
		}
	}

	if (SpawnDropBoxes.Num() == 0)
	{
		return;
	}

	int32 Index = 0;
	while (SpawnDropBoxes.IsValidIndex(Index))
	{
		UDropBoxes* DropBoxes = SpawnDropBoxes[Index];
		if (!DropBoxes->Update())
		{
			SpawnDropBoxes.RemoveAtSwap(Index);
			continue;
		}
		++Index;
	}
}

void UDropBoxSpawner::SpawnDropBox(FCCUnitId InUnitId)
{
	check(SpawnDropBoxQueue.IsValid());

	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);

	AUnit* Unit = Presenter->FindUnit(InUnitId);
	if (!Unit)
	{
		Q6JsonLogPawn(Warning, "There is no a unit", Q6KV("UnitId", InUnitId.X));
		return;
	}

	if (!Unit->IsDead())
	{
		Q6JsonLogPawn(Warning, "Target unit is not dead", Q6KV("UnitId", InUnitId.X));
		return;
	}

	const int32 CurrentWaveIndex = GetCheckedCombatPresenter(this)->GetWave() - 1;
	const int32 UnitSlot = Unit->GetUnitState().Slot;

	if (IsAlreadySpawnedDropBox(CurrentWaveIndex, UnitSlot))
	{
		return;
	}

	TMap<EDropBoxType, int32> DropBoxes;
	int32 GainGold = 0;
	int32 TotalDropBoxesNum = 0;

	GatherDropBoxes(Presenter->GetItemDropInfo(), UnitSlot, DropBoxes, GainGold, TotalDropBoxesNum);
	GatherDropBoxes(Presenter->GetRandomSpawnItemDropInfo(), UnitSlot, DropBoxes, GainGold, TotalDropBoxesNum);

	// sorted by dropbox grade
	DropBoxes.KeySort([](EDropBoxType Key1, EDropBoxType Key2) {
		return Key1 > Key2;
	});

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		Q6JsonLogPawn(Warning, "UDropBoxSpawner::SpawnDropBox - CombatGameResource does not exist");
		return;
	}

	const float SpawnDelayTime = Unit->GetDeadAnimLength() * CombatGameResource->GetDropBoxSpawnStartTimeMultiplier();

	if (DropBoxes.Num() > 0)
	{
		int32 CurrentSpawnIndex = 0;
 		for (const auto& DropBox : DropBoxes)
 		{
 			EnqueueSpawnDropBox(DropBox.Key, DropBox.Value, TotalDropBoxesNum, CurrentSpawnIndex, InUnitId, SpawnDelayTime);
			CurrentSpawnIndex += DropBox.Value;
 		}
	}

	if (GainGold > 0)
	{
		// gold can be dropped with dropbox
		EnqueueSpawnDropBox(EDropBoxType::Gold, 1, 1, 0, InUnitId, SpawnDelayTime);
	}

	// ordering by spawn delay time
	ReservedSpawnDropBoxParams.StableSort([](const FSpawnDropBoxParams& Params1, const FSpawnDropBoxParams& Params2)
	{
		return Params1.SpawnDelayTime < Params2.SpawnDelayTime;
	});

	for (const FSpawnDropBoxParams& SpawnDropBoxParam : ReservedSpawnDropBoxParams)
	{
		bool bSucceed = SpawnDropBoxQueue->Enqueue(SpawnDropBoxParam);

		if (!ensure(bSucceed))
		{
			Q6JsonLogPawn(Error, "CombatPresenter DropBox queue is full", Q6KV("World", GetWorld()->GetName()));
		}
	}

	ReservedSpawnDropBoxParams.Empty();

	SpawnedDropBoxHistories.Emplace(FSpawnedDropBoxHistory(CurrentWaveIndex, UnitSlot));
}

float UDropBoxSpawner::GetSpawnDropBoxRemainTime() const
{
	if (SpawnDropBoxes.Num() == 0)
	{
		return 0.0f;
	}

	UDropBoxes* LastDropBoxes = SpawnDropBoxes.Last();
	return LastDropBoxes ? LastDropBoxes->GetSpawnDropBoxRemainTime() : 0.0f;
}

void UDropBoxSpawner::SynchronizeDropBox()
{
	const int32 CurrentWaveIndex = GetCheckedCombatPresenter(this)->GetWave() - 1;

	TArray<int32> DeadUnitSlots = GetCheckedCombatPresenter(this)->FindDeadUnitSlotsByFaction(ECCFaction::Enemy);
	if (CurrentWaveIndex == 0 && DeadUnitSlots.Num() == 0)
	{
		return;
	}

	for (const int32 UnitSlot : DeadUnitSlots)
	{
		// the previous waves histories don't need anymore
		SpawnedDropBoxHistories.Emplace(FSpawnedDropBoxHistory(CurrentWaveIndex, UnitSlot));
	}
}

void UDropBoxSpawner::CacheDropBoxAssets()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);

	TSet<EDropBoxType> DropBoxTypes;
	GatherDropBoxTypes(Presenter->GetItemDropInfo(), DropBoxTypes);
	GatherDropBoxTypes(Presenter->GetRandomSpawnItemDropInfo(), DropBoxTypes);

	FAssetCacheOptions CacheOptions;
	CacheOptions.bBlocking = true;
	CacheOptions.Priority = 0;

	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(Presenter->GetCombatSeed().SagaType);
	for (EDropBoxType DropBoxType : DropBoxTypes)
	{
		DropBoxCaches.Add(GetGameResource().GetCacheManager()->CacheDropBox(SagaRow.DropBoxSet, DropBoxType, CacheOptions, FGameAssetStreamDelegate()));
	}

	DropBoxTypes.Empty();
}

void UDropBoxSpawner::EnqueueSpawnDropBox(EDropBoxType InDropBoxType, int32 InDropBoxCount, int32 InTotalDropBoxCount, int32 InSpawnStartIndex, FCCUnitId InUnitId, const float InSpawnDelayTime)
{
	FSpawnDropBoxParams SpawnDropBoxParams;
	SpawnDropBoxParams.DropBoxType = InDropBoxType;
	SpawnDropBoxParams.DropBoxCount = InDropBoxCount;
	SpawnDropBoxParams.TotalDropBoxCount = InTotalDropBoxCount;
	SpawnDropBoxParams.SpawnStartIndex = InSpawnStartIndex;
	SpawnDropBoxParams.SourceUnitId = InUnitId;
	SpawnDropBoxParams.SpawnDelayTime = InSpawnDelayTime + GetWorld()->GetTimeSeconds();

	GetDropBoxAsset(SpawnDropBoxParams);

	ReservedSpawnDropBoxParams.Add(SpawnDropBoxParams);
}

void UDropBoxSpawner::GatherDropBoxes(const TArray<FItemDropInfo>& InItemDropInfos, int32 InUnitSlot, TMap<EDropBoxType, int32>& OutDropBoxes, int32& OutGainGold, int32& OutTotalDropBoxCount)
{
	const int32 CurrentWaveIndex = GetCheckedCombatPresenter(this)->GetWave() - 1;

	for (const FItemDropInfo& ItemDropInfo : InItemDropInfos)
	{
		if (ItemDropInfo.WaveIndex == CurrentWaveIndex && ItemDropInfo.Slot == InUnitSlot)
		{
			for (const auto& DropBox : ItemDropInfo.DropBoxes)
			{
				EDropBoxType DropBoxType = (EDropBoxType)DropBox.Key;
				int32* FoundDropBox = OutDropBoxes.Find(DropBoxType);
				if (!FoundDropBox)
				{
					OutDropBoxes.Add(DropBoxType, DropBox.Value);
				}
				else
				{
					*FoundDropBox += DropBox.Value;
				}

				OutTotalDropBoxCount += DropBox.Value;
			}

			OutGainGold += ItemDropInfo.GainGold;
		}
	}
}

void UDropBoxSpawner::GatherDropBoxTypes(const TArray<FItemDropInfo>& InItemDropInfos, TSet<EDropBoxType>& OutDropBoxTypes)
{
	int32 GainGold = 0;
	for (const FItemDropInfo& ItemDropInfo : InItemDropInfos)
	{
		for (const auto& DropBox : ItemDropInfo.DropBoxes)
		{
			EDropBoxType DropBoxType = (EDropBoxType)DropBox.Key;
			OutDropBoxTypes.Add(DropBoxType);
		}

		GainGold += ItemDropInfo.GainGold;
	}

	if (GainGold > 0)
	{
		OutDropBoxTypes.Add(EDropBoxType::Gold);
	}
}

void UDropBoxSpawner::GetDropBoxAsset(FSpawnDropBoxParams& OutParams)
{
	const FCMSSagaRow& SagaRow = GetCMS()->GetSagaRowOrDummy(GetCheckedCombatPresenter(this)->GetCombatSeed().SagaType);
	const FDropBoxTable& DropBoxTable = GetGameResource().GetDropBoxTableAssetRow(SagaRow.DropBoxSet);

	switch (OutParams.DropBoxType)
	{
	case EDropBoxType::NRBox:
		OutParams.SkeletalMesh = DropBoxTable.NRBoxSkeletalMesh.LoadSynchronous();
		OutParams.AnimSequence = DropBoxTable.NRBoxSpawnAnimation.LoadSynchronous();
		OutParams.SpawnDelayTime += DropBoxTable.NRBoxSpawnDelayTime;
		break;

	case EDropBoxType::SRBox:
		OutParams.SkeletalMesh = DropBoxTable.SRBoxSkeletalMesh.LoadSynchronous();
		OutParams.AnimSequence = DropBoxTable.SRBoxSpawnAnimation.LoadSynchronous();
		OutParams.SpawnDelayTime += DropBoxTable.SRBoxSpawnDelayTime;
		break;

	case EDropBoxType::SSRBox:
		OutParams.SkeletalMesh = DropBoxTable.SSRBoxSkeletalMesh.LoadSynchronous();
		OutParams.AnimSequence = DropBoxTable.SSRBoxSpawnAnimation.LoadSynchronous();
		OutParams.SpawnDelayTime += DropBoxTable.SSRBoxSpawnDelayTime;
		break;

	case EDropBoxType::RandomSpawnBox:
		OutParams.SkeletalMesh = DropBoxTable.RandomSpawnBoxSkeletalMesh.LoadSynchronous();
		OutParams.AnimSequence = DropBoxTable.RandomSpawnBoxSpawnAnimation.LoadSynchronous();
		OutParams.SpawnDelayTime += DropBoxTable.RandomSpawnBoxSpawnDelayTime;
		break;

	case EDropBoxType::Gold:
		OutParams.SkeletalMesh = DropBoxTable.GoldSkeletalMesh.LoadSynchronous();
		OutParams.AnimSequence = DropBoxTable.GoldSpawnAnimation.LoadSynchronous();
		OutParams.SpawnDelayTime += DropBoxTable.GoldSpawnDelayTime;
		break;

	default:
		OutParams.SkeletalMesh = DropBoxTable.NRBoxSkeletalMesh.LoadSynchronous();
		OutParams.AnimSequence = DropBoxTable.NRBoxSpawnAnimation.LoadSynchronous();
		OutParams.SpawnDelayTime += DropBoxTable.NRBoxSpawnDelayTime;
		break;
	}
}

EDropBoxType UDropBoxSpawner::GetDropBoxType(EItemGrade InItemGrade)
{
	switch (InItemGrade)
	{
	case EItemGrade::N:
	case EItemGrade::R:
		return EDropBoxType::NRBox;
	case EItemGrade::SR:
		return EDropBoxType::SRBox;
	case EItemGrade::SSR:
		return EDropBoxType::SSRBox;
	}

	return EDropBoxType::NRBox;
}

bool UDropBoxSpawner::IsAlreadySpawnedDropBox(const int32 InWave, const int32 InSlot)
{
	for (const FSpawnedDropBoxHistory& SpawnedDropBoxHistory : SpawnedDropBoxHistories)
	{
		if (SpawnedDropBoxHistory.Wave == InWave && SpawnedDropBoxHistory.Slot == InSlot)
		{
			return true;
		}
	}

	return false;
}

UDropBoxes::UDropBoxes()
	: NextSpawnDropBoxTime(0.0f)
	, bSpawnedAll(false)
{

}

bool UDropBoxes::Update()
{
	UpdateSpawnDropBox();
	UpdateSpawnedDropBox();

	if (bSpawnedAll && SpawnDropBoxInfos.Num() == 0)
	{
		return false;
	}

	return true;
}

void UDropBoxes::EndPlay()
{
	SpawnDropBoxInfos.Empty();
}

void UDropBoxes::UpdateSpawnDropBox()
{
	if (bSpawnedAll)
	{
		return;
	}

	const int32 SpawnedDropBoxNum = SpawnDropBoxInfos.Num();
	if (SpawnedDropBoxNum == SpawnDropBoxParams.DropBoxCount)
	{
		bSpawnedAll = true;
		return;
	}

	if (SpawnedDropBoxNum == 0)
	{
		// first spawn
		SpawnDropBox();
	}
	else if (SpawnedDropBoxNum < SpawnDropBoxParams.DropBoxCount && NextSpawnDropBoxTime <= GetWorld()->GetTimeSeconds())
	{
		// wait to next spawn time
		SpawnDropBox();
	}
}

void UDropBoxes::UpdateSpawnedDropBox()
{
	const float TimeNow = GetWorld()->GetTimeSeconds();

	int32 Index = 0;
	while (SpawnDropBoxInfos.IsValidIndex(Index))
	{
		FSpawnDropBoxInfo& DropBoxInfo = SpawnDropBoxInfos[Index];

		ASkeletalMeshActor* SkeletaMeshActor = DropBoxInfo.Actor;
		if (!SkeletaMeshActor)
		{
			SpawnDropBoxInfos.RemoveAtSwap(Index);
			continue;
		}

		if (DropBoxInfo.SpawnAnimationEndTime < TimeNow)
		{
			SkeletaMeshActor->Destroy();
			SpawnDropBoxInfos.RemoveAtSwap(Index);
			continue;
		}

		++Index;
	}
}

void UDropBoxes::SetSpawnDropBoxParams(const FSpawnDropBoxParams& InParams)
{
	SpawnDropBoxParams = InParams;
}

float UDropBoxes::GetSpawnDropBoxRemainTime() const
{
	if (SpawnDropBoxInfos.Num() == 0)
	{
		return 0.0f;
	}

	const FSpawnDropBoxInfo& SpawnDropBoxInfo = SpawnDropBoxInfos.Last();
	return SpawnDropBoxInfo.SpawnAnimationEndTime - GetWorld()->GetTimeSeconds();
}

void UDropBoxes::SpawnDropBox()
{
	ACombatPresenter* Presenter = GetCheckedCombatPresenter(this);

	AUnit* SourceUnit = Presenter->FindUnit(SpawnDropBoxParams.SourceUnitId);
	check(SourceUnit && SourceUnit->IsDead());

	UCombatGameResource* CombatGameResource = GetCombatGameResource(this);
	if (!CombatGameResource)
	{
		Q6JsonLogPawn(Warning, "UDropBoxes::SpawnDropBox - CombatGameResource does not exist");
		return;
	}

	const float LocationOffset = CombatGameResource->GetDropBoxLocationOffset();

	const FTransform BottomTransform = SourceUnit->GetBottomTransform();
	FVector StartLocation = BottomTransform.GetLocation() + SourceUnit->GetActorRightVector() * (LocationOffset * 0.5f) * (SpawnDropBoxParams.TotalDropBoxCount - 1);

	FActorSpawnParameters SpawnInfo;
	SpawnInfo.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnInfo.ObjectFlags = RF_Transient;

	const int32 SpawnedDropBoxNum = SpawnDropBoxInfos.Num() + SpawnDropBoxParams.SpawnStartIndex;
	FVector Location = StartLocation - SourceUnit->GetActorRightVector() * LocationOffset * SpawnedDropBoxNum;
	FRotator Rotator = BottomTransform.GetRotation().Rotator();

	if (SpawnedDropBoxNum >= 1)
	{
		const float RandomAngleLimitMin = CombatGameResource->GetDropBoxRandomAngleLimitMin();
		const float RandomAngleLimitMax = CombatGameResource->GetDropBoxRandomAngleLimitMax();
		const float RandomAngle = FMath::FRandRange(RandomAngleLimitMin, RandomAngleLimitMax);

		Rotator.Add(0.0f, -RandomAngle, 0.0f);
	}

	ASkeletalMeshActor* Actor = GetWorld()->SpawnActor<ASkeletalMeshActor>(Location, Rotator, SpawnInfo);
	if (!Actor)
	{
		bSpawnedAll = true;
		Q6JsonLogPawn(Warning, "Failed to spawn SkeletalMeshActor.");
		return;
	}

	if (!SpawnDropBoxParams.SkeletalMesh)
	{
		Actor->Destroy();
		bSpawnedAll = true;
		Q6JsonLogPawn(Warning, "Invalid Dropbox SkeletalMesh.");
		return;
	}

	if (!SpawnDropBoxParams.AnimSequence)
	{
		Actor->Destroy();
		bSpawnedAll = true;
		Q6JsonLogPawn(Warning, "Invalid Dropbox AnimSequence.");
		return;
	}

	USkeletalMeshComponent* SkeletalMeshComponent = Actor->GetSkeletalMeshComponent();
	if (!SkeletalMeshComponent)
	{
		Actor->Destroy();
		bSpawnedAll = true;
		Q6JsonLogPawn(Warning, "Invalid Dropbox SkeletalMeshComponent.");
		return;
	}

	SkeletalMeshComponent->SetSkeletalMesh(SpawnDropBoxParams.SkeletalMesh);
	SkeletalMeshComponent->PlayAnimation(SpawnDropBoxParams.AnimSequence, false);

	const float AnimEndTime = SpawnDropBoxParams.AnimSequence->GetPlayLength();

	FSpawnDropBoxInfo SpawnDropBoxinfo;
	SpawnDropBoxinfo.Actor = Actor;
	SpawnDropBoxinfo.SpawnAnimationEndTime = GetWorld()->GetTimeSeconds() + AnimEndTime;
	SpawnDropBoxInfos.Add(SpawnDropBoxinfo);

	NextSpawnDropBoxTime = CombatGameResource->GetDropBoxSpawnTimeOffset() + GetWorld()->GetTimeSeconds();
}
