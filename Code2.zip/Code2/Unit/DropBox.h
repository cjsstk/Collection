// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Animation/SkeletalMeshActor.h"
#include "Containers/CircularQueue.h"
#include "Q6Type.h"

#include "DropBox.generated.h"

enum class EItemGrade : uint8;
struct FItemDropInfo;
class UGameAssetCache;

UENUM(BlueprintType)
enum class EDropBoxType : uint8
{
	None = 0,
	NRBox = 1,
	SRBox = 2,
	SSRBox = 3,
	RandomSpawnBox = 4,
	Gold = 5,
};

USTRUCT()
struct FSpawnDropBoxParams
{
	GENERATED_BODY()

	FSpawnDropBoxParams()
		: DropBoxType(EDropBoxType::None)
		, DropBoxCount(0)
		, TotalDropBoxCount(0)
		, SpawnStartIndex(0)
		, SourceUnitId(CCUnitIdInvalid)
		, SkeletalMesh(nullptr)
		, AnimSequence(nullptr)
		, SpawnDelayTime(0.0f)
	{
	}

	UPROPERTY()
	EDropBoxType DropBoxType;

	UPROPERTY()
	int32 DropBoxCount;

	UPROPERTY()
	int32 TotalDropBoxCount;

	UPROPERTY()
	int32 SpawnStartIndex;

	UPROPERTY()
	FCCUnitId SourceUnitId;

	UPROPERTY()
	USkeletalMesh* SkeletalMesh;

	UPROPERTY()
	UAnimSequenceBase* AnimSequence;

	UPROPERTY()
	float SpawnDelayTime;
};

USTRUCT()
struct FSpawnDropBoxInfo
{
	GENERATED_BODY()

	FSpawnDropBoxInfo()
		: Actor(nullptr)
		, SpawnAnimationEndTime(0.0f)
	{}

	UPROPERTY()
	ASkeletalMeshActor* Actor;

	UPROPERTY()
	float SpawnAnimationEndTime;
};

USTRUCT()
struct FSpawnedDropBoxHistory
{
	GENERATED_BODY()

	FSpawnedDropBoxHistory()
		: Wave(0)
		, Slot(0)
	{}

	FSpawnedDropBoxHistory(int32 InWave, int32 InSlot)
		: Wave(InWave)
		, Slot(InSlot)
	{}

	UPROPERTY()
	int32 Wave;

	UPROPERTY()
	int32 Slot;
};

UCLASS()
class Q6_API UDropBoxSpawner : public UObject
{
	GENERATED_BODY()

public:
	void BeginPlay();
	void EndPlay();
	void Update();

	void SpawnDropBox(FCCUnitId InUnitId);
	float GetSpawnDropBoxRemainTime() const;

	void SynchronizeDropBox();
	void CacheDropBoxAssets();

	EDropBoxType GetDropBoxType(EItemGrade InItemGrade);

private:
	void EnqueueSpawnDropBox(EDropBoxType InDropBoxType, int32 InDropBoxCount, int32 InTotalDropBoxCount, int32 InSpawnStartIndex, FCCUnitId InUnitId, const float InSpawnDelayTime);
	void GetDropBoxAsset(FSpawnDropBoxParams& OutParams);
	void GatherDropBoxes(const TArray<FItemDropInfo>& InItemDropInfos, int32 InUnitSlot, TMap<EDropBoxType, int32>& OutDropBoxes, int32& OutGainGold, int32& OutTotalDropBoxCount);
	void GatherDropBoxTypes(const TArray<FItemDropInfo>& InItemDropInfos, TSet<EDropBoxType>& OutDropBoxTypes);
	bool IsAlreadySpawnedDropBox(const int32 InWave, const int32 InSlot);

	TUniquePtr<TCircularQueue<FSpawnDropBoxParams>> SpawnDropBoxQueue;

	UPROPERTY(Transient)
	TArray<FSpawnDropBoxParams> ReservedSpawnDropBoxParams;

	UPROPERTY(Transient)
	TArray<FSpawnedDropBoxHistory> SpawnedDropBoxHistories;

	UPROPERTY(Transient)
	TArray<UDropBoxes*> SpawnDropBoxes;

	UPROPERTY(Transient)
	TArray<UGameAssetCache*> DropBoxCaches;
};

UCLASS()
class Q6_API UDropBoxes : public UObject
{
	GENERATED_BODY()

public:
	UDropBoxes();

	void EndPlay();
	bool Update();

	void SetSpawnDropBoxParams(const FSpawnDropBoxParams& InParams);
	float GetSpawnDropBoxRemainTime() const;

private:
	void UpdateSpawnDropBox();
	void UpdateSpawnedDropBox();
	void SpawnDropBox();

	UPROPERTY(Transient)
	FSpawnDropBoxParams SpawnDropBoxParams;

	UPROPERTY(Transient)
	TArray<FSpawnDropBoxInfo> SpawnDropBoxInfos;

	UPROPERTY(Transient)
	float NextSpawnDropBoxTime;

	UPROPERTY(Transient)
	bool bSpawnedAll;
};
