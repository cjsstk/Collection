// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMS_gen.h"
#include "CMSType_gen.h"
#include "Q6GameState.h"
#include "Q6Minimal.h"
#include "UnitBase.h"
#include "Unit.generated.h"

class UUnitAnimInstanceBase;
class UUnitAnimInstance;
class UParticleSystemComponent;
struct FSkillAnimHitInfo;
struct FUltimateSkillSequenceAssetRow;

//DECLARE_DYNAMIC_MULTICAST_DELEGATE(FUnitAssetStreamCompleteEvent);

DECLARE_DELEGATE_TwoParams(FParticleEffectNotifyDelegate, const FSpawnParticleParams&, const FSpawnSoundParams&);
DECLARE_DELEGATE_ThreeParams(FFireProjectileNotifyDelegate, const FProjectileEffectDesc&, const FSpawnParticleParams&, const FSpawnSoundParams&);
DECLARE_DELEGATE_TwoParams(FBeamParticleEffectNotifyDelegate, const FBeamParticleEffectDesc&, float);
DECLARE_DELEGATE_OneParam(FNormalSkillSequencePlayDelegate, const FTransform&);
DECLARE_DELEGATE_ThreeParams(FSpawnSkeletalMeshDelegate, const FSpawnSkeletalMeshDesc&, float, bool);

static FORCEINLINE bool IsBossMonsterCategory(EAttributeCategory InCategory)
{
	switch (InCategory)
	{
		case EAttributeCategory::MB_Little:
		case EAttributeCategory::MB_Weak:
		case EAttributeCategory::MB_Middle:
		case EAttributeCategory::MB_Strong:
		case EAttributeCategory::MB_Final:
		case EAttributeCategory::MB_Legend:
			return true;
		default:
			return false;
	}
}

UENUM(BlueprintType)
enum class EUnitMaterialEffectLayer : uint8
{
	Body,
	AnimNotify,
	Hit,
	Overlay, // spawn, dead, rebirth, ccstate
	Max
};

USTRUCT(BlueprintType)
struct FUnitAttributes
{
	GENERATED_BODY()

	FUnitAttributes() :Attack(0), AttackVary(0), AttackVaryPercent(0),
		Defense(0), DefenseVary(0), DefenseVaryPercent(0) {}

	UPROPERTY()
	int32 Attack;

	UPROPERTY()
	int32 AttackVary;

	UPROPERTY()
	int32 AttackVaryPercent;

	UPROPERTY()
	int32 Defense;

	UPROPERTY()
	int32 DefenseVary;

	UPROPERTY()
	int32 DefenseVaryPercent;
};

USTRUCT(BlueprintType)
struct FBuffState
{
	GENERATED_BODY()

	FBuffState() : BuffId(0), BuffType(0), BuffLevel(0), Duration(0), HitCount(0), Multiple(0), BornCategory(ESkillCategory::Normal), SourceUnitId(CCUnitIdInvalid){}
	explicit FBuffState(FCCBuffId InBuffId, int32 InBuffType, int32 InBuffLevel, int32 InDuration, int32 InHitCount, int32 InMultiple, ESkillCategory InBornCategory, FCCUnitId InSourceUnitId)
		: BuffId(InBuffId), BuffType(InBuffType), BuffLevel(InBuffLevel), Duration(InDuration), HitCount(InHitCount), Multiple(InMultiple), BornCategory(InBornCategory), SourceUnitId(InSourceUnitId){}

	UPROPERTY(BlueprintReadOnly)
	FCCBuffId BuffId;

	UPROPERTY(BlueprintReadOnly)
	int32 BuffType;

	UPROPERTY(BlueprintReadOnly)
	int32 BuffLevel;

	UPROPERTY(BlueprintReadOnly)
	int32 Duration;

	UPROPERTY(BlueprintReadWrite)
	int32 HitCount;

	UPROPERTY(BlueprintReadOnly)
	int32 Multiple;

	UPROPERTY(BlueprintReadOnly)
	ESkillCategory BornCategory;

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId SourceUnitId;
};

USTRUCT(BlueprintType)
struct FPointVaryUnitAttributeState
{
	GENERATED_BODY()

	FPointVaryUnitAttributeState() : UnitAttributeType(UnitAttributeTypeInvalid), Value(0) {}
	explicit FPointVaryUnitAttributeState(FUnitAttributeType InUnitAttributeType, int32 InValue)
		: UnitAttributeType(InUnitAttributeType), Value(InValue) {}

	UPROPERTY(BlueprintReadOnly)
	FUnitAttributeType UnitAttributeType;

	UPROPERTY(BlueprintReadOnly)
	int32 Value;
};

USTRUCT(BlueprintType)
struct FSkillState
{
	GENERATED_BODY()

	FSkillState() : SkillType(0), Level(0), Cooldown(0), CoolTime(0), WaitDown(0), WaitTime(0), UsingCount(0), bPattern(false) {}
	explicit FSkillState(FCCSkillId InSkillId, int32 InSkillType, int32 InLevel) :
		SkillId(InSkillId), SkillType(InSkillType), Level(InLevel),
		Cooldown(0), CoolTime(0), WaitDown(0), WaitTime(0), UsingCount(0), bPattern(false) {}

	UPROPERTY(BlueprintReadWrite)
	FCCSkillId SkillId;

	UPROPERTY(BlueprintReadWrite)
	int32 SkillType;

	UPROPERTY(BlueprintReadWrite)
	int32 Level;

	UPROPERTY(BlueprintReadWrite)
	int32 Cooldown;

	UPROPERTY()
	int32 CoolTime;

	UPROPERTY(BlueprintReadWrite)
	int32 WaitDown;

	UPROPERTY()
	int32 WaitTime;

	UPROPERTY()
	int32 UsingCount;

	UPROPERTY()
	bool bPattern;
};

USTRUCT(BlueprintType)
struct FUnitState
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly)
	FCCUnitId UnitId;

	UPROPERTY(BlueprintReadOnly)
	int32 UnitType;

	UPROPERTY(BlueprintReadOnly)
	int32 Slot;

	UPROPERTY(BlueprintReadOnly)
	ECCFaction Faction;

	UPROPERTY(BlueprintReadOnly)
	EAttributeCategory Category;

	UPROPERTY(BlueprintReadOnly)
	int32 Level;

	UPROPERTY(BlueprintReadOnly)
	EItemGrade Grade;

	UPROPERTY(BlueprintReadOnly)
	int64 Health;

	UPROPERTY(BlueprintReadOnly)
	int32 Shield;

	UPROPERTY(BlueprintReadOnly)
	int32 UA;

	UPROPERTY(BlueprintReadOnly)
	int32 SA;

	UPROPERTY(BlueprintReadOnly)
	int32 OverKill;

	UPROPERTY(BlueprintReadOnly)
	int32 MaxHealth;

	UPROPERTY(BlueprintReadOnly)
	int32 MaxShield;

	UPROPERTY(BlueprintReadOnly)
	int32 MaxUA;

	UPROPERTY(BlueprintReadOnly)
	int32 MaxSA;

	UPROPERTY(BlueprintReadOnly)
	ENatureType NatureType;

	UPROPERTY(BlueprintReadOnly)
	TArray<int32> SkillsOnCurPhase;

	UPROPERTY(BlueprintReadOnly)
	bool bSupporter;

	UPROPERTY()
	FSculptureInfo Sculpture;

	UPROPERTY()
	FRelicInfo Relic;

	UPROPERTY(BlueprintReadOnly)
	FUnitAttributes UnitAttributes;

	UPROPERTY(BlueprintReadOnly)
	TArray<FSkillState> Normals;

	UPROPERTY(BlueprintReadOnly)
	TArray<FSkillState> Ultimates;

	UPROPERTY(BlueprintReadOnly)
	TArray<FSkillState> Supports;

	UPROPERTY(BlueprintReadOnly)
	TArray<FSkillState> TurnBegins;

	UPROPERTY(BlueprintReadOnly)
	TArray<FSkillState> Artifacts;

	UPROPERTY(BlueprintReadOnly)
	TArray<FBuffState> Buffs;

	UPROPERTY(BlueprintReadOnly)
	TArray<FPointVaryUnitAttributeState> PointVaryUnitAttributes;

	UPROPERTY(BlueprintReadOnly)
	ECombatMultiSide CombatMultiSide;

	UPROPERTY(BlueprintReadOnly)
	int32 SpawnedWaveIndex;
};

USTRUCT()
struct FBuffEffectState
{
	GENERATED_BODY()

	FBuffEffectState()
		: EffectType(BuffEffectTypeInvalid), bLocked(false)
	{}
	explicit FBuffEffectState(FBuffEffectType InEffectType, bool bInLocked)
		: EffectType(InEffectType), bLocked(bInLocked)
	{}

	bool operator==(const FBuffEffectState& Other) const { return EffectType == Other.EffectType; }
	bool operator!=(const FBuffEffectState& Other) const { return EffectType != Other.EffectType; }

	FBuffEffectType EffectType;
	bool bLocked;
};

USTRUCT(BlueprintType)
struct FCCBuffCoolTime
{
	GENERATED_USTRUCT_BODY()

	FCCBuffCoolTime()
	{
		CCDuration = -1;
		bInfinity = false;
	}

	UPROPERTY()
	int32 CCDuration;

	UPROPERTY()
	bool bInfinity;
};

USTRUCT()
struct FCCStateEffect
{
	GENERATED_USTRUCT_BODY()

	FCCStateEffect()
		: CCType(CrowdControlTypeInvalid)
		, CCStateMaterial(nullptr)
		, CCStateParticleComponent(nullptr)
	{}

	bool HasMaterialEffect() const { return CCStateMaterial != nullptr; }
	bool HasParticleEffect() const { return CCStateParticleComponent != nullptr; }
	bool IsValid() const { return HasMaterialEffect() || HasParticleEffect(); }

	void SetEmpty();

	FCrowdControlType CCType;

	UPROPERTY(Transient)
	UMaterialInterface* CCStateMaterial;

	UPROPERTY(Transient)
	UParticleSystemComponent* CCStateParticleComponent;
};

/**
 * Unit
 */
UCLASS(ConversionRoot)
class Q6_API AUnit : public AUnitBase
{
	GENERATED_BODY()

public:
	AUnit(const FObjectInitializer& ObjectInitializer);

#if WITH_EDITOR
	virtual void PostEditChangeProperty(struct FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual void RerunConstructionScripts() override;
#endif

	virtual void SetActorHiddenInGame(bool bNewHidden) override;
	virtual void Tick(float DeltaTime) override;

	// Init with params
	void InitUnit(int32 InUnitType, FUnitInitParams InInitParams = FUnitInitParams());
	virtual void InitFromUnitState(const FUnitState& InUnitState, bool bInAnimRelaxed, bool bBlockingLoad = false);

	// Attach to Mesh Component.
	bool IsAttached() const;
	void AttachUnitTo(UStaticMeshComponent* ParentMeshComponent, const FName& SocketName);
	void DetachAndReturnToInitialPosition();

	void PlayPrepareSpawnAnimation();
	void StopPrepareSpawnAnimation();

	// Setters
	void SetHealth(int32 NewHealth) { UnitState.Health = FMath::Clamp(NewHealth, 0, UnitState.MaxHealth); }
	void SetShield(int32 NewShield) { UnitState.Shield = FMath::Clamp(NewShield, 0, UnitState.MaxShield); }
	void SetMaxShield(int32 NewMaxShield) { UnitState.MaxShield = UnitState.Shield = NewMaxShield; }
	void SetUA(int32 NewUA) { UnitState.UA = NewUA; }
	void SetSA(int32 NewSA) { UnitState.SA = NewSA; }
	void SetOverKill(int32 NewOverKill) { UnitState.OverKill = NewOverKill; }
	void SetSkillCooldown(const FCCSkillId& Id, int32 Cooldown);
	void SetSkillWaitdown(const FCCSkillId& Id, int32 Waitdown);
	void SetBuffDuration(int32 BuffType, int32 Duration);
	void SetNature(ENatureType InNatureType);
	void SetSupporter(bool bSupporter) { UnitState.bSupporter = bSupporter; }
	void AddBuff(const FBuffState& BuffState);
	void UpdateBuff(const FBuffState& InBuffState);
	void RemoveBuff(FCCBuffId BuffId);
	void SortBuffsByDuration();
	void AddPointVaryUnitAttribute(EPointVaryConvertType InPointVaryUnitAttributeType, int32 InValue);
	bool ClearPointVaryUnitAttributes();
	void UpdateUnitAttributes(FUnitAttributeType UnitAttributeType, int32 InAmount);
	void SetBaseTransform(const FTransform& InTransform);
	void IncreaseSkillUsingCount(FCCSkillId InId);

	// shift enemie's ultimates when first ult used. (copy combatcube)
	bool ShiftUltimateSkillStats();

	// Getters
	virtual AUnit* GetSourceUnit() const { return const_cast<AUnit*>(this); }
	FCCUnitId GetUnitId() const { return UnitState.UnitId; }
	float GetBoundRadius() const { return BoundRadius; }
	ECCFaction GetOverrideFaction() const { return OverrideFaction; }
	bool IsEnemy() const { return OverrideFaction == ECCFaction::Enemy; }
	bool HasVersaBuff() const;

	bool IsDead() const { return UnitState.Health == 0; }
	bool IsSupporter() const { return UnitState.bSupporter; }
	bool HasSupportSkills() const { return !IsDead() && UnitState.Supports.IsValidIndex(0); }
	bool HasUltimateSkills() const;
	int32 GetFirstSupportSkillType() const { return HasSupportSkills() ? UnitState.Supports[0].SkillType : SkillTypeInvalid.x; }
	int32 GetFirstUltimateSkillType() const { return HasUltimateSkills() ? UnitState.Ultimates[0].SkillType : SkillTypeInvalid.x; }
	int32 GetUltimateSkillCount() const { return UnitState.Ultimates.Num(); }
	void GetNextUltimateSkillWaitdown(int32& OutSkillWaitdown, int32* OutInitialWaitdown = nullptr) const;
	virtual const FUltimateSkillSequenceAssetRow& GetUltimateSkillSequenceAssetRow(int32 InSkillType, bool bInAddMissingLog = true) const;

	int32 GetSlot() const { return UnitState.Slot; }
	int32 GetHealth() const { return UnitState.Health; }
	int32 GetMaxHealth() const { return UnitState.MaxHealth; }
	int32 GetShield() const { return UnitState.Shield; }
	int32 GetMaxShield() const { return UnitState.MaxShield; }
	int32 GetUA() const { return UnitState.UA; }
	int32 GetSA() const { return UnitState.SA; }
	int32 GetMaxUA() const { return UnitState.MaxUA; }
	int32 GetMaxSA() const { return UnitState.MaxSA; }

	const FUnitState& GetUnitState() const { return UnitState; }
	ENatureType GetNature() const { return UnitState.NatureType; }

	// combat multi side
	ECombatMultiSide GetCombatMultiSide() const { return UnitState.CombatMultiSide; }
	int32 GetSpawnedWaveIndex() const { return UnitState.SpawnedWaveIndex; }

	void GatherCCBuffEffectsOnPhase(TArray<FBuffEffectState>& Out, ECPTurnPhase Phase) const;
	void GatherCCBuffEffectsOnSkillUse(TArray<FBuffEffectState>& Out, ESkillCategory SkillCategory) const;
	void GatherCCBuffEffects(TArray<FBuffEffectState>& Out, ECrowdControl InCC) const;
	bool HasCCBuffEffect(ECrowdControl InCC) const;
	FCCBuffCoolTime GetCCBuffCoolTime() const;

	FBuffType GetBuffType(const FCCBuffId& InBuffId) const;
	FCCUnitId GetProvokeTargetUnitId() const;

	FTransform GetBottomTransform() const;
	virtual FTransform GetSocketTransform(const FName Socket) const;

	// Streaming
	virtual void StreamLoadAsset() override;

	// Animation
	FTransform GetMultiLayerAttachmentTransform() const;
	FTransform GetMultiLayerAttachmentLightTransform() const;
	virtual float GetTurnSkillAnimLength() const;
	virtual float GetDeadAnimLength() const;
	virtual void GetSkillAnimNotifyInfo(int32 InSkillType, TArray<FSkillAnimHitInfo>& OutSkillAnimHitInfo);

	virtual void StartSpawnFX(ESpawnReason InReason);

	void StartParticleEffects(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam);

	void StartBuffEffectFX(const FBuffType InBuffType);
	void StartBuffEffectFX(const FBuffEffectType InBuffEffectType);
	void StopBuffEffectFX(const FBuffType InBuffType);

	void StartLootEffectFX();

	void SetCCStateEffectsHidden(bool bInHidden);

	virtual void SetSequenceAnimMode(bool bSeqAnimMode) override;
	void SetAnimRelaxed(bool bRelaxed);

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void SetAnimPaused(bool bInPaused);

	virtual void SetStunned(bool bInStunned);
	virtual void SetMoving(bool bInMoving);
	virtual void SetDead();
	virtual void SetHit(const FSpawnParticleParams& ParticleParam, const FSpawnSoundParams& SoundParam);
	virtual void SetShieldHit(bool bBroken);

	ESkillNote GetSkillNote() const;
	void SetSkillNote(ESkillNote InSkillNote);
	void SetDoubleSkillFollowing(bool bIsFollowing);
	virtual void SetUltimateSkillState(bool bIsOn);
	virtual void SetTurnSkillIndex(int32 InIndex);

	virtual void PlayNormalSkill(const FVector& InTargetLocation, bool bIsDouble);
	virtual void PlayTurnSkill();
	virtual void PlayShout();
	virtual void PlayHit();

	void OnAnimNotifyMove(float DistanceLeft, bool bBackward, float TotalDuration);

	void OnAnimNotifyHit(const FSpawnParticleParams& ParticleParams, const FSpawnSoundParams& SoundParams);
	void OnAnimNotifyFireProjectile(const FProjectileEffectDesc& Desc, const FSpawnParticleParams& ParticleParams, const FSpawnSoundParams& SoundParams);

	void OnAnimNotifyPlayBeamParticleEffect(const FBeamParticleEffectDesc& Desc, float TotalDuration);
	void OnAnimNotifyPlayParticleEffectOnTarget(const FSpawnParticleParams& ParticleParams, const FSpawnSoundParams& SoundParams);

	void OnAnimNotifySpawnSkeletalMesh(const FSpawnSkeletalMeshDesc& Desc, float Duration, bool bTarget);

	// Rotation
	virtual void RotateToTargetUnit(const AUnit* InTargetUnit);
	virtual void RotateToLocation(const FVector& InLocation);
	virtual void UpdateRotationToEnd();

	// Movement
	FVector GetMoveTargetLocation(const AUnit* InTargetUnit) const;
	void MoveToWave(const FTransform& InWaveTransform);

	// Visual Effects
	UFUNCTION(BlueprintCallable, Category = "Effect")
	void SetMaterialEffectBP(EUnitMaterialEffectLayer Layer, UMaterialInterface* Material, float InDuration = -1.0f);
	void SetMaterialEffect(EUnitMaterialEffectLayer Layer, UMaterialInterface* Material, float Duration = -1.0f);

	void ClearMaterialEffect();
	void ClearSubMaterialEffect();
	virtual void SetSubMaterialEffect(const FSubMaterialEffectParams& SubMaterialParams, int32 Mask = -1);

	virtual UParticleSystemComponent* SpawnParticle(const FSpawnParticleParams& ParticleParam);
	UParticleSystemComponent* SpawnParticleInternal(const FSpawnParticleParams& ParticleParam, FName AttachPointName);

	// Decal
	void SetShadowDecalMode(ECCFaction Mode, bool bOn);

	bool IsInvisibleDropBox() const { return bInvisibleDropBox; }

	void TurnSkillOverrideMaterialParamters(bool bOverride);

	// Sound
	void SetMuteDeadVoice(bool bInMuteDeadVoice) { bMuteDeadVoice = bInMuteDeadVoice; }
	bool IsMuteDeadVoice() const { return bMuteDeadVoice; }

	void SynchronizeUnitState();

protected:
	virtual void InitFromDesc();
	virtual void InitMesh() override;

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifySkillStart();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifySkillEnd();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyTurnSkillEnd();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyShoutEnd();

	void UpdateTargetTransform(const FVector& InLocation, bool bFinal);

	void SetDeadInternal(UUnitAnimInstanceBase* InAnimInstance);

	void OnSpawnMaterialEffectEnd();
	void OnDeadMaterialEffectStart();
	void OnDeadMaterialEffectEnd();
	void OnDeadAnimEnd();

	void TickMaterialEffect(float DeltaSeconds);

	void ClearCCStateEffect();
	void ClearShadowDecal();

private:
	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyStartCameraSequence();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyRunStart();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyRelaxed();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyUnrelaxed();

	void OnMoveEnd(bool bSetActorTransform = false);

	void ClearIntermediateState();
	void ClearTransforms();

	// Physics
	void CreatePhysicsState();
	void DestroyPhysicsState();

	FTransform GetSocketComponentSpaceRefTransform(const FName Socket) const;

	// Animation
	UUnitAnimInstance* GetUnitAnimInstance() const;
	virtual void LoadAnimations() override;
	virtual void LoadSkillSequences() override {}

	// Rotation
	void RotateToTargetRotation();
	void TickRotation(float DeltaSeconds, FTransform& InOutCurTargetTransform);

	// Movement
	void MoveToTargetLocation();
	void UpdateMoveTime(float InMoveTime = 0.f);
	void TickMovement(float DeltaSeconds, FTransform& InOutCurTargetTransform);

	// Material
	void InitDefaultMaterials();
	void ApplyMaterialEffect();
	virtual void ApplyMaterialOverride(UMaterialInterface* OverrideMaterial);

	// Particle
	void StartDeadFX();

	void StartCCFX(const FCrowdControlType InCCType);
	void StopCCFX(const FCrowdControlType InCCType);

	void StartUnitAttrFX(bool bInDemerit);

	bool HasCCStateEffect(const FCrowdControlType InCCType) const;
	int32 GetNextCCStateIndex() const;
	void UpdateCCStateEffectsScale(float InMultiplier);
	void TickCCStates(float DeltaSeconds);

	// Decal
	void ApplyDecalMode();

public:
	FNormalSkillSequencePlayDelegate NormalSkillSequencePlayDelegate;

	FSimpleDelegate AnimSkillEndDelegate;
	FSimpleDelegate AnimMoveEndDelegate;
	FSimpleDelegate AnimTurnSkillEndDelegate;
	FSimpleDelegate AnimShoutEndDelegate;
	FSimpleDelegate AnimRelaxedDelegate;
	FSimpleDelegate AnimUnrelaxedDelegate;

	FParticleEffectNotifyDelegate AnimHitDelegate;
	FFireProjectileNotifyDelegate AnimFireProjectileDelegate;
	FBeamParticleEffectNotifyDelegate AnimPlayBeamParticleEffectDelegate;
	FParticleEffectNotifyDelegate AnimPlayParticleEffectOnTargetDelegate;
	FSpawnSkeletalMeshDelegate AnimNotifySpawnSkeletalMeshDelegate;

	FSimpleDelegate SpawnEffectFinishedDelegate;
	FSimpleDelegate DeadEffectFinishedDelegate;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = Unit)
	ECCFaction OverrideFaction;

	// Material Effects
	UPROPERTY(Transient)
	TArray<UMaterialInterface*> DefaultMeshMaterials;

	UPROPERTY(Transient)
	UMaterialInterface* EffectMaterials[(int32)EUnitMaterialEffectLayer::Max];

	float EffectMaterialAgeSeconds[(int32)EUnitMaterialEffectLayer::Max];
	float EffectMaterialDurationSeconds[(int32)EUnitMaterialEffectLayer::Max];

	// Timer Handles
	FTimerHandle SpawnEffectTimerHandle;
	FTimerHandle DeadEffectTimerHandle;
	FTimerHandle DeadAnimTimerHandle;

	int32 CommonEffectIndex;

	bool bAnimPaused;
	bool bSkillAnimHasSequenceStart;

private:
	FUnitState UnitState;

	float SubMaterialAgeSecond;

	// Transforms
	UPROPERTY(Transient)
	FTransform BaseTransform;

	UPROPERTY(Transient)
	FTransform InitialTransform;

	UPROPERTY(Transient)
	FTransform TargetTransform;

	UPROPERTY(Transient)
	FTransform FinalTargetTransform;

	UPROPERTY(Transient)
	FQuat RotateStartRotation;

	UPROPERTY(Transient)
	FVector MoveStartLocation;

	bool bRotatable;
	bool bInvisibleDropBox;

	bool bAnimRelaxed;
	bool bRotating;
	bool bMoving;
	bool bSkipMoveBack;
	bool bCCStateEffectsHidden;

	float RotateStartTime;
	float MoveStartTime;
	float MoveTime;

	// CC State
	UPROPERTY(Transient)
	TArray<FCCStateEffect> CCStateEffects;

	int32 LastUpdatedCCStateEffectIndex;
	float LastCCStateUpdateTime;

	// Decal Mode
	bool DecalMode[(int32)ECCFaction::Max];

	// Sound - PlayCharacterVoice
	UPROPERTY()
	bool bMuteDeadVoice;
};
