// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "Q6Minimal.h"
#include "UnitBase.h"
#include "LobbyTemplate.h"
#include "MenuUnit.generated.h"

class USpringArmComponent;
class UUnitAnimInstance;
struct FCharacterType;
enum class ECharacterVoiceCategory : uint8;
enum class EHUDWidgetType : uint8;

/**
 * Unit used outside combat
 */
UCLASS()
class Q6_API AMenuUnit : public AUnitBase
{
	GENERATED_BODY()
	
public:
	friend class ULobbyCharacterComponent;

	AMenuUnit(const FObjectInitializer& ObjectInitializer);

	void InitCharacterUnit(FCharacterType InCharacterType, EHUDWidgetType InHUDWidgetType, bool bInOwned);
	void InitDefaultFocusing();

	USpringArmComponent* GetSpringArm() const { return SpringArm; }
	void AddTargetArmLength(float Length);

	bool IsLoaded() const;

	bool IsInFullView() const { return bFullView; }
	void SetFullView(bool bInFullView);

	bool IsBlack() const { return bBlackMaterial; }

	void ClearUnit();
	void RotateUnit(float ScrollVelocity);

	void InputDragged(const FVector2D& DeltaLocation, float ScrollVelocity);

	void SetPreviewVoice(TSoftObjectPtr<USoundBase> InVoiceSound) { VoiceSound = InVoiceSound; }
	bool PlayPreviewAnimation(ECharacterVoiceCategory InVoiceCategory);
	void StopPreviewAnimation();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyPlayVoice();

	UFUNCTION(BlueprintCallable, Category = "Animation")
	void OnAnimNotifyPreviewAnimEnd();

	void OnTouched();

	FSimpleDelegate OnPreviewAnimEndDelegate;

protected:
	virtual void InitMesh() override;

private:
	void SetBlackMaterial();
	void PostCodexUnitInitMesh();

	FVector CalcOffsetFromArmLength() const;
	void SetSpringArmOffset(const FVector& Offset, const FVector& Min, const FVector& Max);

	UUnitAnimInstance* GetUnitAnimInstance() const;
	virtual void LoadAnimations() override;

	void PlayAnimAsMontage(UAnimSequenceBase* Anim, bool bLoop, float BlendInTime = 0.f, float BlendOutTime = 0.f);
	void OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted);

	UPROPERTY(Transient)
	USpringArmComponent* SpringArm;

	UPROPERTY(Transient)
	TSoftObjectPtr<USoundBase> VoiceSound;

	UPROPERTY(Transient)
	ULobbyAnimationHelper* CodexAnimationHelper;

	FVector FaceFocusingOffset;
	FVector BodyFocusingOffset;
	FVector BottomFocusingOffset;

	float ArmLengthMin;
	float ArmLengthMax;

	FCharacterType CharacterType;
	EHUDWidgetType HUDWidgetType;

	bool bFullView;
	bool bBlackMaterial;
};
