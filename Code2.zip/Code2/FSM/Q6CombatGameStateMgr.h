#pragma once

#include "Q6Minimal.h"
#include "FSM/Q6FSMSystem.h"
#include "Q6CombatGameStateMgr.generated.h"

enum class ECombatGameTransition : uint8;
enum class ECombatStageState : uint8;
enum class ECombatWaveState : uint8;
enum class ECombatTurnState : uint8;
enum class ECombatSkillState : uint8;

// CombatPresenter Event
class UCCEvent;

// FSM States
class FQ6CGSStageNA;
class FQ6CGSStage;
class FQ6CGSWaveNA;
class FQ6CGSWave;
class FQ6CGSTurnNA;
class FQ6CGSTurn;
class FQ6CGSSkillNA;
class FQ6CGSSkill;

// Container
class ACombatPresenter;
class ACombatLocator;

// Multilayer FSM
// States of each layer can block other layer's states
UCLASS()
class UQ6CombatGameStateMgr : public UObject
{
	GENERATED_BODY()
public:
	virtual ~UQ6CombatGameStateMgr();

	void InitFSM(ACombatPresenter* InContainer);
	void Update(float DeltaTime);

	bool HandleInput(const UCCEvent* Event);
	bool AdvanceFSM(ECombatGameTransition Input, const UCCEvent* Event);

	// Callback functions
	// FSM state change
	void StartGame(const UCCEvent* Event);
	void FinishGame(const UCCEvent* Event);
	void StartWave(const UCCEvent* Event);
	void FinishWave(const UCCEvent* Event);
	void StartTurn(const UCCEvent* Event);
	// Game event callbacks
	void EmptyGameEvent(const UCCEvent* Event);
	void HandleGameEvent(const UCCEvent* Event);

	bool IsFirtInstanceBlocking() const;
	bool IsSkillInstanceBlocking() const;
	bool IsSkillInstanceCompatableEvent(const UCCEvent* Event) const;

	// chronicle setter
	void SetTurnSkillState();

	// Stage
	TSharedPtr<FQ6CGSStageNA> StStageNA;
	TSharedPtr<FQ6CGSStage> StStage;
	// Wave
	TSharedPtr<FQ6CGSWaveNA> StWaveNA;
	TSharedPtr<FQ6CGSWave> StWave;
	// Turn
	TSharedPtr<FQ6CGSTurnNA> StTurnNA;
	TSharedPtr<FQ6CGSTurn> StTurn;
	// Skill
	TSharedPtr<FQ6CGSSkillNA> StSkillNA;
	TSharedPtr<FQ6CGSSkill> StSkill;

	// Getter
	ACombatPresenter* GetCombatPresenter() const { return Container; }

private:
	void InitStageFSM();
	void InitWaveFSM();
	void InitTurnFSM();
	void InitSkillFSM();

	// FMSs
	TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatStageState, const UCCEvent*>> StageFSM;
	TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatWaveState, const UCCEvent*>> WaveFSM;
	TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatTurnState, const UCCEvent*>> TurnFSM;
	TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatSkillState, const UCCEvent*>> SkillFSM;

	// Container
	UPROPERTY(Transient)
	ACombatPresenter* Container;
};
