#pragma once
#include "FSM/Q6FSMState.h"
#include "Q6Define.h"

class UCCEvent;

enum class ECombatGameTransition : uint8;
class UQ6CombatGameStateMgr;

enum class ECCTurnPhase : uint8;
class AUnit;

enum class ECombatStageState : uint8
{
	NA = 0,
	Stage,
};

enum class ECombatWaveState : uint8
{
	NA = 0,
	Wave,
};

enum class ECombatTurnState : uint8
{
	NA = 0,
	Turn,
};

enum class ECombatSkillState : uint8
{
	NA = 0,
	Skill,
};

///////////////////////////////////////////////////////////////////////////////////////////
// Stage stages

class FQ6CGSStageNA : public FQ6FSMState<ECombatGameTransition, ECombatStageState, const UCCEvent*>
{
public:
	FQ6CGSStageNA(ECombatStageState Id, UQ6CombatGameStateMgr& InContainer);

	virtual void OnEnter(const UCCEvent*) override;
	virtual void Update(float DeltaTime) override {}
	virtual void OnExit(const UCCEvent*) override;
	virtual bool IsAllowReEnter() const override { return true; }

private:
	UQ6CombatGameStateMgr& Container;
};

class FQ6CGSStage : public FQ6FSMState<ECombatGameTransition, ECombatStageState, const UCCEvent*>
{
public:
	FQ6CGSStage(ECombatStageState Id, UQ6CombatGameStateMgr& InContainer);

	virtual void OnEnter(const UCCEvent*) override;
	virtual void Update(float DeltaTime) override {}
	virtual void OnExit(const UCCEvent*) override {}
	virtual bool IsAllowReEnter() const override { return true; }
	virtual bool IsBlocked(const UCCEvent*) const override;

private:
	UQ6CombatGameStateMgr& Container;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Wave states

class FQ6CGSWaveNA : public FQ6FSMState<ECombatGameTransition, ECombatWaveState, const UCCEvent*>
{
public:
	FQ6CGSWaveNA(ECombatWaveState Id, UQ6CombatGameStateMgr& InContainer);

	virtual void OnEnter(const UCCEvent*) override {}
	virtual void Update(float DeltaTime) override {}
	virtual void OnExit(const UCCEvent*) override {}
	virtual bool IsBlocked(const UCCEvent*) const override;

private:
	UQ6CombatGameStateMgr& Container;
};

class FQ6CGSWave : public FQ6FSMState<ECombatGameTransition, ECombatWaveState, const UCCEvent*>
{
public:
	FQ6CGSWave(ECombatWaveState Id, UQ6CombatGameStateMgr& InContainer);

	virtual void OnEnter(const UCCEvent*) override;
	virtual void Update(float DeltaTime) override {}
	virtual void OnExit(const UCCEvent*) override;
	virtual bool IsAllowReEnter() const override { return true; }
	virtual bool IsBlocked(const UCCEvent*) const override;

private:
	UQ6CombatGameStateMgr& Container;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Turn states

class FQ6CGSTurnNA : public FQ6FSMState<ECombatGameTransition, ECombatTurnState, const UCCEvent*>
{
public:
	FQ6CGSTurnNA(ECombatTurnState Id, UQ6CombatGameStateMgr& InContainer);
	virtual void OnEnter(const UCCEvent*) override {}
	virtual void Update(float DeltaTime) override {}
	virtual void OnExit(const UCCEvent*) override {}
	virtual bool IsBlocked(const UCCEvent*) const override;

private:
	UQ6CombatGameStateMgr& Container;
};

class FQ6CGSTurn : public FQ6FSMState<ECombatGameTransition, ECombatTurnState, const UCCEvent*>
{
public:
	FQ6CGSTurn(ECombatTurnState Id, UQ6CombatGameStateMgr& InContainer);

	virtual void OnEnter(const UCCEvent*) override;
	virtual void Update(float DeltaTime) override {}
	virtual void OnExit(const UCCEvent*) override;
	virtual bool IsAllowReEnter() const override { return true; }
	virtual bool IsBlocked(const UCCEvent*) const override;

	void DetachAllyUnits();

	void PickUnit(FCCUnitId InUnitId, bool bPlaySpawnAnim);
	FCCUnitId GetRestoreTargetUnitId();

private:
	void SetShowCameraLayer(bool bInShow);
	void AttachAllyUnits();
	void AttachAllyUnit(AUnit* InUnit);

private:
	TArray<FCCUnitId> AttachedUnitIds;
	FCCUnitId PickedUnitId;

	UQ6CombatGameStateMgr& Container;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Skill states

class FQ6CGSSkillNA : public FQ6FSMState<ECombatGameTransition, ECombatSkillState, const UCCEvent*>
{
public:
	FQ6CGSSkillNA(ECombatSkillState Id, UQ6CombatGameStateMgr& InContainer);
	virtual void OnEnter(const UCCEvent*) override {}
	virtual void Update(float DeltaTime) override {}
	virtual void OnExit(const UCCEvent*) override {}
	virtual bool IsBlocked(const UCCEvent*) const override;

private:
	UQ6CombatGameStateMgr& Container;
};

class FQ6CGSSkill : public FQ6FSMState<ECombatGameTransition, ECombatSkillState, const UCCEvent*>
{
public:
	FQ6CGSSkill(ECombatSkillState Id, UQ6CombatGameStateMgr& InContainer);

	virtual void OnEnter(const UCCEvent*) override;
	virtual void Update(float DeltaTime) override;
	virtual void OnExit(const UCCEvent*) override;
	virtual bool IsAllowReEnter() const override { return true; }
	virtual bool IsBlocked(const UCCEvent*) const override;

private:
	UQ6CombatGameStateMgr& Container;
};
