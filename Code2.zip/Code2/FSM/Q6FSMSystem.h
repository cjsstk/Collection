#pragma once
#include "Q6FSMState.h"

template<typename Transition, typename StateID, typename TParam>
class FQ6FSMSystem
{
public:
	FQ6FSMSystem() {}
	~FQ6FSMSystem() {}

	StateID GetCurrentStateID() { return CurrentState->GetID(); }
	TWeakPtr<FQ6FSMState<Transition, StateID, TParam>> GetCurrentState() { return CurrentState; }

	void AddState(TSharedPtr<FQ6FSMState<Transition, StateID, TParam>> S)
	{
		if (!S.IsValid())
		{
			return;
		}

		if (States.Num() == 0)
		{
			States.Add(S->GetID(), S);
			CurrentState = S;
			return;
		}

		if (ensure(!States.Contains(S->GetID())))
		{
			States.Add(S->GetID(), S);
		}
	}

	void RemoveState(StateID Id)
	{
		if (ensure(States.Contains(Id)))
		{
			States.Remove(Id);
		}
	}

	bool TryAdvance(Transition Trans, StateID& Id, TParam Param)
	{
		if (!CurrentState.IsValid())
		{
			return false;
		}

		return CurrentState->TryTransition(Trans, Id, Param);
	}

	bool Advance(Transition Trans, StateID& Id, TParam Param)
	{
		if (TryAdvance(Trans, Id, Param))
		{
			// Reset the state to its desired condition before it can reason or act
			CurrentState->OnExit(Param);

			// Update the currentState
			CurrentState = States[Id];
			CurrentState->OnEnter(Param);
			return true;
		}

		return false;
	}

	void Update(float DeltaTime)
	{
		if (CurrentState.IsValid())
		{
			CurrentState->Update(DeltaTime);
		}
	}

	void SetCurrentState(StateID& InId)
	{
		CurrentState = States[InId];
	}

private:
	TSharedPtr<FQ6FSMState<Transition, StateID, TParam>> CurrentState;
	TMap<StateID, TSharedPtr<FQ6FSMState<Transition, StateID, TParam>> > States;
};
