#pragma once
#include "Q6Minimal.h"

enum class ECombatGameTransition : uint8
{
	NA = 0,

	StartStage,
	HandleGameEvent,
	FinishStage,

	StartWave,
	FinishWave,

	StartTurn,
	HandleTurn,
	FinishTurn,

	UseSkill,
	FinishSkill,
};
