#include "Q6CombatGameStateMgr.h"

#include "CCEvent.h"
#include "CombatPresenter.h"
#include "CPInstances.h"
#include "FSM/Q6FSMSystem.h"
#include "LevelUtil.h"
#include "Q6.h"
#include "Q6CombatGameTransition.h"
#include "Q6CombatGameState.h"
#include "Q6Log.h"

//////////////////////////////////////////////////////////////////////////////////
// Constructor & Destructor

UQ6CombatGameStateMgr::~UQ6CombatGameStateMgr()
{
}

//////////////////////////////////////////////////////////////////////////////////
// Initialize FSM states and FSM Systems

void UQ6CombatGameStateMgr::InitFSM(ACombatPresenter* InContainer)
{
	Container = InContainer;

	InitStageFSM();
	InitWaveFSM();
	InitTurnFSM();
	InitSkillFSM();
}

void UQ6CombatGameStateMgr::InitStageFSM()
{
	// States
	StStageNA = MakeShareable(new FQ6CGSStageNA(ECombatStageState::NA, *this));
	StStage = MakeShareable(new FQ6CGSStage(ECombatStageState::Stage, *this));

	// Transition
	StStageNA->AddTransition(ECombatGameTransition::StartStage, StStage->GetID());
	StStageNA->AddTransition(ECombatGameTransition::HandleGameEvent, StStageNA->GetID());
	StStage->AddTransition(ECombatGameTransition::HandleGameEvent, StStage->GetID());
	StStage->AddTransition(ECombatGameTransition::FinishStage, StStageNA->GetID());

	// FSM System
	StageFSM = TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatStageState, const UCCEvent*>>(
		new FQ6FSMSystem<ECombatGameTransition, ECombatStageState, const UCCEvent*>());

	// Add Transition
	StageFSM->AddState(StStageNA);
	StageFSM->AddState(StStage);
}

void UQ6CombatGameStateMgr::InitWaveFSM()
{
	// States
	StWaveNA = MakeShareable(new FQ6CGSWaveNA(ECombatWaveState::NA, *this));
	StWave = MakeShareable(new FQ6CGSWave(ECombatWaveState::Wave, *this));

	// Transition
	StWaveNA->AddTransition(ECombatGameTransition::StartWave, StWave->GetID());
	StWave->AddTransition(ECombatGameTransition::StartWave, StWave->GetID());
	StWave->AddTransition(ECombatGameTransition::FinishWave, StWaveNA->GetID());

	// FSM System
	WaveFSM = TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatWaveState, const UCCEvent*>>(
		new FQ6FSMSystem<ECombatGameTransition, ECombatWaveState, const UCCEvent*>());

	// Add Transition
	WaveFSM->AddState(StWaveNA);
	WaveFSM->AddState(StWave);
}

void UQ6CombatGameStateMgr::InitTurnFSM()
{
	// States
	StTurnNA = MakeShareable(new FQ6CGSTurnNA(ECombatTurnState::NA, *this));
	StTurn = MakeShareable(new FQ6CGSTurn(ECombatTurnState::Turn, *this));

	// Transition
	StTurnNA->AddTransition(ECombatGameTransition::StartTurn, StTurn->GetID());
	StTurn->AddTransition(ECombatGameTransition::StartTurn, StTurn->GetID());
	StTurn->AddTransition(ECombatGameTransition::HandleTurn, StTurn->GetID());
	StTurn->AddTransition(ECombatGameTransition::FinishTurn, StTurnNA->GetID());

	// FSM System
	TurnFSM = TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatTurnState, const UCCEvent*>>(
		new FQ6FSMSystem<ECombatGameTransition, ECombatTurnState, const UCCEvent*>());

	// Add Transition
	TurnFSM->AddState(StTurnNA);
	TurnFSM->AddState(StTurn);
}

void UQ6CombatGameStateMgr::InitSkillFSM()
{
	// States
	StSkillNA = MakeShareable(new FQ6CGSSkillNA(ECombatSkillState::NA, *this));
	StSkill = MakeShareable(new FQ6CGSSkill(ECombatSkillState::Skill, *this));

	// Transition
	StSkillNA->AddTransition(ECombatGameTransition::UseSkill, StSkill->GetID());
	StSkill->AddTransition(ECombatGameTransition::UseSkill, StSkill->GetID());
	StSkill->AddTransition(ECombatGameTransition::FinishSkill, StSkillNA->GetID());

	// FSM System
	SkillFSM = TUniquePtr<FQ6FSMSystem<ECombatGameTransition, ECombatSkillState, const UCCEvent*>>(
		new FQ6FSMSystem<ECombatGameTransition, ECombatSkillState, const UCCEvent*>());

	// Add Transition
	SkillFSM->AddState(StSkillNA);
	SkillFSM->AddState(StSkill);
}

//////////////////////////////////////////////////////////////////////////////////
// Update current state

void UQ6CombatGameStateMgr::Update(float DeltaTime)
{
	if (StageFSM.IsValid())
	{
		StageFSM->Update(DeltaTime);
	}

	if (WaveFSM.IsValid())
	{
		WaveFSM->Update(DeltaTime);
	}

	if (TurnFSM.IsValid())
	{
		TurnFSM->Update(DeltaTime);
	}

	if (SkillFSM.IsValid())
	{
		SkillFSM->Update(DeltaTime);
	}
}

bool UQ6CombatGameStateMgr::HandleInput(const UCCEvent* Event)
{
	bool EventUsed = false;

	switch (Event->GetEventType())
	{
	case ECCEventType::StartGame:
		EventUsed = AdvanceFSM(ECombatGameTransition::StartStage, Event);
		break;
	case ECCEventType::EndGame:
		EventUsed = AdvanceFSM(ECombatGameTransition::FinishStage, Event);
		break;
	case ECCEventType::StartWave:
		EventUsed = AdvanceFSM(ECombatGameTransition::StartWave, Event);
		break;
	case ECCEventType::StartTurn:
		EventUsed = AdvanceFSM(ECombatGameTransition::StartTurn, Event);
		break;
	case ECCEventType::StartPhase:
	case ECCEventType::ChangeCombatMultiSide:
	case ECCEventType::TakeTurn:
		EventUsed = AdvanceFSM(ECombatGameTransition::HandleTurn, Event);
		break;
	case ECCEventType::SkillUsed:
		EventUsed = AdvanceFSM(ECombatGameTransition::UseSkill, Event);
		break;
	case ECCEventType::SkillEnd:
		EventUsed = AdvanceFSM(ECombatGameTransition::FinishSkill, Event);
		break;
	default:
		EventUsed = AdvanceFSM(ECombatGameTransition::HandleGameEvent, Event);
		break;
	}

	return EventUsed;
}

//////////////////////////////////////////////////////////////////////////////////
// Advance blocking check functions

bool UQ6CombatGameStateMgr::IsFirtInstanceBlocking() const
{
	return (Container->QueuedInstances.Num() > 0);
}

bool UQ6CombatGameStateMgr::IsSkillInstanceBlocking() const
{
	if (Container->QueuedInstances.Num() > 0)
	{
		UCPSkillInstance* LastSkillInstance = Cast<UCPSkillInstance>(Container->QueuedInstances.Last());
		return (LastSkillInstance != nullptr);
	}

	return false;
}

bool UQ6CombatGameStateMgr::IsSkillInstanceCompatableEvent(const UCCEvent* Event) const
{
	if (IsSkillInstanceBlocking())
	{
		switch (Event->GetEventType())
		{
		case ECCEventType::StartGame:
		case ECCEventType::StartWave:
		case ECCEventType::StartTurn:
		case ECCEventType::StartPhase:
		case ECCEventType::EndGame:
			return false;
		default:
			return true;
		}
	}

	return false;
}
void UQ6CombatGameStateMgr::SetTurnSkillState()
{
	ECombatStageState NewStageState = ECombatStageState::Stage;
	ECombatWaveState NewWaveState = ECombatWaveState::Wave;
	ECombatTurnState NewTurnState = ECombatTurnState::Turn;
	StageFSM->SetCurrentState(NewStageState);
	WaveFSM->SetCurrentState(NewWaveState);
	TurnFSM->SetCurrentState(NewTurnState);
	StTurn->Unblock();
}


//////////////////////////////////////////////////////////////////////////////////
// Change FSM states

// One Event can be handled by multiple FSM.
// If not change function to return immediately for the sake of performance.
bool UQ6CombatGameStateMgr::AdvanceFSM(ECombatGameTransition Input, const UCCEvent* Event)
{
	bool Advanced = false;

	if (StageFSM.IsValid())
	{
		auto curState = StageFSM->GetCurrentStateID();

		ECombatStageState nextState;
		if (StageFSM->Advance(Input, nextState, Event))
		{
			//Q6JsonLog(Verbose, "Stage Transition]",
			//	Q6KV("Current: ", static_cast<int>(curState)),
			//	Q6KV("Next: ", static_cast<int>(nextState)),
			//	Q6KV("Event: ", static_cast<int>(Event->GetEventType())));
			Advanced = true;
		}
	}

	if (WaveFSM.IsValid())
	{
		auto curState = WaveFSM->GetCurrentStateID();

		ECombatWaveState nextState;
		if (WaveFSM->Advance(Input, nextState, Event))
		{
			//Q6JsonLog(Verbose, "Wave Transition]",
			//	Q6KV("Current: ", static_cast<int>(curState)),
			//	Q6KV("Next: ", static_cast<int>(nextState)),
			//	Q6KV("Event: ", static_cast<int>(Event->GetEventType())));
			Advanced = true;
		}
	}

	if (TurnFSM.IsValid())
	{
		auto curState = TurnFSM->GetCurrentStateID();

		ECombatTurnState nextState;
		if (TurnFSM->Advance(Input, nextState, Event))
		{
			//Q6JsonLog(Verbose, "Turn Transition]",
			//	Q6KV("Current: ", static_cast<int>(curState)),
			//	Q6KV("Next: ", static_cast<int>(nextState)),
			//	Q6KV("Event: ", static_cast<int>(Event->GetEventType())));
			Advanced = true;
		}
	}

	if (SkillFSM.IsValid())
	{
		auto curState = SkillFSM->GetCurrentStateID();

		ECombatSkillState nextState;
		if (SkillFSM->Advance(Input, nextState, Event))
		{
			//Q6JsonLog(Verbose, "Skill Transition]",
			//	Q6KV("Current: ", static_cast<int>(curState)),
			//	Q6KV("Next: ", static_cast<int>(nextState)),
			//	Q6KV("Event: ", static_cast<int>(Event->GetEventType())));
			Advanced = true;
		}
	}

	return Advanced;
}

//////////////////////////////////////////////////////////////////////////////////
// CombatPresentor API wrapper

void UQ6CombatGameStateMgr::StartGame(const UCCEvent* Event)
{
	Container->OnStartGame(CastChecked<UCCStartGameEvent>(Event));
}

void UQ6CombatGameStateMgr::FinishGame(const UCCEvent* Event)
{
	AdvanceFSM(ECombatGameTransition::FinishWave, Event);
	Container->OnEndGame(CastChecked<UCCEndGameEvent>(Event));
}

void UQ6CombatGameStateMgr::StartWave(const UCCEvent* Event)
{
	Container->OnStartWave(CastChecked<UCCStartWaveEvent>(Event));
}

void UQ6CombatGameStateMgr::FinishWave(const UCCEvent* Event)
{
	AdvanceFSM(ECombatGameTransition::FinishTurn, Event);

	bool bSkipFinishWaveAnim = false;

	if (Event->GetEventType() == ECCEventType::EndGame)
	{
		const UCCEndGameEvent* EndGameEvent = CastChecked<UCCEndGameEvent>(Event);
		if (EndGameEvent->EndReason != ECCEndReason::None)
		{
			bSkipFinishWaveAnim = true;
		}
	}
	else if (Event->GetEventType() == ECCEventType::AllyWipeout)
	{
		bSkipFinishWaveAnim = true;
	}

	Container->OnFinishWave(bSkipFinishWaveAnim);
}

void UQ6CombatGameStateMgr::StartTurn(const UCCEvent* Event)
{
	Container->OnStartTurn(CastChecked<UCCStartTurnEvent>(Event));
}

void UQ6CombatGameStateMgr::EmptyGameEvent(const UCCEvent* Event)
{
	Q6JsonLog(Warning, "Flushed unintended CCEvent in StageNA state", Q6KV("ECCEventType", (int32)Event->GetEventType()));
}

void UQ6CombatGameStateMgr::HandleGameEvent(const UCCEvent* Event)
{
	switch (Event->GetEventType())
	{
	case ECCEventType::ReportError:
		Container->OnReportError(CastChecked<UCCReportErrorEvent>(Event));
		break;
	case ECCEventType::SpawnUnit:
		Container->OnSpawnUnit(CastChecked<UCCSpawnUnitEvent>(Event));
		break;
	case ECCEventType::DespawnUnit:
		Container->OnDespawnUnit(CastChecked<UCCDespawnUnitEvent>(Event));
		break;
	case ECCEventType::UnitDead:
		Container->OnUnitDead(CastChecked<UCCUnitDeadEvent>(Event));
		break;
	case ECCEventType::CreateBuff:
		Container->OnCreateBuff(CastChecked<UCCCreateBuffEvent>(Event));
		break;
	case ECCEventType::RemoveBuff:
		Container->OnRemoveBuff(CastChecked<UCCRemoveBuffEvent>(Event));
		break;
	case ECCEventType::RemoveBuffFailed:
		Container->OnRemoveBuffFailed(CastChecked<UCCRemoveBuffFailedEvent>(Event));
		break;
	case ECCEventType::ImmuneBuff:
		Container->OnImmuneBuff(CastChecked<UCCImmuneBuffEvent>(Event));
		break;
	case ECCEventType::StartPhase:
		Container->OnStartPhase(CastChecked<UCCStartPhaseEvent>(Event));
		break;
	case ECCEventType::SkillUsed:
		Container->OnSkillUsed(CastChecked<UCCSkillUsedEvent>(Event));
		break;
	case ECCEventType::SkillEnd:
		Container->OnSkillEnd(CastChecked<UCCSkillEndEvent>(Event));
		break;
	case ECCEventType::SkillFailed:
		Container->OnSkillFailed(CastChecked<UCCSkillFailedEvent>(Event));
		break;
	case ECCEventType::AttackPass:
		Container->OnAttackPass(CastChecked<UCCAttackPassEvent>(Event));
		break;
	case ECCEventType::Target:
		Container->OnSelectTarget(CastChecked<UCCTargetSelectedEvent>(Event));
		break;
	case ECCEventType::HealthChanged:
		Container->OnHealthChanged(CastChecked<UCCUnitHealthChangedEvent>(Event));
		break;
	case ECCEventType::UAChanged:
		Container->OnUAChanged(CastChecked<UCCUnitUAChangedEvent>(Event));
		break;
	case ECCEventType::SAChanged:
		Container->OnSAChanged(CastChecked<UCCUnitSAChangedEvent>(Event));
		break;
	case ECCEventType::OverKillChanged:
		Container->OnOverKillChanged(CastChecked<UCCUnitOverKillChangedEvent>(Event));
		break;
	case ECCEventType::SetSkillCooldown:
		Container->OnSetSkillCooldown(CastChecked<UCCSetSkillTimeEvent>(Event));
		break;
	case ECCEventType::SetCheatSkillCooldown:
		Container->OnSetCheatSkillCooldown(CastChecked<UCCSetCheatSkillCooldownEvent>(Event));
		break;
	case ECCEventType::SkillEffect:
		Container->OnSkillEffect(CastChecked<UCCSkillEffectEvent>(Event));
		break;
	case ECCEventType::DamageBuff:
		Container->OnDamageBuff(CastChecked<UCCDamageBuffEvent>(Event));
		break;
	case ECCEventType::HealBuff:
		Container->OnHealBuff(CastChecked<UCCHealBuffEvent>(Event));
		break;
	case ECCEventType::PointVaryUsed:
		Container->OnPointVaryUsed(CastChecked<UCCPointVaryUsedEvent>(Event));
		break;
	case ECCEventType::PointVaryStateChanged:
		Container->OnPointVaryStateChanged(CastChecked<UCCPointVaryStateChangedEvent>(Event));
		break;
	case ECCEventType::PointVaryEnd:
		Container->OnPointVaryEnd(CastChecked<UCCPointVaryEndEvent>(Event));
		break;
	case ECCEventType::UpdateAttributes:
		Container->OnUpdateAttributes(CastChecked<UCCUpdateAttributesEvent>(Event));
		break;
	case ECCEventType::UpdateBuffDurations:
		Container->OnUpdateBuffDurations(CastChecked<UCCUpdateBuffDurationsEvent>(Event));
		break;
	case ECCEventType::RaidTurnSkillEffect:
		Container->OnRaidTurnSkillEffect(CastChecked<UCCRaidTurnSkillEffectEvent>(Event));
		break;
	case ECCEventType::RaidTurnSkillFinished:
		Container->OnRaidTurnSkillFinished(CastChecked<UCCRaidTurnSkillFinishedEvent>(Event));
		break;
	case ECCEventType::RaidSkillUsed:
		Container->OnRaidSkillUsed(CastChecked<UCCRaidSkillUsed>(Event));
		break;
	case ECCEventType::AllyWipeout:
		Container->OnAllyWipeout(CastChecked<UCCAllyWipeoutEvent>(Event));
		break;
	case ECCEventType::CombatMission:
		Container->OnCombatWeeklyMission(CastChecked<UCCMissionEvent>(Event));
		break;
	case ECCEventType::SelectedPatternUltimate:
		Container->OnSelectedPatternUltimate(CastChecked<UCCSelectedPatternUltimate>(Event));
		break;
	case ECCEventType::EnemyAttackPass:
		Container->OnEnemyAttackPass(CastChecked<UCCEnemyAttackPassEvent>(Event));
		break;
	case ECCEventType::ChangeCombatMultiSide:
		Container->OnChangeCombatMultiSide(CastChecked<UCCChangeCombatMultiSide>(Event));
		break;
	case ECCEventType::TakeTurn:
		Container->OnTakeTurn(CastChecked<UCCTakeTurnEvent>(Event));
		break;
	default:
		Q6JsonLogSunny(Warning, "Invalid enqueued CCEvent", Q6KV("ECCEventType", (int32)Event->GetEventType()));
		break;
	}
}
