#include "Q6CombatGameState.h"

#include "Camera/CameraLayerActor.h"
#include "Engine/Q6DirectionalLight.h"
#include "Camera/Q6CameraLayerComponent.h"
#include "CCEvent.h"
#include "CombatLocator.h"
#include "CombatPresenter.h"
#include "Q6.h"
#include "Q6CombatGameStateMgr.h"
#include "Q6Log.h"

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSStageNA

FQ6CGSStageNA::FQ6CGSStageNA(ECombatStageState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatStageState, const UCCEvent*>(Id)
	, Container(InContainer)
{
}

void FQ6CGSStageNA::OnEnter(const UCCEvent* Param)
{
	if (Param->GetEventType() == ECCEventType::EndGame)
	{
		Container.FinishGame(Param);

		Container.StWave->Block();
		Container.StTurn->Block();
		Container.StSkill->Block();
	}
	else
	{
		Container.EmptyGameEvent(Param);
	}
}

void FQ6CGSStageNA::OnExit(const UCCEvent* Param)
{
	if (Param->GetEventType() == ECCEventType::StartGame)
	{
		Container.StWave->Unblock();
		Container.StTurn->Unblock();
		Container.StSkill->Unblock();
	}
}

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSStage

FQ6CGSStage::FQ6CGSStage(ECombatStageState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatStageState, const UCCEvent*>(Id)
	, Container(InContainer)
{
}

void FQ6CGSStage::OnEnter(const UCCEvent* Param)
{
	if (Param->GetEventType() == ECCEventType::StartGame)
	{
		Container.StartGame(Param);
	}
	else
	{
		Container.HandleGameEvent(Param);
	}
}

bool FQ6CGSStage::IsBlocked(const UCCEvent* Param) const
{
	if (Blocked)
	{
		return true;
	}

	if (!Container.IsFirtInstanceBlocking())
	{
		return false;
	}

	if (Container.IsSkillInstanceBlocking())
	{
		return !Container.IsSkillInstanceCompatableEvent(Param);
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSWaveNA

FQ6CGSWaveNA::FQ6CGSWaveNA(ECombatWaveState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatWaveState, const UCCEvent*>(Id)
	, Container(InContainer)
{
}

bool FQ6CGSWaveNA::IsBlocked(const UCCEvent* Param) const
{
	return Blocked ? true : Container.IsFirtInstanceBlocking();
}

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSWaveIn

FQ6CGSWave::FQ6CGSWave(ECombatWaveState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatWaveState, const UCCEvent*>(Id)
	, Container(InContainer)
{
	// Initialize timeout value here if needed
}

void FQ6CGSWave::OnEnter(const UCCEvent* Param)
{
	Container.StartWave(Param);
}

void FQ6CGSWave::OnExit(const UCCEvent* Param)
{
	Container.FinishWave(Param);
}

bool FQ6CGSWave::IsBlocked(const UCCEvent* Param) const
{
	return Blocked ? true : Container.IsFirtInstanceBlocking();
}

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSTurnNA

FQ6CGSTurnNA::FQ6CGSTurnNA(ECombatTurnState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatTurnState, const UCCEvent*>(Id)
	, Container(InContainer)
{
}

bool FQ6CGSTurnNA::IsBlocked(const UCCEvent* Param) const
{
	return Blocked ? true : Container.IsFirtInstanceBlocking();
}

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSTurn

FQ6CGSTurn::FQ6CGSTurn(ECombatTurnState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatTurnState, const UCCEvent*>(Id)
	, Container(InContainer)
{
	// Initialize timeout value here if needed
}

void FQ6CGSTurn::OnEnter(const UCCEvent* Param)
{
	if (Param->GetEventType() == ECCEventType::StartTurn)
	{
		Container.StartTurn(Param);
	}
	else
	{
		if (Param->GetEventType() == ECCEventType::StartPhase)
		{
			ACombatPresenter* Presenter = Container.GetCombatPresenter();
			// clear rotation
			Presenter->ForEachUnit([](AUnit& InUnit)
			{
				InUnit.RotateToTargetUnit(nullptr);
				InUnit.SetSupporter(false);
			});
		}
		Container.HandleGameEvent(Param);
	}
}

void FQ6CGSTurn::OnExit(const UCCEvent* Param)
{
	if (Param->GetEventType() == ECCEventType::StartPhase)
	{
		return;
	}

	DetachAllyUnits();
}

bool FQ6CGSTurn::IsBlocked(const UCCEvent* Param) const
{
	return Blocked ? true : Container.IsFirtInstanceBlocking();
}

namespace
{
	void BindCameraLayerActorToDirectionalLightActor(ACameraLayerActor* CameraLayerActor)
	{
		if (!CameraLayerActor)
		{
			return;
		}

		for (TActorIterator<AQ6DirectionalLight> It(CameraLayerActor->GetWorld(), AQ6DirectionalLight::StaticClass()); It; ++It)
		{
			AQ6DirectionalLight* DirectionalLightActor = *It;

			if (!DirectionalLightActor->IsHidden())
			{
				CameraLayerActor->AttachToActor(DirectionalLightActor, FAttachmentTransformRules::KeepWorldTransform);
				break;
			}
		}
	}
}

void FQ6CGSTurn::SetShowCameraLayer(bool bInShow)
{
	ACameraLayerActor* CameraLayerActor = Container.GetCombatPresenter()->GetCameraLayerActor();
	if (CameraLayerActor)
	{
		CameraLayerActor->SetActorHiddenInGame(!bInShow);

		if (bInShow)
		{
			BindCameraLayerActorToDirectionalLightActor(CameraLayerActor);
		}
	}
}

void FQ6CGSTurn::DetachAllyUnits()
{
	SetShowCameraLayer(false);

	for (const FCCUnitId& IterUnitId : AttachedUnitIds)
	{
		AUnit* AllyUnit = Container.GetCombatPresenter()->FindUnit(IterUnitId);
		if (AllyUnit)
		{
			AllyUnit->SetActorHiddenInGame(false);
			AllyUnit->DetachAndReturnToInitialPosition();
			AllyUnit->SetAnimRelaxed(false);
			AllyUnit->TurnSkillOverrideMaterialParamters(false);
		}
	}

	AttachedUnitIds.Empty();
}

void FQ6CGSTurn::AttachAllyUnits()
{
	SetShowCameraLayer(true);

	Container.GetCombatPresenter()->ForEachUnit([=](AUnit& Unit)
	{
		if (Unit.GetOverrideFaction() == ECCFaction::Ally)
		{
			AttachAllyUnit(&Unit);
		}
	});

	PickedUnitId = CCUnitIdInvalid;
}

void FQ6CGSTurn::AttachAllyUnit(AUnit* InUnit)
{
	if (InUnit->GetUnitState().Faction != ECCFaction::Ally || InUnit->IsDead())
	{
		return;
	}

	if (!AttachedUnitIds.Contains(InUnit->GetUnitId()))
	{
		if (ACameraLayerActor* CameraLayerActor = Container.GetCombatPresenter()->GetCameraLayerActor())
		{
			InUnit->AttachUnitTo(CameraLayerActor->GetModelPosition(), FName("ModelPosition"));
			InUnit->SetActorRelativeTransform(InUnit->GetMultiLayerAttachmentTransform());
			InUnit->TurnSkillOverrideMaterialParamters(true);
		}
		else if (const ACombatLocator* CombatLocator = Container.GetCombatPresenter()->GetCombatLocator())
		{
			InUnit->AttachUnitTo(CombatLocator->GetModelPosition(), FName("ModelPosition"));
		}
		else
		{
			Q6JsonLogSunny(Warning, "FQ6CGSTurn::AttachAllyUnitToCameraLayer - nowhere to attach unit");
		}

		InUnit->SetActorHiddenInGame(true);
		InUnit->SetAnimRelaxed(true);
		AttachedUnitIds.Add(InUnit->GetUnitId());
	}
}

void FQ6CGSTurn::PickUnit(FCCUnitId InUnitId, bool bPlaySpawnAnim)
{
	if (!AttachedUnitIds.Num())
	{
		AttachAllyUnits();
	}

	if (PickedUnitId == InUnitId)
	{
		return;
	}

	PickedUnitId = InUnitId;
	for (const FCCUnitId& IterUnitId : AttachedUnitIds)
	{
		AUnit* AllyUnit = Container.GetCombatPresenter()->FindUnit(IterUnitId);
		if (AllyUnit)
		{
			if (IterUnitId == PickedUnitId)
			{
				AllyUnit->SetActorHiddenInGame(false);
				if (ACameraLayerActor* CameraLayerActor = Container.GetCombatPresenter()->GetCameraLayerActor())
				{
					CameraLayerActor->SetActorRelativeRotation(AllyUnit->GetMultiLayerAttachmentLightTransform().GetRotation());
				}

				if (bPlaySpawnAnim)
				{
					AllyUnit->PlayPrepareSpawnAnimation();
				}
			}
			else
			{
				if (bPlaySpawnAnim)
				{
					AllyUnit->StopPrepareSpawnAnimation();
				}

				AllyUnit->SetActorHiddenInGame(true);
			}
		}
	}
}

FCCUnitId FQ6CGSTurn::GetRestoreTargetUnitId()
{
	FCCUnitId RestoringUnitId = PickedUnitId;

	if (!AttachedUnitIds.Num())
	{
		AttachAllyUnits();
	}

	if (!AttachedUnitIds.Num())
	{
		Q6JsonLogSunny(Warning, "FQ6CGSTurn::RestorePickedUnit - still has no attached unit after AttachAllyUnits");
		DetachAllyUnits();
		return CCUnitIdInvalid;
	}

	if (!AttachedUnitIds.Contains(RestoringUnitId))
	{
		return CCUnitIdInvalid;
	}

	return RestoringUnitId;
}

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSSkillNA

FQ6CGSSkillNA::FQ6CGSSkillNA(ECombatSkillState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatSkillState, const UCCEvent*>(Id)
	, Container(InContainer)
{
}

bool FQ6CGSSkillNA::IsBlocked(const UCCEvent* Param) const
{
	if (Blocked)
	{
		return true;
	}

	if (!Container.IsFirtInstanceBlocking())
	{
		return false;
	}

	return !Container.IsSkillInstanceBlocking();
}

///////////////////////////////////////////////////////////////////////////////////////////
// FQ6CGSTurn

FQ6CGSSkill::FQ6CGSSkill(ECombatSkillState Id, UQ6CombatGameStateMgr& InContainer)
	: FQ6FSMState<ECombatGameTransition, ECombatSkillState, const UCCEvent*>(Id)
	, Container(InContainer)
{
	// Initialize timeout value here if needed
}

void FQ6CGSSkill::OnEnter(const UCCEvent* Param)
{
	FQ6FSMState::OnEnter(Param);
	Container.HandleGameEvent(Param);
}

void FQ6CGSSkill::Update(float DeltaTime)
{
	FQ6FSMState::Update(DeltaTime);
}

void FQ6CGSSkill::OnExit(const UCCEvent* Param)
{
	FQ6FSMState::OnExit(Param);
	Container.HandleGameEvent(Param);
}

bool FQ6CGSSkill::IsBlocked(const UCCEvent* Param) const
{
	if (Blocked)
	{
		return true;
	}

	if (!Container.IsFirtInstanceBlocking())
	{
		return false;
	}

	return !Container.IsSkillInstanceBlocking();
}
