#pragma once

#include "Q6Minimal.h"
#include "Containers/Map.h"

template <typename Transition, typename StateID, typename TParam>
class FQ6FSMState
{
public:
	FQ6FSMState(StateID Id)
	{
		SId = Id;
		ElapsedTime = 0.0f;
		Blocked = false;
	}
	virtual ~FQ6FSMState() {}

	void AddTransition(Transition Trans, StateID Id)
	{
		if (ensure(!TransMap.Contains(Trans)))
		{
			TransMap.Add(Trans, Id);
		}
	}

	void DeleteTransition(Transition Trans)
	{
		if (ensure(TransMap.Contains(Trans)))
		{
			TransMap.Remove(Trans);
		}
	}

	void Block()
	{
		Blocked = true;
	}

	void Unblock()
	{
		Blocked = false;
	}

	bool TryTransition(Transition Trans, StateID& Id, TParam Param) const
	{
		if (TransMap.Contains(Trans))
		{
			if (!IsBlocked(Param))
			{
				Id = TransMap[Trans];
				return IsAllowReEnter() ? true : (SId != Id);
			}
		}

		return false;
	}

	virtual void OnEnter(TParam)
	{
		ElapsedTime = 0.0f;
	}

	virtual void Update(float dt)
	{
		ElapsedTime += dt;
	}

	virtual void OnExit(TParam) {}

	StateID GetID() const { return SId; }

protected:
	float GetElapsedTime() const { return ElapsedTime; }
	virtual bool IsBlocked(TParam) const { return Blocked; }
	virtual bool IsAllowReEnter() const { return false; }

protected:
	float ElapsedTime;
	bool Blocked;

	TMap<Transition, StateID> TransMap;
	StateID SId;
};
