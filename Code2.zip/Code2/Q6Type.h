#pragma once

#include "Q6Type.generated.h"

// Definition Ids Type
USTRUCT(BlueprintType)
struct FCCIdType
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite)
	int32 X;

	FCCIdType() : X(0) {}
	explicit FCCIdType(int32 InX) : X(InX) {}

	bool operator == (const FCCIdType& Other) const { return X == Other.X; }
	bool operator != (const FCCIdType& Other) const { return X != Other.X; }
};

FORCEINLINE uint32 GetTypeHash(FCCIdType Id) { return GetTypeHash(Id.X); }

USTRUCT(BlueprintType)
struct FCCUnitId : public FCCIdType { GENERATED_BODY() FCCUnitId() {} explicit FCCUnitId(int32 InX) : FCCIdType(InX) {} };

USTRUCT(BlueprintType)
struct FCCBuffId : public FCCIdType { GENERATED_BODY() FCCBuffId() {} explicit FCCBuffId(int32 InX) : FCCIdType(InX) {} };

USTRUCT(BlueprintType)
struct FCPInstanceId : public FCCIdType { GENERATED_BODY() FCPInstanceId() {} explicit FCPInstanceId(int32 InX) : FCCIdType(InX) {} };

USTRUCT(BlueprintType)
struct FCCSkillId : public FCCIdType { GENERATED_BODY() FCCSkillId() {} explicit FCCSkillId(int32 InX) : FCCIdType(InX) {} };

FORCEINLINE uint32 GetTypeHash(FCCUnitId Id) { return GetTypeHash(Id.X); }
FORCEINLINE uint32 GetTypeHash(FCCBuffId Id) { return GetTypeHash(Id.X); }
FORCEINLINE uint32 GetTypeHash(FCPInstanceId Id) { return GetTypeHash(Id.X); }

extern const FCCUnitId CCUnitIdInvalid;
extern const FCCBuffId CCBuffIdInvalid;
extern const FCPInstanceId CCInstanceIdInvalid;
extern const FCCSkillId CCSkillIdInvalid;
extern const FCPInstanceId INITIALIZE_INSTANCE_ID;
extern const FCCSkillId INITIALIZE_SKILL_ID;
extern const TArray<int32> ALLY_AUTO_TARGET_SLOT_ORDER;
