// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "CombatTutorial.h"

#include "CMS/CMSTable.h"
#include "CMS/CMSType_gen.h"
#include "Combat/CombatPresenter.h"
#include "HUD/CombatHUD.h"
#include "HUDStore/HUDStore.h"
#include "HUDStore/BattleHelper.h"
#include "HUDStore/SagaManager.h"
#include "HUDStore/UserRecordManager.h"
#include "Q6.h"
#include "Q6CombatGameMode.h"
#include "Q6GameInstance.h"
#include "Resource/GameResource.h"
#include "Utils/Q6Log.h"
#include "Utils/WidgetUtil.h"
#include "Widget/TutorialWidget.h"

// Sets default values
ACombatTutorial::ACombatTutorial(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
	, CurrentCombatTutorial(ECombatTutorial::None)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ACombatTutorial::BeginPlay()
{
	Super::BeginPlay();

#if !UE_BUILD_SHIPPING
	DumpConsoleCmd = IConsoleManager::Get().RegisterConsoleCommand(
		TEXT("q6.dump_challenged_waves"),
		TEXT("q6.dump_challenged_waves dump all waves that have been tried before."),
		FConsoleCommandWithArgsDelegate::CreateUObject(this, &ACombatTutorial::OnDevDumpChallengedWaves),
		ECVF_Cheat
	);
#endif // #if !UE_BUILD_SHIPPING

	// Request Resurrection Count 
	if (IsLogin())
	{
		GetHUDStore().GetUserRecordManager().ReqResurrectionCount();
	}
}

void ACombatTutorial::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
#if !UE_BUILD_SHIPPING
	IConsoleManager::Get().UnregisterConsoleObject(DumpConsoleCmd);
#endif

	Super::EndPlay(EndPlayReason);
}

// Called every frame
void ACombatTutorial::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

bool ACombatTutorial::IsInCombatTutorial() const
{
	return CurrentCombatTutorial != ECombatTutorial::None;
}

void ACombatTutorial::CreateTutorialWidget(ECombatTutorial InCreateTutorial)
{
	EndCurrentTutorial();

	CurrentTutorialsWidget = CreateTutorialWidgetFromBP(InCreateTutorial);
	if (!CurrentTutorialsWidget)
	{
		return;
	}

	CurrentCombatTutorial = InCreateTutorial;
	CurrentTutorialsWidget->AddToViewport(ZORDER_TUTORIAL);
	CurrentTutorialsWidget->GetEndTutorialsDelegate().BindUObject(this, &ACombatTutorial::EndCurrentTutorial);
}

void ACombatTutorial::CheatFillUA(int32 InCharacterSlot)
{
	const AQ6CombatGameMode* CombatGameMode = Cast<AQ6CombatGameMode>(GetWorld()->GetAuthGameMode());

	if (CombatGameMode)
	{
		const FUnitState& InCheatUnitState = GetCheckedCombatPresenter(this)->GetCharacterStateBySlot(InCharacterSlot);
		CombatGameMode->CombatCube->CheatFillUAForTutorial(InCheatUnitState.UnitId);
	}
}

void ACombatTutorial::CheatFillSA(int32 InCharacterSlot)
{
	const AQ6CombatGameMode* CombatGameMode = Cast<AQ6CombatGameMode>(GetWorld()->GetAuthGameMode());

	if (CombatGameMode)
	{
		const FUnitState& InCheatUnitState = GetCheckedCombatPresenter(this)->GetCharacterStateBySlot(InCharacterSlot);
		CombatGameMode->CombatCube->CheatFillSAForTutorial(InCheatUnitState.UnitId);
	}
}

static EBattleHelperStartPhase ConvertECPTurnPhaseToBattleHelperPhase(ECPTurnPhase InPhase)
{
	return (InPhase == ECPTurnPhase::Steady) ? EBattleHelperStartPhase::Attack : EBattleHelperStartPhase::Turn;
}

bool ACombatTutorial::IsWaveBattleHelperExists()
{
	TArray<FCMSBattleHelperRow> BattleHelpersArray;
	return GetWaveBattleHelperTypesInternal(true, BattleHelpersArray);
}

EContentType ACombatTutorial::GetCombatContentType()
{
	const ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	return CombatPresenter->GetCombatSeed().Content;
}

bool ACombatTutorial::GetWaveBattleHelperTypes(UPARAM(ref) TArray<FCMSBattleHelperRow>& OutBattleHelpers)
{
	return GetWaveBattleHelperTypesInternal(false, OutBattleHelpers);
}

void ACombatTutorial::SaveDoneBattleHelperTypes(UPARAM(ref) TArray<FCMSBattleHelperRow>& OutBattleHelpers)
{
	for (auto& itHelper : OutBattleHelpers)
	{
		BattleHelpersDone.Add(itHelper.Type);
	}
}

bool ACombatTutorial::GetWaveBattleHelperTypesInternal(bool bInStopOnFound, TArray<FCMSBattleHelperRow>& OutBattleHelpers)
{
	const ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	const UQ6SaveGame* InQ6SaveGame = UQ6GameInstance::Get(this)->GetSaveGame();
	if (!InQ6SaveGame)
	{
		return false;
	}

	FSagaType InSagaType = CombatPresenter->GetCombatSeed().SagaType;
	const int32 InWaveIndex = CombatPresenter->GetWaveRowIndex();
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(InSagaType, InWaveIndex);
	if (!WaveRow)
	{
		return false;
	}

	int32 InChallangeCount = GetHUDStore().GetBattleHelper().GetChallengeCount(InSagaType, WaveRow->CmsType());
	ECPTurnPhase CurPhase = GetCurrentPhase();
	if (CurPhase != ECPTurnPhase::TurnSkill && CurPhase != ECPTurnPhase::Steady)
	{
		return false;
	}

	EBattleHelperStartPhase CurBattlePhase = ConvertECPTurnPhaseToBattleHelperPhase(CurPhase);
	for (const FCMSBattleHelperRow* itBattle : WaveRow->GetBattleHelper())
	{
		if (itBattle->ChallengeCount != InChallangeCount)
		{
			continue;
		}

		if (itBattle->StartPhase != CurBattlePhase)
		{
			continue;
		}

		if (BattleHelpersDone.Contains(itBattle->Type))
		{
			continue;
		}

		if (bInStopOnFound)
		{
			return true;
		}
		OutBattleHelpers.Add(*itBattle);
	}

	if (OutBattleHelpers.Num() <= 0)
	{
		return false;
	}

	return true;
}

int32 ACombatTutorial::GetCurrentTurn()
{
	return GetCheckedCombatPresenter(this)->GetTurnCount();
}

int32 ACombatTutorial::GetCurrentWave()
{
	return GetCheckedCombatPresenter(this)->GetWave();
}

ECPTurnPhase ACombatTutorial::GetCurrentPhase()
{
	const ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	return CombatPresenter->CCPhaseToCPPhase(CombatPresenter->GetTurnPhase());
}

int32 ACombatTutorial::GetCurrentWaveChallengeCount()
{
	const ACombatPresenter* CombatPresenter = GetCheckedCombatPresenter(this);
	FSagaType InSagaType = CombatPresenter->GetCombatSeed().SagaType;
	const int32 InWaveIndex = CombatPresenter->GetWaveRowIndex();
	const FCMSWaveRow* WaveRow = GetCMS()->GetWaveRow(InSagaType, InWaveIndex);
	if (!WaveRow)
	{
		return 0;
	}

	return GetHUDStore().GetBattleHelper().GetChallengeCount(InSagaType, WaveRow->CmsType());
}

void ACombatTutorial::EndCurrentTutorial()
{
	Super::EndCurrentTutorial();
	if (CurrentCombatTutorial == ECombatTutorial::None)
	{
		return;
	}

	ECombatTutorial OldCurrentCombatTutorial = CurrentCombatTutorial;
	CurrentCombatTutorial = ECombatTutorial::None;
	OnTutorialEnd(OldCurrentCombatTutorial);
}

void ACombatTutorial::EnterWave(FWaveType InWaveType)
{
	EnteringWave = InWaveType;
}

void ACombatTutorial::AddStageChallenge(FSagaType InSagaType, FWaveType InWaveType)
{
	if (InWaveType != EnteringWave)
	{
		return;
	}

	EnteringWave = WaveTypeInvalid;
	GetHUDStore().GetBattleHelper().ReqStageChallengeAdd(InSagaType, InWaveType);
}

bool ACombatTutorial::IsInTutorial() const
{
	return IsInCombatTutorial();
}

#if !UE_BUILD_SHIPPING
void ACombatTutorial::OnDevDumpChallengedWaves(const TArray<FString>& Args)
{
	const TMap<int32, FStageChallenge>& InStageChallenges = GetHUDStore().GetBattleHelper().GetAllChallengeCount();

	UE_LOG(Q6, Verbose, TEXT("==============Dump All Challenged Waves=============="));
	for (auto& itStage : InStageChallenges)
	{
		UE_LOG(Q6, Verbose, TEXT("%d Stage"), itStage.Key);
		for (auto& itWave : itStage.Value.WaveChallengeCount)
		{
			UE_LOG(Q6, Verbose, TEXT("    %d Wave : %d"), itWave.Key, itWave.Value);
		}
	}
}
#endif
