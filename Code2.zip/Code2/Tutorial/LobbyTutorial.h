// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HUDStore/Q6Account.h"
#include "Tutorial/BaseTutorial.h"
#include "LobbyTutorial.generated.h"

const int32 CHARACTER_SUMMON_PAGE_KEY = 21;
const int32 SCULPTURE_SUMMON_PAGE_KEY = 31;
const int32 RELIC_SUMMON_PAGE_KEY = 41;

UENUM(BlueprintType)
enum class ELobbyTutorial : uint8
{
	None = 0,
	GoSagaStart,
	GoSagaNextStage,
	GoEpisodeFinalStage,
	CharacterSummon,
	PartyEdit,
	GoSagaNextEpisode,
	SculptureSummon,
	SculpturePartyEdit,
	GoSagaOneJoker,
	RelicSummon,
	RelicPartyEdit,
	GoSagaMultiJokerGuide,
	CharacterUpgrade,
	GoSagaMultiJoker,
	GoLobbyOpen,
	EquipmentUpgrade,
	JokerEdit,
	WonderOpen,
	CharacterPromote,
	Unbind,
	MoonlightEngrave,
	TurnSkillUpgrade,
	UltimateSkillUpgrade,
	EquipmentPromote,
	TierUpgrade,
	Shop,
	WeeklyMissions,
	SpecialStage,
	DailyDungeon,
	TrainingCenter,
	WonderPyramid,
	WonderPetPark,
	WonderVacation,
	WonderTemple,
	WonderPowerPlant,
	MultiSideBattle
};

UCLASS()
class Q6_API ALobbyTutorial : public ABaseTutorial
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ALobbyTutorial(const FObjectInitializer& ObjectInitializer);
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void CreateTutorialWidget(ELobbyTutorial InCreateTutorial);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	bool IsInLobbyTutorial() const;

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	bool IsDialoguePlaying() const;

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void PlayDialogue(int32 InEpisode, int32 InStage, int32 InSubStage);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void GotoSelectStage(int32 InEpisode);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void ReserveTutorialOnInit(ELobbyTutorial InTutorialStep, int32 InStep);

	UFUNCTION(BlueprintCallable, Category = "Util")
	bool IsLobbyTutorialDoneSaved(ELobbyTutorial InLobbyTutorial);

	UFUNCTION(BlueprintCallable, Category = "Util")
	void SaveLobbyTutorialDone(ELobbyTutorial InLobbyTutorial);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	ELobbyTutorial GetCurrentTutorialStep();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	EHUDWidgetType GetCurrentHUDWidget();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool HasGradeCharacter(EItemGrade InGrade);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool ExistsInParty(EItemGrade InGrade);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool HasGradeSculpture(EItemGrade InGrade);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool ExistsSculptureInParty(EItemGrade InGrade);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool HasGradeRelic(EItemGrade InGrade);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool ExistsRelicInParty(EItemGrade InGrade);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool HasUpgradedCharacter();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	ELobbyTutorial GetReservedTutorialOnInit();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	int32 GetReservedTutorialStepOnInit();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	void OnChangeHUDWidget(EHUDWidgetType InHUDWidgetType);

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	void OnTutorialEnd(ELobbyTutorial InEndTutorial);

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool IsCheckInOpened();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool CanWatchRewards();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool CanWatchItemDetail();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Q6 Tutorial")
	bool IsCharacterSummonTutorialSagaCleared();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Q6 Tutorial")
	bool IsSculptureSummonTutorialSagaCleared();

	UFUNCTION(BlueprintImplementableEvent, BlueprintCallable, Category = "Q6 Tutorial")
	bool IsRelicSummonTutorialSagaCleared();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	UTutorialsWidget* CreateTutorialWidgetFromBP(ELobbyTutorial InCreateTutorial);

	virtual bool IsInTutorial() const override;
	virtual void EndCurrentTutorial() override;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

private:

	UPROPERTY()
	ELobbyTutorial CurrentLobbyTutorial;
};
