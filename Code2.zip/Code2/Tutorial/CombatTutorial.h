// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CMS/CMS_gen.h"
#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Tutorial/BaseTutorial.h"
#include "CombatTutorial.generated.h"

UENUM(BlueprintType)
enum class ECombatTutorial : uint8
{
	None = 0,
	PlayNormalSkill,
	PlayTurnSkill,
	PlayUltimateSkill,
	TargetChange,
	AttackOrder,
	PlaySupportSkill,
	CombatDetail,
	MonsterUltSkill,
	FastForward,
	ChangePhase,
	FastSkill,
	NatureType,
	Wipeout
};

UCLASS()
class Q6_API ACombatTutorial : public ABaseTutorial
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ACombatTutorial(const FObjectInitializer& ObjectInitializer);
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	bool IsInCombatTutorial() const;

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void CreateTutorialWidget(ECombatTutorial InCreateTutorial);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void CheatFillUA(int32 InCharacterSlot);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void CheatFillSA(int32 InCharacterSlot);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	bool GetWaveBattleHelperTypes(UPARAM(ref) TArray<FCMSBattleHelperRow>& OutBattleHelpers);

	UFUNCTION(BlueprintCallable, Category = "Q6 Tutorial")
	void SaveDoneBattleHelperTypes(UPARAM(ref) TArray<FCMSBattleHelperRow>& OutBattleHelpers);

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	int32 GetCurrentTurn();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	int32 GetCurrentWave();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	ECPTurnPhase GetCurrentPhase();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	int32 GetCurrentWaveChallengeCount();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	bool IsWaveBattleHelperExists();

	UFUNCTION(BlueprintPure, Category = "Q6 Tutorial")
	EContentType GetCombatContentType();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool IsPauseButtonEnable();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool IsUnitBarLongTouchEnable();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool IsSkillQuickUseEnable();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool IsBackToTurnPhaseEnable();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	bool IsDoubleSpeedEnable();

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	void OnTutorialEnd(ECombatTutorial InEndTutorial);

	UFUNCTION(BlueprintImplementableEvent, Category = "Q6 Tutorial")
	UTutorialsWidget* CreateTutorialWidgetFromBP(ECombatTutorial InCreateTutorial);

	virtual bool IsInTutorial() const override;
	virtual void EndCurrentTutorial() override;

	void EnterWave(FWaveType InEnterWave);
	void AddStageChallenge(FSagaType InSagaType, FWaveType InWaveType);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

private:

#if !UE_BUILD_SHIPPING
	IConsoleCommand* DumpConsoleCmd;

	void OnDevDumpChallengedWaves(const TArray<FString>& Args);
#endif

	bool GetWaveBattleHelperTypesInternal(bool bInStopOnFound, TArray<FCMSBattleHelperRow>& OutBattleHelpers);

	UPROPERTY()
	ECombatTutorial CurrentCombatTutorial;

	// prevent re-entering wave for battle helper.
	UPROPERTY()
	FWaveType EnteringWave;

	UPROPERTY()
	TSet<int32> BattleHelpersDone;
};
