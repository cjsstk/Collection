// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "BaseTutorial.h"

#include "CMS/CMSTable.h"
#include "HUD/LobbyHUD.h"
#include "HUDStore/HUDStore.h"
#include "HUDStore/SagaManager.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Resource/GameResource.h"
#include "Tutorial/LobbyTutorial.h"
#include "Utils/Q6Log.h"
#include "Utils/WidgetUtil.h"
#include "Widget/TutorialWidget.h"
#include "LevelUtil.h"

// Sets default values
ABaseTutorial::ABaseTutorial(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
	, bProtectionMode(true)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

}

// Called when the game starts or when spawned
void ABaseTutorial::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void ABaseTutorial::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void ABaseTutorial::TutorialButtonClick(FString InSource)
{
	Proceed(InSource);
}

void ABaseTutorial::Proceed(FString InSource)
{
	if (!CurrentTutorialsWidget)
	{
		OnProceedInitTutorial(FName(*InSource));
		return;
	}

	CurrentTutorialsWidget->ProceedStep(InSource);
}

void ABaseTutorial::SetStep(int32 InStep)
{
	if (!CurrentTutorialsWidget)
	{
		return;
	}

	CurrentTutorialsWidget->SetStep(InStep);
}

void ABaseTutorial::PauseTutorial()
{
	if (!CurrentTutorialsWidget)
	{
		return;
	}

	CurrentTutorialsWidget->PauseStep();
}

bool ABaseTutorial::IsLogin()
{
	UQ6GameInstance* Q6GameInstance = UQ6GameInstance::Get(this);
	if (!Q6GameInstance)
	{
		return false;
	}


	return Q6GameInstance->IsLogin();
}

void ABaseTutorial::SetProtectionMode(bool bInProtect)
{
	bProtectionMode = bInProtect;
}

bool ABaseTutorial::IsProtected() const
{
	return bProtectionMode;
}

bool ABaseTutorial::IsTutorialSkipMode() const
{
#if !UE_BUILD_SHIPPING
	const UQ6GameInstance* Q6GameInstance = GetGameInstance<UQ6GameInstance>();
	return Q6GameInstance ? Q6GameInstance->IsTutorialSkipMode() : false;
#else
	return false;
#endif
}

bool ABaseTutorial::IsSagaCleared(int32 InEpisode, int32 InStage, int32 InSubStage)
{
	return GetHUDStore().GetSagaManager().IsStageCleared(InEpisode, InStage, InSubStage);
}

void ABaseTutorial::EndCurrentTutorial()
{
//	CurrentLobbyTutorial = ELobbyTutorial::None;
	if (CurrentTutorialsWidget)
	{
		CurrentTutorialsWidget->RemoveFromViewport();
	}
	CurrentTutorialsWidget = nullptr;
	ULevelUtil::SetCurrentCaptureActor(GetWorld(), false, "Capture.Tutorial");
}

bool ABaseTutorial::IsInTutorial() const
{
	return false;
}