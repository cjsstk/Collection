// Copyright (c) 2018 XLGames, Inc. All rights reserved.


#include "LobbyTutorial.h"

#include "CMS/CMSTable.h"
#include "HUD/LobbyHUD.h"
#include "HUDStore/CharacterManager.h"
#include "HUDStore/HUDStore.h"
#include "HUDStore/PartyManager.h"
#include "HUDStore/RelicManager.h"
#include "HUDStore/RewardManager.h"
#include "HUDStore/SagaManager.h"
#include "HUDStore/SculptureManager.h"
#include "LevelUtil.h"
#include "Q6.h"
#include "Q6GameInstance.h"
#include "Q6SaveGame.h"
#include "Resource/GameResource.h"
#include "Utils/Q6Log.h"
#include "Utils/WidgetUtil.h"
#include "Widget/TutorialWidget.h"

// Sets default values
ALobbyTutorial::ALobbyTutorial(const FObjectInitializer& ObjectInitializer) : Super(ObjectInitializer)
	, CurrentLobbyTutorial(ELobbyTutorial::None)
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;
}

// Called when the game starts or when spawned
void ALobbyTutorial::BeginPlay()
{
	Super::BeginPlay();
}

// Called every frame
void ALobbyTutorial::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ALobbyTutorial::CreateTutorialWidget(ELobbyTutorial InCreateTutorial)
{
	EndCurrentTutorial();

	CurrentTutorialsWidget = CreateTutorialWidgetFromBP(InCreateTutorial);
	if (!CurrentTutorialsWidget)
	{
		return;
	}

	CurrentLobbyTutorial = InCreateTutorial;
	CurrentTutorialsWidget->AddToViewport(ZORDER_TUTORIAL);
	CurrentTutorialsWidget->GetEndTutorialsDelegate().BindUObject(this, &ALobbyTutorial::EndCurrentTutorial);
}

bool ALobbyTutorial::IsInLobbyTutorial() const
{
	return CurrentLobbyTutorial != ELobbyTutorial::None;
}

bool ALobbyTutorial::IsDialoguePlaying() const
{
	ALobbyHUD* InLobbyHUD = GetCheckedLobbyHUD(this);
	if (!InLobbyHUD)
	{
		return false;
	}

	return (InLobbyHUD->GetCurrentHUDWidgetType() == EHUDWidgetType::Dialogue);
}

void ALobbyTutorial::PlayDialogue(int32 InEpisode, int32 InStage, int32 InSubStage)
{
	ALobbyHUD* InLobbyHUD = GetCheckedLobbyHUD(this);
	if (!InLobbyHUD)
	{
		return;
	}

	if (IsDialoguePlaying())
	{
		return;
	}

	FSagaType SagaType = GetCMS()->FindSagaType(InEpisode, InStage, InSubStage);
	InLobbyHUD->PlaySagaWithStoryClear(SagaType, true, false);
}

void ALobbyTutorial::GotoSelectStage(int32 InEpisode)
{
	ALobbyHUD* InLobbyHUD = GetCheckedLobbyHUD(this);
	if (!InLobbyHUD)
	{
		return;
	}

	if (InLobbyHUD->GetCurrentHUDWidgetType() != EHUDWidgetType::Saga)
	{
		InLobbyHUD->SetHUDType(EHUDWidgetType::Saga);
	}

	ACTION_DISPATCH_SagaStageList(InEpisode);
}

void ALobbyTutorial::ReserveTutorialOnInit(ELobbyTutorial InTutorialStep, int32 InStep)
{
	UQ6GameInstance::Get()->SetReserveTutorialOnInit(InTutorialStep, InStep);
}

bool ALobbyTutorial::IsLobbyTutorialDoneSaved(ELobbyTutorial InLobbyTutorial)
{
	return GetHUDStore().GetWorldUser().IsLobbyTutorialDone(InLobbyTutorial);
}

void ALobbyTutorial::SaveLobbyTutorialDone(ELobbyTutorial InLobbyTutorial)
{
	GetHUDStore().GetWorldUser().ReqAddLobbyTutorialDone(InLobbyTutorial);
}

ELobbyTutorial ALobbyTutorial::GetReservedTutorialOnInit()
{
	return UQ6GameInstance::Get()->GetReservedTutorialOnInit();
}

int32 ALobbyTutorial::GetReservedTutorialStepOnInit()
{
	return UQ6GameInstance::Get()->GetReservedTutorialStepOnInit();
}

ELobbyTutorial ALobbyTutorial::GetCurrentTutorialStep()
{
	return CurrentLobbyTutorial;
}

EHUDWidgetType ALobbyTutorial::GetCurrentHUDWidget()
{
	ALobbyHUD* InLobbyHUD = GetLobbyHUD(this);
	if (!InLobbyHUD)
	{
		return EHUDWidgetType::Invalid;
	}

	return InLobbyHUD->GetCurrentHUDWidgetType();
}

bool ALobbyTutorial::HasGradeCharacter(EItemGrade InGrade)
{
	return GetHUDStore().GetCharacterManager().HasCharacter(InGrade);
}

bool ALobbyTutorial::ExistsInParty(EItemGrade InGrade)
{
	return GetHUDStore().GetPartyManager().ExistsInParty(EPartyIconItemType::Character, InGrade);
}

bool ALobbyTutorial::HasGradeSculpture(EItemGrade InGrade)
{
	return GetHUDStore().GetSculptureManager().HasSculpture(InGrade);
}

bool ALobbyTutorial::ExistsSculptureInParty(EItemGrade InGrade)
{
	return GetHUDStore().GetPartyManager().ExistsInParty(EPartyIconItemType::Sculpture, InGrade);
}

bool ALobbyTutorial::HasGradeRelic(EItemGrade InGrade)
{
	return GetHUDStore().GetRelicManager().HasRelic(InGrade);
}

bool ALobbyTutorial::ExistsRelicInParty(EItemGrade InGrade)
{
	return GetHUDStore().GetPartyManager().ExistsInParty(EPartyIconItemType::Relic, InGrade);
}

bool ALobbyTutorial::HasUpgradedCharacter()
{
	return GetHUDStore().GetCharacterManager().HasUpgradedCharacter();
}

void ALobbyTutorial::EndCurrentTutorial()
{
	Super::EndCurrentTutorial();

	if (CurrentLobbyTutorial == ELobbyTutorial::None)
	{
		return;
	}

	ELobbyTutorial OldCurrentLobbyTutorial = CurrentLobbyTutorial;
	CurrentLobbyTutorial = ELobbyTutorial::None;
	OnTutorialEnd(OldCurrentLobbyTutorial);
}

bool ALobbyTutorial::IsInTutorial() const
{
	return IsInLobbyTutorial();
}
