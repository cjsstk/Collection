// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HUD/Q6UIDefine.h"
#include "BaseTutorial.generated.h"

class UTutorialsWidget;

UCLASS()
class Q6_API ABaseTutorial : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	ABaseTutorial(const FObjectInitializer& ObjectInitializer);

	// Called every frame
	virtual void Tick(float DeltaTime) override;

	void TutorialButtonClick(FString InSource);

	UFUNCTION(BlueprintCallable, Category = "Util")
	void Proceed(FString InSource);

	UFUNCTION(BlueprintCallable, Category = "Util")
	void SetStep(int32 InStep);

	UFUNCTION(BlueprintCallable, Category = "Util")
	bool IsSagaCleared(int32 InEpisode, int32 InStage, int32 InSubStage);

	UFUNCTION(BlueprintCallable, Category = "Util")
	void PauseTutorial();

	UFUNCTION(BlueprintCallable, Category = "Util")
	bool IsLogin();

	UFUNCTION(BlueprintCallable, Category = "Util")
	void SetProtectionMode(bool bInProtect);

	UFUNCTION(BlueprintCallable, Category = "Util")
	bool IsProtected() const;

	UFUNCTION(BlueprintCallable, Category = "Util")
	bool IsTutorialSkipMode() const;

	UFUNCTION(BlueprintImplementableEvent, Category = "Util")
	void InitTutorial();

	UFUNCTION(BlueprintImplementableEvent, Category = "Util")
	void OnProceedInitTutorial(FName InSource);

	virtual bool IsInTutorial() const;
	virtual void EndCurrentTutorial();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

	UPROPERTY()
	UTutorialsWidget* CurrentTutorialsWidget;

	UPROPERTY()
	bool bProtectionMode;
};
