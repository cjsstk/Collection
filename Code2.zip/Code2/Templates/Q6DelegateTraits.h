// Copyright (c) 2018 XLGames, Inc. All rights reserved.

#pragma once

template<class T>
struct TBaseDelegateTraits : public TBaseDelegateTraits<decltype(&T::operator())>
{
};

template<class R, class... Args>
struct TBaseDelegateTraits<R(*)(Args...)>
{
	using Type = TBaseDelegate<R, Args...>;
	inline static Type Create(R(*Func)(Args...))
	{
		return Type::CreateStatic(Func);
	}
};

template<class C, class R, class... Args>
struct TBaseDelegateTraits<R(C::*)(Args...) const>
{
	using Type = TBaseDelegate<R, Args...>;
	inline static Type Create(C&& Lambda)
	{
		return Type::CreateLambda(MoveTemp(Lambda));
	}
};
